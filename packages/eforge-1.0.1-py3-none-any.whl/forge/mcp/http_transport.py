"""HTTP transport for Forge MCP server.

Provides HTTP-based transport with streaming capabilities for MCP protocol.
Complements WebSocket transport with HTTP/REST interface.
"""

import asyncio
import json
import logging
import time
from contextlib import asynccontextmanager
from typing import Any, Dict, Optional, AsyncGenerator
from uuid import uuid4

from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import StreamingResponse
import mcp.types as types
from mcp.server import Server

from forge.mcp.server import _build_server
from forge.mcp.session_context import SessionContext, set_current_session, get_current_session, register_session, unregister_session

logger = logging.getLogger(__name__)


class HTTPSession:
    """Represents an HTTP session with isolated context."""
    
    def __init__(self, session_id: str, server: Server):
        self.session_id = session_id
        self.server = server
        self.project_path: Optional[str] = None
        self.session_roots: list[str] = []
        self.created_at = time.time()
        self.last_activity = time.time()
        self.client_info: Optional[dict] = None
    
    def update_activity(self) -> None:
        """Update the last activity timestamp."""
        self.last_activity = time.time()


class HTTPTransport:
    """HTTP transport for MCP server with streaming capabilities."""
    
    def __init__(self, host: str = "localhost", port: int = 8080):
        self.host = host
        self.port = port
        self.sessions: Dict[str, HTTPSession] = {}
        self.server = _build_server()
        self.app = self._create_app()
    
    def _create_app(self) -> FastAPI:
        """Create the FastAPI application with HTTP endpoints."""
        app = FastAPI(title="Forge MCP HTTP Server")
        
        @app.get("/")
        async def root():
            """Root endpoint with basic info."""
            return {
                "name": "Forge MCP HTTP Server",
                "version": "1.0.0",
                "transport": "http",
                "endpoints": {
                    "mcp": "/mcp",
                    "health": "/health",
                    "sessions": "/sessions",
                    "tools": "/tools",
                    "resources": "/resources"
                }
            }
        
        @app.get("/health")
        async def health():
            """Health check endpoint."""
            return {
                "status": "healthy",
                "timestamp": time.time(),
                "sessions": len(self.sessions)
            }
        
        @app.get("/sessions")
        async def list_sessions():
            """List active sessions."""
            return self.get_session_info()
        
        @app.post("/mcp")
        async def handle_mcp_request(request: Request):
            """Handle MCP JSON-RPC requests over HTTP."""
            try:
                body = await request.json()
                return await self._process_mcp_request(body, request)
            except json.JSONDecodeError as e:
                logger.error(f"Invalid JSON in MCP request: {e}")
                return Response(
                    json.dumps({
                        "error": "Invalid JSON",
                        "message": str(e)
                    }),
                    status_code=422,
                    media_type="application/json"
                )
            except Exception as e:
                logger.error(f"Error processing MCP request: {e}")
                return Response(
                    json.dumps({
                        "jsonrpc": "2.0",
                        "error": {
                            "code": -32603,
                            "message": "Internal error",
                            "data": str(e)
                        }
                    }),
                    status_code=500,
                    media_type="application/json"
                )
        
        @app.post("/mcp/stream")
        async def handle_mcp_stream(request: Request):
            """Handle MCP requests with streaming response."""
            try:
                body = await request.json()
                return StreamingResponse(
                    self._process_mcp_stream(body, request),
                    media_type="application/json"
                )
            except Exception as e:
                logger.error(f"Error processing MCP stream: {e}")
                return Response(
                    json.dumps({
                        "jsonrpc": "2.0",
                        "error": {
                            "code": -32603,
                            "message": "Internal error",
                            "data": str(e)
                        }
                    }),
                    status_code=500,
                    media_type="application/json"
                )
        
        @app.get("/tools")
        async def list_tools():
            """List available tools."""
            try:
                tools = await self.server.list_tools()
                return {
                    "tools": [
                        {
                            "name": tool.name,
                            "description": tool.description,
                            "inputSchema": tool.inputSchema
                        }
                        for tool in tools
                    ]
                }
            except Exception as e:
                logger.error(f"Error listing tools: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        @app.get("/resources")
        async def list_resources():
            """List available resources."""
            try:
                resources = await self.server.list_resources()
                return {
                    "resources": [
                        {
                            "uri": str(resource.uri),
                            "name": resource.name,
                            "description": resource.description,
                            "mimeType": resource.mimeType
                        }
                        for resource in resources
                    ]
                }
            except Exception as e:
                logger.error(f"Error listing resources: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        return app
    
    async def _process_mcp_request(self, message: dict, request: Request) -> Response:
        """Process a single MCP request."""
        # Extract session info from headers
        session_id = request.headers.get("X-Session-ID", str(uuid4()))
        
        # Get or create session
        if session_id not in self.sessions:
            session = HTTPSession(session_id, self.server)
            self.sessions[session_id] = session
        else:
            session = self.sessions[session_id]
        
        session.update_activity()
        
        # Set session context
        current_session = SessionContext(session_id)
        register_session(session_id, current_session)
        set_current_session(current_session)
        
        try:
            response = await self._process_mcp_message(session, message)
            return Response(
                json.dumps(response),
                media_type="application/json"
            )
        finally:
            unregister_session(session_id)
    
    async def _process_mcp_stream(self, message: dict, request: Request) -> AsyncGenerator[str, None]:
        """Process MCP request with streaming response."""
        # Extract session info from headers
        session_id = request.headers.get("X-Session-ID", str(uuid4()))
        
        # Get or create session
        if session_id not in self.sessions:
            session = HTTPSession(session_id, self.server)
            self.sessions[session_id] = session
        else:
            session = self.sessions[session_id]
        
        session.update_activity()
        
        # Set session context
        current_session = SessionContext(session_id)
        register_session(session_id, current_session)
        set_current_session(current_session)
        
        try:
            # Process the message
            response = await self._process_mcp_message(session, message)
            
            # Stream the response
            yield json.dumps(response)
            
            # For streaming operations, we could yield multiple chunks
            method = message.get("method", "")
            if method in ["tools/call", "resources/read"]:
                # Could stream partial results here
                yield "\n" + json.dumps({"stream": "complete"})
                
        finally:
            unregister_session(session_id)
    
    async def _process_mcp_message(self, session: HTTPSession, message: dict) -> dict:
        """Process an MCP message."""
        method = message.get("method")
        params = message.get("params", {})
        message_id = message.get("id")
        
        if method == "initialize":
            # Handle initialization
            session.project_path = params.get("projectPath", ".")
            session.session_roots = params.get("roots", [])
            
            # Store in session context
            current_session = get_current_session()
            if current_session:
                current_session.set_roots(session.session_roots)
                current_session.set_project_path(session.project_path)
                current_session.set_client_info(params.get("clientInfo", {}))
            
            return {
                "jsonrpc": "2.0",
                "id": message_id,
                "result": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {
                        "tools": {},
                        "resources": {},
                        "prompts": {}
                    },
                    "serverInfo": {
                        "name": "forge",
                        "version": "1.0.0",
                        "transport": "http"
                    }
                }
            }
        
        elif method == "tools/list":
            return await self._process_tools_list(session, message_id)
        
        elif method == "resources/list":
            return await self._process_resources_list(session, message_id)
        
        elif method == "tools/call":
            return await self._process_tools_call(session, message_id, params)
        
        elif method == "resources/read":
            return await self._process_resources_read(session, message_id, params)
        
        else:
            # Unknown method
            return {
                "jsonrpc": "2.0",
                "id": message_id,
                "error": {
                    "code": -32601,
                    "message": f"Method not found: {method}"
                }
            }
    
    async def _process_tools_list(self, session: HTTPSession, message_id: Optional[str]) -> dict:
        """Process tools/list request."""
        try:
            tools = await session.server.list_tools()
            return {
                "jsonrpc": "2.0",
                "id": message_id,
                "result": {
                    "tools": [
                        {
                            "name": tool.name,
                            "description": tool.description,
                            "inputSchema": tool.inputSchema
                        }
                        for tool in tools
                    ]
                }
            }
        except Exception as e:
            return {
                "jsonrpc": "2.0",
                "id": message_id,
                "error": {
                    "code": -32603,
                    "message": "Failed to list tools",
                    "data": str(e)
                }
            }
    
    async def _process_resources_list(self, session: HTTPSession, message_id: Optional[str]) -> dict:
        """Process resources/list request."""
        try:
            resources = await session.server.list_resources()
            return {
                "jsonrpc": "2.0",
                "id": message_id,
                "result": {
                    "resources": [
                        {
                            "uri": str(resource.uri),
                            "name": resource.name,
                            "description": resource.description,
                            "mimeType": resource.mimeType
                        }
                        for resource in resources
                    ]
                }
            }
        except Exception as e:
            return {
                "jsonrpc": "2.0",
                "id": message_id,
                "error": {
                    "code": -32603,
                    "message": "Failed to list resources",
                    "data": str(e)
                }
            }
    
    async def _process_tools_call(self, session: HTTPSession, message_id: str, params: dict) -> dict:
        """Process tools/call request."""
        try:
            tool_name = params.get("name")
            arguments = params.get("arguments", {})
            
            if not tool_name:
                return {
                    "jsonrpc": "2.0",
                    "id": message_id,
                    "error": {
                        "code": -32602,
                        "message": "Tool name is required"
                    }
                }
            
            result = await session.server.call_tool(tool_name, arguments)
            
            return {
                "jsonrpc": "2.0",
                "id": message_id,
                "result": {
                    "content": [
                        {
                            "type": content.type,
                            "text": content.text
                        }
                        for content in result.content
                    ],
                    "isError": result.isError
                }
            }
        except Exception as e:
            return {
                "jsonrpc": "2.0",
                "id": message_id,
                "error": {
                    "code": -32603,
                    "message": "Tool call failed",
                    "data": str(e)
                }
            }
    
    async def _process_resources_read(self, session: HTTPSession, message_id: str, params: dict) -> dict:
        """Process resources/read request."""
        try:
            uri = params.get("uri")
            if not uri:
                return {
                    "jsonrpc": "2.0",
                    "id": message_id,
                    "error": {
                        "code": -32602,
                        "message": "URI is required"
                    }
                }
            
            result = await session.server.read_resource(uri)
            
            return {
                "jsonrpc": "2.0",
                "id": message_id,
                "result": {
                    "contents": [
                        {
                            "uri": uri,
                            "mimeType": result.mimeType,
                            "text": result.text
                        }
                    ]
                }
            }
        except Exception as e:
            return {
                "jsonrpc": "2.0",
                "id": message_id,
                "error": {
                    "code": -32603,
                    "message": "Resource read failed",
                    "data": str(e)
                }
            }
    
    def get_session_info(self) -> Dict[str, Any]:
        """Get information about active sessions."""
        return {
            "total_sessions": len(self.sessions),
            "sessions": [
                {
                    "session_id": session.session_id,
                    "created_at": session.created_at,
                    "last_activity": session.last_activity,
                    "project_path": session.project_path,
                    "roots_count": len(session.session_roots)
                }
                for session in self.sessions.values()
            ]
        }
    
    async def start_server(self) -> None:
        """Start the HTTP server."""
        import uvicorn
        
        logger.info(f"Starting HTTP MCP server on {self.host}:{self.port}")
        config = uvicorn.Config(self.app, host=self.host, port=self.port, log_level="info")
        server = uvicorn.Server(config)
        await server.serve()


async def run_mcp_http(host: str = "localhost", port: int = 8080) -> None:
    """Run the MCP server over HTTP transport."""
    transport = HTTPTransport(host, port)
    await transport.start_server()


def run_mcp_http_sync(host: str = "localhost", port: int = 8080) -> None:
    """Run the MCP server over HTTP transport (synchronous)."""
    import asyncio
    
    asyncio.run(run_mcp_http(host, port))


__all__ = [
    "HTTPTransport",
    "run_mcp_http",
    "run_mcp_http_sync"
]
