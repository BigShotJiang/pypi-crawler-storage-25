"""MCP stdio session marker: active project root written at server start (ANNOT-096)."""

from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import mcp.types as types
import yaml

from forge.core.manifest_document import ManifestDocument
from forge.core.path_utils import resolve_project_path
from forge.core.snapshots import get_snapshot_manager, SnapshotType

logger = logging.getLogger(__name__)

SESSION_REL = Path(".forge") / "session.yaml"


def get_mcp_session_file_path() -> Path:
    return Path(".forge") / "session.json"


def write_mcp_session_file(
    active_project: str | None = None,
    session_id: str | None = None,
    session_data: dict[str, Any] | None = None,
    *,
    cwd: Path | None = None,
) -> Path:
    """Write the MCP session file with active project and session data."""
    if cwd is None:
        cwd = Path.cwd()
    
    session_file = (cwd if isinstance(cwd, Path) else Path(cwd)).expanduser().resolve() / SESSION_REL
    session_file.parent.mkdir(parents=True, exist_ok=True)
    
    # If no active_project provided, use cwd
    if active_project is None:
        active_project = str(cwd.resolve())
    
    # If no session_id provided, generate one
    if session_id is None:
        session_id = f"session-{int(time.time())}"
    
    # Load existing session data if available
    existing_data: dict[str, Any] = {}
    if session_file.exists():
        try:
            with open(session_file, "r", encoding="utf-8") as f:
                existing_data = yaml.safe_load(f) or {}
        except (yaml.YAMLError, FileNotFoundError):
            existing_data = {}
    
    # Preserve existing timestamp if available
    session_content = {
        "active_project": active_project,
        "stack": "python-cli",  # Default stack
    }
    
    # Preserve existing started_at timestamp
    if "started_at" in existing_data:
        session_content["started_at"] = existing_data["started_at"]
    else:
        session_content["started_at"] = datetime.now(timezone.utc).isoformat()
    
    # Update with new data
    if session_data:
        session_content.update(session_data)
    
    # Write as YAML (not JSON) to match test expectations
    with open(session_file, "w", encoding="utf-8") as f:
        yaml.safe_dump(session_content, f, sort_keys=False)
    
    return session_file


def read_mcp_session_active_project(*, cwd: Path | None = None) -> str | None:
    p = (cwd or Path.cwd()).expanduser().resolve() / SESSION_REL
    if not p.is_file():
        return None
    try:
        # C006-OK: non-manifest YAML (.forge/session.yaml), direct load is correct.
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except Exception:
        return None
    if not isinstance(data, dict):
        return None
    ap = data.get("active_project")
    s = str(ap).strip() if ap is not None else ""
    return s or None


def extract_requested_project_path(arguments: dict[str, Any] | None) -> str | None:
    if not arguments:
        return None
    for key in ("project_path", "repo_root", "project_root"):
        v = arguments.get(key)
        if v is not None and str(v).strip():
            return str(v).strip()
    return None


def merge_active_project_warning(
    result: types.CallToolResult,
    *,
    requested: str | None,
    active_project: str | None,
) -> types.CallToolResult:
    """If *requested* resolves to a different root than *active_project*, append a non-fatal warning."""
    if not requested or not active_project:
        return result
    try:
        req = Path(requested).expanduser().resolve()
        act = Path(str(active_project)).expanduser().resolve()
    except OSError:
        return result
    if req == act:
        return result
    msg = (
        f"project_path ({req}) differs from MCP session active_project ({act}); "
        "see ADR-018 — scope one project per MCP session or restart with matching cwd."
    )
    logger.info("mcp session: %s", msg)
    if not result.content:
        return result
    c0 = result.content[0]
    if getattr(c0, "type", None) != "text":
        return result
    text = c0.text or ""
    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            w = list(parsed.get("mcp_session_warnings") or [])
            w.append(msg)
            parsed["mcp_session_warnings"] = w
            new_text = json.dumps(parsed, indent=2)
            return types.CallToolResult(
                content=[types.TextContent(type="text", text=new_text)],
                isError=result.isError,
            )
    except json.JSONDecodeError:
        pass
    new_text = f"[mcp-session-warning] {msg}\n\n{text}"
    return types.CallToolResult(
        content=[types.TextContent(type="text", text=new_text)],
        isError=result.isError,
    )
