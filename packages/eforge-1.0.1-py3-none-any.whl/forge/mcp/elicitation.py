"""
forge/mcp/elicitation.py

Universal progressive disclosure for MCP tool arguments.
Any tool can call elicit_fields() before validation to
automatically fill derivable fields and queue elicitations
for fields that need user input.

Three tiers:
  TIER 1 — Mechanical derivation (always, no I/O)
  TIER 2 — Graph-assisted suggestion (when graph available)
  TIER 3 — Elicitation (only what cannot be derived)
"""
from __future__ import annotations
from pathlib import Path
from typing import Any, TYPE_CHECKING

import yaml

if TYPE_CHECKING:
    from forge.core.workspace_entity import ForgeWorkspace


def _manifest_phase_domains(project_path: Path) -> tuple[str, list[str]]:
    """Best-effort manifest phase + declared module domains for prompt hydration."""
    raw: dict[str, Any] | None = None
    try:
        from forge.core.manifest_document import ManifestDocument

        doc = ManifestDocument.from_path(project_path)
        raw = doc.raw
    except Exception:
        try:
            mf = project_path / ".forge" / "manifest.yaml"
            alt = project_path / ".forge" / "manifest.yml"
            path = mf if mf.is_file() else (alt if alt.is_file() else None)
            if path is None:
                return "", []
            blob = yaml.safe_load(path.read_text(encoding="utf-8"))
            raw = blob if isinstance(blob, dict) else None
        except Exception:
            return "", []
    if not isinstance(raw, dict):
        return "", []
    phase = str(raw.get("phase") or "").strip()
    proj = raw.get("project")
    if isinstance(proj, dict):
        phase = phase or str(proj.get("phase") or "").strip()
    domains: set[str] = set()
    for row in raw.get("modules") or []:
        if not isinstance(row, dict):
            continue
        d = str(row.get("domain") or "").strip().upper()
        if d:
            domains.add(d)
    return phase, sorted(domains)


def derive_manifest_node_fields(node: dict[str, Any]) -> dict[str, Any]:
    """Tier 1 derivation for manifest node fields.
    Fills name, tier, domain from id if not provided.
    Returns augmented node dict — never modifies in place.
    """
    node = dict(node)
    node_id = str(node.get("id", ""))

    # name from id
    if not node.get("name") and node_id:
        node["name"] = node_id.rsplit("/", 1)[-1]

    # tier from kind + id
    if not node.get("tier") and node_id:
        try:
            from forge.core.manifest import infer_tier, stable_module_node_id
            node["tier"] = infer_tier(
                stable_module_node_id(node),
                str(node.get("kind", "module"))
            ).value
        except Exception:
            node["tier"] = "worker"

    # domain from id prefix
    if not node.get("domain") and node_id.startswith("module/"):
        prefix = node_id.split("/", 1)[-1].split(".")[0].upper()
        known_domains = {
            "CORE", "MCP", "COMMANDS", "TOOLS", "TYPES",
            "TESTS", "CHECKERS", "COWORK", "DOCS", "FORGE",
            "NODE", "RENDERERS", "VALIDATION"
        }
        if prefix in known_domains:
            node["domain"] = prefix

    return node


def hydrate_arguments(
    tool_name: str,
    arguments: dict[str, Any]
) -> dict[str, Any]:
    """
    Entry point for all tools. Call before validation.
    Returns augmented arguments dict.
    Extend with tool-specific derivation as needed.
    """
    arguments = dict(arguments)

    # Manifest node hydration for append tool
    if tool_name == "forge_manifest_append":
        nodes = arguments.get("nodes", [])
        if isinstance(nodes, list):
            arguments["nodes"] = [
                derive_manifest_node_fields(n)
                if isinstance(n, dict) else n
                for n in nodes
            ]

    # Node ID resolution for graph tools
    # Converts bare names ("engine.engine") to canonical IDs ("module/engine.engine")
    if tool_name in (
        "forge_impact_radius",
        "forge_query",
        "forge_trace",
        "forge_search",
        "forge_inspect",
    ):
        node_id = arguments.get("node_id") or arguments.get("name")
        project_path = arguments.get("project_path")
        if node_id and project_path and "/" not in node_id:
            try:
                from pathlib import Path

                from forge.tools.manifest.graph import (
                    build_manifest_graph,
                    load_graph,
                    resolve_manifest_node,
                )

                root = Path(project_path)
                g, _ = load_graph(root)
                if g is None:
                    g = build_manifest_graph(root)
                resolved = resolve_manifest_node(g, node_id)
                if resolved is not None:
                    arguments["node_id"] = resolved.id
            except Exception:
                pass

    return arguments


def check_project_context(arguments: dict[str, Any]) -> dict[str, Any] | None:
    """Check whether project context is resolvable for this tool call.

    Returns ``None`` when context is resolvable (no elicitation needed).
    Returns an elicitation signal dict when project context is missing or
    ambiguous — callers embed this in their response under
    ``"_elicitation"`` so the client / agent can prompt the user.

    Rules (Sprint 3 Phase 4):
    - Explicit ``project_path`` → always OK; return ``None``.
    - No ``project_path`` + single-project workspace → auto-resolved; return ``None``.
    - No ``project_path`` + no workspace + CWD/session fallback found → return ``None``.
    - No ``project_path`` + no workspace + no fallback → elicit project selection.
    - No ``project_path`` + multi-project workspace → elicit which project.
    """
    pp = arguments.get("project_path")
    if pp is not None and str(pp).strip():
        return None

    try:
        from forge.mcp.mcp_workspace import current_forge_workspace
        fw = current_forge_workspace()
    except Exception:
        fw = None

    if fw is not None and fw.projects:
        if len(fw.projects) == 1:
            return None
        # Multi-project workspace — need disambiguation
        return {
            "elicitation_required": True,
            "elicitation_kind": "project_selection",
            "message": (
                "Multiple Forge projects are registered in the workspace. "
                "Specify project_path to disambiguate."
            ),
            "available_projects": [
                {"id": pid, "path": str(pi.path)}
                for pid, pi in fw.projects.items()
            ],
        }

    # No workspace — try CWD / session-roots fallback
    try:
        from forge.core.path_utils import resolve_project_path
        fallback = resolve_project_path(None)
        if fallback is not None:
            return None
    except Exception:
        pass

    return {
        "elicitation_required": True,
        "elicitation_kind": "project_selection",
        "message": (
            "No Forge project context is available. "
            "Provide project_path or mount a Forge project in the workspace."
        ),
        "available_projects": [],
    }


def workspace_context_dict(workspace: "ForgeWorkspace | None" = None) -> dict[str, Any]:
    """Extract a compact context dict from ``ForgeWorkspace`` for prompt hydration.

    Fields: ``project_name``, ``project_path``, ``project_id``, ``health``,
    ``project_count``.  All entries are strings or primitives — safe to embed
    in prompt templates.  Returns ``{}`` when no workspace is available.
    """
    if workspace is None:
        try:
            from forge.mcp.mcp_workspace import current_forge_workspace
            workspace = current_forge_workspace()
        except Exception:
            return {}

    if workspace is None or not workspace.projects:
        return {}

    health_status = str(
        (workspace.health or {}).get("status", "unknown")
    )
    project_count = len(workspace.projects)

    if project_count == 1:
        only = next(iter(workspace.projects.values()))
        phase_m, doms = _manifest_phase_domains(only.path)
        phase_row = str(getattr(only, "phase", "") or "").strip()
        phase = phase_m or phase_row
        return {
            "project_id": only.id,
            "project_name": only.id,
            "project_path": str(only.path),
            "health": health_status,
            "project_count": project_count,
            "phase": phase,
            "domains": doms,
        }

    return {
        "project_id": None,
        "project_name": None,
        "project_path": None,
        "health": health_status,
        "project_count": project_count,
        "projects": [
            {"id": pid, "path": str(pi.path)}
            for pid, pi in workspace.projects.items()
        ],
    }
