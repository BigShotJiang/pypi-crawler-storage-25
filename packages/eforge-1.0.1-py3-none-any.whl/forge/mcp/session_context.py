"""MCP session context management for INTENT-332931D8.

Stores session-specific information like roots and project path from the MCP handshake.
"""

from __future__ import annotations

import threading
from contextvars import ContextVar, Token
from pathlib import Path
from typing import List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from forge.core.workspace_entity import ForgeWorkspace

# Context variable for current session
_session_context: ContextVar[Optional["SessionContext"]] = ContextVar("session_context", default=None)


class SessionContext:
    """Stores MCP session context information."""

    def __init__(self, session_id: str):
        self.session_id = session_id
        self.roots: List[str] = []
        self.project_path: Optional[str] = None
        self.client_info: Optional[dict] = None
        #: Sprint 3 — hydrated from registry / workspace.yaml (optional).
        self.workspace: ForgeWorkspace | None = None
    
    def set_roots(self, roots: List[str]) -> None:
        """Set the session roots from MCP handshake."""
        self.roots = roots
    
    def set_project_path(self, project_path: str) -> None:
        """Set the project path from MCP handshake."""
        self.project_path = project_path
    
    def set_client_info(self, client_info: dict) -> None:
        """Set client information from MCP handshake."""
        self.client_info = client_info
    
    def get_effective_project_path(self) -> Optional[Path]:
        """Get the effective project path for this session."""
        if self.project_path:
            return Path(self.project_path)
        
        # If no explicit project path, try to find one in roots
        for root in self.roots:
            root_path = Path(root)
            if (root_path / ".forge" / "manifest.yaml").exists():
                return root_path
        
        return None


# Global session registry for WebSocket transport
_session_registry: dict[str, SessionContext] = {}
_session_lock = threading.Lock()


def get_current_session() -> Optional[SessionContext]:
    """Get the current session context."""
    return _session_context.get()


def set_current_session(session: SessionContext | None) -> None:
    """Set the current session context."""
    _session_context.set(session)


def push_session_context(session: SessionContext | None) -> Token:
    """Push *session* onto the context stack; return token for :func:`reset_session_context_token`."""
    return _session_context.set(session)


def reset_session_context_token(token: Token | None) -> None:
    """Reset the session context token from :func:`push_session_context`."""
    if token is not None:
        _session_context.reset(token)


def register_session(session_id: str, session: SessionContext) -> None:
    """Register a session in the global registry."""
    with _session_lock:
        _session_registry[session_id] = session


def get_session(session_id: str) -> Optional[SessionContext]:
    """Get a session from the registry."""
    with _session_lock:
        return _session_registry.get(session_id)


def unregister_session(session_id: str) -> None:
    """Remove a session from the registry."""
    with _session_lock:
        _session_registry.pop(session_id, None)


def get_all_sessions() -> dict[str, SessionContext]:
    """Get all registered sessions."""
    with _session_lock:
        return _session_registry.copy()


__all__ = [
    "SessionContext",
    "get_current_session",
    "push_session_context",
    "reset_session_context_token",
    "set_current_session",
    "register_session",
    "get_session",
    "unregister_session",
    "get_all_sessions"
]
