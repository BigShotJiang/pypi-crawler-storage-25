from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

import mcp.types as types

from forge.core.manifest_document import ManifestDocument
from forge.tools.workspace_store import load_workspace_root, projects_map, workspace_yaml_path


def get_project_context_from_meta() -> dict[str, Any] | None:
    """Get project context from _meta channel for prompt hydration."""
    try:
        from forge.mcp.server import get_meta
        return get_meta("project_context", None)
    except ImportError:
        return None


def hydrate_prompt_with_context(template: str, context: dict[str, Any] | None) -> str:
    """Hydrate a prompt template with project context variables."""
    if not context:
        return template

    replacements = {
        "{{project}}": context.get("project", ""),
        "{{project_path}}": context.get("project_path", ""),
        "{{phase}}": context.get("phase", ""),
        "{{current_task}}": context.get("current_task", ""),
        "{{blocker}}": context.get("blocker", ""),
        "{{health_score}}": str(context.get("health_score", "")),
        "{{entity_count}}": str(context.get("entity_count", "")),
        "{{layer_count}}": str(context.get("layer_count", "")),
        "{{session_id}}": context.get("session_id", ""),
    }

    result = template
    for placeholder, value in replacements.items():
        result = result.replace(placeholder, value)

    return result


def _workspace_context_for_prompt() -> dict[str, Any]:
    """Pull compact workspace context for prompt hydration (Sprint 3 Phase 4).

    Tries ``SessionContext.workspace`` first (set during MCP handshake), then
    falls back to ``current_forge_workspace()`` live resolution.  Returns ``{}``
    when no workspace is resolvable — callers treat empty dict as "no context".
    """
    # 1. Try session context (already hydrated during initialize)
    try:
        from forge.mcp.session_context import get_current_session
        sc = get_current_session()
        if sc is not None and sc.workspace is not None:
            from forge.mcp.elicitation import workspace_context_dict
            ctx = workspace_context_dict(sc.workspace)
            if ctx:
                return ctx
    except Exception:
        pass

    # 2. Live resolution via request context
    try:
        from forge.mcp.elicitation import workspace_context_dict
        return workspace_context_dict(None)
    except Exception:
        return {}

FORGE_PROMPTS: list[types.Prompt] = [
    types.Prompt(
        name="forge/start",
        description="Session entry — project context, operating contract, pipeline discovery",
        arguments=[
            types.PromptArgument(
                name="project_path",
                description="Absolute path to the project root",
                required=False,
            ),
            types.PromptArgument(
                name="intent",
                description="Brief description of session objective",
                required=False,
            ),
        ],
    ),
    types.Prompt(
        name="forge/context",
        description="Dynamic prompt hydrated with live project context from _meta",
        arguments=[
            types.PromptArgument(
                name="template",
                description="Template string with {{project}}, {{phase}}, {{current_task}} placeholders",
                required=False,
            ),
        ],
    ),
    types.Prompt(
        name="forge/audit",
        description="Audit posture — pipeline-backed scan and annotation contract",
        arguments=[
            types.PromptArgument(
                name="project_path",
                description="Absolute path to the project root",
                required=False,
            ),
        ],
    ),
]


def _project_id_from_path(project_path: str) -> str:
    p = Path(project_path).expanduser().resolve()
    # Try workspace entity first (Sprint 3 Phase 4)
    try:
        from forge.mcp.mcp_workspace import current_forge_workspace
        fw = current_forge_workspace()
        if fw is not None:
            for pid, pi in fw.projects.items():
                try:
                    if pi.path.expanduser().resolve() == p:
                        return str(pid)
                except Exception:
                    continue
    except Exception:
        pass
    ws = workspace_yaml_path()
    if ws.is_file():
        try:
            root = load_workspace_root(ws)
            pmap = projects_map(root)
            for pid, entry in pmap.items():
                if not isinstance(entry, dict):
                    continue
                ep = entry.get("path")
                if not ep:
                    continue
                if Path(str(ep)).expanduser().resolve() == p:
                    return str(pid)
        except Exception:
            pass
    return p.name


def _project_id_from_workspace() -> str | None:
    """Resolve project ID from workspace when no explicit path is given (Sprint 3 Phase 4).

    Returns the project ID string for a single-project workspace, or ``None`` when
    workspace is empty or multi-project (caller decides how to elicit).
    """
    try:
        from forge.mcp.mcp_workspace import current_forge_workspace
        fw = current_forge_workspace()
        if fw is not None and len(fw.projects) == 1:
            return next(iter(fw.projects.keys()))
    except Exception:
        pass
    return None


def _build_behavior_text(
    prompt_name: str,
    arguments: dict[str, str],
    project_id: str | None,
    workspace_ctx: dict[str, Any] | None = None,
) -> str:
    args = arguments or {}
    project_path = str(args.get("project_path") or "").strip()
    policy_mode = str(args.get("policy_mode") or "advisory").strip()
    intent = str(args.get("intent") or args.get("session_intent") or "").strip()
    wctx = workspace_ctx or {}

    if prompt_name == "forge/start":
        contract = [
            "Session contract: response_tier=L0, policy_mode=advisory, dry_run=true.",
            "_meta channels active: hints (orient), annotations (scan/verify), resource_links (orient/scan/packet/scaffold).",
            "Hidden tools: forge_blast_radius, forge_project_status, forge_context, forge_diff (situational), forge_trace (situational), forge_report (situational), forge_map (situational), forge_config_set (situational).",
            "Pipeline execution available via forge://pipeline/{id}. Fetch the descriptor and walk its steps rather than following manual instructions.",
        ]
        if project_id:
            lines = ["Session context loaded above.", *contract]
            if intent:
                lines.append(f"Intent: {intent}")
            # Inject workspace context when available (Sprint 3 Phase 4)
            if wctx:
                ws_lines: list[str] = []
                if wctx.get("project_name"):
                    ws_lines.append(f"Workspace project: {wctx['project_name']}")
                if wctx.get("project_path"):
                    ws_lines.append(f"Project path: {wctx['project_path']}")
                if wctx.get("phase"):
                    ws_lines.append(f"Phase: {wctx['phase']}")
                dom_list_phase = wctx.get("domains")
                if isinstance(dom_list_phase, list) and dom_list_phase:
                    ws_lines.append(f"Domains: {', '.join(str(d) for d in dom_list_phase)}")
                if wctx.get("health"):
                    ws_lines.append(f"Workspace health: {wctx['health']}")
                if ws_lines:
                    lines.extend(ws_lines)
            return "\n".join(lines)

        # No explicit project_path — try to source from workspace (Sprint 3 Phase 4)
        if wctx.get("project_count", 0) == 1 and wctx.get("project_name"):
            extras: list[str] = []
            if wctx.get("phase"):
                extras.append(f"Phase: {wctx['phase']}")
            dom_list = wctx.get("domains")
            if isinstance(dom_list, list) and dom_list:
                extras.append(f"Domains: {', '.join(str(d) for d in dom_list)}")
            lines = [
                f"Workspace project: {wctx['project_name']}",
                f"Project path: {wctx.get('project_path', '')}",
                *extras,
                f"Workspace health: {wctx.get('health', 'unknown')}",
                *contract,
            ]
            if intent:
                lines.append(f"Intent: {intent}")
            return "\n".join(lines)

        if wctx.get("project_count", 0) > 1:
            # Multi-project workspace — elicit which one
            project_names = ", ".join(
                p.get("id", "?") for p in (wctx.get("projects") or [])
            )
            return "\n".join(
                [
                    f"Multiple projects in workspace: {project_names}.",
                    "Specify project_path (or MCP metadata project_path) to load context for one project.",
                    *contract,
                ]
            )

        return "\n".join(
            [
                "No Forge workspace is mounted and no default project resolved. "
                "Provide project_path or open a workspace root that contains a Forge manifest.",
                *contract,
            ]
        )

    if prompt_name == "forge/context":
        template = str(args.get("template") or "").strip()
        if not template:
            template = (
                "Project: {{project}}\n"
                "Path: {{project_path}}\n"
                "Phase: {{phase}}\n"
                "Current task: {{current_task}}\n"
                "Blocker: {{blocker}}\n"
                "Health: {{health_score}}\n"
                "Entities: {{entity_count}}"
            )
        ctx = get_project_context_from_meta()
        return hydrate_prompt_with_context(template, ctx)

    if prompt_name == "forge/audit":
        return (
            "Execute forge://pipeline/audit_posture.\n"
            f"Operate with policy_mode={policy_mode} for project_path={project_path or '<from metadata/roots>'}.\n"
            "Record findings as annotations via forge_annotate."
        )

    return f"Unknown prompt: {prompt_name}"


def render_prompt_messages(
    prompt_name: str,
    arguments: dict[str, str],
    resolve_project_id: Callable[[str | None], str | None],
) -> list[dict[str, Any]]:
    args = arguments or {}
    project_path_raw = args.get("project_path")
    project_path = (
        str(project_path_raw).strip()
        if project_path_raw is not None and str(project_path_raw).strip()
        else None
    )
    project_id = resolve_project_id(project_path)

    # Sprint 3 Phase 4: when no explicit path, try workspace resolution
    workspace_ctx: dict[str, Any] = {}
    if project_id is None and project_path is None:
        workspace_ctx = _workspace_context_for_prompt()
        if not project_id and workspace_ctx.get("project_name"):
            # Single-project workspace found — use it as implicit project_id
            project_id = workspace_ctx.get("project_id") or workspace_ctx.get("project_name")

    messages: list[dict[str, Any]] = []
    if project_id:
        messages.append(
            {
                "role": "user",
                "content": [
                    {
                        "type": "resource",
                        "resource": {
                            "uri": f"forge://project/{project_id}/context",
                            "mimeType": "application/json",
                        },
                    }
                ],
            }
        )

    messages.append(
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": _build_behavior_text(
                        prompt_name, args, project_id, workspace_ctx=workspace_ctx
                    ),
                }
            ],
        }
    )
    return messages


def _to_prompt_result(messages: list[dict[str, Any]]) -> types.GetPromptResult:
    out: list[types.PromptMessage] = []
    for msg in messages:
        role = str(msg.get("role") or "user")
        blocks = msg.get("content") if isinstance(msg.get("content"), list) else []
        for block in blocks:
            if not isinstance(block, dict):
                continue
            btype = str(block.get("type") or "text")
            if btype == "resource":
                resource = block.get("resource") if isinstance(block.get("resource"), dict) else {}
                uri = str(resource.get("uri") or "").strip()
                if uri:
                    out.append(
                        types.PromptMessage(
                            role=role,
                            content=types.ResourceLink(
                                name=uri.rsplit("/", 1)[-1] or "resource",
                                uri=uri,
                                mimeType=str(resource.get("mimeType") or "application/json"),
                                type="resource_link",
                            ),
                        )
                    )
                    continue
            text = str(block.get("text") or "")
            out.append(
                types.PromptMessage(
                    role=role,
                    content=types.TextContent(type="text", text=text),
                )
            )
    return types.GetPromptResult(description="forge prompt", messages=out)


def prompt_result_from_messages(messages: list[dict[str, Any]]) -> types.GetPromptResult:
    return _to_prompt_result(messages)


async def resolve_prompt(name: str, arguments: dict[str, str] | None) -> types.GetPromptResult:
    def _resolve_id(p: str | None) -> str | None:
        if p:
            return _project_id_from_path(str(p))
        return _project_id_from_workspace()

    rendered = render_prompt_messages(
        prompt_name=name,
        arguments=arguments or {},
        resolve_project_id=_resolve_id,
    )
    return _to_prompt_result(rendered)

