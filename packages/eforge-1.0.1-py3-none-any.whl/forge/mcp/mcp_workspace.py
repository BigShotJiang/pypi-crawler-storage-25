"""Hydrate ``ForgeWorkspace`` from MCP initialize params + Forge registry — Sprint 3 + Sprint 12."""

from __future__ import annotations

import sys
from contextvars import Token
from dataclasses import replace
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

from forge.core.workspace_entity import ForgeProject, ForgeWorkspace
from forge.workspace.graph import WorkspaceGraph

_SESSION_CACHE_ATTR = "_forge_workspace_entity_v4"
_ROOTS_SIG_ATTR = "_forge_workspace_roots_sig_v5"
_NOT_CACHE = object()


def uri_to_local_path(uri: str) -> str:
    uri = uri.strip()
    if not uri:
        return uri
    if uri.startswith("file://"):
        parsed = urlparse(uri)
        raw = unquote(parsed.path or "")
        if sys.platform == "win32" and raw.startswith("/") and len(raw) >= 3 and raw[2] == ":":
            raw = raw[1:]
        return raw
    return uri


def _normalize_root_item(item: Any) -> list[str]:
    out: list[str] = []
    if isinstance(item, str) and item.strip():
        out.append(uri_to_local_path(item.strip()))
    elif isinstance(item, dict):
        uri = item.get("uri") or item.get("path") or item.get("rootUri")
        if uri is not None:
            out.append(uri_to_local_path(str(uri).strip()))
    return out


def roots_from_initialize_session(session: Any) -> list[str]:
    """Roots from ``InitializeRequestParams.model_dump()`` (includes Pydantic ``extra`` fields)."""
    params = getattr(session, "client_params", None)
    if params is None:
        return []
    try:
        data = params.model_dump(mode="python")
    except Exception:
        data = {}
    raw_roots = (
        data.get("roots")
        or data.get("workspaceRoots")
        or data.get("workspaceFolders")
        or []
    )
    out: list[str] = []
    if isinstance(raw_roots, list):
        for item in raw_roots:
            out.extend(_normalize_root_item(item))
    elif isinstance(raw_roots, str) and raw_roots.strip():
        out.append(uri_to_local_path(raw_roots.strip()))
    return out


def _merge_roots(init_roots: list[str]) -> list[str]:
    seen: set[str] = set()
    merged: list[str] = []

    try:
        from forge.mcp.session_context import get_current_session

        sc = get_current_session()
        if sc and getattr(sc, "roots", None):
            for r in sc.roots:
                s = str(r).strip()
                if not s or s in seen:
                    continue
                seen.add(s)
                merged.append(s)
    except Exception:
        pass

    for r in init_roots:
        s = str(r).strip()
        if not s or s in seen:
            continue
        seen.add(s)
        merged.append(s)
    return merged


def _normalized_root_paths(roots: list[str]) -> list[Path]:
    out: list[Path] = []
    for r in roots:
        try:
            out.append(Path(str(r)).expanduser().resolve())
        except Exception:
            continue
    return out


def _project_path_under_roots(project_path: Path, norm_roots: list[Path]) -> bool:
    try:
        pres = project_path.expanduser().resolve()
    except Exception:
        return False
    for root in norm_roots:
        try:
            pres.relative_to(root)
            return True
        except ValueError:
            continue
    return False


def filter_workspace_by_roots(fw: ForgeWorkspace, roots: list[str]) -> ForgeWorkspace | None:
    """Return a copy of *fw* containing only projects whose path lies under a root path."""
    if not roots:
        return fw
    norm = _normalized_root_paths(roots)
    if not norm:
        return fw
    filtered: dict[str, ForgeProject] = {}
    for pid, pi in fw.projects.items():
        if _project_path_under_roots(pi.path, norm):
            filtered[pid] = pi
    if not filtered:
        return None
    rel = {k: [d for d in v if d in filtered] for k, v in fw.relations.items() if k in filtered}
    return replace(
        fw,
        id=f"{fw.id}-root-scope",
        projects=filtered,
        relations=rel,
        health={
            **fw.health,
            "scoped_to_roots": True,
            "registered": len(filtered),
        },
    )


def discover_workspace_from_roots(roots: list[str]) -> ForgeWorkspace | None:
    """Synthesize a workspace from filesystem roots that contain a Forge manifest."""
    from forge.tools.registry.store import WorkspaceStore

    norm = _normalized_root_paths(roots)
    projects_map: dict[str, ForgeProject] = {}
    for rp in norm:
        mf = rp / ".forge" / "manifest.yaml"
        alt = rp / ".forge" / "manifest.yml"
        mpath = mf if mf.is_file() else (alt if alt.is_file() else None)
        if mpath is None:
            continue
        slug = rp.name
        pid = slug
        suffix = 1
        while pid in projects_map:
            pid = f"{slug}-{suffix}"
            suffix += 1
        projects_map[pid] = ForgeProject(
            id=pid,
            path=rp,
            workspace_id="mcp-root-discover",
            manifest_path=mpath,
        )
    if not projects_map:
        return None
    first = next(iter(projects_map.values()))
    return ForgeWorkspace(
        id="mcp-root-discover",
        root_path=first.path.parent,
        projects=projects_map,
        relations={k: [] for k in projects_map},
        health={"status": "healthy", "registered": len(projects_map), "source": "mcp_roots"},
        registry=WorkspaceStore(),
        registry_path=None,
        workspace_yaml_path=None,
    )


def _resolve_workspace_from_base_and_roots(base: ForgeWorkspace, merged_roots: list[str]) -> ForgeWorkspace | None:
    if merged_roots:
        scoped = filter_workspace_by_roots(base, merged_roots) if base.projects else None
        if scoped is not None:
            return scoped
        return discover_workspace_from_roots(merged_roots)
    return base if base.projects else None


def hydrate_forge_workspace_for_mcp(session: Any | None) -> ForgeWorkspace | None:
    """
    Load ``ForgeWorkspace`` from registry (or workspace graph), scoped to MCP roots when present.
    """
    if session is None:
        return _bootstrap_workspace_without_mcp_session()

    init_roots = roots_from_initialize_session(session)
    setattr(session, "_forge_mcp_init_roots_v1", list(init_roots))
    merged_roots = _merge_roots(init_roots)
    setattr(session, "_forge_mcp_roots_merged_v1", merged_roots)
    roots_sig = "\x00".join(merged_roots)
    prev_sig = getattr(session, _ROOTS_SIG_ATTR, None)
    if prev_sig != roots_sig:
        setattr(session, _ROOTS_SIG_ATTR, roots_sig)
        setattr(session, _SESSION_CACHE_ATTR, _NOT_CACHE)

    sentinel = getattr(session, _SESSION_CACHE_ATTR, _NOT_CACHE)
    if sentinel is not _NOT_CACHE:
        return sentinel  # type: ignore[return-value]

    base = ForgeWorkspace.from_registry()
    if not base.projects:
        wg_path = WorkspaceGraph.default_path()
        wg = WorkspaceGraph.load_graph(wg_path)
        if wg.all_projects():
            base = wg.to_forge_workspace(source_path=wg_path)

    fw = _resolve_workspace_from_base_and_roots(base, merged_roots)

    if fw is None or not fw.projects:
        setattr(session, _SESSION_CACHE_ATTR, None)
        try:
            from forge.mcp.session_context import get_current_session

            sc = get_current_session()
            if sc:
                sc.workspace = None
        except Exception:
            pass
        return None

    setattr(session, _SESSION_CACHE_ATTR, fw)
    try:
        from forge.mcp.session_context import get_current_session

        sc = get_current_session()
        if sc:
            sc.workspace = fw
    except Exception:
        pass
    return fw


def _bootstrap_workspace_without_mcp_session() -> ForgeWorkspace | None:
    base = ForgeWorkspace.from_registry()
    if not base.projects:
        wg_path = WorkspaceGraph.default_path()
        wg = WorkspaceGraph.load_graph(wg_path)
        if wg.all_projects():
            base = wg.to_forge_workspace(source_path=wg_path)
    try:
        from forge.mcp.session_context import get_current_session

        sc = get_current_session()
        merged = list(sc.roots) if sc and getattr(sc, "roots", None) else []
    except Exception:
        merged = []
    fw = _resolve_workspace_from_base_and_roots(base, merged)
    return fw


def bind_mcp_session_context() -> Token | None:
    """Attach :class:`~forge.mcp.session_context.SessionContext` + workspace for this MCP request.

    Returns a :class:`~contextvars.Token` when the caller must
    :func:`~forge.mcp.session_context.reset_session_context_token` afterward
    (stdio transport). HTTP/WebSocket may return ``None`` when a session context
    was already installed by the transport.
    """
    from forge.mcp.session_context import (
        SessionContext,
        get_current_session,
        push_session_context,
    )

    try:
        from mcp.server.lowlevel.server import request_ctx

        mcp_sess = request_ctx.get().session
    except Exception:
        hydrate_forge_workspace_for_mcp(None)
        return None

    existing = get_current_session()
    if existing is not None:
        merged = roots_from_initialize_session(mcp_sess)
        if merged:
            existing.set_roots(list(dict.fromkeys([*merged, *existing.roots])))
        hydrate_forge_workspace_for_mcp(mcp_sess)
        return None

    sc = getattr(mcp_sess, "_forge_session_context", None)
    if sc is None:
        sid = getattr(mcp_sess, "session_id", None) or f"mcp-{id(mcp_sess)}"
        sc = SessionContext(session_id=str(sid))
        mcp_sess._forge_session_context = sc

    init_roots = roots_from_initialize_session(mcp_sess)
    if init_roots:
        sc.set_roots(list(dict.fromkeys([*init_roots, *sc.roots])))

    token = push_session_context(sc)
    hydrate_forge_workspace_for_mcp(mcp_sess)
    return token


def current_forge_workspace() -> ForgeWorkspace | None:
    """Prefer live MCP ``ServerSession`` cache."""
    session = None
    try:
        from mcp.server.lowlevel.server import request_ctx

        session = request_ctx.get().session
    except Exception:
        session = None
    if session is not None:
        return hydrate_forge_workspace_for_mcp(session)
    return _bootstrap_workspace_without_mcp_session()


def hydrate_for_tool_invocation() -> None:
    """Prime session workspace — delegates to :func:`bind_mcp_session_context`.

    Prefer calling :func:`bind_mcp_session_context` from ``server.call_tool``
    exactly once per invocation (with matching reset token).
    """
    bind_mcp_session_context()


__all__ = [
    "bind_mcp_session_context",
    "current_forge_workspace",
    "discover_workspace_from_roots",
    "filter_workspace_by_roots",
    "hydrate_for_tool_invocation",
    "hydrate_forge_workspace_for_mcp",
    "roots_from_initialize_session",
    "uri_to_local_path",
]
