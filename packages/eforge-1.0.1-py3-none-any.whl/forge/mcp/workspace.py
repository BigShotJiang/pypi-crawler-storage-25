from __future__ import annotations

"""Helpers for Forge MCP workspace resources, templates, and file-backed lookups."""

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from forge.core import manifest_path as manifest_resolver
from forge.tools.context.agent_context_reader import load_agent_context_json
from forge.tools.glove_templates import registry as glove_registry
from forge.tools.registry.store import resolve_registry_project_path
from forge.tools.workspace_store import load_workspace_root, projects_map, workspace_yaml_path

GRAPH_TREE_URI = "forge://graph/tree"


def _tier_descriptions() -> dict[str, str]:
    return {
        "surface": "MCP-visible primitives: tools, resources, prompts. Costs startup tokens. May import surface, schema, worker.",
        "worker": "Internal pipeline helpers. Zero surface cost. Called by tools and pipelines.",
        "glove": "Stack adapters implementing IStackGlove. Worker subtype. One per stack.",
        "gate": "Elicitation/confirmation boundary models. Worker subtype. Pydantic schemas only.",
        "schema": "Typed contracts: Pydantic models, YAML schemas. May only import schema.",
        "registry": "Central lookup tables. Schema subtype. e.g. FORGE_ERROR_REGISTRY.",
        "pipeline": "Executable step descriptors. YAML files under .forge/pipelines/.",
    }


def _tier_examples() -> dict[str, list[str]]:
    return {
        "surface": ["mcp.server", "mcp.tools", "mcp.handlers"],
        "worker": ["core.manifest", "core.impact", "core.scratch", "mcp.thin_core"],
        "glove": ["core.gloves", "core.glove_mapper", "mcp.fs_glove"],
        "gate": ["ScaffoldConfirmation", "IntentConfirmation", "GithubWriteConfirmation"],
        "schema": ["core.schemas", "stack-schema-dart", "stack-schema-python"],
        "registry": ["core.registry", "mcp.registry"],
        "pipeline": ["scaffold.pipeline", "bootstrap_app.pipeline", "pre_change_brief.pipeline"],
    }


@dataclass(frozen=True)
class ResourcePaths:
    project_root: Path

    @property
    def repo_root(self) -> Path:
        return self.project_root

    @property
    def docs_adr_dir(self) -> Path:
        return self.repo_root / "docs" / "adr"

    @property
    def cowork_skill(self) -> Path:
        return self.repo_root / "cowork" / "skills" / "forge-start" / "SKILL.md"

    def schema_map(self) -> dict[str, Path]:
        return {
            "forge://schema/manifest/v1": self.repo_root / "schemas" / "v1.schema.yaml",
            "forge://schema/manifest/v2": self.repo_root / "schemas" / "v2.schema.yaml",
            "forge://schema/annotations": self.repo_root / "schemas" / "forge-annotations.schema.yaml",
            "forge://schema/command-contract": self.repo_root / "schemas" / "command_contract.schema.yaml",
            "forge://schema/registry": self.repo_root / "forge" / "core" / "registry_schema.yaml",
            "forge://schema/stacks/dart": self.repo_root / "schemas" / "stacks" / "dart.yaml",
            "forge://schema/stacks/python": self.repo_root / "schemas" / "stacks" / "python.yaml",
            "forge://schema/stacks/web": self.repo_root / "schemas" / "stacks" / "web.yaml",
            "forge://schema/stacks/astro": self.repo_root / "schemas" / "stacks" / "web.yaml",
        }


def build_workspace_registry_payload() -> dict:
    """Build workspace payload from ~/.forge/workspace.yaml."""
    ws_path = workspace_yaml_path()
    if not ws_path.is_file():
        return {
            "projects": {},
            "total": 0,
            "source": str(ws_path),
            "error": "workspace missing",
        }

    try:
        root = load_workspace_root(ws_path)
    except Exception as exc:
        return {
            "projects": {},
            "total": 0,
            "source": str(ws_path),
            "error": f"workspace unreadable: {exc}",
        }

    if not isinstance(root, dict):
        return {
            "projects": {},
            "total": 0,
            "source": str(ws_path),
            "error": "workspace unreadable: invalid document",
        }

    try:
        pmap = projects_map(root)
    except Exception as exc:
        return {
            "projects": {},
            "total": 0,
            "source": str(ws_path),
            "error": f"workspace unreadable: {exc}",
        }

    projects_out: dict[str, dict] = {}
    for k, entry in pmap.items():
        if not isinstance(entry, dict):
            continue
        pid = str(k)
        path = entry.get("path")
        if not pid or not path:
            continue
        projects_out[pid] = {
            "path": str(path),
            "stack": entry.get("stack", "unknown"),
            "phase": entry.get("phase", 1),
            "tags": entry.get("tags", []),
            "status": entry.get("status", "active"),
        }
    payload = {
        "projects": projects_out,
        "total": len(projects_out),
        "source": str(ws_path),
    }
    if not projects_out:
        payload["error"] = "workspace empty"
    return payload


def list_intended_roots(server_root: Path) -> list[dict[str, str]]:
    """Return root candidates from server root + workspace.yaml project paths."""
    roots: list[dict[str, str]] = []
    seen: set[str] = set()

    root_path = str(server_root.expanduser().resolve())
    roots.append({"name": server_root.name, "uri": f"file://{root_path}"})
    seen.add(root_path)

    ws_payload = build_workspace_registry_payload()
    projects = ws_payload.get("projects", {})
    if isinstance(projects, dict):
        for pid, entry in projects.items():
            if not isinstance(entry, dict):
                continue
            p = Path(str(entry.get("path", ""))).expanduser().resolve()
            if not p.is_dir():
                continue
            p_str = str(p)
            if p_str in seen:
                continue
            seen.add(p_str)
            roots.append({"name": str(pid), "uri": f"file://{p_str}"})
    return roots


def read_mcp_roots(server_root: Path) -> str:
    payload = {
        "roots": list_intended_roots(server_root),
        "note": "These are the intended MCP roots for this server",
    }
    return json.dumps(payload, indent=2)


def read_glove_filesystem_local_json() -> str:
    """Static descriptor for the FastMCP fs glove (``forge/mcp/fs_glove.py``)."""
    payload = {
        "kind": "filesystem",
        "stack": "local",
        "tools": ["fs_write_file", "fs_read_file", "fs_list_dir"],
        "allowed_root": "~/Projects",
        "mcp_server": "forge-fs-glove",
        "input_map_support": True,
        "error_codes": ["FS-001", "FS-002", "FS-003"],
    }
    return json.dumps(payload, indent=2)


def read_schema_resource(uri: str, project_root: Path) -> str | None:
    normalized = uri.rstrip("/")
    if normalized == "forge://schema/taxonomy":
        return read_taxonomy_json()
    if normalized == "forge://schema/errors":
        from forge.core.errors import ERRORS, ErrorCode, ErrorLayer
        from forge.core.schemas import FORGE_ERROR_REGISTRY

        combined: dict[str, Any] = {}
        for key, err in ERRORS.items():
            combined[key] = err.to_dict()
        for code, entry in FORGE_ERROR_REGISTRY.items():
            if code not in combined:
                combined[code] = entry.model_dump()
        return json.dumps(
            {
                "errors": combined,
                "taxonomy": {
                    "layers": [e.value for e in ErrorLayer],
                    "codes": [e.value for e in ErrorCode],
                },
                "causal_chain_schema": {
                    "CausalHop": {
                        "fields": {
                            "node_id": "str — manifest node ID",
                            "edge_kind": (
                                "str | None — imports/depends_on/contract"
                            ),
                            "violation": (
                                "str | None — description of violation "
                                "at this hop"
                            ),
                            "severity": (
                                "str — info/low/medium/high/critical"
                            ),
                        },
                        "description": (
                            "One step in an error causal chain. "
                            "Chain reads root→error site."
                        ),
                    }
                },
            },
            indent=2,
        )

    paths = ResourcePaths(project_root)
    path = paths.schema_map().get(uri)
    if path is None:
        return None
    if not path.is_file():
        return f"error: schema not found at {path}"
    return path.read_text(encoding="utf-8")


def read_taxonomy_json() -> str:
    from forge.core.impact import TIER_IMPORT_RULES
    from forge.core.manifest import TIER_DEFAULTS_BY_KIND, TIER_OVERRIDES_BY_ID
    from forge.core.schemas import NODE_TIER_PARENTS, NodeTier

    descriptions = _tier_descriptions()
    examples = _tier_examples()
    tiers: list[dict[str, Any]] = []
    for t in NodeTier:
        parent = NODE_TIER_PARENTS.get(t)
        subtypes = [s.value for s in NodeTier if NODE_TIER_PARENTS.get(s) == t]
        allowed_imports = [a.value for a in TIER_IMPORT_RULES.get(t, [])]
        tiers.append(
            {
                "tier": t.value,
                "parent": parent.value if parent else None,
                "subtypes": subtypes,
                "description": descriptions.get(t.value, ""),
                "allowed_imports": allowed_imports,
                "examples": examples.get(t.value, []),
            }
        )
    return json.dumps(
        {
            "schema_version": 2,
            "tiers": tiers,
            "inference_defaults": {k: v.value for k, v in TIER_DEFAULTS_BY_KIND.items()},
            # Expose both canonical node ids and short aliases for readability.
            "override_ids": {
                **{k: v.value for k, v in TIER_OVERRIDES_BY_ID.items()},
                **{
                    (k.split("module/", 1)[1] if k.startswith("module/") else k): v.value
                    for k, v in TIER_OVERRIDES_BY_ID.items()
                },
            },
            "query_note": (
                "forge_query(tier=X) includes subtypes. "
                "tier=worker returns worker+glove+gate. "
                "tier=schema returns schema+registry."
            ),
        },
        indent=2,
    )


def read_pipeline_descriptor_json(project_root: Path, pipeline_id: str) -> str | None:
    """Load ``.forge/pipelines/{pipeline_id}.pipeline.yaml`` and return JSON for ``PipelineDescriptor``."""
    pid = (pipeline_id or "").strip()
    cleaned = "".join(c for c in pid if c.isalnum() or c in "-_")
    if not cleaned or cleaned != pid:
        return json.dumps({"error": "invalid pipeline id"}, indent=2)
    path = project_root / ".forge" / "pipelines" / f"{cleaned}.pipeline.yaml"
    if not path.is_file():
        return None
    import yaml

    from forge.core.schemas import PipelineDescriptor

    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    desc = PipelineDescriptor.model_validate(raw)
    return json.dumps(desc.model_dump(), indent=2)


def resolve_project_path(project_id: str) -> Path | None:
    """Resolve project id via registry only. Raises ERR-002 for ambiguous/failed resolution."""
    # Check for empty/None project_id per INTENT-D03C4F64
    if not project_id or not str(project_id).strip():
        raise ValueError("ERR-002: Project path could not be resolved - empty project_id")
    
    result = resolve_registry_project_path(project_id)
    if result is None:
        raise ValueError(f"ERR-002: Project path could not be resolved - project '{project_id}' not found")
    return result


def resolve_manifest_file(project_root: Path) -> Path:
    """Return canonical manifest path under the project root."""
    return manifest_resolver.manifest_candidates(project_root)[0]


def resolve_annotations_file(project_root: Path) -> Path:
    return project_root / "forge" / "annotations" / "index.yaml"


def resolve_intent_file(project_root: Path) -> Path:
    return project_root / ".forge" / "intent" / "project.intent.yaml"


def read_project_annotations(project_id: str) -> str:
    try:
        root = resolve_project_path(project_id)
    except ValueError as e:
        return f"error: {e}"
    ann = resolve_annotations_file(root)
    if not ann.is_file():
        return f"error: annotations not found at {ann}"
    return ann.read_text(encoding="utf-8")


def read_project_intent(project_id: str) -> str:
    try:
        root = resolve_project_path(project_id)
    except ValueError as e:
        return f"error: {e}"
    intent_root = root / ".forge" / "intent"
    if not intent_root.is_dir():
        payload = {"records": [], "count": 0, "schema_version": 1}
        return json.dumps(payload, indent=2)
    records: list[dict[str, Any]] = []
    schema_version = 1
    try:
        import yaml

        for p in sorted(intent_root.rglob("*.intent.yaml")):
            raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            if isinstance(raw, dict) and isinstance(raw.get("records"), list):
                schema_version = int(raw.get("schema_version") or schema_version)
                for row in raw.get("records") or []:
                    if isinstance(row, dict):
                        records.append(row)
                continue
            if isinstance(raw, dict):
                records.append(raw)
    except Exception as exc:
        return json.dumps({"error": f"intent read failed: {exc}"}, indent=2)
    payload = {"records": records, "count": len(records), "schema_version": schema_version}
    return json.dumps(payload, indent=2)


def read_project_context_bundle(project_id: str) -> str:
    try:
        root = resolve_project_path(project_id)
    except ValueError as e:
        return f"error: {e}"
    payload = load_agent_context_json(root)
    if payload is None:
        return json.dumps(
            {"error": "context bundle not found — run forge context build to generate"},
            indent=2,
        )
    return json.dumps(payload, indent=2)


def read_cowork_skill(project_root: Path) -> str:
    skill = ResourcePaths(project_root).cowork_skill
    if not skill.is_file():
        return f"error: cowork skill not found at {skill}"
    return skill.read_text(encoding="utf-8")


def list_adrs(project_root: Path) -> str:
    adr_dir = ResourcePaths(project_root).docs_adr_dir
    rows: list[dict[str, str]] = []
    if adr_dir.is_dir():
        for path in sorted(adr_dir.glob("*.md")):
            stem = path.stem
            adr_id = stem.split("-", 2)[0] if stem.upper().startswith("ADR-") else stem
            if not adr_id.upper().startswith("ADR-"):
                parts = stem.split("-")
                if len(parts) >= 2 and parts[0].upper() == "ADR":
                    adr_id = f"ADR-{parts[1]}"
            rows.append({"id": adr_id.upper(), "file": f"docs/adr/{path.name}"})
    return json.dumps(rows, indent=2)


def read_adr_by_id(project_root: Path, adr_id: str) -> str:
    adr_dir = ResourcePaths(project_root).docs_adr_dir
    needle = adr_id.strip().lower()
    if not adr_dir.is_dir():
        return f"error: ADR '{adr_id}' not found"
    for path in sorted(adr_dir.glob("*.md")):
        if needle in path.name.lower():
            return path.read_text(encoding="utf-8")
    return f"error: ADR '{adr_id}' not found"


def list_glove_family(glove_id: str) -> str:
    rows: list[dict[str, Any]] = []
    for _path, _tier, data in glove_registry.discover_templates():
        if not data:
            continue
        if str(data.get("kind") or "") != glove_id:
            continue
        rows.append(dict(data))
    if not rows:
        return f"error: glove '{glove_id}' not found"
    rows.sort(key=lambda r: str(r.get("id", "")))
    return json.dumps({"glove": glove_id, "templates": rows}, indent=2)


def show_glove_template(glove_id: str, stack: str) -> str:
    hit = glove_registry.find_template_for_kind_stack(glove_id, stack)
    if hit is None:
        return f"error: template '{glove_id}.{stack}' not found"
    path, data = hit
    payload = {"id": f"{glove_id}.{stack}", "path": str(path), "template": data}
    return json.dumps(payload, indent=2)


def _parse_uri_query_params(uri: str) -> dict[str, str]:
    if "?" not in uri:
        return {}
    _, query = uri.split("?", 1)
    params: dict[str, str] = {}
    for part in query.split("&"):
        if "=" in part:
            key, value = part.split("=", 1)
            params[key] = value
    return params


def read_graph_tree_json(project_root: Path) -> str:
    """Domain-grouped declaration graph for ForgeStructuralBrowser."""
    from forge.engine.engine import ForgeEngine

    engine = ForgeEngine(project_root)
    engine.load()
    return json.dumps(engine.tree_view(), indent=2)


async def read_graph_tree_resource(uri: str) -> str:
    """MCP resource reader for ``forge://graph/tree``."""
    from forge.core.path_utils import resolve_project_path as resolve_mcp_project_path

    params = _parse_uri_query_params(uri)
    explicit = (params.get("project_path") or "").strip() or None
    root = resolve_mcp_project_path(explicit)
    if root is None:
        return json.dumps(
            {
                "error": "project path could not be resolved — set project_path query param or run from a project root",
                "uri": GRAPH_TREE_URI,
            },
            indent=2,
        )
    try:
        return read_graph_tree_json(root)
    except Exception as exc:
        return json.dumps({"error": f"graph tree load failed: {exc}", "uri": GRAPH_TREE_URI}, indent=2)


def register_workspace_graph_resources(registry: Any) -> None:
    """Register graph projection resources (``forge://graph/tree``)."""
    registry.register_resource(GRAPH_TREE_URI, read_graph_tree_resource)
