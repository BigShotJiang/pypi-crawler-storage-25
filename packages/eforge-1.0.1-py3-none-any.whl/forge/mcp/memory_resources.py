"""MCP resource handlers for the vector memory system.

Provides forge://memory resource surface for searching and accessing vector memory data.
"""

import json
import logging
from typing import Any, Dict, List, Optional

from forge.core.vector_memory import get_vector_memory_store, search_memory, VectorSearchResult
from forge.core.path_utils import resolve_project_path

logger = logging.getLogger(__name__)


def read_memory_resource(uri: str) -> str:
    """Read vector memory resource based on URI."""
    try:
        # Parse URI: forge://memory/{query_type}?{params}
        if not uri.startswith("forge://memory/"):
            raise ValueError(f"Invalid memory resource URI: {uri}")
        
        path_part = uri[14:]  # Remove "forge://memory/"
        
        if "?" in path_part:
            query_type, params_str = path_part.split("?", 1)
            params = parse_query_params(params_str)
        else:
            query_type = path_part
            params = {}
        
        project_path = params.get("project_path")
        if not project_path:
            project_path = str(resolve_project_path())
        
        if query_type == "search":
            return handle_search_query(params, project_path)
        
        elif query_type == "recent":
            return handle_recent_query(params, project_path)
        
        elif query_type == "stats":
            return handle_stats_query(params, project_path)
        
        elif query_type == "entry":
            return handle_entry_query(params, project_path)
        
        else:
            raise ValueError(f"Unknown memory resource type: {query_type}")
            
    except Exception as e:
        logger.error(f"Error reading memory resource {uri}: {e}")
        return json.dumps({"error": str(e), "uri": uri})


def parse_query_params(params_str: str) -> Dict[str, str]:
    """Parse query parameters from URL string."""
    params = {}
    for pair in params_str.split("&"):
        if "=" in pair:
            key, value = pair.split("=", 1)
            params[key] = value
    return params


def handle_search_query(params: Dict[str, str], project_path: str) -> str:
    """Handle memory search queries."""
    try:
        query = params.get("q", "")
        limit = int(params.get("limit", 10))
        content_type = params.get("content_type")
        threshold = float(params.get("threshold", 0.1))
        
        if not query:
            return json.dumps({
                "error": "Query parameter 'q' is required for search",
                "params": params
            })
        
        # Search vector memory
        results = search_memory(
            query=query,
            limit=limit,
            content_type_filter=content_type,
            project_path=project_path
        )
        
        # Format results
        formatted_results = []
        for result in results:
            formatted_results.append({
                "entry_id": result.entry.id,
                "content": result.entry.content,
                "content_type": result.entry.content_type,
                "source_id": result.entry.source_id,
                "similarity_score": result.similarity_score,
                "relevance_rank": result.relevance_rank,
                "timestamp": result.entry.timestamp,
                "iso_timestamp": result.entry.iso_timestamp,
                "metadata": result.entry.metadata
            })
        
        return json.dumps({
            "query": query,
            "limit": limit,
            "content_type_filter": content_type,
            "similarity_threshold": threshold,
            "total_results": len(formatted_results),
            "results": formatted_results
        }, indent=2)
        
    except Exception as e:
        logger.error(f"Error handling search query: {e}")
        return json.dumps({"error": str(e), "query_params": params})


def handle_recent_query(params: Dict[str, str], project_path: str) -> str:
    """Handle recent entries queries."""
    try:
        limit = int(params.get("limit", 50))
        content_type = params.get("content_type")
        
        store = get_vector_memory_store(resolve_project_path(project_path))
        entries = store.get_recent_entries(limit, content_type)
        
        # Format entries
        formatted_entries = []
        for entry in entries:
            formatted_entries.append({
                "entry_id": entry.id,
                "content": entry.content,
                "content_type": entry.content_type,
                "source_id": entry.source_id,
                "timestamp": entry.timestamp,
                "iso_timestamp": entry.iso_timestamp,
                "metadata": entry.metadata
            })
        
        return json.dumps({
            "limit": limit,
            "content_type_filter": content_type,
            "total_entries": len(formatted_entries),
            "entries": formatted_entries
        }, indent=2)
        
    except Exception as e:
        logger.error(f"Error handling recent query: {e}")
        return json.dumps({"error": str(e), "query_params": params})


def handle_stats_query(params: Dict[str, str], project_path: str) -> str:
    """Handle statistics queries."""
    try:
        store = get_vector_memory_store(resolve_project_path(project_path))
        stats = store.get_stats()
        
        return json.dumps({
            "project_path": project_path,
            "stats": stats
        }, indent=2)
        
    except Exception as e:
        logger.error(f"Error handling stats query: {e}")
        return json.dumps({"error": str(e), "query_params": params})


def handle_entry_query(params: Dict[str, str], project_path: str) -> str:
    """Handle individual entry queries."""
    try:
        entry_id = params.get("id")
        if not entry_id:
            return json.dumps({
                "error": "Entry ID parameter 'id' is required",
                "params": params
            })
        
        store = get_vector_memory_store(resolve_project_path(project_path))
        entry = store.get_entry(entry_id)
        
        if not entry:
            return json.dumps({
                "error": f"Entry not found: {entry_id}",
                "entry_id": entry_id
            })
        
        return json.dumps({
            "entry": {
                "entry_id": entry.id,
                "content": entry.content,
                "content_type": entry.content_type,
                "source_id": entry.source_id,
                "timestamp": entry.timestamp,
                "iso_timestamp": entry.iso_timestamp,
                "metadata": entry.metadata,
                "project_path": entry.project_path,
                "has_embedding": entry.embedding is not None
            }
        }, indent=2)
        
    except Exception as e:
        logger.error(f"Error handling entry query: {e}")
        return json.dumps({"error": str(e), "query_params": params})


def auto_embed_from_event_log(project_path: str, limit: int = 100) -> Dict[str, Any]:
    """Auto-embed recent event log entries into vector memory."""
    try:
        from forge.core.vector_memory import auto_embed_content
        from forge.core.event_log import get_event_log
        
        event_log = get_event_log()
        recent_events = event_log.get_recent_events(limit)
        
        embedded_count = 0
        errors = []
        
        for event in recent_events:
            try:
                # Create content from event
                content_parts = [
                    f"Event Type: {event.event_type.value}",
                    f"Severity: {event.severity.value}",
                    f"Timestamp: {event.iso_timestamp}",
                ]
                
                if event.data:
                    content_parts.append(f"Data: {json.dumps(event.data, indent=2)}")
                
                if event.metadata:
                    content_parts.append(f"Metadata: {json.dumps(event.metadata, indent=2)}")
                
                content = "\n".join(content_parts)
                
                # Auto-embed
                entry_id = auto_embed_content(
                    content=content,
                    content_type="event",
                    source_id=event.id,
                    metadata={
                        "event_type": event.event_type.value,
                        "severity": event.severity.value,
                        "project_path": event.metadata.project_path if event.metadata else None
                    },
                    project_path=project_path
                )
                
                if entry_id:
                    embedded_count += 1
                    
            except Exception as e:
                errors.append(f"Failed to embed event {event.id}: {e}")
        
        return {
            "total_events": len(recent_events),
            "embedded_count": embedded_count,
            "errors": errors,
            "project_path": project_path
        }
        
    except Exception as e:
        logger.error(f"Failed to auto-embed from event log: {e}")
        return {
            "error": str(e),
            "project_path": project_path
        }


def auto_embed_from_execution_graph(project_path: str, limit: int = 100) -> Dict[str, Any]:
    """Auto-embed recent execution graph results into vector memory."""
    try:
        from forge.core.vector_memory import auto_embed_content
        from forge.core.execution_graph import get_execution_manager
        
        execution_manager = get_execution_manager(resolve_project_path(project_path))
        recent_results = execution_manager.get_recent_results(limit)
        
        embedded_count = 0
        errors = []
        
        for result in recent_results:
            try:
                # Create content from execution result
                content_parts = [
                    f"Operation Type: {result.operation_type}",
                    f"Status: {result.status}",
                    f"Timestamp: {result.iso_timestamp}",
                    f"Project Path: {result.project_path}",
                ]
                
                if result.operation_id:
                    content_parts.append(f"Operation ID: {result.operation_id}")
                
                if result.duration_ms:
                    content_parts.append(f"Duration: {result.duration_ms}ms")
                
                if result.exit_code is not None:
                    content_parts.append(f"Exit Code: {result.exit_code}")
                
                if result.data:
                    content_parts.append(f"Data: {json.dumps(result.data, indent=2)}")
                
                if result.metadata:
                    content_parts.append(f"Metadata: {json.dumps(result.metadata, indent=2)}")
                
                content = "\n".join(content_parts)
                
                # Auto-embed
                entry_id = auto_embed_content(
                    content=content,
                    content_type="execution_result",
                    source_id=result.id,
                    metadata={
                        "operation_type": result.operation_type,
                        "status": result.status,
                        "project_path": result.project_path,
                        "duration_ms": result.duration_ms,
                        "exit_code": result.exit_code
                    },
                    project_path=project_path
                )
                
                if entry_id:
                    embedded_count += 1
                    
            except Exception as e:
                errors.append(f"Failed to embed execution result {result.id}: {e}")
        
        return {
            "total_results": len(recent_results),
            "embedded_count": embedded_count,
            "errors": errors,
            "project_path": project_path
        }
        
    except Exception as e:
        logger.error(f"Failed to auto-embed from execution graph: {e}")
        return {
            "error": str(e),
            "project_path": project_path
        }


def register_memory_resources(registry) -> None:
    """Register vector memory resource handlers with the MCP registry."""
    registry.register_resource("forge://memory/", read_memory_resource)


__all__ = [
    "read_memory_resource",
    "auto_embed_from_event_log",
    "auto_embed_from_execution_graph",
    "register_memory_resources"
]
