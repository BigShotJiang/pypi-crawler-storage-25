"""Click group helpers for grouped ``forge --help`` output."""

from __future__ import annotations

import click


class OrderedGroup(click.Group):
    """Forge root CLI group with sectioned help."""

    COMMAND_GROUPS: dict[str, list[str]] = {
        "Getting started": [
            "init",
            "orient",
            "discover",
            "verify",
            "doctor",
        ],
        "Explore": [
            "inspect",
            "map",
            "projects",
            "status",
        ],
        "Develop": [
            "intent",
            "annotate",
            "diff",
            "scan",
            "manifest",
            "packet",
            "blast-radius",
            "impact",
        ],
        "Serve": ["mcp", "board"],
        "Advanced": [
            "audit",
            "reality",
            "query",
            "trace",
            "config",
            "github-write",
            "registry",
            "toc",
        ],
    }

    def format_commands(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        for group_name, cmd_names in self.COMMAND_GROUPS.items():
            cmds: list[tuple[str, click.Command]] = []
            for name in cmd_names:
                cmd = self.get_command(ctx, name)
                if cmd is not None:
                    cmds.append((name, cmd))
            if not cmds:
                continue
            with formatter.section(group_name):
                formatter.write_dl(
                    [
                        (name, cmd.get_short_help_str(limit=formatter.width))
                        for name, cmd in cmds
                    ]
                )
