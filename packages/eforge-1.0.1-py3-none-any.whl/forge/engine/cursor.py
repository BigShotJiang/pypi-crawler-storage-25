"""
forge.engine.cursor

GraphCursor — active navigation position within a ForgeSession. Standalone so it can
be shared across sessions, reloaded from packets, or used in non-MCP contexts.

A cursor is a pointer into live engine RAM. The handle (cursor_id) is the reference.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from forge.engine.entity.schemas import NodeModel
    from forge.engine.session import ForgeSession


@dataclass
class ContextFingerprint:
    """What was happening when this cursor was created or last accessed."""

    session_key: str
    active_intents: list[str] = field(default_factory=list)
    active_annotations: list[str] = field(default_factory=list)
    phase: str | None = None
    task: str | None = None
    created_at: float = field(default_factory=time.monotonic)

    def matches(self, other: ContextFingerprint) -> bool:
        """True if same session context — same phase + overlapping intents."""
        if self.phase and other.phase:
            if self.phase != other.phase:
                return False
        overlap = set(self.active_intents) & set(other.active_intents)
        return bool(overlap) or (not self.active_intents and not other.active_intents)


@dataclass
class GraphCursor:
    """Active navigation position in a graph."""

    cursor_id: str
    node_id: str
    session_key: str

    ring_ids: dict[int, list[str]] = field(default_factory=dict)
    selection: list[str] = field(default_factory=list)
    fingerprint: ContextFingerprint | None = None
    expanded: dict[str, Any] = field(default_factory=dict)
    graph_hash: str | None = None
    last_accessed: float = field(default_factory=time.monotonic)

    def touch(self) -> None:
        self.last_accessed = time.monotonic()

    def set_rings(
        self,
        ring1: list[str],
        ring2: list[str],
        ring3: list[str] | None = None,
    ) -> None:
        self.ring_ids[1] = ring1
        self.ring_ids[2] = ring2
        if ring3 is not None:
            self.ring_ids[3] = ring3

    def get_ring(self, ring: int) -> list[str]:
        return self.ring_ids.get(ring, [])

    def select(self, node_ids: list[str]) -> None:
        self.selection = list(node_ids)

    def to_packet_dict(self) -> dict[str, Any]:
        """Serialize cursor for packet storage."""
        return {
            "cursor_id": self.cursor_id,
            "node_id": self.node_id,
            "session_key": self.session_key,
            "ring_ids": {str(k): v for k, v in self.ring_ids.items()},
            "selection": self.selection,
            "graph_hash": self.graph_hash,
            "fingerprint": {
                "phase": self.fingerprint.phase,
                "task": self.fingerprint.task,
                "active_intents": self.fingerprint.active_intents,
            }
            if self.fingerprint
            else None,
        }

    @classmethod
    def from_packet_dict(cls, data: dict[str, Any]) -> GraphCursor:
        fp_data = data.get("fingerprint") or {}
        fp = (
            ContextFingerprint(
                session_key=data.get("session_key", ""),
                phase=fp_data.get("phase"),
                task=fp_data.get("task"),
                active_intents=fp_data.get("active_intents", []),
            )
            if fp_data
            else None
        )
        c = cls(
            cursor_id=data["cursor_id"],
            node_id=data["node_id"],
            session_key=data.get("session_key", ""),
            fingerprint=fp,
            graph_hash=data.get("graph_hash"),
        )
        for k, v in (data.get("ring_ids") or {}).items():
            c.ring_ids[int(k)] = list(v)
        c.selection = list(data.get("selection") or [])
        return c


class CursorRegistry:
    """Global cursor store. Not bound to any session."""

    _cursors: dict[str, GraphCursor] = {}
    _MAX_CURSORS = 100

    @classmethod
    def create(
        cls,
        node_id: str,
        session_key: str,
        fingerprint: ContextFingerprint | None = None,
        graph_hash: str | None = None,
    ) -> GraphCursor:
        cursor_id = f"{session_key}/{node_id}"
        cursor = GraphCursor(
            cursor_id=cursor_id,
            node_id=node_id,
            session_key=session_key,
            fingerprint=fingerprint,
            graph_hash=graph_hash,
        )
        if len(cls._cursors) >= cls._MAX_CURSORS:
            oldest = min(cls._cursors.values(), key=lambda c: c.last_accessed)
            del cls._cursors[oldest.cursor_id]
        cls._cursors[cursor_id] = cursor
        return cursor

    @classmethod
    def get(cls, cursor_id: str) -> GraphCursor | None:
        c = cls._cursors.get(cursor_id)
        if c:
            c.touch()
        return c

    @classmethod
    def get_or_create(
        cls,
        node_id: str,
        session_key: str,
        **kwargs: Any,
    ) -> GraphCursor:
        cursor_id = f"{session_key}/{node_id}"
        existing = cls._cursors.get(cursor_id)
        if existing:
            existing.touch()
            return existing
        return cls.create(node_id, session_key, **kwargs)

    @classmethod
    def from_packet_dict(cls, data: dict[str, Any]) -> GraphCursor:
        cursor = GraphCursor.from_packet_dict(data)
        cls._cursors[cursor.cursor_id] = cursor
        return cursor

    @classmethod
    def invalidate(cls, cursor_id: str) -> None:
        cls._cursors.pop(cursor_id, None)

    @classmethod
    def all_for_session(cls, session_key: str) -> list[GraphCursor]:
        return [c for c in cls._cursors.values() if c.session_key == session_key]
