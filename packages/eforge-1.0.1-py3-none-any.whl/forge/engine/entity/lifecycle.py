"""Valid NodeStatus transitions for the declaration graph."""

from __future__ import annotations

from forge.core.schemas import NodeStatus

VALID_TRANSITIONS: dict[str, list[str]] = {
    "declared": ["implemented", "deprecated"],
    "implemented": ["deprecated"],
    "deprecated": [],
}


def can_transition(current: str, target: str) -> bool:
    return target in VALID_TRANSITIONS.get(current, [])


def next_states(current: str) -> list[str]:
    return list(VALID_TRANSITIONS.get(current, []))


__all__ = ["NodeStatus", "VALID_TRANSITIONS", "can_transition", "next_states"]
