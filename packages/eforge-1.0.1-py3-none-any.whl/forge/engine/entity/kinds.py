"""Re-exports from schema/kinds.py — canonical kind definitions live there."""

from forge.schema.kinds import (
    ALL_KINDS,
    FLUTTER_KINDS,
    UNIVERSAL_KINDS,
    WEB_KINDS,
    KindDefinition,
    KindRegistry,
    get_kind_registry,
)

__all__ = [
    "KindDefinition",
    "KindRegistry",
    "ALL_KINDS",
    "UNIVERSAL_KINDS",
    "FLUTTER_KINDS",
    "WEB_KINDS",
    "get_kind_registry",
]
