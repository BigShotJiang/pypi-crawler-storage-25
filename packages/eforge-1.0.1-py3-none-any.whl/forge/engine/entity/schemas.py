"""Canonical entity shapes for the engine."""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, Any, Sequence, Union

from pydantic import BaseModel, Field

from forge.core.manifest import infer_tier, stable_module_node_id
from forge.core.schemas import NodeStatus, NodeTier

if TYPE_CHECKING:
    from forge.core.schemas import ManifestNodeV2
from forge.tools.manifest.graph import MANIFEST_EDGE_RELATIONS, ManifestEdge, ManifestNode, effective_node_tier


def _str_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    s = str(value).strip()
    return [s] if s else []


def _node_status_from_manifest(node: ManifestNode) -> NodeStatus:
    st = str(node.status or "declared").strip().lower()
    meta = node.meta if isinstance(node.meta, dict) else {}
    return NodeStatus(
        declared=True,
        implemented=st == "implemented",
        reachable=meta.get("reachable") if "reachable" in meta else None,
        intended=bool(meta.get("intended", False)),
    )


class NodeEventKind(str, Enum):
    DECLARED = "declared"
    IMPLEMENTED = "implemented"
    DRIFTED = "drifted"
    VERIFIED = "verified"
    UPDATED = "updated"


class NodeEvent(BaseModel):
    timestamp: str
    event_kind: NodeEventKind
    actor: str | None = None
    detail: dict[str, Any] | None = None


class NodeModel(BaseModel):
    """Canonical node shape. Bridges ManifestNode ↔ ManifestNodeV2."""

    id: str
    name: str
    kind: str
    domain: str
    path: str
    tier: NodeTier
    role: str = ""
    depends_on: list[str] = Field(default_factory=list)
    consumed_by: list[str] = Field(default_factory=list)
    owns: list[str] = Field(default_factory=list)
    status: NodeStatus = Field(default_factory=NodeStatus)
    proposed_depends_on: list[str] = Field(default_factory=list)
    proposed_implements: list[str] = Field(default_factory=list)
    contracts: Union[list[str], dict[str, Any], None] = None
    history: list[NodeEvent] = Field(default_factory=list)
    meta: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_manifest_node(cls, node: ManifestNode) -> NodeModel:
        meta = dict(node.meta) if isinstance(node.meta, dict) else {}
        tier_raw = effective_node_tier(node)
        try:
            tier = NodeTier(str(tier_raw).strip().lower())
        except ValueError:
            tier = infer_tier(node.id, node.kind or "module")
        return cls(
            id=node.id,
            name=node.name or node.id.rsplit("/", 1)[-1],
            kind=node.kind or "module",
            domain=str(node.domain or meta.get("domain") or "CORE").strip().upper(),
            path=node.path or "",
            tier=tier,
            role=str(meta.get("role") or ""),
            depends_on=_str_list(meta.get("depends_on")),
            consumed_by=_str_list(meta.get("consumed_by")),
            owns=_str_list(meta.get("owns")),
            status=_node_status_from_manifest(node),
            proposed_depends_on=_str_list(meta.get("proposed_depends_on")),
            proposed_implements=_str_list(meta.get("proposed_implements")),
            history=[],
            meta=meta,
        )

    @classmethod
    def from_manifest_node_v2(cls, node: ManifestNodeV2) -> NodeModel:
        return cls(
            id=node.id,
            name=node.name,
            kind=node.kind,
            domain=node.domain,
            path=node.path,
            tier=node.tier,
            role=node.role,
            depends_on=list(node.depends_on),
            consumed_by=list(node.consumed_by),
            owns=list(node.owns),
            status=node.status,
            proposed_depends_on=list(node.proposed_depends_on),
            proposed_implements=list(node.proposed_implements),
            history=[],
            meta={},
        )

    @classmethod
    def append_input_field_names(cls) -> frozenset[str]:
        """Keys accepted on ``forge_manifest_append`` input objects (excluding manifest stack noise)."""
        return frozenset(cls.model_fields.keys()) | frozenset({"stack", "type"})

    @classmethod
    def from_manifest_append_dict(
        cls,
        node: dict[str, Any],
        *,
        manifest_required_fields: Sequence[str] | None = None,
    ) -> NodeModel:
        """Coerce a raw append payload into a ``NodeModel`` (defaults + tier inference)."""
        if not isinstance(node, dict):
            raise TypeError("node must be a dict")
        data: dict[str, Any] = dict(node)
        data.pop("stack", None)
        data.pop("type", None)

        node_id = str(data.get("id", "")).strip()
        if not node_id:
            raise ValueError("missing required field: id")

        if not str(data.get("name", "")).strip():
            data["name"] = node_id.rsplit("/", 1)[-1]

        if not str(data.get("kind", "")).strip():
            data["kind"] = "module"
        kind = str(data["kind"]).strip()

        if not str(data.get("path", "")).strip():
            raise ValueError("missing required field: path")

        if not str(data.get("domain", "")).strip():
            part = ""
            if node_id.startswith("module/"):
                part = node_id.split("/", 1)[-1].split(".")[0].upper()
                known = {
                    "CORE",
                    "MCP",
                    "COMMANDS",
                    "TOOLS",
                    "TYPES",
                    "TESTS",
                    "CHECKERS",
                    "COWORK",
                    "DOCS",
                    "FORGE",
                    "NODE",
                    "RENDERERS",
                    "VALIDATION",
                }
                if part in known:
                    data["domain"] = part
        if not str(data.get("domain", "")).strip():
            raise ValueError("missing required field: domain")

        tr = data.get("tier")
        if tr is None or (isinstance(tr, str) and not str(tr).strip()):
            data["tier"] = infer_tier(stable_module_node_id(data), kind)
        else:
            try:
                data["tier"] = NodeTier(str(tr).strip().lower())
            except ValueError:
                data["tier"] = infer_tier(stable_module_node_id(data), kind)

        if data.get("role") is None:
            data["role"] = ""
        else:
            data["role"] = str(data["role"])

        for list_key in (
            "depends_on",
            "consumed_by",
            "owns",
            "proposed_depends_on",
            "proposed_implements",
            "history",
        ):
            val = data.get(list_key)
            if val is None:
                data[list_key] = []
            elif list_key == "history":
                if isinstance(val, list):
                    data[list_key] = [NodeEvent.model_validate(x) for x in val]
                else:
                    data[list_key] = []
            elif not isinstance(val, list):
                data[list_key] = [str(val)]
            else:
                data[list_key] = [str(x).strip() for x in val if str(x).strip()]

        st = data.get("status")
        if st is None:
            data["status"] = NodeStatus()
        elif isinstance(st, dict):
            data["status"] = NodeStatus.model_validate(st)
        elif isinstance(st, NodeStatus):
            pass
        else:
            data["status"] = NodeStatus()

        md = data.get("meta")
        if md is None or not isinstance(md, dict):
            data["meta"] = {}

        ct = data.get("contracts")
        if ct is None:
            data["contracts"] = None
        elif isinstance(ct, dict):
            data["contracts"] = ct
        elif isinstance(ct, list):
            data["contracts"] = [str(x).strip() for x in ct if str(x).strip()]
        elif isinstance(ct, str) and ct.strip():
            data["contracts"] = [ct.strip()]
        else:
            data["contracts"] = None

        merged_req_fields = tuple(manifest_required_fields) if manifest_required_fields else ()
        skipped_req = frozenset(
            {"role", "owns", "depends_on", "consumed_by", "proposed_depends_on", "proposed_implements"}
        )
        for rf in merged_req_fields:
            fs = str(rf).strip()
            if not fs or fs == "tier" or fs in skipped_req:
                continue
            got = data.get(fs)
            if got is None or (isinstance(got, str) and not got.strip()):
                raise ValueError(f"missing required field: {fs}")

        return cls.model_validate(data)

    def to_manifest_dict(self) -> dict[str, Any]:
        """Canonical module entry shape for writing to ``manifest.yaml``."""
        out: dict[str, Any] = {
            "id": self.id,
            "name": self.name,
            "kind": self.kind,
            "domain": self.domain,
            "path": self.path,
            "tier": self.tier.value,
        }
        if str(self.role or "").strip():
            out["role"] = self.role
        for key in (
            "depends_on",
            "consumed_by",
            "owns",
            "proposed_depends_on",
            "proposed_implements",
        ):
            vals = getattr(self, key)
            if vals:
                out[key] = list(vals)
        if self.contracts is not None:
            out["contracts"] = self.contracts
        return out


class EdgeModel(BaseModel):
    """Canonical edge shape.

    Known relations are defined in MANIFEST_EDGE_RELATIONS (graph.py).
    Unknown relations are accepted with a debug log — not rejected — to
    support forge-engine and community extensions.
    """

    from_id: str
    to_id: str
    relation: str
    metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    def is_extension_relation(self) -> bool:
        """True if relation is not in MANIFEST_EDGE_RELATIONS."""
        return bool(self.relation) and self.relation not in MANIFEST_EDGE_RELATIONS

    @classmethod
    def from_manifest_edge(cls, edge: ManifestEdge) -> EdgeModel:
        """Build EdgeModel from a ManifestEdge.

        Relation validation:
          Known relations → accepted silently.
          Unknown relations → accepted with a logged warning (platform extensibility).
          Empty/None relation → accepted as empty string.

        To add a canonical relation, update MANIFEST_EDGE_RELATIONS in
        tools/manifest/graph.py.
        """
        import logging

        _log = logging.getLogger("forge.engine.entity")

        relation = str(edge.relation or "").strip()

        if relation and relation not in MANIFEST_EDGE_RELATIONS:
            _log.debug(
                "EdgeModel: unknown relation %r (from %r → %r). "
                "Add to MANIFEST_EDGE_RELATIONS if canonical, "
                "or define in your extension edge vocabulary.",
                relation,
                edge.from_id,
                edge.to_id,
            )

        meta = dict(edge.meta) if isinstance(edge.meta, dict) else {}
        return cls(
            from_id=edge.from_id,
            to_id=edge.to_id,
            relation=relation,
            metadata=meta,
        )


__all__ = ["NodeModel", "EdgeModel", "NodeTier", "NodeStatus", "NodeEvent", "NodeEventKind"]
