"""
forge.engine.subscribers.stack_reload

Subscriber that watches .forge/stacks/ for
YAML changes and hot-reloads stack profiles
into the StackProfileRegistry.

Triggered by: file_changed event
Emits: stack_profile_loaded event per profile
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from forge.events.schema import UniversalEvent
from forge.protocols.subscriber import SubscriberProtocol


class StackProfileReloadSubscriber(SubscriberProtocol):
    """Hot-reloads .forge/stacks/*.yaml when
    file_changed events are emitted.

    Enables per-project stack customization
    without restarting the MCP server.

    This is the extensibility hook for the
    scaffold procedural compiler — projects
    can override stack profiles at runtime.
    """

    subscribes_to = ["file_changed", "stack_profile_loaded"]
    version = "1.0.0"

    def __init__(
        self,
        project_path: Path,
    ) -> None:
        self._project_path = project_path
        self._stacks_dir = project_path / ".forge" / "stacks"

    def on_event(
        self,
        event: UniversalEvent,
    ) -> list[UniversalEvent]:
        if event.kind == "file_changed":
            return self._on_file_changed(event)
        return []

    def _on_file_changed(
        self,
        event: UniversalEvent,
    ) -> list[UniversalEvent]:
        payload = dict(event.payload or {})
        changed_path = str(payload.get("path") or "")

        if not changed_path:
            return []

        p = Path(changed_path)
        if not (
            p.suffix in (".yaml", ".yml")
            and ".forge" in p.parts
            and "stacks" in p.parts
        ):
            return []

        out: list[UniversalEvent] = []
        try:
            from forge.core.stack_profiles import (
                get_stack_profile_registry,
                stack_profile_from_yaml,
            )

            if not p.is_file():
                return []

            reg = get_stack_profile_registry()

            glove_map = {
                "python": "python",
                "python-cli": "python",
                "dart": "dart",
                "flutter-app": "dart",
                "web": "react",
                "astro": "react",
                "web-react": "react",
                "web-next": "react",
            }
            stem = p.stem
            glove_key = glove_map.get(stem)

            profile = stack_profile_from_yaml(p, glove_key=glove_key)
            reg.register(profile, allow_override=True)

            out.append(
                UniversalEvent(
                    kind="stack_profile_loaded",
                    source_fqid=(
                        "module/engine.subscribers.stack_reload"
                    ),
                    project=str(self._project_path),
                    payload={
                        "stack": profile.id,
                        "source": str(p),
                        "hot_reload": True,
                    },
                )
            )
        except Exception:
            pass

        return out

    def reload_all(self) -> list[str]:
        """Manually reload all profiles from
        .forge/stacks/ directory.
        Called on session startup."""
        if not self._stacks_dir.is_dir():
            return []
        try:
            from forge.core.stack_profiles import (
                get_stack_profile_registry,
            )

            reg = get_stack_profile_registry()
            return reg.load_from_yaml_dir(
                self._stacks_dir,
                allow_override=True,
            )
        except Exception:
            return []
