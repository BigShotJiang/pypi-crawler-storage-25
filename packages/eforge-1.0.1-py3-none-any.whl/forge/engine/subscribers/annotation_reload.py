"""
forge.engine.subscribers.annotation_reload

Subscriber that watches .forge/annotations/
for changes and rebuilds the annotation index.

Triggered by: file_changed, annotation_created,
              annotation_resolved events
Emits: annotation_index_reloaded event

Keeps forge_annotate query results consistent
with disk state during active sessions.
"""
from __future__ import annotations

from pathlib import Path

from forge.events.schema import UniversalEvent
from forge.protocols.subscriber import SubscriberProtocol


class AnnotationOverlayReloadSubscriber(SubscriberProtocol):
    """Rebuilds annotation index when
    annotation files change or annotations
    are created/resolved via MCP.

    Ensures forge_annotate list/query tools
    always return fresh data without needing
    a full session restart.
    """

    subscribes_to = [
        "file_changed",
        "annotation_created",
        "annotation_resolved",
    ]
    version = "1.0.0"

    def __init__(
        self,
        project_path: Path,
    ) -> None:
        self._project_path = project_path
        self._annotations_dir = (
            project_path / ".forge" / "annotations"
        )

    def on_event(
        self,
        event: UniversalEvent,
    ) -> list[UniversalEvent]:
        if event.kind == "file_changed":
            return self._on_file_changed(event)
        if event.kind in (
            "annotation_created",
            "annotation_resolved",
        ):
            return self._rebuild_index()
        return []

    def _on_file_changed(
        self,
        event: UniversalEvent,
    ) -> list[UniversalEvent]:
        payload = dict(event.payload or {})
        changed_path = str(payload.get("path") or "")

        if not changed_path:
            return []

        p = Path(changed_path)

        if not (
            p.suffix in (".yaml", ".yml")
            and ".forge" in p.parts
            and "annotations" in p.parts
        ):
            return []

        return self._rebuild_index()

    def _rebuild_index(
        self,
    ) -> list[UniversalEvent]:
        try:
            from forge.tools.audit.annotations import (
                rebuild_annotation_index,
            )

            result = rebuild_annotation_index(
                self._project_path
            )
            count = 0
            if isinstance(result, dict):
                count = int(
                    result.get("annotations")
                    or result.get("count")
                    or 0
                )

            return [
                UniversalEvent(
                    kind="annotation_index_reloaded",
                    source_fqid=(
                        "module/engine.subscribers"
                        ".annotation_reload"
                    ),
                    project=str(self._project_path),
                    payload={
                        "count": count,
                        "trigger": "subscriber",
                    },
                )
            ]
        except Exception:
            return []
