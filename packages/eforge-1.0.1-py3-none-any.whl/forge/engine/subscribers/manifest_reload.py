"""
forge.engine.subscribers.manifest_reload

Subscriber that watches manifest.yaml for
changes and reloads the ForgeEngine graph.

Triggered by: file_changed event
Emits: manifest_reloaded event

This is the highest-value subscriber for
MCP sessions — eliminates the need to restart
the server after manifest edits.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from forge.events.schema import UniversalEvent
from forge.protocols.subscriber import SubscriberProtocol


class ManifestReloadSubscriber(SubscriberProtocol):
    """Reloads the ForgeEngine graph when
    manifest.yaml changes.

    The session is invalidated and rebuilt
    so subsequent MCP calls see fresh state
    without a server restart.
    """

    subscribes_to = ["file_changed"]
    version = "1.0.0"

    MANIFEST_NAMES = frozenset({
        "manifest.yaml",
        "manifest.yml",
    })

    def __init__(
        self,
        session: Any,
    ) -> None:
        self._session = session

    def on_event(
        self,
        event: UniversalEvent,
    ) -> list[UniversalEvent]:
        payload = dict(event.payload or {})
        changed_path = str(payload.get("path") or "")

        if not changed_path:
            return []

        p = Path(changed_path).expanduser().resolve()

        if p.name not in self.MANIFEST_NAMES:
            return []

        session_path = str(
            getattr(self._session, "path", "")
        ).strip()
        if session_path:
            session_root = Path(session_path).expanduser().resolve()
            try:
                p.relative_to(session_root)
            except ValueError:
                return []

        try:
            count = self._session.reload()
            graph = self._session.engine.registry.graph
            node_count = len(list(graph.nodes))
            edge_count = len(list(graph.edges))

            return [
                UniversalEvent(
                    kind="manifest_reloaded",
                    source_fqid=(
                        "module/engine.subscribers.manifest_reload"
                    ),
                    project=str(self._session.path),
                    payload={
                        "node_count": node_count,
                        "edge_count": edge_count,
                        "trigger": changed_path,
                        "reload_count": count,
                    },
                )
            ]
        except Exception:
            return []
