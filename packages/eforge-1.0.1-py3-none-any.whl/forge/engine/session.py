"""ForgeSession — unified project + engine facade for MCP and CLI."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from forge.core.errors import ForgeError

from forge.core.forge_project_system import ForgeProject
from forge.core.scratch import ScratchStore
from forge.core.schemas import ForgeGraphQueryPayload, ForgeHealthVectorOutput
from forge.engine.engine import ForgeEngine
from forge.engine.entity.schemas import EdgeModel, NodeModel
from forge.engine.resolver import ImpactRadiusResult, InspectResult, RelationshipResolver
from forge.tools.context.schema import ContextBundle


@dataclass
class ForgeSession:
    """Unified session: cached ForgeEngine + lazy ForgeProject ECS view."""

    path: Path
    engine: ForgeEngine
    _project: Optional[ForgeProject] = field(default=None, init=False)
    _scratch: Optional[ScratchStore] = field(default=None, init=False)

    @classmethod
    def open(cls, path: str | Path) -> ForgeSession:
        """Create session and load graph. Equivalent to ForgeEngine(path) + engine.load()."""
        root = Path(path).expanduser().resolve()
        engine = ForgeEngine(root)
        engine.load()
        session = cls(path=root, engine=engine)
        session._register_drift_detectors()
        session._register_stack_profile_reload()
        session._register_manifest_reload()
        session._register_annotation_reload()
        session._wire_stack_profile_registry()
        session._wire_subscribers_to_hookbus()
        return session

    def _register_drift_detectors(self) -> None:
        try:
            from forge.engine.drift.declaration import DeclarationDriftDetector
            from forge.engine.drift.execution import ExecutionDriftDetector
            from forge.protocols.registry import get_subscriber_registry

            sub_reg = get_subscriber_registry()
            existing = [type(s).__name__ for s in sub_reg.all()]
            if "DeclarationDriftDetector" not in existing:
                sub_reg.register(
                    DeclarationDriftDetector(self.engine.registry)
                )
                decl = sub_reg.get("DeclarationDriftDetector")
                if decl is not None:
                    self.engine.hooks.register_subscriber(decl)
            if "ExecutionDriftDetector" not in existing:
                sub_reg.register(
                    ExecutionDriftDetector(self.engine.registry)
                )
                exec_sub = sub_reg.get("ExecutionDriftDetector")
                if exec_sub is not None:
                    self.engine.hooks.register_subscriber(exec_sub)
        except Exception:
            pass

    def _register_stack_profile_reload(self) -> None:
        try:
            from forge.engine.subscribers import StackProfileReloadSubscriber
            from forge.protocols.registry import get_subscriber_registry

            sub_reg = get_subscriber_registry()
            existing = [type(s).__name__ for s in sub_reg.all()]
            if "StackProfileReloadSubscriber" not in existing:
                reload_sub = StackProfileReloadSubscriber(self.path)
                sub_reg.register(reload_sub)
                self.engine.hooks.register_subscriber(reload_sub)
                reload_sub.reload_all()
        except Exception:
            pass

    def _register_manifest_reload(self) -> None:
        try:
            from forge.engine.subscribers import ManifestReloadSubscriber
            from forge.protocols.registry import get_subscriber_registry

            sub_reg = get_subscriber_registry()
            existing = [type(s).__name__ for s in sub_reg.all()]
            if "ManifestReloadSubscriber" not in existing:
                sub = ManifestReloadSubscriber(self)
                sub_reg.register(sub)
                self.engine.hooks.register_subscriber(sub)
        except Exception:
            pass

    def _register_annotation_reload(self) -> None:
        try:
            from forge.engine.subscribers import (
                AnnotationOverlayReloadSubscriber,
            )
            from forge.protocols.registry import get_subscriber_registry

            sub_reg = get_subscriber_registry()
            existing = [type(s).__name__ for s in sub_reg.all()]
            if "AnnotationOverlayReloadSubscriber" not in existing:
                sub = AnnotationOverlayReloadSubscriber(self.path)
                sub_reg.register(sub)
                self.engine.hooks.register_subscriber(sub)
        except Exception:
            pass

    def _wire_subscribers_to_hookbus(self) -> None:
        """Wire all subscribers from SubscriberRegistry into HookBus._bus.

        This is the missing bridge — sub_reg holds the subscriber objects but
        events flow through HookBus._bus. Without this, registered subscribers
        receive nothing.
        """
        try:
            from forge.protocols.registry import get_subscriber_registry

            sub_reg = get_subscriber_registry()

            already_wired = {
                type(s).__name__
                for s in self.engine.hooks._bus._subscribers
            }

            for sub in sub_reg.all():
                name = type(sub).__name__
                if name not in already_wired:
                    self.engine.hooks.register_subscriber(sub)
                    already_wired.add(name)
        except Exception:
            pass

    def _wire_stack_profile_registry(self) -> None:
        try:
            import yaml as _yaml

            from forge.core.manifest_path import resolve_manifest_path
            from forge.core.manifest import ManifestParser
            from forge.core.stack_profiles import get_stack_profile_registry
            from forge.events.schema import UniversalEvent

            reg = get_stack_profile_registry()
            local_stacks = self.path / ".forge" / "stacks"
            if local_stacks.is_dir():
                reg.load_from_yaml_dir(local_stacks, allow_override=True)

            stack = "unknown"
            mp = resolve_manifest_path(self.path)
            if mp and mp.is_file():
                try:
                    mdata = _yaml.safe_load(mp.read_text(encoding="utf-8")) or {}
                    stack = ManifestParser.get_stack(mdata) or "unknown"
                except Exception:
                    pass

            if stack != "unknown":
                self.hooks.emit(
                    UniversalEvent(
                        kind="stack_profile_loaded",
                        source_fqid="module/engine.session",
                        project=str(self.path),
                        payload={"stack": stack},
                    )
                )
        except Exception:
            pass

    def reload(self) -> int:
        """Force graph rebuild. Invalidates cached project."""
        self._project = None
        return self.engine.reload()

    def save(self) -> None:
        self.engine.save()

    @property
    def project(self) -> ForgeProject:
        """Lazy ECS view. Hydrated once, cached on session."""
        if self._project is None:
            self._project = ForgeProject.from_manifest(self.path)
            event_system = self._project.get_system("events")
            if event_system is not None and hasattr(event_system, "attach_hook_bus"):
                event_system.attach_hook_bus(self.engine.hooks)
        return self._project

    @property
    def scratch(self) -> ScratchStore:
        if self._scratch is None:
            self._scratch = ScratchStore(self.path)
            self._scratch.initialize()
        return self._scratch

    def process_pending_events(self) -> None:
        if self._project is not None:
            self._project.process_pending_events()

    def __enter__(self) -> ForgeSession:
        return self

    def __exit__(self, *_: object) -> None:
        self.save()

    def query(self, **filters: Any) -> ForgeGraphQueryPayload:
        return self.engine.query(**filters)

    def blast_radius(self, node_id: str) -> dict[str, Any]:
        return self.engine.blast_radius(node_id)

    def impact_radius(self, node_id: str) -> ImpactRadiusResult:
        return self.engine.impact_radius(node_id)

    def orient(self, node: str | None = None) -> ContextBundle:
        return self.engine.orient(node)

    def health_vector(self) -> ForgeHealthVectorOutput:
        return self.engine.health_vector()

    def tree_view(self) -> dict[str, Any]:
        return self.engine.tree_view()

    def triangulate(self, node_id: str) -> list[dict[str, Any]]:
        return self.engine.triangulate(node_id)

    def node(self, node_id: str) -> NodeModel | None:
        return self.engine.node(node_id)

    def nodes(self, **filters: Any) -> list[NodeModel]:
        return self.engine.nodes(**filters)

    def edges(self, **filters: Any) -> list[EdgeModel]:
        return self.engine.edges(**filters)

    @property
    def hooks(self) -> Any:
        return self.engine.hooks

    @property
    def registry(self) -> Any:
        return self.engine.registry

    @property
    def resolver(self) -> RelationshipResolver:
        return self.engine.resolver

    def inspect(
        self,
        node_id: str,
        fingerprint: Any = None,
    ) -> InspectResult:
        """Convenience: inspect a node via this session's resolver."""
        return self.engine.resolver.inspect(
            node_id,
            session_key=str(self.path),
            fingerprint=fingerprint,
        )

    def editor_graph(
        self,
        *,
        domain: str | None = None,
        tier: str | int | None = None,
        include_extension_edges: bool = True,
    ) -> dict[str, Any]:
        """Return the full project graph in editor format for forge-engine."""
        from forge.core.schemas import (
            EDITOR_TIER_NAMES,
            NODE_TIER_TO_EDITOR_LEVEL,
        )
        from forge.engine.projections.tree import _tier_level, to_editor_graph

        nodes = list(self.engine.registry.get_all())
        edges = list(self.engine.registry.get_edges())
        if not include_extension_edges:
            edges = [e for e in edges if not e.is_extension_relation]

        if domain:
            dom = domain.upper()
            node_ids = {n.id for n in nodes if n.domain == dom}
            nodes = [n for n in nodes if n.id in node_ids]
            edges = [
                e
                for e in edges
                if e.from_id in node_ids or e.to_id in node_ids
            ]

        if tier is not None:
            tier_key = (
                str(tier).strip().lower()
                if isinstance(tier, str)
                else int(tier)
            )
            if isinstance(tier_key, str) and tier_key in EDITOR_TIER_NAMES:
                want_level = EDITOR_TIER_NAMES[tier_key]
                nodes = [
                    n
                    for n in nodes
                    if _tier_level(n.tier) == want_level
                ]
            elif isinstance(tier_key, int):
                nodes = [
                    n for n in nodes if _tier_level(n.tier) == tier_key
                ]
            else:
                want = str(tier).strip().lower()
                nodes = [
                    n
                    for n in nodes
                    if str(n.tier.value).lower() == want
                    or NODE_TIER_TO_EDITOR_LEVEL.get(
                        str(n.tier.value).lower()
                    ) == EDITOR_TIER_NAMES.get(want)
                ]
            node_ids = {n.id for n in nodes}
            edges = [
                e
                for e in edges
                if e.from_id in node_ids and e.to_id in node_ids
            ]

        return to_editor_graph(nodes, edges)

    def node_detail(self, node_id: str) -> dict[str, Any]:
        """Full node detail for the editor inspector panel."""
        from forge.mcp.thin_core import execute_inspect

        return execute_inspect({
            "project_path": str(self.path),
            "node_id": node_id,
            "action": "node",
            "response_tier": "L2",
        })

    def highlight_blast_radius(self, node_id: str) -> dict[str, Any]:
        """Return blast radius data structured for editor highlighting."""
        ring_1: list[str] = []
        ring_2: list[str] = []
        ring_3: list[str] = []

        def _ids_from_raw(items: Any) -> list[str]:
            out: list[str] = []
            if not isinstance(items, list):
                return out
            for it in items:
                if isinstance(it, dict):
                    nid = str(it.get("id") or it.get("node_id") or "")
                else:
                    nid = str(getattr(it, "id", it))
                if nid:
                    out.append(nid)
            return out

        try:
            impact = self.impact_radius(node_id)
            raw = impact.blast_raw or {}
            consumers = raw.get("import_consumers") or []
            if isinstance(consumers, list) and consumers:
                if isinstance(consumers[0], dict):
                    ring_1 = [
                        str(c.get("id") or c.get("node_id") or "")
                        for c in consumers
                        if c.get("id") or c.get("node_id")
                    ]
                else:
                    ring_1 = [str(c) for c in consumers if str(c)]
            if not ring_1:
                ring_1 = list(impact.doc_updates_required or [])
            ring_2 = _ids_from_raw(raw.get("dependents"))
            ring_3 = _ids_from_raw(
                list(raw.get("watchers") or [])
                + list(raw.get("siblings") or [])
                + list(raw.get("domain_members") or [])
            )
        except Exception:
            try:
                raw = self.blast_radius(node_id)
                ring_2 = _ids_from_raw(raw.get("dependents"))
                ring_3 = _ids_from_raw(raw.get("watchers"))
            except Exception:
                pass

        total = len(set(ring_1) | set(ring_2) | set(ring_3))
        rings = {
            "1": {"nodes": ring_1},
            "2": {"nodes": ring_2},
            "3": {"nodes": ring_3},
        }
        return {
            "source_node": node_id,
            "ring_1": ring_1,
            "ring_2": ring_2,
            "ring_3": ring_3,
            "total_affected": total,
            "schema_version": "blast/v1",
            "rings": rings,
        }

    def explain_error(
        self,
        error: "ForgeError",
    ) -> "ForgeError":
        """
        Auto-enrich a ForgeError with graph context.

        Traverses the manifest graph to answer:
          - Who is this node?
          - What domain is it in?
          - What tier is it?
          - Who depends on it? (blast radius)
          - What depends on it? (consumed_by)
          - What does it depend on? (depends_on)
          - Was intent declared?

        Returns a copy of the error enriched with:
          - causal_chain built from graph data
          - affected_node_ids from blast radius
          - hint updated with domain/tier context
          - suggested_commands updated

        If source_node_id is None or node not found,
        returns the error unchanged.
        """
        from forge.core.errors import CausalHop
        import copy

        def _resolve_bool_field(val: Any, key: str) -> bool:
            if isinstance(val, bool):
                return val
            if isinstance(val, dict):
                v = val.get(key)
                if v is None:
                    return False
                return bool(v)
            if isinstance(val, str):
                return key.lower() in val.lower()
            return False

        def _resolve_str_field(
            val: Any, fallback: str = "unknown"
        ) -> str:
            if val is None:
                return fallback
            if isinstance(val, str):
                return val.split(".")[-1].lower()
            if hasattr(val, "value"):
                return str(val.value).lower()
            if hasattr(val, "name"):
                return str(val.name).lower()
            return str(val).split(".")[-1].lower()

        if not error.source_node_id:
            return error

        node_id = error.source_node_id

        try:
            detail = self.node_detail(node_id)
        except Exception:
            return error

        node = detail.get("node") or {}
        domain = node.get("domain", "UNKNOWN")
        tier_label = _resolve_str_field(
            node.get("tier_label") or node.get("tier")
        )
        depends_on = node.get("depends_on", [])
        consumed_by = node.get("consumed_by", [])
        status = node.get("status", {})
        path = node.get("path", "")

        try:
            blast = self.highlight_blast_radius(node_id)
            ring_1 = blast.get("ring_1", [])
            ring_2 = blast.get("ring_2", [])
            all_affected = list(
                dict.fromkeys(ring_1 + ring_2))
        except Exception:
            ring_1 = []
            ring_2 = []
            all_affected = []

        intended = _resolve_bool_field(status, "intended")
        implemented = _resolve_bool_field(status, "implemented")

        chain: list[CausalHop] = []

        chain.append(CausalHop(
            node_id=node_id,
            edge_kind=None,
            violation=error.code.value
                if hasattr(error.code, "value")
                else str(error.code),
            severity="high",
        ))

        for dep_id in ring_1[:3]:
            chain.append(CausalHop(
                node_id=dep_id,
                edge_kind="consumed_by",
                violation="propagated_failure",
                severity="medium",
            ))

        hint_parts = [error.hint]
        if domain and domain != "UNKNOWN":
            hint_parts.append(
                f"Domain: {domain}"
            )
        if tier_label and tier_label != "unknown":
            hint_parts.append(
                f"Tier: {tier_label}"
            )
        if all_affected:
            hint_parts.append(
                f"Blast radius: "
                f"{len(all_affected)} nodes affected"
            )
        if not implemented:
            hint_parts.append(
                "Status: declared but not implemented"
            )
        elif not intended:
            hint_parts.append(
                "No intent declared — "
                "add intent to improve diagnostics"
            )
        if path:
            hint_parts.append(f"File: {path}")

        enriched = copy.deepcopy(error)
        enriched.causal_chain = chain
        enriched.affected_node_ids = all_affected
        enriched.graph_nodes = list(
            dict.fromkeys(
                depends_on + consumed_by
            )
        )
        enriched.hint = " | ".join(hint_parts)

        cmds = list(enriched.suggested_commands)
        if node_id not in " ".join(cmds):
            cmds.insert(0,
                f"forge inspect {node_id}"
            )
        if all_affected:
            cmds.append(
                f"forge blast-radius {node_id}"
            )
        enriched.suggested_commands = cmds

        return enriched
