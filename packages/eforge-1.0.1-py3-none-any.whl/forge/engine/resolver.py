"""RelationshipResolver — graph traversal and query over EntityRegistry."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from forge.core.impact import collect_tier_import_violations
from forge.core.manifest_path import resolve_manifest_path
from forge.core.query import forge_query
from forge.core.query_index import SQLiteQueryBackend
from forge.core.schemas import ChangeEvent, ForgeGraphQueryPayload
from forge.engine.entity.schemas import EdgeModel, NodeModel
from forge.engine.registry import EntityRegistry
from forge.tools.triangulation import triangulate_graphs


@dataclass
class ImpactRadiusResult:
    """Unified impact analysis result for a single node.

    Combines three sources:
    - ``affected_nodes``: all nodes reachable via blast_radius_ring2 (ring1 = direct
      import callers; ring2 = transitive watchers / dependents / siblings / domain peers).
    - ``doc_updates_required``: first-degree import consumers of ``node_id`` (nodes
      with ``imports`` or ``depends_on`` edges pointing at the target).
    - ``contract_violations``: tier-import violations involving ``node_id``.
    - ``ring``: 0 = node found, no ring2 dependents (true leaf); 1 = direct import
      callers only (no transitive); 2 = ring2 transitive nodes exist.
    - ``blast_raw``: raw ``blast_radius_ring2`` dict preserved for backward-compat slicing
      by handler layers (watchers / dependents / siblings / domain_members sections);
      also includes additive ``import_consumers`` and ``contracts`` when the graph has
      ``imports`` / ``contract`` edges.
    """

    affected_nodes: list[NodeModel]
    doc_updates_required: list[str]
    contract_violations: list[str]
    ring: int
    blast_raw: dict[str, Any] = field(default_factory=dict)
    rule_sources: list[str] = field(default_factory=list)


@dataclass
class InspectResult:
    """Node-centric inspection result.

    InspectResult answers: "what IS this node?"
    ImpactRadiusResult answers: "what breaks if this node changes?"
    """

    node_id: str
    node: NodeModel | None

    ring1_ids: list[str]
    ring2_ids: list[str]
    ring3_ids: list[str]

    ring1_count: int
    ring2_count: int
    ring3_count: int

    imports: list[str]
    imported_by: list[str]

    annotation_count: int = 0
    intent_count: int = 0
    contract_count: int = 0
    tier_violations: list[str] = field(default_factory=list)
    drift_items: list[dict[str, Any]] = field(default_factory=list)

    handle: str = ""
    available_actions: list[dict[str, Any]] = field(default_factory=list)


class RelationshipResolver:
    def __init__(self, registry: EntityRegistry) -> None:
        self.registry = registry

    def dependencies(self, node_id: str, depth: int = 1) -> list[NodeModel]:
        return self._traverse(node_id, depth=depth, direction="in")

    def dependents(self, node_id: str, depth: int = 1) -> list[NodeModel]:
        return self._traverse(node_id, depth=depth, direction="out")

    def blast_radius(self, node_id: str) -> dict[str, Any]:
        g = self.registry.graph
        return g.blast_radius_ring2(node_id)

    def trace(self, from_id: str, to_id: str) -> list[str] | None:
        g = self.registry.graph
        if from_id not in {n.id for n in g.nodes} or to_id not in {n.id for n in g.nodes}:
            return None
        queue: deque[list[str]] = deque([[from_id]])
        seen = {from_id}
        while queue:
            path = queue.popleft()
            cur = path[-1]
            if cur == to_id:
                return path
            for e in g.edges_from(cur):
                nxt = e.to_id
                if nxt in seen:
                    continue
                seen.add(nxt)
                queue.append(path + [nxt])
        return None

    def subgraph(self, node_ids: list[str]) -> tuple[list[NodeModel], list[EdgeModel]]:
        ids = {str(x).strip() for x in node_ids if str(x).strip()}
        nodes = [n for n in self.registry.get_all() if n.id in ids]
        edges = [
            e
            for e in self.registry.get_edges()
            if e.from_id in ids and e.to_id in ids
        ]
        return nodes, edges

    def triangulate(self, node_id: str) -> list[dict[str, Any]]:
        root = self.registry.graph.project_path
        return triangulate_graphs(root, scope_target=node_id, graph=self.registry.graph)

    def tier_violations(self) -> list[ChangeEvent]:
        return collect_tier_import_violations(self.registry.graph)

    def impact_radius(self, node_id: str) -> ImpactRadiusResult:
        """Unified impact analysis: blast_radius + direct import consumers + tier violations.

        Ring semantics:
          ring=0 — node found, no ring2 dependents (true leaf).
          ring=1 — direct import callers only (no transitive).
          ring=2 — at least one ring2 transitive node exists (watcher / dependent /
                   sibling / domain member / parity peer / import consumer).
        """
        raw = self.blast_radius(node_id)

        # Collect ring2 IDs (watchers / dependents / siblings / domain / parity).
        ring2_ids: set[str] = set()
        for key in ("watchers", "dependents", "siblings", "domain_members"):
            for n in raw.get(key, []):
                nid = n.id if hasattr(n, "id") else str(n.get("id", ""))
                if nid:
                    ring2_ids.add(nid)
        # import_consumers use "node_id" key, not "id"
        for item in raw.get("import_consumers", []):
            if isinstance(item, dict):
                nid = item.get("node_id", "") or item.get("id", "")
            else:
                nid = getattr(item, "id", "") or getattr(item, "node_id", "")
            if nid:
                ring2_ids.add(str(nid))
        for nid in raw.get("parity_reachable", {}).get("nodes", []):
            if str(nid):
                ring2_ids.add(str(nid))

        ring = 2 if ring2_ids else 0

        # Resolve to NodeModel (registry maps ManifestNode → NodeModel).
        affected_nodes: list[NodeModel] = [
            nm
            for nid in sorted(ring2_ids)
            if (nm := self.registry.get_node(nid)) is not None
        ]

        # doc_updates_required: direct import consumers only.
        # Full BFS propagation is too broad — nearly every node
        # in a connected graph becomes reachable within 10 hops.
        # Direct importers are the nodes that actually need
        # immediate doc review when this node changes.
        doc_updates_required = sorted({
            e.from_id
            for e in self.registry.graph.edges_to(node_id)
            if e.relation in ("imports", "depends_on")
            and e.from_id != node_id
        })

        # contract_violations: tier violations scoped to this node.
        all_violations = self.tier_violations()
        scoped = [
            ev
            for ev in all_violations
            if node_id in (ev.affected_node_ids or [])
        ]
        contract_violations = [
            (
                f"{ev.change_class.value}: "
                f"{ev.context.get('edge', '')} "
                f"({ev.context.get('from_tier', '')} → {ev.context.get('to_tier', '')})"
            )
            for ev in scoped
        ]

        from forge.tools.manifest.propagation import load_rules

        rules = load_rules(self.registry.graph.project_path)
        rule_sources = sorted({r.source for r in rules if hasattr(r, "source")})

        return ImpactRadiusResult(
            affected_nodes=affected_nodes,
            doc_updates_required=doc_updates_required,
            contract_violations=contract_violations,
            ring=ring,
            blast_raw=raw,
            rule_sources=rule_sources,
        )

    def inspect(
        self,
        node_id: str,
        session_key: str = "",
        fingerprint: Any = None,
    ) -> InspectResult:
        """Node-centric inspection with progressive ring traversal."""
        from forge.engine.cursor import ContextFingerprint, CursorRegistry

        g = self.registry.graph
        node = self.registry.get_node(node_id)

        imports = [
            e.to_id
            for e in g.edges_from(node_id)
            if e.relation in ("imports", "depends_on")
        ]
        imported_by = [
            e.from_id
            for e in g.edges_to(node_id)
            if e.relation in ("imports", "depends_on")
        ]

        ring1_ids = imported_by

        raw = self.blast_radius(node_id)
        ring2_ids: list[str] = []
        for key in ("watchers", "dependents", "siblings", "domain_members"):
            for n in raw.get(key, []):
                nid = n.id if hasattr(n, "id") else str(n.get("id", ""))
                if nid and nid not in ring2_ids:
                    ring2_ids.append(nid)
        for item in raw.get("import_consumers", []):
            nid = (
                item.get("node_id", "")
                if isinstance(item, dict)
                else getattr(item, "node_id", "")
            )
            if nid and nid not in ring2_ids:
                ring2_ids.append(nid)

        ring3_ids: list[str] = []
        for nid in raw.get("parity_reachable", {}).get("nodes", []):
            if str(nid) and str(nid) not in ring3_ids:
                ring3_ids.append(str(nid))
        for e in g.edges_from(node_id):
            if e.relation == "contract" and e.to_id not in ring3_ids:
                ring3_ids.append(e.to_id)

        drift_items: list[dict[str, Any]] = []
        try:
            from forge.core.temporal_triangulation import triangulate_temporal_contracts

            result = triangulate_temporal_contracts(
                g.project_path,
                node_id=node_id,
                response_tier="L1",
            )
            drift_items = result.get("results", [])
        except Exception:
            pass

        annotation_count = 0
        intent_count = 0
        try:
            from forge.tools.audit.annotations import load_annotation_index_entries

            entries = load_annotation_index_entries(g.project_path)
            annotation_count = sum(
                1 for e in entries if node_id in str(e.get("affects", "") or "")
            )
        except Exception:
            pass
        try:
            from forge.tools.intent.runtime import load_intent_records

            records = load_intent_records(g.project_path)
            intent_count = sum(1 for r in records if (r.target_id or "") == node_id)
        except Exception:
            pass

        all_violations = self.tier_violations()
        tier_violations = [
            f"{ev.change_class.value}: {ev.context.get('edge', '')}"
            for ev in all_violations
            if node_id in (ev.affected_node_ids or [])
        ]

        contract_count = len(
            [e for e in g.edges_from(node_id) if e.relation == "contract"]
        )

        cursor = CursorRegistry.get_or_create(
            node_id=node_id,
            session_key=session_key,
            fingerprint=fingerprint,
        )
        cursor.set_rings(ring1_ids, ring2_ids, ring3_ids)

        available_actions: list[dict[str, Any]] = []
        if ring1_ids:
            available_actions.append({
                "action": "expand",
                "params": {"handle": cursor.cursor_id, "ring": 1},
                "description": f"Load {len(ring1_ids)} direct importer(s) full data",
            })
        if ring2_ids:
            available_actions.append({
                "action": "expand",
                "params": {"handle": cursor.cursor_id, "ring": 2},
                "description": f"Load {len(ring2_ids)} transitive peer(s) full data",
            })
        if drift_items:
            available_actions.append({
                "action": "diff",
                "params": {"handle": cursor.cursor_id},
                "description": f"{len(drift_items)} drift item(s) detected — inspect drift",
            })
        available_actions.append({
            "action": "select",
            "params": {"handle": cursor.cursor_id, "ids": "list of node_ids"},
            "description": "Focus on specific nodes",
        })
        available_actions.append({
            "action": "packet",
            "params": {"handle": cursor.cursor_id},
            "description": "Save navigation state as packet",
        })

        return InspectResult(
            node_id=node_id,
            node=node,
            ring1_ids=ring1_ids,
            ring2_ids=ring2_ids,
            ring3_ids=ring3_ids,
            ring1_count=len(ring1_ids),
            ring2_count=len(ring2_ids),
            ring3_count=len(ring3_ids),
            imports=imports,
            imported_by=imported_by,
            annotation_count=annotation_count,
            intent_count=intent_count,
            contract_count=contract_count,
            tier_violations=tier_violations,
            drift_items=drift_items,
            handle=cursor.cursor_id,
            available_actions=available_actions,
        )

    def query(self, **filters: Any) -> ForgeGraphQueryPayload:
        from dataclasses import asdict

        from forge.core.workspace_entity import ForgeWorkspace

        g = self.registry.graph
        root = g.project_path
        proj_id = str(filters.get("project_id") or "").strip()
        ws_ctx = ForgeWorkspace.from_registry()

        proj = ws_ctx.get_project(proj_id) if proj_id else None
        if proj_id and proj is None:
            return ForgeGraphQueryPayload.model_validate(
                {"operation": "workspace_project_miss", "project_id": proj_id}
            )

        where = {
            "domain": str(filters.get("domain") or ""),
            "name": str(filters.get("name") or ""),
            "depends_on": str(filters.get("depends_on") or ""),
        }
        kind = str(filters.get("kind") or "")
        has_structural = any(str(where.get(k) or "").strip() for k in ("domain", "name", "depends_on")) or bool(
            kind.strip()
        )
        if proj is not None and proj_id and not has_structural and not filters.get("reverse_of"):
            row = dict(asdict(proj))
            row["path"] = str(row.get("path", ""))
            mp = row.get("manifest_path")
            row["manifest_path"] = str(mp) if mp is not None else ""
            row["operation"] = "workspace_project"
            return ForgeGraphQueryPayload.model_validate(row)

        tier_arg = filters.get("tier")
        tier_s = (str(tier_arg) if tier_arg is not None else "").strip()
        _skip_accelerator = bool(filters.get("_skip_accelerator"))
        common_kw: dict[str, Any] = {
            "kind": kind,
            "where": where,
            "reverse_of": filters.get("reverse_of"),
            "via": filters.get("via"),
            "limit": int(filters.get("limit", 50)),
            "depth": int(filters.get("depth", 1)),
            "direction": str(filters.get("direction") or "both"),
            "sort_by": filters.get("sort_by"),
            "tier": tier_arg,
            "expand_relevant": bool(filters.get("expand_relevant")),
            "expand_domain": filters.get("expand_domain"),
            "expand_max_total": int(filters.get("expand_max_total") or 30),
            "_skip_accelerator": _skip_accelerator,
            "project_path": str(proj.path) if proj is not None else None,
        }
        pp_extra = filters.get("project_path")
        pr_extra = filters.get("project_root")
        if common_kw["project_path"] is None:
            raw_scope = pp_extra if pp_extra is not None and str(pp_extra).strip() else pr_extra
            if raw_scope is not None and str(raw_scope).strip():
                common_kw["project_path"] = str(raw_scope).strip()
        if common_kw.get("project_path"):
            common_kw["_skip_accelerator"] = True
        backend: SQLiteQueryBackend | None = None
        manifest_path = resolve_manifest_path(root, warn_on_root_fallback=False)
        if manifest_path is not None and not common_kw["_skip_accelerator"] and not tier_s:
            backend = SQLiteQueryBackend(root, manifest_path)
            backend.get_or_build(g)
        result = forge_query(g, backend=backend, **common_kw)
        has_structural = any(str(where.get(k) or "").strip() for k in ("domain", "name", "depends_on")) or bool(
            kind.strip()
        )
        if backend is not None and not (result.data.get("nodes") or []) and has_structural:
            retry_kw = {**common_kw, "_skip_accelerator": True}
            result = forge_query(g, backend=None, **retry_kw)
        return ForgeGraphQueryPayload.model_validate(result.as_dict())

    def _traverse(self, node_id: str, *, depth: int, direction: str) -> list[NodeModel]:
        g = self.registry.graph
        if node_id not in {n.id for n in g.nodes}:
            return []
        seen: set[str] = set()
        out: list[NodeModel] = []
        frontier = {node_id}
        for _ in range(max(1, depth)):
            nxt: set[str] = set()
            for nid in frontier:
                if direction in ("out", "both"):
                    for e in g.edges_from(nid):
                        if e.to_id not in seen:
                            nxt.add(e.to_id)
                if direction in ("in", "both"):
                    for e in g.edges_to(nid):
                        if e.from_id not in seen:
                            nxt.add(e.from_id)
            for nid in nxt:
                seen.add(nid)
                nm = self.registry.get_node(nid)
                if nm is not None:
                    out.append(nm)
            frontier = nxt
            if not frontier:
                break
        return out
