"""Execution drift detector — temporal triangulation."""

from __future__ import annotations

from pathlib import Path

from forge.core.temporal_triangulation import triangulate_temporal_contracts
from forge.events.schema import UniversalEvent
from forge.protocols.subscriber import SubscriberProtocol
from forge.tools.triangulation import triangulate_graphs


class ExecutionDriftDetector(SubscriberProtocol):
    subscribes_to = ["node_drifted", "graph_built"]
    version = "1.0.0"

    def __init__(self, registry) -> None:
        self._registry = registry

    def on_event(self, event: UniversalEvent) -> list[UniversalEvent]:
        out: list[UniversalEvent] = []
        try:
            root = Path(str(event.project)).expanduser().resolve()
            node_id = str((event.payload or {}).get("node_id") or "").strip()
            if node_id:
                rows = triangulate_graphs(root, scope_target=node_id, graph=self._registry.graph)
                for row in rows:
                    out.append(
                        UniversalEvent(
                            kind="node_drifted",
                            source_fqid="module/engine.drift.execution",
                            project=str(root),
                            payload={"drift_type": "triangulation", **row},
                        )
                    )
                temporal = triangulate_temporal_contracts(root, node_id=node_id)
                rows = temporal.get("results") if isinstance(temporal, dict) else []
                for item in rows or []:
                    if isinstance(item, dict):
                        out.append(
                            UniversalEvent(
                                kind="node_drifted",
                                source_fqid="module/engine.drift.execution",
                                project=str(root),
                                payload={"drift_type": "temporal", **item},
                            )
                        )
        except Exception:
            return []
        return out
