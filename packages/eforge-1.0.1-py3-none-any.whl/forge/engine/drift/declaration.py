"""Declaration drift detector — intent vs declaration, tier violations."""

from __future__ import annotations

from pathlib import Path

from forge.core.impact import collect_tier_import_violations
from forge.events.schema import UniversalEvent
from forge.protocols.subscriber import SubscriberProtocol
from forge.tools.intent.runtime import diff_intent_vs_declaration


class DeclarationDriftDetector(SubscriberProtocol):
    subscribes_to = ["node_declared", "node_implemented", "schema_changed"]
    version = "1.1.0"

    def __init__(self, registry) -> None:
        self._registry = registry

    def on_event(self, event: UniversalEvent) -> list[UniversalEvent]:
        if event.kind == "schema_changed":
            try:
                return list(self._on_schema_changed(event))
            except Exception:
                return []
        try:
            return list(self._on_manifest_event(event))
        except Exception:
            return []

    def _on_schema_changed(self, event: UniversalEvent) -> list[UniversalEvent]:
        payload = dict(event.payload or {})
        if not bool(payload.get("breaking")):
            return []
        sid = str(payload.get("schema_id") or "").strip()
        consumers = payload.get("consumer_node_ids") or ()
        drift_type = str(payload.get("drift_type") or "schema_breaking_change")
        return [
            UniversalEvent(
                kind="node_drifted",
                source_fqid="module/engine.drift.declaration",
                project=str(event.project),
                payload={
                    "drift_type": drift_type,
                    "node_id": nid,
                    "schema_id": sid,
                    "diff": payload.get("diff"),
                },
            )
            for nid in sorted({str(x).strip() for x in consumers if str(x).strip()})
        ]

    def _on_manifest_event(self, event: UniversalEvent) -> list[UniversalEvent]:
        out: list[UniversalEvent] = []
        root = Path(str(event.project)).expanduser().resolve()
        try:
            graph = self._registry.graph  # noqa: SLF001
        except RuntimeError:
            return []
        for row in diff_intent_vs_declaration(root, graph):
            node_id = str(row.get("target_id") or row.get("node_id") or "")
            out.append(
                UniversalEvent(
                    kind="node_drifted",
                    source_fqid="module/engine.drift.declaration",
                    project=str(root),
                    payload={"drift_type": row.get("drift_type"), "node_id": node_id, **row},
                )
            )
        for ev in collect_tier_import_violations(graph):
            out.append(
                UniversalEvent(
                    kind="node_drifted",
                    source_fqid="module/engine.drift.declaration",
                    project=str(root),
                    payload={
                        "drift_type": "tier_import_violation",
                        "node_id": str((ev.affected_node_ids or [""])[0]),
                        "detail": ev.model_dump() if hasattr(ev, "model_dump") else str(ev),
                    },
                )
            )
        return out
