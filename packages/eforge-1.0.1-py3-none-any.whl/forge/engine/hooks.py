"""HookBus — typed facade over EventBus + EventEmitter."""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from pathlib import Path
from typing import Any

from forge.engine.entity.schemas import NodeModel
from forge.engine.history import EntityHistorySubscriber, get_entity_history_store
from forge.events.bus import EventBus
from forge.events.schema import UniversalEvent
from forge.protocols.subscriber import SubscriberProtocol


class HookBus:
    """Typed event facade; wraps forge.events.bus.EventBus."""

    def __init__(self, project_path: Path | str) -> None:
        self._path = Path(project_path).expanduser().resolve()
        self._bus = EventBus(self._path)
        store = get_entity_history_store(self._path)
        self._bus.subscribe(EntityHistorySubscriber(store))

    def emit_node_declared(
        self,
        node: NodeModel,
        *,
        actor: str | None = None,
        detail: dict[str, Any] | None = None,
    ) -> None:
        self._publish(
            "node_declared",
            {
                "node_id": node.id,
                "kind": node.kind,
                "domain": node.domain,
                "actor": actor,
                "detail": detail,
            },
        )

    def emit_node_implemented(
        self,
        node: NodeModel,
        *,
        actor: str | None = None,
        detail: dict[str, Any] | None = None,
    ) -> None:
        self._publish(
            "node_implemented",
            {
                "node_id": node.id,
                "kind": node.kind,
                "path": node.path,
                "actor": actor,
                "detail": detail,
            },
        )

    def emit_node_drifted(
        self,
        node: NodeModel,
        drift_info: dict[str, Any],
        *,
        actor: str | None = None,
    ) -> None:
        payload = {"node_id": node.id, "actor": actor, **drift_info}
        self._publish("node_drifted", payload)

    def emit_node_updated(
        self,
        node: NodeModel,
        *,
        actor: str | None = None,
        detail: dict[str, Any] | None = None,
    ) -> None:
        self._publish(
            "node_updated",
            {"node_id": node.id, "kind": node.kind, "actor": actor, "detail": detail},
        )

    def emit_verify_passed(
        self,
        node_ids: list[str],
        *,
        actor: str | None = None,
        detail: dict[str, Any] | None = None,
    ) -> None:
        self._publish("verify_passed", {"node_ids": list(node_ids), "actor": actor, "detail": detail})

    def emit_graph_built(self, node_count: int) -> None:
        self._publish("graph_built", {"node_count": node_count})

    def emit_graph_scan_completed(self, project: str) -> None:
        self._publish("graph_built", {"project": project, "scan_completed": True})

    def emit_file_changed(
        self,
        path: str,
        *,
        change_type: str = "modified",
        actor: str | None = None,
    ) -> None:
        """Emit file_changed event.

        Triggers StackProfileReloadSubscriber and ManifestReloadSubscriber when
        path is in .forge/ directory.
        """
        self._publish(
            "file_changed",
            {
                "path": str(path),
                "change_type": change_type,
                "actor": actor,
            },
        )

    def emit_manifest_reloaded(
        self,
        *,
        node_count: int,
        edge_count: int,
        actor: str | None = None,
    ) -> None:
        """Emit manifest_reloaded event.

        Signals that graph state has changed and dependent caches should invalidate.
        """
        self._publish(
            "manifest_reloaded",
            {
                "node_count": node_count,
                "edge_count": edge_count,
                "actor": actor,
            },
        )

    def emit_annotation_index_reloaded(
        self,
        *,
        count: int,
        actor: str | None = None,
    ) -> None:
        self._publish(
            "annotation_index_reloaded",
            {
                "count": count,
                "actor": actor,
            },
        )

    def emit_schema_changed(
        self,
        *,
        schema_id: str,
        breaking: bool,
        diff_summary: Mapping[str, Any],
        consumer_node_ids: Sequence[str],
    ) -> list[UniversalEvent]:
        """Publish a bounded schema-diff fact; downstream subscribers produce further events."""
        ev = UniversalEvent(
            kind="schema_changed",
            source_fqid="module/engine.hooks",
            project=str(self._path),
            payload={
                "schema_id": str(schema_id).strip(),
                "breaking": bool(breaking),
                "diff": dict(diff_summary),
                "consumer_node_ids": tuple(str(x) for x in consumer_node_ids),
            },
        )
        try:
            return list(self._bus.publish(ev))
        except Exception:
            return []

    def emit(self, event: UniversalEvent) -> None:
        """Emit a generic event through the bus."""
        try:
            self._bus.publish(event)
        except Exception:
            pass

    def register_subscriber(self, subscriber: SubscriberProtocol) -> None:
        self._bus.subscribe(subscriber)

    def discover_subscribers(self, forge_dir: Path) -> list[str]:
        return self._bus.discover(forge_dir)

    def on(self, event_kind: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            class _FnSubscriber(SubscriberProtocol):
                subscribes_to = [event_kind]
                version = "1.0.0"

                def handles_event(self, kind: str) -> bool:
                    return kind == event_kind

                def on_event(self, event: UniversalEvent) -> list[UniversalEvent]:
                    fn(event)
                    return []

            self.register_subscriber(_FnSubscriber())
            return fn

        return decorator

    def _publish(self, kind: str, payload: dict[str, Any]) -> None:
        ev = UniversalEvent(
            kind=kind,
            source_fqid="module/engine.hooks",
            project=str(self._path),
            payload=payload,
        )
        self._bus.publish(ev)
