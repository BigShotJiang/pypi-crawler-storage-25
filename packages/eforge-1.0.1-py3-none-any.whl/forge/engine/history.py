"""Entity history cache + JSONL persistence."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from forge.engine.entity.schemas import NodeEvent, NodeEventKind
from forge.events.schema import UniversalEvent


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class EntityHistoryStore:
    """Append-only node history backed by `.forge/entity_history.jsonl`."""

    def __init__(self, project_path: Path | str) -> None:
        self.project_path = Path(project_path).expanduser().resolve()
        self._history_path = self.project_path / ".forge" / "entity_history.jsonl"
        self._loaded = False
        self._events_by_node: dict[str, list[NodeEvent]] = {}

    @property
    def history_path(self) -> Path:
        return self._history_path

    def load(self) -> None:
        if self._loaded:
            return
        self._events_by_node = {}
        if self._history_path.is_file():
            try:
                for line in self._history_path.read_text(encoding="utf-8").splitlines():
                    if not line.strip():
                        continue
                    try:
                        row = json.loads(line)
                    except Exception:
                        continue
                    node_id = str(row.get("node_id") or "").strip()
                    ev_raw = row.get("event")
                    if not node_id or not isinstance(ev_raw, dict):
                        continue
                    try:
                        event = NodeEvent.model_validate(ev_raw)
                    except Exception:
                        continue
                    self._events_by_node.setdefault(node_id, []).append(event)
            except Exception:
                self._events_by_node = {}
        self._loaded = True

    def events_for(self, node_id: str) -> list[NodeEvent]:
        self.load()
        return list(self._events_by_node.get(str(node_id), []))

    def append(
        self,
        node_id: str,
        event_kind: NodeEventKind,
        *,
        actor: str | None = None,
        detail: dict[str, Any] | None = None,
        timestamp: str | None = None,
    ) -> NodeEvent:
        self.load()
        node_s = str(node_id or "").strip()
        if not node_s:
            raise ValueError("node_id is required")
        event = NodeEvent(
            timestamp=str(timestamp or _utc_now_iso()),
            event_kind=event_kind,
            actor=actor,
            detail=detail,
        )
        self._events_by_node.setdefault(node_s, []).append(event)
        self._history_path.parent.mkdir(parents=True, exist_ok=True)
        row = {"node_id": node_s, "event": event.model_dump()}
        with self._history_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=True) + "\n")
        return event


class EntityHistorySubscriber:
    """HookBus subscriber that records node lifecycle events."""

    subscribes_to = ["node_declared", "node_implemented", "node_drifted", "verify_passed", "node_updated"]
    version = "1.0.0"

    def __init__(self, store: EntityHistoryStore) -> None:
        self._store = store

    def handles_event(self, kind: str) -> bool:
        return kind in self.subscribes_to

    def on_event(self, event: UniversalEvent) -> list[UniversalEvent]:
        payload = dict(event.payload or {})
        actor = str(payload.get("actor") or "").strip() or None
        detail = payload.get("detail")
        detail_map = detail if isinstance(detail, dict) else None
        if event.kind == "verify_passed":
            node_ids = payload.get("node_ids")
            if isinstance(node_ids, list):
                for node_id in node_ids:
                    nid = str(node_id or "").strip()
                    if nid:
                        self._store.append(nid, NodeEventKind.VERIFIED, actor=actor, detail=detail_map)
            return []

        node_id = str(payload.get("node_id") or "").strip()
        if not node_id:
            return []
        kind_map = {
            "node_declared": NodeEventKind.DECLARED,
            "node_implemented": NodeEventKind.IMPLEMENTED,
            "node_drifted": NodeEventKind.DRIFTED,
            "node_updated": NodeEventKind.UPDATED,
        }
        event_kind = kind_map.get(event.kind)
        if event_kind is None:
            return []
        self._store.append(node_id, event_kind, actor=actor, detail=detail_map)
        return []


_HISTORY_STORES: dict[Path, EntityHistoryStore] = {}


def get_entity_history_store(project_path: Path | str) -> EntityHistoryStore:
    root = Path(project_path).expanduser().resolve()
    store = _HISTORY_STORES.get(root)
    if store is None:
        store = EntityHistoryStore(root)
        _HISTORY_STORES[root] = store
    return store

