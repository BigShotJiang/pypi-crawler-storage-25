"""EntityRegistry — typed facade over ManifestGraph."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from forge.core.forge_project_system import ForgeEntity

from forge.core.graph_scope import manifest_graph_scoped
from forge.engine.entity.schemas import EdgeModel, NodeModel
from forge.engine.history import EntityHistoryStore, get_entity_history_store
from forge.tools.manifest.graph import (
    ManifestEdge,
    ManifestGraph,
    ManifestNode,
    build_manifest_graph,
    load_graph,
    save_graph,
)


class EntityRegistry:
    """Single source of truth for declaration graph nodes."""

    def __init__(self) -> None:
        self._graph: ManifestGraph | None = None
        self._project_path: Path | None = None
        self._history_store: EntityHistoryStore | None = None

    def load(self, project_path: Path | str) -> int:
        """Load graph from cache or build fresh. Returns node count."""
        root = Path(project_path).expanduser().resolve()
        self._project_path = root
        self._history_store = get_entity_history_store(root)
        self._history_store.load()
        use_cache = True
        manifest_path = root / ".forge" / "manifest.yaml"
        cache_path = root / ".forge" / "manifest_graph.json"
        if manifest_path.exists() and cache_path.exists():
            if manifest_path.stat().st_mtime > cache_path.stat().st_mtime:
                use_cache = False
        cached, _built_at = (None, None) if not use_cache else load_graph(root)
        if cached is not None:
            self._graph = cached
        else:
            self._graph = build_manifest_graph(root)
            save_graph(self._graph)
        return self.node_count

    def save(self) -> Path:
        """Persist graph to ``.forge/manifest_graph.json``."""
        if self._graph is None:
            raise RuntimeError("registry not loaded — call load() first")
        return save_graph(self._graph)

    @classmethod
    def attach_graph(cls, graph: ManifestGraph) -> EntityRegistry:
        """Bind a pre-built graph (no disk reload) — Sprint 10 schema drift + workspace views."""
        reg = cls()
        reg._project_path = Path(graph.project_path).expanduser().resolve()
        reg._graph = graph
        return reg

    @classmethod
    def filtered_view(cls, base: EntityRegistry, project_root: Path) -> EntityRegistry:
        """Subset ``base`` to nodes/edges under ``project_root`` without reloading from disk."""
        g0 = base.graph
        scoped = manifest_graph_scoped(g0, Path(project_root))
        return cls.attach_graph(scoped)

    def get_node(self, node_id: str) -> NodeModel | None:
        g = self._require_graph()
        for n in g.nodes:
            if n.id == node_id:
                return self._attach_history(NodeModel.from_manifest_node(n))
        return None

    def get_entity(self, node_id: str) -> ForgeEntity | None:
        """Lazy hydration: returns ForgeEntity for node_id, or None if not found."""
        node = self.get_node(node_id)
        if node is None:
            return None
        from forge.core.forge_project_system import ForgeEntity

        return ForgeEntity.from_manifest_node(self._node_model_to_manifest(node))

    def get_all(
        self,
        kind: str | None = None,
        domain: str | None = None,
        status: str | None = None,
        tier: str | None = None,
        name: str | None = None,
    ) -> list[NodeModel]:
        g = self._require_graph()
        out: list[NodeModel] = []
        kind_f = (kind or "").strip().lower()
        domain_f = (domain or "").strip().upper()
        status_f = (status or "").strip().lower()
        tier_f = (tier or "").strip().lower()
        name_f = (name or "").strip().lower()
        for n in g.nodes:
            if kind_f and (n.kind or "").lower() != kind_f:
                continue
            if domain_f and domain_f not in (n.domain or "").upper():
                continue
            if status_f and (n.status or "").lower() != status_f:
                continue
            if tier_f:
                nm = NodeModel.from_manifest_node(n)
                if nm.tier.value != tier_f:
                    continue
            if name_f and name_f not in (n.name or "").lower() and name_f not in n.id.lower():
                continue
            out.append(self._attach_history(NodeModel.from_manifest_node(n)))
        return out

    def get_edges(
        self,
        from_id: str | None = None,
        to_id: str | None = None,
        relation: str | None = None,
    ) -> list[EdgeModel]:
        g = self._require_graph()
        rel_f = (relation or "").strip()
        out: list[EdgeModel] = []
        for e in g.edges:
            if from_id and e.from_id != from_id:
                continue
            if to_id and e.to_id != to_id:
                continue
            if rel_f and e.relation != rel_f:
                continue
            out.append(EdgeModel.from_manifest_edge(e))
        return out

    def edges(
        self,
        from_id: str | None = None,
        to_id: str | None = None,
        relation: str | None = None,
    ) -> list[EdgeModel]:
        return self.get_edges(from_id=from_id, to_id=to_id, relation=relation)

    def upsert(self, node: NodeModel) -> NodeModel:
        g = self._require_graph()
        existing = next((n for n in g.nodes if n.id == node.id), None)
        manifest_node = self._node_model_to_manifest(node)
        if existing is not None:
            idx = g.nodes.index(existing)
            g.nodes[idx] = manifest_node
        else:
            g.nodes.append(manifest_node)
        return node

    def remove(self, node_id: str) -> bool:
        g = self._require_graph()
        before = len(g.nodes)
        g.nodes = [n for n in g.nodes if n.id != node_id]
        g.edges = [e for e in g.edges if e.from_id != node_id and e.to_id != node_id]
        return len(g.nodes) < before

    @property
    def graph(self) -> ManifestGraph:
        return self._require_graph()

    @property
    def node_count(self) -> int:
        if self._graph is None:
            return 0
        return len(self._graph.nodes)

    @property
    def edge_count(self) -> int:
        if self._graph is None:
            return 0
        return len(self._graph.edges)

    def _require_graph(self) -> ManifestGraph:
        if self._graph is None:
            raise RuntimeError("registry not loaded — call load() first")
        return self._graph

    def _attach_history(self, node: NodeModel) -> NodeModel:
        if self._history_store is None:
            return node
        return node.model_copy(update={"history": self._history_store.events_for(node.id)})

    @staticmethod
    def _node_model_to_manifest(node: NodeModel) -> ManifestNode:
        st = "implemented" if node.status.implemented else "declared"
        meta = dict(node.meta)
        meta.setdefault("tier", node.tier.value)
        meta.setdefault("role", node.role)
        meta["depends_on"] = list(node.depends_on)
        meta["consumed_by"] = list(node.consumed_by)
        meta["owns"] = list(node.owns)
        meta["proposed_depends_on"] = list(node.proposed_depends_on)
        meta["proposed_implements"] = list(node.proposed_implements)
        return ManifestNode(
            id=node.id,
            kind=node.kind,
            name=node.name,
            path=node.path,
            domain=node.domain,
            parent_id=None,
            status=st,
            meta=meta,
        )
