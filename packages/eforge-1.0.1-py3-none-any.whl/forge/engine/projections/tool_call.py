"""MCP tool-call projections from NodeModel."""

from __future__ import annotations

from typing import Any

from forge.core.schemas import ForgeGraphQueryPayload
from forge.engine.entity.schemas import EdgeModel, NodeModel
from forge.core.schemas import ForgeNodeOutput


def to_tool_call_dict(node: NodeModel) -> dict[str, Any]:
    return node.model_dump()


def to_query_output(
    nodes: list[NodeModel],
    edges: list[EdgeModel],
) -> ForgeGraphQueryPayload:
    return ForgeGraphQueryPayload.model_validate(
        {
            "count": len(nodes),
            "nodes": [to_tool_call_dict(n) for n in nodes],
            "edges": [e.model_dump() for e in edges],
        }
    )


def node_list_to_forge_node_output(nodes: list[NodeModel]) -> list[ForgeNodeOutput]:
    out: list[ForgeNodeOutput] = []
    for n in nodes:
        st = "implemented" if n.status.implemented else "declared"
        out.append(
            ForgeNodeOutput(
                id=n.id,
                kind=n.kind,
                tier=n.tier.value,
                domain=n.domain,
                status=st,
                name=n.name,
                properties=n.meta,
            )
        )
    return out
