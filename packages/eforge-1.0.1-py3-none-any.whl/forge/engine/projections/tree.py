"""Tree projections for ForgeStructuralBrowser."""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from forge.core.schemas import EDITOR_TIER_LABELS, NODE_TIER_TO_EDITOR_LEVEL
from forge.engine.entity.schemas import EdgeModel, NodeModel


def to_tree(nodes: list[NodeModel], edges: list[EdgeModel] | None = None) -> dict[str, Any]:
    """Group nodes by domain. *edges* is accepted for API symmetry with ``to_flat_graph`` but not used."""
    _ = edges
    by_domain: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for n in nodes:
        st = "implemented" if n.status.implemented else "declared"
        by_domain[n.domain or "CORE"].append(
            {
                "id": n.id,
                "kind": n.kind,
                "status": st,
                "depends_on": list(n.depends_on),
                "consumed_by": list(n.consumed_by),
            }
        )
    domains = [
        {"name": name, "nodes": sorted(rows, key=lambda row: row["id"])}
        for name, rows in sorted(by_domain.items())
    ]
    return {"domains": domains}


def to_flat_graph(nodes: list[NodeModel], edges: list[EdgeModel]) -> dict[str, Any]:
    return {
        "nodes": [
            {
                "id": n.id,
                "kind": n.kind,
                "domain": n.domain,
                "tier": n.tier.value,
                "status": "implemented" if n.status.implemented else "declared",
                "depends_on": list(n.depends_on),
                "consumed_by": list(n.consumed_by),
            }
            for n in nodes
        ],
        "edges": [e.model_dump() for e in edges],
    }


def _tier_level(tier: Any) -> int:
    raw = getattr(tier, "value", tier)
    return NODE_TIER_TO_EDITOR_LEVEL.get(str(raw).strip().lower(), 3)


def to_editor_graph(
    nodes: list[NodeModel],
    edges: list[EdgeModel],
) -> dict[str, Any]:
    """Canonical graph payload for the visual editor (forge-engine).

    This is the data contract between forge and forge-engine. The schema
    version must be bumped if the shape changes in a breaking way.

    forge-engine depends on this. Do not change field names without
    a migration path.
    """
    domain_colors = {
        "ENGINE": "#6366f1",
        "MCP": "#8b5cf6",
        "CORE": "#06b6d4",
        "TOOLS": "#10b981",
        "CLI": "#f59e0b",
        "EVENTS": "#ef4444",
        "METRICS": "#ec4899",
        "PROTOCOLS": "#64748b",
        "TESTS": "#94a3b8",
    }

    node_list: list[dict[str, Any]] = []
    for n in nodes:
        domain = n.domain or "CORE"
        node_list.append({
            "id": n.id,
            "label": n.name,
            "kind": n.kind,
            "domain": domain,
            "tier": str(n.tier.value),
            "tier_label": EDITOR_TIER_LABELS.get(
                _tier_level(n.tier), "unknown"
            ),
            "status": (
                "implemented" if n.status.implemented else "declared"
            ),
            "color": domain_colors.get(domain, "#94a3b8"),
            "size_hint": max(6, 24 - (_tier_level(n.tier) * 4)),
            "path": n.path or None,
        })

    edge_list = [
        {
            "source": e.from_id,
            "target": e.to_id,
            "relation": e.relation,
            "directed": True,
        }
        for e in edges
    ]

    return {
        "nodes": node_list,
        "edges": edge_list,
        "node_count": len(node_list),
        "edge_count": len(edge_list),
        "domain_colors": domain_colors,
        "schema_version": "editor/v1",
    }
