"""Health vector projection from registry graph."""

from __future__ import annotations

from typing import Any

from forge.core.schemas import ForgeHealthVectorOutput
from forge.engine.registry import EntityRegistry
from forge.metrics.adi import compute_adi
from forge.metrics.brc import compute_brc
from forge.metrics.idr import IDR_THRESHOLD_DAYS, compute_idr
from forge.metrics.pos import compute_pos
from forge.tools.audit.annotations import (
    annotation_rollups_from_index,
    annotations_index_yaml_path,
    load_annotation_index_entries,
)
from forge.tools.intent.runtime import load_intent_records


def to_health_vector(registry: EntityRegistry) -> ForgeHealthVectorOutput:
    g = registry.graph
    root = registry._project_path or getattr(g, "project_path", None)
    if root is None:
        raise RuntimeError("registry missing project_path — call load() first")
    idx_path = annotations_index_yaml_path(root)
    index_file_present = idx_path.is_file()
    ann_index = load_annotation_index_entries(root, rebuild_if_missing=False)
    adi = compute_adi(root, graph=g)
    brc = compute_brc(graph=g)
    intent_recs = load_intent_records(root)
    idr = compute_idr(graph=g, annotations=ann_index, intent_records=intent_recs)
    roll = annotation_rollups_from_index(ann_index)
    idr_snap = idr.to_dict()
    idr_rationale: dict[str, Any] = {
        **roll,
        "annotation_index_file_present": index_file_present,
        "coverage_model": (
            "annotation_affects_or_intent_target_id_per_manifest_node"
        ),
        "threshold_days": IDR_THRESHOLD_DAYS,
        "idr_healthy": idr_snap.get("healthy"),
        "idr_decay_rate": idr_snap.get("decay_rate"),
        "nodes_with_intent": idr_snap.get("nodes_with_intent"),
        "nodes_without_intent_count": idr_snap.get("nodes_without_intent_count"),
        "nodes_uncovered_preview": idr_snap.get("nodes_without_intent"),
        "intent_corpus_undefined": idr_snap.get("intent_corpus_undefined"),
        "intent_alignment_score": idr_snap.get("intent_alignment_score"),
    }
    pos = compute_pos(graph=g)
    sync_health = "unknown"
    infra_health = "unknown"
    # Composite gate: only **measured** ADI/BRC/IDR/POS signals count.
    # sync_health / infra_health remain "unknown" → must not imply unhealthy.
    pos_ok = pos.obsolete_count == 0
    measured_healthy = (
        registry.node_count > 0
        and adi.healthy
        and brc.healthy
        and idr.healthy
        and pos_ok
    )
    return ForgeHealthVectorOutput(
        graph_health="healthy" if registry.node_count > 0 else "empty",
        sync_health=sync_health,
        infra_health=infra_health,
        adi_score=float(adi.score),
        brc_score=float(brc.score),
        idr_score=float(idr.score),
        healthy=measured_healthy,
        idr_rationale=idr_rationale,
    )
