"""ForgeEngine — single entry point for declaration graph operations."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from forge.core.path_utils import resolve_project_path
from forge.core.schemas import ForgeGraphQueryPayload, ForgeHealthVectorOutput
from forge.engine.entity.schemas import EdgeModel, NodeModel
from forge.engine.history import get_entity_history_store
from forge.engine.hooks import HookBus
from forge.engine.projections.health import to_health_vector
from forge.engine.projections.tree import to_tree
from forge.engine.registry import EntityRegistry
from forge.engine.resolver import ImpactRadiusResult, RelationshipResolver
from forge.tools.context.builder import build_bundle
from forge.tools.context.schema import ContextBundle


class ForgeEngine:
    """Assembles registry, resolver, hooks, and projections for MCP/CLI callers."""

    def __init__(self, project_path: Path | str) -> None:
        self._path = resolve_project_path(str(project_path))
        self.registry = EntityRegistry()
        self.resolver = RelationshipResolver(self.registry)
        self.hooks = HookBus(self._path)
        self._loaded = False

    def load(self) -> int:
        """Load or build graph; emit graph_built. Returns node count."""
        get_entity_history_store(self._path).load()
        count = self.registry.load(self._path)
        self.hooks.emit_graph_built(count)
        self._loaded = True
        return count

    def reload(self) -> int:
        """Force rebuild via registry load (cache bypass delegated to graph builder)."""
        self._loaded = False
        return self.load()

    def save(self) -> Path:
        return self.registry.save()

    def query(self, **filters: Any) -> ForgeGraphQueryPayload:
        self._ensure_loaded()
        return self.resolver.query(**filters)

    def blast_radius(self, node_id: str) -> dict[str, Any]:
        self._ensure_loaded()
        return self.resolver.blast_radius(node_id)

    def impact_radius(self, node_id: str) -> ImpactRadiusResult:
        """Unified impact analysis: blast + doc propagation + tier violations."""
        self._ensure_loaded()
        return self.resolver.impact_radius(node_id)

    def health_vector(self) -> ForgeHealthVectorOutput:
        self._ensure_loaded()
        return to_health_vector(self.registry)

    def tree_view(self) -> dict[str, Any]:
        self._ensure_loaded()
        # to_tree ignores edges; avoid get_edges() so unknown manifest relations cannot break tree MCP.
        return to_tree(self.registry.get_all())

    def orient(self, node: str | None = None) -> ContextBundle:
        _ = node
        self._ensure_loaded()
        return build_bundle(self._path, graph=self.registry.graph)

    def triangulate(self, node_id: str) -> list[dict[str, Any]]:
        self._ensure_loaded()
        return self.resolver.triangulate(node_id)

    def node(self, node_id: str) -> NodeModel | None:
        self._ensure_loaded()
        return self.registry.get_node(node_id)

    def nodes(self, **filters: Any) -> list[NodeModel]:
        self._ensure_loaded()
        return self.registry.get_all(**filters)

    def edges(self, **filters: Any) -> list[EdgeModel]:
        self._ensure_loaded()
        return self.registry.get_edges(**filters)

    def _ensure_loaded(self) -> None:
        if not self._loaded:
            self.load()

    def __enter__(self) -> ForgeEngine:
        self.load()
        return self

    def __exit__(self, *_args: object) -> None:
        return None
