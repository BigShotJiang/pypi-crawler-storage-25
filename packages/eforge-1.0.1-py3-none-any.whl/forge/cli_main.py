from __future__ import annotations

import json
import sys
from typing import Any

import click

from forge.core.path_utils import resolve_project_path


# ── Interactive Query Function ───────────────────────────────────────────────────

def _run_interactive_query(project_path_str: str) -> None:
    """Run interactive query builder."""
    FIELD_DESCRIPTIONS = {
        "kind": "Node kind (module, domain, command, feature, test, glove, doc, error_codes)",
        "domain": "Domain filter (CORE, COMMANDS, TOOLS, CHECKERS, etc.)",
        "name": "Name substring filter - matches partial names",
        "depends_on": "Filter nodes that depend on a specific node",
        "tier": "NodeTier filter (schema, worker, glove, gate)",
        "via": "Via relation echo (imports, belongs_to, calls_service, etc.)",
        "limit": "Maximum number of results to return (default: 50)",
        "depth": "Graph traversal depth (default: 1)",
        "direction": "Edge direction (in, out, both)",
        "sort_by": "Sort results (name, domain, criticality)",
        "expand_relevant": "Include semantic neighbors in results",
        "expand_domain": "Expand within specific domain only",
        "expand_max_total": "Maximum nodes when expanding (default: 30)",
    }
    
    QUERY_EXAMPLES = [
        {"name": "Find all CORE modules", "query": {"kind": "module", "domain": "CORE"}},
        {"name": "Find commands that use shared_options", "query": {"kind": "command", "depends_on": "shared_options"}},
        {"name": "Find high-criticality modules", "query": {"kind": "module", "sort_by": "criticality"}},
        {"name": "Explore CORE domain with dependencies", "query": {"domain": "CORE", "depth": 2, "expand_relevant": True}},
    ]
    
    def _display_field_menu() -> dict[str, Any]:
        click.echo("\n🔍 FORGE INTERACTIVE QUERY BUILDER")
        click.echo("=" * 50)
        click.echo("Available fields (select by number, multiple with space):")
        click.echo()
        
        field_list = list(FIELD_DESCRIPTIONS.items())
        for i, (field, description) in enumerate(field_list, 1):
            click.echo(f"  {i:2d}. {field:<15} - {description}")
        
        click.echo()
        click.echo("Examples:")
        for i, example in enumerate(QUERY_EXAMPLES, 1):
            click.echo(f"  e{i}. {example['name']}")
        
        click.echo()
        click.echo("Commands:")
        click.echo("  h. Help")
        click.echo("  q. Quit")
        click.echo("  r. Run with current selection")
        click.echo()
        return {}
    
    def _get_field_selection() -> dict[str, Any]:
        selection = {}
        
        while True:
            try:
                user_input = click.prompt("Select fields (e.g., 1 3 5 or e2)", type=str).strip()
                
                if user_input.lower() == 'q':
                    click.echo("👋 Quitting query builder")
                    sys.exit(0)
                
                if user_input.lower() == 'h':
                    click.echo("\n📖 QUERY BUILDER HELP")
                    click.echo("=" * 30)
                    click.echo("Field Selection:")
                    click.echo("  - Enter numbers separated by spaces")
                    click.echo("  - Use 'e1', 'e2', etc. for examples")
                    click.echo("  - Use 'r' to run query")
                    click.echo("  - Use 'q' to quit")
                    click.echo()
                    continue
                
                if user_input.lower() == 'r':
                    if selection:
                        return selection
                    click.echo("⚠️  No fields selected yet")
                    continue
                
                # Handle example selection
                if user_input.lower().startswith('e'):
                    try:
                        example_idx = int(user_input[1:]) - 1
                        if 0 <= example_idx < len(QUERY_EXAMPLES):
                            return QUERY_EXAMPLES[example_idx]["query"]
                        else:
                            click.echo("⚠️  Invalid example number")
                            continue
                    except ValueError:
                        click.echo("⚠️  Invalid example format")
                        continue
                
                # Handle field selection
                field_numbers = user_input.split()
                field_list = list(FIELD_DESCRIPTIONS.keys())
                
                for num_str in field_numbers:
                    try:
                        idx = int(num_str) - 1
                        if 0 <= idx < len(field_list):
                            field = field_list[idx]
                            if field == "direction":
                                selection[field] = click.prompt(f"Value for {field}", type=click.Choice(["in", "out", "both"]), default="both")
                            elif field == "tier":
                                selection[field] = click.prompt(f"Value for {field}", type=click.Choice(["schema", "worker", "glove", "gate"]), default=None)
                            elif field in ["limit", "depth", "expand_max_total"]:
                                default = 50 if field == "limit" else (1 if field == "depth" else 30)
                                selection[field] = click.prompt(f"Value for {field}", type=int, default=default)
                            elif field == "expand_relevant":
                                selection[field] = click.confirm(f"Enable {field}?", default=False)
                            else:
                                selection[field] = click.prompt(f"Value for {field}", type=str, default="")
                        else:
                            click.echo(f"⚠️  Invalid field number: {num_str}")
                    except ValueError:
                        click.echo(f"⚠️  Invalid number: {num_str}")
                
                if selection:
                    return selection
                
            except (KeyboardInterrupt, EOFError):
                click.echo("\n👋 Quitting query builder")
                sys.exit(0)
    
    def _display_query_preview(query: dict[str, Any]) -> None:
        click.echo("\n📋 QUERY PREVIEW")
        click.echo("=" * 20)
        
        for field, value in query.items():
            if value:  # Only show non-empty values
                click.echo(f"  {field}: {value}")
        
        click.echo()
    
    # Run interactive flow
    _display_field_menu()
    query = _get_field_selection()
    _display_query_preview(query)
    
    # Execute query
    click.echo("🚀 EXECUTING QUERY...")
    click.echo()
    
    try:
        from forge.mcp.thin_core import run_query_payload
        
        root = resolve_project_path(project_path_str)
        
        payload = run_query_payload(
            {
                "project_path": str(root),
                "domain": query.get("domain", ""),
                "name": query.get("name", ""),
                "depends_on": query.get("depends_on", ""),
                "kind": query.get("kind", ""),
                "tier": query.get("tier"),
                "via": query.get("via"),
                "limit": query.get("limit", 50),
                "depth": query.get("depth", 1),
                "direction": query.get("direction", "both"),
                "sort_by": query.get("sort_by", ""),
                "expand_relevant": query.get("expand_relevant", False),
                "expand_domain": query.get("expand_domain"),
                "expand_max_total": query.get("expand_max_total", 30),
            }
        )
        
        click.echo(json.dumps(payload, indent=2))
        
        # Show summary
        count = payload.get("count", 0)
        click.echo(f"\n✅ Found {count} results")
        
    except Exception as e:
        click.echo(f"❌ Error executing query: {e}", err=True)
        sys.exit(1)


# ── Deprecated-alias helper ───────────────────────────────────────────────────

class _DeprecatedAlias(click.BaseCommand):
    """Transparent deprecated alias — prints a warning then delegates to target."""

    def __init__(self, name: str, target: click.BaseCommand, warning: str) -> None:
        super().__init__(name=name)
        self._target = target
        self._warning = warning

    @property
    def hidden(self) -> bool:  # type: ignore[override]
        return True
    
    @hidden.setter
    def hidden(self, value: bool) -> None:  # type: ignore[override]
        pass  # Ignore attempts to set hidden property

    def get_short_help_str(self, limit: int = 150) -> str:
        return f"[deprecated] use: {self._target.name}"

    def make_context(  # type: ignore[override]
        self,
        info_name: str,
        args: list[str],
        **extra: object,
    ) -> click.Context:
        click.echo(self._warning, err=True)
        return self._target.make_context(info_name, args, **extra)

    def invoke(self, ctx: click.Context) -> object:
        return self._target.invoke(ctx)


# ── blast-radius command (inline — no new file) ───────────────────────────────

@click.command(name="blast-radius")
@click.option("--node", "node_name", default=None, metavar="NAME",
              help="Manifest node name (e.g. core.manifest).")
@click.option("--file", "file_path", default=None, metavar="PATH",
              help="Repo-relative file path — resolved to manifest node.")
@click.option("--project-path", "project_path_str", default=".", metavar="PATH",
              help="Project root (default: cwd).")
def _blast_radius_cmd(
    node_name: str | None,
    file_path: str | None,
    project_path_str: str,
) -> None:
    """Show Ring-2 blast radius for a manifest node. Diagnostic only — exits 0.

    Quick ring-2 lookup by node name or file path. See also: forge impact (full analysis).
    """
    from forge.core.query import forge_query
    from forge.tools.manifest.graph import build_manifest_graph, find_node_id_for_path

    project_path = resolve_project_path(project_path_str)
    graph = build_manifest_graph(project_path)

    node_id: str | None = None
    if node_name:
        for n in graph.nodes:
            if n.name == node_name or n.id == node_name:
                node_id = n.id
                break
        if not node_id:
            click.echo(f"node '{node_name}' not found in manifest graph", err=True)
            return
    elif file_path:
        node_id = find_node_id_for_path(graph, file_path)
        if not node_id:
            click.echo(f"no manifest node for path '{file_path}'", err=True)
            return
    else:
        click.echo("provide --node <name> or --file <path>", err=True)
        return

    qr = forge_query(graph, reverse_of=node_id, where={"change_kind": "any"})
    br = qr.data

    click.echo(f"blast radius: {node_id}\n")

    sections = [
        ("dependents",     br["dependents"]),
        ("watchers",       br["watchers"]),
        ("siblings",       br["siblings"]),
        ("domain_members", br["domain_members"]),
    ]
    any_found = False
    for label, nodes in sections:
        if nodes:
            any_found = True
            click.echo(f"{label} ({len(nodes)}):")
            for n in nodes:
                nid = n["id"]
                reason_str = br["reason"].get(nid, "")
                suffix = f"  # {reason_str}" if reason_str else ""
                click.echo(f"  {nid}{suffix}")

    if not any_found:
        click.echo("no ring-2 dependents found")


@click.command(name="impact")
@click.argument("node_id")
@click.option("--project-path", "project_path_str", default=".", metavar="PATH",
              help="Project root (default: cwd).")
@click.option(
    "--slice",
    default="full",
    type=click.Choice(["full", "blast", "docs", "contracts"]),
    show_default=True,
    help="Impact slice (full = blast + docs + contracts).",
)
def _impact_cmd(
    node_id: str,
    project_path_str: str,
    slice: str,
) -> None:
    """Unified impact radius for a manifest node (ForgeEngine impact_radius).

    Full analysis by node_id. See also: forge blast-radius (quick ring-2 diagnostic).
    """
    import json

    from forge.mcp.thin_core import execute_impact_radius_unified

    project_path = resolve_project_path(project_path_str)
    payload = execute_impact_radius_unified({
        "project_path": str(project_path),
        "node_id": node_id,
        "slice": slice,
    })
    click.echo(json.dumps(payload, indent=2))


@click.command("query")
@click.option("--project-path", "project_path_str", default=".", show_default=True, help="Project root.")
@click.option("--domain", default="", help="Domain filter (e.g. CORE).")
@click.option("--name", default="", help="Name substring filter.")
@click.option("--depends-on", "depends_on", default="", help="depends_on filter.")
@click.option("--kind", default="", help="Node kind filter.")
@click.option("--tier", default=None, help="NodeTier filter (e.g. schema, worker).")
@click.option("--via", default=None, help="Via relation echo (imports|…).")
@click.option("--limit", default=50, type=int, show_default=True)
@click.option("--depth", default=1, type=int, show_default=True)
@click.option(
    "--direction",
    default="both",
    type=click.Choice(["in", "out", "both"]),
    show_default=True,
)
@click.option("--sort-by", "sort_by", default=None)
@click.option("--expand-relevant", "expand_relevant", is_flag=True, default=False)
@click.option("--expand-domain", "expand_domain", default=None)
@click.option("--expand-max-total", "expand_max_total", default=30, type=int)
@click.option(
    "--response-tier",
    "response_tier",
    default="L1",
    type=click.Choice(["L0", "L1", "L2"]),
    help="Session echo only (matches MCP forge_query); does not change graph results.",
)
@click.option("--interactive", "interactive", is_flag=True, default=False, help="Interactive query builder with field selection.")
def forge_query_cli(
    project_path_str: str,
    domain: str,
    name: str,
    depends_on: str,
    kind: str,
    tier: str | None,
    via: str | None,
    limit: int,
    depth: int,
    direction: str,
    sort_by: str | None,
    expand_relevant: bool,
    expand_domain: str | None,
    expand_max_total: int,
    response_tier: str,
    interactive: bool,
) -> None:
    """Run manifest graph query (same primitive as MCP ``forge_query``).
    
    Query the manifest graph for nodes and edges with powerful filtering options.
    This command provides direct access to the same query primitive used by MCP.
    
    Examples:
      forge query --kind=module --domain=CORE                    # All CORE modules
      forge query --kind=command --depends_on=shared_options    # Commands using shared_options
      forge query --name=manifest --limit=10                    # Search for 'manifest' in names
      forge query --domain=COMMANDS --depth=2                   # COMMANDS domain with dependencies
      forge query --sort-by=criticality --limit=20              # Most critical nodes first
      forge query --interactive                               # Interactive query builder
    
    Advanced Options:
      --expand-relevant    Include semantic neighbors (use for discovery)
      --expand-domain      Expand within specific domain only
      --expand-max-total   Limit expansion size (default: 30)
      --interactive        Interactive query builder with field selection
    """
    import json

    from forge.mcp.thin_core import run_query_payload

    # Handle interactive mode
    if interactive:
        return _run_interactive_query(project_path_str)
    
    _ = response_tier
    root = resolve_project_path(project_path_str)
    payload = run_query_payload(
        {
            "project_path": str(root),
            "domain": domain,
            "name": name,
            "depends_on": depends_on,
            "kind": kind,
            "tier": tier,
            "via": via,
            "limit": limit,
            "depth": depth,
            "direction": direction,
            "sort_by": sort_by or "",
            "expand_relevant": expand_relevant,
            "expand_domain": expand_domain,
            "expand_max_total": expand_max_total,
        }
    )
    click.echo(json.dumps(payload, indent=2))


# ── Trigger type and checker registration before any command runs ─────────────

import forge.types  # noqa: F401
import forge.checkers  # noqa: F401

from forge.commands.list import list_cmd
from forge.commands.inspect_cmd import inspect_cmd
from forge.commands.project_cmd import project_cmd
from forge.commands.manifest_cmd import manifest_cmd
from forge.commands.new import new_cmd
from forge.commands.init_cmd import init_cmd
from forge.commands.doctor import doctor_cmd
from forge.commands.board import board_cmd
from forge.commands.config_cmd import config_group
from forge.commands.context_cmd import context_group
from forge.commands.system import system
from forge.commands.scan_cmd import scan_cmd
from forge.tools.docs_audit.cli import docs_audit_cmd
from forge.tools.init_docs.cli import init_docs_cmd
from forge.commands.toc_cmd import toc_cmd
from forge.commands.workspace_cmd import projects_group, workspace_cmd
from forge.commands.scaffold import scaffold_group
from forge.commands.registry_cmd import registry_cmd
from forge.tools.scaffold.cli import composer_group, workshop_group
from forge.commands.audit_cmd import audit_group, audit_annotate_group
from forge.commands.mcp_cmd import mcp_cmd
from forge.commands.github_write_cmd import github_write_cmd
from forge.commands.project_status_cmd import project_status_cmd
from forge.commands.map_cmd import map_cmd
from forge.commands.diff_cmd import diff_cmd
from forge.commands.trace_cmd import trace_cmd
from forge.commands.report_cmd import report_cmd
from forge.commands.intent_cmd import intent_group
from forge.commands.template_cmd import template_cmd
from forge.commands.packet_cmd import packet_group
from forge.commands.orient_cmd import orient_cmd
from forge.commands.discover_cmd import discover_cmd
from forge.commands.sync_cmd import register_sync_commands
from forge.commands.reality_cmd import register_reality_command
from forge.cli_groups import OrderedGroup


@click.command()
@click.option("--project-path", default=".", show_default=True)
@click.option("--name", default=None)
@click.option("--intent", default=None)
@click.option("--stack", default=None)
def start_cmd(project_path, name, intent, stack):
    """Initialize a new Forge project."""
    from forge.commands.start_cmd import run_start
    result = run_start(project_path, name, intent, stack)
    click.echo(f"✓ Project initialized at stage {result['stage']}.")
    click.echo(f"  Next: {result['next_required']}")


@click.group(cls=OrderedGroup)
def main() -> None:
    """
    ✦ eforge — project architecture compiler

    Compile, track, and enforce the
    architecture of any codebase.

    New? Start here:
      forge init     initialize a project
      forge orient   understand your project
      forge verify   check structural health
      forge doctor   check forge setup

    Run forge <command> --help for details.
    """


main.add_command(list_cmd, name="list")
main.add_command(inspect_cmd, name="inspect")
main.add_command(project_cmd, name="project")
main.add_command(manifest_cmd, name="manifest")
main.add_command(new_cmd, name="new")
main.add_command(init_cmd, name="init")
main.add_command(doctor_cmd, name="doctor")
main.add_command(board_cmd, name="board")
main.add_command(config_group, name="config")
main.add_command(context_group, name="context")
main.add_command(intent_group, name="intent")
main.add_command(projects_group, name="projects")
main.add_command(map_cmd, name="map")
main.add_command(diff_cmd, name="diff")
main.add_command(trace_cmd, name="trace")
main.add_command(report_cmd, name="report")
main.add_command(start_cmd, name="start")
main.add_command(template_cmd, name="template")
main.add_command(packet_group, name="packet")
main.add_command(orient_cmd, name="orient")
main.add_command(discover_cmd, name="discover")

main.add_command(workspace_cmd, name="workspace")
workspace_cmd.hidden = True
main.add_command(scan_cmd, name="scan")
from forge.cli.verify import verify_cmd as _verify_cmd
main.add_command(_verify_cmd, name="verify")
main.add_command(docs_audit_cmd, name="impact-check")
main.add_command(init_docs_cmd, name="init-docs")
main.add_command(toc_cmd, name="toc")
main.add_command(scaffold_group, name="scaffold")
main.add_command(registry_cmd, name="registry")
main.add_command(workshop_group, name="workshop")
main.add_command(composer_group, name="composer")
main.add_command(audit_group, name="audit")
main.add_command(audit_annotate_group, name="annotate")
main.add_command(mcp_cmd, name="mcp")
main.add_command(github_write_cmd, name="github-write")
main.add_command(project_status_cmd, name="project-status")
main.add_command(project_status_cmd, name="status")
main.add_command(_blast_radius_cmd, name="blast-radius")
main.add_command(_impact_cmd, name="impact")
main.add_command(forge_query_cli, name="query")
main.add_command(system, name="system")

# Export command group
@click.group()
def export():
    """Export project data in various formats."""
    pass

@export.command(name="public")
@click.option("--project-path", default=".", show_default=True)
@click.option("--output", default=None,
              help="Output file path (default: stdout)")
def export_public_cmd(project_path, output):
    """Generate public JSON snapshot for static site."""
    from forge.commands.export_cmd import export_public
    import json
    result = export_public(project_path, output)
    if not output:
        click.echo(json.dumps(result, indent=2))
    else:
        click.echo(f"✓ Exported to {output}")

@export.command(name="badge")
@click.option("--project-path", default=".", show_default=True)
@click.option("--output", default=None,
              help="Output SVG path")
def export_badge_cmd(project_path, output):
    """Generate SVG health score badge for README."""
    from forge.commands.export_cmd import export_badge
    svg = export_badge(project_path, output)
    if not output:
        click.echo(svg)
    else:
        click.echo(f"✓ Badge written to {output}")

@export.command(name="graph")
@click.option("--project-path", default=".", show_default=True)
@click.option("--output", default=None, help="Output file path (default: stdout)")
def export_graph_cmd(project_path, output):
    """Generate full graph JSON with nodes and edges for interactive visualization."""
    from forge.commands.export_cmd import export_graph
    result = export_graph(project_path, output)
    if not output:
        import json
        click.echo(json.dumps(result, indent=2))

main.add_command(export, name="export")



# Register sync commands
register_sync_commands(main)

# Register reality command
register_reality_command(main)



if __name__ == "__main__":
    main()
