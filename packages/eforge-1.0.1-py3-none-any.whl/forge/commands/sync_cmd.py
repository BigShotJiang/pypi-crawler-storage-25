"""Forge sync command - Auto-update manifest from file system.

Addresses critical gap where Forge graph becomes stale when files are
added/deleted/moved without manual manifest updates.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text

from forge.core.discovery import discover_projects
from forge.core.manifest import ManifestParser
from forge.core.path_utils import resolve_project_path
from forge.commands._shared_options import project_path_option, response_tier_option

logger = logging.getLogger(__name__)
console = Console()


@dataclass(frozen=True)
class SyncResult:
    """Result of manifest synchronization operation."""
    added: List[str]
    removed: List[str]
    updated: List[str]
    errors: List[str]
    total_changes: int
    
    @property
    def has_changes(self) -> bool:
        return bool(self.added or self.removed or self.updated)
    
    @property
    def has_errors(self) -> bool:
        return bool(self.errors)


class ManifestSynchronizer:
    """Synchronizes manifest with actual file system state."""
    
    def __init__(self, project_path: Path):
        self.project_path = project_path
        self.manifest_path = project_path / ".forge" / "manifest.yaml"
        self.parser = ManifestParser(self.manifest_path)
        
    def scan_filesystem(self) -> Dict[str, Any]:
        """Scan actual file system for modules."""
        # Use a simple filesystem scan since discover_projects is for projects, not modules
        modules = {}
        
        # Directories to exclude from sync
        EXCLUDE_DIRS = {
            "node_modules", ".git", ".venv", "venv", "env", "__pycache__",
            ".pytest_cache", ".mypy_cache", ".tox", "build", "dist",
            ".forge", ".secrets", ".DS_Store", "site-packages"
        }
        
        for py_file in self.project_path.rglob("*.py"):
            if not py_file.is_file():
                continue
                
            # Skip files in excluded directories
            relative_path = py_file.relative_to(self.project_path)
            path_parts = str(relative_path).split("/")
            if any(part in EXCLUDE_DIRS for part in path_parts):
                continue
                
            # Skip test files (optional - can be configured)
            if any(part.startswith("test_") or part == "tests" for part in path_parts):
                continue
                
            module_id = str(relative_path.with_suffix("")).replace("/", ".")
            modules[module_id] = {
                "path": str(relative_path),
                "kind": "module"
            }
        return modules
    
    def load_manifest_nodes(self) -> Dict[str, Dict[str, Any]]:
        """Load current manifest nodes."""
        try:
            result = self.parser.parse()
            if not result.ok:
                logger.error(f"Failed to parse manifest: {result.error}")
                return {}
            manifest = result.value
            return {node.get("id", ""): node for node in manifest.get("modules", [])}
        except Exception as e:
            logger.error(f"Failed to load manifest: {e}")
            return {}
    
    def infer_domain_from_path(self, file_path: Path) -> str:
        """Infer domain from file path structure."""
        path_parts = file_path.relative_to(self.project_path).parts
        
        # Domain inference rules
        if "commands" in path_parts:
            return "COMMANDS"
        elif "core" in path_parts:
            return "CORE"
        elif "tools" in path_parts:
            return "TOOLS"
        elif "mcp" in path_parts:
            return "MCP"
        elif "renderers" in path_parts:
            return "RENDERERS"
        elif "checkers" in path_parts:
            return "CHECKERS"
        elif "types" in path_parts:
            return "TYPES"
        else:
            return "UNKNOWN"
    
    def infer_tier_from_path(self, file_path: Path) -> str:
        """Infer tier from file path structure."""
        path_parts = file_path.relative_to(self.project_path).parts
        
        # Tier inference rules
        if "mcp" in path_parts and ("server.py" in str(file_path) or "handlers.py" in str(file_path)):
            return "surface"
        elif "core" in path_parts and ("gloves" in str(file_path) or "registry" in str(file_path)):
            if "gloves" in str(file_path):
                return "glove"
            elif "registry" in str(file_path):
                return "registry"
        elif "core" in path_parts and ("schemas" in str(file_path) or "contracts" in str(file_path)):
            return "schema"
        else:
            return "worker"
    
    def create_node_from_file(self, file_path: Path, module_id: str) -> Dict[str, Any]:
        """Create manifest node from file system discovery."""
        relative_path = file_path.relative_to(self.project_path)
        
        return {
            "id": module_id,
            "kind": "module",
            "domain": self.infer_domain_from_path(file_path),
            "path": str(relative_path),
            "tier": self.infer_tier_from_path(file_path),
            "depends_on": [],
            "consumed_by": [],
            "meta": {}
        }
    
    def detect_discrepancies(self) -> tuple[Dict[str, Any], Dict[str, Dict[str, Any]]]:
        """Detect differences between file system and manifest."""
        fs_modules = self.scan_filesystem()
        manifest_nodes = self.load_manifest_nodes()
        
        # Find files that exist but aren't in manifest
        missing_from_manifest = {}
        for module_id, module_info in fs_modules.items():
            if module_id not in manifest_nodes:
                missing_from_manifest[module_id] = module_info
        
        # Find manifest entries that don't exist in file system
        orphaned_manifest = {}
        for node_id, node in manifest_nodes.items():
            node_path = self.project_path / node.get("path", "")
            if not node_path.exists():
                orphaned_manifest[node_id] = node
        
        return missing_from_manifest, orphaned_manifest
    
    def sync_manifest(self, dry_run: bool = False) -> SyncResult:
        """Synchronize manifest with file system."""
        missing_from_manifest, orphaned_manifest = self.detect_discrepancies()
        
        added = []
        removed = []
        updated = []
        errors = []
        
        if not missing_from_manifest and not orphaned_manifest:
            return SyncResult([], [], [], [], 0)
        
        # Load current manifest for modification
        try:
            result = self.parser.parse()
            if not result.ok:
                errors.append(f"Failed to parse manifest: {result.error}")
                return SyncResult([], [], [], errors, 0)
            manifest = result.value
        except Exception as e:
            errors.append(f"Failed to load manifest: {e}")
            return SyncResult([], [], [], errors, 0)
        
        # Add missing modules
        for module_id, module_info in missing_from_manifest.items():
            try:
                file_path = self.project_path / module_info['path']
                new_node = self.create_node_from_file(file_path, module_id)
                
                if not dry_run:
                    if "modules" not in manifest:
                        manifest["modules"] = []
                    manifest["modules"].append(new_node)
                added.append(module_id)
                logger.info(f"{'[DRY RUN] ' if dry_run else ''}Added module: {module_id}")
                
            except Exception as e:
                errors.append(f"Failed to add {module_id}: {e}")
        
        # Remove orphaned modules
        for node_id, node in orphaned_manifest.items():
            try:
                if not dry_run:
                    if "modules" in manifest:
                        manifest["modules"] = [m for m in manifest["modules"] if m.get("id") != node_id]
                removed.append(node_id)
                logger.info(f"{'[DRY RUN] ' if dry_run else ''}Removed module: {node_id}")
                
            except Exception as e:
                errors.append(f"Failed to remove {node_id}: {e}")
        
        # Save manifest if changes made
        if not dry_run and (added or removed):
            try:
                import yaml
                with open(self.manifest_path, 'w') as f:
                    yaml.dump(manifest, f, default_flow_style=False, sort_keys=False)
                logger.info(f"Manifest updated: {len(added)} added, {len(removed)} removed")
            except Exception as e:
                errors.append(f"Failed to save manifest: {e}")
        
        total_changes = len(added) + len(removed) + len(updated)
        return SyncResult(added, removed, updated, errors, total_changes)


@click.command()
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be changed without making modifications"
)
@click.option(
    "--verbose", "-v",
    is_flag=True,
    help="Show detailed output"
)
@click.option(
    "--force",
    is_flag=True,
    help="Force sync even if no discrepancies detected"
)
@project_path_option(required=False)
@response_tier_option()
def sync(
    dry_run: bool,
    verbose: bool,
    force: bool,
    project_path: Optional[str],
    response_tier: Optional[str]
) -> None:
    """Synchronize manifest with actual file system state.
    
    Automatically detects and fixes discrepancies between the manifest
    and the actual file system, eliminating the need for manual updates
    when files are added, deleted, or moved.
    
    Examples:
        forge sync                    # Sync with file system
        forge sync --dry-run          # Preview changes
        forge sync --verbose          # Detailed output
        forge sync --force            # Force sync operation
    """
    project_path = Path(resolve_project_path(project_path or "."))
    
    if not project_path.exists():
        console.print(f"[red]Error: Project path does not exist: {project_path}[/red]")
        return
    
    # Initialize synchronizer
    synchronizer = ManifestSynchronizer(project_path)
    
    console.print(Panel(
        f"[bold blue]Forge Sync[/bold blue]\n"
        f"Project: {project_path.name}\n"
        f"Mode: {'[yellow]DRY RUN[/yellow]' if dry_run else '[green]LIVE[/green]'}",
        title="Manifest Synchronization"
    ))
    
    # Perform synchronization
    result = synchronizer.sync_manifest(dry_run=dry_run)
    
    # Display results
    if not result.has_changes and not force:
        console.print("[green]Manifest is already synchronized with file system[/green]")
        return
    
    # Create results table
    table = Table(title="Synchronization Results")
    table.add_column("Action", style="bold")
    table.add_column("Count", justify="right")
    table.add_column("Items", style="dim")
    
    if result.added:
        table.add_row("[green]Added[/green]", str(len(result.added)), ", ".join(result.added[:3]) + ("..." if len(result.added) > 3 else ""))
    
    if result.removed:
        table.add_row("[red]Removed[/red]", str(len(result.removed)), ", ".join(result.removed[:3]) + ("..." if len(result.removed) > 3 else ""))
    
    if result.updated:
        table.add_row("[yellow]Updated[/yellow]", str(len(result.updated)), ", ".join(result.updated[:3]) + ("..." if len(result.updated) > 3 else ""))
    
    if result.errors:
        table.add_row("[red]Errors[/red]", str(len(result.errors)), ", ".join(result.errors[:2]) + ("..." if len(result.errors) > 2 else ""))
    
    console.print(table)
    
    # Summary
    if result.has_changes:
        mode_text = "would be" if dry_run else "were"
        console.print(f"\n[bold]{result.total_changes} changes {mode_text} made[/bold]")
        
        if not dry_run:
            console.print("[green]Manifest successfully synchronized![/green]")
            console.print(f"[dim]Run 'forge verify' to validate the updated manifest[/dim]")
    else:
        console.print("[yellow]No changes needed[/yellow]")
    
    # Verbose details
    if verbose and result.has_changes:
        console.print("\n[bold]Detailed Changes:[/bold]")
        
        if result.added:
            console.print("\n[green]Added Modules:[/green]")
            for module_id in result.added:
                console.print(f"  + {module_id}")
        
        if result.removed:
            console.print("\n[red]Removed Modules:[/red]")
            for module_id in result.removed:
                console.print(f"  - {module_id}")
        
        if result.errors:
            console.print("\n[red]Errors:[/red]")
            for error in result.errors:
                console.print(f"  ! {error}")


@click.command()
@click.option(
    "--report-only",
    is_flag=True,
    help="Only report discrepancies, don't fix them"
)
@click.option(
    "--auto-fix",
    is_flag=True,
    help="Automatically fix common issues"
)
@project_path_option(required=False)
@response_tier_option()
def clean(
    report_only: bool,
    auto_fix: bool,
    project_path: Optional[str],
    response_tier: Optional[str]
) -> None:
    """Clean orphaned references from manifest.
    
    Remove dead references to files that no longer exist in the file system.
    This helps maintain a clean and accurate manifest.
    
    Examples:
        forge clean --report-only     # Report orphaned entries only
        forge clean --auto-fix         # Automatically remove orphaned entries
        forge clean                    # Interactive cleaning
    """
    project_path = Path(resolve_project_path(project_path or "."))
    synchronizer = ManifestSynchronizer(project_path)
    
    # Detect orphaned entries
    _, orphaned_manifest = synchronizer.detect_discrepancies()
    
    if not orphaned_manifest:
        console.print("[green]No orphaned entries found[/green]")
        return
    
    console.print(Panel(
        f"[bold red]Found {len(orphaned_manifest)} orphaned entries[/bold red]",
        title="Manifest Cleaning"
    ))
    
    # Display orphaned entries
    table = Table(title="Orphaned Entries")
    table.add_column("Module ID", style="bold")
    table.add_column("Path", style="dim")
    table.add_column("Domain", style="blue")
    
    for node_id, node in orphaned_manifest.items():
        table.add_row(node_id, node.path, node.domain)
    
    console.print(table)
    
    if report_only:
        console.print(f"\n[dim]Use 'forge clean --auto-fix' to remove these entries[/dim]")
        return
    
    if auto_fix:
        # Remove orphaned entries
        result = synchronizer.sync_manifest(dry_run=False)
        console.print(f"\n[green]Removed {len(result.removed)} orphaned entries[/green]")
    else:
        console.print("\n[dim]Use --auto-fix to remove these entries[/dim]")


# Register commands
def register_sync_commands(cli_group):
    """Register sync-related commands with CLI group."""
    cli_group.add_command(sync, name="sync")
    cli_group.add_command(clean, name="clean")
