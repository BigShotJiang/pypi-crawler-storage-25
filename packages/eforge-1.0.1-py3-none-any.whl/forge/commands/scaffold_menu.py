"""
forge scaffold interactive menu.

Reads node_schemas from manifest.yaml — never hardcodes field names.
Produces entries that are passed to the forge_scaffold validator.
Templates are saved/loaded via forge.core.registry — never inside project dirs.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import click
import yaml

from forge.core.registry import (
    list_templates,
    load_template,
    save_template,
    list_feature_templates,
    get_feature_template,
)
from forge.core.manifest_path import resolve_manifest_path
from forge.core.path_utils import resolve_project_path


# ── Manifest helpers ──────────────────────────────────────────────────────────

def _load_manifest_raw(root: Path) -> dict[str, Any]:
    p = resolve_manifest_path(root)
    if p is not None and p.is_file():
        try:
            raw = yaml.safe_load(p.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                return raw
        except Exception:
            pass
    return {}


def _load_node_schemas(root: Path) -> list[dict[str, Any]]:
    """Load node_schemas; delegates to canonical parser implementation."""
    from forge.tools.scaffold.parser import load_node_schemas as _parser_load
    return _parser_load(str(root))


def _detect_stack(root: Path) -> str | None:
    """Detect stack from workspace.yaml or manifest app block."""
    for name in ("workspace.yaml", ".workspace.yaml"):
        ws = root / name
        if ws.is_file():
            try:
                d = yaml.safe_load(ws.read_text(encoding="utf-8"))
                if isinstance(d, dict):
                    sv = str(d.get("stack") or "").strip().lower()
                    if "flutter" in sv:
                        return "flutter-app"
                    if "next" in sv:
                        return "web-next"
                    if "react" in sv:
                        return "web-react"
                    if "python" in sv:
                        return "python-cli"
            except Exception:
                pass
    raw = _load_manifest_raw(root)
    app_type = str((raw.get("app") or {}).get("type") or "").lower()
    if "flutter" in app_type:
        return "flutter-app"
    lang = str((raw.get("stack") or {}).get("language") or "").lower()
    if "python" in lang:
        return "python-cli"
    return None


def _get_domains(root: Path) -> list[str]:
    """Collect unique domains from existing manifest entries.

    Delegates manifest reading to the canonical parser implementation.
    Falls back to FORGE_DOMAINS when no project domains are registered.

    NOTE: the slot-filling questionnaire logic that calls this function is
    parallel to parse_describe() — intentionally NOT unified here.
    That convergence is ANNOT-024 (questionnaire work), not this session.
    """
    from forge.tools.scaffold.parser import collect_manifest_domains
    from forge.tools.scaffold.validation import FORGE_DOMAINS

    domains = collect_manifest_domains(str(root))
    if domains:
        return domains
    return sorted(FORGE_DOMAINS)


def _get_controllers_in_domain(root: Path, domain: str) -> list[str]:
    """Return controller names registered in a domain."""
    raw = _load_manifest_raw(root)
    return [
        str(item.get("name") or "").strip()
        for item in (raw.get("controllers") or [])
        if isinstance(item, dict)
        and str(item.get("domain") or "").strip().upper() == domain.upper()
        and item.get("name")
    ]


def _load_feature_templates(project_path: str, stack: str) -> list[dict[str, Any]]:
    """Load all feature templates for this stack from the feature registry.

    Feature templates define multi-node anatomies (e.g. auth-feature requires
    screen + controller + service).  They are distinct from single-node templates
    managed by save_template / load_template.

    Returns [] on any error — graceful degradation so scaffold_menu never breaks.

    Questionnaire wiring (slot-filling from feature templates) is ANNOT-024 —
    this function is the data-loading prerequisite only.
    """
    try:
        templates = list_feature_templates(stack=stack)
        # Only return templates with no validation errors
        return [t for t in templates if not t.get("_errors")]
    except Exception:
        return []


# ── Display helpers ───────────────────────────────────────────────────────────

def _prompt_numbered(
    label: str,
    choices: list[str],
    default_idx: int | None = None,
) -> str:
    """Show a numbered list and return the selected value."""
    click.echo(f"\n{label}")
    for i, c in enumerate(choices, 1):
        marker = " ←" if default_idx is not None and i - 1 == default_idx else ""
        click.echo(f"  {i}. {c}{marker}")
    default_str = str(default_idx + 1) if default_idx is not None else None
    while True:
        hint = f" [{default_str}]" if default_str else ""
        raw = click.prompt(f"  Select (1–{len(choices)}){hint}", default=default_str or "")
        raw = raw.strip()
        if not raw and default_idx is not None:
            return choices[default_idx]
        try:
            idx = int(raw) - 1
            if 0 <= idx < len(choices):
                return choices[idx]
        except ValueError:
            pass
        click.echo(f"  ✗ Enter a number between 1 and {len(choices)}")


def _interpolate(template: str, entry: dict[str, Any]) -> str:
    domain = str(entry.get("domain") or "")
    id_val = str(entry.get("id") or "")
    pascal = id_val.replace("_", " ").title().replace(" ", "")
    return (
        template
        .replace("{id}", id_val)
        .replace("{domain_lower}", domain.lower())
        .replace("{PascalId}", pascal)
        .replace("{package}", str(entry.get("package") or "app"))
    )


# ── Validation (mirrors handler logic — no import of running server) ──────────

def _validate_entry(
    entry: dict[str, Any],
    schema: dict[str, Any],
) -> dict[str, Any]:
    required_fields: list[str] = list(schema.get("required_fields") or [])
    boosters: dict[str, float] = dict(schema.get("confidence_boosters") or {})

    blockers = [
        f"Missing required field: {f}"
        for f in required_fields
        if entry.get(f) is None
    ]
    passed = len(required_fields) - len(blockers)

    if blockers:
        exit_code = 2
        confidence = max(0.0, 0.5 - 0.1 * len(blockers))
    else:
        base = 0.7
        for field, boost in boosters.items():
            if entry.get(field):
                base += boost
        exit_code = 0
        confidence = min(1.0, base)

    return {
        "exit_code": exit_code,
        "passed": passed,
        "warnings": [],
        "blockers": blockers,
        "confidence": confidence,
    }


# ── File generation ───────────────────────────────────────────────────────────

def _compute_files(entry: dict[str, Any], schema: dict[str, Any]) -> list[str]:
    files: list[str] = []
    if entry.get("file"):
        files.append(str(entry["file"]))
    domain_lower = str(entry.get("domain") or "").lower()
    for v in entry.get("variants") or []:
        files.append(f"lib/features/{domain_lower}/variants/{v}.dart")
    return files


def _generate_files(
    entry: dict[str, Any],
    files: list[str],
    root: Path,
    schema: dict[str, Any],
) -> None:
    stack = schema.get("stack")
    kind = schema.get("kind")
    id_val = str(entry.get("id") or entry.get("name") or "")
    pascal = id_val.replace("_", " ").title().replace(" ", "")
    title = id_val.replace("_", " ").title()
    controller = str((entry.get("watches") or [""])[0]) if entry.get("watches") else ""
    ctrl_file = controller.replace("Controller", "_controller").lower() if controller else ""

    if stack == "flutter-app" and kind == "screen":
        variants = entry.get("variants") or []
        screen_path = root / str(entry.get("file") or "")
        screen_path.parent.mkdir(parents=True, exist_ok=True)

        variant_imports = "\n".join(f"import 'variants/{v}.dart';" for v in variants)
        ctrl_import = f"import '../{ctrl_file}.dart';" if ctrl_file else ""
        ctrl_watch = f"final ctrl = context.watch<{controller}>();" if controller else ""
        ctrl_arg = "ctrl: ctrl" if controller else ""
        ctrl_field = f"  final {controller} ctrl;" if controller else ""
        ctrl_ctor_arg = "required this.ctrl, " if controller else ""

        screen_content = f"""\
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
{ctrl_import}
{variant_imports}

class {pascal}Screen extends StatelessWidget {{
  const {pascal}Screen({{super.key}});

  @override
  Widget build(BuildContext context) {{
    {ctrl_watch}
    return {pascal}V1({ctrl_arg});
  }}
}}
"""
        screen_path.write_text(screen_content.strip(), encoding="utf-8")
        click.echo(f"  ✓ wrote {entry.get('file')}")

        domain_lower = str(entry.get("domain") or "").lower()
        for v in variants:
            vpath = root / f"lib/features/{domain_lower}/variants/{v}.dart"
            vpath.parent.mkdir(parents=True, exist_ok=True)
            variant_content = f"""\
import 'package:flutter/material.dart';
{ctrl_import}

class {pascal}V1 extends StatelessWidget {{
  const {pascal}V1({{{ctrl_ctor_arg}super.key}});
{ctrl_field}

  @override
  Widget build(BuildContext context) {{
    return Scaffold(
      appBar: AppBar(title: const Text('{title}')),
      body: const Center(child: Text('TODO: {id_val}')),
    );
  }}
}}
"""
            vpath.write_text(variant_content.strip(), encoding="utf-8")
            click.echo(f"  ✓ wrote lib/features/{domain_lower}/variants/{v}.dart")
    else:
        click.echo(f"  (file generation for {stack}/{kind} not yet implemented)")

    # Impact-check after generation
    try:
        from forge.mcp.audit import resolve_audit_paths
        from forge.tools.docs_audit.orchestrator import run_docs_audit
        manifest_path, impact_path, impact_local, docs_root = resolve_audit_paths(root)
        if manifest_path.is_file() and impact_path.is_file():
            il = str(impact_local) if impact_local and impact_local.is_file() else None
            result = run_docs_audit(
                manifest_path=str(manifest_path),
                impact_path=str(impact_path),
                impact_local_path=il,
                docs_root=str(docs_root),
                changed_files=files,
                changed_text="",
                strict=False,
            )
            code = getattr(result, "exit_code", 0)
            click.echo(
                "  ✓ impact-check: clean" if code == 0
                else f"  ⚠ impact-check exit_code={code} — run: forge impact-check"
            )
    except Exception:
        pass


# ── Template save from existing manifest ──────────────────────────────────────

_SECTION_TO_KIND: dict[str, str] = {
    "screens": "screen",
    "controllers": "controller",
    "services": "service",
    "models": "model",
    "variants": "variant",
    "pages": "page",
    "components": "component",
    "hooks": "hook",
    "commands": "command",
}


def _save_from_manifest(
    root: Path,
    save_as: str,
    schemas: list[dict[str, Any]],
) -> None:
    """Save an existing manifest node as a named template.

    Prompts user to pick a node from the project manifest, strips
    project-specific fields, then writes to ~/.forge/templates/.
    """
    raw = _load_manifest_raw(root)

    # Collect all named nodes with metadata for display
    all_nodes: list[tuple[str, str, dict[str, Any]]] = []  # (section, kind, entry)
    for section, kind in _SECTION_TO_KIND.items():
        for item in raw.get(section) or []:
            if isinstance(item, dict):
                all_nodes.append((section, kind, item))

    if not all_nodes:
        click.echo(
            "✗ No nodes found in manifest.yaml — nothing to save as template.\n"
            "  Hint: make sure you are running from a project with screens/controllers/services.",
            err=True,
        )
        sys.exit(1)

    # Numbered display list
    labels: list[str] = []
    for _, kind, item in all_nodes:
        node_name = str(item.get("name") or item.get("id") or "?")
        domain = str(item.get("domain") or "")
        domain_part = f"  [{domain}]" if domain else ""
        labels.append(f"{kind:16s}  {node_name}{domain_part}")

    click.echo(f"\n── Pick a node to save as template: {save_as!r} ────────")
    selected_label = _prompt_numbered("Select node:", labels)
    sel_idx = labels.index(selected_label)
    _, kind, entry = all_nodes[sel_idx]

    # Resolve schema for this kind (fall back to a minimal stub)
    schema = next((s for s in schemas if s["kind"] == kind), None)
    if schema is None:
        click.echo(
            f"  (no node_schema found for kind={kind!r} — saving with minimal schema)",
        )
        schema = {"kind": kind, "stack": None}

    description = click.prompt(
        f"  Description for template {save_as!r} (optional)",
        default="",
    ).strip()

    saved_path = save_template(
        artifact=entry,
        schema=schema,
        name=save_as,
        description=description,
    )
    click.echo(f"  ✓ template saved → {saved_path}")


# ── Main menu ─────────────────────────────────────────────────────────────────

_KNOWN_STACKS = ["flutter-app", "web-next", "web-react", "python-cli"]


def run_scaffold_menu(
    project_path: str,
    save_as: str | None = None,
    from_template: str | None = None,
    list_templates_flag: bool = False,
    stack_filter: str | None = None,
) -> None:
    """Interactive scaffold menu — reads node_schemas from manifest.yaml."""

    # ── --save-as mode: pick from existing manifest, no scaffold flow ────────
    if save_as and not from_template:
        root = resolve_project_path(project_path)
        schemas = _load_node_schemas(root)
        _save_from_manifest(root, save_as, schemas)
        return

    # ── --list-templates mode: show registry and exit ─────────────────────────
    if list_templates_flag:
        templates = list_templates(stack=stack_filter)
        if not templates:
            hint = f" for stack {stack_filter!r}" if stack_filter else ""
            click.echo(f"  (no templates found{hint})")
            return
        header = f"Templates{(' — stack: ' + stack_filter) if stack_filter else ''}:"
        click.echo(header)
        for t in templates:
            desc = t.get("description") or ""
            desc_part = f"  {desc}" if desc else ""
            click.echo(
                f"  [{t['_source']:10s}]  {t['_kind']:16s}  {t['_name']}{desc_part}"
            )
        return

    root = Path(project_path).expanduser().resolve()
    schemas = _load_node_schemas(root)

    if not schemas:
        click.echo(
            "✗ No node_schemas found in manifest.yaml — cannot run menu.\n"
            "  Hint: run from a project with node_schemas, or ensure forge's own manifest is accessible.",
            err=True,
        )
        sys.exit(1)

    # ── --from-template mode: pre-load preset slots ───────────────────────────
    preset: dict[str, Any] = {}
    preset_kind: str | None = None
    preset_stack: Any = None

    if from_template:
        # Search all stacks since we don't know the kind yet
        hit = None
        for schema_entry in schemas:
            candidate = load_template(
                schema_entry.get("stack"),
                schema_entry["kind"],
                from_template,
            )
            if candidate:
                hit = candidate
                break
        if hit is None:
            click.echo(
                f"✗ Template {from_template!r} not found in any registry.",
                err=True,
            )
            sys.exit(1)
        tmpl_data, tmpl_source = hit
        preset = dict(tmpl_data.get("slots") or {})
        preset_kind = tmpl_data.get("kind")
        preset_stack = tmpl_data.get("stack")
        click.echo(
            f"\n── loaded template: {from_template!r} "
            f"(kind={preset_kind}, source={tmpl_source})"
        )
        click.echo(f"   preset slots: {', '.join(preset.keys()) or '(none)'}")

    click.echo(f"\n── forge scaffold ─────────────────────────────────────")
    click.echo(f"   project: {root}")

    # ── Level 1: Stack selection ──────────────────────────────────────────────
    present_stacks: list[str] = []
    for s in schemas:
        sv = s.get("stack")
        if sv is None:
            continue
        if isinstance(sv, list):
            for x in sv:
                if x and x not in present_stacks:
                    present_stacks.append(x)
        elif sv and sv not in present_stacks:
            present_stacks.append(sv)
    if not present_stacks:
        present_stacks = _KNOWN_STACKS

    # from_template pre-selects stack
    if preset_stack and (
        preset_stack in present_stacks
        or (isinstance(preset_stack, list) and any(s in present_stacks for s in preset_stack))
    ):
        selected_stack = preset_stack[0] if isinstance(preset_stack, list) else preset_stack
        click.echo(f"  stack: {selected_stack}  (from template)")
    else:
        detected = _detect_stack(root)
        if detected and detected in present_stacks:
            use_detected = click.confirm(f"\nDetected stack: {detected}. Continue?", default=True)
            selected_stack = detected if use_detected else None
        else:
            selected_stack = None
        if selected_stack is None:
            selected_stack = _prompt_numbered("Select stack:", present_stacks)

    # ── Level 2: Kind selection ───────────────────────────────────────────────
    def _stack_matches(sv: Any) -> bool:
        if sv is None:
            return True  # universal (doc, test)
        if isinstance(sv, list):
            return selected_stack in sv
        return sv == selected_stack

    kind_schemas = [s for s in schemas if _stack_matches(s.get("stack"))]
    if not kind_schemas:
        click.echo(f"✗ No kinds registered for stack {selected_stack!r}.", err=True)
        sys.exit(1)

    # from_template pre-selects kind
    if preset_kind and any(s["kind"] == preset_kind for s in kind_schemas):
        selected_kind = preset_kind
        schema = next(s for s in kind_schemas if s["kind"] == preset_kind)
        click.echo(f"  kind  : {selected_kind}  (from template)")
    else:
        kind_labels = [
            f"{s['kind']}  [{', '.join(s.get('required_fields') or [])}]"
            for s in kind_schemas
        ]
        selected_label = _prompt_numbered(f"Select kind ({selected_stack}):", kind_labels)
        sel_idx = kind_labels.index(selected_label)
        selected_kind = kind_schemas[sel_idx]["kind"]
        schema = kind_schemas[sel_idx]

    required_fields: list[str] = list(schema.get("required_fields") or [])
    auto_derive: dict[str, str] = dict(schema.get("auto_derive") or {})

    click.echo(f"\n── Filling slots for: {selected_kind} ──────────────────────")

    # ── Level 3: Slot filling ─────────────────────────────────────────────────
    # Seed entry with any preset_slots from template (overridable below)
    entry: dict[str, Any] = dict(preset)
    # Tracks fields collected interactively — prevents double-prompting
    _user_filled: set[str] = set()

    # Collect id first so auto_derive templates can interpolate it
    if auto_derive:
        entry["id"] = click.prompt("  id (slug, e.g. my_screen)").strip()

    for field in required_fields:
        # name — auto from id
        if field == "name":
            id_val = str(entry.get("id") or "").strip()
            entry["name"] = id_val or click.prompt("  name").strip()
            continue

        # file / path — auto_derive with preview
        if field in ("file", "path"):
            tpl = auto_derive.get(field)
            if tpl:
                # If template needs {domain_lower}: prompt domain first
                # (either not set yet, or only set from preset — user must confirm/override)
                domain_is_preset_only = entry.get("domain") and entry.get("domain") == preset.get("domain")
                if "{domain_lower}" in tpl and (not entry.get("domain") or domain_is_preset_only):
                    domains = _get_domains(root)
                    preset_domain = str(preset.get("domain") or "").upper()
                    default_idx: int | None = None
                    if preset_domain and preset_domain in domains:
                        default_idx = domains.index(preset_domain)
                        label = f"  Select domain [template: {preset_domain}]:"
                    else:
                        label = "  Select domain:"
                    chosen = _prompt_numbered(label, domains, default_idx=default_idx)
                    entry["domain"] = chosen
                    _user_filled.add("domain")
                    # Re-derive any other fields that embed domain
                    for k, t in auto_derive.items():
                        if "{domain_lower}" in t and not entry.get(k):
                            entry[k] = _interpolate(t, entry)
                derived = _interpolate(tpl, entry)
                raw = click.prompt(f"  {field} [auto: {derived}]", default=derived)
            else:
                raw = click.prompt(f"  {field} (repo-relative path)").strip()
            entry[field] = raw.strip()
            continue

        # domain — numbered list from manifest graph (may already be set by file handler)
        if field == "domain":
            if "domain" in _user_filled or (entry.get("domain") and "domain" not in preset):
                # Already collected interactively or set by user (not only from preset)
                continue
            domains = _get_domains(root)
            # If domain came from template preset, highlight it as default
            preset_domain = str(preset.get("domain") or "").upper()
            default_idx: int | None = None
            if preset_domain and preset_domain in domains:
                default_idx = domains.index(preset_domain)
                label = f"  Select domain [template: {preset_domain}]:"
            else:
                label = "  Select domain:"
            domain = _prompt_numbered(label, domains, default_idx=default_idx)
            entry["domain"] = domain
            # Re-derive path fields that embed {domain_lower}
            for k, tpl in auto_derive.items():
                if "{domain_lower}" in tpl and not entry.get(k):
                    entry[k] = _interpolate(tpl, entry)
            continue

        # method — HTTP verbs
        if field == "method":
            entry["method"] = _prompt_numbered(
                "  HTTP method:", ["GET", "POST", "PUT", "PATCH", "DELETE"], default_idx=0
            )
            continue

        # variant parent screen
        if field == "screen":
            entry["screen"] = click.prompt("  Parent screen name").strip()
            continue

        # tests_module
        if field == "tests_module":
            entry["tests_module"] = click.prompt("  Module being tested").strip()
            continue

        # generic fallback
        entry[field] = click.prompt(f"  {field}").strip()

    # Optional fields by kind
    if selected_kind == "screen":
        domain = str(entry.get("domain") or "")
        ctrls = _get_controllers_in_domain(root, domain)
        if ctrls:
            choice = _prompt_numbered(
                "  Select controller to watch:", ctrls + ["(none)"]
            )
            if choice != "(none)":
                entry["watches"] = [choice]
        else:
            watches_raw = click.prompt(
                "  watches (controller names, comma-sep, or blank)",
                default="",
            ).strip()
            if watches_raw:
                entry["watches"] = [w.strip() for w in watches_raw.split(",") if w.strip()]

        id_slug = str(entry.get("id") or entry.get("name") or "screen")
        variants_raw = click.prompt(
            f"  Variant name [auto: {id_slug}_v1]",
            default=f"{id_slug}_v1",
        ).strip()
        if variants_raw:
            entry["variants"] = [v.strip() for v in variants_raw.split(",") if v.strip()]

    elif selected_kind == "controller":
        iface_raw = click.prompt(
            "  interface method (e.g. startGame:Future<void>) or blank",
            default="",
        ).strip()
        if iface_raw and ":" in iface_raw:
            k, v = iface_raw.split(":", 1)
            entry["interface"] = {k.strip(): v.strip()}
        err_raw = click.prompt(
            "  error_codes (comma-sep) or blank",
            default="",
        ).strip()
        if err_raw:
            entry["error_codes"] = [e.strip() for e in err_raw.split(",") if e.strip()]

    # ── Level 4: Validation loop ──────────────────────────────────────────────
    click.echo(f"\n── Validation ─────────────────────────────────────────")

    while True:
        result = _validate_entry(entry, schema)

        if result["exit_code"] == 2:
            click.echo("✗ Blocked — fix required:")
            for b in result["blockers"]:
                click.echo(f"  - {b}")
            if not click.confirm("\nRe-enter slots?", default=True):
                click.echo("\nEntry YAML (for manual use):")
                click.echo(yaml.dump({"entry": entry, "entry_type": selected_kind}, default_flow_style=False))
                return
            # Re-prompt only failing fields
            for b in result["blockers"]:
                for f in required_fields:
                    if f in b:
                        if f == "domain":
                            entry["domain"] = _prompt_numbered(
                                "  Select domain:", _get_domains(root)
                            )
                        elif f == "method":
                            entry["method"] = click.prompt("  method").strip()
                        else:
                            entry[f] = click.prompt(f"  {f}").strip()
            continue

        if result["exit_code"] == 1:
            click.echo(f"⚠ {len(result['warnings'])} warning(s):")
            for w in result["warnings"]:
                click.echo(f"  - {w}")
            click.echo(f"Confidence: {result['confidence']:.0%}")
            if not click.confirm("\nProceed anyway?", default=True):
                click.echo("\nEntry YAML (for manual use):")
                click.echo(yaml.dump({"entry": entry, "entry_type": selected_kind}, default_flow_style=False))
                return

        # Clean (or warnings accepted)
        click.echo(f"✓ Valid — confidence: {result['confidence']:.0%}")
        click.echo(f"  exit_code : {result['exit_code']}")
        click.echo(f"  passed    : {result['passed']}/{len(required_fields)} required fields")
        files = _compute_files(entry, schema)
        if files:
            click.echo("  files     :")
            for f in files:
                click.echo(f"    {f}")

        click.echo("\nEntry YAML:")
        click.echo(yaml.dump({"entry": entry, "entry_type": selected_kind}, default_flow_style=False))

        if not click.confirm("Generate files now?", default=False):
            return

        _generate_files(entry, files, root, schema)
        return


# ══════════════════════════════════════════════════════════════════════════════
# Scaffold questionnaire — tree-walker for feature + node paths
# Resolves ANNOT-024.  Prerequisite: ANNOT-023 (registry at standard).
#
# Two modes:
#   interactive  (responses=None)  — blocks on click.prompt; CLI only
#   agent        (responses=dict)  — reads from dict; no blocking I/O
#
# Both modes return the same type:
#   list[dict]         — completed entries, each tagged with "entry_type"
#   dict               — questionnaire_step payload (agent mode: next question)
#                        or error dict
# ══════════════════════════════════════════════════════════════════════════════

def _qstep(
    step: str,
    prompt_text: str,
    options: list[str],
    hint: str,
    **extra: Any,
) -> dict[str, Any]:
    """Build a structured questionnaire-state dict for agent mode."""
    return {
        "questionnaire_step": step,
        "prompt": prompt_text,
        "options": options,
        "hint": hint,
        **extra,
    }


def _qget(
    responses: dict[str, Any],
    key: str,
    prompt_text: str,
    choices: list[str] | None,
    interactive: bool,
) -> tuple[Any, dict[str, Any] | None]:
    """Resolve one questionnaire slot.

    Returns (value, None) when resolved, or (None, qstep_dict) when blocked.
    In interactive mode this blocks on click.prompt.
    In agent mode it returns a questionnaire_step dict for the caller to surface.
    """
    val = responses.get(key)
    if val is not None:
        return str(val).strip() if isinstance(val, str) else val, None
    if interactive:
        if choices:
            val = _prompt_numbered(f"  {prompt_text}", choices)
        else:
            val = click.prompt(f"  {prompt_text}").strip()
        return val, None
    # Agent mode — need more input
    return None, _qstep(
        step=key,
        prompt_text=prompt_text,
        options=choices or [],
        hint=(
            f"Re-call forge_scaffold with "
            f"responses={{...existing..., {key!r}: <value>}}"
        ),
    )


def _qinterpolate(template_str: str, entry: dict[str, Any]) -> str:
    """Interpolate an auto_derive template string from entry fields."""
    domain = str(entry.get("domain") or "")
    id_val = str(entry.get("id") or "")
    pascal = id_val.replace("_", " ").title().replace(" ", "")
    return (
        template_str
        .replace("{id}", id_val)
        .replace("{domain_lower}", domain.lower())
        .replace("{PascalId}", pascal)
        .replace("{package}", str(entry.get("package") or "app"))
    )


def _build_entry_from_ref(
    node_ref: dict[str, Any],
    domain: str,
    id_val: str,
    schemas: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    """Build a complete entry dict from a feature-template NodeRef.

    The NodeRef carries template-default values (id, domain, watches).
    These are replaced by the questionnaire's resolved domain + id_val.
    Controller names in watches are renamed to match the new id
    (e.g. LobbyController → {PascalId}Controller).
    auto_derive fills file and name from the node_schema patterns.
    """
    kind = str(node_ref.get("kind") or "")
    schema = schemas.get(kind, {})
    auto_derive: dict[str, str] = dict(schema.get("auto_derive") or {})

    entry: dict[str, Any] = {"id": id_val, "domain": domain}

    # Rename watches: substitute template-id controller with actual-id controller
    tmpl_id = str(node_ref.get("id") or "")
    tmpl_pascal = tmpl_id.replace("_", " ").title().replace(" ", "") if tmpl_id else ""
    actual_pascal = id_val.replace("_", " ").title().replace(" ", "")
    watches_raw: list[str] = list(node_ref.get("watches") or [])
    if watches_raw:
        if tmpl_pascal:
            watches = [
                w.replace(f"{tmpl_pascal}Controller", f"{actual_pascal}Controller")
                for w in watches_raw
            ]
        else:
            watches = [w.replace("Controller", f"{actual_pascal}Controller") for w in watches_raw]
        entry["watches"] = watches

    # Apply auto_derive patterns
    for key, tpl in auto_derive.items():
        entry[key] = _qinterpolate(tpl, entry)

    # name always derived from id
    entry["name"] = id_val

    return entry


def _slot_fill(
    project_path: str,
    kind: str,
    schemas: dict[str, dict[str, Any]],
    seed: dict[str, Any] | None = None,
    responses: dict[str, Any] | None = None,
    interactive: bool = True,
) -> dict[str, Any]:
    """Fill required slots for one node kind.

    Returns a complete entry dict or a questionnaire_step dict (agent mode).
    seed pre-fills any already-known fields (e.g. from parse_describe).
    responses bypasses prompts for pre-filled slots.
    """
    schema = schemas.get(kind, {})
    required_fields: list[str] = list(schema.get("required_fields") or [])
    auto_derive: dict[str, str] = dict(schema.get("auto_derive") or {})

    entry: dict[str, Any] = dict(seed or {})
    r = dict(responses or {})

    # Resolve id first — auto_derive templates embed {id}
    if not entry.get("id"):
        val, qstep = _qget(r, "id", "id slug (e.g. lobby)", None, interactive)
        if qstep:
            return qstep
        entry["id"] = val

    for field in required_fields:
        if entry.get(field) is not None:
            continue  # already filled

        if field == "name":
            entry["name"] = str(entry.get("id") or "")
            continue

        if field in auto_derive:
            # Only apply if all tokens are available
            entry[field] = _qinterpolate(auto_derive[field], entry)
            continue

        if field == "domain":
            domains = _get_domains(resolve_project_path(project_path))
            val, qstep = _qget(r, "domain", "Which domain?", domains or None, interactive)
            if qstep:
                return qstep
            entry["domain"] = val
            # Re-derive path fields that embed {domain_lower}
            for k, tpl in auto_derive.items():
                if "{domain_lower}" in tpl and not entry.get(k):
                    entry[k] = _qinterpolate(tpl, entry)
            continue

        if field == "method":
            val, qstep = _qget(
                r, "method", "HTTP method",
                ["GET", "POST", "PUT", "PATCH", "DELETE"], interactive,
            )
            if qstep:
                return qstep
            entry["method"] = val
            continue

        if field == "screen":
            val, qstep = _qget(r, "screen", "Parent screen name", None, interactive)
            if qstep:
                return qstep
            entry["screen"] = val
            continue

        # Generic field fallback
        val, qstep = _qget(r, field, field, None, interactive)
        if qstep:
            return qstep
        entry[field] = val

    # Final pass: ensure name + fill any remaining auto_derive fields
    if not entry.get("name"):
        entry["name"] = str(entry.get("id") or "")
    for key, tpl in auto_derive.items():
        if not entry.get(key):
            entry[key] = _qinterpolate(tpl, entry)

    return entry


def _questionnaire_node_path(
    project_path: str,
    stack: str,
    schemas: dict[str, dict[str, Any]],
    kind: str | None = None,
    seed: dict[str, Any] | None = None,
    responses: dict[str, Any] | None = None,
    interactive: bool = True,
) -> dict[str, Any]:
    """Level 1B — kind selection followed by slot-fill for one node.

    Returns a complete entry dict (tagged entry_type) or questionnaire_step.
    """
    r = dict(responses or {})

    if not kind:
        # Offer stack-relevant kinds first, then universals
        def _stack_match(s: dict[str, Any]) -> bool:
            sv = s.get("stack")
            if sv is None:
                return True
            if isinstance(sv, list):
                return stack in sv
            return sv == stack

        kind_names = [k for k, s in schemas.items() if _stack_match(s)]
        if not kind_names:
            kind_names = list(schemas.keys())

        val, qstep = _qget(r, "level_1", "Which node kind?", kind_names, interactive)
        if qstep:
            return qstep
        kind = str(val)

    entry = _slot_fill(
        project_path, kind, schemas,
        seed=seed, responses=r, interactive=interactive,
    )
    if "questionnaire_step" in entry:
        return entry

    entry["entry_type"] = kind
    return entry


def _questionnaire_feature_path(
    project_path: str,
    stack: str,
    schemas: dict[str, dict[str, Any]],
    responses: dict[str, Any] | None = None,
    interactive: bool = True,
) -> list[dict[str, Any]] | dict[str, Any]:
    """Level 1A — feature template selection → required nodes → optional nodes.

    Returns a list of entry dicts (each tagged entry_type) or questionnaire_step.
    """
    r = dict(responses or {})

    templates = list_feature_templates(stack=stack)
    if not templates:
        return {
            "error": "no_feature_templates",
            "stack": stack,
            "hint": (
                f"No feature templates found for stack {stack!r}. "
                f"Run: forge registry list --templates --stack {stack}"
            ),
        }

    template_names = [t["_name"] for t in templates]
    level_1, qstep = _qget(r, "level_1", "Which feature type?", template_names, interactive)
    if qstep:
        return qstep

    tmpl = get_feature_template(str(level_1), stack)
    if tmpl is None:
        return {
            "error": "template_not_found",
            "name": level_1,
            "available": template_names,
        }

    # Resolve feature-level slots (domain + id) once for all nodes
    domain_val, qstep = _qget(r, "domain", "Which domain?", _get_domains(
        resolve_project_path(project_path)) or None, interactive)
    if qstep:
        return qstep

    id_val, qstep = _qget(r, "id", "Feature name slug (e.g. lobby)?", None, interactive)
    if qstep:
        return qstep

    nodes: list[dict[str, Any]] = []

    # Required nodes — all must be present
    for node_ref in (tmpl.get("requires") or []):
        kind = str(node_ref.get("kind") or "")
        entry = _build_entry_from_ref(node_ref, str(domain_val), str(id_val), schemas)
        entry["entry_type"] = kind
        nodes.append(entry)

    # Optional nodes — skipped unless responses says include
    for node_ref in (tmpl.get("optional") or []):
        kind = str(node_ref.get("kind") or "?")
        opt_id = str(node_ref.get("id") or kind)
        include_key = f"include_{kind}_{opt_id}"
        include = r.get(include_key)
        if include is None:
            if interactive:
                include = click.confirm(f"\n  Include optional {kind} ({opt_id})?", default=False)
            else:
                include = False  # agent default: skip optional unless explicitly requested
        # Normalise string truthy values
        if isinstance(include, str):
            include = include.lower() in ("true", "yes", "1", "y")
        if include:
            entry = _build_entry_from_ref(node_ref, str(domain_val), str(id_val), schemas)
            entry["entry_type"] = kind
            nodes.append(entry)

    return nodes


def run_questionnaire(
    project_path: str,
    stack: str,
    partial_entry: dict[str, Any] | None = None,
    responses: dict[str, Any] | None = None,
) -> list[dict[str, Any]] | dict[str, Any]:
    """Top-level scaffold questionnaire — tree walker for feature + node paths.

    Returns:
        list[dict]  — completed entries, each tagged with "entry_type".
                      Pass each to scaffolder.execute(entry, ..., entry_type, schema).
        dict        — questionnaire_step payload (agent mode: the next question
                      the caller must answer) OR error dict.

    Args:
        project_path:  Project root (expanduser-safe).
        stack:         Detected stack string (e.g. "flutter-app").
        partial_entry: Seed dict from parse_describe(). Pre-fills Level 1B slots.
        responses:     Pre-supplied answers for agent mode.
                         None          → interactive mode (blocks on click.prompt)
                         {}            → agent mode, no answers → returns level_0 question
                         {"level_0": "feature", "level_1": "lobby-feature", ...}
                                       → agent mode, processes until complete

    The responses dict is consumed sequentially:
        level_0: "feature" | "node"
        level_1: template name (feature path) | kind name (node path)
        domain:  domain string
        id:      id slug
        include_{kind}_{id}: "true"|"false" for optional nodes (feature path)
    """
    from forge.tools.scaffold.parser import load_node_schemas

    interactive = responses is None
    r = dict(responses or {})

    schemas_list = load_node_schemas(project_path)
    schemas: dict[str, dict[str, Any]] = {
        s["kind"]: s
        for s in schemas_list
        if isinstance(s, dict) and "kind" in s
    }

    if not schemas:
        return {
            "error": "no_manifest",
            "project_path": project_path,
            "hint": (
                "No manifest found — run 'forge audit --draft' to bootstrap "
                "this project, then retry."
            ),
        }

    # LEVEL 0: feature or single node?
    level_0, qstep = _qget(
        r, "level_0",
        "Feature (multi-node anatomy) or single node?",
        ["feature", "node"],
        interactive,
    )
    if qstep:
        return qstep

    if str(level_0).lower() == "feature":
        return _questionnaire_feature_path(
            project_path, stack, schemas,
            responses=r, interactive=interactive,
        )
    else:
        # Single node — seed from parse_describe() if available
        kind_seed = str(partial_entry.get("kind") or "") if partial_entry else None
        result = _questionnaire_node_path(
            project_path, stack, schemas,
            kind=kind_seed if kind_seed else None,
            seed={k: v for k, v in (partial_entry or {}).items() if k != "kind"},
            responses=r,
            interactive=interactive,
        )
        # Wrap single-node result in a list for uniform return type
        if isinstance(result, dict) and "questionnaire_step" not in result and "error" not in result:
            return [result]
        return result
