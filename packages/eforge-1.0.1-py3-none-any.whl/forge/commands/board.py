from __future__ import annotations

import click
import shutil
import subprocess
import sys
import threading
from pathlib import Path

from forge.core.discovery import discover_projects, get_projects_root
from forge.archive.tui.textual.state_types import ProjectState
from forge.renderers.web.renderer import WebRenderer


"""
forge board — starts the denvboard React web dashboard.

Discovers all Forge projects under get_projects_root(), loads ProjectState
for each, and passes them to WebRenderer which starts a FastAPI server on
the given port and opens the browser.

Usage:
    forge board              # default port 7331
    forge board --port 8080  # custom port

Development:
    Run `forge board` in one terminal for the API server, then
    `cd forge/renderers/web/ui && npm run dev` in another for hot-reload.
"""

def _ensure_npm() -> bool:
    if shutil.which("npm"):
        return True
    print(
        "npm not found. Install Node.js from https://nodejs.org to build the dashboard.",
        file=sys.stderr,
    )
    return False


def _run_npm(ui_root: str, args: list[str], *, label: str) -> int:
    try:
        result = subprocess.run(
            ["npm", *args],
            cwd=ui_root,
            stdout=sys.stdout,
            stderr=sys.stderr,
            check=False,
            text=True,
        )
    except FileNotFoundError:
        print(
            "npm not found. Install Node.js from https://nodejs.org to build the dashboard.",
            file=sys.stderr,
        )
        return 127
    except Exception as exc:  # pragma: no cover - defensive
        print(f"{label} failed: {exc}", file=sys.stderr)
        return 1
    return int(result.returncode)


@click.command("board")
@click.option(
    "--mcp",
    is_flag=True,
    default=False,
    help="Run Forge as an MCP server over stdio (no web UI).",
)
@click.option("--port", type=int, default=7331, show_default=True)
@click.option(
    "--build",
    is_flag=True,
    default=False,
    help="Before start: npm install in ui/ if node_modules missing, then npm run build (skipped if ui/dist exists; use --rebuild). Streams to terminal; exits 1 on failure.",
)
@click.option(
    "--rebuild",
    is_flag=True,
    default=False,
    help="Like --build but always runs npm run build even when ui/dist/ exists.",
)
@click.option(
    "--dev",
    is_flag=True,
    default=False,
    help="Run npm run dev (Vite) in ui/ alongside the API server; use http://localhost:5173 (proxies /api to this server).",
)
def board_cmd(port: int, build: bool, rebuild: bool, dev: bool, mcp: bool) -> None:
    """Start the denvboard web dashboard."""
    if mcp:
        try:
            from forge.tools.workspace_store import find_workspace_projects
            from forge.mcp.server import main
            import sys # nice! 

            projects, source = find_workspace_projects()
            print(f"forge MCP: {len(projects)} projects loaded from {source}", file=sys.stderr)
            if len(projects) == 0:
                print(
                    "forge MCP warning: no workspace projects loaded. Run `forge projects init` or "
                    "`forge projects add <path>` or set FORGE_WORKSPACE=...code-workspace",
                    file=sys.stderr,
                )
            main()
        except (KeyboardInterrupt, SystemExit):
            pass  # clean exit, no traceback
        return
    ui_root_path = Path(__file__).resolve().parent.parent / "renderers" / "web" / "ui"
    ui_root = str(ui_root_path)
    node_modules_dir = ui_root_path / "node_modules"
    dist_dir = ui_root_path / "dist"

    if rebuild:
        build = True

    if build and (rebuild or not dist_dir.exists()):
        if not _ensure_npm():
            raise SystemExit(1)
        if not node_modules_dir.exists():
            if _run_npm(ui_root, ["install"], label="npm install") != 0:
                print("Build failed (npm install).", file=sys.stderr)
                raise SystemExit(1)
        print("Building dashboard...")
        if _run_npm(ui_root, ["run", "build"], label="npm run build") != 0:
            print("Build failed (npm run build).", file=sys.stderr)
            raise SystemExit(1)
        print("Build complete.")
    elif build:
        print("Build skipped (dist/ already exists; use --rebuild to force).")

    if dev:
        if not _ensure_npm():
            raise SystemExit(1)
        if not node_modules_dir.exists():
            if _run_npm(ui_root, ["install"], label="npm install") != 0:
                print("Dev start failed (npm install).", file=sys.stderr)
                raise SystemExit(1)

        if port != 7331:
            print(
                "[forge board --dev] vite.config.ts proxies /api to :7331; "
                f"current --port is {port}.",
                file=sys.stderr,
            )

        def _run_dev() -> None:
            rc = _run_npm(ui_root, ["run", "dev"], label="npm run dev")
            if rc != 0:
                print(f"[forge board --dev] npm run dev exited with code {rc}", file=sys.stderr)

        print("Starting Vite dev server (npm run dev)...")
        threading.Thread(target=_run_dev, daemon=True).start()

    root = get_projects_root()
    projects = list(discover_projects(root))
    states: list[ProjectState] = []
    for project in projects:
        try:
            states.append(ProjectState.load(project))
        except Exception as exc:  # pragma: no cover - defensive logging
            import sys
            import traceback

            print(f"[forge board] failed to load ProjectState for {project.path}: {exc}", file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
    renderer = WebRenderer(port=port)
    renderer.run(states)

