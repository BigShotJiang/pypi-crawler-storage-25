from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click

from forge.core.path_utils import resolve_project_path
from forge.tools.glove_templates.registry import (
    discover_templates,
    filter_templates,
    load_schema_templates_section,
    resolve_schema_yaml_path,
    template_l1_row,
    templates_l0_payload,
    validate_all_templates,
    validate_one_template,
)


def _l2_record(data: dict[str, Any]) -> dict[str, Any]:
    keys = (
        "schema_version",
        "id",
        "kind",
        "stack",
        "tier",
        "spec_fields",
        "conventions",
        "description",
        "produces",
        "requires",
        "inputs",
        "conditionals",
        "wiring",
        "operations",
        "security_rules",
    )
    return {k: data[k] for k in keys if k in data}


@click.group("template")
def template_group() -> None:
    """Discover and validate glove-colocated YAML scaffold templates."""


@template_group.command("list")
@click.option("--stack", default=None, metavar="STACK", help="Filter by template stack value.")
@click.option("--kind", default=None, metavar="KIND", help="Filter by manifest node kind.")
@click.option(
    "--tier",
    "tier_filter",
    type=click.Choice(["nodes", "features", "implementations"], case_sensitive=False),
    default=None,
    help="Filter by template tier directory.",
)
@click.option(
    "--response-tier",
    "response_tier",
    type=click.Choice(["L0", "L1", "L2"], case_sensitive=False),
    default="L1",
    show_default=True,
)
def template_list(
    stack: str | None,
    kind: str | None,
    tier_filter: str | None,
    response_tier: str,
) -> None:
    """List all templates discovered under forge/gloves/*/templates/**/*.yaml."""
    rows: list[dict[str, Any]] = []
    for _path, _tier, data in discover_templates():
        if not data:
            continue
        rows.append(dict(data))
    rows = filter_templates(rows, stack=stack, kind=kind, tier=tier_filter)
    tier_u = str(response_tier).upper()
    if tier_u == "L0":
        click.echo(json.dumps(templates_l0_payload([template_l1_row(r) for r in rows]), indent=2))
        return
    if tier_u == "L1":
        click.echo(json.dumps([template_l1_row(r) for r in rows], indent=2))
        return
    click.echo(json.dumps([_l2_record(r) for r in rows], indent=2))


@template_group.command("show")
@click.argument("template_id")
def template_show(template_id: str) -> None:
    """Print one template record (L2 field set) by id (kind.stack)."""
    want = template_id.strip()
    for _path, _tier, data in discover_templates():
        if not data:
            continue
        if str(data.get("id") or "") == want:
            click.echo(json.dumps(_l2_record(data), indent=2))
            raise SystemExit(0)
    click.echo(f"unknown template id: {want!r}", err=True)
    raise SystemExit(1)


@template_group.command("schema")
@click.option("--project-path", default=".", show_default=True, type=click.Path(file_okay=False))
def template_schema(project_path: str) -> None:
    """Print the ``templates`` section from .forge/schema.yaml (resolved from project or forge repo)."""
    root = resolve_project_path(project_path)
    blob = load_schema_templates_section(root)
    if not blob:
        p = resolve_schema_yaml_path(root)
        click.echo(json.dumps({"error": "no templates section", "schema_path": str(p)}, indent=2))
        raise SystemExit(1)
    click.echo(json.dumps(blob, indent=2))


@template_group.command("validate")
@click.argument("template_id", required=False, default=None)
def template_validate(template_id: str | None) -> None:
    """Validate glove templates. With TEMPLATE_ID, validate only that id; otherwise validate all."""
    want = (template_id or "").strip()
    if want:
        bad_one: list[tuple[Path, str]] = []
        for path, _tier, data in discover_templates():
            if not data:
                continue
            if str(data.get("id") or "") != want:
                continue
            for msg in validate_one_template(data, path):
                bad_one.append((path, msg))
            if not bad_one:
                click.echo(f"template {want!r} valid")
                raise SystemExit(0)
            for p, msg in bad_one:
                click.echo(f"{p}: {msg}", err=True)
            raise SystemExit(1)
        click.echo(f"unknown template id: {want!r}", err=True)
        raise SystemExit(1)

    bad = validate_all_templates()
    if not bad:
        click.echo("all templates valid")
        raise SystemExit(0)
    for path, msg in bad:
        click.echo(f"{path}: {msg}", err=True)
    raise SystemExit(1)


template_cmd = template_group
