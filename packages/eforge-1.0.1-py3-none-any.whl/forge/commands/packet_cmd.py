from __future__ import annotations

import hashlib
import json
import re
import shutil
from collections import defaultdict, deque
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import click
import yaml

from forge.commands._shared_options import response_tier_option
from forge.core.path_utils import resolve_project_path

_NODE_TYPES = ("screen", "controller", "service", "model", "variant", "module")
_METHOD_PATTERN = re.compile(
    r"^([A-Za-z_][A-Za-z0-9_]*)\((.*?)\)\s*->\s*([A-Za-z0-9_<>, ?.\[\]]+)$"
)


class PacketAssembleError(ValueError):
    """Raised when packet assembly fails deterministic validation."""


def _parse_csv(value: str | None) -> list[str]:
    if not value:
        return []
    return [part.strip() for part in str(value).split(",") if part.strip()]


def _load_yaml_dict(path: Path) -> dict[str, Any]:
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise PacketAssembleError(f"failed to parse yaml at {path}: {exc}") from exc
    if not isinstance(raw, dict):
        raise PacketAssembleError(f"yaml at {path} must be a mapping")
    return raw


def _resolve_stack(manifest: dict[str, Any]) -> str:
    project = manifest.get("project")
    if isinstance(project, dict):
        val = str(project.get("stack") or "").strip()
        if val:
            return val
    stack = manifest.get("stack")
    if isinstance(stack, str) and stack.strip():
        return stack.strip()
    if isinstance(stack, dict):
        for key in ("id", "name", "language"):
            val = str(stack.get(key) or "").strip()
            if val:
                return val
    app = manifest.get("app")
    if isinstance(app, dict):
        val = str(app.get("stack") or "").strip()
        if val:
            return val
    raise PacketAssembleError("manifest stack could not be resolved (expected project.stack or stack)")


def _parse_method_signature(signature: str) -> dict[str, Any]:
    text = signature.strip()
    match = _METHOD_PATTERN.match(text)
    if not match:
        raise PacketAssembleError(
            f"invalid method signature '{signature}'; expected name(param:Type)->Return"
        )
    method_name, params_blob, returns = match.group(1), match.group(2).strip(), match.group(3).strip()
    params: list[dict[str, str]] = []
    if params_blob:
        for raw_param in [p.strip() for p in params_blob.split(",") if p.strip()]:
            if ":" not in raw_param:
                raise PacketAssembleError(
                    f"invalid method param '{raw_param}'; expected name:Type"
                )
            p_name, p_type = [x.strip() for x in raw_param.split(":", 1)]
            if not p_name or not p_type:
                raise PacketAssembleError(
                    f"invalid method param '{raw_param}'; expected name:Type"
                )
            params.append({"name": p_name, "type": p_type})
    return {"name": method_name, "params": params, "returns": returns}


def _manifest_modules(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    modules = manifest.get("modules")
    if not isinstance(modules, list):
        return []
    return [row for row in modules if isinstance(row, dict)]


def _lookup_manifest_node(manifest: dict[str, Any], dep_name: str) -> dict[str, Any] | None:
    token = dep_name.strip()
    if not token:
        return None
    for row in _manifest_modules(manifest):
        node_id = str(row.get("id") or "").strip()
        name = str(row.get("name") or "").strip()
        if token in {node_id, name}:
            return row
    return None


def _extract_contract_rule(contract_entry: Any) -> str:
    if isinstance(contract_entry, dict):
        rule = contract_entry.get("rule")
        if isinstance(rule, str) and rule.strip():
            return rule.strip()
        fmt = contract_entry.get("format")
        if isinstance(fmt, str) and fmt.strip():
            return fmt.strip()
    return ""


def _render_template_path(path_tpl: str, *, domain: str, name: str) -> str:
    return path_tpl.replace("{domain}", domain.lower()).replace("{name}", name)


def _topological_file_order(paths: list[str]) -> list[str]:
    # Build a directory-first DAG so parent directories are emitted before children.
    nodes = sorted(set(paths))
    edges: dict[str, set[str]] = {n: set() for n in nodes}
    indegree: dict[str, int] = {n: 0 for n in nodes}
    for src in nodes:
        for dst in nodes:
            if src == dst:
                continue
            src_parent = str(Path(src).parent)
            dst_parent = str(Path(dst).parent)
            if src_parent != "." and dst.startswith(src_parent + "/") and src != dst:
                if dst not in edges[src]:
                    edges[src].add(dst)
                    indegree[dst] += 1
    queue: deque[str] = deque(sorted([n for n in nodes if indegree[n] == 0]))
    ordered: list[str] = []
    while queue:
        cur = queue.popleft()
        ordered.append(cur)
        for nxt in sorted(edges[cur]):
            indegree[nxt] -= 1
            if indegree[nxt] == 0:
                queue.append(nxt)
    if len(ordered) != len(nodes):
        return sorted(nodes)
    return ordered


def _packet_expires_at(packet: dict[str, Any]) -> str | None:
    freshness = packet.get("freshness")
    if not isinstance(freshness, dict):
        return None
    assembled_at = str(freshness.get("assembled_at") or "").strip()
    expires_after = str(freshness.get("expires_after") or "72h").strip().lower()
    if not assembled_at:
        return None
    try:
        if assembled_at.endswith("Z"):
            assembled = datetime.fromisoformat(assembled_at.replace("Z", "+00:00"))
        else:
            assembled = datetime.fromisoformat(assembled_at)
    except ValueError:
        return None
    if expires_after.endswith("h"):
        delta = timedelta(hours=int(expires_after[:-1]))
    elif expires_after.endswith("d"):
        delta = timedelta(days=int(expires_after[:-1]))
    else:
        return None
    return (assembled + delta).astimezone(UTC).isoformat().replace("+00:00", "Z")


def run_packet_assemble(
    *,
    node: str,
    node_type: str,
    domain: str,
    task: str = "generate",
    deps: list[str] | None = None,
    methods: list[str] | None = None,
    project_path: str = ".",
) -> dict[str, Any]:
    deps = deps or []
    methods = methods or []
    node = str(node or "").strip()
    node_type = str(node_type or "").strip().lower()
    domain = str(domain or "").strip().upper()
    task = str(task or "generate").strip().lower()
    if not node:
        raise PacketAssembleError("node is required")
    if node_type not in _NODE_TYPES:
        raise PacketAssembleError("type must be one of screen|controller|service|model|variant|module")
    if task not in {"generate", "fix"}:
        raise PacketAssembleError("task must be generate or fix")

    root = resolve_project_path(project_path)
    manifest_path = root / ".forge" / "manifest.yaml"
    if not manifest_path.is_file():
        raise PacketAssembleError(f"manifest not found: {manifest_path}")
    manifest = _load_yaml_dict(manifest_path)
    stack = _resolve_stack(manifest)
    glove_path = root / ".forge" / "gloves" / f"{stack}.glove.yaml"
    if not glove_path.is_file():
        raise PacketAssembleError(f"glove not found: {glove_path}")
    glove = _load_yaml_dict(glove_path)

    from forge.engine import ForgeEngine

    eng = ForgeEngine(root)
    eng.load()

    def _resolve_packet_node_id(token: str) -> str:
        t = str(token or "").strip()
        if not t:
            return ""
        nm = eng.registry.get_node(t)
        if nm is not None and getattr(nm, "id", None):
            return str(nm.id).strip()
        row = _lookup_manifest_node(manifest, t)
        if row:
            rid = str(row.get("id") or "").strip()
            if rid:
                return rid
        return t

    primary_ref = node
    canonical_node_id = _resolve_packet_node_id(primary_ref)
    target_row = _lookup_manifest_node(manifest, primary_ref) or {}
    file_label = str(target_row.get("name") or "").strip() or (
        canonical_node_id.rsplit("/", 1)[-1] if canonical_node_id else primary_ref
    )

    glove_domains = {str(x).strip().upper() for x in (glove.get("domains") or []) if str(x).strip()}
    if domain not in glove_domains:
        raise PacketAssembleError(
            f"glove contract violated: domain '{domain}' not in glove.domains"
        )

    glove_node_types = glove.get("node_types")
    if not isinstance(glove_node_types, dict) or node_type not in glove_node_types:
        raise PacketAssembleError(
            f"glove contract violated: node_type '{node_type}' not in glove.node_types"
        )
    node_spec = glove_node_types[node_type]
    if not isinstance(node_spec, dict):
        raise PacketAssembleError(f"invalid glove node spec for '{node_type}'")

    forbidden_dep_types = {
        str(x).strip().lower() for x in (node_spec.get("forbidden_deps") or []) if str(x).strip()
    }

    deps_detail: list[dict[str, Any]] = []
    deps_by_kind: dict[str, list[str]] = {"services": [], "controllers": [], "models": []}
    dep_types_observed: defaultdict[str, int] = defaultdict(int)
    for dep_name in deps:
        resolved = _lookup_manifest_node(manifest, dep_name)
        if resolved is None:
            deps_detail.append(
                {
                    "node_id": _resolve_packet_node_id(dep_name),
                    "name": dep_name,
                    "status": "planned",
                    "type": None,
                    "domain": None,
                    "interface": None,
                }
            )
            continue
        dep_type = str(resolved.get("kind") or resolved.get("type") or "").strip().lower()
        if not dep_type:
            dep_type = "module"
        if dep_type in forbidden_dep_types:
            raise PacketAssembleError(
                f"glove contract violated: node_types.{node_type}.forbidden_deps contains '{dep_type}'"
            )
        dep_domain = str(resolved.get("domain") or "").strip().upper() or None
        dep_interface = resolved.get("interface") if isinstance(resolved.get("interface"), dict) else None
        dep_canon = _resolve_packet_node_id(dep_name)
        deps_detail.append(
            {
                "node_id": dep_canon,
                "name": dep_name,
                "status": "present",
                "type": dep_type,
                "domain": dep_domain,
                "interface": dep_interface,
            }
        )
        dep_types_observed[dep_type] += 1
        if dep_type == "service":
            deps_by_kind["services"].append(dep_canon)
        elif dep_type == "controller":
            deps_by_kind["controllers"].append(dep_canon)
        elif dep_type == "model":
            deps_by_kind["models"].append(dep_canon)

    contracts_map = glove.get("contracts")
    if not isinstance(contracts_map, dict):
        raise PacketAssembleError("glove contract violated: glove.contracts missing")
    required_contract_keys = [str(c).strip() for c in (node_spec.get("required_contracts") or []) if str(c).strip()]
    contract_keys: list[str] = []
    contract_rules: list[str] = []
    for key in required_contract_keys:
        entry = contracts_map.get(key)
        if not isinstance(entry, dict):
            raise PacketAssembleError(
                f"glove contract violated: contract '{key}' missing from glove.contracts"
            )
        if entry.get("verifiable") is not True:
            continue
        rule_text = _extract_contract_rule(entry)
        if not rule_text:
            raise PacketAssembleError(
                f"glove contract violated: contract '{key}' missing verifiable rule text"
            )
        contract_keys.append(key)
        contract_rules.append(rule_text)

    output_paths = [str(x) for x in (node_spec.get("output_paths") or []) if str(x).strip()]
    if not output_paths:
        raise PacketAssembleError(
            f"glove contract violated: node_types.{node_type}.output_paths is empty"
        )
    files = []
    for path_tpl in output_paths:
        rendered = _render_template_path(path_tpl, domain=domain, name=file_label)
        files.append(
            {
                "path": rendered,
                "template": f"{node_type}.default",
                "vars": {
                    "name": file_label,
                    "node_id": canonical_node_id,
                    "domain": domain,
                    "node_type": node_type,
                },
                "action": "create" if task == "generate" else "patch",
            }
        )

    wiring_rows = node_spec.get("wiring") if isinstance(node_spec.get("wiring"), list) else []
    wiring = []
    for row in wiring_rows:
        if not isinstance(row, dict):
            continue
        file_path = str(row.get("file") or "").strip()
        pattern = str(row.get("pattern") or "").strip()
        vars_map = row.get("vars") if isinstance(row.get("vars"), dict) else {}
        if file_path and pattern:
            wiring.append(
                {
                    "file": _render_template_path(file_path, domain=domain, name=file_label),
                    "pattern": pattern,
                    "vars": vars_map,
                }
            )

    assembled_at = datetime.now(UTC).isoformat().replace("+00:00", "Z")
    graph_hash = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    glove_version = str(glove.get("version") or "1.0.0").strip()
    packet: dict[str, Any] = {
        "type": task,
        "node": canonical_node_id,
        "domain": domain,
        "stack_glove": stack,
        "glove_version": glove_version,
        "freshness": {
            "assembled_at": assembled_at,
            "graph_hash": graph_hash,
            "glove_version": glove_version,
            "expires_after": "72h",
        },
        "review": {
            "assembled_by": "forge-packet-assemble",
            "reviewed_by": None,
            "reviewed_at": None,
            "notes": "",
        },
        "constraints": {
            "max_nodes_per_packet": 1,
            "max_methods_per_packet": 8,
            "max_wiring_targets": 3,
        },
        "logging": {"domain": domain, "component": canonical_node_id},
        "slot_order": _topological_file_order([str(x["path"]) for x in files]),
    }

    if task == "generate":
        packet.update(
            {
                "inputs": {"deps": deps_by_kind},
                "interface": {"methods": [_parse_method_signature(sig) for sig in methods]},
                "contracts": contract_keys,
                "outputs": {"files": files},
                "manifest_patch": [
                    {
                        "op": "add",
                        "node_id": canonical_node_id,
                        "type": node_type,
                        "domain": domain,
                    }
                ],
                "wiring": wiring,
            }
        )
    else:
        packet.update(
            {
                "broken_method": {
                    "file": files[0]["path"],
                    "method": methods[0] if methods else f"{file_label}.unknown() -> void",
                    "line_range": [1, 1],
                },
                "root_cause": "to be confirmed during human review",
                "dependencies": [
                    {
                        "node_id": d.get("node_id"),
                        "node": d.get("name"),
                        "role": "consumes",
                    }
                    for d in deps_detail
                    if d["status"] == "present"
                ],
                "violated_contract": {
                    "name": contract_keys[0] if contract_keys else "no_hardcode",
                    "rule": contract_rules[0] if contract_rules else "no hardcoded config values",
                },
                "expected_behaviour": "Node behaviour aligns with glove contracts.",
                "validation": {
                    "failing_test": "TODO::set failing test",
                    "verify_before_execute": True,
                    "verify_after_execute": True,
                },
                "scope": {
                    "modify": [str(x["path"]) for x in files],
                    "verify_unchanged": [],
                },
            }
        )

    packet_dir = root / ".forge" / "cowork" / "packets"
    packet_dir.mkdir(parents=True, exist_ok=True)
    safe_file_token = canonical_node_id.replace("/", "__").replace(":", "_")
    if task == "generate":
        packet_file = packet_dir / f"generate__{safe_file_token}.yaml"
    else:
        packet_file = packet_dir / f"fix__{safe_file_token}__FIX.yaml"
    packet_file.write_text(yaml.safe_dump(packet, sort_keys=False), encoding="utf-8")
    expires_at = _packet_expires_at(packet) or ""
    return {
        "packet_path": str(packet_file),
        "node": canonical_node_id,
        "type": node_type,
        "domain": domain,
        "contracts": contract_keys,
        "contract_rules": contract_rules,
        "deps_resolved": sum(1 for d in deps_detail if d["status"] == "present"),
        "deps_planned": sum(1 for d in deps_detail if d["status"] == "planned"),
        "deps_detail": deps_detail,
        "files_to_generate": [str(x["path"]) for x in files],
        "expires_at": expires_at,
        "slot_order": packet.get("slot_order") or [],
        "graph_hash": graph_hash,
        "dep_type_breakdown": dict(dep_types_observed),
    }


def run_packet_list(*, project_path: str, response_tier: str = "L1") -> dict[str, Any]:
    root = resolve_project_path(project_path)
    packet_dir = root / ".forge" / "cowork" / "packets"
    rows = []
    if packet_dir.is_dir():
        for packet_path in sorted(packet_dir.glob("*.yaml")):
            packet = _load_yaml_dict(packet_path)
            reviewed_by = ((packet.get("review") or {}).get("reviewed_by"))
            reviewed = bool(reviewed_by)
            rows.append(
                {
                    "name": packet_path.name,
                    "type": str(packet.get("type") or ""),
                    "node": str(packet.get("node") or ""),
                    "assembled_at": str((packet.get("freshness") or {}).get("assembled_at") or ""),
                    "expires_at": _packet_expires_at(packet),
                    "reviewed": reviewed,
                    "path": str(packet_path),
                }
            )
    return {"response_tier": response_tier, "packets": rows}


def _archive_packet_file(packet_path: Path, archive_dir: Path, outcome: str) -> Path:
    packet = _load_yaml_dict(packet_path)
    now = datetime.now(UTC).isoformat().replace("+00:00", "Z")
    packet["execution"] = {
        "executed_by": "forge-packet",
        "executed_at": now,
        "outcome": outcome,
        "files_created": [],
        "files_modified": [],
        "forge_map_hash_after": "",
        "notes": "",
    }
    archive_dir.mkdir(parents=True, exist_ok=True)
    dest = archive_dir / packet_path.name
    dest.write_text(yaml.safe_dump(packet, sort_keys=False), encoding="utf-8")
    packet_path.unlink()
    return dest


def run_packet_expire(*, project_path: str, expire_all: bool = False, node: str | None = None) -> dict[str, Any]:
    root = resolve_project_path(project_path)
    packet_dir = root / ".forge" / "cowork" / "packets"
    archive_dir = root / ".forge" / "cowork" / "archive"
    now = datetime.now(UTC)
    moved: list[str] = []
    if not packet_dir.is_dir():
        return {"expired": moved}
    for packet_path in sorted(packet_dir.glob("*.yaml")):
        packet = _load_yaml_dict(packet_path)
        packet_node = str(packet.get("node") or "")
        if node and packet_node != node:
            continue
        if not expire_all:
            expires_at_raw = _packet_expires_at(packet)
            if not expires_at_raw:
                continue
            expires_at = datetime.fromisoformat(expires_at_raw.replace("Z", "+00:00"))
            if expires_at > now:
                continue
        moved_to = _archive_packet_file(packet_path, archive_dir, "expired")
        moved.append(str(moved_to))
    return {"expired": moved}


def run_packet_archive(*, project_path: str, packet_path: str) -> dict[str, Any]:
    root = resolve_project_path(project_path)
    src = Path(packet_path).expanduser().resolve()
    if not src.is_file():
        alt = (root / packet_path).resolve()
        if alt.is_file():
            src = alt
    if not src.is_file():
        raise PacketAssembleError(f"packet not found: {packet_path}")
    archive_dir = root / ".forge" / "cowork" / "archive"
    moved_to = _archive_packet_file(src, archive_dir, "archived")
    return {"archived": str(moved_to)}


@click.group("packet", help="Context packet lifecycle commands.")
def packet_group() -> None:
    pass


@packet_group.command("assemble")
@click.option("--node", "node", required=True)
@click.option("--type", "node_type", required=True, type=click.Choice(_NODE_TYPES))
@click.option("--domain", "domain", required=True)
@click.option("--task", "task", default="generate", show_default=True, type=click.Choice(["generate", "fix"]))
@click.option("--deps", "deps_csv", default=None, help="Comma-separated dependency node names.")
@click.option("--methods", "methods_csv", default=None, help="Comma-separated method signatures.")
@click.option("--project-path", "project_path", default=".", show_default=True)
def packet_assemble_cmd(
    node: str,
    node_type: str,
    domain: str,
    task: str,
    deps_csv: str | None,
    methods_csv: str | None,
    project_path: str,
) -> None:
    try:
        payload = run_packet_assemble(
            node=node,
            node_type=node_type,
            domain=domain,
            task=task,
            deps=_parse_csv(deps_csv),
            methods=_parse_csv(methods_csv),
            project_path=project_path,
        )
    except PacketAssembleError as exc:
        click.echo(str(exc), err=True)
        raise SystemExit(1)
    click.echo(
        "assembled packet "
        f"node={payload['node']} contracts={len(payload['contracts'])} "
        f"deps={payload['deps_resolved'] + payload['deps_planned']} files={len(payload['files_to_generate'])}",
        err=True,
    )
    click.echo(str(payload["packet_path"]))


@packet_group.command("list")
@click.option("--project-path", "project_path", default=".", show_default=True)
@response_tier_option(default="L1")
def packet_list_cmd(project_path: str, response_tier: str) -> None:
    payload = run_packet_list(project_path=project_path, response_tier=response_tier)
    rows = payload["packets"]
    if response_tier.upper() == "L1":
        click.echo(json.dumps(payload, indent=2))
        return
    click.echo("name | type | node | assembled_at | expires_at | reviewed")
    for row in rows:
        click.echo(
            f"{row['name']} | {row['type']} | {row['node']} | "
            f"{row['assembled_at']} | {row['expires_at'] or ''} | {row['reviewed']}"
        )


@packet_group.command("expire")
@click.option("--all", "expire_all", is_flag=True, default=False)
@click.option("--node", "node", default=None)
@click.option("--project-path", "project_path", default=".", show_default=True)
def packet_expire_cmd(expire_all: bool, node: str | None, project_path: str) -> None:
    payload = run_packet_expire(project_path=project_path, expire_all=expire_all, node=node)
    click.echo(json.dumps(payload, indent=2))


@packet_group.command("archive")
@click.argument("packet_path")
@click.option("--project-path", "project_path", default=".", show_default=True)
def packet_archive_cmd(packet_path: str, project_path: str) -> None:
    try:
        payload = run_packet_archive(project_path=project_path, packet_path=packet_path)
    except PacketAssembleError as exc:
        click.echo(str(exc), err=True)
        raise SystemExit(1)
    click.echo(json.dumps(payload, indent=2))
