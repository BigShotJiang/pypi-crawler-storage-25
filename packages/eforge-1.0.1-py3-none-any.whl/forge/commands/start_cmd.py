from pathlib import Path
import json
import yaml

def _write_manifest_safe(path: Path, data: dict) -> None:
    """
    Write manifest using structured construction.
    Never mutates an existing manifest dict in place.
    Always constructs the output dict explicitly.
    """
    output = {
        "kind": data.get("kind", "app"),
        "name": data["name"],
        "version": data.get("version", "0.1.0"),
        "stack": data.get("stack", "unknown"),
        "intent": data.get("intent", ""),
        "nodes": data.get("nodes", []),
        "edges": data.get("edges", []),
        "phases": data.get("phases", {"current": 1, "name": "foundation"}),
    }
    path.write_text(
        yaml.dump(output, default_flow_style=False,
                  allow_unicode=True)
    )

VOCAB_MAP = {
    "screen": "screen", "page": "screen", "view": "screen",
    "controller": "controller", "manager": "controller",
    "service": "service", "api": "service", "client": "service",
    "model": "model", "data": "model", "store": "model",
    "auth": "service", "login": "screen", "workout": "screen",
    "exercise": "model", "routine": "model", "dashboard": "screen",
}

def seed_vocabulary(sentence: str) -> dict:
    words = sentence.lower().split()
    vocab = {}
    for word in words:
        clean = word.strip(".,!?")
        if clean in VOCAB_MAP:
            vocab[clean] = VOCAB_MAP[clean]
    return vocab

def run_start(project_path: str,
                name: str | None = None,
                intent: str | None = None,
                stack: str | None = None) -> dict:
    root = Path(project_path).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    forge_dir = root / ".forge"
    forge_dir.mkdir(exist_ok=True)

    # Non-interactive if all three supplied, interactive otherwise
    if name is None:
        name = input("What is your project called? ").strip()
    if intent is None:
        intent = input("What are you building? (one sentence) ").strip()
    if stack is None:
        stack = input("Stack? (flutter / python / web / other) ").strip()

    # Manifest — preserve existing nodes if manifest already exists
    manifest_path = root / "manifest.yaml"
    if manifest_path.exists():
        existing = yaml.safe_load(manifest_path.read_text()) or {}
        existing_nodes = existing.get("nodes", [])
    else:
        existing_nodes = []

    manifest = {
        "kind": "app",
        "name": name,
        "version": "0.1.0",
        "stack": stack,
        "intent": intent,
        "nodes": existing_nodes,
        "edges": [],
        "phases": {"current": 1, "name": "foundation"},
    }
    _write_manifest_safe(manifest_path, manifest)

    # Vocabulary
    vocab = seed_vocabulary(intent)

    # Context
    context = {
        "stage": 1,
        "stage_label": "initialized",
        "project_path": str(root),
        "stack": stack,
        "last_operation": "forge_start",
        "next_required": "forge scaffold",
        "next_reason": (
            "Manifest created. Add your first node with: "
            "forge scaffold --describe '<what you want>'"
        ),
        "blockers": [],
        "user_vocabulary": vocab,
    }
    context_path = forge_dir / "context.json"
    context_path.write_text(json.dumps(context, indent=2))

    # Auto-register forge-extension projects in workspace
    if stack == "forge-extension" or manifest.get("kind") == "forge-extension":
        from forge.workspace.graph import WorkspaceGraph, WorkspaceProject
        workspace_path = WorkspaceGraph.default_path()
        ws_graph = WorkspaceGraph.load_graph(workspace_path)
        if not ws_graph.get(name):
            ws_graph.add_project(WorkspaceProject(
                id=name,
                path=root,
                depends_on=["forge"],
            ))
            ws_graph.save(workspace_path)

    return {
        "ok": True,
        "stage": 1,
        "manifest_path": str(manifest_path),
        "vocabulary_seeded": vocab,
        "next_required": context["next_required"],
        "nodes_preserved": len(existing_nodes),
    }
