from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
from collections import deque
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import click
import yaml

from forge.core.path_utils import resolve_project_path
from forge.mcp.project_status_core import build_project_status_payload
from forge.verify.diff import VerifyDiffError, run_verify_diff

_NODE_TYPES = {"screen", "controller", "service", "model", "variant", "module"}
_WORKSPACE_FILE = Path.home() / ".forge" / "workspace.yaml"


class OrientError(ValueError):
    """Raised for deterministic orient failures."""


def _load_yaml_dict(path: Path) -> dict[str, Any]:
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise OrientError(f"failed to parse yaml at {path}: {exc}") from exc
    if not isinstance(raw, dict):
        raise OrientError(f"yaml at {path} must be a mapping")
    return raw


def _resolve_stack(manifest: dict[str, Any]) -> str:
    project = manifest.get("project")
    if isinstance(project, dict):
        val = str(project.get("stack") or "").strip()
        if val:
            return val
    stack = manifest.get("stack")
    if isinstance(stack, str) and stack.strip():
        return stack.strip()
    if isinstance(stack, dict):
        for key in ("id", "name", "language"):
            val = str(stack.get(key) or "").strip()
            if val:
                return val
    app = manifest.get("app")
    if isinstance(app, dict):
        val = str(app.get("stack") or "").strip()
        if val:
            return val
    raise OrientError("manifest stack could not be resolved (expected project.stack or stack)")


def _normalize_dep_names(raw: Any) -> list[str]:
    if isinstance(raw, list):
        return [str(x).strip() for x in raw if str(x).strip()]
    return []


def _extract_declared_deps(node_row: dict[str, Any]) -> list[str]:
    out: list[str] = []
    deps = node_row.get("deps")
    if isinstance(deps, dict):
        for key in ("services", "controllers", "models"):
            out.extend(_normalize_dep_names(deps.get(key)))
    out.extend(_normalize_dep_names(node_row.get("depends_on")))
    return sorted(set(x for x in out if x))


def _interface_summary(node_row: dict[str, Any]) -> list[str]:
    interface = node_row.get("interface")
    if not isinstance(interface, dict):
        return []
    methods = interface.get("methods")
    if not isinstance(methods, list):
        return []
    out: list[str] = []
    for row in methods:
        if not isinstance(row, dict):
            continue
        name = str(row.get("name") or "").strip()
        returns = str(row.get("returns") or "").strip()
        if not name:
            continue
        out.append(f"{name}->{returns}" if returns else name)
    return out


def _lookup_manifest_node(manifest: dict[str, Any], node_name: str) -> dict[str, Any] | None:
    token = str(node_name or "").strip()
    if not token:
        return None
    modules = manifest.get("modules")
    if not isinstance(modules, list):
        return None
    for row in modules:
        if not isinstance(row, dict):
            continue
        if token in {str(row.get("name") or "").strip(), str(row.get("id") or "").strip()}:
            return row
    return None


def _lookup_planned_node(app_manifest: dict[str, Any], node_name: str) -> dict[str, Any] | None:
    token = str(node_name or "").strip()
    if not token:
        return None
    rows = app_manifest.get("nodes_planned")
    if not isinstance(rows, list):
        return None
    for row in rows:
        if not isinstance(row, dict):
            continue
        if token == str(row.get("name") or "").strip():
            return row
    return None


def _render_token(template: str, *, domain: str, name: str) -> str:
    return template.replace("{domain}", domain.lower()).replace("{name}", name)


def _extract_contract_rule(contract_entry: Any) -> str:
    if isinstance(contract_entry, dict):
        rule = contract_entry.get("rule")
        if isinstance(rule, str) and rule.strip():
            return rule.strip()
        fmt = contract_entry.get("format")
        if isinstance(fmt, str) and fmt.strip():
            return fmt.strip()
    return ""


def _topological_file_order(paths: list[str]) -> list[str]:
    nodes = sorted(set(paths))
    indegree = {n: 0 for n in nodes}
    edges: dict[str, set[str]] = {n: set() for n in nodes}
    for src in nodes:
        src_parent = str(Path(src).parent)
        for dst in nodes:
            if src == dst:
                continue
            if src_parent != "." and dst.startswith(src_parent + "/"):
                if dst not in edges[src]:
                    edges[src].add(dst)
                    indegree[dst] += 1
    q = deque(sorted([n for n in nodes if indegree[n] == 0]))
    out: list[str] = []
    while q:
        cur = q.popleft()
        out.append(cur)
        for nxt in sorted(edges[cur]):
            indegree[nxt] -= 1
            if indegree[nxt] == 0:
                q.append(nxt)
    return out if len(out) == len(nodes) else sorted(nodes)


def _packet_expires_at(packet: dict[str, Any]) -> str | None:
    freshness = packet.get("freshness")
    if not isinstance(freshness, dict):
        return None
    assembled_at = str(freshness.get("assembled_at") or "").strip()
    if not assembled_at:
        return None
    expires_after = str(freshness.get("expires_after") or "72h").strip().lower()
    try:
        assembled = datetime.fromisoformat(assembled_at.replace("Z", "+00:00"))
    except ValueError:
        return None
    if expires_after.endswith("h"):
        hours = int(expires_after[:-1] or "72")
        expires = assembled + timedelta(hours=hours)
    elif expires_after.endswith("d"):
        days = int(expires_after[:-1] or "3")
        expires = assembled + timedelta(days=days)
    else:
        return None
    return expires.astimezone(UTC).isoformat().replace("+00:00", "Z")


def _resolve_project_from_workspace() -> Path:
    if not _WORKSPACE_FILE.is_file():
        raise OrientError(
            "no project_path provided and workspace is empty — pass --project-path explicitly"
        )
    data = _load_yaml_dict(_WORKSPACE_FILE)

    def _lookup_by_id(pid: str) -> str | None:
        projects = data.get("projects")
        if isinstance(projects, dict):
            row = projects.get(pid)
            if isinstance(row, dict) and row.get("path"):
                return str(row["path"])
        workspaces = data.get("workspaces")
        if isinstance(workspaces, list):
            for row in workspaces:
                if not isinstance(row, dict):
                    continue
                rid = str(row.get("id") or row.get("name") or "").strip()
                if rid == pid and row.get("path"):
                    return str(row["path"])
        return None

    marker_keys = (
        "active_project",
        "active_project_id",
        "active",
        "current_project",
        "most_recent_project",
        "recent_project",
        "last_project",
    )
    for key in marker_keys:
        val = data.get(key)
        if isinstance(val, str) and val.strip():
            hit = _lookup_by_id(val.strip())
            if hit:
                return Path(hit).expanduser().resolve()
    defaults = data.get("defaults")
    if isinstance(defaults, dict):
        for key in marker_keys:
            val = defaults.get(key)
            if isinstance(val, str) and val.strip():
                hit = _lookup_by_id(val.strip())
                if hit:
                    return Path(hit).expanduser().resolve()
        for path_key in ("last_project_path", "recent_project_path"):
            val = defaults.get(path_key)
            if isinstance(val, str) and val.strip():
                return Path(val).expanduser().resolve()

    projects = data.get("projects")
    if isinstance(projects, dict) and projects:
        first_row = next(iter(projects.values()))
        if isinstance(first_row, dict) and first_row.get("path"):
            return Path(str(first_row["path"])).expanduser().resolve()
    workspaces = data.get("workspaces")
    if isinstance(workspaces, list) and workspaces:
        first_row = workspaces[0]
        if isinstance(first_row, dict) and first_row.get("path"):
            return Path(str(first_row["path"])).expanduser().resolve()

    raise OrientError(
        "no project_path provided and workspace is empty — pass --project-path explicitly"
    )


def _resolve_project_path(project_path: str | None) -> Path:
    if project_path and str(project_path).strip():
        return resolve_project_path(project_path)
    # Try cwd first before workspace
    from forge.core.path_utils import resolve_project_path as _resolve

    try:
        return _resolve(None)
    except Exception:
        pass
    return _resolve_project_from_workspace()


def _parse_next_nodes_from_diff(diff_text: str) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    current_domain = ""
    for line in diff_text.splitlines():
        domain_match = re.match(r"^([A-Z0-9_]+)\s+\(", line.strip())
        if domain_match:
            current_domain = domain_match.group(1)
            continue
        node_match = re.match(r"^\s*✗\s+([A-Za-z0-9_./-]+)\s+([a-z-]+)\s+← next\s*$", line)
        if node_match and current_domain:
            out.append(
                {
                    "domain": current_domain,
                    "node": node_match.group(1),
                    "type": node_match.group(2),
                }
            )
    return out


def run_engine_session_orient(
    *, project_path: str | None, response_tier: str = "L1"
) -> dict[str, Any]:
    """Session orient via ForgeEngine (:func:`~forge.engine.engine.ForgeEngine.orient` → ``build_bundle``).

    Applies the same field shaping as MCP ``forge_orient`` (``_orientation_from_bundle``),
    including ``_workspace`` / ``intent_coverage_compact``.
    """

    root = _resolve_project_path(project_path)

    # Import here to avoid heavyweight MCP stack at CLI import time.
    from forge.mcp.handlers.core_tools import _orientation_from_bundle
    from forge.mcp.thin_core import execute_orient

    bundle = execute_orient({"project_path": str(root), "response_tier": response_tier.strip()})
    return _orientation_from_bundle(bundle, node=None, response_tier=response_tier.strip())


def run_session_orient(*, project_path: str | None) -> dict[str, Any]:
    """Legacy session summary via project-status + structural verify (+ optional verify-diff).

    Prefer :func:`run_engine_session_orient` for CLI / MCP-aligned orient output (Sprint 9+).
    """
    root = _resolve_project_path(project_path)
    
    # Use component-enhanced project status
    try:
        from forge.mcp.component_enhanced_project_status_core import build_project_status_payload_enhanced
        status_entity = build_project_status_payload_enhanced(
            project_path=str(root),
            response_tier="L1",
            server_start_time=None
        )
        
        # Convert to dict for compatibility
        status = status_entity.to_dict()
    except ImportError:
        # Fallback to original if enhanced version not available
        from forge.mcp.project_status_core import build_project_status_payload
        status = build_project_status_payload(
            project_path=str(root),
            response_tier="L1",
            server_start_time=None
        )
    
    diff_note = None
    next_nodes: list[dict[str, str]] = []
    try:
        diff_out, _diff_code = run_verify_diff(project_root=root, mode="plan", domain=None, verbose=True)
        next_nodes = _parse_next_nodes_from_diff(diff_out)
    except VerifyDiffError:
        diff_note = "no app manifest — diff plan unavailable"
    verify = _run_structural_verify(root)
    exit_code = int(verify.get("exit_code") or 0)
    if exit_code == 0:
        structural_health = "clean"
    elif exit_code == 1:
        structural_health = "warnings"
    else:
        structural_health = "failures"

    workflow: list[str] = []
    if next_nodes:
        workflow.append(f"forge orient --node {next_nodes[0]['node']} to scaffold next node")
    packets = status.get("packets") if isinstance(status.get("packets"), dict) else {}
    if int(packets.get("pending") or 0) > 0:
        workflow.append("forge verify --packet ... to validate pending packet")
    if structural_health != "clean":
        workflow.append("forge verify to resolve structural findings before generation")
    if not workflow:
        workflow.append("forge verify --diff plan to confirm no remaining planned nodes")

    payload = {
        "project": status.get("project"),
        "phase": status.get("phase"),
        "stack": status.get("stack"),
        "current_task": status.get("current_task"),
        "blocker": status.get("blocker"),
        "next_action": status.get("next_action"),
        "warnings": list(status.get("warnings") or []),
        "packets": {
            "pending": int(packets.get("pending") or 0),
            "expired": int(packets.get("expired") or 0),
            "failed": int(packets.get("failed") or 0),
        },
        "structural_health": structural_health,
        "next_nodes": next_nodes,
        "suggested_workflow": workflow,
    }
    if diff_note:
        payload["warnings"].append(diff_note)
    if exit_code != 0:
        payload["verify_failures"] = verify.get("failures") or []
        payload["verify_exit_code"] = exit_code
    return payload


def _render_orient_human(result: dict[str, Any], project_path: Path) -> None:
    """Human-readable orient output."""
    name = (
        result.get("project_name")
        or result.get("project")
        or project_path.name
    )
    click.echo(f"\n✦ eforge orient — {name}\n")

    stack = result.get("stack", "unknown")
    phase = result.get("phase", "?")
    health = result.get("structural_health", "unknown")
    nodes = result.get("graph_node_count", 0)

    health_icon = {
        "clean": "✓",
        "failures": "✗",
        "warnings": "⚠",
        "unknown": "?",
    }.get(str(health).lower(), "?")

    click.echo(f"  stack    : {stack}")
    click.echo(f"  phase    : {phase}")
    click.echo(f"  health   : {health_icon} {health}")
    click.echo(f"  nodes    : {nodes}")

    domains = result.get("domains", [])
    if domains:
        dom_str = ", ".join(str(d) for d in domains[:6])
        if len(domains) > 6:
            dom_str += f" (+{len(domains) - 6})"
        click.echo(f"  domains  : {dom_str}")

    scores = result.get("health_scores") or result.get("health_score") or result.get("metrics") or {}
    if isinstance(scores, dict) and scores:
        click.echo("")
        click.echo("  Health scores:")

        def _pick_score(*keys: str) -> float | None:
            for key in keys:
                val = scores.get(key)
                if val is None:
                    continue
                try:
                    return float(val)
                except (TypeError, ValueError):
                    continue
            return None

        def _score_line(label: str, val: float | None, desc: str) -> None:
            if val is None:
                return
            pct = f"{val:.0f}%"
            click.echo(f"    {label:<4} {pct:>5}  {desc}")

        _score_line("ADI", _pick_score("adi_score", "adi"), "implementation coverage")
        _score_line("BRC", _pick_score("brc_score", "brc"), "blast radius coverage")
        _score_line("IDR", _pick_score("idr_score", "idr"), "intent declaration rate")

    warnings = result.get("warnings", [])
    blocker = result.get("blocker")

    click.echo("")
    if blocker:
        click.echo(f"  ⚠ Blocker: {blocker}")
    elif warnings:
        for w in warnings[:3]:
            click.echo(f"  ⚠ {w}")
    else:
        click.echo("  No warnings.")

    click.echo("")
    click.echo("  Next:")
    click.echo("    forge discover   — find undeclared files")
    click.echo("    forge verify     — check structural parity")
    click.echo("    forge inspect <node> — inspect a node")
    click.echo("")


def _run_structural_verify(root: Path) -> dict[str, Any]:
    cmd = [
        sys.executable,
        "-m",
        "forge.cli_main",
        "verify",
        "--project-path",
        str(root),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    out = proc.stdout or ""
    failures: list[str] = []
    capture = False
    for line in out.splitlines():
        if line.strip().startswith("propagation failures"):
            capture = True
            continue
        if capture:
            if line.strip().startswith("warnings") or line.strip().startswith("clean"):
                break
            if line.strip():
                failures.append(line.strip())
    return {"exit_code": int(proc.returncode), "failures": failures}


def run_scaffold_orient(*, node: str, project_path: str | None) -> dict[str, Any]:
    node_name = str(node or "").strip()
    if not node_name:
        raise OrientError("node is required for scaffold mode")
    root = _resolve_project_path(project_path)
    manifest_path = root / ".forge" / "manifest.yaml"
    if not manifest_path.is_file():
        raise OrientError(f"manifest not found: {manifest_path}")
    manifest = _load_yaml_dict(manifest_path)

    manifest_node = _lookup_manifest_node(manifest, node_name)
    app_manifest_path = root / ".forge" / "app.manifest.yaml"
    app_manifest = _load_yaml_dict(app_manifest_path) if app_manifest_path.is_file() else {}
    planned_node = _lookup_planned_node(app_manifest, node_name) if manifest_node is None else None
    if manifest_node is None and planned_node is None:
        raise OrientError(
            f"Node '{node_name}' not found in manifest or nodes_planned.\n"
            f"Add it first:\n"
            f"forge manifest append --node {node_name} --type <type> --domain <domain>\n"
            f"or add to .forge/app.manifest.yaml nodes_planned"
        )

    source = manifest_node if manifest_node is not None else planned_node
    assert isinstance(source, dict)
    node_type = str(source.get("kind") or source.get("type") or "").strip().lower()
    domain = str(source.get("domain") or "").strip().upper()
    if node_type not in _NODE_TYPES or not domain:
        raise OrientError(
            f"Node '{node_name}' is missing mechanical type/domain in manifest metadata; cannot proceed"
        )
    status = "present" if manifest_node is not None else "planned"

    stack = _resolve_stack(manifest)
    glove_path = root / ".forge" / "gloves" / f"{stack}.glove.yaml"
    if not glove_path.is_file():
        raise OrientError(f"glove not found: {glove_path}")
    glove = _load_yaml_dict(glove_path)
    glove_node_types = glove.get("node_types")
    if not isinstance(glove_node_types, dict) or node_type not in glove_node_types:
        raise OrientError(f"glove contract violated: node_type '{node_type}' not in glove.node_types")
    node_spec = glove_node_types[node_type]
    if not isinstance(node_spec, dict):
        raise OrientError(f"invalid glove node spec for node_type '{node_type}'")

    contract_map = glove.get("contracts")
    if not isinstance(contract_map, dict):
        raise OrientError("glove contract violated: glove.contracts missing")
    contract_keys = [str(x).strip() for x in (node_spec.get("required_contracts") or []) if str(x).strip()]
    contracts: list[dict[str, str]] = []
    for key in contract_keys:
        entry = contract_map.get(key)
        if not isinstance(entry, dict):
            continue
        if entry.get("verifiable") is not True:
            continue
        rule = _extract_contract_rule(entry)
        if not rule:
            continue
        contracts.append({"key": key, "rule": rule})

    declared_deps = _extract_declared_deps(source)
    present: list[dict[str, Any]] = []
    planned: list[dict[str, Any]] = []
    missing: list[dict[str, str]] = []
    gaps: list[str] = []
    deps_by_kind = {"services": [], "controllers": [], "models": []}
    for dep in declared_deps:
        hit_manifest = _lookup_manifest_node(manifest, dep)
        if hit_manifest is not None:
            dep_type = str(hit_manifest.get("kind") or hit_manifest.get("type") or "").strip().lower() or "module"
            iface = _interface_summary(hit_manifest)
            present.append(
                {
                    "name": dep,
                    "type": dep_type,
                    "interface": iface,
                }
            )
            if dep_type == "service":
                deps_by_kind["services"].append(dep)
            elif dep_type == "controller":
                deps_by_kind["controllers"].append(dep)
            elif dep_type == "model":
                deps_by_kind["models"].append(dep)
            continue
        hit_planned = _lookup_planned_node(app_manifest, dep)
        if hit_planned is not None:
            planned.append(
                {
                    "name": dep,
                    "type": str(hit_planned.get("type") or "").strip().lower() or "unknown",
                }
            )
            continue
        missing.append({"name": dep})
        gaps.append(f"dep {dep} is missing from manifest and nodes_planned")

    output_paths = [str(x) for x in (node_spec.get("output_paths") or []) if str(x).strip()]
    test_output_paths = [str(x) for x in (node_spec.get("test_output_paths") or []) if str(x).strip()]
    outputs = [_render_token(x, domain=domain, name=node_name) for x in output_paths]
    outputs.extend(_render_token(x, domain=domain, name=node_name) for x in test_output_paths)
    files = [
        {
            "path": p,
            "template": f"{node_type}.default",
            "vars": {"name": node_name, "domain": domain, "node_type": node_type},
            "action": "create",
        }
        for p in outputs
    ]

    interface_hint = ""
    source_iface = source.get("interface")
    if isinstance(source_iface, dict):
        methods = source_iface.get("methods")
        if isinstance(methods, list) and methods:
            interface_hint = ",".join(
                [str(row.get("name") or "").strip() for row in methods if isinstance(row, dict)]
            )
    if not interface_hint:
        interface_hint = f"{node_name}Interface"
    class_hint = node_name

    wiring_rows = node_spec.get("wiring") if isinstance(node_spec.get("wiring"), list) else []
    wiring: list[dict[str, Any]] = []
    for row in wiring_rows:
        if not isinstance(row, dict):
            continue
        file_path = _render_token(str(row.get("file") or ""), domain=domain, name=node_name)
        pattern = str(row.get("pattern") or "").strip()
        vars_map = row.get("vars") if isinstance(row.get("vars"), dict) else {}
        rendered_vars: dict[str, Any] = {}
        for k, v in vars_map.items():
            if isinstance(v, str):
                rendered_vars[str(k)] = (
                    v.replace("{class}", class_hint).replace("{interface}", interface_hint)
                )
            else:
                rendered_vars[str(k)] = v
        if file_path and pattern:
            wiring.append({"file": file_path, "pattern": pattern, "vars": rendered_vars})

    graph_hash = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    glove_version = str(glove.get("version") or "1.0.0").strip()
    assembled_at = datetime.now(UTC).isoformat().replace("+00:00", "Z")
    packet = {
        "type": "generate",
        "node": node_name,
        "domain": domain,
        "stack_glove": stack,
        "glove_version": glove_version,
        "freshness": {
            "assembled_at": assembled_at,
            "graph_hash": graph_hash,
            "glove_version": glove_version,
            "expires_after": "72h",
        },
        "review": {
            "assembled_by": "forge-orient",
            "reviewed_by": None,
            "reviewed_at": None,
            "notes": "",
        },
        "constraints": {
            "max_nodes_per_packet": 1,
            "max_methods_per_packet": 8,
            "max_wiring_targets": 3,
        },
        "logging": {"domain": domain, "component": node_name},
        "inputs": {"deps": deps_by_kind},
        "interface": {"methods": source_iface.get("methods") if isinstance(source_iface, dict) else []},
        "contracts": [c["key"] for c in contracts],
        "outputs": {"files": files},
        "manifest_patch": [{"op": "add", "node_id": node_name, "type": node_type, "domain": domain}],
        "wiring": wiring,
        "slot_order": _topological_file_order([str(x["path"]) for x in files]),
    }
    packet_dir = root / ".forge" / "cowork" / "packets"
    packet_dir.mkdir(parents=True, exist_ok=True)
    packet_path = packet_dir / f"generate__{node_name}.yaml"
    packet_path.write_text(yaml.safe_dump(packet, sort_keys=False), encoding="utf-8")
    ready = len(gaps) == 0
    return {
        "node": node_name,
        "type": node_type,
        "domain": domain,
        "status": status,
        "glove": {"id": stack, "version": glove_version},
        "contracts": contracts,
        "deps": {
            "present": present,
            "planned": planned,
            "missing": missing,
        },
        "outputs": [str(x["path"]) for x in files],
        "wiring": wiring,
        "slot_order": packet["slot_order"],
        "packet_path": str(packet_path),
        "graph_hash": graph_hash,
        "expires_at": _packet_expires_at(packet),
        "gaps": gaps,
        "ready_to_generate": ready,
    }


@click.command("orient")
@click.option("--node", "node", default=None)
@click.option("--project-path", "project_path", default=None)
@click.option("--response-tier", "response_tier", default="L1", show_default=True)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    default=False,
    help="Output raw JSON (default: human-readable session summary).",
)
def orient_cmd(
    node: str | None,
    project_path: str | None,
    response_tier: str,
    output_json: bool,
) -> None:
    """Understand your project's current state.

    Shows stack, phase, health scores, domains, warnings, and next steps.
    Default output is human-readable. Use --json for programmatic access.
    Scaffold mode (--node) always emits JSON.
    """
    try:
        root = _resolve_project_path(project_path)
        if node and str(node).strip():
            payload = run_scaffold_orient(node=node, project_path=project_path)
            click.echo(json.dumps(payload, indent=2))
            return
        payload = run_engine_session_orient(
            project_path=project_path, response_tier=response_tier
        )
    except OrientError as exc:
        click.echo(str(exc), err=True)
        raise SystemExit(1)
    if output_json:
        click.echo(json.dumps(payload, indent=2))
        return
    _render_orient_human(payload, root)
