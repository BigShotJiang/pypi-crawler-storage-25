from __future__ import annotations

from dataclasses import dataclass
from io import StringIO
from pathlib import Path
from typing import Any

import click
from rich.console import Console
from rich.syntax import Syntax

from forge.commands._shared_options import response_tier_option
from forge.core.discovery import discover_projects, get_projects_root
from forge.core.path_utils import resolve_project_path


ALLOWED_TOP_LEVEL = {"app", "ui_lab", "features", "debug", "ui", "monetization"}

MCP_CONFIG_FILE_TARGETS = frozenset({"config", "manifest", "workspace"})


def resolve_mcp_yaml_file(project_root: Path, file: str) -> Path:
    """Resolve YAML path for MCP ``forge_config_get`` / ``forge_config_set`` (*file=*)."""
    key = (file or "config").strip().lower()
    if key not in MCP_CONFIG_FILE_TARGETS:
        raise ValueError(f"file must be one of {sorted(MCP_CONFIG_FILE_TARGETS)}")
    root = project_root.expanduser().resolve()
    if key == "config":
        cfg = locate_app_config(root)
        if cfg is None:
            raise FileNotFoundError(f"app_config.yaml not found under {root}")
        return cfg
    if key == "manifest":
        p = root / ".forge" / "manifest.yaml"
        if not p.is_file():
            raise FileNotFoundError(f".forge/manifest.yaml not found under {root}")
        return p
    ws = Path.home() / ".forge" / "workspace.yaml"
    if not ws.is_file():
        raise FileNotFoundError(f"workspace.yaml not found at {ws}")
    return ws


def _yaml() -> Any:
    try:
        from ruamel.yaml import YAML  # imported lazily so non-config commands don't require it at import time

        y = YAML()
        y.preserve_quotes = True
        return y
    except Exception:
        import yaml as _pyyaml

        class _CompatYaml:
            def load(self, stream: Any) -> Any:
                text = stream.read() if hasattr(stream, "read") else str(stream)
                return _pyyaml.safe_load(text) or {}

            def dump(self, data: Any, stream: Any) -> None:
                _pyyaml.safe_dump(data, stream, sort_keys=False)

        return _CompatYaml()


def resolve_project_root(project: str) -> Path:
    p = resolve_project_path(project)
    if p.exists() and p.is_dir():
        return p
    for prj in discover_projects(get_projects_root()):
        if prj.name.lower() == project.lower():
            resolved = resolve_project_path(prj.path)
            if resolved.exists() and resolved.is_dir():
                return resolved
    candidate = resolve_project_path(get_projects_root() / project)
    if candidate.exists() and candidate.is_dir():
        return candidate
    raise click.ClickException(f"project_path not found or not a directory: {p}")


def locate_app_config(project_root: Path) -> Path | None:
    for c in (
        project_root / "assets" / "app_config.yaml",
        project_root / "app_config.yaml",
        project_root / "config" / "app_config.yaml",
    ):
        if c.exists():
            return c
    return None


def _get_key(data: Any, key: str) -> tuple[bool, Any]:
    cur = data
    for part in key.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return False, None
        cur = cur[part]
    return True, cur


def _set_key(data: Any, key: str, value: Any) -> tuple[Any, Any]:
    parts = [p for p in key.split(".") if p]
    cur = data
    for part in parts[:-1]:
        if part not in cur or not isinstance(cur[part], dict):
            cur[part] = {}
        cur = cur[part]
    old = cur.get(parts[-1]) if isinstance(cur, dict) else None
    if isinstance(old, bool):
        if isinstance(value, str):
            v = value.strip().lower()
            value = v in ("1", "true", "yes", "on")
    elif isinstance(old, int) and isinstance(value, str) and value.strip().isdigit():
        value = int(value.strip())
    cur[parts[-1]] = value
    return old, data


def read_config(path: Path) -> Any:
    y = _yaml()
    with path.open("r", encoding="utf-8") as f:
        return y.load(f) or {}


def write_config(path: Path, data: Any) -> None:
    y = _yaml()
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    leading_comments = []
    for line in existing.splitlines():
        if line.strip().startswith("#"):
            leading_comments.append(line)
        elif line.strip() == "":
            if leading_comments:
                leading_comments.append(line)
        else:
            break
    with path.open("w", encoding="utf-8") as f:
        if leading_comments:
            f.write("\n".join(leading_comments).rstrip() + "\n")
        y.dump(data, f)


@click.group("config")
def config_group() -> None:
    """Read/write app_config.yaml."""


@config_group.command("get")
@click.argument("project")
@click.argument("key")
@click.option("--format", "fmt", type=click.Choice(["plain", "json"]), default="plain")
@response_tier_option(default="L0")
def config_get(project: str, key: str, fmt: str, response_tier: str) -> None:
    _ = response_tier
    root = resolve_project_root(project)
    cfg = locate_app_config(root)
    if cfg is None:
        click.echo(f"app_config.yaml not found under {root}")
        raise SystemExit(1)
    data = read_config(cfg)
    ok, value = _get_key(data, key)
    if not ok:
        click.echo("Key not found")
        raise SystemExit(1)
    if fmt == "json":
        import json

        click.echo(json.dumps({key: value}))
    else:
        click.echo(value)


@config_group.command("set")
@click.argument("project")
@click.argument("key")
@click.argument("value")
@click.option("--dry-run", is_flag=True, default=False)
@click.option("--rebuild", is_flag=True, default=False)
def config_set(project: str, key: str, value: str, dry_run: bool, rebuild: bool) -> None:
    root = resolve_project_root(project)
    cfg = locate_app_config(root)
    if cfg is None:
        click.echo(f"app_config.yaml not found under {root}")
        raise SystemExit(1)
    data = read_config(cfg)
    old, next_data = _set_key(data, key, value)
    if dry_run:
        click.echo(f"[dry-run] would set {key}: {old} -> {value} ({cfg})")
        raise SystemExit(0)
    write_config(cfg, next_data)
    ok, newv = _get_key(next_data, key)
    click.echo(f"✓ Set {key} = {newv if ok else value}")
    click.echo(f"file: {cfg}")
    if rebuild:
        import subprocess

        subprocess.run(["python3", "-m", "forge.cli", "board", "--rebuild"], check=False)


@config_group.command("validate")
@click.argument("project")
def config_validate(project: str) -> None:
    root = resolve_project_root(project)
    cfg = locate_app_config(root)
    if cfg is None:
        click.echo("✗ FAIL app_config.yaml missing")
        raise SystemExit(2)
    checks: list[tuple[str, str, str]] = []
    try:
        data = read_config(cfg)
        checks.append(("yaml", "PASS", "Valid YAML"))
    except Exception as exc:
        checks.append(("yaml", "FAIL", f"Invalid YAML: {exc}"))
        for _id, status, msg in checks:
            click.echo(f"{'✓' if status=='PASS' else '✗'} {status} {_id}: {msg}")
        raise SystemExit(2)
    required = [
        "app.name",
        "app.version",
        "ui_lab.active_variants",
        "features",
        "debug",
        "ui",
        "monetization",
    ]
    warn = False
    fail = False
    for k in required:
        ok, _ = _get_key(data, k)
        if ok:
            checks.append((k, "PASS", "present"))
        else:
            checks.append((k, "WARN", "missing"))
            warn = True
    unknown = [k for k in data.keys() if k not in ALLOWED_TOP_LEVEL] if isinstance(data, dict) else []
    if unknown:
        checks.append(("top_level_keys", "WARN", f"unknown keys: {', '.join(unknown)}"))
        warn = True
    for _id, status, msg in checks:
        icon = "✓" if status == "PASS" else ("⚠" if status == "WARN" else "✗")
        click.echo(f"{icon} {status} {_id}: {msg}")
    if fail:
        raise SystemExit(2)
    if warn:
        raise SystemExit(1)
    raise SystemExit(0)


@config_group.command("diff")
@click.argument("project")
@click.option("--since", default=None)
def config_diff(project: str, since: str | None) -> None:
    import subprocess

    root = resolve_project_root(project)
    cfg = locate_app_config(root)
    if cfg is None:
        click.echo(f"app_config.yaml not found under {root}")
        raise SystemExit(1)
    if since:
        rel = str(cfg.relative_to(root))
        res = subprocess.run(
            ["git", "-C", str(root), "diff", since, "--", rel],
            capture_output=True,
            text=True,
            check=False,
        )
        click.echo(res.stdout.strip())
        raise SystemExit(0 if res.returncode == 0 else 1)
    data = read_config(cfg)
    click.echo(f"Loaded {cfg}")
    click.echo(str(sorted(data.keys())) if isinstance(data, dict) else "{}")


@config_group.command("reset")
@click.argument("project")
@click.argument("section")
@click.option("--force", is_flag=True, default=False)
def config_reset(project: str, section: str, force: bool) -> None:
    root = resolve_project_root(project)
    cfg = locate_app_config(root)
    if cfg is None:
        click.echo(f"app_config.yaml not found under {root}")
        raise SystemExit(1)
    if not force and not click.confirm(f"Reset section '{section}'?"):
        raise SystemExit(1)
    data = read_config(cfg)
    if isinstance(data, dict):
        data[section] = {}
    write_config(cfg, data)
    click.echo(f"Reset section: {section}")


@config_group.command("show")
@click.argument("project")
@click.option("--section", default=None)
def config_show(project: str, section: str | None) -> None:
    root = resolve_project_root(project)
    cfg = locate_app_config(root)
    if cfg is None:
        click.echo(f"app_config.yaml not found under {root}")
        raise SystemExit(1)
    data = read_config(cfg)
    if section:
        ok, val = _get_key(data, section)
        if not ok:
            click.echo("Key not found")
            raise SystemExit(1)
        data = val
    y = _yaml()
    buf = StringIO()
    y.dump(data, buf)
    Console().print(Syntax(buf.getvalue(), "yaml", theme="ansi_dark"))
