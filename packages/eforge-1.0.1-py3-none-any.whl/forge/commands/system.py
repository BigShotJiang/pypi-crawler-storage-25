"""
Forge System Commands

Comprehensive system health, diagnostics, and recovery for Forge projects.
Modular design with intuitive sub-commands for different operations.
"""

from __future__ import annotations

import click
from pathlib import Path
from typing import Optional

from forge.core.reality_validator import RealityValidator
from forge.tools.manifest.graph import build_manifest_graph
from forge.core.execution_graph import ExecutionGraph, get_execution_manager
from forge.core.contract_graph import ContractGraph
from forge.commands.doctor import doctor_cmd, check_forge_install, check_all_manifests
from forge.core.manifest import ManifestParser
from forge.core.graph_health_metrics import GraphHealthAnalyzer


@click.group()
def system():
    """
    System health, diagnostics, and recovery for Forge projects.
    
    This command group provides comprehensive system analysis capabilities:
    - Health checks and validation
    - Reality validation with graph analysis  
    - Forge installation diagnostics
    - Recovery and repair operations
    
    Can be run against any Forge project, including Forge itself.
    
    Examples:
        forge system health          # Basic health check
        forge system reality         # Reality validation
        forge system doctor          # Forge installation check
        forge system recover         # Recovery operations
        forge system graph           # Graph analysis
    """
    pass


@system.command()
@click.option("--project-path", "-p", type=click.Path(exists=True), help="Project root path")
@click.option("--fix", "-f", is_flag=True, help="Attempt to fix issues automatically")
@click.option("--verbose", "-v", is_flag=True, help="Verbose output")
@click.option("--graph-based", "-g", is_flag=True, help="Use graph-based metrics instead of penalty system")
def health(project_path: Optional[str], fix: bool, verbose: bool, graph_based: bool) -> None:
    """
    Basic system health check.
    
    Validates manifest structure, basic project integrity, and provides
    a quick health assessment. This is the fastest and most lightweight
    system check.
    
    Examples:
        forge system health
        forge system health --fix
        forge system health -p /path/to/project --verbose
    """
    
    # Determine project path
    if project_path:
        project_root = Path(project_path).resolve()
    else:
        from forge.core.workspace import load_workspace, _projects_as_list
        workspace = load_workspace()
        projects = _projects_as_list(workspace)
        if not projects:
            click.echo("❌ No projects found. Use --project-path to specify a project.")
            return
        project_root = Path(projects[0].get("path", ".")).resolve()
    
    click.echo(f"🏥 System Health Check")
    click.echo(f"📁 Project: {project_root}")
    click.echo("=" * 40)
    
    # Check manifest exists and is valid
    manifest_path = project_root / ".forge" / "manifest.yaml"
    if not manifest_path.exists():
        click.echo("❌ No .forge/manifest.yaml found")
        if fix:
            click.echo("🔧 Creating basic manifest structure...")
            manifest_path.parent.mkdir(exist_ok=True)
            manifest_path.write_text("""
# Forge Manifest
version: "1.0"
modules: []
""")
            click.echo("✅ Created basic manifest")
    else:
        try:
            parser = ManifestParser(manifest_path)
            result = parser.parse()
            if result.ok:
                click.echo("✅ Manifest valid")
            else:
                click.echo(f"❌ Manifest invalid: {result.error}")
                if fix:
                    click.echo("🔧 Attempting manifest repair...")
                    try:
                        # Create basic manifest structure
                        basic_content = """# Forge Manifest
version: "1.0"
modules: []
"""
                        manifest_path.write_text(basic_content)
                        click.echo("✅ Manifest repaired")
                    except Exception as e:
                        click.echo(f"❌ Repair failed: {e}")
        except Exception as e:
            click.echo(f"❌ Health check failed: {e}")
    
    # Basic project structure check
    click.echo("\n📂 Project Structure:")
    forge_dir = project_root / ".forge"
    if forge_dir.exists():
        click.echo("✅ .forge directory exists")
    else:
        click.echo("⚠️  .forge directory missing")
    
    # Graph-based metrics if requested
    if graph_based:
        click.echo("\n📊 Graph-Based Health Metrics:")
        try:
            analyzer = GraphHealthAnalyzer(project_root)
            health_result = analyzer.analyze_overall_health()
            click.echo(f"📈 Overall Health: {health_result.overall_health:.1%}")
            click.echo(f"📝 Score Note: {health_result.score_note}")
            
            click.echo("\n🔍 Layer-Aware Metrics:")
            for metric in health_result.metrics:
                status_emoji = "✅" if metric.status == "measured" else ("⚠️" if metric.status == "unavailable" else "❌")
                click.echo(f"  {status_emoji} {metric.metric_type.value}: {metric.display_score} [{metric.status}]")
                
                # Show mapper details for execution coverage
                if metric.metric_type.value == "execution_trace_coverage" and hasattr(metric, 'details'):
                    details = metric.details or {}
                    mapper = details.get('mapper', '')
                    if mapper:
                        click.echo(f"    via {mapper}")
                
                if verbose and metric.details:
                    for key, value in metric.details.items():
                        if key not in ['mapper']:  # Skip mapper as it's shown above
                            click.echo(f"    {key}: {value}")
                
        except Exception as e:
            click.echo(f"❌ Graph-based analysis failed: {e}")
            if verbose:
                import traceback
                click.echo(traceback.format_exc())
    else:
        # Quick module count
        try:
            manifest_graph = build_manifest_graph(project_root)
            click.echo(f"📊 Manifest nodes: {len(manifest_graph.nodes)}")
        except Exception as e:
            click.echo(f"⚠️  Could not read manifest: {e}")
    
    click.echo("\n🏁 Health check complete")


@system.command()
@click.option("--project-path", "-p", type=click.Path(exists=True), help="Project root path")
@click.option("--deep-scan", "-d", is_flag=True, help="Perform deep analysis with all graphs")
@click.option("--verbose", "-v", is_flag=True, help="Verbose output with discrepancy details")
@click.option("--graph-based", "-g", is_flag=True, help="Use graph-based metrics instead of penalty system")
def reality(project_path: Optional[str], deep_scan: bool, verbose: bool, graph_based: bool) -> None:
    """
    Reality validation with graph analysis.
    
    Validates project reality against declared dependencies using
    comprehensive graph analysis. Compares manifest, execution,
    and contract graphs to identify discrepancies.
    
    Examples:
        forge system reality
        forge system reality --deep-scan
        forge system reality -p /path/to/project --verbose
    """
    
    # Determine project path
    if project_path:
        project_root = Path(project_path).resolve()
    else:
        from forge.core.workspace import load_workspace, _projects_as_list
        workspace = load_workspace()
        projects = _projects_as_list(workspace)
        if not projects:
            click.echo("❌ No projects found. Use --project-path to specify a project.")
            return
        project_root = Path(projects[0].get("path", ".")).resolve()
    
    click.echo(f"🔍 Reality Validation")
    click.echo(f"📁 Project: {project_root}")
    click.echo("=" * 40)
    
    try:
        # Build all graphs
        click.echo("📊 Building graphs...")
        manifest_graph = build_manifest_graph(project_root)
        click.echo(f"✅ Manifest graph: {len(manifest_graph.nodes)} nodes, {len(manifest_graph.edges)} edges")
        
        execution_manager = get_execution_manager(project_root)
        execution_graph = ExecutionGraph()
        click.echo(f"✅ Execution graph initialized")
        
        contract_graph = ContractGraph()
        click.echo(f"✅ Contract graph initialized")
        
        # Reality validation with graph-based metrics if requested
        if graph_based:
            click.echo("\n📊 Graph-Based Reality Analysis:")
            try:
                analyzer = GraphHealthAnalyzer(project_root)
                health_result = analyzer.analyze_overall_health()
                click.echo(f"📈 Graph Health: {health_result.overall_health:.1%}")
                click.echo(f"📝 Score Note: {health_result.score_note}")
                click.echo(f"🔍 Metrics Analyzed: {len(health_result.metrics)}")
                
                if verbose:
                    click.echo("\n🔍 Detailed Metrics:")
                    for metric in health_result.metrics:
                        status_emoji = "✅" if metric.status == "measured" else ("⚠️" if metric.status == "unavailable" else "❌")
                        click.echo(f"  {status_emoji} {metric.metric_type.value}: {metric.display_score} [{metric.status}]")
                        
                        # Show mapper details for execution coverage
                        if metric.metric_type.value == "execution_trace_coverage" and hasattr(metric, 'details'):
                            details = metric.details or {}
                            mapper = details.get('mapper', '')
                            if mapper:
                                click.echo(f"    via {mapper}")
                    
                    if health_result.recommendations:
                        click.echo("\n💡 Recommendations:")
                        for rec in health_result.recommendations:
                            click.echo(f"  • {rec}")
            except Exception as e:
                click.echo(f"❌ Graph-based analysis failed: {e}")
                if verbose:
                    import traceback
                    click.echo(traceback.format_exc())
        else:
            # Traditional reality validation
            click.echo("\n🔍 Running reality validation...")
            validator = RealityValidator(project_root)
            result = validator.validate_project()
            
            click.echo(f"📈 Health Score: {result.health_score:.1%}")
            click.echo(f"🔍 Discrepancies: {len(result.discrepancies)}")
            
            # Show discrepancy breakdown
            if result.discrepancies:
                severity_counts = {}
                for disc in result.discrepancies:
                    severity_counts[disc.severity] = severity_counts.get(disc.severity, 0) + 1
                
                click.echo("\n📊 Discrepancy Breakdown:")
                for severity, count in severity_counts.items():
                    click.echo(f"  {severity}: {count}")
                
                # Show details if verbose
                if verbose:
                    click.echo("\n🔍 Discrepancy Details:")
                    for i, disc in enumerate(result.discrepancies[:5]):  # Show first 5
                        click.echo(f"  {i+1}. {disc.severity}: {disc.description[:80]}...")
                    if len(result.discrepancies) > 5:
                        click.echo(f"  ... and {len(result.discrepancies) - 5} more")
        
        # Deep scan analysis
        if deep_scan:
            click.echo("\n🔬 Deep Scan Analysis:")
            if graph_based:
                # Show detailed graph metrics for deep scan
                try:
                    analyzer = GraphHealthAnalyzer(project_root)
                    health_result = analyzer.analyze_overall_health()
                    click.echo(f" Overall Health: {health_result.overall_health:.1%}")
                    click.echo(f"📝 Score Note: {health_result.score_note}")
                    click.echo(f"📈 Metrics Analyzed: {len(health_result.metrics)}")
                    
                    if verbose:
                        click.echo("\n📋 Layer-Aware Metrics:")
                        for metric in health_result.metrics:
                            status_emoji = "✅" if metric.status == "measured" else ("⚠️" if metric.status == "unavailable" else "❌")
                            click.echo(f"  {status_emoji} {metric.metric_type.value}: {metric.display_score} [{metric.status}]")
                except Exception as e:
                    click.echo(f"⚠️  Deep scan analysis failed: {e}")
            else:
                # Traditional deep scan
                click.echo(f"� Files checked: {result.total_files_checked}")
                click.echo(f"📦 Imports found: {result.total_imports_found}")
                click.echo(f"🕸️  Graph nodes: {result.total_graph_nodes}")
                
                if result.summary:
                    click.echo("\n📋 Summary Details:")
                    for key, value in result.summary.items():
                        if isinstance(value, (int, float)):
                            click.echo(f"  {key}: {value}")
        
    except Exception as e:
        click.echo(f"❌ Reality validation failed: {e}")
        if verbose:
            import traceback
            click.echo(traceback.format_exc())
    
    click.echo("\n🏁 Reality validation complete")


@system.command()
@click.option("--verbose", "-v", is_flag=True, help="Verbose output")
def doctor(verbose: bool) -> None:
    """
    Forge installation and environment diagnostics.
    
    Checks Forge installation, configuration, and environment
    to identify potential issues with the Forge toolchain itself.
    
    Examples:
        forge system doctor
        forge system doctor --verbose
    """
    
    click.echo(f"🩺 Forge Doctor")
    click.echo("=" * 40)
    
    try:
        # Check Forge installation
        click.echo("🔧 Checking Forge installation...")
        forge_check = check_forge_install()
        if forge_check.ok:
            click.echo("✅ Forge installation healthy")
        else:
            click.echo(f"❌ Forge issue: {forge_check.error}")
        
        # Check all manifests
        click.echo("\n📋 Checking project manifests...")
        manifest_checks = check_all_manifests()
        for project_name, check_result in manifest_checks:
            if check_result.ok:
                click.echo(f"✅ {project_name}: {check_result.value}")
            else:
                click.echo(f"❌ {project_name}: {check_result.error}")
        
        # Additional doctor checks
        if verbose:
            click.echo("\n🔍 Detailed Environment Check:")
            
            # Check Python version
            import sys
            click.echo(f"🐍 Python version: {sys.version}")
            
            # Check critical imports
            critical_modules = ['yaml', 'click', 'pathlib']
            for module in critical_modules:
                try:
                    __import__(module)
                    click.echo(f"✅ {module} available")
                except ImportError:
                    click.echo(f"❌ {module} missing")
            
            # Check configuration
            from forge.core.workspace import get_projects_root
            try:
                projects_root = get_projects_root()
                click.echo(f"📁 Projects root: {projects_root}")
            except Exception as e:
                click.echo(f"❌ Projects root error: {e}")
    
    except Exception as e:
        click.echo(f"❌ Doctor check failed: {e}")
        if verbose:
            import traceback
            click.echo(traceback.format_exc())
    
    click.echo("\n🏁 Doctor check complete")


@system.command()
@click.option("--project-path", "-p", type=click.Path(exists=True), help="Project root path")
@click.option("--aggressive", "-a", is_flag=True, help="Aggressive recovery (clear all caches)")
@click.option("--verbose", "-v", is_flag=True, help="Verbose output")
def recover(project_path: Optional[str], aggressive: bool, verbose: bool) -> None:
    """
    Recovery and repair operations.
    
    Performs recovery operations to fix common issues like corrupted
    caches, broken state, and synchronization problems.
    
    Examples:
        forge system recover
        forge system recover --aggressive
        forge system recover -p /path/to/project --verbose
    """
    
    # Determine project path
    if project_path:
        project_root = Path(project_path).resolve()
    else:
        from forge.core.workspace import load_workspace, _projects_as_list
        workspace = load_workspace()
        projects = _projects_as_list(workspace)
        if not projects:
            click.echo("❌ No projects found. Use --project-path to specify a project.")
            return
        project_root = Path(projects[0].get("path", ".")).resolve()
    
    click.echo(f"🔧 System Recovery")
    click.echo(f"📁 Project: {project_root}")
    click.echo("=" * 40)
    
    try:
        cleared = 0
        
        # Clear cache files
        cache_files = [
            project_root / ".forge" / "manifest_graph.json",
            project_root / ".forge" / "execution_graph.json", 
            project_root / ".forge" / "contract_graph.json",
            project_root / ".forge" / "cache",
            project_root / ".forge" / "__pycache__",
        ]
        
        if aggressive:
            # Add more aggressive cache clearing
            cache_files.extend([
                project_root / ".forge" / "*.pyc",
                project_root / "**/__pycache__",
                project_root / ".pytest_cache",
            ])
        
        click.echo("🗑️  Clearing cache files...")
        for cache_file in cache_files:
            if cache_file.exists():
                if cache_file.is_dir():
                    import shutil
                    shutil.rmtree(cache_file)
                    if verbose:
                        click.echo(f"  Removed directory: {cache_file}")
                else:
                    cache_file.unlink()
                    if verbose:
                        click.echo(f"  Removed file: {cache_file}")
                cleared += 1
        
        if cleared > 0:
            click.echo(f"✅ Cleared {cleared} cache files/directories")
        else:
            click.echo("ℹ️  No cache files to clear")
        
        # Reset execution manager
        click.echo("\n🔄 Resetting execution manager...")
        try:
            execution_manager = get_execution_manager(project_root)
            execution_manager.reset()
            click.echo("✅ Reset execution manager")
        except Exception as e:
            click.echo(f"⚠️  Could not reset execution manager: {e}")
        
        # Reset manifest parser cache
        if aggressive:
            click.echo("\n🔄 Aggressive recovery: Resetting parsers...")
            try:
                # Force rebuild of manifest graph
                from forge.tools.manifest.graph import build_manifest_graph
                build_manifest_graph(project_root)
                click.echo("✅ Rebuilt manifest graph")
            except Exception as e:
                click.echo(f"⚠️  Could not rebuild manifest graph: {e}")
    
    except Exception as e:
        click.echo(f"❌ Recovery failed: {e}")
        if verbose:
            import traceback
            click.echo(traceback.format_exc())
    
    click.echo("\n🏁 Recovery complete")


@system.command()
@click.option("--project-path", "-p", type=click.Path(exists=True), help="Project root path")
@click.option("--export", "-e", type=click.Path(), help="Export graph analysis to file")
@click.option("--verbose", "-v", is_flag=True, help="Verbose output")
def graph(project_path: Optional[str], export: Optional[str], verbose: bool) -> None:
    """
    Graph analysis and metrics.
    
    Analyzes manifest, execution, and contract graphs to provide
    detailed metrics and insights about project structure.
    
    Examples:
        forge system graph
        forge system graph --export analysis.json
        forge system graph -p /path/to/project --verbose
    """
    
    # Determine project path
    if project_path:
        project_root = Path(project_path).resolve()
    else:
        from forge.core.workspace import load_workspace, _projects_as_list
        workspace = load_workspace()
        projects = _projects_as_list(workspace)
        if not projects:
            click.echo("❌ No projects found. Use --project-path to specify a project.")
            return
        project_root = Path(projects[0].get("path", ".")).resolve()
    
    click.echo(f"📊 Graph Analysis")
    click.echo(f"📁 Project: {project_root}")
    click.echo("=" * 40)
    
    try:
        # Build and analyze graphs
        click.echo("🔨 Building graphs...")
        manifest_graph = build_manifest_graph(project_root)
        execution_manager = get_execution_manager(project_root)
        execution_graph = ExecutionGraph()
        contract_graph = ContractGraph()
        
        # Manifest graph analysis
        click.echo(f"\n📋 Manifest Graph:")
        click.echo(f"  Nodes: {len(manifest_graph.nodes)}")
        click.echo(f"  Edges: {len(manifest_graph.edges)}")
        
        if verbose and manifest_graph.nodes:
            # Node type breakdown
            node_types = {}
            for node in manifest_graph.nodes:
                node_type = node.kind or 'unknown'
                node_types[node_type] = node_types.get(node_type, 0) + 1
            
            click.echo("  Node types:")
            for node_type, count in sorted(node_types.items()):
                click.echo(f"    {node_type}: {count}")
        
        # Execution graph analysis
        click.echo(f"\n🏃 Execution Graph:")
        click.echo(f"  Nodes: {len(execution_graph.nodes)}")
        click.echo(f"  Status: Active")
        
        # Contract graph analysis
        click.echo(f"\n📄 Contract Graph:")
        click.echo(f"  Edges: {len(contract_graph.edges)}")
        click.echo(f"  Status: Active")
        
        # Overall metrics
        total_nodes = len(manifest_graph.nodes) + len(execution_graph.nodes)
        total_edges = len(manifest_graph.edges) + len(contract_graph.edges)
        
        click.echo(f"\n📈 Overall Metrics:")
        click.echo(f"  Total nodes: {total_nodes}")
        click.echo(f"  Total edges: {total_edges}")
        click.echo(f"  Graph density: {total_edges / max(total_nodes, 1):.2f}")
        
        # Export if requested
        if export:
            export_path = Path(export)
            analysis_data = {
                "project_path": str(project_root),
                "timestamp": str(Path.cwd()),
                "manifest_graph": {
                    "nodes": len(manifest_graph.nodes),
                    "edges": len(manifest_graph.edges),
                },
                "execution_graph": {
                    "nodes": len(execution_graph.nodes),
                },
                "contract_graph": {
                    "edges": len(contract_graph.edges),
                },
                "overall": {
                    "total_nodes": total_nodes,
                    "total_edges": total_edges,
                    "graph_density": total_edges / max(total_nodes, 1),
                }
            }
            
            import json
            with open(export_path, 'w') as f:
                json.dump(analysis_data, f, indent=2)
            click.echo(f"\n💾 Analysis exported to: {export_path}")
    
    except Exception as e:
        click.echo(f"❌ Graph analysis failed: {e}")
        if verbose:
            import traceback
            click.echo(traceback.format_exc())
    
    click.echo("\n🏁 Graph analysis complete")


@system.command()
@click.option("--project-path", "-p", type=click.Path(exists=True), help="Project root path")
@click.option("--fix", "-f", is_flag=True, help="Attempt to fix issues automatically")
@click.option("--deep-scan", "-d", is_flag=True, help="Include expensive operations")
@click.option("--verbose", "-v", is_flag=True, help="Verbose output")
@click.option("--graph-based", "-g", is_flag=True, help="Use graph-based metrics instead of penalty system")
def all(project_path: Optional[str], fix: bool, deep_scan: bool, verbose: bool, graph_based: bool) -> None:
    """
    Run all system checks (default behavior).
    
    This is the comprehensive system analysis that runs all available
    checks in sequence. Equivalent to running each sub-command
    individually but more convenient.
    
    Examples:
        forge system all
        forge system all --fix
        forge system all --deep-scan --verbose
        forge system all --graph-based    # Use graph-based metrics
    """
    
    # Determine project path
    if project_path:
        project_root = Path(project_path).resolve()
    else:
        from forge.core.workspace import load_workspace, _projects_as_list
        workspace = load_workspace()
        projects = _projects_as_list(workspace)
        if not projects:
            click.echo("❌ No projects found. Use --project-path to specify a project.")
            return
        project_root = Path(projects[0].get("path", ".")).resolve()
    
    click.echo(f"🚀 Comprehensive System Analysis")
    click.echo(f"📁 Project: {project_root}")
    click.echo("=" * 50)
    
    # Run all checks in sequence
    commands = [
        ("Health Check", lambda: health(project_path, fix, verbose, graph_based)),
        ("Reality Validation", lambda: reality(project_path, deep_scan, verbose, graph_based)),
        ("Doctor Check", lambda: doctor(verbose)),
        ("Graph Analysis", lambda: graph(project_path, None, verbose)),
    ]
    
    if fix:
        commands.append(("Recovery", lambda: recover(project_root, False, verbose)))
    
    for name, cmd in commands:
        click.echo(f"\n{'='*20} {name} {'='*20}")
        try:
            cmd()
        except Exception as e:
            click.echo(f"❌ {name} failed: {e}")
    
    click.echo(f"\n{'='*50}")
    click.echo("🏁 Comprehensive analysis complete")
    
    # Next steps
    click.echo("\n📋 Next Steps:")
    if deep_scan:
        click.echo("  • Review detailed analysis results above")
        click.echo("  • Consider running 'forge system recover --aggressive' if issues persist")
    else:
        click.echo("  • Run 'forge system all --deep-scan' for detailed analysis")
    
    click.echo("  • Use individual commands for targeted analysis:")
    click.echo("    forge system health    # Quick health check")
    click.echo("    forge system reality   # Reality validation")
    click.echo("    forge system doctor    # Forge diagnostics")
