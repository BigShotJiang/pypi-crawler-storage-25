from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

import click
from click.core import ParameterSource

from forge.commands._shared_options import response_tier_option
from forge.core.path_utils import resolve_project_path
from forge.core.manifest_document import ManifestDocument
from forge.core.workspace import (
    add_project as ws_add_project,
    list_projects as ws_list_projects,
    remove_project as ws_remove_project,
)
from forge.tools.registry.graph import derive_relations
from forge.tools.registry.importer import import_from_code_workspace, import_from_yaml
from forge.tools.registry.store import (
    ProjectExistsError,
    add_project,
    get_project,
    list_projects,
    load_registry,
    registry_path,
    remove_project,
    resolve_slug,
    touch_project,
    update_project,
)
from forge.tools.workspace_store import forge_config_path, forge_home, shorten_path_display


def _find_workspace_manifest(project_anchor: Path, search: bool = False) -> tuple[Path, Path] | None:
    """Return ``(project_root_dir, manifest_path)`` from *project_anchor*.
    
    Args:
        project_anchor: The path to check for manifest
        search: If True, walk up parent directories looking for manifest (max 16 levels)
                If False, only check the exact path provided
    
    When search=False (default), requires explicit absolute paths and no silent parent walking.
    When search=True, walks up parent directories looking for manifest files.
    """
    anchor = project_anchor.expanduser().resolve()
    if anchor.is_file():
        anchor = anchor.parent

    checks = (
        lambda r: r / ".forge" / "manifest.yaml",
        lambda r: r / "manifest.yaml", 
        lambda r: r / "docs" / "manifest.yaml",
    )

    # If not searching, only check the exact anchor path
    if not search:
        for mk in checks:
            hit = mk(anchor)
            if hit.is_file():
                return anchor, hit
        return None

    # Search mode: walk up parent directories (legacy behavior)
    cur = anchor
    for _ in range(16):
        for mk in checks:
            hit = mk(cur)
            if hit.is_file():
                return cur, hit
        if cur.parent == cur:
            break
        cur = cur.parent
    return None


@click.group("projects", help="Manage forge-tracked projects.")
def projects_group() -> None:
    pass


def _mermaid_id(s: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in s) or "n"


@projects_group.command("add")
@click.argument("path", type=click.Path(file_okay=False))
@click.option("--slug", default=None)
@click.option("--stack", default=None)
@click.option("--phase", default=None, type=int)
@click.option("--tag", "tags", multiple=True)
@click.option("--depends-on", "depends_on", multiple=True)
@click.option("--force", is_flag=True)
def projects_add(
    path: str,
    slug: str | None,
    stack: str | None,
    phase: int | None,
    tags: tuple[str, ...],
    depends_on: tuple[str, ...],
    force: bool,
) -> None:
    """Add a project to the registry."""
    project = resolve_project_path(path)
    rel: dict[str, list[str]] | None = None
    if depends_on:
        rel = {"depends_on": [str(x) for x in depends_on]}
    tag_list = [t for t in tags if t.strip()]
    try:
        entry = add_project(
            project,
            slug=(slug.strip() if slug else None),
            stack=(stack.strip() if stack else None),
            phase=phase,
            tags=tag_list or None,
            relations=rel,
            force=force,
        )
    except ProjectExistsError as e:
        raise click.ClickException(f"Project exists: {e} (use --force)") from e
    except ValueError as e:
        raise click.ClickException(str(e)) from e
    click.echo(f"Added: {entry['id']}")
    click.echo(f"  path:  {entry['path']}")
    click.echo(f"  stack: {entry['stack']}")
    click.echo(f"  phase: {entry['phase']}")
    if entry.get("tags"):
        click.echo(f"  tags:  {entry['tags']}")
    click.echo(f"  source: registry ({registry_path()})")


@projects_group.command("remove")
@click.argument("slug")
@click.option("--yes", is_flag=True, help="Skip confirmation.")
def projects_remove(slug: str, yes: bool) -> None:
    """Remove a project from registry."""
    reg = load_registry()
    key = resolve_slug(slug, reg)
    if not key:
        raise click.ClickException(f"Not found: {slug}")
    if not yes and not click.confirm(f"Remove '{key}' from registry? [y/n]", default=False):
        click.echo("Aborted.")
        return
    if not remove_project(key):
        raise click.ClickException(f"Not found: {slug}")
    click.echo(f"Removed: {key} from {registry_path()}")


@projects_group.command("list")
@click.option("--json", "as_json", is_flag=True)
@click.option("--status", default=None)
@click.option("--stack", default=None)
@click.option("--tag", "tags", multiple=True)
@click.option("--relations", "show_relations", is_flag=True)
@response_tier_option(default="L1")
@click.pass_context
def projects_list(
    ctx: click.Context,
    as_json: bool,
    status: str | None,
    stack: str | None,
    tags: tuple[str, ...],
    show_relations: bool,
    response_tier: str,
) -> None:
    """List all registered projects."""
    reg = load_registry()
    rows = list_projects(
        status=status,
        stack=stack,
        tags=[t for t in tags if t.strip()] or None,
        registry=reg,
    )
    dr = derive_relations(reg) if show_relations else {}
    tier_explicit = ctx.get_parameter_source("response_tier") == ParameterSource.COMMANDLINE
    if tier_explicit:
        tier = str(response_tier or "L1").upper()
        if tier == "L0":
            click.echo(json.dumps([str(r.get("id", "")) for r in rows], indent=2))
            return
        payload = [
            {
                "name": str(r.get("id", "")),
                "path": str(r.get("path", "")),
                "registry_source": str(registry_path()),
                "stack": str(r.get("stack", "")),
                "phase": int(r.get("phase", 1)),
            }
            for r in rows
        ]
        click.echo(json.dumps(payload, indent=2))
        return
    if as_json:
        payload = {"projects": rows, "source": "registry", "registry": str(registry_path())}
        if show_relations:
            payload["derived_relations"] = {k: [list(t) for t in v] for k, v in dr.items()}
        click.echo(json.dumps(payload, indent=2))
        return
    click.echo(f"Projects (source: registry)\n")
    if show_relations:
        click.echo(f"{'Slug':<14} {'Path':<28} {'Stack':<8} {'Ph':<3} {'Tags':<20} {'Relations'}")
        click.echo("─" * 96)
        for row in rows:
            pdisp = shorten_path_display(Path(str(row.get("path", "")))) if row.get("path") else ""
            tg = ",".join(str(t) for t in (row.get("tags") or [])[:3])
            pid = str(row.get("id", ""))
            rels = dr.get(pid, [])
            rshort = ";".join(f"{a}:{b}" for a, b in rels[:4])
            if len(rels) > 4:
                rshort += "…"
            click.echo(
                f"{pid:<14} {pdisp:<28} {str(row.get('stack','')):<8} {int(row.get('phase',1)):<3} {tg:<20} {rshort}"
            )
    else:
        click.echo(f"{'Slug':<14} {'Path':<28} {'Stack':<8} {'Ph':<3} {'Tags'}")
        click.echo("─" * 80)
        for row in rows:
            pdisp = shorten_path_display(Path(str(row.get("path", "")))) if row.get("path") else ""
            tg = ",".join(str(t) for t in (row.get("tags") or []))
            click.echo(
                f"{str(row.get('id','')):<14} {pdisp:<28} {str(row.get('stack','')):<8} {int(row.get('phase',1)):<3} {tg}"
            )
    env_ws = os.environ.get("FORGE_WORKSPACE")
    click.echo(f"\nRegistry:     {registry_path()}")
    click.echo(f"Config file:  {forge_config_path()}")
    click.echo(f"Workspace env:{env_ws or ' not set'}")


@projects_group.command("info")
@click.argument("slug", required=False)
def projects_info(slug: str | None) -> None:
    """Show registry summary, or one project's full entry + relations."""
    reg = load_registry()
    env_ws = os.environ.get("FORGE_WORKSPACE")
    if not slug:
        n = len(reg.get("projects") or {})
        click.echo("Forge project registry")
        click.echo(f"  Registry:        {registry_path()}")
        click.echo(f"  FORGE_WORKSPACE: {env_ws or '(not set)'}")
        click.echo(f"  Projects:        {n}")
        click.echo("\nDetail: forge projects info <slug>")
        return
    sid = resolve_slug(slug, reg)
    if not sid:
        raise click.ClickException(f"Not found: {slug}")
    touch_project(sid)
    ent = get_project(sid, reg) or {}
    dr = derive_relations(reg)
    rels = dr.get(sid, [])
    click.echo(sid)
    click.echo(f"  path:    {ent.get('path')}")
    click.echo(f"  stack:   {ent.get('stack')}")
    click.echo(f"  phase:   {ent.get('phase', 1)}")
    click.echo(f"  status:  {ent.get('status', 'active')}")
    click.echo(f"  tags:    {ent.get('tags') or []}")
    click.echo("\n  Relations (explicit + derived):")
    if not rels:
        click.echo("    (none)")
    else:
        for kind, tgt in rels:
            click.echo(f"    {kind}: {tgt}")


@projects_group.command("import")
@click.argument("path", type=click.Path(exists=True))
@click.option("--dry-run", is_flag=True)
@click.option("--force", is_flag=True)
def projects_import(path: str, dry_run: bool, force: bool) -> None:
    """Import projects from workspace."""
    p = resolve_project_path(path)
    if p.suffix == ".code-workspace":
        click.echo(f"Importing from {p.name}...")
        added, errors = import_from_code_workspace(p, dry_run=dry_run, force=force)
    elif p.suffix in {".yaml", ".yml"}:
        click.echo(f"Importing from {p.name}...")
        added, errors = import_from_yaml(p, dry_run=dry_run, force=force)
    else:
        raise click.ClickException("Expected .code-workspace or .yaml/.yml")
    for ent in added:
        click.echo(f"✓ {'Would add' if dry_run else 'Added'}: {ent.get('id')} ({ent.get('stack')}, phase {ent.get('phase', 1)})")
    for err in errors:
        click.echo(f"→ Skipped: {err.get('path')} — {err.get('error')}")
    click.echo(f"\n{'Planned' if dry_run else 'Imported'} {len(added)} project(s). {len(errors)} skipped/errors.")
    if not dry_run:
        click.echo(f"Registry: {registry_path()}")


@projects_group.command("relate")
@click.argument("slug")
@click.option("--depends-on", default=None)
@click.option("--provides-to", default=None)
@click.option("--shares-backend", default=None)
@click.option("--contains", default=None)
@click.option("--scaffolds-from", default=None)
@click.option("--uses-templates-from", default=None)
def projects_relate(
    slug: str,
    depends_on: str | None,
    provides_to: str | None,
    shares_backend: str | None,
    contains: str | None,
    scaffolds_from: str | None,
    uses_templates_from: str | None,
) -> None:
    """Declare relations between projects."""
    reg = load_registry()
    sid = resolve_slug(slug, reg)
    if not sid:
        raise click.ClickException(f"Not found: {slug}")
    patch: dict[str, list[str]] = {}
    if depends_on:
        patch.setdefault("depends_on", []).append(depends_on)
    if provides_to:
        patch.setdefault("provides_to", []).append(provides_to)
    if shares_backend:
        patch.setdefault("shares_backend", []).append(shares_backend)
    if contains:
        patch.setdefault("contains", []).append(contains)
    if scaffolds_from:
        patch.setdefault("scaffolds_from", []).append(scaffolds_from)
    if uses_templates_from:
        patch.setdefault("uses_templates_from", []).append(uses_templates_from)
    if not patch:
        raise click.ClickException("Provide at least one relation flag.")
    update_project(sid, relations=patch)
    for k, vs in patch.items():
        for v in vs:
            click.echo(f"Added relation: {sid} —{k}→ {v}")


@projects_group.command("graph")
@click.option("--format", "fmt", type=click.Choice(["mermaid", "table"]), default="mermaid")
@click.option("--depth", default=2, type=int)
def projects_graph(fmt: str, depth: int) -> None:
    """Show project dependency graph."""
    _ = depth  # reserved for future pruning
    reg = load_registry()
    dr = derive_relations(reg)
    edges: set[tuple[str, str, str]] = set()
    for src, pairs in dr.items():
        for rel, tgt in pairs:
            if rel in ("depends_on", "contains", "scaffolds_from", "provides_to", "uses_templates_from"):
                edges.add((src, tgt, rel))
    if fmt == "mermaid":
        click.echo("graph TD")
        for a, b, rel in sorted(edges):
            la, lb = _mermaid_id(a), _mermaid_id(b)
            click.echo(f"  {la}[{a}] -->|{rel}| {lb}[{b}]")
        return
    click.echo(f"{'From':<16} {'Relation':<22} {'To'}")
    click.echo("─" * 56)
    for a, b, rel in sorted(edges):
        click.echo(f"{a:<16} {rel:<22} {b}")


@projects_group.command("scan")
@click.argument("directory", required=False)
@response_tier_option(default="L1")
def projects_scan(directory: str | None, response_tier: str) -> None:
    """Scan for projects (stub)."""
    _ = directory
    rows = list_projects()
    payload = {
        "discovered_count": len(rows),
        "projects": [str(r.get("id", "")) for r in rows],
        "hint": "Use: forge projects import <path-to.code-workspace or yaml>; forge projects add <path>",
    }
    tier = str(response_tier or "L1").upper()
    if tier == "L0":
        payload = {"discovered_count": payload["discovered_count"]}
    click.echo(json.dumps(payload, indent=2))


@projects_group.command("init")
def projects_init() -> None:
    """Initialize forge in a project."""
    fh = forge_home()
    fh.mkdir(parents=True, exist_ok=True)
    reg = load_registry()
    if not registry_path().is_file():
        from forge.tools.registry.store import save_registry

        save_registry(reg)
    env_ws = os.environ.get("FORGE_WORKSPACE")
    n = len(reg.get("projects") or {})
    click.echo("forge projects initialized")
    click.echo(f"Registry: {registry_path()}")
    click.echo(f"Workspace env: {env_ws or 'not set'}")
    click.echo(f"Projects in registry: {n}")
    click.echo("\nImport a VS Code workspace:")
    click.echo("  forge projects import ~/Projects/forge-workspace/forge.code-workspace")


# ── workspace command group — backed by ~/.forge/workspace.yaml ───────────────

_WORKSPACE_MIGRATION_WARNING = (
    "⚠  forge workspace is being merged into forge projects.\n"
    "   Your data is safe. Use forge projects for new work.\n"
    "   Migration guide: forge projects import\n"
)


def _workspace_migration_warning() -> None:
    click.echo(_WORKSPACE_MIGRATION_WARNING, err=True)


@click.group("workspace", invoke_without_command=True)
@click.pass_context
def workspace_cmd(ctx: click.Context) -> None:
    """Manage the forge workspace registry (~/.forge/workspace.yaml).
    
    Centralized project management for multi-project Forge workflows.
    Workspace registry enables project discovery, dependency tracking,
    and unified operations across your development environment.
    
    Examples:
      forge workspace add --interactive                    # Interactive project registration
      forge workspace list                                 # View all registered projects
      forge workspace get my-project path                  # Get project property
      forge workspace remove my-project                    # Remove project from registry
    
    Workspace Features:
      • Project discovery and registration
      • Cross-project dependency management
      • Centralized project metadata
      • Multi-project workflow support
    
    Registry Location: ~/.forge/workspace.yaml
    Environment: FORGE_WORKSPACE (optional workspace override)
    
    See also: forge projects (advanced registry), forge map (project visualization)
    """
    _workspace_migration_warning()
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_cmd.command("list")
@response_tier_option(default="L1")
@click.pass_context
def workspace_list(ctx: click.Context, response_tier: str) -> None:
    """List all registered projects."""
    projects = ws_list_projects()
    tier_explicit = ctx.get_parameter_source("response_tier") == ParameterSource.COMMANDLINE
    if tier_explicit:
        tier = str(response_tier or "L1").upper()
        if tier == "L0":
            click.echo(json.dumps([str(p.get("name", "")) for p in projects], indent=2))
            return
        payload = [
            {
                "name": str(p.get("name", "")),
                "path": str(p.get("path", "")),
                "stack": str(p.get("stack", "")),
                "phase": p.get("phase"),
            }
            for p in projects
        ]
        click.echo(json.dumps(payload, indent=2))
        return
    if not projects:
        click.echo(
            "No projects registered. "
            "Use: forge workspace add <path> --name <name> --stack <stack>"
        )
        return
    for p in projects:
        manifest = p.get("manifest") or "none"
        click.echo(f"  {p['name']} [{p['stack']}] {p['path']} ({manifest})")


@workspace_cmd.command("get")
@click.argument("name")
@click.argument("key")
@response_tier_option(default="L1")
def workspace_get(name: str, key: str, response_tier: str) -> None:
    projects = ws_list_projects()
    hit = next((p for p in projects if str(p.get("name", "")).strip() == name.strip()), None)
    if hit is None:
        raise click.ClickException(f"Not found: {name}")
    value = hit.get(key)
    tier = str(response_tier or "L1").upper()
    if tier == "L0":
        click.echo(str(value))
        return
    click.echo(
        json.dumps(
            {"key": key, "value": value, "source_file": str(forge_home() / "workspace.yaml")},
            indent=2,
        )
    )


@workspace_cmd.command("add")
@click.argument("path", required=False)
@click.option("--name", required=False, default=None, help="Project name (defaults to manifest name or folder)")
@click.option(
    "--stack",
    required=False,
    default=None,
    type=click.Choice(["flutter-app", "web-next", "web-react", "python-cli"]),
    help="Project stack (defaults to detected manifest stack)",
)
@click.option("--manifest", default=None, help="Relative path to manifest.yaml")
@click.option("--search", is_flag=True, help="Search parent directories for manifest.yaml (up to 16 levels)")
@click.option("--interactive", is_flag=True, default=False, help="Interactive project discovery and registration")
def workspace_add(path: str | None, name: str | None, stack: str | None, manifest: str | None, search: bool, interactive: bool) -> None:
    """Register a project in the workspace.
    
    Adds projects to the Forge workspace registry for centralized management.
    Workspace enables multi-project operations, dependency tracking, and
    unified project discovery across your development environment.
    
    Examples:
      forge workspace add ./my-project                    # Register current directory
      forge workspace add ~/Projects/my-app --name MyApp  # Register with custom name
      forge workspace add ./project --stack flutter-app   # Specify stack type
      forge workspace add --interactive                   # Interactive discovery
      forge workspace add ./project --search              # Search parent directories
    
    Project Stacks:
      flutter-app  Flutter mobile/web applications
      web-next     Next.js web applications  
      web-react    React web applications
      python-cli   Python CLI tools and packages
    
    Workspace Benefits:
      • Centralized project registry and discovery
      • Cross-project dependency tracking
      • Unified project operations and management
      • Simplified multi-project workflows
    
    See also: forge workspace list, forge map, forge verify
    """
    # Handle interactive mode
    if interactive:
        return _run_interactive_workspace_add(path, name, stack, manifest, search)
    
    # Require path for non-interactive mode
    if not path:
        raise click.ClickException("PATH argument required when not using --interactive mode")
    
    raw_path = Path(path).expanduser()
    if not raw_path.exists():
        raise click.ClickException(
            f"path does not exist: {raw_path}\n"
            "Tip: use absolute paths or `.` for current directory. "
            "Use --search flag to enable parent directory search."
        )

    found = _find_workspace_manifest(raw_path, search=search)
    if found is None:
        anchor = raw_path.resolve()
        if search:
            raise click.ClickException(
                "No manifest.yaml found searching up from "
                f"{anchor}\n"
                "Searched each directory for .forge/manifest.yaml, manifest.yaml, "
                "docs/manifest.yaml.\n"
                "Tip: Ensure you're in or point to a directory containing a manifest.yaml"
            )
        else:
            raise click.ClickException(
                "No manifest.yaml found at "
                f"{anchor}\n"
                "Checked for .forge/manifest.yaml, manifest.yaml, docs/manifest.yaml.\n"
                "Tip: Use --search flag to enable parent directory search, or point to "
                "the exact directory containing manifest.yaml"
            )

    project_root, manifest_hit = found
    requested = raw_path.resolve()
    if project_root.resolve() != requested:
        click.echo(
            f"Note: using project root {project_root} (manifest: {manifest_hit}) — "
            f"adjusted from {requested}.",
            err=True,
        )

    try:
        doc = ManifestDocument.from_path(project_root)
        parsed = doc.to_legacy_dict()
    except (FileNotFoundError, ValueError) as exc:
        raise click.ClickException(f"invalid manifest for workspace registration: {exc}") from exc

    project_name = (name or str(parsed.get("name") or project_root.name)).strip()
    project_stack = (stack or str(doc.stack)).strip()
    manifest_rel = manifest
    if manifest_rel is None:
        try:
            manifest_rel = str(manifest_hit.resolve().relative_to(project_root))
        except ValueError:
            manifest_rel = str(manifest_hit.resolve())
    
    existing_by_name = any(
        p for p in ws_list_projects()
        if str(p.get("name") or "").strip() == project_name
    )
    existing_by_path = any(
        p for p in ws_list_projects()
        if str(p.get("path") or "").strip() == str(project_root)
    )
    
    ws_add_project(project_name, str(project_root), project_stack, manifest_rel)
    if existing_by_name or existing_by_path:
        click.echo(f"Updated {project_name}")
    else:
        click.echo(f"Registered {project_name}")


@workspace_cmd.command("remove")
@click.argument("name")
def workspace_remove(name: str) -> None:
    """Remove a project from the workspace registry."""
    if ws_remove_project(name):
        click.echo(f"Removed {name}")
    else:
        click.echo(f"Not found: {name}", err=True)
