from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Any

import click
import yaml

from forge.commands._shared_options import response_tier_option
from forge.core.path_utils import resolve_project_path
from forge.core.manifest_path import resolve_manifest_path
from forge.core.discovery import discover_projects, get_projects_root, _get_manifest_path
from forge.core.manifest import ManifestParser, infer_tier, stable_module_node_id
import forge.core.query as _core_query
from forge.tools.manifest.graph import build_manifest_graph, resolve_manifest_node
from forge.tools.glove_templates.registry import load_schema_templates_section


# ── Shared with MCP (same module as CLI — no parallel ops layer) ─────────────


def _project_root_for_manifest(manifest_path: Path) -> Path:
    manifest_path = manifest_path.resolve()
    if manifest_path.parent.name == "docs":
        return manifest_path.parent.parent
    return manifest_path.parent


def validate_project_by_name(project_name: str) -> dict[str, Any]:
    """Validate manifest for a project resolved by discovery name (same as CLI validate)."""
    projects = discover_projects(get_projects_root())
    match = next((p for p in projects if p.name.lower() == project_name.lower()), None)
    if not match:
        project_root = get_projects_root() / project_name
        manifest_path = resolve_manifest_path(project_root)
        if manifest_path is None or not manifest_path.exists():
            return {
                "ok": False,
                "error": f"Project {project_name!r} not found and no manifest under {project_root}",
            }
        mp = manifest_path
    else:
        mp = _get_manifest_path(match.path)
        if not mp or not mp.exists():
            return {
                "ok": False,
                "error": f"No manifest.yaml for project {project_name!r}",
            }
    parser = ManifestParser(mp)
    result = parser.parse()
    if not result.ok:
        return {"ok": False, "error": str(result.error or "parse failed")}
    data = result.value
    if data is None:
        return {"ok": False, "error": "empty manifest"}
    warnings = list(data.get("warnings") or [])
    root = _project_root_for_manifest(mp)
    try:
        graph = build_manifest_graph(root)
    except Exception as exc:
        return {"ok": False, "error": f"Manifest graph build failed: {exc}"}
    rq = _core_query.forge_query(graph, kind="", where={}, limit=10**9, depth=1, direction="both")
    return {
        "ok": True,
        "warnings": warnings,
        "manifest_path": str(mp),
        "graph_node_count": int(rq.data.get("count", 0)),
    }


def manifest_node_path(project_root: Path, node_ref: str) -> dict[str, Any]:
    """Resolve node ref → repo-relative path."""
    root = resolve_project_path(project_root)
    graph = build_manifest_graph(root)
    _core_query.forge_query(graph, kind="", where={}, limit=1, depth=1, direction="both")
    node = resolve_manifest_node(graph, node_ref)
    if node is None:
        return {"ok": False, "error": f"unknown node: {node_ref!r}"}
    p = (node.path or "").strip()
    if not p:
        return {"ok": False, "error": f"node {node.id!r} has no path in manifest", "id": node.id}
    return {"ok": True, "id": node.id, "path": p}


def manifest_node_get(
    project_root: Path,
    node_ref: str,
    field: str | None,
    *,
    as_json: bool,
) -> dict[str, Any]:
    """Return one field or full node as dict (JSON-serializable)."""
    root = resolve_project_path(project_root)
    graph = build_manifest_graph(root)
    _core_query.forge_query(graph, kind="", where={}, limit=1, depth=1, direction="both")
    node = resolve_manifest_node(graph, node_ref)
    if node is None:
        return {"ok": False, "error": f"unknown node: {node_ref!r}"}
    if as_json:
        return {"ok": True, "node": asdict(node)}
    meta = node.meta or {}
    if not field:
        return {
            "ok": True,
            "id": node.id,
            "kind": node.kind,
            "name": node.name,
            "path": node.path or "",
            "domain": node.domain or "",
            "parent_id": node.parent_id or "",
            "role": str(meta.get("role") or ""),
        }
    key = field.strip().lower()
    if key in ("id", "kind", "name", "path", "domain", "parent_id"):
        val = getattr(node, key, None)
        return {"ok": True, "field": key, "value": "" if val is None else str(val)}
    if key == "role":
        return {"ok": True, "field": "role", "value": str(meta.get("role") or "")}
    if key == "owns":
        owns = meta.get("owns")
        return {"ok": True, "field": "owns", "value": owns if isinstance(owns, list) else []}
    if key == "meta":
        return {"ok": True, "field": "meta", "value": meta}
    return {"ok": False, "error": f"unknown field: {field!r}"}


# MCP imports these names; keep stable without colliding with Click command names.
node_path = manifest_node_path
node_get = manifest_node_get


def migrate_manifest_to_v2(project_root: Path, file_path: str) -> dict[str, Any]:
    root = resolve_project_path(project_root)
    target = (root / file_path).resolve() if not Path(file_path).is_absolute() else Path(file_path).expanduser().resolve()
    if not target.is_file():
        return {"ok": False, "error": f"manifest file not found: {target}"}
    raw = yaml.safe_load(target.read_text(encoding="utf-8")) or {}
    if not isinstance(raw, dict):
        return {"ok": False, "error": "manifest file must be a mapping"}

    modules = raw.get("modules")
    if not isinstance(modules, list):
        return {"ok": False, "error": "manifest.modules must be a list for migration"}

    migrated = 0
    removed_stack = 0
    removed_type = 0
    for row in modules:
        if not isinstance(row, dict):
            continue
        if "stack" in row:
            removed_stack += 1
            row.pop("stack", None)
        if "type" in row:
            removed_type += 1
            row.pop("type", None)
        kind = str(row.get("kind") or "module").strip() or "module"
        nid = stable_module_node_id(row)
        if not str(row.get("tier") or "").strip():
            row["tier"] = infer_tier(nid, kind).value
        for list_key in (
            "depends_on",
            "consumed_by",
            "owns",
            "proposed_depends_on",
            "proposed_implements",
        ):
            val = row.get(list_key)
            if val is None:
                row[list_key] = []
                continue
            if not isinstance(val, list):
                row[list_key] = [str(val)]
        migrated += 1

    raw["schema_version"] = 2
    target.write_text(yaml.safe_dump(raw, sort_keys=False), encoding="utf-8")
    return {
        "ok": True,
        "migrated_file": str(target),
        "schema_version": 2,
        "migrated_nodes": migrated,
        "removed_stack_fields": removed_stack,
        "removed_type_fields": removed_type,
    }


# ── CLI ───────────────────────────────────────────────────────────────────────


class _ManifestGroup(click.Group):
    """Accept legacy ``forge manifest NAME --validate`` as ``manifest validate NAME``."""

    def resolve_command(
        self,
        ctx: click.Context,
        args: list[str],
    ) -> tuple[str | None, click.Command | None, list[str]]:
        cmds = frozenset(self.commands.keys())
        if (
            args
            and args[0] not in cmds
            and args[0] != "--help"
            and not str(args[0]).startswith("-")
        ):
            if any(x in args for x in ("--validate", "--export", "--migrate")):
                name = args[0]
                tail = [
                    a
                    for a in args[1:]
                    if a != name and a != "--validate"
                ]
                return super().resolve_command(ctx, ["validate", name, *tail])
        return super().resolve_command(ctx, args)


@click.group("manifest", cls=_ManifestGroup)
def manifest_group() -> None:
    """Manifest graph lookup (path/get) and validation for discovered projects."""


@manifest_group.command("schema")
@click.option("--project-path", default=".", show_default=True, type=click.Path(file_okay=False))
@response_tier_option(default="L1")
def manifest_schema_cmd(project_path: str, response_tier: str) -> None:
    """Print the ``templates`` registry schema slice from .forge/schema.yaml."""
    _ = response_tier
    root = resolve_project_path(project_path)
    blob = load_schema_templates_section(root)
    click.echo(json.dumps(blob if blob else {}, indent=2))


@manifest_group.command("validate")
@click.argument("project_name")
@click.option("--export", type=click.Choice(["md", "json"]), default=None, help="Export format (Phase 2)")
@click.option("--migrate", is_flag=True, help="Migrate manifest schema (Phase 3)")
def manifest_validate(project_name: str, export: str | None, migrate: bool) -> None:
    """Validate manifest.yaml for a project resolved by discovery (name under projects root)."""
    if migrate:
        click.echo("manifest migration: phase 3 — not yet implemented")
        raise SystemExit(0)
    if export:
        click.echo("--export is not implemented in Phase 1.")
        raise SystemExit(0)
    out = validate_project_by_name(project_name)
    if not out.get("ok"):
        click.echo(out.get("error") or "Validation failed.")
        raise SystemExit(1)
    for w in out.get("warnings") or []:
        click.echo(f"Warning: {w}")
    n = out.get("graph_node_count")
    if isinstance(n, int):
        click.echo(f"Declaration graph: {n} nodes.")
    click.echo("Manifest is valid.")
    raise SystemExit(0)


@manifest_group.command("backfill-tiers")
@click.option("--project-path", default=".", show_default=True, type=click.Path(file_okay=False))
def manifest_backfill_tiers_cmd(project_path: str) -> None:
    """Infer and write missing ``tier`` on each ``modules:`` row (ManifestParser — C006)."""
    root = resolve_project_path(project_path)
    mp = resolve_manifest_path(root, warn_on_root_fallback=False)
    if mp is None or not mp.is_file():
        raise click.ClickException(f"No manifest.yaml under {root}")
    res = ManifestParser(mp).backfill_node_tiers()
    if not res.ok:
        raise click.ClickException(str(res.error or "backfill failed"))
    n = int(res.value or 0)
    click.echo(f"Backfilled tier on {n} module row(s).")


@manifest_group.command("migrate")
@click.option("--project-path", default=".", show_default=True, type=click.Path(file_okay=False))
@click.option("--file", "file_path", default=".forge/manifest.yaml", show_default=True, type=click.Path(dir_okay=False))
def manifest_migrate_cmd(project_path: str, file_path: str) -> None:
    """Migrate manifest nodes to canonical schema v2 fields."""
    out = migrate_manifest_to_v2(resolve_project_path(project_path), file_path)
    if not out.get("ok"):
        raise click.ClickException(str(out.get("error") or "manifest migrate failed"))
    click.echo(
        "manifest migrated to v2: "
        f"{out.get('migrated_nodes', 0)} nodes, "
        f"removed stack={out.get('removed_stack_fields', 0)}, "
        f"type={out.get('removed_type_fields', 0)}"
    )


@manifest_group.command("path")
@click.argument("node_ref")
@click.option("--project-path", default=".", show_default=True, type=click.Path(file_okay=False))
def manifest_path_cmd(node_ref: str, project_path: str) -> None:
    """Print repo-relative path for a manifest graph node (Gate 7 — ID → path).

    NODE_REF: full id (module/commands.map), module name (commands.map), or node name.
    """
    root = resolve_project_path(project_path)
    out = manifest_node_path(root, node_ref)
    if not out.get("ok"):
        raise click.ClickException(str(out.get("error") or "path lookup failed"))
    click.echo(out["path"])


@manifest_group.command("add")
@click.argument("node_id")
@click.option("--path", "path", required=True, help="Repo-relative file path")
@click.option("--kind", "kind", required=True, help="Node kind (module, component, etc.)")
@click.option("--domain", "domain", required=True, help="Domain name (UPPER case)")
@click.option(
    "--status",
    "status",
    type=click.Choice(["declared", "implemented", "deprecated"]),
    default="implemented",
    show_default=True,
)
@click.option("--tier", "tier", type=int, default=None, help="Optional tier (1-5)")
@click.option(
    "--depends-on",
    "depends_on",
    multiple=True,
    help="Node IDs this node depends on (repeatable)",
)
@click.option("--dry-run", "dry_run", is_flag=True, default=False, help="Preview without writing")
@click.option("--project-path", "project_path", default=".", show_default=True)
def manifest_add_cmd(
    node_id: str,
    path: str,
    kind: str,
    domain: str,
    status: str,
    tier: int | None,
    depends_on: tuple[str, ...],
    dry_run: bool,
    project_path: str,
) -> None:
    """Add a node to the manifest graph.

    NODE_ID is the canonical node identifier, e.g. module/engine.engine

    Examples:

      forge manifest add module/core.foo \\
        --path forge/core/foo.py \\
        --kind module --domain CORE

      forge manifest add component/ui.button \\
        --path src/components/Button.tsx \\
        --kind component --domain UI \\
        --dry-run
    """
    from rich.console import Console

    from forge.mcp.thin_core import execute_manifest_append

    console = Console()
    root = Path(project_path).resolve()

    try:
        node: dict[str, Any] = {
            "id": node_id,
            "path": path,
            "kind": kind,
            "domain": domain,
            "status": status,
        }
        if tier is not None:
            node["tier"] = tier
        if depends_on:
            node["depends_on"] = list(depends_on)

        result = execute_manifest_append({
            "project_path": str(root),
            "nodes": [node],
            "dry_run": dry_run,
        })

        if result.get("ok"):
            action = "Would add" if dry_run else "Added"
            console.print(f"[green]✓ {action}: {node_id}[/green]")
            if dry_run:
                console.print("  [dim](dry run — no changes written)[/dim]")
            warnings = result.get("kind_warnings", [])
            for w in warnings:
                console.print(f"  [yellow]⚠ {w}[/yellow]")
        else:
            console.print(
                f"[red]Error: {result.get('error', 'Failed')}[/red]"
            )
            raise SystemExit(1)
    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise SystemExit(1) from e


@manifest_group.command("get")
@click.argument("node_ref")
@click.argument("field", required=False)
@click.option("--project-path", default=".", show_default=True, type=click.Path(file_okay=False))
@click.option("--json", "as_json", is_flag=True, help="Emit full node record as JSON.")
def manifest_get_cmd(
    node_ref: str,
    field: str | None,
    project_path: str,
    as_json: bool,
) -> None:
    """Print one field (or full record) for a manifest graph node.

    Fields: id, kind, name, path, domain, parent_id, role, owns, meta.
    """
    root = resolve_project_path(project_path)
    out = manifest_node_get(root, node_ref, field, as_json=as_json)
    if not out.get("ok"):
        raise click.ClickException(str(out.get("error") or "get failed"))
    if as_json:
        click.echo(json.dumps(out["node"], indent=2))
        return
    if not field:
        n = out
        lines = [
            f"id: {n['id']}",
            f"kind: {n['kind']}",
            f"name: {n['name']}",
            f"path: {n['path']}",
            f"domain: {n['domain']}",
            f"parent_id: {n['parent_id']}",
            f"role: {n['role']}",
        ]
        click.echo("\n".join(lines))
        return
    val = out.get("value")
    if isinstance(val, (dict, list)):
        click.echo(json.dumps(val, indent=2))
    else:
        click.echo("" if val is None else str(val))


# Back-compat: cli_main registers this name
manifest_cmd = manifest_group
