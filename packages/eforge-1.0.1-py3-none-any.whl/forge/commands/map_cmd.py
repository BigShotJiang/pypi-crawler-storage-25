"""
forge map — print a graph view to stdout, or regenerate docs with --write-docs.

Default CLI behaviour prints a project map (markdown / mermaid / json) derived from
build_manifest_graph(). To write committed mirrors + JSON context:

    forge map --write-docs           # docs/MAP.md, docs/MANIFEST.md, .forge/agent_context.json
    forge map --write-docs --docs-dry-run   # preview only

The impact-check hook also calls run_map() when graph_impact has affected_nodes.

change-impact.yaml may require MAP/MANIFEST updates after structural edits — use
--write-docs (or rely on the hook when running forge impact-check).
"""

from __future__ import annotations

import re
import sys
from collections import defaultdict
from datetime import date
from pathlib import Path
from typing import Any

import click

from forge.commands._shared_options import response_tier_option
from forge.commands.cli_surface import cli_surface_markdown_section
from forge.core.manifest_document import ManifestDocument
from forge.core.path_utils import resolve_project_path


# ── Sentinel comments — surgical MAP.md replacement ───────────────────────────
_CODEBASE_START = "<!-- @forge-map:codebase-start -->"
_CODEBASE_END = "<!-- @forge-map:codebase-end -->"


# ── Helpers ───────────────────────────────────────────────────────────────────

def _load_manifest_raw(root: Path) -> dict[str, Any]:
    try:
        doc = ManifestDocument.from_path(resolve_project_path(root))
        return dict(doc.to_legacy_dict())
    except (FileNotFoundError, ValueError):
        return {}


def _get_stack(root: Path) -> str | None:
    """Read stack from manifest (canonical label via ManifestParser)."""
    try:
        from forge.core.manifest import ManifestParser

        doc = ManifestDocument.from_path(resolve_project_path(root))
        raw = dict(doc.to_legacy_dict())
        stack = raw.get("stack")
        if isinstance(stack, str) and stack.strip():
            return stack.strip()
        label = ManifestParser.get_stack(raw)
        return label if label and label != "unknown" else None
    except Exception:
        return None


def _load_glove_data(root: Path, stack: str | None) -> dict[str, Any]:
    """
    Use the registered ComposerCanvas to discover layouts and components
    from actual project files.

    Returns dict with layouts, components, by_domain, by_kind.
    """
    from forge.core.composer import get_composer_canvas

    if not stack:
        return {}

    try:
        if stack in ("flutter-app", "flutter"):
            import forge.gloves.dart_glove  # noqa: F401 — register canvas
        elif stack in ("astro", "web"):
            pass  # astro glove TBD
    except ImportError:
        return {}

    canvas = get_composer_canvas(stack)
    if canvas is None:
        return {}

    try:
        layouts = canvas.available_layouts(root)
        components = canvas.available_components(root)
    except Exception:
        return {}

    by_domain: dict[str, list[Any]] = {}
    for item in layouts + components:
        domain = getattr(item, "domain", None)
        if domain is None:
            domain = _layout_domain(item)
        d = str(domain).upper()
        by_domain.setdefault(d, [])
        by_domain[d].append(item)

    by_kind: dict[str, list[Any]] = {}
    for c in components:
        k = c.kind.value
        by_kind.setdefault(k, [])
        by_kind[k].append(c)

    return {
        "layouts": layouts,
        "components": components,
        "by_domain": by_domain,
        "by_kind": by_kind,
    }


def _layout_domain(layout: Any) -> str:
    """Domain for a layout descriptor (layouts omit domain on the dataclass)."""
    node_id = str(getattr(layout, "node_id", "") or "")
    if "/" in node_id and "." in node_id:
        return node_id.split("/", 1)[1].split(".", 1)[0].upper()
    path = str(getattr(layout, "path", "") or "")
    parts = [p.upper() for p in Path(path).parts]
    if "FEATURES" in parts:
        idx = parts.index("FEATURES")
        if idx + 1 < len(parts):
            return parts[idx + 1]
    return "UNKNOWN"


def _render_composer_section(glove_data: dict[str, Any]) -> str:
    """Render layouts and components discovered by the active stack glove."""
    if not glove_data:
        return ""

    layouts = glove_data.get("layouts", [])
    components = glove_data.get("components", [])
    by_kind = glove_data.get("by_kind", {})

    lines: list[str] = [
        "",
        "## Component Architecture",
        "",
        f"_Discovered by glove — {len(layouts)} layouts, "
        f"{len(components)} components_",
        "",
    ]

    if layouts:
        lines += [
            "### Layouts (Screens)",
            "",
            "| Layout | Domain | Slots | Path |",
            "| ------ | ------ | ----- | ---- |",
        ]
        for layout in sorted(layouts, key=lambda x: _layout_domain(x)):
            slots = ", ".join(layout.slot_names())
            lines.append(
                f"| {layout.label} | {_layout_domain(layout)} | {slots} | {layout.path} |"
            )
        lines.append("")

    kind_labels = {
        "molecule": "Variants / Molecules",
        "atom": "Atoms",
        "organism": "Organisms (Controllers)",
        "island": "Islands (Interactive)",
        "card": "Cards",
    }

    for kind, label in kind_labels.items():
        items = by_kind.get(kind, [])
        if not items:
            continue
        lines += [
            f"### {label}",
            "",
            "| Component | Domain | Path |",
            "| --------- | ------ | ---- |",
        ]
        for comp in sorted(items, key=lambda x: x.domain):
            lines.append(f"| {comp.label} | {comp.domain} | {comp.path} |")
        lines.append("")

    return "\n".join(lines)


def _glove_json_payload(glove_data: dict[str, Any]) -> dict[str, Any]:
    """Serialize glove discovery for --format json."""
    if not glove_data:
        return {"layouts": [], "components": []}
    layouts_out = [
        {
            "node_id": layout.node_id,
            "label": layout.label,
            "domain": _layout_domain(layout),
            "path": layout.path,
            "slots": layout.slot_names(),
        }
        for layout in glove_data.get("layouts", [])
    ]
    components_out = [
        {
            "node_id": comp.node_id,
            "label": comp.label,
            "kind": comp.kind.value,
            "domain": comp.domain,
            "path": comp.path,
        }
        for comp in glove_data.get("components", [])
    ]
    return {"layouts": layouts_out, "components": components_out}


def _md_table(headers: list[str], rows: list[list[str]]) -> str:
    """Render a markdown table with padded columns."""
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            if i < len(widths):
                widths[i] = max(widths[i], len(str(cell)))
    header = "| " + " | ".join(h.ljust(w) for h, w in zip(headers, widths)) + " |"
    sep = "| " + " | ".join("-" * w for w in widths) + " |"
    body = [
        "| " + " | ".join(str(c).ljust(w) for c, w in zip(row, widths)) + " |"
        for row in rows
    ]
    return "\n".join([header, sep] + body)


def _modules_by_domain(graph: Any) -> dict[str, list[Any]]:
    bd: dict[str, list[Any]] = defaultdict(list)
    for n in graph.nodes:
        if n.kind not in ("domain", "feature"):
            bd[n.domain or "UNASSIGNED"].append(n)
    for nodes in bd.values():
        nodes.sort(key=lambda n: n.name)
    return dict(bd)


# ── MANIFEST.md generator ─────────────────────────────────────────────────────

def _generate_manifest_md(graph: Any, raw: dict[str, Any], today: str) -> str:
    _app = raw.get("app") if isinstance(raw.get("app"), dict) else {}
    project_name = str(raw.get("name") or _app.get("name") or "unknown")
    description = str(raw.get("description") or "")
    version = str(raw.get("version") or "")
    stack = raw.get("stack") or {}
    phases = raw.get("phases") or {}
    constraints = raw.get("constraints") or []

    by_domain = _modules_by_domain(graph)
    domain_nodes = sorted(
        (n for n in graph.nodes if n.kind == "domain"),
        key=lambda n: n.name,
    )
    total_modules = sum(len(v) for v in by_domain.values())
    import_edges = [e for e in graph.edges if e.relation == "imports"]
    belongs_edges = [e for e in graph.edges if e.relation == "belongs_to"]

    lines: list[str] = []

    # ── Frontmatter ──────────────────────────────────────────────────────────
    lines += [
        "---",
        "id: forge_manifest",
        "type: manifest",
        "status: current",
        f"last_updated: {today}",
        f"project: {project_name}",
        "forge_compatible: true",
        "generated_by: forge map",
        "---",
        "",
    ]

    # ── Contents ─────────────────────────────────────────────────────────────
    lines += [
        "## Contents",
        "",
        "- [Project](#project)",
        "- [Stack](#stack)",
        "- [Modules by Domain](#modules-by-domain)",
        "- [Domains](#domains)",
        "- [Phases](#phases)",
        "- [Constraints](#constraints)",
        "",
    ]

    # ── Project ──────────────────────────────────────────────────────────────
    lines += ["## Project", ""]
    project_rows = [
        ["name", project_name],
        ["version", version],
        ["description", description[:120] + ("…" if len(description) > 120 else "")],
    ]
    lines += [_md_table(["Field", "Value"], project_rows), ""]

    # ── Stack ─────────────────────────────────────────────────────────────────
    lines += ["## Stack", ""]
    stack_rows = [[k, str(v)] for k, v in stack.items() if v is not None]
    if stack_rows:
        lines += [_md_table(["Field", "Value"], stack_rows), ""]

    # ── Modules by Domain ────────────────────────────────────────────────────
    lines += [
        "## Modules by Domain",
        "",
        f"**{total_modules} modules** across **{len(by_domain)} domains** — "
        f"{len(belongs_edges)} domain memberships, {len(import_edges)} import edges.",
        "",
    ]
    for domain in sorted(by_domain.keys()):
        nodes = by_domain[domain]
        lines += [f"### {domain} ({len(nodes)})", ""]
        rows = [
            [n.name, n.path, str((n.meta or {}).get("role") or "")[:90]]
            for n in nodes
        ]
        lines += [_md_table(["Module", "Path", "Role"], rows), ""]

    # ── Domains ──────────────────────────────────────────────────────────────
    lines += ["## Domains", ""]
    if domain_nodes:
        domain_rows = [
            [
                d.name,
                str(len(by_domain.get(d.name, []))),
                str((d.meta or {}).get("description") or ""),
            ]
            for d in domain_nodes
        ]
        lines += [_md_table(["Domain", "Modules", "Description"], domain_rows), ""]

    # ── Phases ────────────────────────────────────────────────────────────────
    lines += ["## Phases", ""]
    current_phase = phases.get("current")
    lines.append(f"Current: **Phase {current_phase}**")
    lines.append("")
    upcoming = phases.get("upcoming") or []
    phase_rows = []
    for p in upcoming:
        if isinstance(p, dict):
            phase_rows.append([
                str(p.get("phase") or p.get("id") or ""),
                str(p.get("name") or ""),
                str(p.get("status") or ""),
            ])
    if phase_rows:
        lines += [_md_table(["Phase", "Name", "Status"], phase_rows), ""]

    # ── Constraints ──────────────────────────────────────────────────────────
    lines += ["## Constraints", ""]
    constraint_rows = []
    for c in constraints:
        if isinstance(c, dict):
            rule = str(c.get("rule") or "").replace("\n", " ").strip()
            constraint_rows.append([
                str(c.get("id") or ""),
                rule[:100] + ("…" if len(rule) > 100 else ""),
                str(c.get("severity") or ""),
            ])
    if constraint_rows:
        lines += [_md_table(["ID", "Rule", "Severity"], constraint_rows), ""]

    return "\n".join(lines) + "\n\n" + cli_surface_markdown_section()


# ── MAP.md codebase section ───────────────────────────────────────────────────

def _generate_codebase_section(graph: Any, today: str) -> str:
    by_domain = _modules_by_domain(graph)
    total = sum(len(v) for v in by_domain.values())
    import_edges = [e for e in graph.edges if e.relation == "imports"]
    belongs_edges = [e for e in graph.edges if e.relation == "belongs_to"]

    lines: list[str] = [
        _CODEBASE_START,
        f"_Generated by `forge map` on {today}. "
        "Do not edit — re-run `forge map` to update._",
        "",
        f"**{len(graph.nodes)} nodes** · **{len(graph.edges)} edges** "
        f"({len(belongs_edges)} domain memberships, {len(import_edges)} import links) "
        f"across **{len(by_domain)} domains**:",
        "",
    ]

    for domain in sorted(by_domain.keys()):
        nodes = by_domain[domain]
        lines.append(f"**{domain}** — {len(nodes)} modules")
        for n in nodes:
            meta = n.meta or {}
            role = str(meta.get("role") or "")
            role_part = f" — {role}" if role else ""
            lines.append(f"- `{n.path}`{role_part}")
        lines.append("")

    lines.append(_CODEBASE_END)
    return "\n".join(lines)


def _splice_map_md(existing: str, codebase_section: str, today: str) -> str:
    """Replace codebase section in MAP.md; update last_updated frontmatter."""
    # Update last_updated in YAML frontmatter
    updated = re.sub(
        r"^last_updated:.*$",
        f"last_updated: {today}",
        existing,
        flags=re.MULTILINE,
    )

    if _CODEBASE_START in updated and _CODEBASE_END in updated:
        # Markers present — precise replacement
        pattern = re.escape(_CODEBASE_START) + r".*?" + re.escape(_CODEBASE_END)
        updated = re.sub(pattern, codebase_section, updated, flags=re.DOTALL)
    else:
        # First run — replace the "## Codebase at a glance" section prose
        pattern = r"(## Codebase at a glance\n\n?).*?(?=\n## |\Z)"
        replacement = r"\g<1>" + codebase_section + "\n"
        new = re.sub(pattern, replacement, updated, flags=re.DOTALL)
        if new == updated:
            # Section not found — append
            updated = updated.rstrip("\n") + f"\n\n## Codebase at a glance\n\n{codebase_section}\n"
        else:
            updated = new

    return updated


# ── Main entry ────────────────────────────────────────────────────────────────

def run_map(
    project_path: str,
    dry_run: bool = False,
    target: str = "all",
) -> None:
    root = resolve_project_path(project_path)

    try:
        from forge.tools.manifest.graph import (
            build_manifest_graph,
            merge_stack_glove_scan_into_graph,
            save_graph,
        )
    except ImportError as exc:
        click.echo(f"✗ Cannot import build_manifest_graph: {exc}", err=True)
        sys.exit(1)

    graph = build_manifest_graph(root)
    merge_stack_glove_scan_into_graph(graph)
    if not dry_run:
        save_graph(graph)
    raw = _load_manifest_raw(root)
    today = str(date.today())

    module_count = sum(1 for n in graph.nodes if n.kind == "module")
    domain_count = sum(1 for n in graph.nodes if n.kind == "domain")

    click.echo("── forge map ───────────────────────────────────────────────")
    click.echo(f"   project : {root}")
    click.echo(
        f"   graph   : {module_count} modules, {domain_count} domains, "
        f"{len(graph.edges)} edges"
    )
    click.echo(f"   target  : {target}")
    if dry_run:
        click.echo("   mode    : dry-run (no files written)")
    click.echo()

    docs_dir = root / "docs"
    wrote: list[str] = []

    # ── JSON context cache — write before markdown render ────────────────────
    if not dry_run:
        try:
            from forge.tools.manifest.context_generator import generate_agent_context_json
            json_path = generate_agent_context_json(root)
            click.echo(f"  ✓ wrote .forge/agent_context.json")
            wrote.append(str(json_path.relative_to(root)))
        except Exception as exc:
            click.echo(f"  ⚠ agent_context.json skipped: {exc}", err=True)

    # ── MANIFEST.md ──────────────────────────────────────────────────────────
    if target in ("manifest", "all"):
        manifest_md = _generate_manifest_md(graph, raw, today)
        manifest_path = docs_dir / "MANIFEST.md"

        if dry_run:
            preview = manifest_md.splitlines()
            click.echo("── MANIFEST.md (preview, first 40 lines) ───────────────────")
            for line in preview[:40]:
                click.echo(f"  {line}")
            click.echo(f"  … ({len(preview)} lines total)")
            click.echo()
        else:
            docs_dir.mkdir(parents=True, exist_ok=True)
            manifest_path.write_text(manifest_md, encoding="utf-8")
            click.echo(f"  ✓ wrote docs/MANIFEST.md  ({len(manifest_md.splitlines())} lines)")
            wrote.append("docs/MANIFEST.md")

    # ── MAP.md ───────────────────────────────────────────────────────────────
    if target in ("map", "all"):
        codebase_section = _generate_codebase_section(graph, today)
        map_path = docs_dir / "MAP.md"

        if map_path.is_file():
            existing = map_path.read_text(encoding="utf-8")
            map_md = _splice_map_md(existing, codebase_section, today)
        else:
            map_md = (
                f"---\nlast_updated: {today}\ngenerated_by: forge map\n---\n\n"
                f"## Codebase at a glance\n\n{codebase_section}\n"
            )

        if dry_run:
            preview = map_md.splitlines()
            click.echo("── MAP.md (preview, first 40 lines) ────────────────────────")
            for line in preview[:40]:
                click.echo(f"  {line}")
            click.echo(f"  … ({len(preview)} lines total)")
            click.echo()
        else:
            docs_dir.mkdir(parents=True, exist_ok=True)
            map_path.write_text(map_md, encoding="utf-8")
            click.echo(f"  ✓ wrote docs/MAP.md  ({len(map_md.splitlines())} lines)")
            wrote.append("docs/MAP.md")

    if not dry_run:
        click.echo()
        if wrote:
            click.echo(
                "✓ Done. Run `forge impact-check` to confirm doc obligations satisfied."
            )
        else:
            click.echo("  (nothing written)")


# ── scope=global ─────────────────────────────────────────────────────────────

def _fmt_global(fmt: str) -> str:
    """Cross-project summary from ~/.forge/registry.yaml.

    Loads each registered project's manifest graph to populate domain/module
    counts.  Graph load failures are silently suppressed — the project row
    still appears with zero counts.
    """
    from forge.tools.registry.store import load_registry
    from forge.tools.manifest.graph import build_manifest_graph

    registry = load_registry()
    projects = dict(registry.get("projects") or {})

    rows: list[tuple[str, str, str, str, int, int]] = []
    for slug, proj in sorted(projects.items()):
        if not isinstance(proj, dict):
            continue
        proj_path = resolve_project_path(str(proj.get("path", "")))
        stack = str(proj.get("stack") or "unknown")
        phase = str(proj.get("phase") or "?")
        status = str(proj.get("status") or "active")
        domains = 0
        modules = 0
        if proj_path.is_dir():
            try:
                g = build_manifest_graph(proj_path)
                domains = sum(1 for n in g.nodes if n.kind == "domain")
                modules = sum(1 for n in g.nodes if n.kind == "module")
            except Exception:
                pass
        rows.append((slug, stack, phase, status, domains, modules))

    if fmt == "md":
        table_rows = [
            [slug, stack, phase, status, str(d), str(m)]
            for slug, stack, phase, status, d, m in rows
        ]
        lines = [
            "# Workspace — All Projects",
            "_Generated by `forge map --scope global`_",
            "",
            _md_table(
                ["Project", "Stack", "Phase", "Status", "Domains", "Modules"],
                table_rows,
            ),
            "",
        ]
        return "\n".join(lines)

    elif fmt == "mermaid":
        lines = ["graph LR"]
        for slug, stack, _phase, _status, _d, modules in rows:
            mid = re.sub(r"[^a-zA-Z0-9]", "_", slug)
            lines.append(f'  {mid}["{slug}\\n{stack} · {modules}m"]')
        for slug, proj in sorted(projects.items()):
            if not isinstance(proj, dict):
                continue
            relations = proj.get("relations") or {}
            for tgt in (relations.get("depends_on") or []):
                src = re.sub(r"[^a-zA-Z0-9]", "_", slug)
                dst = re.sub(r"[^a-zA-Z0-9]", "_", str(tgt))
                lines.append(f"  {src} -->|depends_on| {dst}")
        return "\n".join(lines)

    else:
        import json
        return json.dumps(
            {
                "projects": [
                    {
                        "slug": slug,
                        "stack": stack,
                        "phase": phase,
                        "status": status,
                        "domains": d,
                        "modules": m,
                    }
                    for slug, stack, phase, status, d, m in rows
                ]
            },
            indent=2,
        )


# ── scope=sub-local helpers ───────────────────────────────────────────────────

def _extract_dart_symbols(text: str) -> list[dict[str, Any]]:
    symbols: list[dict[str, Any]] = []
    # Classes (including abstract, mixin, extension)
    for m in re.finditer(
        r"^(?:abstract\s+)?(?:class|mixin|extension)\s+(\w+)", text, re.MULTILINE
    ):
        line = text[: m.start()].count("\n") + 1
        symbols.append({"kind": "class", "name": m.group(1), "line": line})
    # Getters:  Type get name => / Type get name {
    for m in re.finditer(
        r"(?m)^\s*(?:[\w<>\[\]?]+\s+)?get\s+(\w+)\s*(?:=>|\{)", text
    ):
        line = text[: m.start()].count("\n") + 1
        symbols.append({"kind": "getter", "name": m.group(1), "line": line})
    # Methods: indented lines starting with a known return type or modifier.
    # Type tokens may carry generic params (e.g. Future<void>, List<String>).
    for m in re.finditer(
        r"^  (?:(?:static|async|override|Future|void|String|int|bool|double|"
        r"List|Map|Set|dynamic|Widget|Stream)(?:<[^>]+>)?\s+)+(\w+)\s*[(<]",
        text,
        re.MULTILINE,
    ):
        name = m.group(1)
        if name in ("get", "set", "if", "for", "while", "return", "switch"):
            continue
        line = text[: m.start()].count("\n") + 1
        symbols.append({"kind": "method", "name": name, "line": line})
    return sorted(symbols, key=lambda s: int(s.get("line", 0)))


def _extract_python_symbols(text: str) -> list[dict[str, Any]]:
    import ast

    symbols: list[dict[str, Any]] = []
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            symbols.append({"kind": "class", "name": node.name, "line": node.lineno})
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    kind = (
                        "getter"
                        if any(
                            (isinstance(d, ast.Name) and d.id == "property")
                            for d in item.decorator_list
                        )
                        else "method"
                    )
                    symbols.append(
                        {
                            "kind": kind,
                            "name": f"{node.name}.{item.name}",
                            "line": item.lineno,
                        }
                    )
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            symbols.append({"kind": "function", "name": node.name, "line": node.lineno})
    symbols.sort(key=lambda s: int(s.get("line", 0)))
    return symbols


def _extract_generic_symbols(text: str) -> list[dict[str, Any]]:
    symbols: list[dict[str, Any]] = []
    for m in re.finditer(
        r"^(?:class|interface|struct|def|func|fn)\s+(\w+)", text, re.MULTILINE
    ):
        line = text[: m.start()].count("\n") + 1
        symbols.append({"kind": "symbol", "name": m.group(1), "line": line})
    return symbols


def _extract_symbols(path: Path, text: str) -> list[dict[str, Any]]:
    """Dispatch to language-specific symbol extractor."""
    suffix = path.suffix.lower()
    if suffix == ".py":
        return _extract_python_symbols(text)
    if suffix == ".dart":
        return _extract_dart_symbols(text)
    return _extract_generic_symbols(text)


# ── scope=sub-local ───────────────────────────────────────────────────────────

def _fmt_sub_local(file_path: str, project_path: str) -> str:
    """Single-file floor plan: declared symbols + which manifest nodes consume this file.

    Only md format is supported — caller should guard before reaching here.
    """
    root = resolve_project_path(project_path)
    target = Path(file_path).expanduser().resolve()

    if not target.is_file():
        return f"File not found: {target}\n"

    try:
        rel = str(target.relative_to(root)).replace("\\", "/")
    except ValueError:
        rel = str(target)

    text = target.read_text(encoding="utf-8", errors="ignore")
    symbols = _extract_symbols(target, text)

    # Graph lookup — find which manifest nodes import this file
    self_node = None
    consumers: list[str] = []
    try:
        from forge.tools.manifest.graph import build_manifest_graph, find_node_id_for_path  # noqa: PLC0415

        g = build_manifest_graph(root)
        nid = find_node_id_for_path(g, rel)
        if nid:
            by_id = {n.id: n for n in g.nodes}
            self_node = by_id.get(nid)
            consumers = sorted(
                {e.from_id for e in g.edges if e.relation == "imports" and e.to_id == nid}
            )
    except Exception:
        pass

    lines: list[str] = [
        f"# File floor plan — `{rel}`",
        "_Generated by `forge map --scope sub-local`_",
        "",
    ]

    # ── Manifest identity ─────────────────────────────────────────────────────
    lines += ["## Manifest node", ""]
    if self_node:
        lines += [
            _md_table(
                ["Field", "Value"],
                [
                    ["id", str(self_node.id)],
                    ["kind", str(self_node.kind)],
                    ["domain", str(self_node.domain or "—")],
                    ["path", str(self_node.path or rel)],
                ],
            ),
            "",
        ]
    else:
        lines += [f"_(not registered in manifest — `{rel}`)_", ""]

    # ── Symbols ───────────────────────────────────────────────────────────────
    lines += ["## Symbols", ""]
    if symbols:
        sym_rows = [[s["kind"], s["name"], str(s.get("line", ""))] for s in symbols]
        lines += [_md_table(["Kind", "Name", "Line"], sym_rows), ""]
    else:
        lines += ["_(no symbols extracted)_", ""]

    # ── Consumers ─────────────────────────────────────────────────────────────
    lines += ["## Consumed by", ""]
    if consumers:
        for c in consumers:
            lines.append(f"- `{c}`")
        lines.append("")
    else:
        lines += ["_(no registered nodes import this file)_", ""]

    return "\n".join(lines)


# ── Stdout formatters ────────────────────────────────────────────────────────


def _mermaid_id(node_id: str) -> str:
    """Convert 'module/core.manifest' → 'core_manifest' for mermaid node IDs."""
    name = node_id.split("/", 1)[-1]
    return re.sub(r"[^a-zA-Z0-9]", "_", name)


def _fmt_md(
    graph: Any,
    raw: dict[str, Any],
    domain_filter: str | None = None,
    edges: bool = False,
    glove_data: dict[str, Any] | None = None,
) -> str:
    """Markdown project-map report — printed to stdout."""
    _app = raw.get("app") if isinstance(raw.get("app"), dict) else {}
    project_name = str(raw.get("name") or _app.get("name") or "unknown")
    known_broken: list[str] = list(raw.get("known_broken") or [])

    _WIRING = {"watches", "depends_on", "imports", "calls_service"}
    _by_id = {nd.id: nd for nd in graph.nodes}

    def _trunc(names: list[str], limit: int = 3) -> str:
        if len(names) <= limit:
            return ", ".join(names)
        return ", ".join(names[:limit]) + f" +{len(names) - limit} more"

    by_domain = _modules_by_domain(graph)
    if domain_filter:
        by_domain = {k: v for k, v in by_domain.items() if k == domain_filter.upper()}

    domain_nodes = sorted(
        (n for n in graph.nodes if n.kind == "domain"),
        key=lambda n: n.name,
    )
    if domain_filter:
        domain_nodes = [d for d in domain_nodes if d.name == domain_filter.upper()]

    lines: list[str] = [
        f"# Project Map — {project_name}",
        "_Generated by `forge map`_",
        "",
    ]

    # ── Domains ──────────────────────────────────────────────────────────────
    lines += ["## Domains", ""]
    domain_rows = []
    for d in domain_nodes:
        members = by_domain.get(d.name, [])
        member_ids = {f"module/{n.name}" for n in members}
        edge_count = sum(
            1 for e in graph.edges
            if e.relation == "imports"
            and e.from_id in member_ids
            and e.to_id in member_ids
        )
        domain_rows.append([d.name, str(len(members)), str(edge_count)])
    if domain_rows:
        lines += [_md_table(["Domain", "Modules", "Internal edges"], domain_rows), ""]
    else:
        lines += ["_(no domains)_", ""]

    # ── Modules ──────────────────────────────────────────────────────────────
    lines += ["## Modules", ""]
    all_nodes = sorted(
        (n for v in by_domain.values() for n in v),
        key=lambda n: n.name,
    )
    module_rows = []
    for n in all_nodes:
        role = str((n.meta or {}).get("role") or n.kind)[:80]
        dep_names = [
            _by_id[e.to_id].name
            for e in graph.edges
            if e.from_id == n.id and e.relation in _WIRING and e.to_id in _by_id
        ]
        con_names = [
            _by_id[e.from_id].name
            for e in graph.edges
            if e.to_id == n.id and e.relation in _WIRING and e.from_id in _by_id
        ]
        module_rows.append([n.name, role, _trunc(dep_names), _trunc(con_names)])
    if module_rows:
        lines += [
            _md_table(
                ["Module", "Role", "Depends on", "Consumed by"],
                module_rows,
            ),
            "",
        ]

    if glove_data:
        composer_section = _render_composer_section(glove_data)
        if composer_section:
            lines.append(composer_section)

    # ── Dependencies ─────────────────────────────────────────────────────────
    if edges:
        import_edges = [e for e in graph.edges if e.relation == "imports"]
        # filter to nodes in scope
        included_ids = {n.id for nodes in by_domain.values() for n in nodes}
        scoped_edges = [
            e for e in import_edges
            if e.from_id in included_ids and e.to_id in included_ids
        ]
        lines += ["## Dependencies", ""]
        if scoped_edges:
            for e in scoped_edges:
                src_name = e.from_id.split("/", 1)[-1]
                dst_name = e.to_id.split("/", 1)[-1]
                lines.append(f"- {src_name} → {dst_name}")
            lines.append("")
        else:
            lines += ["_(no imports edges)_", ""]

    # ── Known Broken ─────────────────────────────────────────────────────────
    if known_broken:
        lines += ["## Known Broken", ""]
        for item in known_broken:
            lines.append(f"- {item}")
        lines.append("")

    return "\n".join(lines)


def _fmt_mermaid(
    graph: Any,
    domain_filter: str | None = None,
    edges: bool = False,
) -> str:
    """Mermaid TD diagram — modules as nodes, grouped by domain.

    Pass edges=True to emit imports edges as directed arrows between nodes.
    """
    by_domain = _modules_by_domain(graph)
    if domain_filter:
        by_domain = {k: v for k, v in by_domain.items() if k == domain_filter.upper()}

    included_ids = {f"module/{n.name}" for nodes in by_domain.values() for n in nodes}

    lines: list[str] = ["graph TD"]

    # Subgraph per domain
    for domain in sorted(by_domain.keys()):
        nodes = by_domain[domain]
        lines.append(f"  subgraph {domain}")
        for n in nodes:
            mid = _mermaid_id(f"module/{n.name}")
            lines.append(f'    {mid}["{n.name}"]')
        lines.append("  end")

    # Import edges — only when --edges is active
    if edges:
        import_arrows = [
            e for e in graph.edges
            if e.relation == "imports"
            and e.from_id in included_ids
            and e.to_id in included_ids
        ]
        if import_arrows:
            lines.append("")
            for e in import_arrows:
                src = _mermaid_id(e.from_id)
                dst = _mermaid_id(e.to_id)
                lines.append(f"  {src} --> {dst}")

    return "\n".join(lines)


def _fmt_json(
    graph: Any,
    domain_filter: str | None = None,
    glove_data: dict[str, Any] | None = None,
) -> str:
    """Raw graph as JSON — mirrors forge_manifest_graph(format=full)."""
    import json

    by_domain = _modules_by_domain(graph)
    if domain_filter:
        included_ids = {
            f"module/{n.name}"
            for nodes in by_domain.values()
            for n in nodes
            if n.domain == domain_filter.upper()
        }
    else:
        included_ids = None  # all

    nodes_out = []
    for n in graph.nodes:
        if included_ids is not None and n.id not in included_ids:
            if n.kind != "domain":
                continue
        nodes_out.append({
            "id": n.id,
            "kind": n.kind,
            "name": n.name,
            "path": n.path,
            "domain": n.domain,
            "meta": n.meta or {},
        })

    edges_out = []
    for e in graph.edges:
        if included_ids is not None:
            if e.from_id not in included_ids and e.to_id not in included_ids:
                continue
        edges_out.append({
            "from": e.from_id,
            "to": e.to_id,
            "relation": e.relation,
            "derived": e.derived,
        })

    payload: dict[str, Any] = {"nodes": nodes_out, "edges": edges_out}
    payload.update(_glove_json_payload(glove_data or {}))
    return json.dumps(payload, indent=2)


# ── Click command ─────────────────────────────────────────────────────────────

@click.command("map")
@click.option(
    "--scope",
    "scope",
    default="project",
    show_default=True,
    type=click.Choice(["global", "project", "local", "sub-local"]),
    help="global=all domains, project=full graph, local=one domain, sub-local=one node+1hop",
)
@click.option(
    "--format", "fmt",
    default="md",
    show_default=True,
    type=click.Choice(["md", "mermaid", "json"]),
    help="md=markdown, mermaid=diagram, json=raw graph",
)
@click.option(
    "--domain",
    "domain",
    default=None,
    metavar="NAME",
    help="Filter to one domain (use with --scope local).",
)
@click.option(
    "--output",
    "output",
    default=None,
    metavar="FILE",
    help="Write output to FILE instead of stdout.",
)
@click.option(
    "--project-path",
    "project_path",
    default=".",
    show_default=True,
    metavar="PATH",
    help="Project root (default: cwd).",
)
@click.option(
    "--file",
    "file_path",
    default=None,
    metavar="FILE",
    help="Source file to inspect (required for --scope sub-local).",
)
@click.option(
    "--edges",
    "edges",
    is_flag=True,
    default=False,
    help="Include imports edges in output (md: Dependencies section; mermaid: arrows).",
)
@click.option(
    "--write-docs",
    "write_docs",
    is_flag=True,
    default=False,
    help="Write docs/MAP.md, docs/MANIFEST.md, and .forge/agent_context.json (regeneration).",
)
@click.option(
    "--docs-dry-run",
    "docs_dry_run",
    is_flag=True,
    default=False,
    help="With --write-docs: preview only, do not write files.",
)
@response_tier_option(default="L1")
def map_cmd(
    scope: str,
    fmt: str,
    domain: str | None,
    output: str | None,
    project_path: str,
    file_path: str | None,
    edges: bool,
    write_docs: bool,
    docs_dry_run: bool,
    response_tier: str,
) -> None:
    """Print a project map to stdout (markdown, mermaid, or JSON).

    scope=project renders the full graph; scope=local requires --domain.
    scope=global renders a cross-project summary from ~/.forge/registry.yaml.
    scope=sub-local renders a single-file floor plan; requires --file <path>.
    Use --output FILE to write to a file instead of stdout.
    Use --write-docs to regenerate committed docs under docs/ (MAP, MANIFEST) + JSON context.

    \b
    Examples:
      forge map
      forge map --format mermaid
      forge map --write-docs
      forge map --scope local --domain TOOLS
      forge map --scope global
      forge map --scope sub-local --file lib/features/lobby/lobby_controller.dart
      forge map --format json --output graph.json
    """
    _ = response_tier
    # ── Regenerate MAP.md / MANIFEST.md / agent_context.json ─────────────────
    if write_docs:
        bad: list[str] = []
        if scope != "project":
            bad.append("--write-docs requires default --scope project")
        if fmt != "md":
            bad.append("--write-docs: use default --format md")
        if output:
            bad.append("--write-docs: do not pass --output")
        if file_path:
            bad.append("--write-docs: do not pass --file")
        if edges:
            bad.append("--write-docs: do not pass --edges")
        if domain:
            bad.append("--write-docs: do not pass --domain")
        if bad:
            click.echo("✗ " + "; ".join(bad), err=True)
            sys.exit(1)
        run_map(project_path, dry_run=docs_dry_run, target="all")
        return

    # ── scope=global ──────────────────────────────────────────────────────────
    if scope == "global":
        if fmt not in ("md", "mermaid"):
            click.echo("✗ --scope global supports --format md and mermaid only", err=True)
            sys.exit(1)
        text = _fmt_global(fmt)
        if output:
            Path(output).write_text(text, encoding="utf-8")
            click.echo(f"  ✓ wrote {output}", err=True)
        else:
            click.echo(text)
        return

    # ── scope=sub-local ───────────────────────────────────────────────────────
    if scope == "sub-local":
        if not file_path:
            click.echo("✗ --scope sub-local requires --file <path>", err=True)
            sys.exit(1)
        if fmt != "md":
            click.echo("✗ --scope sub-local supports --format md only", err=True)
            sys.exit(1)
        text = _fmt_sub_local(file_path, project_path)
        if output:
            Path(output).write_text(text, encoding="utf-8")
            click.echo(f"  ✓ wrote {output}", err=True)
        else:
            click.echo(text)
        return

    # ── scope=project / local ─────────────────────────────────────────────────
    root = resolve_project_path(project_path)

    try:
        from forge.tools.manifest.graph import (
            build_manifest_graph,
            merge_stack_glove_scan_into_graph,
            save_graph,
        )
    except ImportError as exc:
        click.echo(f"✗ Cannot import build_manifest_graph: {exc}", err=True)
        sys.exit(1)

    if scope == "local" and not domain:
        click.echo("✗ --scope local requires --domain <NAME>", err=True)
        sys.exit(1)

    graph = build_manifest_graph(root)
    merge_stack_glove_scan_into_graph(graph)
    save_graph(graph)
    raw = _load_manifest_raw(root)
    stack = _get_stack(root)
    glove_data = _load_glove_data(root, stack)
    domain_filter = domain.upper() if domain else None

    if fmt == "md":
        text = _fmt_md(
            graph,
            raw,
            domain_filter=domain_filter,
            edges=edges,
            glove_data=glove_data,
        )
    elif fmt == "mermaid":
        text = _fmt_mermaid(graph, domain_filter=domain_filter, edges=edges)
    else:  # json
        text = _fmt_json(graph, domain_filter=domain_filter, glove_data=glove_data)

    if output:
        Path(output).write_text(text, encoding="utf-8")
        click.echo(f"  ✓ wrote {output}", err=True)
    else:
        click.echo(text)
