import os
import re
import shutil
import subprocess
import json
from datetime import datetime
from pathlib import Path

import click

from forge.commands._shared_options import response_tier_option
from forge.core.result import ForgeResult
from forge.core.template import TemplateEngine
from forge.core.scaffolder import Scaffolder
from forge.core.global_config import GlobalConfig
from forge.core.discovery import get_projects_root
from forge.core.path_utils import resolve_project_path

# Placeholder prompts: (prompt_text, choices or None for free text)
PLACEHOLDER_PROMPTS: dict[str, tuple[str, list[str] | None]] = {
    "FRONTEND": ("Frontend framework?", ["react", "vue", "vanilla"]),
    "BACKEND": ("Backend?", ["supabase", "firebase", "none"]),
    "HOSTING": ("Hosting?", ["vercel", "netlify", "self-hosted", "none"]),
    "LANGUAGE": ("Language?", ["typescript", "javascript"]),
    "STYLING": ("Styling?", ["tailwind", "css-modules", "styled-components", "none"]),
    "DEV_PORT": ("Port", None),
    "PACKAGING": ("Python packaging?", ["pyproject.toml", "setup.py", "requirements.txt"]),
    "TUI": ("TUI framework?", ["textual", "curses", "click", "none"]),
    "ENTRYPOINT": ("CLI entry point path?", None),
    "MIN_PYTHON": ("Minimum Python version?", None),
}

DEFAULT_DEV_PORT = "5173"
DEFAULT_MIN_PYTHON = "3.11"

DOMAIN_SUGGESTIONS = [
    "game", "productivity", "service", "utility",
    "health", "finance", "social", "creative",
    "developer-tool",
]


def slugify(name: str) -> str:
    """MyProject → my-project, CleanOps → cleanops"""
    return name.lower().replace(" ", "-").replace("_", "-")


def _placeholders_in_template(project_type: str) -> set[str]:
    """Return set of {{PLACEHOLDER}} keys in the type template."""
    root = Path(__file__).resolve().parent.parent.parent
    templates_dir = root / "templates"
    path = templates_dir / f"{project_type}.manifest.yaml"
    if not path.exists():
        return set()
    text = path.read_text()
    return set(re.findall(r"\{\{([A-Za-z0-9_]+)\}\}", text))


def _get_hooks_dir() -> Path:
    root = Path(__file__).resolve().parent.parent.parent
    return root / "hooks"


def _prompt_choice(
    label: str,
    choices: list[str],
    default_index: int = 0,
) -> str:
    """
    Shows numbered vertical list, accepts number or name (case-insensitive).
    Returns the chosen value. Reprompts on invalid input.
    """
    click.echo(f"{label}:")
    for i, choice in enumerate(choices, 1):
        marker = " (default)" if i == default_index + 1 else ""
        click.echo(f"  {i}. {choice}{marker}")

    while True:
        raw = click.prompt("Choice", default=str(default_index + 1))
        try:
            idx = int(raw) - 1
            if 0 <= idx < len(choices):
                return choices[idx]
        except ValueError:
            pass
        lower = raw.lower().strip()
        for choice in choices:
            if choice.lower() == lower:
                return choice
        click.echo(f"  Please enter a number (1-{len(choices)}) or one of: {', '.join(choices)}")


@click.command(name="new")
@click.argument("name", required=False)
@click.option("--name", "name_opt", default=None, help="Project name (for --non-interactive mode).")
@click.option("--type", "project_type", default=None, help="Project type")
@click.option("--stack", "stack_id", default=None, help="Stack id (for --non-interactive mode).")
@click.option("--path", "project_path", default=None, help="Parent directory (default: ~/Projects/)")
@click.option("--no-git", is_flag=True, default=False, help="Skip git initialisation")
@click.option("--dry-run", is_flag=True, default=False, help="Show what would be created without creating it")
@click.option("--non-interactive", is_flag=True, default=False, help="Disable prompts and require explicit inputs.")
@response_tier_option(default="L1")
def new_cmd(
    name: str | None,
    name_opt: str | None,
    project_type: str | None,
    stack_id: str | None,
    project_path: str | None,
    no_git: bool,
    dry_run: bool,
    non_interactive: bool,
    response_tier: str,
) -> None:
    """
    Scaffold a new Forge project interactively.

    Prompts for any missing arguments.
    Generates manifest.yaml from template.
    Creates directory structure for the project type.
    Initialises git and installs Forge hooks.

    After `forge new` creates a project, register it with: forge projects add .
    """
    if not non_interactive:
        click.echo("✦ forge new  (run with --help to see all options)")
        click.echo("")

    types = sorted(TemplateEngine.get_available_types())
    if not types:
        click.echo("No project types found. Run: forge doctor")
        raise SystemExit(1)

    if non_interactive:
        name = (name_opt or name or "").strip()
        if not name:
            click.echo("Missing required option for --non-interactive: --name")
            raise SystemExit(1)
        if not stack_id:
            click.echo("Missing required option for --non-interactive: --stack")
            raise SystemExit(1)
        if not project_path:
            click.echo("Missing required option for --non-interactive: --path")
            raise SystemExit(1)
        stack_to_type = {
            "python-cli": "python",
            "web-next": "web",
            "web-react": "web",
            "flutter-app": "flutter",
        }
        project_type = stack_to_type.get(str(stack_id), str(stack_id))

    # Step 1 — Project name
    if not name:
        name = click.prompt("Project name?").strip()
    if not name:
        click.echo("Project name is required.")
        raise SystemExit(1)
    if " " in name:
        suggested = slugify(name)
        if click.confirm(f"Use slug '{suggested}' as directory name?", default=True):
            name = suggested.replace("-", " ").title()
        else:
            name = name.strip()
    slug = slugify(name)

    root = get_projects_root()
    resolved_path = (resolve_project_path(project_path) if project_path else root)
    if not resolved_path.exists():
        resolved_path = root
    project_dir = resolved_path / slug
    if project_dir.exists() and any(project_dir.iterdir()):
        click.echo(f"Directory already exists and is non-empty: {project_dir}")
        raise SystemExit(1)

    # Step 2 — Project type
    if not project_type:
        if len(types) == 1:
            project_type = types[0]
        else:
            project_type = _prompt_choice("Project type", types, default_index=0)
    if project_type not in types:
        click.echo(f"Unknown type '{project_type}'. Available: {types}")
        raise SystemExit(1)

    # Step 3 — Type-specific tokens from template placeholders
    config = GlobalConfig.load()
    owner_name = config.get("owner.name") or ""
    owner_role = config.get("owner.role") or ""
    github = config.get("owner.github") or ""
    if not owner_name and not non_interactive:
        owner_name = click.prompt("Owner name", default="")
        config.set("owner.name", owner_name)
    if not owner_role and not non_interactive:
        owner_role = click.prompt("Owner role", default="")
        config.set("owner.role", owner_role)
    if not github and not non_interactive:
        github = click.prompt("GitHub username", default="")
        config.set("owner.github", github)
    if not github:
        github = "user"
    tokens = {
        "PROJECT_NAME": name,
        "PROJECT_TYPE": project_type,
        "PROJECT_SLUG": slug,
        "OWNER_NAME": owner_name,
        "OWNER_ROLE": owner_role,
        "REPO_URL": f"github.com/{github}/{slug}",
    }

    placeholders = _placeholders_in_template(project_type)
    for key in ("PROJECT_NAME", "PROJECT_TYPE", "PROJECT_SLUG", "OWNER_NAME", "OWNER_ROLE", "REPO_URL"):
        placeholders.discard(key)
    for key in sorted(placeholders):
        prompt_info = PLACEHOLDER_PROMPTS.get(key)
        if prompt_info:
            prompt_text, choices = prompt_info
            if non_interactive:
                if choices:
                    val = choices[0]
                elif key == "DEV_PORT":
                    val = DEFAULT_DEV_PORT
                elif key == "MIN_PYTHON":
                    val = DEFAULT_MIN_PYTHON
                else:
                    val = ""
                tokens[key] = val
                continue
            if choices:
                label = prompt_text.rstrip("?").strip()
                val = _prompt_choice(label, choices, default_index=0)
            else:
                if key == "DEV_PORT":
                    click.echo("Dev server port (localhost port for development server)")
                    click.echo("  Vite default: 5173   CRA default: 3000")
                    val = click.prompt(prompt_text, default=DEFAULT_DEV_PORT)
                elif key == "MIN_PYTHON":
                    val = click.prompt(prompt_text, default=DEFAULT_MIN_PYTHON)
                else:
                    val = click.prompt(prompt_text, default="")
            tokens[key] = val
        elif key == "APP_DOMAIN":
            if non_interactive:
                tokens[key] = ""
                continue
            click.echo("App domain suggestions:")
            click.echo("  game           productivity    service")
            click.echo("  utility        health          finance")
            click.echo("  social         creative        developer-tool")
            click.echo("")
            click.echo("Enter a value (or press Enter to skip):")
            tokens[key] = click.prompt("APP_DOMAIN", default="")
        else:
            tokens[key] = click.prompt(f"{key}?", default="")

    # Docs tokens
    tokens["DATE"] = datetime.now().strftime("%Y-%m-%d")
    tokens["ENTRYPOINT"] = {
        "flutter": "lib/main.dart",
        "web": "src/main.jsx",
        "python": f"{slug}/cli.py",
        "unknown": "—",
    }.get(project_type, "—")
    tokens["CONFIG_PATH"] = {
        "flutter": "assets/app_config.yaml",
        "web": "src/config/site.config.js",
        "python": "pyproject.toml",
        "unknown": "—",
    }.get(project_type, "—")
    tokens["CURRENT_PHASE"] = "1"
    tokens["PHASE_NAME"] = "Foundation"
    tokens["PHASE_TABLE"] = "| 1 | Foundation | in_progress |"
    tokens["ADR_TABLE"] = "| — | No ADRs yet | — |"
    tokens["DOMAIN_TABLE"] = "| — | — | — |"
    tokens["DEPENDENCY_MAP"] = "(fill in as project develops)"
    tokens["SRP_DESCRIPTION"] = "Screens are routers only. Logic in controllers/hooks."
    tokens["OCP_DESCRIPTION"] = f"New {project_type} features add files, not edits."
    tokens["DIP_DESCRIPTION"] = "Components depend on abstractions, not concretions."
    tokens["RENDERER_DESCRIPTION"] = (
        "N/A" if project_type != "python" else "renderers/ layer separates UI from core logic."
    )
    if "VERSION" not in tokens:
        tokens["VERSION"] = tokens.get("version", "0.1.0")
    for key in ("LANGUAGE", "RATIONALE", "STATE", "PROJECT_SPECIFIC_ANTIPATTERN_1", "PROJECT_SPECIFIC_ANTIPATTERN_2"):
        if key not in tokens:
            tokens[key] = "—"
    if "variant_key" not in tokens:
        tokens["variant_key"] = "—"
    if "active" not in tokens:
        tokens["active"] = "—"
    if "available" not in tokens:
        tokens["available"] = "—"
    tokens["project_slug"] = slug
    if "feature" not in tokens:
        tokens["feature"] = "—"

    # Step 4 — Confirmation
    backend = tokens.get("BACKEND", "—")
    hosting = tokens.get("HOSTING", "—")
    if not non_interactive:
        click.echo("")
        click.echo("  Name:     " + name)
        click.echo("  Type:     " + project_type)
        click.echo("  Path:     " + str(project_dir) + "  (directory will be slugified)")
        if project_type == "web":
            click.echo("  Backend:  " + backend)
            click.echo("  Hosting:  " + hosting)
        click.echo("  Git:      " + ("no (--no-git)" if no_git else "yes"))
        click.echo("")
        if not click.confirm("Create project?", default=True):
            click.echo("Aborted.")
            raise SystemExit(0)

    if dry_run:
        click.echo("[dry-run] Would create: " + str(project_dir))
        click.echo("[dry-run] Would write manifest.yaml and scaffold " + project_type)
        raise SystemExit(0)

    # Step 5 — Creation: scaffold first (creates dir + structure), then write manifest
    try:
        engine = TemplateEngine(project_type)
    except FileNotFoundError as e:
        click.echo(str(e))
        click.echo("Run: forge doctor")
        raise SystemExit(1)

    scaffolder = Scaffolder(project_type, project_dir)
    create_result = scaffolder.create(
        project_slug=slug,
        project_name=name,
        project_version=tokens.get("version", "0.1.0"),
        tokens=tokens,
    )
    if not create_result.ok:
        click.echo(create_result.error)
        raise SystemExit(1)

    write_result = engine.write(tokens, project_dir)
    if not write_result.ok:
        click.echo(write_result.error)
        raise SystemExit(1)

    if project_type == "flutter":
        root_manifest = project_dir / "manifest.yaml"
        docs_manifest = project_dir / "docs" / "manifest.yaml"
        if root_manifest.exists() and not docs_manifest.exists():
            shutil.copy(root_manifest, docs_manifest)

    if not no_git:
        git_result = scaffolder.init_git()
        if not git_result.ok:
            click.echo("Warning: " + git_result.error)
        else:
            hooks_dir = _get_hooks_dir()
            if hooks_dir.exists():
                scaffolder.install_hooks(hooks_dir)

    scaffolder.create_secrets_dir(slug)

    # Post-create hook
    env = os.environ.copy()
    env["FORGE_PROJECT_NAME"] = name
    env["FORGE_PROJECT_TYPE"] = project_type
    env["FORGE_PROJECT_PATH"] = str(project_dir)
    env["FORGE_PROJECT_SLUG"] = slug
    try:
        post_create = _get_hooks_dir() / "post-create"
        if post_create.exists():
            subprocess.run(
                ["bash", str(post_create)],
                cwd=project_dir,
                env=env,
                capture_output=True,
                timeout=30,
            )
    except Exception:
        pass

    if non_interactive:
        payload = {
            "project_path": str(project_dir),
            "manifest_created": bool((project_dir / "manifest.yaml").is_file() or (project_dir / "docs" / "manifest.yaml").is_file()),
            "workspace_registered": False,
            "stack": str(stack_id or project_type),
            "docs_bootstrapped": bool((project_dir / "docs").is_dir()),
        }
        tier = str(response_tier or "L1").upper()
        if tier == "L0":
            click.echo(f"forge init complete: {name}")
        else:
            click.echo(json.dumps(payload, indent=2))
        return

    click.echo("")
    click.echo(f"✦ {name} created at {project_dir}")
    click.echo("  Next: forge inspect " + slug)
