"""
forge export — generate shareable project snapshots.

Subcommands:
  forge export --public    → static JSON for /tools/forge
  forge export --badge     → SVG health score badge
  forge export --screenshot → (future: graph image)
"""
import json
from datetime import datetime, timezone
from pathlib import Path


def export_public(
    project_path: str,
    output_path: str | None = None,
) -> dict:
    """
    Generate a public-facing JSON snapshot.
    Suitable for serving at /tools/forge on a static site.
    Omits sensitive paths and internal details.
    """
    path = Path(project_path).expanduser().resolve()

    # Load health vector (best-effort)
    health = {}
    try:
        from forge.metrics.vector import HealthVector
        from forge.metrics.adi import compute_adi
        from forge.metrics.brc import compute_brc
        from forge.metrics.idr import compute_idr
        from forge.tools.manifest.graph import (
            build_manifest_graph
        )
        graph = build_manifest_graph(path)
        adi = compute_adi(path, graph)
        brc = compute_brc(graph)
        idr = compute_idr(graph)
        v = HealthVector(
            adi_score=adi.score,
            brc_score=brc.score,
            idr_score=idr.score,
        )
        health = v.to_dict()
    except Exception:
        health = {"overall": 0, "healthy": False}

    # Load graph summary (best-effort)
    graph_summary = {}
    try:
        from forge.tools.manifest.graph import (
            build_manifest_graph
        )
        g = build_manifest_graph(path)
        nodes = list(getattr(g, "nodes", []))
        edges = list(getattr(g, "edges", []))
        domains: dict[str, int] = {}
        for node in nodes:
            d = getattr(node, "domain", None) or \
                (node.get("domain") if isinstance(node, dict)
                 else "UNKNOWN")
            domains[d or "UNKNOWN"] = \
                domains.get(d or "UNKNOWN", 0) + 1
        graph_summary = {
            "node_count": len(nodes),
            "edge_count": len(edges),
            "domains": domains,
        }
    except Exception:
        graph_summary = {"node_count": 0, "edge_count": 0}

    # Recent events (last 5, sanitised)
    recent_events = []
    try:
        from forge.events.emitter import EventEmitter
        emitter = EventEmitter(path)
        events = emitter.read_events(limit=5)
        recent_events = [
            {
                "kind": ev.get("kind", ""),
                "timestamp": ev.get("timestamp", ""),
                "source": ev.get("source_fqid", "")
                           .split(":")[-1],
            }
            for ev in events
        ]
    except Exception:
        recent_events = []

    snapshot = {
        "project": path.name,
        "generated_at": datetime.now(
            timezone.utc
        ).isoformat(),
        "forge_version": _get_forge_version(),
        "health": health,
        "graph": graph_summary,
        "recent_events": recent_events,
    }

    if output_path:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(
            json.dumps(snapshot, indent=2)
        )

    return snapshot


def export_badge(
    project_path: str,
    output_path: str | None = None,
) -> str:
    """
    Generate an SVG health score badge.
    Format: Shields.io-style flat badge.
    Colour: green (>=80), yellow (>=60), red (<60).
    """
    path = Path(project_path).expanduser().resolve()

    # Get overall health score
    score = 0
    try:
        from forge.metrics.vector import HealthVector
        from forge.metrics.adi import compute_adi
        from forge.metrics.brc import compute_brc
        from forge.metrics.idr import compute_idr
        from forge.tools.manifest.graph import (
            build_manifest_graph
        )
        g = build_manifest_graph(path)
        v = HealthVector(
            adi_score=compute_adi(path, g).score,
            brc_score=compute_brc(g).score,
            idr_score=compute_idr(g).score,
        )
        score = v._overall()
    except Exception:
        score = 0

    color = (
        "#4c1" if score >= 80 else
        "#dfb317" if score >= 60 else
        "#e05d44"
    )
    label = "forge health"
    value = f"{score}%"

    svg = f'''<svg xmlns="http://www.w3.org/2000/svg"
        width="120" height="20">
        <linearGradient id="s" x2="0" y2="100%">
          <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
          <stop offset="1" stop-opacity=".1"/>
        </linearGradient>
        <rect rx="3" width="120" height="20" fill="#555"/>
        <rect rx="3" x="80" width="40" height="20"
              fill="{color}"/>
        <rect x="80" width="4" height="20" fill="{color}"/>
        <rect rx="3" width="120" height="20"
              fill="url(#s)"/>
        <g fill="#fff" text-anchor="middle"
           font-family="DejaVu Sans,Verdana,Geneva,sans-serif"
           font-size="11">
          <text x="40" y="15" fill="#010101"
                fill-opacity=".3">{label}</text>
          <text x="40" y="14">{label}</text>
          <text x="100" y="15" fill="#010101"
                fill-opacity=".3">{value}</text>
          <text x="100" y="14">{value}</text>
        </g>
      </svg>'''

    if output_path:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(svg)

    return svg


def _get_forge_version() -> str:
    try:
        import forge
        return getattr(forge, "__version__", "dev")
    except Exception:
        return "dev"

def export_graph(
    project_path: str,
    output_path: str | None = None,
) -> dict:
    """
    Generate a full graph JSON snapshot with nodes and edges.
    Suitable for powering interactive graph visualizations.
    """
    path = Path(project_path).expanduser().resolve()

    nodes_out = []
    edges_out = []

    try:
        from forge.tools.manifest.graph import build_manifest_graph
        g = build_manifest_graph(path)
        raw_nodes = list(getattr(g, "nodes", []))
        raw_edges = list(getattr(g, "edges", []))

        for node in raw_nodes:
            if isinstance(node, dict):
                n = node
            else:
                n = {
                    "id": str(getattr(node, "id", "") or getattr(node, "name", "")),
                    "kind": str(getattr(node, "kind", "module")),
                    "domain": str(getattr(node, "domain", "UNKNOWN")),
                    "tier": str(getattr(node, "tier", "worker")),
                    "status": str(getattr(node, "status", "declared")),
                    "depends_on": list(getattr(node, "depends_on", []) or []),
                    "consumed_by": list(getattr(node, "consumed_by", []) or []),
                }
            nodes_out.append(n)

        for edge in raw_edges:
            if isinstance(edge, dict):
                e = edge
            else:
                e = {
                    "from": str(getattr(edge, "from_id", "") or getattr(edge, "source", "")),
                    "to": str(getattr(edge, "to_id", "") or getattr(edge, "target", "")),
                    "kind": str(getattr(edge, "kind", "imports")),
                }
            edges_out.append(e)

    except Exception as exc:
        nodes_out = []
        edges_out = []

    snapshot = {
        "project": path.name,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "forge_version": _get_forge_version(),
        "node_count": len(nodes_out),
        "edge_count": len(edges_out),
        "nodes": nodes_out,
        "edges": edges_out,
    }

    if output_path:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(snapshot, indent=2))

    return snapshot