from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import click
import yaml

from forge.commands._shared_options import response_tier_option
from forge.core.path_utils import resolve_project_path
from forge.core.response_schema import tier_fields
from forge.tools.audit import runtime


# ── Interactive Audit Functions ───────────────────────────────────────────────────

def _run_interactive_audit_start(project_path: str, branch: str | None, session_label: str | None) -> None:
    """Run interactive audit session setup."""
    AUDIT_TEMPLATES = [
        {
            "name": "Security Review",
            "description": "Security-focused audit with vulnerability tracking",
            "label": "Security Review",
            "focus_areas": ["Authentication", "Authorization", "Data Protection", "Input Validation"],
        },
        {
            "name": "Code Quality",
            "description": "Code quality and maintainability assessment",
            "label": "Code Quality Review",
            "focus_areas": ["Architecture", "Code Standards", "Documentation", "Testing"],
        },
        {
            "name": "Performance Review",
            "description": "Performance and optimization audit",
            "label": "Performance Review",
            "focus_areas": ["Database", "Caching", "Algorithms", "Resource Usage"],
        },
        {
            "name": "Compliance Audit",
            "description": "Regulatory compliance verification",
            "label": "Compliance Audit",
            "focus_areas": ["GDPR", "Security Standards", "Data Privacy", "Access Controls"],
        },
    ]
    
    def _display_audit_menu() -> None:
        click.echo("\n🔍 FORGE INTERACTIVE AUDIT SETUP")
        click.echo("=" * 50)
        click.echo("Select audit type:")
        click.echo()
        
        for i, template in enumerate(AUDIT_TEMPLATES, 1):
            click.echo(f"  {i:2d}. {template['name']}")
            click.echo(f"      {template['description']}")
            click.echo(f"      Focus: {', '.join(template['focus_areas'])}")
            click.echo()
        
        click.echo("Commands:")
        click.echo("  h. Help")
        click.echo("  q. Quit")
        click.echo("  c. Custom audit")
        click.echo()
    
    def _get_audit_selection() -> dict[str, Any]:
        while True:
            try:
                user_input = click.prompt("Select audit type (1-4, c for custom)", type=str).strip()
                
                if user_input.lower() == 'q':
                    click.echo("👋 Quitting audit setup")
                    sys.exit(0)
                
                if user_input.lower() == 'h':
                    click.echo("\n📖 AUDIT SETUP HELP")
                    click.echo("=" * 30)
                    click.echo("Audit Types:")
                    click.echo("  1-4 - Pre-configured audit templates")
                    click.echo("  c - Custom audit with manual configuration")
                    click.echo("  q - Quit")
                    click.echo()
                    continue
                
                if user_input.lower() == 'c':
                    return {"custom": True}
                
                try:
                    idx = int(user_input) - 1
                    if 0 <= idx < len(AUDIT_TEMPLATES):
                        return AUDIT_TEMPLATES[idx]
                    else:
                        click.echo("⚠️  Invalid audit type number")
                except ValueError:
                    click.echo("⚠️  Invalid input")
                
            except (KeyboardInterrupt, EOFError):
                click.echo("\n👋 Quitting audit setup")
                sys.exit(0)
    
    def _configure_custom_audit() -> dict[str, Any]:
        click.echo("\n🔧 CUSTOM AUDIT CONFIGURATION")
        click.echo("=" * 35)
        
        label = click.prompt("Session label", type=str)
        description = click.prompt("Audit description", type=str)
        
        click.echo("\nFocus areas (comma-separated):")
        focus_input = click.prompt("Focus areas", type=str)
        focus_areas = [area.strip() for area in focus_input.split(",") if area.strip()]
        
        return {
            "name": "Custom Audit",
            "description": description,
            "label": label,
            "focus_areas": focus_areas,
            "custom": True,
        }
    
    # Run interactive flow
    _display_audit_menu()
    selection = _get_audit_selection()
    
    if selection.get("custom"):
        selection = _configure_custom_audit()
    
    # Show configuration
    click.echo("\n📋 AUDIT CONFIGURATION")
    click.echo("=" * 25)
    click.echo(f"Type: {selection['name']}")
    click.echo(f"Label: {selection['label']}")
    click.echo(f"Description: {selection['description']}")
    click.echo(f"Focus Areas: {', '.join(selection['focus_areas'])}")
    click.echo()
    
    if not click.confirm("Proceed with this configuration?"):
        click.echo("👋 Audit setup cancelled")
        sys.exit(0)
    
    # Get branch if not provided
    if not branch:
        branch = click.prompt("Git branch (optional)", type=str, default="")
    
    # Start the audit session
    click.echo("🚀 STARTING AUDIT SESSION...")
    click.echo()
    
    try:
        out = runtime.session_start(
            repo_root=str(resolve_project_path(project_path)),
            branch=branch if branch else None,
            session_label=selection["label"],
        )
        
        click.echo("✅ Audit session started")
        click.echo(f"   Session ID: {out.get('session_id', 'N/A')}")
        click.echo(f"   Label: {selection['label']}")
        click.echo()
        click.echo("🎯 NEXT STEPS:")
        click.echo(f"  1. forge audit note add --session-id {out.get('session_id')} --area \"<focus_area>\" --marker obs --content \"Your observation\"")
        click.echo(f"  2. forge audit finding promote --session-id {out.get('session_id')} --title \"Finding Title\" --finding \"Issue description\" --implication \"Impact description\"")
        click.echo(f"  3. forge audit status --session-id {out.get('session_id')}")
        click.echo()
        
        # Add initial note about focus areas
        for area in selection["focus_areas"]:
            try:
                runtime.note_add(
                    session_id=out["session_id"],
                    area=area,
                    marker="obs",
                    content=f"Audit focus area: {area}",
                    reference=None,
                )
            except Exception:
                pass  # Don't fail if note addition fails
        
        click.echo(json.dumps(out, indent=2))
        
    except Exception as e:
        click.echo(f"❌ Error starting audit session: {e}", err=True)
        sys.exit(1)


@click.group("audit", help="Evidence-Gated Audit Memory (EGMP) workflow.\n\nManages audit sessions, findings, annotations, and evidence-gated memory.\nCore EGMP workflow: start → annotate → promote → verify → handoff.\n\nExamples:\n  forge audit start --session-label \"Security Review\"    # Start new audit session\n  forge audit status --session-id SESSION_ID          # Check session status\n  forge audit note add --session-id SESSION_ID --area \"Authentication\" --marker obs --content \"Found issue\"\n  forge audit finding promote --session-id SESSION_ID --title \"Security Vulnerability\" --finding \"XSS in form\" --implication \"Data exposure\"\n  forge audit verify --session-id SESSION_ID           # Verify audit completion\n\nSee also: forge verify (structural verification), forge map (project visualization)")
def audit_group() -> None:
    pass


@audit_group.command("start")
# NOTE: duplicated by forge_session MCP / forge_annotate MCP
@click.option("--project-path", default=".", show_default=True, help="Target project root.")
@click.option("--branch", default=None, help="Git branch for audit context.")
@click.option("--session-label", default=None, help="Human-readable session identifier.")
@click.option("--interactive", is_flag=True, default=False, help="Interactive session setup with guided configuration.")
def audit_start(project_path: str, branch: str | None, session_label: str | None, interactive: bool) -> None:
    """Start a new EGMP audit session.
    
    Creates an audit session for tracking findings, annotations, and evidence.
    Sessions provide structured workflow for code reviews, security audits,
    and compliance verification.
    
    Examples:
      forge audit start --session-label "Security Review"    # Labeled session
      forge audit start --branch main --session-label "Main Branch Audit"
      forge audit start --interactive                       # Guided setup
    
    Session Workflow:
      1. Start session with descriptive label
      2. Add observations, questions, and findings
      3. Promote findings to formal audit items
      4. Verify and close audit session
      5. Handoff to stakeholders
    
    See also: forge audit status, forge audit note add, forge audit finding promote
    """
    if interactive:
        return _run_interactive_audit_start(project_path, branch, session_label)
    
    out = runtime.session_start(
        repo_root=str(resolve_project_path(project_path)),
        branch=branch,
        session_label=session_label,
    )
    click.echo(json.dumps(out, indent=2))


@audit_group.group("note")
def audit_note_group() -> None:
    pass


@audit_note_group.command("add")
@click.option("--session-id", required=True)
@click.option("--area", required=True)
@click.option("--marker", required=True, type=click.Choice(["obs", "question", "surprise"]))
@click.option("--content", required=True)
@click.option("--reference", default=None)
def audit_note_add(session_id: str, area: str, marker: str, content: str, reference: str | None) -> None:
    out = runtime.note_add(session_id=session_id, area=area, marker=marker, content=content, reference=reference)
    click.echo(json.dumps(out, indent=2))


@audit_group.group("finding")
def audit_finding_group() -> None:
    pass


@audit_finding_group.command("promote")
@click.option("--session-id", required=True)
@click.option("--title", required=True)
@click.option("--source-1", required=True)
@click.option("--source-2", required=True)
@click.option("--finding", required=True)
@click.option("--implication", required=True)
def audit_finding_promote(
    session_id: str,
    title: str,
    source_1: str,
    source_2: str,
    finding: str,
    implication: str,
) -> None:
    out = runtime.finding_promote(
        session_id=session_id,
        title=title,
        source_1=source_1,
        source_2=source_2,
        finding=finding,
        implication=implication,
    )
    click.echo(json.dumps(out, indent=2))


@audit_finding_group.command("review")
@click.option("--session-id", required=True)
@click.option("--finding-id", required=True)
@click.option("--status", required=True, type=click.Choice(["approved", "rejected"]))
@click.option("--approved-by", required=True)
def audit_finding_review(session_id: str, finding_id: str, status: str, approved_by: str) -> None:
    out = runtime.finding_review(session_id=session_id, finding_id=finding_id, status=status, approved_by=approved_by)
    click.echo(json.dumps(out, indent=2))


@audit_group.group("memory")
def audit_memory_group() -> None:
    pass


@audit_memory_group.command("promote")
@click.option("--session-id", required=True)
@click.option("--finding-id", required=True)
@click.option("--scope", required=True)
@click.option("--revalidate-when", default="")
@click.option("--approval", required=True)
def audit_memory_promote(session_id: str, finding_id: str, scope: str, revalidate_when: str, approval: str) -> None:
    out = runtime.memory_promote(
        session_id=session_id,
        finding_id=finding_id,
        scope=scope,
        revalidate_when=revalidate_when,
        approval=approval,
    )
    click.echo(json.dumps(out, indent=2))


@audit_group.command("handoff")
# NOTE: duplicated by forge_session MCP / forge_annotate MCP
@click.option("--session-id", required=True)
@click.option("--stopped-at", required=True)
@click.option("--active-scratch-file", "active_scratch_files", multiple=True)
@click.option("--next-action", required=True)
def audit_handoff(session_id: str, stopped_at: str, active_scratch_files: tuple[str, ...], next_action: str) -> None:
    out = runtime.handoff_write(
        session_id=session_id,
        stopped_at=stopped_at,
        active_scratch_files=list(active_scratch_files),
        next_action=next_action,
    )
    click.echo(json.dumps(out, indent=2))


@audit_group.command("status")
# NOTE: duplicated by forge_session MCP / forge_annotate MCP
@click.option("--session-id", required=True)
def audit_status(session_id: str) -> None:
    out = runtime.status(session_id=session_id)
    click.echo(json.dumps(out, indent=2))


@audit_group.command("query")
@click.option("--session-id", default=None, help="EGMP session (required unless --annotations or --schema).")
@click.option("--kind", multiple=True, help="EGMP: repeat flag. Annotations: first value wins if multiple passed.")
@click.option("--status", "status_filter", multiple=True, help="EGMP: repeat flag. Annotations: first value wins.")
@click.option("--area", multiple=True)
@click.option("--limit", default=10, show_default=True)
@click.option("--offset", default=0, show_default=True)
@click.option("--file", "file_filter", default=None, help="Filter annotations by file path substring.")
@click.option("--finding", default=None, help="Filter annotations by finding id.")
@click.option(
    "--severity",
    default=None,
    type=click.Choice(["high", "medium", "low"]),
    help="Filter annotations by severity.",
)
@click.option("--assigned", default=None, help="Filter by assigned agent/person.")
@click.option(
    "--horizon",
    default=None,
    type=click.Choice(["current", "next", "future", "deferred"]),
    help="Filter annotations by horizon.",
)
@click.option("--no-issue", "no_issue", is_flag=True, help="Only annotations without git_issue.")
@click.option(
    "--annotations",
    "query_annotations",
    is_flag=True,
    help="Query .forge-annotations.yaml sidecars instead of EGMP session events.",
)
@click.option("--project-path", default=".", show_default=True, help="Project root for annotation queries.")
@click.option(
    "--no-cache",
    "no_cache",
    is_flag=True,
    help="Bypass SQLite annotation index; walk sidecars directly.",
)
@click.option("--schema", "dump_schema", is_flag=True, help="Print forge-annotations schema and exit.")
@click.option(
    "--graph",
    type=click.Choice(["declaration", "execution", "intent", "all"], case_sensitive=False),
    default="declaration",
    show_default=True,
    help="Source graph for query results.",
)
@click.option(
    "--response-tier",
    type=click.Choice(["L0", "L1", "L2"], case_sensitive=False),
    default="L1",
    show_default=True,
)
def audit_query(
    session_id: str | None,
    kind: tuple[str, ...],
    status_filter: tuple[str, ...],
    area: tuple[str, ...],
    limit: int,
    offset: int,
    file_filter: str | None,
    finding: str | None,
    severity: str | None,
    assigned: str | None,
    horizon: str | None,
    no_issue: bool,
    query_annotations: bool,
    project_path: str,
    no_cache: bool,
    dump_schema: bool,
    graph: str,
    response_tier: str,
) -> None:
    def _project_row(row: dict, fields: list[str]) -> dict:
        return {k: row.get(k) for k in fields}

    def _tier_fields(root: Path, tier: str) -> list[str]:
        return tier_fields(root, "audit_query", tier)

    def _to_l0(rows: list[dict]) -> dict:
        by_kind: dict[str, int] = {}
        by_status: dict[str, int] = {}
        for r in rows:
            k = str(r.get("kind") or "unknown")
            s = str(r.get("status") or "unknown")
            by_kind[k] = by_kind.get(k, 0) + 1
            by_status[s] = by_status.get(s, 0) + 1
        return {"total": len(rows), "by_kind": by_kind, "by_status": by_status}

    def _to_l1(rows: list[dict], root: Path) -> list[dict]:
        fields = _tier_fields(root, "L1")
        if not fields:
            return rows
        return [_project_row(r, fields) for r in rows]

    def _to_l2(rows: list[dict], root: Path) -> list[dict]:
        fields = _tier_fields(root, "L2")
        if not fields:
            return rows
        return [_project_row(r, fields) for r in rows]

    def _should_suppress_dark_matter(tier: str, kind_filters: tuple[str, ...]) -> bool:
        if tier == "L2":
            return False
        normalized = {str(k).strip().lower() for k in kind_filters if str(k).strip()}
        return "dark-matter" not in normalized

    def _intent_rows(root: Path) -> list[dict]:
        from dataclasses import asdict

        from forge.tools.intent.runtime import load_intent_records

        rows: list[dict] = []
        for r in load_intent_records(root):
            title = str(r.raw_description or "").strip()
            if len(title) > 120:
                title = title[:117] + "..."
            rows.append(
                {
                    "id": r.id,
                    "kind": r.scope,
                    "status": r.status,
                    "severity": "low",
                    "title": title,
                    "domain": r.source,
                    "horizon": "current",
                    "source_graph": "intent",
                    "intent_record": asdict(r),
                }
            )
        return rows

    def _execution_rows(root: Path) -> list[dict]:
        from forge.tools.trace_store import load_latest_trace

        eg = load_latest_trace(root)
        rows: list[dict] = []
        if eg is None:
            return rows
        for n in eg.nodes.values():
            rows.append(
                {
                    "id": n.id,
                    "kind": "execution",
                    "status": "active",
                    "severity": "low",
                    "title": n.qualname or n.module or n.id,
                    "domain": "execution",
                    "horizon": "current",
                    "source_graph": "execution",
                }
            )
        return rows

    def _declaration_rows(root: Path, kind: tuple[str, ...], status_filter: tuple[str, ...], severity: str | None, assigned: str | None, finding: str | None, file_filter: str | None, horizon: str | None, no_cache: bool) -> list[dict]:
        from forge.tools.audit.annotations import query_annotations as qa_fn

        kind_one = kind[0] if kind else None
        status_one = status_filter[0] if status_filter else None
        results = qa_fn(
            root,
            kind=kind_one,
            status=status_one,
            severity=severity,
            assigned=assigned,
            finding=finding,
            file=file_filter,
            horizon=horizon,
            use_index=not no_cache,
        )
        rows = results.get("results") if isinstance(results, dict) else []
        out: list[dict] = []
        if isinstance(rows, list):
            for r in rows:
                if not isinstance(r, dict):
                    continue
                x = dict(r)
                x["source_graph"] = "declaration"
                out.append(x)
        return out

    if dump_schema:
        schema_path = Path(__file__).resolve().parents[2] / "schemas" / "forge-annotations.schema.yaml"
        # ManifestParser doesn't cover external JSON Schema files — direct load intentional.
        data = yaml.safe_load(schema_path.read_text(encoding="utf-8")) or {}
        click.echo(yaml.safe_dump(data, sort_keys=False))
        return

    gsel = str(graph or "declaration").lower()
    if query_annotations or gsel in {"declaration", "execution", "intent", "all"}:
        root = resolve_project_path(project_path)
        rows: list[dict] = []
        if gsel in {"declaration", "all"}:
            rows.extend(
                _declaration_rows(
                    root,
                    kind,
                    status_filter,
                    severity,
                    assigned,
                    finding,
                    file_filter,
                    horizon,
                    no_cache,
                )
            )
        if gsel in {"intent", "all"}:
            rows.extend(_intent_rows(root))
        if gsel in {"execution", "all"}:
            rows.extend(_execution_rows(root))
        if gsel in {"declaration", "all"} and _should_suppress_dark_matter(tier=str(response_tier or "L1").upper(), kind_filters=kind):
            rows = [r for r in rows if str(r.get("kind") or "").strip().lower() != "dark-matter"]
        if no_issue:
            rows = [a for a in rows if not a.get("git_issue")]
        tier = str(response_tier or "L1").upper()
        if tier == "L0":
            payload: dict = _to_l0(rows)
        elif tier == "L1":
            payload = {"total": len(rows), "results": _to_l1(rows, root)}
        else:
            payload = {"total": len(rows), "results": _to_l2(rows, root)}
        click.echo(json.dumps(payload, indent=2))
        return

    if not session_id:
        raise click.UsageError("--session-id is required unless --annotations or --schema.")

    filt = {
        "kind": list(kind) if kind else None,
        "status": list(status_filter) if status_filter else None,
        "area": list(area) if area else None,
        "limit": limit,
        "offset": offset,
    }
    out = runtime.query(session_id=session_id, filters=filt)
    click.echo(json.dumps(out, indent=2))


@audit_group.command("verify")
@click.option("--session-id", required=True)
@click.option(
    "--project-path",
    default=None,
    type=click.Path(file_okay=False),
    help="Repo root containing the session (overrides cwd discovery when the server cwd is not the project).",
)
@click.option("--changed-file", "changed_files", multiple=True)
@click.option("--strict", is_flag=True, default=False)
@click.option("--policy-mode", type=click.Choice(["advisory", "enforce"]), default="advisory", show_default=True)
def audit_verify(
    session_id: str,
    project_path: str | None,
    changed_files: tuple[str, ...],
    strict: bool,
    policy_mode: str,
) -> None:
    out = runtime.verify(
        session_id=session_id,
        changed_files=list(changed_files),
        strict=strict,
        policy_mode=policy_mode,
        project_path=project_path,
    )
    click.echo(json.dumps(out, indent=2))
    raise SystemExit(int(out.get("exit_code", 1)))


@audit_group.command("repo")
@click.option("--project-path", default=".", show_default=True)
@click.option("--scope", "scopes", multiple=True)
@click.option("--focus", "focuses", multiple=True)
@click.option("--strict", is_flag=True, default=False)
@click.option("--policy-mode", type=click.Choice(["advisory", "enforce"]), default="advisory", show_default=True)
@click.option(
    "--changed-files-source",
    type=click.Choice(["git", "scope", "all"]),
    default="git",
    show_default=True,
    help="Select changed-file strategy: git diff (low noise), scope subset, or full repo.",
)
@click.option(
    "--alignment-mode",
    type=click.Choice(["target_to_forge", "bidirectional", "target_only"]),
    default="target_to_forge",
    show_default=True,
    help="Directionality of standards reconciliation for multi-repo workflows.",
)
def audit_repo_cmd(
    project_path: str,
    scopes: tuple[str, ...],
    focuses: tuple[str, ...],
    strict: bool,
    policy_mode: str,
    changed_files_source: str,
    alignment_mode: str,
) -> None:
    out = runtime.audit_repo(
        project_path=project_path,
        strict=strict,
        policy_mode=policy_mode,
        changed_files_source=changed_files_source,
        alignment_mode=alignment_mode,
        scope=list(scopes) if scopes else None,
        focus=list(focuses) if focuses else None,
    )
    click.echo(json.dumps(out, indent=2))
    raise SystemExit(int(out.get("exit_code", 1)))


@audit_group.command("meta")
@click.option("--at", "at_path", default=".", show_default=True, help="Branch-point path to audit from.")
@click.option("--scope", "scopes", multiple=True)
@click.option("--focus", "focuses", multiple=True)
@click.option("--depth", default=3, show_default=True, type=int)
@click.option("--siblings/--no-siblings", default=True, show_default=True)
@click.option("--include-parent-context/--no-parent-context", default=True, show_default=True)
@click.option("--strict", is_flag=True, default=False)
@click.option("--policy-mode", type=click.Choice(["advisory", "enforce"]), default="advisory", show_default=True)
@click.option(
    "--changed-files-source",
    type=click.Choice(["git", "scope", "all"]),
    default="git",
    show_default=True,
    help="Select changed-file strategy: git diff (low noise), subtree scope, or full repo.",
)
@click.option(
    "--alignment-mode",
    type=click.Choice(["target_to_forge", "bidirectional", "target_only"]),
    default="target_to_forge",
    show_default=True,
    help="Directionality of standards reconciliation for this branch-point audit.",
)
def audit_meta_cmd(
    at_path: str,
    scopes: tuple[str, ...],
    focuses: tuple[str, ...],
    depth: int,
    siblings: bool,
    include_parent_context: bool,
    strict: bool,
    policy_mode: str,
    changed_files_source: str,
    alignment_mode: str,
) -> None:
    out = runtime.audit_meta(
        at_path=at_path,
        include_siblings=siblings,
        depth=depth,
        include_parent_context=include_parent_context,
        strict=strict,
        policy_mode=policy_mode,
        changed_files_source=changed_files_source,
        alignment_mode=alignment_mode,
        scope=list(scopes) if scopes else None,
        focus=list(focuses) if focuses else None,
    )
    click.echo(json.dumps(out, indent=2))
    raise SystemExit(int(out.get("exit_code", 1)))


@audit_group.group("phase")
def audit_phase_group() -> None:
    pass


@audit_phase_group.command("upsert")
# NOTE: duplicated by forge_session MCP / forge_annotate MCP
@click.option("--session-id", required=True)
@click.option("--phase-id", required=True)
@click.option("--task-id", required=True)
@click.option("--status", required=True, type=click.Choice(["todo", "doing", "blocked", "done"]))
@click.option("--owner", default="", show_default=False)
@click.option("--depends-on", "depends_on", multiple=True)
@click.option("--block-reason", default="", show_default=False)
@click.option("--next-action", default="", show_default=False)
def audit_phase_upsert_cmd(
    session_id: str,
    phase_id: str,
    task_id: str,
    status: str,
    owner: str,
    depends_on: tuple[str, ...],
    block_reason: str,
    next_action: str,
) -> None:
    out = runtime.phase_task_upsert(
        session_id=session_id,
        phase_id=phase_id,
        task_id=task_id,
        status=status,
        owner=owner,
        depends_on=list(depends_on) if depends_on else None,
        block_reason=block_reason,
        next_action=next_action,
    )
    click.echo(json.dumps(out, indent=2))


@audit_phase_group.command("status")
# NOTE: duplicated by forge_session MCP / forge_annotate MCP
@click.option("--session-id", required=True)
def audit_phase_status_cmd(session_id: str) -> None:
    out = runtime.phase_status(session_id=session_id)
    click.echo(json.dumps(out, indent=2))


@audit_group.group("annotate")
def audit_annotate_group() -> None:
    """Manage .forge-annotations.yaml sidecars (alias: forge annotate)."""


def _split_csv_and_flags(values: tuple[str, ...]) -> list[str]:
    """Flatten repeatable CLI flags and comma-separated tokens into a deduped list."""
    out: list[str] = []
    seen: set[str] = set()
    for raw in values:
        for part in (raw or "").split(","):
            token = part.strip()
            if token and token not in seen:
                seen.add(token)
                out.append(token)
    return out


@audit_annotate_group.command("create")
# NOTE: duplicated by forge_session MCP / forge_annotate MCP
@click.option("--project-path", default=".", show_default=True)
@click.option(
    "--file",
    "file_path",
    required=False,
    default="",
    type=str,
    help="Repo-relative path for file-scoped annotations; omit for project-wide milestone/debt notes.",
)
@click.option(
    "--kind",
    required=True,
    type=click.Choice(
        [
            "debt",
            "gap",
            "finding",
            "risk",
            "question",
            "stub",
            "guard",
            "architecture-debt",
            "design-proposal",
            "schema-improvement",
            "future-idea",
            "milestone",
        ]
    ),
)
@click.option("--severity", required=True, type=click.Choice(["high", "medium", "low"]))
@click.option("--note", required=True, type=str)
@click.option("--assigned", default=None)
@click.option("--expires-when", default=None)
@click.option("--adr-refs", default=None, help="Comma-separated ADR refs")
@click.option("--finding", default=None)
@click.option(
    "--pipeline-refs",
    multiple=True,
    default=None,
    help="Pipeline identifiers (repeat flag or comma-separated values). Written to annotation YAML.",
)
@click.option(
    "--tool-refs",
    multiple=True,
    default=None,
    help="Forge tool names (repeat flag or comma-separated values). Written to annotation YAML.",
)
def audit_annotate_create(
    project_path: str,
    file_path: str,
    kind: str,
    severity: str,
    note: str,
    assigned: str | None,
    expires_when: str | None,
    adr_refs: str | None,
    finding: str | None,
    pipeline_refs: tuple[str, ...],
    tool_refs: tuple[str, ...],
) -> None:
    from forge.tools.audit.annotations import (
        ValidationError,
        next_annotation_id,
        validate_annotation,
        write_annotation,
    )
    from forge.tools.audit.bundle import AuditAnnotation
    from forge.tools.audit.index import AnnotationIndex

    project = resolve_project_path(project_path)
    ann_id = next_annotation_id(project)
    refs = [x.strip() for x in (adr_refs or "").split(",") if x.strip()]
    rel = file_path.replace("\\", "/").strip()
    pip = _split_csv_and_flags(pipeline_refs or ())
    tools = _split_csv_and_flags(tool_refs or ())
    ann = AuditAnnotation(
        id=ann_id,
        file=rel,
        kind=kind,
        severity=severity,
        note=note,
        assigned=assigned,
        expires_when=expires_when,
        adr_refs=refs,
        finding=finding,
        pipeline_refs=pip,
        tool_refs=tools,
    )
    try:
        errors = validate_annotation(ann)
    except ValidationError as exc:
        raise click.ClickException(str(exc)) from exc
    if errors:
        raise click.ClickException("; ".join(errors))
    directory = (project / rel).resolve().parent if rel else project
    write_annotation(directory, ann)
    db = project / ".forge" / "audit-index.db"
    if db.exists():
        AnnotationIndex(db).rebuild(project)
    loc = rel if rel else "(project)"
    click.echo(f"Created: {ann_id} @ {loc}")


@audit_annotate_group.command("update")
# NOTE: duplicated by forge_session MCP / forge_annotate MCP
@click.option("--project-path", default=".", show_default=True)
@click.option("--id", "ann_id", required=True, type=str)
@click.option("--status", default=None, type=click.Choice(["open", "resolved", "expired", "wont_fix"]))
@click.option("--assigned", default=None, type=str)
@click.option("--note", default=None, type=str)
@click.option("--expires-when", default=None, type=str)
@click.option("--git-issue", default=None, type=str)
def audit_annotate_update(
    project_path: str,
    ann_id: str,
    status: str | None,
    assigned: str | None,
    note: str | None,
    expires_when: str | None,
    git_issue: str | None,
) -> None:
    from forge.tools.audit.annotations import (
        ValidationError,
        find_annotation_by_id,
        validate_annotation,
        write_annotation,
    )

    project = resolve_project_path(project_path)
    found = find_annotation_by_id(project, ann_id)
    if not found:
        raise click.ClickException(f"Annotation not found: {ann_id}")
    directory, ann = found
    if status is not None:
        ann.status = status
    if assigned is not None:
        ann.assigned = assigned
    if note is not None:
        ann.note = note
    if expires_when is not None:
        ann.expires_when = expires_when
    if git_issue is not None:
        ann.git_issue = git_issue
    try:
        errors = validate_annotation(ann)
    except ValidationError as exc:
        raise click.ClickException(str(exc)) from exc
    if errors:
        raise click.ClickException("; ".join(errors))
    write_annotation(directory, ann)
    click.echo(f"Updated: {ann_id}")


@audit_group.command("create")
# NOTE: duplicated by forge_session MCP / forge_annotate MCP
@click.option("--project-path", default=".", show_default=True)
@click.option("--file", "file_path", required=True, help="Repo-relative path.")
@click.option(
    "--kind",
    required=True,
    type=click.Choice(["debt", "gap", "finding", "risk", "question", "stub", "guard", "architecture-debt", "design-proposal", "schema-improvement", "future-idea"]),
)
@click.option("--severity", required=True, type=click.Choice(["high", "medium", "low"]))
@click.option("--note", required=True)
@click.option("--assigned", default=None)
@click.option("--expires-when", default=None)
@click.option("--adr-refs", default=None, help="Comma-separated ADR ids.")
@click.option("--finding", default=None)
def audit_create_alias(
    project_path: str,
    file_path: str,
    kind: str,
    severity: str,
    note: str,
    assigned: str | None,
    expires_when: str | None,
    adr_refs: str | None,
    finding: str | None,
) -> None:
    from forge.tools.audit.annotations import (
        ValidationError,
        next_annotation_id,
        validate_annotation,
        write_annotation,
    )
    from forge.tools.audit.bundle import AuditAnnotation
    from forge.tools.audit.index import AnnotationIndex

    project = resolve_project_path(project_path)
    ann_id = next_annotation_id(project)
    refs = [x.strip() for x in (adr_refs or "").split(",") if x.strip()]
    ann = AuditAnnotation(
        id=ann_id,
        file=file_path.replace("\\", "/"),
        kind=kind,
        severity=severity,
        note=note,
        assigned=assigned,
        expires_when=expires_when,
        adr_refs=refs,
        finding=finding,
    )
    try:
        errors = validate_annotation(ann)
    except ValidationError as exc:
        raise click.ClickException(str(exc)) from exc
    if errors:
        raise click.ClickException("; ".join(errors))
    directory = (project / file_path).resolve().parent
    write_annotation(directory, ann)
    db = project / ".forge" / "audit-index.db"
    if db.exists():
        AnnotationIndex(db).rebuild(project)
    click.echo(f"Created: {ann_id} in {file_path}")


@audit_group.command("update")
# NOTE: duplicated by forge_session MCP / forge_annotate MCP
@click.option("--project-path", default=".", show_default=True)
@click.option("--id", "ann_id", required=True, type=str)
@click.option("--status", default=None, type=click.Choice(["open", "resolved", "dismissed", "deferred", "draft"]))
@click.option("--assigned", default=None, type=str)
@click.option("--note", default=None, type=str)
@click.option("--expires-when", default=None, type=str)
@click.option("--git-issue", default=None, type=str)
def audit_update_alias(
    project_path: str,
    ann_id: str,
    status: str | None,
    assigned: str | None,
    note: str | None,
    expires_when: str | None,
    git_issue: str | None,
) -> None:
    from forge.tools.audit.annotations import (
        ValidationError,
        find_annotation_by_id,
        validate_annotation,
        write_annotation,
    )

    project = resolve_project_path(project_path)
    found = find_annotation_by_id(project, ann_id)
    if not found:
        raise click.ClickException(f"Annotation not found: {ann_id}")
    directory, ann = found
    if status is not None:
        ann.status = status
    if assigned is not None:
        ann.assigned = assigned
    if note is not None:
        ann.note = note
    if expires_when is not None:
        ann.expires_when = expires_when
    if git_issue is not None:
        ann.git_issue = git_issue
    try:
        errors = validate_annotation(ann)
    except ValidationError as exc:
        raise click.ClickException(str(exc)) from exc
    if errors:
        raise click.ClickException("; ".join(errors))
    write_annotation(directory, ann)
    click.echo(f"Updated: {ann_id}")


@audit_annotate_group.command("resolve")
# NOTE: duplicated by forge_session MCP / forge_annotate MCP
@click.option("--project-path", default=".", show_default=True)
@click.option("--id", "ann_id", required=True, type=str)
@click.option("--resolution-note", required=True, type=str)
def audit_annotate_resolve(project_path: str, ann_id: str, resolution_note: str) -> None:
    from forge.tools.audit.annotations import (
        ValidationError,
        find_annotation_by_id,
        validate_annotation,
        write_annotation,
    )
    from forge.tools.audit.index import AnnotationIndex

    project = resolve_project_path(project_path)
    found = find_annotation_by_id(project, ann_id)
    if not found:
        raise click.ClickException(f"Annotation not found: {ann_id}")
    directory, ann = found
    ts = datetime.now(timezone.utc).isoformat()
    ann.status = "resolved"
    ann.note = f"{ann.note}\n\n[{ts}] resolved: {resolution_note}".strip()
    try:
        errors = validate_annotation(ann)
    except ValidationError as exc:
        raise click.ClickException(str(exc)) from exc
    if errors:
        raise click.ClickException("; ".join(errors))
    write_annotation(directory, ann)
    db = project / ".forge" / "audit-index.db"
    if db.exists():
        AnnotationIndex(db).rebuild(project)
    click.echo(f"Resolved: {ann_id}")


@audit_group.command("promote")
# NOTE: duplicated by forge_session MCP / forge_annotate MCP
@click.option("--project-path", default=".", show_default=True)
@click.option("--annotation-id", required=True, type=str)
@click.option("--checklist-item", default=None, type=int)
def audit_promote(project_path: str, annotation_id: str, checklist_item: int | None) -> None:
    from forge.tools.audit.annotations import annotation_to_dict, review_annotation_status

    project = resolve_project_path(project_path)
    ann = review_annotation_status(
        project,
        annotation_id,
        action="promote",
        checklist_item=checklist_item,
    )
    click.echo(json.dumps(annotation_to_dict(ann), indent=2))


@audit_group.command("dismiss")
# NOTE: duplicated by forge_session MCP / forge_annotate MCP
@click.option("--project-path", default=".", show_default=True)
@click.option("--annotation-id", required=True, type=str)
def audit_dismiss(project_path: str, annotation_id: str) -> None:
    from forge.tools.audit.annotations import annotation_to_dict, review_annotation_status

    project = resolve_project_path(project_path)
    ann = review_annotation_status(project, annotation_id, action="dismiss")
    click.echo(json.dumps(annotation_to_dict(ann), indent=2))


@audit_group.command("reindex")
@click.option("--project-path", default=".", show_default=True)
def audit_reindex(project_path: str) -> None:
    from forge.tools.audit.annotations import rebuild_annotation_index

    project = resolve_project_path(project_path)
    click.echo(json.dumps(rebuild_annotation_index(project), indent=2))


@audit_annotate_group.command("list")
@response_tier_option(default="L1")
@click.option("--project-path", default=".", show_default=True)
@click.option("--kind", default=None)
@click.option("--severity", default=None, type=click.Choice(["high", "medium", "low"]))
@click.option("--status", "status_filter", default="open", show_default=True)
@click.option("--assigned", default=None)
@click.option("--file", "file_filter", default=None)
@click.option("--json", "as_json", is_flag=True)
def audit_annotate_list(
    project_path: str,
    kind: str | None,
    severity: str | None,
    status_filter: str | None,
    assigned: str | None,
    file_filter: str | None,
    as_json: bool,
    response_tier: str,
) -> None:
    from forge.tools.audit.annotations import annotation_to_dict, query_annotations

    project = resolve_project_path(project_path)
    payload = query_annotations(
        project,
        kind=kind,
        severity=severity,
        status=status_filter,
        assigned=assigned,
        file=file_filter,
    )
    rows = payload.get("results", []) if isinstance(payload, dict) else payload
    if isinstance(payload, dict) and payload.get("level") == 1:
        # Flatten grouped Level-1 payload for tabular CLI listing compatibility.
        rows = []
        groups = payload.get("groups") or {}
        for major in groups.values():
            if not isinstance(major, dict):
                continue
            for bucket in major.values():
                if isinstance(bucket, list):
                    rows.extend(bucket)
    if isinstance(rows, list) and rows and isinstance(rows[0], dict):
        from forge.tools.audit.bundle import AuditAnnotation

        rows = [AuditAnnotation(**r) for r in rows]
    if as_json:
        click.echo(json.dumps([annotation_to_dict(a) for a in rows], indent=2))
        return
    click.echo("ID           FILE                             KIND      SEV     STATUS    ASSIGNED  NOTE")
    click.echo("-" * 100)
    for a in rows:
        note = (a.note or "").replace("\n", " ")
        if len(note) > 40:
            note = note[:37] + "..."
        click.echo(
            f"{a.id:<12} {a.file[:32]:<32} {a.kind:<9} {a.severity:<7} {a.status:<9} "
            f"{(a.assigned or '-'): <8} {note}",
        )


@audit_group.command("index")
@click.option("--project-path", default=".", show_default=True)
@click.option("--status", "status_only", is_flag=True, help="Report index freshness without rebuilding.")
def audit_index_cmd(project_path: str, status_only: bool) -> None:
    """Build or inspect SQLite cache for annotation sidecars."""
    from forge.tools.audit.index import AnnotationIndex

    project = resolve_project_path(project_path)
    db = project / ".forge" / "audit-index.db"
    idx = AnnotationIndex(db)
    if status_only:
        st = idx.status_payload(project)
        click.echo(json.dumps(st, indent=2))
        return
    stats = idx.rebuild(project)
    click.echo(
        f"{stats['annotations']} annotations indexed from {stats['sidecar_files']} sidecars "
        f"(fingerprint {stats['fingerprint'][:16]}…)",
    )


@audit_group.group("map")
def audit_map() -> None:
    """Portable audit map — snapshot, navigate, and visualize codebase audit state."""


@audit_map.command("take")
@click.option("--project-path", default=".", show_default=True)
@click.option("--session-id", default=None)
@click.option("--sweep-level", type=click.Choice(["L0", "L1", "L2", "L3", "L4"]), default="L1")
@click.option("--mode", type=click.Choice(["git", "scope", "all"]), default="git")
@click.option("--at", "at_path", default=None)
@click.option("--depth", default=3, type=int)
@click.option("--traverse", type=click.Choice(["bfs", "dfs", "risk-first"]), default="bfs")
@click.option("--out", default="audit-map.bundle.json", show_default=True)
def audit_map_take(
    project_path: str,
    session_id: str | None,
    sweep_level: str,
    mode: str,
    at_path: str | None,
    depth: int,
    traverse: str,
    out: str,
) -> None:
    from forge.tools.audit.map_take import run_audit_map_take
    from forge.tools.audit.repo_info import get_forge_version, get_git_branch, get_git_sha, get_manifest_source

    project = resolve_project_path(project_path)
    out_path = Path(out).expanduser()
    if not out_path.is_absolute():
        out_path = Path.cwd() / out_path
    result = run_audit_map_take(
        project,
        session_id=session_id,
        sweep_level=sweep_level,
        mode=mode,
        at_path=at_path,
        depth=depth,
        traverse=traverse,
        out=out_path,
        get_git_branch=get_git_branch,
        get_git_sha=get_git_sha,
        get_forge_version=get_forge_version,
        get_manifest_source=get_manifest_source,
    )
    cov = result["coverage"]
    by_kind = cov.get("by_kind") or {}
    kinds_s = ", ".join(f"{k}:{v}" for k, v in sorted(by_kind.items()) if v > 0)
    click.echo(f"Bundle:   {result['bundle_id']}")
    click.echo(f"Session:  {result['session_id']}")
    click.echo(f"Nodes:    {cov['total']} ({kinds_s})")
    click.echo(f"Coverage: {cov['pct_reviewed']}% reviewed")
    click.echo(f"Output:   {out_path}")
    for w in result["warnings"]:
        click.echo(f"Warning:  {w}")


@audit_map.command("show")
@response_tier_option(default="L1")
@click.option("--bundle", default="audit-map.bundle.json", show_default=True)
@click.option("--kind", default=None)
@click.option("--status", default=None)
@click.option("--depth", default=None, type=int)
@click.option("--json", "as_json", is_flag=True)
def audit_map_show(
    bundle: str,
    kind: str | None,
    status: str | None,
    depth: int | None,
    as_json: bool,
    response_tier: str,
) -> None:
    from dataclasses import asdict

    from forge.tools.audit.bundle import load_bundle
    from forge.tools.audit.renderer import render_table

    _ = depth
    b = load_bundle(Path(bundle).expanduser())
    nodes = b.nodes
    if kind:
        nodes = [n for n in nodes if n.kind == kind]
    if status:
        nodes = [n for n in nodes if n.status == status]
    if as_json:
        click.echo(
            json.dumps(
                {
                    "bundle_id": b.bundle_id,
                    "coverage": b.coverage or b.compute_coverage(),
                    "nodes": [asdict(n) for n in nodes],
                },
                indent=2,
            ),
        )
        return
    click.echo(render_table(b))
    blocked = [n for n in nodes if n.status == "blocked"]
    critical = [n for n in nodes if n.critical and n.status not in ("verified_clean",)]
    if blocked:
        click.echo("\nBlocked:")
        for n in blocked:
            click.echo(f"  {n.node_id}: {n.path}")
    if critical:
        click.echo("\nCritical (unreviewed):")
        for n in critical:
            click.echo(f"  {n.node_id}: {n.path}")


@audit_map.command("next")
@response_tier_option(default="L1")
@click.option("--bundle", default="audit-map.bundle.json", show_default=True)
@click.option("--strategy", type=click.Choice(["bfs", "dfs", "risk-first"]), default="risk-first")
@click.option("--max", "max_items", default=10, type=int)
@click.option("--kind", default=None)
def audit_map_next(
    bundle: str,
    strategy: str,
    max_items: int,
    kind: str | None,
    response_tier: str,
) -> None:
    from forge.tools.audit.bundle import load_bundle
    from forge.tools.audit.traversal import bfs_queue, dfs_queue, get_next_reason, risk_first_queue

    b = load_bundle(Path(bundle).expanduser())
    nodes = b.nodes
    if kind:
        nodes = [n for n in nodes if n.kind == kind]
    if strategy == "bfs":
        queue = bfs_queue(nodes, b.edges, max_items=max_items)
    elif strategy == "dfs":
        queue = dfs_queue(nodes, b.edges, max_items=max_items)
    else:
        queue = risk_first_queue(nodes, b.edges, max_items=max_items)
    if not queue:
        click.echo("Nothing to review. All nodes are verified or excluded.")
        return
    click.echo(f"Next {len(queue)} nodes (strategy: {strategy}):\n")
    for i, node in enumerate(queue, 1):
        reason = get_next_reason(node)
        click.echo(f"{i:2}. {node.node_id}")
        click.echo(f"    kind:   {node.kind}")
        click.echo(f"    status: {node.status}")
        click.echo(f"    why:    {reason}")
        click.echo(f"    probe:  forge audit meta --at {node.path}")
        click.echo()


@audit_map.command("verify")
@click.option("--bundle", default="audit-map.bundle.json", show_default=True)
def audit_map_verify(bundle: str) -> None:
    from forge.tools.audit.bundle import load_bundle, verify_l1_closure

    b = load_bundle(Path(bundle).expanduser())
    payload = {"verify": verify_l1_closure(b)}
    # Audit bundle verify output — not manifest modules; YAML dump intentional.
    click.echo(yaml.safe_dump(payload, sort_keys=False))


@audit_map.command("draw")
@click.option("--bundle", default="audit-map.bundle.json", show_default=True)
@click.option("--format", "fmt", type=click.Choice(["mermaid", "dot", "obsidian", "table", "md"]), default="mermaid")
@click.option(
    "--focus",
    type=click.Choice(
        ["branch", "coverage", "calls", "deps", "contracts", "change-impact", "drift", "annotations"],
    ),
    default="coverage",
)
@click.option("--depth", default=2, type=int)
@click.option("--at", "at_path", default=None)
@click.option("--traverse", type=click.Choice(["bfs", "dfs"]), default="bfs")
@click.option("--rings", default="4", show_default=True, help='CSV like "1,2" or "all"')
def audit_map_draw(
    bundle: str,
    fmt: str,
    focus: str,
    depth: int,
    at_path: str | None,
    traverse: str,
    rings: str,
) -> None:
    _ = traverse
    from forge.tools.audit.bundle import load_bundle
    from forge.tools.audit.renderer import (
        render_dot,
        render_md,
        render_mermaid,
        render_obsidian,
        render_rings_mermaid,
        render_table,
    )

    b = load_bundle(Path(bundle).expanduser())
    rings_sel: list[int] | None = None
    if rings.strip().lower() != "all":
        vals = [x.strip() for x in rings.split(",") if x.strip()]
        rings_sel = [int(x) for x in vals if x.isdigit()]
    if fmt == "mermaid":
        if rings_sel is not None or rings.strip().lower() == "all":
            if rings_sel is None:
                rings_sel = [1, 2, 3, 4, 5]
            click.echo(render_rings_mermaid(b, rings=rings_sel))
        else:
            click.echo(render_mermaid(b, focus=focus, depth=depth, at=at_path))
    elif fmt == "dot":
        click.echo(render_dot(b, focus=focus))
    elif fmt == "obsidian":
        click.echo(render_obsidian(b))
    elif fmt == "table":
        click.echo(render_table(b))
    elif fmt == "md":
        click.echo(render_md(b))


@audit_map.command("diff")
@response_tier_option(default="L1")
@click.option("--from", "from_bundle", required=True)
@click.option("--to", "to_bundle", default="audit-map.bundle.json", show_default=True)
@click.option("--format", "fmt", type=click.Choice(["md", "json"]), default="md")
def audit_map_diff(
    from_bundle: str,
    to_bundle: str,
    fmt: str,
    response_tier: str,
) -> None:
    from forge.tools.audit.bundle import load_bundle

    old = load_bundle(Path(from_bundle).expanduser())
    new = load_bundle(Path(to_bundle).expanduser())
    old_map = {n.node_id: n for n in old.nodes}
    new_map = {n.node_id: n for n in new.nodes}
    added = [n for nid, n in new_map.items() if nid not in old_map]
    removed = [n for nid, n in old_map.items() if nid not in new_map]
    changed: list[dict[str, str]] = []
    for nid, new_node in new_map.items():
        if nid in old_map:
            old_node = old_map[nid]
            if old_node.status != new_node.status:
                changed.append({"node_id": nid, "from": old_node.status, "to": new_node.status})
    old_cov = old.coverage or {}
    new_cov = new.coverage or {}
    delta_pct = (new_cov.get("pct_reviewed", 0) or 0) - (old_cov.get("pct_reviewed", 0) or 0)
    if fmt == "json":
        click.echo(
            json.dumps(
                {
                    "added": len(added),
                    "removed": len(removed),
                    "changed": changed,
                    "coverage_delta": delta_pct,
                },
                indent=2,
            ),
        )
        return
    click.echo("# Audit Map Diff\n")
    click.echo(
        f"Coverage: {old_cov.get('pct_reviewed', 0)}% → {new_cov.get('pct_reviewed', 0)}% "
        f"({'+' if delta_pct >= 0 else ''}{delta_pct}%)\n",
    )
    if added:
        click.echo(f"Added ({len(added)}):")
        for n in added:
            click.echo(f"  + {n.node_id}")
    if removed:
        click.echo(f"\nRemoved ({len(removed)}):")
        for n in removed:
            click.echo(f"  - {n.node_id}")
    if changed:
        click.echo(f"\nStatus changes ({len(changed)}):")
        for c in changed:
            click.echo(f"  {c['node_id']}: {c['from']} → {c['to']}")


@audit_map.command("check")
@click.option("--bundle", default="audit-map.bundle.json", show_default=True)
@click.option("--profile", type=click.Choice(["v1-default", "strict"]), default="v1-default")
def audit_map_check(bundle: str, profile: str) -> None:
    import sys

    from forge.tools.audit.bundle import load_bundle

    b = load_bundle(Path(bundle).expanduser())
    failures: list[str] = []
    critical_unreviewed = [
        n for n in b.nodes if n.critical and n.status in ("not_started", "observed_indirectly")
    ]
    if critical_unreviewed:
        failures.append(f"{len(critical_unreviewed)} critical node(s) not reviewed")
    blocked_no_evidence = [n for n in b.nodes if n.status == "blocked" and not n.evidence_refs]
    if blocked_no_evidence:
        failures.append(f"{len(blocked_no_evidence)} blocked node(s) have no evidence refs")
    required_kinds = ["branch"]
    for k in required_kinds:
        reviewed = sum(
            1
            for n in b.nodes
            if n.kind == k and n.status in ("reviewed_with_findings", "verified_clean")
        )
        if reviewed == 0:
            failures.append(f"No {k} nodes reviewed")
    if profile == "strict":
        not_reviewed = [n for n in b.nodes if n.status in ("not_started", "observed_indirectly")]
        if not_reviewed:
            failures.append(f"{len(not_reviewed)} node(s) not reviewed (strict profile)")
        open_high = [n for n in b.nodes if n.annotation_ids and n.critical]
        if open_high:
            failures.append(f"{len(open_high)} node(s) have open high-severity annotations")
    if failures:
        click.echo("❌ Audit check FAILED\n")
        for f in failures:
            click.echo(f"  • {f}")
        click.echo(f"\nProfile: {profile}")
        sys.exit(1)
    cov = b.coverage or b.compute_coverage()
    by_status = cov.get("by_status") or {}
    click.echo(f"✅ Audit check PASSED (profile: {profile})")
    click.echo(
        f"   {cov.get('pct_reviewed', 0)}% reviewed, {by_status.get('blocked', 0)} blocked",
    )

