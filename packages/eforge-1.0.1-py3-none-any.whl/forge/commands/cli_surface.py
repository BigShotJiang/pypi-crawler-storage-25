"""Single source for the `forge map`–generated CLI surface section in docs/MANIFEST.md."""

from __future__ import annotations


def cli_surface_markdown_section() -> str:
    """Markdown block appended to docs/MANIFEST.md by `forge map`. Keep in sync with docs/OPERATOR.md intent."""
    rows: list[tuple[str, str, str]] = [
        ("`forge list`", "Discovered projects", "workspace.yaml first, else `~/Projects` walk — not `forge projects list`."),
        ("`forge inspect`", "One project detail", "Uses discovery; same root as `list`."),
        ("`forge discover`", "Untracked files", "Human default; `--json` for programmatic output."),
        ("`forge manifest validate <name>`", "Validate discovered project", "By name under discovery; legacy: `forge manifest NAME --validate`. `--export` / `--migrate` stub."),
        ("`forge manifest path <ref>`", "ID → repo path", "Graph node ref → `path` (module/commands.map or shorthand)."),
        ("`forge manifest get <ref> [field]`", "Node field lookup", "`--json` for full record; fields id, kind, name, path, domain, role, owns, meta."),
        ("`forge map`", "Print graph to stdout", "Default: markdown/mermaid/json view — **not** doc regen."),
        ("`forge diff --full`", "Declaration vs observed diff", "Read-only report: dark matter, ghosts, missing edges, naming mismatches, error-code drift."),
        ("`forge map --write-docs`", "Regenerate MAP + MANIFEST", "Writes `docs/MAP.md` + `docs/MANIFEST.md` + `.forge/agent_context.json`. Also: impact-check hook."),
        ("`forge map` + `--format` / `--scope`", "Graph slice / global", "stdout or `--output`; mutually exclusive with `--write-docs`."),
        ("`forge verify`", "Diff → manifest propagation", "Structural gate; exit 2 = blocked. **Not** `forge audit verify`."),
        ("`forge verify --diff [plan|wiring|contracts|all]`", "Cross-graph diff", "plan=planned vs present, wiring=present vs connected, contracts=connected vs compliant."),
        ("`forge verify --preflight`", "App manifest pre-flight", "Validates planned graph/wiring/contracts before generation."),
        ("`forge verify --packet <path>`", "Context packet validation", "Checks freshness, review sign-off, graph hash, glove version, and atomicity."),
        ("`forge packet assemble`", "Assemble context packet", "Resolves glove contracts, manifest deps, outputs, and wiring into packet YAML for review."),
        ("`forge packet list|expire|archive`", "Packet queue lifecycle", "List pending packets, expire stale ones to archive, or manually archive consumed packets."),
        ("`forge impact-check`", "change-impact policy", "YAML policy on changed files. Default `--manifest docs/manifest.yaml` — forge repo uses root `manifest.yaml`."),
        ("`forge impact`", "Full impact by node_id", "Unified impact_radius; see also `forge blast-radius`."),
        ("`forge blast-radius`", "Ring-2 diagnostic", "Quick lookup by `--node` name or `--file` path; see also `forge impact`."),
        ("`forge annotate`", "Annotation sidecars", "Top-level alias for `forge audit annotate` (create/list/resolve)."),
        ("`forge project-status` / `forge status`", "Compact status snapshot", "Human default; MCP parity: `forge_project_status`."),
        ("`forge github-write`", "GitHub file write", "Writes constrained content paths via GitHub API (MCP parity: `forge_github_write`)."),
        ("`forge scan`", "Scanner / validation / orphans", "Path-based (default `.`). **No** `forge audit scan` CLI."),
        ("`forge reality`", "Import vs manifest", "RealityValidator — declared vs actual imports."),
        ("`forge query`", "Manifest graph query", "Same primitive as MCP `forge_query`; `--interactive` builder."),
        ("`forge init`", "Onboard repo", "Docs skeleton + manifest + `.forge/`."),
        ("`forge new`", "New greenfield project", "Interactive scaffold; different from `init`."),
        ("`forge init-docs`", "Docs tree from template", "`bootstrap_docs` + template path."),
        ("`forge toc`", "Markdown TOC", "`## Contents` maintenance."),
        ("`forge projects`", "Global registry", "`~/.forge/registry.yaml`; `list`/`add`/`import`/… **`scan` = stub**."),
        ("`forge workspace`", "workspace.yaml (legacy)", "Being merged into `forge projects`; warns on invoke."),
        ("`forge audit`", "EGMP", "Sessions, findings, **`audit verify`** = session gate, **`audit map`** = bundle."),
        ("`forge audit index`", "Annotation SQLite cache", "Sidecars → `.forge/audit-index.db`."),
        ("`forge context`", "Template maintenance", "list/edit templates, extractions — bundles via MCP `forge_context`."),
        ("`forge config`", "app_config.yaml", "Per-project app config, not manifest topology."),
        ("`forge board`", "Web dashboard", "FastAPI/React denvboard on port 7331."),
        ("`forge mcp`", "Handler harness", "Debug MCP tools locally; prod often `forge board --mcp`."),
        ("`forge scaffold`", "Composer / menu", "No subcommand → questionnaire menu."),
        ("`forge composer` / `workshop`", "HTTP API stubs", "Scaffold API surface."),
        ("`forge registry`", "**Template** registries", "`~/.forge/registries/` — not `forge projects`."),
        ("`forge doctor`", "Hygiene checks", "Forge package / paths — not policy diff like impact-check."),
    ]
    table = ["| Command | Role | Notes |", "| --- | --- | --- |"]
    for cmd, role, notes in rows:
        safe = notes.replace("|", "\\|")
        table.append(f"| {cmd} | {role} | {safe} |")

    confusion = [
        ("`forge verify` vs `forge audit verify`", "Diff/propagation vs **EGMP session** verify (`--session-id`)."),
        ("`forge map` vs `forge map --write-docs` vs `forge audit map`", "Print graph vs **write** MAP/MANIFEST vs **audit bundle** JSON."),
        ("`forge list` vs `forge projects list`", "**Discovery** vs **registry.yaml** rows."),
        ("`forge scan` vs MCP `forge_audit_scan`", "CLI scanner vs MCP audit scan — no `forge audit scan`."),
        ("`forge manifest validate` vs `forge map --write-docs`", "Named discovered project validate vs **cwd** graph → committed docs."),
        ("`forge impact-check` vs `forge verify`", "YAML **policy** on changed files vs **propagation** API."),
        ("`forge blast-radius` vs `forge impact`", "Quick ring-2 by name/file vs **full** analysis by node_id."),
        ("`forge annotate` vs `forge audit annotate`", "Same command group — top-level alias for convenience."),
        ("`forge registry` vs `forge projects`", "Template sources vs **project** registry."),
        ("`forge workspace` vs `forge projects`", "workspace.yaml (legacy) vs registry.yaml — migrate via `forge projects import`."),
        ("`forge context` vs MCP `forge_context`", "CLI template maintenance vs Gen3 context bundles."),
        ("`forge mcp` vs `forge board --mcp`", "Debug harness vs dashboard stdio server."),
    ]
    conf_lines = "\n".join(f"- **{a}** — {b}" for a, b in confusion)

    return "\n".join(
        [
            "## CLI surface (generated)",
            "",
            "_Appended by `forge map --write-docs` (MANIFEST regen). Source: `forge/commands/cli_surface.py` — edit there, not here._",
            "",
            "### Command index",
            "",
            *table,
            "",
            "### Pairs that are easy to confuse",
            "",
            conf_lines,
            "",
            "### Stubs, aliases, and gaps (rolling)",
            "",
            "- **`forge projects scan`** — stub; prints use `import` / `add`.",
            "- **`forge manifest --export` / `--migrate`** — not implemented (phase-gated).",
            "- **MCP-only** (no `forge` twin): consolidated `forge_audit`, `forge_audit_scan`, `forge_session_log`, etc. — parity gaps tracked under MCP annotations.",
            "",
            "_Narrative operator flow, EGMP, and audit map detail: [Operator Guide](OPERATOR.md)._",
            "",
        ],
    )
