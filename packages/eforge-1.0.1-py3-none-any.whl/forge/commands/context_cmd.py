from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import click

from forge.core.path_utils import resolve_project_path
from forge.tools.context.bootstrap_extractions import run_add_extractions
from forge.tools.context.index import index_staleness_report, rebuild_index
from forge.tools.context.templates import (
    BUILTIN_DIR,
    generate_template,
    list_templates,
    template_yaml_text,
)
from forge.tools.context.templates import _collect_template_files as collect_template_files


@click.group(
    "context",
    invoke_without_command=True,
    help=(
        "Manage context templates and extraction configuration.\n\n"
        "For context bundles use MCP: forge_context resource."
    ),
)
@click.option("--project-path", type=click.Path(file_okay=False), default=".", show_default=True)
@click.option("--check", "do_check", is_flag=True, help="Report context index staleness.")
@click.option("--rebuild-index", "do_rebuild", is_flag=True, help="Rebuild frontmatter index cache.")
@click.pass_context
def context_group(
    ctx: click.Context,
    project_path: str,
    do_check: bool,
    do_rebuild: bool,
) -> None:
    ctx.ensure_object(dict)
    root = resolve_project_path(project_path)
    if root is None:
        raise click.ClickException("project_path could not be resolved")
    ctx.obj["project_path"] = root
    if do_rebuild:
        rebuild_index(root)
        click.echo("Rebuilt frontmatter index → .forge/context_index.json")
    if do_check:
        rep = index_staleness_report(root)
        click.echo(rep.get("message", ""))
        if ctx.invoked_subcommand is None:
            raise SystemExit(0 if not rep.get("stale") else 1)
    if ctx.invoked_subcommand is not None:
        return
    click.echo(
        "Context bundles are provided via MCP — use the forge_context resource "
        "(not the CLI default).\n"
    )
    click.echo(ctx.get_help())


@context_group.command("new-template")
@click.argument("name")
@click.option("--feature", "feature_scope", required=True)
@click.pass_context
def new_template_cmd(ctx: click.Context, name: str, feature_scope: str) -> None:
    """Create a new context template for a feature scope."""
    root: Path = ctx.obj["project_path"]
    from forge.tools.context.index import FrontmatterIndex

    idx = FrontmatterIndex(root)
    idx.build(use_cache=False)
    generate_template(name, feature_scope, idx, root)
    click.echo(template_yaml_text(name, root))
    click.echo(f"\nTemplate saved. Use with:\n  forge context show-template {name}")


@context_group.command("list-templates")
@click.pass_context
def list_templates_cmd(ctx: click.Context) -> None:
    """List available context templates."""
    root: Path = ctx.obj["project_path"]
    rows = list_templates(root)
    click.echo(f"{'name':<16} {'source':<10} {'level':<8} description")
    for r in rows:
        click.echo(
            f"{r['name']:<16} {r['source']:<10} {r.get('level', ''):<8} {r.get('description', '')}"
        )


@context_group.command("show-template")
@click.argument("name")
@click.pass_context
def show_template_cmd(ctx: click.Context, name: str) -> None:
    """Show a context template as YAML."""
    root: Path = ctx.obj["project_path"]
    click.echo(template_yaml_text(name, root))


@context_group.command("edit-template")
@click.argument("name")
@click.pass_context
def edit_template_cmd(ctx: click.Context, name: str) -> None:
    """Edit a context template in $EDITOR."""
    root: Path = ctx.obj["project_path"]
    files = collect_template_files(root)
    editor = os.environ.get("EDITOR", "vi")
    if name not in files:
        raise click.ClickException(f"unknown template: {name}")
    src = files[name]
    proj_dir = root / ".forge" / "context-templates"
    proj_dir.mkdir(parents=True, exist_ok=True)
    dest = proj_dir / f"{name}.yaml"
    try:
        is_builtin = src.resolve().is_relative_to(BUILTIN_DIR.resolve())
    except (AttributeError, ValueError, OSError):
        is_builtin = str(src).startswith(str(BUILTIN_DIR))
    if is_builtin:
        if not dest.exists():
            shutil.copy(src, dest)
            click.echo(f"Copied builtin template to {dest}")
        target = dest
    else:
        target = src
    subprocess.run([editor, str(target)], check=False)


@context_group.command("add-extractions")
@click.option("--project", "project_opt", type=click.Path(file_okay=False), default=None)
@click.option("--dry-run", is_flag=True, default=False)
@click.pass_context
def add_extractions_cmd(ctx: click.Context, project_opt: str | None, dry_run: bool) -> None:
    """Add known_broken extraction sentinels to frontmatter."""
    root = Path(project_opt).resolve() if project_opt else ctx.obj["project_path"]
    fc, n = run_add_extractions(root, dry_run=dry_run)
    click.echo(
        f"Added known_broken: [] to {fc} file(s) ({n} field(s))"
        + (" (dry-run)" if dry_run else "")
    )


@context_group.command("rebuild-index")
@click.pass_context
def rebuild_index_cmd(ctx: click.Context) -> None:
    """Rebuild the frontmatter index cache."""
    root: Path = ctx.obj["project_path"]
    rebuild_index(root)
    click.echo("Rebuilt .forge/context_index.json")
