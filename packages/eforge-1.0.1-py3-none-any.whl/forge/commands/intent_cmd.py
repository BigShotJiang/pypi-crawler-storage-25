from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click
from click.core import ParameterSource

from forge.commands._shared_options import response_tier_option
from forge.core.path_utils import resolve_project_path
from forge.mcp.thin_core import execute_intent_query, execute_intent_update
from forge.tools.intent.runtime import (
    add_intent_record,
    import_obsidian_transcript,
    load_intent_by_id,
    load_intent_records,
    new_intent_record,
)


@click.group("intent")
def intent_group() -> None:
    """Intent graph commands."""


@intent_group.command("add")
@click.option("--project-path", default=".", type=click.Path(file_okay=False), show_default=True)
@click.option("--scope", "scope", type=click.Choice(["project", "feature", "node"], case_sensitive=False), required=True)
@click.option("--target-id", default=None, help="Declaration graph node id.")
@click.option(
    "--from-description",
    "legacy_from_description",
    is_flag=True,
    default=False,
    hidden=True,
    help="Removed; use Claude chat + MCP to author intents.",
)
@click.argument("description")
@response_tier_option(default="L1")
@click.pass_context
def intent_add_cmd(
    ctx: click.Context,
    project_path: str,
    scope: str,
    target_id: str | None,
    legacy_from_description: bool,
    description: str,
    response_tier: str,
) -> None:
    root = resolve_project_path(project_path)
    if legacy_from_description:
        raise click.UsageError(
            "not supported — author intent records via Claude chat and forge intent add"
        )
    rec = new_intent_record(scope=scope.lower(), description=description, target_id=target_id, source="manual")
    add_intent_record(root, rec)
    tier_explicit = ctx.get_parameter_source("response_tier") == ParameterSource.COMMANDLINE
    if tier_explicit:
        payload = {
            "intent_id": rec.id,
            "node_type": rec.scope,
            "file_path": str((root / ".forge" / "intent" / f"{rec.id}.yaml").resolve()),
        }
        click.echo(json.dumps(payload, indent=2))
        return
    click.echo(f"created intent_record: {rec.id}")


@intent_group.command("import")
@click.option("--project-path", default=".", type=click.Path(file_okay=False), show_default=True)
@click.option("--source", "source_kind", type=click.Choice(["obsidian"], case_sensitive=False), required=True)
@click.argument("file_path", type=click.Path(dir_okay=False))
def intent_import_cmd(project_path: str, source_kind: str, file_path: str) -> None:
    root = resolve_project_path(project_path)
    if source_kind.lower() != "obsidian":
        raise click.ClickException("TODO: only obsidian import is currently supported.")
    created = import_obsidian_transcript(root, Path(file_path).expanduser().resolve())
    click.echo(f"imported {len(created)} intent_record(s)")


@intent_group.command("query")
@click.option("--project-path", default=".", type=click.Path(file_okay=False), show_default=True)
@click.option("--target-id", default=None, help="Filter by declaration graph node id.")
@click.option("--status", default=None, help="Filter by intent status (e.g. active).")
@click.option("--scope", default=None, help="Filter by scope (project, feature, node).")
@click.option("--since", default=None, help="ISO datetime — only records created at or after.")
@click.option("--limit", default=0, type=int, help="Cap rows (0 = no limit).")
@response_tier_option(default="L1")
@click.option(
    "--pretty/--json-line",
    "pretty_json",
    default=False,
    show_default=True,
    help="Pretty-print JSON; default is one line (matches MCP forge_intent query).",
)
def intent_query_cmd(
    project_path: str,
    target_id: str | None,
    status: str | None,
    scope: str | None,
    since: str | None,
    limit: int,
    response_tier: str,
    pretty_json: bool,
) -> None:
    """Query intent records + coverage_rollup (same payload as MCP ``forge_intent`` query)."""
    root = resolve_project_path(project_path)
    arguments: dict[str, Any] = {
        "project_path": str(root),
        "response_tier": response_tier,
        "limit": limit,
    }
    if target_id is not None:
        arguments["target_id"] = target_id
    if status is not None:
        arguments["status"] = status
    if scope is not None:
        arguments["scope"] = scope
    if since is not None:
        arguments["since"] = since
    payload = execute_intent_query(arguments)
    if pretty_json:
        click.echo(json.dumps(payload, indent=2))
        return
    click.echo(json.dumps(payload, separators=(",", ":")))


@intent_group.command("list")
@click.option("--project-path", default=".", type=click.Path(file_okay=False), show_default=True)
@response_tier_option(default="L1")
def intent_list_cmd(project_path: str, response_tier: str) -> None:
    root = resolve_project_path(project_path)
    records = load_intent_records(root)
    payload = [
        {
            "intent_id": r.id,
            "node_type": r.scope,
            "status": r.status,
            "created_at": r.created_at,
        }
        for r in records
    ]
    if str(response_tier or "L1").upper() == "L0":
        click.echo(json.dumps([r["intent_id"] for r in payload], indent=2))
        return
    click.echo(json.dumps(payload, indent=2))


_INTENT_STATUS_CLI = {
    "open": "active",
    "done": "deprecated",
    "superseded": "superseded",
}


@intent_group.command("update")
@click.argument("record_id")
@click.option("--target-id", "target_id", default=None, help="Manifest node ID this intent covers")
@click.option("--description", "description", default=None, help="Updated intent description")
@click.option(
    "--status",
    "status",
    type=click.Choice(["open", "done", "superseded"]),
    default=None,
    help="Intent status (open=active, done=deprecated)",
)
@click.option("--rationale", "rationale", default=None, help="Updated rationale (stored in elicitation_schema)")
@click.option("--project-path", "project_path", default=".", show_default=True)
@click.pass_context
def intent_update_cmd(
    ctx: click.Context,
    record_id: str,
    target_id: str | None,
    description: str | None,
    status: str | None,
    rationale: str | None,
    project_path: str,
) -> None:
    """Update an existing intent record.

    RECORD_ID is the intent record UUID.
    """
    from rich.console import Console

    _ = ctx
    console = Console()
    root = Path(project_path).expanduser().resolve()

    args: dict[str, Any] = {
        "project_path": str(root),
        "record_id": record_id,
    }
    if target_id:
        args["target_id"] = target_id
    if description:
        args["description"] = description
    if status:
        args["status"] = _INTENT_STATUS_CLI.get(status, status)
    if rationale:
        args["rationale"] = rationale

    try:
        result = execute_intent_update(args)
        if result.get("confirmation_status") == "updated":
            console.print(f"[green]✓ Updated intent {record_id}[/green]")
            if target_id:
                console.print(f"  target_id: {target_id}")
            if status:
                console.print(f"  status: {status}")
        elif result.get("confirmation_status") == "not_found":
            console.print(f"[red]Error: intent record {record_id!r} not found[/red]")
            raise SystemExit(1)
        else:
            console.print(f"[red]Error: {result.get('error', 'Failed')}[/red]")
            raise SystemExit(1)
    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise SystemExit(1) from e


@intent_group.command("show")
@click.option("--project-path", default=".", type=click.Path(file_okay=False), show_default=True)
@click.argument("intent_id")
@response_tier_option(default="L1")
def intent_show_cmd(project_path: str, intent_id: str, response_tier: str) -> None:
    _ = response_tier
    root = resolve_project_path(project_path)
    rec = load_intent_by_id(root, intent_id)
    if rec is None:
        raise click.ClickException(f"Intent not found: {intent_id}")
    click.echo(json.dumps(rec.to_yaml_dict(), indent=2))
