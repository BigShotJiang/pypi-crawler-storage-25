from __future__ import annotations

from pathlib import Path

import click

from forge.tools.init_docs.config import resolve_template_path
from forge.tools.toc.generator import (
    has_contents_toc_section,
    heading_count_for_toc,
    update_directory_toc,
    update_file_toc,
)


@click.command("toc", help="Insert or refresh ## Contents TOC in Markdown files.")
@click.argument("file", required=False, type=click.Path(exists=True, dir_okay=False))
@click.option("--project", "project_dir", type=click.Path(exists=True, file_okay=False), default=None)
@click.option("--all", "all_flag", is_flag=True, help="Update docs/ under cwd and DOCS-TEMPLATE (if resolvable).")
@click.option("--check", "check_dir", type=click.Path(exists=True, file_okay=False), default=None)
@click.option("--dry-run", is_flag=True)
@click.option("--recursive/--no-recursive", default=True, show_default=True)
@click.option("--min-headings", type=int, default=3, show_default=True)
@click.option(
    "--include-templates",
    is_flag=True,
    default=False,
    help="With --project: also scan FORGE_DOCS_TEMPLATE_PATH.",
)
def toc_cmd(
    file: str | None,
    project_dir: str | None,
    all_flag: bool,
    check_dir: str | None,
    dry_run: bool,
    recursive: bool,
    min_headings: int,
    include_templates: bool,
) -> None:
    click.echo(
        "forge toc is deprecated — use forge_context() or forge_manifest_graph(format=index) instead",
        err=True,
    )
    n = sum([bool(file), bool(all_flag), bool(project_dir), bool(check_dir)])
    if n != 1:
        raise click.UsageError("Specify exactly one of: FILE, --project, --all, or --check")

    if check_dir:
        root = Path(check_dir).resolve()
        md_files = list(root.rglob("*.md")) if recursive else list(root.glob("*.md"))
        bad: list[str] = []
        for fp in sorted(md_files):
            if "node_modules" in fp.parts or ".git" in fp.parts:
                continue
            text = fp.read_text(encoding="utf-8")
            nhead = heading_count_for_toc(text, 2, 3)
            if nhead < min_headings:
                continue
            if not has_contents_toc_section(text):
                try:
                    rel = fp.relative_to(root)
                    bad.append(str(rel))
                except ValueError:
                    bad.append(str(fp))
        if bad:
            click.echo(f"Missing ## Contents ({len(bad)} file(s)):", err=True)
            for b in bad:
                click.echo(f"  {b}", err=True)
            click.echo("Run: forge toc <file> or forge toc --project ...", err=True)
            raise SystemExit(1)
        click.echo("TOC check OK.")
        raise SystemExit(0)

    if file:
        r = update_file_toc(Path(file), min_headings=min_headings, dry_run=dry_run)
        p = r.get("path", file)
        h = r.get("headings", 0)
        a = r.get("action")
        if a == "error":
            click.echo(f"✗ Error: {p}: {r.get('message', '')}", err=True)
            raise SystemExit(1)
        if a == "no_headings":
            click.echo(f"↷ Skipped: {p} ({h} headings, min is {min_headings})")
            raise SystemExit(0)
        if a == "no_change":
            click.echo(f"✓ No change: {p} (TOC current, {h} headings)")
            raise SystemExit(0)
        if dry_run and r.get("preview"):
            click.echo(r["preview"])
        click.echo(f"✓ {'Would update' if dry_run else 'Updated'}: {p} ({h} headings)")
        raise SystemExit(0)

    roots: list[Path] = []
    if all_flag:
        roots.append(Path.cwd() / "docs")
        try:
            roots.append(resolve_template_path())
        except FileNotFoundError:
            pass
    else:
        roots.append(Path(project_dir).resolve())
        if include_templates:
            try:
                roots.append(resolve_template_path())
            except FileNotFoundError:
                click.echo(
                    "(FORGE_DOCS_TEMPLATE_PATH / sibling DOCS-TEMPLATE not found; skipping templates)",
                    err=True,
                )

    all_results: list[dict] = []
    for root in roots:
        if not root.is_dir():
            click.echo(f"(skip missing directory: {root})", err=True)
            continue
        all_results.extend(
            update_directory_toc(
                root,
                recursive=recursive,
                min_headings=min_headings,
                dry_run=dry_run,
            )
        )

    for r in all_results:
        a = r.get("action")
        p = r.get("path", "")
        h = r.get("headings", 0)
        if a in ("inserted", "updated") and r.get("changed"):
            click.echo(f"✓ {'[dry-run] ' if dry_run else ''}{a}: {p} ({h} headings)")
        elif a == "no_change":
            click.echo(f"✓ No change: {p}")
        elif a == "no_headings":
            click.echo(f"↷ Skipped: {p} ({h} headings, min {min_headings})")
        elif a == "error":
            click.echo(f"✗ {p}: {r.get('message')}", err=True)

    updated = sum(1 for r in all_results if r.get("action") in ("inserted", "updated") and r.get("changed"))
    skipped = sum(1 for r in all_results if r.get("action") == "no_headings")
    nochange = sum(1 for r in all_results if r.get("action") == "no_change")
    nerr = sum(1 for r in all_results if r.get("action") == "error")

    click.echo("")
    click.echo(f"Updated:   {updated}")
    click.echo(f"Skipped:   {skipped} (too few headings)")
    click.echo(f"No change: {nochange}")
    click.echo(f"Errors:    {nerr}")
    raise SystemExit(1 if nerr else 0)
