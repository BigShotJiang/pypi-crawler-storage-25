"""
forge.commands.stack_cmd
CLI command for dynamic stack management and extensibility.
"""

import click
import json
from pathlib import Path

from . import _shared_options
from ..core.template_generator import TemplateGenerator, EXAMPLE_STACKS


@click.group()
def stack():
    """Manage dynamic stacks and templates for Forge extensibility."""
    pass


@stack.command()
@_shared_options.project_path_option()
def list(project_path: str):
    """List all available stack templates."""
    project_root = Path(project_path).expanduser()
    generator = TemplateGenerator(project_root)
    
    stacks = generator.list_available_stacks()
    
    if stacks:
        click.echo("Available stack templates:")
        for stack in stacks:
            config = generator.get_stack_config(stack)
            description = config.get('stack', {}).get('description', 'No description')
            click.echo(f"  {stack}: {description}")
    else:
        click.echo("No stack templates found.")


@stack.command()
@_shared_options.project_path_option()
@click.argument("stack_id")
def show(project_path: str, stack_id: str):
    """Show details of a specific stack template."""
    project_root = Path(project_path).expanduser()
    generator = TemplateGenerator(project_root)
    
    config = generator.get_stack_config(stack_id)
    if not config:
        click.echo(f"Stack '{stack_id}' not found.", err=True)
        return 1
    
    click.echo(f"Stack: {stack_id}")
    click.echo(f"Description: {config.get('stack', {}).get('description', 'No description')}")
    
    if config.get('file_extensions'):
        click.echo(f"File extensions: {', '.join(config['file_extensions'])}")
    
    if config.get('indicators'):
        click.echo(f"Indicators: {', '.join(config['indicators'])}")
    
    if config.get('import_patterns'):
        click.echo("Import patterns:")
        for pattern in config['import_patterns']:
            click.echo(f"  - {pattern}")
    
    if config.get('node_types'):
        click.echo("Node types:")
        for node_type, node_config in config['node_types'].items():
            click.echo(f"  {node_type}:")
            if node_config.get('output_paths'):
                click.echo(f"    Output paths: {', '.join(node_config['output_paths'])}")
    
    return 0


@stack.command()
@_shared_options.project_path_option()
@click.argument("stack_id")
@click.option("--from-example", help="Create from example stack (rust, typescript, go)")
def create(project_path: str, stack_id: str, from_example: str):
    """Create a new stack template."""
    project_root = Path(project_path).expanduser()
    generator = TemplateGenerator(project_root)
    
    # Check if stack already exists
    if generator.get_stack_config(stack_id):
        click.echo(f"Stack '{stack_id}' already exists.", err=True)
        return 1
    
    # Use example or prompt for config
    if from_example:
        if from_example not in EXAMPLE_STACKS:
            click.echo(f"Example stack '{from_example}' not found.", err=True)
            click.echo(f"Available examples: {', '.join(EXAMPLE_STACKS.keys())}")
            return 1
        
        config = EXAMPLE_STACKS[from_example]
        click.echo(f"Creating stack '{stack_id}' from example '{from_example}'...")
    else:
        click.echo("Creating new stack template...")
        click.echo("For automated creation, use --from-example")
        click.echo("Manual configuration not yet implemented.")
        return 1
    
    success = generator.create_stack_template(stack_id, config)
    if success:
        click.echo(f"Successfully created stack template: {stack_id}")
        click.echo(f"Files created:")
        click.echo(f"  - .forge/gloves/{stack_id}.glove.yaml")
        click.echo(f"  - .forge/templates/{stack_id}_parser.py")
        click.echo(f"  - .forge/meta/{stack_id}_meta.yaml")
        return 0
    else:
        click.echo(f"Failed to create stack template: {stack_id}", err=True)
        return 1


@stack.command()
@_shared_options.project_path_option()
@click.argument("stack_id")
@click.argument("indicators", nargs=-1)
def register(project_path: str, stack_id: str, indicators: tuple):
    """Register new indicators for stack detection."""
    project_root = Path(project_path).expanduser()
    generator = TemplateGenerator(project_root)
    
    if not indicators:
        click.echo("No indicators provided.", err=True)
        return 1
    
    success = generator.register_stack_indicators(stack_id, list(indicators))
    if success:
        click.echo(f"Registered indicators for '{stack_id}': {', '.join(indicators)}")
        return 0
    else:
        click.echo(f"Failed to register indicators for '{stack_id}'", err=True)
        return 1


@stack.command()
@_shared_options.project_path_option()
def examples():
    """Show available example stacks."""
    click.echo("Available example stacks:")
    for stack_id, config in EXAMPLE_STACKS.items():
        description = config.get('description', 'No description')
        click.echo(f"  {stack_id}: {description}")
        if config.get('file_extensions'):
            click.echo(f"    Extensions: {', '.join(config['file_extensions'])}")
        if config.get('indicators'):
            click.echo(f"    Indicators: {', '.join(config['indicators'])}")


@stack.command()
@_shared_options.project_path_option()
@click.argument("stack_id")
@click.option("--config", help="JSON configuration for the stack")
def add(project_path: str, stack_id: str, config: str):
    """Add a new stack with custom configuration."""
    project_root = Path(project_path).expanduser()
    generator = TemplateGenerator(project_root)
    
    # Check if stack already exists
    if generator.get_stack_config(stack_id):
        click.echo(f"Stack '{stack_id}' already exists.", err=True)
        return 1
    
    if config:
        try:
            stack_config = json.loads(config)
        except json.JSONDecodeError as e:
            click.echo(f"Invalid JSON configuration: {e}", err=True)
            return 1
    else:
        click.echo("Configuration required. Use --config with JSON.", err=True)
        return 1
    
    success = generator.create_stack_template(stack_id, stack_config)
    if success:
        click.echo(f"Successfully created stack template: {stack_id}")
        return 0
    else:
        click.echo(f"Failed to create stack template: {stack_id}", err=True)
        return 1


# Create the main stack command
stack_cmd = stack
