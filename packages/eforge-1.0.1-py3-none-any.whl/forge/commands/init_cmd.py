from __future__ import annotations

from pathlib import Path

import click
import json

from forge.commands._shared_options import response_tier_option
from forge.core.path_utils import resolve_project_path
from forge.tools.init_project.runner import (
    _detect_stack,
    framework_to_stack,
    run_forge_init,
)
from forge.tools.scan.detector import detect_framework

STACK_OPTIONS = {
    "1": "flutter-app",
    "2": "python",
    "3": "astro",
    "4": "react",
    "5": "web",
    "6": "unknown",
}

STACK_LABELS = {
    "flutter-app": "Flutter / Dart",
    "python": "Python",
    "astro": "Astro",
    "react": "React / Next.js",
    "web": "Web (JS/TS)",
    "unknown": "Other / manual",
}


def _detect_stack_with_fallback(project_path: Path) -> str:
    """Detect stack from files; fall back to framework sniffing."""
    detected = _detect_stack(project_path)
    if detected != "unknown":
        return detected
    primary, _, _ = detect_framework(project_path)
    return framework_to_stack(primary, None)


def _prompt_stack_selection(
    project_path: Path,
    detected_stack: str,
) -> str:
    """Interactive stack confirmation (default path)."""
    detected_label = STACK_LABELS.get(detected_stack, detected_stack)

    click.echo("\n✦ eforge — initialize project")
    click.echo(f"  path: {project_path}\n")

    if detected_stack != "unknown":
        click.echo(f"  Detected stack: {detected_label}")
        click.echo("  (found indicator file)\n")

    click.echo("  Available stacks:")
    for key, val in STACK_OPTIONS.items():
        marker = " ← detected" if val == detected_stack else ""
        label = STACK_LABELS.get(val, val)
        click.echo(f"    [{key}] {label}{marker}")

    default_key = next(
        (k for k, v in STACK_OPTIONS.items() if v == detected_stack),
        "6",
    )

    choice = click.prompt(
        "\n  Enter number to confirm",
        default=default_key,
    )
    return STACK_OPTIONS.get(choice.strip(), detected_stack)


def _resolve_init_stack(
    project_path: Path,
    *,
    stack: str | None,
    yes: bool,
    json_output: bool,
) -> str:
    """
    Resolve stack for init.

    Priority:
      1. --stack (explicit override)
      2. Interactive prompt (default)
      3. --yes or --json (auto-accept detected)
      4. File-based detection
    """
    if stack and str(stack).strip():
        return stack.strip().lower()

    detected_stack = _detect_stack_with_fallback(project_path)
    detected_label = STACK_LABELS.get(detected_stack, detected_stack)

    if yes or json_output:
        if yes and not json_output:
            click.echo(
                f"\n  Stack: {detected_label} (--yes, skipping prompt)\n"
            )
        return detected_stack

    return _prompt_stack_selection(project_path, detected_stack)


@click.command("init")
@click.option("--project-path", default=".", show_default=True, type=click.Path(file_okay=False))
@click.option("--dry-run", is_flag=True, help="Show planned actions without writing files.")
@click.option("--force", is_flag=True, help="Overwrite existing files (requires confirmation unless --dry-run).")
@click.option("--minimal", is_flag=True, help="Only docs/manifest.yaml and docs/AGENT_CONTEXT.md.")
@click.option(
    "--stack",
    default=None,
    help="Stack to use (skips detection and interactive prompt).",
)
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    default=False,
    help="Accept detected stack without prompt.",
)
@click.option("--json", "json_output", is_flag=True, help="Emit JSON only (no human summary).")
@response_tier_option(default="L1")
def init_cmd(
    project_path: str,
    dry_run: bool,
    force: bool,
    minimal: bool,
    stack: str | None,
    yes: bool,
    json_output: bool,
    response_tier: str,
) -> None:
    """Onboard an existing project: docs skeleton, manifest, .forge/, optional workspace registration.

    Sets up Forge project structure for existing codebases. Creates manifest.yaml,
    documentation skeleton, and optional workspace registration. Essential for
    bringing existing projects under Forge management.

    Examples:
      forge init                                    # Guided stack selection
      forge init --yes                              # Auto-accept detected stack
      forge init --stack flutter-app                # Explicit stack (no prompt)
      forge init --minimal                          # Minimal setup (manifest + context only)
      forge init --dry-run                          # Preview what will be created
      forge init --force                            # Overwrite existing files
      forge init --json --yes                       # JSON only, no prompts

    Next Steps (after init):
      forge orient       — see project health
      forge discover     — find undeclared files
      forge verify       — check parity
      forge map          — visualize structure
    """
    root = resolve_project_path(project_path)
    chosen_stack = _resolve_init_stack(
        root,
        stack=stack,
        yes=yes,
        json_output=json_output,
    )

    if force and not dry_run:
        preview = run_forge_init(
            root,
            dry_run=True,
            force=True,
            minimal=minimal,
            stack_override=chosen_stack,
        )
        if preview.overwritten and not click.confirm(
            f"Overwrite {len(preview.overwritten)} existing file(s)?",
            default=False,
        ):
            click.echo("Aborted.")
            raise SystemExit(1)

    res = run_forge_init(
        root,
        dry_run=dry_run,
        force=force,
        minimal=minimal,
        stack_override=chosen_stack,
    )
    payload = {
        "project_path": str(root),
        "manifest_created": any(
            p in {".forge/manifest.yaml", "docs/manifest.yaml"}
            for p in (res.created or [])
        ),
        "workspace_registered": any(
            "workspace: registered" in str(n) for n in (res.notes or [])
        ),
        "stack": res.stack,
        "docs_bootstrapped": any(
            str(p).startswith("docs/") for p in (res.created or [])
        ),
    }
    tier = str(response_tier or "L1").upper()
    if tier == "L0":
        click.echo(f"forge init complete: {res.project_name}")
        return
    if json_output:
        click.echo(json.dumps(payload, indent=2))
        return
    click.echo(json.dumps(payload, indent=2))
    print("\n✦ eforge initialized\n")
    print(f"  project : {root.name}")
    print(f"  stack   : {res.stack}")
    print(f"  manifest: .forge/manifest.yaml")
    print(f"  status  : ready\n")
    print("Next steps:")
    print("  forge orient       — see project health")
    print("  forge discover     — find undeclared files")
    print("  forge verify       — check parity")
    print("  forge map          — visualize structure")
    print()
