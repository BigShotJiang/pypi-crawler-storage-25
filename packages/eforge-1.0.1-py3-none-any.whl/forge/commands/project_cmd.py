import click
import json
from click.core import ParameterSource
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from forge.commands._shared_options import response_tier_option
from forge.core.discovery import discover_projects, get_projects_root
from forge.core.manifest import ManifestParser
from forge.core.manifest_path import resolve_manifest_path
from forge.tools.manifest.graph import build_manifest_graph


@click.command("project")
@click.argument("project_name")
@click.option(
    "--project-path",
    "project_path",
    default="~/Projects",
    show_default=True,
    help="Workspace root path.",
)
@response_tier_option(default="L1")
@click.pass_context
def project_cmd(
    ctx: click.Context,
    project_name: str,
    project_path: str,
    response_tier: str,
) -> None:
    """Show workspace project details (discovery). Use `forge inspect` for graph navigation."""
    workspace_root = Path(str(project_path)).expanduser().resolve()
    projects = discover_projects(workspace_root if project_path else get_projects_root())
    match = next((p for p in projects if p.name.lower() == project_name.lower()), None)
    if not match:
        click.echo(f"Project '{project_name}' not found.")
        raise SystemExit(1)
    p = match
    manifest_data: dict[str, object] = {}
    mp = resolve_manifest_path(Path(p.path))
    if mp is not None and mp.is_file():
        parsed = ManifestParser(mp).parse()
        if parsed.ok and isinstance(parsed.value, dict):
            manifest_data = parsed.value
    stack = str(manifest_data.get("stack") or p.type)
    phase = p.current_phase()
    response_source = ctx.get_parameter_source("response_tier")
    tier_explicit = response_source == ParameterSource.COMMANDLINE
    if tier_explicit:
        tier = str(response_tier or "L1").upper()
        if tier == "L0":
            payload: dict[str, object] = {
                "name": p.name,
                "stack": stack,
                "phase": phase,
            }
        else:
            payload = {
                "name": p.name,
                "type": p.type,
                "stack": stack,
                "version": p.version,
                "phase": phase,
                "phase_label": p.phase_label(),
                "path": str(p.path),
                "repo": p.repo,
                "branch": p.branch,
                "description": p.description,
                "dashboard_checks": [
                    {"label": dc.label, "check": dc.check, "type": dc.type}
                    for dc in p.dashboard_checks
                ],
                "phases": p.phases,
                "notes": p.notes,
                "warnings": p.warnings,
                "domain": p.domain,
                "app_config_meta": p.app_config_meta,
                "dependencies": p.dependencies,
            }
            if tier == "L2":
                graph = build_manifest_graph(Path(p.path))
                nodes = list(getattr(graph, "nodes", []) or [])
                domain_list = sorted(
                    {
                        str(getattr(n, "domain", "") or "")
                        for n in nodes
                        if str(getattr(n, "domain", "") or "")
                    }
                )
                orphan_count = sum(
                    1
                    for n in nodes
                    if str(getattr(n, "path", "") or "")
                    and not (Path(p.path) / str(getattr(n, "path", ""))).exists()
                )
                payload["graph_summary"] = {
                    "node_count": len(nodes),
                    "domain_list": domain_list,
                    "orphans": orphan_count,
                }
        click.echo(json.dumps(payload, indent=2))
        return
    console = Console()
    console.print(Panel(p.render_summary(), title=f"{p.name} — {p.type} v{p.version}"))
    console.print(f"[bold]Phase:[/] {p.phase_label()}")
    console.print(f"[bold]Path:[/] {p.path}")
    if p.description:
        console.print(f"[bold]Description:[/] {p.description}")
    console.print("[bold]Dashboard checks (configured):[/]")
    table = Table()
    table.add_column("Label")
    table.add_column("Check")
    table.add_column("Type")
    for dc in p.dashboard_checks:
        table.add_row(dc.label, dc.check, dc.type)
    console.print(table)
    console.print("[bold]Phases:[/]", str(p.phases))
    if p.notes:
        console.print("[bold]Notes:[/]", p.notes)
    if p.warnings:
        console.print("[yellow][bold]Warnings:[/][/yellow]", "\n".join(p.warnings))
