"""
forge.commands.inspect_cmd

forge inspect — progressive node inspection via the graph engine.

The CLI mirror of the forge_inspect MCP tool.
Uses the same execute_inspect() path so CLI and MCP always return identical data.

Usage:
  forge inspect module/engine.engine
  forge inspect engine.engine --ring 1
  forge inspect engine.engine --expand 2
  forge inspect engine.engine --diff
  forge inspect engine.engine --tier L2
  forge inspect --domain ENGINE
  forge inspect --kind component --stack astro
  forge inspect                    # interactive domain + node picker
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from forge.commands._shared_options import response_tier_option
from forge.core.path_utils import resolve_project_path


def _display_inspect_result(
    console: Console,
    result: dict[str, Any],
    action: str,
) -> None:
    """Rich renderer for execute_inspect results (shared by CLI and interactive path)."""
    if action == "node":
        node = result.get("node") or {}
        nid = result.get("node_id", "")
        handle_val = result.get("handle", "")
        rings = result.get("rings", {})
        counts = result.get("counts", {})

        header = Text()
        header.append(nid, style="bold cyan")
        header.append(f"  [{node.get('kind', '?')}]", style="green")
        header.append(f"  {node.get('domain', '?')}", style="yellow")
        header.append(f"  {node.get('status', '?')}", style="dim")
        console.print(Panel(header, title="forge inspect"))

        ring_table = Table(show_header=True, title="Rings")
        ring_table.add_column("Ring", style="cyan", width=8)
        ring_table.add_column("Count", style="white", width=8)
        ring_table.add_column("IDs (preview)")
        for rnum in ("1", "2", "3"):
            ring_data = rings.get(rnum, {})
            count = ring_data.get("count", 0)
            ids = ring_data.get("ids", [])
            preview = ", ".join(str(i) for i in ids[:3])
            if len(ids) > 3:
                preview += f" +{len(ids) - 3} more"
            ring_table.add_row(
                f"Ring {rnum}",
                str(count),
                preview or "[dim]none[/dim]",
            )
        console.print(ring_table)

        if any(counts.values()):
            console.print(
                f"[dim]annotations: {counts.get('annotations', 0)} | "
                f"intents: {counts.get('intents', 0)} | "
                f"violations: {counts.get('tier_violations', 0)} | "
                f"drift: {counts.get('drift_items', 0)}[/dim]"
            )

        console.print(f"\n[dim]handle: {handle_val}[/dim]")
        actions = result.get("available_actions", [])
        if actions:
            console.print("[dim]available actions:[/dim]")
            for a in actions:
                ring_param = a.get("params", {}).get("ring", "")
                ring_suffix = f"  --ring {ring_param}" if ring_param else ""
                console.print(
                    f"[dim]  forge inspect --action {a['action']} "
                    f"--handle {handle_val}{ring_suffix}[/dim]"
                )

    elif action == "expand":
        nodes = result.get("nodes", [])
        ring_num = result.get("ring", "?")
        console.print(f"[bold]Ring {ring_num} — {len(nodes)} nodes[/bold]")
        for n in nodes:
            console.print(
                f"  [cyan]{n.get('id', '')}[/cyan]"
                f" [{n.get('kind', '')}]"
                f" {n.get('domain', '')}"
            )

    elif action == "diff":
        drift = result.get("drift_items", [])
        if not drift:
            console.print("[green]✓ No drift detected[/green]")
        else:
            console.print(f"[yellow]{len(drift)} drift item(s):[/yellow]")
            for d in drift:
                console.print(
                    f"  [yellow]{d.get('drift_class', '')}[/yellow]"
                    f" — {d.get('detail', '')}"
                )

    elif action == "packet":
        console.print(
            f"[green]✓ Saved: {result.get('packet_path', '')}[/green]"
        )


def _run_inspect_on_node(
    node_id: str,
    project_path: str,
    action: str,
    output_format: str,
    response_tier: str,
) -> None:
    """Run inspect on a specific node_id via execute_inspect."""
    from forge.mcp.thin_core import execute_inspect

    console = Console()
    root = resolve_project_path(project_path)

    try:
        result = execute_inspect(
            {
                "project_path": str(root),
                "action": action,
                "node_id": node_id,
                "response_tier": response_tier,
            }
        )
    except Exception as e:
        console.print(f"[red]Inspect failed: {e}[/red]")
        raise SystemExit(1) from e

    if not result.get("ok"):
        console.print(f"[red]{result.get('error', 'Failed')}[/red]")
        if result.get("hint"):
            console.print(f"[dim]{result['hint']}[/dim]")
        raise SystemExit(1)

    if output_format == "json":
        console.print(json.dumps(result, indent=2, default=str))
        return

    if output_format == "yaml":
        import yaml

        console.print(yaml.safe_dump(result, sort_keys=False))
        return

    _display_inspect_result(console, result, action)


def _run_interactive_inspect(
    project_path: str,
    action: str,
    output_format: str,
    response_tier: str,
    *,
    yes_only: bool = False,
) -> None:
    """
    Interactive inspect when no args given.

    Flow:
      1. Load available domains from graph
      2. Show numbered domain list
      3. User picks domain (or 'all')
      4. Show nodes in that domain
      5. User picks node
      6. Run inspect on chosen node
    """
    from forge.tools.manifest.graph import build_manifest_graph

    root = resolve_project_path(project_path)

    try:
        graph = build_manifest_graph(root)
        nodes = graph.nodes
    except Exception as e:
        click.echo(f"Could not load graph: {e}", err=True)
        raise SystemExit(1) from e

    if not nodes:
        click.echo("No nodes found. Run forge discover first.", err=True)
        raise SystemExit(1)

    domains = sorted({n.domain for n in nodes if n.domain})

    if not domains:
        click.echo("No domains found.", err=True)
        raise SystemExit(1)

    click.echo("\n✦ eforge inspect\n")
    click.echo("  Select a domain:\n")

    for i, d in enumerate(domains, 1):
        count = sum(1 for n in nodes if n.domain == d)
        click.echo(f"    [{i}] {d}  ({count} nodes)")

    click.echo(f"    [a] all domains  ({len(nodes)} nodes)")
    click.echo("")

    if yes_only:
        sorted_nodes = sorted(
            nodes,
            key=lambda n: (n.kind or "", n.id or ""),
        )
        click.echo("  Nodes (all domains):\n")
        for i, n in enumerate(sorted_nodes[:50], 1):
            kind = f"[{n.kind}]" if n.kind else ""
            click.echo(f"    [{i:2}] {n.id}  {kind}")
        if len(sorted_nodes) > 50:
            click.echo(f"\n    ... and {len(sorted_nodes) - 50} more.")
        return

    choice = click.prompt("  Enter number or 'a'", default="1").strip().lower()

    if choice == "a":
        selected_domain = None
        domain_nodes = nodes
    else:
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(domains):
                selected_domain = domains[idx]
                domain_nodes = [n for n in nodes if n.domain == selected_domain]
            else:
                click.echo("Invalid choice.", err=True)
                raise SystemExit(1)
        except ValueError:
            click.echo("Invalid choice.", err=True)
            raise SystemExit(1)

    click.echo(
        f"\n  Nodes"
        f"{f' in {selected_domain}' if selected_domain else ''}:\n"
    )

    sorted_nodes = sorted(
        domain_nodes,
        key=lambda n: (n.kind or "", n.id or ""),
    )

    max_shown = 20
    shown = sorted_nodes[:max_shown]

    for i, n in enumerate(shown, 1):
        kind = f"[{n.kind}]" if n.kind else ""
        click.echo(f"    [{i:2}] {n.id}  {kind}")

    if len(sorted_nodes) > max_shown:
        click.echo(
            f"\n    ... and {len(sorted_nodes) - max_shown} more. "
            f"Use --domain {selected_domain or ''} --kind <kind> to filter."
        )

    click.echo("")
    choice2 = click.prompt("  Enter number to inspect", default="1").strip()

    try:
        idx2 = int(choice2) - 1
        if 0 <= idx2 < len(shown):
            chosen_node = shown[idx2]
        else:
            click.echo("Invalid choice.", err=True)
            raise SystemExit(1)
    except ValueError:
        click.echo("Invalid choice.", err=True)
        raise SystemExit(1)

    click.echo(f"\n  Inspecting: {chosen_node.id}\n")

    _run_inspect_on_node(
        chosen_node.id,
        project_path,
        action,
        output_format,
        response_tier,
    )


@click.command("inspect")
@click.argument("node_id", required=False)
@click.option(
    "--project-path",
    "project_path",
    default=".",
    show_default=True,
    help="Project root directory",
)
@click.option(
    "--action",
    type=click.Choice(["node", "expand", "diff", "packet", "search"]),
    default="node",
    show_default=True,
    help="Inspection action",
)
@click.option(
    "--ring",
    type=int,
    default=None,
    help="Ring to expand (1, 2, or 3). Use with --action expand",
)
@click.option(
    "--handle",
    default=None,
    help="Cursor handle for follow-up actions",
)
@click.option(
    "--domain",
    default=None,
    help="Filter by domain (shows all nodes in domain when no node_id given)",
)
@click.option(
    "--kind",
    default=None,
    help="Filter by node kind",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["rich", "json", "yaml"]),
    default="rich",
    show_default=True,
    help="Output format",
)
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    default=False,
    help="Skip interactive prompts; list domains and nodes only",
)
@response_tier_option(default="L1")
def inspect_cmd(
    node_id: str | None,
    project_path: str,
    action: str,
    ring: int | None,
    handle: str | None,
    domain: str | None,
    kind: str | None,
    output_format: str,
    yes: bool,
    response_tier: str,
) -> None:
    """Inspect a node or navigate the graph.

    NODE_ID can be a full canonical ID (module/engine.engine) or a bare name
    (engine.engine) — auto-resolved.

    With no NODE_ID and no filters, opens an interactive domain + node picker.

    Examples:
      forge inspect module/engine.engine
      forge inspect engine.engine
      forge inspect engine.engine --ring 1
      forge inspect --domain ENGINE
      forge inspect --kind component
      forge inspect -y
    """
    console = Console()
    root = Path(project_path).expanduser().resolve()

    if not node_id and not domain and not kind and not handle:
        _run_interactive_inspect(
            str(root),
            action,
            output_format,
            response_tier,
            yes_only=yes,
        )
        return

    arguments: dict[str, Any] = {
        "project_path": str(root),
        "action": action,
        "response_tier": response_tier,
    }
    if node_id:
        arguments["node_id"] = node_id
    if handle:
        arguments["handle"] = handle
    if ring is not None:
        arguments["ring"] = ring

    if not node_id and (domain or kind):
        arguments["action"] = "search"
        from forge.mcp.thin_core import execute_search

        search_args: dict[str, Any] = {
            "project_path": str(root),
            "response_tier": response_tier,
        }
        if domain:
            search_args["domain"] = domain
            search_args["query"] = domain.lower()
        if kind:
            search_args["kind"] = kind
            search_args["query"] = search_args.get("query", "") or kind
        search_args["limit"] = 50

        try:
            result = execute_search(search_args)
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
            raise SystemExit(1) from e

        if output_format == "json":
            console.print(json.dumps(result, indent=2))
            return

        nodes = result.get("nodes", [])
        if not nodes:
            console.print("[yellow]No nodes found[/yellow]")
            return

        table = Table(
            title=(
                f"Nodes"
                f"{f' in {domain}' if domain else ''}"
                f"{f' of kind {kind}' if kind else ''}"
            ),
            show_header=True,
        )
        table.add_column("ID", style="cyan")
        table.add_column("Kind", style="green")
        table.add_column("Domain", style="yellow")
        table.add_column("Status", style="dim")
        for n in nodes:
            table.add_row(
                str(n.get("id", "")),
                str(n.get("kind", "")),
                str(n.get("domain", "")),
                str(n.get("status", "")),
            )
        console.print(table)
        return

    if not node_id and not handle:
        console.print(
            "[red]Error: NODE_ID required (or use --domain / --kind)[/red]"
        )
        raise SystemExit(1)

    if action == "expand" and not handle and node_id:
        from forge.mcp.thin_core import execute_inspect

        bootstrap = execute_inspect(
            {
                "project_path": str(root),
                "action": "node",
                "node_id": node_id,
                "response_tier": response_tier,
            }
        )
        if not bootstrap.get("ok"):
            console.print(
                f"[red]{bootstrap.get('error', 'Failed to resolve node')}[/red]"
            )
            raise SystemExit(1)
        handle = bootstrap.get("handle")
        arguments["handle"] = handle
        arguments.pop("node_id", None)

    try:
        from forge.mcp.thin_core import execute_inspect

        result = execute_inspect(arguments)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise SystemExit(1) from e

    if not result.get("ok"):
        console.print(f"[red]{result.get('error', 'Failed')}[/red]")
        if result.get("hint"):
            console.print(f"[dim]{result['hint']}[/dim]")
        raise SystemExit(1)

    if output_format == "json":
        console.print(json.dumps(result, indent=2))
        return

    if output_format == "yaml":
        import yaml

        console.print(yaml.safe_dump(result, sort_keys=False))
        return

    _display_inspect_result(console, result, action)
