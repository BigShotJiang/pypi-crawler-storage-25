"""
forge.commands._shared_options
Shared Click option decorators for command contract compliance.
Import these instead of declaring options inline per command.
"""

import click


def response_tier_option(default: str = "L1"):
    """response_tier option — required by pipeline and inspection group contracts."""
    return click.option(
        "--response-tier",
        type=click.Choice(["L0", "L1", "L2"]),
        default=default,
        show_default=True,
        help="Output projection tier (L0=minimal, L1=standard, L2=full).",
    )


def project_path_option(required: bool = True):
    """project_path option — base contract, all commands."""
    return click.option(
        "--project-path",
        required=required,
        help="Project root. Resolved via expanduser.",
    )


def dry_run_option():
    """dry_run option — required by scaffold group contract."""
    return click.option(
        "--dry-run",
        is_flag=True,
        default=False,
        help="Preview changes without writing to disk.",
    )
