"""Forge migrate command for INTENT-E2295590 Schema versioning + migration."""

import click
from pathlib import Path
from typing import Any, Dict

from forge.core.manifest import ManifestParser
from forge.core.migration import MigrationManager, detect_schema_version, needs_migration
from forge.core.result import ForgeResult
from forge.core.error_handler import handle_cli_result
from ruamel.yaml import YAML


@click.group()
def migrate() -> None:
    """Schema migration commands for manifest.yaml files."""
    pass


@migrate.command()
@click.option("--project-path", type=click.Path(exists=True), help="Path to project directory")
@click.option("--dry-run", is_flag=True, help="Show what would be migrated without making changes")
def manifest(project_path: str | None, dry_run: bool) -> int:
    """Migrate manifest.yaml to the latest schema version."""
    if project_path:
        project_root = Path(project_path)
    else:
        # Try to find project root
        current = Path.cwd()
        while current != current.parent:
            manifest_path = current / ".forge" / "manifest.yaml"
            if manifest_path.exists():
                project_root = current
                break
            current = current.parent
        else:
            project_root = Path.cwd()
    
    manifest_path = project_root / ".forge" / "manifest.yaml"
    
    if not manifest_path.exists():
        # Try root manifest.yaml as fallback
        manifest_path = project_root / "manifest.yaml"
        if not manifest_path.exists():
            result = ForgeResult.failure("No manifest.yaml found in project")
            return handle_cli_result(result)
    
    # Load current manifest
    parser = ManifestParser(manifest_path)
    parse_result = parser.parse(allow_migration=False)  # Don't auto-migrate for dry run
    
    if not parse_result.ok:
        result = ForgeResult.failure(f"Failed to parse manifest: {parse_result.error}")
        return handle_cli_result(result)
    
    current_data = parse_result.value
    current_version = detect_schema_version(current_data)
    
    # Check if migration is needed
    migration_manager = MigrationManager()
    required_migrations = migration_manager.get_required_migrations(current_version)
    
    if not required_migrations:
        click.echo(f"Manifest is already at latest version ({current_version})")
        return 0
    
    click.echo(f"Current schema version: {current_version}")
    click.echo(f"Latest version: {migration_manager.get_latest_version()}")
    click.echo(f"Required migrations: {len(required_migrations)}")
    
    for migration in required_migrations:
        click.echo(f"  - {migration.description}")
    
    if dry_run:
        click.echo("\nDry run - no changes will be made.")
        return 0
    
    # Perform migration
    migration_result = migration_manager.migrate_manifest(current_data)
    
    if not migration_result.ok:
        result = ForgeResult.failure(f"Migration failed: {migration_result.error}")
        return handle_cli_result(result)
    
    migrated_data = migration_result.value
    
    # Write migrated manifest
    yaml = YAML()
    yaml.indent(mapping=2, sequence=4, offset=2)
    yaml.width = 4096
    
    try:
        with open(manifest_path, 'w') as f:
            yaml.dump(migrated_data, f)
        click.echo(f"✅ Successfully migrated manifest to version {migration_manager.get_latest_version()}")
        return 0
    except Exception as e:
        result = ForgeResult.failure(f"Failed to write migrated manifest: {e}")
        return handle_cli_result(result)


@migrate.command()
@click.option("--project-path", type=click.Path(exists=True), help="Path to project directory")
def status(project_path: str | None) -> int:
    """Check schema version status of manifest.yaml."""
    if project_path:
        project_root = Path(project_path)
    else:
        # Try to find project root
        current = Path.cwd()
        while current != current.parent:
            manifest_path = current / ".forge" / "manifest.yaml"
            if manifest_path.exists():
                project_root = current
                break
            current = current.parent
        else:
            project_root = Path.cwd()
    
    manifest_path = project_root / ".forge" / "manifest.yaml"
    
    if not manifest_path.exists():
        # Try root manifest.yaml as fallback
        manifest_path = project_root / "manifest.yaml"
        if not manifest_path.exists():
            result = ForgeResult.failure("No manifest.yaml found in project")
            return handle_cli_result(result)
    
    # Load current manifest
    parser = ManifestParser(manifest_path)
    parse_result = parser.parse(allow_migration=False)
    
    if not parse_result.ok:
        result = ForgeResult.failure(f"Failed to parse manifest: {parse_result.error}")
        return handle_cli_result(result)
    
    current_data = parse_result.value
    current_version = detect_schema_version(current_data)
    
    migration_manager = MigrationManager()
    latest_version = migration_manager.get_latest_version()
    required_migrations = migration_manager.get_required_migrations(current_version)
    
    click.echo(f"Project: {project_root.name}")
    click.echo(f"Manifest: {manifest_path.relative_to(project_root)}")
    click.echo(f"Current schema version: {current_version}")
    click.echo(f"Latest version: {latest_version}")
    
    if current_version == latest_version:
        click.echo("✅ Schema version is up to date")
        return 0
    else:
        click.echo(f"⚠️  Migration required: {len(required_migrations)} migration(s) needed")
        for migration in required_migrations:
            click.echo(f"  - {migration.description}")
        return 1


@migrate.command()
def version() -> int:
    """Show current migration system information."""
    migration_manager = MigrationManager()
    
    click.echo("Forge Migration System")
    click.echo(f"Latest supported schema version: {migration_manager.get_latest_version()}")
    click.echo(f"Available migrations: {len(migration_manager.migrations)}")
    
    for migration in migration_manager.migrations:
        click.echo(f"  - {migration.from_version} → {migration.to_version}: {migration.description}")
    
    return 0
