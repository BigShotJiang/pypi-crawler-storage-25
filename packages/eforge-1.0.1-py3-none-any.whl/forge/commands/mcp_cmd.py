from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

import click

from forge.core.path_utils import resolve_project_path
from forge.mcp.handlers.registry import TOOL_MAPPING as TOOL_HANDLERS
from forge.mcp.server import run_mcp_stdio
from forge.mcp.registry import all_tool_schemas


def _schema_by_tool_name() -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for tool in all_tool_schemas():
        out[tool.name] = dict(tool.inputSchema or {})
    return out


def _prompt_value(name: str, spec: dict[str, Any], required: bool) -> Any:
    typ = str(spec.get("type", "string"))
    enum_vals = spec.get("enum")
    desc = str(spec.get("description", ""))
    default = spec.get("default")
    if desc and desc != "Short label.":
        click.echo(f"  {name}: {desc}")

    if enum_vals and isinstance(enum_vals, list) and enum_vals:
        click.echo(f"  options: {', '.join(str(x) for x in enum_vals)}")
        raw = click.prompt(f"{name}", default=str(default) if default is not None else None, show_default=default is not None)
        if raw == "" and not required:
            return None
        return raw

    if typ == "boolean":
        if not required and click.confirm(f"set optional {name}?", default=False) is False:
            return None
        return click.confirm(name, default=bool(default) if default is not None else False)

    if typ == "integer":
        if not required and click.confirm(f"set optional {name}?", default=False) is False:
            return None
        return click.prompt(name, type=int, default=int(default) if default is not None else None, show_default=default is not None)

    if typ == "array":
        if not required and click.confirm(f"set optional {name}?", default=False) is False:
            return None
        raw = click.prompt(
            f"{name} (JSON array or comma list)",
            default=json.dumps(default) if default is not None else "",
            show_default=default is not None,
        ).strip()
        if not raw:
            return []
        if raw.startswith("["):
            parsed = json.loads(raw)
            if not isinstance(parsed, list):
                raise click.ClickException(f"{name}: expected JSON array")
            return parsed
        return [x.strip() for x in raw.split(",") if x.strip()]

    if typ == "object":
        if not required and click.confirm(f"set optional {name}?", default=False) is False:
            return None
        raw = click.prompt(f"{name} (JSON object)", default=json.dumps(default) if default is not None else "", show_default=default is not None).strip()
        if not raw:
            return {}
        parsed = json.loads(raw)
        if not isinstance(parsed, dict):
            raise click.ClickException(f"{name}: expected JSON object")
        return parsed

    # default string-ish
    if not required and click.confirm(f"set optional {name}?", default=False) is False:
        return None
    return click.prompt(name, default=str(default) if default is not None else None, show_default=default is not None)


def _guided_args(schema: dict[str, Any], default_project_path: str) -> dict[str, Any]:
    props = schema.get("properties") or {}
    req = set(schema.get("required") or [])
    if not isinstance(props, dict):
        props = {}
    out: dict[str, Any] = {}
    if "project_path" in props and "project_path" in req:
        out["project_path"] = click.prompt("project_path", default=default_project_path, show_default=True)
    for name, spec_any in props.items():
        if name == "project_path" and name in out:
            continue
        spec = spec_any if isinstance(spec_any, dict) else {}
        val = _prompt_value(name, spec, name in req)
        if val is not None:
            out[name] = val
    return out


@click.command("mcp")
@click.option("--project-path", default=".", show_default=True, help="Default project path for guided args.")
@click.option("--verbose", is_flag=True, default=False, help="Print full traceback for tool call errors.")
@click.option("--harness", "--test", "harness", is_flag=True, default=False,
              help="Start interactive test harness instead of MCP server.")
@click.option("--transport", type=click.Choice(["stdio", "ws", "http"]), default="stdio", show_default=True,
              help="Transport protocol: stdio (default), ws (WebSocket), or http (HTTP).")
@click.option("--host", default="localhost", show_default=True, help="Server host (ws/http transport only).")
@click.option("--port", type=int, default=7777, show_default=True, help="Server port (ws/http transport only).")
@click.option("--request-timeout", type=float, default=120.0, show_default=True,
              help="Request timeout in seconds (30-300, default: 120).")
@click.option("--ping-interval", type=float, default=20.0, show_default=True,
              help="WebSocket ping interval in seconds (default: 20).")
@click.option("--ping-timeout", type=float, default=10.0, show_default=True,
              help="WebSocket ping timeout in seconds (default: 10).")
@click.option("--max-reconnect-attempts", type=int, default=5, show_default=True,
              help="Maximum reconnection attempts (default: 5).")
def mcp_cmd(project_path: str, verbose: bool, harness: bool, transport: str, host: str, port: int, 
            request_timeout: float, ping_interval: float, ping_timeout: float, max_reconnect_attempts: int) -> None:
    """
    Start the Forge MCP server over stdio, WebSocket, or HTTP.

    Use --harness / --test to start the interactive tool harness instead
    (useful for manual testing without Cursor/Claude transport).
    
    Use --transport ws to start WebSocket server for full-duplex communication.
    Use --transport http to start HTTP server for REST API access.
    """
    # Validate and set timeout environment variables
    import os
    
    # Ensure reasonable bounds for timeouts
    request_timeout = max(30.0, min(300.0, request_timeout))
    ping_interval = max(5.0, min(60.0, ping_interval))
    ping_timeout = max(5.0, min(30.0, ping_timeout))
    max_reconnect_attempts = max(1, min(20, max_reconnect_attempts))
    
    # Set environment variables for WebSocket client configuration
    os.environ["FORGE_MCP_REQUEST_TIMEOUT"] = str(request_timeout)
    os.environ["FORGE_MCP_PING_INTERVAL"] = str(ping_interval)
    os.environ["FORGE_MCP_PING_TIMEOUT"] = str(ping_timeout)
    os.environ["FORGE_MCP_CLOSE_TIMEOUT"] = str(ping_timeout)  # Use ping_timeout for close_timeout
    os.environ["FORGE_MCP_MAX_RECONNECT_ATTEMPTS"] = str(max_reconnect_attempts)
    
    if verbose:
        click.echo(f"MCP Configuration:")
        click.echo(f"  Request timeout: {request_timeout}s")
        click.echo(f"  Ping interval: {ping_interval}s")
        click.echo(f"  Ping timeout: {ping_timeout}s")
        click.echo(f"  Max reconnect attempts: {max_reconnect_attempts}")
    
    if not harness:
        if transport == "ws":
            from forge.mcp.websocket_transport import run_mcp_websocket_sync
            run_mcp_websocket_sync(host, port)
        elif transport == "http":
            from forge.mcp.http_transport import run_mcp_http_sync
            # Use different default port for HTTP to avoid conflicts
            http_port = port if port != 7777 else 8080
            run_mcp_http_sync(host, http_port)
        else:
            run_mcp_stdio()
        return

    # ── Interactive harness ───────────────────────────────────────────────────
    default_project_path = str(resolve_project_path(project_path))
    schemas = _schema_by_tool_name()

    # Show resolved project at startup
    try:
        from pathlib import Path
        manifest_path = Path(default_project_path) / ".forge" / "manifest.yaml"
        if manifest_path.exists():
            import yaml
            with open(manifest_path, 'r', encoding='utf-8') as f:
                manifest = yaml.safe_load(f) or {}
            project_name = manifest.get("name", "unnamed")
        else:
            project_name = "unnamed"
    except Exception:
        project_name = "unnamed"
    
    click.echo(f"Project: {project_name} at {default_project_path}")
    click.echo("forge mcp interactive harness")

    # Group tools by prefix
    def _group_tools(tool_names: list[str]) -> dict[str, list[str]]:
        groups = {
            "[VERIFY]": [],
            "[AUDIT]": [],
            "[MANIFEST]": [],
            "[ANNOTATE]": [],
            "[ORIENT]": [],
            "[QUERY]": [],
            "[SESSION]": [],
            "[SCAFFOLD]": [],
            "[CONFIG]": [],
            "[OTHER]": [],
            "[DEPRECATED]": []
        }
        
        for name in tool_names:
            if name.startswith("forge_verify"):
                groups["[VERIFY]"].append(name)
            elif name.startswith("forge_audit") or name.startswith("audit_"):
                groups["[AUDIT]"].append(name)
            elif name.startswith("forge_manifest"):
                groups["[MANIFEST]"].append(name)
            elif name.startswith("forge_annotate") or name.startswith("audit_finding") or name.startswith("audit_memory") or name.startswith("audit_handoff"):
                groups["[ANNOTATE]"].append(name)
            elif name == "forge_orient":
                groups["[ORIENT]"].append(name)
            elif name.startswith("forge_query") or name.startswith("forge_impact_check") or name.startswith("forge_blast_radius"):
                groups["[QUERY]"].append(name)
            elif name.startswith("forge_session") or name.startswith("forge_intent"):
                groups["[SESSION]"].append(name)
            elif name.startswith("forge_scaffold") or name.startswith("forge_template"):
                groups["[SCAFFOLD]"].append(name)
            elif name.startswith("forge_config"):
                groups["[CONFIG]"].append(name)
            elif name.startswith("forge_") and not any(name.startswith(prefix) for prefix in ["forge_verify", "forge_audit", "forge_manifest", "forge_annotate", "forge_orient", "forge_query", "forge_session", "forge_scaffold", "forge_config"]):
                groups["[OTHER]"].append(name)
            elif name.startswith("audit_"):
                groups["[DEPRECATED]"].append(name)
            else:
                groups["[OTHER]"].append(name)
        
        return groups

    while True:
        tool_names = sorted(TOOL_HANDLERS.keys())
        groups = _group_tools(tool_names)
        
        click.echo("\nAvailable tools:")
        tool_index = {}
        idx = 1
        
        for group_name, tools in groups.items():
            if group_name == "[DEPRECATED]":
                continue  # Hide deprecated by default
            if not tools:
                continue
            click.echo(f"\n{group_name}:")
            for tool in sorted(tools):
                click.echo(f"  {idx:2d}) {tool}")
                tool_index[str(idx)] = tool
                idx += 1
        
        click.echo("\n  d) Show deprecated tools")
        click.echo(" q) quit")
        sel = click.prompt("select tool", default="q", show_default=False).strip().lower()
        if sel in {"q", "quit", "exit"}:
            return
        if sel == "d":
            # Show deprecated tools
            click.echo("\nDeprecated tools:")
            deprecated_tools = groups["[DEPRECATED]"]
            if deprecated_tools:
                for idx, tool in enumerate(sorted(deprecated_tools), start=1):
                    click.echo(f"  {idx:2d}) {tool}")
                dep_sel = click.prompt("select deprecated tool", default="q", show_default=False).strip().lower()
                if dep_sel in {"q", "quit", "exit"}:
                    continue
                if dep_sel.isdigit():
                    i = int(dep_sel) - 1
                    if 0 <= i < len(deprecated_tools):
                        tool_name = sorted(deprecated_tools)[i]
                    else:
                        click.echo("invalid selection")
                        continue
                else:
                    tool_name = dep_sel
            else:
                click.echo("No deprecated tools available")
                continue
        elif sel.isdigit():
            if sel in tool_index:
                tool_name = tool_index[sel]
            else:
                click.echo("invalid selection")
                continue
        else:
            if sel not in TOOL_HANDLERS:
                click.echo("unknown tool")
                continue
            tool_name = sel

        mode = click.prompt("args mode [guided|json]", default="guided").strip().lower()
        try:
            if mode == "json":
                click.echo("enter JSON object args (single line). blank => default project_path only")
                raw = click.prompt("args", default="", show_default=False).strip()
                args = {"project_path": default_project_path} if not raw else json.loads(raw)
                if not isinstance(args, dict):
                    raise click.ClickException("args must be a JSON object")
            else:
                args = _guided_args(schemas.get(tool_name, {}), default_project_path)
        except Exception as exc:
            click.echo(f"args error: {exc}")
            continue

        # Filter args to show only non-null, non-default values
        filtered_args = {}
        for key, value in args.items():
            if value is not None and value != "":
                # For boolean values, only show if True (False is often default)
                if isinstance(value, bool):
                    if value:
                        filtered_args[key] = value
                else:
                    filtered_args[key] = value

        click.echo("\n=== Tool Invocation Summary ===")
        click.echo(f"Tool:    {tool_name}")
        click.echo(f"Project: {args.get('project_path', default_project_path)}")
        click.echo("Args:")
        if filtered_args:
            click.echo(json.dumps(filtered_args, indent=2))
        else:
            click.echo("  (using defaults)")
        
        if not click.confirm("invoke tool?", default=True):
            continue

        handler = TOOL_HANDLERS[tool_name]
        try:
            result = asyncio.run(handler(args))
        except Exception as exc:
            click.echo(f"handler exception: {exc}")
            if verbose:
                import traceback

                click.echo(traceback.format_exc())
            continue

        is_error = bool(getattr(result, "isError", False))
        text = ""
        try:
            text = result.content[0].text if result.content else ""
        except Exception:
            text = str(result)

        click.echo("\n=== result ===")
        click.echo(f"isError: {is_error}")
        click.echo(text)
        try:
            parsed = json.loads(text)
            click.echo("\n=== parsed json ===")
            click.echo(json.dumps(parsed, indent=2))
        except Exception:
            pass
