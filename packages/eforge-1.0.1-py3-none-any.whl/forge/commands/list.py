import click
import json
from click.core import ParameterSource
from rich.console import Console
from rich.table import Table

from forge.commands._shared_options import response_tier_option
from forge.core.discovery import discover_projects, get_projects_root


@click.command()
@click.option("--type", "filter_type", default=None, help="Filter by project type (flutter, web, python)")
@response_tier_option(default="L0")
@click.pass_context
def list_cmd(ctx: click.Context, filter_type: str | None, response_tier: str) -> None:
    """List all discovered projects."""
    projects = discover_projects(get_projects_root())
    if filter_type:
        projects = [p for p in projects if p.type == filter_type]
    response_source = ctx.get_parameter_source("response_tier")
    tier_explicit = response_source == ParameterSource.COMMANDLINE
    if tier_explicit:
        tier = str(response_tier or "L0").upper()
        if tier == "L0":
            payload = [p.name for p in projects]
        elif tier == "L1":
            payload = [
                {
                    "name": p.name,
                    "stack": p.type,
                    "phase": p.current_phase(),
                    "path": str(p.path),
                }
                for p in projects
            ]
        else:
            payload = [
                {
                    "name": p.name,
                    "type": p.type,
                    "version": p.version,
                    "path": str(p.path),
                    "repo": p.repo,
                    "branch": p.branch,
                    "description": p.description,
                    "phases": p.phases,
                    "warnings": p.warnings,
                    "domain": p.domain,
                    "app_config_meta": p.app_config_meta,
                    "dependencies": p.dependencies,
                }
                for p in projects
            ]
        click.echo(json.dumps(payload, indent=2))
        return
    table = Table(title="Projects")
    table.add_column("Name", style="bold")
    table.add_column("Type")
    table.add_column("Version")
    table.add_column("Phase")
    table.add_column("Path")
    for p in projects:
        phase = p.current_phase()
        phase_str = str(phase) if phase is not None else "—"
        table.add_row(p.name, p.type, p.version, phase_str, str(p.path))
    console = Console()
    console.print(table)
