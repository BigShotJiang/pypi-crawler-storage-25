from __future__ import annotations

import base64
import json
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import quote

import click

ALLOWED_PREFIXES = [
    "src/content/posts/",
    "src/content/projects/",
    "src/content/notes/",
    "src/pages/about.astro",
]


def load_github_token(project_path: Path) -> str:
    """
    Loads GITHUB_TOKEN from ~/Projects/.secrets/{project_name}/.env.
    Raises ValueError if not found.
    """
    project_name = project_path.name
    secrets_path = Path.home() / "Projects" / ".secrets" / project_name / ".env"
    if not secrets_path.exists():
        raise ValueError(
            f"Secrets file not found: {secrets_path}\n"
            f"Create it with: GITHUB_TOKEN=github_pat_..."
        )
    for line in secrets_path.read_text().splitlines():
        line = line.strip()
        if line.startswith("GITHUB_TOKEN="):
            token = line.split("=", 1)[1].strip().strip('"').strip("'")
            if token:
                return token
    raise ValueError(f"GITHUB_TOKEN not found in {secrets_path}")


def _contents_url(repo_owner: str, repo_name: str, file_path: str) -> str:
    encoded = quote(file_path, safe="")
    return f"https://api.github.com/repos/{repo_owner}/{repo_name}/contents/{encoded}"


def github_api_request(method: str, url: str, token: str, body: dict | None = None) -> dict:
    """Make a GitHub API request. Returns parsed JSON (empty dict on 204)."""
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "Content-Type": "application/json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "forge-mcp/1.0",
        },
    )
    try:
        with urllib.request.urlopen(req) as resp:
            raw = resp.read().decode()
            if not raw.strip():
                return {}
            return json.loads(raw)
    except urllib.error.HTTPError as e:
        body_t = e.read().decode(errors="replace")
        raise RuntimeError(f"GitHub API error {e.code}: {body_t}") from e


def run_github_write(
    project_path: str,
    repo_owner: str,
    repo_name: str,
    file_path: str,
    content: str,
    commit_message: str,
    response_tier: str = "L1",
) -> dict:
    root = Path(project_path).expanduser().resolve()

    if ".." in file_path or "//" in file_path:
        return {"error": "Invalid file path: path traversal not allowed (.. or //)"}

    allowed = any(file_path == p or file_path.startswith(p) for p in ALLOWED_PREFIXES)
    if not allowed:
        return {
            "error": f"Path not allowed: {file_path}",
            "allowed_prefixes": ALLOWED_PREFIXES,
        }

    try:
        token = load_github_token(root)
    except ValueError as e:
        return {"error": str(e)}

    base_url = _contents_url(repo_owner, repo_name, file_path)

    sha: str | None = None
    try:
        existing = github_api_request("GET", base_url + "?ref=main", token)
        sha = existing.get("sha") if isinstance(existing, dict) else None
    except RuntimeError as e:
        if "GitHub API error 404" not in str(e):
            return {"error": f"Failed to check existing file: {e}"}

    encoded = base64.b64encode(content.encode("utf-8")).decode("ascii")

    put_body: dict = {
        "message": commit_message,
        "content": encoded,
        "branch": "main",
    }
    if sha:
        put_body["sha"] = sha

    try:
        result = github_api_request("PUT", base_url, token, put_body)
    except RuntimeError as e:
        return {"error": str(e)}

    commit_sha = (result.get("commit") or {}).get("sha", "unknown")
    tier = (response_tier or "L1").upper()

    if tier == "L0":
        return {"success": True, "commit_sha": str(commit_sha)[:8]}

    out: dict = {
        "success": True,
        "file_path": file_path,
        "commit_sha": commit_sha,
        "commit_message": commit_message,
        "repo": f"{repo_owner}/{repo_name}",
        "vercel_deploy": "triggered automatically via GitHub push",
    }
    if tier == "L2":
        out["sha_updated"] = sha is not None
    return out


@click.command("github-write")
@click.option("--project-path", required=True)
@click.option("--repo-owner", required=True)
@click.option("--repo-name", required=True)
@click.option("--file-path", required=True)
@click.option("--content", required=True)
@click.option("--commit-message", required=True)
@click.option(
    "--response-tier",
    default="L1",
    type=click.Choice(["L0", "L1", "L2"]),
)
def github_write_cmd(
    project_path: str,
    repo_owner: str,
    repo_name: str,
    file_path: str,
    content: str,
    commit_message: str,
    response_tier: str,
) -> None:
    """Write a file to a GitHub repo via the GitHub API."""
    result = run_github_write(
        project_path=project_path,
        repo_owner=repo_owner,
        repo_name=repo_name,
        file_path=file_path,
        content=content,
        commit_message=commit_message,
        response_tier=response_tier,
    )
    click.echo(json.dumps(result, indent=2))
