"""forge registry — add/list/update template registries."""

from __future__ import annotations

from pathlib import Path

import click

from forge.core.path_utils import resolve_project_path
from forge.core.registry import REGISTRY_PRIORITY, list_templates, registry_path


@click.group("registry")
def registry_cmd() -> None:
    """Manage forge template registries (local / community / custom)."""


@registry_cmd.command("list")
@click.option(
    "--stack",
    default=None,
    help="Filter templates by stack (flutter-app, web-next, …).",
)
@click.option(
    "--templates",
    "show_templates",
    is_flag=True,
    default=False,
    help="Show individual templates in each registry.",
)
def registry_list(stack: str | None, show_templates: bool) -> None:
    """Show registered sources and their contents."""
    click.echo("\nforge registries:")
    for src in REGISTRY_PRIORITY:
        path = registry_path(src)
        status = "present" if path.exists() else "empty"
        click.echo(f"  {src:12s}  {path}  ({status})")
    if show_templates:
        templates = list_templates(stack=stack)
        if templates:
            click.echo(f"\nTemplates{(' — stack: ' + stack) if stack else ''}:")
            for t in templates:
                desc = t.get("description") or ""
                desc_part = f"  {desc}" if desc else ""
                click.echo(
                    f"  [{t['_source']:10s}]  {t['_kind']:16s}  {t['_name']}{desc_part}"
                )
        else:
            click.echo("\n  (no templates found)")


@registry_cmd.command("add")
@click.argument("source")
@click.option(
    "--name",
    default="custom",
    show_default=True,
    help="Registry slot to populate (custom, community, or a new name).",
)
def registry_add(source: str, name: str) -> None:
    """Add a remote git registry or symlink a local path."""
    target = registry_path(name)
    if source.startswith("http") or source.endswith(".git"):
        import subprocess
        subprocess.run(["git", "clone", source, str(target)], check=True)
        click.echo(f"Registry cloned → {target}")
    else:
        src_path = resolve_project_path(source)
        if not src_path.exists():
            raise click.ClickException(f"Source path does not exist: {src_path}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.symlink_to(src_path)
        click.echo(f"Registry linked: {target} → {src_path}")


@registry_cmd.command("update")
@click.option(
    "--name",
    default="community",
    show_default=True,
    help="Registry to update (must be a git clone).",
)
def registry_update(name: str) -> None:
    """Pull latest for a git-backed registry."""
    path = registry_path(name)
    if not path.exists():
        raise click.ClickException(f"Registry '{name}' not found at {path}")
    if (path / ".git").exists():
        import subprocess
        subprocess.run(["git", "pull"], cwd=path, check=True)
        click.echo(f"Updated '{name}'")
    else:
        click.echo(f"'{name}' is not a git registry — update manually.")
