from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click
import yaml

from forge.core.response_schema import tier_fields
from forge.core.gloves import GLOVES
from forge.core.path_utils import resolve_project_path
from forge.tools.contract_checker import check_contracts
from forge.tools.diff_report import _resolve_stack_key
from forge.tools.manifest.graph import build_manifest_graph
from forge.tools.triangulation import report_records


def _collect_contracts(root: Path) -> dict[str, list[Any]]:
    stack = _resolve_stack_key(root)
    glove = GLOVES.get(stack)
    if glove is None:
        return {}
    contracts: dict[str, list[Any]] = {}
    for node in glove.extract_nodes(root):
        rows = glove.extract_contracts(node)
        if rows:
            contracts[node.id] = rows
    return contracts


def _render_text(violations: list[Any]) -> str:
    if not violations:
        return "No contract violations."
    lines: list[str] = []
    for v in violations:
        lines.append(
            f"{v.file}:{v.line}:{v.symbol}:{v.expected}:{v.actual}"
        )
    return "\n".join(lines)


def _violation_rows(violations: list[Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for idx, v in enumerate(violations, start=1):
        rows.append(
            {
                "violation_id": f"V-{idx:04d}",
                "file": v.file,
                "line": v.line,
                "symbol": v.symbol,
                "expected": v.expected,
                "actual": v.actual,
                "severity": v.severity,
                "violation_kind": v.violation_kind,
            }
        )
    return rows


@click.command("report")
@click.option("--project-path", default=".", type=click.Path(file_okay=False), show_default=True)
@click.option("--scope", type=click.Choice(["repo", "domain", "file", "function"], case_sensitive=False), default="repo")
@click.option("--target", default=None)
@click.option("--layer", type=click.Choice(["declaration", "execution", "all"], case_sensitive=False), default="declaration")
@click.option("--format", "out_format", type=click.Choice(["text", "json", "yaml"], case_sensitive=False), default="text")
@click.option("--response-tier", type=click.Choice(["L0", "L1", "L2"], case_sensitive=False), default="L1", show_default=True)
@click.option("--finding-id", default=None, help="Return a specific finding id (required for L2 in agent flows).")
@click.option("--exit-code", "exit_code_mode", is_flag=True, default=False, help="CI gate mode: exit 1 when issues exist.")
def report_cmd(project_path: str, scope: str, target: str | None, layer: str, out_format: str, response_tier: str, finding_id: str | None, exit_code_mode: bool) -> None:
    _ = (scope, target, layer)
    root = resolve_project_path(project_path)
    try:
        contracts = _collect_contracts(root)
    except PermissionError as exc:
        raise click.ClickException(f"permission denied while reading project files for report: {exc}") from exc
    violations: list[Any] = []
    graph = None
    try:
        graph = build_manifest_graph(root)
    except (FileNotFoundError, ValueError, OSError):
        graph = None
    if contracts and graph is not None:
        violations = check_contracts(graph, contracts, None)
    # Phase 7 unified report is triangulation-first and agent-consumable.
    try:
        rows = report_records(root, finding_id=finding_id, graph=graph)
    except PermissionError as exc:
        raise click.ClickException(f"permission denied while building report: {exc}") from exc
    tier = str(response_tier or "L1").upper()
    if tier == "L2" and not finding_id:
        raise click.ClickException("L2 requires --finding-id.")
    if tier == "L0":
        by_issue: dict[str, int] = {}
        for r in rows:
            k = str(r.get("issue_type") or "unknown")
            by_issue[k] = by_issue.get(k, 0) + 1
        payload: dict[str, Any] = {"count_by_issue_type": by_issue}
    else:
        fields = tier_fields(root, "unified_report", tier)
        payload = {"findings": [{k: r.get(k) for k in fields} for r in rows]} if fields else {"findings": rows}
        payload["contract_violations"] = _violation_rows(violations)
    if exit_code_mode:
        has_issues = bool(violations)
        if isinstance(payload, dict):
            has_issues = has_issues or any(isinstance(v, list) and len(v) > 0 for v in payload.values())
            if not has_issues and "count_by_issue_type" in payload:
                has_issues = any(int(v) > 0 for v in (payload.get("count_by_issue_type") or {}).values())
        raise SystemExit(1 if has_issues else 0)
    if out_format == "json":
        click.echo(json.dumps(payload, indent=2))
        return
    if out_format == "yaml":
        click.echo(yaml.safe_dump(payload, sort_keys=False))
        return
    if tier == "L1":
        parts: list[str] = []
        parts.append("=== Contract violations ===")
        if violations:
            parts.append(_render_text(violations))
        else:
            parts.append("no contract violations found")
        if rows:
            parts.append("")
            parts.append("=== Triangulation ===")
            parts.extend(f"{r['location']}:{r['issue_type']}:{r['layer']}" for r in payload.get("findings", []))
        click.echo("\n".join(parts))
        return
    click.echo(yaml.safe_dump(payload, sort_keys=False))
