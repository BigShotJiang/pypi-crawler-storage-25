from __future__ import annotations

import importlib
import inspect
import sys
from pathlib import Path
from typing import Any, Callable

import click

from forge.core.path_utils import resolve_project_path
from forge.core.gloves import PythonGlove
from forge.commands.map_cmd import _get_stack
from forge.tools.manifest.graph import build_manifest_graph
from forge.tools.trace_store import SafeTraceRunner, write_trace


def _entry_scope_module(mod_name: str, scope: str) -> str | None:
    if scope.strip().lower() == "full":
        return None
    if "." not in mod_name:
        return mod_name
    return mod_name.rpartition(".")[0]


def resolve_entry_callable(entry: str) -> tuple[Callable[..., Any], str, str]:
    s = entry.strip()
    if ":" in s:
        mod_name, qual = s.split(":", 1)
        mod_name, qual = mod_name.strip(), qual.strip()
    else:
        if "." not in s:
            raise click.BadParameter("entry must be module:callable or module.callable")
        mod_name, qual = s.rsplit(".", 1)
        mod_name, qual = mod_name.strip(), qual.strip()
    if not mod_name or not qual:
        raise click.BadParameter("entry must be module:callable or module.callable")
    mod = importlib.import_module(mod_name)
    target = getattr(mod, qual)
    if not callable(target):
        raise click.BadParameter(f"{entry!r} is not callable")
    entry_id = f"{mod_name}.{qual}"
    return target, mod_name, entry_id


def run_python_trace(
    project_root: Path,
    entry: str,
    *,
    scope: str,
    out_path: Path | None,
    fmt: str,
    timeout: int | None = None,
    no_subprocess: bool = False,
    dry_call: bool = False,
    mock_network: bool = False,
    mock_fs_writes: bool = False,
    auto_pythonpath: bool = False,
) -> dict[str, Any]:
    fn, mod_name, entry_id = resolve_entry_callable(entry)
    sig = inspect.signature(fn)
    required_positional = [
        p
        for p in sig.parameters.values()
        if p.default is inspect._empty
        and p.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
    ]
    if required_positional:
        # forge_trace executes a zero-argument callable under sys.settrace.
        # For entry points that require context arguments, auto-wrap when we can
        # deterministically build those args from the project root.
        if entry_id == "forge.core.query.forge_query":
            wrapped = fn
            fn = lambda: wrapped(build_manifest_graph(project_root))
        else:
            req = ", ".join(p.name for p in required_positional)
            raise RuntimeError(
                f"entry callable '{entry_id}' requires arguments ({req}); "
                "forge_trace supports zero-argument callables unless a project-context wrapper exists"
            )
    scope_mod = _entry_scope_module(mod_name, scope)
    runner = SafeTraceRunner(
        timeout=timeout,
        no_subprocess=no_subprocess,
        dry_call=dry_call,
        mock_network=mock_network,
        mock_fs_writes=mock_fs_writes,
        auto_pythonpath=auto_pythonpath,
        project_root=project_root,
    )

    def _execute_trace() -> dict[str, Any]:
        glove = PythonGlove()
        handle = glove.attach_trace_hook(
            entry_id,
            project_path=project_root,
            scope_module=scope_mod,
        )
        try:
            handle.start()
            fn()
        finally:
            graph = handle.stop()
        path = write_trace(project_root, graph, fmt=fmt, path=out_path)
        return {
            "written_to": str(path),
            "entry_point": entry_id,
            "nodes": len(graph.nodes),
            "edges": len(graph.edges),
            "scope_filter": scope_mod,
        }

    result, err = runner.run(_execute_trace)
    if err:
        raise RuntimeError(str(err))
    if isinstance(result, dict) and result.get("dry_call"):
        return {
            "written_to": None,
            "entry_point": entry_id,
            "nodes": 0,
            "edges": 0,
            "scope_filter": scope_mod,
            "dry_call": True,
            "note": str(result.get("note") or "entry not invoked (--dry-call)"),
        }
    return result if isinstance(result, dict) else {}


def _detect_and_dispatch_trace(
    project_path: Path,
    entry_point: str,
    **kwargs: Any,
) -> dict[str, Any] | None:
    """
    Detect project stack and dispatch to the appropriate trace handler.

    Currently:
      python → sys.settrace (existing)
      flutter-app → not yet implemented
      astro → not yet implemented

    Returns trace summary dict on success, or None when stack is unsupported.
    """
    stack = _get_stack(project_path)

    if stack in ("flutter-app", "flutter"):
        click.echo(
            "⚠  Flutter trace not yet implemented.\n"
            "   Run: flutter run --debug to capture logs,\n"
            "   then pipe through: forge_errors_from_log()\n"
            "   See: forge/gloves/dart_glove/__init__.py",
            err=True,
        )
        return None

    if stack == "astro":
        click.echo(
            "⚠  Astro trace not yet implemented.",
            err=True,
        )
        return None

    return run_python_trace(project_path, entry_point, **kwargs)


@click.command("trace")
@click.argument("entry_point")
@click.option("--project-path", default=".", type=click.Path(file_okay=False), show_default=True)
@click.option(
    "--output",
    "-o",
    default=None,
    type=click.Path(dir_okay=False),
    help="Write trace file here (default: .forge/traces/trace-<ts>.{yaml,json}).",
)
@click.option("--format", "fmt", type=click.Choice(["json", "yaml"], case_sensitive=False), default="yaml")
@click.option(
    "--scope",
    type=click.Choice(["module", "full"], case_sensitive=False),
    default="full",
    show_default=True,
    help="module: restrict to package of the entry module; full: project Python only.",
)
@click.option("--exit-code", "exit_code_mode", is_flag=True, default=False, help="CI gate mode: exit 1 when trace is empty.")
@click.option("--timeout", default=None, type=int, help="Max seconds for trace execution. Kills runaway traces.")
@click.option("--no-subprocess", is_flag=True, default=False, help="Block subprocess.run/Popen calls during trace.")
@click.option("--dry-call", is_flag=True, default=False, help="Import and inspect signatures only; do not invoke entry functions.")
@click.option("--mock-network", is_flag=True, default=False, help="Stub socket/requests/httpx during trace (no outbound calls).")
@click.option("--mock-fs-writes", is_flag=True, default=False, help="Stub open() write modes during trace (reads allowed).")
@click.option("--auto-pythonpath", is_flag=True, default=False, help="Auto-prepend repo root + common src/ dirs to sys.path before tracing.")
def trace_cmd(
    entry_point: str,
    project_path: str,
    output: str | None,
    fmt: str,
    scope: str,
    exit_code_mode: bool,
    timeout: int | None,
    no_subprocess: bool,
    dry_call: bool,
    mock_network: bool,
    mock_fs_writes: bool,
    auto_pythonpath: bool,
) -> None:
    """Trace execution and map to manifest.

    Python: captures sys.settrace call graph.
    Flutter: use flutter run + ForgeLog parser.
    Other stacks: coming in future gloves.

    For Flutter projects use:
      flutter run --debug 2>&1 | \\
        python3 -c "
    from forge.gloves.dart_glove import forge_errors_from_log
    import sys
    print(forge_errors_from_log(sys.stdin.read()))
    "

    Examples:
      forge trace main.py
      forge trace mymodule:main_function
      forge trace app.py --scope module
    """
    root = resolve_project_path(project_path)
    if root is None:
        raise click.ClickException("project_path could not be resolved")
    summary = _detect_and_dispatch_trace(
        root,
        entry_point,
        scope=scope,
        out_path=Path(output) if output else None,
        fmt=fmt,
        timeout=timeout,
        no_subprocess=no_subprocess,
        dry_call=dry_call,
        mock_network=mock_network,
        mock_fs_writes=mock_fs_writes,
        auto_pythonpath=auto_pythonpath,
    )
    if summary is None:
        sys.exit(1)
    if exit_code_mode:
        sys.exit(0 if int(summary.get("nodes", 0)) > 0 else 1)
    if summary.get("dry_call"):
        click.echo(f"trace dry-call: {summary.get('note', 'entry not invoked')}")
        return
    click.echo(
        f"trace: {summary['nodes']} nodes, {summary['edges']} edges → {summary['written_to']}"
        + (f" (scope={summary['scope_filter']!r})" if summary.get("scope_filter") else "")
    )