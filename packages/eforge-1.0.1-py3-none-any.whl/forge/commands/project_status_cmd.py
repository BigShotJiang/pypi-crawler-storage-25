from __future__ import annotations

import json

import click

from forge.core.path_utils import resolve_project_path
from forge.mcp.project_status_core import build_project_status_payload

_JSON_KEYS = (
    "project",
    "phase",
    "phase_name",
    "stack",
    "blocker",
    "next_action",
    "warnings",
    "packets",
)


def _structural_health_label(graph_health: str | None, healthy: bool | None) -> str:
    gh = str(graph_health or "").strip().lower()
    if gh in ("healthy", "clean"):
        return "clean"
    if gh in ("empty", "unknown", ""):
        return "unknown"
    if healthy is False:
        return "failures"
    return gh or "unknown"


def _render_status_human(full: dict, root_path: str) -> None:
    """Compact human-readable project status."""
    project = str(full.get("project") or root_path)
    stack = str(full.get("stack") or "unknown")
    phase = full.get("phase")
    phase_label = f"phase {phase}" if phase is not None else "phase ?"

    structural = "unknown"
    nodes = 0
    adi: float | None = None
    brc: float | None = None
    idr: float | None = None

    try:
        from forge.tools.manifest.graph import build_manifest_graph

        graph = build_manifest_graph(root_path)
        nodes = len(graph.nodes)
    except Exception:
        pass

    try:
        from forge.mcp.thin_core import execute_health_vector

        hv = execute_health_vector({"project_path": root_path})
        adi = float(hv["adi_score"]) if hv.get("adi_score") is not None else None
        brc = float(hv["brc_score"]) if hv.get("brc_score") is not None else None
        idr = float(hv["idr_score"]) if hv.get("idr_score") is not None else None
        structural = _structural_health_label(
            str(hv.get("graph_health") or ""),
            hv.get("healthy"),
        )
    except Exception:
        pass

    health_icon = {
        "clean": "✓",
        "failures": "✗",
        "warnings": "⚠",
        "unknown": "?",
    }.get(structural, "?")

    click.echo(f"\n✦ {project}  [{stack}]  {phase_label}")
    click.echo(f"  health: {health_icon} {structural}  |  nodes: {nodes}")

    score_parts: list[str] = []
    if adi is not None:
        score_parts.append(f"ADI {adi:.0f}%")
    if brc is not None:
        score_parts.append(f"BRC {brc:.0f}%")
    if idr is not None:
        score_parts.append(f"IDR {idr:.0f}%")
    if score_parts:
        click.echo(f"  {'  '.join(score_parts)}")

    blocker = full.get("blocker")
    warnings = list(full.get("warnings") or [])
    if blocker or warnings:
        click.echo("")
    if blocker:
        click.echo(f"  ⚠ {blocker}")
    elif warnings:
        for w in warnings[:2]:
            click.echo(f"  ⚠ {w}")
    click.echo("")


@click.command("project-status")
@click.option(
    "--project-path",
    "project_path_str",
    default=".",
    show_default=True,
    metavar="PATH",
    help="Project root containing .forge/manifest.yaml.",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    default=False,
    help="Output raw JSON (default: human-readable summary).",
)
def project_status_cmd(project_path_str: str, output_json: bool) -> None:
    """Emit a compact project snapshot (same core fields as MCP forge_project_status).

    Default output is a short human summary. Use --json for programmatic access.
    """
    root = str(resolve_project_path(project_path_str))
    full = build_project_status_payload(root, response_tier="L0", server_start_time=None)
    if output_json:
        slim = {k: full[k] for k in _JSON_KEYS if k in full}
        click.echo(json.dumps(slim, indent=2))
        return
    _render_status_human(full, root)
