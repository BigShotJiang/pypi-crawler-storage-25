from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import click
import yaml

from forge.commands._shared_options import response_tier_option
from forge.core.manifest import ManifestParser
from forge.core.manifest_path import resolve_manifest_path
from forge.core.path_utils import resolve_project_path
from forge.tools.context.index import FrontmatterIndex
from forge.tools.scan.detector import detect_framework
from forge.tools.scan.scanner import run_parser, run_scan, run_validation_only

HEADING_CONVENTION_MAP: dict[str, dict[str, str]] = {
    "ARCHITECTURE.md": {"architecture": "## Architecture"},
    "MAP.md": {"route_map": "## Route Map"},
    "MANIFEST.md": {"manifest": "## Manifest"},
    "INTERNALS.md": {"internals": "## Internals"},
}


def _load_manifest_stack(root: Path) -> str | None:
    manifest_path = resolve_manifest_path(root)
    if manifest_path is None or not manifest_path.is_file():
        return None
    parsed = ManifestParser(manifest_path).parse()
    if not parsed.ok or not isinstance(parsed.value, dict):
        return None
    data = parsed.value
    stack = data.get("stack")
    if isinstance(stack, str) and stack.strip():
        return stack.strip()
    return ManifestParser.get_stack(data)


def _node_id_for_file(res: Any, file_path: str) -> str:
    for s in getattr(res.parse, "screens", []) or []:
        if str(getattr(s, "file", "")) == file_path:
            return str(getattr(s, "name", Path(file_path).stem))
    for c in getattr(res.parse, "controllers", []) or []:
        if str(getattr(c, "file", "")) == file_path:
            return str(getattr(c, "name", Path(file_path).stem))
    for svc in getattr(res.parse, "services", []) or []:
        if str(getattr(svc, "file", "")) == file_path:
            return str(getattr(svc, "name", Path(file_path).stem))
    return Path(file_path).stem


def _scan_payload(res: Any, response_tier: str) -> dict[str, Any]:
    severed = [c for c in (res.connections or []) if bool(getattr(c, "severed", False))]
    orphans = list(res.orphans or [])
    drift = list(res.drift_items or [])
    l0: dict[str, Any] = {
        "severed_count": len(severed),
        "orphan_count": len(orphans),
        "drift_count": len(drift),
        "exit_code": int(getattr(res, "exit_code", 0)),
    }
    tier = str(response_tier or "L0").upper()
    if tier == "L0":
        return l0
    severed_nodes = [
        {"node_id": _node_id_for_file(res, str(getattr(c, "from_id", ""))), "file": str(getattr(c, "from_id", ""))}
        for c in severed
    ]
    orphan_nodes = [
        {"node_id": _node_id_for_file(res, str(getattr(o, "path", ""))), "file": str(getattr(o, "path", ""))}
        for o in orphans
    ]
    drift_nodes = [{"node_id": _node_id_for_file(res, str(d)), "file": str(d)} for d in drift]
    out = {
        **l0,
        "severed": severed_nodes,
        "orphans": orphan_nodes,
        "drift": drift_nodes,
    }
    if tier == "L2":
        out["severed_detail"] = [
            {
                "from_id": str(getattr(c, "from_id", "")),
                "to_id": str(getattr(c, "to_id", "")),
                "kind": str(getattr(c, "kind", "")),
                "declared": bool(getattr(c, "declared", False)),
                "actual": bool(getattr(c, "actual", False)),
                "severed": bool(getattr(c, "severed", False)),
                "undeclared": bool(getattr(c, "undeclared", False)),
            }
            for c in severed
        ]
        out["orphan_detail"] = [
            {
                "path": str(getattr(o, "path", "")),
                "reason": str(getattr(o, "reason", "")),
                "kind": str(getattr(o, "kind", "")),
            }
            for o in orphans
        ]
        out["drift_detail"] = [str(d) for d in drift]
    return out


def _parse_query(expr: str) -> dict[str, Any]:
    out: dict[str, Any] = {}
    parts = [p.strip() for p in expr.replace(" and ", " AND ").split(" AND ")]
    for p in parts:
        if "=" not in p:
            continue
        k, v = p.split("=", 1)
        k, v = k.strip().lower(), v.strip().strip('"').strip("'")
        if k == "type":
            out.setdefault("types", []).append(v)
        elif k == "domains":
            out.setdefault("domains", []).append(v.upper())
        elif k == "status":
            out["status"] = v
        elif k == "stubbed":
            out["stubbed"] = v.lower() in ("true", "1", "yes", "on")
    return out


def _graph_bfs(
    edges: list[tuple[str, str]],
    start: str,
    depth: int,
) -> list[tuple[str, str]]:
    """Forward dependency edges from start up to `depth` hops."""
    adj: dict[str, list[str]] = {}
    for a, b in edges:
        adj.setdefault(a, []).append(b)
    seen: set[str] = {start}
    frontier = [start]
    collected: list[tuple[str, str]] = []
    for _ in range(max(1, depth)):
        nxt: list[str] = []
        for cur in frontier:
            for nb in adj.get(cur, []):
                collected.append((cur, nb))
                if nb not in seen:
                    seen.add(nb)
                    nxt.append(nb)
        frontier = nxt
        if not frontier:
            break
    return collected


@click.command(
    "scan",
    help="Project scanner: discovery, manifest draft, validation, and docs graph.",
)
@click.argument("project_path", type=click.Path(file_okay=False), default=".", required=False)
@click.option(
    "--project-path",
    "project_path_flag",
    default=None,
    type=click.Path(file_okay=False),
    help="Project root (default: cwd). Alias for the positional path.",
)
@click.option("--output", "-o", type=click.Path(file_okay=False), default=None, help="Output directory.")
@click.option(
    "--format",
    "formats",
    multiple=True,
    default=("all",),
    show_default=True,
    type=click.Choice(["all", "manifest", "graph", "screens", "report", "validation"], case_sensitive=False),
)
@click.option("--dry-run", is_flag=True)
@click.option("--no-validate", is_flag=True, help="Discovery only (skip validation phase).")
@click.option("--no-cache", is_flag=True, help="Do not update .forge/context_cache.json.")
@click.option("--check", "do_check", is_flag=True, help="Validation only; print summary and exit 0/1/2.")
@click.option("--query", "query_expr", default=None, help='Frontmatter query, e.g. \'type=tool AND stubbed=true\'.')
@click.option("--graph", "do_graph", is_flag=True, help="Print dependency graph to stdout.")
@click.option("--from", "graph_from", default=None, help="Start graph from this file path substring.")
@click.option("--depth", "graph_depth", default=2, type=int, show_default=True)
@click.option(
    "--graph-format",
    "graph_format",
    type=click.Choice(["mermaid", "json", "text"], case_sensitive=False),
    default="text",
    show_default=True,
)
@click.option("--orphans", "do_orphans", is_flag=True, help="Print orphan report only; exit 1 if any.")
@click.option("--add-frontmatter", "add_frontmatter", is_flag=True, help="Stub frontmatter for docs missing it.")
@response_tier_option(default="L0")
def scan_cmd(
    project_path: str,
    project_path_flag: str | None,
    output: str | None,
    formats: tuple[str, ...],
    dry_run: bool,
    no_validate: bool,
    no_cache: bool,
    do_check: bool,
    query_expr: str | None,
    do_graph: bool,
    graph_from: str | None,
    graph_depth: int,
    graph_format: str,
    do_orphans: bool,
    add_frontmatter: bool,
    response_tier: str,
) -> None:
    root = resolve_project_path(project_path_flag or project_path or ".")
    if not root.is_dir():
        raise click.ClickException(f"Not a directory: {root}")
    _ = _load_manifest_stack(root)

    if query_expr is not None:
        q = _parse_query(query_expr)
        idx = FrontmatterIndex(root)
        idx.build(use_cache=True)
        types = q.get("types")
        domains = q.get("domains")
        stubbed = q.get("stubbed")
        matched = idx.query(
            domains=[str(d) for d in domains] if domains else None,
            types=[str(t) for t in types] if types else None,
            status=q.get("status"),
        )
        if stubbed is not None:
            matched = [n for n in matched if bool(n.frontmatter.get("stubbed")) == stubbed]
        for n in matched:
            click.echo(n.path)
        return

    if do_graph:
        primary, _, _ = detect_framework(root)
        parse = run_parser(primary, root)
        edges = [(e.source, e.target) for e in parse.dependencies]
        start = graph_from or (edges[0][0] if edges else "")
        if not start:
            click.echo("(no dependency edges)")
            return
        if graph_from:
            start = next((s for s, _ in edges if graph_from in s), start)
        sub = _graph_bfs(edges, start, graph_depth)
        if graph_format == "json":
            click.echo(json.dumps([{"from": a, "to": b} for a, b in sub], indent=2))
        elif graph_format == "mermaid":
            click.echo("graph TD")
            for a, b in sub:
                sa = a.replace("/", "_").replace(".", "_")
                sb = b.replace("/", "_").replace(".", "_")
                click.echo(f'  {sa}["{Path(a).name}"] --> {sb}["{Path(b).name}"]')
        else:
            for a, b in sub:
                click.echo(f"{a} -> {b}")
        return

    if do_orphans:
        res = run_validation_only(root)
        if not res.orphans:
            click.echo("No orphans detected.")
            return
        for o in res.orphans:
            click.echo(f"{o.kind}\t{o.path}\t{o.reason}")
        raise SystemExit(1)

    if add_frontmatter:
        docs = root / "docs"
        if not docs.is_dir():
            raise click.ClickException(f"No docs/ directory under {root}")
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        for md in sorted(docs.rglob("*.md")):
            try:
                raw = md.read_text(encoding="utf-8")
            except Exception:
                continue
            if raw.lstrip().startswith("---"):
                continue
            rel_name = md.name
            slug = rel_name.replace(".md", "").lower().replace(" ", "_") or "doc"
            sug = HEADING_CONVENTION_MAP.get(rel_name, {})
            es_yaml = yaml.safe_dump({"extractable_sections": sug}, default_flow_style=False).strip()
            block = (
                "---\n"
                f"id: {slug}\n"
                "type: internals\n"
                "status: draft\n"
                f"last_updated: {today}\n"
                "known_broken: []\n"
                f"{es_yaml}\n"
                "---\n\n"
            )
            if dry_run:
                click.echo(f"Would prepend frontmatter → {md.relative_to(root)}")
            else:
                md.write_text(block + raw, encoding="utf-8")
                click.echo(f"Updated {md.relative_to(root)}")
        return

    if do_check:
        res = run_validation_only(root)
        payload = _scan_payload(res, response_tier)
        click.echo(json.dumps(payload, indent=2))
        raise SystemExit(0)

    out_dir = Path(output) if output else (root / "scan")
    fmt_list = ["all"] if len(formats) == 1 and formats[0] == "all" else list(formats)
    res = run_scan(
        root,
        out_dir,
        fmt_list,
        dry_run=dry_run,
        validate=not no_validate,
        update_cache=not no_cache,
    )
    # FUTURE: forge_scan MCP tool will wrap this L1 output
    payload = _scan_payload(res, response_tier)
    payload["output_dir"] = str(out_dir)
    payload["dry_run"] = bool(dry_run)
    payload["validate"] = bool(not no_validate)
    click.echo(json.dumps(payload, indent=2))
