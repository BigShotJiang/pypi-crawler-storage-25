from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import click

_DIFF_L1_MAX_ROWS = 400


def _diff_l1_row(r: dict[str, Any]) -> dict[str, Any]:
    """Strict L1 drift row: only id, drift_type, graphs_involved (list of strings)."""
    gi = r.get("graphs_involved")
    if isinstance(gi, list):
        flat = [str(x) for x in gi if str(x).strip()]
    elif gi is None or gi == "":
        flat = []
    else:
        s = str(gi).strip()
        flat = [s] if s else []
    return {"id": r.get("id"), "drift_type": r.get("drift_type"), "graphs_involved": flat}

from forge.core.path_utils import resolve_project_path
from forge.core.response_schema import tier_fields
from forge.commands.report_cmd import _collect_contracts
from forge.tools.contract_checker import contract_drift_rows
from forge.tools.manifest.graph import build_manifest_graph
from forge.tools.intent.runtime import diff_intent_vs_declaration
from forge.tools.diff_report import build_diff_report
from forge.tools.triangulation import triangulate_graphs


def _diff_baseline_path(root: Path) -> Path:
    return root / ".forge" / "diff-baseline.json"


def _load_diff_baseline_ids(root: Path) -> set[str]:
    p = _diff_baseline_path(root)
    if not p.is_file():
        return set()
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return set()
    ids = data.get("drift_ids") if isinstance(data, dict) else None
    if not isinstance(ids, list):
        return set()
    return {str(x) for x in ids if str(x).strip()}


def _save_diff_baseline_ids(root: Path, ids: Iterable[str]) -> None:
    p = _diff_baseline_path(root)
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "drift_ids": sorted({str(x) for x in ids if str(x).strip()}),
        "saved_at": datetime.now(tz=timezone.utc).isoformat(),
    }
    p.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


@click.command("diff")
@click.option("--project-path", default=".", type=click.Path(file_okay=False), show_default=True)
@click.option("--full", is_flag=True, default=False, help="Run full declaration vs glove diff report.")
@click.option("--out", "out_path", default=None, type=click.Path(dir_okay=False), help="Write JSON report to file.")
@click.option("--contracts", "contracts_only", is_flag=True, default=False, help="Show contract drift only.")
@click.option(
    "--intent",
    "intent_only",
    is_flag=True,
    default=False,
    help="Show intent vs declaration drift only (same as --layer intent).",
)
@click.option("--response-tier", type=click.Choice(["L0", "L1", "L2"], case_sensitive=False), default="L1", show_default=True)
@click.option("--exit-code", "exit_code_mode", is_flag=True, default=False, help="CI gate mode: exit 1 when drift exists.")
@click.option(
    "--scope",
    type=click.Choice(["repo", "domain", "file", "function", "parity"], case_sensitive=False),
    default="repo",
    show_default=True,
    help="Diff scope. parity runs parity-only checks without glove diff.",
)
@click.option("--target", "scope_target", default=None, help="Scope target (domain name, file path, or node id).")
@click.option(
    "--layer",
    type=click.Choice(["declaration", "execution", "all", "intent"], case_sensitive=False),
    default="declaration",
    show_default=True,
    help="declaration: manifest vs glove only; execution: latest .forge trace vs manifest; all: both; intent: intent vs declaration (same as --intent).",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=True,
    help="Compute the full report but skip auto-captured annotation drafts.",
)
@click.option(
    "--promote-edges",
    is_flag=True,
    default=False,
    help="With --dry-run: show import edge promotion preview. Without --dry-run: write mapped imports to manifest edges: and run forge verify --scope stack.",
)
@click.option(
    "--delta",
    "delta",
    is_flag=True,
    default=False,
    help="With --full: show only drift rows whose id is not in .forge/diff-baseline.json (first run seeds baseline).",
)
@click.option(
    "--set-baseline",
    "set_baseline",
    is_flag=True,
    default=False,
    help="With --full: write current drift ids to .forge/diff-baseline.json (full rows still printed).",
)
def diff_cmd(
    project_path: str,
    full: bool,
    out_path: str | None,
    contracts_only: bool,
    intent_only: bool,
    response_tier: str,
    exit_code_mode: bool,
    scope: str,
    scope_target: str | None,
    layer: str,
    dry_run: bool,
    promote_edges: bool,
    delta: bool,
    set_baseline: bool,
) -> None:
    """Compare declaration graph against glove static analysis (read-only)."""
    root = resolve_project_path(project_path)
    tier = str(response_tier or "L1").upper()
    layer_norm = str(layer or "").strip().lower()
    intent_mode = bool(intent_only) or layer_norm == "intent"
    if intent_mode:
        graph = build_manifest_graph(root)
        rows = diff_intent_vs_declaration(root, graph)
        if tier == "L0":
            report = {"total_drift": len(rows)}
        else:
            fields = tier_fields(root, "intent_diff", tier)
            report = [{k: r.get(k) for k in fields} for r in rows] if fields else rows
    elif contracts_only:
        contracts = _collect_contracts(root)
        graph = build_manifest_graph(root, contracts=contracts)
        rows = contract_drift_rows(
            graph,
            contracts,
            scope_target=str(scope_target).strip() if scope_target else None,
        )
        if tier == "L0":
            report = {"total_drift_nodes": len({str(r.get('node_id') or '') for r in rows})}
        else:
            key = "contract_diff"
            fields = tier_fields(root, key, tier)
            if fields:
                report = [{k: r.get(k) for k in fields} for r in rows]
            else:
                report = rows
    else:
        if full:
            temporal_tier = tier if tier in ("L1", "L2") else "L2"
            tri_graph = build_manifest_graph(root)
            rows = triangulate_graphs(
                root,
                scope_target=scope_target,
                temporal_tier=temporal_tier,
                graph=tri_graph,
            )
            if set_baseline:
                _save_diff_baseline_ids(
                    root,
                    (str(r.get("id") or "") for r in rows if isinstance(r, dict)),
                )
            else:
                baseline_ids = _load_diff_baseline_ids(root)
                use_delta = bool(delta) or bool(baseline_ids)
                if use_delta:
                    if not baseline_ids:
                        _save_diff_baseline_ids(
                            root,
                            (str(r.get("id") or "") for r in rows if isinstance(r, dict)),
                        )
                    else:
                        rows = [
                            r
                            for r in rows
                            if isinstance(r, dict) and str(r.get("id") or "") not in baseline_ids
                        ]
            if tier == "L0":
                by_class: dict[str, int] = {}
                for r in rows:
                    k = str(r.get("drift_type") or "unknown")
                    by_class[k] = by_class.get(k, 0) + 1
                report = {"total_drift": len(rows), "count_by_drift_class": by_class}
            elif tier == "L1":
                projected = [_diff_l1_row(r) for r in rows if isinstance(r, dict)]
                if len(projected) > _DIFF_L1_MAX_ROWS:
                    report = {
                        "total_drift": len(rows),
                        "l1_truncated": True,
                        "l1_returned": _DIFF_L1_MAX_ROWS,
                        "drift": projected[:_DIFF_L1_MAX_ROWS],
                    }
                else:
                    report = {"total_drift": len(rows), "drift": projected}
            else:
                report = rows
        else:
            report = build_diff_report(
                root,
                scope=scope,
                scope_target=scope_target,
                layer=layer,
                dry_run=dry_run,
                promote_edges=promote_edges,
            ).to_jsonable()
    payload = json.dumps(report, indent=2)
    if exit_code_mode:
        has_drift = False
        if isinstance(report, dict):
            has_drift = any(
                int(report.get(k, 0)) > 0
                for k in ("total_drift", "total_drift_nodes", "total")
                if str(report.get(k, "")).strip() != ""
            )
            if not has_drift:
                has_drift = any(isinstance(v, list) and len(v) > 0 for v in report.values())
        elif isinstance(report, list):
            has_drift = len(report) > 0
        raise SystemExit(1 if has_drift else 0)
    if out_path:
        p = Path(out_path).expanduser()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(payload + "\n", encoding="utf-8")
        click.echo(f"wrote diff report → {p}")
        return
    click.echo(payload)
