"""Reality validation command for Forge.

Validates manifest declarations against actual file imports to detect
discrepancies between declared and actual dependencies.
"""

import logging
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text

from forge.core.reality_validator import RealityValidator, DiscrepancyType
from forge.core.path_utils import resolve_project_path
from forge.commands._shared_options import project_path_option, response_tier_option

logger = logging.getLogger(__name__)
console = Console()


@click.command()
@click.option(
    "--filter",
    help="Filter validation to specific directory (e.g., 'src/pages')"
)
@click.option(
    "--severity",
    type=click.Choice(["error", "warning", "info", "all"]),
    default="error",
    help="Filter discrepancies by severity level"
)
@click.option(
    "--type",
    "discrepancy_type",
    type=click.Choice([t.value for t in DiscrepancyType]),
    help="Filter discrepancies by type"
)
@click.option(
    "--fix-auto",
    is_flag=True,
    help="Automatically fix simple issues (missing declarations)"
)
@click.option(
    "--verbose", "-v",
    is_flag=True,
    help="Show detailed output including all discrepancies"
)
@project_path_option(required=False)
@response_tier_option()
def reality(
    filter: Optional[str],
    severity: str,
    discrepancy_type: Optional[str],
    fix_auto: bool,
    verbose: bool,
    project_path: Optional[str],
    response_tier: Optional[str]
) -> None:
    """Validate manifest against actual file import reality.
    
    Compares declared dependencies in manifest against actual import
    statements in source files to detect discrepancies.
    
    Examples:
        forge reality                           # Validate entire project
        forge reality --filter src/pages       # Validate specific directory
        forge reality --severity warning       # Show warnings and errors
        forge reality --type missing_declaration  # Show specific issue type
        forge reality --fix-auto               # Auto-fix simple issues
    """
    project_path = Path(resolve_project_path(project_path or "."))
    
    console.print(Panel(
        f"[bold blue]Forge Reality Validation[/bold blue]\n"
        f"Project: {project_path.name}\n"
        f"Filter: {filter or 'entire project'}\n"
        f"Severity: {severity}",
        title="Manifest vs Reality Check"
    ))
    
    try:
        validator = RealityValidator(project_path)
        result = validator.validate_project(filter)
        
        # Filter discrepancies
        filtered_discrepancies = _filter_discrepancies(
            result.discrepancies, severity, discrepancy_type
        )
        
        # Display results
        _display_results(result, filtered_discrepancies, verbose)
        
        # Auto-fix if requested
        if fix_auto and filtered_discrepancies:
            _auto_fix_issues(filtered_discrepancies, project_path)
        
        # Exit with appropriate code
        error_count = sum(1 for d in filtered_discrepancies if d.severity == 'error')
        if error_count > 0:
            console.print(f"\n[red]Validation failed with {error_count} errors[/red]")
            exit(1)
        elif filtered_discrepancies:
            console.print(f"\n[yellow]Validation completed with {len(filtered_discrepancies)} warnings[/yellow]")
            exit(0)
        else:
            console.print(f"\n[green]Validation passed successfully[/green]")
            exit(0)
            
    except Exception as e:
        console.print(f"\n[red]Validation error: {e}[/red]")
        logger.error(f"Reality validation failed: {e}")
        exit(1)


def _filter_discrepancies(discrepancies, severity, discrepancy_type):
    """Filter discrepancies by severity and type."""
    filtered = []
    
    for discrepancy in discrepancies:
        # Filter by severity
        if severity != "all":
            if discrepancy.severity != severity:
                continue
        
        # Filter by type
        if discrepancy_type:
            if discrepancy.discrepancy_type.value != discrepancy_type:
                continue
        
        filtered.append(discrepancy)
    
    return filtered


def _display_results(result, discrepancies, verbose):
    """Display validation results."""
    # Summary panel
    console.print(Panel(
        f"[bold]Health Score:[/bold] {result.health_score:.1%}\n"
        f"[bold]Files Checked:[/bold] {result.total_files_checked}\n"
        f"[bold]Imports Found:[/bold] {result.total_imports_found}\n"
        f"[bold]Manifest Nodes:[/bold] {result.total_manifest_nodes}\n"
        f"[bold]Discrepancies:[/bold] {len(discrepancies)}",
        title="Validation Summary"
    ))
    
    if not discrepancies:
        console.print("\n[green]No discrepancies found! Manifest matches reality.[/green]")
        return
    
    # Discrepancy breakdown
    by_type = {}
    by_severity = {'error': 0, 'warning': 0, 'info': 0}
    
    for discrepancy in discrepancies:
        dtype = discrepancy.discrepancy_type.value
        by_type[dtype] = by_type.get(dtype, 0) + 1
        by_severity[discrepancy.severity] += 1
    
    # Summary table
    summary_table = Table(title="Discrepancy Summary")
    summary_table.add_column("Type", style="bold")
    summary_table.add_column("Count", justify="right")
    summary_table.add_column("Severity", style="dim")
    
    for dtype, count in sorted(by_type.items()):
        severity_color = "red" if dtype == DiscrepancyType.MISSING_DECLARATION.value else "yellow"
        summary_table.add_row(dtype, str(count), f"[{severity_color}]{dtype}[/{severity_color}]")
    
    console.print(summary_table)
    
    if verbose or by_severity['error'] > 0:
        # Detailed discrepancies
        console.print("\n[bold]Detailed Discrepancies:[/bold]")
        
        # Group by file for better organization
        by_file = {}
        for discrepancy in discrepancies:
            file_key = str(discrepancy.source_file)
            if file_key not in by_file:
                by_file[file_key] = []
            by_file[file_key].append(discrepancy)
        
        for file_path, file_discrepancies in sorted(by_file.items()):
            console.print(f"\n[dim]{file_path}[/dim]")
            
            for discrepancy in file_discrepancies:
                severity_color = {
                    'error': 'red',
                    'warning': 'yellow', 
                    'info': 'blue'
                }.get(discrepancy.severity, 'white')
                
                console.print(f"  [{severity_color}]({discrepancy.severity.upper()})[/{severity_color}] {discrepancy.description}")
                
                if discrepancy.suggested_action:
                    console.print(f"    [dim]Suggestion: {discrepancy.suggested_action}[/dim]")
    
    # Health score interpretation
    if result.health_score >= 0.9:
        health_color = "green"
        health_text = "Excellent"
    elif result.health_score >= 0.7:
        health_color = "yellow"
        health_text = "Good"
    elif result.health_score >= 0.5:
        health_color = "orange1"
        health_text = "Fair"
    else:
        health_color = "red"
        health_text = "Poor"
    
    console.print(f"\n[bold]Health Assessment:[/bold] [{health_color}]{health_text}[/{health_color}] ({result.health_score:.1%})")


def _auto_fix_issues(discrepancies, project_path):
    """Attempt to auto-fix simple issues."""
    from forge.commands.sync_cmd import ManifestSynchronizer
    
    console.print("\n[bold]Attempting auto-fix...[/bold]")
    
    # Group fixable issues
    missing_declarations = [
        d for d in discrepancies 
        if d.discrepancy_type == DiscrepancyType.MISSING_DECLARATION
        and d.suggested_action and "Add file to manifest" in d.suggested_action
    ]
    
    if missing_declarations:
        console.print(f"Found {len(missing_declarations)} files that should be added to manifest")
        
        # Use sync command to add missing files
        synchronizer = ManifestSynchronizer(project_path)
        sync_result = synchronizer.sync_manifest(dry_run=False)
        
        if sync_result.has_changes:
            console.print(f"[green]Auto-fixed {len(sync_result.added)} missing declarations[/green]")
        else:
            console.print("[yellow]No auto-fixes applied[/yellow]")
    
    extra_declarations = [
        d for d in discrepancies 
        if d.discrepancy_type == DiscrepancyType.EXTRA_DECLARATION
    ]
    
    if extra_declarations:
        console.print(f"[yellow]Found {len(extra_declarations)} extra declarations (manual review required)[/yellow]")


# Register command
def register_reality_command(cli_group):
    """Register reality command with CLI group."""
    cli_group.add_command(reality, name="reality")
