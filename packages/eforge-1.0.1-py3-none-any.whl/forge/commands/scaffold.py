"""forge scaffold — UI template listing (and future apply subcommands)."""
# REFACTOR CANDIDATE: scaffold modes should be split into
# separate modules (menu, pipeline, spec, express).
# Tracked: command contract audit 2026-04-25.

from __future__ import annotations

import json
import logging
import subprocess
import sys
from pathlib import Path
from typing import Any

import click
import yaml

from forge.core.path_utils import resolve_project_path
from forge.core.manifest import ManifestParser
from forge.core.manifest_path import resolve_manifest_path
from forge.core.stack_profiles import profile_for_manifest_dict
from forge.core.template_registry import format_scaffold_list_lines
from forge.tools.glove_templates.registry import (
    find_template_for_kind_stack,
)
from forge.tools.intent.runtime import (
    IntentRecord,
    load_intent_by_id,
    pipeline_intent_domain,
)
from forge.tools.manifest.graph import _slug, build_manifest_graph
from forge.tools.scaffold.parser import load_node_schemas
from forge.tools.scaffold.scaffolder import (
    ScaffoldError,
    instantiate_glove_template,
    parse_template_inputs,
)
from forge.scaffold.spec_mode import run_spec_mode
from forge.scaffold.spec_mode import build_node_manifest_yaml

log = logging.getLogger(__name__)


def _template_stack_segment_for_root(root: Path) -> str:
    """Template id stack segment (e.g. python-cli, dart) from project manifest — same load as former project_template_stack."""
    mp = resolve_manifest_path(root)
    if mp is None or not mp.is_file():
        return "unknown"
    res = ManifestParser(mp).parse()
    if not res.ok or not isinstance(res.value, dict):
        return "unknown"
    return profile_for_manifest_dict(res.value).template_segment


def _resolved_root(project_path: str | Path) -> Path:
    """Expand ``~`` then resolve; use for every scaffold filesystem root."""
    return resolve_project_path(project_path)


class ScaffoldGroup(click.Group):
    """Accept `forge scaffold <node_type> ...` as pipeline shorthand."""

    def resolve_command(self, ctx: click.Context, args: list[str]):  # type: ignore[override]
        if args and not str(args[0]).startswith("-") and str(args[0]) not in self.commands:
            node_type = str(args.pop(0))
            if "--spec" in args:
                args = [a for a in args if a != "--spec"]
                spec_cmd = self.commands.get("spec")
                if spec_cmd is not None:
                    return "spec", spec_cmd, [node_type, *args]
            pipeline = self.commands.get("pipeline")
            if pipeline is not None:
                return "pipeline", pipeline, [node_type, *args]
        return super().resolve_command(ctx, args)


def _pipeline_l1_error(step: str, error_type: str, detail: str) -> None:
    click.echo(json.dumps({"step": step, "error_type": error_type, "detail": detail}, indent=2))


def _run_cli_step(args: list[str], *, cwd: Path | None = None) -> tuple[bool, str]:
    run_kw: dict[str, Any] = {"capture_output": True, "text": True}
    if cwd is not None:
        run_kw["cwd"] = str(cwd)  # cwd required — tool may be called from any working directory
    proc = subprocess.run(args, **run_kw)
    ok = proc.returncode == 0
    out = (proc.stdout or proc.stderr or "").strip()
    return ok, out


def _stack_label(root: Path) -> str:
    """Stack id for node-schema matching — uses raw YAML + ``get_stack`` (Format A safe)."""
    # TODO: replace raw yaml stack detection with ManifestParser
    mp = resolve_manifest_path(root)
    if mp is None or not mp.is_file():
        return "unknown"
    try:
        raw = yaml.safe_load(mp.read_text(encoding="utf-8"))
    except Exception:
        return "unknown"
    if not isinstance(raw, dict):
        return "unknown"
    return ManifestParser.get_stack(raw)


def _schema_matches_stack(schema: dict[str, Any], stack_label: str) -> bool:
    st = schema.get("stack")
    if st is None:
        return True
    if isinstance(st, list):
        return stack_label in {str(x) for x in st}
    return str(st) == stack_label


def _node_schema_for(root: Path, node_type: str) -> dict[str, Any] | None:
    schemas = load_node_schemas(str(root))
    stack = _stack_label(root)
    for s in schemas:
        if str(s.get("kind") or "") != node_type:
            continue
        if _schema_matches_stack(s, stack):
            return s
    for s in schemas:
        if str(s.get("kind") or "") != node_type:
            continue
        st = s.get("stack")
        if st is None or st == "" or (isinstance(st, list) and len(st) == 0):
            return s
        if _schema_matches_stack(s, stack):
            return s
    return None


def _interpolate_auto_derive(tpl: str, *, domain_upper: str, id_slug: str) -> str:
    pascal = id_slug.replace("_", " ").title().replace(" ", "")
    return (
        str(tpl)
        .replace("{id}", id_slug)
        .replace("{domain_lower}", domain_upper.lower())
        .replace("{PascalId}", pascal)
        .replace("{package}", "app")
    )


def _pipeline_id_slug(domain_upper: str) -> str:
    return domain_upper.strip().lower()


def _manifest_entry_basename(node_type: str, id_slug: str) -> str:
    if node_type == "controller":
        return f"{id_slug}_controller"
    if node_type == "service":
        return f"{id_slug}_service"
    if node_type == "screen":
        return f"{id_slug}_screen"
    if node_type == "model":
        return f"{id_slug}_model"
    return f"{id_slug}_{node_type}"


def _display_pipeline_node_id(domain_upper: str, node_type: str, id_slug: str) -> str:
    dl = domain_upper.lower()
    pascal = id_slug.replace("_", " ").title().replace(" ", "")
    if node_type == "controller":
        return f"{dl}.{pascal}Controller"
    if node_type == "service":
        return f"{dl}.{pascal}Service"
    if node_type == "screen":
        return f"{dl}.{pascal}Screen"
    if node_type == "model":
        return f"{dl}.{pascal}"
    if node_type == "module":
        return f"{dl}.{pascal}"
    return f"{dl}.{pascal}"


def _resolve_manifest_paths(
    root: Path,
    node_type: str,
    intent: IntentRecord,
    *,
    output_path: Path | None,
) -> tuple[str, str, str, str, str | None]:
    """Returns (manifest_rel, display_node_id, internal_module_id, entry_name, abs_write_or_none)."""
    intent_id = intent.id
    domain = pipeline_intent_domain(intent)
    if not domain:
        raise ValueError("domain_unresolved")
    id_slug = _pipeline_id_slug(domain)
    schema = _node_schema_for(root, node_type)
    file_tpl = (schema.get("auto_derive") or {}).get("file") if schema else None
    if file_tpl:
        manifest_rel = _interpolate_auto_derive(file_tpl, domain_upper=domain, id_slug=id_slug)
        entry_name = _manifest_entry_basename(node_type, id_slug)
        display = _display_pipeline_node_id(domain, node_type, id_slug)
        abs_write: str | None = None
        if output_path is not None:
            abs_write = str(output_path.expanduser().resolve() / Path(manifest_rel).name)
        internal = f"module/{entry_name}"
        return manifest_rel, display, internal, entry_name, abs_write

    entry_name = _slug(f"{node_type}_{intent_id[:8]}")
    manifest_rel, abs_write = _declaration_path_fields(
        local_name=entry_name, output_path=output_path
    )
    display = f"module.{entry_name}"
    internal = f"module/{entry_name}"
    return manifest_rel, display, internal, entry_name, abs_write


_SCAFFOLD_MODULE_STUB = (
    '"""Generated by forge scaffold — placeholder module."""\n'
)

def _declaration_path_fields(
    *,
    local_name: str,
    output_path: Path | None,
) -> tuple[str, str | None]:
    """Return (manifest_path_field, absolute_written_file_or_none)."""
    if output_path is not None:
        out_root = output_path.expanduser().resolve()
        rel = f"{local_name}.py"
        return rel, str(out_root / rel)
    return f".forge/generated/{local_name}.py", None


def _materialise_declaration(
    root: Path,
    node_type: str,
    intent: IntentRecord,
    *,
    output_path: Path | None = None,
) -> str:
    root = _resolved_root(root)
    manifest_path = resolve_manifest_path(root)
    if manifest_path is None:
        raise click.ClickException("manifest.yaml not found")
    parser = ManifestParser(manifest_path)
    try:
        manifest_rel, _display, _internal, entry_name, abs_write = _resolve_manifest_paths(
            root, node_type, intent, output_path=output_path
        )
    except ValueError as e:
        if str(e) == "domain_unresolved":
            raise click.ClickException(
                "intent record missing explicit `domain` field — set `domain` on "
                ".forge/intent/*.yaml or the matching .forge/annotations/*.yaml"
            ) from e
        raise
    dom = pipeline_intent_domain(intent)
    assert dom is not None
    proposed_depends_on: list[str] = []
    proposed_implements: list[str] = []
    try:
        from forge.commands.packet_cmd import run_packet_assemble

        packet = run_packet_assemble(
            node=entry_name,
            node_type=node_type,
            domain=dom,
            task="generate",
            deps=[],
            methods=[],
            project_path=str(root),
        )
        dep_rows = packet.get("deps_resolved") if isinstance(packet, dict) else []
        for dep in dep_rows if isinstance(dep_rows, list) else []:
            dep_s = str(dep).strip()
            if dep_s:
                proposed_depends_on.append(dep_s)
        contract_rows = packet.get("contracts") if isinstance(packet, dict) else []
        for c in contract_rows if isinstance(contract_rows, list) else []:
            if isinstance(c, dict):
                cid = str(c.get("id") or c.get("node_id") or c.get("name") or "").strip()
                if cid:
                    proposed_implements.append(cid)
                    continue
            c_s = str(c).strip()
            if c_s:
                proposed_implements.append(c_s)
    except Exception:
        # Proposed wiring is advisory metadata; scaffold should still emit declaration
        # if packet assembly is unavailable in this environment.
        pass
    if abs_write is not None:
        target = Path(abs_write)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(_SCAFFOLD_MODULE_STUB, encoding="utf-8")
    entry = {
        "name": entry_name,
        "kind": node_type,
        "domain": dom,
        "path": manifest_rel,
        "implemented": False,
        "intent_ref": intent.id,
        "design_source": intent.source,
        "proposed_depends_on": sorted(set(proposed_depends_on)),
        "proposed_implements": sorted(set(proposed_implements)),
    }
    res = parser.append_node("modules", entry)
    if not getattr(res, "ok", False):
        raise click.ClickException(str(getattr(res, "error", "append failed")))
    return f"module/{entry_name}"


def _run_pipeline(
    node_type: str,
    intent_id: str,
    project_path: str,
    response_tier: str,
    *,
    dry_run: bool = False,
    emit: bool = True,
    emit_spec: bool = False,
    output_path: str | None = None,
    template_inputs: list[str] | None = None,
) -> dict[str, Any]:
    root = _resolved_root(project_path)
    out_opt = _resolved_root(output_path) if (output_path or "").strip() else None

    if emit_spec and dry_run:
        raise click.UsageError("--emit-spec cannot be combined with --dry-run")

    if dry_run:
        intent = load_intent_by_id(root, str(intent_id))
        if intent is None:
            _pipeline_l1_error("read_intent", "not_found", f"intent_id={intent_id}")
            raise SystemExit(1)
        try:
            manifest_rel, display_id, internal_id, _entry_name, abs_plan = _resolve_manifest_paths(
                root, node_type, intent, output_path=out_opt
            )
        except ValueError as e:
            if str(e) == "domain_unresolved":
                payload_err: dict[str, Any] = {
                    "status": "dry_run",
                    "finding": "domain_unresolved",
                    "intent_id": intent_id,
                    "note": "Set `domain` on the intent record or matching annotation YAML.",
                }
                if emit:
                    click.echo(json.dumps(payload_err, indent=2))
                raise SystemExit(1) from e
            raise
        payload = {
            "status": "dry_run",
            "intent_id": intent_id,
            "node_id": display_id,
            "domain": pipeline_intent_domain(intent),
            "internal_module_id": internal_id,
            "steps": ["contract_diff", "trace_function", "full_triangulation"],
            "note": "manifest not modified; diff/trace subprocesses not executed",
            "manifest_path_field": manifest_rel,
        }
        if out_opt is not None:
            payload["output_path"] = str(out_opt)
        if abs_plan is not None:
            payload["would_write_file"] = abs_plan
        if str(response_tier).upper() == "L0":
            payload = {
                "status": "dry_run",
                "node_id": display_id,
                "intent_id": intent_id,
                "domain": pipeline_intent_domain(intent),
                "note": payload["note"],
                "manifest_path_field": manifest_rel,
            }
            if out_opt is not None:
                payload["output_path"] = str(out_opt)
            if abs_plan is not None:
                payload["would_write_file"] = abs_plan
        if emit:
            click.echo(json.dumps(payload, indent=2))
        return payload

    intent = load_intent_by_id(root, str(intent_id))
    if intent is None:
        _pipeline_l1_error("read_intent", "not_found", f"intent_id={intent_id}")
        raise SystemExit(1)

    try:
        node_id = _materialise_declaration(root, node_type, intent, output_path=out_opt)
    except Exception as exc:
        _pipeline_l1_error("create_declaration", "manifest_write_failed", str(exc))
        raise SystemExit(1)

    if emit_spec:
        # WIRED: emit_spec → spec_mode.py (verified)
        dom = pipeline_intent_domain(intent)
        if not dom:
            _pipeline_l1_error(
                "emit_spec",
                "domain_unresolved",
                "intent record missing explicit `domain` field",
            )
            raise SystemExit(1)
        deps: list[str] = []
        methods: list[str] = []
        for item in template_inputs or []:
            raw = str(item or "").strip()
            if not raw or "=" not in raw:
                continue
            k, v = [x.strip() for x in raw.split("=", 1)]
            if not v:
                continue
            if k in ("dep", "deps"):
                deps.extend([x.strip() for x in v.split(",") if x.strip()])
            elif k in ("method", "methods"):
                methods.append(v)
        spec_yaml = build_node_manifest_yaml(
            node_type=node_type,
            name=node_id.split("/", 1)[-1].split(".")[-1].replace("_", " ").title().replace(" ", ""),
            domain=dom,
            project_path=str(root),
            deps=deps,
            methods=methods,
        )
        if emit:
            click.echo(spec_yaml, nl=False)
        return {"status": "emit_spec", "node_manifest_yaml": spec_yaml}

    py = sys.executable
    commands = [
        ("contract_diff", [py, "-m", "forge.cli_main", "diff", "--project-path", str(root), "--contracts", "--response-tier", response_tier, "--target", node_id]),
        ("trace_function", [py, "-m", "forge.cli_main", "trace", node_id, "--project-path", str(root), "--scope", "module"]),
        ("full_triangulation", [py, "-m", "forge.cli_main", "diff", "--project-path", str(root), "--full", "--target", node_id, "--response-tier", response_tier]),
    ]
    trace_status = "ok"
    l1_warnings: list[dict[str, Any]] = []
    for step, cmd in commands:
        ok, out = _run_cli_step(cmd, cwd=root)
        if step == "trace_function" and not ok:
            trace_status = "skipped"
            l1_warnings.append(
                {
                    "step": "trace_function",
                    "issue_type": "entry_point_unresolvable",
                    "detail": out or "unknown error",
                }
            )
            continue
        if not ok:
            _pipeline_l1_error(step, "step_failed", out or "unknown error")
            raise SystemExit(1)

    payload = {
        "status": "ok",
        "intent_id": intent_id,
        "node_type": node_type,
        "nodes": [node_id],
        "node_id": node_id,
        "steps": [s for s, _ in commands],
        "trace_status": trace_status,
    }
    if out_opt is not None:
        payload["output_path"] = str(out_opt)
        try:
            _mf, _, _, _, abs_written = _resolve_manifest_paths(
                root, node_type, intent, output_path=out_opt
            )
            if abs_written:
                payload["generated_file"] = abs_written
        except ValueError:
            pass
    if l1_warnings:
        payload["l1_warnings"] = l1_warnings
    if str(response_tier).upper() == "L0":
        payload = {
            "status": "ok",
            "node_type": node_type,
            "nodes": [node_id],
            "node_id": node_id,
            "trace_status": trace_status,
        }
        if l1_warnings:
            payload["l1_warnings"] = l1_warnings
        if out_opt is not None:
            payload["output_path"] = str(out_opt)
            try:
                _mf0, _, _, _, aw0 = _resolve_manifest_paths(
                    root, node_type, intent, output_path=out_opt
                )
                if aw0:
                    payload["generated_file"] = aw0
            except ValueError:
                pass
    if emit:
        click.echo(json.dumps(payload, indent=2))
    return payload


@click.group(
    "scaffold",
    invoke_without_command=True,
    cls=ScaffoldGroup,
    context_settings={"ignore_unknown_options": True, "allow_extra_args": True},
)
@click.option(
    "--project-path",
    "project_path",
    default=".",
    show_default=False,
    help="Project root for the interactive menu.",
)
@click.option(
    "--save-as",
    "save_as",
    default=None,
    metavar="NAME",
    help="Run menu and save the validated entry as a named template.",
)
@click.option(
    "--from-template",
    "from_template",
    default=None,
    metavar="NAME",
    help="Load preset slots from a named template, then prompt for remaining fields.",
)
@click.option(
    "--list-templates",
    "list_templates_flag",
    is_flag=True,
    default=False,
    help="List available templates (combine with --stack to filter).",
)
@click.option(
    "--stack",
    "stack_filter",
    default=None,
    metavar="STACK",
    help="Filter templates by stack when using --list-templates.",
)
@click.option(
    "--describe",
    "legacy_describe",
    is_flag=True,
    default=False,
    hidden=True,
    help="Removed express lane; triggers usage error when set.",
)
@click.pass_context
def scaffold_group(
    ctx: click.Context,
    project_path: str,
    save_as: str | None,
    from_template: str | None,
    list_templates_flag: bool,
    stack_filter: str | None,
    legacy_describe: bool,
) -> None:
    """Scaffold UI layers from DOCS-TEMPLATE/UI-TEMPLATES (flat layout)."""
    if ctx.invoked_subcommand is not None:
        return
    if legacy_describe:
        raise click.UsageError(
            "not supported — author intent records via Claude chat and forge intent add"
        )
    from forge.commands.scaffold_menu import run_scaffold_menu

    run_scaffold_menu(
        project_path,
        save_as=save_as,
        from_template=from_template,
        list_templates_flag=list_templates_flag,
        stack_filter=stack_filter,
    )


@scaffold_group.command("pipeline")
@click.argument("node_type")
@click.option("--intent-id", required=True, help="Intent record id for end-to-end scaffold pipeline.")
@click.option("--project-path", default=".", show_default=True)
@click.option("--response-tier", type=click.Choice(["L0", "L1", "L2"], case_sensitive=False), default="L1", show_default=True)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Print planned pipeline steps without modifying manifest or running diff/trace.",
)
@click.option(
    "--output-path",
    "output_path",
    default=None,
    type=click.Path(file_okay=False, dir_okay=True),
    help="Write generated module file here; manifest path is relative to this directory.",
)
@click.option(
    "--emit-spec",
    "emit_spec",
    is_flag=True,
    default=False,
    help="Emit JSON spec bundle after declaration; skip diff/trace/triangulation.",
)
@click.option(
    "--input",
    "template_inputs",
    multiple=True,
    help="Template input assignment in name=value form (repeatable).",
)
def scaffold_pipeline(
    node_type: str,
    intent_id: str,
    project_path: str,
    response_tier: str,
    dry_run: bool,
    output_path: str | None,
    emit_spec: bool,
    template_inputs: tuple[str, ...],
) -> None:
    _run_pipeline(
        node_type,
        intent_id,
        project_path,
        response_tier,
        dry_run=dry_run,
        emit=True,
        emit_spec=emit_spec,
        output_path=output_path,
        template_inputs=list(template_inputs),
    )


@scaffold_group.command("spec")
@click.argument("node_type")
@click.option("--name", required=True, help="Node name (e.g. WorkoutService).")
@click.option("--domain", required=True, help="Domain enum value (e.g. GAME).")
@click.option("--project-path", default=".", show_default=True)
@click.option(
    "--dep",
    "deps",
    multiple=True,
    help="Dependency node name (repeatable).",
)
@click.option(
    "--method",
    "methods",
    multiple=True,
    help='Method signature: "name(param:Type) -> ReturnType" (repeatable).',
)
def scaffold_spec(
    node_type: str,
    name: str,
    domain: str,
    project_path: str,
    deps: tuple[str, ...],
    methods: tuple[str, ...],
) -> None:
    """Emit a node manifest YAML spec to stdout (no filesystem writes)."""
    rc = run_spec_mode(
        node_type=node_type,
        name=name,
        domain=domain,
        project_path=project_path,
        deps=list(deps),
        methods=list(methods),
    )
    if rc != 0:
        raise SystemExit(rc)


@scaffold_group.command("list")
@click.option(
    "--project-path",
    default="",
    show_default=False,
    help="Optional project root to show concrete relative output paths.",
)
def scaffold_list(project_path: str) -> None:
    """List registry units, source filenames, and target paths.
    
    Shows all available UI templates organized by stack (Flutter/React) with
    their source files and output paths. Essential for discovering what
    components can be generated.
    
    Examples:
      forge scaffold list                           # All templates with absolute paths
      forge scaffold list --project-path .         # Relative paths for current project
    
    See also: forge scaffold-interactive (interactive component selection)
    """
    pr = _resolved_root(project_path) if project_path else None
    for line in format_scaffold_list_lines(pr):
        click.echo(line)


@scaffold_group.command("express")
@click.argument("template_id")
@click.option(
    "--input",
    "template_inputs",
    multiple=True,
    help="Template input assignment in name=value form (repeatable).",
)
@click.option(
    "--project-path",
    default=".",
    show_default=True,
    help="Project root where generated files are written.",
)
def scaffold_express(template_id: str, template_inputs: tuple[str, ...], project_path: str) -> None:
    """Directly instantiate one glove template (bypass pipeline/menu flows).
    
    Quick template generation for when you know exactly what you want.
    Bypasses the interactive menu and pipeline for direct template instantiation.
    
    Examples:
      forge scaffold express component.astro              # Generate Astro component
      forge scaffold express component.dart --input name=MyButton
      forge scaffold express layout.react --input title=Dashboard
    
    See also: forge scaffold-interactive (interactive component selection)
    """
    want = str(template_id or "").strip()
    if "." not in want:
        raise click.ClickException("template_id must be kind.stack (e.g. component.astro)")
    kind, stack = want.split(".", 1)
    hit = find_template_for_kind_stack(kind, stack)
    if hit is None:
        raise click.ClickException(f"unknown template id: {want!r}")
    template_path, template = hit
    root = _resolved_root(project_path)
    try:
        parsed = parse_template_inputs(list(template_inputs))
        interactive = click.get_text_stream("stdin").isatty()
        out = instantiate_glove_template(
            template=template,
            template_path=template_path,
            project_path=root,
            cli_inputs=parsed,
            interactive=interactive,
        )
    except ScaffoldError as exc:
        raise click.ClickException(str(exc)) from exc
    click.echo(json.dumps(out, indent=2))
