"""
forge.commands.discover_cmd

forge discover — discover untracked modules and suggest manifest updates.

Minimal integration with existing forge infrastructure.
Provides suggestions without automatic mutations.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click
import yaml

from forge.core.manifest import resolve_manifest_path
from forge.core.module_discovery import ModuleDiscovery, suggest_manifest_updates


def _detect_stack(project_root: Path) -> str:
    """Detect stack from manifest or file presence."""
    try:
        from forge.core.manifest import ManifestParser

        mp = resolve_manifest_path(project_root)
        if mp and mp.is_file():
            data = yaml.safe_load(mp.read_text(encoding="utf-8")) or {}
            stack = ManifestParser.get_stack(data)
            if stack and stack != "unknown":
                return stack.lower()
    except Exception:
        pass

    if (project_root / "astro.config.ts").exists() or (
        project_root / "astro.config.mjs"
    ).exists():
        return "astro"
    if (project_root / "package.json").exists():
        return "web"
    if (project_root / "pubspec.yaml").exists():
        return "dart"
    return "python"


def _discover_web_modules(
    project_root: Path,
    existing_manifest: dict,
    stack: str,
) -> list:
    """Use ReactGlove to find untracked web files."""
    from forge.core.gloves import ReactGlove

    glove = ReactGlove()
    try:
        raw_nodes = glove.extract_nodes(project_root)
    except Exception:
        return []

    declared_paths: set[str] = set()
    declared_ids: set[str] = set()
    for section in ("modules", "screens", "services", "controllers", "nodes"):
        for node in existing_manifest.get(section) or []:
            if isinstance(node, dict):
                p = node.get("path", "")
                if p:
                    declared_paths.add(p)
                nid = node.get("id", "")
                if nid:
                    declared_ids.add(str(nid))

    untracked = []
    for node in raw_nodes:
        if node.file in declared_paths:
            continue
        node_name = str(getattr(node, "name", "") or "").lower()
        id_match = any(node_name in did.lower() for did in declared_ids)
        if id_match:
            continue
        untracked.append(_WebDiscoveredModule(node, stack))

    return untracked


class _WebDiscoveredModule:
    """Adapts RawNode to DiscoveredModule interface."""

    def __init__(self, raw_node, stack: str):
        self.name = raw_node.name
        self.path = raw_node.file
        self.domain = raw_node.domain
        self.kind = raw_node.kind
        self._node = raw_node
        self._stack = stack

    def to_manifest_entry(self) -> dict:
        return {
            "id": self._node.id,
            "name": self.name,
            "kind": self.kind,
            "domain": self.domain,
            "path": self.path,
            "status": "implemented",
            "stack": self._stack,
        }


def _module_to_dict(module: Any) -> dict[str, Any]:
    return {
        "path": str(getattr(module, "path", module)),
        "kind": str(getattr(module, "kind", "") or ""),
        "domain": str(getattr(module, "domain", "") or ""),
        "name": str(getattr(module, "name", "") or ""),
    }


def _render_discover_human(result: dict[str, Any]) -> None:
    """Human-readable discover output."""
    untracked = result.get("untracked", [])
    suggestions = result.get("suggestions", [])

    click.echo("\n✦ eforge discover\n")

    if not untracked:
        click.echo("  ✓ No untracked files found.")
        click.echo("  Manifest is up to date.\n")
        return

    click.echo(f"  Found {len(untracked)} untracked file(s):\n")

    for item in untracked[:10]:
        path = item.get("path", item) if isinstance(item, dict) else str(item)
        kind = item.get("kind", "") if isinstance(item, dict) else ""
        domain = item.get("domain", "") if isinstance(item, dict) else ""
        line = f"  + {path}"
        if kind:
            line += f"  [{kind}]"
        if domain:
            line += f"  {domain}"
        click.echo(line)

    if len(untracked) > 10:
        click.echo(f"  ... and {len(untracked) - 10} more")

    if suggestions:
        click.echo(f"\n  {len(suggestions)} manifest suggestion(s) available (--suggest).")

    click.echo("")
    click.echo("  To declare these nodes:")
    click.echo("    forge manifest add <node_id>")
    click.echo("    forge scan . (auto-populate)")
    click.echo("")


def _run_discover(
    project_root: Path,
    *,
    include_tests: bool,
    stack: str,
    suggest: bool,
) -> dict[str, Any]:
    manifest_path = resolve_manifest_path(project_root)
    existing_manifest: dict[str, Any] = {}

    if manifest_path and manifest_path.is_file():
        existing_manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8")) or {}

    resolved_stack = stack if stack != "auto" else _detect_stack(project_root)

    if resolved_stack in ("web", "astro", "react"):
        untracked_modules = _discover_web_modules(
            project_root, existing_manifest, resolved_stack
        )
    else:
        discovery = ModuleDiscovery(project_root)
        if include_tests:
            discovery.excluded_files.discard("test_")
            discovery.excluded_dirs.discard("tests")
        discovery.discover_python_modules()
        untracked_modules = discovery.find_untracked_modules(existing_manifest)

    untracked = [_module_to_dict(m) for m in untracked_modules]
    suggestions: list[dict[str, Any]] = []
    if suggest and untracked_modules:
        if resolved_stack in ("web", "astro", "react"):
            suggestions = [m.to_manifest_entry() for m in untracked_modules]
        else:
            suggestions = suggest_manifest_updates(project_root, existing_manifest)

    return {
        "project_path": str(project_root),
        "stack": resolved_stack,
        "untracked": untracked,
        "suggestions": suggestions,
        "count": len(untracked),
    }


@click.command("discover")
@click.option(
    "--project-path",
    default=".",
    show_default=True,
    help="Project root directory",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    default=False,
    help="Output raw JSON (default: human-readable).",
)
@click.option(
    "--format",
    type=click.Choice(["human", "table", "yaml", "json"]),
    default="human",
    show_default=True,
    help="Output format (human default; table uses Rich).",
)
@click.option(
    "--include-tests",
    is_flag=True,
    default=False,
    help="Include test modules in discovery",
)
@click.option(
    "--suggest",
    is_flag=True,
    default=False,
    help="Generate manifest addition suggestions",
)
@click.option(
    "--interactive",
    is_flag=True,
    default=False,
    help="Interactive mode for reviewing suggestions",
)
@click.option(
    "--stack",
    type=click.Choice(["python", "web", "astro", "dart", "auto"]),
    default="auto",
    show_default=True,
    help=(
        "Stack to scan. auto detects from manifest. web/astro uses ReactGlove. "
        "python uses ModuleDiscovery."
    ),
)
def discover_cmd(
    project_path: str,
    output_json: bool,
    format: str,
    include_tests: bool,
    suggest: bool,
    interactive: bool,
    stack: str,
) -> None:
    """Discover untracked modules and suggest manifest updates.

    Scans the project for source files not tracked in manifest.yaml.
    Default output is human-readable. Use --json for programmatic access.
    """
    project_root = Path(project_path).resolve()
    result = _run_discover(
        project_root,
        include_tests=include_tests,
        stack=stack,
        suggest=suggest,
    )

    if output_json or format == "json":
        click.echo(json.dumps(result, indent=2))
        return

    if format == "yaml":
        payload = {
            "untracked": result["untracked"],
            "suggestions": result["suggestions"],
        }
        click.echo(yaml.dump(payload, default_flow_style=False))
        return

    if format == "table":
        from rich.console import Console
        from rich.table import Table

        console = Console()
        if not result["untracked"]:
            console.print("[green]✓ All modules are tracked in manifest[/green]")
            return
        table = Table(title=f"Untracked Modules ({result['count']} found)")
        table.add_column("Module", style="cyan")
        table.add_column("Path", style="dim")
        table.add_column("Domain", style="yellow")
        table.add_column("Kind", style="green")
        for row in result["untracked"]:
            table.add_row(
                row.get("name", ""),
                row.get("path", ""),
                row.get("domain") or "unknown",
                row.get("kind", ""),
            )
        console.print(table)
        if suggest and result["suggestions"]:
            console.print("\n[bold]Suggested Manifest Additions:[/bold]")
            for suggestion in result["suggestions"]:
                console.print(f"  [cyan]{suggestion.get('id', '')}[/cyan] - {suggestion.get('path', '')}")
        return

    _render_discover_human(result)

    if interactive and result["untracked"]:
        from rich.console import Console

        console = Console()
        console.print(f"\n[bold]Interactive Review - {result['count']} modules found[/bold]")
        for i, row in enumerate(result["untracked"], 1):
            console.print(f"\n[cyan]{i}. {row.get('name', row.get('path'))}[/cyan]")
            console.print(f"   Path: {row.get('path')}")
            console.print(f"   Domain: {row.get('domain') or 'unknown'}")
            console.print(f"   Kind: {row.get('kind')}")
            if click.confirm("   Add this module to manifest?", default=True):
                console.print("   [green]✓ Would add (dry run)[/green]")
            else:
                console.print("   [dim]✗ Skipped[/dim]")
        console.print("\n[dim]Use forge manifest append to actually add modules.[/dim]")
