from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import click

from forge.core.checks import CheckResult
from forge.core.discovery import discover_projects, get_projects_root
from forge.core.manifest import ManifestParser
from forge.core.path_utils import resolve_project_path
from forge.tools.init_project.runner import _detect_stack
from forge.core.global_config import GlobalConfig
from forge.core.template import TemplateEngine
from forge.core.migration import MigrationManager, detect_schema_version, needs_migration
from forge.tools.workspace_store import find_workspace_projects, forge_config_path


def _pkg_root() -> Path:
    return Path(__file__).resolve().parent.parent.parent


def _forge_dir() -> Path:
    return Path("~/Projects/.forge").expanduser()


# Post–MCP relocation (2026-04): references to the old package path confuse tooling,
# graph, and agents. Extend this list when other canonical paths move.
_DEPRECATED_PATH_MARKERS: tuple[tuple[str, str], ...] = (
    ("forge/renderers/mcp", "MCP package path (canonical: forge/mcp/)"),
    ("forge.renderers.mcp", "Python import (canonical: forge.mcp)"),
    ("renderers.mcp.", "Legacy module prefix (canonical: mcp.)"),
    ("renderers/mcp", "Legacy path segment (canonical: mcp/)"),
)

_SKIP_DIR_PARTS = frozenset(
    {"__pycache__", ".git", "node_modules", ".pytest_cache", "dist", "build", "eggs"}
)

# This module defines the marker literals; do not scan ourselves (would false-positive).
_DOCTOR_HYGIENE_SELF = Path(__file__).resolve()


# ── Interactive Doctor Functions ───────────────────────────────────────────────────

def _run_interactive_doctor(category: str | None, fix: bool) -> None:
    """Run interactive health check selection and diagnostics."""
    HEALTH_CATEGORIES = {
        "core": {
            "name": "Core Forge",
            "description": "Forge installation, config, templates, schemas",
            "checks": ["forge itself", "global config", "templates", "schemas", "hooks", "path hygiene"],
        },
        "projects": {
            "name": "Projects",
            "description": "Project manifests and validation",
            "checks": ["projects root", "all manifests"],
        },
        "workspace": {
            "name": "Workspace",
            "description": "Workspace configuration and projects",
            "checks": ["workspace config"],
        },
        "secrets": {
            "name": "Secrets",
            "description": "Secrets directories and permissions",
            "checks": ["secrets directories"],
        },
    }
    
    def _display_category_menu() -> None:
        click.echo("\n🏥 FORGE INTERACTIVE DOCTOR")
        click.echo("=" * 50)
        click.echo("Select health check category:")
        click.echo()
        
        for i, (key, info) in enumerate(HEALTH_CATEGORIES.items(), 1):
            click.echo(f"  {i:2d}. {info['name']}")
            click.echo(f"      {info['description']}")
            click.echo(f"      Checks: {', '.join(info['checks'])}")
            click.echo()
        
        click.echo("Commands:")
        click.echo("  h. Help")
        click.echo("  q. Quit")
        click.echo("  a. All categories (full check)")
        click.echo()
    
    def _get_category_selection() -> str:
        while True:
            try:
                user_input = click.prompt("Select category (1-4, a for all)", type=str).strip()
                
                if user_input.lower() == 'q':
                    click.echo("👋 Quitting doctor")
                    sys.exit(0)
                
                if user_input.lower() == 'h':
                    click.echo("\n📖 DOCTOR HELP")
                    click.echo("=" * 20)
                    click.echo("Categories:")
                    click.echo("  1-4 - Specific health check category")
                    click.echo("  a - Run all categories (full check)")
                    click.echo("  q - Quit")
                    click.echo()
                    continue
                
                if user_input.lower() == 'a':
                    return "all"
                
                try:
                    idx = int(user_input) - 1
                    category_list = list(HEALTH_CATEGORIES.keys())
                    if 0 <= idx < len(category_list):
                        return category_list[idx]
                    else:
                        click.echo("⚠️  Invalid category number")
                except ValueError:
                    click.echo("⚠️  Invalid input")
                
            except (KeyboardInterrupt, EOFError):
                click.echo("\n👋 Quitting doctor")
                sys.exit(0)
    
    def _run_category_checks(selected_category: str) -> tuple[list[CheckResult], list[tuple[str, CheckResult]], list[tuple[str, CheckResult]]]:
        """Run checks for selected category."""
        all_checks = []
        manifest_results = []
        secrets_results = []
        
        if selected_category == "all":
            # Run all checks
            all_checks.extend([
                check_forge_install(),
                check_global_config(fix),
                check_templates(),
                check_schemas(),
                check_hooks(fix),
                check_global_docs(fix),
                check_forge_source_path_hygiene(),
                check_schema_version(),
                check_projects_root(),
                check_workspace_status(),
            ])
            manifest_results = check_all_manifests()
            secrets_results = check_secrets_dirs()
        
        elif selected_category == "core":
            all_checks.extend([
                check_forge_install(),
                check_global_config(fix),
                check_templates(),
                check_schemas(),
                check_hooks(fix),
                check_global_docs(fix),
                check_forge_source_path_hygiene(),
                check_schema_version(),
            ])
        
        elif selected_category == "projects":
            all_checks.append(check_projects_root())
            manifest_results = check_all_manifests()
        
        elif selected_category == "workspace":
            all_checks.append(check_workspace_status())
        
        elif selected_category == "secrets":
            secrets_results = check_secrets_dirs()
        
        return all_checks, manifest_results, secrets_results
    
    def _display_health_score(checks: list[CheckResult], manifest_results: list[tuple[str, CheckResult]], secrets_results: list[tuple[str, CheckResult]]) -> None:
        """Calculate and display health score."""
        total_checks = len(checks) + len(manifest_results) + len(secrets_results)
        ok_checks = sum(1 for c in checks if c.status == "ok")
        ok_manifests = sum(1 for _, c in manifest_results if c.status == "ok")
        ok_secrets = sum(1 for _, c in secrets_results if c.status == "ok")
        
        if total_checks > 0:
            health_score = int(((ok_checks + ok_manifests + ok_secrets) / total_checks) * 100)
            click.echo(f"\n🏥 HEALTH SCORE: {health_score}%")
            click.echo("=" * 30)
            click.echo(f"✅ Passed: {ok_checks + ok_manifests + ok_secrets}/{total_checks}")
            
            if health_score == 100:
                click.echo("🎉 Excellent! Forge ecosystem is fully healthy")
            elif health_score >= 80:
                click.echo("👍 Good! Minor issues detected")
            elif health_score >= 60:
                click.echo("⚠️  Fair! Some attention needed")
            else:
                click.echo("❌ Poor! Significant issues found")
            click.echo()
    
    # Run interactive flow
    if category:
        selected_category = category
    else:
        _display_category_menu()
        selected_category = _get_category_selection()
    
    click.echo(f"\n🔍 Running {selected_category} health checks...")
    click.echo()
    
    # Run the checks
    all_checks, manifest_results, secrets_results = _run_category_checks(selected_category)
    
    # Display results
    click.echo("✦ Forge Doctor Results")
    click.echo("──────────────────────────────────────")
    
    if all_checks:
        for c in all_checks:
            icon = "✓" if c.status == "ok" else ("⚠" if c.status == "warn" else "✗")
            detail = c.value or c.error or ""
            click.echo(f"  {c.label:<18} {icon}  {detail}")
    
    if manifest_results:
        click.echo("──────────────────────────────────────")
        click.echo("  Projects")
        click.echo("──────────────────────────────────────")
        for name, c in manifest_results:
            icon = "✓" if c.status == "ok" else ("⚠" if c.status == "warn" else "✗")
            detail = c.value or c.error or ""
            dogfood = " (dogfood ✦)" if name == "forge" else ""
            click.echo(f"  {name:<18} {icon}  {detail}{dogfood}")
    
    if secrets_results:
        click.echo("──────────────────────────────────────")
        click.echo("  Secrets")
        click.echo("──────────────────────────────────────")
        for name, c in secrets_results:
            icon = "✓" if c.status == "ok" else ("⚠" if c.status == "warn" else "✗")
            detail = c.value or c.error or ""
            click.echo(f"  {name:<18} {icon}  {detail}")
    
    # Display health score
    _display_health_score(all_checks, manifest_results, secrets_results)
    
    # Summary and exit
    warns = sum(1 for c in all_checks + [r[1] for r in manifest_results] + [r[1] for r in secrets_results] if c.status == "warn")
    errs = sum(1 for c in all_checks + [r[1] for r in manifest_results] + [r[1] for r in secrets_results] if c.status == "fail")
    click.echo(f"  {warns} warning(s)  •  {errs} error(s)")
    click.echo("")
    if not fix and (warns or errs):
        click.echo("  Run `forge doctor --fix` to attempt auto-fix of warnings.")
    if errs:
        raise SystemExit(1)


def scan_deprecated_path_references(pkg_root: Path) -> list[str]:
    """Return ``path:line: marker — hint`` for each deprecated substring hit."""
    hits: list[str] = []
    scan_targets: list[Path] = []
    forge_tree = pkg_root / "forge"
    if forge_tree.is_dir():
        scan_targets.append(forge_tree)
    pyproject = pkg_root / "pyproject.toml"
    if pyproject.is_file():
        scan_targets.append(pyproject)

    for base in scan_targets:
        if base.is_file():
            paths = [base]
        else:
            paths = [
                p
                for p in base.rglob("*")
                if p.is_file()
                and not any(part in _SKIP_DIR_PARTS for part in p.parts)
                and p.suffix.lower() in {".py", ".yaml", ".yml", ".md", ".toml"}
            ]
        for path in paths:
            if path.resolve() == _DOCTOR_HYGIENE_SELF:
                continue
            try:
                if path.stat().st_size > 1_500_000:
                    continue
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            lines_list = text.splitlines()
            for i, line in enumerate(lines_list, start=1):
                if line.lstrip().startswith("# hygiene:allow-deprecated-path"):
                    continue
                if i >= 2 and lines_list[i - 2].lstrip().startswith("# hygiene:allow-deprecated-path"):
                    continue
                for marker, hint in _DEPRECATED_PATH_MARKERS:
                    if marker in line:
                        rel = path.relative_to(pkg_root).as_posix()
                        hits.append(f"{rel}:{i}: {marker!r} — {hint}")
                        break
    return hits


def check_forge_source_path_hygiene(pkg_root: Path | None = None) -> CheckResult:
    """
    Dogfood: scan ``forge/`` + ``pyproject.toml`` for stale post-relocation path strings.

    Use ``# hygiene:allow-deprecated-path`` at column 0 on a line to suppress a hit
    on that line (rare migration notes in source).
    """
    root = pkg_root or _pkg_root()
    if not (root / "forge").is_dir():
        return CheckResult("path hygiene", "ok", value="skipped (not a forge checkout)")
    hits = scan_deprecated_path_references(root)
    if not hits:
        return CheckResult("path hygiene", "ok", value="no deprecated MCP path strings")
    preview = "; ".join(hits[:8])
    more = f" (+{len(hits) - 8} more)" if len(hits) > 8 else ""
    return CheckResult(
        "path hygiene",
        "warn",
        error=f"{len(hits)} stale reference(s): {preview}{more}",
    )


def check_global_docs(fix: bool = False) -> CheckResult:
    """
    Checks ~/Projects/.forge/docs/ for required global docs.
    Required: PRINCIPLES.md, ADR-001-RENDERER-AGNOSTIC.md
    Optional: FORGE_MASTER_ARCHITECTURE.md, FORGE_PATTERNS.md, DOMAINS.md, GLOSSARY.md (warn if missing).
    If fix=True, creates docs dir and stubs for any missing file.
    """
    forge_docs = _forge_dir() / "docs"
    required = ["PRINCIPLES.md", "ADR-001-RENDERER-AGNOSTIC.md"]
    optional = ["FORGE_MASTER_ARCHITECTURE.md", "FORGE_PATTERNS.md", "DOMAINS.md", "GLOSSARY.md"]
    all_files = required + optional
    if fix:
        forge_docs.mkdir(parents=True, exist_ok=True)
        for f in all_files:
            path = forge_docs / f
            if not path.exists():
                title = f.replace(".md", "").replace("-", " ").replace("_", " ")
                path.write_text(f"# {title}\n\n> TODO: fill in\n")
    present_required = sum(1 for f in required if (forge_docs / f).exists())
    present_optional = sum(1 for f in optional if (forge_docs / f).exists())
    total_required = len(required)
    total_all = total_required + len(optional)
    present_all = present_required + present_optional
    if present_required == total_required and present_all == total_all:
        return CheckResult("global docs", "ok", value=f"{present_all}/{total_all} present")
    if present_required < total_required:
        missing = [f for f in required if not (forge_docs / f).exists()]
        return CheckResult(
            "global docs", "warn",
            error=f"{present_required}/{total_required} required present (missing: {', '.join(missing)})"
        )
    return CheckResult("global docs", "ok", value=f"{present_all}/{total_all} present")


def check_forge_install() -> CheckResult:
    try:
        import importlib.metadata
        ver = importlib.metadata.version("forge")
        return CheckResult("forge install", "ok", value=f"v{ver}")
    except Exception:
        pass
    pkg_root = _pkg_root()
    pyproject = pkg_root / "pyproject.toml"
    if pyproject.exists():
        for line in pyproject.read_text().splitlines():
            if line.startswith("version = "):
                ver = line.split("=", 1)[1].strip().strip('"\'')
                return CheckResult("forge install", "ok", value=f"v{ver}")
    return CheckResult("forge install", "warn", error="Could not determine version")


def check_global_config(fix: bool) -> CheckResult:
    path = GlobalConfig.CONFIG_PATH
    if path.exists():
        return CheckResult("global config", "ok", value=str(path))
    if fix:
        GlobalConfig.create_default()
        return CheckResult("global config", "ok", value=f"Created {path}")
    return CheckResult("global config", "fail", error=f"Missing {path}")


def check_templates() -> CheckResult:
    # Check package root first (development), then ~/Projects/.forge/templates
    for base in (_pkg_root(), _forge_dir()):
        templates_dir = base / "templates"
        if not templates_dir.exists():
            continue
        expected = {"_base", "flutter", "web", "python"}
        found = set()
        for p in templates_dir.glob("*.manifest.yaml"):
            name = p.stem.replace(".manifest", "")
            found.add(name)
        if expected.issubset(found):
            names = sorted(found - {"_base"})
            return CheckResult("templates", "ok", value=f"{len(found)} templates ({', '.join(names)})")
    return CheckResult("templates", "fail", error="Expected templates not found ( _base, flutter, web, python )")


def check_schemas() -> CheckResult:
    for base in (_pkg_root(), _forge_dir()):
        schema = base / "schemas" / "v1.schema.yaml"
        if schema.exists():
            return CheckResult("schemas", "ok", value="v1.schema.yaml")
    return CheckResult("schemas", "fail", error="v1.schema.yaml not found")


def check_hooks(fix: bool) -> CheckResult:
    for base in (_pkg_root(), _forge_dir()):
        hooks_dir = base / "hooks"
        if not hooks_dir.exists():
            continue
        pre = hooks_dir / "pre-commit"
        post = hooks_dir / "post-create"
        if not pre.exists() or not post.exists():
            continue
        if fix:
            for p in (pre, post):
                try:
                    p.chmod(0o755)
                except OSError:
                    pass
        return CheckResult("hooks", "ok", value="pre-commit, post-create")
    return CheckResult("hooks", "fail", error="pre-commit and post-create not found")


def check_projects_root() -> CheckResult:
    root = get_projects_root()
    if not root.exists():
        return CheckResult("projects root", "fail", error=f"{root} does not exist")
    if not root.is_dir():
        return CheckResult("projects root", "fail", error=f"{root} is not a directory")
    projects = discover_projects(root)
    return CheckResult("projects root", "ok", value=f"{root} ({len(projects)} projects found)")


def check_workspace_status() -> CheckResult:
    cfg = forge_config_path()
    if not cfg.exists():
        return CheckResult("workspace config", "warn", error="missing ~/.forge/config.yaml (run: forge projects init)")
    env_ws = __import__("os").environ.get("FORGE_WORKSPACE")
    if env_ws:
        p = Path(env_ws).expanduser()
        if not p.is_file():
            return CheckResult("workspace config", "warn", error=f"FORGE_WORKSPACE set but unreadable: {p}")
    projects, _src = find_workspace_projects(env_ws)
    if len(projects) == 0:
        return CheckResult("workspace config", "warn", error="0 projects loaded (run: forge projects add <path>)")
    return CheckResult("workspace config", "ok", value=f"{len(projects)} project(s) loaded")


def check_all_manifests() -> list[tuple[str, CheckResult]]:
    root = get_projects_root()
    projects = discover_projects(root)
    results: list[tuple[str, CheckResult]] = []
    for p in projects:
        manifest_path = p.path / ".forge" / "manifest.yaml"
        if not manifest_path.exists():
            results.append((p.name, CheckResult(p.name, "warn", error="no manifest.yaml")))
            continue
        parser = ManifestParser(manifest_path)
        r = parser.parse()
        if r.ok:
            results.append((p.name, CheckResult(p.name, "ok", value="manifest valid")))
        else:
            results.append((p.name, CheckResult(p.name, "fail", error=r.error)))
    # Dirs without manifest
    if root.exists():
        for entry in sorted(root.iterdir()):
            if not entry.is_dir() or entry.name.startswith("."):
                continue
            if (entry / ".forge" / "manifest.yaml").exists():
                continue
            if any(n == entry.name for n, _ in results):
                continue
            results.append((entry.name, CheckResult(entry.name, "warn", error="no manifest.yaml")))
    return sorted(results, key=lambda x: x[0])


def check_secrets_dirs() -> list[tuple[str, CheckResult]]:
    root = get_projects_root()
    projects = discover_projects(root)
    results: list[tuple[str, CheckResult]] = []
    secrets_root = root / ".secrets"
    for p in projects:
        slug = p.name.lower().replace(" ", "-").replace("_", "-")
        secrets_dir = secrets_root / slug
        if secrets_dir.exists():
            results.append((p.name, CheckResult(p.name, "ok", value=str(secrets_dir))))
        else:
            results.append((p.name, CheckResult(p.name, "warn", error=f"Missing {secrets_dir}")))
    return sorted(results, key=lambda x: x[0])


def _count_manifest_nodes(manifest_path: Path) -> int:
    parser = ManifestParser(manifest_path)
    result = parser.parse()
    if not result.ok or not isinstance(result.value, dict):
        return 0
    data = result.value
    for key in ("nodes", "screens", "controllers", "services"):
        block = data.get(key)
        if isinstance(block, list):
            return len(block)
    return 0


def check_project_manifest(project_path: Path) -> CheckResult:
    manifest_path = project_path / ".forge" / "manifest.yaml"
    if not manifest_path.exists():
        return CheckResult("manifest", "fail", error="no .forge/manifest.yaml")
    parser = ManifestParser(manifest_path)
    result = parser.parse()
    if result.ok:
        return CheckResult("manifest", "ok", value="manifest valid")
    return CheckResult("manifest", "fail", error=result.error or "parse failed")


def check_project_stack(project_path: Path) -> CheckResult:
    manifest_path = project_path / ".forge" / "manifest.yaml"
    stack = _detect_stack(project_path)
    if manifest_path.exists():
        parser = ManifestParser(manifest_path)
        parsed = parser.parse()
        if parsed.ok and isinstance(parsed.value, dict):
            manifest_stack = ManifestParser.get_stack(parsed.value)
            if manifest_stack and manifest_stack != "unknown":
                stack = manifest_stack
    if stack == "unknown":
        return CheckResult("stack", "warn", error="could not detect stack")
    return CheckResult("stack", "ok", value=stack)


def check_project_nodes(project_path: Path) -> CheckResult:
    manifest_path = project_path / ".forge" / "manifest.yaml"
    if not manifest_path.exists():
        return CheckResult("nodes declared", "warn", error="no manifest")
    count = _count_manifest_nodes(manifest_path)
    if count == 0:
        return CheckResult("nodes declared", "warn", value="0 nodes")
    return CheckResult("nodes declared", "ok", value=f"{count} node(s)")


def _run_project_doctor(project_path: Path, fix: bool) -> None:
    """Project-scoped diagnostics — no workspace project list."""
    click.echo("✦ Forge Doctor")
    click.echo(f"  project: {project_path.name}")
    click.echo("──────────────────────────────────────")

    checks: list[CheckResult] = [
        check_forge_install(),
        check_project_manifest(project_path),
        check_project_stack(project_path),
        check_project_nodes(project_path),
        check_schema_version(),
    ]

    for c in checks:
        icon = "✓" if c.status == "ok" else ("⚠" if c.status == "warn" else "✗")
        detail = c.value or c.error or ""
        click.echo(f"  {c.label:<18} {icon}  {detail}")

    ok_count = sum(1 for c in checks if c.status == "ok")
    total = len(checks)
    health_score = int((ok_count / total) * 100) if total else 0
    click.echo("──────────────────────────────────────")
    click.echo(f"  health score       ✓  {health_score}%")
    warns = sum(1 for c in checks if c.status == "warn")
    errs = sum(1 for c in checks if c.status == "fail")
    click.echo(f"  {warns} warning(s)  •  {errs} error(s)")
    click.echo("")
    if not fix and (warns or errs):
        click.echo("  Run `forge doctor --project-path . --fix` to attempt auto-fix.")
    if errs:
        raise SystemExit(1)


def check_schema_version() -> CheckResult:
    """Check schema version status and migration availability."""
    migration_manager = MigrationManager()
    latest_version = migration_manager.get_latest_version()
    
    return CheckResult(
        "Schema version",
        "ok",
        value=f"Latest version: {latest_version}"
    )


@click.command(name="doctor")
@click.option("--fix", is_flag=True, default=False, help="Attempt to fix auto-fixable issues")
@click.option("--interactive", is_flag=True, default=False, help="Interactive health check selection and diagnostics")
@click.option("--category", default=None, help="Run specific health check category (core, projects, workspace, secrets)")
@click.option("--project-path", default=None, type=click.Path(file_okay=False), help="Scope diagnostics to one project.")
def doctor_cmd(
    fix: bool,
    interactive: bool,
    category: str | None,
    project_path: str | None,
) -> None:
    """
    Run health checks across the entire Forge ecosystem.
    
    Comprehensive health monitoring for Forge installation, configuration,
    projects, and ecosystem components. Essential for troubleshooting and
    maintenance.
    
    Examples:
      forge doctor                                    # Full health check
      forge doctor --fix                             # Auto-fix issues
      forge doctor --interactive                     # Interactive diagnostics
      forge doctor --category core                   # Core Forge checks only
      forge doctor --category projects               # Project validation only
    
    Health Check Categories:
      core       - Forge installation, config, templates, schemas
      projects   - Project manifests and validation
      workspace  - Workspace configuration and projects
      secrets    - Secrets directories and permissions
    
    Common Issues:
      • Missing global config: forge doctor --fix
      • Path hygiene issues: Check for deprecated MCP paths
      • Project validation failures: Review manifest.yaml files
      • Workspace config missing: forge projects init
    
    See also: forge verify (structural verification), forge map (project visualization)
    """
    if project_path and str(project_path).strip():
        root = resolve_project_path(project_path)
        if root is None:
            root = Path(project_path).expanduser().resolve()
        return _run_project_doctor(root, fix)

    # Handle interactive mode
    if interactive:
        return _run_interactive_doctor(category, fix)

    # Handle category-specific mode
    if category:
        return _run_interactive_doctor(category, fix)

    # Default full check mode
    click.echo("✦ Forge Doctor")
    click.echo("──────────────────────────────────────")

    checks: list[CheckResult] = []
    checks.append(check_forge_install())
    checks.append(check_global_config(fix))
    checks.append(check_templates())
    checks.append(check_schemas())
    checks.append(check_hooks(fix))
    checks.append(check_global_docs(fix))
    checks.append(check_forge_source_path_hygiene())
    checks.append(check_schema_version())
    checks.append(check_projects_root())
    checks.append(check_workspace_status())

    for c in checks:
        icon = "✓" if c.status == "ok" else ("⚠" if c.status == "warn" else "✗")
        detail = c.value or c.error or ""
        click.echo(f"  {c.label:<18} {icon}  {detail}")

    click.echo("──────────────────────────────────────")
    click.echo("  Projects")
    click.echo("──────────────────────────────────────")
    manifest_results = check_all_manifests()
    total_projects = len(manifest_results)
    shown = manifest_results[:5]
    for name, c in shown:
        icon = "✓" if c.status == "ok" else ("⚠" if c.status == "warn" else "✗")
        detail = c.value or c.error or ""
        dogfood = " (dogfood ✦)" if name == "forge" else ""
        click.echo(f"  {name:<18} {icon}  {detail}{dogfood}")
    if total_projects > 5:
        click.echo(f"  … and {total_projects - 5} more (not shown)")
    click.echo("")
    click.echo(
        "  Run forge doctor --project-path . "
        "for project-specific diagnostics"
    )

    click.echo("──────────────────────────────────────")
    click.echo("  Secrets")
    click.echo("──────────────────────────────────────")
    secrets_results = check_secrets_dirs()
    for name, c in secrets_results:
        icon = "✓" if c.status == "ok" else ("⚠" if c.status == "warn" else "✗")
        detail = c.value or c.error or ""
        click.echo(f"  {name:<18} {icon}  {detail}")

    click.echo("──────────────────────────────────────")
    warns = sum(1 for c in checks + [r[1] for r in manifest_results] + [r[1] for r in secrets_results] if c.status == "warn")
    errs = sum(1 for c in checks + [r[1] for r in manifest_results] + [r[1] for r in secrets_results] if c.status == "fail")
    click.echo(f"  {warns} warning(s)  •  {errs} error(s)")
    click.echo("")
    if not fix and (warns or errs):
        click.echo("  Run `forge doctor --fix` to attempt auto-fix of warnings.")
    if errs:
        raise SystemExit(1)
