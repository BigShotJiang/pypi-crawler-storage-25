"""
Minimal UniversalEvent type for use in protocol definitions.
This is intentionally a lightweight copy — the full
implementation lives in forge.events.schema.
External protocol authors import from here, not from
forge.events (which has internal dependencies).
"""
from dataclasses import dataclass, field
from datetime import datetime, timezone
import uuid


@dataclass
class ProtocolEvent:
    """
    Lightweight event type for SubscriberProtocol.
    Compatible with UniversalEvent but has no forge
    internal dependencies.
    """
    kind: str
    source_fqid: str
    project: str
    payload: dict
    id: str = field(
        default_factory=lambda: str(uuid.uuid4())[:8]
    )
    timestamp: str = field(
        default_factory=lambda: datetime.now(
            timezone.utc
        ).isoformat()
    )
    session_id: str = ""
    prev_hash: str = ""
    meta: dict = field(default_factory=dict)
