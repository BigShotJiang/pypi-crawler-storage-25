from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any

@dataclass
class GloveOutput:
    """
    The structured output every glove must produce.
    Forge consumes this — not raw file contents.
    """
    nodes: list[dict]     # list of node dicts (universal schema)
    edges: list[dict]     # list of edge dicts (universal schema)
    stack: str            # which stack was scanned
    project_path: str     # absolute path that was scanned
    meta: dict            # glove-specific metadata

    def is_empty(self) -> bool:
        return len(self.nodes) == 0 and len(self.edges) == 0


class GloveProtocol(ABC):
    """
    The formal protocol for all source analysis in Forge.

    A glove reads source code in a specific stack and produces
    nodes and edges in the universal schema. Any language, any
    stack — implement these three methods and drop the glove in
    .forge/gloves/{stack}/ to make Forge understand it.

    Discovery: Forge auto-loads any directory under .forge/gloves/
    that contains a glove.yaml and an entry point class.
    No manual registration required.

    RULE: A glove NEVER modifies the project. It only reads.
    RULE: scan() must be safe to call repeatedly — idempotent.
    RULE: watch() must be faster than scan() — incremental only.
    """

    # Declare on subclass — not passed at runtime
    stack: str = ""
    version: str = "1.0.0"
    min_forge_version: str = "0.1.0"

    @abstractmethod
    def scan(self, project_path: Path) -> GloveOutput:
        """
        Full project scan. Reads all source files in project_path
        and returns nodes + edges for the entire project.
        Safe to call repeatedly (idempotent).
        """
        ...

    @abstractmethod
    def watch(self, file_path: Path) -> GloveOutput:
        """
        Incremental scan. Called when a single file changes.
        Returns ONLY nodes and edges affected by this file.
        Must be faster than scan().
        """
        ...

    @abstractmethod
    def resolve(self, node_id: str,
                project_path: Path) -> dict | None:
        """
        Point lookup. Given a node ID, return its full node dict
        or None if not found. Used for cross-reference resolution.
        """
        ...

    def handles(self, project_path: Path) -> bool:
        """
        Returns True if this glove can handle the project at path.
        Default: checks for stack-specific indicator files.
        Override for custom detection logic.
        """
        indicators = {
            "flutter": ["pubspec.yaml"],
            "python": ["pyproject.toml", "setup.py",
                       "setup.cfg", "requirements.txt"],
            "web": ["package.json", "next.config.js",
                    "vite.config.ts", "vite.config.js"],
        }
        for indicator in indicators.get(self.stack, []):
            if (project_path / indicator).exists():
                return True
        return False

    def to_registry_node(self) -> dict:
        """
        Returns a universal node dict representing this glove
        for registration in the workspace graph.
        Kind: 'glove'. Domain: 'GLOVES'.
        """
        return {
            "id": f"glove:{self.stack}",
            "fqid": f"forge:glove:{self.stack}",
            "kind": "glove",
            "domain": "GLOVES",
            "layer": "schema",
            "status": "implemented",
            "meta": {
                "stack": self.stack,
                "version": self.version,
                "min_forge_version": self.min_forge_version,
            },
        }
