from abc import ABC, abstractmethod
from .events import ProtocolEvent


class SubscriberProtocol(ABC):
    """
    Formal protocol for reacting to Forge events.

    Drop a subscriber in .forge/subscribers/ to hook into
    any Forge operation without modifying it.

    RULE: on_event() never raises. Catch all exceptions.
    RULE: on_event() completes quickly (< 1 second).
    RULE: Return [] if no downstream events needed.
    DESIGN: Subscribers react to facts. Never commands.
    """

    subscribes_to: list[str] = []
    version: str = "1.0.0"

    @abstractmethod
    def on_event(self, event: ProtocolEvent) -> list[ProtocolEvent]:
        """React to event. Return new events or []"""
        ...

    def handles_event(self, kind: str) -> bool:
        return kind in self.subscribes_to

    def to_registry_node(self) -> dict:
        return {
            "id": f"subscriber:{self.__class__.__name__}",
            "fqid": f"forge:subscriber:{self.__class__.__name__}",
            "kind": "subscriber",
            "domain": "SUBSCRIBERS",
            "layer": "schema",
            "status": "implemented",
            "meta": {
                "subscribes_to": self.subscribes_to,
                "version": self.version,
            },
        }
