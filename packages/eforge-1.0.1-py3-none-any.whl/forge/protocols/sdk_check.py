"""
Verifies that forge/protocols/ has no unexpected
dependencies on forge internals.
Run: python3 forge/protocols/sdk_check.py
"""
import ast
import sys
from pathlib import Path

ALLOWED_INTERNAL = {
    "forge.protocols",   # self-references are fine
}

PROTOCOL_FILES = [
    "forge/protocols/glove.py",
    "forge/protocols/checker.py",
    "forge/protocols/renderer.py",
    "forge/protocols/subscriber.py",
    "forge/protocols/version.py",
    "forge/protocols/events.py",
]

violations = []
for filepath in PROTOCOL_FILES:
    path = Path(filepath)
    if not path.exists():
        continue
    tree = ast.parse(path.read_text())
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            if isinstance(node, ast.ImportFrom):
                module = node.module or ""
            else:
                module = ""
            if module.startswith("forge.") and \
               not any(
                   module.startswith(a)
                   for a in ALLOWED_INTERNAL
               ):
                violations.append(
                    f"{filepath}: imports {module}"
                )

if violations:
    print("SDK VIOLATIONS FOUND:")
    for v in violations:
        print(f"  {v}")
    sys.exit(1)
else:
    print("forge/protocols/ is SDK-clean.")
    sys.exit(0)
