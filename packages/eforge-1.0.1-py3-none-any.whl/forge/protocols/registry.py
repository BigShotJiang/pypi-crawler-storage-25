from pathlib import Path
from typing import Any, Type
import importlib
import yaml

from .glove import GloveProtocol


class GloveRegistry:
    def __init__(self):
        self._registry: dict[str, GloveProtocol] = {}

    def register(self, glove: GloveProtocol) -> None:
        self._registry[glove.stack] = glove

    def discover(self, forge_dir: Path) -> list[str]:
        discovered = []
        gloves_dir = forge_dir / "gloves"
        if not gloves_dir.exists():
            return discovered
        for stack_dir in gloves_dir.iterdir():
            if not stack_dir.is_dir():
                continue
            glove_yaml = stack_dir / "glove.yaml"
            if not glove_yaml.exists():
                continue
            try:
                config = yaml.safe_load(glove_yaml.read_text())
                entry = config.get("entry", "")
                if not entry:
                    continue
                
                # Version compatibility check
                from forge.protocols.version import (
                    check_protocol_version, get_forge_version
                )
                min_ver = config.get("min_forge_version", "0.0.0")
                result = check_protocol_version(
                    config.get("stack", "unknown"),
                    min_ver,
                    get_forge_version(),
                )
                if not result.compatible and result.warning:
                    # Store warning but continue loading
                    discovered_warnings = getattr(
                        self, "_warnings", []
                    )
                    discovered_warnings.append(result.warning)
                    self._warnings = discovered_warnings
                
                module_path, class_name = entry.rsplit(".", 1)
                module = importlib.import_module(module_path)
                instance = getattr(module, class_name)()
                self.register(instance)
                discovered.append(instance.stack)
            except Exception:
                continue
        return discovered

    def get(self, stack: str) -> GloveProtocol | None:
        return self._registry.get(stack)

    def get_for_project(self, project_path: Path) -> GloveProtocol | None:
        for glove in self._registry.values():
            if glove.handles(project_path):
                return glove
        return None

    def all_stacks(self) -> list[str]:
        return list(self._registry.keys())

    def registry_nodes(self) -> list[dict]:
        return [g.to_registry_node() for g in self._registry.values()]


_global_registry = GloveRegistry()


def get_glove_registry() -> GloveRegistry:
    return _global_registry


class CheckerRegistry:
    def __init__(self):
        self._registry: list = []

    def register(self, checker) -> None:
        self._registry.append(checker)

    def get_for_kind(self, infra_kind: str):
        for checker in self._registry:
            if checker.can_handle(infra_kind):
                return checker
        return None

    def discover(self, forge_dir: Path) -> list[str]:
        discovered = []
        checkers_dir = forge_dir / "checkers"
        if not checkers_dir.exists():
            return discovered
        for kind_dir in checkers_dir.iterdir():
            if not kind_dir.is_dir():
                continue
            checker_yaml = kind_dir / "checker.yaml"
            if not checker_yaml.exists():
                continue
            try:
                config = yaml.safe_load(checker_yaml.read_text())
                entry = config.get("entry", "")
                if not entry:
                    continue
                
                # Version compatibility check
                from forge.protocols.version import (
                    check_protocol_version, get_forge_version
                )
                min_ver = config.get("min_forge_version", "0.0.0")
                result = check_protocol_version(
                    config.get("name", "unknown"),
                    min_ver,
                    get_forge_version(),
                )
                if not result.compatible and result.warning:
                    # Store warning but continue loading
                    discovered_warnings = getattr(
                        self, "_warnings", []
                    )
                    discovered_warnings.append(result.warning)
                    self._warnings = discovered_warnings
                
                module_path, class_name = entry.rsplit(".", 1)
                module = importlib.import_module(module_path)
                checker_class = getattr(module, class_name)
                self.register(checker_class())
                discovered.extend(getattr(checker_class, "handles", []))
            except Exception:
                continue
        return discovered

    def all_kinds(self) -> list[str]:
        kinds = []
        for c in self._registry:
            kinds.extend(getattr(c, "handles", []))
        return kinds

    def registry_nodes(self) -> list[dict]:
        return [c.to_registry_node() for c in self._registry]


_global_checker_registry = CheckerRegistry()


def get_checker_registry() -> CheckerRegistry:
    return _global_checker_registry


class RendererRegistry:
    def __init__(self):
        self._registry: dict[str, Any] = {}

    def register(self, renderer) -> None:
        self._registry[renderer.format] = renderer

    def get(self, format: str):
        return self._registry.get(format)

    def discover(self, forge_dir: Path) -> list[str]:
        discovered = []
        renderers_dir = forge_dir / "renderers"
        if not renderers_dir.exists():
            return discovered
        for fmt_dir in renderers_dir.iterdir():
            if not fmt_dir.is_dir():
                continue
            renderer_yaml = fmt_dir / "renderer.yaml"
            if not renderer_yaml.exists():
                continue
            try:
                config = yaml.safe_load(renderer_yaml.read_text())
                entry = config.get("entry", "")
                if not entry:
                    continue
                
                # Version compatibility check
                from forge.protocols.version import (
                    check_protocol_version, get_forge_version
                )
                min_ver = config.get("min_forge_version", "0.0.0")
                result = check_protocol_version(
                    config.get("format", "unknown"),
                    min_ver,
                    get_forge_version(),
                )
                if not result.compatible and result.warning:
                    # Store warning but continue loading
                    discovered_warnings = getattr(
                        self, "_warnings", []
                    )
                    discovered_warnings.append(result.warning)
                    self._warnings = discovered_warnings
                
                module_path, class_name = entry.rsplit(".", 1)
                module = importlib.import_module(module_path)
                instance = getattr(module, class_name)()
                self.register(instance)
                discovered.append(instance.format)
            except Exception:
                continue
        return discovered

    def all_formats(self) -> list[str]:
        return list(self._registry.keys())

    def registry_nodes(self) -> list[dict]:
        return [r.to_registry_node() for r in self._registry.values()]


_global_renderer_registry = RendererRegistry()


def get_renderer_registry() -> RendererRegistry:
    return _global_renderer_registry


class SubscriberRegistry:
    def __init__(self):
        self._registry: dict[str, Any] = {}

    def register(self, subscriber) -> None:
        name = subscriber.__class__.__name__
        self._registry[name] = subscriber

    def get(self, name: str):
        return self._registry.get(name)

    def discover(self, forge_dir: Path) -> list[str]:
        discovered = []
        subs_dir = forge_dir / "subscribers"
        if not subs_dir.exists():
            return discovered
        for sub_dir in subs_dir.iterdir():
            if not sub_dir.is_dir():
                continue
            sub_yaml = sub_dir / "subscriber.yaml"
            if not sub_yaml.exists():
                continue
            try:
                config = yaml.safe_load(sub_yaml.read_text())
                entry = config.get("entry", "")
                if not entry:
                    continue
                
                # Version compatibility check
                from forge.protocols.version import (
                    check_protocol_version, get_forge_version
                )
                min_ver = config.get("min_forge_version", "0.0.0")
                result = check_protocol_version(
                    config.get("name", "unknown"),
                    min_ver,
                    get_forge_version(),
                )
                if not result.compatible and result.warning:
                    # Store warning but continue loading
                    discovered_warnings = getattr(
                        self, "_warnings", []
                    )
                    discovered_warnings.append(result.warning)
                    self._warnings = discovered_warnings
                
                module_path, class_name = entry.rsplit(".", 1)
                module = importlib.import_module(module_path)
                sub_class = getattr(module, class_name)
                instance = sub_class()
                self.register(instance)
                discovered.append(class_name)
            except Exception:
                continue
        return discovered

    def all_names(self) -> list[str]:
        return list(self._registry.keys())

    def all(self) -> list:
        return list(self._registry.values())

    def registry_nodes(self) -> list[dict]:
        return [s.to_registry_node() for s in self._registry.values()]


_global_subscriber_registry = SubscriberRegistry()


def get_subscriber_registry() -> SubscriberRegistry:
    return _global_subscriber_registry


def _register_builtins() -> None:
    try:
        from forge.gloves.adapters import (
            PythonGloveAdapter, DartGloveAdapter,
        )
        for cls in [PythonGloveAdapter, DartGloveAdapter]:
            try:
                _global_registry.register(cls())
            except Exception:
                pass
    except ImportError:
        pass

    # React adapter — registered but scan not implemented.
    # Discoverable for stack detection; invoke disabled.
    try:
        from forge.gloves.adapters import ReactGloveAdapter, SQLGloveAdapter

        react = ReactGloveAdapter()
        _global_registry.register(react)
        _global_registry._registry["react"] = react
        _global_registry._registry["astro"] = react
        _global_registry.register(SQLGloveAdapter())
    except Exception:
        pass

    try:
        from forge.checkers.http_checker import HttpChecker
        _global_checker_registry.register(HttpChecker())
    except ImportError:
        pass

    try:
        from forge.subscribers.convention_injector import ConventionInjector
        _global_subscriber_registry.register(ConventionInjector())
    except ImportError:
        pass


_register_builtins()
