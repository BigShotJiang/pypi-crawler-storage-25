"""
Protocol version compatibility checking.

When Forge loads an external protocol implementation,
it checks the declared min_forge_version against the
running Forge version. Incompatible versions produce
a WARNING — never a crash. The protocol is still loaded
(best-effort) but the warning is surfaced.

Version format: semantic versioning (MAJOR.MINOR.PATCH).
Compatibility: loaded protocol's min_forge_version must
be <= running Forge version.
"""

from dataclasses import dataclass
from typing import Tuple


def parse_version(version_str: str) -> Tuple[int, int, int]:
    """
    Parse a version string into a (major, minor, patch) tuple.
    Returns (0, 0, 0) for unparseable strings — never raises.
    """
    try:
        parts = version_str.strip().lstrip("v").split(".")
        major = int(parts[0]) if len(parts) > 0 else 0
        minor = int(parts[1]) if len(parts) > 1 else 0
        patch = int(parts[2]) if len(parts) > 2 else 0
        return (major, minor, patch)
    except Exception:
        return (0, 0, 0)


def is_compatible(
    min_required: str,
    running: str,
) -> bool:
    """
    Returns True if running version satisfies min_required.
    running >= min_required → compatible.
    """
    return parse_version(running) >= parse_version(min_required)


@dataclass
class VersionCheckResult:
    compatible: bool
    min_required: str
    running: str
    warning: str = ""

    def __bool__(self) -> bool:
        return self.compatible


def check_protocol_version(
    protocol_name: str,
    min_forge_version: str,
    forge_version: str,
) -> VersionCheckResult:
    """
    Check if a protocol implementation is compatible with
    the running Forge version.
    Returns a VersionCheckResult — never raises.
    """
    compatible = is_compatible(min_forge_version, forge_version)
    warning = ""
    if not compatible:
        warning = (
            f"Protocol '{protocol_name}' requires Forge "
            f">= {min_forge_version}, but running {forge_version}. "
            f"Loading anyway (best-effort) — some features may fail."
        )
    return VersionCheckResult(
        compatible=compatible,
        min_required=min_forge_version,
        running=forge_version,
        warning=warning,
    )


def get_forge_version() -> str:
    """
    Returns the running Forge version string.
    Falls back to '0.0.0' if not determinable.
    """
    try:
        import forge
        return getattr(forge, "__version__", "0.0.0")
    except Exception:
        return "0.0.0"
