from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

@dataclass
class CheckResult:
    """
    The structured output every checker must produce.
    score is 0-100. issues contains actionable findings.
    """
    infra_kind: str          # what was checked
    score: int               # 0-100 health score
    healthy: bool            # score >= threshold
    issues: list[dict]       # each: {severity, message, fix}
    meta: dict = field(default_factory=dict)

    def __post_init__(self):
        self.score = max(0, min(100, self.score))
        self.healthy = self.score >= 70

    @classmethod
    def passing(cls, infra_kind: str,
                score: int = 100) -> "CheckResult":
        return cls(infra_kind=infra_kind, score=score,
                   healthy=True, issues=[])

    @classmethod
    def failing(cls, infra_kind: str, score: int,
                message: str, fix: str = "") -> "CheckResult":
        return cls(
            infra_kind=infra_kind, score=score, healthy=False,
            issues=[{"severity": "error",
                     "message": message, "fix": fix}],
        )


@dataclass
class CheckerContext:
    """
    Everything a checker needs to run.
    Passed by Forge — the checker reads, never writes.
    """
    project_path: Path
    infra_kind: str
    config: dict = field(default_factory=dict)
    secrets_path: Path | None = None   # ~/Projects/.secrets/
    meta: dict = field(default_factory=dict)


class CheckerProtocol(ABC):
    """
    The formal protocol for infrastructure health checks.

    A checker tests whether a declared infrastructure node
    is reachable, configured, and healthy. Drop a checker in
    .forge/checkers/{infra_kind}/ to make Forge understand
    a new infrastructure type.

    RULE: A checker NEVER modifies infrastructure. Read-only.
    RULE: check() must complete within 10 seconds.
    RULE: A checker that times out returns CheckResult.failing(),
          never raises.
    """

    handles: list[str] = []   # infra kinds this checker handles
    version: str = "1.0.0"

    @abstractmethod
    def check(self, context: CheckerContext) -> CheckResult:
        """
        Test infrastructure health. Returns CheckResult.
        Must never raise — catch all exceptions internally
        and return CheckResult.failing() with the error.
        """
        ...

    def can_handle(self, infra_kind: str) -> bool:
        return infra_kind in self.handles

    def to_registry_node(self) -> dict:
        return {
            "id": f"checker:{'-'.join(self.handles)}",
            "fqid": f"forge:checker:{'-'.join(self.handles)}",
            "kind": "checker",
            "domain": "CHECKERS",
            "layer": "schema",
            "status": "implemented",
            "meta": {
                "handles": self.handles,
                "version": self.version,
            },
        }
