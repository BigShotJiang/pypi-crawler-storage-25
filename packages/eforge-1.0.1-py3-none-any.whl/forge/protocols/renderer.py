from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class RenderInput:
    graph_data: dict
    format: str
    options: dict = field(default_factory=dict)


class RendererProtocol(ABC):
    """
    Formal protocol for output format rendering.
    Drop a renderer in .forge/renderers/{format}/ to add
    a new output format. Format enum is always open.

    RULE: render() never modifies the graph. Read-only.
    RULE: render() returns a string, never a file path.
    RULE: render() never raises.
    """

    format: str = ""
    version: str = "1.0.0"

    @abstractmethod
    def render(self, input: RenderInput) -> str: ...

    def can_render(self, format: str) -> bool:
        return format == self.format

    def to_registry_node(self) -> dict:
        return {
            "id": f"renderer:{self.format}",
            "fqid": f"forge:renderer:{self.format}",
            "kind": "renderer",
            "domain": "RENDERERS",
            "layer": "schema",
            "status": "implemented",
            "meta": {"format": self.format, "version": self.version},
        }
