"""Event log system for INTENT-A4CBBFBC - Auto-append functionality.

Provides structured logging of significant Forge operations separate from intent graph.
Captures operational facts while avoiding signal-to-noise issues.
"""

import json
import logging
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from uuid import uuid4
from forge.core.path_utils import resolve_project_path

logger = logging.getLogger(__name__)


class EventType(Enum):
    """Types of events that can be auto-appended."""
    SCAFFOLD_COMPLETED = "scaffold.completed"
    SCAN_COMPLETED = "scan.completed"
    SESSION_OPENED = "session.opened"
    SESSION_CLOSED = "session.closed"
    INTENT_CREATED = "intent.created"
    ANNOTATION_CREATED = "annotation.created"
    MANIFEST_UPDATED = "manifest.updated"
    PACKET_ASSEMBLED = "packet.assembled"


class EventSeverity(Enum):
    """Severity levels for events."""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


@dataclass
class EventMetadata:
    """Metadata for event tracking."""
    timestamp: float = field(default_factory=time.time)
    session_id: Optional[str] = None
    client_info: Optional[Dict[str, Any]] = None
    project_path: Optional[str] = None
    user: Optional[str] = None
    duration_ms: Optional[int] = None


@dataclass
class EventEntry:
    """Single event entry in the event log."""
    id: str = field(default_factory=lambda: str(uuid4()))
    event_type: EventType = EventType.SCAFFOLD_COMPLETED
    severity: EventSeverity = EventSeverity.INFO
    metadata: EventMetadata = field(default_factory=EventMetadata)
    data: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert event to dictionary for storage."""
        return {
            "id": self.id,
            "event_type": self.event_type.value,
            "severity": self.severity.value,
            "timestamp": self.metadata.timestamp,
            "iso_timestamp": datetime.fromtimestamp(self.metadata.timestamp, tz=timezone.utc).isoformat(),
            "session_id": self.metadata.session_id,
            "client_info": self.metadata.client_info,
            "project_path": self.metadata.project_path,
            "user": self.metadata.user,
            "duration_ms": self.metadata.duration_ms,
            "data": self.data
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EventEntry":
        """Create event from dictionary."""
        metadata = EventMetadata(
            timestamp=data.get("timestamp", time.time()),
            session_id=data.get("session_id"),
            client_info=data.get("client_info"),
            project_path=data.get("project_path"),
            user=data.get("user"),
            duration_ms=data.get("duration_ms")
        )
        
        return cls(
            id=data.get("id", str(uuid4())),
            event_type=EventType(data.get("event_type", "scaffold.completed")),
            severity=EventSeverity(data.get("severity", "info")),
            metadata=metadata,
            data=data.get("data", {})
        )


class EventClassifier:
    """Classifies operations to determine if they should be auto-appended."""
    
    # Operations that should trigger auto-append
    SIGNIFICANT_OPERATIONS = {
        "forge_scaffold",
        "forge_audit_scan", 
        "forge_session",
        "forge_intent",
        "forge_annotate",
        "forge_manifest",
        "forge_packet"
    }
    
    # Read-only operations that should NOT trigger auto-append
    READ_OPERATIONS = {
        "forge_orient",
        "forge_query",
        "forge_manifest_get",
        "forge_intent_query",
        "forge_verify"
    }
    
    # Operations that should never be auto-appended (to prevent loops)
    EXCLUDED_OPERATIONS = {
        "forge_events",
        "forge_event_log"
    }
    
    @classmethod
    def should_auto_append(cls, operation: str, action: Optional[str] = None, 
                          success: bool = True) -> bool:
        """Determine if an operation should be auto-appended."""
        # Never append excluded operations
        if operation in cls.EXCLUDED_OPERATIONS:
            return False
        
        # Only append successful operations (failures go to error log)
        if not success:
            return False
        
        # Check if it's a significant operation
        if operation in cls.SIGNIFICANT_OPERATIONS:
            # Further filter by action for some operations
            if operation == "forge_scaffold":
                return action in ["generate", "assemble"]
            elif operation == "forge_audit_scan":
                return action == "scan"
            elif operation == "forge_session":
                return action in ["start", "handoff"]
            elif operation == "forge_intent":
                return action == "add"
            elif operation == "forge_annotate":
                return action in ["create", "update"]
            elif operation == "forge_manifest":
                return action in ["append", "migrate"]
            elif operation == "forge_packet":
                return action == "assemble"
        
        return False
    
    @classmethod
    def classify_event(cls, operation: str, action: Optional[str] = None) -> EventType:
        """Classify the event type based on operation and action."""
        if operation == "forge_scaffold" and action in ["generate", "assemble"]:
            return EventType.SCAFFOLD_COMPLETED
        elif operation == "forge_audit_scan" and action == "scan":
            return EventType.SCAN_COMPLETED
        elif operation == "forge_session" and action == "start":
            return EventType.SESSION_OPENED
        elif operation == "forge_session" and action == "handoff":
            return EventType.SESSION_CLOSED
        elif operation == "forge_intent" and action == "add":
            return EventType.INTENT_CREATED
        elif operation == "forge_annotate" and action in ["create", "update"]:
            return EventType.ANNOTATION_CREATED
        elif operation == "forge_manifest" and action in ["append", "migrate"]:
            return EventType.MANIFEST_UPDATED
        elif operation == "forge_packet" and action == "assemble":
            return EventType.PACKET_ASSEMBLED
        else:
            # Default to scaffold completed for unknown operations
            return EventType.SCAFFOLD_COMPLETED


class EventLog:
    """Event log storage and management system."""
    
    def __init__(self, log_dir: Optional[Path] = None):
        self.log_dir = log_dir or Path.cwd() / ".forge" / "events"
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.log_file = self.log_dir / "events.jsonl"
        self.index_file = self.log_dir / "index.json"
        
        # Load existing index
        self._load_index()
    
    def _load_index(self) -> None:
        """Load event index for fast queries."""
        try:
            if self.index_file.exists():
                with open(self.index_file, 'r') as f:
                    self.index = json.load(f)
            else:
                self.index = {
                    "total_events": 0,
                    "event_types": {},
                    "last_updated": time.time()
                }
        except Exception as e:
            logger.warning(f"Failed to load event index: {e}")
            self.index = {
                "total_events": 0,
                "event_types": {},
                "last_updated": time.time()
            }
    
    def _save_index(self) -> None:
        """Save event index."""
        try:
            self.index["last_updated"] = time.time()
            with open(self.index_file, 'w') as f:
                json.dump(self.index, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save event index: {e}")
    
    def append_event(self, event: EventEntry) -> None:
        """Append an event to the log."""
        try:
            # Append to log file
            with open(self.log_file, 'a') as f:
                f.write(json.dumps(event.to_dict()) + '\n')
            
            # Update index
            self.index["total_events"] += 1
            event_type = event.event_type.value
            self.index["event_types"][event_type] = self.index["event_types"].get(event_type, 0) + 1
            
            self._save_index()
            
            logger.debug(f"Appended event {event.id} of type {event_type}")
            
        except Exception as e:
            logger.error(f"Failed to append event {event.id}: {e}")
    
    def query_events(self, event_type: Optional[EventType] = None, 
                    session_id: Optional[str] = None,
                    project_path: Optional[str] = None,
                    limit: int = 100,
                    offset: int = 0) -> List[EventEntry]:
        """Query events from the log."""
        events = []
        
        try:
            if not self.log_file.exists():
                return events
            
            with open(self.log_file, 'r') as f:
                for line in f:
                    try:
                        data = json.loads(line.strip())
                        event = EventEntry.from_dict(data)
                        
                        # Apply filters
                        if event_type and event.event_type != event_type:
                            continue
                        if session_id and event.metadata.session_id != session_id:
                            continue
                        if project_path and event.metadata.project_path != project_path:
                            continue
                        
                        events.append(event)
                        
                    except json.JSONDecodeError:
                        continue
            
            # Sort by timestamp (newest first) and apply pagination
            events.sort(key=lambda e: e.metadata.timestamp, reverse=True)
            
            return events[offset:offset + limit]
            
        except Exception as e:
            logger.error(f"Failed to query events: {e}")
            return []
    
    def get_event_stats(self) -> Dict[str, Any]:
        """Get statistics about the event log."""
        return {
            "total_events": self.index["total_events"],
            "event_types": self.index["event_types"],
            "last_updated": self.index["last_updated"],
            "log_file": str(self.log_file),
            "log_size_bytes": self.log_file.stat().st_size if self.log_file.exists() else 0
        }
    
    def get_recent_events(self, limit: int = 50) -> List[EventEntry]:
        """Get recent events across all types."""
        return self.query_events(limit=limit)


# Global event log instance
_event_log = EventLog()


def get_event_log() -> EventLog:
    """Get the global event log instance."""
    return _event_log


def auto_append_event(operation: str, action: Optional[str] = None,
                     data: Optional[Dict[str, Any]] = None,
                     session_id: Optional[str] = None,
                     client_info: Optional[Dict[str, Any]] = None,
                     project_path: Optional[str] = None,
                     user: Optional[str] = None,
                     duration_ms: Optional[int] = None,
                     severity: EventSeverity = EventSeverity.INFO,
                     success: bool = True) -> Optional[str]:
    """Auto-append an event if the operation is significant.
    
    Returns the event ID if appended, None otherwise.
    """
    if not EventClassifier.should_auto_append(operation, action, success):
        return None
    
    try:
        # Classify the event
        event_type = EventClassifier.classify_event(operation, action)
        
        # Create metadata
        metadata = EventMetadata(
            session_id=session_id,
            client_info=client_info,
            project_path=project_path,
            user=user,
            duration_ms=duration_ms
        )
        
        # Create event
        event = EventEntry(
            event_type=event_type,
            severity=severity,
            metadata=metadata,
            data=data or {}
        )
        
        # Append to log
        _event_log.append_event(event)
        
        # Trigger graph synchronization for significant events
        try:
            from forge.core.graph_sync import trigger_sync_from_event
            trigger_sync_from_event(event_type.value, data, project_path)
        except ImportError:
            # Graph sync not available, skip
            pass
        except Exception as e:
            logger.warning(f"Failed to trigger graph sync: {e}")
        
        # Trigger vector memory auto-embedding for significant events
        try:
            from forge.core.vector_memory_auto_embedding import trigger_auto_embedding_on_event
            trigger_auto_embedding_on_event(event_type.value, data, project_path)
        except ImportError:
            # Vector memory not available, skip
            pass
        except Exception as e:
            logger.warning(f"Failed to trigger vector memory auto-embedding: {e}")
        
        logger.info(f"Auto-appended event {event.id}: {event_type.value}")
        return event.id
        
    except Exception as e:
        logger.error(f"Failed to auto-append event: {e}")
        return None


# Decorator for auto-appending function calls
def auto_append(operation: str, action: Optional[str] = None,
               data_key: str = "result", 
               include_duration: bool = True,
               severity: EventSeverity = EventSeverity.INFO):
    """Decorator to auto-append events for function calls."""
    def decorator(func):
        def wrapper(*args, **kwargs):
            start_time = time.time()
            success = True
            result = None
            error = None
            
            try:
                result = func(*args, **kwargs)
                return result
            except Exception as e:
                success = False
                error = str(e)
                raise
            finally:
                # Only auto-append if the operation is significant
                if EventClassifier.should_auto_append(operation, action, success):
                    # Extract event data
                    event_data = {}
                    if result and data_key:
                        if isinstance(result, dict) and data_key in result:
                            event_data[data_key] = result[data_key]
                        elif hasattr(result, data_key):
                            event_data[data_key] = getattr(result, data_key)
                    
                    if error:
                        event_data["error"] = error
                    
                    # Calculate duration
                    duration_ms = int((time.time() - start_time) * 1000) if include_duration else None
                    
                    # Extract context from kwargs if available
                    session_id = kwargs.get("session_id")
                    project_path = kwargs.get("project_path")
                    user = kwargs.get("user")
                    
                    # Auto-append the event
                    auto_append_event(
                        operation=operation,
                        action=action,
                        data=event_data,
                        session_id=session_id,
                        project_path=project_path,
                        user=user,
                        duration_ms=duration_ms,
                        severity=severity,
                        success=success
                    )
        
        return wrapper
    return decorator


__all__ = [
    "EventType",
    "EventSeverity", 
    "EventMetadata",
    "EventEntry",
    "EventClassifier",
    "EventLog",
    "get_event_log",
    "auto_append_event",
    "auto_append"
]
