from __future__ import annotations

import re
from typing import Any

from pydantic import BaseModel, Field

from forge.core.schemas import ForgeError, PipelineDescriptor, PipelineStep, PipelineStepKind


class StepResult(BaseModel):
    step: str
    kind: PipelineStepKind
    output: dict[str, Any] = Field(default_factory=dict)
    skipped: bool = False
    error: ForgeError | None = None


class PipelineResult(BaseModel):
    pipeline_id: str
    completed: bool
    steps: list[StepResult] = Field(default_factory=list)
    final_output: dict[str, Any] = Field(default_factory=dict)
    error: ForgeError | None = None


class PipelineExecutor:
    """
    Walks a PipelineDescriptor, resolving input_map composition and accumulating step outputs.
    This worker never calls MCP tools directly — handlers translate execution events.
    """

    def __init__(self, descriptor: PipelineDescriptor, context: dict[str, Any]) -> None:
        self.descriptor = descriptor
        self.context = dict(context)
        self.step_outputs: dict[str, dict[str, Any]] = {}

    def resolve_inputs(self, step: PipelineStep) -> dict[str, Any]:
        resolved: dict[str, Any] = {}
        for param, source in (step.input_map or {}).items():
            src = str(source)
            if src.startswith("context."):
                resolved[param] = self.context.get(src[len("context.") :])
                continue
            parts = src.split(".", 1)
            step_label = parts[0]
            field_path = parts[1] if len(parts) > 1 else None
            step_out = self.step_outputs.get(step_label, {})
            resolved[param] = self._extract(step_out, field_path) if field_path else step_out
        return resolved

    def _extract(self, data: Any, path: str | None) -> Any:
        if not path:
            return data
        cur: Any = data
        for part in re.split(r"\.(?![^\[]*\])", path):
            idx_match = re.match(r"(\w+)\[(\d+)\]$", part)
            if idx_match:
                key = idx_match.group(1)
                idx = int(idx_match.group(2))
                cur = cur.get(key, []) if isinstance(cur, dict) else []
                cur = cur[idx] if isinstance(cur, list) and 0 <= idx < len(cur) else None
            else:
                cur = cur.get(part) if isinstance(cur, dict) else None
            if cur is None:
                return None
        return cur

    def record_output(self, step_label: str, output: dict[str, Any]) -> None:
        self.step_outputs[step_label] = dict(output)

    def next_step(self) -> PipelineStep | None:
        executed = set(self.step_outputs.keys())
        for step in self.descriptor.steps:
            if step.step not in executed:
                return step
        return None

    def is_complete(self) -> bool:
        executed = set(self.step_outputs.keys())
        return all(s.step in executed for s in self.descriptor.steps)
