"""Change classification for forge_impact_check — scoped propagation vs broad domain flood."""

from __future__ import annotations

import re
import subprocess
from pathlib import Path

from forge.core.schemas import ChangeClass, ChangeEvent, NodeTier, tier_includes
from forge.tools.manifest.graph import (
    ManifestGraph,
    ManifestNode,
    effective_node_tier,
    find_node_id_for_path,
)

TIER_IMPORT_RULES: dict[NodeTier, list[NodeTier]] = {
    # MCP/surface façade may import schema contracts and worker implementation
    # modules (subtype traversal covers glove/gate/registry under worker/schema).
    NodeTier.SURFACE: [
        NodeTier.SURFACE,
        NodeTier.SCHEMA,
        NodeTier.WORKER,
        NodeTier.PIPELINE,
    ],
    NodeTier.WORKER: [
        NodeTier.SURFACE,
        NodeTier.WORKER,
        NodeTier.SCHEMA,
        NodeTier.GLOVE,
        NodeTier.REGISTRY,
        NodeTier.PIPELINE,
        NodeTier.GATE,
    ],
    NodeTier.SCHEMA: [NodeTier.SCHEMA],
    NodeTier.GLOVE: [NodeTier.WORKER, NodeTier.SCHEMA],
    NodeTier.GATE: [
        NodeTier.SURFACE,
        NodeTier.WORKER,
        NodeTier.SCHEMA,
        NodeTier.GLOVE,
        NodeTier.REGISTRY,
        NodeTier.PIPELINE,
        NodeTier.GATE,
    ],
    NodeTier.REGISTRY: [NodeTier.SCHEMA],
    NodeTier.PIPELINE: [],
}


def _parse_node_tier_label(raw: str | None) -> NodeTier:
    try:
        return NodeTier(str(raw or "worker").strip().lower())
    except ValueError:
        return NodeTier.WORKER


def check_tier_violations(
    graph: ManifestGraph,
    node: ManifestNode | dict[str, object],
) -> list[ChangeEvent]:
    """Check outbound ``imports`` edges against :data:`TIER_IMPORT_RULES`.

    Emits :class:`ChangeEvent` with ``change_class`` ``TIER_IMPORT_VIOLATION`` and
    ``breaking=True`` when an import target tier is not allowed for the source tier.
    """
    by_id = {n.id: n for n in graph.nodes}
    if isinstance(node, ManifestNode):
        nid = node.id
        path_s = str(node.path or "")
        source_tier = _parse_node_tier_label(effective_node_tier(node))
    else:
        nid = str(node.get("id") or "")
        path_s = str(node.get("path") or "")
        n_obj = by_id.get(nid)
        source_tier = _parse_node_tier_label(
            str(node.get("tier") or "")
            if node.get("tier") not in (None, "")
            else (effective_node_tier(n_obj) if n_obj else "worker")
        )
    if not nid:
        return []

    allowed = TIER_IMPORT_RULES.get(source_tier)
    if allowed is None:
        allowed = []

    violations: list[ChangeEvent] = []
    for edge in graph.edges_from(nid):
        if edge.relation != "imports":
            continue
        tid = str(edge.to_id)
        target = by_id.get(tid)
        if target is None:
            continue
        target_tier = _parse_node_tier_label(effective_node_tier(target))
        allowed_ok = bool(allowed) and any(
            tier_includes(a, target_tier) for a in allowed
        )
        if not allowed_ok:
            violations.append(
                ChangeEvent(
                    file=path_s,
                    change_class=ChangeClass.TIER_IMPORT_VIOLATION,
                    breaking=True,
                    affected_node_ids=[nid, tid],
                    context={
                        "violation": "tier_import_rule",
                        "from_node": nid,
                        "to_node": tid,
                        "from_tier": source_tier.value,
                        "to_tier": target_tier.value,
                        "edge": f"{nid} → {tid}",
                    },
                )
            )
    return violations


def collect_tier_import_violations(graph: ManifestGraph) -> list[ChangeEvent]:
    """Run :func:`check_tier_violations` for every node in *graph*."""
    out: list[ChangeEvent] = []
    for n in graph.nodes:
        out.extend(
            check_tier_violations(
                graph,
                {"id": n.id, "path": n.path or "", "tier": effective_node_tier(n)},
            )
        )
    return out

_PIPELINE_STEP_ADD = re.compile(r"^\+\s+-\s+step:\s+\S")
_PIPELINE_STEP_REM = re.compile(r"^\-\s+-\s+step:\s+\S")
_MANIFEST_EDGE_REL = re.compile(r"(?:from_id|to_id)\s*:")


def git_diff_lines_for_file(project_root: Path, rel_path: str) -> list[str]:
    """Unified diff lines for ``rel_path`` vs index/HEAD (best effort)."""
    root = Path(project_root).resolve()
    rel = rel_path.replace("\\", "/")
    for spec in (
        ["git", "diff", "--", rel],
        ["git", "diff", "HEAD", "--", rel],
    ):
        try:
            proc = subprocess.run(
                spec,
                cwd=str(root),
                capture_output=True,
                text=True,
                timeout=120,
                check=False,
            )
            if proc.returncode == 0 and proc.stdout.strip():
                return proc.stdout.splitlines()
        except (OSError, subprocess.TimeoutExpired):
            continue
    return []


def _norm_path(file: str) -> str:
    return file.replace("\\", "/")


def _has_removal_lines(diff_lines: list[str]) -> bool:
    return any(
        line.startswith("-") and not line.startswith("---") for line in diff_lines
    )


def _probable_model_field_line(line: str, prefix: str) -> bool:
    if not line.startswith(prefix):
        return False
    body = line[1:].lstrip()
    if body.startswith(("class ", "def ", "@", "#", '"', "'")):
        return False
    if ":" not in body or "register_error(" in line:
        return False
    head = body.split(":", 1)[0].strip()
    return bool(head) and head[0].isalpha()


def consumers_of_schema_path(graph: ManifestGraph, schema_rel_path: str) -> list[str]:
    """Manifest node ids that declare an ``imports`` edge to the schema module."""
    nid = find_node_id_for_path(graph, _norm_path(schema_rel_path))
    if not nid:
        return []
    out: list[str] = []
    for e in graph.edges_to(nid):
        if e.relation == "imports":
            out.append(e.from_id)
    return sorted(set(out))


def tools_declared_in_diff(diff_lines: list[str]) -> set[str]:
    names: set[str] = set()
    for line in diff_lines:
        if not line or line[0] not in "+-":
            continue
        rest = line[1:]
        m = re.match(r"\s*(?:async\s+)?def\s+(forge_\w+)\s*\(", rest)
        if m:
            names.add(m.group(1))
    return names


def pipeline_nodes_referencing_tools(
    project_root: Path,
    graph: ManifestGraph,
    tool_names: set[str],
) -> list[str]:
    """Pipeline descriptor nodes whose YAML references any of ``tool_names``."""
    if not tool_names:
        return []
    root = Path(project_root).resolve()
    out: list[str] = []
    for p in root.glob(".forge/pipelines/**/*.yaml"):
        if not p.is_file():
            continue
        try:
            text = p.read_text(encoding="utf-8")
        except OSError:
            continue
        if not any(t in text for t in tool_names):
            continue
        rel = str(p.relative_to(root)).replace("\\", "/")
        nid = find_node_id_for_path(graph, rel)
        if nid:
            out.append(nid)
    return sorted(set(out))


def _forge_contract_path(nf: str) -> bool:
    return (
        nf.startswith("forge/")
        or "/forge/" in nf
        or nf.startswith(".forge/")
        or ".forge/" in nf
        or nf.endswith(".pipeline.yaml")
        or nf.endswith("/manifest.yaml")
        or nf == "manifest.yaml"
    )


def _is_server_py(nf: str) -> bool:
    return nf.endswith("/mcp/server.py") or nf.endswith("forge/mcp/server.py")


def classify_change(
    file: str,
    diff_lines: list[str],
    manifest_graph: ManifestGraph,
    project_root: Path,
) -> list[ChangeEvent]:
    """Classify a unified diff into :class:`ChangeEvent` instances."""
    nf = _norm_path(file)
    events: list[ChangeEvent] = []

    def fallback_impact001() -> ChangeEvent:
        return ChangeEvent(
            file=file,
            change_class=ChangeClass.HANDLER_LOGIC_CHANGE,
            breaking=False,
            context={"impact_code": "IMPACT-001"},
        )

    # forge/core/schemas.py — Pydantic models + register_error
    if nf.endswith("forge/core/schemas.py") or nf.endswith("/core/schemas.py"):
        consumers = consumers_of_schema_path(manifest_graph, nf)
        reg_add = any(
            line.startswith("+") and "register_error(" in line for line in diff_lines
        )
        reg_rem = any(
            line.startswith("-") and "register_error(" in line for line in diff_lines
        )
        field_add = any(_probable_model_field_line(line, "+") for line in diff_lines)
        field_rem = any(_probable_model_field_line(line, "-") for line in diff_lines)
        if reg_add:
            events.append(
                ChangeEvent(
                    file=file,
                    change_class=ChangeClass.ERROR_CODE_ADD,
                    breaking=False,
                )
            )
        if reg_rem:
            events.append(
                ChangeEvent(
                    file=file,
                    change_class=ChangeClass.ERROR_CODE_REMOVE,
                    breaking=True,
                    affected_node_ids=[],
                )
            )
        if field_add:
            events.append(
                ChangeEvent(
                    file=file,
                    change_class=ChangeClass.SCHEMA_FIELD_ADD,
                    breaking=False,
                    affected_node_ids=list(consumers),
                )
            )
        if field_rem:
            events.append(
                ChangeEvent(
                    file=file,
                    change_class=ChangeClass.SCHEMA_FIELD_REMOVE,
                    breaking=True,
                    affected_node_ids=list(consumers),
                )
            )
        if not events:
            events.append(fallback_impact001())
        return events

    # MCP tools — signature / exports
    if nf.endswith("forge/mcp/tools.py") or nf.endswith("/mcp/tools.py"):
        tools = tools_declared_in_diff(diff_lines)
        affected = pipeline_nodes_referencing_tools(
            project_root, manifest_graph, tools
        )
        events.append(
            ChangeEvent(
                file=file,
                change_class=ChangeClass.TOOL_SIGNATURE_CHANGE,
                affected_node_ids=affected,
                breaking=_has_removal_lines(diff_lines),
            )
        )
        return events

    # Pipeline descriptors
    if ".pipeline.yaml" in nf:
        for line in diff_lines:
            if _PIPELINE_STEP_ADD.search(line):
                events.append(
                    ChangeEvent(
                        file=file,
                        change_class=ChangeClass.PIPELINE_STEP_ADD,
                        breaking=False,
                    )
                )
            if _PIPELINE_STEP_REM.search(line):
                events.append(
                    ChangeEvent(
                        file=file,
                        change_class=ChangeClass.PIPELINE_STEP_REMOVE,
                        breaking=True,
                    )
                )
            if "input_map" in line and line.startswith(("+", "-")):
                events.append(
                    ChangeEvent(
                        file=file,
                        change_class=ChangeClass.PIPELINE_STEP_INPUT_MAP_CHANGE,
                        breaking=line.startswith("-"),
                    )
                )
        if not events:
            events.append(fallback_impact001())
        return events

    # Manifest (typed/sliced YAML)
    if nf.endswith("/manifest.yaml") or nf.endswith(".forge/manifest.yaml"):
        for line in diff_lines:
            if line.startswith("+") and "id:" in line:
                events.append(
                    ChangeEvent(
                        file=file,
                        change_class=ChangeClass.MANIFEST_NODE_ADD,
                        breaking=False,
                    )
                )
            elif line.startswith("-") and "id:" in line:
                events.append(
                    ChangeEvent(
                        file=file,
                        change_class=ChangeClass.MANIFEST_NODE_REMOVE,
                        breaking=True,
                        affected_node_ids=[],
                    )
                )
            elif _MANIFEST_EDGE_REL.search(line) and line.startswith(
                ("+", "-")
            ):
                if line.startswith("+"):
                    events.append(
                        ChangeEvent(
                            file=file,
                            change_class=ChangeClass.MANIFEST_EDGE_ADD,
                            breaking=False,
                        )
                    )
                else:
                    events.append(
                        ChangeEvent(
                            file=file,
                            change_class=ChangeClass.MANIFEST_EDGE_REMOVE,
                            breaking=True,
                            affected_node_ids=[],
                        )
                    )
        if not events:
            events.append(fallback_impact001())
        return events

    # fs_glove — structural manifest-adjacent surface (additive)
    if nf.endswith("fs_glove.py"):
        return [
            ChangeEvent(
                file=file,
                change_class=ChangeClass.MANIFEST_NODE_ADD,
                breaking=False,
            )
        ]

    # MCP server — forge:// resource URIs
    if _is_server_py(nf):
        uri_add = any(
            line.startswith("+") and "forge://" in line for line in diff_lines
        )
        uri_rem = any(
            line.startswith("-") and "forge://" in line for line in diff_lines
        )
        if uri_add:
            events.append(
                ChangeEvent(
                    file=file,
                    change_class=ChangeClass.RESOURCE_URI_ADD,
                    breaking=False,
                )
            )
        if uri_rem:
            events.append(
                ChangeEvent(
                    file=file,
                    change_class=ChangeClass.RESOURCE_URI_REMOVE,
                    breaking=True,
                    affected_node_ids=[],
                )
            )
        if not events:
            events.append(
                ChangeEvent(
                    file=file,
                    change_class=ChangeClass.HANDLER_LOGIC_CHANGE,
                    breaking=False,
                )
            )
        return events

    # Last resort: contract paths get an explicit IMPACT-001 advisory
    if _forge_contract_path(nf):
        return [fallback_impact001()]
    return []


_SILENT_ADDITIVE = frozenset(
    {
        ChangeClass.ERROR_CODE_ADD,
        ChangeClass.RESOURCE_URI_ADD,
        ChangeClass.PIPELINE_STEP_ADD,
        ChangeClass.MANIFEST_EDGE_ADD,
        ChangeClass.MANIFEST_NODE_ADD,
    }
)


def change_events_to_principle_results(
    events: list[ChangeEvent],
    *,
    changed_node_id: str,
    changed_display: str,
) -> list:
    """Convert classified events to :class:`~forge.tools.docs_audit.principles.PrincipleResult`."""
    from forge.tools.docs_audit.principles import PrincipleResult

    principle_name = "CHANGE_CLASS_PROPAGATION"
    out: list[PrincipleResult] = []

    for ev in events:
        meta: dict[str, object] = {
            "rule": principle_name,
            "change_class": ev.change_class.value,
            "breaking": ev.breaking,
            "file": ev.file,
            "affected_nodes": list(ev.affected_node_ids),
        }
        if ev.context:
            meta["context"] = dict(ev.context)

        if ev.change_class == ChangeClass.HANDLER_LOGIC_CHANGE:
            if (ev.context or {}).get("impact_code") == "IMPACT-001":
                out.append(
                    PrincipleResult(
                        principle=principle_name,
                        changed_node=changed_display,
                        affected_nodes=[changed_node_id],
                        severity="warn",
                        reason=f"Impact classifier fallback — IMPACT-001 ({ev.file})",
                        ring=2,
                        derived=True,
                        metadata=meta,
                    )
                )
            continue

        if ev.change_class in _SILENT_ADDITIVE:
            continue

        if ev.breaking:
            targets = ev.affected_node_ids or [changed_node_id]
            severity = "high"
        elif ev.affected_node_ids:
            targets = ev.affected_node_ids
            severity = "normal"
        else:
            continue

        out.append(
            PrincipleResult(
                principle=principle_name,
                changed_node=changed_display,
                affected_nodes=sorted(set(targets)),
                severity=severity,
                reason=f"{ev.change_class.value} ({ev.file})",
                ring=2,
                derived=True,
                metadata=meta,
            )
        )
    return out
