import copy
import logging
import os
import sys
from io import StringIO
from pathlib import Path
from typing import Any

import yaml
from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap

from forge.core.schemas import NodeStatus, NodeTier
from forge.core.result import ForgeResult
from forge.core.gloves import GLOVES  # noqa: F401
from forge.core.stack_profiles import get_stack_profile
from forge.core.migration import MigrationManager


logger = logging.getLogger(__name__)


_ROOT_MANIFEST_WARNING = "manifest.yaml found at root — expected .forge/manifest.yaml"

TIER_DEFAULTS_BY_KIND: dict[str, NodeTier] = {
    "module": NodeTier.WORKER,
    "schema": NodeTier.SCHEMA,
    "glove": NodeTier.GLOVE,
    "pipeline": NodeTier.PIPELINE,
    "gate": NodeTier.GATE,
    "registry": NodeTier.REGISTRY,
    "tool": NodeTier.SURFACE,
    "resource": NodeTier.SURFACE,
    "prompt": NodeTier.SURFACE,
}

TIER_OVERRIDES_BY_ID: dict[str, NodeTier] = {
    "module/mcp.server": NodeTier.SURFACE,
    "module/mcp.tools": NodeTier.SURFACE,
    "module/mcp.handlers": NodeTier.SURFACE,
    "module/mcp.prompts": NodeTier.SURFACE,
    "module/core.schemas": NodeTier.SCHEMA,
    "module/core.registry": NodeTier.REGISTRY,
    "module/mcp.registry": NodeTier.REGISTRY,
    "module/mcp.fs_glove": NodeTier.GLOVE,
    "module/core.gloves": NodeTier.GLOVE,
    "module/core.glove_mapper": NodeTier.GLOVE,
    "module/core.impact": NodeTier.WORKER,
    "module/core.scratch": NodeTier.WORKER,
}


def _slug_manifest_name(s: str) -> str:
    return (
        str(s)
        .strip()
        .lower()
        .replace(" ", "_")
        .replace("/", "_")
        .replace("\\", "_")
    )


def stable_module_node_id(row: dict[str, Any]) -> str:
    """Same identity rule as ``tools.manifest.graph`` module ingress."""
    decl_id = str(row.get("id") or "").strip()
    name = str(row.get("name") or row.get("id") or "module")
    node_kind = str(row.get("kind") or "module").strip() or "module"
    if decl_id and "/" in decl_id:
        return decl_id
    if node_kind == "domain":
        return f"domain/{_slug_manifest_name(name)}"
    return f"module/{_slug_manifest_name(name)}"


def infer_tier(node_id: str, node_kind: str) -> NodeTier:
    nid = (node_id or "").strip()
    if nid in TIER_OVERRIDES_BY_ID:
        return TIER_OVERRIDES_BY_ID[nid]
    slug = nid.split("/")[-1].lower() if nid else ""
    if slug.startswith("stack-schema-"):
        return NodeTier.SCHEMA
    k = (node_kind or "module").strip().lower()
    return TIER_DEFAULTS_BY_KIND.get(k, NodeTier.WORKER)


class ValidationError(ValueError):
    """Raised when manifest write requests violate stack schema constraints."""


def _manifest_yaml_rt() -> YAML:
    y = YAML(typ="rt")
    y.preserve_quotes = True
    return y


def _to_plain_yaml(obj: Any) -> Any:
    """Convert ruamel CommentedMap/Seq trees to plain dict/list for _normalise_section."""
    from ruamel.yaml.comments import CommentedMap, CommentedSeq

    if isinstance(obj, CommentedMap):
        return {str(k): _to_plain_yaml(v) for k, v in obj.items()}
    if isinstance(obj, CommentedSeq):
        return [_to_plain_yaml(x) for x in obj]
    if isinstance(obj, dict):
        return {str(k): _to_plain_yaml(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_to_plain_yaml(x) for x in obj]
    return obj


def _normalize_node_status_defaults(node_entry: dict[str, Any]) -> dict[str, Any]:
    status = node_entry.get("status")
    if not isinstance(status, dict):
        return node_entry
    status_model = NodeStatus.model_validate(status)
    merged = dict(node_entry)
    merged["status"] = status_model.model_dump()
    return merged


def manifest_candidates(project_root: Path) -> list[Path]:
    root = project_root.expanduser().resolve()
    return [
        root / ".forge" / "manifest.yaml",
        root / "manifest.yaml",
        root / "docs" / "manifest.yaml",
    ]


def resolve_manifest_path(
    project_root: Path,
    *,
    warn_on_root_fallback: bool = True,
) -> Path | None:
    root = project_root.expanduser().resolve()
    for candidate in manifest_candidates(root):
        if not candidate.is_file():
            continue
        if warn_on_root_fallback and candidate == (root / "manifest.yaml"):
            print(_ROOT_MANIFEST_WARNING, file=sys.stderr)
        return candidate
    return None


class ManifestParser:
    """
    Schema-version-aware YAML parser for manifest.yaml files.
    Returns structured dicts. Does not instantiate project objects.
    """

    SUPPORTED_VERSIONS = [1]
    VALID_TYPES = ["flutter", "web", "python", "unknown"]

    def __init__(self, path: Path) -> None:
        self.path = path

    def load_sidecar(self, kind: str) -> dict[str, Any] | None:
        """Delegates to SidecarLoader.load using this parser's manifest path."""
        from forge.core.manifest_sidecar import SidecarLoader

        return SidecarLoader.load(self.path, kind)

    @staticmethod
    def get_stack(data: dict[str, Any] | None) -> str:
        """Canonical tooling stack label from manifest YAML (any shape / partial ok).

        Resolution order:
        1. ``stack`` key at top level (string or dict), else ``project.stack`` / ``app.stack``
        2. Dict ``stack`` blocks (language/cli/frontend/flutter keys)
        3. Top-level ``type`` and legacy ``app.type`` / ``project`` hints (``framework``)
        """
        if not data or not isinstance(data, dict):
            return "unknown"

        def _norm_string(label: str) -> str:
            k = label.strip().lower()
            direct = {
                "python-cli": "python-cli",
                "flutter-app": "flutter-app",
                "web-react": "web-react",
                "web-next": "web-next",
                "astro": "astro",
            }
            if k in direct:
                return direct[k]
            if k in ("python", "py"):
                return "python-cli"
            if k in ("dart", "flutter", "flutter_app", "flutter-app"):
                return "flutter-app"
            if k in ("react", "web-react"):
                return "web-react"
            if k in ("next", "nextjs", "web-next"):
                return "web-next"
            return label.strip()

        def _raw_stack_field(m: dict[str, Any]) -> Any:
            top = m.get("stack")
            if isinstance(top, str) and top.strip():
                return top
            if isinstance(top, dict) and top:
                return top
            for key in ("project", "app"):
                block = m.get(key)
                if not isinstance(block, dict):
                    continue
                st = block.get("stack")
                if isinstance(st, str) and st.strip():
                    return st
                if isinstance(st, dict) and st:
                    return st
            return None

        stack = _raw_stack_field(data)

        if isinstance(stack, str) and stack.strip():
            return _norm_string(stack)

        if isinstance(stack, dict):
            cli = str(stack.get("cli") or "").strip().lower()
            lang = str(stack.get("language") or "").strip().lower()
            frontend = str(stack.get("frontend") or "").strip().lower()
            if cli == "python-cli" or lang == "python":
                return "python-cli"
            if frontend in ("react", "next", "nextjs") or "react" in frontend:
                return "web-next" if "next" in frontend or frontend in ("next", "nextjs") else "web-react"
            if lang in ("dart", "flutter") or "flutter" in stack:
                return "flutter-app"

        typ_raw = str(data.get("type") or "").strip()
        if typ_raw:
            normalized = _norm_string(typ_raw)
            if normalized in ("python-cli", "flutter-app", "web-react", "web-next", "astro"):
                return normalized
            typ = typ_raw.lower()
            if typ == "python" or typ == "py":
                return "python-cli"
            if typ == "flutter":
                return "flutter-app"
            if typ == "web":
                return "web-react"

        app = data.get("app") if isinstance(data.get("app"), dict) else {}
        project = data.get("project") if isinstance(data.get("project"), dict) else {}
        app_type = str(app.get("type") or "").strip().lower()
        for block in (project, app):
            fw = str(block.get("framework") or "").strip().lower()
            if fw == "flutter":
                return "flutter-app"
        if "python" in app_type:
            return "python-cli"
        if "flutter" in app_type:
            return "flutter-app"
        if "react" in app_type:
            return "web-react"
        return "unknown"

    def parse(self, *, strict: bool = False, allow_migration: bool = True) -> ForgeResult[dict]:
        if not self.path.exists():
            return ForgeResult.failure(f"Manifest not found: {self.path}")
        try:
            text = self.path.read_text()
        except OSError as e:
            return ForgeResult.failure(f"Cannot read manifest: {e}")
        try:
            data = yaml.safe_load(text)
        except yaml.YAMLError as e:
            return ForgeResult.failure(f"Invalid YAML: {e}")
        if not isinstance(data, dict):
            return ForgeResult.failure("Manifest must be a YAML mapping")
        
        # Handle schema version and migration
        migration_manager = MigrationManager()
        current_version = data.get("schema_version", 0)
        
        # Check if migration is needed
        if allow_migration and migration_manager.get_required_migrations(current_version):
            migration_result = migration_manager.migrate_manifest(data)
            if not migration_result.ok:
                return migration_result
            data = migration_result.value
            current_version = data["schema_version"]
        
        # Validate schema version
        if current_version not in self.SUPPORTED_VERSIONS:
            return ForgeResult.failure(
                f"Unsupported schema_version: {current_version}. Supported: {self.SUPPORTED_VERSIONS}"
            )
        
        if current_version == 1:
            parsed = self._parse_v1(data)
            if not parsed.ok or not isinstance(parsed.value, dict):
                return parsed
            if strict:
                hard = [
                    t
                    for t in collect_stack_manifest_field_violations(parsed.value)
                    if t[0] != "schema_missing"
                ]
                if hard:
                    lines = "\n".join(f"  [{t[0]}] {t[1]}: {t[2]}" for t in hard)
                    raise ValidationError(f"Strict stack field validation failed:\n{lines}")
            return parsed
        return ForgeResult.failure(f"No parser for schema_version {current_version}")

    def _parse_v1(self, data: dict) -> ForgeResult[dict]:
        warnings: list[str] = []
        name = data.get("name")
        if not name or not isinstance(name, str):
            return ForgeResult.failure("Required field 'name' missing or invalid")
        type_str = data.get("type")
        if not type_str or not isinstance(type_str, str):
            return ForgeResult.failure("Required field 'type' missing or invalid")
        if type_str not in self.VALID_TYPES:
            warnings.append(f"Unknown type '{type_str}' — treated as unknown")
            type_str = "unknown"
            data["type"] = "unknown"
        if type_str == "flutter":
            warnings.extend(self._validate_flutter(data))
        elif type_str == "web":
            warnings.extend(self._validate_web(data))
        elif type_str == "python":
            warnings.extend(self._validate_python(data))
        result = dict(data)
        result["warnings"] = result.get("warnings", []) + warnings
        result["dashboard_checks"] = self._parse_dashboard_checks(data)
        # domain (two-axis classification — ADR-002)
        result["domain"] = data.get("domain", "")
        # app_config structure (extensible config sections — ADR-002)
        result["app_config"] = data.get("app_config", {})
        if "app_config" in result and isinstance(result["app_config"], dict):
            result["app_config"].setdefault("standard_sections", [])
            result["app_config"].setdefault("project_sections", [])
        # dependencies (cross-project error code tracking — ADR-002)
        result["dependencies"] = data.get("dependencies", {})
        if isinstance(result.get("dependencies"), dict):
            result["dependencies"].setdefault("forge_packages", [])
        return ForgeResult.success(result)

    @staticmethod
    def _flutter_stack_declared(data: dict) -> bool:
        """True when manifest stack blocks clearly identify a Flutter/Dart app.

        ``stack.flutter: true`` remains supported as a legacy hint but is **not**
        required when ``stack.language: dart`` or ``stack.framework: flutter`` is
        set (same signals :meth:`get_stack` already uses).
        """

        def _from_stack_block(block: Any) -> bool:
            if not isinstance(block, dict):
                return False
            if block.get("flutter") is True:
                return True
            lang = str(block.get("language") or "").strip().lower()
            fw = str(block.get("framework") or "").strip().lower()
            if lang == "dart":
                return True
            if fw == "flutter":
                return True
            return False

        top = data.get("stack")
        if _from_stack_block(top):
            return True
        for key in ("project", "app"):
            inner = data.get(key)
            if isinstance(inner, dict) and _from_stack_block(inner.get("stack")):
                return True
        return False

    def _validate_flutter(self, data: dict) -> list[str]:
        w: list[str] = []
        if "screens" not in data:
            w.append("flutter: missing 'screens'")
        if not self._flutter_stack_declared(data):
            w.append(
                "flutter: stack must declare dart/flutter (e.g. stack.language: dart, "
                "stack.framework: flutter, or legacy stack.flutter: true)"
            )
        if not data.get("domains"):
            w.append("flutter: no domains defined")
        if "error_codes" not in data and not data.get("error_codes"):
            w.append("flutter: no error_codes path")
        return w

    def _validate_web(self, data: dict) -> list[str]:
        prof = get_stack_profile(self.get_stack(data))
        mreq = getattr(prof, "manifest_required_sections", None)
        if mreq is not None and len(mreq) == 0:
            return []
        w: list[str] = []
        stack = data.get("stack")
        if not isinstance(stack, dict) or "frontend" not in stack:
            w.append("web: stack must contain 'frontend'")
        if not data.get("screens"):
            w.append("web: no screens defined")
        if not data.get("services"):
            w.append("web: no services defined")
        return w

    def _validate_python(self, data: dict) -> list[str]:
        return []

    def _parse_dashboard_checks(self, data: dict) -> list[dict]:
        raw = data.get("dashboard")
        if raw is None:
            return []
        if not isinstance(raw, list):
            return []
        out: list[dict] = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            label = item.get("label")
            check = item.get("check")
            type_str = item.get("type")
            if label is None or check is None or type_str is None:
                continue
            out.append({
                "label": str(label),
                "check": str(check),
                "type": str(type_str),
                "description": str(item.get("description", "")),
                "plugin": str(item.get("plugin", "")),
            })
        return out

    def _normalise_section(
        self,
        raw_section: list | dict | None,
        section_name: str,
        warnings: list[str],
    ) -> list[dict]:
        """
        Format A (Pixionary/denv): dict keyed by name
          { "login": { "file": "lib/.../login_screen.dart", ... } }
        Format B (forge standard): list of dicts
          [ { "path": "lib/.../login_screen.dart", ... } ]
        Always returns list[dict]. Appends warnings on issues.
        """
        if raw_section is None:
            return []

        if isinstance(raw_section, list):
            normalised = []
            for idx, entry in enumerate(raw_section):
                if not isinstance(entry, dict):
                    warnings.append(
                        f"[{section_name}] entry {idx} is not a "
                        f"mapping (got {type(entry).__name__})"
                    )
                    continue
                normalised.append(entry)
            return normalised

        if isinstance(raw_section, dict):
            normalised = []
            for name, entry in raw_section.items():
                if not isinstance(entry, dict):
                    warnings.append(
                        f"[{section_name}] entry '{name}' is not a "
                        f"mapping (got {type(entry).__name__})"
                    )
                    continue
                e = dict(entry)
                # file → path
                if "path" not in e and "file" in e:
                    e["path"] = e.pop("file")
                # notes → role (keep notes too)
                if "role" not in e and "notes" in e:
                    e["role"] = e["notes"]
                # owns → writes
                if "owns" in e and "writes" not in e:
                    e["writes"] = e.pop("owns")
                # key as path fallback
                if not e.get("path"):
                    e["path"] = name
                # store dict key as _name
                e.setdefault("_name", name)
                normalised.append(e)
            return normalised

        warnings.append(
            f"Section '{section_name}' is "
            f"{type(raw_section).__name__}, expected list or dict"
        )
        return []

    def _assert_section_valid_for_stack(
        self,
        section: str,
        manifest: dict[str, Any],
        node_entry: dict[str, Any] | None = None,
    ) -> None:
        # Canonical write-boundary guard: every manifest writer routes through this.
        label = ManifestParser.get_stack(manifest)
        stem = get_stack_profile(label).schema_stem
        if stem is None:
            return

        schema_path = Path(__file__).resolve().parents[2] / "schemas" / "stacks" / f"{stem}.yaml"
        if not schema_path.exists():
            return
        stack_schema = yaml.safe_load(schema_path.read_text(encoding="utf-8")) or {}
        allowed = set(stack_schema.get("allowed_sections") or [])
        if allowed and section not in allowed:
            raise ValidationError(
                f"Section '{section}' not valid for stack schema '{stem}'. "
                f"Check project_path."
            )
        if node_entry is not None and isinstance(node_entry, dict):
            allowed_fields = set(stack_schema.get("allowed_node_fields") or [])
            if allowed_fields:
                extra = sorted(k for k in node_entry.keys() if str(k) not in allowed_fields)
                if extra:
                    raise ValidationError(
                        f"Node fields {extra} not valid for stack schema '{stem}' "
                        f"in section '{section}'."
                    )

    def _load_mapping_for_write(self) -> ForgeResult[dict[str, Any]]:
        """Load a mutable manifest mapping for append/update. Prefers :class:`ManifestDocument`."""
        from forge.core.manifest_document import ManifestDocument, project_root_for_manifest_file

        if not self.path.exists():
            return ForgeResult.failure(f"Manifest not found: {self.path}")
        root = project_root_for_manifest_file(self.path)
        if root is not None:
            try:
                doc = ManifestDocument.from_path(root)
                if doc.path.resolve() == self.path.resolve():
                    return ForgeResult.success(copy.deepcopy(doc.to_legacy_dict()))
            except (FileNotFoundError, ValueError):
                pass
        parsed = self.parse()
        if parsed.ok and isinstance(parsed.value, dict):
            return ForgeResult.success(copy.deepcopy(parsed.value))
        try:
            text = self.path.read_text(encoding="utf-8")
        except OSError as e:
            return ForgeResult.failure(f"Cannot read manifest: {e}")
        try:
            raw_fallback: dict = yaml.safe_load(text) or {}
        except yaml.YAMLError as e:
            return ForgeResult.failure(parsed.error or f"Invalid YAML: {e}")
        if not isinstance(raw_fallback, dict):
            return ForgeResult.failure(parsed.error or "Manifest must be a YAML mapping")
        return ForgeResult.success(copy.deepcopy(raw_fallback))

    def _atomic_manifest_write(self, root_tree: Any) -> ForgeResult[None]:
        """Write YAML via ruamel round-trip to *tmp*, verify parse, then ``os.replace``."""
        tmp = self.path.with_name(f"{self.path.name}.tmp.{os.getpid()}")
        y = _manifest_yaml_rt()
        try:
            with tmp.open("w", encoding="utf-8") as fh:
                y.dump(root_tree, fh)
            chk = ManifestParser(tmp).parse()
            if not chk.ok:
                tmp.unlink(missing_ok=True)
                return ForgeResult.failure(chk.error or "manifest parse failed after write")
            os.replace(tmp, self.path)
        except OSError as e:
            tmp.unlink(missing_ok=True)
            return ForgeResult.failure(f"Cannot write manifest: {e}")
        return ForgeResult.success(None)

    def append_node(self, section: str, node_entry: dict) -> "ForgeResult":
        """
        Append node_entry to *section* in manifest.yaml.

        Uses _normalise_section() so Format-A (dict-keyed) and Format-B (list)
        manifests are handled identically to all other manifest reads.
        Reads the full file with ruamel (round-trip), mutates only *section*,
        writes atomically (tmp + ``os.replace``), then re-parses with
        :meth:`parse` to verify.
        """
        if not self.path.exists():
            return ForgeResult.failure(f"Manifest not found: {self.path}")
        try:
            text = self.path.read_text(encoding="utf-8")
        except OSError as e:
            return ForgeResult.failure(f"Cannot read manifest: {e}")
        y = _manifest_yaml_rt()
        try:
            data = y.load(StringIO(text))
        except Exception as e:
            return ForgeResult.failure(f"Invalid YAML: {e}")
        if data is None:
            data = CommentedMap()
        elif not isinstance(data, (dict, CommentedMap)):
            return ForgeResult.failure("Manifest root must be a YAML mapping")

        plain_for_guard = _to_plain_yaml(data) if isinstance(data, CommentedMap) else dict(data)
        if not isinstance(plain_for_guard, dict):
            return ForgeResult.failure("Manifest root must be a YAML mapping")
        normalized_node_entry = _normalize_node_status_defaults(dict(node_entry))
        if section == "modules" and "tier" not in normalized_node_entry:
            nid_t = stable_module_node_id(normalized_node_entry)
            kind_t = str(normalized_node_entry.get("kind") or "module").strip()
            normalized_node_entry["tier"] = infer_tier(nid_t, kind_t).value
        self._assert_section_valid_for_stack(section, plain_for_guard, node_entry=normalized_node_entry)

        warnings: list[str] = []
        sec_raw = plain_for_guard.get(section)
        items = self._normalise_section(sec_raw, section, warnings)
        node_id = str(normalized_node_entry.get("name") or normalized_node_entry.get("id") or "")
        if node_id and any(
            str(x.get("name") or x.get("id") or x.get("_name") or "") == node_id
            for x in items
            if isinstance(x, dict)
        ):
            return ForgeResult.success({"action": "skipped", "reason": "duplicate"})
        items.append(normalized_node_entry)
        data[section] = items
        wres = self._atomic_manifest_write(data)
        if not wres.ok:
            return ForgeResult.failure(wres.error or "write failed")
        return ForgeResult.success({"action": "appended", "section": section})

    def update_node(self, section: str, node_id: str, fields: dict) -> "ForgeResult":
        """
        Find the node with matching id/name in *section*, merge *fields* into it,
        and write back.

        Uses _normalise_section() for Format-A (dict-keyed) and Format-B (list)
        handling identical to all other manifest reads.
        Reads/writes via ruamel round-trip with atomic replace; verifies with
        :meth:`parse` after write.
        """
        if not self.path.exists():
            return ForgeResult.failure(f"Manifest not found: {self.path}")
        try:
            text = self.path.read_text(encoding="utf-8")
        except OSError as e:
            return ForgeResult.failure(f"Cannot read manifest: {e}")
        y = _manifest_yaml_rt()
        try:
            data = y.load(StringIO(text))
        except Exception as e:
            return ForgeResult.failure(f"Invalid YAML: {e}")
        if data is None:
            data = CommentedMap()
        elif not isinstance(data, (dict, CommentedMap)):
            return ForgeResult.failure("Manifest root must be a YAML mapping")

        plain_root = _to_plain_yaml(data)
        if not isinstance(plain_root, dict):
            return ForgeResult.failure("Manifest root must be a YAML mapping")
        warnings: list[str] = []
        items = self._normalise_section(plain_root.get(section), section, warnings)
        matched = False
        for item in items:
            if not isinstance(item, dict):
                continue
            item_id = str(
                item.get("name") or item.get("id") or item.get("_name") or ""
            )
            if item_id == node_id:
                updated = dict(item)
                updated.update(fields)
                if section == "modules":
                    nid_u = stable_module_node_id(updated)
                    kind_u = str(updated.get("kind") or "module").strip()
                    if not str(updated.get("tier") or "").strip():
                        updated["tier"] = infer_tier(nid_u, kind_u).value
                normalized = _normalize_node_status_defaults(updated)
                self._assert_section_valid_for_stack(section, plain_root, node_entry=normalized)
                item.clear()
                item.update(normalized)
                matched = True
                break
        if not matched:
            return ForgeResult.failure(
                f"Node '{node_id}' not found in section '{section}'"
            )
        data[section] = items
        wres = self._atomic_manifest_write(data)
        if not wres.ok:
            return ForgeResult.failure(wres.error or "write failed")
        if bool(fields.get("implemented", False)):
            try:
                from forge.tools.intent.runtime import deprecate_intents_for_target
                from forge.tools.manifest.graph import build_manifest_graph

                root = self.path.parent.parent if self.path.parent.name == ".forge" else self.path.parent
                g = build_manifest_graph(root)
                target_node_id = ""
                for n in g.nodes:
                    if str(n.name) == node_id or str(n.id) == node_id:
                        target_node_id = str(n.id)
                        break
                if target_node_id:
                    deprecate_intents_for_target(
                        root,
                        target_node_id,
                        condition="declaration node implemented:true",
                    )
            except Exception as exc:
                logger.warning(
                    "Intent deprecation trigger failed for node '%s': %s",
                    node_id,
                    exc,
                )
        return ForgeResult.success(
            {"action": "updated", "section": section, "node_id": node_id}
        )

    def backfill_node_tiers(self) -> ForgeResult[int]:
        """Set ``tier`` on every ``modules:`` row that is missing it (inferred). Returns count written."""
        if not self.path.exists():
            return ForgeResult.failure(f"Manifest not found: {self.path}")
        try:
            text = self.path.read_text(encoding="utf-8")
        except OSError as e:
            return ForgeResult.failure(f"Cannot read manifest: {e}")
        y = _manifest_yaml_rt()
        try:
            data = y.load(StringIO(text))
        except Exception as e:
            return ForgeResult.failure(f"Invalid YAML: {e}")
        if data is None:
            data = CommentedMap()
        elif not isinstance(data, (dict, CommentedMap)):
            return ForgeResult.failure("Manifest root must be a YAML mapping")

        mods = data.get("modules") if hasattr(data, "get") else None
        if not isinstance(mods, list):
            return ForgeResult.success(0)

        updated = 0
        for row in mods:
            if row is None or not hasattr(row, "keys"):
                continue
            if row.get("tier"):
                continue
            plain = dict(row)
            nid = stable_module_node_id(plain)
            kind = str(plain.get("kind") or "module").strip()
            row["tier"] = infer_tier(nid, kind).value
            updated += 1

        if updated == 0:
            return ForgeResult.success(0)

        wres = self._atomic_manifest_write(data)
        if not wres.ok:
            return ForgeResult.failure(wres.error or "write failed")
        logger.info("backfill_node_tiers: updated %s module rows in %s", updated, self.path)
        return ForgeResult.success(updated)


def _forbidden_fields_from_stack_schema(schema: dict[str, Any]) -> set[str]:
    raw = schema.get("forbidden_from_other_stacks")
    if isinstance(raw, list):
        return {str(x).strip() for x in raw if str(x).strip()}
    if isinstance(raw, dict):
        fields = raw.get("fields") or []
        return {str(x).strip() for x in fields if str(x).strip()}
    return set()


def collect_stack_manifest_field_violations(manifest: dict[str, Any]) -> list[tuple[str, str, str]]:
    """Audit manifest *modules* rows and top-level keys against the declared stack schema.

    Returns a list of ``(kind, node_ref, message)`` where *kind* is one of:

    - ``schema_missing`` — no stack YAML on disk for this project (cannot validate)
    - ``unknown_field`` — module field not listed in ``allowed_node_fields``
    - ``cross_stack`` — field forbidden as originating from another stack

    Cross-stack hits take precedence over unknown-field for the same key so callers
    surface the stronger diagnosis once.
    """
    label = ManifestParser.get_stack(manifest)
    profile = get_stack_profile(label)
    stem = getattr(profile, "schema_stem", None)
    if isinstance(stem, str) and stem.strip():
        project_stack = stem.strip().lower()
    else:
        project_stack = str(label or "").strip().lower() or "unknown"

    schema_path = Path(__file__).resolve().parents[2] / "schemas" / "stacks" / f"{project_stack}.yaml"
    if not schema_path.is_file():
        return [
            (
                "schema_missing",
                "manifest",
                f"No stack schema for '{project_stack}' — skipping stack field validation.",
            )
        ]

    try:
        schema = yaml.safe_load(schema_path.read_text(encoding="utf-8")) or {}
    except Exception:
        schema = {}
    if not isinstance(schema, dict):
        return []

    allowed_fields = {str(x) for x in (schema.get("allowed_node_fields") or []) if str(x).strip()}
    stacks_dir = Path(__file__).resolve().parents[2] / "schemas" / "stacks"
    forbidden_cross: set[str] = set()
    for p in sorted(stacks_dir.glob("*.yaml")):
        if p.name == "_template.yaml" or p.stem == project_stack:
            continue
        try:
            other = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        except Exception:
            continue
        if isinstance(other, dict):
            forbidden_cross.update(_forbidden_fields_from_stack_schema(other))

    out: list[tuple[str, str, str]] = []
    if not allowed_fields and not forbidden_cross:
        return out

    for mod in [m for m in (manifest.get("modules") or []) if isinstance(m, dict)]:
        node_ref = str(mod.get("id") or mod.get("name") or "unknown")
        for field in list(mod.keys()):
            if field in forbidden_cross:
                out.append(
                    (
                        "cross_stack",
                        node_ref,
                        f"Cross-stack field '{field}' found for stack '{project_stack}'",
                    )
                )
            elif allowed_fields and field not in allowed_fields:
                out.append(
                    (
                        "unknown_field",
                        node_ref,
                        f"Field '{field}' is not allowed for stack '{project_stack}'",
                    )
                )

    for field in list(manifest.keys()):
        if field in forbidden_cross:
            out.append(
                (
                    "cross_stack",
                    f"manifest:{field}",
                    f"Top-level cross-stack field '{field}' is invalid for stack '{project_stack}'",
                )
            )
    return out
