"""
forge/core/errors.py

Structured error intelligence for Forge MCP tools and CLI.
Every error Forge emits must have a code, a layer, and a hint.

Error code taxonomy:
  MCP-1xx  Transport / server errors
  MCP-2xx  Input contract violations
  MCP-3xx  Declaration graph errors
  MCP-4xx  Execution graph errors
  MCP-5xx  Contract graph errors
  MCP-6xx  Stack/provider errors
  MCP-9xx  Internal / unhandled errors

All codes are machine-readable. Agents use codes, not messages.
Messages are for humans. Hints are for agents.
"""

from __future__ import annotations

import copy
import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ErrorLayer(str, Enum):
    TRANSPORT = "transport"
    INPUT = "input"
    DECLARATION = "declaration"
    EXECUTION = "execution"
    CONTRACT = "contract"
    PROVIDER = "provider"
    INTERNAL = "internal"


@dataclass
class CausalHop:
    """One step in an error causal chain (root cause → error site)."""

    node_id: str
    edge_kind: str | None = None
    violation: str | None = None
    severity: str = "medium"

    def to_dict(self) -> dict[str, Any]:
        return {
            "node_id": self.node_id,
            "edge_kind": self.edge_kind,
            "violation": self.violation,
            "severity": self.severity,
        }


class ErrorCode(str, Enum):
    # Transport (1xx)
    SERVER_UNAVAILABLE = "MCP-101"
    TIMEOUT = "MCP-102"
    PROTOCOL_MISMATCH = "MCP-103"

    # Input (2xx)
    MISSING_PROJECT_PATH = "MCP-201"
    INVALID_ARGUMENT = "MCP-202"
    UNKNOWN_TOOL = "MCP-203"
    DRY_RUN_REQUIRED = "MCP-204"

    # Declaration (3xx)
    MANIFEST_NOT_FOUND = "MCP-301"
    NODE_NOT_FOUND = "MCP-302"
    EDGE_BROKEN = "MCP-303"
    DOMAIN_EMPTY = "MCP-304"
    MANIFEST_SCHEMA_INVALID = "MCP-305"
    NODE_PATH_MISSING = "MCP-306"

    # Execution (4xx)
    TRACE_NOT_FOUND = "MCP-401"
    SUBPROCESS_TIMEOUT = "MCP-402"
    SUBPROCESS_FAILED = "MCP-403"
    TRACE_ID_MISMATCH = "MCP-404"

    # Contract (5xx)
    GLOVE_NOT_FOUND = "MCP-501"
    CONTRACT_VIOLATED = "MCP-502"
    PROVIDER_MISMATCH = "MCP-503"
    TIER_VIOLATION = "MCP-504"

    # Provider (6xx)
    AUTH_PROVIDER_CHANGED = "MCP-601"
    DEPENDENCY_UNAVAILABLE = "MCP-602"

    # Internal (9xx)
    UNHANDLED_EXCEPTION = "MCP-901"
    HANDLER_NOT_FOUND = "MCP-902"
    SCHEMA_DRIFT = "MCP-903"

    # Composer (7xx)
    SLOT_VIOLATION = "COMPOSER-701"
    COMPONENT_NOT_ACCEPTED = "COMPOSER-702"
    SLOT_REQUIRED_EMPTY = "COMPOSER-703"
    BINDING_INVALID = "COMPOSER-704"
    LAYOUT_NOT_FOUND = "COMPOSER-705"


@dataclass
class ForgeError:
    code: ErrorCode
    layer: ErrorLayer
    message: str
    hint: str
    recoverable: bool = True
    context: dict[str, Any] = field(default_factory=dict)

    # Graph context — the atomic decomposition
    graph_nodes: list[str] = field(default_factory=list)
    affected_node_ids: list[str] = field(default_factory=list)
    source_node_id: str | None = None
    source_tool: str | None = None

    # Actionability
    suggested_commands: list[str] = field(default_factory=list)
    suggested_actions: list[str] = field(default_factory=list)

    # Debug
    debug: str | None = None

    # Backward compat aliases
    node_id: str | None = None
    dependency_ids: list[str] = field(default_factory=list)

    causal_chain: list[CausalHop] = field(default_factory=list)
    chain_ref: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code.value,
            "layer": self.layer.value,
            "message": self.message,
            "hint": self.hint,
            "recoverable": self.recoverable,
            "context": self.context,
            "graph_nodes": self.graph_nodes,
            "affected_node_ids": self.affected_node_ids,
            "source_node_id": self.source_node_id,
            "source_tool": self.source_tool,
            "suggested_commands": self.suggested_commands,
            "suggested_actions": self.suggested_actions,
            "node_id": self.node_id,
            "dependency_ids": self.dependency_ids,
            "debug": self.debug,
            "causal_chain": [h.to_dict() for h in self.causal_chain],
            "chain_ref": self.chain_ref,
        }

    def model_dump_json(self, indent: int | None = None) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    def with_graph_context(
        self,
        node_id: str,
        affected: list[str] | None = None,
        blast_radius: int | None = None,
        *,
        suggested_actions: list[str] | None = None,
        suggested_commands: list[str] | None = None,
    ) -> ForgeError:
        """Return a copy with graph context attached."""
        err = copy.deepcopy(self)
        err.source_node_id = node_id
        err.node_id = node_id
        if affected:
            err.affected_node_ids = list(affected)
            err.graph_nodes = list(affected)
        if blast_radius is not None and blast_radius > 5:
            err.hint = f"{err.hint} [blast radius: {blast_radius} nodes]"
        if suggested_actions is not None:
            err.suggested_actions = list(suggested_actions)
        if suggested_commands is not None:
            err.suggested_commands = list(suggested_commands)
        return err

    def with_causal_chain(
        self,
        chain: list[CausalHop],
        chain_ref: str | None = None,
    ) -> ForgeError:
        """Return copy with causal chain attached."""
        err = copy.deepcopy(self)
        err.causal_chain = list(chain)
        err.chain_ref = chain_ref
        if chain:
            root = chain[0].node_id
            if root and "(root cause:" not in err.hint:
                err.hint = f"{err.hint} (root cause: {root})"
        return err


def build_tier_violation_chain(
    from_node: str,
    to_node: str,
    from_tier: str,
    to_tier: str,
    edge_kind: str = "imports",
) -> list[CausalHop]:
    """Build causal chain for a tier import violation error."""
    return [
        CausalHop(
            node_id=from_node,
            edge_kind=edge_kind,
            violation=None,
            severity="info",
        ),
        CausalHop(
            node_id=to_node,
            edge_kind=edge_kind,
            violation=f"tier_violation: {from_tier}→{to_tier}",
            severity="high",
        ),
    ]


def build_drift_chain(
    node_id: str,
    drift_class: str,
    graph_a: str,
    graph_b: str,
) -> list[CausalHop]:
    """Build causal chain for a drift detection error."""
    return [
        CausalHop(
            node_id=node_id,
            edge_kind=None,
            violation=f"{drift_class}: {graph_a}↔{graph_b}",
            severity="medium",
        ),
    ]


ERRORS: dict[str, ForgeError] = {
    "no_project_path": ForgeError(
        code=ErrorCode.MISSING_PROJECT_PATH,
        layer=ErrorLayer.INPUT,
        message="project_path is required",
        hint="Pass project_path as an absolute path to your project root",
        recoverable=True,
        suggested_commands=["forge orient"],
    ),
    "manifest_not_found": ForgeError(
        code=ErrorCode.MANIFEST_NOT_FOUND,
        layer=ErrorLayer.DECLARATION,
        message="No .forge/manifest.yaml found at project path",
        hint="Run `forge init` to initialize Forge for this project",
        recoverable=True,
        suggested_commands=["forge init", "forge init --from-existing ."],
    ),
    "node_not_found": ForgeError(
        code=ErrorCode.NODE_NOT_FOUND,
        layer=ErrorLayer.DECLARATION,
        message="Manifest node not found",
        hint="Run `forge manifest format=full` to see all declared nodes",
        recoverable=True,
        suggested_commands=["forge manifest"],
    ),
    "edge_broken": ForgeError(
        code=ErrorCode.EDGE_BROKEN,
        layer=ErrorLayer.DECLARATION,
        message="Manifest edge is broken or missing an endpoint",
        hint="Run `forge verify --target parity` to list broken edges",
        recoverable=True,
        suggested_commands=["forge verify --target parity", "forge map"],
    ),
    "invalid_argument": ForgeError(
        code=ErrorCode.INVALID_ARGUMENT,
        layer=ErrorLayer.INPUT,
        message="Invalid or missing argument",
        hint="Check required fields and run forge_inspect to verify node IDs",
        recoverable=True,
        suggested_commands=["forge orient"],
    ),
    "subprocess_timeout": ForgeError(
        code=ErrorCode.SUBPROCESS_TIMEOUT,
        layer=ErrorLayer.EXECUTION,
        message="MCP subprocess timed out after 30s",
        hint="Run the equivalent CLI command directly to debug",
        recoverable=True,
        suggested_commands=["forge verify", "forge system health"],
    ),
    "trace_not_found": ForgeError(
        code=ErrorCode.TRACE_NOT_FOUND,
        layer=ErrorLayer.EXECUTION,
        message="No execution trace data found",
        hint="Run `forge trace` to capture execution data",
        recoverable=True,
        suggested_commands=["forge trace"],
    ),
    "dependency_unavailable": ForgeError(
        code=ErrorCode.DEPENDENCY_UNAVAILABLE,
        layer=ErrorLayer.EXECUTION,
        message="Required dependency is not available",
        hint="Install missing dependency or check Forge installation",
        recoverable=True,
        suggested_commands=["forge system health", "forge install"],
    ),
    "unhandled": ForgeError(
        code=ErrorCode.UNHANDLED_EXCEPTION,
        layer=ErrorLayer.INTERNAL,
        message="Unhandled internal error",
        hint="This is a Forge bug. Check forge system health for diagnostics",
        recoverable=False,
        suggested_commands=["forge system health", "forge orient"],
    ),
    "ERR-001": ForgeError(
        code=ErrorCode.UNHANDLED_EXCEPTION,
        layer=ErrorLayer.INTERNAL,
        message="Unhandled error",
        hint=(
            "This is a Forge bug. Run with FORGE_DEBUG=true for full traceback"
        ),
        recoverable=False,
        suggested_commands=["forge system health"],
    ),
    "ERR-002": ForgeError(
        code=ErrorCode.INVALID_ARGUMENT,
        layer=ErrorLayer.INPUT,
        message="Invalid or missing argument",
        hint="Check required fields and run forge_inspect to verify node IDs",
        recoverable=True,
        suggested_commands=["forge orient"],
    ),
    "drift_detected": ForgeError(
        code=ErrorCode.SCHEMA_DRIFT,
        layer=ErrorLayer.DECLARATION,
        message=(
            "Structural drift detected between declaration and execution graphs"
        ),
        hint=(
            "Run forge_inspect action=diff on affected node to see drift details"
        ),
        recoverable=True,
        suggested_commands=[
            "forge inspect --action diff",
            "forge verify --target parity",
        ],
    ),
    "ring_boundary_violation": ForgeError(
        code=ErrorCode.TIER_VIOLATION,
        layer=ErrorLayer.CONTRACT,
        message="Import crosses tier boundary",
        hint=(
            "Check ADR-017 for tier import rules. Use forge_impact_radius to see "
            "blast radius before restructuring"
        ),
        recoverable=True,
        suggested_commands=[
            "forge verify --target stack",
            "forge inspect <node> --action diff",
        ],
    ),
    "intent_undeclared": ForgeError(
        code=ErrorCode.NODE_NOT_FOUND,
        layer=ErrorLayer.DECLARATION,
        message="Node has no intent record — purpose is undeclared",
        hint=(
            "Add intent with forge_intent action=add for this node to improve "
            "IDR coverage"
        ),
        recoverable=True,
        suggested_commands=["forge intent add"],
        suggested_actions=["forge_intent"],
    ),
    "cursor_expired": ForgeError(
        code=ErrorCode.TRACE_NOT_FOUND,
        layer=ErrorLayer.EXECUTION,
        message="Cursor handle expired or not found",
        hint=(
            "Call forge_inspect action=node with the node_id to create a fresh cursor"
        ),
        recoverable=True,
        suggested_actions=["forge_inspect"],
    ),
    "glove_scan_not_implemented": ForgeError(
        code=ErrorCode.GLOVE_NOT_FOUND,
        layer=ErrorLayer.CONTRACT,
        message="Glove scan not implemented for this stack",
        hint=(
            "Use forge_discover for file-level discovery, or forge_manifest_append "
            "to declare nodes manually"
        ),
        recoverable=True,
        suggested_commands=["forge discover"],
        suggested_actions=["forge_discover", "forge_manifest_append"],
    ),
    "slot_violation": ForgeError(
        code=ErrorCode.SLOT_VIOLATION,
        layer=ErrorLayer.CONTRACT,
        message="Component does not satisfy slot contract",
        hint=(
            "Check slot accepted_kinds and "
            "component kind compatibility"
        ),
        recoverable=True,
        suggested_actions=[
            "forge_inspect",
            "check composer slot contracts",
        ],
    ),
    "slot_required_empty": ForgeError(
        code=ErrorCode.SLOT_REQUIRED_EMPTY,
        layer=ErrorLayer.CONTRACT,
        message="Required slot has no component bound",
        hint=(
            "This layout slot is required. "
            "Bind a compatible component."
        ),
        recoverable=True,
        suggested_actions=[
            "forge_inspect",
        ],
    ),
    "binding_invalid": ForgeError(
        code=ErrorCode.BINDING_INVALID,
        layer=ErrorLayer.CONTRACT,
        message="Slot binding failed validation",
        hint=(
            "Run forge_inspect on the layout node "
            "to see accepted component kinds"
        ),
        recoverable=True,
        suggested_actions=[
            "forge_inspect",
        ],
    ),
    "component_not_accepted": ForgeError(
        code=ErrorCode.COMPONENT_NOT_ACCEPTED,
        layer=ErrorLayer.CONTRACT,
        message="Component kind not accepted by slot",
        hint=(
            "Check SlotContract.accepted_kinds "
            "for this slot"
        ),
        recoverable=True,
        suggested_actions=["forge_inspect"],
    ),
    "layout_not_found": ForgeError(
        code=ErrorCode.LAYOUT_NOT_FOUND,
        layer=ErrorLayer.CONTRACT,
        message="Layout descriptor not found",
        hint=(
            "Run forge discover to find "
            "available layouts"
        ),
        recoverable=True,
        suggested_commands=["forge discover"],
    ),
}


def get_error(key: str) -> ForgeError:
    """Deep copy of a registered error (safe for per-call mutation)."""
    if key not in ERRORS:
        raise KeyError(f"Unknown error key: {key!r}")
    return copy.deepcopy(ERRORS[key])


def get_error_by_legacy_code(code: str) -> ForgeError | None:
    """Look up error by legacy ERR-NNN, CORE-NNN, or MCP key."""
    for key, err in ERRORS.items():
        if err.code.value == code or key == code:
            return get_error(key)
    return None


def to_mcp_error_result(error: ForgeError) -> dict[str, Any]:
    """Format error for MCP tool result. Agents read code + hint."""
    d = error.to_dict()
    d["ok"] = False
    return d
