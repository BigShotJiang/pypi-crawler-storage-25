"""
Stack-Agnostic Framework Mapper - Universal Framework Discovery System

Maps any existing framework (dimstack, etc.) to Forge execution graphs
regardless of language, stack, or architecture. Enables new user onboarding
by connecting existing repos to Forge-managed projects.
"""

from __future__ import annotations

import json
import subprocess
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Union
from uuid import uuid4

from forge.core.execution_graph import ExecutionGraph, ExecutionNode, ExecutionEdge


class StackType(Enum):
    """Supported framework stacks."""
    PYTHON = "python"
    JAVASCRIPT = "javascript"
    TYPESCRIPT = "typescript"
    JAVA = "java"
    RUST = "rust"
    GO = "go"
    CPP = "cpp"
    CSHARP = "csharp"
    RUBY = "ruby"
    UNKNOWN = "unknown"


class MappingStrategy(Enum):
    """Framework mapping strategies."""
    STATIC_ANALYSIS = "static_analysis"
    RUNTIME_TRACING = "runtime_tracing"
    HYBRID = "hybrid"
    DECLARATIVE = "declarative"
    CONFIG_DRIVEN = "config_driven"


@dataclass
class FrameworkNode:
    """Node in discovered framework structure."""
    id: str
    name: str
    type: str  # function, class, module, config, etc.
    file_path: str
    line_start: int
    line_end: int
    stack_type: StackType
    metadata: Dict[str, Any] = field(default_factory=dict)
    dependencies: Set[str] = field(default_factory=set)
    callers: Set[str] = field(default_factory=set)
    entry_points: Set[str] = field(default_factory=set)


@dataclass
class FrameworkEdge:
    """Edge in discovered framework structure."""
    id: str
    from_node: str
    to_node: str
    edge_type: str  # calls, imports, extends, implements, configures
    strength: float = 1.0  # Confidence/weight
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class FrameworkMap:
    """Complete framework mapping result."""
    framework_name: str
    framework_version: str
    stack_type: StackType
    mapping_strategy: MappingStrategy
    nodes: List[FrameworkNode]
    edges: List[FrameworkEdge]
    entry_points: List[str]
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)


class StackMapper(ABC):
    """Abstract base class for stack-specific mappers."""
    
    @abstractmethod
    def discover_structure(self, project_path: Path) -> FrameworkMap:
        """Discover framework structure."""
        pass
    
    @abstractmethod
    def trace_execution(self, entry_point: str, project_path: Path) -> FrameworkMap:
        """Trace execution from entry point."""
        pass
    
    @abstractmethod
    def get_stack_type(self) -> StackType:
        """Get the stack type this mapper handles."""
        pass


class PythonStackMapper(StackMapper):
    """Python-specific framework mapper."""
    
    def get_stack_type(self) -> StackType:
        return StackType.PYTHON
    
    def discover_structure(self, project_path: Path) -> FrameworkMap:
        """Discover Python framework structure using AST analysis."""
        import ast
        
        nodes = []
        edges = []
        
        # Find all Python files
        py_files = list(project_path.rglob("*.py"))
        
        for py_file in py_files:
            try:
                with open(py_file, 'r') as f:
                    content = f.read()
                
                tree = ast.parse(content)
                
                # Extract functions, classes, imports
                for node in ast.walk(tree):
                    if isinstance(node, ast.FunctionDef):
                        framework_node = FrameworkNode(
                            id=f"{py_file}:{node.lineno}:{node.name}",
                            name=node.name,
                            type="function",
                            file_path=str(py_file),
                            line_start=node.lineno,
                            line_end=node.end_lineno or node.lineno,
                            stack_type=StackType.PYTHON,
                            metadata={"args": [arg.arg for arg in node.args.args]}
                        )
                        nodes.append(framework_node)
                    
                    elif isinstance(node, ast.ClassDef):
                        framework_node = FrameworkNode(
                            id=f"{py_file}:{node.lineno}:{node.name}",
                            name=node.name,
                            type="class",
                            file_path=str(py_file),
                            line_start=node.lineno,
                            line_end=node.end_lineno or node.lineno,
                            stack_type=StackType.PYTHON,
                            metadata={"bases": [base.id for base in node.bases if isinstance(base, ast.Name)]}
                        )
                        nodes.append(framework_node)
                    
                    elif isinstance(node, ast.Import):
                        for alias in node.names:
                            # Create import edge
                            import_edge = FrameworkEdge(
                                id=f"import_{uuid4().hex[:8]}",
                                from_node=f"{py_file}:module",
                                to_node=alias.name,
                                edge_type="imports",
                                strength=0.8
                            )
                            edges.append(import_edge)
                    
                    elif isinstance(node, ast.ImportFrom):
                        if node.module:
                            for alias in node.names:
                                import_edge = FrameworkEdge(
                                    id=f"import_from_{uuid4().hex[:8]}",
                                    from_node=f"{py_file}:module",
                                    to_node=f"{node.module}.{alias.name}",
                                    edge_type="imports",
                                    strength=0.8
                                )
                                edges.append(import_edge)
            
            except Exception as e:
                print(f"Error parsing {py_file}: {e}")
                continue
        
        return FrameworkMap(
            framework_name="python_framework",
            framework_version="unknown",
            stack_type=StackType.PYTHON,
            mapping_strategy=MappingStrategy.STATIC_ANALYSIS,
            nodes=nodes,
            edges=edges,
            entry_points=self._find_entry_points(project_path)
        )
    
    def trace_execution(self, entry_point: str, project_path: Path) -> FrameworkMap:
        """Trace Python execution using existing forge trace system."""
        from forge.tools.trace_store import SafeTraceRunner, write_trace
        from forge.core.execution_graph import ExecutionGraph
        
        # Use existing SafeTraceRunner
        runner = SafeTraceRunner(
            timeout=60,
            no_subprocess=False,
            dry_call=False,
            mock_network=False,
            mock_fs_writes=True,
            auto_pythonpath=True,
            project_root=project_path
        )
        
        # Run the trace
        with runner._safety_context():
            try:
                # Import and run the entry point
                module_path, function_name = entry_point.rsplit(":", 1)
                import importlib
                module = importlib.import_module(module_path)
                func = getattr(module, function_name)
                
                # Execute with tracing
                result = func()
                
                # Convert execution trace to framework map
                return self._convert_execution_to_framework_map(project_path, entry_point)
                
            except Exception as e:
                print(f"Error tracing execution: {e}")
                return self.discover_structure(project_path)
    
    def _find_entry_points(self, project_path: Path) -> List[str]:
        """Find potential entry points in Python project."""
        entry_points = []
        
        # Look for main.py, __main__.py, etc.
        main_files = ["main.py", "__main__.py", "app.py", "run.py"]
        for main_file in main_files:
            if (project_path / main_file).exists():
                entry_points.append(f"{main_file}:main")
        
        # Look for setup.py or pyproject.toml entry points
        if (project_path / "pyproject.toml").exists():
            try:
                import tomllib
                with open(project_path / "pyproject.toml", "rb") as f:
                    data = tomllib.load(f)
                
                scripts = data.get("project", {}).get("scripts", {})
                for script_name, script_path in scripts.items():
                    entry_points.append(script_path)
            except:
                pass
        
        return entry_points
    
    def _convert_execution_to_framework_map(self, project_path: Path, entry_point: str) -> FrameworkMap:
        """Convert execution trace to framework map."""
        # This would integrate with the existing execution graph system
        # For now, fall back to static analysis
        return self.discover_structure(project_path)


class JavaScriptStackMapper(StackMapper):
    """JavaScript/TypeScript framework mapper."""
    
    def get_stack_type(self) -> StackType:
        return StackType.JAVASCRIPT
    
    def discover_structure(self, project_path: Path) -> FrameworkMap:
        """Discover JavaScript/TypeScript structure."""
        nodes = []
        edges = []
        
        # Find JS/TS files
        js_files = list(project_path.rglob("*.js")) + list(project_path.rglob("*.ts"))
        
        for js_file in js_files:
            try:
                with open(js_file, 'r') as f:
                    content = f.read()
                
                # Simple regex-based parsing (could use TypeScript compiler API)
                import re
                
                # Find functions
                func_pattern = r'(?:function\s+(\w+)|(\w+)\s*=\s*(?:function|\([^)]*\)\s*=>))'
                for match in re.finditer(func_pattern, content):
                    func_name = match.group(1) or match.group(2)
                    if func_name:
                        framework_node = FrameworkNode(
                            id=f"{js_file}:{match.start()}:func_{func_name}",
                            name=func_name,
                            type="function",
                            file_path=str(js_file),
                            line_start=content[:match.start()].count('\n') + 1,
                            line_end=content[:match.end()].count('\n') + 1,
                            stack_type=StackType.JAVASCRIPT
                        )
                        nodes.append(framework_node)
                
                # Find classes
                class_pattern = r'class\s+(\w+)'
                for match in re.finditer(class_pattern, content):
                    class_name = match.group(1)
                    framework_node = FrameworkNode(
                        id=f"{js_file}:{match.start()}:class_{class_name}",
                        name=class_name,
                        type="class",
                        file_path=str(js_file),
                        line_start=content[:match.start()].count('\n') + 1,
                        line_end=content[:match.end()].count('\n') + 1,
                        stack_type=StackType.JAVASCRIPT
                    )
                    nodes.append(framework_node)
                
                # Find imports/requires
                import_pattern = r'(?:import.*from\s+["\']([^"\']+)["\']|require\(["\']([^"\']+)["\'])'
                for match in re.finditer(import_pattern, content):
                    import_path = match.group(1) or match.group(2)
                    if import_path:
                        import_edge = FrameworkEdge(
                            id=f"import_{uuid4().hex[:8]}",
                            from_node=f"{js_file}:module",
                            to_node=import_path,
                            edge_type="imports",
                            strength=0.8
                        )
                        edges.append(import_edge)
            
            except Exception as e:
                print(f"Error parsing {js_file}: {e}")
                continue
        
        return FrameworkMap(
            framework_name="javascript_framework",
            framework_version="unknown",
            stack_type=StackType.JAVASCRIPT,
            mapping_strategy=MappingStrategy.STATIC_ANALYSIS,
            nodes=nodes,
            edges=edges,
            entry_points=self._find_entry_points(project_path)
        )
    
    def trace_execution(self, entry_point: str, project_path: Path) -> FrameworkMap:
        """Trace JavaScript execution (would need Node.js integration)."""
        # For now, fall back to static analysis
        return self.discover_structure(project_path)
    
    def _find_entry_points(self, project_path: Path) -> List[str]:
        """Find JavaScript entry points."""
        entry_points = []
        
        # Look for package.json
        if (project_path / "package.json").exists():
            try:
                with open(project_path / "package.json", 'r') as f:
                    package_data = json.load(f)
                
                main_script = package_data.get("main")
                if main_script:
                    entry_points.append(main_script)
                
                scripts = package_data.get("scripts", {})
                for script_name, script_cmd in scripts.items():
                    if script_name in ["start", "dev", "build"]:
                        entry_points.append(script_cmd)
            except:
                pass
        
        return entry_points


class FrameworkMapper:
    """Universal framework mapper - main orchestrator."""
    
    def __init__(self):
        self.mappers: Dict[StackType, StackMapper] = {
            StackType.PYTHON: PythonStackMapper(),
            StackType.JAVASCRIPT: JavaScriptStackMapper(),
        }
    
    def detect_stack_type(self, project_path: Path) -> StackType:
        """Detect the primary stack type of a project."""
        stack_indicators = {
            StackType.PYTHON: ["*.py", "requirements.txt", "pyproject.toml", "setup.py"],
            StackType.JAVASCRIPT: ["*.js", "*.ts", "package.json", "yarn.lock"],
            StackType.JAVA: ["*.java", "pom.xml", "build.gradle"],
            StackType.RUST: ["*.rs", "Cargo.toml"],
            StackType.GO: ["*.go", "go.mod"],
            StackType.CPP: ["*.cpp", "*.h", "CMakeLists.txt", "Makefile"],
        }
        
        stack_scores = {}
        for stack_type, indicators in stack_indicators.items():
            score = 0
            for indicator in indicators:
                if "*" in indicator:
                    # File pattern
                    pattern = indicator.replace("*", "*")
                    matches = list(project_path.rglob(pattern))
                    score += len(matches)
                else:
                    # Specific file
                    if (project_path / indicator).exists():
                        score += 10  # Higher weight for config files
            
            stack_scores[stack_type] = score
        
        # Return stack with highest score
        if max(stack_scores.values()) == 0:
            return StackType.UNKNOWN
        
        return max(stack_scores, key=stack_scores.get)
    
    def map_framework(self, project_path: Path, strategy: MappingStrategy = MappingStrategy.HYBRID) -> FrameworkMap:
        """Map a framework using the specified strategy."""
        stack_type = self.detect_stack_type(project_path)
        
        if stack_type == StackType.UNKNOWN:
            raise ValueError(f"Could not detect stack type for {project_path}")
        
        mapper = self.mappers.get(stack_type)
        if not mapper:
            raise ValueError(f"No mapper available for stack type: {stack_type}")
        
        if strategy == MappingStrategy.STATIC_ANALYSIS:
            return mapper.discover_structure(project_path)
        elif strategy == MappingStrategy.RUNTIME_TRACING:
            # Try to find entry points and trace
            entry_points = self._find_entry_points_for_stack(project_path, stack_type)
            if entry_points:
                return mapper.trace_execution(entry_points[0], project_path)
            else:
                # Fall back to static analysis
                return mapper.discover_structure(project_path)
        elif strategy == MappingStrategy.HYBRID:
            # Start with static analysis, then enhance with tracing if possible
            static_map = mapper.discover_structure(project_path)
            entry_points = self._find_entry_points_for_stack(project_path, stack_type)
            if entry_points:
                try:
                    traced_map = mapper.trace_execution(entry_points[0], project_path)
                    # Merge static and traced information
                    return self._merge_framework_maps(static_map, traced_map)
                except:
                    pass
            return static_map
        
        raise ValueError(f"Unsupported mapping strategy: {strategy}")
    
    def _find_entry_points_for_stack(self, project_path: Path, stack_type: StackType) -> List[str]:
        """Find entry points for a specific stack."""
        mapper = self.mappers.get(stack_type)
        if mapper and hasattr(mapper, '_find_entry_points'):
            return mapper._find_entry_points(project_path)
        return []
    
    def _merge_framework_maps(self, static_map: FrameworkMap, traced_map: FrameworkMap) -> FrameworkMap:
        """Merge static analysis and runtime tracing results."""
        # Combine nodes from both maps
        all_nodes = static_map.nodes + traced_map.nodes
        
        # Combine edges, preferring traced edges for accuracy
        all_edges = traced_map.edges + [e for e in static_map.edges if e.id not in {te.id for te in traced_map.edges}]
        
        # Merge entry points
        all_entry_points = list(set(static_map.entry_points + traced_map.entry_points))
        
        return FrameworkMap(
            framework_name=static_map.framework_name,
            framework_version=static_map.framework_version,
            stack_type=static_map.stack_type,
            mapping_strategy=MappingStrategy.HYBRID,
            nodes=all_nodes,
            edges=all_edges,
            entry_points=all_entry_points,
            metadata={**static_map.metadata, **traced_map.metadata, "merged": True}
        )
    
    def convert_to_execution_graph(self, framework_map: FrameworkMap) -> ExecutionGraph:
        """Convert framework map to Forge execution graph."""
        graph = ExecutionGraph()
        
        # Convert nodes
        for fw_node in framework_map.nodes:
            exec_node = ExecutionNode(
                id=fw_node.id,
                kind=fw_node.type,
                module=Path(fw_node.file_path).stem,
                qualname=fw_node.name,
                file=fw_node.file_path,
                line=fw_node.line_start,
                stack=fw_node.stack_type.value,
                layer="framework"
            )
            graph.nodes[exec_node.id] = exec_node
        
        # Convert edges
        for fw_edge in framework_map.edges:
            exec_edge = ExecutionEdge(
                id=fw_edge.id,
                from_id=fw_edge.from_node,
                to_id=fw_edge.to_node,
                edge_kind=fw_edge.edge_type,
                layer="framework"
            )
            graph.edges[exec_edge.id] = exec_edge
        
        return graph
