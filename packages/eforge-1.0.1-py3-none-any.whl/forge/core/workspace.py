from pathlib import Path

import yaml


def _normalized_path(path: str) -> str:
    return str(Path(path).expanduser().resolve())


def _workspace_path() -> Path:
    # Resolve on each call so tests/environment overrides of HOME are honored.
    return Path("~/.forge/workspace.yaml").expanduser()


def load_workspace() -> dict:
    workspace_path = _workspace_path()
    if not workspace_path.exists():
        return {"projects": []}
    with open(workspace_path) as f:
        # C006-OK: non-manifest YAML (~/.forge/workspace.yaml), direct load is correct.
        raw = yaml.safe_load(f) or {"projects": []}
    if not isinstance(raw, dict):
        return {"projects": []}
    return raw


def _projects_as_list(ws: dict) -> list[dict]:
    projects = ws.get("projects", [])
    if isinstance(projects, list):
        return [p for p in projects if isinstance(p, dict)]
    if isinstance(projects, dict):
        out: list[dict] = []
        for name, entry in projects.items():
            if not isinstance(entry, dict):
                continue
            row = dict(entry)
            row.setdefault("name", str(name))
            out.append(row)
        return out
    return []


def get_project(name: str) -> dict | None:
    ws = load_workspace()
    return next((p for p in _projects_as_list(ws) if p.get("name") == name), None)


def list_projects() -> list[dict]:
    return _projects_as_list(load_workspace())


def add_project(
    name: str, path: str, stack: str, manifest: str | None = None
) -> None:
    ws = load_workspace()
    rows = _projects_as_list(ws)
    normalized = _normalized_path(path)
    next_row = {"name": name, "path": normalized, "manifest": manifest, "stack": stack}
    replaced = False
    for idx, row in enumerate(rows):
        row_name = str(row.get("name") or "")
        row_path = _normalized_path(str(row.get("path") or ".")) if row.get("path") else ""
        if row_name == name or row_path == normalized:
            rows[idx] = next_row
            replaced = True
            break
    if not replaced:
        rows.append(next_row)
    ws["projects"] = rows
    workspace_path = _workspace_path()
    workspace_path.parent.mkdir(parents=True, exist_ok=True)
    with open(workspace_path, "w") as f:
        yaml.dump(ws, f, default_flow_style=False)


def remove_project(name: str) -> bool:
    ws = load_workspace()
    rows = _projects_as_list(ws)
    before = len(rows)
    ws["projects"] = [p for p in rows if p.get("name") != name]
    if len(ws["projects"]) < before:
        with open(_workspace_path(), "w") as f:
            yaml.dump(ws, f, default_flow_style=False)
        return True
    return False
