"""Forge workspace as first-class entity — Sprint 3 + Sprint 10 (ForgeProject + contracts).

``ForgeWorkspace`` is built from ``~/.forge/registry.yaml`` (delegates to ``WorkspaceStore`` / ``load_registry``)
or derived from ``WorkspaceGraph`` (``workspace.yaml``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, TYPE_CHECKING, cast

if TYPE_CHECKING:
    from forge.engine.registry import EntityRegistry


@dataclass
class ForgeProject:
    """Typed workspace project entry."""

    id: str
    path: Path
    workspace_id: str = ""
    manifest_path: Path | None = None
    phase: str = ""
    stack: str = ""
    health: dict[str, Any] = field(default_factory=dict)
    depends_on: list[str] = field(default_factory=list)
    exposes: tuple[str, ...] = ()
    requires: tuple[str, ...] = ()

    def entity_registry_view(self, workspace_registry: EntityRegistry) -> EntityRegistry:
        """Filtered :class:`~forge.engine.registry.EntityRegistry` — same backing graph subset."""
        from forge.engine.registry import EntityRegistry as ER

        return ER.filtered_view(workspace_registry, self.path)


ProjectInfo = ForgeProject


@dataclass(frozen=True)
class ContractDefinition:
    """Extensible semantic contract surfaced by one project and required by others."""

    id: str
    version: str
    interface: str  # references ``SchemaEntity.id`` semantics
    breaking_change_policy: str = "strict"


@dataclass
class ForgeWorkspace:
    """Aggregated workspace: typed projects + dependency edges + workspace contracts."""

    id: str
    root_path: Path
    projects: dict[str, ForgeProject]
    relations: dict[str, list[str]]
    health: dict[str, Any]
    registry: Any  # WorkspaceStore — avoids import cycle typing
    registry_path: Path | None = None
    workspace_yaml_path: Path | None = None
    contracts: dict[str, ContractDefinition] = field(default_factory=dict)

    def all_projects(self) -> list[ForgeProject]:
        return list(self.projects.values())

    def get_project(self, project_id: str) -> ForgeProject | None:
        return self.projects.get(project_id)

    def resolve_project(self, hint: str | None) -> Path | None:
        """Resolve slug, filesystem path substring, or None → single-project default."""
        if not self.projects:
            return None
        if hint is None or not str(hint).strip():
            if len(self.projects) == 1:
                return next(iter(self.projects.values())).path.expanduser().resolve()
            return None

        raw = str(hint).strip()
        path_hint = Path(raw).expanduser()
        if raw.startswith(("/", "~", ".")) or "/" in raw or raw.endswith((".yaml", ".yml")):
            try:
                resolved = path_hint.resolve()
            except Exception:
                resolved = path_hint
            for pi in self.projects.values():
                try:
                    pr = pi.path.expanduser().resolve()
                except Exception:
                    continue
                if pr == resolved or (resolved.exists() and pr == resolved):
                    return pr

        # Registry-backed slug resolution
        if self.registry_path and self.registry_path.is_file():
            from forge.tools.registry.store import get_project, load_registry, resolve_slug

            reg = load_registry(self.registry_path)
            sid = resolve_slug(raw, reg)
            if sid and sid in self.projects:
                return self.projects[sid].path.expanduser().resolve()
            row = get_project(raw, reg)
            if isinstance(row, dict):
                rid = str(row.get("id", "") or "").strip()
                if rid and rid in self.projects:
                    return self.projects[rid].path.expanduser().resolve()

        # Dict key exact / CI / prefix
        if raw in self.projects:
            return self.projects[raw].path.expanduser().resolve()
        rlow = raw.lower()
        for k, pi in self.projects.items():
            if k.lower() == rlow:
                return pi.path.expanduser().resolve()
        prefs = [k for k in self.projects if str(k).lower().startswith(rlow)]
        if len(prefs) == 1:
            return self.projects[prefs[0]].path.expanduser().resolve()

        # Path substring fallback
        rl = raw.lower().replace("\\", "/")
        for pi in self.projects.values():
            if rl in str(pi.path).lower():
                return pi.path.expanduser().resolve()

        return None

    @classmethod
    def from_registry(cls, registry_path: Path | None = None) -> ForgeWorkspace:
        """Hydrate from ``registry.yaml`` using existing ``WorkspaceStore`` / list_projects."""
        from forge.tools.registry.store import (
            WorkspaceStore,
            list_projects,
            load_registry,
            registry_path as default_registry_path,
        )

        rp = registry_path or default_registry_path()
        reg = load_registry(rp)
        store = WorkspaceStore()
        rows = list_projects(registry=reg)
        projects_map: dict[str, ForgeProject] = {}
        relations_map: dict[str, list[str]] = {}
        ws_id = "forge-registry"
        for row in rows:
            pid = str(row.get("id", "")).strip()
            if not pid:
                continue
            raw_p = row.get("path", "")
            pth = Path(str(raw_p)).expanduser() if raw_p else Path()
            try:
                pth = pth.resolve()
            except Exception:
                pass
            rel = row.get("relations") if isinstance(row.get("relations"), dict) else {}
            deps = [str(x) for x in (rel.get("depends_on") or []) if x is not None]
            mp_raw = row.get("manifest_path")
            manifest_p: Path | None
            if mp_raw:
                manifest_p = Path(str(mp_raw)).expanduser()
            else:
                manifest_p = pth / ".forge" / "manifest.yaml" if pth else None

            exp = row.get("exposes_contracts") or row.get("exposes") or []
            req = row.get("requires_contracts") or row.get("requires") or []
            exposes_t = tuple(sorted({str(x).strip() for x in exp if str(x).strip()}))
            requires_t = tuple(sorted({str(x).strip() for x in req if str(x).strip()}))

            projects_map[pid] = ForgeProject(
                id=pid,
                path=pth,
                workspace_id=ws_id,
                manifest_path=manifest_p,
                phase=str(row.get("phase") or ""),
                stack=str(row.get("stack") or ""),
                health={k: row[k] for k in ("status", "tags") if k in row},
                depends_on=deps,
                exposes=exposes_t,
                requires=requires_t,
            )
            relations_map[pid] = list(deps)

        contracts_map: dict[str, ContractDefinition] = {}
        raw_contracts = reg.get("contracts")
        if isinstance(raw_contracts, dict):
            for cid, blob in raw_contracts.items():
                if not isinstance(blob, dict):
                    continue
                key = str(cid).strip()
                if not key:
                    continue
                contracts_map[key] = ContractDefinition(
                    id=str(blob.get("id") or key),
                    version=str(blob.get("version") or ""),
                    interface=str(blob.get("interface") or ""),
                    breaking_change_policy=str(blob.get("breaking_change_policy") or "strict"),
                )

        dirs = sum(1 for pi in projects_map.values() if pi.path.is_dir())
        total = len(projects_map)
        if total == 0:
            st = "empty"
        elif dirs == total:
            st = "healthy"
        elif dirs > 0:
            st = "degraded"
        else:
            st = "degraded"

        health: dict[str, Any] = {
            "status": st,
            "registered": total,
            "paths_resolvable": dirs,
        }
        root = rp.parent
        return cls(
            id=ws_id,
            root_path=root,
            projects=projects_map,
            relations=relations_map,
            health=health,
            registry=store,
            registry_path=rp,
            workspace_yaml_path=None,
            contracts=contracts_map,
        )

    @classmethod
    def from_workspace_graph(
        cls,
        graph: Any,
        *,
        source_path: Path | None = None,
        registry: Any | None = None,
    ) -> ForgeWorkspace:
        """Build from an in-memory ``WorkspaceGraph`` (workspace.yaml path optional)."""
        from forge.tools.registry.store import WorkspaceStore
        from forge.workspace.graph import WorkspaceGraph

        if not isinstance(graph, WorkspaceGraph):
            raise TypeError(f"expected WorkspaceGraph, got {type(graph).__name__}")
        store = registry if registry is not None else WorkspaceStore()
        projects_map: dict[str, ForgeProject] = {}
        relations_map: dict[str, list[str]] = {}
        ws_id = "workspace-yaml"
        for p in sorted(graph.all_projects(), key=lambda x: x.id):
            mp = p.path / ".forge" / "manifest.yaml"
            projects_map[p.id] = ForgeProject(
                id=p.id,
                path=p.path,
                workspace_id=ws_id,
                manifest_path=mp,
                depends_on=list(p.depends_on),
            )
            relations_map[p.id] = list(p.depends_on)

        paths_ok = all(pi.path.is_dir() for pi in projects_map.values()) if projects_map else True
        deps_ok = all(
            all(d in projects_map for d in pi.depends_on) for pi in projects_map.values()
        )
        if not projects_map:
            st = "empty"
        elif paths_ok and deps_ok:
            st = "healthy"
        else:
            st = "warnings"
        health = {"status": st, "project_count": len(projects_map)}
        root = cast(Path, source_path).parent if source_path is not None else Path.home() / ".forge"
        return cls(
            id=ws_id,
            root_path=root,
            projects=projects_map,
            relations=relations_map,
            health=health,
            registry=store,
            registry_path=None,
            workspace_yaml_path=source_path,
            contracts={},
        )
