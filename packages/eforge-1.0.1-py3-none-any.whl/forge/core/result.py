from dataclasses import dataclass
from typing import Generic, TypeVar, Optional
import os
from ..constants.error_codes import ERROR_CODES, FORGE_ERROR_HINTS

T = TypeVar("T")


@dataclass
class ForgeResult(Generic[T]):
    ok: bool
    value: T | None
    error: str | None
    error_code: str | None = None
    hint: str | None = None
    debug_info: str | None = None

    @staticmethod
    def success(value: T) -> "ForgeResult[T]":
        return ForgeResult(ok=True, value=value, error=None)

    @staticmethod
    def failure(error: str, error_code: str | None = None, hint: str | None = None, debug_info: str | None = None) -> "ForgeResult[None]":
        # Auto-populate hint from error code if not provided
        if error_code and not hint:
            hint = ForgeResult.get_hint_for_error_code(error_code)
        
        return ForgeResult(ok=False, value=None, error=error, error_code=error_code, hint=hint, debug_info=debug_info)

    @staticmethod
    def from_error_code(error_code: str, debug_info: str | None = None) -> "ForgeResult[None]":
        """Create a failure result from an error code with auto-populated message and hint."""
        error_info = ForgeResult.get_error_info(error_code)
        return ForgeResult(
            ok=False,
            value=None,
            error=error_info["message"],
            error_code=error_code,
            hint=error_info["hint"],
            debug_info=debug_info
        )

    @staticmethod
    def get_error_info(error_code: str) -> dict:
        """Get error message and hint for an error code."""
        # Check special Forge error hints first
        if error_code in FORGE_ERROR_HINTS:
            return FORGE_ERROR_HINTS[error_code]
        
        # Check standard error codes
        if error_code in ERROR_CODES:
            return ERROR_CODES[error_code]
        
        # Fallback for unknown error codes
        return {
            "message": f"Unknown error code: {error_code}",
            "hint": "Run with --debug for more details or report this issue"
        }

    @staticmethod
    def get_hint_for_error_code(error_code: str) -> str | None:
        """Get hint for an error code."""
        error_info = ForgeResult.get_error_info(error_code)
        return error_info.get("hint")

    def is_debug_mode(self) -> bool:
        """Check if debug mode is enabled."""
        return os.getenv("FORGE_DEBUG", "false").lower() in ("true", "1", "yes")

    def get_user_message(self) -> str:
        """Get the user-friendly error message without debug info."""
        if self.ok:
            return "Success"
        
        message = self.error or "Unknown error"
        if self.error_code:
            message = f"[{self.error_code}] {message}"
        
        return message

    def get_full_message(self) -> str:
        """Get the full error message including debug info if available."""
        if self.ok:
            return "Success"
        
        message = self.get_user_message()
        
        # Add hint if available
        if self.hint:
            message += f"\nHint: {self.hint}"
        
        # Add debug info if in debug mode
        if self.debug_info and self.is_debug_mode():
            message += f"\nDebug: {self.debug_info}"
        
        return message

    def to_dict(self, include_debug: bool = False) -> dict:
        """Convert result to dictionary for API responses."""
        result = {
            "ok": self.ok,
            "error": self.error,
            "error_code": self.error_code,
            "hint": self.hint
        }
        
        if self.ok and self.value is not None:
            result["value"] = self.value
        
        if include_debug and self.debug_info:
            result["debug_info"] = self.debug_info
        
        return result
