"""Editor resolution — FORGE_EDITOR with DENV_EDITOR fallback."""

import os
import shutil
import subprocess
from pathlib import Path


def _open_in_editor(path: Path) -> None:
    editors = [
        os.environ.get("FORGE_EDITOR"),
        os.environ.get("DENV_EDITOR"),  # denv compatibility
        "cursor",
        "code",
        "zed",
        "vim",
    ]
    for editor in editors:
        if editor and shutil.which(editor):
            subprocess.Popen([editor, str(path)])
            return
