"""Phase 8 — unified manifest graph query primitive (pure, graph-in / dict-out).

``tools.manifest.graph`` builds ``ManifestGraph``; this module is the only supported
read/query surface over that object for MCP ``forge_query``, blast-radius (Ring 2),
and (eventually) diff / manifest graph views.

Manifest shorthand ``forge_query(kind, where, reverse_of, via)`` maps to:

- ``kind``: node ``kind`` filter (substring / equality style matches
  ``run_manifest_graph_query`` — lowercased exact kind when non-empty).
- ``where``: mapping of optional string filters — ``domain``, ``name``, ``depends_on``,
  and for blast mode only ``change_kind`` (passed to ``ManifestGraph.blast_radius_ring2``).
- ``reverse_of``: manifest graph **node id** to centre a query on. When set **and**
  no structural node filters are active (no ``kind`` and no ``where`` domain/name/depends_on),
  selects **Ring-2 blast-radius** mode (same semantics as ``blast_radius_ring2``).
- ``via``: optional edge-relation filter for import-BFS mode; reserved — traversal
  still uses ``imports`` only until multi-relation BFS lands.

Additional parameters preserve the existing MCP contract: ``depth``, ``limit``,
``direction`` for filter + imports BFS mode (see ``tools.manifest.graph``).

``expand_relevant`` (opt-in): semantic outward traversal for planning — bounded,
cycle-safe, domain-aware (see :func:`expand_relevant`).
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, Mapping

from forge.core.criticality import criticality_label
from forge.core.schemas import NodeTier, tier_includes
from forge.tools.manifest.graph import (
    ManifestGraph,
    ManifestNode,
    effective_node_tier,
    run_manifest_graph_query_on_graph,
)
from forge.core.graph_scope import manifest_graph_scoped

if TYPE_CHECKING:
    from forge.core.query_index import QueryBackend

_IMPORTS_CONTRACT = frozenset({"imports", "contract"})
_DATA_KINDS = frozenset({"service", "model"})
_UI_KINDS = frozenset({"screen", "variant", "component"})


@dataclass(frozen=True)
class QueryResult:
    """Structured query output.

    ``operation`` distinguishes blast-radius bundles from filtered node lists.
    ``data`` always matches the legacy JSON-ready dict each surface expects today.
    """

    operation: Literal["filter", "blast_ring2"]
    data: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return dict(self.data)


def _has_structural_filters(
    kind: str,
    where: Mapping[str, Any],
    *,
    tier: str | None = None,
) -> bool:
    if (kind or "").strip():
        return True
    if (tier or "").strip():
        return True
    w = where or {}
    for key in ("domain", "name", "depends_on"):
        if str(w.get(key) or "").strip():
            return True
    return False


def _parse_node_tier_filter(raw: str | None) -> NodeTier | None:
    s = (raw or "").strip().lower()
    if not s:
        return None
    try:
        return NodeTier(s)
    except ValueError:
        return None


def _filter_dict_nodes_by_tier(nodes: list[Any], filter_tier: NodeTier | None) -> list[Any]:
    if filter_tier is None:
        return nodes
    out: list[Any] = []
    for n in nodes:
        if not isinstance(n, dict):
            continue
        raw = str(n.get("tier") or "worker").strip().lower()
        try:
            nt = NodeTier(raw)
        except ValueError:
            nt = NodeTier.WORKER
        if tier_includes(filter_tier, nt):
            out.append(n)
    return out


def _apply_tier_filter_payload(data: dict[str, Any], filter_tier: NodeTier | None) -> None:
    if filter_tier is None:
        return
    nodes = data.get("nodes")
    if not isinstance(nodes, list):
        return
    filtered = _filter_dict_nodes_by_tier(nodes, filter_tier)
    data["nodes"] = filtered
    data["count"] = len(filtered)
    filt = dict(data.get("filters") or {})
    filt["tier"] = filter_tier.value
    data["filters"] = filt


def _cap_primary_nodes(data: dict[str, Any], cap: int) -> None:
    """Trim filter-mode ``nodes`` after tier/include filters; ``cap`` is the user's ``limit``."""
    nodes = data.get("nodes")
    if not isinstance(nodes, list):
        return
    lim = max(1, int(cap))
    if len(nodes) > lim:
        data["nodes"] = nodes[:lim]
        data["count"] = len(data["nodes"])


def _normalize_via(via: str | tuple[str, ...] | None) -> tuple[str, ...]:
    if via is None:
        return ()
    if isinstance(via, tuple):
        return tuple(str(x).strip() for x in via if str(x).strip())
    s = str(via).strip()
    if not s:
        return ()
    return tuple(p.strip() for p in s.split("|") if p.strip())


def _imports_or_contract_between(graph: ManifestGraph, a: str, b: str) -> bool:
    for e in graph.edges:
        if e.relation not in _IMPORTS_CONTRACT:
            continue
        if (e.from_id == a and e.to_id == b) or (e.from_id == b and e.to_id == a):
            return True
    return False


def _neighbor_node_ids(graph: ManifestGraph, nid: str) -> set[str]:
    out: set[str] = set()
    for e in graph.edges_from(nid):
        out.add(e.to_id)
    for e in graph.edges_to(nid):
        out.add(e.from_id)
    return out


def _ui_leaf_blocks_expansion(node: ManifestNode, graph: ManifestGraph, by_id: dict[str, ManifestNode]) -> bool:
    """Pure UI subtree leaf: no outbound edge to a non-UI node — outbound expansion stops here."""
    if (node.kind or "").lower() not in _UI_KINDS:
        return False
    for e in graph.edges_from(node.id):
        t = by_id.get(e.to_id)
        if t is not None and (t.kind or "").lower() not in _UI_KINDS:
            return False
    return True


def _expand_candidate_ok(
    cand: ManifestNode,
    start_id: str,
    start_domain_upper: str,
    graph: ManifestGraph,
) -> bool:
    if _imports_or_contract_between(graph, cand.id, start_id):
        return True
    if (cand.kind or "").lower() in _DATA_KINDS:
        return True
    if start_domain_upper and (cand.domain or "").strip().upper() == start_domain_upper:
        return True
    return False


def _node_row(n: ManifestNode) -> dict[str, Any]:
    return {
        "id": n.id,
        "name": n.name,
        "kind": n.kind,
        "domain": n.domain,
        "path": n.path,
        "tier": effective_node_tier(n),
    }


def enrich_nodes_import_criticality(graph: ManifestGraph, nodes: list[Any] | None) -> None:
    """Attach ``tier``, ``inbound_weight``, and ``criticality`` to each node dict."""
    if not nodes:
        return
    by_id = {n.id: n for n in graph.nodes}
    for row in nodes:
        if not isinstance(row, dict):
            continue
        nid = str(row.get("id") or "")
        if not nid:
            continue
        n = by_id.get(nid)
        if n is not None:
            row["tier"] = effective_node_tier(n)
        w = sum(1 for e in graph.edges_to(nid) if e.relation == "imports")
        row["inbound_weight"] = w
        row["criticality"] = criticality_label(w)


def expand_relevant(
    graph: ManifestGraph,
    start_node_id: str,
    domain: str | None = None,
    *,
    max_hops: int = 3,
    max_nodes: int = 40,
) -> dict[str, Any]:
    """Semantic outward traversal from ``start_node_id`` (cycle-safe, bounded).

    Relevance (include a neighbor in the frontier):
    - same domain as the anchor domain (``domain`` or start node's domain), or
    - ``kind`` is ``service`` or ``model`` (data boundaries), or
    - a direct ``imports`` / ``contract`` edge connects the node to ``start_node_id``.

    Outbound expansion from ``screen`` / ``variant`` / ``component`` stops when that
    node is a UI leaf (only UI kinds downstream).

    Returns ``{"nodes": {id: row}, "warnings": [str, ...]}`` where ``row`` matches
    primary query node summaries (id, name, kind, domain, path). The anchor id is
    omitted from ``nodes``.
    """
    by_id = {n.id: n for n in graph.nodes}
    start = by_id.get(start_node_id)
    if not start:
        return {"nodes": {}, "warnings": ["start_not_found"]}

    dom = (domain or start.domain or "").strip().upper()
    warnings: list[str] = []
    out_nodes: dict[str, dict[str, Any]] = {}
    visited: set[str] = set()
    q: deque[tuple[str, int]] = deque([(start_node_id, 0)])

    while q:
        nid, hop = q.popleft()
        if nid in visited:
            continue
        if len(visited) >= max_nodes:
            warnings.append("expand_relevant truncated — max_nodes reached")
            break
        visited.add(nid)
        n = by_id.get(nid)
        if n is None:
            continue
        if nid != start_node_id:
            out_nodes[nid] = _node_row(n)
        if hop >= max_hops:
            continue
        if nid != start_node_id and _ui_leaf_blocks_expansion(n, graph, by_id):
            continue
        for nb in _neighbor_node_ids(graph, nid):
            if nb in visited:
                continue
            cand = by_id.get(nb)
            if cand is None:
                continue
            if not _expand_candidate_ok(cand, start_node_id, dom, graph):
                continue
            q.append((nb, hop + 1))

    return {"nodes": out_nodes, "warnings": warnings}


def _merge_expand_related(
    graph: ManifestGraph,
    payload: dict[str, Any],
    *,
    expand_domain: str | None,
    max_total: int,
) -> None:
    """Mutates *payload* with ``related`` and optional ``related_warnings``."""
    primaries = payload.get("nodes") or []
    if not isinstance(primaries, list):
        return
    primary_ids: set[str] = set()
    for row in primaries:
        if isinstance(row, dict) and row.get("id"):
            primary_ids.add(str(row["id"]))

    related: dict[str, dict[str, Any]] = {}
    rwarn: list[str] = []
    cap = max(1, int(max_total))

    for row in primaries:
        if not isinstance(row, dict):
            continue
        nid = str(row.get("id") or "").strip()
        if not nid:
            continue
        dom = (expand_domain or "").strip().upper() or None
        pack = expand_relevant(graph, nid, domain=dom, max_hops=3, max_nodes=max(10, cap + 5))
        for w in pack.get("warnings") or []:
            if w and w not in rwarn:
                rwarn.append(str(w))
        for kid, krow in (pack.get("nodes") or {}).items():
            if kid in primary_ids or kid in related:
                continue
            if len(primary_ids) + len(related) >= cap:
                msg = (
                    f"related truncated at {cap} nodes across primary + related "
                    "— use expand_domain to narrow scope"
                )
                if msg not in rwarn:
                    rwarn.append(msg)
                break
            related[kid] = krow
        if len(primary_ids) + len(related) >= cap:
            break

    if related:
        payload["related"] = related
    if rwarn:
        payload["related_warnings"] = rwarn


def forge_query(
    graph: ManifestGraph,
    *,
    kind: str = "",
    where: Mapping[str, Any] | None = None,
    reverse_of: str | None = None,
    via: str | tuple[str, ...] | None = None,
    depth: int = 1,
    limit: int = 50,
    direction: str = "both",
    sort_by: str | None = None,
    tier: str | None = None,
    backend: QueryBackend | None = None,
    _skip_accelerator: bool = False,
    expand_relevant: bool = False,
    expand_domain: str | None = None,
    expand_max_total: int = 30,
    project_root: Path | str | None = None,
    project_path: Path | str | None = None,
) -> QueryResult:
    """Run a manifest graph query over a pre-built ``ManifestGraph`` (no disk I/O).

    **Filter + imports BFS** (default): same behaviour as ``run_manifest_graph_query_on_graph``.

    **Blast Ring 2**: when ``reverse_of`` is a node id and structural filters are off,
    delegates to ``ManifestGraph.blast_radius_ring2`` and returns name lists compatible
    with the ``forge_blast_radius`` MCP handler.

    The ``via`` argument is accepted for API parity with the Phase 8 manifest; it is
    echoed under ``filters["via"]`` in filter mode and ignored for traversal until
    multi-relation expansion exists.

    ``backend``: optional ``QueryBackend`` accelerator (filter mode only). When
    absent, stale, or ``_skip_accelerator`` is true (used while building a SQLite
    snapshot), behaviour matches the pure graph path.

    ``expand_relevant``: when true (filter mode only), merge semantic neighbours into
    ``related`` capped by ``expand_max_total`` across primary + related.

    ``sort_by``: optional ``criticality`` | ``name`` | ``domain`` — applied before
    the result ``limit`` in filter mode (ordering only; ``inbound_weight`` / ``criticality``
    are always attached to each node row).

    ``tier``: optional :class:`~forge.core.schemas.NodeTier` label; matches that tier
    or any subtype (e.g. ``worker`` includes ``glove`` / ``gate``).

    ``project_root`` / ``project_path``: when set (workspace project path), restricts
    ``graph`` nodes/edges to filesystem paths rooted at that prefix before querying
    (Sprint 10). ``project_path`` is a preferred alias for MCP/engine parity.

    ``_skip_accelerator``: internal — when true, never consult ``backend`` (avoids
    recursion while ``SQLiteQueryBackend.build`` snapshots via ``forge_query``).
    """
    scope = project_path if project_path is not None else project_root
    if scope is not None:
        graph = manifest_graph_scoped(graph, Path(scope))

    where = dict(where or {})
    via_t = _normalize_via(via)
    sort_by_s = (sort_by or "").strip() or None
    tier_filter = _parse_node_tier_filter(tier)
    skip_backend = bool(_skip_accelerator or expand_relevant or tier_filter is not None)

    if reverse_of and not _has_structural_filters(kind, where, tier=tier):
        ck = str(where.get("change_kind") or "any").strip() or "any"
        br = graph.blast_radius_ring2(reverse_of, change_kind=ck)

        def _refs(nodes: list[ManifestNode]) -> list[dict[str, str]]:
            return [{"id": n.id, "name": n.name} for n in nodes]

        payload = {
            "watchers": _refs(br["watchers"]),
            "dependents": _refs(br["dependents"]),
            "siblings": _refs(br["siblings"]),
            "domain_members": _refs(br["domain_members"]),
            "parity_reachable": br.get("parity_reachable", {"count": 0, "nodes": [], "note": ""}),
            "reason": br["reason"],
            "change_kind": ck,
            "import_consumers": br.get("import_consumers", []),
            "contracts": br.get(
                "contracts", {"outbound": [], "inbound": [], "total": 0}
            ),
        }
        return QueryResult(operation="blast_ring2", data=payload)

    filt: dict[str, Any]
    if (
        not skip_backend
        and backend is not None
        and not via_t
    ):
        from forge.core.query_index import QueryBackend

        manifest_path = graph.project_path.expanduser().resolve() / ".forge" / "manifest.yaml"
        if isinstance(backend, QueryBackend) and backend.is_valid(manifest_path):
            sub = backend.query(
                {
                    "graph": graph,
                    "kind": kind,
                    "where": where,
                    "depth": depth,
                    "limit": limit,
                    "direction": direction,
                    "via": via_t,
                    "sort_by": sort_by_s,
                }
            )
            if sub is not None:
                filt = dict(sub.data)
                filters = dict(filt.get("filters") or {})
                if via_t:
                    filters["via"] = list(via_t)
                if sort_by_s:
                    filters["sort_by"] = sort_by_s.lower()
                filt["filters"] = filters
                enrich_nodes_import_criticality(graph, filt.get("nodes") if isinstance(filt.get("nodes"), list) else None)
                if expand_relevant:
                    dom_u = str(expand_domain).strip().upper() if expand_domain else None
                    _merge_expand_related(
                        graph,
                        filt,
                        expand_domain=dom_u,
                        max_total=int(expand_max_total) if expand_max_total else 30,
                    )
                _apply_tier_filter_payload(filt, tier_filter)
                if tier_filter is not None:
                    _cap_primary_nodes(filt, int(limit))
                return QueryResult(operation="filter", data=filt)

    # Tier filtering runs on node rows after the graph walk; a small pre-limit can drop
    # every candidate before tier includes are applied — gather broadly, then cap.
    pre_limit = int(limit)
    if tier_filter is not None:
        pre_limit = 10**9

    filt = run_manifest_graph_query_on_graph(
        graph,
        kind_filter=str(kind or ""),
        domain_filter=str(where.get("domain") or ""),
        name_filter=str(where.get("name") or ""),
        dep_filter=str(where.get("depends_on") or ""),
        limit=pre_limit,
        depth=int(depth),
        direction=str(direction or "both"),
        sort_by=sort_by_s,
    )
    out = dict(filt)
    filters = dict(out.get("filters") or {})
    if via_t:
        filters["via"] = list(via_t)
    if sort_by_s:
        filters.setdefault("sort_by", sort_by_s.lower())
    out["filters"] = filters
    enrich_nodes_import_criticality(graph, out.get("nodes") if isinstance(out.get("nodes"), list) else None)
    if expand_relevant:
        dom_u = str(expand_domain).strip().upper() if expand_domain else None
        _merge_expand_related(
            graph,
            out,
            expand_domain=dom_u,
            max_total=int(expand_max_total) if expand_max_total else 30,
        )
    _apply_tier_filter_payload(out, tier_filter)
    if tier_filter is not None:
        _cap_primary_nodes(out, int(limit))
    return QueryResult(operation="filter", data=out)
