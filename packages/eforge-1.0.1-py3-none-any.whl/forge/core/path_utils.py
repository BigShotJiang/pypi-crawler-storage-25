"""
forge.core.path_utils
Single choke point for project_path resolution.
Swap the resolver here when adding remote/cached hosting modes.

iter_files callers beyond report_cmd.py / gloves.py in this tree:
- forge/tools/scan/parsers/python_app.py
- forge/tools/scan/parsers/flutter.py
- forge/tools/scan/parsers/typescript.py
- forge/tools/scan/parsers/react_native.py
"""

import os
from pathlib import Path
from typing import Optional


def resolve_project_path(explicit: Optional[str] = None) -> Optional[Path]:
    """
    Resolve project_path for MCP tool calls.

    Priority order (INTENT-332931D8):
      1. Explicit value passed by caller (highest trust)
      2. Session roots from MCP initialize handshake
      3. CWD if it contains a .forge/manifest.yaml (direct project root)
      4. Walk CWD parents looking for .forge/manifest.yaml
      5. Look up CWD in workspace registry (legacy, deprecation warning)
      6. Return None — caller must handle missing project context

    This makes project_path optional for MCP calls invoked from within
    a project directory (e.g. Cursor, terminal, IDE).
    """
    if explicit:
        return Path(explicit).expanduser().resolve()

    # Priority 2: Session roots from MCP handshake (INTENT-332931D8)
    try:
        from forge.mcp.session_context import get_current_session
        
        session = get_current_session()
        if session:
            effective_path = session.get_effective_project_path()
            if effective_path:
                return effective_path
    except Exception:
        # Session context not available (stdio transport or import error)
        pass

    # Priority 3: CWD if it contains manifest
    cwd = Path(os.getcwd()).resolve()
    if (cwd / ".forge" / "manifest.yaml").exists():
        return cwd

    # Priority 4: Walk CWD parents looking for manifest
    check = cwd
    for _ in range(5):
        if (check / ".forge" / "manifest.yaml").exists():
            return check
        if check.parent == check:
            break
        check = check.parent

    # Priority 5: Workspace registry (legacy - INTENT-332931D8)
    try:
        from forge.tools.registry.store import WorkspaceStore

        store = WorkspaceStore()
        entry = store.find_by_path(str(cwd))
        if entry:
            # Issue deprecation warning for FORGE_WORKSPACE usage
            import warnings
            warnings.warn(
                "FORGE_WORKSPACE registry is deprecated. Use MCP Roots from handshake instead.",
                DeprecationWarning,
                stacklevel=2
            )
            return Path(entry["path"]).expanduser().resolve()
    except Exception:
        pass

    # Priority 6: No project context found
    return None
