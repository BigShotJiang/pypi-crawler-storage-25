"""Unified intent and annotation system for INTENT-08B9AEA4.

Unifies annotations (forge_annotate entries) and intent records at the query layer
so forge_intent query returns both annotation entries and intent records, filterable by type.
"""

import json
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from uuid import uuid4

from forge.core.path_utils import resolve_project_path

logger = logging.getLogger(__name__)


class UnifiedItemType(Enum):
    """Type of unified item."""
    INTENT = "intent"
    ANNOTATION = "annotation"


@dataclass
class UnifiedItem:
    """Unified representation of intent or annotation."""
    id: str
    item_type: UnifiedItemType
    title: str
    description: str
    content: str
    node_id: Optional[str] = None
    kind: Optional[str] = None
    severity: Optional[str] = None
    status: Optional[str] = None
    scope: Optional[str] = None
    target_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    updated_at: Optional[float] = None
    file_path: Optional[str] = None  # Source file path for annotations
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "item_type": self.item_type.value,
            "title": self.title,
            "description": self.description,
            "content": self.content,
            "node_id": self.node_id,
            "kind": self.kind,
            "severity": self.severity,
            "status": self.status,
            "scope": self.scope,
            "target_id": self.target_id,
            "metadata": self.metadata,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "file_path": self.file_path
        }


class UnifiedIntentQuery:
    """Unified query system for intents and annotations."""
    
    def __init__(self, project_path: Path):
        self.project_path = project_path
        self.intent_dir = project_path / ".forge" / "intent"
        self.annotations_dir = project_path / ".forge" / "annotations"
        
        # Ensure directories exist
        self.intent_dir.mkdir(parents=True, exist_ok=True)
        self.annotations_dir.mkdir(parents=True, exist_ok=True)
    
    def query(self, 
              item_type_filter: Optional[str] = None,
              node_id_filter: Optional[str] = None,
              kind_filter: Optional[str] = None,
              severity_filter: Optional[str] = None,
              status_filter: Optional[str] = None,
              scope_filter: Optional[str] = None,
              target_id_filter: Optional[str] = None,
              limit: int = 100,
              offset: int = 0) -> Dict[str, Any]:
        """Query unified intents and annotations with filters."""
        
        results = {
            "items": [],
            "total_count": 0,
            "filters_applied": {
                "item_type": item_type_filter,
                "node_id": node_id_filter,
                "kind": kind_filter,
                "severity": severity_filter,
                "status": status_filter,
                "scope": scope_filter,
                "target_id": target_id_filter
            },
            "limit": limit,
            "offset": offset
        }
        
        # Load intents
        intent_items = self._load_intents()
        
        # Load annotations
        annotation_items = self._load_annotations()
        
        # Combine all items
        all_items = intent_items + annotation_items
        
        # Apply filters
        filtered_items = self._apply_filters(
            all_items,
            item_type_filter,
            node_id_filter,
            kind_filter,
            severity_filter,
            status_filter,
            scope_filter,
            target_id_filter
        )
        
        # Sort by created_at (newest first)
        filtered_items.sort(key=lambda x: x.created_at, reverse=True)
        
        # Apply pagination
        total_count = len(filtered_items)
        paginated_items = filtered_items[offset:offset + limit]
        
        results["items"] = [item.to_dict() for item in paginated_items]
        results["total_count"] = total_count
        
        return results
    
    def _load_intents(self) -> List[UnifiedItem]:
        """Load intent records."""
        intents = []
        
        try:
            # Load intent files
            for intent_file in self.intent_dir.glob("**/*.yaml"):
                try:
                    import yaml
                    with open(intent_file, 'r') as f:
                        intent_data = yaml.safe_load(f) or {}
                    
                    # Convert to unified item
                    intent_item = UnifiedItem(
                        id=intent_data.get("id", ""),
                        item_type=UnifiedItemType.INTENT,
                        title=intent_data.get("id", ""),
                        description=intent_data.get("raw_description", ""),
                        content=intent_data.get("raw_description", ""),
                        node_id=intent_data.get("target_id"),
                        kind="intent",
                        severity=None,
                        status=intent_data.get("status"),
                        scope=intent_data.get("scope"),
                        target_id=intent_data.get("target_id"),
                        metadata={
                            "extracted_nodes": intent_data.get("extracted_nodes", []),
                            "source": intent_data.get("source"),
                            "deprecated_when": intent_data.get("deprecated_when")
                        },
                        created_at=self._parse_timestamp(intent_data.get("created_at")),
                        file_path=str(intent_file)
                    )
                    
                    intents.append(intent_item)
                    
                except Exception as e:
                    logger.warning(f"Failed to load intent from {intent_file}: {e}")
        
        except Exception as e:
            logger.error(f"Failed to load intents: {e}")
        
        return intents
    
    def _load_annotations(self) -> List[UnifiedItem]:
        """Load annotation records."""
        annotations = []
        
        try:
            # Load annotation index
            index_file = self.annotations_dir / "index.yaml"
            if not index_file.exists():
                return annotations
            
            import yaml
            with open(index_file, 'r') as f:
                index_data = yaml.safe_load(f) or {}
            
            # Process each annotation
            for annotation_id, annotation_data in index_data.items():
                try:
                    # Convert to unified item
                    annotation_item = UnifiedItem(
                        id=annotation_id,
                        item_type=UnifiedItemType.ANNOTATION,
                        title=annotation_data.get("title", f"Annotation {annotation_id}"),
                        description=annotation_data.get("note", ""),
                        content=annotation_data.get("note", ""),
                        node_id=annotation_data.get("node_id"),
                        kind=annotation_data.get("kind"),
                        severity=annotation_data.get("severity"),
                        status="active",  # Annotations don't have status, default to active
                        scope="node",  # Annotations are node-scoped
                        target_id=annotation_data.get("node_id"),
                        metadata={
                            "source": annotation_data.get("source"),
                            "metadata": annotation_data.get("metadata", {})
                        },
                        created_at=self._parse_timestamp(annotation_data.get("created_at")),
                        file_path=str(self.annotations_dir / f"{annotation_id}.annotation.yaml")
                    )
                    
                    annotations.append(annotation_item)
                    
                except Exception as e:
                    logger.warning(f"Failed to load annotation {annotation_id}: {e}")
        
        except Exception as e:
            logger.error(f"Failed to load annotations: {e}")
        
        return annotations
    
    def _apply_filters(self, 
                      items: List[UnifiedItem],
                      item_type_filter: Optional[str],
                      node_id_filter: Optional[str],
                      kind_filter: Optional[str],
                      severity_filter: Optional[str],
                      status_filter: Optional[str],
                      scope_filter: Optional[str],
                      target_id_filter: Optional[str]) -> List[UnifiedItem]:
        """Apply filters to items."""
        filtered = items
        
        if item_type_filter:
            try:
                item_type_enum = UnifiedItemType(item_type_filter)
                filtered = [item for item in filtered if item.item_type == item_type_enum]
            except ValueError:
                logger.warning(f"Invalid item_type filter: {item_type_filter}")
        
        if node_id_filter:
            filtered = [item for item in filtered if item.node_id == node_id_filter]
        
        if kind_filter:
            filtered = [item for item in filtered if item.kind == kind_filter]
        
        if severity_filter:
            filtered = [item for item in filtered if item.severity == severity_filter]
        
        if status_filter:
            filtered = [item for item in filtered if item.status == status_filter]
        
        if scope_filter:
            filtered = [item for item in filtered if item.scope == scope_filter]
        
        if target_id_filter:
            filtered = [item for item in filtered if item.target_id == target_id_filter]
        
        return filtered
    
    def _parse_timestamp(self, timestamp_str: Optional[str]) -> float:
        """Parse timestamp string to float."""
        if not timestamp_str:
            return time.time()
        
        try:
            # Try ISO format first
            if 'T' in timestamp_str:
                from datetime import datetime
                dt = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                return dt.timestamp()
            else:
                # Try as float
                return float(timestamp_str)
        except Exception:
            return time.time()
    
    def get_item(self, item_id: str) -> Optional[UnifiedItem]:
        """Get a specific item by ID."""
        # Search intents
        intent_file = self.intent_dir / f"{item_id}.yaml"
        if intent_file.exists():
            try:
                import yaml
                with open(intent_file, 'r') as f:
                    intent_data = yaml.safe_load(f) or {}
                
                return UnifiedItem(
                    id=intent_data.get("id", item_id),
                    item_type=UnifiedItemType.INTENT,
                    title=intent_data.get("id", item_id),
                    description=intent_data.get("raw_description", ""),
                    content=intent_data.get("raw_description", ""),
                    node_id=intent_data.get("target_id"),
                    kind="intent",
                    severity=None,
                    status=intent_data.get("status"),
                    scope=intent_data.get("scope"),
                    target_id=intent_data.get("target_id"),
                    metadata={
                        "extracted_nodes": intent_data.get("extracted_nodes", []),
                        "source": intent_data.get("source")
                    },
                    created_at=self._parse_timestamp(intent_data.get("created_at")),
                    file_path=str(intent_file)
                )
            except Exception as e:
                logger.error(f"Failed to load intent {item_id}: {e}")
        
        # Search annotations
        annotation_file = self.annotations_dir / f"{item_id}.annotation.yaml"
        if annotation_file.exists():
            try:
                import yaml
                with open(annotation_file, 'r') as f:
                    annotation_data = yaml.safe_load(f) or {}
                
                return UnifiedItem(
                    id=item_id,
                    item_type=UnifiedItemType.ANNOTATION,
                    title=annotation_data.get("title", f"Annotation {item_id}"),
                    description=annotation_data.get("note", ""),
                    content=annotation_data.get("note", ""),
                    node_id=annotation_data.get("node_id"),
                    kind=annotation_data.get("kind"),
                    severity=annotation_data.get("severity"),
                    status="active",
                    scope="node",
                    target_id=annotation_data.get("node_id"),
                    metadata={
                        "source": annotation_data.get("source"),
                        "metadata": annotation_data.get("metadata", {})
                    },
                    created_at=self._parse_timestamp(annotation_data.get("created_at")),
                    file_path=str(annotation_file)
                )
            except Exception as e:
                logger.error(f"Failed to load annotation {item_id}: {e}")
        
        return None
    
    def get_stats(self) -> Dict[str, Any]:
        """Get statistics about the unified system."""
        stats = {
            "total_items": 0,
            "item_type_counts": {},
            "kind_counts": {},
            "severity_counts": {},
            "status_counts": {},
            "scope_counts": {}
        }
        
        # Load all items
        intent_items = self._load_intents()
        annotation_items = self._load_annotations()
        all_items = intent_items + annotation_items
        
        stats["total_items"] = len(all_items)
        
        # Count by various dimensions
        for item in all_items:
            # Item type
            item_type = item.item_type.value
            stats["item_type_counts"][item_type] = stats["item_type_counts"].get(item_type, 0) + 1
            
            # Kind
            if item.kind:
                stats["kind_counts"][item.kind] = stats["kind_counts"].get(item.kind, 0) + 1
            
            # Severity
            if item.severity:
                stats["severity_counts"][item.severity] = stats["severity_counts"].get(item.severity, 0) + 1
            
            # Status
            if item.status:
                stats["status_counts"][item.status] = stats["status_counts"].get(item.status, 0) + 1
            
            # Scope
            if item.scope:
                stats["scope_counts"][item.scope] = stats["scope_counts"].get(item.scope, 0) + 1
        
        return stats


# Global query instances
_query_instances: Dict[str, UnifiedIntentQuery] = {}


def get_unified_query(project_path: Path) -> UnifiedIntentQuery:
    """Get or create a unified query instance for a project."""
    project_key = str(project_path.resolve())
    if project_key not in _query_instances:
        _query_instances[project_key] = UnifiedIntentQuery(project_path)
    return _query_instances[project_key]


def query_unified_intents(item_type_filter: Optional[str] = None,
                          node_id_filter: Optional[str] = None,
                          kind_filter: Optional[str] = None,
                          severity_filter: Optional[str] = None,
                          status_filter: Optional[str] = None,
                          scope_filter: Optional[str] = None,
                          target_id_filter: Optional[str] = None,
                          limit: int = 100,
                          offset: int = 0,
                          project_path: Optional[str] = None) -> Dict[str, Any]:
    """Query unified intents and annotations."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    query = get_unified_query(Path(project_path))
    return query.query(
        item_type_filter=item_type_filter,
        node_id_filter=node_id_filter,
        kind_filter=kind_filter,
        severity_filter=severity_filter,
        status_filter=status_filter,
        scope_filter=scope_filter,
        target_id_filter=target_id_filter,
        limit=limit,
        offset=offset
    )


def get_unified_item(item_id: str, project_path: Optional[str] = None) -> Optional[UnifiedItem]:
    """Get a unified item by ID."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    query = get_unified_query(Path(project_path))
    return query.get_item(item_id)


def get_unified_stats(project_path: Optional[str] = None) -> Dict[str, Any]:
    """Get statistics about the unified system."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    query = get_unified_query(Path(project_path))
    return query.get_stats()


__all__ = [
    "UnifiedItemType",
    "UnifiedItem",
    "UnifiedIntentQuery",
    "get_unified_query",
    "query_unified_intents",
    "get_unified_item",
    "get_unified_stats"
]
