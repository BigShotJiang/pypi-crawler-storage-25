from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from forge.core.response_schema import tier_fields
from forge.tools.intent.runtime import IntentRecord, load_intent_records
from forge.tools.manifest.graph import build_manifest_graph
from forge.tools.trace_store import latest_trace_file, load_latest_trace


@dataclass
class TemporalDriftItem:
    node_id: str
    drift_class: str
    graph_a: str
    graph_b: str
    detail: str


@dataclass
class TemporalTriangulationInput:
    declaration_graph: Any
    execution_graph: Any
    intent_graph: Any | None = None


@dataclass
class TemporalTriangulationResult:
    status: str
    message: str
    declaration_graph: Any
    execution_graph: Any
    intent_graph: Any | None


def _parse_iso(ts: str | None) -> datetime | None:
    if not ts:
        return None
    s = str(ts).strip()
    if not s:
        return None
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def _execution_nodes_by_decl_id(project_root: Path) -> dict[str, list[dict[str, Any]]]:
    out: dict[str, list[dict[str, Any]]] = {}
    eg = load_latest_trace(project_root)
    if eg is None:
        return out
    graph = build_manifest_graph(project_root)
    rel_to_decl: dict[str, str] = {}
    for n in graph.nodes:
        rel = str(n.path or "").replace("\\", "/").lstrip("./")
        if rel:
            rel_to_decl[rel] = str(n.id)
    for en in eg.nodes.values():
        fp = str(en.file or "").replace("\\", "/")
        matched: str | None = None
        for rel, decl_id in rel_to_decl.items():
            if fp.endswith(rel):
                matched = decl_id
                break
        if not matched:
            continue
        out.setdefault(matched, []).append(
            {
                "id": en.id,
                "qualname": str(en.qualname or ""),
                "module": str(en.module or ""),
            }
        )
    return out


def _declaration_contract_methods(graph: Any) -> dict[str, set[str]]:
    by_node: dict[str, set[str]] = {}
    for e in getattr(graph, "edges", []):
        if str(getattr(e, "relation", "")) != "contract":
            continue
        meta = getattr(e, "meta", {}) or {}
        method = str(meta.get("method") or "").strip()
        if not method:
            continue
        nid = str(getattr(e, "from_id", "") or "")
        if not nid:
            continue
        by_node.setdefault(nid, set()).add(method)
    return by_node


def triangulate_temporal_contracts(
    project_root: Path | TemporalTriangulationInput,
    *,
    node_id: str | None = None,
    response_tier: str = "L1",
) -> dict[str, Any]:
    if isinstance(project_root, TemporalTriangulationInput):
        return TemporalTriangulationResult(
            status="ok",
            message="temporal triangulation compatibility payload",
            declaration_graph=project_root.declaration_graph,
            execution_graph=project_root.execution_graph,
            intent_graph=project_root.intent_graph,
        )
    root = project_root.expanduser().resolve()
    graph = build_manifest_graph(root)
    decl_nodes = {str(n.id): n for n in graph.nodes}
    decl_methods = _declaration_contract_methods(graph)
    exec_by_decl = _execution_nodes_by_decl_id(root)
    intents = load_intent_records(root)
    intents_by_target: dict[str, list[IntentRecord]] = {}
    for rec in intents:
        target = (rec.target_id or "").strip()
        if target:
            intents_by_target.setdefault(target, []).append(rec)

    manifest_ts: datetime | None = None
    manifest_file = root / ".forge" / "manifest.yaml"
    if manifest_file.is_file():
        manifest_ts = datetime.fromtimestamp(manifest_file.stat().st_mtime, tz=timezone.utc)
    trace_ts: datetime | None = None
    trace_file = latest_trace_file(root)
    if trace_file and trace_file.is_file():
        trace_ts = datetime.fromtimestamp(trace_file.stat().st_mtime, tz=timezone.utc)

    max_intent_ts: datetime | None = None
    for recs in intents_by_target.values():
        for rec in recs:
            dt = _parse_iso(str(rec.created_at or ""))
            if dt and (max_intent_ts is None or dt > max_intent_ts):
                max_intent_ts = dt

    drift_items: list[TemporalDriftItem] = []
    candidate_ids = set(decl_nodes.keys()) | set(exec_by_decl.keys()) | set(intents_by_target.keys())
    if node_id:
        nid = str(node_id).strip()
        candidate_ids = {nid} if nid else set()

    for nid in sorted(candidate_ids):
        decl = decl_nodes.get(nid)
        exec_rows = exec_by_decl.get(nid, [])
        intent_rows = intents_by_target.get(nid, [])

        # schema_drift: declaration contract methods changed but runtime still reflects old names.
        methods = decl_methods.get(nid, set())
        if methods and exec_rows:
            exec_names = {str(r.get("qualname") or r.get("id") or "").split(".")[-1] for r in exec_rows}
            if exec_names and methods.isdisjoint(exec_names):
                drift_items.append(
                    TemporalDriftItem(
                        node_id=nid,
                        drift_class="schema_drift",
                        graph_a="declaration",
                        graph_b="execution",
                        detail="declaration contract methods differ from observed execution call names",
                    )
                )

        # intent_drift: intent description no longer matches implemented declaration node identity.
        if decl and intent_rows:
            dn = str(getattr(decl, "name", "") or "").lower()
            for rec in intent_rows:
                desc = str(rec.raw_description or "").lower()
                if dn and dn not in desc:
                    drift_items.append(
                        TemporalDriftItem(
                            node_id=nid,
                            drift_class="intent_drift",
                            graph_a="intent",
                            graph_b="declaration",
                            detail="intent description diverges from declaration node identity",
                        )
                    )
                    break

        # temporal_gap: one graph has newer timestamp than another for same node presence.
        has_decl = decl is not None
        has_exec = bool(exec_rows)
        has_intent = bool(intent_rows)

        if has_decl and has_exec and manifest_ts and trace_ts and manifest_ts > trace_ts:
            drift_items.append(
                TemporalDriftItem(
                    node_id=nid,
                    drift_class="temporal_gap",
                    graph_a="declaration",
                    graph_b="execution",
                    detail="manifest is newer than latest execution trace for this node",
                )
            )
        if has_decl and has_intent and manifest_ts and max_intent_ts and max_intent_ts > manifest_ts:
            drift_items.append(
                TemporalDriftItem(
                    node_id=nid,
                    drift_class="temporal_gap",
                    graph_a="intent",
                    graph_b="declaration",
                    detail="intent record timestamp is newer than manifest declaration",
                )
            )
        if has_exec and has_intent and trace_ts and max_intent_ts and max_intent_ts > trace_ts:
            drift_items.append(
                TemporalDriftItem(
                    node_id=nid,
                    drift_class="temporal_gap",
                    graph_a="intent",
                    graph_b="execution",
                    detail="intent record is newer than latest execution trace",
                )
            )

    tier = str(response_tier or "L1").upper()
    rows = [asdict(d) for d in drift_items]
    if tier == "L0":
        counts: dict[str, int] = {}
        for r in rows:
            k = str(r.get("drift_class") or "unknown")
            counts[k] = counts.get(k, 0) + 1
        return {"count_by_drift_class": counts}

    fields = tier_fields(root, "temporal_triangulation", tier)
    if not fields:
        return {"results": rows}
    return {"results": [{k: r.get(k) for k in fields} for r in rows]}
