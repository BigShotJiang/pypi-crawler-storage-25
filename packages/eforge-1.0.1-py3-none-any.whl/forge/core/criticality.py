"""Shared inbound-import criticality labels (forge_query, verify --strict, MCP)."""


def criticality_label(inbound_weight: int) -> str:
    if inbound_weight <= 2:
        return "low"
    if inbound_weight <= 7:
        return "medium"
    if inbound_weight <= 15:
        return "high"
    return "critical"
