"""
Real-Time Execution Monitoring Dashboard

Provides live monitoring and analysis of execution graph operations.
Features:
- Real-time execution event streaming
- Performance metrics and bottleneck detection
- Visual execution flow analysis
- Anomaly detection and alerting
- Historical execution patterns
"""

import asyncio
import json
import time
import threading
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Callable
from enum import Enum
import statistics

from .execution_graph import ExecutionGraph, ExecutionNode, ExecutionEdge, ExecutionResult


class ExecutionEventType(Enum):
    """Types of execution events."""
    CALL_START = "call_start"
    CALL_END = "call_end"
    ERROR = "error"
    PERFORMANCE_ALERT = "performance_alert"
    BOTTLENECK_DETECTED = "bottleneck_detected"
    ANOMALY_DETECTED = "anomaly_detected"


class AlertSeverity(Enum):
    """Alert severity levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class ExecutionEvent:
    """Real-time execution event."""
    timestamp: float
    event_type: ExecutionEventType
    node_id: str
    node_name: str
    node_kind: str
    duration_ms: Optional[float] = None
    error_message: Optional[str] = None
    stack_depth: int = 0
    memory_usage_mb: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PerformanceMetric:
    """Performance metric data."""
    node_id: str
    node_name: str
    avg_duration_ms: float
    min_duration_ms: float
    max_duration_ms: float
    call_count: int
    error_rate: float
    last_call: float
    trend: str  # "improving", "degrading", "stable"


@dataclass
class BottleneckInfo:
    """Bottleneck detection information."""
    node_id: str
    node_name: str
    severity: AlertSeverity
    avg_duration_ms: float
    calls_per_second: float
    queue_depth: int
    impact_score: float
    recommendations: List[str]


@dataclass
class AnomalyInfo:
    """Anomaly detection information."""
    timestamp: float
    node_id: str
    anomaly_type: str
    severity: AlertSeverity
    description: str
    confidence: float
    baseline_value: float
    actual_value: float


class ExecutionMonitor:
    """Real-time execution monitoring system."""
    
    def __init__(self, project_path: Path, buffer_size: int = 10000):
        self.project_path = project_path
        self.buffer_size = buffer_size
        
        # Event buffers
        self.events: deque[ExecutionEvent] = deque(maxlen=buffer_size)
        self.recent_events: deque[ExecutionEvent] = deque(maxlen=1000)
        
        # Performance tracking
        self.performance_metrics: Dict[str, PerformanceMetric] = {}
        self.call_history: Dict[str, deque[float]] = defaultdict(lambda: deque(maxlen=100))
        self.error_history: Dict[str, deque[float]] = defaultdict(lambda: deque(maxlen=50))
        
        # Monitoring state
        self.is_monitoring = False
        self.monitor_thread: Optional[threading.Thread] = None
        self.start_time: Optional[float] = None
        
        # Alerting
        self.bottlenecks: Dict[str, BottleneckInfo] = {}
        self.anomalies: List[AnomalyInfo] = []
        self.alert_callbacks: List[Callable[[ExecutionEvent], None]] = []
        
        # Configuration
        self.slow_call_threshold_ms = 1000.0
        self.error_rate_threshold = 0.1  # 10%
        self.bottleneck_threshold_ms = 500.0
        self.anomaly_detection_enabled = True
        
        # Statistics
        self.total_calls = 0
        self.total_errors = 0
        self.total_duration = 0.0
        
        # Lock for thread safety
        self.lock = threading.RLock()
    
    def start_monitoring(self) -> None:
        """Start real-time monitoring."""
        if self.is_monitoring:
            return
        
        self.is_monitoring = True
        self.start_time = time.time()
        
        # Start monitoring thread
        self.monitor_thread = threading.Thread(
            target=self._monitoring_loop,
            name="execution_monitor",
            daemon=True
        )
        self.monitor_thread.start()
        
        print(f"Execution monitoring started for {self.project_path}")
    
    def stop_monitoring(self) -> None:
        """Stop real-time monitoring."""
        if not self.is_monitoring:
            return
        
        self.is_monitoring = False
        
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5.0)
        
        print("Execution monitoring stopped")
    
    def add_execution_event(self, event: ExecutionEvent) -> None:
        """Add an execution event to the monitoring buffer."""
        with self.lock:
            self.events.append(event)
            self.recent_events.append(event)
            
            # Update statistics
            if event.event_type == ExecutionEventType.CALL_END:
                self.total_calls += 1
                if event.duration_ms:
                    self.total_duration += event.duration_ms
                    self.call_history[event.node_id].append(event.duration_ms)
            
            elif event.event_type == ExecutionEventType.ERROR:
                self.total_errors += 1
                self.error_history[event.node_id].append(event.timestamp)
            
            # Update performance metrics
            self._update_performance_metrics(event)
            
            # Check for alerts
            self._check_for_alerts(event)
            
            # Notify callbacks
            for callback in self.alert_callbacks:
                try:
                    callback(event)
                except Exception:
                    pass
    
    def _monitoring_loop(self) -> None:
        """Background monitoring loop."""
        while self.is_monitoring:
            try:
                # Analyze recent events for patterns
                self._analyze_execution_patterns()
                
                # Detect anomalies
                if self.anomaly_detection_enabled:
                    self._detect_anomalies()
                
                # Update bottlenecks
                self._update_bottlenecks()
                
                # Sleep for monitoring interval
                time.sleep(1.0)  # 1 second monitoring interval
                
            except Exception as e:
                print(f"Error in monitoring loop: {e}")
                time.sleep(5.0)  # Wait before retrying
    
    def _update_performance_metrics(self, event: ExecutionEvent) -> None:
        """Update performance metrics for a node."""
        if event.event_type != ExecutionEventType.CALL_END or event.duration_ms is None:
            return
        
        node_id = event.node_id
        node_name = event.node_name
        call_history = self.call_history[node_id]
        error_history = self.error_history[node_id]
        
        if not call_history:
            return
        
        # Calculate metrics
        avg_duration = statistics.mean(call_history)
        min_duration = min(call_history)
        max_duration = max(call_history)
        call_count = len(call_history)
        
        # Calculate error rate
        recent_time = time.time() - 300  # Last 5 minutes
        recent_errors = sum(1 for t in error_history if t > recent_time)
        error_rate = recent_errors / max(call_count, 1)
        
        # Determine trend
        trend = self._calculate_trend(call_history)
        
        # Update metrics
        self.performance_metrics[node_id] = PerformanceMetric(
            node_id=node_id,
            node_name=node_name,
            avg_duration_ms=avg_duration,
            min_duration_ms=min_duration,
            max_duration_ms=max_duration,
            call_count=call_count,
            error_rate=error_rate,
            last_call=event.timestamp,
            trend=trend
        )
    
    def _calculate_trend(self, call_history: deque[float]) -> str:
        """Calculate performance trend from call history."""
        if len(call_history) < 10:
            return "stable"
        
        # Compare recent vs older calls
        recent_calls = list(call_history)[-5:]  # Last 5 calls
        older_calls = list(call_history)[-10:-5]  # 5-10 calls ago
        
        if not older_calls:
            return "stable"
        
        recent_avg = statistics.mean(recent_calls)
        older_avg = statistics.mean(older_calls)
        
        # Determine trend based on percentage change
        change_pct = ((recent_avg - older_avg) / older_avg) * 100
        
        if change_pct > 10:
            return "degrading"
        elif change_pct < -10:
            return "improving"
        else:
            return "stable"
    
    def _check_for_alerts(self, event: ExecutionEvent) -> None:
        """Check for performance alerts."""
        if event.event_type == ExecutionEventType.CALL_END and event.duration_ms:
            # Slow call alert
            if event.duration_ms > self.slow_call_threshold_ms:
                alert_event = ExecutionEvent(
                    timestamp=time.time(),
                    event_type=ExecutionEventType.PERFORMANCE_ALERT,
                    node_id=event.node_id,
                    node_name=event.node_name,
                    node_kind=event.node_kind,
                    duration_ms=event.duration_ms,
                    metadata={"alert_type": "slow_call", "threshold_ms": self.slow_call_threshold_ms}
                )
                self.add_execution_event(alert_event)
        
        elif event.event_type == ExecutionEventType.ERROR:
            # High error rate alert
            metrics = self.performance_metrics.get(event.node_id)
            if metrics and metrics.error_rate > self.error_rate_threshold:
                alert_event = ExecutionEvent(
                    timestamp=time.time(),
                    event_type=ExecutionEventType.PERFORMANCE_ALERT,
                    node_id=event.node_id,
                    node_name=event.node_name,
                    node_kind=event.node_kind,
                    metadata={"alert_type": "high_error_rate", "error_rate": metrics.error_rate}
                )
                self.add_execution_event(alert_event)
    
    def _analyze_execution_patterns(self) -> None:
        """Analyze execution patterns for insights."""
        # This would implement more sophisticated pattern analysis
        # For now, focus on basic bottleneck detection
        pass
    
    def _detect_anomalies(self) -> None:
        """Detect performance anomalies."""
        current_time = time.time()
        
        for node_id, metrics in self.performance_metrics.items():
            call_history = self.call_history[node_id]
            
            if len(call_history) < 20:  # Need enough data for anomaly detection
                continue
            
            # Detect duration anomalies using statistical methods
            durations = list(call_history)
            mean_duration = statistics.mean(durations)
            std_duration = statistics.stdev(durations) if len(durations) > 1 else 0
            
            if std_duration > 0:
                # Check for outliers (more than 3 standard deviations)
                recent_duration = durations[-1]
                z_score = abs(recent_duration - mean_duration) / std_duration
                
                if z_score > 3.0:  # Significant anomaly
                    severity = AlertSeverity.HIGH if z_score > 4.0 else AlertSeverity.MEDIUM
                    
                    anomaly = AnomalyInfo(
                        timestamp=current_time,
                        node_id=node_id,
                        node_name=metrics.node_name,
                        anomaly_type="duration_outlier",
                        severity=severity,
                        description=f"Call duration {recent_duration:.2f}ms is {z_score:.1f} standard deviations from normal",
                        confidence=min(z_score / 3.0, 1.0),
                        baseline_value=mean_duration,
                        actual_value=recent_duration
                    )
                    
                    self.anomalies.append(anomaly)
                    
                    # Keep only recent anomalies
                    if len(self.anomalies) > 100:
                        self.anomalies = self.anomalies[-50:]
    
    def _update_bottlenecks(self) -> None:
        """Update bottleneck detection."""
        current_time = time.time()
        recent_window = 300  # 5 minutes
        
        for node_id, metrics in self.performance_metrics.items():
            # Calculate calls per second
            recent_calls = [
                t for t in self.call_history[node_id] 
                if current_time - t < recent_window
            ]
            calls_per_second = len(recent_calls) / (recent_window / 1000)
            
            # Determine if this is a bottleneck
            is_bottleneck = (
                metrics.avg_duration_ms > self.bottleneck_threshold_ms and
                calls_per_second > 1.0 and
                metrics.call_count > 10
            )
            
            if is_bottleneck:
                # Calculate impact score
                impact_score = (
                    (metrics.avg_duration_ms / self.bottleneck_threshold_ms) *
                    calls_per_second *
                    (1 + metrics.error_rate)
                )
                
                # Determine severity
                if impact_score > 10.0:
                    severity = AlertSeverity.CRITICAL
                elif impact_score > 5.0:
                    severity = AlertSeverity.HIGH
                elif impact_score > 2.0:
                    severity = AlertSeverity.MEDIUM
                else:
                    severity = AlertSeverity.LOW
                
                # Generate recommendations
                recommendations = self._generate_bottleneck_recommendations(metrics)
                
                bottleneck = BottleneckInfo(
                    node_id=node_id,
                    node_name=metrics.node_name,
                    severity=severity,
                    avg_duration_ms=metrics.avg_duration_ms,
                    calls_per_second=calls_per_second,
                    queue_depth=int(calls_per_second * metrics.avg_duration_ms / 1000),
                    impact_score=impact_score,
                    recommendations=recommendations
                )
                
                self.bottlenecks[node_id] = bottleneck
            elif node_id in self.bottlenecks:
                # Remove if no longer a bottleneck
                del self.bottlenecks[node_id]
    
    def _generate_bottleneck_recommendations(self, metrics: PerformanceMetric) -> List[str]:
        """Generate recommendations for bottleneck resolution."""
        recommendations = []
        
        if metrics.avg_duration_ms > 2000:
            recommendations.append("Consider optimizing algorithm or adding caching")
        
        if metrics.error_rate > 0.05:
            recommendations.append("Investigate and fix error conditions")
        
        if metrics.trend == "degrading":
            recommendations.append("Performance is degrading - investigate recent changes")
        
        if metrics.call_count > 1000:
            recommendations.append("High call volume - consider batching or async processing")
        
        # Add specific recommendations based on node kind
        if "service" in metrics.node_id.lower():
            recommendations.append("Service bottleneck - consider scaling or load balancing")
        elif "controller" in metrics.node_id.lower():
            recommendations.append("Controller bottleneck - optimize data access patterns")
        elif "screen" in metrics.node_id.lower():
            recommendations.append("Screen bottleneck - optimize rendering and data loading")
        
        return recommendations[:5]  # Return top 5 recommendations
    
    def get_dashboard_data(self) -> Dict[str, Any]:
        """Get comprehensive dashboard data."""
        with self.lock:
            current_time = time.time()
            uptime = current_time - (self.start_time or current_time)
            
            # Calculate overall metrics
            avg_call_duration = self.total_duration / max(self.total_calls, 1)
            overall_error_rate = self.total_errors / max(self.total_calls, 1)
            
            # Get top performers
            top_metrics = sorted(
                self.performance_metrics.values(),
                key=lambda m: m.avg_duration_ms,
                reverse=True
            )[:10]
            
            # Get recent alerts
            recent_alerts = [
                event for event in self.recent_events
                if event.event_type in [
                    ExecutionEventType.PERFORMANCE_ALERT,
                    ExecutionEventType.BOTTLENECK_DETECTED,
                    ExecutionEventType.ANOMALY_DETECTED
                ]
            ][-20:]  # Last 20 alerts
            
            return {
                "monitoring_status": {
                    "is_active": self.is_monitoring,
                    "uptime_seconds": uptime,
                    "start_time": self.start_time,
                    "buffer_size": len(self.events),
                    "max_buffer_size": self.buffer_size
                },
                "overall_metrics": {
                    "total_calls": self.total_calls,
                    "total_errors": self.total_errors,
                    "avg_duration_ms": avg_call_duration,
                    "error_rate": overall_error_rate,
                    "calls_per_second": self.total_calls / max(uptime, 1)
                },
                "performance_metrics": {
                    "total_nodes_tracked": len(self.performance_metrics),
                    "top_slowest": [
                        {
                            "node_id": m.node_id,
                            "node_name": m.node_name,
                            "avg_duration_ms": m.avg_duration_ms,
                            "call_count": m.call_count,
                            "error_rate": m.error_rate,
                            "trend": m.trend
                        }
                        for m in top_metrics
                    ]
                },
                "bottlenecks": {
                    "total_count": len(self.bottlenecks),
                    "active_bottlenecks": [
                        {
                            "node_id": info.node_id,
                            "node_name": info.node_name,
                            "severity": info.severity.value,
                            "avg_duration_ms": info.avg_duration_ms,
                            "calls_per_second": info.calls_per_second,
                            "impact_score": info.impact_score,
                            "recommendations": info.recommendations
                        }
                        for info in sorted(
                            self.bottlenecks.values(),
                            key=lambda b: b.impact_score,
                            reverse=True
                        )
                    ]
                },
                "anomalies": {
                    "total_count": len(self.anomalies),
                    "recent_anomalies": [
                        {
                            "timestamp": a.timestamp,
                            "node_id": a.node_id,
                            "node_name": a.node_name,
                            "anomaly_type": a.anomaly_type,
                            "severity": a.severity.value,
                            "description": a.description,
                            "confidence": a.confidence
                        }
                        for a in sorted(
                            self.anomalies,
                            key=lambda a: a.timestamp,
                            reverse=True
                        )[-10:]
                    ]
                },
                "recent_alerts": [
                    {
                        "timestamp": event.timestamp,
                        "event_type": event.event_type.value,
                        "node_id": event.node_id,
                        "node_name": event.node_name,
                        "duration_ms": event.duration_ms,
                        "metadata": event.metadata
                    }
                    for event in recent_alerts
                ],
                "configuration": {
                    "slow_call_threshold_ms": self.slow_call_threshold_ms,
                    "error_rate_threshold": self.error_rate_threshold,
                    "bottleneck_threshold_ms": self.bottleneck_threshold_ms,
                    "anomaly_detection_enabled": self.anomaly_detection_enabled
                }
            }
    
    def export_metrics(self, filepath: Path) -> None:
        """Export metrics to JSON file."""
        dashboard_data = self.get_dashboard_data()
        
        with open(filepath, 'w') as f:
            json.dump(dashboard_data, f, indent=2, default=str)
    
    def add_alert_callback(self, callback: Callable[[ExecutionEvent], None]) -> None:
        """Add callback for alert notifications."""
        self.alert_callbacks.append(callback)
    
    def configure_thresholds(self, 
                           slow_call_threshold_ms: float = None,
                           error_rate_threshold: float = None,
                           bottleneck_threshold_ms: float = None) -> None:
        """Configure monitoring thresholds."""
        if slow_call_threshold_ms is not None:
            self.slow_call_threshold_ms = slow_call_threshold_ms
        if error_rate_threshold is not None:
            self.error_rate_threshold = error_rate_threshold
        if bottleneck_threshold_ms is not None:
            self.bottleneck_threshold_ms = bottleneck_threshold_ms


# Global monitor instance
_monitor_instance: Optional[ExecutionMonitor] = None


def get_execution_monitor(project_path: Path) -> ExecutionMonitor:
    """Get or create execution monitor instance."""
    global _monitor_instance
    
    if _monitor_instance is None or str(_monitor_instance.project_path) != str(project_path):
        _monitor_instance = ExecutionMonitor(project_path)
    
    return _monitor_instance


def start_execution_monitoring(project_path: Path) -> ExecutionMonitor:
    """Start execution monitoring for a project."""
    monitor = get_execution_monitor(project_path)
    monitor.start_monitoring()
    return monitor


def stop_execution_monitoring() -> None:
    """Stop execution monitoring."""
    global _monitor_instance
    
    if _monitor_instance:
        _monitor_instance.stop_monitoring()
