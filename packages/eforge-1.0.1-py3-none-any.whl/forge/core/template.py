import re
import yaml
from pathlib import Path

from forge.core.result import ForgeResult


def _deep_merge(base: dict, overlay: dict) -> dict:
    """Merge overlay into base. Overlay wins on conflicts. Returns new dict."""
    out = dict(base)
    for k, v in overlay.items():
        if k in out and isinstance(out[k], dict) and isinstance(v, dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def _template_root() -> Path:
    return Path(__file__).resolve().parent.parent.parent


class TemplateEngine:
    """
    Merges _base.manifest.yaml + {type}.manifest.yaml,
    replaces all {{PLACEHOLDER}} tokens, writes output manifest.
    """

    TEMPLATES_DIR: Path = _template_root() / "templates"
    SCHEMAS_DIR: Path = _template_root() / "schemas"

    def __init__(self, project_type: str) -> None:
        self.project_type = project_type
        base_path = self.TEMPLATES_DIR / "_base.manifest.yaml"
        type_path = self.TEMPLATES_DIR / f"{project_type}.manifest.yaml"
        if not base_path.exists():
            raise FileNotFoundError(f"Base template not found: {base_path}")
        if not type_path.exists():
            raise FileNotFoundError(f"Type template not found: {type_path}")

    def render(self, tokens: dict[str, str]) -> str:
        """
        Merges base + type template (type wins on conflicts).
        Replaces all {{KEY}} tokens with tokens[KEY].
        Returns rendered YAML string.
        Raises ValueError if any {{PLACEHOLDER}} remains unreplaced.
        """
        base_path = self.TEMPLATES_DIR / "_base.manifest.yaml"
        type_path = self.TEMPLATES_DIR / f"{self.project_type}.manifest.yaml"
        # C006-OK: template YAML (_base.manifest.yaml / type.manifest.yaml), not project manifest I/O.
        base_data = yaml.safe_load(base_path.read_text()) or {}
        # C006-OK: template YAML (_base.manifest.yaml / type.manifest.yaml), not project manifest I/O.
        type_data = yaml.safe_load(type_path.read_text()) or {}
        merged = _deep_merge(base_data, type_data)
        yaml_str = yaml.dump(merged, default_flow_style=False, sort_keys=False, allow_unicode=True)
        pattern = re.compile(r"\{\{([A-Za-z0-9_]+)\}\}")
        remaining = set(pattern.findall(yaml_str))
        for key, value in tokens.items():
            yaml_str = yaml_str.replace(f"{{{{{key}}}}}", str(value))
            remaining.discard(key)
        still_remaining = set(pattern.findall(yaml_str))
        if still_remaining:
            raise ValueError(f"Unreplaced placeholders: {sorted(still_remaining)}")
        return yaml_str

    def write(self, tokens: dict[str, str], output_path: Path) -> ForgeResult[Path]:
        """
        Calls render(), writes to output_path/manifest.yaml.
        Returns ForgeResult with path on success.
        """
        try:
            rendered = self.render(tokens)
        except ValueError as e:
            return ForgeResult.failure(str(e))
        manifest_path = output_path / "manifest.yaml"
        try:
            manifest_path.parent.mkdir(parents=True, exist_ok=True)
            manifest_path.write_text(rendered)
        except OSError as e:
            return ForgeResult.failure(f"Cannot write manifest: {e}")
        errors = self.validate_rendered(rendered)
        if errors:
            return ForgeResult.failure("; ".join(errors))
        return ForgeResult.success(manifest_path)

    @classmethod
    def get_available_types(cls) -> list[str]:
        """
        Returns list of available types based on template files present.
        e.g. ["flutter", "web", "python"] — derived from filenames.
        Does not hardcode type names.
        """
        if not cls.TEMPLATES_DIR.exists():
            return []
        types = []
        for p in cls.TEMPLATES_DIR.glob("*.manifest.yaml"):
            name = p.stem.replace(".manifest", "")
            if name != "_base":
                types.append(name)
        return sorted(types)

    def validate_rendered(self, rendered_yaml: str) -> list[str]:
        """
        Parses rendered YAML, checks against v1.schema.yaml.
        Returns list of error strings. Empty = valid.
        Specifically checks that no {{PLACEHOLDER}} values remain.
        """
        errors: list[str] = []
        if "{{" in rendered_yaml and "}}" in rendered_yaml:
            placeholders = re.findall(r"\{\{[^}]+\}\}", rendered_yaml)
            if placeholders:
                errors.append(f"Remaining placeholders: {placeholders}")
        schema_path = self.SCHEMAS_DIR / "v1.schema.yaml"
        if not schema_path.exists():
            return errors
        try:
            schema_data = yaml.safe_load(schema_path.read_text()) or {}
            forbidden = schema_data.get("forbidden_values") or []
            for fv in forbidden:
                if fv in rendered_yaml:
                    errors.append(f"Forbidden value present: {fv}")
        except Exception:
            pass
        return errors
