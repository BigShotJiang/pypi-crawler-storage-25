"""Subgraph scopes for workspace / ForgeProject filtering (Sprint 10)."""

from __future__ import annotations

from pathlib import Path

from forge.tools.manifest.graph import ManifestEdge, ManifestGraph, ManifestNode


def manifest_graph_scoped(full: ManifestGraph, root: Path) -> ManifestGraph:
    """Return a graph view whose nodes belong to repo ``root`` (path-prefix relative to graph origin)."""

    scope = root.expanduser().resolve()
    base = Path(full.project_path).expanduser().resolve()
    try:
        if scope == base:
            return full
    except Exception:
        pass

    def _keep_node(n: ManifestNode) -> bool:
        rp = str(n.path or "").replace("\\", "/").strip()
        if not rp:
            return scope == base
        try:
            abs_node = (base / rp).resolve()
            return bool(abs_node.is_relative_to(scope))
        except (OSError, ValueError, RuntimeError):
            return False

    keep_ids = {n.id for n in full.nodes if _keep_node(n)}
    nodes = [n for n in full.nodes if n.id in keep_ids]
    edges: list[ManifestEdge] = [
        e for e in full.edges if e.from_id in keep_ids and e.to_id in keep_ids
    ]
    return ManifestGraph(project_path=scope, nodes=nodes, edges=edges, source=f"scoped<{full.source}>")
