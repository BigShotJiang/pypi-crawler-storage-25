"""Build-aware analysis engine for proper project configuration understanding.

Parses tsconfig.json, astro.config.mjs, and other build configuration files
to provide context-aware import resolution and validation.
"""

import json
import yaml
from pathlib import Path
from typing import Dict, List, Optional, Any, Union, Tuple
from dataclasses import dataclass
from collections import defaultdict


@dataclass(frozen=True)
class BuildConfiguration:
    """Represents build configuration for a project."""
    project_type: str
    build_tool: str
    module_resolution: str
    base_url: Optional[str]
    paths: Dict[str, List[str]]
    aliases: Dict[str, str]
    extensions: List[str]
    out_dir: str
    src_dir: str


@dataclass(frozen=True)
class TypeScriptConfig:
    """TypeScript configuration."""
    compiler_options: Dict[str, Any]
    include: List[str]
    exclude: List[str]
    references: List[str]


@dataclass(frozen=True)
class AstroConfig:
    """Astro configuration."""
    integrations: List[Dict[str, Any]]
    vite_config: Dict[str, Any]
    build_options: Dict[str, Any]
    markdown_config: Dict[str, Any]


class BuildAwareAnalyzer:
    """Provides build-aware analysis for proper project understanding."""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self._config_cache: Dict[str, Any] = {}
        self._build_config: Optional[BuildConfiguration] = None
    
    def analyze_project(self) -> BuildConfiguration:
        """Analyze project and return build configuration."""
        if self._build_config:
            return self._build_config
        
        # Detect project type and build tool
        project_type = self._detect_project_type()
        build_tool = self._detect_build_tool()
        
        # Load configuration files
        ts_config = self._load_typescript_config()
        astro_config = self._load_astro_config()
        package_config = self._load_package_config()
        
        # Extract module resolution settings
        module_resolution = self._extract_module_resolution(ts_config, astro_config, package_config)
        
        # Extract path mappings and aliases
        base_url, paths, aliases = self._extract_path_mappings(ts_config, astro_config, package_config)
        
        # Extract file extensions
        extensions = self._extract_extensions(ts_config, astro_config, package_config)
        
        # Determine output and source directories
        out_dir = self._extract_out_dir(ts_config, astro_config, package_config)
        src_dir = self._extract_src_dir(ts_config, astro_config, package_config)
        
        self._build_config = BuildConfiguration(
            project_type=project_type,
            build_tool=build_tool,
            module_resolution=module_resolution,
            base_url=base_url,
            paths=paths,
            aliases=aliases,
            extensions=extensions,
            out_dir=out_dir,
            src_dir=src_dir
        )
        
        return self._build_config
    
    def _detect_project_type(self) -> str:
        """Detect project type from configuration files."""
        if (self.project_root / "astro.config.mjs").exists() or \
           (self.project_root / "astro.config.js").exists() or \
           (self.project_root / "astro.config.ts").exists():
            return "astro"
        
        if (self.project_root / "next.config.js").exists():
            return "next"
        
        if (self.project_root / "nuxt.config.js").exists() or \
           (self.project_root / "nuxt.config.ts").exists():
            return "nuxt"
        
        if (self.project_root / "vite.config.js").exists() or \
           (self.project_root / "vite.config.ts").exists():
            return "vite"
        
        if (self.project_root / "webpack.config.js").exists():
            return "webpack"
        
        if (self.project_root / "tsconfig.json").exists():
            return "typescript"
        
        # Check package.json for framework field
        package_json = self.project_root / "package.json"
        if package_json.exists():
            try:
                with open(package_json) as f:
                    pkg = json.load(f)
                    if "astro" in pkg.get("dependencies", {}):
                        return "astro"
                    if "next" in pkg.get("dependencies", {}):
                        return "next"
                    if "nuxt" in pkg.get("dependencies", {}):
                        return "nuxt"
            except (json.JSONDecodeError, IOError):
                pass
        
        return "unknown"
    
    def _detect_build_tool(self) -> str:
        """Detect primary build tool."""
        # Check for build tool lock files
        if (self.project_root / "pnpm-lock.yaml").exists():
            return "pnpm"
        elif (self.project_root / "yarn.lock").exists():
            return "yarn"
        elif (self.project_root / "package-lock.json").exists():
            return "npm"
        
        # Check for build tool configs
        if (self.project_root / "vite.config.js").exists() or \
           (self.project_root / "vite.config.ts").exists():
            return "vite"
        elif (self.project_root / "webpack.config.js").exists():
            return "webpack"
        elif (self.project_root / "rollup.config.js").exists():
            return "rollup"
        elif (self.project_root / "esbuild.config.js").exists():
            return "esbuild"
        
        return "npm"  # Default fallback
    
    def _load_typescript_config(self) -> Optional[TypeScriptConfig]:
        """Load TypeScript configuration."""
        ts_config_path = self.project_root / "tsconfig.json"
        if not ts_config_path.exists():
            return None
        
        try:
            with open(ts_config_path) as f:
                config = json.load(f)
            
            return TypeScriptConfig(
                compiler_options=config.get("compilerOptions", {}),
                include=config.get("include", []),
                exclude=config.get("exclude", []),
                references=config.get("references", [])
            )
        except (json.JSONDecodeError, IOError):
            return None
    
    def _load_astro_config(self) -> Optional[AstroConfig]:
        """Load Astro configuration."""
        # Try different Astro config file extensions
        for ext in [".mjs", ".js", ".ts"]:
            config_path = self.project_root / f"astro.config{ext}"
            if config_path.exists():
                try:
                    # For now, return a basic config since parsing JS would require eval
                    return AstroConfig(
                        integrations=[],
                        vite_config={},
                        build_options={},
                        markdown_config={}
                    )
                except IOError:
                    continue
        
        return None
    
    def _load_package_config(self) -> Dict[str, Any]:
        """Load package.json configuration."""
        package_json = self.project_root / "package.json"
        if not package_json.exists():
            return {}
        
        try:
            with open(package_json) as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return {}
    
    def _extract_module_resolution(self, ts_config: Optional[TypeScriptConfig], 
                                 astro_config: Optional[AstroConfig], 
                                 package_config: Dict[str, Any]) -> str:
        """Extract module resolution strategy."""
        if ts_config and ts_config.compiler_options:
            resolution = ts_config.compiler_options.get("moduleResolution", "node")
            if resolution:
                return resolution
        
        # Check package.json for module field
        if package_config.get("type") == "module":
            return "node"
        
        # Default to node resolution
        return "node"
    
    def _extract_path_mappings(self, ts_config: Optional[TypeScriptConfig], 
                            astro_config: Optional[AstroConfig], 
                            package_config: Dict[str, Any]) -> Tuple[Optional[str], Dict[str, List[str]], Dict[str, str]]:
        """Extract path mappings and aliases."""
        base_url = None
        paths = {}
        aliases = {}
        
        # Extract from TypeScript config
        if ts_config and ts_config.compiler_options:
            base_url = ts_config.compiler_options.get("baseUrl")
            paths = ts_config.compiler_options.get("paths", {})
        
        # Extract from Vite config (would need to parse JS)
        # For now, check package.json imports field
        if package_config.get("imports"):
            imports = package_config["imports"]
            for key, value in imports.items():
                if key.startswith("#"):
                    aliases[key] = value
        
        # Convert TypeScript paths to simpler format
        simplified_paths = {}
        for pattern, targets in paths.items():
            # Remove wildcards for simpler mapping
            clean_pattern = pattern.replace("/*", "")
            clean_targets = [target.replace("/*", "") for target in targets]
            simplified_paths[clean_pattern] = clean_targets
        
        return base_url, simplified_paths, aliases
    
    def _extract_extensions(self, ts_config: Optional[TypeScriptConfig], 
                         astro_config: Optional[AstroConfig], 
                         package_config: Dict[str, Any]) -> List[str]:
        """Extract supported file extensions."""
        extensions = [".js", ".ts", ".jsx", ".tsx", ".json"]
        
        # Add Astro extensions if Astro project
        if astro_config:
            extensions.extend([".astro", ".md", ".mdx"])
        
        # Add TypeScript-specific extensions
        if ts_config:
            extensions.extend([".d.ts"])
        
        # Check package.json for additional extensions
        if package_config.get("forgeExtensions"):
            extensions.extend(package_config["forgeExtensions"])
        
        return list(set(extensions))
    
    def _extract_out_dir(self, ts_config: Optional[TypeScriptConfig], 
                       astro_config: Optional[AstroConfig], 
                       package_config: Dict[str, Any]) -> str:
        """Extract output directory."""
        if ts_config and ts_config.compiler_options:
            out_dir = ts_config.compiler_options.get("outDir")
            if out_dir:
                return out_dir
        
        # Check package.json scripts for build output
        scripts = package_config.get("scripts", {})
        if "build" in scripts:
            build_script = scripts["build"]
            if "--outDir" in build_script:
                # Extract outDir from build script
                parts = build_script.split("--outDir")
                if len(parts) > 1:
                    out_dir = parts[1].strip().split()[0]
                    return out_dir
        
        # Default output directories by project type
        if astro_config:
            return "dist"
        
        return "build"
    
    def _extract_src_dir(self, ts_config: Optional[TypeScriptConfig], 
                        astro_config: Optional[AstroConfig], 
                        package_config: Dict[str, Any]) -> str:
        """Extract source directory."""
        # Check TypeScript include patterns
        if ts_config and ts_config.include:
            for pattern in ts_config.include:
                if "src/" in pattern:
                    return "src"
        
        # Check for common source directories
        src_dirs = ["src", "lib", "app", "source"]
        for src_dir in src_dirs:
            if (self.project_root / src_dir).exists() and \
               (self.project_root / src_dir).is_dir():
                return src_dir
        
        # Default to project root
        return "."
    
    def resolve_import_with_config(self, import_module: str, source_file: Path) -> Optional[Path]:
        """Resolve import path using build configuration."""
        config = self.analyze_project()
        
        # Handle path aliases
        for alias, target in config.aliases.items():
            if import_module.startswith(alias):
                remaining = import_module[len(alias):]
                resolved_path = self.project_root / target.lstrip("./") / remaining
                return resolved_path
        
        # Handle TypeScript paths
        if config.base_url:
            for path_pattern, targets in config.paths.items():
                if import_module.startswith(path_pattern):
                    remaining = import_module[len(path_pattern):]
                    for target in targets:
                        resolved_path = self.project_root / config.base_url / target / remaining
                        if resolved_path.exists():
                            return resolved_path
        
        # Handle relative imports
        if import_module.startswith("./") or import_module.startswith("../"):
            try:
                resolved_path = (source_file.parent / import_module).resolve()
                # Try different extensions
                for ext in config.extensions:
                    candidate = resolved_path.with_suffix(ext)
                    if candidate.exists():
                        return candidate
                
                # Try index files
                for ext in config.extensions:
                    index_candidate = resolved_path / f"index{ext}"
                    if index_candidate.exists():
                        return index_candidate
                
                return resolved_path
            except (ValueError, FileNotFoundError):
                pass
        
        return None
    
    def get_analysis_summary(self) -> Dict[str, Any]:
        """Get comprehensive build analysis summary."""
        config = self.analyze_project()
        
        return {
            'project_type': config.project_type,
            'build_tool': config.build_tool,
            'module_resolution': config.module_resolution,
            'base_url': config.base_url,
            'path_mappings': config.paths,
            'aliases': config.aliases,
            'supported_extensions': config.extensions,
            'output_directory': config.out_dir,
            'source_directory': config.src_dir,
            'configuration_files': self._get_config_files(),
            'has_typescript': (self.project_root / "tsconfig.json").exists(),
            'has_astro_config': any(
                (self.project_root / f"astro.config{ext}").exists() 
                for ext in [".mjs", ".js", ".ts"]
            ),
            'has_vite_config': any(
                (self.project_root / f"vite.config{ext}").exists() 
                for ext in [".js", ".ts"]
            )
        }
    
    def _get_config_files(self) -> List[str]:
        """Get list of configuration files found."""
        config_files = []
        
        # Common configuration files
        common_configs = [
            "package.json", "tsconfig.json", "jsconfig.json",
            "astro.config.mjs", "astro.config.js", "astro.config.ts",
            "vite.config.js", "vite.config.ts",
            "webpack.config.js", "rollup.config.js",
            "next.config.js", "nuxt.config.js", "nuxt.config.ts"
        ]
        
        for config_file in common_configs:
            if (self.project_root / config_file).exists():
                config_files.append(config_file)
        
        return config_files
