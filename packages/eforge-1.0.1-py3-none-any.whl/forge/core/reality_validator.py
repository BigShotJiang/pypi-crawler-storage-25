"""Reality-based manifest validation engine.

Compares actual file imports against manifest declarations to detect
discrepancies between declared and actual dependencies.
Uses stack-agnostic contract-based import resolution.
"""

import logging
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional, Any
from dataclasses import dataclass
from enum import Enum
from datetime import datetime

from forge.core.import_parser import ImportParser, ImportStatement, FileImports
from forge.core.import_parser import ImportParser
from forge.contracts.import_resolution import ImportResolutionContext, ImportResolutionStrategy, ImportResolutionContract, StackAgnosticResolver
from forge.strategies.astro_resolution import AstroResolutionStrategy
from forge.core.health_scoring_service import UnifiedHealthScoringService, HealthScoringContext
from forge.tools.manifest.graph import build_manifest_graph
from forge.core.manifest import ManifestParser
from forge.core.execution_graph import ExecutionGraph, get_execution_manager
from forge.core.contract_graph import ContractGraph

logger = logging.getLogger(__name__)


class DiscrepancyType(Enum):
    """Types of reality validation discrepancies."""
    MISSING_DECLARATION = "missing_declaration"  # Import exists but not in manifest
    EXTRA_DECLARATION = "extra_declaration"      # Manifest declares but no import found
    WRONG_PATH = "wrong_path"                   # Path mismatch between manifest and reality
    BROKEN_IMPORT = "broken_import"             # Import target doesn't exist
    DOMAIN_VIOLATION = "domain_violation"       # Import crosses domain boundaries


@dataclass(frozen=True)
class ValidationDiscrepancy:
    """Represents a single validation discrepancy."""
    discrepancy_type: DiscrepancyType
    source_file: Path
    import_statement: Optional[ImportStatement]
    manifest_node: Optional[Dict[str, Any]]
    description: str
    severity: str  # 'error', 'warning', 'info'
    suggested_action: Optional[str] = None


@dataclass(frozen=True)
class ValidationResult:
    """Results of reality validation against ALL graphs."""
    total_files_checked: int
    total_imports_found: int
    total_manifest_nodes: int
    discrepancies: List[ValidationDiscrepancy]
    health_score: float  # 0.0 to 1.0
    summary: Dict[str, Any]
    total_execution_nodes: int = 0
    total_contract_nodes: int = 0
    total_graph_nodes: int = 0


class RealityValidator:
    """Validates manifest against actual file import reality."""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.manifest_path = project_root / ".forge" / "manifest.yaml"
        self.import_parser = ImportParser(project_root)
        self.manifest_parser = ManifestParser(self.manifest_path)
        
        # Stack-agnostic import resolution using contracts
        strategies = [
            AstroResolutionStrategy()
        ]
        resolution_contract = ImportResolutionContract(strategies)
        self.import_resolver = StackAgnosticResolver(resolution_contract)
        
        # Unified health scoring service
        self.health_scoring_service = UnifiedHealthScoringService()
        
        # Domain boundaries loaded dynamically from configuration
        self.domain_boundaries = self._load_domain_boundaries()
    
    def validate_project(self, file_filter: Optional[str] = None) -> ValidationResult:
        """Validate project reality against ALL available graphs (manifest, execution, contract, intent)."""
        # Load all graphs
        try:
            manifest_graph = build_manifest_graph(self.project_root)
            execution_manager = get_execution_manager(self.project_root)
            execution_graph = ExecutionGraph()  # Create empty execution graph for now
            contract_graph = ContractGraph()  # Initialize empty contract graph for now
        except Exception as e:
            logger.warning(f"Could not load some graphs: {e}")
            # Fallback to manifest-only validation
            manifest_graph = build_manifest_graph(self.project_root)
            execution_graph = ExecutionGraph()
            contract_graph = ContractGraph()
        
        # Mechanical codebase mapping - build graphs from actual code structure
        if file_filter:
            target_dir = self.project_root / file_filter
            file_imports = self.import_parser.parse_directory(target_dir, recursive=True)
        else:
            # For projects without manifest, use mechanical discovery
            if not manifest_graph.nodes:
                logger.info("No manifest found - using mechanical codebase mapping")
                file_imports = self._mechanical_codebase_discovery()
            else:
                # Use manifest if available
                manifest_files = set()
                for node in manifest_graph.nodes:
                    if node.path and node.path.endswith('.py'):
                        manifest_files.add(self.project_root / node.path)
                
                file_imports = {}
                for file_path in manifest_files:
                    if file_path.exists():
                        try:
                            result = self.import_parser.parse_file(file_path)
                            file_imports[file_path] = result
                        except Exception as e:
                            logger.warning(f"Failed to parse {file_path}: {e}")
                
                logger.info(f"Parsed {len(file_imports)} manifest-declared files")
        
        # Perform validation against ALL graphs
        discrepancies = []
        
        # Validate against manifest graph
        manifest_discrepancies = self._validate_against_manifest(file_imports, manifest_graph)
        discrepancies.extend(manifest_discrepancies)
        
        # Validate against execution graph
        execution_discrepancies = self._validate_against_execution(file_imports, execution_graph.nodes)
        discrepancies.extend(execution_discrepancies)
        
        # Validate against contract graph
        contract_discrepancies = self._validate_against_contracts(file_imports, contract_graph.edges)
        discrepancies.extend(contract_discrepancies)
        
        # Calculate comprehensive health score using unified service
        total_graph_nodes = len(manifest_graph.nodes) + len(execution_graph.nodes) + len(contract_graph.edges)
        file_count = len(file_imports) if file_imports else len(manifest_graph.nodes)
        
        # Create health scoring context
        health_context = HealthScoringContext(
            project_root=self.project_root,
            stack=self.import_parser.detected_stack or "unknown",
            file_count=file_count,
            node_count=total_graph_nodes,
            graph_complexity={
                'manifest_nodes': len(manifest_graph.nodes),
                'execution_nodes': len(execution_graph.nodes),
                'contract_edges': len(contract_graph.edges)
            }
        )
        
        # Use unified health scoring service
        health_result = self.health_scoring_service.calculate_project_health(discrepancies, health_context)
        health_score = health_result['health_score']
        
        # Generate comprehensive summary
        summary = self._generate_comprehensive_summary(
            discrepancies, file_imports, 
            manifest_graph, execution_graph, contract_graph
        )
        
        return ValidationResult(
            total_files_checked=len(file_imports),
            total_imports_found=sum(len(fi.imports) for fi in file_imports.values()),
            total_manifest_nodes=len(manifest_graph.nodes),
            total_execution_nodes=len(execution_graph.nodes),
            total_contract_nodes=len(contract_graph.edges),
            total_graph_nodes=total_graph_nodes,
            discrepancies=discrepancies,
            health_score=health_score,
            summary=summary
        )
    
    def _mechanical_codebase_discovery(self) -> Dict[Path, FileImports]:
        """Mechanically discover and map codebase structure without requiring a manifest."""
        file_imports = {}
        
        # Discover actual Python files (excluding cache/dependencies)
        python_files = []
        for file_path in self.project_root.rglob("*.py"):
            if not self.import_parser._should_skip_file(file_path):
                python_files.append(file_path)
        
        logger.info(f"Discovered {len(python_files)} Python files for mechanical mapping")
        
        # Parse files in batches to prevent hanging
        batch_size = 100
        for i in range(0, len(python_files), batch_size):
            batch = python_files[i:i + batch_size]
            logger.info(f"Processing batch {i//batch_size + 1}/{(len(python_files) + batch_size - 1)//batch_size}")
            
            for file_path in batch:
                try:
                    result = self.import_parser.parse_file(file_path)
                    if not result.has_errors:  # Only include files that parse successfully
                        file_imports[file_path] = result
                except Exception as e:
                    logger.debug(f"Skipping {file_path}: {e}")
        
        logger.info(f"Successfully parsed {len(file_imports)} files for mechanical analysis")
        return file_imports
    
    def _validate_against_manifest(self, file_imports: Dict[Path, FileImports], 
                                 manifest_graph) -> List[ValidationDiscrepancy]:
        """Compare file imports against manifest declarations."""
        discrepancies = []
        
        # Build manifest lookup for ManifestNode objects
        manifest_nodes = manifest_graph.nodes
        manifest_by_id = {node.id: node for node in manifest_nodes}
        manifest_by_path = {node.path: node for node in manifest_nodes}
        
        # Collect all declared dependencies from edges
        declared_dependencies: Dict[str, Set[str]] = {}
        for node in manifest_nodes:
            node_id = node.id
            declared_dependencies[node_id] = set()
        
        # Add dependencies from edges
        for edge in manifest_graph.edges:
            if edge.relation in ['depends_on', 'imports']:
                if edge.from_id not in declared_dependencies:
                    declared_dependencies[edge.from_id] = set()
                declared_dependencies[edge.from_id].add(edge.to_id)
        
        # Collect all actual imports
        actual_imports: Dict[str, Set[str]] = {}
        for file_path, imports_data in file_imports.items():
            if imports_data.has_errors:
                continue
                
            # Convert file path to manifest node ID
            relative_path = file_path.relative_to(self.project_root)
            node_id = str(relative_path.with_suffix(''))
            
            actual_imports[node_id] = set()
            for imp in imports_data.imports:
                normalized = self.import_parser.normalize_module_path(imp.module, imp.source_file)
                if normalized:
                    actual_imports[node_id].add(normalized)
        
        # Check for missing declarations
        for importer_id, actual_deps in actual_imports.items():
            declared_deps = declared_dependencies.get(importer_id, set())
            
            for imported_module in actual_deps:
                if imported_module not in declared_deps:
                    # Import exists but not declared in manifest
                    discrepancies.append(ValidationDiscrepancy(
                        discrepancy_type=DiscrepancyType.MISSING_DECLARATION,
                        source_file=self.project_root / importer_id,
                        import_statement=None,
                        manifest_node=manifest_by_id.get(importer_id),
                        description=f"Import {imported_module} not declared in manifest for {importer_id}",
                        severity='error',
                        suggested_action=f"Add {imported_module} to depends_on for {importer_id}"
                    ))
        
        # Check for extra declarations
        for declarer_id, declared_deps in declared_dependencies.items():
            actual_deps = actual_imports.get(declarer_id, set())
            
            for declared_dep in declared_deps:
                if declared_dep not in actual_deps:
                    # Declared but not actually imported
                    discrepancies.append(ValidationDiscrepancy(
                        discrepancy_type=DiscrepancyType.EXTRA_DECLARATION,
                        source_file=self.project_root / declarer_id,
                        import_statement=None,
                        manifest_node=manifest_by_id.get(declarer_id),
                        description=f"Dependency {declared_dep} declared but not actually imported by {declarer_id}",
                        severity='warning',
                        suggested_action=f"Remove {declared_dep} from depends_on for {declarer_id} or add import"
                    ))
        
        # Check for broken imports
        for file_path, imports_data in file_imports.items():
            for imp in imports_data.imports:
                if imp.import_type in ['import', 'require']:
                    # Skip stdlib and installed packages - they're not broken imports
                    if self._is_stdlib_module(imp.module) or self._is_installed_package(imp.module):
                        continue
                    
                    # Only check relative imports for broken paths
                    if imp.module.startswith('./') or imp.module.startswith('../'):
                        resolved_path = self._resolve_import_path(imp.module, imp.source_file)
                        
                        if not resolved_path:
                            discrepancies.append(ValidationDiscrepancy(
                                discrepancy_type=DiscrepancyType.BROKEN_IMPORT,
                                source_file=imp.source_file,
                                import_statement=imp,
                                manifest_node=None,
                                description=f"Import target {imp.module} not found at line {imp.line_number}",
                                severity='error',
                                suggested_action=f"Create missing file or fix import path in {imp.source_file.name}"
                            ))
        
        # Check domain violations
        for file_path, imports_data in file_imports.items():
            for imp in imports_data.imports:
                violation = self._check_domain_violation(file_path, imp.module)
                if violation:
                    discrepancies.append(ValidationDiscrepancy(
                        discrepancy_type=DiscrepancyType.DOMAIN_VIOLATION,
                        source_file=file_path,
                        import_statement=imp,
                        manifest_node=None,
                        description=f"Domain boundary violation: {violation}",
                        severity='warning',
                        suggested_action="Consider architectural refactoring or explicit domain crossing"
                    ))
        
        return discrepancies
    
    def _resolve_import_path(self, import_module: str, source_file: Path) -> Optional[Path]:
        """Resolve import path using stack-agnostic contract-based resolver."""
        # First check if it's a relative import
        if import_module.startswith('./') or import_module.startswith('../'):
            return self.import_resolver.resolve_import(
                import_module=import_module,
                source_file=source_file,
                project_root=self.project_root
            )
        
        # Check if it's a Python standard library module
        if self._is_stdlib_module(import_module):
            return None  # Valid, but not a file
        
        # Check if it's an installed package
        if self._is_installed_package(import_module):
            return None  # Valid, but not a file
        
        # Only then try to resolve as a local file
        return self.import_resolver.resolve_import(
            import_module=import_module,
            source_file=source_file,
            project_root=self.project_root
        )
    
    def _is_stdlib_module(self, module_name: str) -> bool:
        """Check if module is part of Python standard library using dynamic discovery."""
        import sys
        import importlib.util
        
        try:
            # Use Python's own stdlib detection (Python 3.10+)
            if hasattr(sys, 'stdlib_module_names'):
                return module_name in sys.stdlib_module_names
            
            # Fallback: Use importlib.util.find_spec with path analysis
            spec = importlib.util.find_spec(module_name)
            if spec and spec.origin:
                # Check if it's in the stdlib path (not site-packages)
                stdlib_paths = [path for path in sys.path if 'site-packages' not in path and 'dist-packages' not in path]
                return any(spec.origin.startswith(path) for path in stdlib_paths)
            
            return False
        except (ImportError, ModuleNotFoundError, ValueError, AttributeError):
            return False
    
    def _is_installed_package(self, module_name: str) -> bool:
        """Check if module is an installed package using importlib.metadata."""
        try:
            # Use importlib.metadata (Python 3.8+) for proper package detection
            import importlib.metadata
            importlib.metadata.distribution(module_name)
            return True
        except importlib.metadata.PackageNotFoundError:
            pass
        except ImportError:
            # Fallback for older Python versions
            pass
        
        try:
            # Use pkg_resources as fallback
            import pkg_resources
            pkg_resources.get_distribution(module_name)
            return True
        except (pkg_resources.DistributionNotFound, ImportError):
            pass
        
        try:
            # Final fallback: check if it's in any site-packages directory
            import importlib.util
            import site
            
            spec = importlib.util.find_spec(module_name)
            if spec and spec.origin:
                # Check all possible site-packages locations
                site_packages = [Path(path) for path in site.getsitepackages() + [site.getusersitepackages()]]
                return any(spec.origin.startswith(str(path)) for path in site_packages)
        except (ImportError, ModuleNotFoundError, ValueError):
            pass
        
        return False
    
    def _check_domain_violation(self, source_file: Path, import_module: str) -> Optional[str]:
        """Check if import crosses domain boundaries."""
        # Get source domain
        source_path_parts = source_file.relative_to(self.project_root).parts
        source_domain = self._get_domain_for_path(source_path_parts)
        
        # Get target domain
        if import_module.startswith('./') or import_module.startswith('../'):
            # Relative import - calculate target path
            try:
                target_path = self.import_parser.normalize_module_path(import_module, source_file)
                if target_path:
                    target_path_parts = target_path.split('/')
                    target_domain = self._get_domain_for_path(target_path_parts)
                    
                    if source_domain != target_domain and source_domain and target_domain:
                        return f"{source_domain} -> {target_domain}"
            except (ValueError, FileNotFoundError):
                pass
        else:
            # Package import - skip domain check
            pass
        
        return None
    
    def _get_domain_for_path(self, path_parts: Tuple[str, ...]) -> Optional[str]:
        """Determine domain from path parts."""
        for domain, folders in self.domain_boundaries.items():
            if any(folder in path_parts for folder in folders):
                return domain
        return None
    
    # Health scoring now handled by UnifiedHealthScoringService
# This method is deprecated - use health_scoring_service.calculate_project_health()
    
    def analyze_subsystem(self, subsystem_pattern: str, response_tier: str = "L1") -> Dict[str, Any]:
        """Recursively analyze a specific subsystem for component-specific health scoring."""
        logger.info(f"Analyzing subsystem: {subsystem_pattern} (tier: {response_tier})")
        
        # Ultra-targeted discovery - only check specific known paths
        subsystem_files = []
        logger.info(f"Ultra-targeted discovery for subsystem: {subsystem_pattern}")
        
        # Hardcoded known paths for comburiscope to avoid any traversal
        known_paths = [
            "packages/dimstack_core/dimstack_core/comburiscope.py",
            "packages/dimstack_core/dimstack_core/comburiscope_chiral_test_harness.py",
            "packages/dimstack_core/dimstack_core/comburiscope_vault_sync.py",
            "apps/dimstack_api/dimstack_api/routers/comburiscope.py",
            "apps/dimstack_api/dimstack_api/routes/comburiscope.py",
            "apps/dimstack_cli/dimstack_cli/commands/comburiscope.py",
            "comburiscope_dial_up_integration.py",
            "test_comburiscope_refinement_pipeline.py",
            "test_comburiscope_chiral_efficiency.py"
        ]
        
        for path_str in known_paths:
            if subsystem_pattern.lower() in path_str.lower():
                file_path = self.project_root / path_str
                if file_path.exists() and file_path.suffix == '.py':
                    if not self.import_parser._should_skip_file(file_path):
                        subsystem_files.append(file_path)
                        logger.debug(f"Found: {file_path.name}")
        
        logger.info(f"Found {len(subsystem_files)} files via ultra-targeted discovery")
        
        if not subsystem_files:
            return {
                'subsystem': subsystem_pattern,
                'files_found': 0,
                'health_score': 0.0,
                'discrepancies': [],
                'message': f'No files found matching pattern: {subsystem_pattern}'
            }
        
        logger.info(f"Found {len(subsystem_files)} files in {subsystem_pattern} subsystem")
        
        # Parse subsystem files in batches to prevent hanging
        subsystem_imports = {}
        batch_size = 10  # Small batches for subsystem analysis
        
        logger.info(f"Parsing {len(subsystem_files)} subsystem files in batches of {batch_size}")
        for i in range(0, len(subsystem_files), batch_size):
            batch = subsystem_files[i:i + batch_size]
            logger.info(f"Processing batch {i//batch_size + 1}/{(len(subsystem_files) + batch_size - 1)//batch_size}")
            
            for file_path in batch:
                try:
                    result = self.import_parser.parse_file(file_path)
                    if not result.has_errors:
                        subsystem_imports[file_path] = result
                        logger.debug(f"Parsed {file_path.name}: {len(result.imports)} imports")
                except Exception as e:
                    logger.warning(f"Failed to parse {file_path}: {e}")
        
        logger.info(f"Successfully parsed {len(subsystem_imports)}/{len(subsystem_files)} subsystem files")
        
        # Build internal dependency graph for subsystem
        internal_deps = self._build_subsystem_dependency_graph(subsystem_imports, subsystem_pattern)
        
        # Analyze subsystem health
        subsystem_discrepancies = self._analyze_subsystem_health(subsystem_imports, internal_deps, subsystem_pattern)
        
        # Calculate subsystem-specific health score
        subsystem_health = self._calculate_subsystem_health_score(subsystem_discrepancies, len(subsystem_files))
        
        # Filter response based on tier
        result = {
            'subsystem': subsystem_pattern,
            'files_found': len(subsystem_files),
            'files_analyzed': len(subsystem_imports),
            'health_score': subsystem_health,
        }
        
        if response_tier in ["L1", "L2"]:
            result['discrepancies'] = subsystem_discrepancies
            result['component_breakdown'] = self._analyze_component_health(subsystem_imports)
        
        if response_tier == "L2":
            result['internal_dependencies'] = internal_deps
        
        return result
    
    def _build_subsystem_dependency_graph(self, file_imports: Dict[Path, FileImports], subsystem_pattern: str) -> Dict[str, List[str]]:
        """Build internal dependency graph for subsystem."""
        internal_deps = {}
        
        for file_path, imports_data in file_imports.items():
            file_key = file_path.name.replace('.py', '')
            internal_deps[file_key] = []
            
            for imp in imports_data.imports:
                # Check if import is within the same subsystem
                if subsystem_pattern.lower() in imp.module.lower():
                    internal_deps[file_key].append(imp.module)
        
        return internal_deps
    
    def _analyze_subsystem_health(self, file_imports: Dict[Path, FileImports], internal_deps: Dict[str, List[str]], subsystem_pattern: str) -> List[Dict[str, Any]]:
        """Analyze subsystem-specific health issues."""
        discrepancies = []
        
        for file_path, imports_data in file_imports.items():
            file_discrepancies = []
            
            for imp in imports_data.imports:
                # Check for missing internal dependencies
                if subsystem_pattern.lower() in imp.module.lower():
                    target_module = imp.module.split('.')[-1]
                    if target_module not in internal_deps:
                        file_discrepancies.append({
                            'type': 'missing_internal_dependency',
                            'module': imp.module,
                            'severity': 'error',
                            'description': f'Internal dependency {imp.module} not found in subsystem'
                        })
                # Check for external dependency issues
                elif not self._is_stdlib_module(imp.module) and not self._is_installed_package(imp.module):
                    file_discrepancies.append({
                        'type': 'missing_external_dependency',
                        'module': imp.module,
                        'severity': 'warning',
                        'description': f'External dependency {imp.module} may be missing'
                    })
            
            if file_discrepancies:
                discrepancies.append({
                    'file': str(file_path.relative_to(self.project_root)),
                    'issues': file_discrepancies
                })
        
        return discrepancies
    
    def _calculate_subsystem_health_score(self, discrepancies: List[Dict[str, Any]], file_count: int) -> float:
        """Calculate health score specific to subsystem context."""
        if file_count == 0:
            return 0.0
        
        # Count issues by severity
        error_count = sum(len([d for d in disc['issues'] if d['severity'] == 'error']) for disc in discrepancies)
        warning_count = sum(len([d for d in disc['issues'] if d['severity'] == 'warning']) for disc in discrepancies)
        
        # Subsystem-specific scoring (more lenient for manifest warnings)
        total_penalty = (error_count * 3.0 + warning_count * 0.2)
        
        # Scale by subsystem size
        size_factor = min(1.0, 20.0 / max(file_count, 1))
        adjusted_penalty = total_penalty * size_factor
        
        health_score = max(0.0, 100.0 - adjusted_penalty)
        return health_score / 100.0
    
    def _analyze_component_health(self, file_imports: Dict[Path, FileImports]) -> Dict[str, Dict[str, Any]]:
        """Analyze health of individual components within subsystem."""
        component_health = {}
        
        for file_path, imports_data in file_imports.items():
            component_name = file_path.name.replace('.py', '')
            
            # Count imports by type
            stdlib_imports = sum(1 for imp in imports_data.imports if self._is_stdlib_module(imp.module))
            external_imports = sum(1 for imp in imports_data.imports if self._is_installed_package(imp.module))
            internal_imports = sum(1 for imp in imports_data.imports if not self._is_stdlib_module(imp.module) and not self._is_installed_package(imp.module))
            
            component_health[component_name] = {
                'total_imports': len(imports_data.imports),
                'stdlib_imports': stdlib_imports,
                'external_imports': external_imports,
                'internal_imports': internal_imports,
                'path': str(file_path.relative_to(self.project_root))
            }
        
        return component_health
    
    def discover_all_subsystems(self, response_tier: str = "L0") -> Dict[str, Any]:
        """Dynamically discover and analyze all subsystems mechanically."""
        logger.info("Starting mechanical subsystem discovery")
        
        # Discover subsystem candidates from file structure
        subsystem_candidates = set()
        
        # Check packages/dimstack_core for core modules
        core_dir = self.project_root / "packages" / "dimstack_core" / "dimstack_core"
        if core_dir.exists():
            for file_path in core_dir.glob("*.py"):
                if file_path.name != "__init__.py":
                    # Extract subsystem name from filename
                    name_parts = file_path.stem.split('_')
                    if len(name_parts) >= 2:
                        subsystem_candidates.add('_'.join(name_parts[:2]))
                    else:
                        subsystem_candidates.add(name_parts[0])
        
        # Check root level for subsystem patterns
        for file_path in self.project_root.glob("*.py"):
            name_parts = file_path.stem.split('_')
            if len(name_parts) >= 2:
                subsystem_candidates.add('_'.join(name_parts[:2]))
            else:
                subsystem_candidates.add(name_parts[0])
        
        # Analyze each discovered subsystem
        results = {}
        healthy_count = 0
        problematic_count = 0
        
        for subsystem in sorted(subsystem_candidates):
            try:
                result = self.analyze_subsystem(subsystem, response_tier)
                if result['files_found'] > 0:
                    results[subsystem] = result
                    if result['health_score'] > 30.0:
                        healthy_count += 1
                    else:
                        problematic_count += 1
            except Exception as e:
                logger.debug(f"Failed to analyze {subsystem}: {e}")
        
        return {
            'total_subsystems': len(results),
            'healthy_subsystems': healthy_count,
            'problematic_subsystems': problematic_count,
            'results': results
        }
    
    def _load_domain_boundaries(self) -> Dict[str, List[str]]:
        """Load domain boundaries dynamically from configuration."""
        boundaries = {}
        
        # Load from .forge/manifest.yaml
        manifest_path = self.project_root / ".forge" / "manifest.yaml"
        if manifest_path.exists():
            try:
                import yaml
                with open(manifest_path) as f:
                    manifest = yaml.load(f, Loader=yaml.SafeLoader)
                
                domains = manifest.get('domains', {})
                for domain_name, domain_config in domains.items():
                    boundaries[domain_name] = domain_config.get('path_patterns', [])
            except Exception as e:
                logger.warning(f"Failed to load domains from manifest: {e}")
        
        # Load from glove configuration
        glove_paths = [
            self.project_root / ".forge" / "glove.yaml",
            self.project_root / "glove.yaml"
        ]
        
        for glove_path in glove_paths:
            if glove_path.exists():
                try:
                    import yaml
                    with open(glove_path) as f:
                        glove_config = yaml.load(f, Loader=yaml.SafeLoader)
                    
                    domains = glove_config.get('domains', {})
                    for domain_name, domain_config in domains.items():
                        boundaries[domain_name] = domain_config.get('path_patterns', [])
                    break  # Use first found glove config
                except Exception as e:
                    logger.warning(f"Failed to load glove config: {e}")
        
        # Set up default domains if none found
        if not boundaries:
            boundaries = {
                'core': ['forge/core/', 'src/core/'],
                'commands': ['forge/commands/', 'src/commands/'],
                'ui': ['src/ui/', 'src/components/', 'src/views/'],
                'utils': ['src/utils/', 'forge/utils/'],
                'strategies': ['forge/strategies/', 'src/strategies/'],
                'contracts': ['forge/contracts/', 'src/contracts/']
            }
        
        return boundaries
    
    def _generate_summary(self, discrepancies: List[ValidationDiscrepancy],
                         file_imports: Dict[Path, FileImports],
                         manifest_nodes: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate validation summary."""
        # Count by type
        by_type = {}
        for discrepancy in discrepancies:
            dtype = discrepancy.discrepancy_type.value
            by_type[dtype] = by_type.get(dtype, 0) + 1
        
        # Count by severity
        by_severity = {'error': 0, 'warning': 0, 'info': 0}
        for discrepancy in discrepancies:
            by_severity[discrepancy.severity] += 1
        
        # Most common issues
        error_descriptions = [d.description for d in discrepancies if d.severity == 'error']
        common_errors = {}
        for desc in error_descriptions:
            common_errors[desc] = common_errors.get(desc, 0) + 1
        
        return {
            'discrepancies_by_type': by_type,
            'discrepancies_by_severity': by_severity,
            'most_common_errors': sorted(common_errors.items(), key=lambda x: x[1], reverse=True)[:5],
            'total_files': len(file_imports),
            'total_manifest_nodes': len(manifest_nodes),
            'validation_timestamp': datetime.now().isoformat()
        }
    
    def _validate_against_execution(self, file_imports: Dict[Path, FileImports], 
                                  execution_nodes: List) -> List[ValidationDiscrepancy]:
        """Compare file imports against execution graph nodes."""
        discrepancies = []
        
        # Build execution node lookup
        execution_by_file = {node.file: node for node in execution_nodes}
        execution_by_module = {node.module: node for node in execution_nodes}
        
        # Check for files that import but don't appear in execution graph
        for file_path, imports_data in file_imports.items():
            file_str = str(file_path)
            if file_str not in execution_by_file and imports_data.imports:
                discrepancies.append(ValidationDiscrepancy(
                    discrepancy_type=DiscrepancyType.MISSING_DECLARATION,
                    source_file=file_path,
                    import_statement=None,
                    manifest_node=None,
                    description=f"File has imports but no execution record: {file_path.name}",
                    severity='warning',
                    suggested_action="File may not be executed at runtime (check if it's library code)"
                ))
        
        # Check for execution nodes that aren't imported from
        for node in execution_nodes:
            if node.call_count > 0:  # Only check nodes that were actually executed
                # Check if this execution node corresponds to a file we've analyzed
                corresponding_file = None
                for file_path in file_imports:
                    if node.module in str(file_path) or node.file in str(file_path):
                        corresponding_file = file_path
                        break
                
                if not corresponding_file:
                    discrepancies.append(ValidationDiscrepancy(
                        discrepancy_type=DiscrepancyType.EXTRA_DECLARATION,
                        source_file=Path(node.file),
                        import_statement=None,
                        manifest_node=None,
                        description=f"Execution node {node.module} executed but not found in source analysis",
                        severity='info',
                        suggested_action="May be dynamically loaded or generated code"
                    ))
        
        return discrepancies
    
    def _validate_against_contracts(self, file_imports: Dict[Path, FileImports], 
                                   contract_edges: List) -> List[ValidationDiscrepancy]:
        """Compare file imports against contract graph edges."""
        discrepancies = []
        
        # Check for contract violations
        for file_path, imports_data in file_imports.items():
            for imp in imports_data.imports:
                # Check if this import violates any contracts
                for edge in contract_edges:
                    # Simple contract violation check (can be expanded)
                    if hasattr(edge, 'relation') and edge.relation == 'forbidden' and imp.module == edge.target_project:
                        discrepancies.append(ValidationDiscrepancy(
                            discrepancy_type=DiscrepancyType.DOMAIN_VIOLATION,
                            source_file=file_path,
                            import_statement=imp,
                            manifest_node=None,
                            description=f"Import {imp.module} violates contract: {edge.source_project} -> {edge.target_project}",
                            severity='error',
                            suggested_action=f"Remove forbidden import {imp.module}"
                        ))
        
        return discrepancies
    
    def _generate_comprehensive_summary(self, discrepancies: List[ValidationDiscrepancy],
                                       file_imports: Dict[Path, FileImports],
                                       manifest_graph, execution_graph, contract_graph) -> Dict[str, Any]:
        """Generate comprehensive validation summary across all graphs."""
        # Count by type
        by_type = {}
        for discrepancy in discrepancies:
            dtype = discrepancy.discrepancy_type.value
            by_type[dtype] = by_type.get(dtype, 0) + 1
        
        # Count by severity
        by_severity = {'error': 0, 'warning': 0, 'info': 0}
        for discrepancy in discrepancies:
            by_severity[discrepancy.severity] += 1
        
        # Graph coverage analysis
        graph_coverage = {
            'manifest_nodes': len(manifest_graph.nodes),
            'execution_nodes': len(execution_graph.nodes),
            'contract_edges': len(contract_graph.edges),
            'total_graph_nodes': len(manifest_graph.nodes) + len(execution_graph.nodes) + len(contract_graph.edges),
            'files_analyzed': len(file_imports)
        }
        
        # Cross-graph consistency
        cross_graph_issues = []
        if len(manifest_graph.nodes) > 0 and len(execution_graph.nodes) > 0:
            manifest_modules = {node.id for node in manifest_graph.nodes}
            execution_modules = {node.module for node in execution_graph.nodes}
            
            # Modules in manifest but not executed
            missing_execution = manifest_modules - execution_modules
            if missing_execution:
                cross_graph_issues.append(f"{len(missing_execution)} manifest nodes not executed")
            
            # Modules executed but not in manifest
            extra_execution = execution_modules - manifest_modules
            if extra_execution:
                cross_graph_issues.append(f"{len(extra_execution)} executed modules not in manifest")
        
        return {
            'discrepancies_by_type': by_type,
            'discrepancies_by_severity': by_severity,
            'graph_coverage': graph_coverage,
            'cross_graph_issues': cross_graph_issues,
            'validation_timestamp': datetime.now().isoformat(),
            'graphs_validated': ['manifest', 'execution', 'contract']
        }
