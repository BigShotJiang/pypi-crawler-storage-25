"""
Graph-Based Health Metrics

Quantifiable health scoring based on execution/declaration graph ratios.
Eliminates arbitrary penalties in favor of measurable operational metrics.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Any, Literal
from pathlib import Path
from enum import Enum

from forge.tools.manifest.graph import build_manifest_graph, ManifestNode, ManifestEdge
from forge.core.execution_graph import ExecutionGraph, get_execution_manager
from forge.core.contract_graph import ContractGraph


class MetricType(Enum):
    """Types of health metrics."""
    DECLARATION_COVERAGE = "declaration_coverage"
    EDGE_INTEGRITY = "edge_integrity"
    DOMAIN_COMPLETENESS = "domain_completeness"
    EXECUTION_TRACE_COVERAGE = "execution_trace_coverage"
    CONTRACT_SATISFACTION = "contract_satisfaction"


@dataclass
class HealthMetric:
    metric_type: MetricType
    declared_count: int
    actual_count: int
    success_rate: Optional[float]  # None = unavailable
    status: Literal["measured", "unavailable", "error"]
    source_layer: Literal["declaration", "execution", "contract"]
    details: Dict[str, Any]
    unavailable_reason: Optional[str] = None

    @property
    def is_healthy(self) -> bool:
        if self.success_rate is None:
            return True  # unavailable is not unhealthy
        return self.success_rate >= 0.7

    @property
    def display_score(self) -> str:
        if self.success_rate is None:
            return "—  (unavailable)"
        return f"{self.success_rate:.1%}"


@dataclass
class GraphHealthResult:
    overall_health: Optional[float]
    metrics: List[HealthMetric]
    score_note: Optional[str] = None
    summary: Dict[str, Any] = None


class GraphHealthAnalyzer:
    """
    Analyzes graph-based health metrics using quantifiable ratios.
    
    Principles:
    1. No arbitrary penalties - only measurable ratios
    2. Stack-agnostic - works with any Forge-compliant project
    3. Efficient - lazy loading and caching
    4. Clear semantics - each metric has clear meaning
    """
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.project_path = project_root
        self._manifest_graph = None
        self._execution_graph = None
        self._contract_graph = None
    
    @property
    def manifest_graph(self):
        """Lazy load manifest graph."""
        if self._manifest_graph is None:
            self._manifest_graph = build_manifest_graph(self.project_root)
        return self._manifest_graph
    
    def _load_latest_trace_data(self) -> Optional[Dict[str, Any]]:
        """Load the most recent trace file and return trace data."""
        from forge.core.execution_graph import ExecutionGraph
        import json
        import yaml
        
        trace_dir = self.project_path / ".forge" / "traces"
        if not trace_dir.exists() or not any(trace_dir.iterdir()):
            return None
        
        # Get the most recent trace file
        trace_files = list(trace_dir.iterdir())
        trace_files.sort(key=lambda f: f.stat().st_mtime, reverse=True)
        latest_file = trace_files[0]
        
        # Load the trace data
        try:
            if latest_file.suffix == '.json':
                data = json.loads(latest_file.read_text())
            else:
                data = yaml.safe_load(latest_file.read_text())
            
            return data.get('trace', {})
        except Exception:
            return None
    
    @property
    def execution_graph(self):
        """Lazy load execution graph from trace files."""
        if self._execution_graph is None:
            trace_data = self._load_latest_trace_data()
            if trace_data:
                # Create ExecutionGraph and populate with trace data
                self._execution_graph = ExecutionGraph()
                
                # Load nodes from trace data
                for node_data in trace_data.get('nodes', []):
                    from forge.core.execution_graph import ExecutionNode
                    node = ExecutionNode(
                        id=node_data['id'],
                        kind=node_data['kind'],
                        module=node_data['module'],
                        qualname=node_data['qualname'],
                        file=node_data['file'],
                        line=node_data['line'],
                        call_count=node_data.get('call_count', 1),
                        stack=node_data.get('stack', 'python'),
                        layer=node_data.get('layer', 'execution')
                    )
                    self._execution_graph.nodes[node.id] = node
                
                # Load edges from trace data
                for edge_data in trace_data.get('edges', []):
                    from forge.core.execution_graph import ExecutionEdge
                    edge = ExecutionEdge(
                        id=edge_data['id'],
                        from_id=edge_data['from_id'],
                        to_id=edge_data['to_id'],
                        edge_kind=edge_data.get('edge_kind', 'calls'),
                        call_count=edge_data.get('call_count', 1),
                        layer=edge_data.get('layer', 'execution')
                    )
                    self._execution_graph.edges[edge.id] = edge
            else:
                # No trace data available
                execution_manager = get_execution_manager(self.project_root)
                self._execution_graph = ExecutionGraph()
        
        return self._execution_graph
    
    @property
    def contract_graph(self):
        """Lazy load contract graph."""
        if self._contract_graph is None:
            self._contract_graph = ContractGraph()
        return self._contract_graph
    
    def analyze_declaration_coverage(self) -> HealthMetric:
        nodes = list(getattr(self.manifest_graph, "nodes", []))
        declared_count = len(nodes)
        if declared_count == 0:
            return HealthMetric(
                metric_type=MetricType.DECLARATION_COVERAGE,
                declared_count=0, actual_count=0,
                success_rate=None, status="error",
                source_layer="declaration",
                details={}, unavailable_reason="manifest graph is empty"
            )
        nodes_with_path = 0
        for node in nodes:
            path = str(getattr(node, "path", "") or "")
            if path and (self.project_path / path).exists():
                nodes_with_path += 1
        return HealthMetric(
            metric_type=MetricType.DECLARATION_COVERAGE,
            declared_count=declared_count,
            actual_count=nodes_with_path,
            success_rate=nodes_with_path / declared_count,
            status="measured",
            source_layer="declaration",
            details={
                "declared_nodes": declared_count,
                "nodes_with_real_path": nodes_with_path,
                "nodes_without_path": declared_count - nodes_with_path,
            }
        )
    
    def analyze_edge_integrity(self) -> HealthMetric:
        nodes = list(getattr(self.manifest_graph, "nodes", []))
        edges = list(getattr(self.manifest_graph, "edges", []))
        node_ids = {str(getattr(n, "id", "")) for n in nodes}
        
        declared_edges = [
            e for e in edges
            if not bool(getattr(e, "derived", False))
        ]
        declared_count = len(declared_edges)
        if declared_count == 0:
            return HealthMetric(
                metric_type=MetricType.EDGE_INTEGRITY,
                declared_count=0, actual_count=0,
                success_rate=1.0, status="measured",
                source_layer="declaration",
                details={"declared_edges": 0, "resolvable_edges": 0}
            )
        resolvable = sum(
            1 for e in declared_edges
            if str(getattr(e, "from_id", "")) in node_ids
            and str(getattr(e, "to_id", "")) in node_ids
        )
        return HealthMetric(
            metric_type=MetricType.EDGE_INTEGRITY,
            declared_count=declared_count,
            actual_count=resolvable,
            success_rate=resolvable / declared_count,
            status="measured",
            source_layer="declaration",
            details={
                "declared_edges": declared_count,
                "resolvable_edges": resolvable,
                "broken_edges": declared_count - resolvable,
            }
        )
    
    def analyze_domain_completeness(self) -> HealthMetric:
        nodes = list(getattr(self.manifest_graph, "nodes", []))
        all_domains = {
            str(getattr(n, "domain", "") or "")
            for n in nodes
            if str(getattr(n, "domain", "") or "").strip()
        }
        populated = {
            str(getattr(n, "domain", "") or "")
            for n in nodes
            if str(getattr(n, "kind", "") or "") != "domain"
            and str(getattr(n, "domain", "") or "").strip()
        }
        declared_count = len(all_domains)
        actual_count = len(populated)
        if declared_count == 0:
            return HealthMetric(
                metric_type=MetricType.DOMAIN_COMPLETENESS,
                declared_count=0, actual_count=0,
                success_rate=None, status="error",
                source_layer="declaration",
                details={}, unavailable_reason="no domains in manifest"
            )
        return HealthMetric(
            metric_type=MetricType.DOMAIN_COMPLETENESS,
            declared_count=declared_count,
            actual_count=actual_count,
            success_rate=actual_count / declared_count,
            status="measured",
            source_layer="declaration",
            details={
                "total_domains": declared_count,
                "populated_domains": actual_count,
                "empty_domains": sorted(all_domains - populated),
            }
        )
    
    def analyze_execution_trace_coverage(self) -> HealthMetric:
        from forge.core.trace_mapper import get_mapper
        
        trace_dir = self.project_path / ".forge" / "traces"
        has_traces = trace_dir.exists() and any(trace_dir.iterdir())
        
        if not has_traces:
            return HealthMetric(
                metric_type=MetricType.EXECUTION_TRACE_COVERAGE,
                declared_count=0, actual_count=0,
                success_rate=None, status="unavailable",
                source_layer="execution",
                details={},
                unavailable_reason="Run `forge trace` to populate execution data"
            )
        
        # Get stack from manifest to select correct mapper
        stack = "python-cli"  # default
        try:
            from forge.core.manifest_document import ManifestDocument
            doc = ManifestDocument.from_path(self.project_path)
            stack = doc.stack or "python-cli"
        except Exception:
            pass
        
        mapper = get_mapper(stack)
        
        # Load manifest node IDs
        manifest_nodes = list(getattr(self.manifest_graph, "nodes", []))
        manifest_ids = {str(getattr(n, "id", "")) for n in manifest_nodes}
        declared_count = len(manifest_ids)
        
        # Load trace node IDs and map them to manifest IDs
        traced_manifest_ids: set[str] = set()
        trace_errors = 0
        
        try:
            exec_nodes = list(self.execution_graph.nodes.values())
            for node in exec_nodes:
                trace_id = str(getattr(node, "id", "") or 
                              getattr(node, "qualname", "") or
                              getattr(node, "module", ""))
                if not trace_id:
                    continue
                mapped = mapper.map(trace_id)
                if mapped and mapped in manifest_ids:
                    traced_manifest_ids.add(mapped)
        except Exception as e:
            trace_errors += 1
        
        traced_count = len(traced_manifest_ids)
        
        return HealthMetric(
            metric_type=MetricType.EXECUTION_TRACE_COVERAGE,
            declared_count=declared_count,
            actual_count=traced_count,
            success_rate=traced_count / max(declared_count, 1),
            status="measured",
            source_layer="execution",
            details={
                "declared_nodes": declared_count,
                "traced_nodes": traced_count,
                "stack": stack,
                "mapper": mapper.__class__.__name__,
                "trace_errors": trace_errors,
            }
        )
    
    def analyze_contract_satisfaction(self) -> HealthMetric:
        try:
            contract_edges = list(getattr(self.contract_graph, "edges", []))
        except Exception:
            contract_edges = []
        
        if not contract_edges:
            return HealthMetric(
                metric_type=MetricType.CONTRACT_SATISFACTION,
                declared_count=0, actual_count=0,
                success_rate=None, status="unavailable",
                source_layer="contract",
                details={},
                unavailable_reason="No glove contracts configured for this project"
            )
        
        declared_count = len(contract_edges)
        # Only count satisfied contracts — edges with satisfied=True in meta
        satisfied = sum(
            1 for e in contract_edges
            if bool((getattr(e, "meta", {}) or {}).get("satisfied", False))
        )
        return HealthMetric(
            metric_type=MetricType.CONTRACT_SATISFACTION,
            declared_count=declared_count,
            actual_count=satisfied,
            success_rate=satisfied / declared_count,
            status="measured",
            source_layer="contract",
            details={
                "declared_contracts": declared_count,
                "satisfied_contracts": satisfied,
            }
        )
    
    def analyze_overall_health(self) -> GraphHealthResult:
        metrics = [
            self.analyze_declaration_coverage(),
            self.analyze_edge_integrity(),
            self.analyze_domain_completeness(),
            self.analyze_execution_trace_coverage(),
            self.analyze_contract_satisfaction(),
        ]
        
        measured = [m for m in metrics if m.status == "measured"]
        
        if not measured:
            overall = None
            score_note = "No metrics available"
        else:
            overall = sum(m.success_rate for m in measured) / len(measured)
            layer_names = {m.source_layer for m in measured}
            if layer_names == {"declaration"}:
                score_note = (
                    "Score based on declaration graph only. "
                    "Run `forge trace` for execution coverage."
                )
            else:
                score_note = f"Score based on layers: {', '.join(sorted(layer_names))}"
        
        return GraphHealthResult(
            overall_health=overall,
            metrics=metrics,
            score_note=score_note,
            summary={
                "measured_metrics": len(measured),
                "unavailable_metrics": sum(
                    1 for m in metrics if m.status == "unavailable"
                ),
                "error_metrics": sum(
                    1 for m in metrics if m.status == "error"
                ),
            }
        )


def analyze_project_graph_health(project_root: Path) -> GraphHealthResult:
    """
    Analyze graph health for a project.
    
    Args:
        project_root: Path to the project root
        
    Returns:
        GraphHealthResult with quantifiable metrics
    """
    analyzer = GraphHealthAnalyzer(project_root)
    return analyzer.analyze_overall_health()
