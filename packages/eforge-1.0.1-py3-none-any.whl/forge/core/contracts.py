from __future__ import annotations

from dataclasses import asdict, dataclass, field, replace
from typing import Any

__all__ = [
    "ContractParam",
    "RawContract",
    "ContractViolation",
    "ContractRecord",
    "build_contract_registry",
]


@dataclass
class ContractParam:
    name: str
    type: str | None
    required: bool
    default: str | None


@dataclass
class RawContract:
    node_id: str
    method: str
    contract_type: str = "callable"
    params: list[ContractParam] = field(default_factory=list)
    returns: str | None = None
    raises: list[str] = field(default_factory=list)
    async_boundary: bool = False
    layer: str = "declaration"
    boundary_kind: str = "sync"
    in_count: int = 0
    out_count: int = 0
    type_annotations: dict[str, Any] = field(default_factory=dict)
    # Glove / legacy fields (single canonical definition — see forge.core.gloves).
    direction: str = "out"
    type_declared: str | None = None
    payload: dict[str, Any] = field(default_factory=dict)


@dataclass
class ContractViolation:
    caller_node: str
    callee_node: str
    method: str
    violation_kind: str
    expected: str
    actual: str
    file: str
    line: int
    symbol: str
    severity: str


@dataclass(frozen=True)
class ContractRecord:
    """Typed registry row: manifest node, its primary contract slice, and violations (usually empty here)."""

    node_id: str
    contract: RawContract
    violations: list[ContractViolation] = field(default_factory=list)

    def to_jsonable(self) -> dict[str, Any]:
        """JSON shape compatible with pre-typed ``build_contract_registry`` consumers."""
        reg = (self.contract.type_annotations or {}).get("_registry") or {}
        out: dict[str, Any] = {
            "node_id": self.node_id,
            "contract_type": self.contract.contract_type,
            "in_count": int(reg.get("in_count", self.contract.in_count)),
            "out_count": int(reg.get("out_count", self.contract.out_count)),
            "boundary_kind": str(reg.get("boundary_kind") or self.contract.boundary_kind or "sync"),
            "contract_count": int(reg.get("contract_count", self.contract.in_count + self.contract.out_count)),
            "in_edges": list(reg.get("in_edges") or []),
            "out_edges": list(reg.get("out_edges") or []),
            "contract": asdict(self.contract),
            "violations": [asdict(v) for v in self.violations],
        }
        return out


def _iter_registry_edge_payloads(graph: Any) -> list[dict[str, Any]]:
    """Edges used for contract registry aggregation (``contract`` / ``calls`` / ``queries``)."""
    from forge.tools.manifest.graph import ManifestGraph

    allowed = {"contract", "calls", "queries"}
    rows: list[dict[str, Any]] = []
    if isinstance(graph, ManifestGraph):
        import forge.core.query as _core_query

        _core_query.forge_query(
            graph,
            kind="module",
            where={},
            limit=10**9,
            depth=1,
            direction="both",
        )
        for edge in graph.edges:
            if str(edge.relation) not in allowed:
                continue
            meta = dict(edge.meta or {})
            from_id = str(edge.from_id)
            to_id = str(edge.to_id)
            rows.append(
                {
                    "from_id": from_id,
                    "to_id": to_id,
                    "edge_kind": str(meta.get("edge_kind") or edge.relation),
                    "method": str(meta.get("method") or ""),
                    "type_annotations": dict(meta.get("type_annotations") or {}),
                    "boundary_kind": str(meta.get("boundary_kind") or "sync"),
                    "async_boundary": bool(meta.get("async_boundary", False)),
                }
            )
        return rows
    for edge in getattr(graph, "edges", []):
        if str(getattr(edge, "relation", "")) not in allowed:
            continue
        from_id = str(getattr(edge, "from_id", ""))
        to_id = str(getattr(edge, "to_id", ""))
        meta = dict(getattr(edge, "meta", {}) or {})
        rows.append(
            {
                "from_id": from_id,
                "to_id": to_id,
                "edge_kind": str(meta.get("edge_kind") or getattr(edge, "relation", "")),
                "method": str(meta.get("method") or ""),
                "type_annotations": dict(meta.get("type_annotations") or {}),
                "boundary_kind": str(meta.get("boundary_kind") or "sync"),
                "async_boundary": bool(meta.get("async_boundary", False)),
            }
        )
    return rows


def build_contract_registry(graph: Any, contracts: dict[str, list[RawContract]]) -> list[ContractRecord]:
    by_node: dict[str, dict[str, Any]] = {}
    for node_id, rows in contracts.items():
        base = by_node.setdefault(
            str(node_id),
            {
                "node_id": str(node_id),
                "contract_type": "callable",
                "in_edges": [],
                "out_edges": [],
            },
        )
        if rows:
            base["contract_type"] = str(getattr(rows[0], "contract_type", "callable") or "callable")
    for payload in _iter_registry_edge_payloads(graph):
        from_id = str(payload["from_id"])
        to_id = str(payload["to_id"])
        edge_payload = {
            "from_id": from_id,
            "to_id": to_id,
            "edge_kind": str(payload.get("edge_kind") or ""),
            "method": str(payload.get("method") or ""),
            "type_annotations": dict(payload.get("type_annotations") or {}),
            "boundary_kind": str(payload.get("boundary_kind") or "sync"),
            "async_boundary": bool(payload.get("async_boundary", False)),
        }
        by_node.setdefault(
            from_id,
            {"node_id": from_id, "contract_type": "callable", "in_edges": [], "out_edges": []},
        )["out_edges"].append(edge_payload)
        by_node.setdefault(
            to_id,
            {"node_id": to_id, "contract_type": "callable", "in_edges": [], "out_edges": []},
        )["in_edges"].append(edge_payload)

    out: list[ContractRecord] = []
    for node_id, row in sorted(by_node.items(), key=lambda kv: str(kv[0])):
        in_edges = list(row.get("in_edges") or [])
        out_edges = list(row.get("out_edges") or [])
        boundary_kind = "async" if any(bool(e.get("async_boundary")) for e in [*in_edges, *out_edges]) else "sync"
        ctype = str(row.get("contract_type") or "callable")
        registry_meta = {
            "in_edges": in_edges,
            "out_edges": out_edges,
            "in_count": len(in_edges),
            "out_count": len(out_edges),
            "contract_count": len(in_edges) + len(out_edges),
            "boundary_kind": boundary_kind,
        }
        rows = contracts.get(node_id) or []
        if rows:
            first = rows[0]
            merged_ta = {**dict(first.type_annotations), "_registry": registry_meta}
            contract = replace(
                first,
                contract_type=ctype,
                boundary_kind=boundary_kind,
                in_count=len(in_edges),
                out_count=len(out_edges),
                type_annotations=merged_ta,
            )
        else:
            contract = RawContract(
                node_id=node_id,
                method="",
                contract_type=ctype,
                boundary_kind=boundary_kind,
                in_count=len(in_edges),
                out_count=len(out_edges),
                type_annotations={"_registry": registry_meta},
            )
        out.append(ContractRecord(node_id=node_id, contract=contract, violations=[]))
    return out
