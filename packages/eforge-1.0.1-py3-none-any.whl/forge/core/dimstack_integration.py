"""Dimstack integration with Forge systems.

Integrates the mathematical canonicalization pipeline with intent graph,
manifest verification, audit scan, and vector memory systems.
"""

import logging
from typing import Any, Dict, List, Optional, Set, Tuple

from forge.core.dimstack import (
    InvariantAtomic,
    TruthLayer,
    get_dimstack_pipeline,
    canonicalize_forge_content,
    find_semantic_equivalence
)
from forge.core.path_utils import resolve_project_path

logger = logging.getLogger(__name__)


class IntentGraphQualityEnhancer:
    """Enhances intent graph quality using dimstack semantic decomposition."""
    
    def __init__(self, project_path):
        self.project_path = project_path
        self.dimstack = get_dimstack_pipeline(project_path)
    
    def extract_semantic_nodes(self, raw_description: str) -> List[str]:
        """Extract semantic nodes using invariant atomic decomposition.
        
        Replaces NLP word tokenization with invariant-preserving semantic decomposition.
        """
        try:
            # Canonicalize using dimstack
            atomics = self.dimstack.canonicalize_content(raw_description)
            
            # Extract semantic nodes from invariant atomics
            semantic_nodes = []
            
            for atomic in atomics:
                # Use canonical form as semantic node
                node = atomic.canonical_form
                
                # Add semantic type as prefix for clarity
                if atomic.semantic_type:
                    node = f"{atomic.semantic_type}:{node}"
                
                semantic_nodes.append(node)
            
            # Remove duplicates while preserving order
            seen = set()
            unique_nodes = []
            for node in semantic_nodes:
                if node not in seen:
                    seen.add(node)
                    unique_nodes.append(node)
            
            return unique_nodes
            
        except Exception as e:
            logger.error(f"Failed to extract semantic nodes: {e}")
            # Fallback to simple tokenization
            return self._fallback_tokenization(raw_description)
    
    def _fallback_tokenization(self, content: str) -> List[str]:
        """Fallback tokenization if dimstack fails."""
        import re
        
        # Simple word tokenization
        words = re.findall(r'\b\w+\b', content.lower())
        
        # Remove stop words
        stop_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'of', 'with', 'by', 'as', 'is', 'are', 'was', 'were', 'be', 'been'
        }
        
        return [w for w in words if w not in stop_words and len(w) > 2]
    
    def enhance_intent_record(self, intent_data: Dict[str, Any]) -> Dict[str, Any]:
        """Enhance intent record with semantic decomposition."""
        try:
            raw_description = intent_data.get("raw_description", "")
            
            # Extract semantic nodes using dimstack
            semantic_nodes = self.extract_semantic_nodes(raw_description)
            
            # Create enhanced record
            enhanced = intent_data.copy()
            enhanced["extracted_nodes"] = semantic_nodes
            enhanced["semantic_decomposition"] = True
            enhanced["decomposition_method"] = "dimstack"
            
            return enhanced
            
        except Exception as e:
            logger.error(f"Failed to enhance intent record: {e}")
            return intent_data


class ManifestGraphVerifier:
    """Uses transformation-based equivalence checking for manifest graph verification."""
    
    def __init__(self, project_path):
        self.project_path = project_path
        self.dimstack = get_dimstack_pipeline(project_path)
    
    def check_semantic_equivalence(self, node1_data: Dict[str, Any], 
                                  node2_data: Dict[str, Any]) -> bool:
        """Check if two node definitions are semantically identical.
        
        Uses transformation-based equivalence checking to detect semantic identity
        even when syntactically different.
        """
        try:
            # Extract content from node data
            content1 = self._extract_node_content(node1_data)
            content2 = self._extract_node_content(node2_data)
            
            if not content1 or not content2:
                return False
            
            # Use dimstack to check semantic equivalence
            return find_semantic_equivalence(content1, content2, str(self.project_path))
            
        except Exception as e:
            logger.error(f"Failed to check semantic equivalence: {e}")
            return False
    
    def _extract_node_content(self, node_data: Dict[str, Any]) -> str:
        """Extract meaningful content from node data."""
        content_parts = []
        
        # Extract description
        if "description" in node_data:
            content_parts.append(node_data["description"])
        
        # Extract purpose
        if "purpose" in node_data:
            content_parts.append(node_data["purpose"])
        
        # Extract other meaningful fields
        for field in ["title", "name", "summary"]:
            if field in node_data:
                content_parts.append(node_data[field])
        
        return " ".join(content_parts)
    
    def find_duplicate_nodes(self, manifest_nodes: Dict[str, Any]) -> List[Tuple[str, str]]:
        """Find semantically duplicate nodes in manifest."""
        duplicates = []
        node_ids = list(manifest_nodes.keys())
        
        for i in range(len(node_ids)):
            for j in range(i + 1, len(node_ids)):
                id1, id2 = node_ids[i], node_ids[j]
                node1 = manifest_nodes[id1]
                node2 = manifest_nodes[id2]
                
                if self.check_semantic_equivalence(node1, node2):
                    duplicates.append((id1, id2))
        
        return duplicates


class AuditEdgeClassifier:
    """Uses eigenvector-like invariants to classify severed edges by semantic distance."""
    
    def __init__(self, project_path):
        self.project_path = project_path
        self.dimstack = get_dimstack_pipeline(project_path)
    
    def classify_edge_by_semantic_distance(self, source_node: Dict[str, Any],
                                          target_node: Dict[str, Any]) -> Dict[str, Any]:
        """Classify severed edge by semantic distance rather than structural proximity."""
        try:
            # Extract content from both nodes
            source_content = self._extract_node_content(source_node)
            target_content = self._extract_node_content(target_node)
            
            if not source_content or not target_content:
                return {"classification": "unknown", "reason": "insufficient_content"}
            
            # Canonicalize both nodes
            source_atomics = self.dimstack.canonicalize_content(source_content)
            target_atomics = self.dimstack.canonicalize_content(target_content)
            
            # Compute semantic distance
            semantic_distance = self._compute_semantic_distance(source_atomics, target_atomics)
            
            # Classify based on distance
            classification = self._classify_by_distance(semantic_distance)
            
            return {
                "classification": classification,
                "semantic_distance": semantic_distance,
                "source_atomics": len(source_atomics),
                "target_atomics": len(target_atomics)
            }
            
        except Exception as e:
            logger.error(f"Failed to classify edge: {e}")
            return {"classification": "error", "reason": str(e)}
    
    def _extract_node_content(self, node_data: Dict[str, Any]) -> str:
        """Extract meaningful content from node data."""
        content_parts = []
        
        for field in ["description", "purpose", "title", "name", "summary"]:
            if field in node_data and node_data[field]:
                content_parts.append(str(node_data[field]))
        
        return " ".join(content_parts)
    
    def _compute_semantic_distance(self, atomics1: List[InvariantAtomic], 
                                  atomics2: List[InvariantAtomic]) -> float:
        """Compute semantic distance between two sets of atomics."""
        if not atomics1 or not atomics2:
            return float('inf')
        
        # Compute coordinates
        coords1 = self.dimstack.compute_factorized_coordinates(atomics1)
        coords2 = self.dimstack.compute_factorized_coordinates(atomics2)
        
        # Find minimum distance in structural layer
        min_distance = float('inf')
        for coord1 in coords1.values():
            for coord2 in coords2.values():
                distance = coord1.distance_to(coord2, TruthLayer.STRUCTURAL)
                min_distance = min(min_distance, distance)
        
        return min_distance
    
    def _classify_by_distance(self, distance: float) -> str:
        """Classify edge based on semantic distance."""
        if distance <= 0.1:
            return "semantically_identical"
        elif distance <= 0.3:
            return "semantically_similar"
        elif distance <= 0.6:
            return "semantically_related"
        elif distance <= 0.9:
            return "semantically_distant"
        else:
            return "semantically_unrelated"


class ContextGenerationPreprocessor:
    """Comburiscope canonicalization as preprocessing for context generation."""
    
    def __init__(self, project_path):
        self.project_path = project_path
        self.dimstack = get_dimstack_pipeline(project_path)
    
    def preprocess_context_data(self, context_data: Dict[str, Any]) -> Dict[str, Any]:
        """Preprocess context data to reduce redundancy and expose core structure."""
        try:
            preprocessed = context_data.copy()
            
            # Process text fields
            for field, value in context_data.items():
                if isinstance(value, str) and len(value) > 50:  # Only process substantial text
                    # Canonicalize the content
                    atomics = self.dimstack.canonicalize_content(value)
                    
                    # Store canonicalization results
                    preprocessed[f"{field}_canonical_atomics"] = [
                        {
                            "id": atomic.id,
                            "content": atomic.content,
                            "semantic_type": atomic.semantic_type,
                            "truth_layer": atomic.truth_layer.value,
                            "canonical_form": atomic.canonical_form
                        }
                        for atomic in atomics
                    ]
                    
                    # Create reduced content (core structure only)
                    core_content = self._extract_core_structure(atomics)
                    preprocessed[f"{field}_core"] = core_content
            
            preprocessed["comburiscope_processed"] = True
            preprocessed["reduction_ratio"] = self._compute_reduction_ratio(context_data, preprocessed)
            
            return preprocessed
            
        except Exception as e:
            logger.error(f"Failed to preprocess context data: {e}")
            return context_data
    
    def _extract_core_structure(self, atomics: List[InvariantAtomic]) -> str:
        """Extract core structure from canonicalized atomics."""
        # Filter to high-weight atomics
        high_weight_atomics = [
            atomic for atomic in atomics
            if atomic.factorization.get("combined", 0) > 0.5
        ]
        
        # Sort by weight
        high_weight_atomics.sort(
            key=lambda a: a.factorization.get("combined", 0),
            reverse=True
        )
        
        # Extract core content
        core_elements = []
        for atomic in high_weight_atomics[:10]:  # Top 10 elements
            core_elements.append(atomic.canonical_form)
        
        return " | ".join(core_elements)
    
    def _compute_reduction_ratio(self, original: Dict[str, Any], 
                               preprocessed: Dict[str, Any]) -> float:
        """Compute text reduction ratio."""
        original_size = sum(len(str(v)) for v in original.values() if isinstance(v, str))
        reduced_size = sum(len(str(v)) for v in preprocessed.values() 
                         if isinstance(v, str) and v.endswith("_core"))
        
        if original_size == 0:
            return 0.0
        
        return 1.0 - (reduced_size / original_size)


class VectorMemoryEnhancer:
    """Enhances vector memory using invariant atomics as embedding units."""
    
    def __init__(self, project_path):
        self.project_path = project_path
        self.dimstack = get_dimstack_pipeline(project_path)
    
    def create_semantic_embedding(self, content: str, content_type: str) -> List[InvariantAtomic]:
        """Create semantically stable embeddings using invariant atomics."""
        try:
            # Canonicalize content
            atomics = self.dimstack.canonicalize_content(content)
            
            # Enhance atomics with embedding metadata
            for atomic in atomics:
                atomic.metadata.update({
                    "embedding_source": "dimstack",
                    "content_type": content_type,
                    "transformation_invariant": True,
                    "semantic_stability": "high"
                })
            
            return atomics
            
        except Exception as e:
            logger.error(f"Failed to create semantic embedding: {e}")
            return []


# Integration functions
def enhance_intent_graph_quality(intent_data: Dict[str, Any], 
                              project_path: Optional[str] = None) -> Dict[str, Any]:
    """Enhance intent graph quality using dimstack."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    enhancer = IntentGraphQualityEnhancer(resolve_project_path(project_path))
    return enhancer.enhance_intent_record(intent_data)


def verify_manifest_semantics(manifest_nodes: Dict[str, Any],
                             project_path: Optional[str] = None) -> List[Tuple[str, str]]:
    """Verify manifest graph semantics using dimstack."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    verifier = ManifestGraphVerifier(resolve_project_path(project_path))
    return verifier.find_duplicate_nodes(manifest_nodes)


def classify_audit_edges(source_node: Dict[str, Any], target_node: Dict[str, Any],
                        project_path: Optional[str] = None) -> Dict[str, Any]:
    """Classify audit edges using semantic distance."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    classifier = AuditEdgeClassifier(resolve_project_path(project_path))
    return classifier.classify_edge_by_semantic_distance(source_node, target_node)


def preprocess_for_context(context_data: Dict[str, Any],
                         project_path: Optional[str] = None) -> Dict[str, Any]:
    """Preprocess context data using comburiscope."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    preprocessor = ContextGenerationPreprocessor(resolve_project_path(project_path))
    return preprocessor.preprocess_context_data(context_data)


def enhance_vector_embeddings(content: str, content_type: str,
                            project_path: Optional[str] = None) -> List[InvariantAtomic]:
    """Enhance vector memory with invariant atomics."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    enhancer = VectorMemoryEnhancer(resolve_project_path(project_path))
    return enhancer.create_semantic_embedding(content, content_type)


__all__ = [
    "IntentGraphQualityEnhancer",
    "ManifestGraphVerifier", 
    "AuditEdgeClassifier",
    "ContextGenerationPreprocessor",
    "VectorMemoryEnhancer",
    "enhance_intent_graph_quality",
    "verify_manifest_semantics",
    "classify_audit_edges",
    "preprocess_for_context",
    "enhance_vector_embeddings"
]
