"""
forge/core/composer.py

Abstract interfaces for the composer system.
Stack-agnostic. No HTML, no Astro, no React.

These are the forge primitives that gloves
implement and forge-engine renders visually.

HIERARCHY:
  ComposerCanvas      → the orchestrator
  LayoutDescriptor    → declares slots
  SlotContract        → bond rules
  ComponentDescriptor → what fills slots
  SlotBinding         → a resolved binding

CHEMISTRY ANALOGY:
  Atom     = ComponentDescriptor (kind=atom)
  Molecule = ComponentDescriptor (kind=molecule)
  Bond     = SlotContract
  Layout   = LayoutDescriptor (the vessel)
  Composer = ComposerCanvas (the chemist)
"""
from __future__ import annotations

import threading
from dataclasses import dataclass, field
from enum import Enum
from typing import (
    Any, Protocol, runtime_checkable,
    Sequence,
)


# ── Component kinds ───────────────────────

class ComponentKind(str, Enum):
    """
    Atomic hierarchy of UI components.

    ATOM     — single-purpose, indivisible.
               No composition. No children.
               Examples: DraftBanner, TagList,
               ReadingTime, AdUnit

    MOLECULE — atoms composed together.
               Has an internal structure.
               Examples: PostHeader, ArticleSidebar,
               NewsletterSignup

    ORGANISM — molecules + business logic.
               Stateful, data-aware.
               Examples: AdminApp, FilteredPostList,
               ProjectsExplorer

    ISLAND   — client-side interactive.
               Hydrated in the browser.
               Stack-specific (React, Svelte, etc.)
               Examples: Comments, ThemeToggle,
               SocialShare

    CARD     — reusable data display unit.
               Renders one content item.
               Examples: PostCard, NoteCard,
               ProjectCard

    CHROME   — site shell. Never in content.
               Examples: NavBar, Footer, SEO

    LAYOUT   — container with named slots.
               No content of its own.
               Examples: WideLayout, PostLayout,
               FullBleedLayout
    """
    ATOM = "atom"
    MOLECULE = "molecule"
    ORGANISM = "organism"
    ISLAND = "island"
    CARD = "card"
    CHROME = "chrome"
    LAYOUT = "layout"


# ── Slot contract ─────────────────────────

@dataclass(frozen=True)
class SlotContract:
    """
    Defines what a layout slot accepts.

    The 'bond' between layout and component.
    A slot contract is satisfied when a
    ComponentDescriptor's kind is in
    accepted_kinds AND its domain is in
    accepted_domains (if specified).

    name:
        The slot identifier. Matches the
        layout's named slot declaration.
        e.g. "sidebar", "header", "default"

    accepted_kinds:
        Which ComponentKinds may fill this slot.
        Empty = accepts any kind.

    accepted_domains:
        Which forge domains may fill this slot.
        Empty = accepts any domain.

    required:
        Whether this slot must be filled.
        If True and unbound, composer warns.

    max_components:
        Maximum components in this slot.
        0 = unlimited.

    description:
        Human-readable description of the slot.
        Shown in forge-engine composer UI.
    """
    name: str
    accepted_kinds: tuple[ComponentKind, ...] = ()
    accepted_domains: tuple[str, ...] = ()
    required: bool = False
    max_components: int = 1
    description: str = ""

    def accepts(
        self,
        component: "ComponentDescriptor",
    ) -> bool:
        """
        Return True if this slot accepts
        the given component.
        """
        if self.accepted_kinds and \
                component.kind not in \
                self.accepted_kinds:
            return False
        if self.accepted_domains and \
                component.domain not in \
                self.accepted_domains:
            return False
        return True

    def validate(
        self,
        components: Sequence["ComponentDescriptor"],
    ) -> list[str]:
        """
        Return a list of validation errors.
        Empty = valid.
        """
        errors: list[str] = []
        if self.required and not components:
            errors.append(
                f"Slot '{self.name}' is required "
                f"but has no components bound."
            )
        if self.max_components > 0 and \
                len(components) > self.max_components:
            errors.append(
                f"Slot '{self.name}' accepts max "
                f"{self.max_components} component(s), "
                f"got {len(components)}."
            )
        for c in components:
            if not self.accepts(c):
                errors.append(
                    f"Component '{c.node_id}' "
                    f"(kind={c.kind.value}) is not "
                    f"accepted by slot '{self.name}'. "
                    f"Accepted kinds: "
                    f"{[k.value for k in self.accepted_kinds]}"
                )
        return errors


# ── Component descriptor ──────────────────

@dataclass(frozen=True)
class ComponentDescriptor:
    """
    Describes a UI component as a forge entity.

    This is what forge knows about a component —
    not its implementation, but its contract:
    what it is, what it needs, what it fills.

    node_id:
        The forge manifest node id.
        e.g. "component/ui.molecules.post-header"

    label:
        Human-readable name.
        e.g. "PostHeader"

    kind:
        Atomic hierarchy position.

    domain:
        The forge domain this component belongs to.
        e.g. "UI", "ADMIN", "FORGE-BROWSER"

    path:
        File path relative to project root.
        e.g. "src/components/molecules/PostHeader.astro"

    fillable_slots:
        Which slot names this component can fill.
        Empty = can fill any slot (no constraint).
        e.g. ("sidebar", "default")

    props:
        Declared prop names. Used for
        compatibility checking.

    feature_flag:
        If set, this component only renders
        when features[feature_flag] is True.
        e.g. "newsletter", "comments"

    stack:
        The stack this component belongs to.
        None = stack-agnostic (rare).
        e.g. "astro", "react", "flutter"

    description:
        Human-readable description.
        Shown in forge-engine composer UI.
    """
    node_id: str
    label: str
    kind: ComponentKind
    domain: str
    path: str
    fillable_slots: tuple[str, ...] = ()
    props: tuple[str, ...] = ()
    feature_flag: str | None = None
    stack: str | None = None
    description: str = ""

    def can_fill(self, slot_name: str) -> bool:
        """
        Return True if this component can
        fill the named slot.
        """
        if not self.fillable_slots:
            return True  # no constraint
        return slot_name in self.fillable_slots


# ── Layout descriptor ─────────────────────

@dataclass(frozen=True)
class LayoutDescriptor:
    """
    Describes a layout as a forge entity.

    A layout is a container with named slots.
    It declares what can go in each slot.
    It has no content of its own.

    The layout is the vessel.
    SlotContracts are the bond rules.
    ComponentDescriptors fill the slots.

    node_id:
        The forge manifest node id.
        e.g. "layout/ui.variants.wide"

    label:
        Human-readable name.
        e.g. "WideLayout"

    slots:
        The named slots this layout exposes.
        Order matters for rendering hints.

    path:
        File path relative to project root.

    stack:
        The stack this layout belongs to.

    use_cases:
        Suggested page types for this layout.
        e.g. ("admin", "tools", "dashboard")

    description:
        Human-readable description.
    """
    node_id: str
    label: str
    slots: tuple[SlotContract, ...]
    path: str
    stack: str | None = None
    use_cases: tuple[str, ...] = ()
    description: str = ""

    def slot(self, name: str) -> SlotContract | None:
        """Return the named slot, or None."""
        for s in self.slots:
            if s.name == name:
                return s
        return None

    def slot_names(self) -> list[str]:
        """Return all slot names."""
        return [s.name for s in self.slots]

    def required_slots(self) -> list[SlotContract]:
        """Return slots that must be filled."""
        return [s for s in self.slots if s.required]


# ── Slot binding ──────────────────────────

@dataclass
class SlotBinding:
    """
    A resolved binding: component in a slot.

    Represents a decision made in the composer:
    "ComponentDescriptor X fills slot Y
     in LayoutDescriptor Z."

    This is what the composer persists to
    the manifest when a user drags a component
    into a slot.

    layout_node_id:
        The layout being composed.

    slot_name:
        Which slot in the layout.

    component_node_id:
        The component filling the slot.

    page_node_id:
        The page this binding applies to.
        None = applies to all pages using
        this layout (layout-level default).

    valid:
        Whether this binding passes
        SlotContract.validate().
        Set by ComposerCanvas.validate_binding().

    errors:
        Validation errors if valid=False.
    """
    layout_node_id: str
    slot_name: str
    component_node_id: str
    page_node_id: str | None = None
    valid: bool = True
    errors: list[str] = field(
        default_factory=list)


# ── Composer canvas ───────────────────────

@runtime_checkable
class ComposerCanvas(Protocol):
    """
    The orchestrator of the composer system.

    Gloves implement this Protocol to provide
    stack-specific composer behavior.
    forge-engine uses this Protocol to render
    the composer UI without knowing the stack.

    The ComposerCanvas:
      - Discovers available layouts
      - Discovers available components
      - Validates slot bindings
      - Resolves which components fit a slot
      - Persists bindings to the manifest

    Usage:
        canvas = get_composer_canvas(stack)
        layouts = canvas.available_layouts()
        components = canvas.available_components()
        binding = canvas.bind(layout, slot, component)
        errors = canvas.validate_binding(binding)
    """

    def available_layouts(
        self,
        project_path: "Any",
    ) -> list[LayoutDescriptor]:
        """
        Return all layouts available in
        the project. Reads from manifest.
        """
        ...

    def available_components(
        self,
        project_path: "Any",
        kind: ComponentKind | None = None,
        domain: str | None = None,
    ) -> list[ComponentDescriptor]:
        """
        Return all components available in
        the project. Optionally filtered by
        kind and/or domain.
        """
        ...

    def components_for_slot(
        self,
        slot: SlotContract,
        project_path: "Any",
    ) -> list[ComponentDescriptor]:
        """
        Return components that satisfy
        the given SlotContract.
        Convenience method for the composer UI.
        """
        ...

    def validate_binding(
        self,
        binding: SlotBinding,
        project_path: "Any",
    ) -> list[str]:
        """
        Validate a slot binding.
        Returns list of errors (empty = valid).
        """
        ...

    def bind(
        self,
        layout_node_id: str,
        slot_name: str,
        component_node_id: str,
        page_node_id: str | None,
        project_path: "Any",
    ) -> SlotBinding:
        """
        Create and validate a slot binding.
        Does NOT persist to manifest.
        Call persist_binding() to save.
        """
        ...

    def persist_binding(
        self,
        binding: SlotBinding,
        project_path: "Any",
    ) -> None:
        """
        Persist a validated binding to the
        forge manifest as a declared relation.
        Write-back via forge MCP tools only.
        """
        ...


# ── Registry helpers ──────────────────────

# Global registry for stack-specific
# ComposerCanvas implementations.
# Populated by gloves on registration.
_COMPOSER_REGISTRY: dict[
    str, "ComposerCanvas"
] = {}
_REGISTRY_LOCK = threading.Lock()


def register_composer(
    stack: str,
    canvas: "ComposerCanvas",
) -> None:
    """
    Register a stack-specific ComposerCanvas.
    Called by gloves during registration.

    Example:
        register_composer("astro", AstroComposer())
    """
    with _REGISTRY_LOCK:
        _COMPOSER_REGISTRY[stack] = canvas


def get_composer_canvas(
    stack: str,
) -> "ComposerCanvas | None":
    """
    Return the ComposerCanvas for the given
    stack, or None if not registered.
    """
    with _REGISTRY_LOCK:
        return _COMPOSER_REGISTRY.get(stack)


def list_registered_stacks() -> list[str]:
    """
    Return all stacks with a registered
    ComposerCanvas.
    """
    return list(_COMPOSER_REGISTRY.keys())
