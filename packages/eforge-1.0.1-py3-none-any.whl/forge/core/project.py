import os
from dataclasses import dataclass, field
from pathlib import Path

from forge.core.result import ForgeResult
from forge.core.checks import DashboardCheck, CheckResult, registry
from forge.core.manifest import ManifestParser


def _dict_to_dashboard_checks(raw: list[dict], project_root: Path) -> list[DashboardCheck]:
    root = project_root.expanduser().resolve()
    env = dict(os.environ)
    return [
        DashboardCheck(
            project_path=root,
            env=env,
            infra_refs=[],
            label=item["label"],
            check=item["check"],
            type=item["type"],
            description=item.get("description", ""),
            plugin=item.get("plugin", ""),
        )
        for item in raw
        if isinstance(item, dict) and "label" in item and "check" in item and "type" in item
    ]


def _common_kwargs(data: dict, path: Path, dashboard_checks: list[DashboardCheck]) -> dict:
    repo = data.get("repo")
    if isinstance(repo, dict):
        repo_url = repo.get("url")
        repo_str = str(repo_url) if repo_url is not None else None
        branch = repo.get("branch") if isinstance(repo.get("branch"), str) else None
    else:
        repo_str = str(repo) if repo is not None else None
        branch = None
    phases = data.get("phases") if isinstance(data.get("phases"), dict) else {}
    notes = data.get("notes") or ""
    if not isinstance(notes, str):
        notes = str(notes)
    warnings = data.get("warnings") or []
    if not isinstance(warnings, list):
        warnings = []
    domain = str(data.get("domain", "") or "")
    app_config_meta = data.get("app_config_meta") or data.get("app_config") or {}
    if not isinstance(app_config_meta, dict):
        app_config_meta = {}
    dependencies = data.get("dependencies") or {}
    if not isinstance(dependencies, dict):
        dependencies = {}
    return {
        "name": str(data.get("name", "")),
        "type": str(data.get("type", "unknown")),
        "version": str(data.get("version", "0.0.0")),
        "path": path,
        "repo": repo_str,
        "branch": branch,
        "description": str(data.get("description", "")),
        "dashboard_checks": dashboard_checks,
        "phases": phases,
        "notes": notes,
        "warnings": warnings,
        "domain": domain,
        "app_config_meta": app_config_meta,
        "dependencies": dependencies,
    }


@dataclass
class BaseProject:
    name: str
    type: str
    version: str
    path: Path
    repo: str | None
    branch: str | None
    description: str
    dashboard_checks: list[DashboardCheck]
    phases: dict
    notes: str
    warnings: list[str]
    domain: str = ""
    app_config_meta: dict = field(default_factory=dict)
    dependencies: dict = field(default_factory=dict)

    def health_check(self) -> list[CheckResult]:
        results: list[CheckResult] = []
        for dc in self.dashboard_checks:
            results.append(registry.run(dc))
        return results

    def render_summary(self) -> str:
        domain_str = f"/{self.domain}" if self.domain else ""
        return f"{self.name} ({self.type}{domain_str}) v{self.version}"

    def current_phase(self) -> int | None:
        current = self.phases.get("current")
        if isinstance(current, int):
            return current
        return None

    def phase_label(self) -> str:
        current = self.current_phase()
        upcoming = self.phases.get("upcoming") or []
        if isinstance(upcoming, list) and current is not None and 1 <= current <= len(upcoming):
            item = upcoming[current - 1]
            if isinstance(item, dict):
                name = item.get("name", "")
                return f"Phase {current} — {name}"
            return f"Phase {current} — Unknown"
        if current is not None:
            return f"Phase {current} — Unknown"
        return "Unknown"


class ProjectFactory:
    """
    Single responsibility: map manifest data → correct BaseProject subclass.
    This is the ONLY place in the codebase that branches on type strings.
    """

    _TYPE_MAP: dict[str, type["BaseProject"]] = {}

    @classmethod
    def register(cls, type_str: str, project_class: type["BaseProject"]) -> None:
        cls._TYPE_MAP[type_str] = project_class

    @classmethod
    def from_manifest(cls, path: Path) -> ForgeResult["BaseProject"]:
        parser = ManifestParser(path)
        parse_result = parser.parse()
        if not parse_result.ok:
            return ForgeResult.failure(parse_result.error or "Parse failed")
        data = parse_result.value
        if data is None:
            return ForgeResult.failure("Parse returned no data")
        project_root = path.parent if path.name == "manifest.yaml" else path
        if project_root.name == "docs":
            project_root = project_root.parent
        return ForgeResult.success(cls.from_dict(data, project_root))

    @classmethod
    def from_dict(cls, data: dict, path: Path) -> "BaseProject":
        raw_checks = data.get("dashboard_checks") or []
        dashboard_checks = _dict_to_dashboard_checks(raw_checks, path)
        common = _common_kwargs(data, path, dashboard_checks)
        type_str = common["type"]
        project_class = cls._TYPE_MAP.get(type_str)
        if project_class is None:
            from forge.types.unknown import UnknownProject
            project_class = UnknownProject
            common["type"] = "unknown"
        if type_str == "flutter":
            from forge.types.flutter import FlutterProject
            domains = data.get("domains") or []
            if not isinstance(domains, list):
                domains = []
            controllers = data.get("controllers") or []
            if not isinstance(controllers, list):
                controllers = []
            pubspec = path / "pubspec.yaml" if path else None
            pubspec_path = pubspec if pubspec and pubspec.exists() else None
            return FlutterProject(
                **common,
                domains=[str(d) for d in domains],
                controllers=controllers,
                pubspec_path=pubspec_path,
            )
        if type_str == "web":
            from forge.types.web import WebProject
            stack = data.get("stack") or {}
            if not isinstance(stack, dict):
                stack = {}
            screens = data.get("screens") or []
            hooks = data.get("hooks") or []
            services = data.get("services") or []
            if not isinstance(screens, list):
                screens = []
            if not isinstance(hooks, list):
                hooks = []
            if not isinstance(services, list):
                services = []
            return WebProject(
                **common,
                stack=stack,
                screens=screens,
                hooks=hooks,
                services=services,
            )
        if type_str == "python":
            from forge.types.python import PythonProject
            stack = data.get("stack") or {}
            if not isinstance(stack, dict):
                stack = {}
            modules = data.get("modules") or []
            commands = data.get("commands") or []
            if not isinstance(modules, list):
                modules = []
            if not isinstance(commands, list):
                commands = []
            entrypoint = str(stack.get("entrypoint", "") or data.get("entrypoint", ""))
            return PythonProject(
                **common,
                stack=stack,
                modules=modules,
                commands=commands,
                entrypoint=entrypoint,
            )
        return project_class(**common)
