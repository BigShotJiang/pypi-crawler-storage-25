import subprocess
import shutil
from pathlib import Path

from forge.core.result import ForgeResult


def _docs_templates_dir() -> Path:
    """Docs templates: package root first, then ~/Projects/.forge."""
    pkg_root = Path(__file__).resolve().parent.parent.parent
    forge_dir = Path("~/Projects/.forge").expanduser()
    for base in (pkg_root, forge_dir):
        d = base / "templates" / "docs"
        if d.exists():
            return d
    return pkg_root / "templates" / "docs"


class Scaffolder:
    """
    Creates the project directory structure for a new project.
    Each project type has a different scaffold.
    Scaffolder does not know about manifest content — only filesystem.
    """

    def __init__(self, project_type: str, project_path: Path) -> None:
        self.project_type = project_type
        self.project_path = Path(project_path)

    def create(
        self,
        project_slug: str | None = None,
        project_name: str | None = None,
        project_version: str = "0.1.0",
        tokens: dict[str, str] | None = None,
    ) -> ForgeResult[Path]:
        """
        Creates directory structure appropriate for type.
        Does not overwrite existing directories.
        project_slug: used for Python package subdir name.
        project_name / project_version: used in package.json / pyproject.toml.
        tokens: used for docs template replacement; if None, create_docs is skipped.
        Returns ForgeResult with created path.
        """
        if self.project_path.exists() and any(self.project_path.iterdir()):
            return ForgeResult.failure(
                f"Directory already exists and is non-empty: {self.project_path}"
            )
        self.project_path.mkdir(parents=True, exist_ok=True)
        name = project_name or "stub"
        version = project_version or "0.1.0"
        if self.project_type == "flutter":
            self._scaffold_flutter()
        elif self.project_type == "web":
            self._scaffold_web(name, version)
        elif self.project_type == "python":
            self._scaffold_python(project_slug or "src", name, version)
        else:
            self._scaffold_unknown()
        if tokens:
            self.create_docs(tokens)
        return ForgeResult.success(self.project_path)

    def _scaffold_flutter(self) -> None:
        (self.project_path / "lib").mkdir(parents=True, exist_ok=True)
        (self.project_path / "lib" / "core").mkdir(parents=True, exist_ok=True)
        (self.project_path / "docs").mkdir(parents=True, exist_ok=True)
        (self.project_path / "app_config.yaml").write_text(
            "# App config stub\napp:\n  name: \"\"\n  version: \"\"\n"
        )
        (self.project_path / "pubspec.yaml").write_text(
            "name: stub\nversion: 0.1.0\nenvironment:\n  sdk: '>=3.0.0 <4.0.0'\n"
        )
        (self.project_path / ".gitignore").write_text(
            "# Flutter\n*.iml\n.dart_tool/\n.build/\n*.log\n"
        )

    def _scaffold_web(self, name: str, version: str) -> None:
        (self.project_path / "src").mkdir(parents=True, exist_ok=True)
        for d in ("pages", "panels", "hooks", "services", "config"):
            (self.project_path / "src" / d).mkdir(parents=True, exist_ok=True)
        (self.project_path / "src" / "config" / "site.config.js").write_text(
            "// SITE_CONFIG stub\nexport const SITE_CONFIG = {};\n"
        )
        (self.project_path / "public").mkdir(parents=True, exist_ok=True)
        (self.project_path / ".gitignore").write_text(
            "node_modules/\n.env.local\n.env\n.DS_Store\n"
        )
        (self.project_path / "package.json").write_text(
            f'{{"name": "{name}", "version": "{version}"}}\n'
        )

    def _scaffold_python(self, project_slug: str, name: str, version: str) -> None:
        pkg_dir = self.project_path / project_slug
        pkg_dir.mkdir(parents=True, exist_ok=True)
        (pkg_dir / "__init__.py").write_text("")
        (self.project_path / "tests").mkdir(parents=True, exist_ok=True)
        (self.project_path / "tests" / "__init__.py").write_text("")
        (self.project_path / "pyproject.toml").write_text(
            f'[project]\nname = "{name}"\nversion = "{version}"\n'
        )
        (self.project_path / ".gitignore").write_text(
            "*.pyc\n__pycache__/\n.venv/\nvenv/\n*.egg-info/\n"
        )

    def _scaffold_unknown(self) -> None:
        (self.project_path / "README.md").write_text("# Project\n")

    def create_docs(self, tokens: dict[str, str]) -> None:
        """
        Creates docs/ directory and populates it from docs templates.
        Called after the type-specific scaffold. Uses same token replacement as TemplateEngine.
        """
        docs_dir = self.project_path / "docs"
        docs_dir.mkdir(exist_ok=True)
        templates_docs_dir = _docs_templates_dir()

        base_docs = ["MAP.md", "ARCHITECTURE.md", "TODO.md", "UPDATE.md"]
        type_docs = {
            "flutter": ["MANIFEST.md", "ERROR_CODES.md"],
            "web": [],
            "python": [],
            "unknown": [],
        }
        all_docs = base_docs + type_docs.get(self.project_type, [])

        for doc_name in all_docs:
            template_path = templates_docs_dir / doc_name
            output_path = docs_dir / doc_name
            if template_path.exists():
                content = template_path.read_text()
                for key, value in tokens.items():
                    content = content.replace(f"{{{{{key}}}}}", str(value))
                output_path.write_text(content)
            else:
                title = doc_name.replace(".md", "").replace("_", " ").title()
                proj = tokens.get("PROJECT_NAME", "Project")
                output_path.write_text(
                    f"# {title} — {proj}\n\n> TODO: fill in\n"
                )

        (docs_dir / "ADR").mkdir(exist_ok=True)
        (docs_dir / "ADR" / ".gitkeep").touch()

        if self.project_type == "flutter":
            root_manifest = self.project_path / ".forge" / "manifest.yaml"
            docs_manifest = docs_dir / "manifest.yaml"
            if root_manifest.exists() and not docs_manifest.exists():
                shutil.copy(root_manifest, docs_manifest)

    def init_git(self) -> ForgeResult[None]:
        """
        Runs git init, git add ., git commit -m "forge: initial scaffold"
        Returns ForgeResult — does not raise if git unavailable.
        """
        try:
            subprocess.run(
                ["git", "init"],
                cwd=self.project_path,
                check=True,
                capture_output=True,
            )
            subprocess.run(
                ["git", "add", "."],
                cwd=self.project_path,
                check=True,
                capture_output=True,
            )
            subprocess.run(
                ["git", "commit", "-m", "forge: initial scaffold"],
                cwd=self.project_path,
                check=True,
                capture_output=True,
            )
            return ForgeResult.success(None)
        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            return ForgeResult.failure(str(e))

    def install_hooks(self, hooks_source_dir: Path) -> ForgeResult[None]:
        """
        Copies hooks from hooks_source_dir into .git/hooks/
        Sets executable bit on each hook.
        """
        git_hooks = self.project_path / ".git" / "hooks"
        if not git_hooks.exists():
            return ForgeResult.failure(".git/hooks not found — run init_git first")
        for name in ("pre-commit", "post-create"):
            src = hooks_source_dir / name
            if not src.exists():
                continue
            dst = git_hooks / name
            try:
                shutil.copy2(src, dst)
                dst.chmod(0o755)
            except OSError as e:
                return ForgeResult.failure(f"Cannot install hook {name}: {e}")
        return ForgeResult.success(None)

    def scaffold_ui_unit(
        self,
        framework: str,
        category: str,
        unit: str,
        token_map: dict[str, str] | None = None,
    ) -> ForgeResult[list[Path]]:
        """
        Copy one UI template unit into this project using template_registry paths:
        Flutter: lib/ui/... and lib/features/...
        React: src/styles/, src/components/atoms|molecules/, src/layouts/, src/screens|pages/
        """
        from forge.core.template_registry import copy_ui_unit_to_project

        written, errs = copy_ui_unit_to_project(
            self.project_path, framework, category, unit, token_map
        )
        if errs:
            return ForgeResult.failure("; ".join(errs))
        return ForgeResult.success(written)

    def scaffold_ui_framework(
        self,
        framework: str,
        token_map: dict[str, str] | None = None,
    ) -> ForgeResult[list[Path]]:
        """Copy all registry units for flutter or react."""
        from forge.core.template_registry import REGISTRY, copy_ui_unit_to_project

        all_written: list[Path] = []
        all_errs: list[str] = []
        for category, units in REGISTRY.get(framework, {}).items():
            for unit in units:
                written, errs = copy_ui_unit_to_project(
                    self.project_path, framework, category, unit, token_map
                )
                all_written.extend(written)
                all_errs.extend(errs)
        if all_errs:
            return ForgeResult.failure("; ".join(all_errs))
        return ForgeResult.success(all_written)

    def create_secrets_dir(self, slug: str) -> Path:
        """
        Creates ~/Projects/.secrets/{slug}/ if not exists.
        Creates empty .env file inside.
        Returns path.
        """
        root = Path("~/Projects").expanduser()
        secrets_dir = root / ".secrets" / slug
        secrets_dir.mkdir(parents=True, exist_ok=True)
        (secrets_dir / ".env").touch()
        return secrets_dir
