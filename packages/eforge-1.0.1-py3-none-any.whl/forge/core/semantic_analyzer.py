"""Semantic import analysis engine for proper understanding of code structure.

Provides AST-based analysis and circular dependency detection
to replace basic heuristics with real semantic understanding.
"""

import ast
from pathlib import Path
from typing import Dict, List, Set, Optional, Any, Tuple
from dataclasses import dataclass
from collections import defaultdict, deque

from forge.core.import_parser import ImportStatement, FileImports


@dataclass(frozen=True)
class ImportDependency:
    """Represents a semantic import dependency."""
    source_file: Path
    target_module: str
    import_type: str
    line_number: int
    is_conditional: bool = False
    is_dynamic: bool = False
    is_speculative: bool = False


@dataclass(frozen=True)
class ModuleExport:
    """Represents a module export."""
    name: str
    export_type: str  # 'function', 'class', 'variable', 'default'
    line_number: int
    is_re_export: bool = False


class SemanticAnalyzer:
    """Provides semantic understanding of import/export relationships."""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self._dependency_graph: Dict[Path, Set[ImportDependency]] = defaultdict(set)
        self._export_graph: Dict[Path, Set[ModuleExport]] = defaultdict(set)
        self._circular_dependencies: List[Tuple[Path, ...]] = []
    
    def analyze_file(self, file_path: Path, content: str) -> Dict[str, Any]:
        """Perform semantic analysis of a single file."""
        try:
            tree = ast.parse(content)
        except SyntaxError:
            return {'error': 'Invalid syntax', 'imports': [], 'exports': []}
        
        # Extract imports with semantic context
        imports = self._extract_semantic_imports(tree, file_path)
        
        # Extract exports with semantic context
        exports = self._extract_semantic_exports(tree, file_path)
        
        # Build dependency graph
        for imp in imports:
            self._dependency_graph[file_path].add(imp)
        
        # Build export graph
        for export in exports:
            self._export_graph[file_path].add(export)
        
        return {
            'imports': imports,
            'exports': exports,
            'has_conditional_imports': any(imp.is_conditional for imp in imports),
            'has_dynamic_imports': any(imp.is_dynamic for imp in imports),
            'has_re_exports': any(exp.is_re_export for exp in exports)
        }
    
    def _extract_semantic_imports(self, tree: ast.AST, file_path: Path) -> List[ImportDependency]:
        """Extract imports with semantic understanding."""
        imports = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                # Handle: import module
                for alias in node.names:
                    imports.append(ImportDependency(
                        source_file=file_path,
                        target_module=alias.name,
                        import_type='import',
                        line_number=node.lineno,
                        is_conditional=self._is_conditional_import(node)
                    ))
            
            elif isinstance(node, ast.ImportFrom):
                # Handle: from module import name
                if node.module:
                    imports.append(ImportDependency(
                        source_file=file_path,
                        target_module=node.module,
                        import_type='from_import',
                        line_number=node.lineno,
                        is_conditional=self._is_conditional_import(node)
                    ))
            
            elif isinstance(node, ast.Call):
                # Handle dynamic imports: import('module')
                if isinstance(node.func, ast.Name) and node.func.id == 'import':
                    if node.args and isinstance(node.args[0], ast.Constant):
                        module_name = node.args[0].value
                        if isinstance(module_name, str):
                            imports.append(ImportDependency(
                                source_file=file_path,
                                target_module=module_name,
                                import_type='dynamic',
                                line_number=node.lineno,
                                is_dynamic=True,
                                is_speculative=True
                            ))
        
        return imports
    
    def _extract_semantic_exports(self, tree: ast.AST, file_path: Path) -> List[ModuleExport]:
        """Extract exports with semantic understanding."""
        exports = []
        
        for node in ast.walk(tree):
            # Function exports
            if isinstance(node, ast.FunctionDef):
                exports.append(ModuleExport(
                    name=node.name,
                    export_type='function',
                    line_number=node.lineno
                ))
            
            elif isinstance(node, ast.AsyncFunctionDef):
                exports.append(ModuleExport(
                    name=node.name,
                    export_type='async_function',
                    line_number=node.lineno
                ))
            
            # Class exports
            elif isinstance(node, ast.ClassDef):
                exports.append(ModuleExport(
                    name=node.name,
                    export_type='class',
                    line_number=node.lineno
                ))
            
            # Variable exports (module-level assignments)
            elif isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        exports.append(ModuleExport(
                            name=target.id,
                            export_type='variable',
                            line_number=node.lineno
                        ))
            
            # Re-exports
            elif isinstance(node, ast.ImportFrom):
                if node.module and node.names:
                    for alias in node.names:
                        if alias.name == '*':
                            exports.append(ModuleExport(
                                name='*',
                                export_type='re_export_all',
                                line_number=node.lineno,
                                is_re_export=True
                            ))
                        else:
                            exports.append(ModuleExport(
                                name=alias.asname or alias.name,
                                export_type='re_export',
                                line_number=node.lineno,
                                is_re_export=True
                            ))
        
        return exports
    
    def _is_conditional_import(self, node: ast.AST) -> bool:
        """Check if import is inside a conditional block."""
        # Walk up the AST to find if we're inside an if/try/except
        current = getattr(node, 'parent', None)
        while current:
            if isinstance(current, (ast.If, ast.Try, ast.ExceptHandler, ast.While, ast.For)):
                return True
            current = getattr(current, 'parent', None)
        return False
    
    def detect_circular_dependencies(self) -> List[Tuple[Path, ...]]:
        """Detect circular dependencies using DFS."""
        visited = set()
        rec_stack = set()
        cycles = []
        
        def dfs(file_path: Path, path: List[Path]) -> bool:
            if file_path in rec_stack:
                # Found a cycle
                cycle_start = path.index(file_path)
                cycle = tuple(path[cycle_start:] + [file_path])
                if cycle not in cycles:
                    cycles.append(cycle)
                return True
            
            if file_path in visited:
                return False
            
            visited.add(file_path)
            rec_stack.add(file_path)
            
            # Check all dependencies
            for dep in self._dependency_graph.get(file_path, set()):
                # Convert module name to file path if possible
                target_path = self._resolve_module_to_path(dep.target_module)
                if target_path and target_path in self._dependency_graph:
                    if dfs(target_path, path + [file_path]):
                        return True
            
            rec_stack.remove(file_path)
            return False
        
        # Run DFS from all files
        for file_path in self._dependency_graph:
            if file_path not in visited:
                dfs(file_path, [])
        
        self._circular_dependencies = cycles
        return cycles
    
    def _resolve_module_to_path(self, module_name: str) -> Optional[Path]:
        """Resolve module name to file path."""
        # This is a simplified resolution - in practice, this would use
        # the same contract-based resolution as the import resolver
        if module_name.startswith('./') or module_name.startswith('../'):
            # Relative import - try to resolve
            return None  # Would need source file context
        
        # Check if it's a local module
        possible_paths = [
            self.project_root / f"{module_name}.py",
            self.project_root / f"{module_name}.js",
            self.project_root / f"{module_name}.ts",
            self.project_root / f"{module_name}.tsx",
            self.project_root / module_name / "__init__.py",
        ]
        
        for path in possible_paths:
            if path.exists():
                return path
        
        return None
    
    def get_dependency_analysis(self) -> Dict[str, Any]:
        """Get comprehensive dependency analysis."""
        return {
            'dependency_graph': {
                str(k): [{'target': dep.target_module, 'type': dep.import_type, 
                          'line': dep.line_number, 'conditional': dep.is_conditional,
                          'dynamic': dep.is_dynamic} for dep in v]
                for k, v in self._dependency_graph.items()
            },
            'export_graph': {
                str(k): [{'name': exp.name, 'type': exp.export_type, 
                          'line': exp.line_number, 're_export': exp.is_re_export} for exp in v]
                for k, v in self._export_graph.items()
            },
            'circular_dependencies': [
                [str(p) for p in cycle] for cycle in self._circular_dependencies
            ],
            'total_files': len(self._dependency_graph),
            'total_dependencies': sum(len(deps) for deps in self._dependency_graph.values()),
            'files_with_conditional_imports': len([
                f for f, deps in self._dependency_graph.items() 
                if any(dep.is_conditional for dep in deps)
            ]),
            'files_with_dynamic_imports': len([
                f for f, deps in self._dependency_graph.items() 
                if any(dep.is_dynamic for dep in deps)
            ])
        }
