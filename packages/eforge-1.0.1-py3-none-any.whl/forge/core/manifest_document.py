"""Typed manifest document — canonical model built from a single parse (Phase 2)."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from forge.core.manifest import ManifestParser
from forge.core.manifest_path import resolve_manifest_path
from forge.core.stack_profiles import StackProfile, profile_for_manifest_dict


def project_root_for_manifest_file(manifest_file: Path) -> Path | None:
    """Find a project root whose ``resolve_manifest_path(root)`` is *manifest_file*.

    Walks *manifest_file*'s parent chain. Returns ``None`` when the file is not
    the canonical resolved manifest for any ancestor directory.
    """
    mf = manifest_file.expanduser().resolve()
    cur: Path | None = mf.parent
    while cur is not None:
        resolved = resolve_manifest_path(cur, warn_on_root_fallback=False)
        if resolved is not None and resolved.resolve() == mf:
            return cur
        parent = cur.parent
        if parent == cur:
            break
        cur = parent
    return None

_LAYER_NEST_KEYS = frozenset({"slice", "submanifest", "manifest"})
_LAYER_META_KEYS = frozenset({"id", "role", "label"})


@dataclass(frozen=True, slots=True)
class LayerSlice:
    """One declared layer / submanifest slice (composite product)."""

    id: str
    stack: str
    profile: StackProfile
    raw: dict[str, Any]


@dataclass
class ManifestDocument:
    """Canonical ingress shell: resolved manifest path, primary stack, profile, raw dict, layers."""

    path: Path
    stack: str
    profile: StackProfile
    raw: dict[str, Any]
    layers: list[LayerSlice]

    def to_legacy_dict(self) -> dict[str, Any]:
        """Adapter for transitional callers — same mapping ``ManifestParser.parse`` produced."""
        return self.raw

    @classmethod
    def from_path(cls, path: Path) -> ManifestDocument:
        """Load from *project root* (directory searched by ``resolve_manifest_path``).

        Raises:
            FileNotFoundError: no manifest file under the root.
            ValueError: parse failure (invalid schema, missing required fields, etc.).
        """
        root = path.expanduser().resolve()
        mp = resolve_manifest_path(root, warn_on_root_fallback=True)
        if mp is None:
            raise FileNotFoundError(f"No manifest.yaml found under {root}")
        manifest_path = mp.resolve()
        parser = ManifestParser(manifest_path)
        result = parser.parse()
        if not result.ok or result.value is None:
            raise ValueError(result.error or "manifest parse failed")
        raw: dict[str, Any] = result.value
        stack = ManifestParser.get_stack(raw)
        profile = profile_for_manifest_dict(raw)
        layers = _layers_from_raw(raw)
        return cls(
            path=manifest_path,
            stack=stack,
            profile=profile,
            raw=raw,
            layers=layers,
        )


def _layer_slice_from_mapping(
    layer_id: str,
    entry: dict[str, Any],
) -> LayerSlice:
    layer_raw: dict[str, Any]
    for nk in _LAYER_NEST_KEYS:
        inner = entry.get(nk)
        if isinstance(inner, dict):
            layer_raw = dict(inner)
            break
    else:
        layer_raw = {k: v for k, v in entry.items() if k not in _LAYER_META_KEYS}
        if not layer_raw:
            layer_raw = dict(entry)
    lid = str(entry.get("id") or entry.get("role") or entry.get("label") or layer_id).strip() or layer_id
    stack = ManifestParser.get_stack(layer_raw)
    profile = profile_for_manifest_dict(layer_raw)
    return LayerSlice(id=lid, stack=stack, profile=profile, raw=layer_raw)


def layers_from_manifest_dict(data: dict[str, Any]) -> list[LayerSlice]:
    """Public helper for callers with an in-memory manifest mapping (no disk read)."""
    return _layers_from_raw(data)


def _layers_from_raw(raw: dict[str, Any]) -> list[LayerSlice]:
    """Read optional ``layers`` list or mapping (see docs/phase-1/composite-layers-submanifests.yaml)."""
    raw_layers = raw.get("layers")
    if raw_layers is None:
        return []
    out: list[LayerSlice] = []
    if isinstance(raw_layers, list):
        for i, entry in enumerate(raw_layers):
            if not isinstance(entry, dict):
                continue
            out.append(_layer_slice_from_mapping(f"layer_{i}", entry))
    elif isinstance(raw_layers, dict):
        for key, val in raw_layers.items():
            if not isinstance(val, dict):
                continue
            lid = str(key).strip() or "layer"
            entry = dict(val)
            entry.setdefault("id", lid)
            out.append(_layer_slice_from_mapping(lid, entry))
    return out
