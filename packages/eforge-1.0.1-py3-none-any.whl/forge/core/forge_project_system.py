"""
Forge Game System - Projects/Programs as games, Forge primitives as components.
Unity-inspired architecture using Forge's native taxonomy and atomics.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, TypeVar, Union, runtime_checkable

from forge.core.schemas import (
    IntentResult,
    ManifestResult,
    OrientResult,
    PacketResult,
    ForgeGraphQueryPayload,
    SessionResult,
    VerifyResult,
    NodeTier, ChangeClass, ResponseTier,
    AnnotationKind, PipelineStepKind, ErrorDomain
)
from forge.core.debug_output_interface import SeverityLevel
from forge.tools.manifest.graph import (
    MANIFEST_NODE_KINDS,
    MANIFEST_EDGE_RELATIONS,
    ManifestEdge,
    ManifestNode,
    ManifestGraph,
)
from forge.core.gloves import RawNode, RawEdge, StackGlove
from forge.protocols.glove import GloveProtocol
from forge.core.execution_graph import ExecutionGraph, ExecutionNode, ExecutionEdge
from forge.core.trace_mapper import TraceNodeMapper
from forge.core.graph_health_metrics import HealthMetric, MetricType
from forge.events.schema import UniversalEvent
from forge.protocols.events import ProtocolEvent

T = TypeVar('T')


class NodeLifecycle(Enum):
    """Forge node runtime lifecycle (ECS). Not graph declaration NodeStatus in schemas."""
    DECLARED = "declared"
    IMPLEMENTED = "implemented"
    ACTIVE = "active"
    INACTIVE = "inactive"
    ORPHANED = "orphaned"
    DEPRECATED = "deprecated"


class ContractStatus(Enum):
    """Forge contract relationship status."""
    VALID = "valid"
    VIOLATION = "violation"
    PENDING = "pending"
    STALE = "stale"


EDGE_VOCAB_MAP = {"imports": "depends_on"}


# === GAME-LEVEL ENTITIES ===

class ProjectScope(Enum):
    """Scope of project/program entity."""
    PROJECT = "project"      # Single forge project
    PROGRAM = "program"       # Multi-project program
    WORKSPACE = "workspace"   # Entire workspace
    SYSTEM = "system"         # Forge system itself


@dataclass
class ForgeProject:
    """
    Top-level project entity - represents project, program, or workspace.
    Like Unity's Scene but for Forge development environments.
    """
    
    id: str
    scope: ProjectScope
    name: str
    root_path: Path
    
    # Project-level state
    _entities: Dict[str, ForgeEntity] = field(default_factory=dict)
    _systems: Dict[str, ForgeSystem] = field(default_factory=dict)
    _resources: Dict[str, Any] = field(default_factory=dict)
    _global_properties: Dict[str, Any] = field(default_factory=dict)
    
    # Project lifecycle
    active: bool = True
    initialized: bool = False
    
    def __post_init__(self):
        """Initialize project after creation."""
        self.add_builtin_systems()
    
    # Entity management
    def add_entity(self, entity: ForgeEntity) -> ForgeEntity:
        """Add an entity to this project."""
        entity.project = self
        self._entities[entity.id] = entity
        entity.awake()
        return entity
    
    def get_entity(self, entity_id: str) -> Optional[ForgeEntity]:
        """Get entity by ID."""
        return self._entities.get(entity_id)
    
    def get_entities(self, component_type: Type[T] = None) -> List[ForgeEntity]:
        """Get all entities, optionally filtered by component type."""
        if component_type is None:
            return list(self._entities.values())
        return [e for e in self._entities.values() if e.has_component(component_type)]
    
    def remove_entity(self, entity_id: str) -> Optional[ForgeEntity]:
        """Remove entity from game."""
        entity = self._entities.pop(entity_id, None)
        if entity:
            entity.destroy()
        return entity
    
    # System management
    def add_system(self, system: ForgeSystem) -> ForgeSystem:
        """Add a system to this game."""
        system.project = self
        self._systems[system.name] = system
        if self.initialized:
            system.initialize()
        return system
    
    def get_system(self, system_type_or_name):
        if isinstance(system_type_or_name, type):
            for system in self._systems.values():
                if isinstance(system, system_type_or_name):
                    return system
            return None
        return self._systems.get(system_type_or_name)
    
    def add_builtin_systems(self):
        """Add built-in Forge systems."""
        self.add_system(ManifestSystem())
        self.add_system(ContractSystem())
        self.add_system(HealthSystem())
        self.add_system(EventSystem())
        self.add_system(ResourceSystem())
    
    # Resource management
    def set_resource(self, key: str, resource: Any):
        """Set a global resource."""
        self._resources[key] = resource
    
    def get_resource(self, key: str, default: Any = None) -> Any:
        """Get a global resource."""
        return self._resources.get(key, default)
    
    # Game lifecycle
    def initialize(self):
        """Initialize all systems and entities."""
        if self.initialized:
            return
        
        for system in self._systems.values():
            system.initialize()
        
        for entity in self._entities.values():
            entity.start()
        
        self.initialized = True
    
    def process_pending_events(self) -> None:
        """Process queued events. Call at start of each MCP tool invocation, not on a tick."""
        event_system = self.get_system("events")
        if event_system:
            event_system.process_pending_events()

    def destroy(self):
        """Destroy game and cleanup."""
        self.active = False
        
        for entity in self._entities.values():
            entity.destroy()
        
        for system in self._systems.values():
            system.destroy()
        
        self._entities.clear()
        self._systems.clear()
        self._resources.clear()
    
    # Utility methods
    def to_dict(self) -> Dict[str, Any]:
        """Serialize game state."""
        return {
            "id": self.id,
            "scope": self.scope.value,
            "name": self.name,
            "root_path": str(self.root_path),
            "entities": {eid: entity.to_dict() for eid, entity in self._entities.items()},
            "global_properties": self._global_properties.copy(),
            "resources": {k: type(v).__name__ for k, v in self._resources.items()}
        }
    
    def to_manifest(self, output_path: Path | None = None, 
                    upsert_only: bool = True) -> Path:
        """
        Write entity graph back to manifest YAML.
        upsert_only=True: only add/update, never delete existing nodes.
        """
        import yaml
        
        manifest_path = output_path or (self.root_path / ".forge" / "manifest.yaml")
        
        with open(manifest_path) as f:
            existing = yaml.safe_load(f) or {}
        
        existing_nodes = {n.get('id'): n for n in existing.get('nodes', [])}
        
        for entity in self._entities.values():
            if entity.kind == 'domain':
                continue  # domain containers managed separately
            
            props = entity._properties
            meta = props.get('meta', {})
            
            node = existing_nodes.get(entity.id, {})
            
            # Only update fields we own — preserve existing metadata
            node.update({
                "id": entity.id,
                "kind": entity.kind,
                "name": props.get("name", entity.id),
                "path": props.get("path", ""),
                "domain": props.get("domain", ""),
            })
            
            if meta.get("tier"):
                node["tier"] = meta["tier"]
            if meta.get("role"):
                node["role"] = meta["role"]
            if meta.get("owns"):
                node["owns"] = meta["owns"]
            
            existing_nodes[entity.id] = node
        
        existing["nodes"] = list(existing_nodes.values())
        
        with open(manifest_path, "w") as f:
            yaml.dump(existing, f, allow_unicode=True, 
                     sort_keys=False, indent=2)
        
        return manifest_path

    @classmethod
    def from_manifest(cls, project_path: Path) -> "ForgeProject":
        """Create a ForgeProject from a manifest file."""
        from forge.tools.manifest.graph import build_manifest_graph

        graph = build_manifest_graph(project_path)
        project = cls(
            id=str(project_path.name),
            scope=ProjectScope.PROJECT,
            name=str(project_path.name),
            root_path=project_path,
        )
        
        # Register GraphSystem with declaration layer
        graph_system = GraphSystem()
        graph_system.register_layer("declaration", graph)
        graph_system.build_static_import_layer(project_path)
        project.add_system(graph_system)
        
        # Create entities via single conversion path
        static_layer = graph_system.get_layer('static_imports')
        for node in graph.nodes:
            entity = ForgeEntity.from_manifest_node(node)
            graph_comp = entity.get_component(GraphComponent)
            if graph_comp:
                graph_comp.add_layer("declaration", graph)
                if static_layer:
                    graph_comp.add_layer('static_imports', static_layer)
            project.add_entity(entity)
        
        # Initialize project
        project.initialize()
        
        # NOW build entity index — entities exist
        graph_system._project = project  # give GraphSystem project reference
        graph_system.build_entity_index()
        
        # Wire static graph to graph system
        static_graph = graph_system.get_layer('static_imports')
        if static_graph and hasattr(static_graph, 'set_graph_system'):
            static_graph.set_graph_system(graph_system)
        
        # Add execution layer (optional — won't fail if unavailable)
        graph_system.build_execution_layer(project_path)
        execution_layer = graph_system.get_layer('execution')
        if execution_layer:
            for entity in project._entities.values():
                gc = entity.get_component(GraphComponent)
                if gc:
                    gc.add_layer('execution', execution_layer)
        
        # Add intent layer
        graph_system.build_intent_layer(project_path)
        intent_layer = graph_system.get_layer('intent')
        if intent_layer:
            for entity in project._entities.values():
                gc = entity.get_component(GraphComponent)
                if gc:
                    gc.add_layer('intent', intent_layer)
        
        # Add contract layer
        graph_system.build_contract_layer(project_path)
        contract_layer = graph_system.get_layer('contract')
        if contract_layer:
            for entity in project._entities.values():
                gc = entity.get_component(GraphComponent)
                if gc:
                    gc.add_layer('contract', contract_layer)
        
        return project


@dataclass
class ForgeEntity:
    """
    Core entity within a Forge project.
    Like Unity's GameObject but for Forge nodes, contracts, etc.
    """
    
    id: str
    kind: str  # From MANIFEST_NODE_KINDS or custom
    project: Optional[ForgeProject] = None
    
    # Entity state
    _components: Dict[str, ForgeComponent] = field(default_factory=dict)
    _properties: Dict[str, Any] = field(default_factory=dict)
    _tags: List[str] = field(default_factory=list)
    _edges: List["ForgeEdge"] = field(default_factory=list)
    
    # Entity lifecycle
    active: bool = True
    initialized: bool = False
    
    # Dict-like interface
    def __getitem__(self, key: str) -> Any:
        """Get component or property by key."""
        return self._components.get(key) or self._properties.get(key)
    
    def __setitem__(self, key: str, value: Any):
        """Set component or property by key."""
        if isinstance(value, ForgeComponent):
            self.add_component(value, key)
        else:
            self._properties[key] = value
    
    def __contains__(self, key: str) -> bool:
        """Check if component or property exists."""
        return key in self._components or key in self._properties
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get with default."""
        return self[key] if key in self else default
    
    # Component management
    def add_component(self, component: ForgeComponent, name: Optional[str] = None) -> ForgeComponent:
        """Add a component to this entity."""
        comp_name = name or component.__class__.__name__
        
        # Remove existing component of same type
        if comp_name in self._components:
            self.remove_component(comp_name)
        
        component.entity = self
        component.awake()
        self._components[comp_name] = component
        return component
    
    def get_component(self, component_type: Type[T]) -> Optional[T]:
        """Get component by type."""
        for component in self._components.values():
            if isinstance(component, component_type):
                return component
        return None
    
    def get_components(self, component_type: Type[T]) -> List[T]:
        """Get all components of type."""
        return [c for c in self._components.values() if isinstance(c, component_type)]
    
    def remove_component(self, name: str) -> Optional[ForgeComponent]:
        """Remove component by name."""
        component = self._components.pop(name, None)
        if component:
            component.destroy()
        return component
    
    def has_component(self, component_type: Type[ForgeComponent]) -> bool:
        """Check if entity has component type."""
        return self.get_component(component_type) is not None
    
    # Property management
    def set_property(self, key: str, value: Any):
        """Set a simple property."""
        self._properties[key] = value
    
    def get_property(self, key: str, default: Any = None) -> Any:
        """Get a simple property."""
        return self._properties.get(key, default)
    
    # Tag management
    def add_tag(self, tag: str):
        """Add a tag."""
        if tag not in self._tags:
            self._tags.append(tag)
    
    def has_tag(self, tag: str) -> bool:
        """Check if has tag."""
        return tag in self._tags
    
    def remove_tag(self, tag: str):
        """Remove a tag."""
        if tag in self._tags:
            self._tags.remove(tag)

    # Edge management (Forge's graph relationships)
    def add_edge(self, edge: "ForgeEdge") -> None:
        """Add a graph edge."""
        if edge not in self._edges:
            self._edges.append(edge)

    def get_edges(self) -> List["ForgeEdge"]:
        """Get edges."""
        return self._edges.copy()

    def get_dependencies(self) -> List[str]:
        """Node IDs this entity imports."""
        return [
            e.to_id
            for e in self._edges
            if e.relation == "imports" and e.from_id == self.id
        ]

    def get_consumers(self) -> List[str]:
        """Node IDs that import this entity."""
        return [
            e.from_id
            for e in self._edges
            if e.relation == "imports" and e.to_id == self.id
        ]
    
    # Entity lifecycle
    def awake(self):
        """Called when component is added to entity."""
        pass
    
    def start(self):
        """Called after game initialization."""
        self.initialized = True
        for component in self._components.values():
            if hasattr(component, 'start'):
                component.start()
    
    def destroy(self):
        """Destroy entity and all components."""
        self.active = False
        
        for component in self._components.values():
            component.destroy()
        
        self._components.clear()
        self._properties.clear()
        self._tags.clear()
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to ForgeNodeOutput-compatible dict for MCP wire format."""
        node_comp = self.get_component(NodeComponent)
        tier: str | None = None
        domain: str | None = None
        status: str | None = None
        name = self.get_property("name")
        if node_comp is not None:
            tier = node_comp.tier.value
            domain = node_comp.domain or None
            status = node_comp.status.value
            if not name:
                name = node_comp.node_id.split("/")[-1]
        return {
            "id": self.id,
            "kind": self.kind,
            "tier": tier,
            "domain": domain,
            "status": status,
            "name": name or self.id.split("/")[-1],
            "properties": self._properties.copy(),
        }

    @classmethod
    def from_dict(cls, data: dict, kind: str = "generic") -> "ForgeEntity":
        entity = cls(
            id=str(data.get("id", f"{kind}_{id(data)}")),
            kind=data.get("kind", kind),
        )
        # Handle both flat dicts (from MCP arguments) and
        # structured dicts (from to_dict() output)
        properties = data.get("properties", None)
        if properties is not None:
            # Structured format from to_dict()
            entity._properties = dict(properties)
        else:
            # Flat format from MCP arguments
            for key, value in data.items():
                if key not in ("id", "kind", "tags", "components"):
                    entity._properties[key] = value
        return entity

    @classmethod
    def from_manifest_node(cls, graph_node: ManifestNode) -> "ForgeEntity":
        """Convert a ManifestNode to a ForgeEntity with components."""
        entity = cls(
            id=graph_node.id,
            kind=graph_node.kind,
        )

        # GraphComponent / ManifestGraphComponent defined below in this module

        gc = GraphComponent(node_id=graph_node.id)
        entity.set_property("graph_type", "manifest")
        entity.set_property("node_count", 1)
        entity.set_property("edge_count", 0)
        entity.add_component(gc)

        entity.add_component(ManifestGraphComponent(
            manifest_path=graph_node.path or "",
            auto_load=True,
        ))

        from forge.core.schemas import NodeTier

        st = str(graph_node.status or "declared").strip().lower()
        if st == "deprecated":
            lifecycle = NodeLifecycle.DEPRECATED
        else:
            lifecycle = NodeLifecycle.ACTIVE

        entity.add_component(NodeComponent(
            node_id=graph_node.id,
            node_kind=graph_node.kind,
            domain=graph_node.domain or "",
            tier=NodeTier(graph_node.meta.get("tier", "worker")),
            path=graph_node.path or "",
            status=lifecycle,
        ))

        return entity

    def to_manifest_node(self) -> Optional[ManifestNode]:
        """Convert a ForgeEntity back to a ManifestNode."""
        node_comp = self.get_component(NodeComponent)
        if not node_comp:
            return None

        return ManifestNode(
            id=node_comp.node_id,
            kind=node_comp.node_kind,
            name=self.id.split("/")[-1],
            path=node_comp.path,
            domain=node_comp.domain,
            parent_id=None,
            status="implemented" if node_comp.status.value == "implemented" else "declared",
            meta={"tier": node_comp.tier.value},
        )

# === FUNDAMENTAL FORGE COMPONENTS ===

class ForgeComponent(ABC):
    """Base component interface - like Unity's Component but Forge-native."""
    
    entity: Optional[ForgeEntity] = None
    active: bool = True
    
    def awake(self):
        """Called when component is added to entity."""
        pass
    
    def start(self):
        """Called after entity/game initialization."""
        pass
    
    def destroy(self):
        """Called when component is removed."""
        pass
    
    def validate(self) -> List[str]:
        """Return validation errors, empty if valid."""
        return []

    def activate(self) -> None:
        pass

    def deactivate(self) -> None:
        pass
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize component state to dict."""
        return {
            "type": self.__class__.__name__,
            "active": self.active,
            "data": {k: v for k, v in self.__dict__.items() 
                    if k not in ('entity', 'active')}
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ForgeComponent":
        """Reconstruct a component from a dictionary."""
        # Get dataclass fields for this component class
        if hasattr(cls, '__dataclass_fields__'):
            fields = cls.__dataclass_fields__
        else:
            # For non-dataclass components, filter out internal fields
            fields = {k: v for k, v in data.items() if k not in ('entity', 'active')}
        return cls(**{k: v for k, v in data.items() if k in fields})


@dataclass
class ForgeEdge:
    """Forge graph edge - represents relationships between nodes."""
    from_id: str
    to_id: str
    relation: str  # From MANIFEST_EDGE_RELATIONS
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        import logging

        _log = logging.getLogger("forge.core.forge_project_system")
        self.relation = EDGE_VOCAB_MAP.get(self.relation, self.relation)
        if self.relation and self.relation not in MANIFEST_EDGE_RELATIONS:
            _log.debug(
                "ForgeEdge: unknown relation %r (from %r → %r). "
                "Add to MANIFEST_EDGE_RELATIONS if canonical, "
                "or define in your extension edge vocabulary.",
                self.relation,
                self.from_id,
                self.to_id,
            )

    @property
    def is_extension_relation(self) -> bool:
        """True if relation is not in MANIFEST_EDGE_RELATIONS."""
        return bool(self.relation) and self.relation not in MANIFEST_EDGE_RELATIONS

    def to_manifest_edge(self) -> ManifestEdge:
        meta = dict(self.metadata)
        derived = bool(meta.pop("derived", False))
        return ManifestEdge(
            from_id=self.from_id,
            to_id=self.to_id,
            relation=self.relation,
            derived=derived,
            meta=meta,
        )

    @classmethod
    def from_manifest_edge(cls, edge: ManifestEdge) -> "ForgeEdge":
        metadata = dict(edge.meta or {})
        if edge.derived:
            metadata["derived"] = True
        return cls(
            from_id=edge.from_id,
            to_id=edge.to_id,
            relation=edge.relation,
            metadata=metadata,
        )


# === CORE FORGE PRIMITIVES AS COMPONENTS ===

@dataclass
class NodeComponent(ForgeComponent):
    """Core node component - fundamental Forge primitive."""
    node_id: str = ""
    node_kind: str = ""
    domain: str = ""
    tier: NodeTier = NodeTier.WORKER
    path: str = ""
    status: NodeLifecycle = NodeLifecycle.DECLARED
    
    def validate(self) -> List[str]:
        """Validate node configuration."""
        errors = []
        if not self.node_id:
            errors.append("Node ID is required")
        if self.node_kind and self.node_kind not in MANIFEST_NODE_KINDS:
            errors.append(f"Invalid node kind: {self.node_kind}")
        return errors


@dataclass
class TierComponent(ForgeComponent):
    """Tier management component - handles import rules and hierarchy."""
    tier: NodeTier = NodeTier.WORKER
    allowed_imports: List[NodeTier] = field(default_factory=list)
    import_violations: List[str] = field(default_factory=list)
    
    def awake(self):
        """Set up tier-specific behavior."""
        from forge.core.impact import TIER_IMPORT_RULES
        self.allowed_imports = TIER_IMPORT_RULES.get(self.tier, [])
    
    def validate(self) -> List[str]:
        """Validate tier compliance."""
        errors = []
        if self.import_violations:
            errors.extend([f"Import violation: {v}" for v in self.import_violations])
        return errors


@dataclass
class ManifestComponent(ForgeComponent):
    """Manifest synchronization component."""
    manifest_path: str = ""
    auto_sync: bool = True
    last_sync: Optional[str] = None
    sync_errors: List[str] = field(default_factory=list)
    
    def sync(self) -> None:
        """Check for manifest changes."""
        if self.auto_sync and self.entity and self.entity.project:
            # Would implement manifest sync logic here
            pass
    
    def validate(self) -> List[str]:
        """Validate manifest configuration."""
        errors = []
        if not self.manifest_path:
            errors.append("Manifest path not specified")
        if self.sync_errors:
            errors.extend([f"Sync error: {e}" for e in self.sync_errors])
        return errors


@dataclass
class ContractComponent(ForgeComponent):
    """Contract management component."""
    required_contracts: List[str] = field(default_factory=list)
    provided_contracts: List[str] = field(default_factory=list)
    contract_status: Dict[str, ContractStatus] = field(default_factory=dict)
    
    def add_contract(self, contract_id: str, status: ContractStatus = ContractStatus.PENDING):
        """Add a contract relationship."""
        self.contract_status[contract_id] = status
    
    def get_contract_status(self, contract_id: str) -> Optional[ContractStatus]:
        """Get contract status."""
        return self.contract_status.get(contract_id)
    
    def validate(self) -> List[str]:
        """Validate contract compliance."""
        errors = []
        for contract in self.required_contracts:
            status = self.get_contract_status(contract)
            if not status or status == ContractStatus.VIOLATION:
                errors.append(f"Required contract not satisfied: {contract}")
        return errors


@dataclass
class HealthComponent(ForgeComponent):
    """Health monitoring component."""
    health_score: int = 100
    issues: List[str] = field(default_factory=list)
    last_check: Optional[str] = None
    
    def score(self) -> None:
        """Update health metrics."""
        if self.entity:
            # Collect validation issues from all components
            self.issues = []
            for component in self.entity._components.values():
                if hasattr(component, 'validate'):
                    self.issues.extend(component.validate())
            
            # Calculate health score
            self.health_score = max(0, 100 - len(self.issues) * 10)
    
    def get_health_summary(self) -> Dict[str, Any]:
        """Get health summary."""
        return {
            "score": self.health_score,
            "status": "healthy" if self.health_score >= 80 else "degraded" if self.health_score >= 50 else "unhealthy",
            "issues": self.issues.copy()
        }


@dataclass
class ChangeComponent(ForgeComponent):
    """Change tracking component."""
    change_class: Optional[ChangeClass] = None
    affected_nodes: List[str] = field(default_factory=list)
    breaking: bool = False
    context: Dict[str, Any] = field(default_factory=dict)
    
    def track_change(self, change_class: ChangeClass, affected_nodes: List[str] = None, breaking: bool = False):
        """Track a change event."""
        self.change_class = change_class
        self.affected_nodes = affected_nodes or []
        self.breaking = breaking
    
    def get_impact_summary(self) -> Dict[str, Any]:
        """Get change impact summary."""
        return {
            "change_class": self.change_class.value if self.change_class else None,
            "affected_nodes": self.affected_nodes.copy(),
            "breaking": self.breaking,
            "context": self.context.copy()
        }


@dataclass
class AnnotationComponent(ForgeComponent):
    """Annotation management component."""
    annotations: List[Any] = field(default_factory=list)
    # List[AuditAnnotation] — Any used to avoid circular import at dataclass definition time
    annotation_kinds: List[AnnotationKind] = field(default_factory=list)

    def add_annotation(self, annotation: Any) -> None:
        """Add annotation. Accepts AuditAnnotation or dict (auto-converted via from_dict)."""
        from forge.tools.audit.bundle import AuditAnnotation

        if isinstance(annotation, dict):
            annotation = AuditAnnotation.from_dict(annotation)
        if not isinstance(annotation, AuditAnnotation):
            raise TypeError(
                f"Expected AuditAnnotation or dict, got {type(annotation)}"
            )
        self.annotations.append(annotation)
        kind_str = annotation.kind
        if kind_str:
            try:
                ak = AnnotationKind(kind_str)
                if ak not in self.annotation_kinds:
                    self.annotation_kinds.append(ak)
            except ValueError:
                pass

    def get_annotations_by_kind(self, kind: AnnotationKind) -> list[Any]:
        """Return AuditAnnotation objects of kind."""
        return [a for a in self.annotations if a.kind == kind.value]

    def get_all(self) -> list[Any]:
        """Return all AuditAnnotation objects."""
        return list(self.annotations)

    def get_by_id(self, annotation_id: str) -> Any | None:
        """Return AuditAnnotation by id or None."""
        return next(
            (a for a in self.annotations if a.id == annotation_id),
            None,
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize component for MCP/JSON output."""
        return {
            "annotations": [a.to_dict() for a in self.annotations],
            "annotation_kinds": [k.value for k in self.annotation_kinds],
            "count": len(self.annotations),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AnnotationComponent:
        from forge.tools.audit.bundle import AuditAnnotation

        comp = cls()
        for a in data.get("annotations", []):
            comp.add_annotation(
                AuditAnnotation.from_dict(a) if isinstance(a, dict) else a
            )
        return comp


@dataclass
class PipelineComponent(ForgeComponent):
    """Pipeline execution component."""
    pipeline_id: str = ""
    steps: List[Dict[str, Any]] = field(default_factory=list)
    current_step: int = 0
    status: str = "pending"
    
    def add_step(self, step_kind: PipelineStepKind, step_data: Dict[str, Any]):
        """Add a pipeline step."""
        self.steps.append({
            "kind": step_kind.value,
            "data": step_data,
            "status": "pending"
        })
    
    def execute_next_step(self) -> bool:
        """Execute the next step."""
        if self.current_step >= len(self.steps):
            return False
        
        # Would implement step execution logic here
        self.current_step += 1
        return True


@dataclass
class ErrorComponent(ForgeComponent):
    """Error handling component."""
    errors: List[Dict[str, Any]] = field(default_factory=list)
    error_domain: Optional[ErrorDomain] = None
    severity: SeverityLevel = SeverityLevel.INFO
    
    def add_error(self, error: Dict[str, Any]):
        """Add an error."""
        self.errors.append(error)
    
    def get_errors_by_domain(self, domain: ErrorDomain) -> List[Dict[str, Any]]:
        """Get errors by domain."""
        return [e for e in self.errors if e.get("domain") == domain.value]


# === EXTENDED GRAPH / GLOVE / STACK COMPONENTS ===

# === GRAPH SYSTEM COMPONENTS ===

@dataclass
class GraphLayer:
    """A single graph dimension — declaration, execution, intent, contract, etc."""
    name: str
    node_id: str
    graph: Any  # ManifestGraph or other graph type
    
    def siblings(self) -> list[Any]:
        if hasattr(self.graph, 'find_siblings_by_id'):
            return self.graph.find_siblings_by_id(self.node_id)
        return self.graph.find_siblings(self.node_id) if hasattr(self.graph, 'find_siblings') else []
    
    def ancestors(self) -> list[Any]:
        if hasattr(self.graph, 'find_ancestors_by_id'):
            return self.graph.find_ancestors_by_id(self.node_id)
        return self.graph.find_ancestors(self.node_id) if hasattr(self.graph, 'find_ancestors') else []
    
    def descendants(self) -> list[Any]:
        if hasattr(self.graph, 'find_descendants_by_id'):
            return self.graph.find_descendants_by_id(self.node_id)
        return self.graph.find_descendants(self.node_id) if hasattr(self.graph, 'find_descendants') else []
    
    def edges_out(self) -> list[Any]:
        if hasattr(self.graph, 'edges_from_by_id'):
            return self.graph.edges_from_by_id(self.node_id)
        return self.graph.edges_from(self.node_id) if hasattr(self.graph, 'edges_from') else []
    
    def edges_in(self) -> list[Any]:
        if hasattr(self.graph, 'edges_to_by_id'):
            return self.graph.edges_to_by_id(self.node_id)
        return self.graph.edges_to(self.node_id) if hasattr(self.graph, 'edges_to') else []
    
    def blast_radius(self, change_kind: str = "any") -> dict:
        if hasattr(self.graph, 'blast_radius_ring2'):
            return self.graph.blast_radius_ring2(self.node_id, change_kind)
        return {}
    
    def watchers(self) -> list[Any]:
        if hasattr(self.graph, "find_watchers"):
            return self.graph.find_watchers(self.node_id)
        return []


@dataclass
class TriangulationResult:
    """Result of querying across multiple graph layers."""
    query: str
    node_id: str
    layers_queried: list[str]
    per_layer: dict[str, set[str]] = field(default_factory=dict)
    
    @property
    def intersection(self) -> set[str]:
        """Entities present in ALL layers — highest confidence."""
        if not self.per_layer:
            return set()
        sets = list(self.per_layer.values())
        return sets[0].intersection(*sets[1:]) if len(sets) > 1 else sets[0]
    
    @property
    def union(self) -> set[str]:
        """Entities present in ANY layer — broadest coverage."""
        result = set()
        for s in self.per_layer.values():
            result |= s
        return result
    
    @property
    def confidence(self) -> dict[str, float]:
        """Confidence score per entity — 1.0 = in all layers."""
        total = len(self.per_layer)
        if not total:
            return {}
        counts: dict[str, int] = {}
        for s in self.per_layer.values():
            for node_id in s:
                counts[node_id] = counts.get(node_id, 0) + 1
        return {k: round(v / total, 2) for k, v in counts.items()}
    
    def top(self, n: int = 10) -> list[tuple[str, float]]:
        """Highest confidence affected entities."""
        return sorted(self.confidence.items(), key=lambda x: -x[1])[:n]
    
    def to_dict(self) -> dict:
        return {
            "query": self.query,
            "node_id": self.node_id,
            "layers_queried": self.layers_queried,
            "intersection": list(self.intersection),
            "union": list(self.union),
            "top_confidence": self.top(10),
            "confidence_scores": self.confidence,
        }


@dataclass
class GraphComponent(ForgeComponent):
    """Multi-layer graph component — entity's position across all graph dimensions."""
    node_id: str = ""
    _layers: Dict[str, GraphLayer] = field(default_factory=dict)
    _graph_system: Any = None  # reference to GraphSystem
    
    def add_layer(self, name: str, graph: Any) -> "GraphComponent":
        self._layers[name] = GraphLayer(name=name, node_id=self.node_id, graph=graph)
        return self
    
    def in_layer(self, name: str) -> GraphLayer | None:
        return self._layers.get(name)
    
    # Convenience methods — delegate to declaration layer by default
    def siblings(self, layer: str = "declaration") -> list[Any]:
        l = self._layers.get(layer)
        return l.siblings() if l else []
    
    def ancestors(self, layer: str = "declaration") -> list[Any]:
        l = self._layers.get(layer)
        return l.ancestors() if l else []
    
    def descendants(self, layer: str = "declaration") -> list[Any]:
        l = self._layers.get(layer)
        return l.descendants() if l else []
    
    def edges_out(self, layer: str = "declaration") -> list[Any]:
        l = self._layers.get(layer)
        return l.edges_out() if l else []
    
    def edges_in(self, layer: str = "declaration") -> list[Any]:
        l = self._layers.get(layer)
        return l.edges_in() if l else []
    
    def blast_radius(self, change_kind: str = "any", layer: str = "declaration") -> dict:
        l = self._layers.get(layer)
        return l.blast_radius(change_kind) if l else {}
    
    def triangulate(self, query: str, layers: list[str] | None = None, 
                    **kwargs) -> TriangulationResult:
        """Query across multiple graph layers and intersect results."""
        target_layers = layers or list(self._layers.keys())
        result = TriangulationResult(
            query=query,
            node_id=self.node_id,
            layers_queried=target_layers,
        )
        for layer_name in target_layers:
            layer = self._layers.get(layer_name)
            if not layer:
                continue
            method = getattr(layer, query, None)
            if callable(method):
                raw = method(**kwargs)
                # Normalize to set of ids
                ids = set()
                for item in (raw if isinstance(raw, list) else raw.get("watchers", [])):
                    if hasattr(item, "id"):
                        ids.add(item.id)
                    elif isinstance(item, str):
                        ids.add(item)
                result.per_layer[layer_name] = ids
        return result
    
    def to_dict(self) -> dict:
        return {
            "node_id": self.node_id,
            "layers": list(self._layers.keys()),
        }


@dataclass
class ManifestGraphComponent(GraphComponent):
    """Manifest graph specific component."""
    manifest_path: str = ""
    auto_load: bool = True
    cache_enabled: bool = True
    
    def awake(self):
        """Initialize manifest graph."""
        super().awake()
        self.graph_type = "manifest"
        
        if self.auto_load and self.entity and self.entity.project:
            self.load_manifest_graph()
    
    def load_manifest_graph(self) -> Optional[ManifestGraph]:
        """Load manifest from file."""
        if not self.manifest_path and self.entity and self.entity.project:
            self.manifest_path = str(self.entity.project.root_path / ".forge" / "manifest.yaml")
        
        if not self.manifest_path:
            return None
        
        try:
            from forge.tools.manifest.graph import build_manifest_graph
            graph = build_manifest_graph(self.manifest_path, str(self.entity.project.root_path))
            
            # Store in game resources
            if self.entity.project:
                self.entity.project.set_resource("manifest_graph", graph)
            
            self.node_count = len(graph.nodes)
            self.edge_count = len(graph.edges)
            
            return graph
        except Exception as e:
            self.sync_errors.append(f"Failed to load manifest: {e}")
            return None
    
    def get_nodes_by_kind(self, kind: str) -> List[ManifestNode]:
        """Get nodes filtered by kind."""
        graph = self.get_graph()
        if not graph:
            return []
        return [node for node in graph.nodes if node.kind == kind]
    
    def get_nodes_by_tier(self, tier: NodeTier) -> List[ManifestNode]:
        """Get nodes filtered by tier."""
        graph = self.get_graph()
        if not graph:
            return []
        return [node for node in graph.nodes 
                if node.meta.get("tier") == tier.value]


@dataclass
class ExecutionGraphComponent(GraphComponent):
    """Execution graph component for runtime tracking."""
    trace_enabled: bool = True
    performance_tracking: bool = True
    max_trace_depth: int = 100
    
    def awake(self):
        """Initialize execution graph."""
        super().awake()
        self.graph_type = "execution"
        
        if self.entity and self.entity.project:
            self.entity.project.set_resource("execution_graph", ExecutionGraph())
    
    def start_trace(self, node_id: str, operation: str) -> str:
        """Start tracing an operation."""
        if not self.trace_enabled:
            return ""
        
        # Would implement trace start logic here
        return f"trace_{node_id}_{operation}_{hash(node_id)}"
    
    def end_trace(self, trace_id: str, result: Any = None):
        """End a trace."""
        if not self.trace_enabled or not trace_id:
            return
        
        # Would implement trace end logic here
        pass


@dataclass
class WorkspaceGraphComponent(GraphComponent):
    """Workspace graph component for multi-project management."""
    workspace_path: str = ""
    project_count: int = 0
    dependency_count: int = 0
    
    def awake(self):
        """Initialize workspace graph."""
        super().awake()
        self.graph_type = "workspace"
    
    def scan_workspace(self) -> bool:
        """Scan workspace for projects."""
        if not self.workspace_path and self.entity and self.entity.project:
            self.workspace_path = str(self.entity.project.root_path)
        
        if not self.workspace_path:
            return False
        
        try:
            # Would implement workspace scanning logic here
            # This would discover forge projects and build dependency graph
            return True
        except Exception as e:
            self.sync_errors.append(f"Workspace scan failed: {e}")
            return False


# === GLOVE SYSTEM COMPONENTS ===

@dataclass
class GloveComponent(ForgeComponent):
    """Project-domain extension point — invoke domain-specific methods."""
    domain: str = ""
    glove_path: str = ""
    stack: str = ""
    glove_class: Optional[str] = None
    auto_discover: bool = True
    last_analysis: Optional[str] = None
    extracted_nodes: List[RawNode] = field(default_factory=list)
    extracted_edges: List[RawEdge] = field(default_factory=list)
    _methods: Dict[str, Any] = field(default_factory=dict)
    _loaded: bool = False
    
    def get_glove(self) -> Optional[GloveProtocol]:
        """Get the glove protocol instance."""
        if self.entity and self.entity.project:
            return self.entity.project.get_resource(f"glove_{self.stack}")
        return None
    
    def run_analysis(self, project_path: Optional[Path] = None) -> bool:
        """Run glove analysis on project."""
        glove = self.get_glove()
        if not glove:
            return False
        
        if not project_path and self.entity and self.entity.project:
            project_path = self.entity.project.root_path
        
        try:
            # Would run glove analysis here
            # output = glove.extract(project_path)
            # self.extracted_nodes = output.nodes
            # self.extracted_edges = output.edges
            return True
        except Exception as e:
            self.sync_errors.append(f"Analysis failed: {e}")
            return False
    
    def validate(self) -> List[str]:
        """Validate glove configuration."""
        errors = []
        if not self.stack:
            errors.append("Stack name is required")
        glove = self.get_glove()
        if not glove:
            errors.append(f"Glove protocol not found for stack: {self.stack}")
        return errors
    
    def awake(self):
        super().awake()
        if self.glove_path:
            self._load_glove()
    
    def _load_glove(self):
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location(
                f"glove_{self.domain}", self.glove_path
            )
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            # Register all public methods
            for name in dir(mod):
                if not name.startswith('_'):
                    obj = getattr(mod, name)
                    if callable(obj):
                        self._methods[name] = obj
            self._loaded = True
        except Exception as e:
            pass

        if not self._loaded:
            try:
                from forge.core.stack_profiles import get_glove_for_stack

                stack = (self.stack or "").lower()
                adapter = get_glove_for_stack(stack)
                if adapter is not None:
                    self._methods = {
                        name: getattr(adapter, name)
                        for name in dir(adapter)
                        if not name.startswith("_")
                        and callable(getattr(adapter, name, None))
                    }
                    self._loaded = bool(self._methods)
            except Exception:
                pass

    def can_invoke(self, method: str) -> bool:
        return method in self._methods
    
    def invoke(self, method: str, **kwargs) -> Any:
        if not self.can_invoke(method):
            raise ValueError(f"Method {method!r} not found in glove {self.domain!r}. "
                           f"Available: {list(self._methods.keys())}")
        return self._methods[method](**kwargs)
    
    def list_methods(self) -> list[str]:
        return list(self._methods.keys())
    
    def to_dict(self) -> dict:
        return {
            "domain": self.domain,
            "glove_path": self.glove_path,
            "methods": self.list_methods(),
            "loaded": self._loaded,
        }


@dataclass
class StackProfileComponent(ForgeComponent):
    """Stack profile component for configuration management."""
    stack_id: str = ""
    profile_path: str = ""
    template_paths: List[str] = field(default_factory=list)
    glove_class: Optional[str] = None
    schema_slice: Optional[str] = None
    
    def load_profile(self) -> bool:
        """Load stack profile from configuration."""
        if not self.profile_path:
            return False
        
        try:
            # Would load profile from YAML/JSON here
            return True
        except Exception as e:
            self.sync_errors.append(f"Profile load failed: {e}")
            return False
    
    def get_template_for_kind(self, kind: str) -> Optional[str]:
        """Get template path for a node kind."""
        # Would implement template resolution logic here
        return None


@dataclass
class ImportResolutionComponent(ForgeComponent):
    """Import resolution component for cross-stack compatibility."""
    strategy: str = "stack_agnostic"
    resolution_rules: Dict[str, Any] = field(default_factory=dict)
    unresolved_imports: List[str] = field(default_factory=list)
    
    def resolve_import(self, import_path: str, from_stack: str) -> Optional[str]:
        """Resolve an import path to a manifest node ID."""
        # Would implement import resolution logic here
        return None
    
    def add_resolution_rule(self, pattern: str, target: str):
        """Add a resolution rule."""
        self.resolution_rules[pattern] = target
    
    def validate_imports(self) -> List[str]:
        """Validate all imports and return unresolved ones."""
        # Would implement import validation logic here
        return []


# === STACK-AGNOSTIC COMPONENTS ===

@dataclass
class SemanticAnalysisComponent(ForgeComponent):
    """Semantic analysis component for code understanding."""
    analyzer_type: str = "nlp"  # nlp, pattern, hybrid
    confidence_threshold: float = 0.7
    extracted_concepts: List[Dict[str, Any]] = field(default_factory=list)
    domain_terms: List[str] = field(default_factory=list)
    
    def analyze_text(self, text: str) -> List[Dict[str, Any]]:
        """Analyze text for semantic concepts."""
        # Would implement semantic analysis here
        return []
    
    def extract_domain_terms(self, text: str) -> List[str]:
        """Extract domain-specific terms."""
        # Would implement domain term extraction here
        return []
    
    def get_concept_graph(self) -> Dict[str, Any]:
        """Get concept relationship graph."""
        # Would build concept relationships here
        return {}


@dataclass
class FrameworkDetectionComponent(ForgeComponent):
    """Framework detection component for automatic stack identification."""
    detected_frameworks: List[str] = field(default_factory=list)
    confidence_scores: Dict[str, float] = field(default_factory=dict)
    detection_rules: Dict[str, Any] = field(default_factory=dict)
    
    def detect_frameworks(self, project_path: Optional[Path] = None) -> Dict[str, float]:
        """Detect frameworks used in the project."""
        if not project_path and self.entity and self.entity.project:
            project_path = self.entity.project.root_path
        
        # Would implement framework detection logic here
        # Check package.json, requirements.txt, pubspec.yaml, etc.
        return {}
    
    def get_primary_framework(self) -> Optional[str]:
        """Get the primary framework with highest confidence."""
        if not self.confidence_scores:
            return None
        return max(self.confidence_scores, key=self.confidence_scores.get)


@dataclass
class ContractValidationComponent(ForgeComponent):
    """Contract validation component for interface compliance."""
    contract_definitions: Dict[str, Any] = field(default_factory=dict)
    validation_results: Dict[str, bool] = field(default_factory=dict)
    contract_violations: List[Dict[str, Any]] = field(default_factory=list)
    
    def add_contract_definition(self, contract_id: str, definition: Dict[str, Any]):
        """Add a contract definition."""
        self.contract_definitions[contract_id] = definition
    
    def validate_contract(self, contract_id: str, implementation: Any) -> bool:
        """Validate an implementation against a contract."""
        if contract_id not in self.contract_definitions:
            return False
        
        # Would implement contract validation logic here
        return True
    
    def get_violations(self) -> List[Dict[str, Any]]:
        """Get all contract violations."""
        return self.contract_violations.copy()


# === METRICS AND MONITORING COMPONENTS ===

@dataclass
class MetricsComponent(ForgeComponent):
    """Metrics collection and monitoring component."""
    metric_types: List[str] = field(default_factory=list)
    metric_values: Dict[str, float] = field(default_factory=dict)
    collection_interval: float = 1.0  # seconds
    last_collection: Optional[float] = None
    
    def add_metric_type(self, metric_type: str):
        """Add a metric type to track."""
        if metric_type not in self.metric_types:
            self.metric_types.append(metric_type)
    
    def record_metric(self, metric_type: str, value: float):
        """Record a metric value."""
        self.metric_values[metric_type] = value
    
    def get_metric(self, metric_type: str) -> Optional[float]:
        """Get a metric value."""
        return self.metric_values.get(metric_type)
    
    def get_all_metrics(self) -> Dict[str, float]:
        """Get all metrics."""
        return self.metric_values.copy()
    
    def collect_if_due(self) -> None:
        """Collect metrics when collection interval has elapsed."""
        import time
        current_time = time.time()
        
        if self.last_collection is None:
            self.last_collection = current_time
            return
        
        if current_time - self.last_collection >= self.collection_interval:
            self.collect_metrics()
            self.last_collection = current_time
    
    def collect_metrics(self):
        """Collect current metrics."""
        # Would implement metric collection logic here
        pass


@dataclass
class TraceComponent(ForgeComponent):
    """Trace management component for execution tracking."""
    trace_enabled: bool = True
    trace_storage: str = "memory"  # memory, file, database
    active_traces: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    completed_traces: List[Dict[str, Any]] = field(default_factory=list)
    
    def start_trace(self, operation: str, context: Dict[str, Any] = None) -> str:
        """Start a new trace."""
        if not self.trace_enabled:
            return ""
        
        import time
        import uuid
        
        trace_id = str(uuid.uuid4())
        self.active_traces[trace_id] = {
            "operation": operation,
            "start_time": time.time(),
            "context": context or {}
        }
        return trace_id
    
    def end_trace(self, trace_id: str, result: Any = None, error: Any = None):
        """End a trace."""
        if trace_id not in self.active_traces:
            return
        
        import time
        trace = self.active_traces.pop(trace_id)
        trace["end_time"] = time.time()
        trace["duration"] = trace["end_time"] - trace["start_time"]
        trace["result"] = result
        trace["error"] = error
        
        self.completed_traces.append(trace)
        
        # Cleanup old traces if too many
        if len(self.completed_traces) > 1000:
            self.completed_traces = self.completed_traces[-500:]
    
    def get_trace_statistics(self) -> Dict[str, Any]:
        """Get trace statistics."""
        if not self.completed_traces:
            return {}
        
        durations = [t["duration"] for t in self.completed_traces if "duration" in t]
        errors = [t for t in self.completed_traces if t.get("error")]
        
        return {
            "total_traces": len(self.completed_traces),
            "error_count": len(errors),
            "avg_duration": sum(durations) / len(durations) if durations else 0,
            "max_duration": max(durations) if durations else 0,
            "min_duration": min(durations) if durations else 0
        }


@dataclass
class EventComponent(ForgeComponent):
    """Event handling and routing component."""
    event_handlers: Dict[str, List[callable]] = field(default_factory=dict)
    event_queue: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class OrientComponent(ForgeComponent):
    """Orientation-specific component for session and scaffold operations."""
    # Core identity
    project: str = ""
    stack: str = "unknown"
    
    # Phase and task state
    phase: int = 0
    phase_name: str = ""
    current_task: str = ""
    blocker: str = ""
    next_action: str = ""
    
    # Health signals
    warnings: List[str] = field(default_factory=list)
    packets: Dict[str, Any] = field(default_factory=lambda: {
        "pending": 0,
        "expired": 0,
        "failed": 0
    })
    infra_health: Dict[str, Any] = field(default_factory=dict)
    structural_health: str = "clean"
    
    # Meta
    response_tier: str = "L0"
    generated_at: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize with tier-based filtering."""
        base_dict = {
            "type": self.__class__.__name__,
            "active": self.active,
            "data": {
                "project": self.project,
                "stack": self.stack,
                "phase": self.phase,
                "phase_name": self.phase_name,
                "current_task": self.current_task,
                "blocker": self.blocker,
                "next_action": self.next_action,
                "warnings": self.warnings,
                "packets": self.packets,
                "infra_health": self.infra_health,
                "structural_health": self.structural_health,
                "response_tier": self.response_tier,
                "generated_at": self.generated_at
            }
        }
        
        # Filter based on response tier
        if self.response_tier == "L0":
            # L0 returns minimal data
            return {
                **base_dict,
                "project": self.project,
                "phase": self.phase,
                "phase_name": self.phase_name,
                "stack": self.stack,
                "current_task": self.current_task,
                "blocker": self.blocker,
                "next_action": self.next_action,
                "warnings": self.warnings,
                "packets": self.packets,
                "infra_health": self.infra_health,
                "suggested_next": ["forge_context(section=phase)", "forge_context(section=tasks)"],
                "generated_at": self.generated_at
            }
        else:
            # L1+ returns full data
            return base_dict
    processing_enabled: bool = True
    
    def register_handler(self, event_type: str, handler: callable):
        """Register an event handler."""
        if event_type not in self.event_handlers:
            self.event_handlers[event_type] = []
        self.event_handlers[event_type].append(handler)
    
    def emit_event(self, event_type: str, data: Dict[str, Any] = None):
        """Emit an event."""
        event = {
            "type": event_type,
            "data": data or {},
            "timestamp": self._get_timestamp()
        }
        self.event_queue.append(event)
    
    def process_events(self):
        """Process all queued events."""
        if not self.processing_enabled:
            return
        
        while self.event_queue:
            event = self.event_queue.pop(0)
            self._handle_event(event)
    
    def _handle_event(self, event: Dict[str, Any]):
        """Handle a single event."""
        event_type = event["type"]
        handlers = self.event_handlers.get(event_type, [])
        
        for handler in handlers:
            try:
                handler(event)
            except Exception as e:
                # Log error but continue processing
                print(f"Event handler error: {e}")
    
    def _get_timestamp(self) -> float:
        """Get current timestamp."""
        import time
        return time.time()


# === FORGE SYSTEMS ===

class ForgeSystem(ABC):
    """Base system interface - like Unity's systems but Forge-native."""
    
    project: Optional[ForgeProject] = None
    name: str = ""
    active: bool = True
    
    def initialize(self):
        """Initialize system."""
        pass
    
    def destroy(self):
        """Cleanup system."""
        pass


class ManifestSystem(ForgeSystem):
    """Handles manifest synchronization and validation."""
    
    def __init__(self):
        self.name = "manifest"
    
    def sync(self) -> None:
        """Sync manifest components."""
        if not self.project:
            return
        
        for entity in self.project.get_entities(ManifestComponent):
            manifest = entity.get_component(ManifestComponent)
            if manifest and manifest.active:
                manifest.sync()


class ContractSystem(ForgeSystem):
    """Handles contract validation and enforcement."""
    
    def __init__(self):
        self.name = "contract"

    def validate(self) -> None:
        """Validate contract components."""
        if not self.project:
            return
        
        for entity in self.project.get_entities(ContractComponent):
            contract = entity.get_component(ContractComponent)
            if contract and contract.active:
                # Would implement contract validation logic here
                pass


class HealthSystem(ForgeSystem):
    """Handles health monitoring and scoring."""
    
    def __init__(self):
        self.name = "health"
    
    def score(self) -> None:
        """Score health components."""
        if not self.project:
            return
        
        for entity in self.project.get_entities(HealthComponent):
            health = entity.get_component(HealthComponent)
            if health and health.active:
                health.score()


class EventSystem(ForgeSystem):
    """Handles event routing and processing."""
    
    def __init__(self):
        self.name = "events"
        self._event_queue: List[Dict[str, Any]] = []
        self._hook_bus: Any | None = None

    def attach_hook_bus(self, hook_bus: Any) -> None:
        """Called by ForgeSession after project loads."""
        self._hook_bus = hook_bus

    def queue_event(self, event: Dict[str, Any]):
        """Queue an event."""
        self._event_queue.append(event)

    def process_pending_events(self) -> None:
        """Process queued events."""
        while self._event_queue:
            event = self._event_queue.pop(0)
            if self._hook_bus is not None:
                try:
                    kind = str(
                        event.get("event_type") or event.get("kind") or "unknown"
                    )
                    self._hook_bus._publish(kind, dict(event))
                except Exception:
                    pass


class ResourceSystem(ForgeSystem):
    """Handles resource management and loading."""
    
    def __init__(self):
        self.name = "resources"
    
    def load_resource(self, path: str) -> Any:
        """Load a resource."""
        # Would implement resource loading logic here
        return None


# === EXTENDED SYSTEMS ===

class GloveSystem(ForgeSystem):
    """System for managing glove components."""
    
    def __init__(self):
        self.name = "gloves"


class MetricsSystem(ForgeSystem):
    """System for managing metrics components."""
    
    def __init__(self):
        self.name = "metrics"
    
    def collect(self) -> None:
        """Collect metrics from all metrics components."""
        if not self.project:
            return
        
        for entity in self.project.get_entities(MetricsComponent):
            metrics_comp = entity.get_component(MetricsComponent)
            if metrics_comp and metrics_comp.active:
                metrics_comp.collect_if_due()


class ExecutionGraphLayer:
    """Adapter wrapping ExecutionGraph for GraphSystem layer protocol."""
    
    def __init__(self, execution_graph: Any):
        self.graph = execution_graph
        self._gs = None
        self.nodes = []
    
    def set_graph_system(self, gs: Any) -> None:
        self._gs = gs
    
    def edges_from(self, node_id: str) -> list:
        """What this node calls."""
        if hasattr(self.graph, 'get_calls'):
            return self.graph.get_calls(node_id)
        return []
    
    def edges_to(self, node_id: str) -> list:
        """What calls this node."""
        if hasattr(self.graph, 'get_callers'):
            return self.graph.get_callers(node_id)
        return []
    
    def find_siblings(self, node_id: str) -> list:
        return []
    
    def find_ancestors(self, node_id: str) -> list:
        return self.edges_to(node_id)
    
    def find_descendants(self, node_id: str) -> list:
        return self.edges_from(node_id)
    
    def is_live(self, node_id: str) -> bool:
        """Was this node actually executed?"""
        if hasattr(self.graph, 'was_executed'):
            return self.graph.was_executed(node_id)
        return False
    
    def find_siblings_by_id(self, node_id: str) -> list:
        return []
    
    def edges_to_by_id(self, node_id: str) -> list:
        file_path = self._gs._id_to_path.get(node_id) if self._gs else None
        if not file_path:
            return []
        return [self._gs.get_entity_id_for_file(f, self) for f in self.edges_to(file_path)]
    
    def edges_from_by_id(self, node_id: str) -> list:
        file_path = self._gs._id_to_path.get(node_id) if self._gs else None
        if not file_path:
            return []
        return [self._gs.get_entity_id_for_file(f, self) for f in self.edges_from(file_path)]
    
    def get_defines(self, node_id: str) -> list:
        return []
    
    def resolve_id(self, node_id: str) -> str:
        return node_id


@dataclass
class GraphSystem(ForgeSystem):
    """Unified multi-layer graph system — manages all graph dimensions."""
    _layers: Dict[str, Any] = field(default_factory=dict)
    _project: Any = None  # ForgeProject reference
    
    def __post_init__(self):
        self.name = "graph"
    
    def register_layer(self, name: str, graph: Any) -> None:
        self._layers[name] = graph
    
    def get_layer(self, name: str) -> Any:
        return self._layers.get(name)
    
    def triangulate(self, node_id: str, query: str, 
                    layers: list[str] | None = None, **kwargs) -> "TriangulationResult":
        target = layers or list(self._layers.keys())
        result = TriangulationResult(query=query, node_id=node_id, layers_queried=target)
        for layer_name in target:
            graph = self._layers.get(layer_name)
            if not graph:
                continue
            method = getattr(graph, f"find_{query}", None) or getattr(graph, query, None)
            if callable(method):
                try:
                    raw = method(node_id, **kwargs)
                    ids = set()
                    for item in (raw if isinstance(raw, list) else []):
                        if hasattr(item, "id"):
                            ids.add(item.id)
                        elif isinstance(item, str):
                            ids.add(item)
                    result.per_layer[layer_name] = ids
                except Exception:
                    pass
        return result
    
    def propagate(self, node_id: str, change_kind: str = "any") -> list[str]:
        """Propagate change through all layers, return union of affected nodes."""
        affected = set()
        for name, graph in self._layers.items():
            if hasattr(graph, "blast_radius_ring2"):
                result = graph.blast_radius_ring2(node_id, change_kind)
                for key in ["watchers", "dependents", "siblings"]:
                    for item in result.get(key, []):
                        if hasattr(item, "id"):
                            affected.add(item.id)
                        elif isinstance(item, str):
                            affected.add(item)
        return list(affected)
    
    def layers(self) -> list[str]:
        return list(self._layers.keys())
    
    def build_execution_layer(self, project_path: Path) -> None:
        """Build execution graph layer from existing ExecutionGraph."""
        try:
            from forge.core.execution_graph import ExecutionGraph
            exec_graph = ExecutionGraph()
            # Load any existing execution traces if available
            trace_path = project_path / '.forge' / 'execution_trace.json'
            if trace_path.exists():
                exec_graph.load(str(trace_path))
            adapter = ExecutionGraphLayer(exec_graph)
            adapter.set_graph_system(self)
            self.register_layer('execution', adapter)
        except Exception as e:
            # Execution layer is optional — don't fail if unavailable
            pass
    
    def build_intent_layer(self, project_path: Path) -> None:
        """Build intent graph layer from forge_intent records."""
        import yaml
        from pathlib import Path
        
        intents_path = project_path / '.forge' / 'intents'
        if not intents_path.exists():
            # Try alternate locations
            intents_path = project_path / '.forge'
        
        class IntentGraph:
            def __init__(self):
                self.intents = {}  # id -> intent record
                self.node_to_intents = {}  # node_id -> list of intent ids
                self._gs = None
            
            def set_graph_system(self, gs):
                self._gs = gs
            
            def load_intents(self, path: Path):
                for f in path.rglob('*.yaml'):
                    try:
                        data = yaml.safe_load(f.read_text())
                        if isinstance(data, dict) and data.get('scope') == 'node':
                            intent_id = data.get('id', str(f.stem))
                            self.intents[intent_id] = data
                            # Map to target node
                            target_id = data.get('target_id')
                            if target_id:
                                self.node_to_intents.setdefault(target_id, []).append(intent_id)
                    except Exception:
                        pass
            
            def get_intents_for_node(self, node_id: str) -> list:
                return self.node_to_intents.get(node_id, [])
            
            def has_intent(self, node_id: str) -> bool:
                return node_id in self.node_to_intents
            
            def find_siblings(self, node_id: str) -> list:
                """Nodes that share intents."""
                my_intents = set(self.get_intents_for_node(node_id))
                siblings = set()
                for nid, intents in self.node_to_intents.items():
                    if nid != node_id and my_intents & set(intents):
                        siblings.add(nid)
                return list(siblings)
            
            def find_siblings_by_id(self, node_id: str) -> list:
                return self.find_siblings(node_id)
            
            def edges_to(self, node_id: str) -> list:
                return self.get_intents_for_node(node_id)
            
            def edges_from(self, node_id: str) -> list:
                return []
            
            def edges_to_by_id(self, node_id: str) -> list:
                return self.get_intents_for_node(node_id)
            
            def edges_from_by_id(self, node_id: str) -> list:
                return []
            
            def find_ancestors_by_id(self, node_id: str) -> list:
                return self.edges_to_by_id(node_id)
            
            def find_descendants_by_id(self, node_id: str) -> list:
                return []
            
            def get_defines(self, node_id: str) -> list:
                return []
            
            def resolve_id(self, node_id: str) -> str:
                return node_id
            
            @property
            def nodes(self):
                return list(self.node_to_intents.keys())
        
        intent_graph = IntentGraph()
        intent_graph.load_intents(intents_path)
        intent_graph.set_graph_system(self)
        self.register_layer('intent', intent_graph)
    
    def build_contract_layer(self, project_path: Path) -> None:
        """Build contract graph from ContractGraph."""
        try:
            from forge.core.contract_graph import ContractGraph
            
            contract_graph = ContractGraph()
            
            class ContractLayer:
                def __init__(self, cg):
                    self.graph = cg
                    self._gs = None
                
                def set_graph_system(self, gs):
                    self._gs = gs
                
                def find_siblings_by_id(self, node_id: str) -> list:
                    # Nodes that share contracts
                    if hasattr(self.graph, 'intra_edges'):
                        edges = self.graph.intra_edges(node_id)
                        return [e.to_id for e in edges]
                    return []
                
                def edges_to_by_id(self, node_id: str) -> list:
                    # What contracts flow into this node
                    if hasattr(self.graph, 'inter_edges'):
                        return [e.from_id for e in self.graph.inter_edges(node_id)]
                    return []
                
                def edges_from_by_id(self, node_id: str) -> list:
                    if hasattr(self.graph, 'broken_edges'):
                        return [e.to_id for e in self.graph.broken_edges() 
                                if e.from_id == node_id]
                    return []
                
                def find_ancestors_by_id(self, node_id):
                    return self.edges_to_by_id(node_id)
                
                def find_descendants_by_id(self, node_id):
                    return self.edges_from_by_id(node_id)
                
                def get_defines(self, node_id):
                    return []
                
                def resolve_id(self, node_id):
                    return node_id
                
                @property
                def nodes(self):
                    return []
            
            layer = ContractLayer(contract_graph)
            layer.set_graph_system(self)
            self.register_layer('contract', layer)
        except Exception:
            pass
    
    def dead_code_analysis(self) -> dict:
        """
        Find code that is declared and imported but never executed.
        declaration ∩ static_imports - execution = dead code candidates
        """
        if not self._project:
            return {}
        
        decl = self.get_layer('declaration')
        static = self.get_layer('static_imports')
        execution = self.get_layer('execution')
        
        if not decl or not static:
            return {"error": "requires declaration and static_imports layers"}
        
        # All declared entities
        declared_ids = set(self._project._entities.keys())
        
        # Entities that appear in static imports (actually imported somewhere)
        imported_ids = set()
        for node in (static.nodes if hasattr(static, 'nodes') else []):
            entity_id = static.resolve_id(node)
            if not entity_id.startswith('undeclared/'):
                imported_ids.add(entity_id)
        
        # Entities confirmed live in execution layer
        live_ids = set()
        if execution and hasattr(execution, 'graph'):
            for entity in self._project._entities.values():
                if execution.is_live(entity.id):
                    live_ids.add(entity.id)
        
        # Dead code = declared + imported but not executed
        declared_and_imported = declared_ids & imported_ids
        dead_candidates = declared_and_imported - live_ids if live_ids else set()
        
        return {
            "declared": len(declared_ids),
            "imported": len(imported_ids),
            "live": len(live_ids),
            "dead_candidates": len(dead_candidates),
            "dead_candidate_ids": sorted(list(dead_candidates))[:20],
            "note": "execution layer empty — run forge with tracing enabled to populate" if not live_ids else ""
        }
    
    def sync_with_codebase(self, project_path: Path, 
                           dry_run: bool = True) -> dict:
        """
        Scan codebase, find undeclared files, infer manifest entries.
        dry_run=True returns what would be declared without writing.
        dry_run=False appends new nodes to manifest.
        """
        import yaml
        
        static = self.get_layer('static_imports')
        if not static:
            return {"error": "static_imports layer required"}
        
        # Find undeclared files
        undeclared = []
        for file_path in static.nodes:
            entity = self.resolve_entity_for_file(file_path, static)
            if entity is None:
                defines = static.get_defines(file_path)
                if not defines:
                    continue  # skip empty files
                undeclared.append({
                    "file_path": file_path,
                    "defines": defines,
                })
        
        # Infer manifest metadata for each undeclared file
        new_nodes = []
        for item in undeclared:
            path = item["file_path"]
            defines = item["defines"]
            
            # Infer domain from directory
            parts = path.replace('forge/', '').split('/')
            domain = parts[0].upper() if parts else "CORE"
            domain_map = {
                "commands": "COMMANDS", "core": "CORE", "mcp": "MCP",
                "tools": "TOOLS", "renderers": "RENDERERS", "protocols": "PROTOCOLS",
                "gloves": "GLOVES", "events": "EVENTS", "metrics": "METRICS",
                "checkers": "CHECKERS", "workspace": "CORE", "cli": "COMMANDS",
            }
            domain = domain_map.get(parts[0], parts[0].upper())
            
            # Infer kind from path and defines
            kind = "module"
            if "test" in path:
                kind = "test"
            elif "glove" in path:
                kind = "glove"
            elif "renderer" in path:
                kind = "renderer"
            elif "protocol" in path:
                kind = "protocol"
            
            # Infer tier
            tier = "worker"
            if "gate" in path or "validator" in path:
                tier = "gate"
            elif "schema" in path or "model" in path:
                tier = "schema"
            
            # Build node ID from path
            node_id = path.replace('forge/', '').replace('.py', '').replace('/', '.')
            node_id = f"{kind}/{node_id}"
            
            # Extract owns from defines
            owns = [d.split(':')[1] for d in defines 
                    if ':' in d and not d.startswith('class:_') 
                    and not d.startswith('def:_')][:5]
            
            node = {
                "id": node_id,
                "kind": kind,
                "name": path.split('/')[-1].replace('.py', ''),
                "path": path,
                "domain": domain,
                "tier": tier,
                "role": f"Auto-declared by sync_with_codebase — {len(defines)} definitions",
                "owns": owns if owns else [],
            }
            new_nodes.append(node)
        
        result = {
            "undeclared_count": len(undeclared),
            "new_nodes_count": len(new_nodes),
            "dry_run": dry_run,
            "sample": new_nodes[:5],
        }
        
        if not dry_run:
            # Append to manifest
            manifest_path = project_path / '.forge' / 'manifest.yaml'
            with open(manifest_path) as f:
                manifest = yaml.safe_load(f)
            
            existing_ids = {n.get('id') for n in manifest.get('nodes', [])}
            truly_new = [n for n in new_nodes if n['id'] not in existing_ids]
            
            manifest.setdefault('nodes', []).extend(truly_new)
            
            with open(manifest_path, 'w') as f:
                yaml.dump(manifest, f, allow_unicode=True, 
                         sort_keys=False, indent=2)
            
            result["written"] = len(truly_new)
            result["manifest_path"] = str(manifest_path)
        
        return result
    
    def build_entity_index(self) -> None:
        """Build lookup indexes for robust file-to-entity resolution."""
        self._path_to_entity: dict[str, Any] = {}
        self._owns_to_entity: dict[str, Any] = {}
        self._id_to_path: dict[str, str] = {}  # ADD THIS
        
        if not self._project:
            return
        
        for entity in self._project._entities.values():
            # Path index
            path = entity._properties.get("path")
            if path:
                self._path_to_entity[path] = entity
                self._id_to_path[entity.id] = path  # ADD THIS
            
            # Owns index — map each owned symbol to its entity
            owned = entity._properties.get("meta", {}).get("owns", [])
            if owned:
                for symbol in owned:
                    # Only use hashable types as keys (strings, not dicts)
                    if isinstance(symbol, str):
                        self._owns_to_entity[symbol] = entity
                    elif hasattr(symbol, 'name') and isinstance(symbol.name, str):
                        # Handle objects with name attribute
                        self._owns_to_entity[symbol.name] = entity

    def resolve_entity_for_file(self, file_path: str, 
                             static_graph: Any) -> Any | None:
        """Resolve file path to entity using three-level hierarchy."""
        # Level 1: owns match — most authoritative
        file_defines = set(
            d.split(':')[1] for d in static_graph.get_defines(file_path)
        )
        for symbol in file_defines:
            entity = self._owns_to_entity.get(symbol)
            if entity:
                return entity
        
        # Level 2: path field match — fallback
        entity = self._path_to_entity.get(file_path)
        if entity:
            return entity
        
        # Level 3: no match — file is undeclared
        return None

    def get_entity_id_for_file(self, file_path: str, 
                            static_graph: Any) -> str:
        """Get canonical entity ID for a file, or synthetic ID if undeclared."""
        entity = self.resolve_entity_for_file(file_path, static_graph)
        if entity:
            return entity.id
        
        # Synthetic content-addressed ID for undeclared files
        import hashlib
        defines = static_graph.get_defines(file_path)
        content = str(sorted(defines))
        hash_val = hashlib.md5(content.encode()).hexdigest()[:8]
        return f"undeclared/{hash_val}"
    
    def build_static_import_layer(self, project_path: Path) -> None:
        """Scan all Python files and build a static import graph as a layer."""
        import ast
        from collections import defaultdict
        
        # Build import relationships
        imports_from: dict[str, set[str]] = defaultdict(set)  # file -> modules it imports
        imported_by: dict[str, set[str]] = defaultdict(set)   # module -> files that import it
        defines: dict[str, list[str]] = {}                     # file -> classes/functions defined
        
        forge_root = project_path
        
        for py_file in (forge_root / 'forge').rglob('*.py'):
            if any(x in str(py_file) for x in ['__pycache__', 'archive', '_reference', 'component_enhanced']):
                continue
            rel = str(py_file.relative_to(forge_root))
            mod_key = rel.replace('/', '.').replace('.py', '')
            
            try:
                tree = ast.parse(py_file.read_text())
                file_imports = set()
                file_defines = []
                
                for node in ast.walk(tree):
                    if isinstance(node, ast.ImportFrom) and node.module and node.module.startswith('forge'):
                        file_imports.add(node.module)
                        imported_by[node.module].add(rel)
                    elif isinstance(node, ast.Import):
                        for alias in node.names:
                            if alias.name.startswith('forge'):
                                file_imports.add(alias.name)
                                imported_by[alias.name].add(rel)
                    elif isinstance(node, ast.ClassDef):
                        file_defines.append(f'class:{node.name}')
                    elif isinstance(node, ast.FunctionDef):
                        file_defines.append(f'def:{node.name}')
                
                imports_from[rel] = file_imports
                defines[rel] = file_defines
            except Exception:
                pass
        
        # Create a simple graph-like object that GraphLayer can use
        class StaticImportGraph:
            def __init__(self, imports_from, imported_by, defines):
                self.imports_from = imports_from
                self.imported_by = imported_by
                self.defines = defines
                self.nodes = list(imports_from.keys())
            
            def edges_from(self, node_id: str) -> list:
                """What this file imports."""
                return list(self.imports_from.get(node_id, set()))
            
            def edges_to(self, node_id: str) -> list:
                """What imports this file."""
                # Match by path or module name
                result = set()
                for mod, importers in self.imported_by.items():
                    if node_id.replace('/', '.').replace('.py', '') in mod or mod in node_id:
                        result.update(importers)
                return list(result)
            
            def find_siblings(self, node_id: str) -> list:
                """Files that import the same modules."""
                my_imports = self.imports_from.get(node_id, set())
                siblings = set()
                for f, imports in self.imports_from.items():
                    if f != node_id and my_imports & imports:
                        siblings.add(f)
                return list(siblings)
            
            def find_ancestors(self, node_id: str) -> list:
                return self.edges_to(node_id)
            
            def find_descendants(self, node_id: str) -> list:
                return self.edges_from(node_id)
            
            def get_defines(self, node_id: str) -> list:
                return self.defines.get(node_id, [])
            
            def is_orphaned(self, node_id: str) -> bool:
                """Never imported by anything."""
                return len(self.edges_to(node_id)) == 0
            
            def set_graph_system(self, gs: Any) -> None:
                """Wire GraphSystem for entity-aware ID resolution."""
                self._gs = gs

            def resolve_id(self, file_path: str) -> str:
                """Resolve file path to canonical entity ID."""
                if self._gs:
                    return self._gs.get_entity_id_for_file(file_path, self)
                # Fallback synthetic ID if no graph system
                import hashlib
                defines = self.get_defines(file_path)
                content = str(sorted(defines))
                return f"undeclared/{hashlib.md5(content.encode()).hexdigest()[:8]}"

            def find_siblings_by_id(self, node_id: str) -> list[str]:
                """Find siblings, returning canonical entity IDs."""
                # Find the file for this node_id
                file_path = None
                if self._gs:
                    file_path = self._gs._id_to_path.get(node_id)
                if not file_path:
                    return []
                siblings = self.find_siblings(file_path)
                return [self.resolve_id(f) for f in siblings]

            def edges_to_by_id(self, node_id: str) -> list[str]:
                """Get importers as canonical entity IDs."""
                file_path = None
                if self._gs:
                    file_path = self._gs._id_to_path.get(node_id)
                if not file_path:
                    return []
                return [self.resolve_id(f) for f in self.edges_to(file_path)]

            def edges_from_by_id(self, node_id: str) -> list[str]:
                """Get imports as canonical entity IDs."""
                file_path = None
                if self._gs:
                    file_path = self._gs._id_to_path.get(node_id)
                if not file_path:
                    return []
                return [self.resolve_id(f) for f in self.edges_from(file_path)]

            def find_ancestors_by_id(self, node_id: str) -> list[str]:
                return self.edges_to_by_id(node_id)

            def find_descendants_by_id(self, node_id: str) -> list[str]:
                return self.edges_from_by_id(node_id)
        
        static_graph = StaticImportGraph(imports_from, imported_by, defines)
        self.register_layer("static_imports", static_graph)


# === COMPONENT REGISTRY ===

class ForgeComponentRegistry:
    """Registry for component types and templates."""
    
    def __init__(self):
        self._component_types: Dict[str, Type[ForgeComponent]] = {}
        self._entity_templates: Dict[str, Dict[str, Any]] = {}
    
    def register_component(self, name: str, component_type: Type[ForgeComponent]):
        """Register a component type."""
        self._component_types[name] = component_type
    
    def create_component(self, name: str, **kwargs) -> ForgeComponent:
        """Create a component by name."""
        if name not in self._component_types:
            raise ValueError(f"Unknown component type: {name}")
        return self._component_types[name](**kwargs)
    
    def register_template(self, template_name: str, template: Dict[str, Any]):
        """Register an entity template."""
        self._entity_templates[template_name] = template
    
    def create_entity_from_template(self, game: ForgeGame, template_name: str, entity_id: str, **kwargs) -> ForgeEntity:
        """Create an entity from a template."""
        if template_name not in self._entity_templates:
            raise ValueError(f"Unknown template: {template_name}")
        
        template = self._entity_templates[template_name]
        entity = ForgeEntity(
            id=entity_id,
            kind=template.get("kind", "unknown"),
            game=game
        )
        
        # Add components from template
        for comp_name, comp_config in template.get("components", {}).items():
            if comp_name in self._component_types:
                component = self.create_component(comp_name, **comp_config)
                entity.add_component(component, comp_name)
        
        # Add properties from template
        for prop_name, prop_value in template.get("properties", {}).items():
            entity.set_property(prop_name, prop_value)
        
        # Add tags from template
        for tag in template.get("tags", []):
            entity.add_tag(tag)
        
        return entity


# Global registry
_global_registry = ForgeComponentRegistry()

# Register built-in components
_global_registry.register_component("node", NodeComponent)
_global_registry.register_component("tier", TierComponent)
_global_registry.register_component("manifest", ManifestComponent)
_global_registry.register_component("contract", ContractComponent)
_global_registry.register_component("health", HealthComponent)
_global_registry.register_component("change", ChangeComponent)
_global_registry.register_component("annotation", AnnotationComponent)
_global_registry.register_component("pipeline", PipelineComponent)
_global_registry.register_component("error", ErrorComponent)

# Register built-in templates
_global_registry.register_template("forge_controller", {
    "kind": "controller",
    "components": {
        "node": {"node_kind": "controller", "tier": NodeTier.SURFACE},
        "tier": {"tier": NodeTier.SURFACE},
        "manifest": {"auto_sync": True},
        "contract": {"required_contracts": ["controller_interface"]},
        "health": {}
    },
    "properties": {},
    "tags": ["surface", "ui"]
})

_global_registry.register_template("forge_service", {
    "kind": "service",
    "components": {
        "node": {"node_kind": "service", "tier": NodeTier.WORKER},
        "tier": {"tier": NodeTier.WORKER},
        "manifest": {"auto_sync": True},
        "contract": {"required_contracts": ["service_interface"]},
        "health": {}
    },
    "properties": {},
    "tags": ["worker", "business"]
})

_global_registry.register_template("forge_module", {
    "kind": "module",
    "components": {
        "node": {"node_kind": "module", "tier": NodeTier.WORKER},
        "tier": {"tier": NodeTier.WORKER},
        "manifest": {"auto_sync": False},
        "health": {}
    },
    "properties": {},
    "tags": ["worker", "library"]
})


def register_extended_components(registry):
    """Register all extended components with the registry."""
    
    # Graph components
    registry.register_component("graph", GraphComponent)
    registry.register_component("manifest_graph", ManifestGraphComponent)
    registry.register_component("execution_graph", ExecutionGraphComponent)
    registry.register_component("workspace_graph", WorkspaceGraphComponent)
    
    # Glove components
    registry.register_component("glove", GloveComponent)
    registry.register_component("stack_profile", StackProfileComponent)
    registry.register_component("import_resolution", ImportResolutionComponent)
    
    # Stack-agnostic components
    registry.register_component("semantic_analysis", SemanticAnalysisComponent)
    registry.register_component("framework_detection", FrameworkDetectionComponent)
    registry.register_component("contract_validation", ContractValidationComponent)
    
    # Monitoring components
    registry.register_component("metrics", MetricsComponent)
    registry.register_component("trace", TraceComponent)
    registry.register_component("event", EventComponent)


def register_extended_systems(registry):
    """Register all extended systems with the registry."""
    
    registry.register_system("graphs", GraphSystem)
    registry.register_system("gloves", GloveSystem)
    registry.register_system("metrics", MetricsSystem)
    registry.register_system("events", EventSystem)


def create_extended_templates(registry):
    """Create extended entity templates."""
    
    # Graph entity template
    registry.register_template("graph_entity", {
        "kind": "graph",
        "components": {
            "graph": {},
            "manifest_graph": {"auto_load": True},
            "metrics": {},
            "event": {}
        },
        "properties": {},
        "tags": ["graph", "infrastructure"]
    })
    
    # Glove entity template
    registry.register_template("glove_entity", {
        "kind": "glove",
        "components": {
            "glove": {"auto_discover": True},
            "stack_profile": {},
            "import_resolution": {"strategy": "stack_agnostic"},
            "metrics": {},
            "trace": {"trace_enabled": True}
        },
        "properties": {},
        "tags": ["glove", "analysis"]
    })
    
    # Semantic analysis entity template
    registry.register_template("semantic_entity", {
        "kind": "semantic_analyzer",
        "components": {
            "semantic_analysis": {"analyzer_type": "hybrid"},
            "framework_detection": {},
            "contract_validation": {},
            "metrics": {}
        },
        "properties": {},
        "tags": ["semantic", "analysis"]
    })


def get_registry() -> ForgeComponentRegistry:
    """Get the global component registry."""
    return _global_registry


def create_project(project_path: Path, scope: ProjectScope = ProjectScope.PROJECT, **kwargs) -> ForgeProject:
    """Create a Forge project."""
    project_id = project_path.name
    return ForgeProject(
        id=project_id,
        scope=scope,
        name=project_id,
        root_path=project_path,
        **kwargs
    )


def create_entity_from_template(project: ForgeProject, template_name: str, entity_id: str, **kwargs) -> ForgeEntity:
    """Create an entity from a template."""
    return _global_registry.create_entity_from_template(project, template_name, entity_id, **kwargs)


# Usage Examples
def example_usage():
    """Example of Forge Project System usage."""
    
    # Create a project
    project = create_project(Path("/Users/sebastianpereira/Projects/forge"))
    
    # Create entities from templates
    controller = create_entity_from_template(project, "forge_controller", "app/user_controller")
    service = create_entity_from_template(project, "forge_service", "app/user_service")
    module = create_entity_from_template(project, "forge_module", "lib/auth")
    
    # Add entities to project
    project.add_entity(controller)
    project.add_entity(service)
    project.add_entity(module)
    
    # Add custom components
    controller["custom_property"] = "value"
    
    # Initialize and run project loop
    project.initialize()
    
    project.process_pending_events()
    
    # Get health status
    health = controller.get_component(HealthComponent)
    if health:
        print(f"Controller health: {health.get_health_summary()}")
    
    return project
