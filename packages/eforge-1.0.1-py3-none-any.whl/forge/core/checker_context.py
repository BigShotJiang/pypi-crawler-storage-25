from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from forge.core.manifest_document import ManifestDocument


@dataclass(kw_only=True)
class CheckerContext:
    project_path: Path
    env: dict[str, str]
    infra_refs: list[str]
    timeout_seconds: int = 10


def _load_dotenv(project_path: Path) -> dict[str, str]:
    dotenv_path = project_path / ".env"
    if not dotenv_path.is_file():
        return {}
    out: dict[str, str] = {}
    for raw in dotenv_path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        out[key.strip()] = value.strip()
    return out


def _infra_refs_from_raw(manifest: Mapping[str, Any]) -> list[str]:
    infra = manifest.get("infrastructure")
    if infra is None:
        return []
    if isinstance(infra, list):
        return [str(x).strip() for x in infra if str(x).strip()]
    if isinstance(infra, dict):
        refs = infra.get("refs")
        if isinstance(refs, list):
            return [str(x).strip() for x in refs if str(x).strip()]
        out: list[str] = []
        for value in infra.values():
            if isinstance(value, str) and value.strip():
                out.append(value.strip())
        return out
    if isinstance(infra, str) and infra.strip():
        return [infra.strip()]
    return []


def _infra_refs_from_manifest(manifest: Mapping[str, Any] | ManifestDocument) -> list[str]:
    if isinstance(manifest, ManifestDocument):
        refs: list[str] = []
        refs.extend(_infra_refs_from_raw(manifest.raw))
        for layer in manifest.layers:
            refs.extend(_infra_refs_from_raw(layer.raw))
        # Preserve first-seen order across top-level + layer slices.
        out: list[str] = []
        seen: set[str] = set()
        for ref in refs:
            if ref not in seen:
                seen.add(ref)
                out.append(ref)
        return out
    return _infra_refs_from_raw(manifest)


def build_checker_context(
    project_path: Path,
    manifest: Mapping[str, Any] | ManifestDocument,
) -> CheckerContext:
    root = project_path.expanduser().resolve()
    env = dict(_load_dotenv(root))
    env.update(os.environ)
    infra_refs = _infra_refs_from_manifest(manifest)
    return CheckerContext(project_path=root, env=env, infra_refs=infra_refs)
