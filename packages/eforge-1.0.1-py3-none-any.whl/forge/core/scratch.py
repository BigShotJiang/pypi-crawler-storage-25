from __future__ import annotations

from datetime import datetime
from pathlib import Path


class ScratchStore:
    """
    Per-project ephemeral working memory.
    Lifecycle: created at session start, cleared at handoff.
    NOT a permanent log - promote findings to annotations before clear.
    """

    def __init__(self, project_path: Path):
        self.path = project_path / ".forge" / "scratch.md"

    def initialize(self) -> None:
        """Call at session start. Clears previous session scratch."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            f"# Forge Scratch - {self.path.parent.parent.name}\n"
            f"# Initialized: {datetime.now().isoformat()}\n"
            "# This file is cleared on session handoff.\n"
            "# Promote findings to forge_annotate before handoff.\n\n",
            encoding="utf-8",
        )

    def append(self, entry: str) -> None:
        existing = self.path.read_text(encoding="utf-8") if self.path.exists() else ""
        self.path.write_text(existing + "\n" + entry, encoding="utf-8")

    def read(self) -> str | None:
        return self.path.read_text(encoding="utf-8") if self.path.exists() else None

    def clear(self) -> None:
        """Call at session handoff."""
        if self.path.exists():
            self.path.write_text("# cleared on handoff\n", encoding="utf-8")
