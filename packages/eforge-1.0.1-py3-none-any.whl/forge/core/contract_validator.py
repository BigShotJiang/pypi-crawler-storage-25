"""Contract validation engine for real semantic analysis capabilities.

Provides comprehensive contract validation, interface compatibility checking,
and semantic analysis to replace basic validation with proper Forge architecture.
"""

import ast
from pathlib import Path
from typing import Dict, List, Optional, Any, Set, Tuple
from dataclasses import dataclass
from collections import defaultdict
import logging

from forge.core.semantic_analyzer import SemanticAnalyzer, ImportDependency, ModuleExport
from forge.core.domain_integration import DomainIntegration, ContractViolation

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class InterfaceDefinition:
    """Represents an interface definition."""
    name: str
    methods: List[Dict[str, Any]]
    properties: List[Dict[str, Any]]
    inheritance: List[str]
    domain: str


@dataclass(frozen=True)
class ContractDefinition:
    """Represents a contract definition."""
    name: str
    interface_requirements: List[str]
    implementation_patterns: List[str]
    forbidden_patterns: List[str]
    domain: str
    validation_rules: List[Dict[str, Any]]


@dataclass(frozen=True)
class ValidationResult:
    """Represents a validation result."""
    is_valid: bool
    violations: List[ContractViolation]
    warnings: List[ContractViolation]
    compliance_score: float


class ContractValidator:
    """Provides real contract validation with semantic analysis."""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.semantic_analyzer = SemanticAnalyzer(project_root)
        self.domain_integration = DomainIntegration(project_root)
        self.interfaces: Dict[str, InterfaceDefinition] = {}
        self.contracts: Dict[str, ContractDefinition] = {}
        self._load_contract_definitions()
    
    def _load_contract_definitions(self):
        """Load contract and interface definitions from configuration."""
        # Load from .forge/contracts.yaml
        contracts_path = self.project_root / ".forge" / "contracts.yaml"
        if contracts_path.exists():
            self._load_contracts_from_file(contracts_path)
        
        # Load from glove configuration
        glove_contracts = self._load_contracts_from_glove()
        if glove_contracts:
            self.interfaces.update(glove_contracts['interfaces'])
            self.contracts.update(glove_contracts['contracts'])
        
        # Set up default contracts if none found
        if not self.contracts:
            self._setup_default_contracts()
    
    def _load_contracts_from_file(self, contracts_path: Path):
        """Load contracts from YAML file."""
        try:
            import yaml
            with open(contracts_path) as f:
                config = yaml.load(f, Loader=yaml.SafeLoader)
            
            # Load interfaces
            for name, interface_def in config.get('interfaces', {}).items():
                self.interfaces[name] = InterfaceDefinition(
                    name=name,
                    methods=interface_def.get('methods', []),
                    properties=interface_def.get('properties', []),
                    inheritance=interface_def.get('inheritance', []),
                    domain=interface_def.get('domain', 'unknown')
                )
            
            # Load contracts
            for name, contract_def in config.get('contracts', {}).items():
                self.contracts[name] = ContractDefinition(
                    name=name,
                    interface_requirements=contract_def.get('interface_requirements', []),
                    implementation_patterns=contract_def.get('implementation_patterns', []),
                    forbidden_patterns=contract_def.get('forbidden_patterns', []),
                    domain=contract_def.get('domain', 'unknown'),
                    validation_rules=contract_def.get('validation_rules', [])
                )
        except Exception as e:
            logger.warning(f"Failed to load contracts from file: {e}")
    
    def _load_contracts_from_glove(self) -> Optional[Dict[str, Any]]:
        """Load contracts from glove configuration."""
        glove_paths = [
            self.project_root / ".forge" / "glove.yaml",
            self.project_root / "glove.yaml"
        ]
        
        for glove_path in glove_paths:
            if glove_path.exists():
                try:
                    import yaml
                    with open(glove_path) as f:
                        glove_config = yaml.load(f, Loader=yaml.SafeLoader)
                    
                    return {
                        'interfaces': glove_config.get('interfaces', {}),
                        'contracts': glove_config.get('contracts', {})
                    }
                except Exception as e:
                    logger.warning(f"Failed to load glove contracts: {e}")
        
        return None
    
    def _setup_default_contracts(self):
        """Set up default contract definitions."""
        # Default interfaces
        default_interfaces = {
            'CommandInterface': InterfaceDefinition(
                name='CommandInterface',
                methods=[
                    {'name': 'execute', 'params': ['context'], 'returns': 'Result'},
                    {'name': 'validate', 'params': ['args'], 'returns': 'bool'}
                ],
                properties=[],
                inheritance=[],
                domain='commands'
            ),
            'ServiceInterface': InterfaceDefinition(
                name='ServiceInterface',
                methods=[
                    {'name': 'start', 'params': [], 'returns': 'None'},
                    {'name': 'stop', 'params': [], 'returns': 'None'},
                    {'name': 'process', 'params': ['data'], 'returns': 'Result'}
                ],
                properties=[],
                inheritance=[],
                domain='core'
            ),
            'ComponentInterface': InterfaceDefinition(
                name='ComponentInterface',
                methods=[
                    {'name': 'render', 'params': [], 'returns': 'JSX'},
                    {'name': 'mount', 'params': [], 'returns': 'None'},
                    {'name': 'unmount', 'params': [], 'returns': 'None'}
                ],
                properties=[
                    {'name': 'props', 'type': 'object'},
                    {'name': 'state', 'type': 'object'}
                ],
                inheritance=[],
                domain='ui'
            )
        }
        
        # Default contracts
        default_contracts = {
            'CommandContract': ContractDefinition(
                name='CommandContract',
                interface_requirements=['CommandInterface'],
                implementation_patterns=[
                    'class.*Command.*:',
                    'def execute.*:',
                    'def validate.*:'
                ],
                forbidden_patterns=[
                    'import.*react.*',
                    'import.*vue.*',
                    'import.*angular.*'
                ],
                domain='commands',
                validation_rules=[
                    {'type': 'method_exists', 'target': 'execute'},
                    {'type': 'method_exists', 'target': 'validate'},
                    {'type': 'no_ui_imports', 'target': 'all'}
                ]
            ),
            'ServiceContract': ContractDefinition(
                name='ServiceContract',
                interface_requirements=['ServiceInterface'],
                implementation_patterns=[
                    'class.*Service.*:',
                    'def start.*:',
                    'def stop.*:',
                    'def process.*:'
                ],
                forbidden_patterns=[
                    'from.*ui.*',
                    'from.*components.*'
                ],
                domain='core',
                validation_rules=[
                    {'type': 'method_exists', 'target': 'start'},
                    {'type': 'method_exists', 'target': 'stop'},
                    {'type': 'method_exists', 'target': 'process'},
                    {'type': 'no_ui_imports', 'target': 'all'}
                ]
            ),
            'ComponentContract': ContractDefinition(
                name='ComponentContract',
                interface_requirements=['ComponentInterface'],
                implementation_patterns=[
                    'function.*Component.*:',
                    'const.*Component.*=',
                    'class.*Component.*:'
                ],
                forbidden_patterns=[
                    'import.*commands.*',
                    'from.*commands.*'
                ],
                domain='ui',
                validation_rules=[
                    {'type': 'has_render_method', 'target': 'all'},
                    {'type': 'no_command_imports', 'target': 'all'}
                ]
            )
        }
        
        self.interfaces.update(default_interfaces)
        self.contracts.update(default_contracts)
    
    def validate_file(self, file_path: Path, content: str) -> ValidationResult:
        """Validate a file against all applicable contracts."""
        violations = []
        warnings = []
        
        try:
            # Parse AST
            tree = ast.parse(content)
        except SyntaxError as e:
            return ValidationResult(
                is_valid=False,
                violations=[ContractViolation(
                    violation_type='syntax_error',
                    source_file=file_path,
                    target_module='',
                    description=f'Syntax error: {e}',
                    severity='error',
                    suggested_fix='Fix syntax errors before validation'
                )],
                warnings=[],
                compliance_score=0.0
            )
        
        # Get domain for this file
        domain = self.domain_integration.get_domain_for_path(file_path)
        
        # Get applicable contracts for this domain
        applicable_contracts = [
            contract for contract in self.contracts.values()
            if contract.domain == domain or contract.domain == 'all'
        ]
        
        # Validate against each contract
        for contract in applicable_contracts:
            contract_result = self._validate_against_contract(tree, file_path, contract)
            violations.extend(contract_result.violations)
            warnings.extend(contract_result.warnings)
        
        # Validate interface compliance
        interface_result = self._validate_interface_compliance(tree, file_path)
        violations.extend(interface_result.violations)
        warnings.extend(interface_result.warnings)
        
        # Calculate compliance score
        total_issues = len(violations) + len(warnings)
        error_weight = len(violations) * 10
        warning_weight = len(warnings) * 3
        compliance_score = max(0.0, 1.0 - (error_weight + warning_weight) / max(len(applicable_contracts) * 10, 1))
        
        return ValidationResult(
            is_valid=len(violations) == 0,
            violations=violations,
            warnings=warnings,
            compliance_score=compliance_score
        )
    
    def _validate_against_contract(self, tree: ast.AST, file_path: Path, contract: ContractDefinition) -> ValidationResult:
        """Validate AST against a specific contract."""
        violations = []
        warnings = []
        
        # Check implementation patterns
        for pattern in contract.implementation_patterns:
            if not self._check_pattern_in_ast(tree, pattern):
                violations.append(ContractViolation(
                    violation_type='missing_pattern',
                    source_file=file_path,
                    target_module='',
                    description=f"Missing required pattern: {pattern}",
                    severity='error',
                    suggested_fix=f"Add pattern '{pattern}' to implementation"
                ))
        
        # Check forbidden patterns
        for pattern in contract.forbidden_patterns:
            if self._check_pattern_in_ast(tree, pattern):
                violations.append(ContractViolation(
                    violation_type='forbidden_pattern',
                    source_file=file_path,
                    target_module='',
                    description=f"Forbidden pattern found: {pattern}",
                    severity='error',
                    suggested_fix=f"Remove pattern '{pattern}' from implementation"
                ))
        
        # Validate specific rules
        for rule in contract.validation_rules:
            rule_result = self._validate_rule(tree, file_path, rule)
            violations.extend(rule_result.violations)
            warnings.extend(rule_result.warnings)
        
        return ValidationResult(
            is_valid=len(violations) == 0,
            violations=violations,
            warnings=warnings,
            compliance_score=1.0 if len(violations) == 0 else 0.0
        )
    
    def _validate_interface_compliance(self, tree: ast.AST, file_path: Path) -> ValidationResult:
        """Validate that exports comply with interface definitions."""
        violations = []
        warnings = []
        
        # Extract classes and functions from AST
        classes = [node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)]
        functions = [node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
        
        # Check each class against interfaces
        for class_node in classes:
            for interface in self.interfaces.values():
                if self._class_implements_interface(class_node, interface):
                    compliance_result = self._validate_class_interface_compliance(class_node, interface)
                    violations.extend(compliance_result.violations)
                    warnings.extend(compliance_result.warnings)
        
        return ValidationResult(
            is_valid=len(violations) == 0,
            violations=violations,
            warnings=warnings,
            compliance_score=1.0 if len(violations) == 0 else 0.0
        )
    
    def _check_pattern_in_ast(self, tree: ast.AST, pattern: str) -> bool:
        """Check if pattern exists in AST (simplified implementation)."""
        # This is a simplified pattern matching - in practice would use more sophisticated AST analysis
        import re
        
        # Convert AST back to source for pattern matching
        source = ast.unparse(tree) if hasattr(ast, 'unparse') else str(tree)
        return bool(re.search(pattern, source))
    
    def _validate_rule(self, tree: ast.AST, file_path: Path, rule: Dict[str, Any]) -> ValidationResult:
        """Validate a specific rule against AST."""
        violations = []
        warnings = []
        
        rule_type = rule.get('type')
        target = rule.get('target')
        
        if rule_type == 'method_exists':
            if not self._has_method(tree, target):
                violations.append(ContractViolation(
                    violation_type='missing_method',
                    source_file=file_path,
                    target_module='',
                    description=f"Missing required method: {target}",
                    severity='error',
                    suggested_fix=f"Add method '{target}' to class"
                ))
        
        elif rule_type == 'no_ui_imports':
            if self._has_ui_imports(tree):
                violations.append(ContractViolation(
                    violation_type='forbidden_import',
                    source_file=file_path,
                    target_module='',
                    description="UI imports not allowed in this domain",
                    severity='error',
                    suggested_fix="Remove UI imports and move to appropriate domain"
                ))
        
        elif rule_type == 'has_render_method':
            if not self._has_method(tree, 'render'):
                violations.append(ContractViolation(
                    violation_type='missing_method',
                    source_file=file_path,
                    target_module='',
                    description="Missing required render method",
                    severity='error',
                    suggested_fix="Add render method to component"
                ))
        
        return ValidationResult(
            is_valid=len(violations) == 0,
            violations=violations,
            warnings=warnings,
            compliance_score=1.0 if len(violations) == 0 else 0.0
        )
    
    def _class_implements_interface(self, class_node: ast.ClassDef, interface: InterfaceDefinition) -> bool:
        """Check if class implements an interface (simplified)."""
        # Simplified implementation - would check inheritance, method signatures, etc.
        class_name = class_node.name.lower()
        interface_name = interface.name.lower()
        
        # Check if class name suggests interface implementation
        return interface_name in class_name or any(
            base.id.lower() == interface_name 
            for base in class_node.bases 
            if isinstance(base, ast.Name)
        )
    
    def _validate_class_interface_compliance(self, class_node: ast.ClassDef, interface: InterfaceDefinition) -> ValidationResult:
        """Validate class compliance with interface."""
        violations = []
        warnings = []
        
        # Check required methods
        class_methods = {method.name for method in class_node.body if isinstance(method, ast.FunctionDef)}
        required_methods = {method['name'] for method in interface.methods}
        
        missing_methods = required_methods - class_methods
        for method in missing_methods:
            violations.append(ContractViolation(
                violation_type='missing_interface_method',
                source_file=Path(''),  # Would be set by caller
                target_module='',
                description=f"Missing interface method: {method}",
                severity='error',
                suggested_fix=f"Implement method '{method}' to comply with {interface.name}"
            ))
        
        return ValidationResult(
            is_valid=len(violations) == 0,
            violations=violations,
            warnings=warnings,
            compliance_score=1.0 if len(violations) == 0 else 0.0
        )
    
    def _has_method(self, tree: ast.AST, method_name: str) -> bool:
        """Check if AST contains a method with given name."""
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == method_name:
                return True
        return False
    
    def _has_ui_imports(self, tree: ast.AST) -> bool:
        """Check if AST contains UI imports."""
        ui_patterns = ['react', 'vue', 'angular', 'components/', 'ui/']
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if any(pattern in alias.name.lower() for pattern in ui_patterns):
                        return True
            elif isinstance(node, ast.ImportFrom):
                if node.module and any(pattern in node.module.lower() for pattern in ui_patterns):
                    return True
        
        return False
    
    def get_validation_summary(self) -> Dict[str, Any]:
        """Get comprehensive validation summary."""
        return {
            'interfaces': {
                name: {
                    'methods': interface.methods,
                    'properties': interface.properties,
                    'domain': interface.domain
                }
                for name, interface in self.interfaces.items()
            },
            'contracts': {
                name: {
                    'interface_requirements': contract.interface_requirements,
                    'implementation_patterns': contract.implementation_patterns,
                    'forbidden_patterns': contract.forbidden_patterns,
                    'domain': contract.domain,
                    'validation_rules': contract.validation_rules
                }
                for name, contract in self.contracts.items()
            },
            'total_interfaces': len(self.interfaces),
            'total_contracts': len(self.contracts),
            'domains': list(set(contract.domain for contract in self.contracts.values()))
        }
