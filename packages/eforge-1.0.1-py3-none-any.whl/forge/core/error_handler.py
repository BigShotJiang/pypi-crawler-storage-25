"""Error handling utilities for INTENT-BB399595 Error UX implementation."""

import sys
import traceback
from typing import Any
from .result import ForgeResult


class ForgeErrorHandler:
    """Centralized error handling for Forge CLI and MCP."""
    
    @staticmethod
    def handle_result(result: ForgeResult[Any], print_to_stderr: bool = True) -> int:
        """
        Handle a ForgeResult and return appropriate exit code.
        
        Args:
            result: The ForgeResult to handle
            print_to_stderr: Whether to print error messages to stderr
            
        Returns:
            Exit code (0 for success, 1 for error)
        """
        if result.ok:
            if result.value is not None:
                # Print successful output to stdout
                if isinstance(result.value, str):
                    print(result.value)
                else:
                    print(str(result.value))
            return 0
        
        # Handle error case
        if print_to_stderr:
            ForgeErrorHandler.print_error_to_stderr(result)
        
        return 1
    
    @staticmethod
    def print_error_to_stderr(result: ForgeResult[Any]) -> None:
        """Print error message with hint to stderr."""
        if result.ok:
            return
        
        # Print user-friendly error message
        error_msg = result.get_user_message()
        print(error_msg, file=sys.stderr)
        
        # Print hint if available
        if result.hint:
            print(f"Hint: {result.hint}", file=sys.stderr)
        
        # Print debug info if in debug mode
        if result.debug_info and result.is_debug_mode():
            print(f"Debug: {result.debug_info}", file=sys.stderr)
    
    @staticmethod
    def handle_exception(exc: Exception, error_code: str | None = None, context: str | None = None) -> ForgeResult[None]:
        """
        Convert an exception to a ForgeResult with appropriate error code.
        
        Args:
            exc: The exception to handle
            error_code: Optional error code to use
            context: Optional context description
            
        Returns:
            ForgeResult representing the error
        """
        # Generate debug info from traceback
        debug_info = traceback.format_exc() if ForgeErrorHandler._is_debug_mode() else None
        
        # Determine error code if not provided
        if not error_code:
            error_code = ForgeErrorHandler._get_error_code_for_exception(exc)
        
        # Build error message
        error_msg = str(exc)
        if context:
            error_msg = f"{context}: {error_msg}"
        
        return ForgeResult.failure(
            error=error_msg,
            error_code=error_code,
            debug_info=debug_info
        )
    
    @staticmethod
    def _is_debug_mode() -> bool:
        """Check if debug mode is enabled."""
        import os
        return os.getenv("FORGE_DEBUG", "false").lower() in ("true", "1", "yes")
    
    @staticmethod
    def _get_error_code_for_exception(exc: Exception) -> str:
        """Map common exceptions to error codes."""
        if isinstance(exc, FileNotFoundError):
            return "CORE-005"
        elif isinstance(exc, PermissionError):
            return "CORE-001"
        elif isinstance(exc, ValueError):
            return "CORE-002"
        elif isinstance(exc, KeyError):
            return "CORE-005"
        elif isinstance(exc, (ConnectionError, OSError)):
            return "REMOTE-001"
        else:
            return "CORE-001"
    
    @staticmethod
    def create_mcp_error_payload(error_code: str, message: str, hint: str | None = None, debug_info: str | None = None) -> dict:
        """
        Create MCP error payload with hint field.
        
        Args:
            error_code: The error code
            message: Error message
            hint: Optional hint
            debug_info: Optional debug info
            
        Returns:
            MCP-compatible error payload
        """
        payload = {
            "code": error_code,
            "domain": error_code.split("-")[0] if "-" in error_code else "ERR",
            "message": message,
        }
        
        if hint:
            payload["hint"] = hint
        
        if debug_info and ForgeErrorHandler._is_debug_mode():
            payload["debug"] = debug_info
        
        return payload


def handle_cli_result(result: ForgeResult[Any]) -> int:
    """Convenience function for CLI commands to handle results."""
    return ForgeErrorHandler.handle_result(result)


def handle_cli_error(exc: Exception, error_code: str | None = None, context: str | None = None) -> ForgeResult[None]:
    """Convenience function for CLI commands to handle exceptions."""
    return ForgeErrorHandler.handle_exception(exc, error_code, context)
