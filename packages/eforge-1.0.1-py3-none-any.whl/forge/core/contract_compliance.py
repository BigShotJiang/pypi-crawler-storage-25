"""
Contract Compliance Scoring System

Automated scoring system for contract adherence and quality.
Provides:
- Contract compliance scoring (0-100)
- Quality metrics and analysis
- Improvement recommendations
- Historical compliance tracking
- Automated violation detection
"""

import json
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple
from collections import defaultdict

from forge.core.contract_graph import ContractEdge, ContractGraph, EdgeStatus
from forge.core.manifest import ManifestParser


class ComplianceCategory(Enum):
    """Categories of compliance checks."""
    STRUCTURE = "structure"
    NAMING = "naming"
    DEPENDENCIES = "dependencies"
    DOCUMENTATION = "documentation"
    IMPLEMENTATION = "implementation"
    TESTING = "testing"
    SECURITY = "security"


class ComplianceLevel(Enum):
    """Compliance levels."""
    EXCELLENT = "excellent"      # 90-100
    GOOD = "good"               # 80-89
    ACCEPTABLE = "acceptable"   # 70-79
    NEEDS_IMPROVEMENT = "needs_improvement"  # 60-69
    POOR = "poor"              # < 60


@dataclass
class ComplianceViolation:
    """Individual compliance violation."""
    category: ComplianceCategory
    severity: str  # "critical", "high", "medium", "low"
    description: str
    contract_id: str
    node_id: str
    suggestion: str
    impact_score: float  # 0-10


@dataclass
class CategoryScore:
    """Score for a specific compliance category."""
    category: ComplianceCategory
    score: float  # 0-100
    weight: float  # Importance weight
    violations: List[ComplianceViolation]
    checks_passed: int
    total_checks: int


@dataclass
class ComplianceReport:
    """Comprehensive compliance report."""
    project_id: str
    project_path: str
    overall_score: float  # 0-100
    compliance_level: ComplianceLevel
    category_scores: List[CategoryScore]
    total_violations: int
    critical_violations: int
    recommendations: List[str]
    timestamp: str
    scan_duration_ms: float


class ContractComplianceScorer:
    """Automated contract compliance scoring system."""
    
    def __init__(self, project_path: Path):
        self.project_path = project_path
        self.project_id = project_path.name
        
        # Compliance weights (must sum to 1.0)
        self.category_weights = {
            ComplianceCategory.STRUCTURE: 0.25,
            ComplianceCategory.NAMING: 0.15,
            ComplianceCategory.DEPENDENCIES: 0.20,
            ComplianceCategory.DOCUMENTATION: 0.15,
            ComplianceCategory.IMPLEMENTATION: 0.15,
            ComplianceCategory.TESTING: 0.10
        }
        
        # Severity impact scores
        self.severity_impact = {
            "critical": 10.0,
            "high": 7.5,
            "medium": 5.0,
            "low": 2.5
        }
        
        # Naming conventions
        self.naming_patterns = {
            "screen": r"^[a-z][a-z0-9_]*_screen$",
            "controller": r"^[a-z][a-z0-9_]*_controller$",
            "service": r"^[a-z][a-z0-9_]*_service$",
            "module": r"^[a-z][a-z0-9_]*$",
            "domain": r"^[A-Z][A-Z0-9_]*$"
        }
        
        # Required documentation
        self.required_docs = {
            "screen": ["description", "props", "state", "events"],
            "controller": ["description", "actions", "state"],
            "service": ["description", "methods", "dependencies"],
            "module": ["description", "exports", "dependencies"]
        }
    
    def score_compliance(self, contract_graph: ContractGraph = None) -> ComplianceReport:
        """Score contract compliance for the project."""
        start_time = time.time()
        
        # Load contract graph if not provided
        if contract_graph is None:
            contract_graph = self._load_contract_graph()
        
        # Analyze each compliance category
        category_scores = []
        all_violations = []
        
        for category in ComplianceCategory:
            score, violations = self._score_category(category, contract_graph)
            category_scores.append(CategoryScore(
                category=category,
                score=score,
                weight=self.category_weights[category],
                violations=violations,
                checks_passed=self._count_passed_checks(category, violations),
                total_checks=self._get_total_checks(category)
            ))
            all_violations.extend(violations)
        
        # Calculate overall score
        overall_score = self._calculate_overall_score(category_scores)
        compliance_level = self._determine_compliance_level(overall_score)
        
        # Generate recommendations
        recommendations = self._generate_recommendations(category_scores, all_violations)
        
        # Count critical violations
        critical_violations = len([v for v in all_violations if v.severity == "critical"])
        
        scan_duration = (time.time() - start_time) * 1000
        
        return ComplianceReport(
            project_id=self.project_id,
            project_path=str(self.project_path),
            overall_score=overall_score,
            compliance_level=compliance_level,
            category_scores=category_scores,
            total_violations=len(all_violations),
            critical_violations=critical_violations,
            recommendations=recommendations,
            timestamp=datetime.now(timezone.utc).isoformat(),
            scan_duration_ms=scan_duration
        )
    
    def _load_contract_graph(self) -> ContractGraph:
        """Load contract graph for the project."""
        # This would integrate with the actual contract graph loading
        # For now, create a mock contract graph
        return ContractGraph()
    
    def _score_category(self, category: ComplianceCategory, contract_graph: ContractGraph) -> Tuple[float, List[ComplianceViolation]]:
        """Score a specific compliance category."""
        violations = []
        
        if category == ComplianceCategory.STRUCTURE:
            violations.extend(self._check_structure_compliance(contract_graph))
        elif category == ComplianceCategory.NAMING:
            violations.extend(self._check_naming_compliance(contract_graph))
        elif category == ComplianceCategory.DEPENDENCIES:
            violations.extend(self._check_dependency_compliance(contract_graph))
        elif category == ComplianceCategory.DOCUMENTATION:
            violations.extend(self._check_documentation_compliance(contract_graph))
        elif category == ComplianceCategory.IMPLEMENTATION:
            violations.extend(self._check_implementation_compliance(contract_graph))
        elif category == ComplianceCategory.TESTING:
            violations.extend(self._check_testing_compliance(contract_graph))
        
        # Calculate score based on violations
        total_impact = sum(v.impact_score for v in violations)
        max_impact = 100.0  # Maximum possible impact
        
        score = max(0.0, max_impact - total_impact)
        
        return score, violations
    
    def _check_structure_compliance(self, contract_graph: ContractGraph) -> List[ComplianceViolation]:
        """Check contract structure compliance."""
        violations = []
        
        # Check for circular dependencies
        circular_deps = self._detect_circular_dependencies(contract_graph)
        for cycle in circular_deps:
            violations.append(ComplianceViolation(
                category=ComplianceCategory.STRUCTURE,
                severity="critical",
                description=f"Circular dependency detected: {' -> '.join(cycle)}",
                contract_id="structure",
                node_id=cycle[0] if cycle else "",
                suggestion="Break circular dependency by refactoring or introducing abstraction",
                impact_score=8.0
            ))
        
        # Check for orphaned contracts
        orphaned = self._find_orphaned_contracts(contract_graph)
        for contract_id in orphaned:
            violations.append(ComplianceViolation(
                category=ComplianceCategory.STRUCTURE,
                severity="medium",
                description=f"Orphaned contract: {contract_id}",
                contract_id=contract_id,
                node_id=contract_id,
                suggestion="Connect contract to dependency graph or remove if unused",
                impact_score=3.0
            ))
        
        # Check for missing interface definitions
        missing_interfaces = self._find_missing_interfaces(contract_graph)
        for interface in missing_interfaces:
            violations.append(ComplianceViolation(
                category=ComplianceCategory.STRUCTURE,
                severity="high",
                description=f"Missing interface definition for: {interface}",
                contract_id="structure",
                node_id=interface,
                suggestion="Define proper interface contract",
                impact_score=6.0
            ))
        
        return violations
    
    def _check_naming_compliance(self, contract_graph: ContractGraph) -> List[ComplianceViolation]:
        """Check naming convention compliance."""
        violations = []
        
        # This would check actual contract names against patterns
        # For now, simulate some naming violations
        
        violations.append(ComplianceViolation(
            category=ComplianceCategory.NAMING,
            severity="medium",
            description="Inconsistent naming convention detected",
            contract_id="naming",
            node_id="example_node",
            suggestion="Follow established naming patterns: screens end with _screen, controllers with _controller",
            impact_score=4.0
        ))
        
        return violations
    
    def _check_dependency_compliance(self, contract_graph: ContractGraph) -> List[ComplianceViolation]:
        """Check dependency compliance."""
        violations = []
        
        # Check for broken dependencies
        broken_edges = contract_graph.broken_edges()
        for edge in broken_edges:
            violations.append(ComplianceViolation(
                category=ComplianceCategory.DEPENDENCIES,
                severity="critical",
                description=f"Broken dependency: {edge.source_project} -> {edge.target_project}",
                contract_id=edge.field_name,
                node_id=edge.source_project,
                suggestion="Fix broken dependency or update contract reference",
                impact_score=9.0
            ))
        
        # Check for missing dependencies
        missing_deps = self._find_missing_dependencies(contract_graph)
        for dep in missing_deps:
            violations.append(ComplianceViolation(
                category=ComplianceCategory.DEPENDENCIES,
                severity="high",
                description=f"Missing dependency: {dep}",
                contract_id="dependencies",
                node_id=dep,
                suggestion="Add missing dependency to contract",
                impact_score=6.0
            ))
        
        return violations
    
    def _check_documentation_compliance(self, contract_graph: ContractGraph) -> List[ComplianceViolation]:
        """Check documentation compliance."""
        violations = []
        
        # Check for missing documentation
        missing_docs = self._find_missing_documentation(contract_graph)
        for doc_info in missing_docs:
            violations.append(ComplianceViolation(
                category=ComplianceCategory.DOCUMENTATION,
                severity="medium",
                description=f"Missing documentation: {doc_info['type']} for {doc_info['node']}",
                contract_id="documentation",
                node_id=doc_info['node'],
                suggestion=f"Add {doc_info['type']} documentation",
                impact_score=3.0
            ))
        
        # Check for outdated documentation
        outdated_docs = self._find_outdated_documentation(contract_graph)
        for doc in outdated_docs:
            violations.append(ComplianceViolation(
                category=ComplianceCategory.DOCUMENTATION,
                severity="low",
                description=f"Outdated documentation: {doc}",
                contract_id="documentation",
                node_id=doc,
                suggestion="Update documentation to match current implementation",
                impact_score=2.0
            ))
        
        return violations
    
    def _check_implementation_compliance(self, contract_graph: ContractGraph) -> List[ComplianceViolation]:
        """Check implementation compliance."""
        violations = []
        
        # Check for unimplemented contracts
        unimplemented = self._find_unimplemented_contracts(contract_graph)
        for contract in unimplemented:
            violations.append(ComplianceViolation(
                category=ComplianceCategory.IMPLEMENTATION,
                severity="high",
                description=f"Unimplemented contract: {contract}",
                contract_id=contract,
                node_id=contract,
                suggestion="Implement contract or mark as planned",
                impact_score=7.0
            ))
        
        # Check for implementation mismatches
        mismatches = self._find_implementation_mismatches(contract_graph)
        for mismatch in mismatches:
            violations.append(ComplianceViolation(
                category=ComplianceCategory.IMPLEMENTATION,
                severity="medium",
                description=f"Implementation mismatch: {mismatch}",
                contract_id="implementation",
                node_id=mismatch,
                suggestion="Align implementation with contract definition",
                impact_score=5.0
            ))
        
        return violations
    
    def _check_testing_compliance(self, contract_graph: ContractGraph) -> List[ComplianceViolation]:
        """Check testing compliance."""
        violations = []
        
        # Check for missing tests
        missing_tests = self._find_missing_tests(contract_graph)
        for test_info in missing_tests:
            violations.append(ComplianceViolation(
                category=ComplianceCategory.TESTING,
                severity="medium",
                description=f"Missing test coverage: {test_info['type']} for {test_info['node']}",
                contract_id="testing",
                node_id=test_info['node'],
                suggestion=f"Add {test_info['type']} tests",
                impact_score=4.0
            ))
        
        # Check for failing tests
        failing_tests = self._find_failing_tests(contract_graph)
        for test in failing_tests:
            violations.append(ComplianceViolation(
                category=ComplianceCategory.TESTING,
                severity="high",
                description=f"Failing test: {test}",
                contract_id="testing",
                node_id=test,
                suggestion="Fix failing test implementation",
                impact_score=6.0
            ))
        
        return violations
    
    def _detect_circular_dependencies(self, contract_graph: ContractGraph) -> List[List[str]]:
        """Detect circular dependencies in contract graph."""
        # Simplified circular dependency detection
        # In a real implementation, this would use proper graph algorithms
        return [["service_a", "service_b", "service_a"]]  # Example cycle
    
    def _find_orphaned_contracts(self, contract_graph: ContractGraph) -> List[str]:
        """Find orphaned contracts with no connections."""
        # Simplified orphan detection
        return ["orphaned_contract"]  # Example orphan
    
    def _find_missing_interfaces(self, contract_graph: ContractGraph) -> List[str]:
        """Find missing interface definitions."""
        return ["missing_interface"]  # Example missing interface
    
    def _find_missing_dependencies(self, contract_graph: ContractGraph) -> List[str]:
        """Find missing dependencies."""
        return ["missing_dependency"]  # Example missing dependency
    
    def _find_missing_documentation(self, contract_graph: ContractGraph) -> List[Dict[str, str]]:
        """Find missing documentation."""
        return [
            {"type": "description", "node": "example_node"},
            {"type": "api_docs", "node": "example_service"}
        ]
    
    def _find_outdated_documentation(self, contract_graph: ContractGraph) -> List[str]:
        """Find outdated documentation."""
        return ["outdated_docs"]  # Example outdated docs
    
    def _find_unimplemented_contracts(self, contract_graph: ContractGraph) -> List[str]:
        """Find unimplemented contracts."""
        return ["unimplemented_contract"]  # Example unimplemented
    
    def _find_implementation_mismatches(self, contract_graph: ContractGraph) -> List[str]:
        """Find implementation mismatches."""
        return ["mismatched_implementation"]  # Example mismatch
    
    def _find_missing_tests(self, contract_graph: ContractGraph) -> List[Dict[str, str]]:
        """Find missing tests."""
        return [
            {"type": "unit", "node": "example_service"},
            {"type": "integration", "node": "example_controller"}
        ]
    
    def _find_failing_tests(self, contract_graph: ContractGraph) -> List[str]:
        """Find failing tests."""
        return ["failing_test"]  # Example failing test
    
    def _count_passed_checks(self, category: ComplianceCategory, violations: List[ComplianceViolation]) -> int:
        """Count passed checks for a category."""
        total_checks = self._get_total_checks(category)
        critical_violations = len([v for v in violations if v.severity == "critical"])
        return max(0, total_checks - critical_violations)
    
    def _get_total_checks(self, category: ComplianceCategory) -> int:
        """Get total number of checks for a category."""
        check_counts = {
            ComplianceCategory.STRUCTURE: 10,
            ComplianceCategory.NAMING: 8,
            ComplianceCategory.DEPENDENCIES: 12,
            ComplianceCategory.DOCUMENTATION: 8,
            ComplianceCategory.IMPLEMENTATION: 10,
            ComplianceCategory.TESTING: 6
        }
        return check_counts.get(category, 5)
    
    def _calculate_overall_score(self, category_scores: List[CategoryScore]) -> float:
        """Calculate overall compliance score."""
        weighted_score = 0.0
        total_weight = 0.0
        
        for cat_score in category_scores:
            weighted_score += cat_score.score * cat_score.weight
            total_weight += cat_score.weight
        
        return weighted_score / total_weight if total_weight > 0 else 0.0
    
    def _determine_compliance_level(self, score: float) -> ComplianceLevel:
        """Determine compliance level from score."""
        if score >= 90:
            return ComplianceLevel.EXCELLENT
        elif score >= 80:
            return ComplianceLevel.GOOD
        elif score >= 70:
            return ComplianceLevel.ACCEPTABLE
        elif score >= 60:
            return ComplianceLevel.NEEDS_IMPROVEMENT
        else:
            return ComplianceLevel.POOR
    
    def _generate_recommendations(self, category_scores: List[CategoryScore], all_violations: List[ComplianceViolation]) -> List[str]:
        """Generate improvement recommendations."""
        recommendations = []
        
        # Prioritize critical violations
        critical_violations = [v for v in all_violations if v.severity == "critical"]
        if critical_violations:
            recommendations.append("Address critical violations immediately to ensure system stability")
        
        # Category-specific recommendations
        for cat_score in category_scores:
            if cat_score.score < 70:
                if cat_score.category == ComplianceCategory.STRUCTURE:
                    recommendations.append("Review and refactor contract structure to eliminate circular dependencies")
                elif cat_score.category == ComplianceCategory.DEPENDENCIES:
                    recommendations.append("Fix broken dependencies and ensure proper dependency management")
                elif cat_score.category == ComplianceCategory.DOCUMENTATION:
                    recommendations.append("Complete missing documentation to improve maintainability")
                elif cat_score.category == ComplianceCategory.IMPLEMENTATION:
                    recommendations.append("Implement all contract definitions to ensure consistency")
                elif cat_score.category == ComplianceCategory.TESTING:
                    recommendations.append("Improve test coverage to ensure reliability")
                elif cat_score.category == ComplianceCategory.NAMING:
                    recommendations.append("Standardize naming conventions across all contracts")
        
        # General recommendations
        if len(all_violations) > 20:
            recommendations.append("Consider a comprehensive refactoring to address multiple issues")
        
        # Remove duplicates and limit
        unique_recommendations = list(set(recommendations))
        return unique_recommendations[:10]
    
    def save_report(self, report: ComplianceReport, filepath: Path = None) -> Path:
        """Save compliance report to file."""
        if filepath is None:
            filepath = self.project_path / ".forge" / "compliance_report.json"
        
        # Convert to JSON-serializable format
        report_dict = {
            "project_id": report.project_id,
            "project_path": report.project_path,
            "overall_score": report.overall_score,
            "compliance_level": report.compliance_level.value,
            "category_scores": [
                {
                    "category": cat_score.category.value,
                    "score": cat_score.score,
                    "weight": cat_score.weight,
                    "violations": [
                        {
                            "category": v.category.value,
                            "severity": v.severity,
                            "description": v.description,
                            "contract_id": v.contract_id,
                            "node_id": v.node_id,
                            "suggestion": v.suggestion,
                            "impact_score": v.impact_score
                        }
                        for v in cat_score.violations
                    ],
                    "checks_passed": cat_score.checks_passed,
                    "total_checks": cat_score.total_checks
                }
                for cat_score in report.category_scores
            ],
            "total_violations": report.total_violations,
            "critical_violations": report.critical_violations,
            "recommendations": report.recommendations,
            "timestamp": report.timestamp,
            "scan_duration_ms": report.scan_duration_ms
        }
        
        filepath.parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, 'w') as f:
            json.dump(report_dict, f, indent=2)
        
        return filepath
    
    def get_compliance_trend(self, days: int = 30) -> Dict[str, Any]:
        """Get compliance trend over time."""
        # This would load historical reports and calculate trends
        # For now, return mock trend data
        return {
            "trend_days": days,
            "current_score": 75.0,
            "previous_score": 72.0,
            "trend_direction": "improving",
            "trend_percentage": 4.2,
            "historical_scores": [70, 72, 71, 73, 75]
        }


# Convenience functions
def score_project_compliance(project_path: Path) -> ComplianceReport:
    """Score compliance for a project."""
    scorer = ContractComplianceScorer(project_path)
    return scorer.score_compliance()


def get_compliance_dashboard(project_path: Path) -> Dict[str, Any]:
    """Get compliance dashboard data."""
    scorer = ContractComplianceScorer(project_path)
    report = scorer.score_compliance()
    trend = scorer.get_compliance_trend()
    
    return {
        "current_report": asdict(report),
        "trend": trend,
        "summary": {
            "overall_score": report.overall_score,
            "compliance_level": report.compliance_level.value,
            "total_violations": report.total_violations,
            "critical_violations": report.critical_violations,
            "recommendations_count": len(report.recommendations)
        }
    }
