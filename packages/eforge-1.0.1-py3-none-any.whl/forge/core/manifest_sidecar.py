from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


class ValidationError(ValueError):
    """Sidecar validation failure."""


class SidecarLoader:
    KNOWN_SIDECARS = {
        "operations": "manifest.operations.yaml",
    }

    @staticmethod
    def sidecar_path(manifest_path: Path, kind: str) -> Path:
        """Returns the expected sidecar path for a given manifest and kind."""
        k = str(kind or "").strip().lower()
        name = SidecarLoader.KNOWN_SIDECARS.get(k)
        if not name:
            raise ValueError(f"unknown sidecar kind: {kind!r}")
        mp = Path(manifest_path).expanduser().resolve()
        return mp.with_name(name)

    @staticmethod
    def load(manifest_path: Path, kind: str) -> dict[str, Any] | None:
        """
        Loads and validates a sidecar file if it exists.
        Returns None if the sidecar does not exist (not an error).
        Raises ValidationError if the file exists but is invalid.
        Uses operations.schema.yaml for validation when kind='operations'.
        """
        path = SidecarLoader.sidecar_path(manifest_path, kind)
        if not path.is_file():
            return None
        try:
            raw = yaml.safe_load(path.read_text(encoding="utf-8"))
        except yaml.YAMLError as exc:
            raise ValidationError(f"invalid YAML in {path}: {exc}") from exc
        if raw is None:
            raw = {}
        if not isinstance(raw, dict):
            raise ValidationError("sidecar root must be a mapping")
        SidecarLoader._validate(kind, raw)
        return raw

    @staticmethod
    def write(manifest_path: Path, kind: str, data: dict[str, Any]) -> None:
        """
        Writes a sidecar file. Creates it if it doesn't exist.
        Validates data against schema before writing.
        Never writes invalid data.
        """
        if not isinstance(data, dict):
            raise ValidationError("sidecar data must be a mapping")
        SidecarLoader._validate(kind, data)
        path = SidecarLoader.sidecar_path(manifest_path, kind)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")

    @staticmethod
    def _schema_path(kind: str) -> Path:
        if kind != "operations":
            raise ValueError(f"unknown sidecar kind: {kind!r}")
        return Path(__file__).resolve().parents[1] / "schemas" / "operations.schema.yaml"

    @staticmethod
    def _load_schema(kind: str) -> dict[str, Any]:
        schema_path = SidecarLoader._schema_path(kind)
        if not schema_path.is_file():
            raise ValidationError(f"sidecar schema not found: {schema_path}")
        raw = yaml.safe_load(schema_path.read_text(encoding="utf-8")) or {}
        if not isinstance(raw, dict):
            raise ValidationError(f"invalid sidecar schema at {schema_path}")
        return raw

    @staticmethod
    def _validate(kind: str, data: dict[str, Any]) -> None:
        if kind not in SidecarLoader.KNOWN_SIDECARS:
            raise ValueError(f"unknown sidecar kind: {kind!r}")
        if kind == "operations":
            schema = SidecarLoader._load_schema(kind)
            SidecarLoader._validate_operations(schema, data)

    @staticmethod
    def _require_fields(ctx: str, obj: dict[str, Any], required: list[str]) -> None:
        for field in required:
            if field not in obj:
                raise ValidationError(f"{ctx}: missing required field '{field}'")

    @staticmethod
    def _reject_unknown_fields(ctx: str, obj: dict[str, Any], allowed: set[str]) -> None:
        for field in obj:
            if field not in allowed:
                raise ValidationError(f"{ctx}: unknown field '{field}'")

    @staticmethod
    def _validate_operations(schema: dict[str, Any], data: dict[str, Any]) -> None:
        allowed_root = set(str(x) for x in (schema.get("allowed_fields") or []))
        required_root = [str(x) for x in (schema.get("required_fields") or [])]
        SidecarLoader._require_fields("operations", data, required_root)
        SidecarLoader._reject_unknown_fields("operations", data, allowed_root)

        ops = data.get("operations")
        if not isinstance(ops, list):
            raise ValidationError("operations: 'operations' must be a list")

        op_schema = schema.get("operations_entry") if isinstance(schema.get("operations_entry"), dict) else {}
        input_schema = schema.get("input_entry") if isinstance(schema.get("input_entry"), dict) else {}
        exec_schema = schema.get("executor_entry") if isinstance(schema.get("executor_entry"), dict) else {}
        seen_ids: set[str] = set()

        for idx, row in enumerate(ops):
            ctx = f"operations[{idx}]"
            if not isinstance(row, dict):
                raise ValidationError(f"{ctx}: entry must be a mapping")
            SidecarLoader._require_fields(ctx, row, [str(x) for x in (op_schema.get("required_fields") or [])])
            SidecarLoader._reject_unknown_fields(ctx, row, set(str(x) for x in (op_schema.get("allowed_fields") or [])))

            op_id = str(row.get("id") or "").strip()
            if not op_id:
                raise ValidationError(f"{ctx}: id must be a non-empty string")
            if op_id in seen_ids:
                raise ValidationError(f"{ctx}: duplicate id '{op_id}'")
            seen_ids.add(op_id)

            desc = row.get("description")
            if not isinstance(desc, str) or not desc.strip():
                raise ValidationError(f"{ctx}: description must be a non-empty string")

            perm = str(row.get("permissions") or "").strip()
            if perm not in set(str(x) for x in (op_schema.get("permissions_enum") or [])):
                raise ValidationError(f"{ctx}: invalid permissions '{perm}'")

            inputs = row.get("inputs")
            if inputs is not None:
                if not isinstance(inputs, dict):
                    raise ValidationError(f"{ctx}: inputs must be a mapping")
                for field_name, spec in inputs.items():
                    in_ctx = f"{ctx}.inputs.{field_name}"
                    if not isinstance(spec, dict):
                        raise ValidationError(f"{in_ctx}: input spec must be a mapping")
                    SidecarLoader._require_fields(in_ctx, spec, [str(x) for x in (input_schema.get("required_fields") or [])])
                    SidecarLoader._reject_unknown_fields(in_ctx, spec, set(str(x) for x in (input_schema.get("allowed_fields") or [])))
                    typ = str(spec.get("type") or "").strip()
                    if typ not in set(str(x) for x in (input_schema.get("type_enum") or [])):
                        raise ValidationError(f"{in_ctx}: invalid type '{typ}'")
                    if not isinstance(spec.get("required"), bool):
                        raise ValidationError(f"{in_ctx}: required must be boolean")
                    if not isinstance(spec.get("description"), str):
                        raise ValidationError(f"{in_ctx}: description must be string")
                    if typ == "enum":
                        values = spec.get("values")
                        if not isinstance(values, list) or not values:
                            raise ValidationError(f"{in_ctx}: enum input requires non-empty values list")

            executor = row.get("executor")
            if not isinstance(executor, dict):
                raise ValidationError(f"{ctx}: executor must be a mapping")
            SidecarLoader._require_fields(f"{ctx}.executor", executor, [str(x) for x in (exec_schema.get("required_fields") or [])])
            SidecarLoader._reject_unknown_fields(f"{ctx}.executor", executor, set(str(x) for x in (exec_schema.get("allowed_fields") or [])))
            kind = str(executor.get("kind") or "").strip()
            if kind not in set(str(x) for x in (exec_schema.get("kind_enum") or [])):
                raise ValidationError(f"{ctx}.executor: invalid kind '{kind}'")
            if kind == "cli":
                cmd = executor.get("command")
                if not isinstance(cmd, str) or not cmd.strip():
                    raise ValidationError(f"{ctx}.executor: cli executor requires non-empty command")
            if kind == "mcp":
                tool = executor.get("tool")
                if not isinstance(tool, str) or not tool.strip():
                    raise ValidationError(f"{ctx}.executor: mcp executor requires non-empty tool")
            args = executor.get("args")
            if args is not None and not isinstance(args, dict):
                raise ValidationError(f"{ctx}.executor: args must be a mapping when provided")
