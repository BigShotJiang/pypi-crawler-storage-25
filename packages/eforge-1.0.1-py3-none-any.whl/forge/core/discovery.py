import logging
from pathlib import Path

from forge.core.manifest_path import resolve_manifest_path
from forge.core.project import BaseProject, ProjectFactory


logger = logging.getLogger(__name__)

FORGE_MARKERS = [
    "docs/CURSOR_CONTEXT.md",
    "docs/ARCHITECTURE.md",
    "docs/MAP.md",
    "docs/FORGE_SPEC.md",
]
FORGE_EXCLUDE = {".forge", ".secrets", "node_modules", ".git"}


def _is_forge_project(path: Path) -> bool:
    """Three-tier detection — no project left behind."""
    # Tier 1: forge standard (.forge/manifest.yaml)
    if (path / ".forge" / "manifest.yaml").exists():
        return True
    # Tier 2: legacy root manifest (warned by resolver)
    if (path / "manifest.yaml").exists():
        return True
    # Tier 3: denv legacy (docs/ manifest)
    if (path / "docs" / "manifest.yaml").exists():
        return True
    # Tier 4: Flutter/denv-style (doc markers + pubspec + lib/)
    has_marker = any((path / m).exists() for m in FORGE_MARKERS)
    if has_marker and (path / "pubspec.yaml").exists() and (path / "lib").is_dir():
        return True
    return False


def _get_manifest_path(path: Path) -> Path | None:
    """Resolve project manifest path with .forge priority and legacy fallback."""
    return resolve_manifest_path(path)


def _stub_project(path: Path, warning: str) -> BaseProject:
    """Minimal UnknownProject for projects without parseable manifest."""
    from forge.types.unknown import UnknownProject

    return UnknownProject(
        name=path.name,
        type="unknown",
        version="unknown",
        path=path,
        repo=None,
        branch=None,
        description="",
        dashboard_checks=[],
        phases={},
        notes="",
        warnings=[warning],
        domain="",
        app_config_meta={},
        dependencies={},
    )


def _projects_from_workspace(ws_entries: list[dict]) -> list[BaseProject]:
    """Build BaseProject list from workspace.yaml entries (workspace-first path)."""
    projects: list[BaseProject] = []
    for entry in ws_entries:
        raw_path = entry.get("path") or ""
        path = Path(str(raw_path)).expanduser().resolve()
        if not path.is_dir():
            logger.debug("workspace entry path missing or not a dir: %s", raw_path)
            continue
        manifest_path = _get_manifest_path(path)
        if manifest_path:
            result = ProjectFactory.from_manifest(manifest_path)
            if result.ok and result.value is not None:
                projects.append(result.value)
            else:
                projects.append(_stub_project(path, result.error or "Parse failed"))
        else:
            projects.append(
                _stub_project(path, "No manifest.yaml — run: forge manifest --init")
            )
    projects.sort(key=lambda p: p.name.lower())
    return projects


def discover_projects(root: Path) -> list[BaseProject]:
    # Try workspace.yaml first — registered projects take priority over filesystem walk.
    try:
        root_resolved = root.expanduser().resolve()
    except Exception:
        root_resolved = root
    if root_resolved == get_projects_root().expanduser().resolve():
        try:
            from forge.core.workspace import list_projects as _list_ws_projects

            ws_entries = _list_ws_projects()
            if ws_entries:
                return _projects_from_workspace(ws_entries)
        except Exception:
            pass
    # Fallback: filesystem walk of root directory.
    projects: list[BaseProject] = []
    if not root.exists() or not root.is_dir():
        return []
    for item in sorted(list(root.iterdir())):
        if not item.is_dir():
            continue
        if item.name in FORGE_EXCLUDE or item.name.startswith("."):
            continue
        if not _is_forge_project(item):
            continue
        manifest_path = _get_manifest_path(item)
        if manifest_path:
            result = ProjectFactory.from_manifest(manifest_path)
            if result.ok and result.value is not None:
                projects.append(result.value)
            else:
                projects.append(_stub_project(item, result.error or "Parse failed"))
        else:
            projects.append(
                _stub_project(item, "No manifest.yaml — run: forge manifest --init")
            )
    projects.sort(key=lambda p: p.name.lower())
    return projects


def get_projects_root() -> Path:
    """Returns Path('~/Projects/').expanduser(). Reads FORGE_PROJECTS_ROOT env var as override if set."""
    import os

    root = os.environ.get("FORGE_PROJECTS_ROOT")
    if root:
        return Path(root).expanduser()
    return Path("~/Projects").expanduser()
