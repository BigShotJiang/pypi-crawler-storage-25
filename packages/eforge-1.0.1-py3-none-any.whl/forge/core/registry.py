"""
forge template registry — multi-source save/load/list.

Two registry kinds live side-by-side in this module:

  Node templates  (single-kind anatomy)
    Root:  ~/.forge/templates/{source}/{stack}/{kind}/{name}.yaml
    API:   save_template / load_template / list_templates
    Used by: commands.scaffold_menu (--from-template / --save-as / --list-templates)

  Feature templates  (multi-node anatomy — "auth needs screen + controller + service")
    Root:   ~/.forge/registries/{tier}/{stack}/{name}.yaml   (user-local)
    Bundled: <forge_install>/templates/registries/{tier}/{stack}/{name}.yaml
    API:   save_feature_template / get_feature_template / list_feature_templates
    Schema: forge/core/registry_schema.yaml
    Used by: commands.scaffold_menu (_load_feature_templates) — wired in ANNOT-024

Priority order (both kinds): local → community → custom → bundled
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
from mcp.types import ToolAnnotations

import yaml

REGISTRIES_ROOT = Path("~/.forge/templates").expanduser()
REGISTRY_PRIORITY = ["local", "community", "custom"]

# ── Feature template roots ─────────────────────────────────────────────────────
# User-local first; bundled ships inside the forge package as the last resort.
FEATURE_REGISTRIES_ROOT = Path("~/.forge/registries").expanduser()
FEATURE_REGISTRY_PRIORITY = ["local", "community", "custom"]
_FEATURE_BUNDLED_ROOT = Path(__file__).resolve().parent.parent.parent / "templates" / "registries"

# Fields that are project-specific — stripped when saving; user fills these at use time.
# 'domain' is also stripped so templates are portable across domains.
_PROJECT_SPECIFIC = {"id", "name", "file", "path", "domain"}


def registry_path(source: str = "local") -> Path:
    # Local templates live directly at ~/.forge/templates/
    # Community / custom get their own sub-directories.
    if source == "local":
        return REGISTRIES_ROOT
    return REGISTRIES_ROOT / source


def template_path(
    stack: str | list | None,
    kind: str,
    name: str,
    source: str = "local",
) -> Path:
    # Normalise stack: list → first element; None → "universal"
    if isinstance(stack, list):
        bucket = stack[0] if stack else "universal"
    else:
        bucket = stack or "universal"
    return registry_path(source) / bucket / kind / f"{name}.yaml"


def save_template(
    artifact: dict[str, Any],
    schema: dict[str, Any],
    name: str,
    description: str = "",
    source: str = "local",
) -> Path:
    """Strip project-specific fields and write a reusable template.

    Template format:
        kind / stack / description / slots / required_at_use /
        generated_files_pattern / forge_registry_version
    """
    slots = {
        k: v for k, v in artifact.items()
        if k not in _PROJECT_SPECIFIC
    }

    # required_at_use: schema required fields that were stripped (user fills at use time)
    required_fields: list[str] = list(schema.get("required_fields") or [])
    required_at_use = sorted(
        {f for f in required_fields if f in _PROJECT_SPECIFIC}
        | {"id"}  # id always required
    )

    # generated_files_pattern: auto_derive path templates from schema
    auto_derive: dict[str, str] = dict(schema.get("auto_derive") or {})
    generated_files_pattern = list(auto_derive.values()) if auto_derive else []

    template: dict[str, Any] = {
        "kind": schema["kind"],
        "stack": schema.get("stack"),
        "description": description,
        "slots": slots,
        "required_at_use": required_at_use,
        "generated_files_pattern": generated_files_pattern,
        "forge_registry_version": 1,
    }
    path = template_path(schema.get("stack"), schema["kind"], name, source)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        yaml.dump(template, fh, default_flow_style=False, allow_unicode=True)
    return path


def load_template(
    stack: str | list | None,
    kind: str,
    name: str,
) -> tuple[dict[str, Any], str] | None:
    """
    Search registries in priority order.
    Returns (template_dict, source_name) or None if not found.
    Falls back to the 'universal' bucket when a stack-specific path misses.
    """
    for source in REGISTRY_PRIORITY:
        # Stack-specific path first
        p = template_path(stack, kind, name, source)
        if p.exists():
            data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            _normalise(data)
            return data, source
        # Universal fallback
        p_univ = template_path(None, kind, name, source)
        if p_univ.exists():
            data = yaml.safe_load(p_univ.read_text(encoding="utf-8")) or {}
            _normalise(data)
            return data, source
    return None


def _normalise(data: dict[str, Any]) -> None:
    """Normalise legacy key 'preset_slots' → 'slots' in-place."""
    if "preset_slots" in data and "slots" not in data:
        data["slots"] = data.pop("preset_slots")


def list_templates(
    stack: str | None = None,
    source: str | None = None,
) -> list[dict[str, Any]]:
    """Return all templates, optionally filtered by stack and/or source."""
    sources = [source] if source else REGISTRY_PRIORITY
    results: list[dict[str, Any]] = []
    for src in sources:
        base = registry_path(src)
        if not base.exists():
            continue
        for yaml_file in sorted(base.rglob("*.yaml")):
            parts = yaml_file.relative_to(base).parts
            if len(parts) != 3:
                continue  # expect {bucket}/{kind}/{name}.yaml
            t = yaml.safe_load(yaml_file.read_text(encoding="utf-8")) or {}
            t["_name"] = yaml_file.stem
            t["_bucket"] = parts[0]
            t["_kind"] = parts[1]
            t["_source"] = src
            results.append(t)
    if stack:
        results = [
            t for t in results
            if t.get("stack") == stack
            or t.get("_bucket") == "universal"
        ]
    return results


# ══════════════════════════════════════════════════════════════════════════════
# Feature template API
# Schema contract: forge/core/registry_schema.yaml
# Storage: ~/.forge/registries/{tier}/{stack}/{name}.yaml
# Bundled: <forge_install>/templates/registries/{tier}/{stack}/{name}.yaml
# Prerequisite for ANNOT-024 (questionnaire wiring in scaffold_menu)
# ══════════════════════════════════════════════════════════════════════════════

def _feature_tier_root(tier: str, *, user: bool = True) -> Path:
    """Return root for a single tier.  user=True → ~/.forge/registries,
    user=False → bundled package path."""
    if user:
        return FEATURE_REGISTRIES_ROOT / tier
    return _FEATURE_BUNDLED_ROOT / tier


def _validate_feature_template(data: dict[str, Any]) -> list[str]:
    """Lightweight validation against registry_schema.yaml required fields.

    Returns a list of error strings.  Empty = valid.
    Does NOT require a full JSON-schema library — checks required keys only.
    """
    errors: list[str] = []
    for field in ("template", "stack", "version", "requires"):
        if field not in data:
            errors.append(f"missing required field: {field!r}")
    req = data.get("requires")
    if req is not None:
        if not isinstance(req, list):
            errors.append("'requires' must be a list of NodeRef dicts")
        else:
            for i, item in enumerate(req):
                if not isinstance(item, dict) or "kind" not in item:
                    errors.append(
                        f"requires[{i}] must be a dict with at least 'kind': {item!r}"
                    )
    return errors


def _iter_feature_yaml(tier: str, stack: str, *, user: bool) -> list[Path]:
    """Return all *.yaml files in {root}/{tier}/{stack}/, sorted."""
    root = _feature_tier_root(tier, user=user) / stack
    if not root.is_dir():
        return []
    return sorted(root.glob("*.yaml"))


def list_feature_templates(
    stack: str | None = None,
    tier: str = "local",
) -> list[dict[str, Any]]:
    """Return feature templates for a stack from a single tier.

    Search order: user-local first, then bundled (same tier name).
    Deduplicates by template name — user-local wins over bundled.

    Returns list of template dicts, each augmented with:
      _name   — file stem (template name)
      _source — "local" | "community" | "custom" | "bundled"
      _errors — list of validation error strings (empty = valid)
    """
    seen: dict[str, dict[str, Any]] = {}  # name → first-found template

    def _load_dir(paths: list[Path], source_label: str) -> None:
        for p in paths:
            name = p.stem
            if name in seen:
                continue  # user-local already claimed this name
            try:
                data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            except Exception:
                continue
            errors = _validate_feature_template(data)
            data["_name"] = name
            data["_source"] = source_label
            data["_errors"] = errors
            seen[name] = data

    stacks_to_scan = [stack] if stack else []

    if stacks_to_scan:
        for s in stacks_to_scan:
            _load_dir(_iter_feature_yaml(tier, s, user=True), tier)
            _load_dir(_iter_feature_yaml(tier, s, user=False), "bundled")
    else:
        # No stack filter: scan all subdirectories
        for root_fn, label in (
            (lambda t: _feature_tier_root(t, user=True), tier),
            (lambda t: _feature_tier_root(t, user=False), "bundled"),
        ):
            base = root_fn(tier)
            if base.is_dir():
                for subdir in sorted(base.iterdir()):
                    if subdir.is_dir():
                        _load_dir(sorted(subdir.glob("*.yaml")), label)

    return list(seen.values())


def get_feature_template(
    name: str,
    stack: str,
    tier: str = "local",
) -> dict[str, Any] | None:
    """Load a single feature template by name and stack.

    Search order: user-local/{tier}/{stack}/{name}.yaml → bundled/{tier}/{stack}/{name}.yaml
    Returns the parsed dict (with _name, _source, _errors) or None if not found.
    """
    for user_flag, source_label in ((True, tier), (False, "bundled")):
        p = _feature_tier_root(tier, user=user_flag) / stack / f"{name}.yaml"
        if p.is_file():
            try:
                data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            except Exception:
                continue
            data["_name"] = p.stem
            data["_source"] = source_label
            data["_errors"] = _validate_feature_template(data)
            return data
    return None


def save_feature_template(
    template_dict: dict[str, Any],
    tier: str = "local",
) -> Path:
    """Write a feature template to ~/.forge/registries/{tier}/{stack}/{name}.yaml.

    Validates against registry_schema.yaml before writing.
    Raises ValueError if required fields are missing.
    Returns the path written.
    """
    errors = _validate_feature_template(template_dict)
    if errors:
        raise ValueError(
            f"Feature template validation failed:\n" + "\n".join(f"  {e}" for e in errors)
        )
    stack = str(template_dict["stack"])
    name = str(template_dict["template"])
    dest = _feature_tier_root(tier, user=True) / stack / f"{name}.yaml"
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open("w", encoding="utf-8") as fh:
        yaml.dump(template_dict, fh, default_flow_style=False, allow_unicode=True)
    return dest
