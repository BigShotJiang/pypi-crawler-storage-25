from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _template_path() -> Path:
    return _repo_root() / "schemas" / "stacks" / "_template.yaml"


def _type_name(v: Any) -> str:
    if isinstance(v, bool):
        return "bool"
    if isinstance(v, int):
        return "int"
    if isinstance(v, float):
        return "float"
    if isinstance(v, str):
        return "str"
    if isinstance(v, list):
        return "list"
    if isinstance(v, dict):
        return "dict"
    if v is None:
        return "null"
    return type(v).__name__


def validate_stack_schema(schema_path: Path) -> list[str]:
    """Validate a stack schema against the universal template contract."""
    violations: list[str] = []
    p = schema_path.expanduser().resolve()
    try:
        raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except Exception as exc:  # noqa: BLE001
        return [f"{p}: unreadable YAML ({exc})"]
    if not isinstance(raw, dict):
        return [f"{p}: root must be a mapping/object"]

    try:
        tmpl = yaml.safe_load(_template_path().read_text(encoding="utf-8")) or {}
    except Exception as exc:  # noqa: BLE001
        return [f"{p}: template unreadable ({exc})"]
    if not isinstance(tmpl, dict):
        return [f"{p}: template root must be a mapping/object"]

    required = [
        "stack_id",
        "display_name",
        "package_manifest",
        "test_patterns",
        "allowed_node_kinds",
        "allowed_sections",
        "allowed_node_fields",
        "forbidden_from_other_stacks",
        "scaffold_templates",
    ]
    for key in required:
        if key not in raw:
            violations.append(f"{p}: missing required field '{key}'")

    if isinstance(raw.get("stack_id"), str):
        if not str(raw.get("stack_id")).strip():
            violations.append(f"{p}: 'stack_id' must be a non-empty string")
    elif "stack_id" in raw:
        violations.append(f"{p}: 'stack_id' must be string, got {_type_name(raw.get('stack_id'))}")

    if isinstance(raw.get("display_name"), str):
        if not str(raw.get("display_name")).strip():
            violations.append(f"{p}: 'display_name' must be a non-empty string")
    elif "display_name" in raw:
        violations.append(f"{p}: 'display_name' must be string, got {_type_name(raw.get('display_name'))}")

    if isinstance(raw.get("package_manifest"), str):
        if not str(raw.get("package_manifest")).strip():
            violations.append(f"{p}: 'package_manifest' must be a non-empty string")
    elif "package_manifest" in raw:
        violations.append(f"{p}: 'package_manifest' must be string, got {_type_name(raw.get('package_manifest'))}")

    for key in ("test_patterns", "allowed_node_kinds", "allowed_sections"):
        value = raw.get(key)
        if key not in raw:
            continue
        if not isinstance(value, list):
            violations.append(f"{p}: '{key}' must be list[str], got {_type_name(value)}")
            continue
        bad = [idx for idx, item in enumerate(value) if not isinstance(item, str) or not item.strip()]
        if bad:
            violations.append(f"{p}: '{key}' has non-string/empty entries at indexes {bad}")

    # contracts: production stack YAML must declare a non-empty module field allowlist (Sprint 4)
    anf = raw.get("allowed_node_fields")
    if "allowed_node_fields" in raw:
        if not isinstance(anf, list):
            violations.append(f"{p}: 'allowed_node_fields' must be list[str], got {_type_name(anf)}")
        else:
            bad = [idx for idx, item in enumerate(anf) if not isinstance(item, str) or not item.strip()]
            if bad:
                violations.append(f"{p}: 'allowed_node_fields' has non-string/empty entries at indexes {bad}")
            elif not any(isinstance(item, str) and item.strip() for item in anf):
                violations.append(f"{p}: 'allowed_node_fields' must be non-empty (see tests/stack_contract.py pattern)")

    fcos = raw.get("forbidden_from_other_stacks")
    if "forbidden_from_other_stacks" in raw:
        if not isinstance(fcos, dict):
            violations.append(
                f"{p}: 'forbidden_from_other_stacks' must be object with fields/node_kinds, got {_type_name(fcos)}"
            )
        else:
            for sub in ("fields", "node_kinds"):
                sub_v = fcos.get(sub)
                if sub not in fcos:
                    violations.append(f"{p}: 'forbidden_from_other_stacks.{sub}' is required")
                    continue
                if not isinstance(sub_v, list):
                    violations.append(
                        f"{p}: 'forbidden_from_other_stacks.{sub}' must be list[str], got {_type_name(sub_v)}"
                    )
                    continue
                bad = [idx for idx, item in enumerate(sub_v) if not isinstance(item, str) or not item.strip()]
                if bad:
                    violations.append(
                        f"{p}: 'forbidden_from_other_stacks.{sub}' has non-string/empty entries at indexes {bad}"
                    )

    scaff = raw.get("scaffold_templates")
    if "scaffold_templates" in raw and not isinstance(scaff, dict):
        violations.append(f"{p}: 'scaffold_templates' must be object/map, got {_type_name(scaff)}")

    notes = raw.get("notes")
    if "notes" in raw and notes is not None and not isinstance(notes, str):
        violations.append(f"{p}: optional 'notes' must be string when present")

    return violations
