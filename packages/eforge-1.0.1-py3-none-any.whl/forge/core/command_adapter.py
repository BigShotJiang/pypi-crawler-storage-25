"""
Command Adapter - Makes existing Forge commands compatible with component architecture.
Provides seamless integration between dict-based commands and component-based projects.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Callable
from pathlib import Path
import functools

from forge.core.forge_project_system import ForgeProject
from forge.archive.ecs.graph_component_adapter import GraphComponentAdapter, make_graph_system_compatible


class CommandAdapter:
    """
    Adapter that makes existing Forge commands work with component architecture.
    Provides backward compatibility while enabling component-based development.
    """
    
    def __init__(self, project: ForgeProject):
        self.project = project
        self.graph_adapter = GraphComponentAdapter(project)
        self.command_patches: Dict[str, Callable] = {}
        self.original_functions: Dict[str, Callable] = {}
    
    # === COMMAND PATCHING ===
    
    def patch_command(self, command_name: str, module_path: str, function_name: str):
        """Patch a command to use component system."""
        try:
            # Import the module
            module_parts = module_path.split('.')
            module = __import__(module_path)
            for part in module_parts[1:]:
                module = getattr(module, part)
            
            # Get original function
            original_func = getattr(module, function_name)
            self.original_functions[f"{module_path}.{function_name}"] = original_func
            
            # Create patched function
            patched_func = self._create_patched_function(original_func, command_name)
            
            # Apply patch
            setattr(module, function_name, patched_func)
            self.command_patches[command_name] = patched_func
            
            return True
        except Exception as e:
            print(f"Failed to patch {command_name}: {e}")
            return False
    
    def _create_patched_function(self, original_func: Callable, command_name: str) -> Callable:
        """Create a patched version of the function."""
        
        @functools.wraps(original_func)
        def patched_function(*args, **kwargs):
            # Inject project context if needed
            if 'project_path' in kwargs:
                project_path = kwargs['project_path']
                if not project_path or str(project_path) == ".":
                    kwargs['project_path'] = str(self.project.root_path)
            
            # Ensure graph adapter is available
            if hasattr(original_func, '__globals__'):
                original_func.__globals__['_graph_adapter'] = self.graph_adapter
                original_func.__globals__['_component_project'] = self.project
            
            # Call original function
            try:
                result = original_func(*args, **kwargs)
                
                # Sync components back to graph if needed
                self._sync_components_to_graph()
                
                return result
            except Exception as e:
                print(f"Error in patched {command_name}: {e}")
                raise
        
        return patched_function
    
    def _sync_components_to_graph(self):
        """Sync component entities back to graph format."""
        # This ensures that component changes are reflected in the graph
        graph_dict = self.graph_adapter.get_graph_as_dict()
        # Store in project resources for other commands to access
        self.project.set_resource("current_graph", graph_dict)
    
    def restore_original_functions(self):
        """Restore all original functions."""
        for full_name, original_func in self.original_functions.items():
            try:
                module_path, function_name = full_name.rsplit('.', 1)
                module_parts = module_path.split('.')
                module = __import__(module_path)
                for part in module_parts[1:]:
                    module = getattr(module, part)
                
                setattr(module, function_name, original_func)
            except Exception as e:
                print(f"Failed to restore {full_name}: {e}")
        
        self.command_patches.clear()
        self.original_functions.clear()
    
    # === LEGACY API COMPATIBILITY ===
    
    def get_legacy_graph_interface(self):
        """Get a dict-like interface compatible with existing commands."""
        return make_graph_system_compatible(self.project)
    
    def ensure_graph_loaded(self):
        """Ensure graph is loaded and available."""
        if not self.graph_adapter._graph_cache.get("manifest"):
            self.graph_adapter.load_manifest_graph()
    
    def get_nodes(self, **filters) -> List[Dict[str, Any]]:
        """Get nodes using legacy API."""
        self.ensure_graph_loaded()
        return self.graph_adapter.get_nodes(**filters)
    
    def get_edges(self, **filters) -> List[Dict[str, Any]]:
        """Get edges using legacy API."""
        self.ensure_graph_loaded()
        return self.graph_adapter.get_edges(**filters)
    
    def add_node(self, node_dict: Dict[str, Any]) -> str:
        """Add node using legacy API."""
        self.ensure_graph_loaded()
        return self.graph_adapter.add_node(node_dict)
    
    def add_edge(self, edge_dict: Dict[str, Any]) -> str:
        """Add edge using legacy API."""
        self.ensure_graph_loaded()
        return self.graph_adapter.add_edge(edge_dict)
    
    def remove_node(self, node_id: str) -> bool:
        """Remove node using legacy API."""
        self.ensure_graph_loaded()
        return self.graph_adapter.remove_node(node_id)
    
    def remove_edge(self, edge_key: str) -> bool:
        """Remove edge using legacy API."""
        self.ensure_graph_loaded()
        return self.graph_adapter.remove_edge(edge_key)


# === COMMAND REGISTRY ===

class CommandRegistry:
    """Registry for managing command patches."""
    
    def __init__(self):
        self.adapters: Dict[str, CommandAdapter] = {}
        self.global_patches: List[Dict[str, Any]] = []
    
    def register_project(self, project: ForgeProject) -> str:
        """Register a project for command adaptation."""
        adapter = CommandAdapter(project)
        project_id = project.id
        self.adapters[project_id] = adapter
        
        # Apply common patches
        self._apply_common_patches(adapter)
        
        return project_id
    
    def get_adapter(self, project_id: str) -> Optional[CommandAdapter]:
        """Get adapter for a project."""
        return self.adapters.get(project_id)
    
    def _apply_common_patches(self, adapter: CommandAdapter):
        """Apply patches to common Forge commands."""
        common_patches = [
            # Graph-related commands
            {
                "command": "build_manifest_graph",
                "module": "forge.tools.manifest.graph",
                "function": "build_manifest_graph"
            },
            # Manifest commands
            {
                "command": "manifest_validate",
                "module": "forge.commands.manifest_cmd", 
                "function": "validate_manifest"
            },
            # Query commands
            {
                "command": "query_nodes",
                "module": "forge.tools.manifest.query",
                "function": "query_nodes"
            },
            # Diff commands
            {
                "command": "diff_nodes",
                "module": "forge.commands.diff_cmd",
                "function": "diff_nodes"
            }
        ]
        
        for patch in common_patches:
            adapter.patch_command(
                patch["command"],
                patch["module"],
                patch["function"]
            )
    
    def restore_all(self):
        """Restore all original functions."""
        for adapter in self.adapters.values():
            adapter.restore_original_functions()
        self.adapters.clear()


# === DECORATOR FOR COMMANDS ===

def component_compatible_command(command_name: str):
    """
    Decorator to make a command compatible with component architecture.
    Usage:
    
    @component_compatible_command("my_command")
    def my_command_func(project_path, **kwargs):
        # Function can now work with both dict and component systems
        graph = kwargs.get('_graph_adapter') or load_graph(project_path)
        return process_nodes(graph)
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Try to get component context
            graph_adapter = kwargs.get('_graph_adapter')
            component_project = kwargs.get('_component_project')
            
            if not graph_adapter and component_project:
                # Create adapter if not available
                from forge.archive.ecs.graph_component_adapter import create_graph_adapter
                graph_adapter = create_graph_adapter(component_project)
                kwargs['_graph_adapter'] = graph_adapter
            
            # Ensure project path is set
            if 'project_path' in kwargs:
                project_path = kwargs['project_path']
                if component_project and (not project_path or str(project_path) == "."):
                    kwargs['project_path'] = str(component_project.root_path)
            
            # Call original function
            return func(*args, **kwargs)
        
        wrapper._component_compatible = True
        wrapper._command_name = command_name
        return wrapper
    
    return decorator


# === UTILITY FUNCTIONS ===

def create_command_adapter(project: ForgeProject) -> CommandAdapter:
    """Create a command adapter for a project."""
    return CommandAdapter(project)


def get_global_command_registry() -> CommandRegistry:
    """Get the global command registry."""
    if not hasattr(get_global_command_registry, '_instance'):
        get_global_command_registry._instance = CommandRegistry()
    return get_global_command_registry._instance


def patch_forge_commands(project: ForgeProject):
    """Patch all common Forge commands for component compatibility."""
    registry = get_global_command_registry()
    project_id = registry.register_project(project)
    
    return registry.get_adapter(project_id)


# === EXAMPLE USAGE ===

def command_adapter_example():
    """Example of using command adapter with existing Forge commands."""
    from forge.core.forge_project_system import create_project
    from forge.tools.manifest.graph import build_manifest_graph
    
    # Create project
    project = create_project(Path("/Users/sebastianpereira/Projects/forge"))
    
    # Create command adapter
    adapter = create_command_adapter(project)
    
    # Patch common commands
    adapter.patch_command(
        "build_manifest_graph",
        "forge.tools.manifest.graph",
        "build_manifest_graph"
    )
    
    # Use legacy API through adapter
    nodes = adapter.get_nodes(kind="controller")
    print(f"Found {len(nodes)} controllers")
    
    # Add new node
    new_node = {
        "id": "test/controller",
        "kind": "controller",
        "name": "TestController",
        "path": "src/test_controller.py",
        "domain": "test",
        "meta": {"tier": "surface"}
    }
    node_id = adapter.add_node(new_node)
    print(f"Added node: {node_id}")
    
    # Get dict-compatible interface
    graph_interface = adapter.get_legacy_graph_interface()
    all_nodes = graph_interface["nodes"]
    all_edges = graph_interface["edges"]
    
    # Use like original
    controllers = [n for n in all_nodes if n.get("kind") == "controller"]
    dependencies = [e for e in all_edges if e.get("relation") == "depends_on"]
    
    return project, adapter, graph_interface


def decorator_example():
    """Example of using component-compatible decorator."""
    
    @component_compatible_command("my_analysis")
    def analyze_nodes(project_path, **kwargs):
        """Analyze nodes using component system if available."""
        # Get graph adapter from kwargs or create one
        graph_adapter = kwargs.get('_graph_adapter')
        if not graph_adapter:
            # Fallback to traditional loading
            from forge.tools.manifest.graph import build_manifest_graph
            graph = build_manifest_graph(project_path, str(Path(project_path).parent))
            return [{"id": n.id, "kind": n.kind} for n in graph.nodes]
        
        # Use component system
        nodes = graph_adapter.get_nodes()
        return [{"id": n["id"], "kind": n["kind"]} for n in nodes]
    
    # Function can now be called with or without component context
    return analyze_nodes
