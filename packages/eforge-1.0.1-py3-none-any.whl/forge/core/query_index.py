"""SQLite read cache for ``forge_query`` filter mode (Phase 8 accelerator).

``QueryBackend`` is the stable protocol boundary; ``SQLiteQueryBackend`` is the v1
implementation. Future Postgres / Supabase backends are new modules implementing the
same protocol — ``forge_query`` only depends on ``QueryBackend``.

Schema (v1) — derived from ``QueryResult.data`` filter payloads (``nodes[*].{id,name,kind,domain,path,out,in}``),
never from raw manifest YAML:

.. code-block:: sql

    CREATE TABLE meta (
      k TEXT PRIMARY KEY,
      v TEXT NOT NULL
    );
    -- keys: manifest_path, manifest_mtime, built_at, forge_version

    CREATE TABLE nodes (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      kind TEXT NOT NULL,
      domain TEXT,
      path TEXT
    );
    CREATE INDEX idx_nodes_kind ON nodes(kind);
    CREATE INDEX idx_nodes_name ON nodes(name);

    CREATE TABLE edges (
      from_id TEXT NOT NULL,
      to_id TEXT NOT NULL,
      relation TEXT NOT NULL,
      PRIMARY KEY (from_id, to_id, relation)
    ) WITHOUT ROWID;
    CREATE INDEX idx_edges_from ON edges(from_id);
    CREATE INDEX idx_edges_to ON edges(to_id);

``build()`` snapshots the graph by calling ``forge_query(..., depth=1, _skip_accelerator=True)``
and persisting ``imports`` edges extracted from each node's ``out``/``in`` lists.

``forge_query`` uses a backend only as a transparent accelerator for filter mode;
blast mode and invalid / missing backends always use in-memory graph traversal.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Mapping, Protocol, runtime_checkable

from forge.tools.manifest.graph import ManifestGraph

if TYPE_CHECKING:
    from forge.core.query import QueryResult

# TODO: replace with a shared TypedDict / dataclass when filter payloads are centralised.
QueryFilters = Mapping[str, Any]


@runtime_checkable
class QueryBackend(Protocol):
    def build(self, graph: ManifestGraph) -> None: ...
    def query(self, filters: QueryFilters) -> "QueryResult | None": ...
    def is_valid(self, manifest_path: Path) -> bool: ...
    def invalidate(self) -> None: ...


def _forge_version() -> str:
    try:
        from importlib.metadata import version

        return str(version("forge"))
    except Exception:
        return "0"


@dataclass
class SQLiteQueryBackend:
    """Read cache at ``<project_root>/.forge/audit-index.db`` (not canonical — YAML + graph files are)."""

    project_root: Path
    manifest_path: Path

    def __post_init__(self) -> None:
        self.project_root = self.project_root.expanduser().resolve()
        self.manifest_path = self.manifest_path.expanduser().resolve()
        self.db_path = self.project_root / ".forge" / "audit-index.db"

    def invalidate(self) -> None:
        if self.db_path.is_file():
            try:
                self.db_path.unlink()
            except OSError:
                pass

    def is_valid(self, manifest_path: Path) -> bool:
        mp = manifest_path.expanduser().resolve()
        if not mp.is_file():
            return False
        if not self.db_path.is_file():
            return False
        try:
            cur_mtime = str(mp.stat().st_mtime)
        except OSError:
            return False
        try:
            conn = sqlite3.connect(str(self.db_path))
            row = conn.execute("SELECT v FROM meta WHERE k = 'manifest_mtime'").fetchone()
            conn.close()
        except sqlite3.Error:
            return False
        if not row:
            return False
        return str(row[0]) == cur_mtime

    def build(self, graph: ManifestGraph) -> None:
        """Populate the DB from ``forge_query`` over *graph* (never raw YAML)."""
        from forge.core import query as query_mod

        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        snap = query_mod.forge_query(
            graph,
            kind="",
            where={},
            reverse_of=None,
            via=None,
            depth=1,
            limit=10**9,
            direction="both",
            backend=None,
            _skip_accelerator=True,
        ).as_dict()
        nodes_rows = snap.get("nodes") or []
        if not isinstance(nodes_rows, list):
            nodes_rows = []

        try:
            mtime = str(self.manifest_path.stat().st_mtime)
        except OSError:
            mtime = "0"

        built_at = datetime.now(timezone.utc).isoformat()
        self.invalidate()
        conn = sqlite3.connect(str(self.db_path))
        try:
            conn.execute("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT NOT NULL)")
            conn.execute(
                """CREATE TABLE nodes (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    domain TEXT,
                    path TEXT
                )"""
            )
            conn.execute(
                """CREATE TABLE edges (
                    from_id TEXT NOT NULL,
                    to_id TEXT NOT NULL,
                    relation TEXT NOT NULL,
                    PRIMARY KEY (from_id, to_id, relation)
                ) WITHOUT ROWID"""
            )
            conn.execute("CREATE INDEX idx_nodes_kind ON nodes(kind)")
            conn.execute("CREATE INDEX idx_nodes_name ON nodes(name)")
            conn.execute("CREATE INDEX idx_edges_from ON edges(from_id)")
            conn.execute("CREATE INDEX idx_edges_to ON edges(to_id)")

            meta = {
                "manifest_path": str(self.manifest_path),
                "manifest_mtime": mtime,
                "built_at": built_at,
                "forge_version": _forge_version(),
            }
            for k, v in meta.items():
                conn.execute("INSERT INTO meta (k, v) VALUES (?, ?)", (k, v))

            seen_edges: set[tuple[str, str, str]] = set()
            for row in nodes_rows:
                if not isinstance(row, dict):
                    continue
                nid = str(row.get("id") or "")
                if not nid:
                    continue
                conn.execute(
                    "INSERT OR REPLACE INTO nodes (id, name, kind, domain, path) VALUES (?,?,?,?,?)",
                    (
                        nid,
                        str(row.get("name") or ""),
                        str(row.get("kind") or ""),
                        row.get("domain"),
                        str(row.get("path") or ""),
                    ),
                )
                for e in row.get("out") or []:
                    if not isinstance(e, dict):
                        continue
                    if str(e.get("relation") or "") != "imports":
                        continue
                    to_id = str(e.get("to") or "")
                    if not to_id:
                        continue
                    key = (nid, to_id, "imports")
                    if key in seen_edges:
                        continue
                    seen_edges.add(key)
                    conn.execute(
                        "INSERT OR IGNORE INTO edges (from_id, to_id, relation) VALUES (?,?,?)",
                        (nid, to_id, "imports"),
                    )
                for e in row.get("in") or []:
                    if not isinstance(e, dict):
                        continue
                    if str(e.get("relation") or "") != "imports":
                        continue
                    from_id = str(e.get("from") or "")
                    if not from_id:
                        continue
                    key = (from_id, nid, "imports")
                    if key in seen_edges:
                        continue
                    seen_edges.add(key)
                    conn.execute(
                        "INSERT OR IGNORE INTO edges (from_id, to_id, relation) VALUES (?,?,?)",
                        (from_id, nid, "imports"),
                    )
            conn.commit()
        finally:
            conn.close()

    def get_or_build(self, graph: ManifestGraph) -> None:
        if not self.is_valid(self.manifest_path):
            self.build(graph)

    def query(self, filters: QueryFilters) -> QueryResult | None:
        """Return a ``QueryResult`` for filter mode, or ``None`` to fall back to graph traversal."""
        from forge.core.query import QueryResult

        raw_graph = filters.get("graph")
        if not isinstance(raw_graph, ManifestGraph):
            return None
        via = filters.get("via") or ()
        if not isinstance(via, tuple):
            via = ()

        payload = self._accelerated_payload(
            raw_graph,
            kind_filter=str(filters.get("kind") or ""),
            domain_filter=str((filters.get("where") or {}).get("domain") or ""),
            name_filter=str((filters.get("where") or {}).get("name") or ""),
            dep_filter=str((filters.get("where") or {}).get("depends_on") or ""),
            limit=int(filters.get("limit") or 50),
            depth=int(filters.get("depth") or 1),
            direction=str(filters.get("direction") or "both"),
            via=via,
            sort_by=str(filters.get("sort_by") or "").strip() or None,
        )
        if payload is None:
            return None
        return QueryResult(operation="filter", data=payload)

    def _accelerated_payload(
        self,
        graph: ManifestGraph,
        *,
        kind_filter: str,
        domain_filter: str,
        name_filter: str,
        dep_filter: str,
        limit: int,
        depth: int,
        direction: str,
        via: tuple[str, ...],
        sort_by: str | None,
    ) -> dict[str, Any] | None:
        """Return the same dict shape as ``run_manifest_graph_query_on_graph``, or ``None`` to fall back."""
        if not self.is_valid(self.manifest_path):
            return None
        if via:
            return None

        kind_f = kind_filter.lower()
        domain_f = domain_filter.lower()
        name_f = name_filter.lower()
        dep_f = dep_filter.lower()
        dep_f_slug = dep_f.replace(".", "_")
        lim = max(1, int(limit))
        dep = max(1, min(3, int(depth)))
        direc = direction.lower() if direction.lower() in ("in", "out", "both") else "both"

        try:
            conn = sqlite3.connect(str(self.db_path))
        except sqlite3.Error:
            return None
        try:
            imports_in: dict[str, set[str]] = {}
            imports_out: dict[str, set[str]] = {}
            for fr, to in conn.execute(
                "SELECT from_id, to_id FROM edges WHERE relation = 'imports'"
            ):
                imports_in.setdefault(str(to), set()).add(str(fr))
                imports_out.setdefault(str(fr), set()).add(str(to))

            node_by_id = {n.id: n for n in graph.nodes}

            def _node_dict(node: Any, hop: int) -> dict[str, Any]:
                out_edges = [{"to": e.to_id, "relation": e.relation} for e in graph.edges_from(node.id)]
                in_edges = [{"from": e.from_id, "relation": e.relation} for e in graph.edges_to(node.id)]
                return {
                    "id": node.id,
                    "name": node.name,
                    "kind": node.kind,
                    "domain": node.domain,
                    "path": node.path,
                    "out": out_edges,
                    "in": in_edges,
                    "hop": hop,
                }

            seeds_sql = "SELECT id FROM nodes WHERE 1=1"
            params: list[Any] = []
            if kind_f:
                seeds_sql += " AND lower(kind) = ?"
                params.append(kind_f)
            if domain_f:
                seeds_sql += " AND lower(coalesce(domain, '')) LIKE ?"
                params.append(f"%{domain_f}%")
            if name_f:
                seeds_sql += " AND lower(name) LIKE ?"
                params.append(f"%{name_f}%")

            seed_ids = {str(r[0]) for r in conn.execute(seeds_sql, params)}
            if dep_f:
                dep_sql = (
                    "SELECT DISTINCT n.id FROM nodes n "
                    "JOIN edges e ON e.from_id = n.id AND e.relation = 'imports' "
                    "WHERE lower(e.to_id) LIKE ? OR lower(replace(e.to_id, '.', '_')) LIKE ?"
                )
                dep_ids = {
                    str(r[0])
                    for r in conn.execute(dep_sql, (f"%{dep_f}%", f"%{dep_f_slug}%"))
                }
                seed_ids &= dep_ids

            results: list[dict[str, Any]] = []
            seen: set[str] = set()
            for node in graph.nodes:
                if node.id not in seed_ids:
                    continue
                if kind_f and (node.kind or "").lower() != kind_f:
                    continue
                if domain_f and domain_f not in (node.domain or "").lower():
                    continue
                if name_f and name_f not in (node.name or "").lower():
                    continue
                if dep_f:
                    outgoing = [
                        e
                        for e in graph.edges_from(node.id)
                        if dep_f in e.to_id.lower() or dep_f_slug in e.to_id.lower()
                    ]
                    if not outgoing:
                        continue
                if node.id in seen:
                    continue
                seen.add(node.id)
                results.append(_node_dict(node, hop=0))

            frontier: set[str] = set(seen)
            for hop in range(1, dep):
                candidates: set[str] = set()
                for nid2 in frontier:
                    if direc in ("in", "both"):
                        candidates.update(c for c in imports_in.get(nid2, set()) if c not in seen)
                    if direc in ("out", "both"):
                        candidates.update(c for c in imports_out.get(nid2, set()) if c not in seen)
                if not candidates:
                    break
                for nid3 in sorted(candidates):
                    node2 = node_by_id.get(nid3)
                    if node2 is None:
                        continue
                    seen.add(nid3)
                    results.append(_node_dict(node2, hop=hop))
                frontier = candidates

            sb = (sort_by or "").strip().lower()
            if sb == "criticality":
                results.sort(
                    key=lambda r: sum(
                        1 for e in graph.edges_to(str(r.get("id") or "")) if e.relation == "imports"
                    ),
                    reverse=True,
                )
            elif sb == "name":
                results.sort(key=lambda r: str(r.get("name") or "").lower())
            elif sb == "domain":
                results.sort(
                    key=lambda r: (
                        str(r.get("domain") or "").upper(),
                        str(r.get("name") or "").lower(),
                    )
                )

            results = results[:lim]
            return {
                "count": len(results),
                "nodes": results,
                "filters": {
                    "kind": kind_f or None,
                    "domain": domain_f or None,
                    "name": name_f or None,
                    "depends_on": dep_f or None,
                    "depth": dep,
                    "direction": direc,
                    "sort_by": sb or None,
                },
            }
        except sqlite3.Error:
            return None
        finally:
            conn.close()
