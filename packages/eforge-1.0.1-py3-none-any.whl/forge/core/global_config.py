import yaml
from pathlib import Path


def _get_nested(data: dict, key: str):
    parts = key.split(".")
    obj = data
    for p in parts:
        if isinstance(obj, dict) and p in obj:
            obj = obj[p]
        else:
            return None
    return obj


def _set_nested(data: dict, key: str, value) -> None:
    parts = key.split(".")
    obj = data
    for p in parts[:-1]:
        if p not in obj:
            obj[p] = {}
        obj = obj[p]
    obj[parts[-1]] = value


class GlobalConfig:
    """
    Reads and writes ~/.forge/config.yaml.
    Provides defaults when keys are missing.
    Used by forge new (pre-fill owner), forge doctor (validate setup).
    """

    CONFIG_PATH: Path = Path("~/.forge/config.yaml").expanduser()

    def __init__(self, data: dict | None = None) -> None:
        self._data = dict(data) if data is not None else {}

    @classmethod
    def load(cls) -> "GlobalConfig":
        """Loads from CONFIG_PATH. Returns defaults if missing."""
        path = cls.CONFIG_PATH
        if not path.exists():
            return cls(_default_data())
        try:
            raw = path.read_text()
            data = yaml.safe_load(raw)
            if not isinstance(data, dict):
                return cls(_default_data())
            return cls(_deep_merge(_default_data(), data))
        except Exception:
            return cls(_default_data())

    @classmethod
    def create_default(cls) -> "GlobalConfig":
        """Writes a default config. Called by forge doctor --fix."""
        path = cls.CONFIG_PATH
        path.parent.mkdir(parents=True, exist_ok=True)
        data = _default_data()
        path.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False))
        return cls(data)

    def get(self, key: str, default=None):
        """Dot-notation access: config.get("owner.name")"""
        val = _get_nested(self._data, key)
        return val if val is not None else default

    def set(self, key: str, value) -> None:
        """Dot-notation write + immediate save to disk."""
        _set_nested(self._data, key, value)
        path = self.CONFIG_PATH
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.dump(self._data, default_flow_style=False, sort_keys=False))


def _default_data() -> dict:
    """Load default configuration dynamically."""
    defaults = {
        "owner": {"name": "", "role": "", "github": ""},
        "projects_root": "~/Projects/",
        "defaults": {},
        "manifest_schema_version": 1,
    }
    
    # Load dynamic defaults based on environment
    import os
    import sys
    
    # Detect Python version dynamically
    defaults["defaults"]["python_min"] = f"{sys.version_info.major}.{sys.version_info.minor}"
    
    # Detect common tools dynamically
    if os.path.exists("/usr/local/bin/node") or os.path.exists("/usr/bin/node"):
        defaults["defaults"]["language"] = "typescript"
    else:
        defaults["defaults"]["language"] = "python"
    
    # Detect hosting platforms from environment
    if os.getenv("VERCEL_TOKEN") or os.getenv("VERCEL_ORG_ID"):
        defaults["defaults"]["hosting"] = "vercel"
    elif os.getenv("NETLIFY_AUTH_TOKEN"):
        defaults["defaults"]["hosting"] = "netlify"
    elif os.getenv("AWS_ACCESS_KEY_ID"):
        defaults["defaults"]["hosting"] = "aws"
    else:
        defaults["defaults"]["hosting"] = "localhost"
    
    # Detect backend platforms from environment
    if os.getenv("SUPABASE_URL") or os.getenv("SUPABASE_KEY"):
        defaults["defaults"]["backend"] = "supabase"
    elif os.getenv("FIREBASE_PROJECT_ID"):
        defaults["defaults"]["backend"] = "firebase"
    elif os.getenv("DATABASE_URL"):
        defaults["defaults"]["backend"] = "postgresql"
    else:
        defaults["defaults"]["backend"] = "sqlite"
    
    return defaults


def _deep_merge(base: dict, overlay: dict) -> dict:
    out = dict(base)
    for k, v in overlay.items():
        if k in out and isinstance(out[k], dict) and isinstance(v, dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out
