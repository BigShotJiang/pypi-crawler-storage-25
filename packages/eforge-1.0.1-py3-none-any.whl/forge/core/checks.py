from dataclasses import dataclass
from typing import Callable, Literal

from forge.core.checker_context import CheckerContext


@dataclass(kw_only=True)
class DashboardCheck(CheckerContext):
    """One dashboard row from manifest; carries :class:`CheckerContext` for infra parity."""

    label: str
    check: str
    type: str
    description: str = ""
    plugin: str = ""  # for type: plugin — references project checker


@dataclass
class CheckResult:
    label: str
    status: Literal["ok", "warn", "fail", "unknown", "error"]
    value: str | None = None
    error: str | None = None


class CheckerRegistry:
    """
    Maps check type strings to checker callables.
    Checkers register themselves — dashboard never imports checkers directly.

    Usage:
        registry = CheckerRegistry()
        registry.register("http_ping", check_http_ping)
        result = registry.run(dashboard_check)
    """

    def __init__(self) -> None:
        self._checkers: dict[str, Callable[[DashboardCheck], CheckResult]] = {}

    def register(self, type_str: str, fn: Callable[[DashboardCheck], CheckResult]) -> None:
        self._checkers[type_str] = fn

    def run(self, check: DashboardCheck) -> CheckResult:
        fn = self._checkers.get(check.type)
        if fn is None:
            return CheckResult(
                check.label,
                "unknown",
                error=f"unrecognised check type: {check.type}",
            )
        return fn(check)


# Global registry instance — checkers/__init__.py registers built-in checkers on import.
registry = CheckerRegistry()
