"""MCP Tasks implementation for INTENT-344E846B.

First-class protocol concepts for long-running operations with status tracking,
queryability, and cancellation support.
"""

import json
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from uuid import uuid4

from forge.core.path_utils import resolve_project_path

logger = logging.getLogger(__name__)


class TaskStatus(Enum):
    """Task status enumeration."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class TaskProgress:
    """Task progress information."""
    current: int = 0
    total: int = 100
    message: str = ""
    percentage: float = 0.0
    
    def __post_init__(self):
        """Calculate percentage after initialization."""
        if self.total > 0:
            self.percentage = (self.current / self.total) * 100
        else:
            self.percentage = 0.0
    
    def update(self, current: int, message: Optional[str] = None) -> None:
        """Update progress."""
        self.current = current
        if self.total > 0:
            self.percentage = (self.current / self.total) * 100
        if message is not None:
            self.message = message


@dataclass
class TaskResult:
    """Task result information."""
    success: bool = False
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    exit_code: Optional[int] = None
    duration_ms: Optional[int] = None


@dataclass
class MCPTask:
    """MCP Task representation for long-running operations."""
    id: str = field(default_factory=lambda: str(uuid4()))
    name: str = ""
    task_type: str = ""
    status: TaskStatus = TaskStatus.PENDING
    progress: TaskProgress = field(default_factory=TaskProgress)
    result: Optional[TaskResult] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    project_path: str = ""
    caller_id: Optional[str] = None  # MCP session ID
    cancellation_requested: bool = False
    
    def start(self) -> None:
        """Mark task as started."""
        self.status = TaskStatus.RUNNING
        self.started_at = time.time()
    
    def complete(self, success: bool = True, data: Optional[Dict[str, Any]] = None,
                error: Optional[str] = None, exit_code: Optional[int] = None) -> None:
        """Mark task as completed."""
        self.status = TaskStatus.COMPLETED if success else TaskStatus.FAILED
        self.completed_at = time.time()
        
        # Calculate duration
        if self.started_at:
            duration_ms = int((self.completed_at - self.started_at) * 1000)
        else:
            duration_ms = None
        
        self.result = TaskResult(
            success=success,
            data=data,
            error=error,
            exit_code=exit_code,
            duration_ms=duration_ms
        )
    
    def cancel(self) -> None:
        """Cancel the task."""
        self.status = TaskStatus.CANCELLED
        self.cancellation_requested = True
        self.completed_at = time.time()
    
    def update_progress(self, current: int, total: Optional[int] = None,
                       message: Optional[str] = None) -> None:
        """Update task progress."""
        if total is not None:
            self.progress.total = total
        
        self.progress.update(current, message)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert task to dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "task_type": self.task_type,
            "status": self.status.value,
            "progress": {
                "current": self.progress.current,
                "total": self.progress.total,
                "message": self.progress.message,
                "percentage": self.progress.percentage
            },
            "result": self.result.__dict__ if self.result else None,
            "metadata": self.metadata,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "project_path": self.project_path,
            "caller_id": self.caller_id,
            "cancellation_requested": self.cancellation_requested
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MCPTask":
        """Create task from dictionary."""
        task = cls(
            id=data["id"],
            name=data["name"],
            task_type=data["task_type"],
            status=TaskStatus(data["status"]),
            project_path=data.get("project_path", ""),
            caller_id=data.get("caller_id")
        )
        
        # Restore progress
        progress_data = data.get("progress", {})
        task.progress = TaskProgress(
            current=progress_data.get("current", 0),
            total=progress_data.get("total", 100),
            message=progress_data.get("message", "")
        )
        
        # Restore result
        if data.get("result"):
            result_data = data["result"]
            task.result = TaskResult(**result_data)
        
        # Restore timestamps
        task.created_at = data.get("created_at", time.time())
        task.started_at = data.get("started_at")
        task.completed_at = data.get("completed_at")
        
        # Restore metadata
        task.metadata = data.get("metadata", {})
        
        return task


class TaskManager:
    """Manages MCP tasks with persistence and query capabilities."""
    
    def __init__(self, project_path: Path):
        self.project_path = project_path
        self.tasks_dir = project_path / ".forge" / "tasks"
        self.tasks_dir.mkdir(parents=True, exist_ok=True)
        
        self.tasks_file = self.tasks_dir / "tasks.jsonl"
        self._tasks: Dict[str, MCPTask] = {}
        
        self._load_tasks()
    
    def _load_tasks(self) -> None:
        """Load tasks from storage."""
        try:
            if self.tasks_file.exists():
                with open(self.tasks_file, 'r') as f:
                    for line in f:
                        try:
                            data = json.loads(line.strip())
                            task = MCPTask.from_dict(data)
                            self._tasks[task.id] = task
                        except (json.JSONDecodeError, KeyError):
                            continue
            
            logger.info(f"Loaded {len(self._tasks)} tasks from storage")
            
        except Exception as e:
            logger.error(f"Failed to load tasks: {e}")
    
    def _save_tasks(self) -> None:
        """Save tasks to storage."""
        try:
            with open(self.tasks_file, 'w') as f:
                for task in self._tasks.values():
                    f.write(json.dumps(task.to_dict()) + '\n')
        except Exception as e:
            logger.error(f"Failed to save tasks: {e}")
    
    def create_task(self, name: str, task_type: str, metadata: Optional[Dict[str, Any]] = None,
                   caller_id: Optional[str] = None) -> MCPTask:
        """Create a new task."""
        task = MCPTask(
            name=name,
            task_type=task_type,
            metadata=metadata or {},
            project_path=str(self.project_path),
            caller_id=caller_id
        )
        
        self._tasks[task.id] = task
        self._save_tasks()
        
        logger.info(f"Created task {task.id}: {name}")
        return task
    
    def get_task(self, task_id: str) -> Optional[MCPTask]:
        """Get a task by ID."""
        return self._tasks.get(task_id)
    
    def list_tasks(self, status_filter: Optional[TaskStatus] = None,
                   caller_filter: Optional[str] = None,
                   limit: int = 100) -> List[MCPTask]:
        """List tasks with optional filtering."""
        tasks = list(self._tasks.values())
        
        # Apply filters
        if status_filter:
            tasks = [t for t in tasks if t.status == status_filter]
        
        if caller_filter:
            tasks = [t for t in tasks if t.caller_id == caller_filter]
        
        # Sort by creation time (newest first)
        tasks.sort(key=lambda t: t.created_at, reverse=True)
        
        return tasks[:limit]
    
    def update_task(self, task_id: str, **updates) -> bool:
        """Update a task."""
        task = self._tasks.get(task_id)
        if not task:
            return False
        
        for key, value in updates.items():
            if hasattr(task, key):
                setattr(task, key, value)
        
        self._save_tasks()
        return True
    
    def cancel_task(self, task_id: str) -> bool:
        """Cancel a task."""
        task = self._tasks.get(task_id)
        if not task:
            return False
        
        task.cancel()
        self._save_tasks()
        logger.info(f"Cancelled task {task_id}")
        return True
    
    def cleanup_completed_tasks(self, max_age_hours: int = 24) -> int:
        """Clean up old completed tasks."""
        cutoff_time = time.time() - (max_age_hours * 3600)
        
        tasks_to_remove = []
        for task_id, task in self._tasks.items():
            if (task.status in [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED] and
                task.completed_at and task.completed_at < cutoff_time):
                tasks_to_remove.append(task_id)
        
        for task_id in tasks_to_remove:
            del self._tasks[task_id]
        
        if tasks_to_remove:
            self._save_tasks()
            logger.info(f"Cleaned up {len(tasks_to_remove)} old tasks")
        
        return len(tasks_to_remove)
    
    def get_task_stats(self) -> Dict[str, Any]:
        """Get task statistics."""
        status_counts = {}
        type_counts = {}
        
        for task in self._tasks.values():
            status_counts[task.status.value] = status_counts.get(task.status.value, 0) + 1
            type_counts[task.task_type] = type_counts.get(task.task_type, 0) + 1
        
        return {
            "total_tasks": len(self._tasks),
            "status_distribution": status_counts,
            "type_distribution": type_counts,
            "project_path": str(self.project_path)
        }


# Global task managers
_task_managers: Dict[str, TaskManager] = {}


def get_task_manager(project_path: Path) -> TaskManager:
    """Get or create a task manager for a project."""
    project_key = str(project_path.resolve())
    if project_key not in _task_managers:
        _task_managers[project_key] = TaskManager(project_path)
    return _task_managers[project_key]


def create_task(name: str, task_type: str, metadata: Optional[Dict[str, Any]] = None,
               project_path: Optional[str] = None, caller_id: Optional[str] = None) -> MCPTask:
    """Create a new MCP task."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    manager = get_task_manager(Path(project_path))
    return manager.create_task(name, task_type, metadata, caller_id)


def get_task(task_id: str, project_path: Optional[str] = None) -> Optional[MCPTask]:
    """Get a task by ID."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    manager = get_task_manager(Path(project_path))
    return manager.get_task(task_id)


def list_tasks(status_filter: Optional[str] = None, caller_filter: Optional[str] = None,
              limit: int = 100, project_path: Optional[str] = None) -> List[MCPTask]:
    """List tasks with optional filtering."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    manager = get_task_manager(Path(project_path))
    
    # Convert status filter string to enum
    status_enum = None
    if status_filter:
        try:
            status_enum = TaskStatus(status_filter)
        except ValueError:
            pass
    
    return manager.list_tasks(status_enum, caller_filter, limit)


def cancel_task(task_id: str, project_path: Optional[str] = None) -> bool:
    """Cancel a task."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    manager = get_task_manager(Path(project_path))
    return manager.cancel_task(task_id)


class TaskContext:
    """Context manager for running tasks with automatic progress tracking."""
    
    def __init__(self, task: MCPTask):
        self.task = task
    
    def __enter__(self) -> "TaskContext":
        """Start the task."""
        self.task.start()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Complete the task."""
        if exc_type is None:
            self.task.complete(success=True)
        else:
            error_msg = str(exc_val) if exc_val else "Unknown error"
            self.task.complete(success=False, error=error_msg)
    
    def update_progress(self, current: int, total: Optional[int] = None,
                       message: Optional[str] = None) -> None:
        """Update task progress."""
        self.task.update_progress(current, total, message)
    
    def check_cancellation(self) -> bool:
        """Check if cancellation was requested."""
        return self.task.cancellation_requested


def run_task(name: str, task_type: str, func, *args, metadata: Optional[Dict[str, Any]] = None,
            project_path: Optional[str] = None, caller_id: Optional[str] = None, **kwargs) -> MCPTask:
    """Run a function as a task with automatic progress tracking."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    # Create task
    task = create_task(name, task_type, metadata, project_path, caller_id)
    
    # Run function in task context
    with TaskContext(task):
        try:
            # If function accepts task_context, pass it
            import inspect
            sig = inspect.signature(func)
            if 'task_context' in sig.parameters:
                result = func(*args, task_context=self, **kwargs)
            else:
                result = func(*args, **kwargs)
            
            # Store result in task
            if isinstance(result, dict):
                task.result.data = result
            else:
                task.result.data = {"result": result}
                
        except Exception as e:
            logger.error(f"Task {task.id} failed: {e}")
            raise
    
    return task


__all__ = [
    "TaskStatus",
    "TaskProgress",
    "TaskResult",
    "MCPTask",
    "TaskManager",
    "TaskContext",
    "get_task_manager",
    "create_task",
    "get_task",
    "list_tasks",
    "cancel_task",
    "run_task"
]
