"""Domain integration engine for proper Forge domain system integration.

Integrates semantic analysis, build-aware analysis, and contract validation
with Forge's domain system using proper oriented programming patterns.
"""

from pathlib import Path
from typing import Dict, List, Optional, Any, Set, Tuple
from dataclasses import dataclass
from collections import defaultdict
import logging

from forge.core.semantic_analyzer import SemanticAnalyzer, ImportDependency, ModuleExport
from forge.core.build_aware_analyzer import BuildAwareAnalyzer, BuildConfiguration
from forge.core.import_parser import ImportStatement
from forge.contracts.import_resolution import ImportResolutionContract, StackAgnosticResolver

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class DomainBoundary:
    """Represents a domain boundary rule."""
    domain_name: str
    path_patterns: List[str]
    allowed_imports: Set[str]
    forbidden_imports: Set[str]
    export_requirements: Set[str]


@dataclass(frozen=True)
class ContractViolation:
    """Represents a contract validation violation."""
    violation_type: str
    source_file: Path
    target_module: str
    description: str
    severity: str
    suggested_fix: str


class DomainIntegration:
    """Integrates analysis systems with Forge's domain system."""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.semantic_analyzer = SemanticAnalyzer(project_root)
        self.build_analyzer = BuildAwareAnalyzer(project_root)
        self.domain_boundaries: Dict[str, DomainBoundary] = {}
        self.contract_violations: List[ContractViolation] = []
        self._load_domain_configuration()
    
    def _load_domain_configuration(self):
        """Load domain configuration from manifest or config files."""
        # Load from .forge/manifest.yaml domain definitions
        manifest_path = self.project_root / ".forge" / "manifest.yaml"
        if manifest_path.exists():
            self._load_domains_from_manifest(manifest_path)
        
        # Load domain boundaries from glove configuration
        glove_config = self._load_glove_config()
        if glove_config:
            self._load_domains_from_glove(glove_config)
        
        # Set up default domains if none found
        if not self.domain_boundaries:
            self._setup_default_domains()
    
    def _load_domains_from_manifest(self, manifest_path: Path):
        """Load domain definitions from manifest.yaml."""
        try:
            import yaml
            with open(manifest_path) as f:
                manifest = yaml.load(f, Loader=yaml.SafeLoader)
            
            domains = manifest.get('domains', {})
            for domain_name, domain_config in domains.items():
                self.domain_boundaries[domain_name] = DomainBoundary(
                    domain_name=domain_name,
                    path_patterns=domain_config.get('path_patterns', []),
                    allowed_imports=set(domain_config.get('allowed_imports', [])),
                    forbidden_imports=set(domain_config.get('forbidden_imports', [])),
                    export_requirements=set(domain_config.get('export_requirements', []))
                )
        except Exception as e:
            logger.warning(f"Failed to load domains from manifest: {e}")
    
    def _load_glove_config(self) -> Optional[Dict[str, Any]]:
        """Load glove configuration for domain definitions."""
        glove_paths = [
            self.project_root / ".forge" / "glove.yaml",
            self.project_root / "glove.yaml"
        ]
        
        for glove_path in glove_paths:
            if glove_path.exists():
                try:
                    import yaml
                    with open(glove_path) as f:
                        return yaml.load(f, Loader=yaml.SafeLoader)
                except Exception as e:
                    logger.warning(f"Failed to load glove config: {e}")
        
        return None
    
    def _load_domains_from_glove(self, glove_config: Dict[str, Any]):
        """Load domain definitions from glove configuration."""
        domains = glove_config.get('domains', {})
        for domain_name, domain_config in domains.items():
            self.domain_boundaries[domain_name] = DomainBoundary(
                domain_name=domain_name,
                path_patterns=domain_config.get('path_patterns', []),
                allowed_imports=set(domain_config.get('allowed_imports', [])),
                forbidden_imports=set(domain_config.get('forbidden_imports', [])),
                export_requirements=set(domain_config.get('export_requirements', []))
            )
    
    def _setup_default_domains(self):
        """Set up default domain boundaries."""
        default_domains = {
            'core': DomainBoundary(
                domain_name='core',
                path_patterns=['forge/core/', 'src/core/'],
                allowed_imports=set(),
                forbidden_imports={'src/components/', 'src/ui/', 'src/views/'},
                export_requirements={'interface', 'contract', 'abstract'}
            ),
            'commands': DomainBoundary(
                domain_name='commands',
                path_patterns=['forge/commands/', 'src/commands/'],
                allowed_imports={'forge/core/', 'src/core/'},
                forbidden_imports={'src/ui/', 'src/views/'},
                export_requirements={'command', 'handler'}
            ),
            'ui': DomainBoundary(
                domain_name='ui',
                path_patterns=['src/ui/', 'src/components/', 'src/views/'],
                allowed_imports={'src/core/', 'src/utils/'},
                forbidden_imports={'forge/commands/'},
                export_requirements={'component', 'view', 'ui'}
            ),
            'utils': DomainBoundary(
                domain_name='utils',
                path_patterns=['src/utils/', 'forge/utils/'],
                allowed_imports=set(),
                forbidden_imports={'src/ui/', 'src/views/', 'forge/commands/'},
                export_requirements={'util', 'helper', 'function'}
            )
        }
        
        self.domain_boundaries.update(default_domains)
    
    def get_domain_for_path(self, file_path: Path) -> Optional[str]:
        """Get domain name for a file path."""
        relative_path = file_path.relative_to(self.project_root)
        path_str = str(relative_path)
        
        for domain_name, boundary in self.domain_boundaries.items():
            for pattern in boundary.path_patterns:
                if path_str.startswith(pattern):
                    return domain_name
        
        return None
    
    def validate_domain_boundaries(self, file_path: Path, dependencies: List[ImportDependency]) -> List[ContractViolation]:
        """Validate that imports respect domain boundaries."""
        violations = []
        source_domain = self.get_domain_for_path(file_path)
        
        if not source_domain:
            return violations
        
        source_boundary = self.domain_boundaries[source_domain]
        
        for dep in dependencies:
            # Resolve target to file path if possible
            target_path = self._resolve_module_to_path(dep.target_module)
            if not target_path:
                continue
            
            target_domain = self.get_domain_for_path(target_path)
            if not target_domain:
                continue
            
            # Check forbidden imports
            if any(target_path.match(pattern) for pattern in source_boundary.forbidden_imports):
                violations.append(ContractViolation(
                    violation_type='domain_boundary_violation',
                    source_file=file_path,
                    target_module=dep.target_module,
                    description=f"Import from forbidden domain '{target_domain}' to '{source_domain}'",
                    severity='error',
                    suggested_fix=f"Move import to allowed domain or refactor architecture"
                ))
            
            # Check allowed imports (if specified)
            if source_boundary.allowed_imports:
                if not any(target_path.match(pattern) for pattern in source_boundary.allowed_imports):
                    violations.append(ContractViolation(
                        violation_type='unauthorized_import',
                        source_file=file_path,
                        target_module=dep.target_module,
                        description=f"Import from '{target_domain}' not allowed in '{source_domain}' domain",
                        severity='warning',
                        suggested_fix=f"Add import to allowed_imports or move to appropriate domain"
                    ))
        
        return violations
    
    def validate_export_contracts(self, file_path: Path, exports: List[ModuleExport]) -> List[ContractViolation]:
        """Validate that exports meet domain contract requirements."""
        violations = []
        domain = self.get_domain_for_path(file_path)
        
        if not domain:
            return violations
        
        boundary = self.domain_boundaries[domain]
        
        # Check if file exports required contract types
        export_types = {exp.export_type for exp in exports}
        required_types = boundary.export_requirements
        
        for required_type in required_types:
            if required_type not in export_types:
                violations.append(ContractViolation(
                    violation_type='missing_export_contract',
                    source_file=file_path,
                    target_module='',
                    description=f"Domain '{domain}' requires export of type '{required_type}'",
                    severity='error',
                    suggested_fix=f"Add required export or move file to appropriate domain"
                ))
        
        return violations
    
    def _resolve_module_to_path(self, module_name: str) -> Optional[Path]:
        """Resolve module name to file path using build configuration."""
        return self.build_analyzer.resolve_import_with_config(module_name, self.project_root)
    
    def integrate_semantic_analysis(self, file_path: Path, content: str) -> Dict[str, Any]:
        """Integrate semantic analysis with domain validation."""
        # Perform semantic analysis
        semantic_result = self.semantic_analyzer.analyze_file(file_path, content)
        
        if 'error' in semantic_result:
            return semantic_result
        
        # Convert to domain-aware format
        imports = semantic_result['imports']
        exports = semantic_result['exports']
        
        # Validate domain boundaries
        boundary_violations = self.validate_domain_boundaries(file_path, imports)
        
        # Validate export contracts
        export_violations = self.validate_export_contracts(file_path, exports)
        
        # Detect circular dependencies
        self.semantic_analyzer.detect_circular_dependencies()
        
        return {
            'semantic_analysis': semantic_result,
            'domain_validation': {
                'boundary_violations': boundary_violations,
                'export_violations': export_violations,
                'domain': self.get_domain_for_path(file_path)
            },
            'circular_dependencies': self.semantic_analyzer.detect_circular_dependencies(),
            'build_aware_context': self.build_analyzer.get_analysis_summary()
        }
    
    def create_contract_validator(self) -> 'ContractValidator':
        """Create a contract validator instance."""
        return ContractValidator(self)
    
    def get_domain_analysis_summary(self) -> Dict[str, Any]:
        """Get comprehensive domain analysis summary."""
        return {
            'domains': {
                name: {
                    'path_patterns': boundary.path_patterns,
                    'allowed_imports': list(boundary.allowed_imports),
                    'forbidden_imports': list(boundary.forbidden_imports),
                    'export_requirements': list(boundary.export_requirements)
                }
                for name, boundary in self.domain_boundaries.items()
            },
            'total_violations': len(self.contract_violations),
            'violations_by_type': defaultdict(list),
            'build_configuration': self.build_analyzer.get_analysis_summary(),
            'semantic_analysis': self.semantic_analyzer.get_dependency_analysis()
        }


class ContractValidator:
    """Validates contracts and interfaces across domains."""
    
    def __init__(self, domain_integration: DomainIntegration):
        self.domain_integration = domain_integration
        self.interface_registry: Dict[str, Dict[str, Any]] = {}
        self.contract_registry: Dict[str, Dict[str, Any]] = {}
    
    def register_interface(self, interface_name: str, interface_def: Dict[str, Any]):
        """Register an interface definition."""
        self.interface_registry[interface_name] = interface_def
    
    def register_contract(self, contract_name: str, contract_def: Dict[str, Any]):
        """Register a contract definition."""
        self.contract_registry[contract_name] = contract_def
    
    def validate_interface_compliance(self, file_path: Path, exports: List[ModuleExport]) -> List[ContractViolation]:
        """Validate that exports comply with registered interfaces."""
        violations = []
        
        for export in exports:
            # Check if export matches any registered interface
            for interface_name, interface_def in self.interface_registry.items():
                if self._export_matches_interface(export, interface_def):
                    violations.extend(self._validate_export_against_interface(export, interface_def, interface_name))
        
        return violations
    
    def _export_matches_interface(self, export: ModuleExport, interface_def: Dict[str, Any]) -> bool:
        """Check if export matches interface definition."""
        # Simplified matching - in practice would be more sophisticated
        required_type = interface_def.get('export_type')
        return export.export_type == required_type
    
    def _validate_export_against_interface(self, export: ModuleExport, interface_def: Dict[str, Any], interface_name: str) -> List[ContractViolation]:
        """Validate export against specific interface requirements."""
        violations = []
        
        # Check required methods
        required_methods = interface_def.get('required_methods', [])
        # In practice, would parse the actual export to check methods
        
        # Check required properties
        required_properties = interface_def.get('required_properties', [])
        # In practice, would parse the actual export to check properties
        
        return violations
    
    def validate_contract_implementation(self, file_path: Path, content: str) -> List[ContractViolation]:
        """Validate that file implements required contracts."""
        violations = []
        domain = self.domain_integration.get_domain_for_path(file_path)
        
        if not domain:
            return violations
        
        # Get contracts for this domain
        domain_contracts = [
            name for name, contract in self.contract_registry.items()
            if contract.get('domain') == domain
        ]
        
        # Validate each contract
        for contract_name in domain_contracts:
            contract_def = self.contract_registry[contract_name]
            violations.extend(self._validate_file_against_contract(file_path, content, contract_def, contract_name))
        
        return violations
    
    def _validate_file_against_contract(self, file_path: Path, content: str, contract_def: Dict[str, Any], contract_name: str) -> List[ContractViolation]:
        """Validate file against a specific contract."""
        violations = []
        
        # Check required imports
        required_imports = contract_def.get('required_imports', [])
        # In practice, would parse imports from content
        
        # Check required exports
        required_exports = contract_def.get('required_exports', [])
        # In practice, would parse exports from content
        
        # Check implementation patterns
        implementation_patterns = contract_def.get('implementation_patterns', [])
        # In practice, would analyze AST for patterns
        
        return violations
