"""Dimstack/Comburiscope Mathematical Pipeline (INTENT-59BDA019).

Recursive semantic canonicalization system that decomposes information into
invariant atomics and performs truth-preserving transformations.
"""

import json
import logging
import math
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import uuid4

import numpy as np

from forge.core.path_utils import resolve_project_path

logger = logging.getLogger(__name__)


class TruthLayer(Enum):
    """Multi-layer truth representation (A/B/C truth layers)."""
    SCALAR = "A"  # Base scalar truths, contains no other layers
    VECTOR = "B"  # Vector truths, contains scalar layer
    STRUCTURAL = "C"  # Structural truths, contains both scalar and vector layers


@dataclass
class InvariantAtomic:
    """An invariant atomic unit of semantic information."""
    id: str = field(default_factory=lambda: str(uuid4()))
    content: str = ""
    semantic_type: str = ""  # "concept", "relation", "attribute", "operation"
    truth_layer: TruthLayer = TruthLayer.SCALAR
    invariants: Dict[str, Any] = field(default_factory=dict)
    coordinate: Optional[List[float]] = None
    factorization: Dict[str, float] = field(default_factory=dict)
    canonical_form: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    
    def __post_init__(self):
        """Post-initialization processing."""
        if self.canonical_form is None:
            self.canonical_form = self._compute_canonical_form()
    
    def _compute_canonical_form(self) -> str:
        """Compute canonical form of the atomic."""
        # Simple canonicalization: lowercase, normalize whitespace
        normalized = " ".join(self.content.lower().strip().split())
        return f"{self.semantic_type}:{normalized}"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage."""
        return {
            "id": self.id,
            "content": self.content,
            "semantic_type": self.semantic_type,
            "truth_layer": self.truth_layer.value,
            "invariants": self.invariants,
            "coordinate": self.coordinate,
            "factorization": self.factorization,
            "canonical_form": self.canonical_form,
            "metadata": self.metadata,
            "timestamp": self.timestamp
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "InvariantAtomic":
        """Create from dictionary."""
        # Convert truth_layer back to enum
        if "truth_layer" in data:
            data["truth_layer"] = TruthLayer(data["truth_layer"])
        return cls(**data)


@dataclass
class FactorizedCoordinate:
    """A point in factorized coordinate space."""
    scalar_coords: List[float] = field(default_factory=list)
    vector_coords: List[float] = field(default_factory=list)
    structural_coords: List[float] = field(default_factory=list)
    dimension: int = 0
    
    def __post_init__(self):
        """Post-initialization processing."""
        self.dimension = max(len(self.scalar_coords), len(self.vector_coords), len(self.structural_coords))
    
    def to_vector(self, layer: TruthLayer) -> List[float]:
        """Get coordinate vector for specific truth layer."""
        if layer == TruthLayer.SCALAR:
            return self.scalar_coords
        elif layer == TruthLayer.VECTOR:
            return self.vector_coords
        elif layer == TruthLayer.STRUCTURAL:
            return self.structural_coords
        else:
            return []
    
    def distance_to(self, other: "FactorizedCoordinate", layer: TruthLayer) -> float:
        """Calculate Euclidean distance to another coordinate in specified layer."""
        vec1 = self.to_vector(layer)
        vec2 = other.to_vector(layer)
        
        if len(vec1) != len(vec2):
            return float('inf')
        
        return math.sqrt(sum((a - b) ** 2 for a, b in zip(vec1, vec2)))


class SemanticDecomposer(ABC):
    """Abstract base for semantic decomposition algorithms."""
    
    @abstractmethod
    def decompose(self, content: str) -> List[InvariantAtomic]:
        """Decompose content into invariant atomics."""
        pass
    
    @abstractmethod
    def extract_semantic_type(self, content: str) -> str:
        """Extract semantic type from content."""
        pass


class SimpleSemanticDecomposer(SemanticDecomposer):
    """Simple semantic decomposition using pattern matching and heuristics."""
    
    def __init__(self):
        # Semantic type patterns
        self.concept_patterns = [
            r"\b(is|are|was|were|becomes|became)\b",
            r"\b(define|definition|concept|idea|notion)\b"
        ]
        
        self.relation_patterns = [
            r"\b(relates|connects|links|depends|requires)\b",
            r"\b(has|contains|includes|involves)\b"
        ]
        
        self.attribute_patterns = [
            r"\b(property|attribute|characteristic|feature)\b",
            r"\b(color|size|shape|type|kind)\b"
        ]
        
        self.operation_patterns = [
            r"\b(create|build|make|generate|produce)\b",
            r"\b(transform|convert|change|modify)\b"
        ]
    
    def decompose(self, content: str) -> List[InvariantAtomic]:
        """Decompose content into invariant atomics."""
        import re
        
        atomics = []
        
        # Split content into semantic units
        sentences = re.split(r'[.!?]+', content)
        sentences = [s.strip() for s in sentences if s.strip()]
        
        for sentence in sentences:
            semantic_type = self.extract_semantic_type(sentence)
            
            # Extract key concepts and relations
            words = self._extract_key_words(sentence)
            
            for word in words:
                atomic = InvariantAtomic(
                    content=word,
                    semantic_type=semantic_type,
                    truth_layer=self._determine_truth_layer(word, semantic_type),
                    invariants=self._extract_invariants(word, semantic_type)
                )
                atomics.append(atomic)
        
        return atomics
    
    def extract_semantic_type(self, content: str) -> str:
        """Extract semantic type from content."""
        import re
        
        content_lower = content.lower()
        
        # Check patterns in order of specificity
        if any(re.search(pattern, content_lower) for pattern in self.operation_patterns):
            return "operation"
        elif any(re.search(pattern, content_lower) for pattern in self.relation_patterns):
            return "relation"
        elif any(re.search(pattern, content_lower) for pattern in self.attribute_patterns):
            return "attribute"
        else:
            return "concept"
    
    def _extract_key_words(self, content: str) -> List[str]:
        """Extract key words from content."""
        import re
        
        # Remove stop words and extract meaningful terms
        stop_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'of', 'with', 'by', 'as', 'is', 'are', 'was', 'were', 'be', 'been',
            'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
            'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these',
            'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they'
        }
        
        words = re.findall(r'\b\w+\b', content.lower())
        key_words = [w for w in words if w not in stop_words and len(w) > 2]
        
        return key_words
    
    def _determine_truth_layer(self, word: str, semantic_type: str) -> TruthLayer:
        """Determine truth layer based on word and semantic type."""
        # Simple heuristics for layer determination
        if semantic_type == "operation":
            return TruthLayer.STRUCTURAL
        elif semantic_type == "relation":
            return TruthLayer.VECTOR
        else:
            return TruthLayer.SCALAR
    
    def _extract_invariants(self, word: str, semantic_type: str) -> Dict[str, Any]:
        """Extract invariant properties from word."""
        invariants = {}
        
        # Length invariant
        invariants["length"] = len(word)
        
        # Character composition
        invariants["alpha_ratio"] = sum(c.isalpha() for c in word) / len(word)
        invariants["vowel_ratio"] = sum(c.lower() in 'aeiou' for c in word) / len(word)
        
        # Semantic invariants
        invariants["semantic_type"] = semantic_type
        invariants["is_compound"] = '_' in word or '-' in word
        
        return invariants


class ComburiscopeEngine:
    """Comburiscope canonicalization engine - RREF for semantic matrices."""
    
    def __init__(self, decomposer: SemanticDecomposer):
        self.decomposer = decomposer
        self.canonical_cache: Dict[str, InvariantAtomic] = {}
    
    def canonicalize(self, content: str) -> List[InvariantAtomic]:
        """Canonicalize content using comburiscope process."""
        # Decompose into atomics
        atomics = self.decomposer.decompose(content)
        
        # Apply canonicalization transformations
        canonical_atomics = []
        for atomic in atomics:
            canonical_atomic = self._apply_canonicalization(atomic)
            canonical_atomics.append(canonical_atomic)
        
        # Remove redundancies and expose core structure
        core_atomics = self._burn_redundant_paths(canonical_atomics)
        
        return core_atomics
    
    def _apply_canonicalization(self, atomic: InvariantAtomic) -> InvariantAtomic:
        """Apply canonicalization transformations to atomic."""
        # Check cache first
        cache_key = atomic.canonical_form
        if cache_key in self.canonical_cache:
            return self.canonical_cache[cache_key]
        
        # Apply transformations
        canonical = InvariantAtomic(
            content=atomic.content,
            semantic_type=atomic.semantic_type,
            truth_layer=atomic.truth_layer,
            invariants=atomic.invariants.copy()
        )
        
        # Normalize coordinates
        canonical.coordinate = self._normalize_coordinates(atomic)
        
        # Update factorization
        canonical.factorization = self._compute_factorization(canonical)
        
        # Cache result
        self.canonical_cache[cache_key] = canonical
        
        return canonical
    
    def _normalize_coordinates(self, atomic: InvariantAtomic) -> List[float]:
        """Normalize atomic coordinates."""
        # Simple coordinate normalization based on invariants
        coords = [
            atomic.invariants.get("length", 0) / 20.0,  # Normalized length
            atomic.invariants.get("alpha_ratio", 0),
            atomic.invariants.get("vowel_ratio", 0),
            1.0 if atomic.invariants.get("is_compound", False) else 0.0
        ]
        
        # Normalize to unit vector
        norm = math.sqrt(sum(c * c for c in coords))
        if norm > 0:
            coords = [c / norm for c in coords]
        
        return coords
    
    def _compute_factorization(self, atomic: InvariantAtomic) -> Dict[str, float]:
        """Compute factorization weights for atomic."""
        factorization = {}
        
        # Factor based on semantic type
        type_weights = {
            "concept": 0.8,
            "relation": 0.6,
            "attribute": 0.4,
            "operation": 0.9
        }
        
        factorization["semantic_weight"] = type_weights.get(atomic.semantic_type, 0.5)
        
        # Factor based on truth layer
        layer_weights = {
            TruthLayer.SCALAR: 0.3,
            TruthLayer.VECTOR: 0.6,
            TruthLayer.STRUCTURAL: 0.9
        }
        
        factorization["layer_weight"] = layer_weights.get(atomic.truth_layer, 0.5)
        
        # Combined factorization
        factorization["combined"] = (
            factorization["semantic_weight"] * factorization["layer_weight"]
        )
        
        return factorization
    
    def _burn_redundant_paths(self, atomics: List[InvariantAtomic]) -> List[InvariantAtomic]:
        """Remove redundant relational paths and expose core structure."""
        # Group by canonical form
        canonical_groups = {}
        for atomic in atomics:
            key = atomic.canonical_form
            if key not in canonical_groups:
                canonical_groups[key] = []
            canonical_groups[key].append(atomic)
        
        # Keep only the highest-weight atomic from each group
        core_atomics = []
        for group in canonical_groups.values():
            if len(group) == 1:
                core_atomics.append(group[0])
            else:
                # Select atomic with highest combined factorization
                best = max(group, key=lambda a: a.factorization.get("combined", 0))
                core_atomics.append(best)
        
        return core_atomics


class DimstackPipeline:
    """Main Dimstack pipeline for semantic canonicalization."""
    
    def __init__(self, project_path: Path, decomposer: Optional[SemanticDecomposer] = None):
        self.project_path = project_path
        self.decomposer = decomposer or SimpleSemanticDecomposer()
        self.comburiscope = ComburiscopeEngine(self.decomposer)
        
        # Storage
        self.canonical_dir = project_path / ".forge" / "dimstack"
        self.canonical_dir.mkdir(parents=True, exist_ok=True)
        
        self.canonical_cache_file = self.canonical_dir / "canonical.jsonl"
        self.coordinate_space_file = self.canonical_dir / "coordinates.json"
        
        # Cache
        self._canonical_cache: Dict[str, List[InvariantAtomic]] = {}
        self._coordinate_space: Dict[str, FactorizedCoordinate] = {}
        
        self._load_cache()
    
    def _load_cache(self) -> None:
        """Load existing cache from storage."""
        try:
            # Load canonical cache
            if self.canonical_cache_file.exists():
                with open(self.canonical_cache_file, 'r') as f:
                    for line in f:
                        try:
                            data = json.loads(line.strip())
                            content = data["content"]
                            atomics = [InvariantAtomic.from_dict(a) for a in data["atomics"]]
                            self._canonical_cache[content] = atomics
                        except (json.JSONDecodeError, KeyError):
                            continue
            
            # Load coordinate space
            if self.coordinate_space_file.exists():
                with open(self.coordinate_space_file, 'r') as f:
                    data = json.load(f)
                    for key, coord_data in data.items():
                        coord = FactorizedCoordinate(**coord_data)
                        self._coordinate_space[key] = coord
            
            logger.info(f"Loaded {len(self._canonical_cache)} canonicalizations")
            
        except Exception as e:
            logger.error(f"Failed to load dimstack cache: {e}")
    
    def _save_cache(self) -> None:
        """Save cache to storage."""
        try:
            # Save canonical cache
            with open(self.canonical_cache_file, 'w') as f:
                for content, atomics in self._canonical_cache.items():
                    data = {
                        "content": content,
                        "atomics": [a.to_dict() for a in atomics]
                    }
                    f.write(json.dumps(data) + '\n')
            
            # Save coordinate space
            with open(self.coordinate_space_file, 'w') as f:
                data = {k: v.__dict__ for k, v in self._coordinate_space.items()}
                json.dump(data, f, indent=2)
                
        except Exception as e:
            logger.error(f"Failed to save dimstack cache: {e}")
    
    def canonicalize_content(self, content: str) -> List[InvariantAtomic]:
        """Canonicalize content using dimstack pipeline."""
        # Check cache first
        cache_key = content.strip().lower()
        if cache_key in self._canonical_cache:
            return self._canonical_cache[cache_key]
        
        # Apply comburiscope canonicalization
        atomics = self.comburiscope.canonicalize(content)
        
        # Cache result
        self._canonical_cache[cache_key] = atomics
        
        # Save cache periodically
        if len(self._canonical_cache) % 10 == 0:
            self._save_cache()
        
        return atomics
    
    def compute_factorized_coordinates(self, atomics: List[InvariantAtomic]) -> Dict[str, FactorizedCoordinate]:
        """Compute factorized coordinates for atomics."""
        coordinates = {}
        
        for atomic in atomics:
            # Initialize coordinate
            coord = FactorizedCoordinate()
            
            # Assign to appropriate layer
            if atomic.truth_layer == TruthLayer.SCALAR:
                coord.scalar_coords = atomic.coordinate or []
            elif atomic.truth_layer == TruthLayer.VECTOR:
                coord.vector_coords = atomic.coordinate or []
            elif atomic.truth_layer == TruthLayer.STRUCTURAL:
                coord.structural_coords = atomic.coordinate or []
            
            coordinates[atomic.id] = coord
        
        return coordinates
    
    def find_semantic_equivalence(self, content1: str, content2: str, 
                                 layer: TruthLayer = TruthLayer.STRUCTURAL,
                                 threshold: float = 0.1) -> bool:
        """Find semantic equivalence between two contents."""
        # Canonicalize both contents
        atomics1 = self.canonicalize_content(content1)
        atomics2 = self.canonicalize_content(content2)
        
        # Compute coordinates
        coords1 = self.compute_factorized_coordinates(atomics1)
        coords2 = self.compute_factorized_coordinates(atomics2)
        
        # Find minimum distance between any pair
        min_distance = float('inf')
        for coord1 in coords1.values():
            for coord2 in coords2.values():
                distance = coord1.distance_to(coord2, layer)
                min_distance = min(min_distance, distance)
        
        return min_distance <= threshold
    
    def extract_invariant_atomics(self, content: str, 
                                 semantic_type_filter: Optional[str] = None,
                                 truth_layer_filter: Optional[TruthLayer] = None) -> List[InvariantAtomic]:
        """Extract invariant atomics with optional filtering."""
        atomics = self.canonicalize_content(content)
        
        # Apply filters
        if semantic_type_filter:
            atomics = [a for a in atomics if a.semantic_type == semantic_type_filter]
        
        if truth_layer_filter:
            atomics = [a for a in atomics if a.truth_layer == truth_layer_filter]
        
        return atomics
    
    def get_pipeline_stats(self) -> Dict[str, Any]:
        """Get pipeline statistics."""
        total_atomics = sum(len(atomics) for atomics in self._canonical_cache.values())
        
        layer_counts = {}
        type_counts = {}
        
        for atomics in self._canonical_cache.values():
            for atomic in atomics:
                layer_counts[atomic.truth_layer.value] = layer_counts.get(atomic.truth_layer.value, 0) + 1
                type_counts[atomic.semantic_type] = type_counts.get(atomic.semantic_type, 0) + 1
        
        return {
            "total_canonicalizations": len(self._canonical_cache),
            "total_atomics": total_atomics,
            "layer_distribution": layer_counts,
            "type_distribution": type_counts,
            "cache_size": len(self.comburiscope.canonical_cache),
            "project_path": str(self.project_path)
        }


# Global pipeline instances
_pipelines: Dict[str, DimstackPipeline] = {}


def get_dimstack_pipeline(project_path: Path, 
                        decomposer: Optional[SemanticDecomposer] = None) -> DimstackPipeline:
    """Get or create a dimstack pipeline for a project."""
    project_key = str(project_path.resolve())
    if project_key not in _pipelines:
        _pipelines[project_key] = DimstackPipeline(project_path, decomposer)
    return _pipelines[project_key]


def canonicalize_forge_content(content: str, project_path: Optional[str] = None) -> List[InvariantAtomic]:
    """Canonicalize Forge content using dimstack pipeline."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    pipeline = get_dimstack_pipeline(Path(project_path))
    return pipeline.canonicalize_content(content)


def find_semantic_equivalence(content1: str, content2: str, 
                             project_path: Optional[str] = None,
                             threshold: float = 0.1) -> bool:
    """Find semantic equivalence between Forge contents."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    pipeline = get_dimstack_pipeline(Path(project_path))
    return pipeline.find_semantic_equivalence(content1, content2, threshold=threshold)


__all__ = [
    "InvariantAtomic",
    "FactorizedCoordinate", 
    "TruthLayer",
    "SemanticDecomposer",
    "SimpleSemanticDecomposer",
    "ComburiscopeEngine",
    "DimstackPipeline",
    "get_dimstack_pipeline",
    "canonicalize_forge_content",
    "find_semantic_equivalence"
]
