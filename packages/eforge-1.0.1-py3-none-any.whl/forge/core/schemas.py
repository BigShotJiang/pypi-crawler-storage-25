"""
forge/core/schemas.py
Canonical Pydantic models for Forge's internal contracts.
All tool return shapes, session state, annotation extensions,
and intent records are defined here and imported everywhere else.
MCP handlers import for outputSchema declarations.
CLI commands import for validation before write.
"""

from __future__ import annotations

import json
from enum import Enum
from typing import Any, Literal, Optional

from pydantic import AliasChoices, BaseModel, ConfigDict, Field


class AnnotationKind(str, Enum):
    """Subset of annotation kinds aligned with schemas/forge-annotations.schema.yaml."""

    DEBT = "debt"
    GAP = "gap"
    FINDING = "finding"
    RISK = "risk"
    QUESTION = "question"
    STUB = "stub"
    GUARD = "guard"
    ARCHITECTURE_DEBT = "architecture-debt"
    DESIGN_PROPOSAL = "design-proposal"
    SCHEMA_IMPROVEMENT = "schema-improvement"
    FUTURE_IDEA = "future-idea"
    MILESTONE = "milestone"


class PipelineStepKind(str, Enum):
    RESOURCE = "resource"
    TOOL = "tool"
    ELICITATION = "elicitation"
    CONDITION = "condition"
    FS_WRITE = "fs_write"
    FS_READ = "fs_read"


class PipelineStep(BaseModel):
    step: str
    kind: PipelineStepKind
    resource: str | None = None
    tool: str | None = None
    params: list[str] = Field(default_factory=list)
    elicitation_schema: str | None = None
    condition_field: str | None = None
    condition_value: str | None = None
    required: bool = True
    gate: bool = False
    input_map: dict[str, str] = Field(default_factory=dict)
    # Maps this step's input param names to prior step output fields.
    # Format: {"this_param": "step_label.output_field"}
    # Dot notation for nested fields: "step_label.field.subfield"
    # Array index: "step_label.inferred_nodes[0].kind"
    # Special prefix "context." reads from session metadata.


class PipelineDescriptor(BaseModel):
    pipeline_id: str
    node_kind: str | None = None
    stack: str | None = None
    steps: list[PipelineStep]
    schema_compliance: str | None = None
    version: int = 1


class NodeTier(str, Enum):
    """Declaration graph tier — hierarchical for forge_query filtering."""

    SURFACE = "surface"
    WORKER = "worker"
    GLOVE = "glove"
    GATE = "gate"
    SCHEMA = "schema"
    REGISTRY = "registry"
    PIPELINE = "pipeline"


# Tier hierarchy — parent lookup for query traversal (subtype → ancestor).
NODE_TIER_PARENTS: dict[NodeTier, NodeTier | None] = {
    NodeTier.SURFACE: None,
    NodeTier.WORKER: None,
    NodeTier.GLOVE: NodeTier.WORKER,
    NodeTier.GATE: NodeTier.WORKER,
    NodeTier.SCHEMA: None,
    NodeTier.REGISTRY: NodeTier.SCHEMA,
    NodeTier.PIPELINE: None,
}


def tier_includes(query_tier: NodeTier, node_tier: NodeTier) -> bool:
    """True if ``node_tier`` is ``query_tier`` or a descendant subtype in :data:`NODE_TIER_PARENTS`."""
    t: NodeTier | None = node_tier
    while t is not None:
        if t == query_tier:
            return True
        t = NODE_TIER_PARENTS.get(t)
    return False


class ChangeClass(str, Enum):
    SCHEMA_FIELD_ADD = "schema_field_add"
    SCHEMA_FIELD_REMOVE = "schema_field_remove"
    SCHEMA_FIELD_RENAME = "schema_field_rename"
    ERROR_CODE_ADD = "error_code_add"
    ERROR_CODE_REMOVE = "error_code_remove"
    TOOL_SIGNATURE_CHANGE = "tool_signature_change"
    RESOURCE_URI_ADD = "resource_uri_add"
    RESOURCE_URI_REMOVE = "resource_uri_remove"
    PIPELINE_STEP_ADD = "pipeline_step_add"
    PIPELINE_STEP_REMOVE = "pipeline_step_remove"
    PIPELINE_STEP_INPUT_MAP_CHANGE = "pipeline_step_input_map_change"
    HANDLER_LOGIC_CHANGE = "handler_logic_change"
    MANIFEST_NODE_ADD = "manifest_node_add"
    MANIFEST_NODE_REMOVE = "manifest_node_remove"
    MANIFEST_EDGE_ADD = "manifest_edge_add"
    MANIFEST_EDGE_REMOVE = "manifest_edge_remove"
    TIER_IMPORT_VIOLATION = "tier_import_violation"


class ChangeEvent(BaseModel):
    """Single classified diff hunk outcome for scoped impact propagation."""

    file: str
    change_class: ChangeClass
    affected_node_ids: list[str] = Field(default_factory=list)
    breaking: bool = False
    context: dict[str, Any] = Field(default_factory=dict)


class ResponseTier(str, Enum):
    L0 = "L0"  # ~20 tokens - status + next action only
    L1 = "L1"  # ~200-600 tokens - scoped section
    L2 = "L2"  # ~1500+ tokens - full bundle


class OutputResolutionPolicy(BaseModel):
    tier: ResponseTier = ResponseTier.L0
    policy_mode: Literal["advisory", "strict"] = "advisory"
    strict: bool = False
    dry_run: bool = True
    debug: bool = False
    changed_files_source: Literal["git", "manual"] = "git"

    def resolve_depth(self) -> int:
        return {"L0": 0, "L1": 1, "L2": 2}[self.tier.value]

    def allows_write(self) -> bool:
        return not self.dry_run

    @classmethod
    def from_meta(cls, get_meta_fn) -> "OutputResolutionPolicy":
        """Construct from MCP session metadata. Used in server.py."""
        return cls(
            tier=ResponseTier(get_meta_fn("response_tier", "L0")),
            policy_mode=get_meta_fn("policy_mode", "advisory"),
            strict=get_meta_fn("strict", False),
            dry_run=get_meta_fn("dry_run", True),
            debug=get_meta_fn("debug", False),
            changed_files_source=get_meta_fn("changed_files_source", "git"),
        )


class OrientResult(BaseModel):
    project_id: str
    phase: int
    health: int
    next_action: str
    suggested_workflow: list[str] = Field(default_factory=list)
    context_link: str | None = None


class AuditScanResult(BaseModel):
    nodes_checked: int
    findings_count: int
    findings_by_severity: dict[str, int]
    auto_annotated: int
    annotations_link: str | None = None


class VerifyResult(BaseModel):
    exit_code: int
    graph_health: int
    sync_health: int
    violations: list[str] = Field(default_factory=list)
    auto_annotated: int = 0
    verify_link: str | None = None


class ImpactCheckResult(BaseModel):
    target_node: str
    blast_radius: list[str]
    affected_domains: list[str]
    annotation_count: int
    proceed_recommended: bool


class ScaffoldResult(BaseModel):
    node_id: str
    files_emitted: list[str]
    dry_run: bool
    manifest_link: str | None = None


class ManifestResult(BaseModel):
    nodes: list[dict[str, Any]] = Field(default_factory=list)
    edges: list[dict[str, Any]] = Field(default_factory=list)
    node_count: int = 0
    edge_count: int = 0


class ForgeGraphQueryPayload(BaseModel):
    """JSON body from ``forge.core.query.forge_query`` (``.as_dict()``).

    Shape depends on operation (filter list vs blast_ring2 bundle); extra keys allowed.
    """

    model_config = ConfigDict(extra="allow")


class AnnotateResult(BaseModel):
    action: str
    annotation_id: str | None = None
    affected_count: int = 0
    success: bool


class PacketResult(BaseModel):
    node_id: str
    contracts: list[str]
    wiring: list[str]
    template_id: str | None = None
    glove_link: str | None = None


class SessionResult(BaseModel):
    action: str
    session_id: str | None = None
    status: str
    scratch_path: str | None = None


class SessionAction(str, Enum):
    START = "start"
    NOTE = "note"
    HANDOFF = "handoff"
    STATUS = "status"
    PROMOTE = "promote"
    ARCHIVE = "archive"
    PHASE_UPSERT = "phase_upsert"
    PHASE_STATUS = "phase_status"
    PAUSE = "pause"


class SessionState(BaseModel):
    session_id: str
    project_id: str
    started_at: str
    action_log: list[str] = Field(default_factory=list)
    scratch_path: str
    open_annotation_count: int = 0
    status: Literal["active", "handed_off", "archived"] = "active"


class GithubWriteResult(BaseModel):
    repo: str
    path: str
    sha: str | None = None
    dry_run: bool


class ManifestAppendResult(BaseModel):
    node_id: str
    manifest_path: str
    dry_run: bool
    graph_health_after: int | None = None


class ConfigGetResult(BaseModel):
    key: str
    value: str | None
    source: str


class TemplateResult(BaseModel):
    action: str
    templates: list[dict[str, Any]] = Field(default_factory=list)
    template: dict[str, Any] | None = None


class IntentResult(BaseModel):
    action: str
    record_id: str | None = None
    records: list[dict[str, Any]] = Field(default_factory=list)
    elicitation_required: bool = False
    confirmation_status: str | None = None
    # forge_intent action=query — preserved for MCP structuredContent (see make_tool_result).
    response_tier: str | None = None
    filters_applied: dict[str, Any] | None = None
    coverage_rollup: dict[str, Any] | None = Field(
        default=None,
        description="Intent vs manifest graph rollup (query action).",
    )


class CLIProgressEvent(BaseModel):
    event: Literal["progress"] = "progress"
    current: int
    total: int
    message: str = ""


class AnnotationStatus(str, Enum):
    # Canonical enum - source of truth for all writers
    DRAFT = "draft"
    OPEN = "open"
    RESOLVED = "resolved"
    DISMISSED = "dismissed"
    DEFERRED = "deferred"
    # Legacy aliases "expired"/"wont_fix" map to DISMISSED on read.


class AnnotationRelations(BaseModel):
    pipeline_refs: list[str] = Field(default_factory=list)
    tool_refs: list[str] = Field(default_factory=list)
    elicitation_trigger: bool = False


class IntentScope(str, Enum):
    PROJECT = "project"
    FEATURE = "feature"
    NODE = "node"


class IntentStatus(str, Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    SUPERSEDED = "superseded"


class NodeHint(BaseModel):
    kind: str
    name: str
    domain: str | None = None
    confidence: float = 0.5


class DesignIntentRecord(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    id: str
    scope: IntentScope
    target_id: str | None = None
    raw_description: str
    extracted_entities: list[str] = Field(
        default_factory=list,
        validation_alias=AliasChoices("extracted_entities", "extracted_nodes"),
    )
    inferred_nodes: list[NodeHint] = Field(default_factory=list)
    status: IntentStatus = IntentStatus.ACTIVE
    deprecated_when: str | None = None
    source: str
    created: str = Field(validation_alias=AliasChoices("created", "created_at"))
    elicitation_required: bool = False
    elicitation_schema: dict[str, Any] | None = None
    layer_id: str | None = None
    domain: str | None = None
    target_node: Any | None = Field(default=None, exclude=True, repr=False)

    @property
    def extracted_nodes(self) -> list[str]:
        # Back-compat alias for existing runtime code and on-disk YAML.
        return self.extracted_entities

    @property
    def created_at(self) -> str:
        # Back-compat alias for existing runtime code and on-disk YAML.
        return self.created

    def to_yaml_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "id": self.id,
            "scope": self.scope.value,
            "target_id": self.target_id or None,
            "raw_description": self.raw_description,
            "extracted_nodes": list(self.extracted_entities),
            "source": self.source,
            "status": self.status.value,
            "deprecated_when": self.deprecated_when or "",
            "created_at": self.created,
        }
        if self.layer_id:
            out["layer_id"] = self.layer_id
        if self.domain and str(self.domain).strip():
            out["domain"] = str(self.domain).strip().upper()
        return out

    @classmethod
    def from_mapping(cls, data: dict[str, Any]) -> "DesignIntentRecord":
        tid = data.get("target_id")
        tid_s = str(tid).strip() if tid is not None and str(tid).strip() else ""
        layer = data.get("layer_id")
        layer_s = str(layer).strip() if layer is not None and str(layer).strip() else None
        raw_nodes = data.get("extracted_nodes")
        if raw_nodes is None:
            raw_nodes = data.get("extracted_entities") or []
        nodes = [str(x) for x in raw_nodes] if isinstance(raw_nodes, list) else []
        dom = data.get("domain")
        domain_opt = (
            str(dom).strip().upper()
            if dom is not None and str(dom).strip()
            else None
        )
        raw_status = str(data.get("status") or "active").strip().lower()
        if raw_status == "expired" or raw_status == "wont_fix":
            raw_status = "dismissed"
        if raw_status == "dismissed":
            # IntentStatus has no dismissed state; degrade to deprecated for intent lifecycle.
            raw_status = "deprecated"
        return cls(
            id=str(data["id"]),
            scope=IntentScope(str(data["scope"])),
            target_id=tid_s or None,
            raw_description=str(data.get("raw_description") or ""),
            extracted_entities=nodes,
            source=str(data.get("source") or "manual"),
            status=IntentStatus(raw_status),
            created=str(data.get("created") or data.get("created_at") or ""),
            layer_id=layer_s,
            deprecated_when=str(data.get("deprecated_when") or "") or None,
            domain=domain_opt,
            elicitation_required=bool(data.get("elicitation_required", False)),
            elicitation_schema=(
                data.get("elicitation_schema")
                if isinstance(data.get("elicitation_schema"), dict)
                else None
            ),
            inferred_nodes=[],
        )


IntentRecord = DesignIntentRecord


class FunctionalIntentRecord(BaseModel):
    id: str
    design_intent_id: str
    target_node_id: str | None = None
    proposed_depends_on: list[str] = Field(default_factory=list)
    proposed_implements: list[str] = Field(default_factory=list)
    proposed_tier: NodeTier = NodeTier.WORKER
    acceptance_criteria: list[str] = Field(default_factory=list)
    elicitation_schema: dict[str, Any] | None = None
    status: IntentStatus = IntentStatus.ACTIVE
    created: str
    source: str = "forge_intent"


class FunctionalIntentConfirmation(BaseModel):
    approve: bool
    revised_proposed_depends_on: list[str] = Field(default_factory=list)
    revised_acceptance_criteria: list[str] = Field(default_factory=list)


class NodeStatus(BaseModel):
    declared: bool = False
    implemented: bool = False
    reachable: bool | None = None
    intended: bool = False


class ManifestNodeV2(BaseModel):
    id: str
    name: str
    kind: str
    domain: str
    path: str
    tier: NodeTier
    role: str = ""
    depends_on: list[str] = Field(default_factory=list)
    consumed_by: list[str] = Field(default_factory=list)
    owns: list[str] = Field(default_factory=list)
    status: NodeStatus = Field(default_factory=NodeStatus)
    proposed_depends_on: list[str] = Field(default_factory=list)
    proposed_implements: list[str] = Field(default_factory=list)
    contracts: Optional[list[str] | dict[str, Any]] = None


# Deprecated fields — read during migration, never written post-v2.
MANIFEST_V1_DEPRECATED = {"stack", "type"}


class UIComponentKind(str, Enum):
    CONFIRMATION = "confirmation"
    FORM = "form"
    PROGRESS = "progress"
    STATUS = "status"
    ANNOTATION_LIST = "annotation_list"
    INTENT_REVIEW = "intent_review"
    DIFF_SUMMARY = "diff_summary"


class UIComponent(BaseModel):
    kind: UIComponentKind
    title: str
    data: dict[str, Any]
    actions: list[str] = Field(default_factory=list)
    requires_response: bool = False


class MetaUI(BaseModel):
    components: list[UIComponent] = Field(default_factory=list)
    layout: Literal["inline", "panel", "modal"] = "inline"


# --- Typed errors (MCP / tools) ---------------------------------------------
# Complements :class:`forge.core.result.ForgeResult` (``error: str``) and
# :class:`forge.core.checks.CheckResult` (``error: str | None``) for CLI and
# dashboard strings — this model is the stable, machine-readable shape for
# handlers and ``forge://schema/errors``.


class ErrorDomain(str, Enum):
    AUTH = "AUTH"
    GAME = "GAME"
    MCP = "MCP"
    MANIFEST = "MANIFEST"
    INTENT = "INTENT"
    SCAFFOLD = "SCAFFOLD"
    VERIFY = "VERIFY"
    GRAPH = "GRAPH"
    ERR = "ERR"


class ForgeError(BaseModel):
    """Stable tool/MCP error payload; pair with ForgeResult.failure(msg) at CLI boundaries."""

    code: str
    domain: ErrorDomain
    message: str

    node_id: str | None = None
    dependency_ids: list[str] = Field(default_factory=list)
    source_tool: str | None = None
    check_class: str | None = None
    context: dict[str, Any] = Field(default_factory=dict)
    hint: str | None = None  # User-friendly hint for Error UX
    debug: str | None = None  # Debug information (only shown in debug mode)


FORGE_ERROR_REGISTRY: dict[str, ForgeError] = {}


def register_error(
    code: str,
    domain: ErrorDomain,
    message: str,
    check_class: str | None = None,
) -> ForgeError:
    entry = ForgeError(
        code=code,
        domain=domain,
        message=message,
        check_class=check_class,
    )
    FORGE_ERROR_REGISTRY[code] = entry
    return entry


def make_error(
    code: str,
    *,
    node_id: str | None = None,
    dependency_ids: list[str] | None = None,
    source_tool: str | None = None,
    context: dict[str, Any] | None = None,
    message: str | None = None,
) -> ForgeError:
    """Instantiate a registered error template with runtime context."""
    from ..constants.error_codes import FORGE_ERROR_HINTS
    
    template = FORGE_ERROR_REGISTRY[code]
    ctx = dict(context or {})
    msg = message if message is not None else template.message
    if message is None and code == "ERR-001":
        exc_s = str(ctx.get("exception") or "").strip()
        tool_s = (source_tool or "").strip()
        if exc_s:
            msg = (
                f"Unhandled error in {tool_s}: {exc_s}"
                if tool_s
                else f"Unhandled error: {exc_s}"
            )
        else:
            msg = template.message
    
    # Add hint from error codes if not already in context
    hint = ctx.get("hint")
    if not hint and code in FORGE_ERROR_HINTS:
        hint = FORGE_ERROR_HINTS[code]["hint"]
    
    # Add debug info if in debug mode
    debug_info = ctx.get("debug")
    if not debug_info and ctx.get("exception"):
        import os
        if os.getenv("FORGE_DEBUG", "false").lower() in ("true", "1", "yes"):
            debug_info = str(ctx.get("exception"))
    
    return template.model_copy(
        update={
            "node_id": node_id,
            "dependency_ids": list(dependency_ids or []),
            "source_tool": source_tool,
            "context": ctx,
            "message": msg,
            "hint": hint,
            "debug": debug_info,
        }
    )


def forge_error_registry_json(*, indent: int | None = 2) -> str:
    """JSON for MCP resource ``forge://schema/errors``."""
    payload = {
        "registered_codes": [
            {
                "code": code,
                "domain": entry.domain.value,
                "message": entry.message,
                "check_class": entry.check_class,
            }
            for code, entry in sorted(FORGE_ERROR_REGISTRY.items())
        ],
        "total": len(FORGE_ERROR_REGISTRY),
        "schema_version": 1,
    }
    return json.dumps(payload, indent=indent)


register_error(
    "ERR-001",
    ErrorDomain.ERR,
    "Unhandled exception in handler (see context.exception and context.debug)",
)
register_error(
    "ERR-002",
    ErrorDomain.ERR,
    "Project path could not be resolved",
)
register_error(
    "MCP-001",
    ErrorDomain.MCP,
    "outputSchema validation failed — CLI output did not match declared schema",
)
register_error(
    "MCP-002",
    ErrorDomain.MCP,
    "Resource not found",
)
register_error(
    "MANIFEST-001",
    ErrorDomain.MANIFEST,
    "Node not found in declaration graph",
    check_class="parity",
)
register_error(
    "INTENT-001",
    ErrorDomain.INTENT,
    "Intent record not found",
)
register_error(
    "SCAFFOLD-001",
    ErrorDomain.SCAFFOLD,
    "Glove not found for node kind / stack combination",
)
register_error(
    "VERIFY-001",
    ErrorDomain.VERIFY,
    "Parity check failed — declared node has no implementation",
    check_class="parity",
)
register_error(
    "VERIFY-002",
    ErrorDomain.VERIFY,
    "Proposed dependency unresolved — proposed_depends_on entry has no corresponding depends_on edge",
    check_class="proposed_deps",
)
register_error(
    "VERIFY-003",
    ErrorDomain.VERIFY,
    "Proposed contract unresolved — proposed_implements entry not satisfied by declared edges",
    check_class="proposed_implements",
)
register_error(
    "GRAPH-001",
    ErrorDomain.GRAPH,
    "Edge traversal failed — node references non-existent dependency",
)
register_error(
    "AUTH-999",
    ErrorDomain.AUTH,
    "Reserved auth / gateway failure tag (placeholder until auth middleware is wired)",
)
register_error(
    "GAME-001",
    ErrorDomain.GAME,
    "Packet or workflow operational tag — use in packet logging.error_code (see packet validator)",
)
register_error(
    "FS-001",
    ErrorDomain.ERR,
    "Path escape rejected — path must be within ~/Projects",
)
register_error(
    "FS-002",
    ErrorDomain.ERR,
    "File not found",
)
register_error(
    "FS-003",
    ErrorDomain.ERR,
    "Write failed",
)
register_error(
    "IMPACT-001",
    ErrorDomain.ERR,
    "Change could not be classified — diff unreadable or file not tracked in manifest. Advisory only.",
)


# --- Epoch 0: Tool Input/Output Models ---------------------------------------
# Pydantic models matching the inputSchema of all active MCP tools.
# These are the single source of truth for tool shapes.
# Handlers don't use them yet (that's Epoch 1) - they just define the contracts.


class ForgeOrientInput(BaseModel):
    """Input model for forge_orient tool."""
    node: Optional[str] = None
    project_path: Optional[str] = None
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeAnnotateInput(BaseModel):
    """Input model for forge_annotate tool."""
    action: Literal[
        "create",
        "update",
        "resolve",
        "promote",
        "dismiss",
        "bulk_dismiss",
        "bulk_update",
        "note",
        "list",
        "show",
        "query_by_node",
    ]
    project_path: Optional[str] = None
    node_id: Optional[str] = None
    affects: list[str] = Field(default_factory=list)
    blocks: list[str] = Field(default_factory=list)
    requires: list[str] = Field(default_factory=list)
    annotation_id: Optional[str] = None
    kind: Optional[str] = None
    file: Optional[str] = None
    title: Optional[str] = None
    content: Optional[str] = None
    severity: Optional[Literal["high", "medium", "low"]] = None
    horizon: Optional[Literal["current", "next", "future", "deferred"]] = None
    response_tier: Literal["L0", "L1", "L2"] = "L0"
    assigned: Optional[str] = None
    expires_when: Optional[str] = None
    finding: Optional[str] = None
    adr_refs: Optional[list[str]] = None
    pipeline_refs: Optional[list[str]] = None
    tool_refs: Optional[list[str]] = None
    status: Optional[str] = None
    git_issue: Optional[str] = None
    note: Optional[str] = None
    ids: Optional[list[str]] = None
    fields: Optional[dict[str, Any]] = None
    resolution_note: Optional[str] = None
    marker: Optional[str] = None
    session_id: Optional[str] = None


class ForgeVerifyInput(BaseModel):
    """Input model for forge_verify tool."""
    project_path: Optional[str] = None
    target: Literal[
        "staged", "full", "unstaged", "parity", "stack"
    ] = Field(
        default="staged",
        description=(
            "staged — changed files in git index; "
            "full — all tracked files (drift detect); "
            "unstaged — working tree changes; "
            "parity — parity edge validation only; "
            "stack — stack field compliance only"
        ),
    )
    scope: Optional[str] = None
    strict: bool = False
    diff: Optional[str] = None
    domain: Optional[str] = None
    preflight: bool = False
    packet: Optional[str] = None
    response_tier: Literal["L0", "L1", "L2"] = "L0"


class ForgeManifestInput(BaseModel):
    """Input model for forge_manifest tool."""
    action: Literal["path", "get", "validate", "schema", "migrate"]
    project_path: Optional[str] = None
    node_ref: Optional[str] = None
    field: Optional[str] = None
    project_name: Optional[str] = None
    file: Optional[str] = None
    format: Literal["raw", "graph", "index", "summary", "full", "criticality"] = "raw"
    section: Optional[str] = None
    scope: Optional[str] = None
    as_json: bool = False
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeIntentInput(BaseModel):
    """Input model for forge_intent tool."""
    action: Literal["add", "query", "confirm", "deprecate", "specify"]
    raw_description: Optional[str] = None
    scope: Literal["project", "feature", "node"] = "feature"
    target_id: Optional[str] = None
    design_intent_id: Optional[str] = None
    target_node_id: Optional[str] = None
    proposed_depends_on: Optional[list[str]] = None
    proposed_implements: Optional[list[str]] = None
    proposed_tier: Literal["surface", "worker", "registry", "schema", "glove"] = "worker"
    acceptance_criteria: Optional[list[str]] = None
    record_id: Optional[str] = None
    project_path: Optional[str] = None
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeSessionInput(BaseModel):
    """Input model for forge_session tool."""
    action: Literal["start", "status", "handoff", "pause", "phase_upsert", "phase_status"]
    project_path: Optional[str] = None
    session_id: Optional[str] = None
    repo_root: Optional[str] = None
    branch: Optional[str] = None
    session_label: Optional[str] = None
    stopped_at: Optional[str] = None
    next_action: Optional[str] = None
    phase_id: Optional[str] = None
    task_id: Optional[str] = None
    status: Optional[Literal["todo", "doing", "blocked", "done"]] = None
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgePipelineInput(BaseModel):
    """Input model for forge_pipeline tool."""
    project_path: str = Field(..., description="Path to the forge project")
    pipeline_id: str = Field(..., description="Pipeline ID to execute e.g. verify_gate")


class ForgeImpactCheckInput(BaseModel):
    """Input model for forge_impact_check tool."""
    project_path: Optional[str] = None
    changed_files: list[str]
    strict: bool = False
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeAuditScanInput(BaseModel):
    """Input model for forge_audit_scan tool."""
    project_path: Optional[str] = None
    mode: Literal["repo", "meta"] = "repo"
    at_path: Optional[str] = None
    changed_files_source: Literal["git", "scope", "all"] = "git"
    alignment_mode: Literal["target_to_forge", "bidirectional", "target_only"] = "target_to_forge"
    scope: Optional[list[str]] = None
    focus: Optional[list[str]] = None
    depth: int = 3
    include_siblings: bool = True
    include_parent_context: bool = True
    strict: bool = False
    policy_mode: Literal["advisory", "enforce"] = "advisory"
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeScaffoldInput(BaseModel):
    """Input model for forge_scaffold tool."""
    project_path: Optional[str] = None
    node_type: Optional[str] = Field(
        default=None,
        description=(
            "Node kind to scaffold. Universal: "
            "module, service, controller, screen. "
            "Web/Astro: component, page, layout, "
            "route, content. "
            "Flutter: screen, widget, variant."
        ),
    )
    stack: Optional[str] = Field(
        default=None,
        description=(
            "Target stack: web, astro, python, "
            "flutter, dart. Inferred from manifest "
            "if not provided."
        ),
    )
    template_inputs: Optional[dict[str, Any]] = Field(
        default=None,
        description=(
            "Template field values — name, domain, "
            "path, contracts, etc. Run forge_template "
            "first to see required fields for your "
            "kind and stack."
        ),
    )
    intent_id: Optional[str] = None
    output_path: Optional[str] = None
    dry_run: bool = False
    emit_spec: bool = False
    describe: Optional[str] = None
    response_tier: Literal["L0", "L1", "L2"] = "L0"


class ForgeTemplateInput(BaseModel):
    """Input model for forge_template tool."""
    action: Literal["list", "show", "schema", "validate"]
    project_path: Optional[str] = None
    template_id: Optional[str] = None
    stack: Optional[str] = None
    kind: Optional[str] = None
    tier: Optional[str] = None
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeHealthVectorInput(BaseModel):
    """Input model for forge_health_vector tool."""
    project_path: Optional[str] = None


class ForgePipelineRunInput(BaseModel):
    """Input model for forge_pipeline_run tool."""
    pipeline_id: str
    project_path: Optional[str] = None
    context_overrides: Optional[dict[str, Any]] = None
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeWorkspaceInput(BaseModel):
    """Input model for forge_workspace tool."""
    action: Literal["status", "add", "dependents", "dependencies"]
    project_path: Optional[str] = None
    project_id: Optional[str] = None
    depends_on: Optional[list[str]] = None
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgePacketAssembleInput(BaseModel):
    """Input model for forge_packet_assemble tool."""
    node: str
    type: Literal["screen", "controller", "service", "model", "variant", "module"]
    domain: str
    task: Literal["generate", "fix"] = "generate"
    deps: Optional[list[str]] = None
    methods: Optional[list[str]] = None
    project_path: Optional[str] = None
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeInitInput(BaseModel):
    """Input model for forge_init tool."""
    project_path: Optional[str] = None
    name: Optional[str] = None
    intent: Optional[str] = None
    stack: Optional[str] = None


class ForgeVerifyEventsInput(BaseModel):
    """Input model for forge_verify_events tool."""
    project_path: Optional[str] = None
    date: Optional[str] = None


class ForgeContextInput(BaseModel):
    """Input model for forge_context tool."""
    project_path: Optional[str] = None


class ForgeProjectStatusInput(BaseModel):
    """Input model for forge_project_status tool."""
    project_path: Optional[str] = None


class ForgeConfigGetInput(BaseModel):
    """Input model for forge_config_get tool."""
    key: str
    file: Literal["config", "manifest", "workspace"] = "config"
    project_path: Optional[str] = None
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeConfigSetInput(BaseModel):
    """Input model for forge_config_set tool."""
    key: str
    value: Any
    file: Literal["config", "manifest", "workspace"] = "config"
    project_path: Optional[str] = None
    response_tier: Literal["L0", "L1", "L2"] = "L1"
    dry_run: bool = False


class ForgeSessionLogInput(BaseModel):
    """Input model for forge_session_log tool."""
    session_id: str
    project_path: Optional[str] = None
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeManifestAppendInput(BaseModel):
    """Input model for forge_manifest_append tool."""
    project_path: Optional[str] = None
    nodes: list[dict[str, Any]]
    dry_run: bool = False
    response_tier: Literal["L0", "L1", "L2"] = "L1"
    validate_graph: bool = False
    check_dependencies: bool = False


class ForgeMapInput(BaseModel):
    """Input model for forge_map tool."""
    project_path: Optional[str] = None
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeTraceInput(BaseModel):
    """Input model for forge_trace tool."""
    project_path: Optional[str] = None
    from_id: Optional[str] = Field(
        default=None,
        description="Source manifest node id (or bare name resolved via graph)",
    )
    to_id: Optional[str] = Field(
        default=None,
        description="Target manifest node id (or bare name resolved via graph)",
    )
    from_node: Optional[str] = Field(
        default=None,
        description="Alias for from_id",
    )
    to_node: Optional[str] = Field(
        default=None,
        description="Alias for to_id",
    )
    callable_path: Optional[str] = Field(
        default=None,
        description="Legacy CLI runtime trace entry point (optional for graph trace)",
    )
    output_dir: Optional[str] = None
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeGithubWriteInput(BaseModel):
    """Input model for forge_github_write tool."""
    project_path: Optional[str] = None
    repo_owner: str
    repo_name: str
    file_path: str
    content: str
    commit_message: str
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeReportInput(BaseModel):
    """Input model for forge_report tool."""
    project_path: Optional[str] = None
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgePacketInput(BaseModel):
    """Input model for forge_packet tool."""
    project_path: Optional[str] = None
    response_tier: Literal["L0", "L1", "L2"] = "L1"

class ForgeQueryInput(BaseModel):
    """Input schema for forge_query tool."""
    project_path: Optional[str] = Field(default=None, description="Path to Forge project")
    tier: Optional[str] = Field(default=None, description="Node tier filter (surface/worker/glove/gate/schema/registry/pipeline)")
    domain: Optional[str] = Field(default=None, description="Domain filter (AUTH/CANVAS/GAME/LOBBY/PROFILE/PREMIUM/CORE/REMOTE)")
    name: Optional[str] = Field(default=None, description="Name substring filter")
    kind: Optional[str] = Field(default=None, description="Kind filter (command/system/component/etc)")
    node_id: Optional[str] = Field(default=None, description="Specific node ID — returns single node if found")
    project_id: Optional[str] = Field(
        default=None,
        description="Workspace registry slug — resolves typed ForgeProject metadata or scopes graph traversal",
    )
    status: Optional[str] = Field(default=None, description="Status filter (active/planned/deprecated)")
    limit: Optional[int] = Field(default=50, description="Max results to return")
    depth: Optional[int] = Field(default=1, description="Traversal depth for import BFS")
    direction: Optional[str] = Field(default="both", description="Edge direction: in, out, or both")
    depends_on: Optional[str] = Field(default=None, description="Filter nodes with dependency on this id/name")
    response_tier: Literal["L0", "L1", "L2"] = Field(
        default="L1",
        description="L0=counts+IDs only, L1=standard fields (default), L2=full detail",
    )


class ForgeBlastRadiusInput(BaseModel):
    """Input schema for forge_blast_radius tool."""
    project_path: Optional[str] = Field(default=None, description="Path to Forge project")
    node: Optional[str] = Field(default=None, description="Target node ID for blast radius analysis")
    response_tier: Literal["L0", "L1", "L2"] = Field(
        default="L1",
        description="L0=counts+IDs only, L1=standard fields (default), L2=full detail",
    )


# Editor tier vocabulary — forge owns semantics; forge-engine imports these constants.
EDITOR_TIER_NAMES: dict[str, int] = {
    "surface": 1,
    "application": 2,
    "domain": 3,
    "infrastructure": 4,
    "schema": 5,
}
EDITOR_TIER_LABELS: dict[int, str] = {v: k for k, v in EDITOR_TIER_NAMES.items()}

# Maps declaration-graph NodeTier values to editor tier levels.
NODE_TIER_TO_EDITOR_LEVEL: dict[str, int] = {
    "surface": 1,
    "worker": 2,
    "glove": 2,
    "gate": 2,
    "pipeline": 2,
    "schema": 5,
    "registry": 4,
}


class ForgeEditorGraphInput(BaseModel):
    """Input schema for ForgeSession.editor_graph() and forge-engine forge_editor_graph.

    Data contract between forge and forge-engine. Schema version: editor/v1.
    """
    project_path: str = Field(
        description="Absolute path to project root",
    )
    domain: str | None = Field(
        default=None,
        description=(
            "Filter to a single domain (e.g. 'ENGINE'). None returns all domains."
        ),
    )
    tier: str | None = Field(
        default=None,
        description=(
            "Filter by named editor tier: 'surface', 'application', 'domain', "
            "'infrastructure', 'schema'. Also accepts NodeTier names "
            "(e.g. 'worker'). None returns all."
        ),
    )
    include_extension_edges: bool = Field(
        default=True,
        description=(
            "Include edges with non-canonical relation types. "
            "False returns only MANIFEST_EDGE_RELATIONS edges."
        ),
    )
    response_tier: Literal["L0", "L1", "L2"] = Field(
        default="L2",
        description=(
            "L0=counts only, L1=nodes+edges slim, L2=full detail (default). "
            "Editor always wants L2."
        ),
    )


class ForgeSearchInput(BaseModel):
    """Input schema for forge_search."""
    project_path: str = Field(description="Absolute path to project root")
    query: str = Field(
        description="Partial name, id, or domain to search for",
    )
    kind: Optional[str] = Field(
        default=None,
        description="Filter by node kind (module, controller, service…)",
    )
    domain: Optional[str] = Field(
        default=None,
        description="Filter by domain name",
    )
    limit: int = Field(
        default=20,
        description="Max results to return",
    )
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeDiscoverInput(BaseModel):
    """Input schema for forge_discover."""
    project_path: str = Field(description="Absolute path to project root")
    stack: Optional[str] = Field(
        default="auto",
        description=(
            "Stack to scan: auto (default), python, web, astro, dart. "
            "auto detects from manifest."
        ),
    )
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeInspectInput(BaseModel):
    """Input schema for forge_inspect."""
    project_path: str = Field(description="Absolute path to project root")
    action: Literal["node", "expand", "select", "diff", "packet", "search"] = Field(
        default="node",
        description=(
            "node — inspect a node (default); expand — load ring full data; "
            "select — focus subset; diff — contextual drift; "
            "packet — save as packet; search — find by name"
        ),
    )
    node_id: Optional[str] = Field(
        default=None,
        description="Node ID or bare name. Bare names auto-resolved via glove.",
    )
    query: Optional[str] = Field(
        default=None,
        description=(
            "Search query — alias for node_id when action=search. "
            "Accepts partial names, bare names, or full IDs."
        ),
    )
    kind: Optional[str] = Field(
        default=None,
        description="Filter by node kind when action=search",
    )
    domain: Optional[str] = Field(
        default=None,
        description="Filter by domain when action=search",
    )
    limit: int = Field(
        default=20,
        description="Max search results when action=search",
    )
    handle: Optional[str] = Field(
        default=None,
        description="Cursor handle from previous forge_inspect call",
    )
    ring: Optional[int] = Field(
        default=None,
        description="Ring number to expand (1, 2, 3)",
    )
    ids: Optional[list[str]] = Field(
        default=None,
        description="Node IDs to focus on",
    )
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeImpactRadiusInput(BaseModel):
    """Input schema for forge_impact_radius tool.

    Unified replacement for forge_blast_radius + forge_impact_check.
    """
    project_path: str = Field(description="Absolute path to project root")
    node_id: str = Field(description="Node ID to analyse")
    slice: Optional[Literal["full", "blast", "docs", "contracts"]] = Field(
        default="full",
        description=(
            "full — all fields; "
            "blast — affected_nodes + ring only; "
            "docs — doc_updates_required only; "
            "contracts — contract_violations only"
        ),
    )
    response_tier: Literal["L0", "L1", "L2"] = "L1"


class ForgeImpactRadiusOutput(BaseModel):
    """Output schema for forge_impact_radius."""
    ok: bool
    project: str
    node_id: str
    ring: int
    affected_nodes: list[dict[str, Any]] = []
    doc_updates_required: list[str] = []
    contract_violations: list[str] = []
    slice: str = "full"
    metadata: dict[str, Any] = {}


class ForgeNodeOutput(BaseModel):
    """Typed entity shape for MCP responses. Bridge: ForgeEntity.to_dict() → this."""
    id: str = Field(description="Entity node ID")
    kind: str = Field(description="Entity kind (command/system/component/etc)")
    tier: Optional[str] = Field(default=None, description="Node tier")
    domain: Optional[str] = Field(default=None, description="Domain")
    status: Optional[str] = Field(default=None, description="Status")
    name: Optional[str] = Field(default=None, description="Display name")
    properties: dict[str, Any] = Field(default_factory=dict, description="Raw properties")


# --- Output Models for Single-Action Tools -----------------------------------
# Multi-action tools (forge_annotate, forge_manifest, forge_template, forge_verify, 
# forge_intent, forge_session, forge_workspace, forge_pipeline_run) cannot have 
# outputSchema per MCP protocol — their responses have incompatible shapes per action.


class ForgeOrientOutput(BaseModel):
    """Output model for forge_orient tool."""
    project: str
    phase: int
    stack: str
    structural_health: str
    next_action: Optional[str] = None
    warnings: list[str] = []
    verify_exit_code: int = 0


class ForgeHealthVectorOutput(BaseModel):
    """Output model for forge_health_vector tool."""
    graph_health: str
    sync_health: str
    infra_health: str
    adi_score: float
    brc_score: float
    idr_score: float
    healthy: bool
    idr_rationale: Optional[dict[str, Any]] = Field(
        default=None,
        description=(
            "How IDR was derived: annotation index presence, row/target counts, "
            "coverage model hint, preview of uncovered nodes."
        ),
    )


class ForgeVerifyEventsOutput(BaseModel):
    """Output model for forge_verify_events tool."""
    date: str
    events_valid: bool
    event_count: int
    chain_validation_status: str


class ForgeImpactCheckOutput(BaseModel):
    """Output model for forge_impact_check tool."""
    exit_code: int
    triggered_rules: list[str] = []
    impact_summary: str
    affected_nodes: list[str] = []
    proceed_recommended: bool


class ForgePacketAssembleOutput(BaseModel):
    """Output model for forge_packet_assemble tool."""
    packet_path: str
    node_id: str
    node_type: str
    domain: str
    contracts: list[str]
    wiring: list[str]
    template_id: Optional[str] = None
    glove_link: Optional[str] = None



tool_input_schemas: dict[str, type[BaseModel]] = {
    "forge_query": ForgeQueryInput,
    "forge_blast_radius": ForgeBlastRadiusInput,
}

try:
    from forge.engine.entity.schemas import NodeModel as _NodeModel

    ManifestNodeV2 = _NodeModel
except ImportError:
    pass