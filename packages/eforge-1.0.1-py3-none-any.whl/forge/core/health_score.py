"""
HealthScorer — denv-compatible health score and status.

Weights match denv exactly so same project scores same in both.
Used by dashboard v2; no UI here.
"""


class HealthScorer:
    """
    Weights match denv exactly so same project scores same in both.

    denv formula:
      secrets_present:        +15
      scripts_present:        +10
      git_clean:              +10
      supabase_linked:        +15
      no_pending_migrations:  +10
      config_valid:           +15
      docs_completeness:      0-25 (fraction of 8 required docs × 25)
      Total max: 100
    """

    REQUIRED_DOCS = [
        "CURSOR_CONTEXT.md",  # or AGENT_CONTEXT.md
        "MANIFEST.md",
        "ARCHITECTURE.md",
        "MAP.md",
        "FLUTTER_PRINCIPLES.md",
        "TEMPLATES.md",
        "TODO.md",
        "UPDATE.md",
    ]
    REQUIRED_DOCS_GENERIC = [
        "ARCHITECTURE.md",
        "MAP.md",
        "TODO.md",
        "UPDATE.md",
    ]

    @staticmethod
    def score(state) -> int:
        score = 0
        if getattr(state, "secrets_present", False):
            score += 15
        if getattr(state, "scripts_present", False):
            score += 10
        if getattr(getattr(state, "git", None), "is_clean", True):
            score += 10
        if getattr(getattr(state, "supabase", None), "linked", False):
            score += 15
        if getattr(getattr(state, "supabase", None), "migrations_count", 0) == 0:
            score += 10
        if getattr(state, "config_valid", False):
            score += 15

        # Docs completeness
        project_type = getattr(getattr(state, "project", None), "type", "unknown")
        required = (
            HealthScorer.REQUIRED_DOCS
            if project_type == "flutter"
            else HealthScorer.REQUIRED_DOCS_GENERIC
        )
        project = getattr(state, "project", None)
        docs_dir = getattr(project, "path", None)
        if docs_dir is not None:
            docs_dir = docs_dir / "docs"
        else:
            docs_dir = __import__("pathlib").Path(".")
        present = 0
        for doc in required:
            if docs_dir and (docs_dir / doc).exists():
                present += 1
            elif doc == "CURSOR_CONTEXT.md" and docs_dir and (docs_dir / "AGENT_CONTEXT.md").exists():
                present += 1
        if required:
            score += int((present / len(required)) * 25)
        return min(score, 100)

    @staticmethod
    def status(score: int) -> str:
        if score >= 85:
            return "healthy"
        if score >= 60:
            return "warn"
        if score > 0:
            return "critical"
        return "unknown"

    @staticmethod
    def dot(status: str) -> str:
        return {"healthy": "●", "warn": "⊙", "critical": "✗", "unknown": "○"}.get(
            status, "○"
        )

    @staticmethod
    def colour(status: str) -> str:
        return {
            "healthy": "green",
            "warn": "yellow",
            "critical": "red",
            "unknown": "grey",
        }.get(status, "grey")
