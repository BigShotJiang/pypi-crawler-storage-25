"""
Unified Health Scoring Service

Forge-compliant health scoring service that replaces multiple scattered scoring methods.
Implements dependency injection, contract-based penalties, and stack-agnostic design.
"""

from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Any

from forge.contracts.health_scoring import (
    HealthScoringContract,
    HealthScoringConfig,
    HealthScoringFactory,
    DiscrepancyCategory,
    SeverityLevel
)
from dataclasses import dataclass
from enum import Enum
from typing import Optional


# Local definition to avoid circular import
@dataclass
class ValidationDiscrepancy:
    """Local definition to avoid circular import with reality_validator."""
    discrepancy_type: Any
    source_file: Optional[Path]
    import_statement: Optional[Any]
    manifest_node: Optional[Any]
    description: str
    severity: str
    suggested_action: Optional[str] = None


@dataclass
class HealthScoringContext:
    """Context for health scoring calculations."""
    project_root: Path
    stack: str
    file_count: int
    node_count: int
    graph_complexity: Dict[str, int]
    custom_metrics: Dict[str, Any] = None


class UnifiedHealthScoringService:
    """Unified health scoring service adhering to Forge architectural principles."""
    
    def __init__(self, config: Optional[HealthScoringConfig] = None):
        """Initialize with optional configuration."""
        self.config = config or HealthScoringFactory.load_config_from_glove("default")
        self.strategy = HealthScoringFactory.create_strategy(self.config)
    
    def calculate_project_health(self, 
                               discrepancies: List[ValidationDiscrepancy],
                               context: HealthScoringContext) -> Dict[str, Any]:
        """Calculate comprehensive project health score."""
        # Convert ValidationDiscrepancy to contract format
        contract_discrepancies = self._convert_discrepancies(discrepancies)
        
        # Build context dictionary
        scoring_context = {
            'stack': context.stack,
            'file_count': context.file_count,
            'node_count': context.node_count,
            'graph_complexity': context.graph_complexity,
            'custom_metrics': context.custom_metrics or {}
        }
        
        # Calculate score using strategy
        score = self.strategy.calculate_score(contract_discrepancies, scoring_context)
        
        # Generate comprehensive result
        return {
            'health_score': score,
            'explanation': self.strategy.get_explanation(score, contract_discrepancies),
            'breakdown': self._generate_breakdown(contract_discrepancies, scoring_context),
            'context': scoring_context,
            'discrepancy_count': len(discrepancies),
            'scoring_method': 'unified_contract_based'
        }
    
    def _convert_discrepancies(self, discrepancies: List[ValidationDiscrepancy]) -> List[Dict[str, Any]]:
        """Convert ValidationDiscrepancy objects to contract format."""
        converted = []
        
        for disc in discrepancies:
            # Map discrepancy types to categories
            category_map = {
                'missing_import': DiscrepancyCategory.MISSING_IMPORT,
                'extra_declaration': DiscrepancyCategory.EXTRA_DECLARATION,
                'broken_import': DiscrepancyCategory.BROKEN_DEPENDENCY,
                'domain_violation': DiscrepancyCategory.DOMAIN_VIOLATION,
                'architectural_violation': DiscrepancyCategory.ARCHITECTURAL_VIOLATION,
                'configuration_issue': DiscrepancyCategory.CONFIGURATION_ISSUE
            }
            
            discrepancy_type = disc.discrepancy_type.value if hasattr(disc.discrepancy_type, 'value') else str(disc.discrepancy_type)
            category = category_map.get(discrepancy_type, DiscrepancyCategory.CONFIGURATION_ISSUE)
            
            # Convert severity
            severity_str = disc.severity if hasattr(disc, 'severity') else 'warning'
            try:
                severity = SeverityLevel(severity_str)
            except ValueError:
                severity = SeverityLevel.WARNING  # Default
            
            converted.append({
                'category': category.value,
                'severity': severity.value,
                'description': disc.description,
                'source_file': str(disc.source_file) if disc.source_file else None,
                'suggested_action': disc.suggested_action if hasattr(disc, 'suggested_action') else None,
                'discrepancy_type': discrepancy_type
            })
        
        return converted
    
    def _generate_breakdown(self, 
                          discrepancies: List[Dict[str, Any]], 
                          context: Dict[str, Any]) -> Dict[str, Any]:
        """Generate detailed breakdown of scoring calculation."""
        breakdown = {
            'penalty_breakdown': {},
            'severity_distribution': {},
            'category_distribution': {},
            'complexity_analysis': {}
        }
        
        # Calculate penalties by category and severity
        for disc in discrepancies:
            category = disc['category']
            severity = disc['severity']
            
            # Update distributions
            breakdown['severity_distribution'][severity] = breakdown['severity_distribution'].get(severity, 0) + 1
            breakdown['category_distribution'][category] = breakdown['category_distribution'].get(category, 0) + 1
            
            # Calculate penalty
            weight = self.config.get_weight(
                DiscrepancyCategory(category),
                SeverityLevel(severity),
                context.get('stack')
            )
            
            key = f"{category}/{severity}"
            breakdown['penalty_breakdown'][key] = breakdown['penalty_breakdown'].get(key, 0) + weight
        
        # Complexity analysis
        file_count = context.get('file_count', 1)
        node_count = context.get('node_count', 1)
        
        breakdown['complexity_analysis'] = {
            'file_count': file_count,
            'node_count': node_count,
            'complexity_factor': self._calculate_complexity_factor(file_count),
            'graph_density': node_count / max(file_count, 1),
            'scaling_applied': file_count > 1
        }
        
        return breakdown
    
    def _calculate_complexity_factor(self, file_count: int) -> float:
        """Calculate complexity scaling factor."""
        base_factor = self.config.complexity_scaling.get('base_factor', 50.0)
        return min(1.0, base_factor / max(file_count, 1))
    
    def update_config(self, new_config: HealthScoringConfig) -> None:
        """Update scoring configuration."""
        self.config = new_config
        self.strategy = HealthScoringFactory.create_strategy(new_config)
    
    def get_config_summary(self) -> Dict[str, Any]:
        """Get summary of current configuration."""
        return {
            'penalty_weights': [
                {
                    'category': w.category.value,
                    'severity': w.severity.value,
                    'weight': w.weight,
                    'description': w.description,
                    'stack_specific': w.stack_specific
                }
                for w in self.config.penalty_weights
            ],
            'complexity_scaling': self.config.complexity_scaling,
            'score_range': {
                'minimum': self.config.minimum_score,
                'maximum': self.config.maximum_score
            }
        }


# Singleton instance for backward compatibility
_default_scoring_service = None

def get_health_scoring_service() -> UnifiedHealthScoringService:
    """Get default health scoring service instance."""
    global _default_scoring_service
    if _default_scoring_service is None:
        _default_scoring_service = UnifiedHealthScoringService()
    return _default_scoring_service


def calculate_health_score(discrepancies: List[ValidationDiscrepancy], 
                         context: HealthScoringContext) -> Dict[str, Any]:
    """Convenience function for health scoring."""
    service = get_health_scoring_service()
    return service.calculate_project_health(discrepancies, context)
