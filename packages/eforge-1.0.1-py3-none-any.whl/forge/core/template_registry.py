"""
UI scaffold template registry — flat DOCS-TEMPLATE/UI-TEMPLATES layout.

Templates live under:
  <DOCS-TEMPLATE>/UI-TEMPLATES/FLUTTER/*.dart
  <DOCS-TEMPLATE>/UI-TEMPLATES/REACT/*.{tsx,ts,css}

Resolution (same priority as forge init-docs docs root, then /UI-TEMPLATES):
  1. FORGE_DOCS_TEMPLATE_PATH / UI-TEMPLATES
  2. ../DOCS-TEMPLATE/UI-TEMPLATES (sibling of forge repo)
  3. Bundled stub under forge/core/ui_templates_bundle/UI-TEMPLATES
"""

from __future__ import annotations

import os
import warnings
from pathlib import Path
from typing import Any

# Registry: framework -> category -> list of template unit base names (file stems / logical groups)
REGISTRY: dict[str, dict[str, list[str]]] = {
    "flutter": {
        "tokens": ["tokens"],
        "atoms": ["atoms"],
        "molecules": ["components"],
        "layouts": ["layouts"],
        "screens": ["home_screen"],
    },
    "react": {
        "tokens": ["tokens"],
        "atoms": ["Button", "Input"],
        "molecules": ["molecules"],
        "layouts": ["layouts"],
        "screens": ["Dashboard", "AuthPage"],
    },
}


def _forge_repo_root() -> Path:
    """Repository root (parent of the `forge` Python package)."""
    return Path(__file__).resolve().parent.parent.parent


def resolve_docs_template_root() -> Path:
    """
    Resolve DOCS-TEMPLATE (or equivalent) root — mirrors init-docs priority.
    Does not append UI-TEMPLATES.
    """
    env = os.environ.get("FORGE_DOCS_TEMPLATE_PATH")
    if env:
        p = Path(env).expanduser().resolve()
        if p.exists() and p.is_dir():
            return p
        raise FileNotFoundError(
            f"FORGE_DOCS_TEMPLATE_PATH is set but directory not found: {p}\n"
            "Unset it or fix the path."
        )
    repo = _forge_repo_root()
    sibling = (repo.parent / "DOCS-TEMPLATE").resolve()
    if sibling.exists() and sibling.is_dir():
        return sibling
    bundled_docs = Path(__file__).resolve().parent.parent / "tools" / "init_docs" / "templates"
    if bundled_docs.exists() and bundled_docs.is_dir():
        warnings.warn(
            "Using init-docs bundled path as DOCS-TEMPLATE root for UI resolution. "
            "Prefer ~/Projects/DOCS-TEMPLATE or FORGE_DOCS_TEMPLATE_PATH.",
            UserWarning,
            stacklevel=2,
        )
        return bundled_docs
    raise FileNotFoundError(
        "No DOCS-TEMPLATE root found for UI-TEMPLATES. "
        "Set FORGE_DOCS_TEMPLATE_PATH or create ../DOCS-TEMPLATE/."
    )


def resolve_ui_templates_root() -> Path:
    """Directory containing FLUTTER/ and REACT/ flat template files."""
    env = os.environ.get("FORGE_DOCS_TEMPLATE_PATH")
    sibling = (_forge_repo_root().parent / "DOCS-TEMPLATE" / "UI-TEMPLATES").resolve()
    primary: Path | None = None

    if env:
        primary = Path(env).expanduser().resolve() / "UI-TEMPLATES"
        if primary.is_dir():
            return primary
    elif sibling.is_dir():
        return sibling

    bundled = Path(__file__).parent / "ui_templates_bundle" / "UI-TEMPLATES"
    if bundled.is_dir():
        if os.environ.get("FORGE_ALLOW_BUNDLED_TEMPLATES", "").lower() in (
            "1",
            "true",
            "yes",
        ):
            warnings.warn(
                "Using bundled UI-TEMPLATES fallback. "
                "Set FORGE_DOCS_TEMPLATE_PATH to your "
                "DOCS-TEMPLATES/DOCS-TEMPLATE directory.",
                UserWarning,
                stacklevel=2,
            )
            return bundled

        raise FileNotFoundError(
            "No UI-TEMPLATES source found.\n"
            "Tried (in order):\n"
            "  1. FORGE_DOCS_TEMPLATE_PATH env var (not set or not found)\n"
            f"  2. {sibling} (not found)\n"
            "  3. Bundled fallback requires FORGE_ALLOW_BUNDLED_TEMPLATES=1\n\n"
            "Fix: set FORGE_DOCS_TEMPLATE_PATH:\n"
            "  export FORGE_DOCS_TEMPLATE_PATH="
            '"$HOME/Projects/DOCS-TEMPLATES/DOCS-TEMPLATE"\n'
            "Then verify: forge init-docs --show-template-path"
        )

    if primary is not None:
        raise FileNotFoundError(
            f"UI-TEMPLATES not found at {primary}; bundled fallback missing at {bundled}."
        )
    raise FileNotFoundError(
        f"UI-TEMPLATES not found at {sibling}; bundled fallback missing at {bundled}."
    )


def _source_name_sort_key(filename: str) -> tuple[int, str]:
    """Prefer .tsx/.ts before .css in listings."""
    if filename.endswith(".tsx"):
        return (0, filename)
    if filename.endswith(".ts"):
        return (1, filename)
    if filename.endswith(".module.css"):
        return (2, filename)
    if filename.endswith(".css"):
        return (3, filename)
    return (9, filename)


def react_group_key(filename: str) -> str:
    """Map a REACT template filename to its scaffold unit key (basename without role suffix)."""
    if filename.endswith(".module.css"):
        return filename[: -len(".module.css")]
    if filename in ("tokens.css", "tokens.ts"):
        return "tokens"
    if filename.endswith(".tsx"):
        return Path(filename).stem
    if filename.endswith(".ts"):
        return Path(filename).stem
    return Path(filename).stem


def group_react_files(react_dir: Path) -> dict[str, list[Path]]:
    """Group flat REACT files by unit (Button + Button.module.css, etc.)."""
    grouped: dict[str, list[Path]] = {}
    if not react_dir.is_dir():
        return grouped
    for path in sorted(react_dir.iterdir()):
        if not path.is_file():
            continue
        key = react_group_key(path.name)
        grouped.setdefault(key, []).append(path)
    for key in grouped:
        grouped[key] = sorted(grouped[key], key=lambda p: _source_name_sort_key(p.name))
    return grouped


def flutter_template_path(ui_root: Path, unit: str) -> Path:
    return ui_root / "FLUTTER" / f"{unit}.dart"


def source_files_for_flutter_unit(ui_root: Path, unit: str) -> list[Path]:
    p = flutter_template_path(ui_root, unit)
    return [p] if p.is_file() else []


def source_files_for_react_unit(ui_root: Path, unit: str) -> list[Path]:
    react_dir = ui_root / "REACT"
    grouped = group_react_files(react_dir)
    return grouped.get(unit, [])


def _flutter_screen_feature_parts(stem: str) -> tuple[str, str]:
    """
    home_screen.dart -> feature dir 'home', file 'home_screen.dart'
    dashboard.dart -> feature 'dashboard', file 'dashboard_screen.dart'
    """
    if stem.endswith("_screen") and len(stem) > 7:
        feature = stem[: -len("_screen")]
        if feature:
            return feature, f"{feature}_screen.dart"
    return stem, f"{stem}_screen.dart"


def flutter_target_paths(project_root: Path, category: str, unit: str, src: Path) -> list[Path]:
    """Destination paths relative to project root for one Flutter source file."""
    root = project_root.resolve()
    if category == "tokens":
        return [root / "lib" / "ui" / "tokens" / "tokens.dart"]
    if category == "atoms":
        return [root / "lib" / "ui" / "atoms" / "atoms.dart"]
    if category == "molecules":
        return [root / "lib" / "ui" / "components" / "components.dart"]
    if category == "layouts":
        return [root / "lib" / "ui" / "layouts" / "layouts.dart"]
    if category == "screens":
        stem = src.stem
        feature, fname = _flutter_screen_feature_parts(stem)
        return [root / "lib" / "features" / feature / fname]
    return [root / "lib" / "ui" / src.name]


def react_screen_dest_dir(project_root: Path) -> Path:
    """Prefer src/pages if it exists, else src/screens."""
    base = project_root / "src"
    pages = base / "pages"
    if pages.is_dir():
        return pages
    return base / "screens"


def react_target_paths(project_root: Path, category: str, unit: str, src: Path) -> Path:
    root = project_root.resolve()
    name = src.name
    if category == "tokens":
        return root / "src" / "styles" / name
    if category == "atoms":
        return root / "src" / "components" / "atoms" / name
    if category == "molecules":
        return root / "src" / "components" / "molecules" / name
    if category == "layouts":
        return root / "src" / "layouts" / name
    if category == "screens":
        return react_screen_dest_dir(root) / name
    return root / "src" / name


def react_target_paths_for_unit(project_root: Path, category: str, unit: str, sources: list[Path]) -> list[Path]:
    return [react_target_paths(project_root, category, unit, s) for s in sources]


def iter_registry_entries(
    ui_root: Path | None = None,
) -> list[dict[str, Any]]:
    """
    Flatten registry with resolved source file paths (for list / apply).
    """
    root = ui_root or resolve_ui_templates_root()
    out: list[dict[str, Any]] = []
    for framework, categories in REGISTRY.items():
        for category, units in categories.items():
            for unit in units:
                if framework == "flutter":
                    sources = source_files_for_flutter_unit(root, unit)
                else:
                    sources = source_files_for_react_unit(root, unit)
                rel_names = [p.name for p in sorted(sources, key=lambda p: _source_name_sort_key(p.name))]
                out.append(
                    {
                        "framework": framework,
                        "category": category,
                        "unit": unit,
                        "source_files": sources,
                        "source_names": rel_names,
                    }
                )
    return out


def format_scaffold_list_lines(project_root: Path | None = None) -> list[str]:
    """Human-readable lines for `forge scaffold list` (expected output paths)."""
    root = resolve_ui_templates_root()
    entries = iter_registry_entries(root)
    pr: Path | None = project_root.resolve() if project_root else None
    lines: list[str] = []
    lines.append(f"UI templates root: {root}")
    if pr:
        lines.append(f"Example output (project: {pr}):")
    else:
        lines.append("Output paths (relative to project root):")
    for e in entries:
        fw = e["framework"]
        cat = e["category"]
        unit = e["unit"]
        sources: list[Path] = e["source_files"]
        if not sources:
            lines.append(f"  [{fw}] {cat}/{unit} — MISSING template files {e['source_names']}")
            continue
        if fw == "flutter":
            assert len(sources) == 1
            if pr:
                targets = flutter_target_paths(pr, cat, unit, sources[0])
                tstr = ", ".join(str(p.relative_to(pr)) for p in targets)
            else:
                tstr = _flutter_relative_display(cat, sources[0].stem)
        else:
            if pr:
                targets = react_target_paths_for_unit(pr, cat, unit, sources)
                tstr = ", ".join(str(p.relative_to(pr)) for p in targets)
            else:
                tstr = _react_relative_display(cat, [s.name for s in sources])
        src_disp = ", ".join(s.name for s in sorted(sources, key=lambda p: _source_name_sort_key(p.name)))
        lines.append(f"  [{fw}] {cat}/{unit}  ← {src_disp}")
        lines.append(f"      → {tstr}")
    return lines


def _flutter_relative_display(category: str, stem: str) -> str:
    if category == "tokens":
        return "lib/ui/tokens/tokens.dart"
    if category == "atoms":
        return "lib/ui/atoms/atoms.dart"
    if category == "molecules":
        return "lib/ui/components/components.dart"
    if category == "layouts":
        return "lib/ui/layouts/layouts.dart"
    if category == "screens":
        feature, fname = _flutter_screen_feature_parts(stem)
        return f"lib/features/{feature}/{fname}"
    return f"lib/ui/{stem}.dart"


def _react_relative_display(category: str, names: list[str]) -> str:
    parts = []
    for n in sorted(names, key=_source_name_sort_key):
        if category == "tokens":
            parts.append(f"src/styles/{n}")
        elif category == "atoms":
            parts.append(f"src/components/atoms/{n}")
        elif category == "molecules":
            parts.append(f"src/components/molecules/{n}")
        elif category == "layouts":
            parts.append(f"src/layouts/{n}")
        elif category == "screens":
            parts.append(f"src/screens/{n}")
        else:
            parts.append(f"src/{n}")
    joined = ", ".join(parts)
    if category == "screens":
        return f"{joined}  (or src/pages/ if that directory exists)"
    return joined


def copy_ui_unit_to_project(
    project_root: Path,
    framework: str,
    category: str,
    unit: str,
    token_map: dict[str, str] | None = None,
) -> tuple[list[Path], list[str]]:
    """
    Copy one registry unit from UI-TEMPLATES into project_root.
    Returns (written paths, errors).
    """
    ui_root = resolve_ui_templates_root()
    token_map = token_map or {}
    errors: list[str] = []
    written: list[Path] = []
    if framework == "flutter":
        sources = source_files_for_flutter_unit(ui_root, unit)
        if not sources:
            return [], [f"Missing Flutter template for unit {unit!r}"]
        src = sources[0]
        targets = flutter_target_paths(project_root, category, unit, src)
    else:
        sources = sorted(
            source_files_for_react_unit(ui_root, unit),
            key=lambda p: _source_name_sort_key(p.name),
        )
        if not sources:
            return [], [f"Missing React template for unit {unit!r}"]
        targets = react_target_paths_for_unit(project_root, category, unit, sources)
    for src_path, dst_path in zip(sources, targets, strict=True):
        if not src_path.is_file():
            errors.append(f"Missing source {src_path}")
            continue
        try:
            dst_path.parent.mkdir(parents=True, exist_ok=True)
            text = src_path.read_text(encoding="utf-8")
            for k, v in token_map.items():
                text = text.replace(f"{{{{{k}}}}}", v)
            dst_path.write_text(text, encoding="utf-8")
            written.append(dst_path)
        except OSError as exc:
            errors.append(f"{dst_path}: {exc}")
    return written, errors
