"""
Forge-Compliant Debug Output Interface

Structured output interface for successes/failures with composability
for dashboard/MCP integration and terminal display.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Union
from enum import Enum
from datetime import datetime
import json


class OutputFormat(Enum):
    """Supported output formats for composability."""
    TERMINAL = "terminal"
    JSON = "json"
    DASHBOARD = "dashboard"
    MCP = "mcp"


class SeverityLevel(Enum):
    """Severity levels for debug output."""
    SUCCESS = "success"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class ComponentType(Enum):
    """Forge component types for categorization."""
    SYSTEM = "system"
    HEALTH = "health"
    REALITY = "reality"
    GRAPH = "graph"
    MANIFEST = "manifest"
    EXECUTION = "execution"
    CONTRACT = "contract"
    DOCTOR = "doctor"
    RECOVERY = "recovery"


@dataclass
class DebugResult:
    """Individual debug result with structured data."""
    component: ComponentType
    operation: str
    severity: SeverityLevel
    message: str
    details: Optional[Dict[str, Any]] = None
    timestamp: datetime = field(default_factory=datetime.now)
    duration_ms: Optional[int] = None
    stack_trace: Optional[str] = None
    recommendations: List[str] = field(default_factory=list)
    
    @property
    def is_success(self) -> bool:
        """Check if result is successful."""
        return self.severity == SeverityLevel.SUCCESS
    
    @property
    def is_failure(self) -> bool:
        """Check if result is a failure."""
        return self.severity in [SeverityLevel.ERROR, SeverityLevel.CRITICAL]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "component": self.component.value,
            "operation": self.operation,
            "severity": self.severity.value,
            "message": self.message,
            "details": self.details,
            "timestamp": self.timestamp.isoformat(),
            "duration_ms": self.duration_ms,
            "stack_trace": self.stack_trace,
            "recommendations": self.recommendations,
            "is_success": self.is_success,
            "is_failure": self.is_failure
        }


@dataclass
class DebugSummary:
    """Summary statistics for debug session."""
    total_operations: int
    successful_operations: int
    failed_operations: int
    warnings: int
    critical_issues: int
    total_duration_ms: int
    components_tested: List[ComponentType]
    
    @property
    def success_rate(self) -> float:
        """Calculate success rate as percentage."""
        if self.total_operations == 0:
            return 0.0
        return (self.successful_operations / self.total_operations) * 100
    
    @property
    def health_status(self) -> str:
        """Overall health status based on results."""
        if self.critical_issues > 0:
            return "CRITICAL"
        elif self.failed_operations > 0:
            return "FAILED"
        elif self.warnings > 0:
            return "WARNING"
        else:
            return "HEALTHY"


@dataclass
class DebugSession:
    """Complete debug session with results and summary."""
    session_id: str
    project_path: str
    start_time: datetime = field(default_factory=datetime.now)
    end_time: Optional[datetime] = None
    results: List[DebugResult] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def add_result(self, result: DebugResult) -> None:
        """Add a result to the session."""
        self.results.append(result)
    
    def get_summary(self) -> DebugSummary:
        """Calculate summary statistics."""
        total_ops = len(self.results)
        successful_ops = len([r for r in self.results if r.is_success])
        failed_ops = len([r for r in self.results if r.is_failure])
        warnings = len([r for r in self.results if r.severity == SeverityLevel.WARNING])
        critical_issues = len([r for r in self.results if r.severity == SeverityLevel.CRITICAL])
        
        total_duration = sum(r.duration_ms or 0 for r in self.results)
        components_tested = list(set(r.component for r in self.results))
        
        return DebugSummary(
            total_operations=total_ops,
            successful_operations=successful_ops,
            failed_operations=failed_ops,
            warnings=warnings,
            critical_issues=critical_issues,
            total_duration_ms=total_duration,
            components_tested=components_tested
        )
    
    def finalize(self) -> None:
        """Mark session as complete."""
        self.end_time = datetime.now()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert session to dictionary for JSON serialization."""
        summary = self.get_summary()
        return {
            "session_id": self.session_id,
            "project_path": self.project_path,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "summary": {
                "total_operations": summary.total_operations,
                "successful_operations": summary.successful_operations,
                "failed_operations": summary.failed_operations,
                "warnings": summary.warnings,
                "critical_issues": summary.critical_issues,
                "success_rate": summary.success_rate,
                "health_status": summary.health_status,
                "total_duration_ms": summary.total_duration_ms,
                "components_tested": [c.value for c in summary.components_tested]
            },
            "results": [result.to_dict() for result in self.results],
            "metadata": self.metadata
        }


class DebugOutputFormatter:
    """Formats debug output for different targets (terminal, dashboard, MCP)."""
    
    @staticmethod
    def format_terminal(session: DebugSession) -> str:
        """Format output for terminal display."""
        summary = session.get_summary()
        
        lines = [
            f"🔍 FORGE DEBUG SESSION: {session.session_id}",
            f"📁 Project: {session.project_path}",
            f"⏱️  Duration: {summary.total_duration_ms}ms",
            f"📊 Success Rate: {summary.success_rate:.1f}%",
            f"🏥 Health Status: {summary.health_status}",
            "",
            f"📈 Operations: {summary.total_operations} total",
            f"  ✅ Success: {summary.successful_operations}",
            f"  ❌ Failed: {summary.failed_operations}",
            f"  ⚠️  Warnings: {summary.warnings}",
            f"  🚨 Critical: {summary.critical_issues}",
            ""
        ]
        
        # Component breakdown
        component_counts = {}
        for result in session.results:
            comp = result.component.value
            if comp not in component_counts:
                component_counts[comp] = {"success": 0, "failure": 0, "warning": 0}
            
            if result.is_success:
                component_counts[comp]["success"] += 1
            elif result.is_failure:
                component_counts[comp]["failure"] += 1
            elif result.severity == SeverityLevel.WARNING:
                component_counts[comp]["warning"] += 1
        
        if component_counts:
            lines.append("🔧 Component Breakdown:")
            for comp, counts in component_counts.items():
                total = counts["success"] + counts["failure"] + counts["warning"]
                lines.append(f"  {comp}: {total} ops ({counts['success']}✅ {counts['failure']}❌ {counts['warning']}⚠️)")
            lines.append("")
        
        # Show failures and warnings
        failures = [r for r in session.results if r.is_failure]
        warnings = [r for r in session.results if r.severity == SeverityLevel.WARNING]
        
        if failures:
            lines.append("🚨 FAILURES:")
            for result in failures[:5]:  # Show first 5
                lines.append(f"  ❌ {result.component.value}.{result.operation}: {result.message}")
                if result.recommendations:
                    for rec in result.recommendations[:2]:
                        lines.append(f"      💡 {rec}")
            if len(failures) > 5:
                lines.append(f"      ... and {len(failures) - 5} more failures")
            lines.append("")
        
        if warnings:
            lines.append("⚠️  WARNINGS:")
            for result in warnings[:3]:  # Show first 3
                lines.append(f"  ⚠️  {result.component.value}.{result.operation}: {result.message}")
            if len(warnings) > 3:
                lines.append(f"      ... and {len(warnings) - 3} more warnings")
            lines.append("")
        
        # Recommendations
        all_recommendations = []
        for result in session.results:
            all_recommendations.extend(result.recommendations)
        
        if all_recommendations:
            lines.append("💡 RECOMMENDATIONS:")
            for i, rec in enumerate(all_recommendations[:5]):
                lines.append(f"  {i+1}. {rec}")
            if len(all_recommendations) > 5:
                lines.append(f"  ... and {len(all_recommendations) - 5} more recommendations")
        
        return "\n".join(lines)
    
    @staticmethod
    def format_json(session: DebugSession) -> str:
        """Format output as JSON for machine consumption."""
        return json.dumps(session.to_dict(), indent=2)
    
    @staticmethod
    def format_dashboard(session: DebugSession) -> Dict[str, Any]:
        """Format output for dashboard display."""
        summary = session.get_summary()
        
        # Component health data
        component_health = {}
        for result in session.results:
            comp = result.component.value
            if comp not in component_health:
                component_health[comp] = {
                    "total": 0,
                    "success": 0,
                    "failure": 0,
                    "warning": 0,
                    "health_score": 0.0
                }
            
            component_health[comp]["total"] += 1
            if result.is_success:
                component_health[comp]["success"] += 1
            elif result.is_failure:
                component_health[comp]["failure"] += 1
            elif result.severity == SeverityLevel.WARNING:
                component_health[comp]["warning"] += 1
            
            # Calculate health score
            total = component_health[comp]["total"]
            if total > 0:
                component_health[comp]["health_score"] = (
                    (component_health[comp]["success"] / total) * 100
                )
        
        # Timeline data
        timeline = [
            {
                "timestamp": result.timestamp.isoformat(),
                "component": result.component.value,
                "operation": result.operation,
                "severity": result.severity.value,
                "message": result.message,
                "duration_ms": result.duration_ms
            }
            for result in session.results
        ]
        
        return {
            "session": {
                "id": session.session_id,
                "project_path": session.project_path,
                "start_time": session.start_time.isoformat(),
                "end_time": session.end_time.isoformat() if session.end_time else None,
                "summary": {
                    "success_rate": summary.success_rate,
                    "health_status": summary.health_status,
                    "total_operations": summary.total_operations,
                    "duration_ms": summary.total_duration_ms
                }
            },
            "components": component_health,
            "timeline": timeline,
            "issues": [
                {
                    "component": result.component.value,
                    "operation": result.operation,
                    "severity": result.severity.value,
                    "message": result.message,
                    "recommendations": result.recommendations
                }
                for result in session.results if result.is_failure or result.severity == SeverityLevel.WARNING
            ]
        }
    
    @staticmethod
    def format_mcp(session: DebugSession) -> Dict[str, Any]:
        """Format output for MCP response."""
        summary = session.get_summary()
        
        return {
            "type": "debug_session_result",
            "session_id": session.session_id,
            "success": summary.health_status == "HEALTHY",
            "summary": {
                "health_status": summary.health_status,
                "success_rate": summary.success_rate,
                "total_operations": summary.total_operations,
                "failed_operations": summary.failed_operations,
                "critical_issues": summary.critical_issues
            },
            "results": [
                {
                    "component": result.component.value,
                    "operation": result.operation,
                    "severity": result.severity.value,
                    "message": result.message,
                    "recommendations": result.recommendations
                }
                for result in session.results if result.is_failure or result.severity == SeverityLevel.WARNING
            ],
            "metadata": {
                "project_path": session.project_path,
                "duration_ms": summary.total_duration_ms,
                "components_tested": [c.value for c in summary.components_tested]
            }
        }


class DebugOutputInterface:
    """
    Main interface for Forge-compliant debug output.
    
    Provides structured, composable output for:
    - Terminal display with emojis and formatting
    - JSON serialization for machine consumption
    - Dashboard integration with component health data
    - MCP responses with structured data
    """
    
    def __init__(self, session_id: str, project_path: str):
        self.session = DebugSession(session_id=session_id, project_path=project_path)
        self.formatter = DebugOutputFormatter()
    
    def add_success(self, component: ComponentType, operation: str, message: str, 
                    details: Optional[Dict[str, Any]] = None, duration_ms: Optional[int] = None) -> None:
        """Add a successful result."""
        result = DebugResult(
            component=component,
            operation=operation,
            severity=SeverityLevel.SUCCESS,
            message=message,
            details=details,
            duration_ms=duration_ms
        )
        self.session.add_result(result)
    
    def add_failure(self, component: ComponentType, operation: str, message: str,
                    details: Optional[Dict[str, Any]] = None, duration_ms: Optional[int] = None,
                    stack_trace: Optional[str] = None, recommendations: List[str] = None) -> None:
        """Add a failure result."""
        result = DebugResult(
            component=component,
            operation=operation,
            severity=SeverityLevel.ERROR,
            message=message,
            details=details,
            duration_ms=duration_ms,
            stack_trace=stack_trace,
            recommendations=recommendations or []
        )
        self.session.add_result(result)
    
    def add_warning(self, component: ComponentType, operation: str, message: str,
                   details: Optional[Dict[str, Any]] = None, recommendations: List[str] = None) -> None:
        """Add a warning result."""
        result = DebugResult(
            component=component,
            operation=operation,
            severity=SeverityLevel.WARNING,
            message=message,
            details=details,
            recommendations=recommendations or []
        )
        self.session.add_result(result)
    
    def add_critical(self, component: ComponentType, operation: str, message: str,
                     details: Optional[Dict[str, Any]] = None, duration_ms: Optional[int] = None,
                     stack_trace: Optional[str] = None, recommendations: List[str] = None) -> None:
        """Add a critical result."""
        result = DebugResult(
            component=component,
            operation=operation,
            severity=SeverityLevel.CRITICAL,
            message=message,
            details=details,
            duration_ms=duration_ms,
            stack_trace=stack_trace,
            recommendations=recommendations or []
        )
        self.session.add_result(result)
    
    def finalize(self) -> None:
        """Finalize the debug session."""
        self.session.finalize()
    
    def get_output(self, format_type: OutputFormat = OutputFormat.TERMINAL) -> Union[str, Dict[str, Any]]:
        """Get formatted output for specified format."""
        if format_type == OutputFormat.TERMINAL:
            return self.formatter.format_terminal(self.session)
        elif format_type == OutputFormat.JSON:
            return self.formatter.format_json(self.session)
        elif format_type == OutputFormat.DASHBOARD:
            return self.formatter.format_dashboard(self.session)
        elif format_type == OutputFormat.MCP:
            return self.formatter.format_mcp(self.session)
        else:
            raise ValueError(f"Unsupported output format: {format_type}")


# Convenience functions for common use cases
def create_debug_session(project_path: str, session_id: Optional[str] = None) -> DebugOutputInterface:
    """Create a new debug session with auto-generated ID if not provided."""
    import uuid
    if session_id is None:
        session_id = str(uuid.uuid4())[:8]
    return DebugOutputInterface(session_id, project_path)
