"""Stack profile registry — Phase 1 typed-manifest boundary.

Canonical stack ids align with ``ManifestParser.get_stack`` labels and
``docs/phase-0/canonical-stack-ids.yaml``. Callers resolve a profile with
``get_stack_profile`` or ``profile_for_manifest_dict``; extend via
``register_stack_profile`` (tests / plugins).

Composite products (client + API + database + …) are modeled as multiple *layers*, each
with its own stack id and profile. This module registers ids per layer; a single manifest
may eventually expose several layers (submanifests / nested blocks). See
``docs/phase-1/composite-layers-submanifests.yaml``.

**Extensibility:** New stacks are **additive** — append a row in ``docs/phase-0/canonical-stack-ids.yaml``,
add a builtin in ``_install_builtin_profiles`` and/or call ``register_stack_profile`` (plugins),
and extend ``ManifestParser.get_stack`` so manifests resolve to the new id. Unregistered ids
fall back to ``UNKNOWN_STACK_PROFILE``. See ``docs/phase-1/extensibility-add-stack.yaml``.
"""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

import yaml

from forge.core.gloves import GLOVES


@dataclass(frozen=True, slots=True)
class ImpactRule:
    """Stack-aware impact hint keyed by manifest node kind + semantic effect."""

    node_kind: str
    effect: str
    checks: list[str]
    severity: str
    description: str


@runtime_checkable
class StackProfile(Protocol):
    """Behavior bundle for a manifest stack (template path, glove, schema slice)."""

    @property
    def id(self) -> str: ...

    @property
    def template_segment(self) -> str: ...

    @property
    def glove_key(self) -> str | None: ...

    @property
    def schema_stem(self) -> str | None: ...

    @property
    def impact_rules(self) -> Sequence[ImpactRule]: ...


WEB_IMPACT_RULES: tuple[ImpactRule, ...] = (
    ImpactRule(
        node_kind="module",
        effect="behavior_changed",
        checks=["import_consumers", "component_dependents"],
        severity="medium",
        description="Module behavior change: verify import consumers and component dependents",
    ),
    ImpactRule(
        node_kind="component",
        effect="behavior_changed",
        checks=["page_consumers", "layout_consumers"],
        severity="medium",
        description="Component behavior change: verify pages and layouts that use this component",
    ),
    ImpactRule(
        node_kind="page",
        effect="behavior_changed",
        checks=["route_integrity", "layout_consumers"],
        severity="low",
        description="Page behavior change: verify routing and layout",
    ),
    ImpactRule(
        node_kind="layout",
        effect="behavior_changed",
        checks=["page_consumers", "component_consumers"],
        severity="high",
        description="Layout behavior change: verify all pages and components using layout",
    ),
    ImpactRule(
        node_kind="route",
        effect="behavior_changed",
        checks=["api_consumers"],
        severity="high",
        description="Route behavior change: verify API consumers",
    ),
    ImpactRule(
        node_kind="domain",
        effect="behavior_changed",
        checks=["domain_members"],
        severity="medium",
        description="Domain behavior change: verify all domain members",
    ),
    ImpactRule(
        node_kind="service",
        effect="behavior_changed",
        checks=["component_consumers", "page_consumers"],
        severity="high",
        description="Service behavior change: verify all consumers",
    ),
    ImpactRule(
        node_kind="module",
        effect="schema_changed",
        checks=["import_consumers"],
        severity="high",
        description="Module schema change: verify all importers",
    ),
    ImpactRule(
        node_kind="component",
        effect="schema_changed",
        checks=["page_consumers", "layout_consumers", "prop_signatures"],
        severity="high",
        description="Component schema change: verify prop signatures and all consumers",
    ),
    ImpactRule(
        node_kind="config",
        effect="behavior_changed",
        checks=["propagate_to_consumers", "verify_stack_constraints"],
        severity="low",
        description=(
            "Config file change may affect "
            "build behavior and all pages "
            "that depend on stack settings."
        ),
    ),
)


GENERIC_IMPACT_RULES: list[ImpactRule] = [
    ImpactRule(
        node_kind="module",
        effect="behavior_changed",
        checks=["review_mcp_parity"],
        severity="medium",
        description="Module behavior change: review dependents and CLI/MCP parity",
    ),
    ImpactRule(
        node_kind="tool",
        effect="behavior_changed",
        checks=["review_mcp_parity"],
        severity="medium",
        description="Tool behavior change: review MCP handler parity",
    ),
    ImpactRule(
        node_kind="mcp_tool",
        effect="behavior_changed",
        checks=["review_mcp_parity"],
        severity="medium",
        description="MCP tool behavior change: review CLI parity",
    ),
    ImpactRule(
        node_kind="doc",
        effect="behavior_changed",
        checks=["review_docs_sync"],
        severity="low",
        description="Documentation node change: review MAP/MANIFEST sync",
    ),
    ImpactRule(
        node_kind="index",
        effect="behavior_changed",
        checks=["review_docs_sync"],
        severity="low",
        description="Index node change: review registry sync",
    ),
    ImpactRule(
        node_kind="controller",
        effect="behavior_changed",
        checks=["screen_dependents", "service_contracts"],
        severity="high",
        description="Controller behavior change: verify dependent screens and service contracts",
    ),
    ImpactRule(
        node_kind="model",
        effect="schema_changed",
        checks=["caller_signatures", "db_schema"],
        severity="high",
        description="Model schema change: verify all callers and DB schema parity",
    ),
    ImpactRule(
        node_kind="service",
        effect="api_changed",
        checks=["controller_consumers", "db_schema"],
        severity="high",
        description="Service API change: verify controller consumers and DB contracts",
    ),
    ImpactRule(
        node_kind="model",
        effect="behavior_changed",
        checks=["caller_signatures"],
        severity="medium",
        description="Model behavior change: verify caller signatures",
    ),
    ImpactRule(
        node_kind="pipeline",
        effect="behavior_changed",
        checks=["review_mcp_parity"],
        severity="medium",
        description="Pipeline step behavior change: review CLI/MCP parity",
    ),
    ImpactRule(
        node_kind="validator",
        effect="behavior_changed",
        checks=["review_mcp_parity"],
        severity="medium",
        description="Validator behavior change: review CLI/MCP parity",
    ),
]


@dataclass(frozen=True, slots=True)
class BuiltinStackProfile:
    """Concrete profile for built-in stacks (immutable, registry-safe)."""

    id: str
    template_segment: str
    glove_key: str | None
    schema_stem: str | None
    impact_rules: tuple[ImpactRule, ...] = field(default_factory=tuple)
    # Web manifests: ``()`` skips legacy screens/services/frontend-dict checks (node-graph style).
    # ``None`` keeps legacy :meth:`ManifestParser._validate_web` rules.
    manifest_required_sections: tuple[str, ...] | None = None
    display_name: str | None = None
    manifest_optional_sections: tuple[str, ...] = field(default_factory=tuple)
    node_kinds: tuple[str, ...] = field(default_factory=tuple)
    stack_labels: tuple[str, ...] = field(default_factory=tuple)

    def glove_registered(self) -> bool:
        """True if ``glove_key`` is non-empty and present in ``GLOVES``."""
        k = self.glove_key
        return bool(k) and k in GLOVES


STACK_PROFILES: dict[str, StackProfile] = {}


class StackProfileRegistry:
    """Registry for BuiltinStackProfile instances.

    Single source of truth for stack profiles. Supports manual registration,
    YAML discovery, and optional HookBus events on project-local overrides.
    """

    def __init__(self) -> None:
        self._profiles: dict[str, BuiltinStackProfile] = {}
        self._aliases: dict[str, str] = {}

    def register(
        self,
        profile: BuiltinStackProfile,
        *,
        allow_override: bool = False,
        emit_event: bool = False,
    ) -> None:
        key = _norm_stack_id(profile.id)
        if not key:
            raise ValueError("stack profile id must be non-empty")
        if key == "unknown":
            raise ValueError("id 'unknown' is reserved for UNKNOWN_STACK_PROFILE")
        if key in self._profiles and not allow_override:
            raise ValueError(f"profile already registered: {key!r}")
        self._profiles[key] = profile
        for label in profile.stack_labels or ():
            alias = _norm_stack_id(label)
            if alias != key and alias not in self._profiles:
                self._aliases[alias] = key
        if emit_event:
            self._emit_profile_registered(key)

    def get(self, stack_id: str) -> BuiltinStackProfile | None:
        key = _norm_stack_id(stack_id)
        if key in self._profiles:
            return self._profiles[key]
        canonical = self._aliases.get(key)
        if canonical:
            return self._profiles.get(canonical)
        return None

    def get_or_unknown(self, stack_id: str) -> BuiltinStackProfile:
        return self.get(stack_id) or UNKNOWN_STACK_PROFILE

    def get_glove(self, stack_id: str) -> Any | None:
        """Resolve a stack's glove_key to a live GloveProtocol instance."""
        profile = self.get(stack_id)
        if not profile:
            return None
        glove_key = profile.glove_key
        if not glove_key:
            return None
        try:
            from forge.protocols.registry import get_glove_registry

            glove_reg = get_glove_registry()
            return glove_reg.get(glove_key)
        except Exception:
            return None

    def list_profiles(self) -> list[BuiltinStackProfile]:
        return list(self._profiles.values())

    def list_ids(self) -> list[str]:
        return sorted(self._profiles.keys())

    def load_from_yaml_dir(
        self,
        schemas_dir: Path,
        *,
        glove_map: dict[str, str] | None = None,
        allow_override: bool = False,
    ) -> list[str]:
        """Discover and load all *.yaml files in schemas_dir as stack profiles."""
        loaded: list[str] = []
        glove_map = glove_map or {}
        for yaml_path in sorted(schemas_dir.glob("*.yaml")):
            if yaml_path.name.startswith("_"):
                continue
            try:
                glove_key = glove_map.get(yaml_path.stem)
                profile = stack_profile_from_yaml(yaml_path, glove_key=glove_key)
                if not any(r.node_kind != "*" for r in profile.impact_rules):
                    profile = replace(profile, impact_rules=WEB_IMPACT_RULES)
                self.register(
                    profile,
                    allow_override=allow_override,
                    emit_event=allow_override,
                )
                loaded.append(profile.id)
            except Exception:
                pass
        return loaded

    def to_summary_dict(self) -> dict[str, dict[str, Any]]:
        """Summary for MCP resource / debug."""
        return {
            pid: {
                "display_name": p.display_name,
                "glove_key": p.glove_key,
                "glove_available": self.get_glove(pid) is not None,
                "schema_stem": p.schema_stem,
                "impact_rules": len(p.impact_rules),
                "node_kinds": list(p.node_kinds),
                "stack_labels": list(p.stack_labels),
            }
            for pid, p in self._profiles.items()
        }

    @staticmethod
    def _emit_profile_registered(profile_id: str) -> None:
        try:
            from forge.events.schema import UniversalEvent
            from forge.events.bus import EventBus

            bus = EventBus(Path.cwd())
            bus.publish(
                UniversalEvent(
                    kind="profile_registered",
                    source_fqid="module/core.stack_profiles",
                    project=str(Path.cwd()),
                    payload={"stack": profile_id},
                )
            )
        except Exception:
            pass


_STACK_PROFILE_REGISTRY = StackProfileRegistry()


def get_stack_profile_registry() -> StackProfileRegistry:
    """Global stack profile registry (primary API for new code)."""
    return _STACK_PROFILE_REGISTRY


def get_glove_for_stack(stack_id: str) -> Any | None:
    """Get the GloveProtocol for a stack, or None if unavailable."""
    return _STACK_PROFILE_REGISTRY.get_glove(stack_id)


UNKNOWN_STACK_PROFILE = BuiltinStackProfile(
    id="unknown",
    template_segment="unknown",
    glove_key=None,
    schema_stem=None,
    impact_rules=(),
)


def get_impact_rules(stack_label: str) -> list[ImpactRule]:
    """Return universal rules plus stack-specific rules from the registry.

    Unknown stacks receive :data:`GENERIC_IMPACT_RULES` only.
    """
    prof = get_stack_profile(stack_label)
    base = list(GENERIC_IMPACT_RULES)
    if prof.id == "unknown":
        return base
    extra = getattr(prof, "impact_rules", None) or ()
    return base + list(extra)


def _norm_stack_id(stack_id: str) -> str:
    return str(stack_id or "").strip().lower().replace("_", "-")


def register_stack_profile(profile: StackProfile, *, allow_override: bool = False) -> None:
    """Register a profile under ``profile.id`` (normalized). Reserved: ``unknown``.

    Additive by default: duplicate ids raise unless ``allow_override=True``. Existing builtins
    stay stable; plugins register additional ids without replacing forge defaults.
    """
    if isinstance(profile, BuiltinStackProfile):
        _STACK_PROFILE_REGISTRY.register(profile, allow_override=allow_override)
        STACK_PROFILES[_norm_stack_id(profile.id)] = profile
        return
    key = _norm_stack_id(profile.id)
    if not key:
        raise ValueError("stack profile id must be non-empty")
    if key == "unknown":
        raise ValueError("id 'unknown' is reserved for UNKNOWN_STACK_PROFILE")
    if key in STACK_PROFILES and not allow_override:
        raise ValueError(f"stack profile already registered: {key!r}")
    STACK_PROFILES[key] = profile


def get_stack_profile(stack_id: str) -> StackProfile:
    """Return the registered profile or ``UNKNOWN_STACK_PROFILE``."""
    key = _norm_stack_id(stack_id)
    if not key:
        return UNKNOWN_STACK_PROFILE
    found = _STACK_PROFILE_REGISTRY.get(stack_id)
    if found is not None:
        return found
    legacy = STACK_PROFILES.get(key)
    if legacy is not None:
        return legacy
    return UNKNOWN_STACK_PROFILE


def profile_for_manifest_dict(data: dict[str, Any] | None) -> StackProfile:
    """Resolve profile from raw manifest YAML using ``ManifestParser.get_stack``."""
    from forge.core.manifest import ManifestParser

    label = ManifestParser.get_stack(data)
    return get_stack_profile(label)


def stack_profile_from_yaml(
    schema_path: Path,
    *,
    glove_key: str | None = None,
) -> BuiltinStackProfile:
    """Load a BuiltinStackProfile from a stack schema YAML file.

    The YAML is the log form (human-editable, version-controlled). The
    BuiltinStackProfile is the exp form (live, typed, validated).

    Bridge: YAML → Pydantic-validated profile.
    Inverse: stack_profile_to_yaml_dict() → YAML.
    """
    data = yaml.safe_load(schema_path.read_text(encoding="utf-8")) or {}

    stack_id = str(data.get("stack_id") or data.get("stack") or schema_path.stem)
    display_name = str(data.get("display_name") or stack_id)
    schema_stem = str(data.get("stack") or schema_path.stem)

    impact_rules: list[ImpactRule] = []
    for effect, rules in (data.get("impact_rules") or {}).items():
        for rule in rules or []:
            if not isinstance(rule, dict):
                continue
            impact_rules.append(
                ImpactRule(
                    node_kind=str(rule.get("node_kind", "*")),
                    effect=str(effect),
                    checks=list(rule.get("generates") or rule.get("checks") or []),
                    severity=str(rule.get("severity", "medium")),
                    description=str(
                        rule.get("description", "")
                        or f"{effect} on {rule.get('node_kind', '*')}"
                    ),
                )
            )

    node_kinds = tuple(str(k) for k in (data.get("allowed_node_kinds") or []))
    stack_labels = tuple([stack_id] + list(data.get("aliases") or []))

    return BuiltinStackProfile(
        id=stack_id,
        template_segment=str(data.get("template_segment") or schema_stem),
        glove_key=glove_key,
        schema_stem=schema_stem,
        impact_rules=tuple(impact_rules),
        display_name=display_name,
        node_kinds=node_kinds,
        stack_labels=stack_labels,
        manifest_required_sections=tuple(data.get("required_sections") or ()),
        manifest_optional_sections=tuple(data.get("allowed_sections") or ()),
    )


def stack_profile_to_yaml_dict(profile: BuiltinStackProfile) -> dict[str, Any]:
    """Serialize a BuiltinStackProfile to YAML-compatible dict (log form).

    Inverse of stack_profile_from_yaml().
    """
    impact_rules_dict: dict[str, list[dict[str, Any]]] = {}
    for rule in profile.impact_rules:
        if rule.effect not in impact_rules_dict:
            impact_rules_dict[rule.effect] = []
        impact_rules_dict[rule.effect].append(
            {
                "node_kind": rule.node_kind,
                "checks": list(rule.checks),
                "severity": rule.severity,
                "description": rule.description,
            }
        )
    return {
        "stack_id": profile.id,
        "display_name": profile.display_name,
        "schema_stem": profile.schema_stem,
        "glove_key": profile.glove_key,
        "allowed_node_kinds": list(profile.node_kinds),
        "allowed_sections": list(profile.manifest_optional_sections),
        "impact_rules": impact_rules_dict,
        "stack_labels": list(profile.stack_labels),
    }


def _effective_web_impact_rules(yaml_rules: tuple[ImpactRule, ...]) -> tuple[ImpactRule, ...]:
    """Use kind-specific rules for verify; YAML role-only rules fall back to WEB_IMPACT_RULES."""
    if yaml_rules and any(r.node_kind != "*" for r in yaml_rules):
        return yaml_rules
    return WEB_IMPACT_RULES


def _load_python_profile() -> BuiltinStackProfile:
    """Load python-cli profile from schemas/stacks/python.yaml if available."""
    try:
        schemas_dir = Path(__file__).resolve().parents[2] / "schemas" / "stacks"
        py_yaml = schemas_dir / "python.yaml"
        if py_yaml.is_file():
            loaded = stack_profile_from_yaml(py_yaml, glove_key="python")
            return BuiltinStackProfile(
                id="python-cli",
                template_segment="python-cli",
                glove_key="python",
                schema_stem="python",
                display_name=loaded.display_name or "Python CLI",
                impact_rules=loaded.impact_rules
                or (
                    ImpactRule(
                        node_kind="command",
                        effect="behavior_changed",
                        checks=["mcp_parity"],
                        severity="medium",
                        description="Command behavior change: verify MCP tool parity",
                    ),
                ),
                node_kinds=loaded.node_kinds
                or (
                    "module",
                    "command",
                    "tool",
                    "checker",
                    "renderer",
                    "schema",
                    "test",
                ),
            )
    except Exception:
        pass
    return BuiltinStackProfile(
        id="python-cli",
        template_segment="python-cli",
        glove_key="python",
        schema_stem="python",
        node_kinds=(
            "module",
            "command",
            "tool",
            "checker",
            "renderer",
            "schema",
            "test",
        ),
        impact_rules=(
            ImpactRule(
                node_kind="command",
                effect="behavior_changed",
                checks=["mcp_parity"],
                severity="medium",
                description="Command behavior change: verify MCP tool parity",
            ),
        ),
    )


def _load_dart_profile() -> BuiltinStackProfile:
    """Load flutter-app profile from schemas/stacks/dart.yaml if available."""
    try:
        schemas_dir = Path(__file__).resolve().parents[2] / "schemas" / "stacks"
        dart_yaml = schemas_dir / "dart.yaml"
        if dart_yaml.is_file():
            loaded = stack_profile_from_yaml(dart_yaml, glove_key="dart")
            return BuiltinStackProfile(
                id="flutter-app",
                template_segment=loaded.template_segment or "dart",
                glove_key="dart",
                schema_stem="dart",
                display_name=loaded.display_name or "Flutter App",
                impact_rules=loaded.impact_rules
                or (
                    ImpactRule(
                        node_kind="screen",
                        effect="behavior_changed",
                        checks=["variant_consistency"],
                        severity="low",
                        description="Screen behavior change: verify variant UI consistency",
                    ),
                ),
                node_kinds=loaded.node_kinds
                or (
                    "module",
                    "screen",
                    "controller",
                    "service",
                    "widget",
                    "route",
                    "test",
                ),
            )
    except Exception:
        pass
    return BuiltinStackProfile(
        id="flutter-app",
        template_segment="dart",
        glove_key="dart",
        schema_stem="dart",
        node_kinds=(
            "module",
            "screen",
            "controller",
            "service",
            "widget",
            "route",
            "test",
        ),
        impact_rules=(
            ImpactRule(
                node_kind="screen",
                effect="behavior_changed",
                checks=["variant_consistency"],
                severity="low",
                description="Screen behavior change: verify variant UI consistency",
            ),
        ),
    )


def _load_web_profile() -> BuiltinStackProfile:
    """Load web stack profile from schemas/stacks/web.yaml if available, else hardcoded."""
    try:
        schemas_dir = Path(__file__).resolve().parents[2] / "schemas" / "stacks"
        web_yaml = schemas_dir / "web.yaml"
        if web_yaml.is_file():
            loaded = stack_profile_from_yaml(web_yaml, glove_key="react")
            return BuiltinStackProfile(
                id="web",
                template_segment=loaded.template_segment or "web-react",
                glove_key="react",
                schema_stem="web",
                display_name=loaded.display_name or "Web (generic)",
                manifest_required_sections=(),
                manifest_optional_sections=loaded.manifest_optional_sections or ("nodes", "edges"),
                node_kinds=loaded.node_kinds
                or (
                    "module",
                    "domain",
                    "component",
                    "page",
                    "layout",
                    "route",
                    "service",
                    "schema",
                    "content",
                ),
                stack_labels=("web", "frontend"),
                impact_rules=_effective_web_impact_rules(loaded.impact_rules),
            )
    except Exception:
        pass
    return BuiltinStackProfile(
        id="web",
        template_segment="web-react",
        glove_key="react",
        schema_stem="web",
        display_name="Web (generic)",
        manifest_required_sections=(),
        manifest_optional_sections=("nodes", "edges"),
        node_kinds=(
            "module",
            "domain",
            "component",
            "page",
            "layout",
            "route",
            "service",
            "schema",
            "content",
        ),
        stack_labels=("web", "frontend"),
        impact_rules=WEB_IMPACT_RULES,
    )


def _builtin_profiles() -> dict[str, BuiltinStackProfile]:
    return {
        "python-cli": _load_python_profile(),
        "flutter-app": _load_dart_profile(),
        "web-react": BuiltinStackProfile(
            id="web-react",
            template_segment="web-react",
            glove_key="react",
            schema_stem="web",
            manifest_required_sections=(),
            manifest_optional_sections=("nodes", "edges"),
            node_kinds=(
                "module",
                "domain",
                "component",
                "page",
                "layout",
                "route",
                "service",
                "schema",
                "content",
            ),
            stack_labels=("web-react", "react"),
            impact_rules=WEB_IMPACT_RULES,
        ),
        "web-next": BuiltinStackProfile(
            id="web-next",
            template_segment="web-next",
            glove_key="react",
            schema_stem="web",
            manifest_required_sections=(),
            manifest_optional_sections=("nodes", "edges"),
            node_kinds=(
                "module",
                "domain",
                "component",
                "page",
                "layout",
                "route",
                "service",
                "schema",
                "content",
            ),
            stack_labels=("web-next", "next", "nextjs"),
            impact_rules=WEB_IMPACT_RULES,
        ),
        "web": _load_web_profile(),
        "astro": BuiltinStackProfile(
            id="astro",
            template_segment="web-react",
            glove_key="astro",
            schema_stem="web",
            manifest_required_sections=(),
            display_name="Astro (Web)",
            manifest_optional_sections=("nodes", "edges"),
            node_kinds=(
                "module",
                "domain",
                "doc",
                "component",
                "route",
                "content-schema",
                "layout",
                "page",
                "service",
                "schema",
            ),
            stack_labels=("astro", "web", "frontend"),
            impact_rules=WEB_IMPACT_RULES,
        ),
    }


def _install_builtin_profiles() -> None:
    global STACK_PROFILES
    builtins = _builtin_profiles()
    STACK_PROFILES = {}
    _STACK_PROFILE_REGISTRY._profiles.clear()
    _STACK_PROFILE_REGISTRY._aliases.clear()
    for key, prof in builtins.items():
        _STACK_PROFILE_REGISTRY.register(prof, allow_override=True)
        STACK_PROFILES[key] = prof


_install_builtin_profiles()
