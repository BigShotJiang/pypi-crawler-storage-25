"""Cross-project workspace contract checks — Sprint 10 Phase 4."""

from __future__ import annotations

from typing import Any

from forge.core.workspace_entity import ForgeWorkspace
def projects_requiring_contract(ws: ForgeWorkspace, contract_id: str) -> list[str]:
    cid = str(contract_id).strip()
    if not cid:
        return []
    hits: list[str] = []
    for pid, fp in ws.projects.items():
        if cid in tuple(str(x) for x in fp.requires):
            hits.append(pid)
    return sorted(hits)


def verify_workspace_contracts(ws: ForgeWorkspace) -> list[dict[str, Any]]:
    """Emit verify-shaped rows for missing contract definitions or missing providers."""
    failures: list[dict[str, Any]] = []
    providers: dict[str, str] = {}
    for pid, fp in ws.projects.items():
        for raw in fp.exposes:
            cid = str(raw).strip()
            if not cid:
                continue
            providers.setdefault(cid, pid)

    for pid, fp in ws.projects.items():
        for raw in fp.requires:
            cid = str(raw).strip()
            if not cid:
                continue
            if cid not in ws.contracts:
                failures.append(
                    {
                        "kind": "workspace-contract-missing-definition",
                        "severity": "error",
                        "message": f"project {pid!r} requires contract {cid!r} but no workspace definition exists",
                        "node": pid,
                        "adr": "Sprint-10",
                    }
                )
                continue
            if cid not in providers:
                affected = ",".join(projects_requiring_contract(ws, cid)) or "(none)"
                failures.append(
                    {
                        "kind": "workspace-contract-unprovisioned",
                        "severity": "error",
                        "message": (
                            f"project {pid!r} requires contract {cid!r} without a declaring exposer "
                            f"(requiring_projects={affected})"
                        ),
                        "node": pid,
                        "adr": "Sprint-10",
                    }
                )
    return failures
