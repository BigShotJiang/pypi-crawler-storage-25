"""
Dynamic template and meta-resource system for Forge extensibility.

Integrates with existing MCP glove template registry to avoid reinventing the wheel.
"""

import yaml
from pathlib import Path
from typing import Dict, Any, List, Optional
import logging

logger = logging.getLogger(__name__)

# Import existing MCP glove template registry
try:
    from forge.tools.glove_templates.registry import (
        gloves_templates_root,
        resolve_schema_yaml_path,
        validate_template_extensions
    )
    MCP_GLOVE_REGISTRY_AVAILABLE = True
except ImportError:
    MCP_GLOVE_REGISTRY_AVAILABLE = False
    logger.warning("MCP glove template registry not available, using fallback")


class TemplateGenerator:
    """Dynamic template generator for extensible stack support."""
    
    def __init__(self, forge_root: Path):
        self.forge_root = forge_root
        
        # Use MCP glove registry paths if available
        if MCP_GLOVE_REGISTRY_AVAILABLE:
            self.gloves_dir = gloves_templates_root()
        else:
            self.gloves_dir = forge_root / ".forge" / "gloves"
        
        self.templates_dir = forge_root / ".forge" / "templates"
        self.meta_resources_dir = forge_root / ".forge" / "meta"
        
        # Ensure directories exist
        self.templates_dir.mkdir(parents=True, exist_ok=True)
        self.gloves_dir.mkdir(parents=True, exist_ok=True)
        self.meta_resources_dir.mkdir(parents=True, exist_ok=True)
    
    def create_stack_template(self, stack_id: str, config: Dict[str, Any]) -> bool:
        """Create a new stack template dynamically."""
        try:
            # Generate glove configuration
            glove_config = self._generate_glove_config(stack_id, config)
            glove_path = self.gloves_dir / f"{stack_id}.glove.yaml"
            
            with open(glove_path, 'w') as f:
                yaml.dump(glove_config, f, default_flow_style=False)
            
            # Generate import parser template
            parser_template = self._generate_parser_template(stack_id, config)
            parser_path = self.templates_dir / f"{stack_id}_parser.py"
            
            with open(parser_path, 'w') as f:
                f.write(parser_template)
            
            # Generate meta-resources
            self._generate_meta_resources(stack_id, config)
            
            logger.info(f"Created stack template: {stack_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to create stack template {stack_id}: {e}")
            return False
    
    def _generate_glove_config(self, stack_id: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate glove configuration for new stack."""
        base_config = {
            'stack': {
                'id': stack_id,
                'description': config.get('description', f'{stack_id} stack'),
                'version': '1.0.0'
            },
            'domains': config.get('domains', ['CORE']),
            'node_types': {},
            'contracts': {},
            'import_patterns': config.get('import_patterns', []),
            'file_extensions': config.get('file_extensions', []),
            'indicators': config.get('indicators', [])
        }
        
        # Add node types from config
        for node_type, node_config in config.get('node_types', {}).items():
            base_config['node_types'][node_type] = {
                'allowed_deps': node_config.get('allowed_deps', []),
                'forbidden_deps': node_config.get('forbidden_deps', []),
                'required_contracts': node_config.get('required_contracts', []),
                'output_paths': node_config.get('output_paths', [])
            }
        
        # Add contracts from config
        for contract_id, contract_config in config.get('contracts', {}).items():
            base_config['contracts'][contract_id] = contract_config
        
        return base_config
    
    def _generate_parser_template(self, stack_id: str, config: Dict[str, Any]) -> str:
        """Generate import parser template for new stack."""
        template = f'''"""
Import parser template for {stack_id} stack.

Generated dynamically by Forge template system.
"""

import re
from typing import List
from ..import_parser import ImportStatement


def parse_{stack_id}_imports(content: str, glove_config: dict) -> List[ImportStatement]:
    """Parse imports for {stack_id} stack."""
    imports = []
    lines = content.split('\\n')
    
    # Import patterns from glove config
    import_patterns = glove_config.get('import_patterns', [])
    
    if not import_patterns:
        # Default pattern matching
        import_patterns = [
            r'import\\s+(?:[\\'"])(.+?)(?:[\\'"])',  # Basic import
            r'from\\s+(?:[\\'"])(.+?)(?:[\\'"])',  # From import
        ]
    
    for line_num, line in enumerate(lines, 1):
        line = line.strip()
        
        for pattern in import_patterns:
            match = re.search(pattern, line)
            if match:
                module = match.group(1)
                imports.append(ImportStatement(
                    module=module,
                    alias=None,
                    line=line_num,
                    type='import'
                ))
                break
    
    return imports


def detect_{stack_id}_stack(project_root: Path, glove_config: dict) -> bool:
    """Detect if project uses {stack_id} stack."""
    indicators = glove_config.get('indicators', [])
    
    for indicator in indicators:
        if (project_root / indicator).exists():
            return True
    
    return False
'''
        return template
    
    def _generate_meta_resources(self, stack_id: str, config: Dict[str, Any]) -> None:
        """Generate meta-resources for new stack."""
        # Create stack-specific meta-resources
        meta_config = {
            'stack_id': stack_id,
            'description': config.get('description', ''),
            'created_at': 'auto-generated',
            'health_metrics': config.get('health_metrics', {}),
            'validation_rules': config.get('validation_rules', [])
        }
        
        meta_path = self.meta_resources_dir / f"{stack_id}_meta.yaml"
        with open(meta_path, 'w') as f:
            yaml.dump(meta_config, f, default_flow_style=False)
    
    def list_available_stacks(self) -> List[str]:
        """List all available stack templates using MCP glove registry."""
        stacks = []
        
        if MCP_GLOVE_REGISTRY_AVAILABLE:
            # Use MCP glove registry discovery
            try:
                from forge.tools.glove_templates.registry import registry as glove_registry
                for _path, _tier, data in glove_registry.discover_templates():
                    if data and data.get("stack"):
                        stacks.append(data["stack"])
            except Exception as e:
                logger.debug(f"MCP glove registry discovery failed: {e}")
        
        # Fallback to local glove configs
        if not stacks:
            for glove_file in self.gloves_dir.glob("*.glove.yaml"):
                stacks.append(glove_file.stem)
        
        return sorted(list(set(stacks)))  # Remove duplicates
    
    def get_stack_config(self, stack_id: str) -> Optional[Dict[str, Any]]:
        """Get configuration for a specific stack using MCP glove registry."""
        if MCP_GLOVE_REGISTRY_AVAILABLE:
            try:
                from forge.tools.glove_templates.registry import registry as glove_registry
                # Try to find template in MCP registry
                hit = glove_registry.find_template_for_kind_stack("module", stack_id)
                if hit:
                    path, data = hit
                    return data
            except Exception as e:
                logger.debug(f"MCP glove registry lookup failed for {stack_id}: {e}")
        
        # Fallback to local glove configs
        glove_path = self.gloves_dir / f"{stack_id}.glove.yaml"
        if glove_path.exists():
            try:
                with open(glove_path) as f:
                    return yaml.safe_load(f)
            except Exception as e:
                logger.error(f"Failed to load stack config {stack_id}: {e}")
        
        return None
    
    def register_stack_indicators(self, stack_id: str, indicators: List[str]) -> bool:
        """Register new indicators for stack detection."""
        try:
            config = self.get_stack_config(stack_id)
            if not config:
                return False
            
            config.setdefault('indicators', []).extend(indicators)
            
            glove_path = self.gloves_dir / f"{stack_id}.glove.yaml"
            with open(glove_path, 'w') as f:
                yaml.dump(config, f, default_flow_style=False)
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to register indicators for {stack_id}: {e}")
            return False
    
    def create_stack_from_example(self, stack_id: str, example_config: Dict[str, Any]) -> bool:
        """Create new stack from example configuration."""
        return self.create_stack_template(stack_id, example_config)


# Example stack configurations for common stacks
EXAMPLE_STACKS = {
    'rust': {
        'description': 'Rust programming language stack',
        'file_extensions': ['.rs'],
        'indicators': ['Cargo.toml', 'Cargo.lock', 'src/'],
        'import_patterns': [
            r'use\\s+(.+?);',
            r'mod\\s+(.+?);',
            r'extern\\s+crate\\s+(.+?);'
        ],
        'node_types': {
            'module': {
                'output_paths': ['src/{name}.rs']
            },
            'library': {
                'output_paths': ['src/lib.rs']
            }
        }
    },
    
    'typescript': {
        'description': 'TypeScript/JavaScript stack',
        'file_extensions': ['.ts', '.tsx', '.js', '.jsx'],
        'indicators': ['package.json', 'tsconfig.json', 'node_modules/'],
        'import_patterns': [
            r'import\\s+.+?\\s+from\\s+[\'"](.+?)[\'"]',
            r'import\\s+[\'"](.+?)[\'"]',
            r'require\\s*\([\'"](.+?)[\'"]\)'
        ],
        'node_types': {
            'component': {
                'output_paths': ['src/{name}.tsx']
            },
            'service': {
                'output_paths': ['src/services/{name}.ts']
            }
        }
    },
    
    'go': {
        'description': 'Go programming language stack',
        'file_extensions': ['.go'],
        'indicators': ['go.mod', 'go.sum', 'main.go'],
        'import_patterns': [
            r'import\\s+[\'"](.+?)[\'"]',
            r'import\\s+\(.+?\)'
        ],
        'node_types': {
            'package': {
                'output_paths': ['{name}/{name}.go']
            }
        }
    }
}
