"""Vector Memory Layer for INTENT-BEAA7B96.

Complements the deterministic manifest graph with fuzzy semantic recall.
Provides vector embeddings for design rationale, history, and context.
"""

import json
import logging
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
from uuid import uuid4

import numpy as np

from forge.core.event_log import get_event_log, EventEntry, EventType
from forge.core.execution_graph import get_execution_manager, ExecutionResult
from forge.core.path_utils import resolve_project_path

logger = logging.getLogger(__name__)


@dataclass
class VectorMemoryEntry:
    """A single entry in the vector memory store."""
    id: str = field(default_factory=lambda: str(uuid4()))
    content: str = ""
    content_type: str = ""  # "intent", "annotation", "event", "execution_result", "adr", "note"
    source_id: Optional[str] = None  # Link to source entity
    metadata: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None
    timestamp: float = field(default_factory=time.time)
    iso_timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    project_path: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage."""
        data = asdict(self)
        # Don't store embedding in dict if None
        if data["embedding"] is None:
            del data["embedding"]
        return data
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "VectorMemoryEntry":
        """Create from dictionary."""
        return cls(**data)


@dataclass
class VectorSearchResult:
    """Result from vector similarity search."""
    entry: VectorMemoryEntry
    similarity_score: float
    relevance_rank: int


class EmbeddingProvider:
    """Abstract base for embedding providers."""
    
    def embed(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for a list of texts."""
        raise NotImplementedError
    
    def embed_single(self, text: str) -> List[float]:
        """Generate embedding for a single text."""
        return self.embed([text])[0]


class SimpleEmbeddingProvider(EmbeddingProvider):
    """Simple embedding provider using TF-IDF and dimensionality reduction.
    
    This is a fallback implementation that doesn't require external APIs.
    For production, replace with OpenAI, SentenceTransformers, or similar.
    """
    
    def __init__(self, embedding_dim: int = 384):
        self.embedding_dim = embedding_dim
        self._vocabulary: Dict[str, int] = {}
        self._idf_cache: Dict[str, float] = {}
        self._initialized = False
    
    def _initialize_vocabulary(self, texts: List[str]) -> None:
        """Initialize vocabulary from training texts."""
        from collections import Counter
        import math
        
        # Count word frequencies
        word_counts = Counter()
        doc_count = len(texts)
        
        for text in texts:
            words = self._tokenize(text)
            unique_words = set(words)
            for word in unique_words:
                word_counts[word] += 1
        
        # Calculate IDF and assign vocabulary indices
        for i, (word, count) in enumerate(word_counts.most_common(10000)):  # Top 10k words
            self._vocabulary[word] = i
            self._idf_cache[word] = math.log(doc_count / (count + 1))
        
        self._initialized = True
    
    def _tokenize(self, text: str) -> List[str]:
        """Simple tokenization."""
        import re
        # Lowercase, remove punctuation, split on whitespace
        words = re.findall(r'\b\w+\b', text.lower())
        return words
    
    def _tfidf_vector(self, text: str) -> List[float]:
        """Convert text to TF-IDF vector."""
        if not self._initialized:
            return [0.0] * self.embedding_dim
        
        words = self._tokenize(text)
        word_counts = {}
        
        # Count word frequencies
        for word in words:
            word_counts[word] = word_counts.get(word, 0) + 1
        
        # Create TF-IDF vector
        vector = [0.0] * len(self._vocabulary)
        vocab_size = len(self._vocabulary)
        
        for word, count in word_counts.items():
            if word in self._vocabulary:
                idx = self._vocabulary[word]
                tf = count / len(words)
                idf = self._idf_cache[word]
                vector[idx] = tf * idf
                
        # Pad or truncate to embedding_dim
        if vocab_size < self.embedding_dim:
            vector.extend([0.0] * (self.embedding_dim - vocab_size))
        else:
            vector = vector[:self.embedding_dim]
        
        # Normalize
        norm = sum(x * x for x in vector) ** 0.5
        if norm > 0:
            vector = [x / norm for x in vector]
        
        return vector
    
    def embed(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for texts."""
        if not texts:
            return []
        
        # Initialize vocabulary if needed
        if not self._initialized:
            self._initialize_vocabulary(texts)
        
        return [self._tfidf_vector(text) for text in texts]


class VectorMemoryStore:
    """Vector memory store for semantic search and fuzzy recall."""
    
    def __init__(self, project_path: Path, embedding_provider: Optional[EmbeddingProvider] = None):
        self.project_path = project_path
        self.memory_dir = project_path / ".forge" / "memory"
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        
        self.memory_file = self.memory_dir / "vectors.jsonl"
        self.index_file = self.memory_dir / "index.json"
        
        self.embedding_provider = embedding_provider or SimpleEmbeddingProvider()
        self._entries: Dict[str, VectorMemoryEntry] = {}
        self._embeddings: Dict[str, List[float]] = {}
        
        self._load_store()
    
    def _load_store(self) -> None:
        """Load existing entries from storage."""
        try:
            # Load entries
            if self.memory_file.exists():
                with open(self.memory_file, 'r') as f:
                    for line in f:
                        try:
                            data = json.loads(line.strip())
                            entry = VectorMemoryEntry.from_dict(data)
                            self._entries[entry.id] = entry
                            if entry.embedding:
                                self._embeddings[entry.id] = entry.embedding
                        except (json.JSONDecodeError, KeyError):
                            continue
            
            # Load index
            if self.index_file.exists():
                with open(self.index_file, 'r') as f:
                    index_data = json.load(f)
                    # Update embedding provider if needed
                    if "vocabulary" in index_data and hasattr(self.embedding_provider, '_vocabulary'):
                        self.embedding_provider._vocabulary = index_data["vocabulary"]
                        self.embedding_provider._idf_cache = index_data.get("idf_cache", {})
                        self.embedding_provider._initialized = True
            
            logger.info(f"Loaded {len(self._entries)} vector memory entries")
            
        except Exception as e:
            logger.error(f"Failed to load vector memory store: {e}")
    
    def _save_store(self) -> None:
        """Save entries to storage."""
        try:
            # Save entries
            with open(self.memory_file, 'w') as f:
                for entry in self._entries.values():
                    f.write(json.dumps(entry.to_dict()) + '\n')
            
            # Save index
            index_data = {
                "total_entries": len(self._entries),
                "last_updated": time.time(),
                "embedding_dim": self.embedding_provider.embedding_dim
            }
            
            # Save vocabulary if available
            if hasattr(self.embedding_provider, '_vocabulary') and self.embedding_provider._initialized:
                index_data["vocabulary"] = self.embedding_provider._vocabulary
                index_data["idf_cache"] = self.embedding_provider._idf_cache
            
            with open(self.index_file, 'w') as f:
                json.dump(index_data, f, indent=2)
                
        except Exception as e:
            logger.error(f"Failed to save vector memory store: {e}")
    
    def add_entry(self, content: str, content_type: str, source_id: Optional[str] = None, 
                 metadata: Optional[Dict[str, Any]] = None) -> str:
        """Add a new entry to the vector memory store."""
        try:
            entry = VectorMemoryEntry(
                content=content,
                content_type=content_type,
                source_id=source_id,
                metadata=metadata or {},
                project_path=str(self.project_path)
            )
            
            # Generate embedding
            embedding = self.embedding_provider.embed_single(content)
            entry.embedding = embedding
            
            # Store entry
            self._entries[entry.id] = entry
            self._embeddings[entry.id] = embedding
            
            # Save to storage
            self._save_store()
            
            logger.info(f"Added vector memory entry: {entry.id} ({content_type})")
            return entry.id
            
        except Exception as e:
            logger.error(f"Failed to add vector memory entry: {e}")
            raise
    
    def search(self, query: str, limit: int = 10, content_type_filter: Optional[str] = None,
               similarity_threshold: float = 0.1) -> List[VectorSearchResult]:
        """Search for similar entries using vector similarity."""
        try:
            if not self._entries:
                return []
            
            # Generate query embedding
            query_embedding = self.embedding_provider.embed_single(query)
            
            # Calculate similarities
            results = []
            for entry_id, embedding in self._embeddings.items():
                entry = self._entries[entry_id]
                
                # Apply content type filter
                if content_type_filter and entry.content_type != content_type_filter:
                    continue
                
                # Calculate cosine similarity
                similarity = self._cosine_similarity(query_embedding, embedding)
                
                if similarity >= similarity_threshold:
                    results.append(VectorSearchResult(
                        entry=entry,
                        similarity_score=similarity,
                        relevance_rank=0  # Will be set after sorting
                    ))
            
            # Sort by similarity and assign ranks
            results.sort(key=lambda r: r.similarity_score, reverse=True)
            for i, result in enumerate(results[:limit]):
                result.relevance_rank = i + 1
            
            return results[:limit]
            
        except Exception as e:
            logger.error(f"Failed to search vector memory: {e}")
            return []
    
    def _cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """Calculate cosine similarity between two vectors."""
        if len(vec1) != len(vec2):
            return 0.0
        
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        norm1 = sum(a * a for a in vec1) ** 0.5
        norm2 = sum(b * b for b in vec2) ** 0.5
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        return dot_product / (norm1 * norm2)
    
    def get_entry(self, entry_id: str) -> Optional[VectorMemoryEntry]:
        """Get a specific entry by ID."""
        return self._entries.get(entry_id)
    
    def get_recent_entries(self, limit: int = 50, content_type_filter: Optional[str] = None) -> List[VectorMemoryEntry]:
        """Get recent entries."""
        entries = list(self._entries.values())
        
        if content_type_filter:
            entries = [e for e in entries if e.content_type == content_type_filter]
        
        # Sort by timestamp (newest first) and limit
        entries.sort(key=lambda e: e.timestamp, reverse=True)
        return entries[:limit]
    
    def get_stats(self) -> Dict[str, Any]:
        """Get statistics about the vector memory store."""
        content_type_counts = {}
        for entry in self._entries.values():
            content_type_counts[entry.content_type] = content_type_counts.get(entry.content_type, 0) + 1
        
        return {
            "total_entries": len(self._entries),
            "content_types": content_type_counts,
            "embedding_dim": self.embedding_provider.embedding_dim,
            "last_updated": max((e.timestamp for e in self._entries.values()), default=0)
        }


# Global vector memory stores
_vector_stores: Dict[str, VectorMemoryStore] = {}


def get_vector_memory_store(project_path: Path, embedding_provider: Optional[EmbeddingProvider] = None) -> VectorMemoryStore:
    """Get or create a vector memory store for a project."""
    project_key = str(project_path.resolve())
    if project_key not in _vector_stores:
        _vector_stores[project_key] = VectorMemoryStore(project_path, embedding_provider)
    return _vector_stores[project_key]


def auto_embed_content(content: str, content_type: str, source_id: Optional[str] = None,
                      metadata: Optional[Dict[str, Any]] = None, project_path: Optional[str] = None) -> Optional[str]:
    """Automatically embed content and add to vector memory."""
    try:
        if not project_path:
            project_path = str(resolve_project_path())
        
        store = get_vector_memory_store(Path(project_path))
        entry_id = store.add_entry(content, content_type, source_id, metadata)
        
        logger.info(f"Auto-embedded content: {entry_id} ({content_type})")
        return entry_id
        
    except Exception as e:
        logger.error(f"Failed to auto-embed content: {e}")
        return None


def search_memory(query: str, limit: int = 10, content_type_filter: Optional[str] = None,
                 project_path: Optional[str] = None) -> List[VectorSearchResult]:
    """Search vector memory for similar content."""
    try:
        if not project_path:
            project_path = str(resolve_project_path())
        
        store = get_vector_memory_store(Path(project_path))
        return store.search(query, limit, content_type_filter)
        
    except Exception as e:
        logger.error(f"Failed to search vector memory: {e}")
        return []


__all__ = [
    "VectorMemoryEntry",
    "VectorSearchResult", 
    "EmbeddingProvider",
    "SimpleEmbeddingProvider",
    "VectorMemoryStore",
    "get_vector_memory_store",
    "auto_embed_content",
    "search_memory"
]
