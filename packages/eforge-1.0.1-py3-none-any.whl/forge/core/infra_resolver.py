from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse

from forge.core.checker_context import CheckerContext, build_checker_context
from forge.core.checks import CheckResult, DashboardCheck
from forge.core.manifest_document import ManifestDocument, project_root_for_manifest_file


@dataclass(frozen=True, slots=True)
class InfraRef:
    """One infrastructure ref string with its declaring scope (manifest root or layer id)."""

    ref: str
    source_id: str


def _refs_from_infrastructure_value(infra: Any) -> list[str]:
    """Parse the ``infrastructure`` manifest value into ref strings (list / dict / str)."""
    if infra is None:
        return []
    if isinstance(infra, list):
        return [str(x).strip() for x in infra if str(x).strip()]
    if isinstance(infra, dict):
        refs = infra.get("refs")
        if isinstance(refs, list):
            return [str(x).strip() for x in refs if str(x).strip()]
        out: list[str] = []
        for value in infra.values():
            if isinstance(value, str) and value.strip():
                out.append(value.strip())
        return out
    if isinstance(infra, str) and infra.strip():
        return [infra.strip()]
    return []


def _extract_from_raw(raw: dict[str, Any], source_id: str) -> list[InfraRef]:
    return [InfraRef(ref=r, source_id=source_id) for r in _refs_from_infrastructure_value(raw.get("infrastructure"))]


def _extract_infra_refs(doc: ManifestDocument) -> list[InfraRef]:
    out: list[InfraRef] = []
    out.extend(_extract_from_raw(doc.raw, "manifest"))
    for layer in doc.layers:
        out.extend(_extract_from_raw(layer.raw, layer.id))
    return out


def _normalize_ref_key(ref: str) -> str:
    v = ref.strip()
    if not v:
        return ""
    if "://" in v:
        parsed = urlparse(v)
        host = parsed.netloc.lower()
        path = parsed.path.rstrip("/")
        return f"{host}{path}"
    return v.lower().rstrip("/")


def _checker_name_for_ref(ref: str) -> str | None:
    v = ref.strip().lower()
    if v.startswith("http://") or v.startswith("https://"):
        return "http_ping"
    if v.startswith("vercel:"):
        return "vercel_status"
    if v.startswith("supabase:"):
        return "db_count"
    if v.startswith("env:"):
        return "supabase_health"
    return None


def _default_infra_checkers() -> dict[str, Callable[..., CheckResult]]:
    """Built-in infra checkers (import side effects register ``DashboardCheck`` handlers too)."""
    import forge.checkers  # noqa: F401

    from forge.checkers.db_count import check_db_count
    from forge.checkers.http_ping import check_http_ping
    from forge.checkers.supabase_health import check_supabase_health
    from forge.checkers.vercel_status import check_vercel_status

    return {
        "http_ping": check_http_ping,
        "supabase_health": check_supabase_health,
        "vercel_status": check_vercel_status,
        "db_count": check_db_count,
    }


def _project_root_for_doc(doc: ManifestDocument) -> Path:
    pr = project_root_for_manifest_file(doc.path)
    if pr is not None:
        return pr
    p = doc.path.resolve()
    if p.parent.name == ".forge":
        return p.parent.parent
    return p.parent


def _invoke_checker(checker: Callable[..., CheckResult], ref: str, context: CheckerContext) -> CheckResult:
    check_row = DashboardCheck(
        project_path=context.project_path,
        env=dict(context.env),
        infra_refs=list(context.infra_refs),
        timeout_seconds=context.timeout_seconds,
        label=ref,
        check=ref,
        type="infra",
    )
    return checker(check_row)


def resolve(doc: ManifestDocument) -> list[CheckResult]:
    project_path = _project_root_for_doc(doc)
    ck = _default_infra_checkers()

    infra_refs = _extract_infra_refs(doc)
    if not infra_refs:
        return []

    context = build_checker_context(project_path, doc)

    deduped: dict[tuple[str, str], InfraRef] = {}
    for ir in infra_refs:
        key = (_normalize_ref_key(ir.ref), ir.source_id)
        if ir.ref.strip() and key not in deduped:
            deduped[key] = ir

    results: list[CheckResult] = []
    for ir in deduped.values():
        label = f"{ir.source_id}:{ir.ref}"
        checker_name = _checker_name_for_ref(ir.ref)
        if checker_name is None:
            results.append(
                CheckResult(
                    label=label,
                    status="unknown",
                    value=None,
                    error=f"No checker matched ref: {ir.ref}",
                )
            )
            continue

        checker = ck.get(checker_name) if isinstance(ck, dict) else None
        if checker is None:
            results.append(
                CheckResult(
                    label=label,
                    status="unknown",
                    value=None,
                    error=f"Checker not registered: {checker_name}",
                )
            )
            continue

        try:
            result = _invoke_checker(checker, ir.ref, context)
            results.append(
                CheckResult(
                    label=label,
                    status=result.status,
                    value=result.value,
                    error=result.error,
                )
            )
        except Exception as exc:
            results.append(
                CheckResult(
                    label=label,
                    status="error",
                    value=None,
                    error=str(exc),
                )
            )
    return results


def _check_result_to_dict(r: CheckResult) -> dict[str, Any]:
    return {"label": r.label, "status": r.status, "value": r.value, "error": r.error}


def to_payload(results: list[CheckResult]) -> dict[str, Any]:
    """Shape for MCP ``forge_project_status`` ``infra_health`` (L0)."""
    return {"checked": len(results), "results": [_check_result_to_dict(r) for r in results]}
