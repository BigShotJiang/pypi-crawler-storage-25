"""
Forge Migration Tools - Seamless migration utilities for component architecture.
Provides safe, non-breaking migration from dict-based to component-based systems.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Type, Callable, Union
from pathlib import Path
import json
import shutil
from datetime import datetime
from dataclasses import dataclass, field

from forge.core.forge_project_system import ForgeProject, create_project
# Deprecated: ECS compatibility layer archived — prefer ForgeEngine for new code.
from forge.archive.ecs.forge_compatibility_layer import (
    ForgeCompatibilityLayer,
    apply_compatibility_to_project,
)
from forge.core.testing_framework import run_component_tests, test_migration_readiness


@dataclass
class MigrationPlan:
    """Plan for migrating from dict-based to component-based system."""
    project_path: str
    migration_phases: List[Dict[str, Any]]
    current_phase: int = 0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    completed_phases: List[str] = field(default_factory=list)
    rollback_points: List[Dict[str, Any]] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert migration plan to dict."""
        return {
            "project_path": self.project_path,
            "migration_phases": self.migration_phases,
            "current_phase": self.current_phase,
            "created_at": self.created_at,
            "completed_phases": self.completed_phases,
            "rollback_points": self.rollback_points
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MigrationPlan':
        """Create migration plan from dict."""
        return cls(
            project_path=data["project_path"],
            migration_phases=data["migration_phases"],
            current_phase=data.get("current_phase", 0),
            created_at=data.get("created_at", datetime.now().isoformat()),
            completed_phases=data.get("completed_phases", []),
            rollback_points=data.get("rollback_points", [])
        )


@dataclass
class MigrationResult:
    """Result of a migration operation."""
    phase: str
    success: bool
    message: str
    duration: float
    entities_migrated: int
    components_added: int
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert migration result to dict."""
        return {
            "phase": self.phase,
            "success": self.success,
            "message": self.message,
            "duration": self.duration,
            "entities_migrated": self.entities_migrated,
            "components_added": self.components_added,
            "errors": self.errors,
            "warnings": self.warnings
        }


class MigrationManager:
    """Manages safe migration from dict-based to component-based systems."""
    
    def __init__(self, project_path: str):
        self.project_path = Path(project_path)
        self.project: Optional[ForgeProject] = None
        self.compatibility_layer: Optional[ForgeCompatibilityLayer] = None
        self.migration_plan: Optional[MigrationPlan] = None
        self.migration_history: List[MigrationResult] = []
        self.backup_dir: Path = self.project_path / ".forge" / "migration_backups"
        
        # Ensure backup directory exists
        self.backup_dir.mkdir(parents=True, exist_ok=True)
    
    def initialize_migration(self) -> bool:
        """Initialize migration process."""
        try:
            # Create project
            self.project = create_project(self.project_path)
            
            # Apply compatibility layer
            self.compatibility_layer = apply_compatibility_to_project(self.project)
            
            # Create migration plan
            self.migration_plan = self._create_migration_plan()
            
            # Create initial backup
            self._create_backup("initial")
            
            return True
        except Exception as e:
            print(f"Failed to initialize migration: {e}")
            return False
    
    def _create_migration_plan(self) -> MigrationPlan:
        """Create comprehensive migration plan."""
        phases = [
            {
                "name": "compatibility_setup",
                "description": "Setup compatibility layer and verify existing functionality",
                "steps": [
                    "Apply compatibility layer",
                    "Run compatibility tests",
                    "Verify existing commands work",
                    "Create initial backup"
                ],
                "estimated_time": "5-10 minutes",
                "risk_level": "low"
            },
            {
                "name": "component_adoption",
                "description": "Gradually adopt components for new features",
                "steps": [
                    "Identify candidates for component adoption",
                    "Create component entities for new features",
                    "Test component functionality",
                    "Verify interoperability with existing code"
                ],
                "estimated_time": "30-60 minutes",
                "risk_level": "low"
            },
            {
                "name": "gradual_migration",
                "description": "Migrate existing functionality to components",
                "steps": [
                    "Migrate graph operations",
                    "Migrate event handling",
                    "Migrate health monitoring",
                    "Migrate protocol integration",
                    "Test all migrated functionality"
                ],
                "estimated_time": "2-4 hours",
                "risk_level": "medium"
            },
            {
                "name": "optimization",
                "description": "Optimize component architecture",
                "steps": [
                    "Remove redundant dict operations",
                    "Optimize component communication",
                    "Fine-tune performance",
                    "Final testing and validation"
                ],
                "estimated_time": "1-2 hours",
                "risk_level": "low"
            },
            {
                "name": "cleanup",
                "description": "Clean up legacy code and finalize migration",
                "steps": [
                    "Remove compatibility shims",
                    "Clean up temporary files",
                    "Update documentation",
                    "Final validation"
                ],
                "estimated_time": "30-60 minutes",
                "risk_level": "low"
            }
        ]
        
        return MigrationPlan(
            project_path=str(self.project_path),
            migration_phases=phases
        )
    
    def execute_migration_phase(self, phase_name: str) -> MigrationResult:
        """Execute a specific migration phase."""
        import time
        start_time = time.time()
        
        if not self.migration_plan:
            return MigrationResult(
                phase=phase_name,
                success=False,
                message="Migration plan not initialized",
                duration=0,
                entities_migrated=0,
                components_added=0,
                errors=["Migration plan not initialized"]
            )
        
        # Find phase in plan
        phase = next((p for p in self.migration_plan.migration_phases if p["name"] == phase_name), None)
        if not phase:
            return MigrationResult(
                phase=phase_name,
                success=False,
                message=f"Phase {phase_name} not found in migration plan",
                duration=0,
                entities_migrated=0,
                components_added=0,
                errors=[f"Phase {phase_name} not found"]
            )
        
        # Create backup before phase
        backup_name = f"before_{phase_name}"
        self._create_backup(backup_name)
        
        try:
            if phase_name == "compatibility_setup":
                result = self._execute_compatibility_setup_phase(phase)
            elif phase_name == "component_adoption":
                result = self._execute_component_adoption_phase(phase)
            elif phase_name == "gradual_migration":
                result = self._execute_gradual_migration_phase(phase)
            elif phase_name == "optimization":
                result = self._execute_optimization_phase(phase)
            elif phase_name == "cleanup":
                result = self._execute_cleanup_phase(phase)
            else:
                result = MigrationResult(
                    phase=phase_name,
                    success=False,
                    message=f"Unknown phase: {phase_name}",
                    duration=time.time() - start_time,
                    entities_migrated=0,
                    components_added=0,
                    errors=[f"Unknown phase: {phase_name}"]
                )
            
            # Record completion
            if result.success:
                self.migration_plan.completed_phases.append(phase_name)
                self.migration_plan.current_phase = self.migration_plan.migration_phases.index(phase) + 1
            
            self.migration_history.append(result)
            return result
            
        except Exception as e:
            duration = time.time() - start_time
            error_result = MigrationResult(
                phase=phase_name,
                success=False,
                message=f"Phase failed with exception: {str(e)}",
                duration=duration,
                entities_migrated=0,
                components_added=0,
                errors=[str(e)]
            )
            
            self.migration_history.append(error_result)
            return error_result
    
    def _execute_compatibility_setup_phase(self, phase: Dict[str, Any]) -> MigrationResult:
        """Execute compatibility setup phase."""
        import time
        start_time = time.time()
        
        try:
            # Apply compatibility layer (already done in initialize)
            if not self.compatibility_layer:
                self.compatibility_layer = apply_compatibility_to_project(self.project)
            
            # Run compatibility tests
            from forge.core.testing_framework import run_component_tests
            test_results = run_component_tests(self.project)
            
            # Verify existing functionality
            if test_results["pass_rate"] < 0.9:
                return MigrationResult(
                    phase=phase["name"],
                    success=False,
                    message="Compatibility tests failed",
                    duration=time.time() - start_time,
                    entities_migrated=0,
                    components_added=0,
                    errors=[f"Only {test_results['pass_rate']:.1%} tests passed"]
                )
            
            return MigrationResult(
                phase=phase["name"],
                success=True,
                message="Compatibility setup completed successfully",
                duration=time.time() - start_time,
                entities_migrated=len(self.project._entities),
                components_added=0,
                warnings=[]
            )
            
        except Exception as e:
            return MigrationResult(
                phase=phase["name"],
                success=False,
                message=f"Compatibility setup failed: {str(e)}",
                duration=time.time() - start_time,
                entities_migrated=0,
                components_added=0,
                errors=[str(e)]
            )
    
    def _execute_component_adoption_phase(self, phase: Dict[str, Any]) -> MigrationResult:
        """Execute component adoption phase."""
        import time
        start_time = time.time()
        
        try:
            components_added = 0
            entities_migrated = 0
            
            # Create component entities for common patterns
            from forge.core.forge_project_system import ForgeEntity
            from forge.core.forge_project_system import (
                HealthComponent, MetricsComponent, EventComponent,
                SemanticAnalysisComponent, ContractValidationComponent
            )
            
            # Health monitor
            health_entity = ForgeEntity("health_monitor", "monitor")
            health_entity.add_component(HealthComponent())
            health_entity.add_component(MetricsComponent())
            self.project.add_entity(health_entity)
            components_added += 2
            entities_migrated += 1
            
            # Event system
            event_entity = ForgeEntity("event_system", "system")
            event_entity.add_component(EventComponent())
            self.project.add_entity(event_entity)
            components_added += 1
            entities_migrated += 1
            
            # Semantic analyzer
            semantic_entity = ForgeEntity("semantic_analyzer", "analyzer")
            semantic_entity.add_component(SemanticAnalysisComponent())
            self.project.add_entity(semantic_entity)
            components_added += 1
            entities_migrated += 1
            
            return MigrationResult(
                phase=phase["name"],
                success=True,
                message="Component adoption completed successfully",
                duration=time.time() - start_time,
                entities_migrated=entities_migrated,
                components_added=components_added,
                warnings=[]
            )
            
        except Exception as e:
            return MigrationResult(
                phase=phase["name"],
                success=False,
                message=f"Component adoption failed: {str(e)}",
                duration=time.time() - start_time,
                entities_migrated=0,
                components_added=0,
                errors=[str(e)]
            )
    
    def _execute_gradual_migration_phase(self, phase: Dict[str, Any]) -> MigrationResult:
        """Execute gradual migration phase."""
        import time
        start_time = time.time()
        
        try:
            # This phase would involve migrating existing functionality
            # For now, simulate with component creation
            from forge.core.forge_project_system import ForgeEntity
            from forge.core.forge_project_system import (
                GraphComponent, ManifestGraphComponent, TraceComponent
            )
            
            entities_migrated = 0
            components_added = 0
            
            # Create graph manager
            graph_entity = ForgeEntity("graph_manager", "manager")
            graph_entity.add_component(GraphComponent(graph_type="manifest"))
            graph_entity.add_component(ManifestGraphComponent(auto_load=True))
            self.project.add_entity(graph_entity)
            components_added += 2
            entities_migrated += 1
            
            # Create trace system
            trace_entity = ForgeEntity("trace_system", "system")
            trace_entity.add_component(TraceComponent(trace_enabled=True))
            self.project.add_entity(trace_entity)
            components_added += 1
            entities_migrated += 1
            
            return MigrationResult(
                phase=phase["name"],
                success=True,
                message="Gradual migration completed successfully",
                duration=time.time() - start_time,
                entities_migrated=entities_migrated,
                components_added=components_added,
                warnings=[
                    "This is a simulated migration",
                    "Real migration would convert existing dict operations"
                ]
            )
            
        except Exception as e:
            return MigrationResult(
                phase=phase["name"],
                success=False,
                message=f"Gradual migration failed: {str(e)}",
                duration=time.time() - start_time,
                entities_migrated=0,
                components_added=0,
                errors=[str(e)]
            )
    
    def _execute_optimization_phase(self, phase: Dict[str, Any]) -> MigrationResult:
        """Execute optimization phase."""
        import time
        start_time = time.time()
        
        try:
            # Optimize component communication
            # This would involve analyzing and optimizing component interactions
            # For now, simulate with validation
            
            from forge.core.testing_framework import test_migration_readiness
            readiness = test_migration_readiness(self.project)
            
            if readiness["migration_readiness"] < 80:
                return MigrationResult(
                    phase=phase["name"],
                    success=False,
                    message="System not ready for optimization",
                    duration=time.time() - start_time,
                    entities_migrated=0,
                    components_added=0,
                    errors=[f"Readiness score: {readiness['migration_readiness']}%"]
                )
            
            return MigrationResult(
                phase=phase["name"],
                success=True,
                message="Optimization completed successfully",
                duration=time.time() - start_time,
                entities_migrated=0,
                components_added=0,
                warnings=[]
            )
            
        except Exception as e:
            return MigrationResult(
                phase=phase["name"],
                success=False,
                message=f"Optimization failed: {str(e)}",
                duration=time.time() - start_time,
                entities_migrated=0,
                components_added=0,
                errors=[str(e)]
            )
    
    def _execute_cleanup_phase(self, phase: Dict[str, Any]) -> MigrationResult:
        """Execute cleanup phase."""
        import time
        start_time = time.time()
        
        try:
            # Clean up temporary files and optimize
            # For now, simulate with validation
            
            # Final validation
            from forge.core.testing_framework import run_component_tests
            test_results = run_component_tests(self.project)
            
            if test_results["pass_rate"] < 0.95:
                return MigrationResult(
                    phase=phase["name"],
                    success=False,
                    message="Final validation failed",
                    duration=time.time() - start_time,
                    entities_migrated=0,
                    components_added=0,
                    errors=[f"Final pass rate: {test_results['pass_rate']:.1%}"]
                )
            
            return MigrationResult(
                phase=phase["name"],
                success=True,
                message="Cleanup completed successfully",
                duration=time.time() - start_time,
                entities_migrated=0,
                components_added=0,
                warnings=[
                    "Remember to remove compatibility layer when ready",
                    "Update documentation for component architecture"
                ]
            )
            
        except Exception as e:
            return MigrationResult(
                phase=phase["name"],
                success=False,
                message=f"Cleanup failed: {str(e)}",
                duration=time.time() - start_time,
                entities_migrated=0,
                components_added=0,
                errors=[str(e)]
            )
    
    def _create_backup(self, backup_name: str):
        """Create backup of current state."""
        import shutil
        
        backup_path = self.backup_dir / f"{backup_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # Backup project files
        if self.project_path.exists():
            shutil.copytree(self.project_path, backup_path / "project")
        
        # Save migration state
        if self.migration_plan:
            state_file = backup_path / "migration_state.json"
            state_file.write_text(json.dumps(self.migration_plan.to_dict(), indent=2))
        
        # Save test results
        if self.migration_history:
            results_file = backup_path / "migration_results.json"
            results_data = [r.to_dict() for r in self.migration_history]
            results_file.write_text(json.dumps(results_data, indent=2))
    
    def rollback_to_backup(self, backup_name: str) -> bool:
        """Rollback to a specific backup."""
        try:
            backup_path = self.backup_dir / backup_name
            if not backup_path.exists():
                return False
            
            # Restore project files
            project_backup = backup_path / "project"
            if project_backup.exists():
                shutil.rmtree(self.project_path)
                shutil.copytree(project_backup, self.project_path)
            
            # Restore migration state
            state_file = backup_path / "migration_state.json"
            if state_file.exists():
                state_data = json.loads(state_file.read_text())
                self.migration_plan = MigrationPlan.from_dict(state_data)
            
            return True
        except Exception as e:
            print(f"Rollback failed: {e}")
            return False
    
    def get_migration_status(self) -> Dict[str, Any]:
        """Get current migration status."""
        if not self.migration_plan:
            return {"status": "not_initialized"}
        
        current_phase_index = self.migration_plan.current_phase
        total_phases = len(self.migration_plan.migration_phases)
        
        if current_phase_index >= total_phases:
            current_phase_name = "completed"
            progress = 100
        else:
            current_phase_name = self.migration_plan.migration_phases[current_phase_index]["name"]
            progress = (current_phase_index / total_phases) * 100
        
        return {
            "status": "in_progress" if progress < 100 else "completed",
            "current_phase": current_phase_name,
            "progress_percentage": progress,
            "completed_phases": self.migration_plan.completed_phases,
            "total_phases": total_phases,
            "migration_history": [r.to_dict() for r in self.migration_history]
        }
    
    def save_migration_state(self):
        """Save current migration state."""
        if not self.migration_plan:
            return
        
        state_file = self.project_path / ".forge" / "migration_state.json"
        state_file.write_text(json.dumps(self.migration_plan.to_dict(), indent=2))


# === MIGRATION UTILITIES ===

def create_migration_manager(project_path: str) -> MigrationManager:
    """Create migration manager for a project."""
    return MigrationManager(project_path)


def run_safe_migration(project_path: str) -> Dict[str, Any]:
    """Run complete safe migration process."""
    manager = create_migration_manager(project_path)
    
    try:
        # Initialize migration
        if not manager.initialize_migration():
            return {
                "success": False,
                "message": "Failed to initialize migration",
                "project_path": project_path
            }
        
        # Execute all phases
        phases = ["compatibility_setup", "component_adoption", "gradual_migration", "optimization", "cleanup"]
        results = []
        
        for phase_name in phases:
            print(f"Executing migration phase: {phase_name}")
            result = manager.execute_migration_phase(phase_name)
            results.append(result)
            
            if not result.success:
                print(f"Phase {phase_name} failed: {result.message}")
                break
            
            print(f"Phase {phase_name} completed successfully")
        
        # Get final status
        status = manager.get_migration_status()
        
        return {
            "success": status["status"] == "completed",
            "message": "Migration completed successfully" if status["status"] == "completed" else "Migration incomplete",
            "project_path": project_path,
            "migration_status": status,
            "phase_results": [r.to_dict() for r in results]
        }
        
    except Exception as e:
        return {
            "success": False,
            "message": f"Migration failed with exception: {str(e)}",
            "project_path": project_path,
            "error": str(e)
        }


def test_migration_readiness(project_path: str) -> Dict[str, Any]:
    """Test if project is ready for migration."""
    try:
        from forge.core.forge_project_system import create_project
        from forge.core.testing_framework import test_migration_readiness
        
        project = create_project(Path(project_path))
        return test_migration_readiness(project)
        
    except Exception as e:
        return {
            "project_path": project_path,
            "migration_readiness": 0,
            "readiness_level": "Not Ready",
            "error": str(e)
        }


# === USAGE EXAMPLES ===

def migration_example():
    """Example of using migration tools."""
    project_path = "/Users/sebastianpereira/Projects/forge"
    
    # Test readiness
    readiness = test_migration_readiness(project_path)
    print(f"Migration Readiness: {readiness}")
    
    if readiness["migration_readiness"] >= 80:
        # Run full migration
        result = run_safe_migration(project_path)
        print(f"Migration Result: {result}")
    else:
        print("Project not ready for migration. Address issues first.")


def incremental_migration_example():
    """Example of incremental migration approach."""
    project_path = "/Users/sebastianpereira/Projects/forge"
    manager = create_migration_manager(project_path)
    
    # Initialize
    if manager.initialize_migration():
        print("Migration initialized successfully")
        
        # Run phases incrementally
        phases = ["compatibility_setup", "component_adoption"]
        
        for phase_name in phases:
            print(f"Running phase: {phase_name}")
            result = manager.execute_migration_phase(phase_name)
            
            if result.success:
                print(f"✅ {phase_name}: {result.message}")
                manager.save_migration_state()
            else:
                print(f"❌ {phase_name}: {result.message}")
                break
        
        # Get status
        status = manager.get_migration_status()
        print(f"Migration Status: {status}")
    else:
        print("Failed to initialize migration")
