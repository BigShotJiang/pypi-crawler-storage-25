"""Import statement parser for reality-based manifest validation.

Extracts actual import statements from source files and compares them
against manifest declarations to detect reality gaps.
"""

import ast
import logging
import os
import re
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Any, Optional
from dataclasses import dataclass

import logging

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ImportStatement:
    """Represents a parsed import statement."""
    module: str
    source_file: Path
    line_number: int
    import_type: str  # 'import', 'require', 'dynamic', 'relative'
    alias: Optional[str] = None
    is_speculative: bool = False


@dataclass(frozen=True)
class FileImports:
    """All imports found in a single file."""
    file_path: Path
    imports: List[ImportStatement]
    has_errors: bool = False
    error_messages: List[str] = None


class ImportParser:
    """Parses import statements from various file types."""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.excluded_dirs = set()
        self.dependency_dirs = set()
        self.build_dirs = set()
        self.detected_stack = None
        
        # Initialize detection caches
        self._detect_dependency_directories()
        self._detect_build_directories({})
        self._detect_project_stack()
    
    def parse_file(self, file_path: Path) -> FileImports:
        """Parse all imports from a single file using stack-agnostic approach."""
        if not file_path.exists():
            return FileImports(file_path, [], True, ["File does not exist"])
        
        if self._should_skip_file(file_path):
            return FileImports(file_path, [], False, [])
        
        try:
            # Use stack-agnostic parsing with detected stack
            imports = self._parse_imports_with_glove(file_path, self.detected_stack)
            return FileImports(file_path, imports, False, [])
            
        except Exception as e:
            return FileImports(file_path, [], True, [f"Parse error: {e}"])
    
    def parse_directory(self, directory: Path, recursive: bool = True, max_files: int = 1000) -> Dict[Path, FileImports]:
        """Parse imports from all supported files in a directory with file limit protection."""
        results = {}
        file_count = 0
        
        if recursive:
            files = directory.rglob("*")
        else:
            files = list(directory.iterdir())
        
        for file_path in files:
            if file_count >= max_files:
                logger.warning(f"Reached file limit ({max_files}) in {directory}, stopping parse")
                break
                
            if file_path.is_file():
                # Skip files in excluded directories
                if not self._should_skip_file(file_path):
                    results[file_path] = self.parse_file(file_path)
                    file_count += 1
        
        logger.info(f"Parsed {file_count} files from {directory}")
        return results
    
    def _should_skip_file(self, file_path: Path) -> bool:
        """Check if file should be skipped during parsing using dynamic project analysis."""
        # Load project configuration to understand structure
        project_config = self._load_project_config()
        
        # Check if file is in a dependency directory
        if self._is_dependency_directory(file_path, project_config):
            return True
        
        # Check if file is in a build output directory
        if self._is_build_artifact(file_path, project_config):
            return True
        
        # Check if file is in version control directory
        if self._is_version_control_file(file_path):
            return True
        
        return False
    
    def _load_project_config(self) -> Dict:
        """Load project configuration from package.json, etc."""
        config = {}
        
        # Load package.json if exists
        package_json = self.project_root / "package.json"
        if package_json.exists():
            try:
                with open(package_json) as f:
                    pkg = json.load(f)
                    config.update(pkg)
            except (json.JSONDecodeError, IOError):
                pass
        
        # Detect package manager from lock files
        if (self.project_root / "pnpm-lock.yaml").exists():
            config['packageManager'] = 'pnpm'
        elif (self.project_root / "yarn.lock").exists():
            config['packageManager'] = 'yarn'
        elif (self.project_root / "package-lock.json").exists():
            config['packageManager'] = 'npm'
        
        return config
    
    def _is_dependency_directory(self, file_path: Path, config: Dict) -> bool:
        """Check if path is in a dependency directory using dynamic detection."""
        # Detect dependency directories dynamically
        dep_dirs = self._detect_dependency_directories()
        
        # Add package manager specific directories
        package_manager = config.get('packageManager')
        if package_manager == 'pnpm':
            dep_dirs.update({'.pnpm', 'pnpm-modules'})
        elif package_manager == 'yarn':
            dep_dirs.update({'.yarn', 'yarn-modules'})
        
        # Check Python dependency directories
        python_dep_dirs = {'site-packages', 'dist-packages', '__pycache__', '.pytest_cache'}
        dep_dirs.update(python_dep_dirs)
        
        return any(part in dep_dirs for part in file_path.parts)
    
    def _is_build_artifact(self, file_path: Path, config: Dict) -> bool:
        """Check if file is in a build output directory using dynamic detection."""
        # Detect build directories dynamically
        build_dirs = self._detect_build_directories(config)
        
        return any(part in build_dirs for part in file_path.parts)
    
    def _detect_project_stack(self) -> None:
        """Detect the project stack based on specific file patterns."""
        # Check for specific stack indicators (prioritize exact files)
        if (self.project_root / 'pubspec.yaml').exists():
            self.detected_stack = 'flutter_supabase'
            logger.debug("Detected flutter_supabase stack")
            return
        elif (self.project_root / 'package.json').exists():
            self.detected_stack = 'node'
            logger.debug("Detected node stack")
            return
        elif (self.project_root / 'Cargo.toml').exists():
            self.detected_stack = 'rust'
            logger.debug("Detected rust stack")
            return
        elif (self.project_root / 'go.mod').exists():
            self.detected_stack = 'go'
            logger.debug("Detected go stack")
            return
        
        # Check for Python-specific indicators
        python_indicators = ['requirements.txt', 'setup.py', 'pyproject.toml']
        for indicator in python_indicators:
            if (self.project_root / indicator).exists():
                self.detected_stack = 'python'
                logger.debug("Detected python stack")
                return
        
        # Check for Python project structure (has Python files)
        try:
            python_files = list(self.project_root.rglob("*.py"))
            if python_files:
                self.detected_stack = 'python'
                logger.debug("Detected python stack from .py files")
                return
        except Exception:
            pass
        
        # Default to python if no stack detected
        self.detected_stack = 'python'
        logger.debug("Defaulting to python stack")
    
    def _is_version_control_file(self, file_path: Path) -> bool:
        """Check if file is in version control directory."""
        vc_dirs = {'.git', '.svn', '.hg', '.bzr'}
        return any(part in vc_dirs for part in file_path.parts)
    
    def _parse_python_imports(self, file_path: Path) -> List[ImportStatement]:
        """Parse Python imports using glove system."""
        return self._parse_imports_with_glove(file_path, 'python')
    
    def _parse_imports_with_glove(self, file_path: Path, stack_id: str) -> List[ImportStatement]:
        """Parse imports using stack-agnostic glove system."""
        try:
            # Load glove configuration
            glove_config = self._load_glove_config(stack_id)
            if not glove_config:
                # Fallback to basic parsing if no glove config
                return self._basic_fallback_parsing(file_path)
            
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            imports = []
            
            # Use glove-defined parsing patterns
            if stack_id == 'python':
                imports = self._parse_python_with_patterns(content, glove_config)
            elif stack_id == 'flutter_supabase':
                imports = self._parse_dart_imports(content, glove_config)
            else:
                # Generic parsing for unknown stacks
                imports = self._generic_import_parsing(content, glove_config)
            
            return imports
            
        except Exception as e:
            logger.debug(f"Error parsing imports with glove in {file_path}: {e}")
            return self._basic_fallback_parsing(file_path)
    
    def _load_glove_config(self, stack_id: str) -> Optional[Dict[str, Any]]:
        """Load glove configuration for the specified stack."""
        # First check project-local glove config
        glove_path = self.project_root / ".forge" / "gloves" / f"{stack_id}.glove.yaml"
        if glove_path.exists():
            try:
                import yaml
                with open(glove_path) as f:
                    return yaml.safe_load(f)
            except Exception as e:
                logger.debug(f"Failed to load project glove config {stack_id}: {e}")
        
        # Fallback to forge installation glove configs
        forge_glove_path = Path(__file__).parent.parent.parent / ".forge" / "gloves" / f"{stack_id}.glove.yaml"
        if forge_glove_path.exists():
            try:
                import yaml
                with open(forge_glove_path) as f:
                    return yaml.safe_load(f)
            except Exception as e:
                logger.debug(f"Failed to load forge glove config {stack_id}: {e}")
        
        return None
    
    def _parse_python_with_patterns(self, content: str, glove_config: Dict[str, Any]) -> List[ImportStatement]:
        """Parse Python imports using glove-defined patterns."""
        imports = []
        lines = content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            
            # Python import statements
            if line.startswith('import '):
                parts = line.split()
                if len(parts) >= 2:
                    module = parts[1].strip('\'"')
                    if module:
                        imports.append(ImportStatement(
                            module=module,
                            alias=None,
                            line=line_num,
                            type='import'
                        ))
            elif line.startswith('from '):
                parts = line.split()
                if len(parts) >= 4 and parts[1] != '.':
                    submodule = parts[3].strip('\'"')
                    module = f"{parts[1]}.{submodule}"
                    imports.append(ImportStatement(
                        module=module,
                        alias=None,
                        line=line_num,
                        type='from'
                    ))
        
        return imports
    
    def _parse_dart_imports(self, content: str, glove_config: Dict[str, Any]) -> List[ImportStatement]:
        """Parse Dart imports using glove patterns."""
        imports = []
        lines = content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            
            # Parse import statements
            if line.startswith('import '):
                match = re.match(r'import\s+([\'"])(.+?)\1(?:\s+as\s+(\w+))?', line)
                if match:
                    module = match.group(2)
                    alias = match.group(3)
                    imports.append(ImportStatement(
                        module=module,
                        alias=alias,
                        line=line_num,
                        type='import'
                    ))
            
            # Parse part directives
            elif line.startswith('part '):
                match = re.match(r'part\s+([\'"])(.+?)\1;', line)
                if match:
                    module = match.group(2)
                    imports.append(ImportStatement(
                        module=module,
                        alias=None,
                        line=line_num,
                        type='part'
                    ))
        
        return imports
    
    def _generic_import_parsing(self, content: str, glove_config: Dict[str, Any]) -> List[ImportStatement]:
        """Generic import parsing for unknown stacks."""
        imports = []
        lines = content.split('\n')
        
        # Common import patterns across languages
        import_patterns = [
            r'import\s+(?:[\'"])(.+?)(?:[\'"])',  # Python, TypeScript
            r'require\s+(?:[\'"])(.+?)(?:[\'"])',  # Ruby, Node.js
            r'using\s+(.+?);',  # C#
            r'#include\s+[<"](.+?)[>"]',  # C/C++
        ]
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            for pattern in import_patterns:
                match = re.search(pattern, line)
                if match:
                    imports.append(ImportStatement(
                        module=match.group(1),
                        alias=None,
                        line=line_num,
                        type='import'
                    ))
                    break
        
        return imports
    
    def _basic_fallback_parsing(self, file_path: Path) -> List[ImportStatement]:
        """Basic fallback parsing when no glove config is available."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Simple regex-based parsing as last resort
            imports = []
            lines = content.split('\n')
            
            for line_num, line in enumerate(lines, 1):
                line = line.strip()
                
                # Python-style imports
                if line.startswith('import '):
                    parts = line.split()
                    if len(parts) >= 2:
                        imports.append(ImportStatement(
                            module=parts[1].strip('\'"'),
                            alias=None,
                            line=line_num,
                            type='import'
                        ))
                elif line.startswith('from '):
                    parts = line.split()
                    if len(parts) >= 4 and parts[1] != '.':
                        submodule = parts[3].strip('\'"')
                        imports.append(ImportStatement(
                            module=f"{parts[1]}.{submodule}",
                            alias=None,
                            line=line_num,
                            type='from'
                        ))
            
            return imports
            
        except Exception as e:
            logger.debug(f"Error in fallback parsing {file_path}: {e}")
            return []
    
    def _parse_typescript_imports(self, content: str, file_path: Path) -> List[ImportStatement]:
        """Parse TypeScript/JavaScript import statements."""
        imports = []
        lines = content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            
            # ES6 imports
            if line.startswith('import '):
                imports.extend(self._parse_es6_import(line, file_path, line_num))
            
            # CommonJS require
            elif line.startswith('const ') and 'require(' in line:
                imports.extend(self._parse_require_import(line, file_path, line_num))
            
            # Dynamic import
            elif 'import(' in line:
                imports.extend(self._parse_dynamic_import(line, file_path, line_num))
        
        return imports
    
    def _parse_javascript_imports(self, content: str, file_path: Path) -> List[ImportStatement]:
        """Parse JavaScript import statements."""
        return self._parse_typescript_imports(content, file_path)
    
    def _parse_astro_imports(self, content: str, file_path: Path) -> List[ImportStatement]:
        """Parse Astro component imports."""
        imports = []
        
        # Split into frontmatter and script sections
        parts = content.split('---', 2)
        if len(parts) >= 3:
            frontmatter = parts[1]
            script_content = parts[2]
            
            # Parse frontmatter (YAML with potential imports)
            imports.extend(self._parse_typescript_imports(frontmatter, file_path))
            
            # Parse script section
            imports.extend(self._parse_typescript_imports(script_content, file_path))
        elif len(parts) >= 2:
            # Just frontmatter
            frontmatter = parts[1]
            imports.extend(self._parse_typescript_imports(frontmatter, file_path))
        
        return imports
    
    def _parse_es6_import(self, line: str, file_path: Path, line_num: int) -> List[ImportStatement]:
        """Parse ES6 import statement using semantic analysis."""
        imports = []
        
        # Use semantic analysis instead of simple regex
        try:
            # Extract module path with proper ES6 import syntax understanding
            if 'from' in line:
                # Handle: import ... from 'module'
                parts = line.split('from')
                if len(parts) >= 2:
                    module_part = parts[-1].strip()
                    if module_part.startswith(('"', "'")) and module_part.endswith(('"', "'")):
                        module = module_part[1:-1].strip()
                        if module:
                            imports.append(ImportStatement(
                                module=module,
                                source_file=file_path,
                                line_number=line_num,
                                import_type='import'
                            ))
            elif line.strip().startswith('import'):
                # Handle bare import: import 'module'
                module_part = line.strip()[6:].strip()  # Remove 'import '
                if module_part.startswith(('"', "'")) and module_part.endswith(('"', "'")):
                    module = module_part[1:-1].strip()
                    if module:
                        imports.append(ImportStatement(
                            module=module,
                            source_file=file_path,
                            line_number=line_num,
                            import_type='import'
                        ))
        except (IndexError, ValueError):
            # Fallback to basic parsing if semantic analysis fails
            pass
        
        return imports
    
    def _parse_require_import(self, line: str, file_path: Path, line_num: int) -> List[ImportStatement]:
        """Parse CommonJS require statement using semantic analysis."""
        imports = []
        
        # Use semantic analysis instead of simple regex
        try:
            # Find require() calls with proper CommonJS syntax understanding
            require_start = line.find('require(')
            if require_start != -1:
                require_end = line.find(')', require_start)
                if require_end != -1:
                    require_content = line[require_start + 8:require_end].strip()
                    # Handle different quote styles
                    if (require_content.startswith('"') and require_content.endswith('"')) or \
                       (require_content.startswith("'") and require_content.endswith("'")):
                        module = require_content[1:-1].strip()
                        if module:
                            imports.append(ImportStatement(
                                module=module,
                                source_file=file_path,
                                line_number=line_num,
                                import_type='require'
                            ))
        except (IndexError, ValueError):
            # Fallback to basic parsing if semantic analysis fails
            pass
        
        return imports
    
    def _parse_dynamic_import(self, line: str, file_path: Path, line_num: int) -> List[ImportStatement]:
        """Parse dynamic import statement using semantic analysis."""
        imports = []
        
        # Use semantic analysis instead of simple regex
        try:
            # Find dynamic import() calls with proper ES2020 syntax understanding
            import_start = line.find('import(')
            if import_start != -1:
                import_end = line.find(')', import_start)
                if import_end != -1:
                    import_content = line[import_start + 7:import_end].strip()
                    # Handle different quote styles and template literals
                    if (import_content.startswith('"') and import_content.endswith('"')) or \
                       (import_content.startswith("'") and import_content.endswith("'")):
                        module = import_content[1:-1].strip()
                        if module:
                            imports.append(ImportStatement(
                                module=module,
                                source_file=file_path,
                                line_number=line_num,
                                import_type='dynamic',
                                is_speculative=True
                            ))
                    elif import_content.startswith('`') and import_content.endswith('`'):
                        # Handle template literals (basic extraction)
                        template_content = import_content[1:-1].strip()
                        if template_content and not any(char in template_content for char in ['${', '}']):
                            # Simple template literal without interpolation
                            module = template_content
                            imports.append(ImportStatement(
                                module=module,
                                source_file=file_path,
                                line_number=line_num,
                                import_type='dynamic',
                                is_speculative=True
                            ))
        except (IndexError, ValueError):
            # Fallback to basic parsing if semantic analysis fails
            pass
        
        return imports
    
    def normalize_module_path(self, module: str, source_file: Path) -> Optional[str]:
        """Normalize module path to project-relative format."""
        if module.startswith('./') or module.startswith('../'):
            # Relative import
            try:
                base_dir = source_file.parent
                module_path = (base_dir / module).resolve()
                relative_path = module_path.relative_to(self.project_root)
                return str(relative_path.with_suffix(''))
            except (ValueError, FileNotFoundError):
                return None
        elif module.startswith('/'):
            # Absolute import
            try:
                module_path = self.project_root / module[1:]
                relative_path = module_path.relative_to(self.project_root)
                return str(relative_path.with_suffix(''))
            except (ValueError, FileNotFoundError):
                return None
        else:
            # Package/module import
            return module
    
    def _detect_dependency_directories(self) -> Set[str]:
        """Detect dependency directories dynamically based on project structure."""
        dep_dirs = set()
        
        # Common dependency directories
        common_deps = {'node_modules', 'bower_components', 'vendor', 'lib', 'libs'}
        dep_dirs.update(common_deps)
        
        # Python-specific directories
        python_deps = {'site-packages', 'dist-packages', '__pycache__', '.pytest_cache', '.tox'}
        dep_dirs.update(python_deps)
        
        # Build output directories
        build_dirs = {'build', 'dist', 'out', 'target', 'bin', 'obj'}
        dep_dirs.update(build_dirs)
        
        # Cache directories
        cache_dirs = {'.cache', '.tmp', '.temp', 'cache', 'tmp'}
        dep_dirs.update(cache_dirs)
        
        # Framework-specific directories
        framework_dirs = {
            '.next', '.nuxt', '.output', '.vite', '.angular', 
            '.vscode', '.idea', 'coverage', '.coverage'
        }
        dep_dirs.update(framework_dirs)
        
        # Detect from actual project structure
        try:
            for item in list(self.project_root.iterdir()):
                if item.is_dir():
                    dir_name = item.name
                    
                    # Check if it looks like a dependency directory
                    if (dir_name.startswith('.') or 
                        dir_name.endswith('_modules') or
                        dir_name.endswith('_packages') or
                        'node_modules' in dir_name or
                        'packages' in dir_name.lower() or
                        'vendor' in dir_name.lower() or
                        'lib' in dir_name.lower() and dir_name != 'lib'):
                        dep_dirs.add(dir_name)
                    
                    # Check for large directories (likely dependencies)
                    try:
                        file_count = len(list(item.iterdir()))
                        if file_count > 100:  # Likely a dependency directory
                            dep_dirs.add(dir_name)
                    except (PermissionError, OSError):
                        pass
        except (PermissionError, OSError):
            pass
        
        return dep_dirs
    
    def _detect_build_directories(self, config: Dict) -> Set[str]:
        """Detect build directories dynamically based on project configuration."""
        build_dirs = set()
        
        # Common build directories
        common_build = {'dist', 'build', 'out', 'target', 'bin', 'obj'}
        build_dirs.update(common_build)
        
        # Framework-specific build directories
        framework_build = {'.next', '.nuxt', '.output', '.vite', '.angular', '.cache'}
        build_dirs.update(framework_build)
        
        # Detect from project configuration
        if config.get('scripts'):
            scripts = config['scripts']
            if any('vite' in script for script in scripts.values()):
                build_dirs.update({'.vite', 'dist'})
            if any('webpack' in script for script in scripts.values()):
                build_dirs.update({'webpack', 'dist'})
            if any('rollup' in script for script in scripts.values()):
                build_dirs.update({'rollup', 'dist'})
            if any('esbuild' in script for script in scripts.values()):
                build_dirs.update({'esbuild', 'dist'})
        
        # Detect from configuration files
        if (self.project_root / "vite.config.js").exists() or (self.project_root / "vite.config.ts").exists():
            build_dirs.update({'.vite', 'dist'})
        
        if (self.project_root / "webpack.config.js").exists():
            build_dirs.update({'webpack', 'dist'})
        
        if (self.project_root / "next.config.js").exists():
            build_dirs.update({'.next', 'out'})
        
        if (self.project_root / "nuxt.config.js").exists() or (self.project_root / "nuxt.config.ts").exists():
            build_dirs.update({'.nuxt', '.output', 'dist'})
        
        if (self.project_root / "angular.json").exists():
            build_dirs.update({'dist'})
        
        # Detect from actual project structure
        try:
            for item in list(self.project_root.iterdir()):
                if item.is_dir():
                    dir_name = item.name
                    
                    # Check if it looks like a build directory
                    if (dir_name.startswith('.') or
                        dir_name in common_build or
                        'build' in dir_name.lower() or
                        'dist' in dir_name.lower() or
                        'out' in dir_name.lower() or
                        'target' in dir_name.lower()):
                        build_dirs.add(dir_name)
                    
                    # Check for directories with typical build artifacts
                    try:
                        has_build_artifacts = False
                        for sub_item in list(item.iterdir())[:10]:  # Check first 10 items
                            if sub_item.is_file():
                                file_name = sub_item.name.lower()
                                if (file_name.endswith('.min.js') or
                                    file_name.endswith('.min.css') or
                                    file_name.endswith('.bundle.js') or
                                    file_name.endswith('.map') or
                                    'bundle' in file_name or
                                    'chunk' in file_name):
                                    has_build_artifacts = True
                                    break
                        
                        if has_build_artifacts:
                            build_dirs.add(dir_name)
                    except (PermissionError, OSError, StopIteration):
                        pass
        except (PermissionError, OSError):
            pass
        
        return build_dirs
    
    def _load_supported_extensions(self) -> Dict[str, callable]:
        """Load supported extensions dynamically based on project configuration."""
        extensions = {}
        
        # Base extensions always supported
        base_extensions = {
            '.py': self._parse_python_imports,
            '.ts': self._parse_typescript_imports,
            '.tsx': self._parse_typescript_imports,
            '.js': self._parse_javascript_imports,
            '.jsx': self._parse_javascript_imports,
            '.astro': self._parse_astro_imports,
        }
        extensions.update(base_extensions)
        
        # Load project-specific extensions from configuration
        project_config = self._load_project_config()
        
        # Add TypeScript-specific extensions
        if project_config.get('typescript') or (self.project_root / "tsconfig.json").exists():
            extensions.update({
                '.d.ts': self._parse_typescript_imports,
            })
        
        # Add Astro-specific extensions
        if project_config.get('astro') or any(
            (self.project_root / f"astro.config{ext}").exists() 
            for ext in ['.mjs', '.js', '.ts']
        ):
            extensions.update({
                '.md': self._parse_markdown_imports,
                '.mdx': self._parse_markdown_imports,
            })
        
        # Add Vue-specific extensions
        if project_config.get('vue') or (self.project_root / "vue.config.js").exists():
            extensions.update({
                '.vue': self._parse_vue_imports,
            })
        
        # Add Svelte-specific extensions
        if project_config.get('svelte') or (self.project_root / "svelte.config.js").exists():
            extensions.update({
                '.svelte': self._parse_svelte_imports,
            })
        
        return extensions
    
    def _parse_markdown_imports(self, content: str, file_path: Path) -> List[ImportStatement]:
        """Parse imports from markdown files (basic implementation)."""
        imports = []
        lines = content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            # Look for import patterns in markdown code blocks
            if line.strip().startswith('```'):
                # In code block - parse as appropriate language
                continue
            # Basic import pattern matching for markdown
            if 'import ' in line or 'require(' in line:
                # Use TypeScript parser as fallback
                imports.extend(self._parse_typescript_imports(line, file_path))
        
        return imports
    
    def _parse_vue_imports(self, content: str, file_path: Path) -> List[ImportStatement]:
        """Parse imports from Vue single-file components."""
        imports = []
        
        # Extract script section
        script_match = re.search(r'<script[^>]*>(.*?)</script>', content, re.DOTALL)
        if script_match:
            script_content = script_match.group(1)
            imports.extend(self._parse_javascript_imports(script_content, file_path))
        
        return imports
    
    def _parse_svelte_imports(self, content: str, file_path: Path) -> List[ImportStatement]:
        """Parse imports from Svelte components."""
        imports = []
        
        # Extract script section
        script_match = re.search(r'<script[^>]*>(.*?)</script>', content, re.DOTALL)
        if script_match:
            script_content = script_match.group(1)
            imports.extend(self._parse_javascript_imports(script_content, file_path))
        
        return imports
    
    def get_import_summary(self, file_imports: Dict[Path, FileImports]) -> Dict[str, Any]:
        """Generate summary of all parsed imports."""
        all_imports = []
        errors = []
        
        for file_path, imports_data in file_imports.items():
            if imports_data.has_errors:
                errors.extend([f"{file_path}: {error}" for error in imports_data.error_messages])
            all_imports.extend(imports_data.imports)
        
        # Group by module
        module_imports: Dict[str, List[ImportStatement]] = {}
        for imp in all_imports:
            normalized = self.normalize_module_path(imp.module, imp.source_file)
            if normalized:
                if normalized not in module_imports:
                    module_imports[normalized] = []
                module_imports[normalized].append(imp)
        
        return {
            'total_files_parsed': len(file_imports),
            'total_imports_found': len(all_imports),
            'unique_modules': len(module_imports),
            'module_imports': module_imports,
            'errors': errors,
            'files_with_errors': sum(1 for fi in file_imports.values() if fi.has_errors)
        }
