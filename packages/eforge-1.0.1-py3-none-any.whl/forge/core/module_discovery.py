"""
forge.core.module_discovery

Minimal, futureproof module discovery system.
Integrates with existing manifest graph without bloat.

Design Principles:
- Zero configuration required
- Works with existing manifest structure
- Provides suggestions, not automatic mutations
- Extensible for future file types
- Performance-conscious scanning
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple

from forge.core.schemas import NodeTier


class DiscoveredModule:
    """Represents a discovered module with minimal metadata."""
    
    def __init__(self, path: Path, project_root: Path):
        self.path = path.relative_to(project_root)
        self.project_root = project_root
        self.name = self._infer_name()
        self.domain = self._infer_domain()
        self.kind = self._infer_kind()
        self.tier = self._infer_tier()
        
    def _infer_name(self) -> str:
        """Infer module name from path."""
        parts = self.path.parts
        if len(parts) >= 2 and parts[0] in ("forge", "src", "lib"):
            return str(parts[1]) if len(parts) > 2 else str(parts[0])
        return self.path.stem
        
    def _infer_domain(self) -> str | None:
        """Infer domain from path structure."""
        parts = self.path.parts
        for part in parts:
            if part.upper() in {"CORE", "AUTH", "REMOTE", "PREMIUM", "TOOLS"}:
                return part.upper()
        return "CORE" if "core" in parts else None
        
    def _infer_tier(self) -> NodeTier:
        """Infer tier from path and kind."""
        if "core" in self.path.parts or self.kind == "schema":
            return NodeTier.SCHEMA
        return NodeTier.WORKER
        
    def _infer_kind(self) -> str:
        """Infer module kind from path and filename."""
        if self.path.name.startswith("test_") or "tests" in self.path.parts:
            return "test"
        if "schema" in self.path.parts or self.path.name.endswith("_schema.py"):
            return "schema"
        if "cli" in self.path.parts or "commands" in self.path.parts:
            return "controller"
        return "module"
        
    def to_manifest_entry(self) -> Dict[str, Any]:
        """Convert to manifest-compatible entry."""
        return {
            "id": f"{self.kind}/{self.name}",
            "name": self.name,
            "path": str(self.path),
            "domain": self.domain,
            "tier": self.tier.value,
            "kind": self.kind,
            "meta": {
                "discovered": True,
                "auto_generated": True,
            }
        }


class ModuleDiscovery:
    """Minimal module discovery engine."""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root.resolve()
        self.excluded_dirs = {
            "__pycache__", ".git", ".forge", "node_modules", 
            ".venv", "venv", "env", ".env", "dist", "build"
        }
        self.excluded_files = {
            "__init__.py", "conftest.py", "setup.py"
        }
        
    def discover_python_modules(self) -> List[DiscoveredModule]:
        """Discover Python modules in the project."""
        modules = []
        
        # Priority directories to scan
        priority_dirs = ["forge", "src", "lib"]
        
        for priority_dir in priority_dirs:
            dir_path = self.project_root / priority_dir
            if dir_path.is_dir():
                modules.extend(self._scan_directory(dir_path))
                
        # Fallback to root scan if no priority directories found
        if not modules:
            modules.extend(self._scan_directory(self.project_root))
            
        return modules
        
    def _scan_directory(self, directory: Path) -> List[DiscoveredModule]:
        """Scan a directory for Python modules."""
        modules = []
        
        for root, dirs, files in os.walk(directory):
            # Filter out excluded directories
            dirs[:] = [d for d in dirs if d not in self.excluded_dirs]
            
            root_path = Path(root)
            
            for file in files:
                if not file.endswith(".py"):
                    continue
                    
                file_path = root_path / file
                
                # Skip excluded files
                if file in self.excluded_files:
                    continue
                    
                # Skip test files in separate test directories
                if "tests" in file_path.parts and file.startswith("test_"):
                    continue
                    
                module = DiscoveredModule(file_path, self.project_root)
                modules.append(module)
                
        return modules
        
    def find_untracked_modules(self, existing_manifest: Dict[str, Any]) -> List[DiscoveredModule]:
        """Find modules not in the current manifest."""
        discovered = self.discover_python_modules()
        
        # Extract existing module paths from manifest
        existing_paths = set()
        for module in existing_manifest.get("modules", []):
            if isinstance(module, dict) and "path" in module:
                existing_paths.add(Path(module["path"]))
                
        # Filter out already tracked modules
        untracked = [
            module for module in discovered 
            if module.path not in existing_paths
        ]
        
        return untracked
        
    def suggest_manifest_additions(self, existing_manifest: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate suggested manifest entries for untracked modules."""
        untracked = self.find_untracked_modules(existing_manifest)
        return [module.to_manifest_entry() for module in untracked]


def discover_modules(project_root: Path) -> List[DiscoveredModule]:
    """Convenience function for module discovery."""
    discovery = ModuleDiscovery(project_root)
    return discovery.discover_python_modules()


def suggest_manifest_updates(project_root: Path, existing_manifest: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Convenience function for manifest suggestions."""
    discovery = ModuleDiscovery(project_root)
    return discovery.suggest_manifest_additions(existing_manifest)
