from __future__ import annotations

import sys
from pathlib import Path


_ROOT_MANIFEST_WARNING = "manifest.yaml found at root — expected .forge/manifest.yaml"


def manifest_candidates(project_root: Path) -> list[Path]:
    root = Path(str(project_root)).expanduser().resolve()
    return [
        root / ".forge" / "manifest.yaml",
        root / "manifest.yaml",
        root / "docs" / "manifest.yaml",
    ]


def resolve_manifest_path(
    project_root: Path,
    *,
    warn_on_root_fallback: bool = True,
) -> Path | None:
    for candidate in manifest_candidates(project_root):
        if not candidate.is_file():
            continue
        if (
            warn_on_root_fallback
            and candidate.name == "manifest.yaml"
            and candidate.parent == project_root.expanduser().resolve()
        ):
            print(_ROOT_MANIFEST_WARNING, file=sys.stderr)
        return candidate
    return None
