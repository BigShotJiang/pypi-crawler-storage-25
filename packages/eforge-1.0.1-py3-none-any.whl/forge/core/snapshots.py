"""Forge Snapshots implementation for INTENT-B36D0989.

Persistence layer that allows Forge graph state to survive beyond stdio process
lifetime and be accessible from non-local clients with local-first architecture.
"""

import hashlib
import json
import logging
import sqlite3
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
from uuid import uuid4

from forge.core.path_utils import resolve_project_path

logger = logging.getLogger(__name__)


class SnapshotType(Enum):
    """Type of snapshot."""
    FULL = "full"  # Complete state
    INCREMENTAL = "incremental"  # Changes since last snapshot
    SESSION = "session"  # Session state only


class SnapshotStatus(Enum):
    """Snapshot status."""
    PENDING = "pending"
    CREATING = "creating"
    COMPLETED = "completed"
    FAILED = "failed"
    CORRUPTED = "corrupted"


@dataclass
class SnapshotMetadata:
    """Metadata for a snapshot."""
    id: str = field(default_factory=lambda: str(uuid4()))
    snapshot_type: SnapshotType = SnapshotType.FULL
    status: SnapshotStatus = SnapshotStatus.PENDING
    created_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None
    size_bytes: int = 0
    checksum: Optional[str] = None
    workspace_id: str = ""
    forge_version: str = ""
    schema_version: str = "1.0"
    parent_snapshot_id: Optional[str] = None  # For incremental snapshots
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "snapshot_type": self.snapshot_type.value,
            "status": self.status.value,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
            "size_bytes": self.size_bytes,
            "checksum": self.checksum,
            "workspace_id": self.workspace_id,
            "forge_version": self.forge_version,
            "schema_version": self.schema_version,
            "parent_snapshot_id": self.parent_snapshot_id,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SnapshotMetadata":
        """Create from dictionary."""
        return cls(
            id=data["id"],
            snapshot_type=SnapshotType(data["snapshot_type"]),
            status=SnapshotStatus(data["status"]),
            created_at=data["created_at"],
            completed_at=data.get("completed_at"),
            size_bytes=data["size_bytes"],
            checksum=data.get("checksum"),
            workspace_id=data["workspace_id"],
            forge_version=data["forge_version"],
            schema_version=data["schema_version"],
            parent_snapshot_id=data.get("parent_snapshot_id"),
            metadata=data.get("metadata", {})
        )


@dataclass
class SnapshotData:
    """Complete snapshot data including all graphs."""
    manifest_graph: Dict[str, Any] = field(default_factory=dict)
    intent_graph: List[Dict[str, Any]] = field(default_factory=list)
    session_state: Dict[str, Any] = field(default_factory=dict)
    vector_memory: Dict[str, Any] = field(default_factory=dict)
    event_log: List[Dict[str, Any]] = field(default_factory=list)
    annotations: Dict[str, Any] = field(default_factory=dict)
    tasks: Dict[str, Any] = field(default_factory=dict)
    apps: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_json(self) -> str:
        """Convert to JSON string."""
        return json.dumps({
            "manifest_graph": self.manifest_graph,
            "intent_graph": self.intent_graph,
            "session_state": self.session_state,
            "vector_memory": self.vector_memory,
            "event_log": self.event_log,
            "annotations": self.annotations,
            "tasks": self.tasks,
            "apps": self.apps,
            "metadata": self.metadata
        }, indent=2)
    
    @classmethod
    def from_json(cls, json_str: str) -> "SnapshotData":
        """Create from JSON string."""
        data = json.loads(json_str)
        return cls(
            manifest_graph=data.get("manifest_graph", {}),
            intent_graph=data.get("intent_graph", []),
            session_state=data.get("session_state", {}),
            vector_memory=data.get("vector_memory", {}),
            event_log=data.get("event_log", []),
            annotations=data.get("annotations", {}),
            tasks=data.get("tasks", {}),
            apps=data.get("apps", {}),
            metadata=data.get("metadata", {})
        )
    
    def calculate_checksum(self) -> str:
        """Calculate SHA-256 checksum of snapshot data."""
        content = self.to_json().encode('utf-8')
        return hashlib.sha256(content).hexdigest()


class SnapshotStore(ABC):
    """Abstract base for snapshot storage backends."""
    
    @abstractmethod
    def save_snapshot(self, metadata: SnapshotMetadata, data: SnapshotData) -> bool:
        """Save a snapshot."""
        pass
    
    @abstractmethod
    def load_snapshot(self, snapshot_id: str) -> Tuple[Optional[SnapshotMetadata], Optional[SnapshotData]]:
        """Load a snapshot."""
        pass
    
    @abstractmethod
    def list_snapshots(self, workspace_id: str, limit: int = 100) -> List[SnapshotMetadata]:
        """List snapshots for a workspace."""
        pass
    
    @abstractmethod
    def delete_snapshot(self, snapshot_id: str) -> bool:
        """Delete a snapshot."""
        pass
    
    @abstractmethod
    def get_latest_snapshot(self, workspace_id: str, snapshot_type: Optional[SnapshotType] = None) -> Optional[SnapshotMetadata]:
        """Get the latest snapshot for a workspace."""
        pass


class SQLiteSnapshotStore(SnapshotStore):
    """SQLite-based snapshot store for local persistence."""
    
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_database()
    
    def _init_database(self) -> None:
        """Initialize database schema."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS snapshots (
                    id TEXT PRIMARY KEY,
                    snapshot_type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    completed_at REAL,
                    size_bytes INTEGER NOT NULL,
                    checksum TEXT,
                    workspace_id TEXT NOT NULL,
                    forge_version TEXT,
                    schema_version TEXT NOT NULL,
                    parent_snapshot_id TEXT,
                    metadata TEXT,
                    data TEXT
                )
            """)
            
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_workspace_created 
                ON snapshots(workspace_id, created_at DESC)
            """)
            
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_workspace_status 
                ON snapshots(workspace_id, status)
            """)
    
    def save_snapshot(self, metadata: SnapshotMetadata, data: SnapshotData) -> bool:
        """Save a snapshot to SQLite database."""
        try:
            with sqlite3.connect(self.db_path) as conn:
                # Calculate checksum
                checksum = data.calculate_checksum()
                metadata.checksum = checksum
                metadata.size_bytes = len(data.to_json().encode('utf-8'))
                
                conn.execute("""
                    INSERT OR REPLACE INTO snapshots 
                    (id, snapshot_type, status, created_at, completed_at, size_bytes, 
                     checksum, workspace_id, forge_version, schema_version, parent_snapshot_id, 
                     metadata, data)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    metadata.id,
                    metadata.snapshot_type.value,
                    metadata.status.value,
                    metadata.created_at,
                    metadata.completed_at,
                    metadata.size_bytes,
                    metadata.checksum,
                    metadata.workspace_id,
                    metadata.forge_version,
                    metadata.schema_version,
                    metadata.parent_snapshot_id,
                    json.dumps(metadata.metadata),
                    data.to_json()
                ))
                
            return True
            
        except Exception as e:
            logger.error(f"Failed to save snapshot {metadata.id}: {e}")
            return False
    
    def load_snapshot(self, snapshot_id: str) -> Tuple[Optional[SnapshotMetadata], Optional[SnapshotData]]:
        """Load a snapshot from SQLite database."""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.execute("""
                    SELECT id, snapshot_type, status, created_at, completed_at, size_bytes,
                           checksum, workspace_id, forge_version, schema_version, parent_snapshot_id,
                           metadata, data
                    FROM snapshots WHERE id = ?
                """, (snapshot_id,))
                
                row = cursor.fetchone()
                if not row:
                    return None, None
                
                # Reconstruct metadata
                metadata = SnapshotMetadata(
                    id=row[0],
                    snapshot_type=SnapshotType(row[1]),
                    status=SnapshotStatus(row[2]),
                    created_at=row[3],
                    completed_at=row[4],
                    size_bytes=row[5],
                    checksum=row[6],
                    workspace_id=row[7],
                    forge_version=row[8],
                    schema_version=row[9],
                    parent_snapshot_id=row[10],
                    metadata=json.loads(row[11]) if row[11] else {}
                )
                
                # Reconstruct data
                data = SnapshotData.from_json(row[12])
                
                # Verify checksum
                if metadata.checksum and data.calculate_checksum() != metadata.checksum:
                    logger.warning(f"Snapshot {snapshot_id} checksum mismatch, marking as corrupted")
                    metadata.status = SnapshotStatus.CORRUPTED
                    self._update_snapshot_status(snapshot_id, SnapshotStatus.CORRUPTED)
                    return metadata, None
                
                return metadata, data
                
        except Exception as e:
            logger.error(f"Failed to load snapshot {snapshot_id}: {e}")
            return None, None
    
    def list_snapshots(self, workspace_id: str, limit: int = 100) -> List[SnapshotMetadata]:
        """List snapshots for a workspace."""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.execute("""
                    SELECT id, snapshot_type, status, created_at, completed_at, size_bytes,
                           checksum, workspace_id, forge_version, schema_version, parent_snapshot_id,
                           metadata
                    FROM snapshots 
                    WHERE workspace_id = ? AND status != 'corrupted'
                    ORDER BY created_at DESC
                    LIMIT ?
                """, (workspace_id, limit))
                
                snapshots = []
                for row in cursor.fetchall():
                    metadata = SnapshotMetadata(
                        id=row[0],
                        snapshot_type=SnapshotType(row[1]),
                        status=SnapshotStatus(row[2]),
                        created_at=row[3],
                        completed_at=row[4],
                        size_bytes=row[5],
                        checksum=row[6],
                        workspace_id=row[7],
                        forge_version=row[8],
                        schema_version=row[9],
                        parent_snapshot_id=row[10],
                        metadata=json.loads(row[11]) if row[11] else {}
                    )
                    snapshots.append(metadata)
                
                return snapshots
                
        except Exception as e:
            logger.error(f"Failed to list snapshots for workspace {workspace_id}: {e}")
            return []
    
    def delete_snapshot(self, snapshot_id: str) -> bool:
        """Delete a snapshot."""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.execute("DELETE FROM snapshots WHERE id = ?", (snapshot_id,))
                return cursor.rowcount > 0
                
        except Exception as e:
            logger.error(f"Failed to delete snapshot {snapshot_id}: {e}")
            return False
    
    def get_latest_snapshot(self, workspace_id: str, snapshot_type: Optional[SnapshotType] = None) -> Optional[SnapshotMetadata]:
        """Get the latest snapshot for a workspace."""
        try:
            query = """
                SELECT id, snapshot_type, status, created_at, completed_at, size_bytes,
                       checksum, workspace_id, forge_version, schema_version, parent_snapshot_id,
                       metadata
                FROM snapshots 
                WHERE workspace_id = ? AND status = 'completed'
            """
            params = [workspace_id]
            
            if snapshot_type:
                query += " AND snapshot_type = ?"
                params.append(snapshot_type.value)
            
            query += " ORDER BY created_at DESC LIMIT 1"
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.execute(query, params)
                row = cursor.fetchone()
                
                if not row:
                    return None
                
                return SnapshotMetadata(
                    id=row[0],
                    snapshot_type=SnapshotType(row[1]),
                    status=SnapshotStatus(row[2]),
                    created_at=row[3],
                    completed_at=row[4],
                    size_bytes=row[5],
                    checksum=row[6],
                    workspace_id=row[7],
                    forge_version=row[8],
                    schema_version=row[9],
                    parent_snapshot_id=row[10],
                    metadata=json.loads(row[11]) if row[11] else {}
                )
                
        except Exception as e:
            logger.error(f"Failed to get latest snapshot for workspace {workspace_id}: {e}")
            return None
    
    def _update_snapshot_status(self, snapshot_id: str, status: SnapshotStatus) -> None:
        """Update snapshot status."""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    UPDATE snapshots SET status = ? WHERE id = ?
                """, (status.value, snapshot_id))
                
        except Exception as e:
            logger.error(f"Failed to update snapshot status for {snapshot_id}: {e}")


class SupabaseSnapshotStore(SnapshotStore):
    """Supabase-based snapshot store for remote persistence."""
    
    def __init__(self, url: str, key: str):
        self.url = url
        self.key = key
        # This would be implemented with actual Supabase client
        logger.info("Supabase snapshot store initialized (placeholder implementation)")
    
    def save_snapshot(self, metadata: SnapshotMetadata, data: SnapshotData) -> bool:
        """Save a snapshot to Supabase."""
        # Placeholder implementation
        logger.info(f"Saving snapshot {metadata.id} to Supabase (placeholder)")
        return True
    
    def load_snapshot(self, snapshot_id: str) -> Tuple[Optional[SnapshotMetadata], Optional[SnapshotData]]:
        """Load a snapshot from Supabase."""
        # Placeholder implementation
        logger.info(f"Loading snapshot {snapshot_id} from Supabase (placeholder)")
        return None, None
    
    def list_snapshots(self, workspace_id: str, limit: int = 100) -> List[SnapshotMetadata]:
        """List snapshots for a workspace."""
        # Placeholder implementation
        return []
    
    def delete_snapshot(self, snapshot_id: str) -> bool:
        """Delete a snapshot."""
        # Placeholder implementation
        return True
    
    def get_latest_snapshot(self, workspace_id: str, snapshot_type: Optional[SnapshotType] = None) -> Optional[SnapshotMetadata]:
        """Get the latest snapshot for a workspace."""
        # Placeholder implementation
        return None


class ForgeSnapshotManager:
    """Main snapshot manager for Forge."""
    
    def __init__(self, project_path: Path, remote_store: Optional[SnapshotStore] = None):
        self.project_path = project_path
        self.workspace_id = self._generate_workspace_id()
        
        # Local store (SQLite)
        local_db_path = project_path / ".forge" / "snapshots" / "snapshots.db"
        self.local_store = SQLiteSnapshotStore(local_db_path)
        
        # Remote store (Supabase or None)
        self.remote_store = remote_store
        
        # Forge version
        self.forge_version = self._get_forge_version()
    
    def _generate_workspace_id(self) -> str:
        """Generate workspace ID based on project path."""
        # Use hash of project path for consistent workspace ID
        path_str = str(self.project_path.resolve())
        return hashlib.sha256(path_str.encode('utf-8')).hexdigest()[:16]
    
    def _get_forge_version(self) -> str:
        """Get Forge version."""
        try:
            # Try to read from pyproject.toml or similar
            pyproject_path = self.project_path / "pyproject.toml"
            if pyproject_path.exists():
                import toml
                with open(pyproject_path, 'r') as f:
                    data = toml.load(f)
                    return data.get("project", {}).get("version", "unknown")
        except Exception:
            pass
        
        return "unknown"
    
    def create_snapshot(self, snapshot_type: SnapshotType = SnapshotType.FULL, 
                       parent_snapshot_id: Optional[str] = None) -> Optional[str]:
        """Create a snapshot of the current Forge state."""
        try:
            # Create metadata
            metadata = SnapshotMetadata(
                snapshot_type=snapshot_type,
                status=SnapshotStatus.CREATING,
                workspace_id=self.workspace_id,
                forge_version=self.forge_version,
                parent_snapshot_id=parent_snapshot_id
            )
            
            # Collect snapshot data
            data = self._collect_snapshot_data()
            
            # Save to local store
            if self.local_store.save_snapshot(metadata, data):
                metadata.status = SnapshotStatus.COMPLETED
                metadata.completed_at = time.time()
                self.local_store.save_snapshot(metadata, data)  # Update status
                
                # Sync to remote store if available
                if self.remote_store:
                    self.remote_store.save_snapshot(metadata, data)
                
                logger.info(f"Created snapshot {metadata.id} of type {snapshot_type.value}")
                return metadata.id
            else:
                metadata.status = SnapshotStatus.FAILED
                self.local_store.save_snapshot(metadata, data)  # Update status
                return None
                
        except Exception as e:
            logger.error(f"Failed to create snapshot: {e}")
            return None
    
    def restore_snapshot(self, snapshot_id: str) -> bool:
        """Restore a snapshot to the current Forge state."""
        try:
            # Try local store first
            metadata, data = self.local_store.load_snapshot(snapshot_id)
            
            # If not found locally, try remote store
            if not metadata and self.remote_store:
                metadata, data = self.remote_store.load_snapshot(snapshot_id)
                # Save to local store for future use
                if metadata and data:
                    self.local_store.save_snapshot(metadata, data)
            
            if not metadata or not data:
                logger.error(f"Snapshot {snapshot_id} not found")
                return False
            
            # Restore data to Forge
            success = self._restore_snapshot_data(data)
            
            if success:
                logger.info(f"Restored snapshot {snapshot_id}")
            else:
                logger.error(f"Failed to restore snapshot {snapshot_id}")
            
            return success
            
        except Exception as e:
            logger.error(f"Failed to restore snapshot {snapshot_id}: {e}")
            return False
    
    def _collect_snapshot_data(self) -> SnapshotData:
        """Collect all Forge state data for snapshot."""
        data = SnapshotData()
        
        # Collect manifest graph
        try:
            manifest_file = self.project_path / ".forge" / "manifest.yaml"
            if manifest_file.exists():
                import yaml
                with open(manifest_file, 'r') as f:
                    data.manifest_graph = yaml.safe_load(f) or {}
        except Exception as e:
            logger.warning(f"Failed to collect manifest graph: {e}")
        
        # Collect intent graph
        try:
            intent_dir = self.project_path / ".forge" / "intent"
            data.intent_graph = []
            
            for intent_file in intent_dir.glob("**/*.intent.yaml"):
                try:
                    import yaml
                    with open(intent_file, 'r') as f:
                        intent_data = yaml.safe_load(f) or {}
                        data.intent_graph.append(intent_data)
                except Exception as e:
                    logger.warning(f"Failed to load intent {intent_file}: {e}")
        except Exception as e:
            logger.warning(f"Failed to collect intent graph: {e}")
        
        # Collect session state
        try:
            session_file = self.project_path / ".forge" / "mcp_session.json"
            if session_file.exists():
                with open(session_file, 'r') as f:
                    data.session_state = json.load(f)
        except Exception as e:
            logger.warning(f"Failed to collect session state: {e}")
        
        # Collect vector memory
        try:
            from forge.core.vector_memory import get_vector_memory_store
            vm_store = get_vector_memory_store(self.project_path)
            stats = vm_store.get_stats()
            data.vector_memory = {
                "stats": stats,
                "entries_count": len(vm_store._entries)
            }
        except Exception as e:
            logger.warning(f"Failed to collect vector memory: {e}")
        
        # Collect event log
        try:
            from forge.core.event_log import get_event_log
            event_log = get_event_log()
            events = event_log.get_recent_events(1000)  # Last 1000 events
            data.event_log = [event.to_dict() for event in events]
        except Exception as e:
            logger.warning(f"Failed to collect event log: {e}")
        
        # Collect annotations
        try:
            annotations_dir = self.project_path / ".forge" / "annotations"
            index_file = annotations_dir / "index.yaml"
            if index_file.exists():
                import yaml
                with open(index_file, 'r') as f:
                    data.annotations = yaml.safe_load(f) or {}
        except Exception as e:
            logger.warning(f"Failed to collect annotations: {e}")
        
        # Collect tasks and apps (summary only)
        try:
            from forge.core.mcp_tasks import get_task_manager
            from forge.core.forge_apps import get_app_registry
            
            task_manager = get_task_manager(self.project_path)
            app_registry = get_app_registry(self.project_path)
            
            data.tasks = task_manager.get_task_stats()
            data.apps = app_registry.get_registry_stats()
        except Exception as e:
            logger.warning(f"Failed to collect tasks/apps: {e}")
        
        # Add metadata
        data.metadata = {
            "created_at": time.time(),
            "forge_version": self.forge_version,
            "workspace_id": self.workspace_id,
            "project_path": str(self.project_path)
        }
        
        return data
    
    def _restore_snapshot_data(self, data: SnapshotData) -> bool:
        """Restore snapshot data to Forge."""
        success = True
        
        # Restore manifest graph
        if data.manifest_graph:
            try:
                manifest_file = self.project_path / ".forge" / "manifest.yaml"
                manifest_file.parent.mkdir(parents=True, exist_ok=True)
                
                import yaml
                with open(manifest_file, 'w') as f:
                    yaml.dump(data.manifest_graph, f, default_flow_style=False)
                    
            except Exception as e:
                logger.error(f"Failed to restore manifest graph: {e}")
                success = False
        
        # Restore intent graph
        if data.intent_graph:
            try:
                intent_dir = self.project_path / ".forge" / "intent"
                intent_dir.mkdir(parents=True, exist_ok=True)
                
                import yaml
                for intent_data in data.intent_graph:
                    intent_id = intent_data.get("id")
                    if intent_id:
                        intent_file = intent_dir / f"{intent_id}.intent.yaml"
                        with open(intent_file, 'w') as f:
                            yaml.dump(intent_data, f, default_flow_style=False)
                            
            except Exception as e:
                logger.error(f"Failed to restore intent graph: {e}")
                success = False
        
        # Restore session state
        if data.session_state:
            try:
                session_file = self.project_path / ".forge" / "mcp_session.json"
                session_file.parent.mkdir(parents=True, exist_ok=True)
                
                with open(session_file, 'w') as f:
                    json.dump(data.session_state, f, indent=2)
                    
            except Exception as e:
                logger.error(f"Failed to restore session state: {e}")
                success = False
        
        # Note: Vector memory, event log, annotations, tasks, and apps are not restored
        # as they are typically large and/or ephemeral. They would need separate handling.
        
        return success
    
    def list_snapshots(self, limit: int = 100) -> List[SnapshotMetadata]:
        """List snapshots for the current workspace."""
        return self.local_store.list_snapshots(self.workspace_id, limit)
    
    def delete_snapshot(self, snapshot_id: str) -> bool:
        """Delete a snapshot."""
        success = self.local_store.delete_snapshot(snapshot_id)
        
        if success and self.remote_store:
            self.remote_store.delete_snapshot(snapshot_id)
        
        return success
    
    def get_latest_snapshot(self, snapshot_type: Optional[SnapshotType] = None) -> Optional[SnapshotMetadata]:
        """Get the latest snapshot."""
        return self.local_store.get_latest_snapshot(self.workspace_id, snapshot_type)
    
    def push_to_remote(self, snapshot_id: Optional[str] = None) -> bool:
        """Push local snapshot to remote store."""
        if not self.remote_store:
            logger.warning("No remote store configured")
            return False
        
        try:
            if snapshot_id:
                # Push specific snapshot
                metadata, data = self.local_store.load_snapshot(snapshot_id)
                if metadata and data:
                    return self.remote_store.save_snapshot(metadata, data)
            else:
                # Push latest snapshot
                latest = self.get_latest_snapshot()
                if latest:
                    metadata, data = self.local_store.load_snapshot(latest.id)
                    if metadata and data:
                        return self.remote_store.save_snapshot(metadata, data)
            
            return False
            
        except Exception as e:
            logger.error(f"Failed to push snapshot to remote: {e}")
            return False
    
    def pull_from_remote(self, snapshot_id: Optional[str] = None) -> bool:
        """Pull snapshot from remote store."""
        if not self.remote_store:
            logger.warning("No remote store configured")
            return False
        
        try:
            if snapshot_id:
                # Pull specific snapshot
                metadata, data = self.remote_store.load_snapshot(snapshot_id)
                if metadata and data:
                    return self.local_store.save_snapshot(metadata, data)
            else:
                # Pull latest snapshot
                latest_remote = self.remote_store.get_latest_snapshot(self.workspace_id)
                if latest_remote:
                    metadata, data = self.remote_store.load_snapshot(latest_remote.id)
                    if metadata and data:
                        return self.local_store.save_snapshot(metadata, data)
            
            return False
            
        except Exception as e:
            logger.error(f"Failed to pull snapshot from remote: {e}")
            return False


# Global snapshot managers
_snapshot_managers: Dict[str, ForgeSnapshotManager] = {}


def get_snapshot_manager(project_path: Path, 
                        remote_store: Optional[SnapshotStore] = None) -> ForgeSnapshotManager:
    """Get or create a snapshot manager for a project."""
    project_key = str(project_path.resolve())
    if project_key not in _snapshot_managers:
        _snapshot_managers[project_key] = ForgeSnapshotManager(project_path, remote_store)
    return _snapshot_managers[project_key]


def create_snapshot(snapshot_type: str = "full", 
                  project_path: Optional[str] = None,
                  parent_snapshot_id: Optional[str] = None) -> Optional[str]:
    """Create a snapshot."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    manager = get_snapshot_manager(Path(project_path))
    snapshot_type_enum = SnapshotType(snapshot_type)
    return manager.create_snapshot(snapshot_type_enum, parent_snapshot_id)


def restore_snapshot(snapshot_id: str, project_path: Optional[str] = None) -> bool:
    """Restore a snapshot."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    manager = get_snapshot_manager(Path(project_path))
    return manager.restore_snapshot(snapshot_id)


def list_snapshots(limit: int = 100, project_path: Optional[str] = None) -> List[Dict[str, Any]]:
    """List snapshots."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    manager = get_snapshot_manager(Path(project_path))
    snapshots = manager.list_snapshots(limit)
    return [snapshot.to_dict() for snapshot in snapshots]


__all__ = [
    "SnapshotType",
    "SnapshotStatus",
    "SnapshotMetadata",
    "SnapshotData",
    "SnapshotStore",
    "SQLiteSnapshotStore",
    "SupabaseSnapshotStore",
    "ForgeSnapshotManager",
    "get_snapshot_manager",
    "create_snapshot",
    "restore_snapshot",
    "list_snapshots"
]
