"""Forge Apps implementation for INTENT-344E846B.

First-class protocol concepts for structured capability surfaces with
named, versioned, domain-scoped bundles of tools + resources + prompts.
"""

import json
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set
from uuid import uuid4

from forge.core.path_utils import resolve_project_path

logger = logging.getLogger(__name__)


class AppType(Enum):
    """Forge App type enumeration."""
    FRAMEWORK = "framework"      # Core Forge framework tools
    DOMAIN = "domain"            # Domain-specific tools (e.g., canvas, database)
    INTEGRATION = "integration"  # External integrations
    UTILITY = "utility"          # Utility and helper tools


@dataclass
class AppCapability:
    """A single capability within an app."""
    name: str
    type: str  # "tool", "resource", "prompt"
    description: str
    version: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ForgeApp:
    """Forge App representation."""
    id: str = field(default_factory=lambda: str(uuid4()))
    name: str = ""
    version: str = "1.0.0"
    app_type: AppType = AppType.UTILITY
    domain: str = "general"
    description: str = ""
    capabilities: List[AppCapability] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)  # Other app IDs
    config: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    project_path: str = ""
    
    def __post_init__(self):
        """Post-initialization processing."""
        if not self.updated_at:
            self.updated_at = self.created_at
    
    def add_capability(self, name: str, capability_type: str, description: str,
                      version: str = "1.0.0", metadata: Optional[Dict[str, Any]] = None) -> None:
        """Add a capability to the app."""
        capability = AppCapability(
            name=name,
            type=capability_type,
            description=description,
            version=version,
            metadata=metadata or {}
        )
        self.capabilities.append(capability)
        self.updated_at = time.time()
    
    def get_tools(self) -> List[AppCapability]:
        """Get tool capabilities."""
        return [c for c in self.capabilities if c.type == "tool"]
    
    def get_resources(self) -> List[AppCapability]:
        """Get resource capabilities."""
        return [c for c in self.capabilities if c.type == "resource"]
    
    def get_prompts(self) -> List[AppCapability]:
        """Get prompt capabilities."""
        return [c for c in self.capabilities if c.type == "prompt"]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert app to dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "version": self.version,
            "app_type": self.app_type.value,
            "domain": self.domain,
            "description": self.description,
            "capabilities": [
                {
                    "name": c.name,
                    "type": c.type,
                    "description": c.description,
                    "version": c.version,
                    "metadata": c.metadata
                }
                for c in self.capabilities
            ],
            "dependencies": self.dependencies,
            "config": self.config,
            "metadata": self.metadata,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "project_path": self.project_path
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ForgeApp":
        """Create app from dictionary."""
        app = cls(
            id=data["id"],
            name=data["name"],
            version=data["version"],
            app_type=AppType(data["app_type"]),
            domain=data["domain"],
            description=data["description"],
            dependencies=data.get("dependencies", []),
            config=data.get("config", {}),
            metadata=data.get("metadata", {}),
            project_path=data.get("project_path", "")
        )
        
        # Restore capabilities
        for cap_data in data.get("capabilities", []):
            capability = AppCapability(
                name=cap_data["name"],
                type=cap_data["type"],
                description=cap_data["description"],
                version=cap_data["version"],
                metadata=cap_data.get("metadata", {})
            )
            app.capabilities.append(capability)
        
        # Restore timestamps
        app.created_at = data.get("created_at", time.time())
        app.updated_at = data.get("updated_at", app.created_at)
        
        return app


class AppRegistry:
    """Registry for managing Forge Apps."""
    
    def __init__(self, project_path: Path):
        self.project_path = project_path
        self.apps_dir = project_path / ".forge" / "apps"
        self.apps_dir.mkdir(parents=True, exist_ok=True)
        
        self.apps_file = self.apps_dir / "apps.jsonl"
        self.config_file = self.apps_dir / "app_config.yaml"
        
        self._apps: Dict[str, ForgeApp] = {}
        
        self._load_apps()
        self._load_config()
    
    def _load_apps(self) -> None:
        """Load apps from storage."""
        try:
            if self.apps_file.exists():
                with open(self.apps_file, 'r') as f:
                    for line in f:
                        try:
                            data = json.loads(line.strip())
                            app = ForgeApp.from_dict(data)
                            self._apps[app.id] = app
                        except (json.JSONDecodeError, KeyError):
                            continue
            
            logger.info(f"Loaded {len(self._apps)} apps from storage")
            
        except Exception as e:
            logger.error(f"Failed to load apps: {e}")
    
    def _load_config(self) -> None:
        """Load app configuration from YAML file."""
        try:
            if self.config_file.exists():
                import yaml
                with open(self.config_file, 'r') as f:
                    config = yaml.safe_load(f) or {}
                
                # Create apps from config
                for app_name, app_config in config.items():
                    if app_name not in [app.name for app in self._apps.values()]:
                        app = ForgeApp(
                            name=app_name,
                            version=app_config.get("version", "1.0.0"),
                            app_type=AppType(app_config.get("type", "utility")),
                            domain=app_config.get("domain", "general"),
                            description=app_config.get("description", ""),
                            config=app_config.get("config", {}),
                            metadata=app_config.get("metadata", {}),
                            project_path=str(self.project_path)
                        )
                        
                        # Add capabilities from config
                        for cap_name, cap_config in app_config.get("capabilities", {}).items():
                            app.add_capability(
                                name=cap_name,
                                capability_type=cap_config.get("type", "tool"),
                                description=cap_config.get("description", ""),
                                version=cap_config.get("version", "1.0.0"),
                                metadata=cap_config.get("metadata", {})
                            )
                        
                        self._apps[app.id] = app
                
                logger.info(f"Loaded {len([a for a in self._apps.values() if a.name == app_name])} apps from config")
            
        except Exception as e:
            logger.error(f"Failed to load app config: {e}")
    
    def _save_apps(self) -> None:
        """Save apps to storage."""
        try:
            with open(self.apps_file, 'w') as f:
                for app in self._apps.values():
                    f.write(json.dumps(app.to_dict()) + '\n')
        except Exception as e:
            logger.error(f"Failed to save apps: {e}")
    
    def register_app(self, app: ForgeApp) -> str:
        """Register a new app."""
        app.project_path = str(self.project_path)
        self._apps[app.id] = app
        self._save_apps()
        
        logger.info(f"Registered app {app.id}: {app.name}")
        return app.id
    
    def get_app(self, app_id: str) -> Optional[ForgeApp]:
        """Get an app by ID."""
        return self._apps.get(app_id)
    
    def get_app_by_name(self, name: str) -> Optional[ForgeApp]:
        """Get an app by name."""
        for app in self._apps.values():
            if app.name == name:
                return app
        return None
    
    def list_apps(self, app_type_filter: Optional[AppType] = None,
                 domain_filter: Optional[str] = None) -> List[ForgeApp]:
        """List apps with optional filtering."""
        apps = list(self._apps.values())
        
        # Apply filters
        if app_type_filter:
            apps = [a for a in apps if a.app_type == app_type_filter]
        
        if domain_filter:
            apps = [a for a in apps if a.domain == domain_filter]
        
        # Sort by name
        apps.sort(key=lambda a: a.name)
        
        return apps
    
    def update_app(self, app_id: str, **updates) -> bool:
        """Update an app."""
        app = self._apps.get(app_id)
        if not app:
            return False
        
        for key, value in updates.items():
            if hasattr(app, key):
                setattr(app, key, value)
        
        app.updated_at = time.time()
        self._save_apps()
        return True
    
    def unregister_app(self, app_id: str) -> bool:
        """Unregister an app."""
        if app_id in self._apps:
            del self._apps[app_id]
            self._save_apps()
            logger.info(f"Unregistered app {app_id}")
            return True
        return False
    
    def get_app_capabilities(self, app_id: str) -> Optional[Dict[str, List[AppCapability]]]:
        """Get all capabilities for an app."""
        app = self.get_app(app_id)
        if not app:
            return None
        
        return {
            "tools": app.get_tools(),
            "resources": app.get_resources(),
            "prompts": app.get_prompts()
        }
    
    def search_capabilities(self, query: str, capability_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """Search for capabilities across all apps."""
        results = []
        query_lower = query.lower()
        
        for app in self._apps.values():
            for capability in app.capabilities:
                if capability_type and capability.type != capability_type:
                    continue
                
                # Search in name and description
                if (query_lower in capability.name.lower() or 
                    query_lower in capability.description.lower()):
                    results.append({
                        "app_id": app.id,
                        "app_name": app.name,
                        "app_version": app.version,
                        "app_type": app.app_type.value,
                        "capability": capability
                    })
        
        return results
    
    def get_registry_stats(self) -> Dict[str, Any]:
        """Get registry statistics."""
        type_counts = {}
        domain_counts = {}
        capability_counts = {"tool": 0, "resource": 0, "prompt": 0}
        
        for app in self._apps.values():
            type_counts[app.app_type.value] = type_counts.get(app.app_type.value, 0) + 1
            domain_counts[app.domain] = domain_counts.get(app.domain, 0) + 1
            
            for capability in app.capabilities:
                capability_counts[capability.type] = capability_counts.get(capability.type, 0) + 1
        
        return {
            "total_apps": len(self._apps),
            "type_distribution": type_counts,
            "domain_distribution": domain_counts,
            "capability_distribution": capability_counts,
            "project_path": str(self.project_path)
        }


# Global app registries
_app_registries: Dict[str, AppRegistry] = {}


def get_app_registry(project_path: Path) -> AppRegistry:
    """Get or create an app registry for a project."""
    project_key = str(project_path.resolve())
    if project_key not in _app_registries:
        _app_registries[project_key] = AppRegistry(project_path)
    return _app_registries[project_key]


def register_app(name: str, app_type: str, domain: str = "general", description: str = "",
                version: str = "1.0.0", config: Optional[Dict[str, Any]] = None,
                project_path: Optional[str] = None) -> ForgeApp:
    """Register a new Forge App."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    app = ForgeApp(
        name=name,
        version=version,
        app_type=AppType(app_type),
        domain=domain,
        description=description,
        config=config or {},
        project_path=project_path
    )
    
    registry = get_app_registry(Path(project_path))
    registry.register_app(app)
    
    return app


def get_app(app_id: str, project_path: Optional[str] = None) -> Optional[ForgeApp]:
    """Get an app by ID."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    registry = get_app_registry(Path(project_path))
    return registry.get_app(app_id)


def list_apps(app_type_filter: Optional[str] = None, domain_filter: Optional[str] = None,
             project_path: Optional[str] = None) -> List[ForgeApp]:
    """List apps with optional filtering."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    registry = get_app_registry(Path(project_path))
    
    # Convert filter string to enum
    type_enum = None
    if app_type_filter:
        try:
            type_enum = AppType(app_type_filter)
        except ValueError:
            pass
    
    return registry.list_apps(type_enum, domain_filter)


def search_capabilities(query: str, capability_type: Optional[str] = None,
                       project_path: Optional[str] = None) -> List[Dict[str, Any]]:
    """Search for capabilities across all apps."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    registry = get_app_registry(Path(project_path))
    return registry.search_capabilities(query, capability_type)


class AppBuilder:
    """Builder for creating Forge Apps with fluent interface."""
    
    def __init__(self, name: str, app_type: str = "utility"):
        self.app = ForgeApp(
            name=name,
            app_type=AppType(app_type)
        )
    
    def version(self, version: str) -> "AppBuilder":
        """Set app version."""
        self.app.version = version
        return self
    
    def domain(self, domain: str) -> "AppBuilder":
        """Set app domain."""
        self.app.domain = domain
        return self
    
    def description(self, description: str) -> "AppBuilder":
        """Set app description."""
        self.app.description = description
        return self
    
    def config(self, config: Dict[str, Any]) -> "AppBuilder":
        """Set app configuration."""
        self.app.config = config
        return self
    
    def metadata(self, metadata: Dict[str, Any]) -> "AppBuilder":
        """Set app metadata."""
        self.app.metadata = metadata
        return self
    
    def tool(self, name: str, description: str, version: str = "1.0.0",
             metadata: Optional[Dict[str, Any]] = None) -> "AppBuilder":
        """Add a tool capability."""
        self.app.add_capability(name, "tool", description, version, metadata)
        return self
    
    def resource(self, name: str, description: str, version: str = "1.0.0",
                metadata: Optional[Dict[str, Any]] = None) -> "AppBuilder":
        """Add a resource capability."""
        self.app.add_capability(name, "resource", description, version, metadata)
        return self
    
    def prompt(self, name: str, description: str, version: str = "1.0.0",
              metadata: Optional[Dict[str, Any]] = None) -> "AppBuilder":
        """Add a prompt capability."""
        self.app.add_capability(name, "prompt", description, version, metadata)
        return self
    
    def dependency(self, app_id: str) -> "AppBuilder":
        """Add a dependency."""
        self.app.dependencies.append(app_id)
        return self
    
    def build(self, project_path: Optional[str] = None) -> ForgeApp:
        """Build and register the app."""
        if not project_path:
            project_path = str(resolve_project_path())
        
        registry = get_app_registry(Path(project_path))
        registry.register_app(self.app)
        
        return self.app


__all__ = [
    "AppType",
    "AppCapability",
    "ForgeApp",
    "AppRegistry",
    "AppBuilder",
    "get_app_registry",
    "register_app",
    "get_app",
    "list_apps",
    "search_capabilities"
]
