from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Iterable, List

from forge.archive.tui.textual.manifest_reader import (
    ContractBlock,
    ContractExposes,
    ContractRequires,
    ManifestData,
    read_manifest,
)

if TYPE_CHECKING:
    from forge.archive.tui.textual.state import ProjectState


class EdgeStatus(Enum):
    PLANNED = "planned"
    ACTIVE = "active"
    BROKEN = "broken"
    ORPHANED = "orphaned"
    UNRESOLVED = "unresolved"


@dataclass
class ContractEdge:
    source_project: str
    source_domain: str
    target_project: str
    target_domain: str
    field_name: str
    declared_type: str
    provided_type: str | None
    phase: int | None
    status: EdgeStatus
    message: str


@dataclass
class ContractGraph:
    edges: list[ContractEdge] = field(default_factory=list)

    def intra_edges(self, project_id: str) -> list[ContractEdge]:
        """Edges where source and target are the same project_id."""
        return [
            e
            for e in self.edges
            if e.source_project == project_id and e.target_project == project_id
        ]

    def inter_edges(self, project_id: str) -> list[ContractEdge]:
        """Edges crossing project boundaries involving this project."""
        return [
            e
            for e in self.edges
            if e.source_project == project_id or e.target_project == project_id
            if e.source_project != e.target_project
        ]

    def broken_edges(self) -> list[ContractEdge]:
        """Edges that are broken or orphaned."""
        return [e for e in self.edges if e.status in {EdgeStatus.BROKEN, EdgeStatus.ORPHANED}]

    def conformance_score(self, project_id: str) -> int:
        """
        0–100. Projects with no contract data score 100.

        Formula (per design):
          total_edges = count of all contract edges (intra + inter) for this project
          score_base = (active + planned) / total_edges * 100
          penalty = 10 * broken + 10 * orphaned + 5 * unresolved
          score = score_base - penalty, clamped to [0, 100]
        """
        relevant = [
            e
            for e in self.edges
            if e.source_project == project_id or e.target_project == project_id
        ]
        if not relevant:
            return 100

        total_edges = len(relevant)
        active = sum(1 for e in relevant if e.status == EdgeStatus.ACTIVE)
        planned = sum(1 for e in relevant if e.status == EdgeStatus.PLANNED)
        broken = sum(1 for e in relevant if e.status == EdgeStatus.BROKEN)
        orphaned = sum(1 for e in relevant if e.status == EdgeStatus.ORPHANED)
        unresolved = sum(1 for e in relevant if e.status == EdgeStatus.UNRESOLVED)

        score_base = int(((active + planned) / total_edges) * 100)
        penalty = broken * 10 + orphaned * 10 + unresolved * 5
        score = max(0, min(100, score_base - penalty))
        return score


def _index_exposes(manifest: ManifestData, project_name: str) -> dict[tuple[str, str], ContractExposes]:
    """
    Build an index of (domain, field_name) -> ContractExposes for this project.
    """
    index: dict[tuple[str, str], ContractExposes] = {}
    for fc in manifest.controllers + manifest.services + manifest.hooks:
        if not fc.contract:
            continue
        dom = (fc.domain or "").strip()
        if not dom:
            continue
        for ex in fc.contract.exposes:
            key = (dom, ex.name)
            index[key] = ex
    return index


def build_contract_graph(states: Iterable["ProjectState"]) -> ContractGraph:
    """
    Build the full contract graph from a list of ProjectState objects.

    Algorithm (simplified, manifest-only for now):
    1. For each project, read ManifestData.
    2. For each FileContract with contract.requires:
       a. Resolve target project/domain (intra vs inter).
       b. Look up provider's ContractExposes.
       c. Compare types and phase to classify EdgeStatus.
    3. Collect all edges into a ContractGraph.

    Never raises — all errors become UNRESOLVED edges.
    """
    states_list: List["ProjectState"] = list(states)
    manifests: dict[str, ManifestData | None] = {}
    exposes_index: dict[str, dict[tuple[str, str], ContractExposes]] = {}

    for st in states_list:
        project_name = st.project.name
        try:
            md = read_manifest(st.project)
        except Exception:
            md = None
        manifests[project_name] = md
        if md is not None:
            exposes_index[project_name] = _index_exposes(md, project_name)

    edges: list[ContractEdge] = []

    for st in states_list:
        project_name = st.project.name
        md = manifests.get(project_name)
        if md is None:
            continue
        contracts = md.controllers + md.services + md.hooks
        for fc in contracts:
            if not fc.contract:
                continue
            source_domain = (fc.domain or "").strip()
            for req in fc.contract.requires:
                from_dom = (req.from_domain or "").strip()
                if not from_dom:
                    continue

                # Resolve target project/domain.
                if req.is_inter and "/" in from_dom:
                    target_project, target_domain = from_dom.split("/", 1)
                else:
                    target_project = project_name
                    target_domain = from_dom

                provider_manifest = manifests.get(target_project)
                provided_type: str | None = None
                status = EdgeStatus.UNRESOLVED
                message = "Target project or domain not found"

                if provider_manifest is not None:
                    ex_index = exposes_index.get(target_project, {})
                    key = (target_domain, req.name)
                    provider = ex_index.get(key)
                    if provider is None:
                        # Domain exists but field not exposed.
                        provided_type = None
                        message = (
                            f"{source_domain} requires {target_domain}.{req.name} "
                            f"but it is not exposed by {target_project}"
                        )
                        status = EdgeStatus.BROKEN
                    else:
                        provided_type = provider.type
                        declared = (req.type or "").strip()
                        if not declared or declared == provided_type:
                            # Honour phase: planned vs active.
                            if req.phase is not None and getattr(st.project, "current_phase", None):
                                try:
                                    current_phase = st.project.current_phase()
                                except Exception:
                                    current_phase = None
                            else:
                                current_phase = None

                            if req.phase is not None and current_phase is not None and req.phase > current_phase:
                                status = EdgeStatus.PLANNED
                                message = f"Dependency becomes active in Phase {req.phase}"
                            else:
                                status = EdgeStatus.ACTIVE
                                message = "Dependency satisfied"
                        else:
                            status = EdgeStatus.BROKEN
                            message = (
                                f"Type mismatch on {source_domain}.{req.name}: "
                                f"provider says {provided_type}, consumer expects {declared}"
                            )

                edge = ContractEdge(
                    source_project=project_name,
                    source_domain=source_domain,
                    target_project=target_project,
                    target_domain=target_domain,
                    field_name=req.name,
                    declared_type=req.type,
                    provided_type=provided_type,
                    phase=req.phase,
                    status=status,
                    message=message,
                )
                edges.append(edge)

    return ContractGraph(edges=edges)

