"""Secret scanner for INTENT-2F54177D Security model.

Scans file content for sensitive data patterns and redacts them before
they enter any Forge pipeline (scan, scaffold, context generation).

Never logs, stores, or transmits the original secret values.
"""

import base64
import re
import secrets
import string
from pathlib import Path
from typing import Dict, List, NamedTuple, Optional, Tuple
from dataclasses import dataclass


@dataclass
class SecretMatch:
    """Represents a detected secret with redaction info."""
    secret_type: str
    original_start: int
    original_end: int
    redacted_value: str
    confidence: float  # 0.0 to 1.0


class SecretScanner:
    """Scans content for sensitive data patterns and redacts them."""
    
    # Common secret patterns
    PATTERNS = {
        "aws_access_key": re.compile(r'AKIA[0-9A-Z]{16}', re.IGNORECASE),
        "aws_secret_key": re.compile(r'[A-Za-z0-9/+=]{40}', re.IGNORECASE),
        "github_token": re.compile(r'ghp_[a-zA-Z0-9]{36}', re.IGNORECASE),
        "github_pat": re.compile(r'github_pat_[a-zA-Z0-9_]{82}', re.IGNORECASE),
        "private_key_rsa": re.compile(r'-----BEGIN RSA PRIVATE KEY-----[\s\S]*?-----END RSA PRIVATE KEY-----'),
        "private_key_pem": re.compile(r'-----BEGIN PRIVATE KEY-----[\s\S]*?-----END PRIVATE KEY-----'),
        "private_key_ec": re.compile(r'-----BEGIN EC PRIVATE KEY-----[\s\S]*?-----END EC PRIVATE KEY-----'),
        "api_key_generic": re.compile(r'[A-Za-z0-9]{32,}', re.IGNORECASE),
        "jwt_token": re.compile(r'eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*'),
    }
    
    # High entropy detection (strings that look like random keys)
    HIGH_ENTROPY_THRESHOLD = 3.5  # Lowered to catch more potential secrets
    MIN_ENTROPY_LENGTH = 16
    
    def __init__(self):
        self.matches: List[SecretMatch] = []
    
    def scan_content(self, content: str, file_path: Optional[Path] = None) -> str:
        """
        Scan content for secrets and return redacted content.
        
        Args:
            content: The content to scan
            file_path: Optional file path for context
            
        Returns:
            Redacted content with secrets replaced by [REDACTED:type]
        """
        self.matches = []
        redacted_content = content
        
        # Scan for known patterns
        all_matches = []
        for secret_type, pattern in self.PATTERNS.items():
            for match in pattern.finditer(content):
                redacted_value = f"[REDACTED:{secret_type}]"
                secret_match = SecretMatch(
                    secret_type=secret_type,
                    original_start=match.start(),
                    original_end=match.end(),
                    redacted_value=redacted_value,
                    confidence=self._calculate_confidence(match.group(), secret_type)
                )
                all_matches.append(secret_match)
        
        # Remove overlapping matches (keep highest confidence)
        self.matches = self._remove_overlapping_matches(all_matches)
        
        # Scan for high entropy strings (only on remaining content)
        self._scan_high_entropy(content, self.matches)
        
        # Sort matches by position (reverse order to avoid offset issues)
        self.matches.sort(key=lambda m: m.original_start, reverse=True)
        
        # Apply redactions
        for match in self.matches:
            redacted_content = (
                redacted_content[:match.original_start] +
                match.redacted_value +
                redacted_content[match.original_end:]
            )
        
        return redacted_content
    
    def _remove_overlapping_matches(self, matches: List[SecretMatch]) -> List[SecretMatch]:
        """Remove overlapping matches, keeping specific patterns over high entropy."""
        if not matches:
            return []
        
        # Define pattern priority (higher number = higher priority)
        PRIORITY = {
            "aws_access_key": 10,
            "aws_secret_key": 10,
            "github_token": 10,
            "github_pat": 10,
            "private_key_rsa": 10,
            "private_key_pem": 10,
            "private_key_ec": 10,
            "jwt_token": 9,
            "api_key_generic": 8,
            "high_entropy": 1,  # Lowest priority
        }
        
        # Sort by priority (descending), then confidence, then start position
        matches.sort(key=lambda m: (PRIORITY.get(m.secret_type, 0), m.confidence, m.original_start), reverse=True)
        
        filtered_matches = []
        for match in matches:
            # Check if this match overlaps with any already accepted match
            overlaps = False
            for accepted in filtered_matches:
                if (match.original_start < accepted.original_end and 
                    match.original_end > accepted.original_start):
                    overlaps = True
                    break
            
            if not overlaps:
                filtered_matches.append(match)
        
        return filtered_matches
    
    def _scan_high_entropy(self, content: str, existing_matches: List[SecretMatch] = None) -> None:
        """Scan for high entropy strings that might be secret keys."""
        if existing_matches is None:
            existing_matches = []
        
        # Look for strings that could be random keys
        words = re.findall(r'\b[A-Za-z0-9+/=_-]{20,}\b', content)
        
        for word in words:
            if self._calculate_entropy(word) >= self.HIGH_ENTROPY_THRESHOLD:
                # Skip if it matches a known pattern (already caught)
                if any(pattern.fullmatch(word) for pattern in self.PATTERNS.values()):
                    continue
                
                # Find all occurrences of this word
                for match in re.finditer(re.escape(word), content):
                    # Check if this potential match overlaps with existing matches
                    match_start = match.start()
                    match_end = match.end()
                    
                    overlaps = False
                    for existing in existing_matches:
                        if (match_start < existing.original_end and 
                            match_end > existing.original_start):
                            overlaps = True
                            break
                    
                    if overlaps:
                        continue
                    
                    redacted_value = "[REDACTED:high_entropy]"
                    secret_match = SecretMatch(
                        secret_type="high_entropy",
                        original_start=match_start,
                        original_end=match_end,
                        redacted_value=redacted_value,
                        confidence=0.7  # Lower confidence for entropy-based detection
                    )
                    self.matches.append(secret_match)
    
    def _calculate_entropy(self, string: str) -> float:
        """Calculate Shannon entropy of a string."""
        if not string:
            return 0.0
        
        # Count character frequencies
        char_counts = {}
        for char in string:
            char_counts[char] = char_counts.get(char, 0) + 1
        
        # Calculate entropy
        import math
        entropy = 0.0
        string_len = len(string)
        
        for count in char_counts.values():
            probability = count / string_len
            if probability > 0:
                entropy -= probability * math.log2(probability)
        
        return entropy
    
    def _calculate_confidence(self, match: str, secret_type: str) -> float:
        """Calculate confidence score for a secret match."""
        base_confidence = {
            "aws_access_key": 0.95,
            "aws_secret_key": 0.85,
            "github_token": 0.95,
            "github_pat": 0.95,
            "private_key_rsa": 0.99,
            "private_key_pem": 0.99,
            "private_key_ec": 0.99,
            "api_key_generic": 0.6,
            "jwt_token": 0.8,
        }
        
        confidence = base_confidence.get(secret_type, 0.5)
        
        # Adjust confidence based on match characteristics
        if secret_type in ["aws_access_key", "github_token", "github_pat"]:
            # These have very specific formats - check if match matches pattern exactly
            pattern = self.PATTERNS[secret_type]
            if pattern.fullmatch(match):
                confidence += 0.05
        
        return min(confidence, 1.0)
    
    def scan_env_file(self, file_path: Path) -> str:
        """Scan .env file content and return redacted content."""
        if not file_path.exists():
            return ""
        
        try:
            content = file_path.read_text(encoding='utf-8')
            return self.scan_content(content, file_path)
        except Exception:
            # If we can't read the file, return empty string
            # Never log the error to avoid leaking file paths with secrets
            return ""
    
    def get_summary(self) -> Dict[str, int]:
        """Get summary of detected secrets by type."""
        summary = {}
        for match in self.matches:
            summary[match.secret_type] = summary.get(match.secret_type, 0) + 1
        return summary
    
    def has_secrets(self) -> bool:
        """Check if any secrets were detected."""
        return len(self.matches) > 0
    
    def get_redaction_count(self) -> int:
        """Get total number of redactions made."""
        return len(self.matches)


def scan_file_for_secrets(file_path: Path) -> Tuple[str, List[SecretMatch]]:
    """
    Convenience function to scan a file for secrets.
    
    Args:
        file_path: Path to the file to scan
        
    Returns:
        Tuple of (redacted_content, list_of_matches)
    """
    scanner = SecretScanner()
    
    if not file_path.exists():
        return "", []
    
    try:
        content = file_path.read_text(encoding='utf-8')
        redacted_content = scanner.scan_content(content, file_path)
        return redacted_content, scanner.matches
    except Exception:
        # If we can't read the file, return empty results
        # Never log the error to avoid leaking file paths with secrets
        return "", []


def scan_string_for_secrets(content: str) -> Tuple[str, List[SecretMatch]]:
    """
    Convenience function to scan a string for secrets.
    
    Args:
        content: String content to scan
        
    Returns:
        Tuple of (redacted_content, list_of_matches)
    """
    scanner = SecretScanner()
    redacted_content = scanner.scan_content(content)
    return redacted_content, scanner.matches


def is_safe_content(content: str) -> bool:
    """
    Check if content is safe (contains no secrets).
    
    Args:
        content: String content to check
        
    Returns:
        True if no secrets detected, False otherwise
    """
    _, matches = scan_string_for_secrets(content)
    return len(matches) == 0
