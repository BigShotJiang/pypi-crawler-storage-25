"""Schema migration system for INTENT-E2295590."""

import logging
from pathlib import Path
from typing import Any, Dict, List
from .result import ForgeResult

logger = logging.getLogger(__name__)


class Migration:
    """Base class for schema migrations."""
    
    def __init__(self, from_version: int, to_version: int, description: str):
        self.from_version = from_version
        self.to_version = to_version
        self.description = description
    
    def applies_to(self, current_version: int) -> bool:
        """Check if this migration applies to the current version."""
        return current_version == self.from_version
    
    def migrate(self, data: Dict[str, Any]) -> ForgeResult[Dict[str, Any]]:
        """Apply migration to manifest data."""
        raise NotImplementedError("Subclasses must implement migrate method")


class AddSchemaVersionMigration(Migration):
    """Migration to retroactively add schema_version field to pre-version manifests."""
    
    def __init__(self):
        super().__init__(0, 1, "Add schema_version field to legacy manifests")
    
    def applies_to(self, current_version: int) -> bool:
        """Apply to manifests without schema_version field."""
        return current_version == 0 or current_version is None
    
    def migrate(self, data: Dict[str, Any]) -> ForgeResult[Dict[str, Any]]:
        """Add schema_version field to manifest data."""
        try:
            migrated_data = data.copy()
            migrated_data["schema_version"] = 1
            
            # Add migration note to warnings if warnings field exists
            if "warnings" not in migrated_data:
                migrated_data["warnings"] = []
            
            migrated_data["warnings"].append("schema_version field added during migration")
            
            logger.info(f"Added schema_version field to manifest")
            return ForgeResult.success(migrated_data)
        
        except Exception as e:
            return ForgeResult.failure(f"Failed to add schema_version: {e}")


class MigrationManager:
    """Manages schema migrations for manifest files."""
    
    def __init__(self):
        self.migrations: List[Migration] = [
            AddSchemaVersionMigration(),
        ]
    
    def get_required_migrations(self, current_version: int) -> List[Migration]:
        """Get list of migrations needed to upgrade from current version."""
        required = []
        version = current_version
        
        while version < self.get_latest_version():
            for migration in self.migrations:
                if migration.applies_to(version):
                    required.append(migration)
                    version = migration.to_version
                    break
            else:
                # No migration found for this version
                break
        
        return required
    
    def get_latest_version(self) -> int:
        """Get the latest supported schema version."""
        return max(m.to_version for m in self.migrations)
    
    def migrate_manifest(self, data: Dict[str, Any]) -> ForgeResult[Dict[str, Any]]:
        """Apply all required migrations to manifest data."""
        current_version = data.get("schema_version", 0)
        required_migrations = self.get_required_migrations(current_version)
        
        if not required_migrations:
            return ForgeResult.success(data)
        
        migrated_data = data.copy()
        
        for migration in required_migrations:
            result = migration.migrate(migrated_data)
            if not result.ok:
                return result
            migrated_data = result.value
        
        logger.info(f"Migrated manifest from version {current_version} to {self.get_latest_version()}")
        return ForgeResult.success(migrated_data)
    
    def validate_version(self, version: int) -> ForgeResult[None]:
        """Validate that a schema version is supported."""
        latest = self.get_latest_version()
        if version > latest:
            return ForgeResult.failure(
                f"Schema version {version} is newer than supported version {latest}"
            )
        if version < 0:
            return ForgeResult.failure(f"Invalid schema version: {version}")
        return ForgeResult.success(None)


def detect_schema_version(data: Dict[str, Any]) -> int:
    """Detect schema version from manifest data."""
    if "schema_version" in data:
        return int(data["schema_version"])
    return 0  # Pre-version manifests


def needs_migration(data: Dict[str, Any]) -> bool:
    """Check if manifest data needs migration."""
    current_version = detect_schema_version(data)
    manager = MigrationManager()
    return len(manager.get_required_migrations(current_version)) > 0
