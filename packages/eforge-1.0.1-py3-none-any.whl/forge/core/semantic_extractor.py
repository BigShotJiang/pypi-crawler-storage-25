"""Improved NLP extractor with semantic filtering for INTENT-08B9AEA4.

Replaces raw word tokenization with semantic extraction: noun phrases,
domain terms, and manifest vocabulary matches.
"""

import logging
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from forge.core.path_utils import resolve_project_path

logger = logging.getLogger(__name__)


@dataclass
class ExtractedNode:
    """Represents a semantically extracted node."""
    text: str
    node_type: str  # "noun_phrase", "domain_term", "manifest_vocab", "semantic"
    confidence: float  # 0.0 to 1.0
    position: int  # Position in original text
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class SemanticExtractor(ABC):
    """Abstract base for semantic extractors."""
    
    @abstractmethod
    def extract_nodes(self, text: str) -> List[ExtractedNode]:
        """Extract semantic nodes from text."""
        pass


class ImprovedNLPExtractor(SemanticExtractor):
    """Improved NLP extractor with semantic filtering."""
    
    def __init__(self, project_path: Optional[Path] = None):
        self.project_path = project_path or resolve_project_path()
        self.manifest_vocab = self._load_manifest_vocabulary()
        self.domain_terms = self._load_domain_terms()
        
        # Stop words and generic terms to filter out
        self.stop_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'of', 'with', 'by', 'as', 'is', 'are', 'was', 'were', 'be', 'been',
            'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
            'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these',
            'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they', 'what',
            'when', 'where', 'why', 'how', 'who', 'which', 'whose', 'whom'
        }
        
        self.generic_verbs = {
            'make', 'get', 'take', 'put', 'give', 'come', 'go', 'see', 'look',
            'use', 'work', 'try', 'need', 'want', 'like', 'feel', 'seem',
            'find', 'know', 'think', 'say', 'tell', 'ask', 'mean', 'call'
        }
        
        self.generic_prepositions = {
            'in', 'on', 'at', 'by', 'for', 'with', 'without', 'through', 'during',
            'before', 'after', 'above', 'below', 'between', 'among', 'around',
            'about', 'against', 'along', 'among', 'behind', 'beneath', 'beside'
        }
    
    def _load_manifest_vocabulary(self) -> Set[str]:
        """Load vocabulary from manifest files."""
        vocab = set()
        
        try:
            manifest_file = self.project_path / ".forge" / "manifest.yaml"
            if manifest_file.exists():
                import yaml
                with open(manifest_file, 'r') as f:
                    manifest = yaml.safe_load(f) or {}
                
                # Extract node names, types, and other terms
                modules = manifest.get("modules", {})
                for module_name, module_data in modules.items():
                    vocab.add(module_name.lower())
                    
                    # Add node types
                    if "nodes" in module_data:
                        for node_name, node_data in module_data["nodes"].items():
                            vocab.add(node_name.lower())
                            if "type" in node_data:
                                vocab.add(node_data["type"].lower())
                    
                    # Add domains
                    if "domain" in module_data:
                        vocab.add(module_data["domain"].lower())
            
        except Exception as e:
            logger.warning(f"Failed to load manifest vocabulary: {e}")
        
        return vocab
    
    def _load_domain_terms(self) -> Set[str]:
        """Load domain-specific terms."""
        terms = set()
        
        # Common software development domain terms
        terms.update([
            'api', 'endpoint', 'service', 'microservice', 'monolith', 'architecture',
            'database', 'schema', 'migration', 'query', 'index', 'cache', 'queue',
            'frontend', 'backend', 'fullstack', 'ui', 'ux', 'component', 'module',
            'package', 'library', 'framework', 'dependency', 'version', 'release',
            'deployment', 'production', 'staging', 'development', 'testing',
            'unit', 'integration', 'e2e', 'ci', 'cd', 'pipeline', 'workflow',
            'repository', 'branch', 'merge', 'commit', 'push', 'pull', 'review',
            'bug', 'feature', 'enhancement', 'refactor', 'optimization',
            'security', 'authentication', 'authorization', 'encryption', 'hash',
            'token', 'session', 'cookie', 'cors', 'csrf', 'xss', 'injection',
            'docker', 'kubernetes', 'container', 'orchestration', 'scaling',
            'load', 'balancer', 'proxy', 'gateway', 'firewall', 'monitoring',
            'logging', 'metrics', 'alerting', 'observability', 'tracing'
        ])
        
        return terms
    
    def extract_nodes(self, text: str) -> List[ExtractedNode]:
        """Extract semantic nodes with filtering."""
        nodes = []
        
        # 1. Extract noun phrases
        noun_phrases = self._extract_noun_phrases(text)
        nodes.extend(noun_phrases)
        
        # 2. Extract domain terms
        domain_terms = self._extract_domain_terms(text)
        nodes.extend(domain_terms)
        
        # 3. Extract manifest vocabulary matches
        manifest_terms = self._extract_manifest_terms(text)
        nodes.extend(manifest_terms)
        
        # 4. Extract semantic terms (general high-value terms)
        semantic_terms = self._extract_semantic_terms(text)
        nodes.extend(semantic_terms)
        
        # Remove duplicates and sort by confidence
        unique_nodes = self._deduplicate_nodes(nodes)
        unique_nodes.sort(key=lambda n: n.confidence, reverse=True)
        
        return unique_nodes
    
    def _extract_noun_phrases(self, text: str) -> List[ExtractedNode]:
        """Extract noun phrases using patterns."""
        nodes = []
        
        # Simple noun phrase patterns
        patterns = [
            r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b',  # Title case phrases
            r'\b([a-z]+(?:\s+[a-z]+){1,3})\s+(?:system|service|component|module|layer|handler|manager|controller)\b',  # Technical compounds
            r'\b(?:the|a|an)\s+([a-z]+(?:\s+[a-z]+){1,2})\b',  # Noun phrases after articles
        ]
        
        for pattern in patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                phrase = match.group(1).lower()
                
                # Filter out stop words and generic terms
                if self._is_valid_term(phrase):
                    nodes.append(ExtractedNode(
                        text=phrase,
                        node_type="noun_phrase",
                        confidence=0.7,
                        position=match.start(),
                        metadata={"pattern": pattern}
                    ))
        
        return nodes
    
    def _extract_domain_terms(self, text: str) -> List[ExtractedNode]:
        """Extract domain-specific terms."""
        nodes = []
        text_lower = text.lower()
        
        for term in self.domain_terms:
            if term in text_lower:
                position = text_lower.find(term)
                nodes.append(ExtractedNode(
                    text=term,
                    node_type="domain_term",
                    confidence=0.8,
                    position=position,
                    metadata={"domain": "software_development"}
                ))
        
        return nodes
    
    def _extract_manifest_terms(self, text: str) -> List[ExtractedNode]:
        """Extract terms from manifest vocabulary."""
        nodes = []
        text_lower = text.lower()
        
        for term in self.manifest_vocab:
            if term in text_lower:
                position = text_lower.find(term)
                nodes.append(ExtractedNode(
                    text=term,
                    node_type="manifest_vocab",
                    confidence=0.9,
                    position=position,
                    metadata={"source": "manifest"}
                ))
        
        return nodes
    
    def _extract_semantic_terms(self, text: str) -> List[ExtractedNode]:
        """Extract general semantic terms."""
        nodes = []
        
        # Extract individual words that are not stop words
        words = re.findall(r'\b[a-zA-Z]{3,}\b', text)
        
        for i, word in enumerate(words):
            word_lower = word.lower()
            
            # Skip if it's a stop word or generic term
            if (word_lower in self.stop_words or 
                word_lower in self.generic_verbs or 
                word_lower in self.generic_prepositions):
                continue
            
            # Only include words that seem meaningful
            if self._is_meaningful_word(word_lower):
                position = text.find(word)
                nodes.append(ExtractedNode(
                    text=word_lower,
                    node_type="semantic",
                    confidence=0.5,
                    position=position,
                    metadata={"word_index": i}
                ))
        
        return nodes
    
    def _is_valid_term(self, term: str) -> bool:
        """Check if a term is valid (not a stop word or generic)."""
        words = term.split()
        
        # Filter out terms that are too short or contain only stop words
        if len(term) < 3 or len(words) == 0:
            return False
        
        # Check if all words are stop words
        if all(word.lower() in self.stop_words for word in words):
            return False
        
        # Check if term contains generic verbs or prepositions
        if any(word.lower() in self.generic_verbs or word.lower() in self.generic_prepositions 
               for word in words):
            return False
        
        return True
    
    def _is_meaningful_word(self, word: str) -> bool:
        """Check if a word is meaningful enough to include."""
        # Must be at least 3 characters
        if len(word) < 3:
            return False
        
        # Should contain at least one vowel (for English words)
        if not any(char in 'aeiou' for char in word):
            return False
        
        # Should not be all the same character
        if len(set(word)) == 1:
            return False
        
        return True
    
    def _deduplicate_nodes(self, nodes: List[ExtractedNode]) -> List[ExtractedNode]:
        """Remove duplicate nodes, keeping highest confidence."""
        seen = {}
        unique_nodes = []
        
        for node in nodes:
            key = (node.text.lower(), node.node_type)
            if key not in seen or node.confidence > seen[key].confidence:
                seen[key] = node
                unique_nodes.append(node)
        
        return unique_nodes


class LLMExtractor(SemanticExtractor):
    """LLM-powered semantic extractor (placeholder for future implementation)."""
    
    def __init__(self, project_path: Optional[Path] = None):
        self.project_path = project_path or resolve_project_path()
        # This would be implemented when sampling is available (INTENT-E9F8F97B)
        logger.info("LLM extractor initialized (placeholder for future implementation)")
    
    def extract_nodes(self, text: str) -> List[ExtractedNode]:
        """Extract semantic nodes using LLM (placeholder)."""
        # For now, fall back to improved NLP extractor
        extractor = ImprovedNLPExtractor(self.project_path)
        return extractor.extract_nodes(text)


def get_semantic_extractor(project_path: Optional[Path] = None, 
                          use_llm: bool = False) -> SemanticExtractor:
    """Get semantic extractor instance."""
    if use_llm:
        return LLMExtractor(project_path)
    else:
        return ImprovedNLPExtractor(project_path)


def extract_semantic_nodes(text: str, project_path: Optional[str] = None,
                          use_llm: bool = False) -> List[str]:
    """Extract semantic nodes from text, returning just the node texts."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    extractor = get_semantic_extractor(Path(project_path), use_llm)
    nodes = extractor.extract_nodes(text)
    
    return [node.text for node in nodes]


def extract_semantic_nodes_with_metadata(text: str, project_path: Optional[str] = None,
                                       use_llm: bool = False) -> List[Dict[str, Any]]:
    """Extract semantic nodes with full metadata."""
    if not project_path:
        project_path = str(resolve_project_path())
    
    extractor = get_semantic_extractor(Path(project_path), use_llm)
    nodes = extractor.extract_nodes(text)
    
    return [
        {
            "text": node.text,
            "node_type": node.node_type,
            "confidence": node.confidence,
            "position": node.position,
            "metadata": node.metadata
        }
        for node in nodes
    ]


__all__ = [
    "ExtractedNode",
    "SemanticExtractor",
    "ImprovedNLPExtractor",
    "LLMExtractor",
    "get_semantic_extractor",
    "extract_semantic_nodes",
    "extract_semantic_nodes_with_metadata"
]
