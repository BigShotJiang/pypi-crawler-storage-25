from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import yaml

from forge.core.gloves import RawEdge
from forge.core.manifest import ManifestParser
from forge.core.manifest_document import ManifestDocument, project_root_for_manifest_file
from forge.tools.manifest.graph import _slug

_PACKAGE_URI_RE = re.compile(r"^package:([^/]+)/(.+)$")
_PRIMITIVE_TYPES = frozenset(
    {
        "int",
        "double",
        "num",
        "bool",
        "string",
        "void",
        "dynamic",
        "object",
        "never",
        "future",
        "stream",
        "iterable",
        "list",
        "map",
        "set",
        "datetime",
        "duration",
        "uint8list",
    }
)


def _norm_rel_path(p: str) -> str:
    return str(p).replace("\\", "/").lstrip("./")


def _glove_dart_prefix_to_lib_rel(dotted: str) -> str | None:
    """
    ``dotted`` is the body of a DartGlove id after ``dart/`` and before any ``::``.

    Examples (DartGlove uses lib-relative paths with ``/`` replaced by ``.``):
      ``core.app_config.dart`` → ``core/app_config.dart``
      ``features.auth.auth_controller.dart`` → ``features/auth/auth_controller.dart``
    """
    if not dotted.endswith(".dart"):
        return None
    body = dotted[: -len(".dart")]
    if not body:
        return None
    parts = body.split(".")
    return "/".join(parts) + ".dart"


def _strip_generics(type_name: str) -> str:
    t = type_name.strip()
    if not t:
        return t
    if "<" in t and t.endswith(">"):
        inner = t[t.index("<") + 1 : t.rindex(">")].strip()
        if "," in inner:
            return ""
        return inner.strip()
    return t


class GloveMapper:
    """
    Maps DartGlove internal edge endpoints to manifest graph module ids
    (``module/{_slug(name)}``) so ``forge diff`` and promotion can align with
    :class:`forge.tools.manifest.graph.ManifestGraph`.
    """

    def __init__(self, manifest_path: Path, project_root: Path | None = None) -> None:
        self.manifest_path = manifest_path.expanduser().resolve()
        if project_root is not None:
            self.project_root = project_root.expanduser().resolve()
        elif self.manifest_path.parent.name == ".forge":
            self.project_root = self.manifest_path.parent.parent.resolve()
        else:
            self.project_root = self.manifest_path.parent.resolve()
        self._path_to_graph_id: dict[str, str] = {}
        self._graph_id_to_decl_id: dict[str, str] = {}
        self._class_slug_to_graph_ids: dict[str, list[str]] = {}
        self._dart_package_name: str | None = None
        self._load_package_name()
        self._build_lookup(self.manifest_path)

    def _load_package_name(self) -> None:
        pub = self.project_root / "pubspec.yaml"
        if not pub.is_file():
            return
        try:
            raw = yaml.safe_load(pub.read_text(encoding="utf-8")) or {}
        except Exception:
            return
        if isinstance(raw, dict):
            n = raw.get("name")
            if isinstance(n, str) and n.strip():
                self._dart_package_name = n.strip()

    def _build_lookup(self, manifest_path: Path) -> None:
        if not manifest_path.is_file():
            return
        raw: dict[str, Any] | None = None
        root = project_root_for_manifest_file(manifest_path)
        if root is not None:
            try:
                doc = ManifestDocument.from_path(root)
                if doc.path.resolve() == manifest_path.resolve():
                    raw = doc.to_legacy_dict()
            except (FileNotFoundError, ValueError):
                pass
        if raw is None:
            parsed = ManifestParser(manifest_path).parse()
            if not parsed.ok or not isinstance(parsed.value, dict):
                return
            raw = parsed.value
        modules = raw.get("modules") or []
        if not isinstance(modules, list):
            return
        for row in modules:
            if not isinstance(row, dict):
                continue
            name = str(row.get("name") or row.get("id") or "").strip()
            if not name:
                continue
            decl_id = str(row.get("id") or name).strip()
            mid = f"module/{_slug(name)}"
            self._graph_id_to_decl_id[mid] = decl_id
            path = row.get("path")
            if path:
                np = _norm_rel_path(str(path))
                self._path_to_graph_id.setdefault(np, mid)
            tail = decl_id.split(".")[-1]
            if tail:
                key = _slug(tail)
                self._class_slug_to_graph_ids.setdefault(key, []).append(mid)
            if path:
                stem = Path(str(path)).stem
                sk = _slug(stem)
                self._class_slug_to_graph_ids.setdefault(sk, []).append(mid)

    def decl_id_for_graph_module(self, graph_module_id: str) -> str:
        return self._graph_id_to_decl_id.get(graph_module_id, graph_module_id)

    def map_edges(
        self,
        raw_edges: list[RawEdge],
        *,
        edge_kinds: frozenset[str] | None = None,
    ) -> list[RawEdge]:
        kinds = edge_kinds or frozenset({"imports"})
        mapped: list[RawEdge] = []
        for edge in raw_edges:
            if edge.edge_kind not in kinds:
                continue
            ctx = self._importing_lib_path(edge.from_id)
            from_g = self._resolve_endpoint(edge.from_id, ctx)
            to_g = self._resolve_endpoint(edge.to_id, ctx)
            if not from_g or not to_g:
                continue
            mapped.append(
                RawEdge(
                    id=f"mapped/{edge.id}",
                    from_id=from_g,
                    to_id=to_g,
                    edge_kind=edge.edge_kind,
                    stack=edge.stack,
                    layer="declaration",
                    weight=edge.weight,
                    async_edge=edge.async_edge,
                    conditional=edge.conditional,
                    source="dartglove_mapped",
                )
            )
        return mapped

    def _importing_lib_path(self, from_id: str) -> Path | None:
        file_part = from_id.split("::", 1)[0] if "::" in from_id else from_id
        if not file_part.startswith("dart/"):
            return None
        rel = _glove_dart_prefix_to_lib_rel(file_part[5:])
        if not rel:
            return None
        return (self.project_root / "lib" / rel).resolve()

    def _resolve_endpoint(self, glove_id: str, importing_file: Path | None) -> str | None:
        if glove_id.startswith("dart_import/"):
            uri = glove_id.split("/", 1)[1]
            path = self._resolve_import_uri(uri, importing_file)
            if not path:
                return None
            return self._path_to_graph_id.get(_norm_rel_path(path))

        if glove_id.startswith("dart_type/"):
            token = glove_id.split("/", 1)[1]
            token = _strip_generics(token)
            if not token or _slug(token) in _PRIMITIVE_TYPES:
                return None
            return self._pick_unique(self._class_slug_to_graph_ids.get(_slug(token), []))

        if glove_id.startswith("dart/"):
            file_part, _, class_name = glove_id.partition("::")
            dotted = file_part[5:]
            lib_rel = _glove_dart_prefix_to_lib_rel(dotted)
            if not lib_rel:
                return None
            lib_path = _norm_rel_path(str(Path("lib") / lib_rel))
            if class_name:
                by_path = self._path_to_graph_id.get(lib_path)
                if by_path:
                    return by_path
                return self._pick_unique(self._class_slug_to_graph_ids.get(_slug(class_name), []))
            return self._path_to_graph_id.get(lib_path)

        return None

    def _pick_unique(self, ids: list[str]) -> str | None:
        if not ids:
            return None
        uniq = list(dict.fromkeys(ids))
        if len(uniq) == 1:
            return uniq[0]
        return None

    def _resolve_import_uri(self, uri: str, importing_file: Path | None) -> str | None:
        uri = uri.strip()
        if not uri:
            return None
        if uri.startswith("dart:"):
            return None
        m = _PACKAGE_URI_RE.match(uri)
        if m:
            pkg = m.group(1)
            rel = m.group(2).replace("\\", "/")
            if self._dart_package_name and pkg == self._dart_package_name:
                return _norm_rel_path(str(Path("lib") / rel))
            return None
        if importing_file is None:
            return None
        try:
            target = (importing_file.parent / uri).resolve()
            rel = target.relative_to(self.project_root)
        except Exception:
            return None
        return _norm_rel_path(str(rel))


def promote_edges(
    missing_edges: list[RawEdge],
    manifest_path: Path,
    *,
    mapper: GloveMapper | None = None,
) -> dict[str, Any]:
    """
    Append ``imports`` edges (manifest ``edges:`` list) for graph endpoints that are
    not already present. YAML uses declaration ids (e.g. ``auth.AuthController``);
    the graph loader normalises them to ``module/...`` ids.
    """
    import copy

    manifest_path = manifest_path.expanduser().resolve()
    if not manifest_path.is_file():
        raise FileNotFoundError(manifest_path)
    if mapper is None:
        root = manifest_path.parent.parent if manifest_path.parent.name == ".forge" else manifest_path.parent
        mapper = GloveMapper(manifest_path, project_root=root)

    proj_root = project_root_for_manifest_file(manifest_path)
    if proj_root is None:
        proj_root = (
            manifest_path.parent.parent
            if manifest_path.parent.name == ".forge"
            else manifest_path.parent
        )
    doc: ManifestDocument | None = None
    try:
        doc = ManifestDocument.from_path(proj_root)
    except (FileNotFoundError, ValueError):
        doc = None
    if doc is not None and doc.path.resolve() == manifest_path.resolve():
        data = copy.deepcopy(doc.to_legacy_dict())
    else:
        parsed = ManifestParser(manifest_path).parse()
        data = dict(parsed.value) if parsed.ok and isinstance(parsed.value, dict) else {}
    raw_edges = data.get("edges")
    if raw_edges is None:
        raw_edges = []
    if not isinstance(raw_edges, list):
        raw_edges = []

    existing: set[tuple[str, str, str]] = set()
    for row in raw_edges:
        if not isinstance(row, dict):
            continue
        fr = str(row.get("from") or "").strip()
        to = str(row.get("to") or "").strip()
        rel = str(row.get("edge_kind") or row.get("relation") or "").strip()
        if fr and to and rel:
            existing.add((fr, to, rel))

    added = 0
    skipped_dup = 0
    for edge in missing_edges:
        if edge.edge_kind != "imports":
            continue
        if (edge.source or "") != "dartglove_mapped":
            continue
        decl_from = mapper.decl_id_for_graph_module(edge.from_id)
        decl_to = mapper.decl_id_for_graph_module(edge.to_id)
        key = (decl_from, decl_to, "imports")
        if key in existing:
            skipped_dup += 1
            continue
        raw_edges.append(
            {
                "from": decl_from,
                "to": decl_to,
                "edge_kind": "imports",
            }
        )
        existing.add(key)
        added += 1

    data["edges"] = raw_edges
    manifest_path.write_text(
        yaml.safe_dump(data, sort_keys=False, allow_unicode=True, default_flow_style=False),
        encoding="utf-8",
    )
    return {"added": added, "skipped_duplicates": skipped_dup}
