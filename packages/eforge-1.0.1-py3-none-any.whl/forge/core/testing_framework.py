"""
Forge Component Testing Framework - Safe testing without breaking existing functionality.
Provides sandboxed testing environment for component architecture.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Type, Callable, Union
from pathlib import Path
import tempfile
import shutil
import json
from contextlib import contextmanager
from dataclasses import dataclass

from forge.core.forge_project_system import ForgeProject, create_project
# Deprecated: ECS compatibility layer archived — prefer ForgeEngine for new code.
from forge.archive.ecs.forge_compatibility_layer import (
    ForgeCompatibilityLayer,
    apply_compatibility_to_project,
)


@dataclass
class TestResult:
    """Result of a compatibility test."""
    test_name: str
    passed: bool
    message: str
    details: Dict[str, Any]
    execution_time: float
    component_entities_created: int
    legacy_functions_patched: int
    errors: List[str]


@dataclass
class TestEnvironment:
    """Isolated test environment for component testing."""
    test_dir: Path
    original_project: Optional[ForgeProject]
    test_project: Optional[ForgeProject]
    compatibility_layer: Optional[ForgeCompatibilityLayer]
    backup_state: Dict[str, Any]
    
    def __init__(self, test_dir: Path):
        self.test_dir = test_dir
        self.original_project = None
        self.test_project = None
        self.compatibility_layer = None
        self.backup_state = {}
    
    def setup_from_project(self, project: ForgeProject):
        """Setup test environment from existing project."""
        self.original_project = project
        
        # Create test project copy
        test_project_path = self.test_dir / "test_project"
        shutil.copytree(project.root_path, test_project_path)
        
        # Create test project
        self.test_project = create_project(test_project_path)
        
        # Apply compatibility layer
        self.compatibility_layer = apply_compatibility_to_project(self.test_project)
        
        # Backup original state
        self.backup_state = {
            "entities": list(project._entities.keys()),
            "systems": list(project._systems.keys()),
            "resources": {k: type(v).__name__ for k, v in project._resources.items()}
        }
    
    def cleanup(self):
        """Cleanup test environment."""
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)


class ComponentTester:
    """Safe component testing without breaking existing functionality."""
    
    def __init__(self):
        self.test_results: List[TestResult] = []
        self.current_test_env: Optional[TestEnvironment] = None
    
    @contextmanager
    def isolated_test_environment(self, project: ForgeProject = None):
        """Create isolated test environment."""
        with tempfile.TemporaryDirectory() as temp_dir:
            test_dir = Path(temp_dir)
            
            if project:
                # Test with existing project
                env = TestEnvironment(test_dir)
                env.setup_from_project(project)
                self.current_test_env = env
                try:
                    yield env
                finally:
                    env.cleanup()
                    self.current_test_env = None
            else:
                # Test with fresh project
                test_project_path = test_dir / "test_project"
                test_project_path.mkdir()
                
                # Create minimal test project
                test_project = create_project(test_project_path)
                compatibility_layer = apply_compatibility_to_project(test_project)
                
                env = TestEnvironment(test_dir)
                env.test_project = test_project
                env.compatibility_layer = compatibility_layer
                self.current_test_env = env
                try:
                    yield env
                finally:
                    env.cleanup()
                    self.current_test_env = None
    
    def run_test(self, test_name: str, test_func: Callable, **kwargs) -> TestResult:
        """Run a single test in isolated environment."""
        import time
        start_time = time.time()
        errors = []
        
        try:
            # Run test function
            result = test_func(self.current_test_env, **kwargs)
            
            # Collect metrics
            execution_time = time.time() - start_time
            component_entities = len(self.current_test_env.test_project._entities) if self.current_test_env.test_project else 0
            legacy_functions = len(self.current_test_env.compatibility_layer.patched_functions) if self.current_test_env.compatibility_layer else 0
            
            test_result = TestResult(
                test_name=test_name,
                passed=result is True,
                message="Test passed" if result is True else "Test failed",
                details={"result": result} if isinstance(result, dict) else {},
                execution_time=execution_time,
                component_entities_created=component_entities,
                legacy_functions_patched=legacy_functions,
                errors=errors
            )
            
        except Exception as e:
            execution_time = time.time() - start_time
            test_result = TestResult(
                test_name=test_name,
                passed=False,
                message=f"Test failed with exception: {str(e)}",
                details={"exception": str(e)},
                execution_time=execution_time,
                component_entities_created=0,
                legacy_functions_patched=0,
                errors=[str(e)]
            )
        
        self.test_results.append(test_result)
        return test_result
    
    def run_test_suite(self, test_suite: Dict[str, Callable]) -> List[TestResult]:
        """Run a suite of tests."""
        results = []
        for test_name, test_func in test_suite.items():
            result = self.run_test(test_name, test_func)
            results.append(result)
        return results
    
    def get_test_summary(self) -> Dict[str, Any]:
        """Get summary of all test results."""
        if not self.test_results:
            return {"total": 0, "passed": 0, "failed": 0}
        
        total = len(self.test_results)
        passed = sum(1 for r in self.test_results if r.passed)
        failed = total - passed
        
        return {
            "total": total,
            "passed": passed,
            "failed": failed,
            "pass_rate": passed / total if total > 0 else 0,
            "avg_execution_time": sum(r.execution_time for r in self.test_results) / total,
            "total_components_created": sum(r.component_entities_created for r in self.test_results),
            "total_functions_patched": sum(r.legacy_functions_patched for r in self.test_results),
            "all_errors": [e for r in self.test_results for e in r.errors]
        }


# === TEST CASES ===

def test_basic_component_creation(env: TestEnvironment) -> bool:
    """Test basic component creation and management."""
    if not env.test_project or not env.compatibility_layer:
        return False
    
    try:
        # Create entity with component
        from forge.core.forge_project_system import ForgeEntity
        from forge.core.forge_project_system import MetricsComponent
        
        entity = ForgeEntity("test_entity", "test")
        entity.add_component(MetricsComponent())
        env.test_project.add_entity(entity)
        
        # Verify entity exists and has component
        retrieved_entity = env.test_project.get_entity("test_entity")
        if not retrieved_entity:
            return False
        
        component = retrieved_entity.get_component(MetricsComponent)
        if not component:
            return False
        
        return True
    except Exception:
        return False


def test_dict_compatibility(env: TestEnvironment) -> bool:
    """Test dict-based API compatibility."""
    if not env.compatibility_layer:
        return False
    
    try:
        # Test dict-like access
        adapter = env.compatibility_layer.graph_adapter
        
        # Add node using dict format
        node_dict = {
            "id": "test/controller",
            "kind": "controller",
            "name": "TestController",
            "path": "test.py",
            "domain": "test",
            "meta": {"tier": "surface"}
        }
        node_id = adapter.add_node(node_dict)
        
        # Retrieve node using dict format
        nodes = adapter.get_nodes(kind="controller")
        if not nodes:
            return False
        
        # Verify node was added
        found_node = next((n for n in nodes if n.get("id") == node_id), None)
        if not found_node:
            return False
        
        return True
    except Exception:
        return False


def test_mcp_handler_compatibility(env: TestEnvironment) -> bool:
    """Test MCP handler compatibility with components."""
    if not env.compatibility_layer:
        return False
    
    try:
        # Simulate MCP handler call
        from forge.core.forge_project_system import MetricsComponent, HealthComponent
        
        # Check if health monitor entity was created
        health_entity = env.test_project.get_entity("health_monitor")
        if not health_entity:
            return False
        
        # Check if metrics component exists
        metrics_comp = health_entity.get_component(MetricsComponent)
        if not metrics_comp:
            return False
        
        # Test component functionality
        metrics_comp.record_metric("test_metric", 42)
        if metrics_comp.get_metric("test_metric") != 42:
            return False
        
        return True
    except Exception:
        return False


def test_protocol_integration(env: TestEnvironment) -> bool:
    """Test protocol integration with components."""
    if not env.compatibility_layer:
        return False
    
    try:
        # Test glove protocol integration
        from forge.core.forge_project_system import GloveComponent
        
        # Create glove entity
        glove_entity = ForgeEntity("test_glove", "glove")
        glove_entity.add_component(GloveComponent(
            stack="python",
            auto_discover=True
        ))
        env.test_project.add_entity(glove_entity)
        
        # Verify glove component
        glove_comp = glove_entity.get_component(GloveComponent)
        if not glove_comp:
            return False
        
        return True
    except Exception:
        return False


def test_graph_synchronization(env: TestEnvironment) -> bool:
    """Test graph synchronization between dict and component systems."""
    if not env.compatibility_layer:
        return False
    
    try:
        adapter = env.compatibility_layer.graph_adapter
        
        # Add node via component system
        from forge.core.forge_project_system import ForgeEntity
        from forge.core.forge_project_system import NodeComponent
        
        entity = ForgeEntity("sync_test", "test")
        entity.add_component(NodeComponent(
            node_id="sync_test",
            node_kind="controller",
            tier="surface"
        ))
        env.test_project.add_entity(entity)
        
        # Check if node appears in graph
        graph_dict = adapter.get_graph_as_dict()
        nodes = graph_dict.get("nodes", [])
        
        found_node = next((n for n in nodes if n.get("id") == "sync_test"), None)
        if not found_node:
            return False
        
        return True
    except Exception:
        return False


def test_event_system_integration(env: TestEnvironment) -> bool:
    """Test event system integration with components."""
    if not env.compatibility_layer:
        return False
    
    try:
        from forge.core.forge_project_system import EventComponent
        
        # Create event entity
        event_entity = ForgeEntity("event_test", "test")
        event_entity.add_component(EventComponent(
            processing_enabled=True
        ))
        env.test_project.add_entity(event_entity)
        
        # Test event emission
        event_comp = event_entity.get_component(EventComponent)
        if not event_comp:
            return False
        
        # Register handler and emit event
        event_received = []
        
        def test_handler(event):
            event_received.append(event)
        
        event_comp.register_handler("test_event", test_handler)
        event_comp.emit_event("test_event", {"data": "test"})
        event_comp.process_events()
        
        if not event_received:
            return False
        
        return True
    except Exception:
        return False


# === MAIN TESTING INTERFACE ===

def run_component_tests(project: Optional[ForgeProject] = None) -> Dict[str, Any]:
    """Run comprehensive component tests."""
    tester = ComponentTester()
    
    # Define test suite
    test_suite = {
        "basic_component_creation": test_basic_component_creation,
        "dict_compatibility": test_dict_compatibility,
        "mcp_handler_compatibility": test_mcp_handler_compatibility,
        "protocol_integration": test_protocol_integration,
        "graph_synchronization": test_graph_synchronization,
        "event_system_integration": test_event_system_integration
    }
    
    # Run tests
    with tester.isolated_test_environment(project) as env:
        results = tester.run_test_suite(test_suite)
    
    return tester.get_test_summary()


def run_quick_compatibility_check(project_path: str) -> Dict[str, Any]:
    """Quick compatibility check for a project."""
    try:
        from forge.core.forge_project_system import create_project
        
        # Create test project
        project = create_project(Path(project_path))
        
        # Apply compatibility layer
        layer = apply_compatibility_to_project(project)
        
        # Run basic checks
        tester = ComponentTester()
        
        with tester.isolated_test_environment(project) as env:
            # Quick tests
            basic_result = tester.run_test("basic_setup", test_basic_component_creation)
            dict_result = tester.run_test("dict_api", test_dict_compatibility)
            
            summary = tester.get_test_summary()
            
            return {
                "project_path": project_path,
                "compatibility_applied": True,
                "test_results": summary,
                "recommendation": "Ready for component adoption" if summary["pass_rate"] >= 0.8 else "Needs investigation"
            }
    
    except Exception as e:
        return {
            "project_path": project_path,
            "compatibility_applied": False,
            "error": str(e),
            "recommendation": "Failed to apply compatibility layer"
        }


# === MIGRATION TESTING ===

def test_migration_readiness(project: ForgeProject) -> Dict[str, Any]:
    """Test if project is ready for component migration."""
    tester = ComponentTester()
    
    def test_existing_functionality(env: TestEnvironment) -> bool:
        """Test that existing functionality still works."""
        try:
            # Test existing graph operations
            adapter = env.compatibility_layer.graph_adapter
            nodes = adapter.get_nodes()
            edges = adapter.get_edges()
            
            # Test basic operations
            if len(nodes) < 0 or len(edges) < 0:
                return False
            
            return True
        except Exception:
            return False
    
    def test_component_functionality(env: TestEnvironment) -> bool:
        """Test that new component functionality works."""
        try:
            from forge.core.forge_project_system import HealthComponent
            
            # Create entity with health component
            entity = ForgeEntity("health_test", "test")
            entity.add_component(HealthComponent())
            env.test_project.add_entity(entity)
            
            # Test component
            health = entity.get_component(HealthComponent)
            if not health:
                return False
            
            return True
        except Exception:
            return False
    
    def test_interoperability(env: TestEnvironment) -> bool:
        """Test interoperability between systems."""
        try:
            # Add node via dict API
            adapter = env.compatibility_layer.graph_adapter
            node_id = adapter.add_node({
                "id": "interop_test",
                "kind": "controller",
                "meta": {"tier": "surface"}
            })
            
            # Access via component API
            entity = env.test_project.get_entity("interop_test")
            if not entity:
                return False
            
            return True
        except Exception:
            return False
    
    with tester.isolated_test_environment(project) as env:
        # Run migration tests
        existing_result = tester.run_test("existing_functionality", test_existing_functionality)
        component_result = tester.run_test("component_functionality", test_component_functionality)
        interop_result = tester.run_test("interoperability", test_interoperability)
        
        summary = tester.get_test_summary()
        
        # Calculate migration readiness
        readiness_score = 0
        if existing_result.passed:
            readiness_score += 40
        if component_result.passed:
            readiness_score += 40
        if interop_result.passed:
            readiness_score += 20
        
        return {
            "project_id": project.id,
            "migration_readiness": readiness_score,
            "readiness_level": (
                "Ready" if readiness_score >= 80 else
                "Mostly Ready" if readiness_score >= 60 else
                "Partially Ready" if readiness_score >= 40 else
                "Not Ready"
            ),
            "test_results": summary,
            "recommendations": _get_migration_recommendations(readiness_score)
        }


def _get_migration_recommendations(score: int) -> List[str]:
    """Get migration recommendations based on readiness score."""
    recommendations = []
    
    if score >= 80:
        recommendations.append("✅ Ready for full component migration")
        recommendations.append("🚀 Can adopt component architecture immediately")
    elif score >= 60:
        recommendations.append("⚠️ Mostly ready - some investigation needed")
        recommendations.append("🔧 Fix failing tests before migration")
    elif score >= 40:
        recommendations.append("❌ Partially ready - significant issues found")
        recommendations.append("🛠️ Address compatibility issues before proceeding")
    else:
        recommendations.append("🚫 Not ready - major compatibility issues")
        recommendations.append("🔄 Requires substantial fixes before migration")
    
    return recommendations


# === USAGE EXAMPLES ===

def example_testing():
    """Example of using testing framework."""
    from forge.core.forge_project_system import create_project
    
    # Test with existing project
    project = create_project(Path("/Users/sebastianpereira/Projects/forge"))
    
    # Run comprehensive tests
    results = run_component_tests(project)
    print(f"Test Results: {results}")
    
    # Check migration readiness
    migration_results = test_migration_readiness(project)
    print(f"Migration Readiness: {migration_results}")
    
    # Quick compatibility check
    quick_check = run_quick_compatibility_check(str(project.root_path))
    print(f"Quick Check: {quick_check}")
    
    return results, migration_results, quick_check
