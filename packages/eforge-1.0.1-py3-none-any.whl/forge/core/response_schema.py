from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


def _schema_path(project_root: Path) -> Path:
    return project_root / ".forge" / "schema.yaml"


def load_response_schema(project_root: Path) -> dict[str, Any]:
    path = _schema_path(project_root)
    if not path.is_file():
        return {}
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def tier_fields(project_root: Path, output_type: str, tier: str) -> list[str]:
    schema = load_response_schema(project_root)
    outputs = schema.get("output_types")
    if not isinstance(outputs, dict):
        return []
    block = outputs.get(output_type)
    if not isinstance(block, dict):
        return []
    tiers = block.get("tiers")
    if not isinstance(tiers, dict):
        return []
    row = tiers.get(tier)
    if not isinstance(row, list):
        return []
    return [str(x) for x in row if isinstance(x, (str, int, float))]


def project_root_from_path(project_path: Path) -> Path:
    root = project_path.expanduser().resolve()
    if (root / ".forge").is_dir():
        return root
    if root.name == ".forge":
        return root.parent
    return root
