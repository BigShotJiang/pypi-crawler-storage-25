from __future__ import annotations

import re
import time
import ast
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Protocol

from forge.tools.scan.parsers.python_app import parse_python

from forge.core.contracts import ContractParam, RawContract
from forge.core.execution_graph import ExecutionGraph, TraceHandle

if TYPE_CHECKING:
    from forge.core.manifest_document import ManifestDocument


@dataclass
class RawNode:
    id: str
    kind: str
    stack: str
    domain: str
    name: str
    file: str | None
    line: int | None = None
    description: str | None = None
    status: dict[str, bool | None] = field(default_factory=dict)


@dataclass
class RawEdge:
    id: str
    from_id: str
    to_id: str
    edge_kind: str
    stack: str
    layer: str = "declaration"
    weight: int = 0
    async_edge: bool = False
    conditional: bool = False
    source: str | None = None


class StackGlove(Protocol):
    def extract_nodes(self, project_path: Path) -> list[RawNode]:
        ...

    def extract_edges(self, project_path: Path) -> list[RawEdge]:
        ...

    def extract_contracts(self, node: RawNode) -> list[RawContract]:
        ...

    def attach_trace_hook(
        self,
        entry_node: str | RawNode,
        *,
        project_path: Path | None = None,
        scope_module: str | None = None,
    ) -> TraceHandle:
        ...


class PythonGlove:
    """Wrapper over existing Python scan parser output."""

    def extract_nodes(self, project_path: Path) -> list[RawNode]:
        parsed = parse_python(project_path)
        nodes: list[RawNode] = []
        for f in parsed.files:
            node_id = f"file/{f.path.replace('/', '.')}"
            nodes.append(
                RawNode(
                    id=node_id,
                    kind=f.kind,
                    stack="python",
                    domain=f.domain,
                    name=Path(f.path).stem,
                    file=f.path,
                    status={
                        "declared": True,
                        "implemented": bool(f.path),
                        "reachable": None,
                        "intended": None,
                    },
                )
            )
        return nodes

    def extract_edges(self, project_path: Path) -> list[RawEdge]:
        parsed = parse_python(project_path)
        edges: list[RawEdge] = []
        for idx, dep in enumerate(parsed.dependencies):
            src = f"file/{dep.source.replace('/', '.')}"
            dst = f"file/{dep.target.replace('/', '.')}"
            edges.append(
                RawEdge(
                    id=f"edge/python/{idx}",
                    from_id=src,
                    to_id=dst,
                    edge_kind="imports",
                    stack="python",
                    source="python_glove",
                )
            )
        return edges

    def extract_contracts(self, node: RawNode) -> list[RawContract]:
        if not node.file:
            return []
        p = Path(node.file)
        if not p.exists() or p.suffix != ".py":
            return []
        try:
            src = p.read_text(encoding="utf-8", errors="ignore")
            tree = ast.parse(src, filename=str(p))
        except Exception:
            return []

        out: list[RawContract] = []

        def _ann(x: ast.expr | None) -> str | None:
            if x is None:
                return None
            try:
                return ast.unparse(x)
            except Exception:
                return None

        def _params(fn: ast.FunctionDef | ast.AsyncFunctionDef) -> list[ContractParam]:
            params: list[ContractParam] = []
            pos = list(fn.args.posonlyargs) + list(fn.args.args)
            defaults = list(fn.args.defaults)
            start = max(0, len(pos) - len(defaults))
            default_map: dict[str, ast.expr] = {}
            for i, d in enumerate(defaults):
                default_map[pos[start + i].arg] = d
            for a in pos:
                if a.arg in ("self", "cls"):
                    continue
                dv = default_map.get(a.arg)
                params.append(
                    ContractParam(
                        name=a.arg,
                        type=_ann(a.annotation),
                        required=dv is None,
                        default=(ast.unparse(dv) if dv is not None else None),
                    )
                )
            for a, d in zip(fn.args.kwonlyargs, fn.args.kw_defaults):
                params.append(
                    ContractParam(
                        name=a.arg,
                        type=_ann(a.annotation),
                        required=d is None,
                        default=(ast.unparse(d) if d is not None else None),
                    )
                )
            if fn.args.vararg:
                params.append(ContractParam(name="*" + fn.args.vararg.arg, type=_ann(fn.args.vararg.annotation), required=False, default=None))
            if fn.args.kwarg:
                params.append(ContractParam(name="**" + fn.args.kwarg.arg, type=_ann(fn.args.kwarg.annotation), required=False, default=None))
            return params

        for n in ast.walk(tree):
            if not isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            raises: list[str] = []
            for sub in ast.walk(n):
                if isinstance(sub, ast.Raise) and sub.exc is not None:
                    try:
                        raises.append(ast.unparse(sub.exc))
                    except Exception:
                        raises.append("unknown")
            decos = []
            for d in n.decorator_list:
                try:
                    decos.append(ast.unparse(d))
                except Exception:
                    pass
            out.append(
                RawContract(
                    node_id=node.id,
                    method=n.name,
                    params=_params(n),
                    returns=_ann(n.returns),
                    raises=sorted(set(raises)),
                    async_boundary=isinstance(n, ast.AsyncFunctionDef),
                    direction="out",
                    type_declared=_ann(n.returns),
                    payload={"decorators": decos},
                )
            )
        return out

    def attach_trace_hook(
        self,
        entry_node: str | RawNode,
        *,
        project_path: Path | None = None,
        scope_module: str | None = None,
    ) -> TraceHandle:
        if project_path is None:
            raise ValueError("PythonGlove.attach_trace_hook requires project_path")
        entry_id = entry_node.id if isinstance(entry_node, RawNode) else str(entry_node)
        graph = ExecutionGraph(entry_point=entry_id, trace_start=time.time())
        return TraceHandle(graph, project_path, scope_module=scope_module)


class DartGlove:
    # abstract class / mixin declarations; exclude enum class keyword false positives via ^ anchor
    _CLASS_RE = re.compile(
        r"(?m)^(?:@\w+(?:\([^)]*\))?\s+)*(?:abstract\s+)?(?:class|mixin)\s+([A-Za-z_]\w*)",
    )
    _IMPORT_RE = re.compile(r"^\s*import\s+['\"]([^'\"]+)['\"]", re.MULTILINE)
    _FINAL_FIELD_RE = re.compile(r"\bfinal\s+([A-Za-z_]\w*)\s+([A-Za-z_]\w*)\s*;")
    _METHOD_RE = re.compile(
        r"^\s*(?!_)([A-Za-z_][\w<>\?,\s]*)\s+([A-Za-z_]\w*)\s*\(([^)]*)\)\s*\{?",
        re.MULTILINE,
    )
    _KIND_BY_SUFFIX = {
        "controller": "controller",
        "service": "service",
        "screen": "screen",
        "widget": "component",
        "model": "model",
    }

    @staticmethod
    def _project_root_for_manifest(project_path: Path) -> Path:
        base = project_path.expanduser().resolve()
        return base.parent if base.name == "lib" else base

    @staticmethod
    def _load_project_manifest_domains(manifest: "ManifestDocument | None") -> frozenset[str]:
        """Uppercase domain codes from project manifest (Format A/B top-level ``domains``)."""
        if manifest is None:
            return frozenset()
        doms = manifest.raw.get("domains")
        if isinstance(doms, list):
            return frozenset(str(d).strip().upper() for d in doms if str(d).strip())
        return frozenset()

    @staticmethod
    def _infer_domain(file_path: str, known_domains: frozenset[str]) -> str:
        """
        Map a Dart file path to a declaration domain for diff/domain filters.

        Convention: ``lib/features/<folder>/...`` uses ``<folder>`` when it matches
        a manifest domain; data/remote → REMOTE; data/models, lib/core, lib/ui → CORE.
        """
        posix = Path(file_path).as_posix()
        parts = Path(file_path).parts
        if "features" in parts:
            idx = parts.index("features")
            if idx + 1 < len(parts):
                candidate = parts[idx + 1].upper()
                if candidate in known_domains:
                    return candidate
        if "/lib/data/remote/" in posix:
            return "REMOTE"
        if "/lib/core/premium/" in posix:
            return "PREMIUM"
        if "/lib/data/models/" in posix:
            return "CORE"
        if "/lib/core/" in posix:
            return "CORE"
        if "/lib/ui/" in posix:
            return "CORE"
        return "CORE"

    @staticmethod
    def _load_manifest_module_path_domains(manifest: "ManifestDocument | None") -> dict[str, str]:
        """Map ``lib/...`` module paths from manifest to declared domain (uppercase)."""
        out: dict[str, str] = {}
        if manifest is None:
            return out
        for mod in manifest.raw.get("modules") or []:
            if not isinstance(mod, dict):
                continue
            path = mod.get("path")
            dom = mod.get("domain")
            if path and dom:
                key = str(path).replace("\\", "/").lstrip("./")
                dom_u = str(dom).strip().upper()
                # First declaration wins — later duplicate paths (e.g. promoted
                # per-class rows) must not overwrite the canonical domain.
                out.setdefault(key, dom_u)
        return out

    @staticmethod
    def _domain_from_manifest_paths(lib_rel: str, path_domains: dict[str, str]) -> str | None:
        """Resolve domain using manifest ``path`` keys (``lib/...``). ``lib_rel`` is under ``lib/``."""
        norm = lib_rel.replace("\\", "/").lstrip("/")
        full = f"lib/{norm}" if not norm.startswith("lib/") else norm
        if full in path_domains:
            return path_domains[full]
        best: str | None = None
        best_len = -1
        for decl_path, dom in path_domains.items():
            if full == decl_path or full.startswith(f"{decl_path}/"):
                if len(decl_path) > best_len:
                    best_len = len(decl_path)
                    best = dom
        return best

    def _collect_dart_files(self, project_path: Path) -> list[Path]:
        base = project_path.expanduser().resolve()
        if base.is_file() and base.suffix == ".dart":
            return [base]
        if base.is_dir() and base.name == "lib":
            roots = [base]
        elif (base / "lib").is_dir():
            roots = [base / "lib"]
        else:
            roots = [base]
        files: list[Path] = []
        for root in roots:
            files.extend(sorted(p for p in root.rglob("*.dart") if p.is_file()))
        return files

    def _relative_path(self, file_path: Path, base: Path) -> str:
        try:
            return str(file_path.relative_to(base)).replace("\\", "/")
        except Exception:
            return str(file_path).replace("\\", "/")

    def _infer_kind(self, class_name: str) -> str:
        lower = class_name.lower()
        for suffix, kind in self._KIND_BY_SUFFIX.items():
            if lower.endswith(suffix):
                return kind
        return "module"

    def _node_id(self, rel_path: str, class_name: str) -> str:
        return f"dart/{rel_path.replace('/', '.')}::{class_name}"

    def _extract_class_spans(self, text: str) -> list[tuple[str, int, int]]:
        spans: list[tuple[str, int, int]] = []
        matches = list(self._CLASS_RE.finditer(text))
        for idx, m in enumerate(matches):
            start = m.start()
            end = matches[idx + 1].start() if idx + 1 < len(matches) else len(text)
            spans.append((m.group(1), start, end))
        return spans

    def extract_nodes(self, project_path: Path) -> list[RawNode]:
        base = project_path.expanduser().resolve()
        project_root = self._project_root_for_manifest(base)
        from forge.core.manifest_document import ManifestDocument

        manifest_doc: ManifestDocument | None = None
        try:
            manifest_doc = ManifestDocument.from_path(project_root)
        except (FileNotFoundError, ValueError):
            manifest_doc = None
        known_domains = self._load_project_manifest_domains(manifest_doc)
        path_domains = self._load_manifest_module_path_domains(manifest_doc)
        manifest_paths = frozenset(path_domains.keys()) if path_domains else frozenset()
        nodes: list[RawNode] = []
        for p in self._collect_dart_files(base):
            text = p.read_text(encoding="utf-8", errors="ignore")
            rel = self._relative_path(p, base if base.name == "lib" else base / "lib")
            lib_key = f"lib/{rel}" if not str(rel).startswith("lib/") else str(rel).replace("\\", "/")
            if manifest_paths:
                if not any(
                    lib_key == mp or lib_key.startswith(f"{mp.rstrip('/')}/")
                    for mp in manifest_paths
                ):
                    continue
            domain = self._domain_from_manifest_paths(rel, path_domains) or self._infer_domain(
                str(p), known_domains
            )
            for class_name, start, _end in self._extract_class_spans(text):
                line_no = text.count("\n", 0, start) + 1
                nodes.append(
                    RawNode(
                        id=self._node_id(rel, class_name),
                        kind=self._infer_kind(class_name),
                        stack="dart",
                        domain=domain,
                        name=class_name,
                        file=str(p),
                        line=line_no,
                        status={
                            "declared": True,
                            "implemented": True,
                            "reachable": None,
                            "intended": None,
                        },
                    )
                )
        return nodes

    def extract_edges(self, project_path: Path) -> list[RawEdge]:
        base = project_path.expanduser().resolve()
        edges: list[RawEdge] = []
        edge_idx = 0
        lib_base = base if base.name == "lib" else base / "lib"
        for p in self._collect_dart_files(base):
            text = p.read_text(encoding="utf-8", errors="ignore")
            rel = self._relative_path(p, lib_base)
            norm = rel.replace("\\", "/")
            dotted = norm.replace("/", ".") if norm.endswith(".dart") else f"{norm.replace('/', '.')}.dart"
            file_from = f"dart/{dotted}"
            for m in self._IMPORT_RE.finditer(text):
                target = m.group(1)
                edges.append(
                    RawEdge(
                        id=f"edge/dart/import/{edge_idx}",
                        from_id=file_from,
                        to_id=f"dart_import/{target}",
                        edge_kind="imports",
                        stack="dart",
                        layer="declaration",
                        source="dart_glove",
                    )
                )
                edge_idx += 1

            for class_name, start, end in self._extract_class_spans(text):
                class_block = text[start:end]
                this_refs = set(re.findall(r"\bthis\.([A-Za-z_]\w*)", class_block))
                for dep_type, dep_name in self._FINAL_FIELD_RE.findall(class_block):
                    if dep_name not in this_refs:
                        continue
                    edges.append(
                        RawEdge(
                            id=f"edge/dart/compose/{edge_idx}",
                            from_id=self._node_id(rel, class_name),
                            to_id=f"dart_type/{dep_type}",
                            edge_kind="composes",
                            stack="dart",
                            layer="declaration",
                            source="dart_glove",
                        )
                    )
                    edge_idx += 1
        return edges

    def extract_contracts(self, node: RawNode) -> list[RawContract]:
        if not node.file:
            return []
        file_path = Path(node.file)
        if not file_path.exists():
            return []
        text = file_path.read_text(encoding="utf-8", errors="ignore")
        contracts: list[RawContract] = []
        for return_type, method_name, params in self._METHOD_RE.findall(text):
            allow_private = bool((node.status or {}).get("declared_private_contracts"))
            if method_name == node.name or (method_name.startswith("_") and not allow_private):
                continue
            parsed_params: list[ContractParam] = []
            raw_params = [p.strip() for p in params.split(",") if p.strip()]
            for rp in raw_params:
                name = rp
                typ: str | None = None
                default: str | None = None
                required = True
                if ":" in rp:
                    left, right = rp.split(":", 1)
                    name = left.strip()
                    typ = right.strip()
                if "=" in name:
                    name, default = [x.strip() for x in name.split("=", 1)]
                    required = False
                if "=" in (typ or ""):
                    tleft, dright = [x.strip() for x in (typ or "").split("=", 1)]
                    typ = tleft
                    default = dright
                    required = False
                if rp.startswith("{") or rp.startswith("["):
                    required = False
                parsed_params.append(ContractParam(name=name.strip("{}[] "), type=typ, required=required, default=default))
            async_boundary = "Future<" in return_type or "Future " in return_type or " async" in text
            throws = [m.group(1).strip() for m in re.finditer(r"//\s*@throws\s+([A-Za-z_][\w\.]*)", text)]
            contracts.append(
                RawContract(
                    node_id=node.id,
                    method=method_name,
                    params=parsed_params,
                    returns=return_type.strip() or None,
                    raises=throws,
                    async_boundary=async_boundary,
                    direction="out",
                    type_declared=return_type.strip() or None,
                    payload={"params": params.strip()},
                )
            )
        return contracts

    def attach_trace_hook(
        self,
        entry_node: str | RawNode,
        *,
        project_path: Path | None = None,
        scope_module: str | None = None,
    ) -> TraceHandle:
        raise NotImplementedError("deferred: Phase 4")


class ReactGlove:
    _SKIP_DIRS = frozenset({
        "node_modules", ".git", "dist",
        ".astro", ".next", ".nuxt",
        "build", "out", "coverage",
        "__pycache__", ".vercel", "supabase",
        "scripts",
    })
    _WEB_EXTENSIONS = frozenset({
        ".tsx", ".ts", ".astro",
        ".jsx", ".js",
    })
    _SKIP_PATTERNS = (
        ".d.ts", ".config.ts", ".config.js",
        ".test.ts", ".test.tsx", ".spec.ts",
        ".spec.tsx",
    )
    _IMPORT_RE = re.compile(
        r"""(?:import|export)\s+
            (?:[\w\s{},*]+\s+from\s+)?
            ['"]([^'"]+)['"]""",
        re.VERBOSE,
    )
    _REQUIRE_RE = re.compile(
        r"""require\s*\(\s*['"]([^'"]+)['"]\s*\)""",
    )

    def extract_nodes(self, project_path: Path) -> list[RawNode]:
        """Walk web/Astro project and return RawNode for each source file."""
        nodes: list[RawNode] = []
        root = Path(project_path).expanduser().resolve()

        for file_path in root.rglob("*"):
            if not file_path.is_file():
                continue
            if any(part in self._SKIP_DIRS for part in file_path.parts):
                continue
            if file_path.suffix not in self._WEB_EXTENSIONS:
                continue
            name = file_path.name
            if any(name.endswith(p) for p in self._SKIP_PATTERNS):
                continue
            rel = file_path.relative_to(root)
            rel_str = str(rel).replace("\\", "/")
            if rel_str.startswith("public/"):
                continue

            kind = self._infer_kind(rel)
            domain = self._infer_domain(rel)

            stem = rel.with_suffix("").as_posix()
            dot_path = stem.replace("/", ".")
            for prefix in ("src.", "app."):
                if dot_path.startswith(prefix):
                    dot_path = dot_path[len(prefix):]
                    break
            node_id = f"{kind}/{dot_path}"

            nodes.append(
                RawNode(
                    id=node_id,
                    kind=kind,
                    stack="web",
                    domain=domain,
                    name=file_path.stem,
                    file=rel_str,
                    status={
                        "declared": False,
                        "implemented": True,
                        "reachable": None,
                        "intended": None,
                    },
                )
            )

        return nodes

    def _infer_kind(self, rel: Path) -> str:
        """Infer node kind from file path."""
        parts = rel.parts
        name = rel.stem.lower()
        suffix = rel.suffix

        if "pages" in parts:
            if "api" in parts:
                return "route"
            return "page"

        if "layouts" in parts:
            return "layout"

        if "lib" in parts or "utils" in parts:
            return "service"

        if name == "middleware":
            return "service"

        if name == "types" or name.endswith(".types"):
            return "schema"

        if suffix == ".astro":
            return "component"

        if suffix in (".tsx", ".jsx") and rel.stem and rel.stem[0].isupper():
            return "component"

        return "module"

    def _infer_domain(self, rel: Path) -> str:
        """Infer domain from directory structure."""
        parts = [p.upper() for p in rel.parts]

        if "COMPONENTS" in parts:
            idx = parts.index("COMPONENTS")
            if idx + 1 < len(parts):
                sub = parts[idx + 1]
                if sub in ("FORGE", "FORGE-BROWSER"):
                    return "FORGE-BROWSER"
                if sub == "GRAPH":
                    return "GRAPH"
                if sub == "UI":
                    return "UI"
            return "UI"

        if "LAYOUTS" in parts:
            return "LAYOUTS"
        if "PAGES" in parts:
            if "API" in parts:
                return "ROUTING"
            if "ADMIN" in parts:
                return "ADMIN"
            return "ROUTING"
        if "LIB" in parts:
            if "AUTH" in parts:
                return "AUTH"
            if "ADMIN" in parts:
                return "ADMIN"
            return "LIB"
        if "MIDDLEWARE" in parts:
            return "ROUTING"

        return "CORE"

    def extract_edges(self, project_path: Path) -> list[RawEdge]:
        """Extract import edges from web source files."""
        nodes = self.extract_nodes(project_path)
        path_to_id: dict[str, str] = {n.file: n.id for n in nodes if n.file}

        root = Path(project_path).expanduser().resolve()
        edges: list[RawEdge] = []
        edge_idx = 0

        for node in nodes:
            if not node.file:
                continue
            file_path = root / node.file
            try:
                src = file_path.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            imports: list[str] = []
            imports.extend(self._IMPORT_RE.findall(src))
            imports.extend(self._REQUIRE_RE.findall(src))

            for imp in imports:
                if (
                    not imp.startswith(".")
                    and not imp.startswith("@/")
                    and not imp.startswith("~/")
                    and not imp.startswith("src/")
                ):
                    continue

                resolved = self._resolve_import(imp, file_path, root, path_to_id)
                if resolved:
                    edges.append(
                        RawEdge(
                            id=f"edge/web/{edge_idx}",
                            from_id=node.id,
                            to_id=resolved,
                            edge_kind="imports",
                            stack="web",
                            source="react_glove",
                        )
                    )
                    edge_idx += 1

        return edges

    def _resolve_import(
        self,
        imp: str,
        from_file: Path,
        root: Path,
        path_to_id: dict[str, str],
    ) -> str | None:
        """Resolve import string to a node_id."""
        if imp.startswith("@/") or imp.startswith("~/"):
            imp = "src/" + imp[2:]

        if imp.startswith("."):
            base = from_file.parent / imp
        else:
            base = root / imp

        for ext in (".tsx", ".ts", ".astro", ".jsx", ".js"):
            candidate = base.with_suffix(ext).resolve()
            try:
                rel = str(candidate.relative_to(root.resolve())).replace("\\", "/")
                if rel in path_to_id:
                    return path_to_id[rel]
            except ValueError:
                pass

        for ext in (".tsx", ".ts", ".astro", ".jsx", ".js"):
            candidate = (base / f"index{ext}").resolve()
            try:
                rel = str(candidate.relative_to(root.resolve())).replace("\\", "/")
                if rel in path_to_id:
                    return path_to_id[rel]
            except ValueError:
                pass

        return None

    def extract_contracts(self, node: RawNode) -> list[RawContract]:
        raise NotImplementedError("deferred: Phase 2 full impl")

    def attach_trace_hook(
        self,
        entry_node: str | RawNode,
        *,
        project_path: Path | None = None,
        scope_module: str | None = None,
    ) -> TraceHandle:
        raise NotImplementedError("deferred: Phase 2 full impl")


class SQLGlove:
    def extract_nodes(self, project_path: Path) -> list[RawNode]:
        base = project_path.expanduser().resolve()
        out: list[RawNode] = []
        for p in sorted(base.rglob("*.sql")):
            rel = str(p.relative_to(base)).replace("\\", "/")
            out.append(
                RawNode(
                    id=f"sql/{rel.replace('/', '.')}",
                    kind="module",
                    stack="sql",
                    domain="DATA",
                    name=p.stem,
                    file=str(p),
                    line=1,
                    status={"declared": True, "implemented": True, "reachable": None, "intended": None},
                )
            )
        return out

    def extract_edges(self, project_path: Path) -> list[RawEdge]:
        _ = project_path
        return []

    def extract_contracts(self, node: RawNode) -> list[RawContract]:
        if not node.file:
            return []
        p = Path(node.file)
        if not p.is_file() or p.suffix.lower() != ".sql":
            return []
        text = p.read_text(encoding="utf-8", errors="ignore")
        out: list[RawContract] = []
        for m in re.finditer(r"create\s+table\s+([a-zA-Z_][\w]*)\s*\((.*?)\);", text, flags=re.IGNORECASE | re.DOTALL):
            table = m.group(1)
            cols_raw = m.group(2)
            params: list[ContractParam] = []
            col_types: dict[str, str] = {}
            for raw_line in cols_raw.split(","):
                part = raw_line.strip()
                if not part:
                    continue
                chunks = [c for c in re.split(r"\s+", part) if c]
                if len(chunks) < 2:
                    continue
                col = chunks[0].strip('"')
                typ = chunks[1].upper()
                params.append(ContractParam(name=col, type=typ, required=False, default=None))
                col_types[col] = typ
            out.append(
                RawContract(
                    node_id=node.id,
                    method=f"table:{table}",
                    contract_type="sql-table",
                    params=params,
                    returns="row",
                    boundary_kind="sync",
                    type_annotations={"table": table, "columns": col_types},
                )
            )
        for m in re.finditer(r"select\s+(.*?)\s+from\s+([a-zA-Z_][\w]*)", text, flags=re.IGNORECASE | re.DOTALL):
            cols = [c.strip() for c in m.group(1).split(",") if c.strip()]
            table = m.group(2)
            col_types = {c: "unknown" for c in cols}
            out.append(
                RawContract(
                    node_id=node.id,
                    method=f"select:{table}",
                    contract_type="sql-query",
                    params=[ContractParam(name=c, type="unknown", required=False, default=None) for c in cols],
                    returns="rows",
                    boundary_kind="sync",
                    type_annotations={"table": table, "columns": col_types},
                )
            )
        return out

    def attach_trace_hook(
        self,
        entry_node: str | RawNode,
        *,
        project_path: Path | None = None,
        scope_module: str | None = None,
    ) -> TraceHandle:
        raise NotImplementedError("deferred: Phase 2 full impl")


GLOVES: dict[str, StackGlove] = {
    "python": PythonGlove(),
    "dart": DartGlove(),
    "react": ReactGlove(),
    "astro": ReactGlove(),
    "sql": SQLGlove(),
}
