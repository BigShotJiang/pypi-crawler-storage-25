"""
TraceNodeMapper — stack-agnostic bridge between execution trace
node IDs and declaration graph node IDs.

Each stack implements the TraceNodeMapper protocol. The mapper is
registered in TRACE_NODE_MAPPERS keyed by stack name, matching
the stack names in core.stack_profiles.

Design principles:
- Protocol not inheritance (runtime duck typing, no ABC overhead)
- Graceful: unknown IDs return None, never crash
- Stack-agnostic: Python is the first implementation, others follow
- Stateless: mappers take a trace_id and return a manifest_id or None
"""

from __future__ import annotations
from typing import Protocol, Optional, runtime_checkable


@runtime_checkable
class TraceNodeMapper(Protocol):
    """Maps a trace node ID to its manifest node ID equivalent.
    
    Each stack has a different trace ID scheme. This protocol
    ensures the execution→declaration bridge works for any stack.
    """
    
    def map(self, trace_id: str) -> Optional[str]:
        """Return manifest node id for trace_id, or None if unmappable."""
        ...
    
    def reverse(self, manifest_id: str) -> Optional[str]:
        """Return trace id for manifest_id, or None if unmappable.
        Used for looking up whether a specific manifest node was traced.
        """
        ...


class PythonTraceNodeMapper:
    """Maps Python module.qualname trace IDs to manifest node IDs.
    
    Python traces produce IDs like:
      forge.core.manifest_document.ManifestDocument.from_path
    
    Manifest nodes use IDs like:
      module/core.manifest_document
    
    Mapping rule:
      1. Strip "forge." prefix if present
      2. Take the module segment (everything before the first class/fn)
      3. Prepend "module/"
    
    This mapper operates at module granularity — a trace of any
    function in a module counts as that module being traced.
    """
    
    _PREFIX = "forge."
    
    def map(self, trace_id: str) -> Optional[str]:
        """Map Python trace ID to manifest node ID."""
        if not trace_id:
            return None
        
        # Strip forge. prefix
        s = trace_id
        if s.startswith(self._PREFIX):
            s = s[len(self._PREFIX):]
        
        # Take the module path — everything up to (not including)
        # the first capitalized segment (class name) or function name
        parts = s.split(".")
        module_parts = []
        for i, part in enumerate(parts):
            # Stop at first class name (capitalized) - this indicates we've reached the class/function level
            if part and part[0].isupper():
                break
            # If this is the last part, include it (could be a module name)
            if i == len(parts) - 1:
                module_parts.append(part)
                break
            # Stop before the last part if the last part looks like a function/class (not a module)
            elif i == len(parts) - 2 and len(parts) > 1:
                last_part = parts[-1]
                # If the last part starts with uppercase (class) or we have 3+ parts (likely module.function), stop here
                if last_part[0].isupper() or len(parts) >= 3:
                    module_parts.append(part)
                    break
                # Otherwise, the last part is probably a module name, so continue
                elif part:
                    module_parts.append(part)
            elif part:
                module_parts.append(part)
        
        if not module_parts:
            return None
        
        module_path = ".".join(module_parts)
        return f"module/{module_path}"
    
    def reverse(self, manifest_id: str) -> Optional[str]:
        """Map manifest node ID back to Python module path."""
        if not manifest_id or not manifest_id.startswith("module/"):
            return None
        module_path = manifest_id[len("module/"):]
        return f"{self._PREFIX}{module_path}"


class WebTraceNodeMapper:
    """Placeholder for web stack (Astro/React) trace ID mapping.
    
    Web traces will use a different ID scheme (file paths, not
    module paths). This stub satisfies the protocol contract and
    returns None for all IDs until implemented.
    """
    
    def map(self, trace_id: str) -> Optional[str]:
        return None  # TODO: implement for Astro/React traces
    
    def reverse(self, manifest_id: str) -> Optional[str]:
        return None  # TODO: implement for Astro/React traces


class DartTraceNodeMapper:
    """Placeholder for Dart/Flutter stack trace ID mapping.
    
    Dart traces will use library URIs (package:app/core/manifest.dart).
    This stub returns None until implemented.
    """
    
    def map(self, trace_id: str) -> Optional[str]:
        return None  # TODO: implement for Dart/Flutter traces
    
    def reverse(self, manifest_id: str) -> Optional[str]:
        return None  # TODO: implement for Dart/Flutter traces


# Registry — keyed by stack profile id from core.stack_profiles
# Add new stacks here as their mappers are implemented.
TRACE_NODE_MAPPERS: dict[str, TraceNodeMapper] = {
    "python-cli": PythonTraceNodeMapper(),
    "python":     PythonTraceNodeMapper(),
    "web":        WebTraceNodeMapper(),
    "astro":      WebTraceNodeMapper(),
    "flutter-app": DartTraceNodeMapper(),
    "dart":       DartTraceNodeMapper(),
}


def get_mapper(stack: str) -> TraceNodeMapper:
    """Return the mapper for a given stack, defaulting to Python."""
    return TRACE_NODE_MAPPERS.get(stack, PythonTraceNodeMapper())
