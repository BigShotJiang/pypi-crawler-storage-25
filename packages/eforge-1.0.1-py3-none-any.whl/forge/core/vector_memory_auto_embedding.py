"""Vector Memory Auto-Embedding Integration.

Automatically embeds content from event log, execution graph, and other sources
into the vector memory layer for semantic search and fuzzy recall.
"""

import logging
import time
from typing import Any, Dict, List, Optional

from forge.core.event_log import get_event_log, EventEntry
from forge.core.execution_graph import get_execution_manager, ExecutionResult
from forge.core.vector_memory import auto_embed_content, get_vector_memory_store
from forge.core.path_utils import resolve_project_path

logger = logging.getLogger(__name__)


def _list_intent_records(project_root):
    """Stub — intent records will reconnect to ForgeEntity system in future session."""
    return []


class VectorMemoryAutoEmbedding:
    """Handles automatic embedding of content into vector memory."""
    
    def __init__(self, project_path):
        self.project_path = project_path
        self.memory_store = get_vector_memory_store(project_path)
    
    def embed_event_log_entries(self, limit: int = 100) -> Dict[str, Any]:
        """Auto-embed recent event log entries."""
        try:
            event_log = get_event_log()
            recent_events = event_log.get_recent_events(limit)
            
            embedded_count = 0
            errors = []
            
            for event in recent_events:
                try:
                    # Create content from event
                    content_parts = [
                        f"Event Type: {event.event_type.value}",
                        f"Severity: {event.severity.value}",
                        f"Timestamp: {event.iso_timestamp}",
                    ]
                    
                    if event.data:
                        content_parts.append(f"Data: {event.data}")
                    
                    if event.metadata:
                        content_parts.append(f"Metadata: {event.metadata}")
                    
                    content = "\n".join(content_parts)
                    
                    # Auto-embed
                    entry_id = auto_embed_content(
                        content=content,
                        content_type="event",
                        source_id=event.id,
                        metadata={
                            "event_type": event.event_type.value,
                            "severity": event.severity.value,
                            "project_path": event.metadata.project_path if event.metadata else None
                        },
                        project_path=str(self.project_path)
                    )
                    
                    if entry_id:
                        embedded_count += 1
                        
                except Exception as e:
                    errors.append(f"Failed to embed event {event.id}: {e}")
            
            return {
                "total_events": len(recent_events),
                "embedded_count": embedded_count,
                "errors": errors,
                "project_path": str(self.project_path)
            }
            
        except Exception as e:
            logger.error(f"Failed to auto-embed from event log: {e}")
            return {
                "error": str(e),
                "project_path": str(self.project_path)
            }
    
    def embed_execution_results(self, limit: int = 100) -> Dict[str, Any]:
        """Auto-embed recent execution graph results."""
        try:
            execution_manager = get_execution_manager(self.project_path)
            recent_results = execution_manager.get_recent_results(limit)
            
            embedded_count = 0
            errors = []
            
            for result in recent_results:
                try:
                    # Create content from execution result
                    content_parts = [
                        f"Operation Type: {result.operation_type}",
                        f"Status: {result.status}",
                        f"Timestamp: {result.iso_timestamp}",
                        f"Project Path: {result.project_path}",
                    ]
                    
                    if result.operation_id:
                        content_parts.append(f"Operation ID: {result.operation_id}")
                    
                    if result.duration_ms:
                        content_parts.append(f"Duration: {result.duration_ms}ms")
                    
                    if result.exit_code is not None:
                        content_parts.append(f"Exit Code: {result.exit_code}")
                    
                    if result.data:
                        content_parts.append(f"Data: {result.data}")
                    
                    if result.metadata:
                        content_parts.append(f"Metadata: {result.metadata}")
                    
                    content = "\n".join(content_parts)
                    
                    # Auto-embed
                    entry_id = auto_embed_content(
                        content=content,
                        content_type="execution_result",
                        source_id=result.id,
                        metadata={
                            "operation_type": result.operation_type,
                            "status": result.status,
                            "project_path": result.project_path,
                            "duration_ms": result.duration_ms,
                            "exit_code": result.exit_code
                        },
                        project_path=str(self.project_path)
                    )
                    
                    if entry_id:
                        embedded_count += 1
                        
                except Exception as e:
                    errors.append(f"Failed to embed execution result {result.id}: {e}")
            
            return {
                "total_results": len(recent_results),
                "embedded_count": embedded_count,
                "errors": errors,
                "project_path": str(self.project_path)
            }
            
        except Exception as e:
            logger.error(f"Failed to auto-embed from execution graph: {e}")
            return {
                "error": str(e),
                "project_path": str(self.project_path)
            }
    
    def embed_intent_records(self, limit: int = 50) -> Dict[str, Any]:
        """Auto-embed intent records."""
        try:
                        
            intent_records = _list_intent_records(self.project_path)
            embedded_count = 0
            errors = []
            
            for i, (path, record) in enumerate(intent_records[:limit]):
                try:
                    # Create content from intent record
                    content_parts = [
                        f"Intent ID: {record.id}",
                        f"Scope: {record.scope.value}",
                        f"Status: {record.status.value}",
                        f"Description: {record.raw_description}",
                        f"Created: {record.created_at}",
                    ]
                    
                    if record.target_id:
                        content_parts.append(f"Target ID: {record.target_id}")
                    
                    if record.extracted_nodes:
                        content_parts.append(f"Extracted Nodes: {record.extracted_nodes}")
                    
                    if record.source:
                        content_parts.append(f"Source: {record.source}")
                    
                    content = "\n".join(content_parts)
                    
                    # Auto-embed
                    entry_id = auto_embed_content(
                        content=content,
                        content_type="intent",
                        source_id=record.id,
                        metadata={
                            "scope": record.scope.value,
                            "status": record.status.value,
                            "target_id": record.target_id,
                            "source": record.source,
                            "created_at": record.created_at
                        },
                        project_path=str(self.project_path)
                    )
                    
                    if entry_id:
                        embedded_count += 1
                        
                except Exception as e:
                    errors.append(f"Failed to embed intent {record.id}: {e}")
            
            return {
                "total_intents": len(intent_records[:limit]),
                "embedded_count": embedded_count,
                "errors": errors,
                "project_path": str(self.project_path)
            }
            
        except Exception as e:
            logger.error(f"Failed to auto-embed from intent records: {e}")
            return {
                "error": str(e),
                "project_path": str(self.project_path)
            }
    
    def embed_annotations(self, limit: int = 100) -> Dict[str, Any]:
        """Auto-embed annotation records."""
        try:
            from forge.core.annotations import AnnotationIndex
            
            annotation_index = AnnotationIndex(self.project_path)
            annotations = annotation_index.get_recent_annotations(limit)
            
            embedded_count = 0
            errors = []
            
            for annotation in annotations:
                try:
                    # Create content from annotation
                    content_parts = [
                        f"Annotation ID: {annotation.id}",
                        f"Kind: {annotation.kind.value}",
                        f"Severity: {annotation.severity.value}",
                        f"Node ID: {annotation.node_id}",
                        f"Created: {annotation.created_at}",
                    ]
                    
                    if annotation.title:
                        content_parts.append(f"Title: {annotation.title}")
                    
                    if annotation.note:
                        content_parts.append(f"Note: {annotation.note}")
                    
                    if annotation.metadata:
                        content_parts.append(f"Metadata: {annotation.metadata}")
                    
                    content = "\n".join(content_parts)
                    
                    # Auto-embed
                    entry_id = auto_embed_content(
                        content=content,
                        content_type="annotation",
                        source_id=annotation.id,
                        metadata={
                            "kind": annotation.kind.value,
                            "severity": annotation.severity.value,
                            "node_id": annotation.node_id,
                            "title": annotation.title,
                            "created_at": annotation.created_at
                        },
                        project_path=str(self.project_path)
                    )
                    
                    if entry_id:
                        embedded_count += 1
                        
                except Exception as e:
                    errors.append(f"Failed to embed annotation {annotation.id}: {e}")
            
            return {
                "total_annotations": len(annotations),
                "embedded_count": embedded_count,
                "errors": errors,
                "project_path": str(self.project_path)
            }
            
        except Exception as e:
            logger.error(f"Failed to auto-embed from annotations: {e}")
            return {
                "error": str(e),
                "project_path": str(self.project_path)
            }
    
    def run_full_auto_embedding(self) -> Dict[str, Any]:
        """Run complete auto-embedding for all content types."""
        start_time = time.time()
        
        results = {}
        
        # Embed event log entries
        results["events"] = self.embed_event_log_entries()
        
        # Embed execution results
        results["execution_results"] = self.embed_execution_results()
        
        # Embed intent records
        results["intents"] = self.embed_intent_records()
        
        # Embed annotations
        results["annotations"] = self.embed_annotations()
        
        # Calculate totals
        total_embedded = sum(r.get("embedded_count", 0) for r in results.values())
        total_errors = sum(len(r.get("errors", [])) for r in results.values())
        
        duration_ms = int((time.time() - start_time) * 1000)
        
        return {
            "status": "completed",
            "duration_ms": duration_ms,
            "total_embedded": total_embedded,
            "total_errors": total_errors,
            "results": results,
            "project_path": str(self.project_path)
        }


def get_auto_embedding(project_path) -> VectorMemoryAutoEmbedding:
    """Get auto-embedding instance for a project."""
    return VectorMemoryAutoEmbedding(project_path)


def trigger_auto_embedding_on_event(event_type: str, entity_data: Dict[str, Any], project_path: str) -> bool:
    """Trigger auto-embedding when significant events occur."""
    try:
        auto_embedding = get_auto_embedding(resolve_project_path(project_path))
        
        # Trigger embedding based on event type
        if event_type in ["scaffold.completed", "scan.completed", "intent.created"]:
            # Run a quick embedding of recent content
            if event_type == "intent.created":
                auto_embedding.embed_intent_records(limit=5)
            elif event_type == "scaffold.completed":
                auto_embedding.embed_execution_results(limit=5)
            elif event_type == "scan.completed":
                auto_embedding.embed_event_log_entries(limit=10)
        
        return True
        
    except Exception as e:
        logger.error(f"Failed to trigger auto-embedding: {e}")
        return False


__all__ = [
    "VectorMemoryAutoEmbedding",
    "get_auto_embedding",
    "trigger_auto_embedding_on_event"
]
