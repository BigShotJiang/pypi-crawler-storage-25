"""
Atomic Memory Mapper - Universal Memory Call Mapping Across Languages

Maps memory calls, allocations, and patterns across all programming languages
at the most atomic level, enabling universal framework discovery and analysis.
"""

from __future__ import annotations

import ast
import json
import re
import subprocess
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Union, Tuple
from uuid import uuid4


class MemoryOperation(Enum):
    """Types of memory operations."""
    ALLOCATE = "allocate"
    DEALLOCATE = "deallocate"
    READ = "read"
    WRITE = "write"
    COPY = "copy"
    MOVE = "move"
    REFERENCE = "reference"
    DEREFERENCE = "dereference"
    MAP = "map"
    UNMAP = "unmap"
    LOCK = "lock"
    UNLOCK = "unlock"


class MemoryScope(Enum):
    """Memory scope levels."""
    STACK = "stack"
    HEAP = "heap"
    STATIC = "static"
    GLOBAL = "global"
    REGISTER = "register"
    CACHE = "cache"
    VIRTUAL = "virtual"


@dataclass
class AtomicMemoryNode:
    """Atomic memory operation node."""
    id: str
    operation: MemoryOperation
    scope: MemoryScope
    size_bytes: Optional[int]
    address_pattern: str
    data_type: str
    language: str
    file_path: str
    line_start: int
    line_end: int
    function_name: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    dependencies: Set[str] = field(default_factory=set)
    callers: Set[str] = field(default_factory=set)


@dataclass
class MemoryPattern:
    """Memory usage pattern across languages."""
    pattern_id: str
    pattern_name: str
    description: str
    languages: Set[str]
    frequency: int
    complexity_score: float
    memory_efficiency: float
    security_implications: List[str]
    examples: List[AtomicMemoryNode]


class LanguageMemoryMapper(ABC):
    """Abstract base for language-specific memory mapping."""
    
    @abstractmethod
    def extract_memory_operations(self, file_path: Path) -> List[AtomicMemoryNode]:
        """Extract memory operations from source file."""
        pass
    
    @abstractmethod
    def get_language_name(self) -> str:
        """Get the language name."""
        pass
    
    @abstractmethod
    def detect_memory_patterns(self, nodes: List[AtomicMemoryNode]) -> List[MemoryPattern]:
        """Detect memory usage patterns."""
        pass


class PythonMemoryMapper(LanguageMemoryMapper):
    """Python-specific memory mapper."""
    
    def get_language_name(self) -> str:
        return "python"
    
    def extract_memory_operations(self, file_path: Path) -> List[AtomicMemoryNode]:
        """Extract Python memory operations using AST analysis."""
        nodes = []
        
        try:
            with open(file_path, 'r') as f:
                content = f.read()
            
            tree = ast.parse(content)
            
            for ast_node in ast.walk(tree):
                if isinstance(ast_node, ast.Call):
                    memory_node = self._analyze_function_call(ast_node, file_path, content)
                    if memory_node:
                        nodes.append(memory_node)
                
                elif isinstance(ast_node, ast.Assign):
                    memory_nodes = self._analyze_assignment(ast_node, file_path, content)
                    nodes.extend(memory_nodes)
                
                elif isinstance(ast_node, ast.ClassDef):
                    memory_nodes = self._analyze_class_definition(ast_node, file_path, content)
                    nodes.extend(memory_nodes)
                
                elif isinstance(ast_node, ast.FunctionDef):
                    memory_nodes = self._analyze_function_definition(ast_node, file_path, content)
                    nodes.extend(memory_nodes)
        
        except Exception as e:
            print(f"Error parsing {file_path}: {e}")
        
        return nodes
    
    def _analyze_function_call(self, call_node: ast.Call, file_path: Path, content: str) -> Optional[AtomicMemoryNode]:
        """Analyze function call for memory operations."""
        if isinstance(call_node.func, ast.Name):
            func_name = call_node.func.id
            
            # Memory allocation patterns
            if func_name in ["malloc", "calloc", "realloc", "valloc", "aligned_alloc"]:
                return AtomicMemoryNode(
                    id=f"{file_path}:{call_node.lineno}:alloc_{func_name}",
                    operation=MemoryOperation.ALLOCATE,
                    scope=MemoryScope.HEAP,
                    size_bytes=self._estimate_size_from_call(call_node),
                    address_pattern="heap_ptr",
                    data_type="void*",
                    language="python",
                    file_path=str(file_path),
                    line_start=call_node.lineno,
                    line_end=getattr(call_node, "end_lineno", call_node.lineno),
                    function_name=self._get_enclosing_function(call_node),
                    metadata={"call_type": func_name, "args_count": len(call_node.args)}
                )
            
            # Memory deallocation
            elif func_name in ["free", "dealloc"]:
                return AtomicMemoryNode(
                    id=f"{file_path}:{call_node.lineno}:dealloc_{func_name}",
                    operation=MemoryOperation.DEALLOCATE,
                    scope=MemoryScope.HEAP,
                    size_bytes=None,
                    address_pattern="heap_ptr",
                    data_type="void",
                    language="python",
                    file_path=str(file_path),
                    line_start=call_node.lineno,
                    line_end=getattr(call_node, "end_lineno", call_node.lineno),
                    function_name=self._get_enclosing_function(call_node),
                    metadata={"call_type": func_name}
                )
            
            # Memory mapping
            elif func_name in ["mmap", "mmap64"]:
                return AtomicMemoryNode(
                    id=f"{file_path}:{call_node.lineno}:mmap",
                    operation=MemoryOperation.MAP,
                    scope=MemoryScope.VIRTUAL,
                    size_bytes=self._estimate_size_from_call(call_node),
                    address_pattern="virtual_addr",
                    data_type="void*",
                    language="python",
                    file_path=str(file_path),
                    line_start=call_node.lineno,
                    line_end=getattr(call_node, "end_lineno", call_node.lineno),
                    function_name=self._get_enclosing_function(call_node),
                    metadata={"call_type": "mmap"}
                )
            
            # Python-specific memory operations
            elif func_name in ["array", "bytearray", "memoryview", "buffer"]:
                return AtomicMemoryNode(
                    id=f"{file_path}:{call_node.lineno}:python_{func_name}",
                    operation=MemoryOperation.ALLOCATE,
                    scope=MemoryScope.HEAP,
                    size_bytes=self._estimate_python_size(func_name, call_node),
                    address_pattern="python_obj",
                    data_type=func_name,
                    language="python",
                    file_path=str(file_path),
                    line_start=call_node.lineno,
                    line_end=getattr(call_node, "end_lineno", call_node.lineno),
                    function_name=self._get_enclosing_function(call_node),
                    metadata={"python_type": func_name}
                )
        
        return None
    
    def _analyze_assignment(self, assign_node: ast.Assign, file_path: Path, content: str) -> List[AtomicMemoryNode]:
        """Analyze assignment for memory operations."""
        nodes = []
        
        for target in assign_node.targets:
            if isinstance(target, ast.Name):
                var_name = target.id
                
                # Check for large data structure creation
                if isinstance(assign_node.value, ast.List):
                    list_len = len(assign_node.value.elts)
                    if list_len > 10:  # Large list
                        nodes.append(AtomicMemoryNode(
                            id=f"{file_path}:{assign_node.lineno}:list_alloc_{var_name}",
                            operation=MemoryOperation.ALLOCATE,
                            scope=MemoryScope.HEAP,
                            size_bytes=list_len * 8,  # Rough estimate
                            address_pattern="python_list",
                            data_type="list",
                            language="python",
                            file_path=str(file_path),
                            line_start=assign_node.lineno,
                            line_end=getattr(assign_node, "end_lineno", assign_node.lineno),
                            function_name=self._get_enclosing_function(assign_node),
                            metadata={"var_name": var_name, "list_length": list_len}
                        ))
                
                elif isinstance(assign_node.value, ast.Dict):
                    dict_len = len(assign_node.value.keys)
                    if dict_len > 10:  # Large dict
                        nodes.append(AtomicMemoryNode(
                            id=f"{file_path}:{assign_node.lineno}:dict_alloc_{var_name}",
                            operation=MemoryOperation.ALLOCATE,
                            scope=MemoryScope.HEAP,
                            size_bytes=dict_len * 16,  # Rough estimate
                            address_pattern="python_dict",
                            data_type="dict",
                            language="python",
                            file_path=str(file_path),
                            line_start=assign_node.lineno,
                            line_end=getattr(assign_node, "end_lineno", assign_node.lineno),
                            function_name=self._get_enclosing_function(assign_node),
                            metadata={"var_name": var_name, "dict_length": dict_len}
                        ))
        
        return nodes
    
    def _analyze_class_definition(self, class_node: ast.ClassDef, file_path: Path, content: str) -> List[AtomicMemoryNode]:
        """Analyze class definition for memory patterns."""
        nodes = []
        
        # Check for __slots__ optimization
        for item in class_node.body:
            if isinstance(item, ast.Assign):
                for target in item.targets:
                    if isinstance(target, ast.Name) and target.id == "__slots__":
                        nodes.append(AtomicMemoryNode(
                            id=f"{file_path}:{class_node.lineno}:slots_optimization",
                            operation=MemoryOperation.ALLOCATE,
                            scope=MemoryScope.HEAP,
                            size_bytes=len(item.value.elts) * 8 if hasattr(item.value, 'elts') else 0,
                            address_pattern="instance_slots",
                            data_type="__slots__",
                            language="python",
                            file_path=str(file_path),
                            line_start=class_node.lineno,
                            line_end=getattr(class_node, "end_lineno", class_node.lineno),
                            function_name=class_node.name,
                            metadata={"optimization": "__slots__", "class": class_node.name}
                        ))
        
        return nodes
    
    def _analyze_function_definition(self, func_node: ast.FunctionDef, file_path: Path, content: str) -> List[AtomicMemoryNode]:
        """Analyze function definition for stack operations."""
        nodes = []
        
        # Stack frame allocation
        args_size = len(func_node.args.args) * 8  # Rough estimate
        nodes.append(AtomicMemoryNode(
            id=f"{file_path}:{func_node.lineno}:stack_frame_{func_node.name}",
            operation=MemoryOperation.ALLOCATE,
            scope=MemoryScope.STACK,
            size_bytes=args_size,
            address_pattern="stack_frame",
            data_type="stack_frame",
            language="python",
            file_path=str(file_path),
            line_start=func_node.lineno,
            line_end=getattr(func_node, "end_lineno", func_node.lineno),
            function_name=func_node.name,
            metadata={"args_count": len(func_node.args.args), "function": func_node.name}
        ))
        
        return nodes
    
    def _estimate_size_from_call(self, call_node: ast.Call) -> Optional[int]:
        """Estimate memory size from function call arguments."""
        if call_node.args:
            # Try to extract size from first argument
            first_arg = call_node.args[0]
            if isinstance(first_arg, ast.Constant):
                return first_arg.value
            elif isinstance(first_arg, ast.Num):
                return first_arg.n
        return None
    
    def _estimate_python_size(self, func_name: str, call_node: ast.Call) -> Optional[int]:
        """Estimate Python object size."""
        if func_name == "array" and call_node.args:
            # array(typecode, initializer)
            if len(call_node.args) >= 2:
                initializer = call_node.args[1]
                if isinstance(initializer, ast.List):
                    return len(initializer.elts) * 8
        elif func_name in ["bytearray", "memoryview"] and call_node.args:
            # bytearray(size)
            first_arg = call_node.args[0]
            if isinstance(first_arg, ast.Constant):
                return first_arg.value
        return None
    
    def _get_enclosing_function(self, node: ast.AST) -> str:
        """Get the name of the enclosing function."""
        # This would need to be implemented with proper AST traversal
        return "unknown"
    
    def detect_memory_patterns(self, nodes: List[AtomicMemoryNode]) -> List[MemoryPattern]:
        """Detect Python memory usage patterns."""
        patterns = []
        
        # Pattern 1: Large list allocations
        large_lists = [n for n in nodes if n.data_type == "list" and n.size_bytes and n.size_bytes > 1000]
        if large_lists:
            patterns.append(MemoryPattern(
                pattern_id="large_list_allocation",
                pattern_name="Large List Allocation",
                description="Frequent allocation of large lists",
                languages={"python"},
                frequency=len(large_lists),
                complexity_score=0.6,
                memory_efficiency=0.7,
                security_implications=["potential_memory_exhaustion"],
                examples=large_lists[:5]
            ))
        
        # Pattern 2: Memory leak patterns (alloc without dealloc)
        alloc_nodes = [n for n in nodes if n.operation == MemoryOperation.ALLOCATE]
        dealloc_nodes = [n for n in nodes if n.operation == MemoryOperation.DEALLOCATE]
        
        if len(alloc_nodes) > len(dealloc_nodes) * 2:
            patterns.append(MemoryPattern(
                pattern_id="potential_memory_leak",
                pattern_name="Potential Memory Leak",
                description="More allocations than deallocations",
                languages={"python"},
                frequency=len(alloc_nodes) - len(dealloc_nodes),
                complexity_score=0.8,
                memory_efficiency=0.3,
                security_implications=["memory_leak", "resource_exhaustion"],
                examples=alloc_nodes[:5]
            ))
        
        return patterns


class CMemoryMapper(LanguageMemoryMapper):
    """C/C++ specific memory mapper."""
    
    def get_language_name(self) -> str:
        return "c"
    
    def extract_memory_operations(self, file_path: Path) -> List[AtomicMemoryNode]:
        """Extract C/C++ memory operations using regex analysis."""
        nodes = []
        
        try:
            with open(file_path, 'r') as f:
                content = f.read()
            
            lines = content.split('\n')
            
            for line_num, line in enumerate(lines, 1):
                # malloc patterns
                malloc_match = re.search(r'(\w+)\s*=\s*(?:malloc|calloc|realloc)\s*\(', line)
                if malloc_match:
                    var_name = malloc_match.group(1)
                    size_match = re.search(r'(\w+)\s*\*\s*(\w+)', line)
                    size = int(size_match.group(1)) if size_match else None
                    
                    nodes.append(AtomicMemoryNode(
                        id=f"{file_path}:{line_num}:malloc_{var_name}",
                        operation=MemoryOperation.ALLOCATE,
                        scope=MemoryScope.HEAP,
                        size_bytes=size,
                        address_pattern="heap_ptr",
                        data_type="void*",
                        language="c",
                        file_path=str(file_path),
                        line_start=line_num,
                        line_end=line_num,
                        function_name="unknown",
                        metadata={"variable": var_name}
                    ))
                
                # free patterns
                free_match = re.search(r'free\s*\(\s*(\w+)\s*\)', line)
                if free_match:
                    var_name = free_match.group(1)
                    nodes.append(AtomicMemoryNode(
                        id=f"{file_path}:{line_num}:free_{var_name}",
                        operation=MemoryOperation.DEALLOCATE,
                        scope=MemoryScope.HEAP,
                        size_bytes=None,
                        address_pattern="heap_ptr",
                        data_type="void",
                        language="c",
                        file_path=str(file_path),
                        line_start=line_num,
                        line_end=line_num,
                        function_name="unknown",
                        metadata={"variable": var_name}
                    ))
                
                # mmap patterns
                mmap_match = re.search(r'(\w+)\s*=\s*mmap\s*\(', line)
                if mmap_match:
                    var_name = mmap_match.group(1)
                    nodes.append(AtomicMemoryNode(
                        id=f"{file_path}:{line_num}:mmap_{var_name}",
                        operation=MemoryOperation.MAP,
                        scope=MemoryScope.VIRTUAL,
                        size_bytes=None,
                        address_pattern="virtual_addr",
                        data_type="void*",
                        language="c",
                        file_path=str(file_path),
                        line_start=line_num,
                        line_end=line_num,
                        function_name="unknown",
                        metadata={"variable": var_name}
                    ))
                
                # Stack arrays
                array_match = re.search(r'(\w+)\s+(\w+)\s*\[(\w+)\]', line)
                if array_match:
                    type_name = array_match.group(1)
                    var_name = array_match.group(2)
                    size_str = array_match.group(3)
                    
                    try:
                        size = int(size_str)
                        nodes.append(AtomicMemoryNode(
                            id=f"{file_path}:{line_num}:stack_array_{var_name}",
                            operation=MemoryOperation.ALLOCATE,
                            scope=MemoryScope.STACK,
                            size_bytes=size * self._get_type_size(type_name),
                            address_pattern="stack_array",
                            data_type=type_name,
                            language="c",
                            file_path=str(file_path),
                            line_start=line_num,
                            line_end=line_num,
                            function_name="unknown",
                            metadata={"variable": var_name, "array_size": size}
                        ))
                    except ValueError:
                        pass
        
        except Exception as e:
            print(f"Error parsing C file {file_path}: {e}")
        
        return nodes
    
    def _get_type_size(self, type_name: str) -> int:
        """Get size of C type in bytes."""
        type_sizes = {
            "char": 1, "int": 4, "float": 4, "double": 8,
            "long": 8, "short": 2, "void": 1, "bool": 1
        }
        return type_sizes.get(type_name, 4)
    
    def detect_memory_patterns(self, nodes: List[AtomicMemoryNode]) -> List[MemoryPattern]:
        """Detect C/C++ memory usage patterns."""
        patterns = []
        
        # Pattern 1: Stack buffer usage
        stack_arrays = [n for n in nodes if n.scope == MemoryScope.STACK and n.data_type != "stack_frame"]
        if stack_arrays:
            patterns.append(MemoryPattern(
                pattern_id="stack_buffer_usage",
                pattern_name="Stack Buffer Usage",
                description="Stack-allocated buffer arrays",
                languages={"c"},
                frequency=len(stack_arrays),
                complexity_score=0.4,
                memory_efficiency=0.8,
                security_implications=["stack_overflow"],
                examples=stack_arrays[:5]
            ))
        
        # Pattern 2: Heap allocation patterns
        heap_allocs = [n for n in nodes if n.scope == MemoryScope.HEAP and n.operation == MemoryOperation.ALLOCATE]
        if heap_allocs:
            patterns.append(MemoryPattern(
                pattern_id="heap_allocation",
                pattern_name="Heap Allocation",
                description="Dynamic heap memory allocation",
                languages={"c"},
                frequency=len(heap_allocs),
                complexity_score=0.7,
                memory_efficiency=0.6,
                security_implications=["heap_overflow", "memory_leak"],
                examples=heap_allocs[:5]
            ))
        
        return patterns


class JavaScriptMemoryMapper(LanguageMemoryMapper):
    """JavaScript specific memory mapper."""
    
    def get_language_name(self) -> str:
        return "javascript"
    
    def extract_memory_operations(self, file_path: Path) -> List[AtomicMemoryNode]:
        """Extract JavaScript memory operations."""
        nodes = []
        
        try:
            with open(file_path, 'r') as f:
                content = f.read()
            
            lines = content.split('\n')
            
            for line_num, line in enumerate(lines, 1):
                # Array creation
                array_match = re.search(r'(\w+)\s*=\s*\[(.*?)\]', line)
                if array_match:
                    var_name = array_match.group(1)
                    elements = array_match.group(2)
                    element_count = len([e for e in elements.split(',') if e.strip()])
                    
                    if element_count > 5:  # Large array
                        nodes.append(AtomicMemoryNode(
                            id=f"{file_path}:{line_num}:array_{var_name}",
                            operation=MemoryOperation.ALLOCATE,
                            scope=MemoryScope.HEAP,
                            size_bytes=element_count * 8,
                            address_pattern="js_array",
                            data_type="Array",
                            language="javascript",
                            file_path=str(file_path),
                            line_start=line_num,
                            line_end=line_num,
                            function_name="unknown",
                            metadata={"variable": var_name, "element_count": element_count}
                        ))
                
                # Object creation
                object_match = re.search(r'(\w+)\s*=\s*\{(.*?)\}', line)
                if object_match:
                    var_name = object_match.group(1)
                    properties = object_match.group(2)
                    prop_count = len([p for p in properties.split(',') if p.strip()])
                    
                    if prop_count > 5:  # Large object
                        nodes.append(AtomicMemoryNode(
                            id=f"{file_path}:{line_num}:object_{var_name}",
                            operation=MemoryOperation.ALLOCATE,
                            scope=MemoryScope.HEAP,
                            size_bytes=prop_count * 16,
                            address_pattern="js_object",
                            data_type="Object",
                            language="javascript",
                            file_path=str(file_path),
                            line_start=line_num,
                            line_end=line_num,
                            function_name="unknown",
                            metadata={"variable": var_name, "property_count": prop_count}
                        ))
                
                # Buffer/ArrayBuffer creation
                buffer_match = re.search(r'(?:new\s+)?(?:ArrayBuffer|Buffer|Uint8Array|Int32Array)\s*\((\w+)\)', line)
                if buffer_match:
                    size_str = buffer_match.group(1)
                    try:
                        size = int(size_str)
                        nodes.append(AtomicMemoryNode(
                            id=f"{file_path}:{line_num}:buffer_{size}",
                            operation=MemoryOperation.ALLOCATE,
                            scope=MemoryScope.HEAP,
                            size_bytes=size,
                            address_pattern="js_buffer",
                            data_type="ArrayBuffer",
                            language="javascript",
                            file_path=str(file_path),
                            line_start=line_num,
                            line_end=line_num,
                            function_name="unknown",
                            metadata={"buffer_size": size}
                        ))
                    except ValueError:
                        pass
        
        except Exception as e:
            print(f"Error parsing JavaScript file {file_path}: {e}")
        
        return nodes
    
    def detect_memory_patterns(self, nodes: List[AtomicMemoryNode]) -> List[MemoryPattern]:
        """Detect JavaScript memory usage patterns."""
        patterns = []
        
        # Pattern 1: Large object allocations
        large_objects = [n for n in nodes if n.data_type == "Object" and n.size_bytes and n.size_bytes > 1000]
        if large_objects:
            patterns.append(MemoryPattern(
                pattern_id="large_object_allocation",
                pattern_name="Large Object Allocation",
                description="Frequent allocation of large JavaScript objects",
                languages={"javascript"},
                frequency=len(large_objects),
                complexity_score=0.5,
                memory_efficiency=0.7,
                security_implications=["memory_pressure"],
                examples=large_objects[:5]
            ))
        
        return patterns


class AtomicMemoryMapper:
    """Universal atomic memory mapper across all languages."""
    
    def __init__(self):
        self.mappers: Dict[str, LanguageMemoryMapper] = {
            "python": PythonMemoryMapper(),
            "c": CMemoryMapper(),
            "cpp": CMemoryMapper(),  # Use C mapper for C++
            "javascript": JavaScriptMemoryMapper(),
            "typescript": JavaScriptMemoryMapper(),  # Use JS mapper for TypeScript
        }
    
    def detect_language(self, file_path: Path) -> str:
        """Detect programming language from file extension and content."""
        ext = file_path.suffix.lower()
        
        language_map = {
            ".py": "python",
            ".c": "c",
            ".cpp": "cpp",
            ".cc": "cpp",
            ".cxx": "cpp",
            ".h": "c",  # Header files, assume C
            ".hpp": "cpp",
            ".js": "javascript",
            ".jsx": "javascript",
            ".ts": "typescript",
            ".tsx": "typescript",
            ".java": "java",
            ".rs": "rust",
            ".go": "go",
            ".rb": "ruby",
        }
        
        return language_map.get(ext, "unknown")
    
    def map_memory_operations(self, project_path: Path) -> Dict[str, List[AtomicMemoryNode]]:
        """Map memory operations across all files in project."""
        all_nodes: Dict[str, List[AtomicMemoryNode]] = {}
        
        # Find all source files
        source_extensions = [".py", ".c", ".cpp", ".cc", ".cxx", ".h", ".hpp", ".js", ".jsx", ".ts", ".tsx"]
        source_files = []
        for ext in source_extensions:
            source_files.extend(project_path.rglob(f"*{ext}"))
        
        for file_path in source_files:
            language = self.detect_language(file_path)
            if language == "unknown":
                continue
            
            mapper = self.mappers.get(language)
            if mapper:
                nodes = mapper.extract_memory_operations(file_path)
                if nodes:
                    all_nodes[str(file_path)] = nodes
        
        return all_nodes
    
    def analyze_cross_language_patterns(self, all_nodes: Dict[str, List[AtomicMemoryNode]]) -> List[MemoryPattern]:
        """Analyze memory patterns across all languages."""
        all_patterns = []
        
        # Collect all nodes by language
        nodes_by_language: Dict[str, List[AtomicMemoryNode]] = {}
        for file_path, nodes in all_nodes.items():
            if nodes:
                language = nodes[0].language
                if language not in nodes_by_language:
                    nodes_by_language[language] = []
                nodes_by_language[language].extend(nodes)
        
        # Detect patterns within each language
        for language, nodes in nodes_by_language.items():
            mapper = self.mappers.get(language)
            if mapper:
                patterns = mapper.detect_memory_patterns(nodes)
                all_patterns.extend(patterns)
        
        # Detect cross-language patterns
        cross_language_patterns = self._detect_cross_language_patterns(nodes_by_language)
        all_patterns.extend(cross_language_patterns)
        
        return all_patterns
    
    def _detect_cross_language_patterns(self, nodes_by_language: Dict[str, List[AtomicMemoryNode]]) -> List[MemoryPattern]:
        """Detect patterns that span multiple languages."""
        patterns = []
        
        # Pattern 1: High memory allocation across languages
        total_allocations = sum(len([n for n in nodes if n.operation == MemoryOperation.ALLOCATE]) 
                              for nodes in nodes_by_language.values())
        
        if total_allocations > 1000:
            patterns.append(MemoryPattern(
                pattern_id="high_memory_allocation",
                pattern_name="High Memory Allocation Across Languages",
                description="High volume of memory allocations across multiple languages",
                languages=set(nodes_by_language.keys()),
                frequency=total_allocations,
                complexity_score=0.8,
                memory_efficiency=0.5,
                security_implications=["memory_pressure", "resource_exhaustion"],
                examples=[]
            ))
        
        # Pattern 2: Mixed stack/heap usage
        stack_nodes = sum(len([n for n in nodes if n.scope == MemoryScope.STACK]) 
                         for nodes in nodes_by_language.values())
        heap_nodes = sum(len([n for n in nodes if n.operation == MemoryOperation.ALLOCATE and n.scope == MemoryScope.HEAP]) 
                         for nodes in nodes_by_language.values())
        
        if stack_nodes > 0 and heap_nodes > 0:
            patterns.append(MemoryPattern(
                pattern_id="mixed_memory_usage",
                pattern_name="Mixed Stack/Heap Memory Usage",
                description="Combined use of stack and heap memory across languages",
                languages=set(nodes_by_language.keys()),
                frequency=stack_nodes + heap_nodes,
                complexity_score=0.6,
                memory_efficiency=0.7,
                security_implications=["stack_overflow", "heap_corruption"],
                examples=[]
            ))
        
        return patterns
    
    def generate_memory_report(self, project_path: Path) -> Dict[str, Any]:
        """Generate comprehensive memory analysis report."""
        # Map memory operations
        all_nodes = self.map_memory_operations(project_path)
        
        # Analyze patterns
        patterns = self.analyze_cross_language_patterns(all_nodes)
        
        # Calculate statistics
        total_nodes = sum(len(nodes) for nodes in all_nodes.values())
        total_allocations = sum(len([n for n in nodes if n.operation == MemoryOperation.ALLOCATE]) 
                               for nodes in all_nodes.values())
        total_deallocations = sum(len([n for n in nodes if n.operation == MemoryOperation.DEALLOCATE]) 
                                 for nodes in all_nodes.values())
        
        # Memory usage by scope
        scope_usage: Dict[str, int] = {}
        for nodes in all_nodes.values():
            for node in nodes:
                scope_usage[node.scope.value] = scope_usage.get(node.scope.value, 0) + 1
        
        # Memory usage by language
        language_usage: Dict[str, int] = {}
        for file_path, nodes in all_nodes.items():
            if nodes:
                language = nodes[0].language
                language_usage[language] = language_usage.get(language, 0) + len(nodes)
        
        return {
            "project_info": {
                "path": str(project_path),
                "analysis_timestamp": time.time()
            },
            "memory_statistics": {
                "total_memory_operations": total_nodes,
                "total_allocations": total_allocations,
                "total_deallocations": total_deallocations,
                "potential_leaks": total_allocations - total_deallocations,
                "scope_distribution": scope_usage,
                "language_distribution": language_usage
            },
            "detected_patterns": [
                {
                    "pattern_id": pattern.pattern_id,
                    "pattern_name": pattern.pattern_name,
                    "description": pattern.description,
                    "languages": list(pattern.languages),
                    "frequency": pattern.frequency,
                    "complexity_score": pattern.complexity_score,
                    "memory_efficiency": pattern.memory_efficiency,
                    "security_implications": pattern.security_implications
                }
                for pattern in patterns
            ],
            "detailed_operations": {
                file_path: [
                    {
                        "id": node.id,
                        "operation": node.operation.value,
                        "scope": node.scope.value,
                        "size_bytes": node.size_bytes,
                        "data_type": node.data_type,
                        "line": node.line_start,
                        "function": node.function_name
                    }
                    for node in nodes[:100]  # Limit for report
                ]
                for file_path, nodes in all_nodes.items()
            }
        }
