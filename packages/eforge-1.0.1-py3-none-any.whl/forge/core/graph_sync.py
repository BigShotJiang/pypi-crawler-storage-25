"""Cross-graph synchronization system for INTENT-E9BAF9C4.

Coordinates between manifest, intent, and execution graphs to maintain
automatic triangulation without manual linking.
"""

import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from forge.core.event_log import get_event_log, EventType, EventEntry
from forge.core.execution_graph import get_execution_manager, persist_execution_result
from forge.core.manifest import ManifestParser
from forge.core.path_utils import resolve_project_path
from forge.core.vector_memory_auto_embedding import VectorMemoryAutoEmbedding

logger = logging.getLogger(__name__)


@dataclass
class GraphSyncEvent:
    """Event that triggers cross-graph synchronization."""
    source_graph: str  # "manifest", "intent", "execution", "event_log"
    event_type: str
    entity_id: str
    entity_data: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    sync_actions: List[str] = field(default_factory=list)


class GraphSynchronizer:
    """Coordinates synchronization between all three graphs."""
    
    def __init__(self, project_path: Path):
        self.project_path = project_path
        self.event_log = get_event_log()
        self.execution_manager = get_execution_manager(project_path)
        self.manifest_parser = ManifestParser(project_path)
        
        # Sync rules mapping
        self.sync_rules = {
            # Event log -> Execution graph
            ("event_log", "scaffold.completed"): self._sync_scaffold_to_execution,
            ("event_log", "scan.completed"): self._sync_scan_to_execution,
            ("event_log", "intent.created"): self._sync_intent_to_execution,
            
            # Event log -> Intent graph (reverse linking)
            ("event_log", "scaffold.completed"): self._sync_scaffold_to_intent,
            ("event_log", "manifest.updated"): self._sync_manifest_to_intent,
            
            # Event log -> Manifest graph (file watching)
            ("event_log", "file.created"): self._sync_file_to_manifest,
            ("event_log", "file.deleted"): self._sync_file_deletion_to_manifest,
        }
    
    def process_event_log_entries(self, limit: int = 100) -> List[GraphSyncEvent]:
        """Process recent event log entries and generate sync events."""
        sync_events = []
        
        # Get recent events from event log
        recent_events = self.event_log.get_recent_events(limit)
        
        for event in recent_events:
            # Generate sync events based on event type
            sync_actions = self._determine_sync_actions(event)
            
            if sync_actions:
                sync_event = GraphSyncEvent(
                    source_graph="event_log",
                    event_type=event.event_type.value,
                    entity_id=event.id,
                    entity_data=event.data,
                    sync_actions=sync_actions
                )
                sync_events.append(sync_event)
        
        return sync_events
    
    def _determine_sync_actions(self, event: EventEntry) -> List[str]:
        """Determine what sync actions should be triggered by an event."""
        actions = []
        event_type = event.event_type.value
        
        # Scaffold completion triggers multiple sync actions
        if event_type == "scaffold.completed":
            actions.extend([
                "sync_to_execution_graph",
                "reverse_link_to_intent",
                "update_manifest_stats"
            ])
        
        # Scan completion triggers execution sync
        elif event_type == "scan.completed":
            actions.append("sync_to_execution_graph")
        
        # Intent creation triggers execution sync
        elif event_type == "intent.created":
            actions.append("sync_to_execution_graph")
        
        # Manifest updates trigger intent sync
        elif event_type == "manifest.updated":
            actions.append("sync_to_intent_graph")
        
        return actions
    
    def execute_sync(self, sync_event: GraphSyncEvent) -> bool:
        """Execute a synchronization event."""
        success = True
        
        for action in sync_event.sync_actions:
            try:
                if action == "sync_to_execution_graph":
                    success &= self._sync_to_execution_graph(sync_event)
                elif action == "reverse_link_to_intent":
                    success &= self._reverse_link_to_intent(sync_event)
                elif action == "update_manifest_stats":
                    success &= self._update_manifest_stats(sync_event)
                elif action == "sync_to_intent_graph":
                    success &= self._sync_to_intent_graph(sync_event)
                else:
                    logger.warning(f"Unknown sync action: {action}")
                    success = False
            except Exception as e:
                logger.error(f"Failed to execute sync action {action}: {e}")
                success = False
        
        return success
    
    def _sync_to_execution_graph(self, sync_event: GraphSyncEvent) -> bool:
        """Sync event to execution graph."""
        try:
            event_type = sync_event.event_type
            entity_data = sync_event.entity_data
            
            if event_type == "scaffold.completed":
                # Scaffold results already persisted via auto-append
                # This ensures execution graph has the scaffold trace
                return True
            
            elif event_type == "scan.completed":
                # Scan results already persisted via auto-append
                return True
            
            elif event_type == "intent.created":
                # Intent creation events
                return persist_execution_result(
                    operation_type="intent_created",
                    project_path=str(self.project_path),
                    data=entity_data,
                    operation_id=sync_event.entity_id
                ) is not None
            
            return True
        except Exception as e:
            logger.error(f"Failed to sync to execution graph: {e}")
            return False
    
    def _reverse_link_to_intent(self, sync_event: GraphSyncEvent) -> bool:
        """Create reverse links from scaffold results to originating intents."""
        try:
            if sync_event.event_type != "scaffold.completed":
                return True
            
            entity_data = sync_event.entity_data
            
            # Check if scaffold was created from an intent
            intent_id = entity_data.get("intent_id")
            node_id = entity_data.get("node_id")
            
            if intent_id and node_id:
                # This would update the intent record to add an "implements" edge
                # For now, we'll log this action
                logger.info(f"Would create reverse link: intent {intent_id} implements node {node_id}")
                return True
            
            return True
        except Exception as e:
            logger.error(f"Failed to create reverse link to intent: {e}")
            return False
    
    def _update_manifest_stats(self, sync_event: GraphSyncEvent) -> bool:
        """Update manifest statistics after scaffold completion."""
        try:
            # This would update manifest statistics
            # For now, we'll log this action
            logger.info(f"Would update manifest stats for: {sync_event.entity_data}")
            return True
        except Exception as e:
            logger.error(f"Failed to update manifest stats: {e}")
            return False
    
    def _sync_to_intent_graph(self, sync_event: GraphSyncEvent) -> bool:
        """Sync manifest updates to intent graph."""
        try:
            if sync_event.event_type != "manifest.updated":
                return True
            
            # This would update related intent records
            logger.info(f"Would sync manifest update to intent graph: {sync_event.entity_data}")
            return True
        except Exception as e:
            logger.error(f"Failed to sync to intent graph: {e}")
            return False
    
    def _sync_scaffold_to_execution(self, sync_event: GraphSyncEvent) -> bool:
        """Sync scaffold completion to execution graph."""
        return self._sync_to_execution_graph(sync_event)
    
    def _sync_scan_to_execution(self, sync_event: GraphSyncEvent) -> bool:
        """Sync scan completion to execution graph."""
        return self._sync_to_execution_graph(sync_event)
    
    def _sync_intent_to_execution(self, sync_event: GraphSyncEvent) -> bool:
        """Sync intent creation to execution graph."""
        return self._sync_to_execution_graph(sync_event)
    
    def _sync_scaffold_to_intent(self, sync_event: GraphSyncEvent) -> bool:
        """Sync scaffold completion to intent graph (reverse linking)."""
        return self._reverse_link_to_intent(sync_event)
    
    def _sync_manifest_to_intent(self, sync_event: GraphSyncEvent) -> bool:
        """Sync manifest updates to intent graph."""
        return self._sync_to_intent_graph(sync_event)
    
    def _sync_file_to_manifest(self, sync_event: GraphSyncEvent) -> bool:
        """Sync file creation to manifest graph (auto-registration)."""
        try:
            # This would auto-register new files in the manifest
            logger.info(f"Would auto-register file in manifest: {sync_event.entity_data}")
            return True
        except Exception as e:
            logger.error(f"Failed to sync file to manifest: {e}")
            return False
    
    def _sync_file_deletion_to_manifest(self, sync_event: GraphSyncEvent) -> bool:
        """Sync file deletion to manifest graph (orphan detection)."""
        try:
            # This would mark deleted nodes as orphaned in the manifest
            logger.info(f"Would mark file as orphaned in manifest: {sync_event.entity_data}")
            return True
        except Exception as e:
            logger.error(f"Failed to sync file deletion to manifest: {e}")
            return False
    
    def _determine_sync_actions_for_event_type(self, event_type: str) -> List[str]:
        """Determine sync actions for a specific event type."""
        actions = []
        
        if event_type == "scaffold.completed":
            actions.extend([
                "sync_to_execution_graph",
                "reverse_link_to_intent", 
                "update_manifest_stats"
            ])
        elif event_type == "scan.completed":
            actions.append("sync_to_execution_graph")
        elif event_type == "intent.created":
            actions.append("sync_to_execution_graph")
        elif event_type == "manifest.updated":
            actions.append("sync_to_intent_graph")
        
        return actions
    
    def run_sync_cycle(self) -> Dict[str, Any]:
        """Run a complete synchronization cycle."""
        start_time = time.time()
        
        try:
            # Process event log entries
            sync_events = self.process_event_log_entries()
            
            # Execute sync events
            results = []
            for sync_event in sync_events:
                success = self.execute_sync(sync_event)
                results.append({
                    "sync_event_id": sync_event.entity_id,
                    "success": success,
                    "actions": sync_event.sync_actions
                })
            
            duration_ms = int((time.time() - start_time) * 1000)
            
            return {
                "status": "completed",
                "duration_ms": duration_ms,
                "events_processed": len(sync_events),
                "results": results,
                "success_count": sum(1 for r in results if r["success"]),
                "failure_count": sum(1 for r in results if not r["success"])
            }
            
        except Exception as e:
            logger.error(f"Sync cycle failed: {e}")
            return {
                "status": "failed",
                "error": str(e),
                "duration_ms": int((time.time() - start_time) * 1000)
            }


# Global synchronizer instances
_synchronizers: Dict[str, GraphSynchronizer] = {}


def get_graph_synchronizer(project_path: Path) -> GraphSynchronizer:
    """Get or create a graph synchronizer for a project."""
    project_key = str(project_path.resolve())
    if project_key not in _synchronizers:
        _synchronizers[project_key] = GraphSynchronizer(project_path)
    return _synchronizers[project_key]


def run_graph_sync(project_path: str) -> Dict[str, Any]:
    """Run graph synchronization for a project."""
    synchronizer = get_graph_synchronizer(Path(project_path))
    return synchronizer.run_sync_cycle()


def trigger_sync_from_event(event_type: str, entity_data: Dict[str, Any], project_path: str) -> bool:
    """Trigger immediate sync from a specific event."""
    try:
        synchronizer = get_graph_synchronizer(Path(project_path))
        
        # Create a sync event
        sync_event = GraphSyncEvent(
            source_graph="event_log",
            event_type=event_type,
            entity_id=entity_data.get("id", "unknown"),
            entity_data=entity_data
        )
        
        # Determine sync actions
        sync_event.sync_actions = synchronizer._determine_sync_actions_for_event_type(event_type)
        
        # Execute sync
        return synchronizer.execute_sync(sync_event)
        
    except Exception as e:
        logger.error(f"Failed to trigger sync from event: {e}")
        return False


__all__ = [
    "GraphSyncEvent",
    "GraphSynchronizer", 
    "get_graph_synchronizer",
    "run_graph_sync",
    "trigger_sync_from_event"
]
