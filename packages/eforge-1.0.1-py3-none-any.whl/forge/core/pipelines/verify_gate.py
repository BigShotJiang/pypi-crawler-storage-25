from forge.core.schemas import PipelineDescriptor, PipelineStep, PipelineStepKind

VERIFY_GATE_PIPELINE = PipelineDescriptor(
    pipeline_id="pipeline/verify_gate",
    name="verify_gate",
    description="Run forge_verify and gate on result — blocks if failures exist",
    steps=[
        PipelineStep(
            step="step_verify",
            kind=PipelineStepKind.TOOL,
            tool="forge_verify",
            params=["response_tier=L1"],
        ),
        PipelineStep(
            step="step_gate",
            kind=PipelineStepKind.CONDITION,
            condition_field="exit_code",
            condition_value="0",
            gate=True,
        ),
    ]
)
