from __future__ import annotations

import json
import sys
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from types import FrameType
from typing import Any, Callable, Dict, List, Optional
from uuid import uuid4


@dataclass
class ExecutionNode:
    id: str
    kind: str
    module: str
    qualname: str
    file: str
    line: int
    call_count: int = 0
    stack: str = "python"
    layer: str = "execution"


@dataclass
class ExecutionEdge:
    id: str
    from_id: str
    to_id: str
    edge_kind: str = "calls"
    call_count: int = 0
    layer: str = "execution"


@dataclass
class ExecutionResult:
    """Persistent execution result for audit, scan, verification operations."""
    id: str = field(default_factory=lambda: str(uuid4()))
    operation_type: str = ""  # "audit_scan", "verify", "impact_check", etc.
    operation_id: Optional[str] = None  # Link to originating operation
    project_path: str = ""
    timestamp: float = field(default_factory=time.time)
    iso_timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    status: str = "completed"  # "completed", "failed", "partial"
    duration_ms: Optional[int] = None
    exit_code: Optional[int] = None
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ExecutionGraph:
    nodes: dict[str, ExecutionNode] = field(default_factory=dict)
    edges: dict[str, ExecutionEdge] = field(default_factory=dict)
    results: dict[str, ExecutionResult] = field(default_factory=dict)
    trace_start: float = field(default_factory=time.time)
    trace_end: float | None = None
    entry_point: str | None = None

    def add_call(self, caller_frame: FrameType | None, callee_frame: FrameType) -> None:
        if caller_frame is None:
            return
        callee = _frame_to_node(callee_frame)
        caller = _frame_to_node(caller_frame)
        if callee is None or caller is None:
            return
        for n in (caller, callee):
            if n.id in self.nodes:
                self.nodes[n.id].call_count += 1
            else:
                self.nodes[n.id] = n
        edge_id = f"{caller.id}->{callee.id}"
        if edge_id not in self.edges:
            self.edges[edge_id] = ExecutionEdge(
                id=edge_id,
                from_id=caller.id,
                to_id=callee.id,
                edge_kind="calls",
                call_count=1,
            )
        else:
            self.edges[edge_id].call_count += 1

    def to_raw(self) -> tuple[list[Any], list[Any]]:
        from forge.core.gloves import RawEdge, RawNode

        nodes_out: list[RawNode] = []
        for n in self.nodes.values():
            nodes_out.append(
                RawNode(
                    id=n.id,
                    kind=n.kind,
                    stack=n.stack,
                    domain="CORE",
                    name=n.qualname,
                    file=n.file,
                    line=n.line,
                    status={"declared": False, "implemented": True, "reachable": None, "intended": None},
                )
            )
        edges_out: list[RawEdge] = []
        for e in self.edges.values():
            edges_out.append(
                RawEdge(
                    id=e.id,
                    from_id=e.from_id,
                    to_id=e.to_id,
                    edge_kind=e.edge_kind,
                    stack="python",
                    layer="execution",
                    source="execution_trace",
                )
            )
        return nodes_out, edges_out

    def add_result(self, result: ExecutionResult) -> None:
        """Add an execution result to the graph."""
        self.results[result.id] = result
    
    def get_result(self, result_id: str) -> Optional[ExecutionResult]:
        """Get an execution result by ID."""
        return self.results.get(result_id)
    
    def get_results_by_operation(self, operation_type: str, project_path: Optional[str] = None) -> List[ExecutionResult]:
        """Get results by operation type, optionally filtered by project path."""
        results = []
        for result in self.results.values():
            if result.operation_type == operation_type:
                if project_path is None or result.project_path == project_path:
                    results.append(result)
        # Sort by timestamp (newest first)
        results.sort(key=lambda r: r.timestamp, reverse=True)
        return results
    
    def get_recent_results(self, limit: int = 50, project_path: Optional[str] = None) -> List[ExecutionResult]:
        """Get recent execution results, optionally filtered by project path."""
        results = list(self.results.values())
        if project_path:
            results = [r for r in results if r.project_path == project_path]
        # Sort by timestamp (newest first) and limit
        results.sort(key=lambda r: r.timestamp, reverse=True)
        return results[:limit]
    
    def to_trace_yaml_dict(self) -> dict[str, Any]:
        return {
            "trace": {
                "entry_point": self.entry_point,
                "captured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(self.trace_start)),
                "duration_seconds": (self.trace_end or time.time()) - self.trace_start,
                "nodes": [asdict(n) for n in self.nodes.values()],
                "edges": [asdict(e) for e in self.edges.values()],
            }
        }
    
    def to_results_dict(self) -> dict[str, Any]:
        """Convert execution results to dictionary format."""
        return {
            "results": [asdict(r) for r in self.results.values()],
            "total_count": len(self.results),
            "last_updated": time.time()
        }


def _frame_to_node(frame: FrameType) -> ExecutionNode | None:
    code = frame.f_code
    mod = frame.f_globals.get("__name__", "")
    qual = getattr(code, "co_qualname", code.co_name)
    path = str(code.co_filename or "")
    line = int(code.co_firstlineno)
    node_id = f"{mod}.{qual}" if mod else qual
    kind = "function"
    if "." in qual:
        kind = "method"
    return ExecutionNode(
        id=node_id,
        kind=kind,
        module=str(mod),
        qualname=str(qual),
        file=path,
        line=line,
        call_count=1,
    )


class TraceHandle:
    def __init__(
        self,
        graph: ExecutionGraph,
        project_path: Path,
        scope_module: str | None = None,
    ) -> None:
        self._graph = graph
        self._project_path = project_path.expanduser().resolve()
        self._scope_module = scope_module.strip() if scope_module else None
        self._active = False
        self._prev_trace: Callable[..., Any] | None = None

    def start(self) -> None:
        self._prev_trace = sys.gettrace()
        self._active = True
        sys.settrace(self._trace_fn)

    def stop(self) -> ExecutionGraph:
        sys.settrace(self._prev_trace)  # type: ignore[arg-type]
        self._active = False
        self._graph.trace_end = time.time()
        return self._graph

    def _project_under(self, path: Path) -> bool:
        try:
            path.resolve().relative_to(self._project_path)
            return True
        except ValueError:
            return False

    def _should_trace_file(self, path_str: str) -> bool:
        if not path_str or "<" in path_str:
            return False
        norm = path_str.replace("\\", "/")
        if "/lib/python" in norm or "site-packages" in norm:
            return False
        try:
            p = Path(path_str).resolve()
        except OSError:
            return False
        if not p.is_file():
            return False
        return self._project_under(p)

    def _trace_fn(self, frame: FrameType, event: str, arg: Any) -> Callable[..., Any] | None:  # noqa: ANN401
        if not self._active:
            return None
        if event != "call":
            return self._trace_fn
        callee = frame
        caller = frame.f_back
        if caller is None:
            return self._trace_fn
        callee_file = callee.f_code.co_filename
        caller_file = caller.f_code.co_filename
        if not self._should_trace_file(callee_file) or not self._should_trace_file(caller_file):
            return self._trace_fn
        if self._scope_module:
            cm = str(callee.f_globals.get("__name__", ""))
            pm = str(caller.f_globals.get("__name__", ""))
            sc = self._scope_module

            def _under(m: str) -> bool:
                return m == sc or m.startswith(sc + ".")

            if not (_under(cm) and _under(pm)):
                return self._trace_fn
        self._graph.add_call(caller, callee)
        return self._trace_fn


class ExecutionGraphManager:
    """Manages persistent execution graph storage and retrieval."""
    
    def __init__(self, project_path: Path):
        self.project_path = project_path
        self.execution_dir = project_path / ".forge" / "execution"
        self.execution_dir.mkdir(parents=True, exist_ok=True)
        self.results_file = self.execution_dir / "results.jsonl"
        self.graph_file = self.execution_dir / "graph.json"
    
    def save_result(self, result: ExecutionResult) -> None:
        """Save an execution result to persistent storage."""
        try:
            with open(self.results_file, 'a') as f:
                f.write(json.dumps(asdict(result)) + '\n')
        except Exception as e:
            print(f"Failed to save execution result: {e}")
    
    def load_results(self, project_path: Optional[str] = None) -> List[ExecutionResult]:
        """Load execution results from persistent storage."""
        results = []
        try:
            if not self.results_file.exists():
                return results
            
            with open(self.results_file, 'r') as f:
                for line in f:
                    try:
                        data = json.loads(line.strip())
                        if project_path is None or data.get("project_path") == project_path:
                            results.append(ExecutionResult(**data))
                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            print(f"Failed to load execution results: {e}")
        
        return results
    
    def get_recent_results(self, limit: int = 50, project_path: Optional[str] = None) -> List[ExecutionResult]:
        """Get recent execution results."""
        results = self.load_results(project_path)
        results.sort(key=lambda r: r.timestamp, reverse=True)
        return results[:limit]
    
    def get_results_by_operation(self, operation_type: str, project_path: Optional[str] = None) -> List[ExecutionResult]:
        """Get results by operation type."""
        results = self.load_results(project_path)
        filtered = [r for r in results if r.operation_type == operation_type]
        filtered.sort(key=lambda r: r.timestamp, reverse=True)
        return filtered
    
    def save_graph_snapshot(self, graph: ExecutionGraph) -> None:
        """Save a snapshot of the execution graph."""
        try:
            graph_data = {
                "timestamp": time.time(),
                "project_path": str(self.project_path),
                "nodes": [asdict(n) for n in graph.nodes.values()],
                "edges": [asdict(e) for e in graph.edges.values()],
                "results_count": len(graph.results)
            }
            with open(self.graph_file, 'w') as f:
                json.dump(graph_data, f, indent=2)
        except Exception as e:
            print(f"Failed to save graph snapshot: {e}")
    
    def load_graph_snapshot(self) -> Optional[Dict[str, Any]]:
        """Load the most recent graph snapshot."""
        try:
            if not self.graph_file.exists():
                return None
            with open(self.graph_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Failed to load graph snapshot: {e}")
            return None


# Global execution graph manager
_execution_managers: Dict[str, ExecutionGraphManager] = {}


def get_execution_manager(project_path: Path) -> ExecutionGraphManager:
    """Get or create an execution graph manager for a project."""
    project_key = str(project_path.resolve())
    if project_key not in _execution_managers:
        _execution_managers[project_key] = ExecutionGraphManager(project_path)
    return _execution_managers[project_key]


def persist_execution_result(
    operation_type: str,
    project_path: str,
    data: Dict[str, Any],
    operation_id: Optional[str] = None,
    status: str = "completed",
    duration_ms: Optional[int] = None,
    exit_code: Optional[int] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> str:
    """Persist an execution result and return its ID."""
    result = ExecutionResult(
        operation_type=operation_type,
        operation_id=operation_id,
        project_path=project_path,
        status=status,
        duration_ms=duration_ms,
        exit_code=exit_code,
        data=data,
        metadata=metadata or {}
    )
    
    manager = get_execution_manager(Path(project_path))
    manager.save_result(result)
    
    return result.id


__all__ = [
    "ExecutionNode",
    "ExecutionEdge", 
    "ExecutionResult",
    "ExecutionGraph",
    "TraceHandle",
    "ExecutionGraphManager",
    "get_execution_manager",
    "persist_execution_result"
]
