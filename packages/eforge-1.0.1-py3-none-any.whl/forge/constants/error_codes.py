# GENERATED FILE — do not edit manually.
# Regenerate with: forge scaffold --entry-type error_codes --refresh error_codes

ERROR_CODES = {
  "CORE-001": {
    "message": "Internal error — run with --debug for details",
    "hint": "Please report this issue at github.com/forge-org/forge/issues with the full error output from --debug flag"
  },
  "CORE-002": {
    "message": "Validation failed",
    "hint": "Check your input format and required fields. Run with --debug for detailed validation errors"
  },
  "CORE-003": {
    "message": "Configuration missing",
    "hint": "Run 'forge init' to create missing configuration files, or check your .forge/ directory"
  },
  "CORE-004": {
    "message": "Unsupported operation",
    "hint": "This operation is not supported for your current project type or configuration"
  },
  "CORE-005": {
    "message": "Resource not found",
    "hint": "Check if the resource path is correct and the file exists"
  },
  "AUTH-001": {
    "message": "Authentication failed",
    "hint": "Check your credentials or run 'forge auth init' to configure authentication"
  },
  "AUTH-002": {
    "message": "Invalid credentials",
    "hint": "Run 'forge auth init' to update your credentials or check your ~/.forge/credentials file"
  },
  "AUTH-003": {
    "message": "Session expired",
    "hint": "Run 'forge auth refresh' to renew your session or authenticate again"
  },
  "AUTH-004": {
    "message": "Account locked",
    "hint": "Contact support or check your account status online"
  },
  "AUTH-005": {
    "message": "MFA required",
    "hint": "Complete multi-factor authentication and try again"
  },
  "REMOTE-001": {
    "message": "Remote service unavailable",
    "hint": "Check your internet connection and try again in a few minutes"
  },
  "REMOTE-002": {
    "message": "Request timed out",
    "hint": "Try again with a longer timeout or check your network connection"
  },
  "REMOTE-003": {
    "message": "Remote authentication failed",
    "hint": "Check your remote service credentials and permissions"
  },
  "REMOTE-004": {
    "message": "Remote response invalid",
    "hint": "The remote service returned an unexpected response. Try again or contact support"
  },
  "REMOTE-005": {
    "message": "Remote rate limit exceeded",
    "hint": "Wait a few minutes before trying again, or check if you need API rate limit increases"
  },
  "PREMIUM-001": {
    "message": "Premium feature locked",
    "hint": "Upgrade to a premium plan to access this feature"
  },
  "PREMIUM-002": {
    "message": "Subscription required",
    "hint": "Subscribe to a plan to access this feature"
  },
  "PREMIUM-003": {
    "message": "Subscription expired",
    "hint": "Renew your subscription to continue using premium features"
  },
  "PREMIUM-004": {
    "message": "Billing validation failed",
    "hint": "Update your billing information or contact support"
  },
  "PREMIUM-005": {
    "message": "Premium entitlement missing",
    "hint": "Your current plan doesn't include this feature. Upgrade your subscription"
  }
}

# Special error codes with specific Forge guidance
FORGE_ERROR_HINTS = {
  "ERR-002": {
    "message": "No project found",
    "hint": "Run 'forge init <path>' or pass --project-path explicitly to specify the project location"
  },
  "ERR-001": {
    "message": "Internal error",
    "hint": "Run with --debug for details. Please report at github.com/forge-org/forge/issues"
  }
}
