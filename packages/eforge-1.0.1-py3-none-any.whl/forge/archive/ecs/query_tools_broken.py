"""Query and intent tool handlers for Forge MCP.

Includes graph querying, intent management, and related functionality.
"""

from __future__ import annotations

from typing import Any

import mcp.types as types
from forge.mcp.handlers.error_handlers import (
    make_tool_result,
    forge_error_result,
    handle_unhandled_exception,
    handle_validation_error,
)
from forge.mcp.handlers.validation import (
    validate_project_path,
    validate_project_id,
)


async def handle_forge_intent(arguments: dict[str, Any]) -> types.CallToolResult:
    """
    Intent management for Forge projects.
    
    Priority: P3 - Query functionality
    """
    try:
        project_path = arguments.get("project_path", "")
        if not project_path:
            return handle_validation_error(
                "project_path",
                "project_path is required",
                {"available_arguments": ["project_path"]}
            )
        
        path = validate_project_path(project_path)
        
        # Validate action parameter
        action = arguments.get("action", "")
        if not action:
            return handle_validation_error(
                "action",
                "action is required",
                {"available_actions": ["add", "query", "show", "update", "specify"]}
            )
        
        # Route to specific intent operations
        if action == "add":
            return await _handle_intent_add(arguments, path)
        elif action == "query":
            return await _handle_intent_query(arguments, path)
        elif action == "show":
            return await _handle_intent_show(arguments, path)
        elif action == "update":
            return await _handle_intent_update(arguments, path)
        elif action == "specify":
            return await _handle_intent_specify(arguments, path)
        elif action == "list":
            return await _handle_intent_list(arguments, path)
        else:
            return handle_validation_error(
                "action",
                f"Invalid action: {action}",
                {"available_actions": ["add", "query", "show", "update", "specify", "list"]}
            )
        
    except ValueError as e:
        return handle_validation_error(
            "action" if "action" in str(e) else "project_path",
            str(e),
            {
                "project_path": arguments.get("project_path", ""),
                "action": arguments.get("action"),
            }
        )
    except Exception as e:
        return handle_unhandled_exception(
            "forge_intent",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "action": arguments.get("action"),
            }
        )


async def _handle_intent_add(arguments: dict[str, Any], project_path) -> types.CallToolResult:
    """Handle intent addition."""
    try:
        # Import intent functionality
        try:
            from forge.mcp.thin_core import execute_intent_add
        except ImportError as e:
            from forge.core.errors import ERRORS
            error = ERRORS["dependency_unavailable"].copy()
            error.context.update({
                "missing_dependency": "forge.mcp.thin_core",
                "import_error": str(e),
            })
            return forge_error_result(error)
        
        result = execute_intent_add(arguments)
        return make_tool_result(
            json.dumps(result, indent=2),
            forge.core.schemas.IntentResult,
            structured_data=result
        )
    except Exception as e:
        return handle_unhandled_exception(
            "intent_add",
            e,
            {"project_path": str(project_path)}
        )


async def _handle_intent_query(arguments: dict[str, Any], project_path) -> types.CallToolResult:
    """Handle intent query."""
    try:
        # Import intent functionality
        try:
            from forge.mcp.thin_core import execute_intent_query
        except ImportError as e:
            from forge.core.errors import ERRORS
            error = ERRORS["dependency_unavailable"].copy()
            error.context.update({
                "missing_dependency": "forge.mcp.thin_core",
                "import_error": str(e),
            })
            return forge_error_result(error)
        
        result = execute_intent_query(arguments)
        return make_tool_result(
            json.dumps(result, indent=2),
            forge.core.schemas.IntentResult,
            structured_data=result
        )
    except Exception as e:
        return handle_unhandled_exception(
            "intent_query",
            e,
            {"project_path": str(project_path)}
        )


async def _handle_intent_show(arguments: dict[str, Any], project_path) -> types.CallToolResult:
    """Handle intent show operation."""
    try:
        record_id = arguments.get("record_id")
        if not record_id:
            return handle_validation_error(
                "record_id",
                "record_id is required",
                {"available_parameters": ["record_id"]}
            )
        
        # Import intent functionality
        try:
            from forge.mcp.thin_core import execute_intent_show
        except ImportError as e:
            from forge.core.errors import ERRORS
            error = ERRORS["dependency_unavailable"].copy()
            error.context.update({
                "missing_dependency": "forge.mcp.thin_core",
                "import_error": str(e),
            })
            return forge_error_result(error)
        
        result = execute_intent_show({
            **arguments,
            "record_id": record_id,
        })
        return make_tool_result(
            json.dumps(result, indent=2),
            forge.core.schemas.IntentResult,
            structured_data=result
        )
    except ValueError as e:
        return handle_validation_error(
            "record_id",
            str(e),
            {
                "project_path": str(project_path),
                "record_id": arguments.get("record_id"),
            }
        )
    except Exception as e:
        return handle_unhandled_exception(
            "intent_show",
            e,
            {
                "project_path": str(project_path),
                "record_id": arguments.get("record_id"),
            }
        )


async def _handle_intent_update(arguments: dict[str, Any], project_path) -> types.CallToolResult:
    """Handle intent update operation."""
    try:
        record_id = arguments.get("record_id")
        if not record_id:
            return handle_validation_error(
                "record_id",
                "record_id is required",
                {"available_parameters": ["record_id"]}
            )
        
        # Import intent functionality
        try:
            from forge.mcp.thin_core import execute_intent_update
        except ImportError as e:
            from forge.core.errors import ERRORS
            error = ERRORS["dependency_unavailable"].copy()
            error.context.update({
                "missing_dependency": "forge.mcp.thin_core",
                "import_error": str(e),
            })
            return forge_error_result(error)
        
        result = execute_intent_update({
            **arguments,
            "record_id": record_id,
        })
        return make_tool_result(
            json.dumps(result, indent=2),
            forge.core.schemas.IntentResult,
            structured_data=result
        )
    except ValueError as e:
        return handle_validation_error(
            "record_id",
            str(e),
            {
                "project_path": str(project_path),
                "record_id": arguments.get("record_id"),
            }
        )
    except Exception as e:
        return handle_unhandled_exception(
            "intent_update",
            e,
            {
                "project_path": str(project_path),
                "record_id": arguments.get("record_id"),
            }
        )


async def _handle_intent_specify(arguments: dict[str, Any], project_path) -> types.CallToolResult:
    """Handle intent specify operation."""
    try:
        # Import intent functionality
        try:
            from forge.mcp.thin_core import execute_intent_specify
        except ImportError as e:
            from forge.core.errors import ERRORS
            error = ERRORS["dependency_unavailable"].copy()
            error.context.update({
                "missing_dependency": "forge.mcp.thin_core",
                "import_error": str(e),
            })
            return forge_error_result(error)
        
        result = execute_intent_specify(arguments)
        return make_tool_result(
            json.dumps(result, indent=2),
            forge.core.schemas.IntentResult,
            structured_data=result
        )
    except Exception as e:
        return handle_unhandled_exception(
            "intent_specify",
            e,
            {"project_path": str(project_path)}
        )


async def _handle_intent_list(arguments: dict[str, Any], project_path) -> types.CallToolResult:
    """Handle intent list operation."""
    try:
        # Import intent functionality
            from forge.mcp.thin_core import execute_intent_list
        except ImportError as e:
            from forge.core.errors import ERRORS
            error = ERRORS["dependency_unavailable"].copy()
            error.context.update({
                "missing_dependency": "forge.mcp.thin_core",
                "import_error": str(e),
            })
            return forge_error_result(error)
        
        result = execute_intent_list(arguments)
        
        return make_tool_result(
            json.dumps(result, indent=2),
            forge.core.schemas.IntentResult,
            structured_data=result
        )
        
    except Exception as e:
        return handle_unhandled_exception(
            "intent_specify",
            e,
            {"project_path": str(project_path)}
        )


async def _handle_intent_list(arguments: dict[str, Any], project_path) -> types.CallToolResult:
    """Handle intent list operation."""
    try:
        # Import intent functionality
        from forge.mcp.thin_core import execute_intent_list
        
        result = execute_intent_list(arguments)
        
        return make_tool_result(
            json.dumps(result, indent=2),
            forge.core.schemas.IntentResult,
            structured_data=result
        )
        
    except Exception as e:
        return handle_unhandled_exception(
            "intent_list",
            e,
            {"project_path": str(project_path)}
        )
