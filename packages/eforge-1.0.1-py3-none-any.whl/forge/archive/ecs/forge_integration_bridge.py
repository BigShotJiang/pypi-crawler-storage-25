"""
Forge Integration Bridge - Connects the new game system with existing Forge architecture.
Bridges Unity-inspired components with Forge's existing schemas, contracts, and protocols.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Type, Union
from pathlib import Path

from forge.core.forge_project_system import (
    ForgeGame, ForgeEntity, ForgeComponent, ForgeSystem,
    NodeComponent, TierComponent, ManifestComponent, ContractComponent,
    HealthComponent, ChangeComponent, AnnotationComponent, PipelineComponent, ErrorComponent,
    GameScope, get_registry
)
from forge.core.schemas import (
    NodeTier, NodeStatus, ChangeClass, ResponseTier
)
from forge.core.forge_project_system import ContractStatus
from forge.tools.manifest.graph import ManifestGraph, ManifestEdge, build_manifest_graph
from forge.protocols.glove import GloveProtocol
from forge.protocols.checker import CheckerProtocol
from forge.protocols.subscriber import SubscriberProtocol
from forge.protocols.renderer import RendererProtocol


class ForgeIntegrationBridge:
    """
    Bridge between new project system and existing Forge architecture.
    Converts between component-based and traditional Forge structures.
    """
    
    def __init__(self, project: ForgeProject):
        self.project = project
        self._manifest_graph: Optional[ManifestGraph] = None
        self._protocol_adapters: Dict[str, Any] = {}
    
    # === MANIFEST INTEGRATION ===
    
    def load_manifest_graph(self, manifest_path: Optional[Path] = None) -> ManifestGraph:
        """Load manifest graph and convert to entities."""
        if manifest_path is None:
            manifest_path = self.project.root_path / ".forge" / "manifest.yaml"
        
        self._manifest_graph = build_manifest_graph(str(manifest_path), str(self.project.root_path))
        self._convert_manifest_to_entities()
        return self._manifest_graph
    
    def _convert_manifest_to_entities(self):
        """Convert manifest nodes to project entities."""
        if not self._manifest_graph:
            return
        
        for manifest_node in self._manifest_graph.nodes:
            entity = self._create_entity_from_manifest_node(manifest_node)
            self.project.add_entity(entity)
    
    def _create_entity_from_manifest_node(self, manifest_node: ManifestNode) -> ForgeEntity:
        """Create a project entity from a manifest node."""
        entity = ForgeEntity(
            id=manifest_node.id,
            kind=manifest_node.kind
        )
        
        # Add core node component
        node_comp = NodeComponent(
            node_id=manifest_node.id,
            node_kind=manifest_node.kind,
            domain=manifest_node.domain or "",
            tier=NodeTier(manifest_node.meta.get("tier", "worker")),
            path=manifest_node.path or "",
            status=NodeStatus.IMPLEMENTED if manifest_node.status == "implemented" else NodeStatus.DECLARED
        )
        entity.add_component(node_comp)
        
        # Add tier component
        tier_comp = TierComponent(tier=node_comp.tier)
        entity.add_component(tier_comp)
        
        # Add manifest component
        manifest_comp = ManifestComponent(
            manifest_path=manifest_node.path or "",
            auto_sync=True
        )
        entity.add_component(manifest_comp)
        
        # Add health component
        health_comp = HealthComponent()
        entity.add_component(health_comp)
        
        # Add change tracking component
        change_comp = ChangeComponent()
        entity.add_component(change_comp)
        
        return entity
    
    def entities_to_manifest_graph(self) -> ManifestGraph:
        """Convert game entities back to manifest graph."""
        if not self._manifest_graph:
            self._manifest_graph = ManifestGraph()
        
        # Clear existing nodes
        self._manifest_graph.nodes.clear()
        self._manifest_graph.edges.clear()
        
        # Convert entities to manifest nodes
        for entity in self.game._entities.values():
            manifest_node = self._entity_to_manifest_node(entity)
            self._manifest_graph.nodes.append(manifest_node)
        
        return self._manifest_graph
    
    def _entity_to_manifest_node(self, entity: ForgeEntity) -> ManifestNode:
        """Convert a game entity to a manifest node."""
        node_comp = entity.get_component(NodeComponent)
        if not node_comp:
            # Create basic node if no node component
            return ManifestNode(
                id=entity.id,
                kind=entity.kind,
                name=entity.id.split("/")[-1],
                path="",
                domain="",
                parent_id=None
            )
        
        return ManifestNode(
            id=node_comp.node_id,
            kind=node_comp.node_kind,
            name=node_comp.node_id.split("/")[-1],
            path=node_comp.path,
            domain=node_comp.domain,
            parent_id=None,
            status="implemented" if node_comp.status == NodeStatus.IMPLEMENTED else "declared",
            meta={"tier": node_comp.tier.value}
        )
    
    # === SCHEMA INTEGRATION ===
    
    def apply_schema_validation(self):
        """Apply Forge schema validation to all entities."""
        for entity in self.game._entities.values():
            self._validate_entity_schemas(entity)
    
    def _validate_entity_schemas(self, entity: ForgeEntity):
        """Validate a single entity against Forge schemas."""
        node_comp = entity.get_component(NodeComponent)
        if node_comp:
            # Validate node kind
            if node_comp.node_kind not in MANIFEST_NODE_KINDS:
                error_comp = entity.get_component(ErrorComponent)
                if not error_comp:
                    error_comp = ErrorComponent()
                    entity.add_component(error_comp)
                
                error_comp.add_error({
                    "domain": ErrorDomain.MANIFEST,
                    "message": f"Invalid node kind: {node_comp.node_kind}",
                    "severity": SeverityLevel.ERROR
                })
        
        # Validate other components
        tier_comp = entity.get_component(TierComponent)
        if tier_comp and tier_comp.import_violations:
            error_comp = entity.get_component(ErrorComponent)
            if not error_comp:
                error_comp = ErrorComponent()
                entity.add_component(error_comp)
            
            for violation in tier_comp.import_violations:
                error_comp.add_error({
                    "domain": ErrorDomain.VERIFY,
                    "message": f"Tier import violation: {violation}",
                    "severity": SeverityLevel.ERROR
                })
    
    # === PROTOCOL INTEGRATION ===
    
    def register_glove_protocol(self, glove: GloveProtocol) -> str:
        """Register a glove protocol as a system."""
        adapter = GloveProtocolAdapter(glove, self.project)
        self._protocol_adapters[f"glove_{glove.stack}"] = adapter
        self.project.add_system(adapter)
        return f"glove_{glove.stack}"
    
    def register_checker_protocol(self, checker: CheckerProtocol) -> str:
        """Register a checker protocol as a system."""
        adapter = CheckerProtocolAdapter(checker, self.project)
        self._protocol_adapters[f"checker_{checker.__class__.__name__}"] = adapter
        self.project.add_system(adapter)
        return f"checker_{checker.__class__.__name__}"
    
    def register_subscriber_protocol(self, subscriber: SubscriberProtocol) -> str:
        """Register a subscriber protocol as a system."""
        adapter = SubscriberProtocolAdapter(subscriber, self.project)
        self._protocol_adapters[f"subscriber_{subscriber.__class__.__name__}"] = adapter
        self.project.add_system(adapter)
        return f"subscriber_{subscriber.__class__.__name__}"
    
    def register_renderer_protocol(self, renderer: RendererProtocol) -> str:
        """Register a renderer protocol as a system."""
        adapter = RendererProtocolAdapter(renderer, self.project)
        self._protocol_adapters[f"renderer_{renderer.format}"] = adapter
        self.project.add_system(adapter)
        return f"renderer_{renderer.format}"


# === PROTOCOL ADAPTERS ===

class GloveProtocolAdapter(ForgeSystem):
    """Adapter for GloveProtocol to work as a ForgeSystem."""
    
    def __init__(self, glove: GloveProtocol, project: ForgeProject):
        super().__init__()
        self.glove = glove
        self.project = project
        self.name = f"glove_{glove.stack}"
    
    def initialize(self):
        """Initialize glove protocol."""
        # Would initialize glove here
        pass
    
    def update(self, delta_time: float):
        """Update glove protocol."""
        # Would run glove analysis here
        pass
    
    def destroy(self):
        """Cleanup glove protocol."""
        pass


class CheckerProtocolAdapter(ForgeSystem):
    """Adapter for CheckerProtocol to work as a ForgeSystem."""
    
    def __init__(self, checker: CheckerProtocol, project: ForgeProject):
        super().__init__()
        self.checker = checker
        self.project = project
        self.name = f"checker_{checker.__class__.__name__}"
    
    def initialize(self):
        """Initialize checker protocol."""
        pass
    
    def update(self, delta_time: float):
        """Run health checks."""
        # Would run checker here
        pass


class SubscriberProtocolAdapter(ForgeSystem):
    """Adapter for SubscriberProtocol to work as a ForgeSystem."""
    
    def __init__(self, subscriber: SubscriberProtocol, project: ForgeProject):
        super().__init__()
        self.subscriber = subscriber
        self.project = project
        self.name = f"subscriber_{subscriber.__class__.__name__}"
    
    def initialize(self):
        """Initialize subscriber protocol."""
        pass
    
    def update(self, delta_time: float):
        """Process events."""
        # Would process events here
        pass


class RendererProtocolAdapter(ForgeSystem):
    """Adapter for RendererProtocol to work as a ForgeSystem."""
    
    def __init__(self, renderer: RendererProtocol, project: ForgeProject):
        super().__init__()
        self.renderer = renderer
        self.project = project
        self.name = f"renderer_{renderer.format}"
    
    def initialize(self):
        """Initialize renderer protocol."""
        pass
    
    def update(self, delta_time: float):
        """Handle rendering."""
        # Would handle rendering here
        pass


# === COMPONENT FACTORIES ===

class ForgeComponentFactory:
    """Factory for creating Forge components from existing schemas."""
    
    @staticmethod
    def create_from_manifest_node(manifest_node: ManifestNode) -> List[ForgeComponent]:
        """Create components from a manifest node."""
        components = []
        
        # Node component
        node_comp = NodeComponent(
            node_id=manifest_node.id,
            node_kind=manifest_node.kind,
            domain=manifest_node.domain or "",
            tier=NodeTier(manifest_node.meta.get("tier", "worker")),
            path=manifest_node.path or "",
            status=NodeStatus.IMPLEMENTED if manifest_node.status == "implemented" else NodeStatus.DECLARED
        )
        components.append(node_comp)
        
        # Tier component
        tier_comp = TierComponent(tier=node_comp.tier)
        components.append(tier_comp)
        
        # Manifest component
        manifest_comp = ManifestComponent(
            manifest_path=manifest_node.path or "",
            auto_sync=True
        )
        components.append(manifest_comp)
        
        # Health component
        health_comp = HealthComponent()
        components.append(health_comp)
        
        return components
    
    @staticmethod
    def create_from_change_event(change_event: ChangeEvent) -> ChangeComponent:
        """Create change component from change event."""
        return ChangeComponent(
            change_class=change_event.change_class,
            affected_nodes=change_event.affected_node_ids,
            breaking=change_event.breaking,
            context=change_event.context
        )
    
    @staticmethod
    def create_from_forge_error(forge_error: ForgeError) -> ErrorComponent:
        """Create error component from forge error."""
        error_comp = ErrorComponent()
        error_comp.error_domain = forge_error.domain
        error_comp.severity = SeverityLevel.ERROR
        error_comp.add_error(forge_error.dict())
        return error_comp
    
    @staticmethod
    def create_from_pipeline_step(pipeline_step: PipelineStep) -> PipelineComponent:
        """Create pipeline component from pipeline step."""
        pipeline_comp = PipelineComponent(
            pipeline_id=pipeline_step.step,
            status="pending"
        )
        pipeline_comp.add_step(
            PipelineStepKind(pipeline_step.kind),
            {
                "resource": pipeline_step.resource,
                "tool": pipeline_step.tool,
                "params": pipeline_step.params,
                "required": pipeline_step.required,
                "gate": pipeline_step.gate,
                "input_map": pipeline_step.input_map
            }
        )
        return pipeline_comp


# === UTILITY FUNCTIONS ===

def create_integrated_project(project_path: Path, scope: ProjectScope = ProjectScope.PROJECT) -> ForgeProject:
    """Create a fully integrated Forge project."""
    from forge.core.forge_project_system import ForgeProject, create_project
    
    project = create_project(project_path, scope)
    
    # Create integration bridge
    bridge = ForgeIntegrationBridge(project)
    
    # Load manifest
    bridge.load_manifest_graph()
    
    # Apply schema validation
    bridge.apply_schema_validation()
    
    # Store bridge for later use
    project.set_resource("integration_bridge", bridge)
    
    return project


def register_all_protocols(project: ForgeProject, protocols: Dict[str, Any]):
    """Register all available protocols with project."""
    bridge = project.get_resource("integration_bridge")
    if not bridge:
        bridge = ForgeIntegrationBridge(project)
        project.set_resource("integration_bridge", bridge)
    
    for name, protocol in protocols.items():
        if isinstance(protocol, GloveProtocol):
            bridge.register_glove_protocol(protocol)
        elif isinstance(protocol, CheckerProtocol):
            bridge.register_checker_protocol(protocol)
        elif isinstance(protocol, SubscriberProtocol):
            bridge.register_subscriber_protocol(protocol)
        elif isinstance(protocol, RendererProtocol):
            bridge.register_renderer_protocol(protocol)


def sync_project_to_manifest(project: ForgeProject) -> Dict[str, Any]:
    """Sync project state back to manifest format."""
    bridge = project.get_resource("integration_bridge")
    if not bridge:
        bridge = ForgeIntegrationBridge(project)
        project.set_resource("integration_bridge", bridge)
    
    manifest_graph = bridge.entities_to_manifest_graph()
    
    return {
        "nodes": [
            {
                "id": node.id,
                "kind": node.kind,
                "name": node.name,
                "path": node.path,
                "domain": node.domain,
                "tier": node.meta.get("tier", "worker"),
                "status": node.status
            }
            for node in manifest_graph.nodes
        ],
        "edges": [
            {
                "from_id": edge.from_id,
                "to_id": edge.to_id,
                "relation": edge.relation
            }
            for edge in manifest_graph.edges
        ]
    }


# Usage Examples
def integration_example():
    """Example of using integration bridge."""
    
    # Create integrated project
    project = create_integrated_project(Path("/Users/sebastianpereira/Projects/forge"))
    
    # Initialize project
    project.initialize()
    
    # Run project loop
    for i in range(10):
        project.update(0.016)
    
    # Sync back to manifest
    manifest_data = sync_project_to_manifest(project)
    
    return project, manifest_data
