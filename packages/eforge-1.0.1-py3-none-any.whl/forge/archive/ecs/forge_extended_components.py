"""
Extended Forge Components - Graph, Glove, and Stack-Agnostic modules as components.
Completes the component system with all remaining Forge primitives.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, TypeVar, Union, runtime_checkable

from forge.core.forge_project_system import ForgeComponent, ForgeSystem, ForgeProject
from forge.core.schemas import (
    NodeTier, ChangeClass, ResponseTier,
    AnnotationKind, PipelineStepKind, ErrorDomain
)
from forge.core.debug_output_interface import SeverityLevel
from forge.core.forge_project_system import ContractStatus

# Import existing Forge classes
from forge.tools.manifest.graph import ManifestGraph, ManifestNode, ManifestEdge
from forge.core.gloves import RawNode, RawEdge, StackGlove
from forge.protocols.glove import GloveProtocol
from forge.core.execution_graph import ExecutionGraph, ExecutionNode, ExecutionEdge
from forge.core.trace_mapper import TraceNodeMapper
from forge.core.graph_health_metrics import HealthMetric, MetricType
from forge.events.schema import UniversalEvent
from forge.protocols.events import ProtocolEvent

T = TypeVar('T')


# === GRAPH SYSTEM COMPONENTS ===

@dataclass
class GraphLayer:
    """A single graph dimension — declaration, execution, intent, contract, etc."""
    name: str
    node_id: str
    graph: Any  # ManifestGraph or other graph type
    
    def siblings(self) -> list[Any]:
        if hasattr(self.graph, 'find_siblings_by_id'):
            return self.graph.find_siblings_by_id(self.node_id)
        return self.graph.find_siblings(self.node_id) if hasattr(self.graph, 'find_siblings') else []
    
    def ancestors(self) -> list[Any]:
        if hasattr(self.graph, 'find_ancestors_by_id'):
            return self.graph.find_ancestors_by_id(self.node_id)
        return self.graph.find_ancestors(self.node_id) if hasattr(self.graph, 'find_ancestors') else []
    
    def descendants(self) -> list[Any]:
        if hasattr(self.graph, 'find_descendants_by_id'):
            return self.graph.find_descendants_by_id(self.node_id)
        return self.graph.find_descendants(self.node_id) if hasattr(self.graph, 'find_descendants') else []
    
    def edges_out(self) -> list[Any]:
        if hasattr(self.graph, 'edges_from_by_id'):
            return self.graph.edges_from_by_id(self.node_id)
        return self.graph.edges_from(self.node_id) if hasattr(self.graph, 'edges_from') else []
    
    def edges_in(self) -> list[Any]:
        if hasattr(self.graph, 'edges_to_by_id'):
            return self.graph.edges_to_by_id(self.node_id)
        return self.graph.edges_to(self.node_id) if hasattr(self.graph, 'edges_to') else []
    
    def blast_radius(self, change_kind: str = "any") -> dict:
        if hasattr(self.graph, 'blast_radius_ring2'):
            return self.graph.blast_radius_ring2(self.node_id, change_kind)
        return {}
    
    def watchers(self) -> list[Any]:
        if hasattr(self.graph, "find_watchers"):
            return self.graph.find_watchers(self.node_id)
        return []


@dataclass
class TriangulationResult:
    """Result of querying across multiple graph layers."""
    query: str
    node_id: str
    layers_queried: list[str]
    per_layer: dict[str, set[str]] = field(default_factory=dict)
    
    @property
    def intersection(self) -> set[str]:
        """Entities present in ALL layers — highest confidence."""
        if not self.per_layer:
            return set()
        sets = list(self.per_layer.values())
        return sets[0].intersection(*sets[1:]) if len(sets) > 1 else sets[0]
    
    @property
    def union(self) -> set[str]:
        """Entities present in ANY layer — broadest coverage."""
        result = set()
        for s in self.per_layer.values():
            result |= s
        return result
    
    @property
    def confidence(self) -> dict[str, float]:
        """Confidence score per entity — 1.0 = in all layers."""
        total = len(self.per_layer)
        if not total:
            return {}
        counts: dict[str, int] = {}
        for s in self.per_layer.values():
            for node_id in s:
                counts[node_id] = counts.get(node_id, 0) + 1
        return {k: round(v / total, 2) for k, v in counts.items()}
    
    def top(self, n: int = 10) -> list[tuple[str, float]]:
        """Highest confidence affected entities."""
        return sorted(self.confidence.items(), key=lambda x: -x[1])[:n]
    
    def to_dict(self) -> dict:
        return {
            "query": self.query,
            "node_id": self.node_id,
            "layers_queried": self.layers_queried,
            "intersection": list(self.intersection),
            "union": list(self.union),
            "top_confidence": self.top(10),
            "confidence_scores": self.confidence,
        }


@dataclass
class GraphComponent(ForgeComponent):
    """Multi-layer graph component — entity's position across all graph dimensions."""
    node_id: str = ""
    _layers: Dict[str, GraphLayer] = field(default_factory=dict)
    _graph_system: Any = None  # reference to GraphSystem
    
    def add_layer(self, name: str, graph: Any) -> "GraphComponent":
        self._layers[name] = GraphLayer(name=name, node_id=self.node_id, graph=graph)
        return self
    
    def in_layer(self, name: str) -> GraphLayer | None:
        return self._layers.get(name)
    
    # Convenience methods — delegate to declaration layer by default
    def siblings(self, layer: str = "declaration") -> list[Any]:
        l = self._layers.get(layer)
        return l.siblings() if l else []
    
    def ancestors(self, layer: str = "declaration") -> list[Any]:
        l = self._layers.get(layer)
        return l.ancestors() if l else []
    
    def descendants(self, layer: str = "declaration") -> list[Any]:
        l = self._layers.get(layer)
        return l.descendants() if l else []
    
    def edges_out(self, layer: str = "declaration") -> list[Any]:
        l = self._layers.get(layer)
        return l.edges_out() if l else []
    
    def edges_in(self, layer: str = "declaration") -> list[Any]:
        l = self._layers.get(layer)
        return l.edges_in() if l else []
    
    def blast_radius(self, change_kind: str = "any", layer: str = "declaration") -> dict:
        l = self._layers.get(layer)
        return l.blast_radius(change_kind) if l else {}
    
    def triangulate(self, query: str, layers: list[str] | None = None, 
                    **kwargs) -> TriangulationResult:
        """Query across multiple graph layers and intersect results."""
        target_layers = layers or list(self._layers.keys())
        result = TriangulationResult(
            query=query,
            node_id=self.node_id,
            layers_queried=target_layers,
        )
        for layer_name in target_layers:
            layer = self._layers.get(layer_name)
            if not layer:
                continue
            method = getattr(layer, query, None)
            if callable(method):
                raw = method(**kwargs)
                # Normalize to set of ids
                ids = set()
                for item in (raw if isinstance(raw, list) else raw.get("watchers", [])):
                    if hasattr(item, "id"):
                        ids.add(item.id)
                    elif isinstance(item, str):
                        ids.add(item)
                result.per_layer[layer_name] = ids
        return result
    
    def to_dict(self) -> dict:
        return {
            "node_id": self.node_id,
            "layers": list(self._layers.keys()),
        }


@dataclass
class ManifestGraphComponent(GraphComponent):
    """Manifest graph specific component."""
    manifest_path: str = ""
    auto_load: bool = True
    cache_enabled: bool = True
    
    def awake(self):
        """Initialize manifest graph."""
        super().awake()
        self.graph_type = "manifest"
        
        if self.auto_load and self.entity and self.entity.game:
            self.load_manifest_graph()
    
    def load_manifest_graph(self) -> Optional[ManifestGraph]:
        """Load manifest from file."""
        if not self.manifest_path and self.entity and self.entity.game:
            self.manifest_path = str(self.entity.game.root_path / ".forge" / "manifest.yaml")
        
        if not self.manifest_path:
            return None
        
        try:
            from forge.tools.manifest.graph import build_manifest_graph
            graph = build_manifest_graph(self.manifest_path, str(self.entity.game.root_path))
            
            # Store in game resources
            if self.entity.game:
                self.entity.game.set_resource("manifest_graph", graph)
            
            self.node_count = len(graph.nodes)
            self.edge_count = len(graph.edges)
            
            return graph
        except Exception as e:
            self.sync_errors.append(f"Failed to load manifest: {e}")
            return None
    
    def get_nodes_by_kind(self, kind: str) -> List[ManifestNode]:
        """Get nodes filtered by kind."""
        graph = self.get_graph()
        if not graph:
            return []
        return [node for node in graph.nodes if node.kind == kind]
    
    def get_nodes_by_tier(self, tier: NodeTier) -> List[ManifestNode]:
        """Get nodes filtered by tier."""
        graph = self.get_graph()
        if not graph:
            return []
        return [node for node in graph.nodes 
                if node.meta.get("tier") == tier.value]


@dataclass
class ExecutionGraphComponent(GraphComponent):
    """Execution graph component for runtime tracking."""
    trace_enabled: bool = True
    performance_tracking: bool = True
    max_trace_depth: int = 100
    
    def awake(self):
        """Initialize execution graph."""
        super().awake()
        self.graph_type = "execution"
        
        if self.entity and self.entity.game:
            self.entity.game.set_resource("execution_graph", ExecutionGraph())
    
    def start_trace(self, node_id: str, operation: str) -> str:
        """Start tracing an operation."""
        if not self.trace_enabled:
            return ""
        
        # Would implement trace start logic here
        return f"trace_{node_id}_{operation}_{hash(node_id)}"
    
    def end_trace(self, trace_id: str, result: Any = None):
        """End a trace."""
        if not self.trace_enabled or not trace_id:
            return
        
        # Would implement trace end logic here
        pass


@dataclass
class WorkspaceGraphComponent(GraphComponent):
    """Workspace graph component for multi-project management."""
    workspace_path: str = ""
    project_count: int = 0
    dependency_count: int = 0
    
    def awake(self):
        """Initialize workspace graph."""
        super().awake()
        self.graph_type = "workspace"
    
    def scan_workspace(self) -> bool:
        """Scan workspace for projects."""
        if not self.workspace_path and self.entity and self.entity.game:
            self.workspace_path = str(self.entity.game.root_path)
        
        if not self.workspace_path:
            return False
        
        try:
            # Would implement workspace scanning logic here
            # This would discover forge projects and build dependency graph
            return True
        except Exception as e:
            self.sync_errors.append(f"Workspace scan failed: {e}")
            return False


# === GLOVE SYSTEM COMPONENTS ===

@dataclass
class GloveComponent(ForgeComponent):
    """Project-domain extension point — invoke domain-specific methods."""
    domain: str = ""
    glove_path: str = ""
    stack: str = ""
    glove_class: Optional[str] = None
    auto_discover: bool = True
    last_analysis: Optional[str] = None
    extracted_nodes: List[RawNode] = field(default_factory=list)
    extracted_edges: List[RawEdge] = field(default_factory=list)
    _methods: Dict[str, Any] = field(default_factory=dict)
    _loaded: bool = False
    
    def get_glove(self) -> Optional[GloveProtocol]:
        """Get the glove protocol instance."""
        if self.entity and self.entity.game:
            return self.entity.game.get_resource(f"glove_{self.stack}")
        return None
    
    def run_analysis(self, project_path: Optional[Path] = None) -> bool:
        """Run glove analysis on project."""
        glove = self.get_glove()
        if not glove:
            return False
        
        if not project_path and self.entity and self.entity.game:
            project_path = self.entity.game.root_path
        
        try:
            # Would run glove analysis here
            # output = glove.extract(project_path)
            # self.extracted_nodes = output.nodes
            # self.extracted_edges = output.edges
            return True
        except Exception as e:
            self.sync_errors.append(f"Analysis failed: {e}")
            return False
    
    def validate(self) -> List[str]:
        """Validate glove configuration."""
        errors = []
        if not self.stack:
            errors.append("Stack name is required")
        glove = self.get_glove()
        if not glove:
            errors.append(f"Glove protocol not found for stack: {self.stack}")
        return errors
    
    def awake(self):
        super().awake()
        if self.glove_path:
            self._load_glove()
    
    def _load_glove(self):
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location(
                f"glove_{self.domain}", self.glove_path
            )
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            # Register all public methods
            for name in dir(mod):
                if not name.startswith('_'):
                    obj = getattr(mod, name)
                    if callable(obj):
                        self._methods[name] = obj
            self._loaded = True
        except Exception as e:
            pass
    
    def can_invoke(self, method: str) -> bool:
        return method in self._methods
    
    def invoke(self, method: str, **kwargs) -> Any:
        if not self.can_invoke(method):
            raise ValueError(f"Method {method!r} not found in glove {self.domain!r}. "
                           f"Available: {list(self._methods.keys())}")
        return self._methods[method](**kwargs)
    
    def list_methods(self) -> list[str]:
        return list(self._methods.keys())
    
    def to_dict(self) -> dict:
        return {
            "domain": self.domain,
            "glove_path": self.glove_path,
            "methods": self.list_methods(),
            "loaded": self._loaded,
        }


@dataclass
class StackProfileComponent(ForgeComponent):
    """Stack profile component for configuration management."""
    stack_id: str = ""
    profile_path: str = ""
    template_paths: List[str] = field(default_factory=list)
    glove_class: Optional[str] = None
    schema_slice: Optional[str] = None
    
    def load_profile(self) -> bool:
        """Load stack profile from configuration."""
        if not self.profile_path:
            return False
        
        try:
            # Would load profile from YAML/JSON here
            return True
        except Exception as e:
            self.sync_errors.append(f"Profile load failed: {e}")
            return False
    
    def get_template_for_kind(self, kind: str) -> Optional[str]:
        """Get template path for a node kind."""
        # Would implement template resolution logic here
        return None


@dataclass
class ImportResolutionComponent(ForgeComponent):
    """Import resolution component for cross-stack compatibility."""
    strategy: str = "stack_agnostic"
    resolution_rules: Dict[str, Any] = field(default_factory=dict)
    unresolved_imports: List[str] = field(default_factory=list)
    
    def resolve_import(self, import_path: str, from_stack: str) -> Optional[str]:
        """Resolve an import path to a manifest node ID."""
        # Would implement import resolution logic here
        return None
    
    def add_resolution_rule(self, pattern: str, target: str):
        """Add a resolution rule."""
        self.resolution_rules[pattern] = target
    
    def validate_imports(self) -> List[str]:
        """Validate all imports and return unresolved ones."""
        # Would implement import validation logic here
        return []


# === STACK-AGNOSTIC COMPONENTS ===

@dataclass
class SemanticAnalysisComponent(ForgeComponent):
    """Semantic analysis component for code understanding."""
    analyzer_type: str = "nlp"  # nlp, pattern, hybrid
    confidence_threshold: float = 0.7
    extracted_concepts: List[Dict[str, Any]] = field(default_factory=list)
    domain_terms: List[str] = field(default_factory=list)
    
    def analyze_text(self, text: str) -> List[Dict[str, Any]]:
        """Analyze text for semantic concepts."""
        # Would implement semantic analysis here
        return []
    
    def extract_domain_terms(self, text: str) -> List[str]:
        """Extract domain-specific terms."""
        # Would implement domain term extraction here
        return []
    
    def get_concept_graph(self) -> Dict[str, Any]:
        """Get concept relationship graph."""
        # Would build concept relationships here
        return {}


@dataclass
class FrameworkDetectionComponent(ForgeComponent):
    """Framework detection component for automatic stack identification."""
    detected_frameworks: List[str] = field(default_factory=list)
    confidence_scores: Dict[str, float] = field(default_factory=dict)
    detection_rules: Dict[str, Any] = field(default_factory=dict)
    
    def detect_frameworks(self, project_path: Optional[Path] = None) -> Dict[str, float]:
        """Detect frameworks used in the project."""
        if not project_path and self.entity and self.entity.game:
            project_path = self.entity.game.root_path
        
        # Would implement framework detection logic here
        # Check package.json, requirements.txt, pubspec.yaml, etc.
        return {}
    
    def get_primary_framework(self) -> Optional[str]:
        """Get the primary framework with highest confidence."""
        if not self.confidence_scores:
            return None
        return max(self.confidence_scores, key=self.confidence_scores.get)


@dataclass
class ContractValidationComponent(ForgeComponent):
    """Contract validation component for interface compliance."""
    contract_definitions: Dict[str, Any] = field(default_factory=dict)
    validation_results: Dict[str, bool] = field(default_factory=dict)
    contract_violations: List[Dict[str, Any]] = field(default_factory=list)
    
    def add_contract_definition(self, contract_id: str, definition: Dict[str, Any]):
        """Add a contract definition."""
        self.contract_definitions[contract_id] = definition
    
    def validate_contract(self, contract_id: str, implementation: Any) -> bool:
        """Validate an implementation against a contract."""
        if contract_id not in self.contract_definitions:
            return False
        
        # Would implement contract validation logic here
        return True
    
    def get_violations(self) -> List[Dict[str, Any]]:
        """Get all contract violations."""
        return self.contract_violations.copy()


# === METRICS AND MONITORING COMPONENTS ===

@dataclass
class MetricsComponent(ForgeComponent):
    """Metrics collection and monitoring component."""
    metric_types: List[str] = field(default_factory=list)
    metric_values: Dict[str, float] = field(default_factory=dict)
    collection_interval: float = 1.0  # seconds
    last_collection: Optional[float] = None
    
    def add_metric_type(self, metric_type: str):
        """Add a metric type to track."""
        if metric_type not in self.metric_types:
            self.metric_types.append(metric_type)
    
    def record_metric(self, metric_type: str, value: float):
        """Record a metric value."""
        self.metric_values[metric_type] = value
    
    def get_metric(self, metric_type: str) -> Optional[float]:
        """Get a metric value."""
        return self.metric_values.get(metric_type)
    
    def get_all_metrics(self) -> Dict[str, float]:
        """Get all metrics."""
        return self.metric_values.copy()
    
    def update(self, delta_time: float):
        """Update metrics collection."""
        import time
        current_time = time.time()
        
        if self.last_collection is None:
            self.last_collection = current_time
            return
        
        if current_time - self.last_collection >= self.collection_interval:
            self.collect_metrics()
            self.last_collection = current_time
    
    def collect_metrics(self):
        """Collect current metrics."""
        # Would implement metric collection logic here
        pass


@dataclass
class TraceComponent(ForgeComponent):
    """Trace management component for execution tracking."""
    trace_enabled: bool = True
    trace_storage: str = "memory"  # memory, file, database
    active_traces: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    completed_traces: List[Dict[str, Any]] = field(default_factory=list)
    
    def start_trace(self, operation: str, context: Dict[str, Any] = None) -> str:
        """Start a new trace."""
        if not self.trace_enabled:
            return ""
        
        import time
        import uuid
        
        trace_id = str(uuid.uuid4())
        self.active_traces[trace_id] = {
            "operation": operation,
            "start_time": time.time(),
            "context": context or {}
        }
        return trace_id
    
    def end_trace(self, trace_id: str, result: Any = None, error: Any = None):
        """End a trace."""
        if trace_id not in self.active_traces:
            return
        
        import time
        trace = self.active_traces.pop(trace_id)
        trace["end_time"] = time.time()
        trace["duration"] = trace["end_time"] - trace["start_time"]
        trace["result"] = result
        trace["error"] = error
        
        self.completed_traces.append(trace)
        
        # Cleanup old traces if too many
        if len(self.completed_traces) > 1000:
            self.completed_traces = self.completed_traces[-500:]
    
    def get_trace_statistics(self) -> Dict[str, Any]:
        """Get trace statistics."""
        if not self.completed_traces:
            return {}
        
        durations = [t["duration"] for t in self.completed_traces if "duration" in t]
        errors = [t for t in self.completed_traces if t.get("error")]
        
        return {
            "total_traces": len(self.completed_traces),
            "error_count": len(errors),
            "avg_duration": sum(durations) / len(durations) if durations else 0,
            "max_duration": max(durations) if durations else 0,
            "min_duration": min(durations) if durations else 0
        }


@dataclass
class EventComponent(ForgeComponent):
    """Event handling and routing component."""
    event_handlers: Dict[str, List[callable]] = field(default_factory=dict)
    event_queue: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class OrientComponent(ForgeComponent):
    """Orientation-specific component for session and scaffold operations."""
    # Core identity
    project: str = ""
    stack: str = "unknown"
    
    # Phase and task state
    phase: int = 0
    phase_name: str = ""
    current_task: str = ""
    blocker: str = ""
    next_action: str = ""
    
    # Health signals
    warnings: List[str] = field(default_factory=list)
    packets: Dict[str, Any] = field(default_factory=lambda: {
        "pending": 0,
        "expired": 0,
        "failed": 0
    })
    infra_health: Dict[str, Any] = field(default_factory=dict)
    structural_health: str = "clean"
    
    # Meta
    response_tier: str = "L0"
    generated_at: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize with tier-based filtering."""
        base_dict = {
            "type": self.__class__.__name__,
            "active": self.active,
            "data": {
                "project": self.project,
                "stack": self.stack,
                "phase": self.phase,
                "phase_name": self.phase_name,
                "current_task": self.current_task,
                "blocker": self.blocker,
                "next_action": self.next_action,
                "warnings": self.warnings,
                "packets": self.packets,
                "infra_health": self.infra_health,
                "structural_health": self.structural_health,
                "response_tier": self.response_tier,
                "generated_at": self.generated_at
            }
        }
        
        # Filter based on response tier
        if self.response_tier == "L0":
            # L0 returns minimal data
            return {
                **base_dict,
                "project": self.project,
                "phase": self.phase,
                "phase_name": self.phase_name,
                "stack": self.stack,
                "current_task": self.current_task,
                "blocker": self.blocker,
                "next_action": self.next_action,
                "warnings": self.warnings,
                "packets": self.packets,
                "infra_health": self.infra_health,
                "suggested_next": ["forge_context(section=phase)", "forge_context(section=tasks)"],
                "generated_at": self.generated_at
            }
        else:
            # L1+ returns full data
            return base_dict
    processing_enabled: bool = True
    
    def register_handler(self, event_type: str, handler: callable):
        """Register an event handler."""
        if event_type not in self.event_handlers:
            self.event_handlers[event_type] = []
        self.event_handlers[event_type].append(handler)
    
    def emit_event(self, event_type: str, data: Dict[str, Any] = None):
        """Emit an event."""
        event = {
            "type": event_type,
            "data": data or {},
            "timestamp": self._get_timestamp()
        }
        self.event_queue.append(event)
    
    def process_events(self):
        """Process all queued events."""
        if not self.processing_enabled:
            return
        
        while self.event_queue:
            event = self.event_queue.pop(0)
            self._handle_event(event)
    
    def _handle_event(self, event: Dict[str, Any]):
        """Handle a single event."""
        event_type = event["type"]
        handlers = self.event_handlers.get(event_type, [])
        
        for handler in handlers:
            try:
                handler(event)
            except Exception as e:
                # Log error but continue processing
                print(f"Event handler error: {e}")
    
    def _get_timestamp(self) -> float:
        """Get current timestamp."""
        import time
        return time.time()
    
    def update(self, delta_time: float):
        """Process events during update cycle."""
        self.process_events()


# === SYSTEMS FOR EXTENDED COMPONENTS ===

class GraphSystem(ForgeSystem):
    """System for managing graph components."""
    
    def __init__(self):
        self.name = "graphs"
    
    def update(self, delta_time: float):
        """Update all graph components."""
        if not self.game:
            return
        
        for entity in self.game.get_entities(GraphComponent):
            graph_comp = entity.get_component(GraphComponent)
            if graph_comp and graph_comp.active:
                # Would implement graph-specific updates here
                pass


class GloveSystem(ForgeSystem):
    """System for managing glove components."""
    
    def __init__(self):
        self.name = "gloves"
    
    def update(self, delta_time: float):
        """Update all glove components."""
        if not self.game:
            return
        
        for entity in self.game.get_entities(GloveComponent):
            glove_comp = entity.get_component(GloveComponent)
            if glove_comp and glove_comp.active:
                # Would implement glove-specific updates here
                pass


class MetricsSystem(ForgeSystem):
    """System for managing metrics components."""
    
    def __init__(self):
        self.name = "metrics"
    
    def update(self, delta_time: float):
        """Update all metrics components."""
        if not self.game:
            return
        
        for entity in self.game.get_entities(MetricsComponent):
            metrics_comp = entity.get_component(MetricsComponent)
            if metrics_comp and metrics_comp.active:
                metrics_comp.update(delta_time)


class EventSystem(ForgeSystem):
    """System for managing event components."""
    
    def __init__(self):
        self.name = "events"
    
    def update(self, delta_time: float):
        """Update all event components."""
        if not self.project:
            return
        
        for entity in self.project.get_entities(EventComponent):
            event_comp = entity.get_component(EventComponent)
            if event_comp and event_comp.active:
                event_comp.update(delta_time)



def register_extended_components(registry):
    """Register all extended components with the registry."""
    
    # Graph components
    registry.register_component("graph", GraphComponent)
    registry.register_component("manifest_graph", ManifestGraphComponent)
    registry.register_component("execution_graph", ExecutionGraphComponent)
    registry.register_component("workspace_graph", WorkspaceGraphComponent)
    
    # Glove components
    registry.register_component("glove", GloveComponent)
    registry.register_component("stack_profile", StackProfileComponent)
    registry.register_component("import_resolution", ImportResolutionComponent)
    
    # Stack-agnostic components
    registry.register_component("semantic_analysis", SemanticAnalysisComponent)
    registry.register_component("framework_detection", FrameworkDetectionComponent)
    registry.register_component("contract_validation", ContractValidationComponent)
    
    # Monitoring components
    registry.register_component("metrics", MetricsComponent)
    registry.register_component("trace", TraceComponent)
    registry.register_component("event", EventComponent)


def register_extended_systems(registry):
    """Register all extended systems with the registry."""
    
    registry.register_system("graphs", GraphSystem)
    registry.register_system("gloves", GloveSystem)
    registry.register_system("metrics", MetricsSystem)
    registry.register_system("events", EventSystem)


def create_extended_templates(registry):
    """Create extended entity templates."""
    
    # Graph entity template
    registry.register_template("graph_entity", {
        "kind": "graph",
        "components": {
            "graph": {},
            "manifest_graph": {"auto_load": True},
            "metrics": {},
            "event": {}
        },
        "properties": {},
        "tags": ["graph", "infrastructure"]
    })
    
    # Glove entity template
    registry.register_template("glove_entity", {
        "kind": "glove",
        "components": {
            "glove": {"auto_discover": True},
            "stack_profile": {},
            "import_resolution": {"strategy": "stack_agnostic"},
            "metrics": {},
            "trace": {"trace_enabled": True}
        },
        "properties": {},
        "tags": ["glove", "analysis"]
    })
    
    # Semantic analysis entity template
    registry.register_template("semantic_entity", {
        "kind": "semantic_analyzer",
        "components": {
            "semantic_analysis": {"analyzer_type": "hybrid"},
            "framework_detection": {},
            "contract_validation": {},
            "metrics": {}
        },
        "properties": {},
        "tags": ["semantic", "analysis"]
    })


# Usage Examples
def extended_example():
    """Example of using extended components."""
    from forge.core.forge_project_system import create_project, get_registry
    
    # Create project
    project = create_project(Path("/Users/sebastianpereira/Projects/forge"))
    
    # Get registry and register extended components
    registry = get_registry()
    register_extended_components(registry)
    
    # Create entities with extended components
    graph_entity = registry.create_entity_from_template(project, "graph_entity", "main_graph")
    glove_entity = registry.create_entity_from_template(project, "glove_entity", "python_glove")
    semantic_entity = registry.create_entity_from_template(project, "semantic_entity", "semantic_analyzer")
    
    # Add to project
    project.add_entity(graph_entity)
    project.add_entity(glove_entity)
    project.add_entity(semantic_entity)
    
    # Initialize and run
    project.initialize()
    
    for i in range(10):
        project.update(0.016)
    
    return project
