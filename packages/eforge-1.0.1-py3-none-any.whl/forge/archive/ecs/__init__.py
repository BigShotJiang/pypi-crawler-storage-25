"""Archived ECS bridge modules (pre-ForgeEngine). Prefer ``forge.engine.ForgeEngine``."""
