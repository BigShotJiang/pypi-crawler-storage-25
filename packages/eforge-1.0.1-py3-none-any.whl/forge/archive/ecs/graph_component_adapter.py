"""
Graph Component Adapter - Makes existing Forge graph system compatible with component architecture.
Provides bidirectional compatibility between dict-based graphs and component-based entities.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Type, TypeVar, Union
from pathlib import Path

from forge.core.forge_project_system import ForgeProject, ForgeEntity
from forge.core.forge_project_system import GraphComponent, ManifestGraphComponent

# Import existing Forge graph classes
from forge.tools.manifest.graph import (
    ManifestGraph, ManifestNode, ManifestEdge, 
    MANIFEST_NODE_KINDS, MANIFEST_EDGE_RELATIONS,
    build_manifest_graph, save_graph, load_graph
)

T = TypeVar('T')


class GraphComponentAdapter:
    """
    Adapter that makes existing Forge graph system work with component architecture.
    Provides seamless integration between dict-based graphs and component entities.
    """
    
    def __init__(self, project: ForgeProject):
        self.project = project
        self._graph_cache: Dict[str, Any] = {}
        self._entity_graph_mapping: Dict[str, str] = {}  # graph_id -> entity_id
        self._graph_entity_mapping: Dict[str, str] = {}  # entity_id -> graph_id
    
    # === GRAPH CREATION AND LOADING ===
    
    def load_manifest_graph(self, manifest_path: Optional[Path] = None) -> ManifestGraph:
        """Load manifest graph and create component entities."""
        if manifest_path is None:
            manifest_path = self.project.root_path / ".forge" / "manifest.yaml"
        
        # Load the actual graph
        graph = build_manifest_graph(str(manifest_path), str(self.project.root_path))
        self._graph_cache["manifest"] = graph
        
        # Create component entities for all nodes
        self._create_entities_from_graph(graph)
        
        return graph
    
    def create_manifest_graph_from_entities(self) -> ManifestGraph:
        """Create ManifestGraph from component entities."""
        graph = ManifestGraph()
        
        # Convert entities back to graph nodes
        for entity in self.project._entities.values():
            graph_node = self._entity_to_graph_node(entity)
            if graph_node:
                graph.nodes.append(graph_node)
        
        # Convert component edges back to graph edges
        graph.edges = self._create_graph_edges_from_entities()
        
        return graph
    
    def _create_entities_from_graph(self, graph: ManifestGraph):
        """Create component entities from manifest graph nodes."""
        for graph_node in graph.nodes:
            entity = self._graph_node_to_entity(graph_node)
            if entity:
                self.project.add_entity(entity)
                self._entity_graph_mapping[entity.id] = graph_node.id
                self._graph_entity_mapping[graph_node.id] = entity.id
        
        # Create edges as relationships between entities
        self._create_entity_edges_from_graph(graph)
    
    def _graph_node_to_entity(self, graph_node: ManifestNode) -> Optional[ForgeEntity]:
        """Convert a ManifestNode to a ForgeEntity with components."""
        entity = ForgeEntity(
            id=graph_node.id,
            kind=graph_node.kind
        )
        
        # Add core components
        entity.add_component(GraphComponent(
            graph_type="manifest",
            node_count=1,  # Will be updated when full graph is built
            edge_count=0
        ))
        
        entity.add_component(ManifestGraphComponent(
            manifest_path=graph_node.path or "",
            auto_sync=True
        ))
        
        # Add node-specific component
        from forge.core.forge_project_system import NodeComponent
        from forge.core.schemas import NodeTier, NodeStatus
        
        entity.add_component(NodeComponent(
            node_id=graph_node.id,
            node_kind=graph_node.kind,
            domain=graph_node.domain or "",
            tier=NodeTier(graph_node.meta.get("tier", "worker")),
            path=graph_node.path or "",
            status=NodeStatus.IMPLEMENTED if graph_node.status == "implemented" else NodeStatus.DECLARED
        ))
        
        return entity
    
    def _entity_to_graph_node(self, entity: ForgeEntity) -> Optional[ManifestNode]:
        """Convert a ForgeEntity back to a ManifestNode."""
        from forge.core.forge_project_system import NodeComponent
        
        node_comp = entity.get_component(NodeComponent)
        if not node_comp:
            return None
        
        return ManifestNode(
            id=node_comp.node_id,
            kind=node_comp.node_kind,
            name=entity.id.split("/")[-1],
            path=node_comp.path,
            domain=node_comp.domain,
            parent_id=None,
            status="implemented" if node_comp.status.value == "implemented" else "declared",
            meta={"tier": node_comp.tier.value}
        )
    
    def _create_entity_edges_from_graph(self, graph: ManifestGraph):
        """Create entity relationships from graph edges."""
        for edge in graph.edges:
            from_entity_id = self._graph_entity_mapping.get(edge.from_id)
            to_entity_id = self._graph_entity_mapping.get(edge.to_id)
            
            if from_entity_id and to_entity_id:
                from_entity = self.project.get_entity(from_entity_id)
                to_entity = self.project.get_entity(to_entity_id)
                
                if from_entity and to_entity:
                    # Store edge relationship in entity properties
                    edge_key = f"edge_{edge.relation}_{to_entity_id}"
                    from_entity.set_property(edge_key, {
                        "to_id": to_entity_id,
                        "relation": edge.relation,
                        "metadata": edge.metadata
                    })
    
    def _create_graph_edges_from_entities(self) -> List[ManifestEdge]:
        """Create graph edges from entity relationships."""
        edges = []
        
        for entity in self.project._entities.values():
            # Find all edge properties
            for prop_key, prop_value in entity._properties.items():
                if prop_key.startswith("edge_") and isinstance(prop_value, dict):
                    to_id = prop_value.get("to_id")
                    relation = prop_value.get("relation")
                    metadata = prop_value.get("metadata", {})
                    
                    if to_id and relation:
                        # Convert entity ID back to graph node ID
                        graph_to_id = self._entity_graph_mapping.get(to_id, to_id)
                        graph_from_id = self._entity_graph_mapping.get(entity.id, entity.id)
                        
                        if graph_to_id and graph_from_id:
                            edge = ManifestEdge(
                                from_id=graph_from_id,
                                to_id=graph_to_id,
                                relation=relation,
                                metadata=metadata
                            )
                            edges.append(edge)
        
        return edges
    
    # === DICT COMPATIBILITY LAYER ===
    
    def get_graph_as_dict(self, graph_type: str = "manifest") -> Dict[str, Any]:
        """Get graph in traditional dict format for backward compatibility."""
        graph = self._graph_cache.get(graph_type)
        if not graph:
            if graph_type == "manifest":
                graph = self.create_manifest_graph_from_entities()
                self._graph_cache[graph_type] = graph
        
        if not graph:
            return {}
        
        return {
            "nodes": [
                {
                    "id": node.id,
                    "kind": node.kind,
                    "name": node.name,
                    "path": node.path,
                    "domain": node.domain,
                    "tier": node.meta.get("tier", "worker"),
                    "status": node.status,
                    "parent_id": node.parent_id,
                    "fqid": node.fqid,
                    "layer": node.layer,
                    "meta": node.meta
                }
                for node in graph.nodes
            ],
            "edges": [
                {
                    "from_id": edge.from_id,
                    "to_id": edge.to_id,
                    "relation": edge.relation,
                    "metadata": edge.metadata
                }
                for edge in graph.edges
            ]
        }
    
    def load_graph_from_dict(self, graph_dict: Dict[str, Any], graph_type: str = "manifest") -> ManifestGraph:
        """Load graph from dict format and create entities."""
        graph = ManifestGraph()
        
        # Create nodes from dict
        node_data = graph_dict.get("nodes", [])
        for node_dict in node_data:
            node = ManifestNode(
                id=node_dict["id"],
                kind=node_dict["kind"],
                name=node_dict.get("name", node_dict["id"]),
                path=node_dict.get("path", ""),
                domain=node_dict.get("domain", ""),
                parent_id=node_dict.get("parent_id"),
                status=node_dict.get("status", "declared"),
                fqid=node_dict.get("fqid", ""),
                layer=node_dict.get("layer", "declaration"),
                meta=node_dict.get("meta", {})
            )
            graph.nodes.append(node)
        
        # Create edges from dict
        edge_data = graph_dict.get("edges", [])
        for edge_dict in edge_data:
            edge = ManifestEdge(
                from_id=edge_dict["from_id"],
                to_id=edge_dict["to_id"],
                relation=edge_dict["relation"],
                metadata=edge_dict.get("metadata", {})
            )
            graph.edges.append(edge)
        
        self._graph_cache[graph_type] = graph
        self._create_entities_from_graph(graph)
        
        return graph
    
    # === LEGACY API COMPATIBILITY ===
    
    def get_nodes(self, kind: Optional[str] = None, tier: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get nodes in legacy dict format."""
        graph_dict = self.get_graph_as_dict()
        nodes = graph_dict.get("nodes", [])
        
        filtered_nodes = nodes
        if kind:
            filtered_nodes = [n for n in filtered_nodes if n.get("kind") == kind]
        if tier:
            filtered_nodes = [n for n in filtered_nodes if n.get("meta", {}).get("tier") == tier]
        
        return filtered_nodes
    
    def get_edges(self, relation: Optional[str] = None, from_id: Optional[str] = None, to_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get edges in legacy dict format."""
        graph_dict = self.get_graph_as_dict()
        edges = graph_dict.get("edges", [])
        
        filtered_edges = edges
        if relation:
            filtered_edges = [e for e in filtered_edges if e.get("relation") == relation]
        if from_id:
            filtered_edges = [e for e in filtered_edges if e.get("from_id") == from_id]
        if to_id:
            filtered_edges = [e for e in filtered_edges if e.get("to_id") == to_id]
        
        return filtered_edges
    
    def add_node(self, node_dict: Dict[str, Any]) -> str:
        """Add a node using legacy dict format."""
        graph = self._graph_cache.get("manifest")
        if not graph:
            graph = ManifestGraph()
            self._graph_cache["manifest"] = graph
        
        node = ManifestNode(
            id=node_dict["id"],
            kind=node_dict["kind"],
            name=node_dict.get("name", node_dict["id"]),
            path=node_dict.get("path", ""),
            domain=node_dict.get("domain", ""),
            parent_id=node_dict.get("parent_id"),
            status=node_dict.get("status", "declared"),
            fqid=node_dict.get("fqid", ""),
            layer=node_dict.get("layer", "declaration"),
            meta=node_dict.get("meta", {})
        )
        
        graph.nodes.append(node)
        
        # Create entity for the new node
        entity = self._graph_node_to_entity(node)
        if entity:
            self.project.add_entity(entity)
            self._entity_graph_mapping[entity.id] = node.id
            self._graph_entity_mapping[node.id] = entity.id
        
        return node.id
    
    def add_edge(self, edge_dict: Dict[str, Any]) -> str:
        """Add an edge using legacy dict format."""
        graph = self._graph_cache.get("manifest")
        if not graph:
            graph = ManifestGraph()
            self._graph_cache["manifest"] = graph
        
        edge = ManifestEdge(
            from_id=edge_dict["from_id"],
            to_id=edge_dict["to_id"],
            relation=edge_dict["relation"],
            metadata=edge_dict.get("metadata", {})
        )
        
        graph.edges.append(edge)
        
        # Create entity relationship
        from_entity_id = self._graph_entity_mapping.get(edge.from_id)
        to_entity_id = self._graph_entity_mapping.get(edge.to_id)
        
        if from_entity_id and to_entity_id:
            from_entity = self.project.get_entity(from_entity_id)
            if from_entity:
                edge_key = f"edge_{edge.relation}_{to_entity_id}"
                from_entity.set_property(edge_key, {
                    "to_id": to_entity_id,
                    "relation": edge.relation,
                    "metadata": edge.metadata
                })
        
        return f"{edge.from_id}->{edge.to_id}"
    
    def remove_node(self, node_id: str) -> bool:
        """Remove a node using legacy ID format."""
        # Remove from graph
        graph = self._graph_cache.get("manifest")
        if graph:
            graph.nodes = [n for n in graph.nodes if n.id != node_id]
        
        # Remove entity
        entity_id = self._graph_entity_mapping.get(node_id)
        if entity_id:
            self.project.remove_entity(entity_id)
            del self._entity_graph_mapping[node_id]
            del self._entity_graph_mapping[entity_id]
        
        return True
    
    def remove_edge(self, edge_key: str) -> bool:
        """Remove an edge using legacy key format."""
        # Parse edge key (format: "from_id->to_id")
        if "->" in edge_key:
            from_id, to_id = edge_key.split("->", 1)
        else:
            return False
        
        # Remove from graph
        graph = self._graph_cache.get("manifest")
        if graph:
            graph.edges = [e for e in graph.edges 
                          if not (e.from_id == from_id and e.to_id == to_id)]
        
        # Remove entity relationships
        entity_id = self._graph_entity_mapping.get(from_id)
        if entity_id:
            entity = self.project.get_entity(entity_id)
            if entity:
                # Find and remove edge properties
                keys_to_remove = [k for k in entity._properties.keys() 
                                if k.startswith("edge_") and to_id in k]
                for key in keys_to_remove:
                    del entity._properties[key]
        
        return True
    
    # === QUERY AND FILTERING ===
    
    def query_nodes(self, filters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Query nodes with filters (compatible with existing forge query system)."""
        nodes = self.get_nodes()
        
        for key, value in filters.items():
            if key == "kind":
                nodes = [n for n in nodes if n.get("kind") == value]
            elif key == "tier":
                nodes = [n for n in nodes if n.get("meta", {}).get("tier") == value]
            elif key == "domain":
                nodes = [n for n in nodes if n.get("domain") == value]
            elif key == "status":
                nodes = [n for n in nodes if n.get("status") == value]
        
        return nodes
    
    def get_node_by_id(self, node_id: str) -> Optional[Dict[str, Any]]:
        """Get node by ID in legacy dict format."""
        nodes = self.get_nodes()
        for node in nodes:
            if node.get("id") == node_id:
                return node
        return None
    
    def get_edges_by_node(self, node_id: str, direction: str = "both") -> List[Dict[str, Any]]:
        """Get edges connected to a node."""
        edges = self.get_edges()
        
        if direction == "outgoing":
            return [e for e in edges if e.get("from_id") == node_id]
        elif direction == "incoming":
            return [e for e in edges if e.get("to_id") == node_id]
        else:  # both
            return [e for e in edges if e.get("from_id") == node_id or e.get("to_id") == node_id]
    
    # === PERSISTENCE ===
    
    def save_graph(self, graph_type: str = "manifest", cache_path: Optional[Path] = None) -> bool:
        """Save graph to cache file."""
        graph = self._graph_cache.get(graph_type)
        if not graph:
            graph = self.create_manifest_graph_from_entities()
            self._graph_cache[graph_type] = graph
        
        if cache_path is None:
            cache_path = self.project.root_path / ".forge" / "manifest_graph.json"
        
        try:
            save_graph(graph, str(cache_path))
            return True
        except Exception:
            return False
    
    def load_cached_graph(self, graph_type: str = "manifest", cache_path: Optional[Path] = None) -> Optional[ManifestGraph]:
        """Load graph from cache file."""
        if cache_path is None:
            cache_path = self.project.root_path / ".forge" / "manifest_graph.json"
        
        try:
            graph = load_graph(str(cache_path))
            if graph:
                self._graph_cache[graph_type] = graph
                self._create_entities_from_graph(graph)
                return graph
        except Exception:
            pass
        
        return None


# === UTILITY FUNCTIONS ===

def create_graph_adapter(project: ForgeProject) -> GraphComponentAdapter:
    """Create a graph adapter for a project."""
    return GraphComponentAdapter(project)


def make_graph_system_compatible(project: ForgeProject) -> Dict[str, Any]:
    """
    Create a dict-compatible interface that works with existing Forge commands.
    Returns a dict-like object that proxies to the component system.
    """
    
    adapter = create_graph_adapter(project)
    
    class GraphDictProxy:
        """Dict-like proxy for graph operations."""
        
        def __init__(self, adapter: GraphComponentAdapter):
            self.adapter = adapter
        
        def get_nodes(self, **filters):
            return self.adapter.query_nodes(filters)
        
        def get_edges(self, **filters):
            return self.adapter.get_edges(
                relation=filters.get("relation"),
                from_id=filters.get("from_id"),
                to_id=filters.get("to_id")
            )
        
        def add_node(self, node_dict):
            return self.adapter.add_node(node_dict)
        
        def add_edge(self, edge_dict):
            return self.adapter.add_edge(edge_dict)
        
        def remove_node(self, node_id):
            return self.adapter.remove_node(node_id)
        
        def remove_edge(self, edge_key):
            return self.adapter.remove_edge(edge_key)
        
        def save(self, path=None):
            return self.adapter.save_graph(cache_path=Path(path) if path else None)
        
        def load(self, path=None):
            return self.adapter.load_cached_graph(cache_path=Path(path) if path else None)
        
        def to_dict(self):
            return self.adapter.get_graph_as_dict()
        
        # Dict-like access
        def __getitem__(self, key):
            if key == "nodes":
                return self.adapter.get_nodes()
            elif key == "edges":
                return self.adapter.get_edges()
            else:
                return self.to_dict().get(key)
        
        def __setitem__(self, key, value):
            # Handle direct dict assignment
            if key == "nodes":
                # Load nodes from dict format
                self.adapter.load_graph_from_dict({"nodes": value, "edges": []})
            elif key == "edges":
                # Load edges from dict format
                self.adapter.load_graph_from_dict({"nodes": [], "edges": value})
        
        def __contains__(self, key):
            return key in ["nodes", "edges"]
    
    return GraphDictProxy(adapter)


# === INTEGRATION WITH EXISTING COMMANDS ===

def patch_existing_graph_commands():
    """
    Patch existing Forge graph commands to use component system.
    This allows existing commands to work without modification.
    """
    
    # Store original functions
    import forge.tools.manifest.graph as original_module
    
    # Patch build_manifest_graph
    original_build_manifest_graph = original_module.build_manifest_graph
    
    def patched_build_manifest_graph(manifest_path: str, project_root: str) -> ManifestGraph:
        """Patched version that creates component entities."""
        # This would be called from existing commands
        # We need to get the current project somehow
        # For now, return original behavior
        return original_build_manifest_graph(manifest_path, project_root)
    
    # Apply patches
    original_module.build_manifest_graph = patched_build_manifest_graph
    
    return {
        "original_build_manifest_graph": original_build_manifest_graph,
        "patched_build_manifest_graph": patched_build_manifest_graph
    }


# Usage Examples
def graph_adapter_example():
    """Example of using graph adapter with component system."""
    from forge.core.forge_project_system import create_project
    
    # Create project
    project = create_project(Path("/Users/sebastianpereira/Projects/forge"))
    
    # Create graph adapter
    adapter = create_graph_adapter(project)
    
    # Load existing manifest
    graph = adapter.load_manifest_graph()
    print(f"Loaded {len(graph.nodes)} nodes and {len(graph.edges)} edges")
    
    # Use legacy dict API
    nodes = adapter.get_nodes(kind="controller")
    print(f"Found {len(nodes)} controllers")
    
    # Add new node using dict format
    new_node = {
        "id": "new/controller",
        "kind": "controller",
        "name": "NewController",
        "path": "src/new_controller.py",
        "domain": "app",
        "meta": {"tier": "surface"}
    }
    node_id = adapter.add_node(new_node)
    print(f"Added node: {node_id}")
    
    # Add edge using dict format
    new_edge = {
        "from_id": "new/controller",
        "to_id": "existing/service",
        "relation": "depends_on",
        "metadata": {}
    }
    edge_key = adapter.add_edge(new_edge)
    print(f"Added edge: {edge_key}")
    
    # Get dict-compatible interface
    graph_proxy = make_graph_system_compatible(project)
    
    # Use like original dict
    all_nodes = graph_proxy["nodes"]
    all_edges = graph_proxy["edges"]
    
    # Query like original
    controllers = graph_proxy.get_nodes(kind="controller")
    dependencies = graph_proxy.get_edges(relation="depends_on")
    
    # Save back
    graph_proxy.save()
    
    return project, adapter, graph_proxy
