from __future__ import annotations

import json

import mcp.types as types

from forge.core.schemas import (
    IntentResult,
    ManifestResult,
    OrientResult,
    PacketResult,
    ForgeGraphQueryPayload,
    SessionResult,
    VerifyResult,
    ForgeOrientOutput,
    ForgeHealthVectorOutput,
    ForgeVerifyEventsOutput,
    ForgeImpactCheckOutput,
    ForgePacketAssembleOutput,
)
from forge.core.pipeline_executor import PipelineResult
from forge.core.errors import ErrorCode, ErrorLayer

ERROR_SCHEMA = {
    "type": "object",
    "required": ["code", "layer", "message", "hint"],
    "properties": {
        "code": {"type": "string", "pattern": "^MCP-[0-9]{3}$"},
        "layer": {
            "type": "string",
            "enum": ["transport","input","declaration",
                     "execution","contract","provider","internal"]
        },
        "message": {"type": "string"},
        "hint": {"type": "string"},
        "recoverable": {"type": "boolean"},
        "graph_nodes": {"type": "array", "items": {"type": "string"}},
        "suggested_commands": {"type": "array", "items": {"type": "string"}}
    }
}

def _build_tool_description(base: str, properties: dict) -> str:
    """Build a tool description string from a base sentence and a properties dict.

    Appends one formatted line per property (skipping project_path — universal noise):
        name (type, default=X): description

    Rules:
    - Properties without a ``description`` field are skipped.
    - Enum values are omitted from prose; they live in the schema.
    - Type/default are never repeated inside the description text.
    """
    lines = []
    for name, prop in properties.items():
        if name == "project_path":
            continue
        desc = prop.get("description")
        if not desc:
            continue
        ptype = prop.get("type", "any")
        default = prop.get("default")
        if default is not None:
            if isinstance(default, bool):
                dval = "true" if default else "false"
            elif isinstance(default, (list, dict)):
                dval = json.dumps(default)
            else:
                dval = str(default)
            lines.append(f"{name} ({ptype}, default={dval}): {desc}")
        else:
            lines.append(f"{name} ({ptype}): {desc}")
    if lines:
        return base + "\n" + "\n".join(lines)
    return base


# ── Per-tool property dicts ───────────────────────────────────────────────────
# Extracted so the same dict is wired into both description= and
# inputSchema.properties= — single source of truth.

_forge_context_props: dict = {
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
    "template": {
        "type": "string",
        "description": "Context template to use for the bundle",
        "default": "default",
    },
    "feature": {
        "type": "string",
        "description": "Specific feature to focus on in the context",
    },
    "section": {
        "type": "string",
        "description": "Specific section of the context to include",
        "enum": [
            "known_broken", "constraints", "phase", "tasks",
            "graph", "goals", "session", "open", "modules",
        ],
    },
    "include_session": {
        "type": "boolean",
        "default": False,
        "description": "Include session scratch. Omit by default to prevent cross-project bleed.",
    },
    "exclude_sections": {
        "type": "array",
        "items": {"type": "string"},
        "description": "Sections to suppress. 'session' excluded by default.",
    },
    "sections": {
        "type": "array",
        "items": {"type": "string"},
        "description": "Explicit allowlist of sections to return.",
    },
}

_forge_project_status_props: dict = {
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
}

_forge_impact_check_props: dict = {
    "project_path": {"type": "string"},
    "changed_files": {
        "type": "array",
        "items": {"type": "string"},
        "description": "List of repo-relative file paths to check for impact",
    },
    "strict": {
        "type": "boolean",
        "default": False,
        "description": "Treat triggered impact rules as blocking failures",
    },
}

_forge_config_get_props: dict = {
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
    "key": {
        "type": "string",
        "description": "Dot-notation key path to read — e.g. app.name or ui.theme",
    },
    "file": {
        "type": "string",
        "enum": ["config", "manifest", "workspace"],
        "default": "config",
        "description": "YAML file: app_config paths (config), .forge/manifest.yaml (manifest), ~/.forge/workspace.yaml (workspace).",
    },
}

_forge_config_set_props: dict = {
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
    "key": {
        "type": "string",
        "description": "Dot-notation key path to write — e.g. app.name or debug.enabled",
    },
    "value": {
        "description": "Value to write at the specified key path",
    },
    "dry_run": {
        "type": "boolean",
        "default": True,
        "description": "Preview changes without writing to config file",
    },
    "file": {
        "type": "string",
        "enum": ["config", "manifest", "workspace"],
        "default": "config",
        "description": "YAML file: app_config paths (config), .forge/manifest.yaml (manifest), ~/.forge/workspace.yaml (workspace).",
    },
}

_forge_session_log_props: dict = {
    "response_tier": {
        "type": "string",
        "description": "Response verbosity — L0 minimal, L1 standard, L2 full",
    },
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
}

_forge_workspace_props: dict = {
    "action": {
        "type": "string",
        "enum": ["status", "add", "dependents", "dependencies"],
        "description": "Action to perform",
    },
    "project_id": {
        "type": "string",
        "description": "Project ID for add/dependents/dependencies",
    },
    "project_path": {
        "type": "string",
        "description": "Absolute path (for add action)",
    },
    "depends_on": {
        "type": "array",
        "items": {"type": "string"},
        "description": "Dependency IDs (for add action)",
    },
}

_forge_manifest_append_props: dict = {
    "project_path": {
        "type": "string",
        "description": "Project root containing .forge/manifest.yaml (resolved with expanduser/resolve).",
    },
    "nodes": {
        "type": "array",
        "items": {"type": "object"},
        "description": "List of manifest node objects to append to the declaration graph",
    },
    "dry_run": {
        "type": "boolean",
        "default": False,
        "description": "Preview what would be appended without writing to manifest",
    },
    "response_tier": {
        "type": "string",
        "enum": ["L0", "L1", "L2"],
        "default": "L1",
        "description": "Response verbosity — L0 minimal, L1 standard, L2 full",
    },
}

_forge_scaffold_props: dict = {
    "project_path": {"type": "string", "description": "Project root for the scaffold pipeline."},
    "dry_run": {
        "type": "boolean",
        "default": False,
        "description": "Preview scaffold output without writing any files",
    },
    "node_type": {
        "type": "string",
        "description": "Type of node to scaffold — screen, controller, service, model, variant, module",
    },
    "intent_id": {
        "type": "string",
        "description": "Intent record ID to scaffold from — created with forge_intent",
    },
    "output_path": {
        "type": "string",
        "description": "Override output directory for generated files",
    },
    "emit_spec": {
        "type": "boolean",
        "default": False,
        "description": "Emit a spec file alongside generated code",
    },
    "describe": {
        "type": "string",
        "description": "Deprecated parameter - should be rejected by handler.",
    },
}

_forge_packet_assemble_props: dict = {
    "node": {
        "type": "string",
        "description": "Target node name for packet assembly.",
    },
    "type": {
        "type": "string",
        "enum": ["screen", "controller", "service", "model", "variant", "module"],
        "description": "Node type for packet assembly.",
    },
    "domain": {
        "type": "string",
        "description": "Uppercase domain key validated against glove.domains.",
    },
    "task": {
        "type": "string",
        "enum": ["generate", "fix"],
        "default": "generate",
        "description": "Packet task mode.",
    },
    "deps": {
        "type": "array",
        "items": {"type": "string"},
        "description": "Optional dependency node names.",
    },
    "methods": {
        "type": "array",
        "items": {"type": "string"},
        "description": "Optional method signatures in name(param:Type)->Return format.",
    },
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
}

_forge_orient_props: dict = {
    "node": {
        "type": "string",
        "description": "Node name for scaffold orientation mode; omit for session orientation",
    },
    "project_path": {
        "type": "string",
        "description": "Optional project root; when omitted resolves from workspace active/most-recent.",
    },
}

_forge_template_props: dict = {
    "action": {
        "type": "string",
        "enum": ["list", "show", "schema", "validate"],
        "description": "Template action — list, show, apply, or validate",
    },
    "stack": {"type": "string", "description": "Stack filter for list action — python, flutter, web, or dart"},
    "kind": {"type": "string", "description": "Template kind filter for list action"},
    "tier": {
        "type": "string",
        "enum": ["nodes", "features", "implementations"],
        "description": "Template tier filter for list action",
    },
    "template_id": {"type": "string", "description": "Template identifier for show or apply actions"},
    "response_tier": {
        "type": "string",
        "enum": ["L0", "L1", "L2"],
        "default": "L1",
        "description": "Response verbosity — L0 minimal, L1 standard, L2 full",
    },
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
}

_forge_map_props: dict = {
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
    "format": {
        "type": "string",
        "enum": ["md", "mermaid", "json"],
        "default": "md",
        "description": "Output format for the map",
    },
    "map_scope": {
        "type": "string",
        "enum": ["global", "project", "local", "sub-local"],
        "default": "project",
        "description": "Graph scope — global, project, local, or sub-local",
    },
    "domain": {
        "type": "string",
        "description": "Optional domain filter (CLI --domain; use with map_scope=local).",
    },
    "file": {
        "type": "string",
        "description": "Repo-relative file path for map_scope=sub-local (CLI --file).",
    },
    "edges": {
        "type": "boolean",
        "default": False,
        "description": "Include dependency edges in the map output",
    },
}

_forge_audit_scan_props: dict = {
    "mode": {
        "type": "string",
        "enum": ["repo", "meta"],
        "default": "repo",
        "description": "Scan mode — repo for full project scan, meta for branch-point audit",
    },
    "project_path": {"type": "string", "default": "."},
    "at_path": {
        "type": "string",
        "default": ".",
        "description": "Root path for meta mode scan; defaults to current directory",
    },
    "changed_files_source": {
        "type": "string",
        "enum": ["git", "scope", "all"],
        "default": "git",
        "description": "Source for detecting changed files",
    },
    "alignment_mode": {
        "type": "string",
        "enum": ["target_to_forge", "bidirectional", "target_only"],
        "default": "target_to_forge",
        "description": "Direction of alignment check between target and forge",
    },
    "scope": {
        "type": "array",
        "items": {"type": "string"},
        "description": "Audit scope filter — limits which check categories run",
    },
    "focus": {
        "type": "array",
        "items": {"type": "string"},
        "description": "Audit focus filter — limits which findings are surfaced",
    },
    "depth": {
        "type": "integer",
        "default": 3,
        "description": "Traversal depth for meta mode sibling discovery",
    },
    "include_siblings": {
        "type": "boolean",
        "default": True,
        "description": "Include sibling layer projects in meta mode audit",
    },
    "include_parent_context": {
        "type": "boolean",
        "default": True,
        "description": "Include parent project context in meta mode audit",
    },
    "strict": {
        "type": "boolean",
        "default": False,
        "description": "Treat advisory findings as blocking failures",
    },
    "policy_mode": {
        "type": "string",
        "enum": ["advisory", "enforce"],
        "default": "advisory",
        "description": "Policy enforcement mode — advisory warns, enforce blocks",
    },
}

_forge_session_props: dict = {
    "action": {
        "type": "string",
        "enum": ["start", "status", "handoff", "pause", "phase_upsert", "phase_status"],
        "description": "Session lifecycle action (thin ``forge audit`` CLI).",
    },
    "session_id": {
        "type": "string",
        "description": "EGMP session id (required for handoff/pause/phase_upsert/phase_status; optional for status — latest session_state is used when omitted).",
    },
    "repo_root": {
        "type": "string",
        "description": "Repo root for session start; mapped to CLI --project-path.",
    },
    "branch": {"type": "string", "description": "Optional branch for audit start."},
    "session_label": {"type": "string", "description": "Optional label for audit start."},
    "stopped_at": {"type": "string", "description": "ISO timestamp for handoff."},
    "next_action": {"type": "string", "description": "Next action string (handoff or phase upsert)."},
    "phase_id": {"type": "string", "description": "Phase id for phase_upsert."},
    "task_id": {"type": "string", "description": "Task id for phase_upsert."},
    "status": {
        "type": "string",
        "enum": ["todo", "doing", "blocked", "done"],
        "description": "Task status for phase_upsert (ignored for other actions).",
    },
}

_forge_audit_deprecated_props: dict = {
    "action": {
        "type": "string",
        "description": "Deprecated router action; prefer forge_session, forge_annotate, forge_query, forge_map, forge_verify.",
    },
    "sub_action": {"type": "string", "description": "Nested action for session/map/index/annotate/finding."},
    "project_path": {"type": "string", "description": "Project root."},
    "session_id": {"type": "string", "description": "EGMP session id."},
    "repo_root": {"type": "string", "description": "Repo root hint."},
    "annotation_id": {"type": "string", "description": "Single annotation id."},
    "ids": {"type": "array", "items": {"type": "string"}, "description": "Bulk ids."},
    "fields": {"type": "object", "additionalProperties": True, "description": "Bulk field updates."},
    "node_ref": {"type": "string", "description": "Manifest or audit node ref."},
    "graph": {"type": "string", "description": "Graph scope for queries."},
    "limit": {"type": "integer", "default": 10, "description": "List limit."},
    "offset": {"type": "integer", "default": 0, "description": "List offset."},
}

_forge_annotate_props: dict = {
    "action": {
        "type": "string",
        "enum": ["create", "update", "resolve", "promote", "dismiss", "bulk_dismiss", "bulk_update", "note", "list", "show"],
        "description": "Annotation action — create, update, resolve, promote, dismiss, list, show",
    },
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
    "annotation_id": {"type": "string", "description": "Annotation ID for update, resolve, promote, dismiss, or show"},
    "session_id": {"type": "string", "description": "Session id for action=note."},
    "kind": {"type": "string", "description": "Annotation kind — finding, debt, milestone, design-proposal, question"},
    "file": {"type": "string", "description": "Repo-relative file path this annotation applies to"},
    "title": {"type": "string", "description": "Short title summarising the finding or decision"},
    "content": {"type": "string", "description": "Full annotation body text"},
    "severity": {"type": "string", "enum": ["high", "medium", "low"], "description": "Severity level — high, medium, or low"},
    "horizon": {
        "type": "string",
        "enum": ["current", "next", "future", "deferred"],
        "description": "Planning horizon — current, next, future, or deferred",
    },
    "status": {"type": "string", "description": "New status for update action"},
    "resolution_note": {"type": "string", "description": "Explanation of how the finding was resolved"},
    "marker": {
        "type": "string",
        "enum": ["obs", "question", "surprise"],
        "description": "EGMP note marker (action=note).",
    },
    "ids": {"type": "array", "items": {"type": "string"}, "description": "Annotation ids for bulk_dismiss / bulk_update."},
    "fields": {
        "type": "object",
        "additionalProperties": True,
        "description": "Field map for bulk_update.",
    },
    "pipeline_refs": {"type": "array", "items": {"type": "string"}, "description": "Pipeline identifiers for create — maps to repeatable --pipeline-refs."},
    "tool_refs": {"type": "array", "items": {"type": "string"}, "description": "Forge tool names for create — maps to repeatable --tool-refs."},
    "response_tier": {
        "type": "string",
        "enum": ["L0", "L1", "L2"],
        "default": "L0",
        "description": "Response verbosity — L0 minimal, L1 standard, L2 full",
    },
}

_forge_manifest_props: dict = {
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
    "action": {
        "type": "string",
        "description": "Manifest operation — path, get, validate, schema, or migrate",
        "enum": ["path", "get", "validate", "schema", "migrate"],
    },
    "node_ref": {
        "type": "string",
        "description": "Node identifier for get action — e.g. module/core.manifest",
    },
    "field": {
        "type": "string",
        "description": "Specific field to read from a manifest node",
    },
    "project_name": {
        "type": "string",
        "description": "Project name for validate action",
    },
    "as_json": {
        "type": "boolean",
        "default": False,
        "description": "Return raw manifest as JSON instead of structured view",
    },
    "format": {
        "type": "string",
        "enum": ["raw", "graph", "index", "summary", "full", "criticality"],
        "default": "raw",
        "description": "Output format — raw YAML, graph, index, summary, full, criticality",
    },
    "section": {
        "type": "string",
        "description": "Manifest section to read — nodes, edges, or meta",
    },
    "scope": {
        "type": "string",
        "description": "Domain filter for graph and full format views",
    },
    "file": {
        "type": "string",
        "description": "Schema file path for action=migrate (CLI --file).",
    },
}

_forge_blast_radius_props: dict = {
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
    "node": {
        "type": "string",
        "description": "Manifest node name or id (CLI --node).",
    },
    "file": {
        "type": "string",
        "description": "Repo-relative file path resolved to a node (CLI --file).",
    },
}

_forge_verify_props: dict = {
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
    "target": {
        "type": "string",
        "default": "staged",
        "description": "Verification target — staged (git index), full (all files), unstaged",
    },
    "scope": {
        "type": "string",
        "enum": ["all", "parity", "stack"],
        "description": "Scope of structural checks to run",
    },
    "strict": {
        "type": "boolean",
        "default": False,
        "description": "Treat unknown manifest fields as hard errors",
    },
    "diff": {
        "type": "string",
        "enum": ["plan", "wiring", "contracts", "all"],
        "description": "Cross-graph diff mode. plan=planned vs present, wiring=present vs connected, contracts=connected vs compliant, all=run all three in sequence.",
    },
    "domain": {
        "type": "string",
        "description": "Filter diff output to a single domain. Used with diff parameter only.",
    },
    "preflight": {
        "type": "boolean",
        "description": "Run preflight check against .forge/app.manifest.yaml before any generation. Validates all planned connections and contracts.",
    },
    "packet": {
        "type": "string",
        "description": "Path to a context packet file. Validates freshness, review sign-off, graph hash, glove version, atomicity, and node existence in app manifest.",
    },
}

_forge_diff_props: dict = {
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
    "full": {
        "type": "boolean",
        "default": True,
        "description": "Show full diff instead of summary",
    },
    "out": {
        "type": "string",
        "description": "Output file path for the diff",
    },
    "scope": {
        "type": "string",
        "enum": ["repo", "domain", "file", "function", "parity"],
        "default": "repo",
        "description": "Diff scope — repo, domain, file, function, or parity",
    },
    "scope_target": {
        "type": "string",
        "description": "Deprecated alias for target= (CLI --target). Prefer target.",
    },
    "target": {
        "type": "string",
        "description": "Scope target: domain name, file path, or node id (CLI --target).",
    },
    "layer": {
        "type": "string",
        "enum": ["declaration", "execution", "all"],
        "default": "declaration",
        "description": "Diff layer — declaration, execution, or all",
    },
    "dry_run": {
        "type": "boolean",
        "default": False,
        "description": "Preview diff without making changes",
    },
    "promote_edges": {
        "type": "boolean",
        "default": False,
        "description": "Promote edges during diff processing",
    },
    "exit_code": {
        "type": "boolean",
        "default": False,
        "description": "Show exit code in output",
    },
    "contracts": {
        "type": "boolean",
        "default": False,
        "description": "Include contract violations in diff",
    },
    "intent": {
        "type": "boolean",
        "default": False,
        "description": "Include intent information in diff",
    },
}

_forge_trace_props: dict = {
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
    "entry_point": {
        "type": "string",
        "description": "Python function or method to trace",
    },
    "output": {
        "type": "string",
        "description": "Output file path for the trace results",
    },
    "format": {
        "type": "string",
        "enum": ["yaml", "json"],
        "default": "yaml",
        "description": "Output format for trace results",
    },
    "scope": {
        "type": "string",
        "enum": ["module", "full"],
        "default": "full",
        "description": "Trace scope — module or full",
    },
    "exit_code": {
        "type": "boolean",
        "default": False,
        "description": "Show exit code in trace output",
    },
}

_forge_github_write_props: dict = {
    "project_path": {
        "type": "string",
        "description": "Path to the site project root e.g. ~/Projects/astro-blog-site",
    },
    "repo_owner": {
        "type": "string",
        "description": "GitHub repo owner e.g. NT9V",
    },
    "repo_name": {
        "type": "string",
        "description": "GitHub repo name e.g. astro-blog-site",
    },
    "file_path": {
        "type": "string",
        "description": "Repo-relative file path e.g. src/content/posts/my-post.mdx",
    },
    "content": {
        "type": "string",
        "description": "Full file content (UTF-8 text)",
    },
    "commit_message": {
        "type": "string",
        "description": "Git commit message",
    },
}

_forge_report_props: dict = {
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
    "scope": {
        "type": "string",
        "enum": ["repo", "domain", "file", "function"],
        "default": "repo",
        "description": "Report scope — repo, domain, file, or function",
    },
    "target": {
        "type": "string",
        "description": "Target for the report scope",
    },
    "layer": {
        "type": "string",
        "enum": ["declaration", "execution", "all"],
        "default": "declaration",
        "description": "Report layer — declaration, execution, or all",
    },
    "format": {
        "type": "string",
        "enum": ["text", "json", "yaml"],
        "default": "json",
        "description": "Report output format",
    },
    "finding_id": {
        "type": "string",
        "description": "Specific finding ID to report on",
    },
    "exit_code": {
        "type": "boolean",
        "default": False,
        "description": "Show exit code in report output",
    },
}

_forge_query_props: dict = {
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
    "kind": {
        "type": "string",
        "description": "Node kind filter — module, domain, doc, index, or mcp_tool",
    },
    "domain": {
        "type": "string",
        "description": "Domain filter — CORE, MCP, COMMANDS, TOOLS, or other domain name",
    },
    "name": {
        "type": "string",
        "description": "Node name filter — partial match against node name field",
    },
    "depends_on": {
        "type": "string",
        "description": "Filter nodes that declare a dependency on this node id",
    },
    "limit": {
        "type": "integer",
        "default": 10,
        "description": "Maximum number of nodes to return",
    },
    "depth": {
        "type": "integer",
        "default": 1,
        "minimum": 1,
        "maximum": 3,
        "description": "BFS traversal depth for dependency expansion",
    },
    "direction": {
        "type": "string",
        "enum": ["in", "out", "both"],
        "default": "both",
        "description": "Edge traversal direction — inbound, outbound, or both",
    },
    "sort_by": {
        "type": "string",
        "enum": ["criticality", "name", "domain"],
        "description": "Sort field for results — name, tier, or criticality",
    },
    "expand_relevant": {
        "type": "boolean",
        "default": False,
        "description": "Include semantically related nodes in results",
    },
    "expand_domain": {
        "type": "string",
        "description": "Domain to expand relevant nodes from",
    },
    "expand_max_total": {
        "type": "integer",
        "default": 30,
        "description": "Maximum total nodes including expansions",
    },
    "tier": {
        "type": "string",
        "description": "Tier filter — surface, worker, registry, schema, or glove",
    },
}

_forge_intent_props: dict = {
    "action": {
        "type": "string",
        "enum": ["add", "query", "confirm", "deprecate", "specify"],
        "description": "Intent action — add, list, show, update, or link",
    },
    "raw_description": {
        "type": "string",
        "description": "Natural language description of the intended change",
    },
    "scope": {
        "type": "string",
        "enum": ["project", "feature", "node"],
        "default": "feature",
        "description": "Scope filter for list action",
    },
    "target_id": {
        "type": "string",
        "description": "Target node ID for link action",
    },
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
    "record_id": {
        "type": "string",
        "description": "Intent record ID for show, update, or link",
    },
    "design_intent_id": {
        "type": "string",
        "description": "Design intent id to link when action=specify.",
    },
    "target_node_id": {
        "type": "string",
        "description": "Manifest node id this functional intent specifies.",
    },
    "proposed_depends_on": {
        "type": "array",
        "items": {"type": "string"},
        "description": "Proposed dependency edges for functional intent.",
        "default": [],
    },
    "proposed_implements": {
        "type": "array",
        "items": {"type": "string"},
        "description": "Proposed contract/schema ids this intent should implement.",
        "default": [],
    },
    "proposed_tier": {
        "type": "string",
        "description": "Proposed NodeTier for the target node.",
        "default": "worker",
    },
    "acceptance_criteria": {
        "type": "array",
        "items": {"type": "string"},
        "description": "Verifiable acceptance criteria.",
        "default": [],
    },
}

_forge_pipeline_run_props: dict = {
    "pipeline_id": {
        "type": "string",
        "description": "Pipeline identifier (e.g. verify_gate).",
    },
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
    "context_overrides": {
        "type": "object",
        "description": "Optional context values merged into executor context before step resolution.",
        "default": {},
    },
}

_forge_packet_props: dict = {
    "node": {
        "type": "string",
        "description": "Target node name for packet assembly.",
    },
    "type": {
        "type": "string",
        "description": "Node type for packet assembly.",
    },
    "domain": {
        "type": "string",
        "description": "Uppercase domain key validated against glove.domains.",
    },
    "project_path": {
        "type": "string",
        "description": "Absolute path to project root. If omitted, resolved from CWD or registry.",
    },
    "deps": {
        "type": "array",
        "description": "Optional dependency node names.",
        "items": {"type": "string"},
        "default": [],
    },
    "methods": {
        "type": "array",
        "description": "Optional method signatures in name(param:Type)->Return format.",
        "items": {"type": "string"},
        "default": [],
    },
    "task": {
        "type": "string",
        "description": "Packet task mode.",
        "default": "generate",
    },
}

_RESPONSE_TIER_PROP_BASE: dict = {
    "type": "string",
    "enum": ["L0", "L1", "L2"],
    "description": "Response verbosity — L0 minimal, L1 standard, L2 full",
}


def _attach_response_tier(props: dict, default_tier: str) -> None:
    if "response_tier" in props:
        return
    prop = dict(_RESPONSE_TIER_PROP_BASE)
    prop["default"] = default_tier
    props["response_tier"] = prop


_RESPONSE_TIER_DEFAULTS: dict[str, str] = {
    "_forge_project_status_props": "L0",
    "_forge_audit_deprecated_props": "L1",
    "_forge_query_props": "L1",
    "_forge_manifest_props": "L1",
    "_forge_blast_radius_props": "L0",
    "_forge_verify_props": "L0",
    "_forge_scaffold_props": "L0",
    "_forge_annotate_props": "L0",
    "_forge_github_write_props": "L1",
}

for _name, _props in list(globals().items()):
    if not (_name.startswith("_forge_") and _name.endswith("_props") and isinstance(_props, dict)):
        continue
    _attach_response_tier(_props, _RESPONSE_TIER_DEFAULTS.get(_name, "L1"))

_forge_session_props.pop("response_tier", None)

_OUTPUT_SCHEMAS: dict[str, dict] = {
    "forge_orient": OrientResult.model_json_schema(),
    "forge_packet_assemble": PacketResult.model_json_schema(),
    "forge_manifest": ManifestResult.model_json_schema(),
    "forge_verify": VerifyResult.model_json_schema(),
    "forge_query": ForgeGraphQueryPayload.model_json_schema(),
    "forge_session": SessionResult.model_json_schema(),
    "forge_intent": IntentResult.model_json_schema(),
    "forge_pipeline_run": PipelineResult.model_json_schema(),
}

_READ_ONLY_IDEMPOTENT_ANNOTATION = types.ToolAnnotations(readOnlyHint=True, idempotentHint=True)
_IDEMPOTENT_ONLY_ANNOTATION = types.ToolAnnotations(idempotentHint=True)
_DESTRUCTIVE_ANNOTATION = types.ToolAnnotations(destructiveHint=True)

_TOOL_ANNOTATIONS: dict[str, types.ToolAnnotations] = {
    "forge_orient": _READ_ONLY_IDEMPOTENT_ANNOTATION,
    "forge_manifest": _READ_ONLY_IDEMPOTENT_ANNOTATION,
    "forge_query": _READ_ONLY_IDEMPOTENT_ANNOTATION,
    "forge_config_get": _READ_ONLY_IDEMPOTENT_ANNOTATION,
    "forge_template": _READ_ONLY_IDEMPOTENT_ANNOTATION,
    "forge_impact_check": _READ_ONLY_IDEMPOTENT_ANNOTATION,
    "forge_verify": _READ_ONLY_IDEMPOTENT_ANNOTATION,
    "forge_packet_assemble": _READ_ONLY_IDEMPOTENT_ANNOTATION,
    "forge_audit_scan": _IDEMPOTENT_ONLY_ANNOTATION,
    "forge_scaffold": _DESTRUCTIVE_ANNOTATION,
    "forge_github_write": _DESTRUCTIVE_ANNOTATION,
    "forge_manifest_append": _DESTRUCTIVE_ANNOTATION,
    "forge_intent": _DESTRUCTIVE_ANNOTATION,
    "forge_pipeline_run": _DESTRUCTIVE_ANNOTATION,
    "forge_session": _IDEMPOTENT_ONLY_ANNOTATION,
}


# Schema-only definitions; handlers register these via registry.register_tool().
FORGE_TOOLS: list[types.Tool] = [
    types.Tool(
        name="forge_context",
        description=_build_tool_description(
            "Get the current project FORGE-CONTEXT bundle (declaration from .forge/manifest.yaml); "
            "call at the start of project work.",
            _forge_context_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_context_props,
            "required": [],
        },
        outputSchema={
            "type": "object",
            "required": [],
            "properties": {}
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_project_status",
        description=_build_tool_description(
            "Single-call project snapshot returning project, phase, stack, current_task, "
            "blocker, and next_action (~20 tokens); prefer this over forge_context for "
            "session orientation.",
            _forge_project_status_props,
        ),
        inputSchema={
            "type": "object",
            "required": [],
            "properties": _forge_project_status_props,
        },
        outputSchema={
            "type": "object",
            "required": [],
            "properties": {}
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_impact_check",
        description=_build_tool_description(
            "Run change-impact / docs-audit rules against changed files (policy inputs live under "
            "docs/ and .forge/; declaration graph is .forge/manifest.yaml). "
            "Returns exit_code 0 (no triggers), 1 (advisory — triggered rules with "
            "warn-only or satisfied checks), 2 (required follow-up — serious violations) "
            "plus structured failures.",
            _forge_impact_check_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_impact_check_props,
            "required": ["project_path"],
        },
        outputSchema=ForgeImpactCheckOutput.model_json_schema(),
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": True,
            "requires_manifest": True,
            "requires_trace": False,
            "requires_contracts": False
        },
        annotations=_TOOL_ANNOTATIONS["forge_impact_check"],
    ),
    types.Tool(
        name="forge_config_get",
        description=_build_tool_description(
            "Read a value from the project's app_config.yaml (repo root or assets/) using dot-notation keys.",
            _forge_config_get_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_config_get_props,
            "required": ["key"],
        },
        outputSchema={
            "type": "object",
            "required": ["key", "value"],
            "properties": {
                "key": {"type": "string"},
                "value": {}
            }
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
        annotations=_TOOL_ANNOTATIONS["forge_config_get"],
    ),
    types.Tool(
        name="forge_config_set",
        description=_build_tool_description(
            "Write a value to the project's app_config.yaml (repo root or assets/); always prefer dry_run=true first.",
            _forge_config_set_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_config_set_props,
            "required": ["key"],
        },
        outputSchema={
            "type": "object",
            "required": ["ok"],
            "properties": {
                "ok": {"type": "boolean"},
                "key": {"type": "string"},
                "value": {}
            }
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_manifest_append",
        description=_build_tool_description(
            "Append validated module nodes to .forge/manifest.yaml using ManifestParser.append_node "
            "(C006 sanctioned write path).",
            _forge_manifest_append_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_manifest_append_props,
            "required": ["project_path", "nodes"],
        },
        outputSchema={
            "type": "object",
            "required": ["ok"],
            "properties": {
                "ok": {"type": "boolean"},
                "dry_run": {"type": "boolean"},
                "appended_ids": {"type": "array", "items": {"type": "string"}},
                "updated_node_count": {"type": "integer"},
                "manifest_path": {"type": "string"}
            }
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": True,
            "requires_manifest": True,
            "requires_trace": False,
            "requires_contracts": False
        },
        annotations=_TOOL_ANNOTATIONS["forge_manifest_append"],
    ),
    types.Tool(
        name="forge_scaffold",
        description=_build_tool_description(
            "Thin MCP wrapper: runs `forge scaffold pipeline` with node_type + intent_id "
            "(declaration append, then contract diff, best-effort trace, full triangulation; "
            "emit_spec skips downstream steps).",
            _forge_scaffold_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_scaffold_props,
            "required": ["project_path", "node_type", "intent_id"],
        },
        outputSchema={
            "type": "object",
            "required": ["exit_code"],
            "properties": {
                "exit_code": {"type": "integer"},
                "output": {"type": "string"},
                "node": {"type": "string"}
            }
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": True,
            "requires_manifest": True,
            "requires_trace": False,
            "requires_contracts": False
        },
        annotations=_TOOL_ANNOTATIONS["forge_scaffold"],
    ),
    types.Tool(
        name="forge_orient",
        description=_build_tool_description(
            "Dual-mode orientation tool. Call with no node for session orientation (replaces forge_project_status + forge_context + forge verify chain). Call with node= for scaffold orientation (resolves type, domain, contracts, deps, output paths, and wiring from manifest and glove — produces a ready context packet).\n\nALWAYS call this at session start instead of forge_project_status.\nALWAYS call this instead of forge_blast_radius when scaffolding a specific node. Never assume node parameters — this tool resolves them mechanically from the manifest.",
            _forge_orient_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_orient_props,
            "required": [],
        },
        outputSchema=ForgeOrientOutput.model_json_schema(),
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
        annotations=_TOOL_ANNOTATIONS["forge_orient"],
    ),
    types.Tool(
        name="forge_packet_assemble",
        description=_build_tool_description(
            "Assemble a context packet for a node — resolves glove contracts, manifest deps, output paths, and wiring patterns into a ready-to-execute packet. Returns packet path and summary. Human review and sign-off required before execution. Call this whenever scaffolding or fixing a specific node — do not use blast-radius or generic context calls as a substitute.",
            _forge_packet_assemble_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_packet_assemble_props,
            "required": ["node", "type", "domain"],
        },
        outputSchema=ForgePacketAssembleOutput.model_json_schema(),
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": True,
            "requires_manifest": True,
            "requires_trace": False,
            "requires_contracts": True
        },
        annotations=_TOOL_ANNOTATIONS["forge_packet_assemble"],
    ),
    types.Tool(
        name="forge_template_list",
        description=_build_tool_description(
            "List available templates from the glove-colocated YAML template registry.",
            {**_forge_template_props, "action": {"type": "string", "enum": ["list"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_template_props, "action": {"type": "string", "enum": ["list"]}},
            "required": ["action"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_template"],
    ),
    types.Tool(
        name="forge_template_show",
        description=_build_tool_description(
            "Show details of a specific template from the glove-colocated YAML template registry.",
            {**_forge_template_props, "action": {"type": "string", "enum": ["show"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_template_props, "action": {"type": "string", "enum": ["show"]}},
            "required": ["action", "template_id"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_template"],
    ),
    types.Tool(
        name="forge_template_schema",
        description=_build_tool_description(
            "Show the schema for the glove-colocated YAML template registry.",
            {**_forge_template_props, "action": {"type": "string", "enum": ["schema"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_template_props, "action": {"type": "string", "enum": ["schema"]}},
            "required": ["action"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_template"],
    ),
    types.Tool(
        name="forge_template_validate",
        description=_build_tool_description(
            "Validate templates in the glove-colocated YAML template registry.",
            {**_forge_template_props, "action": {"type": "string", "enum": ["validate"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_template_props, "action": {"type": "string", "enum": ["validate"]}},
            "required": ["action"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_template"],
    ),
    types.Tool(
        name="forge_map",
        description=_build_tool_description(
            "Rebuild map outputs from the live declaration graph rooted in .forge/ "
            "and return the result; run after any .forge/manifest.yaml change.",
            _forge_map_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_map_props,
            "required": [],
        },
        outputSchema={
            "type": "object",
            "required": ["format"],
            "properties": {
                "format": {"type": "string"},
                "scope": {"type": "string"},
                "domain": {"type": "string"},
                "nodes": {"type": "array", "items": {"type": "object"}},
                "edges": {"type": "array", "items": {"type": "object"}},
                "written_to": {"type": "string"}
            }
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    # ── Audit scan (repo-level, kept standalone — not folded into forge_audit) ─
    types.Tool(
        name="forge_audit_scan",
        description=_build_tool_description(
            "Run a repository-level audit scan in repo mode (global policy + scan + doctor) "
            "or meta mode (branch-point contextual audit for sibling layer and descendants). "
            "Scan embeds graph_health and sync_health scores; scan alone is not a pass/fail gate.",
            _forge_audit_scan_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_audit_scan_props,
            "required": ["mode"],
        },
        outputSchema={
            "type": "object",
            "required": ["exit_code", "scan_summary"],
            "properties": {
                "exit_code": {"type": "integer"},
                "scan_summary": {
                    "type": "object",
                    "properties": {
                        "graph_health": {"type": "integer"},
                        "sync_health": {"type": "integer"},
                        "severed": {"type": "integer"},
                        "orphans": {"type": "integer"},
                        "drift": {"type": "integer"}
                    }
                },
                "doctor_summary": {"type": "object"},
                "capabilities_report": {"type": "object"}
            }
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": True,
            "requires_manifest": True,
            "requires_trace": False,
            "requires_contracts": False
        },
        annotations=_TOOL_ANNOTATIONS["forge_audit_scan"],
    ),
    # ── Consolidated manifest reader (2 tools → 1) ───────────────────────────
    types.Tool(
        name="forge_manifest_path",
        description=_build_tool_description(
            "Get the file path for a specific manifest node.",
            {**_forge_manifest_props, "action": {"type": "string", "enum": ["path"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_manifest_props, "action": {"type": "string", "enum": ["path"]}},
            "required": ["action", "node_ref"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_manifest"],
    ),
    types.Tool(
        name="forge_manifest_get",
        description=_build_tool_description(
            "Get a specific manifest node or field from the declaration graph.",
            {**_forge_manifest_props, "action": {"type": "string", "enum": ["get"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_manifest_props, "action": {"type": "string", "enum": ["get"]}},
            "required": ["action", "node_ref"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_manifest"],
    ),
    types.Tool(
        name="forge_manifest_validate",
        description=_build_tool_description(
            "Validate a manifest project against the schema.",
            {**_forge_manifest_props, "action": {"type": "string", "enum": ["validate"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_manifest_props, "action": {"type": "string", "enum": ["validate"]}},
            "required": ["action", "project_name"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_manifest"],
    ),
    types.Tool(
        name="forge_manifest_schema",
        description=_build_tool_description(
            "Show the schema for the manifest format.",
            {**_forge_manifest_props, "action": {"type": "string", "enum": ["schema"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_manifest_props, "action": {"type": "string", "enum": ["schema"]}},
            "required": ["action"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_manifest"],
    ),
    types.Tool(
        name="forge_manifest_migrate",
        description=_build_tool_description(
            "Migrate a manifest to the latest schema version.",
            {**_forge_manifest_props, "action": {"type": "string", "enum": ["migrate"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_manifest_props, "action": {"type": "string", "enum": ["migrate"]}},
            "required": ["action"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_manifest"],
    ),
    # ── Pass 7: blast radius (was 2 tools) ────────────────────────────────────
    types.Tool(
        name="forge_blast_radius",
        description=_build_tool_description(
            "Thin CLI wrapper: ``forge blast-radius`` — Ring-2 dependents from --node or --file.",
            _forge_blast_radius_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_blast_radius_props,
            "required": [],
        },
        outputSchema={
            "type": "object",
            "required": ["ring"],
            "properties": {
                "ring": {"type": "array", "items": {"type": "object"}},
                "source_node_id": {"type": "string"},
                "watchers": {"type": "array", "items": {"type": "string"}},
                "dependents": {"type": "array", "items": {"type": "string"}},
                "siblings": {"type": "array", "items": {"type": "string"}},
                "domain_members": {"type": "array", "items": {"type": "string"}},
                "reason": {"type": "string"}
            }
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_verify",
        description=_build_tool_description(
            "Run forge verify with structural checks on git files.",
            {**_forge_verify_props, "mode": {"type": "string", "enum": ["structural"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_verify_props, "mode": {"type": "string", "enum": ["structural"]}},
            "required": [],
        },
        outputSchema=_OUTPUT_SCHEMAS["forge_verify"],
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_verify"],
    ),
    types.Tool(
        name="forge_verify_diff",
        description=_build_tool_description(
            "Run forge verify diff mode to compare graphs.",
            {**_forge_verify_props, "diff": {"type": "string", "enum": ["plan", "wiring", "contracts", "all"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_verify_props, "diff": {"type": "string", "enum": ["plan", "wiring", "contracts", "all"]}},
            "required": ["diff"],
        },
        outputSchema=_OUTPUT_SCHEMAS["forge_verify"],
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_verify"],
    ),
    types.Tool(
        name="forge_verify_preflight",
        description=_build_tool_description(
            "Run forge verify preflight mode to validate app.manifest.yaml.",
            {**_forge_verify_props, "preflight": {"type": "boolean", "default": True}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_verify_props, "preflight": {"type": "boolean", "default": True}},
            "required": [],
        },
        outputSchema=_OUTPUT_SCHEMAS["forge_verify"],
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_verify"],
    ),
    types.Tool(
        name="forge_verify_packet",
        description=_build_tool_description(
            "Run forge verify packet mode to validate a context packet.",
            {**_forge_verify_props, "packet": {"type": "string"}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_verify_props, "packet": {"type": "string"}},
            "required": ["packet"],
        },
        outputSchema=_OUTPUT_SCHEMAS["forge_verify"],
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_verify"],
    ),
    types.Tool(
        name="forge_trace",
        description=_build_tool_description(
            "Capture a Python call graph via sys.settrace for one entry callable; writes .forge/traces/ by default.",
            _forge_trace_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_trace_props,
            "required": ["entry_point"],
        },
        outputSchema={
            "type": "object",
            "required": ["nodes", "edges", "written_to"],
            "properties": {
                "nodes": {"type": "integer"},
                "edges": {"type": "integer"},
                "written_to": {"type": "string"},
                "scope_filter": {"type": "string"}
            }
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="packet",
        description=_build_tool_description(
            "Assemble a context packet for a node with resolved glove contracts, manifest deps, and output paths.",
            _forge_packet_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_packet_props,
            "required": ["node", "type", "domain"],
        },
        outputSchema={
            "type": "object",
            "required": ["node", "packet_path"],
            "properties": {
                "node": {"type": "string"},
                "packet_path": {"type": "string"},
                "contracts": {"type": "array", "items": {"type": "string"}},
                "deps_resolved": {"type": "integer"},
                "deps_planned": {"type": "integer"},
                "files_to_generate": {"type": "array", "items": {"type": "string"}}
            }
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": True,
            "requires_manifest": True,
            "requires_trace": False,
            "requires_contracts": True
        },
    ),
    types.Tool(
        name="forge_report",
        description=_build_tool_description(
            "Run contract violation report output (file:line:symbol:expected:actual).",
            _forge_report_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_report_props,
            "required": [],
        },
        outputSchema={
            "type": "object",
            "required": ["findings"],
            "properties": {
                "findings": {"type": "array", "items": {"type": "object"}},
                "contract_violations": {"type": "array", "items": {"type": "object"}},
                "count_by_issue_type": {"type": "object"}
            }
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="github_write",
        description=_build_tool_description(
            "Write or update a file in a GitHub repository via the GitHub API. "
            "Reads GITHUB_TOKEN from ~/Projects/.secrets/{project_name}/.env "
            "where project_name is derived from the project_path. "
            "Only writes to allowed content paths. Every write commits to "
            "the repo main branch and triggers Vercel auto-deploy. "
            "Returns commit SHA on success.\n\n"
            "ALLOWED PATHS: src/content/posts/, src/content/projects/, "
            "src/content/notes/, src/pages/about.astro\n\n"
            "ADR-018: scope project_path to the target site project.",
            _forge_github_write_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_github_write_props,
            "required": [
                "project_path",
                "repo_owner",
                "repo_name",
                "file_path",
                "content",
                "commit_message",
            ],
        },
        outputSchema={
            "type": "object",
            "required": ["commit_sha"],
            "properties": {
                "commit_sha": {"type": "string"},
                "file_path": {"type": "string"},
                "repo_owner": {"type": "string"},
                "repo_name": {"type": "string"},
                "status": {"type": "string"}
            }
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": True,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
        annotations=_TOOL_ANNOTATIONS["forge_github_write"],
    ),
    # ── forge_query — precise manifest graph queries ──────────────────────────
    types.Tool(
        name="forge_query",
        description=_build_tool_description(
            "Run precise manifest graph queries returning matching nodes with id, kind, "
            "domain, path, and direct edges; faster than forge_manifest for targeted lookups. "
            "Results include inbound_weight (int) and criticality (low/medium/high/critical) "
            "per node. Use sort_by='criticality' to rank by dependency weight.",
            _forge_query_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_query_props,
            "required": [],
        },
        outputSchema=_OUTPUT_SCHEMAS["forge_query"],
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
        annotations=_TOOL_ANNOTATIONS["forge_query"],
    ),
    types.Tool(
        name="forge_session_start",
        description=_build_tool_description(
            "Start a new EGMP session via ``forge audit`` CLI.",
            {**_forge_session_props, "action": {"type": "string", "enum": ["start"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_session_props, "action": {"type": "string", "enum": ["start"]}},
            "required": ["action"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_session"],
    ),
    types.Tool(
        name="forge_session_status",
        description=_build_tool_description(
            "Get the status of an EGMP session.",
            {**_forge_session_props, "action": {"type": "string", "enum": ["status"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_session_props, "action": {"type": "string", "enum": ["status"]}},
            "required": ["action"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_session"],
    ),
    types.Tool(
        name="forge_session_handoff",
        description=_build_tool_description(
            "Handoff an EGMP session to another context.",
            {**_forge_session_props, "action": {"type": "string", "enum": ["handoff"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_session_props, "action": {"type": "string", "enum": ["handoff"]}},
            "required": ["action", "session_id"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_session"],
    ),
    types.Tool(
        name="forge_session_pause",
        description=_build_tool_description(
            "Pause an EGMP session.",
            {**_forge_session_props, "action": {"type": "string", "enum": ["pause"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_session_props, "action": {"type": "string", "enum": ["pause"]}},
            "required": ["action", "session_id"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_session"],
    ),
    types.Tool(
        name="forge_session_phase_upsert",
        description=_build_tool_description(
            "Upsert a phase in an EGMP session.",
            {**_forge_session_props, "action": {"type": "string", "enum": ["phase_upsert"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_session_props, "action": {"type": "string", "enum": ["phase_upsert"]}},
            "required": ["action", "session_id", "phase_id"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_session"],
    ),
    types.Tool(
        name="forge_session_phase_status",
        description=_build_tool_description(
            "Get the status of a phase in an EGMP session.",
            {**_forge_session_props, "action": {"type": "string", "enum": ["phase_status"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_session_props, "action": {"type": "string", "enum": ["phase_status"]}},
            "required": ["action", "session_id"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_session"],
    ),
    types.Tool(
        name="forge_intent_add",
        description=_build_tool_description(
            "Create a new intent record in the intent graph.",
            {**_forge_intent_props, "action": {"type": "string", "enum": ["add"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_intent_props, "action": {"type": "string", "enum": ["add"]}},
            "required": ["action", "raw_description"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_intent"],
    ),
    types.Tool(
        name="forge_intent_query",
        description=_build_tool_description(
            "Query intent records with filters.",
            {**_forge_intent_props, "action": {"type": "string", "enum": ["query"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_intent_props, "action": {"type": "string", "enum": ["query"]}},
            "required": ["action"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_intent"],
    ),
    types.Tool(
        name="forge_intent_recent",
        description=_build_tool_description(
            "Get recent intent records.",
            {**_forge_intent_props, "action": {"type": "string", "enum": ["recent"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_intent_props, "action": {"type": "string", "enum": ["recent"]}},
            "required": ["action"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_intent"],
    ),
    types.Tool(
        name="forge_intent_confirm",
        description=_build_tool_description(
            "Confirm an intent record.",
            {**_forge_intent_props, "action": {"type": "string", "enum": ["confirm"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_intent_props, "action": {"type": "string", "enum": ["confirm"]}},
            "required": ["action", "record_id"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_intent"],
    ),
    types.Tool(
        name="forge_intent_deprecate",
        description=_build_tool_description(
            "Deprecate an intent record.",
            {**_forge_intent_props, "action": {"type": "string", "enum": ["deprecate"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_intent_props, "action": {"type": "string", "enum": ["deprecate"]}},
            "required": ["action", "record_id"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_intent"],
    ),
    types.Tool(
        name="forge_intent_specify",
        description=_build_tool_description(
            "Specify a functional intent linked to a design intent.",
            {**_forge_intent_props, "action": {"type": "string", "enum": ["specify"]}},
        ),
        inputSchema={
            "type": "object",
            "properties": {**_forge_intent_props, "action": {"type": "string", "enum": ["specify"]}},
            "required": ["action", "design_intent_id"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False,
        },
        annotations=_TOOL_ANNOTATIONS["forge_intent"],
    ),
    types.Tool(
        name="forge_pipeline_run",
        description=_build_tool_description(
            "Execute a typed pipeline descriptor step-by-step using the pipeline executor.",
            _forge_pipeline_run_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_pipeline_run_props,
            "required": ["pipeline_id"],
        },
        outputSchema=_OUTPUT_SCHEMAS["forge_pipeline_run"],
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
        annotations=_TOOL_ANNOTATIONS["forge_pipeline_run"],
    ),
    # Split forge_annotate tools
    types.Tool(
        name="forge_annotate_create",
        description="Create a new annotation on a file with kind, severity, title, and content.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string"},
                "title": {"type": "string"},
                "kind": {"type": "string", "enum": ["finding", "debt", "milestone", "design-proposal", "question"]},
                "severity": {"type": "string", "enum": ["high", "medium", "low"]},
                "file": {"type": "string"},
                "content": {"type": "string"},
                "horizon": {"type": "string", "enum": ["current", "next", "future", "deferred"]},
                "assigned": {"type": "string"},
                "expires_when": {"type": "string"},
                "adr_refs": {"type": "array", "items": {"type": "string"}},
                "pipeline_refs": {"type": "array", "items": {"type": "string"}},
                "tool_refs": {"type": "array", "items": {"type": "string"}},
                "response_tier": {"type": "string", "enum": ["L0", "L1", "L2"], "default": "L0"},
            },
            "required": ["title", "kind", "severity", "file", "content"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_annotate_update",
        description="Update an existing annotation with new status, content, or metadata.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string"},
                "annotation_id": {"type": "string"},
                "status": {"type": "string"},
                "content": {"type": "string"},
                "assigned": {"type": "string"},
                "expires_when": {"type": "string"},
                "git_issue": {"type": "string"},
                "response_tier": {"type": "string", "enum": ["L0", "L1", "L2"], "default": "L0"},
            },
            "required": ["annotation_id"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_annotate_resolve",
        description="Resolve an annotation with an explanation of how it was fixed.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string"},
                "annotation_id": {"type": "string"},
                "resolution_note": {"type": "string"},
                "response_tier": {"type": "string", "enum": ["L0", "L1", "L2"], "default": "L0"},
            },
            "required": ["annotation_id", "resolution_note"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_annotate_promote",
        description="Promote an annotation to higher priority or status.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string"},
                "annotation_id": {"type": "string"},
                "response_tier": {"type": "string", "enum": ["L0", "L1", "L2"], "default": "L0"},
            },
            "required": ["annotation_id"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_annotate_dismiss",
        description="Dismiss an annotation as no longer relevant.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string"},
                "annotation_id": {"type": "string"},
                "response_tier": {"type": "string", "enum": ["L0", "L1", "L2"], "default": "L0"},
            },
            "required": ["annotation_id"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_annotate_bulk_dismiss",
        description="Dismiss multiple annotations at once.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string"},
                "ids": {"type": "array", "items": {"type": "string"}},
                "response_tier": {"type": "string", "enum": ["L0", "L1", "L2"], "default": "L0"},
            },
            "required": ["ids"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_annotate_bulk_update",
        description="Update multiple annotations with field mappings.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string"},
                "ids": {"type": "array", "items": {"type": "string"}},
                "fields": {"type": "object", "additionalProperties": True},
                "response_tier": {"type": "string", "enum": ["L0", "L1", "L2"], "default": "L0"},
            },
            "required": ["ids", "fields"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_annotate_note",
        description="Add EGMP session notes with markers.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string"},
                "session_id": {"type": "string"},
                "marker": {"type": "string", "enum": ["obs", "question", "surprise"]},
                "content": {"type": "string"},
                "response_tier": {"type": "string", "enum": ["L0", "L1", "L2"], "default": "L0"},
            },
            "required": ["session_id", "marker"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_annotate_list",
        description="List annotations with optional status and kind filters.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string"},
                "status": {"type": "string"},
                "kind": {"type": "string"},
                "response_tier": {"type": "string", "enum": ["L0", "L1", "L2"], "default": "L0"},
            },
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_annotate_show",
        description="Show details of a specific annotation.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string"},
                "annotation_id": {"type": "string"},
                "response_tier": {"type": "string", "enum": ["L0", "L1", "L2"], "default": "L0"},
            },
            "required": ["annotation_id"],
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_init",
        description=(
            "Initialize a new Forge project. Creates manifest.yaml "
            "and .forge/context.json at stage:1. Runs non-interactively "
            "when name, intent, and stack are all provided. "
            "Use on an empty or new directory before any other Forge tool."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {
                    "type": "string",
                    "description": "Absolute path to the project directory"
                },
                "name": {"type": "string",
                         "description": "Project name (skips prompt)"},
                "intent": {"type": "string",
                         "description": "One-sentence description (skips prompt)"},
                "stack": {"type": "string",
                        "description": "flutter | python | web | other"},
            },
            "required": ["project_path"],
        },
        outputSchema={
            "type": "object",
            "required": [],
            "properties": {
                "ok": {"type": "boolean"},
                "stage": {"type": "integer"},
                "manifest_path": {"type": "string"},
                "vocabulary_seeded": {"type": "object"},
                "next_required": {"type": "string"},
                "nodes_preserved": {"type": "integer"},
            }
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_workspace",
        description=_build_tool_description(
            "Query and manage the workspace graph. "
            "The workspace is the topology of all Forge projects "
            "and their dependencies. "
            "Actions: status (list all projects), "
            "add (register a project), "
            "dependents (who depends on project_id), "
            "dependencies (what project_id depends on).",
            _forge_workspace_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_workspace_props,
            "required": ["action"],
        },
        outputSchema={
            "type": "object",
            "required": ["ok"],
            "properties": {
                "ok": {"type": "boolean"},
                "project_count": {"type": "integer"},
                "projects": {
                    "type": "array",
                    "items": {"type": "object"}
                },
                "workspace_path": {"type": "string"},
                "project_id": {"type": "string"},
                "dependents": {
                    "type": "array",
                    "items": {"type": "object"}
                },
                "dependencies": {
                    "type": "array",
                    "items": {"type": "object"}
                },
                "error": {"type": "string"},
                "added": {"type": "string"},
            }
        },
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_verify_events",
        description=_build_tool_description(
            "Verify event log integrity for a project. "
            "Reads today's event log and verifies the SHA-256 hash chain. "
            "Returns chain validation status and event count.",
            {
                "project_path": {
                    "type": "string",
                    "description": "Absolute path to the project directory",
                },
                "date": {
                    "type": "string",
                    "description": "Date to verify (YYYY-MM-DD). Defaults to today.",
                },
            },
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string"},
                "date": {"type": "string"},
            },
            "required": ["project_path"],
        },
        outputSchema=ForgeVerifyEventsOutput.model_json_schema(),
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
    types.Tool(
        name="forge_health_vector",
        description=_build_tool_description(
            "Unified health vector for a project. Returns all six health dimensions (graph_health, sync_health, infra_health, adi_score, brc_score, idr_score) plus overall status and healthy flag.",
            {
                "project_path": {
                    "type": "string",
                    "description": "Absolute path to the project directory",
                },
            },
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string"},
            },
            "required": ["project_path"],
        },
        outputSchema=ForgeHealthVectorOutput.model_json_schema(),
        errorSchema=ERROR_SCHEMA,
        contract={
            "requires_project_path": False,
            "requires_manifest": False,
            "requires_trace": False,
            "requires_contracts": False
        },
    ),
]


FORGE_DEPRECATED_TOOLS: list[types.Tool] = [
    types.Tool(
        name="audit",
        description=_build_tool_description(
            "Deprecated. Use forge_session, forge_annotate, forge_query, forge_map, forge_verify. "
            "Legacy fat router still accepts extra action-specific fields (additionalProperties).",
            _forge_audit_deprecated_props,
        ),
        inputSchema={
            "type": "object",
            "properties": _forge_audit_deprecated_props,
            "required": ["action"],
            "additionalProperties": True,
        },
    ),
]
