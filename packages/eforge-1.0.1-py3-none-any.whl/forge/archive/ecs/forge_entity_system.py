"""
Forge Entity System - Unity-inspired component architecture using Forge primitives.
Replaces Unity terminology with Forge's node/graph/manifest taxonomy.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Type, TypeVar, Union
from pathlib import Path

from forge.core.schemas import NodeTier
from forge.tools.manifest.graph import MANIFEST_NODE_KINDS, MANIFEST_EDGE_RELATIONS

T = TypeVar('T')


class NodeLifecycle(Enum):
    """Forge node runtime lifecycle (ECS). Not graph declaration NodeStatus in schemas."""
    DECLARED = "declared"
    IMPLEMENTED = "implemented"
    ACTIVE = "active"
    INACTIVE = "inactive"
    ORPHANED = "orphaned"
    DEPRECATED = "deprecated"


class ContractStatus(Enum):
    """Forge contract relationship status."""
    VALID = "valid"
    VIOLATION = "violation"
    PENDING = "pending"
    STALE = "stale"


@dataclass
class ForgeAspect:
    """Base aspect - Forge's version of Unity Component."""
    node: Optional[ForgeNode] = None
    status: NodeLifecycle = NodeLifecycle.DECLARED
    enabled: bool = True
    
    def activate(self):
        """Called when aspect is added to node."""
        self.status = NodeLifecycle.ACTIVE
    
    def update(self, context: Dict[str, Any]):
        """Called during node update cycle."""
        pass
    
    def deactivate(self):
        """Called when aspect is removed."""
        self.status = NodeLifecycle.INACTIVE
    
    def validate(self) -> List[str]:
        """Return validation errors, empty if valid."""
        return []


@dataclass
class ForgeHandler(ForgeAspect):
    """Base handler - Forge's version of Unity Script."""
    
    def start(self):
        """Called before first update cycle."""
        pass
    
    def on_enable(self):
        """Called when handler becomes active."""
        pass
    
    def on_disable(self):
        """Called when handler becomes inactive."""
        pass
    
    def update(self, context: Dict[str, Any]):
        """Override for per-tick logic."""
        super().update(context)


class ForgeNode:
    """
    Forge Node - Core entity using Forge's node/graph taxonomy.
    Acts like dict for flexibility but with structured behavior.
    """
    
    def __init__(self, node_id: str, kind: str, tier: NodeTier = NodeTier.WORKER):
        self.id = node_id
        self.kind = kind
        self.tier = tier
        self.name = node_id.split("/")[-1] if "/" in node_id else node_id
        self.path = ""
        self.domain = ""
        self.status = NodeLifecycle.DECLARED
        
        # Forge-specific attributes
        self._aspects: Dict[str, ForgeAspect] = {}
        self._properties: Dict[str, Any] = {}
        self._contracts: Dict[str, ContractStatus] = {}
        self._edges: List[ForgeEdge] = []
        self._tags: List[str] = []
        
        # Metadata from manifest
        self.meta: Dict[str, Any] = {}
    
    # Dict-like interface for flexibility
    def __getitem__(self, key: str) -> Any:
        """Get aspect, property, or contract by key."""
        return self._aspects.get(key) or self._properties.get(key)
    
    def __setitem__(self, key: str, value: Any):
        """Set aspect, property, or contract by key."""
        if isinstance(value, ForgeAspect):
            self.add_aspect(value, key)
        else:
            self._properties[key] = value
    
    def __contains__(self, key: str) -> bool:
        """Check if aspect, property, or contract exists."""
        return key in self._aspects or key in self._properties or key in self._contracts
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get with default value."""
        return self[key] if key in self else default
    
    # Aspect management (Forge's component system)
    def add_aspect(self, aspect: ForgeAspect, name: Optional[str] = None) -> ForgeAspect:
        """Add an aspect to this node."""
        aspect_name = name or aspect.__class__.__name__
        
        # Remove existing aspect of same type
        if aspect_name in self._aspects:
            self.remove_aspect(aspect_name)
        
        aspect.node = self
        aspect.activate()
        self._aspects[aspect_name] = aspect
        return aspect
    
    def get_aspect(self, aspect_type: Type[T]) -> Optional[T]:
        """Get aspect by type."""
        for aspect in self._aspects.values():
            if isinstance(aspect, aspect_type):
                return aspect
        return None
    
    def get_aspects(self, aspect_type: Type[T]) -> List[T]:
        """Get all aspects of type."""
        return [a for a in self._aspects.values() if isinstance(a, aspect_type)]
    
    def remove_aspect(self, name: str) -> Optional[ForgeAspect]:
        """Remove aspect by name."""
        aspect = self._aspects.pop(name, None)
        if aspect:
            aspect.deactivate()
        return aspect
    
    def has_aspect(self, aspect_type: Type[ForgeAspect]) -> bool:
        """Check if node has aspect type."""
        return self.get_aspect(aspect_type) is not None
    
    # Handler management (Forge's script system)
    def add_handler(self, handler: ForgeHandler, name: Optional[str] = None) -> ForgeHandler:
        """Add a handler aspect."""
        handler = self.add_aspect(handler, name)
        if isinstance(handler, ForgeHandler):
            handler.start()
        return handler
    
    # Property management
    def set_property(self, key: str, value: Any):
        """Set a simple property."""
        self._properties[key] = value
    
    def get_property(self, key: str, default: Any = None) -> Any:
        """Get a simple property."""
        return self._properties.get(key, default)
    
    # Contract management
    def add_contract(self, contract_id: str, status: ContractStatus = ContractStatus.PENDING):
        """Add a contract relationship."""
        self._contracts[contract_id] = status
    
    def get_contract_status(self, contract_id: str) -> Optional[ContractStatus]:
        """Get contract status."""
        return self._contracts.get(contract_id)
    
    def validate_contracts(self) -> Dict[str, List[str]]:
        """Validate all contracts and aspects."""
        results = {}
        
        # Validate aspects
        for name, aspect in self._aspects.items():
            errors = aspect.validate()
            if errors:
                results[f"aspect.{name}"] = errors
        
        # Validate contracts
        for contract_id, status in self._contracts.items():
            if status == ContractStatus.VIOLATION:
                results[f"contract.{contract_id}"] = [f"Contract violation: {contract_id}"]
        
        return results
    
    # Edge management (Forge's graph relationships)
    def add_edge(self, edge: ForgeEdge):
        """Add a graph edge."""
        if edge not in self._edges:
            self._edges.append(edge)
    
    def get_edges(self, relation: Optional[str] = None) -> List[ForgeEdge]:
        """Get edges, optionally filtered by relation."""
        if relation:
            return [e for e in self._edges if e.relation == relation]
        return self._edges.copy()
    
    def get_dependencies(self) -> List[ForgeEdge]:
        """Get dependency edges."""
        return [e for e in self._edges if e.relation in ("depends_on", "implements")]
    
    def get_consumers(self) -> List[ForgeEdge]:
        """Get edges where this node is the target."""
        return [e for e in self._edges if e.to_id == self.id]
    
    # Tag system
    def add_tag(self, tag: str):
        """Add a tag."""
        if tag not in self._tags:
            self._tags.append(tag)
    
    def has_tag(self, tag: str) -> bool:
        """Check if has tag."""
        return tag in self._tags
    
    def remove_tag(self, tag: str):
        """Remove a tag."""
        if tag in self._tags:
            self._tags.remove(tag)
    
    # Lifecycle
    def update(self, context: Optional[Dict[str, Any]] = None):
        """Update all active aspects."""
        if self.status != NodeLifecycle.ACTIVE:
            return
        
        ctx = context or {}
        for aspect in self._aspects.values():
            if aspect.enabled and aspect.status == NodeLifecycle.ACTIVE:
                aspect.update(ctx)
    
    def activate(self):
        """Activate this node."""
        self.status = NodeLifecycle.ACTIVE
        for aspect in self._aspects.values():
            if aspect.enabled:
                aspect.status = NodeLifecycle.ACTIVE
    
    def deactivate(self):
        """Deactivate this node."""
        self.status = NodeLifecycle.INACTIVE
        for aspect in self._aspects.values():
            aspect.status = NodeLifecycle.INACTIVE
    
    # Utility methods
    def get_active_aspects(self) -> List[ForgeAspect]:
        """Get all active aspects."""
        return [a for a in self._aspects.values() 
                if a.status == NodeLifecycle.ACTIVE and a.enabled]
    
    def to_manifest_dict(self) -> Dict[str, Any]:
        """Export to manifest-compatible dictionary."""
        return {
            "id": self.id,
            "kind": self.kind,
            "name": self.name,
            "path": self.path,
            "domain": self.domain,
            "tier": self.tier.value,
            "meta": self.meta,
            "properties": self._properties,
            "tags": self._tags,
            "contracts": {cid: status.value for cid, status in self._contracts.items()},
            "aspects": {
                name: {
                    "type": aspect.__class__.__name__,
                    "enabled": aspect.enabled,
                    "data": {k: v for k, v in aspect.__dict__.items() 
                            if k not in ('node', 'status', 'enabled')}
                }
                for name, aspect in self._aspects.items()
            }
        }
    
    @classmethod
    def from_manifest_dict(cls, data: Dict[str, Any]) -> ForgeNode:
        """Create from manifest dictionary."""
        node = cls(
            node_id=data["id"],
            kind=data["kind"],
            tier=NodeTier(data.get("tier", "worker"))
        )
        node.name = data.get("name", node.name)
        node.path = data.get("path", "")
        node.domain = data.get("domain", "")
        node.meta = data.get("meta", {})
        node._properties = data.get("properties", {})
        node._tags = data.get("tags", [])

        # GAP 1 FIX — restore status from data
        status_str = data.get("status", "declared")
        status_map = {s.value: s for s in NodeLifecycle}
        node.status = status_map.get(status_str, NodeLifecycle.DECLARED)

        # Reconstruct contracts
        for contract_id, status_str in data.get("contracts", {}).items():
            node.add_contract(contract_id, ContractStatus(status_str))

        # GAP 2 FIX — restore edges from data
        # Only add edges whose relation is in MANIFEST_EDGE_RELATIONS
        # "imports" from graph JSON maps to "depends_on" in entity vocab
        EDGE_VOCAB_MAP = {"imports": "depends_on"}
        for edge_data in data.get("edges", []):
            raw_relation = edge_data.get("kind") or edge_data.get("relation", "")
            relation = EDGE_VOCAB_MAP.get(raw_relation, raw_relation)
            if relation in MANIFEST_EDGE_RELATIONS:
                try:
                    edge = ForgeEdge(
                        from_id=edge_data.get("from") or edge_data.get("from_id", ""),
                        to_id=edge_data.get("to") or edge_data.get("to_id", ""),
                        relation=relation,
                        metadata=edge_data.get("metadata", {})
                    )
                    node.add_edge(edge)
                except ValueError:
                    pass  # skip invalid edges silently

        # GAP 3 FIX — attach default aspects via registry
        from forge.archive.ecs.forge_entity_system import _global_registry
        template = _global_registry._node_templates.get(node.kind, {})
        for aspect_name, aspect_config in template.get("aspects", {}).items():
            if aspect_name in _global_registry._aspect_factories:
                aspect_type = _global_registry._aspect_factories[aspect_name]
                try:
                    aspect = aspect_type(**aspect_config)
                    node.add_aspect(aspect, aspect_name)
                except Exception:
                    pass  # skip if aspect construction fails

        return node


@dataclass
class ForgeEdge:
    """Forge graph edge - represents relationships between nodes."""
    from_id: str
    to_id: str
    relation: str  # From MANIFEST_EDGE_RELATIONS
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        if self.relation not in MANIFEST_EDGE_RELATIONS:
            raise ValueError(f"Invalid edge relation: {self.relation}")


# Forge-specific Aspects
@dataclass
class ManifestAspect(ForgeAspect):
    """Handles manifest synchronization."""
    manifest_path: str = ""
    auto_sync: bool = True
    last_sync: Optional[str] = None
    
    def update(self, context: Dict[str, Any]):
        """Check for manifest changes."""
        if self.auto_sync and self.node:
            # Would implement manifest sync logic here
            pass
    
    def validate(self) -> List[str]:
        """Validate manifest configuration."""
        errors = []
        if not self.manifest_path:
            errors.append("Manifest path not specified")
        return errors


@dataclass
class TierAspect(ForgeAspect):
    """Manages node tier behavior and import rules."""
    allowed_imports: List[NodeTier] = field(default_factory=list)
    
    def activate(self):
        """Set up tier-specific behavior."""
        super().activate()
        if not self.allowed_imports and self.node:
            # Set default import rules based on tier
            from forge.core.impact import TIER_IMPORT_RULES
            self.allowed_imports = TIER_IMPORT_RULES.get(self.node.tier, [])
    
    def validate(self) -> List[str]:
        """Validate tier compliance."""
        errors = []
        if self.node and self.node.kind not in MANIFEST_NODE_KINDS:
            errors.append(f"Invalid node kind: {self.node.kind}")
        return errors


@dataclass
class ContractAspect(ForgeAspect):
    """Manages contract relationships."""
    required_contracts: List[str] = field(default_factory=list)
    provided_contracts: List[str] = field(default_factory=list)
    
    def validate(self) -> List[str]:
        """Validate contract compliance."""
        errors = []
        if self.node:
            for contract in self.required_contracts:
                status = self.node.get_contract_status(contract)
                if not status or status == ContractStatus.VIOLATION:
                    errors.append(f"Required contract not satisfied: {contract}")
        return errors


@dataclass
class HealthAspect(ForgeAspect):
    """Monitors node health metrics."""
    health_score: int = 100
    issues: List[str] = field(default_factory=list)
    
    def update(self, context: Dict[str, Any]):
        """Update health metrics."""
        if self.node:
            # Collect validation issues
            validation_results = self.node.validate_contracts()
            self.issues = []
            for category, errors in validation_results.items():
                self.issues.extend(f"{category}: {error}" for error in errors)
            
            # Calculate health score
            self.health_score = max(0, 100 - len(self.issues) * 10)
    
    def get_health_summary(self) -> Dict[str, Any]:
        """Get health summary."""
        return {
            "score": self.health_score,
            "status": "healthy" if self.health_score >= 80 else "degraded" if self.health_score >= 50 else "unhealthy",
            "issues": self.issues.copy()
        }


# Forge-specific Handlers
class LifecycleHandler(ForgeHandler):
    """Handles node lifecycle events."""
    
    def start(self):
        """Initialize lifecycle."""
        if self.node:
            print(f"Starting node lifecycle: {self.node.id}")
    
    def update(self, context: Dict[str, Any]):
        """Process lifecycle updates."""
        if self.node:
            # Would implement lifecycle logic here
            pass


class SyncHandler(ForgeHandler):
    """Handles synchronization with external systems."""
    
    def update(self, context: Dict[str, Any]):
        """Sync node state."""
        if self.node:
            manifest = self.node.get_aspect(ManifestAspect)
            if manifest and manifest.auto_sync:
                # Would implement sync logic here
                pass


class ComplianceHandler(ForgeHandler):
    """Handles compliance checking."""
    
    def update(self, context: Dict[str, Any]):
        """Check compliance."""
        if self.node:
            tier = self.node.get_aspect(TierAspect)
            if tier:
                errors = tier.validate()
                if errors:
                    # Would handle compliance violations
                    pass


# Node Registry and Factory
class ForgeNodeRegistry:
    """Registry for node types and their default aspects."""
    
    def __init__(self):
        self._node_templates: Dict[str, Dict[str, Any]] = {}
        self._aspect_factories: Dict[str, Type[ForgeAspect]] = {}
        self._handler_factories: Dict[str, Type[ForgeHandler]] = {}
    
    def register_node_template(self, node_kind: str, template: Dict[str, Any]):
        """Register a node template."""
        self._node_templates[node_kind] = template
    
    def register_aspect(self, name: str, aspect_type: Type[ForgeAspect]):
        """Register an aspect type."""
        self._aspect_factories[name] = aspect_type
    
    def register_handler(self, name: str, handler_type: Type[ForgeHandler]):
        """Register a handler type."""
        self._handler_factories[name] = handler_type
    
    def create_node(self, node_id: str, kind: str, **kwargs) -> ForgeNode:
        """Create a node from registered templates."""
        node = ForgeNode(node_id, kind, **kwargs)
        
        # Apply template if exists
        template = self._node_templates.get(kind, {})
        
        # Add default aspects
        for aspect_name, aspect_config in template.get("aspects", {}).items():
            if aspect_name in self._aspect_factories:
                aspect_type = self._aspect_factories[aspect_name]
                aspect = aspect_type(**aspect_config)
                node.add_aspect(aspect, aspect_name)
        
        # Add default handlers
        for handler_name, handler_config in template.get("handlers", {}).items():
            if handler_name in self._handler_factories:
                handler_type = self._handler_factories[handler_name]
                handler = handler_type(**handler_config)
                node.add_handler(handler, handler_name)
        
        return node


# Global registry
_global_registry = ForgeNodeRegistry()

# Register built-in aspects and handlers
_global_registry.register_aspect("manifest", ManifestAspect)
_global_registry.register_aspect("tier", TierAspect)
_global_registry.register_aspect("contract", ContractAspect)
_global_registry.register_aspect("health", HealthAspect)

_global_registry.register_handler("lifecycle", LifecycleHandler)
_global_registry.register_handler("sync", SyncHandler)
_global_registry.register_handler("compliance", ComplianceHandler)

# Register default templates for common node kinds
_global_registry.register_node_template("controller", {
    "aspects": {
        "manifest": {"auto_sync": True},
        "tier": {},
        "health": {}
    },
    "handlers": {
        "lifecycle": {},
        "sync": {},
        "compliance": {}
    }
})

_global_registry.register_node_template("service", {
    "aspects": {
        "manifest": {"auto_sync": True},
        "tier": {},
        "contract": {"required_contracts": ["service_interface"]},
        "health": {}
    },
    "handlers": {
        "lifecycle": {},
        "sync": {},
        "compliance": {}
    }
})

_global_registry.register_node_template("module", {
    "aspects": {
        "manifest": {"auto_sync": False},
        "tier": {},
        "health": {}
    },
    "handlers": {
        "lifecycle": {},
        "compliance": {}
    }
})


def get_registry() -> ForgeNodeRegistry:
    """Get the global node registry."""
    return _global_registry


def create_node(node_id: str, kind: str, **kwargs) -> ForgeNode:
    """Create a node using the global registry."""
    return _global_registry.create_node(node_id, kind, **kwargs)


# Usage Examples
def example_usage():
    """Example of Forge Entity System usage."""
    
    # Create nodes using registry
    controller = create_node("app/user_controller", "controller")
    service = create_node("app/user_service", "service")
    module = create_node("lib/auth", "module")
    
    # Dict-like access
    controller["custom_property"] = "value"
    controller["health"].health_score = 95
    
    # Add custom aspects
    class CustomAspect(ForgeAspect):
        def validate(self):
            return []
    
    controller.add_aspect(CustomAspect())
    
    # Create edges
    edge = ForgeEdge(
        from_id="app/user_controller",
        to_id="app/user_service", 
        relation="depends_on"
    )
    controller.add_edge(edge)
    
    # Update cycle
    controller.update()
    service.update()
    
    # Export to manifest
    manifest_data = controller.to_manifest_dict()
    
    return controller, service, module
