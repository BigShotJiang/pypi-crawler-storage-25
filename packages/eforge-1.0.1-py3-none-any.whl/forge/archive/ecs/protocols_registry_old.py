from pathlib import Path
from typing import Type
import importlib
import yaml

from .glove import GloveProtocol

class GloveRegistry:
    """
    Discovers and loads GloveProtocol implementations.

    Discovery path: .forge/gloves/{stack}/glove.yaml
    Each glove.yaml declares:
        stack: flutter
        entry: forge.gloves.flutter.FlutterGlove  # importable path
        version: 1.0.0
        min_forge_version: 0.1.0

    Built-in gloves are registered via register_builtin().
    External gloves are discovered via discover().
    """

    def __init__(self):
        self._registry: dict[str, GloveProtocol] = {}

    def register(self, glove: GloveProtocol) -> None:
        """Register a glove instance by its declared stack."""
        self._registry[glove.stack] = glove

    def register_builtin(
        self, glove_class: Type[GloveProtocol]
    ) -> None:
        """Register a built-in glove from a class."""
        self.register(glove_class())

    def discover(self, forge_dir: Path) -> list[str]:
        """
        Discover external gloves from .forge/gloves/.
        Returns list of successfully loaded stack names.
        Never raises — failed discovery is logged, not fatal.
        """
        discovered = []
        gloves_dir = forge_dir / "gloves"
        if not gloves_dir.exists():
            return discovered

        for stack_dir in gloves_dir.iterdir():
            if not stack_dir.is_dir():
                continue
            glove_yaml = stack_dir / "glove.yaml"
            if not glove_yaml.exists():
                continue
            try:
                config = yaml.safe_load(
                    glove_yaml.read_text()
                )
                entry = config.get("entry", "")
                if not entry:
                    continue
                module_path, class_name = entry.rsplit(".", 1)
                module = importlib.import_module(module_path)
                glove_class = getattr(module, class_name)
                instance = glove_class()
                self.register(instance)
                discovered.append(instance.stack)
            except Exception:
                continue   # failed glove never breaks Forge

        return discovered

    def get(self, stack: str) -> GloveProtocol | None:
        return self._registry.get(stack)

    def get_for_project(
        self, project_path: Path
    ) -> GloveProtocol | None:
        """
        Return the first registered glove that handles
        the project at project_path.
        """
        for glove in self._registry.values():
            if glove.handles(project_path):
                return glove
        return None

    def all_stacks(self) -> list[str]:
        return list(self._registry.keys())

    def registry_nodes(self) -> list[dict]:
        """
        Returns universal node dicts for all registered gloves.
        Used to populate the workspace graph GLOVES domain.
        """
        return [g.to_registry_node()
                for g in self._registry.values()]


# Module-level singleton
_global_registry = GloveRegistry()

def get_glove_registry() -> GloveRegistry:
    return _global_registry

# Register built-in gloves
# (after imports to avoid circular imports)
def _register_builtins() -> None:
    try:
        from ..gloves.adapters import PythonGloveAdapter
        _global_registry.register(PythonGloveAdapter())
    except ImportError:
        pass
    try:
        from ..gloves.adapters import DartGloveAdapter
        _global_registry.register(DartGloveAdapter())
    except ImportError:
        pass
    try:
        from ..gloves.adapters import ReactGloveAdapter
        _global_registry.register(ReactGloveAdapter())
    except ImportError:
        pass
    try:
        from ..gloves.adapters import SQLGloveAdapter
        _global_registry.register(SQLGloveAdapter())
    except ImportError:
        pass

_register_builtins()
