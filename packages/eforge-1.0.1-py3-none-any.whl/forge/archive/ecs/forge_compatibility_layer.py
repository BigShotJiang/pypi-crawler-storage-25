"""
Forge Compatibility Layer - Systematic integration of all Forge modules with component architecture.
Provides unified compatibility layer for existing dict-based Forge systems.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Type, TypeVar, Union, Callable
from pathlib import Path
import functools

from forge.core.forge_project_system import ForgeProject, ForgeEntity
from forge.archive.ecs.graph_component_adapter import GraphComponentAdapter
from forge.core.forge_project_system import (
    GloveComponent, StackProfileComponent, ImportResolutionComponent,
    SemanticAnalysisComponent, FrameworkDetectionComponent, ContractValidationComponent,
    MetricsComponent, TraceComponent, EventComponent
)

T = TypeVar('T')


class ForgeCompatibilityLayer:
    """
    Universal compatibility layer for all Forge modules.
    Makes every existing Forge system work with component architecture.
    """
    
    def __init__(self, project: ForgeProject):
        self.project = project
        self.adapters: Dict[str, Any] = {}
        self.patched_functions: Dict[str, Callable] = {}
        self.module_patches: Dict[str, Dict[str, Callable]] = {}
        
        # Initialize core adapters
        self.graph_adapter = GraphComponentAdapter(project)
        self.adapters["graph"] = self.graph_adapter
        
        # Component registry for dynamic creation
        self.component_registry: Dict[str, Type] = {}
        self._register_builtin_components()
    
    # === COMPONENT REGISTRY ===
    
    def _register_builtin_components(self):
        """Register all built-in component types."""
        from forge.core.forge_project_system import (
            GraphComponent, ManifestGraphComponent, ExecutionGraphComponent,
            GloveComponent, StackProfileComponent, ImportResolutionComponent,
            SemanticAnalysisComponent, FrameworkDetectionComponent,
            ContractValidationComponent, MetricsComponent, TraceComponent, EventComponent
        )
        
        self.component_registry.update({
            "graph": GraphComponent,
            "manifest_graph": ManifestGraphComponent,
            "execution_graph": ExecutionGraphComponent,
            "glove": GloveComponent,
            "stack_profile": StackProfileComponent,
            "import_resolution": ImportResolutionComponent,
            "semantic_analysis": SemanticAnalysisComponent,
            "framework_detection": FrameworkDetectionComponent,
            "contract_validation": ContractValidationComponent,
            "metrics": MetricsComponent,
            "trace": TraceComponent,
            "event": EventComponent
        })
    
    def register_component_type(self, name: str, component_type: Type):
        """Register a custom component type."""
        self.component_registry[name] = component_type
    
    def create_component(self, component_type: str, **kwargs) -> Any:
        """Create a component instance by type name."""
        if component_type not in self.component_registry:
            raise ValueError(f"Unknown component type: {component_type}")
        return self.component_registry[component_type](**kwargs)
    
    # === MODULE PATCHING SYSTEM ===
    
    def patch_module(self, module_path: str, function_patches: Dict[str, str]):
        """Patch a module with component-compatible functions."""
        try:
            # Import the module
            module_parts = module_path.split('.')
            module = __import__(module_path)
            for part in module_parts[1:]:
                module = getattr(module, part)
            
            # Store original functions
            if module_path not in self.module_patches:
                self.module_patches[module_path] = {}
            
            for func_name, func_signature in function_patches.items():
                if hasattr(module, func_name):
                    original_func = getattr(module, func_name)
                    self.module_patches[module_path][func_name] = original_func
                    
                    # Create patched function
                    patched_func = self._create_patched_function(
                        original_func, func_name, func_signature
                    )
                    
                    # Apply patch
                    setattr(module, func_name, patched_func)
                    self.patched_functions[f"{module_path}.{func_name}"] = patched_func
        
        except Exception as e:
            print(f"Failed to patch {module_path}: {e}")
    
    def _create_patched_function(self, original_func: Callable, func_name: str, signature: str) -> Callable:
        """Create a patched version of a function."""
        
        @functools.wraps(original_func)
        def patched_function(*args, **kwargs):
            # Inject project context
            kwargs['_compatibility_layer'] = self
            kwargs['_project'] = self.project
            
            # Inject graph adapter
            kwargs['_graph_adapter'] = self.graph_adapter
            
            # Inject component registry
            kwargs['_component_registry'] = self.component_registry
            
            # Call original function
            try:
                result = original_func(*args, **kwargs)
                return result
            except Exception as e:
                print(f"Error in patched {func_name}: {e}")
                raise
        
        return patched_function
    
    # === FORGE/MCP INTEGRATION ===
    
    def patch_mcp_handlers(self):
        """Patch all MCP handlers to use component system."""
        mcp_patches = {
            "forge.mcp.handlers": {
                "handle_forge_health_vector": "patch_health_vector_handler",
                "handle_forge_project_status": "patch_project_status_handler", 
                "handle_forge_verify": "patch_verify_handler",
                "handle_forge_orient": "patch_orient_handler",
                "handle_forge_audit_scan": "patch_audit_scan_handler",
                "handle_forge_annotate": "patch_annotate_handler"
            },
            "forge.mcp.tools": {
                "register_builtin_tools": "patch_tool_registration"
            }
        }
        
        for module_path, patches in mcp_patches.items():
            self.patch_module(module_path, patches)
    
    def patch_health_vector_handler(self, original_func: Callable) -> Callable:
        """Patch health vector handler to use components."""
        @functools.wraps(original_func)
        def patched_handler(arguments: dict[str, Any]) -> Any:
            # Extract project path
            project_path = arguments.get('project_path')
            if not project_path:
                return original_func(arguments)
            
            # Ensure project exists
            if not self.project or str(self.project.root_path) != project_path:
                from forge.core.forge_project_system import create_project
                self.project = create_project(Path(project_path))
                self.graph_adapter.project = self.project
            
            # Add metrics component if not exists
            project_entity = self.project.get_entity("health_monitor")
            if not project_entity:
                from forge.core.forge_project_system import MetricsComponent
                project_entity = ForgeEntity("health_monitor", "monitor")
                project_entity.add_component(MetricsComponent(
                    metric_types=["health", "performance", "usage"],
                    collection_interval=1.0
                ))
                self.project.add_entity(project_entity)
            
            # Call original with enhanced context
            enhanced_args = arguments.copy()
            enhanced_args['_metrics_component'] = project_entity.get_component(MetricsComponent)
            
            return original_func(enhanced_args)
        
        return patched_handler
    
    def patch_project_status_handler(self, original_func: Callable) -> Callable:
        """Patch project status handler to use components."""
        @functools.wraps(original_func)
        def patched_handler(arguments: dict[str, Any]) -> Any:
            project_path = arguments.get('project_path')
            if project_path and str(self.project.root_path) != project_path:
                from forge.core.forge_project_system import create_project
                self.project = create_project(Path(project_path))
                self.graph_adapter.project = self.project
            
            # Add graph component for status tracking
            status_entity = self.project.get_entity("status_tracker")
            if not status_entity:
                from forge.core.forge_project_system import GraphComponent
                status_entity = ForgeEntity("status_tracker", "tracker")
                status_entity.add_component(GraphComponent(
                    graph_type="manifest",
                    auto_load=True
                ))
                self.project.add_entity(status_entity)
            
            return original_func(arguments)
        
        return patched_handler
    
    def patch_verify_handler(self, original_func: Callable) -> Callable:
        """Patch verify handler to use components."""
        @functools.wraps(original_func)
        def patched_handler(arguments: dict[str, Any]) -> Any:
            project_path = arguments.get('project_path')
            if project_path and str(self.project.root_path) != project_path:
                from forge.core.forge_project_system import create_project
                self.project = create_project(Path(project_path))
                self.graph_adapter.project = self.project
            
            # Add contract validation component
            verify_entity = self.project.get_entity("verify_checker")
            if not verify_entity:
                from forge.core.forge_project_system import ContractValidationComponent
                verify_entity = ForgeEntity("verify_checker", "validator")
                verify_entity.add_component(ContractValidationComponent())
                self.project.add_entity(verify_entity)
            
            return original_func(arguments)
        
        return patched_handler
    
    def patch_orient_handler(self, original_func: Callable) -> Callable:
        """Patch orient handler to use components."""
        @functools.wraps(original_func)
        def patched_handler(arguments: dict[str, Any]) -> Any:
            project_path = arguments.get('project_path')
            if project_path and str(self.project.root_path) != project_path:
                from forge.core.forge_project_system import create_project
                self.project = create_project(Path(project_path))
                self.graph_adapter.project = self.project
            
            # Add semantic analysis component
            orient_entity = self.project.get_entity("orient_analyzer")
            if not orient_entity:
                from forge.core.forge_project_system import SemanticAnalysisComponent
                orient_entity = ForgeEntity("orient_analyzer", "analyzer")
                orient_entity.add_component(SemanticAnalysisComponent(
                    analyzer_type="hybrid",
                    confidence_threshold=0.7
                ))
                self.project.add_entity(orient_entity)
            
            return original_func(arguments)
        
        return patched_handler
    
    def patch_audit_scan_handler(self, original_func: Callable) -> Callable:
        """Patch audit scan handler to use components."""
        @functools.wraps(original_func)
        def patched_handler(arguments: dict[str, Any]) -> Any:
            project_path = arguments.get('project_path')
            if project_path and str(self.project.root_path) != project_path:
                from forge.core.forge_project_system import create_project
                self.project = create_project(Path(project_path))
                self.graph_adapter.project = self.project
            
            # Add metrics and trace components
            audit_entity = self.project.get_entity("audit_tracker")
            if not audit_entity:
                from forge.core.forge_project_system import MetricsComponent, TraceComponent
                audit_entity = ForgeEntity("audit_tracker", "tracker")
                audit_entity.add_component(MetricsComponent(
                    metric_types=["audit_findings", "coverage", "compliance"]
                ))
                audit_entity.add_component(TraceComponent(
                    trace_enabled=True,
                    trace_storage="memory"
                ))
                self.project.add_entity(audit_entity)
            
            return original_func(arguments)
        
        return patched_handler
    
    def patch_annotate_handler(self, original_func: Callable) -> Callable:
        """Patch annotate handler to use components."""
        @functools.wraps(original_func)
        def patched_handler(arguments: dict[str, Any]) -> Any:
            project_path = arguments.get('project_path')
            if project_path and str(self.project.root_path) != project_path:
                from forge.core.forge_project_system import create_project
                self.project = create_project(Path(project_path))
                self.graph_adapter.project = self.project
            
            # Add event component for annotation tracking
            annotation_entity = self.project.get_entity("annotation_tracker")
            if not annotation_entity:
                from forge.core.forge_project_system import EventComponent
                annotation_entity = ForgeEntity("annotation_tracker", "tracker")
                annotation_entity.add_component(EventComponent(
                    processing_enabled=True
                ))
                self.project.add_entity(annotation_entity)
            
            return original_func(arguments)
        
        return patched_handler
    
    def patch_tool_registration(self, original_func: Callable) -> Callable:
        """Patch tool registration to use components."""
        @functools.wraps(original_func)
        def patched_function(*args, **kwargs):
            # Add glove component for tool management
            tools_entity = self.project.get_entity("tool_manager")
            if not tools_entity:
                from forge.core.forge_project_system import GloveComponent
                tools_entity = ForgeEntity("tool_manager", "manager")
                tools_entity.add_component(GloveComponent(
                    stack="universal",
                    auto_discover=True
                ))
                self.project.add_entity(tools_entity)
            
            return original_func(*args, **kwargs)
        
        return patched_function
    
    # === PROTOCOL INTEGRATION ===
    
    def patch_protocols(self):
        """Patch all protocol systems to use components."""
        protocol_patches = {
            "forge.protocols.glove": {
                "GloveProtocol": "patch_glove_protocol"
            },
            "forge.protocols.checker": {
                "CheckerProtocol": "patch_checker_protocol"
            },
            "forge.protocols.subscriber": {
                "SubscriberProtocol": "patch_subscriber_protocol"
            }
        }
        
        for module_path, patches in protocol_patches.items():
            self.patch_module(module_path, patches)
    
    def patch_glove_protocol(self, original_class: Type) -> Type:
        """Patch GloveProtocol to use components."""
        class PatchedGloveProtocol(original_class):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                # Add glove component to registry
                if hasattr(self, 'stack'):
                    glove_entity = ForgeEntity(f"glove_{self.stack}", "glove")
                    from forge.core.forge_project_system import GloveComponent
                    glove_entity.add_component(GloveComponent(
                        stack=self.stack,
                        auto_discover=True
                    ))
                    # This would need access to the project - for now, just create the entity
        
        return PatchedGloveProtocol
    
    def patch_checker_protocol(self, original_class: Type) -> Type:
        """Patch CheckerProtocol to use components."""
        class PatchedCheckerProtocol(original_class):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                # Add metrics component for checker
                checker_entity = ForgeEntity(f"checker_{self.__class__.__name__}", "checker")
                from forge.core.forge_project_system import MetricsComponent
                checker_entity.add_component(MetricsComponent(
                    metric_types=["health", "performance", "validation"]
                ))
        
        return PatchedCheckerProtocol
    
    def patch_subscriber_protocol(self, original_class: Type) -> Type:
        """Patch SubscriberProtocol to use components."""
        class PatchedSubscriberProtocol(original_class):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                # Add event component for subscriber
                subscriber_entity = ForgeEntity(f"subscriber_{self.__class__.__name__}", "subscriber")
                from forge.core.forge_project_system import EventComponent
                subscriber_entity.add_component(EventComponent(
                    processing_enabled=True
                ))
        
        return PatchedSubscriberProtocol
    
    # === COMMAND INTEGRATION ===
    
    def patch_commands(self):
        """Patch all Forge commands to use components."""
        command_patches = {
            "forge.commands.manifest_cmd": {
                "validate_manifest": "patch_manifest_validation"
            },
            "forge.commands.diff_cmd": {
                "diff_nodes": "patch_diff_command"
            },
            "forge.commands.query_cmd": {
                "query_nodes": "patch_query_command"
            },
            "forge.commands.orient_cmd": {
                "run_session_orient": "patch_orient_command"
            }
        }
        
        for module_path, patches in command_patches.items():
            self.patch_module(module_path, patches)
    
    def patch_manifest_validation(self, original_func: Callable) -> Callable:
        """Patch manifest validation to use components."""
        @functools.wraps(original_func)
        def patched_function(*args, **kwargs):
            # Add contract validation component
            validator_entity = self.project.get_entity("manifest_validator")
            if not validator_entity:
                from forge.core.forge_project_system import ContractValidationComponent
                validator_entity = ForgeEntity("manifest_validator", "validator")
                validator_entity.add_component(ContractValidationComponent())
                self.project.add_entity(validator_entity)
            
            return original_func(*args, **kwargs)
        
        return patched_function
    
    def patch_diff_command(self, original_func: Callable) -> Callable:
        """Patch diff command to use components."""
        @functools.wraps(original_func)
        def patched_function(*args, **kwargs):
            # Add change tracking component
            diff_entity = self.project.get_entity("diff_tracker")
            if not diff_entity:
                from forge.core.forge_project_system import ChangeComponent
                diff_entity = ForgeEntity("diff_tracker", "tracker")
                diff_entity.add_component(ChangeComponent())
                self.project.add_entity(diff_entity)
            
            return original_func(*args, **kwargs)
        
        return patched_function
    
    def patch_query_command(self, original_func: Callable) -> Callable:
        """Patch query command to use components."""
        @functools.wraps(original_func)
        def patched_function(*args, **kwargs):
            # Add graph component for queries
            query_entity = self.project.get_entity("query_engine")
            if not query_entity:
                from forge.core.forge_project_system import GraphComponent
                query_entity = ForgeEntity("query_engine", "engine")
                query_entity.add_component(GraphComponent(
                    graph_type="manifest"
                ))
                self.project.add_entity(query_entity)
            
            return original_func(*args, **kwargs)
        
        return patched_function
    
    def patch_orient_command(self, original_func: Callable) -> Callable:
        """Patch orient command to use components."""
        @functools.wraps(original_func)
        def patched_function(*args, **kwargs):
            # Add semantic analysis component
            orient_entity = self.project.get_entity("orient_analyzer")
            if not orient_entity:
                from forge.core.forge_project_system import SemanticAnalysisComponent
                orient_entity = ForgeEntity("orient_analyzer", "analyzer")
                orient_entity.add_component(SemanticAnalysisComponent(
                    analyzer_type="hybrid"
                ))
                self.project.add_entity(orient_entity)
            
            return original_func(*args, **kwargs)
        
        return patched_function
    
    # === UNIVERSAL APPLIER ===
    
    def apply_all_patches(self):
        """Apply all patches to make Forge fully component-compatible."""
        print("Applying Forge compatibility layer patches...")
        
        # Patch MCP handlers
        self.patch_mcp_handlers()
        print("✓ MCP handlers patched")
        
        # Patch protocols
        self.patch_protocols()
        print("✓ Protocols patched")
        
        # Patch commands
        self.patch_commands()
        print("✓ Commands patched")
        
        # Initialize core entities
        self._initialize_core_entities()
        print("✓ Core entities initialized")
        
        print("Forge compatibility layer fully applied!")
    
    def _initialize_core_entities(self):
        """Initialize core component entities."""
        # Health monitor
        health_entity = ForgeEntity("health_monitor", "monitor")
        from forge.core.forge_project_system import MetricsComponent, HealthComponent
        health_entity.add_component(MetricsComponent())
        health_entity.add_component(HealthComponent())
        self.project.add_entity(health_entity)
        
        # Graph manager
        graph_entity = ForgeEntity("graph_manager", "manager")
        from forge.core.forge_project_system import GraphComponent
        graph_entity.add_component(GraphComponent(graph_type="manifest"))
        self.project.add_entity(graph_entity)
        
        # Event system
        event_entity = ForgeEntity("event_system", "system")
        from forge.core.forge_project_system import EventComponent
        event_entity.add_component(EventComponent())
        self.project.add_entity(event_entity)
    
    def restore_all_patches(self):
        """Restore all original functions."""
        print("Restoring original Forge functions...")
        
        for module_path, functions in self.module_patches.items():
            try:
                module_parts = module_path.split('.')
                module = __import__(module_path)
                for part in module_parts[1:]:
                    module = getattr(module, part)
                
                for func_name, original_func in functions.items():
                    setattr(module, func_name, original_func)
                
            except Exception as e:
                print(f"Failed to restore {module_path}: {e}")
        
        self.module_patches.clear()
        self.patched_functions.clear()
        print("✓ All patches restored")
    
    def get_compatibility_status(self) -> Dict[str, Any]:
        """Get status of compatibility layer."""
        return {
            "project_id": self.project.id,
            "project_path": str(self.project.root_path),
            "patched_modules": list(self.module_patches.keys()),
            "patched_functions": list(self.patched_functions.keys()),
            "registered_components": list(self.component_registry.keys()),
            "active_entities": list(self.project._entities.keys()),
            "graph_adapter_status": "active" if self.graph_adapter else "inactive"
        }


# === GLOBAL REGISTRY ===

_global_compatibility_layers: Dict[str, ForgeCompatibilityLayer] = {}


def get_compatibility_layer(project: ForgeProject) -> ForgeCompatibilityLayer:
    """Get or create compatibility layer for a project."""
    project_id = project.id
    
    if project_id not in _global_compatibility_layers:
        _global_compatibility_layers[project_id] = ForgeCompatibilityLayer(project)
    
    return _global_compatibility_layers[project_id]


def apply_compatibility_to_project(project: ForgeProject) -> ForgeCompatibilityLayer:
    """Apply compatibility layer to a project."""
    layer = get_compatibility_layer(project)
    layer.apply_all_patches()
    return layer


def remove_compatibility_from_project(project_id: str) -> bool:
    """Remove compatibility layer from a project."""
    if project_id in _global_compatibility_layers:
        layer = _global_compatibility_layers[project_id]
        layer.restore_all_patches()
        del _global_compatibility_layers[project_id]
        return True
    return False


# === USAGE EXAMPLES ===

def compatibility_example():
    """Example of using the compatibility layer."""
    from forge.core.forge_project_system import create_project
    
    # Create project
    project = create_project(Path("/Users/sebastianpereira/Projects/forge"))
    
    # Apply compatibility layer
    layer = apply_compatibility_to_project(project)
    
    # Now all Forge commands work with components!
    # Existing MCP handlers get metrics components
    # Existing protocols get event components
    # Existing commands get appropriate components
    
    # Check status
    status = layer.get_compatibility_status()
    print(f"Compatibility status: {status}")
    
    # Use enhanced functionality
    health_monitor = project.get_entity("health_monitor")
    if health_monitor:
        metrics = health_monitor.get_component(MetricsComponent)
        if metrics:
            metrics.record_metric("test_metric", 42)
    
    return project, layer


# === DECORATOR FOR EASY INTEGRATION ===

def component_compatible(module_path: str, function_name: str):
    """
    Decorator to make a function automatically component-compatible.
    
    Usage:
        @component_compatible("forge.mcp.handlers", "handle_forge_health_vector")
        def handle_forge_health_vector(arguments):
            # Function automatically gets component context
            layer = kwargs.get('_compatibility_layer')
            project = kwargs.get('_project')
            # Use components freely
            return enhanced_result
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Inject compatibility context
            kwargs['_module_path'] = module_path
            kwargs['_function_name'] = function_name
            
            return func(*args, **kwargs)
        
        wrapper._component_compatible = True
        wrapper._module_path = module_path
        wrapper._function_name = function_name
        return wrapper
    
    return decorator
