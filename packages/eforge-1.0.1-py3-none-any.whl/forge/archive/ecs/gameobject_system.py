"""
Unity-like GameObject system for Forge.
Supports components and scripts like Unity's Entity Component System.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Type, TypeVar, Union
from enum import Enum

T = TypeVar('T')


class ComponentStatus(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    DESTROYED = "destroyed"


@dataclass
class Component:
    """Base component class - like Unity's Component."""
    game_object: Optional['GameObject'] = None
    status: ComponentStatus = ComponentStatus.ACTIVE
    enabled: bool = True
    
    def awake(self):
        """Called when component is added to GameObject."""
        pass
    
    def update(self, delta_time: float):
        """Called every frame/update cycle."""
        pass
    
    def destroy(self):
        """Called when component is removed."""
        self.status = ComponentStatus.DESTROYED


@dataclass
class Script(Component):
    """Base script class - like Unity's MonoBehaviour."""
    
    def start(self):
        """Called before first update."""
        pass
    
    def on_enable(self):
        """Called when component becomes enabled."""
        pass
    
    def on_disable(self):
        """Called when component becomes disabled."""
        pass


class GameObject:
    """
    Unity-like GameObject with component system.
    Acts like a dict but with object behavior.
    """
    
    def __init__(self, name: str = "GameObject"):
        self.name = name
        self._components: Dict[str, Component] = {}
        self._properties: Dict[str, Any] = {}
        self._tags: List[str] = []
        self._active = True
    
    # Dict-like interface
    def __getitem__(self, key: str) -> Any:
        """Get component or property by key."""
        return self._components.get(key) or self._properties.get(key)
    
    def __setitem__(self, key: str, value: Any):
        """Set component or property by key."""
        if isinstance(value, Component):
            self.add_component(value, key)
        else:
            self._properties[key] = value
    
    def __contains__(self, key: str) -> bool:
        """Check if component or property exists."""
        return key in self._components or key in self._properties
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get component or property with default."""
        return self[key] if key in self else default
    
    # Component management
    def add_component(self, component: Component, name: Optional[str] = None) -> Component:
        """Add a component to this GameObject."""
        comp_name = name or component.__class__.__name__
        
        # Remove existing component of same type
        if comp_name in self._components:
            self.remove_component(comp_name)
        
        component.game_object = self
        component.awake()
        self._components[comp_name] = component
        return component
    
    def get_component(self, component_type: Type[T]) -> Optional[T]:
        """Get component by type."""
        for component in self._components.values():
            if isinstance(component, component_type):
                return component
        return None
    
    def get_components(self, component_type: Type[T]) -> List[T]:
        """Get all components of type."""
        return [c for c in self._components.values() if isinstance(c, component_type)]
    
    def remove_component(self, name: str) -> Optional[Component]:
        """Remove component by name."""
        component = self._components.pop(name, None)
        if component:
            component.destroy()
        return component
    
    def has_component(self, component_type: Type[Component]) -> bool:
        """Check if GameObject has component type."""
        return self.get_component(component_type) is not None
    
    # Script management
    def add_script(self, script: Script, name: Optional[str] = None) -> Script:
        """Add a script component."""
        script = self.add_component(script, name)
        if isinstance(script, Script):
            script.start()
        return script
    
    # Property management
    def set_property(self, key: str, value: Any):
        """Set a simple property (non-component)."""
        self._properties[key] = value
    
    def get_property(self, key: str, default: Any = None) -> Any:
        """Get a simple property."""
        return self._properties.get(key, default)
    
    # Tag system
    def add_tag(self, tag: str):
        """Add a tag to this GameObject."""
        if tag not in self._tags:
            self._tags.append(tag)
    
    def has_tag(self, tag: str) -> bool:
        """Check if GameObject has tag."""
        return tag in self._tags
    
    def remove_tag(self, tag: str):
        """Remove a tag from this GameObject."""
        if tag in self._tags:
            self._tags.remove(tag)
    
    # Lifecycle
    def update(self, delta_time: float = 0.016):
        """Update all active components."""
        if not self._active:
            return
            
        for component in self._components.values():
            if component.enabled and component.status == ComponentStatus.ACTIVE:
                component.update(delta_time)
    
    def destroy(self):
        """Destroy this GameObject and all components."""
        for component in self._components.values():
            component.destroy()
        self._components.clear()
        self._properties.clear()
        self._tags.clear()
        self._active = False
    
    # Utility methods
    def get_active_components(self) -> List[Component]:
        """Get all active components."""
        return [c for c in self._components.values() 
                if c.status == ComponentStatus.ACTIVE and c.enabled]
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary (for saving/prefabs)."""
        return {
            "name": self.name,
            "properties": self._properties.copy(),
            "tags": self._tags.copy(),
            "components": {
                name: {
                    "type": comp.__class__.__name__,
                    "data": comp.__dict__
                }
                for name, comp in self._components.items()
            }
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'GameObject':
        """Create from dictionary (for loading prefabs)."""
        game_obj = cls(data["name"])
        game_obj._properties = data.get("properties", {})
        game_obj._tags = data.get("tags", [])
        
        # Component reconstruction would need a registry system
        # This is a simplified version
        return game_obj


# Example Components for Forge
@dataclass
class Transform(Component):
    """Position/rotation/scale component."""
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    rotation_x: float = 0.0
    rotation_y: float = 0.0
    rotation_z: float = 0.0
    scale_x: float = 1.0
    scale_y: float = 1.0
    scale_z: float = 1.0
    
    def get_position(self) -> tuple[float, float, float]:
        return (self.x, self.y, self.z)
    
    def set_position(self, x: float, y: float, z: float):
        self.x, self.y, self.z = x, y, z


@dataclass
class ForgeNode(Component):
    """Forge-specific node component."""
    node_id: str = ""
    node_type: str = ""
    domain: str = ""
    tier: str = "worker"
    
    def awake(self):
        """Register with forge systems when added."""
        if self.game_object:
            print(f"Registering node {self.node_id} with forge")


@dataclass
class ManifestComponent(Component):
    """Manifest-related component."""
    manifest_path: str = ""
    auto_sync: bool = True
    
    def update(self, delta_time: float):
        """Check for manifest changes."""
        if self.auto_sync:
            # Would implement manifest sync logic here
            pass


# Example Scripts
class NodeLifecycleScript(Script):
    """Script that manages node lifecycle."""
    
    def start(self):
        """Initialize node."""
        node = self.game_object.get_component(ForgeNode)
        if node:
            print(f"Starting node {node.node_id}")
    
    def update(self, delta_time: float):
        """Update node state."""
        node = self.game_object.get_component(ForgeNode)
        if node:
            # Would implement node update logic here
            pass


# Prefab System
class Prefab:
    """Scriptable Object prefab system."""
    
    def __init__(self, name: str):
        self.name = name
        self._template: Optional[GameObject] = None
        self._instances: List[GameObject] = []
    
    def set_template(self, game_object: GameObject):
        """Set the template GameObject."""
        self._template = game_object
    
    def instantiate(self, name: Optional[str] = None) -> GameObject:
        """Create a new instance from the template."""
        if not self._template:
            raise ValueError("No template set for prefab")
        
        # Deep copy the template
        import copy
        instance = copy.deepcopy(self._template)
        instance.name = name or f"{self.name}_instance"
        self._instances.append(instance)
        
        # Re-awake all components
        for component in instance._components.values():
            component.game_object = instance
            component.awake()
            if isinstance(component, Script):
                component.start()
        
        return instance
    
    def get_instances(self) -> List[GameObject]:
        """Get all instances of this prefab."""
        return self._instances.copy()


# Usage Examples
def example_usage():
    """Example of how to use the GameObject system."""
    
    # Create a GameObject
    player = GameObject("Player")
    
    # Add components (dict-like access)
    player["transform"] = Transform(x=10, y=0, z=5)
    player["forge_node"] = ForgeNode(
        node_id="player_controller",
        node_type="controller", 
        domain="game",
        tier="surface"
    )
    
    # Add script
    player.add_script(NodeLifecycleScript())
    
    # Access components
    transform = player["transform"]  # Dict access
    node = player.get_component(ForgeNode)  # Type-safe access
    
    # Set properties
    player["health"] = 100
    player["level"] = 1
    
    # Update loop
    player.update(0.016)  # 60 FPS
    
    # Prefab system
    enemy_prefab = Prefab("Enemy")
    enemy_template = GameObject("EnemyTemplate")
    enemy_template["transform"] = Transform()
    enemy_template["forge_node"] = ForgeNode(
        node_id="enemy_base",
        node_type="service",
        domain="ai",
        tier="worker"
    )
    enemy_prefab.set_template(enemy_template)
    
    # Spawn enemies
    enemy1 = enemy_prefab.instantiate("Enemy1")
    enemy2 = enemy_prefab.instantiate("Enemy2")
    
    return player, enemy1, enemy2
