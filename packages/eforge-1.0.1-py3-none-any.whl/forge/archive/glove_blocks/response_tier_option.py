@click.option(
    "--response-tier",
    type=click.Choice(["L0", "L1", "L2"]),
    default="L1",
    show_default=True,
    help="Output verbosity tier.",
)
