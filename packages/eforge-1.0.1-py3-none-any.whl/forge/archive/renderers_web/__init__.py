from forge.renderers.base import RendererRegistry
from forge.archive.renderers_web.renderer import WebRenderer

RendererRegistry.register("web", WebRenderer)

