from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient

from forge.renderers.web.error_codes import DashboardErrorCode
from forge.renderers.web.tests.test_docs_router import _app


def test_docs_tree_found(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "MAP.md").write_text("# Map\n", encoding="utf-8")
    (docs / "ARCHITECTURE.md").write_text("# Architecture overview\n", encoding="utf-8")
    client = TestClient(_app())
    r = client.get("/api/docs/tree", params={"project_path": str(tmp_path)})
    assert r.status_code == 200
    data = r.json()
    assert len(data["files"]) == 2
    names = {f["name"] for f in data["files"]}
    assert names == {"MAP.md", "ARCHITECTURE.md"}
    map_entry = next(f for f in data["files"] if f["name"] == "MAP.md")
    assert map_entry["group"] == "Core"


def test_docs_tree_no_docs_folder(tmp_path: Path) -> None:
    client = TestClient(_app())
    r = client.get("/api/docs/tree", params={"project_path": str(tmp_path)})
    assert r.status_code == 404
    assert r.json()["code"] == DashboardErrorCode.FILE_NOT_FOUND.value


def test_docs_file_read(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    p = docs / "MAP.md"
    p.write_text(
        "# Title\n\n## Section A\n\n### Deep\n\nbody\n",
        encoding="utf-8",
    )
    client = TestClient(_app())
    r = client.get(
        "/api/docs/file",
        params={"path": str(p.resolve()), "project_path": str(tmp_path)},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["type"] == "markdown"
    assert "body" in body["content"]
    assert isinstance(body["toc"], list)
    assert len(body["toc"]) >= 3


def test_docs_file_path_traversal(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    client = TestClient(_app())
    r = client.get(
        "/api/docs/file",
        params={"path": "../../etc/passwd", "project_path": str(tmp_path)},
    )
    assert r.status_code == 403
    assert r.json()["code"] == DashboardErrorCode.VALIDATION_ERROR.value


def test_docs_search_finds_match(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "ARCHITECTURE.md").write_text(
        "# System\n\nThis describes the Architecture of the app.\n",
        encoding="utf-8",
    )
    (docs / "other.md").write_text("# Other\n\nnothing here\n", encoding="utf-8")
    client = TestClient(_app())
    r = client.get(
        "/api/docs/search",
        params={"project_path": str(tmp_path), "q": "Architecture"},
    )
    assert r.status_code == 200
    data = r.json()
    ids = {res["file_name"] for res in data["results"]}
    assert "ARCHITECTURE.md" in ids


def test_docs_search_case_insensitive(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "ARCHITECTURE.md").write_text(
        "# System\n\nMixed Case Architecture Phrase.\n",
        encoding="utf-8",
    )
    client = TestClient(_app())
    r1 = client.get(
        "/api/docs/search",
        params={"project_path": str(tmp_path), "q": "Architecture"},
    )
    r2 = client.get(
        "/api/docs/search",
        params={"project_path": str(tmp_path), "q": "architecture"},
    )
    assert r1.status_code == 200 and r2.status_code == 200
    s1 = {x["file_id"] for x in r1.json()["results"]}
    s2 = {x["file_id"] for x in r2.json()["results"]}
    assert s1 == s2


def test_docs_toc_extraction(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    p = docs / "headings.md"
    p.write_text(
        "# Alpha Top\n\n## Beta — Gamma\n\n### Delta!\n\nText.\n",
        encoding="utf-8",
    )
    client = TestClient(_app())
    r = client.get(
        "/api/docs/file",
        params={"path": str(p.resolve()), "project_path": str(tmp_path)},
    )
    assert r.status_code == 200
    toc = r.json()["toc"]
    titles = [entry["title"] for entry in toc]
    assert titles[:3] == ["Alpha Top", "Beta — Gamma", "Delta!"]
    anchors = [entry["anchor"] for entry in toc]
    assert anchors[0] == "alpha-top"
    assert anchors[1] == "beta-gamma"
    assert anchors[2] == "delta"
