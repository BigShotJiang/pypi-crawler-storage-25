from __future__ import annotations

from types import SimpleNamespace
from pathlib import Path

from fastapi import FastAPI
from fastapi.testclient import TestClient

from forge.archive.tui.textual.state import ProjectState
from forge.renderers.web.routers.graph_router import create_graph_router


def _client(tmp_path: Path) -> TestClient:
    app = FastAPI()
    state_by_id = {"forge": ProjectState(project=SimpleNamespace(path=tmp_path, name="forge"))}
    app.include_router(create_graph_router(state_by_id))
    return TestClient(app)


def test_graph_registry_endpoint_returns_nodes(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setattr(
        "forge.renderers.web.routers.graph_router.load_registry",
        lambda: {"projects": {"forge": {"id": "forge", "name": "forge", "path": str(tmp_path)}}},
    )
    c = _client(tmp_path)
    r = c.get("/graph/registry")
    assert r.status_code == 200
    body = r.json()
    assert len(body["nodes"]) >= 1


def test_graph_manifest_endpoint_returns_nodes(tmp_path: Path) -> None:
    (tmp_path / "manifest.yaml").write_text(
        "screens:\n- name: HomeScreen\n  file: lib/home.dart\n  watches: [HomeController]\ncontrollers:\n- name: HomeController\n  file: lib/home_controller.dart\n",
        encoding="utf-8",
    )
    c = _client(tmp_path)
    r = c.get("/graph/manifest/forge")
    assert r.status_code == 200
    body = r.json()
    assert len(body["nodes"]) >= 1


def test_blast_radius_endpoint_returns_results(tmp_path: Path) -> None:
    (tmp_path / "audit-map.bundle.json").write_text(
        '{"bundle_id":"b","schema_version":"1","document_kind":"audit_map_bundle","session_id":"s","repo":{},"generated_at":"x","generator_version":"1","inputs":{},"warnings":[],"stats":{},"nodes":[{"node_id":"a","kind":"module","path":"x","label":"a","ring_id":2},{"node_id":"b","kind":"module","path":"y","label":"b","ring_id":2}],"edges":[{"from_node_id":"a","to_node_id":"b","relation":"depends_on"}],"cross_ring_edges":[],"coverage":{},"rings_summary":{},"provenance":{}}',
        encoding="utf-8",
    )
    c = _client(tmp_path)
    r = c.post("/graph/blast-radius", json={"node_id": "a", "project_slug": "forge"})
    assert r.status_code == 200
    body = r.json()
    assert body["node_id"] == "a"
    assert "blast_radius" in body
