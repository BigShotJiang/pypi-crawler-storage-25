from __future__ import annotations

from types import SimpleNamespace
from pathlib import Path

from fastapi import FastAPI
from fastapi.testclient import TestClient

from forge.archive.tui.textual.state import ProjectState
from forge.renderers.web.routers.tasks_router import create_tasks_router


def _client(tmp_path: Path) -> TestClient:
    app = FastAPI()
    root = tmp_path.resolve()
    state_by_id = {
        "p1": ProjectState(project=SimpleNamespace(path=root)),
    }
    app.include_router(create_tasks_router(state_by_id))
    return TestClient(app)


def test_toggle_checkbox_unchecked_to_checked(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    todo = docs / "TODO.md"
    todo.write_text("## A\n\n- [ ] One task here\n", encoding="utf-8")
    client = _client(tmp_path)
    r = client.post(
        "/projects/p1/tasks/toggle",
        json={
            "group_label": "A",
            "task_text": "One task here",
            "checked": True,
        },
    )
    assert r.status_code == 200
    assert r.json()["success"] is True
    assert "- [x]" in todo.read_text()


def test_toggle_checkbox_preserves_other_lines(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    todo = docs / "TODO.md"
    original = "## A\n\n- [ ] keep\n- [ ] toggle me\n## B\n\n- [ ] other\n"
    todo.write_text(original, encoding="utf-8")
    client = _client(tmp_path)
    r = client.post(
        "/projects/p1/tasks/toggle",
        json={
            "group_label": "A",
            "task_text": "toggle me",
            "checked": True,
        },
    )
    assert r.status_code == 200
    assert r.json()["success"] is True
    text = todo.read_text()
    assert "- [ ] keep" in text
    assert "- [x] toggle me" in text
    assert "## B" in text
    assert "- [ ] other" in text


def test_tasks_scope_all_finds_audit(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "TODO.md").write_text("## T\n\n- [ ] from todo\n", encoding="utf-8")
    (docs / "AUDIT.md").write_text("## Audit sec\n\n- [ ] from audit\n", encoding="utf-8")
    client = _client(tmp_path)
    r = client.get("/projects/p1/tasks", params={"scope": "all"})
    assert r.status_code == 200
    data = r.json()
    labels = {g["label"] for g in data["groups"]}
    assert any("TODO.md" in x for x in labels)
    assert any("AUDIT.md" in x for x in labels)


def test_tasks_tag_parsing(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "TODO.md").write_text(
        "## T\n\n- [ ] Fix thing #denv #p1\n",
        encoding="utf-8",
    )
    client = _client(tmp_path)
    r = client.get("/projects/p1/tasks")
    assert r.status_code == 200
    task = r.json()["groups"][0]["tasks"][0]
    assert task["text"] == "Fix thing"
    assert task["tags"] == ["denv", "p1"]
