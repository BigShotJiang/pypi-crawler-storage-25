from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.testclient import TestClient

from forge.renderers.web.docs_router import docs_router
from forge.renderers.web.error_codes import DashboardErrorCode
from forge.renderers.web.error_response import DashboardError, error_response, handle_unexpected


def _app() -> FastAPI:
    app = FastAPI()
    app.include_router(docs_router)

    @app.exception_handler(DashboardError)
    async def dashboard_error_handler(request: Request, exc: DashboardError):
        return error_response(exc.code, exc.message, exc.detail, exc.status_code)

    @app.exception_handler(Exception)
    async def unhandled_error_handler(request: Request, exc: Exception):
        return handle_unexpected(exc, str(request.url.path))

    return app


def test_annotations_create_sidecar(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    md = docs / "MAP.md"
    md.write_text("# M\n", encoding="utf-8")
    client = TestClient(_app())
    r = client.post(
        "/api/docs/annotations",
        params={"project_path": str(tmp_path)},
        json={
            "file_path": str(md.resolve()),
            "anchor": "## For AI assistants",
            "note": "hello",
            "tags": ["session-prep", "important"],
        },
    )
    assert r.status_code == 200
    side = docs / "MAP.md.notes.yaml"
    assert side.is_file()
    raw = side.read_text()
    assert "tags_inline" in raw
    gi = tmp_path / ".gitignore"
    assert gi.is_file()
    assert ".notes.yaml" in gi.read_text()


def test_annotations_read_existing(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    md = docs / "NOTE.md"
    md.write_text("# x\n", encoding="utf-8")
    side = docs / "NOTE.md.notes.yaml"
    side.write_text(
        "annotations:\n"
        "  - id: ann-test1\n"
        "    anchor: \"## Hi\"\n"
        "    note: there\n"
        "    tags: [a]\n"
        "    tags_inline: \"#a\"\n"
        "    created: \"2026-03-21\"\n"
        "    done: false\n",
        encoding="utf-8",
    )
    client = TestClient(_app())
    r = client.get(
        "/api/docs/annotations",
        params={"project_path": str(tmp_path), "path": str(md.resolve())},
    )
    assert r.status_code == 200
    assert len(r.json()["annotations"]) == 1
    assert r.json()["annotations"][0]["id"] == "ann-test1"


def test_annotations_obsidian_format(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    md = docs / "MAP.md"
    md.write_text("# M\n", encoding="utf-8")
    client = TestClient(_app())
    r = client.post(
        "/api/docs/annotations",
        params={"project_path": str(tmp_path)},
        json={
            "file_path": str(md.resolve()),
            "anchor": "## Section",
            "note": "body",
            "tags": ["one", "two"],
        },
    )
    assert r.status_code == 200
    raw = (docs / "MAP.md.notes.yaml").read_text()
    assert "tags_inline:" in raw
    assert "#one" in raw or "one" in raw
