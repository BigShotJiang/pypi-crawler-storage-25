from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.testclient import TestClient

from forge.renderers.web.error_codes import DashboardErrorCode
from forge.renderers.web.error_response import DashboardError, error_response, handle_unexpected
from forge.tools.docs_audit.api_router import impact_router
from forge.tools.scaffold.api_router import composer_router


def _app() -> FastAPI:
    app = FastAPI()
    app.include_router(composer_router)
    app.include_router(impact_router)

    @app.exception_handler(DashboardError)
    async def dashboard_error_handler(request: Request, exc: DashboardError):
        return error_response(exc.code, exc.message, exc.detail, exc.status_code)

    @app.exception_handler(Exception)
    async def unhandled_error_handler(request: Request, exc: Exception):
        return handle_unexpected(exc, str(request.url.path))

    return app


def test_composer_export_bad_canvas_returns_422(tmp_path: Path) -> None:
    client = TestClient(_app())
    r = client.post("/api/composer/export", json={"canvas": {}, "project_path": str(tmp_path)})
    assert r.status_code == 422


def test_composer_open_missing_file_returns_404() -> None:
    client = TestClient(_app())
    r = client.post("/api/composer/open", json={"path": "/tmp/does-not-exist.forge.json"})
    assert r.status_code == 404
    body = r.json()
    assert body["code"] == DashboardErrorCode.COMPOSER_FILE_NOT_FOUND.value


def test_impact_missing_project_returns_404() -> None:
    client = TestClient(_app())
    r = client.post(
        "/api/impact/evaluate",
        json={"project_path": "/tmp/no-such-project", "changed_files": [], "strict": False, "changed_text": ""},
    )
    assert r.status_code == 404
    assert r.json()["code"] == DashboardErrorCode.IMPACT_PROJECT_NOT_FOUND.value

