from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.testclient import TestClient

from forge.renderers.web.docs_router import docs_router
from forge.renderers.web.error_codes import DashboardErrorCode
from forge.renderers.web.error_response import DashboardError, error_response, handle_unexpected


def _app() -> FastAPI:
    app = FastAPI()
    app.include_router(docs_router)

    @app.exception_handler(DashboardError)
    async def dashboard_error_handler(request: Request, exc: DashboardError):
        return error_response(exc.code, exc.message, exc.detail, exc.status_code)

    @app.exception_handler(Exception)
    async def unhandled_error_handler(request: Request, exc: Exception):
        return handle_unexpected(exc, str(request.url.path))

    return app


def test_docs_tree_404_without_docs_folder(tmp_path: Path) -> None:
    client = TestClient(_app())
    r = client.get("/api/docs/tree", params={"project_path": str(tmp_path)})
    assert r.status_code == 404
    assert r.json()["code"] == DashboardErrorCode.FILE_NOT_FOUND.value


def test_docs_tree_lists_files(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "MAP.md").write_text("# Title Here\n", encoding="utf-8")
    (docs / "data.yaml").write_text("x: 1\n", encoding="utf-8")
    client = TestClient(_app())
    r = client.get("/api/docs/tree", params={"project_path": str(tmp_path)})
    assert r.status_code == 200
    data = r.json()
    names = {f["name"] for f in data["files"]}
    assert "MAP.md" in names
    assert "data.yaml" in names
    map_entry = next(f for f in data["files"] if f["name"] == "MAP.md")
    assert map_entry["title"] == "Title Here"


def test_docs_file_reads_content(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    p = docs / "NOTE.md"
    p.write_text("---\nx: 1\n---\n\n# Body\n", encoding="utf-8")
    client = TestClient(_app())
    r = client.get(
        "/api/docs/file",
        params={"path": str(p.resolve()), "project_path": str(tmp_path)},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["type"] == "markdown"
    assert "Body" in body["content"]


def test_docs_file_rejects_escape(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    outside = tmp_path / "secret.yaml"
    outside.write_text("x: 1\n", encoding="utf-8")
    client = TestClient(_app())
    r = client.get(
        "/api/docs/file",
        params={"path": str(outside.resolve()), "project_path": str(tmp_path)},
    )
    assert r.status_code == 403


def test_docs_tree_empty_folder_warns(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    client = TestClient(_app())
    r = client.get("/api/docs/tree", params={"project_path": str(tmp_path)})
    assert r.status_code == 200
    data = r.json()
    assert data["files"] == []
    assert any("empty" in w.lower() for w in data["warnings"])


def test_docs_tree_skips_binary_looking_md(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "good.md").write_text("# Good\n", encoding="utf-8")
    (docs / "bad.md").write_bytes(b"# fake\n\x00binary")
    client = TestClient(_app())
    r = client.get("/api/docs/tree", params={"project_path": str(tmp_path)})
    assert r.status_code == 200
    names = {f["name"] for f in r.json()["files"]}
    assert names == {"good.md"}


def test_docs_file_binary_returns_415(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    p = docs / "bad.md"
    p.write_bytes(b"x\x00y")
    client = TestClient(_app())
    r = client.get(
        "/api/docs/file",
        params={"path": str(p.resolve()), "project_path": str(tmp_path)},
    )
    assert r.status_code == 415
    assert r.json()["code"] == DashboardErrorCode.VALIDATION_ERROR.value


def test_docs_file_large_file_flag(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    p = docs / "big.md"
    p.write_text("# h\n" + "x" * 600_000, encoding="utf-8")
    client = TestClient(_app())
    r = client.get(
        "/api/docs/file",
        params={"path": str(p.resolve()), "project_path": str(tmp_path)},
    )
    assert r.status_code == 200
    assert r.json()["large_file"] is True


def test_docs_search_finds_text(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "a.md").write_text("# Hi\n\nalpha beta gamma\n", encoding="utf-8")
    client = TestClient(_app())
    r = client.get(
        "/api/docs/search",
        params={"project_path": str(tmp_path), "q": "beta"},
    )
    assert r.status_code == 200
    data = r.json()
    assert data["total_matches"] >= 1
    assert len(data["results"]) >= 1
