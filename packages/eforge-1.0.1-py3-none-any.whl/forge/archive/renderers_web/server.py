from __future__ import annotations

from collections.abc import Iterable
from datetime import datetime, timezone
from pathlib import Path
import logging
import time

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.base import BaseHTTPMiddleware

from forge.core.contract_graph import build_contract_graph
from forge.archive.tui.textual.state import ProjectState
from forge.renderers.web.error_response import DashboardError, error_response, handle_unexpected
from forge.renderers.web.routers import (
    create_config_router,
    create_contracts_router,
    create_graph_router,
    create_health_router,
    create_projects_router,
    create_tasks_router,
)

logger = logging.getLogger("forge.dashboard")


def create_app(states: Iterable[ProjectState]) -> FastAPI:
    app = FastAPI(title="forge denvboard")
    started_at = datetime.now(timezone.utc)
    state_by_id = {(s.project.name or s.project.path.name).strip().lower().replace(" ", "-") or s.project.path.name.lower(): s for s in states}
    graph_holder = {"graph": build_contract_graph(list(state_by_id.values()))}

    class RequestLogMiddleware(BaseHTTPMiddleware):
        async def dispatch(self, request: Request, call_next):
            start = time.time(); response = await call_next(request); ms = round((time.time() - start) * 1000)
            logger.info(f"{request.method} {request.url.path} -> {response.status_code} ({ms}ms)"); return response

    app.add_middleware(RequestLogMiddleware)
    app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"], allow_methods=["*"], allow_headers=["*"])
    app.add_exception_handler(DashboardError, lambda req, exc: error_response(exc.code, exc.message, exc.detail, exc.status_code))
    app.add_exception_handler(Exception, lambda req, exc: handle_unexpected(exc, str(req.url.path)))

    for router in (
        create_projects_router(state_by_id, started_at),
        create_health_router(state_by_id),
        create_tasks_router(state_by_id),
        create_contracts_router(state_by_id, graph_holder),
        create_config_router(state_by_id, graph_holder),
        create_graph_router(state_by_id),
    ):
        app.include_router(router, prefix="/api")

    try:
        from forge.tools.docs_audit.api_router import impact_router
        from forge.tools.scaffold.api_router import composer_router, build_workshop_router
        app.include_router(impact_router); app.include_router(composer_router); app.include_router(build_workshop_router())
    except Exception:
        pass
    try:
        from forge.renderers.web.docs_router import docs_router
        app.include_router(docs_router)
    except Exception:
        pass

    dist_dir = Path(__file__).parent / "ui" / "dist"
    if dist_dir.exists(): app.mount("/", StaticFiles(directory=dist_dir, html=True), name="ui")
    else:
        @app.get("/", response_class=HTMLResponse)
        def placeholder_root() -> str:
            return "<html><body><h1>forge denvboard</h1><p>UI not built yet. Run <code>npm install && npm run build</code> in forge/renderers/web/ui/.</p></body></html>"

    return app

