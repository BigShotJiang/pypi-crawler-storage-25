"""
Docs viewer API: tree, file content, search under project docs/.
"""

from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import unquote

from fastapi import APIRouter, Body, Query
from pydantic import BaseModel, Field

from forge.renderers.web.docs_annotations import (
    create_annotation,
    delete_annotation,
    list_all_annotation_tags,
    read_annotations_for_file,
    update_annotation,
)
from forge.renderers.web.error_codes import DashboardErrorCode
from forge.renderers.web.error_response import DashboardError
from forge.renderers.web.tasks_md import count_open_tasks_in_file, extract_inline_tasks_for_file

docs_router = APIRouter(prefix="/api/docs", tags=["docs"])

SKIP_DIRS = frozenset({"node_modules", "__pycache__", ".git", ".idea", ".vscode", "dist", "build"})
ALLOW_SUFFIXES = {".md", ".yaml", ".yml", ".json"}
MAX_DEPTH_DIRS = 3
MAX_FILES = 100
MAX_TOC = 50
LARGE_FILE_BYTES = 500_000

CORE_NAMES = {
    "map.md",
    "architecture.md",
    "manifest.md",
    "manifest.yaml",
    "internals.md",
}
PLANNING_NAMES = {"todo.md", "audit.md", "roadmap.md", "changelog.md"}
WORKFLOW_NAMES = {"update.md", "readme_checklist.md", "agent_context.md", "cursor_context.md"}
STANDARDS_NAMES = {"flutter_principles.md", "templates.md", "principles.md"}
ERRORS_NAMES = {"error_codes.md"}
ADR_NAMES = {"adr_registry.yaml", "adr_registry.yml"}

GROUP_ORDER = ["Core", "Planning", "Workflow", "Standards", "Errors", "ADRs", "Tools", "Config", "Other"]


def _resolve_docs_root(project_path: Path) -> Path | None:
    p = project_path.resolve()
    for name in ("docs", "DOCS", "documentation"):
        cand = p / name
        if cand.is_dir():
            return cand
    return None


def _file_id(rel: Path) -> str:
    stem = rel.stem.upper()
    if len(rel.parts) == 1:
        return stem
    return str(rel.with_suffix("")).replace("/", "__").replace("\\", "__").upper()


def _assign_group(rel: Path) -> str:
    parts_lower = tuple(x.lower() for x in rel.parts)
    name_lower = rel.name.lower()
    suffix = rel.suffix.lower()

    if any(p == "tool-docs" for p in parts_lower):
        return "Tools"
    if any(p == "stack_principles" for p in parts_lower):
        return "Standards"
    if name_lower.startswith("adr-") and suffix == ".md":
        return "ADRs"
    if name_lower in ADR_NAMES or name_lower.startswith("adr") and "registry" in name_lower:
        return "ADRs"
    if name_lower in {n.lower() for n in CORE_NAMES} or name_lower == "manifest.yaml":
        return "Core"
    if name_lower in PLANNING_NAMES:
        return "Planning"
    if name_lower in WORKFLOW_NAMES:
        return "Workflow"
    if name_lower in STANDARDS_NAMES:
        return "Standards"
    if name_lower in ERRORS_NAMES:
        return "Errors"
    if name_lower.startswith("adding_") or name_lower.startswith("schema_migration") or name_lower == "workshop.md":
        return "Tools"
    if suffix in (".yaml", ".yml") and name_lower not in ("manifest.yaml", "manifest.yml", "adr_registry.yaml", "adr_registry.yml"):
        return "Config"
    if suffix in (".yaml", ".yml") and name_lower in ("manifest.yaml", "manifest.yml"):
        return "Core"
    return "Other"


def _group_sort_key(group: str, name: str) -> tuple[int, str]:
    pri = {
        "Core": ["map.md", "architecture.md", "manifest.md", "manifest.yaml", "internals.md"],
        "Planning": sorted(PLANNING_NAMES),
        "Workflow": sorted(WORKFLOW_NAMES),
        "Standards": sorted(STANDARDS_NAMES),
        "Errors": sorted(ERRORS_NAMES),
    }.get(group, [])
    nl = name.lower()
    for i, p in enumerate(pri):
        if p == nl:
            return (i, nl)
    return (1000, nl)


def _is_probably_text(path: Path) -> bool:
    """Skip binary-looking files from listings and treat as non-displayable."""
    try:
        size = path.stat().st_size
        if size == 0:
            return True
        n = min(size, 8192)
        with path.open("rb") as f:
            chunk = f.read(n)
    except OSError:
        return False
    if b"\x00" in chunk:
        return False
    if not chunk:
        return True
    ok = sum(1 for b in chunk if b in (9, 10, 11, 12, 13) or 32 <= b <= 126 or b >= 128)
    return ok / len(chunk) > 0.88


def _collect_files(docs_root: Path) -> tuple[list[dict[str, Any]], list[str]]:
    warnings: list[str] = []
    out: list[dict[str, Any]] = []

    for path in sorted(docs_root.rglob("*")):
        if not path.is_file():
            continue
        if path.suffix.lower() == ".forge.json" or path.name.endswith(".forge.json"):
            continue
        if path.suffix.lower() not in ALLOW_SUFFIXES:
            continue
        if not _is_probably_text(path):
            continue
        try:
            rel = path.relative_to(docs_root)
        except ValueError:
            continue
        if len(rel.parts) > MAX_DEPTH_DIRS + 1:
            continue
        if any(p in SKIP_DIRS for p in rel.parts):
            continue
        st = path.stat()
        modified = datetime.fromtimestamp(st.st_mtime, tz=timezone.utc).isoformat()
        group = _assign_group(rel)
        title = _title_for_file(path)
        entry = {
            "id": _file_id(rel),
            "name": path.name,
            "title": title,
            "path": str(path.resolve()),
            "size": st.st_size,
            "modified": modified,
            "group": group,
            "order": 0,
        }
        out.append(entry)

    out.sort(
        key=lambda e: (
            GROUP_ORDER.index(e["group"]) if e["group"] in GROUP_ORDER else 99,
            _group_sort_key(e["group"], e["name"])[0],
            e["name"].lower(),
        )
    )

    for i, e in enumerate(out):
        e["order"] = i
        if e["name"].lower().endswith(".md"):
            fp = Path(e["path"])
            try:
                e["open_tasks"] = count_open_tasks_in_file(fp)
            except OSError:
                e["open_tasks"] = 0
            atags: list[str] = []
            try:
                for ann in read_annotations_for_file(fp):
                    for t in ann.get("tags") or []:
                        if isinstance(t, str) and t.strip():
                            atags.append(t.strip().lstrip("#").lower())
                e["annotation_tags"] = sorted(set(atags))
            except OSError:
                e["annotation_tags"] = []
        else:
            e["open_tasks"] = 0
            e["annotation_tags"] = []

    if len(out) > MAX_FILES:
        warnings.append(f"Docs listing exceeds {MAX_FILES} files; only the first {MAX_FILES} are returned.")
        out = out[:MAX_FILES]

    return out, warnings


def _title_for_file(path: Path) -> str:
    if path.suffix.lower() == ".md":
        try:
            with path.open(encoding="utf-8", errors="replace") as f:
                for line in f:
                    s = line.strip()
                    if s.startswith("# "):
                        return s[2:].strip()
                    if s:
                        break
        except OSError:
            pass
        return path.stem
    return path.stem


def _read_title_from_content(content: str, fallback: str) -> str:
    for line in content.splitlines():
        s = line.strip()
        if s.startswith("# "):
            return s[2:].strip()
        if s:
            break
    return fallback


def _slug_anchor(title: str, used: dict[str, int]) -> str:
    base = re.sub(r"[^\w\s-]", "", title.lower().strip(), flags=re.UNICODE)
    base = re.sub(r"[\s_]+", "-", base).strip("-") or "section"
    n = used.get(base, 0)
    used[base] = n + 1
    return base if n == 0 else f"{base}-{n}"


def _extract_toc_md(content: str) -> list[dict[str, int | str]]:
    used: dict[str, int] = {}
    toc: list[dict[str, int | str]] = []
    for line in content.splitlines():
        m = re.match(r"^(#{1,4})\s+(.+)$", line.strip())
        if not m:
            continue
        level = len(m.group(1))
        raw = m.group(2).strip()
        title = re.sub(r"\s+#+$", "", raw).strip()
        anchor = _slug_anchor(title, used)
        toc.append({"level": level, "title": title, "anchor": anchor})
        if len(toc) >= MAX_TOC:
            break
    return toc


def _strip_frontmatter(content: str) -> tuple[str, dict[str, str]]:
    if not content.startswith("---"):
        return content, {}
    end = content.find("\n---", 3)
    if end == -1:
        return content, {}
    block = content[3:end]
    rest = content[end + 4 :].lstrip("\n")
    meta: dict[str, str] = {}
    for line in block.splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            meta[k.strip()] = v.strip().strip('"').strip("'")
    return rest, meta


def _strip_md_search(text: str) -> str:
    t = re.sub(r"^#{1,6}\s+", " ", text, flags=re.MULTILINE)
    t = re.sub(r"[`*_]+", " ", t)
    return t.lower()


def _validate_file_in_docs(file_path: Path, docs_root: Path) -> None:
    raw = str(file_path)
    if ".." in raw.replace("\\", "/"):
        raise DashboardError(
            DashboardErrorCode.VALIDATION_ERROR,
            "Invalid path",
            detail="Path traversal not allowed",
            status_code=403,
        )
    try:
        fp = file_path.resolve()
        dr = docs_root.resolve()
        fp.relative_to(dr)
    except ValueError:
        raise DashboardError(
            DashboardErrorCode.VALIDATION_ERROR,
            "Access denied",
            detail="File is not under the project docs directory",
            status_code=403,
        ) from None


@docs_router.get("/tree")
def docs_tree(project_path: str = Query(..., description="Absolute path to project root")) -> dict[str, Any]:
    root = Path(project_path).expanduser().resolve()
    if not root.is_dir():
        raise DashboardError(
            DashboardErrorCode.FILE_NOT_FOUND,
            "Project path not found",
            detail=str(root),
            status_code=404,
        )
    docs_root = _resolve_docs_root(root)
    if docs_root is None:
        raise DashboardError(
            DashboardErrorCode.FILE_NOT_FOUND,
            "No docs folder found",
            detail=(
                f"No docs/, DOCS/, or documentation/ under {root}. "
                f"Run: forge init-docs --project-path {root}"
            ),
            status_code=404,
        )
    files, warnings = _collect_files(docs_root)
    if not files:
        warnings.append("docs folder is empty (no supported text files yet).")
    seen = {f["group"] for f in files}
    groups_ordered = [g for g in GROUP_ORDER if g in seen] + sorted(seen - set(GROUP_ORDER))
    return {
        "project_path": str(root),
        "project_name": root.name,
        "docs_path": str(docs_root.resolve()),
        "files": files,
        "groups": groups_ordered,
        "warnings": warnings,
    }


@docs_router.get("/file")
def docs_file(
    path: str = Query(..., description="Absolute path to file"),
    project_path: str = Query(..., description="Project root (must match tree resolution)"),
) -> dict[str, Any]:
    root = Path(project_path).expanduser().resolve()
    docs_root = _resolve_docs_root(root)
    if docs_root is None:
        raise DashboardError(
            DashboardErrorCode.FILE_NOT_FOUND,
            "No docs folder found",
            detail=str(root),
            status_code=404,
        )
    raw_path = unquote(path)
    file_path = Path(raw_path)
    _validate_file_in_docs(file_path, docs_root)
    if not file_path.is_file():
        raise DashboardError(
            DashboardErrorCode.FILE_NOT_FOUND,
            "File not found",
            detail=str(file_path),
            status_code=404,
        )
    suffix = file_path.suffix.lower()
    if suffix not in ALLOW_SUFFIXES:
        raise DashboardError(
            DashboardErrorCode.VALIDATION_ERROR,
            "Unsupported file type",
            detail=suffix,
            status_code=403,
        )
    if not _is_probably_text(file_path):
        raise DashboardError(
            DashboardErrorCode.VALIDATION_ERROR,
            "Cannot display binary file",
            detail=str(file_path.resolve()),
            status_code=415,
        )
    try:
        content = file_path.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        raise DashboardError(
            DashboardErrorCode.FILE_READ_ERROR,
            "Could not read file",
            detail=str(e),
            status_code=500,
        ) from e
    st = file_path.stat()
    modified = datetime.fromtimestamp(st.st_mtime, tz=timezone.utc).isoformat()
    title = _read_title_from_content(content, file_path.stem)
    toc: list[dict[str, int | str]] = []
    body = content
    meta: dict[str, str] = {}
    ftype = "markdown"
    if suffix == ".md":
        body, meta = _strip_frontmatter(content)
        title = _read_title_from_content(body, title)
        toc = _extract_toc_md(body)
    elif suffix in (".yaml", ".yml"):
        ftype = "yaml"
    elif suffix == ".json":
        ftype = "json"
    task_items: list[dict[str, Any]] = []
    file_annotations: list[dict[str, Any]] = []
    if suffix == ".md":
        task_items = extract_inline_tasks_for_file(file_path)
        file_annotations = read_annotations_for_file(file_path)
    return {
        "path": str(file_path.resolve()),
        "name": file_path.name,
        "title": title,
        "content": body if suffix == ".md" else content,
        "type": ftype,
        "modified": modified,
        "size": st.st_size,
        "large_file": st.st_size > LARGE_FILE_BYTES,
        "toc": toc,
        "frontmatter": meta,
        "task_items": task_items,
        "annotations": file_annotations,
        "project_path": str(root),
    }


@docs_router.get("/search")
def docs_search(
    project_path: str = Query(...),
    q: str = Query(..., min_length=2),
) -> dict[str, Any]:
    root = Path(project_path).expanduser().resolve()
    docs_root = _resolve_docs_root(root)
    if docs_root is None:
        raise DashboardError(
            DashboardErrorCode.FILE_NOT_FOUND,
            "No docs folder found",
            detail=str(root),
            status_code=404,
        )
    files, _ = _collect_files(docs_root)
    needle = q.lower()
    results: list[dict[str, Any]] = []
    total_matches = 0

    for finfo in files:
        if len(results) >= 20:
            break
        fpath = Path(finfo["path"])
        try:
            raw = fpath.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        search_text = _strip_md_search(raw) if fpath.suffix.lower() == ".md" else raw.lower()
        if needle not in search_text and needle not in finfo["title"].lower():
            continue
        lines = raw.splitlines()
        matches: list[dict[str, Any]] = []
        for i, line in enumerate(lines):
            check = _strip_md_search(line) if fpath.suffix.lower() == ".md" else line.lower()
            if needle not in check and needle not in line.lower():
                continue
            lo = max(0, i - 1)
            hi = min(len(lines), i + 2)
            context = "\n".join(lines[lo:hi])
            pos = line.lower().find(needle)
            if pos < 0:
                pos = line.lower().find(needle.lower())
            if pos < 0:
                pos = 0
            start = max(0, pos - 30)
            end = min(len(line), pos + len(needle) + 30)
            excerpt = line[start:end]
            matches.append({"line": i + 1, "context": context, "excerpt": excerpt})
            if len(matches) >= 5:
                break
        if not matches and needle in finfo["title"].lower():
            matches.append(
                {
                    "line": 1,
                    "context": lines[0] if lines else finfo["title"],
                    "excerpt": finfo["title"][: min(80, len(finfo["title"]))],
                }
            )
        if not matches:
            continue
        total_matches += len(matches)
        results.append(
            {
                "file_id": finfo["id"],
                "file_name": finfo["name"],
                "title": finfo["title"],
                "matches": matches,
                "match_count": len(matches),
            }
        )

    results.sort(key=lambda r: -r["match_count"])
    return {"query": q, "results": results, "total_matches": total_matches}


class AnnotationCreateBody(BaseModel):
    file_path: str = Field(..., min_length=1)
    anchor: str = Field(..., min_length=1)
    note: str = Field(..., min_length=1)
    tags: list[str] = Field(default_factory=list)


class AnnotationPatchBody(BaseModel):
    note: str | None = None
    tags: list[str] | None = None
    done: bool | None = None


@docs_router.get("/annotation-tags")
def docs_annotation_tags(project_path: str = Query(...)) -> dict[str, Any]:
    root = Path(project_path).expanduser().resolve()
    docs_root = _resolve_docs_root(root)
    if docs_root is None:
        raise DashboardError(
            DashboardErrorCode.FILE_NOT_FOUND,
            "No docs folder found",
            detail=str(root),
            status_code=404,
        )
    tags, by_file = list_all_annotation_tags(docs_root)
    return {"tags": tags, "files_by_tag": by_file}


@docs_router.get("/annotations")
def docs_get_annotations(
    project_path: str = Query(...),
    path: str = Query(..., description="Absolute path to .md file"),
) -> dict[str, Any]:
    root = Path(project_path).expanduser().resolve()
    docs_root = _resolve_docs_root(root)
    if docs_root is None:
        raise DashboardError(
            DashboardErrorCode.FILE_NOT_FOUND,
            "No docs folder found",
            detail=str(root),
            status_code=404,
        )
    fp = Path(unquote(path)).expanduser().resolve()
    _validate_file_in_docs(fp, docs_root)
    if fp.suffix.lower() != ".md":
        raise DashboardError(
            DashboardErrorCode.VALIDATION_ERROR,
            "Not a markdown file",
            detail=str(fp),
            status_code=403,
        )
    return {"annotations": read_annotations_for_file(fp)}


@docs_router.post("/annotations")
def docs_post_annotation(
    project_path: str = Query(...),
    body: AnnotationCreateBody = Body(...),
) -> dict[str, Any]:
    root = Path(project_path).expanduser().resolve()
    docs_root = _resolve_docs_root(root)
    if docs_root is None:
        raise DashboardError(
            DashboardErrorCode.FILE_NOT_FOUND,
            "No docs folder found",
            detail=str(root),
            status_code=404,
        )
    fp = Path(body.file_path).expanduser().resolve()
    _validate_file_in_docs(fp, docs_root)
    if fp.suffix.lower() != ".md":
        raise DashboardError(
            DashboardErrorCode.VALIDATION_ERROR,
            "Not a markdown file",
            detail=str(fp),
            status_code=403,
        )
    entry = create_annotation(fp, root, anchor=body.anchor, note=body.note, tags=body.tags)
    if entry is None:
        raise DashboardError(
            DashboardErrorCode.FILE_WRITE_ERROR,
            "Could not write annotation",
            detail=str(fp),
            status_code=500,
        )
    return {"annotation": entry}


@docs_router.patch("/annotations/{ann_id}")
def docs_patch_annotation(
    ann_id: str,
    project_path: str = Query(...),
    body: AnnotationPatchBody = Body(...),
) -> dict[str, Any]:
    root = Path(project_path).expanduser().resolve()
    docs_root = _resolve_docs_root(root)
    if docs_root is None:
        raise DashboardError(
            DashboardErrorCode.FILE_NOT_FOUND,
            "No docs folder found",
            detail=str(root),
            status_code=404,
        )
    entry = update_annotation(
        docs_root,
        ann_id,
        note=body.note,
        tags=body.tags,
        done=body.done,
    )
    if entry is None:
        raise DashboardError(
            DashboardErrorCode.FILE_NOT_FOUND,
            "Annotation not found",
            detail=ann_id,
            status_code=404,
        )
    return {"annotation": entry}


@docs_router.delete("/annotations/{ann_id}")
def docs_delete_annotation(ann_id: str, project_path: str = Query(...)) -> dict[str, Any]:
    root = Path(project_path).expanduser().resolve()
    docs_root = _resolve_docs_root(root)
    if docs_root is None:
        raise DashboardError(
            DashboardErrorCode.FILE_NOT_FOUND,
            "No docs folder found",
            detail=str(root),
            status_code=404,
        )
    ok = delete_annotation(docs_root, ann_id)
    if not ok:
        raise DashboardError(
            DashboardErrorCode.FILE_NOT_FOUND,
            "Annotation not found",
            detail=ann_id,
            status_code=404,
        )
    return {"deleted": True, "id": ann_id}
