"""
Sidecar annotation files: <doc>.md.notes.yaml next to markdown sources.
"""

from __future__ import annotations

import secrets
from datetime import date
from pathlib import Path
from typing import Any

import yaml

GITIGNORE_SNIPPET = "\n# forge board personal annotations\ndocs/*.notes.yaml\n"


def sidecar_path(md_path: Path) -> Path:
    return md_path.parent / f"{md_path.name}.notes.yaml"


def ensure_docs_gitignore(project_root: Path) -> None:
    """Append docs/*.notes.yaml to project .gitignore if missing."""
    gi = project_root / ".gitignore"
    try:
        existing = gi.read_text(encoding="utf-8") if gi.is_file() else ""
    except OSError:
        return
    if "*.notes.yaml" in existing or ".notes.yaml" in existing:
        return
    try:
        with gi.open("a", encoding="utf-8") as f:
            if existing and not existing.endswith("\n"):
                f.write("\n")
            f.write(GITIGNORE_SNIPPET.lstrip("\n") if existing else GITIGNORE_SNIPPET)
    except OSError:
        return


def _load_sidecar_raw(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {"annotations": []}
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
        data = yaml.safe_load(raw)
    except (OSError, yaml.YAMLError):
        return {"annotations": []}
    if not isinstance(data, dict):
        return {"annotations": []}
    ann = data.get("annotations")
    if not isinstance(ann, list):
        data["annotations"] = []
    return data


def _tags_inline(tags: list[str]) -> str:
    return " ".join(f"#{t}" for t in tags)


def read_annotations_for_file(md_path: Path) -> list[dict[str, Any]]:
    data = _load_sidecar_raw(sidecar_path(md_path))
    out = []
    for a in data.get("annotations", []):
        if isinstance(a, dict) and a.get("id"):
            out.append(a)
    return out


def list_all_annotation_tags(docs_root: Path) -> tuple[list[str], dict[str, list[str]]]:
    """Return sorted unique tags and map tag -> list of md basenames with that tag."""
    by_tag: dict[str, set[str]] = {}
    for p in sorted(docs_root.rglob("*.md.notes.yaml")):
        try:
            md_name = p.name.removesuffix(".notes.yaml")
            data = _load_sidecar_raw(p)
            for a in data.get("annotations", []):
                if not isinstance(a, dict):
                    continue
                tags = a.get("tags") or []
                if isinstance(tags, str):
                    tags = [t.strip().lstrip("#") for t in tags.split() if t.strip().startswith("#")]
                if not isinstance(tags, list):
                    continue
                for t in tags:
                    if not isinstance(t, str):
                        continue
                    tl = t.strip().lstrip("#").lower()
                    if not tl:
                        continue
                    by_tag.setdefault(tl, set()).add(md_name)
        except OSError:
            continue
    flat = sorted(by_tag.keys())
    return flat, {k: sorted(v) for k, v in by_tag.items()}


def create_annotation(
    md_path: Path,
    project_root: Path,
    *,
    anchor: str,
    note: str,
    tags: list[str],
) -> dict[str, Any] | None:
    sc = sidecar_path(md_path)
    data = _load_sidecar_raw(sc)
    ann_list = data.setdefault("annotations", [])
    if not isinstance(ann_list, list):
        data["annotations"] = []
        ann_list = data["annotations"]
    clean_tags = [t.strip().lstrip("#").lower() for t in tags if t.strip()]
    aid = f"ann-{secrets.token_hex(6)}"
    today = str(date.today())
    entry: dict[str, Any] = {
        "id": aid,
        "anchor": anchor.strip(),
        "note": note.strip(),
        "tags": clean_tags,
        "tags_inline": _tags_inline(clean_tags),
        "created": today,
        "done": False,
    }
    ann_list.append(entry)
    try:
        sc.parent.mkdir(parents=True, exist_ok=True)
        with sc.open("w", encoding="utf-8") as f:
            yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True)
    except OSError:
        return None
    ensure_docs_gitignore(project_root)
    return entry


def find_annotation_by_id(docs_root: Path, ann_id: str) -> tuple[Path, dict[str, Any], int] | None:
    for p in docs_root.rglob("*.md.notes.yaml"):
        data = _load_sidecar_raw(p)
        for i, a in enumerate(data.get("annotations", [])):
            if isinstance(a, dict) and a.get("id") == ann_id:
                md_path = p.parent / p.name.removesuffix(".notes.yaml")
                return md_path, data, i
    return None


def update_annotation(
    docs_root: Path,
    ann_id: str,
    *,
    note: str | None = None,
    tags: list[str] | None = None,
    done: bool | None = None,
) -> dict[str, Any] | None:
    found = find_annotation_by_id(docs_root, ann_id)
    if not found:
        return None
    _md_path, data, idx = found
    sc = sidecar_path(_md_path)
    ann_list = data.get("annotations", [])
    if idx >= len(ann_list):
        return None
    entry = ann_list[idx]
    if not isinstance(entry, dict):
        return None
    if note is not None:
        entry["note"] = note.strip()
    if tags is not None:
        clean_tags = [t.strip().lstrip("#").lower() for t in tags if t.strip()]
        entry["tags"] = clean_tags
        entry["tags_inline"] = _tags_inline(clean_tags)
    if done is not None:
        entry["done"] = bool(done)
    try:
        with sc.open("w", encoding="utf-8") as f:
            yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True)
    except OSError:
        return None
    return entry


def delete_annotation(docs_root: Path, ann_id: str) -> bool:
    found = find_annotation_by_id(docs_root, ann_id)
    if not found:
        return False
    md_path, data, idx = found
    sc = sidecar_path(md_path)
    ann_list = data.get("annotations", [])
    if idx >= len(ann_list):
        return False
    ann_list.pop(idx)
    try:
        if ann_list:
            with sc.open("w", encoding="utf-8") as f:
                yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True)
        else:
            sc.unlink(missing_ok=True)
    except OSError:
        return False
    return True
