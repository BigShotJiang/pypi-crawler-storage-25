from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import APIRouter, Body, HTTPException

from forge.archive.tui.textual.state import ProjectState
from forge.tools.audit.bundle import load_bundle
from forge.tools.audit.traversal import blast_radius_all_rings
from forge.tools.manifest.graph import build_manifest_graph
from forge.tools.registry.graph import derive_relations
from forge.tools.registry.store import _projects_map, load_registry


def _node_payload(node_id: str, label: str, kind: str, ring_id: int, **extra: Any) -> dict[str, Any]:
    out = {"id": node_id, "label": label, "kind": kind, "ring_id": ring_id}
    out.update(extra)
    return out


def create_graph_router(state_by_id: dict[str, ProjectState]) -> APIRouter:
    router = APIRouter()

    def _resolve_project(slug: str) -> Path:
        s = state_by_id.get(slug)
        if s:
            return s.project.path
        for pid, st in state_by_id.items():
            if pid == slug or st.project.name.lower() == slug.lower():
                return st.project.path
        raise HTTPException(status_code=404, detail=f"unknown project slug: {slug}")

    @router.get("/graph/registry")
    def graph_registry() -> dict[str, Any]:
        reg = load_registry()
        pmap = _projects_map(reg)
        rel = derive_relations(reg)
        nodes: list[dict[str, Any]] = []
        edges: list[dict[str, Any]] = []
        for k, v in pmap.items():
            if not isinstance(v, dict):
                continue
            pid = str(v.get("id") or k)
            nodes.append(_node_payload(f"ring1/{pid}", str(v.get("name") or pid), "project", 1, path=str(v.get("path") or "")))
        for src, pairs in rel.items():
            for relation, tgt in pairs:
                edges.append({"source": f"ring1/{src}", "target": f"ring1/{tgt}", "relation": relation, "derived": relation in ("cousin", "sibling_candidate", "parent")})
        return {"nodes": nodes, "edges": edges}

    @router.get("/graph/manifest/{project_slug}")
    def graph_manifest(project_slug: str) -> dict[str, Any]:
        root = _resolve_project(project_slug)
        g = build_manifest_graph(root)
        nodes = [_node_payload(f"ring2/{n.id}", n.name, n.kind, 2, path=n.path, domain=n.domain, parent_id=n.parent_id) for n in g.nodes]
        edges = [{"source": f"ring2/{e.from_id}", "target": f"ring2/{e.to_id}", "relation": e.relation, "derived": bool(e.derived)} for e in g.edges]
        return {"nodes": nodes, "edges": edges}

    @router.get("/graph/full/{project_slug}")
    def graph_full(project_slug: str) -> dict[str, Any]:
        root = _resolve_project(project_slug)
        rings: dict[str, dict[str, Any]] = {}
        cross_ring_edges: list[dict[str, Any]] = []
        bundle_path = root / "audit-map.bundle.json"
        if bundle_path.exists():
            b = load_bundle(bundle_path)
            for node in b.nodes:
                rid = str(int(getattr(node, "ring_id", 4) or 4))
                rings.setdefault(rid, {"nodes": [], "edges": []})
                rings[rid]["nodes"].append(
                    _node_payload(node.node_id, node.label or node.node_id, node.kind, int(rid), path=node.path, status=node.status)
                )
            by_ring = {n.node_id: int(getattr(n, "ring_id", 4) or 4) for n in b.nodes}
            for e in b.edges:
                sr = by_ring.get(e.from_node_id)
                tr = by_ring.get(e.to_node_id)
                if sr is None or tr is None:
                    continue
                if sr == tr:
                    rings.setdefault(str(sr), {"nodes": [], "edges": []})["edges"].append(
                        {"source": e.from_node_id, "target": e.to_node_id, "relation": e.relation, "derived": False}
                    )
                else:
                    cross_ring_edges.append({"source": e.from_node_id, "target": e.to_node_id, "relation": e.relation, "derived": False})
            for e in b.cross_ring_edges:
                cross_ring_edges.append({"source": e.from_node_id, "target": e.to_node_id, "relation": e.relation, "derived": True})
            return {"rings": rings, "cross_ring_edges": cross_ring_edges}

        reg = graph_registry()
        man = graph_manifest(project_slug)
        rings = {"1": {"nodes": reg["nodes"], "edges": reg["edges"]}, "2": {"nodes": man["nodes"], "edges": man["edges"]}}
        return {"rings": rings, "cross_ring_edges": []}

    @router.post("/graph/blast-radius")
    def graph_blast_radius(payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
        node_id = str(payload.get("node_id") or "")
        project_slug = str(payload.get("project_slug") or "")
        if not node_id or not project_slug:
            raise HTTPException(status_code=400, detail="node_id and project_slug are required")
        root = _resolve_project(project_slug)
        bundle_path = root / "audit-map.bundle.json"
        if not bundle_path.exists():
            raise HTTPException(status_code=404, detail="audit-map.bundle.json not found for project")
        b = load_bundle(bundle_path)
        raw = blast_radius_all_rings(node_id, b, max_depth=5)
        return {
            "node_id": node_id,
            "blast_radius": {
                str(k): [
                    {"id": n.node_id, "label": n.label, "kind": n.kind, "path": n.path, "status": n.status}
                    for n in v
                ]
                for k, v in raw.items()
            },
        }

    return router
