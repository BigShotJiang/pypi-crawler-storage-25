from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException

from forge.core.contract_graph import EdgeStatus
from forge.archive.tui.textual.state import ProjectState


def create_contracts_router(
    state_by_id: dict[str, ProjectState], contract_graph_holder: dict[str, Any]
) -> APIRouter:
    router = APIRouter()

    def _get_state(project_id: str) -> ProjectState:
        try:
            return state_by_id[project_id]
        except KeyError:
            raise HTTPException(status_code=404, detail="project not found")

    def _graph() -> Any:
        return contract_graph_holder["graph"]

    @router.get("/contracts")
    def get_contracts() -> dict[str, Any]:
        edges_payload: list[dict[str, Any]] = []
        for e in _graph().edges:
            edges_payload.append(
                {
                    "source_project": e.source_project,
                    "source_domain": e.source_domain,
                    "target_project": e.target_project,
                    "target_domain": e.target_domain,
                    "field_name": e.field_name,
                    "declared_type": e.declared_type,
                    "provided_type": e.provided_type,
                    "phase": e.phase,
                    "status": e.status.value,
                    "message": e.message,
                }
            )
        return {"edges": edges_payload}

    @router.get("/projects/{project_id}/contracts")
    def get_project_contracts(project_id: str) -> dict[str, Any]:
        _get_state(project_id)
        intra = _graph().intra_edges(project_id)
        inter = _graph().inter_edges(project_id)

        def _serialize(edges: list[Any]) -> list[dict[str, Any]]:
            out: list[dict[str, Any]] = []
            for e in edges:
                out.append(
                    {
                        "source_project": e.source_project,
                        "source_domain": e.source_domain,
                        "target_project": e.target_project,
                        "target_domain": e.target_domain,
                        "field_name": e.field_name,
                        "declared_type": e.declared_type,
                        "provided_type": e.provided_type,
                        "phase": e.phase,
                        "status": e.status.value,
                        "message": e.message,
                    }
                )
            return out

        return {"intra": _serialize(intra), "inter": _serialize(inter)}

    @router.get("/projects/{project_id}/conformance")
    def get_conformance(project_id: str) -> dict[str, Any]:
        _get_state(project_id)
        graph = _graph()
        score = graph.conformance_score(project_id)
        relevant = [
            e
            for e in graph.edges
            if e.source_project == project_id or e.target_project == project_id
        ]
        broken = sum(1 for e in relevant if e.status == EdgeStatus.BROKEN)
        orphaned = sum(1 for e in relevant if e.status == EdgeStatus.ORPHANED)
        planned = sum(1 for e in relevant if e.status == EdgeStatus.PLANNED)
        active = sum(1 for e in relevant if e.status == EdgeStatus.ACTIVE)
        return {
            "score": score,
            "broken": broken,
            "orphaned": orphaned,
            "planned": planned,
            "active": active,
        }

    return router

