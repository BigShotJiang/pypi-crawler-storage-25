from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException

from forge.archive.tui.textual.manifest_reader import FileContract, ManifestData, read_manifest
from forge.archive.tui.textual.readiness import ReadinessReport, compute_readiness
from forge.archive.tui.textual.state import ProjectState


def _intent_coverage_compact_for_board(project_path: Path) -> dict[str, Any] | None:
    """Same compact rollup as MCP orient / project_status — for forge board JSON API.

    When present, ``intent_coverage_compact`` is a stable diagnostic envelope (see
    ``forge.mcp.thin_core._intent_coverage_compact_summary``), including e.g.
    ``engine_domain_node_count``, ``engine_imports_inbound_total``,
    ``engine_python_glove_imports_to_engine_total``,
    ``intent_target_graph_path_python_syntax_rate`` (``.py`` files only),     ``intent_target_graph_path_import_resolve_rate``,
    ``intent_target_graph_path_imports_inbound_rate``,
    ``intent_target_graph_path_python_funcdef_annotation_rate``,
    ``intent_target_graph_path_python_compile_rate``,
    and ``graph_cache_loaded``.
    Values may be ``null``; keys are intended to remain stable for dashboard clients.
    The archived React board project overview (``IntentCoveragePanel``) renders this payload.
    """
    try:
        from forge.mcp.thin_core import _intent_coverage_compact_summary

        return _intent_coverage_compact_summary(project_path.expanduser().resolve())
    except Exception:
        return None


def _count_open_tasks(project_path: Path) -> int:
    """Count open (not done) tasks in docs/TODO.md for a project."""
    todo_path = project_path / "docs" / "TODO.md"
    if not todo_path.exists():
        return 0

    open_count = 0
    try:
        for raw_line in todo_path.read_text().splitlines():
            stripped = raw_line.strip()
            if stripped.startswith("- [") and not (
                stripped.startswith("- [x]") or stripped.startswith("- [X]")
            ):
                open_count += 1
    except Exception:
        return 0
    return open_count


def create_projects_router(
    state_by_id: dict[str, ProjectState], started_at: datetime
) -> APIRouter:
    router = APIRouter()

    def _get_state(project_id: str) -> ProjectState:
        try:
            return state_by_id[project_id]
        except KeyError:
            raise HTTPException(status_code=404, detail="project not found")

    def _get_phase_label(state: ProjectState) -> Any:
        project = state.project
        current = getattr(project, "current_phase", None)
        if callable(current):
            try:
                return current()
            except Exception:
                pass
        phases = getattr(project, "phases", None)
        if isinstance(phases, dict) and phases:
            try:
                numeric_keys = [
                    int(k)
                    for k in phases.keys()
                    if isinstance(k, (int, str)) and str(k).isdigit()
                ]
                if numeric_keys:
                    return max(numeric_keys)
            except Exception:
                try:
                    return list(phases.keys())[-1]
                except Exception:
                    pass
        return None

    @router.get("/projects")
    def list_projects() -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for pid, state in state_by_id.items():
            root = Path(state.project.path)
            row: dict[str, Any] = {
                "id": pid,
                "name": state.project.name,
                "root": str(root),
                "health_score": state.health_score,
                "readiness_score": state.readiness.score_pct if state.readiness else None,
                "phase": _get_phase_label(state),
                "open_tasks": _count_open_tasks(root),
            }
            ic = _intent_coverage_compact_for_board(root)
            if ic is not None:
                row["intent_coverage_compact"] = ic
            rows.append(row)
        return rows

    @router.get("/projects/{project_id}")
    def get_project(project_id: str) -> dict[str, Any]:
        state = _get_state(project_id)
        root = Path(state.project.path)
        out: dict[str, Any] = {
            "id": project_id,
            "name": state.project.name,
            "root": str(root),
            "health_score": state.health_score,
            "readiness_score": state.readiness.score_pct if state.readiness else None,
        }
        ic = _intent_coverage_compact_for_board(root)
        if ic is not None:
            out["intent_coverage_compact"] = ic
        return out

    @router.get("/projects/{project_id}/manifest")
    def get_manifest(project_id: str) -> ManifestData:
        state = _get_state(project_id)
        return read_manifest(state.project)

    @router.get("/projects/{project_id}/readiness")
    def get_readiness(project_id: str) -> ReadinessReport:
        state = _get_state(project_id)
        if state.readiness is not None:
            return state.readiness
        manifest = read_manifest(state.project)
        return compute_readiness(state.project, manifest)

    @router.get("/projects/{project_id}/files")
    def get_files(project_id: str) -> list[dict[str, Any]]:
        state = _get_state(project_id)
        try:
            manifest = read_manifest(state.project)
        except Exception:
            return []
        if manifest is None:
            return []

        controllers = getattr(manifest, "controllers", []) or []
        files: list[FileContract] = list(controllers)
        all_files = getattr(manifest, "all_files", None)
        if isinstance(all_files, list):
            files = list(all_files)

        result: list[dict[str, Any]] = []
        for fc in files:
            result.append(
                {
                    "path": str(fc.path),
                    "name": getattr(fc, "name", ""),
                    "domain": getattr(fc, "domain", None),
                    "phase": getattr(fc, "phase", None),
                    "debug_only": getattr(fc, "debug_only", False),
                    "is_controller": getattr(fc, "is_controller", False),
                    "is_screen": getattr(fc, "is_screen", False),
                }
            )
        return result

    @router.get("/projects/{project_id}/files/{file_path:path}")
    def get_file(project_id: str, file_path: str) -> FileContract:
        state = _get_state(project_id)
        try:
            manifest = read_manifest(state.project)
        except Exception:
            raise HTTPException(status_code=404, detail="file not found")
        if manifest is None:
            raise HTTPException(status_code=404, detail="file not found")

        all_files = getattr(manifest, "all_files", None)
        candidates: list[FileContract]
        if isinstance(all_files, list):
            candidates = list(all_files)
        else:
            controllers = getattr(manifest, "controllers", []) or []
            candidates = list(controllers)

        normalized = file_path.replace("\\", "/")
        for fc in candidates:
            if str(fc.path).replace("\\", "/") == normalized:
                return fc
        raise HTTPException(status_code=404, detail="file not found")

    @router.get("/status")
    def get_status() -> dict[str, Any]:
        now = datetime.now(timezone.utc)
        return {
            "version": "1.0.0",
            "uptime_seconds": int((now - started_at).total_seconds()),
            "projects_count": len(state_by_id),
        }

    return router

