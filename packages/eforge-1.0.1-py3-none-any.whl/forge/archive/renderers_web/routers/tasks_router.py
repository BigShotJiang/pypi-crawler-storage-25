from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from forge.archive.tui.textual.state import ProjectState
from forge.renderers.web.tasks_md import (
    collect_all_docs_md_tasks,
    load_todo_groups,
    toggle_task_line_in_file,
)


class TaskToggleBody(BaseModel):
    group_label: str = Field(..., min_length=1)
    task_text: str = Field(..., min_length=1)
    checked: bool
    file_path: str | None = None


def create_tasks_router(state_by_id: dict[str, ProjectState]) -> APIRouter:
    router = APIRouter()

    def _get_state(project_id: str) -> ProjectState:
        try:
            return state_by_id[project_id]
        except KeyError:
            raise HTTPException(status_code=404, detail="project not found")

    def _current_phase(groups: list[dict[str, Any]]) -> str | None:
        current_phase: str | None = None
        for g in groups:
            label = str(g.get("label", ""))
            if "current" in label.lower():
                current_phase = label
                break
        if current_phase is None:
            for g in groups:
                label = str(g.get("label", ""))
                tasks = g.get("tasks") or []
                if any(not t.get("done") for t in tasks):
                    current_phase = label
                    break
        return current_phase

    @router.get("/projects/{project_id}/tasks")
    def get_tasks(
        project_id: str,
        scope: Literal["todo", "all"] = "todo",
    ) -> dict[str, Any]:
        state = _get_state(project_id)
        docs = state.project.path / "docs"
        if scope == "todo":
            todo_path = docs / "TODO.md"
            groups = load_todo_groups(todo_path)
            return {"current_phase": _current_phase(groups), "groups": groups, "scope": scope}

        if not docs.is_dir():
            return {"current_phase": None, "groups": [], "scope": scope}
        groups = collect_all_docs_md_tasks(docs)
        return {"current_phase": _current_phase(groups), "groups": groups, "scope": scope}

    @router.post("/projects/{project_id}/tasks/toggle")
    def toggle_task(project_id: str, body: TaskToggleBody) -> dict[str, Any]:
        state = _get_state(project_id)
        docs = state.project.path / "docs"
        if body.file_path:
            target = Path(body.file_path).expanduser().resolve()
        else:
            target = (docs / "TODO.md").resolve()
        try:
            docs_r = docs.resolve()
            target.relative_to(docs_r)
        except ValueError:
            return {"success": False, "line": None, "error": "file not under project docs"}
        if not target.is_file():
            return {"success": False, "line": None, "error": "file not found"}
        ok, line_no, err = toggle_task_line_in_file(target, body.group_label, body.task_text, body.checked)
        if ok:
            return {"success": True, "line": line_no, "error": None}
        return {"success": False, "line": None, "error": err or "toggle failed"}

    return router
