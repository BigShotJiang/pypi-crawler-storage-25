from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from fastapi import APIRouter, Body, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from forge.commands.config_cmd import (
    ALLOWED_TOP_LEVEL,
    _get_key,
    _set_key,
    locate_app_config,
    read_config,
    resolve_project_root,
    write_config,
)
from forge.core.contract_graph import build_contract_graph
from forge.core.manifest_path import resolve_manifest_path
from forge.archive.tui.textual.state import ProjectState


class ConfigChange(BaseModel):
    layer: str
    field_path: str
    new_value: Any


class ConfigSetRequest(BaseModel):
    project_path: str
    key: str
    value: Any


class ConfigValidateRequest(BaseModel):
    project_path: str


ConfigChange.model_rebuild()


def create_config_router(
    state_by_id: dict[str, ProjectState], contract_graph_holder: dict[str, Any]
) -> APIRouter:
    router = APIRouter()

    def _get_state(project_id: str) -> ProjectState:
        try:
            return state_by_id[project_id]
        except KeyError:
            raise HTTPException(status_code=404, detail="project not found")

    @router.get("/projects/{project_id}/config/runtime")
    def get_runtime_config(project_id: str) -> dict[str, Any]:
        state = _get_state(project_id)
        root = state.project.path
        candidates = [root / "assets" / "app_config.yaml", root / "app_config.yaml"]
        cfg_path: Path | None = None
        for c in candidates:
            if c.exists():
                cfg_path = c
                break
        if cfg_path is None:
            return {}

    @router.get("/config/show")
    def config_show(project_path: str) -> dict[str, Any]:
        root = resolve_project_root(project_path)
        cfg = locate_app_config(root)
        if cfg is None:
            return JSONResponse(
                status_code=404,
                content={"error": "app_config.yaml not found", "project_path": str(root)},
            )
        data = read_config(cfg)
        return {"file_path": str(cfg), "config": data}

    @router.post("/config/set")
    def config_set(req: ConfigSetRequest = Body(...)) -> dict[str, Any]:
        root = resolve_project_root(req.project_path)
        cfg = locate_app_config(root)
        if cfg is None:
            return JSONResponse(
                status_code=404,
                content={"error": "app_config.yaml not found", "project_path": str(root)},
            )
        data = read_config(cfg)
        old, updated = _set_key(data, req.key, req.value)
        write_config(cfg, updated)
        ok, newv = _get_key(updated, req.key)
        return {
            "key": req.key,
            "old_value": old,
            "new_value": newv if ok else None,
            "file_path": str(cfg),
            "dry_run": False,
        }

    @router.post("/config/validate")
    def config_validate(req: ConfigValidateRequest = Body(...)) -> dict[str, Any]:
        root = resolve_project_root(req.project_path)
        cfg = locate_app_config(root)
        if cfg is None:
            return {
                "status": "fail",
                "exit_code": 2,
                "checks": [
                    {
                        "id": "config.exists",
                        "label": "Config exists",
                        "status": "fail",
                        "message": "app_config.yaml missing",
                    }
                ],
            }
        checks: list[dict[str, str]] = []
        try:
            data = read_config(cfg)
            checks.append(
                {
                    "id": "yaml",
                    "label": "Valid YAML",
                    "status": "pass",
                    "message": "ok",
                }
            )
        except Exception as exc:
            return {
                "status": "fail",
                "exit_code": 2,
                "checks": [
                    {
                        "id": "yaml",
                        "label": "Valid YAML",
                        "status": "fail",
                        "message": str(exc),
                    }
                ],
            }
        required = [
            "app.name",
            "app.version",
            "ui_lab.active_variants",
            "features",
            "debug",
            "ui",
            "monetization",
        ]
        has_warn = False
        for key in required:
            ok, _ = _get_key(data, key)
            if ok:
                checks.append(
                    {"id": key, "label": key, "status": "pass", "message": "present"}
                )
            else:
                checks.append(
                    {"id": key, "label": key, "status": "warn", "message": "missing"}
                )
                has_warn = True
        unknown = (
            [k for k in data.keys() if k not in ALLOWED_TOP_LEVEL]
            if isinstance(data, dict)
            else []
        )
        if unknown:
            checks.append(
                {
                    "id": "top_level",
                    "label": "Top-level keys",
                    "status": "warn",
                    "message": f"unknown keys: {', '.join(unknown)}",
                }
            )
            has_warn = True
        return {"status": "warn" if has_warn else "pass", "exit_code": 1 if has_warn else 0, "checks": checks}

    @router.get("/config/diff")
    def config_diff(project_path: str, since: str | None = None) -> dict[str, Any]:
        import subprocess

        root = resolve_project_root(project_path)
        cfg = locate_app_config(root)
        if cfg is None:
            return JSONResponse(
                status_code=404,
                content={"error": "app_config.yaml not found", "project_path": str(root)},
            )
        if since:
            rel = str(cfg.relative_to(root))
            proc = subprocess.run(
                ["git", "-C", str(root), "diff", since, "--", rel],
                capture_output=True,
                text=True,
                check=False,
            )
            changes: list[dict[str, Any]] = []
            for line in proc.stdout.splitlines():
                if line.startswith("+") or line.startswith("-"):
                    if line.startswith("+++") or line.startswith("---"):
                        continue
                    changes.append(
                        {
                            "key": line[1:60],
                            "old_value": None,
                            "new_value": None,
                            "type": "line",
                        }
                    )
            return {"changes": changes}
        return {"changes": []}

        try:
            data = yaml.safe_load(cfg_path.read_text()) or {}
            if isinstance(data, dict):
                return data
            return {"value": data}
        except Exception:
            return {}

    def _resolve_config_path(state: ProjectState, layer: str) -> Path | None:
        root = state.project.path
        if layer == "runtime":
            for c in [root / "assets" / "app_config.yaml", root / "app_config.yaml"]:
                if c.exists():
                    return c
            return None
        return resolve_manifest_path(root)

    def _apply_field_path(mapping: dict, path: str, value: Any) -> dict:
        parts = [p for p in path.split(".") if p]
        if not parts:
            return mapping
        cur: Any = mapping
        for key in parts[:-1]:
            if not isinstance(cur, dict):
                return mapping
            if key not in cur or not isinstance(cur[key], dict):
                cur[key] = {}
            cur = cur[key]
        if isinstance(cur, dict):
            cur[parts[-1]] = value
        return mapping

    def _compute_diff(old: str, new: str) -> str:
        import difflib

        old_lines = old.splitlines(keepends=True)
        new_lines = new.splitlines(keepends=True)
        diff_lines = difflib.unified_diff(
            old_lines, new_lines, fromfile="before", tofile="after"
        )
        return "".join(diff_lines)

    @router.post("/projects/{project_id}/config/preview")
    def preview_config_change(
        project_id: str, change: ConfigChange = Body(...)
    ) -> dict[str, Any]:
        state = _get_state(project_id)
        cfg_path = _resolve_config_path(state, change.layer)
        if cfg_path is None:
            return JSONResponse(status_code=404, content={"error": "config file not found"})

        original_text = cfg_path.read_text() if cfg_path.exists() else ""
        try:
            parsed = yaml.safe_load(original_text) if original_text else {}
        except Exception:
            parsed = {}
        if not isinstance(parsed, dict):
            parsed = {}

        updated = _apply_field_path(parsed, change.field_path, change.new_value)
        new_text = yaml.safe_dump(updated, sort_keys=False)
        diff = _compute_diff(original_text, new_text)
        return {"file": str(cfg_path), "diff": diff, "contract_impact": []}

    @router.post("/projects/{project_id}/config/apply")
    def apply_config_change(
        project_id: str, change: ConfigChange = Body(...)
    ) -> dict[str, Any]:
        state = _get_state(project_id)
        cfg_path = _resolve_config_path(state, change.layer)
        if cfg_path is None:
            return JSONResponse(
                status_code=404,
                content={"applied": False, "error": "config file not found"},
            )

        original_text = cfg_path.read_text() if cfg_path.exists() else ""
        try:
            parsed = yaml.safe_load(original_text) if original_text else {}
        except Exception:
            parsed = {}
        if not isinstance(parsed, dict):
            parsed = {}

        before_score = contract_graph_holder["graph"].conformance_score(project_id)
        updated = _apply_field_path(parsed, change.field_path, change.new_value)
        new_text = yaml.safe_dump(updated, sort_keys=False)
        try:
            cfg_path.parent.mkdir(parents=True, exist_ok=True)
            cfg_path.write_text(new_text)
        except Exception as exc:
            return JSONResponse(
                status_code=500, content={"applied": False, "error": str(exc)}
            )

        contract_graph_holder["graph"] = build_contract_graph(list(state_by_id.values()))
        after_score = contract_graph_holder["graph"].conformance_score(project_id)
        return {
            "applied": True,
            "file": str(cfg_path),
            "conformance_delta": after_score - before_score,
        }

    return router

