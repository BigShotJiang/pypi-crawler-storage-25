from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException

from forge.archive.tui.textual.manifest_reader import read_manifest
from forge.archive.tui.textual.state import ProjectState


def create_health_router(state_by_id: dict[str, ProjectState]) -> APIRouter:
    router = APIRouter()

    def _get_state(project_id: str) -> ProjectState:
        try:
            return state_by_id[project_id]
        except KeyError:
            raise HTTPException(status_code=404, detail="project not found")

    @router.get("/projects/{project_id}/health")
    def get_health(project_id: str) -> dict[str, Any]:
        state = _get_state(project_id)
        try:
            manifest = read_manifest(state.project)
        except Exception:
            return {"overall": state.health_score, "domains": {}}
        if manifest is None:
            return {"overall": state.health_score, "domains": {}}

        domains: set[str] = set()
        controllers = getattr(manifest, "controllers", []) or []
        for fc in controllers:
            domain = getattr(fc, "domain", None)
            if domain:
                domains.add(str(domain).upper())

        results = state.check_results or []
        domain_map: dict[str, dict[str, Any]] = {}
        for dom in sorted(domains):
            dom_checks = [cr for cr in results if dom in (cr.label or "").upper()]
            if not dom_checks:
                domain_map[dom] = {"score": 100, "status": "ok", "issues": []}
                continue

            score = 100
            issues: list[str] = []
            for cr in dom_checks:
                if cr.status == "warn":
                    score = min(score, 70)
                    if cr.value:
                        issues.append(str(cr.value))
                    elif cr.error:
                        issues.append(str(cr.error))
                    else:
                        issues.append(cr.label)
                elif cr.status == "fail":
                    score = min(score, 40)
                    if cr.value:
                        issues.append(str(cr.value))
                    elif cr.error:
                        issues.append(str(cr.error))
                    else:
                        issues.append(cr.label)
            status = "ok" if score >= 80 else "warn" if score >= 60 else "fail"
            domain_map[dom] = {"score": score, "status": status, "issues": issues}

        return {"overall": state.health_score, "domains": domain_map}

    return router

