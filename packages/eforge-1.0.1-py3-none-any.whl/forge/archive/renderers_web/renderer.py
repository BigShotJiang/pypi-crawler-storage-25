from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Sequence

from forge.renderers.base import RendererProtocol
from forge.archive.tui.textual.state_types import ProjectState


@dataclass
class WebRenderer(RendererProtocol):
    """Web renderer that serves the denvboard FastAPI app."""

    port: int = 7331

    def run(self, states: Iterable[ProjectState]) -> None:  # type: ignore[override]
        # Import locally to avoid mandatory FastAPI/uvicorn dependency for non-board users.
        import threading
        import time
        import webbrowser

        import uvicorn  # type: ignore[import-not-found]

        from forge.renderers.web.server import create_app

        state_list: Sequence[ProjectState] = list(states)
        app = create_app(state_list)

        def _open_browser() -> None:
            time.sleep(1.2)
            webbrowser.open(f"http://localhost:{self.port}")

        thread = threading.Thread(target=_open_browser, daemon=True)
        thread.start()

        try:
            uvicorn.run(app, host="127.0.0.1", port=self.port)
        except KeyboardInterrupt:  # pragma: no cover - interactive shutdown
            # Clean shutdown on Ctrl+C; uvicorn handles server teardown.
            pass

