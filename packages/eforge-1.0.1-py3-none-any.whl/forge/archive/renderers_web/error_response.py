from __future__ import annotations

import logging
import traceback

from fastapi.responses import JSONResponse

from forge.renderers.web.error_codes import DashboardErrorCode

logger = logging.getLogger("forge.dashboard")


class DashboardError(Exception):
    def __init__(
        self,
        code: DashboardErrorCode,
        message: str,
        detail: str | None = None,
        status_code: int = 500,
    ):
        self.code = code
        self.message = message
        self.detail = detail
        self.status_code = status_code
        super().__init__(message)


def error_response(
    code: DashboardErrorCode,
    message: str,
    detail: str | None = None,
    status_code: int = 500,
) -> JSONResponse:
    logger.error(
        f"[{code.value}] {message}" + (f" | {detail}" if detail else "")
    )
    return JSONResponse(
        status_code=status_code,
        content={
            "error": True,
            "code": code.value,
            "message": message,
            "detail": detail,
        },
    )


def handle_unexpected(e: Exception, context: str) -> JSONResponse:
    tb = traceback.format_exc()
    logger.error(f"[DASH_E001] Unexpected error in {context}:\n{tb}")
    return error_response(
        DashboardErrorCode.INTERNAL_ERROR,
        f"Unexpected error in {context}",
        detail=str(e),
        status_code=500,
    )

