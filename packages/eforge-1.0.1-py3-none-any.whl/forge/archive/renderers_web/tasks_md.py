"""
Parse markdown task lists (- [ ] / - [x]) for board Tasks panel and Docs viewer.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

SKIP_DIR_NAMES = frozenset({"node_modules", "__pycache__", ".git", ".idea", ".vscode", "dist", "build"})

_CHECKBOX_LINE = re.compile(r"^(\s*-\s+)\[([ xX])\](\s*)(.*)$")


def split_trailing_tags(text: str) -> tuple[str, list[str]]:
    """Strip Obsidian-style #tags from end; return (display_text, tags)."""
    parts = text.strip().split()
    tags: list[str] = []
    while parts and parts[-1].startswith("#") and len(parts[-1]) > 1:
        w = parts[-1][1:]
        if re.fullmatch(r"[A-Za-z0-9_-]+", w):
            tags.insert(0, w.lower())
            parts.pop()
        else:
            break
    return (" ".join(parts).strip(), tags)


def _priority_from_text(text: str) -> str:
    lowered = text.lower()
    if "p0" in lowered or "p1" in lowered or "!!" in lowered:
        return "high"
    if "p3" in lowered or "nice to have" in lowered:
        return "low"
    return "medium"


def _parse_group_label_for_file(group_label: str, file_path: Path) -> str:
    """Resolve section heading from API group label (may be 'FILE.md — Section')."""
    bn = file_path.name
    for sep in (" — ", " – ", " - "):
        if sep in group_label:
            left, right = group_label.split(sep, 1)
            if left.strip() == bn:
                return right.strip()
    return group_label.strip()


def parse_md_task_groups(
    lines: list[str],
    *,
    file_name: str | None = None,
    file_path_str: str | None = None,
    label_prefix_file: bool = False,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """
    Returns (groups, inline_tasks).
    Each group: label, file?, file_path?, tasks[{text, done, priority, notes, tags, line}]
    """
    groups: list[dict[str, Any]] = []
    inline_tasks: list[dict[str, Any]] = []
    current_group: dict[str, Any] | None = None
    current_section_title: str | None = None
    last_task: dict[str, Any] | None = None

    for line_idx, raw_line in enumerate(lines, start=1):
        line = raw_line.rstrip("\n")
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("#") and not stripped.startswith("##"):
            continue
        if stripped.startswith("##"):
            section = stripped.lstrip("#").strip()
            current_section_title = section
            display_label = section
            if label_prefix_file and file_name:
                display_label = f"{file_name} — {section}"
            current_group = {
                "label": display_label,
                "section": section,
                "section_anchor": slugify_heading(section),
                "tasks": [],
            }
            if file_name:
                current_group["file"] = file_name
            if file_path_str:
                current_group["file_path"] = file_path_str
            groups.append(current_group)
            last_task = None
            continue
        m_cb = _CHECKBOX_LINE.match(line)
        if m_cb:
            _indent, mark, _sp, rest = m_cb.groups()
            done = mark.lower() == "x"
            display, tags = split_trailing_tags(rest.strip())
            if current_group is None:
                display_label = "Tasks"
                if label_prefix_file and file_name:
                    display_label = f"{file_name} — Tasks"
                current_group = {
                    "label": display_label,
                    "section": None,
                    "section_anchor": None,
                    "tasks": [],
                }
                if file_name:
                    current_group["file"] = file_name
                if file_path_str:
                    current_group["file_path"] = file_path_str
                groups.append(current_group)
            priority = _priority_from_text(display)
            task = {
                "text": display,
                "done": done,
                "priority": priority,
                "tags": tags,
                "line": line_idx,
            }
            current_group["tasks"].append(task)
            last_task = task
            inline_tasks.append(
                {
                    "line": line_idx,
                    "group_label": current_group["label"],
                    "section": current_section_title,
                    "text": display,
                    "done": done,
                    "tags": tags,
                }
            )
            continue
        if stripped.startswith("→") or stripped.startswith("Detail:") or stripped.startswith("detail:"):
            if last_task is not None:
                note = stripped.lstrip("→").strip()
                existing = last_task.get("notes")
                if existing:
                    last_task["notes"] = f"{existing} {note}"
                else:
                    last_task["notes"] = note
            continue

    return groups, inline_tasks


def load_todo_groups(todo_path: Path) -> list[dict[str, Any]]:
    if not todo_path.is_file():
        return []
    try:
        lines = todo_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    groups, _ = parse_md_task_groups(
        lines,
        file_name="TODO.md",
        file_path_str=str(todo_path.resolve()),
        label_prefix_file=False,
    )
    for g in groups:
        g.setdefault("file", "TODO.md")
        g.setdefault("file_path", str(todo_path.resolve()))
    return groups


def collect_all_docs_md_tasks(docs_root: Path) -> list[dict[str, Any]]:
    all_groups: list[dict[str, Any]] = []
    for path in sorted(docs_root.rglob("*.md")):
        try:
            rel = path.relative_to(docs_root)
        except ValueError:
            continue
        if any(p in SKIP_DIR_NAMES for p in rel.parts):
            continue
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        groups, _ = parse_md_task_groups(
            lines,
            file_name=path.name,
            file_path_str=str(path.resolve()),
            label_prefix_file=True,
        )
        all_groups.extend(groups)
    return all_groups


def extract_inline_tasks_for_file(path: Path) -> list[dict[str, Any]]:
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    _, inline = parse_md_task_groups(
        lines,
        file_name=path.name,
        file_path_str=str(path.resolve()),
        label_prefix_file=False,
    )
    return inline


def toggle_task_line_in_file(
    file_path: Path,
    group_label: str,
    task_text: str,
    checked: bool,
) -> tuple[bool, int | None, str | None]:
    """
    Toggle first matching checkbox in group. Returns (ok, 1-based line or None, error).
    Never raises for I/O — returns error string.
    """
    if ".." in str(file_path).replace("\\", "/"):
        return False, None, "invalid path"
    try:
        text = file_path.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        return False, None, str(e)
    raw_lines = text.splitlines(keepends=True)
    bare = [ln.rstrip("\n\r") for ln in raw_lines]
    section_key = _parse_group_label_for_file(group_label, file_path)
    in_section = False
    current_section: str | None = None
    target = task_text.strip()

    for i, ln in enumerate(bare):
        st = ln.strip()
        if st.startswith("##"):
            current_section = st.lstrip("#").strip()
            in_section = current_section == section_key
            continue
        m = _CHECKBOX_LINE.match(ln)
        if not m:
            continue
        if not in_section:
            if current_section is None and section_key in ("Tasks", group_label.strip()):
                in_section = True
            if not in_section:
                continue
        indent, mark, sp, rest = m.groups()
        done = mark.lower() == "x"
        display, _tags = split_trailing_tags(rest.strip())
        if display != target:
            continue
        if done == checked:
            return True, i + 1, None
        new_mark = "x" if checked else " "
        new_line = f"{indent}[{new_mark}]{sp}{rest}"
        bare[i] = new_line
        parts: list[str] = []
        for j, ln in enumerate(bare):
            if j < len(raw_lines):
                old = raw_lines[j]
                if old.endswith("\r\n"):
                    parts.append(ln + "\r\n")
                elif old.endswith("\n"):
                    parts.append(ln + "\n")
                elif old.endswith("\r"):
                    parts.append(ln + "\r")
                else:
                    parts.append(ln)
            else:
                parts.append(ln + "\n")
        rebuilt = "".join(parts)
        try:
            file_path.write_text(rebuilt, encoding="utf-8")
        except OSError as e:
            return False, None, str(e)
        return True, i + 1, None

    return False, None, "task not found"


def count_open_tasks_in_file(path: Path) -> int:
    inline = extract_inline_tasks_for_file(path)
    return sum(1 for t in inline if not t["done"])


def slugify_heading(title: str) -> str:
    """Match docs_router TOC slug for a single heading (first occurrence)."""
    base = re.sub(r"[^\w\s-]", "", title.lower().strip(), flags=re.UNICODE)
    base = re.sub(r"[\s_]+", "-", base).strip("-") or "section"
    return base
