import click

from forge.core.discovery import discover_projects, get_projects_root

# Trigger renderer registration
import forge.renderers  # noqa: F401
from forge.renderers.base import RendererRegistry
from forge.archive.tui.textual.state_types import ProjectState


@click.command()
@click.option(
    "--renderer",
    type=click.Choice(["auto", "textual", "rich"], case_sensitive=False),
    default="auto",
    help="Renderer: auto (detect), textual (TUI), rich (print and exit).",
)
def dashboard_cmd(renderer: str) -> None:
    """Launch the dashboard (TUI or rich output)."""
    click.echo(
        "⚠ forge dashboard is deprecated. Use: forge board",
        err=True,
    )
    projects = discover_projects(get_projects_root())
    states = [ProjectState.load(p) for p in projects]
    r = RendererRegistry.resolve(renderer)
    r.run(states)
