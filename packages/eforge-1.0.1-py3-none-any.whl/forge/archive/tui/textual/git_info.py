"""GitInfo helper — subprocess git calls. No UI imports."""

from dataclasses import dataclass


@dataclass
class GitInfo:
    branch: str = "unknown"
    last_commit_msg: str = ""
    last_commit_age: str = ""
    is_clean: bool = True
    remote_url: str = ""
    linked_issue_number: int | None = None
    error: str | None = None


def load_git_info(project_path) -> GitInfo:
    """Run git commands; return GitInfo. Never raises."""
    import subprocess
    from pathlib import Path
    info = GitInfo()
    path = getattr(project_path, "path", project_path)
    if not path or not path.exists():
        info.error = "Project path missing"
        return info
    try:
        r = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=path,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if r.returncode == 0 and r.stdout:
            info.branch = r.stdout.strip()
    except Exception as e:
        info.error = str(e)
        return info
    try:
        r = subprocess.run(
            ["git", "log", "-1", "--pretty=%s", "HEAD"],
            cwd=path,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if r.returncode == 0 and r.stdout:
            info.last_commit_msg = r.stdout.strip()[:80]
    except Exception:
        pass
    try:
        r = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=path,
            capture_output=True,
            text=True,
            timeout=5,
        )
        info.is_clean = r.returncode == 0 and not r.stdout.strip()
    except Exception:
        pass
    try:
        r = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            cwd=path,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if r.returncode == 0 and r.stdout:
            info.remote_url = r.stdout.strip()
    except Exception:
        pass
    return info
