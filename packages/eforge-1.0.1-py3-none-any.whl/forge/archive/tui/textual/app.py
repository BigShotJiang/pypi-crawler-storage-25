"""ForgeApp — Textual root. All app-level bindings use priority=True."""

import subprocess
from typing import Callable

from textual.app import App
from textual.binding import Binding
from textual.reactive import reactive

from forge.core.discovery import discover_projects, get_projects_root
from forge.archive.tui.textual.state import ProjectState
from forge.archive.tui.textual.manifest_reader import read_manifest
from forge.archive.tui.textual.editor import _open_in_editor

from forge.archive.tui.textual.screens.dashboard import DashboardScreen
from forge.archive.tui.textual.screens.inspector import InspectorScreen
from forge.archive.tui.textual.screens.health_report import HealthReportScreen
from forge.archive.tui.textual.screens.config_editor import ConfigEditorScreen
from forge.archive.tui.textual.screens.git_panel import GitPanelScreen
from forge.archive.tui.textual.screens.logs_screen import LogsScreen
from forge.archive.tui.textual.screens.readiness import ReadinessScreen


class ForgeApp(App[None]):
    TITLE = "forge"

    BINDINGS = [
        Binding("i", "push_inspector", "Inspector", priority=True),
        Binding("a", "push_health", "Health", priority=True),
        Binding("g", "push_git", "Git", priority=True),
        Binding("c", "push_config", "Config", priority=True),
        Binding("l", "push_logs", "Logs", priority=True),
        Binding("r", "push_readiness", "Readiness", priority=True),
        Binding("n", "push_new", "New", priority=True),
        Binding("o", "open_editor", "Open", priority=True),
        Binding("R", "refresh", "Refresh", priority=True),
        Binding("q", "quit", "Quit", priority=True),
        Binding("escape", "back", "Back", priority=True),
    ]

    selected_index: reactive[int] = reactive(0)
    projects: list = []
    states: list[ProjectState] = []
    _push_after_mount: Callable[["ForgeApp"], None] | None = None

    def __init__(
        self,
        initial_states: list[ProjectState] | None = None,
        push_after_mount: Callable[["ForgeApp"], None] | None = None,
    ) -> None:
        super().__init__()
        self._initial_states = initial_states
        self._push_after_mount = push_after_mount

    def on_mount(self) -> None:
        if self._initial_states:
            self.states = self._initial_states
            self.projects = [s.project for s in self.states]
        else:
            self._load_all()
        if self._push_after_mount:
            self._push_after_mount(self)
        else:
            self.push_screen(DashboardScreen())

    def _load_all(self) -> None:
        self.projects = discover_projects(get_projects_root())
        self.states = [ProjectState.load(p) for p in self.projects]

    @property
    def selected_state(self) -> ProjectState | None:
        if not self.states:
            return None
        idx = max(0, min(self.selected_index, len(self.states) - 1))
        return self.states[idx]

    def set_selected(self, state: ProjectState) -> None:
        """Called by DashboardScreen when selection changes."""
        if state in self.states:
            self.selected_index = self.states.index(state)

    def action_push_inspector(self) -> None:
        if s := self.selected_state:
            manifest = read_manifest(s.project)
            self.push_screen(InspectorScreen(s, manifest))

    def action_push_health(self) -> None:
        if s := self.selected_state:
            self.push_screen(HealthReportScreen(s))

    def action_push_git(self) -> None:
        if s := self.selected_state:
            self.push_screen(GitPanelScreen(s))

    def action_push_config(self) -> None:
        if s := self.selected_state:
            self.push_screen(ConfigEditorScreen(s))

    def action_push_logs(self) -> None:
        if s := self.selected_state:
            self.push_screen(LogsScreen(s))

    def action_push_readiness(self) -> None:
        if s := self.selected_state:
            self.push_screen(ReadinessScreen(s))

    def action_push_new(self) -> None:
        self.exit()
        subprocess.run(["forge", "new"], check=False)

    def action_open_editor(self) -> None:
        if s := self.selected_state:
            _open_in_editor(s.project.path)

    def action_refresh(self) -> None:
        self._load_all()
        self.notify("Refreshed", severity="information")

    def action_back(self) -> None:
        if len(self.screen_stack) > 1:
            self.pop_screen()
