"""
Health = correctness NOW (is this project in a working state?)
Readiness = production ops preparedness (separate score).
No Textual imports.

Imports ProjectState from state_types (not state) — cycle broken.
state_types.py is the shared data module; neither state.py nor health_scorer.py
imports the other at module level.
"""

from forge.archive.tui.textual.state_types import ProjectState


class HealthScorer:
    WEIGHTS = {
        "manifest_valid": 20,
        "secrets_present": 15,
        "config_valid": 15,
        "git_clean": 10,
        "checks": 20,
        "phase_defined": 5,
        "repo_url": 5,
        "scripts_present": 5,
        "no_warnings": 5,
    }

    @staticmethod
    def score(state: ProjectState) -> int:
        """Returns 0-100."""
        score = 0
        # manifest_valid: project loaded without stub
        if getattr(state.project, "version", None) != "unknown":
            score += HealthScorer.WEIGHTS["manifest_valid"]
        if getattr(state, "secrets_present", False):
            score += HealthScorer.WEIGHTS["secrets_present"]
        if getattr(state, "config_valid", False):
            score += HealthScorer.WEIGHTS["config_valid"]
        if getattr(state, "git", None) and getattr(state.git, "is_clean", True):
            score += HealthScorer.WEIGHTS["git_clean"]
        # checks: divide 20 across check results
        results = getattr(state, "check_results", []) or []
        if results:
            ok_count = sum(1 for r in results if getattr(r, "status", None) == "ok")
            score += int(HealthScorer.WEIGHTS["checks"] * ok_count / len(results))
        if getattr(state.project, "phases", None) and state.project.phases.get("current") is not None:
            score += HealthScorer.WEIGHTS["phase_defined"]
        if getattr(state.project, "repo", None) and state.project.repo:
            score += HealthScorer.WEIGHTS["repo_url"]
        if getattr(state, "scripts_present", False):
            score += HealthScorer.WEIGHTS["scripts_present"]
        if not (getattr(state, "warnings", None) or []):
            score += HealthScorer.WEIGHTS["no_warnings"]
        return min(score, 100)

    @staticmethod
    def status(score: int) -> str:
        if score >= 90:
            return "healthy"
        if score >= 60:
            return "warn"
        if score > 0:
            return "critical"
        return "unknown"

    @staticmethod
    def dot(status: str) -> str:
        return {"healthy": "●", "warn": "⊙", "critical": "✗", "unknown": "○"}.get(
            status, "○"
        )

    @staticmethod
    def colour(status: str) -> str:
        return {
            "healthy": "green",
            "warn": "yellow",
            "critical": "red",
            "unknown": "grey",
        }.get(status, "grey")
