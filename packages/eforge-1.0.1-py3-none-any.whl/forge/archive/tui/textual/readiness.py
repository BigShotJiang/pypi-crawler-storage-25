"""ReadinessChecker + ReadinessReport. Separate from health. No UI imports."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from forge.core.project import BaseProject


@dataclass
class ReadinessItem:
    label: str
    done: bool
    fix_hint: str = ""
    section: str = ""


@dataclass
class ReadinessReport:
    items: list[ReadinessItem] = field(default_factory=list)
    score_pct: int = 0
    done_count: int = 0
    total_count: int = 0

    def by_section(self) -> dict[str, list[ReadinessItem]]:
        out: dict[str, list[ReadinessItem]] = {}
        for item in self.items:
            sec = item.section or "General"
            out.setdefault(sec, []).append(item)
        return out


def compute_readiness(project: "BaseProject") -> ReadinessReport:
    """Compute ReadinessReport for a project. Never raises."""
    items: list[ReadinessItem] = []
    path = getattr(project, "path", None)
    ptype = getattr(project, "type", "unknown")
    if not path:
        return ReadinessReport(items=items)

    # Manifest
    for cand in [path / "manifest.yaml", path / "docs" / "manifest.yaml"]:
        if cand.exists():
            items.append(ReadinessItem("manifest.yaml exists", True, section="Manifest"))
            break
    else:
        items.append(ReadinessItem("manifest.yaml exists", False, "Add manifest.yaml", "Manifest"))

    # Sections present (stub checks)
    items.append(ReadinessItem("phases section", bool(getattr(project, "phases", None)), section="Manifest"))
    items.append(ReadinessItem("dashboard checks defined", bool(getattr(project, "dashboard_checks", None)), section="Manifest"))

    # Type-specific
    if ptype == "flutter":
        if (path / "lib" / "core" / "forge_log.dart").exists():
            items.append(ReadinessItem("lib/core/forge_log.dart", True, section="Logging"))
        else:
            items.append(ReadinessItem("lib/core/forge_log.dart", False, "Add forge_log.dart", "Logging"))
        if (path / "docs" / "ERROR_CODES.md").exists():
            items.append(ReadinessItem("docs/ERROR_CODES.md", True, section="Logging"))
        else:
            items.append(ReadinessItem("docs/ERROR_CODES.md", False, "Add ERROR_CODES.md", "Logging"))
        if (path / "assets" / "app_config.yaml").exists() or (path / "app_config.yaml").exists():
            items.append(ReadinessItem("app_config.yaml", True, section="Config"))
        else:
            items.append(ReadinessItem("app_config.yaml", False, "Add app_config", "Config"))
    elif ptype == "web":
        if (path / "src" / "config" / "site.config.js").exists():
            items.append(ReadinessItem("site.config.js", True, section="Web"))
        else:
            items.append(ReadinessItem("site.config.js", False, "Add site.config.js", "Web"))
        if (path / "src").exists() and (path / "src" / "services").is_dir():
            items.append(ReadinessItem("src/services/", True, section="Web"))
        else:
            items.append(ReadinessItem("src/services/", False, "Add services", "Web"))
    elif ptype == "python":
        items.append(ReadinessItem("pyproject.toml", (path / "pyproject.toml").exists(), section="Python"))
        items.append(ReadinessItem("tests/ directory", (path / "tests").is_dir(), "Add tests/", "Python"))

    done = sum(1 for i in items if i.done)
    total = len(items) or 1
    score_pct = int(100 * done / total)
    return ReadinessReport(items=items, score_pct=score_pct, done_count=done, total_count=total)
