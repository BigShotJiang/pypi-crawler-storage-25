"""Textual TUI adapter — implements RendererProtocol."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from forge.archive.tui.textual.state_types import ProjectState, SupabaseInfo  # noqa: F401
    from forge.archive.tui.textual.manifest_reader import ManifestData


class TextualRenderer:
    """Interactive TUI renderer. Uses ForgeApp."""

    def show_project_list(self, states: list["ProjectState"]) -> None:
        # TUI shows list in DashboardScreen
        self.run(states)

    def show_project_detail(self, state: "ProjectState") -> None:
        self.run([state])

    def show_health_report(self, state: "ProjectState") -> None:
        from forge.archive.tui.textual.app import ForgeApp
        from forge.archive.tui.textual.screens.health_report import HealthReportScreen
        ForgeApp(
            initial_states=[state],
            push_after_mount=lambda app: app.push_screen(HealthReportScreen(state)),
        ).run()

    def show_inspector(
        self, state: "ProjectState", manifest: "ManifestData | None"
    ) -> None:
        from forge.archive.tui.textual.app import ForgeApp
        from forge.archive.tui.textual.screens.inspector import InspectorScreen
        from forge.archive.tui.textual.manifest_reader import read_manifest
        m = manifest or read_manifest(state.project)
        ForgeApp(
            initial_states=[state],
            push_after_mount=lambda app: app.push_screen(InspectorScreen(state, m)),
        ).run()

    def show_config_editor(self, state: "ProjectState") -> None:
        from forge.archive.tui.textual.app import ForgeApp
        from forge.archive.tui.textual.screens.config_editor import ConfigEditorScreen
        ForgeApp(
            initial_states=[state],
            push_after_mount=lambda app: app.push_screen(ConfigEditorScreen(state)),
        ).run()

    def show_logs(self, state: "ProjectState") -> None:
        from forge.archive.tui.textual.app import ForgeApp
        from forge.archive.tui.textual.screens.logs_screen import LogsScreen
        ForgeApp(
            initial_states=[state],
            push_after_mount=lambda app: app.push_screen(LogsScreen(state)),
        ).run()

    def run(self, states: list["ProjectState"]) -> None:
        from forge.archive.tui.textual.app import ForgeApp
        ForgeApp(initial_states=states).run()
