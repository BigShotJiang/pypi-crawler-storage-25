from textual.widgets import ListView, ListItem, Static
from textual.containers import Vertical
from forge.archive.tui.textual.state import ProjectState
from forge.archive.tui.textual.health_scorer import HealthScorer


class ProjectListItem(ListItem):
    """ListItem that stores ProjectState so dashboard can read it on highlight/select."""

    def __init__(self, state: ProjectState, **kwargs):
        self.state = state
        super().__init__(**kwargs)

    def compose(self):
        p = self.state.project
        status = HealthScorer.status(self.state.health_score)
        dot = HealthScorer.dot(status)
        color = HealthScorer.colour(status)
        yield Static(f"[{color}]{dot}[/] {p.name} ({p.type})")


class ProjectListWidget(Vertical):
    """Shows project names with health dot. Uses ListView so -highlighted row is visible."""

    DEFAULT_CSS = """
    ProjectListWidget > ListView > ListItem.-highlighted {
        background: $accent;
        color: $text;
    }
    """

    def __init__(self, states: list[ProjectState], selected_index: int = 0, **kwargs):
        super().__init__(**kwargs)
        self._states = states
        self._selected_index = max(0, min(selected_index, len(states) - 1)) if states else 0

    def compose(self):
        items = [ProjectListItem(state) for state in self._states]
        yield ListView(
            *items,
            id="project-list-view",
            initial_index=self._selected_index,
        )

    def set_selected_index(self, index: int) -> None:
        self._selected_index = max(0, min(index, len(self._states) - 1)) if self._states else 0
        results = self.query("#project-list-view")
        lv = results.first(ListView) if results else None
        if lv is not None:
            lv.index = self._selected_index

    def set_states(self, states: list[ProjectState], selected_index: int = 0) -> None:
        self._states = states
        self._selected_index = max(0, min(selected_index, len(states) - 1)) if states else 0
        self.remove_children()
        items = [ProjectListItem(state) for state in self._states]
        lv = ListView(
            *items,
            id="project-list-view",
            initial_index=self._selected_index,
        )
        self.mount(lv)
