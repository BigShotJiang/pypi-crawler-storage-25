from textual.widgets import Static


class PhaseTrackerWidget(Static):
    def __init__(self, phase_label: str, current_phase: int | None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._label = phase_label
        self._current = current_phase

    def render(self):
        if self._current is not None:
            return f"Phase {self._current} — {self._label}"
        return "Phase — Unknown"
