from textual.widgets import Static
from forge.core.checks import CheckResult


class CheckRowWidget(Static):
    def __init__(self, result: CheckResult, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._result = result

    def render(self):
        r = self._result
        status = r.status
        color = {"ok": "green", "warn": "yellow", "fail": "red", "unknown": "dim"}.get(status, "white")
        text = r.value or r.error or "—"
        return f"[{color}]{status}[/] {r.label}: {text}"
