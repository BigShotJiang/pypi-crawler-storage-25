from textual.widgets import Static
from textual.containers import Vertical
from forge.archive.tui.textual.manifest_reader import FileContract


class DetailPanelWidget(Vertical):
    def __init__(self, contract: FileContract | None = None, **kwargs):
        super().__init__(**kwargs)
        self._contract = contract

    def compose(self):
        if not self._contract:
            yield Static("Select a contract for details")
            return
        c = self._contract
        yield Static(f"Name: {c.name}")
        yield Static(f"Path: {c.path}")
        if c.reads:
            yield Static(f"Reads: {', '.join(c.reads)}")
        if c.writes:
            yield Static(f"Writes: {', '.join(c.writes)}")
        if c.error_codes:
            yield Static("Error codes: " + ", ".join(c.error_codes))

    def set_contract(self, contract: FileContract | None):
        self._contract = contract
        self.remove_children()
        for child in self.compose():
            self.mount(child)
