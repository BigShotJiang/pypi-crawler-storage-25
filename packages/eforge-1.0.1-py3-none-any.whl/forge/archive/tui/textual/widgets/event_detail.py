"""Event detail panel. set_event(log_event) + refresh() for denv pattern."""

from textual.widgets import Static
from textual.containers import Vertical


class EventDetailWidget(Vertical):
    def __init__(self, event: dict | None = None, **kwargs):
        super().__init__(**kwargs)
        self._event = event

    def compose(self):
        if not self._event:
            yield Static("Select an event")
            return
        e = self._event
        yield Static(f"Domain: {e.get('domain', '—')}")
        yield Static(f"Message: {e.get('message', '—')}")
        if e.get("contract"):
            yield Static(f"Contract: {e.get('contract')}")

    def set_event(self, event: dict | None) -> None:
        self._event = event
        self.remove_children()
        if not self._event:
            self.mount(Static("Select an event"))
            return
        e = self._event
        self.mount(Static(f"Domain: {e.get('domain', '—')}"))
        self.mount(Static(f"Message: {e.get('message', '—')}"))
        if e.get("contract"):
            self.mount(Static(f"Contract: {e.get('contract')}"))
