"""Config editor row: key + Input. Exposes focus_input() for denv navigation pattern."""

from textual.widgets import ListItem, Static, Input
from textual.containers import Horizontal


class ConfigRowWidget(ListItem):
    """One editable row: label (key) + Input (value). focus_input() focuses the Input."""

    def __init__(self, key: str, value: str, row_id: str = "", **kwargs):
        self._key = key
        self._value = value
        self._row_id = row_id or key
        super().__init__(**kwargs)

    def compose(self):
        with Horizontal():
            yield Static(f"{self._key}:", classes="config-key")
            yield Input(value=self._value, id=f"config-input-{self._row_id}")

    def focus_input(self) -> None:
        results = self.query("Input")
        inp = results.first() if results else None
        if inp:
            self.app.set_focus(inp)
