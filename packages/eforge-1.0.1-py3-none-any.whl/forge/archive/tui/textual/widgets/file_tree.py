from textual.widgets import Tree
from forge.archive.tui.textual.manifest_reader import FileContract, ManifestData


def _find_node_by_data(node, target: FileContract):
    if getattr(node, "data", None) is target:
        return node
    for child in getattr(node, "children", []):
        found = _find_node_by_data(child, target)
        if found is not None:
            return found
    return None


class FileTreeWidget(Tree):
    def __init__(self, manifest: ManifestData | None, hide_debug_only: bool = False, **kwargs):
        super().__init__(label="Files", **kwargs)
        self._manifest = manifest
        self._hide_debug = hide_debug_only

    def get_node_by_contract(self, fc: FileContract):
        """Return the TreeNode whose .data is this contract, or None."""
        return _find_node_by_data(self.root, fc)

    def on_mount(self):
        self.root.expand()
        if not self._manifest:
            self.root.add_leaf("No manifest")
            return
        for cat, items in self._manifest.by_category.items():
            if self._hide_debug:
                items = [i for i in items if not getattr(i, "debug_only", False)]
            if not items:
                continue
            node = self.root.add(cat.upper(), expand=True)
            for fc in items:
                badge = ""
                if getattr(fc, "debug_only", False):
                    badge += " [DEBUG]"
                if getattr(fc, "phase", None) is not None:
                    badge += f" [P{fc.phase}]"
                node.add_leaf(f"{fc.name}{badge}", data=fc)
