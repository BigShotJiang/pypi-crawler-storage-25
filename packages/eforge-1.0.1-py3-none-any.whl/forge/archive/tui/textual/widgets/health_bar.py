from textual.widgets import Static


class HealthBarWidget(Static):
    def __init__(self, score_pct: int, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._score = max(0, min(100, score_pct))

    def render(self):
        filled = int(10 * self._score / 100)
        bar = "█" * filled + "░" * (10 - filled)
        if self._score >= 80:
            color = "green"
        elif self._score >= 50:
            color = "yellow"
        else:
            color = "red"
        return f"[{color}]{bar}[/] {self._score}%"
