from textual.widgets import Static, Label
from textual.containers import Vertical
from forge.archive.tui.textual.state import ProjectState
from forge.archive.tui.textual.health_scorer import HealthScorer


def _bar(score: int, length: int = 10) -> tuple[str, str]:
    """Returns (bar_string, color). score 0-100."""
    score = max(0, min(100, score))
    filled = int(length * score / 100)
    bar = "█" * filled + "░" * (length - filled)
    if score >= 85:
        color = "green"
    elif score >= 60:
        color = "yellow"
    else:
        color = "red"
    return bar, color


class ProjectDetailWidget(Vertical):
    """Detail panel: one Label per row, health/readiness bars, phase tracker section."""

    def __init__(self, state: ProjectState | None = None, **kwargs):
        super().__init__(**kwargs)
        self._state = state

    def compose(self):
        if not self._state:
            yield Label("Select a project")
            return
        yield from self._build_labels()

    def _build_labels(self):
        """Build one Label per field row from self._state."""
        if not self._state:
            return
        s = self._state
        p = s.project

        yield Label(f"[cyan bold]{p.name}[/]")

        branch_dot = "[green]●[/]" if s.git.is_clean else "[yellow]⊙[/]"
        yield Label(f"Branch     {branch_dot} {s.git.branch}")

        msg = (s.git.last_commit_msg or "—")[:40]
        age = s.git.last_commit_age or ""
        yield Label(f"Commit     {msg}  {age}")

        sup_dot = "[green]●[/] linked" if s.supabase.linked else "[dim]○[/] not linked"
        yield Label(f"Supabase   {sup_dot}")

        sec = "[green]✓ present[/]" if s.secrets_present else "[dim]○ missing[/]"
        yield Label(f"Secrets    {sec}")

        cfg = "[green]✓ valid[/]" if s.config_valid else "[dim]○ invalid[/]"
        yield Label(f"Config     {cfg}")

        current = getattr(p, "current_phase", lambda: None)
        current = current() if callable(current) else None
        phase_label = getattr(p, "phase_label", lambda: "Unknown")
        phase_label = phase_label() if callable(phase_label) else "Unknown"
        phase_str = f"{current}  {phase_label}" if current is not None else "—"
        yield Label(f"Phase      {phase_str}")

        upcoming = getattr(p, "phases", {}) or {}
        next_list = upcoming.get("upcoming") or []
        next_idx = (current + 1) if current is not None else 0
        if isinstance(next_list, list) and next_list and 0 <= next_idx < len(next_list):
            item = next_list[next_idx]
            next_name = item.get("name", "—") if isinstance(item, dict) else str(item)
            yield Label(f"Next →     {next_name}")
        else:
            yield Label("Next →     —")

        bar_str, bar_color = _bar(s.health_score)
        yield Label(f"Health     [{bar_color}]{bar_str}[/]  {s.health_score}/100")

        r_bar, r_color = _bar(s.readiness.score_pct)
        yield Label(f"Readiness  [{r_color}]{r_bar}[/]  {s.readiness.score_pct}%")

        yield Label("── PHASE TRACKER ──────────────────")
        ph_bar, ph_color = _bar(s.health_score)
        status = s.health_status or "unknown"
        ph_num = current if current is not None else "—"
        yield Label(f"{p.name}    Ph{ph_num}  [{ph_color}]{ph_bar}[/]  {status}")

    def set_state(self, state: ProjectState | None) -> None:
        """Update the displayed state and trigger re-render."""
        self._state = state
        self.remove_children()
        for w in self._build_labels():
            self.mount(w)
