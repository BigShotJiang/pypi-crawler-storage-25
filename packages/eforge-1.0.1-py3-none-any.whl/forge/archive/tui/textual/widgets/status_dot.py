from textual.widgets import Static
from forge.archive.tui.textual.health_scorer import HealthScorer


class StatusDotWidget(Static):
    def __init__(self, status: str, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._status = status

    def render(self):
        dot = HealthScorer.dot(self._status)
        color = HealthScorer.colour(self._status)
        return f"[{color}]{dot}[/]"
