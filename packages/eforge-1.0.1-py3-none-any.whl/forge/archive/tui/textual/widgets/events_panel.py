"""Events list panel. set_filter(domain) + refresh() for denv pattern."""

from textual.widgets import ListView, ListItem, Static
from textual.containers import Vertical


class EventListItem(ListItem):
    def __init__(self, event: dict, **kwargs):
        self.event_data = event
        super().__init__(**kwargs)

    def compose(self):
        msg = self.event_data.get("message", "")[:60]
        yield Static(msg)


class EventsPanelWidget(Vertical):
    def __init__(self, events_by_domain: dict[str, list[dict]] | None = None, **kwargs):
        super().__init__(**kwargs)
        self._events_by_domain = events_by_domain or {}
        self._filter: str | None = None

    def set_filter(self, domain: str | None) -> None:
        self._filter = domain
        self.remove_children()
        events = self._events_by_domain.get(domain, []) if domain else []
        items = [EventListItem(e) for e in events]
        if items:
            self.mount(ListView(*items, id="events-list"))
        else:
            self.mount(Static("(no events)" if domain else "Select a domain"))
