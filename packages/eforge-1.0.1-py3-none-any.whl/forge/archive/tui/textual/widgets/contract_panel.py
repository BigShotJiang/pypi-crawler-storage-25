from textual.widgets import Static, ListView, ListItem
from textual.containers import VerticalScroll
from forge.archive.tui.textual.manifest_reader import FileContract


class ContractFieldListItem(ListItem):
    """ListItem that stores field_key and contract for navigation/action."""

    def __init__(self, field_key: str, display: str, contract: FileContract | None = None, **kwargs):
        self.field_key = field_key
        self.contract = contract
        super().__init__(**kwargs)
        self._display = display

    def compose(self):
        yield Static(self._display)


class ContractPanelWidget(VerticalScroll):
    def __init__(self, contract: FileContract | None = None, **kwargs):
        super().__init__(**kwargs)
        self._contract = contract

    def _build_field_items(self) -> list[ContractFieldListItem]:
        items: list[ContractFieldListItem] = []
        if not self._contract:
            return items
        c = self._contract
        items.append(ContractFieldListItem("name", f"[bold]{c.name}[/]", c))
        items.append(ContractFieldListItem("path", f"Path: {c.path}", c))
        if c.role:
            items.append(ContractFieldListItem("role", f"Role: {c.role}", c))
        if c.phase is not None:
            items.append(ContractFieldListItem("phase", f"Phase: {c.phase}", c))
        if c.debug_only:
            items.append(ContractFieldListItem("debug", "[dim red]DEBUG ONLY[/]", c))
        if c.error_codes:
            items.append(ContractFieldListItem("error_codes", "[bold]ERROR CODES[/]", c))
            for code in c.error_codes:
                items.append(ContractFieldListItem("error_code", f"  → {code}", c))
        if c.reads:
            items.append(ContractFieldListItem("reads", f"Reads: {', '.join(c.reads)}", c))
        if c.writes:
            items.append(ContractFieldListItem("writes", f"Writes: {', '.join(c.writes)}", c))
        if c.navigates_to:
            items.append(ContractFieldListItem("navigates_to", f"Navigates: {', '.join(c.navigates_to)}", c))
        return items

    def compose(self):
        # Always create a single ListView; contents are managed by set_contract().
        yield ListView(id="contract-list")

    def set_contract(self, contract: FileContract | None) -> None:
        """Update the displayed contract fields without recreating the ListView."""
        from textual.widgets import ListView as _LV  # local import to avoid cycles

        self._contract = contract
        # Find the existing list view once; if it's missing, nothing to do.
        results = self.query("#contract-list")
        lv = results.first(_LV) if results else None
        if lv is None:
            return

        # Clear current items and repopulate based on the new contract.
        lv.clear()
        items = self._build_field_items()
        if not items:
            placeholder = Static("Select a file" if contract is None else "—")
            lv.append(placeholder)
            return
        for item in items:
            lv.append(item)
