from forge.renderers.base import RendererRegistry
from forge.archive.tui.textual.renderer import TextualRenderer

RendererRegistry.register("textual", TextualRenderer)
