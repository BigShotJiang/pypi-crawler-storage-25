from textual.screen import Screen
from textual.containers import Horizontal, Vertical
from textual.binding import Binding
from textual.widgets import Header, Static, ListView

from forge.archive.tui.textual.widgets.project_list import ProjectListWidget
from forge.archive.tui.textual.widgets.project_detail import ProjectDetailWidget


class DashboardScreen(Screen[None]):
    BINDINGS = [
        Binding("up", "previous_project", "Up", show=False),
        Binding("down", "next_project", "Down", show=False),
    ]

    def compose(self):
        app = self.app
        yield Header()
        with Horizontal():
            with Vertical(id="left-panel"):
                yield Static("Projects", classes="panel-title")
                yield ProjectListWidget(
                    getattr(app, "states", []),
                    getattr(app, "selected_index", 0),
                    id="project-list",
                )
            with Vertical(id="right-panel"):
                yield Static("Detail", classes="panel-title")
                yield ProjectDetailWidget(getattr(app, "selected_state", None), id="project-detail")

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        """Arrow key navigation — updates detail panel immediately."""
        if event.item is None:
            return
        state = getattr(event.item, "state", None) or getattr(event.item, "project", None)
        if state is None:
            return
        if state in self.app.states:
            self.app.selected_index = self.app.states.index(state)
        self._refresh_detail()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Enter key — updates detail AND pushes InspectorScreen."""
        if event.item is None:
            return
        state = getattr(event.item, "state", None) or getattr(event.item, "project", None)
        if state is None:
            return
        if state in self.app.states:
            self.app.selected_index = self.app.states.index(state)
        self._refresh_detail()
        from forge.archive.tui.textual.screens.inspector import InspectorScreen
        from forge.archive.tui.textual.manifest_reader import read_manifest
        manifest = read_manifest(self.app.projects[self.app.selected_index])
        self.app.push_screen(InspectorScreen(self.app.selected_state, manifest))

    def _refresh_detail(self) -> None:
        """Directly update the detail widget with the current selection."""
        state = self.app.selected_state
        if state is None:
            return
        results = self.query("#project-detail")
        detail = results.first() if results else None
        if detail and hasattr(detail, "set_state"):
            detail.set_state(state)
            detail.refresh()
        results = self.query("#phase-tracker")
        tracker = results.first() if results else None
        if tracker:
            tracker.refresh()

    def action_previous_project(self) -> None:
        app = self.app
        if getattr(app, "states", None):
            app.selected_index = max(0, app.selected_index - 1)

    def action_next_project(self) -> None:
        app = self.app
        if getattr(app, "states", None):
            app.selected_index = min(
                len(app.states) - 1,
                app.selected_index + 1,
            )
