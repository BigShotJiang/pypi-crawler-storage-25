from textual.screen import Screen
from textual.containers import VerticalScroll
from textual.widgets import Header, Static

from forge.archive.tui.textual.state import ProjectState
from forge.archive.tui.textual.health_scorer import HealthScorer
from forge.archive.tui.textual.widgets.health_bar import HealthBarWidget
from forge.archive.tui.textual.widgets.check_row import CheckRowWidget


class HealthReportScreen(Screen[None]):
    def __init__(self, state: ProjectState, **kwargs):
        super().__init__(**kwargs)
        self._state = state

    def compose(self):
        yield Header()
        s = self._state
        p = s.project
        yield Static(f"[bold cyan]Health — {p.name}[/]")
        status = HealthScorer.status(s.health_score)
        dot = HealthScorer.dot(status)
        color = HealthScorer.colour(status)
        yield Static(f"Score: [{color}]{dot}[/] {s.health_score} — {status}")
        yield HealthBarWidget(s.health_score)
        with VerticalScroll():
            yield Static("[bold]Checks[/]")
            for r in s.check_results:
                yield CheckRowWidget(r)
            if s.warnings:
                yield Static("[bold]Warnings[/]")
                for w in s.warnings:
                    yield Static(f"[yellow]{w}[/]")
