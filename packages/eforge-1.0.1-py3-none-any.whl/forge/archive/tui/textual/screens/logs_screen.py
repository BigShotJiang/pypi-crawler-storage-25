from textual.screen import Screen
from textual.containers import Horizontal, Vertical
from textual.widgets import Header, Static, ListView, ListItem

from forge.archive.tui.textual.state import ProjectState
from forge.archive.tui.textual.widgets.events_panel import EventsPanelWidget, EventListItem
from forge.archive.tui.textual.widgets.event_detail import EventDetailWidget


class DomainListItem(ListItem):
    def __init__(self, domain_name: str, **kwargs):
        self.domain_name = domain_name
        super().__init__(**kwargs)

    def compose(self):
        yield Static(self.domain_name)


class LogsScreen(Screen[None]):
    def __init__(
        self,
        state: ProjectState,
        filter_code: str | None = None,
        filter_domain: str | None = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self._state = state
        self._filter_code = filter_code
        self._filter_domain = filter_domain
        self._selected_domain: str | None = None
        self._selected_event: dict | None = None
        self._events_by_domain = self._stub_events_by_domain()

    def _stub_events_by_domain(self) -> dict[str, list[dict]]:
        return {
            "app": [{"domain": "app", "message": "started", "contract": None}],
            "api": [{"domain": "api", "message": "request", "contract": "lib/api.dart"}],
        }

    def compose(self):
        yield Header()
        yield Static(f"[bold cyan]Logs — {self._state.project.name}[/]")
        domains = list(self._events_by_domain.keys())
        domain_items = [DomainListItem(d) for d in domains]
        with Horizontal():
            with Vertical(id="logs-domains"):
                yield Static("DOMAINS", classes="panel-title")
                yield ListView(*domain_items, id="domains-list")
            with Vertical(id="logs-events"):
                yield Static("EVENTS", classes="panel-title")
                yield EventsPanelWidget(self._events_by_domain, id="events-panel")
            with Vertical(id="logs-detail"):
                yield Static("DETAIL", classes="panel-title")
                yield EventDetailWidget(None, id="event-detail")

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        if event.item is None:
            return
        if event.control.id == "domains-list" and isinstance(event.item, DomainListItem):
            self._selected_domain = event.item.domain_name
            self._refresh_events_panel()
        elif event.control.id == "events-list" and isinstance(event.item, EventListItem):
            self._selected_event = event.item.event_data
            self._refresh_event_detail()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        if event.item is None:
            return
        if event.control.id == "events-list" and isinstance(event.item, EventListItem):
            self._selected_event = event.item.event_data
            self._refresh_event_detail()
            if event.item.event_data.get("contract"):
                from forge.archive.tui.textual.screens.inspector import InspectorScreen
                from forge.archive.tui.textual.manifest_reader import read_manifest
                manifest = read_manifest(self._state.project)
                self.app.push_screen(InspectorScreen(self._state, manifest))

    def _refresh_events_panel(self) -> None:
        results = self.query("#events-panel")
        panel = results.first() if results else None
        if panel and hasattr(panel, "set_filter"):
            panel.set_filter(self._selected_domain)
            panel.refresh()

    def _refresh_event_detail(self) -> None:
        results = self.query("#event-detail")
        detail = results.first() if results else None
        if detail and hasattr(detail, "set_event"):
            detail.set_event(self._selected_event)
            detail.refresh()
