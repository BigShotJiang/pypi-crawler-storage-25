import subprocess
from textual.screen import Screen
from textual.containers import Vertical
from textual.binding import Binding
from textual.widgets import Header, Static, ListView, ListItem

from forge.archive.tui.textual.state_types import ProjectState


class BranchListItem(ListItem):
    def __init__(self, branch_name: str, is_current: bool = False, **kwargs):
        self.branch_name = branch_name
        self.is_current = is_current
        super().__init__(**kwargs)

    def compose(self):
        prefix = "[green]* [/]" if self.is_current else "  "
        yield Static(f"{prefix}{self.branch_name}")


class IssueListItem(ListItem):
    def __init__(self, issue_title: str, issue_number: int | None = None, **kwargs):
        self.issue_title = issue_title
        self.issue_number = issue_number
        super().__init__(**kwargs)

    def compose(self):
        num = f"#{self.issue_number} " if self.issue_number is not None else ""
        yield Static(f"{num}{self.issue_title}")


class GitPanelScreen(Screen[None]):
    BINDINGS = [
        Binding("tab", "focus_next_section", "Next section", show=False),
        Binding("shift+tab", "focus_prev_section", "Prev section", show=False),
    ]

    def __init__(self, state: ProjectState, **kwargs):
        super().__init__(**kwargs)
        self._state = state
        self._branches: list[str] = []
        self._issues: list[tuple[str, int | None]] = []
        self._focus_panel = 0

    def on_mount(self) -> None:
        self._load_branches()
        self._load_issues()

    def _load_branches(self) -> None:
        path = getattr(self._state.project.path, "path", self._state.project.path)
        try:
            r = subprocess.run(
                ["git", "branch", "-a"],
                cwd=path,
                capture_output=True,
                text=True,
                timeout=5,
            )
            if r.returncode == 0 and r.stdout:
                lines = [
                    x.strip().lstrip("* ").strip()
                    for x in r.stdout.strip().splitlines()
                ]
                self._branches = [x for x in lines if x and not x.startswith("remotes/")]
                if not self._branches:
                    self._branches = [self._state.git.branch or "main"]
        except Exception:
            self._branches = [self._state.git.branch or "main"]

    def _load_issues(self) -> None:
        path = getattr(self._state.project.path, "path", self._state.project.path)
        try:
            r = subprocess.run(
                ["gh", "issue", "list", "--limit", "20", "--json", "title,number"],
                cwd=path,
                capture_output=True,
                text=True,
                timeout=5,
            )
            if r.returncode == 0 and r.stdout:
                import json
                data = json.loads(r.stdout)
                self._issues = [(x.get("title", ""), x.get("number")) for x in data]
            else:
                self._issues = []
        except Exception:
            self._issues = []

    def compose(self):
        yield Header()
        s = self._state
        yield Static(f"[bold cyan]Git — {s.project.name}[/]")
        current = s.git.branch or ""
        branch_items = [
            BranchListItem(b, is_current=(b == current))
            for b in (self._branches or [current or "main"])
        ]
        issue_items = [
            IssueListItem(title, num) for title, num in self._issues
        ] or [IssueListItem("No issues (gh CLI not available or no issues)", None)]
        with Vertical(id="git-branches-section"):
            yield Static("BRANCHES", classes="panel-title")
            yield ListView(*branch_items, id="branches-list")
        with Vertical(id="git-issues-section"):
            yield Static("ISSUES", classes="panel-title")
            yield ListView(*issue_items, id="issues-list")

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        pass

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        if event.item is None:
            return
        if event.control.id == "branches-list" and isinstance(event.item, BranchListItem):
            self.notify(f"Checkout {event.item.branch_name} (stub)", severity="information")
        elif event.control.id == "issues-list" and isinstance(event.item, IssueListItem):
            self.notify(f"Issue: {event.item.issue_title} (stub)", severity="information")

    def action_focus_next_section(self) -> None:
        self._focus_panel = (self._focus_panel + 1) % 2
        self._focus_section()

    def action_focus_prev_section(self) -> None:
        self._focus_panel = (self._focus_panel - 1) % 2
        self._focus_section()

    def _focus_section(self) -> None:
        if self._focus_panel == 0:
            results = self.query("#branches-list")
        else:
            results = self.query("#issues-list")
        w = results.first() if results else None
        if w:
            self.set_focus(w)
