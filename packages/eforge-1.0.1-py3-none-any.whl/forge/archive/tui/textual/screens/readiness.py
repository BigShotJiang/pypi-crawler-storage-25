from textual.screen import Screen
from textual.containers import VerticalScroll
from textual.widgets import Header, Static

from forge.archive.tui.textual.state_types import ProjectState
from forge.archive.tui.textual.widgets.health_bar import HealthBarWidget


class ReadinessScreen(Screen[None]):
    def __init__(self, state: ProjectState, **kwargs):
        super().__init__(**kwargs)
        self._state = state

    def compose(self):
        yield Header()
        s = self._state
        p = s.project
        yield Static(f"[bold cyan]Readiness — {p.name}[/]")
        yield HealthBarWidget(s.readiness.score_pct)
        yield Static(f"{s.readiness.done_count}/{s.readiness.total_count}")
        with VerticalScroll():
            for section, items in s.readiness.by_section().items():
                yield Static(f"[bold]{section}[/]")
                for item in items:
                    mark = "●" if item.done else "○"
                    yield Static(f"  {mark} {item.label}  {item.fix_hint or ''}")
