from textual.screen import Screen
from textual.containers import Vertical
from textual.binding import Binding
from textual.widgets import Header, Static, ListView

from forge.archive.tui.textual.state_types import ProjectState
from forge.archive.tui.textual.widgets.config_row import ConfigRowWidget


class ConfigEditorScreen(Screen[None]):
    BINDINGS = [
        Binding("s", "save", "Save", show=True),
        Binding("r", "reload", "Reload", show=True),
        Binding("tab", "focus_next_input", "Next field", show=False),
        Binding("shift+tab", "focus_prev_input", "Prev field", show=False),
    ]

    def __init__(self, state: ProjectState, initial_tab: str = "features", **kwargs):
        super().__init__(**kwargs)
        self._state = state
        self._initial_tab = initial_tab
        self._fields = self._load_fields()

    def _load_fields(self) -> list[tuple[str, str]]:
        s = self._state
        return [
            ("config_path", s.config_path or ""),
            ("branch", s.git.branch or ""),
            ("remote", s.git.remote_url or ""),
        ]

    def compose(self):
        yield Header()
        yield Static("[bold cyan]Config Editor[/]")
        yield Static(f"Project: {self._state.project.name}")
        items = [
            ConfigRowWidget(k, v, row_id=str(i))
            for i, (k, v) in enumerate(self._fields)
        ]
        yield ListView(*items, id="config-list")

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        if event.control.id != "config-list":
            return
        # Highlight is handled by ListView; no detail panel to refresh

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        if event.control.id != "config-list" or event.item is None:
            return
        if hasattr(event.item, "focus_input"):
            event.item.focus_input()

    def action_save(self) -> None:
        self.notify("Save (stub) — values not persisted", severity="information")

    def action_reload(self) -> None:
        self._state = ProjectState.load(self._state.project)
        self._fields = self._load_fields()
        self.notify("Reloaded from disk", severity="information")

    def action_focus_next_input(self) -> None:
        inputs = self.query("Input")
        if not inputs:
            return
        current = self.focused
        if current and current in inputs:
            idx = list(inputs).index(current)
            next_idx = (idx + 1) % len(inputs)
            self.set_focus(inputs[next_idx])
        else:
            self.set_focus(inputs[0])

    def action_focus_prev_input(self) -> None:
        inputs = self.query("Input")
        if not inputs:
            return
        current = self.focused
        if current and current in inputs:
            idx = list(inputs).index(current)
            next_idx = (idx - 1) % len(inputs)
            self.set_focus(inputs[next_idx])
        else:
            self.set_focus(inputs[-1])
