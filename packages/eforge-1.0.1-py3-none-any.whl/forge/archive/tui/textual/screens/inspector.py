from textual.screen import Screen
from textual.containers import Horizontal, Vertical
from textual.binding import Binding
from textual.widgets import Header, Static, Tree, ListView

from forge.archive.tui.textual.state_types import ProjectState
from forge.archive.tui.textual.manifest_reader import ManifestData, FileContract
from forge.archive.tui.textual.widgets.file_tree import FileTreeWidget
from forge.archive.tui.textual.widgets.contract_panel import ContractPanelWidget, ContractFieldListItem
from forge.archive.tui.textual.widgets.detail_panel import DetailPanelWidget


def _contract_from_node(node) -> FileContract | None:
    data = getattr(node, "data", None)
    if data is not None and isinstance(data, FileContract):
        return data
    return None


class InspectorScreen(Screen[None]):
    BINDINGS = [
        Binding("tab", "focus_next_panel", "Next panel", show=False),
        Binding("shift+tab", "focus_prev_panel", "Prev panel", show=False),
    ]

    def __init__(
        self,
        state: ProjectState,
        manifest: ManifestData | None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self._state = state
        self._manifest = manifest
        self._hide_debug = False
        self._selected_file: FileContract | None = None
        self._selected_field: str | None = None
        self._focus_panel = 0  # 0=file-tree, 1=contract-panel

    def compose(self):
        yield Header()
        with Horizontal():
            with Vertical(id="inspector-tree"):
                yield Static("FILES", classes="panel-title")
                yield FileTreeWidget(self._manifest, self._hide_debug, id="file-tree")
            with Vertical(id="inspector-contract"):
                yield Static("CONTRACT", classes="panel-title")
                yield ContractPanelWidget(self._selected_file, id="contract-panel")
            with Vertical(id="inspector-detail"):
                yield Static("DETAIL", classes="panel-title")
                yield DetailPanelWidget(self._selected_file, id="detail-panel")

    def on_tree_node_highlighted(self, event: Tree.NodeHighlighted) -> None:
        contract = _contract_from_node(event.node)
        if contract is not None:
            self._selected_file = contract
            self._refresh_contract_panel()
            self._refresh_detail_panel()

    def on_tree_node_selected(self, event: Tree.NodeSelected) -> None:
        contract = _contract_from_node(event.node)
        if contract is not None:
            self._selected_file = contract
            self._refresh_contract_panel()
            self._refresh_detail_panel()
            self.notify(f"Selected: {contract.name}", severity="information")

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        if event.control.id != "contract-list" or event.item is None:
            return
        item = event.item
        if isinstance(item, ContractFieldListItem):
            self._selected_field = item.field_key
            self._refresh_detail_panel()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        if event.control.id != "contract-list" or event.item is None:
            return
        item = event.item
        if not isinstance(item, ContractFieldListItem) or item.contract is None:
            return
        c = item.contract
        key = item.field_key
        if key in ("reads", "writes", "navigates_to") and self._manifest:
            paths = (c.reads if key == "reads" else c.writes if key == "writes" else c.navigates_to) or []
            for path in paths:
                fc = self._manifest.find(path)
                if fc is not None:
                    results = self.query("#file-tree")
                    tree = results.first(FileTreeWidget) if results else None
                    if tree and hasattr(tree, "get_node_by_contract"):
                        node = tree.get_node_by_contract(fc)
                        if node is not None:
                            tree.select_node(node)
                            self._selected_file = fc
                            self._refresh_contract_panel()
                            self._refresh_detail_panel()
                    break

    def _refresh_contract_panel(self) -> None:
        results = self.query("#contract-panel")
        panel = results.first() if results else None
        if panel and hasattr(panel, "set_contract"):
            panel.set_contract(self._selected_file)
            panel.refresh()

    def _refresh_detail_panel(self) -> None:
        results = self.query("#detail-panel")
        panel = results.first() if results else None
        if panel and hasattr(panel, "set_contract"):
            panel.set_contract(self._selected_file)
            panel.refresh()

    def action_focus_next_panel(self) -> None:
        self._focus_panel = (self._focus_panel + 1) % 2
        if self._focus_panel == 0:
            results = self.query("#file-tree")
            w = results.first() if results else None
            if w:
                self.set_focus(w)
        else:
            results = self.query("#contract-panel")
            w = results.first() if results else None
            if w:
                self.set_focus(w)

    def action_focus_prev_panel(self) -> None:
        self._focus_panel = (self._focus_panel - 1) % 2
        if self._focus_panel == 0:
            results = self.query("#file-tree")
            w = results.first() if results else None
            if w:
                self.set_focus(w)
        else:
            results = self.query("#contract-panel")
            w = results.first() if results else None
            if w:
                self.set_focus(w)
