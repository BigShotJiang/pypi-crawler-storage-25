"""Open project in editor. Uses forge.core.editor when available."""

from pathlib import Path


def _open_in_editor(path: Path) -> None:
    try:
        from forge.core.editor import _open_in_editor as _core_open
        _core_open(path)
    except ImportError:
        import os
        import subprocess
        import shutil
        editors = [
            os.environ.get("FORGE_EDITOR"),
            os.environ.get("DENV_EDITOR"),
            "cursor", "code", "zed", "vim",
        ]
        for editor in editors:
            if editor and shutil.which(editor):
                subprocess.Popen([editor, str(path)])
                return
