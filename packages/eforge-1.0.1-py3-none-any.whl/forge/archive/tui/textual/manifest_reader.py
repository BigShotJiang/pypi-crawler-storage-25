"""FileContract + ManifestData for Inspector. Reads project manifest.yaml. No Textual imports."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from forge.core.project import BaseProject


@dataclass
class ContractExposes:
    name: str
    type: str
    description: str = ""


@dataclass
class ContractRequires:
    from_domain: str
    name: str
    type: str
    phase: int | None = None
    is_inter: bool = False


@dataclass
class ContractBlock:
    exposes: list[ContractExposes] = field(default_factory=list)
    requires: list[ContractRequires] = field(default_factory=list)


@dataclass
class FileContract:
    path: str
    name: str
    role: str = ""
    reads: list[str] = field(default_factory=list)
    writes: list[str] = field(default_factory=list)
    navigates_to: list[str] = field(default_factory=list)
    providers: list[str] = field(default_factory=list)
    depends_on: list[str] = field(default_factory=list)
    variants: list[str] = field(default_factory=list)
    variant_key: str = ""
    domain: str = ""
    phase: int | None = None
    debug_only: bool = False
    error_codes: list[str] = field(default_factory=list)
    is_screen: bool = False
    is_controller: bool = False
    is_hook: bool = False
    is_module: bool = False
    is_variant: bool = False
    is_service: bool = False
    contract: ContractBlock | None = None
    extra: dict = field(default_factory=dict)


@dataclass
class InterDependency:
    id: str
    version: str | None
    domain: str
    consumes: list[ContractExposes] = field(default_factory=list)


@dataclass
class InterExposes:
    domain: str
    for_projects: list[str] = field(default_factory=list)
    fields: list[ContractExposes] = field(default_factory=list)


@dataclass
class ManifestData:
    screens: list[FileContract] = field(default_factory=list)
    controllers: list[FileContract] = field(default_factory=list)
    hooks: list[FileContract] = field(default_factory=list)
    modules: list[FileContract] = field(default_factory=list)
    commands: list[FileContract] = field(default_factory=list)
    services: list[FileContract] = field(default_factory=list)
    variants: list[FileContract] = field(default_factory=list)
    other: list[FileContract] = field(default_factory=list)
    active_variants: dict[str, str] = field(default_factory=dict)
    dependencies: list[InterDependency] = field(default_factory=list)
    inter_exposes: list[InterExposes] = field(default_factory=list)

    @property
    def by_category(self) -> dict[str, list[FileContract]]:
        out: dict[str, list[FileContract]] = {}
        for key, lst in [
            ("screens", self.screens),
            ("controllers", self.controllers),
            ("hooks", self.hooks),
            ("modules", self.modules),
            ("commands", self.commands),
            ("services", self.services),
            ("variants", self.variants),
            ("other", self.other),
        ]:
            if lst:
                out[key] = lst
        return out

    def find(self, name: str) -> FileContract | None:
        for fc in self.all_files:
            if name in (fc.name, fc.path) or name in fc.path:
                return fc
        return None

    @property
    def all_files(self) -> list[FileContract]:
        return (
            self.screens
            + self.controllers
            + self.hooks
            + self.modules
            + self.commands
            + self.services
            + self.variants
            + self.other
        )


def _parse_contract_list(data: list, role: str, **flags) -> list[FileContract]:
    out: list[FileContract] = []
    for item in data or []:
        if isinstance(item, str):
            out.append(FileContract(path=item, name=item.split("/")[-1].replace(".dart", ""), role=role, **flags))
            continue
        if isinstance(item, dict):
            path = item.get("path") or item.get("file") or ""
            name = item.get("name") or path.split("/")[-1].replace(".dart", "").replace(".py", "")
            contract_block: ContractBlock | None = None
            raw_contract = item.get("contract")
            if isinstance(raw_contract, dict):
                exposes_list: list[ContractExposes] = []
                for ex in raw_contract.get("exposes") or []:
                    if not isinstance(ex, dict):
                        continue
                    exposes_list.append(
                        ContractExposes(
                            name=str(ex.get("name", "")),
                            type=str(ex.get("type", "")),
                            description=str(ex.get("description", "")),
                        )
                    )
                requires_list: list[ContractRequires] = []
                for rq in raw_contract.get("requires") or []:
                    if not isinstance(rq, dict):
                        continue
                    from_raw = str(rq.get("from", "") or "")
                    is_inter = "/" in from_raw
                    requires_list.append(
                        ContractRequires(
                            from_domain=from_raw,
                            name=str(rq.get("name", "")),
                            type=str(rq.get("type", "")),
                            phase=rq.get("phase"),
                            is_inter=is_inter,
                        )
                    )
                contract_block = ContractBlock(exposes=exposes_list, requires=requires_list)
            out.append(
                FileContract(
                    path=str(path),
                    name=str(name),
                    role=role,
                    phase=item.get("phase"),
                    debug_only=bool(item.get("debug_only")),
                    error_codes=list(item.get("error_codes") or []),
                    domain=str(item.get("domain", "")),
                     contract=contract_block,
                    **flags,
                )
            )
    return out


def read_manifest(project: "BaseProject") -> ManifestData | None:
    """Resolve manifest via :class:`ManifestDocument`. Returns None if not found. Never raises."""
    path = getattr(project, "path", None)
    if not path:
        return None
    try:
        from forge.core.manifest_document import ManifestDocument

        doc = ManifestDocument.from_path(Path(path).expanduser().resolve())
        data = doc.to_legacy_dict()
    except (FileNotFoundError, ValueError):
        return None
    if not isinstance(data, dict):
        return None

    screens = _parse_contract_list(data.get("screens") or [], "screen", is_screen=True)
    controllers = _parse_contract_list(
        data.get("controllers") or [], "controller", is_controller=True
    )
    hooks = _parse_contract_list(data.get("hooks") or [], "hook", is_hook=True)
    modules = _parse_contract_list(data.get("modules") or [], "module", is_module=True)
    services = _parse_contract_list(data.get("services") or [], "service", is_service=True)
    variants_raw = data.get("variants") or []
    variants = _parse_contract_list(variants_raw, "variant", is_variant=True)
    active: dict[str, Any] = {}
    if isinstance(data.get("ui_lab"), dict):
        active = dict(data["ui_lab"].get("active_variants") or {})
    # Web project adapter: treat hooks as controllers for inspector/health.
    project_type = getattr(project, "type", "") or ""
    if project_type == "web":
        if hooks:
            # Mark hooks as controllers as well so they participate in controller views.
            adapted = []
            for fc in hooks:
                adapted.append(
                    FileContract(
                        path=fc.path,
                        name=fc.name,
                        role=fc.role,
                        reads=list(fc.reads),
                        writes=list(fc.writes),
                        navigates_to=list(fc.navigates_to),
                        providers=list(fc.providers),
                        depends_on=list(fc.depends_on),
                        variants=list(fc.variants),
                        variant_key=fc.variant_key,
                        domain=fc.domain,
                        phase=fc.phase,
                        debug_only=fc.debug_only,
                        error_codes=list(fc.error_codes),
                        is_screen=fc.is_screen,
                        is_controller=True,
                        is_hook=True,
                        is_module=fc.is_module,
                        is_variant=fc.is_variant,
                        is_service=fc.is_service,
                        extra=dict(fc.extra),
                    )
                )
            controllers = controllers + adapted

    # Top-level inter-project declarations (optional, additive).
    inter_deps: list[InterDependency] = []
    raw_deps = data.get("dependencies") or []
    if isinstance(raw_deps, list):
        for dep in raw_deps:
            if not isinstance(dep, dict):
                continue
            dep_id = str(dep.get("id") or "")
            version = dep.get("version")
            for dom in dep.get("domains") or []:
                if not isinstance(dom, dict):
                    continue
                domain_name = str(dom.get("domain") or "")
                consumes_list: list[ContractExposes] = []
                for ex in dom.get("consumes") or []:
                    if not isinstance(ex, dict):
                        continue
                    consumes_list.append(
                        ContractExposes(
                            name=str(ex.get("name", "")),
                            type=str(ex.get("type", "")),
                            description=str(ex.get("description", "")),
                        )
                    )
                inter_deps.append(
                    InterDependency(
                        id=dep_id,
                        version=str(version) if version is not None else None,
                        domain=domain_name,
                        consumes=consumes_list,
                    )
                )

    inter_exposes: list[InterExposes] = []
    raw_exp = data.get("exposes") or []
    if isinstance(raw_exp, list):
        for item in raw_exp:
            if not isinstance(item, dict):
                continue
            domain_name = str(item.get("domain") or "")
            for_field = item.get("for")
            if isinstance(for_field, list):
                for_projects = [str(x) for x in for_field]
            elif isinstance(for_field, str) and for_field != "any":
                for_projects = [for_field]
            else:
                for_projects = []
            fields: list[ContractExposes] = []
            for ex in item.get("fields") or []:
                if not isinstance(ex, dict):
                    continue
                fields.append(
                    ContractExposes(
                        name=str(ex.get("name", "")),
                        type=str(ex.get("type", "")),
                        description=str(ex.get("description", "")),
                    )
                )
            inter_exposes.append(
                InterExposes(
                    domain=domain_name,
                    for_projects=for_projects,
                    fields=fields,
                )
            )

    app_config_path = path / "assets" / "app_config.yaml"
    if not app_config_path.exists():
        app_config_path = path / "app_config.yaml"
    if app_config_path.exists():
        try:
            import yaml

            ac = yaml.safe_load(app_config_path.read_text()) or {}
            if isinstance(ac.get("ui_lab"), dict):
                active.update(ac["ui_lab"].get("active_variants") or {})
        except Exception:
            pass
    return ManifestData(
        screens=screens,
        controllers=controllers,
        hooks=hooks,
        modules=modules,
        services=services,
        variants=variants,
        active_variants=active,
        dependencies=inter_deps,
        inter_exposes=inter_exposes,
    )
