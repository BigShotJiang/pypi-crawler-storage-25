"""
forge/renderers/textual/state_types.py

Pure data types for the textual renderer — ProjectState + SupabaseInfo.

Extracted from state.py to break the circular import with health_scorer.py:
  state.py     → (runtime) imports HealthScorer
  health_scorer → (was TYPE_CHECKING only) imports ProjectState

By moving ProjectState here, health_scorer.py can import it at the top level
with no guard, and state_types.py has no top-level dep on health_scorer.py.
The HealthScorer call inside load() uses a local import (method-level only) —
the standard Python pattern for deps that cannot be at module level.

Both state.py and health_scorer.py import from here.
state.py re-exports ProjectState + SupabaseInfo for all existing callers.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from forge.core.checks import CheckResult, registry
from forge.archive.tui.textual.git_info import GitInfo, load_git_info
from forge.archive.tui.textual.readiness import ReadinessReport, compute_readiness

if TYPE_CHECKING:
    from forge.core.project import BaseProject


@dataclass
class SupabaseInfo:
    linked: bool = False
    ref: str = ""
    migrations_count: int = 0
    error: str | None = None


@dataclass
class ProjectState:
    project: "BaseProject"
    git: GitInfo = field(default_factory=GitInfo)
    supabase: SupabaseInfo = field(default_factory=SupabaseInfo)
    secrets_present: bool = False
    config_valid: bool = False
    config_path: str = ""
    scripts_present: bool = False
    check_results: list[CheckResult] = field(default_factory=list)
    health_score: int = 0
    health_status: str = "unknown"
    readiness: ReadinessReport = field(default_factory=ReadinessReport)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @classmethod
    def load(cls, project: "BaseProject") -> "ProjectState":
        # Local import — HealthScorer imports ProjectState from this module at
        # the top level, so we cannot import it at module scope here without
        # recreating the cycle. Method-level import is the correct Python idiom.
        from forge.archive.tui.textual.health_scorer import HealthScorer  # noqa: PLC0415

        state = cls(project=project)
        state._load_git()
        state._load_supabase()
        state._load_secrets()
        state._load_config()
        state._load_scripts()
        state._load_checks()
        state._load_readiness()
        state.health_score = HealthScorer.score(state)
        state.health_status = HealthScorer.status(state.health_score)
        return state

    def _load_git(self) -> None:
        self.git = load_git_info(self.project.path)

    def _load_supabase(self) -> None:
        path = self.project.path
        config_path = path / "supabase" / "config.toml"
        if config_path.exists():
            try:
                text = config_path.read_text()
                if "project_id" in text or "projectId" in text:
                    self.supabase.linked = True
            except Exception as e:
                self.supabase.error = str(e)
        mig = path / "supabase" / "migrations"
        if mig.is_dir():
            self.supabase.migrations_count = len(list(mig.glob("*.sql")))

    def _load_secrets(self) -> None:
        slug = self.project.path.name.lower()
        secrets_root = Path("~/Projects/.secrets").expanduser()

        # Check folder format first (preferred)
        folder_env = secrets_root / slug / ".env"
        # Check flat format as fallback (legacy)
        flat_env = secrets_root / f"{slug}.env"

        if folder_env.exists():
            self.secrets_present = folder_env.stat().st_size > 0
        elif flat_env.exists():
            self.secrets_present = flat_env.stat().st_size > 0
        else:
            self.secrets_present = False

    def _load_config(self) -> None:
        path = self.project.path
        ptype = getattr(self.project, "type", "unknown")
        if ptype == "flutter":
            for p in [path / "assets" / "app_config.yaml", path / "app_config.yaml"]:
                if p.exists():
                    self.config_valid = True
                    self.config_path = str(p)
                    return
        elif ptype == "web":
            p = path / "src" / "config" / "site.config.js"
            self.config_valid = p.exists()
            if p.exists():
                self.config_path = str(p)
        elif ptype == "python":
            p = path / "pyproject.toml"
            self.config_valid = p.exists()
            if p.exists():
                self.config_path = str(p)

    def _load_scripts(self) -> None:
        path = self.project.path
        ptype = getattr(self.project, "type", "unknown")
        if ptype == "flutter":
            run_sh = path / "scripts" / "run.sh"
            self.scripts_present = run_sh.exists() and run_sh.stat().st_mode & 0o111
        elif ptype == "web":
            try:
                pkg = path / "package.json"
                if pkg.exists():
                    data = json.loads(pkg.read_text())
                    self.scripts_present = "dev" in (data.get("scripts") or {})
            except Exception:
                pass
        elif ptype == "python":
            try:
                import tomllib
            except ImportError:
                import tomli as tomllib  # type: ignore
            py = path / "pyproject.toml"
            if py.exists():
                try:
                    data = tomllib.loads(py.read_bytes())
                    scripts = (data.get("project") or {}).get("scripts") or {}
                    self.scripts_present = bool(scripts)
                except Exception:
                    pass

    def _load_checks(self) -> None:
        for dc in getattr(self.project, "dashboard_checks", []) or []:
            try:
                self.check_results.append(registry.run(dc))
            except Exception:
                self.check_results.append(
                    CheckResult(dc.label, "unknown", error="check failed")
                )

    def _load_readiness(self) -> None:
        self.readiness = compute_readiness(self.project)
        self.warnings = getattr(self.project, "warnings", []) or []
        self.errors = []
