"""Archived Textual TUI (Sprint B). See README.md."""
