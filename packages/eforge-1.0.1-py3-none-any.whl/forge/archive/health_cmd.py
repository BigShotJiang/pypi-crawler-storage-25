import json

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from forge.core.discovery import discover_projects, get_projects_root
from forge.core.path_utils import resolve_project_path


@click.command()
@click.argument("project_name", required=False)
@click.option(
    "--vector",
    "show_vector",
    is_flag=True,
    help="Print ADI/BRC/IDR health vector scores (forge_health_vector).",
)
@click.option("--project-path", default=".", show_default=True)
def health_cmd(
    project_name: str | None,
    show_vector: bool,
    project_path: str,
) -> None:
    """Run dashboard checks. Omit name to check all projects."""
    click.echo(
        "⚠ forge health is deprecated. Use: forge verify",
        err=True,
    )
    if show_vector:
        from forge.mcp.thin_core import execute_health_vector

        root = resolve_project_path(project_path)
        payload = execute_health_vector({"project_path": str(root)})
        click.echo(json.dumps(payload, indent=2))
        return

    click.echo("forge health is deprecated — use forge verify instead", err=True)
    projects = discover_projects(get_projects_root())
    if project_name:
        projects = [p for p in projects if p.name.lower() == project_name.lower()]
    console = Console()
    for project in projects:
        results = project.health_check()
        table = Table(title=f"{project.name} — health")
        table.add_column("Check", style="bold")
        table.add_column("Status")
        table.add_column("Value / Error")
        for r in results:
            table.add_row(r.label, r.status, r.value or r.error or "—")
        console.print(Panel(table))
