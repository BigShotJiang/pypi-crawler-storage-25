"""
Health Scoring Contracts

Forge-compliant contract definitions for health scoring systems.
Defines interfaces, validation rules, and penalty structures.
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Protocol, runtime_checkable


class SeverityLevel(Enum):
    """Standardized severity levels for health scoring."""
    CRITICAL = "critical"
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class DiscrepancyCategory(Enum):
    """Categories of discrepancies for targeted penalty assessment."""
    MISSING_IMPORT = "missing_import"
    EXTRA_DECLARATION = "extra_declaration"
    BROKEN_DEPENDENCY = "broken_dependency"
    DOMAIN_VIOLATION = "domain_violation"
    ARCHITECTURAL_VIOLATION = "architectural_violation"
    CONFIGURATION_ISSUE = "configuration_issue"


@dataclass
class PenaltyWeight:
    """Configurable penalty weight for health scoring."""
    category: DiscrepancyCategory
    severity: SeverityLevel
    weight: float
    description: str
    stack_specific: bool = False
    applicable_stacks: List[str] = None  # None = all stacks


@dataclass
class HealthScoringConfig:
    """Configuration for health scoring behavior."""
    penalty_weights: List[PenaltyWeight]
    complexity_scaling: Dict[str, float]
    minimum_score: float = 0.0
    maximum_score: float = 1.0
    
    def get_weight(self, category: DiscrepancyCategory, severity: SeverityLevel, stack: str = None) -> float:
        """Get penalty weight for category and severity."""
        for weight in self.penalty_weights:
            if (weight.category == category and 
                weight.severity == severity and
                (not weight.stack_specific or stack in weight.applicable_stacks)):
                return weight.weight
        return 0.0  # Default: no penalty


@runtime_checkable
class HealthScoringStrategy(Protocol):
    """Protocol for health scoring strategies."""
    
    def calculate_score(self, 
                      discrepancies: List[Dict[str, any]], 
                      context: Dict[str, any]) -> float:
        """Calculate health score given discrepancies and context."""
        ...


class HealthScoringContract(ABC):
    """Abstract base class for health scoring implementations."""
    
    @abstractmethod
    def validate_config(self, config: HealthScoringConfig) -> bool:
        """Validate scoring configuration."""
        pass
    
    @abstractmethod
    def calculate_score(self, 
                      discrepancies: List[Dict[str, any]], 
                      context: Dict[str, any]) -> float:
        """Calculate health score with given discrepancies and context."""
        pass
    
    @abstractmethod
    def get_explanation(self, score: float, discrepancies: List[Dict[str, any]]) -> str:
        """Provide human-readable explanation of the score."""
        pass


class StackAgnosticScoringStrategy(HealthScoringContract):
    """Stack-agnostic health scoring implementation."""
    
    def __init__(self, config: HealthScoringConfig):
        self.config = config
        self.validate_config(config)
    
    def validate_config(self, config: HealthScoringConfig) -> bool:
        """Validate configuration completeness."""
        required_categories = [
            DiscrepancyCategory.MISSING_IMPORT,
            DiscrepancyCategory.EXTRA_DECLARATION,
            DiscrepancyCategory.BROKEN_DEPENDENCY,
        ]
        
        for category in required_categories:
            for severity in SeverityLevel:
                if not any(w.category == category and w.severity == severity for w in config.penalty_weights):
                    # Add default weight if missing
                    config.penalty_weights.append(PenaltyWeight(
                        category=category,
                        severity=severity,
                        weight=self._default_weight(category, severity),
                        description=f"Default weight for {category.value}/{severity.value}"
                    ))
        
        return True
    
    def _default_weight(self, category: DiscrepancyCategory, severity: SeverityLevel) -> float:
        """Provide default penalty weights."""
        severity_multipliers = {
            SeverityLevel.CRITICAL: 5.0,
            SeverityLevel.ERROR: 2.0,
            SeverityLevel.WARNING: 0.5,
            SeverityLevel.INFO: 0.1
        }
        
        category_multipliers = {
            DiscrepancyCategory.MISSING_IMPORT: 1.0,
            DiscrepancyCategory.EXTRA_DECLARATION: 0.2,  # Lenient for manifest issues
            DiscrepancyCategory.BROKEN_DEPENDENCY: 1.5,
            DiscrepancyCategory.DOMAIN_VIOLATION: 2.0,
            DiscrepancyCategory.ARCHITECTURAL_VIOLATION: 1.8,
            DiscrepancyCategory.CONFIGURATION_ISSUE: 0.8
        }
        
        return severity_multipliers[severity] * category_multipliers[category]
    
    def calculate_score(self, 
                      discrepancies: List[Dict[str, any]], 
                      context: Dict[str, any]) -> float:
        """Calculate health score using contract-based penalties."""
        if not discrepancies:
            return self.config.maximum_score
        
        stack = context.get('stack', 'unknown')
        file_count = context.get('file_count', 1)
        
        # Calculate total penalty
        total_penalty = 0.0
        for discrepancy in discrepancies:
            category = DiscrepancyCategory(discrepancy.get('category', 'missing_import'))
            severity = SeverityLevel(discrepancy.get('severity', 'warning'))
            
            weight = self.config.get_weight(category, severity, stack)
            total_penalty += weight
        
        # Apply complexity scaling
        scaling_factor = self._calculate_complexity_factor(file_count, self.config.complexity_scaling)
        adjusted_penalty = total_penalty * scaling_factor
        
        # Calculate final score
        raw_score = max(0.0, self.config.maximum_score - adjusted_penalty)
        return max(self.config.minimum_score, min(self.config.maximum_score, raw_score))
    
    def _calculate_complexity_factor(self, file_count: int, scaling_config: Dict[str, float]) -> float:
        """Calculate complexity-based scaling factor."""
        base_factor = scaling_config.get('base_factor', 50.0)
        min_factor = scaling_config.get('min_factor', 0.1)
        max_factor = scaling_config.get('max_factor', 1.0)
        
        calculated_factor = base_factor / max(file_count, 1)
        return max(min_factor, min(max_factor, calculated_factor))
    
    def get_explanation(self, score: float, discrepancies: List[Dict[str, any]]) -> str:
        """Provide human-readable explanation of the health score."""
        if score >= 0.9:
            return f"Excellent health ({score:.1%}): Minimal issues detected"
        elif score >= 0.7:
            return f"Good health ({score:.1%}): Some issues present but manageable"
        elif score >= 0.5:
            return f"Fair health ({score:.1%}): Multiple issues need attention"
        elif score >= 0.3:
            return f"Poor health ({score:.1%}): Significant issues require immediate attention"
        else:
            return f"Critical health ({score:.1%}): Major architectural problems detected"


class HealthScoringFactory:
    """Factory for creating health scoring strategies."""
    
    @staticmethod
    def create_strategy(config: HealthScoringConfig, strategy_type: str = "stack_agnostic") -> HealthScoringContract:
        """Create health scoring strategy based on configuration."""
        if strategy_type == "stack_agnostic":
            return StackAgnosticScoringStrategy(config)
        else:
            raise ValueError(f"Unknown strategy type: {strategy_type}")
    
    @staticmethod
    def load_config_from_glove(stack: str) -> HealthScoringConfig:
        """Load scoring configuration from glove template."""
        # This would integrate with MCP glove registry
        default_weights = [
            # Missing import penalties
            PenaltyWeight(DiscrepancyCategory.MISSING_IMPORT, SeverityLevel.ERROR, 2.0, "Missing import error"),
            PenaltyWeight(DiscrepancyCategory.MISSING_IMPORT, SeverityLevel.WARNING, 0.5, "Missing import warning"),
            PenaltyWeight(DiscrepancyCategory.MISSING_IMPORT, SeverityLevel.INFO, 0.1, "Missing import info"),
            
            # Extra declaration penalties (manifest issues)
            PenaltyWeight(DiscrepancyCategory.EXTRA_DECLARATION, SeverityLevel.ERROR, 1.0, "Extra declaration error"),
            PenaltyWeight(DiscrepancyCategory.EXTRA_DECLARATION, SeverityLevel.WARNING, 0.1, "Extra declaration warning"),
            PenaltyWeight(DiscrepancyCategory.EXTRA_DECLARATION, SeverityLevel.INFO, 0.05, "Extra declaration info"),
            
            # Broken dependency penalties
            PenaltyWeight(DiscrepancyCategory.BROKEN_DEPENDENCY, SeverityLevel.ERROR, 3.0, "Broken dependency error"),
            PenaltyWeight(DiscrepancyCategory.BROKEN_DEPENDENCY, SeverityLevel.WARNING, 1.0, "Broken dependency warning"),
            
            # Domain violation penalties
            PenaltyWeight(DiscrepancyCategory.DOMAIN_VIOLATION, SeverityLevel.ERROR, 2.5, "Domain violation error"),
            PenaltyWeight(DiscrepancyCategory.DOMAIN_VIOLATION, SeverityLevel.WARNING, 0.8, "Domain violation warning"),
        ]
        
        return HealthScoringConfig(
            penalty_weights=default_weights,
            complexity_scaling={
                'base_factor': 50.0,
                'min_factor': 0.1,
                'max_factor': 1.0
            }
        )
