"""Import resolution contracts for stack-agnostic validation.

Defines interfaces for import resolution that can be implemented
by stack-specific strategies while maintaining architectural integrity.
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass


@dataclass(frozen=True)
class ImportResolutionRule:
    """Represents a single import resolution rule."""
    source_extension: str
    target_extensions: List[str]
    priority: int = 1
    stack_specific: bool = False


@dataclass(frozen=True)
class ImportResolutionContext:
    """Context for import resolution operations."""
    project_root: Path
    source_file: Path
    import_module: str
    stack_config: Optional[Dict[str, Any]] = None


class ImportResolutionStrategy(ABC):
    """Abstract base class for stack-specific import resolution strategies."""
    
    @abstractmethod
    def get_resolution_rules(self, context: ImportResolutionContext) -> List[ImportResolutionRule]:
        """Return resolution rules for the given context."""
        pass
    
    @abstractmethod
    def supports_extension(self, extension: str) -> bool:
        """Check if this strategy supports the given file extension."""
        pass
    
    @abstractmethod
    def resolve_import(self, context: ImportResolutionContext) -> Optional[Path]:
        """Resolve import path according to strategy rules."""
        pass


class ImportResolutionContract:
    """Contract interface for import resolution operations."""
    
    def __init__(self, strategies: List[ImportResolutionStrategy]):
        self.strategies = strategies
    
    def resolve_import_path(self, context: ImportResolutionContext) -> Optional[Path]:
        """Resolve import path using appropriate strategy."""
        source_ext = context.source_file.suffix
        
        # Find strategy that supports this extension
        for strategy in self.strategies:
            if strategy.supports_extension(source_ext):
                return strategy.resolve_import(context)
        
        return None
    
    def get_applicable_rules(self, context: ImportResolutionContext) -> List[ImportResolutionRule]:
        """Get all applicable resolution rules for the context."""
        source_ext = context.source_file.suffix
        rules = []
        
        for strategy in self.strategies:
            if strategy.supports_extension(source_ext):
                rules.extend(strategy.get_resolution_rules(context))
        
        return sorted(rules, key=lambda r: r.priority)


class StackAgnosticResolver:
    """Stack-agnostic import resolver using contract-based strategies."""
    
    def __init__(self, contract: ImportResolutionContract):
        self.contract = contract
    
    def resolve_import(self, import_module: str, source_file: Path, 
                      project_root: Path, stack_config: Optional[Dict[str, Any]] = None) -> Optional[Path]:
        """Resolve import path using stack-agnostic contract."""
        context = ImportResolutionContext(
            project_root=project_root,
            source_file=source_file,
            import_module=import_module,
            stack_config=stack_config
        )
        
        return self.contract.resolve_import_path(context)
