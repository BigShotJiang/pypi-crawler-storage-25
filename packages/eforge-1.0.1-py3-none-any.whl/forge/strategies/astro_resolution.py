"""Astro-specific import resolution strategy.

Implements stack-agnostic import resolution contract for Astro projects,
handling React island imports and TypeScript module resolution.
"""

from pathlib import Path
from typing import Dict, List, Optional, Any

from forge.contracts.import_resolution import (
    ImportResolutionStrategy,
    ImportResolutionRule,
    ImportResolutionContext
)


class AstroResolutionStrategy(ImportResolutionStrategy):
    """Astro-specific import resolution strategy."""
    
    def __init__(self):
        # Astro-specific resolution rules
        self.base_rules = [
            ImportResolutionRule('.astro', ['.tsx', '.ts', '.astro', '.js'], priority=1),
            ImportResolutionRule('.tsx', ['.tsx', '.ts', '.js'], priority=1),
            ImportResolutionRule('.ts', ['.ts', '.js'], priority=1),
            ImportResolutionRule('.js', ['.js', '.ts'], priority=1),
        ]
    
    def get_resolution_rules(self, context: ImportResolutionContext) -> List[ImportResolutionRule]:
        """Return Astro-specific resolution rules."""
        rules = self.base_rules.copy()
        
        # Add stack-specific rules from config if available
        if context.stack_config:
            custom_rules = context.stack_config.get('import_resolution_rules', [])
            for rule_data in custom_rules:
                rule = ImportResolutionRule(
                    source_extension=rule_data['source_extension'],
                    target_extensions=rule_data['target_extensions'],
                    priority=rule_data.get('priority', 2),
                    stack_specific=True
                )
                rules.append(rule)
        
        return sorted(rules, key=lambda r: r.priority)
    
    def supports_extension(self, extension: str) -> bool:
        """Check if strategy supports the given extension."""
        return any(rule.source_extension == extension for rule in self.base_rules)
    
    def resolve_import(self, context: ImportResolutionContext) -> Optional[Path]:
        """Resolve import path using Astro-specific rules."""
        if not (context.import_module.startswith('./') or context.import_module.startswith('../')):
            return None
        
        try:
            # Get resolution rules for this source extension
            source_ext = context.source_file.suffix
            applicable_rules = [r for r in self.get_resolution_rules(context) 
                             if r.source_extension == source_ext]
            
            if not applicable_rules:
                return None
            
            # Use highest priority rule
            rule = applicable_rules[0]
            
            # Calculate base path
            from forge.core.import_parser import ImportParser
            parser = ImportParser(context.project_root)
            base_path = parser.normalize_module_path(context.import_module, context.source_file)
            
            if not base_path:
                return None
            
            # Try target extensions in order
            for target_ext in rule.target_extensions:
                target_path = context.project_root / f"{base_path}{target_ext}"
                if target_path.exists():
                    return target_path
            
            # Try index files as fallback
            for target_ext in rule.target_extensions:
                index_path = context.project_root / base_path / f"index{target_ext}"
                if index_path.exists():
                    return index_path
            
            return None
            
        except (ValueError, FileNotFoundError):
            return None


class ReactIslandResolutionStrategy(ImportResolutionStrategy):
    """Specialized strategy for React island imports in Astro."""
    
    def get_resolution_rules(self, context: ImportResolutionContext) -> List[ImportResolutionRule]:
        """Return React island specific rules."""
        return [
            ImportResolutionRule('.astro', ['.tsx'], priority=0, stack_specific=True),
            ImportResolutionRule('.tsx', ['.tsx', '.ts'], priority=0, stack_specific=True),
        ]
    
    def supports_extension(self, extension: str) -> bool:
        """Support Astro and TSX files for React islands."""
        return extension in ['.astro', '.tsx']
    
    def resolve_import(self, context: ImportResolutionContext) -> Optional[Path]:
        """Resolve React island imports with special handling."""
        # Check if this is likely a React island import
        source_ext = context.source_file.suffix
        
        if source_ext == '.astro':
            # Astro files importing React components
            return self._resolve_astro_to_react(context)
        elif source_ext == '.tsx':
            # React components importing other React components
            return self._resolve_react_to_react(context)
        
        return None
    
    def _resolve_astro_to_react(self, context: ImportResolutionContext) -> Optional[Path]:
        """Resolve Astro to React component imports."""
        try:
            from forge.core.import_parser import ImportParser
            parser = ImportParser(context.project_root)
            base_path = parser.normalize_module_path(context.import_module, context.source_file)
            
            if not base_path:
                return None
            
            # Try .tsx first (React islands)
            target_path = context.project_root / f"{base_path}.tsx"
            if target_path.exists():
                return target_path
            
            # Fall back to .ts
            target_path = context.project_root / f"{base_path}.ts"
            if target_path.exists():
                return target_path
            
            return None
            
        except (ValueError, FileNotFoundError):
            return None
    
    def _resolve_react_to_react(self, context: ImportResolutionContext) -> Optional[Path]:
        """Resolve React to React component imports."""
        try:
            from forge.core.import_parser import ImportParser
            parser = ImportParser(context.project_root)
            base_path = parser.normalize_module_path(context.import_module, context.source_file)
            
            if not base_path:
                return None
            
            # Try .tsx first
            target_path = context.project_root / f"{base_path}.tsx"
            if target_path.exists():
                return target_path
            
            # Fall back to .ts
            target_path = context.project_root / f"{base_path}.ts"
            if target_path.exists():
                return target_path
            
            return None
            
        except (ValueError, FileNotFoundError):
            return None
