import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from .schema import UniversalEvent

class EventEmitter:
    """
    Writes events to .forge/events/YYYY-MM-DD.jsonl
    Append-only. Thread-safe via file append mode.

    CRITICAL DESIGN RULE:
    Events are facts — past-tense records of what happened.
    They are NEVER commands or instructions.
    A subscriber may react to an event, but the event itself
    must never say what to do next.
    """

    def __init__(self, project_path: str | Path):
        self.project_path = Path(project_path).expanduser().resolve()
        self.events_dir = self.project_path / ".forge" / "events"
        self._session_id: str = ""
        self._last_hash: str = ""

    def set_session(self, session_id: str) -> None:
        self._session_id = session_id

    def _log_path(self) -> Path:
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        return self.events_dir / f"{today}.jsonl"

    def _compute_hash(self, event_dict: dict) -> str:
        """SHA-256 of the event dict (json-serialised)."""
        content = json.dumps(event_dict, sort_keys=True)
        return hashlib.sha256(
            content.encode()
        ).hexdigest()[:16]   # first 16 chars — sufficient

    def emit(self, event: UniversalEvent) -> UniversalEvent:
        """
        Write event to the daily JSONL log.
        Returns the event (with id and timestamp populated).
        Never raises — event emission failure must not
        break the operation that produced the event.
        """
        if self._session_id and not event.session_id:
            event.session_id = self._session_id

        # Set prev_hash before writing
        event.prev_hash = self._last_hash

        try:
            self.events_dir.mkdir(parents=True, exist_ok=True)
            event_dict = event.to_dict()
            with open(self._log_path(), "a", encoding="utf-8") as f:
                f.write(json.dumps(event_dict) + "\n")
            # Update chain
            self._last_hash = self._compute_hash(event_dict)
        except Exception:
            pass   # Silent — never break the caller
        return event

    def emit_tool_event(
        self,
        tool_name: str,
        project: str,
        kind: str,           # "tool_called" | "tool_completed" | "tool_failed"
        payload: dict | None = None,
    ) -> UniversalEvent:
        event = UniversalEvent(
            kind=kind,
            source_fqid=f"forge:{tool_name}",
            project=project,
            payload=payload or {},
        )
        return self.emit(event)

    def read_events(
        self,
        date: str | None = None,
        kind_filter: str | None = None,
        limit: int = 100,
    ) -> list[dict]:
        """
        Read events from the log.
        date: "YYYY-MM-DD" or None for today.
        kind_filter: event kind string or None for all.
        limit: max events to return (newest first).
        """
        if date is None:
            date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        log_path = self.events_dir / f"{date}.jsonl"
        if not log_path.exists():
            return []
        events = []
        try:
            with open(log_path, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        ev = json.loads(line)
                        if kind_filter is None or \
                           ev.get("kind") == kind_filter:
                            events.append(ev)
                    except json.JSONDecodeError:
                        continue
        except Exception:
            return []
        return events[-limit:]   # newest last, trimmed
