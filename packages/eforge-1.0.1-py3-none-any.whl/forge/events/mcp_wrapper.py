from pathlib import Path
from .emitter import EventEmitter
from .schema import UniversalEvent

def extract_project(arguments: dict) -> str:
    """
    Extract project identifier from tool arguments.
    Tries project_path first, then project, then 'unknown'.
    """
    raw = (
        arguments.get("project_path")
        or arguments.get("project")
        or "unknown"
    )
    try:
        return Path(raw).expanduser().resolve().name
    except Exception:
        return str(raw)

def get_emitter(arguments: dict) -> EventEmitter | None:
    """
    Build an EventEmitter for the project in arguments.
    Returns None if project_path cannot be resolved.
    Never raises.
    """
    try:
        raw = arguments.get("project_path") or \
              arguments.get("project")
        if not raw:
            return None
        path = Path(raw).expanduser().resolve()
        if not path.exists():
            return None
        return EventEmitter(path)
    except Exception:
        return None

def wrap_tool_call(
    tool_name: str,
    arguments: dict,
    handler_fn,       # the existing handle_forge_* function
) -> dict:
    """
    Wraps a single tool call:
      1. Emits tool_called event
      2. Calls handler_fn(arguments)
      3. Emits tool_completed or tool_failed
      4. Returns result unchanged

    NEVER modifies the result. NEVER raises from event code.
    The wrapper is transparent — the tool behaves identically
    whether or not event emission succeeds.
    """
    emitter = get_emitter(arguments)
    project = extract_project(arguments)

    if emitter:
        emitter.emit_tool_event(
            tool_name=tool_name,
            project=project,
            kind="tool_called",
            payload={"arguments": {
                k: v for k, v in arguments.items()
                if k != "project_path"   # don't log full paths
            }},
        )

    result = None
    try:
        result = handler_fn(arguments)
        if emitter:
            emitter.emit_tool_event(
                tool_name=tool_name,
                project=project,
                kind="tool_completed",
                payload={"ok": result.get("ok", True)
                         if isinstance(result, dict) else True},
            )
        return result
    except Exception as e:
        if emitter:
            emitter.emit_tool_event(
                tool_name=tool_name,
                project=project,
                kind="tool_failed",
                payload={"error": str(e)[:200]},
            )
        raise   # re-raise — wrapper never swallows errors
