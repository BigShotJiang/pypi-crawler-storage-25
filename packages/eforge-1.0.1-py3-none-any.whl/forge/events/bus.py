from pathlib import Path
from .schema import UniversalEvent
from .emitter import EventEmitter


class EventBus:
    """
    Routes events to registered subscribers.
    The bus is a fact router — delivers past-tense events.
    Never interprets events or issues commands.

    RULE: publish() never raises.
    RULE: Subscriber failures are always silent.
    """

    def __init__(self, project_path: str | Path):
        self.project_path = Path(project_path)
        self._subscribers: list = []
        self._emitter = EventEmitter(project_path)

    def subscribe(self, subscriber) -> None:
        self._subscribers.append(subscriber)

    def publish(self, event: UniversalEvent) -> list[UniversalEvent]:
        """
        Deliver event to all interested subscribers.
        Returns all downstream events emitted.
        Never raises.
        """
        self._emitter.emit(event)
        downstream = []
        for subscriber in self._subscribers:
            if not subscriber.handles_event(event.kind):
                continue
            try:
                new_events = subscriber.on_event(event)
                for new_ev in (new_events or []):
                    self._emitter.emit(new_ev)
                    downstream.append(new_ev)
            except Exception:
                continue
        return downstream

    def discover(self, forge_dir: Path) -> list[str]:
        """Discover subscribers from .forge/subscribers/. Never raises."""
        try:
            from forge.protocols.registry import get_subscriber_registry
            reg = get_subscriber_registry()
            discovered = reg.discover(forge_dir)
            for name in discovered:
                sub = reg.get(name)
                if sub:
                    self.subscribe(sub)
            return discovered
        except Exception:
            return []
