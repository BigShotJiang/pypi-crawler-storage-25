from dataclasses import dataclass, field
from datetime import datetime, timezone
import uuid

# Event kind registry — open enum, always additive
# New kinds are added here and nowhere else
KNOWN_EVENT_KINDS = [
    # Tool lifecycle
    "tool_called",
    "tool_completed",
    "tool_failed",
    # Graph operations
    "node_declared",
    "node_implemented",
    "node_drifted",
    "node_updated",
    "graph_built",
    "graph_reconciled",
    # Verification
    "verify_passed",
    "verify_failed",
    "exclusion_violated",
    # Scaffold
    "scaffold_completed",
    "scaffold_failed",
    # Schema / contracts
    "schema_changed",
    # Annotation
    "annotation_created",
    "annotation_resolved",
    # Session
    "session_started",
    "session_ended",
    # Init
    "project_initialized",
    # Stack profiles
    "stack_profile_loaded",
    "profile_registered",
    # File system
    "file_changed",
    "manifest_reloaded",
    "annotation_index_reloaded",
]

@dataclass
class UniversalEvent:
    kind: str                    # from KNOWN_EVENT_KINDS (open)
    source_fqid: str             # which node/tool produced this
    project: str                 # project name or path
    payload: dict                # event-specific data

    # Auto-populated — do not pass these manually
    id: str = field(
        default_factory=lambda: str(uuid.uuid4())[:8]
    )
    timestamp: str = field(
        default_factory=lambda: datetime.now(
            timezone.utc
        ).isoformat()
    )
    session_id: str = ""         # set by EventEmitter if in session
    prev_hash: str = ""        # SHA-256 of previous event's to_dict() output
    meta: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "kind": self.kind,
            "source_fqid": self.source_fqid,
            "project": self.project,
            "session_id": self.session_id,
            "prev_hash": self.prev_hash,
            "payload": self.payload,
            "meta": self.meta,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "UniversalEvent":
        return cls(
            id=data.get("id", ""),
            timestamp=data.get("timestamp", ""),
            kind=data["kind"],
            source_fqid=data.get("source_fqid", ""),
            project=data.get("project", ""),
            session_id=data.get("session_id", ""),
            prev_hash=data.get("prev_hash", ""),
            payload=data.get("payload", {}),
            meta=data.get("meta", {}),
        )
