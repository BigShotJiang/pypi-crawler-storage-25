"""Serialize / restore :class:`SchemaRegistry` for workspace baselines."""

from __future__ import annotations

from pathlib import Path
from typing import Any, cast

import yaml

from forge.schema.registry import FieldDefinition, SchemaEntity, SchemaRegistry


def _field_row(fd: FieldDefinition | dict[str, Any]) -> FieldDefinition:
    if isinstance(fd, FieldDefinition):
        return fd
    return FieldDefinition(
        name=str(fd["name"]),
        type_repr=str(fd.get("type_repr", "")),
        required=bool(fd.get("required", False)),
        has_default=bool(fd.get("has_default", False)),
    )


def _entity_from_record(schema_id: str, rec: dict[str, Any]) -> SchemaEntity:
    fields_raw = rec.get("fields") or []
    flds = tuple(sorted((_field_row(f) for f in fields_raw), key=lambda x: x.name))
    return SchemaEntity(
        id=str(rec.get("id") or schema_id),
        version=str(rec.get("version") or ""),
        fields=flds,
        consumers=tuple(sorted(str(x) for x in (rec.get("consumers") or []) if x)),
        breaking_change_fields=tuple(
            sorted(str(x) for x in (rec.get("breaking_change_fields") or []) if x),
        ),
    )


def registry_from_yaml(content: str) -> SchemaRegistry:
    """Hydrate entities from YAML file body (``.forge/schema_registry_baseline.yaml``)."""
    reg = SchemaRegistry()
    data = yaml.safe_load(content)
    block = {} if data is None else cast(dict[str, Any], data)
    entities = cast(dict[str, Any], block.get("schemas") or {})
    for key, rows in entities.items():
        sid = str(key).strip()
        if not sid or not isinstance(rows, dict):
            continue
        ent = _entity_from_record(sid, rows)
        reg.register(ent)
    return reg


def registry_to_yaml(reg: SchemaRegistry) -> str:
    """Produce v1 snapshot document for committing / diffing drift baselines."""
    doc: dict[str, Any] = {"schema_snapshot_version": 1, "schemas": {}}
    for sid in reg.schema_ids():
        ent = reg.get(sid)
        if ent is None:
            continue
        doc["schemas"][sid] = {
            "id": ent.id,
            "version": ent.version,
            "consumers": list(ent.consumers),
            "breaking_change_fields": list(ent.breaking_change_fields),
            "fields": [
                {
                    "name": f.name,
                    "type_repr": f.type_repr,
                    "required": f.required,
                    "has_default": f.has_default,
                }
                for f in sorted(ent.fields, key=lambda x: x.name)
            ],
        }
    return yaml.safe_dump(doc, sort_keys=True, default_flow_style=False)


def write_registry_yaml(reg: SchemaRegistry, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(registry_to_yaml(reg), encoding="utf-8")


def read_registry_yaml(path: Path | None) -> SchemaRegistry | None:
    """Return entities if file readable; absent file → ``None`` (skip drift)."""
    if path is None or not path.is_file():
        return None
    try:
        return registry_from_yaml(path.read_text(encoding="utf-8"))
    except Exception:
        return None
