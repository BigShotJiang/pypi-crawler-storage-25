"""Schema-registry drift propagation — Sprint 10 Phase 2.

Compares persisted workspace baselines to live builtins, publishes ``schema_changed``
facts via :class:`~forge.engine.hooks.HookBus`, drains resulting ``node_drifted``
events into forge verify severity-2 payloads.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from forge.engine.hooks import HookBus
from forge.engine.registry import EntityRegistry
from forge.engine.drift.declaration import DeclarationDriftDetector
from forge.events.schema import UniversalEvent
from forge.schema.registry import SchemaChangeDiff, SchemaEntity, SchemaRegistry


def collect_schema_registry_drift_failures(
    project_path: Path,
    baseline: SchemaRegistry,
    live: SchemaRegistry,
    *,
    workspace_registry: EntityRegistry | None = None,
    workspace_id: str = "local",
    adr_tag: str = "Sprint-10",
) -> tuple[list[dict[str, Any]], list[UniversalEvent]]:
    """Diff baselines vs live builtins; emit HookBus propagation; assemble verify failures.

    Returns tuples of verify-shaped failure dictionaries and downstream events.
    """

    hooks = HookBus(project_path)
    scoped = workspace_registry if workspace_registry is not None else EntityRegistry()
    detector = DeclarationDriftDetector(scoped)
    hooks.register_subscriber(detector)

    downstream: list[UniversalEvent] = []

    baseline_ids = set(baseline.entity_map())
    live_ids = set(live.entity_map())
    unified = sorted(baseline_ids | live_ids)

    failures: list[dict[str, Any]] = []

    def _vf(kind: str, severity: str, message: str, node: str, adr: str) -> dict[str, Any]:
        return {"kind": kind, "severity": severity, "message": message, "node": node, "adr": adr}

    def _consume_downstream(events: list[UniversalEvent]) -> None:
        for ev in events:
            downstream.append(ev)
            if ev.kind != "node_drifted":
                continue
            pl = dict(ev.payload or {})
            nid = str(pl.get("node_id") or pl.get("target_id") or "").strip()
            failures.append(
                _vf(
                    kind="schema-drift-node",
                    severity="error",
                    message=(
                        f"schema propagation drift workspace={workspace_id} "
                        f"schema={pl.get('schema_id', '')} drift_type={pl.get('drift_type', '')}"
                    ),
                    node=nid or "unknown",
                    adr=adr_tag,
                ),
            )

    for sid in unified:
        old_e = baseline.get(sid)
        new_e = live.get(sid)
        if old_e == new_e and old_e is not None:
            continue
        schema_diff = SchemaRegistry.diff(old_e, new_e)
        if not schema_diff.added_fields and not schema_diff.removed_fields and not schema_diff.changed_fields:
            continue
        summary = schema_diff.to_summary()
        version_line = (
            {"old_version": old_e.version, "new_version": new_e.version}
            if isinstance(old_e, SchemaEntity) and isinstance(new_e, SchemaEntity)
            else {}
        )
        emitted = hooks.emit_schema_changed(
            schema_id=sid if sid else "(unknown)",
            breaking=schema_diff.breaking,
            diff_summary={**summary, **version_line},
            consumer_node_ids=new_e.consumers if isinstance(new_e, SchemaEntity) else (),
        )
        _consume_downstream(emitted)

        failures.extend(_diff_failures(workspace_id, schema_diff, adr_tag))

    return (failures, downstream)


def _diff_failures(ws_id: str, diff: SchemaChangeDiff, adr: str) -> list[dict[str, Any]]:
    if not diff.breaking:
        return []
    return [
        {
            "kind": "schema-registry-drift-breaking",
            "severity": "error",
            "message": (
                f"breaking registry drift workspace={ws_id} schema={diff.schema_id} "
                f"removed={diff.removed_fields} changed={diff.changed_fields}"
            ),
            "node": diff.schema_id,
            "adr": adr,
        }
    ]
