"""
forge-extension grants system.

A project with kind: forge-extension in its top-level
manifest gets access to three capabilities that regular
projects do not:

  1. hook nodes    — can declare nodes of kind: hook
  2. cross-project edges — can use forge: namespace in edges
  3. workspace-registration — auto-added to workspace.yaml
                              on forge_init

Grants are checked by forge_verify when processing a manifest
with kind: forge-extension at the top level.
"""

FORGE_EXTENSION_GRANTS = [
    "hook_nodes",
    "cross_project_edges",
    "workspace_registration",
]


def is_forge_extension(manifest_data: dict) -> bool:
    """Returns True if the manifest declares kind: forge-extension."""
    return manifest_data.get("kind") == "forge-extension"


def get_grants(manifest_data: dict) -> list[str]:
    """
    Returns the list of grants for this manifest.
    Regular projects: empty list.
    forge-extension projects: all three grants.
    """
    if is_forge_extension(manifest_data):
        return list(FORGE_EXTENSION_GRANTS)
    return []


def check_grant(
    manifest_data: dict, grant: str
) -> bool:
    """Returns True if this manifest has the specified grant."""
    return grant in get_grants(manifest_data)
