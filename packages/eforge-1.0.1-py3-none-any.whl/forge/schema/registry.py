"""Schema registry — Sprint 10 Phase 1 (schema propagation groundwork).

Registers canonical Pydantic shapes (``NodeModel``, ``EdgeModel``, ``ForgeQueryInput``)
as typed :class:`SchemaEntity` records for drift / blast propagation ahead.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel
from pydantic.fields import FieldInfo
from pydantic_core import PydanticUndefined

from forge.core.schemas import ForgeQueryInput
from forge.engine.entity.schemas import EdgeModel, NodeModel


@dataclass(frozen=True)
class FieldDefinition:
    """One field slot on a versioned schema surface."""

    name: str
    type_repr: str
    required: bool
    has_default: bool


@dataclass(frozen=True)
class SchemaChangeDiff:
    """Field-level structural delta between two :class:`SchemaEntity` surfaces."""

    schema_id: str
    added_fields: tuple[str, ...]
    removed_fields: tuple[str, ...]
    changed_fields: tuple[str, ...]
    breaking: bool

    def to_summary(self) -> dict[str, Any]:
        """JSON-friendly capsule for HookBus / verify payloads."""
        return {
            "schema_id": self.schema_id,
            "added_fields": list(self.added_fields),
            "removed_fields": list(self.removed_fields),
            "changed_fields": list(self.changed_fields),
            "breaking": self.breaking,
        }


def _diff_entities(old_ent: SchemaEntity, new_ent: SchemaEntity) -> SchemaChangeDiff:
    if old_ent.id != new_ent.id:
        msg = "SchemaRegistry.diff requires matching schema ids"
        raise ValueError(msg)
    left = {f.name: f for f in old_ent.fields}
    right = {f.name: f for f in new_ent.fields}

    removed = tuple(sorted(set(left) - set(right)))
    added = tuple(sorted(set(right) - set(left)))

    changed: list[str] = []
    for name in sorted(set(left) & set(right)):
        if left[name] != right[name]:
            changed.append(name)

    changed_t = tuple(changed)

    breaking = bool(removed)

    brittle = set(old_ent.breaking_change_fields) | set(new_ent.breaking_change_fields)

    # New required slots without defaults are breaking for consumers expecting the old surface.
    for name in added:
        fd = right[name]
        if fd.required and not fd.has_default:
            breaking = True

    # Field shape changes matter when the slot is brittle or cardinality tightens / type differs.
    for name in changed_t:
        o, n = left[name], right[name]
        if name in brittle or o.type_repr != n.type_repr:
            breaking = True
            continue
        if (not n.required or n.has_default) and (o.required and not o.has_default):
            breaking = False
            continue  # Relaxing requirement is treated as compatible
        if n.required and not n.has_default and ((not o.required) or o.has_default):
            breaking = True

    return SchemaChangeDiff(
        schema_id=old_ent.id,
        added_fields=added,
        removed_fields=removed,
        changed_fields=changed_t,
        breaking=breaking,
    )


@dataclass(frozen=True)
class SchemaEntity:
    """Versioned structural contract with optional dependents (consumer node ids).

    ``consumers`` lists declaration-graph node ids whose logic depends on this schema
    surface (populate incrementally via :meth:`SchemaRegistry.track_consumer`).
    ``breaking_change_fields`` names whose type/required-ness changes are breaking.
    """

    id: str
    version: str
    fields: tuple[FieldDefinition, ...]
    consumers: tuple[str, ...] = ()
    breaking_change_fields: tuple[str, ...] = ()


def _field_definition(name: str, finfo: FieldInfo) -> FieldDefinition:
    ann = finfo.annotation
    type_repr = getattr(ann, "__name__", None) or str(ann)
    required = finfo.is_required()
    default_raw = getattr(finfo, "default", PydanticUndefined)
    has_default = (default_raw is not PydanticUndefined) or getattr(finfo, "default_factory", None) is not None
    return FieldDefinition(
        name=name,
        type_repr=type_repr,
        required=required,
        has_default=has_default or not required,
    )


def schema_fields_from_model(model: type[BaseModel]) -> tuple[FieldDefinition, ...]:
    """Flatten Pydantic v2 ``model_fields`` into stable field rows."""
    return tuple(
        sorted(
            (_field_definition(name, fi) for name, fi in model.model_fields.items()),
            key=lambda f: f.name,
        )
    )


def entity_from_model(
    entity_id: str,
    *,
    model: type[BaseModel],
    version: str = "1.0.0",
    consumers: tuple[str, ...] = (),
    breaking_change_fields: tuple[str, ...] = (),
) -> SchemaEntity:
    return SchemaEntity(
        id=entity_id,
        version=version,
        fields=schema_fields_from_model(model),
        consumers=consumers,
        breaking_change_fields=breaking_change_fields,
    )


NODE_BREAKING_FIELDS: tuple[str, ...] = (
    "id",
    "kind",
    "domain",
    "tier",
    "path",
    "status",
    "depends_on",
    "consumed_by",
)


@dataclass
class SchemaRegistry:
    """In-memory schema catalog with consumer tracking helpers."""

    _entities: dict[str, SchemaEntity] = field(default_factory=dict)

    def register(self, entity: SchemaEntity) -> None:
        self._entities[entity.id] = entity

    def get(self, schema_id: str) -> SchemaEntity | None:
        return self._entities.get(schema_id)

    def clone(self) -> SchemaRegistry:
        out = SchemaRegistry()
        out._entities = dict(self._entities)
        return out

    def track_consumer(self, schema_id: str, node_id: str) -> None:
        ent = self._entities.get(schema_id)
        if ent is None:
            return
        c = tuple(sorted(set(ent.consumers + (node_id,))))
        self._entities[schema_id] = SchemaEntity(
            id=ent.id,
            version=ent.version,
            fields=ent.fields,
            consumers=c,
            breaking_change_fields=ent.breaking_change_fields,
        )

    @classmethod
    def builtin(cls) -> SchemaRegistry:
        """Canonical entities used across engine + MCP query surface."""
        reg = cls()
        reg.register(
            entity_from_model(
                "forge.schema/NodeModel",
                model=NodeModel,
                breaking_change_fields=NODE_BREAKING_FIELDS,
                consumers=("module/engine.entity", "module/engine.registry"),
            )
        )
        reg.register(
            entity_from_model(
                "forge.schema/EdgeModel",
                model=EdgeModel,
                breaking_change_fields=("from_id", "to_id", "relation"),
                consumers=("module/engine.entity", "module/engine.registry"),
            )
        )
        reg.register(
            entity_from_model(
                "forge.schema/ForgeQueryInput",
                model=ForgeQueryInput,
                breaking_change_fields=("depends_on", "node_id"),
                consumers=(
                    "module/mcp.handlers.core_tools",
                    "module/core.query",
                ),
            )
        )
        return reg

    def schema_ids(self) -> tuple[str, ...]:
        return tuple(sorted(self._entities))

    def entity_map(self) -> dict[str, SchemaEntity]:
        return dict(self._entities)

    @staticmethod
    def diff(old: SchemaEntity | None, new: SchemaEntity | None) -> SchemaChangeDiff:
        """Compare two surfaces; removals or brittle field churn are classified breaking."""
        if old is None and new is None:
            return SchemaChangeDiff(
                schema_id="(none)",
                added_fields=(),
                removed_fields=(),
                changed_fields=(),
                breaking=False,
            )
        if old is None and new is not None:
            return SchemaChangeDiff(
                schema_id=new.id,
                added_fields=tuple(f.name for f in new.fields),
                removed_fields=(),
                changed_fields=(),
                breaking=False,
            )
        if new is None and old is not None:
            return SchemaChangeDiff(
                schema_id=old.id,
                added_fields=(),
                removed_fields=tuple(f.name for f in old.fields),
                changed_fields=(),
                breaking=True,
            )
        return _diff_entities(old, new)


__all__ = [
    "FieldDefinition",
    "SchemaChangeDiff",
    "SchemaEntity",
    "SchemaRegistry",
    "entity_from_model",
    "schema_fields_from_model",
]
