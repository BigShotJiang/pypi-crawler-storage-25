from dataclasses import dataclass, field


@dataclass
class KindDefinition:
    """
    A node kind definition. Kind definitions are themselves
    nodes in the graph (layer: schema, kind: schema_kind).
    This is the self-description principle: Forge's own
    schema is expressed using Forge's own primitives.
    """
    id: str                      # the kind name: "screen", "service"
    stack: str | None = None     # None = universal (all stacks)
    inherits: str | None = None  # parent kind (inherits its fields)
    description: str = ""
    required_meta: list[str] = field(default_factory=list)
    optional_meta: list[str] = field(default_factory=list)
    template: str | None = None  # scaffold template path

    def to_node(self) -> dict:
        """
        Returns a universal node dict for this kind definition.
        This is what appears in the schema layer of the graph.
        """
        return {
            "id": f"kind:{self.id}",
            "fqid": f"forge:kind:{self.id}",
            "kind": "schema_kind",
            "domain": "SCHEMA",
            "layer": "schema",
            "status": "implemented",
            "meta": {
                "kind_id": self.id,
                "stack": self.stack,
                "inherits": self.inherits,
                "description": self.description,
                "required_meta": self.required_meta,
                "optional_meta": self.optional_meta,
                "template": self.template,
            },
        }

    def inherits_from(
        self, registry: "KindRegistry"
    ) -> "KindDefinition | None":
        if not self.inherits:
            return None
        return registry.get(self.inherits)


# Stacks where WEB_KINDS are first-class manifest kinds (not aliases of module).
WEB_STACKS = frozenset({"web", "astro", "react"})

# Universal kinds — valid for any stack
UNIVERSAL_KINDS = [
    KindDefinition(
        id="module",
        description=(
            "Universal code unit — file-backed node (Python module, "
            "Astro component file, shared library, etc.)."
        ),
        optional_meta=["contracts", "role", "tier", "depends_on", "consumed_by"],
    ),
    KindDefinition(
        id="service",
        description="Stateless operations on one resource.",
        optional_meta=["endpoints", "clients"],
    ),
    KindDefinition(
        id="model",
        description="Data structure. No business logic.",
        optional_meta=["fields", "validators"],
    ),
    KindDefinition(
        id="controller",
        description="Business logic for one domain.",
        optional_meta=["actions", "events"],
    ),
    KindDefinition(
        id="command",
        description="CLI or MCP command entry point.",
        optional_meta=["params", "flags"],
    ),
    KindDefinition(
        id="middleware",
        inherits="service",
        description="Wraps another node. Intercepts inputs/outputs.",
        optional_meta=["wraps", "intercepts"],
    ),
    KindDefinition(
        id="protocol",
        inherits="service",
        description="Communication contract between nodes.",
        optional_meta=["methods", "events"],
    ),
    KindDefinition(
        id="pipeline",
        inherits="service",
        description="Sequential transformation stages.",
        optional_meta=["stages", "transforms"],
    ),
    KindDefinition(
        id="registry",
        inherits="service",
        description="Named, swappable implementations.",
        optional_meta=["registered_kinds"],
    ),
    KindDefinition(
        id="hook",
        description="Extension point. Augments an existing tool.",
        required_meta=["augments"],
    ),
    KindDefinition(
        id="glove",
        description="Source analysis for a specific stack.",
        required_meta=["stack"],
        optional_meta=["version"],
    ),
    KindDefinition(
        id="checker",
        description="Infrastructure health check.",
        required_meta=["handles"],
        optional_meta=["version"],
    ),
    KindDefinition(
        id="renderer",
        description="Graph output format.",
        required_meta=["format"],
        optional_meta=["version"],
    ),
    KindDefinition(
        id="subscriber",
        description="Event bus subscriber.",
        required_meta=["subscribes_to"],
        optional_meta=["version"],
    ),
    KindDefinition(
        id="schema_kind",
        description="A node kind definition. Self-referential.",
        required_meta=["kind_id"],
    ),
    KindDefinition(
        id="forge-extension",
        description=(
            "A project that extends Forge. Grants: hook nodes, "
            "cross-project edges, workspace_registration."
        ),
        optional_meta=["grants", "augments"],
    ),
]

# Flutter-specific kinds
FLUTTER_KINDS = [
    KindDefinition(
        id="screen",
        stack="flutter",
        inherits="controller",
        description="Router-only screen. ADR-019.",
        optional_meta=["variants", "route"],
    ),
    KindDefinition(
        id="variant",
        stack="flutter",
        description="UI variant of a screen or widget.",
        optional_meta=["parent"],
    ),
    KindDefinition(
        id="widget",
        stack="flutter",
        description="Reusable UI component.",
        optional_meta=["props"],
    ),
]

WEB_KINDS: list[KindDefinition] = [
    KindDefinition(
        id="component",
        stack="web",
        description="UI component — React, Astro, or framework-agnostic",
        optional_meta=["props", "slots", "variants", "styles"],
    ),
    KindDefinition(
        id="page",
        stack="web",
        description="Routable page or route handler",
        optional_meta=["route", "layout", "data_fetching"],
    ),
    KindDefinition(
        id="layout",
        stack="web",
        description="Page layout wrapper",
        optional_meta=["slots", "variants"],
    ),
    KindDefinition(
        id="route",
        stack="web",
        description="API route or endpoint",
        optional_meta=["method", "path", "middleware"],
    ),
    KindDefinition(
        id="content",
        stack="web",
        description="Content collection entry (Astro content collections)",
        optional_meta=["schema", "collection"],
    ),
]

ALL_KINDS = UNIVERSAL_KINDS + FLUTTER_KINDS + WEB_KINDS


class KindRegistry:
    """
    The registry of all valid node kinds.
    Self-describing: can produce schema-layer graph nodes
    for every registered kind.
    """

    def __init__(self):
        self._kinds: dict[str, KindDefinition] = {}

    def register(self, kind: KindDefinition) -> None:
        self._kinds[kind.id] = kind

    def get(self, kind_id: str) -> KindDefinition | None:
        return self._kinds.get(kind_id)

    def is_valid(self, kind_id: str) -> bool:
        return kind_id in self._kinds

    def is_valid_for_stack(self, kind_id: str, stack: str | None = None) -> bool:
        """Whether *kind_id* is allowed for *stack* (profile-aware when stack is set)."""
        kid = str(kind_id or "").strip()
        if not kid:
            return True
        stack_key = str(stack or "").strip().lower()
        if stack_key:
            return self.valid_for_stack(kid, stack_key)
        return self.get(kid) is not None

    def for_stack(self, stack_id: str) -> list[KindDefinition]:
        """Return kind definitions valid for a stack via StackProfileRegistry."""
        try:
            from forge.core.stack_profiles import get_stack_profile_registry

            reg = get_stack_profile_registry()
            profile = reg.get(stack_id)
            if profile and profile.node_kinds:
                kinds: list[KindDefinition] = []
                for kind_name in profile.node_kinds:
                    kd = self.get(kind_name)
                    if kd is not None:
                        kinds.append(kd)
                if kinds:
                    return kinds
        except Exception:
            pass
        stack_key = str(stack_id or "").strip().lower()
        return [
            k
            for k in self._kinds.values()
            if k.stack in (None, "universal", "", stack_key)
        ]

    def valid_for_stack(self, kind_name: str, stack_id: str) -> bool:
        """True if kind_name is valid for the given stack."""
        kid = str(kind_name or "").strip()
        if not kid:
            return True
        return any(k.id == kid for k in self.for_stack(stack_id))

    def all_kinds(self) -> list[str]:
        return list(self._kinds.keys())

    def schema_nodes(self) -> list[dict]:
        """
        Returns universal node dicts for all registered kinds.
        These populate the SCHEMA domain of the graph.
        """
        return [k.to_node() for k in self._kinds.values()]

    def resolve_template(
        self, kind_id: str, stack: str | None = None
    ) -> str | None:
        """
        Find the best template for this kind+stack combination.
        Fallback chain:
          1. Exact match: kind_id + stack
          2. Stack-agnostic: kind_id only
          3. Parent kind (if inherits is set)
          4. None (generic stub will be used)
        """
        kind = self.get(kind_id)
        if not kind:
            return None
        if kind.template:
            return kind.template
        # Try parent
        if kind.inherits:
            return self.resolve_template(kind.inherits, stack)
        return None


# Module-level singleton
_global_kind_registry = KindRegistry()
for _kind in ALL_KINDS:
    _global_kind_registry.register(_kind)


def get_kind_registry() -> KindRegistry:
    return _global_kind_registry
