from __future__ import annotations

import json
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from forge.tools.context.schema import DocNode


def forge_dir(project_path: Path) -> Path:
    d = project_path / ".forge"
    d.mkdir(parents=True, exist_ok=True)
    return d


def context_index_path(project_path: Path) -> Path:
    return forge_dir(project_path) / "context_index.json"


def load_raw_index(project_path: Path) -> dict[str, Any] | None:
    p = context_index_path(project_path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def doc_node_from_dict(d: dict[str, Any]) -> DocNode:
    es = d.get("extractable_sections")
    if es is None:
        es = d.get("sentinels") or {}
    return DocNode(
        id=str(d.get("id", "")),
        type=str(d.get("type", "")),
        path=str(d.get("path", "")),
        status=str(d.get("status", "")),
        last_updated=d.get("last_updated"),
        frontmatter=dict(d.get("frontmatter") or {}),
        extractable_sections=dict(es or {}),
        headings=list(d.get("headings") or []),
        project=d.get("project"),
    )


def save_index(
    project_path: Path,
    nodes: list[DocNode],
    *,
    stale: bool = False,
) -> None:
    built_at = datetime.now(timezone.utc).isoformat()
    payload = {
        "schema_version": 1,
        "built_at": built_at,
        "file_count": len(nodes),
        "stale": stale,
        "docs": [asdict(n) for n in nodes],
    }
    context_index_path(project_path).write_text(json.dumps(payload, indent=2), encoding="utf-8")


def index_staleness_report(project_path: Path) -> dict[str, Any]:
    """
    Returns metadata for `forge context --check`.
    Marks stale if any tracked .md is newer than built_at.
    """
    raw = load_raw_index(project_path)
    if not raw:
        return {
            "exists": False,
            "stale": True,
            "built_at": None,
            "file_count": 0,
            "modified_since": [],
            "message": "context_index: missing — run: forge context --rebuild-index",
        }
    built_at = raw.get("built_at")
    docs = raw.get("docs") or []
    modified: list[str] = []
    stale = False
    try:
        if built_at:
            bt = datetime.fromisoformat(built_at.replace("Z", "+00:00"))
            for d in docs:
                rel = d.get("path")
                if not rel:
                    continue
                fp = (project_path / rel).resolve()
                if not fp.exists():
                    stale = True
                    modified.append(f"{rel} (missing)")
                    continue
                mt = datetime.fromtimestamp(fp.stat().st_mtime, tz=timezone.utc)
                if mt > bt:
                    stale = True
                    modified.append(rel)
    except Exception:
        stale = True
    msg = (
        f"context_index: stale ({len(modified)} files modified since build)"
        if stale and modified
        else (
            "context_index: stale"
            if stale
            else f"context_index: fresh (built {built_at}, {len(docs)} files)"
        )
    )
    if stale:
        msg += " → run: forge context --rebuild-index"
    return {
        "exists": True,
        "stale": stale,
        "built_at": built_at,
        "file_count": len(docs),
        "modified_since": modified,
        "message": msg,
    }
