"""
forge/tools/context/agent_context_reader.py

Phase 8.5 — File-backed context reader for AGENT_CONTEXT.md.

Replaces dynamic build_bundle() assembly in handle_forge_context.
Reads the precomputed, deterministic docs/AGENT_CONTEXT.md produced
by forge/tools/manifest/context_generator.py.

Public API:
    load_agent_context(project_path) -> dict[str, dict[str, str]]
    resolve_context(scope, section, *, project_path, target=None) -> dict

Contract:
  - load_agent_context() is deterministic: same file = same output.
  - No transformations, no graph traversal, no dynamic assembly.
  - Exact content preserved as parsed from file.
  - On missing file or parse error: returns empty structure (never raises).
  - resolve_context() returns a dict ready to JSON-serialize as MCP response.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


# ── File locations ────────────────────────────────────────────────────────────

_AGENT_CONTEXT_JSON_PATH = ".forge/agent_context.json"

_AGENT_CONTEXT_PATHS = [
    "docs/AGENT_CONTEXT.md",
    "AGENT_CONTEXT.md",
]


def _locate_agent_context_json(project_path: Path) -> Path | None:
    p = project_path / _AGENT_CONTEXT_JSON_PATH
    return p if p.is_file() else None


def _locate_agent_context(project_path: Path) -> Path | None:
    for rel in _AGENT_CONTEXT_PATHS:
        p = project_path / rel
        if p.is_file():
            return p
    return None


# ── Parser ────────────────────────────────────────────────────────────────────

# Matches:  ## [scope:minimal]  or  ## [scope:local:some/symbol]
_SCOPE_RE = re.compile(r"^##\s+\[scope:([^\]]+)\]", re.MULTILINE)
# Matches:  ### [section:constraints]
_SECTION_RE = re.compile(r"^###\s+\[section:([^\]]+)\]", re.MULTILINE)


def load_agent_context_json(project_path: Path) -> dict[str, dict[str, Any]] | None:
    """Load .forge/agent_context.json — JSON fast path for MCP hot reads.

    Returns scopes dict in the same shape as load_agent_context():
        {scope_name: {section_name: <typed Python object>, ...}, ...}

    Values are typed Python objects (list, dict, str) — callers receive
    richer data than the YAML-string content from the Markdown path.

    Returns None if file absent or unparseable. Never raises.
    """
    root = Path(project_path).resolve()
    p = _locate_agent_context_json(root)
    if p is None:
        return None

    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None

    if not isinstance(data, dict):
        return None

    scopes = data.get("scopes")
    if not isinstance(scopes, dict):
        return None

    result: dict[str, dict[str, Any]] = {}
    for scope_name, sections in scopes.items():
        if isinstance(sections, dict):
            result[scope_name] = dict(sections)
    return result or None


def load_agent_context(project_path: Path) -> dict[str, dict[str, str]]:
    """Parse AGENT_CONTEXT.md into a nested dict.

    Returns:
        {
            "minimal": {
                "constraints": "<raw content string>",
                "known_broken": "<raw content string>",
                ...
            },
            "system": { ... },
            ...
        }

    Content strings are the exact text between section headers —
    no transformations applied. Includes code fences if present.

    Returns {} on missing file or any parse error (never raises).
    """
    root = Path(project_path).resolve()
    path = _locate_agent_context(root)
    if path is None:
        return {}

    try:
        text = path.read_text(encoding="utf-8")
    except Exception:
        return {}

    # Split into scope blocks by finding ## [scope:*] boundaries.
    scope_matches = list(_SCOPE_RE.finditer(text))
    if not scope_matches:
        return {}

    result: dict[str, dict[str, str]] = {}

    for i, scope_match in enumerate(scope_matches):
        scope_name = scope_match.group(1).strip()
        scope_start = scope_match.end()
        scope_end = scope_matches[i + 1].start() if i + 1 < len(scope_matches) else len(text)
        scope_body = text[scope_start:scope_end]

        # Split scope body into section blocks by ### [section:*] boundaries.
        section_matches = list(_SECTION_RE.finditer(scope_body))
        sections: dict[str, str] = {}

        for j, sec_match in enumerate(section_matches):
            sec_name = sec_match.group(1).strip()
            sec_start = sec_match.end()
            sec_end = section_matches[j + 1].start() if j + 1 < len(section_matches) else len(scope_body)
            # Strip leading/trailing whitespace but preserve internal structure exactly.
            sec_content = scope_body[sec_start:sec_end].strip()
            sections[sec_name] = sec_content

        result[scope_name] = sections

    return result


# ── Scope normaliser ──────────────────────────────────────────────────────────

def _normalise_scope(scope: str | None, target: str | None) -> str:
    """Map (scope, target) → scope key as stored in AGENT_CONTEXT.md.

    Scope keys in the file:
      "minimal"
      "system"
      "local:<symbol_id>"
      "implementation:<symbol_id>"
      "feature:<feature_id>"

    If scope is None → "minimal" (default session orient).
    If scope contains a known prefix, pass through unchanged.
    If target is given and scope is "local"|"implementation"|"feature",
    they are combined: "local:some/symbol".
    """
    if not scope:
        return "minimal"
    s = str(scope).strip()
    # Already qualified (e.g. "local:module/core.manifest") → pass through
    if ":" in s:
        return s
    # Unqualified scope + optional target
    if s in ("minimal", "system"):
        return s
    if target:
        return f"{s}:{target}"
    return s


# ── Resolver ──────────────────────────────────────────────────────────────────

def resolve_context(
    scope: str | None,
    section: str | None,
    *,
    project_path: Path,
    target: str | None = None,
) -> dict[str, Any]:
    """Select and return the exact slice from the agent context cache.

    Prefers .forge/agent_context.json (JSON fast path — typed objects,
    token-efficient for MCP). Falls back to docs/AGENT_CONTEXT.md for
    backwards compatibility.

    Args:
        scope:        Scope name: "minimal", "system", "local", etc.
                      If None → "minimal".
        section:      Section name within scope: "constraints", "graph", etc.
                      If None → returns all sections in scope as a dict.
        project_path: Project root — used to locate cache files.
        target:       Symbol ID for scoped lookups (e.g. "module/core.manifest").
                      Combined with scope as "local:<target>".

    Returns a dict ready to JSON-serialize. Never raises.
    """
    # Prefer JSON cache — richer types, no YAML parsing overhead
    ctx: dict[str, dict[str, Any]] | None = load_agent_context_json(project_path)
    source = "agent_context_json"

    if ctx is None:
        # Fall back to Markdown for backwards compatibility
        ctx = load_agent_context(project_path)  # type: ignore[assignment]
        source = "agent_context_file"

    effective_scope = _normalise_scope(scope, target)

    # Fallback: if requested scope not found, try "minimal"
    if effective_scope not in ctx:
        if effective_scope != "minimal" and "minimal" in ctx:
            effective_scope = "minimal"
        elif ctx:
            effective_scope = next(iter(ctx))
        else:
            return _fallback_response(scope, section, "agent context not found or empty")

    scope_data = ctx[effective_scope]

    if section:
        sec = str(section).strip()
        if sec in scope_data:
            return {
                "scope": effective_scope,
                "section": sec,
                "content": scope_data[sec],
                "source": source,
            }
        # Section not in this scope — return available sections list
        return {
            "scope": effective_scope,
            "section": sec,
            "content": None,
            "available_sections": sorted(scope_data.keys()),
            "source": source,
            "note": f"section '{sec}' not found in scope '{effective_scope}'",
        }

    # No section requested → return all sections in scope
    return {
        "scope": effective_scope,
        "sections": scope_data,
        "available_scopes": sorted(ctx.keys()),
        "source": source,
    }


def _fallback_response(scope: Any, section: Any, reason: str) -> dict[str, Any]:
    return {
        "scope": str(scope) if scope else "minimal",
        "section": str(section) if section else None,
        "content": None,
        "source": "agent_context_file",
        "error": reason,
    }


# ── Available scopes/sections (introspection) ─────────────────────────────────

def list_available(project_path: Path) -> dict[str, list[str]]:
    """Return {scope: [section, ...]} for all parsed scopes. Never raises."""
    ctx = load_agent_context(project_path)
    return {scope: sorted(sections.keys()) for scope, sections in ctx.items()}
