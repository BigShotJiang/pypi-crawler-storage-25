from __future__ import annotations

import fnmatch
from pathlib import Path
from datetime import date, datetime
from typing import Any, Iterator

import yaml

from forge.tools.context.cache import doc_node_from_dict, index_staleness_report, load_raw_index, save_index
from forge.tools.context.schema import DocNode
from forge.tools.context.sentinels import extract_sentinel


def parse_markdown_frontmatter(raw: str) -> tuple[dict[str, Any], str]:
    if not raw.lstrip().startswith("---"):
        return {}, raw
    text = raw.lstrip("\ufeff")
    if not text.startswith("---"):
        return {}, raw
    parts = text.split("---", 2)
    if len(parts) < 3:
        return {}, raw
    try:
        fm = yaml.safe_load(parts[1]) or {}
        if not isinstance(fm, dict):
            fm = {}
        body = parts[2].lstrip("\n")
        return fm, body
    except Exception:
        return {}, raw


def _slug_from_path(project_path: Path, file_path: Path) -> str:
    try:
        rel = file_path.resolve().relative_to(project_path.resolve())
        s = str(rel).replace("/", "_").replace("\\", "_")
        return s.removesuffix(".md").lower() or "doc"
    except Exception:
        return file_path.stem.lower() or "doc"


def _json_safe_metadata(obj: Any) -> Any:
    if isinstance(obj, (date, datetime)):
        return obj.isoformat()
    if isinstance(obj, dict):
        return {str(k): _json_safe_metadata(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_json_safe_metadata(x) for x in obj]
    return obj


def _depends_ids(fm: dict[str, Any]) -> list[str]:
    raw = fm.get("depends_on") or []
    if not isinstance(raw, list):
        return []
    out: list[str] = []
    for item in raw:
        if isinstance(item, str):
            out.append(item)
        elif isinstance(item, dict) and item.get("id"):
            out.append(str(item["id"]))
    return out


def _called_by_ids(fm: dict[str, Any]) -> list[str]:
    raw = fm.get("called_by") or []
    if not isinstance(raw, list):
        return []
    return [str(x) for x in raw if isinstance(x, (str, int, float))]


def _cooperates_ids(fm: dict[str, Any]) -> list[str]:
    raw = fm.get("cooperates_with") or []
    if not isinstance(raw, list):
        return []
    return [str(x) for x in raw if isinstance(x, (str, int, float))]


def _links_paths(fm: dict[str, Any]) -> list[str]:
    raw = fm.get("links_to") or []
    if not isinstance(raw, list):
        return []
    paths: list[str] = []
    for item in raw:
        if isinstance(item, dict) and item.get("path"):
            paths.append(str(item["path"]))
        elif isinstance(item, str):
            paths.append(item)
    return paths


SKIP_DIR_NAMES = {
    ".git",
    "node_modules",
    ".venv",
    "venv",
    "__pycache__",
    "dist",
    "build",
    ".tox",
    ".mypy_cache",
}


def _extractable_sections_from_frontmatter(fm: dict[str, Any], body: str) -> dict[str, str]:
    """
    Populated only from frontmatter unless `extractable_sections` is a list of
    legacy HTML block names to pull from the body (opt-in).
    """
    raw = fm.get("extractable_sections")
    if isinstance(raw, dict):
        return {str(k): str(v) for k, v in raw.items()}
    if isinstance(raw, list):
        out: dict[str, str] = {}
        for key in raw:
            if isinstance(key, str):
                val = extract_sentinel(body, key)
                if val is not None:
                    out[key] = val
        return out
    return {}


def _iter_markdown_files(project_path: Path) -> Iterator[Path]:
    root = project_path.resolve()
    for p in root.rglob("*.md"):
        if any(part in SKIP_DIR_NAMES for part in p.relative_to(root).parts):
            continue
        yield p


class FrontmatterIndex:
    """Queryable index of markdown docs with frontmatter + sentinels."""

    def __init__(self, project_path: Path) -> None:
        self.project_path = project_path.resolve()
        self._nodes: list[DocNode] = []
        self._by_id: dict[str, DocNode] = {}

    def build(self, use_cache: bool = True) -> FrontmatterIndex:
        if use_cache:
            raw = load_raw_index(self.project_path)
            if raw and raw.get("docs"):
                rep = index_staleness_report(self.project_path)
                if not rep.get("stale"):
                    self._nodes = [doc_node_from_dict(d) for d in raw["docs"]]
                    self._by_id = {n.id: n for n in self._nodes if n.id}
                    return self
        self._nodes = []
        self._by_id = {}
        for fp in _iter_markdown_files(self.project_path):
            try:
                raw_text = fp.read_text(encoding="utf-8")
            except Exception:
                continue
            fm, body = parse_markdown_frontmatter(raw_text)
            rel = str(fp.relative_to(self.project_path)).replace("\\", "/")
            doc_id = str(fm.get("id") or _slug_from_path(self.project_path, fp))
            dtype = str(fm.get("type") or "")
            status = str(fm.get("status") or "")
            last_updated = fm.get("last_updated")
            if last_updated is not None:
                last_updated = str(last_updated)
            proj = fm.get("project")
            proj_s = str(proj) if proj is not None else None
            node = DocNode(
                id=doc_id,
                type=dtype,
                path=rel,
                status=status,
                last_updated=last_updated,
                frontmatter=_json_safe_metadata(fm),
                extractable_sections=_extractable_sections_from_frontmatter(fm, body),
                headings=[],
                project=proj_s,
            )
            self._nodes.append(node)
            if doc_id:
                self._by_id.setdefault(doc_id, node)
        save_index(self.project_path, self._nodes, stale=False)
        return self

    @property
    def nodes(self) -> list[DocNode]:
        return list(self._nodes)

    def query(
        self,
        domains: list[str] | None = None,
        types: list[str] | None = None,
        id_pattern: str | None = None,
        phase: int | None = None,
        status: str | None = None,
        has_sentinel: str | None = None,
        depends_on: str | None = None,
    ) -> list[DocNode]:
        doms = [d.upper() for d in (domains or [])]
        tys = types or []
        out: list[DocNode] = []
        for n in self._nodes:
            fm = n.frontmatter
            if doms:
                raw_dom = fm.get("domains") or []
                if not isinstance(raw_dom, list):
                    raw_dom = []
                nd = {str(x).upper() for x in raw_dom}
                if not nd.intersection(set(doms)):
                    continue
            if tys and (n.type not in tys):
                continue
            if id_pattern and not fnmatch.fnmatch(n.id.lower(), id_pattern.lower()):
                continue
            if phase is not None:
                ph = fm.get("phase")
                try:
                    if int(ph) != int(phase):
                        continue
                except Exception:
                    continue
            if status and n.status != status:
                continue
            if has_sentinel:
                if has_sentinel not in n.extractable_sections:
                    continue
            if depends_on:
                if depends_on not in _depends_ids(fm):
                    continue
            out.append(n)
        return out

    def get(self, doc_id: str) -> DocNode | None:
        return self._by_id.get(doc_id)

    def get_dependents(self, doc_id: str) -> list[DocNode]:
        out: list[DocNode] = []
        for n in self._nodes:
            if doc_id in _depends_ids(n.frontmatter):
                out.append(n)
        return out

    def _direct_neighbor_ids(self, cur_id: str) -> list[str]:
        n = self.get(cur_id)
        if not n:
            return []
        fm = n.frontmatter
        nbrs: list[str] = []
        nbrs.extend(_depends_ids(fm))
        nbrs.extend(_called_by_ids(fm))
        nbrs.extend(_cooperates_ids(fm))
        for p in _links_paths(fm):
            hit = self._node_by_path(p)
            if hit:
                nbrs.append(hit.id)
        for dep in self.get_dependents(cur_id):
            nbrs.append(dep.id)
        # de-dupe preserve order
        return list(dict.fromkeys(x for x in nbrs if x))

    def get_related(self, doc_id: str, depth: int = 1) -> list[DocNode]:
        if depth < 1:
            return []
        seen: set[str] = {doc_id}
        frontier = [doc_id]
        collected: list[DocNode] = []
        for _ in range(depth):
            nxt: list[str] = []
            for cur in frontier:
                for nb in self._direct_neighbor_ids(cur):
                    if nb in seen:
                        continue
                    seen.add(nb)
                    node = self.get(nb)
                    if node:
                        collected.append(node)
                    nxt.append(nb)
            frontier = nxt
        return collected

    def _node_by_path(self, path: str) -> DocNode | None:
        path = path.replace("\\", "/").lstrip("./")
        for n in self._nodes:
            if n.path == path or n.path.endswith(path) or path.endswith(n.path):
                return n
        return None

    def traverse_manifest(self, manifest_path: Path, _seen: set[str] | None = None) -> list[DocNode]:
        if _seen is None:
            _seen = set()
        mp = manifest_path.resolve()
        key = str(mp)
        if key in _seen:
            return []
        _seen.add(key)
        if not mp.exists():
            return []
        from forge.core.manifest import ManifestParser
        from forge.core.manifest_document import ManifestDocument, project_root_for_manifest_file

        data: dict[str, Any] | None = None
        root_m = project_root_for_manifest_file(mp)
        if root_m is not None:
            try:
                doc = ManifestDocument.from_path(root_m)
                if doc.path.resolve() == mp.resolve():
                    data = doc.to_legacy_dict()
            except (FileNotFoundError, ValueError):
                pass
        if data is None:
            parsed = ManifestParser(mp).parse()
            if parsed.ok and isinstance(parsed.value, dict):
                data = parsed.value
        if not isinstance(data, dict):
            return []
        base = mp.parent
        paths: list[str] = []
        for key in ("screens", "hooks", "controllers", "services", "modules", "variants"):
            block = data.get(key)
            if isinstance(block, list):
                for row in block:
                    if isinstance(row, dict):
                        p = row.get("path") or row.get("file")
                        if p:
                            paths.append(str(p))
                    elif isinstance(row, str):
                        paths.append(row)
        out: list[DocNode] = []
        seen: set[str] = set()
        for p in paths:
            rel = (base / p).resolve()
            try:
                rel_s = str(rel.relative_to(self.project_path))
            except Exception:
                rel_s = p.replace("\\", "/")
            hit = self._node_by_path(rel_s) or self._node_by_path(p)
            if hit and hit.id not in seen:
                seen.add(hit.id)
                out.append(hit)
        for item in data.get("links_to") or []:
            if isinstance(item, dict) and item.get("path"):
                sub = base / str(item["path"])
                if sub.exists() and sub.suffix in (".yaml", ".yml"):
                    out.extend(self.traverse_manifest(sub, _seen))
        return out


def rebuild_index(project_path: Path) -> FrontmatterIndex:
    """Force rebuild and persist cache."""
    idx = FrontmatterIndex(project_path)
    idx.build(use_cache=False)
    return idx
