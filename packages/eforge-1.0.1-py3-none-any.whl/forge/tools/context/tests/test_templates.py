from __future__ import annotations

from pathlib import Path

import yaml

from forge.tools.context.index import FrontmatterIndex
from forge.tools.context.templates import (
    generate_template,
    list_templates,
    load_template,
    save_template,
)
from forge.tools.context.schema import TemplateSpec


def test_load_builtin_template(tmp_path: Path) -> None:
    spec = load_template("minimal", tmp_path)
    assert spec.name == "minimal"


def test_load_project_template_overrides_builtin(tmp_path: Path) -> None:
    d = tmp_path / ".forge" / "context-templates"
    d.mkdir(parents=True)
    (d / "minimal.yaml").write_text(
        yaml.safe_dump({"name": "minimal", "description": "proj", "level": "session"}),
        encoding="utf-8",
    )
    spec = load_template("minimal", tmp_path)
    assert spec.description == "proj"


def test_generate_template_for_feature(tmp_path: Path) -> None:
    (tmp_path / "docs").mkdir()
    (tmp_path / "composer_doc.md").write_text(
        "---\nid: composer_tool\ntype: tool\nlast_updated: 2026-01-01\n---\n",
        encoding="utf-8",
    )
    idx = FrontmatterIndex(tmp_path)
    idx.build(use_cache=False)
    spec = generate_template("genfeat", "composer", idx, tmp_path)
    assert spec.name == "genfeat"
    assert spec.query


def test_generate_template_saves_yaml(tmp_path: Path) -> None:
    idx = FrontmatterIndex(tmp_path)
    idx.build(use_cache=False)
    generate_template("saved", "auth", idx, tmp_path)
    assert (tmp_path / ".forge" / "context-templates" / "saved.yaml").exists()


def test_list_templates_shows_all_sources() -> None:
    rows = list_templates(None)
    assert any(r["source"] == "builtin" for r in rows)


def test_template_resolution_order(tmp_path: Path) -> None:
    d = tmp_path / ".forge" / "context-templates"
    d.mkdir(parents=True)
    (d / "minimal.yaml").write_text(
        yaml.safe_dump({"name": "minimal", "description": "win", "level": "session"}),
        encoding="utf-8",
    )
    spec = load_template("minimal", tmp_path)
    assert spec.description == "win"


def test_save_template_roundtrip(tmp_path: Path) -> None:
    p = tmp_path / "t.yaml"
    spec = TemplateSpec(name="t", description="d", level="session", max_items_per_list=3)
    save_template(spec, p)
    data = yaml.safe_load(p.read_text(encoding="utf-8"))
    assert data["name"] == "t"
