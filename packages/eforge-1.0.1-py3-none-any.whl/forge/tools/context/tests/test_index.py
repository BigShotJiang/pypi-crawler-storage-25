from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import yaml

from forge.tools.context.index import FrontmatterIndex, parse_markdown_frontmatter


def test_build_from_dir_with_frontmatter(tmp_path: Path) -> None:
    d = tmp_path / "docs"
    d.mkdir()
    (d / "a.md").write_text(
        dedent(
            """
            ---
            id: doc_a
            type: tool
            status: current
            last_updated: 2026-01-01
            domains: [AUTH]
            ---
            ## H2
            ### H3
            """
        ).strip(),
        encoding="utf-8",
    )
    idx = FrontmatterIndex(tmp_path)
    idx.build(use_cache=False)
    assert len(idx.nodes) >= 1
    assert idx.get("doc_a") is not None
    n = idx.get("doc_a")
    assert n is not None
    assert n.headings == []


def test_query_by_domain(tmp_path: Path) -> None:
    _write(tmp_path / "x.md", "dx", domains=["AUTH"])
    idx = FrontmatterIndex(tmp_path)
    idx.build(use_cache=False)
    r = idx.query(domains=["AUTH"])
    assert len(r) == 1


def test_query_by_type(tmp_path: Path) -> None:
    _write(tmp_path / "t.md", "tid", doc_type="tool")
    idx = FrontmatterIndex(tmp_path)
    idx.build(use_cache=False)
    assert len(idx.query(types=["tool"])) == 1


def test_query_by_id_pattern(tmp_path: Path) -> None:
    _write(tmp_path / "c.md", "composer_iron")
    idx = FrontmatterIndex(tmp_path)
    idx.build(use_cache=False)
    assert len(idx.query(id_pattern="composer*")) >= 1


def test_query_multiple_conditions_anded(tmp_path: Path) -> None:
    _write(tmp_path / "m.md", "m1", doc_type="tool", domains=["AUTH"], status="stub")
    idx = FrontmatterIndex(tmp_path)
    idx.build(use_cache=False)
    assert len(idx.query(types=["tool"], domains=["AUTH"], status="stub")) == 1
    assert len(idx.query(types=["tool"], status="current")) == 0


def test_get_dependents_traverses_graph(tmp_path: Path) -> None:
    _write(tmp_path / "core.md", "core", doc_type="tool")
    _write(
        tmp_path / "dep.md",
        "dep",
        extra={"depends_on": ["core"]},
    )
    idx = FrontmatterIndex(tmp_path)
    idx.build(use_cache=False)
    d = idx.get_dependents("core")
    assert len(d) == 1
    assert d[0].id == "dep"


def test_get_related_depth_1(tmp_path: Path) -> None:
    _write(tmp_path / "a.md", "a", extra={"cooperates_with": ["b"]})
    _write(tmp_path / "b.md", "b")
    idx = FrontmatterIndex(tmp_path)
    idx.build(use_cache=False)
    rel = idx.get_related("a", depth=1)
    assert any(n.id == "b" for n in rel)


def test_get_related_depth_2(tmp_path: Path) -> None:
    _write(tmp_path / "a.md", "a", extra={"depends_on": ["b"]})
    _write(tmp_path / "b.md", "b", extra={"depends_on": ["c"]})
    _write(tmp_path / "c.md", "c")
    idx = FrontmatterIndex(tmp_path)
    idx.build(use_cache=False)
    rel = idx.get_related("a", depth=2)
    ids = {n.id for n in rel}
    assert "b" in ids
    assert "c" in ids


def test_traverse_manifest_finds_screens(tmp_path: Path) -> None:
    (tmp_path / "lib").mkdir()
    (tmp_path / "lib" / "s.md").write_text(
        "---\nid: screen_x\ntype: ui_component\nlast_updated: 2026-01-01\n---\n",
        encoding="utf-8",
    )
    man = tmp_path / "manifest.yaml"
    man.write_text(
        yaml.safe_dump(
            {
                "schema_version": 1,
                "name": "p",
                "type": "flutter",
                "version": "1",
                "screens": [{"path": "lib/s.md", "name": "s"}],
            }
        ),
        encoding="utf-8",
    )
    idx = FrontmatterIndex(tmp_path)
    idx.build(use_cache=False)
    found = idx.traverse_manifest(man)
    assert any(n.id == "screen_x" for n in found)


def test_index_with_no_frontmatter_files(tmp_path: Path) -> None:
    (tmp_path / "plain.md").write_text("# Title\n", encoding="utf-8")
    idx = FrontmatterIndex(tmp_path)
    idx.build(use_cache=False)
    assert len(idx.nodes) >= 1
    n = idx.nodes[0]
    assert n.frontmatter == {} or "id" in n.__dict__


def _write(
    path: Path,
    doc_id: str,
    *,
    doc_type: str = "map",
    domains: list[str] | None = None,
    status: str = "current",
    extra: dict | None = None,
) -> None:
    fm = {
        "id": doc_id,
        "type": doc_type,
        "status": status,
        "last_updated": "2026-01-01",
    }
    if domains:
        fm["domains"] = domains
    if extra:
        fm.update(extra)
    body = "## Section\n"
    path.write_text("---\n" + yaml.safe_dump(fm) + "---\n" + body, encoding="utf-8")


def test_parse_frontmatter() -> None:
    fm, body = parse_markdown_frontmatter("---\na: 1\n---\nBody")
    assert fm.get("a") == 1
    assert body.startswith("Body")
