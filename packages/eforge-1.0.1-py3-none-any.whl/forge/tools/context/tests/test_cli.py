from __future__ import annotations

from pathlib import Path

from click.testing import CliRunner

from forge.cli import main


def test_context_feature_flag(tmp_path: Path) -> None:
    (tmp_path / "docs").mkdir()
    (tmp_path / "auth_doc.md").write_text(
        "---\nid: auth_x\ntype: tool\nlast_updated: 2026-01-01\ndomains: [AUTH]\n---\n",
        encoding="utf-8",
    )
    runner = CliRunner()
    r = runner.invoke(main, ["context", "--project-path", str(tmp_path)])
    assert r.exit_code == 0
    assert "forge_context" in r.output


def test_context_new_template(tmp_path: Path) -> None:
    runner = CliRunner()
    r = runner.invoke(
        main,
        ["context", "--project-path", str(tmp_path), "new-template", "nt", "--feature", "auth"],
    )
    assert r.exit_code == 0
    assert "Template saved" in r.output


def test_context_list_templates() -> None:
    runner = CliRunner()
    r = runner.invoke(main, ["context", "list-templates"])
    assert r.exit_code == 0
    assert "builtin" in r.output


def test_context_show_template() -> None:
    runner = CliRunner()
    r = runner.invoke(main, ["context", "show-template", "minimal"])
    assert r.exit_code == 0
    assert "minimal" in r.output


def test_context_add_extractions_dry_run(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "AGENT_CONTEXT.md").write_text(
        "---\ntype: agent_context\nid: ac\nlast_updated: 2026-01-01\n---\n"
        "## Active constraints\n\n- one\n\n## Known issues\n\n- bug\n",
        encoding="utf-8",
    )
    runner = CliRunner()
    r = runner.invoke(
        main,
        ["context", "--project-path", str(tmp_path), "add-extractions", "--dry-run"],
    )
    assert r.exit_code == 0
    assert "known_broken" in r.output


def test_context_rebuild_index(tmp_path: Path) -> None:
    (tmp_path / "z.md").write_text("---\nid: z\nlast_updated: 2026-01-01\n---\n", encoding="utf-8")
    runner = CliRunner()
    r = runner.invoke(main, ["context", "--project-path", str(tmp_path), "rebuild-index"])
    assert r.exit_code == 0
    assert (tmp_path / ".forge" / "context_index.json").exists()
