from forge.tools.context.sentinels import (
    extract_all_sentinels,
    extract_sentinel,
    has_sentinel,
    inject_sentinel,
    validate_sentinels,
)


def test_extract_present_block() -> None:
    md = """<!-- CONTEXT:constraints -->
- rule a
<!-- END:constraints -->
"""
    assert extract_sentinel(md, "constraints") == "- rule a"


def test_extract_missing_block_returns_none() -> None:
    assert extract_sentinel("hello", "constraints") is None


def test_extract_all_returns_dict() -> None:
    md = """<!-- CONTEXT:a -->
x
<!-- END:a -->
<!-- CONTEXT:b -->

<!-- END:b -->
"""
    d = extract_all_sentinels(md)
    assert d["a"] == "x"
    assert d["b"] == ""


def test_inject_new_block() -> None:
    base = "## Intro\n\nHello\n"
    out = inject_sentinel(base, "constraints", "- c1", after_section="## Intro")
    assert "CONTEXT:constraints" in out
    assert "- c1" in out


def test_inject_replaces_existing() -> None:
    base = """<!-- CONTEXT:constraints -->
old
<!-- END:constraints -->
"""
    out = inject_sentinel(base, "constraints", "new")
    assert "new" in out
    assert "old" not in out


def test_validate_unclosed_block() -> None:
    md = "<!-- CONTEXT:constraints -->\nno end"
    v = validate_sentinels(md)
    assert any(x["type"] == "unclosed" for x in v)


def test_validate_nested_blocks() -> None:
    md = """<!-- CONTEXT:a -->
<!-- CONTEXT:b -->
<!-- END:b -->
<!-- END:a -->
"""
    v = validate_sentinels(md)
    assert any(x["type"] == "nested" for x in v)


def test_sentinel_invisible_in_render() -> None:
    inner = "- item\n\n[link](x.md)"
    md = f"<!-- CONTEXT:x -->\n{inner}\n<!-- END:x -->"
    assert extract_sentinel(md, "x") == inner


def test_legacy_html_sentinels_still_work() -> None:
    """Regression guard: legacy HTML sentinel API remains callable."""
    md = "<!-- CONTEXT:constraints -->\n- rule\n<!-- END:constraints -->\n"
    assert extract_sentinel(md, "constraints") == "- rule"
    assert validate_sentinels(md) == []
