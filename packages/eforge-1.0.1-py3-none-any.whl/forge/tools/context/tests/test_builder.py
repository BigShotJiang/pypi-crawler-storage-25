from __future__ import annotations

import json
import time
from pathlib import Path

import yaml

from forge.tools.context.builder import (
    build_bundle,
    build_project,
    build_queried,
    extract_active_variants,
    extract_constraints_from_impact,
    extract_debug_flags,
    extract_feature_flags,
)
from forge.tools.context.index import FrontmatterIndex
from forge.tools.context.schema import TemplateSpec


def test_build_project_reads_manifest_yaml(tmp_path: Path) -> None:
    man = {
        "schema_version": 1,
        "name": "demo",
        "type": "python",
        "version": "1",
        "phases": {"current": 2, "upcoming": [{"phase": 2, "name": "Beta", "status": "in_progress"}]},
        "screens": [{"name": "Home", "domain": "UI"}],
        "controllers": [{"name": "AuthCtrl", "domain": "AUTH"}],
        "services": [{"name": "Api"}],
    }
    (tmp_path / "manifest.yaml").write_text(yaml.safe_dump(man), encoding="utf-8")
    pc = build_project(tmp_path)
    assert pc.name == "demo"
    assert pc.phase == "2"
    assert pc.phase_label == "Beta"
    assert pc.stack == "python-cli"
    assert "AUTH" in pc.domains
    assert "Home" in pc.screens


def test_build_project_reads_change_impact(tmp_path: Path) -> None:
    ci = {
        "schema_version": 1,
        "version": 1,
        "name": "p",
        "change_types": [
            {
                "id": "z",
                "severity": "normal",
                "triggers": {"file_patterns": ["a/**"]},
                "requires": {"files": [{"path": "docs/X.md"}]},
            },
            {
                "id": "b",
                "severity": "blocker",
                "triggers": {"file_patterns": ["lib/**"]},
                "requires": {"files": [{"path": "docs/Y.md", "headings_any": ["## H"]}]},
            },
        ],
    }
    (tmp_path / "change-impact.yaml").write_text(yaml.safe_dump(ci), encoding="utf-8")
    pc = build_project(tmp_path)
    assert "b" in pc.impact_rules
    assert any("lib/**" in c for c in pc.constraint_summary)
    assert pc.constraint_summary[0].startswith("Changing") or "lib/**" in pc.constraint_summary[0]


def test_build_project_reads_app_config(tmp_path: Path) -> None:
    cfg = {
        "ui_lab": {"active_variants": {"shell": "a"}},
        "features": {"composer": True, "off": False},
        "debug": {"verbose": True},
    }
    (tmp_path / "app_config.yaml").write_text(yaml.safe_dump(cfg), encoding="utf-8")
    pc = build_project(tmp_path)
    assert pc.active_variants.get("shell") == "a"
    assert pc.feature_flags.get("composer") is True
    assert pc.debug_flags.get("verbose") is True


def test_extract_constraints_from_impact(tmp_path: Path) -> None:
    p = tmp_path / "ci.yaml"
    p.write_text(
        yaml.safe_dump(
            {
                "change_types": [
                    {
                        "id": "x",
                        "severity": "high",
                        "triggers": {"file_patterns": ["*.dart"]},
                        "requires": {"files": [{"path": "docs/A.md"}]},
                    }
                ]
            }
        ),
        encoding="utf-8",
    )
    lines = extract_constraints_from_impact(p)
    assert len(lines) == 1
    assert "docs/A.md" in lines[0]


def test_extract_constraints_blockers_first(tmp_path: Path) -> None:
    p = tmp_path / "ci.yaml"
    p.write_text(
        yaml.safe_dump(
            {
                "change_types": [
                    {
                        "id": "n",
                        "severity": "normal",
                        "triggers": {"file_patterns": ["n/**"]},
                        "requires": {"files": []},
                    },
                    {
                        "id": "blk",
                        "severity": "blocker",
                        "triggers": {"file_patterns": ["b/**"]},
                        "requires": {"files": [{"path": "z.md"}]},
                    },
                ]
            }
        ),
        encoding="utf-8",
    )
    lines = extract_constraints_from_impact(p)
    assert "b/**" in lines[0]


def test_extract_active_variants(tmp_path: Path) -> None:
    p = tmp_path / "c.yaml"
    p.write_text(yaml.safe_dump({"ui_lab": {"active_variants": {"x": "y"}}}), encoding="utf-8")
    assert extract_active_variants(p) == {"x": "y"}


def test_extract_feature_flags(tmp_path: Path) -> None:
    p = tmp_path / "c.yaml"
    p.write_text(yaml.safe_dump({"features": {"a": True, "b": False}}), encoding="utf-8")
    assert extract_feature_flags(p)["a"] is True


def test_extract_debug_flags(tmp_path: Path) -> None:
    p = tmp_path / "c.yaml"
    p.write_text(yaml.safe_dump({"debug": {"d": True}}), encoding="utf-8")
    assert extract_debug_flags(p).get("d") is True


def test_build_project_known_broken_from_frontmatter(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "AGENT_CONTEXT.md").write_text(
        "---\ntype: agent_context\nknown_broken:\n  - REAL\n---\n\n## Known issues\n- WRONG\n",
        encoding="utf-8",
    )
    pc = build_project(tmp_path)
    assert pc.known_broken == ["REAL"]
    assert "WRONG" not in " ".join(pc.known_broken)


def test_build_project_known_broken_empty_if_missing(tmp_path: Path) -> None:
    pc = build_project(tmp_path)
    assert pc.known_broken == []


def test_build_project_never_parses_markdown_body(tmp_path: Path) -> None:
    test_build_project_known_broken_from_frontmatter(tmp_path)


def test_build_queried_with_domain_query(tmp_path: Path) -> None:
    (tmp_path / "d.md").write_text(
        "---\nid: x\ntype: tool\nlast_updated: 2026-01-01\ndomains: [AUTH]\n"
        "extractable_sections:\n  constraints: c1\n---\nbody\n",
        encoding="utf-8",
    )
    idx = FrontmatterIndex(tmp_path)
    idx.build(use_cache=False)
    spec = TemplateSpec(
        name="t",
        query={"domains": ["AUTH"]},
        extract_sentinels=["constraints"],
        include={"queried": True},
    )
    qr = build_queried(idx, spec, tmp_path)
    assert qr is not None
    assert "x" in qr.matched_docs
    assert "constraints" in qr.sentinels
    assert "c1" in qr.sentinels["constraints"]


def test_build_queried_no_results(tmp_path: Path) -> None:
    idx = FrontmatterIndex(tmp_path)
    idx.build(use_cache=False)
    spec = TemplateSpec(name="t", query={"domains": ["ZZZNONE"]}, include={"queried": True})
    qr = build_queried(idx, spec, tmp_path)
    assert qr is not None
    assert qr.matched_docs == []


def test_build_bundle_with_feature_scope(tmp_path: Path) -> None:
    (tmp_path / "auth_doc.md").write_text(
        "---\nid: auth_x\ntype: tool\nlast_updated: 2026-01-01\ndomains: [AUTH]\n---\n",
        encoding="utf-8",
    )
    b = build_bundle(project_path=tmp_path, template="feature", feature_scope="auth")
    assert "FORGE-CONTEXT" in b.markdown
    assert b.queried is not None


def test_build_bundle_composer_template(tmp_path: Path) -> None:
    b = build_bundle(project_path=tmp_path, template="composer")
    assert "FORGE-CONTEXT" in b.markdown


def test_builder_never_raises(tmp_path: Path) -> None:
    b = build_bundle(project_path=tmp_path, template="__no_such_template__")
    assert "FORGE-CONTEXT" in b.markdown
    assert "non-fatal" in b.markdown.lower() or "failed" in b.markdown.lower()


def test_stale_index_triggers_rebuild(tmp_path: Path) -> None:
    (tmp_path / "a.md").write_text("---\nid: a\nlast_updated: 2026-01-01\n---\n", encoding="utf-8")
    idx = FrontmatterIndex(tmp_path)
    idx.build(use_cache=False)
    cache_p = tmp_path / ".forge" / "context_index.json"
    assert cache_p.exists()
    data = json.loads(cache_p.read_text(encoding="utf-8"))
    built = data["built_at"]
    p = tmp_path / "a.md"
    t = time.time() + 30
    import os

    os.utime(p, (t, t))
    idx2 = FrontmatterIndex(tmp_path)
    idx2.build(use_cache=True)
    data2 = json.loads(cache_p.read_text(encoding="utf-8"))
    assert data2["built_at"] != built or len(idx2.nodes) >= len(idx.nodes)
