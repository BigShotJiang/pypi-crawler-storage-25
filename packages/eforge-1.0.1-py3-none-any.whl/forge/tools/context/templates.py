from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

from forge.tools.context.schema import TemplateSpec
from forge.tools.init_docs.config import resolve_template_path

BUILTIN_DIR = Path(__file__).resolve().parent / "builtin_templates"


def _safe_load_yaml(path: Path) -> dict[str, Any]:
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _spec_from_dict(d: dict[str, Any]) -> TemplateSpec:
    q = d.get("query")
    if q is not None and not isinstance(q, dict):
        q = None
    fm = d.get("from_manifests")
    if not isinstance(fm, list):
        fm = []
    es = d.get("extract_sentinels")
    if not isinstance(es, list):
        es = []
    inc = d.get("include")
    if not isinstance(inc, dict):
        inc = {}
    return TemplateSpec(
        name=str(d.get("name", "unnamed")),
        description=str(d.get("description", "")),
        level=str(d.get("level", "session")),
        query=q,
        from_manifests=[str(x) for x in fm],
        extract_sentinels=[str(x) for x in es],
        include=inc,
        max_items_per_list=int(d.get("max_items_per_list") or 10),
        feature_scope=d.get("feature_scope"),
    )


def _collect_template_files(project_path: Path | None) -> dict[str, Path]:
    """
    Resolution order load 3 → 2 → 1; last path wins per stem (project overrides).
    """
    by_name: dict[str, Path] = {}
    for p in sorted(BUILTIN_DIR.glob("*.yaml")):
        by_name[p.stem] = p
    try:
        canon_root = resolve_template_path() / "context-templates"
        if canon_root.is_dir():
            for p in sorted(canon_root.glob("*.yaml")):
                by_name[p.stem] = p
    except Exception:
        pass
    if project_path:
        proj_dir = Path(project_path).resolve() / ".forge" / "context-templates"
        if proj_dir.is_dir():
            for p in sorted(proj_dir.glob("*.yaml")):
                by_name[p.stem] = p
    return by_name


def load_template(name: str, project_path: Path | None = None) -> TemplateSpec:
    files = _collect_template_files(project_path)
    if name not in files:
        raise FileNotFoundError(f"context template not found: {name}")
    return _spec_from_dict(_safe_load_yaml(files[name]))


def save_template(spec: TemplateSpec, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    d: dict[str, Any] = {
        "name": spec.name,
        "description": spec.description,
        "level": spec.level,
        "query": spec.query,
        "from_manifests": spec.from_manifests,
        "extract_sentinels": spec.extract_sentinels,
        "include": spec.include,
        "max_items_per_list": spec.max_items_per_list,
    }
    if spec.feature_scope is not None:
        d["feature_scope"] = spec.feature_scope
    path.write_text(yaml.safe_dump(d, sort_keys=False, allow_unicode=True), encoding="utf-8")


SCOPE_HINT_DOMAINS: dict[str, list[str]] = {
    "auth": ["AUTH"],
    "composer": ["COMPOSER", "DOCS", "SCAFFOLD"],
    "lobby": ["LOBBY"],
    "pulse-migration": ["MIGRATION", "PULSE"],
    "scaffold": ["SCAFFOLD"],
}


def generate_template(
    name: str,
    feature_scope: str,
    index: Any,
    project_path: Path,
) -> TemplateSpec:
    """Procedurally generate a template from index signals."""
    from forge.tools.context.index import FrontmatterIndex

    assert isinstance(index, FrontmatterIndex)
    scope = feature_scope.strip().lower()
    id_pat = f"{scope}*"
    doms = SCOPE_HINT_DOMAINS.get(scope, [])
    matched = index.query(domains=doms if doms else None, id_pattern=id_pat)
    if not matched:
        matched = index.query(
            types=["tool", "ui_component", "manifest"],
            id_pattern=id_pat,
        )
    sentinel_names: set[str] = set()
    for n in matched:
        sentinel_names.update(n.extractable_sections.keys())
    manifest_paths: set[str] = set()
    for n in matched:
        fm = n.frontmatter
        raw = fm.get("links_to") or []
        if isinstance(raw, list):
            for item in raw:
                if isinstance(item, dict):
                    p = item.get("path")
                    if p and str(p).endswith((".yaml", ".yml")):
                        manifest_paths.add(str(p))
    spec = TemplateSpec(
        name=name,
        description=f"Auto-generated context template for `{feature_scope}`",
        level="task",
        query={
            "id_pattern": id_pat,
            "domains": doms,
        },
        from_manifests=sorted(manifest_paths),
        extract_sentinels=sorted(sentinel_names) or ["constraints", "known-broken"],
        include={
            "global": ["skills_available"],
            "project": ["name", "phase_label", "domains"],
            "session": ["this_session"],
            "queried": True,
        },
        max_items_per_list=15,
        feature_scope=feature_scope,
    )
    out_dir = project_path / ".forge" / "context-templates"
    out_dir.mkdir(parents=True, exist_ok=True)
    save_template(spec, out_dir / f"{name}.yaml")
    return spec


def list_templates(project_path: Path | None = None) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    # builtin
    for p in sorted(BUILTIN_DIR.glob("*.yaml")):
        d = _safe_load_yaml(p)
        rows.append(
            {
                "name": p.stem,
                "source": "builtin",
                "description": str(d.get("description", "")),
                "level": str(d.get("level", "")),
                "path": str(p),
            }
        )
        seen.add(p.stem)
    # canonical
    try:
        canon = resolve_template_path() / "context-templates"
        if canon.is_dir():
            for p in sorted(canon.glob("*.yaml")):
                d = _safe_load_yaml(p)
                rows.append(
                    {
                        "name": p.stem,
                        "source": "canonical",
                        "description": str(d.get("description", "")),
                        "level": str(d.get("level", "")),
                        "path": str(p),
                    }
                )
                seen.add(p.stem)
    except Exception:
        pass
    if project_path:
        proj = Path(project_path).resolve() / ".forge" / "context-templates"
        if proj.is_dir():
            for p in sorted(proj.glob("*.yaml")):
                d = _safe_load_yaml(p)
                rows.append(
                    {
                        "name": p.stem,
                        "source": "project",
                        "description": str(d.get("description", "")),
                        "level": str(d.get("level", "")),
                        "path": str(p),
                    }
                )
                seen.add(p.stem)
    return rows


def template_yaml_text(name: str, project_path: Path | None = None) -> str:
    files = _collect_template_files(project_path)
    if name not in files:
        raise FileNotFoundError(name)
    return files[name].read_text(encoding="utf-8")
