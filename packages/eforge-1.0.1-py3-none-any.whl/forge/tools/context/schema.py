from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class DocNode:
    id: str
    type: str
    path: str
    status: str
    last_updated: str | None
    frontmatter: dict[str, Any]
    extractable_sections: dict[str, str]
    headings: list[str]
    project: str | None


@dataclass
class QueryResult:
    query: dict[str, Any]
    matched_docs: list[str]
    sentinels: dict[str, list[str]]
    manifest_entries: list[dict[str, Any]]


@dataclass
class ProjectContext:
    """YAML-primary + frontmatter-only machine context for a project."""

    name: str
    phase: str | None
    phase_label: str | None
    phase_override: str | None
    stack: str | None
    domains: list[str]
    screens: list[str]
    controllers: list[str]
    services: list[str]
    active_variants: dict[str, str]
    feature_flags: dict[str, bool]
    debug_flags: dict[str, bool]
    impact_rules: list[str]
    constraint_summary: list[str]
    adr_constraints: list[str]
    known_broken: list[str]
    next_action: str | None = None
    blocker: str | None = None
    current_task: str | None = None


@dataclass
class TaskContext:
    """Task / scan slice for FORGE-CONTEXT (optional validation.json + cache)."""

    severed_connections: int = 0
    orphan_count: int = 0
    drift_count: int = 0
    scan_age: str = "never"
    impact_status: str = "—"
    impact_age: str = "—"


@dataclass
class TemplateSpec:
    name: str
    description: str = ""
    level: str = "session"
    query: dict[str, Any] | None = None
    from_manifests: list[str] = field(default_factory=list)
    extract_sentinels: list[str] = field(default_factory=list)
    include: dict[str, Any] = field(default_factory=dict)
    max_items_per_list: int = 10
    feature_scope: str | None = None


@dataclass
class ContextBundle:
    """Rendered mechanical context for agents."""

    markdown: str
    template_name: str
    level: str
    project_path: str
    global_section: dict[str, Any] = field(default_factory=dict)
    project_section: dict[str, Any] = field(default_factory=dict)
    session_section: dict[str, Any] = field(default_factory=dict)
    task_section: dict[str, Any] = field(default_factory=dict)
    queried: QueryResult | None = None
    project_context: ProjectContext | None = None
    graph_section: dict[str, Any] | None = None

    def to_yaml_minimal(self, section: str | None = None) -> dict:
        pc = self.project_context
        project_name = getattr(pc, "name", None)
        project_phase = getattr(pc, "phase", None)
        project_stack = getattr(pc, "stack", None)
        project_known_broken = list(getattr(pc, "known_broken", []) or [])[:10]
        project_domains = list(getattr(pc, "domains", []) or [])[:10]
        constraints = list(getattr(pc, "constraint_summary", []) or [])[:10]

        task_obj = getattr(self, "task", None)
        task_section = self.task_section or {}
        # Phase 3: scan_age_days comes from graph cache built_at (graph_section) when not on task_obj
        scan_age_days = getattr(task_obj, "scan_age_days", None)
        if scan_age_days is None:
            scan_age_days = (self.graph_section or {}).get("scan_age_days")
        severed = getattr(task_obj, "severed", task_section.get("severed_connections", 0))
        orphans = getattr(task_obj, "orphans", task_section.get("orphans", task_section.get("orphan_count", 0)))
        drift_items = getattr(task_obj, "drift_items", task_section.get("drift_items", task_section.get("drift_count", 0)))

        graph_obj = getattr(self, "graph", None)
        graph_section = self.graph_section or {}
        node_count = getattr(graph_obj, "node_count", graph_section.get("node_count", 0))
        edge_count = getattr(graph_obj, "edge_count", graph_section.get("edge_count", 0))
        graph_domains = list(getattr(graph_obj, "domains", graph_section.get("domains", []) or []))[:10]

        task_payload: dict[str, Any] = {
            "scan_age_days": scan_age_days,
            "severed": severed,
            "orphans": orphans,
            "drift_items": drift_items,
        }

        if section:
            s = str(section).strip()
            if s == "known_broken":
                return {"known_broken": project_known_broken}
            if s == "phase":
                return {"phase": project_phase, "stack": project_stack}
            if s == "tasks":
                return {"tasks": task_payload}
            if s == "session":
                return {"session": dict(self.session_section or {})}
            if s == "adr":
                return {"adr": list(getattr(pc, "adr_constraints", []) or []) if pc else []}
            if s == "variants":
                return {"variants": dict(getattr(pc, "active_variants", {}) or {}) if pc else {}}

        spine: dict[str, Any] = {
            "project": {
                "name": project_name,
                "phase": project_phase,
                "stack": project_stack,
                "known_broken": project_known_broken,
                "domains": project_domains,
            },
            "constraints": constraints,
            "task": task_payload,
            "graph": {
                "node_count": node_count,
                "edge_count": edge_count,
                "domains": graph_domains,
            },
            "available_sections": [
                "constraints",
                "graph",
                "session",
                "tasks",
                "adr",
                "variants",
                "known_broken",
                "phase",
            ],
        }
        if section and section in spine:
            return {section: spine[section]}
        return spine

    def to_markdown(
        self,
        spec: TemplateSpec,
        global_s: dict[str, Any],
        session_s: dict[str, Any],
        task_s: dict[str, Any],
        queried: QueryResult | None,
    ) -> str:
        """Render full FORGE-CONTEXT document (YAML-primary project narrative)."""
        import yaml

        lines: list[str] = [
            "<!-- FORGE-CONTEXT -->",
            "",
            f"<!-- Template: {spec.name} | level: {spec.level} -->",
            "",
            "<!-- SECTION:global -->",
            "```yaml",
            yaml.safe_dump(global_s, sort_keys=False, allow_unicode=True).strip(),
            "```",
            "",
            "<!-- SECTION:project -->",
        ]
        pc = self.project_context
        if pc:
            feats = {k: v for k, v in pc.feature_flags.items() if v}
            lines.extend(
                [
                    f"**Project:** {pc.name}",
                    f"**Phase:** {pc.phase or '—'} — {pc.phase_label or '—'}",
                    f"**Stack:** {pc.stack or '—'}",
                    f"**Domains:** {', '.join(pc.domains) if pc.domains else '—'}",
                    f"**Variants:** {pc.active_variants or '—'}",
                    f"**Features (enabled):** {feats or '—'}",
                    "",
                    "**Architectural constraints:**",
                ]
            )
            if pc.constraint_summary:
                for c in pc.constraint_summary:
                    lines.append(f"  - {c}")
            else:
                lines.append("  - (none parsed from legacy change-impact.yaml)")
            lines.extend(["", "**Known broken:**"])
            if pc.known_broken:
                for kb in pc.known_broken:
                    lines.append(f"  - {kb}")
            else:
                lines.append("  - (none — set `known_broken` in AGENT_CONTEXT.md frontmatter)")
            if pc.phase_override is not None:
                lines.extend(["", f"**Phase override (frontmatter):** {pc.phase_override}"])
            if pc.adr_constraints:
                lines.extend(["", "**ADR constraints:**"])
                for a in pc.adr_constraints:
                    lines.append(f"  - {a}")
        else:
            lines.append("_Project context unavailable._")
        lines.extend(["", "<!-- END:SECTION:project -->", "", "<!-- SECTION:session -->"])
        lines.extend(
            [
                "```yaml",
                yaml.safe_dump(session_s, sort_keys=False, allow_unicode=True).strip(),
                "```",
                "",
                "<!-- SECTION:task -->",
                f"**Scan:** {task_s.get('scan_age', 'never')}",
                f"**Severed connections:** {task_s.get('severed_connections', 0)} "
                f"(run: `forge scan --check` for details)",
                f"**Orphans:** {task_s.get('orphan_count', 0)}",
                f"**Drift items:** {task_s.get('drift_count', 0)}",
                f"**Impact check:** {task_s.get('impact_status', '—')} — {task_s.get('impact_age', '—')}",
                "",
            ]
        )
        if queried:
            lines.extend(
                [
                    "<!-- SECTION:queried -->",
                    "```yaml",
                    yaml.safe_dump(
                        {
                            "query": queried.query,
                            "matched_docs": queried.matched_docs,
                            "matched_extractable_sections": queried.sentinels,
                            "manifest_entries": queried.manifest_entries,
                        },
                        sort_keys=False,
                        allow_unicode=True,
                    ).strip(),
                    "```",
                    "",
                ]
            )
        if self.graph_section:
            lines.extend(
                [
                    "<!-- SECTION:graph -->",
                    "```yaml",
                    yaml.safe_dump(self.graph_section, sort_keys=False, allow_unicode=True).strip(),
                    "```",
                    "",
                ]
            )
        lines.append("<!-- END:FORGE-CONTEXT -->")
        return "\n".join(lines)
