from __future__ import annotations

from pathlib import Path

import yaml

from forge.tools.context.index import parse_markdown_frontmatter


def _normalize_type(raw: str) -> str:
    return str(raw or "").lower().replace("-", "_")


def run_add_extractions(
    project: Path,
    *,
    dry_run: bool = False,
    docs_only: bool = True,
) -> tuple[int, int]:
    """
    Walk markdown under docs/. For agent_context, map, internals without
    `known_broken` in frontmatter, add `known_broken: []`.
    Returns (files_changed, fields_added).
    """
    root = project.resolve()
    scan_root = (root / "docs") if docs_only and (root / "docs").is_dir() else root
    files_changed = 0
    fields_added = 0

    for path in scan_root.rglob("*.md"):
        if "node_modules" in path.parts or ".git" in path.parts:
            continue
        try:
            raw = path.read_text(encoding="utf-8")
        except Exception:
            continue
        if not raw.lstrip().startswith("---"):
            continue
        fm, body = parse_markdown_frontmatter(raw)
        dtype = _normalize_type(str(fm.get("type", "")))
        if dtype not in ("agent_context", "map", "internals"):
            continue
        if "known_broken" in fm:
            continue
        fields_added += 1
        if dry_run:
            files_changed += 1
            continue
        fm2 = dict(fm)
        fm2["known_broken"] = []
        new_fm = yaml.safe_dump(fm2, sort_keys=False, allow_unicode=True)
        new_text = f"---\n{new_fm}---\n{body}"
        path.write_text(new_text, encoding="utf-8")
        files_changed += 1
    return files_changed, fields_added
