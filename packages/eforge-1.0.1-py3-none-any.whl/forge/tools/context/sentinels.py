from __future__ import annotations

# LEGACY: HTML sentinel extraction (`<!-- CONTEXT:name -->` … `<!-- END:name -->`).
# Kept for backward compatibility and opt-in `extractable_sections: [name]` in
# frontmatter. `forge context` no longer uses these as the primary extraction
# method — use YAML (manifest, change-impact, app_config, adr_registry) and
# frontmatter fields such as `known_broken` instead.
# DEPRECATED (forge 2.0 target): sentinel-based extraction is
# legacy opt-in only. New code should use YAML frontmatter
# extractable_sections dict. See ADR-007.
# Do not remove until FrontmatterIndex backward-compat path
# is replaced. Gate: forge 2.0 / sentinel sunset task.

import re
from typing import Any

# Standard / reserved block names (others trigger validate warning only)
RESERVED_BLOCK_NAMES: frozenset[str] = frozenset(
    {
        "constraints",
        "known-broken",
        "phase-status",
        "api-surface",
        "dependencies",
        "owned-by",
        "error-codes",
        "next-actions",
    }
)

_START = re.compile(r"<!--\s*CONTEXT:([a-z0-9-]+)\s*-->")
_END = re.compile(r"<!--\s*END:([a-z0-9-]+)\s*-->")


def extract_sentinel(content: str, block_name: str) -> str | None:
    """
    Extract content of a named sentinel block.
    Returns None if block not present.
    Returns empty string if block present but empty.
    Strips leading/trailing whitespace.
    Never raises.
    """
    try:
        lines = content.splitlines()
        i = 0
        while i < len(lines):
            m = _START.match(lines[i].strip())
            if m and m.group(1) == block_name:
                i += 1
                buf: list[str] = []
                while i < len(lines):
                    em = _END.match(lines[i].strip())
                    if em and em.group(1) == block_name:
                        return "\n".join(buf).strip()
                    buf.append(lines[i])
                    i += 1
                return None
            i += 1
        return None
    except Exception:
        return None


def extract_all_sentinels(content: str) -> dict[str, str]:
    """Extract all sentinel blocks from content. Returns {block_name: content} dict."""
    out: dict[str, str] = {}
    try:
        lines = content.splitlines()
        i = 0
        while i < len(lines):
            m = _START.match(lines[i].strip())
            if m:
                name = m.group(1)
                i += 1
                buf: list[str] = []
                while i < len(lines):
                    em = _END.match(lines[i].strip())
                    if em:
                        if em.group(1) == name:
                            out[name] = "\n".join(buf).strip()
                        i += 1
                        break
                    buf.append(lines[i])
                    i += 1
                continue
            i += 1
    except Exception:
        pass
    return out


def has_sentinel(content: str, block_name: str) -> bool:
    """Check if a sentinel block exists."""
    return extract_sentinel(content, block_name) is not None


def inject_sentinel(
    content: str,
    block_name: str,
    block_content: str,
    after_section: str | None = None,
) -> str:
    """
    Insert or replace a sentinel block.
    If block exists: replace its content.
    If not: insert after after_section heading or at end of file if not found.
    """
    try:
        lines = content.splitlines(keepends=True)
        # Replace existing
        text = "".join(lines)
        if has_sentinel(text, block_name):
            return _replace_sentinel_inner(text, block_name, block_content)

        insertion = (
            f"<!-- CONTEXT:{block_name} -->\n{block_content.rstrip()}\n<!-- END:{block_name} -->\n"
        )
        if not after_section:
            if text and not text.endswith("\n"):
                text += "\n"
            return text + ("\n" if text and not text.endswith("\n") else "") + insertion

        needle = after_section.strip()
        idx = -1
        for i, line in enumerate(lines):
            stripped = line.strip()
            if stripped.lower().startswith(needle.lower()):
                idx = i
                break
        if idx < 0:
            if text and not text.endswith("\n"):
                text += "\n"
            return text + "\n" + insertion

        # Insert after the section body: find next H2 (## not ###)
        j = idx + 1
        while j < len(lines):
            s = lines[j].strip()
            if s.startswith("##") and not s.startswith("###"):
                break
            j += 1
        new_lines = lines[:j] + [insertion if insertion.endswith("\n") else insertion + "\n"] + lines[j:]
        return "".join(new_lines)
    except Exception:
        return content


def _replace_sentinel_inner(content: str, block_name: str, block_content: str) -> str:
    lines = content.splitlines(keepends=True)
    out: list[str] = []
    i = 0
    replaced = False
    while i < len(lines):
        m = _START.match(lines[i].strip())
        if m and m.group(1) == block_name:
            out.append(lines[i])
            i += 1
            inner = block_content.rstrip() + ("\n" if block_content else "")
            if inner and not inner.endswith("\n"):
                inner += "\n"
            while i < len(lines):
                em = _END.match(lines[i].strip())
                if em and em.group(1) == block_name:
                    out.append(inner)
                    out.append(lines[i])
                    i += 1
                    replaced = True
                    break
                i += 1
            continue
        out.append(lines[i])
        i += 1
    if not replaced:
        return content
    return "".join(out)


def validate_sentinels(content: str) -> list[dict[str, Any]]:
    """
    Check for malformed sentinels.
    Returns list of {type, block, line, message} dicts.
    """
    issues: list[dict[str, Any]] = []
    try:
        lines = content.splitlines()
        stack: list[tuple[str, int]] = []
        for lineno, line in enumerate(lines, start=1):
            sm = _START.match(line.strip())
            if sm:
                name = sm.group(1)
                if stack:
                    issues.append(
                        {
                            "type": "nested",
                            "block": name,
                            "line": lineno,
                            "message": f"nested CONTEXT:{name} inside CONTEXT:{stack[-1][0]}",
                        }
                    )
                stack.append((name, lineno))
                if name not in RESERVED_BLOCK_NAMES:
                    issues.append(
                        {
                            "type": "unknown_name",
                            "block": name,
                            "line": lineno,
                            "message": f"unknown block name `{name}` (not in standard set)",
                        }
                    )
                continue
            em = _END.match(line.strip())
            if em:
                ename = em.group(1)
                if not stack:
                    issues.append(
                        {
                            "type": "orphan_end",
                            "block": ename,
                            "line": lineno,
                            "message": f"END:{ename} without matching START",
                        }
                    )
                else:
                    open_name, _ = stack.pop()
                    if open_name != ename:
                        issues.append(
                            {
                                "type": "mismatched_end",
                                "block": ename,
                                "line": lineno,
                                "message": f"END:{ename} closes CONTEXT:{open_name}",
                            }
                        )
        for name, lineno in stack:
            issues.append(
                {
                    "type": "unclosed",
                    "block": name,
                    "line": lineno,
                    "message": f"CONTEXT:{name} never closed with END:{name}",
                }
            )
    except Exception as exc:
        issues.append({"type": "parse_error", "block": "", "line": 0, "message": str(exc)})
    return issues
