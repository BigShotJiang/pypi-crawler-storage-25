from __future__ import annotations

import dataclasses
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from forge.core.manifest import ManifestParser
from forge.core.manifest_document import ManifestDocument, project_root_for_manifest_file
from forge.core.manifest_path import manifest_candidates
from forge.tools.context.index import FrontmatterIndex, parse_markdown_frontmatter, rebuild_index
from forge.tools.context.schema import (
    ContextBundle,
    ProjectContext,
    QueryResult,
    TaskContext,
    TemplateSpec,
)
from forge.tools.context.templates import load_template


def resolve_project_path(project_id: str) -> Path | None:
    """Resolve project slug via merged workspace sources and fallbacks."""
    from forge.tools.workspace_store import resolve_project_path as _resolve

    return _resolve(project_id)


def _truncate_list(items: list[Any], max_n: int) -> list[Any]:
    if max_n <= 0:
        return []
    return items[:max_n]


def _manifest_paths(project_path: Path) -> list[Path]:
    return manifest_candidates(project_path)


def _change_impact_paths(project_path: Path) -> list[Path]:
    # DEPRECATED: change-impact.yaml — use .forge/impact-rules.yaml via _load_rules()
    # This path preserved for backward compat only (context bundle display IDs).
    return [
        project_path / ".forge" / "change-impact.yaml",
        project_path / "change-impact.yaml",
        project_path / "docs" / "change-impact.yaml",
    ]


def _adr_registry_paths(project_path: Path) -> list[Path]:
    return [
        project_path / "docs" / "adr" / "adr_registry.yaml",
        project_path / "docs" / "adr_registry.yaml",
    ]


def _app_config_paths(project_path: Path) -> list[Path]:
    return [
        project_path / "assets" / "app_config.yaml",
        project_path / "app_config.yaml",
        project_path / "config" / "app_config.yaml",
    ]


def _load_manifest_dict(project_path: Path) -> dict[str, Any] | None:
    root = project_path.expanduser().resolve()
    for p in _manifest_paths(root):
        if not p.is_file():
            continue
        pr = project_root_for_manifest_file(p)
        if pr is None:
            continue
        try:
            doc = ManifestDocument.from_path(pr)
        except (FileNotFoundError, ValueError):
            continue
        if doc.path.resolve() != p.resolve():
            continue
        return dict(doc.to_legacy_dict())
    return None


def _phase_from_manifest(data: dict[str, Any]) -> tuple[str | None, str | None]:
    phases = data.get("phases")
    if isinstance(phases, dict):
        cur = phases.get("current")
        if cur is not None:
            label = None
            for u in phases.get("upcoming") or []:
                if isinstance(u, dict) and u.get("phase") == cur:
                    label = str(u.get("name") or u.get("status") or "")
                    break
            return str(cur), label or None
    if isinstance(phases, list):
        for p in phases:
            if not isinstance(p, dict):
                continue
            st = str(p.get("status", "")).lower()
            if st in ("current", "in_progress"):
                pid = p.get("id", p.get("phase"))
                return (str(pid) if pid is not None else None, str(p.get("label") or p.get("name") or "") or None)
    return None, None


def _bucket_names(data: dict[str, Any], key: str) -> list[str]:
    out: list[str] = []
    for row in data.get(key) or []:
        if isinstance(row, dict):
            n = row.get("name") or row.get("path") or row.get("file")
            if n:
                out.append(str(n))
        elif isinstance(row, str) and row:
            out.append(row.split("/")[-1])
    return out


def _domains_from_manifest(data: dict[str, Any]) -> list[str]:
    doms: list[str] = []
    for bucket in ("controllers", "hooks", "services", "screens", "modules"):
        for row in data.get(bucket) or []:
            if isinstance(row, dict) and row.get("domain"):
                doms.append(str(row["domain"]).upper())
    d0 = data.get("domain")
    if d0:
        doms.append(str(d0).upper())
    return sorted(set(doms))


def extract_active_variants(config_path: Path) -> dict[str, str]:
    if not config_path.exists():
        return {}
    try:
        data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}
    lab = data.get("ui_lab")
    if isinstance(lab, dict):
        av = lab.get("active_variants")
        if isinstance(av, dict):
            return {str(k): str(v) for k, v in av.items()}
    return {}


def extract_feature_flags(config_path: Path) -> dict[str, bool]:
    if not config_path.exists():
        return {}
    try:
        data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}
    feats = data.get("features")
    if not isinstance(feats, dict):
        return {}
    out: dict[str, bool] = {}
    for k, v in feats.items():
        if isinstance(v, bool):
            out[str(k)] = v
        elif isinstance(v, str):
            out[str(k)] = v.strip().lower() in ("1", "true", "yes", "on")
    return out


def extract_debug_flags(config_path: Path) -> dict[str, bool]:
    if not config_path.exists():
        return {}
    try:
        data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}
    dbg = data.get("debug")
    if not isinstance(dbg, dict):
        return {}
    out: dict[str, bool] = {}
    for k, v in dbg.items():
        if isinstance(v, bool):
            out[str(k)] = v
        elif isinstance(v, str):
            out[str(k)] = v.strip().lower() in ("1", "true", "yes", "on")
    return out


def _sev_rank(sev: str) -> int:
    return {"blocker": 0, "high": 1, "normal": 2}.get((sev or "normal").lower(), 3)


def _trigger_phrase(trig: dict[str, Any]) -> str:
    pats = trig.get("file_patterns") or []
    if isinstance(pats, str):
        pats = [pats]
    kws = trig.get("keywords") or []
    if isinstance(kws, str):
        kws = [kws]
    parts: list[str] = []
    if pats:
        parts.append(", ".join(str(x) for x in pats))
    if kws:
        parts.append("keywords: " + ", ".join(str(x) for x in kws))
    return " / ".join(parts) if parts else "(unspecified triggers)"


def _requires_phrase(req: dict[str, Any]) -> str:
    files = (req.get("files") or []) if isinstance(req, dict) else []
    bits: list[str] = []
    for rf in files:
        if not isinstance(rf, dict):
            continue
        p = str(rf.get("path", ""))
        ha = rf.get("headings_any") or rf.get("headings") or []
        if isinstance(ha, str):
            ha = [ha]
        if ha and p:
            bits.append(f"{p} ## " + ", ".join(str(h) for h in ha))
        elif p:
            bits.append(p)
    return "; ".join(bits) if bits else "(no required files)"


def extract_constraints_from_impact(impact_path: Path) -> list[str]:
    if not impact_path.exists():
        return []
    try:
        data = yaml.safe_load(impact_path.read_text(encoding="utf-8")) or {}
    except Exception:
        return []
    if not isinstance(data, dict):
        return []
    rules = data.get("change_types")
    if not isinstance(rules, list):
        return []
    decorated: list[tuple[int, str]] = []
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        sev = str(rule.get("severity", "normal"))
        trig = rule.get("triggers") or {}
        if not isinstance(trig, dict):
            trig = {}
        req = rule.get("requires") or {}
        if not isinstance(req, dict):
            req = {}
        t = _trigger_phrase(trig)
        r = _requires_phrase(req)
        line = f"Changing {t} requires {r}"
        decorated.append((_sev_rank(sev), line))
    decorated.sort(key=lambda x: (x[0], x[1]))
    return [d[1] for d in decorated]


def _adr_constraint_lines(adr_path: Path) -> list[str]:
    if not adr_path.exists():
        return []
    try:
        data = yaml.safe_load(adr_path.read_text(encoding="utf-8")) or {}
    except Exception:
        return []
    if not isinstance(data, dict):
        return []
    raw = data.get("constraints")
    if isinstance(raw, list):
        return [str(x) for x in raw if x]
    lines: list[str] = []
    for adr in data.get("adrs") or []:
        if not isinstance(adr, dict):
            continue
        aid = adr.get("id", "")
        enf = adr.get("enforcement")
        if isinstance(enf, dict):
            t = enf.get("type", "")
            f = enf.get("file", "")
            lines.append(f"{aid}: enforcement {t} ({f})")
        else:
            lines.append(str(aid))
    return lines


def _known_broken_from_frontmatter(project_path: Path) -> tuple[list[str], str | None]:
    """AGENT_CONTEXT.md first, then docs/TODO.md. Frontmatter only."""
    phase_override: str | None = None
    for rel in ("docs/AGENT_CONTEXT.md", "AGENT_CONTEXT.md"):
        p = project_path / rel
        if not p.exists():
            continue
        try:
            raw = p.read_text(encoding="utf-8")
        except Exception:
            continue
        fm, _body = parse_markdown_frontmatter(raw)
        if fm.get("phase") is not None:
            phase_override = str(fm.get("phase"))
        if "known_broken" in fm:
            kb = fm.get("known_broken")
            if isinstance(kb, list):
                return [str(x) for x in kb if x is not None], phase_override
            if kb is not None:
                return [str(kb)], phase_override
            return [], phase_override
    todo = project_path / "docs" / "TODO.md"
    if todo.exists():
        try:
            fm2, _ = parse_markdown_frontmatter(todo.read_text(encoding="utf-8"))
            if "known_broken" in fm2:
                kb2 = fm2.get("known_broken")
                if isinstance(kb2, list):
                    return [str(x) for x in kb2 if x is not None], phase_override
                if kb2 is not None:
                    return [str(kb2)], phase_override
        except Exception:
            pass
    return [], phase_override


def build_project(project_path: Path) -> ProjectContext:
    """
    YAML-primary project context. Does not parse markdown bodies
    for constraints or known_broken (frontmatter only for the latter).
    """
    root = project_path.resolve()
    data = _load_manifest_dict(root) or {}
    name = str(data.get("name") or root.name)
    app = data.get("app")
    if isinstance(app, dict) and app.get("name"):
        name = str(app["name"])
    phase, phase_label = _phase_from_manifest(data)
    stack = ManifestParser.get_stack(data)
    domains = _domains_from_manifest(data)
    screens = _bucket_names(data, "screens")
    controllers = _bucket_names(data, "controllers") + _bucket_names(data, "hooks")
    services = _bucket_names(data, "services")

    cfg_path = next((p for p in _app_config_paths(root) if p.exists()), None)
    active_variants = extract_active_variants(cfg_path) if cfg_path else {}
    feature_flags = extract_feature_flags(cfg_path) if cfg_path else {}
    debug_flags = extract_debug_flags(cfg_path) if cfg_path else {}

    # DEPRECATED: change-impact.yaml display path — prefer impact-rules.yaml for propagation.
    impact_path = next((p for p in _change_impact_paths(root) if p.exists()), None)
    constraint_summary: list[str] = []
    if impact_path:
        try:
            constraint_summary = extract_constraints_from_impact(impact_path)
        except Exception:
            constraint_summary = []
    impact_rules: list[str] = []
    if impact_path and impact_path.exists():
        try:
            idata = yaml.safe_load(impact_path.read_text(encoding="utf-8")) or {}
            for ct in idata.get("change_types") or []:
                if isinstance(ct, dict) and ct.get("id"):
                    impact_rules.append(str(ct["id"]))
        except Exception:
            impact_rules = []

    adr_path = next((p for p in _adr_registry_paths(root) if p.exists()), None)
    adr_constraints = _adr_constraint_lines(adr_path) if adr_path else []

    known_broken, phase_override = _known_broken_from_frontmatter(root)

    return ProjectContext(
        name=name,
        phase=phase,
        phase_label=phase_label,
        phase_override=phase_override,
        stack=stack,
        domains=domains,
        screens=screens,
        controllers=controllers,
        services=services,
        active_variants=active_variants,
        feature_flags=feature_flags,
        debug_flags=debug_flags,
        impact_rules=impact_rules,
        constraint_summary=constraint_summary,
        adr_constraints=adr_constraints,
        known_broken=known_broken,
        next_action=str(data.get("next_action") or "").strip() or None,
        blocker=str(data.get("blocker") or "").strip() or None,
        current_task=str(data.get("current_task") or "").strip() or None,
    )


def _resolve_include(
    section: str,
    spec: TemplateSpec,
    all_keys: dict[str, list[str]],
) -> list[str] | str:
    raw = spec.include.get(section)
    if raw == "all":
        return "all"
    if isinstance(raw, list):
        return [str(x) for x in raw]
    if isinstance(raw, bool) and section == "queried":
        return ["queried"] if raw else []
    return []


def _gather_global(spec: TemplateSpec) -> dict[str, Any]:
    keys = _resolve_include("global", spec, {})
    out: dict[str, Any] = {}
    if keys == "all":
        keys = ["skills_available", "template_path", "template_resolution"]
    for k in keys:
        if k == "skills_available":
            home = Path.home()
            skills = home / ".cursor" / "skills"
            names: list[str] = []
            if skills.is_dir():
                for p in skills.iterdir():
                    if p.is_dir() and (p / "SKILL.md").exists():
                        names.append(p.name)
            out[k] = _truncate_list(sorted(names), spec.max_items_per_list)
        elif k == "template_path":
            from forge.tools.init_docs.config import get_template_path_info

            out[k] = get_template_path_info().get("resolved")
        elif k == "template_resolution":
            from forge.tools.init_docs.config import get_template_path_info

            out[k] = get_template_path_info()
    return out


def _gather_project(spec: TemplateSpec, pc: ProjectContext) -> dict[str, Any]:
    keys = _resolve_include("project", spec, {})
    out: dict[str, Any] = {}
    if keys == "all":
        keys = [
            "name",
            "phase",
            "phase_label",
            "stack",
            "known_broken",
            "constraints",
            "domains",
            "screens",
            "controllers",
            "services",
            "active_variants",
            "feature_flags",
            "debug_flags",
            "impact_rules",
            "constraint_summary",
            "adr_constraints",
            "next_action",
            "blocker",
            "current_task",
        ]
    for k in keys:
        if k == "name":
            out[k] = pc.name
        elif k == "phase":
            out[k] = pc.phase
        elif k == "phase_label":
            out[k] = pc.phase_label
        elif k == "stack":
            out[k] = pc.stack
        elif k == "known_broken":
            out[k] = list(pc.known_broken)
        elif k == "constraints":
            out[k] = list(pc.constraint_summary)
        elif k == "domains":
            out[k] = _truncate_list(pc.domains, spec.max_items_per_list)
        elif k == "screens":
            out[k] = _truncate_list(pc.screens, spec.max_items_per_list)
        elif k == "controllers":
            out[k] = _truncate_list(pc.controllers, spec.max_items_per_list)
        elif k == "services":
            out[k] = _truncate_list(pc.services, spec.max_items_per_list)
        elif k == "active_variants":
            out[k] = dict(pc.active_variants)
        elif k == "feature_flags":
            out[k] = {k2: v2 for k2, v2 in pc.feature_flags.items() if v2}
        elif k == "debug_flags":
            out[k] = dict(pc.debug_flags)
        elif k == "impact_rules":
            out[k] = list(pc.impact_rules)
        elif k == "constraint_summary":
            out[k] = list(pc.constraint_summary)
        elif k == "adr_constraints":
            out[k] = list(pc.adr_constraints)
        elif k == "next_action":
            out[k] = pc.next_action
        elif k == "blocker":
            out[k] = pc.blocker
        elif k == "current_task":
            out[k] = pc.current_task
    return out


def _gather_session(spec: TemplateSpec, project_path: Path) -> dict[str, Any]:
    keys = _resolve_include("session", spec, {})
    out: dict[str, Any] = {}
    if keys == "all":
        keys = ["this_session", "quick_notes", "tasks_to_file"]
    scratch = _resolve_scratch_path(project_path)
    scratch_text = ""
    if scratch.exists():
        try:
            scratch_text = scratch.read_text(encoding="utf-8").strip()
        except Exception:
            pass
    for k in keys:
        if k == "this_session":
            out[k] = scratch_text[:2000] if scratch_text else "(empty ~/.forge/scratch.md)"
        elif k == "quick_notes":
            out[k] = scratch_text[:500] if scratch_text else ""
        elif k == "tasks_to_file":
            todo_p = project_path / "docs" / "TODO.md"
            if todo_p.exists():
                try:
                    txt = todo_p.read_text(encoding="utf-8")
                    out[k] = txt[:3000]
                except Exception:
                    out[k] = ""
            else:
                out[k] = ""
    return out


def _resolve_scratch_path(project_path: Path) -> Path:
    """
    Scratch is per-project. Falls back to global only if project scratch absent.
    Per-project: {project_root}/.forge/scratch.md
    Global fallback: ~/.forge/scratch.md (legacy, cross-project — avoid writing here)
    """
    project_scratch = project_path / ".forge" / "scratch.md"
    if project_scratch.exists():
        return project_scratch
    global_scratch = Path.home() / ".forge" / "scratch.md"
    if global_scratch.exists():
        return global_scratch
    return project_scratch


def build_task(project_path: Path, feature_scope: str | None = None) -> TaskContext:
    """
    Build task-level context: scan validation.json (if present) + .forge/context_cache.json.
    """
    _ = feature_scope
    tc = TaskContext()
    root = project_path.resolve()
    val_p = root / "scan" / "validation.json"
    if val_p.exists():
        try:
            v = json.loads(val_p.read_text(encoding="utf-8"))
            summ = v.get("summary") or {}
            tc.severed_connections = int(v.get("severed", summ.get("severed", 0)))
            tc.orphan_count = int(summ.get("orphans", 0))
            tc.drift_count = int(summ.get("drift_items", 0))
        except Exception:
            pass
    cache_p = root / ".forge" / "context_cache.json"
    if cache_p.exists():
        try:
            data = json.loads(cache_p.read_text(encoding="utf-8"))
            scan = data.get("scan") or {}
            ts = scan.get("run_at")
            if ts:
                built = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                delta = datetime.now(timezone.utc) - built.astimezone(timezone.utc)
                hours = delta.total_seconds() / 3600
                if hours < 1:
                    tc.scan_age = f"{max(0, int(delta.total_seconds() // 60))} min"
                elif hours < 48:
                    tc.scan_age = f"{round(hours, 1)} h"
                else:
                    tc.scan_age = f"{int(hours // 24)} d"
            if not val_p.exists():
                tc.severed_connections = int(scan.get("severed", tc.severed_connections))
                tc.orphan_count = int(scan.get("orphan_count", tc.orphan_count))
                tc.drift_count = int(scan.get("drift_count", tc.drift_count))
        except Exception:
            pass
    return tc


def build_graph_context(
    project_path: Path,
    scope: str | None = None,
    *,
    full: bool = False,
    graph: Any | None = None,
) -> dict[str, Any]:
    """
    Graph-aware context: manifest Ring-2 summary for FORGE-CONTEXT ``graph`` section.
    ``scope`` filters by domain / id substring; ``full`` includes more relation samples.
    """
    from forge.tools.manifest.graph import (
        DERIVED_PEER_RELATION,
        build_manifest_graph,
        filter_graph_for_scope,
        graph_scan_age_days,
    )

    root = project_path.resolve()
    try:
        g = graph if graph is not None else build_manifest_graph(root)
    except Exception as exc:
        return {
            "node_count": 0,
            "edge_count": 0,
            "domains": [],
            "relations_sample": [],
            "orphans": [],
            "scope": scope or "all",
            "scan_age_days": None,
            "error": str(exc),
        }
    if scope:
        g = filter_graph_for_scope(g, scope)
    by_id = {n.id: n for n in g.nodes}
    touched: set[str] = set()
    for e in g.edges:
        touched.add(e.from_id)
        touched.add(e.to_id)
    orphans = [n.name for n in g.nodes if n.id not in touched]
    domains = sorted({(n.domain or "").upper() for n in g.nodes if n.domain})
    sample: list[str] = []
    max_e = 80 if full else 15
    for e in g.edges:
        if not full and e.relation == DERIVED_PEER_RELATION:
            continue
        if len(sample) >= max_e:
            break
        a = by_id.get(e.from_id)
        b = by_id.get(e.to_id)
        if not a or not b:
            continue
        sample.append(f"{a.name} —{e.relation}→ {b.name}")
    # Phase 3: include scan_age_days from graph cache built_at timestamp
    try:
        age_days = graph_scan_age_days(root)
    except Exception:
        age_days = None
    structural_health: str | None = None
    verify_failures: list[str] = []
    verify_exit_code: int | None = None
    verify_path = root / ".forge" / "verify-last.json"
    if verify_path.is_file():
        try:
            vdata = json.loads(verify_path.read_text(encoding="utf-8"))
            verify_exit_code = int(vdata.get("exit_code") or 0)
            raw_failures = vdata.get("failures") or []
            if isinstance(raw_failures, list):
                verify_failures = [str(x) for x in raw_failures if x]
            if verify_exit_code == 0:
                structural_health = "clean"
            elif verify_exit_code == 1:
                structural_health = "warnings"
            else:
                structural_health = "failures"
        except Exception:
            pass
    health_score: dict[str, float] | None = None
    idr_rationale: dict[str, Any] | None = None
    try:
        from forge.engine.registry import EntityRegistry
        from forge.engine.projections.health import to_health_vector

        reg = EntityRegistry()
        reg._project_path = root
        reg._graph = g
        hv = to_health_vector(reg)
        health_score = {
            "adi": float(hv.adi_score),
            "brc": float(hv.brc_score),
            "idr": float(hv.idr_score),
            "overall": float(hv.adi_score + hv.brc_score + hv.idr_score) / 3.0,
        }
        idr_rationale = hv.idr_rationale
    except Exception:
        health_score = None
        idr_rationale = None
    return {
        "node_count": len(g.nodes),
        "edge_count": len(g.edges),
        "domains": domains,
        "relations_sample": sample,
        "orphans": orphans[:30],
        "scope": scope or "all",
        "scan_age_days": age_days,
        "structural_health": structural_health,
        "verify_failures": verify_failures,
        "verify_exit_code": verify_exit_code,
        "health_score": health_score,
        "idr_rationale": idr_rationale,
    }


def _gather_task(spec: TemplateSpec, project_path: Path) -> dict[str, Any]:
    keys = _resolve_include("task", spec, {})
    out: dict[str, Any] = {}
    if keys == "all":
        keys = ["scan_results", "scan_age_hours", "scan_stale", "impact_status", "impact_age_hours"]
    cache_p = project_path / ".forge" / "context_index.json"
    for k in keys:
        if k == "scan_results":
            out[k] = "(run `forge impact-check` for policy audit details)"
        elif k == "scan_stale":
            out[k] = "(use `forge context --check` for index staleness)"
        elif k == "impact_status":
            out[k] = "(optional: parse last impact-check output)"
        elif k == "impact_age_hours":
            out[k] = ""
        elif k == "scan_age_hours":
            out[k] = ""
    if cache_p.exists():
        try:
            data = json.loads(cache_p.read_text(encoding="utf-8"))
            bt = data.get("built_at")
            if bt:
                built = datetime.fromisoformat(bt.replace("Z", "+00:00"))
                delta = datetime.now(timezone.utc) - built.astimezone(timezone.utc)
                out["context_index_age_hours"] = round(delta.total_seconds() / 3600, 2)
        except Exception:
            pass
    tc = build_task(project_path)
    out["severed_connections"] = tc.severed_connections
    out["orphan_count"] = tc.orphan_count
    out["drift_count"] = tc.drift_count
    out["scan_age"] = tc.scan_age
    out["impact_status"] = tc.impact_status
    out["impact_age"] = tc.impact_age
    return out


def build_queried(
    index: FrontmatterIndex,
    spec: TemplateSpec,
    project_path: Path,
    feature_scope: str | None = None,
) -> QueryResult | None:
    qraw = spec.query
    if not qraw:
        qraw = {}
    q = dict(qraw)
    dyn = bool(q.pop("feature_scope_dynamic", False))
    if dyn and feature_scope:
        scope = feature_scope.strip().lower()
        q.setdefault("id_pattern", f"{scope}*")
        from forge.tools.context.templates import SCOPE_HINT_DOMAINS

        doms = SCOPE_HINT_DOMAINS.get(scope, [])
        if doms:
            q["domains"] = doms
    if not q and not (dyn and feature_scope):
        return None
    domains = q.get("domains")
    if isinstance(domains, str):
        domains = [domains]
    types = q.get("types")
    if types is None and q.get("type") is not None:
        types = [str(q["type"])]
    if isinstance(types, str):
        types = [types]
    id_pattern = q.get("id_pattern")
    if id_pattern is not None:
        id_pattern = str(id_pattern)
    phase = q.get("phase")
    try:
        phase_i = int(phase) if phase is not None else None
    except Exception:
        phase_i = None
    status = q.get("status")
    status_s = str(status) if status is not None else None
    has_sentinel = q.get("has_sentinel")
    has_s = str(has_sentinel) if has_sentinel is not None else None
    depends_on = q.get("depends_on")
    dep_s = str(depends_on) if depends_on is not None else None

    matched = index.query(
        domains=[str(d) for d in (domains or [])] if domains else None,
        types=[str(t) for t in (types or [])] if types else None,
        id_pattern=id_pattern,
        phase=phase_i,
        status=status_s,
        has_sentinel=has_s,
        depends_on=dep_s,
    )
    if dyn and feature_scope and not matched:
        matched = index.query(id_pattern=f"{feature_scope.strip().lower()}*")

    manifest_entries: list[dict[str, Any]] = []
    for rel in spec.from_manifests:
        mp = project_path / rel
        for n in index.traverse_manifest(mp):
            manifest_entries.append(
                {
                    "manifest": rel,
                    "doc_id": n.id,
                    "path": n.path,
                    "type": n.type,
                }
            )

    names = list(spec.extract_sentinels)
    sent_map: dict[str, list[str]] = {}
    for n in matched:
        for sname, text in n.extractable_sections.items():
            if names and sname not in names:
                continue
            t = (text or "").strip()
            if not t:
                continue
            sent_map.setdefault(sname, [])
            if t not in sent_map[sname]:
                sent_map[sname].append(t)

    return QueryResult(
        query=q,
        matched_docs=[n.id for n in matched],
        sentinels=sent_map,
        manifest_entries=_truncate_list(manifest_entries, spec.max_items_per_list),
    )


def build_bundle(
    project_path: Path | None = None,
    level: str | None = None,
    template: str = "default",
    feature_scope: str | None = None,
    sections: list[str] | None = None,
    exclude_sections: list[str] | None = None,
    include_session: bool = False,
    *,
    rebuild_index_first: bool = False,
    graph: Any | None = None,
) -> ContextBundle:
    try:
        root = Path(project_path or ".").resolve()
        spec = load_template(template, root)
        eff_level = level if level is not None else spec.level
        fs = feature_scope if feature_scope is not None else spec.feature_scope
        q = dict(spec.query or {})
        if template == "feature" and feature_scope:
            q["feature_scope_dynamic"] = True
        spec = dataclasses.replace(spec, level=eff_level, feature_scope=fs, query=q or None)

        pc = build_project(root)

        idx = FrontmatterIndex(root)
        if rebuild_index_first:
            rebuild_index(root)
        idx.build(use_cache=True)

        queried = build_queried(idx, spec, root, feature_scope=feature_scope)
        inc = spec.include or {}
        _exclude = set(exclude_sections or [])
        if not include_session:
            _exclude.add("session")
        _allow = set(sections) if sections else None

        include_global_section = (_allow is None or "global" in _allow) and "global" not in _exclude
        include_project_section = (_allow is None or "project" in _allow) and "project" not in _exclude
        include_session_section = (_allow is None or "session" in _allow) and "session" not in _exclude
        include_task_section = (_allow is None or "task" in _allow) and "task" not in _exclude
        include_queried_section = (_allow is None or "queried" in _allow) and "queried" not in _exclude
        include_graph_section = (_allow is None or "graph" in _allow) and "graph" not in _exclude

        if not inc.get("queried") or not include_queried_section:
            queried_for_md = None
        else:
            queried_for_md = queried

        global_s = _gather_global(spec) if include_global_section else {}
        project_s = _gather_project(spec, pc) if include_project_section else {}
        session_s = _gather_session(spec, root) if include_session_section else {}
        task_s = _gather_task(spec, root) if include_task_section else {}

        graph_section: dict[str, Any] | None = None
        gm = inc.get("graph")
        if include_graph_section and gm in ("summary", "full"):
            graph_section = build_graph_context(
                root, scope=fs, full=(gm == "full"), graph=graph
            )

        bundle = ContextBundle(
            markdown="",
            template_name=spec.name,
            level=spec.level,
            project_path=str(root),
            global_section=global_s,
            project_section=project_s,
            session_section=session_s,
            task_section=task_s,
            queried=queried,
            project_context=pc,
            graph_section=graph_section,
        )
        bundle.markdown = bundle.to_markdown(spec, global_s, session_s, task_s, queried_for_md)
        return bundle
    except Exception as exc:
        md = (
            "<!-- FORGE-CONTEXT -->\n\n"
            f"_Context bundle failed (non-fatal): `{exc}`_\n\n"
            "<!-- END:FORGE-CONTEXT -->"
        )
        return ContextBundle(
            markdown=md,
            template_name=template,
            level=level or "session",
            project_path=str(Path(project_path or ".").resolve()),
            queried=None,
            project_context=None,
        )
