from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from pathlib import Path
import re

from forge.core.manifest_path import resolve_manifest_path
from forge.tools.docs_audit.orchestrator import run_docs_audit
from forge.tools.docs_audit.output.summary import build_summary
from forge.tools.docs_audit.loaders.yaml_loader import load_yaml
from forge.tools.init_docs.config import resolve_template_path
from forge.tools.toc.generator import update_file_toc


@dataclass(frozen=True)
class FileAction:
    path: str
    action: str  # created|skipped|overwritten


def _render(template_text: str, replacements: dict[str, str]) -> str:
    out = template_text
    for key, val in replacements.items():
        out = out.replace("{{" + key + "}}", val)
    return out


def _load_forge_version(repo_root: Path) -> str:
    manifest_path = resolve_manifest_path(repo_root) or (repo_root / ".forge" / "manifest.yaml")
    data = load_yaml(manifest_path)
    return str(data.get("version", "1.0.0"))


def _project_tokens(project_root: Path, forge_root: Path) -> dict[str, str]:
    manifest_path = resolve_manifest_path(project_root) or (project_root / ".forge" / "manifest.yaml")
    project_manifest = load_yaml(manifest_path)
    project_name = str(project_manifest.get("name", project_root.name))
    project_version = str(project_manifest.get("version", "0.1.0"))
    return {
        "PROJECT_NAME": project_name,
        "PROJECT_VERSION": project_version,
        "DATE": date.today().isoformat(),
        "FORGE_VERSION": _load_forge_version(forge_root),
    }


def _extract_h2_headings(text: str) -> list[str]:
    return [line.strip() for line in text.splitlines() if re.match(r"^##\s+", line.strip())]


def run_gap_analysis(
    project_path: Path,
    template_dir: Path,
    created: list[FileAction],
    skipped: list[FileAction],
) -> str:
    """
    When files were skipped (already exist), run docs-audit against
    them and surface gaps as actionable suggestions — not failures.
    This makes init-docs useful for partially-documented projects.
    """
    if not skipped:
        return ""

    lines: list[str] = []
    docs_root = project_path / "docs"
    manifest_path = resolve_manifest_path(project_path) or (project_path / ".forge" / "manifest.yaml")
    # DEPRECATED: change-impact.yaml — advisory docs-audit only; skipped when absent.
    impact_path = project_path / ".forge" / "change-impact.yaml"
    if not impact_path.exists():
        impact_path = project_path / "change-impact.yaml"
    if manifest_path.exists() and impact_path.exists() and docs_root.exists():
        result = run_docs_audit(
            manifest_path=str(manifest_path),
            impact_path=str(impact_path),
            impact_local_path=str(project_path / "change-impact.local.yaml")
            if (project_path / "change-impact.local.yaml").exists()
            else None,
            docs_root=str(docs_root),
            changed_files=[str(p) for p in docs_root.rglob("*") if p.is_file()],
            strict=False,
        )
        if result.failures:
            lines.append("┌─ Docs Gap Analysis ──────────────────────────────────────┐")
            lines.append(f"│ {len(result.failures)} gaps found in existing docs. Suggested actions:        │")
            lines.append("├───────────────────────────────────────────────────────────┤")
            for f in result.failures:
                lines.append(f"│ {f.file[:22].ljust(22)} │ {f.message[:50].ljust(50)} │")
            lines.append("└───────────────────────────────────────────────────────────┘")
            lines.append("Run: forge impact-check shell -> load . -> evaluate")

    for action in skipped:
        proj_file = project_path / action.path
        tmpl_file = template_dir / action.path
        if not proj_file.exists() or not tmpl_file.exists():
            continue
        existing = proj_file.read_text(encoding="utf-8")
        template = tmpl_file.read_text(encoding="utf-8")
        existing_h2 = set(_extract_h2_headings(existing))
        template_h2 = _extract_h2_headings(template)
        missing = [h for h in template_h2 if h not in existing_h2]
        if missing:
            lines.append("")
            lines.append(f"{action.path} — skipped (exists)")
            lines.append("  Template has sections not in your file:")
            for m in missing:
                lines.append(f"    missing: {m}")
            lines.append("  Add these manually or run with --force to reset from template.")
    return "\n".join(lines)


def bootstrap_docs(project_root: Path, force: bool, dry_run: bool, forge_root: Path) -> tuple[list[FileAction], str, int]:
    template_dir = resolve_template_path()
    tokens = _project_tokens(project_root=project_root, forge_root=forge_root)
    actions: list[FileAction] = []
    toc_generated = 0

    for src in template_dir.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(template_dir)
        if rel == Path("README.md"):
            continue
        dst = project_root / rel
        exists = dst.exists()
        if exists and not force:
            actions.append(FileAction(path=str(rel).replace("\\", "/"), action="skipped"))
            continue
        action = "overwritten" if exists else "created"
        actions.append(FileAction(path=str(rel).replace("\\", "/"), action=action))
        if dry_run:
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        rendered = _render(src.read_text(encoding="utf-8"), tokens)
        dst.write_text(rendered, encoding="utf-8")
        if dst.suffix.lower() == ".md":
            tr = update_file_toc(dst, min_headings=3, dry_run=False)
            if tr.get("changed"):
                toc_generated += 1

    # advisory docs-audit run; never fail bootstrap
    audit_summary = "docs-audit advisory skipped"
    if not dry_run:
        manifest_path = resolve_manifest_path(project_root) or (project_root / ".forge" / "manifest.yaml")
        # DEPRECATED: change-impact.yaml — advisory docs-audit only; skipped when absent.
        impact_path = project_root / ".forge" / "change-impact.yaml"
        if not impact_path.exists():
            impact_path = project_root / "change-impact.yaml"
        docs_root = project_root / "docs"
        if manifest_path.exists() and impact_path.exists() and docs_root.exists():
            result = run_docs_audit(
                manifest_path=str(manifest_path),
                impact_path=str(impact_path),
                impact_local_path=str(project_root / "change-impact.local.yaml")
                if (project_root / "change-impact.local.yaml").exists()
                else None,
                docs_root=str(docs_root),
                changed_files=[str(p) for p in docs_root.rglob("*") if p.is_file()],
                strict=False,
            )
            created = [a for a in actions if a.action == "created"]
            skipped = [a for a in actions if a.action == "skipped"]
            if skipped:
                gap_report = run_gap_analysis(project_root, template_dir, created, skipped)
                if gap_report:
                    audit_summary = f"{build_summary(result)}\n{gap_report}"
                else:
                    audit_summary = build_summary(result)
            else:
                audit_summary = f"Initial docs audit: {build_summary(result)}"
        else:
            audit_summary = (
                "docs-audit advisory skipped "
                "(missing docs/manifest.yaml or legacy change-impact.yaml)"
            )

    return actions, audit_summary, toc_generated

