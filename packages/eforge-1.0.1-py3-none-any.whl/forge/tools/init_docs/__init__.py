"""forge init-docs bootstrap tool."""

