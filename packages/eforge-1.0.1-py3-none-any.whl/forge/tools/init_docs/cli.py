from __future__ import annotations

from pathlib import Path

import click

from forge.core.path_utils import resolve_project_path
from forge.tools.init_docs.bootstrapper import bootstrap_docs
from forge.tools.init_docs.config import get_template_path_info


@click.command(name="init-docs")
@click.option("--project-path", default=".", show_default=True)
@click.option("--force", is_flag=True, default=False)
@click.option("--dry-run", is_flag=True, default=False)
@click.option("--show-template-path", is_flag=True, default=False)
def init_docs_cmd(project_path: str, force: bool, dry_run: bool, show_template_path: bool) -> None:
    if show_template_path:
        info = get_template_path_info()
        click.echo("Template Path Resolution")
        click.echo("┌──────────┬──────────────────────────────┬────────┬────────┐")
        click.echo("│ Priority │ Source                       │ Exists │ Active │")
        click.echo("├──────────┼──────────────────────────────┼────────┼────────┤")
        for s in info["sources"]:
            exists = "yes" if s["exists"] else "no"
            active = "✓" if s["active"] else ""
            click.echo(
                f"│ {str(s['priority']).ljust(8)} │ {str(s['label'])[:28].ljust(28)} │ {exists.ljust(6)} │ {active.ljust(6)} │"
            )
        click.echo("└──────────┴──────────────────────────────┴────────┴────────┘")
        if info["resolved"]:
            click.echo(f"Resolved: {info['resolved']}")
        if info["error"]:
            click.echo(f"Error: {info['error']}")
        return

    project_root = resolve_project_path(project_path)
    forge_root = Path(__file__).resolve().parents[3]
    actions, audit_summary, toc_n = bootstrap_docs(
        project_root=project_root,
        force=force,
        dry_run=dry_run,
        forge_root=forge_root,
    )
    click.echo("┌──────────────────────────────────────────────────────────┬─────────────┐")
    click.echo("│ File                                                     │ Action      │")
    click.echo("├──────────────────────────────────────────────────────────┼─────────────┤")
    for action in actions:
        click.echo(f"│ {action.path[:56].ljust(56)} │ {action.action.ljust(11)} │")
    click.echo("└──────────────────────────────────────────────────────────┴─────────────┘")
    created = sum(1 for a in actions if a.action == "created")
    skipped = sum(1 for a in actions if a.action == "skipped")
    overwritten = sum(1 for a in actions if a.action == "overwritten")
    click.echo(f"{created} files created, {skipped} skipped, {overwritten} overwritten")
    if not dry_run and toc_n:
        click.echo(f"✓ TOC generated for {toc_n} file(s)")
    click.echo(f"docs-audit advisory: {audit_summary}")

