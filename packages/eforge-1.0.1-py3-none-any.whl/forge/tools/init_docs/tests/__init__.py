"""tests for init_docs tool."""

