from pathlib import Path

from click.testing import CliRunner
import pytest

from forge.cli import main
from forge.tools.init_docs.bootstrapper import bootstrap_docs
from forge.tools.init_docs.config import resolve_template_path
import forge.tools.init_docs.config as init_config


@pytest.fixture
def use_bundled_init_templates(monkeypatch: pytest.MonkeyPatch) -> None:
    """Force bootstrap to use repo stub templates (ignore real sibling DOCS-TEMPLATE)."""
    bundled = Path(__file__).resolve().parents[1] / "templates"
    monkeypatch.setattr(
        "forge.tools.init_docs.bootstrapper.resolve_template_path",
        lambda: bundled,
    )


def _write_manifest(path: Path, name: str = "demo", version: str = "0.2.0") -> None:
    path.write_text(
        "\n".join(
            [
                "schema_version: 1",
                f"name: {name}",
                "type: web",
                f"version: {version}",
            ]
        ),
        encoding="utf-8",
    )


def test_creates_expected_files(tmp_path: Path, use_bundled_init_templates: None) -> None:
    _write_manifest(tmp_path / "manifest.yaml", name="myapp", version="1.2.3")
    forge_root = Path(__file__).resolve().parents[4]
    actions, _, _ = bootstrap_docs(project_root=tmp_path, force=False, dry_run=False, forge_root=forge_root)
    created = {a.path for a in actions if a.action == "created"}
    assert "docs/MAP.md" in created
    assert ".forge/change-impact.yaml" in created
    assert "AGENTS.md" in created


def test_skips_existing_when_not_force(tmp_path: Path, use_bundled_init_templates: None) -> None:
    _write_manifest(tmp_path / "manifest.yaml")
    (tmp_path / "docs").mkdir(parents=True, exist_ok=True)
    (tmp_path / "docs" / "MAP.md").write_text("existing", encoding="utf-8")
    forge_root = Path(__file__).resolve().parents[4]
    actions, _, _ = bootstrap_docs(project_root=tmp_path, force=False, dry_run=False, forge_root=forge_root)
    assert any(a.path == "docs/MAP.md" and a.action == "skipped" for a in actions)


def test_overwrites_when_force(tmp_path: Path, use_bundled_init_templates: None) -> None:
    _write_manifest(tmp_path / "manifest.yaml")
    (tmp_path / "docs").mkdir(parents=True, exist_ok=True)
    target = tmp_path / "docs" / "MAP.md"
    target.write_text("existing", encoding="utf-8")
    forge_root = Path(__file__).resolve().parents[4]
    actions, _, _ = bootstrap_docs(project_root=tmp_path, force=True, dry_run=False, forge_root=forge_root)
    assert any(a.path == "docs/MAP.md" and a.action == "overwritten" for a in actions)
    assert "existing" not in target.read_text(encoding="utf-8")


def test_dry_run_writes_nothing(tmp_path: Path, use_bundled_init_templates: None) -> None:
    _write_manifest(tmp_path / "manifest.yaml")
    forge_root = Path(__file__).resolve().parents[4]
    actions, _, _ = bootstrap_docs(project_root=tmp_path, force=False, dry_run=True, forge_root=forge_root)
    assert actions
    assert not (tmp_path / "docs").exists()


def test_placeholder_injection(tmp_path: Path, use_bundled_init_templates: None) -> None:
    _write_manifest(tmp_path / "manifest.yaml", name="inject-app", version="9.9.9")
    forge_root = Path(__file__).resolve().parents[4]
    bootstrap_docs(project_root=tmp_path, force=False, dry_run=False, forge_root=forge_root)
    map_text = (tmp_path / "docs" / "MAP.md").read_text(encoding="utf-8")
    assert "inject-app" in map_text
    assert "9.9.9" in map_text


def test_post_bootstrap_docs_audit_does_not_crash(tmp_path: Path, use_bundled_init_templates: None) -> None:
    _write_manifest(tmp_path / "manifest.yaml")
    forge_root = Path(__file__).resolve().parents[4]
    _actions, audit_summary, _toc = bootstrap_docs(project_root=tmp_path, force=False, dry_run=False, forge_root=forge_root)
    assert "docs-audit advisory" in f"docs-audit advisory: {audit_summary}"


def test_resolves_sibling_path(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    sibling = tmp_path / "DOCS-TEMPLATE"
    (sibling / "docs").mkdir(parents=True, exist_ok=True)
    (sibling / "docs" / "MAP.md").write_text("x", encoding="utf-8")
    fake_file = tmp_path / "forge" / "tools" / "init_docs" / "config.py"
    monkeypatch.setattr(init_config, "__file__", str(fake_file))
    monkeypatch.delenv("FORGE_DOCS_TEMPLATE_PATH", raising=False)
    resolved = resolve_template_path()
    assert resolved == sibling.resolve()


def test_resolves_env_var_path(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    env_dir = tmp_path / "tpl"
    env_dir.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("FORGE_DOCS_TEMPLATE_PATH", str(env_dir))
    assert resolve_template_path() == env_dir.resolve()


def test_env_var_takes_priority_over_sibling(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    sibling = tmp_path / "DOCS-TEMPLATE"
    sibling.mkdir(parents=True, exist_ok=True)
    env_dir = tmp_path / "alt-template"
    env_dir.mkdir(parents=True, exist_ok=True)
    fake_file = tmp_path / "forge" / "tools" / "init_docs" / "config.py"
    monkeypatch.setattr(init_config, "__file__", str(fake_file))
    monkeypatch.setenv("FORGE_DOCS_TEMPLATE_PATH", str(env_dir))
    assert resolve_template_path() == env_dir.resolve()


def test_falls_back_to_bundled(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("FORGE_DOCS_TEMPLATE_PATH", raising=False)
    monkeypatch.setenv("FORGE_ALLOW_BUNDLED_TEMPLATES", "1")
    resolved = resolve_template_path()
    assert "forge/tools/init_docs/templates" in str(resolved)


def test_fatal_when_nothing_found(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fake_file = tmp_path / "forge" / "tools" / "init_docs" / "config.py"
    monkeypatch.setattr(init_config, "__file__", str(fake_file))
    monkeypatch.delenv("FORGE_DOCS_TEMPLATE_PATH", raising=False)
    monkeypatch.delenv("FORGE_ALLOW_BUNDLED_TEMPLATES", raising=False)
    with pytest.raises(FileNotFoundError) as exc:
        resolve_template_path()
    msg = str(exc.value)
    assert "FORGE_DOCS_TEMPLATE_PATH" in msg or "template" in msg.lower()


def test_show_template_path_flag() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["init-docs", "--show-template-path"])
    assert result.exit_code == 0
    assert "Resolved:" in result.output or "Error:" in result.output


def test_gap_analysis_on_existing_project(tmp_path: Path, use_bundled_init_templates: None) -> None:
    _write_manifest(tmp_path / "manifest.yaml")
    (tmp_path / "docs").mkdir(parents=True, exist_ok=True)
    (tmp_path / "docs" / "MAP.md").write_text("# existing\n", encoding="utf-8")
    forge_root = Path(__file__).resolve().parents[4]
    actions, summary, _toc = bootstrap_docs(project_root=tmp_path, force=False, dry_run=False, forge_root=forge_root)
    assert any(a.action == "skipped" for a in actions)
    assert "Suggested actions" in summary or "skipped (exists)" in summary


def test_gap_analysis_missing_sections(tmp_path: Path, use_bundled_init_templates: None) -> None:
    _write_manifest(tmp_path / "manifest.yaml")
    (tmp_path / "docs").mkdir(parents=True, exist_ok=True)
    (tmp_path / "docs" / "TODO.md").write_text("# TODO\n", encoding="utf-8")
    forge_root = Path(__file__).resolve().parents[4]
    _actions, summary, _toc = bootstrap_docs(project_root=tmp_path, force=False, dry_run=False, forge_root=forge_root)
    assert "missing: ## Phase Roadmap" in summary

