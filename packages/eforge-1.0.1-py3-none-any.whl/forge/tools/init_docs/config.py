import os
from pathlib import Path


def _bundled_opt_in() -> bool:
    v = os.environ.get("FORGE_ALLOW_BUNDLED_TEMPLATES", "")
    return v in ("1", "true", "yes", "TRUE", "YES")


def resolve_template_path() -> Path:
    """
    Resolve the DOCS-TEMPLATE source directory.

    Priority order:
    1. FORGE_DOCS_TEMPLATE_PATH environment variable
    2. ../DOCS-TEMPLATE/ relative to forge repo root
       (sibling directory in same parent folder)
    3. forge/tools/init_docs/templates/ — only when
       FORGE_ALLOW_BUNDLED_TEMPLATES=1 (stub; not maintained)

    Without (1) or (2), bundled templates are not used unless you
    explicitly opt in — avoids silent wrong-template audits.
    """
    # Priority 1 — explicit env var
    env = os.environ.get("FORGE_DOCS_TEMPLATE_PATH")
    if env:
        p = Path(env).expanduser().resolve()
        if p.exists() and p.is_dir():
            return p
        raise FileNotFoundError(
            f"FORGE_DOCS_TEMPLATE_PATH is set but not found: {p}\n"
            f"Unset it or fix the path."
        )

    # Priority 2 — sibling DOCS-TEMPLATE/ in parent directory
    forge_root = Path(__file__).parent.parent.parent.resolve()
    sibling = (forge_root.parent / "DOCS-TEMPLATE").resolve()
    if sibling.exists() and sibling.is_dir():
        return sibling

    # Priority 3 — bundled stub (explicit opt-in only)
    bundled = Path(__file__).parent / "templates"
    if bundled.exists() and bundled.is_dir():
        if _bundled_opt_in():
            return bundled
        raise FileNotFoundError(
            "No template source found.\n"
            "Set FORGE_DOCS_TEMPLATE_PATH (recommended), or ensure "
            f"../DOCS-TEMPLATE exists (looked at {sibling}).\n"
            "To use the bundled stub only for CI or local testing:\n"
            "  FORGE_ALLOW_BUNDLED_TEMPLATES=1\n"
            f"Stub directory exists but is disabled: {bundled}"
        )

    raise FileNotFoundError(
        "No DOCS-TEMPLATE source found.\n"
        "Tried (in order):\n"
        "  1. FORGE_DOCS_TEMPLATE_PATH env var (not set)\n"
        f"  2. {sibling} (not found)\n"
        f"  3. {bundled} (not found)\n\n"
        "Fix: set FORGE_DOCS_TEMPLATE_PATH in your shell:\n"
        "  export FORGE_DOCS_TEMPLATE_PATH="
        '"$HOME/Projects/DOCS-TEMPLATE"\n'
        "Then run: forge init-docs --show-template-path"
    )


def get_template_path_info() -> dict:
    """
    Returns metadata about template path resolution
    without raising. Used by --show-template-path and tests.
    """
    env = os.environ.get("FORGE_DOCS_TEMPLATE_PATH")
    forge_root = Path(__file__).parent.parent.parent.resolve()
    sibling = (forge_root.parent / "DOCS-TEMPLATE").resolve()
    bundled = Path(__file__).parent / "templates"

    sources = [
        {
            "priority": 1,
            "label": "FORGE_DOCS_TEMPLATE_PATH env var",
            "path": env or "(not set)",
            "exists": bool(env and Path(env).expanduser().exists()),
            "active": False,
        },
        {
            "priority": 2,
            "label": "sibling ../DOCS-TEMPLATE/",
            "path": str(sibling),
            "exists": sibling.exists(),
            "active": False,
        },
        {
            "priority": 3,
            "label": "bundled stub (requires FORGE_ALLOW_BUNDLED_TEMPLATES=1)",
            "path": str(bundled),
            "exists": bundled.exists(),
            "active": False,
        },
    ]

    try:
        resolved = resolve_template_path()
        res_s = str(resolved)
        for s in sources:
            if s["priority"] == 1 and env:
                if Path(env).expanduser().resolve() == resolved:
                    s["active"] = True
                    continue
            if s["path"] == res_s:
                s["active"] = True
        return {
            "resolved": res_s,
            "sources": sources,
            "error": None,
        }
    except FileNotFoundError as e:
        return {
            "resolved": None,
            "sources": sources,
            "error": str(e),
        }
