from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable

from forge.core.contracts import ContractRecord, ContractViolation, RawContract, build_contract_registry
import forge.core.query as _core_query


def _index_contracts(contracts: dict[str, list[RawContract]]) -> dict[str, dict[str, RawContract]]:
    out: dict[str, dict[str, RawContract]] = {}
    for node_id, rows in contracts.items():
        out[node_id] = {c.method: c for c in rows}
    return out


def _coerce_type(t: str | None) -> str:
    return (t or "unknown").strip() or "unknown"


def _compatible(expected: str, actual: str) -> bool:
    if expected == "unknown" or actual == "unknown":
        return True
    return expected == actual


def _prime_manifest_modules(graph: Any) -> None:
    """Phase 8 query primitive — establishes module scope before reading typed ``graph.edges``."""
    from forge.tools.manifest.graph import ManifestGraph

    if not isinstance(graph, ManifestGraph):
        return
    _core_query.forge_query(
        graph,
        kind="module",
        where={},
        limit=10**9,
        depth=1,
        direction="both",
    )


def _iter_contract_edges(graph: Any) -> Iterable[Any]:
    """Contract declaration edges: ``ManifestGraph.edges`` after ``forge_query``, else legacy getattr."""
    from forge.tools.manifest.graph import ManifestGraph

    _prime_manifest_modules(graph)
    if isinstance(graph, ManifestGraph):
        for edge in graph.edges:
            if str(edge.relation) == "contract":
                yield edge
        return
    for edge in getattr(graph, "edges", []) or []:
        if str(getattr(edge, "relation", "")) == "contract":
            yield edge


def _node_path_and_line(graph: Any, node_id: str) -> tuple[str, int]:
    from forge.tools.manifest.graph import ManifestGraph

    if isinstance(graph, ManifestGraph):
        by_id = {str(n.id): n for n in graph.nodes}
        node = by_id.get(node_id)
        if node is None:
            return "", 1
        file = str(node.path or "")
        line = int((node.meta or {}).get("line", 1) or 1)
        return file, line
    node_by_id = {str(n.id): n for n in getattr(graph, "nodes", [])}
    node = node_by_id.get(node_id)
    file = str(getattr(node, "path", "") or "") if node else ""
    line = int((getattr(node, "meta", {}) or {}).get("line", 1) or 1) if node else 1
    return file, line


def check_contracts(
    graph: Any,
    contracts: dict[str, list[RawContract]],
    execution_graph: Any | None = None,
) -> list[ContractViolation]:
    # UPGRADE: execution_graph reserved for Phase 5 execution-aware contracts (e.g. annotate
    # violations with trace-backed call pairs once ContractViolation schema allows optional fields).
    _ = execution_graph
    idx = _index_contracts(contracts)
    out: list[ContractViolation] = []

    for edge in _iter_contract_edges(graph):
        caller_id = str(getattr(edge, "from_id", ""))
        callee_id = str(getattr(edge, "to_id", ""))
        meta = dict(getattr(edge, "meta", {}) or {})
        method = str(meta.get("method") or "")
        if not method:
            continue
        caller_c = idx.get(caller_id, {}).get(method)
        callee_c = idx.get(callee_id, {}).get(method)
        if caller_c is None or callee_c is None:
            continue

        file, line = _node_path_and_line(graph, caller_id)
        symbol = method

        if len(caller_c.params) != len(callee_c.params):
            out.append(
                ContractViolation(
                    caller_node=caller_id,
                    callee_node=callee_id,
                    method=method,
                    violation_kind="missing-param",
                    expected=f"{len(callee_c.params)} params",
                    actual=f"{len(caller_c.params)} params",
                    file=file,
                    line=line,
                    symbol=symbol,
                    severity="error",
                )
            )
        else:
            for cp, pp in zip(callee_c.params, caller_c.params):
                et = _coerce_type(cp.type)
                at = _coerce_type(pp.type)
                if not _compatible(et, at):
                    out.append(
                        ContractViolation(
                            caller_node=caller_id,
                            callee_node=callee_id,
                            method=method,
                            violation_kind="type-mismatch",
                            expected=f"{cp.name}:{et}",
                            actual=f"{pp.name}:{at}",
                            file=file,
                            line=line,
                            symbol=symbol,
                            severity="error",
                        )
                    )

        er = _coerce_type(callee_c.returns)
        ar = _coerce_type(caller_c.returns)
        if not _compatible(er, ar):
            out.append(
                ContractViolation(
                    caller_node=caller_id,
                    callee_node=callee_id,
                    method=method,
                    violation_kind="wrong-return",
                    expected=er,
                    actual=ar,
                    file=file,
                    line=line,
                    symbol=symbol,
                    severity="error",
                )
            )
        if caller_c.async_boundary != callee_c.async_boundary:
            out.append(
                ContractViolation(
                    caller_node=caller_id,
                    callee_node=callee_id,
                    method=method,
                    violation_kind="async-boundary",
                    expected=f"async={callee_c.async_boundary}",
                    actual=f"async={caller_c.async_boundary}",
                    file=file,
                    line=line,
                    symbol=symbol,
                    severity="warning",
                )
            )
    return out


def contract_registry(graph: Any, contracts: dict[str, list[RawContract]]) -> list[ContractRecord]:
    return build_contract_registry(graph, contracts)


def contract_drift_rows(
    graph: Any,
    contracts: dict[str, list[RawContract]],
    *,
    scope_target: str | None = None,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    st = str(scope_target).strip() if scope_target else ""
    _prime_manifest_modules(graph)
    for edge in _iter_contract_edges(graph):
        if st:
            to_id = str(getattr(edge, "to_id", ""))
            from_id = str(getattr(edge, "from_id", ""))
            if to_id != st and from_id != st:
                continue
        meta = dict(getattr(edge, "meta", {}) or {})
        ta = dict(meta.get("type_annotations") or {})
        caller_r = str(ta.get("caller_return") or "unknown")
        callee_r = str(ta.get("callee_return") or "unknown")
        drift_type = "none"
        if caller_r != "unknown" and callee_r != "unknown" and caller_r != callee_r:
            drift_type = "return-type"
        if ta.get("caller_params") != ta.get("callee_params"):
            drift_type = "param-type"
        if drift_type == "none":
            continue
        rows.append(
            {
                "node_id": str(getattr(edge, "to_id", "")),
                "boundary_kind": str(meta.get("boundary_kind") or "sync"),
                "drift_type": drift_type,
                "expected_types": {
                    "params": ta.get("callee_params") or [],
                    "return": callee_r,
                },
                "actual_types": {
                    "params": ta.get("caller_params") or [],
                    "return": caller_r,
                },
                "method": str(meta.get("method") or ""),
                "contract_type": "callable",
            }
        )
    return rows


def async_boundary_rows(graph: Any, execution_graph: Any | None = None) -> list[dict[str, Any]]:
    trace_edges = set()
    if execution_graph is not None and hasattr(execution_graph, "edges"):
        for e in getattr(execution_graph, "edges", {}).values():
            trace_edges.add((str(getattr(e, "from_id", "")), str(getattr(e, "to_id", ""))))
    out: list[dict[str, Any]] = []
    _prime_manifest_modules(graph)
    for edge in _iter_contract_edges(graph):
        meta = dict(getattr(edge, "meta", {}) or {})
        if not bool(meta.get("async_boundary", False)):
            continue
        pair = (str(getattr(edge, "from_id", "")), str(getattr(edge, "to_id", "")))
        has_trace = pair in trace_edges
        out.append(
            {
                "from_id": pair[0],
                "to_id": pair[1],
                "async_boundary": True,
                "has_execution_trace": has_trace,
                "edge_kind": str(meta.get("edge_kind") or "contract"),
                "method": str(meta.get("method") or ""),
            }
        )
    return out
