from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from forge.core.manifest_path import manifest_candidates, resolve_manifest_path
from forge.tools.docs_audit.contracts.normalize import normalize_manifest
from forge.tools.scan.detector import detect_framework
from forge.tools.scan.models import FrameworkType, ParseResult, ScanResult, ServiceEntry
from forge.tools.scan.parsers.flutter import parse_flutter
from forge.tools.scan.parsers.python_app import parse_python
from forge.tools.scan.parsers.react_native import parse_react_native
from forge.tools.scan.parsers.typescript import parse_typescript
from forge.tools.scan.renderers.graph import render_graph
from forge.tools.scan.renderers.manifest import render_manifest
from forge.tools.scan.renderers.report import render_report
from forge.tools.scan.renderers.screens import render_screens
from forge.tools.scan.renderers.validation import render_validation
from forge.tools.scan.validators import (
    detect_orphans,
    validate_connections,
    validate_declared_vs_actual,
    validate_frontmatter,
)


def _manifest_paths(project_path: Path) -> list[Path]:
    return manifest_candidates(project_path)


def _resolve_manifest(project_path: Path) -> Path | None:
    return resolve_manifest_path(project_path)


def _norm_scan_path(p: str) -> str:
    return str(p).replace("\\", "/").lstrip("./")


def _parse_name_list_scan(val: Any) -> list[str]:
    if val is None:
        return []
    if isinstance(val, str):
        v = val.strip()
        if not v or v.lower() == "none":
            return []
        return [v]
    if isinstance(val, list):
        return [str(x).strip() for x in val if str(x).strip()]
    return []


def _screen_watch_names_scan(row: dict[str, Any]) -> list[str]:
    w = _parse_name_list_scan(row.get("watches"))
    if w:
        return w
    return _parse_name_list_scan(row.get("controller"))


def _controller_read_targets_scan(row: dict[str, Any]) -> list[str]:
    refs: list[str] = []
    refs.extend(_parse_name_list_scan(row.get("reads")))
    refs.extend(_parse_name_list_scan(row.get("depends_on")))
    seen: set[str] = set()
    out: list[str] = []
    for r in refs:
        if r not in seen:
            seen.add(r)
            out.append(r)
    return out


def _ctrl_key_scan(name: str) -> str:
    return name.replace("_", "").lower()


def _load_manifest_dict_scan(project_path: Path) -> dict[str, Any] | None:
    for p in _manifest_paths(project_path):
        if p.exists():
            try:
                data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
                return data if isinstance(data, dict) else None
            except Exception:
                return None
    return None


def hydrate_services_from_manifest(parse: ParseResult, project_path: Path) -> None:
    raw = _load_manifest_dict_scan(project_path)
    if not raw:
        return
    m = normalize_manifest(raw)
    existing = {s.name for s in parse.services}
    for row in m.get("services") or []:
        if not isinstance(row, dict):
            continue
        name = str(row.get("name") or row.get("id") or "")
        if not name or name in existing:
            continue
        fp = str(row.get("file") or row.get("path") or "")
        dom = row.get("domain")
        domain = str(dom).upper() if isinstance(dom, str) and dom.strip() else "UNKNOWN"
        parse.services.append(
            ServiceEntry(name=name, file=_norm_scan_path(fp), domain=domain, confidence="manifest", hints=[])
        )
        existing.add(name)


def _find_controller_for_manifest(parse: ParseResult, manifest_name: str) -> Any | None:
    k = _ctrl_key_scan(manifest_name)
    for c in parse.controllers:
        if _ctrl_key_scan(c.name) == k:
            return c
    return None


def _find_screen_by_file(parse: ParseResult, rel_file: str) -> Any | None:
    t = _norm_scan_path(rel_file)
    for s in parse.screens:
        if _norm_scan_path(s.file) == t:
            return s
    return None


def derive_manifest_edges(parse: ParseResult, project_path: Path) -> None:
    """
    Mutates parse in-place: derived_watchers, derived_consumers, derived_siblings
    from manifest.yaml wiring.
    """
    for s in parse.screens:
        s.derived_siblings = []
    for c in parse.controllers:
        c.derived_watchers = []
    for svc in parse.services:
        svc.derived_consumers = []

    hydrate_services_from_manifest(parse, project_path)
    raw = _load_manifest_dict_scan(project_path)
    if not raw:
        return
    m = normalize_manifest(raw)

    # watchers: manifest screen → controller
    watch_sets: dict[frozenset[str], list[str]] = {}
    for row in m.get("screens") or []:
        if not isinstance(row, dict):
            continue
        fp = row.get("file") or row.get("path")
        if not fp:
            continue
        screen = _find_screen_by_file(parse, str(fp))
        if not screen:
            continue
        watches = _screen_watch_names_scan(row)
        for w in watches:
            ctrl = _find_controller_for_manifest(parse, w)
            if ctrl and screen.name not in ctrl.derived_watchers:
                ctrl.derived_watchers.append(screen.name)
        if watches:
            key = frozenset(watches)
            watch_sets.setdefault(key, []).append(screen.name)

    # siblings: shared watches
    for _k, names in watch_sets.items():
        if len(names) < 2:
            continue
        for a in names:
            sa = next((x for x in parse.screens if x.name == a), None)
            if not sa:
                continue
            for b in names:
                if b != a and b not in sa.derived_siblings:
                    sa.derived_siblings.append(b)

    # service consumers
    for row in m.get("controllers") or []:
        if not isinstance(row, dict):
            continue
        cname = str(row.get("name") or row.get("id") or "")
        centry = _find_controller_for_manifest(parse, cname)
        if not centry:
            continue
        for tgt in _controller_read_targets_scan(row):
            for svc in parse.services:
                if svc.name == tgt or _ctrl_key_scan(svc.name) == _ctrl_key_scan(tgt):
                    if centry.name not in svc.derived_consumers:
                        svc.derived_consumers.append(centry.name)


def run_parser(framework: FrameworkType, root: Path) -> ParseResult:
    if framework == FrameworkType.FLUTTER:
        return parse_flutter(root)
    if framework == FrameworkType.REACT_NATIVE:
        return parse_react_native(root)
    if framework == FrameworkType.TYPESCRIPT:
        return parse_typescript(root)
    if framework == FrameworkType.PYTHON:
        return parse_python(root)
    return parse_python(root)


def _stale_paths_from_entries(entries: list[Any]) -> list[str]:
    from datetime import datetime, timezone

    from forge.tools.scan.validators.frontmatter_validator import parse_last_updated_date

    now = datetime.now(timezone.utc)
    stale: list[str] = []
    for e in entries:
        if (e.status or "").lower() != "current" or not e.last_updated:
            continue
        parsed = parse_last_updated_date(e.last_updated)
        if parsed and (now - parsed.astimezone(timezone.utc)).days > 90:
            stale.append(e.path)
    return sorted(set(stale))


def _compute_exit_code(
    severed_n: int,
    orphans_n: int,
    fm_issues: list[str],
    drift_n: int,
    stale_n: int,
    missing_docs_n: int = 0,
) -> int:
    if severed_n > 0 or missing_docs_n > 0:
        return 2
    if orphans_n > 0 or drift_n > 0 or stale_n > 0 or fm_issues:
        return 1
    return 0


def _health_scores(
    severed_n: int,
    orphans_n: int,
    fm_issues: list[str],
    drift_n: int,
    stale_n: int,
    missing_docs_n: int = 0,
) -> tuple[int, int]:
    """0–100 scores derived from scan signals (informational; not an exit gate)."""
    graph_health = max(0, min(100, 100 - severed_n * 22 - orphans_n * 4 - missing_docs_n * 15))
    sync_health = max(
        0,
        min(100, 100 - drift_n * 10 - len(fm_issues) * 5 - stale_n * 3),
    )
    return graph_health, sync_health


def _merge_context_cache(project_path: Path, scan_blob: dict[str, Any]) -> None:
    forge_dir = project_path / ".forge"
    forge_dir.mkdir(parents=True, exist_ok=True)
    cache_p = forge_dir / "context_cache.json"
    data: dict[str, Any] = {}
    if cache_p.exists():
        try:
            raw = json.loads(cache_p.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                data = raw
        except Exception:
            data = {}
    data["scan"] = scan_blob
    cache_p.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def run_scan(
    project_path: Path,
    output_dir: Path,
    formats: list[str],
    dry_run: bool = False,
    validate: bool = True,
    update_cache: bool = True,
) -> ScanResult:
    """
    Full scan: discovery → optional validation → cache → render outputs.
    """
    root = project_path.resolve()
    primary, _candidates, _reasons = detect_framework(root)
    parse = run_parser(primary, root)

    frontmatter: list[Any] = []
    connections: list[Any] = []
    orphans: list[Any] = []
    stale_docs: list[str] = []
    missing_docs: list[str] = []
    drift_items: list[str] = []
    frontmatter_issues: list[str] = []
    exit_code = 0

    manifest_path = _resolve_manifest(root)

    if manifest_path:
        derive_manifest_edges(parse, root)

    if validate:
        fe, f_issues = validate_frontmatter(root)
        frontmatter = fe
        frontmatter_issues = f_issues
        stale_docs = _stale_paths_from_entries(fe)

        if manifest_path:
            c1, drift1 = validate_declared_vs_actual(parse, manifest_path)
            connections.extend(c1)
            drift_items.extend(drift1)
            connections.extend(validate_connections(parse, manifest_path))
            orphans.extend(detect_orphans(parse, manifest_path, root / "docs"))

    severed_n = len([c for c in connections if c.severed])
    gate = _compute_exit_code(
        severed_n,
        len(orphans),
        frontmatter_issues,
        len(drift_items),
        len(stale_docs),
        len(missing_docs),
    )
    gh, sh = _health_scores(
        severed_n,
        len(orphans),
        frontmatter_issues,
        len(drift_items),
        len(stale_docs),
        len(missing_docs),
    )
    # forge scan: health vector only — process exit is always 0.
    exit_code = 0

    context_data: dict[str, Any] = {
        "run_at": datetime.now(timezone.utc).isoformat(),
        "exit_code": exit_code,
        "graph_health": gh,
        "sync_health": sh,
        "health_signal": gate,
        "severed": severed_n,
        "summary": (
            f"{len(parse.files)} files, {len(orphans)} orphans, {severed_n} severed connections"
        ),
        "file_count": len(parse.files),
        "screen_count": len(parse.screens),
        "controller_count": len(parse.controllers),
        "service_count": len(parse.services),
        "drift_count": len(drift_items),
        "drift_node_ids": list(drift_items),
        "orphan_count": len(orphans),
        "orphan_node_ids": [o.path for o in orphans],
        "severed_node_ids": [c.from_id for c in connections if c.severed],
    }

    scan_result = ScanResult(
        parse=parse,
        frontmatter=frontmatter,
        connections=connections,
        orphans=orphans,
        stale_docs=stale_docs,
        missing_docs=missing_docs,
        drift_items=drift_items,
        context_data=context_data,
        frontmatter_issues=frontmatter_issues,
        exit_code=exit_code,
    )

    if update_cache and not dry_run:
        _merge_context_cache(root, context_data)

    renderers: dict[str, Any] = {
        "manifest": lambda: render_manifest(parse, output_dir, dry_run),
        "graph": lambda: render_graph(parse, output_dir, dry_run),
        "screens": lambda: render_screens(parse, output_dir, dry_run),
        "report": lambda: render_report(parse, output_dir, dry_run, scan=scan_result if validate else None),
        "validation": lambda: render_validation(scan_result, output_dir, dry_run),
    }

    selected = list(renderers.keys()) if formats == ["all"] or "all" in formats else formats
    for name in selected:
        if name == "validation" and not validate:
            continue
        fn = renderers.get(name)
        if fn:
            fn()

    return scan_result


def run_validation_only(project_path: Path) -> ScanResult:
    """Validation phases without writing artifacts (no render)."""
    root = project_path.resolve()
    primary, _, _ = detect_framework(root)
    parse = run_parser(primary, root)
    manifest_path = _resolve_manifest(root)
    if manifest_path:
        derive_manifest_edges(parse, root)
    connections: list[Any] = []
    drift_items: list[str] = []
    orphans: list[Any] = []
    frontmatter_issues: list[str] = []
    frontmatter: list[Any] = []
    stale_docs: list[str] = []

    fe, f_issues = validate_frontmatter(root)
    frontmatter = fe
    frontmatter_issues = f_issues
    stale_docs = _stale_paths_from_entries(fe)

    if manifest_path:
        c1, drift1 = validate_declared_vs_actual(parse, manifest_path)
        connections.extend(c1)
        drift_items.extend(drift1)
        connections.extend(validate_connections(parse, manifest_path))
        orphans.extend(detect_orphans(parse, manifest_path, root / "docs"))

    severed_n = len([c for c in connections if c.severed])
    gate = _compute_exit_code(
        severed_n,
        len(orphans),
        frontmatter_issues,
        len(drift_items),
        len(stale_docs),
        0,
    )
    gh, sh = _health_scores(
        severed_n,
        len(orphans),
        frontmatter_issues,
        len(drift_items),
        len(stale_docs),
        0,
    )
    exit_code = 0
    context_data = {
        "run_at": datetime.now(timezone.utc).isoformat(),
        "exit_code": exit_code,
        "graph_health": gh,
        "sync_health": sh,
        "health_signal": gate,
        "severed": severed_n,
        "summary": f"{len(parse.files)} files, {len(orphans)} orphans, {severed_n} severed connections",
        "file_count": len(parse.files),
        "screen_count": len(parse.screens),
        "controller_count": len(parse.controllers),
        "service_count": len(parse.services),
        "drift_count": len(drift_items),
        "drift_node_ids": list(drift_items),
        "orphan_count": len(orphans),
        "orphan_node_ids": [o.path for o in orphans],
        "severed_node_ids": [c.from_id for c in connections if c.severed],
    }
    return ScanResult(
        parse=parse,
        frontmatter=frontmatter,
        connections=connections,
        orphans=orphans,
        stale_docs=stale_docs,
        missing_docs=[],
        drift_items=drift_items,
        context_data=context_data,
        frontmatter_issues=frontmatter_issues,
        exit_code=exit_code,
    )


def load_validation_json(project_path: Path) -> dict[str, Any] | None:
    p = project_path / "scan" / "validation.json"
    if not p.exists():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except Exception:
        return None
