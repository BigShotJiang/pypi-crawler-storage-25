from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Tuple

from .models import FrameworkType


PRIORITY = [
    FrameworkType.FLUTTER,
    FrameworkType.REACT_NATIVE,
    FrameworkType.TYPESCRIPT,
    FrameworkType.PYTHON,
    FrameworkType.UNKNOWN,
]


def _safe_read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""


def detect_framework(root: Path) -> Tuple[FrameworkType, List[FrameworkType], Dict[FrameworkType, str]]:
    """
    Detect framework by sniffing root files.

    Returns:
        primary: FrameworkType
        candidates: list[FrameworkType]
        reasons: dict[FrameworkType, str]
    """
    reasons: Dict[FrameworkType, str] = {}
    candidates: List[FrameworkType] = []

    pubspec = root / "pubspec.yaml"
    if pubspec.exists() and (root / "lib").is_dir():
        ft = FrameworkType.FLUTTER
        candidates.append(ft)
        reasons[ft] = "pubspec.yaml + lib/ found"

    package_json = root / "package.json"
    pkg = {}
    if package_json.exists():
        try:
            pkg = json.loads(_safe_read_text(package_json) or "{}")
        except Exception:
            pkg = {}
    deps = {}
    if isinstance(pkg, dict):
        deps = {}
        for key in ("dependencies", "devDependencies"):
            if isinstance(pkg.get(key), dict):
                deps.update(pkg[key])
    dep_keys = " ".join(deps.keys()).lower() if deps else ""

    if deps and ("react-native" in dep_keys or "expo" in dep_keys):
        ft = FrameworkType.REACT_NATIVE
        candidates.append(ft)
        reasons[ft] = "package.json with react-native/expo dep"
    elif package_json.exists() or (root / "tsconfig.json").exists():
        ft = FrameworkType.TYPESCRIPT
        candidates.append(ft)
        reasons.setdefault(ft, "package.json or tsconfig.json found")

    if (root / "requirements.txt").exists() or (root / "pyproject.toml").exists() or (root / "setup.py").exists():
        ft = FrameworkType.PYTHON
        candidates.append(ft)
        reasons[ft] = "requirements.txt / pyproject.toml / setup.py found"

    # De-duplicate candidates preserving order
    seen = set()
    uniq: List[FrameworkType] = []
    for c in candidates:
        if c not in seen:
            uniq.append(c)
            seen.add(c)

    if not uniq:
        return FrameworkType.UNKNOWN, [], {FrameworkType.UNKNOWN: "No framework markers found"}

    primary = FrameworkType.UNKNOWN
    for ft in PRIORITY:
        if ft in uniq:
            primary = ft
            break

    return primary, uniq, reasons

