from __future__ import annotations

from pathlib import Path
from typing import List

from ..models import ControllerEntry, DepEdge, FrameworkType, ParseResult, ScreenEntry
from . import file_entry_for, infer_domain, iter_files, make_posix


MAX_FILE_SIZE = 500 * 1024


def _safe_read(path: Path, result: ParseResult) -> str:
    try:
        if path.stat().st_size > MAX_FILE_SIZE:
            result.skipped.append(f"Skipped large file: {path}")
            return ""
    except Exception:
        result.notes.append(f"Could not stat file: {path}")
        return ""
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        result.notes.append(f"Could not read file: {path}")
        return ""


def _load_pyproject(root: Path, result: ParseResult) -> None:
    py = root / "pyproject.toml"
    if not py.exists():
        return
    text = _safe_read(py, result)
    # Simple line-based extraction to avoid external deps
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("name") and "=" in stripped and not result.project_name:
            result.project_name = stripped.split("=", 1)[1].strip().strip("\"'")
        if stripped.startswith("version") and "=" in stripped and not result.project_version:
            result.project_version = stripped.split("=", 1)[1].strip().strip("\"'")


def parse_python(root: Path) -> ParseResult:
    root = root.expanduser().resolve()
    result = ParseResult(
        framework=FrameworkType.PYTHON,
        project_name=root.name,
        project_version="unknown",
    )
    _load_pyproject(root, result)

    screens: List[ScreenEntry] = []
    controllers: List[ControllerEntry] = []
    edges: set[DepEdge] = set()

    for path in iter_files(root, subdirs=None):
        if path.suffix != ".py":
            continue
        rel_posix = make_posix(path, root)
        result.files.append(file_entry_for(path, root))
        text = _safe_read(path, result)
        if not text:
            continue

        lower_name = path.name.lower()

        # Screens / views
        name_screen_like = any(
            lower_name.endswith(suffix)
            for suffix in ("_screen.py", "_view.py", "_panel.py")
        )
        has_ui_import = any(
            token in text[:1000]
            for token in (
                "import curses",
                "from rich",
                "import tkinter",
                "import urwid",
            )
        )
        if name_screen_like or has_ui_import:
            domain, conf = infer_domain(rel_posix, path.name)
            confidence = "high" if name_screen_like and has_ui_import else ("medium" if name_screen_like or has_ui_import else "low")
            screens.append(
                ScreenEntry(
                    name=path.stem,
                    file=rel_posix,
                    domain=domain,
                    confidence=confidence,
                    route=None,
                    nav_method=None,
                    hints=[],
                )
            )

        # Controllers / services
        if any(
            lower_name.endswith(suffix)
            for suffix in ("_service.py", "_handler.py", "_manager.py", "_controller.py")
        ):
            domain, conf = infer_domain(rel_posix, path.name)
            controllers.append(
                ControllerEntry(
                    name=path.stem,
                    file=rel_posix,
                    domain=domain,
                    confidence=conf,
                    hints=[],
                )
            )

        # Imports (project-local only)
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith("import "):
                mod = stripped.replace("import", "", 1).strip().split(" ", 1)[0]
            elif stripped.startswith("from ") and " import " in stripped:
                mod = stripped.split("import", 1)[0].replace("from", "", 1).strip()
            else:
                continue
            if not mod or mod.startswith("."):
                # relative import — approximate path if we can
                continue
            # Try to map module to a .py file in project
            candidate = root / (mod.replace(".", "/") + ".py")
            if not candidate.exists():
                continue
            try:
                target_rel = make_posix(candidate, root)
            except ValueError:
                continue
            if target_rel == rel_posix:
                continue
            edges.add(DepEdge(source=rel_posix, target=target_rel))

    result.screens = screens
    result.controllers = controllers
    result.dependencies = sorted(edges, key=lambda e: (e.source, e.target, e.kind))
    return result

