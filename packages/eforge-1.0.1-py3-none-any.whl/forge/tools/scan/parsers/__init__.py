from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable, List, Tuple

from ..models import FileEntry


SKIP_DIRS = {
    ".git",
    "build",
    ".dart_tool",
    "node_modules",
    "__pycache__",
    ".expo",
    ".idea",
    ".vscode",
    ".venv",
    "venv",
}

FORGE_DOMAIN_KEYWORDS: Dict[str, List[str]] = {
    "AUTH":    ["auth", "login", "signup", "sign_in", "session", "token", "password"],
    "LOBBY":   ["lobby", "room", "match", "queue", "waiting"],
    "CANVAS":  ["canvas", "draw", "paint", "board", "stroke"],
    "GAME":    ["game", "guess", "round", "score", "play", "word"],
    "PROFILE": ["profile", "user", "account", "avatar", "settings"],
    "PREMIUM": ["premium", "subscription", "paywall", "purchase", "billing"],
    "THEME":   ["theme", "style", "token", "color", "brand"],
    "REMOTE":  ["remote", "supabase", "api", "service", "http", "client", "repository"],
}

DEFAULT_DOMAIN = "CORE"


def make_posix(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")


def iter_files(
    project_root: Path,
    subdirs: Iterable[str] | None = None,
    root: Path | None = None,
) -> Iterable[Path]:
    bounded_root = root.resolve() if root is not None else project_root.resolve()
    bases: List[Path]
    if subdirs:
        bases = [
            (project_root / s).resolve()
            for s in subdirs
            if (project_root / s).exists()
        ]
        if not bases:
            bases = [project_root.resolve()]
    else:
        bases = [project_root.resolve()]
    seen: set[Path] = set()
    for base in bases:
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if not path.is_file():
                continue
            if path.is_symlink():
                try:
                    path.resolve().relative_to(bounded_root)
                except ValueError:
                    continue
            try:
                path.relative_to(bounded_root)
            except ValueError:
                continue  # outside root — skip silently
            # skip dirs by checking parents
            if any(part in SKIP_DIRS for part in path.parts):
                continue
            if path in seen:
                continue
            seen.add(path)
            yield path


def infer_domain(path: str, name: str) -> Tuple[str, str]:
    """
    Infer (domain, confidence) from path + filename.
    high: filename contains keyword
    medium: directory segment contains keyword
    low: loose substring match
    """
    text = f"{path}/{name}".lower()
    best_domain = DEFAULT_DOMAIN
    best_conf = "low"

    segments = text.split("/")
    fname = segments[-1] if segments else text

    for domain, keywords in FORGE_DOMAIN_KEYWORDS.items():
        for kw in keywords:
            if kw in fname:
                return domain, "high"

    for domain, keywords in FORGE_DOMAIN_KEYWORDS.items():
        for kw in keywords:
            if any(kw == seg for seg in segments):
                if best_conf != "high":
                    best_domain = domain
                    best_conf = "medium"

    if best_conf == "low":
        for domain, keywords in FORGE_DOMAIN_KEYWORDS.items():
            for kw in keywords:
                if kw in text:
                    best_domain = domain
                    best_conf = "low"
                    break

    return best_domain, best_conf


def classify_kind(name: str, parent_segments: Iterable[str]) -> str:
    lower = name.lower()
    parents = [p.lower() for p in parent_segments]
    if any(seg in ("screens", "pages", "views") for seg in parents):
        return "screen"
    if any(seg in ("controllers", "services", "hooks", "store") for seg in parents):
        return "service"
    if any(
        lower.endswith(suffix)
        for suffix in (
            "_screen.dart",
            "_page.dart",
            "_view.dart",
            "_screen.py",
            "_view.py",
            "_panel.py",
        )
    ):
        return "screen"
    if any(
        suffix in lower
        for suffix in (
            "controller",
            "provider",
            "service",
            "handler",
            "manager",
            "store",
        )
    ):
        return "controller"
    return "other"


def file_entry_for(path: Path, root: Path) -> FileEntry:
    rel = make_posix(path, root)
    domain, confidence = infer_domain(rel, path.name)
    kind = classify_kind(path.name, path.relative_to(root).parts[:-1])
    return FileEntry(path=rel, kind=kind, domain=domain, confidence=confidence)


