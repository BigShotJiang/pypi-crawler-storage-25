from __future__ import annotations

import re
from pathlib import Path
from typing import List

import yaml

from ..models import ControllerEntry, DepEdge, FrameworkType, ParseResult, ScreenEntry
from . import DEFAULT_DOMAIN, file_entry_for, infer_domain, iter_files, make_posix


MAX_FILE_SIZE = 500 * 1024  # 500 KB


def _safe_read(path: Path, result: ParseResult) -> str:
    try:
        if path.stat().st_size > MAX_FILE_SIZE:
            result.skipped.append(f"Skipped large file: {path}")
            return ""
    except Exception:
        result.notes.append(f"Could not stat file: {path}")
        return ""
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        result.notes.append(f"Could not read file: {path}")
        return ""


def _parse_pubspec(root: Path, result: ParseResult) -> None:
    pub = root / "pubspec.yaml"
    if not pub.exists():
        return
    text = _safe_read(pub, result)
    for line in text.splitlines():
        if line.strip().startswith("name:") and not result.project_name:
            result.project_name = line.split(":", 1)[1].strip().strip("\"'")
        if line.strip().startswith("version:") and not result.project_version:
            result.project_version = line.split(":", 1)[1].strip().strip("\"'")


def _load_external_deps(root: Path, result: ParseResult) -> set[str]:
    """Return the set of declared package names from pubspec.yaml.

    Reads both ``dependencies`` and ``dev_dependencies`` sections.  The
    project's own package name lives under the top-level ``name:`` key and is
    intentionally *not* included here, so self-referential ``package:appname/``
    imports are never filtered out.

    Returns an empty set (and appends a warning to ``result.notes``) if
    pubspec.yaml is absent or cannot be parsed.
    """
    pub = root / "pubspec.yaml"
    if not pub.exists():
        return set()
    text = _safe_read(pub, result)
    if not text:
        return set()
    try:
        data = yaml.safe_load(text) or {}
    except Exception as exc:
        result.notes.append(
            f"Warning: could not parse pubspec.yaml for dependency filtering — "
            f"external package edges will not be suppressed. ({exc})"
        )
        return set()
    if not isinstance(data, dict):
        return set()
    deps: set[str] = set()
    for section in ("dependencies", "dev_dependencies"):
        section_data = data.get(section) or {}
        if isinstance(section_data, dict):
            deps.update(section_data.keys())
    return deps


def parse_flutter(root: Path) -> ParseResult:
    result = ParseResult(
        framework=FrameworkType.FLUTTER,
        project_name=root.name,
        project_version="unknown",
    )
    _parse_pubspec(root, result)
    external_pkgs: set[str] = _load_external_deps(root, result)

    lib_root = root / "lib"
    if not lib_root.exists():
        result.notes.append("lib/ directory not found; scanning entire tree as fallback")

    screens: List[ScreenEntry] = []
    controllers: List[ControllerEntry] = []
    edges: set[DepEdge] = set()

    for path in iter_files(root, subdirs=("lib",)):
        if path.suffix != ".dart":
            continue
        rel_posix = make_posix(path, root)
        result.files.append(file_entry_for(path, root))
        text = _safe_read(path, result)
        if not text:
            continue
        lower_name = path.name.lower()

        # Screen heuristics
        is_screen_name = lower_name.endswith("_screen.dart") or lower_name.endswith("_page.dart")
        has_widget = any(
            kw in text[:2000]
            for kw in (
                "extends StatelessWidget",
                "extends StatefulWidget",
                "extends ConsumerWidget",
            )
        )
        if is_screen_name or has_widget:
            domain, conf = infer_domain(rel_posix, path.name)
            conf_level = "high" if is_screen_name and has_widget else ("medium" if is_screen_name or has_widget else "low")
            screens.append(
                ScreenEntry(
                    name=path.stem,
                    file=rel_posix,
                    domain=domain,
                    confidence=conf_level,
                    route=None,
                    nav_method=None,
                    hints=[],
                )
            )

        # Controller heuristics
        if any(
            lower_name.endswith(suffix)
            for suffix in (
                "_controller.dart",
                "_provider.dart",
                "_notifier.dart",
                "_cubit.dart",
                "_bloc.dart",
            )
        ):
            domain, conf = infer_domain(rel_posix, path.name)
            controllers.append(
                ControllerEntry(
                    name=path.stem,
                    file=rel_posix,
                    domain=domain,
                    confidence=conf,
                    hints=[],
                )
            )

        # Imports
        for line in text.splitlines():
            line = line.strip()
            if not line.startswith("import "):
                continue
            m = re.search(r"['\"]([^'\"]+)['\"]", line)
            if not m:
                continue
            target = m.group(1)
            if target.startswith("package:"):
                # Extract the package name (segment between "package:" and the
                # first "/") and skip edges for external dependencies so that
                # third-party packages (provider, dio, etc.) don't pollute the
                # internal dependency graph.
                pkg_name = target[len("package:"):].split("/")[0]
                if pkg_name in external_pkgs:
                    continue
                # package:appname/path → lib/path
                parts = target.split("/", 1)
                if len(parts) == 2:
                    target_rel = "lib/" + parts[1]
                else:
                    continue
            elif target.startswith("./") or target.startswith("../"):
                target_path = (path.parent / target).resolve()
                if not target_path.exists():
                    continue
                try:
                    target_rel = make_posix(target_path, root)
                except ValueError:
                    continue
            else:
                # absolute or third-party import
                continue
            if target_rel == rel_posix:
                continue
            edges.add(DepEdge(source=rel_posix, target=target_rel))

    result.screens = screens
    result.controllers = controllers
    result.dependencies = sorted(edges, key=lambda e: (e.source, e.target, e.kind))
    return result

