from __future__ import annotations

import re
from pathlib import Path
from typing import List

from ..models import ControllerEntry, DepEdge, FrameworkType, ParseResult, ScreenEntry
from . import file_entry_for, infer_domain, iter_files, make_posix


MAX_FILE_SIZE = 500 * 1024


def _safe_read(path: Path, result: ParseResult) -> str:
    try:
        if path.stat().st_size > MAX_FILE_SIZE:
            result.skipped.append(f"Skipped large file: {path}")
            return ""
    except Exception:
        result.notes.append(f"Could not stat file: {path}")
        return ""
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        result.notes.append(f"Could not read file: {path}")
        return ""


def _load_package_json(root: Path, result: ParseResult) -> None:
    pkg = root / "package.json"
    if not pkg.exists():
        return
    import json

    try:
        data = json.loads(_safe_read(pkg, result) or "{}")
    except Exception:
        result.notes.append("Could not parse package.json")
        return
    if isinstance(data, dict):
        if not result.project_name and isinstance(data.get("name"), str):
            result.project_name = data["name"]
        if not result.project_version and isinstance(data.get("version"), str):
            result.project_version = data["version"]


def parse_react_native(root: Path) -> ParseResult:
    result = ParseResult(
        framework=FrameworkType.REACT_NATIVE,
        project_name=root.name,
        project_version="unknown",
    )
    _load_package_json(root, result)

    subdirs = ("src", "app", "screens", "components")
    screens: List[ScreenEntry] = []
    controllers: List[ControllerEntry] = []
    edges: set[DepEdge] = set()

    for path in iter_files(root, subdirs=subdirs):
        if path.suffix.lower() not in {".tsx", ".jsx", ".ts", ".js"}:
            continue
        rel_posix = make_posix(path, root)
        result.files.append(file_entry_for(path, root))
        text = _safe_read(path, result)
        if not text:
            continue

        lower_name = path.stem.lower()
        parents = [p.lower() for p in path.relative_to(root).parts[:-1]]

        # Screen heuristics
        in_screens_folder = any(seg == "screens" for seg in parents)
        in_app_folder = any(seg == "app" for seg in parents)
        name_screen_like = any(
            lower_name.endswith(suffix)
            for suffix in ("screen", "page", "view")
        )
        if in_screens_folder or in_app_folder or name_screen_like:
            domain, conf = infer_domain(rel_posix, path.name)
            confidence = "high" if in_screens_folder or in_app_folder else "medium"
            nav_method = None
            if "useNavigation(" in text:
                nav_method = "Navigator"
            if "Stack.Screen" in text or "<Stack" in text:
                nav_method = "Stack"
            if "Tab.Navigator" in text or "<Tab.Navigator" in text:
                nav_method = "Tab"
            if in_app_folder:
                nav_method = "FileRouter"
            screens.append(
                ScreenEntry(
                    name=path.stem,
                    file=rel_posix,
                    domain=domain,
                    confidence=confidence,
                    route=None,
                    nav_method=nav_method,
                    hints=[],
                )
            )

        # Controllers / services
        if any(seg in ("hooks", "store", "context", "redux", "state") for seg in parents) or lower_name.startswith(
            "use"
        ):
            domain, conf = infer_domain(rel_posix, path.name)
            controllers.append(
                ControllerEntry(
                    name=path.stem,
                    file=rel_posix,
                    domain=domain,
                    confidence=conf,
                    hints=[],
                )
            )

        # Imports (relative only)
        for line in text.splitlines():
            line = line.strip()
            m = None
            if line.startswith("import "):
                m = re.search(r"from ['\"]([^'\"]+)['\"]", line)
            elif "require(" in line:
                m = re.search(r"require\(['\"]([^'\"]+)['\"]\)", line)
            if not m:
                continue
            target = m.group(1)
            if not (target.startswith("./") or target.startswith("../")):
                continue
            target_path = (path.parent / target).resolve()
            if not target_path.exists():
                continue
            try:
                target_rel = make_posix(target_path, root)
            except ValueError:
                continue
            if target_rel == rel_posix:
                continue
            edges.add(DepEdge(source=rel_posix, target=target_rel))

    result.screens = screens
    result.controllers = controllers
    result.dependencies = sorted(edges, key=lambda e: (e.source, e.target, e.kind))
    return result

