from __future__ import annotations

import re
from pathlib import Path
from typing import List

from ..models import ControllerEntry, DepEdge, FrameworkType, ParseResult, ScreenEntry
from . import file_entry_for, infer_domain, iter_files, make_posix


MAX_FILE_SIZE = 500 * 1024


def _safe_read(path: Path, result: ParseResult) -> str:
    try:
        if path.stat().st_size > MAX_FILE_SIZE:
            result.skipped.append(f"Skipped large file: {path}")
            return ""
    except Exception:
        result.notes.append(f"Could not stat file: {path}")
        return ""
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        result.notes.append(f"Could not read file: {path}")
        return ""


def _load_package_json(root: Path, result: ParseResult) -> None:
    pkg = root / "package.json"
    if not pkg.exists():
        return
    import json

    try:
        data = json.loads(_safe_read(pkg, result) or "{}")
    except Exception:
        result.notes.append("Could not parse package.json")
        return
    if isinstance(data, dict):
        if not result.project_name and isinstance(data.get("name"), str):
            result.project_name = data["name"]
        if not result.project_version and isinstance(data.get("version"), str):
            result.project_version = data["version"]


def parse_typescript(root: Path) -> ParseResult:
    result = ParseResult(
        framework=FrameworkType.TYPESCRIPT,
        project_name=root.name,
        project_version="unknown",
    )
    _load_package_json(root, result)

    subdirs = ("src", "pages", "views", "screens")
    screens: List[ScreenEntry] = []
    controllers: List[ControllerEntry] = []
    edges: set[DepEdge] = set()

    for path in iter_files(root, subdirs=subdirs):
        if path.suffix.lower() not in {".ts", ".tsx", ".js", ".jsx"}:
            continue
        rel_posix = make_posix(path, root)
        result.files.append(file_entry_for(path, root))
        text = _safe_read(path, result)
        if not text:
            continue

        lower_name = path.stem.lower()
        parents = [p.lower() for p in path.relative_to(root).parts[:-1]]

        # Screens
        in_screen_dirs = any(seg in ("pages", "views", "screens") for seg in parents)
        name_screen_like = any(
            lower_name.endswith(suffix)
            for suffix in ("page", "view", "screen")
        )
        if in_screen_dirs or name_screen_like:
            domain, _ = infer_domain(rel_posix, path.name)
            confidence = "high" if in_screen_dirs else "medium"
            nav_method = None
            if "useRouter(" in text or "from 'next/router'" in text or "from 'next/navigation'" in text:
                nav_method = "NextRouter"
            if "BrowserRouter" in text or "react-router" in text or "createBrowserRouter" in text:
                nav_method = "ReactRouter"
            screens.append(
                ScreenEntry(
                    name=path.stem,
                    file=rel_posix,
                    domain=domain,
                    confidence=confidence,
                    route=None,
                    nav_method=nav_method,
                    hints=[],
                )
            )

        # Controllers / services
        in_service_dirs = any(
            seg in ("services", "hooks", "store", "api", "lib")
            for seg in parents
        )
        name_service_like = any(
            lower_name.endswith(suffix)
            for suffix in ("service", "hook", "store", "api", "client")
        )
        if in_service_dirs or name_service_like:
            domain, conf = infer_domain(rel_posix, path.name)
            controllers.append(
                ControllerEntry(
                    name=path.stem,
                    file=rel_posix,
                    domain=domain,
                    confidence=conf,
                    hints=[],
                )
            )

        # Imports
        for line in text.splitlines():
            line = line.strip()
            m = None
            if line.startswith("import "):
                m = re.search(r"from ['\"]([^'\"]+)['\"]", line)
            elif "require(" in line:
                m = re.search(r"require\(['\"]([^'\"]+)['\"]\)", line)
            if not m:
                continue
            target = m.group(1)
            if not (target.startswith("./") or target.startswith("../")):
                continue
            target_path = (path.parent / target).resolve()
            if not target_path.exists():
                continue
            try:
                target_rel = make_posix(target_path, root)
            except ValueError:
                continue
            if target_rel == rel_posix:
                continue
            edges.add(DepEdge(source=rel_posix, target=target_rel))

    result.screens = screens
    result.controllers = controllers
    result.dependencies = sorted(edges, key=lambda e: (e.source, e.target, e.kind))
    return result

