from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from forge.tools.scan.models import Connection, ParseResult


def _load_manifest_dict(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _controller_rows(data: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for key in ("controllers", "hooks"):
        block = data.get(key)
        if isinstance(block, list):
            for row in block:
                if isinstance(row, dict):
                    out.append(row)
        elif isinstance(block, dict):
            for _k, row in block.items():
                if isinstance(row, dict):
                    out.append(row)
    return out


def _screen_rows(data: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    block = data.get("screens")
    if isinstance(block, list):
        for row in block:
            if isinstance(row, dict):
                out.append(row)
    elif isinstance(block, dict):
        for _k, row in block.items():
            if isinstance(row, dict):
                out.append(row)
    return out


def _parse_name_list(val: Any) -> list[str]:
    if val is None:
        return []
    if isinstance(val, str):
        return [val.strip()] if val.strip() else []
    if isinstance(val, list):
        return [str(x).strip() for x in val if str(x).strip()]
    return []


def validate_connections(
    parse: ParseResult,
    manifest_path: Path,
) -> list[Connection]:
    """
    Cross-check manifest wiring (reads/writes/fires/watches) against parser inventory.
    """
    connections: list[Connection] = []
    data = _load_manifest_dict(manifest_path)
    names_from_parse: set[str] = set()
    for c in parse.controllers:
        names_from_parse.add(c.name)
        names_from_parse.add(c.name.replace("_", ""))
    for f in parse.files:
        stem = Path(f.path).stem
        names_from_parse.add(stem)

    # services from manifest
    manifest_service_names: set[str] = set()
    for row in data.get("services") or []:
        if isinstance(row, dict) and row.get("name"):
            manifest_service_names.add(str(row["name"]))
        elif isinstance(row, str):
            manifest_service_names.add(row)

    def _ref_exists(ref: str) -> bool:
        r = ref.strip()
        if r in manifest_service_names:
            return True
        if r in names_from_parse:
            return True
        for n in names_from_parse:
            if r.lower() in n.lower() or n.lower() in r.lower():
                return True
        return False

    ctrl_by_name: dict[str, dict[str, Any]] = {}
    for row in _controller_rows(data):
        nm = str(row.get("name") or row.get("id") or "")
        if nm:
            ctrl_by_name[nm] = row

    for row in _controller_rows(data):
        cid = str(row.get("name") or row.get("id") or "controller")
        for ref in _parse_name_list(row.get("reads")):
            ok = _ref_exists(ref)
            connections.append(
                Connection(
                    from_id=f"{cid}.reads",
                    to_id=ref,
                    kind="reads",
                    declared=True,
                    actual=ok,
                    severed=not ok,
                    undeclared=False,
                )
            )
        for ref in _parse_name_list(row.get("writes")):
            ok = _ref_exists(ref)
            connections.append(
                Connection(
                    from_id=f"{cid}.writes",
                    to_id=ref,
                    kind="writes",
                    declared=True,
                    actual=ok,
                    severed=not ok,
                    undeclared=False,
                )
            )

    watches_index: dict[str, list[str]] = {}
    for srow in _screen_rows(data):
        sname = str(srow.get("name") or srow.get("id") or "screen")
        for w in _parse_name_list(srow.get("watches")):
            watches_index.setdefault(w, []).append(sname)

    for row in _controller_rows(data):
        cid = str(row.get("name") or row.get("id") or "controller")
        fires = _parse_name_list(row.get("fires"))
        for ev in fires:
            subs = watches_index.get(ev) or watches_index.get(cid) or []
            has_sub = bool(subs)
            connections.append(
                Connection(
                    from_id=f"{cid}.fires",
                    to_id=ev,
                    kind="fires",
                    declared=True,
                    actual=has_sub,
                    severed=not has_sub and bool(ev),
                    undeclared=False,
                )
            )

    for srow in _screen_rows(data):
        sname = str(srow.get("name") or srow.get("id") or "screen")
        for w in _parse_name_list(srow.get("watches")):
            ok = w in ctrl_by_name or _ref_exists(w)
            connections.append(
                Connection(
                    from_id=f"{sname}.watches",
                    to_id=w,
                    kind="watches",
                    declared=True,
                    actual=ok,
                    severed=not ok,
                    undeclared=False,
                )
            )

    return connections
