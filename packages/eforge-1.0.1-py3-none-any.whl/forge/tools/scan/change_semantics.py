from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import yaml

CHANGE_KINDS: dict[str, dict[str, Any]] = {
    "interface_contract_change": {
        "description": "reads/writes/fires changed",
        "traverse": ["watchers", "dependents"],
        "severity": "blocker",
    },
    "feature_swap": {
        "description": "variant or feature flag changed",
        "traverse": ["variant_consumers"],
        "severity": "warn",
    },
    "domain_reassignment": {
        "description": "controller domain changed",
        "traverse": ["error_codes", "watchers"],
        "severity": "blocker",
    },
    "architecture_change": {
        "description": "structural pattern changed",
        "traverse": ["all_affected_layers"],
        "requires_adr": True,
        "severity": "blocker",
    },
    "component_swap": {
        "description": "UI component replaced",
        "traverse": ["screen_consumers"],
        "severity": "warn",
    },
}


@dataclass
class SemanticChange:
    kind: str
    changed_node: str
    old_value: dict[str, Any] | None
    new_value: dict[str, Any] | None
    affected: list[str] = field(default_factory=list)
    requires_adr: bool = False
    severity: str = "warn"


def _ctrl_rows(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for key in ("controllers", "hooks"):
        block = manifest.get(key)
        if isinstance(block, list):
            out.extend(r for r in block if isinstance(r, dict))
        elif isinstance(block, dict):
            out.extend(r for r in block.values() if isinstance(r, dict))
    return out


def _screen_rows(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    block = manifest.get("screens")
    out: list[dict[str, Any]] = []
    if isinstance(block, list):
        out.extend(r for r in block if isinstance(r, dict))
    elif isinstance(block, dict):
        out.extend(r for r in block.values() if isinstance(r, dict))
    return out


def _eq_list(a: Any, b: Any) -> bool:
    return list(a or []) == list(b or [])


def traverse_graph(
    manifest: dict[str, Any],
    changed_node: str,
    traverse_kinds: list[str],
    depth: int = 2,
) -> list[str]:
    """
    Walk manifest relationships starting at changed_node (controller name or path).
    """
    affected: list[str] = []
    ctrls = {str(c.get("name") or c.get("id") or ""): c for c in _ctrl_rows(manifest)}
    screens = _screen_rows(manifest)

    def watchers_for(ctrl: str) -> list[str]:
        names: list[str] = []
        for s in screens:
            w = s.get("watches") or []
            if isinstance(w, str):
                w = [w]
            if not isinstance(w, list):
                continue
            if ctrl in [str(x) for x in w]:
                nm = str(s.get("name") or s.get("id") or "")
                if nm:
                    names.append(nm)
        return names

    def dependents_for(service: str) -> list[str]:
        out: list[str] = []
        for nm, c in ctrls.items():
            if not nm:
                continue
            reads = c.get("reads") or []
            if isinstance(reads, str):
                reads = [reads]
            if isinstance(reads, list) and service in [str(x) for x in reads]:
                out.append(nm)
        return out

    frontier = [changed_node]
    seen: set[str] = {changed_node}
    for _ in range(max(1, depth)):
        nxt: list[str] = []
        for cur in frontier:
            for tk in traverse_kinds:
                if tk == "watchers":
                    for w in watchers_for(cur):
                        if w not in seen:
                            seen.add(w)
                            affected.append(w)
                            nxt.append(w)
                elif tk == "dependents":
                    for d in dependents_for(cur):
                        if d not in seen:
                            seen.add(d)
                            affected.append(d)
                            nxt.append(d)
                elif tk == "error_codes":
                    c = ctrls.get(cur)
                    if c and c.get("domain"):
                        affected.append(f"ERROR_CODES:{c.get('domain')}")
                elif tk in ("variant_consumers", "screen_consumers", "all_affected_layers"):
                    affected.append(f"{tk}:{cur}")
        frontier = nxt
        if not frontier:
            break
    return list(dict.fromkeys(affected))


def classify_change(old_manifest: dict[str, Any], new_manifest: dict[str, Any]) -> list[SemanticChange]:
    """
    Diff two manifest dicts and emit high-level semantic change records.
    Never raises.
    """
    out: list[SemanticChange] = []
    try:
        old_c = {str(c.get("name") or c.get("id") or ""): c for c in _ctrl_rows(old_manifest)}
        new_c = {str(c.get("name") or c.get("id") or ""): c for c in _ctrl_rows(new_manifest)}
        all_names = sorted(set(old_c.keys()) | set(new_c.keys()) - {""})
        for name in all_names:
            o = old_c.get(name) or {}
            n = new_c.get(name) or {}
            if _eq_list(o.get("reads"), n.get("reads")) and _eq_list(o.get("writes"), n.get("writes")) and _eq_list(
                o.get("fires"), n.get("fires")
            ):
                pass
            else:
                if o != n and (o or n):
                    meta = CHANGE_KINDS["interface_contract_change"]
                    out.append(
                        SemanticChange(
                            kind="interface_contract_change",
                            changed_node=name,
                            old_value=dict(o),
                            new_value=dict(n),
                            affected=traverse_graph(new_manifest, name, meta["traverse"], depth=2),
                            requires_adr=False,
                            severity=str(meta["severity"]),
                        )
                    )
            if (o.get("domain") or "") != (n.get("domain") or "") and (o or n):
                meta = CHANGE_KINDS["domain_reassignment"]
                out.append(
                    SemanticChange(
                        kind="domain_reassignment",
                        changed_node=name,
                        old_value={"domain": o.get("domain")},
                        new_value={"domain": n.get("domain")},
                        affected=traverse_graph(new_manifest, name, meta["traverse"], depth=2),
                        requires_adr=False,
                        severity=str(meta["severity"]),
                    )
                )

        old_s = {str(s.get("name") or s.get("id") or ""): s for s in _screen_rows(old_manifest)}
        new_s = {str(s.get("name") or s.get("id") or ""): s for s in _screen_rows(new_manifest)}
        for name in sorted(set(old_s.keys()) | set(new_s.keys()) - {""}):
            o = old_s.get(name) or {}
            n = new_s.get(name) or {}
            if not _eq_list(o.get("watches"), n.get("watches")) and (o or n):
                meta = CHANGE_KINDS["interface_contract_change"]
                out.append(
                    SemanticChange(
                        kind="interface_contract_change",
                        changed_node=f"screen:{name}",
                        old_value=dict(o),
                        new_value=dict(n),
                        affected=traverse_graph(new_manifest, name, meta["traverse"], depth=2),
                        requires_adr=False,
                        severity=str(meta["severity"]),
                    )
                )
            if (o.get("variant") or "") != (n.get("variant") or "") and (o or n):
                meta = CHANGE_KINDS["component_swap"]
                out.append(
                    SemanticChange(
                        kind="component_swap",
                        changed_node=f"screen:{name}",
                        old_value={"variant": o.get("variant")},
                        new_value={"variant": n.get("variant")},
                        affected=traverse_graph(
                            new_manifest, name, meta["traverse"], depth=2
                        ),
                        requires_adr=False,
                        severity=str(meta["severity"]),
                    )
                )
    except Exception:
        return []
    return out


def load_change_semantics_yaml(path: Any) -> dict[str, Any]:
    # DEPRECATED: change-impact.yaml — use .forge/impact-rules.yaml via _load_rules()
    # Preserved for scan/classifier backward compat; returns {} when missing.
    """Load optional change-impact.yaml (change_kinds); returns {} on failure."""
    try:
        from pathlib import Path

        p = Path(path)
        if not p.is_file():
            return {}
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}
