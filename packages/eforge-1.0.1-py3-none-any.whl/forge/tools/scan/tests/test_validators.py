from __future__ import annotations

from pathlib import Path

import yaml

from forge.tools.scan.models import FrameworkType, ParseResult
from forge.tools.scan.scanner import run_parser
from forge.tools.scan.validators.declared_vs_actual import validate_declared_vs_actual
from forge.tools.scan.validators.connection_validator import validate_connections
from forge.tools.scan.validators.frontmatter_validator import validate_frontmatter, KNOWN_TYPES
from forge.tools.scan.validators.orphan_detector import detect_orphans


def test_declared_vs_actual_finds_severed(tmp_path: Path) -> None:
    man = {
        "screens": [{"name": "Home", "file": "app/home_screen.py"}],
    }
    (tmp_path / "manifest.yaml").write_text(yaml.safe_dump(man), encoding="utf-8")
    parse = ParseResult(framework=FrameworkType.PYTHON, project_name="x", project_version="1")
    conns, drift = validate_declared_vs_actual(parse, tmp_path / "manifest.yaml")
    assert any(c.severed for c in conns)
    assert drift


def test_declared_vs_actual_finds_undeclared(tmp_path: Path) -> None:
    (tmp_path / "app").mkdir()
    (tmp_path / "app" / "x_screen.py").write_text("# ui\n", encoding="utf-8")
    man = {
        "screens": [{"name": "Home", "file": "app/home_screen.py"}],
        "controllers": [{"name": "C", "file": "app/c_controller.py"}],
    }
    (tmp_path / "app" / "home_screen.py").write_text("# ui\n", encoding="utf-8")
    (tmp_path / "app" / "c_controller.py").write_text("# c\n", encoding="utf-8")
    (tmp_path / "manifest.yaml").write_text(yaml.safe_dump(man), encoding="utf-8")
    parse = run_parser(FrameworkType.PYTHON, tmp_path)
    conns, drift = validate_declared_vs_actual(parse, tmp_path / "manifest.yaml")
    assert any(c.undeclared for c in conns)
    assert any("Undeclared" in d for d in drift)


def test_frontmatter_validator_missing_fields(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "a.md").write_text("---\nid: a\ntype: tool\nstatus: current\n---\n", encoding="utf-8")
    entries, issues = validate_frontmatter(tmp_path)
    assert entries
    assert any("last_updated" in i for i in issues)


def test_frontmatter_validator_stale_status(tmp_path: Path) -> None:
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "b.md").write_text(
        "---\nid: b\ntype: tool\nstatus: current\nlast_updated: 2020-01-01\n---\n",
        encoding="utf-8",
    )
    entries, issues = validate_frontmatter(tmp_path)
    assert any("stale threshold" in i for i in issues)
    assert entries[0].path.startswith("docs/")


def test_connection_validator_finds_severed_reads(tmp_path: Path) -> None:
    man = {
        "controllers": [
            {"name": "C1", "file": "app/c1_controller.py", "reads": ["DoesNotExistSvc"]},
        ],
    }
    (tmp_path / "manifest.yaml").write_text(yaml.safe_dump(man), encoding="utf-8")
    (tmp_path / "app").mkdir()
    (tmp_path / "app" / "c1_controller.py").write_text("# x\n", encoding="utf-8")
    parse = run_parser(FrameworkType.PYTHON, tmp_path)
    conns = validate_connections(parse, tmp_path / "manifest.yaml")
    assert any(c.severed and c.kind == "reads" for c in conns)


def test_connection_validator_finds_orphaned_fires(tmp_path: Path) -> None:
    man = {
        "controllers": [
            {"name": "C1", "file": "app/c1_controller.py", "fires": ["orphan_event"]},
        ],
        "screens": [{"name": "S1", "file": "app/s1_screen.py"}],
    }
    (tmp_path / "manifest.yaml").write_text(yaml.safe_dump(man), encoding="utf-8")
    (tmp_path / "app").mkdir()
    (tmp_path / "app" / "c1_controller.py").write_text("# x\n", encoding="utf-8")
    (tmp_path / "app" / "s1_screen.py").write_text("# ui\n", encoding="utf-8")
    parse = run_parser(FrameworkType.PYTHON, tmp_path)
    conns = validate_connections(parse, tmp_path / "manifest.yaml")
    assert any(c.kind == "fires" and c.severed for c in conns)


def test_orphan_detector_finds_unused_files(tmp_path: Path) -> None:
    man = {
        "screens": [{"name": "S", "file": "app/s_screen.py"}],
        "controllers": [{"name": "C", "file": "app/c_controller.py"}],
    }
    (tmp_path / "manifest.yaml").write_text(yaml.safe_dump(man), encoding="utf-8")
    (tmp_path / "app").mkdir()
    (tmp_path / "app" / "s_screen.py").write_text("# ui\n", encoding="utf-8")
    (tmp_path / "app" / "c_controller.py").write_text("# c\n", encoding="utf-8")
    (tmp_path / "app" / "floater_controller.py").write_text("# orphan\n", encoding="utf-8")
    parse = run_parser(FrameworkType.PYTHON, tmp_path)
    docs = tmp_path / "docs"
    docs.mkdir()
    orphans = detect_orphans(parse, tmp_path / "manifest.yaml", docs)
    assert any(o.kind == "file" and "floater_controller" in o.path for o in orphans)


def test_orphan_detector_finds_orphaned_error_codes(tmp_path: Path) -> None:
    man = {"controllers": [{"name": "C", "file": "app/c.py", "domain": "LOBBY"}]}
    (tmp_path / "manifest.yaml").write_text(yaml.safe_dump(man), encoding="utf-8")
    (tmp_path / "app").mkdir()
    (tmp_path / "app" / "c.py").write_text("# c\n", encoding="utf-8")
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "ERROR_CODES.md").write_text("## AUTH\n\n- E1\n", encoding="utf-8")
    parse = ParseResult(framework=FrameworkType.PYTHON, project_name="x", project_version="1")
    orphans = detect_orphans(parse, tmp_path / "manifest.yaml", docs)
    assert any(o.kind == "error_code" for o in orphans)


def test_known_types_includes_tool() -> None:
    assert "tool" in KNOWN_TYPES
