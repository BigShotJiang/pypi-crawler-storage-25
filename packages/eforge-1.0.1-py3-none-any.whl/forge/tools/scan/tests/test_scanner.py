from __future__ import annotations

from pathlib import Path

from forge.tools.scan.scanner import run_scan


def test_run_scan_no_validate_writes_manifest(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text('[project]\nname = "p"\n', encoding="utf-8")
    out = tmp_path / "out"
    res = run_scan(
        tmp_path,
        out,
        ["manifest"],
        dry_run=False,
        validate=False,
        update_cache=False,
    )
    assert res.exit_code == 0
    assert (out / "manifest.draft.yaml").is_file()
