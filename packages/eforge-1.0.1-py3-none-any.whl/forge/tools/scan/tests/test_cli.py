from __future__ import annotations

from pathlib import Path

from click.testing import CliRunner

from forge.cli import main


def test_scan_check_invokes(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text('[project]\nname = "t"\n', encoding="utf-8")
    (tmp_path / "docs").mkdir()
    runner = CliRunner()
    r = runner.invoke(main, ["scan", str(tmp_path), "--check"])
    assert r.exit_code in (0, 1, 2)


def test_scan_dry_run_no_validate(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text('[project]\nname = "t"\n', encoding="utf-8")
    runner = CliRunner()
    r = runner.invoke(main, ["scan", str(tmp_path), "--dry-run", "--no-validate"])
    assert r.exit_code == 0
