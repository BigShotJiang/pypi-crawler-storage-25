from __future__ import annotations

from pathlib import Path

from forge.tools.scan.models import FrameworkType
from forge.tools.scan.scanner import run_parser


def test_parse_python_finds_py_files(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text('[project]\nname = "p"\nversion="1"\n', encoding="utf-8")
    (tmp_path / "app").mkdir()
    (tmp_path / "app" / "main.py").write_text("x = 1\n", encoding="utf-8")
    res = run_parser(FrameworkType.PYTHON, tmp_path)
    assert any("app/main.py" in f.path for f in res.files)
