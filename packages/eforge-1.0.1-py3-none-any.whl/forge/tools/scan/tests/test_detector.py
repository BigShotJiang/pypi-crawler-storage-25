from __future__ import annotations

from pathlib import Path

from forge.tools.scan.detector import detect_framework
from forge.tools.scan.models import FrameworkType


def test_detect_python_project(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text('[project]\nname = "x"\n', encoding="utf-8")
    primary, cands, _ = detect_framework(tmp_path)
    assert primary == FrameworkType.PYTHON
    assert FrameworkType.PYTHON in cands


def test_detect_flutter_project(tmp_path: Path) -> None:
    (tmp_path / "pubspec.yaml").write_text("name: demo\n", encoding="utf-8")
    (tmp_path / "lib").mkdir()
    primary, _, _ = detect_framework(tmp_path)
    assert primary == FrameworkType.FLUTTER
