from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from forge.tools.scan.change_semantics import (
    CHANGE_KINDS,
    classify_change,
    load_change_semantics_yaml,
    traverse_graph,
)


def test_classify_reads_change() -> None:
    old = {"controllers": [{"name": "C", "reads": ["A"]}]}
    new = {"controllers": [{"name": "C", "reads": ["B"]}]}
    out = classify_change(old, new)
    assert any(x.kind == "interface_contract_change" for x in out)


def test_classify_domain_change() -> None:
    old = {"controllers": [{"name": "C", "domain": "AUTH"}]}
    new = {"controllers": [{"name": "C", "domain": "LOBBY"}]}
    out = classify_change(old, new)
    assert any(x.kind == "domain_reassignment" for x in out)


def test_classify_no_change() -> None:
    m = {"controllers": [{"name": "C", "reads": ["S"]}]}
    assert classify_change(m, m) == []


def test_traverse_watchers() -> None:
    m = {
        "controllers": [{"name": "C", "domain": "X"}],
        "screens": [{"name": "S", "watches": ["C"]}],
    }
    got = traverse_graph(m, "C", ["watchers"], depth=2)
    assert "S" in got


def test_traverse_dependents() -> None:
    m = {
        "controllers": [
            {"name": "C1", "reads": ["Svc"]},
            {"name": "C2", "reads": []},
        ],
        "services": [{"name": "Svc"}],
    }
    got = traverse_graph(m, "Svc", ["dependents"], depth=2)
    assert "C1" in got


@pytest.mark.skip(
    reason="change-impact.yaml system deprecated "
    "in orchestrator.py — tests preserved "
    "for reference only"
)
def test_change_semantics_yaml_valid() -> None:
    root = Path(__file__).resolve().parents[4]
    data = load_change_semantics_yaml(root / "docs" / "change-impact.yaml")
    assert data.get("schema_version") == 1
    kinds = data.get("change_kinds")
    assert isinstance(kinds, list) and kinds
    yaml.safe_dump(data)


def test_change_kinds_dict() -> None:
    assert "interface_contract_change" in CHANGE_KINDS
