from __future__ import annotations

from pathlib import Path

import yaml

from forge.tools.scan.models import ControllerEntry, FrameworkType, ParseResult, ScreenEntry
from forge.tools.scan.scanner import derive_manifest_edges


def test_derive_manifest_edges_wires_watchers(tmp_path: Path) -> None:
    man = {
        "screens": {"s1": {"file": "lib/a.dart", "controller": "C1"}},
        "controllers": {"C1": {"file": "lib/c1.dart", "domain": "D"}},
        "services": {},
    }
    (tmp_path / "manifest.yaml").write_text(yaml.safe_dump(man), encoding="utf-8")
    parse = ParseResult(
        framework=FrameworkType.FLUTTER,
        project_name="x",
        project_version="1",
        screens=[
            ScreenEntry(
                name="a",
                file="lib/a.dart",
                domain="D",
                confidence="high",
                route=None,
                nav_method=None,
            )
        ],
        controllers=[
            ControllerEntry(name="c1", file="lib/c1.dart", domain="D", confidence="high"),
        ],
    )
    derive_manifest_edges(parse, tmp_path)
    assert parse.controllers[0].derived_watchers == ["a"]


def test_derive_manifest_edges_wires_consumers(tmp_path: Path) -> None:
    man = {
        "screens": {},
        "controllers": {
            "c": {"file": "lib/c.dart", "domain": "D", "depends_on": ["Svc"]},
        },
        "services": {"Svc": {"file": "lib/s.dart", "domain": "REMOTE"}},
    }
    (tmp_path / "manifest.yaml").write_text(yaml.safe_dump(man), encoding="utf-8")
    parse = ParseResult(
        framework=FrameworkType.FLUTTER,
        project_name="x",
        project_version="1",
        controllers=[
            ControllerEntry(name="c", file="lib/c.dart", domain="D", confidence="high"),
        ],
    )
    derive_manifest_edges(parse, tmp_path)
    assert len(parse.services) == 1
    assert parse.services[0].name == "Svc"
    assert "c" in parse.services[0].derived_consumers


def test_derive_siblings_shared_watches(tmp_path: Path) -> None:
    man = {
        "screens": {
            "a": {"file": "lib/a.dart", "watches": ["X"]},
            "b": {"file": "lib/b.dart", "watches": ["X"]},
        },
        "controllers": {"X": {"file": "lib/x.dart", "domain": "D"}},
        "services": {},
    }
    (tmp_path / "manifest.yaml").write_text(yaml.safe_dump(man), encoding="utf-8")
    parse = ParseResult(
        framework=FrameworkType.FLUTTER,
        project_name="x",
        project_version="1",
        screens=[
            ScreenEntry(name="a", file="lib/a.dart", domain="D", confidence="high", route=None, nav_method=None),
            ScreenEntry(name="b", file="lib/b.dart", domain="D", confidence="high", route=None, nav_method=None),
        ],
        controllers=[
            ControllerEntry(name="x", file="lib/x.dart", domain="D", confidence="high"),
        ],
    )
    derive_manifest_edges(parse, tmp_path)
    sa = parse.screens[0]
    sb = parse.screens[1]
    assert "b" in sa.derived_siblings
    assert "a" in sb.derived_siblings
