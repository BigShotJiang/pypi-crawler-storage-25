from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, List


class FrameworkType(Enum):
    FLUTTER = "flutter"
    REACT_NATIVE = "react_native"
    TYPESCRIPT = "typescript"
    PYTHON = "python"
    UNKNOWN = "unknown"


@dataclass
class FileEntry:
    path: str  # POSIX, relative to project root
    kind: str  # "screen" | "controller" | "service" | "other"
    domain: str  # inferred Forge domain
    confidence: str  # "high" | "medium" | "low"


@dataclass
class ScreenEntry:
    name: str  # e.g. "LoginScreen"
    file: str  # POSIX relative path
    domain: str
    confidence: str
    route: str | None
    nav_method: str | None  # "GoRouter" | "Navigator" | "Stack" | "FileRouter" | "Unknown" | None
    hints: List[str] = field(default_factory=list)
    parent_id: str | None = None
    children: List[str] = field(default_factory=list)
    derived_siblings: List[str] = field(default_factory=list)


@dataclass
class ControllerEntry:
    name: str
    file: str
    domain: str
    confidence: str
    hints: List[str] = field(default_factory=list)
    parent_id: str | None = None
    derived_watchers: List[str] = field(default_factory=list)


@dataclass
class ServiceEntry:
    name: str
    file: str
    domain: str
    confidence: str
    hints: List[str] = field(default_factory=list)
    derived_consumers: List[str] = field(default_factory=list)


@dataclass(eq=True, frozen=True)
class DepEdge:
    source: str  # POSIX relative path
    target: str  # POSIX relative path
    kind: str = "import"


@dataclass
class ParseResult:
    framework: FrameworkType
    project_name: str
    project_version: str
    files: List[FileEntry] = field(default_factory=list)
    screens: List[ScreenEntry] = field(default_factory=list)
    controllers: List[ControllerEntry] = field(default_factory=list)
    services: List[ServiceEntry] = field(default_factory=list)
    dependencies: List[DepEdge] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    skipped: List[str] = field(default_factory=list)


@dataclass
class FrontmatterEntry:
    path: str
    id: str | None
    type: str | None
    status: str | None
    last_updated: str | None
    domains: list[str]
    depends_on: list[str]
    called_by: list[str]
    known_broken: list[str]
    extractable_sections: dict[str, str]
    raw: dict[str, Any]


@dataclass
class Connection:
    from_id: str
    to_id: str
    kind: str
    declared: bool
    actual: bool
    severed: bool
    undeclared: bool


@dataclass
class Orphan:
    path: str
    reason: str
    kind: str


@dataclass
class ScanResult:
    """Extended result combining ParseResult with validation findings."""

    parse: ParseResult
    frontmatter: list[FrontmatterEntry] = field(default_factory=list)
    connections: list[Connection] = field(default_factory=list)
    orphans: list[Orphan] = field(default_factory=list)
    stale_docs: list[str] = field(default_factory=list)
    missing_docs: list[str] = field(default_factory=list)
    drift_items: list[str] = field(default_factory=list)
    context_data: dict[str, Any] = field(default_factory=dict)
    frontmatter_issues: list[str] = field(default_factory=list)
    exit_code: int = 0
