"""Renderer helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Callable

from ..models import ParseResult


def ensure_output_dir(output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)


RendererFunc = Callable[[ParseResult, Path, bool], None]


