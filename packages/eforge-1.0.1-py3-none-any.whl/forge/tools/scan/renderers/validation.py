from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from forge.tools.scan.models import ScanResult

from . import ensure_output_dir


def render_validation(
    result: ScanResult,
    output_dir: Path,
    dry_run: bool = False,
) -> None:
    """Write machine-readable validation.json for CI and forge context."""
    ensure_output_dir(output_dir)
    parse = result.parse
    severed = [c for c in result.connections if c.severed]
    severed_payload = [
        {
            "from_id": c.from_id,
            "to_id": c.to_id,
            "kind": c.kind,
            "declared": c.declared,
            "actual": c.actual,
            "severed": c.severed,
            "undeclared": c.undeclared,
        }
        for c in severed
    ]
    orphans_payload = [{"path": o.path, "reason": o.reason, "kind": o.kind} for o in result.orphans]

    summary = {
        "files": len(parse.files),
        "screens": len(parse.screens),
        "controllers": len(parse.controllers),
        "connections": len(result.connections),
        "severed": len(severed),
        "orphans": len(result.orphans),
        "frontmatter_issues": len(result.frontmatter_issues),
        "drift_items": len(result.drift_items),
    }

    ctx = result.context_data or {}
    payload = {
        "scanned_at": datetime.now(timezone.utc).isoformat(),
        "project": parse.project_name,
        "severed": len(severed),
        "summary": summary,
        "severed_connections": severed_payload,
        "orphans": orphans_payload,
        "frontmatter_issues": list(result.frontmatter_issues),
        "drift_items": list(result.drift_items),
        "missing_docs": list(result.missing_docs),
        "stale_docs": list(result.stale_docs),
        "exit_code": result.exit_code,
        "graph_health": ctx.get("graph_health"),
        "sync_health": ctx.get("sync_health"),
        "health_signal": ctx.get("health_signal"),
    }

    out_path = output_dir / "validation.json"
    text = json.dumps(payload, indent=2) + "\n"
    if dry_run:
        preview = "\n".join(text.splitlines()[:30])
        print(f"[dry-run] Would write {out_path}:\n{preview}\n...")
    else:
        out_path.write_text(text, encoding="utf-8")
