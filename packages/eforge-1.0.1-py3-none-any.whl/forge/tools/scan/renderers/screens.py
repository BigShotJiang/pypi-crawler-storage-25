from __future__ import annotations

from pathlib import Path

from ..models import ParseResult, ScreenEntry
from . import ensure_output_dir


def _infer_route(screen: ScreenEntry) -> str | None:
    name = Path(screen.file).name
    base = name.rsplit(".", 1)[0]
    for suffix in ("_screen", "_page", "_view", "Screen", "Page", "View"):
        if base.endswith(suffix):
            base = base[: -len(suffix)]
            break
    slug = base.lower().replace("_", "-")
    if slug in ("index", "home", "main"):
        return "/"
    if not slug:
        return None
    if not slug.startswith("/"):
        slug = "/" + slug
    return slug


def render_screens(result: ParseResult, output_dir: Path, dry_run: bool) -> None:
    ensure_output_dir(output_dir)
    lines: list[str] = []
    lines.append(f"# Screen / Route Map — {result.project_name}")
    lines.append("")
    lines.append("| Screen | File | Domain | Confidence | Inferred Route | Nav Method |")
    lines.append("|--------|------|--------|------------|----------------|------------|")
    for s in result.screens:
        route = s.route or _infer_route(s) or ""
        nav = s.nav_method or ""
        lines.append(
            f"| {s.name} | {s.file} | {s.domain} | {s.confidence} | {route} | {nav} |"
        )
    content = "\n".join(lines) + "\n"
    out_path = output_dir / "screens.md"
    if dry_run:
        preview = "\n".join(content.splitlines()[:20])
        print(f"[dry-run] Would write {out_path}:\n{preview}\n...")
    else:
        out_path.write_text(content, encoding="utf-8")

