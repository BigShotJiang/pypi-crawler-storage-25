from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from ..models import ControllerEntry, ParseResult, ScreenEntry
from . import ensure_output_dir


def _snake_key(name: str) -> str:
    base = name.rsplit(".", 1)[0]
    for suffix in (
        "_screen",
        "_page",
        "_view",
        "_controller",
        "_service",
        "_provider",
        "_notifier",
    ):
        if base.endswith(suffix):
            base = base[: -len(suffix)]
            break
    out = []
    for ch in base:
        if ch.isupper():
            if out:
                out.append("_")
            out.append(ch.lower())
        elif ch.isalnum():
            out.append(ch.lower())
        else:
            out.append("_")
    key = "".join(out).strip("_")
    return key or "item"


def _render_screens_block(screens: list[ScreenEntry]) -> str:
    lines: list[str] = []
    for s in screens:
        key = _snake_key(Path(s.file).name)
        lines.append(f"  {key}:")
        lines.append(f"    file: {s.file}")
        lines.append(f"    domain: {s.domain}")
        lines.append(f"    confidence: {s.confidence}")
        lines.append(f"    role: \"\"")
        lines.append(f"    controller: \"\"")
        lines.append(f"    reads: []")
        lines.append(f"    writes: []")
        if s.hints:
            lines.append(f"    hints:")
            for hint in s.hints:
                lines.append(f"      - \"{hint}\"")
    return "\n".join(lines) if lines else ""


def _render_controllers_block(controllers: list[ControllerEntry]) -> str:
    lines: list[str] = []
    for c in controllers:
        key = _snake_key(Path(c.file).name)
        lines.append(f"  {key}:")
        lines.append(f"    file: {c.file}")
        lines.append(f"    domain: {c.domain}")
        lines.append(f"    confidence: {c.confidence}")
        if c.hints:
            lines.append(f"    hints:")
            for hint in c.hints:
                lines.append(f"      - \"{hint}\"")
    return "\n".join(lines) if lines else ""


def render_manifest(result: ParseResult, output_dir: Path, dry_run: bool) -> None:
    ensure_output_dir(output_dir)
    ts = datetime.now(timezone.utc).isoformat()
    lines: list[str] = []
    lines.append("# forge-scan draft — DO NOT COMMIT WITHOUT REVIEW")
    lines.append(f"# Generated: {ts}")
    lines.append("# Confidence flags: high = filename + folder match, medium = one signal, low = fallback")
    lines.append("")
    lines.append("app:")
    lines.append(f"  name: {result.project_name or 'unknown'}")
    lines.append(f"  version: {result.project_version or 'unknown'}")
    lines.append(f"  framework: {result.framework.value}")
    lines.append("")
    lines.append("screens:")
    screens_block = _render_screens_block(result.screens)
    if screens_block:
        lines.append(screens_block)
    lines.append("")
    lines.append("controllers:")
    controllers_block = _render_controllers_block(result.controllers)
    if controllers_block:
        lines.append(controllers_block)

    content = "\n".join(lines) + "\n"
    out_path = output_dir / "manifest.draft.yaml"
    if dry_run:
        preview = "\n".join(content.splitlines()[:20])
        print(f"[dry-run] Would write {out_path}:\n{preview}\n...")
    else:
        out_path.write_text(content, encoding="utf-8")

