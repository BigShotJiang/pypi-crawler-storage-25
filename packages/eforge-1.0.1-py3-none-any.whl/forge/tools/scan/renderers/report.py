from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List

from ..models import ParseResult, ScanResult
from . import ensure_output_dir


def _domain_distribution(result: ParseResult) -> Dict[str, Dict[str, int]]:
    out: Dict[str, Dict[str, int]] = {}
    for s in result.screens:
        dom = s.domain or "CORE"
        out.setdefault(dom, {"screens": 0, "controllers": 0})
        out[dom]["screens"] += 1
    for c in result.controllers:
        dom = c.domain or "CORE"
        out.setdefault(dom, {"screens": 0, "controllers": 0})
        out[dom]["controllers"] += 1
    return out


def render_report(
    result: ParseResult,
    output_dir: Path,
    dry_run: bool,
    scan: ScanResult | None = None,
) -> None:
    ensure_output_dir(output_dir)
    ts = datetime.now(timezone.utc).isoformat()

    lines: List[str] = []
    lines.append(f"# forge-scan Report — {result.project_name}")
    lines.append("")
    lines.append(f"**Scanned:** {ts}  ")
    lines.append(f"**Framework:** {result.framework.value}  ")
    lines.append(f"**Files scanned:** {len(result.files)}  ")
    lines.append(f"**Files skipped:** {len(result.skipped)}  ")
    lines.append(f"**Screens detected:** {len(result.screens)}  ")
    lines.append(f"**Controllers detected:** {len(result.controllers)}  ")
    lines.append(f"**Dependency edges:** {len(result.dependencies)}  ")
    lines.append("")

    lines.append("## Domain Distribution")
    dist = _domain_distribution(result)
    if not dist:
        lines.append("(no domains inferred)")
    else:
        lines.append("| Domain | Screens | Controllers |")
        lines.append("|--------|---------|-------------|")
        for dom, counts in sorted(dist.items()):
            lines.append(
                f"| {dom} | {counts['screens']} | {counts['controllers']} |"
            )
    lines.append("")

    warnings: List[str] = []
    if result.skipped:
        warnings.append(f"{len(result.skipped)} files skipped (too large or unreadable)")
    unlinked = [
        s for s in result.screens
        if not any(c.file for c in result.controllers if c.domain == s.domain)
    ]
    if unlinked:
        warnings.append(f"{len(unlinked)} screens have no controller in same domain")

    lines.append("## Warnings")
    if warnings:
        for w in warnings:
            lines.append(f"- {w}")
    else:
        lines.append("- None")
    lines.append("")

    lines.append("## Parser Notes")
    if result.notes:
        for n in result.notes:
            lines.append(f"- {n}")
    else:
        lines.append("- None")
    lines.append("")

    lines.append("## Skipped Files")
    if result.skipped:
        for s in result.skipped:
            lines.append(f"- {s}")
    else:
        lines.append("- None")
    lines.append("")

    if scan is not None:
        lines.append("## Validation Results")
        lines.append("")
        lines.append("### Declared vs Actual")
        lines.append("| Item | Declared | Detected | Status |")
        lines.append("|------|----------|----------|--------|")
        for c in scan.connections:
            if c.kind not in ("screen", "controller"):
                continue
            item = c.from_id or c.to_id
            decl = "✓" if c.declared else "✗"
            det = "✓" if c.actual else "✗"
            if c.severed:
                st = "SEVERED"
            elif c.undeclared:
                st = "UNDECLARED"
            else:
                st = "OK"
            lines.append(f"| {item} | {decl} | {det} | {st} |")
        if not any(c.kind in ("screen", "controller") for c in scan.connections):
            lines.append("| — | — | — | (no manifest screen/controller entries) |")
        lines.append("")

        lines.append("### Severed Connections")
        sev = [c for c in scan.connections if c.severed]
        if sev:
            for c in sev:
                lines.append(
                    f"- ✗ `{c.from_id}` [{c.kind}] → `{c.to_id}` "
                    f"(declared={c.declared}, actual={c.actual})"
                )
        else:
            lines.append("- None")
        lines.append("")

        lines.append("### Orphans")
        if scan.orphans:
            for o in scan.orphans:
                lines.append(f"- ⚠ `{o.path}` — {o.reason} ({o.kind})")
        else:
            lines.append("- None")
        lines.append("")

        lines.append("### Frontmatter Issues")
        if scan.frontmatter_issues:
            for issue in scan.frontmatter_issues:
                lines.append(f"- ⚠ {issue}")
        else:
            lines.append("- None")
        lines.append("")

    content = "\n".join(lines)
    out_path = output_dir / "report.md"
    if dry_run:
        preview = "\n".join(content.splitlines()[:40])
        print(f"[dry-run] Would write {out_path}:\n{preview}\n...")
    else:
        out_path.write_text(content, encoding="utf-8")

