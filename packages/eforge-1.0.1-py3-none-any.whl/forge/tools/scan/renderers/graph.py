from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from ..models import DepEdge, FileEntry, ParseResult
from . import ensure_output_dir


def _group_by_domain(files: List[FileEntry]) -> Dict[str, List[str]]:
    out: Dict[str, List[str]] = {}
    for f in files:
        domain = f.domain or "CORE"
        out.setdefault(domain, []).append(f.path)
    return out


def _node_id(path: str) -> str:
    import os

    base = os.path.basename(path)
    name = base.rsplit(".", 1)[0]
    for ch in "/-.":
        name = name.replace(ch, "_")
    return name or "node"


def render_graph(result: ParseResult, output_dir: Path, dry_run: bool) -> None:
    ensure_output_dir(output_dir)

    # deps.json
    import json

    deps_path = output_dir / "deps.json"
    deps_payload = [
        {"from": e.source, "to": e.target, "kind": e.kind}
        for e in result.dependencies
        if e.source != e.target
    ]
    deps_json = json.dumps(deps_payload, indent=2)
    if dry_run:
        preview = "\n".join(deps_json.splitlines()[:20])
        print(f"[dry-run] Would write {deps_path}:\n{preview}\n...")
    else:
        deps_path.write_text(deps_json, encoding="utf-8")

    # deps.mermaid
    mermaid_lines: List[str] = []
    mermaid_lines.append("graph TD")

    domain_groups = _group_by_domain(result.files)
    for domain, paths in domain_groups.items():
        mermaid_lines.append(f"  subgraph {domain}")
        for p in paths:
            nid = _node_id(p)
            mermaid_lines.append(f"    {nid}[\"{Path(p).name}\"]")
        mermaid_lines.append("  end")

    for e in result.dependencies:
        if e.source == e.target:
            continue
        src = _node_id(e.source)
        dst = _node_id(e.target)
        mermaid_lines.append(f"  {src} --> {dst}")

    mermaid_content = "\n".join(mermaid_lines) + "\n"
    mermaid_path = output_dir / "deps.mermaid"
    if dry_run:
        preview = "\n".join(mermaid_content.splitlines()[:20])
        print(f"[dry-run] Would write {mermaid_path}:\n{preview}\n...")
    else:
        mermaid_path.write_text(mermaid_content, encoding="utf-8")

