from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

import yaml

from forge.core.schemas import FunctionalIntentRecord, IntentRecord, IntentStatus
from forge.tools.manifest.graph import ManifestGraph

logger = logging.getLogger(__name__)

_DECL_KINDS = frozenset({"screen", "controller", "service", "module", "component", "model", "command"})

__all__ = [
    "FunctionalIntentRecord",
    "IntentRecord",
    "add_intent_record",
    "attach_intent_target_nodes",
    "declaration_domain_for_intent",
    "deprecate_intents_for_target",
    "diff_intent_vs_declaration",
    "import_obsidian_transcript",
    "intent_dir",
    "load_intent_by_id",
    "load_intent_record",
    "load_intent_records",
    "new_intent_record",
    "pipeline_intent_domain",
    "save_intent_record",
    "validate_functional_intent_record",
    "validate_intent_record",
]


def _resolved_project_root(project_root: Path | str) -> Path:
    """Canonical project root: always expand ``~`` then resolve."""
    return Path(str(project_root)).expanduser().resolve()


def intent_dir(project_root: Path | str) -> Path:
    return _resolved_project_root(project_root) / ".forge" / "intent"


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _record_path(root: Path, record_id: str) -> Path:
    return intent_dir(root) / f"{record_id}.yaml"


def _safe_hint_id(s: str) -> str:
    return str(s).strip()


def _extract_node_hints(description: str) -> list[str]:
    words = [w.strip(" ,.;:()[]{}") for w in description.split()]
    hints = []
    for w in words:
        if "/" in w and len(w) > 3:
            hints.append(_safe_hint_id(w))
    seen: set[str] = set()
    out: list[str] = []
    for h in hints:
        if h and h not in seen:
            seen.add(h)
            out.append(h)
    return out


def validate_intent_record(rec: IntentRecord | dict[str, Any]) -> None:
    d: dict[str, Any]
    if isinstance(rec, IntentRecord):
        d = rec.to_yaml_dict()
    else:
        d = dict(rec)
    required = {"id", "scope", "raw_description", "extracted_nodes", "source", "status", "created_at"}
    missing = [k for k in required if k not in d]
    if missing:
        raise ValueError(f"intent_record missing required fields: {missing}")
    if d["scope"] not in {"project", "feature", "node"}:
        raise ValueError("scope must be one of: project|feature|node")
    if d["status"] not in {"active", "deprecated", "superseded"}:
        raise ValueError("status must be one of: active|deprecated|superseded")
    dom = d.get("domain")
    if dom is not None and str(dom).strip() == "":
        raise ValueError("domain must be non-empty when set")


def validate_functional_intent_record(rec: FunctionalIntentRecord | dict[str, Any]) -> None:
    d: dict[str, Any]
    if isinstance(rec, FunctionalIntentRecord):
        d = rec.model_dump()
    else:
        d = dict(rec)
    required = {"id", "design_intent_id", "status", "created", "source"}
    missing = [k for k in required if k not in d]
    if missing:
        raise ValueError(f"functional_intent missing required fields: {missing}")
    if str(d.get("status") or "").strip().lower() not in {"draft", "active", "deprecated", "superseded"}:
        raise ValueError("status must be one of: draft|active|deprecated|superseded")
    for k in ("proposed_depends_on", "proposed_implements", "acceptance_criteria"):
        v = d.get(k)
        if v is not None and not isinstance(v, list):
            raise ValueError(f"{k} must be a list")


def load_intent_record(path: Path) -> IntentRecord:
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(raw, dict):
        raise ValueError(f"intent file {path.name}: root must be a mapping")
    validate_intent_record(raw)
    return IntentRecord.from_mapping(raw)


def save_intent_record(record: IntentRecord, path: Path) -> None:
    validate_intent_record(record)
    path.parent.mkdir(parents=True, exist_ok=True)
    body = record.to_yaml_dict()
    if not record.layer_id:
        body.pop("layer_id", None)
    path.write_text(yaml.safe_dump(body, sort_keys=False), encoding="utf-8")


def new_intent_record(
    *,
    scope: str,
    description: str,
    target_id: str | None = None,
    source: str = "manual",
    layer_id: str | None = None,
    domain: str | None = None,
) -> IntentRecord:
    """Build a new in-memory intent (not persisted)."""
    rid = str(uuid4())
    dom_u = str(domain).strip().upper() if domain and str(domain).strip() else None
    return IntentRecord(
        id=rid,
        scope=str(scope).strip(),
        target_id=str(target_id).strip() if target_id else None,
        raw_description=str(description),
        extracted_entities=_extract_node_hints(description),
        source=str(source),
        status="active",
        created=_iso_now(),
        layer_id=str(layer_id).strip() if layer_id and str(layer_id).strip() else None,
        deprecated_when=None,
        domain=dom_u,
    )


def add_intent_record(project_root: Path | str, record: IntentRecord) -> IntentRecord:
    root = _resolved_project_root(project_root)
    intent_dir(root).mkdir(parents=True, exist_ok=True)
    validate_intent_record(record)
    save_intent_record(record, _record_path(root, record.id))
    return record


def load_intent_records(project_root: Path | str) -> list[IntentRecord]:
    root = _resolved_project_root(project_root)
    d = intent_dir(root)
    if not d.is_dir():
        return []
    out: list[IntentRecord] = []
    for p in sorted(d.glob("*.yaml")):
        try:
            rec = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        except Exception as exc:
            logger.warning("skipping intent file %s: YAML load failed: %s", p.name, exc)
            continue
        if not isinstance(rec, dict):
            logger.warning(
                "skipping intent file %s: root must be a mapping, got %s",
                p.name,
                type(rec).__name__,
            )
            continue
        try:
            validate_intent_record(rec)
        except Exception as exc:
            logger.warning("skipping intent file %s: validation failed: %s", p.name, exc)
            continue
        out.append(IntentRecord.from_mapping(rec))
    return out


def _annotation_dict_for_id(root: Path, intent_id: str) -> dict[str, Any] | None:
    """Return raw annotation mapping for ``intent_id`` if present under ``.forge/annotations``."""
    key = str(intent_id).strip()
    if not key:
        return None
    ann_dir = root / ".forge" / "annotations"
    if not ann_dir.is_dir():
        return None
    direct = ann_dir / f"{key}.yaml"
    candidates = [direct] if direct.is_file() else sorted(ann_dir.glob("*.yaml"))
    for ap in candidates:
        try:
            raw = yaml.safe_load(ap.read_text(encoding="utf-8")) or {}
        except Exception:
            continue
        if not isinstance(raw, dict):
            continue
        if str(raw.get("id") or "").strip() != key:
            continue
        return raw
    return None


def _intent_record_from_annotation(data: dict[str, Any]) -> IntentRecord | None:
    """Map an EGMP / forge annotation YAML row into a synthetic :class:`IntentRecord`."""
    aid = str(data.get("id") or "").strip()
    if not aid:
        return None
    raw_desc = str(
        data.get("note")
        or data.get("title")
        or data.get("body")
        or data.get("raw_description")
        or ""
    ).strip()
    dom = data.get("domain")
    domain_opt = str(dom).strip().upper() if dom is not None and str(dom).strip() else None
    affects = data.get("affects") or []
    extracted = [str(x) for x in affects] if isinstance(affects, list) else []
    created = str(data.get("created") or data.get("created_at") or "").strip()
    st = str(data.get("status") or "open").lower()
    status = "deprecated" if st in ("deprecated", "resolved", "dismissed") else "active"
    tid = data.get("target_id")
    tid_s = str(tid).strip() if tid is not None and str(tid).strip() else ""
    return IntentRecord(
        id=aid,
        scope=str(data.get("scope") or "node").strip(),
        target_id=tid_s or None,
        raw_description=raw_desc or aid,
        extracted_entities=extracted,
        source=str(data.get("origin") or "annotation"),
        status=status,
        created=created or _iso_now(),
        layer_id=None,
        deprecated_when=str(data.get("deprecated_when") or "") or None,
        domain=domain_opt,
    )


def load_intent_by_id(project_root: Path | str, intent_id: str) -> IntentRecord | None:
    """Load one intent by id from ``.forge/intent/{id}.yaml`` or ``.forge/annotations``."""
    root = _resolved_project_root(project_root)
    key = str(intent_id).strip()
    if not key:
        return None
    ip = _record_path(root, key)
    if ip.is_file():
        try:
            rec = load_intent_record(ip)
        except Exception:
            pass
        else:
            if not (rec.domain and str(rec.domain).strip()):
                raw_ann = _annotation_dict_for_id(root, key)
                if raw_ann:
                    dom = raw_ann.get("domain")
                    if dom is not None and str(dom).strip():
                        rec = rec.model_copy(update={"domain": str(dom).strip().upper()})
            return rec
    raw_ann_only = _annotation_dict_for_id(root, key)
    if raw_ann_only:
        return _intent_record_from_annotation(raw_ann_only)
    return None


def pipeline_intent_domain(record: IntentRecord) -> str | None:
    """Explicit ``domain`` field only — no graph or text heuristics (scaffold pipeline)."""
    if record.domain and str(record.domain).strip():
        return str(record.domain).strip().upper()
    return None


def deprecate_intents_for_target(project_root: Path | str, target_id: str, condition: str) -> int:
    root = _resolved_project_root(project_root)
    d = intent_dir(root)
    if not d.is_dir():
        return 0
    updated = 0
    for p in sorted(d.glob("*.yaml")):
        try:
            rec = load_intent_record(p)
        except Exception:
            continue
        if rec.target_id != str(target_id):
            continue
        if rec.status == "deprecated":
            continue
        rec2 = rec.model_copy(update={"status": IntentStatus.DEPRECATED, "deprecated_when": condition})
        save_intent_record(rec2, p)
        updated += 1
    return updated


def import_obsidian_transcript(project_root: Path | str, file_path: Path | str) -> list[IntentRecord]:
    root = _resolved_project_root(project_root)
    fp = Path(str(file_path)).expanduser().resolve()
    text = fp.read_text(encoding="utf-8", errors="ignore")
    lines = [ln.strip("- ").strip() for ln in text.splitlines() if ln.strip().startswith("-")]
    if not lines:
        lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    created: list[IntentRecord] = []
    source = f"obsidian:{Path(file_path).name}"
    for ln in lines[:25]:
        if len(ln) < 6:
            continue
        created.append(
            add_intent_record(
                root,
                new_intent_record(scope="feature", description=ln, source=source),
            )
        )
    return created


def _declaration_row_for_id(graph: ManifestGraph, node_id: str) -> dict[str, Any] | None:
    import forge.core.query as _core_query

    for kind in _DECL_KINDS:
        qr = _core_query.forge_query(
            graph,
            kind=kind,
            where={},
            limit=10**9,
            depth=1,
            direction="both",
        )
        for row in qr.data.get("nodes", []) or []:
            if isinstance(row, dict) and str(row.get("id") or "") == node_id:
                return row
    return None


def _declaration_id_set(graph: ManifestGraph) -> set[str]:
    import forge.core.query as _core_query

    ids: set[str] = set()
    for kind in _DECL_KINDS:
        qr = _core_query.forge_query(
            graph,
            kind=kind,
            where={},
            limit=10**9,
            depth=1,
            direction="both",
        )
        for row in qr.data.get("nodes", []) or []:
            if isinstance(row, dict) and row.get("id"):
                ids.add(str(row["id"]))
    return ids


def declaration_domain_for_intent(record: IntentRecord, graph: ManifestGraph) -> str | None:
    """Resolve declaration domain via ``forge_query`` rows; optional text fallback."""
    candidates: list[str] = []
    tid = (record.target_id or "").strip()
    if tid:
        candidates.append(tid)
    for x in record.extracted_nodes:
        xs = (x or "").strip()
        if xs and xs not in candidates:
            candidates.append(xs)
    for nid in candidates:
        row = _declaration_row_for_id(graph, nid)
        if row:
            dom = str(row.get("domain") or "").strip()
            if dom:
                return dom.upper()
    # FALLBACK: text heuristics when forge_query finds no matching declaration node
    desc = record.raw_description.lower()
    blob = f"{desc} {tid.lower()}"
    rules: tuple[tuple[tuple[str, ...], str], ...] = (
        (("auth", "jwt", "oauth", "sso", "password", "login", "session", "signin", "signup"), "AUTH"),
        (("game", "lobby", "player", "match", "canvas", "multiplayer", "room"), "GAME"),
        (("payment", "stripe", "billing", "invoice", "subscription", "checkout"), "COMMERCE"),
        (("map", "manifest", "graph", "diff", "trace", "audit", "scaffold", "intent"), "TOOLS"),
    )
    for keys, dom in rules:
        if any(k in blob for k in keys):
            return dom
    return "CORE"


def attach_intent_target_nodes(records: list[IntentRecord], graph: ManifestGraph) -> list[IntentRecord]:
    """Resolve ``target_id`` into :class:`~forge.engine.entity.schemas.NodeModel` when present."""
    from forge.engine.entity.schemas import NodeModel

    node_by_id = {str(n.id): n for n in graph.nodes}
    out: list[IntentRecord] = []
    for rec in records:
        tid = (rec.target_id or "").strip()
        nm = None
        if tid:
            mn = node_by_id.get(tid)
            if mn is not None:
                nm = NodeModel.from_manifest_node(mn)
        out.append(rec.model_copy(update={"target_node": nm}))
    return out


def _declaration_payload_for_node(graph: ManifestGraph, node_id: str, node: Any) -> dict[str, Any]:
    from forge.engine.entity.schemas import NodeModel

    if node is not None:
        return NodeModel.from_manifest_node(node).model_dump(mode="python")
    row = _declaration_row_for_id(graph, node_id)
    if row:
        return {
            "id": row.get("id"),
            "name": row.get("name"),
            "kind": row.get("kind"),
            "domain": row.get("domain"),
            "path": row.get("path"),
        }
    return {"id": node_id, "name": "", "kind": ""}


def diff_intent_vs_declaration(project_root: Path | str, graph: ManifestGraph) -> list[dict[str, Any]]:
    root = _resolved_project_root(project_root)
    records = attach_intent_target_nodes(load_intent_records(root), graph)
    known = _declaration_id_set(graph)
    node_by_id = {str(n.id): n for n in graph.nodes}
    drift: list[dict[str, Any]] = []

    for rec in records:
        rid = rec.id
        target = (rec.target_id or "").strip()
        if target and target not in known:
            drift.append(
                {
                    "id": rid,
                    "drift_type": "intent-without-node",
                    "target_id": target,
                    "intent_record": rec.to_yaml_dict(),
                    "declaration_node": None,
                    "details": "intent target has no declaration node (forge_query graph)",
                }
            )
        for hint in rec.extracted_nodes:
            h = (hint or "").strip()
            if h and h not in known:
                drift.append(
                    {
                        "id": rid,
                        "drift_type": "intent-extracted-missing",
                        "target_id": h,
                        "intent_record": rec.to_yaml_dict(),
                        "declaration_node": None,
                        "details": "intent extracted_nodes id not found in declaration graph (forge_query)",
                    }
                )

    target_ids = {(r.target_id or "").strip() for r in records if (r.target_id or "").strip()}
    for node_id in sorted(known):
        if node_id not in target_ids:
            node = node_by_id.get(node_id)
            decl_payload = _declaration_payload_for_node(graph, node_id, node)
            drift.append(
                {
                    "id": f"decl:{node_id}",
                    "drift_type": "node-without-intent",
                    "target_id": node_id,
                    "intent_record": None,
                    "declaration_node": decl_payload,
                    "details": "declaration node has no intent record",
                }
            )

    for rec in records:
        rid = rec.id
        target = (rec.target_id or "").strip()
        if not target or target not in known:
            continue
        tn = rec.target_node
        desc = rec.raw_description.lower()
        if tn is not None:
            tokens = {tn.name.lower(), tn.id.lower()}
            if tn.id:
                tokens.add(tn.id.rsplit("/", 1)[-1].lower())
            tokens.discard("")
            if tokens and not any(t and t in desc for t in tokens):
                drift.append(
                    {
                        "id": rid,
                        "drift_type": "design-drift",
                        "target_id": target,
                        "intent_record": rec.to_yaml_dict(),
                        "declaration_node": tn.model_dump(mode="python"),
                        "details": "intent description diverges from declaration node contract",
                    }
                )
        else:
            node = node_by_id.get(target)
            if node is None:
                continue
            if node.name.lower() not in desc:
                drift.append(
                    {
                        "id": rid,
                        "drift_type": "design-drift",
                        "target_id": target,
                        "intent_record": rec.to_yaml_dict(),
                        "declaration_node": _declaration_payload_for_node(graph, target, node),
                        "details": "intent description diverges from declaration node contract",
                    }
                )
    return drift
