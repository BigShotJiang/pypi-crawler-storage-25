"""Intent graph tooling."""
