from __future__ import annotations

from pathlib import Path
from typing import Any

from forge.core.temporal_triangulation import triangulate_temporal_contracts
from forge.tools.intent.runtime import load_intent_records
from forge.tools.manifest.graph import build_manifest_graph
from forge.tools.trace_store import load_latest_trace


def _exec_node_ids(project_root: Path, graph: Any | None = None) -> set[str]:
    eg = load_latest_trace(project_root)
    if eg is None:
        return set()
    out: set[str] = set()
    path_to_mod: dict[str, str] = {}
    g = graph if graph is not None else build_manifest_graph(project_root)
    for n in g.nodes:
        p = str(n.path or "").replace("\\", "/").lstrip("./")
        if p:
            path_to_mod[p] = str(n.id)
    for n in eg.nodes.values():
        fp = str(n.file or "").replace("\\", "/")
        for rel, mid in path_to_mod.items():
            if fp.endswith(rel):
                out.add(mid)
                break
    return out


def triangulate_graphs(
    project_root: Path,
    scope_target: str | None = None,
    *,
    temporal_tier: str = "L2",
    graph: Any | None = None,
) -> list[dict[str, Any]]:
    root = project_root.expanduser().resolve()
    g = graph if graph is not None else build_manifest_graph(root)
    decl_ids = {str(n.id) for n in g.nodes}
    exec_ids = _exec_node_ids(root, graph=g)
    intents = load_intent_records(root)
    intent_targets = {(r.target_id or "").strip() for r in intents if (r.target_id or "").strip()}
    intent_targets = {x for x in intent_targets if x}

    if scope_target:
        s = str(scope_target).strip()
        decl_ids = {x for x in decl_ids if x == s}
        exec_ids = {x for x in exec_ids if x == s}
        intent_targets = {x for x in intent_targets if x == s}

    out: list[dict[str, Any]] = []
    for nid in sorted(decl_ids - exec_ids):
        out.append({"id": nid, "drift_type": "declared-not-executed", "graphs_involved": ["declaration", "execution"]})
    for nid in sorted(intent_targets - decl_ids):
        out.append({"id": nid, "drift_type": "intended-not-declared", "graphs_involved": ["intent", "declaration"]})
    for nid in sorted(exec_ids - intent_targets):
        out.append({"id": nid, "drift_type": "executed-not-intended", "graphs_involved": ["execution", "intent"]})
    temporal = triangulate_temporal_contracts(
        root,
        node_id=scope_target,
        response_tier=str(temporal_tier or "L2").upper(),
    )
    tt = str(temporal_tier or "L2").upper()
    for row in temporal.get("results", []) if isinstance(temporal, dict) else []:
        if not isinstance(row, dict):
            continue
        ga = str(row.get("graph_a") or "").strip()
        gb = str(row.get("graph_b") or "").strip()
        graphs_involved = [x for x in (ga, gb) if x]
        item: dict[str, Any] = {
            "id": str(row.get("node_id") or ""),
            "drift_type": str(row.get("drift_class") or "temporal_gap"),
            "graphs_involved": graphs_involved,
        }
        if tt == "L2":
            item["detail"] = str(row.get("detail") or "")
            item["triangulation_source"] = "temporal"
        out.append(item)
    return out


def report_records(project_root: Path, *, finding_id: str | None = None, graph: Any | None = None) -> list[dict[str, Any]]:
    g = graph if graph is not None else build_manifest_graph(project_root)
    by_id = {str(n.id): n for n in g.nodes}
    items = triangulate_graphs(project_root, graph=g)
    rows: list[dict[str, Any]] = []
    for idx, it in enumerate(items, start=1):
        fid = f"T-{idx:04d}"
        if finding_id and fid != finding_id:
            continue
        node = by_id.get(str(it.get("id") or ""))
        file = str(getattr(node, "path", "") or "")
        symbol = str(getattr(node, "name", "") or str(it.get("id") or ""))
        location = f"{file}:{1}:{symbol}" if file else f"::{symbol}"
        layer = ",".join(it.get("graphs_involved") or [])
        rows.append(
            {
                "id": fid,
                "location": location,
                "issue_type": str(it.get("drift_type") or "drift"),
                "layer": layer,
                "blast_radius": [str(it.get("id") or "")],
                "suggested_fix": "align declaration, intent, and runtime behavior",
                "minimal_context": f"triangulation drift for {symbol}",
            }
        )
    return rows
