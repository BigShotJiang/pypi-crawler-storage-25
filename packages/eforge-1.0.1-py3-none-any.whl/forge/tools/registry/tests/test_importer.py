from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml

from forge.tools.registry.importer import import_from_code_workspace, import_from_yaml
from forge.tools.registry.store import load_registry, registry_path


def test_import_code_workspace_relative_paths(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    root = tmp_path / "root"
    wsdir = root / "forge-workspace"
    wsdir.mkdir(parents=True)
    forge = root / "forge"
    forge.mkdir()
    (forge / "pyproject.toml").write_text("[project]\nname='forge'\n", encoding="utf-8")
    wsp = wsdir / "forge.code-workspace"
    wsp.write_text(json.dumps({"folders": [{"path": "../forge"}]}), encoding="utf-8")
    added, err = import_from_code_workspace(wsp)
    assert not err
    assert any(a.get("id") == "forge" for a in added)
    reg = load_registry()
    assert "forge" in reg["projects"]


def test_import_code_workspace_strips_jsonc(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    root = tmp_path / "root"
    wsdir = root / "w"
    wsdir.mkdir(parents=True)
    forge = root / "forge"
    forge.mkdir()
    (forge / "pyproject.toml").write_text("[project]\nname='f'\n", encoding="utf-8")
    wsp = wsdir / "x.code-workspace"
    raw = '{\n// c\n"folders": [{"path": "../forge"}]\n}\n'
    wsp.write_text(raw, encoding="utf-8")
    added, err = import_from_code_workspace(wsp)
    assert not err
    assert added


def test_import_skips_existing_slugs(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    root = tmp_path / "root"
    wsdir = root / "w"
    wsdir.mkdir(parents=True)
    forge = root / "forge"
    forge.mkdir()
    (forge / "pyproject.toml").write_text("[project]\nname='f'\n", encoding="utf-8")
    wsp = wsdir / "x.code-workspace"
    wsp.write_text(json.dumps({"folders": [{"path": "../forge"}]}), encoding="utf-8")
    import_from_code_workspace(wsp)
    added2, err2 = import_from_code_workspace(wsp, force=False)
    assert not added2
    assert err2


def test_import_records_import_source(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    root = tmp_path / "root"
    wsdir = root / "w"
    wsdir.mkdir(parents=True)
    forge = root / "forge"
    forge.mkdir()
    (forge / "pyproject.toml").write_text("[project]\nname='f'\n", encoding="utf-8")
    wsp = wsdir / "x.code-workspace"
    wsp.write_text(json.dumps({"folders": [{"path": "../forge"}]}), encoding="utf-8")
    import_from_code_workspace(wsp)
    reg = load_registry()
    src = reg.get("import_sources") or []
    assert any(isinstance(s, dict) and s.get("kind") == "code_workspace" for s in src)


def test_import_dry_run_no_writes(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    root = tmp_path / "root"
    wsdir = root / "w"
    wsdir.mkdir(parents=True)
    forge = root / "forge"
    forge.mkdir()
    (forge / "pyproject.toml").write_text("[project]\nname='f'\n", encoding="utf-8")
    wsp = wsdir / "x.code-workspace"
    wsp.write_text(json.dumps({"folders": [{"path": "../forge"}]}), encoding="utf-8")
    import_from_code_workspace(wsp, dry_run=True)
    assert not registry_path().is_file()


def test_import_detects_stack_per_project(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    root = tmp_path / "root"
    wsdir = root / "w"
    wsdir.mkdir(parents=True)
    fl = root / "fl"
    fl.mkdir()
    (fl / "pubspec.yaml").write_text("name: x\n", encoding="utf-8")
    wsp = wsdir / "x.code-workspace"
    wsp.write_text(json.dumps({"folders": [{"path": "../fl"}]}), encoding="utf-8")
    added, _ = import_from_code_workspace(wsp)
    assert added[0].get("stack") == "flutter"


def test_import_from_yaml_projects_section(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    p = tmp_path / "proj"
    p.mkdir()
    (p / "pyproject.toml").write_text("[project]\nname='p'\n", encoding="utf-8")
    yp = tmp_path / "cfg.yaml"
    yp.write_text(
        yaml.safe_dump({"projects": {"proj": {"path": str(p), "stack": "python", "phase": 2}}}),
        encoding="utf-8",
    )
    added, err = import_from_yaml(yp)
    assert not err
    assert added
    assert load_registry()["projects"]["proj"]["phase"] == 2
