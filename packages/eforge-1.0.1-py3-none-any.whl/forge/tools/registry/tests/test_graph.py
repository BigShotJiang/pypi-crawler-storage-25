from __future__ import annotations

from forge.tools.registry.graph import (
    blast_radius_ring1,
    derive_relations,
    find_ancestors,
    find_children,
    find_cousins,
    find_descendants,
    find_parent,
    find_siblings,
)


def _reg() -> dict:
    return {
        "schema_version": 1,
        "document_kind": "forge_project_registry",
        "projects": {
            "parent": {
                "id": "parent",
                "path": "/p",
                "stack": "python",
                "phase": 1,
                "status": "active",
                "relations": {"contains": ["child"]},
            },
            "child": {
                "id": "child",
                "path": "/c",
                "stack": "python",
                "phase": 1,
                "status": "active",
                "relations": {},
            },
            "a": {
                "id": "a",
                "path": "/a",
                "stack": "python",
                "phase": 1,
                "status": "active",
                "relations": {"depends_on": ["lib"]},
            },
            "b": {
                "id": "b",
                "path": "/b",
                "stack": "python",
                "phase": 1,
                "status": "active",
                "relations": {"depends_on": ["lib"], "shares_backend": ["db1"]},
            },
            "c": {
                "id": "c",
                "path": "/c2",
                "stack": "flutter",
                "phase": 1,
                "status": "active",
                "relations": {"shares_backend": ["db1"]},
            },
            "lib": {
                "id": "lib",
                "path": "/l",
                "stack": "python",
                "phase": 1,
                "status": "active",
                "relations": {},
            },
        },
        "resources": {
            "db1": {"id": "db1", "kind": "postgres", "linked_projects": ["b", "c"]},
        },
        "import_sources": [],
    }


def test_find_children_from_contains() -> None:
    r = _reg()
    assert find_children("parent", r) == ["child"]


def test_find_parent_from_contains() -> None:
    r = _reg()
    assert find_parent("child", r) == "parent"


def test_find_cousins_different_parent_shared_resource() -> None:
    r = _reg()
    cousins = find_cousins("b", r)
    assert "c" in cousins


def test_find_siblings_from_shared_resource() -> None:
    r = _reg()
    sib = find_siblings("b", r)
    assert "c" in sib


def test_find_ancestors_transitive() -> None:
    r = _reg()
    r["projects"]["grand"] = {
        "id": "grand",
        "path": "/g",
        "stack": "python",
        "phase": 1,
        "status": "active",
        "relations": {"contains": ["parent"]},
    }
    r["projects"]["parent"]["relations"]["contains"] = ["child"]
    assert find_ancestors("child", r) == ["parent", "grand"]


def test_find_descendants_transitive() -> None:
    r = _reg()
    assert find_descendants("parent", r) == ["child"]


def test_blast_radius_direct_dependencies() -> None:
    r = _reg()
    br = blast_radius_ring1("lib", r)
    assert "a" in br["direct"]
    assert "b" in br["direct"]


def test_blast_radius_cousin_via_resource() -> None:
    r = _reg()
    br = blast_radius_ring1("b", r)
    assert "c" in br["cousins"]


def test_derive_relations_returns_all() -> None:
    r = _reg()
    dr = derive_relations(r)
    assert dr["parent"]
    assert any(t == "child" for _, t in dr["parent"])
