# Registry unit tests
