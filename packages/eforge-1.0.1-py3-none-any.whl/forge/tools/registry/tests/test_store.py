from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from forge.tools.registry.store import (
    ProjectExistsError,
    add_project,
    detect_phase,
    detect_slug,
    detect_slug_from_name,
    detect_stack,
    list_projects,
    load_registry,
    registry_path,
    remove_project,
    resolve_slug,
    save_registry,
)


def test_load_registry_returns_empty_if_missing(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    r = load_registry(path=tmp_path / "nope.yaml")
    assert r["projects"] == {}
    assert r["document_kind"] == "forge_project_registry"


def test_add_project_writes_to_registry(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    p = tmp_path / "app"
    p.mkdir()
    (p / "pyproject.toml").write_text("[project]\nname='x'\n", encoding="utf-8")
    add_project(p, slug="app")
    rp = registry_path()
    assert rp.is_file()
    data = yaml.safe_load(rp.read_text(encoding="utf-8"))
    assert "app" in data["projects"]


def test_add_project_skips_if_exists(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    p = tmp_path / "a"
    p.mkdir()
    (p / "pyproject.toml").write_text("[project]\nname='a'\n", encoding="utf-8")
    add_project(p, slug="a")
    with pytest.raises(ProjectExistsError):
        add_project(p, slug="a", force=False)


def test_add_project_force_overwrites(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    p = tmp_path / "a"
    p.mkdir()
    (p / "pyproject.toml").write_text("[project]\nname='a'\n", encoding="utf-8")
    add_project(p, slug="a")
    add_project(p, slug="a", force=True, stack="python")
    ent = load_registry()["projects"]["a"]
    assert ent["stack"] == "python"


def test_remove_project_deletes_entry(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    p = tmp_path / "x"
    p.mkdir()
    (p / "pyproject.toml").write_text("[project]\nname='x'\n", encoding="utf-8")
    add_project(p, slug="x")
    assert remove_project("x")
    assert "x" not in load_registry()["projects"]


@pytest.mark.parametrize(
    ("name", "expected"),
    [
        ("DOCS-TEMPLATES", "docs_templates"),
        ("lifeOS", "lifeos"),
        ("workout-app", "workout_app"),
        ("MyProject", "myproject"),
    ],
)
def test_detect_slug_normalizes(name: str, expected: str) -> None:
    assert detect_slug_from_name(name) == expected
    assert detect_slug(Path(name)) == detect_slug_from_name(name)


def test_detect_stack_flutter_from_pubspec(tmp_path: Path) -> None:
    p = tmp_path / "f"
    p.mkdir()
    (p / "pubspec.yaml").write_text("name: x\n", encoding="utf-8")
    assert detect_stack(p) == "flutter"


def test_detect_stack_python_from_pyproject(tmp_path: Path) -> None:
    p = tmp_path / "py"
    p.mkdir()
    (p / "pyproject.toml").write_text("[project]\nname='x'\n", encoding="utf-8")
    assert detect_stack(p) == "python"


def test_detect_stack_react_from_package_json(tmp_path: Path) -> None:
    p = tmp_path / "r"
    p.mkdir()
    (p / "package.json").write_text('{"dependencies":{"react":"18"}}', encoding="utf-8")
    assert detect_stack(p) == "react"


def test_detect_phase_from_manifest(tmp_path: Path) -> None:
    p = tmp_path / "m"
    p.mkdir()
    (p / "manifest.yaml").write_text(
        "phases:\n  current: 3\n",
        encoding="utf-8",
    )
    assert detect_phase(p) == 3


def test_list_projects_filters_by_status_stack_tag(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    a = tmp_path / "a"
    b = tmp_path / "b"
    a.mkdir()
    b.mkdir()
    (a / "pyproject.toml").write_text("[project]\nname='a'\n", encoding="utf-8")
    (b / "pyproject.toml").write_text("[project]\nname='b'\n", encoding="utf-8")
    add_project(a, slug="a", tags=["mobile"])
    add_project(b, slug="b", tags=["web"])
    reg = load_registry()
    assert len(list_projects(status="active", registry=reg)) == 2
    assert len(list_projects(stack="python", registry=reg)) == 2
    assert len(list_projects(tags=["mobile"], registry=reg)) == 1


def test_resolve_slug_case_insensitive(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    p = tmp_path / "Pix"
    p.mkdir()
    (p / "pyproject.toml").write_text("[project]\nname='x'\n", encoding="utf-8")
    add_project(p, slug="pixionary")
    assert resolve_slug("PIXIONARY", load_registry()) == "pixionary"


def test_resolve_slug_prefix_match(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    p = tmp_path / "pixionary"
    p.mkdir()
    (p / "pyproject.toml").write_text("[project]\nname='x'\n", encoding="utf-8")
    add_project(p, slug="pixionary")
    assert resolve_slug("pix", load_registry()) == "pixionary"


def test_resolve_slug_hyphen_underscore(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    p = tmp_path / "d"
    p.mkdir()
    (p / "pyproject.toml").write_text("[project]\nname='x'\n", encoding="utf-8")
    add_project(p, slug="docs_templates")
    assert resolve_slug("docs-templates", load_registry()) == "docs_templates"
