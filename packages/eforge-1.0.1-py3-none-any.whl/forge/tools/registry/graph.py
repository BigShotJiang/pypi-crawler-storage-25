from __future__ import annotations

from collections import defaultdict, deque
from typing import Any

from forge.tools.registry.store import _projects_map, _normalize_relations, load_registry


def _rel_lists(entry: dict[str, Any]) -> dict[str, list[str]]:
    return _normalize_relations(entry.get("relations"))


def derive_relations(registry: dict[str, Any]) -> dict[str, list[tuple[str, str]]]:
    """
    Derive implicit + explicit relations.
    Returns: {project_id: [(relation_kind, target_id), ...]}
    """
    pmap = _projects_map(registry)
    out: dict[str, list[tuple[str, str]]] = defaultdict(list)
    resources = registry.get("resources") or {}
    if not isinstance(resources, dict):
        resources = {}

    # Explicit from each project
    for pid, entry in pmap.items():
        if not isinstance(entry, dict):
            continue
        sid = str(entry.get("id", pid))
        rel = _rel_lists(entry)
        for kind in (
            "depends_on",
            "provides_to",
            "shares_backend",
            "contains",
            "scaffolds_from",
            "uses_templates_from",
        ):
            for tgt in rel.get(kind, []):
                out[sid].append((kind, str(tgt)))
                if kind == "contains":
                    out[str(tgt)].append(("parent", sid))

    # Resource sharing → cousins
    for _rid, rdef in resources.items():
        if not isinstance(rdef, dict):
            continue
        linked = rdef.get("linked_projects") or []
        if not isinstance(linked, list):
            continue
        lp = [str(x) for x in linked if x]
        for i, a in enumerate(lp):
            for b in lp[i + 1 :]:
                if a == b:
                    continue
                out[a].append(("cousin", b))
                out[b].append(("cousin", a))

    # Sibling candidates: same stack + overlapping tags, not parent/child
    proj_ids = [str(k) for k, v in pmap.items() if isinstance(v, dict)]
    entries = {str(k): v for k, v in pmap.items() if isinstance(v, dict)}
    parents_of: dict[str, set[str]] = defaultdict(set)
    children_of: dict[str, set[str]] = defaultdict(set)
    for pid, entry in entries.items():
        sid = str(entry.get("id", pid))
        for c in _rel_lists(entry).get("contains", []):
            children_of[sid].add(c)
            parents_of[c].add(sid)

    for i, a in enumerate(proj_ids):
        ea = entries.get(a) or {}
        ta = {str(t).lower() for t in (ea.get("tags") or []) if t}
        sta = str(ea.get("stack", "")).lower()
        for b in proj_ids[i + 1 :]:
            if b == a:
                continue
            eb = entries.get(b) or {}
            tb = {str(t).lower() for t in (eb.get("tags") or []) if t}
            stb = str(eb.get("stack", "")).lower()
            if not ta or not tb or not ta.intersection(tb):
                continue
            if sta and stb and sta != stb:
                continue
            if b in children_of.get(a, ()) or a in children_of.get(b, ()):
                continue
            out[a].append(("sibling_candidate", b))
            out[b].append(("sibling_candidate", a))

    return dict(out)


def find_children(slug: str, registry: dict[str, Any]) -> list[str]:
    pmap = _projects_map(registry)
    key: str | None = None
    for k, v in pmap.items():
        if not isinstance(v, dict):
            continue
        sid = str(v.get("id", k))
        if str(k) == slug or sid == slug:
            key = str(k)
            break
    if key is None:
        return []
    ent = pmap.get(key)
    if not isinstance(ent, dict):
        return []
    return list(_rel_lists(ent).get("contains", []))


def find_parent(slug: str, registry: dict[str, Any]) -> str | None:
    dr = derive_relations(registry)
    for rel, tgt in dr.get(slug, []):
        if rel == "parent":
            return tgt
    return None


def find_siblings(slug: str, registry: dict[str, Any]) -> list[str]:
    """Projects sharing a parent or a backend resource (declared shares_backend)."""
    pmap = _projects_map(registry)
    parents: list[str] = []
    dr = derive_relations(registry)
    for rel, tgt in dr.get(slug, []):
        if rel == "parent":
            parents.append(tgt)
    sib: set[str] = set()
    for p in parents:
        for c in find_children(p, registry):
            if c != slug:
                sib.add(c)
    ent = None
    for k, v in pmap.items():
        if not isinstance(v, dict):
            continue
        sid = str(v.get("id", k))
        if sid == slug or k == slug:
            ent = v
            break
    if ent:
        for res in _rel_lists(ent).get("shares_backend", []):
            rmap = registry.get("resources") or {}
            if isinstance(rmap, dict) and res in rmap:
                lp = (rmap[res] or {}).get("linked_projects") or []
                if isinstance(lp, list):
                    for x in lp:
                        xs = str(x)
                        if xs != slug:
                            sib.add(xs)
    return sorted(sib)


def find_cousins(slug: str, registry: dict[str, Any]) -> list[str]:
    """Projects sharing a backend resource (resource graph), excluding self."""
    out: set[str] = set()
    dr = derive_relations(registry)
    for rel, tgt in dr.get(slug, []):
        if rel == "cousin":
            out.add(tgt)
    return sorted(out)


def find_ancestors(slug: str, registry: dict[str, Any], max_depth: int = 10) -> list[str]:
    seen: list[str] = []
    cur = slug
    for _ in range(max_depth):
        p = find_parent(cur, registry)
        if not p or p in seen:
            break
        seen.append(p)
        cur = p
    return seen


def find_descendants(slug: str, registry: dict[str, Any], max_depth: int = 10) -> list[str]:
    out: list[str] = []
    q: deque[tuple[str, int]] = deque([(slug, 0)])
    seen: set[str] = {slug}
    while q:
        cur, d = q.popleft()
        if d >= max_depth:
            continue
        for ch in find_children(cur, registry):
            if ch in seen:
                continue
            seen.add(ch)
            out.append(ch)
            q.append((ch, d + 1))
    return out


def blast_radius_ring1(
    slug: str,
    registry: dict[str, Any],
    change_kind: str = "any",
) -> dict[str, Any]:
    """
    Ring-1 blast surface for a project change.
    # UNSTABLE: reason strings and change_kind filtering may evolve.
    """
    _ = change_kind
    dr = derive_relations(registry)
    pmap = _projects_map(registry)
    direct: set[str] = set()
    reason: dict[str, str] = {}
    for pid, pairs in dr.items():
        for rel, tgt in pairs:
            if rel == "depends_on" and tgt == slug:
                direct.add(pid)
                reason[pid] = f"depends_on {slug}"
    children = find_children(slug, registry)
    for c in children:
        reason[c] = f"contained by {slug}"
    ancestors = find_ancestors(slug, registry)
    for a in ancestors:
        reason[a] = f"ancestor of {slug}"
    cousins = find_cousins(slug, registry)
    for c in cousins:
        if c not in reason:
            reason[c] = "shared backend resource (cousin)"
    return {
        "direct": sorted(direct),
        "cousins": cousins,
        "children": children,
        "ancestors": ancestors,
        "reason": reason,
    }
