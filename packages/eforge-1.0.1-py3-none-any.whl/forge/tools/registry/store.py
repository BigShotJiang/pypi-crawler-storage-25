from __future__ import annotations

import json
import re
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap


def registry_path() -> Path:
    """~/.forge/registry.yaml (resolved per call so tests can monkeypatch HOME)."""
    return Path.home() / ".forge" / "registry.yaml"


DOCUMENT_KIND = "forge_project_registry"


class ProjectExistsError(Exception):
    """Raised when add_project targets an existing id without force=True."""


def _yaml_rt() -> YAML:
    y = YAML(typ="rt")
    y.preserve_quotes = True
    return y


def _as_commented_map(obj: Any) -> CommentedMap:
    if isinstance(obj, CommentedMap):
        return obj
    if isinstance(obj, dict):
        cm = CommentedMap()
        for k, v in obj.items():
            if isinstance(v, dict) and not isinstance(v, CommentedMap):
                cm[k] = _as_commented_map(v)
            elif isinstance(v, list):
                cm[k] = [_as_commented_map(i) if isinstance(i, dict) else i for i in v]
            else:
                cm[k] = v
        return cm
    return CommentedMap()


def _empty_relations() -> dict[str, list[str]]:
    return {
        "depends_on": [],
        "provides_to": [],
        "shares_backend": [],
        "contains": [],
        "scaffolds_from": [],
        "uses_templates_from": [],
    }


def _empty_registry_root() -> CommentedMap:
    root = CommentedMap()
    root["schema_version"] = 1
    root["document_kind"] = DOCUMENT_KIND
    root["projects"] = CommentedMap()
    root["resources"] = CommentedMap()
    root["import_sources"] = []
    return root


def load_registry(path: Path | None = None) -> dict[str, Any]:
    """
    Load registry.yaml.
    Returns empty registry structure if file doesn't exist — never errors.
    """
    p = path or registry_path()
    if not p.is_file():
        return {
            "schema_version": 1,
            "document_kind": DOCUMENT_KIND,
            "projects": {},
            "resources": {},
            "import_sources": [],
        }
    try:
        y = _yaml_rt()
        data = y.load(p.read_text(encoding="utf-8"))
    except Exception:
        return {
            "schema_version": 1,
            "document_kind": DOCUMENT_KIND,
            "projects": {},
            "resources": {},
            "import_sources": [],
        }
    if not isinstance(data, dict):
        return {
            "schema_version": 1,
            "document_kind": DOCUMENT_KIND,
            "projects": {},
            "resources": {},
            "import_sources": [],
        }
    out = dict(data)
    out.setdefault("schema_version", 1)
    out.setdefault("document_kind", DOCUMENT_KIND)
    out.setdefault("projects", {})
    out.setdefault("resources", {})
    out.setdefault("import_sources", [])
    if not isinstance(out["projects"], dict):
        out["projects"] = {}
    if not isinstance(out["resources"], dict):
        out["resources"] = {}
    if not isinstance(out["import_sources"], list):
        out["import_sources"] = []
    return out


def save_registry(data: dict[str, Any], path: Path | None = None) -> None:
    """
    Write registry.yaml using ruamel.yaml (round-trip when file exists).
    Creates ~/.forge/ if needed.
    """
    p = path or registry_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    y = _yaml_rt()
    if p.is_file():
        try:
            existing = y.load(p.read_text(encoding="utf-8"))
            root = _as_commented_map(existing if isinstance(existing, dict) else {})
        except Exception:
            root = _empty_registry_root()
    else:
        root = _empty_registry_root()
    root["schema_version"] = data.get("schema_version", root.get("schema_version", 1))
    root["document_kind"] = data.get("document_kind", DOCUMENT_KIND)
    new_p = data.get("projects") or {}
    pr = root.setdefault("projects", CommentedMap())
    if not isinstance(pr, CommentedMap):
        pr = _as_commented_map(dict(pr) if isinstance(pr, dict) else {})
        root["projects"] = pr
    keep = {str(k) for k in new_p.keys()}
    for rk in list(pr.keys()):
        if str(rk) not in keep:
            del pr[rk]
    for pk, pv in new_p.items():
        pr[str(pk)] = _as_commented_map(pv) if isinstance(pv, dict) else pv
    new_r = data.get("resources") or {}
    rr = root.setdefault("resources", CommentedMap())
    if not isinstance(rr, CommentedMap):
        rr = _as_commented_map(dict(rr) if isinstance(rr, dict) else {})
        root["resources"] = rr
    keep_r = {str(k) for k in new_r.keys()}
    for rk in list(rr.keys()):
        if str(rk) not in keep_r:
            del rr[rk]
    for rk, rv in new_r.items():
        rr[str(rk)] = _as_commented_map(rv) if isinstance(rv, dict) else rv
    root["import_sources"] = list(data.get("import_sources") or [])
    with p.open("w", encoding="utf-8") as f:
        y.dump(root, f)


def _projects_map(reg: dict[str, Any]) -> dict[str, Any]:
    p = reg.get("projects")
    return p if isinstance(p, dict) else {}


def get_project(slug: str, registry: dict[str, Any] | None = None) -> dict[str, Any] | None:
    """Get one project by slug (exact key)."""
    reg = registry if registry is not None else load_registry()
    pmap = _projects_map(reg)
    if slug in pmap and isinstance(pmap[slug], dict):
        return dict(pmap[slug])
    for k, v in pmap.items():
        if not isinstance(v, dict):
            continue
        if str(v.get("id", k)) == slug:
            return dict(v)
    return None


def detect_slug(path: Path) -> str:
    """
    Derive slug from directory name (see spec: lowercase, -/space → _, no camel splits).
    """
    return detect_slug_from_name(path.name)


def detect_slug_from_name(name: str) -> str:
    s = name.strip().replace(" ", "_").replace("-", "_")
    s = s.lower()
    s = re.sub(r"_+", "_", s).strip("_")
    return s or "project"


def _read_package_json_dict(project_root: Path) -> dict[str, Any] | None:
    pj = project_root / "package.json"
    if not pj.is_file():
        return None
    try:
        data = json.loads(pj.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def detect_stack(path: Path) -> str:
    """Detect stack from project root markers (ordered checks)."""
    root = path.resolve()
    if (root / "pubspec.yaml").is_file():
        return "flutter"
    data = _read_package_json_dict(root)
    if data:
        deps = data.get("dependencies") or {}
        dev = data.get("devDependencies") or {}
        if not isinstance(deps, dict):
            deps = {}
        if not isinstance(dev, dict):
            dev = {}
        all_deps = {**deps, **dev}
        if "next" in all_deps:
            return "nextjs"
        if all_deps.get("react") or "react" in deps:
            return "react"
        return "node"
    if (root / "pyproject.toml").is_file():
        return "python"
    if (root / "requirements.txt").is_file():
        return "python"
    return "unknown"


def detect_phase(path: Path) -> int:
    """Read phase from root or docs manifest (phases.current or list entry status: current)."""
    from forge.core.manifest_document import ManifestDocument
    from forge.core.manifest import resolve_manifest_path
    import yaml

    root = path.expanduser().resolve()
    try:
        doc = ManifestDocument.from_path(root)
        data = doc.to_legacy_dict()
    except (FileNotFoundError, ValueError):
        mp = resolve_manifest_path(root, warn_on_root_fallback=False)
        if mp is None or not mp.is_file():
            return 1
        try:
            raw = yaml.safe_load(mp.read_text(encoding="utf-8")) or {}
            if not isinstance(raw, dict):
                return 1
            data = raw
        except Exception:
            return 1
    if isinstance(data, dict):
        phases = data.get("phases")
        if isinstance(phases, dict):
            cur = phases.get("current")
            if cur is not None:
                try:
                    return int(cur)
                except (TypeError, ValueError):
                    return 1
        if isinstance(phases, list):
            for row in phases:
                if not isinstance(row, dict):
                    continue
                st = str(row.get("status", "")).lower()
                if st in ("current", "in_progress"):
                    pid = row.get("id", row.get("phase"))
                    if pid is not None:
                        try:
                            return int(pid)
                        except (TypeError, ValueError):
                            return 1
    return 1


def _normalize_relations(rel: dict[str, Any] | None) -> dict[str, list[str]]:
    base = _empty_relations()
    if not rel or not isinstance(rel, dict):
        return base
    for k in base:
        v = rel.get(k)
        if isinstance(v, list):
            base[k] = [str(x) for x in v if x is not None]
    return base


def add_project(
    path: Path,
    slug: str | None = None,
    stack: str | None = None,
    phase: int | None = None,
    tags: list[str] | None = None,
    relations: dict[str, Any] | None = None,
    *,
    force: bool = False,
    registry: dict[str, Any] | None = None,
    persist: bool = True,
) -> dict[str, Any]:
    """
    Add project to registry. Auto-detects slug, stack, phase when omitted.
    Raises ProjectExistsError if id exists and force is False.
    """
    reg = deepcopy_reg(registry)
    project_root = path.expanduser().resolve()
    if not project_root.is_dir():
        raise ValueError(f"Not a directory: {project_root}")
    if slug is not None and str(slug).strip():
        pid = detect_slug_from_name(str(slug).strip())
    else:
        pid = detect_slug(project_root)
    pmap = _projects_map(reg)
    if pid in pmap and not force:
        raise ProjectExistsError(pid)
    if isinstance(stack, str) and stack.strip():
        stk = stack.strip()
    else:
        stk = detect_stack(project_root)
    ph = int(phase) if phase is not None else detect_phase(project_root)
    tag_list = [str(t).strip() for t in (tags or []) if str(t).strip()]
    rel = _normalize_relations(relations)
    entry: dict[str, Any] = {
        "id": pid,
        "path": str(project_root),
        "stack": stk,
        "phase": ph,
        "status": "active",
        "added": date.today().isoformat(),
        "tags": tag_list,
        "relations": rel,
    }
    pmap[pid] = entry
    reg["projects"] = pmap
    if persist:
        save_registry(reg)
    return entry


def deepcopy_reg(reg: dict[str, Any] | None) -> dict[str, Any]:
    """Plain deep copy for registry dict."""
    import copy

    base = load_registry() if reg is None else reg
    return copy.deepcopy(base)


def update_project(
    slug: str,
    *,
    registry: dict[str, Any] | None = None,
    persist: bool = True,
    **fields: Any,
) -> dict[str, Any]:
    """Update specific fields on a project (shallow merge for relations)."""
    reg = deepcopy_reg(registry)
    pmap = _projects_map(reg)
    key = resolve_slug(slug, reg)
    if not key or key not in pmap or not isinstance(pmap[key], dict):
        raise KeyError(slug)
    cur = dict(pmap[key])
    rel_update = fields.pop("relations", None)
    for k, v in fields.items():
        if k == "tags" and v is not None:
            cur["tags"] = [str(t) for t in v] if isinstance(v, list) else cur.get("tags", [])
        elif v is not None:
            cur[k] = v
    if rel_update is not None and isinstance(rel_update, dict):
        base = _normalize_relations(cur.get("relations"))
        for rk, rv in rel_update.items():
            if rk in base and isinstance(rv, list):
                base[rk] = list(dict.fromkeys(base[rk] + [str(x) for x in rv]))
        cur["relations"] = base
    pmap[key] = cur
    reg["projects"] = pmap
    if persist:
        save_registry(reg)
    return cur


def remove_project(slug: str, registry: dict[str, Any] | None = None, *, persist: bool = True) -> bool:
    """Remove project from registry. Returns True if removed."""
    reg = deepcopy_reg(registry)
    pmap = _projects_map(reg)
    key = resolve_slug(slug, reg)
    if not key or key not in pmap:
        return False
    del pmap[key]
    reg["projects"] = pmap
    if persist:
        save_registry(reg)
    return True


def list_projects(
    *,
    status: str | None = None,
    stack: str | None = None,
    tags: list[str] | None = None,
    registry: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """List projects with optional filters."""
    reg = registry if registry is not None else load_registry()
    pmap = _projects_map(reg)
    want_tags = {t.strip().lower() for t in (tags or []) if t and str(t).strip()}
    out: list[dict[str, Any]] = []
    for k, v in pmap.items():
        if not isinstance(v, dict):
            continue
        row = dict(v)
        row.setdefault("id", k)
        if status and str(row.get("status", "active")).lower() != status.lower():
            continue
        if stack and str(row.get("stack", "")).lower() != stack.lower():
            continue
        if want_tags:
            pt = {str(t).lower() for t in (row.get("tags") or []) if t}
            if not want_tags.intersection(pt):
                continue
        out.append(row)
    out.sort(key=lambda r: str(r.get("id", "")))
    return out


def touch_project(slug: str, registry: dict[str, Any] | None = None, *, persist: bool = True) -> None:
    """Update last_accessed timestamp."""
    reg = deepcopy_reg(registry)
    key = resolve_slug(slug, reg)
    if not key:
        return
    pmap = _projects_map(reg)
    if key not in pmap or not isinstance(pmap[key], dict):
        return
    pmap[key]["last_accessed"] = datetime.now(timezone.utc).isoformat()
    reg["projects"] = pmap
    if persist:
        save_registry(reg)


def _norm_key(s: str) -> str:
    return detect_slug_from_name(s.replace(".", "_"))


def resolve_slug(query: str, registry: dict[str, Any] | None = None) -> str | None:
    """
    Fuzzy slug resolution: exact, case-insensitive, hyphen/underscore, unique prefix.
    """
    reg = registry if registry is not None else load_registry()
    pmap = _projects_map(reg)
    if not pmap:
        return None
    q = query.strip()
    if not q:
        return None
    keys = [str(k) for k in pmap.keys()]
    if q in pmap:
        return q
    qlow = q.lower()
    for k in keys:
        if k.lower() == qlow:
            return k
    nq = _norm_key(q)
    for k in keys:
        if _norm_key(k) == nq:
            return k
    matches = [k for k in keys if k.lower().startswith(qlow)]
    if len(matches) == 1:
        return matches[0]
    return None


def resolve_registry_project_path(project_id: str) -> Path | None:
    """Resolve slug via registry only (absolute path if directory exists)."""
    reg = load_registry()
    sid = resolve_slug(project_id, reg)
    if not sid:
        return None
    ent = get_project(sid, reg)
    if not ent:
        return None
    p = Path(str(ent.get("path", ""))).expanduser().resolve()
    return p if p.is_dir() else None


class WorkspaceStore:
    """Minimal workspace registry access used by MCP path resolution."""

    def _entries(self) -> list[dict[str, Any]]:
        """Return registry project entries as dict rows."""
        return list_projects()

    def find_by_path(self, path: str) -> dict[str, Any] | None:
        """Find a project whose root matches or contains the given path."""
        resolved = Path(path).expanduser().resolve()
        for entry in self._entries():
            raw_entry_path = entry.get("path", "")
            entry_path = Path(str(raw_entry_path)).expanduser().resolve()
            if entry_path == resolved or resolved.is_relative_to(entry_path):
                return entry
        return None
