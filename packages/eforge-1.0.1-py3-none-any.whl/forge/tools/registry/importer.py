from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from forge.tools.registry.store import (
    ProjectExistsError,
    add_project,
    detect_phase,
    detect_slug,
    detect_stack,
    load_registry,
    save_registry,
)
from forge.tools.workspace_store import strip_jsonc_comments


def _record_import_source(reg: dict[str, Any], kind: str, path_abs: str) -> None:
    sources = list(reg.get("import_sources") or [])
    if not isinstance(sources, list):
        sources = []
    entry = {
        "kind": kind,
        "path": path_abs,
        "last_imported": datetime.now(timezone.utc).isoformat(),
        "auto_sync": False,
    }
    sources = [
        s
        for s in sources
        if not (isinstance(s, dict) and s.get("path") == path_abs and s.get("kind") == kind)
    ]
    sources.append(entry)
    reg["import_sources"] = sources
    save_registry(reg)


def import_from_code_workspace(
    workspace_path: Path,
    dry_run: bool = False,
    force: bool = False,
) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
    """
    Import projects from a .code-workspace file.
    Returns (added_entries, errors).
    """
    wp = workspace_path.expanduser().resolve()
    errors: list[dict[str, str]] = []
    added: list[dict[str, Any]] = []
    if not wp.is_file():
        return [], [{"path": str(wp), "error": "not a file"}]
    try:
        cleaned = strip_jsonc_comments(wp.read_text(encoding="utf-8"))
        raw = json.loads(cleaned)
    except Exception as e:
        return [], [{"path": str(wp), "error": str(e)}]
    folders = raw.get("folders") if isinstance(raw, dict) else None
    if not isinstance(folders, list):
        return [], [{"path": str(wp), "error": "no folders[]"}]
    base = wp.parent.resolve()

    for row in folders:
        if not isinstance(row, dict):
            continue
        p = row.get("path")
        if not p:
            continue
        try:
            ap = (base / str(p)).resolve() if not Path(str(p)).is_absolute() else Path(str(p)).resolve()
        except Exception as e:
            errors.append({"path": str(p), "error": str(e)})
            continue
        if not ap.is_dir():
            errors.append({"path": str(ap), "error": "not a directory"})
            continue
        slug = detect_slug(ap)
        if dry_run:
            added.append(
                {
                    "id": slug,
                    "path": str(ap),
                    "stack": detect_stack(ap),
                    "phase": detect_phase(ap),
                }
            )
            continue
        try:
            entry = add_project(ap, slug=slug, force=force)
            added.append(entry)
        except ProjectExistsError:
            errors.append({"path": str(ap), "error": f"exists: {slug}"})
        except Exception as e:
            errors.append({"path": str(ap), "error": str(e)})

    if not dry_run and added:
        reg = load_registry()
        _record_import_source(reg, "code_workspace", str(wp))
    return added, errors


def import_from_yaml(
    yaml_path: Path,
    dry_run: bool = False,
    force: bool = False,
) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
    """
    Import from workspace.yaml or config.yaml-style `projects:` map.
    """
    yp = yaml_path.expanduser().resolve()
    errors: list[dict[str, str]] = []
    added: list[dict[str, Any]] = []
    if not yp.is_file():
        return [], [{"path": str(yp), "error": "not a file"}]
    try:
        data = yaml.safe_load(yp.read_text(encoding="utf-8")) or {}
    except Exception as e:
        return [], [{"path": str(yp), "error": str(e)}]
    if not isinstance(data, dict):
        return [], [{"path": str(yp), "error": "not a mapping"}]
    projects = data.get("projects")
    if not isinstance(projects, dict):
        return [], [{"path": str(yp), "error": "no projects mapping"}]

    for key, row in projects.items():
        if not isinstance(row, dict):
            continue
        path_s = row.get("path")
        if not path_s:
            errors.append({"path": str(key), "error": "missing path"})
            continue
        try:
            ap = Path(str(path_s)).expanduser().resolve()
        except Exception as e:
            errors.append({"path": str(path_s), "error": str(e)})
            continue
        if not ap.is_dir():
            errors.append({"path": str(ap), "error": "not a directory"})
            continue
        slug = detect_slug_from_key(str(key), ap)
        if dry_run:
            added.append(
                {
                    "id": slug,
                    "path": str(ap),
                    "stack": row.get("stack") or detect_stack(ap),
                    "phase": int(row.get("phase", detect_phase(ap))),
                }
            )
            continue
        try:
            pv = row.get("phase")
            ph = int(pv) if pv is not None else detect_phase(ap)
            entry = add_project(
                ap,
                slug=slug,
                stack=str(row["stack"]) if row.get("stack") is not None else None,
                phase=ph,
                force=force,
            )
            added.append(entry)
        except ProjectExistsError:
            errors.append({"path": str(ap), "error": f"exists: {slug}"})
        except Exception as e:
            errors.append({"path": str(ap), "error": str(e)})

    if not dry_run and added:
        reg = load_registry()
        _record_import_source(reg, "yaml", str(yp))
    return added, errors


def detect_slug_from_key(key: str, path: Path) -> str:
    from forge.tools.registry.store import detect_slug_from_name

    if key and str(key).strip():
        return detect_slug_from_name(str(key))
    return detect_slug(path)
