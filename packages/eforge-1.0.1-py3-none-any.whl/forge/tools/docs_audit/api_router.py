from __future__ import annotations

import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from forge.core.manifest_path import resolve_manifest_path
from forge.tools.docs_audit.contracts.models import Severity
from forge.tools.docs_audit.orchestrator import run_docs_audit
from forge.tools.docs_audit.output.schema import AuditResponse, Failure, TriggeredRule
from forge.renderers.web.error_codes import DashboardErrorCode
from forge.renderers.web.error_response import DashboardError


impact_router = APIRouter(prefix="/api/impact", tags=["impact"])


class EvaluateRequest(BaseModel):
    project_path: str
    changed_files: list[str]
    strict: bool
    changed_text: str | None = ""


class WaiverValidateRequest(BaseModel):
    rule_id: str
    reason: str
    owner: str
    expires_on: str  # ISO date


def _resolve_project_paths(project_path: Path) -> tuple[Path, Path, Path, Path]:
    if not project_path.exists():
        raise DashboardError(
            DashboardErrorCode.IMPACT_PROJECT_NOT_FOUND,
            "Project path not found",
            detail=str(project_path),
            status_code=404,
        )
    # Prefer docs/ variants, fall back to repo-root variants.
    docs_root = project_path / "docs"
    if not docs_root.exists():
        docs_root = project_path

    manifest = resolve_manifest_path(project_path)
    if manifest is None or not manifest.exists():
        raise DashboardError(
            DashboardErrorCode.IMPACT_MANIFEST_MISSING,
            "manifest.yaml not found",
            detail=str(project_path),
            status_code=404,
        )

    # DEPRECATED: change-impact.yaml — evaluate endpoint legacy; rules API returns empty.
    impact = project_path / ".forge" / "change-impact.yaml"
    if not impact.exists():
        impact = project_path / "change-impact.yaml"
    if not impact.exists():
        impact = docs_root / "change-impact.yaml"
    if not impact.exists():
        raise HTTPException(
            status_code=400,
            detail=f"change-impact.yaml not found under {project_path} (legacy evaluate API)",
        )

    impact_local = docs_root / "change-impact.local.yaml"
    if not impact_local.exists():
        impact_local = project_path / "change-impact.local.yaml"

    return manifest, impact, impact_local, docs_root


def _audit_result_to_response(project: str, result: Any, strict_mode: bool) -> AuditResponse:
    exit_code = int(result.exit_code)
    status: str = "pass"
    if exit_code == 2:
        status = "fail"
    elif exit_code == 1:
        status = "warn"

    pass_count = sum(1 for tr in result.triggered_rules if tr.rule.severity == Severity.NORMAL)
    warn_count = sum(1 for tr in result.triggered_rules if tr.rule.severity == Severity.HIGH)
    blocker_count = sum(1 for tr in result.triggered_rules if tr.rule.severity == Severity.BLOCKER)

    triggered_rules: list[TriggeredRule] = []
    rule_sources: dict[str, str] = {}
    for tr in result.triggered_rules:
        triggered_rules.append(
            TriggeredRule(
                rule_id=tr.rule.id,
                severity=tr.rule.severity.value,
                source=tr.rule.source,
                reason="; ".join(tr.reasons) if tr.reasons else "n/a",
            )
        )
        rule_sources[tr.rule.id] = tr.rule.source

    failures: list[Failure] = []
    for f in result.failures:
        suggested = f.suggested_updates[0] if f.suggested_updates else ""
        failures.append(
            Failure(
                rule_id=f.rule_id,
                severity=f.severity.value,
                file=f.file,
                message=f.message,
                suggested_update=suggested,
                source=f.rule_source,
                waiver_status=None,
            )
        )

    return AuditResponse(
        project=project,
        status=status,  # type: ignore[arg-type]
        exit_code=exit_code,  # type: ignore[arg-type]
        triggered_rules=triggered_rules,
        failures=failures,
        pass_count=pass_count,
        warn_count=warn_count,
        blocker_count=blocker_count,
        generated_at=datetime.now(timezone.utc).isoformat(),
        strict_mode=strict_mode,
        rule_sources=rule_sources,  # type: ignore[arg-type]
    )


@impact_router.get("/rules")
def get_impact_rules(project_path: str) -> dict[str, Any]:
    # change-impact.yaml lookup — DEPRECATED
    # The change-impact.yaml system was phased out.
    # Use forge_impact_radius or forge_verify instead.
    # This endpoint is preserved for API compatibility
    # but returns empty rules.
    _ = project_path  # API contract: callers still pass project_path
    return {
        "rules": [],
        "deprecated": True,
        "message": "change-impact.yaml system phased out. Use forge_impact_radius instead.",
    }


@impact_router.post("/evaluate")
def evaluate_impact(req: EvaluateRequest) -> AuditResponse:
    project_path = Path(req.project_path).resolve()
    manifest_path, impact_path, impact_local, docs_root = _resolve_project_paths(project_path)

    result = run_docs_audit(
        manifest_path=str(manifest_path),
        impact_path=str(impact_path),
        impact_local_path=str(impact_local) if impact_local.exists() else None,
        docs_root=str(docs_root),
        changed_files=req.changed_files,
        changed_text=req.changed_text or "",
        strict=req.strict,
    )
    return _audit_result_to_response(project=req.project_path, result=result, strict_mode=bool(getattr(result, "strict", req.strict)))


@impact_router.post("/waiver/validate")
def validate_waiver(req: WaiverValidateRequest) -> dict[str, Any]:
    """
    Lightweight waiver validation.
    (Frontend currently does not call this; endpoint exists for completeness.)
    """
    try:
        # validate ISO date (YYYY-MM-DD)
        _ = datetime.fromisoformat(req.expires_on)
    except Exception:
        raise HTTPException(status_code=400, detail="expires_on must be ISO datetime/date (YYYY-MM-DD)")
    if not req.reason.strip():
        raise HTTPException(status_code=400, detail="reason required")
    if not req.owner.strip():
        raise HTTPException(status_code=400, detail="owner required")
    return {"ok": True}


@impact_router.get("/git-diff")
def git_diff(project_path: str) -> dict[str, Any]:
    """
    Helper for UI: returns `git diff --name-only` output.
    """
    root = Path(project_path).resolve()
    try:
        proc = subprocess.run(
            ["git", "diff", "--name-only"],
            cwd=str(root),
            check=False,
            capture_output=True,
            text=True,
        )
        files = [line.strip() for line in (proc.stdout or "").splitlines() if line.strip()]
        return {"changed_files": files}
    except Exception:
        return {"changed_files": []}

