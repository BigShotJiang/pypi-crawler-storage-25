"""
Semantic manifest diff: change_kinds (HOW) vs change_types (WHAT).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class SemanticChange:
    kind: str
    changed_node: str
    old_value: dict[str, Any] | None
    new_value: dict[str, Any] | None
    affected: list[str] = field(default_factory=list)
    requires_adr: bool = False
    severity: str = "info"


def _controllers_list(m: dict[str, Any]) -> list[dict[str, Any]]:
    c = m.get("controllers")
    if not isinstance(c, list):
        return []
    return [x for x in c if isinstance(x, dict)]


def _screens_entries(m: dict[str, Any]) -> list[tuple[str, dict[str, Any]]]:
    out: list[tuple[str, dict[str, Any]]] = []
    for s in m.get("screens") or []:
        if isinstance(s, dict):
            nm = str(s.get("name") or Path(str(s.get("path") or "")).stem or "")
            out.append((nm, s))
        elif isinstance(s, str):
            out.append((Path(s).stem, {"path": s}))
    return out


def _ctrl_names(m: dict[str, Any]) -> set[str]:
    return {str(c.get("name", "")) for c in _controllers_list(m) if c.get("name")}


def _find_kind(change_kinds: list[dict[str, Any]], kid: str) -> dict[str, Any] | None:
    for k in change_kinds:
        if isinstance(k, dict) and str(k.get("id", "")) == kid:
            return k
    return None


def traverse_manifest_graph(
    manifest: dict[str, Any],
    changed_node: str,
    traverse_kinds: list[str],
) -> list[str]:
    """Walk manifest relationships; never raises."""
    try:
        out: list[str] = []
        ctrl_name = ""
        if "controllers." in changed_node:
            parts = changed_node.split(".")
            if len(parts) >= 2:
                ctrl_name = parts[1]
        elif changed_node.startswith("screens."):
            parts = changed_node.split(".")
            if len(parts) >= 2:
                ctrl_name = parts[1]
        else:
            ctrl_name = changed_node.split(".")[-1] if "." in changed_node else changed_node

        for tk in traverse_kinds:
            if tk == "watchers":
                out.extend(_watchers_for_controller(manifest, ctrl_name))
            elif tk == "dependents":
                out.extend(_dependents_for_controller(manifest, ctrl_name))
            elif tk == "error_codes":
                dom = _domain_for_controller(manifest, ctrl_name)
                if dom:
                    out.append(f"ERROR_CODES.md:{dom}")
                else:
                    out.append("ERROR_CODES.md")
            elif tk == "screen_consumers":
                out.extend(_screens_with_variant(manifest, changed_node))
            elif tk == "variant_consumers":
                out.extend(_variant_consumer_screens(manifest))
            elif tk == "all_affected_layers":
                out.extend(["screens", "controllers", "services"])
        return sorted(set(out))
    except Exception:
        return []


def _watchers_for_controller(manifest: dict[str, Any], controller_name: str) -> list[str]:
    found: list[str] = []
    for name, sdict in _screens_entries(manifest):
        watches = sdict.get("watches")
        if not isinstance(watches, list):
            continue
        for w in watches:
            if controller_name and controller_name in str(w):
                found.append(name or str(sdict.get("path", "screen")))
    return found


def _dependents_for_controller(manifest: dict[str, Any], controller_name: str) -> list[str]:
    found: list[str] = []
    for c in _controllers_list(manifest):
        nm = str(c.get("name", ""))
        if not nm or nm == controller_name:
            continue
        reads = c.get("reads") or []
        if isinstance(reads, list) and controller_name:
            for r in reads:
                if controller_name in str(r):
                    found.append(nm)
                    break
    return found


def _domain_for_controller(manifest: dict[str, Any], controller_name: str) -> str:
    for c in _controllers_list(manifest):
        if str(c.get("name", "")) == controller_name:
            return str(c.get("domain", "") or "")
    return ""


def _screens_with_variant(manifest: dict[str, Any], changed_node: str) -> list[str]:
    # changed_node like screens.MyScreen.variant
    parts = changed_node.split(".")
    target = parts[1] if len(parts) > 1 else ""
    found: list[str] = []
    for name, sdict in _screens_entries(manifest):
        if target and name != target and str(sdict.get("path", "")) != target:
            continue
        if "variant" in sdict:
            found.append(name or str(sdict.get("path", "screen")))
    return found


def _variant_consumer_screens(manifest: dict[str, Any]) -> list[str]:
    return [n or str(d.get("path", "")) for n, d in _screens_entries(manifest) if d.get("variant")]


def classify_change(
    old_manifest: dict[str, Any],
    new_manifest: dict[str, Any],
    change_kinds: list[dict[str, Any]],
) -> list[SemanticChange]:
    """
    Compare two manifest states using change_kinds policy.
    Never raises (empty list on failure).
    """
    try:
        if not isinstance(old_manifest, dict) or not isinstance(new_manifest, dict):
            return []
        if not isinstance(change_kinds, list):
            return []

        out: list[SemanticChange] = []
        names = _ctrl_names(old_manifest) | _ctrl_names(new_manifest)

        for name in sorted(names):
            o = next((c for c in _controllers_list(old_manifest) if str(c.get("name", "")) == name), None)
            n = next((c for c in _controllers_list(new_manifest) if str(c.get("name", "")) == name), None)
            if o is None or n is None:
                continue

            kd_iface = _find_kind(change_kinds, "interface_contract_change")
            if kd_iface:
                iface_delta = (
                    _list_sig(o.get("reads"))
                    != _list_sig(n.get("reads"))
                    or _list_sig(o.get("writes"))
                    != _list_sig(n.get("writes"))
                    or _list_sig(o.get("fires"))
                    != _list_sig(n.get("fires"))
                    or _json_sig(o.get("interface"))
                    != _json_sig(n.get("interface"))
                )
                if iface_delta:
                    node = f"controllers.{name}.interface"
                    tr = kd_iface.get("traverse") or []
                    tr_list = [str(x) for x in tr] if isinstance(tr, list) else []
                    out.append(
                        SemanticChange(
                            kind="interface_contract_change",
                            changed_node=f"controllers.{name}",
                            old_value={
                                "reads": o.get("reads"),
                                "writes": o.get("writes"),
                                "fires": o.get("fires"),
                                "interface": o.get("interface"),
                            },
                            new_value={
                                "reads": n.get("reads"),
                                "writes": n.get("writes"),
                                "fires": n.get("fires"),
                                "interface": n.get("interface"),
                            },
                            affected=traverse_manifest_graph(new_manifest, node, tr_list),
                            requires_adr=bool(kd_iface.get("requires_adr")),
                            severity=str(kd_iface.get("severity", "blocker")),
                        )
                    )

            kd_domain = _find_kind(change_kinds, "domain_reassignment")
            if kd_domain and str(o.get("domain", "")) != str(n.get("domain", "")):
                node = f"controllers.{name}.domain"
                tr = kd_domain.get("traverse") or []
                tr_list = [str(x) for x in tr] if isinstance(tr, list) else []
                out.append(
                    SemanticChange(
                        kind="domain_reassignment",
                        changed_node=node,
                        old_value={"domain": o.get("domain")},
                        new_value={"domain": n.get("domain")},
                        affected=traverse_manifest_graph(new_manifest, node, tr_list),
                        requires_adr=bool(kd_domain.get("requires_adr")),
                        severity=str(kd_domain.get("severity", "blocker")),
                    )
                )

        kd_comp = _find_kind(change_kinds, "component_swap")
        if kd_comp:
            old_s = {n: d for n, d in _screens_entries(old_manifest)}
            new_s = {n: d for n, d in _screens_entries(new_manifest)}
            for key in sorted(set(old_s) | set(new_s)):
                od, nd = old_s.get(key, {}), new_s.get(key, {})
                if not nd:
                    continue
                ov, nv = od.get("variant"), nd.get("variant")
                if key in old_s and ov != nv:
                    node = f"screens.{key}.variant"
                    tr = kd_comp.get("traverse") or []
                    tr_list = [str(x) for x in tr] if isinstance(tr, list) else []
                    out.append(
                        SemanticChange(
                            kind="component_swap",
                            changed_node=node,
                            old_value={"variant": ov},
                            new_value={"variant": nv},
                            affected=traverse_manifest_graph(new_manifest, node, tr_list),
                            requires_adr=bool(kd_comp.get("requires_adr")),
                            severity=str(kd_comp.get("severity", "warn")),
                        )
                    )

        kd_arch = _find_kind(change_kinds, "architecture_change")
        if kd_arch and old_manifest.get("phases") != new_manifest.get("phases"):
            node = "manifest.phases"
            tr = kd_arch.get("traverse") or []
            tr_list = [str(x) for x in tr] if isinstance(tr, list) else []
            out.append(
                SemanticChange(
                    kind="architecture_change",
                    changed_node=node,
                    old_value={"phases": old_manifest.get("phases")},
                    new_value={"phases": new_manifest.get("phases")},
                    affected=traverse_manifest_graph(new_manifest, node, tr_list),
                    requires_adr=bool(kd_arch.get("requires_adr")),
                    severity=str(kd_arch.get("severity", "blocker")),
                )
            )

        return out
    except Exception:
        return []


def _list_sig(v: Any) -> tuple[Any, ...]:
    if v is None:
        return ()
    if isinstance(v, list):
        return tuple(str(x) for x in v)
    return (str(v),)


def _json_sig(v: Any) -> str:
    import json

    try:
        return json.dumps(v, sort_keys=True, default=str)
    except Exception:
        return str(v)


def semantic_change_to_dict(sc: SemanticChange) -> dict[str, Any]:
    return {
        "kind": sc.kind,
        "changed_node": sc.changed_node,
        "old_value": sc.old_value,
        "new_value": sc.new_value,
        "affected": list(sc.affected),
        "requires_adr": sc.requires_adr,
        "severity": sc.severity,
    }
