from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from forge.tools.registry.graph import blast_radius_ring1

if TYPE_CHECKING:
    from forge.tools.manifest.graph import ManifestGraph


UNIVERSAL_PRINCIPLES = [
    "PARENT_CHANGE_AFFECTS_CHILDREN",
    "SHARED_RESOURCE_CHANGE_AFFECTS_CONSUMERS",
    "CONTRACT_CHANGE_AFFECTS_IMPLEMENTORS",
    "INTERFACE_CHANGE_AFFECTS_WATCHERS",
    "SCHEMA_CHANGE_AFFECTS_READERS",
    "CHANGE_CLASS_PROPAGATION",
]


@dataclass(frozen=True)
class PrincipleResult:
    principle: str
    changed_node: str
    affected_nodes: list[str]
    severity: str
    reason: str
    ring: int
    derived: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)


def principle_interface_change(
    node_id: str,
    manifest_graph: "ManifestGraph",
) -> PrincipleResult | None:
    by_id = {n.id: n for n in manifest_graph.nodes}
    n = by_id.get(node_id)
    if n is None or n.kind != "controller":
        return None
    watchers = [x.name for x in manifest_graph.find_watchers(n.id)]
    if not watchers:
        return None
    return PrincipleResult(
        principle="INTERFACE_CHANGE_AFFECTS_WATCHERS",
        changed_node=n.name,
        affected_nodes=sorted(set(watchers)),
        severity="high",
        reason=f"Controller interface changed; watching screens may break: {n.name}",
        ring=2,
    )


def principle_reads_change(
    node_id: str,
    manifest_graph: "ManifestGraph",
) -> PrincipleResult | None:
    by_id = {n.id: n for n in manifest_graph.nodes}
    n = by_id.get(node_id)
    if n is None or n.kind != "service":
        return None
    deps = [x.name for x in manifest_graph.find_dependents(n.id)]
    if not deps:
        return None
    return PrincipleResult(
        principle="SHARED_RESOURCE_CHANGE_AFFECTS_CONSUMERS",
        changed_node=n.name,
        affected_nodes=sorted(set(deps)),
        severity="blocker",
        reason=f"Service contract changed; dependent controllers must be checked: {n.name}",
        ring=2,
    )


def principle_domain_change(
    node_id: str,
    manifest_graph: "ManifestGraph",
) -> PrincipleResult | None:
    by_id = {n.id: n for n in manifest_graph.nodes}
    n = by_id.get(node_id)
    if n is None:
        return None
    domain = n.name if n.kind == "domain" else (n.domain or "")
    if not domain:
        return None
    members = [x.name for x in manifest_graph.find_domain_members(domain) if x.id != node_id]
    if not members:
        return None
    return PrincipleResult(
        principle="CHANGE_CLASS_PROPAGATION",
        changed_node=n.name,
        affected_nodes=sorted(set(members)),
        severity="high",
        reason=f"Domain membership changed; member docs and error codes may drift: {domain}",
        ring=2,
        metadata={"legacy_domain_broadcast": True, "domain": domain},
    )


def principle_parent_change(
    node_id: str,
    registry_graph: dict,
) -> PrincipleResult | None:
    if not node_id:
        return None
    br = blast_radius_ring1(node_id, registry_graph, change_kind="any")
    cousins = list(br.get("cousins") or [])
    if not cousins:
        return None
    return PrincipleResult(
        principle="PARENT_CHANGE_AFFECTS_CHILDREN",
        changed_node=node_id,
        affected_nodes=sorted(set(cousins)),
        severity="warn",
        reason="Project parent/backend adjacency changed; cousin projects sharing backend should be checked.",
        ring=1,
    )


def principle_contract_change(
    node_id: str,
    manifest_graph: "ManifestGraph",
) -> PrincipleResult | None:
    by_id = {n.id: n for n in manifest_graph.nodes}
    n = by_id.get(node_id)
    if n is None:
        return None
    implementors: list[str] = []
    for e in manifest_graph.edges:
        if e.relation != "implements" or e.to_id != node_id:
            continue
        src = by_id.get(e.from_id)
        if src:
            implementors.append(src.name)
    if not implementors:
        return None
    return PrincipleResult(
        principle="CONTRACT_CHANGE_AFFECTS_IMPLEMENTORS",
        changed_node=n.name,
        affected_nodes=sorted(set(implementors)),
        severity="high",
        reason=f"Contract changed; implementors must be reviewed: {n.name}",
        ring=2,
    )


def apply_principles(
    changed_node_id: str,
    changed_node_kind: str,
    change_kind: str,
    manifest_graph: "ManifestGraph",
    registry_graph: dict,
    *,
    skip_domain_principle: bool = False,
) -> list[PrincipleResult]:
    ck = (change_kind or "any").strip().lower()
    out: list[PrincipleResult] = []

    if ck in ("interface_change", "any"):
        r = principle_interface_change(changed_node_id, manifest_graph)
        if r:
            out.append(r)

    if ck in ("reads_change", "schema_change", "any"):
        r = principle_reads_change(changed_node_id, manifest_graph)
        if r:
            out.append(r)

    if not skip_domain_principle and ck in ("domain_change", "any"):
        r = principle_domain_change(changed_node_id, manifest_graph)
        if r:
            out.append(r)

    if ck in ("contract_change", "any"):
        r = principle_contract_change(changed_node_id, manifest_graph)
        if r:
            out.append(r)

    # Ring-1 principle is opt-in by passing a registry graph and project-ish node ids.
    if registry_graph and ck == "any" and changed_node_kind == "project":
        r = principle_parent_change(changed_node_id, registry_graph)
        if r:
            out.append(r)

    return out
