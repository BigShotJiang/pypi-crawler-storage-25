from __future__ import annotations

import json
import subprocess
from pathlib import Path

import click
import yaml

from forge.commands._shared_options import response_tier_option
from forge.core.manifest_path import resolve_manifest_path
from forge.core.path_utils import resolve_project_path
from forge.tools.docs_audit.loaders.changed_files import get_changed_files
from forge.tools.docs_audit.orchestrator import run_docs_audit
from forge.tools.docs_audit.output.summary import build_summary
from forge.tools.docs_audit.output.to_json import build_audit_json
from forge.tools.docs_audit.output.to_markdown import build_audit_markdown


def _maybe_run_map_hook(result: object, project_root: Path, no_hooks: bool) -> None:
    """CLI wrapper around maybe_run_map_hook: adds --no-hooks guard and click output.

    Delegates core hook logic to
    ``forge.tools.docs_audit.orchestrator.maybe_run_map_hook`` so the same
    behaviour fires from both the CLI and the MCP handler paths.
    """
    if no_hooks:
        return
    from forge.tools.docs_audit.orchestrator import maybe_run_map_hook  # noqa: PLC0415

    graph_impact = getattr(result, "graph_impact", None) or {}
    affected = graph_impact.get("affected_nodes") or []
    if affected:
        click.echo(
            f"\n[hooks] graph_impact affected_nodes={len(affected)} — running forge map…",
            err=True,
        )
    maybe_run_map_hook(result, project_root)
    if affected:
        click.echo("[hooks] forge map complete.", err=True)


def _git_show_manifest(project_root: Path, ref: str) -> dict | None:
    for rel in ("docs/manifest.yaml", "manifest.yaml"):
        try:
            proc = subprocess.run(
                ["git", "-C", str(project_root), "show", f"{ref}:{rel}"],
                capture_output=True,
                text=True,
                timeout=30,
                check=False,
            )
            if proc.returncode == 0 and (proc.stdout or "").strip():
                data = yaml.safe_load(proc.stdout)
                if isinstance(data, dict):
                    return data
        except Exception:
            continue
    return None


def _load_old_manifest_for_classify(
    project_root: Path,
    old_manifest_opt: str | None,
    git_ref: str,
) -> dict | None:
    if old_manifest_opt:
        p = Path(old_manifest_opt)
        p = p if p.is_absolute() else (project_root / p)
        if not p.is_file():
            return None
        data = yaml.safe_load(p.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    return _git_show_manifest(project_root, git_ref)


@click.command(name="docs-audit")
@click.option("--project-path", default=".", show_default=True, help="Target project root.")
@click.option("--manifest", default=".forge/manifest.yaml", show_default=True)
@click.option("--impact", default="", show_default=True, help="DEPRECATED: Use graph-based impact analysis instead")
@click.option("--impact-local", default="", show_default=True, help="DEPRECATED: Use graph-based impact analysis instead")
@click.option("--docs-root", default="docs", show_default=True)
@click.option("--changed-files-source", type=click.Choice(["git", "explicit"]), default="git", show_default=True)
@click.option("--changed-files-json", default="", show_default=False)
@click.option("--changed-files", multiple=True, help="Explicit changed file path(s). Repeatable.")
@click.option("--base", default="HEAD~1", show_default=True)
@click.option("--head", default="HEAD", show_default=True)
@click.option(
    "--out-json",
    default=None,
    type=str,
    help="Write JSON report to this path, or '-' for stdout. Default: do not write JSON.",
)
@click.option("--out-md", default="audit.md", show_default=True)
@click.option("--profile", default="", show_default=False)
@click.option("--all-files", is_flag=True, default=False, help="Audit all docs files regardless of git diff.")
@click.option("--strict", is_flag=True, default=False)
@click.option(
    "--classify",
    is_flag=True,
    default=False,
    help="Run semantic manifest diff (change_kinds) when old manifest is available (--old-manifest or git show).",
)
@click.option(
    "--old-manifest",
    default=None,
    type=str,
    help="Path to previous manifest.yaml for --classify (repo-relative or absolute).",
)
@click.option(
    "--git-ref",
    default="HEAD",
    show_default=True,
    help="Git ref for manifest when --classify is set without --old-manifest.",
)
@click.option(
    "--no-hooks",
    is_flag=True,
    default=False,
    help="Disable post-change hooks (e.g. auto forge map). Hooks run by default.",
)
@click.option(
    "--init",
    "init_rules",
    is_flag=True,
    default=False,
    help="Scaffold a .forge/change-impact.yaml from the baseline template.",
)
@response_tier_option(default="L0")
def docs_audit_cmd(
    project_path: str,
    manifest: str,
    impact: str,
    impact_local: str,
    docs_root: str,
    changed_files_source: str,
    changed_files_json: str,
    changed_files: tuple[str, ...],
    base: str,
    head: str,
    out_json: str,
    out_md: str,
    profile: str,
    all_files: bool,
    strict: bool,
    classify: bool,
    old_manifest: str | None,
    git_ref: str,
    no_hooks: bool,
    init_rules: bool,
    response_tier: str,
) -> None:
    _ = response_tier
    _ = profile  # profile override is reserved for policy profile expansion
    project_root = resolve_project_path(project_path)
    if project_root is None:
        raise click.ClickException("project_path could not be resolved")
    if init_rules:
        target = project_root / ".forge" / "change-impact.yaml"
        if target.exists():
            click.echo(f"Already exists: {target}")
            return
        target.parent.mkdir(parents=True, exist_ok=True)
        baseline = Path(__file__).resolve().parents[3] / ".forge" / "change-impact.yaml"
        if not baseline.exists():
            raise click.ClickException(f"baseline rules not found: {baseline}")
        target.write_text(baseline.read_text(encoding="utf-8"), encoding="utf-8")
        click.echo(f"Scaffolded: {target}")
        return
    manifest_path = (project_root / manifest).resolve() if not Path(manifest).is_absolute() else Path(manifest)
    impact_path = (project_root / impact).resolve() if not Path(impact).is_absolute() else Path(impact)
    impact_local_path = (
        (project_root / impact_local).resolve() if not Path(impact_local).is_absolute() else Path(impact_local)
    )
    docs_root_path = (project_root / docs_root).resolve() if not Path(docs_root).is_absolute() else Path(docs_root)
    # Compatibility fallbacks for projects keeping manifest/impact at repo root.
    if not manifest_path.exists():
        resolved_manifest = resolve_manifest_path(project_root)
        if resolved_manifest is not None and resolved_manifest.exists():
            manifest_path = resolved_manifest
    if not impact_path.exists():
        forge_impact = project_root / ".forge" / "change-impact.yaml"
        if forge_impact.exists():
            impact_path = forge_impact
        root_impact = project_root / "change-impact.yaml"
        if root_impact.exists():
            impact_path = root_impact
    if not impact_local_path.exists():
        root_impact_local = project_root / "change-impact.local.yaml"
        if root_impact_local.exists():
            impact_local_path = root_impact_local

    changed_files = get_changed_files(
        source=changed_files_source,
        base=base,
        head=head,
        changed_files_json=changed_files_json or None,
        changed_files=list(changed_files) if changed_files else None,
        cwd=str(project_root),
    )
    if all_files:
        changed_files = [str(p).replace("\\", "/") for p in docs_root_path.rglob("*") if p.is_file()]

    old_manifest_dict: dict | None = None
    do_classify = bool(classify)
    if do_classify:
        old_manifest_dict = _load_old_manifest_for_classify(project_root, old_manifest, git_ref)
        if old_manifest_dict is None:
            click.echo(
                "Semantic classification skipped (no --old-manifest file and git show manifest failed).",
                err=True,
            )

    result = run_docs_audit(
        manifest_path=str(manifest_path),
        impact_path=str(impact_path),
        impact_local_path=str(impact_local_path) if impact_local_path.exists() else None,
        docs_root=str(docs_root_path),
        changed_files=changed_files,
        changed_text="",
        strict=strict,
        old_manifest=old_manifest_dict,
        classify_semantics=bool(do_classify and old_manifest_dict is not None),
    )
    json_payload = build_audit_json(result)
    md_payload = build_audit_markdown(result)
    if out_json is not None:
        text = json.dumps(json_payload, indent=2)
        if out_json.strip() == "-":
            click.echo(text)
        else:
            try:
                Path(out_json).write_text(text, encoding="utf-8")
            except OSError as exc:
                click.echo(
                    f"Warning: could not write audit.json to {out_json} ({exc}). "
                    "Use --out-json /tmp/audit.json to specify a writable path.",
                    err=True,
                )
    Path(out_md).write_text(md_payload, encoding="utf-8")
    summary_text = build_summary(result)
    if do_classify and old_manifest_dict is not None and not result.semantic_changes:
        summary_text += "\n\nSemantic analysis:\n  (no differences detected vs old manifest)"
    click.echo(summary_text)
    _maybe_run_map_hook(result, project_root, no_hooks)
    raise SystemExit(result.exit_code)

