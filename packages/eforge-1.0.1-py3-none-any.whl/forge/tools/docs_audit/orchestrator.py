from __future__ import annotations

import logging
import subprocess
import sys
from dataclasses import asdict
from datetime import date
from pathlib import Path
from typing import Any

from forge.core.manifest import ManifestParser
from forge.tools.docs_audit.contracts.models import (
    AuditFailure,
    ChangeRule,
    CheckSpec,
    RequirementFile,
    Severity,
    TriggerSpec,
    TriggeredRule,
    Waiver,
)
from forge.tools.docs_audit.contracts.normalize import normalize_manifest
from forge.tools.docs_audit.engine.policy_eval import evaluate
from forge.tools.docs_audit.engine.results import merge_results
from forge.tools.docs_audit.engine.trigger_eval import evaluate_triggers
from forge.tools.docs_audit.loaders.docs_loader import load_docs_corpus
from forge.tools.docs_audit.loaders.yaml_loader import load_yaml
from forge.tools.docs_audit.output.waiver_warnings import collect_waiver_warnings
from forge.tools.docs_audit.schema.validate import validate_change_impact, validate_manifest


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _to_severity(raw: str) -> Severity:
    raw = (raw or "normal").lower()
    if raw == "blocker":
        return Severity.BLOCKER
    if raw == "high":
        return Severity.HIGH
    if raw in ("warn", "warning"):
        return Severity.WARN
    return Severity.NORMAL


def _prepare_manifest_raw_for_docs_audit(manifest_path: str) -> dict[str, Any]:
    """
    Load manifest.yaml for docs audit. Uses ManifestParser.parse() when possible,
    then ManifestParser._normalise_section for list-based Format B sections and
    legacy dict-keyed Format A (same path as context consumers that rely on
    normalised list[dict] buckets).
    """
    p = Path(manifest_path)
    if not p.is_file():
        return {}
    res = ManifestParser(p).parse()
    if res.ok and isinstance(res.value, dict):
        raw: dict[str, Any] = dict(res.value)
    else:
        data = load_yaml(manifest_path)
        raw = dict(data) if isinstance(data, dict) else {}
    parser = ManifestParser(p)
    sec_warnings: list[str] = []
    for sec in ("screens", "controllers", "hooks", "services", "variants"):
        if sec not in raw:
            continue
        raw[sec] = parser._normalise_section(raw.get(sec), sec, sec_warnings)
    if isinstance(raw.get("app"), dict):
        app = raw["app"]
        for fld in ("name", "version", "type"):
            if fld not in raw and fld in app:
                raw[fld] = app[fld]
    return raw


def _parse_rule(raw: dict[str, Any], source: str) -> ChangeRule:
    waiver = None
    if isinstance(raw.get("waiver"), dict):
        waiver = Waiver(
            reason=str(raw["waiver"].get("reason", "")),
            owner=str(raw["waiver"].get("owner", "")),
            expires_on=str(raw["waiver"].get("expires_on", "")),
        )
    req_files: list[RequirementFile] = []
    requires_raw = raw.get("requires")
    if isinstance(requires_raw, list):
        for item in requires_raw:
            if not isinstance(item, dict):
                continue
            req_files.append(
                RequirementFile(
                    path=str(item.get("path", "")),
                    headings_any=_as_list(
                        item.get("headings_any") or item.get("headings") or item.get("sections")
                    ),
                    keys_all=_as_list(item.get("keys_all")),
                    keys_any=_as_list(item.get("keys_any")),
                )
            )
    else:
        requires = requires_raw if isinstance(requires_raw, dict) else {}
        for rf in requires.get("files", []) or []:
            if not isinstance(rf, dict):
                continue
            req_files.append(
                RequirementFile(
                    path=str(rf.get("path", "")),
                    headings_any=_as_list(rf.get("headings_any") or rf.get("headings")),
                    keys_all=_as_list(rf.get("keys_all")),
                    keys_any=_as_list(rf.get("keys_any")),
                )
            )
    checks = [
        CheckSpec(type=str(c.get("type", "")), params={k: v for k, v in c.items() if k != "type"})
        for c in _as_list(raw.get("checks"))
        if isinstance(c, dict)
    ]
    trig_raw = raw.get("triggers")
    if isinstance(trig_raw, list):
        globs: list[str] = []
        for item in trig_raw:
            if not isinstance(item, dict):
                continue
            g = item.get("glob") or item.get("file_pattern") or item.get("pattern")
            if g:
                globs.append(str(g))
        trig: dict[str, Any] = {
            "match_mode": "any",
            "file_patterns": globs,
            "keywords": [],
            "keyword_trigger_mode": str(raw.get("keyword_trigger_mode", "hint")),
        }
    elif isinstance(trig_raw, dict):
        trig = trig_raw
    else:
        trig = {}
    return ChangeRule(
        id=str(raw.get("id", "")),
        severity=_to_severity(str(raw.get("severity", "normal"))),
        owner=str(raw.get("owner", "docs")),
        autofix=str(raw.get("autofix", "none")),
        scope=[str(x) for x in _as_list(raw.get("scope") or ["docs"])],
        triggers=TriggerSpec(
            match_mode=str(trig.get("match_mode", "any")),
            file_patterns=[str(x) for x in _as_list(trig.get("file_patterns"))],
            manifest_node_patterns=[
                str(x) for x in _as_list(trig.get("manifest_node_patterns"))
            ],
            keywords=[str(x) for x in _as_list(trig.get("keywords"))],
            keyword_trigger_mode=str(trig.get("keyword_trigger_mode", "hint")),
        ),
        requires=req_files,
        checks=checks,
        notes=str(raw.get("notes") or raw.get("description") or ""),
        source=source,
        waiver=waiver,
    )


def _waiver_valid(waiver: Waiver | None) -> bool:
    if waiver is None:
        return False
    if not waiver.reason or not waiver.owner or not waiver.expires_on:
        return False
    try:
        exp = date.fromisoformat(waiver.expires_on)
    except ValueError:
        return False
    return exp >= date.today()


def _merge_rules(core_rules: list[ChangeRule], local_rules: list[ChangeRule]) -> tuple[list[ChangeRule], list[AuditFailure]]:
    merged: dict[str, ChangeRule] = {r.id: r for r in core_rules}
    failures: list[AuditFailure] = []

    for local in local_rules:
        core = merged.get(local.id)
        if core is None:
            merged[local.id] = local
            continue
        # Cannot silently weaken blocker without valid waiver.
        if core.severity == Severity.BLOCKER and local.severity != Severity.BLOCKER:
            if not _waiver_valid(local.waiver):
                failures.append(
                    AuditFailure(
                        rule_id=local.id,
                        severity=Severity.BLOCKER,
                        file="docs/change-impact.local.yaml",
                        message=(
                            "Local override weakens blocker severity without valid waiver metadata "
                            "(reason, owner, expires_on)."
                        ),
                        rule_source="local_override",
                        suggested_updates=["docs/change-impact.local.yaml"],
                    )
                )
                continue
        merged[local.id] = local
    return list(merged.values()), failures


def _project_root_from_manifest_path(manifest_path: str) -> Path:
    p = Path(manifest_path).resolve()
    r = p.parent
    if r.name == "docs":
        r = r.parent
    return r


def changed_files_to_manifest_node_ids(
    changed_files: list[str],
    project_path: Path,
    *,
    manifest_data: dict[str, Any] | None = None,
) -> list[str]:
    """Resolve changed repo-relative paths to manifest graph node ids (declaration graph)."""
    from forge.tools.manifest.graph import build_manifest_graph, find_node_id_for_path

    if not changed_files:
        return []
    try:
        g = (
            build_manifest_graph(project_path, manifest_data=manifest_data)
            if manifest_data
            else build_manifest_graph(project_path)
        )
    except Exception:
        return []
    out: list[str] = []
    for cf in changed_files:
        nid = find_node_id_for_path(g, str(cf).replace("\\", "/"))
        if nid:
            out.append(nid)
    return out


def find_graph_affected_nodes(
    changed_files: list[str],
    project_path: Path,
    *,
    manifest_data: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Map changed files to Ring-2 manifest graph blast radius (grouped by relation).
    When manifest_data is set, build the graph from that dict (same preparation as
    run_docs_audit); otherwise load manifest from disk.
    """
    from forge.tools.manifest.graph import aggregate_ring2_for_files, build_manifest_graph

    empty: dict[str, Any] = {"direct": [], "watchers": [], "dependents": [], "siblings": [], "reason": {}}
    root = Path(project_path).resolve()
    if not changed_files:
        return empty
    try:
        g = (
            build_manifest_graph(root, manifest_data=manifest_data)
            if manifest_data
            else build_manifest_graph(root)
        )
    except Exception:
        return empty
    return aggregate_ring2_for_files(g, changed_files)


def run_docs_audit(
    manifest_path: str,
    impact_path: str,
    impact_local_path: str | None,
    docs_root: str,
    changed_files: list[str],
    changed_text: str = "",
    strict: bool = False,
    *,
    old_manifest: dict[str, Any] | None = None,
    classify_semantics: bool = False,
):
    # DEPRECATED: change-impact.yaml system phased out
    # Use graph-based impact analysis instead
    
    # 1) Schema validation first (fail-fast)
    v_manifest = validate_manifest(manifest_path)
    validation_failures: list[AuditFailure] = []
    if not v_manifest.ok:
        validation_failures.extend(
            [
                AuditFailure(
                    rule_id="schema.manifest",
                    severity=Severity.BLOCKER,
                    file=manifest_path,
                    message=e,
                    rule_source="core",
                    suggested_updates=[manifest_path],
                )
                for e in v_manifest.errors
            ]
        )
    
    # Skip change-impact validation - deprecated system
    # Modern alternatives: forge blast-radius, forge query, forge impact-check
    
    if validation_failures:
        return merge_results(
            triggered_rules=[],
            failures=validation_failures,
            strict=strict,
            waiver_warnings=[],
            semantic_changes=[],
            manifest_resolved_from=None,
            graph_impact=None,
        )

    manifest_raw = _prepare_manifest_raw_for_docs_audit(manifest_path)
    manifest = normalize_manifest(manifest_raw)
    docs_text = load_docs_corpus(docs_root)

    # DEPRECATED: Static rule system replaced by graph analysis
    core_rules: list[ChangeRule] = []
    local_rules: list[ChangeRule] = []
    
    # Note: impact_path and impact_local_path are kept for compatibility
    # but no longer processed for static rules (deprecated system)
    
    # Skip rule merging - deprecated static rule system
    merged_rules = []
    merge_failures = []

    project_root = _project_root_from_manifest_path(manifest_path)
    graph_impact_raw = find_graph_affected_nodes(
        changed_files, project_root, manifest_data=manifest_raw or None
    )
    graph_impact_out: dict[str, Any] = (
        graph_impact_raw
        if any(graph_impact_raw.get(k) for k in ("direct", "watchers", "dependents", "siblings"))
        else {}
    )

    changed_node_ids = changed_files_to_manifest_node_ids(
        changed_files, project_root, manifest_data=manifest_raw or None
    )
    triggered = evaluate_triggers(
        merged_rules,
        changed_files=changed_files,
        changed_text=changed_text,
        changed_node_ids=changed_node_ids,
    )
    waiver_warnings = collect_waiver_warnings(merged_rules, warning_window_days=14)
    resolved_mp = Path(manifest_path).resolve() if Path(manifest_path).is_file() else None
    t, failures, strict_val, mprov = evaluate(
        triggered=triggered,
        manifest=manifest,
        docs_text=docs_text,
        strict=strict,
        resolved_manifest_path=resolved_mp,
    )

    semantic_changes: list[Any] = []
    if classify_semantics and old_manifest is not None:
        kinds = core_data.get("change_kinds") or []
        if isinstance(kinds, list):
            from forge.tools.docs_audit.change_classifier import classify_change

            semantic_changes = classify_change(dict(old_manifest), dict(manifest_raw), list(kinds))

    from forge.tools.docs_audit.impact_engine import compute_impact

    impact = compute_impact(
        changed_files=changed_files,
        project_path=project_root,
        include_ring1=False,
        manifest_data=manifest_raw or None,
    )
    graph_impact_payload = {
        **graph_impact_out,
        "principles_applied": len(impact.principle_results),
        "principle_results": [
            {
                "principle": r.principle,
                "changed_node": r.changed_node,
                "affected_nodes": list(r.affected_nodes),
                "severity": r.severity,
                "reason": r.reason,
                "ring": r.ring,
                "derived": r.derived,
                **(
                    {"metadata": dict(r.metadata)}
                    if getattr(r, "metadata", None)
                    else {}
                ),
            }
            for r in impact.principle_results
        ],
        "affected_nodes": list(impact.combined),
        "summary": dict(impact.graph_summary),
    }

    return merge_results(
        triggered_rules=t,
        failures=failures,
        strict=strict_val,
        waiver_warnings=waiver_warnings,
        semantic_changes=semantic_changes,
        manifest_resolved_from=mprov,
        graph_impact=graph_impact_payload,
    )


def maybe_run_map_hook(result: Any, project_root: Path) -> None:
    """Regenerate map docs when impact-check detects graph-structural changes.

    Fires when ``result.graph_impact["affected_nodes"]`` is non-empty, meaning
    the changed files touch registered manifest nodes — a structural signal that
    ``docs/MAP.md`` and ``.forge/agent_context.json`` may be stale.

    Safe to call from both the CLI path and the MCP handler path.  Errors are
    logged but never propagated; the impact-check ``exit_code`` is always
    authoritative.
    """
    _log = logging.getLogger(__name__)
    graph_impact = getattr(result, "graph_impact", None) or {}
    affected = (graph_impact.get("affected_nodes") or [])
    if not affected:
        return
    _log.info("[post_change_hook] affected_nodes=%d — running forge map", len(affected))
    map_rc = _run_hook_cli(
        [sys.executable, "-m", "forge.cli_main", "map", "--project-path", str(project_root)],
        project_root=project_root,
        hook_name="forge_map",
    )
    if map_rc == 0:
        _log.info("[post_change_hook] forge map complete; running forge verify")
        verify_rc = _run_hook_cli(
            [
                sys.executable,
                "-m",
                "forge.cli_main",
                "verify",
                "--project-path",
                str(project_root),
                "--scope",
                "all",
            ],
            project_root=project_root,
            hook_name="forge_verify",
        )
        _log.info("[post_change_hook] forge verify exit=%d (advisory)", verify_rc)
    else:
        _log.warning("[post_change_hook] forge map failed exit=%d; skipping verify chain", map_rc)

    impact_rc = _run_hook_cli(
        [
            sys.executable,
            "-m",
            "forge.cli_main",
            "impact-check",
            "--project-path",
            str(project_root),
            "--changed-files-source",
            "git",
            "--no-hooks",
            "--response-tier",
            "L1",
        ],
        project_root=project_root,
        hook_name="forge_impact_check",
    )
    _append_impact_scratch(project_root, impact_rc)
    _log.info("[post_change_hook] forge impact-check exit=%d (advisory)", impact_rc)


def _run_hook_cli(command: list[str], *, project_root: Path, hook_name: str) -> int:
    _log = logging.getLogger(__name__)
    try:
        proc = subprocess.run(
            command,
            capture_output=True,
            text=True,
            cwd=str(project_root),
            check=False,
        )
        if proc.returncode != 0:
            _log.warning(
                "[post_change_hook] %s exit=%d stderr=%s",
                hook_name,
                proc.returncode,
                (proc.stderr or "").strip(),
            )
        return int(proc.returncode)
    except Exception as exc:  # noqa: BLE001
        _log.warning("[post_change_hook] %s skipped: %s", hook_name, exc)
        return 1


def _append_impact_scratch(project_root: Path, impact_exit_code: int) -> None:
    from datetime import datetime

    _log = logging.getLogger(__name__)
    scratch = project_root / ".forge" / "cowork" / "scratch.md"
    scratch.parent.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    line = f"- [{stamp}] impact-check exit={impact_exit_code}\n"
    try:
        if scratch.exists():
            content = scratch.read_text(encoding="utf-8")
        else:
            content = "# Scratch\n\n## Impact\n"
        if "## Impact" not in content:
            content = content.rstrip() + "\n\n## Impact\n"
        content = content.replace("## Impact", f"## Impact\n{line}", 1)
        scratch.write_text(content, encoding="utf-8")
    except Exception as exc:  # noqa: BLE001
        _log.warning("[post_change_hook] scratch impact append skipped: %s", exc)


def debug_rule_dump(impact_path: str) -> list[dict[str, Any]]:
    data = load_yaml(impact_path)
    return [asdict(_parse_rule(r, "core")) for r in data.get("change_types", [])]

