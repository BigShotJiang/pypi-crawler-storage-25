"""tests for docs_audit subtool"""

