from __future__ import annotations

from pathlib import Path

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from forge.tools.docs_audit.api_router import impact_router


FIX = Path(__file__).parent / "fixtures"


def _app() -> FastAPI:
    app = FastAPI()
    app.include_router(impact_router)
    return app


def test_impact_evaluate_pass_fixture() -> None:
    client = TestClient(_app())
    project_path = str(FIX / "passing_repo")
    resp = client.post(
        "/api/impact/evaluate",
        json={
            "project_path": project_path,
            "changed_files": [],
            "strict": False,
        },
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["exit_code"] == 0
    assert data["status"] == "pass"
    assert data["failures"] == []
    assert isinstance(data["triggered_rules"], list)
    assert "pass_count" in data and "warn_count" in data and "blocker_count" in data
    assert "rule_sources" in data


@pytest.mark.skip(
    reason="change-impact.yaml system deprecated "
    "in orchestrator.py — tests preserved "
    "for reference only"
)
def test_impact_evaluate_failing_fixture() -> None:
    client = TestClient(_app())
    project_path = str(FIX / "failing_repo_missing_docs")
    resp = client.post(
        "/api/impact/evaluate",
        json={
            "project_path": project_path,
            "changed_files": ["docs/ARCHITECTURE.md"],
            "strict": False,
        },
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["exit_code"] == 2
    assert data["status"] == "fail"
    assert len(data["failures"]) > 0
    assert len(data["triggered_rules"]) >= 1

