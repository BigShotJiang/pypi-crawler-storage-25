import json
from pathlib import Path

import pytest

from forge.tools.docs_audit.orchestrator import run_docs_audit
from forge.tools.docs_audit.output.to_json import build_audit_json
from forge.tools.docs_audit.output.to_markdown import build_audit_markdown


FIX = Path(__file__).parent / "fixtures"


@pytest.mark.skip(
    reason="change-impact.yaml system deprecated "
    "in orchestrator.py — tests preserved "
    "for reference only"
)
def test_local_override_weakening_blocker_requires_waiver_and_reports_provenance() -> None:
    base = FIX / "local_override_weakening_blocker" / "docs"
    result = run_docs_audit(
        manifest_path=str(base / "manifest.yaml"),
        impact_path=str(base / "change-impact.yaml"),
        impact_local_path=str(base / "change-impact.local.yaml"),
        docs_root=str(base),
        changed_files=["docs/MAP.md"],
    )
    payload = build_audit_json(result)
    assert result.exit_code == 2
    assert payload["failures"][0]["rule_source"] == "local_override"


def test_output_format_contains_required_keys() -> None:
    base = FIX / "passing_repo" / "docs"
    result = run_docs_audit(
        manifest_path=str(base / "manifest.yaml"),
        impact_path=str(base / "change-impact.yaml"),
        impact_local_path=None,
        docs_root=str(base),
        changed_files=["docs/MAP.md"],
    )
    j = build_audit_json(result)
    md = build_audit_markdown(result)
    assert {"schema_version", "triggered_change_types", "failures", "exit_code"}.issubset(j.keys())
    assert "Docs Audit Report" in md
    assert json.dumps(j)

