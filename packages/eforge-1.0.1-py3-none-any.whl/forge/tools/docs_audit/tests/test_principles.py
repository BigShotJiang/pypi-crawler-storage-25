from __future__ import annotations

from pathlib import Path

from forge.tools.docs_audit.principles import (
    principle_domain_change,
    principle_interface_change,
    principle_reads_change,
)
from forge.tools.manifest.graph import build_manifest_graph


def _graph():
    m = {
        "screens": [
            {"name": "HomeScreen", "file": "lib/home_screen.dart", "domain": "CORE", "watches": ["HomeController"]},
            {
                "name": "DashboardScreen",
                "file": "lib/dashboard_screen.dart",
                "domain": "CORE",
                "watches": ["HomeController"],
            },
        ],
        "controllers": [
            {"name": "HomeController", "file": "lib/home_controller.dart", "domain": "CORE", "reads": ["HomeService"]},
        ],
        "services": [{"name": "HomeService", "file": "lib/home_service.dart", "domain": "CORE"}],
    }
    return build_manifest_graph(Path("."), manifest_data=m)


def test_interface_change_finds_watchers() -> None:
    g = _graph()
    r = principle_interface_change("controller/homecontroller", g)
    assert r is not None
    assert sorted(r.affected_nodes) == ["DashboardScreen", "HomeScreen"]


def test_reads_change_finds_consumers() -> None:
    g = _graph()
    r = principle_reads_change("service/homeservice", g)
    assert r is not None
    assert r.affected_nodes == ["HomeController"]


def test_domain_change_finds_members() -> None:
    g = _graph()
    r = principle_domain_change("controller/homecontroller", g)
    assert r is not None
    assert "HomeScreen" in r.affected_nodes


def test_no_result_when_no_watchers() -> None:
    m = {
        "controllers": [{"name": "C", "file": "lib/c.dart", "domain": "CORE"}],
        "screens": [],
        "services": [],
    }
    g = build_manifest_graph(Path("."), manifest_data=m)
    assert principle_interface_change("controller/c", g) is None


def test_severity_correct_per_principle() -> None:
    g = _graph()
    assert principle_interface_change("controller/homecontroller", g).severity == "high"  # type: ignore[union-attr]
    assert principle_reads_change("service/homeservice", g).severity == "blocker"  # type: ignore[union-attr]
    assert principle_domain_change("controller/homecontroller", g).severity == "high"  # type: ignore[union-attr]


def test_derived_flag_always_true() -> None:
    g = _graph()
    for r in (
        principle_interface_change("controller/homecontroller", g),
        principle_reads_change("service/homeservice", g),
        principle_domain_change("controller/homecontroller", g),
    ):
        assert r is not None
        assert r.derived is True
