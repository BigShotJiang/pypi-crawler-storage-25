from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from forge.tools.docs_audit.impact_engine import compute_impact


def _write_project(tmp_path: Path, *, overrides: dict | None = None) -> None:
    (tmp_path / "docs").mkdir(parents=True, exist_ok=True)
    manifest = {
        "screens": [
            {"name": "HomeScreen", "file": "lib/home_screen.dart", "domain": "CORE", "watches": ["HomeController"]},
            {"name": "DashboardScreen", "file": "lib/dashboard_screen.dart", "domain": "CORE", "watches": ["HomeController"]},
        ],
        "controllers": [
            {"name": "HomeController", "file": "lib/home_controller.dart", "domain": "CORE", "reads": ["HomeService"]}
        ],
        "services": [{"name": "HomeService", "file": "lib/home_service.dart", "domain": "CORE"}],
    }
    (tmp_path / "manifest.yaml").write_text(yaml.safe_dump(manifest), encoding="utf-8")
    base_ci = {"schema_version": 1, "change_types": []}
    if overrides:
        base_ci["principle_overrides"] = overrides
    (tmp_path / "docs" / "change-impact.yaml").write_text(yaml.safe_dump(base_ci), encoding="utf-8")


def test_compute_impact_returns_result(tmp_path: Path) -> None:
    _write_project(tmp_path)
    r = compute_impact(["lib/home_controller.dart"], tmp_path, include_ring1=False)
    assert r.changed_files == ["lib/home_controller.dart"]
    assert isinstance(r.combined, list)


@pytest.mark.skip(
    reason="change-impact.yaml system deprecated "
    "in orchestrator.py — tests preserved "
    "for reference only"
)
def test_rules_can_override_principle_severity(tmp_path: Path) -> None:
    _write_project(tmp_path, overrides={"escalate_severity": {"INTERFACE_CHANGE_AFFECTS_WATCHERS": "blocker"}})
    r = compute_impact(["lib/home_controller.dart"], tmp_path, include_ring1=False)
    row = next(x for x in r.combined if x["principle"] == "INTERFACE_CHANGE_AFFECTS_WATCHERS")
    assert row["severity"] == "blocker"


@pytest.mark.skip(
    reason="change-impact.yaml system deprecated "
    "in orchestrator.py — tests preserved "
    "for reference only"
)
def test_rules_can_suppress_principle(tmp_path: Path) -> None:
    _write_project(tmp_path, overrides={"suppress": ["INTERFACE_CHANGE_AFFECTS_WATCHERS"]})
    r = compute_impact(["lib/home_controller.dart"], tmp_path, include_ring1=False)
    assert all(x["principle"] != "INTERFACE_CHANGE_AFFECTS_WATCHERS" for x in r.combined)


def test_combined_deduplicates_affected_nodes(tmp_path: Path) -> None:
    _write_project(tmp_path)
    r = compute_impact(["lib/home_controller.dart"], tmp_path, include_ring1=False)
    nodes = [x["node"] for x in r.combined if x["principle"] == "INTERFACE_CHANGE_AFFECTS_WATCHERS"]
    assert len(nodes) == len(set(nodes))


def test_ring2_only_when_ring1_disabled(tmp_path: Path) -> None:
    _write_project(tmp_path)
    r = compute_impact(["lib/home_controller.dart"], tmp_path, include_ring1=False)
    assert all(p.ring == 2 for p in r.principle_results)


def test_graph_summary_human_readable(tmp_path: Path) -> None:
    _write_project(tmp_path)
    r = compute_impact(["lib/home_controller.dart"], tmp_path, include_ring1=False)
    assert "principles_applied" in r.graph_summary
    assert "affected_nodes" in r.graph_summary
