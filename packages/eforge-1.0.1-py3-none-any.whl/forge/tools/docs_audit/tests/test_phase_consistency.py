from pathlib import Path

from forge.tools.docs_audit.checks.registry import run_check
from forge.tools.docs_audit.loaders.docs_loader import load_docs_corpus


FIX = Path(__file__).parent / "fixtures"


def _run(name: str):
    base = FIX / name / "docs"
    docs = load_docs_corpus(str(base))
    return run_check({"type": "phase_consistency"}, {}, docs)


def test_phase_passing() -> None:
    failures = _run("phase_passing")
    assert failures == []


def test_phase_mismatch_blocker() -> None:
    failures = _run("phase_mismatch")
    assert any(f.severity.value == "blocker" for f in failures)


def test_phase_missing_marker_warning() -> None:
    failures = _run("phase_missing_marker")
    assert any(f.severity.value == "normal" for f in failures)


def test_phase_no_agent_context_passes() -> None:
    failures = _run("phase_no_agent_context")
    assert failures == []


def test_agent_context_resolves_from_archive_when_canonical_missing() -> None:
    docs = {
        "docs/TODO.md": "Phase 2 current",
        "docs/MAP.md": "Phase 2 ← current",
        "docs/archive/AGENT_CONTEXT.md": "Phase 2 active",
    }
    failures = run_check({"type": "phase_consistency"}, {}, docs)
    assert failures == []


def test_manifest_current_phase_enforced_against_docs() -> None:
    docs = {"docs/TODO.md": "Phase 2 ← current"}
    manifest = {"phases": {"current": 3}}
    failures = run_check(
        {"type": "phase_consistency", "files": ["docs/TODO.md"]},
        manifest,
        docs,
    )
    assert any("manifest phases.current=3" in f.message for f in failures)


def test_manifest_phase_aligned_with_doc_passes() -> None:
    docs = {"docs/TODO.md": "Phase 2 ← current"}
    manifest = {"phases": {"current": 2}}
    failures = run_check(
        {"type": "phase_consistency", "files": ["docs/TODO.md"]},
        manifest,
        docs,
    )
    assert failures == []

