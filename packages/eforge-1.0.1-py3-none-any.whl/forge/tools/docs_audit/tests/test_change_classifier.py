from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml

from forge.tools.docs_audit.change_classifier import (
    SemanticChange,
    classify_change,
    traverse_manifest_graph,
)

REPO_ROOT = Path(__file__).resolve().parents[4]

KINDS_MIN = [
    {
        "id": "interface_contract_change",
        "description": "iface",
        "triggers": {"manifest_field_patterns": ["controllers.*.reads"]},
        "traverse": ["watchers", "dependents"],
        "severity": "blocker",
        "requires_adr": False,
    },
    {
        "id": "domain_reassignment",
        "description": "dom",
        "triggers": {"manifest_field_patterns": ["controllers.*.domain"]},
        "traverse": ["error_codes", "watchers"],
        "severity": "blocker",
        "requires_adr": False,
    },
    {
        "id": "architecture_change",
        "description": "arch",
        "triggers": {"manual": True},
        "traverse": ["all_affected_layers"],
        "severity": "blocker",
        "requires_adr": True,
    },
    {
        "id": "component_swap",
        "description": "comp",
        "triggers": {"manifest_field_patterns": ["screens.*.variant"]},
        "traverse": ["screen_consumers"],
        "severity": "warn",
        "requires_adr": False,
    },
]


def test_classify_reads_change_detected() -> None:
    old = {"controllers": [{"name": "Home", "domain": "CORE", "reads": ["a"]}]}
    new = {"controllers": [{"name": "Home", "domain": "CORE", "reads": ["a", "b"]}]}
    out = classify_change(old, new, KINDS_MIN)
    assert any(x.kind == "interface_contract_change" for x in out)


def test_classify_domain_change_detected() -> None:
    old = {"controllers": [{"name": "Home", "domain": "CORE", "reads": []}]}
    new = {"controllers": [{"name": "Home", "domain": "AUTH", "reads": []}]}
    out = classify_change(old, new, KINDS_MIN)
    assert any(x.kind == "domain_reassignment" for x in out)


def test_classify_fires_change_detected() -> None:
    kinds = list(KINDS_MIN)
    old = {"controllers": [{"name": "Home", "domain": "CORE", "fires": ["x"]}]}
    new = {"controllers": [{"name": "Home", "domain": "CORE", "fires": ["x", "y"]}]}
    out = classify_change(old, new, kinds)
    assert any(x.kind == "interface_contract_change" for x in out)


def test_classify_no_change_returns_empty() -> None:
    m = {"controllers": [{"name": "Home", "domain": "CORE", "reads": ["a"]}]}
    assert classify_change(m, m, KINDS_MIN) == []


def test_classify_requires_adr_for_arch_change() -> None:
    kinds = list(KINDS_MIN)
    old = {"controllers": [], "phases": [{"id": 1}]}
    new = {"controllers": [], "phases": [{"id": 1}, {"id": 2}]}
    out = classify_change(old, new, kinds)
    arch = [x for x in out if x.kind == "architecture_change"]
    assert len(arch) == 1
    assert arch[0].requires_adr is True


def test_traverse_watchers_finds_screens() -> None:
    m = {
        "controllers": [{"name": "HomeController", "domain": "CORE"}],
        "screens": [{"name": "Dash", "watches": ["HomeController.refresh"]}],
    }
    got = traverse_manifest_graph(m, "controllers.HomeController.interface", ["watchers"])
    assert "Dash" in got


def test_traverse_dependents_finds_controllers() -> None:
    m = {
        "controllers": [
            {"name": "HomeController", "domain": "CORE", "reads": []},
            {"name": "Other", "domain": "CORE", "reads": ["HomeController.score"]},
        ],
    }
    got = traverse_manifest_graph(m, "controllers.HomeController", ["dependents"])
    assert "Other" in got


def test_classify_never_raises() -> None:
    out = classify_change({}, None, "bad")  # type: ignore[arg-type]
    assert out == []


@pytest.mark.skip(
    reason="change-impact.yaml system deprecated "
    "in orchestrator.py — tests preserved "
    "for reference only"
)
def test_change_kinds_schema_validates() -> None:
    jsonschema = pytest.importorskip("jsonschema")
    schema_path = Path(__file__).resolve().parents[1] / "schema" / "change-impact.schema.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    doc_path = REPO_ROOT / "docs" / "change-impact.yaml"
    instance = yaml.safe_load(doc_path.read_text(encoding="utf-8"))
    jsonschema.validate(instance=instance, schema=schema)


def test_build_summary_includes_semantic_block() -> None:
    from forge.tools.docs_audit.contracts.models import AuditResult
    from forge.tools.docs_audit.output.summary import build_summary

    sc = SemanticChange(
        kind="interface_contract_change",
        changed_node="controllers.Home",
        old_value={"reads": []},
        new_value={"reads": ["x"]},
        affected=["S1"],
        requires_adr=False,
        severity="blocker",
    )
    r = AuditResult(
        triggered_rules=[],
        failures=[],
        waiver_warnings=[],
        strict=False,
        semantic_changes=[sc],
    )
    text = build_summary(r)
    assert "Semantic analysis:" in text
    assert "interface_contract_change" in text
