from __future__ import annotations

from types import SimpleNamespace
from pathlib import Path

from forge.tools.docs_audit import orchestrator


def test_post_change_hook_chain_order(monkeypatch, tmp_path: Path) -> None:  # type: ignore[no-untyped-def]
    (tmp_path / ".forge").mkdir(parents=True, exist_ok=True)
    calls: list[list[str]] = []

    class _Proc:
        def __init__(self, code: int = 0) -> None:
            self.returncode = code
            self.stdout = ""
            self.stderr = ""

    def _fake_run(cmd, capture_output, text, cwd, check):  # type: ignore[no-untyped-def]
        calls.append(list(cmd))
        return _Proc(0)

    monkeypatch.setattr(orchestrator.subprocess, "run", _fake_run)
    result = SimpleNamespace(graph_impact={"affected_nodes": ["module/a"]})
    orchestrator.maybe_run_map_hook(result, tmp_path)

    assert len(calls) == 3
    assert calls[0][3] == "map"
    assert calls[1][3] == "verify"
    assert calls[2][3] == "impact-check"
    scratch = tmp_path / ".forge" / "cowork" / "scratch.md"
    assert scratch.is_file()
    text = scratch.read_text(encoding="utf-8")
    assert "## Impact" in text
    assert "impact-check exit=0" in text


def test_post_change_hook_skips_verify_when_map_fails(monkeypatch, tmp_path: Path) -> None:  # type: ignore[no-untyped-def]
    (tmp_path / ".forge").mkdir(parents=True, exist_ok=True)
    calls: list[list[str]] = []

    class _Proc:
        def __init__(self, code: int) -> None:
            self.returncode = code
            self.stdout = ""
            self.stderr = "err"

    def _fake_run(cmd, capture_output, text, cwd, check):  # type: ignore[no-untyped-def]
        calls.append(list(cmd))
        sub = cmd[3]
        if sub == "map":
            return _Proc(2)
        return _Proc(1 if sub == "impact-check" else 0)

    monkeypatch.setattr(orchestrator.subprocess, "run", _fake_run)
    result = SimpleNamespace(graph_impact={"affected_nodes": ["module/a"]})
    orchestrator.maybe_run_map_hook(result, tmp_path)

    assert len(calls) == 2
    assert calls[0][3] == "map"
    assert calls[1][3] == "impact-check"
    assert all(c[3] != "verify" for c in calls)

