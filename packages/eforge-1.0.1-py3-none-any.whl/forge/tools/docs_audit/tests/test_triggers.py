from forge.tools.docs_audit.contracts.models import ChangeRule, RequirementFile, Severity, TriggerSpec
from forge.tools.docs_audit.engine.trigger_eval import evaluate_triggers


def _rule(keyword_mode: str = "hint") -> ChangeRule:
    return ChangeRule(
        id="r1",
        severity=Severity.NORMAL,
        owner="docs",
        autofix="none",
        scope=["docs"],
        triggers=TriggerSpec(
            match_mode="any",
            file_patterns=["docs/**"],
            keywords=["error"],
            keyword_trigger_mode=keyword_mode,
        ),
        requires=[RequirementFile(path="docs/MAP.md")],
        checks=[],
    )


def test_keyword_does_not_authoritatively_trigger_when_hint_mode() -> None:
    trs = evaluate_triggers([_rule("hint")], changed_files=["src/app.ts"], changed_text="error")
    assert len(trs) == 0


def test_file_pattern_is_primary_trigger() -> None:
    trs = evaluate_triggers([_rule("hint")], changed_files=["docs/MAP.md"], changed_text="")
    assert len(trs) == 1


def test_manifest_node_pattern_triggers_without_file_match() -> None:
    rule = ChangeRule(
        id="by_node",
        severity=Severity.NORMAL,
        owner="docs",
        autofix="none",
        scope=["docs"],
        triggers=TriggerSpec(
            match_mode="any",
            manifest_node_patterns=["module/foo.*"],
        ),
        requires=[RequirementFile(path="docs/X.md")],
        checks=[],
    )
    trs = evaluate_triggers(
        [rule],
        changed_files=["unrelated/path.txt"],
        changed_text="",
        changed_node_ids=["module/foo.bar"],
    )
    assert len(trs) == 1
    assert "manifest_node_match" in trs[0].reasons


def test_manifest_node_and_file_all_mode_requires_both() -> None:
    rule = ChangeRule(
        id="both",
        severity=Severity.NORMAL,
        owner="docs",
        autofix="none",
        scope=["docs"],
        triggers=TriggerSpec(
            match_mode="all",
            file_patterns=["docs/*.md"],
            manifest_node_patterns=["screen/*"],
        ),
        requires=[RequirementFile(path="docs/MAP.md")],
        checks=[],
    )
    only_file = evaluate_triggers(
        [rule],
        changed_files=["docs/MAP.md"],
        changed_text="",
        changed_node_ids=[],
    )
    assert len(only_file) == 0
    both = evaluate_triggers(
        [rule],
        changed_files=["docs/MAP.md"],
        changed_text="",
        changed_node_ids=["screen/home"],
    )
    assert len(both) == 1

