from pathlib import Path

import pytest

from forge.tools.docs_audit.orchestrator import run_docs_audit


FIX = Path(__file__).parent / "fixtures"


def test_exit_code_pass() -> None:
    base = FIX / "passing_repo" / "docs"
    result = run_docs_audit(
        manifest_path=str(base / "manifest.yaml"),
        impact_path=str(base / "change-impact.yaml"),
        impact_local_path=None,
        docs_root=str(base),
        # Outside docs/** — no change_types trigger → exit 0.
        changed_files=["pyproject.toml"],
    )
    assert result.exit_code == 0


@pytest.mark.skip(
    reason="change-impact.yaml system deprecated "
    "in orchestrator.py — tests preserved "
    "for reference only"
)
def test_exit_code_advisory_when_triggered_no_failures() -> None:
    base = FIX / "passing_repo" / "docs"
    result = run_docs_audit(
        manifest_path=str(base / "manifest.yaml"),
        impact_path=str(base / "change-impact.yaml"),
        impact_local_path=None,
        docs_root=str(base),
        changed_files=["docs/ERROR_CODES.md"],
    )
    assert result.triggered_rules
    assert result.exit_code == 1


@pytest.mark.skip(
    reason="change-impact.yaml system deprecated "
    "in orchestrator.py — tests preserved "
    "for reference only"
)
def test_exit_code_blocker() -> None:
    base = FIX / "failing_repo_missing_docs" / "docs"
    result = run_docs_audit(
        manifest_path=str(base / "manifest.yaml"),
        impact_path=str(base / "change-impact.yaml"),
        impact_local_path=None,
        docs_root=str(base),
        changed_files=["docs/MAP.md"],
    )
    assert result.exit_code == 2

