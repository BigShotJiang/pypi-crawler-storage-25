"""Policy evaluation: manifest.yaml required-file satisfaction + drift warning."""

from __future__ import annotations

from pathlib import Path

from forge.tools.docs_audit.contracts.models import (
    ChangeRule,
    RequirementFile,
    Severity,
    TriggerSpec,
    TriggeredRule,
)
from forge.tools.docs_audit.engine.policy_eval import evaluate


def _manifest_only_rule() -> TriggeredRule:
    rule = ChangeRule(
        id="manifest-required-test",
        severity=Severity.BLOCKER,
        owner="docs",
        autofix="none",
        scope=["docs"],
        triggers=TriggerSpec(),
        requires=[RequirementFile(path="manifest.yaml")],
        checks=[],
    )
    return TriggeredRule(rule=rule, reasons=["test"])


def test_manifest_required_satisfied_by_root(tmp_path: Path) -> None:
    root_m = tmp_path / "manifest.yaml"
    root_m.write_text("schema_version: 1\nname: t\n", encoding="utf-8")
    triggered = [_manifest_only_rule()]
    _, failures, _, prov = evaluate(
        triggered=triggered,
        manifest={"schema_version": 1, "name": "t"},
        docs_text={},
        resolved_manifest_path=root_m.resolve(),
    )
    assert prov == "root"
    assert not any("Required file missing" in f.message for f in failures)


def test_manifest_required_satisfied_by_docs(tmp_path: Path) -> None:
    docs_m = tmp_path / "docs" / "manifest.yaml"
    docs_m.parent.mkdir(parents=True)
    docs_m.write_text("schema_version: 1\nname: t\n", encoding="utf-8")
    triggered = [_manifest_only_rule()]
    _, failures, _, prov = evaluate(
        triggered=triggered,
        manifest={"schema_version": 1, "name": "t"},
        docs_text={},
        resolved_manifest_path=docs_m.resolve(),
    )
    assert prov == "docs"
    assert not any("Required file missing" in f.message for f in failures)


def test_manifest_drift_emits_warn_not_blocker(tmp_path: Path) -> None:
    root_m = tmp_path / "manifest.yaml"
    docs_m = tmp_path / "docs" / "manifest.yaml"
    docs_m.parent.mkdir(parents=True)
    root_m.write_text("a: 1\n", encoding="utf-8")
    docs_m.write_text("a: 2\n", encoding="utf-8")
    _, failures, _, _ = evaluate(
        triggered=[],
        manifest={},
        docs_text={},
        resolved_manifest_path=root_m.resolve(),
    )
    drift = [f for f in failures if f.rule_id == "MANIFEST_DRIFT"]
    assert len(drift) == 1
    assert drift[0].severity == Severity.WARN


def test_manifest_neither_exists_still_blocker(tmp_path: Path) -> None:
    triggered = [_manifest_only_rule()]
    _, failures, _, prov = evaluate(
        triggered=triggered,
        manifest={},
        docs_text={},
        resolved_manifest_path=None,
    )
    assert prov is None
    assert any("Required file missing: manifest.yaml" in f.message for f in failures)
