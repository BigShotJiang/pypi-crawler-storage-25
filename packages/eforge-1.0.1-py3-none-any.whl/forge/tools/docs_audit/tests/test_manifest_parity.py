from pathlib import Path

from forge.tools.docs_audit.checks.registry import run_check
from forge.tools.docs_audit.contracts.normalize import normalize_manifest
from forge.tools.docs_audit.loaders.docs_loader import load_docs_corpus
from forge.tools.docs_audit.loaders.yaml_loader import load_yaml


FIX = Path(__file__).parent / "fixtures"


def _run(name: str):
    base = FIX / name / "docs"
    manifest = normalize_manifest(load_yaml(base / "manifest.yaml"))
    docs = load_docs_corpus(str(base))
    return run_check({"type": "manifest_doc_parity", "manifest_doc_file": "docs/MANIFEST.md"}, manifest, docs)


def test_parity_passing() -> None:
    failures = _run("parity_passing")
    assert failures == []


def test_parity_missing_screen_blocker() -> None:
    failures = _run("parity_missing_screen")
    assert any(f.severity.value == "blocker" and "Missing screen" in f.message for f in failures)


def test_parity_stale_entry_warning() -> None:
    failures = _run("parity_stale_entry")
    assert any(f.severity.value == "normal" and "Stale" in f.message for f in failures)


def test_parity_slug_match() -> None:
    failures = _run("parity_slug_match")
    assert failures == []

