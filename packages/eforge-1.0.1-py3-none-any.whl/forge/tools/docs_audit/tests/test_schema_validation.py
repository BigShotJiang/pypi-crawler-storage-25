from pathlib import Path
from textwrap import dedent

import pytest

from forge.tools.docs_audit.contracts.models import AuditFailure, AuditResult, Severity
from forge.tools.docs_audit.output.summary import build_summary
from forge.tools.docs_audit.schema.validate import validate_change_impact, validate_manifest


FIX = Path(__file__).parent / "fixtures"


def test_schema_validation_passes_on_valid_fixture() -> None:
    base = FIX / "passing_repo" / "docs"
    assert validate_change_impact(str(base / "change-impact.yaml")).ok
    assert validate_manifest(str(base / "manifest.yaml")).ok


def test_schema_validation_fails_on_invalid_fixture() -> None:
    base = FIX / "invalid_schema_case" / "docs"
    assert not validate_change_impact(str(base / "change-impact.yaml")).ok
    assert not validate_manifest(str(base / "manifest.yaml")).ok


def test_manifest_schema_accepts_app_block(tmp_path: Path) -> None:
    p = tmp_path / "manifest.yaml"
    p.write_text(
        dedent(
            """
            app:
              name: Scaffolded
              version: "1.0.0"
              type: flutter
            """
        ).strip(),
        encoding="utf-8",
    )
    r = validate_manifest(str(p))
    assert r.ok, r.errors


def test_manifest_schema_accepts_toplevel() -> None:
    base = FIX / "passing_repo" / "docs"
    r = validate_manifest(str(base / "manifest.yaml"))
    assert r.ok, r.errors


def test_manifest_schema_fails_neither_shape(tmp_path: Path) -> None:
    p = tmp_path / "manifest.yaml"
    p.write_text("orphan_only: true\n", encoding="utf-8")
    r = validate_manifest(str(p))
    assert not r.ok


def test_change_impact_checks_optional(tmp_path: Path) -> None:
    p = tmp_path / "change-impact.yaml"
    p.write_text(
        dedent(
            """
            schema_version: 1
            version: 1
            name: policy
            change_types:
              - id: docs_only
                severity: normal
                triggers:
                  file_patterns: ["docs/**"]
                  match_mode: any
                requires:
                  files:
                    - path: docs/MAP.md
            """
        ).strip(),
        encoding="utf-8",
    )
    r = validate_change_impact(str(p))
    assert r.ok, r.errors


def test_change_impact_empty_checks_ok(tmp_path: Path) -> None:
    p = tmp_path / "change-impact.yaml"
    p.write_text(
        dedent(
            """
            schema_version: 1
            version: 1
            name: policy
            change_types:
              - id: with_empty_checks
                severity: normal
                triggers:
                  file_patterns: ["docs/**"]
                  match_mode: any
                requires:
                  files:
                    - path: docs/MAP.md
                checks: []
            """
        ).strip(),
        encoding="utf-8",
    )
    r = validate_change_impact(str(p))
    assert r.ok, r.errors


def test_schema_vs_triggered_summary() -> None:
    schema_fail = AuditFailure(
        rule_id="schema.manifest",
        severity=Severity.BLOCKER,
        file="docs/manifest.yaml",
        message="missing",
        rule_source="core",
    )
    r = AuditResult(
        triggered_rules=[], failures=[schema_fail], waiver_warnings=[], strict=False, semantic_changes=[]
    )
    s = build_summary(r)
    assert "Schema errors: 1" in s
    assert "Triggered failures: 0" in s
    assert "All failures are schema validation errors" in s

    mixed = AuditResult(
        triggered_rules=[],
        failures=[
            schema_fail,
            AuditFailure(
                rule_id="domain_alignment",
                severity=Severity.BLOCKER,
                file="docs/X.md",
                message="m",
                rule_source="core",
            ),
        ],
        waiver_warnings=[],
        strict=False,
        semantic_changes=[],
    )
    s2 = build_summary(mixed)
    assert "Schema errors: 1" in s2
    assert "Triggered failures: 1" in s2
    assert "All failures are schema validation errors" not in s2


@pytest.mark.parametrize("runner_cwd", ["project", "elsewhere"])
def test_audit_json_no_write_by_default(tmp_path: Path, runner_cwd: str, monkeypatch: pytest.MonkeyPatch) -> None:
    from shutil import copytree

    from click.testing import CliRunner

    from forge.cli import main

    src = FIX / "passing_repo"
    proj = tmp_path / "proj"
    copytree(src, proj)
    other = tmp_path / "other"
    other.mkdir()
    cwd = proj if runner_cwd == "project" else other
    monkeypatch.chdir(cwd)
    runner = CliRunner()
    result = runner.invoke(main, ["impact-check", "--project-path", str(proj)])
    assert result.exit_code == 0, result.output
    assert not (cwd / "audit.json").exists()

