from forge.tools.docs_audit.checks.registry import run_check


def test_registry_dispatch_heading_exists() -> None:
    docs = {"docs/MAP.md": "# T\n\n## Route Map\n"}
    failures = run_check({"type": "heading_exists", "file": "docs/MAP.md", "headings": ["## Route Map"]}, {}, docs)
    assert failures == []


def test_registry_dispatch_required_docs_present_failure() -> None:
    docs = {"docs/MAP.md": "x"}
    failures = run_check({"type": "required_docs_present", "files": ["docs/MAP.md", "docs/TODO.md"]}, {}, docs)
    assert failures
    assert "Missing required docs" in failures[0].message

