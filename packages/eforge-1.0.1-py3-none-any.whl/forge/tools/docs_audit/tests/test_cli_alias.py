from click.testing import CliRunner

from forge.cli import main


def test_impact_check_alias_exists() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["impact-check", "--help"])
    assert result.exit_code == 0
    assert "Usage:" in result.output

