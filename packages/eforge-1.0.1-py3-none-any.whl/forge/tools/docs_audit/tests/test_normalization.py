from pathlib import Path

from forge.tools.docs_audit.contracts.normalize import normalize_manifest
from forge.tools.docs_audit.loaders.yaml_loader import load_yaml


def test_normalization_maps_controllers_to_hooks() -> None:
    path = Path(__file__).parent / "fixtures" / "hooks_vs_controllers_alias" / "docs" / "manifest.yaml"
    manifest = normalize_manifest(load_yaml(path))
    assert "hooks" in manifest
    assert len(manifest["hooks"]) == 1
    assert manifest["hooks"][0]["name"] == "useJobs"

