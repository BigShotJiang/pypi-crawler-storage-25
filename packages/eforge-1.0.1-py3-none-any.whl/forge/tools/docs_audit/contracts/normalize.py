from __future__ import annotations

from typing import Any


def _map_or_list_to_list(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        return [v for v in value if isinstance(v, dict)]
    if isinstance(value, dict):
        out: list[dict[str, Any]] = []
        for name, item in value.items():
            if isinstance(item, dict):
                row = dict(item)
                row.setdefault("name", str(name))
                out.append(row)
        return out
    return []


def normalize_manifest(manifest: dict[str, Any]) -> dict[str, Any]:
    """Single source of normalization for all checks/evaluation."""
    m = dict(manifest or {})
    if "hooks" not in m and "controllers" in m:
        m["hooks"] = m["controllers"]
    if "controllers" not in m and "hooks" in m:
        m["controllers"] = m["hooks"]

    m["screens"] = _map_or_list_to_list(m.get("screens"))
    m["hooks"] = _map_or_list_to_list(m.get("hooks"))
    m["controllers"] = _map_or_list_to_list(m.get("controllers"))
    m["services"] = _map_or_list_to_list(m.get("services"))

    for bucket in ("hooks", "controllers", "services", "screens"):
        for row in m[bucket]:
            if "domain" in row and isinstance(row["domain"], str):
                row["domain"] = row["domain"].upper()
            if bucket in ("hooks", "controllers"):
                ec = row.get("error_codes", [])
                if isinstance(ec, list):
                    row["error_codes"] = ec
                elif ec:
                    row["error_codes"] = [ec]
                else:
                    row["error_codes"] = []

    # Format B Python manifests: modules: list-based, domain inferred from name prefix.
    # e.g. "core.manifest" → domain "CORE", "dashboard.app" → domain "DASHBOARD"
    # Unified graph manifests (e.g. web) may declare the same rows under ``nodes:`` only.
    raw_modules = _map_or_list_to_list(m.get("modules")) + _map_or_list_to_list(m.get("nodes"))
    for row in raw_modules:
        if "domain" not in row:
            name = str(row.get("name") or "")
            parts = name.split(".")
            if len(parts) > 1:
                row["domain"] = parts[0].upper()
    m["modules"] = raw_modules

    return m

