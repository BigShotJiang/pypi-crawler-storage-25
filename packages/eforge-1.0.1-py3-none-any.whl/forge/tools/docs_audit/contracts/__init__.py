"""Contract models and normalization."""

