from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Severity(str, Enum):
    BLOCKER = "blocker"
    HIGH = "high"
    NORMAL = "normal"
    WARN = "warn"


@dataclass(frozen=True)
class ComponentContract:
    name: str
    domain: str
    reads: list[str] = field(default_factory=list)
    writes: list[str] = field(default_factory=list)
    error_codes: list[str] = field(default_factory=list)
    capabilities: list[str] = field(default_factory=list)  # future swap parity checks


@dataclass(frozen=True)
class RequirementFile:
    path: str
    headings_any: list[str] = field(default_factory=list)
    keys_all: list[str] = field(default_factory=list)
    keys_any: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class CheckSpec:
    type: str
    params: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class TriggerSpec:
    match_mode: str = "any"  # any|all
    file_patterns: list[str] = field(default_factory=list)
    # fnmatch patterns against manifest node ids (e.g. module/mcp.*) after path→node resolution
    manifest_node_patterns: list[str] = field(default_factory=list)
    keywords: list[str] = field(default_factory=list)
    keyword_trigger_mode: str = "hint"  # hint|authoritative


@dataclass(frozen=True)
class Waiver:
    reason: str
    owner: str
    expires_on: str


@dataclass(frozen=True)
class ChangeRule:
    id: str
    severity: Severity
    owner: str
    autofix: str  # none|suggest|apply
    scope: list[str]
    triggers: TriggerSpec
    requires: list[RequirementFile]
    checks: list[CheckSpec]
    notes: str = ""
    source: str = "core"  # core|local_override
    waiver: Waiver | None = None


@dataclass(frozen=True)
class ValidationResult:
    ok: bool
    errors: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class TriggeredRule:
    rule: ChangeRule
    reasons: list[str]


@dataclass(frozen=True)
class AuditFailure:
    rule_id: str
    severity: Severity
    file: str
    message: str
    rule_source: str = "core"
    suggested_updates: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class AuditResult:
    triggered_rules: list[TriggeredRule]
    failures: list[AuditFailure]
    waiver_warnings: list[str] = field(default_factory=list)
    strict: bool = False
    # Optional HOW-layer semantic diff (change_kinds); does not affect exit_code.
    semantic_changes: list[Any] = field(default_factory=list)
    # Which tree satisfied manifest.yaml for policy (root | docs); from loaded manifest_path.
    manifest_resolved_from: str | None = None
    # Ring 2 manifest graph blast radius (informational; Stage 2 — no exit_code effect).
    graph_impact: dict[str, Any] = field(default_factory=dict)

    @property
    def exit_code(self) -> int:
        """impact-check contract: 0=no triggers, 1=advisory, 2=required follow-up."""
        if not self.triggered_rules:
            if not self.failures:
                return 0
            if all(f.severity == Severity.WARN for f in self.failures):
                return 1
            return 2
        serious = [f for f in self.failures if f.severity != Severity.WARN]
        blocker = any(f.severity == Severity.BLOCKER for f in serious)
        if self.strict:
            blocker = blocker or any(f.severity == Severity.HIGH for f in serious)
        if blocker:
            return 2
        if serious:
            return 2
        if self.failures:
            return 1
        return 1

