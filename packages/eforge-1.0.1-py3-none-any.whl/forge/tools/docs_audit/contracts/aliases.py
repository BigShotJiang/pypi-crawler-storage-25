from __future__ import annotations


HEADING_ALIASES: dict[str, list[str]] = {
    "## Hooks/Controllers": ["## Hooks", "## Controllers"],
    "## Current Architecture (Source of Truth)": ["## Current Architecture", "## Current State"],
    "## Roadmap / Planned (Explicitly Future)": ["## Roadmap / Planned", "## Roadmap"],
}


def heading_candidates(heading: str) -> list[str]:
    return [heading] + HEADING_ALIASES.get(heading, [])

