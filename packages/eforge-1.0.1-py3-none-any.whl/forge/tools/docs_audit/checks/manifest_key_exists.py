from __future__ import annotations

from forge.tools.docs_audit.contracts.models import AuditFailure, Severity


def run(spec: dict, manifest: dict, _docs_text: dict[str, str]) -> list[AuditFailure]:
    key = spec.get("key")
    keys_any = spec.get("keys_any", [])
    if key:
        if key in manifest:
            return []
        return [
            AuditFailure(
                rule_id="check.manifest_key_exists",
                severity=Severity.NORMAL,
                file="docs/manifest.yaml",
                message=f"Missing manifest key: {key}",
                rule_source="core",
                suggested_updates=["docs/manifest.yaml"],
            )
        ]
    if keys_any:
        if any(k in manifest for k in keys_any):
            return []
        return [
            AuditFailure(
                rule_id="check.manifest_key_exists",
                severity=Severity.NORMAL,
                file="docs/manifest.yaml",
                message=f"Missing any of manifest keys: {keys_any}",
                rule_source="core",
                suggested_updates=["docs/manifest.yaml"],
            )
        ]
    return []

