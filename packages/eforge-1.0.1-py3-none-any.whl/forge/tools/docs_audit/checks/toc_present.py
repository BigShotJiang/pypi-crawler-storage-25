from __future__ import annotations

import fnmatch

from forge.tools.docs_audit.contracts.models import AuditFailure, Severity
from forge.tools.context.index import parse_markdown_frontmatter
from forge.tools.toc.generator import has_contents_toc_section, heading_count_for_toc

TOC_REQUIRED_BY_TYPE = {
    "map": True,
    "internals": True,
    "architecture": True,
    "tool": True,
    "todo": False,
    "update": False,
    "error_codes": False,
    "agent_context": False,
    "agent_notes": False,
    "adr": False,
}


def run(spec: dict, _manifest: dict, docs_text: dict[str, str]) -> list[AuditFailure]:
    min_h = int(spec.get("min_headings_to_require", 3))
    exclude = spec.get("exclude_file_patterns") or [
        "**/README_CHECKLIST.md",
        "**/node_modules/**",
        "**/quarantine/**",
    ]
    failures: list[AuditFailure] = []
    for path in sorted(docs_text):
        if not path.endswith(".md"):
            continue
        if any(fnmatch.fnmatch(path.replace("\\", "/"), p) for p in exclude):
            continue
        text = docs_text[path]
        fm, _body = parse_markdown_frontmatter(text)
        toc_required = fm.get("toc_required")
        if toc_required is False:
            continue
        if toc_required is True:
            required = True
        else:
            doc_type = str(fm.get("type") or "").strip().lower()
            required = bool(TOC_REQUIRED_BY_TYPE.get(doc_type, False))
        if not required:
            continue
        n = heading_count_for_toc(text, 2, 3)
        if n < min_h:
            continue
        if has_contents_toc_section(text):
            continue
        failures.append(
            AuditFailure(
                rule_id="check.toc_present",
                severity=Severity.WARN,
                file=path,
                message=(
                    f"File has {n} headings (h2–h3) but no ## Contents TOC. "
                    f"Run: forge toc {path}"
                ),
                rule_source="core",
                suggested_updates=[path],
            )
        )
    return failures
