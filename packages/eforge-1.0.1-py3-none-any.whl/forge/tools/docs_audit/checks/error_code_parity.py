from __future__ import annotations

from forge.tools.docs_audit.contracts.models import AuditFailure, Severity


def run(spec: dict, manifest: dict, docs_text: dict[str, str]) -> list[AuditFailure]:
    error_file = spec.get("error_codes_file", "docs/ERROR_CODES.md")
    text = docs_text.get(error_file, "")
    if not text:
        for key, value in docs_text.items():
            if key.endswith(error_file):
                text = value
                break
    referenced: set[str] = set()
    for bucket in ("hooks", "controllers"):
        for row in manifest.get(bucket, []):
            for code in row.get("error_codes", []) or []:
                referenced.add(str(code))
    missing = [code for code in sorted(referenced) if code not in text]
    if not missing:
        return []
    return [
        AuditFailure(
            rule_id="check.error_code_parity",
            severity=Severity.NORMAL,
            file=error_file,
            message=f"Manifest error_codes not documented: {missing}",
            rule_source="core",
            suggested_updates=[error_file],
        )
    ]

