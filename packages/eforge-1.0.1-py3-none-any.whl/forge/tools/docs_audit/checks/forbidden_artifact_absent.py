from __future__ import annotations

import re

from forge.tools.docs_audit.contracts.models import AuditFailure, Severity


def run(spec: dict, _manifest: dict, docs_text: dict[str, str]) -> list[AuditFailure]:
    pattern = spec.get("pattern", r"\*\*\* End Patch\*\*\*")
    rx = re.compile(pattern)
    offenders = [f for f, text in docs_text.items() if f.endswith(".md") and rx.search(text)]
    if not offenders:
        return []
    return [
        AuditFailure(
            rule_id="check.forbidden_artifact_absent",
            severity=Severity.NORMAL,
            file="docs/**/*.md",
            message=f"Forbidden artifact pattern found in: {offenders}",
            rule_source="core",
            suggested_updates=offenders,
        )
    ]

