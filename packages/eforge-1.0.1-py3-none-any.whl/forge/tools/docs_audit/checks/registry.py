from __future__ import annotations

from forge.tools.docs_audit.contracts.models import AuditFailure
from forge.tools.docs_audit.checks import (
    domain_alignment,
    error_code_format,
    error_code_parity,
    forbidden_artifact_absent,
    heading_exists,
    manifest_doc_parity,
    manifest_key_exists,
    phase_consistency,
    required_docs_present,
)
from forge.tools.docs_audit.checks.toc_present import run as toc_present_run


REGISTRY = {
    "heading_exists": heading_exists.run,
    "required_docs_present": required_docs_present.run,
    "forbidden_artifact_absent": forbidden_artifact_absent.run,
    "domain_alignment": domain_alignment.run,
    "error_code_parity": error_code_parity.run,
    "manifest_key_exists": manifest_key_exists.run,
    "error_code_format": error_code_format.run,
    "manifest_doc_parity": manifest_doc_parity.run,
    "phase_consistency": phase_consistency.run,
    "toc_present": toc_present_run,
}


def run_check(check_spec: dict, manifest: dict, docs_text: dict[str, str]) -> list[AuditFailure]:
    check_type = check_spec.get("type")
    if check_type not in REGISTRY:
        return []
    return REGISTRY[check_type](check_spec, manifest, docs_text)

