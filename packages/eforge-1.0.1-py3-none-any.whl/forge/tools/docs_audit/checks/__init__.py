"""Check plugins for docs_audit."""

