from __future__ import annotations

import re

from forge.tools.docs_audit.contracts.models import AuditFailure, Severity


def _slug(value: str) -> str:
    value = value.strip()
    value = re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", value)
    value = value.replace("_", "-")
    value = re.sub(r"\s+", "-", value)
    value = re.sub(r"-+", "-", value)
    return value.lower()


def _extract_section(text: str, heading: str) -> str:
    pattern = re.compile(rf"^##\s+{re.escape(heading)}\s*$", re.MULTILINE)
    m = pattern.search(text)
    if not m:
        return ""
    start = m.end()
    nxt = re.search(r"^##\s+", text[start:], re.MULTILINE)
    end = start + nxt.start() if nxt else len(text)
    return text[start:end]


def _extract_names(section_text: str) -> set[str]:
    names: set[str] = set()
    for raw in section_text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("|") and line.count("|") >= 2:
            cols = [c.strip() for c in line.split("|") if c.strip()]
            if cols and cols[0].lower() not in {"name", "---"}:
                names.add(cols[0].strip("`"))
            continue
        if line.startswith("-"):
            token = line.lstrip("-").strip().strip("`")
            if token:
                names.add(token)
    return names


def _contains_name(doc_names: set[str], target: str) -> tuple[bool, str]:
    if target in doc_names:
        return True, "exact"
    tslug = _slug(target)
    for d in doc_names:
        if _slug(d) == tslug:
            return True, "slug"
    return False, "none"


def run(spec: dict, manifest: dict, docs_text: dict[str, str]) -> list[AuditFailure]:
    manifest_doc = spec.get("manifest_doc_file", "docs/MANIFEST.md")
    text = docs_text.get(manifest_doc, "")
    if not text:
        for k, v in docs_text.items():
            if k.endswith(manifest_doc):
                text = v
                break
    if not text:
        return []

    screen_section = _extract_section(text, "Screens")
    controller_section = _extract_section(text, "Controllers")
    domain_section = _extract_section(text, "Domains")
    doc_screens = _extract_names(screen_section)
    doc_controllers = _extract_names(controller_section)
    doc_domains = _extract_names(domain_section)

    man_screens = [str(x.get("name", "")) for x in manifest.get("screens", []) if x.get("name")]
    man_controllers = [
        str(x.get("name", "")) for x in (manifest.get("controllers", []) or manifest.get("hooks", [])) if x.get("name")
    ]
    man_domains = sorted(
        {
            str(x.get("domain", "")).upper()
            for bucket in ("screens", "controllers", "hooks", "services")
            for x in manifest.get(bucket, [])
            if x.get("domain")
        }
    )

    failures: list[AuditFailure] = []
    for name in man_screens:
        ok, strategy = _contains_name(doc_screens, name)
        if not ok:
            failures.append(
                AuditFailure(
                    rule_id="check.manifest_doc_parity",
                    severity=Severity.BLOCKER,
                    file=manifest_doc,
                    message=f"Missing screen `{name}` in docs/MANIFEST.md (match_strategy={strategy})",
                    rule_source="core",
                    suggested_updates=[manifest_doc],
                )
            )
    for name in man_controllers:
        ok, strategy = _contains_name(doc_controllers, name)
        if not ok:
            failures.append(
                AuditFailure(
                    rule_id="check.manifest_doc_parity",
                    severity=Severity.BLOCKER,
                    file=manifest_doc,
                    message=f"Missing controller `{name}` in docs/MANIFEST.md (match_strategy={strategy})",
                    rule_source="core",
                    suggested_updates=[manifest_doc],
                )
            )
    for name in man_domains:
        ok, strategy = _contains_name(doc_domains, name)
        if not ok:
            failures.append(
                AuditFailure(
                    rule_id="check.manifest_doc_parity",
                    severity=Severity.BLOCKER,
                    file=manifest_doc,
                    message=f"Missing domain `{name}` in docs/MANIFEST.md (match_strategy={strategy})",
                    rule_source="core",
                    suggested_updates=[manifest_doc],
                )
            )

    for stale in sorted(doc_screens):
        ok, _ = _contains_name(set(man_screens), stale)
        if not ok:
            failures.append(
                AuditFailure(
                    rule_id="check.manifest_doc_parity",
                    severity=Severity.NORMAL,
                    file=manifest_doc,
                    message=f"Stale screen entry in docs/MANIFEST.md: `{stale}`",
                    rule_source="core",
                    suggested_updates=[manifest_doc],
                )
            )
    for stale in sorted(doc_controllers):
        ok, _ = _contains_name(set(man_controllers), stale)
        if not ok:
            failures.append(
                AuditFailure(
                    rule_id="check.manifest_doc_parity",
                    severity=Severity.NORMAL,
                    file=manifest_doc,
                    message=f"Stale controller entry in docs/MANIFEST.md: `{stale}`",
                    rule_source="core",
                    suggested_updates=[manifest_doc],
                )
            )
    for stale in sorted(doc_domains):
        ok, _ = _contains_name(set(man_domains), stale)
        if not ok:
            failures.append(
                AuditFailure(
                    rule_id="check.manifest_doc_parity",
                    severity=Severity.NORMAL,
                    file=manifest_doc,
                    message=f"Stale domain entry in docs/MANIFEST.md: `{stale}`",
                    rule_source="core",
                    suggested_updates=[manifest_doc],
                )
            )
    return failures

