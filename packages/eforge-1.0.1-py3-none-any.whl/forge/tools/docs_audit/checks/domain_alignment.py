from __future__ import annotations

from forge.tools.docs_audit.contracts.models import AuditFailure, Severity


def run(spec: dict, manifest: dict, docs_text: dict[str, str]) -> list[AuditFailure]:
    error_file = spec.get("error_codes_file", "docs/ERROR_CODES.md")
    text = docs_text.get(error_file, "")
    if not text:
        for key, value in docs_text.items():
            if key.endswith(error_file):
                text = value
                break
    domains: set[str] = set()
    for bucket in ("hooks", "controllers", "services"):
        for row in manifest.get(bucket, []):
            d = row.get("domain")
            if isinstance(d, str) and d:
                domains.add(d.upper())
    missing = [d for d in sorted(domains) if f"## {d} Domain" not in text]
    if not missing:
        return []
    return [
        AuditFailure(
            rule_id="check.domain_alignment",
            severity=Severity.NORMAL,
            file=error_file,
            message=f"Missing domain sections in ERROR_CODES: {missing}",
            rule_source="core",
            suggested_updates=[error_file],
        )
    ]

