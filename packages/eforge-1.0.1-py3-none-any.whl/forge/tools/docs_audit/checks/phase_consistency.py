from __future__ import annotations

import re

from forge.tools.docs_audit.contracts.models import AuditFailure, Severity


PHASE_RE = re.compile(r"[Pp]hase\s+(\d+)")


def _extract_current_phase(text: str) -> int | None:
    if not text:
        return None
    lines = text.splitlines()
    best: tuple[int, int] | None = None
    for idx, line in enumerate(lines):
        m = PHASE_RE.search(line)
        if not m:
            continue
        marker_score = 0
        window = "\n".join(lines[max(0, idx - 2) : idx + 3]).lower()
        if "current" in window or "← current" in window or "active" in window:
            marker_score = 1
        phase = int(m.group(1))
        cand = (marker_score, phase)
        if best is None or cand[0] > best[0]:
            best = cand
    if best is None:
        return None
    return best[1]


def _resolve_text(docs_text: dict[str, str], path: str) -> str:
    if path in docs_text:
        return docs_text[path]
    for k, v in docs_text.items():
        if k.endswith(path):
            return v
    return ""


def _resolve_phase_file_text(docs_text: dict[str, str], path: str) -> str:
    """Resolve doc body; AGENT_CONTEXT may live under docs/archive/."""
    text = _resolve_text(docs_text, path)
    if text:
        return text
    if path.endswith("AGENT_CONTEXT.md"):
        return _resolve_text(docs_text, "docs/archive/AGENT_CONTEXT.md")
    return ""


def _manifest_declared_phase(manifest: dict) -> int | None:
    """Mechanical phase source: manifest ``phases.current`` (declaration graph)."""
    phases = manifest.get("phases")
    if not isinstance(phases, dict):
        return None
    cur = phases.get("current")
    if cur is None:
        return None
    try:
        return int(cur)
    except (TypeError, ValueError):
        return None


def run(spec: dict, manifest: dict, docs_text: dict[str, str]) -> list[AuditFailure]:
    """
    Prefer ``manifest.phases.current`` when present: doc-extracted phases must match it.
    Markdown phase markers in TODO/MAP/AGENT_CONTEXT remain a secondary signal; AGENT_CONTEXT
    is legacy (prefer forge_context / forge_project_status for agents).
    """
    files = spec.get("files", ["docs/TODO.md", "docs/MAP.md", "docs/AGENT_CONTEXT.md"])
    phases: dict[str, int] = {}
    failures: list[AuditFailure] = []
    manifest_phase = _manifest_declared_phase(manifest)
    for path in files:
        text = _resolve_phase_file_text(docs_text, path)
        if not text:
            if path.endswith("AGENT_CONTEXT.md"):
                continue
            failures.append(
                AuditFailure(
                    rule_id="check.phase_consistency",
                    severity=Severity.NORMAL,
                    file=path,
                    message=f"Missing phase marker source file: {path}",
                    rule_source="core",
                    suggested_updates=[path],
                )
            )
            continue
        phase = _extract_current_phase(text)
        if phase is None:
            failures.append(
                AuditFailure(
                    rule_id="check.phase_consistency",
                    severity=Severity.NORMAL,
                    file=path,
                    message=f"No current phase marker found in {path}",
                    rule_source="core",
                    suggested_updates=[path],
                )
            )
            continue
        phases[path] = phase

    if manifest_phase is not None and phases:
        for path, doc_phase in phases.items():
            if doc_phase != manifest_phase:
                failures.append(
                    AuditFailure(
                        rule_id="check.phase_consistency",
                        severity=Severity.BLOCKER,
                        file=path,
                        message=(
                            f"Doc phase {doc_phase} does not match manifest phases.current={manifest_phase}"
                        ),
                        rule_source="core",
                        suggested_updates=[path, "manifest.yaml"],
                    ),
                )

    if len(set(phases.values())) > 1:
        failures.append(
            AuditFailure(
                rule_id="check.phase_consistency",
                severity=Severity.BLOCKER,
                file="docs/*",
                message=f"Phase mismatch across docs files: {phases}",
                rule_source="core",
                suggested_updates=list(phases.keys()),
            )
        )
    return failures

