from __future__ import annotations

from forge.tools.docs_audit.contracts.aliases import heading_candidates
from forge.tools.docs_audit.contracts.models import AuditFailure, Severity


def run(spec: dict, _manifest: dict, docs_text: dict[str, str]) -> list[AuditFailure]:
    file_path = spec.get("file", "")
    headings = spec.get("headings", [])
    text = docs_text.get(file_path, "")
    if not file_path or not headings:
        return []
    for heading in headings:
        if any(candidate in text for candidate in heading_candidates(heading)):
            return []
    return [
        AuditFailure(
            rule_id="check.heading_exists",
            severity=Severity.NORMAL,
            file=file_path,
            message=f"Missing one of required headings: {headings}",
            rule_source="core",
            suggested_updates=[file_path],
        )
    ]

