from __future__ import annotations

import re

from forge.tools.docs_audit.contracts.models import AuditFailure, Severity


def run(spec: dict, _manifest: dict, docs_text: dict[str, str]) -> list[AuditFailure]:
    file_path = spec.get("file", "docs/ERROR_CODES.md")
    pattern = spec.get("pattern", r"E_[A-Z0-9]+_[A-Z0-9]+_[A-Z0-9_]+")
    text = docs_text.get(file_path, "")
    if not text:
        return []
    if re.search(pattern, text):
        return []
    return [
        AuditFailure(
            rule_id="check.error_code_format",
            severity=Severity.NORMAL,
            file=file_path,
            message=f"No code matching required pattern `{pattern}`",
            rule_source="core",
            suggested_updates=[file_path],
        )
    ]

