from __future__ import annotations

from forge.tools.docs_audit.contracts.models import AuditFailure, Severity


def run(spec: dict, _manifest: dict, docs_text: dict[str, str]) -> list[AuditFailure]:
    required = spec.get("files", [])
    if not required:
        return []
    missing = [f for f in required if f not in docs_text]
    if not missing:
        return []
    return [
        AuditFailure(
            rule_id="check.required_docs_present",
            severity=Severity.NORMAL,
            file="docs/*",
            message=f"Missing required docs: {missing}",
            rule_source="core",
            suggested_updates=missing,
        )
    ]

