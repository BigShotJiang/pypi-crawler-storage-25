from __future__ import annotations

import json
import subprocess
from pathlib import Path

def _git_changed_files(base: str, head: str, cwd: str | None = None) -> list[str]:
    cmd = ["git", "diff", "--name-only", f"{base}...{head}"]
    try:
        proc = subprocess.run(
            cmd,
            check=False,
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=30,
        )
    except OSError:
        return []
    if proc.returncode != 0:
        return []
    return [line.strip() for line in proc.stdout.splitlines() if line.strip()]


def get_changed_files(
    source: str,
    base: str,
    head: str,
    changed_files_json: str | None = None,
    changed_files: list[str] | None = None,
    cwd: str | None = None,
) -> list[str]:
    if changed_files:
        expanded: list[str] = []
        for item in changed_files:
            text = str(item)
            for part in text.replace(",", " ").split():
                if part:
                    expanded.append(part)
        return expanded
    if source == "explicit":
        if not changed_files_json:
            return []
        data = json.loads(Path(changed_files_json).read_text(encoding="utf-8"))
        if not isinstance(data, list):
            return []
        return [str(x) for x in data]
    return _git_changed_files(base=base, head=head, cwd=cwd)

