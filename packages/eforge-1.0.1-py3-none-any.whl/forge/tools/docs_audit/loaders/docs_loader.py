from __future__ import annotations

from pathlib import Path


def load_docs_corpus(docs_root: str) -> dict[str, str]:
    root = Path(docs_root)
    if not root.exists():
        return {}
    out: dict[str, str] = {}
    cwd = Path.cwd()
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() not in {".md", ".yaml", ".yml"}:
            continue
        resolved = path.resolve()
        try:
            rel_from_cwd = str(resolved.relative_to(cwd)).replace("\\", "/")
        except ValueError:
            rel_from_cwd = str(resolved).replace("\\", "/")
        out[rel_from_cwd] = path.read_text(encoding="utf-8")
    return out

