from __future__ import annotations

from pathlib import Path
from typing import Any

from forge.tools.docs_audit.checks.registry import run_check
from forge.tools.docs_audit.contracts.models import AuditFailure, Severity, TriggeredRule


def _manifest_source_label(resolved: Path) -> str:
    s = str(resolved.resolve()).replace("\\", "/")
    if s.endswith("/docs/manifest.yaml") or "/docs/manifest.yaml" in s:
        return "docs"
    return "root"


def _overlay_manifest_text(docs_text: dict[str, str], resolved_manifest_path: Path | None) -> tuple[dict[str, str], str | None]:
    """Copy docs corpus; inject loaded manifest text under common keys if missing."""
    if resolved_manifest_path is None:
        return docs_text, None
    mp = Path(resolved_manifest_path)
    if not mp.is_file():
        return docs_text, None
    try:
        mt = mp.read_text(encoding="utf-8")
    except OSError:
        return docs_text, None
    out = dict(docs_text)
    prov = _manifest_source_label(mp)
    keys = {
        "manifest.yaml",
        "docs/manifest.yaml",
        str(mp.resolve()).replace("\\", "/"),
        str(mp).replace("\\", "/"),
    }
    for k in keys:
        if k and k not in out:
            out[k] = mt
    return out, prov


def _manifest_drift_warnings(project_root: Path) -> list[AuditFailure]:
    root_m = project_root / "manifest.yaml"
    docs_m = project_root / "docs" / "manifest.yaml"
    if not root_m.is_file() or not docs_m.is_file():
        return []
    try:
        if root_m.read_bytes() == docs_m.read_bytes():
            return []
    except OSError:
        return []
    return [
        AuditFailure(
            rule_id="MANIFEST_DRIFT",
            severity=Severity.WARN,
            file="manifest.yaml",
            message=(
                "MANIFEST_DRIFT: root and docs/manifest.yaml differ — root is canonical "
                "(sync or align mirrors per ADR-005)"
            ),
            rule_source="core",
            suggested_updates=["manifest.yaml", "docs/manifest.yaml"],
        )
    ]


def _project_root_from_manifest_path(manifest_path: Path | None) -> Path | None:
    if manifest_path is None:
        return None
    try:
        mp = manifest_path.resolve()
    except OSError:
        return None
    if mp.parent.name == "docs":
        return mp.parent.parent
    return mp.parent


def evaluate(
    triggered: list[TriggeredRule],
    manifest: dict[str, Any],
    docs_text: dict[str, str],
    strict: bool = False,
    *,
    resolved_manifest_path: Path | None = None,
) -> tuple[list[TriggeredRule], list[AuditFailure], bool, str | None]:
    effective_docs, manifest_prov = _overlay_manifest_text(docs_text, resolved_manifest_path)

    def _resolve_doc_key(path: str) -> str | None:
        if path in effective_docs:
            return path
        for key in effective_docs:
            if key.endswith(path):
                return key
        return None

    failures: list[AuditFailure] = []
    for tr in triggered:
        rule = tr.rule
        for req in rule.requires:
            resolved_key = _resolve_doc_key(req.path)
            if resolved_key is None:
                # manifest.yaml may live only at repo root / docs/ — not in docs corpus scan
                norm = req.path.replace("\\", "/").rstrip("/")
                if norm.endswith("manifest.yaml") and resolved_manifest_path is not None:
                    mp = Path(resolved_manifest_path)
                    if mp.is_file():
                        try:
                            mt = mp.read_text(encoding="utf-8")
                        except OSError:
                            mt = ""
                        # Re-overlay so req.path and checks resolve consistently
                        effective_docs = dict(effective_docs)
                        for k in (req.path, norm, "manifest.yaml", "docs/manifest.yaml"):
                            if k and k not in effective_docs:
                                effective_docs[k] = mt
                        resolved_key = _resolve_doc_key(req.path) or _resolve_doc_key("manifest.yaml")
                if resolved_key is None:
                    failures.append(
                        AuditFailure(
                            rule_id=rule.id,
                            severity=rule.severity,
                            file=req.path,
                            message=f"Required file missing: {req.path}",
                            rule_source=rule.source,
                            suggested_updates=[req.path],
                        )
                    )
                    continue
            content = effective_docs[resolved_key]
            if req.headings_any:
                check_failures = run_check(
                    {"type": "heading_exists", "file": resolved_key, "headings": req.headings_any},
                    manifest,
                    effective_docs,
                )
                for f in check_failures:
                    failures.append(
                        AuditFailure(
                            rule_id=rule.id,
                            severity=f.severity,
                            file=f.file,
                            message=f.message,
                            rule_source=rule.source,
                            suggested_updates=[req.path],
                        )
                    )
            if req.keys_all:
                for key in req.keys_all:
                    check_failures = run_check({"type": "manifest_key_exists", "key": key}, manifest, effective_docs)
                    for f in check_failures:
                        failures.append(
                            AuditFailure(
                                rule_id=rule.id,
                                severity=f.severity,
                                file=f.file,
                                message=f.message,
                                rule_source=rule.source,
                                suggested_updates=["docs/manifest.yaml"],
                            )
                        )
            if req.keys_any:
                check_failures = run_check(
                    {"type": "manifest_key_exists", "keys_any": req.keys_any}, manifest, effective_docs
                )
                for f in check_failures:
                    failures.append(
                        AuditFailure(
                            rule_id=rule.id,
                            severity=f.severity,
                            file=f.file,
                            message=f.message,
                            rule_source=rule.source,
                            suggested_updates=["docs/manifest.yaml"],
                        )
                    )
            _ = content

        for check in rule.checks:
            check_spec = {"type": check.type, **check.params}
            check_failures = run_check(check_spec, manifest, effective_docs)
            for f in check_failures:
                failures.append(
                    AuditFailure(
                        rule_id=rule.id,
                        severity=f.severity,
                        file=f.file,
                        message=f.message,
                        rule_source=rule.source,
                        suggested_updates=f.suggested_updates,
                    )
                )

    root = _project_root_from_manifest_path(resolved_manifest_path)
    if root is not None:
        failures.extend(_manifest_drift_warnings(root))

    return triggered, failures, strict, manifest_prov
