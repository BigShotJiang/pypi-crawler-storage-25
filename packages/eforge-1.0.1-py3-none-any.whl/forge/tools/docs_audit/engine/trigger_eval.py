from __future__ import annotations

import fnmatch

from forge.tools.docs_audit.contracts.models import ChangeRule, TriggeredRule


def _match_paths(changed_files: list[str], patterns: list[str]) -> bool:
    if not patterns:
        return False
    for changed in changed_files:
        if any(fnmatch.fnmatch(changed, p) for p in patterns):
            return True
    return False


def _match_manifest_node_patterns(node_ids: list[str], patterns: list[str]) -> bool:
    if not patterns:
        return False
    for nid in node_ids:
        for p in patterns:
            if fnmatch.fnmatch(nid, p):
                return True
    return False


def evaluate_triggers(
    rules: list[ChangeRule],
    changed_files: list[str],
    changed_text: str = "",
    *,
    changed_node_ids: list[str] | None = None,
) -> list[TriggeredRule]:
    triggered: list[TriggeredRule] = []
    nodes = list(changed_node_ids or [])
    for rule in rules:
        reasons: list[str] = []
        pattern_hit = _match_paths(changed_files, rule.triggers.file_patterns)
        node_hit = _match_manifest_node_patterns(nodes, rule.triggers.manifest_node_patterns)
        keyword_hit = False
        if rule.triggers.keywords:
            keyword_hit = any(k in changed_text for k in rule.triggers.keywords)

        # Deterministic precedence:
        # - file patterns are primary
        # - manifest node patterns: Gate 7 / declaration-graph triggers (path → node id)
        # - keywords are hints unless keyword_trigger_mode=authoritative
        dims: list[bool] = []
        if rule.triggers.file_patterns:
            dims.append(pattern_hit)
        if rule.triggers.manifest_node_patterns:
            dims.append(node_hit)
        if rule.triggers.keywords and rule.triggers.keyword_trigger_mode == "authoritative":
            dims.append(keyword_hit)
        if not dims and rule.triggers.keywords:
            dims.append(keyword_hit)

        if not dims:
            ok = False
        elif rule.triggers.match_mode == "all":
            ok = all(dims)
        else:
            ok = any(dims)

        if ok:
            if pattern_hit:
                reasons.append("file_pattern_match")
            if node_hit:
                reasons.append("manifest_node_match")
            if keyword_hit:
                reasons.append("keyword_match")
            triggered.append(TriggeredRule(rule=rule, reasons=reasons))
    return triggered

