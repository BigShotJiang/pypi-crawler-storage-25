from __future__ import annotations

from typing import Any

from forge.tools.docs_audit.contracts.models import AuditResult


def merge_results(
    triggered_rules,
    failures,
    strict: bool,
    waiver_warnings=None,
    semantic_changes=None,
    manifest_resolved_from: str | None = None,
    graph_impact: dict[str, Any] | None = None,
) -> AuditResult:
    gi: dict[str, Any] = {} if graph_impact is None else dict(graph_impact)
    return AuditResult(
        triggered_rules=triggered_rules,
        failures=failures,
        waiver_warnings=waiver_warnings or [],
        strict=strict,
        semantic_changes=semantic_changes or [],
        manifest_resolved_from=manifest_resolved_from,
        graph_impact=gi,
    )

