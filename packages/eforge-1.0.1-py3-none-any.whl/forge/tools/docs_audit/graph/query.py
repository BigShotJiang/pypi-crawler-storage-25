from __future__ import annotations


def query_impact(_graph: dict, _changed: list[str]) -> dict:
    """Phase-2 stub for impact query."""
    return {"impacted": []}

