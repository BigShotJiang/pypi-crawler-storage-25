from __future__ import annotations


def build_graph(_manifest: dict, _rules: list[dict], _docs_text: dict[str, str]) -> dict:
    """Phase-2 stub: derived graph only, never authoring surface."""
    return {"nodes": [], "edges": []}

