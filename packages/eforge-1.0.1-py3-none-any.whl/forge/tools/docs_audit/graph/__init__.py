"""Derived graph stubs for phase 2."""

