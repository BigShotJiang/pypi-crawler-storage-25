from __future__ import annotations

from forge.tools.docs_audit.change_classifier import SemanticChange, semantic_change_to_dict
from forge.tools.docs_audit.contracts.models import AuditResult


def build_summary(result: AuditResult) -> str:
    schema_errs = sum(1 for f in result.failures if f.rule_id.startswith("schema."))
    triggered_failures = len(result.failures) - schema_errs
    lines: list[str] = [
        f"Schema errors: {schema_errs}  (pre-flight, fix YAML)",
        f"Triggered failures: {triggered_failures}  (audit, fix docs)",
    ]
    if schema_errs > 0 and triggered_failures == 0:
        lines.extend(
            [
                "",
                "All failures are schema validation errors.",
                "Fix manifest.yaml or change-impact.yaml shape to resolve.",
                "Run: forge impact-check --help for schema requirements.",
            ]
        )
    lines.append("")
    blocker = sum(1 for f in result.failures if f.severity.value == "blocker")
    high = sum(1 for f in result.failures if f.severity.value == "high")
    normal = sum(1 for f in result.failures if f.severity.value == "normal")
    lines.append(
        f"docs-audit: triggered={len(result.triggered_rules)} "
        f"failures={len(result.failures)} (blocker={blocker}, high={high}, normal={normal}) "
        f"exit={result.exit_code}"
    )
    if result.semantic_changes:
        lines.append("")
        lines.append("Semantic analysis:")
        for sc in result.semantic_changes:
            if isinstance(sc, SemanticChange):
                d = semantic_change_to_dict(sc)
            elif isinstance(sc, dict):
                d = sc
            else:
                continue
            lines.append(f"  {d.get('kind', '?')} detected")
            lines.append(f"    Changed: {d.get('changed_node', '')}")
            aff = d.get("affected") or []
            if aff:
                lines.append(f"    Affected: {', '.join(str(x) for x in aff)}")
            lines.append(f"    Severity: {d.get('severity', '')}")
            lines.append(f"    ADR required: {'yes' if d.get('requires_adr') else 'no'}")
    lines.append("")
    lines.append("Graph impact (derived):")
    gi = dict(getattr(result, "graph_impact", {}) or {})
    combined = gi.get("affected_nodes") or []
    if isinstance(combined, list) and combined:
        for row in combined:
            if not isinstance(row, dict):
                continue
            node = str(row.get("node", ""))
            principle = str(row.get("principle", ""))
            sev = str(row.get("severity", ""))
            reason = str(row.get("reason", ""))
            lines.append(f"  -> {principle}: {node} ({sev})")
            if reason:
                lines.append(f"     {reason}")
    else:
        lines.append("  (no graph-derived affected nodes)")
    return "\n".join(lines)

