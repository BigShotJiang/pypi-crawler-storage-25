from __future__ import annotations

from forge.tools.docs_audit.change_classifier import SemanticChange, semantic_change_to_dict
from forge.tools.docs_audit.contracts.models import AuditResult


def build_audit_json(result: AuditResult) -> dict:
    return {
        "schema_version": 1,
        "triggered_change_types": [
            {
                "id": tr.rule.id,
                "severity": tr.rule.severity.value,
                "rule_source": tr.rule.source,
                "reasons": tr.reasons,
            }
            for tr in result.triggered_rules
        ],
        "failures": [
            {
                "rule_id": f.rule_id,
                "severity": f.severity.value,
                "file": f.file,
                "message": f.message,
                "rule_source": f.rule_source,
                "suggested_updates": f.suggested_updates,
            }
            for f in result.failures
        ],
        "waiver_warnings": result.waiver_warnings,
        "manifest_resolved_from": result.manifest_resolved_from,
        "exit_code": result.exit_code,
        "semantic_changes": [
            semantic_change_to_dict(sc)
            if isinstance(sc, SemanticChange)
            else (sc if isinstance(sc, dict) else {"repr": str(sc)})
            for sc in (result.semantic_changes or [])
        ],
        "graph_impact": result.graph_impact or {},
    }

