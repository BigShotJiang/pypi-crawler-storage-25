from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class TriggeredRule(BaseModel):
    rule_id: str
    severity: str
    source: Literal["core", "local_override"]
    reason: str


class Failure(BaseModel):
    rule_id: str
    severity: str
    file: str
    message: str
    suggested_update: str
    source: Literal["core", "local_override"]
    waiver_status: str | None = None


class AuditResponse(BaseModel):
    project: str
    status: Literal["pass", "warn", "fail"]
    exit_code: Literal[0, 1, 2]

    triggered_rules: list[TriggeredRule]
    failures: list[Failure]

    pass_count: int
    warn_count: int
    blocker_count: int

    generated_at: str
    strict_mode: bool
    rule_sources: dict[str, Literal["core", "local_override"]]

