from __future__ import annotations

from datetime import date

from forge.tools.docs_audit.contracts.models import ChangeRule


def collect_waiver_warnings(rules: list[ChangeRule], warning_window_days: int = 14) -> list[str]:
    warnings: list[str] = []
    today = date.today()
    for rule in rules:
        waiver = rule.waiver
        if waiver is None:
            continue
        try:
            exp = date.fromisoformat(waiver.expires_on)
        except ValueError:
            continue
        days = (exp - today).days
        if 0 <= days <= warning_window_days:
            warnings.append(
                f"Waiver for rule {rule.id} expires {waiver.expires_on} — owned by {waiver.owner}"
            )
    return warnings

