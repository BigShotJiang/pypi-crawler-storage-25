from __future__ import annotations

from forge.tools.docs_audit.contracts.models import AuditResult


def build_audit_markdown(result: AuditResult) -> str:
    lines: list[str] = []
    lines.append("# Docs Audit Report")
    lines.append("")
    lines.append(f"- Triggered rules: {len(result.triggered_rules)}")
    lines.append(f"- Failures: {len(result.failures)}")
    lines.append(f"- Exit code: {result.exit_code}")
    lines.append("")

    if result.triggered_rules:
        lines.append("## Triggered Rules")
        for tr in result.triggered_rules:
            lines.append(
                f"- `{tr.rule.id}` ({tr.rule.severity.value}, source={tr.rule.source}) reasons={','.join(tr.reasons) or 'n/a'}"
            )
        lines.append("")

    if result.failures:
        lines.append("## Failures")
        for f in result.failures:
            lines.append(f"- [{f.severity.value}] `{f.rule_id}` `{f.file}` ({f.rule_source}) - {f.message}")
            if f.suggested_updates:
                lines.append(f"  - Suggested updates: {', '.join(f.suggested_updates)}")
    else:
        lines.append("## Status")
        lines.append("- Pass")
    if result.waiver_warnings:
        lines.append("")
        lines.append("## Waiver Warnings")
        for w in result.waiver_warnings:
            lines.append(f"- ⚠️ {w}")
    lines.append("")
    return "\n".join(lines)

