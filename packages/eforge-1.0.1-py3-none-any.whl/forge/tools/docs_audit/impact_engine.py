from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import yaml

from forge.core.impact import (
    change_events_to_principle_results,
    classify_change,
    git_diff_lines_for_file,
)
from forge.core.manifest_path import resolve_manifest_path
from forge.tools.docs_audit.contracts.models import AuditFailure
from forge.tools.docs_audit.principles import PrincipleResult, apply_principles
from forge.tools.manifest.graph import (
    build_manifest_graph,
    find_node_id_for_path,
)
from forge.tools.registry.store import load_registry


@dataclass(frozen=True)
class ImpactResult:
    changed_files: list[str]
    principle_results: list[PrincipleResult]
    rule_results: list[AuditFailure]
    combined: list[dict[str, Any]]
    exit_code: int
    graph_summary: dict[str, Any] = field(default_factory=dict)


def _read_change_impact_yaml(project_path: Path) -> dict[str, Any]:
    # DEPRECATED: change-impact.yaml is phased out in favor of graph-based analysis
    # Return empty dict to disable static rule processing
    # Modern alternatives: forge blast-radius, forge query, forge impact-check
    return {}


def _severity_rank(sev: str) -> int:
    m = {"warn": 1, "normal": 2, "high": 3, "blocker": 4}
    return m.get(str(sev).lower(), 2)


def _apply_overrides(
    principle_results: list[PrincipleResult],
    rules_cfg: dict[str, Any],
) -> list[PrincipleResult]:
    po = rules_cfg.get("principle_overrides") or {}
    if not isinstance(po, dict):
        return principle_results

    suppress_raw = po.get("suppress") or []
    suppress = {str(x) for x in suppress_raw} if isinstance(suppress_raw, list) else set()

    escalations_raw = po.get("escalate_severity") or {}
    escalations = dict(escalations_raw) if isinstance(escalations_raw, dict) else {}

    add_aff_raw = po.get("add_affected_nodes") or {}
    add_aff = dict(add_aff_raw) if isinstance(add_aff_raw, dict) else {}

    out: list[PrincipleResult] = []
    for r in principle_results:
        if r.principle in suppress:
            continue
        sev = str(escalations.get(r.principle, r.severity)).lower()
        if _severity_rank(sev) < _severity_rank(r.severity):
            sev = r.severity
        extra = add_aff.get(r.principle) or []
        extra_nodes = [str(x) for x in extra] if isinstance(extra, list) else []
        nodes = sorted(set([*r.affected_nodes, *extra_nodes]))
        out.append(
            PrincipleResult(
                principle=r.principle,
                changed_node=r.changed_node,
                affected_nodes=nodes,
                severity=sev,
                reason=r.reason,
                ring=r.ring,
                derived=True,
                metadata=dict(r.metadata or {}),
            )
        )
    return out


def _combine(results: list[PrincipleResult]) -> list[dict[str, Any]]:
    merged: dict[tuple[str, str], dict[str, Any]] = {}
    for r in results:
        for node in r.affected_nodes:
            key = (node, r.principle)
            row = merged.get(key)
            if row is None:
                merged[key] = {
                    "node": node,
                    "reason": r.reason,
                    "principle": r.principle,
                    "severity": r.severity,
                    "ring": r.ring,
                    "derived": True,
                }
                if r.metadata:
                    merged[key]["metadata"] = dict(r.metadata)
                continue
            if _severity_rank(r.severity) > _severity_rank(str(row["severity"])):
                row["severity"] = r.severity
            if r.metadata:
                md = dict(row.get("metadata") or {})
                md.update(r.metadata)
                row["metadata"] = md
    rows = list(merged.values())
    rows.sort(key=lambda x: (-_severity_rank(str(x["severity"])), str(x["node"]), str(x["principle"])))
    return rows


def compute_impact(
    changed_files: list[str],
    project_path: Path,
    include_ring1: bool = False,
    *,
    manifest_data: dict[str, Any] | None = None,
) -> ImpactResult:
    # INTERFACE BOUNDARY: principle overlay is additive/informational.
    # exit_code is NOT affected by principle results in this flow.
    # Do not change this contract without updating docs/INTERNALS.md
    # and freezing against downstream dependents first.
    project_root = Path(project_path).resolve()
    capped_files = list(changed_files)
    if len(capped_files) > 500:
        capped_files = capped_files[:500]
    graph = (
        build_manifest_graph(project_root, manifest_data=manifest_data)
        if manifest_data
        else build_manifest_graph(project_root)
    )
    by_id = {n.id: n for n in graph.nodes}
    registry_graph = load_registry() if include_ring1 else {}

    results: list[PrincipleResult] = []
    for cf in capped_files:
        rel = str(cf).replace("\\", "/")
        nid = find_node_id_for_path(graph, rel)
        n = by_id.get(nid) if nid else None

        diff_lines = git_diff_lines_for_file(project_root, rel)
        if diff_lines:
            events = classify_change(rel, diff_lines, graph, project_root)
            disp = n.name if n else rel
            cid = nid if nid else rel
            results.extend(
                change_events_to_principle_results(
                    events,
                    changed_node_id=str(cid),
                    changed_display=str(disp),
                )
            )

        if nid and n:
            results.extend(
                apply_principles(
                    changed_node_id=nid,
                    changed_node_kind=n.kind,
                    change_kind="any",
                    manifest_graph=graph,
                    registry_graph=registry_graph,
                    skip_domain_principle=True,
                )
            )

            # imports-edge traversal: callers that directly import the changed node.
            # apply_principles covers belongs_to only; this pass adds ring-1 import callers.
            imports_callers = [
                by_id[e.from_id]
                for e in graph.edges_to(nid)
                if e.relation == "imports" and e.from_id in by_id
            ]
            for caller in imports_callers:
                results.append(
                    PrincipleResult(
                        principle="imports_dependency",
                        changed_node=nid,
                        affected_nodes=[caller.id],
                        severity="warn",
                        reason="imports: direct caller of changed module",
                        ring="ring1",
                        derived=False,
                        metadata={},
                    )
                )

    rules_cfg = _read_change_impact_yaml(project_root)
    overridden = _apply_overrides(results, rules_cfg)
    combined = _combine(overridden)

    affected_nodes = sorted({str(x["node"]) for x in combined})
    summary = {
        "principles_applied": len(overridden),
        "affected_count": len(affected_nodes),
        "affected_nodes": affected_nodes,
        "changed_files_mapped": len([cf for cf in changed_files if find_node_id_for_path(graph, cf)]),
    }
    return ImpactResult(
        changed_files=list(changed_files),
        principle_results=overridden,
        rule_results=[],
        combined=combined,
        exit_code=0,
        graph_summary=summary,
    )


def principle_result_to_dict(result: PrincipleResult) -> dict[str, Any]:
    return asdict(result)


# ── Phase 6.5 — ADR enforcement ───────────────────────────────────────────────
# ADR rules = proactive: run on forge_impact_check call, validate current state.
# Impact rules = reactive: run on diff event (existing compute_impact above).
# Same engine, different trigger — dispatched via run_rules(mode=...).
#
# Enforcement types handled:
#   file_exists    → check enforcement.path exists
#   test           → check enforcement.file exists (test file)
#   manifest_field → check manifest has the required field(s)
#   pending        → skip (not yet enforced; note in result)


@dataclass(frozen=True)
class AdrViolation:
    adr_id: str
    title: str
    enforcement_type: str
    severity: str   # "warn" | "blocker"
    detail: str


@dataclass(frozen=True)
class AdrCheckResult:
    violations: list[AdrViolation]
    skipped: int      # pending / unimplemented enforcement types
    checked: int      # ADRs actually evaluated
    exit_code: int    # 0 = clean, 1 = warnings, 2 = blockers


def _load_adr_registry(project_path: Path) -> list[dict[str, Any]]:
    for p in (
        project_path / "docs" / "adr" / "adr_registry.yaml",
        project_path / "docs" / "adr_registry.yaml",
    ):
        if p.is_file():
            try:
                data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
                return list(data.get("adrs") or []) if isinstance(data, dict) else []
            except Exception:
                return []
    return []


def _load_manifest_for_adr(project_path: Path) -> dict[str, Any]:
    p = resolve_manifest_path(project_path)
    if p is not None and p.is_file():
        try:
            data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            return dict(data) if isinstance(data, dict) else {}
        except Exception:
            return {}
    return {}


def _resolve_path(raw: str, project_path: Path) -> Path:
    """Resolve enforcement path; supports ~ and relative paths."""
    p = Path(raw.replace("~", str(Path.home())))
    if not p.is_absolute():
        p = project_path / p
    return p


def _check_nested_field(obj: dict[str, Any], dotted: str) -> bool:
    """Return True if a dotted field path exists and is not empty in obj."""
    parts = dotted.split(".")
    cur: Any = obj
    for part in parts:
        if not isinstance(cur, dict):
            return False
        cur = cur.get(part)
    return cur is not None and cur != [] and cur != {}


def compute_adr_state(project_path: Path) -> AdrCheckResult:
    """Proactive ADR state check: validates current project against adr_registry.yaml.
    Runs on forge_impact_check call (ADR mode). Does not require a diff."""
    root = project_path.resolve()
    adrs = _load_adr_registry(root)
    manifest = _load_manifest_for_adr(root)

    violations: list[AdrViolation] = []
    skipped = 0
    checked = 0

    for entry in adrs:
        if not isinstance(entry, dict):
            continue
        adr_id = str(entry.get("id") or "")
        title = str(entry.get("title") or "")
        status = str(entry.get("status") or "").lower()

        # Skip superseded or missing ADRs — not actively enforced
        if status in ("superseded", "missing", "draft"):
            skipped += 1
            continue

        enf = entry.get("enforcement")
        if not isinstance(enf, dict):
            skipped += 1
            continue

        enf_type = str(enf.get("type") or "pending").lower()

        if enf_type == "pending":
            skipped += 1
            continue

        checked += 1

        if enf_type == "file_exists":
            raw_path = str(enf.get("path") or "")
            if not raw_path:
                skipped += 1
                checked -= 1
                continue
            target = _resolve_path(raw_path, root)
            if not target.exists():
                deduction = enf.get("deduction")
                sev = "blocker" if not deduction else "warn"
                violations.append(AdrViolation(
                    adr_id=adr_id,
                    title=title,
                    enforcement_type=enf_type,
                    severity=sev,
                    detail=f"Required file missing: {raw_path}",
                ))

        elif enf_type == "test":
            test_file = str(enf.get("file") or "")
            if test_file:
                target = _resolve_path(test_file, root)
                if not target.exists():
                    violations.append(AdrViolation(
                        adr_id=adr_id,
                        title=title,
                        enforcement_type=enf_type,
                        severity="warn",
                        detail=f"Enforcement test file missing: {test_file}",
                    ))
            else:
                skipped += 1
                checked -= 1

        elif enf_type == "manifest_field":
            fields = enf.get("fields") or []
            if isinstance(fields, list):
                for f in fields:
                    if not _check_nested_field(manifest, str(f)):
                        violations.append(AdrViolation(
                            adr_id=adr_id,
                            title=title,
                            enforcement_type=enf_type,
                            severity="warn",
                            detail=f"Manifest field missing or empty: {f}",
                        ))
            else:
                skipped += 1
                checked -= 1

        else:
            # Unknown enforcement type — skip silently
            skipped += 1
            checked -= 1

    has_blocker = any(v.severity == "blocker" for v in violations)
    has_warn = any(v.severity == "warn" for v in violations)
    exit_code = 2 if has_blocker else (1 if has_warn else 0)

    return AdrCheckResult(
        violations=violations,
        skipped=skipped,
        checked=checked,
        exit_code=exit_code,
    )


def run_rules(
    mode: str,
    project_path: Path,
    *,
    changed_files: list[str] | None = None,
    include_ring1: bool = False,
    manifest_data: dict[str, Any] | None = None,
) -> ImpactResult | AdrCheckResult:
    """Unified rule runner.

    mode='impact'  → reactive (diff-event): compute_impact on changed_files
    mode='adr'     → proactive (state-check): compute_adr_state on current project

    Both modes use the same underlying manifest graph. Different triggers only.
    DO NOT merge impact-rules.yaml and change-impact.yaml.
    """
    if mode == "adr":
        return compute_adr_state(project_path)
    # Default: impact mode
    return compute_impact(
        changed_files=list(changed_files or []),
        project_path=project_path,
        include_ring1=include_ring1,
        manifest_data=manifest_data,
    )
