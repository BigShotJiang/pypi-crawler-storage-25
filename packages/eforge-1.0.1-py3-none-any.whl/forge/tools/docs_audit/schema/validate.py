from __future__ import annotations

from pathlib import Path

from forge.tools.docs_audit.contracts.models import ValidationResult
from forge.tools.docs_audit.loaders.yaml_loader import load_yaml


def _validate_required(path: str, required: list[str]) -> ValidationResult:
    data = load_yaml(path)
    errors: list[str] = []
    if not Path(path).exists():
        return ValidationResult(ok=False, errors=[f"file missing: {path}"])
    for key in required:
        if key not in data:
            errors.append(f"missing required key `{key}` in {path}")
    return ValidationResult(ok=len(errors) == 0, errors=errors)


def validate_change_impact(path: str) -> ValidationResult:
    res = _validate_required(path, ["schema_version", "version", "name", "change_types"])
    if not res.ok:
        return res
    data = load_yaml(path)
    errors = list(res.errors)
    if not isinstance(data.get("change_types"), list):
        errors.append("`change_types` must be a list")
    else:
        for i, rule in enumerate(data["change_types"]):
            if not isinstance(rule, dict):
                errors.append(f"change_types[{i}] must be object")
                continue
            for key in ("id", "severity", "triggers", "requires"):
                if key not in rule:
                    errors.append(f"change_types[{i}] missing `{key}`")
            if "checks" in rule:
                chk = rule["checks"]
                if chk is None:
                    errors.append(f"change_types[{i}] `checks` must be a list when present")
                elif not isinstance(chk, list):
                    errors.append(f"change_types[{i}] `checks` must be a list")
                else:
                    for j, c in enumerate(chk):
                        if not isinstance(c, dict):
                            errors.append(f"change_types[{i}].checks[{j}] must be object")
                        elif not str(c.get("type", "")).strip():
                            errors.append(f"change_types[{i}].checks[{j}] missing non-empty `type`")
            if "severity" in rule and rule["severity"] not in {"blocker", "high", "normal", "warn", "warning"}:
                errors.append(f"change_types[{i}] invalid severity `{rule['severity']}`")
    ck = data.get("change_kinds")
    if ck is not None:
        if not isinstance(ck, list):
            errors.append("`change_kinds` must be a list when present")
        else:
            for i, row in enumerate(ck):
                if not isinstance(row, dict):
                    errors.append(f"change_kinds[{i}] must be object")
                    continue
                for key in ("id", "description", "severity"):
                    if key not in row:
                        errors.append(f"change_kinds[{i}] missing `{key}`")
                sev = row.get("severity")
                if sev is not None and str(sev) not in {"blocker", "warn", "info", "warning"}:
                    errors.append(f"change_kinds[{i}] invalid severity `{sev}`")
                tr = row.get("triggers")
                if tr is not None and not isinstance(tr, dict):
                    errors.append(f"change_kinds[{i}] `triggers` must be an object when present")
                tv = row.get("traverse")
                if tv is not None and not isinstance(tv, list):
                    errors.append(f"change_kinds[{i}] `traverse` must be a list when present")
    return ValidationResult(ok=len(errors) == 0, errors=errors)


def validate_manifest(path: str) -> ValidationResult:
    if not Path(path).exists():
        return ValidationResult(ok=False, errors=[f"file missing: {path}"])
    data = load_yaml(path)
    errors: list[str] = []

    shape_a = all(k in data for k in ("schema_version", "name", "type", "version"))
    app = data.get("app")
    shape_b = isinstance(app, dict) and all(k in app for k in ("name", "version", "type"))

    if shape_a:
        if not isinstance(data.get("schema_version"), int):
            errors.append("`schema_version` must be integer")
        return ValidationResult(ok=len(errors) == 0, errors=errors)

    if shape_b:
        for k in ("name", "version", "type"):
            v = app.get(k)
            if v is None or (isinstance(v, str) and not v.strip()):
                errors.append(f"app.{k} must be present and non-empty")
            elif isinstance(v, bool):
                errors.append(f"app.{k} must be a string or numeric version")
            elif not isinstance(v, (str, int, float)):
                errors.append(f"app.{k} must be a string or numeric version")
        return ValidationResult(ok=len(errors) == 0, errors=errors)

    errors.append(
        "manifest must use either top-level keys schema_version, name, type, and version, "
        "or an `app:` block with name, version, and type"
    )
    return ValidationResult(ok=False, errors=errors)

