from __future__ import annotations

import json
import logging
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Iterator, Mapping

import yaml

from forge.tools.scaffold.template_validation import validate_template_extensions
from forge.tools.intent.runtime import (
    IntentRecord,
    declaration_domain_for_intent,
    pipeline_intent_domain,
)
from forge.tools.manifest.graph import build_manifest_graph, resolve_manifest_node
from forge.tools.scaffold.scaffolder import (
    ScaffoldError,
    apply_template_conditionals,
    collect_template_inputs,
    parse_template_inputs,
    render_template_wiring,
)

log = logging.getLogger(__name__)

_VALID_TIERS = frozenset({"nodes", "features", "implementations"})
_L1_FIELDS = ("id", "kind", "stack", "tier", "description")


def gloves_templates_root() -> Path:
    """``forge/gloves`` — sibling of ``forge/commands``."""
    return Path(__file__).resolve().parents[2] / "gloves"


def resolve_schema_yaml_path(project_root: Path | str) -> Path:
    """Prefer ``<project>/.forge/schema.yaml``; fall back to forge repo checkout."""
    root = Path(str(project_root)).expanduser().resolve()
    cand = root / ".forge" / "schema.yaml"
    if cand.is_file():
        return cand
    repo = Path(__file__).resolve().parents[3]
    fb = repo / ".forge" / "schema.yaml"
    if fb.is_file():
        return fb
    return cand


def load_schema_templates_section(project_root: Path | str) -> dict[str, Any]:
    path = resolve_schema_yaml_path(project_root)
    if not path.is_file():
        return {}
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(raw, dict):
        return {}
    tpl = raw.get("templates")
    return tpl if isinstance(tpl, dict) else {}


def iter_template_yaml_paths() -> Iterator[tuple[Path, str]]:
    root = gloves_templates_root()
    if not root.is_dir():
        return
    for glove_dir in sorted(root.iterdir()):
        if not glove_dir.is_dir():
            continue
        tpl_root = glove_dir / "templates"
        if not tpl_root.is_dir():
            continue
        for tier in sorted(_VALID_TIERS):
            d = tpl_root / tier
            if not d.is_dir():
                continue
            for path in sorted(d.glob("*.yaml")):
                yield path, tier


def _load_yaml_mapping(path: Path) -> dict[str, Any] | None:
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError):
        return None
    if not isinstance(raw, dict):
        return None
    return raw


def validate_one_template(data: dict[str, Any], path: Path) -> list[str]:
    errs: list[str] = []
    req_str = ("schema_version", "id", "kind", "stack", "tier", "description")
    for k in req_str:
        v = data.get(k)
        if v is None or (isinstance(v, str) and not v.strip()):
            errs.append(f"missing or empty required field: {k}")
    sf = data.get("spec_fields")
    if not isinstance(sf, list) or not sf or not all(isinstance(x, str) and x.strip() for x in sf):
        errs.append("spec_fields must be a non-empty list of non-empty strings")
    tier = str(data.get("tier") or "")
    if tier not in _VALID_TIERS:
        errs.append(f"tier must be one of {sorted(_VALID_TIERS)}")
    for opt in ("conventions", "produces", "requires"):
        v = data.get(opt)
        if v is None:
            continue
        if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
            errs.append(f"{opt} must be a list of strings when present")
    tid = str(data.get("id") or "")
    kid = str(data.get("kind") or "")
    stk = str(data.get("stack") or "")
    if tid and kid and stk and tid != f"{kid}.{stk}":
        errs.append(f"id {tid!r} must equal kind.stack ({kid}.{stk})")
    errs.extend(validate_template_extensions(data, path))
    return errs


def _discover_one_template(path_tier: tuple[Path, str]) -> tuple[Path, str, dict[str, Any]]:
    path, tier_dir = path_tier
    data = _load_yaml_mapping(path)
    if data is None:
        return path, tier_dir, {}
    declared = str(data.get("tier") or "").strip()
    eff_tier = declared if declared in _VALID_TIERS else tier_dir
    return path, eff_tier, data


def discover_templates() -> list[tuple[Path, str, dict[str, Any]]]:
    pairs = list(iter_template_yaml_paths())
    if not pairs:
        return []
    max_workers = min(32, len(pairs))
    out: list[tuple[Path, str, dict[str, Any]]] = []
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = [ex.submit(_discover_one_template, pt) for pt in pairs]
        for fut in as_completed(futures):
            out.append(fut.result())
    out.sort(key=lambda x: (str(x[0]), x[1]))
    return out


def validate_all_templates() -> list[tuple[Path, str]]:
    bad: list[tuple[Path, str]] = []
    for path, _tier, data in discover_templates():
        if not data:
            bad.append((path, "unreadable or not a YAML mapping"))
            continue
        for msg in validate_one_template(data, path):
            bad.append((path, msg))
    return bad


def find_template_for_kind_stack(kind: str, stack: str) -> tuple[Path, dict[str, Any]] | None:
    want = f"{kind}.{stack}"
    for path, _t, data in discover_templates():
        if not data:
            continue
        if str(data.get("id") or "") == want:
            return path, data
    return None


def collect_contract_ids_for_node(project_root: Path, node_id: str) -> list[str]:
    try:
        g = build_manifest_graph(project_root.expanduser().resolve())
    except Exception:
        return []
    out: list[str] = []
    for e in g.edges:
        if e.relation != "contract":
            continue
        if e.from_id != node_id and e.to_id != node_id:
            continue
        meta = e.meta or {}
        cid = str(meta.get("contract_id") or "").strip()
        method = str(meta.get("method") or "").strip()
        if cid:
            out.append(cid)
        elif method:
            out.append(f"{e.from_id}->{e.to_id}:{method}")
        else:
            out.append(f"{e.from_id}->{e.to_id}")
    return sorted(set(out))


def template_l1_row(data: dict[str, Any]) -> dict[str, Any]:
    return {k: data.get(k) for k in _L1_FIELDS}


def templates_l0_payload(rows: list[dict[str, Any]]) -> dict[str, Any]:
    by_stack: dict[str, int] = defaultdict(int)
    by_tier: dict[str, int] = defaultdict(int)
    for r in rows:
        sk = str(r.get("stack") or "unknown")
        by_stack[sk] += 1
        tr = str(r.get("tier") or "unknown")
        by_tier[tr] += 1
    return {"count_by_stack": dict(by_stack), "count_by_tier": dict(by_tier)}


def filter_templates(
    rows: list[dict[str, Any]],
    *,
    stack: str | None,
    kind: str | None,
    tier: str | None,
) -> list[dict[str, Any]]:
    out = rows
    if stack:
        out = [r for r in out if str(r.get("stack") or "") == stack]
    if kind:
        out = [r for r in out if str(r.get("kind") or "") == kind]
    if tier:
        out = [r for r in out if str(r.get("tier") or "") == tier]
    return out


def build_emit_spec_bundle(
    *,
    project_root: Path,
    node_id: str,
    node_type: str,
    intent: IntentRecord | Mapping[str, Any],
    template: dict[str, Any] | None,
    template_id: str | None,
    tier: str | None,
    manifest_rel_path: str,
    abs_output_file: str | None,
    template_path: Path | None = None,
    cli_inputs: list[str] | None = None,
    interactive_inputs: bool = False,
) -> dict[str, Any]:
    root = project_root.expanduser().resolve()
    ir: IntentRecord = intent if isinstance(intent, IntentRecord) else IntentRecord.from_mapping(dict(intent))
    node_name = ""
    node_domain = ""
    node_path = manifest_rel_path
    graph = None
    try:
        graph = build_manifest_graph(root)
        node = resolve_manifest_node(graph, node_id)
        if node is not None:
            node_name = node.name or ""
            node_domain = str(node.domain or "")
            node_path = node.path or manifest_rel_path
    except Exception:
        pass
    contracts = collect_contract_ids_for_node(root, node_id)
    dom_from_intent: str | None = pipeline_intent_domain(ir)
    if dom_from_intent is None and graph is not None:
        dom_from_intent = declaration_domain_for_intent(ir, graph)
    spec: dict[str, Any] = {
        "name": node_name or (ir.target_id or _fallback_name(node_id)),
        "domain": node_domain or dom_from_intent or "CORE",
        "path": node_path,
        "contracts": contracts,
    }
    out_path = abs_output_file
    if not out_path and node_path:
        out_path = str((root / node_path).resolve()) if not node_path.startswith("/") else node_path
    collected_inputs: dict[str, Any] = {}
    produces = list(template.get("produces") or []) if template else []
    conditional_injections: list[dict[str, str]] = []
    wiring_rows: list[dict[str, str]] = []
    if template:
        parsed_cli = parse_template_inputs(cli_inputs)
        try:
            collected_inputs = collect_template_inputs(
                template, cli_inputs=parsed_cli, interactive=interactive_inputs
            )
        except ScaffoldError:
            # emit-spec should still work when required scaffold inputs were not provided
            collected_inputs = {}
        glove_stack_dir = template_path.parents[2] if template_path is not None else None
        produces, conditional_injections = apply_template_conditionals(
            template, input_values=collected_inputs, glove_stack_dir=glove_stack_dir
        )
        wiring_rows = render_template_wiring(template, input_values=collected_inputs)

    bundle: dict[str, Any] = {
        "template_id": template_id or "",
        "tier": tier or "",
        "spec": spec,
        "conventions": list(template.get("conventions") or []) if template else [],
        "produces": produces,
        "description": str(template.get("description") or "") if template else "",
        "inputs": collected_inputs,
        "conditionals": conditional_injections,
        "wiring": wiring_rows,
        "output_path": out_path or "",
    }
    return bundle


def _fallback_name(node_id: str) -> str:
    if "/" in node_id:
        return node_id.split("/", 1)[-1]
    return node_id


def dump_emit_spec_json(bundle: dict[str, Any]) -> str:
    return json.dumps(bundle, indent=2)
