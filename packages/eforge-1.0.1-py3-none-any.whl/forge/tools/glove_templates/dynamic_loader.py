"""Dynamic template loader for Forge glove templates.

Replaces static module registration with runtime discovery
and lazy loading of glove templates from YAML files.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass

from forge.core.path_utils import resolve_project_path

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class TemplateMetadata:
    """Metadata for a discovered glove template."""
    id: str
    kind: str
    stack: str
    tier: str
    description: str
    path: Path
    spec_fields: List[str]
    requires: List[str]
    produces: List[str]


class DynamicTemplateRegistry:
    """Dynamic template registry with lazy loading and caching."""
    
    def __init__(self, project_path: Optional[str] = None):
        self.project_path = Path(resolve_project_path(project_path or "."))
        self._template_cache: Dict[str, TemplateMetadata] = {}
        self._discovered = False
        
        # Template search paths
        self.glove_root = self.project_path / "forge" / "gloves"
        
    def _discover_templates(self) -> Dict[str, TemplateMetadata]:
        """Discover all glove templates from filesystem."""
        if self._discovered:
            return self._template_cache
            
        templates = {}
        
        # Search for template directories
        for template_dir in self.glove_root.glob("*/templates/nodes/*.yaml"):
            try:
                template = self._load_template_metadata(template_dir)
                if template:
                    templates[template.id] = template
                    logger.debug(f"Discovered template: {template.id}")
            except Exception as e:
                logger.warning(f"Failed to load template {template_dir}: {e}")
                
        self._template_cache = templates
        self._discovered = True
        
        logger.info(f"Discovered {len(templates)} glove templates")
        return templates
        
    def _load_template_metadata(self, template_path: Path) -> Optional[TemplateMetadata]:
        """Load template metadata from YAML file."""
        try:
            import yaml
            with open(template_path, 'r') as f:
                data = yaml.safe_load(f)
                
            if not data:
                return None
                
            # Extract path components for template ID
            relative_path = template_path.relative_to(self.project_path)
            path_parts = str(relative_path).parts
            
            # Extract template ID from path: forge/gloves/{stack}/templates/nodes/{id}.yaml
            if len(path_parts) >= 5 and path_parts[0] == "forge" and path_parts[1] == "gloves":
                template_id = template_path.stem  # filename without .yaml
                stack = path_parts[2]  # e.g., "web", "deployment", "design-system"
            else:
                return None
                
            return TemplateMetadata(
                id=template_id,
                kind=data.get("kind", "unknown"),
                stack=stack,
                tier=data.get("tier", "nodes"),
                description=data.get("description", ""),
                path=template_path,
                spec_fields=data.get("spec_fields", []),
                requires=data.get("requires", []),
                produces=data.get("produces", [])
            )
        except Exception as e:
            logger.error(f"Failed to parse template {template_path}: {e}")
            return None
            
    def get_template(self, template_id: str) -> Optional[TemplateMetadata]:
        """Get template metadata by ID with lazy loading."""
        templates = self._discover_templates()
        return templates.get(template_id)
        
    def list_templates(self, stack: Optional[str] = None, kind: Optional[str] = None) -> List[TemplateMetadata]:
        """List all templates, optionally filtered by stack/kind."""
        templates = self._discover_templates()
        
        filtered = []
        for template in templates.values():
            if stack and template.stack != stack:
                continue
            if kind and template.kind != kind:
                continue
            filtered.append(template)
            
        return sorted(filtered, key=lambda t: (t.stack, t.kind, t.id))
        
    def get_template_content(self, template_id: str) -> Optional[Dict[str, Any]]:
        """Get full template content (YAML data)."""
        template = self.get_template(template_id)
        if not template:
            return None
            
        try:
            import yaml
            with open(template.path, 'r') as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.error(f"Failed to load template content {template_id}: {e}")
            return None
            
    def reload(self) -> None:
        """Force reload of template discovery."""
        self._discovered = False
        self._template_cache.clear()
        logger.info("Template registry reloaded")
        
    def get_stats(self) -> Dict[str, Any]:
        """Get registry statistics."""
        templates = self._discover_templates()
        
        stacks = {}
        kinds = {}
        
        for template in templates.values():
            stacks[template.stack] = stacks.get(template.stack, 0) + 1
            kinds[template.kind] = kinds.get(template.kind, 0) + 1
            
        return {
            "total_templates": len(templates),
            "stacks": stacks,
            "kinds": kinds,
            "discovered_at": self._discovered
        }


# Global registry instance
_registry: Optional[DynamicTemplateRegistry] = None


def get_template_registry(project_path: Optional[str] = None) -> DynamicTemplateRegistry:
    """Get global template registry instance."""
    global _registry
    if _registry is None:
        _registry = DynamicTemplateRegistry(project_path)
    return _registry


def register_template_resources(server) -> None:
    """Register template-related MCP resources."""
    registry = get_template_registry()
    
    async def list_templates_resource(uri: str) -> str:
        """Handle forge://templates/list requests."""
        try:
            # Parse query parameters
            if "?" in uri:
                path_part, params_str = uri.split("?", 1)
                params = parse_query_params(params_str)
            else:
                path_part = uri[20:]  # Remove "forge://templates/"
                params = {}
                
            if path_part == "list":
                stack = params.get("stack")
                kind = params.get("kind")
                templates = registry.list_templates(stack, kind)
                
                result = {
                    "templates": [
                        {
                            "id": t.id,
                            "kind": t.kind,
                            "stack": t.stack,
                            "tier": t.tier,
                            "description": t.description,
                            "spec_fields": t.spec_fields,
                            "requires": t.requires,
                            "produces": t.produces
                        }
                        for t in templates
                    ],
                    "filters_applied": {"stack": stack, "kind": kind},
                    "total_count": len(templates)
                }
                return json.dumps(result, indent=2)
                
            elif path_part == "get":
                template_id = params.get("id")
                if not template_id:
                    return json.dumps({"error": "Template ID required"}, indent=2)
                    
                template = registry.get_template_content(template_id)
                if template:
                    return json.dumps(template, indent=2)
                else:
                    return json.dumps({"error": f"Template {template_id} not found"}, indent=2)
                    
            elif path_part == "stats":
                stats = registry.get_stats()
                return json.dumps(stats, indent=2)
                
            else:
                return json.dumps({"error": f"Unknown template resource: {path_part}"}, indent=2)
                
        except Exception as e:
            logger.error(f"Template resource error: {e}")
            return json.dumps({"error": str(e)}, indent=2)
    
    # Register template resources
    server.list_resources({
        "forge://templates/list": "List all available glove templates",
        "forge://templates/get": "Get specific template by ID", 
        "forge://templates/stats": "Template registry statistics"
    })
    
    server.read_resource("forge://templates", list_templates_resource)


def parse_query_params(params_str: str) -> Dict[str, str]:
    """Parse URL query parameters."""
    params = {}
    for pair in params_str.split("&"):
        if "=" in pair:
            key, value = pair.split("=", 1)
            params[key] = value
    return params
