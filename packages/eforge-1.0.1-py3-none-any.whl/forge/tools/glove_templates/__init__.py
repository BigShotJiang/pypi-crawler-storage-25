"""Glove-colocated YAML template registry (discovered under forge/gloves/*/templates/)."""

from forge.tools.glove_templates.registry import (
    collect_contract_ids_for_node,
    discover_templates,
    find_template_for_kind_stack,
    gloves_templates_root,
    load_schema_templates_section,
    resolve_schema_yaml_path,
    validate_all_templates,
    validate_one_template,
)

__all__ = [
    "collect_contract_ids_for_node",
    "discover_templates",
    "find_template_for_kind_stack",
    "gloves_templates_root",
    "load_schema_templates_section",
    "resolve_schema_yaml_path",
    "validate_all_templates",
    "validate_one_template",
]
