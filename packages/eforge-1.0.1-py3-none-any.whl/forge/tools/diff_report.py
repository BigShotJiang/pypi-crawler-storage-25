from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
import re
from typing import Any

import shutil
import subprocess

from forge.core.execution_graph import ExecutionGraph, ExecutionNode
from forge.core.gloves import GLOVES, RawEdge, RawNode
from forge.core.glove_mapper import GloveMapper, promote_edges as promote_manifest_import_edges
from forge.core.manifest import ManifestParser
from forge.core.manifest_path import resolve_manifest_path
import forge.core.query as _core_query
from forge.tools.manifest.graph import ManifestGraph, ManifestNode, build_manifest_graph

_DECL_KINDS = {"screen", "controller", "service", "module", "component", "model", "command"}
_AUTO_CAPTURE_MAX = 200


@dataclass
class DiffReport:
    project_id: str
    stack: str
    glove_used: str
    declaration_nodes: int
    glove_nodes: int
    dark_matter: list[RawNode]
    ghost_nodes: list[str]
    missing_edges: list[RawEdge]
    naming_mismatches: list[dict[str, Any]]
    error_code_drift: dict[str, Any]
    parity_pairs: dict[str, Any]
    generated_at: str
    annotations_captured: dict[str, Any] | None = None
    execution_diff: dict[str, Any] | None = None
    contract_violations: dict[str, Any] | None = None
    edge_promotion: dict[str, Any] | None = None
    schema_dep_drift: dict[str, Any] | None = None

    def to_jsonable(self) -> dict[str, Any]:
        out = {
            "project_id": self.project_id,
            "stack": self.stack,
            "glove_used": self.glove_used,
            "declaration_nodes": self.declaration_nodes,
            "glove_nodes": self.glove_nodes,
            "dark_matter": [asdict(n) for n in self.dark_matter],
            "ghost_nodes": list(self.ghost_nodes),
            "missing_edges": [asdict(e) for e in self.missing_edges],
            "naming_mismatches": list(self.naming_mismatches),
            "error_code_drift": dict(self.error_code_drift),
            "parity_pairs": dict(self.parity_pairs),
            "generated_at": self.generated_at,
            "annotations_captured": self.annotations_captured or {"captured": 0, "skipped_duplicates": 0, "ids": []},
            "schema_dep_drift": dict(self.schema_dep_drift or {"findings": [], "total": 0}),
        }
        if self.execution_diff is not None:
            out["execution_diff"] = dict(self.execution_diff)
        if self.contract_violations is not None:
            out["contract_violations"] = dict(self.contract_violations)
        if self.edge_promotion is not None:
            out["edge_promotion"] = dict(self.edge_promotion)
        return out


@dataclass
class DiffFinding:
    kind: str
    severity: str
    message: str
    node: str
    related: str | None = None
    file: str | None = None


def _domain_reachable_node_ids(graph: ManifestGraph, domain_upper: str) -> set[str]:
    """Cycle-safe domain traversal over graph edges starting at domain members."""
    seeds = {
        n.id
        for n in graph.nodes
        if (n.domain or "").strip().upper() == domain_upper
    }
    if not seeds:
        return set()
    visited: set[str] = set()
    frontier = list(seeds)

    def _edges_from(node_id: str) -> list[Any]:
        edges_from_fn = getattr(graph, "edges_from", None)
        if callable(edges_from_fn):
            return list(edges_from_fn(node_id))
        return [e for e in getattr(graph, "edges", []) if getattr(e, "from_id", None) == node_id]

    def _edges_to(node_id: str) -> list[Any]:
        edges_to_fn = getattr(graph, "edges_to", None)
        if callable(edges_to_fn):
            return list(edges_to_fn(node_id))
        return [e for e in getattr(graph, "edges", []) if getattr(e, "to_id", None) == node_id]

    while frontier:
        nid = frontier.pop()
        if nid in visited:
            continue
        visited.add(nid)
        for e in _edges_from(nid):
            if e.to_id not in visited:
                frontier.append(e.to_id)
        for e in _edges_to(nid):
            if e.from_id not in visited:
                frontier.append(e.from_id)
    return visited


def _schema_declared_field_names(schema_node: ManifestNode) -> set[str]:
    m = schema_node.meta or {}
    raw_fields = m.get("fields")
    out: set[str] = set()
    if isinstance(raw_fields, list):
        for f in raw_fields:
            if isinstance(f, dict):
                n = f.get("name") or f.get("field")
                if n:
                    out.add(str(n))
            elif isinstance(f, str) and f.strip():
                out.add(f.strip())
    return out


def _check_schema_deps(graph: ManifestGraph, node: ManifestNode) -> list[dict[str, Any]]:
    """For service nodes with ``schema_deps`` declared, validate schema nodes and field coverage."""
    deps = (node.meta or {}).get("schema_deps", []) if node.meta else []
    if not isinstance(deps, list):
        return []
    findings: list[dict[str, Any]] = []
    by_id = {n.id: n for n in graph.nodes}
    for dep in deps:
        if not isinstance(dep, dict):
            continue
        table = str(dep.get("table") or "").strip()
        if not table:
            continue
        fields_raw = dep.get("fields") or []
        fields_list = [str(x) for x in fields_raw] if isinstance(fields_raw, list) else []
        schema_node_id = f"schema/{table}"
        schema_node = by_id.get(schema_node_id)
        if schema_node is None:
            findings.append({
                "drift_type": "schema_dep_undeclared",
                "node": node.id,
                "table": table,
                "fields": fields_list,
                "detail": (
                    f"service accesses {table}.{fields_list} but no declaration graph node {schema_node_id}"
                ),
            })
            continue
        declared = _schema_declared_field_names(schema_node)
        if not declared:
            continue
        missing = [fn for fn in fields_list if fn not in declared]
        if missing:
            findings.append({
                "drift_type": "schema_dep_field_missing",
                "node": node.id,
                "table": table,
                "fields": missing,
                "detail": f"service accesses {table}.{missing} not listed on {schema_node_id}",
            })
    return findings


def _collect_schema_dep_findings(graph: ManifestGraph) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for n in graph.nodes:
        if getattr(n, "kind", None) != "service":
            continue
        out.extend(_check_schema_deps(graph, n))
    return out


def _normalize_path(p: str | None) -> str:
    if not p:
        return ""
    norm = str(p).replace("\\", "/")
    if norm.startswith("./"):
        norm = norm[2:]
    return norm


def _slug(s: str) -> str:
    return "".join(ch for ch in s.lower() if ch.isalnum())


def _decl_matches_glove_name(decl_name: str, glove_name: str) -> bool:
    """True if a manifest node name matches a glove class (handles ``core.AppConfig`` vs ``AppConfig``)."""
    if _slug(decl_name) == _slug(glove_name):
        return True
    if "." in decl_name:
        tail = decl_name.rsplit(".", 1)[-1]
        if _slug(tail) == _slug(glove_name):
            return True
    return False


def _infer_name_slug_from_file(path: str) -> str:
    stem = Path(path).stem.lower()
    for suffix in ("_screen", "_controller", "_service", "_widget", "_model"):
        if stem.endswith(suffix):
            stem = stem[: -len(suffix)]
            break
    return _slug(stem)


def _run_stack_verify(project_path: Path) -> None:
    """Run ``forge verify --scope stack`` in a subprocess (avoids import cycles with ``forge.cli``)."""
    root = project_path.expanduser().resolve()
    forge_exe = shutil.which("forge")
    if not forge_exe:
        raise RuntimeError(
            "forge executable not found on PATH — cannot run stack verify after edge promotion"
        )
    proc = subprocess.run(
        [forge_exe, "verify", "--scope", "stack", "--project-path", str(root)],
        capture_output=True,
        text=True,
        cwd=str(root),  # cwd required — tool may be called from any working directory
    )
    if proc.returncode != 0:
        out = (proc.stdout or "") + (proc.stderr or "")
        raise RuntimeError(f"forge verify --scope stack failed (exit {proc.returncode}): {out}")


def _declared_path_exists(root: Path, path: str | None) -> bool:
    rel = _normalize_path(path)
    if not rel:
        return False
    return (root / rel).is_file()


def _resolve_stack_key(project_path: Path) -> str:
    if (project_path / "pubspec.yaml").is_file() and (project_path / "lib").is_dir():
        return "dart"
    if (project_path / "pyproject.toml").is_file():
        return "python"
    p = resolve_manifest_path(project_path)
    if p is not None:
        parsed = ManifestParser(p).parse()
        if not parsed.ok or not isinstance(parsed.value, dict):
            return "python"
        data = parsed.value
        t = str(data.get("type") or "").strip().lower()
        if t == "python":
            return "python"
        if t in ("flutter", "flutter-app"):
            return "dart"
        if t in ("web", "react", "web-next", "web-react"):
            return "react"
        st = data.get("stack")
        if isinstance(st, dict):
            lang = str(st.get("language") or "").strip().lower()
            if lang in ("python", "dart", "react", "sql"):
                return lang
    return "python"


_ERROR_CODE_RE = re.compile(r"\b([A-Z][A-Z0-9_]+-\d{3})\b")
_ERROR_CONST_RE = re.compile(r"\b(ERROR_[A-Z0-9_]+)\b")
_DOMAIN_ERROR_CODE_RE = re.compile(r"^[A-Z]{2,8}-\d{3}$")
_EXCLUDED_ERROR_CODE_PREFIXES = ("ADR-", "ANNOT-", "PIX-ADR-", "LOS-ADR-", "CON-")


def _code_files_for_stack(root: Path, stack_key: str) -> list[Path]:
    if stack_key == "dart":
        return sorted(root.rglob("*.dart"))
    if stack_key == "react":
        return sorted([*root.rglob("*.ts"), *root.rglob("*.tsx"), *root.rglob("*.js"), *root.rglob("*.jsx")])
    return sorted(root.rglob("*.py"))


def _extract_error_refs(text: str) -> set[str]:
    out = set(_ERROR_CODE_RE.findall(text))
    out.update(_ERROR_CONST_RE.findall(text))
    return out


def _looks_like_error_code(code: str) -> bool:
    if any(code.startswith(prefix) for prefix in _EXCLUDED_ERROR_CODE_PREFIXES):
        return False
    return bool(_DOMAIN_ERROR_CODE_RE.match(code))


def _error_code_drift(root: Path, stack_key: str, manifest_graph: Any) -> dict[str, Any]:
    storage_path = ""
    for node in manifest_graph.nodes:
        if node.kind == "error_codes":
            storage_path = node.path or ""
            break
    storage_file: Path | None = None
    declared: set[str] = set()
    if storage_path:
        storage_file = (root / storage_path).resolve()
        if storage_file.is_file():
            declared = _extract_error_refs(storage_file.read_text(encoding="utf-8", errors="ignore"))
    if storage_file is None or not storage_file.is_file():
        fallback = root / "docs" / "ERROR_CODES.md"
        if fallback.is_file():
            storage_file = fallback
            declared = _extract_error_refs(fallback.read_text(encoding="utf-8", errors="ignore"))
    if (root / "forge" / "core" / "schemas.py").is_file():
        try:
            from forge.core.schemas import FORGE_ERROR_REGISTRY

            declared.update(FORGE_ERROR_REGISTRY.keys())
        except Exception:
            pass
    if (storage_file is None or not storage_file.is_file()) and not declared:
        return {
            "skipped": True,
            "reason": "no error code registry found",
            "unregistered": 0,
            "orphaned": 0,
            "format_mismatches": 0,
            "findings": [],
        }
    referenced: set[str] = set()
    for f in _code_files_for_stack(root, stack_key):
        rel = _normalize_path(str(f.relative_to(root)))
        if storage_path and rel == _normalize_path(storage_path):
            continue
        referenced.update(_extract_error_refs(f.read_text(encoding="utf-8", errors="ignore")))
    referenced_codes = {code for code in referenced if _looks_like_error_code(code)}
    declared_codes = {code for code in declared if _looks_like_error_code(code)}
    unregistered = sorted(referenced_codes - declared_codes)
    orphaned = sorted(declared_codes - referenced_codes)
    format_mismatches = sorted(
        code for code in referenced if "-" in code and not _looks_like_error_code(code)
    )
    findings: list[dict[str, Any]] = []
    findings.extend(
        {
            "kind": "error-code-unregistered",
            "severity": "warning",
            "code": code,
            "message": f"Referenced error code not in registry: {code}",
        }
        for code in unregistered
    )
    findings.extend(
        {
            "kind": "error-code-orphan",
            "severity": "info",
            "code": code,
            "message": f"Registry error code not referenced by any node: {code}",
        }
        for code in orphaned
    )
    findings.extend(
        {
            "kind": "error-code-format-mismatch",
            "severity": "warning",
            "code": code,
            "message": f"Error code format mismatch against registry contract: {code}",
        }
        for code in format_mismatches
    )
    return {
        "skipped": False,
        "unregistered": len(unregistered),
        "orphaned": len(orphaned),
        "format_mismatches": len(format_mismatches),
        "findings": findings,
        "referenced_not_declared": unregistered,
        "declared_not_referenced": orphaned,
    }


def _check_parity_pairs(graph: Any, project_path: Path) -> tuple[int, int, int, list[DiffFinding]]:
    from forge.cli.verify import _get_file_timestamp

    node_by_id = {str(n.id): n for n in graph.nodes}
    node_by_path = {_normalize_path(str(getattr(n, "path", "") or "")): n for n in graph.nodes if _normalize_path(str(getattr(n, "path", "") or ""))}
    checked = 0
    gaps = 0
    stale = 0
    findings: list[DiffFinding] = []

    seen_pairs: set[tuple[str, str]] = set()
    for edge in graph.edges:
        if str(getattr(edge, "relation", "")) != "parity":
            continue
        pair = tuple(sorted([str(edge.from_id), str(edge.to_id)]))
        if pair in seen_pairs:
            continue
        seen_pairs.add(pair)
        checked += 1
        left = node_by_id.get(str(edge.from_id))
        right = node_by_id.get(str(edge.to_id))
        if not left or not right:
            gaps += 1
            missing = str(edge.to_id) if left and not right else str(edge.from_id)
            findings.append(
                DiffFinding(
                    kind="parity-gap",
                    severity="high",
                    message=f"parity gap: missing node {missing}",
                    node=str(edge.from_id),
                    related=str(edge.to_id),
                )
            )
            continue
        left_path = _normalize_path(str(getattr(left, "path", "") or ""))
        right_path = _normalize_path(str(getattr(right, "path", "") or ""))
        if not left_path or not right_path:
            continue
        ts_left = _get_file_timestamp(project_path / left_path, repo_root=project_path)
        ts_right = _get_file_timestamp(project_path / right_path, repo_root=project_path)
        if ts_left and ts_right and ts_left != ts_right:
            stale += 1
            findings.append(
                DiffFinding(
                    kind="stale-parity",
                    severity="medium",
                    message=f"parity drift: {edge.from_id} and {edge.to_id} are out of sync",
                    node=str(edge.from_id),
                    related=str(edge.to_id),
                )
            )

    for node in graph.nodes:
        source_glob = str((getattr(node, "meta", {}) or {}).get("parity_source") or "").strip()
        if not source_glob:
            continue
        checked += 1
        source_path = _normalize_path(str(getattr(node, "path", "") or ""))
        ts_source = (
            _get_file_timestamp(project_path / source_path, repo_root=project_path)
            if source_path
            else None
        )
        for match in sorted(project_path.glob(source_glob)):
            if not match.is_file():
                continue
            rel = _normalize_path(str(match.relative_to(project_path)))
            target = node_by_path.get(rel)
            if target is None:
                gaps += 1
                findings.append(
                    DiffFinding(
                        kind="parity-gap",
                        severity="high",
                        message=f"parity gap: {node.id} parity source missing node for {rel}",
                        node=str(node.id),
                        related=None,
                        file=rel,
                    )
                )
                continue
            target_path = _normalize_path(str(getattr(target, "path", "") or ""))
            ts_target = (
                _get_file_timestamp(project_path / target_path, repo_root=project_path)
                if target_path
                else None
            )
            if ts_source and ts_target and ts_source != ts_target:
                stale += 1
                findings.append(
                    DiffFinding(
                        kind="stale-parity",
                        severity="medium",
                        message=f"parity drift: {node.id} is out of sync with {target.id}",
                        node=str(node.id),
                        related=str(target.id),
                        file=target_path,
                    )
                )
    return checked, gaps, stale, findings


def _path_under_project(root: Path, path_str: str) -> str:
    if not path_str:
        return ""
    try:
        p = Path(path_str).expanduser().resolve()
        return _normalize_path(str(p.relative_to(root)))
    except Exception:
        return ""


def _match_execution_node_to_declaration_id(
    graph: ManifestGraph,
    en: ExecutionNode,
    root: Path,
) -> str | None:
    """Resolve an execution node to a declaration module id via ``forge_query`` (name + path)."""
    rel = _path_under_project(root, en.file)
    stem = Path(rel).stem if rel else ""
    hint = (stem or (en.module.rsplit(".", 1)[-1] if en.module else "")).strip()
    if not hint:
        return None
    qr = _core_query.forge_query(
        graph,
        kind="module",
        where={"name": hint},
        limit=50,
        depth=1,
    )
    rows = qr.data.get("nodes") or []
    if not isinstance(rows, list) or not rows:
        return None
    for row in rows:
        if not isinstance(row, dict):
            continue
        row_path = _normalize_path(str(row.get("path") or ""))
        if rel and row_path and row_path == rel:
            nid = str(row.get("id") or "")
            return nid or None
    hint_l = hint.lower()
    for row in rows:
        if not isinstance(row, dict):
            continue
        if str(row.get("name") or "").lower() == hint_l:
            nid = str(row.get("id") or "")
            return nid or None
    first = rows[0]
    if isinstance(first, dict):
        return str(first.get("id") or "") or None
    return None


def _compute_execution_diff(root: Path, graph: Any, execution_graph: ExecutionGraph | None) -> dict[str, Any]:
    if execution_graph is None:
        from forge.tools.trace_store import latest_trace_file

        if latest_trace_file(root) is None:
            return {"skipped": True, "reason": "no trace file in .forge/traces/"}
        return {"skipped": True, "reason": "invalid trace payload"}

    eg = execution_graph

    decl_paths: dict[str, list[str]] = {}
    for n in graph.nodes:
        rel = _normalize_path(str(getattr(n, "path", "") or ""))
        if not rel:
            continue
        decl_paths.setdefault(rel, []).append(str(n.id))

    traced_paths: set[str] = set()
    path_to_nodes: dict[str, list[str]] = {}
    for n in eg.nodes.values():
        rel = _path_under_project(root, n.file)
        if rel:
            traced_paths.add(rel)
            path_to_nodes.setdefault(rel, []).append(n.id)

    declared_paths = set(decl_paths.keys())
    execution_only_paths = sorted(traced_paths - declared_paths)
    unreached_paths = sorted(declared_paths - traced_paths)

    import_edges = {
        (str(e.from_id), str(e.to_id)) for e in graph.edges if str(getattr(e, "relation", "")) == "imports"
    }

    def primary_mod(rel: str) -> str | None:
        ids = decl_paths.get(rel)
        if ids:
            return ids[0]
        return None

    implicit: list[dict[str, Any]] = []
    for edge in eg.edges.values():
        cn = eg.nodes.get(edge.from_id)
        tn = eg.nodes.get(edge.to_id)
        if not cn or not tn:
            continue
        cr = _path_under_project(root, cn.file)
        tr = _path_under_project(root, tn.file)
        if not cr or not tr or cr == tr:
            continue
        mid_from = primary_mod(cr)
        mid_to = primary_mod(tr)
        if not mid_from or not mid_to or mid_from == mid_to:
            continue
        if (mid_from, mid_to) not in import_edges:
            implicit.append(
                {
                    "kind": "implicit-dependency",
                    "severity": "info",
                    "from_module": mid_from,
                    "to_module": mid_to,
                    "via_call": f"{edge.from_id} → {edge.to_id}",
                }
            )

    matched_pairs: list[dict[str, Any]] = []
    if isinstance(graph, ManifestGraph):
        unmatched_exec_ids: list[str] = []
        for en in eg.nodes.values():
            decl_id = _match_execution_node_to_declaration_id(graph, en, root)
            if decl_id:
                matched_pairs.append(
                    {
                        "execution_node_id": en.id,
                        "declaration_node_id": decl_id,
                        "path": _path_under_project(root, en.file),
                    }
                )
            else:
                unmatched_exec_ids.append(en.id)
        exec_only_ids = sorted(set(unmatched_exec_ids))
    else:
        exec_only_ids = sorted({nid for rel in execution_only_paths for nid in path_to_nodes.get(rel, [])})

    findings: list[dict[str, Any]] = []
    for nid in exec_only_ids:
        findings.append({"kind": "execution-only", "severity": "info", "node_id": nid})
    for rel in unreached_paths:
        for mid in decl_paths.get(rel, []):
            findings.append(
                {
                    "kind": "declared-not-reached",
                    "severity": "info",
                    "module_id": mid,
                    "path": rel,
                }
            )
    findings.extend(implicit)

    return {
        "skipped": False,
        "trace_entry": eg.entry_point,
        "counts": {
            "execution_nodes": len(eg.nodes),
            "execution_edges": len(eg.edges),
            "execution_only_paths": len(execution_only_paths),
            "declared_paths_not_reached": len(unreached_paths),
            "implicit_dependency_calls": len(implicit),
        },
        "execution_only_paths": execution_only_paths,
        "declared_paths_not_reached": unreached_paths,
        "findings": findings,
        "matched": matched_pairs,
        "unmatched_execution": exec_only_ids,
    }


def _execution_diff_for_layer(eff_layer: str, root: Path, graph: Any) -> dict[str, Any]:
    if eff_layer == "declaration":
        return {"skipped": True, "reason": "declaration layer only"}
    from forge.tools.trace_store import load_latest_trace

    return _compute_execution_diff(root, graph, load_latest_trace(root))


def _compute_contract_violations(root: Path, stack_key: str, glove: Any, graph: Any) -> dict[str, Any]:
    from forge.core.temporal_triangulation import (
        TemporalTriangulationInput,
        triangulate_temporal_contracts,
    )
    from forge.tools.contract_checker import (
        async_boundary_rows,
        check_contracts,
        contract_drift_rows,
        contract_registry,
    )

    contracts: dict[str, list[Any]] = {}
    if not hasattr(glove, "extract_contracts"):
        return {"total": 0, "by_severity": {"error": 0, "warning": 0}, "findings": []}
    for n in glove.extract_nodes(root):
        try:
            rows = glove.extract_contracts(n)
        except Exception:
            rows = []
        if rows:
            contracts[n.id] = rows
    try:
        graph_with_contracts = build_manifest_graph(root, contracts=contracts)
    except TypeError:
        graph_with_contracts = graph
    if isinstance(graph_with_contracts, ManifestGraph):
        _probe = _core_query.forge_query(
            graph_with_contracts,
            kind="",
            where={},
            limit=10**9,
            depth=1,
            direction="both",
        )
        decl_node_count = int(_probe.data.get("count", 0))
    else:
        decl_node_count = len(getattr(graph_with_contracts, "nodes", []))
    violations = check_contracts(graph_with_contracts, contracts, execution_graph=None)
    by_sev = {"error": 0, "warning": 0}
    for v in violations:
        by_sev[v.severity] = by_sev.get(v.severity, 0) + 1
    registry_rows = contract_registry(graph_with_contracts, contracts)
    drift_rows = contract_drift_rows(graph_with_contracts, contracts)
    async_rows = async_boundary_rows(graph_with_contracts, execution_graph=None)
    temporal = triangulate_temporal_contracts(
        TemporalTriangulationInput(
            declaration_graph={
                "nodes": decl_node_count,
                "edges": len(getattr(graph_with_contracts, "edges", [])),
            },
            execution_graph={"nodes": 0, "edges": 0},
            intent_graph=None,
        )
    )
    return {
        "total": len(violations),
        "by_severity": by_sev,
        "findings": [asdict(v) for v in violations],
        "contract_registry": [r.to_jsonable() for r in registry_rows],
        "contract_drift": drift_rows,
        "async_boundaries": async_rows,
        "temporal_triangulation": asdict(temporal),
    }


def build_diff_report(
    project_path: Path,
    *,
    scope: str = "repo",
    scope_target: str | None = None,
    layer: str = "declaration",
    dry_run: bool = False,
    promote_edges: bool = False,
) -> DiffReport:
    root = project_path.expanduser().resolve()
    graph = build_manifest_graph(root)
    if isinstance(graph, ManifestGraph):
        schema_dep_findings = _collect_schema_dep_findings(graph)
        schema_dep_payload: dict[str, Any] = {"findings": schema_dep_findings, "total": len(schema_dep_findings)}
        decl_ids: set[str] = set()
        for k in _DECL_KINDS:
            qr = _core_query.forge_query(graph, kind=k, where={}, limit=10**9, depth=1, direction="both")
            decl_ids.update(
                str(row["id"])
                for row in qr.data.get("nodes", [])
                if isinstance(row, dict) and row.get("id")
            )
        declaration_nodes = [n for n in graph.nodes if n.id in decl_ids]
    else:
        schema_dep_payload = {"findings": [], "total": 0}
        declaration_nodes = [n for n in graph.nodes if getattr(n, "kind", None) in _DECL_KINDS]
    stack_key = _resolve_stack_key(root)
    glove = GLOVES.get(stack_key)
    if glove is None:
        raise ValueError(f"No glove registered for stack '{stack_key}'")

    eff_layer = (layer or "declaration").strip().lower()
    if eff_layer not in ("declaration", "execution", "all"):
        eff_layer = "declaration"

    effective_scope = (scope or "repo").strip().lower()
    glove_nodes = [n for n in glove.extract_nodes(root) if n.kind in _DECL_KINDS]
    glove_edges = glove.extract_edges(root)
    dart_mapper: GloveMapper | None = None
    dart_manifest_path: Path | None = None
    if stack_key == "dart":
        for candidate in (root / ".forge" / "manifest.yaml", root / "manifest.yaml"):
            if candidate.is_file():
                dart_manifest_path = candidate
                break
        if dart_manifest_path is not None:
            dart_mapper = GloveMapper(dart_manifest_path, project_root=root)
            edges_for_diff = dart_mapper.map_edges(glove_edges, edge_kinds=frozenset({"imports"}))
        else:
            edges_for_diff = glove_edges
    else:
        edges_for_diff = glove_edges
    if effective_scope == "domain" and scope_target:
        dom = scope_target.strip().upper()
        reachable_ids = _domain_reachable_node_ids(graph, dom)
        declaration_nodes = [
            n
            for n in declaration_nodes
            if (n.domain or "").strip().upper() == dom or n.id in reachable_ids
        ]
        glove_nodes = [
            n
            for n in glove_nodes
            if (str(getattr(n, "domain", "")) or "").strip().upper() == dom
        ]
    elif effective_scope == "file" and scope_target:
        target = _normalize_path(scope_target)
        declaration_nodes = [n for n in declaration_nodes if _normalize_path(n.path) == target]
        glove_nodes = [n for n in glove_nodes if _normalize_path(str(getattr(n, "file", "") or "")) == target]
    elif effective_scope == "function" and scope_target:
        node_id = scope_target.strip()
        keep_ids = {node_id}
        for edge in graph.edges:
            if edge.from_id == node_id:
                keep_ids.add(edge.to_id)
            if edge.to_id == node_id:
                keep_ids.add(edge.from_id)
        declaration_nodes = [n for n in declaration_nodes if n.id in keep_ids]
        decl_paths = {_normalize_path(n.path) for n in declaration_nodes if _normalize_path(n.path)}
        glove_nodes = [n for n in glove_nodes if _normalize_path(str(getattr(n, "file", "") or "")) in decl_paths]

    parity_checked, parity_gaps, parity_stale, parity_findings = _check_parity_pairs(graph, root)
    if effective_scope == "parity":
        report = DiffReport(
            project_id=root.name,
            stack=stack_key,
            glove_used=glove.__class__.__name__,
            declaration_nodes=0,
            glove_nodes=0,
            dark_matter=[],
            ghost_nodes=[],
            missing_edges=[],
            naming_mismatches=[],
            error_code_drift={"skipped": True, "reason": "parity-only scope", "unregistered": 0, "orphaned": 0, "format_mismatches": 0, "findings": []},
            parity_pairs={
                "checked": parity_checked,
                "gaps": parity_gaps,
                "stale": parity_stale,
                "findings": [asdict(f) for f in parity_findings],
            },
            generated_at=datetime.now(timezone.utc).isoformat(),
            execution_diff=_execution_diff_for_layer(eff_layer, root, graph),
            contract_violations=_compute_contract_violations(root, stack_key, glove, graph),
            schema_dep_drift=schema_dep_payload,
        )
        report.annotations_captured = (
            {"captured": 0, "skipped_duplicates": 0, "ids": [], "dry_run": True}
            if dry_run
            else auto_capture_annotations(report, root)
        )
        return report

    if eff_layer == "execution":
        report = DiffReport(
            project_id=root.name,
            stack=stack_key,
            glove_used=glove.__class__.__name__,
            declaration_nodes=0,
            glove_nodes=0,
            dark_matter=[],
            ghost_nodes=[],
            missing_edges=[],
            naming_mismatches=[],
            error_code_drift={
                "skipped": True,
                "reason": "execution-only layer",
                "unregistered": 0,
                "orphaned": 0,
                "format_mismatches": 0,
                "findings": [],
            },
            parity_pairs={"checked": 0, "gaps": 0, "stale": 0, "findings": []},
            generated_at=datetime.now(timezone.utc).isoformat(),
            execution_diff=_execution_diff_for_layer("execution", root, graph),
            contract_violations=_compute_contract_violations(root, stack_key, glove, graph),
            schema_dep_drift=schema_dep_payload,
        )
        report.annotations_captured = {"captured": 0, "skipped_duplicates": 0, "ids": []}
        return report

    decl_by_path = {_normalize_path(n.path): n for n in declaration_nodes if _normalize_path(n.path)}
    decl_by_name = {(n.kind, _slug(n.name)): n for n in declaration_nodes}
    matched_decl_ids: set[str] = set()
    dark_matter = []
    for n in glove_nodes:
        np = _normalize_path(n.file)
        dn = decl_by_name.get((n.kind, _slug(n.name)))
        if dn is None:
            for cand in declaration_nodes:
                if cand.kind == n.kind and _decl_matches_glove_name(cand.name, n.name):
                    dn = cand
                    break
        if dn is None:
            for cand in declaration_nodes:
                if _decl_matches_glove_name(cand.name, n.name):
                    dn = cand
                    break
        if dn is not None:
            matched_decl_ids.add(dn.id)
            continue
        dp = decl_by_path.get(np)
        if dp is not None and _decl_matches_glove_name(dp.name, n.name):
            matched_decl_ids.add(dp.id)
            continue
        dark_matter.append(n)
    ghost_decl = [n for n in declaration_nodes if n.id not in matched_decl_ids]

    dark_by_path = {_normalize_path(n.file): n for n in dark_matter if _normalize_path(n.file)}
    naming_mismatches: list[dict[str, Any]] = []
    dark_consumed: set[str] = set()
    ghost_nodes: list[str] = []

    for d in ghost_decl:
        dp = _normalize_path(d.path)
        # For declaration-first Python stacks, treat an on-disk declared path as implemented.
        # This prevents false ghost inflation when glove extraction is intentionally partial.
        if _declared_path_exists(root, d.path):
            continue
        match = dark_by_path.get(dp)
        if match is None:
            gslug = _slug(d.name)
            for cand in dark_matter:
                if cand.id in dark_consumed:
                    continue
                if _infer_name_slug_from_file(_normalize_path(cand.file or "")) == gslug:
                    match = cand
                    break
        if match is not None:
            dark_consumed.add(match.id)
            naming_mismatches.append(
                {
                    "declared": f"{d.kind}:{d.name}",
                    "observed": f"{match.kind}:{match.name}",
                    "file": dp or _normalize_path(match.file),
                }
            )
        else:
            ghost_nodes.append(f"{d.kind}:{d.name}")

    dark_filtered = [n for n in dark_matter if n.id not in dark_consumed]

    decl_edge_keys = {(e.from_id, e.to_id, e.relation) for e in graph.edges}
    missing_edges = [e for e in edges_for_diff if (e.from_id, e.to_id, e.edge_kind) not in decl_edge_keys]

    node_domain = {n.id: (n.domain or "").strip().upper() for n in graph.nodes}
    if effective_scope == "domain" and scope_target:
        dom_u = scope_target.strip().upper()
        missing_edges = [
            e
            for e in missing_edges
            if node_domain.get(e.from_id) == dom_u or node_domain.get(e.to_id) == dom_u
        ]

    edge_promotion: dict[str, Any] | None = None
    if promote_edges:
        imports_missing = [
            e
            for e in missing_edges
            if e.edge_kind == "imports" and (e.source or "") == "dartglove_mapped"
        ]
        sample: list[dict[str, Any]] = []
        if dart_mapper:
            for e in imports_missing[:8]:
                sample.append(
                    {
                        "from": dart_mapper.decl_id_for_graph_module(e.from_id),
                        "to": dart_mapper.decl_id_for_graph_module(e.to_id),
                        "edge_kind": e.edge_kind,
                    }
                )
        edge_promotion = {
            "imports_missing_count": len(imports_missing),
            "dry_run": dry_run,
            "sample_manifest_edges": sample,
        }

    report = DiffReport(
        project_id=root.name,
        stack=stack_key,
        glove_used=glove.__class__.__name__,
        declaration_nodes=len(declaration_nodes),
        glove_nodes=len(glove_nodes),
        dark_matter=dark_filtered,
        ghost_nodes=sorted(ghost_nodes),
        missing_edges=missing_edges,
        naming_mismatches=naming_mismatches,
        error_code_drift=_error_code_drift(root, stack_key, graph),
        parity_pairs={
            "checked": parity_checked,
            "gaps": parity_gaps,
            "stale": parity_stale,
            "findings": [asdict(f) for f in parity_findings],
        },
        generated_at=datetime.now(timezone.utc).isoformat(),
        execution_diff=_execution_diff_for_layer(eff_layer, root, graph),
        contract_violations=_compute_contract_violations(root, stack_key, glove, graph),
        edge_promotion=edge_promotion,
        schema_dep_drift=schema_dep_payload,
    )
    report.annotations_captured = (
        {"captured": 0, "skipped_duplicates": 0, "ids": [], "dry_run": True}
        if dry_run
        else auto_capture_annotations(report, root)
    )
    if promote_edges and not dry_run and stack_key == "dart" and dart_mapper and dart_manifest_path:
        stats = promote_manifest_import_edges(
            report.missing_edges, dart_manifest_path, mapper=dart_mapper
        )
        if report.edge_promotion is not None:
            report.edge_promotion = {**report.edge_promotion, **stats}
        else:
            report.edge_promotion = stats
        _run_stack_verify(root)
    return report


def _annotation_kind_from_finding(finding_type: str) -> str:
    return {
        "dark-matter": "dark-matter",
        "ghost-node": "ghost-node",
        "naming-mismatch": "naming-mismatch",
        "parity-gap": "finding",
        "error-code-unregistered": "finding",
        "contract-violation": "finding",
    }[finding_type]


def _annotation_severity_from_finding(finding_type: str) -> str:
    return {
        "ghost-node": "high",
        "dark-matter": "medium",
        "naming-mismatch": "medium",
        "parity-gap": "medium",
        "error-code-unregistered": "medium",
        "contract-violation": "high",
    }[finding_type]


def _build_finding_rows(report: DiffReport) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for n in report.dark_matter:
        node_id = str(getattr(n, "id", "") or "")
        if not node_id:
            continue
        rows.append(
            {
                "node_id": node_id,
                "finding_type": "dark-matter",
                "file": _normalize_path(getattr(n, "file", "") or ""),
                "summary": f"Observed node is missing from declaration graph: {node_id}",
            }
        )
    for g in report.ghost_nodes:
        rows.append(
            {
                "node_id": g,
                "finding_type": "ghost-node",
                "file": "",
                "summary": f"Declared node has no observed implementation: {g}",
            }
        )
    for m in report.naming_mismatches:
        node_id = str(m.get("declared") or "")
        rows.append(
            {
                "node_id": node_id,
                "finding_type": "naming-mismatch",
                "file": _normalize_path(str(m.get("file") or "")),
                "summary": f"Declared '{m.get('declared')}' differs from observed '{m.get('observed')}'.",
            }
        )
    parity = report.parity_pairs if isinstance(report.parity_pairs, dict) else {}
    for item in parity.get("findings") or []:
        if not isinstance(item, dict):
            continue
        if str(item.get("kind") or "") != "parity-gap":
            continue
        node_id = str(item.get("node") or "")
        if not node_id:
            continue
        rows.append(
            {
                "node_id": node_id,
                "finding_type": "parity-gap",
                "file": _normalize_path(str(item.get("file") or "")),
                "summary": str(item.get("message") or f"Parity gap detected for {node_id}"),
            }
        )
    drift = report.error_code_drift if isinstance(report.error_code_drift, dict) else {}
    for item in drift.get("findings") or []:
        if not isinstance(item, dict):
            continue
        if str(item.get("kind") or "") != "error-code-unregistered":
            continue
        code = str(item.get("code") or "")
        if not code:
            continue
        rows.append(
            {
                "node_id": f"error-code:{code}",
                "finding_type": "error-code-unregistered",
                "file": "",
                "summary": str(item.get("message") or f"Referenced error code not in registry: {code}"),
            }
        )
    cset = report.contract_violations if isinstance(report.contract_violations, dict) else {}
    for item in cset.get("findings") or []:
        if not isinstance(item, dict):
            continue
        sym = str(item.get("symbol") or "")
        if not sym:
            continue
        rows.append(
            {
                "node_id": sym,
                "finding_type": "contract-violation",
                "file": _normalize_path(str(item.get("file") or "")),
                "summary": f"contract violation: {sym} in {item.get('file')}",
            }
        )
    return rows


def auto_capture_annotations(report: DiffReport, project_path: Path) -> dict[str, Any]:
    from forge.tools.audit.annotations import write_annotation
    from forge.tools.audit.bundle import AuditAnnotation
    import yaml

    root = project_path.expanduser().resolve()
    findings = _build_finding_rows(report)
    if len(findings) > _AUTO_CAPTURE_MAX:
        findings = findings[:_AUTO_CAPTURE_MAX]
    existing: list[AuditAnnotation] = []
    ann_dir = root / ".forge" / "annotations"
    if ann_dir.is_dir():
        for ann_file in sorted(ann_dir.glob("ANNOT-*.yaml")):
            raw = yaml.safe_load(ann_file.read_text(encoding="utf-8")) or {}
            if not isinstance(raw, dict):
                continue
            existing.append(
                AuditAnnotation(
                    id=str(raw.get("id") or ""),
                    file=str(raw.get("file") or ""),
                    kind=str(raw.get("kind") or ""),
                    severity=str(raw.get("severity") or "low"),
                    note=str(raw.get("note") or raw.get("title") or ""),
                    status=str(raw.get("status") or "open"),
                    origin=str(raw.get("origin") or "human"),
                    title=raw.get("title"),
                    body=raw.get("body"),
                    affects=[str(x) for x in (raw.get("affects") or []) if isinstance(x, (str, int, float))],
                )
            )
    dedup_keys = {
        (
            ((a.affects or [a.file])[0] if (a.affects or [a.file]) else ""),
            a.kind,
            a.origin,
        ): a
        for a in existing
    }
    captured_ids: list[str] = []
    skipped = 0
    ts = datetime.now(timezone.utc).isoformat()
    next_id_seed = 1
    for ann in existing:
        m = re.search(r"ANNOT-(\d+)", ann.id)
        if m:
            next_id_seed = max(next_id_seed, int(m.group(1)) + 1)

    for row in findings:
        kind = _annotation_kind_from_finding(row["finding_type"])
        key = (row["node_id"], kind, "forge-diff")
        if key in dedup_keys:
            existing_ann = dedup_keys[key]
            existing_ann.body = f"{row['summary']}\n\nlast_seen: {ts}"
            found_file = existing_ann.file or row["file"]
            directory = (root / found_file).parent if found_file else root
            write_annotation(directory, existing_ann)
            skipped += 1
            continue
        ann_id = f"ANNOT-{next_id_seed:03d}"
        next_id_seed += 1
        ann = AuditAnnotation(
            id=ann_id,
            file=row["file"] or ".forge/manifest.yaml",
            kind=kind,
            severity=_annotation_severity_from_finding(row["finding_type"]),
            note=f"{row['finding_type']}: {row['node_id']}",
            title=f"{row['finding_type']}: {row['node_id']}",
            body=f"{row['summary']}\n\ncaptured_at: {ts}",
            affects=[row["node_id"]],
            origin="forge-diff",
            status="draft",
        )
        directory = (root / ann.file).parent if row["file"] else root
        write_annotation(directory, ann)
        dedup_keys[key] = ann
        captured_ids.append(ann_id)

    return {"captured": len(captured_ids), "skipped_duplicates": skipped, "ids": captured_ids}
