from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class ValidationResult:
    ok: bool
    errors: list[str] = field(default_factory=list)


_REQUIRED: dict[str, list[str]] = {
    "session_state": [
        "schema_version",
        "document_kind",
        "session_id",
        "repo_root",
        "branch",
        "head_sha",
        "started_at",
        "updated_at",
        "status",
    ],
    "events_ledger": ["schema_version", "document_kind", "session_id", "events"],
    "memory_index": ["schema_version", "document_kind", "repo_id", "updated_at", "memories"],
}


def validate_document(data: dict[str, Any], expected_kind: str) -> ValidationResult:
    errs: list[str] = []
    if not isinstance(data, dict):
        return ValidationResult(ok=False, errors=["document must be an object"])
    if data.get("document_kind") != expected_kind:
        errs.append(f"document_kind must be `{expected_kind}`")
    req = _REQUIRED.get(expected_kind, [])
    for k in req:
        if k not in data:
            errs.append(f"missing required key `{k}`")
    if data.get("schema_version") != 1:
        errs.append("schema_version must be 1")
    return ValidationResult(ok=len(errs) == 0, errors=errs)

