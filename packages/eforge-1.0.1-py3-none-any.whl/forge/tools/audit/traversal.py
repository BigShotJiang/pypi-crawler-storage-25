from __future__ import annotations

from collections import deque

from .bundle import AuditMapBundle, AuditMapEdge, AuditMapNode

DEFAULT_EXCLUDE_STATUSES = [
    "verified_clean",
]


def bfs_queue(
    nodes: list[AuditMapNode],
    edges: list[AuditMapEdge] | None = None,
    root_id: str | None = None,
    exclude_status: list[str] | None = None,
    max_items: int | None = None,
) -> list[AuditMapNode]:
    exclude = exclude_status or DEFAULT_EXCLUDE_STATUSES
    eligible = [n for n in nodes if n.status not in exclude]

    if not edges:
        kind_order = [
            "branch",
            "feature_slice",
            "command",
            "runtime_flow",
            "policy",
            "module",
            "doc",
        ]
        result = sorted(
            eligible,
            key=lambda n: (
                kind_order.index(n.kind) if n.kind in kind_order else 99,
                n.node_id,
            ),
        )
        return result[:max_items] if max_items else result

    children: dict[str, list[str]] = {}
    for edge in edges:
        if edge.relation == "contains":
            children.setdefault(edge.from_node_id, []).append(edge.to_node_id)

    node_map = {n.node_id: n for n in eligible}
    visited: set[str] = set()
    queue: deque[str] = deque()

    roots = (
        [root_id]
        if root_id
        else [
            n.node_id
            for n in eligible
            if not any(e.to_node_id == n.node_id for e in (edges or []) if e.relation == "contains")
        ]
    )

    for r in roots:
        if r in node_map:
            queue.append(r)

    result: list[AuditMapNode] = []
    while queue:
        nid = queue.popleft()
        if nid in visited:
            continue
        visited.add(nid)
        if nid in node_map:
            result.append(node_map[nid])
        for child_id in children.get(nid, []):
            if child_id not in visited:
                queue.append(child_id)

    return result[:max_items] if max_items else result


def dfs_queue(
    nodes: list[AuditMapNode],
    edges: list[AuditMapEdge] | None = None,
    root_id: str | None = None,
    exclude_status: list[str] | None = None,
    max_items: int | None = None,
) -> list[AuditMapNode]:
    exclude = exclude_status or DEFAULT_EXCLUDE_STATUSES
    eligible = [n for n in nodes if n.status not in exclude]
    node_map = {n.node_id: n for n in eligible}

    children: dict[str, list[str]] = {}
    for edge in edges or []:
        if edge.relation == "contains":
            children.setdefault(edge.from_node_id, []).append(edge.to_node_id)

    visited: set[str] = set()
    result: list[AuditMapNode] = []

    def dfs(nid: str) -> None:
        if nid in visited or nid not in node_map:
            return
        visited.add(nid)
        result.append(node_map[nid])
        for child_id in children.get(nid, []):
            dfs(child_id)

    if root_id:
        dfs(root_id)
    else:
        for node in eligible:
            dfs(node.node_id)

    return result[:max_items] if max_items else result


def risk_first_queue(
    nodes: list[AuditMapNode],
    edges: list[AuditMapEdge] | None = None,
    max_items: int = 10,
    exclude_status: list[str] | None = None,
) -> list[AuditMapNode]:
    _ = edges
    exclude = exclude_status or DEFAULT_EXCLUDE_STATUSES
    eligible = [n for n in nodes if n.status not in exclude]

    priority = {
        "blocked": 0,
        "not_started": 1,
        "observed_indirectly": 2,
        "reviewed_with_findings": 3,
        "in_progress": 4,
    }

    def sort_key(n: AuditMapNode) -> tuple:
        p = priority.get(n.status, 99)
        critical_boost = 0 if n.critical else 1
        has_findings = 0 if n.finding_ids else 1
        has_annotations = 0 if n.annotation_ids else 1
        return (
            critical_boost,
            p,
            has_findings,
            has_annotations,
            n.node_id,
        )

    sorted_nodes = sorted(eligible, key=sort_key)
    return sorted_nodes[:max_items]


def get_next_reason(node: AuditMapNode) -> str:
    if node.status == "blocked":
        return "blocked — needs remediation"
    if node.critical and node.status == "not_started":
        return "critical node not yet reviewed"
    if node.annotation_ids:
        return f"has {len(node.annotation_ids)} open annotation(s)"
    if node.finding_ids:
        return f"has {len(node.finding_ids)} finding(s)"
    if node.status == "observed_indirectly":
        return "in scope but not explicitly reviewed"
    return "not yet reviewed"


def blast_radius_all_rings(
    node_id: str,
    bundle: AuditMapBundle,
    max_depth: int = 5,
) -> dict[int, list[AuditMapNode]]:
    nodes_by_id = {n.node_id: n for n in bundle.nodes}
    if node_id not in nodes_by_id:
        return {}

    # Cross-ring + in-ring adjacency
    adjacency: dict[str, list[str]] = {}
    for e in [*(bundle.edges or []), *(bundle.cross_ring_edges or [])]:
        adjacency.setdefault(e.from_node_id, []).append(e.to_node_id)
        if str(getattr(e, "relation", "")) == "parity":
            adjacency.setdefault(e.to_node_id, []).append(e.from_node_id)

    out: dict[int, list[AuditMapNode]] = {}
    seen: set[str] = {node_id}
    q: deque[tuple[str, int]] = deque([(node_id, 0)])

    while q:
        cur, depth = q.popleft()
        if depth >= max_depth:
            continue
        for nxt in adjacency.get(cur, []):
            if nxt in seen:
                continue
            seen.add(nxt)
            n = nodes_by_id.get(nxt)
            if not n:
                continue
            rid = int(getattr(n, "ring_id", 4) or 4)
            out.setdefault(rid, []).append(n)
            q.append((nxt, depth + 1))

    # Deterministic output
    for rid in list(out.keys()):
        out[rid] = sorted(out[rid], key=lambda n: n.node_id)
    return out
