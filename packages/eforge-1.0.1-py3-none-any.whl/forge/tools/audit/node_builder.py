from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from forge.tools.manifest.graph import ManifestGraph
from forge.tools.registry.store import _projects_map
from forge.tools.context.index import parse_markdown_frontmatter

from .bundle import SIDECAR_FILENAME, AuditAnnotation, AuditMapBundle, AuditMapEdge, AuditMapNode
from .sidecar_walk import iter_sidecar_paths


# UNSTABLE: node_id format changes when Gate 5 lands
def _path_to_node_id(kind: str, path: str) -> str:
    slug = path.replace("/", ".").replace(".py", "").replace(".yaml", "")
    return f"{kind}/{slug}"


def _frontmatter_id_for_path(path: str, project_root: Path | None) -> str | None:
    if not project_root:
        return None
    p = (project_root / path).resolve()
    if not p.exists() or not p.is_file() or p.suffix.lower() != ".md":
        return None
    try:
        text = p.read_text(encoding="utf-8")
        fm, _ = parse_markdown_frontmatter(text)
        val = fm.get("id")
        if val is None:
            return None
        sid = str(val).strip()
        return sid or None
    except Exception:
        return None


def _canonical_id(
    *,
    kind: str,
    path: str,
    node_id: str,
    project_root: Path | None = None,
) -> str:
    fm_id = _frontmatter_id_for_path(path, project_root)
    if fm_id:
        return fm_id
    if node_id.startswith("ring1/") or node_id.startswith("ring2/"):
        return node_id
    return _path_to_node_id(kind, path or node_id)


def _ensure_node(
    nodes: list[AuditMapNode],
    node_id: str,
    *,
    kind: str,
    path: str,
    label: str,
    status: str = "not_started",
    finding_ids: list[str] | None = None,
    ring_id: int = 4,
    project_root: Path | None = None,
) -> AuditMapNode:
    existing = next((n for n in nodes if n.node_id == node_id), None)
    if existing:
        return existing
    node = AuditMapNode(
        node_id=node_id,
        kind=kind,
        path=path,
        label=label,
        canonical_id=_canonical_id(kind=kind, path=path, node_id=node_id, project_root=project_root),
        status=status,
        finding_ids=list(finding_ids or []),
        ring_id=ring_id,
    )
    nodes.append(node)
    return node


def build_nodes_from_scan(scan_validation_path: Path) -> tuple[list[AuditMapNode], list[AuditMapEdge]]:
    """
    Read scan/validation.json. Returns (nodes, edges).
    Supports extended keys (screens, controllers) for tests/tools; otherwise uses
    orphans, severed_connections, and frontmatter_issues from the standard renderer.
    """
    if not scan_validation_path.exists():
        return [], []

    data = json.loads(scan_validation_path.read_text(encoding="utf-8"))
    nodes: list[AuditMapNode] = []
    edges: list[AuditMapEdge] = []
    project_root = scan_validation_path.parent.parent

    for screen in data.get("screens", []) or []:
        if not isinstance(screen, dict):
            continue
        fp = screen.get("file") or screen.get("name") or ""
        node = AuditMapNode(
            node_id=_path_to_node_id("feature_slice", fp),
            canonical_id=_canonical_id(
                kind="feature_slice",
                path=str(screen.get("file", "")),
                node_id=_path_to_node_id("feature_slice", fp),
                project_root=project_root,
            ),
            kind="feature_slice",
            path=str(screen.get("file", "")),
            label=str(screen.get("name", "")),
            status="not_started",
            ring_id=4,
        )
        nodes.append(node)

    for ctrl in data.get("controllers", []) or []:
        if not isinstance(ctrl, dict):
            continue
        fp = ctrl.get("file") or ctrl.get("name") or ""
        node = AuditMapNode(
            node_id=_path_to_node_id("feature_slice", fp),
            canonical_id=_canonical_id(
                kind="feature_slice",
                path=str(ctrl.get("file", "")),
                node_id=_path_to_node_id("feature_slice", fp),
                project_root=project_root,
            ),
            kind="feature_slice",
            path=str(ctrl.get("file", "")),
            label=str(ctrl.get("name", "")),
            status="not_started",
            ring_id=4,
        )
        nodes.append(node)

    for orphan in data.get("orphans", []) or []:
        if isinstance(orphan, dict):
            path_s = str(orphan.get("path", ""))
        else:
            path_s = str(orphan)
        if not path_s:
            continue
        nodes.append(
            AuditMapNode(
                node_id=_path_to_node_id("module", path_s),
                canonical_id=_canonical_id(
                    kind="module",
                    path=path_s,
                    node_id=_path_to_node_id("module", path_s),
                    project_root=project_root,
                ),
                kind="module",
                path=path_s,
                label=Path(path_s).name,
                status="observed_indirectly",
                ring_id=4,
            )
        )

    for row in data.get("severed_connections", []) or []:
        if not isinstance(row, dict):
            continue
        a = str(row.get("from_id", ""))
        b = str(row.get("to_id", ""))
        if a:
            _ensure_node(
                nodes,
                _path_to_node_id("module", a),
                kind="module",
                path=a,
                label=Path(a).name,
                project_root=project_root,
            )
        if b:
            _ensure_node(
                nodes,
                _path_to_node_id("module", b),
                kind="module",
                path=b,
                label=Path(b).name,
                project_root=project_root,
            )
        if a and b:
            edges.append(AuditMapEdge(from_node_id=_path_to_node_id("module", a), to_node_id=_path_to_node_id("module", b), relation="depends_on"))

    for issue in data.get("frontmatter_issues", []) or []:
        if isinstance(issue, dict):
            file_path = str(issue.get("file", ""))
            issue_txt = str(issue.get("issue", ""))
        else:
            s = str(issue)
            file_path = s.split(":", 1)[0].strip() if ":" in s else ""
            issue_txt = s
        if not file_path:
            continue
        node_id = _path_to_node_id("module", file_path)
        existing = next((n for n in nodes if n.node_id == node_id), None)
        fid = f"frontmatter:{issue_txt}"
        if existing:
            if fid not in existing.finding_ids:
                existing.finding_ids.append(fid)
        else:
            nodes.append(
                AuditMapNode(
                    node_id=node_id,
                    canonical_id=_canonical_id(kind="module", path=file_path, node_id=node_id, project_root=project_root),
                    kind="module",
                    path=file_path,
                    label=Path(file_path).name,
                    status="observed_indirectly",
                    finding_ids=[fid],
                    ring_id=4,
                )
            )

    return nodes, edges


def build_nodes_from_command_tree(command_tree_path: Path) -> list[AuditMapNode]:
    if not command_tree_path.exists():
        return []

    data = json.loads(command_tree_path.read_text(encoding="utf-8"))
    nodes: list[AuditMapNode] = []

    def walk(cmd: dict[str, Any], parent_id: str | None) -> None:
        name = str(cmd.get("name", ""))
        node_id = _path_to_node_id("command", name)
        node = AuditMapNode(
            node_id=node_id,
            kind="command",
            path=name,
            label=name,
            parent_id=parent_id,
            status="not_started",
            capability="implemented",
            ring_id=4,
        )
        nodes.append(node)
        for sub in cmd.get("subcommands", []) or []:
            if isinstance(sub, dict):
                walk(sub, node_id)

    if isinstance(data, list):
        for cmd in data:
            if isinstance(cmd, dict):
                walk(cmd, None)
    elif isinstance(data, dict):
        walk(data, None)

    return nodes


def build_nodes_from_meta_output(
    meta_output: dict[str, Any],
    branch_path: str,
    *,
    kind: str = "branch",
) -> list[AuditMapNode]:
    exit_code = int(meta_output.get("exit_code", 0))
    status_map = {0: "in_progress", 1: "reviewed_with_findings", 2: "blocked"}
    status = status_map.get(exit_code, "not_started")
    failures = meta_output.get("impact_summary", {}).get("failures", []) or []
    finding_ids: list[str] = []
    for f in failures:
        if not isinstance(f, dict):
            continue
        rid = f.get("rule_id") or f.get("code")
        if rid:
            finding_ids.append(str(rid))
    node_kind = kind if kind in ("branch", "policy", "module", "doc", "runtime_flow", "feature_slice", "command") else "branch"
    node = AuditMapNode(
        node_id=_path_to_node_id(node_kind, branch_path),
        canonical_id=_canonical_id(kind=node_kind, path=branch_path, node_id=_path_to_node_id(node_kind, branch_path)),
        kind=node_kind,
        path=branch_path,
        label=Path(branch_path).name if branch_path not in (".", "") else branch_path,
        status=status,
        finding_ids=finding_ids,
        ring_id=4,
    )
    return [node]


def build_nodes_from_registry(registry: dict) -> list[AuditMapNode]:
    nodes: list[AuditMapNode] = []
    pmap = _projects_map(registry if isinstance(registry, dict) else {})
    for key, val in pmap.items():
        if not isinstance(val, dict):
            continue
        slug = str(val.get("id") or key)
        label = str(val.get("name") or slug)
        path = str(val.get("path") or "")
        nodes.append(
            AuditMapNode(
                node_id=f"ring1/{slug}",
                canonical_id=f"ring1/{slug}",
                kind="branch",
                path=path,
                label=label,
                status="not_started",
                ring_id=1,
            )
        )
    return nodes


def build_nodes_from_manifest_graph(
    manifest_graph: ManifestGraph,
) -> tuple[list[AuditMapNode], list[AuditMapEdge]]:
    nodes: list[AuditMapNode] = []
    edges: list[AuditMapEdge] = []
    for n in manifest_graph.nodes:
        nodes.append(
            AuditMapNode(
                node_id=f"ring2/{n.id}",
                canonical_id=f"ring2/{n.id}",
                kind="feature_slice",
                path=n.path or "",
                label=n.name,
                status="not_started",
                parent_id=f"ring2/{n.parent_id}" if n.parent_id else None,
                ring_id=2,
            )
        )
    for e in manifest_graph.edges:
        edges.append(
            AuditMapEdge(
                from_node_id=f"ring2/{e.from_id}",
                to_node_id=f"ring2/{e.to_id}",
                relation=str(e.relation),
            )
        )
    return nodes, edges


def build_cross_ring_edges(
    ring1_nodes: list[AuditMapNode],
    ring2_nodes: list[AuditMapNode],
    ring4_nodes: list[AuditMapNode],
) -> list[AuditMapEdge]:
    def norm(p: str) -> str:
        return str(p or "").replace("\\", "/").lstrip("./")

    out: list[AuditMapEdge] = []
    seen: set[tuple[str, str, str]] = set()

    # Ring4 file path matches Ring2 node path -> implements
    for n4 in ring4_nodes:
        p4 = norm(n4.path)
        if not p4:
            continue
        for n2 in ring2_nodes:
            p2 = norm(n2.path)
            if not p2:
                continue
            if p4 == p2 or p4.endswith(p2) or p2.endswith(p4):
                k = (n4.node_id, n2.node_id, "implements")
                if k not in seen:
                    seen.add(k)
                    out.append(AuditMapEdge(from_node_id=n4.node_id, to_node_id=n2.node_id, relation="implements"))

    # Ring2 belongs_to Ring1 project
    ring1_by_slug = {str(n.label).strip().lower(): n for n in ring1_nodes if n.node_id}
    only_ring1 = ring1_nodes[0] if len(ring1_nodes) == 1 else None
    for n2 in ring2_nodes:
        tgt = only_ring1
        if tgt is None:
            nid = n2.node_id.lower()
            npath = norm(n2.path).lower()
            for slug, n1 in ring1_by_slug.items():
                if slug and (f"/{slug}/" in f"/{npath}/" or slug in nid):
                    tgt = n1
                    break
        if tgt is None:
            continue
        k = (n2.node_id, tgt.node_id, "belongs_to")
        if k not in seen:
            seen.add(k)
            out.append(AuditMapEdge(from_node_id=n2.node_id, to_node_id=tgt.node_id, relation="belongs_to"))
    return out


def load_annotations_from_sidecar(directory: Path) -> list[AuditAnnotation]:
    from .annotations import audit_annotation_from_dict

    sidecar = directory / SIDECAR_FILENAME
    if not sidecar.exists():
        return []

    try:
        import yaml

        data = yaml.safe_load(sidecar.read_text(encoding="utf-8")) or {}
        annotations: list[AuditAnnotation] = []
        for raw in data.get("annotations", []) or []:
            if isinstance(raw, dict):
                annotations.append(audit_annotation_from_dict(raw))
        return annotations
    except Exception:
        return []


def scan_all_annotations(project_path: Path) -> list[AuditAnnotation]:
    from .annotations import _iter_annotation_files, audit_annotation_from_dict

    root = project_path.resolve()
    out: list[AuditAnnotation] = []
    for ann_file in _iter_annotation_files(root):
        try:
            raw = yaml.safe_load(ann_file.read_text(encoding="utf-8")) or {}
        except Exception:
            continue
        if not isinstance(raw, dict):
            continue
        out.append(audit_annotation_from_dict(raw))
    if out:
        return out

    all_annotations: list[AuditAnnotation] = []
    for sidecar in iter_sidecar_paths(root):
        directory = sidecar.parent
        all_annotations.extend(load_annotations_from_sidecar(directory))
    return all_annotations


def attach_annotations_to_nodes(
    nodes: list[AuditMapNode],
    annotations: list[AuditAnnotation],
) -> None:
    for annotation in annotations:
        if annotation.status != "open":
            continue
        for node in nodes:
            if annotation.file in node.path or node.path in annotation.file:
                if annotation.id not in node.annotation_ids:
                    node.annotation_ids.append(annotation.id)
                if annotation.severity == "high":
                    node.critical = True


def build_audit_map_bundle(
    project: Path,
    *,
    bundle_id: str,
    session_id: str,
    mode: str,
    at: str | None,
    depth: int,
    sweep_level: str,
    traverse: str,
    generator_version: str,
    meta_output: dict[str, Any] | None,
) -> tuple[AuditMapBundle, list[str]]:
    """Assemble bundle from scan artifacts, optional command tree, meta audit, annotations."""
    warnings: list[str] = []
    nodes: list[AuditMapNode] = []
    edges: list[AuditMapEdge] = []

    scan_path = project / "scan" / "validation.json"
    scan_nodes, scan_edges = build_nodes_from_scan(scan_path)
    nodes.extend(scan_nodes)
    edges.extend(scan_edges)
    if not scan_path.exists():
        warnings.append("scan/validation.json not found. Run: forge scan . --format all")

    cmd_tree = _resolve_command_tree_path(project)
    cmd_nodes = build_nodes_from_command_tree(cmd_tree)
    nodes.extend(cmd_nodes)
    if not cmd_tree.exists():
        warnings.append("command_tree.json not found. Skipping command nodes.")

    branch_path = str(at or ".").replace("\\", "/")
    if meta_output is not None:
        nodes.extend(build_nodes_from_meta_output(meta_output, branch_path))

    annotations = scan_all_annotations(project)
    attach_annotations_to_nodes(nodes, annotations)

    bundle = AuditMapBundle(
        bundle_id=bundle_id,
        session_id=session_id,
        repo={},  # filled by caller
        generator_version=generator_version,
        inputs={
            "mode": mode,
            "at": at,
            "depth": depth,
            "sweep_level": sweep_level,
            "traverse": traverse,
        },
        warnings=warnings,
        nodes=nodes,
        edges=edges,
        provenance={
            "manifest_source": _manifest_source(project),
            "scan_path": str(scan_path),
        },
    )
    bundle.coverage = bundle.compute_coverage()
    return bundle, warnings


def _manifest_source(project: Path) -> str:
    if (project / "docs" / "manifest.yaml").exists():
        return "docs/manifest.yaml"
    if (project / "manifest.yaml").exists():
        return "manifest.yaml (root)"
    return "not found"


def _resolve_command_tree_path(project: Path) -> Path:
    """Prefer sibling forge-workspace layout; fallback to missing path under project parent."""
    cand = project.parent / "forge-workspace" / project.name / "command-map-artifacts" / "command_tree.json"
    return cand
