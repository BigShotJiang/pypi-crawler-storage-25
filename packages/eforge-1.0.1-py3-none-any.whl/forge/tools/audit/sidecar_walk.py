"""Discover `.forge-annotations.yaml` sidecars without descending into VCS or build caches."""

from __future__ import annotations

import os
from pathlib import Path

from .bundle import SIDECAR_FILENAME

# Directory basenames to prune entirely (never read sidecars here).
_SIDECAR_SKIP_DIRS: frozenset[str] = frozenset(
    {
        ".git",
        ".hg",
        ".svn",
        "node_modules",
        "__pycache__",
        ".venv",
        "venv",
        ".tox",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        "dist",
        "build",
        ".gradle",
        "DerivedData",
        ".idea",
    },
)


def _prune_dir(name: str) -> bool:
    if name in _SIDECAR_SKIP_DIRS:
        return True
    if name.endswith(".egg-info"):
        return True
    return False


def iter_sidecar_paths(root: Path) -> list[Path]:
    """Return sorted absolute paths to every sidecar file under root (pruned walk)."""
    root = root.resolve()
    out: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(root, topdown=True):
        dirnames[:] = [d for d in dirnames if not _prune_dir(d)]
        if SIDECAR_FILENAME in filenames:
            out.append((Path(dirpath) / SIDECAR_FILENAME).resolve())
    return sorted(out)
