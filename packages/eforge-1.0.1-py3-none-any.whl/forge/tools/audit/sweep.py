from __future__ import annotations

from pathlib import Path

from forge.tools.audit import runtime
from forge.tools.audit.bundle import AuditMapBundle

STANDARD_L1_BRANCHES = [
    "forge/forge/commands",
    "forge/forge/tools/audit",
    "forge/forge/tools/docs_audit",
    "forge/forge/tools/scan",
    "forge/forge/mcp",
    "forge/forge/renderers/web",
    "forge/forge/core",
    "forge/forge/checkers",
    "forge/forge/types",
    "forge/tests",
    "forge/docs",
]

L2_ADDITIONAL_BRANCHES = [
    "forge/forge/tools/context",
    "forge/forge/tools/init_docs",
    "forge/forge/tools/init_project",
    "forge/forge/tools/scaffold",
    "forge/forge/tools/toc",
    "forge/forge/tools/workspace_store.py",
    "forge/forge/renderers/textual",
    "forge/forge/dashboard",
]

L3_CONTRACT_BRANCHES = [
    "forge/forge/mcp",
    "forge/.forge/change-impact.yaml",
    "forge/docs/change-impact.yaml",  # legacy fallback path
    "forge/forge/tools/docs_audit",
]


def _normalize_branch_path(project_path: Path, branch_path: str) -> str:
    """Convert prompt-style paths to repo-relative paths."""
    rel = branch_path.replace("\\", "/").strip("/")
    # Paths in prompt use forge/forge/... for this repo; normalize to actual tree.
    if rel.startswith("forge/"):
        candidate = rel[len("forge/") :]
        if (project_path / candidate).exists():
            return candidate
    return rel


def get_branches_for_sweep(
    sweep_level: str,
    project_path: Path,
    existing_bundle: AuditMapBundle | None = None,
) -> list[str]:
    """
    Returns branch paths to audit for the given sweep level.
    L4 uses blocked node paths from existing bundle.
    """
    _ = project_path
    if sweep_level == "L0":
        return []
    if sweep_level == "L1":
        return list(STANDARD_L1_BRANCHES)
    if sweep_level == "L2":
        return list(STANDARD_L1_BRANCHES) + list(L2_ADDITIONAL_BRANCHES)
    if sweep_level == "L3":
        return list(L3_CONTRACT_BRANCHES)
    if sweep_level == "L4":
        if not existing_bundle:
            return []
        blocked = []
        for n in existing_bundle.nodes:
            if n.status == "blocked" and n.path:
                blocked.append(n.path)
        # preserve order and uniqueness
        seen: set[str] = set()
        out: list[str] = []
        for p in blocked:
            if p not in seen:
                seen.add(p)
                out.append(p)
        return out
    return list(STANDARD_L1_BRANCHES)


def run_meta_for_branch(
    branch_path: str,
    mode: str,
    project_path: Path,
    siblings: bool = False,
    *,
    focus: list[str] | None = None,
) -> dict:
    """
    Call forge audit meta programmatically for one branch path.
    """
    rel = _normalize_branch_path(project_path, branch_path)
    at_path = (project_path / rel).resolve() if rel != "." else project_path.resolve()
    return runtime.audit_meta(
        at_path=str(at_path),
        include_siblings=siblings,
        depth=3,
        include_parent_context=True,
        strict=False,
        policy_mode="advisory",
        changed_files_source=mode,
        alignment_mode="target_to_forge",
        scope=None,
        focus=focus,
    )

