from __future__ import annotations

from pathlib import Path

from .bundle import (
    FOCUS_MODES_IMPLEMENTED,
    FOCUS_MODES_STUBBED,
    AuditMapBundle,
    AuditMapNode,
)

STATUS_COLORS = {
    "verified_clean": "#90EE90",
    "reviewed_with_findings": "#FFD700",
    "observed_indirectly": "#FFA500",
    "blocked": "#FF6B6B",
    "not_started": "#D3D3D3",
    "in_progress": "#87CEEB",
}

STUB_MESSAGE = (
    "# This focus mode is not yet implemented.\n"
    "# It depends on stable node IDs (Gate 5).\n"
    "# See docs/adr/ADR-011 for implementation plan.\n"
    "# Implemented focus modes: {implemented}\n"
)


def render_mermaid(
    bundle: AuditMapBundle,
    focus: str = "coverage",
    depth: int = 2,
    at: str | None = None,
) -> str:
    if focus in FOCUS_MODES_STUBBED:
        return STUB_MESSAGE.format(implemented=", ".join(FOCUS_MODES_IMPLEMENTED))

    nodes = _filter_nodes(bundle.nodes, at, depth)

    if focus == "coverage":
        return _render_coverage_mermaid(nodes, bundle.edges)
    if focus == "branch":
        return _render_branch_mermaid(nodes, bundle.edges)

    return STUB_MESSAGE.format(implemented=", ".join(FOCUS_MODES_IMPLEMENTED))


def _filter_nodes(
    nodes: list[AuditMapNode],
    at: str | None,
    depth: int,
) -> list[AuditMapNode]:
    _ = depth
    if not at:
        return nodes
    return [n for n in nodes if n.path.startswith(at)]


def _safe_node_id(node_id: str) -> str:
    return (
        node_id.replace("/", "_")
        .replace(".", "_")
        .replace("-", "_")
        .replace(" ", "_")
    )


def render_rings_mermaid(
    bundle: AuditMapBundle,
    rings: list[int] | None = None,
) -> str:
    selected = set(rings or [4])
    if not rings:
        selected = {4}
    nodes = [n for n in bundle.nodes if int(getattr(n, "ring_id", 4) or 4) in selected]
    edges = [e for e in bundle.edges if any(n.node_id == e.from_node_id for n in nodes) and any(n.node_id == e.to_node_id for n in nodes)]
    cross = [
        e
        for e in (bundle.cross_ring_edges or [])
        if any(n.node_id == e.from_node_id for n in nodes) and any(n.node_id == e.to_node_id for n in nodes)
    ]

    ring_titles = {
        1: "Ecosystem",
        2: "Manifest",
        3: "Feature",
        4: "Code",
        5: "Change",
    }
    lines = ["graph TD"]
    by_ring: dict[int, list[AuditMapNode]] = {}
    for n in nodes:
        rid = int(getattr(n, "ring_id", 4) or 4)
        by_ring.setdefault(rid, []).append(n)
    for rid in sorted(by_ring):
        title = ring_titles.get(rid, f"Ring{rid}")
        lines.append(f'  subgraph Ring{rid}["{title}"]')
        for n in sorted(by_ring[rid], key=lambda x: x.node_id):
            sid = _safe_node_id(n.node_id)
            label = n.label or Path(n.path).name or n.node_id
            lines.append(f"    {sid}[{label}]")
        lines.append("  end")
    for e in edges:
        lines.append(f"  {_safe_node_id(e.from_node_id)} -->|{e.relation}| {_safe_node_id(e.to_node_id)}")
    for e in cross:
        lines.append(f"  {_safe_node_id(e.from_node_id)} -.{e.relation}.-> {_safe_node_id(e.to_node_id)}")
    return "\n".join(lines)


def _render_coverage_mermaid(
    nodes: list[AuditMapNode],
    edges: list,
) -> str:
    lines = ["graph TD"]

    for node in nodes:
        safe_id = _safe_node_id(node.node_id)
        color = STATUS_COLORS.get(node.status, "#D3D3D3")
        label = node.label or Path(node.path).name or node.node_id
        border = "stroke:#FF0000,stroke-width:3px" if node.annotation_ids else ""
        style = f"fill:{color}"
        if border:
            style += f",{border}"
        lines.append(f"  {safe_id}[{label}]")
        lines.append(f"  style {safe_id} {style}")

    for edge in edges:
        if edge.relation == "contains":
            from_id = _safe_node_id(edge.from_node_id)
            to_id = _safe_node_id(edge.to_node_id)
            lines.append(f"  {from_id} --> {to_id}")

    return "\n".join(lines)


def _render_branch_mermaid(
    nodes: list[AuditMapNode],
    edges: list,
) -> str:
    branch_nodes = [n for n in nodes if n.kind in ("branch", "feature_slice", "command", "module")]
    lines = ["graph TD"]

    for node in branch_nodes:
        safe_id = _safe_node_id(node.node_id)
        label = node.label or Path(node.path).name or node.node_id
        lines.append(f"  {safe_id}[{label}]")

    for edge in edges:
        if edge.relation in ("contains", "depends_on"):
            from_id = _safe_node_id(edge.from_node_id)
            to_id = _safe_node_id(edge.to_node_id)
            arrow = "-->" if edge.relation == "contains" else "-.->"
            lines.append(f"  {from_id} {arrow} {to_id}")

    return "\n".join(lines)


def render_dot(
    bundle: AuditMapBundle,
    focus: str = "coverage",
) -> str:
    if focus in FOCUS_MODES_STUBBED:
        return STUB_MESSAGE.format(implemented=", ".join(FOCUS_MODES_IMPLEMENTED))

    lines = ["digraph forge_audit {"]
    for node in bundle.nodes:
        safe_id = _safe_node_id(node.node_id)
        color = STATUS_COLORS.get(node.status, "#D3D3D3")
        label = node.label or Path(node.path).name or node.node_id
        lines.append(f'  {safe_id} [label="{label}" fillcolor="{color}" style="filled"];')
    for edge in bundle.edges:
        from_id = _safe_node_id(edge.from_node_id)
        to_id = _safe_node_id(edge.to_node_id)
        lines.append(f"  {from_id} -> {to_id};")
    lines.append("}")
    return "\n".join(lines)


def render_obsidian(
    bundle: AuditMapBundle,
) -> str:
    lines = [
        "# Audit Map",
        f"bundle_id: {bundle.bundle_id}",
        f"generated: {bundle.generated_at}",
        "",
        "## Nodes",
    ]
    for node in bundle.nodes:
        status_emoji = {
            "verified_clean": "✅",
            "reviewed_with_findings": "🔶",
            "observed_indirectly": "👁",
            "blocked": "🚫",
            "not_started": "⬜",
            "in_progress": "🔵",
        }.get(node.status, "⬜")
        label = node.label or Path(node.path).name or node.node_id
        lines.append(f"{status_emoji} [[{node.node_id}]] — {label}")
    lines.append("")
    lines.append("## Edges")
    for edge in bundle.edges:
        lines.append(f"[[{edge.from_node_id}]] —{edge.relation}→ [[{edge.to_node_id}]]")
    return "\n".join(lines)


def render_table(
    bundle: AuditMapBundle,
    group_by: str = "kind",
) -> str:
    _ = group_by
    cov = bundle.coverage or bundle.compute_coverage()
    lines = [
        "# Audit Coverage",
        f"Total: {cov.get('total', 0)} nodes",
        f"Reviewed: {cov.get('pct_reviewed', 0)}%",
        "",
        "## By status",
        "| Status | Count |",
        "|--------|-------|",
    ]
    for status, count in (cov.get("by_status") or {}).items():
        lines.append(f"| {status} | {count} |")
    lines += [
        "",
        "## By kind",
        "| Kind | Count |",
        "|------|-------|",
    ]
    for kind, count in (cov.get("by_kind") or {}).items():
        lines.append(f"| {kind} | {count} |")
    return "\n".join(lines)


def render_md(
    bundle: AuditMapBundle,
) -> str:
    cov = bundle.coverage or bundle.compute_coverage()
    blocked = [n for n in bundle.nodes if n.status == "blocked"]
    critical = [n for n in bundle.nodes if n.critical]
    lines = [
        "# Audit Map Report",
        f"Bundle: {bundle.bundle_id}",
        f"Generated: {bundle.generated_at}",
        f"Session: {bundle.session_id}",
        "",
        "## Coverage",
        f"- Total nodes: {cov.get('total', 0)}",
        f"- Reviewed: {cov.get('pct_reviewed', 0)}%",
        "",
        f"## Blocked ({len(blocked)})",
    ]
    for n in blocked:
        lines.append(f"- {n.node_id}: {n.path}")
    lines += [
        "",
        f"## Critical ({len(critical)})",
    ]
    for n in critical:
        lines.append(f"- {n.node_id}: {n.path}")
    return "\n".join(lines)
