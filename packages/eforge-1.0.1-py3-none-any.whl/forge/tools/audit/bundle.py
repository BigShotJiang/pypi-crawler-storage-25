from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

BUNDLE_SCHEMA_VERSION = "1"
DOCUMENT_KIND = "audit_map_bundle"
SIDECAR_FILENAME = ".forge-annotations.yaml"

NODE_STATUSES = [
    "not_started",
    "observed_indirectly",
    "in_progress",
    "reviewed_with_findings",
    "verified_clean",
    "blocked",
]

NODE_KINDS = [
    "branch",
    "feature_slice",
    "command",
    "runtime_flow",
    "policy",
    "module",
    "doc",
]

EDGE_RELATIONS = [
    "contains",
    "depends_on",
    "implements",
    "uses",
    "guards",
    "renders",
    "calls",
    "belongs_to",
    "watches",
    "reads",
    "writes",
    "fires",
    "sibling_peer",
    "scaffolds_from",
]

ANNOTATION_KINDS = [
    "debt",
    "gap",
    "finding",
    "risk",
    "question",
    "stub",
    "guard",
    "dark-matter",
    "ghost-node",
    "naming-mismatch",
    "verification-checkpoint",
    "architecture-debt",
    "design-proposal",
    "schema-improvement",
    "future-idea",
    "milestone",
]

FOCUS_MODES = [
    "branch",
    "coverage",
    "calls",
    "deps",
    "contracts",
    "change-impact",
    "drift",
    "annotations",
]

FOCUS_MODES_IMPLEMENTED = ["branch", "coverage"]
FOCUS_MODES_STUBBED = [f for f in FOCUS_MODES if f not in FOCUS_MODES_IMPLEMENTED]

# RESERVED ID PREFIXES (forge system use):
# adr-, ring1-, ring2-, forge-
# Project prefixes (user-defined): pix-, lifeos-, denv-
# Enforcement: Gate 7 (pending)


@dataclass
class AuditMapNode:
    # UNSTABLE: path-based now; format {kind}/{path_slug}; replaces with type/scope after Gate 5
    node_id: str
    # UNSTABLE: None until Gate 5
    canonical_id: str | None = None
    kind: str = "branch"
    path: str = ""
    label: str = ""
    parent_id: str | None = None
    status: str = "not_started"
    critical: bool = False
    capability: str | None = None
    evidence_refs: list[str] = field(default_factory=list)
    finding_ids: list[str] = field(default_factory=list)
    annotation_ids: list[str] = field(default_factory=list)
    last_reviewed_at: str | None = None
    confidence: str | None = None
    ring_id: int = 4
    sweep_level: str | None = None

    def validate(self) -> list[str]:
        errors: list[str] = []
        if self.kind not in NODE_KINDS:
            errors.append(f"Invalid kind: {self.kind}")
        if self.status not in NODE_STATUSES:
            errors.append(f"Invalid status: {self.status}")
        return errors


@dataclass
class AuditMapEdge:
    from_node_id: str
    to_node_id: str
    relation: str = "contains"

    def validate(self) -> list[str]:
        if self.relation not in EDGE_RELATIONS:
            return [f"Invalid relation: {self.relation}"]
        return []


@dataclass
class AuditAnnotation:
    id: str
    file: str
    kind: str
    severity: str
    note: str
    status: str = "open"
    origin: str = "human"
    horizon: str | None = None
    # UNSTABLE: None until Gate 5
    symbol: str | None = None
    line: int | None = None
    finding: str | None = None
    assigned: str | None = None
    expires_when: str | None = None
    created: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    title: str | None = None
    body: str | None = None
    affects: list[str] = field(default_factory=list)
    adr_refs: list[str] = field(default_factory=list)
    git_issue: str | None = None
    reviewed_by: str | None = None
    reviewed_at: str | None = None
    checklist: list[dict[str, Any]] = field(default_factory=list)
    # Graph-linked (schema v2): manifest node ids validated at write time (warnings only).
    blocks: list[str] = field(default_factory=list)
    requires: list[str] = field(default_factory=list)
    phase: int | None = None
    pipeline_refs: list[str] = field(default_factory=list)
    tool_refs: list[str] = field(default_factory=list)
    elicitation_trigger: bool = False

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dict (log form).

        Compatible with YAML sidecar format and MCP wire format.
        """
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AuditAnnotation:
        """Deserialize from dict (exp form).

        Delegates to audit_annotation_from_dict which handles unknown keys
        and type coercion.
        """
        from forge.tools.audit.annotations import audit_annotation_from_dict

        return audit_annotation_from_dict(data)

    def to_yaml_dict(self) -> dict[str, Any]:
        """Serialize to YAML-compatible dict.

        Drops None values for clean YAML output.
        """
        return {k: v for k, v in self.to_dict().items() if v is not None and v != [] and v != {}}


@dataclass
class AuditMapBundle:
    bundle_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    schema_version: str = BUNDLE_SCHEMA_VERSION
    document_kind: str = DOCUMENT_KIND
    session_id: str = ""
    repo: dict = field(default_factory=dict)
    generated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    generator_version: str = ""
    inputs: dict = field(default_factory=dict)
    # UNSTABLE: None until node_ids stable (Gate 5); DO NOT compute until then
    topology_hash: str | None = None
    warnings: list[str] = field(default_factory=list)
    stats: dict = field(default_factory=dict)
    nodes: list[AuditMapNode] = field(default_factory=list)
    edges: list[AuditMapEdge] = field(default_factory=list)
    cross_ring_edges: list[AuditMapEdge] = field(default_factory=list)
    coverage: dict = field(default_factory=dict)
    rings_summary: dict = field(default_factory=dict)
    provenance: dict = field(default_factory=dict)

    def compute_coverage(self) -> dict:
        by_status = {s: 0 for s in NODE_STATUSES}
        by_kind = {k: 0 for k in NODE_KINDS}
        for node in self.nodes:
            if node.status in by_status:
                by_status[node.status] += 1
            if node.kind in by_kind:
                by_kind[node.kind] += 1
        total = len(self.nodes)
        reviewed = by_status["reviewed_with_findings"] + by_status["verified_clean"]
        pct = round(reviewed / total * 100) if total > 0 else 0
        return {
            "total": total,
            "reviewed": reviewed,
            "pct_reviewed": pct,
            "by_status": by_status,
            "by_kind": by_kind,
        }

    def compute_rings_summary(self) -> dict[int, dict[str, int]]:
        out: dict[int, dict[str, int]] = {}
        for node in self.nodes:
            rid = int(getattr(node, "ring_id", 4) or 4)
            slot = out.setdefault(rid, {"total": 0, "reviewed": 0, "blocked": 0})
            slot["total"] += 1
            if node.status in ("reviewed_with_findings", "verified_clean"):
                slot["reviewed"] += 1
            if node.status == "blocked":
                slot["blocked"] += 1
        return out


def bundle_to_json(bundle: AuditMapBundle, indent: int = 2) -> str:
    return json.dumps(asdict(bundle), indent=indent)


def _node_from_dict(n: dict) -> AuditMapNode:
    allowed = {f.name for f in AuditMapNode.__dataclass_fields__.values()}  # type: ignore[attr-defined]
    clean = {k: v for k, v in n.items() if k in allowed}
    return AuditMapNode(**clean)


def _edge_from_dict(e: dict) -> AuditMapEdge:
    allowed = {f.name for f in AuditMapEdge.__dataclass_fields__.values()}  # type: ignore[attr-defined]
    clean = {k: v for k, v in e.items() if k in allowed}
    return AuditMapEdge(**clean)


def bundle_from_json(data: str) -> AuditMapBundle:
    raw = json.loads(data)
    nodes_raw = raw.pop("nodes", [])
    edges_raw = raw.pop("edges", [])
    cross_raw = raw.pop("cross_ring_edges", [])
    raw.pop("coverage", None)
    allowed_b = {f.name for f in AuditMapBundle.__dataclass_fields__.values()}  # type: ignore[attr-defined]
    bundle_raw = {k: v for k, v in raw.items() if k in allowed_b}
    bundle = AuditMapBundle(**bundle_raw)
    bundle.nodes = [_node_from_dict(n) if isinstance(n, dict) else n for n in nodes_raw]
    bundle.edges = [_edge_from_dict(e) if isinstance(e, dict) else e for e in edges_raw]
    bundle.cross_ring_edges = [_edge_from_dict(e) if isinstance(e, dict) else e for e in cross_raw]
    bundle.coverage = bundle.compute_coverage()
    bundle.rings_summary = bundle.compute_rings_summary()
    return bundle


def load_bundle(path: Path | str) -> AuditMapBundle:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(
            f"Bundle not found: {p}\nRun: forge audit map take",
        )
    return bundle_from_json(p.read_text(encoding="utf-8"))


def save_bundle(bundle: AuditMapBundle, path: Path | str) -> None:
    bundle.coverage = bundle.compute_coverage()
    bundle.rings_summary = bundle.compute_rings_summary()
    Path(path).write_text(bundle_to_json(bundle), encoding="utf-8")


def verify_l1_closure(bundle: AuditMapBundle) -> dict[str, int | float | str]:
    rank = {"L0": 0, "L1": 1, "L2": 2, "L3": 3, "L4": 4}
    default_level = str(bundle.inputs.get("sweep_level") or "")
    total = len(bundle.nodes)
    l1_or_above = 0
    below_l1 = 0
    for node in bundle.nodes:
        lvl = str(getattr(node, "sweep_level", None) or default_level or "")
        if rank.get(lvl, -1) >= 1:
            l1_or_above += 1
        else:
            below_l1 += 1
    coverage_pct = round((l1_or_above / total) * 100, 2) if total else 0.0
    return {
        "total_nodes": total,
        "l1_or_above": l1_or_above,
        "below_l1": below_l1,
        "coverage_pct": coverage_pct,
        "verdict": "pass" if below_l1 == 0 else "fail",
        "pass_threshold": 100,
    }
