from __future__ import annotations

import json
from pathlib import Path

from forge.tools.audit.bundle import AuditMapBundle, AuditMapNode
from forge.tools.audit.map_take import run_audit_map_take
from forge.tools.audit.sweep import (
    L2_ADDITIONAL_BRANCHES,
    STANDARD_L1_BRANCHES,
    get_branches_for_sweep,
)


def _write_scan(project: Path) -> None:
    scan = project / "scan"
    scan.mkdir(parents=True, exist_ok=True)
    payload = {
        "screens": [{"file": "forge/tools/audit/a.py", "name": "A"}],
        "controllers": [{"file": "forge/tools/audit/c.py", "name": "C"}],
        "orphans": [],
        "severed_connections": [],
        "frontmatter_issues": [],
    }
    (scan / "validation.json").write_text(json.dumps(payload), encoding="utf-8")


def _id(_: Path) -> str:
    return "x"


def test_l0_produces_no_meta_calls(tmp_path: Path, monkeypatch) -> None:
    _write_scan(tmp_path)
    calls: list[str] = []

    def _meta(*args, **kwargs):
        calls.append("x")
        return {"exit_code": 0, "impact_summary": {"failures": []}}

    monkeypatch.setattr("forge.tools.audit.map_take.run_meta_for_branch", _meta)
    result = run_audit_map_take(
        tmp_path,
        session_id=None,
        sweep_level="L0",
        mode="git",
        at_path=None,
        depth=3,
        traverse="bfs",
        out=tmp_path / "audit-map.bundle.json",
        get_git_branch=_id,
        get_git_sha=_id,
        get_forge_version=lambda: "1",
        get_manifest_source=lambda _: "manifest.yaml (root)",
    )
    assert calls == []
    assert result["bundle"].inputs["sweep_level"] == "L0"


def test_l1_includes_standard_branches(tmp_path: Path) -> None:
    branches = get_branches_for_sweep("L1", tmp_path)
    assert branches == STANDARD_L1_BRANCHES


def test_l2_includes_l1_plus_additional(tmp_path: Path) -> None:
    branches = get_branches_for_sweep("L2", tmp_path)
    for p in STANDARD_L1_BRANCHES:
        assert p in branches
    for p in L2_ADDITIONAL_BRANCHES:
        assert p in branches


def test_l4_only_includes_blocked_nodes(tmp_path: Path) -> None:
    b = AuditMapBundle(
        nodes=[
            AuditMapNode(node_id="branch/a", kind="branch", path="a", status="blocked"),
            AuditMapNode(node_id="branch/b", kind="branch", path="b", status="not_started"),
            AuditMapNode(node_id="branch/c", kind="branch", path="c", status="blocked"),
        ]
    )
    blocked = get_branches_for_sweep("L4", tmp_path, existing_bundle=b)
    assert blocked == ["a", "c"]


def test_sweep_level_recorded_in_bundle_inputs(tmp_path: Path, monkeypatch) -> None:
    _write_scan(tmp_path)

    def _meta(*args, **kwargs):
        return {"exit_code": 0, "impact_summary": {"failures": []}}

    monkeypatch.setattr("forge.tools.audit.map_take.run_meta_for_branch", _meta)
    result = run_audit_map_take(
        tmp_path,
        session_id=None,
        sweep_level="L2",
        mode="git",
        at_path=None,
        depth=3,
        traverse="bfs",
        out=tmp_path / "audit-map.bundle.json",
        get_git_branch=_id,
        get_git_sha=_id,
        get_forge_version=lambda: "1",
        get_manifest_source=lambda _: "manifest.yaml (root)",
    )
    bundle = result["bundle"]
    assert bundle.inputs["sweep_level"] == "L2"
    assert bundle.inputs["traverse"] == "dfs"

