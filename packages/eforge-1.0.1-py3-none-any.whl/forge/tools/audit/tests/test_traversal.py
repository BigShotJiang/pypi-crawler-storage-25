from __future__ import annotations

from forge.tools.audit.bundle import AuditMapEdge, AuditMapNode
from forge.tools.audit.traversal import (
    bfs_queue,
    dfs_queue,
    get_next_reason,
    risk_first_queue,
)


def _nodes() -> list[AuditMapNode]:
    return [
        AuditMapNode(node_id="b1", kind="branch", status="not_started"),
        AuditMapNode(node_id="m1", kind="module", status="verified_clean"),
        AuditMapNode(node_id="blk", kind="module", status="blocked"),
        AuditMapNode(node_id="crit", kind="feature_slice", status="not_started", critical=True),
    ]


def test_bfs_returns_results() -> None:
    q = bfs_queue(_nodes(), edges=None, max_items=5)
    assert len(q) >= 1


def test_dfs_returns_results() -> None:
    q = dfs_queue(_nodes(), edges=None, max_items=5)
    assert len(q) >= 1


def test_risk_first_puts_blocked_first() -> None:
    nodes = [
        AuditMapNode(node_id="a", kind="module", status="not_started"),
        AuditMapNode(node_id="b", kind="module", status="blocked"),
    ]
    q = risk_first_queue(nodes, max_items=10, exclude_status=[])
    assert q[0].node_id == "b"


def test_risk_first_puts_critical_before_indirect() -> None:
    nodes = [
        AuditMapNode(node_id="i", kind="module", status="observed_indirectly"),
        AuditMapNode(node_id="c", kind="module", status="not_started", critical=True),
    ]
    q = risk_first_queue(nodes, max_items=10, exclude_status=[])
    assert q[0].node_id == "c"


def test_queue_excludes_verified_clean_by_default() -> None:
    nodes = _nodes()
    q = risk_first_queue(nodes, max_items=10)
    assert all(n.status != "verified_clean" for n in q)


def test_get_next_reason_for_blocked() -> None:
    n = AuditMapNode(node_id="x", kind="module", status="blocked")
    assert "blocked" in get_next_reason(n).lower()


def test_get_next_reason_for_observed_indirectly() -> None:
    n = AuditMapNode(node_id="x", kind="module", status="observed_indirectly")
    assert "scope" in get_next_reason(n).lower() or "reviewed" in get_next_reason(n).lower()


def test_bfs_with_contains_edges_orders_children() -> None:
    nodes = [
        AuditMapNode(node_id="root", kind="branch", status="not_started"),
        AuditMapNode(node_id="child", kind="module", status="not_started"),
    ]
    edges = [AuditMapEdge("root", "child", "contains")]
    q = bfs_queue(nodes, edges, root_id="root", exclude_status=[], max_items=10)
    ids = [n.node_id for n in q]
    assert "root" in ids
    assert "child" in ids
