from __future__ import annotations

import json
from pathlib import Path

from forge.tools.audit.bundle import AuditMapBundle, AuditMapEdge, AuditMapNode
from forge.tools.audit.map_take import run_audit_map_take
from forge.tools.audit.node_builder import (
    build_cross_ring_edges,
    build_nodes_from_manifest_graph,
    build_nodes_from_registry,
)
from forge.tools.audit.renderer import render_rings_mermaid
from forge.tools.audit.traversal import blast_radius_all_rings
from forge.tools.manifest.graph import build_manifest_graph


def _id(_: Path) -> str:
    return "x"


def test_bundle_nodes_have_ring_id() -> None:
    n = AuditMapNode(node_id="x")
    assert n.ring_id in (1, 2, 3, 4, 5)


def test_ring1_nodes_from_registry() -> None:
    reg = {"projects": {"forge": {"id": "forge", "name": "forge", "path": "/tmp/forge"}}}
    nodes = build_nodes_from_registry(reg)
    assert nodes and nodes[0].ring_id == 1


def test_ring2_nodes_from_manifest() -> None:
    g = build_manifest_graph(
        Path("."),
        manifest_data={"screens": [{"name": "Home", "file": "lib/home.dart", "watches": ["C"]}], "controllers": [{"name": "C", "file": "lib/c.dart"}]},
    )
    nodes, edges = build_nodes_from_manifest_graph(g)
    assert any(n.ring_id == 2 for n in nodes)
    assert isinstance(edges, list)


def test_cross_ring_edges_detected() -> None:
    r1 = [AuditMapNode(node_id="ring1/forge", label="forge", ring_id=1)]
    r2 = [AuditMapNode(node_id="ring2/screen/home", path="lib/home.dart", label="Home", ring_id=2)]
    r4 = [AuditMapNode(node_id="feature_slice/lib.home", path="lib/home.dart", label="home.dart", ring_id=4)]
    edges = build_cross_ring_edges(r1, r2, r4)
    assert any(e.relation == "implements" for e in edges)


def test_blast_radius_crosses_rings() -> None:
    n4 = AuditMapNode(node_id="n4", ring_id=4)
    n2 = AuditMapNode(node_id="n2", ring_id=2)
    n1 = AuditMapNode(node_id="n1", ring_id=1)
    b = AuditMapBundle(
        nodes=[n4, n2, n1],
        edges=[],
        cross_ring_edges=[
            AuditMapEdge("n4", "n2", "implements"),
            AuditMapEdge("n2", "n1", "belongs_to"),
        ],
    )
    br = blast_radius_all_rings("n4", b)
    assert 2 in br and 1 in br


def test_rings_summary_computed() -> None:
    b = AuditMapBundle(
        nodes=[
            AuditMapNode(node_id="a", ring_id=1, status="not_started"),
            AuditMapNode(node_id="b", ring_id=2, status="verified_clean"),
        ]
    )
    rs = b.compute_rings_summary()
    assert rs[1]["total"] == 1
    assert rs[2]["reviewed"] == 1


def test_mermaid_renders_subgraphs() -> None:
    b = AuditMapBundle(
        nodes=[
            AuditMapNode(node_id="r1/a", ring_id=1, label="forge"),
            AuditMapNode(node_id="r2/b", ring_id=2, label="Home"),
        ]
    )
    out = render_rings_mermaid(b, rings=[1, 2])
    assert "subgraph Ring1" in out
    assert "subgraph Ring2" in out


def test_l0_only_ring1_nodes(tmp_path: Path, monkeypatch) -> None:
    (tmp_path / "scan").mkdir(parents=True, exist_ok=True)
    (tmp_path / "scan" / "validation.json").write_text(json.dumps({"screens": [], "controllers": []}), encoding="utf-8")

    monkeypatch.setattr(
        "forge.tools.audit.map_take.load_registry",
        lambda: {"projects": {"forge": {"id": "forge", "name": "forge", "path": str(tmp_path)}}},
    )
    monkeypatch.setattr("forge.tools.audit.map_take.run_meta_for_branch", lambda *a, **k: {"exit_code": 0, "impact_summary": {"failures": []}})

    out = run_audit_map_take(
        tmp_path,
        session_id=None,
        sweep_level="L0",
        mode="git",
        at_path=None,
        depth=3,
        traverse="bfs",
        out=tmp_path / "audit-map.bundle.json",
        get_git_branch=_id,
        get_git_sha=_id,
        get_forge_version=lambda: "1",
        get_manifest_source=lambda _: "manifest.yaml (root)",
    )
    assert all(int(getattr(n, "ring_id", 4) or 4) == 1 for n in out["bundle"].nodes)
