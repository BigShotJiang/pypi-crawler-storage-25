from __future__ import annotations

from forge.tools.audit.bundle import AuditMapBundle, AuditMapEdge, AuditMapNode
from forge.tools.audit.renderer import render_dot, render_mermaid, render_obsidian, render_table


def _sample_bundle() -> AuditMapBundle:
    return AuditMapBundle(
        nodes=[
            AuditMapNode(node_id="k/m1", kind="module", path="a.py", label="a", status="blocked"),
            AuditMapNode(node_id="k/m2", kind="module", path="b.py", label="b", status="not_started", annotation_ids=["ANNOT-001"]),
        ],
        edges=[AuditMapEdge("k/m1", "k/m2", "contains")],
    )


def test_mermaid_coverage_deterministic() -> None:
    b = _sample_bundle()
    a = render_mermaid(b, focus="coverage")
    b2 = render_mermaid(b, focus="coverage")
    assert a == b2
    assert "graph TD" in a


def test_mermaid_branch_deterministic() -> None:
    b = _sample_bundle()
    assert render_mermaid(b, focus="branch") == render_mermaid(b, focus="branch")


def test_stubbed_focus_returns_stub_message() -> None:
    b = _sample_bundle()
    for focus in ("calls", "deps", "contracts", "change-impact", "drift", "annotations"):
        out = render_mermaid(b, focus=focus)
        assert "Gate 5" in out
        assert "coverage" in out or "branch" in out


def test_mermaid_contains_node_label() -> None:
    b = _sample_bundle()
    out = render_mermaid(b, focus="coverage")
    assert "a" in out or "b" in out


def test_table_has_correct_totals() -> None:
    b = _sample_bundle()
    b.coverage = b.compute_coverage()
    t = render_table(b)
    assert "Total: 2" in t


def test_obsidian_uses_wikilinks() -> None:
    b = _sample_bundle()
    o = render_obsidian(b)
    assert "[[" in o


def test_dot_contains_node_ids() -> None:
    b = _sample_bundle()
    d = render_dot(b, focus="coverage")
    assert "digraph" in d
    assert "k_m1" in d or "m1" in d
