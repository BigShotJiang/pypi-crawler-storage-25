from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner

from forge.commands.audit_cmd import audit_group
from forge.tools.audit.annotations import (
    ValidationError,
    ANNOTATION_QUERY_RESULT_KIND,
    annotation_query_mcp_envelope,
    annotation_to_dict,
    find_annotation_by_id,
    query_annotations,
    resolve_annotation_from,
    resolve_annotation_kind,
    validate_annotation,
    write_annotation,
)
from forge.tools.audit.bundle import AuditAnnotation, AuditMapNode
from forge.tools.audit.node_builder import attach_annotations_to_nodes


def _touch_forge_root(root: Path) -> None:
    (root / ".forge").mkdir(parents=True, exist_ok=True)


def test_resolve_annotation_kind_prefers_explicit_kind() -> None:
    assert resolve_annotation_kind(marker="obs", kind="risk") == "risk"


def test_resolve_annotation_kind_marker_map() -> None:
    assert resolve_annotation_kind(marker="obs", kind=None) == "gap"
    assert resolve_annotation_kind(marker="question", kind="") == "question"
    assert resolve_annotation_kind(marker="surprise", kind=None) == "risk"


def test_query_filters_by_kind(tmp_path: Path) -> None:
    _touch_forge_root(tmp_path)
    d = tmp_path / "pkg"
    d.mkdir()
    write_annotation(
        d,
        AuditAnnotation(id="ANNOT-001", file="pkg/x.py", kind="debt", severity="low", note="n"),
    )
    rows = query_annotations(tmp_path, kind="debt", use_index=False)
    assert rows["level"] == 2
    assert rows["total"] == 1
    assert rows["results"][0]["kind"] == "debt"


def test_query_filters_by_severity(tmp_path: Path) -> None:
    _touch_forge_root(tmp_path)
    d = tmp_path / "a"
    d.mkdir()
    write_annotation(
        d,
        AuditAnnotation(id="ANNOT-001", file="a/f.py", kind="risk", severity="high", note="h"),
    )
    rows = query_annotations(tmp_path, severity="high", use_index=False)
    assert rows["level"] == 2
    assert rows["total"] == 1


def test_query_filters_by_status(tmp_path: Path) -> None:
    _touch_forge_root(tmp_path)
    d = tmp_path / "b"
    d.mkdir()
    ann = AuditAnnotation(id="ANNOT-001", file="b/g.py", kind="gap", severity="medium", note="m", status="resolved")
    write_annotation(d, ann)
    open_rows = query_annotations(tmp_path, status="open", use_index=False)
    assert open_rows["level"] == 1
    assert open_rows["groups"] == {}


def test_query_filters_by_assigned(tmp_path: Path) -> None:
    _touch_forge_root(tmp_path)
    d = tmp_path / "c"
    d.mkdir()
    write_annotation(
        d,
        AuditAnnotation(
            id="ANNOT-001",
            file="c/h.py",
            kind="question",
            severity="low",
            note="q",
            assigned="cowork",
        ),
    )
    rows = query_annotations(tmp_path, assigned="cowork", use_index=False)
    assert rows["level"] == 2
    assert rows["total"] == 1


def test_query_returns_empty_when_no_sidecars(tmp_path: Path) -> None:
    assert query_annotations(tmp_path, use_index=False) == {
        "level": 0,
        "total": 0,
        "by_origin": {},
        "by_kind": {},
        "by_status": {},
        "by_horizon": {},
    }


def test_annotation_query_mcp_envelope_documents_paging_and_fingerprint_spec(tmp_path: Path) -> None:
    _touch_forge_root(tmp_path)
    d = tmp_path / "pkg"
    d.mkdir()
    write_annotation(
        d,
        AuditAnnotation(id="ANNOT-001", file="pkg/x.py", kind="debt", severity="low", note="n"),
    )
    env = annotation_query_mcp_envelope(tmp_path, use_index=False, limit=5, offset=0)
    assert env["result_kind"] == ANNOTATION_QUERY_RESULT_KIND
    assert env["schema_version"] == 1
    assert env["paging"]["total_matches"] == 1
    assert env["paging"]["returned_rows"] == 1
    assert env["sidecar_cache"]["fingerprint_spec_id"]
    assert len(env["sidecar_cache"]["workspace_fingerprint_hex"]) == 64


def test_annotation_query_horizon_filter_consistent_warm_and_cold_index(tmp_path: Path) -> None:
    _touch_forge_root(tmp_path)
    d = tmp_path / "pkg"
    d.mkdir()
    write_annotation(
        d,
        AuditAnnotation(
            id="ANNOT-201",
            file="pkg/a.py",
            kind="debt",
            severity="high",
            note="in current horizon",
            status="open",
            horizon="current",
        ),
    )
    write_annotation(
        d,
        AuditAnnotation(
            id="ANNOT-202",
            file="pkg/b.py",
            kind="debt",
            severity="high",
            note="in next horizon",
            status="open",
            horizon="next",
        ),
    )
    cold = annotation_query_mcp_envelope(
        tmp_path,
        status="open",
        severity="high",
        horizon="current",
        use_index=False,
        limit=100,
        offset=0,
    )
    warm = annotation_query_mcp_envelope(
        tmp_path,
        status="open",
        severity="high",
        horizon="current",
        use_index=True,
        limit=100,
        offset=0,
    )
    cold_ids = {str(row.get("id")) for row in cold.get("annotations", []) if isinstance(row, dict)}
    warm_ids = {str(row.get("id")) for row in warm.get("annotations", []) if isinstance(row, dict)}
    assert cold_ids == {"ANNOT-201"}
    assert warm_ids == cold_ids


def test_pruned_walk_skips_git_and_respects_limit_with_index(tmp_path: Path) -> None:
    from forge.tools.audit.index import AnnotationIndex

    _touch_forge_root(tmp_path)
    src = tmp_path / "src"
    src.mkdir()
    write_annotation(
        src,
        AuditAnnotation(id="ANNOT-001", file="src/a.py", kind="debt", severity="low", note="ok"),
    )
    nested_git = tmp_path / ".git" / "hooks"
    nested_git.mkdir(parents=True)
    write_annotation(
        nested_git,
        AuditAnnotation(id="ANNOT-999", file="hooks/x", kind="risk", severity="high", note="hidden"),
    )

    all_rows = query_annotations(tmp_path, kind="debt", use_index=False)
    assert all_rows["total"] == 1
    assert all_rows["results"][0]["id"] == "ANNOT-001"

    db = tmp_path / ".forge" / "audit-index.db"
    AnnotationIndex(db).rebuild(tmp_path)
    page = query_annotations(tmp_path, kind="debt", use_index=True, limit=1, offset=0)
    assert page["total"] == 1
    assert page["results"][0]["id"] == "ANNOT-001"


def test_write_and_read_annotation_round_trip(tmp_path: Path) -> None:
    _touch_forge_root(tmp_path)
    d = tmp_path / "d"
    d.mkdir()
    ann = AuditAnnotation(id="ANNOT-010", file="d/z.py", kind="stub", severity="medium", note="z")
    write_annotation(d, ann)
    sc = tmp_path / ".forge" / "annotations" / "ANNOT-010.yaml"
    assert sc.is_file()
    found = find_annotation_by_id(tmp_path, "ANNOT-010")
    assert found is not None
    _, read_back = found
    assert read_back.note == "z"


def test_attach_annotations_marks_critical() -> None:
    nodes = [AuditMapNode(node_id="m/x", kind="module", path="lib/foo.py", label="foo")]
    anns = [
        AuditAnnotation(
            id="ANNOT-001",
            file="lib/foo.py",
            kind="debt",
            severity="high",
            note="bad",
        ),
    ]
    attach_annotations_to_nodes(nodes, anns)
    assert nodes[0].critical is True
    assert "ANNOT-001" in nodes[0].annotation_ids


def test_annotation_to_dict_serializable() -> None:
    ann = AuditAnnotation(id="ANNOT-001", file="x", kind="guard", severity="low", note="n")
    d = annotation_to_dict(ann)
    assert d["id"] == "ANNOT-001"
    assert d["severity"] == "low"


def test_validate_annotation_catches_bad_kind() -> None:
    ann = AuditAnnotation(id="ANNOT-001", file="x", kind="invalid", severity="low", note="n")
    errs = validate_annotation(ann)
    assert errs


def test_validate_finding_requires_file() -> None:
    ann = AuditAnnotation(id="ANNOT-001", file="", kind="finding", severity="low", note="n")
    with pytest.raises(ValidationError, match="file is required"):
        validate_annotation(ann)


def test_validate_architecture_debt_requires_file() -> None:
    ann = AuditAnnotation(id="ANNOT-001", file="", kind="architecture-debt", severity="low", note="n")
    with pytest.raises(ValidationError, match="file is required"):
        validate_annotation(ann)


def test_validate_verification_checkpoint_allows_empty_file() -> None:
    ann = AuditAnnotation(
        id="ANNOT-001",
        file="",
        kind="verification-checkpoint",
        severity="high",
        note="t",
        checklist=[{"item": "one", "confirmed": False}],
    )
    assert validate_annotation(ann) == []


def test_create_auto_generates_id(tmp_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(
        audit_group,
        [
            "annotate",
            "create",
            "--project-path",
            str(tmp_path),
            "--file",
            "src/a.py",
            "--kind",
            "debt",
            "--severity",
            "low",
            "--note",
            "n",
        ],
    )
    assert result.exit_code == 0
    assert "Created: ANNOT-001" in result.output


def test_create_validates_kind_enum(tmp_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(
        audit_group,
        [
            "annotate",
            "create",
            "--project-path",
            str(tmp_path),
            "--file",
            "src/a.py",
            "--kind",
            "bad",
            "--severity",
            "low",
            "--note",
            "n",
        ],
    )
    assert result.exit_code != 0


def test_create_validates_severity_enum(tmp_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(
        audit_group,
        [
            "annotate",
            "create",
            "--project-path",
            str(tmp_path),
            "--file",
            "src/a.py",
            "--kind",
            "debt",
            "--severity",
            "critical",
            "--note",
            "n",
        ],
    )
    assert result.exit_code != 0


def test_update_only_modifies_provided_fields(tmp_path: Path) -> None:
    _touch_forge_root(tmp_path)
    d = tmp_path / "src"
    d.mkdir(parents=True)
    write_annotation(
        d,
        AuditAnnotation(id="ANNOT-001", file="src/a.py", kind="debt", severity="low", note="orig", assigned="x"),
    )
    runner = CliRunner()
    result = runner.invoke(
        audit_group,
        [
            "annotate",
            "update",
            "--project-path",
            str(tmp_path),
            "--id",
            "ANNOT-001",
            "--assigned",
            "stage3",
        ],
    )
    assert result.exit_code == 0
    found = find_annotation_by_id(tmp_path, "ANNOT-001")
    assert found is not None
    _, ann = found
    assert ann.assigned == "stage3"
    assert ann.note == "orig"


def test_resolve_sets_status_resolved(tmp_path: Path) -> None:
    _touch_forge_root(tmp_path)
    d = tmp_path / "src"
    d.mkdir(parents=True)
    write_annotation(
        d,
        AuditAnnotation(id="ANNOT-001", file="src/a.py", kind="debt", severity="low", note="orig"),
    )
    runner = CliRunner()
    result = runner.invoke(
        audit_group,
        [
            "annotate",
            "resolve",
            "--project-path",
            str(tmp_path),
            "--id",
            "ANNOT-001",
            "--resolution-note",
            "done",
        ],
    )
    assert result.exit_code == 0
    found = find_annotation_by_id(tmp_path, "ANNOT-001")
    assert found is not None
    _, ann = found
    assert ann.status == "resolved"
    assert "resolved: done" in ann.note


def test_list_filters_by_status(tmp_path: Path) -> None:
    _touch_forge_root(tmp_path)
    d = tmp_path / "src"
    d.mkdir(parents=True)
    write_annotation(
        d,
        AuditAnnotation(id="ANNOT-001", file="src/a.py", kind="debt", severity="low", note="o1", status="open"),
    )
    write_annotation(
        d,
        AuditAnnotation(id="ANNOT-002", file="src/b.py", kind="debt", severity="low", note="o2", status="resolved"),
    )
    runner = CliRunner()
    result = runner.invoke(
        audit_group,
        ["annotate", "list", "--project-path", str(tmp_path), "--status", "open"],
    )
    assert result.exit_code == 0
    assert "ANNOT-001" in result.output
    assert "ANNOT-002" not in result.output


def test_schema_flag_returns_valid_yaml() -> None:
    runner = CliRunner()
    result = runner.invoke(audit_group, ["query", "--schema"])
    assert result.exit_code == 0
    data = __import__("yaml").safe_load(result.output)
    assert isinstance(data, dict)
    assert "annotation" in data


def test_resolve_from_node_id_and_symbol(tmp_path: Path) -> None:
    _touch_forge_root(tmp_path)
    d = tmp_path / "src"
    d.mkdir(parents=True)
    write_annotation(
        d,
        AuditAnnotation(
            id="ANNOT-042",
            file="src/login.py",
            kind="risk",
            severity="medium",
            note="login mismatch",
            title="login mismatch",
            symbol="login",
            affects=["module:login"],
        ),
    )
    by_node = resolve_annotation_from(tmp_path, node_id="module:login")
    assert by_node["annotation_id"] == "ANNOT-042"
    assert by_node["resolved_from"] == "node_id"
    by_symbol = resolve_annotation_from(tmp_path, resolve_from="login")
    assert by_symbol["annotation_id"] == "ANNOT-042"
    assert by_symbol["resolved_from"] == "symbol"


def test_write_annotation_blocks_known_node_no_graph_warning(tmp_path: Path, caplog: pytest.LogCaptureFixture) -> None:
    import yaml

    from forge.tools.manifest.graph import build_manifest_graph

    _touch_forge_root(tmp_path)
    forge = tmp_path / ".forge"
    man = {
        "schema_version": 1,
        "name": "g",
        "type": "python",
        "version": "1.0.0",
        "modules": [{"id": "module/known", "name": "known", "path": "src/k.py"}],
    }
    (forge / "manifest.yaml").write_text(yaml.safe_dump(man, sort_keys=False), encoding="utf-8")
    g = build_manifest_graph(tmp_path)
    assert g.nodes
    known_id = g.nodes[0].id
    d = tmp_path / "src"
    d.mkdir(parents=True)
    (d / "k.py").write_text("", encoding="utf-8")
    ann = AuditAnnotation(
        id="ANNOT-GV",
        file="src/k.py",
        kind="gap",
        severity="low",
        note="n",
        blocks=[known_id],
    )
    with caplog.at_level("WARNING"):
        write_annotation(d, ann)
    assert not any("unknown manifest node id" in r.message for r in caplog.records)


def test_write_annotation_blocks_unknown_node_logs_warning(tmp_path: Path, caplog: pytest.LogCaptureFixture) -> None:
    import yaml

    _touch_forge_root(tmp_path)
    forge = tmp_path / ".forge"
    man = {
        "schema_version": 1,
        "name": "g",
        "type": "python",
        "version": "1.0.0",
        "modules": [{"id": "module/known", "name": "known", "path": "src/k.py"}],
    }
    (forge / "manifest.yaml").write_text(yaml.safe_dump(man, sort_keys=False), encoding="utf-8")
    d = tmp_path / "src"
    d.mkdir(parents=True)
    (d / "k.py").write_text("", encoding="utf-8")
    ann = AuditAnnotation(
        id="ANNOT-GW",
        file="src/k.py",
        kind="gap",
        severity="low",
        note="n",
        blocks=["module/phantom-xyz"],
    )
    with caplog.at_level("WARNING"):
        write_annotation(d, ann)
    assert any("unknown manifest node id" in r.message for r in caplog.records)
