from __future__ import annotations

import json
from pathlib import Path

import pytest

from forge.tools.audit.bundle import (
    AuditMapBundle,
    AuditMapEdge,
    AuditMapNode,
    bundle_from_json,
    bundle_to_json,
    load_bundle,
    save_bundle,
)
from forge.tools.audit.node_builder import build_nodes_from_scan


def test_coverage_counts_correctly() -> None:
    b = AuditMapBundle(
        nodes=[
            AuditMapNode(node_id="a", kind="module", status="verified_clean"),
            AuditMapNode(node_id="b", kind="module", status="not_started"),
            AuditMapNode(node_id="c", kind="branch", status="reviewed_with_findings"),
        ],
    )
    cov = b.compute_coverage()
    assert cov["total"] == 3
    assert cov["reviewed"] == 2
    assert cov["by_status"]["verified_clean"] == 1
    assert cov["by_kind"]["module"] == 2


def test_bundle_serializes_round_trip() -> None:
    b = AuditMapBundle(
        session_id="s1",
        nodes=[AuditMapNode(node_id="n1", kind="command", path="x", label="X")],
        edges=[AuditMapEdge("n1", "n2", "contains")],
    )
    s = bundle_to_json(b)
    b2 = bundle_from_json(s)
    assert b2.session_id == "s1"
    assert len(b2.nodes) == 1
    assert b2.nodes[0].node_id == "n1"
    assert len(b2.edges) == 1
    assert b2.edges[0].to_node_id == "n2"


def test_bundle_from_scan_output(tmp_path: Path) -> None:
    scan_dir = tmp_path / "scan"
    scan_dir.mkdir()
    payload = {
        "screens": [{"file": "lib/a.dart", "name": "AScreen"}],
        "controllers": [{"file": "lib/c.dart", "name": "C"}],
        "orphans": [],
        "severed_connections": [],
        "frontmatter_issues": [],
    }
    (scan_dir / "validation.json").write_text(json.dumps(payload), encoding="utf-8")
    nodes, edges = build_nodes_from_scan(scan_dir / "validation.json")
    assert len(nodes) >= 2
    kinds = {n.kind for n in nodes}
    assert "feature_slice" in kinds


def test_observed_indirectly_not_counted_as_reviewed() -> None:
    b = AuditMapBundle(
        nodes=[
            AuditMapNode(node_id="o", kind="module", status="observed_indirectly"),
            AuditMapNode(node_id="v", kind="module", status="verified_clean"),
        ],
    )
    cov = b.compute_coverage()
    assert cov["reviewed"] == 1


def test_topology_hash_field_is_none_by_default() -> None:
    b = AuditMapBundle()
    assert b.topology_hash is None


def test_canonical_id_is_none_by_default() -> None:
    n = AuditMapNode(node_id="x")
    assert n.canonical_id is None


def test_load_bundle_raises_if_not_found(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        load_bundle(tmp_path / "missing.json")


def test_save_and_load_round_trip(tmp_path: Path) -> None:
    p = tmp_path / "b.json"
    b = AuditMapBundle(nodes=[AuditMapNode(node_id="z", kind="doc", label="Z")])
    save_bundle(b, p)
    b2 = load_bundle(p)
    assert b2.nodes[0].node_id == "z"
