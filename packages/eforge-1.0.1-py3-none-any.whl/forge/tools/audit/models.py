from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class GateName(str, Enum):
    SCRATCH_TO_VERIFIED = "scratch_to_verified"
    VERIFIED_TO_MEMORY = "verified_to_memory"
    MEMORY_TO_CANONICAL = "memory_to_canonical"


class GateResult(str, Enum):
    PASS = "pass"
    FAIL = "fail"


class AuditEventKind(str, Enum):
    SESSION_STARTED = "session_started"
    NOTE_ADDED = "note_added"
    FINDING_PROMOTED = "finding_promoted"
    FINDING_REVIEWED = "finding_reviewed"
    MEMORY_PROMOTED = "memory_promoted"
    GATE_EVALUATED = "gate_evaluated"
    HANDOFF_WRITTEN = "handoff_written"
    SESSION_STATUS_CHANGED = "session_status_changed"


@dataclass(frozen=True)
class ActorIdentity:
    actor_id: str
    actor_type: str = "human"  # human|agent|service
    role: str = ""  # owner|maintainer|reviewer|...


@dataclass(frozen=True)
class Reference:
    type: str  # file|symbol|command|url|other
    value: str


@dataclass(frozen=True)
class GateDecision:
    gate_name: GateName
    result: GateResult
    reasons: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class NoteRecord:
    id: str
    timestamp: str
    area: str
    marker: str  # obs|question|surprise
    content: str
    refs: list[Reference] = field(default_factory=list)
    module_key: str = ""
    supersedes_note_id: str | None = None


@dataclass(frozen=True)
class FindingRecord:
    id: str
    title: str
    source_refs: list[Reference]
    finding: str
    implication: str
    status: str  # pending_review|approved|rejected
    severity: str  # blocker|high|normal|warn
    area: str
    module_key: str
    branch: str
    head_sha: str
    contradicts: list[str] = field(default_factory=list)
    supersedes: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class MemoryRecord:
    id: str
    derived_from: list[str]
    statement: str
    scope: str
    status: str  # candidate|canonical|superseded
    approved_by: str = ""
    approved_at: str = ""
    revalidate_when: list[str] = field(default_factory=list)
    branch: str = ""
    head_sha: str = ""
    supersedes: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class AuditEvent:
    event_id: str
    kind: AuditEventKind
    at: str
    actor: ActorIdentity
    branch: str
    head_sha: str
    payload: dict


@dataclass(frozen=True)
class SessionState:
    schema_version: int
    session_id: str
    repo_root: str
    branch: str
    head_sha: str
    started_at: str
    updated_at: str
    status: str  # active|paused|closed
    active_area: str = ""
    handoff_written: bool = False
    verified_pending_review_count: int = 0
    ready_to_promote_count: int = 0

