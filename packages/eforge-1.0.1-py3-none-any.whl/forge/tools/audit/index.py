from __future__ import annotations

import hashlib
import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .sidecar_walk import iter_sidecar_paths

logger = logging.getLogger(__name__)

# Machine-stable fingerprint contract (for MCP / tooling; not human prose).
SIDECAR_INDEX_FINGERPRINT_V1_ID = "forge.audit.sidecar_fingerprint_v1"
SIDECAR_INDEX_FINGERPRINT_SPEC: dict[str, Any] = {
    "id": SIDECAR_INDEX_FINGERPRINT_V1_ID,
    "algorithm": "sha256",
    "digest_hex_length": 64,
    "inputs": {
        "paths": "Resolved Path per pruned sidecar file, lexicographically sorted",
        "per_path": "mtime_ns and size_bytes from stat; OSError → literal ':missing' line",
        "line_format": "utf-8: {path}:{mtime_ns}:{size}\\n or {path}:missing\\n",
    },
    "walk": "forge.tools.audit.sidecar_walk.iter_sidecar_paths",
}

ANNOTATION_QUERY_SORT_KEYS: list[dict[str, str]] = [
    {"field": "severity", "order": "high_then_medium_then_low_then_other"},
    {"field": "file", "order": "ascending"},
    {"field": "id", "order": "ascending"},
]

_ORDER_SQL = (
    " ORDER BY CASE severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 "
    "WHEN 'low' THEN 2 ELSE 99 END, file, id"
)


def _iter_annotation_yaml_files(project_path: Path) -> list[Path]:
    ann_dir = project_path / ".forge" / "annotations"
    if not ann_dir.is_dir():
        return []
    return sorted([p for p in ann_dir.glob("ANNOT-*.yaml") if p.is_file()])


def fingerprint_sidecar_paths(paths: list[Path]) -> str:
    """Stable fingerprint from path list + mtime + size (paths should be sorted)."""
    h = hashlib.sha256()
    for p in paths:
        try:
            st = p.stat()
            h.update(f"{p}:{st.st_mtime_ns}:{st.st_size}\n".encode())
        except OSError:
            h.update(f"{p}:missing\n".encode())
    return h.hexdigest()


class AnnotationIndex:
    """
    SQLite cache over YAML sidecars. Source of truth is always YAML files.

    Freshness: sha256 of all sidecar paths + mtimes stored in metadata; recomputed
    on each query; if differs, rebuild before querying.

    Fallback: index fresh → use; stale → rebuild; missing → walk sidecars;
    corrupt → warn and walk sidecars.
    """

    def __init__(self, db_path: Path) -> None:
        self.db_path = Path(db_path)

    def _read_stored_fingerprint(self) -> str | None:
        if not self.db_path.is_file():
            return None
        try:
            with sqlite3.connect(self.db_path) as conn:
                row = conn.execute("SELECT value FROM metadata WHERE key = 'fingerprint'").fetchone()
                return str(row[0]) if row else None
        except sqlite3.Error:
            return None

    def stored_fingerprint(self) -> str | None:
        """Fingerprint last written to metadata (None if DB missing or unreadable)."""
        return self._read_stored_fingerprint()

    @staticmethod
    def match_where(
        *,
        kind: str | None = None,
        status: str | None = None,
        severity: str | None = None,
        assigned: str | None = None,
        finding: str | None = None,
        file: str | None = None,
        expires_when: str | None = None,
        horizon: str | None = None,
    ) -> tuple[str, list[Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        if kind:
            clauses.append("kind = ?")
            params.append(kind)
        if status:
            clauses.append("status = ?")
            params.append(status)
        if severity:
            clauses.append("severity = ?")
            params.append(severity)
        if assigned:
            clauses.append("assigned = ?")
            params.append(assigned)
        if finding:
            clauses.append("finding = ?")
            params.append(finding)
        if file:
            clauses.append("file LIKE ?")
            params.append(f"%{file}%")
        if expires_when:
            clauses.append("LOWER(COALESCE(expires_when,'')) LIKE ?")
            params.append(f"%{expires_when.lower()}%")
        if horizon:
            clauses.append("horizon = ?")
            params.append(horizon)
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        return where, params

    def freshness(self, project_path: Path) -> tuple[bool, str | None, str, int]:
        """
        Single pruned walk: (is_fresh, stored_fingerprint_or_none, current_fingerprint, sidecar_file_count).
        """
        project_path = project_path.resolve()
        paths = iter_sidecar_paths(project_path)
        fp_now = fingerprint_sidecar_paths(paths)
        stored = self._read_stored_fingerprint()
        if stored is None:
            return False, None, fp_now, len(paths)
        return stored == fp_now, stored, fp_now, len(paths)

    def is_fresh(self, project_path: Path) -> bool:
        fresh, _, _, _ = self.freshness(project_path)
        return fresh

    def ensure_index(self, project_path: Path) -> None:
        """One pruned walk; rebuild SQLite only when fingerprint differs or DB is missing."""
        project_path = project_path.resolve()
        paths = iter_sidecar_paths(project_path)
        fp = fingerprint_sidecar_paths(paths)
        stored = self._read_stored_fingerprint()
        if stored == fp and self.db_path.is_file():
            return
        self._rebuild_from_paths(project_path, paths, fp)

    def rebuild(self, project_path: Path) -> dict[str, Any]:
        """Rebuild SQLite from YAML sidecars. Returns build stats (one filesystem walk)."""
        project_path = project_path.resolve()
        paths = iter_sidecar_paths(project_path)
        fp = fingerprint_sidecar_paths(paths)
        return self._rebuild_from_paths(project_path, paths, fp)

    def _rebuild_from_paths(self, project_path: Path, paths: list[Path], fp: str) -> dict[str, Any]:
        built = datetime.now(timezone.utc).isoformat()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        ann_count = 0
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DROP TABLE IF EXISTS annotations")
            conn.execute("DROP TABLE IF EXISTS metadata")
            conn.execute(
                """CREATE TABLE metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )""",
            )
            conn.execute(
                """CREATE TABLE annotations (
                    id TEXT NOT NULL,
                    file TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    note TEXT NOT NULL,
                    status TEXT NOT NULL,
                    symbol TEXT,
                    line INTEGER,
                    finding TEXT,
                    assigned TEXT,
                    expires_when TEXT,
                    horizon TEXT,
                    created TEXT NOT NULL,
                    adr_refs_json TEXT NOT NULL,
                    git_issue TEXT,
                    sidecar_dir TEXT NOT NULL
                )""",
            )
            conn.execute("CREATE INDEX idx_ann_id ON annotations(id)")
            conn.execute("CREATE INDEX idx_ann_file ON annotations(file)")
            conn.execute("CREATE INDEX idx_ann_kind ON annotations(kind)")
            conn.execute("CREATE INDEX idx_ann_status ON annotations(status)")
            seen_ids: set[str] = set()
            for sidecar in paths:
                try:
                    import yaml

                    raw = yaml.safe_load(sidecar.read_text(encoding="utf-8")) or {}
                    sidecar_dir = str(sidecar.parent.resolve())
                    for ann in raw.get("annotations", []) or []:
                        if not isinstance(ann, dict):
                            continue
                        if not str(ann.get("id", "")).strip():
                            continue
                        ann_id = str(ann.get("id", ""))
                        if ann_id in seen_ids:
                            continue
                        adr = ann.get("adr_refs") or []
                        if not isinstance(adr, list):
                            adr = []
                        conn.execute(
                            """INSERT INTO annotations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                            (
                                ann_id,
                                str(ann.get("file", "")),
                                str(ann.get("kind", "")),
                                str(ann.get("severity", "")),
                                str(ann.get("note", "")),
                                str(ann.get("status", "open")),
                                ann.get("symbol"),
                                ann.get("line"),
                                ann.get("finding"),
                                ann.get("assigned"),
                                ann.get("expires_when"),
                                ann.get("horizon"),
                                str(ann.get("created", "")),
                                json.dumps(adr),
                                ann.get("git_issue"),
                                sidecar_dir,
                            ),
                        )
                        ann_count += 1
                        seen_ids.add(ann_id)
                except Exception as exc:
                    logger.warning("Skipping sidecar %s during index rebuild: %s", sidecar, exc)

            for ann_file in _iter_annotation_yaml_files(project_path):
                try:
                    import yaml

                    ann = yaml.safe_load(ann_file.read_text(encoding="utf-8")) or {}
                    if not isinstance(ann, dict):
                        continue
                    ann_id = str(ann.get("id", "")).strip()
                    if not ann_id or ann_id in seen_ids:
                        continue
                    adr = ann.get("adr_refs") or []
                    if not isinstance(adr, list):
                        adr = []
                    conn.execute(
                        """INSERT INTO annotations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (
                            ann_id,
                            str(ann.get("file", "")),
                            str(ann.get("kind", "")),
                            str(ann.get("severity", "")),
                            str(ann.get("note", "")),
                            str(ann.get("status", "open")),
                            ann.get("symbol"),
                            ann.get("line"),
                            ann.get("finding"),
                            ann.get("assigned"),
                            ann.get("expires_when"),
                            ann.get("horizon"),
                            str(ann.get("created", "")),
                            json.dumps(adr),
                            ann.get("git_issue"),
                            str(ann_file.parent.resolve()),
                        ),
                    )
                    ann_count += 1
                    seen_ids.add(ann_id)
                except Exception as exc:
                    logger.warning("Skipping annotation file %s during index rebuild: %s", ann_file, exc)
            conn.execute("INSERT INTO metadata (key, value) VALUES (?, ?)", ("fingerprint", fp))
            conn.execute("INSERT INTO metadata (key, value) VALUES (?, ?)", ("last_built", built))
            conn.commit()
        return {
            "sidecar_files": len(paths),
            "annotations": ann_count,
            "fingerprint": fp,
            "last_built": built,
        }

    def count_matching(
        self,
        *,
        kind: str | None = None,
        status: str | None = None,
        severity: str | None = None,
        assigned: str | None = None,
        finding: str | None = None,
        file: str | None = None,
        expires_when: str | None = None,
        horizon: str | None = None,
    ) -> int:
        where, params = self.match_where(
            kind=kind,
            status=status,
            severity=severity,
            assigned=assigned,
            finding=finding,
            file=file,
            expires_when=expires_when,
            horizon=horizon,
        )
        sql = "SELECT COUNT(*) FROM annotations" + where
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(sql, params).fetchone()
        return int(row[0]) if row else 0

    def query(
        self,
        *,
        kind: str | None = None,
        status: str | None = None,
        severity: str | None = None,
        assigned: str | None = None,
        finding: str | None = None,
        file: str | None = None,
        expires_when: str | None = None,
        horizon: str | None = None,
        limit: int | None = None,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        where, params = self.match_where(
            kind=kind,
            status=status,
            severity=severity,
            assigned=assigned,
            finding=finding,
            file=file,
            expires_when=expires_when,
            horizon=horizon,
        )
        sql = "SELECT * FROM annotations" + where + _ORDER_SQL
        off = max(0, offset)
        if limit is not None:
            sql += " LIMIT ? OFFSET ?"
            params.extend([limit, off])
        elif off:
            sql += " LIMIT ? OFFSET ?"
            params.extend([-1, off])
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def status_payload(self, project_path: Path) -> dict[str, Any]:
        if not self.db_path.is_file():
            paths = iter_sidecar_paths(project_path.resolve())
            fp_now = fingerprint_sidecar_paths(paths)
            return {
                "state": "missing",
                "last_built": None,
                "fingerprint": fp_now,
                "fingerprint_stored": None,
                "sidecar_files": len(paths),
            }
        try:
            fresh, stored_fp, fp_now, n_sidecars = self.freshness(project_path)
            with sqlite3.connect(self.db_path) as conn:
                row = conn.execute("SELECT value FROM metadata WHERE key = 'last_built'").fetchone()
            last_built = row[0] if row else None
            return {
                "state": "fresh" if fresh else "stale",
                "last_built": last_built,
                "fingerprint": fp_now,
                "fingerprint_stored": stored_fp,
                "sidecar_files": n_sidecars,
            }
        except sqlite3.Error as exc:
            logger.warning("Annotation index DB unreadable (%s): %s", self.db_path, exc)
            return {"state": "corrupt", "last_built": None, "error": str(exc)}
