from __future__ import annotations

import uuid
from pathlib import Path
from typing import Any

from forge.tools.audit import runtime
from forge.tools.audit.bundle import AuditMapBundle, AuditMapNode, load_bundle, save_bundle
from forge.tools.audit.node_builder import (
    attach_annotations_to_nodes,
    build_cross_ring_edges,
    build_nodes_from_command_tree,
    build_nodes_from_manifest_graph,
    build_nodes_from_registry,
    build_nodes_from_meta_output,
    build_nodes_from_scan,
    scan_all_annotations,
)
from forge.tools.manifest.graph import build_manifest_graph
from forge.tools.registry.store import load_registry
from forge.tools.audit.sweep import get_branches_for_sweep, run_meta_for_branch


def run_audit_map_take(
    project: Path,
    *,
    session_id: str | None,
    sweep_level: str,
    mode: str,
    at_path: str | None,
    depth: int,
    traverse: str,
    out: Path,
    get_git_branch: Any,
    get_git_sha: Any,
    get_forge_version: Any,
    get_manifest_source: Any,
) -> dict[str, Any]:
    project = project.resolve()
    bundle_id = str(uuid.uuid4())
    sess_id = session_id or f"map-{bundle_id[:8]}"
    warnings: list[str] = []
    nodes = []
    edges = []
    # L2 defaults to DFS traversal if caller keeps CLI default.
    traverse_eff = "dfs" if sweep_level == "L2" and traverse == "bfs" else traverse

    scan_path = project / "scan" / "validation.json"
    scan_nodes: list = []
    if sweep_level != "L0":
        scan_nodes, scan_edges = build_nodes_from_scan(scan_path)
        nodes.extend(scan_nodes)
        edges.extend(scan_edges)
        if not scan_path.exists():
            warnings.append("scan/validation.json not found. Run: forge scan . --format all")

    # Ring 1 (ecosystem)
    try:
        registry = load_registry()
        ring1_nodes = [n for n in build_nodes_from_registry(registry) if n.label.lower() == project.name.lower()]
        if not ring1_nodes:
            ring1_nodes = build_nodes_from_registry(registry)
    except Exception:
        ring1_nodes = []
    if not ring1_nodes:
        ring1_nodes = [
            AuditMapNode(
                node_id=f"ring1/{project.name}",
                kind="branch",
                path=str(project),
                label=project.name,
                status="not_started",
                ring_id=1,
            )
        ]
    nodes.extend(ring1_nodes)

    if sweep_level != "L0" and sweep_level != "L4":
        cmd_tree = project.parent / "forge-workspace" / project.name / "command-map-artifacts" / "command_tree.json"
        cmd_nodes = build_nodes_from_command_tree(cmd_tree)
        nodes.extend(cmd_nodes)
        if not cmd_tree.exists():
            warnings.append("command_tree.json not found. Skipping command nodes.")

    out_path = Path(out)
    if not out_path.is_absolute():
        out_path = project / out
    out_path = out_path.resolve()

    existing_bundle: AuditMapBundle | None = None
    if sweep_level == "L4" and out_path.exists():
        try:
            existing_bundle = load_bundle(out_path)
        except Exception:
            existing_bundle = None
            warnings.append("L4 requested but existing bundle could not be loaded; using empty blocked set.")

    ring2_nodes: list = []
    ring2_edges: list = []
    if sweep_level != "L0":
        try:
            mg = build_manifest_graph(project)
            ring2_nodes, ring2_edges = build_nodes_from_manifest_graph(mg)
            nodes.extend(ring2_nodes)
            edges.extend(ring2_edges)
        except Exception:
            warnings.append("manifest graph unavailable; skipping Ring 2 nodes.")

    branches = get_branches_for_sweep(sweep_level, project, existing_bundle=existing_bundle)
    meta_calls = 0
    if sweep_level != "L0":
        for branch in branches:
            focus = ["contracts"] if sweep_level == "L3" else None
            meta = run_meta_for_branch(
                branch_path=branch,
                mode=mode,
                project_path=project,
                siblings=(sweep_level == "L2"),
                focus=focus,
            )
            meta_calls += 1
            node_kind = "policy" if sweep_level == "L3" else "branch"
            nodes.extend(build_nodes_from_meta_output(meta, branch_path=branch, kind=node_kind))

    if sweep_level == "L4":
        nodes = [n for n in nodes if n.status == "blocked"]

    for n in nodes:
        if getattr(n, "sweep_level", None) is None:
            n.sweep_level = sweep_level

    annotations = scan_all_annotations(project)
    attach_annotations_to_nodes(nodes, annotations)

    ring4_nodes = [n for n in nodes if int(getattr(n, "ring_id", 4) or 4) == 4]
    cross_ring_edges = build_cross_ring_edges(ring1_nodes, ring2_nodes, ring4_nodes)

    bundle = AuditMapBundle(
        bundle_id=bundle_id,
        session_id=sess_id,
        repo={},
        generator_version=str(get_forge_version()),
        inputs={
            "mode": mode,
            "at": at_path,
            "depth": depth,
            "sweep_level": sweep_level,
            "traverse": traverse_eff,
            "meta_calls": meta_calls,
            "branches": branches,
        },
        warnings=warnings,
        nodes=nodes,
        edges=edges,
        cross_ring_edges=cross_ring_edges,
        provenance={
            "manifest_source": str(get_manifest_source(project)),
            "scan_path": str(scan_path),
        },
    )
    if sweep_level == "L4":
        try:
            verify_out = runtime.verify(session_id=sess_id, changed_files=[], strict=False, policy_mode="advisory")
            bundle.stats["verify_exit_code"] = int(verify_out.get("exit_code", 1))
        except Exception:
            # audit verify is session-bound in EGMP; keep L4 sweep resilient.
            bundle.stats["verify_exit_code"] = None
            warnings.append("L4 verify could not run without active EGMP session.")
    bundle.coverage = bundle.compute_coverage()
    bundle.rings_summary = bundle.compute_rings_summary()
    bundle.repo = {
        "root": str(project),
        "branch": str(get_git_branch(project)),
        "head_sha": str(get_git_sha(project)),
    }
    bundle.provenance = {
        **bundle.provenance,
        "manifest_source": str(get_manifest_source(project)),
    }
    save_bundle(bundle, out_path)
    cov = bundle.coverage or bundle.compute_coverage()
    return {
        "bundle_id": bundle_id,
        "session_id": sess_id,
        "bundle": bundle,
        "coverage": cov,
        "warnings": warnings,
        "output_path": str(out_path),
    }


def bundle_summary_dict(bundle: AuditMapBundle) -> dict[str, Any]:
    cov = bundle.coverage or bundle.compute_coverage()
    return {
        "bundle_id": bundle.bundle_id,
        "session_id": bundle.session_id,
        "coverage": cov,
        "node_count": cov.get("total", 0),
        "rings_summary": bundle.rings_summary or bundle.compute_rings_summary(),
    }
