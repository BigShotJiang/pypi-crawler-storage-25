from __future__ import annotations

import subprocess
from pathlib import Path


def get_git_branch(path: Path) -> str:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=path,
            capture_output=True,
            text=True,
            check=False,
        )
        return result.stdout.strip() or "unknown"
    except Exception:
        return "unknown"


def get_git_sha(path: Path) -> str:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=path,
            capture_output=True,
            text=True,
            check=False,
        )
        return (result.stdout.strip() or "unknown")[:12]
    except Exception:
        return "unknown"


def get_forge_version() -> str:
    try:
        import importlib.metadata

        return importlib.metadata.version("forge")
    except Exception:
        return "unknown"


def get_manifest_source(project: Path) -> str:
    if (project / "docs" / "manifest.yaml").exists():
        return "docs/manifest.yaml"
    if (project / "manifest.yaml").exists():
        return "manifest.yaml (root)"
    return "not found"
