from __future__ import annotations

from dataclasses import asdict
from datetime import UTC, datetime
import json
import logging
import os
import sys
from pathlib import Path
import subprocess
from typing import Any

import yaml

from forge.mcp.audit import resolve_audit_paths
from forge.mcp.registry import all_tool_schemas
from forge.core.schemas import CLIProgressEvent
from forge.tools.audit.validate import validate_document
from forge.tools.docs_audit.orchestrator import run_docs_audit
from forge.tools.docs_audit.loaders.changed_files import get_changed_files
from forge.tools.scan.scanner import run_validation_only
from forge.core.event_log import auto_append, EventSeverity
from forge.core.execution_graph import persist_execution_result

_MAX_CHANGED_FILES = 500
_SKIP_DIR_PARTS = frozenset({
    ".git",
    "node_modules",
    ".venv",
    "venv",
    "__pycache__",
    "dist",
    "build",
    ".tox",
    ".mypy_cache",
    ".pytest_cache",
})


def _now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _resolve_repo_root_for_session(session_id: str) -> Path:
    """Resolve the repo root for a given session ID."""
    cwd = Path.cwd().resolve()
    for base in [cwd, *cwd.parents]:
        candidate = base / "cowork" / "audit" / "sessions" / session_id / "state.yaml"
        if candidate.is_file():
            return base
    return cwd


def _load_state(repo_root: Path, session_id: str) -> tuple[dict[str, Any], dict[str, Path]]:
    """Load session state and return state dict and paths dict."""
    state_path = repo_root / "cowork" / "audit" / "sessions" / session_id / "state.yaml"
    state = _read_yaml(state_path)
    paths = {
        "state": state_path,
        "events": repo_root / "cowork" / "audit" / "sessions" / session_id / "events.yaml",
    }
    return state, paths


def _repo_root_from(target: Path) -> Path:
    """Find the repo root from a target path."""
    current = target
    while current != current.parent:
        if (current / ".git").is_dir():
            return current
        current = current.parent
    return target  # fallback to target if no .git found


def _read_yaml(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return data if isinstance(data, dict) else {}


def _write_yaml(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")


def _repo_identity(repo_root: Path) -> tuple[str, str]:
    def _git(args: list[str], default: str) -> str:
        try:
            proc = subprocess.run(
                ["git", "-C", str(repo_root), *args],
                capture_output=True,
                text=True,
                check=False,
                timeout=30,
            )
            out = (proc.stdout or "").strip()
            return out or default
        except Exception:
            return default

    return _git(["rev-parse", "--abbrev-ref", "HEAD"], "unknown"), _git(["rev-parse", "HEAD"], "unknown")


def _repo_root_from(start: Path | None = None) -> Path:
    cur = (start or Path.cwd()).resolve()
    for p in [cur, *cur.parents]:
        if (p / ".git").exists():
            return p
    return cur


def _relative_files(root: Path, base: Path) -> list[str]:
    out: list[str] = []
    if not base.exists():
        return out
    for p in base.rglob("*"):
        if not p.is_file():
            continue
        if any(part in _SKIP_DIR_PARTS for part in p.parts):
            continue
        try:
            out.append(str(p.relative_to(root)).replace("\\", "/"))
        except ValueError:
            continue
    return sorted(out)


def _cap_changed_files(
    files: list[str],
    limit: int = _MAX_CHANGED_FILES,
) -> tuple[list[str], bool]:
    if len(files) <= limit:
        return files, False
    return files[:limit], True


def _entity_health_snapshot(project_path: Path) -> dict[str, Any]:
    try:
        from forge.core.forge_project_system import ForgeProject
        project = ForgeProject.from_manifest(project_path)
        real = [e for e in project._entities.values() if e.kind != 'domain']
        implemented = sum(1 for e in real if e._properties.get('status') == 'implemented')
        declared = len(real) - implemented
        return {
            "total_entities": len(real),
            "implemented": implemented,
            "declared_only": declared,
            "coverage": round(implemented / len(real) * 100) if real else 0,
            "warn_count": declared,
            "error_count": 0,
            "checks": [],
            "manifest_count": len(real),
        }
    except Exception as exc:
        return {"error": str(exc), "warn_count": 0, "error_count": 0,
                "total_entities": 0, "implemented": 0, "declared_only": 0, "coverage": 0}


def _capabilities() -> dict[str, Any]:
    try:
        from forge.cli import main as cli_main
        names: list[str] = []
        for cmd in sorted(cli_main.commands.keys()):
            names.append(cmd)
        return {
            "cli_commands": sorted({*names, "diff"}),
            "mcp_tools": sorted({*(t.name for t in all_tool_schemas()), "forge_diff"}),
            "audit_scopes": ["docs", "code", "runtime", "feature", "memory", "all"],
            "audit_focus": ["sync", "deprecation", "health", "graph", "impact", "capabilities", "all"],
        }
    except Exception:
        return {}


def create_annotation(
    project_path: Path,
    *,
    kind: str,
    marker: str | None = None,
    title: str,
    content: str,
    severity: str | None = None,
    horizon: str | None = None,
    session_id: str | None = None,
) -> dict[str, Any]:
    """Create a new annotation with validation."""
    # Validate required fields
    if not title or not content:
        raise ValueError("title and content are required for create annotation")
    
    # Create annotation object
    from .annotations import AuditAnnotation, next_annotation_id
    annotation = AuditAnnotation(
        id=str(next_annotation_id(project_path)),
        kind=resolve_annotation_kind(kind),
        marker=marker,
        title=title,
        content=content,
        severity=severity,
        horizon=horizon,
        status="draft",
        origin="human",
        created_at=_now(),
    )
    
    # Validate annotation
    from .annotations import validate_annotation
    errors = validate_annotation(annotation)
    if errors:
        raise ValueError("Invalid annotation: " + "; ".join(errors))
    
    # Write annotation
    from .annotations import write_annotation, _annotations_dir
    annotations_dir = _annotations_dir(project_path)
    annotations_dir.mkdir(parents=True, exist_ok=True)
    ann_path = annotations_dir / f"ANNOT-{annotation.id:04d}.yaml"
    
    write_annotation(annotations_dir, annotation)
    
    return {
        "ok": True,
        "annotation_id": annotation.id,
        "annotation": annotation.model_dump(),
    }


def session_start(
    repo_root: str,
    branch: str | None = None,
    session_label: str | None = None,
) -> dict[str, Any]:
    """Start an EGMP audit session and return session state."""
    root = Path(repo_root).expanduser().resolve()
    session_id = f"session-{_now().replace(':', '').replace('-', '')}"
    branch_name = branch or _repo_identity(root)[0]
    label = session_label or "audit session"
    
    session_data = {
        "document_kind": "session_state",
        "schema_version": 1,
        "session_id": session_id,
        "repo_root": str(root),
        "branch": branch_name,
        "session_label": label,
        "started_at": _now(),
        "status": "active",
    }
    
    # Write session state file
    events_dir = root / ".forge" / "events"
    events_dir.mkdir(parents=True, exist_ok=True)
    state_path = events_dir / f"{session_id}.yaml"
    _write_yaml(state_path, session_data)
    
    return {
        "session_id": session_id,
        "state_path": str(state_path),
        "branch": branch_name,
        "session_label": label,
    }


def audit_repo(
    project_path: str = ".",
    strict: bool = False,
    policy_mode: str = "advisory",
    changed_files_source: str = "git",  # git|scope|all
    alignment_mode: str = "target_to_forge",  # target_to_forge|bidirectional|target_only
    scope: list[str] | None = None,
    focus: list[str] | None = None,
) -> dict[str, Any]:
    root = _repo_root_from(Path(project_path).expanduser().resolve())
    scopes = scope or ["all"]
    focuses = focus or ["all"]

    changed_files: list[str] = []
    if changed_files_source == "git":
        try:
            changed_files = get_changed_files(source="git", base="HEAD~1", head="HEAD", cwd=str(root))
        except Exception:
            changed_files = []
    elif changed_files_source == "scope":
        changed_files = _relative_files(root, root / "docs")
    elif changed_files_source == "all":
        changed_files = _relative_files(root, root)
    changed_files, files_truncated = _cap_changed_files(changed_files)
    if policy_mode == "enforce" and changed_files_source == "git" and not changed_files:
        # Enforce mode should not be a silent no-op when no git diff exists.
        changed_files, files_truncated = _cap_changed_files(
            _relative_files(root, root / "docs")
        )
    
    manifest_path, impact_path, impact_local, docs_root = resolve_audit_paths(root)
    impact = run_docs_audit(
        manifest_path=str(manifest_path),
        impact_path=str(impact_path),
        impact_local_path=str(impact_local) if impact_local and impact_local.is_file() else None,
        docs_root=str(docs_root),
        changed_files=changed_files,
        changed_text="",
        strict=strict,
    )
    scan = run_validation_only(root)
    doctor = _entity_health_snapshot(root)
    capabilities = _capabilities()

    cached_manifest_graph = None
    try:
        from forge.tools.manifest.graph import build_manifest_graph

        cached_manifest_graph = build_manifest_graph(root)
    except Exception:
        cached_manifest_graph = None

    # Scan health is informational (graph_health / sync_health); do not gate exit_code.
    exit_code = max(
        int(impact.exit_code),
        2 if int(doctor.get("error_count", 0)) > 0 else (1 if int(doctor.get("warn_count", 0)) > 0 else 0),
    )
    if policy_mode == "enforce" and int(impact.exit_code) == 1:
        exit_code = max(exit_code, 2)
    
    # Replace scanner-derived graph_health with honest layer-aware score
    try:
        from forge.core.graph_health_metrics import GraphHealthAnalyzer
        analyzer = GraphHealthAnalyzer(root)
        if cached_manifest_graph is not None:
            analyzer._manifest_graph = cached_manifest_graph
        health_result = analyzer.analyze_overall_health()
        graph_health_score = int((health_result.overall_health or 0) * 100)
        health_note = health_result.score_note
    except Exception:
        graph_health_score = 0
        health_note = None

    return {
        "document_kind": "verify_result",
        "schema_version": 1,
        "mode": "repo",
        "alignment_mode": alignment_mode,
        "repo_root": str(root),
        "scope": scopes,
        "focus": focuses,
        "changed_files_source": changed_files_source,
        "policy_mode": policy_mode,
        "exit_code": exit_code,
        "gate_summary": {"gate_fail_count": 0, "gate_pass_count": 0},
        "impact_summary": {
            "triggered_rules": [tr.rule.id for tr in impact.triggered_rules],
            "failures": [asdict(f) for f in impact.failures],
            "exit_code": impact.exit_code,
            "changed_files_considered": changed_files,
            "changed_files_truncated": files_truncated,
            "changed_files_cap": _MAX_CHANGED_FILES,
        },
        "scan_summary": {
            "graph_health": graph_health_score,
            "sync_health": scan.context_data.get("sync_health"),
            "health_signal": scan.context_data.get("health_signal"),
            "severed": len([c for c in scan.connections if c.severed]),
            "severed_node_ids": [c.from_id for c in scan.connections if c.severed],
            "orphans": len(scan.orphans),
            "orphan_node_ids": [o.path for o in scan.orphans],
            "drift": len(scan.drift_items),
            "drift_node_ids": list(scan.drift_items),
            "frontmatter_issues": len(scan.frontmatter_issues),
        },
        "doctor_summary": doctor,
        "capabilities_report": capabilities,
        "recommendations": (
            ["Capture Forge deltas as candidate improvements only; prioritize target remediation."]
            if alignment_mode == "target_to_forge"
            else (["Run symmetric standards reconciliation across both repos."] if alignment_mode == "bidirectional" else [])
        ),
    }


def audit_meta(
    at_path: str = ".",
    include_siblings: bool = True,
    depth: int = 3,
    include_parent_context: bool = True,
    strict: bool = False,
    policy_mode: str = "advisory",
    changed_files_source: str = "git",  # git|scope|all
    alignment_mode: str = "target_to_forge",  # target_to_forge|bidirectional|target_only
    scope: list[str] | None = None,
    focus: list[str] | None = None,
) -> dict[str, Any]:
    """Run meta-mode audit scan."""
    target = Path(at_path).expanduser().resolve()
    root = _repo_root_from(target)
    rel_target = str(target.relative_to(root)).replace("\\", "/") if target != root else "."
    
    if changed_files_source == "git":
        try:
            all_changed = get_changed_files(source="git", base="HEAD~1", head="HEAD", cwd=str(root))
        except Exception:
            all_changed = []
        target_prefix = "" if rel_target == "." else (rel_target + "/")
        changed = [f for f in all_changed if f.startswith(target_prefix)]
    else:
        changed = []
    
    return {
        "mode": "meta",
        "target": rel_target,
        "changed_files": changed,
        "include_siblings": include_siblings,
        "depth": depth,
        "include_parent_context": include_parent_context,
        "strict": strict,
        "policy_mode": policy_mode,
        "alignment_mode": alignment_mode,
        "scope": scope or [],
        "focus": focus or [],
    }


def finding_promote(
    session_id: str,
    title: str,
    source_1: str,
    source_2: str,
    finding: str,
    implication: str,
    actor_id: str = "system",
) -> dict[str, Any]:
    """Promote a finding with validation gates."""
    repo_root = _resolve_repo_root_for_session(session_id)
    state, paths = _load_state(repo_root, session_id)
    ctr = dict(state.get("id_counters") or {})
    next_finding = int(ctr.get("finding", 0)) + 1
    ctr["finding"] = next_finding
    state["id_counters"] = ctr
    finding_id = f"F-{next_finding:04d}"

    reasons: list[str] = []
    if not source_1 or not source_2:
        reasons.append("Gate A requires at least two independent sources.")
    if not title or not finding or not implication:
        reasons.append("Gate B requires title, finding, and implication.")
    
    gate_result = "fail" if reasons else "pass"
    
    return {
        "finding_id": finding_id,
        "gate": {
            "result": gate_result,
            "reasons": reasons,
        },
        "session_id": session_id,
        "actor_id": actor_id,
    }
