from __future__ import annotations

import json
import logging
import sqlite3
from dataclasses import asdict
from datetime import date
from pathlib import Path
from typing import Any

import yaml

from .bundle import ANNOTATION_KINDS, SIDECAR_FILENAME, AuditAnnotation
from .index import (
    ANNOTATION_QUERY_SORT_KEYS,
    SIDECAR_INDEX_FINGERPRINT_SPEC,
    SIDECAR_INDEX_FINGERPRINT_V1_ID,
    AnnotationIndex,
    fingerprint_sidecar_paths,
)

logger = logging.getLogger(__name__)

ANNOTATION_QUERY_RESULT_KIND = "forge.audit.annotation_query"

# Kind-specific validation (see schemas/forge-annotations.schema.yaml).
REQUIRES_FILE = frozenset({"finding", "architecture-debt"})


class ValidationError(ValueError):
    """Raised when annotation fields violate kind-specific rules."""


ANNOTATION_QUERY_SCHEMA_VERSION = 1

# MCP / note markers → annotation schema ``kind`` (schemas/forge-annotations.schema.yaml).
MARKER_TO_KIND: dict[str, str] = {
    "obs": "gap",
    "question": "question",
    "surprise": "risk",
}


def resolve_annotation_kind(*, marker: str | None, kind: str | None) -> str:
    """Resolve ``kind`` for AuditAnnotation from explicit ``kind`` or legacy ``marker``."""
    if kind and str(kind).strip():
        return str(kind).strip()
    m = (marker or "").strip().lower()
    if m in MARKER_TO_KIND:
        return MARKER_TO_KIND[m]
    if m in ANNOTATION_KINDS:
        return m
    raise ValueError(
        f"annotation kind: supply kind= one of {ANNOTATION_KINDS!r} "
        f"or marker= one of {list(MARKER_TO_KIND)!r}"
    )

_VALID_STATUSES = {"draft", "open", "resolved", "dismissed", "deferred"}
_VALID_ORIGINS = {"human", "forge-diff", "forge-scan", "forge-verify"}


def _parse_phase_field(val: Any) -> int | None:
    if val is None:
        return None
    if isinstance(val, bool):
        return None
    if isinstance(val, int):
        return val
    if isinstance(val, float):
        return int(val)
    if isinstance(val, str) and val.strip().lstrip("-").isdigit():
        return int(val.strip())
    return None


def audit_annotation_from_dict(raw: dict[str, Any]) -> AuditAnnotation:
    """Build ``AuditAnnotation`` from YAML/JSON dict (drops unknown keys)."""
    from dataclasses import fields

    allowed = {f.name for f in fields(AuditAnnotation)}
    merged: dict[str, Any] = {
        "id": str(raw.get("id") or ""),
        "file": str(raw.get("file") or ""),
        "kind": str(raw.get("kind") or ""),
        "severity": str(raw.get("severity") or "low"),
        "note": str(raw.get("note") or raw.get("title") or ""),
        "status": str(raw.get("status") or "open"),
        "origin": str(raw.get("origin") or "human"),
        "created": str(raw.get("created") or ""),
    }
    list_str_keys = ("affects", "adr_refs", "blocks", "requires", "pipeline_refs", "tool_refs")
    for k in allowed:
        if k in merged:
            continue
        if k not in raw:
            continue
        v = raw[k]
        if k in list_str_keys:
            merged[k] = [str(x) for x in (v or []) if isinstance(x, (str, int, float))]
        elif k == "checklist" and isinstance(v, list):
            merged[k] = [dict(x) for x in v if isinstance(x, dict)]
        elif k == "phase":
            merged[k] = _parse_phase_field(v)
        elif k == "elicitation_trigger":
            merged[k] = bool(v)
        else:
            merged[k] = v
    clean = {k: merged[k] for k in allowed if k in merged}
    return AuditAnnotation(**clean)


def _looks_like_manifest_node_id(s: str) -> bool:
    t = (s or "").strip()
    if not t:
        return False
    if "/" in t:
        return True
    return t.startswith("module") or t.startswith("ring")


def warn_unknown_graph_linked_node_ids(project_root: Path, ann: AuditAnnotation) -> None:
    """Log warnings when graph-linked node ids are absent from the live manifest graph."""
    from forge.tools.manifest.graph import build_manifest_graph

    root = project_root.expanduser().resolve()
    try:
        g = build_manifest_graph(root)
        valid = {n.id for n in g.nodes}
    except Exception as exc:
        logger.debug("graph-linked annotation check skipped: %s", exc)
        return
    for bid in ann.blocks or []:
        sid = str(bid).strip()
        if sid and sid not in valid:
            logger.warning("annotation %s blocks unknown manifest node id %r", ann.id, sid)
    for rid in ann.requires or []:
        sid = str(rid).strip()
        if sid and sid not in valid:
            logger.warning("annotation %s requires unknown manifest node id %r", ann.id, sid)
    ew = (ann.expires_when or "").strip()
    if ew and _looks_like_manifest_node_id(ew) and ew not in valid:
        logger.warning("annotation %s expires_when unknown manifest node id %r", ann.id, ew)


def _annotations_dir(project_path: Path) -> Path:
    return project_path.expanduser().resolve() / ".forge" / "annotations"


def _annotations_index_path(project_path: Path) -> Path:
    return _annotations_dir(project_path) / "index.yaml"


def _iter_annotation_files(project_path: Path) -> list[Path]:
    ann_dir = _annotations_dir(project_path)
    if not ann_dir.is_dir():
        return []
    return sorted([p for p in ann_dir.glob("ANNOT-*.yaml") if p.is_file()])


def _load_annotation_yaml(path: Path) -> dict[str, Any]:
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return raw if isinstance(raw, dict) else {}


def create_annotation(
    project_path: Path,
    *,
    kind: str,
    marker: str | None = None,
    title: str,
    content: str,
    severity: str | None = None,
    horizon: str | None = None,
    session_id: str | None = None,
) -> AuditAnnotation:
    """Create a new annotation with validation."""
    # Validate required fields
    if not title or not content:
        raise ValueError("title and content are required for create annotation")
    
    # Create annotation object
    annotation = AuditAnnotation(
        id=str(next_annotation_id(project_path)),
        kind=resolve_annotation_kind(kind),
        marker=marker,
        title=title,
        content=content,
        severity=severity,
        horizon=horizon,
        status="draft",
        origin="human",
        created_at=_now(),
    )
    
    # Validate annotation
    errors = validate_annotation(annotation)
    if errors:
        raise ValueError("Invalid annotation: " + "; ".join(errors))
    
    # Write annotation
    annotations_dir = _annotations_dir(project_path)
    annotations_dir.mkdir(parents=True, exist_ok=True)
    ann_path = annotations_dir / f"ANNOT-{annotation.id:04d}.yaml"
    
    write_annotation(annotations_dir, annotation)
    
    return annotation


def _annotation_index_entry(raw: dict[str, Any]) -> dict[str, Any]:
    affects_raw = raw.get("affects") or []
    affects_first = None
    if isinstance(affects_raw, list) and affects_raw:
        affects_first = str(affects_raw[0])
    return {
        "id": str(raw.get("id") or "").strip(),
        "title": str(raw.get("title") or "").strip(),
        "kind": str(raw.get("kind") or "").strip(),
        "status": str(raw.get("status") or "open").strip(),
        "origin": str(raw.get("origin") or "human").strip(),
        "horizon": str(raw.get("horizon") or "").strip() or None,
        "severity": str(raw.get("severity") or "").strip() or None,
        "phase": raw.get("phase"),
        "affects": affects_first,
    }


def rebuild_annotation_index(project_path: Path) -> dict[str, Any]:
    root = project_path.expanduser().resolve()
    entries: list[dict[str, Any]] = []
    for ann_file in _iter_annotation_files(root):
        raw = _load_annotation_yaml(ann_file)
        entry = _annotation_index_entry(raw)
        if entry["id"]:
            entries.append(entry)
    entries.sort(key=lambda e: str(e["id"]))
    payload = {"annotations": entries}
    out_path = _annotations_index_path(root)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        yaml.dump(payload, default_flow_style=False, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    return {"index_path": str(out_path), "annotations": len(entries)}


def load_annotation_index_entries(
    project_path: Path | str,
    *,
    rebuild_if_missing: bool = False,
) -> list[dict[str, Any]]:
    """Load summarized annotation rows from ``.forge/annotations/index.yaml``.

    Used by metrics (IDR) and other read-only callers. When ``rebuild_if_missing``
    is false (default), returns an empty list if the index file is absent —
    avoids writing the tree during projections.
    """
    root = Path(project_path).expanduser().resolve()
    p = _annotations_index_path(root)
    if not p.is_file():
        if rebuild_if_missing:
            rebuild_annotation_index(root)
        else:
            return []
    if not p.is_file():
        return []
    raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    items = raw.get("annotations") if isinstance(raw, dict) else []
    if not isinstance(items, list):
        return []
    out: list[dict[str, Any]] = []
    for item in items:
        if isinstance(item, dict):
            out.append(item)
    return out


def annotations_index_yaml_path(project_path: Path | str) -> Path:
    """Absolute path to ``.forge/annotations/index.yaml`` (may not exist)."""
    return _annotations_index_path(Path(project_path).expanduser().resolve())


def annotation_rollups_from_index(entries: list[dict[str, Any]]) -> dict[str, int]:
    """Mechanical counts from annotation index rows (IDR / intent rollups).

    Rows with non-empty ``affects`` are the ones currently merged into IDR inputs.
    ``annotation_rows_intent_horizon`` counts rows whose ``horizon`` is ``intent``
    (project convention for intent-scoped audit notes).
    """
    total = len(entries)
    with_affects = 0
    intent_horizon = 0
    for e in entries:
        if not isinstance(e, dict):
            continue
        if str(e.get("affects") or "").strip():
            with_affects += 1
        if str(e.get("horizon") or "").strip().lower() == "intent":
            intent_horizon += 1
    return {
        "annotation_index_row_count": total,
        "annotation_rows_with_affects": with_affects,
        "annotation_rows_intent_horizon": intent_horizon,
    }


def _load_annotation_index(project_path: Path) -> list[dict[str, Any]]:
    return load_annotation_index_entries(project_path, rebuild_if_missing=True)


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[3]


def default_annotation_schema_path() -> Path:
    return _repo_root() / "schemas" / "forge-annotations.schema.yaml"


def load_annotation_schema_as_dict(schema_path: Path | None = None) -> dict[str, Any]:
    p = schema_path or default_annotation_schema_path()
    raw = yaml.safe_load(p.read_text(encoding="utf-8"))
    return raw if isinstance(raw, dict) else {}


def annotation_schema_for_query_json(
    schema_path: Path | None = None,
    *,
    field: str | None = None,
) -> str:
    data = load_annotation_schema_as_dict(schema_path)
    if field:
        if field in data:
            return json.dumps({field: data[field]}, indent=2)
        if field in (data.get("annotation") or {}):
            ann = data.get("annotation") or {}
            return json.dumps({field: ann.get(field)}, indent=2)
    return json.dumps(data, indent=2)


def validate_annotation(
    ann: AuditAnnotation,
    schema_path: Path | None = None,
) -> list[str]:
    """
    Validate annotation against schema. Returns list of errors (empty = valid).
    Loads schemas/forge-annotations.schema.yaml if path omitted.
    """
    _ = load_annotation_schema_as_dict(schema_path)
    errors: list[str] = []
    if not (ann.id or "").strip():
        errors.append("id is required")
    if ann.kind in REQUIRES_FILE:
        if not (ann.file or "").strip():
            raise ValidationError(f"file is required for kind: {ann.kind}")
    if not (ann.note or "").strip():
        errors.append("note is required")
    if ann.kind not in ANNOTATION_KINDS:
        errors.append(f"Invalid kind: {ann.kind!r}; expected one of {ANNOTATION_KINDS}")
    if ann.severity not in ("high", "medium", "low"):
        errors.append(f"Invalid severity: {ann.severity!r}")
    if ann.status not in _VALID_STATUSES:
        errors.append(f"Invalid status: {ann.status!r}")
    if ann.origin not in _VALID_ORIGINS:
        errors.append(f"Invalid origin: {ann.origin!r}")
    if ann.kind == "verification-checkpoint" and not ann.checklist:
        errors.append("verification-checkpoint annotations must include a non-empty checklist")
    if not isinstance(ann.blocks, list):
        errors.append("blocks must be a list")
    else:
        for i, item in enumerate(ann.blocks):
            if not isinstance(item, (str, int, float)):
                errors.append(f"blocks[{i}] must be string-like")
    if not isinstance(ann.requires, list):
        errors.append("requires must be a list")
    else:
        for i, item in enumerate(ann.requires):
            if not isinstance(item, (str, int, float)):
                errors.append(f"requires[{i}] must be string-like")
    if ann.phase is not None and not isinstance(ann.phase, int):
        errors.append("phase must be an integer when set")
    for label, seq in (("pipeline_refs", ann.pipeline_refs), ("tool_refs", ann.tool_refs)):
        if not isinstance(seq, list):
            errors.append(f"{label} must be a list")
        else:
            for i, item in enumerate(seq):
                if not isinstance(item, (str, int, float)):
                    errors.append(f"{label}[{i}] must be string-like")
    return errors


def _json_id_list(raw: Any) -> list[str]:
    if not raw:
        return []
    try:
        parsed = json.loads(raw) if isinstance(raw, str) else raw
    except json.JSONDecodeError:
        return []
    if not isinstance(parsed, list):
        return []
    return [str(x) for x in parsed if isinstance(x, (str, int, float))]


def _row_to_annotation(row: dict[str, Any]) -> AuditAnnotation:
    adr: list[str] = []
    raw_adr = row.get("adr_refs_json")
    if raw_adr:
        try:
            parsed = json.loads(raw_adr) if isinstance(raw_adr, str) else []
            if isinstance(parsed, list):
                adr = [str(x) for x in parsed]
        except json.JSONDecodeError:
            adr = []
    return AuditAnnotation(
        id=str(row["id"]),
        file=str(row["file"]),
        kind=str(row["kind"]),
        severity=str(row["severity"]),
        note=str(row["note"]),
        status=str(row.get("status") or "open"),
        symbol=row.get("symbol"),
        line=row.get("line"),
        finding=row.get("finding"),
        assigned=row.get("assigned"),
        expires_when=row.get("expires_when"),
        created=str(row.get("created") or ""),
        title=row.get("title"),
        body=row.get("body"),
        affects=[str(x) for x in (json.loads(row.get("affects_json") or "[]"))] if row.get("affects_json") else [],
        adr_refs=adr,
        git_issue=row.get("git_issue"),
        origin=str(row.get("origin") or "human"),
        reviewed_by=row.get("reviewed_by"),
        reviewed_at=row.get("reviewed_at"),
        horizon=row.get("horizon"),
        checklist=[dict(x) for x in (json.loads(row.get("checklist_json") or "[]")) if isinstance(x, dict)] if row.get("checklist_json") else [],
        blocks=_json_id_list(row.get("blocks_json")),
        requires=_json_id_list(row.get("requires_json")),
        phase=_parse_phase_field(row.get("phase")),
    )


def _paginate_annotations(
    anns: list[AuditAnnotation],
    *,
    limit: int | None,
    offset: int,
) -> list[AuditAnnotation]:
    start = max(0, offset)
    if limit is None:
        return anns[start:]
    return anns[start : start + limit]


def _sorted_filtered_annotations(
    all_ann: list[AuditAnnotation],
    *,
    kind: str | None = None,
    status: str | None = None,
    severity: str | None = None,
    assigned: str | None = None,
    finding: str | None = None,
    file: str | None = None,
    expires_when: str | None = None,
    origin: str | None = None,
    horizon: str | None = None,
) -> list[AuditAnnotation]:
    severity_order = {"high": 0, "medium": 1, "low": 2}
    results: list[AuditAnnotation] = []
    for ann in all_ann:
        if kind and ann.kind != kind:
            continue
        if status and ann.status != status:
            continue
        if severity and ann.severity != severity:
            continue
        if assigned and ann.assigned != assigned:
            continue
        if finding and ann.finding != finding:
            continue
        if file and file not in ann.file:
            continue
        if expires_when and expires_when.lower() not in (ann.expires_when or "").lower():
            continue
        if origin and ann.origin != origin:
            continue
        if horizon and (ann.horizon or "") != horizon:
            continue
        results.append(ann)
    return sorted(
        results,
        key=lambda a: (severity_order.get(a.severity, 99), a.file, a.id),
    )


def annotation_query_mcp_envelope(
    project_path: Path,
    *,
    kind: str | None = None,
    status: str | None = None,
    severity: str | None = None,
    assigned: str | None = None,
    finding: str | None = None,
    file: str | None = None,
    expires_when: str | None = None,
    horizon: str | None = None,
    use_index: bool = True,
    limit: int = 10,
    offset: int = 0,
) -> dict[str, Any]:
    """
    Structured MCP payload: explicit paging, data source, fingerprint contract.
    Aligns with machine-first / Gen-3 style tool responses (typed envelope).
    """
    from .sidecar_walk import iter_sidecar_paths

    project_path = project_path.expanduser().resolve()
    db_path = project_path / ".forge" / "audit-index.db"
    lim = max(0, int(limit))
    off = max(0, int(offset))

    base = {
        "result_kind": ANNOTATION_QUERY_RESULT_KIND,
        "schema_version": ANNOTATION_QUERY_SCHEMA_VERSION,
        "filters_effective": {
            k: v
            for k, v in {
                "kind": kind,
                "status": status,
                "severity": severity,
                "assigned": assigned,
                "finding": finding,
                "file_substring": file,
                "expires_when_substring": expires_when,
                "horizon": horizon,
            }.items()
            if v is not None and v != ""
        },
    }

    filter_kwargs = {
        "kind": kind,
        "status": status,
        "severity": severity,
        "assigned": assigned,
        "finding": finding,
        "file": file,
        "expires_when": expires_when,
        "horizon": horizon,
    }

    if not use_index:
        all_rows: list[AuditAnnotation] = []
        for ann_file in _iter_annotation_files(project_path):
            raw = _load_annotation_yaml(ann_file)
            all_rows.append(
                AuditAnnotation(
                    id=str(raw.get("id") or ""),
                    file=str(raw.get("file") or ""),
                    kind=str(raw.get("kind") or ""),
                    severity=str(raw.get("severity") or "low"),
                    note=str(raw.get("note") or raw.get("title") or ""),
                    status=str(raw.get("status") or "open"),
                    origin=str(raw.get("origin") or "human"),
                    horizon=str(raw.get("horizon") or "") or None,
                    assigned=raw.get("assigned"),
                    expires_when=raw.get("expires_when"),
                    git_issue=raw.get("git_issue"),
                    title=raw.get("title"),
                    body=raw.get("body"),
                    affects=[str(x) for x in (raw.get("affects") or []) if isinstance(x, (str, int, float))],
                    adr_refs=[str(x) for x in (raw.get("adr_refs") or []) if isinstance(x, (str, int, float))],
                    reviewed_by=raw.get("reviewed_by"),
                    reviewed_at=raw.get("reviewed_at"),
                    checklist=[dict(x) for x in (raw.get("checklist") or []) if isinstance(x, dict)],
                    created=str(raw.get("created") or ""),
                )
            )
        ranked = _sorted_filtered_annotations(
            all_rows,
            **filter_kwargs,
        )
        total = len(ranked)
        page = _paginate_annotations(ranked, limit=lim, offset=off)
        paths = iter_sidecar_paths(project_path)
        fp_live = fingerprint_sidecar_paths(paths)
        base.update(
            {
                "annotations": [annotation_to_dict(a) for a in page],
                "data_source": "yaml_sidecar_scan",
                "data_source_note": "no_cache=true: SQLite bypassed; full scan of pruned sidecar tree",
                "paging": {
                    "limit_applied": lim,
                    "offset_applied": off,
                    "returned_rows": len(page),
                    "total_matches": total,
                    "more_rows_available": off + len(page) < total,
                    "sort_applied": ANNOTATION_QUERY_SORT_KEYS,
                },
                "sidecar_cache": {
                    "sqlite_relative_path": ".forge/audit-index.db",
                    "fingerprint_spec_id": SIDECAR_INDEX_FINGERPRINT_V1_ID,
                    "fingerprint_spec": SIDECAR_INDEX_FINGERPRINT_SPEC,
                    "workspace_fingerprint_hex": fp_live,
                    "indexed_fingerprint_hex": None,
                    "pruned_sidecar_files_seen": len(paths),
                },
            },
        )
        return base

    index = AnnotationIndex(db_path)
    try:
        index.ensure_index(project_path)
        total = index.count_matching(
            **filter_kwargs,
        )
        rows = index.query(
            **filter_kwargs,
            limit=lim,
            offset=off,
        )
        anns = [_row_to_annotation(r) for r in rows]
        base.update(
            {
                "annotations": [annotation_to_dict(a) for a in anns],
                "data_source": "sqlite_annotation_index",
                "data_source_note": "Filters + sort executed in SQLite; YAML sidecars remain source of truth",
                "paging": {
                    "limit_applied": lim,
                    "offset_applied": off,
                    "returned_rows": len(anns),
                    "total_matches": total,
                    "more_rows_available": off + len(anns) < total,
                    "sort_applied": ANNOTATION_QUERY_SORT_KEYS,
                },
                "sidecar_cache": {
                    "sqlite_relative_path": ".forge/audit-index.db",
                    "fingerprint_spec_id": SIDECAR_INDEX_FINGERPRINT_V1_ID,
                    "fingerprint_spec": SIDECAR_INDEX_FINGERPRINT_SPEC,
                    "workspace_fingerprint_hex": None,
                    "indexed_fingerprint_hex": index.stored_fingerprint(),
                    "role": "indexed_fingerprint_hex must match a fresh workspace fingerprint or index rebuilds",
                },
            },
        )
        return base
    except sqlite3.Error as exc:
        logger.warning("Annotation index query failed (%s); falling back to sidecar walk.", exc)
    except OSError as exc:
        logger.warning("Annotation index IO error (%s); falling back to sidecar walk.", exc)

    return annotation_query_mcp_envelope(
        project_path,
        **filter_kwargs,
        use_index=False,
        limit=lim,
        offset=off,
    )


def query_annotations(
    project_path: Path,
    kind: str | None = None,
    status: str | None = None,
    origin: str | None = None,
    severity: str | None = None,
    assigned: str | None = None,
    finding: str | None = None,
    file: str | None = None,
    expires_when: str | None = None,
    horizon: str | None = None,
    *,
    use_index: bool = True,
    limit: int | None = None,
    offset: int = 0,
) -> dict[str, Any]:
    project_path = project_path.expanduser().resolve()

    def _group(rows: list[AuditAnnotation], *, primary: str, secondary: str) -> dict[str, dict[str, list[dict[str, Any]]]]:
        out: dict[str, dict[str, list[dict[str, Any]]]] = {}
        for ann in rows:
            p = getattr(ann, primary) or "unknown"
            s = getattr(ann, secondary) or "unknown"
            slot = out.setdefault(str(p), {})
            bucket = slot.setdefault(str(s), [])
            bucket.append(annotation_to_dict(ann))
        return out

    def _from_rows(all_rows: list[AuditAnnotation]) -> dict[str, Any]:
        ranked = _sorted_filtered_annotations(
            all_rows,
            kind=kind,
            status=status,
            severity=severity,
            assigned=assigned,
            finding=finding,
            file=file,
            expires_when=expires_when,
            origin=origin,
            horizon=horizon,
        )
        # ADR-014 Level 0 summary applies only when no filters are provided.
        if not any([status, origin, kind, severity, assigned, finding, file, expires_when, horizon]):
            index_items = _load_annotation_index(project_path)
            by_status: dict[str, int] = {}
            by_origin: dict[str, int] = {}
            by_kind: dict[str, int] = {}
            by_horizon: dict[str, int] = {}
            for item in index_items:
                st = str(item.get("status") or "open")
                org = str(item.get("origin") or "human")
                kd = str(item.get("kind") or "unknown")
                hz_raw = item.get("horizon")
                hz = str(hz_raw) if hz_raw else "null"
                by_status[st] = by_status.get(st, 0) + 1
                by_origin[org] = by_origin.get(org, 0) + 1
                by_kind[kd] = by_kind.get(kd, 0) + 1
                by_horizon[hz] = by_horizon.get(hz, 0) + 1
            return {
                "level": 0,
                "total": len(index_items),
                "by_origin": by_origin,
                "by_kind": by_kind,
                "by_status": by_status,
                "by_horizon": by_horizon,
            }
        # ADR-014 Level 1
        if (status and not origin) or (origin and not status):
            if kind == "verification-checkpoint" and status == "draft":
                page = _paginate_annotations(ranked, limit=limit, offset=offset)
                return {
                    "level": 2,
                    "filter": {"status": status, "origin": origin, "kind": kind},
                    "total": len(ranked),
                    "results": [annotation_to_dict(a) for a in page],
                }
            if status:
                return {"level": 1, "filter": {"status": status}, "grouped_by": ["origin", "kind"], "groups": _group(ranked, primary="origin", secondary="kind")}
            return {"level": 1, "filter": {"origin": origin}, "grouped_by": ["status", "kind"], "groups": _group(ranked, primary="status", secondary="kind")}
        # ADR-014 Level 2 (status + origin) with optional kind narrowing
        page = _paginate_annotations(ranked, limit=limit, offset=offset)
        return {
            "level": 2,
            "filter": {"status": status, "origin": origin, "kind": kind},
            "total": len(ranked),
            "results": [annotation_to_dict(a) for a in page],
        }

    _ = use_index
    all_rows: list[AuditAnnotation] = []
    for ann_path in _iter_annotation_files(project_path):
        raw = _load_annotation_yaml(ann_path)
        all_rows.append(audit_annotation_from_dict(raw))
    return _from_rows(all_rows)


def annotation_to_dict(ann: AuditAnnotation) -> dict[str, Any]:
    out = asdict(ann)
    if ann.kind == "verification-checkpoint":
        total = len(ann.checklist or [])
        confirmed = sum(1 for item in (ann.checklist or []) if bool(item.get("confirmed")))
        out["checklist_progress"] = f"{confirmed}/{total} confirmed"
    return out


def find_annotation_by_id(project_path: Path, ann_id: str) -> tuple[Path, AuditAnnotation] | None:
    root = project_path.expanduser().resolve()
    for ann_file in _iter_annotation_files(root):
        raw = _load_annotation_yaml(ann_file)
        if str(raw.get("id") or "") != ann_id:
            continue
        ann = audit_annotation_from_dict(raw)
        return ann_file.parent, ann

    from .sidecar_walk import iter_sidecar_paths

    for sidecar in iter_sidecar_paths(root):
        for ann in load_annotations_from_sidecar_file(sidecar):
            if ann.id == ann_id:
                return sidecar.parent, ann
    return None


def load_annotations_from_sidecar_file(sidecar: Path) -> list[AuditAnnotation]:
    if not sidecar.is_file():
        return []
    try:
        data = yaml.safe_load(sidecar.read_text(encoding="utf-8")) or {}
        out: list[AuditAnnotation] = []
        for raw in data.get("annotations", []) or []:
            if isinstance(raw, dict):
                out.append(audit_annotation_from_dict(raw))
        return out
    except Exception:
        return []


def write_annotation(
    directory: Path,
    annotation: AuditAnnotation,
    *,
    schema_path: Path | None = None,
) -> None:
    if annotation.kind == "verification-checkpoint":
        if not annotation.checklist:
            raise ValueError("Invalid annotation: verification-checkpoint requires checklist with at least one item.")
        if not annotation.expires_when:
            annotation.expires_when = "all checklist items confirmed"
    if annotation.origin == "human" and annotation.kind != "verification-checkpoint":
        if annotation.status == "draft":
            raise ValueError("Invalid annotation: origin=human requires status=open (draft is not allowed).")
    else:
        if not annotation.status:
            annotation.status = "draft"

    errors = validate_annotation(annotation, schema_path=schema_path)
    if errors:
        raise ValueError("Invalid annotation: " + "; ".join(errors))

    root = directory.resolve()
    project_root = root
    while project_root != project_root.parent:
        if (project_root / ".forge").is_dir():
            break
        project_root = project_root.parent
    if not (project_root / ".forge").is_dir():
        project_root = root if root.is_dir() and root.name != "annotations" else root.parent
        if project_root.name != ".forge":
            project_root = project_root.parent if project_root.name == "src" else project_root
    ann_dir = _annotations_dir(project_root)
    ann_dir.mkdir(parents=True, exist_ok=True)
    existing = find_annotation_by_id(project_root, annotation.id)
    if existing is not None:
        _, existing_ann = existing
        # Immutable identity contract: once created, id and created timestamp are never reassigned.
        annotation.id = existing_ann.id
        if existing_ann.created:
            annotation.created = existing_ann.created
    warn_unknown_graph_linked_node_ids(project_root, annotation)
    ann_file = ann_dir / f"{annotation.id}.yaml"
    ann_payload: dict[str, Any] = {
        "id": annotation.id,
        "kind": annotation.kind,
        "severity": annotation.severity,
        "status": annotation.status,
        "origin": annotation.origin,
        "created": annotation.created,
        "note": annotation.note,
        "title": annotation.title or annotation.note,
        "body": annotation.body or annotation.note,
    }
    if annotation.file:
        ann_payload["file"] = annotation.file
    if annotation.affects:
        ann_payload["affects"] = annotation.affects
    if annotation.symbol:
        ann_payload["symbol"] = annotation.symbol
    if annotation.line is not None:
        ann_payload["line"] = annotation.line
    if annotation.finding:
        ann_payload["finding"] = annotation.finding
    if annotation.horizon:
        ann_payload["horizon"] = annotation.horizon
    if annotation.expires_when:
        ann_payload["expires_when"] = annotation.expires_when
    if annotation.assigned:
        ann_payload["assigned"] = annotation.assigned
    if annotation.git_issue:
        ann_payload["git_issue"] = annotation.git_issue
    if annotation.adr_refs:
        ann_payload["adr_refs"] = annotation.adr_refs
    if annotation.checklist:
        ann_payload["checklist"] = annotation.checklist
    if annotation.blocks:
        ann_payload["blocks"] = list(annotation.blocks)
    if annotation.requires:
        ann_payload["requires"] = list(annotation.requires)
    if annotation.phase is not None:
        ann_payload["phase"] = annotation.phase
    if annotation.pipeline_refs:
        ann_payload["pipeline_refs"] = list(annotation.pipeline_refs)
    if annotation.tool_refs:
        ann_payload["tool_refs"] = list(annotation.tool_refs)
    if annotation.elicitation_trigger:
        ann_payload["elicitation_trigger"] = True
    if annotation.reviewed_by is not None:
        ann_payload["reviewed_by"] = annotation.reviewed_by
    if annotation.reviewed_at is not None:
        ann_payload["reviewed_at"] = annotation.reviewed_at
    ann_file.write_text(
        yaml.dump(ann_payload, default_flow_style=False, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    rebuild_annotation_index(project_path=project_root)
    return

    sidecar = directory / SIDECAR_FILENAME
    if sidecar.exists():
        data = yaml.safe_load(sidecar.read_text(encoding="utf-8")) or {}
    else:
        data = {"schema_version": 1, "annotations": []}

    annotations = list(data.get("annotations", []) or [])
    ann_dict = asdict(annotation)

    existing_idx = next((i for i, a in enumerate(annotations) if isinstance(a, dict) and a.get("id") == annotation.id), None)

    if existing_idx is not None:
        annotations[existing_idx] = ann_dict
    else:
        annotations.append(ann_dict)

    data["annotations"] = annotations
    directory.mkdir(parents=True, exist_ok=True)
    sidecar.write_text(
        yaml.dump(data, default_flow_style=False, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )


def _scan_max_annotation_id(project_path: Path) -> int:
    """Fallback when ``annotation-id.lock`` is absent: max N from ``.forge/annotations/ANNOT-*.yaml`` only."""
    annotations_dir = project_path.expanduser().resolve() / ".forge" / "annotations"
    if not annotations_dir.is_dir():
        return 0
    max_id = 0
    for f in annotations_dir.glob("ANNOT-*.yaml"):
        if not f.is_file():
            continue
        try:
            num = int(f.stem.replace("ANNOT-", ""))
        except ValueError:
            continue
        max_id = max(max_id, num)
    return max_id


def next_annotation_id(project_path: Path) -> str:
    """
    Return the next ``ANNOT-NNN`` id using ``.forge/annotation-id.lock`` as the authoritative counter.

    The lock file stores the numeric id that was **just assigned** (not the next free slot).
    When the lock is missing or empty, ``_scan_max_annotation_id`` seeds from ``.forge/annotations/`` once.
    Uses ``fcntl`` flock around read/increment/write when available.
    """
    try:
        import fcntl
    except ImportError:
        fcntl = None  # type: ignore[assignment]

    project_path = project_path.expanduser().resolve()
    lock_path = project_path / ".forge" / "annotation-id.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)

    def _assign_unlocked() -> str:
        if lock_path.is_file() and lock_path.stat().st_size > 0:
            content = lock_path.read_text(encoding="utf-8").strip()
            current = int(content) if content.isdigit() else 0
        else:
            current = _scan_max_annotation_id(project_path)
        next_num = current + 1
        padded = f"{next_num:03d}"
        lock_path.write_text(padded, encoding="utf-8")
        return f"ANNOT-{padded}"

    if fcntl is None:
        return _assign_unlocked()

    # Single file is both mutex and counter: exclusive lock for the whole RMW.
    with lock_path.open("a+", encoding="utf-8") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            handle.seek(0)
            raw = handle.read()
            stripped = raw.strip()
            if stripped.isdigit():
                current = int(stripped)
            elif not stripped:
                current = _scan_max_annotation_id(project_path)
            else:
                current = 0
            next_num = current + 1
            padded = f"{next_num:03d}"
            handle.seek(0)
            handle.truncate()
            handle.write(padded)
            handle.flush()
            return f"ANNOT-{padded}"
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def update_annotation_fields(
    project_path: Path,
    ann_id: str,
    **fields: Any,
) -> AuditAnnotation:
    allowed = {"assigned", "note", "expires_when", "git_issue"}
    found = find_annotation_by_id(project_path, ann_id)
    if not found:
        raise KeyError(f"Annotation not found: {ann_id}")
    directory, ann = found
    for key, val in fields.items():
        if key not in allowed:
            continue
        if val is None:
            continue
        setattr(ann, key, val)
    write_annotation(directory, ann)
    return ann


def apply_annotation_fields(
    project_path: Path,
    ann_id: str,
    fields: dict[str, Any],
) -> AuditAnnotation:
    found = find_annotation_by_id(project_path, ann_id)
    if not found:
        raise KeyError(f"Annotation not found: {ann_id}")
    directory, ann = found
    allowed = {"assigned", "note", "expires_when", "git_issue", "horizon", "status"}
    for key, val in (fields or {}).items():
        if key not in allowed or val is None:
            continue
        setattr(ann, key, val)
    write_annotation(directory, ann)
    return ann


def review_annotation_status(
    project_path: Path,
    ann_id: str,
    *,
    action: str,
    checklist_item: int | None = None,
) -> AuditAnnotation:
    if action not in {"promote", "dismiss"}:
        raise ValueError("Unsupported review action")
    found = find_annotation_by_id(project_path, ann_id)
    if not found:
        raise KeyError(f"Annotation not found: {ann_id}")
    directory, ann = found
    if ann.status != "draft":
        raise ValueError(f"Annotation {ann_id} must be in draft status for action={action}")
    today = date.today().isoformat()
    if action == "dismiss":
        ann.status = "dismissed"
        ann.reviewed_by = "human"
        ann.reviewed_at = today
        write_annotation(directory, ann)
        return ann
    if ann.kind == "verification-checkpoint" and ann.checklist:
        if checklist_item is None:
            for item in ann.checklist:
                item["confirmed"] = True
                item["confirmed_at"] = today
            ann.status = "resolved"
            ann.reviewed_by = "human"
            ann.reviewed_at = today
        else:
            idx = int(checklist_item)
            if idx < 0 or idx >= len(ann.checklist):
                raise ValueError(f"checklist_item out of range: {idx}")
            ann.checklist[idx]["confirmed"] = True
            ann.checklist[idx]["confirmed_at"] = today
            if all(bool(item.get("confirmed")) for item in ann.checklist):
                ann.status = "resolved"
                ann.reviewed_by = "human"
                ann.reviewed_at = today
            else:
                ann.status = "draft"
        write_annotation(directory, ann)
        return ann
    ann.status = "open"
    ann.reviewed_by = "human"
    ann.reviewed_at = today
    write_annotation(directory, ann)
    return ann


def resolve_annotation(
    project_path: Path,
    ann_id: str,
    resolution_note: str,
) -> AuditAnnotation:
    found = find_annotation_by_id(project_path, ann_id)
    if not found:
        raise KeyError(f"Annotation not found: {ann_id}")
    directory, ann = found
    ann.status = "resolved"
    ann.note = f"{ann.note}\n\n(resolved) {resolution_note}".strip()
    write_annotation(directory, ann)
    return ann


def _annotation_match_dict(
    row: dict[str, Any],
    *,
    resolved_from: str,
) -> dict[str, Any]:
    return {
        "annotation_id": row.get("id"),
        "resolved_from": resolved_from,
        "title": row.get("title") or row.get("note"),
        "domain": row.get("domain"),
    }


def _resolve_execution_scope_matches(
    project_path: Path,
    node_id: str,
    rows: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Annotations linked to a node's execution state (path, imports, drift)."""
    if not node_id:
        return []
    matches: list[dict[str, Any]] = []
    try:
        from forge.engine.session import ForgeSession

        session = ForgeSession.open(project_path)
        node = session.node(node_id)
        if node is None:
            return []
        has_path = bool(str(node.path or "").strip())
        import_edges = [
            e for e in session.edges()
            if e.from_id == node_id or e.to_id == node_id
        ]
        drift_kinds = frozenset({
            "drift",
            "execution-drift",
            "node_drifted",
            "gap",
        })
        for row in rows:
            affects = row.get("affects") or []
            if isinstance(affects, list) and any(
                str(a) == node_id for a in affects
            ):
                kind = str(row.get("kind") or "").lower()
                if kind in drift_kinds or has_path or import_edges:
                    matches.append(
                        _annotation_match_dict(
                            row, resolved_from="execution"
                        )
                    )
    except Exception:
        return []
    return matches


def _resolve_intent_scope_matches(
    project_path: Path,
    node_id: str,
    rows: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Annotations contextually linked to intent records for *node_id*."""
    if not node_id:
        return []
    try:
        from forge.tools.intent.runtime import load_intent_records

        intents = [
            r
            for r in load_intent_records(project_path)
            if str(r.target_id or "").strip() == node_id
        ]
        if not intents:
            return []
        intent_ids = {r.id for r in intents}
        matches: list[dict[str, Any]] = []
        for row in rows:
            meta = row.get("meta") if isinstance(row.get("meta"), dict) else {}
            linked = str(meta.get("intent_id") or row.get("intent_id") or "")
            affects = row.get("affects") or []
            if linked in intent_ids:
                matches.append(
                    _annotation_match_dict(row, resolved_from="intent")
                )
            elif isinstance(affects, list) and any(
                str(a) == node_id for a in affects
            ):
                note = str(row.get("note") or row.get("title") or "").lower()
                if "intent" in note:
                    matches.append(
                        _annotation_match_dict(row, resolved_from="intent")
                    )
        return matches
    except Exception:
        return []


def resolve_from(
    scope: str,
    project_path: Path | str,
) -> dict[str, Any] | list[dict[str, Any]]:
    """Resolve annotation context for an execution/intent/declaration scope string."""
    root = Path(project_path).expanduser().resolve()
    try:
        return resolve_annotation_from(root, resolve_from=str(scope))
    except KeyError:
        return []


def resolve_annotation_from(
    project_path: Path,
    *,
    resolve_from: str | None = None,
    node_id: str | None = None,
    domain: str | None = None,
    kind: str | None = None,
    file_path: str | None = None,
    symbol: str | None = None,
) -> dict[str, Any]:
    root = project_path.expanduser().resolve()
    rows: list[dict[str, Any]] = []
    for ann_file in _iter_annotation_files(root):
        raw = _load_annotation_yaml(ann_file)
        if isinstance(raw, dict):
            rows.append(raw)

    if node_id:
        nid = str(node_id).strip()
        for row in rows:
            affects = row.get("affects") or []
            if isinstance(affects, list) and any(str(a) == nid for a in affects):
                return {
                    "annotation_id": row.get("id"),
                    "resolved_from": "node_id",
                    "title": row.get("title") or row.get("note"),
                    "domain": row.get("domain"),
                }
    if domain and kind:
        dom = str(domain).strip().lower()
        kd = str(kind).strip().lower()
        for row in rows:
            row_kind = str(row.get("kind") or "").lower()
            row_domain = str(row.get("domain") or "").lower()
            if not row_domain:
                affects = row.get("affects") or []
                if isinstance(affects, list) and affects:
                    token = str(affects[0]).split(":")[0]
                    row_domain = token.lower()
            if row_kind == kd and row_domain == dom:
                return {
                    "annotation_id": row.get("id"),
                    "resolved_from": "domain+kind",
                    "title": row.get("title") or row.get("note"),
                    "domain": row_domain.upper() if row_domain else None,
                }
    if file_path:
        fp = str(file_path).replace("\\", "/").strip()
        for row in rows:
            if str(row.get("file") or "").replace("\\", "/") == fp:
                return {
                    "annotation_id": row.get("id"),
                    "resolved_from": "file",
                    "title": row.get("title") or row.get("note"),
                    "domain": row.get("domain"),
                }
    if symbol:
        sym = str(symbol).strip().lower()
        for row in rows:
            if str(row.get("symbol") or "").strip().lower() == sym:
                return {
                    "annotation_id": row.get("id"),
                    "resolved_from": "symbol",
                    "title": row.get("title") or row.get("note"),
                    "domain": row.get("domain"),
                }

    if resolve_from:
        rf = str(resolve_from).strip()
        lowered = rf.lower()
        if lowered.startswith("execution:"):
            node_id = rf.split(":", 1)[1].strip()
            matches = _resolve_execution_scope_matches(
                root, node_id, rows
            )
            if matches:
                return matches[0]
        elif lowered.startswith("intent:"):
            node_id = rf.split(":", 1)[1].strip()
            matches = _resolve_intent_scope_matches(
                root, node_id, rows
            )
            if matches:
                return matches[0]
        elif lowered.startswith("declaration:"):
            node_id = rf.split(":", 1)[1].strip()
            for row in rows:
                affects = row.get("affects") or []
                if isinstance(affects, list) and any(
                    str(a) == node_id for a in affects
                ):
                    return {
                        "annotation_id": row.get("id"),
                        "resolved_from": "declaration",
                        "title": row.get("title") or row.get("note"),
                        "domain": row.get("domain"),
                    }
        for row in rows:
            affects = row.get("affects") or []
            if isinstance(affects, list) and any(str(a) == rf for a in affects):
                return {
                    "annotation_id": row.get("id"),
                    "resolved_from": "node_id",
                    "title": row.get("title") or row.get("note"),
                    "domain": row.get("domain"),
                }
            if str(row.get("file") or "").replace("\\", "/") == rf.replace("\\", "/"):
                return {
                    "annotation_id": row.get("id"),
                    "resolved_from": "file",
                    "title": row.get("title") or row.get("note"),
                    "domain": row.get("domain"),
                }
            if str(row.get("symbol") or "").strip().lower() == lowered:
                return {
                    "annotation_id": row.get("id"),
                    "resolved_from": "symbol",
                    "title": row.get("title") or row.get("note"),
                    "domain": row.get("domain"),
                }

    raise KeyError("No annotation match for resolve_from inputs")
