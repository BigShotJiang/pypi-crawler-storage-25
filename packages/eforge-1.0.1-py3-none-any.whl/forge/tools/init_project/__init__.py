"""forge init — onboard existing projects to Forge layout."""

from forge.tools.init_project.runner import run_forge_init

__all__ = ["run_forge_init"]
