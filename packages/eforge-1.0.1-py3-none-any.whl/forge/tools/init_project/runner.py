from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any

import yaml

from forge.core.manifest import ManifestParser
from forge.core.stack_profiles import get_stack_profile
from forge.tools.init_docs.config import resolve_template_path
from forge.tools.scan.detector import detect_framework
from forge.tools.scan.models import FrameworkType
from forge.tools.toc.generator import update_file_toc
from forge.tools.workspace_store import (
    detect_project,
    entry_to_map,
    load_workspace_root,
    projects_map,
    save_workspace_root,
)


def _render_template(text: str, tokens: dict[str, str]) -> str:
    out = text
    for key, val in tokens.items():
        out = out.replace("{{" + key + "}}", val)
    return out


FULL_DOC_FILES = [
    "docs/MAP.md",
    "docs/ARCHITECTURE.md",
    "docs/MANIFEST.md",
    "docs/TODO.md",
    "docs/UPDATE.md",
    "docs/AGENT_CONTEXT.md",
    "docs/ERROR_CODES.md",
    "docs/INTERNALS.md",
]

MINIMAL_DOC_FILES = [
    "docs/AGENT_CONTEXT.md",
]


def _read_pubspec_meta(root: Path) -> tuple[str, str]:
    p = root / "pubspec.yaml"
    if not p.is_file():
        return "", ""
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        if not isinstance(data, dict):
            return "", ""
        name = str(data.get("name") or "").strip()
        ver = str(data.get("version") or "").strip() or "0.1.0"
        return name, ver
    except Exception:
        return "", ""


def _read_package_json_meta(root: Path) -> tuple[str, str]:
    p = root / "package.json"
    if not p.is_file():
        return "", ""
    try:
        data = json.loads(p.read_text(encoding="utf-8") or "{}")
        if not isinstance(data, dict):
            return "", ""
        name = str(data.get("name") or "").strip()
        ver = str(data.get("version") or "0.1.0").strip() or "0.1.0"
        return name, ver
    except Exception:
        return "", ""


def _read_pyproject_meta(root: Path) -> tuple[str, str]:
    p = root / "pyproject.toml"
    if not p.is_file():
        return "", ""
    text = p.read_text(encoding="utf-8", errors="ignore")
    name = ""
    version = ""
    m = re.search(r"(?ms)^\[project\].*?^name\s*=\s*[\"']([^\"']+)[\"']", text)
    if m:
        name = m.group(1).strip()
    m2 = re.search(r"(?ms)^\[project\].*?^version\s*=\s*[\"']([^\"']+)[\"']", text)
    if m2:
        version = m2.group(1).strip()
    if not name:
        m3 = re.search(r"(?ms)^\[tool\.poetry\].*?^name\s*=\s*[\"']([^\"']+)[\"']", text)
        if m3:
            name = m3.group(1).strip()
    if not version:
        m4 = re.search(r"(?ms)^\[tool\.poetry\].*?^version\s*=\s*[\"']([^\"']+)[\"']", text)
        if m4:
            version = m4.group(1).strip()
    if not version:
        version = "0.1.0"
    return name, version


def detect_project_name_version(root: Path) -> tuple[str, str]:
    n, v = _read_pubspec_meta(root)
    if n:
        return n, v
    n, v = _read_package_json_meta(root)
    if n:
        return n, v
    n, v = _read_pyproject_meta(root)
    if n:
        return n, v
    return root.name, "0.1.0"


def _detect_stack(project_path: Path) -> str:
    """
    Auto-detect stack from project files.
    Checks in priority order.
    """
    # Flutter/Dart
    if (project_path / "pubspec.yaml").exists():
        return "flutter-app"

    # Python
    if any(
        [
            (project_path / "pyproject.toml").exists(),
            (project_path / "setup.py").exists(),
            (project_path / "requirements.txt").exists(),
        ]
    ):
        return "python"

    # Astro
    if (project_path / "astro.config.mjs").exists() or (
        project_path / "astro.config.ts"
    ).exists():
        return "astro"

    # React/Next
    if (project_path / "next.config.js").exists() or (
        project_path / "next.config.ts"
    ).exists():
        return "react"

    # Node/TypeScript
    if (project_path / "package.json").exists():
        pkg = (project_path / "package.json").read_text(
            encoding="utf-8", errors="ignore"
        )
        if "react" in pkg:
            return "react"
        return "web"

    return "unknown"


def framework_to_stack(primary: FrameworkType, override: str | None) -> str:
    if override:
        return override.strip().lower()
    return {
        FrameworkType.FLUTTER: "flutter-app",
        FrameworkType.REACT_NATIVE: "web",
        FrameworkType.TYPESCRIPT: "web",
        FrameworkType.PYTHON: "python",
        FrameworkType.UNKNOWN: "unknown",
    }.get(primary, "unknown")


def needs_app_config(primary: FrameworkType) -> bool:
    return primary in (FrameworkType.FLUTTER, FrameworkType.REACT_NATIVE, FrameworkType.TYPESCRIPT)


def build_manifest_dict(name: str, mtype: str, version: str) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "name": name,
        "stack": mtype,
        "type": mtype,
        "version": version,
        "app": {
            "name": name,
            "version": version,
            "type": mtype,
        },
        "phases": [
            {"id": 1, "label": "Foundation", "status": "current"},
        ],
        "screens": [],
        "controllers": [],
        "services": [],
        "dashboard": {
            "checks": [
                {"id": "env", "label": "Environment", "type": "readiness"},
            ]
        },
    }


def build_app_config_dict(name: str, version: str) -> dict[str, Any]:
    return {
        "app": {"name": name, "version": version},
        "ui_lab": {"active_variants": {}},
        "features": {},
        "debug": {"show_debug_banner": True, "log_level": "verbose"},
        "ui": {"primary_color": "#000000"},
        "monetization": {"sparks_enabled": False},
    }


def _default_internals_md(tokens: dict[str, str]) -> str:
    return (
        f"---\nproject: {tokens['PROJECT_NAME']}\nversion: {tokens['PROJECT_VERSION']}\n"
        f"lastUpdated: {tokens['DATE']}\n---\n\n"
        f"# {tokens['PROJECT_NAME']} — INTERNALS\n\n"
        "## Overview\n\nProject internals (fill as you go).\n\n"
        "## Stack\n\n{tokens['STACK']}\n"
    )


@dataclass
class InitResult:
    project_name: str
    stack: str
    created: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    overwritten: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    dry_run: bool = False


def _ensure_forge_dir(project: Path, dry_run: bool) -> list[str]:
    out: list[str] = []
    forge = project / ".forge"
    cache = forge / "context_cache.json"
    g1 = forge / ".gitignore"
    intent_dir = forge / "intent"
    intent_stub = intent_dir / "project.intent.yaml"
    intent_features = intent_dir / "features"
    intent_gitkeep = intent_dir / ".gitkeep"
    if dry_run:
        if not cache.is_file():
            out.append(str(cache.relative_to(project)))
        if not g1.is_file():
            out.append(str(g1.relative_to(project)))
        if not intent_stub.is_file():
            out.append(str(intent_stub.relative_to(project)))
        if not intent_gitkeep.is_file():
            out.append(str(intent_gitkeep.relative_to(project)))
        return out
    forge.mkdir(parents=True, exist_ok=True)
    if not cache.is_file():
        cache.write_text("{}\n", encoding="utf-8")
        out.append(str(cache.relative_to(project)))
    if not g1.is_file():
        g1.write_text("*\n", encoding="utf-8")
        out.append(str(g1.relative_to(project)))
    intent_dir.mkdir(parents=True, exist_ok=True)
    intent_features.mkdir(parents=True, exist_ok=True)
    if not intent_stub.is_file():
        intent_stub.write_text(
            "schema_version: 1\n"
            "document_kind: forge_intent_records\n"
            "records: []\n",
            encoding="utf-8",
        )
        out.append(str(intent_stub.relative_to(project)))
    if not intent_gitkeep.is_file():
        intent_gitkeep.write_text("", encoding="utf-8")
        out.append(str(intent_gitkeep.relative_to(project)))
    return out


def _ensure_root_gitignore(project: Path, dry_run: bool) -> str | None:
    gi = project / ".gitignore"
    required_lines = [
        ".forge/",
        ".forge/verify-last.json",
        "forge.egg-info/",
        "**/__pycache__/",
        ".obsidian/workspace.json",
    ]
    if dry_run:
        if gi.is_file():
            body = gi.read_text(encoding="utf-8", errors="ignore")
            existing = set(body.splitlines())
            missing = [line for line in required_lines if line not in existing]
            if missing:
                return f"(would append {', '.join(missing)} to .gitignore)"
        else:
            return f"(would create .gitignore with {', '.join(required_lines)})"
        return None
    if gi.is_file():
        body = gi.read_text(encoding="utf-8", errors="ignore")
        lines = body.splitlines()
        missing = [line for line in required_lines if line not in lines and not any(l.strip() == line for l in lines)]
        if missing:
            with gi.open("a", encoding="utf-8") as f:
                if body and not body.endswith("\n"):
                    f.write("\n")
                for line in missing:
                    f.write(f"{line}\n")
            return f"appended {', '.join(missing)} to .gitignore"
    else:
        gi.write_text("\n".join(required_lines) + "\n", encoding="utf-8")
        return f"created .gitignore with {', '.join(required_lines)}"
    return None


def register_workspace_quiet(project: Path) -> str:
    try:
        info = detect_project(project)
        if info is None:
            return "workspace: skipped (project markers incomplete — run after manifest exists)"
        doc = load_workspace_root()
        pr = projects_map(doc)
        if info.slug in pr:
            return "workspace: already registered"
        pr[info.slug] = entry_to_map(info)
        save_workspace_root(doc)
        return f"workspace: registered {info.slug}"
    except Exception as exc:  # noqa: BLE001
        return f"workspace: skipped ({exc})"


def run_impact_check_advisory(project: Path) -> str:
    try:
        from forge.tools.docs_audit.orchestrator import run_docs_audit
        from forge.tools.docs_audit.output.summary import build_summary

        manifest_path = project / "docs" / "manifest.yaml"
        if not manifest_path.is_file():
            manifest_path = project / "manifest.yaml"
        # DEPRECATED: change-impact.yaml — advisory impact-check only; skipped when absent.
        impact_path = project / ".forge" / "change-impact.yaml"
        # Create .forge directory if it doesn't exist
        if not impact_path.parent.exists():
            impact_path.parent.mkdir(parents=True, exist_ok=True)
        docs_root = project / "docs"
        if not manifest_path.is_file() or not impact_path.is_file() or not docs_root.is_dir():
            return "impact-check: skipped (need docs/manifest.yaml, .forge/change-impact.yaml, docs/)"

        changed = [str(p).replace("\\", "/") for p in docs_root.rglob("*") if p.is_file()]
        if not changed:
            changed = ["docs/MAP.md"]
        result = run_docs_audit(
            manifest_path=str(manifest_path),
            impact_path=str(impact_path),
            impact_local_path=str(project / "docs" / "change-impact.local.yaml")
            if (project / "docs" / "change-impact.local.yaml").is_file()
            else None,
            docs_root=str(docs_root),
            changed_files=changed,
            strict=False,
        )
        return f"impact-check: {build_summary(result)} (exit {result.exit_code} — advisory only)"
    except Exception as exc:  # noqa: BLE001
        return f"impact-check: skipped ({exc})"


def _validate_manifest_for_init(project: Path) -> str:
    manifest_path = project / ".forge" / "manifest.yaml"
    parser = ManifestParser(manifest_path)
    result = parser.parse()
    if not result.ok:
        msg = result.error or "unknown parse error"
        raise RuntimeError(f"manifest validate failed for {manifest_path}: {msg}")
    warnings = list((result.value or {}).get("warnings") or [])
    if warnings:
        msg = f"manifest validate: ok ({len(warnings)} warning(s))"
    else:
        msg = "manifest validate: ok"
    stack_label = ManifestParser.get_stack(result.value or {})
    profile = get_stack_profile(stack_label)
    schema_name = (profile.schema_stem or str(stack_label or "")).strip()
    if schema_name:
        stack_schema = Path(__file__).resolve().parents[3] / "schemas" / "stacks" / f"{schema_name}.yaml"
        if not stack_schema.is_file():
            msg = (
                f"{msg}; Warning: no stack schema found for stack '{schema_name}'. "
                f"Consider adding schemas/stacks/{schema_name}.yaml."
            )
    return msg


def _bundle_default_schema(
    project: Path,
    *,
    dry_run: bool,
    force: bool,
) -> tuple[str | None, str | None, str | None]:
    src = Path(__file__).resolve().parents[3] / "schemas" / "v1.schema.yaml"
    rel = ".forge/v1.schema.yaml"
    dst = project / rel
    if not src.is_file():
        return None, "schema bundle skipped: source schemas/v1.schema.yaml not found", None
    existed = dst.is_file()
    if existed and not force:
        return None, None, None
    if dry_run:
        return rel, None, ("overwritten" if existed else "created")
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    return rel, None, ("overwritten" if existed else "created")


def run_forge_init(
    project_path: Path,
    *,
    dry_run: bool = False,
    force: bool = False,
    minimal: bool = False,
    stack_override: str | None = None,
) -> InitResult:
    project = project_path.resolve()
    primary, _cand, _reasons = detect_framework(project)
    name, version = detect_project_name_version(project)
    if stack_override:
        stack = stack_override.strip().lower()
    else:
        stack = _detect_stack(project)
        if stack == "unknown":
            stack = framework_to_stack(primary, None)
    result = InitResult(project_name=name, stack=stack, dry_run=dry_run)

    tokens = {
        "PROJECT_NAME": name,
        "PROJECT_VERSION": version,
        "APP_NAME": name,
        "STACK": stack,
        "CURRENT_PHASE": "1",
        "PHASE_LABEL": "Foundation",
        "DATE": date.today().isoformat(),
        "FORGE_VERSION": "1.0.0",
    }

    try:
        template_dir = resolve_template_path()
    except FileNotFoundError:
        template_dir = Path(__file__).resolve().parents[1] / "init_docs" / "templates"

    doc_list = MINIMAL_DOC_FILES if minimal else FULL_DOC_FILES

    # canonical project manifest
    manifest_rel = ".forge/manifest.yaml"
    manifest_dst = project / manifest_rel
    manifest_body = yaml.dump(
        build_manifest_dict(name, stack, version),
        default_flow_style=False,
        sort_keys=False,
        allow_unicode=True,
    )
    if manifest_dst.is_file() and not force:
        result.skipped.append(manifest_rel)
    else:
        if manifest_dst.is_file():
            result.overwritten.append(manifest_rel)
        else:
            result.created.append(manifest_rel)
        if not dry_run:
            manifest_dst.parent.mkdir(parents=True, exist_ok=True)
            manifest_dst.write_text(manifest_body, encoding="utf-8")

    # legacy docs/manifest.yaml mirror for existing docs flows/tests.
    legacy_manifest_rel = "docs/manifest.yaml"
    legacy_manifest_dst = project / legacy_manifest_rel
    if legacy_manifest_dst.is_file() and not force:
        result.skipped.append(legacy_manifest_rel)
    else:
        if legacy_manifest_dst.is_file():
            result.overwritten.append(legacy_manifest_rel)
        else:
            result.created.append(legacy_manifest_rel)
        if not dry_run:
            legacy_manifest_dst.parent.mkdir(parents=True, exist_ok=True)
            legacy_manifest_dst.write_text(manifest_body, encoding="utf-8")

    # Doc markdown files from template
    for rel in doc_list:
        if rel == manifest_rel:
            continue
        dst = project / rel
        src = template_dir / rel
        if dst.is_file() and not force:
            result.skipped.append(rel)
            continue
        if dst.is_file():
            result.overwritten.append(rel)
        else:
            result.created.append(rel)

        if dry_run:
            continue

        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.is_file():
            text = _render_template(src.read_text(encoding="utf-8"), tokens)
        elif rel == "docs/INTERNALS.md":
            text = _default_internals_md(tokens)
        else:
            text = f"# {rel}\n\n_(forge init stub — add content or copy from DOCS-TEMPLATE)_\n"
        dst.write_text(text, encoding="utf-8")
        if dst.suffix.lower() == ".md":
            tr = update_file_toc(dst, min_headings=3, dry_run=False)
            if tr.get("changed"):
                pass

    # app_config for Flutter / React (web) only
    want_config = needs_app_config(primary) or (
        stack_override
        and stack_override.lower() in ("flutter", "flutter-app", "web", "react")
    )
    if want_config:
        flutter_ac = project / "assets" / "app_config.yaml"
        root_ac = project / "app_config.yaml"
        existing = flutter_ac if flutter_ac.is_file() else (root_ac if root_ac.is_file() else None)
        cfg_body = yaml.dump(
            build_app_config_dict(name, version),
            default_flow_style=False,
            sort_keys=False,
            allow_unicode=True,
        )
        if existing is not None:
            if not force:
                result.skipped.append(str(existing.relative_to(project)))
            else:
                rel = str(existing.relative_to(project))
                result.overwritten.append(rel)
                if not dry_run:
                    existing.write_text(cfg_body, encoding="utf-8")
        else:
            if primary == FrameworkType.FLUTTER or stack in (
                "flutter",
                "flutter-app",
            ):
                target, rel = flutter_ac, "assets/app_config.yaml"
            else:
                target, rel = root_ac, "app_config.yaml"
            result.created.append(rel)
            if not dry_run:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(cfg_body, encoding="utf-8")

    # .forge + root .gitignore
    for rel_path in _ensure_forge_dir(project, dry_run):
        if rel_path not in result.created:
            result.created.append(rel_path)
    schema_rel, schema_note, schema_action = _bundle_default_schema(project, dry_run=dry_run, force=force)
    if schema_rel:
        if schema_action == "overwritten":
            result.overwritten.append(schema_rel)
        elif schema_action == "created" and schema_rel not in result.created:
            result.created.append(schema_rel)
    if schema_note:
        result.notes.append(schema_note)
    gi_note = _ensure_root_gitignore(project, dry_run)
    if gi_note:
        result.notes.append(gi_note)

    if not dry_run:
        result.notes.append(register_workspace_quiet(project))
        result.notes.append(_validate_manifest_for_init(project))
        result.notes.append(run_impact_check_advisory(project))

    return result
