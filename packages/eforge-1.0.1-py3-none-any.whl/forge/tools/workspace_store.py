"""
Canonical ~/.forge/workspace.yaml handling: schema, ruamel round-trip,
project discovery metadata, and path resolution for context + MCP.
"""

from __future__ import annotations

import json
import os
import re
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator

import yaml
from ruamel.yaml import YAML

from forge.core.manifest import ManifestParser
from forge.core.manifest_document import ManifestDocument
from ruamel.yaml.comments import CommentedMap

WORKSPACE_VERSION = 1


def forge_home() -> Path:
    return Path.home() / ".forge"


def workspace_yaml_path() -> Path:
    return forge_home() / "workspace.yaml"


def forge_config_path() -> Path:
    return forge_home() / "config.yaml"


CONFIG_DEFAULTS: dict[str, Any] = {
    "schema_version": 1,
    "projects_root": None,
    "projects": {},
    "paths": {
        "docs_template": None,
        "secrets": None,
        "scratch": None,
    },
    "extensions": [],
}


def _yaml_rt() -> YAML:
    y = YAML(typ="rt")
    y.preserve_quotes = True
    return y


def _as_commented_map(obj: Any) -> CommentedMap:
    if isinstance(obj, CommentedMap):
        return obj
    if isinstance(obj, dict):
        cm = CommentedMap()
        for k, v in obj.items():
            if isinstance(v, dict) and not isinstance(v, CommentedMap):
                cm[k] = _as_commented_map(v)
            else:
                cm[k] = v
        return cm
    return CommentedMap()


def load_workspace_root(path: Path | None = None) -> CommentedMap:
    """Load workspace.yaml with ruamel; return a CommentedMap (may be empty)."""
    p = path or workspace_yaml_path()
    y = _yaml_rt()
    if not p.is_file():
        root = CommentedMap()
        root["version"] = WORKSPACE_VERSION
        root["defaults"] = CommentedMap()
        root["projects"] = CommentedMap()
        _ensure_defaults(root)
        return root
    raw = p.read_text(encoding="utf-8")
    data = y.load(raw)
    if data is None:
        root = CommentedMap()
    elif isinstance(data, CommentedMap):
        root = data
    elif isinstance(data, dict):
        root = _as_commented_map(data)
    else:
        root = CommentedMap()
    if "version" not in root:
        root["version"] = WORKSPACE_VERSION
    if "defaults" not in root or not isinstance(root["defaults"], (dict, CommentedMap)):
        root["defaults"] = CommentedMap()
    if "projects" not in root or not isinstance(root["projects"], (dict, CommentedMap)):
        root["projects"] = CommentedMap()
    _ensure_defaults(root)
    return root


def save_workspace_root(doc: CommentedMap, path: Path | None = None) -> None:
    p = path or workspace_yaml_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    y = _yaml_rt()
    with p.open("w", encoding="utf-8") as f:
        y.dump(doc, f)


def _ensure_defaults(root: CommentedMap) -> None:
    d = root["defaults"]
    if not isinstance(d, CommentedMap):
        d = _as_commented_map(dict(d) if isinstance(d, dict) else {})
        root["defaults"] = d
    d.setdefault("projects_root", "~/Projects")
    d.setdefault("secrets_path", "~/Projects/.secrets")
    d.setdefault("scratch_path", "~/.forge/scratch.md")
    if "forge_docs_template_path" not in d:
        d["forge_docs_template_path"] = os.environ.get("FORGE_DOCS_TEMPLATE_PATH") or ""


def projects_map(root: CommentedMap) -> CommentedMap:
    pr = root["projects"]
    if not isinstance(pr, CommentedMap):
        pr = _as_commented_map(dict(pr) if isinstance(pr, dict) else {})
        root["projects"] = pr
    return pr


def slug_from_directory_name(name: str) -> str:
    """Lowercase, underscore style; camelCase and hyphens normalized."""
    s = name.strip().replace("-", "_")
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", s)
    s = s.replace("-", "_").replace(" ", "_")
    s = s.lower()
    s = re.sub(r"_+", "_", s).strip("_")
    return s or "project"


def normalize_slug_key(slug: str) -> str:
    s = slug.strip()
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s)
    s = s.replace("-", "_").replace(" ", "_")
    s = s.lower()
    s = re.sub(r"_+", "_", s).strip("_")
    return s


def slug_variants(slug: str) -> set[str]:
    base = normalize_slug_key(slug)
    compact = base.replace("_", "")
    hy = base.replace("_", "-")
    return {base, compact, hy}


def is_forge_project_dir(p: Path) -> bool:
    if (p / ".forge" / "manifest.yaml").is_file():
        return True
    if (p / "docs" / "manifest.yaml").is_file() or (p / "manifest.yaml").is_file():
        return True
    if (p / "pubspec.yaml").is_file():
        return True
    if (p / "package.json").is_file():
        return True
    if (p / "pyproject.toml").is_file():
        return True
    if (p / "requirements.txt").is_file():
        return True
    return False


def _load_manifest_dict(project_root: Path) -> dict[str, Any] | None:
    root = project_root.expanduser().resolve()
    try:
        doc = ManifestDocument.from_path(root)
        return dict(doc.to_legacy_dict())
    except (FileNotFoundError, ValueError):
        return None


def _phase_int_from_manifest(data: dict[str, Any]) -> int:
    phases = data.get("phases")
    if isinstance(phases, dict):
        cur = phases.get("current")
        if cur is not None:
            try:
                return int(cur)
            except (TypeError, ValueError):
                return 1
    if isinstance(phases, list):
        for p in phases:
            if not isinstance(p, dict):
                continue
            st = str(p.get("status", "")).lower()
            if st in ("current", "in_progress"):
                pid = p.get("id", p.get("phase"))
                if pid is not None:
                    try:
                        return int(pid)
                    except (TypeError, ValueError):
                        return 1
    return 1


def _name_from_manifest(data: dict[str, Any], fallback: str) -> str:
    app = data.get("app")
    if isinstance(app, dict) and app.get("name"):
        return str(app["name"])
    if data.get("name"):
        return str(data["name"])
    return fallback


def _stack_from_pubspec(project_root: Path) -> str | None:
    p = project_root / "pubspec.yaml"
    if not p.is_file():
        return None
    return "flutter"


def _read_package_json(project_root: Path) -> dict[str, Any] | None:
    p = project_root / "package.json"
    if not p.is_file():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _stack_from_package_json(project_root: Path) -> str | None:
    data = _read_package_json(project_root)
    if not data:
        return None
    deps = data.get("dependencies") or {}
    if not isinstance(deps, dict):
        deps = {}
    if "react-native" in deps or "react-native" in str(data.get("name", "")).lower():
        return "react-native"
    if deps.get("react") or "react" in str(data.get("dependencies", {})):
        return "react"
    # Heuristic: if package.json exists and has react in devDependencies
    dev = data.get("devDependencies") or {}
    if isinstance(dev, dict) and dev.get("react"):
        return "react"
    return "react"


def _stack_from_python(project_root: Path) -> str | None:
    if (project_root / "pyproject.toml").is_file():
        return "python"
    if (project_root / "requirements.txt").is_file():
        return "python"
    return None


def _name_from_pubspec(project_root: Path) -> str | None:
    p = project_root / "pubspec.yaml"
    if not p.is_file():
        return None
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        if isinstance(data, dict) and data.get("name"):
            return str(data["name"])
    except Exception:
        pass
    return None


def _name_from_package_json(project_root: Path) -> str | None:
    data = _read_package_json(project_root)
    if data and data.get("name"):
        return str(data["name"])
    return None


def detect_stack(project_root: Path, manifest: dict[str, Any] | None) -> str:
    """Resolve stack from markers first, then from manifest dict.

    Vocabulary split (until Step 1b): manifest path returns canonical labels from
    ``ManifestParser.get_stack`` (e.g. ``flutter-app``, ``python-cli``); marker path
    returns legacy labels (e.g. ``flutter``, ``python``) — to be unified in follow-up.
    """
    if (project_root / "pubspec.yaml").is_file():
        return "flutter"
    pj = _stack_from_package_json(project_root)
    if pj:
        return pj
    py = _stack_from_python(project_root)
    if py:
        return py
    if manifest:
        return ManifestParser.get_stack(manifest)
    return "unknown"


def detect_stack_from_markers(project_root: Path) -> str:
    if (project_root / "pubspec.yaml").is_file():
        return "flutter"
    if (project_root / "package.json").is_file():
        return "react"
    if (project_root / "pyproject.toml").is_file():
        return "python"
    if (project_root / "requirements.txt").is_file():
        return "python"
    return "unknown"


def strip_jsonc_comments(text: str) -> str:
    """
    Remove // line comments and /* */ block comments from JSONC text.
    """
    out: list[str] = []
    in_str = False
    in_line = False
    in_block = False
    escape = False
    i = 0
    while i < len(text):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if in_line:
            if ch == "\n":
                in_line = False
                out.append(ch)
            i += 1
            continue
        if in_block:
            if ch == "*" and nxt == "/":
                in_block = False
                i += 2
            else:
                i += 1
            continue
        if in_str:
            out.append(ch)
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_str = False
            i += 1
            continue
        if ch == '"':
            in_str = True
            out.append(ch)
            i += 1
            continue
        if ch == "/" and nxt == "/":
            in_line = True
            i += 2
            continue
        if ch == "/" and nxt == "*":
            in_block = True
            i += 2
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def load_code_workspace(path: Path) -> dict[str, dict[str, Any]]:
    """
    Load projects from a .code-workspace file.
    """
    try:
        cleaned = strip_jsonc_comments(path.read_text(encoding="utf-8"))
        raw = json.loads(cleaned)
    except Exception:
        return {}
    folders = raw.get("folders") if isinstance(raw, dict) else None
    if not isinstance(folders, list):
        return {}
    base = path.parent.resolve()
    out: dict[str, dict[str, Any]] = {}
    for row in folders:
        if not isinstance(row, dict):
            continue
        p = row.get("path")
        if not p:
            continue
        ap = (base / str(p)).resolve() if not Path(str(p)).is_absolute() else Path(str(p)).resolve()
        slug = slug_from_directory_name(ap.name)
        out[slug] = {
            "path": str(ap),
            "stack": detect_stack_from_markers(ap),
            "source": path.name,
        }
    return out


def _merge_missing(target: CommentedMap, defaults: dict[str, Any]) -> None:
    for k, v in defaults.items():
        if k not in target:
            target[k] = deepcopy(v)
            continue
        cur = target[k]
        if isinstance(cur, (CommentedMap, dict)) and isinstance(v, dict):
            cm = _as_commented_map(cur)
            _merge_missing(cm, v)
            target[k] = cm


def ensure_forge_config(config_path: Path | None = None) -> CommentedMap:
    p = config_path or forge_config_path()
    y = _yaml_rt()
    if p.is_file():
        data = y.load(p.read_text(encoding="utf-8"))
        root = _as_commented_map(data if isinstance(data, dict) else {})
    else:
        root = CommentedMap()
    _merge_missing(root, CONFIG_DEFAULTS)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as f:
        y.dump(root, f)
    return root


def load_forge_config(config_path: Path | None = None) -> dict[str, dict[str, Any]]:
    """
    Load manually registered projects from ~/.forge/config.yaml projects section.
    """
    p = config_path or forge_config_path()
    if not p.is_file():
        return {}
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}
    projects = data.get("projects") or {}
    if not isinstance(projects, dict):
        return {}
    out: dict[str, dict[str, Any]] = {}
    for k, v in projects.items():
        if not isinstance(v, dict):
            continue
        path_s = v.get("path")
        if not path_s:
            continue
        ap = Path(str(path_s)).expanduser().resolve()
        slug = slug_from_directory_name(str(k))
        out[slug] = {
            "path": str(ap),
            "stack": str(v.get("stack") or detect_stack_from_markers(ap)),
            "phase": int(v.get("phase", 1)) if str(v.get("phase", "1")).isdigit() else 1,
            "source": "~/.forge/config.yaml",
        }
    return out


def find_workspace_projects(
    forge_workspace_env: str | None = None,
) -> tuple[dict[str, dict[str, Any]], str]:
    """
    Discover registered projects: prefer ~/.forge/registry.yaml when non-empty;
    else .code-workspace / workspace.yaml + config.yaml (legacy).
    """
    try:
        from forge.tools.registry.store import list_projects, load_registry

        reg = load_registry()
        pmap = reg.get("projects") or {}
        if isinstance(pmap, dict) and len(pmap) > 0:
            out: dict[str, dict[str, Any]] = {}
            for row in list_projects(registry=reg):
                pid = str(row.get("id", ""))
                if not pid:
                    continue
                out[pid] = {
                    "path": str(row.get("path", "")),
                    "stack": str(row.get("stack", "unknown")),
                    "phase": int(row.get("phase", 1)),
                    "source": "registry",
                    "tags": row.get("tags") or [],
                }
            return out, "registry (~/.forge/registry.yaml)"
    except Exception:
        pass

    env_val = forge_workspace_env if forge_workspace_env is not None else os.environ.get("FORGE_WORKSPACE")
    workspace_file: Path | None = None
    projects: dict[str, dict[str, Any]] = {}
    source_label = []

    def _load_yaml_workspace(path: Path) -> dict[str, dict[str, Any]]:
        data = _plain_dict_from_root(path)
        pmap = data.get("projects") or {}
        out: dict[str, dict[str, Any]] = {}
        if isinstance(pmap, dict):
            for k, v in pmap.items():
                if not isinstance(v, dict):
                    continue
                p = v.get("path")
                if not p:
                    continue
                ap = Path(str(p)).expanduser().resolve()
                out[slug_from_directory_name(str(k))] = {
                    "path": str(ap),
                    "stack": str(v.get("stack") or detect_stack_from_markers(ap)),
                    "source": path.name,
                }
        return out

    if env_val:
        wp = Path(env_val).expanduser().resolve()
        if wp.is_file():
            workspace_file = wp
            if wp.suffix == ".code-workspace":
                projects.update(load_code_workspace(wp))
                source_label.append(wp.name)
            elif wp.suffix in {".yaml", ".yml"}:
                projects.update(_load_yaml_workspace(wp))
                source_label.append(wp.name)
    else:
        for pat in (
            Path.home() / "Projects" / "forge-workspace",
            Path.home() / "Projects",
        ):
            hits = sorted(pat.glob("*.code-workspace")) if pat.is_dir() else []
            if hits:
                workspace_file = hits[0].resolve()
                projects.update(load_code_workspace(workspace_file))
                source_label.append(workspace_file.name)
                break

    cfg_projects = load_forge_config()
    projects.update(cfg_projects)  # manual wins
    if cfg_projects:
        source_label.append("~/.forge/config.yaml")

    if not projects:
        return (
            {},
            "none — run: forge projects import <.code-workspace> or forge projects add <path>",
        )
    return projects, " + ".join(source_label) if source_label else "no workspace configured"


def detect_project(project_root: Path, slug_override: str | None = None) -> ProjectInfo | None:
    root = project_root.resolve()
    if not root.is_dir() or not is_forge_project_dir(root):
        return None
    manifest = _load_manifest_dict(root)
    slug = slug_override or slug_from_directory_name(root.name)
    stack = detect_stack(root, manifest)
    phase = _phase_int_from_manifest(manifest) if manifest else 1
    if manifest:
        name = _name_from_manifest(manifest, root.name)
    else:
        name = _name_from_pubspec(root) or _name_from_package_json(root) or root.name
    return ProjectInfo(
        slug=slug,
        path_abs=str(root),
        stack=stack,
        phase=phase,
        name=name,
        status="active",
    )


@dataclass
class ProjectInfo:
    slug: str
    path_abs: str
    stack: str
    phase: int
    name: str
    status: str = "active"


def iter_scan_dirs(root: Path, max_depth: int) -> Iterator[Path]:
    """Subdirectories of root at relative depth 1..max_depth inclusive."""
    root = root.expanduser().resolve()
    if not root.is_dir():
        return
    for dirpath, dirnames, _files in os.walk(root, topdown=True):
        p = Path(dirpath)
        try:
            rel = p.relative_to(root)
        except ValueError:
            continue
        depth = len(rel.parts)
        if depth > max_depth:
            dirnames[:] = []
            continue
        if depth >= 1:
            yield p.resolve()


def _path_from_entry(entry: Any) -> str | None:
    if isinstance(entry, str):
        return entry
    if isinstance(entry, dict):
        p = entry.get("path")
        if p:
            return str(p)
    return None


def _lookup_in_projects(projects: Any, pid: str) -> str | None:
    if projects is None:
        return None
    if isinstance(projects, dict):
        if pid in projects:
            return _path_from_entry(projects[pid])
        for key, entry in projects.items():
            if str(key).lower() == pid.lower():
                return _path_from_entry(entry)
    if isinstance(projects, list):
        for row in projects:
            if not isinstance(row, dict):
                continue
            rid = str(row.get("id") or row.get("name") or row.get("slug") or "")
            if rid == pid or rid.lower() == pid.lower():
                return _path_from_entry(row)
    return None


def _plain_dict_from_root(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        y = _yaml_rt()
        data = y.load(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return {}
        return dict(data)
    except Exception:
        return {}


def _projects_root_from_data(data: dict[str, Any]) -> Path:
    defaults = data.get("defaults") or {}
    if isinstance(defaults, dict):
        pr = defaults.get("projects_root")
        if pr:
            return Path(str(pr)).expanduser().resolve()
    return (Path.home() / "Projects").resolve()


def workspace_yaml_exists() -> bool:
    return workspace_yaml_path().is_file()


def default_scan_root() -> Path:
    """
    Default directory for filesystem discovery (manifest/package markers).
    Order: defaults.projects_root from ~/.forge/workspace.yaml if present and valid dir,
    else ~/Projects if it exists, else cwd. Forge does not require workspace.yaml.
    """
    ws = workspace_yaml_path()
    if ws.is_file():
        data = _plain_dict_from_root(ws)
        pr = _projects_root_from_data(data)
        if pr.is_dir():
            return pr.resolve()
    hp = (Path.home() / "Projects").resolve()
    if hp.is_dir():
        return hp
    return Path.cwd().resolve()


def resolve_project_path(project_id: str) -> Path | None:
    """
    Resolve slug to project root:
      0. ~/.forge/registry.yaml (when present and non-empty project map)
      1. Legacy merged workspace (code-workspace + config) when registry empty
      2. ~/Projects / slug variants
      3. cwd if slug matches and dir looks like a forge project
      4. None
    """
    pid = project_id.strip()
    if not pid:
        return None

    try:
        from forge.tools.registry.store import load_registry, resolve_registry_project_path

        reg = load_registry()
        pmap = reg.get("projects") or {}
        if isinstance(pmap, dict) and len(pmap) > 0:
            hit = resolve_registry_project_path(pid)
            if hit is not None:
                return hit
    except Exception:
        pass

    projects, _src = find_workspace_projects()
    want = slug_variants(pid)
    for slug, info in projects.items():
        cand = slug_variants(slug)
        if want & cand:
            p = Path(str(info.get("path", ""))).expanduser().resolve()
            if p.is_dir():
                return p

    pr = (Path.home() / "Projects").resolve()
    for c in (pid, pid.capitalize(), pid.upper(), normalize_slug_key(pid), normalize_slug_key(pid).replace("_", "-")):
        cand = pr / c
        if cand.is_dir():
            return cand.resolve()

    # CWD fallback removed per INTENT-D03C4F64 - should raise ERR-002 instead
    return None


def workspace_document_to_json_serializable(doc: CommentedMap) -> dict[str, Any]:
    """Convert CommentedMap tree to plain dict for json.dumps."""

    def conv(x: Any) -> Any:
        if isinstance(x, CommentedMap):
            return {str(k): conv(v) for k, v in x.items()}
        if isinstance(x, dict):
            return {str(k): conv(v) for k, v in x.items()}
        if isinstance(x, list):
            return [conv(i) for i in x]
        return x

    return conv(doc)


def entry_to_map(info: ProjectInfo) -> CommentedMap:
    m = CommentedMap()
    m["path"] = info.path_abs
    m["stack"] = info.stack
    m["phase"] = info.phase
    m["status"] = info.status
    m["name"] = info.name
    return m


def shorten_path_display(p: Path) -> str:
    try:
        r = p.resolve()
        home = Path.home().resolve()
        if r == home:
            return "~"
        rel = r.relative_to(home)
        return "~/" + str(rel).replace("\\", "/")
    except ValueError:
        return str(p.resolve())


__all__ = [
    "WORKSPACE_VERSION",
    "ProjectInfo",
    "default_scan_root",
    "detect_project",
    "entry_to_map",
    "forge_home",
    "is_forge_project_dir",
    "CONFIG_DEFAULTS",
    "ensure_forge_config",
    "find_workspace_projects",
    "forge_config_path",
    "load_code_workspace",
    "load_forge_config",
    "normalize_slug_key",
    "iter_scan_dirs",
    "load_workspace_root",
    "projects_map",
    "resolve_project_path",
    "strip_jsonc_comments",
    "save_workspace_root",
    "shorten_path_display",
    "slug_from_directory_name",
    "workspace_document_to_json_serializable",
    "workspace_yaml_exists",
    "workspace_yaml_path",
]
