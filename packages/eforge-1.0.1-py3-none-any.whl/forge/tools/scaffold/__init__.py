"""Workshop mode and scaffold tooling (phase-1 stubs)."""
