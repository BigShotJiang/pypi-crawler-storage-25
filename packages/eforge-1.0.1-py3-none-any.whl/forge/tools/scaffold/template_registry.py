from __future__ import annotations

from pathlib import Path
from typing import Any
import json

import forge.core.template_registry as core_tr

from forge.tools.scaffold.props_parser import ParsedContractBlock, parse_palette_entries_for_file
from forge.tools.scaffold.canvas_schema import CanvasNode


def resolve_ui_templates_root() -> Path:
    """
    Resolve UI-TEMPLATES root directory.

    Uses the same DOCS-TEMPLATE priority chain as init-docs via forge/core/template_registry.
    """
    return core_tr.resolve_ui_templates_root()


def _select_react_parse_source(sources: list[Path]) -> Path | None:
    if not sources:
        return None
    # Prefer .tsx > .ts > .module.css > .css
    def key(p: Path) -> int:
        n = p.name
        if n.endswith(".tsx"):
            return 0
        if n.endswith(".ts"):
            return 1
        if n.endswith(".module.css"):
            return 2
        if n.endswith(".css"):
            return 3
        return 9

    return sorted(sources, key=key)[0]


def _contract_entry_to_dict(src: Path, block: ParsedContractBlock) -> dict[str, Any]:
    return {
        "name": block.name,
        "file": src.name,
        "layer": block.layer,
        "props": [p.to_dict() for p in block.props],
        "states": block.states,
        "events": block.events,
        "slots": block.slots,
        "preview": None,
    }


def _components_for_flutter_unit(ui_root: Path, unit: str) -> list[dict[str, Any]]:
    # Each flutter unit maps to a single .dart file in our registry.
    sources = core_tr.source_files_for_flutter_unit(ui_root, unit)
    if not sources:
        return []
    src = sources[0]
    entries = parse_palette_entries_for_file(src, unit)
    if not entries:
        return [
            {
                "name": unit,
                "file": src.name,
                "layer": None,
                "props": [],
                "states": [],
                "events": [],
                "slots": [],
                "preview": None,
            }
        ]
    return [_contract_entry_to_dict(src, b) for b in entries]


def _components_for_react_unit(ui_root: Path, unit: str) -> list[dict[str, Any]]:
    sources = core_tr.source_files_for_react_unit(ui_root, unit)
    if not sources:
        return []
    src = _select_react_parse_source(sources)
    if src is None:
        return []
    entries = parse_palette_entries_for_file(src, unit)
    if not entries:
        return [
            {
                "name": unit,
                "file": src.name,
                "layer": None,
                "props": [],
                "states": [],
                "events": [],
                "slots": [],
                "preview": None,
            }
        ]
    return [_contract_entry_to_dict(src, b) for b in entries]


def get_components_registry(stack: str) -> dict[str, Any]:
    """
    Build the response payload for GET /api/composer/components (per stack).
    """
    ui_root = resolve_ui_templates_root()
    if stack not in core_tr.REGISTRY:
        return {}

    out: dict[str, Any] = {}
    categories = core_tr.REGISTRY[stack]
    for category, units in categories.items():
        out[category] = []
        for unit in units:
            if stack == "flutter":
                out[category].extend(_components_for_flutter_unit(ui_root, unit))
            else:
                out[category].extend(_components_for_react_unit(ui_root, unit))
    return out


def list_recipes() -> list[dict[str, Any]]:
    ui_root = resolve_ui_templates_root()
    recipes_dir = ui_root / "recipes"
    if not recipes_dir.exists() or not recipes_dir.is_dir():
        recipes_dir = Path(__file__).resolve().parents[2] / "core" / "recipes"
    if not recipes_dir.exists() or not recipes_dir.is_dir():
        return []
    out: list[dict[str, Any]] = []
    for p in sorted(recipes_dir.glob("*.json")):
        try:
            payload = json.loads(p.read_text(encoding="utf-8"))
            tree = CanvasNode.from_dict(dict(payload.get("tree") or {})).to_dict()
            out.append(
                {
                    "id": str(payload.get("id") or p.stem),
                    "name": str(payload.get("name") or p.stem),
                    "description": str(payload.get("description") or ""),
                    "stack": str(payload.get("stack") or "all"),
                    "thumbnail": payload.get("thumbnail"),
                    "tree": tree,
                }
            )
        except Exception:
            continue
    return out


def get_recipe_by_id(recipe_id: str) -> dict[str, Any] | None:
    for r in list_recipes():
        if r.get("id") == recipe_id:
            return r
    return None


# ── Local scaffold code-body registry ─────────────────────────────────────────

_LOCAL_REGISTRIES_ROOT = Path("~/.forge/registries/local").expanduser()
# Bundled templates ship with the forge package under templates/scaffold/
_BUNDLED_TEMPLATES_ROOT = Path(__file__).resolve().parents[3] / "templates" / "scaffold"


def resolve_scaffold_template(
    kind: str,
    stack: str | None = None,
    name: str = "default",
    project_root: Path | None = None,
) -> dict[str, Any]:
    """
    Resolve a code scaffold template.

    Search order (first match wins) per INTENT-364CC387:
      1. Project-local: .forge/templates/{kind}/{stack}.yaml — project repo
      2. Project-local: .forge/templates/{kind}/{name}.dart.yaml — project default (dart)
      3. Project-local: .forge/templates/{kind}/{name}.yaml — project default
      4. Global: FORGE_DOCS_TEMPLATE_PATH/templates/scaffold/{kind}/{stack}.yaml
      5. Global: FORGE_DOCS_TEMPLATE_PATH/templates/scaffold/{kind}/{name}.dart.yaml
      6. Global: FORGE_DOCS_TEMPLATE_PATH/templates/scaffold/{kind}/{name}.yaml
      7. Bundled: <forge_package>/templates/scaffold/{kind}/{stack}.yaml
      8. Bundled: <forge_package>/templates/scaffold/{kind}/{name}.dart.yaml
      9. Bundled: <forge_package>/templates/scaffold/{kind}/{name}.yaml

    Args:
        kind: Template kind (e.g., 'screen', 'controller', 'service')
        stack: Stack-specific template name (e.g., 'flutter-app', 'python-cli')
        name: Default template name (default: 'default')
        project_root: Project root path for project-local templates

    Returns:
        Parsed template dict.

    Raises:
        FileNotFoundError: If no template found in any location.

    Template YAML format:
        kind: screen
        stack: flutter-app
        slots: [id, domain, watches]
        output_path: "lib/features/{domain_lower}/{id}_screen.dart"
        body: |
          import 'package:flutter/material.dart';
          class {PascalId}Screen extends StatelessWidget { ... }
    """
    import yaml as _yaml
    import os

    def _try_candidates(root: Path) -> dict[str, Any] | None:
        """Try template candidates in a root directory."""
        candidates: list[Path] = []
        if stack:
            safe = stack.replace("-", "_").replace("/", "_")
            candidates.append(root / f"{safe}.yaml")
        candidates.append(root / f"{name}.dart.yaml")
        candidates.append(root / f"{name}.yaml")
        for p in candidates:
            if p.is_file():
                try:
                    data = _yaml.safe_load(p.read_text(encoding="utf-8"))
                    if isinstance(data, dict):
                        return data
                except Exception:
                    pass
        return None

    def _get_global_template_root() -> Path:
        """Get global template root from FORGE_DOCS_TEMPLATE_PATH."""
        env = os.environ.get("FORGE_DOCS_TEMPLATE_PATH")
        if env:
            p = Path(env).expanduser().resolve()
            if p.exists() and p.is_dir():
                return p / "templates" / "scaffold"
            raise FileNotFoundError(
                f"FORGE_DOCS_TEMPLATE_PATH is set but directory not found: {p}\n"
                "Unset it or fix the path."
            )
        # Fall back to sibling DOCS-TEMPLATE if env not set
        repo = Path(__file__).resolve().parent.parent.parent
        sibling = (repo.parent / "DOCS-TEMPLATE").resolve()
        if sibling.exists() and sibling.is_dir():
            return sibling / "templates" / "scaffold"
        return None

    # 1. Project-local templates (highest priority)
    if project_root is not None:
        project_templates = project_root / ".forge" / "templates"
        if project_templates.exists():
            result = _try_candidates(project_templates / kind)
            if result is not None:
                return result

    # 2. Global templates from FORGE_DOCS_TEMPLATE_PATH
    global_root = _get_global_template_root()
    if global_root is not None and global_root.exists():
        result = _try_candidates(global_root / kind)
        if result is not None:
            return result

    # 3. Bundled templates (fallback)
    result = _try_candidates(_BUNDLED_TEMPLATES_ROOT / kind)
    if result is not None:
        return result

    # 4. Hard error if nothing resolves
    search_paths = []
    if project_root is not None:
        search_paths.append(f"{project_root}/.forge/templates/{kind}/")
    if global_root is not None:
        search_paths.append(f"{global_root}/{kind}/")
    search_paths.append(f"{_BUNDLED_TEMPLATES_ROOT}/{kind}/")

    raise FileNotFoundError(
        f"Template not found: kind='{kind}', stack='{stack}', name='{name}'. "
        f"Searched in: {', '.join(str(p) for p in search_paths)}. "
        "Create a template in one of these locations or check the template name."
    )

