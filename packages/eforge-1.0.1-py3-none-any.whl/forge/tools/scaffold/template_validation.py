from __future__ import annotations

from pathlib import Path
from typing import Any

from forge.tools.scaffold.template_expressions import referenced_names, validate_safe_expr

_INPUT_TYPES = {"str", "bool", "enum", "int", "list"}
_WIRING_KINDS = {"imports", "registrations", "dependency_edges"}
_OPERATIONS_PERMISSIONS = {"read", "write", "admin"}
_OPERATIONS_EXECUTOR_KINDS = {"cli", "mcp"}


def validate_template_extensions(data: dict[str, Any], path: Path) -> list[str]:
    errs: list[str] = []
    declared_inputs: set[str] = set()

    inputs = data.get("inputs")
    if inputs is not None:
        if not isinstance(inputs, dict):
            errs.append("inputs must be an object/map when present")
        else:
            for name, cfg in inputs.items():
                if not isinstance(name, str) or not name.strip():
                    errs.append("inputs keys must be non-empty strings")
                    continue
                declared_inputs.add(name)
                if not isinstance(cfg, dict):
                    errs.append(f"inputs.{name} must be an object")
                    continue
                t = str(cfg.get("type") or "")
                if t not in _INPUT_TYPES:
                    errs.append(f"inputs.{name}.type must be one of {sorted(_INPUT_TYPES)}")
                req = cfg.get("required")
                if not isinstance(req, bool):
                    errs.append(f"inputs.{name}.required must be bool")
                desc = cfg.get("description")
                if not isinstance(desc, str) or not desc.strip():
                    errs.append(f"inputs.{name}.description must be a non-empty string")
                has_default = "default" in cfg
                if req is False and not has_default:
                    errs.append(f"inputs.{name}.default required when required=false")
                if t == "list" and has_default:
                    dv = cfg.get("default")
                    if not isinstance(dv, list) or not dv or not all(isinstance(x, str) for x in dv):
                        errs.append(
                            f"inputs.{name}.default must be a non-empty list of strings when type=list"
                        )
                values = cfg.get("values")
                if t == "enum":
                    if not isinstance(values, list) or not values or not all(isinstance(v, str) for v in values):
                        errs.append(f"inputs.{name}.values must be a non-empty string list for enum")
                    if has_default and isinstance(values, list) and cfg.get("default") not in values:
                        errs.append(f"inputs.{name}.default must be one of values")
                elif values is not None:
                    errs.append(f"inputs.{name}.values only allowed when type=enum")
                cond = cfg.get("condition")
                if cond is not None:
                    if not isinstance(cond, str) or not cond.strip():
                        errs.append(f"inputs.{name}.condition must be a non-empty string when present")
                    else:
                        try:
                            validate_safe_expr(cond, declared_inputs | {name})
                        except ValueError as exc:
                            errs.append(f"inputs.{name}.condition invalid: {exc}")

    conditionals = data.get("conditionals")
    if conditionals is not None:
        if not isinstance(conditionals, list):
            errs.append("conditionals must be a list when present")
        else:
            for i, row in enumerate(conditionals):
                pfx = f"conditionals[{i}]"
                if not isinstance(row, dict):
                    errs.append(f"{pfx} must be an object")
                    continue
                when = row.get("when")
                if not isinstance(when, str) or not when.strip():
                    errs.append(f"{pfx}.when must be a non-empty string")
                else:
                    names = referenced_names(when)
                    unknown = sorted(names - declared_inputs)
                    if unknown:
                        errs.append(f"{pfx}.when references unknown inputs: {unknown}")
                    else:
                        try:
                            validate_safe_expr(when, declared_inputs)
                        except ValueError as exc:
                            errs.append(f"{pfx}.when invalid: {exc}")
                inject = row.get("inject")
                if not isinstance(inject, dict):
                    errs.append(f"{pfx}.inject must be an object")
                else:
                    bf = inject.get("file")
                    if not isinstance(bf, str) or not bf.strip():
                        errs.append(f"{pfx}.inject.file must be a non-empty string")
                    tgt = inject.get("target")
                    if not isinstance(tgt, str) or not tgt.strip():
                        errs.append(f"{pfx}.inject.target must be a non-empty string")
                po = row.get("produces_override")
                if po is not None and (not isinstance(po, list) or not all(isinstance(x, str) for x in po)):
                    errs.append(f"{pfx}.produces_override must be a list of strings when present")

    wiring = data.get("wiring")
    if wiring is not None:
        if not isinstance(wiring, list):
            errs.append("wiring must be a list when present")
        else:
            for i, row in enumerate(wiring):
                pfx = f"wiring[{i}]"
                if not isinstance(row, dict):
                    errs.append(f"{pfx} must be an object")
                    continue
                kind = str(row.get("kind") or "")
                if kind not in _WIRING_KINDS:
                    errs.append(f"{pfx}.kind must be one of {sorted(_WIRING_KINDS)}")
                tgt = row.get("target")
                if not isinstance(tgt, str) or not tgt.strip():
                    errs.append(f"{pfx}.target must be a non-empty string")
                val = row.get("value")
                if not isinstance(val, str) or not val.strip():
                    errs.append(f"{pfx}.value must be a non-empty string")
                when = row.get("when")
                if when is not None:
                    if not isinstance(when, str) or not when.strip():
                        errs.append(f"{pfx}.when must be a non-empty string when present")
                    else:
                        names = referenced_names(when)
                        unknown = sorted(names - declared_inputs)
                        if unknown:
                            errs.append(f"{pfx}.when references unknown inputs: {unknown}")
                        else:
                            try:
                                validate_safe_expr(when, declared_inputs)
                            except ValueError as exc:
                                errs.append(f"{pfx}.when invalid: {exc}")
    operations = data.get("operations")
    if operations is not None:
        if not isinstance(operations, list):
            errs.append("operations must be a list when present")
        else:
            for i, row in enumerate(operations):
                pfx = f"operations[{i}]"
                if not isinstance(row, dict):
                    errs.append(f"{pfx} must be an object")
                    continue
                op_id = row.get("id")
                if not isinstance(op_id, str) or not op_id.strip():
                    errs.append(f"{pfx}.id must be a non-empty string")
                desc = row.get("description")
                if not isinstance(desc, str) or not desc.strip():
                    errs.append(f"{pfx}.description must be a non-empty string")
                perm = row.get("permissions")
                if not isinstance(perm, str) or perm not in _OPERATIONS_PERMISSIONS:
                    errs.append(
                        f"{pfx}.permissions must be one of {sorted(_OPERATIONS_PERMISSIONS)}"
                    )
                inputs = row.get("inputs")
                if inputs is not None:
                    if not isinstance(inputs, dict):
                        errs.append(f"{pfx}.inputs must be an object/map when present")
                    else:
                        for in_name, cfg in inputs.items():
                            ipfx = f"{pfx}.inputs.{in_name}"
                            if not isinstance(cfg, dict):
                                errs.append(f"{ipfx} must be an object")
                                continue
                            t = str(cfg.get("type") or "")
                            if t not in _INPUT_TYPES:
                                errs.append(
                                    f"{ipfx}.type must be one of {sorted(_INPUT_TYPES)}"
                                )
                            req = cfg.get("required")
                            if not isinstance(req, bool):
                                errs.append(f"{ipfx}.required must be bool")
                            ide = cfg.get("description")
                            if not isinstance(ide, str) or not ide.strip():
                                errs.append(
                                    f"{ipfx}.description must be a non-empty string"
                                )
                            values = cfg.get("values")
                            if t == "enum":
                                if (
                                    not isinstance(values, list)
                                    or not values
                                    or not all(isinstance(v, str) for v in values)
                                ):
                                    errs.append(
                                        f"{ipfx}.values must be a non-empty string list for enum"
                                    )
                            elif values is not None:
                                errs.append(
                                    f"{ipfx}.values only allowed when type=enum"
                                )
                executor = row.get("executor")
                if not isinstance(executor, dict):
                    errs.append(f"{pfx}.executor must be an object")
                else:
                    kind = executor.get("kind")
                    if (
                        not isinstance(kind, str)
                        or kind not in _OPERATIONS_EXECUTOR_KINDS
                    ):
                        errs.append(
                            f"{pfx}.executor.kind must be one of {sorted(_OPERATIONS_EXECUTOR_KINDS)}"
                        )
                    command = executor.get("command")
                    tool = executor.get("tool")
                    if kind == "cli":
                        if not isinstance(command, str) or not command.strip():
                            errs.append(
                                f"{pfx}.executor.command must be a non-empty string when kind=cli"
                            )
                    if kind == "mcp":
                        if not isinstance(tool, str) or not tool.strip():
                            errs.append(
                                f"{pfx}.executor.tool must be a non-empty string when kind=mcp"
                            )
                    args = executor.get("args")
                    if args is not None and not isinstance(args, dict):
                        errs.append(
                            f"{pfx}.executor.args must be an object/map when present"
                        )
    return errs
