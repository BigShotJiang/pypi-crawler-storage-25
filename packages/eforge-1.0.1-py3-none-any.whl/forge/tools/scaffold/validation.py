"""
Manifest entry validation for Composer export, MCP scaffold, and related flows.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

FORGE_DOMAINS = frozenset(
    {
        "AUTH",
        "CANVAS",
        "GAME",
        "LOBBY",
        "PROFILE",
        "PREMIUM",
        "CORE",
        "REMOTE",
        "THEME",
    }
)


@dataclass
class ValidationResult:
    exit_code: int  # 0 clean, 1 warn, 2 block
    passed: int
    warnings: list[str] = field(default_factory=list)
    blockers: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)
    confidence: float = 0.0


def format_validation_summary(result: ValidationResult) -> str:
    if result.blockers:
        return f"✗ {len(result.blockers)} blocker(s) — fix before using"
    if result.warnings:
        return f"⚠ {len(result.warnings)} warnings — safe to use, review later"
    return f"✓ Valid — {result.passed} checks passed"


def _norm_domain(raw: str) -> str:
    return (raw or "").strip().upper()


def _entry_file(entry: dict[str, Any]) -> str:
    return str(entry.get("file") or entry.get("path") or "").strip()


def infer_domain_token_from_path(file_rel: str) -> str | None:
    u = file_rel.replace("\\", "/").upper()
    for d in sorted(FORGE_DOMAINS, key=len, reverse=True):
        if d == "CORE":
            continue
        if d in u:
            return d
    return None


def _collect_domains_from_manifest(project_path: str) -> list[str]:
    """Thin shim — delegates to the canonical implementation in parser.py.

    Signature changed from (data: dict) → (project_path: str) as part of the
    ANNOT-031/ANNOT-038 extraction.  The only internal call site
    (validate_manifest_entry) has been updated accordingly.
    """
    from forge.tools.scaffold.parser import collect_manifest_domains
    return collect_manifest_domains(project_path)


def _load_manifest_data(project_path: Path) -> dict[str, Any] | None:
    from forge.core.manifest_document import ManifestDocument

    root = project_path.expanduser().resolve()
    try:
        doc = ManifestDocument.from_path(root)
        return dict(doc.to_legacy_dict())
    except (FileNotFoundError, ValueError):
        return None


def _infer_stack_from_file(file_rel: str) -> str:
    low = file_rel.lower()
    if low.endswith(".dart"):
        return "flutter"
    if low.endswith((".tsx", ".jsx", ".ts", ".js")):
        return "web"
    return "unknown"


def _path_matches_convention(file_rel: str, domain: str, stack: str) -> tuple[bool, str | None]:
    fr = file_rel.replace("\\", "/")
    if stack == "flutter":
        if "lib/features/" in fr:
            return True, None
        return False, "Prefer Flutter paths under lib/features/{domain}/"
    if stack == "web":
        if "src/features/" in fr:
            return True, None
        if "src/screens/" in fr or "src/components/" in fr:
            return True, None
        return False, "Prefer React paths under src/features/{domain}/ or src/screens/"
    return True, None


def validate_manifest_entry(
    entry: dict[str, Any],
    entry_type: str,
    project_path: Path | None = None,
) -> ValidationResult:
    """
    Validate a manifest.yaml-style entry. Never raises to callers.
    """
    warnings: list[str] = []
    blockers: list[str] = []
    suggestions: list[str] = []
    passed = 0
    try:
        et = (entry_type or "").strip().lower()
        entry = entry if isinstance(entry, dict) else {}

        if et not in ("screen", "controller", "service"):
            blockers.append(f"Invalid entry_type {entry_type!r} (expected screen|controller|service)")
            vr = ValidationResult(2, 0, warnings, blockers, suggestions, 0.0)
            vr.confidence = compute_confidence(entry, et, vr)
            return vr

        name = str(entry.get("name") or "").strip()
        if name:
            passed += 1
        else:
            blockers.append("Missing required field: name")

        rel = _entry_file(entry)
        if rel:
            passed += 1
        else:
            blockers.append("Missing required field: file (or path)")

        domain_raw = str(entry.get("domain") or "").strip()
        dom = _norm_domain(domain_raw)
        if dom:
            passed += 1
        else:
            blockers.append("Missing required field: domain")

        if dom and dom not in FORGE_DOMAINS:
            blockers.append(f"Invalid Forge domain {domain_raw!r} (expected one of {sorted(FORGE_DOMAINS)})")

        if et == "screen":
            if "watches" not in entry:
                warnings.append("screen: missing watches key (recommend a list, possibly empty)")
            elif not isinstance(entry.get("watches"), list):
                warnings.append("screen: watches should be a list")
            else:
                passed += 1
                w = entry.get("watches")
                if isinstance(w, list) and len(w) == 0:
                    warnings.append("screen: watches is empty")

        if et == "controller":
            iface = entry.get("interface")
            if iface is None or iface in ({}, [], ""):
                warnings.append("controller: interface block missing or empty (recommended)")
            else:
                passed += 1
            ec = entry.get("error_codes")
            if ec is None:
                warnings.append("controller: error_codes missing (recommend [])")
            elif isinstance(ec, list) and len(ec) == 0:
                warnings.append("controller: error_codes is empty")
            if isinstance(ec, list) and len(ec) > 0:
                passed += 1

        stack = _infer_stack_from_file(rel) if rel else "unknown"
        if rel and dom:
            ok_path, hint = _path_matches_convention(rel, dom, stack)
            if ok_path:
                passed += 1
            elif hint:
                warnings.append(f"file path: {hint}")
        elif rel:
            passed += 1

        if project_path is not None and rel:
            try:
                root = project_path.resolve()
                candidate = root / rel
                if candidate.exists():
                    warnings.append(f"Target file already exists: {rel} (possible overwrite)")
            except Exception:
                pass

        if project_path is not None and dom:
            known = set(_collect_domains_from_manifest(str(project_path.resolve())))
            if known and dom not in known:
                warnings.append(
                    f"Domain {dom} not present in existing manifest.yaml entries — new domain introduced"
                )

        if blockers:
            exit_code = 2
        elif warnings:
            exit_code = 1
        else:
            exit_code = 0

        vr = ValidationResult(
            exit_code=exit_code,
            passed=passed,
            warnings=warnings,
            blockers=blockers,
            suggestions=suggestions,
            confidence=0.0,
        )
        vr.confidence = compute_confidence(entry, et, vr)
        return vr
    except Exception as exc:  # noqa: BLE001 — contract: never raise
        return ValidationResult(
            exit_code=2,
            passed=passed,
            warnings=warnings,
            blockers=blockers + [f"Unexpected validation error: {exc}"],
            suggestions=suggestions,
            confidence=0.0,
        )


def compute_confidence(entry: dict[str, Any], entry_type: str, validation: ValidationResult) -> float:
    """Score 0.0–1.0 from structure + validation lists."""
    et = (entry_type or "").strip().lower()
    rel = _entry_file(entry)
    dom = _norm_domain(str(entry.get("domain") or ""))

    score = 0.0
    has_name = bool(str(entry.get("name") or "").strip())
    has_file = bool(rel)
    has_domain = bool(dom)
    if has_name and has_file and has_domain:
        score += 0.3

    if dom in FORGE_DOMAINS:
        score += 0.2

    stack = _infer_stack_from_file(rel) if rel else "unknown"
    if rel and dom:
        ok_path, _ = _path_matches_convention(rel, dom, stack)
        if ok_path:
            score += 0.2
    elif rel:
        score += 0.1

    if et == "screen" and isinstance(entry.get("watches"), list) and len(entry["watches"]) > 0:
        score += 0.15

    if et == "controller":
        iface = entry.get("interface")
        if iface not in (None, {}, [], ""):
            score += 0.1
        ec = entry.get("error_codes")
        if isinstance(ec, list) and len(ec) > 0:
            score += 0.1
        if iface in (None, {}, [], ""):
            score -= 0.2
        if ec is None or (isinstance(ec, list) and len(ec) == 0):
            score -= 0.1

    if dom == "CORE":
        score -= 0.1

    score -= 0.4 * len(validation.blockers)
    score -= 0.1 * len(validation.warnings)

    return max(0.0, min(1.0, score))


def aggregate_validation_results(results: list[ValidationResult]) -> ValidationResult:
    if not results:
        return ValidationResult(0, 0, [], [], [], 1.0)
    exit_code = max(r.exit_code for r in results)
    passed = sum(r.passed for r in results)
    warnings: list[str] = []
    blockers: list[str] = []
    suggestions: list[str] = []
    for r in results:
        warnings.extend(r.warnings)
        blockers.extend(r.blockers)
        suggestions.extend(r.suggestions)
    confidence = min(r.confidence for r in results) if results else 1.0
    return ValidationResult(exit_code, passed, warnings, blockers, suggestions, confidence)


def merge_docs_audit_into_validation(vr: ValidationResult, audit: Any) -> ValidationResult:
    from forge.tools.docs_audit.contracts.models import AuditFailure, Severity

    blockers = list(vr.blockers)
    warnings = list(vr.warnings)
    suggestions = list(vr.suggestions)
    for f in getattr(audit, "failures", []) or []:
        if not isinstance(f, AuditFailure):
            continue
        msg = f"{f.rule_id}: {f.message}"
        if f.severity == Severity.BLOCKER or (
            bool(getattr(audit, "strict", False)) and f.severity == Severity.HIGH
        ):
            blockers.append(msg)
        elif f.severity in (Severity.HIGH, Severity.WARN):
            warnings.append(msg)
        else:
            suggestions.append(msg)

    exit_code = max(vr.exit_code, int(getattr(audit, "exit_code", 0) or 0))

    conf = min(vr.confidence, max(0.0, 1.0 - 0.08 * len(getattr(audit, "failures", []) or [])))
    return ValidationResult(exit_code, vr.passed, warnings, blockers, suggestions, conf)


def try_run_docs_audit(project_root: Path, changed_files: list[str]) -> Any | None:
    try:
        from forge.mcp.audit import resolve_audit_paths
        from forge.tools.docs_audit.orchestrator import run_docs_audit

        manifest_path, impact_path, impact_local, docs_root = resolve_audit_paths(project_root)
        if not manifest_path.is_file() or not impact_path.is_file():
            return None
        il = str(impact_local) if impact_local and impact_local.is_file() else None
        return run_docs_audit(
            manifest_path=str(manifest_path),
            impact_path=str(impact_path),
            impact_local_path=il,
            docs_root=str(docs_root),
            changed_files=changed_files,
            changed_text="",
            strict=False,
        )
    except Exception:
        return None


def merge_validation_and_audit(
    base: ValidationResult,
    project_root: Path,
    changed_files: list[str],
) -> ValidationResult:
    audit = try_run_docs_audit(project_root, changed_files)
    if audit is None:
        return base
    return merge_docs_audit_into_validation(base, audit)


def validation_result_to_dict(vr: ValidationResult) -> dict[str, Any]:
    return {
        "exit_code": vr.exit_code,
        "passed": vr.passed,
        "warnings": list(vr.warnings),
        "blockers": list(vr.blockers),
        "suggestions": list(vr.suggestions),
        "confidence": vr.confidence,
        "summary": format_validation_summary(vr),
    }
