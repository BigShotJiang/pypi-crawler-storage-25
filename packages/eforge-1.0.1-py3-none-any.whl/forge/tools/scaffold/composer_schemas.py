from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class CanvasNodeSchema(BaseModel):
    id: str
    component: str
    props: dict[str, Any] = Field(default_factory=dict)
    wiring: dict[str, Any] = Field(default_factory=dict)
    variant: str | None = None
    children: list["CanvasNodeSchema"] = Field(default_factory=list)
    slot: str | None = None


class CanvasMetaSchema(BaseModel):
    name: str
    version: str
    stack: str
    created: str
    author: str
    app: str
    forge_version: str


class CanvasConfigSchema(BaseModel):
    shell: str
    variant: str
    token_set: str


class CanvasTreeSchema(BaseModel):
    meta: CanvasMetaSchema
    config: CanvasConfigSchema
    tree: CanvasNodeSchema


class ExportRequest(BaseModel):
    canvas: CanvasTreeSchema
    project_path: str
    write_to_disk: bool = False


class ExportFile(BaseModel):
    path: str
    content: str
    exists: bool


class ImpactCheckResult(BaseModel):
    exit_code: int
    status: str
    blocker_count: int
    warn_count: int
    failures: list[dict[str, Any]]


class ValidationPayload(BaseModel):
    """Aggregated manifest-entry + optional docs-audit checks for scaffold/export."""

    exit_code: int = 0
    passed: int = 0
    warnings: list[str] = Field(default_factory=list)
    blockers: list[str] = Field(default_factory=list)
    suggestions: list[str] = Field(default_factory=list)
    confidence: float = 0.0
    summary: str = ""


class ExportResponse(BaseModel):
    files: list[ExportFile]
    warnings: list[str]
    impact_check: ImpactCheckResult | None = None
    validation: ValidationPayload | None = None


class SaveRequest(BaseModel):
    canvas: CanvasTreeSchema
    path: str


class SaveResponse(BaseModel):
    saved_path: str


class OpenRequest(BaseModel):
    path: str


class ImportRequest(BaseModel):
    path: str
    stack: str


class ControllersResponse(BaseModel):
    controllers: list[dict[str, Any]]

