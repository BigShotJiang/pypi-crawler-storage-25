from __future__ import annotations

from pathlib import Path


def resolve_block_path(glove_stack_dir: Path, block_file: str) -> Path:
    val = str(block_file or "").strip()
    if not val:
        raise ValueError("block file must be a non-empty string")
    rel = Path(val[7:]) if val.startswith("blocks/") else Path(val)
    blocks_root = (glove_stack_dir / "blocks").resolve()
    target = (blocks_root / rel).resolve()
    if not target.is_relative_to(blocks_root):
        raise ValueError(f"block path escapes blocks dir: {block_file}")
    return target
