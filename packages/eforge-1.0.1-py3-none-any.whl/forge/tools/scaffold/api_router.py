"""
Scaffold HTTP API stubs + Composer backend endpoints.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from forge.core.manifest_document import ManifestDocument
from forge.core.manifest_path import resolve_manifest_path
from forge.tools.scaffold.canvas_schema import CanvasNode, ControllerFieldBinding, RouteBinding, CallbackBinding, ConfigBinding
from forge.tools.scaffold.composer_schemas import (
    ControllersResponse,
    ExportFile,
    ExportRequest,
    ExportResponse,
    ImpactCheckResult,
    ImportRequest,
    OpenRequest,
    SaveRequest,
    SaveResponse,
    ValidationPayload,
    CanvasTreeSchema,
)
from forge.tools.scaffold.validation import (
    infer_domain_token_from_path,
    merge_validation_and_audit,
    validate_manifest_entry,
    validation_result_to_dict,
)
from forge.tools.scaffold.props_parser import infer_stack_from_path
from forge.tools.scaffold.template_registry import get_components_registry, list_recipes, get_recipe_by_id
from forge.tools.scaffold.importers.base import get_importer
from forge.core.manifest import ManifestParser
from forge.renderers.web.error_codes import DashboardErrorCode
from forge.renderers.web.error_response import DashboardError

logger = logging.getLogger(__name__)


def build_workshop_router() -> Any:
    """Return FastAPI APIRouter for /api/workshop/* (workshop is stubbed)."""
    router = APIRouter(prefix="/api/workshop", tags=["workshop"])
    not_impl = JSONResponse(
        status_code=501,
        content={"detail": "Not Implemented", "scope": "workshop"},
    )

    @router.post("/session/start")
    async def post_session_start():
        """Body: { project_path: str } — stub."""
        return not_impl

    @router.post("/session/swap")
    async def post_session_swap():
        """Body: { session_id, key, value, rebuild: bool } — stub."""
        return not_impl

    @router.get("/session/diff")
    async def get_session_diff():
        """Query: session_id — stub (GET has no body)."""
        return not_impl

    @router.post("/session/commit")
    async def post_session_commit():
        return not_impl

    @router.post("/session/revert")
    async def post_session_revert():
        return not_impl

    return router


composer_router = APIRouter(prefix="/api/composer", tags=["composer"])


def _project_root_from_path(p: str) -> Path:
    return Path(p).expanduser().resolve()


def _normalize_forge_json_path(base: Path) -> Path:
    # Spec says "path where to write .forge.json". Accept both:
    # - a directory path
    # - a direct file path ending in ".forge.json"
    as_str = str(base)
    if as_str.endswith(".forge.json"):
        return base
    # Treat everything else as a directory.
    return base / ".forge.json"


def _snake_case(s: str) -> str:
    out = re.sub(r"[^A-Za-z0-9]+", "_", s.strip())
    out = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", out)
    out = out.strip("_").lower()
    return out or "screen"


def _pascal_case(s: str) -> str:
    parts = re.split(r"[^A-Za-z0-9]+", s.strip())
    parts = [p for p in parts if p]
    if not parts:
        return "Screen"
    return "".join(p[:1].upper() + p[1:] for p in parts)


def _screen_class_name(name: str) -> str:
    base = _pascal_case(name)
    if not base.endswith("Screen"):
        base += "Screen"
    return base


def _flatten_nodes(root: Any) -> list[Any]:
    out: list[Any] = [root]
    for c in root.children:
        out.extend(_flatten_nodes(c))
    return out


def _component_name_to_layer(stack: str) -> dict[str, str]:
    """Map palette component `name` -> registry category (atoms | molecules | ...)."""
    grouped = get_components_registry(stack)
    idx: dict[str, str] = {}
    for layer, items in grouped.items():
        if not isinstance(items, list):
            continue
        for it in items:
            nm = it.get("name")
            if nm:
                idx[str(nm)] = str(layer)
    return idx


def _known_component_layer(component_name: str, stack: str) -> str | None:
    if not component_name:
        return None
    return _component_name_to_layer(stack).get(component_name)


def _controller_var_name(ctrl: str) -> str:
    stem = ctrl[:-10] if ctrl.endswith("Controller") else ctrl
    if not stem:
        stem = "ctrl"
    return stem[:1].lower() + stem[1:] + "Ctrl"


def _safe_react_prop_value(v: Any) -> str:
    if isinstance(v, bool):
        return "{true}" if v else "{false}"
    if isinstance(v, int | float):
        return "{" + str(v) + "}"
    return '"' + str(v).replace('"', '\\"') + '"'


def _safe_flutter_prop_value(v: Any) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int | float):
        return str(v)
    return "'" + str(v).replace("'", "\\'") + "'"


def _parse_wiring_ref(ref: Any) -> tuple[str, str, str]:
    if isinstance(ref, str):
        if "." not in ref:
            return "controller_field", ref, ""
        left, right = ref.split(".", 1)
        return "controller_field", left, right
    if isinstance(ref, ControllerFieldBinding):
        return "controller_field", ref.controller, ref.field
    if isinstance(ref, dict):
        kind = str(ref.get("kind", "controller_field"))
        if kind == "route":
            return "route", str(ref.get("route_name", "")), ""
        if kind == "callback":
            return "callback", str(ref.get("controller", "")), str(ref.get("method", ""))
        if kind == "config":
            return "config", str(ref.get("key", "")), ""
        return "controller_field", str(ref.get("controller", "")), str(ref.get("field", ""))
    return "controller_field", "", ""


def _collect_controllers_from_canvas(canvas: Any) -> list[str]:
    ctrls: set[str] = set()
    for n in _flatten_nodes(canvas.tree):
        for ref in (n.wiring or {}).values():
            kind, c, _ = _parse_wiring_ref(ref)
            if kind in ("controller_field", "callback") and c:
                ctrls.add(c)
    return sorted(ctrls)


def _render_react_node(node: Any, indent: int, controller_vars: dict[str, str], stack: str) -> str:
    layer = _known_component_layer(node.component, stack)
    pad = " " * indent
    if not layer:
        return f"{pad}{{/* SLOT: {node.component} — wire manually */}}"

    props: list[str] = []
    for k, v in (node.props or {}).items():
        props.append(f'{k}={_safe_react_prop_value(v)}')
    for k, ref in (node.wiring or {}).items():
        kind, a, b = _parse_wiring_ref(ref)
        if kind == "route" and k in ("onPress", "onTap", "onClick"):
            props.append(f"{k}={{() => navigate('/{a}')}}")
        elif kind == "callback" and k in ("onPress", "onTap", "onClick"):
            var = controller_vars.get(a, _controller_var_name(a))
            props.append(f"{k}={{() => {var}.{b}()}}")
        elif kind == "config":
            props.append(f"{k}={{config.{a}}}")
        else:
            ctrl, path = a, b
            var = controller_vars.get(ctrl, _controller_var_name(ctrl))
            if path:
                props.append(f"{k}={{{var}.{path}}}")
    props_s = (" " + " ".join(props)) if props else ""

    if not node.children:
        return f"{pad}<{node.component}{props_s} />"

    lines = [f"{pad}<{node.component}{props_s}>"]
    for c in node.children:
        lines.append(_render_react_node(c, indent + 2, controller_vars, stack))
    lines.append(f"{pad}</{node.component}>")
    return "\n".join(lines)


def _render_react_screen(canvas: Any, controllers: list[dict[str, Any]]) -> str:
    try:
        stack = str(canvas.meta.stack or "react")
        screen = _screen_class_name(canvas.meta.name)
        shell = canvas.config.shell or "AppShell"
        used_ctrls = _collect_controllers_from_canvas(canvas)
        controller_vars = {c: _controller_var_name(c) for c in used_ctrls}

        imports_by_layer: dict[str, set[str]] = {"atoms": set(), "molecules": set(), "layouts": set(), "screens": set()}
        unknown: set[str] = set()
        for n in _flatten_nodes(canvas.tree):
            layer = _known_component_layer(n.component, stack)
            if layer in imports_by_layer:
                imports_by_layer[layer].add(n.component)
            elif n.component:
                unknown.add(n.component)
        imports_by_layer["layouts"].add(shell)

        lines: list[str] = [
            "// Generated by Forge Composer",
            "// forge scaffold template output",
            "// DO NOT EDIT — edit .forge.json instead",
            "",
            "import { useEffect } from 'react'",
            "import { useNavigate } from 'react-router-dom'",
        ]

        for ctrl in used_ctrls:
            hook_name = f"use{ctrl[:-10] if ctrl.endswith('Controller') else ctrl}Controller"
            lines.append(f"import {{ {hook_name} }} from '../controllers/{ctrl}'")

        mapping = {
            "atoms": "../atoms/atoms",
            "molecules": "../molecules/molecules",
            "layouts": "../layouts/layouts",
        }
        for layer, names in imports_by_layer.items():
            if not names:
                continue
            if layer == "screens":
                for nm in sorted(names):
                    lines.append(f"import {{ {nm} }} from '../screens/{nm}'")
            else:
                lines.append(f"import {{ {', '.join(sorted(names))} }} from '{mapping[layer]}'")
        for nm in sorted(unknown):
            lines.append(f"// import {{ {nm} }} from '???'")

        lines += ["", f"export default function {screen}() {{"] 
        lines.append("  const navigate = useNavigate()")
        lines.append("  const config = {} as any")
        for ctrl in used_ctrls:
            stem = ctrl[:-10] if ctrl.endswith("Controller") else ctrl
            hook_name = f"use{stem}Controller"
            lines.append(f"  const {controller_vars[ctrl]} = {hook_name}()")

        lines += ["  return (", f"    <{shell}>"]
        if canvas.tree.component:
            lines.append(_render_react_node(canvas.tree, 6, controller_vars, stack))
        else:
            for c in canvas.tree.children:
                lines.append(_render_react_node(c, 6, controller_vars, stack))
        lines += [f"    </{shell}>", "  )", "}"]
        return "\n".join(lines) + "\n"
    except Exception as e:
        return f"// Generated by Forge Composer\n// Error during React generation: {e}\n"


def _render_flutter_node(node: Any, indent: int, controller_vars: dict[str, str], stack: str) -> str:
    layer = _known_component_layer(node.component, stack)
    pad = " " * indent
    if not layer:
        return f"{pad}// SLOT: {node.component} — wire manually\n{pad}const SizedBox.shrink(),"

    props: list[str] = []
    for k, v in (node.props or {}).items():
        props.append(f"{k}: {_safe_flutter_prop_value(v)},")
    for k, ref in (node.wiring or {}).items():
        kind, a, b = _parse_wiring_ref(ref)
        if kind == "route" and k in ("onTap", "onPress", "onClick"):
            props.append(f"{k}: () => Navigator.pushNamed(context, '/{a}'),")
        elif kind == "callback" and k in ("onTap", "onPress", "onClick"):
            var = controller_vars.get(a, _controller_var_name(a))
            props.append(f"{k}: () => {var}.{b}(),")
        elif kind == "config":
            props.append(f"{k}: AppConfig.of(context).{a},")
        else:
            ctrl, path = a, b
            var = controller_vars.get(ctrl, _controller_var_name(ctrl))
            if path:
                props.append(f"{k}: {var}.{path},")

    if not node.children:
        if props:
            return f"{pad}{node.component}(\n{pad}  " + f"\n{pad}  ".join(props) + f"\n{pad}),"
        return f"{pad}{node.component}(),"

    props.append("children: [")
    child_lines: list[str] = []
    for c in node.children:
        child_lines.append(_render_flutter_node(c, indent + 4, controller_vars, stack))
    props.extend(child_lines)
    props.append("],")
    return f"{pad}{node.component}(\n{pad}  " + f"\n{pad}  ".join(props) + f"\n{pad}),"


def _render_flutter_screen(canvas: Any, controllers: list[dict[str, Any]]) -> str:
    try:
        stack = str(canvas.meta.stack or "flutter")
        cls = _screen_class_name(canvas.meta.name)
        route = _snake_case(canvas.meta.name)
        used_ctrls = _collect_controllers_from_canvas(canvas)
        controller_vars = {c: _controller_var_name(c) for c in used_ctrls}

        lines: list[str] = [
            "// Generated by Forge Composer",
            "// forge scaffold template output",
            "// DO NOT EDIT — edit .forge.json instead",
            "",
            "import 'package:flutter/material.dart';",
            "import 'package:provider/provider.dart';",
            "import '../config/app_config.dart';",
            "import '../ui/atoms/atoms.dart';",
            "import '../ui/components/components.dart';",
            "import '../ui/layouts/layouts.dart';",
        ]
        for ctrl in used_ctrls:
            lines.append(f"import '../controllers/{ctrl}.dart';")

        lines += [
            "",
            f"class {cls} extends StatelessWidget {{",
            f"  const {cls}({{super.key}});",
            "",
            f"  static const routeName = '/{route}';",
            "",
            "  @override",
            "  Widget build(BuildContext context) {",
        ]
        for ctrl in used_ctrls:
            lines.append(f"    final {controller_vars[ctrl]} = context.watch<{ctrl}>();")

        if canvas.tree.component:
            root = _render_flutter_node(canvas.tree, 4, controller_vars, stack).rstrip(",")
        elif canvas.tree.children:
            child_lines = [_render_flutter_node(c, 8, controller_vars, stack) for c in canvas.tree.children]
            root = "    Column(\n      children: [\n" + "\n".join(child_lines) + "\n      ],\n    )"
        else:
            root = "    const SizedBox.shrink()"
        lines += [f"    return {root};", "  }", "}"]
        return "\n".join(lines) + "\n"
    except Exception as e:
        return f"// Generated by Forge Composer\n// Error during Flutter generation: {e}\n"


@composer_router.get("/components")
def composer_components(stack: str = "all") -> dict[str, Any]:
    """
    GET /api/composer/components
    Query: stack (flutter | react | all, default all)
    """
    out: dict[str, Any] = {"stacks": {}}
    wanted = {"flutter", "react"} if stack == "all" else {stack}
    for fw in wanted:
        if fw not in ("flutter", "react"):
            continue
        out["stacks"][fw] = get_components_registry(fw)
    return out


def _read_manifest(path: Path) -> dict[str, Any] | None:
    try:
        doc = ManifestDocument.from_path(path.expanduser().resolve())
        return dict(doc.to_legacy_dict())
    except (FileNotFoundError, ValueError):
        return None


def get_component_registry(stack: str) -> dict[str, dict[str, Any]]:
    grouped = get_components_registry(stack)
    out: dict[str, dict[str, Any]] = {}
    for items in grouped.values():
        if not isinstance(items, list):
            continue
        for item in items:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or "")
            if name:
                out[name] = item
    return out


def load_manifest_safe(start_path: Path) -> dict[str, Any]:
    cur = start_path.resolve()
    for parent in [cur, *cur.parents]:
        try:
            doc = ManifestDocument.from_path(parent)
            return dict(doc.to_legacy_dict())
        except (FileNotFoundError, ValueError):
            continue
    return {}


@composer_router.get("/controllers", response_model=ControllersResponse)
def composer_controllers(project_path: str) -> ControllersResponse:
    """
    GET /api/composer/controllers?project_path=<path>
    Response: { "controllers": [...] }
    """
    root = _project_root_from_path(project_path)
    data = _read_manifest(root)
    if data is None:
        logger.warning("composer: manifest.yaml not found under %s", root)
        return ControllersResponse(controllers=[])

    controllers_raw = data.get("controllers") or data.get("hooks") or []
    if not isinstance(controllers_raw, list):
        controllers_raw = []

    controllers: list[dict[str, Any]] = []
    for c in controllers_raw:
        if not isinstance(c, dict):
            continue
        name = str(c.get("name") or "")
        domain = c.get("domain") or c.get("type") or ""
        reads = c.get("reads") or []
        writes = c.get("writes") or []
        error_codes = c.get("error_codes") or c.get("errors") or []

        controllers.append(
            {
                "name": name,
                "domain": str(domain),
                "reads": list(reads) if isinstance(reads, list) else [],
                "writes": list(writes) if isinstance(writes, list) else [],
                "error_codes": list(error_codes) if isinstance(error_codes, list) else [],
            }
        )

    return ControllersResponse(controllers=controllers)


@composer_router.get("/recipes")
def composer_recipes(stack: str = "all") -> dict[str, Any]:
    recipes = list_recipes()
    if stack and stack != "all":
        recipes = [r for r in recipes if r.get("stack") in (stack, "both", "all")]
    return {"recipes": recipes}


@composer_router.get("/recipes/{recipe_id}")
def composer_recipe_by_id(recipe_id: str) -> dict[str, Any]:
    recipe = get_recipe_by_id(recipe_id)
    if recipe is None:
        raise HTTPException(status_code=404, detail="recipe not found")
    return recipe


@composer_router.get("/screens")
def composer_screens(project_path: str) -> dict[str, Any]:
    root = _project_root_from_path(project_path)
    manifest_path = resolve_manifest_path(root)
    if manifest_path is None or not manifest_path.exists():
        raise DashboardError(
            DashboardErrorCode.IMPACT_MANIFEST_MISSING,
            "manifest.yaml not found",
            detail=str(root),
            status_code=404,
        )
    parser = ManifestParser(manifest_path)
    parsed = parser.parse()
    if not parsed.ok or not isinstance(parsed.value, dict):
        return {
            "screens": [],
            "project_path": str(root),
            "manifest_valid": False,
            "warnings": [parsed.error or "manifest parse failed"],
        }
    data = parsed.value
    screens_out: list[dict[str, Any]] = []
    for s in data.get("screens") or []:
        if isinstance(s, str):
            rel = s
            name = Path(s).stem
            route = None
        elif isinstance(s, dict):
            rel = str(s.get("path") or s.get("file") or "")
            name = str(s.get("name") or Path(rel).stem)
            route = s.get("route")
        else:
            continue
        if not rel:
            continue
        abs_path = (root / rel).resolve() if not Path(rel).is_absolute() else Path(rel).resolve()
        ext = abs_path.suffix.lower()
        if ext == ".dart":
            stack = "flutter"
        elif ext in (".tsx", ".jsx"):
            stack = "react"
        else:
            stack = "unknown"
        sidecar = abs_path.with_suffix(".forge.json")
        screens_out.append(
            {
                "name": name,
                "path": str(abs_path),
                "stack": stack,
                "has_canvas": sidecar.exists(),
                "route": str(route) if route is not None else None,
            }
        )
    return {
        "screens": screens_out,
        "project_path": str(root),
        "manifest_valid": True,
        "warnings": list(data.get("warnings") or []),
    }


@composer_router.post("/export", response_model=ExportResponse)
def composer_export(req: ExportRequest) -> ExportResponse:
    """
    POST /api/composer/export
    Response: { files, warnings, impact_check:null }
    """
    canvas = req.canvas
    project_root = _project_root_from_path(req.project_path)
    if not project_root.exists():
        raise DashboardError(
            DashboardErrorCode.COMPOSER_FILE_NOT_FOUND,
            "Project path not found",
            detail=str(project_root),
            status_code=404,
        )
    stack = canvas.meta.stack
    warnings: list[str] = []
    files: list[ExportFile] = []
    controllers_resp = composer_controllers(req.project_path)
    controllers = controllers_resp.controllers

    screen_stem = _snake_case(canvas.meta.name)
    if stack == "react":
        out_path = project_root / "src" / "screens" / f"{screen_stem}.tsx"
        content = _render_react_screen(canvas, controllers)
    elif stack == "flutter":
        out_path = project_root / "lib" / "features" / screen_stem / f"{screen_stem}_screen.dart"
        content = _render_flutter_screen(canvas, controllers)
    else:
        out_path = project_root / "generated" / f"{screen_stem}.txt"
        content = f"// Unknown stack: {stack}\n"
        warnings.append(f"Unknown stack: {stack}.")

    code_exists = out_path.exists()
    files.append(ExportFile(path=str(out_path), content=content, exists=code_exists))

    forge_json_path = out_path.with_suffix(".forge.json")
    forge_json_content = json.dumps(canvas.model_dump(), indent=2)
    files.append(
        ExportFile(
            path=str(forge_json_path),
            content=forge_json_content,
            exists=forge_json_path.exists(),
        )
    )

    written_files: list[Path] = []
    if req.write_to_disk:
        for f in files:
            p = Path(f.path)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(f.content, encoding="utf-8")
            written_files.append(p)
            f.exists = True

    impact_check: ImpactCheckResult | None = None
    rel_main = str(out_path.relative_to(project_root)).replace("\\", "/")
    domain_guess = infer_domain_token_from_path(rel_main) or "CORE"
    manifest_entry: dict[str, Any] = {
        "name": canvas.meta.name,
        "file": rel_main,
        "domain": domain_guess,
        "watches": [],
    }
    v_base = validate_manifest_entry(manifest_entry, "screen", project_root)
    changed_for_audit = [str(Path(f.path).relative_to(project_root)).replace("\\", "/") for f in files]
    v_merged = merge_validation_and_audit(v_base, project_root, changed_for_audit)
    validation = ValidationPayload(**validation_result_to_dict(v_merged))

    if req.write_to_disk:
        try:
            from forge.tools.docs_audit.api_router import evaluate_impact, EvaluateRequest

            changed_files = [str(p.relative_to(project_root)) for p in written_files if p.exists()]
            audit = evaluate_impact(
                EvaluateRequest(
                    project_path=str(project_root),
                    changed_files=changed_files,
                    strict=False,
                    changed_text="",
                )
            )
            impact_check = ImpactCheckResult(
                exit_code=audit.exit_code,
                status=audit.status,
                blocker_count=audit.blocker_count,
                warn_count=audit.warn_count,
                failures=[f.model_dump() for f in audit.failures],
            )
        except Exception as e:  # pragma: no cover - non-fatal
            logger.warning("composer/export: impact check failed: %s", e)
            impact_check = None

    return ExportResponse(
        files=files,
        warnings=warnings,
        impact_check=impact_check,
        validation=validation,
    )


@composer_router.post("/save", response_model=SaveResponse)
def composer_save(req: SaveRequest) -> SaveResponse:
    """
    POST /api/composer/save
    Writes canvas JSON to .forge.json.
    """
    base = _project_root_from_path(req.path)
    out_path = _normalize_forge_json_path(base)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(req.canvas.model_dump(), indent=2, sort_keys=False), encoding="utf-8")
    return SaveResponse(saved_path=str(out_path))


@composer_router.post("/open")
def composer_open(req: OpenRequest) -> dict[str, Any]:
    """
    POST /api/composer/open
    Reads and parses .forge.json from path.
    """
    base = _project_root_from_path(req.path)
    in_path = _normalize_forge_json_path(base)
    if not in_path.exists():
        raise DashboardError(
            DashboardErrorCode.COMPOSER_FILE_NOT_FOUND,
            ".forge.json not found",
            detail=str(in_path),
            status_code=404,
        )
    try:
        payload = json.loads(in_path.read_text(encoding="utf-8"))
    except Exception as e:
        raise DashboardError(
            DashboardErrorCode.COMPOSER_FILE_MALFORMED,
            "Failed to parse .forge.json",
            detail=str(e),
            status_code=422,
        )

    parsed = CanvasTreeSchema.model_validate(payload)
    return parsed.model_dump()


@composer_router.post("/import-screen")
def composer_import_screen(req: ImportRequest) -> dict[str, Any]:
    """
    POST /api/composer/import-screen
    Best-effort: returns unknown CanvasNode if parsing fails.
    """
    path = Path(req.path).expanduser().resolve()
    if not path.exists():
        raise DashboardError(
            DashboardErrorCode.COMPOSER_FILE_NOT_FOUND,
            f"Screen file not found: {req.path}",
            detail=str(path),
            status_code=404,
        )
    stack = req.stack or infer_stack_from_path(path)
    try:
        importer = get_importer(stack)
    except ValueError:
        raise DashboardError(
            DashboardErrorCode.COMPOSER_IMPORT_FAILED,
            f"No importer available for {path}",
            status_code=422,
        )
    if not importer.can_import(str(path)):
        raise DashboardError(
            DashboardErrorCode.COMPOSER_IMPORT_FAILED,
            f"No importer available for {path}",
            status_code=422,
        )
    registry = get_component_registry(stack)
    manifest = load_manifest_safe(path.parent)
    result = importer.import_screen(str(path), registry, manifest)
    return {
        "canvas": result.canvas.to_dict(),
        "confidence": result.confidence,
        "warnings": result.warnings,
        "unknown_count": result.unknown_count,
        "total_count": result.total_count,
    }


@composer_router.get("/files")
def composer_files(project_path: str, pattern: str = "*.forge.json") -> dict[str, Any]:
    root = _project_root_from_path(project_path)
    if not root.exists() or not root.is_dir():
        return {"files": []}
    files: list[dict[str, Any]] = []
    try:
        for p in root.rglob(pattern):
            rel_depth = len(p.relative_to(root).parts)
            if rel_depth > 5 or not p.is_file():
                continue
            mtime = datetime.fromtimestamp(p.stat().st_mtime, tz=timezone.utc).isoformat()
            files.append({"path": str(p), "name": p.name, "modified": mtime})
    except Exception:
        return {"files": []}
    files.sort(key=lambda x: x["modified"], reverse=True)
    return {"files": files}

