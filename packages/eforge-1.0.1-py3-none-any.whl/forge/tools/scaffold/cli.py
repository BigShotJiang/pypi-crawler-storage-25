"""CLI stubs for forge workshop + Composer (phase 1)."""

from __future__ import annotations

import click


@click.group("workshop")
def workshop_group() -> None:
    """Workshop mode — swap UI variants in isolation (stubs). See docs/WORKSHOP.md."""


@workshop_group.command("start")
@click.option("--project", "project_path", required=True, type=click.Path())
def workshop_start(project_path: str) -> None:
    click.echo("not yet implemented")


@workshop_group.command("swap")
@click.option("--key", required=True)
@click.option("--value", required=True)
@click.option("--rebuild", is_flag=True, default=False)
def workshop_swap(key: str, value: str, rebuild: bool) -> None:
    _ = (key, value, rebuild)
    click.echo("not yet implemented")


@workshop_group.command("diff")
def workshop_diff() -> None:
    click.echo("not yet implemented")


@workshop_group.command("commit")
def workshop_commit() -> None:
    click.echo("not yet implemented")


@workshop_group.command("revert")
def workshop_revert() -> None:
    click.echo("not yet implemented")


@workshop_group.command("history")
def workshop_history() -> None:
    click.echo("not yet implemented")


@click.group("composer")
def composer_group() -> None:
    """Forge Composer — compose UI components into screens (phase-1 stubs)."""


@composer_group.command("open")
@click.argument("path", type=click.Path())
def composer_open_cmd(path: str) -> None:
    """
    Opens .forge.json and prints a short summary.
    """
    _ = path
    click.echo("not yet implemented")


@composer_group.command("export")
@click.argument("path", type=click.Path())
@click.option("--stack", required=True, type=str)
@click.option("--project", "project_path", required=True, type=click.Path())
@click.option("--write", is_flag=True, default=False)
def composer_export_cmd(path: str, stack: str, project_path: str, write: bool) -> None:
    """
    Exports canvas JSON to screen code.
    """
    _ = (path, stack, project_path, write)
    click.echo("not yet implemented")


@composer_group.command("save")
@click.argument("path", type=click.Path())
def composer_save_cmd(path: str) -> None:
    """
    Saves canvas from stdin to .forge.json.
    """
    _ = path
    click.echo("not yet implemented")


@composer_group.command("import")
@click.argument("path", type=click.Path())
@click.option("--stack", required=True, type=str)
def composer_import_cmd(path: str, stack: str) -> None:
    """
    Imports an existing screen file to canvas JSON.
    """
    _ = (path, stack)
    click.echo("not yet implemented")
