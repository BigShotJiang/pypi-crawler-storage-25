from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
import uuid


@dataclass
class ControllerFieldBinding:
    kind: str = "controller_field"
    controller: str = ""
    field: str = ""


@dataclass
class RouteBinding:
    kind: str = "route"
    route_name: str = ""
    args: dict[str, Any] = field(default_factory=dict)


@dataclass
class CallbackBinding:
    kind: str = "callback"
    controller: str = ""
    method: str = ""


@dataclass
class ConfigBinding:
    kind: str = "config"
    key: str = ""


Binding = ControllerFieldBinding | RouteBinding | CallbackBinding | ConfigBinding


@dataclass
class CanvasMeta:
    name: str
    version: str  # e.g. "v1", "v2"
    stack: str  # "flutter" | "react"
    created: str  # ISO date
    author: str  # {{AUTHOR}} placeholder
    app: str  # project name
    forge_version: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "version": self.version,
            "stack": self.stack,
            "created": self.created,
            "author": self.author,
            "app": self.app,
            "forge_version": self.forge_version,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CanvasMeta":
        return cls(
            name=str(data.get("name", "")),
            version=str(data.get("version", "")),
            stack=str(data.get("stack", "")),
            created=str(data.get("created", "")),
            author=str(data.get("author", "")),
            app=str(data.get("app", "")),
            forge_version=str(data.get("forge_version", "")),
        )


@dataclass
class CanvasNode:
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    component: str = ""
    props: dict[str, Any] = field(default_factory=dict)
    wiring: dict[str, Binding | str] = field(default_factory=dict)
    # legacy string format: "ControllerName.fieldName"
    variant: str | None = None
    children: list["CanvasNode"] = field(default_factory=list)
    slot: str | None = None
    # slot: which named slot in parent (e.g. "header")

    def to_dict(self) -> dict[str, Any]:
        wiring_out: dict[str, Any] = {}
        for k, v in (self.wiring or {}).items():
            if isinstance(v, str):
                wiring_out[k] = v
            elif isinstance(v, ControllerFieldBinding):
                wiring_out[k] = {"kind": "controller_field", "controller": v.controller, "field": v.field}
            elif isinstance(v, RouteBinding):
                wiring_out[k] = {"kind": "route", "route_name": v.route_name, "args": dict(v.args)}
            elif isinstance(v, CallbackBinding):
                wiring_out[k] = {"kind": "callback", "controller": v.controller, "method": v.method}
            elif isinstance(v, ConfigBinding):
                wiring_out[k] = {"kind": "config", "key": v.key}
        return {
            "id": self.id,
            "component": self.component,
            "props": self.props,
            "wiring": wiring_out,
            "variant": self.variant,
            "children": [c.to_dict() for c in self.children],
            "slot": self.slot,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CanvasNode":
        children_raw = data.get("children") or []
        children = [CanvasNode.from_dict(c) for c in children_raw if isinstance(c, dict)]
        raw_wiring = data.get("wiring") or {}
        parsed_wiring: dict[str, Binding | str] = {}
        if isinstance(raw_wiring, dict):
            for k, v in raw_wiring.items():
                if isinstance(v, str):
                    if "." in v:
                        c, f = v.split(".", 1)
                        parsed_wiring[str(k)] = ControllerFieldBinding(controller=c, field=f)
                    else:
                        parsed_wiring[str(k)] = v
                    continue
                if not isinstance(v, dict):
                    continue
                kind = str(v.get("kind", "controller_field"))
                if kind == "route":
                    parsed_wiring[str(k)] = RouteBinding(
                        route_name=str(v.get("route_name", "")),
                        args=dict(v.get("args") or {}),
                    )
                elif kind == "callback":
                    parsed_wiring[str(k)] = CallbackBinding(
                        controller=str(v.get("controller", "")),
                        method=str(v.get("method", "")),
                    )
                elif kind == "config":
                    parsed_wiring[str(k)] = ConfigBinding(key=str(v.get("key", "")))
                else:
                    parsed_wiring[str(k)] = ControllerFieldBinding(
                        controller=str(v.get("controller", "")),
                        field=str(v.get("field", "")),
                    )
        return cls(
            id=str(data.get("id", "")) or str(uuid.uuid4())[:8],
            component=str(data.get("component", "")),
            props=dict(data.get("props") or {}),
            wiring=parsed_wiring,
            variant=data.get("variant"),
            children=children,
            slot=data.get("slot"),
        )


@dataclass
class CanvasConfig:
    shell: str  # "AppShell" | "AuthShell" etc
    variant: str  # screen-level variant
    token_set: str  # e.g. "pulse_dark"

    def to_dict(self) -> dict[str, Any]:
        return {
            "shell": self.shell,
            "variant": self.variant,
            "token_set": self.token_set,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CanvasConfig":
        return cls(
            shell=str(data.get("shell", "")),
            variant=str(data.get("variant", "")),
            token_set=str(data.get("token_set", "")),
        )


@dataclass
class CanvasTree:
    meta: CanvasMeta
    config: CanvasConfig
    tree: CanvasNode

    def to_dict(self) -> dict[str, Any]:
        return {
            "meta": self.meta.to_dict(),
            "config": self.config.to_dict(),
            "tree": self.tree.to_dict(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CanvasTree":
        meta_raw = data.get("meta") or {}
        config_raw = data.get("config") or {}
        tree_raw = data.get("tree") or {}
        if not isinstance(meta_raw, dict) or not isinstance(config_raw, dict) or not isinstance(tree_raw, dict):
            raise ValueError("CanvasTree.from_dict expects {meta, config, tree} objects")
        return cls(
            meta=CanvasMeta.from_dict(meta_raw),
            config=CanvasConfig.from_dict(config_raw),
            tree=CanvasNode.from_dict(tree_raw),
        )


@dataclass
class RecipeDef:
    id: str
    name: str
    description: str
    stack: str
    thumbnail: str | None
    tree: CanvasNode

