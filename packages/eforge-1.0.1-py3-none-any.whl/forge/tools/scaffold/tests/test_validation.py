from __future__ import annotations

from pathlib import Path
from typing import Any, cast

import pytest

from forge.tools.scaffold.validation import (
    ValidationResult,
    compute_confidence,
    validate_manifest_entry,
)


def test_valid_controller_entry_passes() -> None:
    entry = {
        "name": "HomeController",
        "file": "lib/features/core/home_controller.dart",
        "domain": "CORE",
        "interface": {"reads": ["x"]},
        "error_codes": ["E1"],
    }
    r = validate_manifest_entry(entry, "controller", None)
    assert r.exit_code == 0
    assert not r.blockers


def test_missing_domain_is_blocker() -> None:
    r = validate_manifest_entry(
        {"name": "X", "file": "lib/features/core/x.dart"},
        "screen",
        None,
    )
    assert r.exit_code == 2
    assert any("domain" in b.lower() for b in r.blockers)


def test_invalid_domain_is_blocker() -> None:
    r = validate_manifest_entry(
        {
            "name": "X",
            "file": "lib/features/core/x.dart",
            "domain": "NOT_A_DOMAIN",
            "watches": ["a"],
        },
        "screen",
        None,
    )
    assert r.exit_code == 2
    assert any("invalid" in b.lower() or "domain" in b.lower() for b in r.blockers)


def test_missing_interface_is_warning() -> None:
    r = validate_manifest_entry(
        {
            "name": "C",
            "file": "lib/features/core/c.dart",
            "domain": "CORE",
            "error_codes": ["E1"],
        },
        "controller",
        None,
    )
    assert r.exit_code == 1
    assert any("interface" in w.lower() for w in r.warnings)


def test_missing_error_codes_is_warning() -> None:
    r = validate_manifest_entry(
        {
            "name": "C",
            "file": "lib/features/core/c.dart",
            "domain": "CORE",
            "interface": {"x": 1},
        },
        "controller",
        None,
    )
    assert r.exit_code == 1
    assert any("error_codes" in w.lower() for w in r.warnings)


def test_valid_screen_entry_passes() -> None:
    r = validate_manifest_entry(
        {
            "name": "Home",
            "file": "lib/features/lobby/home_screen.dart",
            "domain": "LOBBY",
            "watches": ["session"],
        },
        "screen",
        None,
    )
    assert r.exit_code == 0
    assert not r.blockers


def test_missing_watches_is_warning() -> None:
    r = validate_manifest_entry(
        {
            "name": "Home",
            "file": "lib/features/lobby/home_screen.dart",
            "domain": "LOBBY",
        },
        "screen",
        None,
    )
    assert r.exit_code == 1
    assert any("watches" in w.lower() for w in r.warnings)


def test_confidence_high_for_complete_entry() -> None:
    entry = {
        "name": "Home",
        "file": "lib/features/lobby/home_screen.dart",
        "domain": "LOBBY",
        "watches": ["a"],
    }
    vr = validate_manifest_entry(entry, "screen", None)
    c = compute_confidence(entry, "screen", vr)
    assert c > 0.8


def test_confidence_low_for_missing_fields() -> None:
    entry: dict[str, Any] = {"name": "", "file": "", "domain": ""}
    vr = validate_manifest_entry(entry, "screen", None)
    c = compute_confidence(entry, "screen", vr)
    assert c < 0.5


def test_validation_never_raises(tmp_path: Path) -> None:
    r = validate_manifest_entry(cast(Any, object()), "screen", tmp_path)
    assert isinstance(r, ValidationResult)
