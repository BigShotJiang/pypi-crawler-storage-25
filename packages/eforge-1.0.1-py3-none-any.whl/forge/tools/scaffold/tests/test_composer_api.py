from __future__ import annotations

import json
from pathlib import Path

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from forge.tools.scaffold.api_router import composer_router
from forge.tools.scaffold.canvas_schema import CanvasConfig, CanvasMeta, CanvasNode, CanvasTree


@pytest.fixture(autouse=True)
def _use_bundled_ui_templates(monkeypatch: pytest.MonkeyPatch) -> None:
    """Composer export resolves component layers via UI-TEMPLATES; pin bundled stubs (sibling DOCS-TEMPLATE wins otherwise)."""
    from forge.core import template_registry as tr

    bundled = Path(tr.__file__).resolve().parent / "ui_templates_bundle" / "UI-TEMPLATES"
    monkeypatch.setattr(tr, "resolve_ui_templates_root", lambda: bundled)


def _app() -> FastAPI:
    app = FastAPI()
    app.include_router(composer_router)
    return app


def _sample_canvas(stack: str = "react") -> CanvasTree:
    return CanvasTree(
        meta=CanvasMeta(
            name="MyScreen",
            version="v1",
            stack=stack,
            created="2026-01-01",
            author="{{AUTHOR}}",
            app="testapp",
            forge_version="0.0.0",
        ),
        config=CanvasConfig(shell="AppShell", variant="default", token_set="default"),
        tree=CanvasNode(
            component="Button",
            props={"label": "Hello"},
            wiring={"value": "HomeController.refresh"},
            variant=None,
            children=[
                CanvasNode(component="Input", props={"value": "1"}, wiring={}, variant=None, children=[]),
            ],
            slot="body",
        ),
    )


def _flatten_stack_components(payload: dict, stack: str) -> list[dict]:
    reg = (payload.get("stacks") or {}).get(stack) or {}
    out: list[dict] = []
    for _cat, items in reg.items():
        if isinstance(items, list):
            out.extend([x for x in items if isinstance(x, dict)])
    return out


def test_get_composer_components_returns_registry() -> None:
    client = TestClient(_app())
    resp = client.get("/api/composer/components", params={"stack": "react"})
    assert resp.status_code == 200
    data = resp.json()
    assert "stacks" in data
    assert "react" in data["stacks"]
    assert "atoms" in data["stacks"]["react"]
    assert isinstance(data["stacks"]["react"]["atoms"], list)
    assert len(data["stacks"]["react"]["atoms"]) >= 1


def test_components_endpoint_returns_flutter() -> None:
    client = TestClient(_app())
    resp = client.get("/api/composer/components", params={"stack": "flutter"})
    assert resp.status_code == 200
    flat = _flatten_stack_components(resp.json(), "flutter")
    assert len(flat) >= 5
    names = {c["name"] for c in flat}
    assert "Button" in names
    btn = next(c for c in flat if c["name"] == "Button")
    assert isinstance(btn.get("props"), list) and len(btn["props"]) >= 1


def test_components_endpoint_returns_react() -> None:
    client = TestClient(_app())
    resp = client.get("/api/composer/components", params={"stack": "react"})
    assert resp.status_code == 200
    flat = _flatten_stack_components(resp.json(), "react")
    assert len(flat) >= 5
    names = {c["name"] for c in flat}
    assert "StatCard" in names


def test_composer_palette_all_stacks_non_empty() -> None:
    client = TestClient(_app())
    resp = client.get("/api/composer/components", params={"stack": "all"})
    assert resp.status_code == 200
    data = resp.json()
    for stack in ("flutter", "react"):
        flat = _flatten_stack_components(data, stack)
        assert len(flat) > 0


def test_components_endpoint_at_least_eight_with_props() -> None:
    client = TestClient(_app())
    for stack in ("flutter", "react"):
        resp = client.get("/api/composer/components", params={"stack": stack})
        assert resp.status_code == 200
        flat = _flatten_stack_components(resp.json(), stack)
        nonempty = [c for c in flat if c.get("props")]
        assert len(nonempty) >= 8, stack
        for c in nonempty:
            assert c.get("name")
            assert isinstance(c["props"], list) and len(c["props"]) >= 1
            assert "layer" in c


def test_get_composer_controllers_reads_manifest(tmp_path: Path) -> None:
    import yaml

    (tmp_path / "manifest.yaml").write_text(
        yaml.safe_dump(
            {
                "schema_version": 1,
                "name": "composer-test",
                "type": "web",
                "stack": {"frontend": "react"},
                "version": "1.0.0",
                "screens": [],
                "services": [],
                "controllers": [
                    {
                        "name": "HomeController",
                        "domain": "CORE",
                        "reads": ["stats", "isLoading"],
                        "writes": ["refresh"],
                        "error_codes": [],
                    }
                ],
            },
            sort_keys=False,
        ),
        encoding="utf-8",
    )

    client = TestClient(_app())
    resp = client.get("/api/composer/controllers", params={"project_path": str(tmp_path)})
    assert resp.status_code == 200
    data = resp.json()
    controllers = data.get("controllers") or []
    assert len(controllers) == 1
    assert controllers[0]["name"] == "HomeController"
    assert controllers[0]["domain"] == "CORE"


def test_post_export_returns_files_list(tmp_path: Path) -> None:
    client = TestClient(_app())
    canvas = _sample_canvas(stack="react").to_dict()
    resp = client.post(
        "/api/composer/export",
        json={"canvas": canvas, "project_path": str(tmp_path), "write_to_disk": False},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert "files" in data
    assert isinstance(data["files"], list)
    assert len(data["files"]) >= 1
    assert data["impact_check"] is None
    assert data.get("validation") is not None
    assert "summary" in data["validation"]
    assert "exit_code" in data["validation"]


def test_export_includes_forge_json(tmp_path: Path) -> None:
    client = TestClient(_app())
    canvas = _sample_canvas(stack="react").to_dict()
    resp = client.post(
        "/api/composer/export",
        json={"canvas": canvas, "project_path": str(tmp_path), "write_to_disk": False},
    )
    assert resp.status_code == 200
    files = resp.json()["files"]
    assert len(files) == 2
    assert any(f["path"].endswith(".forge.json") for f in files)
    assert any(f["path"].endswith(".tsx") or f["path"].endswith(".dart") for f in files)


def test_react_export_generates_component_call(tmp_path: Path) -> None:
    client = TestClient(_app())
    canvas = _sample_canvas(stack="react").to_dict()
    resp = client.post("/api/composer/export", json={"canvas": canvas, "project_path": str(tmp_path), "write_to_disk": False})
    assert resp.status_code == 200
    code = next(f["content"] for f in resp.json()["files"] if f["path"].endswith(".tsx"))
    assert "Button" in code
    assert "Hello" in code
    assert "// SLOT" not in code


def test_flutter_export_generates_widget_call(tmp_path: Path) -> None:
    client = TestClient(_app())
    canvas = _sample_canvas(stack="flutter").to_dict()
    resp = client.post("/api/composer/export", json={"canvas": canvas, "project_path": str(tmp_path), "write_to_disk": False})
    assert resp.status_code == 200
    code = next(f["content"] for f in resp.json()["files"] if f["path"].endswith(".dart"))
    assert "Button" in code
    assert "Hello" in code


def test_export_with_wiring(tmp_path: Path) -> None:
    client = TestClient(_app())
    tree = _sample_canvas(stack="react")
    tree.tree.component = "Button"
    tree.tree.wiring = {"value": "HomeController.streakCount"}
    resp = client.post("/api/composer/export", json={"canvas": tree.to_dict(), "project_path": str(tmp_path), "write_to_disk": False})
    assert resp.status_code == 200
    code = next(f["content"] for f in resp.json()["files"] if f["path"].endswith(".tsx"))
    assert "homeCtrl" in code
    assert "streakCount" in code


def test_pydantic_validation_rejects_bad_canvas(tmp_path: Path) -> None:
    client = TestClient(_app())
    resp = client.post(
        "/api/composer/export",
        json={"canvas": {"meta": {}}, "project_path": str(tmp_path), "write_to_disk": False},
    )
    assert resp.status_code == 422


def test_save_open_round_trip(tmp_path: Path) -> None:
    client = TestClient(_app())
    canvas_tree = _sample_canvas(stack="react")
    save_payload = {"canvas": canvas_tree.to_dict(), "path": str(tmp_path)}
    save_resp = client.post("/api/composer/save", json=save_payload)
    assert save_resp.status_code == 200
    saved_path = save_resp.json()["saved_path"]
    assert saved_path.endswith(".forge.json")

    open_resp = client.post("/api/composer/open", json={"path": str(tmp_path)})
    assert open_resp.status_code == 200
    opened = open_resp.json()
    assert opened == canvas_tree.to_dict()

