from __future__ import annotations

from pathlib import Path

from forge.tools.scaffold.props_parser import (
    PropDef,
    parse_component_props,
    parse_contract_blocks_from_text,
)


def test_parses_contract_from_button_tsx() -> None:
    # Bundled stub template with CONTRACT block.
    root = Path(__file__).resolve().parents[3]
    p = (
        root / "core/ui_templates_bundle/UI-TEMPLATES/REACT/Button.tsx"
    )
    props = parse_component_props(p)
    assert props, "expected non-empty props from Button.tsx CONTRACT block"
    assert any(pp.name == "label" and pp.type == "string" and pp.required for pp in props)
    assert any(pp.name == "variant" and pp.type == "string" and not pp.required for pp in props)
    assert any(pp.name == "isLoading" and pp.type == "boolean" and not pp.required for pp in props)
    assert any(pp.name == "disabled" and pp.type == "boolean" and not pp.required for pp in props)


def test_parse_contract_block_from_dart_string() -> None:
    src = """
// CONTRACT
// - name: DemoBtn
// - layer: atom
// - props: label String, count int?, onTap VoidCallback?
// - events: onTap VoidCallback?
"""
    blocks = parse_contract_blocks_from_text(src)
    assert len(blocks) == 1
    assert blocks[0].name == "DemoBtn"
    assert blocks[0].layer == "atom"
    names = {p.name for p in blocks[0].props}
    assert names == {"label", "count", "onTap"}
    assert any(p.name == "label" and p.required for p in blocks[0].props)
    assert any(p.name == "count" and not p.required for p in blocks[0].props)
    assert blocks[0].events and blocks[0].events[0]["name"] == "onTap"


def test_no_contract_returns_empty_list(tmp_path: Path) -> None:
    f = tmp_path / "NoContract.tsx"
    f.write_text("export const x = 1;\n", encoding="utf-8")
    props = parse_component_props(f)
    assert props == []


def test_handles_flutter_and_react_files() -> None:
    root = Path(__file__).resolve().parents[3]
    flutter_p = (
        root / "core/ui_templates_bundle/UI-TEMPLATES/FLUTTER/atoms.dart"
    )
    react_p = (
        root / "core/ui_templates_bundle/UI-TEMPLATES/REACT/Button.tsx"
    )

    flutter_props = parse_component_props(flutter_p)
    react_props = parse_component_props(react_p)

    assert len(flutter_props) >= 1
    assert len(react_props) >= 1
    assert all(isinstance(pp, PropDef) for pp in flutter_props + react_props)

