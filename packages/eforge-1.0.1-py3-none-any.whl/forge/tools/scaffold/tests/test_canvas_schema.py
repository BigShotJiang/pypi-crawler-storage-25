from __future__ import annotations

from forge.tools.scaffold.canvas_schema import (
    CanvasConfig,
    CanvasMeta,
    CanvasNode,
    CanvasTree,
    ControllerFieldBinding,
)


def test_canvas_node_serializes_round_trip() -> None:
    node = CanvasNode(
        component="Button",
        props={"label": "Hello"},
        wiring={"value": ControllerFieldBinding(controller="HomeController", field="refresh")},
        variant="default",
        slot="body",
        children=[
            CanvasNode(component="Input", props={"value": "1"}, wiring={}, variant=None, slot=None),
            CanvasNode(component="Dashboard", props={}, wiring={}, variant=None, slot="header"),
        ],
    )
    payload = node.to_dict()
    restored = CanvasNode.from_dict(payload)
    assert restored.to_dict() == payload
    assert CanvasNode.from_dict(restored.to_dict()).to_dict() == payload


def test_nested_children_survive_round_trip() -> None:
    root = CanvasNode(
        component="ScreenRoot",
        children=[
            CanvasNode(
                component="Section",
                children=[CanvasNode(component="Button", props={"label": "X"})],
            )
        ],
    )
    tree = CanvasTree(
        meta=CanvasMeta(
            name="MyScreen",
            version="v1",
            stack="react",
            created="2026-01-01",
            author="{{AUTHOR}}",
            app="testapp",
            forge_version="0.0.0",
        ),
        config=CanvasConfig(shell="AppShell", variant="default", token_set="default"),
        tree=root,
    )
    payload = tree.to_dict()
    restored = CanvasTree.from_dict(payload)
    assert restored.to_dict() == payload


def test_from_dict_to_dict_idempotent() -> None:
    node = CanvasNode(component="A", props={}, wiring={}, variant=None, children=[], slot=None)
    assert CanvasNode.from_dict(node.to_dict()).to_dict() == node.to_dict()

