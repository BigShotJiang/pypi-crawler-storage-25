"""Scaffold describe= parser — canonical parse layer for forge scaffold.

Owns three things:
  load_node_schemas        — read node_schemas from manifest.yaml
  collect_manifest_domains — canonical manifest domain reader
  parse_describe           — describe= string → {kind, id, domain, watches, ...}

Dependency rule (enforced — do not violate):
  parser.py  MAY import from validation.py  (e.g. FORGE_DOMAINS)
  validation.py  must NOT import from parser.py  (no circular imports)
  scaffolder.py  must NOT import from parser.py  (receives already-parsed entry dict)
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import yaml

from forge.core.manifest import ManifestParser
from forge.core.manifest_document import ManifestDocument
from forge.core.manifest_path import resolve_manifest_path


def _node_schemas_from_yaml_mapping(raw: dict[str, Any] | None) -> list[dict]:
    if not raw:
        return []
    return [
        s for s in (raw.get("node_schemas") or [])
        if isinstance(s, dict) and "kind" in s
    ]


def _node_schemas_for_project(project_root: Path) -> list[dict]:
    """Load ``node_schemas`` for *project_root* — :class:`ManifestDocument` first, else raw YAML."""
    mp = resolve_manifest_path(project_root)
    if mp is None or not mp.is_file():
        return []
    raw: dict[str, Any] | None = None
    try:
        doc = ManifestDocument.from_path(project_root)
        raw = doc.to_legacy_dict()
    except (FileNotFoundError, ValueError):
        try:
            loaded = yaml.safe_load(mp.read_text(encoding="utf-8"))
            raw = loaded if isinstance(loaded, dict) else None
        except Exception:
            raw = None
    return _node_schemas_from_yaml_mapping(raw)


def load_node_schemas(project_path: str) -> list[dict]:
    """Read node_schemas from manifest.yaml.  Returns list of schema dicts.

    Search order:
      1. Resolved manifest for *project_path* (strict :class:`ManifestDocument` or raw YAML)
      2. Development checkout: repository ``.forge/manifest.yaml`` (``parents[3]`` from this file)

    Returns the first non-empty schemas list found, or [] when none exist.
    """
    root = Path(project_path).expanduser().resolve()
    schemas = _node_schemas_for_project(root)
    if schemas:
        return schemas

    repo_dev_manifest = Path(__file__).resolve().parents[3] / ".forge" / "manifest.yaml"
    if repo_dev_manifest.is_file():
        try:
            loaded = yaml.safe_load(repo_dev_manifest.read_text(encoding="utf-8"))
            alt = _node_schemas_from_yaml_mapping(loaded if isinstance(loaded, dict) else None)
        except Exception:
            alt = []
        if alt:
            mp = resolve_manifest_path(root)
            stack_label = "unknown"
            if mp is not None and mp.is_file():
                try:
                    raw_stack = yaml.safe_load(mp.read_text(encoding="utf-8"))
                    if isinstance(raw_stack, dict):
                        stack_label = ManifestParser.get_stack(raw_stack)
                except Exception:
                    stack_label = "unknown"
            if stack_label in ("", "unknown"):
                return []
            alt = [s for s in alt if _schema_stack_matches_project(s, stack_label)]
            if alt:
                return alt
    return []


def _schema_stack_matches_project(schema: dict, stack_label: str) -> bool:
    """True when schema ``stack`` matches *stack_label* (repo catalog must not bleed across stacks)."""
    st = schema.get("stack")
    if st is None or st == "" or st == []:
        return False
    if isinstance(st, list):
        return stack_label in {str(x) for x in st}
    return str(st) == stack_label


def collect_manifest_domains(project_path: str) -> list[str]:
    """Canonical manifest domain reader.

    Replaces two near-duplicate private functions:
      _get_manifest_domains()            in forge/mcp/handlers.py
      _collect_domains_from_manifest()   in forge/tools/scaffold/validation.py

    The key difference between the two originals was file search order:
      handlers.py   — manifest.yaml FIRST, then docs/  (correct ✓)
      validation.py — docs/manifest.yaml FIRST          (wrong  ✗)
    This implementation resolves .forge/manifest.yaml first.

    Scans the ``screens``, ``controllers``, and ``services`` sections for
    ``domain`` fields.  Returns a sorted, deduplicated list of uppercase domain
    strings, or [] when no manifest is found or no domains are registered.
    """
    root = Path(project_path).expanduser().resolve()
    try:
        doc = ManifestDocument.from_path(root)
    except (FileNotFoundError, ValueError):
        return []
    raw = doc.to_legacy_dict()
    found: set[str] = set()
    for section in ("screens", "controllers", "services"):
        for item in raw.get(section) or []:
            if isinstance(item, dict):
                d = str(item.get("domain") or "").strip().upper()
                if d:
                    found.add(d)
    return sorted(found) if found else []


def parse_describe(
    text: str,
    node_schemas: list[dict],
    extra_domains: set[str] | None = None,
) -> dict:
    """Parse a describe= string into a partial entry dict.

    Returns a dict with keys: ``kind``, plus any of ``id``, ``domain``,
    ``watches``, ``method`` that could be extracted.  The ``kind`` key holds
    the inferred entry_type — callers should pop it before merging the rest
    into an entry dict.

    Extraction rules (all case-insensitive, no external NLP):
      kind    — first schema kind keyword found in text (longest match wins)
      domain  — FORGE_DOMAINS + extra_domains tokens (longest match wins)
      id      — leading word(s) before the kind keyword, slugified
      watches — every word matching *Controller (length > len("controller"))
      method  — HTTP verb (GET/POST/PUT/PATCH/DELETE) for api-route kind

    Args:
        text:          The describe= string from the caller.
        node_schemas:  List of schema dicts (from load_node_schemas).
        extra_domains: Project-manifest domains to merge with FORGE_DOMAINS.
                       Callers can obtain this via collect_manifest_domains().
                       Passed as a set for O(1) union.

    Dependency: imports FORGE_DOMAINS from validation.py at call time.
    validation.py must NOT import from parser.py.
    """
    from forge.tools.scaffold.validation import FORGE_DOMAINS

    # Build kind-keyed lookup
    schemas: dict[str, dict[str, Any]] = {
        s["kind"]: s
        for s in node_schemas
        if isinstance(s, dict) and "kind" in s
    }

    # Merge project domains (checked first) with canonical forge set
    all_domains: set[str] = FORGE_DOMAINS | (extra_domains or set())

    low = text.lower()
    words = re.split(r"[\s,;]+", text.strip())

    # ── kind ──────────────────────────────────────────────────────────────────
    # Longest-match first prevents 'screen' matching inside 'test_screen'.
    inferred_kind = ""
    kind_pos = len(low)
    for k in sorted(schemas.keys(), key=len, reverse=True):
        pos = low.find(k)
        if pos != -1 and pos < kind_pos:
            inferred_kind = k
            kind_pos = pos

    # ── domain ────────────────────────────────────────────────────────────────
    inferred_domain = ""
    for d in sorted(all_domains, key=len, reverse=True):
        if d.lower() in low:
            inferred_domain = d
            break

    # ── id ────────────────────────────────────────────────────────────────────
    # Take meaningful tokens that appear before the kind keyword.
    # Domain name is NOT used as an id fallback — the user must supply an
    # explicit slug; otherwise id stays empty (→ missing_slot for the caller).
    _FILLER = {"a", "an", "the", "new", "my", "our", "for", "in", "of", "with", "as", "is"}
    inferred_id = ""
    if inferred_kind and kind_pos > 0:
        before = text[:kind_pos].strip()
        tokens = [w.lower() for w in re.split(r"[\s,;]+", before) if w]
        tokens = [t for t in tokens if t not in _FILLER and not t.endswith("controller")]
        if tokens:
            inferred_id = "_".join(tokens)

    # Last resort: first non-structural, non-domain, non-kind, non-controller word.
    # Only fires when nothing meaningful appeared before the kind keyword.
    if not inferred_id:
        _structural = _FILLER | {"domain", "that", "watches", "depends", "on", "using"}
        _kind_names = set(schemas.keys())
        for w in words:
            slug = re.sub(r"[^a-z0-9_]", "", w.lower())
            if (
                slug
                and slug not in _structural
                and slug != inferred_domain.lower()
                and slug not in _kind_names
                and not w.lower().endswith("controller")
            ):
                inferred_id = slug
                break

    # Slugify: lowercase, replace non-alphanumeric/underscore with underscores
    inferred_id = re.sub(r"[^a-z0-9_]", "_", inferred_id.lower()).strip("_")

    # ── watches (controllers) ──────────────────────────────────────────────────
    # Only extract compound names — reject bare "controller" / "Controller"
    controllers = [
        w for w in words
        if w.lower().endswith("controller") and len(w) > len("controller")
    ]
    normalised_controllers: list[str] = []
    for c in controllers:
        if c[0].isupper():
            normalised_controllers.append(c)
        else:
            normalised_controllers.append(c.replace("_", " ").title().replace(" ", ""))

    # ── HTTP method (for api-route kind) ──────────────────────────────────────
    _HTTP = {"GET", "POST", "PUT", "PATCH", "DELETE"}
    inferred_method = next((w.upper() for w in words if w.upper() in _HTTP), "")

    # ── Assemble result ────────────────────────────────────────────────────────
    # ``kind`` is always present (may be empty string when nothing matched).
    # Other keys are omitted when not inferrable — callers should treat absence
    # as "not derived" rather than None, to avoid clobbering explicit entry fields.
    result: dict[str, Any] = {"kind": inferred_kind}
    if inferred_id:
        result["id"] = inferred_id
    if inferred_domain:
        result["domain"] = inferred_domain
    if normalised_controllers:
        result["watches"] = normalised_controllers
    if inferred_method and inferred_kind == "api-route":
        result["method"] = inferred_method

    return result
