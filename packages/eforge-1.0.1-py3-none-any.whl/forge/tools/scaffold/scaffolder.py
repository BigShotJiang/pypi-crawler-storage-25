"""
Workshop session model and lifecycle stubs.

Full implementation deferred; see docs/WORKSHOP.md.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import yaml

from forge.core.manifest_sidecar import SidecarLoader, ValidationError as SidecarValidationError
from forge.core.manifest_path import resolve_manifest_path
from forge.core.manifest import ManifestParser
from forge.core.stack_profiles import get_stack_profile
from forge.tools.scaffold.blocks import resolve_block_path
from forge.tools.scaffold.template_expressions import eval_safe_expr, interpolate_fields
from forge.core.event_log import auto_append, EventSeverity


class ScaffoldError(Exception):
    """Raised when scaffold execution would mutate an incompatible project stack."""


_INPUT_TYPES = {"str", "bool", "enum", "int", "list"}


@dataclass
class WorkshopSession:
    """Tracks app_config.yaml ui_lab.active_variants during a workshop run."""

    app_path: Path
    baseline: dict[str, Any]  # snapshot of app_config.yaml ui_lab.active_variants at start
    current: dict[str, Any]  # current active_variants state
    history: list[Any] = field(default_factory=list)  # (timestamp, key, old, new)
    active: bool = False  # is a session in progress
    canvas_path: str | None = None
    # When set, swap_variant updates the canvas JSON file too.


def start_session(app_path: Path) -> WorkshopSession:
    """Begin workshop session; snapshot baseline active_variants (stub)."""
    raise NotImplementedError("workshop: start_session")


def swap_variant(
    session: WorkshopSession,
    key: str,
    value: Any,
    canvas_path: str | None = None,
) -> WorkshopSession:
    """Apply one variant swap; append to history (stub)."""
    raise NotImplementedError("workshop: swap_variant")


def diff_session(session: WorkshopSession) -> dict[str, Any]:
    """Diff baseline vs current active_variants (stub)."""
    raise NotImplementedError("workshop: diff_session")


def commit_session(session: WorkshopSession) -> None:
    """Write final state to app_config (stub)."""
    raise NotImplementedError("workshop: commit_session")


def revert_session(session: WorkshopSession) -> None:
    """Restore baseline snapshot (stub)."""
    raise NotImplementedError("workshop: revert_session")


def _fill_slots(template_str: str, entry: dict[str, Any]) -> str:
    """Replace {slot} tokens in a template string from entry fields."""
    id_val = str(entry.get("id") or entry.get("name") or "")
    domain = str(entry.get("domain") or "")
    pascal = id_val.replace("_", " ").title().replace(" ", "")
    out = (
        template_str
        .replace("{id}", id_val)
        .replace("{domain}", domain)
        .replace("{domain_lower}", domain.lower())
        .replace("{PascalId}", pascal)
        .replace("{package}", str(entry.get("package") or "app"))
    )
    # Generic token replacement for schema-defined fields (e.g. {path}, {stack}).
    for k, v in entry.items():
        out = out.replace(f"{{{k}}}", str(v))
    return out


def parse_template_inputs(raw_inputs: list[str] | None) -> dict[str, str]:
    out: dict[str, str] = {}
    for raw in raw_inputs or []:
        item = str(raw or "").strip()
        if not item:
            continue
        if "=" not in item:
            raise ScaffoldError(f"invalid --input value {item!r}; expected name=value")
        k, v = item.split("=", 1)
        key = k.strip()
        if not key:
            raise ScaffoldError(f"invalid --input value {item!r}; missing input name")
        out[key] = v
    return out


def collect_template_inputs(
    template: dict[str, Any],
    *,
    cli_inputs: dict[str, str] | None = None,
    interactive: bool = False,
) -> dict[str, Any]:
    raw_defs = template.get("inputs") or {}
    if not isinstance(raw_defs, dict):
        return {}
    values: dict[str, Any] = {}
    cli = dict(cli_inputs or {})
    allowed = set(raw_defs.keys())
    for name, spec in raw_defs.items():
        if not isinstance(spec, dict):
            raise ScaffoldError(f"inputs.{name} must be an object")
        cond = spec.get("condition")
        if isinstance(cond, str) and cond.strip():
            if not eval_safe_expr(cond, values, allowed):
                continue
        type_name = str(spec.get("type") or "")
        if type_name not in _INPUT_TYPES:
            raise ScaffoldError(f"unsupported input type for {name}: {type_name!r}")
        required = bool(spec.get("required"))
        default = spec.get("default")
        raw_value: Any = None
        has_raw = False
        if name in cli:
            raw_value = cli[name]
            has_raw = True
        elif interactive:
            import click

            prompt_text = str(spec.get("description") or name)
            maybe_default = default if "default" in spec else None
            raw_value = click.prompt(prompt_text, default=maybe_default, show_default="default" in spec)
            has_raw = True
        elif "default" in spec:
            raw_value = default
            has_raw = True
        if not has_raw:
            if required:
                raise ScaffoldError(f"missing required template input: {name}")
            continue
        values[name] = _coerce_input_value(name, spec, raw_value)
    return values


def apply_template_conditionals(
    template: dict[str, Any],
    *,
    input_values: dict[str, Any],
    glove_stack_dir: Path | None = None,
) -> tuple[list[str], list[dict[str, str]]]:
    produces_raw = template.get("produces") or []
    produces = [interpolate_fields(str(x), input_values) for x in produces_raw if isinstance(x, str)]
    out_injections: list[dict[str, str]] = []
    rows = template.get("conditionals") or []
    if not isinstance(rows, list):
        return produces, out_injections
    allowed = set((template.get("inputs") or {}).keys())
    for row in rows:
        if not isinstance(row, dict):
            continue
        when = str(row.get("when") or "").strip()
        if not when:
            continue
        if not eval_safe_expr(when, input_values, allowed):
            continue
        inject = row.get("inject") or {}
        if isinstance(inject, dict):
            block_file = str(inject.get("file") or "").strip()
            target_tpl = str(inject.get("target") or "").strip()
            if block_file and target_tpl:
                target = interpolate_fields(target_tpl, input_values)
                block_path = (
                    str(resolve_block_path(glove_stack_dir, block_file))
                    if glove_stack_dir is not None
                    else block_file
                )
                out_injections.append({"file": block_path, "target": target})
        po = row.get("produces_override")
        if isinstance(po, list) and po:
            resolved = [interpolate_fields(str(x), input_values) for x in po if isinstance(x, str)]
            for new_path in resolved:
                idx = _find_matching_produces_index(produces, new_path)
                if idx >= 0:
                    produces[idx] = new_path
                else:
                    produces.append(new_path)
    return produces, out_injections


def render_template_wiring(template: dict[str, Any], *, input_values: dict[str, Any]) -> list[dict[str, str]]:
    rows = template.get("wiring") or []
    if not isinstance(rows, list):
        return []
    allowed = set((template.get("inputs") or {}).keys())
    out: list[dict[str, str]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        when = row.get("when")
        if isinstance(when, str) and when.strip():
            if not eval_safe_expr(when, input_values, allowed):
                continue
        kind = str(row.get("kind") or "").strip()
        target = str(row.get("target") or "").strip()
        value = str(row.get("value") or "").strip()
        if not kind or not target or not value:
            continue
        out.append(
            {
                "kind": kind,
                "target": interpolate_fields(target, input_values),
                "value": interpolate_fields(value, input_values),
            }
        )
    return out


def instantiate_glove_template(
    *,
    template: dict[str, Any],
    template_path: Path,
    project_path: Path,
    cli_inputs: dict[str, str] | None = None,
    interactive: bool = True,
) -> dict[str, Any]:
    """Instantiate a glove template directly into project_path."""
    root = project_path.expanduser().resolve()
    template_file = template_path.expanduser().resolve()
    glove_stack_dir = template_file.parents[2]
    _assert_template_stack_compatible(root, template)

    inputs = collect_template_inputs(template, cli_inputs=cli_inputs or {}, interactive=interactive)
    produces, injections = apply_template_conditionals(
        template, input_values=inputs, glove_stack_dir=glove_stack_dir
    )
    wiring = render_template_wiring(template, input_values=inputs)

    writes: dict[str, str] = {}
    for rel in produces:
        if not rel:
            continue
        target = (root / rel).resolve()
        if not target.is_relative_to(root):
            raise ScaffoldError(f"refusing to write outside project_path: {rel}")
        target.parent.mkdir(parents=True, exist_ok=True)
        if str(target) not in writes:
            writes[str(target)] = ""

    for inj in injections:
        block_path = Path(str(inj.get("file") or "")).expanduser().resolve()
        target_rel = str(inj.get("target") or "").strip()
        if not target_rel:
            continue
        if not block_path.is_file():
            raise ScaffoldError(f"block file not found: {block_path}")
        content = block_path.read_text(encoding="utf-8")
        rendered = interpolate_fields(content, inputs)
        target = (root / target_rel).resolve()
        if not target.is_relative_to(root):
            raise ScaffoldError(f"refusing to write outside project_path: {target_rel}")
        target.parent.mkdir(parents=True, exist_ok=True)
        existing = writes.get(str(target), "")
        writes[str(target)] = f"{existing}\n{rendered}".lstrip("\n") if existing else rendered

    written_rel: list[str] = []
    for abs_path, content in writes.items():
        p = Path(abs_path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        written_rel.append(str(p.relative_to(root)))

    operations_raw = template.get("operations")
    if operations_raw is not None:
        if not isinstance(operations_raw, list):
            raise ScaffoldError("template.operations must be a list when present")
        rendered_operations = _interpolate_template_value(operations_raw, inputs)
        if not isinstance(rendered_operations, list):
            raise ScaffoldError("template.operations rendered value must be a list")
        for i, row in enumerate(rendered_operations):
            if not isinstance(row, dict):
                raise ScaffoldError(f"template.operations[{i}] must render to an object")
        manifest_path = _sidecar_manifest_path_for_project(root)
        try:
            existing = SidecarLoader.load(manifest_path, "operations") or {}
        except SidecarValidationError as exc:
            raise ScaffoldError(f"invalid existing operations sidecar: {exc}") from exc
        existing_rows = existing.get("operations") if isinstance(existing, dict) else []
        if existing_rows is None:
            existing_rows = []
        if not isinstance(existing_rows, list):
            raise ScaffoldError("existing operations sidecar has non-list operations")
        merged = _merge_operations_by_id(existing_rows, rendered_operations)
        payload = {
            "schema_version": int(existing.get("schema_version", 1))
            if isinstance(existing, dict)
            else 1,
            "operations": merged,
        }
        try:
            SidecarLoader.write(manifest_path, "operations", payload)
        except SidecarValidationError as exc:
            raise ScaffoldError(f"operations sidecar validation failed: {exc}") from exc
        sidecar_rel = str(SidecarLoader.sidecar_path(manifest_path, "operations").relative_to(root))
        if sidecar_rel not in written_rel:
            written_rel.append(sidecar_rel)

    return {
        "status": "ok",
        "template_id": str(template.get("id") or ""),
        "inputs": inputs,
        "written": sorted(written_rel),
        "wiring": wiring,
    }


def _assert_template_stack_compatible(project_root: Path, template: dict[str, Any]) -> None:
    """Reject scaffold-express writes when template stack mismatches target project stack."""
    manifest_path = resolve_manifest_path(project_root)
    if manifest_path is None or not manifest_path.is_file():
        # Empty scaffold targets are valid; no stack contract exists yet.
        return

    manifest_data = _load_manifest_for_scaffold(project_root)
    project_stack = ManifestParser.get_stack(manifest_data)
    profile = get_stack_profile(project_stack)
    template_stack = str(template.get("stack") or "").strip().lower()
    if not template_stack:
        return

    allowed = {
        str(project_stack).strip().lower(),
        str(profile.template_segment).strip().lower(),
    }
    if template_stack in allowed:
        return

    raise ScaffoldError(
        f"template stack '{template_stack}' is not valid for project stack '{project_stack}' "
        f"(allowed: {sorted(x for x in allowed if x)})."
    )


def _sidecar_manifest_path_for_project(project_root: Path) -> Path:
    found = resolve_manifest_path(project_root)
    if found is not None:
        return found
    # Fallback for scaffold-express in empty targets: keep sidecar at project root.
    return project_root / "manifest.yaml"


def _interpolate_template_value(value: Any, inputs: dict[str, Any]) -> Any:
    if isinstance(value, str):
        return interpolate_fields(value, inputs)
    if isinstance(value, list):
        return [_interpolate_template_value(v, inputs) for v in value]
    if isinstance(value, dict):
        return {str(k): _interpolate_template_value(v, inputs) for k, v in value.items()}
    return value


def _merge_operations_by_id(existing: list[dict[str, Any]], incoming: list[dict[str, Any]]) -> list[dict[str, Any]]:
    merged: list[dict[str, Any]] = []
    by_id: dict[str, dict[str, Any]] = {}

    for row in existing:
        if not isinstance(row, dict):
            raise ScaffoldError("existing operations sidecar contains non-object entries")
        op_id = str(row.get("id") or "").strip()
        if not op_id:
            raise ScaffoldError("existing operations sidecar contains operation without id")
        if op_id in by_id:
            raise ScaffoldError(f"existing operations sidecar contains duplicate id '{op_id}'")
        by_id[op_id] = row
        merged.append(row)

    for row in incoming:
        op_id = str(row.get("id") or "").strip()
        if not op_id:
            raise ScaffoldError("template operation is missing id")
        current = by_id.get(op_id)
        if current is None:
            by_id[op_id] = row
            merged.append(row)
            continue
        if current != row:
            raise ScaffoldError(
                f"operation id collision for '{op_id}': existing definition differs from template"
            )
    return merged


def _coerce_input_value(name: str, spec: dict[str, Any], value: Any) -> Any:
    t = str(spec.get("type") or "")
    if t == "str":
        return str(value)
    if t == "bool":
        if isinstance(value, bool):
            return value
        val = str(value).strip().lower()
        if val in {"1", "true", "yes", "y", "on"}:
            return True
        if val in {"0", "false", "no", "n", "off"}:
            return False
        raise ScaffoldError(f"invalid bool for input {name}: {value!r}")
    if t == "int":
        try:
            return int(value)
        except (TypeError, ValueError) as exc:
            raise ScaffoldError(f"invalid int for input {name}: {value!r}") from exc
    if t == "enum":
        values = spec.get("values") or []
        if not isinstance(values, list) or not all(isinstance(v, str) for v in values):
            raise ScaffoldError(f"invalid enum values for input {name}")
        sval = str(value)
        if sval not in values:
            raise ScaffoldError(f"invalid enum for input {name}: {sval!r}, expected one of {values}")
        return sval
    if t == "list":
        if isinstance(value, list):
            return [str(x) for x in value]
        val = str(value).strip()
        if not val:
            return []
        return [p.strip() for p in val.split(",") if p.strip()]
    raise ScaffoldError(f"unsupported input type for {name}: {t!r}")


def _find_matching_produces_index(produces: list[str], new_path: str) -> int:
    new_name = Path(new_path).name
    new_stem = Path(new_name).stem
    for idx, cur in enumerate(produces):
        cpath = Path(cur)
        if cpath.parent == Path(new_path).parent and cpath.stem == new_stem:
            return idx
        if cpath.name == new_name:
            return idx
    return -1


def _update_manifest(
    entry: dict[str, Any],
    entry_type: str,
    project_path: Path,
) -> bool:
    """Append the new node to the correct section in manifest.yaml. Returns True on success."""
    from forge.core.manifest import ManifestParser
    from forge.core.manifest_document import ManifestDocument

    _SECTION_MAP = {
        "screen": "screens",
        "controller": "controllers",
        "service": "services",
        "model": "models",
        "variant": "variants",
        "page": "pages",
        "component": "components",
        "hook": "hooks",
        "command": "commands",
        "module": "modules",
        "doc": "modules",
        "test": "modules",
        "glove": "modules",
        "error_codes": "modules",
    }
    section = _SECTION_MAP.get(entry_type)
    if not section:
        return False  # unknown kind — don't touch manifest

    candidate = resolve_manifest_path(project_path)
    if candidate is not None and candidate.is_file():
        try:
            doc = ManifestDocument.from_path(project_path.expanduser().resolve())
            manifest = doc.to_legacy_dict()
            project_stack = doc.stack
        except (FileNotFoundError, ValueError):
            manifest = {}
            project_stack = "unknown"
        if project_stack == "flutter-app":
            project_stack = "dart"
        elif project_stack == "python-cli":
            project_stack = "python"

        DART_SECTIONS = {"screens", "watches", "routes", "widgets"}
        PYTHON_SECTIONS = {"modules", "commands", "tools", "gloves"}

        if section in DART_SECTIONS and project_stack != "dart":
            raise ScaffoldError(
                f"Cannot write '{section}' entry to {project_stack} project — stack mismatch. "
                f"Check project_path is correct."
            )
        if section in PYTHON_SECTIONS and project_stack == "dart":
            raise ScaffoldError(
                f"Cannot write '{section}' entry to dart project — stack mismatch. "
                f"Check project_path is correct."
            )
        return ManifestParser(candidate).append_node(section, entry).ok
    return False


def _slug(s: str) -> str:
    return str(s).strip().lower().replace(" ", "-").replace("_", "-").replace("/", "-")


def _ensure_scaffold_id(entry: dict[str, Any], entry_type: str) -> dict[str, Any]:
    if entry.get("id"):
        return dict(entry)
    name = str(entry.get("name") or "").strip()
    if not name:
        return dict(entry)
    ts = datetime.now(timezone.utc).isoformat()
    seed = f"{entry_type}:{name}:{ts}"
    short_hash = hashlib.sha256(seed.encode("utf-8")).hexdigest()[:6]
    out = dict(entry)
    out["id"] = f"{entry_type}-{_slug(name)}-{short_hash}"
    return out


def _load_manifest_for_scaffold(project_path: Path) -> dict[str, Any]:
    from forge.core.manifest_document import ManifestDocument

    try:
        doc = ManifestDocument.from_path(project_path.expanduser().resolve())
        return dict(doc.to_legacy_dict())
    except (FileNotFoundError, ValueError):
        return {}


def _load_domain_template(domain: str) -> list[dict[str, str]]:
    p = Path("~/.forge/registries/local/domains").expanduser() / f"{domain.lower()}.yaml"
    if not p.is_file():
        return []
    try:
        raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except Exception:
        return []
    rows = raw.get("codes") if isinstance(raw, dict) else []
    out: list[dict[str, str]] = []
    if isinstance(rows, list):
        for row in rows:
            if not isinstance(row, dict):
                continue
            code = str(row.get("code") or "").strip()
            msg = str(row.get("message") or "").strip()
            if code and msg:
                out.append({"code": code, "message": msg})
    return out


def _project_stack(manifest_data: dict[str, Any]) -> str:
    t = str(manifest_data.get("type") or "").strip().lower()
    if t in {"flutter", "flutter-app"}:
        return "flutter-app"
    if t in {"python", "python-cli"}:
        return "python-cli"
    if t in {"web", "react", "web-react", "web-next"}:
        return "web-react"
    return "python-cli"


def _error_codes_settings(manifest_data: dict[str, Any], project_path: Path, entry: dict[str, Any]) -> dict[str, Any]:
    cfg = manifest_data.get("error_codes")
    cfg_d = dict(cfg) if isinstance(cfg, dict) else {}
    domains = entry.get("domains")
    if not isinstance(domains, list) or not domains:
        domains = cfg_d.get("domains")
    if not isinstance(domains, list) or not domains:
        domains = manifest_data.get("domains")
    if not isinstance(domains, list) or not domains:
        domains = ["CORE"]
    domains = [str(d).strip().upper() for d in domains if str(d).strip()]
    stack = _project_stack(manifest_data)
    storage_default = {
        "flutter-app": "lib/constants/error_codes.dart",
        "python-cli": "forge/constants/error_codes.py",
        "web-react": "src/constants/error_codes.ts",
    }[stack]
    storage = str(entry.get("storage") or cfg_d.get("storage") or storage_default)
    fmt = str(cfg_d.get("format") or "[DOMAIN-NNN] message")
    return {"domains": domains, "storage": storage, "format": fmt, "stack": stack}


def _render_error_codes_source(stack: str, domains: list[str]) -> str:
    rows: list[dict[str, str]] = []
    for domain in domains:
        templ = _load_domain_template(domain)
        if templ:
            rows.extend(templ)
        else:
            for i in range(1, 4):
                rows.append({"code": f"{domain}-{i:03d}", "message": f"{domain} message {i}"})

    if stack == "flutter-app":
        entries = ",\n".join([f"  '{r['code']}': '{r['message']}'" for r in rows])
        return (
            "// GENERATED FILE — do not edit manually.\n"
            "// Regenerate with: forge scaffold --entry-type error_codes --refresh error_codes\n\n"
            "const Map<String, String> ERROR_CODES = {\n"
            f"{entries}\n"
            "};\n"
        )
    if stack == "web-react":
        entries = ",\n".join([f"  '{r['code']}': '{r['message']}'" for r in rows])
        return (
            "// GENERATED FILE — do not edit manually.\n"
            "// Regenerate with: forge scaffold --entry-type error_codes --refresh error_codes\n\n"
            "export const ERROR_CODES: Record<string, string> = {\n"
            f"{entries}\n"
            "};\n"
        )
    return (
        "# GENERATED FILE — do not edit manually.\n"
        "# Regenerate with: forge scaffold --entry-type error_codes --refresh error_codes\n\n"
        f"ERROR_CODES = {json.dumps({r['code']: r['message'] for r in rows}, indent=2)}\n"
    )


def _execute_error_codes(entry: dict[str, Any], project_path: Path, dry_run: bool) -> dict[str, Any]:
    manifest_data = _load_manifest_for_scaffold(project_path)
    settings = _error_codes_settings(manifest_data, project_path, entry)
    rendered = _render_error_codes_source(settings["stack"], settings["domains"])
    out_path = settings["storage"]
    node_entry = {
        "id": entry.get("id") or _ensure_scaffold_id({"name": "error_codes"}, "error_codes")["id"],
        "name": str(entry.get("name") or "error_codes"),
        "path": out_path,
        "role": "Generated error code storage file",
        "domains": settings["domains"],
        "format": settings["format"],
        "storage": out_path,
        "kind": "error_codes",
    }
    if dry_run:
        return {
            "status": "dry_run",
            "would_write": [out_path],
            "filled_body_preview": rendered[:800],
            "manifest_updated": False,
        }
    file_path = project_path / out_path
    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(rendered, encoding="utf-8")
    manifest_updated = _update_manifest(node_entry, "error_codes", project_path)
    return {"status": "ok", "written": [out_path], "manifest_updated": manifest_updated}


@auto_append(operation="forge_scaffold", action="generate", data_key="result")
def execute(
    entry: dict[str, Any],
    project_path: Path,
    entry_type: str,
    schema: dict[str, Any],
    *,
    dry_run: bool = False,
) -> dict[str, Any]:
    """
    Execution engine: validated entry → template resolved → file written → manifest updated.

    Ownership: execution entry for programmatic scaffold runs (validation must pass first).
    MCP uses ``forge scaffold pipeline`` via ``handle_forge_scaffold_thin`` instead of this path.

    Steps:
      1. Resolve code template via tools.scaffold.template_registry
      2. Fill {slot} tokens from validated entry dict
      3. Determine output path (template.output_path or entry["file"])
      4. dry_run=True → return preview without writing
      5. Write file to project_path / output_path
      6. Append node to manifest.yaml under correct section
      7. Return {status, written, manifest_updated}
    """
    from forge.tools.scaffold.template_registry import resolve_scaffold_template

    stack = str(schema.get("stack") or "")
    entry = _ensure_scaffold_id(entry, entry_type)

    if entry_type == "error_codes":
        return _execute_error_codes(entry, project_path, dry_run)

    # 1. Resolve template
    try:
        template = resolve_scaffold_template(entry_type, stack=stack or None, project_root=project_path)
    except FileNotFoundError as e:
        no_file_needed = bool(schema.get("no_file_needed"))
        if no_file_needed:
            if dry_run:
                return {
                    "status": "dry_run_manifest_only",
                    "would_write": [],
                    "manifest_updated": False,
                }
            manifest_updated = _update_manifest(entry, entry_type, project_path)
            return {
                "status": "manifest_only",
                "written": [],
                "manifest_updated": manifest_updated,
            }
        return {
            "status": "no_template",
            "written": [],
            "manifest_updated": False,
            "hint": str(e),
        }

    # 2. Fill slots
    body_raw = str(template.get("body") or "")
    output_path_tpl = str(template.get("output_path") or entry.get("file") or entry.get("path") or "")

    filled_body = _fill_slots(body_raw, entry)
    output_path = _fill_slots(output_path_tpl, entry) if output_path_tpl else str(entry.get("file") or entry.get("path") or "")

    if not output_path:
        return {
            "status": "no_output_path",
            "written": [],
            "manifest_updated": False,
            "hint": "entry or template must provide output_path or file field",
        }

    # 3. Dry-run: return slot-filling preview without writing
    if dry_run:
        return {
            "status": "dry_run",
            "would_write": [output_path],
            "filled_body_preview": filled_body[:800],
            "manifest_updated": False,
        }

    # 4. Write file
    file_path = project_path / output_path
    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(filled_body, encoding="utf-8")

    # 5. Append node to manifest.yaml
    manifest_updated = _update_manifest(entry, entry_type, project_path)

    return {
        "status": "ok",
        "written": [output_path],
        "manifest_updated": manifest_updated,
    }
