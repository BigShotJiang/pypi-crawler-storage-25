from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class PropDef:
    name: str
    type: str  # "string" | "bool" | "int" | "ReactNode" | etc
    required: bool  # true if no ? suffix
    default: str | None

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "type": self.type,
            "required": self.required,
            "default": self.default,
        }


@dataclass
class ComponentContractInfo:
    component_name: str
    states: list[str]
    stack: str  # "flutter" | "react"
    props: list[PropDef]


CONTRACT_HEADER_RE = re.compile(r"^\s*//\s*CONTRACT\s*$")
STATE_LINE_RE = re.compile(r"^-\s*states\s*:\s*(.*)$", re.IGNORECASE | re.MULTILINE)
PROPS_LINE_RE = re.compile(r"^-\s*props\s*:\s*(.*)$", re.IGNORECASE | re.MULTILINE)
NAME_LINE_RE = re.compile(r"^-\s*name\s*:\s*(.+)$", re.IGNORECASE | re.MULTILINE)
LAYER_LINE_RE = re.compile(r"^-\s*layer\s*:\s*(\S+)$", re.IGNORECASE | re.MULTILINE)
EVENTS_LINE_RE = re.compile(r"^-\s*events\s*:\s*(.*)$", re.IGNORECASE | re.MULTILINE)
SLOTS_LINE_RE = re.compile(r"^-\s*slots\s*:\s*(.*)$", re.IGNORECASE | re.MULTILINE)


def _split_comma_outside_generics(raw: str) -> list[str]:
    """Split on commas not inside <...>."""
    parts: list[str] = []
    depth = 0
    start = 0
    for i, ch in enumerate(raw):
        if ch == "<":
            depth += 1
        elif ch == ">":
            depth = max(0, depth - 1)
        elif ch == "," and depth == 0:
            parts.append(raw[start:i].strip())
            start = i + 1
    parts.append(raw[start:].strip())
    return [p for p in parts if p]


def _extract_contract_block_lines_from(lines: list[str], start_idx: int) -> tuple[list[str], int]:
    """
    After a CONTRACT header at start_idx-1, consume //-comment list lines until blank or break.
    Returns (payload lines without // prefix, index of line after the block).
    """
    out: list[str] = []
    j = start_idx
    max_j = min(len(lines), start_idx + 120)
    while j < max_j:
        line = lines[j]
        if not line.strip():
            return out, j + 1
        m = re.match(r"^\s*//\s?(.*)$", line)
        if not m:
            return out, j
        payload = m.group(1).strip()
        if not payload.startswith("-"):
            return out, j
        out.append(payload)
        j += 1
    return out, j


def extract_all_contract_block_lines(file_text: str) -> list[list[str]]:
    """All CONTRACT blocks in the file (scan entire file)."""
    lines = file_text.splitlines()
    blocks: list[list[str]] = []
    i = 0
    n = len(lines)
    while i < n:
        if CONTRACT_HEADER_RE.match(lines[i]):
            block, next_i = _extract_contract_block_lines_from(lines, i + 1)
            if block:
                blocks.append(block)
            i = next_i if next_i > i + 1 else i + 1
        else:
            i += 1
    return blocks


def _extract_first_contract_block_lines(file_text: str) -> list[str]:
    """Legacy: first CONTRACT in the first ~80 lines only."""
    lines = file_text.splitlines()
    start = None
    for i, line in enumerate(lines[:80]):
        if CONTRACT_HEADER_RE.match(line):
            start = i + 1
            break
    if start is None:
        return []
    block, _ = _extract_contract_block_lines_from(lines, start)
    return block


def _parse_states(contract_lines: list[str]) -> list[str]:
    joined = "\n".join(contract_lines)
    m = STATE_LINE_RE.search(joined)
    if not m:
        return []
    raw = m.group(1).strip()
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    return parts


def _parse_name(contract_lines: list[str]) -> str | None:
    joined = "\n".join(contract_lines)
    m = NAME_LINE_RE.search(joined)
    if not m:
        return None
    return m.group(1).strip()


def _parse_layer(contract_lines: list[str]) -> str | None:
    joined = "\n".join(contract_lines)
    m = LAYER_LINE_RE.search(joined)
    if not m:
        return None
    return m.group(1).strip()


def _parse_line_value(contract_lines: list[str], pattern: re.Pattern[str]) -> str | None:
    joined = "\n".join(contract_lines)
    m = pattern.search(joined)
    if not m:
        return None
    return m.group(1).strip()


def _split_type_and_default(rem: str) -> tuple[str, str | None]:
    """Split `Type` or `Type=default` at first '=' outside <>."""
    depth = 0
    for i, ch in enumerate(rem):
        if ch == "<":
            depth += 1
        elif ch == ">":
            depth = max(0, depth - 1)
        elif ch == "=" and depth == 0:
            return rem[:i].strip(), rem[i + 1 :].strip().strip('"').strip("'")
    return rem.strip(), None


def _parse_typed_entries(raw: str) -> list[PropDef]:
    if not raw:
        return []
    entries = _split_comma_outside_generics(raw)
    props: list[PropDef] = []
    for ent in entries:
        ent = ent.strip()
        if not ent:
            continue
        parts = ent.split(None, 1)
        if len(parts) < 2:
            continue
        name, rem = parts[0], parts[1].strip()
        required = True
        if rem.endswith("?"):
            required = False
            rem = rem[:-1].rstrip()
        type_token, default = _split_type_and_default(rem)
        if not type_token:
            continue
        props.append(
            PropDef(
                name=name,
                type=type_token,
                required=required,
                default=default,
            )
        )
    return props


def _parse_props(contract_lines: list[str]) -> list[PropDef]:
    raw = _parse_line_value(contract_lines, PROPS_LINE_RE)
    if raw is None:
        return []
    return _parse_typed_entries(raw)


def _parse_events(contract_lines: list[str]) -> list[dict[str, str]]:
    raw = _parse_line_value(contract_lines, EVENTS_LINE_RE)
    if not raw or raw == "[]":
        return []
    entries = _split_comma_outside_generics(raw)
    out: list[dict[str, str]] = []
    for ent in entries:
        ent = ent.strip()
        if not ent:
            continue
        parts = ent.split(None, 1)
        if len(parts) == 1:
            out.append({"name": parts[0], "type": "callback"})
        else:
            etype = parts[1].removesuffix("?").strip() or "callback"
            out.append({"name": parts[0], "type": etype})
    return out


def _parse_slots(contract_lines: list[str]) -> list[str]:
    raw = _parse_line_value(contract_lines, SLOTS_LINE_RE)
    if raw is None:
        return []
    raw = raw.strip()
    if raw == "[]" or raw == "":
        return []
    raw = raw.strip("[]")
    return [p.strip() for p in _split_comma_outside_generics(raw) if p.strip()]


@dataclass
class ParsedContractBlock:
    name: str | None
    layer: str | None
    states: list[str]
    props: list[PropDef]
    events: list[dict[str, str]]
    slots: list[str]


def parse_contract_blocks_from_text(text: str) -> list[ParsedContractBlock]:
    blocks = extract_all_contract_block_lines(text)
    return [_parse_single_contract_block(b) for b in blocks]


def _parse_single_contract_block(contract_lines: list[str]) -> ParsedContractBlock:
    return ParsedContractBlock(
        name=_parse_name(contract_lines),
        layer=_parse_layer(contract_lines),
        states=_parse_states(contract_lines),
        props=_parse_props(contract_lines),
        events=_parse_events(contract_lines),
        slots=_parse_slots(contract_lines),
    )


def parse_palette_entries_for_file(path: Path, fallback_unit: str) -> list[ParsedContractBlock]:
    """
    All CONTRACT entries in a template file. Empty list if unreadable or no CONTRACT.
    """
    try:
        text = path.read_text(encoding="utf-8")
    except Exception as e:  # pragma: no cover - defensive
        logger.warning("props_parser: cannot read file %s: %s", path, e)
        return []
    raw_blocks = extract_all_contract_block_lines(text)
    if not raw_blocks:
        legacy = _extract_first_contract_block_lines(text)
        if not legacy:
            return []
        raw_blocks = [legacy]
    parsed = [_parse_single_contract_block(b) for b in raw_blocks]
    out: list[ParsedContractBlock] = []
    for i, b in enumerate(parsed):
        name = b.name
        if not name:
            name = fallback_unit if len(parsed) == 1 else f"{fallback_unit}_{i + 1}"
        out.append(
            ParsedContractBlock(
                name=name,
                layer=b.layer,
                states=b.states,
                props=b.props,
                events=b.events,
                slots=b.slots,
            )
        )
    return out


def parse_component_props(file_path: Path) -> list[PropDef]:
    """
    Parses the first CONTRACT block (legacy: first block in first ~80 lines).

    Degraded mode: if CONTRACT is missing/unparseable, returns [] and logs a warning.
    Never raises.
    """
    try:
        text = file_path.read_text(encoding="utf-8")
    except Exception as e:  # pragma: no cover - defensive
        logger.warning("props_parser: cannot read file %s: %s", file_path, e)
        return []

    contract_lines = _extract_first_contract_block_lines(text)
    if not contract_lines:
        all_blocks = extract_all_contract_block_lines(text)
        if all_blocks:
            return _parse_props(all_blocks[0])
        logger.warning("props_parser: missing/empty CONTRACT block in %s", file_path)
        return []

    return _parse_props(contract_lines)


def parse_component_contract(file_path: Path) -> tuple[list[PropDef], list[str]]:
    """
    Extra helper for Composer: returns (props, states) from the first CONTRACT block.
    CONTRACT-unparseable -> ([], []).
    Never raises.
    """
    try:
        text = file_path.read_text(encoding="utf-8")
    except Exception as e:  # pragma: no cover
        logger.warning("props_parser: cannot read file %s: %s", file_path, e)
        return [], []

    contract_lines = _extract_first_contract_block_lines(text)
    if not contract_lines:
        all_blocks = extract_all_contract_block_lines(text)
        if all_blocks:
            b = all_blocks[0]
            return _parse_props(b), _parse_states(b)
        return [], []

    return _parse_props(contract_lines), _parse_states(contract_lines)


def infer_stack_from_path(file_path: Path) -> str:
    s = str(file_path).replace("\\", "/").lower()
    if "/flutter/" in s or s.endswith(".dart"):
        return "flutter"
    return "react"


def parse_component_contract_info(file_path: Path) -> ComponentContractInfo:
    """
    Helper that returns component_name + (states/stack) + parsed props.

    Degraded mode: missing/unparseable CONTRACT -> empty props/states.
    Never raises.
    """
    component_name = file_path.stem
    stack = infer_stack_from_path(file_path)
    props, states = parse_component_contract(file_path)
    blocks = parse_palette_entries_for_file(file_path, file_path.stem)
    if blocks and blocks[0].name:
        component_name = blocks[0].name or component_name
    return ComponentContractInfo(
        component_name=component_name,
        states=states,
        stack=stack,
        props=props,
    )
