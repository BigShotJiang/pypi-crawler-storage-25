from pathlib import Path

from forge.tools.scaffold.importers.react import ReactImporter


FIX = Path(__file__).parent / "fixtures"


def _registry() -> dict[str, dict]:
    return {k: {"name": k} for k in ["AppShell", "VStack", "SectionHeader", "StatCard", "Button", "Grid", "DataTable"]}


def test_react_simple_screen() -> None:
    res = ReactImporter().import_screen(str(FIX / "simple_react_screen.tsx"), _registry(), {"name": "demo"})
    assert res.canvas.tree.component == "AppShell"
    assert res.confidence > 0.7
