from pathlib import Path

from forge.tools.scaffold.importers.flutter import FlutterImporter


FIX = Path(__file__).parent / "fixtures"


def _registry() -> dict[str, dict]:
    return {k: {"name": k} for k in ["AppShell", "AppBar", "VStack", "Text", "Button", "ListTile"]}


def test_flutter_simple_screen() -> None:
    res = FlutterImporter().import_screen(str(FIX / "simple_flutter_screen.dart"), _registry(), {"name": "demo"})
    assert res.canvas.tree.component == "AppShell"
    assert res.confidence > 0.5
