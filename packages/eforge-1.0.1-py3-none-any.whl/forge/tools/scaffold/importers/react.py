from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from forge.tools.scaffold.canvas_schema import CanvasConfig, CanvasMeta, CanvasNode, ControllerFieldBinding, RouteBinding, CanvasTree
from forge.tools.scaffold.importers.base import ImportResult, ScreenImporter, make_fallback_result


_MAP: dict[str, str] = {
    "div": "Box",
    "span": "Text",
    "button": "Button",
    "input": "Input",
    "ul": "VStack",
    "ol": "VStack",
    "li": "ListTile",
    "h1": "Text",
    "h2": "Text",
    "h3": "Text",
    "p": "Text",
    "img": "Image",
    "a": "Link",
}


class ReactImporter(ScreenImporter):
    stack = "react"

    def can_import(self, path: str) -> bool:
        return path.endswith(".tsx") or path.endswith(".jsx")

    def import_screen(
        self,
        path: str,
        registry: dict[str, dict[str, Any]],
        manifest: dict[str, Any],
    ) -> ImportResult:
        p = Path(path)
        if not p.exists():
            return make_fallback_result(path, self.stack, "File not found")
        try:
            text = p.read_text(encoding="utf-8")
        except Exception as exc:
            return make_fallback_result(path, self.stack, f"Failed reading file: {exc}")

        name_match = re.search(r"export\s+default\s+function\s+(\w+)", text) or re.search(r"const\s+(\w+)\s*=\s*\(", text)
        screen_name = name_match.group(1) if name_match else p.stem
        jsx = text
        start = text.find("return (")
        if start != -1:
            start = start + len("return (")
            end = text.rfind(")")
            if end > start:
                jsx = text[start:end]
        tags = list(re.finditer(r"<([A-Za-z][A-Za-z0-9_]*)\b([^>]*)/?>", jsx))
        if not tags:
            return make_fallback_result(path, self.stack, "No JSX tree detected", source=text)

        def _node_for(tag: str, attrs: str) -> CanvasNode:
            mapped = tag if tag in registry else _MAP.get(tag, "unknown")
            props: dict[str, Any] = {}
            wiring: dict[str, Any] = {}
            for k, v in re.findall(r'(\w+)="([^"]*)"', attrs):
                props[k] = v
            for k in re.findall(r"\s(\w+)\b(?!=)", attrs):
                props.setdefault(k, True)
            expr_props = re.findall(r"(\w+)\s*=\s*\{([^}]*)\}", attrs)
            for k, expr in expr_props:
                props[k] = "{" + expr + "}"
                w = re.search(r"(\w+)\.(\w+)", expr)
                if w:
                    wiring[k] = ControllerFieldBinding(controller=w.group(1), field=w.group(2))
                nav = re.search(r"navigate\(\s*['\"]([^'\"]+)['\"]\s*\)", expr)
                if nav:
                    wiring[k] = RouteBinding(route_name=nav.group(1).lstrip("/"), args={})
            if mapped == "unknown":
                props["raw_source"] = f"<{tag} {attrs}>"
                props["html_element"] = tag if tag.islower() else None
            return CanvasNode(component=mapped, props=props, wiring=wiring, children=[], slot=None)

        root_tag = tags[0].group(1)
        root = _node_for(root_tag, tags[0].group(2))
        nav_global = re.search(r"navigate\(\s*['\"]([^'\"]+)['\"]\s*\)", jsx)
        if nav_global:
            root.wiring["onClick"] = RouteBinding(route_name=nav_global.group(1).lstrip("/"), args={})
        field_global = re.search(r"(\w+)\.(\w+)", jsx)
        if field_global:
            root.wiring.setdefault(
                "value",
                ControllerFieldBinding(controller=field_global.group(1), field=field_global.group(2)),
            )
        for m in tags[1:18]:
            root.children.append(_node_for(m.group(1), m.group(2)))

        total = 1 + len(root.children)
        known = sum(1 for n in [root, *root.children] if n.component != "unknown")
        unknown = total - known
        confidence = max(0.0, min(1.0, known / total if total else 0.0))
        shell = root.component if root.component in ("AppShell", "AuthShell", "WizardShell", "SettingsShell") else "AppShell"
        tree = CanvasTree(
            meta=CanvasMeta(
                name=re.sub(r"(Screen|Page|View)$", "", screen_name) or screen_name,
                version="v1",
                stack="react",
                created=datetime.now(timezone.utc).isoformat(),
                author="{{AUTHOR}}",
                app=str(manifest.get("name") or "unknown"),
                forge_version="1.0.0",
            ),
            config=CanvasConfig(shell=shell, variant="default", token_set="default"),
            tree=root,
        )
        warnings: list[str] = []
        if unknown:
            warnings.append(f"{unknown} components could not be identified")
        return ImportResult(canvas=tree, confidence=confidence, warnings=warnings, unknown_count=unknown, total_count=total)
