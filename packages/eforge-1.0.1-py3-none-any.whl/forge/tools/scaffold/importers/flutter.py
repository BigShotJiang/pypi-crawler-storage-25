from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from forge.tools.scaffold.canvas_schema import CanvasConfig, CanvasMeta, CanvasNode, ControllerFieldBinding, CanvasTree
from forge.tools.scaffold.importers.base import ImportResult, ScreenImporter, make_fallback_result


_MAP: dict[str, str] = {
    "Scaffold": "AppShell",
    "AppBar": "AppBar",
    "Column": "VStack",
    "Row": "HStack",
    "ListView": "VStack",
    "Text": "Text",
    "ElevatedButton": "Button",
    "TextButton": "Button",
    "OutlinedButton": "Button",
    "IconButton": "IconButton",
    "TextField": "Input",
    "TextFormField": "Input",
    "Card": "Card",
    "ListTile": "ListTile",
    "Container": "Box",
    "GridView": "Grid",
    "Image": "Image",
    "Icon": "Icon",
    "CircleAvatar": "Avatar",
    "Chip": "Chip",
}


class FlutterImporter(ScreenImporter):
    stack = "flutter"

    def can_import(self, path: str) -> bool:
        return path.endswith(".dart")

    def import_screen(
        self,
        path: str,
        registry: dict[str, dict[str, Any]],
        manifest: dict[str, Any],
    ) -> ImportResult:
        p = Path(path)
        if not p.exists():
            return make_fallback_result(path, self.stack, "File not found")
        try:
            text = p.read_text(encoding="utf-8")
        except Exception as exc:
            return make_fallback_result(path, self.stack, f"Failed reading file: {exc}")

        class_match = re.search(r"class\s+(\w+)\s+extends\s+StatelessWidget", text)
        screen_name = class_match.group(1) if class_match else p.stem
        build_match = re.search(r"build\s*\([^)]*\)\s*\{(?P<body>[\s\S]*?)\n\s*\}", text)
        body = build_match.group("body") if build_match else text
        return_match = re.search(r"return\s*\((?P<tree>[\s\S]*?)\);\s*$", body, flags=re.M)
        tree_src = return_match.group("tree") if return_match else body

        widgets = list(re.finditer(r"([A-Z][A-Za-z0-9_]*)\s*\(", tree_src))
        if not widgets:
            return make_fallback_result(path, self.stack, "No widget tree detected", source=text)

        def _node_for(name: str, snippet: str) -> CanvasNode:
            mapped = _MAP.get(name, name if name in registry else "unknown")
            props: dict[str, Any] = {}
            if mapped == "unknown":
                props["dart_widget"] = name
                props["raw_source"] = snippet[:140]
            if "context.watch<" in snippet or "context.read<" in snippet:
                ctrl_match = re.search(r"context\.(?:watch|read)<(\w+)>", snippet)
                if ctrl_match:
                    props["needs_wiring"] = True
                    wiring = {"value": ControllerFieldBinding(controller=ctrl_match.group(1), field="unknown")}
                else:
                    wiring = {}
            else:
                wiring = {}
            for k, v in re.findall(r"(\w+)\s*:\s*'([^']*)'", snippet):
                props[k] = v
            for k, v in re.findall(r'(\w+)\s*:\s*"([^"]*)"', snippet):
                props[k] = v
            for k, v in re.findall(r"(\w+)\s*:\s*(true|false|\d+)", snippet):
                if v in ("true", "false"):
                    props[k] = v == "true"
                elif v.isdigit():
                    props[k] = int(v)
            return CanvasNode(component=mapped, props=props, wiring=wiring, children=[], slot=None)

        root_name = widgets[0].group(1)
        root_snip = tree_src[widgets[0].start() : widgets[0].start() + 220]
        root = _node_for(root_name, root_snip)
        if "context.watch<" in text or "context.read<" in text:
            ctrl_match = re.search(r"context\.(?:watch|read)<(\w+)>", text)
            if ctrl_match:
                root.wiring["value"] = ControllerFieldBinding(controller=ctrl_match.group(1), field="unknown")
        for m in widgets[1:12]:
            name = m.group(1)
            snip = tree_src[m.start() : m.start() + 220]
            root.children.append(_node_for(name, snip))

        total = 1 + len(root.children)
        known = sum(1 for n in [root, *root.children] if n.component != "unknown")
        unknown = total - known
        confidence = max(0.0, min(1.0, known / total if total else 0.0))
        shell = "AppShell" if root_name in ("Scaffold", "SafeArea") else "AppShell"
        tree = CanvasTree(
            meta=CanvasMeta(
                name=screen_name,
                version="v1",
                stack="flutter",
                created=datetime.now(timezone.utc).isoformat(),
                author="{{AUTHOR}}",
                app=str(manifest.get("name") or "unknown"),
                forge_version="1.0.0",
            ),
            config=CanvasConfig(shell=shell, variant="default", token_set="default"),
            tree=root,
        )
        warnings: list[str] = []
        if unknown:
            warnings.append(f"{unknown} components could not be identified")
        return ImportResult(canvas=tree, confidence=confidence, warnings=warnings, unknown_count=unknown, total_count=total)
