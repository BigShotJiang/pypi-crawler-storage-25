from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from forge.tools.scaffold.canvas_schema import CanvasConfig, CanvasMeta, CanvasNode, CanvasTree


@dataclass
class ImportResult:
    canvas: CanvasTree
    confidence: float
    warnings: list[str] = field(default_factory=list)
    unknown_count: int = 0
    total_count: int = 0


class ScreenImporter:
    stack: str = "unknown"

    def can_import(self, path: str) -> bool:
        raise NotImplementedError

    def import_screen(
        self,
        path: str,
        registry: dict[str, dict[str, Any]],
        manifest: dict[str, Any],
    ) -> ImportResult:
        raise NotImplementedError


def make_fallback_result(path: str, stack: str, warning: str, source: str = "") -> ImportResult:
    node = CanvasNode(
        component="unknown",
        props={"raw_source": source[:2000], "source_path": path},
        wiring={},
        children=[],
        slot=None,
    )
    name = Path(path).stem or "ImportedScreen"
    tree = CanvasTree(
        meta=CanvasMeta(
            name=name,
            version="v1",
            stack=stack,
            created=datetime.now(timezone.utc).isoformat(),
            author="{{AUTHOR}}",
            app="unknown",
            forge_version="1.0.0",
        ),
        config=CanvasConfig(shell="AppShell", variant="default", token_set="default"),
        tree=node,
    )
    return ImportResult(canvas=tree, confidence=0.1, warnings=[warning], unknown_count=1, total_count=1)


def get_importer(stack: str) -> ScreenImporter:
    from forge.tools.scaffold.importers.flutter import FlutterImporter
    from forge.tools.scaffold.importers.react import ReactImporter

    if stack == "flutter":
        return FlutterImporter()
    if stack in ("react", "nextjs"):
        return ReactImporter()
    raise ValueError(f"No importer for stack: {stack}")
