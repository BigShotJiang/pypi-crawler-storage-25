from __future__ import annotations

import ast
import re
from typing import Any, Mapping

_INTERP_RE = re.compile(r"\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}")
_LEGACY_INTERP_RE = re.compile(r"\{([A-Za-z_][A-Za-z0-9_]*)\}")

_ALLOWED_BOOL_OPS = (ast.And, ast.Or)
_ALLOWED_UNARY_OPS = (ast.Not,)
_ALLOWED_CMP_OPS = (ast.Eq, ast.NotEq, ast.In, ast.NotIn)
_ALLOWED_CONST = (str, bool, int)


def referenced_names(expr: str) -> set[str]:
    tree = ast.parse(expr, mode="eval")
    out: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            out.add(node.id)
    return out


def validate_safe_expr(expr: str, allowed_names: set[str]) -> None:
    tree = ast.parse(expr, mode="eval")
    for node in ast.walk(tree):
        if isinstance(node, (ast.Expression, ast.Load)):
            continue
        if isinstance(node, (ast.boolop, ast.cmpop, ast.unaryop)):
            continue
        if isinstance(node, ast.Name):
            if node.id not in allowed_names:
                raise ValueError(f"unknown name in expression: {node.id}")
            continue
        if isinstance(node, ast.Constant):
            if not isinstance(node.value, _ALLOWED_CONST):
                raise ValueError(f"unsupported constant in expression: {node.value!r}")
            continue
        if isinstance(node, ast.BoolOp):
            if not isinstance(node.op, _ALLOWED_BOOL_OPS):
                raise ValueError("unsupported boolean operator")
            continue
        if isinstance(node, ast.UnaryOp):
            if not isinstance(node.op, _ALLOWED_UNARY_OPS):
                raise ValueError("unsupported unary operator")
            continue
        if isinstance(node, ast.Compare):
            if not node.ops or not all(isinstance(op, _ALLOWED_CMP_OPS) for op in node.ops):
                raise ValueError("unsupported comparison operator")
            continue
        if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
            continue
        raise ValueError(f"unsupported expression node: {type(node).__name__}")


def eval_safe_expr(expr: str, context: Mapping[str, Any], allowed_names: set[str]) -> bool:
    validate_safe_expr(expr, allowed_names)
    tree = ast.parse(expr, mode="eval")
    return bool(_eval(tree.body, dict(context)))


def _eval(node: ast.AST, context: Mapping[str, Any]) -> Any:
    if isinstance(node, ast.Name):
        return context.get(node.id)
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.List):
        return [_eval(e, context) for e in node.elts]
    if isinstance(node, ast.Tuple):
        return tuple(_eval(e, context) for e in node.elts)
    if isinstance(node, ast.Set):
        return {_eval(e, context) for e in node.elts}
    if isinstance(node, ast.BoolOp):
        vals = [_eval(v, context) for v in node.values]
        if isinstance(node.op, ast.And):
            return all(vals)
        if isinstance(node.op, ast.Or):
            return any(vals)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
        return not _eval(node.operand, context)
    if isinstance(node, ast.Compare):
        left = _eval(node.left, context)
        for op, comp in zip(node.ops, node.comparators):
            right = _eval(comp, context)
            if isinstance(op, ast.Eq):
                ok = left == right
            elif isinstance(op, ast.NotEq):
                ok = left != right
            elif isinstance(op, ast.In):
                ok = left in right
            elif isinstance(op, ast.NotIn):
                ok = left not in right
            else:
                raise ValueError("unsupported comparison operator")
            if not ok:
                return False
            left = right
        return True
    raise ValueError(f"unsupported expression node: {type(node).__name__}")


def interpolate_fields(text: str, values: Mapping[str, Any]) -> str:
    out = str(text)

    def _replace_mustache(match: re.Match[str]) -> str:
        key = match.group(1)
        if key not in values:
            raise ValueError(f"missing interpolation value: {key}")
        return str(values[key])

    out = _INTERP_RE.sub(_replace_mustache, out)

    def _replace_legacy(match: re.Match[str]) -> str:
        key = match.group(1)
        if key not in values:
            return match.group(0)
        return str(values[key])

    out = _LEGACY_INTERP_RE.sub(_replace_legacy, out)
    return out
