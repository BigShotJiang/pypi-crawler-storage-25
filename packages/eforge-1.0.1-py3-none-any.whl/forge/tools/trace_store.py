from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from typing import Any
from contextlib import ExitStack, contextmanager
from unittest import mock

import yaml

from forge.core.execution_graph import ExecutionGraph, ExecutionEdge, ExecutionNode


class SafeTraceRunner:
    """Run trace functions with optional safety guards."""

    def __init__(
        self,
        timeout: int | None = None,
        no_subprocess: bool = False,
        dry_call: bool = False,
        mock_network: bool = False,
        mock_fs_writes: bool = False,
        auto_pythonpath: bool = False,
        project_root: Path | None = None,
    ) -> None:
        self.timeout = timeout
        self.no_subprocess = no_subprocess
        self.dry_call = dry_call
        self.mock_network = mock_network
        self.mock_fs_writes = mock_fs_writes
        self.auto_pythonpath = auto_pythonpath
        self.project_root = project_root

    def _patch_sys_path(self) -> None:
        """Prepend project import roots when requested."""
        if not self.auto_pythonpath or not self.project_root:
            return
        candidates = [self.project_root, self.project_root / "src", self.project_root / "lib"]
        for p in reversed(candidates):
            if p.exists() and str(p) not in sys.path:
                sys.path.insert(0, str(p))

    @contextmanager
    def _safety_context(self):
        """Patch risky APIs for safe tracing."""
        patches: list[Any] = []
        if self.no_subprocess:
            def _blocked_subprocess(*_a, **_kw):
                raise RuntimeError("subprocess blocked by --no-subprocess (safe trace mode)")
            patches.extend(
                [
                    mock.patch("subprocess.run", side_effect=_blocked_subprocess),
                    mock.patch("subprocess.Popen", side_effect=_blocked_subprocess),
                ]
            )
        if self.mock_network:
            def _blocked_socket(*_a, **_kw):
                raise OSError("network blocked by --mock-network (safe trace mode)")
            patches.append(mock.patch("socket.socket", side_effect=_blocked_socket))
            try:
                import requests  # noqa: F401
                patches.append(mock.patch("requests.Session.request", side_effect=lambda *_a, **_kw: _blocked_socket()))
            except ImportError:
                pass
        if self.mock_fs_writes:
            _real_open = open

            def _safe_open(path, mode="r", *_a, **_kw):
                if any(m in mode for m in ("w", "a", "x")):
                    raise IOError(f"write blocked by --mock-fs-writes: {path}")
                return _real_open(path, mode, *_a, **_kw)

            patches.append(mock.patch("builtins.open", side_effect=_safe_open))
        with ExitStack() as stack:
            for p in patches:
                stack.enter_context(p)
            yield

    def run(self, trace_fn, *args, **kwargs):
        """Execute trace function with safety guards and optional timeout."""
        self._patch_sys_path()

        def _execute():
            with self._safety_context():
                if self.dry_call:
                    return {"dry_call": True, "note": "entry not invoked (--dry-call)"}
                return trace_fn(*args, **kwargs)

        if self.timeout:
            import threading

            result = [None]
            error = [None]

            def _target():
                try:
                    result[0] = _execute()
                except Exception as exc:  # noqa: BLE001
                    error[0] = exc

            thread = threading.Thread(target=_target, daemon=True)
            thread.start()
            thread.join(timeout=self.timeout)
            if thread.is_alive():
                return None, TimeoutError(f"forge trace exceeded --timeout {self.timeout}s")
            if error[0]:
                return None, error[0]
            return result[0], None

        try:
            return _execute(), None
        except Exception as exc:  # noqa: BLE001
            return None, exc


def traces_dir(project_root: Path) -> Path:
    d = project_root.expanduser().resolve() / ".forge" / "traces"
    d.mkdir(parents=True, exist_ok=True)
    return d


def write_trace(
    project_root: Path,
    graph: ExecutionGraph,
    *,
    fmt: str,
    path: Path | None = None,
) -> Path:
    root = project_root.expanduser().resolve()
    fmt_l = (fmt or "yaml").strip().lower()
    payload = graph.to_trace_yaml_dict()
    if path is None:
        out_dir = traces_dir(root)
        stem = f"trace-{int(graph.trace_start)}"
        path = out_dir / (f"{stem}.json" if fmt_l == "json" else f"{stem}.yaml")
    else:
        path = path.expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    if fmt_l == "json":
        path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    else:
        path.write_text(yaml.safe_dump(payload, sort_keys=False, allow_unicode=True), encoding="utf-8")
    return path


def latest_trace_file(project_root: Path) -> Path | None:
    root = project_root.expanduser().resolve()
    out_dir = root / ".forge" / "traces"
    if not out_dir.is_dir():
        return None
    candidates = sorted(
        [p for p in out_dir.iterdir() if p.suffix.lower() in (".yaml", ".yml", ".json") and p.is_file()],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return candidates[0] if candidates else None


def load_latest_trace(project_root: Path) -> ExecutionGraph | None:
    """Load the newest trace file under ``.forge/traces`` and return a typed graph.

    On-disk files remain YAML/JSON dicts (``to_trace_yaml_dict`` / ``trace`` wrapper).
    """
    path = latest_trace_file(project_root)
    if path is None:
        return None
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        data = json.loads(text)
        if not isinstance(data, dict):
            return None
    else:
        data = yaml.safe_load(text)
        if not isinstance(data, dict):
            return None
    return trace_dict_to_execution_graph(data)


def trace_dict_to_execution_graph(data: dict[str, Any]) -> ExecutionGraph | None:
    """Rehydrate ``ExecutionGraph`` from a stored trace file body (YAML/JSON root dict).

    Used by ``load_latest_trace`` and any caller that reads trace JSON from disk or
    fixtures. Not the primary API for in-memory traces (use ``ExecutionGraph`` directly).
    """
    raw_trace = data.get("trace")
    if not isinstance(raw_trace, dict):
        return None
    g = ExecutionGraph(
        entry_point=(str(raw_trace.get("entry_point") or "").strip() or None),
        trace_start=time.time(),
        trace_end=None,
    )
    nodes_raw = raw_trace.get("nodes") or []
    edges_raw = raw_trace.get("edges") or []
    if isinstance(nodes_raw, list):
        for row in nodes_raw:
            if not isinstance(row, dict):
                continue
            nid = str(row.get("id") or "")
            if not nid:
                continue
            g.nodes[nid] = ExecutionNode(
                id=nid,
                kind=str(row.get("kind") or "function"),
                module=str(row.get("module") or ""),
                qualname=str(row.get("qualname") or ""),
                file=str(row.get("file") or ""),
                line=int(row.get("line") or 0),
                call_count=int(row.get("call_count") or 0),
                stack=str(row.get("stack") or "python"),
                layer=str(row.get("layer") or "execution"),
            )
    if isinstance(edges_raw, list):
        for row in edges_raw:
            if not isinstance(row, dict):
                continue
            eid = str(row.get("id") or "")
            if not eid:
                continue
            g.edges[eid] = ExecutionEdge(
                id=eid,
                from_id=str(row.get("from_id") or ""),
                to_id=str(row.get("to_id") or ""),
                edge_kind=str(row.get("edge_kind") or "calls"),
                call_count=int(row.get("call_count") or 0),
                layer=str(row.get("layer") or "execution"),
            )
    return g
