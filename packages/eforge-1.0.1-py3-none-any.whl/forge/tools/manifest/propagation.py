"""
forge/tools/manifest/propagation.py

Phase 7 — Propagation engine.

Contract (non-negotiable):
  - propagate() NEVER raises. Failures go through emit_failure().
  - BFS traversal is bidirectional (edges_from + edges_to).
  - Role derivation is direction-sensitive: edge.from_id == current → caller;
    edge.to_id == current → callee; see derive_role() below.
  - On no_matching_rule: emit_failure and continue. Do NOT throw.
  - Do NOT rely on forge_blast_radius rings param for traversal.
    Use edges_from/edges_to directly (rings is reserved/informational).
  - Effect vocabulary and Role vocabulary are CLOSED SETS.
    Do not add values without explicit instruction + ADR.

Effect vocabulary: async_required | signature_changed | import_changed | behavior_changed
Role vocabulary:   self | caller | callee | importer | dependent
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

import yaml

from forge.tools.manifest.failures import emit_failure
from forge.tools.manifest.graph import ManifestEdge, ManifestGraph


# ── Role vocab ───────────────────────────────────────────────────────────────

class Role(str, Enum):
    self_ = "self"
    caller = "caller"
    callee = "callee"
    importer = "importer"
    dependent = "dependent"

    def __str__(self) -> str:
        return self.value


# ── Data types ────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class Diff:
    """A change event: which node changed and what effects it produces."""
    target: str                  # node_id of the changed node
    effects: list[str]           # e.g. ["async_required", "signature_changed"]


@dataclass(frozen=True)
class Impact:
    """One propagation result row: a node that must act, why, and how."""
    node_id: str
    role: str                    # Role value as string
    effect: str
    actions: list[str]           # e.g. ["add_async", "add_await"]
    source_node: str             # node_id that triggered this impact


# ── Rule loader ───────────────────────────────────────────────────────────────

@dataclass
class PropRule:
    effect: str
    applies_to: str              # role name
    generates: list[str]         # action list
    source: str = "generic"      # generic | project_file | stack_profile


def impact_rules_to_prop_rules(
    rules: list[Any],
    *,
    default_source: str = "stack_profile",
) -> list[PropRule]:
    """Convert stack profile ImpactRules to PropRules for the propagation engine.

    ImpactRule.checks → PropRule.generates
    ImpactRule.effect stays as effect
    ImpactRule.node_kind is discarded here (used for filtering upstream, not routing)
    """
    from forge.core.stack_profiles import ImpactRule

    out: list[PropRule] = []
    seen: set[tuple[str, str]] = set()
    for rule in rules:
        if not isinstance(rule, ImpactRule):
            continue
        key = (rule.effect, "self")
        if key not in seen:
            seen.add(key)
            out.append(
                PropRule(
                    effect=rule.effect,
                    applies_to="self",
                    generates=list(rule.checks),
                    source=default_source,
                )
            )
        key2 = (rule.effect, "dependent")
        if key2 not in seen:
            seen.add(key2)
            out.append(
                PropRule(
                    effect=rule.effect,
                    applies_to="dependent",
                    generates=[f"review_{c}" for c in rule.checks],
                    source=default_source,
                )
            )
    return out


def _load_rules(project_path: Path) -> list[PropRule]:
    """Load PropRules. Priority:
    1. project .forge/impact-rules.yaml
    2. project docs/impact-rules.yaml
    3. project impact-rules.yaml
    4. Stack profile ImpactRules (fallback)
    5. Empty list (never raises)
    """
    for candidate in (
        project_path / ".forge" / "impact-rules.yaml",
        project_path / "docs" / "impact-rules.yaml",
        project_path / "impact-rules.yaml",
    ):
        if candidate.is_file():
            try:
                raw = yaml.safe_load(candidate.read_text(encoding="utf-8")) or []
                if not isinstance(raw, list):
                    raw = []
                out: list[PropRule] = []
                for entry in raw:
                    if not isinstance(entry, dict):
                        continue
                    effect = str(entry.get("effect") or "")
                    applies_to = str(entry.get("applies_to") or "")
                    generates = list(entry.get("generates") or [])
                    if effect and applies_to:
                        out.append(
                            PropRule(
                                effect=effect,
                                applies_to=applies_to,
                                generates=generates,
                                source="project_file",
                            )
                        )
                if out:
                    return out
            except Exception:
                pass

    try:
        from forge.core.manifest_path import resolve_manifest_path
        from forge.core.stack_profiles import (
            GENERIC_IMPACT_RULES,
            get_impact_rules,
            profile_for_manifest_dict,
        )

        mp = resolve_manifest_path(project_path)
        stack_label = "unknown"
        if mp and mp.is_file():
            try:
                mdata = yaml.safe_load(mp.read_text(encoding="utf-8")) or {}
                prof = profile_for_manifest_dict(mdata)
                stack_label = prof.id
            except Exception:
                pass

        impact_rules = get_impact_rules(stack_label)
        if impact_rules:

            def _rule_key(rule: Any) -> tuple[str, str, tuple[str, ...]]:
                return (rule.node_kind, rule.effect, tuple(rule.checks))

            generic_keys = {_rule_key(r) for r in GENERIC_IMPACT_RULES}
            generic_rules = [r for r in impact_rules if _rule_key(r) in generic_keys]
            stack_rules = [r for r in impact_rules if _rule_key(r) not in generic_keys]
            out: list[PropRule] = []
            if generic_rules:
                out.extend(
                    impact_rules_to_prop_rules(
                        generic_rules, default_source="generic"
                    )
                )
            if stack_rules:
                out.extend(
                    impact_rules_to_prop_rules(
                        stack_rules, default_source="stack_profile"
                    )
                )
            if out:
                return out
    except Exception:
        pass

    return []


def _match_rules(
    rules: list[PropRule],
    effect: str,
    role: Role,
) -> list[PropRule]:
    return [r for r in rules if r.effect == effect and r.applies_to == str(role)]


# ── Role derivation ───────────────────────────────────────────────────────────

def derive_role(edge: ManifestEdge, current_id: str) -> Role:
    """Derive the structural role of *current_id* relative to *edge*.

    Direction rules:
      edge.from_id == current_id  →  current is the *caller* (it calls/imports the target)
      edge.to_id   == current_id  →  current is the *callee* (it is called by the source)

    Relation-aware refinements:
      relation == "imports"    and from_id == current  →  importer
      relation == "imports"    and to_id   == current  →  dependent
      relation == "belongs_to"                         →  dependent (structural membership)

    Falls back to caller/callee if relation is unrecognised.
    """
    relation = str(edge.relation or "")

    if edge.from_id == current_id:
        # This node is the *source* of the edge
        if relation == "imports":
            return Role.importer
        return Role.caller

    if edge.to_id == current_id:
        # This node is the *target* of the edge
        if relation == "imports":
            return Role.dependent
        if relation == "belongs_to":
            return Role.dependent
        return Role.callee

    # Defensive fallback: edge does not involve current_id
    return Role.dependent


# ── Propagation engine ────────────────────────────────────────────────────────

def propagate(
    diff: Diff,
    graph: ManifestGraph,
    rules: list[PropRule] | None = None,
    *,
    project_path: Path | None = None,
    max_depth: int = 10,
) -> list[Impact]:
    """BFS propagation from diff.target across the manifest graph.

    For each reachable node (bidirectional edge traversal), derive its
    role relative to the traversed edge, look up matching impact rules,
    and emit Impact records. Unmatched effect+role pairs emit a failure
    and continue — they do NOT raise.

    Args:
        diff:         The change event (target node + effect list).
        graph:        Materialized ManifestGraph.
        rules:        Pre-loaded PropRule list. If None and project_path is
                      given, loads from project_path/docs/impact-rules.yaml.
        project_path: Used only for rule loading when rules=None.
        max_depth:    BFS depth cap (safety valve against cycles).

    Returns:
        list[Impact] — may be empty; never raises.
    """
    if rules is None:
        rules = _load_rules(project_path or Path("."))

    by_id = {n.id: n for n in graph.nodes}

    impacts: list[Impact] = []

    # ── Self impact first ────────────────────────────────────────────────────
    target = diff.target
    if target not in by_id:
        emit_failure("unknown_symbol", {"symbol": target, "diff_target": True})
        return impacts

    for effect in diff.effects:
        matched = _match_rules(rules, effect, Role.self_)
        if matched:
            for rule in matched:
                impacts.append(Impact(
                    node_id=target,
                    role=str(Role.self_),
                    effect=effect,
                    actions=list(rule.generates),
                    source_node=target,
                ))
        # (No emit_failure for self+effect — not all effects have a self rule)

    # ── BFS across graph ─────────────────────────────────────────────────────
    visited: set[str] = {target}
    queue: deque[tuple[str, int]] = deque([(target, 0)])

    while queue:
        current_id, depth = queue.popleft()
        if depth >= max_depth:
            continue

        # Collect all edges touching this node (bidirectional)
        neighbors: list[tuple[ManifestEdge, str]] = []
        for edge in graph.edges_from(current_id):
            neighbor_id = edge.to_id
            neighbors.append((edge, neighbor_id))
        for edge in graph.edges_to(current_id):
            neighbor_id = edge.from_id
            neighbors.append((edge, neighbor_id))

        for edge, neighbor_id in neighbors:
            if neighbor_id not in by_id:
                emit_failure("unknown_symbol", {
                    "symbol": neighbor_id,
                    "traversed_from": current_id,
                })
                continue

            # derive_role from the *neighbor's* perspective
            role = derive_role(edge, neighbor_id)

            for effect in diff.effects:
                matched = _match_rules(rules, effect, role)
                if not matched:
                    emit_failure("no_matching_rule", {
                        "symbol": neighbor_id,
                        "effect": effect,
                        "role": str(role),
                        "traversed_from": current_id,
                    })
                    # continue — do not throw
                else:
                    for rule in matched:
                        impacts.append(Impact(
                            node_id=neighbor_id,
                            role=str(role),
                            effect=effect,
                            actions=list(rule.generates),
                            source_node=target,
                        ))

            if neighbor_id not in visited:
                visited.add(neighbor_id)
                queue.append((neighbor_id, depth + 1))

    return impacts


# ── Convenience loader ────────────────────────────────────────────────────────

def load_rules(project_path: Path) -> list[PropRule]:
    """Public API for rule loading (mirrors internal _load_rules)."""
    return _load_rules(project_path)
