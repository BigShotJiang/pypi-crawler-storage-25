"""
forge/tools/manifest/failures.py

Phase 5 — Failure model for the propagation engine.

Rules (non-negotiable from COMPILER_SPEC):
  - emit_failure() NEVER raises. Emit and continue.
  - Callers (especially propagate()) must not throw on no_matching_rule.
  - graph_drift recovery triggers a graph rebuild, not a crash.

Failure types (closed set — do not add without explicit instruction):
  graph_drift       — graph is out of date relative to manifest on disk
  no_matching_rule  — propagation found no impact rule for an effect+role pair
  invalid_patch     — a generated patch does not apply cleanly
  unknown_symbol    — a node ID referenced in a diff is not in the graph
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class FailureType(str, Enum):
    graph_drift = "graph_drift"
    no_matching_rule = "no_matching_rule"
    invalid_patch = "invalid_patch"
    unknown_symbol = "unknown_symbol"


@dataclass
class Failure:
    """A non-fatal failure emitted during propagation or compilation."""

    type: FailureType
    context: dict[str, Any] = field(default_factory=dict)
    recovery_hint: str = ""


# Module-level registry of emitted failures for this Python process.
# Consumers (e.g. propagate()) append to this list; callers may inspect it.
_emitted: list[Failure] = []

# Registry of symbols encountered but not found in the graph.
# unknown_symbol failures register here so they can be reviewed later.
_unknown_symbols: list[str] = []


def emit_failure(failure_type: str | FailureType, context: dict[str, Any] | None = None) -> Failure:
    """Emit a structured failure. Never raises. Returns the Failure for callers.

    Recovery paths (implemented here as hints + side effects):
      graph_drift      → logs warning; caller should rebuild graph and retry
      no_matching_rule → logs warning; marks symbol for manual review; continue
      invalid_patch    → logs error; caller should revert and escalate
      unknown_symbol   → registers symbol in _unknown_symbols; logs warning
    """
    ctx: dict[str, Any] = dict(context or {})
    try:
        ftype = FailureType(failure_type)
    except ValueError:
        logger.warning("emit_failure: unknown failure type %r — treating as no_matching_rule", failure_type)
        ftype = FailureType.no_matching_rule
        ctx.setdefault("original_type", str(failure_type))

    hint = _apply_recovery(ftype, ctx)
    failure = Failure(type=ftype, context=ctx, recovery_hint=hint)
    _emitted.append(failure)
    return failure


def _apply_recovery(ftype: FailureType, ctx: dict[str, Any]) -> str:
    """Apply recovery side effects and return a human-readable hint. Never raises."""
    try:
        if ftype == FailureType.graph_drift:
            symbol = ctx.get("symbol") or ctx.get("node_id") or "(unknown)"
            logger.warning(
                "graph_drift: graph is stale for symbol %r — run `forge scan` to rebuild, then retry",
                symbol,
            )
            return "run `forge scan` → rebuild graph → retry propagation"

        if ftype == FailureType.no_matching_rule:
            symbol = ctx.get("symbol") or ctx.get("node_id") or "(unknown)"
            effect = ctx.get("effect") or "(unknown)"
            role = ctx.get("role") or "(unknown)"
            logger.warning(
                "no_matching_rule: no impact rule for effect=%r role=%r on symbol %r — "
                "marking for manual review, continuing",
                effect, role, symbol,
            )
            ctx.setdefault("requires_manual_review", True)
            return "no rule matched — symbol marked for manual review, propagation continues"

        if ftype == FailureType.invalid_patch:
            symbol = ctx.get("symbol") or ctx.get("node_id") or "(unknown)"
            logger.error(
                "invalid_patch: patch for symbol %r did not apply — revert and escalate",
                symbol,
            )
            return "revert patch → escalate to maintainer"

        if ftype == FailureType.unknown_symbol:
            symbol = ctx.get("symbol") or ctx.get("node_id") or "(unknown)"
            if symbol and symbol not in _unknown_symbols:
                _unknown_symbols.append(symbol)
            logger.warning(
                "unknown_symbol: %r not found in graph — registered for review, continuing",
                symbol,
            )
            return "symbol registered in unknown_symbols registry — propagation continues"

    except Exception as exc:  # recovery must never raise
        logger.warning("emit_failure: recovery side effect raised unexpectedly: %s", exc)

    return ""


def get_emitted() -> list[Failure]:
    """Return a copy of all failures emitted in this process."""
    return list(_emitted)


def get_unknown_symbols() -> list[str]:
    """Return a copy of all unknown symbols registered via emit_failure."""
    return list(_unknown_symbols)


def clear_emitted() -> None:
    """Clear the emitted failures log. Use between isolated propagation runs."""
    _emitted.clear()
    _unknown_symbols.clear()
