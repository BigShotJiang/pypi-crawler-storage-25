from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from forge.core.manifest import TIER_OVERRIDES_BY_ID, infer_tier, resolve_manifest_path
from forge.core.schemas import NodeTier
from forge.core.manifest_document import LayerSlice, ManifestDocument, layers_from_manifest_dict
from forge.core.stack_profiles import StackProfile
from forge.tools.docs_audit.contracts.normalize import normalize_manifest

# Default cache location relative to project root.
_GRAPH_CACHE_FILENAME = ".forge/manifest_graph.json"

MANIFEST_NODE_KINDS = [
    "screen",
    "controller",
    "service",
    "module",
    "feature",
    "domain",
    "component",
    "config",
    "error_code",
    "layer",
]

# Edge relation vocabulary for Forge manifest graphs.
#
# CANONICAL (declared in manifest.yaml):
#   depends_on    — explicit dependency
#   imports       — static import edge
#   implements    — interface fulfillment
#   contract      — contract binding
#   parity        — must-stay-in-sync pair
#   watches       — observes for changes
#   reads/writes  — data flow
#   fires         — event emission
#   gates         — access control
#   uses_variant  — A/B or feature flag
#   belongs_to    — domain membership
#   hooks_into    — plugin hook
#   produced_by   — generation source
#   must_use      — required dependency
#   must_not_use  — forbidden dependency
#
# DERIVED (inferred, not in manifest.yaml):
#   inferred      — engine-inferred edge
#   sibling_peer  — Ring 2 peer link
#
# EXTENSION RELATIONS:
# Extensions (forge-engine, community) may define additional relations.
# See EdgeModel.from_manifest_edge() for validation behavior.

MANIFEST_EDGE_RELATIONS = [
    "watches",
    "reads",
    "writes",
    "fires",
    "gates",
    "uses_variant",
    "belongs_to",
    "depends_on",
    "imports",
    "implements",
    "inferred",
    "must_not_use",
    "must_use",
    "hooks_into",
    "produced_by",
    "contract",
    # Parity contract: nodes that must stay in sync with each other.
    # Used by verify propagation engine.
    "parity",
    # Derived peer link (Ring 2). Not declared in manifest YAML —
    # inferred from sibling patterns.
    "sibling_peer",
]

# parity-sync: touched to refresh manifest<->graph drift marker.

# Inferred peer links (Ring 2); not declared in manifest YAML.
DERIVED_PEER_RELATION = "sibling_peer"


def resolve_node_status(node_path: str | None, project_root: Path) -> str:
    """Determine node status based on file existence."""
    if not node_path:
        return "declared"
    full_path = project_root / node_path
    return "implemented" if full_path.exists() else "declared"


@dataclass
class ManifestNode:
    id: str
    kind: str
    name: str
    path: str
    domain: str | None
    parent_id: str | None
    status: str = "declared"
    fqid: str = ""
    layer: str = "declaration"
    meta: dict = field(default_factory=dict)


def effective_node_tier(node: ManifestNode) -> str:
    """Effective declaration tier for queries — YAML when aligned, else :func:`~forge.core.manifest.infer_tier`.

    Stale YAML (e.g. ``tier: worker`` on ``stack-schema-*`` contract docs) defers to ``infer_tier``.
    """
    inferred = infer_tier(node.id, node.kind or "module")
    m = node.meta or {}
    raw = m.get("tier")
    if raw in (None, ""):
        return inferred.value
    try:
        declared = NodeTier(str(raw).strip().lower())
    except ValueError:
        return inferred.value
    if declared == inferred:
        return declared.value
    nid = (node.id or "").strip()
    if nid in TIER_OVERRIDES_BY_ID:
        return inferred.value
    slug = nid.split("/")[-1].lower() if nid else ""
    if slug.startswith("stack-schema-"):
        return inferred.value
    return declared.value


@dataclass
class ManifestEdge:
    from_id: str
    to_id: str
    relation: str
    derived: bool = False
    meta: dict[str, Any] = field(default_factory=dict)


def _edge_identity_key(edge: ManifestEdge) -> tuple[str, str, str, str]:
    """Stable key for deduplication: (from, to, relation, contract_method_or_empty).

    ``contract`` edges may legitimately share the same endpoints with different
    ``meta.method`` values; all other relations use the triple only.
    """
    m = edge.meta or {}
    method = str(m.get("method") or "") if edge.relation == "contract" else ""
    return (edge.from_id, edge.to_id, edge.relation, method)


def _dedupe_manifest_edges(edges: list[ManifestEdge]) -> list[ManifestEdge]:
    """Keep first occurrence per identity key — idempotent after multiple derivation passes."""
    seen: set[tuple[str, str, str, str]] = set()
    out: list[ManifestEdge] = []
    for e in edges:
        k = _edge_identity_key(e)
        if k in seen:
            continue
        seen.add(k)
        out.append(e)
    return out


@dataclass
class ManifestGraph:
    project_path: Path
    nodes: list[ManifestNode] = field(default_factory=list)
    edges: list[ManifestEdge] = field(default_factory=list)
    source: str = ""

    def _node_by_id(self) -> dict[str, ManifestNode]:
        return {n.id: n for n in self.nodes}

    def find_node(self, name: str, kind: str | None = None) -> ManifestNode | None:
        for n in self.nodes:
            if n.name != name:
                continue
            if kind is not None and n.kind != kind:
                continue
            return n
        return None

    def find_siblings(self, node_id: str) -> list[ManifestNode]:
        n = self._node_by_id().get(node_id)
        if not n:
            return []
        out: list[ManifestNode] = []
        seen: set[str] = set()
        # Same parent feature/domain
        if n.parent_id:
            for o in self.nodes:
                if o.id != n.id and o.parent_id == n.parent_id and o.id not in seen:
                    out.append(o)
                    seen.add(o.id)
        # Same watched controller(s) — screens
        w = (n.meta or {}).get("watched_controllers") or []
        if n.kind == "screen" and isinstance(w, list) and w:
            wfrozenset = frozenset(str(x) for x in w if x)
            for o in self.nodes:
                if o.id == n.id or o.kind != "screen":
                    continue
                ow = (o.meta or {}).get("watched_controllers") or []
                if not isinstance(ow, list):
                    continue
                if frozenset(str(x) for x in ow if x) == wfrozenset and wfrozenset:
                    if o.id not in seen:
                        out.append(o)
                        seen.add(o.id)
        # Same domain (non-screen or screen with domain)
        dom = (n.domain or "").strip().upper()
        if dom:
            for o in self.nodes:
                if o.id == n.id or o.id in seen:
                    continue
                od = (o.domain or "").strip().upper()
                if od == dom:
                    out.append(o)
                    seen.add(o.id)
        return out

    def find_watchers(self, controller_ref: str) -> list[ManifestNode]:
        """Screens that declare they watch ``controller_ref``.

        ``controller_ref`` is resolved **ID-first**: if it equals a node's ``id``, that controller
        is used; otherwise a **single** legacy match on controller ``name`` is accepted (ambiguous
        display names yield no hits).
        """
        token = (controller_ref or "").strip()
        if not token:
            return []
        by_id = self._node_by_id()
        ctl = by_id.get(token)
        if ctl is None:
            name_matches = [n for n in self.nodes if n.kind == "controller" and n.name == token]
            if len(name_matches) != 1:
                return []
            ctl = name_matches[0]
        found: list[ManifestNode] = []
        ctl_id = ctl.id
        ctl_name = ctl.name
        for n in self.nodes:
            if n.kind != "screen":
                continue
            w = (n.meta or {}).get("watched_controllers") or []
            if not isinstance(w, list):
                continue
            for raw in w:
                s = str(raw).strip()
                if s == ctl_id or s == ctl_name:
                    found.append(n)
                    break
        return found

    def find_dependents(self, service_ref: str) -> list[ManifestNode]:
        """Controllers listing ``service_ref`` in ``read_targets`` (by service id first, then name)."""
        token = (service_ref or "").strip()
        if not token:
            return []
        by_id = self._node_by_id()
        svc = by_id.get(token)
        if svc is None:
            name_matches = [n for n in self.nodes if n.kind == "service" and n.name == token]
            if len(name_matches) != 1:
                return []
            svc = name_matches[0]
        found: list[ManifestNode] = []
        svc_id = svc.id
        svc_name = svc.name
        for n in self.nodes:
            if n.kind != "controller":
                continue
            r = (n.meta or {}).get("read_targets") or []
            if not isinstance(r, list):
                continue
            for raw in r:
                s = str(raw).strip()
                if s == svc_id or s == svc_name:
                    found.append(n)
                    break
        return found

    def find_domain_members(self, domain: str) -> list[ManifestNode]:
        d = domain.strip().upper()
        return [n for n in self.nodes if (n.domain or "").strip().upper() == d]

    def nodes_by_domain(self, domain: str) -> list[ManifestNode]:
        """Public accessor — returns all nodes belonging to a domain.
        Does not reach into private fields."""
        return self.find_domain_members(domain)

    def edges_from(self, node_id: str) -> list[ManifestEdge]:
        """All edges where from_id == node_id (outbound from this node)."""
        return [e for e in self.edges if e.from_id == node_id]

    def edges_to(self, node_id: str) -> list[ManifestEdge]:
        """All edges where to_id == node_id (inbound to this node)."""
        return [e for e in self.edges if e.to_id == node_id]

    def find_ancestors(self, node_id: str) -> list[ManifestNode]:
        out: list[ManifestNode] = []
        by_id = self._node_by_id()
        cur = by_id.get(node_id)
        seen: set[str] = set()
        while cur and cur.parent_id and cur.parent_id not in seen:
            p = by_id.get(cur.parent_id)
            if not p:
                break
            out.append(p)
            seen.add(p.id)
            cur = p
        # domain chain
        cur = by_id.get(node_id)
        if cur and cur.domain:
            dom_id = f"domain/{_slug(cur.domain)}"
            domn = by_id.get(dom_id)
            if domn and domn.id not in seen:
                out.append(domn)
        return out

    def find_descendants(self, node_id: str) -> list[ManifestNode]:
        by_id = self._node_by_id()
        root = by_id.get(node_id)
        if not root:
            return []
        out: list[ManifestNode] = []
        stack = [nid for nid, n in by_id.items() if n.parent_id == node_id]
        seen: set[str] = set()
        while stack:
            nid = stack.pop()
            if nid in seen:
                continue
            seen.add(nid)
            n = by_id.get(nid)
            if n:
                out.append(n)
                stack.extend(nn.id for nn in self.nodes if nn.parent_id == nid)
        return out

    def blast_radius_ring2(
        self,
        node_id: str,
        change_kind: str = "any",
    ) -> dict[str, Any]:
        by_id = self._node_by_id()
        n = by_id.get(node_id)
        reason: dict[str, str] = {}
        watchers_l: list[ManifestNode] = []
        dependents_l: list[ManifestNode] = []
        siblings_l: list[ManifestNode] = []
        domain_members_l: list[ManifestNode] = []
        parity_reachable_l: list[ManifestNode] = []

        if not n:
            return {
                "watchers": [],
                "dependents": [],
                "siblings": [],
                "domain_members": [],
                "parity_reachable": {"count": 0, "nodes": [], "note": ""},
                "reason": {},
                "import_consumers": [],
                "contracts": {"outbound": [], "inbound": [], "total": 0},
            }

        ck = (change_kind or "any").strip().lower()

        def note(nodes: list[ManifestNode], msg: str) -> None:
            for x in nodes:
                reason.setdefault(x.id, msg)

        if ck in ("interface_change", "any") and n.kind == "controller":
            w = self.find_watchers(n.id)
            watchers_l = w
            note(w, f"Ring2 interface: screen watches `{n.id}`")

        if ck in ("reads_change", "any") and n.kind == "service":
            d = self.find_dependents(n.id)
            dependents_l = d
            note(d, f"Ring2 reads: controller depends on `{n.id}`")

        if ck in ("reads_change", "any") and n.kind == "controller":
            # Controllers that list this controller in depends_on / reads
            for o in self.nodes:
                if o.kind != "controller" or o.id == n.id:
                    continue
                r = (o.meta or {}).get("read_targets") or []
                if isinstance(r, list):
                    refs = [str(x).strip() for x in r if str(x).strip()]
                    if n.id in refs or n.name in refs:
                        dependents_l.append(o)
                        reason.setdefault(o.id, f"Ring2 reads: references `{n.id}`")

        if ck in ("domain_change", "any") and n.domain:
            dm = self.find_domain_members(n.domain)
            domain_members_l = [x for x in dm if x.id != n.id]
            note(domain_members_l, f"Ring2 domain: shared `{n.domain}`")

        if ck == "any":
            sib = self.find_siblings(node_id)
            siblings_l = [x for x in sib if x.id != node_id]
            note(siblings_l, "Ring2 sibling peer (domain / shared watches / parent)")

        # Nodes that declare an imports edge pointing to this node (glove / manifest).
        seen_importers: set[str] = set()
        for e in self.edges_to(node_id):
            if e.relation != "imports" or e.from_id not in by_id:
                continue
            if e.from_id in seen_importers:
                continue
            seen_importers.add(e.from_id)
            x = by_id[e.from_id]
            dependents_l.append(x)
            reason.setdefault(x.id, f"imports: declares dependency on `{n.name}`")

        outbound_contracts: list[dict[str, Any]] = []
        inbound_contracts: list[dict[str, Any]] = []
        for e in self.edges_from(node_id):
            if e.relation != "contract":
                continue
            em = e.meta or {}
            outbound_contracts.append({
                "peer_id": e.to_id,
                "method": em.get("method"),
                "contract_id": em.get("contract_id"),
                "verified": em.get("verified"),
            })
        for e in self.edges_to(node_id):
            if e.relation != "contract":
                continue
            em = e.meta or {}
            inbound_contracts.append({
                "peer_id": e.from_id,
                "method": em.get("method"),
                "contract_id": em.get("contract_id"),
                "verified": em.get("verified"),
            })

        # Parity edges are symmetric by contract: traverse both directions.
        for e in self.edges:
            if e.relation != "parity":
                continue
            symmetric = bool((e.meta or {}).get("symmetric", False))
            if not symmetric:
                continue
            if e.from_id == node_id and e.to_id in by_id:
                parity_reachable_l.append(by_id[e.to_id])
                reason.setdefault(e.to_id, f"parity: must stay in sync with `{n.name}`")
            elif e.to_id == node_id and e.from_id in by_id:
                parity_reachable_l.append(by_id[e.from_id])
                reason.setdefault(e.from_id, f"parity: must stay in sync with `{n.name}`")

        # de-dupe preserve order
        def dedupe(nodes: list[ManifestNode]) -> list[ManifestNode]:
            seen: set[str] = set()
            out2: list[ManifestNode] = []
            for x in nodes:
                if x.id not in seen:
                    seen.add(x.id)
                    out2.append(x)
            return out2

        deduped_deps = dedupe(dependents_l)
        import_consumer_entries: list[dict[str, Any]] = [
            {
                "node_id": iid,
                "name": by_id[iid].name,
                "reason": reason.get(
                    iid, f"imports: declares dependency on `{n.name}`"
                ),
            }
            for iid in sorted(seen_importers)
        ]

        return {
            "watchers": dedupe(watchers_l),
            "dependents": deduped_deps,
            "siblings": dedupe(siblings_l),
            "domain_members": dedupe(domain_members_l),
            "parity_reachable": {
                "count": len(dedupe(parity_reachable_l)),
                "nodes": [x.id for x in dedupe(parity_reachable_l)],
                "note": (
                    "these nodes share a parity contract with the origin — "
                    "if origin changes, all parity_reachable must also update"
                ),
            },
            "reason": reason,
            "import_consumers": import_consumer_entries,
            "contracts": {
                "outbound": outbound_contracts,
                "inbound": inbound_contracts,
                "total": len(outbound_contracts) + len(inbound_contracts),
            },
        }


def _slug(s: str) -> str:
    return (
        str(s)
        .strip()
        .lower()
        .replace(" ", "_")
        .replace("/", "_")
        .replace("\\", "_")
    )


def _norm_rel_path(p: str) -> str:
    return str(p).replace("\\", "/").lstrip("./")


def _graph_has_module_like_nodes(graph: ManifestGraph) -> bool:
    kinds = frozenset({"module", "controller", "service", "screen", "component", "model"})
    for n in graph.nodes:
        if n.kind in kinds and (n.path or "").strip():
            return True
    return False


def _merge_python_glove_imports_into_graph(graph: ManifestGraph) -> None:
    """Append ``imports`` edges from :func:`forge.tools.scan.parsers.python_app.parse_python`.

    Resolves ``DepEdge`` source/target relative paths to graph node ids via
    :func:`find_node_id_for_path`. Skips pairs that already have an ``imports`` edge
    (manifest ``depends_on`` or prior merge). Tags new edges with
    ``meta.source == \"python_glove\"`` and ``derived=True``.
    """
    from forge.tools.scan.parsers.python_app import parse_python

    root = graph.project_path.resolve()
    try:
        parsed = parse_python(root)
    except Exception:
        return
    if not parsed.dependencies:
        return
    edge_list: list[ManifestEdge] = list(graph.edges)
    seen_import_pairs: set[tuple[str, str]] = {
        (e.from_id, e.to_id) for e in edge_list if e.relation == "imports"
    }
    for dep in parsed.dependencies:
        src_p = _norm_rel_path(str(dep.source))
        tgt_p = _norm_rel_path(str(dep.target))
        from_nid = find_node_id_for_path(graph, src_p)
        to_nid = find_node_id_for_path(graph, tgt_p)
        if not from_nid or not to_nid or from_nid == to_nid:
            continue
        pair = (from_nid, to_nid)
        if pair in seen_import_pairs:
            continue
        seen_import_pairs.add(pair)
        edge_list.append(
            ManifestEdge(
                from_id=from_nid,
                to_id=to_nid,
                relation="imports",
                derived=True,
                meta={"source": "python_glove"},
            )
        )
    graph.edges = _dedupe_manifest_edges(edge_list)


def merge_stack_glove_scan_into_graph(graph: ManifestGraph) -> None:
    """Augment a manifest graph with stack glove import hints (Python + Dart).

    **Python** (``pyproject.toml`` or manifest ``type: python``): project-local import
    edges from :func:`forge.tools.scan.parsers.python_app.parse_python`, matched to
    manifest module nodes by ``path``.

    **Dart** (Flutter): synthetic ``lib/`` modules and mapped glove edges (legacy behavior).

    Used by ``forge map`` and MCP ``forge_map`` after :func:`build_manifest_graph`.
    Idempotent with respect to duplicate ``imports`` pairs.
    """
    from collections import defaultdict

    from forge.core.glove_mapper import GloveMapper, _glove_dart_prefix_to_lib_rel
    from forge.core.gloves import DartGlove, GLOVES
    from forge.tools.diff_report import _resolve_stack_key

    root = graph.project_path.resolve()
    stack = _resolve_stack_key(root)
    if stack == "python":
        _merge_python_glove_imports_into_graph(graph)
        return
    if stack != "dart":
        return
    lib_root = root / "lib"
    if not lib_root.is_dir():
        return
    glove = GLOVES.get("dart")
    if not isinstance(glove, DartGlove):
        return

    manifest_path = root / ".forge" / "manifest.yaml"
    # Only fallback to root manifest.yaml if .forge/manifest.yaml doesn't exist
    # This ensures we prioritize the standard .forge/ directory structure

    try:
        raw_nodes = glove.extract_nodes(root)
        raw_edges = glove.extract_edges(root)
    except Exception:
        return
    if not raw_nodes:
        return

    nodes_dict: dict[str, ManifestNode] = {n.id: n for n in graph.nodes}
    edge_list: list[ManifestEdge] = list(graph.edges)

    if not _graph_has_module_like_nodes(graph):
        by_file: dict[str, list[Any]] = defaultdict(list)
        for rn in raw_nodes:
            by_file[str(Path(str(rn.file)).resolve())].append(rn)
        for _fpath, rns in by_file.items():
            if not rns:
                continue
            fp = Path(str(rns[0].file)).resolve()
            try:
                lib_rel = fp.relative_to(lib_root)
            except ValueError:
                continue
            rel = _norm_rel_path(str(Path("lib") / lib_rel))
            mid = f"module/dart_{_slug(rel)}"
            if mid in nodes_dict:
                continue
            dom = (str(rns[0].domain or "CORE")).strip().upper() or "CORE"
            kind_pref = str(rns[0].kind or "module")
            for rn in rns:
                if rn.kind in ("controller", "screen", "service"):
                    kind_pref = str(rn.kind)
                    break
            if kind_pref not in MANIFEST_NODE_KINDS:
                kind_pref = "module"
            stem = fp.stem
            cls_names = sorted({str(rn.name) for rn in rns if (rn.name or "").strip()})
            nodes_dict[mid] = ManifestNode(
                id=mid,
                kind=kind_pref,
                name=stem,
                path=rel,
                domain=dom,
                parent_id=None,
                status=resolve_node_status(rel, root),
                meta={"glove_synthetic": True, "dart_classes": cls_names},
            )
            did = _ensure_domain_node(nodes_dict, edge_list, dom, root)
            if did:
                edge_list.append(
                    ManifestEdge(
                        from_id=mid,
                        to_id=did,
                        relation="belongs_to",
                        derived=True,
                        meta={"source": "dart_glove"},
                    )
                )

    graph.nodes = sorted(nodes_dict.values(), key=lambda x: x.id)
    id_set = {n.id for n in graph.nodes}

    if manifest_path.is_file():
        mapper = GloveMapper(manifest_path, project_root=root)
        for raw in mapper.map_edges(raw_edges, edge_kinds=frozenset({"imports"})):
            if raw.from_id in id_set and raw.to_id in id_set:
                edge_list.append(
                    ManifestEdge(
                        from_id=raw.from_id,
                        to_id=raw.to_id,
                        relation="imports",
                        derived=True,
                        meta={"source": "dartglove_mapped"},
                    )
                )

    mapper2 = GloveMapper(manifest_path, project_root=root) if manifest_path.is_file() else None
    if mapper2 is not None:
        for edge in raw_edges:
            if edge.edge_kind != "imports" or not str(edge.to_id).startswith("dart_import/"):
                continue
            from_part = str(edge.from_id).split("::", 1)[0]
            if "::" in str(edge.from_id) or not from_part.startswith("dart/"):
                continue
            lib_file_rel = _glove_dart_prefix_to_lib_rel(from_part[5:])
            if not lib_file_rel:
                continue
            from_norm = _norm_rel_path(str(Path("lib") / lib_file_rel))
            from_nid = find_node_id_for_path(graph, from_norm)
            if not from_nid:
                continue
            uri = str(edge.to_id).split("/", 1)[1]
            imp_path = root / from_norm
            to_rel = mapper2._resolve_import_uri(uri, imp_path if imp_path.is_file() else None)
            if not to_rel:
                continue
            to_norm = _norm_rel_path(to_rel)
            to_nid = find_node_id_for_path(graph, to_norm)
            if not to_nid or to_nid == from_nid:
                continue
            edge_list.append(
                ManifestEdge(
                    from_id=from_nid,
                    to_id=to_nid,
                    relation="imports",
                    derived=True,
                    meta={"source": "dart_glove_path"},
                )
            )

    graph.edges = _dedupe_manifest_edges(edge_list)


def _parse_name_list(val: Any) -> list[str]:
    if val is None:
        return []
    if isinstance(val, str):
        v = val.strip()
        if not v or v.lower() == "none":
            return []
        return [v]
    if isinstance(val, list):
        return [str(x).strip() for x in val if str(x).strip()]
    return []


def _screen_watch_names(row: dict[str, Any]) -> list[str]:
    w = _parse_name_list(row.get("watches"))
    if w:
        return w
    return _parse_name_list(row.get("controller"))


def _controller_read_targets(row: dict[str, Any]) -> list[str]:
    refs: list[str] = []
    refs.extend(_parse_name_list(row.get("reads")))
    refs.extend(_parse_name_list(row.get("depends_on")))
    seen: set[str] = set()
    out: list[str] = []
    for r in refs:
        if r not in seen:
            seen.add(r)
            out.append(r)
    return out


def _profile_meta(profile: StackProfile) -> dict[str, Any]:
    """Optional graph meta — stable string keys for StackProfile (does not replace node schema)."""
    return {
        "profile_id": str(getattr(profile, "id", "") or ""),
        "profile_template_segment": str(getattr(profile, "template_segment", "") or ""),
        "profile_glove_key": getattr(profile, "glove_key", None),
        "profile_schema_stem": getattr(profile, "schema_stem", None),
    }


def _add_layer_slice_nodes(
    nodes: dict[str, ManifestNode],
    layers: list[LayerSlice],
    project_path: Path,
) -> None:
    """One graph node per declared composite layer (``ManifestDocument.layers`` / inline equivalent)."""
    for layer in layers:
        lid = f"layer/{_slug(layer.id)}"
        if lid in nodes:
            continue
        meta: dict[str, Any] = {
            "layer_id": layer.id,
            "stack_label": layer.stack,
            **_profile_meta(layer.profile),
        }
        nodes[lid] = ManifestNode(
            id=lid,
            kind="layer",
            name=layer.id,
            path="",
            domain=None,
            parent_id=None,
            status=resolve_node_status("", project_path),
            meta=meta,
        )


def _coerce_map_or_list(value: Any) -> list[dict[str, Any]]:
    """Same shape as ``normalize._map_or_list_to_list`` — list or dict-of-dicts → list[dict]."""
    if isinstance(value, list):
        return [v for v in value if isinstance(v, dict)]
    if isinstance(value, dict):
        out: list[dict[str, Any]] = []
        for name, item in value.items():
            if isinstance(item, dict):
                row = dict(item)
                row.setdefault("name", str(name))
                out.append(row)
        return out
    return []


def _doc_projection_for_graph(doc: ManifestDocument) -> dict[str, Any]:
    """Projection boundary: derive graph ingress payload from ``ManifestDocument``."""
    return normalize_legacy_manifest(dict(doc.raw))


def _edge_rows_from_doc_projection(
    doc: ManifestDocument | None,
    normalized: dict[str, Any],
) -> list[dict[str, Any]]:
    """Resolve declarative edge rows without raw manifest lookups in graph assembly."""
    rows = normalized.get("edges")
    if isinstance(rows, list):
        return [r for r in rows if isinstance(r, dict)]
    if doc is not None:
        raw_edges = doc.raw.get("edges")
        if isinstance(raw_edges, list):
            return [r for r in raw_edges if isinstance(r, dict)]
    return []


def normalize_legacy_manifest(raw: dict[str, Any]) -> dict[str, Any]:
    """Coalesce pre–schema-v1 / modules-only shapes before ``normalize_manifest``.

    - ``schema_version`` missing or ``< 1`` → set to ``1`` and append a warning.
    - ``nodes`` absent but ``modules`` present → copy module rows into ``nodes`` (graph ingress).
    - ``domains`` as a bare string list with no ``nodes``/``modules`` rows → synthetic ``kind: domain`` nodes.

    Explicit ``edges:`` are preserved; callers should prefer edges over duplicate ``depends_on`` (C006).
    """
    if not isinstance(raw, dict):
        return {}
    out = dict(raw)
    w = out.get("warnings")
    warnings: list[str] = list(w) if isinstance(w, list) else []

    sch = out.get("schema_version")
    coerced_schema = False
    if sch is None:
        coerced_schema = True
        out["schema_version"] = 1
    else:
        try:
            v = int(sch)
        except (TypeError, ValueError):
            v = 1
        if v < 1:
            coerced_schema = True
            out["schema_version"] = 1
    if coerced_schema:
        warnings.append("schema_version missing or <1 — coerced to 1 for legacy manifest normalization")

    mod_rows = _coerce_map_or_list(out.get("modules"))
    node_rows = _coerce_map_or_list(out.get("nodes"))
    if not node_rows and mod_rows:
        warnings.append("legacy manifest: modules-only — mirrored rows into nodes for graph ingress")
        out["nodes"] = [dict(r) for r in mod_rows]

    doms = out.get("domains")
    if (
        isinstance(doms, list)
        and doms
        and not _coerce_map_or_list(out.get("nodes"))
        and not mod_rows
    ):
        synth: list[dict[str, Any]] = []
        for d in doms:
            if not isinstance(d, str) or not d.strip():
                continue
            name = d.strip().upper()
            did = f"domain/{_slug(name)}"
            synth.append(
                {
                    "id": did,
                    "kind": "domain",
                    "name": name,
                    "path": "",
                    "domain": name,
                    "role": "Synthetic domain node from legacy domains: list",
                }
            )
        if synth:
            warnings.append("legacy manifest: domains: string list — synthesized domain nodes")
            out["nodes"] = synth

    if warnings:
        out["warnings"] = warnings
    return out


def _ensure_domain_node(
    nodes: dict[str, ManifestNode],
    edges: list[ManifestEdge],
    domain_name: str,
    project_path: Path,
    *,
    parent_id: str | None = None,
) -> str:
    d = domain_name.strip().upper()
    if not d:
        return ""
    nid = f"domain/{_slug(d)}"
    if nid not in nodes:
        nodes[nid] = ManifestNode(
            id=nid,
            kind="domain",
            name=d,
            path="",
            domain=d,
            parent_id=parent_id,
            status=resolve_node_status("", project_path),
            meta={},
        )
    return nid


def build_manifest_graph(
    project_path: Path,
    manifest_data: dict | None = None,
    contracts: dict[str, list[Any]] | None = None,
    include_discovered: bool = False,
) -> ManifestGraph:
    root = project_path.resolve()
    raw: dict[str, Any] = {}
    source = ""
    doc: ManifestDocument | None = None
    doc_layers: list[LayerSlice] = []

    if manifest_data is not None:
        raw = dict(manifest_data)
        source = "inline"
        doc_layers = layers_from_manifest_dict(raw)
    else:
        try:
            doc = ManifestDocument.from_path(root)
            raw = _doc_projection_for_graph(doc)
            source = str(doc.path)
            doc_layers = list(doc.layers)
        except (FileNotFoundError, ValueError):
            # Compatibility fallback for lightweight/legacy manifests used by
            # tests and bootstrap flows that do not satisfy full parser fields.
            mp = resolve_manifest_path(root, warn_on_root_fallback=False)
            if mp is not None and mp.is_file():
                try:
                    parsed = yaml.safe_load(mp.read_text(encoding="utf-8")) or {}
                    if isinstance(parsed, dict):
                        raw = dict(parsed)
                        source = str(mp)
                except Exception:
                    pass

    if raw:
        raw = normalize_legacy_manifest(raw)

    m = normalize_manifest(raw) if raw else {}
    nodes: dict[str, ManifestNode] = {}
    edges: list[ManifestEdge] = []

    _add_layer_slice_nodes(nodes, doc_layers, project_path)

    # Feature / sub-manifest stubs (Ring 3 hook)
    for idx, sm in enumerate(m.get("sub_manifests") or []):
        if not isinstance(sm, dict):
            continue
        fname = str(sm.get("name") or sm.get("id") or f"feature_{idx}")
        fid = f"feature/{_slug(fname)}"
        if fid not in nodes:
            nodes[fid] = ManifestNode(
                id=fid,
                kind="feature",
                name=fname,
                path=str(sm.get("path") or ""),
                domain=None,
                parent_id=None,
                status=resolve_node_status(str(sm.get("path") or ""), project_path),
                meta=dict(sm),
            )

    # Domain buckets
    for bucket in ("screens", "controllers", "services"):
        for row in m.get(bucket) or []:
            if not isinstance(row, dict):
                continue
            dom = row.get("domain")
            if isinstance(dom, str) and dom.strip():
                _ensure_domain_node(nodes, edges, dom, project_path)

    def add_screen(row: dict[str, Any]) -> None:
        name = str(row.get("name") or row.get("id") or "screen")
        sid = f"screen/{_slug(name)}"
        fp = str(row.get("path") or row.get("file") or "")
        dom_s = row.get("domain")
        domain = dom_s.strip().upper() if isinstance(dom_s, str) and dom_s.strip() else None
        watches = _screen_watch_names(row)
        nodes[sid] = ManifestNode(
            id=sid,
            kind="screen",
            name=name,
            path=_norm_rel_path(fp) if fp else "",
            domain=domain,
            parent_id=None,
            status=resolve_node_status(_norm_rel_path(fp) if fp else "", project_path),
            meta={"watched_controllers": watches, "raw_keys": list(row.keys())},
        )
        for w in watches:
            tid = f"controller/{_slug(w)}"
            edges.append(ManifestEdge(from_id=sid, to_id=tid, relation="watches", derived=False))
        if domain:
            did = _ensure_domain_node(nodes, edges, domain, project_path)
            if did:
                edges.append(ManifestEdge(from_id=sid, to_id=did, relation="belongs_to", derived=False))

    def add_controller_node(row: dict[str, Any]) -> None:
        name = str(row.get("name") or row.get("id") or "controller")
        cid = f"controller/{_slug(name)}"
        fp = str(row.get("path") or row.get("file") or "")
        dom_s = row.get("domain")
        domain = dom_s.strip().upper() if isinstance(dom_s, str) and dom_s.strip() else None
        read_targets = _controller_read_targets(row)
        nodes[cid] = ManifestNode(
            id=cid,
            kind="controller",
            name=name,
            path=_norm_rel_path(fp) if fp else "",
            domain=domain,
            parent_id=None,
            status=resolve_node_status(_norm_rel_path(fp) if fp else "", project_path),
            meta={"read_targets": read_targets, "raw_keys": list(row.keys())},
        )

    def add_service(row: dict[str, Any]) -> None:
        name = str(row.get("name") or row.get("id") or "service")
        sid = f"service/{_slug(name)}"
        fp = str(row.get("path") or row.get("file") or "")
        dom_s = row.get("domain")
        domain = dom_s.strip().upper() if isinstance(dom_s, str) and dom_s.strip() else None
        svc_meta: dict[str, Any] = {}
        sd = row.get("schema_deps")
        if sd is not None:
            svc_meta["schema_deps"] = sd
        nodes[sid] = ManifestNode(
            id=sid,
            kind="service",
            name=name,
            path=_norm_rel_path(fp) if fp else "",
            domain=domain,
            parent_id=None,
            status=resolve_node_status(_norm_rel_path(fp) if fp else "", project_path),
            meta=svc_meta,
        )
        if domain:
            did = _ensure_domain_node(nodes, edges, domain, project_path)
            if did:
                edges.append(ManifestEdge(from_id=sid, to_id=did, relation="belongs_to", derived=False))

    service_name_set: set[str] = set()
    for row in m.get("services") or []:
        if isinstance(row, dict):
            nm = str(row.get("name") or row.get("id") or "")
            if nm:
                service_name_set.add(nm)
            add_service(row)

    ctrl_rows = [r for r in (m.get("controllers") or []) if isinstance(r, dict)]
    for row in ctrl_rows:
        add_controller_node(row)

    for row in m.get("screens") or []:
        if isinstance(row, dict):
            add_screen(row)

    for row in ctrl_rows:
        name = str(row.get("name") or row.get("id") or "controller")
        cid = f"controller/{_slug(name)}"
        if cid not in nodes:
            continue
        domain = nodes[cid].domain
        for tgt in _controller_read_targets(row):
            tid_svc = f"service/{_slug(tgt)}"
            if tid_svc in nodes or tgt in service_name_set:
                edges.append(ManifestEdge(from_id=cid, to_id=tid_svc, relation="reads", derived=False))
            else:
                edges.append(
                    ManifestEdge(
                        from_id=cid,
                        to_id=f"controller/{_slug(tgt)}",
                        relation="depends_on",
                        derived=False,
                    )
                )
        for ref in _parse_name_list(row.get("writes")):
            edges.append(
                ManifestEdge(
                    from_id=cid,
                    to_id=f"state/{_slug(ref)}",
                    relation="writes",
                    derived=False,
                )
            )
        for ref in _parse_name_list(row.get("fires")):
            edges.append(
                ManifestEdge(
                    from_id=cid,
                    to_id=f"event/{_slug(ref)}",
                    relation="fires",
                    derived=False,
                )
            )
        if domain:
            did = _ensure_domain_node(nodes, edges, domain, project_path)
            if did:
                edges.append(ManifestEdge(from_id=cid, to_id=did, relation="belongs_to", derived=False))

    # Format B Python manifests: modules: list → module nodes + domain-level belongs_to edges.
    # Domain inferred from name prefix by normalize_manifest() (e.g. "core.manifest" → CORE).
    # One belongs_to edge per module→domain: no cartesian product — domain-level only.
    for row in m.get("modules") or []:
        if not isinstance(row, dict):
            continue
        decl_id = str(row.get("id") or "").strip()
        name = str(row.get("name") or row.get("id") or "module")
        node_kind = str(row.get("kind") or "module").strip() or "module"
        if decl_id and "/" in decl_id:
            mid = decl_id
        elif node_kind == "domain":
            mid = f"domain/{_slug(name)}"
        else:
            mid = f"module/{_slug(name)}"
        fp = str(row.get("path") or "")
        dom_s = row.get("domain")
        domain = dom_s.strip().upper() if isinstance(dom_s, str) and dom_s.strip() else None
        tier_raw = row.get("tier")
        tier_s = (
            str(tier_raw).strip().lower()
            if tier_raw not in (None, "")
            else infer_tier(mid, node_kind).value
        )
        nodes[mid] = ManifestNode(
            id=mid,
            kind=node_kind,
            name=name,
            path=_norm_rel_path(fp) if fp else "",
            domain=domain,
            parent_id=None,
            status=resolve_node_status(_norm_rel_path(fp) if fp else "", project_path),
            meta={
                "role": str(row.get("role") or ""),
                "owns": row.get("owns") or [],
                "parity_source": str(row.get("parity_source") or "").strip() or None,
                "raw_keys": list(row.keys()),
                "tier": tier_s,
            },
        )
        if domain and node_kind != "domain":
            did = _ensure_domain_node(nodes, edges, domain, project_path)
            if did:
                edges.append(ManifestEdge(from_id=mid, to_id=did, relation="belongs_to", derived=False))

    # Second pass: module depends_on → imports edges.
    # Reads each module's depends_on list and creates relation="imports" edges
    # between module nodes. Only wires edges where both endpoints exist in the
    # node set — unknown deps are skipped silently (they may live in an unscanned
    # subtree). This pass must run after all module nodes are created above.
    for row in m.get("modules") or []:
        if not isinstance(row, dict):
            continue
        decl_id = str(row.get("id") or "").strip()
        name = str(row.get("name") or row.get("id") or "module")
        node_kind = str(row.get("kind") or "module").strip() or "module"
        if decl_id and "/" in decl_id:
            from_id = decl_id
        elif node_kind == "domain":
            from_id = f"domain/{_slug(name)}"
        else:
            from_id = f"module/{_slug(name)}"
        if from_id not in nodes:
            continue
        raw_deps = row.get("depends_on") or []
        if isinstance(raw_deps, str):
            raw_deps = [raw_deps] if raw_deps.strip() else []
        for dep in raw_deps:
            dep_name = str(dep).strip()
            if not dep_name:
                continue
            if dep_name in nodes:
                to_id = dep_name
            elif "/" in dep_name:
                to_id = dep_name
            else:
                to_id = f"module/{_slug(dep_name)}"
            if to_id not in nodes:
                continue  # dep not in manifest node set — skip silently
            edges.append(ManifestEdge(from_id=from_id, to_id=to_id, relation="imports", derived=False))

        # Parse must_not_use edges
        raw_exclusions = row.get("must_not_use") or []
        if isinstance(raw_exclusions, str):
            raw_exclusions = [raw_exclusions] if raw_exclusions.strip() else []
        for exclusion in raw_exclusions:
            exclusion_name = str(exclusion).strip()
            if not exclusion_name:
                continue
            if exclusion_name in nodes:
                to_id = exclusion_name
            elif "/" in exclusion_name:
                to_id = exclusion_name
            else:
                to_id = f"module/{_slug(exclusion_name)}"
            if to_id not in nodes:
                continue  # exclusion target not in manifest node set — skip silently
            edges.append(ManifestEdge(from_id=from_id, to_id=to_id, relation="must_not_use", derived=False))

    # Declarative explicit edges (supports ADR-017 parity edges).
    raw_edges = _edge_rows_from_doc_projection(doc, m)
    for row in raw_edges:
        source_ref = str(row.get("from") or row.get("from_id") or "").strip()
        target_ref = str(row.get("to") or row.get("to_id") or "").strip()
        relation = str(row.get("edge_kind") or row.get("relation") or "").strip()
        if not source_ref or not target_ref or not relation:
            continue

        def _resolve_ref(ref: str) -> str:
            if ref in nodes:
                return ref
            if "/" in ref:
                prefix, tail = ref.split("/", 1)
                prefix = prefix.strip().lower()
                tail = tail.strip()
                if prefix and tail:
                    typed = f"{prefix}/{_slug(tail)}"
                    if typed in nodes:
                        return typed
            module_like = f"module/{_slug(ref)}"
            if module_like in nodes:
                return module_like
            return ref

        from_id = _resolve_ref(source_ref)
        to_id = _resolve_ref(target_ref)
        edge_meta = {
            "symmetric": bool(row.get("symmetric", False)),
            "staleness_check": bool(row.get("staleness_check", True)),
            "note": str(row.get("note") or "").strip() or None,
        }
        edges.append(ManifestEdge(from_id=from_id, to_id=to_id, relation=relation, derived=False, meta=edge_meta))
        if edge_meta["symmetric"]:
            edges.append(ManifestEdge(from_id=to_id, to_id=from_id, relation=relation, derived=False, meta=edge_meta))

    # Derived: screens sharing watches
    screen_nodes = [n for n in nodes.values() if n.kind == "screen"]
    for i, a in enumerate(screen_nodes):
        wa = frozenset((a.meta or {}).get("watched_controllers") or [])
        if not wa:
            continue
        for b in screen_nodes[i + 1 :]:
            wb = frozenset((b.meta or {}).get("watched_controllers") or [])
            if wa == wb:
                edges.append(ManifestEdge(from_id=a.id, to_id=b.id, relation=DERIVED_PEER_RELATION, derived=True))

    # Derived: controllers sharing a service read target
    ctrl_nodes = [n for n in nodes.values() if n.kind == "controller"]
    service_to_ctrls: dict[str, list[str]] = defaultdict(list)
    for n in ctrl_nodes:
        for t in (n.meta or {}).get("read_targets") or []:
            tid_svc = f"service/{_slug(str(t))}"
            if tid_svc in nodes:
                service_to_ctrls[tid_svc].append(n.id)
    for _svc, ids in service_to_ctrls.items():
        ids_u = sorted(set(ids))
        for i, a in enumerate(ids_u):
            for b in ids_u[i + 1 :]:
                edges.append(ManifestEdge(from_id=a, to_id=b, relation=DERIVED_PEER_RELATION, derived=True))

    # Derived: screens same domain
    dom_screens: dict[str, list[ManifestNode]] = defaultdict(list)
    for n in screen_nodes:
        if n.domain:
            dom_screens[n.domain].append(n)
    for _d, group in dom_screens.items():
        for i, a in enumerate(group):
            for b in group[i + 1 :]:
                edges.append(ManifestEdge(from_id=a.id, to_id=b.id, relation=DERIVED_PEER_RELATION, derived=True))

    g = ManifestGraph(
        project_path=root,
        nodes=sorted(nodes.values(), key=lambda x: x.id),
        edges=edges,
        source=source,
    )
    _materialise_contract_edges(g, contracts or {})
    # Intent soft edges (non-binding): extracted_nodes -> inferred edges.
    try:
        from forge.tools.intent.runtime import load_intent_records

        node_ids = {n.id for n in g.nodes}
        for rec in load_intent_records(root):
            target_id = (rec.target_id or "").strip()
            hints = [str(x) for x in rec.extracted_nodes if str(x).strip()]
            if not target_id or target_id not in node_ids:
                continue
            for hint in hints:
                if hint not in node_ids:
                    continue
                g.edges.append(
                    ManifestEdge(
                        from_id=target_id,
                        to_id=hint,
                        relation="inferred",
                        derived=True,
                        meta={"edge_kind": "inferred", "source": "intent", "intent_id": rec.id},
                    )
                )
    except Exception:
        pass
    # Add discovered modules if requested (foundation auto-discovery)
    if include_discovered:
        try:
            from forge.core.module_discovery import ModuleDiscovery
            discovery = ModuleDiscovery(root)
            discovered_modules = discovery.find_untracked_modules(m)
            
            # Add discovered modules as nodes with special metadata
            for module in discovered_modules:
                if module.kind not in {"test", "schema"}:  # Skip tests and schemas by default
                    mid = f"{module.kind}/{module.name}"
                    if mid not in nodes:  # Avoid duplicates
                        nodes[mid] = ManifestNode(
                            id=mid,
                            kind=module.kind,
                            name=module.name,
                            path=str(module.path),
                            domain=module.domain,
                            parent_id=None,
                            status="drifted",
                            meta={
                                "discovered": True,
                                "auto_generated": True,
                                "untracked": True,
                            },
                        )
                        
                        # Add domain relationship if domain is known
                        if module.domain:
                            did = _ensure_domain_node(nodes, edges, module.domain, project_path)
                            if did:
                                edges.append(ManifestEdge(from_id=mid, to_id=did, relation="belongs_to", derived=True, meta={"source": "auto_discovery"}))
        except Exception:
            # Fail silently - discovery is optional enhancement
            pass
    
    g.edges = _dedupe_manifest_edges(g.edges)
    
    # Populate fqid for all nodes
    project_name = project_path.name
    for node in g.nodes:
        if not node.fqid:
            node.fqid = f"{project_name}:{node.id}"
    
    return g


def _materialise_contract_edges(graph: ManifestGraph, contracts: dict[str, list[Any]]) -> None:
    if not contracts:
        return
    existing = {(e.from_id, e.to_id, e.relation, str((e.meta or {}).get("method") or "")) for e in graph.edges}
    appended: list[ManifestEdge] = []
    for edge in list(graph.edges):
        if edge.relation not in {"calls", "queries"}:
            continue
        caller = str(edge.from_id)
        callee = str(edge.to_id)
        caller_contracts = contracts.get(caller) or []
        callee_by_method = {str(getattr(c, "method", "") or ""): c for c in (contracts.get(callee) or [])}
        for cc in caller_contracts:
            method = str(getattr(cc, "method", "") or "")
            if not method or method not in callee_by_method:
                continue
            callee_c = callee_by_method[method]
            ret_a = str(getattr(cc, "returns", None) or "unknown")
            ret_b = str(getattr(callee_c, "returns", None) or "unknown")
            cc_params = [f"{getattr(p, 'name', '')}:{getattr(p, 'type', None) or 'unknown'}" for p in getattr(cc, "params", [])]
            callee_params = [f"{getattr(p, 'name', '')}:{getattr(p, 'type', None) or 'unknown'}" for p in getattr(callee_c, "params", [])]
            verified = (ret_a == ret_b) or (ret_a == "unknown") or (ret_b == "unknown")
            key = (caller, callee, "contract", method)
            if key in existing:
                continue
            existing.add(key)
            async_boundary = bool(getattr(cc, "async_boundary", False) or getattr(callee_c, "async_boundary", False))
            appended.append(
                ManifestEdge(
                    from_id=caller,
                    to_id=callee,
                    relation="contract",
                    derived=False,
                    meta={
                        "edge_kind": "contract",
                        "method": method,
                        "contract_id": f"{callee}.{method}",
                        "verified": bool(verified),
                        "async_boundary": async_boundary,
                        "boundary_kind": "async" if async_boundary else "sync",
                        "type_annotations": {
                            "caller_params": cc_params,
                            "callee_params": callee_params,
                            "caller_return": ret_a,
                            "callee_return": ret_b,
                        },
                    },
                )
            )
    graph.edges.extend(appended)


def manifest_graph_to_jsonable(graph: ManifestGraph, *, scope: str | None = None) -> dict[str, Any]:
    """Serialize graph for MCP / APIs; optional scope filters by domain or feature id substring."""

    nodes = graph.nodes
    if scope:
        s = scope.strip().upper()
        nodes = [
            n
            for n in graph.nodes
            if (n.domain or "").upper() == s or s.lower() in n.id.lower() or s.lower() in n.name.lower()
        ]
        ids = {n.id for n in nodes}
        edges = [e for e in graph.edges if e.from_id in ids and e.to_id in ids]
    else:
        edges = list(graph.edges)

    return {
        "graph_schema_version": 1,
        "project_path": str(graph.project_path),
        "source": graph.source,
        "nodes": [asdict(n) for n in nodes],
        "edges": [asdict(e) for e in edges],
    }


def filter_graph_for_scope(graph: ManifestGraph, scope: str | None) -> ManifestGraph:
    if not scope:
        return graph
    s = scope.strip().upper()
    nodes = [
        n
        for n in graph.nodes
        if (n.domain or "").upper() == s or s.lower() in n.id.lower() or s.lower() in n.name.lower()
    ]
    ids = {n.id for n in nodes}
    edges = [e for e in graph.edges if e.from_id in ids and e.to_id in ids]
    return ManifestGraph(project_path=graph.project_path, nodes=nodes, edges=edges, source=graph.source)


def resolve_manifest_node(graph: ManifestGraph, ref: str) -> ManifestNode | None:
    """Resolve a CLI reference to a graph node.

    Accepts full node id (e.g. ``module/commands.map``), module shorthand
    (``commands.map`` → ``module/commands.map``), id suffix tokens (unique), or display ``name``
    **only when exactly one node** shares that ``name``.
    """
    token = ref.strip()
    if not token:
        return None
    by_id = {n.id: n for n in graph.nodes}
    if token in by_id:
        return by_id[token]
    if "/" not in token:
        mid = f"module/{token}"
        if mid in by_id:
            return by_id[mid]
    tl = token.lower()
    for n in graph.nodes:
        nid = n.id.lower()
        if nid == tl or nid.endswith("/" + tl):
            return n
    name_hits = [n for n in graph.nodes if n.name == token]
    if len(name_hits) == 1:
        return name_hits[0]
    return None


def find_node_id_for_path(graph: ManifestGraph, rel_path: str) -> str | None:
    target = _norm_rel_path(rel_path)
    exact: ManifestNode | None = None
    scored: list[tuple[int, ManifestNode]] = []
    for n in graph.nodes:
        if not n.path:
            continue
        np = _norm_rel_path(n.path)
        if np == target:
            exact = n
            break
        if target.endswith(np) or np.endswith(target):
            scored.append((len(np), n))
    if exact:
        return exact.id
    if scored:
        scored.sort(key=lambda t: t[0], reverse=True)
        return scored[0][1].id
    return None


def aggregate_ring2_for_files(
    graph: ManifestGraph,
    changed_files: list[str],
) -> dict[str, Any]:
    direct: list[str] = []
    watchers: list[str] = []
    dependents: list[str] = []
    siblings: list[str] = []
    reason: dict[str, str] = {}

    seen_w: set[str] = set()
    seen_d: set[str] = set()
    seen_s: set[str] = set()

    for cf in changed_files:
        rel = _norm_rel_path(cf)
        nid = find_node_id_for_path(graph, rel)
        if not nid:
            continue
        n = next((x for x in graph.nodes if x.id == nid), None)
        if n:
            direct.append(n.name)
        br = graph.blast_radius_ring2(nid, change_kind="any")
        for w in br["watchers"]:
            if w.name not in seen_w:
                seen_w.add(w.name)
                watchers.append(w.name)
                reason[w.name] = br["reason"].get(w.id, "Ring2 watcher")
        for d in br["dependents"]:
            if d.name not in seen_d:
                seen_d.add(d.name)
                dependents.append(d.name)
                reason[d.name] = br["reason"].get(d.id, "Ring2 dependent")
        for s in br["siblings"]:
            if s.name not in seen_s:
                seen_s.add(s.name)
                siblings.append(s.name)
                reason[s.name] = br["reason"].get(s.id, "Ring2 sibling")

    return {
        "direct": sorted(set(direct)),
        "watchers": watchers,
        "dependents": dependents,
        "siblings": siblings,
        "reason": reason,
    }


# ── Phase 3 — Persistence ─────────────────────────────────────────────────────
# built_at is stored in metadata ONLY — not inside graph content.
# Graph content (nodes + edges + source) must be deterministic across runs.
# built_at feeds scan_age_days in the context spine.


def save_graph(
    graph: ManifestGraph,
    *,
    cache_path: Path | None = None,
    built_at: datetime | None = None,
) -> Path:
    """Persist graph to JSON cache. Returns the path written to.

    Structure:
      {
        "metadata": {"built_at": "<ISO-UTC>"},
        "graph": {nodes, edges, source, project_path}
      }

    built_at is NOT embedded in graph content — graph content is deterministic.
    """
    if cache_path is None:
        cache_path = graph.project_path / _GRAPH_CACHE_FILENAME
    ts = (built_at or datetime.now(tz=timezone.utc)).isoformat()
    payload = {
        "metadata": {"built_at": ts},
        "graph": manifest_graph_to_jsonable(graph),
    }
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    # Atomic write — temp file + replace
    import os
    import tempfile

    fd, tmp = tempfile.mkstemp(prefix=".manifest_graph.", dir=str(cache_path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        os.replace(tmp, cache_path)
    except Exception:
        try:
            Path(tmp).unlink(missing_ok=True)
        except Exception:
            pass
        raise
    return cache_path


def load_graph(
    project_path: Path,
    *,
    cache_path: Path | None = None,
) -> tuple[ManifestGraph | None, datetime | None]:
    """Load graph from JSON cache. Returns (graph, built_at) or (None, None) on miss/error."""
    if cache_path is None:
        cache_path = project_path / _GRAPH_CACHE_FILENAME
    if not cache_path.exists():
        return None, None
    try:
        raw = json.loads(cache_path.read_text(encoding="utf-8"))
    except Exception:
        return None, None
    meta = raw.get("metadata") or {}
    built_at: datetime | None = None
    ts_str = meta.get("built_at")
    if ts_str:
        try:
            built_at = datetime.fromisoformat(ts_str)
        except Exception:
            pass
    g_raw = raw.get("graph") or {}
    try:
        nodes = [
            ManifestNode(**{k: v for k, v in n.items() if k in ManifestNode.__dataclass_fields__})
            for n in (g_raw.get("nodes") or [])
        ]
        edges = [
            ManifestEdge(**{k: v for k, v in e.items() if k in ManifestEdge.__dataclass_fields__})
            for e in (g_raw.get("edges") or [])
        ]
        graph = ManifestGraph(
            project_path=project_path.resolve(),
            nodes=nodes,
            edges=edges,
            source=str(g_raw.get("source") or "cache"),
        )
        return graph, built_at
    except Exception:
        return None, None


def graph_scan_age_days(
    project_path: Path,
    *,
    cache_path: Path | None = None,
) -> float | None:
    """Return decimal days since the graph was built, or None if no cache.
    Feeds scan_age_days in the context spine."""
    _, built_at = load_graph(project_path, cache_path=cache_path)
    if built_at is None:
        return None
    now = datetime.now(tz=timezone.utc)
    if built_at.tzinfo is None:
        built_at = built_at.replace(tzinfo=timezone.utc)
    delta = now - built_at
    return delta.total_seconds() / 86400.0


def _inbound_import_count(g: ManifestGraph, node_id: str) -> int:
    return sum(1 for e in g.edges_to(node_id) if e.relation == "imports")


def _manifest_graph_query_on_graph(
    g: ManifestGraph,
    *,
    kind_filter: str = "",
    domain_filter: str = "",
    name_filter: str = "",
    dep_filter: str = "",
    limit: int = 50,
    depth: int = 1,
    direction: str = "both",
    sort_by: str | None = None,
) -> dict[str, Any]:
    """Filter nodes and optionally expand along ``imports`` edges (BFS). MCP / mechanical menus."""
    kind_f = kind_filter.lower()
    domain_f = domain_filter.lower()
    name_f = name_filter.lower()
    dep_f = dep_filter.lower()
    dep_f_slug = dep_f.replace(".", "_")
    lim = max(1, int(limit))
    dep = max(1, min(3, int(depth)))
    direc = direction.lower() if direction.lower() in ("in", "out", "both") else "both"

    imports_in: dict[str, set[str]] = {}
    imports_out: dict[str, set[str]] = {}
    for e in g.edges:
        if e.relation != "imports":
            continue
        imports_in.setdefault(e.to_id, set()).add(e.from_id)
        imports_out.setdefault(e.from_id, set()).add(e.to_id)

    node_by_id = {n.id: n for n in g.nodes}

    def _node_dict(node: ManifestNode, hop: int) -> dict[str, Any]:
        out_edges = [{"to": e.to_id, "relation": e.relation} for e in g.edges_from(node.id)]
        in_edges = [{"from": e.from_id, "relation": e.relation} for e in g.edges_to(node.id)]
        return {
            "id": node.id,
            "name": node.name,
            "kind": node.kind,
            "domain": node.domain,
            "path": node.path,
            "tier": effective_node_tier(node),
            "out": out_edges,
            "in": in_edges,
            "hop": hop,
        }

    results: list[dict[str, Any]] = []
    seen: set[str] = set()

    for node in g.nodes:
        if kind_f and (node.kind or "").lower() != kind_f:
            continue
        if domain_f and domain_f not in (node.domain or "").lower():
            continue
        if name_f and name_f not in (node.name or "").lower():
            continue
        if dep_f:
            outgoing = [
                e
                for e in g.edges_from(node.id)
                if dep_f in e.to_id.lower() or dep_f_slug in e.to_id.lower()
            ]
            if not outgoing:
                continue
        if node.id in seen:
            continue
        seen.add(node.id)
        results.append(_node_dict(node, hop=0))

    frontier: set[str] = set(seen)

    for hop in range(1, dep):
        candidates: set[str] = set()
        for nid in frontier:
            if direc in ("in", "both"):
                candidates.update(c for c in imports_in.get(nid, set()) if c not in seen)
            if direc in ("out", "both"):
                candidates.update(c for c in imports_out.get(nid, set()) if c not in seen)

        if not candidates:
            break

        for nid in sorted(candidates):
            node = node_by_id.get(nid)
            if node is None:
                continue
            seen.add(nid)
            results.append(_node_dict(node, hop=hop))

        frontier = candidates

    sb = (sort_by or "").strip().lower()
    if sb == "criticality":
        results.sort(key=lambda r: _inbound_import_count(g, str(r.get("id") or "")), reverse=True)
    elif sb == "name":
        results.sort(key=lambda r: str(r.get("name") or "").lower())
    elif sb == "domain":
        results.sort(key=lambda r: (str(r.get("domain") or "").upper(), str(r.get("name") or "").lower()))

    results = results[:lim]

    return {
        "count": len(results),
        "nodes": results,
        "filters": {
            "kind": kind_f or None,
            "domain": domain_f or None,
            "name": name_f or None,
            "depends_on": dep_f or None,
            "depth": dep,
            "direction": direc,
            "sort_by": sb or None,
        },
    }


def run_manifest_graph_query(
    project_root: Path,
    *,
    kind_filter: str = "",
    domain_filter: str = "",
    name_filter: str = "",
    dep_filter: str = "",
    limit: int = 50,
    depth: int = 1,
    direction: str = "both",
) -> dict[str, Any]:
    """Build graph from disk, then delegate to ``forge.core.query.forge_query``."""
    from forge.core.query import forge_query

    root = project_root.expanduser().resolve()
    g = build_manifest_graph(root)
    return forge_query(
        g,
        kind=kind_filter,
        where={
            "domain": domain_filter,
            "name": name_filter,
            "depends_on": dep_filter,
        },
        reverse_of=None,
        limit=limit,
        depth=depth,
        direction=direction,
    ).as_dict()


def run_manifest_graph_query_on_graph(
    g: ManifestGraph,
    *,
    kind_filter: str = "",
    domain_filter: str = "",
    name_filter: str = "",
    dep_filter: str = "",
    limit: int = 50,
    depth: int = 1,
    direction: str = "both",
    sort_by: str | None = None,
) -> dict[str, Any]:
    """Same as ``run_manifest_graph_query`` but uses an existing graph (tests)."""
    return _manifest_graph_query_on_graph(
        g,
        kind_filter=kind_filter,
        domain_filter=domain_filter,
        name_filter=name_filter,
        dep_filter=dep_filter,
        limit=limit,
        depth=depth,
        direction=direction,
        sort_by=sort_by,
    )
