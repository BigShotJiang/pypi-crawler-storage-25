# Tests for forge.tools.manifest
