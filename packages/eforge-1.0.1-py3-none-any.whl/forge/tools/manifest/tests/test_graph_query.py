from __future__ import annotations

from pathlib import Path

from forge.tools.manifest.graph import (
    build_manifest_graph,
    run_manifest_graph_query_on_graph,
)
from forge.tools.manifest.tests.test_graph import _sample_manifest


def test_graph_query_depth_one_screen_filter() -> None:
    g = build_manifest_graph(Path("."), manifest_data=_sample_manifest())
    out = run_manifest_graph_query_on_graph(g, kind_filter="screen", limit=20, depth=1)
    assert out["count"] == 2
    assert all(n["kind"] == "screen" for n in out["nodes"])
    assert all(n["hop"] == 0 for n in out["nodes"])


def test_graph_query_depth_two_imports_out() -> None:
    g = build_manifest_graph(Path("."), manifest_data=_sample_manifest())
    out = run_manifest_graph_query_on_graph(
        g,
        name_filter="home",
        kind_filter="screen",
        depth=2,
        direction="out",
        limit=20,
    )
    hops = {n["hop"] for n in out["nodes"]}
    assert 0 in hops
    assert len(out["nodes"]) >= 1
