from __future__ import annotations

from pathlib import Path

from forge.tools.manifest.graph import (
    DERIVED_PEER_RELATION,
    build_manifest_graph,
    resolve_manifest_node,
)


def _sample_manifest() -> dict:
    return {
        "name": "demo",
        "type": "flutter",
        "screens": [
            {
                "name": "home",
                "path": "lib/home.dart",
                "watches": ["HomeController"],
                "domain": "CORE",
            },
            {
                "name": "profile",
                "path": "lib/profile.dart",
                "watches": ["HomeController"],
                "domain": "CORE",
            },
        ],
        "controllers": [
            {
                "name": "HomeController",
                "domain": "AUTH",
                "path": "lib/home_controller.dart",
                "depends_on": ["ApiService"],
            },
            {
                "name": "OtherController",
                "domain": "AUTH",
                "path": "lib/other_controller.dart",
                "depends_on": ["ApiService"],
            },
        ],
        "services": [
            {"name": "ApiService", "domain": "REMOTE", "path": "lib/api.dart"},
        ],
    }


def test_build_graph_from_manifest(tmp_path: Path) -> None:
    g = build_manifest_graph(tmp_path, manifest_data=_sample_manifest())
    kinds = {n.kind for n in g.nodes}
    assert "screen" in kinds and "controller" in kinds and "service" in kinds
    watches = [e for e in g.edges if e.relation == "watches"]
    assert len(watches) >= 2


def test_find_watchers() -> None:
    g = build_manifest_graph(Path("."), manifest_data=_sample_manifest())
    w = g.find_watchers("HomeController")
    names = {x.name for x in w}
    assert names == {"home", "profile"}


def test_find_dependents() -> None:
    g = build_manifest_graph(Path("."), manifest_data=_sample_manifest())
    d = g.find_dependents("ApiService")
    names = {x.name for x in d}
    assert names == {"HomeController", "OtherController"}


def test_find_siblings_shared_controller() -> None:
    g = build_manifest_graph(Path("."), manifest_data=_sample_manifest())
    sid = next(n.id for n in g.nodes if n.name == "home")
    sibs = g.find_siblings(sid)
    assert {x.name for x in sibs} >= {"profile"}


def test_find_siblings_shared_domain() -> None:
    g = build_manifest_graph(Path("."), manifest_data=_sample_manifest())
    cid = next(n.id for n in g.nodes if n.name == "HomeController")
    sibs = g.find_siblings(cid)
    assert {x.name for x in sibs} >= {"OtherController"}


def test_find_domain_members() -> None:
    g = build_manifest_graph(Path("."), manifest_data=_sample_manifest())
    m = g.find_domain_members("AUTH")
    assert {x.name for x in m} >= {"HomeController", "OtherController"}


def test_blast_radius_interface_change() -> None:
    g = build_manifest_graph(Path("."), manifest_data=_sample_manifest())
    cid = next(n.id for n in g.nodes if n.name == "HomeController")
    br = g.blast_radius_ring2(cid, change_kind="interface_change")
    assert {x.name for x in br["watchers"]} == {"home", "profile"}


def test_blast_radius_service_change() -> None:
    g = build_manifest_graph(Path("."), manifest_data=_sample_manifest())
    sid = next(n.id for n in g.nodes if n.name == "ApiService")
    br = g.blast_radius_ring2(sid, change_kind="reads_change")
    assert {x.name for x in br["dependents"]} == {"HomeController", "OtherController"}


def test_derived_edges_marked_correctly() -> None:
    g = build_manifest_graph(Path("."), manifest_data=_sample_manifest())
    derived = [e for e in g.edges if e.derived]
    assert derived
    assert all(e.derived for e in derived)
    assert any(e.relation == DERIVED_PEER_RELATION for e in derived)


def test_explicit_edges_not_derived() -> None:
    g = build_manifest_graph(Path("."), manifest_data=_sample_manifest())
    watches_e = [e for e in g.edges if e.relation == "watches"]
    assert watches_e
    assert all(not e.derived for e in watches_e)


def test_node_id_format() -> None:
    """UNSTABLE until Gate 5 — id scheme may change."""
    g = build_manifest_graph(Path("."), manifest_data=_sample_manifest())
    ids = {n.id for n in g.nodes}
    assert "screen/home" in ids


def test_resolve_manifest_node_modules(tmp_path: Path) -> None:
    data = {
        "name": "demo",
        "type": "python",
        "modules": [
            {"name": "commands.map", "path": "forge/commands/map_cmd.py", "role": "map"},
        ],
    }
    g = build_manifest_graph(tmp_path, manifest_data=data)
    a = resolve_manifest_node(g, "commands.map")
    b = resolve_manifest_node(g, "module/commands.map")
    assert a is not None and b is not None
    assert a.id == "module/commands.map"
    assert a == b
    assert a.path == "forge/commands/map_cmd.py"


def test_resolve_manifest_node_unknown(tmp_path: Path) -> None:
    g = build_manifest_graph(tmp_path, manifest_data=_sample_manifest())
    assert resolve_manifest_node(g, "totally_missing") is None
