"""
forge/tools/manifest/context_generator.py

Phase 8 — Deterministic AGENT_CONTEXT.md generator.

Produces docs/AGENT_CONTEXT.md as a 2D indexed cache [scope:X][section:Y].
Must be pure + deterministic: same graph + same rules = identical output.

Separation rule (enforced here, not negotiated):
  INCLUDE: graph topology, rules, known_broken (stable), constraints, ADR refs
  EXCLUDE: timestamps, scan_age_days, drift_counts, session data, run metadata

Usage:
    from forge.tools.manifest.context_generator import generate_agent_context
    content = generate_agent_context(project_path)
    (project_path / "docs" / "AGENT_CONTEXT.md").write_text(content)
"""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

import yaml

from forge.core.manifest_document import ManifestDocument
from forge.tools.manifest.graph import ManifestGraph, ManifestNode, build_manifest_graph
from forge.tools.manifest.propagation import load_rules


# ── Loaders ───────────────────────────────────────────────────────────────────

def _load_manifest(project_path: Path) -> dict[str, Any]:
    root = project_path.expanduser().resolve()
    try:
        doc = ManifestDocument.from_path(root)
        return dict(doc.to_legacy_dict())
    except (FileNotFoundError, ValueError):
        return {}


def _load_adr_registry(project_path: Path) -> list[dict[str, Any]]:
    for p in (
        project_path / "docs" / "adr" / "adr_registry.yaml",
        project_path / "docs" / "adr_registry.yaml",
    ):
        if p.is_file():
            try:
                data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
                return list(data.get("adrs") or []) if isinstance(data, dict) else []
            except Exception:
                return []
    return []


def _load_agent_notes(project_path: Path) -> str:
    """Load docs/AGENT_NOTES.md content. Returns '' if absent."""
    p = project_path / "docs" / "AGENT_NOTES.md"
    if p.is_file():
        try:
            return p.read_text(encoding="utf-8").strip()
        except Exception:
            return ""
    return ""


# ── Graph helpers ─────────────────────────────────────────────────────────────

def _domain_summary(graph: ManifestGraph) -> dict[str, list[str]]:
    """Returns {domain: [node_ids]} for non-domain nodes."""
    result: dict[str, list[str]] = defaultdict(list)
    for n in sorted(graph.nodes, key=lambda x: x.id):
        if n.kind == "domain":
            continue
        result[n.domain or "(unclassified)"].append(n.id)
    return dict(result)


def _node_to_dict(n: ManifestNode) -> dict[str, Any]:
    d: dict[str, Any] = {"id": n.id, "kind": n.kind, "name": n.name}
    if n.domain:
        d["domain"] = n.domain
    if n.path:
        d["path"] = n.path
    return d


def _depth1_subgraph(
    node_id: str,
    graph: ManifestGraph,
    max_symbols: int = 5,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Return (nodes, edges) for a depth-1 subgraph around node_id."""
    by_id = {n.id: n for n in graph.nodes}
    neighbor_ids: set[str] = set()

    edge_dicts: list[dict[str, Any]] = []
    for edge in graph.edges_from(node_id):
        neighbor_ids.add(edge.to_id)
        edge_dicts.append({"from": edge.from_id, "to": edge.to_id, "relation": edge.relation})
    for edge in graph.edges_to(node_id):
        neighbor_ids.add(edge.from_id)
        edge_dicts.append({"from": edge.from_id, "to": edge.to_id, "relation": edge.relation})

    all_ids = sorted({node_id, *neighbor_ids})[:max_symbols]
    node_dicts = [_node_to_dict(by_id[nid]) for nid in all_ids if nid in by_id]
    return node_dicts, edge_dicts


def _depth2_subgraph(
    node_id: str,
    graph: ManifestGraph,
    max_symbols: int = 10,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str]]:
    """Return (nodes, edges, cross_domain_flags) for depth-2 subgraph."""
    by_id = {n.id: n for n in graph.nodes}
    visited: set[str] = {node_id}
    queue = [node_id]
    all_edge_dicts: list[dict[str, Any]] = []
    cross_domain: list[str] = []

    root_domain = by_id.get(node_id, None)
    root_domain_name = root_domain.domain if root_domain else None

    for _ in range(2):  # 2 hops
        next_queue: list[str] = []
        for current in queue:
            for edge in graph.edges_from(current):
                all_edge_dicts.append({"from": edge.from_id, "to": edge.to_id, "relation": edge.relation})
                if edge.to_id not in visited:
                    visited.add(edge.to_id)
                    next_queue.append(edge.to_id)
                    neighbor = by_id.get(edge.to_id)
                    if neighbor and neighbor.domain != root_domain_name and neighbor.kind != "domain":
                        cross_domain.append(edge.to_id)
            for edge in graph.edges_to(current):
                all_edge_dicts.append({"from": edge.from_id, "to": edge.to_id, "relation": edge.relation})
                if edge.from_id not in visited:
                    visited.add(edge.from_id)
                    next_queue.append(edge.from_id)
                    neighbor = by_id.get(edge.from_id)
                    if neighbor and neighbor.domain != root_domain_name and neighbor.kind != "domain":
                        cross_domain.append(edge.from_id)
        queue = next_queue

    truncated = sorted(visited)[:max_symbols]
    node_dicts = [_node_to_dict(by_id[nid]) for nid in truncated if nid in by_id]
    # Deduplicate edges
    seen_edges: set[tuple[str, str, str]] = set()
    unique_edges: list[dict[str, Any]] = []
    for e in all_edge_dicts:
        key = (e["from"], e["to"], e["relation"])
        if key not in seen_edges:
            seen_edges.add(key)
            unique_edges.append(e)

    return node_dicts, unique_edges, sorted(set(cross_domain))


# ── Constraint extractor ──────────────────────────────────────────────────────

def _extract_constraints(manifest: dict[str, Any], adrs: list[dict[str, Any]]) -> list[str]:
    """Pull stable architectural constraints from manifest + accepted ADRs."""
    constraints: list[str] = []

    # From manifest frontmatter active_constraints
    for c in (manifest.get("active_constraints") or []):
        if isinstance(c, str):
            constraints.append(c)

    # From manifest known_broken (stable issues only — no drift, no timestamps)
    # (not constraints, handled separately)

    # From accepted ADRs — title is the constraint
    for adr in adrs:
        if not isinstance(adr, dict):
            continue
        if str(adr.get("status") or "").lower() not in ("accepted", "active"):
            continue
        title = str(adr.get("title") or "")
        adr_id = str(adr.get("id") or "")
        if title and adr_id:
            constraints.append(f"{adr_id}: {title}")

    return constraints


def _extract_known_broken(manifest: dict[str, Any]) -> list[str]:
    raw = manifest.get("known_broken") or []
    return [str(x) for x in raw if isinstance(x, str)]


# ── ADR index builder ─────────────────────────────────────────────────────────

def _adr_index(adrs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Build compact ADR index (id + title + status + enforcement type)."""
    rows = []
    for adr in adrs:
        if not isinstance(adr, dict):
            continue
        enf = adr.get("enforcement") or {}
        rows.append({
            "id": str(adr.get("id") or ""),
            "title": str(adr.get("title") or ""),
            "status": str(adr.get("status") or ""),
            "enforcement": str(enf.get("type") or "pending") if isinstance(enf, dict) else "pending",
        })
    return rows


def _adr_for_domain(adrs: list[dict[str, Any]], domain: str) -> list[dict[str, Any]]:
    """Return ADRs relevant to a domain (scope=global or matching stack/applies_to)."""
    domain_lower = domain.lower()
    result = []
    for adr in adrs:
        if not isinstance(adr, dict):
            continue
        if str(adr.get("status") or "").lower() not in ("accepted", "active"):
            continue
        scope = str(adr.get("scope") or "")
        applies_to = adr.get("applies_to") or []
        if scope == "global" or "all" in applies_to:
            result.append(adr)
            continue
        # Check if domain name matches scope or applies_to entries
        if domain_lower in str(scope).lower():
            result.append(adr)
            continue
        for a in applies_to:
            if domain_lower in str(a).lower():
                result.append(adr)
                break
    return result


# ── Rules section ─────────────────────────────────────────────────────────────

def _rules_summary(project_path: Path) -> list[dict[str, Any]]:
    rules = load_rules(project_path)
    return [
        {"effect": r.effect, "applies_to": r.applies_to, "generates": list(r.generates)}
        for r in rules
    ]


# ── YAML block renderer ───────────────────────────────────────────────────────

def _yaml_block(data: Any) -> str:
    return yaml.safe_dump(data, sort_keys=True, allow_unicode=True, default_flow_style=False).strip()


# ── Section renderers ─────────────────────────────────────────────────────────

def _render_section(scope: str, section: str, content: str) -> str:
    return f"### [section:{section}]\n\n```yaml\n{content}\n```\n"


def _scope_minimal(
    graph: ManifestGraph,
    manifest: dict[str, Any],
    adrs: list[dict[str, Any]],
    project_path: Path,
) -> str:
    constraints = _extract_constraints(manifest, adrs)
    known_broken = _extract_known_broken(manifest)

    lines = [
        "## [scope:minimal]",
        "<!-- Max depth: 0 — project-level constraints and known issues only -->",
        "",
        _render_section("minimal", "constraints", _yaml_block(constraints)),
        _render_section("minimal", "known_broken", _yaml_block(known_broken)),
        _render_section("minimal", "rules", _yaml_block(_rules_summary(project_path))),
    ]
    return "\n".join(lines)


def _scope_system(
    graph: ManifestGraph,
    manifest: dict[str, Any],
    adrs: list[dict[str, Any]],
    project_path: Path,
    agent_notes: str,
) -> str:
    domain_sum = _domain_summary(graph)
    graph_summary = {
        "node_count": len(graph.nodes),
        "edge_count": len(graph.edges),
        "domains": {
            domain: {"member_count": len(members), "members": sorted(members)}
            for domain, members in sorted(domain_sum.items())
        },
    }
    constraints = _extract_constraints(manifest, adrs)
    adr_idx = _adr_index(adrs)

    lines = [
        "## [scope:system]",
        "<!-- Max depth: unbounded — full architectural overview -->",
        "",
        _render_section("system", "graph", _yaml_block(graph_summary)),
        _render_section("system", "constraints", _yaml_block(constraints)),
        _render_section("system", "adr", _yaml_block(adr_idx)),
    ]

    if agent_notes:
        lines.append("### [section:supplementary]\n")
        lines.append("<!-- Source: docs/AGENT_NOTES.md — human-authored, compiler-readable -->")
        lines.append("")
        lines.append(agent_notes)
        lines.append("")

    return "\n".join(lines)


# ── Shared data builder ───────────────────────────────────────────────────────

def _build_context_data(
    graph: ManifestGraph,
    manifest: dict[str, Any],
    adrs: list[dict[str, Any]],
    project_path: Path,
    agent_notes: str,
) -> dict[str, Any]:
    """Build raw context data dict shared between JSON and MD output.

    Returns a scopes dict:
        {
            "minimal": {"constraints": [...], "known_broken": [...], "rules": [...]},
            "system":  {"graph": {...}, "constraints": [...], "adr": [...]},
        }
    Values are typed Python objects — no YAML/Markdown encoding applied.
    """
    constraints = _extract_constraints(manifest, adrs)
    known_broken = _extract_known_broken(manifest)
    rules = _rules_summary(project_path)

    domain_sum = _domain_summary(graph)
    graph_summary: dict[str, Any] = {
        "node_count": len(graph.nodes),
        "edge_count": len(graph.edges),
        "domains": {
            domain: {"member_count": len(members), "members": sorted(members)}
            for domain, members in sorted(domain_sum.items())
        },
    }
    adr_idx = _adr_index(adrs)

    scopes: dict[str, Any] = {
        "minimal": {
            "constraints": constraints,
            "known_broken": known_broken,
            "rules": rules,
        },
        "system": {
            "graph": graph_summary,
            "constraints": constraints,
            "adr": adr_idx,
        },
    }

    if agent_notes:
        scopes["system"]["supplementary"] = agent_notes

    return scopes


# ── Top-level generators ──────────────────────────────────────────────────────

def generate_agent_context_json(project_path: Path) -> Path:
    """Generate .forge/agent_context.json — JSON cache for MCP hot path.

    Pure + deterministic: same inputs → identical output.
    No timestamps, no scan_age_days, no drift counts.

    Markdown generation is a separate render step (generate_agent_context)
    only called by forge map — this function owns the MCP fast path.

    Returns the path written.
    """
    root = Path(project_path).resolve()
    graph = build_manifest_graph(root)
    manifest = _load_manifest(root)
    adrs = _load_adr_registry(root)
    agent_notes = _load_agent_notes(root)

    scopes = _build_context_data(graph, manifest, adrs, root, agent_notes)

    payload: dict[str, Any] = {
        "schema": "agent_context_v1",
        "generated_by": "forge compiler (Phase 8)",
        "human_edits": "NEVER — edit docs/AGENT_NOTES.md instead",
        "scopes": scopes,
    }

    forge_dir = root / ".forge"
    forge_dir.mkdir(parents=True, exist_ok=True)
    out_path = forge_dir / "agent_context.json"
    out_path.write_text(
        json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False),
        encoding="utf-8",
    )
    return out_path


def generate_agent_context(project_path: Path) -> str:
    """Generate deterministic AGENT_CONTEXT.md content.

    Pure + deterministic: same inputs → identical output.
    No timestamps, no scan_age_days, no drift counts.

    Returns the full file content as a string (caller writes it).
    """
    root = Path(project_path).resolve()
    graph = build_manifest_graph(root)
    manifest = _load_manifest(root)
    adrs = _load_adr_registry(root)
    agent_notes = _load_agent_notes(root)

    header = "\n".join([
        "---",
        "id: docs/agent_context",
        "type: agent_context",
        "generated_by: forge compiler (Phase 8)",
        "human_edits: NEVER — edit docs/AGENT_NOTES.md instead",
        "schema: cowork/AGENT_CONTEXT_SCHEMA.md",
        "---",
        "",
        "# AGENT_CONTEXT",
        "",
        "<!-- AUTO-GENERATED — do not edit manually. -->",
        "<!-- Human-authored context: docs/AGENT_NOTES.md -->",
        "<!-- Schema: cowork/AGENT_CONTEXT_SCHEMA.md -->",
        "",
        "<!-- DETERMINISM: timestamps/scan_age/drift excluded per separation rule. -->",
        "",
    ])

    scope_minimal = _scope_minimal(graph, manifest, adrs, root)
    scope_system = _scope_system(graph, manifest, adrs, root, agent_notes)

    return header + scope_minimal + "\n\n---\n\n" + scope_system + "\n"
