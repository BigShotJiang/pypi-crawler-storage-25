"""
forge/cli.py

Thin re-export. Production entry point is forge/cli_main.py.
This file exists for import compatibility.
"""

from forge.cli_main import main  # noqa: F401
