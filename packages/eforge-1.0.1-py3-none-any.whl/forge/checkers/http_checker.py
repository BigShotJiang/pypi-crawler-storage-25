from forge.protocols.checker import (
    CheckerProtocol, CheckerContext, CheckResult
)
import urllib.request


class HttpChecker(CheckerProtocol):
    handles = ["http", "https", "endpoint"]
    version = "1.0.0"

    def check(self, context: CheckerContext) -> CheckResult:
        url = context.config.get("url", "")
        if not url:
            return CheckResult.failing(
                "http", 0,
                "No URL configured",
                "Add url to infra node config"
            )
        try:
            req = urllib.request.Request(url, method="HEAD")
            with urllib.request.urlopen(req, timeout=5) as resp:
                if resp.status < 400:
                    return CheckResult.passing("http")
                return CheckResult.failing(
                    "http", 30,
                    f"HTTP {resp.status}",
                    "Check endpoint configuration"
                )
        except Exception as e:
            return CheckResult.failing(
                "http", 0, str(e)[:100],
                "Verify endpoint is reachable"
            )
