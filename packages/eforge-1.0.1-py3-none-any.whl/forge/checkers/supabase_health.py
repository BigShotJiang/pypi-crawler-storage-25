import os
import httpx
from forge.core.checks import DashboardCheck, CheckResult, registry


def check_supabase_health(dc: DashboardCheck) -> CheckResult:
    """
    dc.check format: "env:VAR_NAME"
    Read URL from environment variable named VAR_NAME.
    Ping {url}/rest/v1/ with anon key header.
    ok   → 200
    warn → env var set but unreachable
    fail → env var missing
    Stub ok for anon key — try without auth header first.
    """
    check = dc.check.strip()
    if not check.startswith("env:"):
        return CheckResult(dc.label, "fail", error="supabase_health check must be env:VAR_NAME")
    var_name = check[4:].strip()
    if not var_name:
        return CheckResult(dc.label, "fail", error="env var name missing")
    url = os.environ.get(var_name)
    if not url:
        return CheckResult(dc.label, "fail", error=f"Environment variable {var_name} not set")
    url = url.rstrip("/")
    ping_url = f"{url}/rest/v1/"
    headers: dict[str, str] = {}
    anon = (os.environ.get("SUPABASE_ANON_KEY") or "").strip()
    if anon:
        headers["apikey"] = anon
        headers["Authorization"] = f"Bearer {anon}"
    try:
        with httpx.Client(timeout=5.0) as client:
            response = client.get(ping_url, headers=headers)
            if response.status_code == 200:
                return CheckResult(dc.label, "ok", value="200 OK")
            return CheckResult(
                dc.label,
                "warn",
                value=str(response.status_code),
                error=f"Unreachable: {response.status_code}",
            )
    except Exception as e:
        return CheckResult(dc.label, "warn", error=f"Unreachable: {e}")


registry.register("supabase_health", check_supabase_health)
