import os
import re
from urllib.parse import quote

import httpx

from forge.core.checks import DashboardCheck, CheckResult, registry

_TABLE_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


def check_db_count(dc: DashboardCheck) -> CheckResult:
    """
    dc.check format: ``supabase:table_name`` or ``supabase:table_name?filter`` (PostgREST query).

    Uses ``SUPABASE_URL`` and ``SUPABASE_ANON_KEY`` from the environment.
    Sends ``Prefer: count=exact`` and reads total from ``Content-Range`` (e.g. ``0-0/42``).
    """
    check = dc.check.strip()
    if not check.startswith("supabase:"):
        return CheckResult(
            dc.label,
            "fail",
            error="db_count check must be supabase:table_name[?postgrest_filter]",
        )
    rest = check[9:].strip()
    if not rest:
        return CheckResult(dc.label, "fail", error="table name missing")
    if "?" in rest:
        table, query_suffix = rest.split("?", 1)
    else:
        table, query_suffix = rest, ""
    table = table.strip()
    if not table or not _TABLE_RE.match(table):
        return CheckResult(
            dc.label,
            "fail",
            error=f"invalid table name: {table!r}",
        )

    base = (os.environ.get("SUPABASE_URL") or "").strip().rstrip("/")
    key = (os.environ.get("SUPABASE_ANON_KEY") or "").strip()
    if not base or not key:
        return CheckResult(
            dc.label,
            "unknown",
            error="db_count requires SUPABASE_URL and SUPABASE_ANON_KEY in environment",
        )

    q = "select=*"
    if query_suffix.strip():
        q = f"{query_suffix.strip()}&select=*" if "select=" not in query_suffix else query_suffix.strip()

    url = f"{base}/rest/v1/{quote(table, safe='')}?{q}"
    headers = {
        "apikey": key,
        "Authorization": f"Bearer {key}",
        "Prefer": "count=exact",
        "Range": "0-0",
    }
    try:
        with httpx.Client(timeout=10.0) as client:
            response = client.get(url, headers=headers)
    except Exception as e:
        return CheckResult(dc.label, "fail", error=str(e))

    if response.status_code == 401:
        return CheckResult(dc.label, "fail", error="Supabase rejected credentials (401)")
    if response.status_code == 404:
        return CheckResult(dc.label, "fail", error=f"Table or route not found (404): {table!r}")
    if response.status_code >= 400:
        return CheckResult(
            dc.label,
            "warn",
            value=str(response.status_code),
            error=response.text[:200] if response.text else f"HTTP {response.status_code}",
        )

    cr = (response.headers.get("content-range") or "").strip()
    total: int | None = None
    if "/" in cr:
        tail = cr.split("/")[-1].strip()
        if tail.isdigit():
            total = int(tail)
    if total is None:
        return CheckResult(
            dc.label,
            "warn",
            error=f"Could not parse count from Content-Range: {cr!r}",
        )
    return CheckResult(dc.label, "ok", value=str(total))


registry.register("db_count", check_db_count)
