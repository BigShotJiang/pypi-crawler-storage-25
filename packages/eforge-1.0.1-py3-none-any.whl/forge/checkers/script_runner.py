import subprocess

from forge.core.checks import CheckResult, DashboardCheck, registry


def check_script(dc: DashboardCheck) -> CheckResult:
    """
    Runs dc.check as a shell command.
    Exit code 0 → ok. Non-zero → fail.
    stdout shown as value. stderr shown as error.
    Timeout: 30 seconds.
    """
    try:
        result = subprocess.run(
            dc.check,
            shell=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            return CheckResult(
                label=dc.label,
                status="ok",
                value=(result.stdout or "").strip()[:100] or "passed",
            )
        return CheckResult(
            label=dc.label,
            status="fail",
            value=(result.stdout or "").strip()[:100] or None,
            error=(result.stderr or "").strip()[:200] or f"exit {result.returncode}",
        )
    except subprocess.TimeoutExpired:
        return CheckResult(
            label=dc.label, status="fail", error="Timed out after 30s"
        )
    except Exception as e:
        return CheckResult(label=dc.label, status="unknown", error=str(e))


registry.register("script", check_script)
