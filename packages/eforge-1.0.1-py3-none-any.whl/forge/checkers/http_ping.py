import httpx
from forge.core.checks import DashboardCheck, CheckResult, registry


def check_http_ping(dc: DashboardCheck) -> CheckResult:
    """
    GET dc.check URL.
    ok      → 200 response under 2s
    warn    → 200 response over 2s
    fail    → connection refused or non-200
    unknown → URL malformed
    Stub: use httpx with 3s timeout. Catch all exceptions → fail.
    """
    url = dc.check.strip()
    if not url.startswith("http://") and not url.startswith("https://"):
        return CheckResult(dc.label, "unknown", error="URL must start with http:// or https://")
    try:
        with httpx.Client(timeout=3.0) as client:
            response = client.get(url)
            if response.status_code != 200:
                return CheckResult(
                    dc.label,
                    "fail",
                    value=f"{response.status_code}",
                    error=f"Non-200 response: {response.status_code}",
                )
            elapsed = response.elapsed.total_seconds()
            if elapsed > 2.0:
                return CheckResult(dc.label, "warn", value=f"200 OK ({elapsed:.1f}s)")
            return CheckResult(dc.label, "ok", value="200 OK")
    except Exception as e:
        return CheckResult(dc.label, "fail", error=str(e))


registry.register("http_ping", check_http_ping)
