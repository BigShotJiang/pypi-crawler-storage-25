from forge.core.checks import CheckResult, DashboardCheck, registry


def check_plugin(dc: DashboardCheck) -> CheckResult:
    """
    Dispatches to project-local plugin checker.
    Looks for .forge/project_checkers.py in the project directory.
    If not found: returns status=unknown with setup hint.
    
    DEPRECATED: Plugin system not implemented.
    Modern alternatives: forge doctor, forge verify, custom checkers
    """
    plugin_name = dc.plugin or "Plugin"
    class_hint = plugin_name.title().replace("_", "")
    return CheckResult(
        label=dc.label,
        status="unknown",
        error=(
            f"Plugin checker '{dc.plugin}' not configured. "
            f"Plugin system deprecated. Use forge doctor or custom checkers instead."
        ),
    )


registry.register("plugin", check_plugin)
