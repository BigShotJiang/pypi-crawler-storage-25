# Import all checkers to trigger self-registration with registry.
# This is the ONLY file that imports concrete checker modules.
from forge.checkers import (  # noqa: F401
    http_ping,
    supabase_health,
    vercel_status,
    db_count,
    script_runner,
    plugin_loader,
)
