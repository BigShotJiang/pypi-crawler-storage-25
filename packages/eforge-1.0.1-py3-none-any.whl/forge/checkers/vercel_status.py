import os

import httpx

from forge.core.checks import DashboardCheck, CheckResult, registry


def check_vercel_status(dc: DashboardCheck) -> CheckResult:
    """
    dc.check format: ``vercel:project-name`` (exact match to Vercel project name).

    Requires ``VERCEL_TOKEN``. Optional ``VERCEL_TEAM_ID`` for team-scoped projects.
    Lists projects via ``GET https://api.vercel.com/v9/projects``.
    """
    check = dc.check.strip()
    if not check.startswith("vercel:"):
        return CheckResult(
            dc.label,
            "fail",
            error="vercel_status check must be vercel:project-name",
        )
    project_name = check[7:].strip()
    if not project_name:
        return CheckResult(dc.label, "fail", error="project name missing")

    token = (os.environ.get("VERCEL_TOKEN") or "").strip()
    if not token:
        return CheckResult(
            dc.label,
            "unknown",
            error="Vercel API token not configured — set VERCEL_TOKEN",
        )

    team_id = (os.environ.get("VERCEL_TEAM_ID") or "").strip()
    headers = {"Authorization": f"Bearer {token}"}
    params: dict[str, str] = {}
    if team_id:
        params["teamId"] = team_id

    try:
        with httpx.Client(timeout=15.0) as client:
            response = client.get(
                "https://api.vercel.com/v9/projects",
                headers=headers,
                params=params or None,
            )
    except Exception as e:
        return CheckResult(dc.label, "warn", error=str(e))

    if response.status_code == 401:
        return CheckResult(dc.label, "fail", error="Vercel API rejected token (401)")
    if response.status_code == 403:
        return CheckResult(
            dc.label,
            "fail",
            error="Vercel API forbidden (403) — check token scope or VERCEL_TEAM_ID",
        )
    if response.status_code != 200:
        return CheckResult(
            dc.label,
            "warn",
            value=str(response.status_code),
            error=f"Vercel API HTTP {response.status_code}",
        )

    try:
        payload = response.json()
    except Exception as e:
        return CheckResult(dc.label, "warn", error=f"Invalid JSON from Vercel: {e}")

    projects = payload.get("projects")
    if not isinstance(projects, list):
        return CheckResult(dc.label, "warn", error="Unexpected Vercel response shape (no projects list)")

    for p in projects:
        if isinstance(p, dict) and p.get("name") == project_name:
            pid = p.get("id", "")
            return CheckResult(
                dc.label,
                "ok",
                value=f"{project_name}" + (f" ({pid})" if pid else ""),
            )

    return CheckResult(
        dc.label,
        "fail",
        error=f"Project {project_name!r} not found for this token/team",
    )


registry.register("vercel_status", check_vercel_status)
