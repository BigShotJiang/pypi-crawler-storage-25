"""Non-interactive Rich renderer. Prints and exits. No Textual imports."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from forge.archive.tui.textual.state import ProjectState
    from forge.archive.tui.textual.manifest_reader import ManifestData


class RichRenderer:
    """Non-interactive renderer for CI, piped output, or dumb terminals. Prints and exits."""

    def run(self, states: list["ProjectState"]) -> None:
        self.show_project_list(states)

    def show_project_list(self, states: list["ProjectState"]) -> None:
        from rich.console import Console
        from rich.table import Table
        from forge.archive.tui.textual.health_scorer import HealthScorer
        console = Console()
        table = Table(title="Projects")
        table.add_column("Name")
        table.add_column("Type")
        table.add_column("Phase")
        table.add_column("Health")
        table.add_column("Status")
        table.add_column("Branch")
        for s in states:
            p = s.project
            phase = getattr(p, "current_phase", lambda: None)()
            if callable(phase):
                phase = None
            phase_str = str(phase) if phase is not None else "—"
            status = HealthScorer.status(s.health_score)
            color = HealthScorer.colour(status)
            table.add_row(
                p.name,
                p.type,
                phase_str,
                str(s.health_score),
                f"[{color}]{status}[/]",
                s.git.branch,
            )
        console.print(table)

    def show_project_detail(self, state: "ProjectState") -> None:
        from rich.console import Console
        from rich.panel import Panel
        from rich.text import Text
        console = Console()
        p = state.project
        lines = [
            f"Name: {p.name}",
            f"Type: {p.type}",
            f"Version: {p.version}",
            f"Path: {p.path}",
            f"Health: {state.health_score} ({state.health_status})",
            f"Branch: {state.git.branch}",
        ]
        console.print(Panel(Text.from_markup("\n".join(lines)), title="Project"))

    def show_health_report(self, state: "ProjectState") -> None:
        from rich.console import Console
        from rich.panel import Panel
        from forge.archive.tui.textual.health_scorer import HealthScorer
        console = Console()
        dot = HealthScorer.dot(state.health_status)
        color = HealthScorer.colour(state.health_status)
        console.print(Panel(f"[{color}]{dot}[/] {state.health_score} — {state.health_status}"))
        for r in state.check_results:
            console.print(f"  {r.status}: {r.label} — {r.value or r.error or '—'}")

    def show_inspector(
        self, state: "ProjectState", manifest: "ManifestData | None"
    ) -> None:
        from rich.console import Console
        from rich.tree import Tree as RichTree
        console = Console()
        tree = RichTree("manifest")
        if manifest:
            for cat, items in manifest.by_category.items():
                branch = tree.add(cat)
                for fc in items:
                    branch.add(fc.name)
        console.print(tree)

    def show_config_editor(self, state: "ProjectState") -> None:
        from rich.console import Console
        from rich.table import Table
        console = Console()
        console.print(Table(title="Config (read-only)"))
        console.print(f"Config path: {state.config_path or '—'}")

    def show_logs(self, state: "ProjectState") -> None:
        from rich.console import Console
        from rich.table import Table
        console = Console()
        table = Table(title="Logs (last 50)")
        table.add_column("Time")
        table.add_column("Message")
        console.print(table)
        console.print("(no log events)")
