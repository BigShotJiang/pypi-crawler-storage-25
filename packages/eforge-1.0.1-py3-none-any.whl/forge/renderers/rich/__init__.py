from forge.renderers.base import RendererRegistry
from forge.renderers.rich.renderer import RichRenderer

RendererRegistry.register("rich", RichRenderer)
