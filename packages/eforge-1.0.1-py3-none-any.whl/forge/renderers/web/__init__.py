# Live FastAPI dashboard renderer (forge board, docs_audit API).
# Reference snapshot with UI + tests: forge/archive/renderers_web/
# Pending L5 WebSocket work — server/routers here are canonical.

from forge.renderers.base import RendererRegistry
from forge.archive.renderers_web.renderer import WebRenderer

RendererRegistry.register("web", WebRenderer)

__all__ = ["WebRenderer"]
