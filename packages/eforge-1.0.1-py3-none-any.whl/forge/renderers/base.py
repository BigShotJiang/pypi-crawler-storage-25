from typing import Protocol

# Import only for type hints; avoid circular import by deferring
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from forge.archive.tui.textual.state import ProjectState
    from forge.archive.tui.textual.manifest_reader import ManifestData


class RendererProtocol(Protocol):
    def show_project_list(self, states: list["ProjectState"]) -> None: ...
    def show_project_detail(self, state: "ProjectState") -> None: ...
    def show_health_report(self, state: "ProjectState") -> None: ...
    def show_inspector(
        self, state: "ProjectState", manifest: "ManifestData | None"
    ) -> None: ...
    def show_config_editor(self, state: "ProjectState") -> None: ...
    def show_logs(self, state: "ProjectState") -> None: ...
    def run(self, states: list["ProjectState"]) -> None: ...


class RendererRegistry:
    _renderers: dict[str, type] = {}

    @classmethod
    def register(cls, name: str, renderer_class: type) -> None:
        cls._renderers[name] = renderer_class

    @classmethod
    def resolve(cls, name: str = "auto"):
        if name == "auto":
            name = cls._detect()
        if name not in cls._renderers:
            raise KeyError(
                f"Unknown renderer: {name}. "
                f"Available: {list(cls._renderers.keys())}"
            )
        return cls._renderers[name]()

    @classmethod
    def _detect(cls) -> str:
        import os
        if os.environ.get("CI") or os.environ.get("TERM") == "dumb":
            return "rich"
        return "rich"

    @classmethod
    def available(cls) -> list[str]:
        return list(cls._renderers.keys())
