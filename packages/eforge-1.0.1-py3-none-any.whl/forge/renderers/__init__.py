# Import adapters to trigger registration with RendererRegistry
from forge.renderers import rich  # noqa: F401
from forge.renderers import web  # noqa: F401
