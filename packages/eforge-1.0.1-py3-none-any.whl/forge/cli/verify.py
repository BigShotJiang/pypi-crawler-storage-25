"""
forge/cli/verify.py

forge verify — change impact pipeline.
Maps changed files → manifest nodes → propagation impacts + failures.

Usage:
    forge verify              # git diff HEAD --name-only
    forge verify --staged     # git diff --cached --name-only
    forge verify --file <f>   # single file
    forge verify --full       # all tracked files

Exit codes:
    0 — clean (no structural failures or warnings)
    1 — structural warnings only (e.g. changed files with no manifest node), or
        ``--strict`` manifest stack-field validation failure (unknown / cross-stack fields)
    2 — structural failures (propagation failures, tier-import violations (ADR-017),
        schema violations, C006)

API surface used — all names confirmed from docs/VERIFY_API_SURFACE.md:
    build_manifest_graph(project_path)          → ManifestGraph
    find_node_id_for_path(graph, rel_path)      → str | None
    Diff(target=node_id, effects=[...])
    propagate(diff, graph, project_path=...)    → list[Impact]
    get_emitted()                               → list[Failure]
    clear_emitted()
    impact.node_id / .role / .effect / .actions / .source_node
    failure.type.value / .context / .recovery_hint
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import click
import yaml

from forge.commands._shared_options import response_tier_option
from forge.core.criticality import criticality_label
from forge.core.impact import collect_tier_import_violations
from forge.core.path_utils import resolve_project_path
from forge.core.schemas import CLIProgressEvent
from forge.core.workspace_contracts import verify_workspace_contracts
from forge.core.workspace_entity import ForgeWorkspace
from forge.engine.registry import EntityRegistry
from forge.schema.drift_pipeline import collect_schema_registry_drift_failures
from forge.schema.registry import SchemaRegistry
from forge.schema.snapshot_io import read_registry_yaml
from forge.core.stack_schema_validator import validate_stack_schema
from forge.core.stack_profiles import get_impact_rules
from forge.tools.manifest.failures import clear_emitted, get_emitted
from forge.tools.manifest.graph import build_manifest_graph, find_node_id_for_path
from forge.tools.manifest.propagation import Diff, propagate
from forge.verify.diff import VerifyDiffError, run_verify_diff
from forge.verify.packet_validator import PacketValidationError, validate_packet
from forge.verify.preflight import PreflightError, run_preflight


@dataclass
class VerifyFailure:
    kind: str
    severity: str
    message: str
    node: str
    adr: str
    from_node: str = ""
    to_node: str = ""
    from_tier: str = ""
    to_tier: str = ""
    edge: str = ""
    causal_chain: list[dict] = field(default_factory=list)
    error_detail: dict[str, Any] = field(default_factory=dict)


def _tier_import_failure_from_event(ev: Any) -> VerifyFailure:
    """Build a tier-import VerifyFailure with structured edge fields."""
    from forge.core.errors import build_tier_violation_chain, get_error

    affected = list(ev.affected_node_ids or [])
    ctx = dict(ev.context or {})
    edge_s = str(ctx.get("edge") or "")
    from_node = str(
        ctx.get("from_node")
        or ctx.get("source")
        or (affected[0] if affected else "")
    )
    to_node = str(
        ctx.get("to_node")
        or ctx.get("target")
        or (affected[1] if len(affected) > 1 else "")
    )
    if not from_node and "→" in edge_s:
        left, _, right = edge_s.partition("→")
        from_node = left.strip()
        if not to_node:
            to_node = right.strip()
    from_tier = str(ctx.get("from_tier") or "")
    to_tier = str(ctx.get("to_tier") or "")
    msg = (
        f"tier import rule: {edge_s} "
        f"(from_tier={from_tier!r} to_tier={to_tier!r})"
    )
    node_id = from_node or (affected[0] if affected else "")
    causal_chain: list[dict] = []
    error_detail: dict[str, Any] = {}
    if from_node and to_node:
        chain = build_tier_violation_chain(
            from_node,
            to_node,
            from_tier or "?",
            to_tier or "?",
        )
        causal_chain = [h.to_dict() for h in chain]
        err = get_error("ring_boundary_violation")
        err = err.with_causal_chain(chain)
        err = err.with_graph_context(from_node, affected=[to_node])
        error_detail = err.to_dict()
    return VerifyFailure(
        kind="tier-import-violation",
        severity="error",
        message=msg,
        node=node_id,
        adr="ADR-017",
        from_node=from_node,
        to_node=to_node,
        from_tier=from_tier,
        to_tier=to_tier,
        edge=edge_s,
        causal_chain=causal_chain,
        error_detail=error_detail,
    )


def _check_stack_field_bleed(graph: Any, manifest: dict[str, Any], project_path: Path) -> list[VerifyFailure]:
    _ = (graph, project_path)
    from forge.core.manifest import collect_stack_manifest_field_violations

    failures: list[VerifyFailure] = []
    for vkind, node_ref, msg in collect_stack_manifest_field_violations(manifest):
        if vkind == "schema_missing":
            failures.append(
                VerifyFailure(
                    kind="stack-schema-missing",
                    severity="warning",
                    message=msg,
                    node=node_ref,
                    adr="ADR-013",
                )
            )
        elif vkind == "cross_stack":
            failures.append(
                VerifyFailure(
                    kind="stack-field-bleed",
                    severity="error",
                    message=msg,
                    node=node_ref,
                    adr="ADR-013",
                )
            )
        else:
            failures.append(
                VerifyFailure(
                    kind="stack-unknown-field",
                    severity="warning",
                    message=msg,
                    node=node_ref,
                    adr="ADR-018",
                )
            )
    return failures


def _distribution_repo_root() -> Path:
    """Root of the installed forge repo (bundled ``schemas/stacks`` live here)."""
    return Path(__file__).resolve().parents[2]


def _check_stack_schema_contracts(project_path: Path) -> list[VerifyFailure]:
    stack_dir = _distribution_repo_root() / "schemas" / "stacks"
    failures: list[VerifyFailure] = []
    for p in sorted(stack_dir.glob("*.yaml")):
        if p.name.startswith("_"):
            continue
        for msg in validate_stack_schema(p):
            failures.append(
                VerifyFailure(
                    kind="stack-schema-contract",
                    severity="error",
                    message=msg,
                    node=f"schema:{p.relative_to(stack_dir.parent.parent)}",
                    adr="ADR-013",
                )
            )
    _ = project_path
    return failures


def _extend_verify_with_stack_distribution_checks(result: dict[str, Any], project_path: Path) -> None:
    """Validate bundled ``schemas/stacks/*.yaml`` contracts (exclude ``_*.yaml`` templates).

    Failures reference absolute paths via :func:`validate_stack_schema` messages plus a
    ``schema:schemas/stacks/<name>.yaml`` node id.

    Sprint 4 Phase 2 — stack schema drift surfaces on every verify. For manifest modules
    that exceed the active stack allowlist, use ``forge verify --scope stack`` /
    MCP target ``stack`` (:func:`_check_stack_field_bleed`).
    """
    schema_failures = _check_stack_schema_contracts(project_path)
    if schema_failures:
        result["failures"].extend(asdict(f) for f in schema_failures)
        result["exit_code"] = max(int(result.get("exit_code") or 0), 2)
    _ = project_path


def _normalize_repo_rel_path(rel_path: str) -> str:
    rp = rel_path.replace("\\", "/")
    if rp.startswith("./"):
        rp = rp[2:]
    return rp


def _emit_progress(current: int, total: int, message: str = "") -> None:
    if os.environ.get("FORGE_PROGRESS_STREAM", "0") != "1":
        return
    evt = CLIProgressEvent(current=current, total=total, message=message)
    print(json.dumps(evt.model_dump()), flush=True)


def _load_forgeignore(project_path: Path) -> list[str]:
    """Load extra unmapped-file exemptions from repo-root ``.forgeignore`` (one glob/path per line).

    Same pattern rules as ``manifest.exempt_paths``: exact path, ``*suffix``, or ``dir/`` prefix.
    Lines starting with ``#`` or empty are skipped.
    """
    p = project_path.resolve() / ".forgeignore"
    if not p.is_file():
        return []
    try:
        raw = p.read_text(encoding="utf-8")
    except OSError:
        return []
    out: list[str] = []
    for line in raw.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        out.append(s)
    return out


# Files that are structurally legitimate but not graph node paths.
def _is_unmapped_exempt(rel_path: str, exempt_paths: list[str] | None = None) -> bool:
    rp = _normalize_repo_rel_path(rel_path)
    # Forge workspace state — never declaration-graph module paths
    if rp.startswith(".forge/"):
        return True
    if "/__pycache__/" in f"/{rp}/" or rp.startswith("__pycache__/"):
        return True
    if rp in (".gitignore", ".gitattributes", ".editorconfig", ".python-version"):
        return True
    if rp.startswith(".github/"):
        return True
    # Policy trees (ADR prose + stack schema slices) — never declaration-graph modules.
    if rp.startswith("docs/adr/") and rp.endswith(".md"):
        return True
    if rp.startswith("schemas/") and rp.endswith(".yaml"):
        return True

    for raw in exempt_paths or []:
        pat = _normalize_repo_rel_path(str(raw))
        if not pat:
            continue
        if pat.startswith("*") and len(pat) > 1:
            if rp.endswith(pat[1:]):
                return True
            continue
        if pat.endswith("/"):
            base = pat.rstrip("/")
            if rp == base or rp.startswith(base + "/"):
                return True
            continue
        if rp == pat:
            return True
    return False


# ── Git helpers ───────────────────────────────────────────────────────────────

def _git_changed_files(staged: bool = False, *, cwd: Path | None = None) -> list[str]:
    """Return repo-relative paths of changed files from git diff.

    For staged changes, uses ``--name-status`` and omits deleted paths entirely
    (a deletion is not an unmapped working file).

    When *cwd* is set (resolved project root), git runs in that repo so
    ``forge verify --project-path /other/app`` lists that app's files even if the
    shell cwd is another clone (e.g. Forge itself).
    """
    if staged:
        cmd = ["git", "diff", "--cached", "--name-status"]
    else:
        cmd = ["git", "diff", "HEAD", "--name-only"]
    try:
        run_kw: dict[str, object] = {"capture_output": True, "text": True, "check": True}
        if cwd is not None:
            run_kw["cwd"] = cwd
        result = subprocess.run(cmd, **run_kw)
        lines = [ln for ln in result.stdout.strip().splitlines() if ln.strip()]
        if not staged:
            return lines
        paths: list[str] = []
        for line in lines:
            parts = line.split("\t")
            if len(parts) < 2:
                continue
            status = parts[0]
            if status == "D":
                continue
            if len(parts) >= 3 and (status.startswith("R") or status.startswith("C")):
                paths.append(parts[2])
                continue
            paths.append(parts[1])
        return paths
    except subprocess.CalledProcessError as e:
        click.echo(f"git error: {e.stderr.strip()}", err=True)
        return []


def _git_deleted_files_staged(*, cwd: Path | None = None) -> list[str]:
    """Return deleted repo-relative paths from staged changes."""
    try:
        run_kw: dict[str, object] = {"capture_output": True, "text": True, "check": True}
        if cwd is not None:
            run_kw["cwd"] = cwd
        result = subprocess.run(["git", "diff", "--cached", "--name-status"], **run_kw)
        lines = [ln for ln in result.stdout.strip().splitlines() if ln.strip()]
        out: list[str] = []
        for line in lines:
            parts = line.split("\t")
            if len(parts) >= 2 and parts[0] == "D":
                out.append(parts[1])
        return out
    except subprocess.CalledProcessError as e:
        click.echo(f"git error: {e.stderr.strip()}", err=True)
        return []


def _git_tracked_files(*, cwd: Path | None = None) -> list[str]:
    """Return all files currently tracked by git in the repository at *cwd*."""
    try:
        run_kw: dict[str, object] = {"capture_output": True, "text": True, "check": True}
        if cwd is not None:
            run_kw["cwd"] = cwd
        result = subprocess.run(["git", "ls-files"], **run_kw)
        return [f for f in result.stdout.strip().splitlines() if f.strip()]
    except subprocess.CalledProcessError as e:
        click.echo(f"git error: {e.stderr.strip()}", err=True)
        return []


def _resolve_stack_label(project_path: Path) -> str:
    try:
        from forge.core.manifest_document import ManifestDocument

        doc = ManifestDocument.from_path(resolve_project_path(project_path))
        return doc.stack
    except (FileNotFoundError, ValueError):
        raw = _load_manifest_raw(project_path)
        if raw:
            from forge.core.manifest import ManifestParser

            return ManifestParser.get_stack(raw)
        return "unknown"


def _collect_proposed_contract_failures(raw_manifest: dict[str, Any], *, strict: bool) -> list[VerifyFailure]:
    modules = raw_manifest.get("modules")
    if not isinstance(modules, list):
        return []
    out: list[VerifyFailure] = []
    sev = "error" if strict else "medium"
    for row in modules:
        if not isinstance(row, dict):
            continue
        node_id = str(row.get("id") or row.get("name") or "").strip()
        depends_on = row.get("depends_on")
        depends_set = {
            str(x).strip()
            for x in (depends_on if isinstance(depends_on, list) else [])
            if str(x).strip()
        }
        proposed_deps = row.get("proposed_depends_on")
        for dep in (proposed_deps if isinstance(proposed_deps, list) else []):
            dep_s = str(dep).strip()
            if dep_s and dep_s not in depends_set:
                out.append(
                    VerifyFailure(
                        kind="VERIFY-002",
                        severity=sev,
                        message=f"{node_id}: proposed_depends_on entry {dep_s!r} not found in depends_on",
                        node=node_id,
                        adr="ADR-017",
                    )
                )
        proposed_impl = row.get("proposed_implements")
        for target in (proposed_impl if isinstance(proposed_impl, list) else []):
            target_s = str(target).strip()
            if target_s and target_s not in depends_set:
                out.append(
                    VerifyFailure(
                        kind="VERIFY-003",
                        severity=sev,
                        message=f"{node_id}: proposed_implements entry {target_s!r} not satisfied by declared depends_on",
                        node=node_id,
                        adr="ADR-017",
                    )
                )
    return out


def _collapse_no_matching_rule_failures(
    failures: list[dict[str, Any]],
    graph: Any,
    stack_label: str,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Drop per-neighbor ``no_matching_rule`` noise; attach deduped impact rule hints."""
    nm: list[dict[str, Any]] = []
    rest: list[dict[str, Any]] = []
    for f in failures:
        if str(f.get("type") or "") == "no_matching_rule":
            nm.append(f)
        else:
            rest.append(f)

    matches: list[dict[str, Any]] = []
    unknown_pairs: list[dict[str, Any]] = []
    if not nm:
        return failures, {"matches": matches, "unknown_pairs": unknown_pairs}

    by_id = {n.id: n for n in getattr(graph, "nodes", [])}
    groups: dict[tuple[str, str], list[str]] = defaultdict(list)
    for f in nm:
        ctx = f.get("context") or {}
        sym = str(ctx.get("symbol") or "")
        eff = str(ctx.get("effect") or "")
        node = by_id.get(sym)
        kind = str(getattr(node, "kind", "") or "unknown") if node else "unknown"
        if sym:
            groups[(kind, eff)].append(sym)

    rules = get_impact_rules(stack_label)
    extra_failures: list[dict[str, Any]] = []

    for (kind, effect), syms in sorted(groups.items()):
        syms_u = sorted(set(syms))
        rule_hits = [r for r in rules if r.node_kind == kind and r.effect == effect]
        if not rule_hits:
            unknown_pairs.append({
                "node_kind": kind,
                "effect": effect,
                "affected_count": len(syms_u),
                "example_node_ids": syms_u[:5],
            })
            extra_failures.append({
                "type": "unknown_impact_rule",
                "context": {
                    "node_kind": kind,
                    "effect": effect,
                    "affected_count": len(syms_u),
                    "example_node_ids": syms_u[:5],
                },
                "recovery_hint": (
                    f"No impact rule for node_kind={kind!r} effect={effect!r} — "
                    "extend GENERIC_IMPACT_RULES or StackProfile.impact_rules"
                ),
            })
        else:
            for rule in rule_hits:
                matches.append({**asdict(rule), "affected_node_ids": syms_u})

    return rest + extra_failures, {"matches": matches, "unknown_pairs": unknown_pairs}


# ── Core pipeline ─────────────────────────────────────────────────────────────

def _run_verify(
    files: list[str],
    project_path: Path,
    *,
    deleted_files: list[str] | None = None,
    strict: bool = False,
) -> dict[str, Any]:
    """
    Pipeline:
      1. build_manifest_graph — load the node/edge set
      2. Per file: find_node_id_for_path → node_id
      3. Diff(target=node_id, effects=["behavior_changed"])
      4. propagate(diff, graph) → list[Impact]
      5. get_emitted() → failures; clear_emitted() between runs
      6. Assemble result dict
    """
    graph = build_manifest_graph(project_path)

    raw_manifest = _load_manifest_raw(project_path)
    exempt_raw = raw_manifest.get("exempt_paths") if isinstance(raw_manifest, dict) else None
    exempt_paths: list[str] = []
    if isinstance(exempt_raw, list):
        exempt_paths = [str(x).strip() for x in exempt_raw if str(x).strip()]
    exempt_paths.extend(_load_forgeignore(project_path))

    changed_nodes: list[str] = []
    skipped_files: list[str] = []
    all_impacts: list[dict[str, Any]] = []
    all_failures: list[dict[str, Any]] = []
    for rel_path in deleted_files or []:
        node_id = find_node_id_for_path(graph, rel_path)
        if node_id is None:
            continue
        dependents = sorted(
            {
                e.from_id
                for e in graph.edges_to(node_id)
                if str(getattr(e, "relation", "")) == "imports" and str(e.from_id) != str(node_id)
            }
        )
        if dependents:
            all_failures.append(
                asdict(
                    VerifyFailure(
                        kind="broken-dependency",
                        severity="error",
                        message=f"deleted node {node_id} still has {len(dependents)} dependents: {dependents}",
                        node=node_id,
                        adr="ADR-017",
                    )
                )
            )

    total_files = max(len(files), 1)
    for idx, rel_path in enumerate(files, start=1):
        _emit_progress(idx, total_files, rel_path)
        node_id = find_node_id_for_path(graph, rel_path)
        if node_id is None:
            if not _is_unmapped_exempt(rel_path, exempt_paths):
                skipped_files.append(rel_path)
            continue

        changed_nodes.append(node_id)

        # Reset failure registry before each propagation run.
        clear_emitted()

        # Unknown file-level edits are treated as behavior changes for propagation.
        diff = Diff(target=node_id, effects=["behavior_changed"])
        impacts = propagate(diff, graph, project_path=project_path)

        for imp in impacts:
            all_impacts.append({
                "node_id": imp.node_id,
                "role": imp.role,
                "effect": imp.effect,
                "actions": list(imp.actions),
                "source_node": imp.source_node,
            })

        for failure in get_emitted():
            all_failures.append({
                "type": str(failure.type.value),
                "context": dict(failure.context),
                "recovery_hint": failure.recovery_hint,
            })

    stack_label = _resolve_stack_label(project_path)
    all_failures, impact_rules = _collapse_no_matching_rule_failures(all_failures, graph, stack_label)

    parity_failures = _check_parity_edges(graph, project_path)
    parity_payload = [asdict(f) for f in parity_failures]
    all_failures.extend(parity_payload)

    tier_import_events = collect_tier_import_violations(graph)
    tier_import_failures = [
        _tier_import_failure_from_event(ev) for ev in tier_import_events
    ]
    all_failures.extend([asdict(f) for f in tier_import_failures])

    snap_reg = read_registry_yaml(project_path / ".forge" / "schema_registry_baseline.yaml")
    if snap_reg is not None:
        scoped_er = EntityRegistry.attach_graph(graph)
        drift_payload, _ = collect_schema_registry_drift_failures(
            project_path,
            snap_reg,
            SchemaRegistry.builtin(),
            workspace_registry=scoped_er,
        )
        all_failures.extend(drift_payload)
    try:
        ws_hub = ForgeWorkspace.from_registry()
        if ws_hub.contracts or any(fp.requires or fp.exposes for fp in ws_hub.projects.values()):
            all_failures.extend(verify_workspace_contracts(ws_hub))
    except Exception:
        pass

    structural_failures = list(all_failures)

    proposed_failures = _collect_proposed_contract_failures(raw_manifest, strict=strict)
    all_failures.extend([asdict(f) for f in proposed_failures])
    if strict:
        structural_failures.extend([asdict(f) for f in proposed_failures])

    parity_broken = sum(1 for f in parity_failures if f.kind == "broken-parity")
    parity_stale = sum(1 for f in parity_failures if f.kind == "stale-parity")

    has_severity_2 = bool(structural_failures) or parity_broken > 0
    # Stale parity is a sync/doc freshness concern tracked in parity_check payload;
    # structural verify exit code should not fail on freshness-only drift.
    has_severity_1 = bool(skipped_files)
    exit_code = 2 if has_severity_2 else (1 if has_severity_1 else 0)

    return {
        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        "changed_nodes": changed_nodes,
        "skipped_files": skipped_files,
        "impacts": list({(i["node_id"], i["role"]): i for i in all_impacts}.values()),
        "failures": all_failures,
        "exit_code": exit_code,
        "impact_rules": impact_rules,
        "parity_check": {
            "broken": parity_broken,
            "stale": parity_stale,
            "clean": (parity_broken == 0 and parity_stale == 0),
            "failures": parity_payload,
        },
    }


def _get_file_timestamp(file_path: Path, *, repo_root: Path | None = None) -> float | None:
    run_kw: dict[str, object] = {"capture_output": True, "text": True}
    if repo_root is not None:
        run_kw["cwd"] = str(repo_root.resolve())  # cwd required — tool may be called from any working directory
    result = subprocess.run(
        ["git", "log", "-1", "--format=%ct", "--", str(file_path)],
        **run_kw,
    )
    if result.returncode == 0 and result.stdout.strip():
        try:
            return float(result.stdout.strip())
        except ValueError:
            pass
    if file_path.exists():
        return file_path.stat().st_mtime
    return None


def _check_parity_edges(graph: Any, project_path: Path) -> list[VerifyFailure]:
    node_by_id = {n.id: n for n in getattr(graph, "nodes", [])}
    parity_edges = [
        e for e in getattr(graph, "edges", [])
        if (getattr(e, "edge_kind", None) == "parity" or getattr(e, "relation", None) == "parity")
    ]
    failures: list[VerifyFailure] = []

    for edge in parity_edges:
        from_id = str(getattr(edge, "from_id", ""))
        to_id = str(getattr(edge, "to_id", ""))
        node_a = node_by_id.get(from_id)
        node_b = node_by_id.get(to_id)

        if node_a and not node_b:
            failures.append(
                VerifyFailure(
                    kind="broken-parity",
                    severity="error",
                    message=f"parity pair broken: {from_id} exists but {to_id} missing",
                    node=from_id,
                    adr="ADR-017",
                )
            )
            continue
        if node_b and not node_a:
            failures.append(
                VerifyFailure(
                    kind="broken-parity",
                    severity="error",
                    message=f"parity pair broken: {to_id} exists but {from_id} missing",
                    node=to_id,
                    adr="ADR-017",
                )
            )
            continue
        if not (node_a and node_b):
            continue

        edge_meta = getattr(edge, "meta", {}) or {}
        staleness_check = getattr(edge, "staleness_check", None)
        if staleness_check is None:
            staleness_check = edge_meta.get("staleness_check", True)
        if staleness_check is False:
            continue

        node_a_path = str(getattr(node_a, "path", "") or "")
        node_b_path = str(getattr(node_b, "path", "") or "")
        ts_a = (
            _get_file_timestamp(project_path / node_a_path, repo_root=project_path)
            if node_a_path
            else None
        )
        ts_b = (
            _get_file_timestamp(project_path / node_b_path, repo_root=project_path)
            if node_b_path
            else None
        )
        if ts_a and ts_b and ts_a != ts_b:
            newer = from_id if ts_a > ts_b else to_id
            older = to_id if ts_a > ts_b else from_id
            failures.append(
                VerifyFailure(
                    kind="stale-parity",
                    severity="warning",
                    message=(
                        f"parity drift: {newer} modified more recently than {older} "
                        "— both must update together"
                    ),
                    node=newer,
                    adr="ADR-017",
                )
            )
    return failures


# ── Schema validation ─────────────────────────────────────────────────────────

def _load_manifest_raw(project_path: Path) -> dict[str, Any]:
    """Load project manifest via :class:`~forge.core.manifest_document.ManifestDocument`."""
    from forge.core.manifest_document import ManifestDocument

    try:
        doc = ManifestDocument.from_path(resolve_project_path(project_path))
        return dict(doc.to_legacy_dict())
    except (FileNotFoundError, ValueError):
        return {}


def _run_validate_schema(project_path: Path) -> tuple[list[dict[str, Any]], int, int]:
    """
    Validate every module node against node_schemas[kind=module].

    Returns:
        (violations, passed_count, total_count)

    Each violation dict matches the structured failure shape:
        {
            "code":    "CON-001",
            "level":   3,
            "node_id": "module/<name>",
            "field":   "<missing_field>",
            "message": "required field '<field>' missing on module/<name>",
        }
    """
    raw = _load_manifest_raw(project_path)
    modules: list[dict[str, Any]] = [
        m for m in (raw.get("modules") or []) if isinstance(m, dict)
    ]

    # Find the module schema — only "module" kind is expected right now.
    schemas: list[dict[str, Any]] = raw.get("node_schemas") or []
    module_schema = next(
        (s for s in schemas if isinstance(s, dict) and s.get("kind") == "module"),
        None,
    )
    if module_schema is None:
        return [], 0, len(modules)  # no schema to validate against

    required_fields: list[str] = list(module_schema.get("required_fields") or [])
    prefix: str = str(module_schema.get("error_code_prefix") or "CON")

    violations: list[dict[str, Any]] = []
    passed = 0

    for mod in modules:
        name = str(mod.get("name") or mod.get("id") or "unknown")
        node_id = f"module/{name}"
        node_violations: list[dict[str, Any]] = []

        for field in required_fields:
            val = mod.get(field)
            # Only flag fields that are truly absent (not set at all).
            # An explicit empty list [] is valid — do not treat as missing.
            if val is None:
                node_violations.append({
                    "code": f"{prefix}-001",
                    "level": 3,
                    "node_id": node_id,
                    "field": field,
                    "message": f"required field '{field}' missing on {node_id}",
                })

        if node_violations:
            violations.extend(node_violations)
        else:
            passed += 1

    return violations, passed, len(modules)


def _check_c006_manifest_io(project_path: Path) -> list[dict[str, Any]]:
    """
    C006 — All manifest.yaml I/O must go through ManifestParser / ManifestDocument.

    Detects the parser-divergence bug pattern: a file that both reads an
    existing project manifest via yaml.safe_load/load AND writes it back via
    yaml.dump/safe_dump, bypassing the sanctioned parse/write path.  This was
    the root cause of the forge_impact_check and scaffolder.execute() bugs.

    Exclusions (documented):
      forge/core/manifest.py — the sanctioned ManifestParser path itself
      forge/core/template.py — creates brand-new manifest files from Jinja
                               templates during project init; not mutating
      forge/**/tests/**      — test fixtures legitimately use yaml.safe_dump
                               to build tmp manifest files
    """
    import re as _re

    violations: list[dict[str, Any]] = []
    forge_dir = project_path / "forge"
    if not forge_dir.is_dir():
        return violations

    _EXCLUSIONS = {
        "forge/core/manifest.py",   # sanctioned I/O path
        "forge/core/template.py",   # project-init creation, not mutation
    }

    # Read side (loading existing manifest content)
    _yaml_read = _re.compile(r"\byaml\.(safe_load|load)\b")
    # Write side (dumping back to disk)
    _yaml_write = _re.compile(r"\byaml\.(dump|safe_dump)\b")
    # A manifest-path variable being assigned to a manifest.yaml path
    _manifest_assign = _re.compile(
        r"(manifest_path|candidate|manifest_file|mp)\s*=.*manifest\.yaml"
    )
    # That same variable being written back via .write_text
    _manifest_write = _re.compile(
        r"(manifest_path|candidate|manifest_file|mp)\s*\.write_text"
    )

    for py_file in sorted(forge_dir.rglob("*.py")):
        try:
            rel = py_file.relative_to(project_path)
        except ValueError:
            continue
        rel_str = str(rel)
        if rel_str in _EXCLUSIONS:
            continue
        if "/tests/" in rel_str:
            continue
        try:
            text = py_file.read_text(encoding="utf-8")
        except OSError:
            continue
        # Fire only when the full mutation pattern is present:
        # read (yaml.safe_load) + write (yaml.dump) + manifest var assigned
        # + that manifest var written back via .write_text.
        if (
            _yaml_read.search(text)
            and _yaml_write.search(text)
            and _manifest_assign.search(text)
            and _manifest_write.search(text)
        ):
            violations.append({
                "code": "C006",
                "level": 3,
                "node_id": rel_str,
                "field": "manifest_io",
                "message": (
                    f"C006: raw yaml mutation of manifest.yaml in {rel_str} — "
                    "use ManifestParser.append_node() or update_node() instead"
                ),
            })

    return violations


def _check_error_code_storage(project_path: Path) -> list[dict[str, Any]]:
    raw = _load_manifest_raw(project_path)
    cfg = raw.get("error_codes")
    if not isinstance(cfg, dict):
        return []
    storage = str(cfg.get("storage") or "").strip()
    if not storage:
        return [{
            "code": "ERR-001",
            "level": 3,
            "node_id": "error_codes",
            "field": "storage",
            "message": "error_codes declared but storage path is missing",
        }]
    storage_file = project_path / storage
    if not storage_file.is_file():
        return [{
            "code": "ERR-001",
            "level": 3,
            "node_id": "error_codes",
            "field": "storage",
            "message": f"error_codes storage file missing: {storage}",
        }]
    text = storage_file.read_text(encoding="utf-8", errors="ignore")
    if "GENERATED FILE" not in text:
        return [{
            "code": "ERR-002",
            "level": 3,
            "node_id": "error_codes",
            "field": "storage",
            "message": (
                "error_codes storage missing generated header comment; "
                "regenerate via forge scaffold --entry-type error_codes --refresh error_codes"
            ),
        }]
    return []


def _write_result(result: dict[str, Any], project_path: Path) -> Path:
    out_dir = project_path / ".forge"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "verify-last.json"
    # NOT YAML: verify-last.json uses json module (correct)
    out_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    return out_path


def empty_verify_result() -> dict[str, Any]:
    """Clean verify payload when there are no files to check (MCP / programmatic use)."""
    return {
        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        "changed_nodes": [],
        "skipped_files": [],
        "impacts": [],
        "failures": [],
        "exit_code": 0,
        "impact_rules": {"matches": [], "unknown_pairs": []},
        "parity_check": {
            "broken": 0,
            "stale": 0,
            "clean": True,
            "failures": [],
        },
    }


def resolve_mcp_verify_files(target: str, project_path: Path) -> list[str]:
    """Map MCP ``target`` to repo-relative paths for ``_run_verify``."""
    t = (target or "").strip()
    if t.lower() == "staged":
        return _git_changed_files(staged=True, cwd=project_path)
    if t.lower() == "full":
        return _git_tracked_files(cwd=project_path)
    if t.lower() in ("unstaged", "worktree", "working", "untracked"):
        return _git_changed_files(staged=False, cwd=project_path)
    return [t] if t else []


def run_verify_core(project_path: Path, files: list[str]) -> dict[str, Any]:
    """Run propagation pipeline only (no schema/C006 extras — those stay on the CLI command)."""
    if files:
        return _run_verify(files, project_path, strict=False)
    return empty_verify_result()


def run_verify_cli_parity(project_path: Path, target: str, *, strict: bool = False) -> dict[str, Any]:
    """Run the same structural checks as CLI `forge verify` for a target."""
    from forge.core.manifest import ManifestParser, ValidationError, resolve_manifest_path

    if strict:
        mp = resolve_manifest_path(project_path, warn_on_root_fallback=False)
        if mp is not None and mp.is_file():
            try:
                ManifestParser(mp).parse(strict=True)
            except ValidationError as exc:
                return {
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                    "changed_nodes": [],
                    "skipped_files": [],
                    "impacts": [],
                    "failures": [
                        {
                            "kind": "manifest.strict_stack_fields",
                            "severity": "error",
                            "message": str(exc),
                            "node": "manifest",
                            "adr": "ADR-018",
                        }
                    ],
                    "exit_code": 1,
                    "impact_rules": {"matches": [], "unknown_pairs": []},
                    "parity_check": {"broken": 0, "stale": 0, "clean": True, "failures": []},
                }

    t = (target or "").strip().lower()
    if t == "stack":
        raw = _load_manifest_raw(project_path)
        stack_failures = _check_stack_field_bleed(None, raw, project_path)
        payload = [asdict(f) for f in stack_failures]
        hard_failures = [f for f in payload if str(f.get("severity", "")).lower() != "warning"]
        return {
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            "changed_nodes": [],
            "skipped_files": [],
            "impacts": [],
            "failures": payload,
            "exit_code": 2 if hard_failures else 0,
            "impact_rules": {"matches": [], "unknown_pairs": []},
            "parity_check": {"broken": 0, "stale": 0, "clean": True, "failures": []},
        }
    if t == "stacks":
        schema_failures = _check_stack_schema_contracts(project_path)
        payload = [asdict(f) for f in schema_failures]
        return {
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            "changed_nodes": [],
            "skipped_files": [],
            "impacts": [],
            "failures": payload,
            "exit_code": 2 if payload else 0,
            "impact_rules": {"matches": [], "unknown_pairs": []},
            "parity_check": {"broken": 0, "stale": 0, "clean": True, "failures": []},
        }
    if t == "parity":
        graph = build_manifest_graph(project_path)
        parity_failures = _check_parity_edges(graph, project_path)
        parity_payload = [asdict(f) for f in parity_failures]
        broken = sum(1 for f in parity_failures if f.kind == "broken-parity")
        stale = sum(1 for f in parity_failures if f.kind == "stale-parity")
        return {
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            "changed_nodes": [],
            "skipped_files": [],
            "impacts": [],
            "failures": parity_payload,
            "exit_code": 2 if broken > 0 else (1 if stale > 0 else 0),
            "impact_rules": {"matches": [], "unknown_pairs": []},
            "parity_check": {
                "broken": broken,
                "stale": stale,
                "clean": (broken == 0 and stale == 0),
                "failures": parity_payload,
            },
        }
    files = resolve_mcp_verify_files(target, project_path)
    deleted_files = _git_deleted_files_staged(cwd=project_path) if t == "staged" else []
    if files:
        result = _run_verify(files, project_path, deleted_files=deleted_files, strict=strict)
    elif deleted_files:
        result = _run_verify([], project_path, deleted_files=deleted_files, strict=strict)
    else:
        result = empty_verify_result()
    _extend_verify_with_stack_distribution_checks(result, project_path)
    c006_violations = _check_c006_manifest_io(project_path)
    if c006_violations:
        result["failures"].extend(c006_violations)
        result["exit_code"] = max(int(result["exit_code"]), 2)
    error_code_violations = _check_error_code_storage(project_path)
    if error_code_violations:
        result["failures"].extend(error_code_violations)
        result["exit_code"] = max(int(result["exit_code"]), 2)

    # Status-aware responses for drifted nodes
    graph = build_manifest_graph(project_path, include_discovered=True)
    drifted_violations = []
    for node in graph.nodes:
        if getattr(node, 'status', None) == 'drifted':
            drifted_violations.append({
                "kind": "node_status.drifted",
                "severity": "warning",
                "message": f"Dark matter: {node.id} exists in source but is not declared in manifest.yaml. Add it to the manifest or remove the file.",
                "node": node.id,
                "status": node.status,
            })
    if drifted_violations:
        result["failures"].extend(drifted_violations)
        # Drifted nodes are warnings, don't change exit_code from 0 to 1 unless there are already warnings

    # Exclusion verify pass - check must_not_use constraints
    exclusion_violations = []
    
    # Build node to domain mapping
    node_to_domain = {}
    domain_to_nodes = {}
    for node in graph.nodes:
        if node.domain:
            node_to_domain[node.id] = node.domain
            domain_to_nodes.setdefault(node.domain, []).append(node.id)
    
        
    # Collect all must_not_use constraints (node-level and domain-level)
    must_not_use_constraints = []
    
    # Node-level constraints
    for edge in graph.edges:
        if edge.relation == "must_not_use":
            must_not_use_constraints.append({
                "from_id": edge.from_id,
                "to_id": edge.to_id,
                "type": "node",
                "scope": edge.from_id
            })
    
    # Domain-level constraints - if a domain node has must_not_use edges
    for edge in graph.edges:
        if edge.relation == "must_not_use" and edge.from_id.startswith("domain/"):
            domain_node_id = edge.from_id
            # Find the domain name from the domain node
            domain_node = next((n for n in graph.nodes if n.id == domain_node_id), None)
            if domain_node and domain_node.domain in domain_to_nodes:
                # Apply this constraint to all non-domain nodes in the domain
                for node_id in domain_to_nodes[domain_node.domain]:
                    if not node_id.startswith("domain/"):  # Don't apply to domain nodes themselves
                        must_not_use_constraints.append({
                            "from_id": node_id,
                            "to_id": edge.to_id,
                            "type": "domain",
                            "scope": domain_node_id
                        })
    
    # Check for violations
    for constraint in must_not_use_constraints:
        from_id = constraint["from_id"]
        to_id = constraint["to_id"]
        
        # Check if there's an imports edge that violates this exclusion
        violating_edges = [e for e in graph.edges 
                          if e.from_id == from_id and e.to_id == to_id and e.relation == "imports"]
        if violating_edges:
            exclusion_violations.append({
                "kind": "exclusion.must_not_use_violation",
                "severity": "error",
                "message": f"Node {from_id} must not use {to_id} but imports edge found ({constraint['type']}-level constraint from {constraint['scope']})",
                "node": from_id,
                "target": to_id,
                "constraint_type": constraint["type"],
                "constraint_scope": constraint["scope"],
                "exclusion_edge": f"{from_id} -> {to_id} (must_not_use)",
                "violating_edge": f"{from_id} -> {to_id} (imports)",
            })
    
    if exclusion_violations:
        result["failures"].extend(exclusion_violations)
        result["exit_code"] = max(int(result["exit_code"]), 2)

    if strict:
        g_crit = build_manifest_graph(project_path)
        for nid in result.get("changed_nodes") or []:
            if not isinstance(nid, str) or not nid.strip():
                continue
            inbound = sum(1 for e in g_crit.edges_to(nid) if e.relation == "imports")
            if criticality_label(inbound) != "critical":
                continue
            result["failures"].append(
                {
                    "rule_id": "criticality.critical_node_modified",
                    "severity": "warning",
                    "node": nid,
                    "message": (
                        f"{nid} is critical ({inbound} dependents) — ensure test coverage is updated"
                    ),
                }
            )

    return result


def persist_verify_result(result: dict[str, Any], project_path: Path) -> Path:
    """Write ``.forge/verify-last.json`` after optional fields (e.g. ``strict``) are attached."""
    return _write_result(result, project_path)


def _print_result(result: dict[str, Any]) -> None:
    changed = result["changed_nodes"]
    skipped = result.get("skipped_files", [])
    impacts = result.get("impacts", [])
    failures = result["failures"]

    click.echo(f"changed nodes ({len(changed)}):")
    for nid in changed:
        click.echo(f"  {nid}")

    if skipped:
        click.echo(f"\nno manifest node for ({len(skipped)}):")
        for f in skipped:
            click.echo(f"  {f}")

    if impacts:
        click.echo(f"\nimpacts ({len(impacts)}):")
        for imp in impacts:
            click.echo(
                f"  {imp['node_id']} [{imp['role']}]"
                f" ← {imp['effect']} from {imp['source_node']}"
            )
            if imp["actions"]:
                click.echo(f"    actions: {', '.join(imp['actions'])}")

    # Schema violations are carried in failures with a "code" key.
    schema_failures = [f for f in failures if "code" in f]
    prop_failures = [
        f for f in failures if "code" not in f and str(f.get("severity", "")).lower() != "warning"
    ]
    warn_failures = [f for f in failures if str(f.get("severity", "")).lower() == "warning"]

    if schema_failures:
        click.echo(f"\nschema violations ({len(schema_failures)}):")
        for f in schema_failures:
            click.echo(f"  [{f['code']}] {f['message']}")
            click.echo(f"    node: {f['node_id']}  field: {f['field']}")

    if prop_failures:
        click.echo(f"\npropagation failures ({len(prop_failures)}):")
        for f in prop_failures:
            ftype = f.get("type") or f.get("kind") or "failure"
            msg = f.get("recovery_hint") or f.get("message") or ""
            click.echo(f"  [{ftype}] {msg}")
            ctx = f.get("context") or {}
            if isinstance(ctx, dict):
                for k, v in ctx.items():
                    click.echo(f"    {k}: {v}")

    if warn_failures:
        click.echo(f"\nwarnings ({len(warn_failures)}):")
        for f in warn_failures:
            rid = f.get("rule_id") or "warning"
            click.echo(f"  [{rid}] {f.get('message', '')}")
            if f.get("node"):
                click.echo(f"    node: {f['node']}")

    if not schema_failures and not prop_failures:
        click.echo("\nclean — no propagation failures")

    click.echo(f"\nexit_code: {result['exit_code']}")


def _print_summary(result: dict[str, Any]) -> None:
    """Terse stdout — full detail remains in ``verify-last.json`` only."""
    ir = result.get("impact_rules") or {}
    click.echo(f"changed_nodes: {len(result.get('changed_nodes') or [])}")
    click.echo(f"impact_rule_matches: {len(ir.get('matches') or [])}")
    click.echo("unknown_rule_pairs:")
    for u in ir.get("unknown_pairs") or []:
        click.echo(
            f"  {u.get('node_kind')} × {u.get('effect')} "
            f"({u.get('affected_count')} nodes)"
        )
    click.echo(f"exit_code: {result.get('exit_code')}")


def _run_packet_validate(project_path: Path, packet_path: str) -> None:
    try:
        out, code = validate_packet(
            project_root=project_path,
            packet_path=Path(packet_path).expanduser().resolve(),
        )
    except PacketValidationError as exc:
        click.echo(str(exc), err=True)
        sys.exit(1)
    click.echo(out, nl=False)
    sys.exit(code)


def _run_diff_verify(
    project_path: Path,
    diff_mode: str,
    diff_domain: str | None,
    diff_verbose: bool,
) -> None:
    try:
        out, code = run_verify_diff(
            project_root=project_path,
            mode=diff_mode,
            domain=diff_domain,
            verbose=diff_verbose,
        )
    except VerifyDiffError as exc:
        click.echo(str(exc), err=True)
        sys.exit(1)
    if out:
        click.echo(out, nl=False)
    sys.exit(code)


def _run_preflight(exit_code_mode: bool, app_manifest: str | None, node_manifests: str | None) -> None:
    try:
        report = run_preflight(
            app_manifest_path=app_manifest,
            node_manifests_dir=node_manifests,
        )
    except PreflightError as exc:
        click.echo(f"preflight failed: {exc}", err=True)
        sys.exit(1)
    click.echo(yaml.safe_dump(report, sort_keys=False))
    code = int(report.get("exit_code", 1))
    if exit_code_mode:
        sys.exit(code)
    sys.exit(code)


def _run_legacy_verify(
    *,
    staged: bool,
    file_path: str | None,
    full: bool,
    validate_schema: bool,
    project_path: Path,
    strict: bool,
    scope: str,
    exit_code_mode: bool,
    summary: bool,
) -> None:
    if strict:
        from forge.core.manifest import ManifestParser, ValidationError, resolve_manifest_path

        mp = resolve_manifest_path(project_path, warn_on_root_fallback=False)
        if mp is not None and mp.is_file():
            try:
                ManifestParser(mp).parse(strict=True)
            except ValidationError as exc:
                result = {
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                    "changed_nodes": [],
                    "skipped_files": [],
                    "impacts": [],
                    "failures": [
                        {
                            "kind": "manifest.strict_stack_fields",
                            "severity": "error",
                            "message": str(exc),
                            "node": "manifest",
                            "adr": "ADR-018",
                        }
                    ],
                    "exit_code": 1,
                    "impact_rules": {"matches": [], "unknown_pairs": []},
                    "parity_check": {"broken": 0, "stale": 0, "clean": True, "failures": []},
                }
                if exit_code_mode:
                    sys.exit(1)
                if summary:
                    _print_summary(result)
                else:
                    _print_result(result)
                out_path = _write_result(result, project_path)
                click.echo(f"\nresult written → {out_path}")
                sys.exit(1)

    if scope.lower() == "stack":
        raw = _load_manifest_raw(project_path)
        stack_failures = _check_stack_field_bleed(None, raw, project_path)
        payload = [asdict(f) for f in stack_failures]
        hard_failures = [f for f in payload if str(f.get("severity", "")).lower() != "warning"]
        result = {
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            "changed_nodes": [],
            "skipped_files": [],
            "impacts": [],
            "failures": payload,
            "exit_code": 2 if hard_failures else 0,
            "impact_rules": {"matches": [], "unknown_pairs": []},
            "parity_check": {"broken": 0, "stale": 0, "clean": True, "failures": []},
        }
        if exit_code_mode:
            sys.exit(result["exit_code"])
        if summary:
            _print_summary(result)
        else:
            _print_result(result)
        out_path = _write_result(result, project_path)
        click.echo(f"\nresult written → {out_path}")
        sys.exit(result["exit_code"])

    if scope.lower() == "stacks":
        schema_failures = _check_stack_schema_contracts(project_path)
        payload = [asdict(f) for f in schema_failures]
        result = {
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            "changed_nodes": [],
            "skipped_files": [],
            "impacts": [],
            "failures": payload,
            "exit_code": 2 if payload else 0,
            "impact_rules": {"matches": [], "unknown_pairs": []},
            "parity_check": {"broken": 0, "stale": 0, "clean": True, "failures": []},
        }
        if exit_code_mode:
            sys.exit(result["exit_code"])
        if summary:
            _print_summary(result)
        else:
            _print_result(result)
        out_path = _write_result(result, project_path)
        click.echo(f"\nresult written → {out_path}")
        sys.exit(result["exit_code"])

    if scope.lower() == "parity":
        graph = build_manifest_graph(project_path)
        parity_failures = _check_parity_edges(graph, project_path)
        parity_payload = [asdict(f) for f in parity_failures]
        broken = sum(1 for f in parity_failures if f.kind == "broken-parity")
        stale = sum(1 for f in parity_failures if f.kind == "stale-parity")
        result = {
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            "changed_nodes": [],
            "skipped_files": [],
            "impacts": [],
            "failures": parity_payload,
            "exit_code": 2 if broken > 0 else (1 if stale > 0 else 0),
            "impact_rules": {"matches": [], "unknown_pairs": []},
            "parity_check": {
                "broken": broken,
                "stale": stale,
                "clean": (broken == 0 and stale == 0),
                "failures": parity_payload,
            },
        }
        if exit_code_mode:
            sys.exit(result["exit_code"])
        if summary:
            _print_summary(result)
        else:
            _print_result(result)
        out_path = _write_result(result, project_path)
        click.echo(f"\nresult written → {out_path}")
        sys.exit(result["exit_code"])

    if file_path is not None:
        files = [file_path]
        deleted_files: list[str] = []
    elif full:
        files = _git_tracked_files(cwd=project_path)
        deleted_files = []
    elif staged:
        files = _git_changed_files(staged=True, cwd=project_path)
        deleted_files = _git_deleted_files_staged(cwd=project_path)
    else:
        files = _git_changed_files(staged=False, cwd=project_path)
        deleted_files = []

    if files:
        click.echo(f"verifying {len(files)} file(s) against manifest graph...\n")
        result = _run_verify(files, project_path, deleted_files=deleted_files, strict=strict)
    elif deleted_files:
        click.echo(f"verifying {len(deleted_files)} deleted file(s) against manifest graph...\n")
        result = _run_verify([], project_path, deleted_files=deleted_files, strict=strict)
    else:
        click.echo("no files to verify — skipping propagation check\n")
        result = {
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            "changed_nodes": [],
            "skipped_files": [],
            "impacts": [],
            "failures": [],
            "exit_code": 0,
            "impact_rules": {"matches": [], "unknown_pairs": []},
        }

    _extend_verify_with_stack_distribution_checks(result, project_path)

    if validate_schema:
        click.echo("running schema validation against node_schemas...\n")
        violations, passed, total = _run_validate_schema(project_path)
        click.echo(f"  modules checked : {total}")
        click.echo(f"  passed          : {passed}")
        click.echo(f"  violations      : {len(violations)}\n")
        result["failures"].extend(violations)
        result["schema_validation"] = {
            "total": total,
            "passed": passed,
            "violations": len(violations),
        }
        if violations:
            result["exit_code"] = max(int(result["exit_code"]), 2)

    c006_violations = _check_c006_manifest_io(project_path)
    if c006_violations:
        result["failures"].extend(c006_violations)
        result["exit_code"] = max(int(result["exit_code"]), 2)

    error_code_violations = _check_error_code_storage(project_path)
    if error_code_violations:
        result["failures"].extend(error_code_violations)
        result["exit_code"] = max(int(result["exit_code"]), 2)

    if strict:
        g_crit = build_manifest_graph(project_path)
        for nid in result.get("changed_nodes") or []:
            if not isinstance(nid, str) or not nid.strip():
                continue
            inbound = sum(1 for e in g_crit.edges_to(nid) if e.relation == "imports")
            if criticality_label(inbound) != "critical":
                continue
            result["failures"].append(
                {
                    "rule_id": "criticality.critical_node_modified",
                    "severity": "warning",
                    "node": nid,
                    "message": (
                        f"{nid} is critical ({inbound} dependents) — ensure test coverage is updated"
                    ),
                }
            )

    if exit_code_mode:
        sys.exit(result["exit_code"])
    if summary:
        _print_summary(result)
    else:
        _print_result(result)

    out_path = _write_result(result, project_path)
    click.echo(f"\nresult written → {out_path}")

    sys.exit(result["exit_code"])


# ── CLI entry point ───────────────────────────────────────────────────────────

@click.command()
@click.option(
    "--staged", is_flag=True, default=False,
    help="Check staged files only (git diff --cached).",
)
@click.option(
    "--file", "file_path", default=None, metavar="FILE",
    help="Check a single file path.",
)
@click.option(
    "--full", is_flag=True, default=False,
    help="Check all files tracked by git.",
)
@click.option(
    "--validate-schema", "validate_schema", is_flag=True, default=False,
    help="Validate all manifest module nodes against node_schemas. Runs after propagation checks.",
)
@click.option(
    "--project-path", "project_path_str", default=".", metavar="PATH",
    help="Project root (default: cwd).",
)
@click.option(
    "--strict",
    "strict",
    is_flag=True,
    default=False,
    help=(
        "Strict mode: fail with exit code 1 if manifest module fields violate the "
        "declared stack schema (unknown / cross-stack fields). Also runs stack bleed "
        "criticality hints (ADR-013) after propagation."
    ),
)
@click.option(
    "--scope",
    "scope",
    type=click.Choice(["all", "parity", "stack", "stacks"], case_sensitive=False),
    default="all",
    show_default=True,
    help="Run full verify pipeline or parity-only checks.",
)
@click.option(
    "--exit-code",
    "exit_code_mode",
    is_flag=True,
    default=False,
    help="CI gate mode: return exit code only.",
)
@click.option(
    "--summary",
    "summary",
    is_flag=True,
    default=False,
    help="Print counts and deduped rule summary only; full detail in verify-last.json.",
)
@click.option(
    "--preflight",
    "preflight",
    is_flag=True,
    default=False,
    help="Run pre-generation manifest wiring checks.",
)
@click.option(
    "--app-manifest",
    "app_manifest",
    default=None,
    metavar="PATH",
    help="Path to app manifest YAML for preflight mode.",
)
@click.option(
    "--node-manifests",
    "node_manifests",
    default=None,
    metavar="DIR",
    help="Directory containing node manifest YAML files for preflight mode.",
)
@click.option(
    "--diff",
    "diff_mode",
    type=click.Choice(["plan", "wiring", "contracts", "all"], case_sensitive=False),
    default=None,
    help="Run scaffold diff checks: plan, wiring, contracts, or all.",
)
@click.option(
    "--domain",
    "diff_domain",
    default=None,
    metavar="DOMAIN",
    help="Optional domain filter for --diff modes.",
)
@click.option(
    "--verbose",
    "diff_verbose",
    is_flag=True,
    default=False,
    help="Show fully satisfied domains in --diff plan output.",
)
@click.option(
    "--packet",
    "packet_path",
    default=None,
    metavar="PACKET_PATH",
    help="Validate a context packet before execution.",
)
@response_tier_option(default="L1")
def verify_cmd(
    staged: bool,
    file_path: str | None,
    full: bool,
    validate_schema: bool,
    project_path_str: str,
    strict: bool,
    scope: str,
    exit_code_mode: bool,
    summary: bool,
    preflight: bool,
    app_manifest: str | None,
    node_manifests: str | None,
    diff_mode: str | None,
    diff_domain: str | None,
    diff_verbose: bool,
    packet_path: str | None,
    response_tier: str,
) -> None:
    """Map changed files to manifest nodes and run propagation impact check."""
    _ = response_tier
    project_path = resolve_project_path(project_path_str)
    if packet_path:
        _run_packet_validate(project_path, packet_path)
    if diff_mode:
        _run_diff_verify(project_path, diff_mode, diff_domain, diff_verbose)
    if preflight:
        _run_preflight(exit_code_mode, app_manifest, node_manifests)

    _run_legacy_verify(
        staged=staged,
        file_path=file_path,
        full=full,
        validate_schema=validate_schema,
        project_path=project_path,
        strict=strict,
        scope=scope,
        exit_code_mode=exit_code_mode,
        summary=summary,
    )
