"""Forge snapshot CLI commands for INTENT-B36D0989.

CLI commands for snapshot push/pull operations and snapshot management.
"""

import argparse
import json
import logging
import sys
from pathlib import Path

from forge.core.path_utils import resolve_project_path
from forge.core.snapshots import (
    SnapshotType,
    get_snapshot_manager,
    create_snapshot,
    restore_snapshot,
    list_snapshots
)

logger = logging.getLogger(__name__)


def cmd_snapshot_create(args):
    """Create a snapshot."""
    try:
        project_path = resolve_project_path()
        
        # Determine snapshot type
        snapshot_type = args.type
        if snapshot_type == "full":
            snapshot_type_enum = SnapshotType.FULL
        elif snapshot_type == "incremental":
            snapshot_type_enum = SnapshotType.INCREMENTAL
        elif snapshot_type == "session":
            snapshot_type_enum = SnapshotType.SESSION
        else:
            print(f"Error: Invalid snapshot type: {snapshot_type}")
            return 1
        
        # Get parent snapshot ID if incremental
        parent_id = args.parent if args.parent else None
        
        # Create snapshot
        snapshot_id = create_snapshot(
            snapshot_type=snapshot_type.value,
            project_path=str(project_path),
            parent_snapshot_id=parent_id
        )
        
        if snapshot_id:
            print(f"✅ Created snapshot: {snapshot_id}")
            
            # Push to remote if requested
            if args.push:
                manager = get_snapshot_manager(Path(project_path))
                if manager.push_to_remote(snapshot_id):
                    print(f"✅ Pushed snapshot to remote: {snapshot_id}")
                else:
                    print(f"⚠️  Failed to push snapshot to remote: {snapshot_id}")
            
            return 0
        else:
            print("❌ Failed to create snapshot")
            return 1
            
    except Exception as e:
        print(f"❌ Error creating snapshot: {e}")
        return 1


def cmd_snapshot_restore(args):
    """Restore a snapshot."""
    try:
        project_path = resolve_project_path()
        
        success = restore_snapshot(args.id, project_path=str(project_path))
        
        if success:
            print(f"✅ Restored snapshot: {args.id}")
            return 0
        else:
            print(f"❌ Failed to restore snapshot: {args.id}")
            return 1
            
    except Exception as e:
        print(f"❌ Error restoring snapshot: {e}")
        return 1


def cmd_snapshot_list(args):
    """List snapshots."""
    try:
        project_path = resolve_project_path()
        
        snapshots = list_snapshots(limit=args.limit, project_path=str(project_path))
        
        if not snapshots:
            print("No snapshots found")
            return 0
        
        print(f"Found {len(snapshots)} snapshots:")
        print()
        
        for snapshot in snapshots:
            status_symbol = "✅" if snapshot["status"] == "completed" else "❌"
            created_at = snapshot["created_at"]
            size_mb = snapshot["size_bytes"] / (1024 * 1024)
            
            print(f"{status_symbol} {snapshot['id'][:8]}...  {snapshot['snapshot_type']}  "
                  f"{created_at:.0f}  {size_mb:.2f}MB  {snapshot['status']}")
            
            if args.verbose:
                print(f"   Workspace: {snapshot['workspace_id']}")
                print(f"   Forge version: {snapshot['forge_version']}")
                print(f"   Schema version: {snapshot['schema_version']}")
                if snapshot['parent_snapshot_id']:
                    print(f"   Parent: {snapshot['parent_snapshot_id'][:8]}...")
                print()
        
        return 0
        
    except Exception as e:
        print(f"❌ Error listing snapshots: {e}")
        return 1


def cmd_snapshot_delete(args):
    """Delete a snapshot."""
    try:
        project_path = resolve_project_path()
        manager = get_snapshot_manager(Path(project_path))
        
        success = manager.delete_snapshot(args.id)
        
        if success:
            print(f"✅ Deleted snapshot: {args.id}")
            return 0
        else:
            print(f"❌ Failed to delete snapshot: {args.id}")
            return 1
            
    except Exception as e:
        print(f"❌ Error deleting snapshot: {e}")
        return 1


def cmd_snapshot_push(args):
    """Push snapshots to remote store."""
    try:
        project_path = resolve_project_path()
        manager = get_snapshot_manager(Path(project_path))
        
        if args.id:
            # Push specific snapshot
            success = manager.push_to_remote(args.id)
            if success:
                print(f"✅ Pushed snapshot to remote: {args.id}")
            else:
                print(f"❌ Failed to push snapshot to remote: {args.id}")
        else:
            # Push latest snapshot
            latest = manager.get_latest_snapshot()
            if latest:
                success = manager.push_to_remote(latest.id)
                if success:
                    print(f"✅ Pushed latest snapshot to remote: {latest.id}")
                else:
                    print(f"❌ Failed to push latest snapshot to remote: {latest.id}")
            else:
                print("❌ No snapshots found to push")
                return 1
        
        return 0 if success else 1
        
    except Exception as e:
        print(f"❌ Error pushing snapshot: {e}")
        return 1


def cmd_snapshot_pull(args):
    """Pull snapshots from remote store."""
    try:
        project_path = resolve_project_path()
        manager = get_snapshot_manager(Path(project_path))
        
        if args.id:
            # Pull specific snapshot
            success = manager.pull_from_remote(args.id)
            if success:
                print(f"✅ Pulled snapshot from remote: {args.id}")
            else:
                print(f"❌ Failed to pull snapshot from remote: {args.id}")
        else:
            # Pull latest snapshot
            success = manager.pull_from_remote()
            if success:
                print("✅ Pulled latest snapshot from remote")
            else:
                print("❌ Failed to pull latest snapshot from remote")
                return 1
        
        return 0 if success else 1
        
    except Exception as e:
        print(f"❌ Error pulling snapshot: {e}")
        return 1


def cmd_snapshot_status(args):
    """Show snapshot status and statistics."""
    try:
        project_path = resolve_project_path()
        manager = get_snapshot_manager(Path(project_path))
        
        print(f"Workspace ID: {manager.workspace_id}")
        print(f"Project path: {project_path}")
        print(f"Forge version: {manager.forge_version}")
        print()
        
        # Local snapshots
        local_snapshots = manager.list_snapshots(limit=1000)
        print(f"Local snapshots: {len(local_snapshots)}")
        
        if local_snapshots:
            # Count by type
            type_counts = {}
            status_counts = {}
            total_size = 0
            
            for snapshot in local_snapshots:
                snapshot_type = snapshot["snapshot_type"]
                status = snapshot["status"]
                size = snapshot["size_bytes"]
                
                type_counts[snapshot_type] = type_counts.get(snapshot_type, 0) + 1
                status_counts[status] = status_counts.get(status, 0) + 1
                total_size += size
            
            print("  By type:")
            for stype, count in type_counts.items():
                print(f"    {stype}: {count}")
            
            print("  By status:")
            for status, count in status_counts.items():
                print(f"    {status}: {count}")
            
            print(f"  Total size: {total_size / (1024 * 1024):.2f} MB")
        
        # Latest snapshot
        latest = manager.get_latest_snapshot()
        if latest:
            print(f"Latest snapshot: {latest.id[:8]}... ({latest.snapshot_type})")
            print(f"  Created: {latest.created_at:.0f}")
            if latest.completed_at:
                print(f"  Completed: {latest.completed_at:.0f}")
        else:
            print("No snapshots found")
        
        # Remote store status
        if manager.remote_store:
            print("Remote store: Available")
        else:
            print("Remote store: Not configured")
        
        return 0
        
    except Exception as e:
        print(f"❌ Error getting snapshot status: {e}")
        return 1


def add_snapshot_parser(subparsers):
    """Add snapshot commands to argument parser."""
    snapshot_parser = subparsers.add_parser('snapshot', help='Forge snapshot commands')
    snapshot_subparsers = snapshot_parser.add_subparsers(dest='snapshot_command', help='Snapshot commands')
    
    # Create command
    create_parser = snapshot_subparsers.add_parser('create', help='Create a snapshot')
    create_parser.add_argument('--type', choices=['full', 'incremental', 'session'], 
                              default='full', help='Snapshot type (default: full)')
    create_parser.add_argument('--parent', help='Parent snapshot ID (for incremental)')
    create_parser.add_argument('--push', action='store_true', 
                              help='Push to remote store after creation')
    create_parser.set_defaults(func=cmd_snapshot_create)
    
    # Restore command
    restore_parser = snapshot_subparsers.add_parser('restore', help='Restore a snapshot')
    restore_parser.add_argument('id', help='Snapshot ID to restore')
    restore_parser.set_defaults(func=cmd_snapshot_restore)
    
    # List command
    list_parser = snapshot_subparsers.add_parser('list', help='List snapshots')
    list_parser.add_argument('--limit', type=int, default=20, help='Number of snapshots to show (default: 20)')
    list_parser.add_argument('--verbose', '-v', action='store_true', help='Show detailed information')
    list_parser.set_defaults(func=cmd_snapshot_list)
    
    # Delete command
    delete_parser = snapshot_subparsers.add_parser('delete', help='Delete a snapshot')
    delete_parser.add_argument('id', help='Snapshot ID to delete')
    delete_parser.set_defaults(func=cmd_snapshot_delete)
    
    # Push command
    push_parser = snapshot_subparsers.add_parser('push', help='Push snapshots to remote store')
    push_parser.add_argument('--id', help='Specific snapshot ID to push (default: latest)')
    push_parser.set_defaults(func=cmd_snapshot_push)
    
    # Pull command
    pull_parser = snapshot_subparsers.add_parser('pull', help='Pull snapshots from remote store')
    pull_parser.add_argument('--id', help='Specific snapshot ID to pull (default: latest)')
    pull_parser.set_defaults(func=cmd_snapshot_pull)
    
    # Status command
    status_parser = snapshot_subparsers.add_parser('status', help='Show snapshot status')
    status_parser.set_defaults(func=cmd_snapshot_status)


def main():
    """Main entry point for snapshot commands."""
    parser = argparse.ArgumentParser(description='Forge snapshot CLI')
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Add snapshot commands
    add_snapshot_parser(subparsers)
    
    # Parse arguments
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    # Execute command
    if hasattr(args, 'func'):
        return args.func(args)
    else:
        print(f"Unknown command: {args.command}")
        return 1


if __name__ == '__main__':
    sys.exit(main())
