"""
forge/gloves/dart_glove/__init__.py

Flutter/Dart ComposerCanvas implementation.

Maps Pixionary's proven patterns to
forge composer primitives:

  lib/features/*/variants/*.dart
    → ComponentDescriptor (kind=MOLECULE)

  lib/features/*/*_screen.dart
    → LayoutDescriptor with slots:
        default (required)
        variant (accepts MOLECULE/ISLAND)

  lib/ui/components/*.dart
    → ComponentDescriptor (kind=ATOM)

  lib/core/*_controller.dart
    → ComponentDescriptor (kind=ORGANISM)

  lib/core/*_service.dart
    → ComponentDescriptor (kind=ORGANISM)

Registers as "flutter-app" in
the composer registry on import.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from forge.core.errors import (
    CausalHop,
    ErrorCode,
    ErrorLayer,
    ForgeError,
)
from forge.core.composer import (
    ComponentDescriptor,
    ComponentKind,
    LayoutDescriptor,
    SlotBinding,
    SlotContract,
    register_composer,
)


# ── Path → kind mapping ───────────────

def _kind_for_path(path: Path) -> ComponentKind:
    """
    Infer ComponentKind from file path.

    Pixionary conventions:
      variants/   → MOLECULE (UI variant)
      components/ → ATOM (shared widget)
      controller  → ORGANISM (business logic)
      service     → ORGANISM (external boundary)
      screen      → LAYOUT (router)
      model       → not a component
    """
    parts = path.parts
    name = path.stem.lower()

    if "variants" in parts:
        return ComponentKind.MOLECULE
    if "components" in parts or "widgets" in parts:
        return ComponentKind.ATOM
    if name.endswith("_controller"):
        return ComponentKind.ORGANISM
    if name.endswith("_service"):
        return ComponentKind.ORGANISM
    if name.endswith("_screen"):
        return ComponentKind.LAYOUT
    if "sandbox" in parts or "debug" in parts:
        return ComponentKind.ATOM
    return ComponentKind.MOLECULE


def _domain_for_path(path: Path) -> str:
    """
    Infer domain from file path.

    lib/features/auth/... → AUTH
    lib/features/game/... → GAME
    lib/core/...          → CORE
    lib/ui/...            → UI
    lib/data/...          → DATA
    """
    parts = [p.upper() for p in path.parts]

    if "FEATURES" in parts:
        idx = parts.index("FEATURES")
        if idx + 1 < len(parts):
            return parts[idx + 1]
    if "CORE" in parts:
        return "CORE"
    if "UI" in parts:
        return "UI"
    if "DATA" in parts:
        return "DATA"
    if "DEBUG" in parts or "SANDBOX" in parts:
        return "DEBUG"
    return "UNKNOWN"


def _node_id_for_path(
    path: Path,
    kind: ComponentKind,
    project_root: Path,
) -> str:
    """
    Generate a forge manifest node id
    from a file path.

    lib/features/auth/variants/login_v1.dart
    → component/auth.login_v1

    lib/features/game/game_screen.dart
    → screen/game.game

    lib/ui/components/avatar_circle.dart
    → component/ui.avatar_circle
    """
    try:
        rel = path.relative_to(project_root / "lib")
    except ValueError:
        rel = path

    name = path.stem

    kind_prefix = {
        ComponentKind.LAYOUT: "screen",
        ComponentKind.ORGANISM: "controller",
        ComponentKind.MOLECULE: "component",
        ComponentKind.ATOM: "component",
        ComponentKind.ISLAND: "component",
    }.get(kind, "module")

    domain = _domain_for_path(path).lower()

    # Strip _screen suffix from layout names
    if kind == ComponentKind.LAYOUT:
        name = re.sub(r"_screen$", "", name)

    return f"{kind_prefix}/{domain}.{name}"


# ── Layout slot contracts ─────────────

def _default_flutter_layout() -> tuple[SlotContract, ...]:
    """
    Default slot contracts for a Flutter
    screen (LayoutDescriptor).

    Pixionary pattern:
      default slot → required, any kind
      variant slot → optional, MOLECULE/ISLAND
    """
    return (
        SlotContract(
            name="default",
            required=True,
            description=(
                "Main content. Usually filled "
                "by the active variant."
            ),
        ),
        SlotContract(
            name="variant",
            accepted_kinds=(
                ComponentKind.MOLECULE,
                ComponentKind.ISLAND,
            ),
            required=False,
            description=(
                "Active UI variant. "
                "Selected by UiLab or config."
            ),
        ),
    )


# ── Discovery ─────────────────────────

def _discover_dart_files(
    project_root: Path,
) -> list[Path]:
    """Find all .dart files under lib/."""
    lib = project_root / "lib"
    if not lib.exists():
        return []
    return [
        p
        for p in lib.rglob("*.dart")
        if not any(part.startswith(".") for part in p.parts)
        and p.stat().st_size < 500_000
    ]


def _path_to_component(
    path: Path,
    project_root: Path,
) -> ComponentDescriptor | None:
    """
    Convert a .dart file to a
    ComponentDescriptor.
    Returns None for model/data files.
    """
    name = path.stem.lower()

    # Skip non-component files
    skip_patterns = [
        "_model",
        ".g.",
        ".freezed.",
        "database.types",
        "pubspec",
    ]
    if any(p in name for p in skip_patterns):
        return None
    if "models" in path.parts:
        return None

    kind = _kind_for_path(path)
    domain = _domain_for_path(path)
    node_id = _node_id_for_path(path, kind, project_root)

    # Infer fillable slots from path
    fillable: tuple[str, ...] = ()
    if "variants" in path.parts:
        fillable = ("variant", "default")

    return ComponentDescriptor(
        node_id=node_id,
        label=path.stem,
        kind=kind,
        domain=domain,
        path=str(path.relative_to(project_root)),
        fillable_slots=fillable,
        stack="flutter-app",
    )


def _path_to_layout(
    path: Path,
    project_root: Path,
) -> LayoutDescriptor | None:
    """
    Convert a *_screen.dart file to a
    LayoutDescriptor.
    """
    if not path.stem.endswith("_screen"):
        return None

    domain = _domain_for_path(path)
    node_id = _node_id_for_path(path, ComponentKind.LAYOUT, project_root)

    return LayoutDescriptor(
        node_id=node_id,
        label=path.stem,
        slots=_default_flutter_layout(),
        path=str(path.relative_to(project_root)),
        stack="flutter-app",
        use_cases=("screen", "router"),
        description=(
            f"Router screen for "
            f"{domain} domain. "
            f"Delegates to variants/."
        ),
    )


# ── ComposerCanvas implementation ─────

class FlutterComposerCanvas:
    """
    ComposerCanvas for Flutter/Dart projects.

    Implements the ComposerCanvas Protocol
    for the flutter-app stack.

    Reads from the manifest graph and
    filesystem to discover available
    layouts (screens) and components
    (variants, atoms, organisms).
    """

    def available_layouts(
        self,
        project_path: Any,
    ) -> list[LayoutDescriptor]:
        root = Path(str(project_path))
        dart_files = _discover_dart_files(root)
        layouts = []
        for f in dart_files:
            layout = _path_to_layout(f, root)
            if layout is not None:
                layouts.append(layout)
        return layouts

    def available_components(
        self,
        project_path: Any,
        kind: ComponentKind | None = None,
        domain: str | None = None,
    ) -> list[ComponentDescriptor]:
        root = Path(str(project_path))
        dart_files = _discover_dart_files(root)
        components = []
        for f in dart_files:
            comp = _path_to_component(f, root)
            if comp is None:
                continue
            if kind is not None and comp.kind != kind:
                continue
            if domain is not None and comp.domain.upper() != domain.upper():
                continue
            components.append(comp)
        return components

    def components_for_slot(
        self,
        slot: SlotContract,
        project_path: Any,
    ) -> list[ComponentDescriptor]:
        all_comps = self.available_components(project_path)
        return [c for c in all_comps if slot.accepts(c)]

    def validate_binding(
        self,
        binding: SlotBinding,
        project_path: Any,
    ) -> list[str]:
        root = Path(str(project_path))
        errors: list[str] = []

        # Find the layout
        layouts = self.available_layouts(root)
        layout = next(
            (l for l in layouts if l.node_id == binding.layout_node_id),
            None,
        )
        if layout is None:
            errors.append(f"Layout not found: {binding.layout_node_id}")
            return errors

        # Find the slot
        slot = layout.slot(binding.slot_name)
        if slot is None:
            errors.append(
                f"Slot '{binding.slot_name}' not found in layout "
                f"{binding.layout_node_id}"
            )
            return errors

        # Find the component
        comps = self.available_components(root)
        comp = next(
            (c for c in comps if c.node_id == binding.component_node_id),
            None,
        )
        if comp is None:
            errors.append(f"Component not found: {binding.component_node_id}")
            return errors

        # Validate slot contract
        errors.extend(slot.validate([comp]))
        return errors

    def bind(
        self,
        layout_node_id: str,
        slot_name: str,
        component_node_id: str,
        page_node_id: str | None,
        project_path: Any,
    ) -> SlotBinding:
        binding = SlotBinding(
            layout_node_id=layout_node_id,
            slot_name=slot_name,
            component_node_id=component_node_id,
            page_node_id=page_node_id,
        )
        errors = self.validate_binding(binding, project_path)
        binding.valid = len(errors) == 0
        binding.errors = errors
        return binding

    def persist_binding(
        self,
        binding: SlotBinding,
        project_path: Any,
    ) -> None:
        # Write-back via forge MCP only.
        # forge_manifest_append with
        # the binding as a declared relation.
        raise NotImplementedError(
            "Persist via forge MCP tools: "
            "forge_manifest_append with "
            "edge relation 'slot_binding'"
        )


# ── ForgeLog parser ───────────────────

_FORGE_LOG_RE = re.compile(
    r"^\[(?P<domain>[A-Z]+)"
    r"\.(?P<component>[^\]]+)\]\s+"
    r"(?P<action>\S+)\s+"
    r"(?P<level>INFO|WARN|ERROR)"
    r"(?:\s+(?P<code>[A-Z][A-Z0-9_]+))?:"
    r"(?:\s+(?P<message>[^\n{]+))?"
    r"(?:\s*\{contract:(?P<contract>[^}]+)\})?",
    re.MULTILINE,
)


@dataclass(frozen=True)
class ForgeLogEntry:
    """
    A parsed ForgeLog line from Pixionary.

    Format:
      [DOMAIN.Component] action LEVEL CODE:
        message {contract:Component.method}
    """
    domain: str
    component: str
    action: str
    level: str
    code: str | None
    message: str | None
    contract: str | None
    raw: str

    @property
    def node_id(self) -> str:
        """
        Infer forge manifest node_id.

        [AUTH.AuthController] →
          controller/auth.auth_controller
        [GAME.GameController] →
          controller/game.game_controller
        [REMOTE.SupabaseService] →
          service/remote.supabase_service
        """
        domain = self.domain.lower()
        comp = self.component

        # Convert PascalCase to snake_case
        snake = re.sub(
            r"([A-Z])",
            lambda m: "_" + m.group(1).lower(),
            comp,
        ).lstrip("_")

        # Determine kind prefix
        if "controller" in snake:
            prefix = "controller"
        elif "service" in snake:
            prefix = "service"
        elif "screen" in snake:
            prefix = "screen"
        else:
            prefix = "module"

        return f"{prefix}/{domain}.{snake}"

    @property
    def severity(self) -> str:
        return {
            "INFO": "low",
            "WARN": "medium",
            "ERROR": "high",
        }.get(self.level, "medium")

    def to_causal_hop(self) -> CausalHop:
        """Convert to a forge CausalHop."""
        return CausalHop(
            node_id=self.node_id,
            edge_kind=self.contract,
            violation=self.code,
            severity=self.severity,
        )

    def to_forge_error(self) -> ForgeError:
        """
        Convert a ForgeLog ERROR entry
        to a ForgeError.

        Maps:
          level=ERROR → recoverable=True
          code → ErrorCode if known,
                 else UNHANDLED_EXCEPTION
          domain → ErrorLayer
          message → ForgeError.message
          contract → hint context
        """
        layer_map = {
            "AUTH": ErrorLayer.CONTRACT,
            "GAME": ErrorLayer.EXECUTION,
            "CANVAS": ErrorLayer.EXECUTION,
            "LOBBY": ErrorLayer.EXECUTION,
            "REMOTE": ErrorLayer.PROVIDER,
            "PREMIUM": ErrorLayer.CONTRACT,
            "CORE": ErrorLayer.INTERNAL,
            "PROFILE": ErrorLayer.EXECUTION,
        }
        layer = layer_map.get(self.domain, ErrorLayer.INTERNAL)

        hint = (
            f"ForgeLog {self.level} in "
            f"{self.domain}.{self.component}."
            f"{self.action}"
        )
        if self.contract:
            hint += f" | Contract: {self.contract}"
        if self.code:
            hint += f" | Code: {self.code}"

        err = ForgeError(
            code=ErrorCode.UNHANDLED_EXCEPTION,
            layer=layer,
            message=self.message or f"{self.action} failed",
            hint=hint,
            recoverable=True,
            source_node_id=self.node_id,
        )
        err.causal_chain = [self.to_causal_hop()]
        return err


def parse_forge_log(text: str) -> list[ForgeLogEntry]:
    """
    Parse ForgeLog output text into
    structured entries.

    Accepts multi-line log output from
    flutter run, flutter logs, or
    captured debugPrint output.
    """
    entries = []
    for match in _FORGE_LOG_RE.finditer(text):
        entries.append(
            ForgeLogEntry(
                domain=match.group("domain"),
                component=match.group("component"),
                action=match.group("action"),
                level=match.group("level"),
                code=match.group("code"),
                message=(match.group("message") or "").strip() or None,
                contract=match.group("contract"),
                raw=match.group(0),
            )
        )
    return entries


def forge_errors_from_log(text: str) -> list[ForgeError]:
    """
    Parse ForgeLog text and return
    ForgeErrors for ERROR-level entries.

    Use with ForgeSession.explain_error()
    to enrich with graph context.
    """
    entries = parse_forge_log(text)
    return [e.to_forge_error() for e in entries if e.level == "ERROR"]


# ── Registration ──────────────────────

# Register on import so any code that
# does `import forge.gloves.dart_glove`
# gets the canvas available immediately.
_canvas = FlutterComposerCanvas()
register_composer("flutter-app", _canvas)
register_composer("flutter", _canvas)


# ── Public API ────────────────────────

def get_flutter_canvas() -> FlutterComposerCanvas:
    """Return the registered Flutter canvas."""
    return _canvas


__all__ = [
    "FlutterComposerCanvas",
    "ForgeLogEntry",
    "forge_errors_from_log",
    "get_flutter_canvas",
    "parse_forge_log",
]
