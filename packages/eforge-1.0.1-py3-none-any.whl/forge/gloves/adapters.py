from pathlib import Path
from typing import Any

from forge.core.gloves import DartGlove, PythonGlove, ReactGlove, SQLGlove
from forge.protocols.glove import GloveOutput, GloveProtocol


class PythonGloveAdapter(GloveProtocol):
    """Adapter for existing PythonGlove to new GloveProtocol."""
    
    stack = "python"
    version = "1.0.0"
    min_forge_version = "0.1.0"

    def __init__(self):
        self._inner = PythonGlove()

    def scan(self, project_path: Path) -> GloveOutput:
        """Convert existing extract_nodes/edges to GloveOutput."""
        try:
            nodes = self._inner.extract_nodes(project_path)
        except NotImplementedError:
            # Handle gloves that aren't fully implemented yet
            nodes = []
        try:
            edges = self._inner.extract_edges(project_path)
        except NotImplementedError:
            edges = []
        
        # Convert RawNode to universal dict format
        node_dicts = []
        for node in nodes:
            node_dicts.append({
                "id": node.id,
                "kind": node.kind,
                "domain": node.domain,
                "name": node.name,
                "path": node.file,
                "status": node.status,
                "stack": self.stack,
                "meta": {},
            })
        
        # Convert RawEdge to universal dict format
        edge_dicts = []
        for edge in edges:
            edge_dicts.append({
                "from_id": edge.from_id,
                "to_id": edge.to_id,
                "relation": edge.edge_kind,
                "meta": {},
            })
        
        return GloveOutput(
            nodes=node_dicts,
            edges=edge_dicts,
            stack=self.stack,
            project_path=str(project_path),
            meta={"adapter": "PythonGloveAdapter"},
        )

    def watch(self, file_path: Path) -> GloveOutput:
        """Delegate to scan() - no incremental support yet."""
        return self.scan(file_path.parent)

    def resolve(self, node_id: str, project_path: Path) -> dict | None:
        """Find node in scan results."""
        result = self.scan(project_path)
        for node in result.nodes:
            if node.get("id") == node_id:
                return node
        return None


class DartGloveAdapter(GloveProtocol):
    """Adapter for existing DartGlove to new GloveProtocol."""
    
    stack = "dart"
    version = "1.0.0"
    min_forge_version = "0.1.0"

    def __init__(self):
        self._inner = DartGlove()

    def scan(self, project_path: Path) -> GloveOutput:
        """Convert existing extract_nodes/edges to GloveOutput."""
        try:
            nodes = self._inner.extract_nodes(project_path)
        except NotImplementedError:
            # Handle gloves that aren't fully implemented yet
            nodes = []
        try:
            edges = self._inner.extract_edges(project_path)
        except NotImplementedError:
            edges = []
        
        # Convert RawNode to universal dict format
        node_dicts = []
        for node in nodes:
            node_dicts.append({
                "id": node.id,
                "kind": node.kind,
                "domain": node.domain,
                "name": node.name,
                "path": node.file,
                "status": node.status,
                "stack": self.stack,
                "meta": {},
            })
        
        # Convert RawEdge to universal dict format
        edge_dicts = []
        for edge in edges:
            edge_dicts.append({
                "from_id": edge.from_id,
                "to_id": edge.to_id,
                "relation": edge.edge_kind,
                "meta": {},
            })
        
        return GloveOutput(
            nodes=node_dicts,
            edges=edge_dicts,
            stack=self.stack,
            project_path=str(project_path),
            meta={"adapter": "DartGloveAdapter"},
        )

    def watch(self, file_path: Path) -> GloveOutput:
        """Delegate to scan() - no incremental support yet."""
        return self.scan(file_path.parent)

    def resolve(self, node_id: str, project_path: Path) -> dict | None:
        """Find node in scan results."""
        result = self.scan(project_path)
        for node in result.nodes:
            if node.get("id") == node_id:
                return node
        return None


class ReactGloveAdapter(GloveProtocol):
    """Adapter for existing ReactGlove to new GloveProtocol."""
    
    stack = "web"
    version = "1.0.0"
    min_forge_version = "0.1.0"

    def __init__(self):
        self._inner = ReactGlove()

    def scan(self, project_path: Path) -> GloveOutput:
        """Convert existing extract_nodes/edges to GloveOutput."""
        try:
            nodes = self._inner.extract_nodes(project_path)
        except NotImplementedError:
            # Handle gloves that aren't fully implemented yet
            nodes = []
        try:
            edges = self._inner.extract_edges(project_path)
        except NotImplementedError:
            edges = []
        
        # Convert RawNode to universal dict format
        node_dicts = []
        for node in nodes:
            node_dicts.append({
                "id": node.id,
                "kind": node.kind,
                "domain": node.domain,
                "name": node.name,
                "path": node.file,
                "status": node.status,
                "stack": self.stack,
                "meta": {},
            })
        
        # Convert RawEdge to universal dict format
        edge_dicts = []
        for edge in edges:
            edge_dicts.append({
                "from_id": edge.from_id,
                "to_id": edge.to_id,
                "relation": edge.edge_kind,
                "meta": {},
            })
        
        return GloveOutput(
            nodes=node_dicts,
            edges=edge_dicts,
            stack=self.stack,
            project_path=str(project_path),
            meta={"adapter": "ReactGloveAdapter"},
        )

    def watch(self, file_path: Path) -> GloveOutput:
        """Delegate to scan() - no incremental support yet."""
        return self.scan(file_path.parent)

    def resolve(self, node_id: str, project_path: Path) -> dict | None:
        """Find node in scan results."""
        result = self.scan(project_path)
        for node in result.nodes:
            if node.get("id") == node_id:
                return node
        return None


class SQLGloveAdapter(GloveProtocol):
    """Adapter for existing SQLGlove to new GloveProtocol."""
    
    stack = "sql"
    version = "1.0.0"
    min_forge_version = "0.1.0"

    def __init__(self):
        self._inner = SQLGlove()

    def scan(self, project_path: Path) -> GloveOutput:
        """Convert existing extract_nodes/edges to GloveOutput."""
        try:
            nodes = self._inner.extract_nodes(project_path)
        except NotImplementedError:
            # Handle gloves that aren't fully implemented yet
            nodes = []
        try:
            edges = self._inner.extract_edges(project_path)
        except NotImplementedError:
            edges = []
        
        # Convert RawNode to universal dict format
        node_dicts = []
        for node in nodes:
            node_dicts.append({
                "id": node.id,
                "kind": node.kind,
                "domain": node.domain,
                "name": node.name,
                "path": node.file,
                "status": node.status,
                "stack": self.stack,
                "meta": {},
            })
        
        # Convert RawEdge to universal dict format
        edge_dicts = []
        for edge in edges:
            edge_dicts.append({
                "from_id": edge.from_id,
                "to_id": edge.to_id,
                "relation": edge.edge_kind,
                "meta": {},
            })
        
        return GloveOutput(
            nodes=node_dicts,
            edges=edge_dicts,
            stack=self.stack,
            project_path=str(project_path),
            meta={"adapter": "SQLGloveAdapter"},
        )

    def watch(self, file_path: Path) -> GloveOutput:
        """Delegate to scan() - no incremental support yet."""
        return self.scan(file_path.parent)

    def resolve(self, node_id: str, project_path: Path) -> dict | None:
        """Find node in scan results."""
        result = self.scan(project_path)
        for node in result.nodes:
            if node.get("id") == node_id:
                return node
        return None
