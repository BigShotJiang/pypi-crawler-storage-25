"""Glove markers and colocated stack templates (YAML under each ``*/templates/`` tree)."""
