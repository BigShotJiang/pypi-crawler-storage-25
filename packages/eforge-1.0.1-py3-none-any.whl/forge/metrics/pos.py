from dataclasses import dataclass, field

POS_THRESHOLD = 60   # score >= 60 = likely obsolete


@dataclass
class ObsolescenceSignal:
    node_id: str
    score: int          # 0-100, higher = more likely obsolete
    signals: list[str]  # human-readable reasons

    @property
    def likely_obsolete(self) -> bool:
        return self.score >= POS_THRESHOLD


@dataclass
class POSResult:
    likely_obsolete: list[ObsolescenceSignal] = field(
        default_factory=list
    )
    monitored: list[ObsolescenceSignal] = field(
        default_factory=list
    )

    @property
    def obsolete_count(self) -> int:
        return len(self.likely_obsolete)

    def to_dict(self) -> dict:
        return {
            "likely_obsolete_count": self.obsolete_count,
            "likely_obsolete": [
                {
                    "node_id": s.node_id,
                    "score": s.score,
                    "signals": s.signals,
                }
                for s in self.likely_obsolete
            ],
            "monitored_count": len(self.monitored),
        }


def compute_pos(
    graph=None,
    annotations: list | None = None,
    threshold_days: int = 90,
) -> POSResult:
    """
    Compute POS for a project.
    Signals checked per node:
      - No annotation in > threshold_days (+40)
      - status is 'declared' (not implemented) (+30)
      - node has no edges (+20)
      - annotation explicitly marks as deprecated (+60)
    """
    if graph is None:
        return POSResult()

    from datetime import datetime, timezone, timedelta
    now = datetime.now(timezone.utc)
    threshold = now - timedelta(days=threshold_days)

    nodes = list(getattr(graph, "nodes", []))
    edges = list(getattr(graph, "edges", []))

    # Build edge-connected set
    connected_ids: set[str] = set()
    for edge in edges:
        fid = getattr(edge, "from_id", None) or \
              (edge.get("from") if isinstance(edge, dict)
               else "")
        tid = getattr(edge, "to_id", None) or \
              (edge.get("to") if isinstance(edge, dict)
               else "")
        if fid:
            connected_ids.add(fid)
        if tid:
            connected_ids.add(tid)

    # Build annotation map: node_id -> newest timestamp
    ann_map: dict[str, datetime] = {}
    for ann in (annotations or []):
        target = (
            ann.get("target_node") or
            ann.get("node_id") or ""
        )
        ts_str = (
            ann.get("timestamp") or
            ann.get("created_at") or ""
        )
        if not target or not ts_str:
            continue
        try:
            ts = datetime.fromisoformat(
                ts_str.replace("Z", "+00:00")
            )
            existing = ann_map.get(target)
            if existing is None or ts > existing:
                ann_map[target] = ts
        except Exception:
            continue

    signals_list = []
    for node in nodes:
        nid = getattr(node, "id", None) or \
              (node.get("id") if isinstance(node, dict)
               else None)
        if not nid:
            continue

        score = 0
        reasons = []

        # No recent annotation
        last_ann = ann_map.get(nid)
        if last_ann is None or last_ann < threshold:
            score += 40
            reasons.append(
                f"No annotation in {threshold_days}+ days"
            )

        # Not implemented
        status = getattr(node, "status", "declared")
        if isinstance(node, dict):
            status = node.get("status", "declared")
        if status == "declared":
            score += 30
            reasons.append("Not yet implemented")

        # No edges
        if nid not in connected_ids:
            score += 20
            reasons.append("No declared edges")

        if score > 0:
            signals_list.append(ObsolescenceSignal(
                node_id=nid,
                score=min(100, score),
                signals=reasons,
            ))

    result = POSResult()
    for s in signals_list:
        if s.likely_obsolete:
            result.likely_obsolete.append(s)
        else:
            result.monitored.append(s)

    return result
