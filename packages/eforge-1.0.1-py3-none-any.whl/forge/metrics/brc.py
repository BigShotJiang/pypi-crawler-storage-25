"""
Blast Radius Coverage (BRC)

Score: 0-100 (percentage of nodes with edge coverage).
A node is "covered" if it has at least one declared edge
(incoming or outgoing) in the declaration graph.

Uncovered nodes (isolated) cannot have blast radius
calculated — changes to them have unknown impact.
BRC measures how much of your graph is blast-radius-safe.
"""

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class BRCResult:
    total_nodes: int
    covered_nodes: int
    uncovered_nodes: list[str] = field(
        default_factory=list
    )

    @property
    def score(self) -> int:
        if self.total_nodes == 0:
            return 100   # empty project is trivially covered
        return int(
            (self.covered_nodes / self.total_nodes) * 100
        )

    @property
    def healthy(self) -> bool:
        return self.score >= 70

    def to_dict(self) -> dict:
        return {
            "score": self.score,
            "healthy": self.healthy,
            "total_nodes": self.total_nodes,
            "covered_nodes": self.covered_nodes,
            "uncovered_count": len(self.uncovered_nodes),
            "uncovered_nodes": self.uncovered_nodes[:20],
        }


def compute_brc(graph=None) -> BRCResult:
    """
    Compute BRC for a project's declaration graph.
    graph: ManifestGraph or similar with .nodes and .edges
    """
    if graph is None:
        return BRCResult(total_nodes=0, covered_nodes=0)

    nodes = list(getattr(graph, "nodes", []))
    edges = list(getattr(graph, "edges", []))

    if not nodes:
        return BRCResult(total_nodes=0, covered_nodes=0)

    # Build set of node IDs that appear in any edge
    connected_ids: set[str] = set()
    for edge in edges:
        from_id = getattr(edge, "from_id", None) or \
                  edge.get("from", "") \
                  if isinstance(edge, dict) else ""
        to_id = getattr(edge, "to_id", None) or \
                edge.get("to", "") \
                if isinstance(edge, dict) else ""
        if from_id:
            connected_ids.add(from_id)
        if to_id:
            connected_ids.add(to_id)

    all_ids = []
    for node in nodes:
        nid = getattr(node, "id", None) or \
              node.get("id", "") \
              if isinstance(node, dict) else ""
        if nid:
            all_ids.append(nid)

    covered = [nid for nid in all_ids
               if nid in connected_ids]
    uncovered = [nid for nid in all_ids
                 if nid not in connected_ids]

    return BRCResult(
        total_nodes=len(all_ids),
        covered_nodes=len(covered),
        uncovered_nodes=uncovered,
    )
