from dataclasses import dataclass
from pathlib import Path


@dataclass
class HealthVector:
    """
    The complete health vector for a project.
    Six independently queryable dimensions.
    """
    graph_health: int = 100    # declaration graph integrity
    sync_health: int = 100     # generated artifacts freshness
    infra_health: int = 100    # infrastructure checker results
    adi_score: int = 0         # architectural debt (0=good)
    brc_score: int = 100       # blast radius coverage
    idr_score: int = 100       # intent retention

    def to_dict(self) -> dict:
        return {
            "graph_health": self.graph_health,
            "sync_health": self.sync_health,
            "infra_health": self.infra_health,
            "adi_score": self.adi_score,
            "brc_score": self.brc_score,
            "idr_score": self.idr_score,
            "overall": self._overall(),
            "healthy": self._healthy(),
        }

    def _overall(self) -> int:
        scores = [
            self.graph_health,
            self.sync_health,
            self.infra_health,
            100 - self.adi_score,  # invert ADI
            self.brc_score,
            self.idr_score,
        ]
        return int(sum(scores) / len(scores))

    def _healthy(self) -> bool:
        return (
            self.graph_health >= 70 and
            self.adi_score <= 30 and
            self.brc_score >= 70
        )
