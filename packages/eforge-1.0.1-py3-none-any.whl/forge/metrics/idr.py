from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

IDR_THRESHOLD_DAYS = 90

_INTENT_RECORDS_NOT_PASSED = object()


@dataclass
class IDRResult:
    total_nodes: int
    nodes_with_intent: int
    nodes_without_intent: list[str] = field(default_factory=list)
    stale_nodes: list[str] = field(default_factory=list)
    # Intent-record corpus (Sprint 11) — orthogonal to annotation decay ``score``.
    intent_corpus_undefined: bool = False
    """True when ``intent_records`` was supplied as an empty list (no intent YAML rows)."""
    intent_alignment_score: int | None = None
    """0–100 from active intent→node linkage; ``None`` when corpus undefined or not measured."""

    @property
    def decay_rate(self) -> float:
        """0.0 = no decay. 1.0 = total decay (annotation model)."""
        if self.total_nodes == 0:
            return 0.0
        return len(self.nodes_without_intent) / self.total_nodes

    @property
    def score(self) -> int:
        """100 = no annotation decay. 0 = total decay (legacy health gate)."""
        return int((1.0 - self.decay_rate) * 100)

    @property
    def healthy(self) -> bool:
        return self.decay_rate <= 0.3

    def to_dict(self) -> dict:
        d: dict[str, Any] = {
            "score": self.score,
            "decay_rate": round(self.decay_rate, 3),
            "healthy": self.healthy,
            "total_nodes": self.total_nodes,
            "nodes_with_intent": self.nodes_with_intent,
            "nodes_without_intent_count": len(self.nodes_without_intent),
            "nodes_without_intent": self.nodes_without_intent[:20],
            "intent_corpus_undefined": self.intent_corpus_undefined,
            "intent_alignment_score": self.intent_alignment_score,
        }
        return d


def _declarable_node_ids(graph: Any) -> list[str]:
    nodes = list(getattr(graph, "nodes", []))
    decl_kinds = frozenset(
        {"screen", "controller", "service", "module", "component", "model", "command"},
    )
    out: list[str] = []
    for node in nodes:
        kind = str(getattr(node, "kind", "") or "").strip().lower()
        if kind not in decl_kinds:
            continue
        nid = getattr(node, "id", None) or (node.get("id") if isinstance(node, dict) else None)
        if nid:
            out.append(str(nid))
    return out


def compute_idr(
    graph=None,
    annotations: list | None = None,
    *,
    intent_records: Any = _INTENT_RECORDS_NOT_PASSED,
    threshold_days: int = IDR_THRESHOLD_DAYS,
) -> IDRResult:
    """Intent decay from annotation coverage vs declared graph nodes.

    **Annotations** (legacy path)

    - ``annotations is None`` and ``annotations == []`` are equivalent: no rows
      contribute to coverage, so every graph node ID counts as *without intent*
      (full decay when ``total_nodes > 0``).

    **Intent records** (Sprint 11+)

    - When ``intent_records`` is omitted (default sentinel), intent alignment is
      not measured — ``intent_corpus_undefined`` is False and
      ``intent_alignment_score`` is ``None``.
    - When ``intent_records`` is ``[]``, the corpus is **undefined**:
      ``intent_corpus_undefined=True``, ``intent_alignment_score=None``.
    - When non-empty, active records with ``target_id`` (and extracted entity hints)
      add to annotation coverage via ``_resolve_targets`` — IDR decay uses the
      union of annotation *and* intent-covered node ids.
    - ``intent_alignment_score`` is the share of declarable nodes targeted by at
      least one *active* intent record (0 = none linked, 100 = all).

    **Graph**

    - ``graph is None`` → ``IDRResult(total_nodes=0, nodes_with_intent=0)`` with
      ``decay_rate == 0`` (no nodes to measure).
    """
    intent_corpus_undefined = False
    intent_alignment_score: int | None = None

    if graph is None:
        return IDRResult(
            total_nodes=0,
            nodes_with_intent=0,
            intent_corpus_undefined=intent_corpus_undefined,
            intent_alignment_score=intent_alignment_score,
        )

    from datetime import datetime, timedelta, timezone

    threshold = datetime.now(timezone.utc) - timedelta(days=threshold_days)

    nodes = list(getattr(graph, "nodes", []))
    all_ids: list[str] = []
    for node in nodes:
        nid = getattr(node, "id", None) or (node.get("id") if isinstance(node, dict) else None)
        if nid:
            all_ids.append(str(nid))

    covered_ids: set[str] = set()
    id_set = set(all_ids)
    path_by_id: dict[str, str] = {}
    for node in nodes:
        nid = getattr(node, "id", None) or (node.get("id") if isinstance(node, dict) else None)
        if nid:
            path_by_id[str(nid)] = str(getattr(node, "path", "") or "")

    def _resolve_targets(raw: str) -> set[str]:
        out: set[str] = set()
        token = str(raw or "").strip()
        if not token:
            return out
        if token in id_set:
            out.add(token)
        needle = token.replace(".", "/").lower()
        for nid in all_ids:
            if needle in nid.lower() or needle in path_by_id.get(nid, "").lower():
                out.add(nid)
        return out

    for ann in annotations or []:
        ts_str = ann.get("timestamp") or ann.get("created_at") or ""
        targets: list[str] = []
        for key in ("target_node", "node_id"):
            val = ann.get(key)
            if val:
                targets.append(str(val))
        affects = ann.get("affects")
        if isinstance(affects, list):
            targets.extend(str(x) for x in affects if x)
        elif isinstance(affects, str) and affects.strip():
            targets.append(affects.strip())
        if not targets:
            continue
        recent = True
        if ts_str:
            try:
                ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                recent = ts >= threshold
            except Exception:
                recent = True
        if not recent:
            continue
        for target in targets:
            covered_ids.update(_resolve_targets(target))

    if intent_records is not _INTENT_RECORDS_NOT_PASSED:
        recs = list(intent_records or [])
        if not recs:
            intent_corpus_undefined = True
            intent_alignment_score = None
        else:
            decl_ids = set(_declarable_node_ids(graph))
            targeted: set[str] = set()
            for rec in recs:
                st = getattr(rec, "status", None)
                sv = getattr(st, "value", st)
                if str(sv).strip().lower() not in {"active", "draft"}:
                    continue
                tid = (getattr(rec, "target_id", None) or "").strip()
                if tid:
                    resolved = _resolve_targets(tid)
                    covered_ids.update(resolved)
                    targeted.update(resolved)
                for hint in getattr(rec, "extracted_entities", []) or []:
                    h = (hint or "").strip()
                    if h:
                        resolved = _resolve_targets(h)
                        covered_ids.update(resolved)
                        targeted.update(resolved)
            if not decl_ids:
                intent_alignment_score = 100
            else:
                ratio = len(targeted) / max(1, len(decl_ids))
                intent_alignment_score = int(round(ratio * 100))

    with_intent = [nid for nid in all_ids if nid in covered_ids]
    without_intent = [nid for nid in all_ids if nid not in covered_ids]

    return IDRResult(
        total_nodes=len(all_ids),
        nodes_with_intent=len(with_intent),
        nodes_without_intent=without_intent,
        intent_corpus_undefined=intent_corpus_undefined,
        intent_alignment_score=intent_alignment_score,
    )
