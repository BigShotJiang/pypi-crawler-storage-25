"""
Architectural Debt Index (ADI)

Score: 0-100 where 0 = no debt, 100 = maximum debt.
Computed from three signals:

  1. Ghost nodes (declared, not implemented)
     Each ghost = +5 ADI
  2. Dark matter (implemented, not declared)
     Each dark matter node = +8 ADI
  3. Open annotations past threshold
     Each stale annotation (> threshold days) = +3 ADI

ADI is capped at 100. It is maintained incrementally
via event subscriptions — not recomputed from scratch
on every call.
"""

from dataclasses import dataclass, field
from pathlib import Path


GHOST_WEIGHT = 5       # declared but not implemented
DARK_MATTER_WEIGHT = 8 # implemented but not declared
STALE_ANNOTATION_WEIGHT = 3
STALE_ANNOTATION_DAYS = 30


@dataclass
class ADIBreakdown:
    ghost_nodes: list[str] = field(default_factory=list)
    dark_matter_nodes: list[str] = field(default_factory=list)
    stale_annotations: list[str] = field(default_factory=list)

    @property
    def score(self) -> int:
        raw = (
            len(self.ghost_nodes) * GHOST_WEIGHT +
            len(self.dark_matter_nodes) * DARK_MATTER_WEIGHT +
            len(self.stale_annotations) * STALE_ANNOTATION_WEIGHT
        )
        return min(100, raw)

    @property
    def healthy(self) -> bool:
        return self.score <= 30

    def to_dict(self) -> dict:
        return {
            "score": self.score,
            "healthy": self.healthy,
            "breakdown": {
                "ghost_nodes": self.ghost_nodes,
                "ghost_count": len(self.ghost_nodes),
                "dark_matter_nodes": self.dark_matter_nodes,
                "dark_matter_count":
                    len(self.dark_matter_nodes),
                "stale_annotations": self.stale_annotations,
                "stale_annotation_count":
                    len(self.stale_annotations),
            },
        }


def compute_adi(
    project_path: Path,
    graph=None,
    annotations: list | None = None,
    stale_days: int = STALE_ANNOTATION_DAYS,
) -> ADIBreakdown:
    """
    Compute ADI for a project.
    graph: the manifest graph (ManifestGraph or None)
    annotations: list of annotation dicts or None
    """
    breakdown = ADIBreakdown()

    # Signal 1 & 2: ghost nodes and dark matter
    if graph is not None:
        nodes = getattr(graph, "nodes", [])
        for node in nodes:
            node_id = getattr(node, "id", "unknown")
            status = str(getattr(node, "status", "declared") or "declared").lower()
            implemented = status == "implemented"
            declared = status in ("declared", "implemented", "planned")

            if declared and not implemented:
                breakdown.ghost_nodes.append(node_id)
            elif implemented and not declared:
                breakdown.dark_matter_nodes.append(node_id)

    # Signal 3: stale annotations
    if annotations:
        from datetime import datetime, timezone, timedelta
        threshold = datetime.now(timezone.utc) - \
                    timedelta(days=stale_days)
        for ann in annotations:
            ts_str = (
                ann.get("timestamp") or
                ann.get("created_at") or ""
            )
            if not ts_str:
                continue
            try:
                ts = datetime.fromisoformat(
                    ts_str.replace("Z", "+00:00")
                )
                if ts < threshold:
                    breakdown.stale_annotations.append(
                        ann.get("id", "unknown")
                    )
            except Exception:
                continue

    return breakdown
