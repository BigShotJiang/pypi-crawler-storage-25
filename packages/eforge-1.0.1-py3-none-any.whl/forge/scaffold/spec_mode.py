from __future__ import annotations

import logging
import re
import sys
from pathlib import Path
from typing import Any

import yaml

from forge.core.manifest import ManifestParser
from forge.core.manifest_path import resolve_manifest_path

log = logging.getLogger(__name__)

_NODE_TYPES = {"screen", "controller", "service", "model", "variant", "module"}
_DEP_SUFFIX_TYPES: tuple[tuple[str, str], ...] = (
    ("controller", "controller"),
    ("service", "service"),
    ("screen", "screen"),
    ("model", "model"),
    ("variant", "variant"),
    ("module", "module"),
)


class SpecModeError(ValueError):
    """Raised when spec-mode input or glove validation fails."""


def _read_project_stack(project_path: Path) -> str:
    manifest_path = resolve_manifest_path(project_path)
    if manifest_path is None:
        raise SpecModeError("manifest.yaml not found for project_path")
    parsed = ManifestParser(manifest_path).parse()
    if not parsed.ok or not isinstance(parsed.value, dict):
        raise SpecModeError(parsed.error or "failed to parse manifest")
    data = parsed.value
    stack = data.get("stack")
    if isinstance(stack, str) and stack.strip():
        return stack.strip()
    for key in ("app", "project"):
        block = data.get(key)
        if not isinstance(block, dict):
            continue
        inner = block.get("stack")
        if isinstance(inner, str) and inner.strip():
            return inner.strip()
    fallback = ManifestParser.get_stack(data)
    if not fallback or fallback == "unknown":
        raise SpecModeError("stack not declared in manifest")
    return fallback


def _load_glove(project_path: Path, stack: str) -> dict[str, Any]:
    glove_path = project_path / ".forge" / "gloves" / f"{stack}.glove.yaml"
    if not glove_path.is_file():
        raise SpecModeError(
            f"glove contract violated: stack glove not found at {glove_path}"
        )
    try:
        raw = yaml.safe_load(glove_path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise SpecModeError(f"failed to parse glove yaml: {exc}") from exc
    if not isinstance(raw, dict):
        raise SpecModeError("invalid glove yaml: expected mapping")
    return raw


def _infer_dep_type(dep: str) -> str | None:
    low = dep.strip().lower()
    for suffix, kind in _DEP_SUFFIX_TYPES:
        if low.endswith(suffix):
            return kind
    return None


def _parse_method_signature(signature: str) -> dict[str, Any]:
    text = signature.strip()
    pattern = r"^([A-Za-z_][A-Za-z0-9_]*)\((.*?)\)\s*->\s*([A-Za-z0-9_<>, ?.\[\]]+)$"
    m = re.match(pattern, text)
    if not m:
        raise SpecModeError(
            "method signature invalid; expected 'name(param:Type) -> ReturnType'"
        )
    method_name, params_blob, returns = m.group(1), m.group(2).strip(), m.group(3).strip()
    params: list[dict[str, str]] = []
    if params_blob:
        for raw_param in [p.strip() for p in params_blob.split(",") if p.strip()]:
            if ":" not in raw_param:
                raise SpecModeError(
                    f"method signature invalid param '{raw_param}'; expected name:Type"
                )
            p_name, p_type = [x.strip() for x in raw_param.split(":", 1)]
            if not p_name or not p_type:
                raise SpecModeError(
                    f"method signature invalid param '{raw_param}'; expected name:Type"
                )
            params.append({"name": p_name, "type": p_type})
    return {"name": method_name, "params": params, "returns": returns}


def _render_path_templates(templates: list[str], *, domain: str, name: str) -> list[str]:
    rendered: list[str] = []
    domain_tok = str(domain).lower()
    for tpl in templates:
        rendered.append(str(tpl).replace("{domain}", domain_tok).replace("{name}", name))
    return rendered


def build_node_manifest_yaml(
    *,
    node_type: str,
    name: str,
    domain: str,
    project_path: str,
    deps: list[str] | None = None,
    methods: list[str] | None = None,
) -> str:
    project_root = Path(project_path).expanduser().resolve()
    deps = deps or []
    methods = methods or []
    node_type = str(node_type or "").strip().lower()
    name = str(name or "").strip()
    domain = str(domain or "").strip().upper()
    if not name:
        raise SpecModeError("input validation failed: name is required")
    if node_type not in _NODE_TYPES:
        raise SpecModeError(
            "input validation failed: node_type must be one of "
            "screen|controller|service|model|variant|module"
        )

    stack = _read_project_stack(project_root)
    glove = _load_glove(project_root, stack)
    glove_domains = [str(x).strip().upper() for x in (glove.get("domains") or []) if str(x).strip()]
    if domain not in glove_domains:
        raise SpecModeError(
            f"glove contract violated: domain '{domain}' not in glove.domains"
        )
    node_types = glove.get("node_types")
    if not isinstance(node_types, dict) or node_type not in node_types:
        raise SpecModeError(
            f"glove contract violated: node_type '{node_type}' not in glove.node_types"
        )
    node_spec = node_types[node_type]
    if not isinstance(node_spec, dict):
        raise SpecModeError(f"invalid glove node spec for node_type '{node_type}'")

    forbidden_dep_types = {
        str(x).strip().lower() for x in (node_spec.get("forbidden_deps") or [])
    }
    for dep in deps:
        dep_type = _infer_dep_type(dep)
        if dep_type is None:
            raise SpecModeError(
                f"glove contract violated: cannot infer dependency type for '{dep}' "
                "to validate forbidden_deps"
            )
        if dep_type in forbidden_dep_types:
            raise SpecModeError(
                f"glove contract violated: node_types.{node_type}.forbidden_deps "
                f"contains '{dep_type}', but deps include '{dep}'"
            )

    output_templates = [str(x) for x in (node_spec.get("output_paths") or []) if str(x).strip()]
    if not output_templates:
        raise SpecModeError(
            f"glove contract violated: node_types.{node_type}.output_paths is empty"
        )
    rendered_outputs = _render_path_templates(output_templates, domain=domain, name=name)

    method_specs = [_parse_method_signature(sig) for sig in methods]
    contract_keys = [str(x).strip() for x in (node_spec.get("required_contracts") or []) if str(x).strip()]

    services = [d for d in deps if _infer_dep_type(d) == "service"]
    controllers = [d for d in deps if _infer_dep_type(d) == "controller"]
    models = [d for d in deps if _infer_dep_type(d) == "model"]

    manifest: dict[str, Any] = {
        "node": name,
        "type": node_type,
        "domain": domain,
        "stack_glove": stack,
        "deps": {
            "services": services,
            "controllers": controllers,
            "models": models,
        },
        "interface": {"methods": method_specs},
        "outputs": [{"path": p, "template": f"{node_type}.default"} for p in rendered_outputs],
        "manifest_patch": [{"op": "add", "node": name, "type": node_type}],
        "wiring": [],
        "contracts": contract_keys,
        "logging": {"domain": domain, "component": name},
    }
    return yaml.safe_dump(manifest, sort_keys=False)


def run_spec_mode(
    *,
    node_type: str,
    name: str,
    domain: str,
    project_path: str,
    deps: list[str] | None = None,
    methods: list[str] | None = None,
) -> int:
    try:
        payload = build_node_manifest_yaml(
            node_type=node_type,
            name=name,
            domain=domain,
            project_path=project_path,
            deps=deps,
            methods=methods,
        )
    except SpecModeError as exc:
        log.error("scaffold_spec_failed node=%s type=%s error=%s", name, node_type, exc)
        print(f"spec validation failed: {exc}", file=sys.stderr)
        return 1
    print(payload, end="")
    return 0
