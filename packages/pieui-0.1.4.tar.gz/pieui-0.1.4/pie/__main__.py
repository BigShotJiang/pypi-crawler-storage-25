"""PieDemo CLI

Command-line interface for the PieDemo framework.
"""

import argparse
import sys
from typing import Optional

from .code import (
    handle_card_add,
    handle_card_push,
    handle_build,
    handle_create,
    handle_web,
    handle_web_verify,
)
from .code.services.storage import PieStorageError


CARD_TYPES = {"simple", "complex", "container", "complex-container"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pie",
        description="Pie - Framework for building interactive web applications",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands", required=True)

    # piedemo web module:app [verify|build]
    web_parser = subparsers.add_parser("web", help="Run or lint a web application")
    web_parser.add_argument("web", help="Web in format module:attribute, e.g. some:app")
    web_subparsers = web_parser.add_subparsers(dest="web_command")
    web_subparsers.add_parser("verify", help="Verify the web application")
    web_subparsers.add_parser("build", help="Build static JSON from a Web application")

    card_parser = subparsers.add_parser("card", help="Manage card templates")
    card_subparsers = card_parser.add_subparsers(dest="card_command", required=True)
    card_add_parser = card_subparsers.add_parser("add", help="Create a card file from a template")
    card_add_parser.add_argument("card_type", choices=sorted(CARD_TYPES))
    card_add_parser.add_argument("card_name", metavar="NAME")
    card_add_parser.add_argument("--io", action="store_true", dest="use_io")
    card_add_parser.add_argument("--ajax", action="store_true", dest="use_ajax")
    card_push_parser = card_subparsers.add_parser("push", help="Upload a card file")
    card_push_parser.add_argument("card_name", metavar="NAME")

    create_parser = subparsers.add_parser("create", help="Create a new Pie project")
    create_parser.add_argument("project_name", metavar="NAME")

    return parser


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)


def run(
    command: str,
    web: Optional[str] = None,
    web_command: Optional[str] = None,
    card_command: Optional[str] = None,
    card_type: Optional[str] = None,
    card_name: Optional[str] = None,
    project_name: Optional[str] = None,
    use_io: bool = False,
    use_ajax: bool = False,
) -> int:
    try:
        if command == "web":
            if web is None:
                raise ValueError("Web path is required")
            if web_command == "verify":
                handle_web_verify(web)
            elif web_command == "build":
                handle_build(web)
            else:
                handle_web(web)
            return 0

        if command == "page":
            return 0
        if command == "card":
            if card_command == "add":
                handle_card_add(
                    card_name=card_name,
                    card_type=card_type,
                    use_io=use_io,
                    use_ajax=use_ajax,
                )
            elif card_command == "push":
                if card_name is None:
                    raise ValueError("Card name is required")
                handle_card_push(card_name)
            return 0
        if command == "create":
            if project_name is None:
                raise ValueError("Project name is required")
            handle_create(project_name)
            return 0
        if command == "init":
            return 0
        if command == "login":
            return 0
        return 0
    except (ValueError, PieStorageError) as error:
        print(f"[pie] Error: {error}", file=sys.stderr)
        return 1


def main() -> int:
    return run(**vars(parse_args()))


if __name__ == "__main__":
    raise SystemExit(main())
