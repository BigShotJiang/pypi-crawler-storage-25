from __future__ import annotations

from collections.abc import Callable
from queue import Queue
import time
import types
from pathlib import Path
from types import SimpleNamespace
from typing import cast

import pytest


def test_llama_cpp_chat_uses_first_sorted_gguf_and_chat_completion(tmp_path: Path) -> None:
    """llama.cpp chat should load the first sorted GGUF file and use native chat completion."""
    from track.contracts import AiModel, InferenceConfig, Message
    from track.inference.chat.llama_cpp import LlamaCppChatLLM, LlamaCppRuntime

    repo_dir = tmp_path / "repo"
    repo_dir.mkdir()
    later_file = repo_dir / "z-model.gguf"
    first_file = repo_dir / "a-model.gguf"
    later_file.write_bytes(b"gguf")
    first_file.write_bytes(b"gguf")
    captured_init: dict[str, object] = {}
    captured_chat: dict[str, object] = {}

    class FakeLlama:
        """Capture llama.cpp model construction and chat completion calls."""

        def __init__(self, **kwargs: object) -> None:
            """Store constructor kwargs for assertion."""
            captured_init.update(kwargs)

        def create_chat_completion(self, **kwargs: object) -> dict[str, object]:
            """Return one assistant message for the captured chat completion request."""
            captured_chat.update(kwargs)
            return {"choices": [{"message": {"content": "done"}}]}

    runtime = LlamaCppRuntime(llama=FakeLlama)
    model = AiModel(
        provider="local",
        model_id=str(repo_dir),
        alias="chat",
        inference_config=InferenceConfig(max_tokens=17, temperature=0.2, top_p=0.8),
    )
    chat = LlamaCppChatLLM(model_config=model, runtime=runtime)

    response = chat.chat([Message.system("rules"), Message.user("hello")])

    assert response.text() == "done"
    assert captured_init["model_path"] == str(first_file)
    assert captured_init["n_gpu_layers"] == -1
    assert captured_chat["messages"] == [
        {"role": "system", "content": "rules"},
        {"role": "user", "content": "hello"},
    ]
    assert captured_chat["max_tokens"] == 17
    assert captured_chat["temperature"] == 0.2
    assert captured_chat["top_p"] == 0.8


def test_llama_cpp_chat_rejects_unexpected_backend_payloads(tmp_path: Path) -> None:
    """llama.cpp chat should raise instead of returning repr strings for unsupported payloads."""
    from track.contracts import AiModel, Message
    from track.inference.chat.llama_cpp import LlamaCppChatLLM, LlamaCppRuntime

    model_file = tmp_path / "model.gguf"
    model_file.write_bytes(b"gguf")
    runtime = LlamaCppRuntime(
        llama=lambda **_kwargs: SimpleNamespace(
            create_chat_completion=lambda **_chat_kwargs: {"choices": [{"message": {"content": object()}}]}
        )
    )
    model = AiModel(provider="local", model_id=str(model_file), alias="chat")
    chat = LlamaCppChatLLM(model_config=model, runtime=runtime)

    with pytest.raises(RuntimeError, match="unsupported response payload"):
        chat.chat([Message.user("hello")])


def test_llama_cpp_chat_rejects_non_text_messages(tmp_path: Path) -> None:
    """llama.cpp chat should reject multimodal content before calling the backend."""
    from track.contracts import AiModel, Message
    from track.inference.chat.llama_cpp import LlamaCppChatLLM, LlamaCppRuntime

    model_file = tmp_path / "model.gguf"
    model_file.write_bytes(b"gguf")
    runtime = LlamaCppRuntime(
        llama=lambda **_kwargs: SimpleNamespace(create_chat_completion=lambda **_chat_kwargs: {})
    )
    model = AiModel(provider="local", model_id=str(model_file), alias="chat")
    chat = LlamaCppChatLLM(model_config=model, runtime=runtime)

    with pytest.raises(ValueError, match="supports only text content"):
        chat.chat([Message.user("hello", image_path="/tmp/image.png")])


def test_vllm_chat_rejects_unexpected_backend_payloads() -> None:
    """vLLM chat should raise instead of returning repr strings for unsupported payloads."""
    from track.contracts import AiModel, Message
    from track.inference.chat.vllm import VLLMChatLLM, VLLMRuntime

    runtime = VLLMRuntime(
        llm=lambda **_: SimpleNamespace(chat=lambda *_args, **_kwargs: [object()]),
        sampling_params=lambda **kwargs: kwargs,
    )
    model = AiModel(provider="local", model_id="test/chat", alias="chat")
    chat = VLLMChatLLM(model_config=model, runtime=runtime)

    with pytest.raises(RuntimeError, match="unsupported response payload"):
        chat.chat([Message.user("hello")])


def test_vllm_chat_uses_native_chat_messages_instead_of_raw_prompt() -> None:
    """vLLM chat should use tokenizer chat templates instead of a manual Assistant prompt."""
    from track.contracts import AiModel, Message
    from track.inference.chat.vllm import VLLMChatLLM, VLLMRuntime

    recorded_messages: list[dict[str, str]] = []

    class FakeVLLMModel:
        """Capture native chat calls and reject raw prompt generation."""

        def chat(self, messages: list[dict[str, str]], *_args: object, **_kwargs: object) -> list[SimpleNamespace]:
            """Return one assistant response for the captured chat messages."""
            recorded_messages.extend(messages)
            return [SimpleNamespace(outputs=[SimpleNamespace(text="done")])]

        def generate(self, *_args: object, **_kwargs: object) -> list[object]:
            """Fail if the backend falls back to hand-rendered raw prompts."""
            raise AssertionError("raw prompt generation should not be used for chat")

    runtime = VLLMRuntime(
        llm=lambda **_kwargs: FakeVLLMModel(),
        sampling_params=lambda **kwargs: kwargs,
    )
    model = AiModel(provider="local", model_id="test/chat", alias="chat")
    chat = VLLMChatLLM(model_config=model, runtime=runtime)

    response = chat.chat([Message.system("rules"), Message.user("hello")])

    assert response.text() == "done"
    assert recorded_messages == [
        {"role": "system", "content": "rules"},
        {"role": "user", "content": "hello"},
    ]


def test_vllm_chat_disables_trust_remote_code_by_default() -> None:
    """vLLM model construction should not opt into remote repository code by default."""
    from track.contracts import AiModel
    from track.inference.chat.vllm import VLLMChatLLM, VLLMRuntime

    captured: dict[str, object] = {}

    def fake_llm(**kwargs: object) -> SimpleNamespace:
        """Capture model construction kwargs for inspection."""
        captured.update(kwargs)
        return SimpleNamespace(generate=lambda *_args, **_kwargs: [])

    runtime = VLLMRuntime(
        llm=fake_llm,
        sampling_params=lambda **kwargs: kwargs,
    )
    model = AiModel(provider="local", model_id="test/chat", alias="chat")
    VLLMChatLLM(model_config=model, runtime=runtime)

    assert captured["trust_remote_code"] is False


def test_vllm_chat_surfaces_actionable_flashinfer_version_mismatch() -> None:
    """vLLM load failures should explain how to repair FlashInfer version mismatches."""
    from track.contracts import AiModel, Message
    from track.inference.chat.vllm import VLLMChatLLM, VLLMRuntime

    runtime = VLLMRuntime(
        llm=lambda **_kwargs: (_ for _ in ()).throw(
            RuntimeError(
                "flashinfer-cubin version (0.0.0) does not match flashinfer version (0.6.6)."
            )
        ),
        sampling_params=lambda **kwargs: kwargs,
    )
    model = AiModel(provider="local", model_id="test/chat", alias="chat")
    chat = VLLMChatLLM(model_config=model, runtime=runtime)

    with pytest.raises(
        RuntimeError,
        match="install matching flashinfer and flashinfer-cubin versions",
    ):
        chat.chat([Message.user("hello")])


def test_mlx_chat_surfaces_actionable_unsupported_model_error() -> None:
    """MLX chat load failures should explain unsupported mlx_vlm model architectures."""
    from track.contracts import AiModel, Message
    from track.inference.chat.mlx import MLXChatLLM, MLXRuntime

    runtime = MLXRuntime(
        load=lambda *_args, **_kwargs: (_ for _ in ()).throw(
            ValueError(
                "Model type gemma3_text not supported. Error: No module named 'mlx_vlm.models.gemma3_text'"
            )
        ),
        generate=lambda *_args, **_kwargs: SimpleNamespace(text="unused"),
        apply_chat_template=lambda **kwargs: kwargs.get("prompt"),
    )
    model = AiModel(provider="local", model_id="test/gemma3", alias="gemma3")
    chat = MLXChatLLM(model_config=model, runtime=runtime)

    with pytest.raises(
        RuntimeError,
        match="embedding-only registration",
    ):
        chat.chat([Message.user("hello")])


def test_mlx_chat_surfaces_actionable_circular_import_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """MLX chat should explain upstream mlx_vlm circular import failures."""
    from track.contracts import AiModel, Message
    from track.inference.chat import mlx as mlx_chat

    def raising_loader() -> None:
        """Raise the circular import error observed in broken mlx_vlm installs."""
        raise ImportError(
            "cannot import name 'MODEL_CONVERSION_DTYPES' from partially initialized module "
            "'mlx_vlm.utils' (most likely due to a circular import)"
        )

    monkeypatch.setattr(mlx_chat, "_load_mlx_runtime", raising_loader)

    model = AiModel(provider="local", model_id="test/gemma4", alias="gemma4")
    chat = mlx_chat.MLXChatLLM(model_config=model)

    with pytest.raises(
        RuntimeError,
        match="circular import inside the installed mlx_vlm package",
    ):
        chat.chat([Message.user("hello")])


def test_mlx_embedding_surfaces_actionable_circular_import_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """MLX embeddings should explain upstream mlx_vlm circular import failures."""
    from track.inference.embedding import mlx as mlx_embedding

    def raising_loader() -> None:
        """Raise the circular import error observed in broken mlx_vlm installs."""
        raise ImportError(
            "cannot import name 'MODEL_CONVERSION_DTYPES' from partially initialized module "
            "'mlx_vlm.utils' (most likely due to a circular import)"
        )

    monkeypatch.setattr(mlx_embedding, "_load_mlx_embedding_runtime", raising_loader)

    model = mlx_embedding.MLXEmbeddingModel(model_id="test/embedding")

    with pytest.raises(
        RuntimeError,
        match="circular import inside the installed MLX runtime stack",
    ):
        model.embed("hello")


def test_transcription_rejects_unexpected_backend_payloads() -> None:
    """Transcription should raise instead of stringifying unsupported backend payloads."""
    from track.inference.transcription.transformers import TransformersTranscriptionModel

    model = TransformersTranscriptionModel(model_id="test/transcription")
    model.pipeline = lambda *_args, **_kwargs: object()

    with pytest.raises(RuntimeError, match="unsupported response payload"):
        model.transcribe(b"audio")


def test_mlx_audio_fails_early_when_tokenizer_backed_model_has_no_tokenizer(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """MLX audio should raise an actionable install error before calling a broken tokenizer-backed model."""
    from track.inference.audio import mlx as mlx_audio
    from track.inference.audio.models import AudioModelConfig

    class FakeTokenizerBackedModel:
        """Stand in for a tokenizer-backed MLX TTS model that did not finish initialization."""

        def __init__(self) -> None:
            """Initialize the broken test model state."""
            self.tokenizer = None

        def _encode_text(self, text: str, voice: str) -> list[int]:
            """Mimic the tokenizer-backed model interface used for validation."""
            del text, voice
            return [1]

        def generate(self, **_kwargs: object) -> list[object]:
            """Fail the test if generation is attempted before validation."""
            raise AssertionError("generation should not be attempted without a tokenizer")

    fake_model = FakeTokenizerBackedModel()
    monkeypatch.setattr(
        mlx_audio,
        "_load_mlx_audio_load",
        lambda: lambda _location: fake_model,
    )
    monkeypatch.setattr(mlx_audio, "resolve_model_location", lambda *_args, **_kwargs: "/tmp/test-audio")

    model = mlx_audio.MLXAudioModel(
        config=AudioModelConfig(model_id="test/audio"),
        model_path="/tmp",
    )

    with pytest.raises(
        RuntimeError,
        match='Reinstall the macOS extra with `pip install "ai-track\\[macos\\]"`',
    ):
        model.generate_speech("hello")


def test_mlx_audio_does_not_cache_model_that_fails_tokenizer_validation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """MLX audio should retry loading after tokenizer validation rejects a broken model."""
    from track.inference.audio import mlx as mlx_audio
    from track.inference.audio.models import AudioModelConfig

    class FakeTokenizerBackedModel:
        """Stand in for a tokenizer-backed MLX TTS model that cannot generate safely."""

        def __init__(self) -> None:
            """Initialize the broken tokenizer-backed model state."""
            self.tokenizer = None

        def _encode_text(self, text: str, voice: str) -> list[int]:
            """Mimic the tokenizer-backed model interface used for validation."""
            del text, voice
            return [1]

        def generate(self, **_kwargs: object) -> list[object]:
            """Fail the test if generation is attempted after validation fails."""
            raise AssertionError("generation should not be attempted without a tokenizer")

    loaded_models: list[FakeTokenizerBackedModel] = []

    def fake_load(_location: str) -> FakeTokenizerBackedModel:
        """Return a fresh broken model on each load attempt."""
        loaded_model = FakeTokenizerBackedModel()
        loaded_models.append(loaded_model)
        return loaded_model

    monkeypatch.setattr(mlx_audio, "_load_mlx_audio_load", lambda: fake_load)
    monkeypatch.setattr(mlx_audio, "resolve_model_location", lambda *_args, **_kwargs: "/tmp/test-audio")

    model = mlx_audio.MLXAudioModel(
        config=AudioModelConfig(model_id="test/audio"),
        model_path="/tmp",
    )

    for _attempt in range(2):
        with pytest.raises(RuntimeError, match="tokenizer-backed speech models load correctly"):
            model.generate_speech("hello")

    assert len(loaded_models) == 2
    assert model._model is None


def test_mflux_image_generation_always_passes_a_concrete_seed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """MFLUX image generation should always provide a concrete integer seed to the backend."""
    from track.inference.image import mflux
    from track.inference.image.mflux import MfluxImageGenerationModel

    recorded_calls: list[dict[str, object]] = []

    monkeypatch.setattr(mflux.random, "randrange", lambda _start, _stop: 1234)

    model = MfluxImageGenerationModel.__new__(MfluxImageGenerationModel)
    model.load_error = None
    model._generation_lock = None
    model.model = SimpleNamespace(
        generate_image=lambda **kwargs: recorded_calls.append(kwargs) or SimpleNamespace(image=object())
    )

    model._generate(prompt="hello", size=32, steps=4)
    model._generate(prompt="hello", size=32, steps=4, seed=7)

    assert recorded_calls[0]["seed"] == 1234
    assert recorded_calls[1]["seed"] == 7


def test_diffusers_uses_torch_generator_only_for_explicit_seed() -> None:
    """Diffusers image generation should avoid fixed generators unless a seed is provided."""
    from track.inference.image.diffusers import DiffusersFluxImageModel

    created_generators: list[tuple[str, int]] = []

    class FakeGenerator:
        """Record explicit seeds used to initialize the torch generator."""

        def __init__(self, *, device: str) -> None:
            self.device = device

        def manual_seed(self, value: int) -> str:
            """Capture the provided seed value."""
            created_generators.append((self.device, value))
            return f"seeded:{value}"

    class FakeTorch:
        """Provide the small subset of torch used by the image backend."""

        @staticmethod
        def Generator(device: str) -> FakeGenerator:
            """Return a fake generator for the requested device."""
            return FakeGenerator(device=device)

    model = DiffusersFluxImageModel.__new__(DiffusersFluxImageModel)
    model.pipeline = lambda **kwargs: SimpleNamespace(images=[kwargs])
    model.device = "cuda"
    model.load_error = None

    import sys

    previous_torch = sys.modules.get("torch")
    fake_torch = types.ModuleType("torch")
    setattr(fake_torch, "Generator", FakeTorch.Generator)
    sys.modules["torch"] = fake_torch
    try:
        first = model._run_pipeline(prompt="hello", size=32, steps=4)
        second = model._run_pipeline(prompt="hello", size=32, steps=4, seed=5)
    finally:
        if previous_torch is None:
            sys.modules.pop("torch", None)
        else:
            sys.modules["torch"] = previous_torch

    assert first.images[0]["generator"] is None
    assert second.images[0]["generator"] == "seeded:5"
    assert created_generators == [("cuda", 5)]


def test_diffusers_enables_cpu_offload_for_configured_device() -> None:
    """Diffusers CPU offload should target the backend device explicitly."""
    from track.inference.image.diffusers import DiffusersFluxImageModel

    captured: dict[str, object] = {}

    class FakePipeline:
        """Capture offload configuration without importing the real diffusers runtime."""

        def enable_model_cpu_offload(self, *, device: str) -> None:
            """Record the configured offload device."""
            captured["device"] = device

    class FakeFlux2KleinPipeline:
        """Provide the diffusers pipeline constructor used by the backend."""

        @staticmethod
        def from_pretrained(*_args: object, **kwargs: object) -> FakePipeline:
            """Return a fake pipeline and record load kwargs."""
            captured["load_kwargs"] = kwargs
            return FakePipeline()

    import sys

    previous_torch = sys.modules.get("torch")
    previous_diffusers = sys.modules.get("diffusers")
    fake_torch = types.ModuleType("torch")
    setattr(fake_torch, "bfloat16", "bfloat16")
    fake_diffusers = types.ModuleType("diffusers")
    setattr(fake_diffusers, "Flux2KleinPipeline", FakeFlux2KleinPipeline)
    sys.modules["torch"] = fake_torch
    sys.modules["diffusers"] = fake_diffusers
    try:
        model = DiffusersFluxImageModel(model_id="test/image", device="cuda")
    finally:
        if previous_torch is None:
            sys.modules.pop("torch", None)
        else:
            sys.modules["torch"] = previous_torch
        if previous_diffusers is None:
            sys.modules.pop("diffusers", None)
        else:
            sys.modules["diffusers"] = previous_diffusers

    assert model.pipeline is not None
    assert captured["device"] == "cuda"
    assert captured["load_kwargs"] == {"torch_dtype": "bfloat16", "cache_dir": None}


def test_diffusers_pipeline_runs_under_generation_lock() -> None:
    """Diffusers generation should serialize access to stateful offload hooks."""
    from track.inference.image.diffusers import DiffusersFluxImageModel

    model = DiffusersFluxImageModel.__new__(DiffusersFluxImageModel)
    model.device = "cuda"
    model.load_error = None
    model._generation_lock = __import__("threading").Lock()

    def fake_pipeline(**kwargs: object) -> SimpleNamespace:
        """Assert the pipeline is called while the wrapper lock is held."""
        acquired = model._generation_lock.acquire(blocking=False)
        if acquired:
            model._generation_lock.release()
        assert acquired is False
        return SimpleNamespace(images=[kwargs])

    model.pipeline = fake_pipeline

    import sys

    previous_torch = sys.modules.get("torch")
    fake_torch = types.ModuleType("torch")
    setattr(fake_torch, "Generator", lambda device: SimpleNamespace(manual_seed=lambda value: value))
    sys.modules["torch"] = fake_torch
    try:
        result = model._run_pipeline(prompt="hello", size=32, steps=4)
    finally:
        if previous_torch is None:
            sys.modules.pop("torch", None)
        else:
            sys.modules["torch"] = previous_torch

    assert result.images[0]["prompt"] == "hello"


def test_diffusers_streaming_recreates_pipeline_after_generation() -> None:
    """Diffusers streaming should replace the pipeline after callback-based partial decoding."""
    from track.inference.image.diffusers import DiffusersFluxImageModel

    class FakeNoGrad:
        """Provide a context manager compatible with torch.no_grad."""

        def __enter__(self) -> None:
            """Enter the no-grad context."""

        def __exit__(self, *_args: object) -> None:
            """Exit the no-grad context."""

    class FakeTorch(types.ModuleType):
        """Provide the small subset of torch used by the image backend."""

        class cuda:
            """Provide CUDA cache cleanup."""

            @staticmethod
            def empty_cache() -> None:
                """Accept cache cleanup requests."""

        @staticmethod
        def no_grad() -> FakeNoGrad:
            """Return a no-op no-grad context manager."""
            return FakeNoGrad()

    class FakePipeline:
        """Simulate one diffusers pipeline instance."""

        def __init__(self, name: str) -> None:
            """Store a stable pipeline identifier for assertions."""
            self.name = name
            self.calls = 0
            self.hook_resets = 0
            self.vae = SimpleNamespace(
                config={"scaling_factor": 2},
                decode=lambda latents, return_dict: [(latents, return_dict)],
            )
            self.image_processor = SimpleNamespace(postprocess=lambda image, output_type: [(image, output_type)])

        def __call__(self, **kwargs: object) -> SimpleNamespace:
            """Emit one intermediate callback and one final image."""
            self.calls += 1
            callback = cast(
                Callable[[object, int, object, dict[str, object]], object] | None,
                kwargs.get("callback_on_step_end"),
            )
            if callback is not None:
                callback(self, 0, None, {"latents": 8})
            return SimpleNamespace(images=[f"final-{self.name}-{self.calls}"])

        def maybe_free_model_hooks(self) -> None:
            """Record hook cleanup on the used pipeline."""
            self.hook_resets += 1

    pipelines: list[FakePipeline] = []

    def build_pipeline() -> FakePipeline:
        """Return a distinct fake pipeline each time Track rebuilds it."""
        pipeline = FakePipeline(name=f"pipeline-{len(pipelines)}")
        pipelines.append(pipeline)
        return pipeline

    model = DiffusersFluxImageModel.__new__(DiffusersFluxImageModel)
    model.model_id = "test/image"
    model.device = "cuda"
    model.model_path = None
    model.load_error = None
    model._generation_lock = __import__("threading").Lock()
    model.pipeline = build_pipeline()
    model._build_pipeline = build_pipeline

    import sys

    previous_torch = sys.modules.get("torch")
    sys.modules["torch"] = FakeTorch("torch")
    try:
        first_events = list(model.stream_image(prompt="hello", size=32, steps=4))
        first_replacement = model.pipeline
        second_events = list(model.stream_image(prompt="again", size=32, steps=4))
    finally:
        if previous_torch is None:
            sys.modules.pop("torch", None)
        else:
            sys.modules["torch"] = previous_torch

    assert [event.kind for event in first_events] == ["intermediate", "final"]
    assert [event.kind for event in second_events] == ["intermediate", "final"]
    assert len(pipelines) == 3
    assert pipelines[0].hook_resets == 1
    assert pipelines[1].hook_resets == 1
    assert first_replacement is pipelines[1]
    assert model.pipeline is pipelines[2]


def test_diffusers_non_stream_generation_reuses_pipeline() -> None:
    """Diffusers non-stream image generation should keep the existing pipeline instance."""
    from track.inference.image.diffusers import DiffusersFluxImageModel

    model = DiffusersFluxImageModel.__new__(DiffusersFluxImageModel)
    model.device = "cuda"
    model.load_error = None
    model._generation_lock = __import__("threading").Lock()
    model.pipeline = lambda **kwargs: SimpleNamespace(images=[kwargs])

    import sys

    previous_torch = sys.modules.get("torch")
    fake_torch = types.ModuleType("torch")
    setattr(fake_torch, "Generator", lambda device: SimpleNamespace(manual_seed=lambda value: value))
    sys.modules["torch"] = fake_torch
    try:
        first_image = model.generate_image(prompt="hello", size=32, steps=4)
        second_image = model.generate_image(prompt="again", size=32, steps=4)
    finally:
        if previous_torch is None:
            sys.modules.pop("torch", None)
        else:
            sys.modules["torch"] = previous_torch

    assert first_image["prompt"] == "hello"
    assert second_image["prompt"] == "again"


def test_diffusers_callback_generation_recreates_pipeline_after_partial_decode() -> None:
    """Diffusers callback image generation should rebuild after decoding intermediate latents."""
    from track.inference.image.diffusers import DiffusersFluxImageModel

    class FakeNoGrad:
        """Provide a context manager compatible with torch.no_grad."""

        def __enter__(self) -> None:
            """Enter the no-grad context."""

        def __exit__(self, *_args: object) -> None:
            """Exit the no-grad context."""

    class FakeTorch(types.ModuleType):
        """Provide the small subset of torch used by the image backend."""

        class cuda:
            """Provide CUDA cache cleanup."""

            @staticmethod
            def empty_cache() -> None:
                """Accept cache cleanup requests."""

        @staticmethod
        def no_grad() -> FakeNoGrad:
            """Return a no-op no-grad context manager."""
            return FakeNoGrad()

    class FakePipeline:
        """Simulate a diffusers pipeline that invokes callback-based partial decoding."""

        def __init__(self, name: str) -> None:
            """Store a stable pipeline identifier for assertions."""
            self.name = name
            self.hook_resets = 0
            self.vae = SimpleNamespace(
                config={"scaling_factor": 2},
                decode=lambda latents, return_dict: [(latents, return_dict)],
            )
            self.image_processor = SimpleNamespace(postprocess=lambda image, output_type: [(image, output_type)])

        def __call__(self, **kwargs: object) -> SimpleNamespace:
            """Invoke the provided step callback before returning a final image."""
            callback = cast(
                Callable[[object, int, object, dict[str, object]], object] | None,
                kwargs.get("callback_on_step_end"),
            )
            if callback is not None:
                callback(self, 0, None, {"latents": 8})
            return SimpleNamespace(images=[f"final-{self.name}"])

        def maybe_free_model_hooks(self) -> None:
            """Record hook cleanup on the used pipeline."""
            self.hook_resets += 1

    pipelines: list[FakePipeline] = []

    def build_pipeline() -> FakePipeline:
        """Return a distinct fake pipeline each time Track rebuilds it."""
        pipeline = FakePipeline(name=f"pipeline-{len(pipelines)}")
        pipelines.append(pipeline)
        return pipeline

    model = DiffusersFluxImageModel.__new__(DiffusersFluxImageModel)
    model.model_id = "test/image"
    model.device = "cuda"
    model.model_path = None
    model.load_error = None
    model._generation_lock = __import__("threading").Lock()
    model.pipeline = build_pipeline()
    model._build_pipeline = build_pipeline
    callback_images: list[object] = []

    import sys

    previous_torch = sys.modules.get("torch")
    sys.modules["torch"] = FakeTorch("torch")
    try:
        image = model.generate_image(
            prompt="hello",
            size=32,
            steps=4,
            callback=lambda _step, _total, callback_image: callback_images.append(callback_image),
        )
    finally:
        if previous_torch is None:
            sys.modules.pop("torch", None)
        else:
            sys.modules["torch"] = previous_torch

    assert image == "final-pipeline-0"
    assert callback_images == [((4.0, False), "pil")]
    assert len(pipelines) == 2
    assert pipelines[0].hook_resets == 1
    assert model.pipeline is pipelines[1]


def test_diffusers_streaming_resets_offload_hooks_between_generations() -> None:
    """Diffusers streaming should reset stateful offload hooks before the next generation."""
    from track.inference.image.diffusers import DiffusersFluxImageModel

    class FakeNoGrad:
        """Provide a context manager compatible with torch.no_grad."""

        def __enter__(self) -> None:
            """Enter the no-grad context."""

        def __exit__(self, *_args: object) -> None:
            """Exit the no-grad context."""

    class FakeTorch(types.ModuleType):
        """Provide the small subset of torch used by the image backend."""

        class cuda:
            """Record CUDA cache cleanup calls."""

            empty_cache_calls = 0

            @staticmethod
            def empty_cache() -> None:
                """Record that CUDA cache cleanup was requested."""
                FakeTorch.cuda.empty_cache_calls += 1

        @staticmethod
        def no_grad() -> FakeNoGrad:
            """Return a no-op no-grad context manager."""
            return FakeNoGrad()

    class FakePipeline:
        """Simulate a stateful offloaded diffusers pipeline."""

        def __init__(self) -> None:
            """Start with stale interruption state from a prior caller."""
            self._interrupt = True
            self.calls: list[dict[str, object]] = []
            self.hook_resets = 0
            self.vae = SimpleNamespace(
                config={"scaling_factor": 2},
                decode=lambda latents, return_dict: [(latents, return_dict)],
            )
            self.image_processor = SimpleNamespace(postprocess=lambda image, output_type: [(image, output_type)])

        def __call__(self, **kwargs: object) -> SimpleNamespace:
            """Run one fake generation and leave stale interrupt state behind."""
            if self._interrupt:
                raise RuntimeError("stale interrupt flag was not reset")
            if kwargs.get("callback_on_step_end_tensor_inputs") != ["latents"]:
                raise RuntimeError("latents were not requested for the step callback")
            self.calls.append(kwargs)
            callback = cast(
                Callable[[object, int, object, dict[str, object]], object] | None,
                kwargs.get("callback_on_step_end"),
            )
            if callback is not None:
                callback(self, 0, None, {"latents": 8})
            self._interrupt = True
            return SimpleNamespace(images=[f"final-{len(self.calls)}"])

        def maybe_free_model_hooks(self) -> None:
            """Record that stateful offload hooks were reset."""
            self.hook_resets += 1

    model = DiffusersFluxImageModel.__new__(DiffusersFluxImageModel)
    model.device = "cuda"
    model.load_error = None
    model._generation_lock = __import__("threading").Lock()
    pipelines: list[FakePipeline] = []

    def build_pipeline() -> FakePipeline:
        """Return a fresh fake pipeline for each rebuild."""
        pipeline = FakePipeline()
        pipelines.append(pipeline)
        return pipeline

    model.pipeline = build_pipeline()
    model._build_pipeline = build_pipeline

    import sys

    previous_torch = sys.modules.get("torch")
    sys.modules["torch"] = FakeTorch("torch")
    try:
        first_events = list(model.stream_image(prompt="hello", size=32, steps=4))
        second_events = list(model.stream_image(prompt="again", size=32, steps=4))
    finally:
        if previous_torch is None:
            sys.modules.pop("torch", None)
        else:
            sys.modules["torch"] = previous_torch

    assert [event.kind for event in first_events] == ["intermediate", "final"]
    assert [event.kind for event in second_events] == ["intermediate", "final"]
    assert pipelines[0].hook_resets == 1
    assert pipelines[1].hook_resets == 1
    assert FakeTorch.cuda.empty_cache_calls == 2


def test_diffusers_streaming_close_interrupts_worker_and_allows_next_generation() -> None:
    """Closing a diffusers image stream should interrupt the worker and clean up for reuse."""
    from track.inference.image.diffusers import DiffusersFluxImageModel

    class FakeNoGrad:
        """Provide a context manager compatible with torch.no_grad."""

        def __enter__(self) -> None:
            """Enter the no-grad context."""

        def __exit__(self, *_args: object) -> None:
            """Exit the no-grad context."""

    class FakeTorch(types.ModuleType):
        """Provide the small subset of torch used by the image backend."""

        class cuda:
            """Provide CUDA cache cleanup."""

            @staticmethod
            def empty_cache() -> None:
                """Accept cache cleanup requests."""

        @staticmethod
        def no_grad() -> FakeNoGrad:
            """Return a no-op no-grad context manager."""
            return FakeNoGrad()

    class FakePipeline:
        """Simulate a pipeline that can be interrupted between preview callbacks."""

        def __init__(self) -> None:
            """Prepare synchronization points for the stream lifecycle test."""
            self._interrupt = False
            self.call_count = 0
            self.hook_resets = 0
            self.preview_queue: Queue[object] = Queue()
            self.vae = SimpleNamespace(
                config={"scaling_factor": 2},
                decode=lambda latents, return_dict: [(latents, return_dict)],
            )
            self.image_processor = SimpleNamespace(postprocess=lambda image, output_type: [(image, output_type)])

        def __call__(self, **kwargs: object) -> SimpleNamespace:
            """Generate previews until interruption is requested."""
            self.call_count += 1
            callback = cast(
                Callable[[object, int, object, dict[str, object]], object] | None,
                kwargs.get("callback_on_step_end"),
            )
            if callback is not None:
                callback(self, 0, None, {"latents": 8})
                self.preview_queue.put("preview")
            deadline = time.monotonic() + 1.0
            while not self._interrupt and time.monotonic() < deadline:
                time.sleep(0.01)
            if self._interrupt:
                return SimpleNamespace(images=[f"interrupted-{self.call_count}"])
            return SimpleNamespace(images=[f"final-{self.call_count}"])

        def maybe_free_model_hooks(self) -> None:
            """Record that stateful offload hooks were reset."""
            self.hook_resets += 1

    model = DiffusersFluxImageModel.__new__(DiffusersFluxImageModel)
    model.device = "cuda"
    model.load_error = None
    model._generation_lock = __import__("threading").Lock()
    pipelines: list[FakePipeline] = []

    def build_pipeline() -> FakePipeline:
        """Return a fresh fake pipeline for each rebuild."""
        pipeline = FakePipeline()
        pipelines.append(pipeline)
        return pipeline

    model.pipeline = build_pipeline()
    model._build_pipeline = build_pipeline

    import sys

    previous_torch = sys.modules.get("torch")
    sys.modules["torch"] = FakeTorch("torch")
    try:
        stream = model.stream_image(prompt="hello", size=32, steps=4)
        first_event = next(stream)
        first_pipeline = model.pipeline
        stream.close()

        assert first_pipeline.preview_queue.get(timeout=1.0) == "preview"
        next_events = list(model.stream_image(prompt="again", size=32, steps=4))
    finally:
        if previous_torch is None:
            sys.modules.pop("torch", None)
        else:
            sys.modules["torch"] = previous_torch

    assert first_event.kind == "intermediate"
    assert pipelines[0].call_count == 1
    assert pipelines[1].call_count == 1
    assert pipelines[0].hook_resets == 1
    assert pipelines[1].hook_resets == 1
    assert next_events[-1].kind == "final"


def test_diffusers_unpacks_flux2_packed_step_latents_before_vae_decode() -> None:
    """Diffusers intermediate decoding should convert FLUX.2 token latents to VAE layout."""
    from track.inference.image.diffusers import _prepare_vae_decode_latents

    class FakeLatents:
        """Track tensor-like shape transforms used by the FLUX.2 unpacking path."""

        def __init__(self, shape: tuple[int, ...]) -> None:
            """Store the current fake tensor shape."""
            self.shape = shape

        def reshape(self, *shape: int) -> "FakeLatents":
            """Return a fake tensor with the requested shape."""
            return FakeLatents(shape)

        def permute(self, *dimensions: int) -> "FakeLatents":
            """Return a fake tensor with dimensions reordered like PyTorch."""
            return FakeLatents(tuple(self.shape[dimension] for dimension in dimensions))

    pipe = SimpleNamespace(vae=SimpleNamespace(config={}))
    latents = FakeLatents((1, 4096, 128))

    decode_latents = _prepare_vae_decode_latents(pipe, latents)

    assert decode_latents.shape == (1, 32, 128, 128)


def test_diffusers_denormalizes_flux2_step_latents_before_unpatchifying() -> None:
    """FLUX.2 intermediate decoding should apply VAE BN stats before reducing patch channels."""
    from track.inference.image.diffusers import _prepare_vae_decode_latents

    class FakeShapeTensor:
        """Track tensor-like shape transforms and channel-wise arithmetic."""

        device = "cuda"
        dtype = "bfloat16"

        def __init__(self, shape: tuple[int, ...]) -> None:
            """Store the current fake tensor shape."""
            self.shape = shape

        def reshape(self, *shape: int) -> "FakeShapeTensor":
            """Return a fake tensor with the requested shape."""
            return FakeShapeTensor(shape)

        def permute(self, *dimensions: int) -> "FakeShapeTensor":
            """Return a fake tensor with dimensions reordered like PyTorch."""
            return FakeShapeTensor(tuple(self.shape[dimension] for dimension in dimensions))

        def __mul__(self, other: "FakeChannelVector") -> "FakeShapeTensor":
            """Require channel-wise operands to match the tensor channel dimension."""
            if self.shape[1] != other.shape[1]:
                raise RuntimeError(
                    f"The size of tensor a ({self.shape[1]}) must match the size of tensor b ({other.shape[1]})"
                )
            return self

        def __add__(self, other: "FakeChannelVector") -> "FakeShapeTensor":
            """Require channel-wise operands to match the tensor channel dimension."""
            if self.shape[1] != other.shape[1]:
                raise RuntimeError(
                    f"The size of tensor a ({self.shape[1]}) must match the size of tensor b ({other.shape[1]})"
                )
            return self

    class FakeChannelVector:
        """Represent a broadcastable VAE batch-normalization vector."""

        def __init__(self, channels: int) -> None:
            """Store the channel count represented by the vector."""
            self.shape = (1, channels, 1, 1)

        def view(self, *_shape: int) -> "FakeChannelVector":
            """Return a broadcastable view of the vector."""
            return self

        def to(self, _device: object, _dtype: object) -> "FakeChannelVector":
            """Return the vector on the requested fake device and dtype."""
            return self

        def __add__(self, _other: object) -> "FakeChannelVector":
            """Return the vector for scalar addition."""
            return self

        def sqrt(self) -> "FakeChannelVector":
            """Return the vector for square-root operations."""
            return self

    pipe = SimpleNamespace(
        vae=SimpleNamespace(
            bn=SimpleNamespace(
                running_mean=FakeChannelVector(128),
                running_var=FakeChannelVector(128),
            ),
            config={"batch_norm_eps": 1e-5},
        )
    )

    decode_latents = _prepare_vae_decode_latents(pipe, FakeShapeTensor((1, 4096, 128)))

    assert decode_latents.shape == (1, 32, 128, 128)


def test_diffusers_rejects_non_square_flux2_packed_step_latents() -> None:
    """Diffusers intermediate decoding should fail clearly for unexpected packed latent grids."""
    from track.inference.image.diffusers import _prepare_vae_decode_latents

    class FakeLatents:
        """Provide only the shape needed to detect packed FLUX.2 latents."""

        shape = (1, 4095, 128)

    pipe = SimpleNamespace(vae=SimpleNamespace(config={}))

    with pytest.raises(ValueError, match="Cannot unpack non-square FLUX.2 latents"):
        _prepare_vae_decode_latents(pipe, FakeLatents())


def test_diffusers_decodes_step_images_with_mapping_vae_config() -> None:
    """Diffusers intermediate decoding should accept FrozenDict-style VAE configs."""
    from track.inference.image.diffusers import DiffusersFluxImageModel

    class FakeNoGrad:
        """Provide a context manager compatible with torch.no_grad."""

        def __enter__(self) -> None:
            """Enter the no-grad context."""

        def __exit__(self, *_args: object) -> None:
            """Exit the no-grad context."""

    class FakeTorch(types.ModuleType):
        """Provide the small subset of torch used by the image backend."""

        @staticmethod
        def no_grad() -> FakeNoGrad:
            """Return a no-op no-grad context manager."""
            return FakeNoGrad()

    decoded_images: list[object] = []
    pipe = SimpleNamespace(
        vae=SimpleNamespace(
            config={"scaling_factor": 2},
            decode=lambda scaled_latents, return_dict: decoded_images.append(
                (scaled_latents, return_dict)
            )
            or ["decoded"],
        ),
        image_processor=SimpleNamespace(
            postprocess=lambda image, output_type: [(image, output_type)],
        ),
    )
    model = DiffusersFluxImageModel.__new__(DiffusersFluxImageModel)

    import sys

    previous_torch = sys.modules.get("torch")
    sys.modules["torch"] = FakeTorch("torch")
    try:
        image = model._decode_step_image(pipe, 8)
    finally:
        if previous_torch is None:
            sys.modules.pop("torch", None)
        else:
            sys.modules["torch"] = previous_torch

    assert image == ("decoded", "pil")
    assert decoded_images == [(4.0, False)]


def test_diffusers_defaults_missing_vae_scaling_factor_to_one(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Diffusers intermediate decoding should log when defaulting a missing VAE scaling factor."""
    from track.inference.image.diffusers import _resolve_vae_scaling_factor

    with caplog.at_level("WARNING", logger="track.inference.image.diffusers"):
        scaling_factor = _resolve_vae_scaling_factor({})

    assert scaling_factor == 1
    assert "defaulting to 1" in caplog.text
