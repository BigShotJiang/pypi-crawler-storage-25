from setuptools import setup, find_packages

setup(
    name="fire-eye-teambcs", 
    version="3.1.0", # প্রতিবার আপলোডের সময় ভার্সন বাড়িয়ে দিবেন
    author="TEAMBCS",
    author_email="bcs.team.oficial@gmail.com",
    license="MIT",
    description="Advanced WAF Detector & Security Scanner",
    long_description="Advanced WAF Detector & Security Scanner Developed by TEAMBCS",
    long_description_content_type="text/markdown",
    url="https://github.com/TEAMBCS/Fire-Eye", 
    packages=find_packages(),
    install_requires=[
        "requests",
        "aiohttp",
        "colorama",
        "rich",
        "pyfiglet",
        "aiohttp[socks]",
        "aiohttp-socks",
    ],
    python_requires='>=3.8',
    entry_points={
        'console_scripts': [
            'fire-eye=fire_eye.run:start', 
        ],
    },
    include_package_data=True, # এটি যোগ করতে পারেন
    zip_safe=False,
)
