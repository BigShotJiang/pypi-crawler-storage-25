import sys
import os

def start():
    try:
        import fire_eye.main 
    except Exception:
        sys.exit(0)

if __name__ == "__main__":
    start()
