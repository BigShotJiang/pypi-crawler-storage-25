# graph/core_graph.py
from __future__ import annotations

import multiprocessing
import threading
import time
import warnings
from collections import defaultdict
from dataclasses import dataclass
from multiprocessing import Queue as MPQueue
from pathlib import Path
from typing import Any

from celestialtree import (
    Client as CelestialTreeClient,
)
from celestialtree import (
    NullClient as NullCelestialTreeClient,
)
from celestialtree import (
    format_descendants_forest,
    format_provenance_forest,
)
from networkx import is_directed_acyclic_graph, DiGraph

from ..observability import NullTaskReporter, TaskReporter
from ..persistence import FailInlet, FailSpout, LogInlet, LogSpout
from ..persistence.util_jsonl import load_task_by_error, load_task_by_stage
from ..runtime import TaskEnvelope, TaskInQueue, TaskOutQueue
from ..runtime.util_errors import (
    CelestialTreeConnectionError,
    ScheduleModeError,
    UnconsumedError,
)
from ..runtime.util_estimators import (
    calc_elapsed,
    calc_global_remain_equal_pred,
    calc_remaining,
)
from ..runtime.util_types import (
    STAGE_STYLE,
    CTreeEvent,
    StageStatus,
    TerminationSignal,
)
from ..stage import TaskStage
from ..utils.util_collections import cluster_by_value_sorted
from ..utils.util_format import format_avg_time
from .util_analysis import (
    compute_node_levels,
    format_networkx_graph,
)
from .util_serialize import build_structure_graph, format_structure_list_from_graph


@dataclass
class StageRuntime:
    """单个 Stage 的运行时封装，保存阶段实例及其输入输出队列。"""

    stage: TaskStage
    in_queue: TaskInQueue
    out_queue: TaskOutQueue
    start_time: float = 0.0


class TaskGraph:
    """任务图核心类，负责构建、连接和调度一组 TaskStage 节点。"""

    # ==== 初始化 ====

    def __init__(
        self,
        schedule_mode: str = "eager",
        log_level: str = "SUCCESS",
    ) -> None:
        """
        初始化 TaskGraph 实例。

        TaskGraph 表示一组 TaskStage 节点所构成的任务图，可用于构建并行、串行、
        分层等多种形式的任务执行流程。通过分析图结构和调度布局策略，实现灵活的
        DAG 任务调度控制。

        :param schedule_mode: str, optional, default = 'eager'
            控制任务图的调度布局模式，支持以下两种策略：
            - 'eager'：
                默认模式。所有节点一次性调度并发执行，依赖关系通过队列流自动控制。
                适用于最大化并行度的执行场景。
            - 'staged'：
                分层执行模式。任务图必须为有向无环图（DAG）。
                节点按层级顺序逐层启动，确保上层所有任务完成后再启动下一层。
                更利于调试、性能分析和阶段性资源控制。

        :param log_level: str, optional, default = 'SUCCESS'
            日志级别，支持以下级别：
            - 'TRACE'
            - 'DEBUG'
            - 'SUCCESS'
            - 'INFO'
            - 'WARNING'
            - 'ERROR'
            - 'CRITICAL'
        """
        self._set_log_level(log_level)
        self._set_schedule_mode(schedule_mode)
        self.set_reporter()
        self.set_ctree()

        self._init_env()

    def _init_env(self) -> None:
        """
        初始化环境
        """
        self._init_state()
        self._init_spout()
        self._init_inlet()

    def _init_state(self) -> None:
        """
        初始化状态
        """
        # 用于保存所有子进程的引用
        self.processes: list[multiprocessing.Process] = []
        # 用于保存所有子线程的引用
        self.threads: list[threading.Thread] = []
        # 用于保存每个节点的运行信息
        self.stage_runtime_dict: dict[str, StageRuntime] = {}
        # 用于保存每个节点的上一次collect_runtime_snapshot()的状态信息
        self.status_dict: dict[str, dict[str, Any]] = defaultdict(dict)
        # 用于保存任务图的摘要信息
        self.graph_summary: dict[str, int | float] = {}
        # 用于保存每个节点的历史状态信息列表（仅保留最近20条）
        self.stage_history: dict[str, list[dict]] = {}
        # 用于保存每个节点的输入任务ID集合
        self.input_ids: dict[str, set[int]] = defaultdict(set)
        # 用于保存根节点列表
        self.root_stages: list[TaskStage] = []
        # 用于保存图结构的邻接表
        self.out_edges: dict[str, list[str]] = defaultdict(list)
        self.in_edges: dict[str, list[str]] = defaultdict(list)

    def _init_spout(self) -> None:
        """
        初始化监听器
        """
        self.log_spout = LogSpout()
        self.fail_spout = FailSpout("graph_errors")

    def _init_inlet(self) -> None:
        """
        初始化收集器
        """
        self.log_inlet = LogInlet(self.log_spout.get_queue(), self.log_level)
        self.fail_inlet = FailInlet(self.fail_spout.get_queue())

    # ==== 建图 ====

    def set_stages(self, root_stages: list[TaskStage], stages: list[TaskStage]) -> None:
        """
        添加节点到任务图中

        :param root_stages: 根节点列表
        :param stages: 待添加的节点列表
        """
        self.root_stages = root_stages

        for stage in stages + root_stages:
            if stage.get_tag() in self.stage_runtime_dict:
                continue

            stage_tag = stage.get_tag()
            in_queue = TaskInQueue(
                queue=MPQueue(),
                queue_tags=[],
                out_tag=stage.get_tag(),
                log_inlet=self.log_inlet,
            )
            out_queue = TaskOutQueue(
                queue_list=[],
                queue_tags=[],
                in_tag=stage.get_tag(),
                log_inlet=self.log_inlet,
            )

            self.stage_runtime_dict[stage_tag] = StageRuntime(
                stage=stage,
                in_queue=in_queue,
                out_queue=out_queue,
            )

    def connect(self, from_stages: list[TaskStage], to_stages: list[TaskStage]) -> None:
        """
        建立超边连接：from_stages 中的每个节点连接到 to_stages 中的每个节点。

        :param from_stages: 上游节点列表
        :param to_stages: 下游节点列表
        """
        for from_stage in from_stages:
            for to_stage in to_stages:
                self.out_edges[from_stage.get_tag()].append(to_stage.get_tag())
                self.in_edges[to_stage.get_tag()].append(from_stage.get_tag())

    # ==== 配置 ====

    def _set_schedule_mode(self, schedule_mode: str) -> None:
        """
        设置任务链的执行模式

        :param schedule_mode: 节点执行模式, 可选值为 'eager' 或 'staged'
        """
        if schedule_mode == "eager":
            self.schedule_mode = "eager"
        elif schedule_mode == "staged":
            self.schedule_mode = "staged"
        else:
            raise ScheduleModeError(schedule_mode)

    def _set_log_level(self, level: str = "SUCCESS") -> None:
        """
        设置日志级别

        :param level: 日志级别, 默认为 "SUCCESS"
        """
        self.log_level = level.upper()

    def set_reporter(
        self, is_report: bool = False, host: str = "127.0.0.1", port: int = 5000
    ) -> None:
        """
        设定报告器

        :param is_report: 是否启用报告器
        :param host: 报告器主机地址
        :param port: 报告器端口
        """
        self._is_report = is_report
        self._report_host = host
        self._report_port = port
        self.reporter: TaskReporter | NullTaskReporter
        if is_report:
            self.reporter = TaskReporter(
                host=host,
                port=port,
                task_graph=self,
                log_inlet=self.log_inlet,
            )
        else:
            self.reporter = NullTaskReporter()

    def set_ctree(
        self,
        use_ctree: bool = False,
        host: str = "127.0.0.1",
        http_port: int = 7777,
        grpc_port: int = 7778,
        transport: str = "grpc",
    ) -> None:
        """
        设定事件树客户端

        :param use_ctree: 是否使用事件树
        :param host: 事件树主机地址
        :param http_port: 事件树 HTTP 端口
        :param grpc_port: 事件树 gRPC 端口
        :param transport: 传输方式, 可选 'grpc' 或 'http'
        """
        self._use_ctree = use_ctree
        self._ctree_host = host
        self._ctree_http_port = http_port
        self._ctree_grpc_port = grpc_port
        self._ctree_transport = transport

        if use_ctree:
            self.ctree_client = CelestialTreeClient(
                host=host, http_port=http_port, grpc_port=grpc_port, transport=transport
            )
            if not self.ctree_client.health():
                raise CelestialTreeConnectionError()
        else:
            self.ctree_client = NullCelestialTreeClient()

    def set_graph_mode(self, stage_mode: str, execution_mode: str) -> None:
        """
        设置任务链的执行模式

        :param stage_mode: 节点执行模式, 可选值为 'serial', 'thread' 或 'process'
        :param execution_mode: 节点内部执行模式, 可选值为 'serial', 'thread' 或 'async'
        """

        def set_subsequent_stage_mode(stage: TaskStage) -> None:
            """
            递归设置当前节点及其所有后续节点的执行模式。

            :param stage: 当前节点
            """
            stage.set_stage_mode(stage_mode)
            stage.set_execution_mode(execution_mode)
            visited_stages.add(stage)

            for next_stage_tag in self.out_edges[stage.get_tag()]:
                next_stage = self.stage_runtime_dict[next_stage_tag].stage
                if next_stage in visited_stages:
                    continue
                set_subsequent_stage_mode(next_stage)

        visited_stages: set[TaskStage] = set()
        for root_stage in self.root_stages:
            set_subsequent_stage_mode(root_stage)
        self._build_analysis()

    # ==== 启动 ====

    def _build_resources(self) -> None:
        """
        构建每个阶段的运行时资源（队列、计数器、前驱绑定）
        """
        for stage_tag, stage_runtime in self.stage_runtime_dict.items():
            if not self.in_edges[stage_tag]:  # 如果没有前驱
                continue

            current_stage: TaskStage = stage_runtime.stage
            in_queue: TaskInQueue = stage_runtime.in_queue
            prev_stages: list[TaskStage] = []

            # 遍历每个前驱，创建边队列
            for prev_stage_tag in self.in_edges[stage_tag]:
                prev_stage = self.stage_runtime_dict[prev_stage_tag].stage
                in_queue.add_source_tag(prev_stage_tag)

                prev_out_queue: TaskOutQueue = self.stage_runtime_dict[
                    prev_stage_tag
                ].out_queue
                prev_out_queue.add_queue(in_queue.queue, stage_tag)
                prev_stages.append(prev_stage)

            current_stage.prev_bindings(prev_stages)

    def _build_analysis(self) -> None:
        """
        分析任务图，计算 DAG 属性和层级信息
        """
        self.structure_json = build_structure_graph(
            self.root_stages, self.out_edges, self.stage_runtime_dict
        )
        self.structure_list = format_structure_list_from_graph(self.structure_json)
        self.networkx_graph = format_networkx_graph(self.structure_json)

        self.isDAG = is_directed_acyclic_graph(self.networkx_graph)
        self.layers_dict = {}
        if self.isDAG:
            stage_level_dict = compute_node_levels(self.networkx_graph)
            self.layers_dict = cluster_by_value_sorted(stage_level_dict)

    def start_graph(
        self, init_tasks_dict: dict, put_termination_signal: bool = True
    ) -> None:
        """
        启动任务链

        :param init_tasks_dict: 任务列表
        :param put_termination_signal: 是否注入终止信号
        """
        self._build_resources()
        self._build_analysis()

        if not self.isDAG and put_termination_signal:
            warnings.warn(
                "Early injection of termination signals in a non-DAG graph may cause "
                "some nodes (including root nodes) to shut down as soon as their current "
                "tasks are exhausted, preventing them from consuming tasks that arrive "
                "later from other nodes. It is recommended to set put_termination_signal=False "
                "and manually inject termination signals via the web interface at an "
                "appropriate time.",
                RuntimeWarning,
            )
        start_time = time.perf_counter()

        try:
            self.fail_spout.start()
            self.log_spout.start()
            self.log_inlet.start_graph(self.get_structure_list())
            self.fail_inlet.start_graph(self.get_structure_json())
            self.reporter.start()

            self.put_stage_queue(init_tasks_dict, put_termination_signal)
            self._execute_stages()

        finally:
            self._finalize_nodes()

            self.reporter.stop()
            self._release_resources()
            self.log_inlet.end_graph(time.perf_counter() - start_time)
            self.fail_spout.stop()
            self.log_spout.stop()

    # ==== 执行 ====

    def put_stage_queue(
        self, tasks_dict: dict, put_termination_signal: bool = True
    ) -> None:
        """
        将任务放入队列

        :param tasks_dict: 待处理的任务字典
        :param put_termination_signal: 是否放入终止信号
        """
        for tag, tasks in tasks_dict.items():
            stage: TaskStage = self.stage_runtime_dict[tag].stage
            in_queue: TaskInQueue = self.stage_runtime_dict[tag].in_queue
            input_ids: set = self.input_ids[tag]

            for task in tasks:
                if isinstance(task, TerminationSignal):
                    termination_id = self.ctree_client.emit(
                        CTreeEvent.TERMINATION_INPUT,
                        payload=stage.get_summary(),
                    )
                    in_queue.put(TerminationSignal(termination_id, source="input"))
                    continue

                input_id = self.ctree_client.emit(
                    CTreeEvent.TASK_INPUT,
                    payload=stage.get_summary(),
                )
                envelope = TaskEnvelope.wrap(task, input_id, source="input")
                in_queue.put(envelope)
                input_ids.add(input_id)

                stage.metrics.add_task_count()
                self.log_inlet.task_input(
                    stage.get_func_name(),
                    stage.get_task_repr(task),
                    stage.get_tag(),
                    input_id,
                )

        if put_termination_signal:
            for root_stage in self.root_stages:
                root_stage_tag = root_stage.get_tag()
                root_in_queue: TaskInQueue = self.stage_runtime_dict[
                    root_stage_tag
                ].in_queue

                termination_id = self.ctree_client.emit(
                    CTreeEvent.TERMINATION_INPUT,
                    payload=root_stage.get_summary(),
                )
                root_in_queue.put(TerminationSignal(termination_id, source="input"))
                self.log_inlet.termination_input(
                    root_stage.get_func_name(),
                    root_stage.get_tag(),
                    termination_id,
                )

    def _execute_stages(self) -> None:
        """
        执行所有节点
        """
        if self.schedule_mode == "eager":
            # eager schedule_mode：一次性执行所有节点
            for stage_runtime in self.stage_runtime_dict.values():
                self._execute_stage(stage_runtime.stage)

            for p in self.processes:
                p.join()
                self.log_inlet.process_exit(p.name, p.exitcode)
            for t in self.threads:
                t.join()
        elif self.schedule_mode == "staged":
            # staged schedule_mode：一层层地顺序执行
            for layer_level, layer in self.layers_dict.items():
                self.log_inlet.start_layer(layer, layer_level)
                start_time = time.perf_counter()

                processes = []
                threads = []
                for stage_tag in layer:
                    stage: TaskStage = self.stage_runtime_dict[stage_tag].stage
                    self._execute_stage(stage)
                    if stage.stage_mode == "process":
                        processes.append(self.processes[-1])
                    elif stage.stage_mode == "thread":
                        threads.append(self.threads[-1])

                # join 当前层的所有进程和线程
                for p in processes:
                    p.join()
                    self.log_inlet.process_exit(p.name, p.exitcode)
                for t in threads:
                    t.join()

                self.log_inlet.end_layer(layer, time.perf_counter() - start_time)

    def _execute_stage(self, stage: TaskStage) -> None:
        """
        执行单个节点

        :param stage: 节点
        """
        stage_tag = stage.get_tag()
        stage_runtime = self.stage_runtime_dict[stage_tag]

        fail_queue = self.fail_spout.get_queue()
        log_queue = self.log_spout.get_queue()

        # 输入输出队列
        input_queues: TaskInQueue = stage_runtime.in_queue
        output_queues: TaskOutQueue = stage_runtime.out_queue

        stage_runtime.start_time = time.time()

        if self._use_ctree:
            stage.set_ctree(
                self._ctree_host, self._ctree_http_port, self._ctree_grpc_port
            )
        else:
            stage.set_nullctree(self.ctree_client.event_id)

        stage.set_log_level(self.log_level)

        if stage.stage_mode == "process":
            p = multiprocessing.Process(
                target=stage.start_stage,
                args=(input_queues, output_queues, fail_queue, log_queue),
                name=stage_tag,
            )
            p.start()
            self.processes.append(p)
        elif stage.stage_mode == "thread":
            t = threading.Thread(
                target=stage.start_stage,
                args=(input_queues, output_queues, fail_queue, log_queue),
                name=stage_tag,
                daemon=True,
            )
            t.start()
            self.threads.append(t)
        else:
            stage.start_stage(input_queues, output_queues, fail_queue, log_queue)

    # ==== 终止与清理 ====

    def _finalize_nodes(self) -> None:
        """
        确保所有子进程安全结束，更新节点状态，并导出每个节点队列剩余任务。
        """
        # 确保所有进程安全结束（不一定要 terminate，但如果没结束就强制）
        for p in self.processes:
            if p.is_alive():
                self.log_inlet.process_termination_attempt(p.name)
                p.terminate()
                p.join(timeout=5)
                if p.is_alive():
                    self.log_inlet.process_termination_timeout(p.name)
                self.log_inlet.process_exit(p.name, p.exitcode)

        # 确保所有线程安全结束（线程不可 terminate，仅做 cooperative join）
        for t in self.threads:
            t.join(timeout=10)
            if t.is_alive():
                self.log_inlet.process_termination_timeout(t.name)

        # 更新所有节点状态为"已停止"
        for stage_runtime in self.stage_runtime_dict.values():
            stage: TaskStage = stage_runtime.stage
            stage.mark_stopped()

        # 收集并持久化每个 stage 中未消费的任务
        for stage_tag, stage_runtime in self.stage_runtime_dict.items():
            current_stage: TaskStage = stage_runtime.stage
            in_queue: TaskInQueue = stage_runtime.in_queue

            remaining_sources = in_queue.drain()
            current_stage.metrics.add_error_count(len(remaining_sources))

            # 持久化逻辑
            for source in remaining_sources:
                task = source.task
                task_id = source.id
                error_id = self.ctree_client.emit(
                    CTreeEvent.TASK_ERROR,
                    [task_id],
                    payload=current_stage.get_summary(),
                )

                self.fail_inlet.task_error(stage_tag, UnconsumedError(), error_id, task)

                self.log_inlet.task_error(
                    current_stage.get_func_name(),
                    current_stage.get_task_repr(task),
                    UnconsumedError(),
                    task_id,
                    error_id,
                )

    def _release_resources(self) -> None:
        """
        释放资源
        """
        for stage_runtime in self.stage_runtime_dict.values():
            stage: TaskStage = stage_runtime.stage
            stage.release_queue()

    # ==== 运行时监控 ====

    def _snapshot_one_stage(
        self,
        stage_tag: str,
        stage: TaskStage,
        stage_runtime: StageRuntime,
        last_status: dict,
        now: float,
        interval: float,
        history_limit: int,
    ) -> tuple[dict, list[dict], tuple[int, int, float, float]]:
        """
        计算单个 stage 的运行时快照

        :param stage_tag: 节点标签
        :param stage: 节点实例
        :param stage_runtime: 节点运行时信息
        :param last_status: 上一次快照的状态字典
        :param now: 当前时间戳
        :param interval: 快照采集间隔
        :param history_limit: 历史记录最大条数
        :return: (stage_snapshot_dict, history_list, running_metrics)，
            其中 running_metrics = (processed, pending, elapsed, remaining)
        """
        status = stage.get_status()
        stage_counts = stage.get_counts()

        keys = [
            "tasks_succeeded",
            "tasks_pending",
            "tasks_failed",
            "tasks_duplicated",
            "tasks_processed",
        ]
        deltas = {f"add_{k}": stage_counts[k] - last_status.get(k, 0) for k in keys}

        start_time = stage_runtime.start_time
        last_elapsed = last_status.get("elapsed_time", 0)
        last_pending = last_status.get("tasks_pending", 0)
        elapsed = calc_elapsed(status, last_elapsed, last_pending, interval)

        remaining = calc_remaining(
            stage_counts["tasks_processed"], stage_counts["tasks_pending"], elapsed
        )

        # 计算平均时间（秒/任务）并格式化为字符串
        avg_time_str = format_avg_time(elapsed, stage_counts["tasks_processed"])

        history: list = list(self.stage_history.get(stage_tag, []))
        history.append(
            {
                "timestamp": now,
                "tasks_processed": stage_counts["tasks_processed"],
            }
        )
        history.pop(0) if len(history) > history_limit else None

        snapshot = {
            **stage.get_summary(),
            "status": status,
            **stage_counts,
            **deltas,
            "start_time": start_time,
            "elapsed_time": elapsed,
            "remaining_time": remaining,
            "task_avg_time": avg_time_str,
        }

        processed = int(stage_counts["tasks_processed"] or 0)
        pending = int(stage_counts["tasks_pending"] or 0)
        elapsed_f = float(elapsed or 0.0)
        remaining_f = float(remaining or 0.0)

        return snapshot, history, (processed, pending, elapsed_f, remaining_f)

    def _calc_graph_remain(
        self,
        running_processed_map: dict[str, int],
        running_pending_map: dict[str, int],
        running_elapsed_map: dict[str, float],
        running_remaining_map: dict[str, float],
    ) -> float:
        """
        根据 DAG/非 DAG 策略计算全局预计剩余时间

        :param running_processed_map: 各节点已处理任务数
        :param running_pending_map: 各节点待处理任务数
        :param running_elapsed_map: 各节点已用时间
        :param running_remaining_map: 各节点预计剩余时间
        :return: 全局预计剩余时间（秒）
        """
        if not self.isDAG:
            return max(running_remaining_map.values(), default=0.0)

        expected_pending_map = calc_global_remain_equal_pred(
            self.networkx_graph,
            running_processed_map,
            running_pending_map,
            running_elapsed_map,
        )
        return max(expected_pending_map.values(), default=0.0)

    def collect_runtime_snapshot(self) -> None:
        """
        收集运行时快照
        """
        status_dict: dict[str, dict] = {}
        history_dict: dict[str, list[dict]] = {}
        now = time.time()
        interval = self.reporter.interval
        history_limit = self.reporter.history_limit

        totals = {
            "total_succeeded": 0,
            "total_pending": 0,
            "total_failed": 0,
            "total_duplicated": 0,
            "total_nodes": 0,
            "total_remain": 0.0,
        }

        # 为全局预计 remaining 收集
        running_elapsed_map: dict[str, float] = {}
        running_processed_map: dict[str, int] = {}
        running_pending_map: dict[str, int] = {}
        running_remaining_map: dict[str, float] = {}

        for stage_tag, stage_runtime in self.stage_runtime_dict.items():
            stage: TaskStage = stage_runtime.stage
            last_status = self.status_dict.get(stage_tag, {})

            snapshot, history, (processed, pending, elapsed, remaining) = (
                self._snapshot_one_stage(
                    stage_tag,
                    stage,
                    stage_runtime,
                    last_status,
                    now,
                    interval,
                    history_limit,
                )
            )

            totals["total_succeeded"] += snapshot["tasks_succeeded"]
            totals["total_pending"] += snapshot["tasks_pending"]
            totals["total_failed"] += snapshot["tasks_failed"]
            totals["total_duplicated"] += snapshot["tasks_duplicated"]

            if snapshot["status"] == StageStatus.RUNNING:
                totals["total_nodes"] += 1

            status_dict[stage_tag] = snapshot
            history_dict[stage_tag] = history

            running_processed_map[stage_tag] = processed
            running_pending_map[stage_tag] = pending
            running_elapsed_map[stage_tag] = elapsed
            running_remaining_map[stage_tag] = remaining

        totals["total_remain"] = self._calc_graph_remain(
            running_processed_map,
            running_pending_map,
            running_elapsed_map,
            running_remaining_map,
        )

        self.status_dict = status_dict
        self.graph_summary = dict(totals)
        self.stage_history = dict(history_dict)

    # ==== 查询接口 ====

    def get_fail_by_stage_dict(self) -> dict:
        """
        获取按节点分组的失败任务字典

        :return: {stage_tag: [失败任务列表]}
        """
        return load_task_by_stage(self.fail_spout.jsonl_path)

    def get_fail_by_error_dict(self) -> dict:
        """
        获取按错误类型分组的失败任务字典

        :return: {error_type: [失败任务列表]}
        """
        return load_task_by_error(self.fail_spout.jsonl_path)

    def get_total_error_num(self) -> int:
        """
        获取总错误数

        :return: 错误总数
        """
        return self.fail_spout.total_error_num

    def get_status_dict(self) -> dict[str, dict]:
        """
        获取任务链的状态字典

        :return: 任务链状态字典
        """
        return self.status_dict

    def get_graph_summary(self) -> dict:
        """
        获取任务链的摘要信息字典

        :return: 包含 total_succeeded, total_pending, total_failed 等字段的字典
        """
        return self.graph_summary

    def get_stage_history(self) -> dict[str, list[dict]]:
        """
        获取各节点的历史状态信息字典

        :return: {stage_tag: [历史快照列表]}
        """
        return self.stage_history

    def get_graph_analysis(self) -> dict:
        """
        获取任务图的分析信息

        :return: 包含 isDAG, schedule_mode, class_name, layers_dict 的字典
        """
        return {
            "isDAG": self.isDAG,
            "schedule_mode": self.schedule_mode,
            "class_name": self.__class__.__name__,
            "layers_dict": self.layers_dict,
        }

    def get_structure_json(self) -> list[dict]:
        """
        获取任务图的 JSON 结构

        :return: JSON 格式的任务图结构列表
        """
        return self.structure_json

    def get_structure_list(self) -> list[str]:
        """
        获取任务图的格式化结构列表

        :return: 带边框的格式化字符串列表
        """
        return self.structure_list

    def get_networkx_graph(self) -> DiGraph:
        """
        获取任务图的 networkx 有向图（DiGraph）

        :return: networkx.DiGraph 实例
        """
        return self.networkx_graph

    def get_fallback_path(self) -> str:
        """
        获取失败任务的回退路径

        :return: 失败任务 JSONL 文件的绝对路径，未设置时返回空字符串
        """
        if self.fail_spout.jsonl_path is None:
            return ""
        return str(Path(self.fail_spout.jsonl_path).resolve())

    def get_stage_input_trace(self, stage_tag: str) -> str:
        """
        获取任务节点的输入依赖关系树

        :param stage_tag: 节点标签
        :return: 格式化的依赖关系树字符串
        """
        if not self._use_ctree:
            return ""

        input_ids: set = self.input_ids[stage_tag]
        descendants = self.ctree_client.descendants_batch(list(input_ids), "meta")
        return format_descendants_forest(descendants, STAGE_STYLE)

    def get_error_trace(self, error_id: int) -> str:
        """
        获取错误任务的依赖关系树

        :param error_id: 错误事件 ID
        :return: 格式化的溯源关系树字符串
        """
        provenance = self.ctree_client.provenance(error_id)
        return format_provenance_forest(provenance, STAGE_STYLE)
