from typing import Final, Optional

class BedrockModel(str):
    def cris(self, region: Optional[str] = None) -> str: ...
    def global_cris(self, region: Optional[str] = None) -> str: ...

class Models:

    AI21_JAMBA_1_5_LARGE: Final[BedrockModel]
    AI21_JAMBA_1_5_MINI: Final[BedrockModel]
    AMAZON_NOVA_2_LITE: Final[BedrockModel]
    AMAZON_NOVA_2_MULTIMODAL_EMBEDDINGS: Final[BedrockModel]
    AMAZON_NOVA_2_SONIC: Final[BedrockModel]
    AMAZON_NOVA_LITE: Final[BedrockModel]
    AMAZON_NOVA_MICRO: Final[BedrockModel]
    AMAZON_NOVA_PRO: Final[BedrockModel]
    AMAZON_RERANK: Final[BedrockModel]
    AMAZON_TITAN_EMBED_G1_TEXT_02: Final[BedrockModel]
    AMAZON_TITAN_EMBED_IMAGE: Final[BedrockModel]
    AMAZON_TITAN_EMBED_TEXT: Final[BedrockModel]
    AMAZON_TITAN_TG1_LARGE: Final[BedrockModel]
    ANTHROPIC_CLAUDE_HAIKU_4_5_20251001: Final[BedrockModel]
    ANTHROPIC_CLAUDE_OPUS_4_1_20250805: Final[BedrockModel]
    ANTHROPIC_CLAUDE_OPUS_4_5_20251101: Final[BedrockModel]
    ANTHROPIC_CLAUDE_OPUS_4_6: Final[BedrockModel]
    ANTHROPIC_CLAUDE_SONNET_4_20250514: Final[BedrockModel]
    ANTHROPIC_CLAUDE_SONNET_4_5_20250929: Final[BedrockModel]
    ANTHROPIC_CLAUDE_SONNET_4_6: Final[BedrockModel]
    COHERE_EMBED: Final[BedrockModel]
    COHERE_EMBED_ENGLISH: Final[BedrockModel]
    COHERE_EMBED_MULTILINGUAL: Final[BedrockModel]
    COHERE_RERANK: Final[BedrockModel]
    DEEPSEEK_R1: Final[BedrockModel]
    DEEPSEEK_V3: Final[BedrockModel]
    DEEPSEEK_V3_2: Final[BedrockModel]
    GOOGLE_GEMMA_3_12B_IT: Final[BedrockModel]
    GOOGLE_GEMMA_3_27B_IT: Final[BedrockModel]
    GOOGLE_GEMMA_3_4B_IT: Final[BedrockModel]
    LUMA_RAY: Final[BedrockModel]
    META_LLAMA3_1_70B_INSTRUCT: Final[BedrockModel]
    META_LLAMA3_1_8B_INSTRUCT: Final[BedrockModel]
    META_LLAMA3_3_70B_INSTRUCT: Final[BedrockModel]
    META_LLAMA3_70B_INSTRUCT: Final[BedrockModel]
    META_LLAMA3_8B_INSTRUCT: Final[BedrockModel]
    META_LLAMA4_MAVERICK_17B_INSTRUCT: Final[BedrockModel]
    META_LLAMA4_SCOUT_17B_INSTRUCT: Final[BedrockModel]
    MINIMAX_MINIMAX_M2: Final[BedrockModel]
    MINIMAX_MINIMAX_M2_1: Final[BedrockModel]
    MINIMAX_MINIMAX_M2_5: Final[BedrockModel]
    MISTRAL_DEVSTRAL_2_123B: Final[BedrockModel]
    MISTRAL_MAGISTRAL_SMALL_2509: Final[BedrockModel]
    MISTRAL_MINISTRAL_3_14B_INSTRUCT: Final[BedrockModel]
    MISTRAL_MINISTRAL_3_3B_INSTRUCT: Final[BedrockModel]
    MISTRAL_MINISTRAL_3_8B_INSTRUCT: Final[BedrockModel]
    MISTRAL_MISTRAL_7B_INSTRUCT: Final[BedrockModel]
    MISTRAL_MISTRAL_LARGE_2402: Final[BedrockModel]
    MISTRAL_MISTRAL_LARGE_2407: Final[BedrockModel]
    MISTRAL_MISTRAL_LARGE_3_675B_INSTRUCT: Final[BedrockModel]
    MISTRAL_MISTRAL_SMALL_2402: Final[BedrockModel]
    MISTRAL_MIXTRAL_8X7B_INSTRUCT: Final[BedrockModel]
    MISTRAL_PIXTRAL_LARGE_2502: Final[BedrockModel]
    MISTRAL_VOXTRAL_MINI_3B_2507: Final[BedrockModel]
    MISTRAL_VOXTRAL_SMALL_24B_2507: Final[BedrockModel]
    MOONSHOTAI_KIMI_K2_5: Final[BedrockModel]
    MOONSHOT_KIMI_K2_THINKING: Final[BedrockModel]
    NVIDIA_NEMOTRON_NANO_12B: Final[BedrockModel]
    NVIDIA_NEMOTRON_NANO_3_30B: Final[BedrockModel]
    NVIDIA_NEMOTRON_NANO_9B: Final[BedrockModel]
    NVIDIA_NEMOTRON_SUPER_3_120B: Final[BedrockModel]
    OPENAI_GPT_OSS_120B: Final[BedrockModel]
    OPENAI_GPT_OSS_20B: Final[BedrockModel]
    OPENAI_GPT_OSS_SAFEGUARD_120B: Final[BedrockModel]
    OPENAI_GPT_OSS_SAFEGUARD_20B: Final[BedrockModel]
    QWEN_QWEN3_235B_A22B_2507: Final[BedrockModel]
    QWEN_QWEN3_32B: Final[BedrockModel]
    QWEN_QWEN3_CODER_30B_A3B: Final[BedrockModel]
    QWEN_QWEN3_CODER_480B_A35B: Final[BedrockModel]
    QWEN_QWEN3_CODER_NEXT: Final[BedrockModel]
    QWEN_QWEN3_NEXT_80B_A3B: Final[BedrockModel]
    QWEN_QWEN3_VL_235B_A22B: Final[BedrockModel]
    STABILITY_SD3_5_LARGE: Final[BedrockModel]
    STABILITY_STABLE_CONSERVATIVE_UPSCALE: Final[BedrockModel]
    STABILITY_STABLE_CREATIVE_UPSCALE: Final[BedrockModel]
    STABILITY_STABLE_FAST_UPSCALE: Final[BedrockModel]
    STABILITY_STABLE_IMAGE_CONTROL_SKETCH: Final[BedrockModel]
    STABILITY_STABLE_IMAGE_CONTROL_STRUCTURE: Final[BedrockModel]
    STABILITY_STABLE_IMAGE_CORE: Final[BedrockModel]
    STABILITY_STABLE_IMAGE_ERASE_OBJECT: Final[BedrockModel]
    STABILITY_STABLE_IMAGE_INPAINT: Final[BedrockModel]
    STABILITY_STABLE_IMAGE_REMOVE_BACKGROUND: Final[BedrockModel]
    STABILITY_STABLE_IMAGE_SEARCH_RECOLOR: Final[BedrockModel]
    STABILITY_STABLE_IMAGE_SEARCH_REPLACE: Final[BedrockModel]
    STABILITY_STABLE_IMAGE_STYLE_GUIDE: Final[BedrockModel]
    STABILITY_STABLE_IMAGE_ULTRA: Final[BedrockModel]
    STABILITY_STABLE_OUTPAINT: Final[BedrockModel]
    STABILITY_STABLE_STYLE_TRANSFER: Final[BedrockModel]
    TWELVELABS_MARENGO_EMBED_2_7: Final[BedrockModel]
    TWELVELABS_MARENGO_EMBED_3_0: Final[BedrockModel]
    TWELVELABS_PEGASUS_1_2: Final[BedrockModel]
    WRITER_PALMYRA_VISION_7B: Final[BedrockModel]
    WRITER_PALMYRA_X4: Final[BedrockModel]
    WRITER_PALMYRA_X5: Final[BedrockModel]
    ZAI_GLM_4_7: Final[BedrockModel]
    ZAI_GLM_4_7_FLASH: Final[BedrockModel]
    ZAI_GLM_5: Final[BedrockModel]
    AMAZON_NOVA_CANVAS: Final[BedrockModel]  # deprecated: Model 'amazon.nova-canvas-v1:0' has LEGACY status
    AMAZON_NOVA_PREMIER: Final[BedrockModel]  # deprecated: Model 'amazon.nova-premier-v1:0' has LEGACY status
    AMAZON_NOVA_REEL: Final[BedrockModel]  # deprecated: Model 'amazon.nova-reel-v1:1' has LEGACY status
    AMAZON_NOVA_SONIC: Final[BedrockModel]  # deprecated: Model 'amazon.nova-sonic-v1:0' has LEGACY status
    AMAZON_TITAN_IMAGE_GENERATOR: Final[BedrockModel]  # deprecated: Model 'amazon.titan-image-generator-v2:0' has LEGACY status
    ANTHROPIC_CLAUDE_3_5_HAIKU_20241022: Final[BedrockModel]  # deprecated: Model 'anthropic.claude-3-5-haiku-20241022-v1:0' has LEGACY status
    ANTHROPIC_CLAUDE_3_5_SONNET_20240620: Final[BedrockModel]  # deprecated: Model 'anthropic.claude-3-5-sonnet-20240620-v1:0' has LEGACY status
    ANTHROPIC_CLAUDE_3_5_SONNET_20241022: Final[BedrockModel]  # deprecated: Model 'anthropic.claude-3-5-sonnet-20241022-v2:0' has LEGACY status
    ANTHROPIC_CLAUDE_3_7_SONNET_20250219: Final[BedrockModel]  # deprecated: Model 'anthropic.claude-3-7-sonnet-20250219-v1:0' has LEGACY status
    ANTHROPIC_CLAUDE_3_HAIKU_20240307: Final[BedrockModel]  # deprecated: Model 'anthropic.claude-3-haiku-20240307-v1:0' has LEGACY status
    ANTHROPIC_CLAUDE_3_SONNET_20240229: Final[BedrockModel]  # deprecated: Model 'anthropic.claude-3-sonnet-20240229-v1:0' has LEGACY status
    ANTHROPIC_CLAUDE_OPUS_4_20250514: Final[BedrockModel]  # deprecated: Model 'anthropic.claude-opus-4-20250514-v1:0' has LEGACY status
    COHERE_COMMAND_R: Final[BedrockModel]  # deprecated: Model 'cohere.command-r-v1:0' has LEGACY status
    COHERE_COMMAND_R_PLUS: Final[BedrockModel]  # deprecated: Model 'cohere.command-r-plus-v1:0' has LEGACY status
    META_LLAMA3_1_405B_INSTRUCT: Final[BedrockModel]  # deprecated: Model 'meta.llama3-1-405b-instruct-v1:0' has LEGACY status
    META_LLAMA3_2_11B_INSTRUCT: Final[BedrockModel]  # deprecated: Model 'meta.llama3-2-11b-instruct-v1:0' has LEGACY status
    META_LLAMA3_2_1B_INSTRUCT: Final[BedrockModel]  # deprecated: Model 'meta.llama3-2-1b-instruct-v1:0' has LEGACY status
    META_LLAMA3_2_3B_INSTRUCT: Final[BedrockModel]  # deprecated: Model 'meta.llama3-2-3b-instruct-v1:0' has LEGACY status
    META_LLAMA3_2_90B_INSTRUCT: Final[BedrockModel]  # deprecated: Model 'meta.llama3-2-90b-instruct-v1:0' has LEGACY status
