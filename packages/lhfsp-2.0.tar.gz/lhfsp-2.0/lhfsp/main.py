import random
import string # Added this import

def manualhash(text, y, z):
    hashtextlist = []
    for char in text:
        x = ord(char)
        # Standard hashing logic
        r = (x**y) % z
        hashchar = chr(r)
        hashtextlist.append(hashchar)
    hashtext = "".join(hashtextlist)
    return hashtext

def classichash(text):
    # Added 'return' here
    return manualhash(text, 2013, 2908)

def keyhash(text, key1, key2):
    if not (len(key1) == 4 and key1.isalpha()):
        raise ValueError(f'{key1}: key should be 4 letters long and alphabetic!')
    if not (len(key2) == 4 and key2.isalpha()):
        raise ValueError(f'{key2}: key should be 4 letters long and alphabetic!')
    
    # Fixed assignment: y = 0; z = 0
    y, z = 0, 0 
    
    for char in key1:
        y += ord(char)
    for char in key2:
        z += ord(char)
        
    # Added 'return' here
    return manualhash(text, y, z)
    
def rkeyhash(text):
    rkey1 = ''.join(random.choices(string.ascii_letters, k=4))
    rkey2 = ''.join(random.choices(string.ascii_letters, k=4))
    print(f'key 1: {rkey1}\nkey 2: {rkey2}')
    return keyhash(text, rkey1, rkey2)