print('! WARNING !\nDont use LHFSP (Light Hash For Small Projects) to do big projects, cause you can face security problems. LHFSP is made for small projects not meant to be hacked as a light hashing method. thanks!')

from .main import manualhash, classichash, keyhash, rkeyhash