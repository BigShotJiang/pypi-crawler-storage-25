"""
certmesh.api.log_store
=======================

S3-backed structured log storage for the dashboard.

Captures application log records as JSON lines and persists them to S3
with configurable retention.  Logs are partitioned by date for efficient
range queries and automatic lifecycle expiry.

S3 key layout::

    {prefix}/logs/{YYYY}/{MM}/{DD}/{HH}-{uuid4}.jsonl

Configuration (environment variables):

- ``CM_LOG_S3_ENABLED``     -- enable S3 log persistence (default ``false``)
- ``CM_LOG_S3_BUCKET``      -- S3 bucket for logs (falls back to ``CM_DASHBOARD_S3_BUCKET``)
- ``CM_LOG_S3_PREFIX``      -- key prefix (default ``certmesh/``)
- ``CM_LOG_RETENTION_DAYS`` -- auto-delete logs older than N days (default ``30``; ``0`` = indefinite)
- ``CM_LOG_FORMAT``         -- storage format, currently ``json`` only
- ``CM_LOG_BUFFER_SIZE``    -- records to buffer before flushing (default ``50``)
- ``CM_LOG_FLUSH_INTERVAL`` -- seconds between forced flushes (default ``30``)
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class LogStoreConfig:
    """Configuration for the S3 log store."""

    enabled: bool = False
    bucket: str = ""
    prefix: str = "certmesh/"
    region: str = ""
    retention_days: int = 30  # 0 = indefinite
    log_format: str = "json"
    buffer_size: int = 50
    flush_interval: float = 30.0


def _safe_float(val: str | None, default: float) -> float:
    """Convert *val* to float, returning *default* on failure."""
    if val is None:
        return default
    try:
        return float(val)
    except (ValueError, TypeError):
        return default


def build_log_store_config() -> LogStoreConfig:
    """Build log store config from environment variables."""
    from certmesh.settings import safe_bool, safe_int

    return LogStoreConfig(
        enabled=safe_bool(os.environ.get("CM_LOG_S3_ENABLED"), default=False),
        bucket=os.environ.get("CM_LOG_S3_BUCKET", os.environ.get("CM_DASHBOARD_S3_BUCKET", "")),
        prefix=os.environ.get("CM_LOG_S3_PREFIX", "certmesh/"),
        region=os.environ.get("CM_LOG_S3_REGION", os.environ.get("CM_DASHBOARD_S3_REGION", "")),
        retention_days=safe_int(os.environ.get("CM_LOG_RETENTION_DAYS"), 30),
        log_format=os.environ.get("CM_LOG_STORAGE_FORMAT", "json"),
        buffer_size=safe_int(os.environ.get("CM_LOG_BUFFER_SIZE"), 50),
        flush_interval=_safe_float(os.environ.get("CM_LOG_FLUSH_INTERVAL"), 30.0),
    )


@dataclass
class LogRecord:
    """A single structured log entry."""

    timestamp: str
    level: str
    logger_name: str = ""
    message: str = ""
    extra: dict[str, Any] = field(default_factory=dict)

    _CORE_FIELDS = frozenset({"timestamp", "level", "logger", "message"})

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {k: v for k, v in self.extra.items() if k not in self._CORE_FIELDS}
        d["timestamp"] = self.timestamp
        d["level"] = self.level
        d["logger"] = self.logger_name
        d["message"] = self.message
        return d


class LogCapture(logging.Handler):
    """Logging handler that captures records and sends them to a LogStore.

    Attach this handler to the root logger to pipe all application logs
    into the dashboard log viewer.
    """

    def __init__(self, store: LogStore) -> None:
        super().__init__()
        self._store = store

    def emit(self, record: logging.LogRecord) -> None:
        try:
            ts = datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat()
            extra: dict[str, Any] = {}
            # Capture structured extra fields added via logger.info(..., extra={...})
            for key in ("provider", "cert_id", "subject", "error", "key", "bucket", "path"):
                val = getattr(record, key, None)
                if val is not None:
                    extra[key] = str(val)
            if record.exc_text:
                extra["exception"] = record.exc_text

            log_record = LogRecord(
                timestamp=ts,
                level=record.levelname,
                logger_name=record.name,
                message=self.format(record) if not record.getMessage() else record.getMessage(),
                extra=extra,
            )
            self._store.add(log_record)
        except Exception:  # noqa: BLE001 - logging handler must never raise
            pass


class LogStore:
    """S3-backed log store with in-memory buffer and search.

    Buffers log records in memory and periodically flushes to S3 as
    JSONL files.  Provides search/query over both buffered and S3-stored
    logs.

    Thread-safe: all operations are protected by a lock.
    """

    def __init__(self, config: LogStoreConfig) -> None:
        self._config = config
        self._lock = threading.Lock()
        self._buffer: list[dict[str, Any]] = []
        self._recent: list[dict[str, Any]] = []  # rolling window for fast queries
        self._max_recent = 2000
        self._s3_client: Any | None = None
        self._s3_available = False
        self._last_flush: float = time.monotonic()
        self._flush_timer: threading.Timer | None = None

        if config.enabled and config.bucket:
            try:
                import boto3
                from botocore.config import Config as BotoConfig

                kwargs: dict[str, Any] = {
                    "config": BotoConfig(
                        connect_timeout=5,
                        read_timeout=10,
                        retries={"max_attempts": 2},
                    ),
                }
                if config.region:
                    kwargs["region_name"] = config.region
                self._s3_client = boto3.client("s3", **kwargs)
                self._s3_client.head_bucket(Bucket=config.bucket)
                self._s3_available = True
                logger.info(
                    "Log store S3 connected",
                    extra={"bucket": config.bucket, "prefix": config.prefix},
                )
            except Exception:  # noqa: BLE001 - graceful degradation
                logger.warning(
                    "Log store S3 unavailable, logs retained in-memory only",
                    extra={"bucket": config.bucket},
                )
                self._s3_available = False

        if config.enabled:
            self._schedule_flush()

    def _schedule_flush(self) -> None:
        """Schedule the next periodic flush."""
        self._flush_timer = threading.Timer(self._config.flush_interval, self._periodic_flush)
        self._flush_timer.daemon = True
        self._flush_timer.start()

    def _periodic_flush(self) -> None:
        """Flush buffered logs to S3 on a timer."""
        try:
            self.flush()
        finally:
            if self._config.enabled:
                self._schedule_flush()

    def add(self, record: LogRecord) -> None:
        """Add a log record to the buffer."""
        entry = record.to_dict()
        with self._lock:
            self._buffer.append(entry)
            self._recent.append(entry)
            if len(self._recent) > self._max_recent:
                self._recent = self._recent[-self._max_recent :]

            if len(self._buffer) >= self._config.buffer_size:
                self._flush_locked()

    def flush(self) -> None:
        """Flush buffered logs to S3."""
        with self._lock:
            self._flush_locked()

    def _flush_locked(self) -> None:
        """Flush buffer to S3.  Must be called with ``self._lock`` held."""
        if not self._buffer:
            return

        if not self._s3_available or self._s3_client is None:
            # Discard old buffer entries beyond retention window
            self._buffer.clear()
            self._last_flush = time.monotonic()
            return

        now = datetime.now(tz=timezone.utc)
        key = (
            f"{self._config.prefix.rstrip('/')}/logs/"
            f"{now.strftime('%Y/%m/%d')}/"
            f"{now.strftime('%H')}-{uuid.uuid4().hex[:12]}.jsonl"
        )
        body = "\n".join(json.dumps(entry, default=str) for entry in self._buffer) + "\n"

        try:
            self._s3_client.put_object(
                Bucket=self._config.bucket,
                Key=key,
                Body=body.encode("utf-8"),
                ContentType="application/x-ndjson",
                ServerSideEncryption="AES256",
            )
            self._buffer.clear()
            self._last_flush = time.monotonic()
        except Exception:  # noqa: BLE001 - best-effort persistence
            logger.debug("Log store S3 flush failed, retaining buffer")

    def query(
        self,
        *,
        search: str = "",
        level: str = "",
        logger_name: str = "",
        provider: str = "",
        start_time: str = "",
        end_time: str = "",
        limit: int = 200,
        offset: int = 0,
    ) -> dict[str, Any]:
        """Query log records from the in-memory recent window.

        For S3-stored logs, use ``query_s3`` for historical queries.

        Returns:
            Dict with ``logs``, ``total``, ``limit``, ``offset``.
        """
        with self._lock:
            results = list(reversed(self._recent))  # newest first

        # Apply filters
        if search:
            search_lower = search.lower()
            results = [
                r
                for r in results
                if search_lower in r.get("message", "").lower()
                or search_lower in r.get("logger", "").lower()
                or search_lower in json.dumps(r.get("extra", {}), default=str).lower()
            ]

        if level:
            level_upper = level.upper()
            results = [r for r in results if r.get("level", "").upper() == level_upper]

        if logger_name:
            results = [r for r in results if logger_name in r.get("logger", "")]

        if provider:
            provider_lower = provider.lower()
            results = [r for r in results if r.get("provider", "").lower() == provider_lower]

        if start_time:
            results = [r for r in results if r.get("timestamp", "") >= start_time]

        if end_time:
            results = [r for r in results if r.get("timestamp", "") <= end_time]

        total = len(results)
        page = results[offset : offset + limit]

        return {
            "logs": page,
            "total": total,
            "limit": limit,
            "offset": offset,
        }

    def _parse_s3_log_object(
        self,
        key: str,
        *,
        search: str,
        level: str,
        results: list[dict[str, Any]],
        limit: int,
    ) -> None:
        """Download and parse a single S3 log object, appending matches to *results*."""
        try:
            resp = self._s3_client.get_object(Bucket=self._config.bucket, Key=key)
            content = resp["Body"].read().decode("utf-8")
            for line in content.strip().split("\n"):
                if not line or len(results) >= limit:
                    return
                try:
                    entry = json.loads(line)
                except (json.JSONDecodeError, ValueError):
                    logger.debug(
                        "Skipping malformed log entry in S3 object",
                        extra={"key": key},
                    )
                    continue
                if level and entry.get("level", "").upper() != level.upper():
                    continue
                if search and search.lower() not in json.dumps(entry, default=str).lower():
                    continue
                results.append(entry)
        except Exception:  # noqa: BLE001
            logger.debug("Failed to parse S3 log object", extra={"key": key}, exc_info=True)

    def query_s3(
        self,
        *,
        date: str = "",
        search: str = "",
        level: str = "",
        limit: int = 500,
    ) -> dict[str, Any]:
        """Query historical logs from S3 for a specific date.

        Args:
            date: Date string ``YYYY-MM-DD`` to query.
            search: Text search filter.
            level: Log level filter.
            limit: Maximum records to return.

        Returns:
            Dict with ``logs``, ``total``, ``date``.
        """
        if not self._s3_available or not self._s3_client or not date:
            return {"logs": [], "total": 0, "date": date}

        try:
            parts = date.split("-")
            prefix = f"{self._config.prefix.rstrip('/')}/logs/{parts[0]}/{parts[1]}/{parts[2]}/"
        except (IndexError, ValueError):
            return {"logs": [], "total": 0, "date": date}

        results: list[dict[str, Any]] = []
        try:
            paginator = self._s3_client.get_paginator("list_objects_v2")
            for page in paginator.paginate(Bucket=self._config.bucket, Prefix=prefix):
                for obj in page.get("Contents", []):
                    if len(results) >= limit:
                        break
                    self._parse_s3_log_object(
                        obj["Key"],
                        search=search,
                        level=level,
                        results=results,
                        limit=limit,
                    )
        except Exception:  # noqa: BLE001
            logger.warning("Log store S3 query failed", extra={"date": date})

        return {"logs": results, "total": len(results), "date": date}

    def get_stats(self) -> dict[str, Any]:
        """Return log store statistics."""
        with self._lock:
            return {
                "buffered": len(self._buffer),
                "recent_count": len(self._recent),
                "s3_available": self._s3_available,
                "retention_days": self._config.retention_days,
                "format": self._config.log_format,
            }

    def shutdown(self) -> None:
        """Flush remaining logs and stop timers."""
        if self._flush_timer:
            self._flush_timer.cancel()
        self.flush()

    @property
    def is_s3_available(self) -> bool:
        return self._s3_available
