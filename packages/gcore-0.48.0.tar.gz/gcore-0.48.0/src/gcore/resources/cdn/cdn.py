# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Any, cast

import httpx

from .ips import (
    IPsResource,
    AsyncIPsResource,
    IPsResourceWithRawResponse,
    AsyncIPsResourceWithRawResponse,
    IPsResourceWithStreamingResponse,
    AsyncIPsResourceWithStreamingResponse,
)
from .logs import (
    LogsResource,
    AsyncLogsResource,
    LogsResourceWithRawResponse,
    AsyncLogsResourceWithRawResponse,
    LogsResourceWithStreamingResponse,
    AsyncLogsResourceWithStreamingResponse,
)
from .metrics import (
    MetricsResource,
    AsyncMetricsResource,
    MetricsResourceWithRawResponse,
    AsyncMetricsResourceWithRawResponse,
    MetricsResourceWithStreamingResponse,
    AsyncMetricsResourceWithStreamingResponse,
)
from .shields import (
    ShieldsResource,
    AsyncShieldsResource,
    ShieldsResourceWithRawResponse,
    AsyncShieldsResourceWithRawResponse,
    ShieldsResourceWithStreamingResponse,
    AsyncShieldsResourceWithStreamingResponse,
)
from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from .ip_ranges import (
    IPRangesResource,
    AsyncIPRangesResource,
    IPRangesResourceWithRawResponse,
    AsyncIPRangesResourceWithRawResponse,
    IPRangesResourceWithStreamingResponse,
    AsyncIPRangesResourceWithStreamingResponse,
)
from .audit_logs import (
    AuditLogsResource,
    AsyncAuditLogsResource,
    AuditLogsResourceWithRawResponse,
    AsyncAuditLogsResourceWithRawResponse,
    AuditLogsResourceWithStreamingResponse,
    AsyncAuditLogsResourceWithStreamingResponse,
)
from .statistics import (
    StatisticsResource,
    AsyncStatisticsResource,
    StatisticsResourceWithRawResponse,
    AsyncStatisticsResourceWithRawResponse,
    StatisticsResourceWithStreamingResponse,
    AsyncStatisticsResourceWithStreamingResponse,
)
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...types.cdn import (
    cdn_update_account_params,
    cdn_list_aws_regions_params,
    cdn_list_purge_statuses_params,
    cdn_list_alibaba_regions_params,
)
from .certificates import (
    CertificatesResource,
    AsyncCertificatesResource,
    CertificatesResourceWithRawResponse,
    AsyncCertificatesResourceWithRawResponse,
    CertificatesResourceWithStreamingResponse,
    AsyncCertificatesResourceWithStreamingResponse,
)
from .client_config import (
    ClientConfigResource,
    AsyncClientConfigResource,
    ClientConfigResourceWithRawResponse,
    AsyncClientConfigResourceWithRawResponse,
    ClientConfigResourceWithStreamingResponse,
    AsyncClientConfigResourceWithStreamingResponse,
)
from .origin_groups import (
    OriginGroupsResource,
    AsyncOriginGroupsResource,
    OriginGroupsResourceWithRawResponse,
    AsyncOriginGroupsResourceWithRawResponse,
    OriginGroupsResourceWithStreamingResponse,
    AsyncOriginGroupsResourceWithStreamingResponse,
)
from ..._base_client import make_request_options
from .rule_templates import (
    RuleTemplatesResource,
    AsyncRuleTemplatesResource,
    RuleTemplatesResourceWithRawResponse,
    AsyncRuleTemplatesResourceWithRawResponse,
    RuleTemplatesResourceWithStreamingResponse,
    AsyncRuleTemplatesResourceWithStreamingResponse,
)
from .network_capacity import (
    NetworkCapacityResource,
    AsyncNetworkCapacityResource,
    NetworkCapacityResourceWithRawResponse,
    AsyncNetworkCapacityResourceWithRawResponse,
    NetworkCapacityResourceWithStreamingResponse,
    AsyncNetworkCapacityResourceWithStreamingResponse,
)
from ...types.cdn.aws_regions import AwsRegions
from ...types.cdn.cdn_account import CDNAccount
from .trusted_ca_certificates import (
    TrustedCaCertificatesResource,
    AsyncTrustedCaCertificatesResource,
    TrustedCaCertificatesResourceWithRawResponse,
    AsyncTrustedCaCertificatesResourceWithRawResponse,
    TrustedCaCertificatesResourceWithStreamingResponse,
    AsyncTrustedCaCertificatesResourceWithStreamingResponse,
)
from ...types.cdn.alibaba_regions import AlibabaRegions
from .cdn_resources.cdn_resources import (
    CDNResourcesResource,
    AsyncCDNResourcesResource,
    CDNResourcesResourceWithRawResponse,
    AsyncCDNResourcesResourceWithRawResponse,
    CDNResourcesResourceWithStreamingResponse,
    AsyncCDNResourcesResourceWithStreamingResponse,
)
from .logs_uploader.logs_uploader import (
    LogsUploaderResource,
    AsyncLogsUploaderResource,
    LogsUploaderResourceWithRawResponse,
    AsyncLogsUploaderResourceWithRawResponse,
    LogsUploaderResourceWithStreamingResponse,
    AsyncLogsUploaderResourceWithStreamingResponse,
)
from ...types.cdn.cdn_account_limits import CDNAccountLimits
from ...types.cdn.cdn_available_features import CDNAvailableFeatures
from ...types.cdn.cdn_list_purge_statuses_response import CDNListPurgeStatusesResponse

__all__ = ["CDNResource", "AsyncCDNResource"]


class CDNResource(SyncAPIResource):
    @cached_property
    def cdn_resources(self) -> CDNResourcesResource:
        return CDNResourcesResource(self._client)

    @cached_property
    def shields(self) -> ShieldsResource:
        return ShieldsResource(self._client)

    @cached_property
    def origin_groups(self) -> OriginGroupsResource:
        """
        CDN origin groups aggregate one or more origin servers with failover and load balancing for content delivery.
        """
        return OriginGroupsResource(self._client)

    @cached_property
    def rule_templates(self) -> RuleTemplatesResource:
        """
        CDN rule templates define reusable rule configurations that can be applied across multiple CDN resources for consistent caching, delivery, and security policies.
        """
        return RuleTemplatesResource(self._client)

    @cached_property
    def certificates(self) -> CertificatesResource:
        """
        CDN SSL certificates enable HTTPS content delivery, supporting both uploaded certificates and automated Let's Encrypt provisioning.
        """
        return CertificatesResource(self._client)

    @cached_property
    def trusted_ca_certificates(self) -> TrustedCaCertificatesResource:
        """
        Trusted CA certificates verify the authenticity of CDN origin servers during HTTPS connections.
        """
        return TrustedCaCertificatesResource(self._client)

    @cached_property
    def audit_logs(self) -> AuditLogsResource:
        """
        Get the history of users requests to CDN.
        It contains requests made both via the API and via the control panel.

        The following methods are not tracked in the activity logs:
        - HEAD
        - OPTIONS
        """
        return AuditLogsResource(self._client)

    @cached_property
    def logs(self) -> LogsResource:
        """Log viewer provides you with general information about CDN operation.

        This information does not contain all possible
        sets of fields and restricted by time. To receive full data, use Logs Uploader.
        """
        return LogsResource(self._client)

    @cached_property
    def logs_uploader(self) -> LogsUploaderResource:
        return LogsUploaderResource(self._client)

    @cached_property
    def statistics(self) -> StatisticsResource:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return StatisticsResource(self._client)

    @cached_property
    def network_capacity(self) -> NetworkCapacityResource:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return NetworkCapacityResource(self._client)

    @cached_property
    def metrics(self) -> MetricsResource:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return MetricsResource(self._client)

    @cached_property
    def ip_ranges(self) -> IPRangesResource:
        return IPRangesResource(self._client)

    @cached_property
    def ips(self) -> IPsResource:
        return IPsResource(self._client)

    @cached_property
    def client_config(self) -> ClientConfigResource:
        """Information about the current state of the CDN service in your account."""
        return ClientConfigResource(self._client)

    @cached_property
    def with_raw_response(self) -> CDNResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/G-Core/gcore-python#accessing-raw-response-data-eg-headers
        """
        return CDNResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CDNResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/G-Core/gcore-python#with_streaming_response
        """
        return CDNResourceWithStreamingResponse(self)

    def get_account_limits(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CDNAccountLimits:
        """Get information about CDN service limits."""
        return self._get(
            "/cdn/clients/me/limits",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CDNAccountLimits,
        )

    def get_account_overview(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CDNAccount:
        """Get information about CDN service."""
        return self._get(
            "/cdn/clients/me",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CDNAccount,
        )

    def get_available_features(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CDNAvailableFeatures:
        """Get information about available CDN features."""
        return self._get(
            "/cdn/clients/me/features",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CDNAvailableFeatures,
        )

    def list_alibaba_regions(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AlibabaRegions:
        """
        Get the list of Alibaba Cloud regions.

        Args:
          limit: Maximum number of items to return in the response. Cannot exceed 1000.

          offset: Number of items to skip from the beginning of the list.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return cast(
            AlibabaRegions,
            self._get(
                "/cdn/alibaba_regions",
                options=make_request_options(
                    extra_headers=extra_headers,
                    extra_query=extra_query,
                    extra_body=extra_body,
                    timeout=timeout,
                    query=maybe_transform(
                        {
                            "limit": limit,
                            "offset": offset,
                        },
                        cdn_list_alibaba_regions_params.CDNListAlibabaRegionsParams,
                    ),
                ),
                cast_to=cast(Any, AlibabaRegions),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    def list_aws_regions(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AwsRegions:
        """
        Get the list of Amazon AWS regions.

        Args:
          limit: Maximum number of items to return in the response. Cannot exceed 1000.

          offset: Number of items to skip from the beginning of the list.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return cast(
            AwsRegions,
            self._get(
                "/cdn/aws_regions",
                options=make_request_options(
                    extra_headers=extra_headers,
                    extra_query=extra_query,
                    extra_body=extra_body,
                    timeout=timeout,
                    query=maybe_transform(
                        {
                            "limit": limit,
                            "offset": offset,
                        },
                        cdn_list_aws_regions_params.CDNListAwsRegionsParams,
                    ),
                ),
                cast_to=cast(Any, AwsRegions),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    def list_purge_statuses(
        self,
        *,
        cname: str | Omit = omit,
        from_created: str | Omit = omit,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        purge_type: str | Omit = omit,
        status: str | Omit = omit,
        to_created: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CDNListPurgeStatusesResponse:
        """
        Get purges history.

        Args:
          cname: Purges associated with a specific resource CNAME.

              Example:

              - &cname=example.com

          from_created: Start date and time of the requested time period (ISO 8601/RFC 3339 format,
              UTC.)

              Examples:

              - &`from_created`=2021-06-14T00:00:00Z
              - &`from_created`=2021-06-14T00:00:00.000Z

          limit: Maximum number of purges in the response.

          offset: Number of purge requests in the response to skip starting from the beginning of
              the requested period.

          purge_type: Purge requests with a certain purge type.

              Possible values:

              - **`purge_by_pattern`** - Purge by Pattern.
              - **`purge_by_url`** - Purge by URL.
              - **`purge_all`** - Purge All.

          status: Purge with a certain status.

              Possible values:

              - **In progress**
              - **Successful**
              - **Failed**
              - **Status report disabled**

          to_created: End date and time of the requested time period (ISO 8601/RFC 3339 format, UTC.)

              Examples:

              - &`to_created`=2021-06-15T00:00:00Z
              - &`to_created`=2021-06-15T00:00:00.000Z

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return cast(
            CDNListPurgeStatusesResponse,
            self._get(
                "/cdn/purge_statuses",
                options=make_request_options(
                    extra_headers=extra_headers,
                    extra_query=extra_query,
                    extra_body=extra_body,
                    timeout=timeout,
                    query=maybe_transform(
                        {
                            "cname": cname,
                            "from_created": from_created,
                            "limit": limit,
                            "offset": offset,
                            "purge_type": purge_type,
                            "status": status,
                            "to_created": to_created,
                        },
                        cdn_list_purge_statuses_params.CDNListPurgeStatusesParams,
                    ),
                ),
                cast_to=cast(
                    Any, CDNListPurgeStatusesResponse
                ),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    def update_account(
        self,
        *,
        utilization_level: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CDNAccount:
        """
        Change information about CDN service.

        Args:
          utilization_level: CDN traffic usage limit in gigabytes.

              When the limit is reached, we will send an email notification.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._patch(
            "/cdn/clients/me",
            body=maybe_transform(
                {"utilization_level": utilization_level}, cdn_update_account_params.CDNUpdateAccountParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CDNAccount,
        )


class AsyncCDNResource(AsyncAPIResource):
    @cached_property
    def cdn_resources(self) -> AsyncCDNResourcesResource:
        return AsyncCDNResourcesResource(self._client)

    @cached_property
    def shields(self) -> AsyncShieldsResource:
        return AsyncShieldsResource(self._client)

    @cached_property
    def origin_groups(self) -> AsyncOriginGroupsResource:
        """
        CDN origin groups aggregate one or more origin servers with failover and load balancing for content delivery.
        """
        return AsyncOriginGroupsResource(self._client)

    @cached_property
    def rule_templates(self) -> AsyncRuleTemplatesResource:
        """
        CDN rule templates define reusable rule configurations that can be applied across multiple CDN resources for consistent caching, delivery, and security policies.
        """
        return AsyncRuleTemplatesResource(self._client)

    @cached_property
    def certificates(self) -> AsyncCertificatesResource:
        """
        CDN SSL certificates enable HTTPS content delivery, supporting both uploaded certificates and automated Let's Encrypt provisioning.
        """
        return AsyncCertificatesResource(self._client)

    @cached_property
    def trusted_ca_certificates(self) -> AsyncTrustedCaCertificatesResource:
        """
        Trusted CA certificates verify the authenticity of CDN origin servers during HTTPS connections.
        """
        return AsyncTrustedCaCertificatesResource(self._client)

    @cached_property
    def audit_logs(self) -> AsyncAuditLogsResource:
        """
        Get the history of users requests to CDN.
        It contains requests made both via the API and via the control panel.

        The following methods are not tracked in the activity logs:
        - HEAD
        - OPTIONS
        """
        return AsyncAuditLogsResource(self._client)

    @cached_property
    def logs(self) -> AsyncLogsResource:
        """Log viewer provides you with general information about CDN operation.

        This information does not contain all possible
        sets of fields and restricted by time. To receive full data, use Logs Uploader.
        """
        return AsyncLogsResource(self._client)

    @cached_property
    def logs_uploader(self) -> AsyncLogsUploaderResource:
        return AsyncLogsUploaderResource(self._client)

    @cached_property
    def statistics(self) -> AsyncStatisticsResource:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return AsyncStatisticsResource(self._client)

    @cached_property
    def network_capacity(self) -> AsyncNetworkCapacityResource:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return AsyncNetworkCapacityResource(self._client)

    @cached_property
    def metrics(self) -> AsyncMetricsResource:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return AsyncMetricsResource(self._client)

    @cached_property
    def ip_ranges(self) -> AsyncIPRangesResource:
        return AsyncIPRangesResource(self._client)

    @cached_property
    def ips(self) -> AsyncIPsResource:
        return AsyncIPsResource(self._client)

    @cached_property
    def client_config(self) -> AsyncClientConfigResource:
        """Information about the current state of the CDN service in your account."""
        return AsyncClientConfigResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncCDNResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/G-Core/gcore-python#accessing-raw-response-data-eg-headers
        """
        return AsyncCDNResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCDNResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/G-Core/gcore-python#with_streaming_response
        """
        return AsyncCDNResourceWithStreamingResponse(self)

    async def get_account_limits(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CDNAccountLimits:
        """Get information about CDN service limits."""
        return await self._get(
            "/cdn/clients/me/limits",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CDNAccountLimits,
        )

    async def get_account_overview(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CDNAccount:
        """Get information about CDN service."""
        return await self._get(
            "/cdn/clients/me",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CDNAccount,
        )

    async def get_available_features(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CDNAvailableFeatures:
        """Get information about available CDN features."""
        return await self._get(
            "/cdn/clients/me/features",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CDNAvailableFeatures,
        )

    async def list_alibaba_regions(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AlibabaRegions:
        """
        Get the list of Alibaba Cloud regions.

        Args:
          limit: Maximum number of items to return in the response. Cannot exceed 1000.

          offset: Number of items to skip from the beginning of the list.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return cast(
            AlibabaRegions,
            await self._get(
                "/cdn/alibaba_regions",
                options=make_request_options(
                    extra_headers=extra_headers,
                    extra_query=extra_query,
                    extra_body=extra_body,
                    timeout=timeout,
                    query=await async_maybe_transform(
                        {
                            "limit": limit,
                            "offset": offset,
                        },
                        cdn_list_alibaba_regions_params.CDNListAlibabaRegionsParams,
                    ),
                ),
                cast_to=cast(Any, AlibabaRegions),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    async def list_aws_regions(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AwsRegions:
        """
        Get the list of Amazon AWS regions.

        Args:
          limit: Maximum number of items to return in the response. Cannot exceed 1000.

          offset: Number of items to skip from the beginning of the list.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return cast(
            AwsRegions,
            await self._get(
                "/cdn/aws_regions",
                options=make_request_options(
                    extra_headers=extra_headers,
                    extra_query=extra_query,
                    extra_body=extra_body,
                    timeout=timeout,
                    query=await async_maybe_transform(
                        {
                            "limit": limit,
                            "offset": offset,
                        },
                        cdn_list_aws_regions_params.CDNListAwsRegionsParams,
                    ),
                ),
                cast_to=cast(Any, AwsRegions),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    async def list_purge_statuses(
        self,
        *,
        cname: str | Omit = omit,
        from_created: str | Omit = omit,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        purge_type: str | Omit = omit,
        status: str | Omit = omit,
        to_created: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CDNListPurgeStatusesResponse:
        """
        Get purges history.

        Args:
          cname: Purges associated with a specific resource CNAME.

              Example:

              - &cname=example.com

          from_created: Start date and time of the requested time period (ISO 8601/RFC 3339 format,
              UTC.)

              Examples:

              - &`from_created`=2021-06-14T00:00:00Z
              - &`from_created`=2021-06-14T00:00:00.000Z

          limit: Maximum number of purges in the response.

          offset: Number of purge requests in the response to skip starting from the beginning of
              the requested period.

          purge_type: Purge requests with a certain purge type.

              Possible values:

              - **`purge_by_pattern`** - Purge by Pattern.
              - **`purge_by_url`** - Purge by URL.
              - **`purge_all`** - Purge All.

          status: Purge with a certain status.

              Possible values:

              - **In progress**
              - **Successful**
              - **Failed**
              - **Status report disabled**

          to_created: End date and time of the requested time period (ISO 8601/RFC 3339 format, UTC.)

              Examples:

              - &`to_created`=2021-06-15T00:00:00Z
              - &`to_created`=2021-06-15T00:00:00.000Z

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return cast(
            CDNListPurgeStatusesResponse,
            await self._get(
                "/cdn/purge_statuses",
                options=make_request_options(
                    extra_headers=extra_headers,
                    extra_query=extra_query,
                    extra_body=extra_body,
                    timeout=timeout,
                    query=await async_maybe_transform(
                        {
                            "cname": cname,
                            "from_created": from_created,
                            "limit": limit,
                            "offset": offset,
                            "purge_type": purge_type,
                            "status": status,
                            "to_created": to_created,
                        },
                        cdn_list_purge_statuses_params.CDNListPurgeStatusesParams,
                    ),
                ),
                cast_to=cast(
                    Any, CDNListPurgeStatusesResponse
                ),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    async def update_account(
        self,
        *,
        utilization_level: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CDNAccount:
        """
        Change information about CDN service.

        Args:
          utilization_level: CDN traffic usage limit in gigabytes.

              When the limit is reached, we will send an email notification.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._patch(
            "/cdn/clients/me",
            body=await async_maybe_transform(
                {"utilization_level": utilization_level}, cdn_update_account_params.CDNUpdateAccountParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CDNAccount,
        )


class CDNResourceWithRawResponse:
    def __init__(self, cdn: CDNResource) -> None:
        self._cdn = cdn

        self.get_account_limits = to_raw_response_wrapper(
            cdn.get_account_limits,
        )
        self.get_account_overview = to_raw_response_wrapper(
            cdn.get_account_overview,
        )
        self.get_available_features = to_raw_response_wrapper(
            cdn.get_available_features,
        )
        self.list_alibaba_regions = to_raw_response_wrapper(
            cdn.list_alibaba_regions,
        )
        self.list_aws_regions = to_raw_response_wrapper(
            cdn.list_aws_regions,
        )
        self.list_purge_statuses = to_raw_response_wrapper(
            cdn.list_purge_statuses,
        )
        self.update_account = to_raw_response_wrapper(
            cdn.update_account,
        )

    @cached_property
    def cdn_resources(self) -> CDNResourcesResourceWithRawResponse:
        return CDNResourcesResourceWithRawResponse(self._cdn.cdn_resources)

    @cached_property
    def shields(self) -> ShieldsResourceWithRawResponse:
        return ShieldsResourceWithRawResponse(self._cdn.shields)

    @cached_property
    def origin_groups(self) -> OriginGroupsResourceWithRawResponse:
        """
        CDN origin groups aggregate one or more origin servers with failover and load balancing for content delivery.
        """
        return OriginGroupsResourceWithRawResponse(self._cdn.origin_groups)

    @cached_property
    def rule_templates(self) -> RuleTemplatesResourceWithRawResponse:
        """
        CDN rule templates define reusable rule configurations that can be applied across multiple CDN resources for consistent caching, delivery, and security policies.
        """
        return RuleTemplatesResourceWithRawResponse(self._cdn.rule_templates)

    @cached_property
    def certificates(self) -> CertificatesResourceWithRawResponse:
        """
        CDN SSL certificates enable HTTPS content delivery, supporting both uploaded certificates and automated Let's Encrypt provisioning.
        """
        return CertificatesResourceWithRawResponse(self._cdn.certificates)

    @cached_property
    def trusted_ca_certificates(self) -> TrustedCaCertificatesResourceWithRawResponse:
        """
        Trusted CA certificates verify the authenticity of CDN origin servers during HTTPS connections.
        """
        return TrustedCaCertificatesResourceWithRawResponse(self._cdn.trusted_ca_certificates)

    @cached_property
    def audit_logs(self) -> AuditLogsResourceWithRawResponse:
        """
        Get the history of users requests to CDN.
        It contains requests made both via the API and via the control panel.

        The following methods are not tracked in the activity logs:
        - HEAD
        - OPTIONS
        """
        return AuditLogsResourceWithRawResponse(self._cdn.audit_logs)

    @cached_property
    def logs(self) -> LogsResourceWithRawResponse:
        """Log viewer provides you with general information about CDN operation.

        This information does not contain all possible
        sets of fields and restricted by time. To receive full data, use Logs Uploader.
        """
        return LogsResourceWithRawResponse(self._cdn.logs)

    @cached_property
    def logs_uploader(self) -> LogsUploaderResourceWithRawResponse:
        return LogsUploaderResourceWithRawResponse(self._cdn.logs_uploader)

    @cached_property
    def statistics(self) -> StatisticsResourceWithRawResponse:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return StatisticsResourceWithRawResponse(self._cdn.statistics)

    @cached_property
    def network_capacity(self) -> NetworkCapacityResourceWithRawResponse:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return NetworkCapacityResourceWithRawResponse(self._cdn.network_capacity)

    @cached_property
    def metrics(self) -> MetricsResourceWithRawResponse:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return MetricsResourceWithRawResponse(self._cdn.metrics)

    @cached_property
    def ip_ranges(self) -> IPRangesResourceWithRawResponse:
        return IPRangesResourceWithRawResponse(self._cdn.ip_ranges)

    @cached_property
    def ips(self) -> IPsResourceWithRawResponse:
        return IPsResourceWithRawResponse(self._cdn.ips)

    @cached_property
    def client_config(self) -> ClientConfigResourceWithRawResponse:
        """Information about the current state of the CDN service in your account."""
        return ClientConfigResourceWithRawResponse(self._cdn.client_config)


class AsyncCDNResourceWithRawResponse:
    def __init__(self, cdn: AsyncCDNResource) -> None:
        self._cdn = cdn

        self.get_account_limits = async_to_raw_response_wrapper(
            cdn.get_account_limits,
        )
        self.get_account_overview = async_to_raw_response_wrapper(
            cdn.get_account_overview,
        )
        self.get_available_features = async_to_raw_response_wrapper(
            cdn.get_available_features,
        )
        self.list_alibaba_regions = async_to_raw_response_wrapper(
            cdn.list_alibaba_regions,
        )
        self.list_aws_regions = async_to_raw_response_wrapper(
            cdn.list_aws_regions,
        )
        self.list_purge_statuses = async_to_raw_response_wrapper(
            cdn.list_purge_statuses,
        )
        self.update_account = async_to_raw_response_wrapper(
            cdn.update_account,
        )

    @cached_property
    def cdn_resources(self) -> AsyncCDNResourcesResourceWithRawResponse:
        return AsyncCDNResourcesResourceWithRawResponse(self._cdn.cdn_resources)

    @cached_property
    def shields(self) -> AsyncShieldsResourceWithRawResponse:
        return AsyncShieldsResourceWithRawResponse(self._cdn.shields)

    @cached_property
    def origin_groups(self) -> AsyncOriginGroupsResourceWithRawResponse:
        """
        CDN origin groups aggregate one or more origin servers with failover and load balancing for content delivery.
        """
        return AsyncOriginGroupsResourceWithRawResponse(self._cdn.origin_groups)

    @cached_property
    def rule_templates(self) -> AsyncRuleTemplatesResourceWithRawResponse:
        """
        CDN rule templates define reusable rule configurations that can be applied across multiple CDN resources for consistent caching, delivery, and security policies.
        """
        return AsyncRuleTemplatesResourceWithRawResponse(self._cdn.rule_templates)

    @cached_property
    def certificates(self) -> AsyncCertificatesResourceWithRawResponse:
        """
        CDN SSL certificates enable HTTPS content delivery, supporting both uploaded certificates and automated Let's Encrypt provisioning.
        """
        return AsyncCertificatesResourceWithRawResponse(self._cdn.certificates)

    @cached_property
    def trusted_ca_certificates(self) -> AsyncTrustedCaCertificatesResourceWithRawResponse:
        """
        Trusted CA certificates verify the authenticity of CDN origin servers during HTTPS connections.
        """
        return AsyncTrustedCaCertificatesResourceWithRawResponse(self._cdn.trusted_ca_certificates)

    @cached_property
    def audit_logs(self) -> AsyncAuditLogsResourceWithRawResponse:
        """
        Get the history of users requests to CDN.
        It contains requests made both via the API and via the control panel.

        The following methods are not tracked in the activity logs:
        - HEAD
        - OPTIONS
        """
        return AsyncAuditLogsResourceWithRawResponse(self._cdn.audit_logs)

    @cached_property
    def logs(self) -> AsyncLogsResourceWithRawResponse:
        """Log viewer provides you with general information about CDN operation.

        This information does not contain all possible
        sets of fields and restricted by time. To receive full data, use Logs Uploader.
        """
        return AsyncLogsResourceWithRawResponse(self._cdn.logs)

    @cached_property
    def logs_uploader(self) -> AsyncLogsUploaderResourceWithRawResponse:
        return AsyncLogsUploaderResourceWithRawResponse(self._cdn.logs_uploader)

    @cached_property
    def statistics(self) -> AsyncStatisticsResourceWithRawResponse:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return AsyncStatisticsResourceWithRawResponse(self._cdn.statistics)

    @cached_property
    def network_capacity(self) -> AsyncNetworkCapacityResourceWithRawResponse:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return AsyncNetworkCapacityResourceWithRawResponse(self._cdn.network_capacity)

    @cached_property
    def metrics(self) -> AsyncMetricsResourceWithRawResponse:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return AsyncMetricsResourceWithRawResponse(self._cdn.metrics)

    @cached_property
    def ip_ranges(self) -> AsyncIPRangesResourceWithRawResponse:
        return AsyncIPRangesResourceWithRawResponse(self._cdn.ip_ranges)

    @cached_property
    def ips(self) -> AsyncIPsResourceWithRawResponse:
        return AsyncIPsResourceWithRawResponse(self._cdn.ips)

    @cached_property
    def client_config(self) -> AsyncClientConfigResourceWithRawResponse:
        """Information about the current state of the CDN service in your account."""
        return AsyncClientConfigResourceWithRawResponse(self._cdn.client_config)


class CDNResourceWithStreamingResponse:
    def __init__(self, cdn: CDNResource) -> None:
        self._cdn = cdn

        self.get_account_limits = to_streamed_response_wrapper(
            cdn.get_account_limits,
        )
        self.get_account_overview = to_streamed_response_wrapper(
            cdn.get_account_overview,
        )
        self.get_available_features = to_streamed_response_wrapper(
            cdn.get_available_features,
        )
        self.list_alibaba_regions = to_streamed_response_wrapper(
            cdn.list_alibaba_regions,
        )
        self.list_aws_regions = to_streamed_response_wrapper(
            cdn.list_aws_regions,
        )
        self.list_purge_statuses = to_streamed_response_wrapper(
            cdn.list_purge_statuses,
        )
        self.update_account = to_streamed_response_wrapper(
            cdn.update_account,
        )

    @cached_property
    def cdn_resources(self) -> CDNResourcesResourceWithStreamingResponse:
        return CDNResourcesResourceWithStreamingResponse(self._cdn.cdn_resources)

    @cached_property
    def shields(self) -> ShieldsResourceWithStreamingResponse:
        return ShieldsResourceWithStreamingResponse(self._cdn.shields)

    @cached_property
    def origin_groups(self) -> OriginGroupsResourceWithStreamingResponse:
        """
        CDN origin groups aggregate one or more origin servers with failover and load balancing for content delivery.
        """
        return OriginGroupsResourceWithStreamingResponse(self._cdn.origin_groups)

    @cached_property
    def rule_templates(self) -> RuleTemplatesResourceWithStreamingResponse:
        """
        CDN rule templates define reusable rule configurations that can be applied across multiple CDN resources for consistent caching, delivery, and security policies.
        """
        return RuleTemplatesResourceWithStreamingResponse(self._cdn.rule_templates)

    @cached_property
    def certificates(self) -> CertificatesResourceWithStreamingResponse:
        """
        CDN SSL certificates enable HTTPS content delivery, supporting both uploaded certificates and automated Let's Encrypt provisioning.
        """
        return CertificatesResourceWithStreamingResponse(self._cdn.certificates)

    @cached_property
    def trusted_ca_certificates(self) -> TrustedCaCertificatesResourceWithStreamingResponse:
        """
        Trusted CA certificates verify the authenticity of CDN origin servers during HTTPS connections.
        """
        return TrustedCaCertificatesResourceWithStreamingResponse(self._cdn.trusted_ca_certificates)

    @cached_property
    def audit_logs(self) -> AuditLogsResourceWithStreamingResponse:
        """
        Get the history of users requests to CDN.
        It contains requests made both via the API and via the control panel.

        The following methods are not tracked in the activity logs:
        - HEAD
        - OPTIONS
        """
        return AuditLogsResourceWithStreamingResponse(self._cdn.audit_logs)

    @cached_property
    def logs(self) -> LogsResourceWithStreamingResponse:
        """Log viewer provides you with general information about CDN operation.

        This information does not contain all possible
        sets of fields and restricted by time. To receive full data, use Logs Uploader.
        """
        return LogsResourceWithStreamingResponse(self._cdn.logs)

    @cached_property
    def logs_uploader(self) -> LogsUploaderResourceWithStreamingResponse:
        return LogsUploaderResourceWithStreamingResponse(self._cdn.logs_uploader)

    @cached_property
    def statistics(self) -> StatisticsResourceWithStreamingResponse:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return StatisticsResourceWithStreamingResponse(self._cdn.statistics)

    @cached_property
    def network_capacity(self) -> NetworkCapacityResourceWithStreamingResponse:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return NetworkCapacityResourceWithStreamingResponse(self._cdn.network_capacity)

    @cached_property
    def metrics(self) -> MetricsResourceWithStreamingResponse:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return MetricsResourceWithStreamingResponse(self._cdn.metrics)

    @cached_property
    def ip_ranges(self) -> IPRangesResourceWithStreamingResponse:
        return IPRangesResourceWithStreamingResponse(self._cdn.ip_ranges)

    @cached_property
    def ips(self) -> IPsResourceWithStreamingResponse:
        return IPsResourceWithStreamingResponse(self._cdn.ips)

    @cached_property
    def client_config(self) -> ClientConfigResourceWithStreamingResponse:
        """Information about the current state of the CDN service in your account."""
        return ClientConfigResourceWithStreamingResponse(self._cdn.client_config)


class AsyncCDNResourceWithStreamingResponse:
    def __init__(self, cdn: AsyncCDNResource) -> None:
        self._cdn = cdn

        self.get_account_limits = async_to_streamed_response_wrapper(
            cdn.get_account_limits,
        )
        self.get_account_overview = async_to_streamed_response_wrapper(
            cdn.get_account_overview,
        )
        self.get_available_features = async_to_streamed_response_wrapper(
            cdn.get_available_features,
        )
        self.list_alibaba_regions = async_to_streamed_response_wrapper(
            cdn.list_alibaba_regions,
        )
        self.list_aws_regions = async_to_streamed_response_wrapper(
            cdn.list_aws_regions,
        )
        self.list_purge_statuses = async_to_streamed_response_wrapper(
            cdn.list_purge_statuses,
        )
        self.update_account = async_to_streamed_response_wrapper(
            cdn.update_account,
        )

    @cached_property
    def cdn_resources(self) -> AsyncCDNResourcesResourceWithStreamingResponse:
        return AsyncCDNResourcesResourceWithStreamingResponse(self._cdn.cdn_resources)

    @cached_property
    def shields(self) -> AsyncShieldsResourceWithStreamingResponse:
        return AsyncShieldsResourceWithStreamingResponse(self._cdn.shields)

    @cached_property
    def origin_groups(self) -> AsyncOriginGroupsResourceWithStreamingResponse:
        """
        CDN origin groups aggregate one or more origin servers with failover and load balancing for content delivery.
        """
        return AsyncOriginGroupsResourceWithStreamingResponse(self._cdn.origin_groups)

    @cached_property
    def rule_templates(self) -> AsyncRuleTemplatesResourceWithStreamingResponse:
        """
        CDN rule templates define reusable rule configurations that can be applied across multiple CDN resources for consistent caching, delivery, and security policies.
        """
        return AsyncRuleTemplatesResourceWithStreamingResponse(self._cdn.rule_templates)

    @cached_property
    def certificates(self) -> AsyncCertificatesResourceWithStreamingResponse:
        """
        CDN SSL certificates enable HTTPS content delivery, supporting both uploaded certificates and automated Let's Encrypt provisioning.
        """
        return AsyncCertificatesResourceWithStreamingResponse(self._cdn.certificates)

    @cached_property
    def trusted_ca_certificates(self) -> AsyncTrustedCaCertificatesResourceWithStreamingResponse:
        """
        Trusted CA certificates verify the authenticity of CDN origin servers during HTTPS connections.
        """
        return AsyncTrustedCaCertificatesResourceWithStreamingResponse(self._cdn.trusted_ca_certificates)

    @cached_property
    def audit_logs(self) -> AsyncAuditLogsResourceWithStreamingResponse:
        """
        Get the history of users requests to CDN.
        It contains requests made both via the API and via the control panel.

        The following methods are not tracked in the activity logs:
        - HEAD
        - OPTIONS
        """
        return AsyncAuditLogsResourceWithStreamingResponse(self._cdn.audit_logs)

    @cached_property
    def logs(self) -> AsyncLogsResourceWithStreamingResponse:
        """Log viewer provides you with general information about CDN operation.

        This information does not contain all possible
        sets of fields and restricted by time. To receive full data, use Logs Uploader.
        """
        return AsyncLogsResourceWithStreamingResponse(self._cdn.logs)

    @cached_property
    def logs_uploader(self) -> AsyncLogsUploaderResourceWithStreamingResponse:
        return AsyncLogsUploaderResourceWithStreamingResponse(self._cdn.logs_uploader)

    @cached_property
    def statistics(self) -> AsyncStatisticsResourceWithStreamingResponse:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return AsyncStatisticsResourceWithStreamingResponse(self._cdn.statistics)

    @cached_property
    def network_capacity(self) -> AsyncNetworkCapacityResourceWithStreamingResponse:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return AsyncNetworkCapacityResourceWithStreamingResponse(self._cdn.network_capacity)

    @cached_property
    def metrics(self) -> AsyncMetricsResourceWithStreamingResponse:
        """
        Consumption statistics is updated in near real-time as a standard practice.
        However, the frequency of updates can vary, but they are typically available within a 24-hour period.
        Exceptions, such as maintenance periods, may delay data beyond 24 hours until servers resume and fill in the missing statistics.
        """
        return AsyncMetricsResourceWithStreamingResponse(self._cdn.metrics)

    @cached_property
    def ip_ranges(self) -> AsyncIPRangesResourceWithStreamingResponse:
        return AsyncIPRangesResourceWithStreamingResponse(self._cdn.ip_ranges)

    @cached_property
    def ips(self) -> AsyncIPsResourceWithStreamingResponse:
        return AsyncIPsResourceWithStreamingResponse(self._cdn.ips)

    @cached_property
    def client_config(self) -> AsyncClientConfigResourceWithStreamingResponse:
        """Information about the current state of the CDN service in your account."""
        return AsyncClientConfigResourceWithStreamingResponse(self._cdn.client_config)
