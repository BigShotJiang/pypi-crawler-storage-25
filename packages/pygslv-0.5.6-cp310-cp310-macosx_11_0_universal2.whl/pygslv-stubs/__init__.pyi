"""
GSLV (GridSoLVer) is eRoots' excellent power systems simulation library
"""
from __future__ import annotations
import pybind11_stubgen.typing_ext
import scipy.sparse
import typing
__all__ = ['AcOpfMode', 'ActionType', 'ActiveBranchData', 'AdmittanceMatrices', 'Area', 'Assets', 'Association', 'Associations', 'AvailableTransferMode', 'Battery', 'BatteryData', 'BranchGroup', 'BranchGroupTypes', 'BranchImpedanceMode', 'BranchParent', 'BranchParentData', 'BuildStatus', 'Bus', 'BusData', 'BusMode', 'ClusteringResults', 'Community', 'ConnectivityMatrices', 'Const', 'Contingency', 'ContingencyAnalysisOptions', 'ContingencyAnalysisResults', 'ContingencyFilteringMethods', 'ContingencyGroup', 'ContingencyIndices', 'ContingencyMethod', 'ContingencyOperationTypes', 'ControllableBranchParent', 'ControllableShunt', 'ConvergenceReport', 'ConverterControlType', 'Country', 'CpfParametrization', 'CpfStopAt', 'CurrentInjection', 'DcLine', 'DeviceType', 'DiagramType', 'EQ', 'EditableDevice', 'EmissionGas', 'Expr', 'ExternalGrid', 'ExternalGridMode', 'Facility', 'FastDecoupledAdmittanceMatrices', 'FaultType', 'Fuel', 'GEQ', 'GenerationNtcFormulation', 'Generator', 'GeneratorData', 'GeneratorQCurve', 'GenericAreaGroup', 'HashMapsize_t_double', 'HvdcControlType', 'HvdcData', 'HvdcLine', 'InjectionParent', 'Investment', 'InvestmentEvaluationMethod', 'InvestmentGroup', 'InvestmentsEvaluationObjectives', 'JobStatus', 'LEQ', 'LicenseResponse', 'Line', 'LinearAdmittanceMatrices', 'LinearAnalysis', 'LinearAnalysisOptions', 'LinearMultiContingencies', 'LinearMultiContingency', 'Load', 'LoadData', 'LoadParent', 'LogEntry', 'LogSeverity', 'Logger', 'LpConstraintType', 'LpCst', 'LpExp', 'LpModel', 'LpResult', 'LpSense', 'LpVar', 'MAXIMIZE', 'MINIMIZE', 'MIPSolvers', 'ModellingAuthority', 'MultiCircuit', 'Municipality', 'NodalCapacityMethod', 'NumericalCircuit', 'OptionsTemplate', 'OverheadLineType', 'PassiveBranchData', 'PhysicalDevice', 'PowerFlowOptions', 'PowerFlowResults', 'ProfileBus', 'ProfileConverterControlType', 'ProfilePhysicalDevicePtr', 'ProfileTapModuleControl', 'ProfileTapPhaseControl', 'Profilebool', 'Profiledouble', 'Profileint', 'Profileuint', 'Region', 'RemedialAction', 'RemedialActionGroup', 'ResultsTemplate', 'SequenceLineType', 'SeriesAdmittanceMatrices', 'SeriesReactance', 'Shunt', 'ShuntData', 'ShuntParent', 'SimulationIndices', 'SimulationType', 'SolverType', 'SpaseArrayBus', 'SpaseArrayConverterControlType', 'SpaseArrayPhysicalDevicePtr', 'SpaseArrayTapModuleControl', 'SpaseArrayTapPhaseControl', 'SpaseArraybool', 'SpaseArraydouble', 'SpaseArrayint', 'SpaseArrayuint', 'StaticGenerator', 'SubObjectType', 'Substation', 'SubstationTypes', 'Switch', 'TapChanger', 'TapChangerTypes', 'TapModuleControl', 'TapPhaseControl', 'Technology', 'TimeFrame', 'TimeGrouping', 'Transformer2W', 'Transformer3W', 'UndergroundLineType', 'Upfc', 'Var', 'VoltageLevel', 'Vsc', 'VscData', 'Winding', 'WindingsConnection', 'Wire', 'WireInTower', 'ZonalGrouping', 'Zone', 'acos', 'activate', 'asin', 'atan', 'checkLicense', 'compile', 'cos', 'cosh', 'exp', 'get_version', 'isLicensed', 'log', 'make_const', 'make_var', 'multi_island_pf', 'pow', 'read_file', 'run_contingencies', 'search_license_and_activate', 'sin', 'sinh', 'sqrt', 'sym_diff', 'sym_eval', 'tan']
class AcOpfMode:
    """
    Members:
    
      ACOPFstd
    
      ACOPFslacks
    
      ACOPFMaxInjections
    """
    ACOPFMaxInjections: typing.ClassVar[AcOpfMode]  # value = <AcOpfMode.ACOPFMaxInjections: 2>
    ACOPFslacks: typing.ClassVar[AcOpfMode]  # value = <AcOpfMode.ACOPFslacks: 1>
    ACOPFstd: typing.ClassVar[AcOpfMode]  # value = <AcOpfMode.ACOPFstd: 0>
    __members__: typing.ClassVar[dict[str, AcOpfMode]]  # value = {'ACOPFstd': <AcOpfMode.ACOPFstd: 0>, 'ACOPFslacks': <AcOpfMode.ACOPFslacks: 1>, 'ACOPFMaxInjections': <AcOpfMode.ACOPFMaxInjections: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class ActionType:
    """
    Members:
    
      NoAction
    
      Add
    
      Modify
    
      Delete
    """
    Add: typing.ClassVar[ActionType]  # value = <ActionType.Add: 1>
    Delete: typing.ClassVar[ActionType]  # value = <ActionType.Delete: 3>
    Modify: typing.ClassVar[ActionType]  # value = <ActionType.Modify: 2>
    NoAction: typing.ClassVar[ActionType]  # value = <ActionType.NoAction: 0>
    __members__: typing.ClassVar[dict[str, ActionType]]  # value = {'NoAction': <ActionType.NoAction: 0>, 'Add': <ActionType.Add: 1>, 'Modify': <ActionType.Modify: 2>, 'Delete': <ActionType.Delete: 3>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class ActiveBranchData:
    Pset: Numpy.ndarray[]
    Qset: Numpy.ndarray[]
    any_pf_control: bool
    is_controlled: Numpy.ndarray[]
    m_taps: Numpy.ndarray[]
    nbus: int
    nelm: int
    tap_angle: Numpy.ndarray[]
    tap_angle_max: Numpy.ndarray[]
    tap_angle_min: Numpy.ndarray[]
    tap_controlled_buses: Numpy.ndarray[]
    tap_module: Numpy.ndarray[]
    tap_module_control_mode: list[TapModuleControl]
    tap_module_max: Numpy.ndarray[]
    tap_module_min: Numpy.ndarray[]
    tap_phase_control_mode: list[TapPhaseControl]
    tau_taps: Numpy.ndarray[]
    vset: Numpy.ndarray[]
    def __init__(self, arg0: int, arg1: int) -> None:
        ...
class AdmittanceMatrices:
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, Ybus: scipy.sparse.csc_matrix, Yf: scipy.sparse.csc_matrix, Yt: scipy.sparse.csc_matrix, Yshunt_bus: Numpy.ndarray[], ys: Numpy.ndarray[], ysh2: Numpy.ndarray[], vtap_f: Numpy.ndarray[], vtap_t: Numpy.ndarray[], yff: Numpy.ndarray[], yft: Numpy.ndarray[], ytf: Numpy.ndarray[], ytt: Numpy.ndarray[], F: Numpy.ndarray[], T: Numpy.ndarray[]) -> None:
        ...
    @property
    def Ybus(self) -> scipy.sparse.csc_matrix:
        ...
    @property
    def Yf(self) -> scipy.sparse.csc_matrix:
        ...
    @property
    def Yshunt_bus(self) -> Numpy.ndarray[]:
        ...
    @property
    def Yt(self) -> scipy.sparse.csc_matrix:
        ...
    @property
    def yff(self) -> Numpy.ndarray[]:
        ...
    @property
    def yft(self) -> Numpy.ndarray[]:
        ...
    @property
    def ytf(self) -> Numpy.ndarray[]:
        ...
    @property
    def ytt(self) -> Numpy.ndarray[]:
        ...
class Area(GenericAreaGroup):
    def __init__(self, name: str = '', idtag: str = '', code: str = '') -> None:
        """
        Constructor for Area.
        
        :param name: Name of the area
        :param idtag: ID tag
        :param code: Code for the area.
        """
class Assets:
    def __init__(self, nt: int = 1) -> None:
        """
        Create an Assets container.
        
        Parameters
        ----------
        nt : int, optional
            Number of time steps to allocate. Defaults to 1.
        """
    def add_area(self, val: Area) -> None:
        """
        Add a new Area instance to the container.
        
        Parameters
        ----------
        val : Area
            Object to add.
        """
    def add_battery(self, val: Battery) -> None:
        """
        Add a new Battery instance to the container.
        
        Parameters
        ----------
        val : Battery
            Object to add.
        """
    def add_branch_group(self, val: BranchGroup) -> None:
        """
        Add a new BranchGroup instance to the container.
        
        Parameters
        ----------
        val : BranchGroup
            Object to add.
        """
    def add_bus(self, val: Bus) -> None:
        """
        Add a new Bus instance to the container.
        
        Parameters
        ----------
        val : Bus
            Object to add.
        """
    def add_bus_bar(self, val: ...) -> None:
        """
        Add a new BusBar instance to the container.
        
        Parameters
        ----------
        val : BusBar
            Object to add.
        """
    def add_community(self, val: Community) -> None:
        """
        Add a new Community instance to the container.
        
        Parameters
        ----------
        val : Community
            Object to add.
        """
    def add_contingency(self, val: Contingency) -> None:
        """
        Add a new Contingency instance to the container.
        
        Parameters
        ----------
        val : Contingency
            Object to add.
        """
    def add_contingency_group(self, val: ContingencyGroup) -> None:
        """
        Add a new ContingencyGroup instance to the container.
        
        Parameters
        ----------
        val : ContingencyGroup
            Object to add.
        """
    def add_controllable_shunt(self, val: ControllableShunt) -> None:
        """
        Add a new ControllableShunt instance to the container.
        
        Parameters
        ----------
        val : ControllableShunt
            Object to add.
        """
    def add_country(self, val: Country) -> None:
        """
        Add a new Country instance to the container.
        
        Parameters
        ----------
        val : Country
            Object to add.
        """
    def add_current_injection(self, val: CurrentInjection) -> None:
        """
        Add a new CurrentInjection instance to the container.
        
        Parameters
        ----------
        val : CurrentInjection
            Object to add.
        """
    def add_dc_line(self, val: DcLine) -> None:
        """
        Add a new DcLine instance to the container.
        
        Parameters
        ----------
        val : DcLine
            Object to add.
        """
    def add_emission_gas(self, val: EmissionGas) -> None:
        """
        Add a new EmissionGas instance to the container.
        
        Parameters
        ----------
        val : EmissionGas
            Object to add.
        """
    def add_external_grid(self, val: ExternalGrid) -> None:
        """
        Add a new ExternalGrid instance to the container.
        
        Parameters
        ----------
        val : ExternalGrid
            Object to add.
        """
    def add_facility(self, val: Facility) -> None:
        """
        Add a new Facility instance to the container.
        
        Parameters
        ----------
        val : Facility
            Object to add.
        """
    def add_fuel(self, val: Fuel) -> None:
        """
        Add a new Fuel instance to the container.
        
        Parameters
        ----------
        val : Fuel
            Object to add.
        """
    def add_generator(self, val: Generator) -> None:
        """
        Add a new Generator instance to the container.
        
        Parameters
        ----------
        val : Generator
            Object to add.
        """
    def add_hvdc_line(self, val: HvdcLine) -> None:
        """
        Add a new HvdcLine instance to the container.
        
        Parameters
        ----------
        val : HvdcLine
            Object to add.
        """
    def add_investment(self, val: Investment) -> None:
        """
        Add a new Investment instance to the container.
        
        Parameters
        ----------
        val : Investment
            Object to add.
        """
    def add_investment_group(self, val: InvestmentGroup) -> None:
        """
        Add a new InvestmentGroup instance to the container.
        
        Parameters
        ----------
        val : InvestmentGroup
            Object to add.
        """
    def add_line(self, val: Line) -> None:
        """
        Add a new Line instance to the container.
        
        Parameters
        ----------
        val : Line
            Object to add.
        """
    def add_load(self, val: Load) -> None:
        """
        Add a new Load instance to the container.
        
        Parameters
        ----------
        val : Load
            Object to add.
        """
    def add_modelling_authority(self, val: ModellingAuthority) -> None:
        """
        Add a new ModellingAuthority instance to the container.
        
        Parameters
        ----------
        val : ModellingAuthority
            Object to add.
        """
    def add_municipality(self, val: Municipality) -> None:
        """
        Add a new Municipality instance to the container.
        
        Parameters
        ----------
        val : Municipality
            Object to add.
        """
    def add_overhead_line_type(self, val: OverheadLineType) -> None:
        """
        Add a new OverheadLineType instance to the container.
        
        Parameters
        ----------
        val : OverheadLineType
            Object to add.
        """
    def add_region(self, val: Region) -> None:
        """
        Add a new Region instance to the container.
        
        Parameters
        ----------
        val : Region
            Object to add.
        """
    def add_remedial_action(self, val: RemedialAction) -> None:
        """
        Add a new RemedialAction instance to the container.
        
        Parameters
        ----------
        val : RemedialAction
            Object to add.
        """
    def add_remedial_action_group(self, val: RemedialActionGroup) -> None:
        """
        Add a new RemedialActionGroup instance to the container.
        
        Parameters
        ----------
        val : RemedialActionGroup
            Object to add.
        """
    def add_sequence_line_type(self, val: SequenceLineType) -> None:
        """
        Add a new SequenceLineType instance to the container.
        
        Parameters
        ----------
        val : SequenceLineType
            Object to add.
        """
    def add_series_reactance(self, val: SeriesReactance) -> None:
        """
        Add a new SeriesReactance instance to the container.
        
        Parameters
        ----------
        val : SeriesReactance
            Object to add.
        """
    def add_shunt(self, val: Shunt) -> None:
        """
        Add a new Shunt instance to the container.
        
        Parameters
        ----------
        val : Shunt
            Object to add.
        """
    def add_static_generator(self, val: StaticGenerator) -> None:
        """
        Add a new StaticGenerator instance to the container.
        
        Parameters
        ----------
        val : StaticGenerator
            Object to add.
        """
    def add_substation(self, val: Substation) -> None:
        """
        Add a new Substation instance to the container.
        
        Parameters
        ----------
        val : Substation
            Object to add.
        """
    def add_switch(self, val: Switch) -> None:
        """
        Add a new Switch instance to the container.
        
        Parameters
        ----------
        val : Switch
            Object to add.
        """
    def add_technology(self, val: Technology) -> None:
        """
        Add a new Technology instance to the container.
        
        Parameters
        ----------
        val : Technology
            Object to add.
        """
    def add_transformer(self, val: Transformer2W) -> None:
        """
        Add a new Transformer instance to the container.
        
        Parameters
        ----------
        val : Transformer
            Object to add.
        """
    def add_transformer_3w(self, val: Transformer3W) -> None:
        """
        Add a new Transformer3w instance to the container.
        
        Parameters
        ----------
        val : Transformer3w
            Object to add.
        """
    def add_transformer_type(self, val: ...) -> None:
        """
        Add a new TransformerType instance to the container.
        
        Parameters
        ----------
        val : TransformerType
            Object to add.
        """
    def add_underground_line_type(self, val: UndergroundLineType) -> None:
        """
        Add a new UndergroundLineType instance to the container.
        
        Parameters
        ----------
        val : UndergroundLineType
            Object to add.
        """
    def add_upfc(self, val: Upfc) -> None:
        """
        Add a new Upfc instance to the container.
        
        Parameters
        ----------
        val : Upfc
            Object to add.
        """
    def add_voltage_level(self, val: VoltageLevel) -> None:
        """
        Add a new VoltageLevel instance to the container.
        
        Parameters
        ----------
        val : VoltageLevel
            Object to add.
        """
    def add_vsc(self, val: Vsc) -> None:
        """
        Add a new Vsc instance to the container.
        
        Parameters
        ----------
        val : Vsc
            Object to add.
        """
    def add_winding(self, val: Winding) -> None:
        """
        Add a new Winding instance to the container.
        
        Parameters
        ----------
        val : Winding
            Object to add.
        """
    def add_wire(self, val: Wire) -> None:
        """
        Add a new Wire instance to the container.
        
        Parameters
        ----------
        val : Wire
            Object to add.
        """
    def add_zone(self, val: Zone) -> None:
        """
        Add a new Zone instance to the container.
        
        Parameters
        ----------
        val : Zone
            Object to add.
        """
    def delete_area(self, val: Area) -> None:
        """
        Remove an existing Area from the container.
        
        Parameters
        ----------
        val : Area
            Object to remove (it must already exist).
        """
    def delete_area_at(self, index: int) -> None:
        """
        Remove a(n) Area by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_battery(self, val: Battery) -> None:
        """
        Remove an existing Battery from the container.
        
        Parameters
        ----------
        val : Battery
            Object to remove (it must already exist).
        """
    def delete_battery_at(self, index: int) -> None:
        """
        Remove a(n) Battery by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_branch_group(self, val: BranchGroup) -> None:
        """
        Remove an existing BranchGroup from the container.
        
        Parameters
        ----------
        val : BranchGroup
            Object to remove (it must already exist).
        """
    def delete_branch_group_at(self, index: int) -> None:
        """
        Remove a(n) BranchGroup by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_bus(self, val: Bus) -> None:
        """
        Remove an existing Bus from the container.
        
        Parameters
        ----------
        val : Bus
            Object to remove (it must already exist).
        """
    def delete_bus_at(self, index: int) -> None:
        """
        Remove a(n) Bus by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_bus_bar(self, val: ...) -> None:
        """
        Remove an existing BusBar from the container.
        
        Parameters
        ----------
        val : BusBar
            Object to remove (it must already exist).
        """
    def delete_bus_bar_at(self, index: int) -> None:
        """
        Remove a(n) BusBar by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_community(self, val: Community) -> None:
        """
        Remove an existing Community from the container.
        
        Parameters
        ----------
        val : Community
            Object to remove (it must already exist).
        """
    def delete_community_at(self, index: int) -> None:
        """
        Remove a(n) Community by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_contingency(self, val: Contingency) -> None:
        """
        Remove an existing Contingency from the container.
        
        Parameters
        ----------
        val : Contingency
            Object to remove (it must already exist).
        """
    def delete_contingency_at(self, index: int) -> None:
        """
        Remove a(n) Contingency by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_contingency_group(self, val: ContingencyGroup) -> None:
        """
        Remove an existing ContingencyGroup from the container.
        
        Parameters
        ----------
        val : ContingencyGroup
            Object to remove (it must already exist).
        """
    def delete_contingency_group_at(self, index: int) -> None:
        """
        Remove a(n) ContingencyGroup by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_controllable_shunt(self, val: ControllableShunt) -> None:
        """
        Remove an existing ControllableShunt from the container.
        
        Parameters
        ----------
        val : ControllableShunt
            Object to remove (it must already exist).
        """
    def delete_controllable_shunt_at(self, index: int) -> None:
        """
        Remove a(n) ControllableShunt by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_country(self, val: Country) -> None:
        """
        Remove an existing Country from the container.
        
        Parameters
        ----------
        val : Country
            Object to remove (it must already exist).
        """
    def delete_country_at(self, index: int) -> None:
        """
        Remove a(n) Country by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_current_injection(self, val: CurrentInjection) -> None:
        """
        Remove an existing CurrentInjection from the container.
        
        Parameters
        ----------
        val : CurrentInjection
            Object to remove (it must already exist).
        """
    def delete_current_injection_at(self, index: int) -> None:
        """
        Remove a(n) CurrentInjection by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_dc_line(self, val: DcLine) -> None:
        """
        Remove an existing DcLine from the container.
        
        Parameters
        ----------
        val : DcLine
            Object to remove (it must already exist).
        """
    def delete_dc_line_at(self, index: int) -> None:
        """
        Remove a(n) DcLine by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_emission_gas(self, val: EmissionGas) -> None:
        """
        Remove an existing EmissionGas from the container.
        
        Parameters
        ----------
        val : EmissionGas
            Object to remove (it must already exist).
        """
    def delete_emission_gas_at(self, index: int) -> None:
        """
        Remove a(n) EmissionGas by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_external_grid(self, val: ExternalGrid) -> None:
        """
        Remove an existing ExternalGrid from the container.
        
        Parameters
        ----------
        val : ExternalGrid
            Object to remove (it must already exist).
        """
    def delete_external_grid_at(self, index: int) -> None:
        """
        Remove a(n) ExternalGrid by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_facility(self, val: Facility) -> None:
        """
        Remove an existing Facility from the container.
        
        Parameters
        ----------
        val : Facility
            Object to remove (it must already exist).
        """
    def delete_facility_at(self, index: int) -> None:
        """
        Remove a(n) Facility by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_fuel(self, val: Fuel) -> None:
        """
        Remove an existing Fuel from the container.
        
        Parameters
        ----------
        val : Fuel
            Object to remove (it must already exist).
        """
    def delete_fuel_at(self, index: int) -> None:
        """
        Remove a(n) Fuel by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_generator(self, val: Generator) -> None:
        """
        Remove an existing Generator from the container.
        
        Parameters
        ----------
        val : Generator
            Object to remove (it must already exist).
        """
    def delete_generator_at(self, index: int) -> None:
        """
        Remove a(n) Generator by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_hvdc_line(self, val: HvdcLine) -> None:
        """
        Remove an existing HvdcLine from the container.
        
        Parameters
        ----------
        val : HvdcLine
            Object to remove (it must already exist).
        """
    def delete_hvdc_line_at(self, index: int) -> None:
        """
        Remove a(n) HvdcLine by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_investment(self, val: Investment) -> None:
        """
        Remove an existing Investment from the container.
        
        Parameters
        ----------
        val : Investment
            Object to remove (it must already exist).
        """
    def delete_investment_at(self, index: int) -> None:
        """
        Remove a(n) Investment by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_investment_group(self, val: InvestmentGroup) -> None:
        """
        Remove an existing InvestmentGroup from the container.
        
        Parameters
        ----------
        val : InvestmentGroup
            Object to remove (it must already exist).
        """
    def delete_investment_group_at(self, index: int) -> None:
        """
        Remove a(n) InvestmentGroup by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_line(self, val: Line) -> None:
        """
        Remove an existing Line from the container.
        
        Parameters
        ----------
        val : Line
            Object to remove (it must already exist).
        """
    def delete_line_at(self, index: int) -> None:
        """
        Remove a(n) Line by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_load(self, val: Load) -> None:
        """
        Remove an existing Load from the container.
        
        Parameters
        ----------
        val : Load
            Object to remove (it must already exist).
        """
    def delete_load_at(self, index: int) -> None:
        """
        Remove a(n) Load by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_modelling_authority(self, val: ModellingAuthority) -> None:
        """
        Remove an existing ModellingAuthority from the container.
        
        Parameters
        ----------
        val : ModellingAuthority
            Object to remove (it must already exist).
        """
    def delete_modelling_authority_at(self, index: int) -> None:
        """
        Remove a(n) ModellingAuthority by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_municipality(self, val: Municipality) -> None:
        """
        Remove an existing Municipality from the container.
        
        Parameters
        ----------
        val : Municipality
            Object to remove (it must already exist).
        """
    def delete_municipality_at(self, index: int) -> None:
        """
        Remove a(n) Municipality by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_overhead_line_type(self, val: OverheadLineType) -> None:
        """
        Remove an existing OverheadLineType from the container.
        
        Parameters
        ----------
        val : OverheadLineType
            Object to remove (it must already exist).
        """
    def delete_overhead_line_type_at(self, index: int) -> None:
        """
        Remove a(n) OverheadLineType by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_region(self, val: Region) -> None:
        """
        Remove an existing Region from the container.
        
        Parameters
        ----------
        val : Region
            Object to remove (it must already exist).
        """
    def delete_region_at(self, index: int) -> None:
        """
        Remove a(n) Region by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_remedial_action(self, val: RemedialAction) -> None:
        """
        Remove an existing RemedialAction from the container.
        
        Parameters
        ----------
        val : RemedialAction
            Object to remove (it must already exist).
        """
    def delete_remedial_action_at(self, index: int) -> None:
        """
        Remove a(n) RemedialAction by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_remedial_action_group(self, val: RemedialActionGroup) -> None:
        """
        Remove an existing RemedialActionGroup from the container.
        
        Parameters
        ----------
        val : RemedialActionGroup
            Object to remove (it must already exist).
        """
    def delete_remedial_action_group_at(self, index: int) -> None:
        """
        Remove a(n) RemedialActionGroup by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_sequence_line_type(self, val: SequenceLineType) -> None:
        """
        Remove an existing SequenceLineType from the container.
        
        Parameters
        ----------
        val : SequenceLineType
            Object to remove (it must already exist).
        """
    def delete_sequence_line_type_at(self, index: int) -> None:
        """
        Remove a(n) SequenceLineType by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_series_reactance(self, val: SeriesReactance) -> None:
        """
        Remove an existing SeriesReactance from the container.
        
        Parameters
        ----------
        val : SeriesReactance
            Object to remove (it must already exist).
        """
    def delete_series_reactance_at(self, index: int) -> None:
        """
        Remove a(n) SeriesReactance by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_shunt(self, val: Shunt) -> None:
        """
        Remove an existing Shunt from the container.
        
        Parameters
        ----------
        val : Shunt
            Object to remove (it must already exist).
        """
    def delete_shunt_at(self, index: int) -> None:
        """
        Remove a(n) Shunt by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_static_generator(self, val: StaticGenerator) -> None:
        """
        Remove an existing StaticGenerator from the container.
        
        Parameters
        ----------
        val : StaticGenerator
            Object to remove (it must already exist).
        """
    def delete_static_generator_at(self, index: int) -> None:
        """
        Remove a(n) StaticGenerator by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_substation(self, val: Substation) -> None:
        """
        Remove an existing Substation from the container.
        
        Parameters
        ----------
        val : Substation
            Object to remove (it must already exist).
        """
    def delete_substation_at(self, index: int) -> None:
        """
        Remove a(n) Substation by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_switch(self, val: Switch) -> None:
        """
        Remove an existing Switch from the container.
        
        Parameters
        ----------
        val : Switch
            Object to remove (it must already exist).
        """
    def delete_switch_at(self, index: int) -> None:
        """
        Remove a(n) Switch by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_technology(self, val: Technology) -> None:
        """
        Remove an existing Technology from the container.
        
        Parameters
        ----------
        val : Technology
            Object to remove (it must already exist).
        """
    def delete_technology_at(self, index: int) -> None:
        """
        Remove a(n) Technology by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_transformer(self, val: Transformer2W) -> None:
        """
        Remove an existing Transformer from the container.
        
        Parameters
        ----------
        val : Transformer
            Object to remove (it must already exist).
        """
    def delete_transformer_3w(self, val: Transformer3W) -> None:
        """
        Remove an existing Transformer3w from the container.
        
        Parameters
        ----------
        val : Transformer3w
            Object to remove (it must already exist).
        """
    def delete_transformer_3w_at(self, index: int) -> None:
        """
        Remove a(n) Transformer3w by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_transformer_at(self, index: int) -> None:
        """
        Remove a(n) Transformer by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_transformer_type(self, val: ...) -> None:
        """
        Remove an existing TransformerType from the container.
        
        Parameters
        ----------
        val : TransformerType
            Object to remove (it must already exist).
        """
    def delete_transformer_type_at(self, index: int) -> None:
        """
        Remove a(n) TransformerType by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_underground_line_type(self, val: UndergroundLineType) -> None:
        """
        Remove an existing UndergroundLineType from the container.
        
        Parameters
        ----------
        val : UndergroundLineType
            Object to remove (it must already exist).
        """
    def delete_underground_line_type_at(self, index: int) -> None:
        """
        Remove a(n) UndergroundLineType by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_upfc(self, val: Upfc) -> None:
        """
        Remove an existing Upfc from the container.
        
        Parameters
        ----------
        val : Upfc
            Object to remove (it must already exist).
        """
    def delete_upfc_at(self, index: int) -> None:
        """
        Remove a(n) Upfc by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_voltage_level(self, val: VoltageLevel) -> None:
        """
        Remove an existing VoltageLevel from the container.
        
        Parameters
        ----------
        val : VoltageLevel
            Object to remove (it must already exist).
        """
    def delete_voltage_level_at(self, index: int) -> None:
        """
        Remove a(n) VoltageLevel by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_vsc(self, val: Vsc) -> None:
        """
        Remove an existing Vsc from the container.
        
        Parameters
        ----------
        val : Vsc
            Object to remove (it must already exist).
        """
    def delete_vsc_at(self, index: int) -> None:
        """
        Remove a(n) Vsc by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_winding(self, val: Winding) -> None:
        """
        Remove an existing Winding from the container.
        
        Parameters
        ----------
        val : Winding
            Object to remove (it must already exist).
        """
    def delete_winding_at(self, index: int) -> None:
        """
        Remove a(n) Winding by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_wire(self, val: Wire) -> None:
        """
        Remove an existing Wire from the container.
        
        Parameters
        ----------
        val : Wire
            Object to remove (it must already exist).
        """
    def delete_wire_at(self, index: int) -> None:
        """
        Remove a(n) Wire by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    def delete_zone(self, val: Zone) -> None:
        """
        Remove an existing Zone from the container.
        
        Parameters
        ----------
        val : Zone
            Object to remove (it must already exist).
        """
    def delete_zone_at(self, index: int) -> None:
        """
        Remove a(n) Zone by its positional index.
        
        Parameters
        ----------
        index : int
            Zero-based position of the element to delete.
        """
    @property
    def areas(self) -> list[Area]:
        """
        Sequence of Area objects.
        """
    @areas.setter
    def areas(self, arg1: list[Area]) -> None:
        ...
    @property
    def batteries(self) -> list[Battery]:
        """
        Sequence of Battery objects.
        """
    @batteries.setter
    def batteries(self, arg1: list[Battery]) -> None:
        ...
    @property
    def branch_groups(self) -> list[BranchGroup]:
        """
        Sequence of BranchGroup objects.
        """
    @branch_groups.setter
    def branch_groups(self, arg1: list[BranchGroup]) -> None:
        ...
    @property
    def bus_bars(self) -> list[...]:
        """
        Sequence of BusBar objects.
        """
    @bus_bars.setter
    def bus_bars(self, arg1: list[...]) -> None:
        ...
    @property
    def buses(self) -> list[Bus]:
        """
        Sequence of Bus objects.
        """
    @buses.setter
    def buses(self, arg1: list[Bus]) -> None:
        ...
    @property
    def communities(self) -> list[Community]:
        """
        Sequence of Community objects.
        """
    @communities.setter
    def communities(self, arg1: list[Community]) -> None:
        ...
    @property
    def contingencies(self) -> list[Contingency]:
        """
        Sequence of Contingency objects.
        """
    @contingencies.setter
    def contingencies(self, arg1: list[Contingency]) -> None:
        ...
    @property
    def contingency_groups(self) -> list[ContingencyGroup]:
        """
        Sequence of ContingencyGroup objects.
        """
    @contingency_groups.setter
    def contingency_groups(self, arg1: list[ContingencyGroup]) -> None:
        ...
    @property
    def controllable_shunts(self) -> list[ControllableShunt]:
        """
        Sequence of ControllableShunt objects.
        """
    @controllable_shunts.setter
    def controllable_shunts(self, arg1: list[ControllableShunt]) -> None:
        ...
    @property
    def countries(self) -> list[Country]:
        """
        Sequence of Country objects.
        """
    @countries.setter
    def countries(self, arg1: list[Country]) -> None:
        ...
    @property
    def current_injections(self) -> list[CurrentInjection]:
        """
        Sequence of CurrentInjection objects.
        """
    @current_injections.setter
    def current_injections(self, arg1: list[CurrentInjection]) -> None:
        ...
    @property
    def dc_lines(self) -> list[DcLine]:
        """
        Sequence of DcLine objects.
        """
    @dc_lines.setter
    def dc_lines(self, arg1: list[DcLine]) -> None:
        ...
    @property
    def emission_gases(self) -> list[EmissionGas]:
        """
        Sequence of EmissionGas objects.
        """
    @emission_gases.setter
    def emission_gases(self, arg1: list[EmissionGas]) -> None:
        ...
    @property
    def external_grids(self) -> list[ExternalGrid]:
        """
        Sequence of ExternalGrid objects.
        """
    @external_grids.setter
    def external_grids(self, arg1: list[ExternalGrid]) -> None:
        ...
    @property
    def facilities(self) -> list[Facility]:
        """
        Sequence of Facility objects.
        """
    @facilities.setter
    def facilities(self, arg1: list[Facility]) -> None:
        ...
    @property
    def fuels(self) -> list[Fuel]:
        """
        Sequence of Fuel objects.
        """
    @fuels.setter
    def fuels(self, arg1: list[Fuel]) -> None:
        ...
    @property
    def generators(self) -> list[Generator]:
        """
        Sequence of Generator objects.
        """
    @generators.setter
    def generators(self, arg1: list[Generator]) -> None:
        ...
    @property
    def hvdc_lines(self) -> list[HvdcLine]:
        """
        Sequence of HvdcLine objects.
        """
    @hvdc_lines.setter
    def hvdc_lines(self, arg1: list[HvdcLine]) -> None:
        ...
    @property
    def investment_groups(self) -> list[InvestmentGroup]:
        """
        Sequence of InvestmentGroup objects.
        """
    @investment_groups.setter
    def investment_groups(self, arg1: list[InvestmentGroup]) -> None:
        ...
    @property
    def investments(self) -> list[Investment]:
        """
        Sequence of Investment objects.
        """
    @investments.setter
    def investments(self, arg1: list[Investment]) -> None:
        ...
    @property
    def lines(self) -> list[Line]:
        """
        Sequence of Line objects.
        """
    @lines.setter
    def lines(self, arg1: list[Line]) -> None:
        ...
    @property
    def loads(self) -> list[Load]:
        """
        Sequence of Load objects.
        """
    @loads.setter
    def loads(self, arg1: list[Load]) -> None:
        ...
    @property
    def modelling_authorities(self) -> list[ModellingAuthority]:
        """
        Sequence of ModellingAuthority objects.
        """
    @modelling_authorities.setter
    def modelling_authorities(self, arg1: list[ModellingAuthority]) -> None:
        ...
    @property
    def municipalities(self) -> list[Municipality]:
        """
        Sequence of Municipality objects.
        """
    @municipalities.setter
    def municipalities(self, arg1: list[Municipality]) -> None:
        ...
    @property
    def overhead_line_types(self) -> list[OverheadLineType]:
        """
        Sequence of OverheadLineType objects.
        """
    @overhead_line_types.setter
    def overhead_line_types(self, arg1: list[OverheadLineType]) -> None:
        ...
    @property
    def regions(self) -> list[Region]:
        """
        Sequence of Region objects.
        """
    @regions.setter
    def regions(self, arg1: list[Region]) -> None:
        ...
    @property
    def remedial_action_groups(self) -> list[RemedialActionGroup]:
        """
        Sequence of RemedialActionGroup objects.
        """
    @remedial_action_groups.setter
    def remedial_action_groups(self, arg1: list[RemedialActionGroup]) -> None:
        ...
    @property
    def remedial_actions(self) -> list[RemedialAction]:
        """
        Sequence of RemedialAction objects.
        """
    @remedial_actions.setter
    def remedial_actions(self, arg1: list[RemedialAction]) -> None:
        ...
    @property
    def sequence_line_types(self) -> list[SequenceLineType]:
        """
        Sequence of SequenceLineType objects.
        """
    @sequence_line_types.setter
    def sequence_line_types(self, arg1: list[SequenceLineType]) -> None:
        ...
    @property
    def series_reactances(self) -> list[SeriesReactance]:
        """
        Sequence of SeriesReactance objects.
        """
    @series_reactances.setter
    def series_reactances(self, arg1: list[SeriesReactance]) -> None:
        ...
    @property
    def shunts(self) -> list[Shunt]:
        """
        Sequence of Shunt objects.
        """
    @shunts.setter
    def shunts(self, arg1: list[Shunt]) -> None:
        ...
    @property
    def static_generators(self) -> list[StaticGenerator]:
        """
        Sequence of StaticGenerator objects.
        """
    @static_generators.setter
    def static_generators(self, arg1: list[StaticGenerator]) -> None:
        ...
    @property
    def substations(self) -> list[Substation]:
        """
        Sequence of Substation objects.
        """
    @substations.setter
    def substations(self, arg1: list[Substation]) -> None:
        ...
    @property
    def switches(self) -> list[Switch]:
        """
        Sequence of Switch objects.
        """
    @switches.setter
    def switches(self, arg1: list[Switch]) -> None:
        ...
    @property
    def technologies(self) -> list[Technology]:
        """
        Sequence of Technology objects.
        """
    @technologies.setter
    def technologies(self, arg1: list[Technology]) -> None:
        ...
    @property
    def time_array(self) -> list[int]:
        """
        1-D NumPy array of time stamps used by the simulation.
        """
    @property
    def transformer_3ws(self) -> list[Transformer3W]:
        """
        Sequence of Transformer3w objects.
        """
    @transformer_3ws.setter
    def transformer_3ws(self, arg1: list[Transformer3W]) -> None:
        ...
    @property
    def transformer_types(self) -> list[...]:
        """
        Sequence of TransformerType objects.
        """
    @transformer_types.setter
    def transformer_types(self, arg1: list[...]) -> None:
        ...
    @property
    def transformers(self) -> list[Transformer2W]:
        """
        Sequence of Transformer objects.
        """
    @transformers.setter
    def transformers(self, arg1: list[Transformer2W]) -> None:
        ...
    @property
    def underground_line_types(self) -> list[UndergroundLineType]:
        """
        Sequence of UndergroundLineType objects.
        """
    @underground_line_types.setter
    def underground_line_types(self, arg1: list[UndergroundLineType]) -> None:
        ...
    @property
    def upfcs(self) -> list[Upfc]:
        """
        Sequence of Upfc objects.
        """
    @upfcs.setter
    def upfcs(self, arg1: list[Upfc]) -> None:
        ...
    @property
    def voltage_levels(self) -> list[VoltageLevel]:
        """
        Sequence of VoltageLevel objects.
        """
    @voltage_levels.setter
    def voltage_levels(self, arg1: list[VoltageLevel]) -> None:
        ...
    @property
    def vscs(self) -> list[Vsc]:
        """
        Sequence of Vsc objects.
        """
    @vscs.setter
    def vscs(self, arg1: list[Vsc]) -> None:
        ...
    @property
    def windings(self) -> list[Winding]:
        """
        Sequence of Winding objects.
        """
    @windings.setter
    def windings(self, arg1: list[Winding]) -> None:
        ...
    @property
    def wires(self) -> list[Wire]:
        """
        Sequence of Wire objects.
        """
    @wires.setter
    def wires(self, arg1: list[Wire]) -> None:
        ...
    @property
    def zones(self) -> list[Zone]:
        """
        Sequence of Zone objects.
        """
    @zones.setter
    def zones(self, arg1: list[Zone]) -> None:
        ...
class Association:
    __hash__: typing.ClassVar[None] = None
    def __eq__(self, arg0: Association) -> bool:
        """
        Equality operator for Association.
        
        :param other: The other Association object.
        :return: True if equal, False otherwise.
        """
    def __init__(self, api_obj: ... | ... | ..., value: float) -> None:
        """
        Constructor for Association.
        
        :param api_obj: API object pointer (Fuel, Technology, or EmissionGas)
        :param value: Association value
        """
    def get_api_object_idtag(self) -> str:
        """
        Get the ID tag of the API object.
        
        :return: The ID tag as a string.
        """
    @property
    def api_object(self) -> ... | ... | ...:
        """
        The API object (FuelPtr, TechnologyPtr, or EmissionGasPtr).
        
        :getter: Get the API object.
        :setter: Set the API object.
        """
    @api_object.setter
    def api_object(self, arg1: ... | ... | ...) -> None:
        ...
    @property
    def value(self) -> float:
        """
        The association value.
        
        :getter: Get the association value.
        :setter: Set the association value.
        """
    @value.setter
    def value(self, arg1: float) -> None:
        ...
class Associations:
    def __init__(self, dtype: DeviceType) -> None:
        """
        Constructor for Associations.
        
        :param dtype: The device type associated with these associations.
        """
    def add(self, val: Association) -> None:
        """
        Add an Association to the collection.
        
        :param val: The Association to add.
        """
    def add_object(self, api_obj: ... | ... | ..., val: float) -> None:
        """
        Add an API object and its associated value.
        
        :param api_obj: The API object (Fuel, Technology, or EmissionGas).
        :param val: The value associated with the object.
        """
    def remove(self, val: Association) -> None:
        """
        Remove an Association from the collection.
        
        :param val: The Association to remove.
        """
    def remove_by_key(self, val: str) -> None:
        """
        Remove an Association by its key.
        
        :param val: The key of the Association to remove.
        """
class AvailableTransferMode:
    """
    Members:
    
      Generation
    
      InstalledPower
    
      Load
    
      GenerationAndLoad
    """
    Generation: typing.ClassVar[AvailableTransferMode]  # value = <AvailableTransferMode.Generation: 0>
    GenerationAndLoad: typing.ClassVar[AvailableTransferMode]  # value = <AvailableTransferMode.GenerationAndLoad: 3>
    InstalledPower: typing.ClassVar[AvailableTransferMode]  # value = <AvailableTransferMode.InstalledPower: 1>
    Load: typing.ClassVar[AvailableTransferMode]  # value = <AvailableTransferMode.Load: 2>
    __members__: typing.ClassVar[dict[str, AvailableTransferMode]]  # value = {'Generation': <AvailableTransferMode.Generation: 0>, 'InstalledPower': <AvailableTransferMode.InstalledPower: 1>, 'Load': <AvailableTransferMode.Load: 2>, 'GenerationAndLoad': <AvailableTransferMode.GenerationAndLoad: 3>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Battery(Generator):
    def __init__(self, nt: int, bus: Bus = None, name: str = 'batt', idtag: str = '', code: str = '', P: float = 0.0, power_factor: float = 0.8, vset: float = 1.0, is_controlled: bool = True, Qmin: float = -9999.0, Qmax: float = 9999.0, Snom: float = 9999.0, Enom: float = 9999.0, Pmin: float = -9999.0, Pmax: float = 9999.0, Cost: float = 1.0, active: bool = True, Sbase: float = 100.0, enabled_dispatch: bool = True, mttf: float = 0.0, mttr: float = 0.0, charge_efficiency: float = 0.9, discharge_efficiency: float = 0.9, max_soc: float = 0.99, min_soc: float = 0.3, soc: float = 0.8, charge_per_cycle: float = 0.1, discharge_per_cycle: float = 0.1, r1: float = 1e-20, x1: float = 1e-20, r0: float = 1e-20, x0: float = 1e-20, r2: float = 1e-20, x2: float = 1e-20, capex: float = 0.0, opex: float = 0.0, srap_enabled: bool = True, build_status: BuildStatus = ...) -> None:
        """
        Constructor for Battery.
        
        :param nt: Number of simulation timesteps.
        :param bus: Pointer to the connected AC bus (may be *None*).
        :param name/idtag/code: Human-readable name and identifiers.
        :param P / power_factor / vset: Initial active-power set-point (MW), power factor, and voltage set-point (pu).
        :param is_controlled: If *true*, battery controls voltage/reactive power.
        :param Qmin/Qmax: Reactive-power capability limits (MVAr).
        :param Snom/Enom: Apparent-power rating (MVA) and nominal energy (MWh).
        :param Pmin/Pmax: Dispatchable active-power limits (MW; negative = charge).
        :param Cost: Linear production/consumption cost coefficient.
        :param active: Whether the battery is in-service in the base case.
        :param Sbase: System base power for per-unit calculations (MVA).
        :param enabled_dispatch: Allow optimisation to dispatch the unit.
        :param mttf/mttr: Mean time to failure / repair (h).
        :param charge_efficiency / discharge_efficiency: Round-trip efficiencies (0-1).
        :param max_soc / min_soc: Maximum and minimum state-of-charge (0-1).
        :param soc: Initial state-of-charge (0-1).
        :param charge_per_cycle / discharge_per_cycle: Allowed energy per charge/discharge cycle (pu of Enom).
        :param r1/x1, r0/x0, r2/x2: Sequence impedances for fault studies (pu).
        :param capex/opex: Capital and annual operating expenditure (currency units).
        :param srap_enabled: Include unit in restoration/SRAP studies.
        :param build_status: Construction / service status enumeration.
        """
    @property
    def Enom(self) -> float:
        """
        Nominal energy in MWh.
        """
    @Enom.setter
    def Enom(self, arg1: float) -> None:
        ...
    @property
    def avg_efficiency(self) -> float:
        """
        Average efficiency of the battery.
        """
    @property
    def charge_efficiency(self) -> float:
        """
        Charging efficiency.
        """
    @charge_efficiency.setter
    def charge_efficiency(self, arg1: float) -> None:
        ...
    @property
    def charge_per_cycle(self) -> float:
        """
        Charge per cycle.
        """
    @charge_per_cycle.setter
    def charge_per_cycle(self, arg1: float) -> None:
        ...
    @property
    def device_type(self) -> DeviceType:
        """
        Device type of the battery.
        """
    @device_type.setter
    def device_type(self, arg1: DeviceType) -> None:
        ...
    @property
    def discharge_efficiency(self) -> float:
        """
        Discharging efficiency.
        """
    @discharge_efficiency.setter
    def discharge_efficiency(self, arg1: float) -> None:
        ...
    @property
    def discharge_per_cycle(self) -> float:
        """
        Discharge per cycle.
        """
    @discharge_per_cycle.setter
    def discharge_per_cycle(self, arg1: float) -> None:
        ...
    @property
    def energy(self) -> float:
        """
        Current energy in MWh.
        """
    @energy.setter
    def energy(self, arg1: float) -> None:
        ...
    @property
    def max_soc(self) -> float:
        """
        Maximum state of charge.
        """
    @max_soc.setter
    def max_soc(self, arg1: float) -> None:
        ...
    @property
    def min_energy(self) -> float:
        """
        Minimum energy in MWh.
        """
    @min_energy.setter
    def min_energy(self, arg1: float) -> None:
        ...
    @property
    def min_soc(self) -> float:
        """
        Minimum state of charge.
        """
    @min_soc.setter
    def min_soc(self, arg1: float) -> None:
        ...
    @property
    def min_soc_charge(self) -> float:
        """
        Minimum state of charge for charging.
        """
    @min_soc_charge.setter
    def min_soc_charge(self, arg1: float) -> None:
        ...
    @property
    def soc(self) -> float:
        """
        Current state of charge.
        """
    @soc.setter
    def soc(self, arg1: float) -> None:
        ...
    @property
    def soc_0(self) -> float:
        """
        Initial state of charge.
        """
    @soc_0.setter
    def soc_0(self, arg1: float) -> None:
        ...
class BatteryData(GeneratorData):
    charge_efficiency: Numpy.ndarray[]
    discharge_efficiency: Numpy.ndarray[]
    e_max: Numpy.ndarray[]
    e_min: Numpy.ndarray[]
    efficiency: Numpy.ndarray[]
    enom: Numpy.ndarray[]
    max_soc: Numpy.ndarray[]
    min_soc: Numpy.ndarray[]
    soc_0: Numpy.ndarray[]
    def __init__(self, arg0: int, arg1: int) -> None:
        ...
class BranchGroup(EditableDevice):
    def __init__(self, name: str = '', idtag: str = '', code: str = '', group_type: BranchGroupTypes = ...) -> None:
        """
        Constructor for BranchGroup.
        
        :param name: Name of the branch group
        :param idtag: ID tag
        :param code: Code
        :param group_type: Branch group type
        """
    @property
    def group_type(self) -> BranchGroupTypes:
        """
        Branch group type.
        
        :getter: Get the branch group type.
        :setter: Set the branch group type.
        """
    @group_type.setter
    def group_type(self, arg1: BranchGroupTypes) -> None:
        ...
class BranchGroupTypes:
    """
    Members:
    
      LineSegmentsGroup
    
      TransformerGroup
    
      GenericGroup
    """
    GenericGroup: typing.ClassVar[BranchGroupTypes]  # value = <BranchGroupTypes.GenericGroup: 2>
    LineSegmentsGroup: typing.ClassVar[BranchGroupTypes]  # value = <BranchGroupTypes.LineSegmentsGroup: 0>
    TransformerGroup: typing.ClassVar[BranchGroupTypes]  # value = <BranchGroupTypes.TransformerGroup: 1>
    __members__: typing.ClassVar[dict[str, BranchGroupTypes]]  # value = {'LineSegmentsGroup': <BranchGroupTypes.LineSegmentsGroup: 0>, 'TransformerGroup': <BranchGroupTypes.TransformerGroup: 1>, 'GenericGroup': <BranchGroupTypes.GenericGroup: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class BranchImpedanceMode:
    """
    Members:
    
      Specified
    
      Upper
    
      Lower
    """
    Lower: typing.ClassVar[BranchImpedanceMode]  # value = <BranchImpedanceMode.Lower: 2>
    Specified: typing.ClassVar[BranchImpedanceMode]  # value = <BranchImpedanceMode.Specified: 0>
    Upper: typing.ClassVar[BranchImpedanceMode]  # value = <BranchImpedanceMode.Upper: 1>
    __members__: typing.ClassVar[dict[str, BranchImpedanceMode]]  # value = {'Specified': <BranchImpedanceMode.Specified: 0>, 'Upper': <BranchImpedanceMode.Upper: 1>, 'Lower': <BranchImpedanceMode.Lower: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class BranchParent(PhysicalDevice):
    def __init__(self, nt: int, name: str, idtag: str, code: str, bus_from_default: ..., bus_to_default: ..., active_default: bool, reducible_default: bool, rate_default: float, contingency_factor: float, protection_rating_factor: float, monitor_loading: bool, mttf: float, mttr: float, build_status: BuildStatus, capex: float, opex: float, cost_default: float, device_type: DeviceType) -> None:
        """
        Constructor for BranchParent.
        
        :param nt: Number of timesteps
        :param name: Name of the branch
        :param idtag: ID tag for the branch
        :param code: Code for the branch
        :param bus_from_default: Default 'from' bus
        :param bus_to_default: Default 'to' bus
        :param active_default: Default active state
        :param reducible_default: Default reducibility
        :param rate_default: Default rate
        :param contingency_factor: Contingency factor
        :param protection_rating_factor: Protection rating factor
        :param contingency_enabled: Whether contingency is enabled
        :param monitor_loading: Whether to monitor loading
        :param mttf: Mean time to failure
        :param mttr: Mean time to repair
        :param build_status: Build status
        :param capex: Capital expenditure
        :param opex: Operational expenditure
        :param cost_default: Default cost
        :param device_type: Device type
        """
    def get_virtual_taps(self) -> tuple[float, float]:
        """
        Get the virtual taps for the branch.
        """
    def has_bus_from(self) -> bool:
        """
        Check if the 'from' bus is set.
        """
    def has_bus_to(self) -> bool:
        """
        Check if the 'to' bus is set.
        """
    @property
    def active(self) -> Profilebool:
        """
        The active profile of the branch.
        """
    @active.setter
    def active(self, arg1: Profilebool) -> None:
        ...
    @property
    def build_status(self) -> BuildStatus:
        """
        Build status of the branch.
        """
    @build_status.setter
    def build_status(self, arg1: BuildStatus) -> None:
        ...
    @property
    def bus_from(self) -> ...:
        """
        The 'from' bus connection.
        """
    @bus_from.setter
    def bus_from(self, arg1: ...) -> None:
        ...
    @property
    def bus_to(self) -> ...:
        """
        The 'to' bus connection.
        """
    @bus_to.setter
    def bus_to(self, arg1: ...) -> None:
        ...
    @property
    def capex(self) -> float:
        """
        Capital expenditure.
        """
    @capex.setter
    def capex(self, arg1: float) -> None:
        ...
    @property
    def contingency_factor(self) -> Profiledouble:
        """
        Contingency factor profile.
        """
    @contingency_factor.setter
    def contingency_factor(self, arg1: Profiledouble) -> None:
        ...
    @property
    def cost(self) -> Profiledouble:
        """
        The cost profile of the branch.
        """
    @cost.setter
    def cost(self, arg1: Profiledouble) -> None:
        ...
    @property
    def group(self) -> ...:
        """
        The branch group.
        """
    @group.setter
    def group(self, arg1: ...) -> None:
        ...
    @property
    def monitor_loading(self) -> Profilebool:
        """
        Loading monitoring status.
        """
    @monitor_loading.setter
    def monitor_loading(self, arg1: Profilebool) -> None:
        ...
    @property
    def mttf(self) -> float:
        """
        Mean time to failure.
        """
    @mttf.setter
    def mttf(self, arg1: float) -> None:
        ...
    @property
    def mttr(self) -> float:
        """
        Mean time to repair.
        """
    @mttr.setter
    def mttr(self, arg1: float) -> None:
        ...
    @property
    def opex(self) -> float:
        """
        Operational expenditure.
        """
    @opex.setter
    def opex(self, arg1: float) -> None:
        ...
    @property
    def protection_rating_factor(self) -> Profiledouble:
        """
        Protection rating factor profile.
        """
    @protection_rating_factor.setter
    def protection_rating_factor(self, arg1: Profiledouble) -> None:
        ...
    @property
    def rate(self) -> Profiledouble:
        """
        The rate profile of the branch.
        """
    @rate.setter
    def rate(self, arg1: Profiledouble) -> None:
        ...
    @property
    def reducible(self) -> bool:
        """
        Reducibility status of the branch.
        """
    @reducible.setter
    def reducible(self, arg1: bool) -> None:
        ...
class BranchParentData:
    F: Numpy.ndarray[]
    T: Numpy.ndarray[]
    active: Numpy.ndarray[]
    contingency_rates: Numpy.ndarray[]
    dc: Numpy.ndarray[]
    idtag: list[str]
    monitor_loading: Numpy.ndarray[]
    mttf: Numpy.ndarray[]
    mttr: Numpy.ndarray[]
    names: list[str]
    nbus: int
    nelm: int
    original_idx: Numpy.ndarray[]
    overload_cost: Numpy.ndarray[]
    protection_rates: Numpy.ndarray[]
    rates: Numpy.ndarray[]
    def __init__(self, arg0: int, arg1: int) -> None:
        ...
    @property
    def C_branch_bus_f(self) -> scipy.sparse.csc_matrix:
        ...
    @C_branch_bus_f.setter
    def C_branch_bus_f(self, arg1: int, arg2: int) -> None:
        ...
    @property
    def C_branch_bus_t(self) -> scipy.sparse.csc_matrix:
        ...
    @C_branch_bus_t.setter
    def C_branch_bus_t(self, arg1: int, arg2: int) -> None:
        ...
    @property
    def reducible(self, arg1: int) -> bool:
        ...
    @reducible.setter
    def reducible(self, arg1: list[bool]) -> None:
        ...
class BuildStatus:
    """
    Members:
    
      Commissioned
    
      Decommissioned
    
      Planned
    
      Candidate
    
      PlannedDecommission
    """
    Candidate: typing.ClassVar[BuildStatus]  # value = <BuildStatus.Candidate: 3>
    Commissioned: typing.ClassVar[BuildStatus]  # value = <BuildStatus.Commissioned: 0>
    Decommissioned: typing.ClassVar[BuildStatus]  # value = <BuildStatus.Decommissioned: 1>
    Planned: typing.ClassVar[BuildStatus]  # value = <BuildStatus.Planned: 2>
    PlannedDecommission: typing.ClassVar[BuildStatus]  # value = <BuildStatus.PlannedDecommission: 4>
    __members__: typing.ClassVar[dict[str, BuildStatus]]  # value = {'Commissioned': <BuildStatus.Commissioned: 0>, 'Decommissioned': <BuildStatus.Decommissioned: 1>, 'Planned': <BuildStatus.Planned: 2>, 'Candidate': <BuildStatus.Candidate: 3>, 'PlannedDecommission': <BuildStatus.PlannedDecommission: 4>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Bus(PhysicalDevice):
    def __init__(self, nt: int = 1, name: str = 'Bus', idtag: str = '', code: str = '', Vnom: float = 10.0, vmin: float = 0.9, vmax: float = 1.1, angle_min: float = -6.28, angle_max: float = 6.28, r_fault: float = 0.0, x_fault: float = 0.0, xpos: float = 0.0, ypos: float = 0.0, height: float = 0.0, width: float = 0.0, active_default: bool = True, is_slack: bool = False, is_dc: bool = False, is_internal: bool = False, area: Area = None, zone: Zone = None, substation: Substation = None, voltage_level: VoltageLevel = None, country: Country = None, longitude: float = 0.0, latitude: float = 0.0, Vm0: float = 1.0, Va0: float = 0.0) -> None:
        """
        Constructor for Bus.
        
        :param nt: Number of time steps
        :param name: Name of the bus
        :param idtag: ID tag for the bus
        :param code: Code for the bus
        :param Vnom: Nominal voltage
        :param vmin: Minimum voltage
        :param vmax: Maximum voltage
        :param angle_min: Minimum angle
        :param angle_max: Maximum angle
        :param r_fault: Fault resistance
        :param x_fault: Fault reactance
        :param xpos: X position
        :param ypos: Y position
        :param height: Height of the bus
        :param width: Width of the bus
        :param active_default: Default active state
        :param is_slack: Whether the bus is slack
        :param is_dc: Whether the bus is DC
        :param is_internal: Whether the bus is internal
        :param area: Associated area
        :param zone: Associated zone
        :param substation: Associated substation
        :param voltage_level: Associated voltage level
        :param country: Associated country
        :param longitude: Longitude
        :param latitude: Latitude
        :param Vm0: Initial voltage magnitude
        :param Va0: Initial voltage angle
        """
    def get_voltage_guess(self, use_stored_guess: bool = False) -> complex:
        """
        Get the voltage guess.
        
        :param use_stored_guess: Whether to use the stored guess.
        :return: Complex voltage guess.
        """
    def set_active_val(self, arg0: bool) -> None:
        """
        set all the active profile values
        """
    @property
    def Qmax_sum(self) -> float:
        """
        Sum of maximum reactive power.
        """
    @Qmax_sum.setter
    def Qmax_sum(self, arg1: float) -> None:
        ...
    @property
    def Qmin_sum(self) -> float:
        """
        Sum of minimum reactive power.
        """
    @Qmin_sum.setter
    def Qmin_sum(self, arg1: float) -> None:
        ...
    @property
    def Va0(self) -> float:
        """
        Initial voltage angle.
        """
    @Va0.setter
    def Va0(self, arg1: float) -> None:
        ...
    @property
    def Vm0(self) -> float:
        """
        Initial voltage magnitude.
        """
    @Vm0.setter
    def Vm0(self, arg1: float) -> None:
        ...
    @property
    def Vnom(self) -> float:
        """
        Nominal voltage.
        """
    @Vnom.setter
    def Vnom(self, arg1: float) -> None:
        ...
    @property
    def active(self) -> Profilebool:
        """
        Active state.
        """
    @active.setter
    def active(self, arg1: Profilebool) -> None:
        ...
    @property
    def angle_cost(self) -> float:
        """
        Cost of angle deviation.
        """
    @angle_cost.setter
    def angle_cost(self, arg1: float) -> None:
        ...
    @property
    def angle_max(self) -> float:
        """
        Maximum angle.
        """
    @angle_max.setter
    def angle_max(self, arg1: float) -> None:
        ...
    @property
    def angle_min(self) -> float:
        """
        Minimum angle.
        """
    @angle_min.setter
    def angle_min(self, arg1: float) -> None:
        ...
    @property
    def area(self) -> Area:
        """
        Associated area.
        """
    @area.setter
    def area(self, arg1: Area) -> None:
        ...
    @property
    def country(self) -> Country:
        """
        Associated country.
        """
    @country.setter
    def country(self, arg1: Country) -> None:
        ...
    @property
    def h(self) -> float:
        """
        Height of the bus.
        """
    @h.setter
    def h(self, arg1: float) -> None:
        ...
    @property
    def is_dc(self) -> bool:
        """
        Whether the bus is DC.
        """
    @is_dc.setter
    def is_dc(self, arg1: bool) -> None:
        ...
    @property
    def is_internal(self) -> bool:
        """
        Whether the bus is internal.
        """
    @is_internal.setter
    def is_internal(self, arg1: bool) -> None:
        ...
    @property
    def is_slack(self) -> bool:
        """
        Whether the bus is a slack bus.
        """
    @is_slack.setter
    def is_slack(self, arg1: bool) -> None:
        ...
    @property
    def latitude(self) -> float:
        """
        Latitude of the bus.
        """
    @latitude.setter
    def latitude(self, arg1: float) -> None:
        ...
    @property
    def longitude(self) -> float:
        """
        Longitude of the bus.
        """
    @longitude.setter
    def longitude(self, arg1: float) -> None:
        ...
    @property
    def r_fault(self) -> float:
        """
        Fault resistance.
        """
    @r_fault.setter
    def r_fault(self, arg1: float) -> None:
        ...
    @property
    def substation(self) -> Substation:
        """
        Associated substation.
        """
    @substation.setter
    def substation(self, arg1: Substation) -> None:
        ...
    @property
    def type(self) -> BusMode:
        """
        Bus type.
        """
    @type.setter
    def type(self, arg1: BusMode) -> None:
        ...
    @property
    def vmax(self) -> float:
        """
        Maximum voltage.
        """
    @vmax.setter
    def vmax(self, arg1: float) -> None:
        ...
    @property
    def vmin(self) -> float:
        """
        Minimum voltage.
        """
    @vmin.setter
    def vmin(self, arg1: float) -> None:
        ...
    @property
    def voltage_level(self) -> VoltageLevel:
        """
        Associated voltage level.
        """
    @voltage_level.setter
    def voltage_level(self, arg1: VoltageLevel) -> None:
        ...
    @property
    def w(self) -> float:
        """
        Width of the bus.
        """
    @w.setter
    def w(self, arg1: float) -> None:
        ...
    @property
    def x(self) -> float:
        """
        X position.
        """
    @x.setter
    def x(self, arg1: float) -> None:
        ...
    @property
    def x_fault(self) -> float:
        """
        Fault reactance.
        """
    @x_fault.setter
    def x_fault(self, arg1: float) -> None:
        ...
    @property
    def y(self) -> float:
        """
        Y position.
        """
    @y.setter
    def y(self, arg1: float) -> None:
        ...
    @property
    def zone(self) -> Zone:
        """
        Associated zone.
        """
    @zone.setter
    def zone(self, arg1: Zone) -> None:
        ...
class BusData:
    Vbus: Numpy.ndarray[]
    Vmax: Numpy.ndarray[]
    Vmin: Numpy.ndarray[]
    Vnom: Numpy.ndarray[]
    active: Numpy.ndarray[]
    angle_max: Numpy.ndarray[]
    angle_min: Numpy.ndarray[]
    areas: Numpy.ndarray[]
    b_fixed: Numpy.ndarray[]
    bus_types: list[BusMode]
    cost_v: Numpy.ndarray[]
    idtag: list[str]
    ii_fixed: Numpy.ndarray[]
    installed_power: Numpy.ndarray[]
    is_dc: Numpy.ndarray[]
    is_p_controlled: list[bool]
    is_q_controlled: list[bool]
    is_va_controlled: list[bool]
    is_vm_controlled: list[bool]
    names: list[str]
    nbus: int
    original_idx: Numpy.ndarray[]
    q_fixed: Numpy.ndarray[]
    q_shared_total: Numpy.ndarray[]
    srap_available_power: Numpy.ndarray[]
    substations: Numpy.ndarray[]
    def __init__(self, arg0: int) -> None:
        ...
class BusMode:
    """
    Members:
    
      PQ
    
      PV
    
      Slack
    
      PQV
    
      P
    """
    P: typing.ClassVar[BusMode]  # value = <BusMode.P: 5>
    PQ: typing.ClassVar[BusMode]  # value = <BusMode.PQ: 1>
    PQV: typing.ClassVar[BusMode]  # value = <BusMode.PQV: 4>
    PV: typing.ClassVar[BusMode]  # value = <BusMode.PV: 2>
    Slack: typing.ClassVar[BusMode]  # value = <BusMode.Slack: 3>
    __members__: typing.ClassVar[dict[str, BusMode]]  # value = {'PQ': <BusMode.PQ: 1>, 'PV': <BusMode.PV: 2>, 'Slack': <BusMode.Slack: 3>, 'PQV': <BusMode.PQV: 4>, 'P': <BusMode.P: 5>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class ClusteringResults:
    def __init__(self, time_array: list[int], time_indices: Numpy.ndarray[], original_sample_idx: Numpy.ndarray[], sampled_probabilities: Numpy.ndarray[]) -> None:
        ...
    @property
    def original_sample_idx(self) -> Numpy.ndarray[]:
        ...
    @property
    def sampled_probabilities(self) -> Numpy.ndarray[]:
        ...
    @property
    def time_array(self) -> list[int]:
        ...
    @property
    def time_indices(self) -> Numpy.ndarray[]:
        ...
class Community(GenericAreaGroup):
    def __init__(self, name: str = '', idtag: str = '', code: str = '') -> None:
        """
        Constructor for Community.
        
        :param name: Name of the community
        :param idtag: ID tag
        :param code: Code for the community.
        """
class ConnectivityMatrices:
    def __init__(self, Cf: scipy.sparse.csc_matrix, Ct: scipy.sparse.csc_matrix, branch_active: Numpy.ndarray[]) -> None:
        ...
    @property
    def Cf(self) -> scipy.sparse.csc_matrix:
        ...
    @property
    def Ct(self) -> scipy.sparse.csc_matrix:
        ...
class Const(Expr):
    def __init__(self, value: float) -> None:
        ...
    @property
    def value(self) -> float:
        ...
class Contingency(EditableDevice):
    def __init__(self, idtag: str = '', device_idtag: str = '', name: str = '', code: str = '', prop: ContingencyOperationTypes = ..., value: float = 0.0, group: ContingencyGroup = None) -> None:
        """
        Constructor for Contingency.
        
        :param idtag: Contingency ID tag
        :param device_idtag: Device ID tag
        :param name: Name of the contingency
        :param code: Code of the contingency
        :param prop: Contingency operation type
        :param value: Associated value for the contingency
        :param group: Contingency group pointer
        """
    @property
    def device_idtag(self) -> str:
        """
        Device ID tag associated with the contingency.
        
        :getter: Get the device ID tag.
        :setter: Set the device ID tag.
        """
    @device_idtag.setter
    def device_idtag(self, arg1: str) -> None:
        ...
    @property
    def group(self) -> ContingencyGroup:
        """
        Contingency group pointer.
        
        :getter: Get the group pointer.
        :setter: Set the group pointer.
        """
    @group.setter
    def group(self, arg1: ContingencyGroup) -> None:
        ...
    @property
    def prop(self) -> ContingencyOperationTypes:
        """
        Property indicating the contingency operation type.
        
        :getter: Get the operation type.
        :setter: Set the operation type.
        """
    @prop.setter
    def prop(self, arg1: ContingencyOperationTypes) -> None:
        ...
    @property
    def value(self) -> float:
        """
        Value associated with the contingency.
        
        :getter: Get the value.
        :setter: Set the value.
        """
    @value.setter
    def value(self, arg1: float) -> None:
        ...
class ContingencyAnalysisOptions:
    Pf: Numpy.ndarray[] | None
    contingency_dead_band: float
    contingency_method: ContingencyMethod
    detailed_massive_report: bool
    lin_options: LinearAnalysisOptions
    pf_options: PowerFlowOptions
    srap_dead_band: float
    srap_max_power: float
    srap_rever_to_nominal_rating: bool
    srap_top_n: int
    use_provided_flows: bool
    use_srap: bool
    def __init__(self, use_provided_flows: bool = False, Pf: Numpy.ndarray[] | None = None, pf_options: PowerFlowOptions = ..., lin_options: LinearAnalysisOptions = ..., use_srap: bool = False, srap_max_power: float = 1400.0, srap_top_n: int = 5, srap_dead_band: float = 10.0, srap_rever_to_nominal_rating: bool = False, detailed_massive_report: bool = False, contingency_dead_band: float = 0.0, contingency_method: ContingencyMethod = ...) -> None:
        ...
class ContingencyAnalysisResults(ResultsTemplate):
    def __init__(self, nbus: int, nbr: int, nhvdc: int, nvsc: int, ngen: int, nbatt: int, nsh: int, time_array_: list[int], clustering_results_: ClusteringResults | None) -> None:
        ...
    @typing.overload
    def setContingency(self, results: ..., t_idx: int) -> None:
        ...
    @typing.overload
    def setContingency(self, Pf: Numpy.ndarray[], loading: Numpy.ndarray[], t_idx: int) -> None:
        ...
    @property
    def avg_values(self) -> PowerFlowResults:
        ...
    @property
    def br_overload_count(self) -> Numpy.ndarray[]:
        ...
    @property
    def max_values(self) -> PowerFlowResults:
        ...
    @property
    def min_values(self) -> PowerFlowResults:
        ...
    @property
    def std_values(self) -> PowerFlowResults:
        ...
class ContingencyFilteringMethods:
    """
    Members:
    
      All
    
      Country
    
      Zone
    
      Area
    """
    All: typing.ClassVar[ContingencyFilteringMethods]  # value = <ContingencyFilteringMethods.All: 0>
    Area: typing.ClassVar[ContingencyFilteringMethods]  # value = <ContingencyFilteringMethods.Area: 3>
    Country: typing.ClassVar[ContingencyFilteringMethods]  # value = <ContingencyFilteringMethods.Country: 1>
    Zone: typing.ClassVar[ContingencyFilteringMethods]  # value = <ContingencyFilteringMethods.Zone: 2>
    __members__: typing.ClassVar[dict[str, ContingencyFilteringMethods]]  # value = {'All': <ContingencyFilteringMethods.All: 0>, 'Country': <ContingencyFilteringMethods.Country: 1>, 'Zone': <ContingencyFilteringMethods.Zone: 2>, 'Area': <ContingencyFilteringMethods.Area: 3>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class ContingencyGroup(EditableDevice):
    def __init__(self, name: str = '', idtag: str = '', code: str = '', category: str = '') -> None:
        """
        Constructor for ContingencyGroup.
        
        :param name: Name of the contingency group
        :param idtag: ID tag for the group
        :param code: Code for the group
        :param category: Category of the contingency group
        """
    @property
    def category(self) -> str:
        """
        Category of the contingency group.
        
        :getter: Get the category.
        :setter: Set the category.
        """
    @category.setter
    def category(self, arg1: str) -> None:
        ...
class ContingencyIndices:
    branch_contingency_indices: Numpy.ndarray[]
    bus_contingency_indices: Numpy.ndarray[]
    injections_factors: Numpy.ndarray[]
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, contingencies: list[Contingency], branches_dict: dict[str, int], generator_bus_idx_dict: dict[str, int]) -> None:
        ...
class ContingencyMethod:
    """
    Members:
    
      PowerFlow
    
      OptimalPowerFlow
    
      HELM
    
      PTDF
    """
    HELM: typing.ClassVar[ContingencyMethod]  # value = <ContingencyMethod.HELM: 2>
    OptimalPowerFlow: typing.ClassVar[ContingencyMethod]  # value = <ContingencyMethod.OptimalPowerFlow: 1>
    PTDF: typing.ClassVar[ContingencyMethod]  # value = <ContingencyMethod.PTDF: 3>
    PowerFlow: typing.ClassVar[ContingencyMethod]  # value = <ContingencyMethod.PowerFlow: 0>
    __members__: typing.ClassVar[dict[str, ContingencyMethod]]  # value = {'PowerFlow': <ContingencyMethod.PowerFlow: 0>, 'OptimalPowerFlow': <ContingencyMethod.OptimalPowerFlow: 1>, 'HELM': <ContingencyMethod.HELM: 2>, 'PTDF': <ContingencyMethod.PTDF: 3>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class ContingencyOperationTypes:
    """
    Members:
    
      Active
    
      PowerPercentage
    """
    Active: typing.ClassVar[ContingencyOperationTypes]  # value = <ContingencyOperationTypes.Active: 0>
    PowerPercentage: typing.ClassVar[ContingencyOperationTypes]  # value = <ContingencyOperationTypes.PowerPercentage: 1>
    __members__: typing.ClassVar[dict[str, ContingencyOperationTypes]]  # value = {'Active': <ContingencyOperationTypes.Active: 0>, 'PowerPercentage': <ContingencyOperationTypes.PowerPercentage: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class ControllableBranchParent(BranchParent):
    def __init__(self, nt: int, name: str, idtag: str, code: str, bus_from: ..., bus_to: ..., active: bool, reducible: bool, rate: float, r: float, x: float, g: float, b: float, tap_module: float, tap_module_max: float, tap_module_min: float, tap_phase: float, tap_phase_max: float, tap_phase_min: float, tolerance: float, vset: float, Pset: float, Qset: float, regulation_branch: BranchParent, regulation_bus: ..., temp_base: float, temp_oper: float, alpha: float, tap_module_control_mode: TapModuleControl, tap_phase_control_mode: TapPhaseControl, contingency_factor: float, protection_rating_factor: float, monitor_loading: bool, r0: float, x0: float, g0: float, b0: float, r2: float, x2: float, g2: float, b2: float, Cost: float, mttf: float, mttr: float, capex: float, opex: float, build_status: BuildStatus, device_type: DeviceType, tc_total_positions: int = 5, tc_neutral_position: int = 2, tc_normal_position: int = 2, tc_dV: float = 0.01, tc_asymmetry_angle: float = 90.0, tc_type: TapChangerTypes = ...) -> None:
        """
        Constructor for ControllableBranchParent.
        
        :param nt: Number of simulation timesteps.
        :param name: Human-readable branch name.
        :param idtag: Stable unique identifier.
        :param code: Short engineering code or label.
        :param bus_from: Pointer to the *from* bus.
        :param bus_to: Pointer to the *to* bus.
        :param active: Initial active state profile.
        :param reducible: Whether the branch may be reduced in equivalents.
        :param rate: Thermal rating (A or MVA, depending on context).
        :param r: Positive-sequence series resistance **R**.
        :param x: Positive-sequence series reactance **X**.
        :param g: Positive-sequence shunt conductance **G/2**.
        :param b: Positive-sequence shunt susceptance **B/2**.
        :param tap_module: Initial tap magnitude (per-unit).
        :param tap_module_max: Maximum allowable tap magnitude.
        :param tap_module_min: Minimum allowable tap magnitude.
        :param tap_phase: Initial tap phase shift (deg).
        :param tap_phase_max: Maximum phase shift (deg).
        :param tap_phase_min: Minimum phase shift (deg).
        :param tolerance: Power-flow convergence tolerance (pu).
        :param vset: Voltage set-point for regulation (pu).
        :param Pset: Active-power set-point (MW).
        :param Qset: Reactive-power set-point (MVAr).
        :param regulation_branch: Pointer to branch used as regulating device.
        :param regulation_bus: Pointer to remote regulated bus.
        :param temp_base: Reference temperature (°C) for *R* values.
        :param temp_oper: Current operating temperature profile (°C).
        :param alpha: Temperature coefficient of resistance (1/°C).
        :param tap_module_control_mode: Control mode for tap magnitude.
        :param tap_phase_control_mode: Control mode for tap phase.
        :param contingency_factor: Multiplicative contingency rating factor.
        :param protection_rating_factor: Protection-based rating factor.
        :param monitor_loading: Enable automatic loading alarms.
        :param r0: Zero-sequence resistance **R₀**.
        :param x0: Zero-sequence reactance **X₀**.
        :param g0: Zero-sequence conductance **G₀/2**.
        :param b0: Zero-sequence susceptance **B₀/2**.
        :param r2: Negative-sequence resistance **R₂**.
        :param x2: Negative-sequence reactance **X₂**.
        :param g2: Negative-sequence conductance **G₂/2**.
        :param b2: Negative-sequence susceptance **B₂/2**.
        :param Cost: Operational cost per unit energy or time.
        :param mttf: Mean time to failure (h).
        :param mttr: Mean time to repair (h).
        :param capex: Capital expenditure (currency units).
        :param opex: Annual operating expenditure (currency units).
        :param build_status: Planned, under-construction, or in-service.
        :param device_type: Technology / device taxonomy code.
        :param tc_total_positions: Total tap-changer positions (default 5).
        :param tc_neutral_position: Neutral (0 pu) position index (default 2).
        :param tc_normal_position: Normal operating position index (default 2).
        :param tc_dV: Voltage step per tap position (pu).
        :param tc_asymmetry_angle: Phase-asymmetry angle between tap limbs (deg).
        :param tc_type: Tap-changer type (e.g. on-load, off-load).
        """
    @property
    def B(self) -> float:
        """
        Positive-sequence susceptance **p.u.**.
        """
    @B.setter
    def B(self, arg1: float) -> None:
        ...
    @property
    def B0(self) -> float:
        """
        Zero-sequence susceptance **p.u.**.
        """
    @B0.setter
    def B0(self, arg1: float) -> None:
        ...
    @property
    def B2(self) -> float:
        """
        Negative-sequence susceptance **p.u.**.
        """
    @B2.setter
    def B2(self, arg1: float) -> None:
        ...
    @property
    def G(self) -> float:
        """
        Positive-sequence conductance **p.u.**.
        """
    @G.setter
    def G(self, arg1: float) -> None:
        ...
    @property
    def G0(self) -> float:
        """
        Zero-sequence conductance **p.u.**.
        """
    @G0.setter
    def G0(self, arg1: float) -> None:
        ...
    @property
    def G2(self) -> float:
        """
        Negative-sequence conductance **p.u.**.
        """
    @G2.setter
    def G2(self, arg1: float) -> None:
        ...
    @property
    def Pset(self) -> Profiledouble:
        """
        Active-power set-point profile (MW).
        """
    @Pset.setter
    def Pset(self, arg1: Profiledouble) -> None:
        ...
    @property
    def Qset(self) -> Profiledouble:
        """
        Reactive-power set-point profile (MVAr).
        """
    @Qset.setter
    def Qset(self, arg1: Profiledouble) -> None:
        ...
    @property
    def R(self) -> float:
        """
        Positive-sequence resistance **p.u.**.
        """
    @R.setter
    def R(self, arg1: float) -> None:
        ...
    @property
    def R0(self) -> float:
        """
        Zero-sequence resistance **p.u.**.
        """
    @R0.setter
    def R0(self, arg1: float) -> None:
        ...
    @property
    def R2(self) -> float:
        """
        Negative-sequence resistance **p.u.**.
        """
    @R2.setter
    def R2(self, arg1: float) -> None:
        ...
    @property
    def X(self) -> float:
        """
        Positive-sequence reactance **p.u.**.
        """
    @X.setter
    def X(self, arg1: float) -> None:
        ...
    @property
    def X0(self) -> float:
        """
        Zero-sequence reactance **p.u.**.
        """
    @X0.setter
    def X0(self, arg1: float) -> None:
        ...
    @property
    def X2(self) -> float:
        """
        Negative-sequence reactance **p.u.**.
        """
    @X2.setter
    def X2(self, arg1: float) -> None:
        ...
    @property
    def alpha(self) -> float:
        """
        Thermal coefficient of resistance.
        """
    @alpha.setter
    def alpha(self, arg1: float) -> None:
        ...
    @property
    def regulation_branch(self) -> BranchParent:
        """
        Pointer to regulating branch.
        """
    @regulation_branch.setter
    def regulation_branch(self, arg1: BranchParent) -> None:
        ...
    @property
    def regulation_bus(self) -> ...:
        """
        Pointer to regulated bus.
        """
    @regulation_bus.setter
    def regulation_bus(self, arg1: ...) -> None:
        ...
    @property
    def tap_changer(self) -> ...:
        """
        Embedded tap-changer object.
        """
    @tap_changer.setter
    def tap_changer(self, arg1: ...) -> None:
        ...
    @property
    def tap_module(self) -> Profiledouble:
        """
        Tap magnitude profile (pu).
        """
    @tap_module.setter
    def tap_module(self, arg1: Profiledouble) -> None:
        ...
    @property
    def tap_module_control_mode(self) -> ProfileTapModuleControl:
        """
        Tap-magnitude control mode.
        """
    @tap_module_control_mode.setter
    def tap_module_control_mode(self, arg1: ProfileTapModuleControl) -> None:
        ...
    @property
    def tap_module_max(self) -> float:
        """
        Maximum tap magnitude (pu).
        """
    @tap_module_max.setter
    def tap_module_max(self, arg1: float) -> None:
        ...
    @property
    def tap_module_min(self) -> float:
        """
        Minimum tap magnitude (pu).
        """
    @tap_module_min.setter
    def tap_module_min(self, arg1: float) -> None:
        ...
    @property
    def tap_phase(self) -> Profiledouble:
        """
        Tap phase profile (rad).
        """
    @tap_phase.setter
    def tap_phase(self, arg1: Profiledouble) -> None:
        ...
    @property
    def tap_phase_control_mode(self) -> ProfileTapPhaseControl:
        """
        Tap-phase control mode.
        """
    @tap_phase_control_mode.setter
    def tap_phase_control_mode(self, arg1: ProfileTapPhaseControl) -> None:
        ...
    @property
    def tap_phase_max(self) -> float:
        """
        Maximum phase shift (rad).
        """
    @tap_phase_max.setter
    def tap_phase_max(self, arg1: float) -> None:
        ...
    @property
    def tap_phase_min(self) -> float:
        """
        Minimum phase shift (rad).
        """
    @tap_phase_min.setter
    def tap_phase_min(self, arg1: float) -> None:
        ...
    @property
    def temp_base(self) -> float:
        """
        Base temperature (°C).
        """
    @temp_base.setter
    def temp_base(self, arg1: float) -> None:
        ...
    @property
    def temp_oper(self) -> Profiledouble:
        """
        Operating temperature profile (°C).
        """
    @temp_oper.setter
    def temp_oper(self, arg1: Profiledouble) -> None:
        ...
    @property
    def tolerance(self) -> float:
        """
        Tolerance value.
        """
    @tolerance.setter
    def tolerance(self, arg1: float) -> None:
        ...
    @property
    def vset(self) -> Profiledouble:
        """
        Voltage set-point profile (pu).
        """
    @vset.setter
    def vset(self, arg1: Profiledouble) -> None:
        ...
class ControllableShunt(ShuntParent):
    def __init__(self, nt: int, bus: Bus = None, name: str = 'Controllable Shunt', idtag: str = '', code: str = '', is_nonlinear: bool = False, number_of_steps: int = 1, step: int = 1, g_per_step: float = 0.0, b_per_step: float = 0.0, Cost: float = 1200.0, active: bool = True, G: float = 1e-20, B: float = 1e-20, G0: float = 1e-20, B0: float = 1e-20, vset: float = 1.0, mttf: float = 0.0, mttr: float = 0.0, capex: float = 0.0, opex: float = 0.0, is_controlled: bool = True, control_bus: Bus = None, build_status: BuildStatus = ...) -> None:
        """
        Constructor for ControllableShunt.
        
        :param nt: Number of simulation timesteps.
        :param bus: Pointer to the connected AC bus (may be *None*).
        :param name/idtag/code: Readable name and identifiers.
        :param is_nonlinear: If *true*, shunt has non-linear step behaviour.
        :param number_of_steps: Total discrete tap/step positions.
        :param step: Initial step index (1-based).
        :param g_per_step / b_per_step: Conductance / susceptance added **per step** (pu at rated voltage).
        :param Cost: Linear cost coefficient for reactive-power support.
        :param active: Whether the device is energised in the base case.
        :param G/B: Initial positive-sequence shunt conductance / susceptance (pu).
        :param G0/B0: Zero-sequence conductance / susceptance (pu).
        :param vset: Voltage set-point for control (pu).
        :param mttf/mttr: Mean time to failure / repair (h).
        :param capex/opex: Capital and annual operating expenditure.
        :param is_controlled: Enable automatic voltage control on *control_bus*.
        :param control_bus: Bus whose voltage is regulated (may equal *bus*).
        :param build_status: Construction / service status enumeration.
        """
    def get_bmax(self) -> float:
        """
        Get maximum susceptance.
        """
    def get_bmin(self) -> float:
        """
        Get minimum susceptance.
        """
    def set_control_bus_val(self, val: Bus) -> None:
        """
        Set control bus value.
        """
    def set_step_val(self, val: int) -> None:
        """
        Set step value.
        """
    def set_vset_val(self, val: float) -> None:
        """
        Set voltage setpoint value.
        """
    @property
    def b_steps(self) -> list[float]:
        """
        Susceptance steps.
        """
    @b_steps.setter
    def b_steps(self, arg1: list[float]) -> None:
        ...
    @property
    def control_bus(self) -> ProfileBus:
        """
        Control bus.
        """
    @control_bus.setter
    def control_bus(self, arg1: ProfileBus) -> None:
        ...
    @property
    def g_steps(self) -> list[float]:
        """
        Conductance steps.
        """
    @g_steps.setter
    def g_steps(self, arg1: list[float]) -> None:
        ...
    @property
    def is_controlled(self) -> bool:
        """
        Whether the shunt is controlled.
        """
    @is_controlled.setter
    def is_controlled(self, arg1: bool) -> None:
        ...
    @property
    def is_nonlinear(self) -> bool:
        """
        Whether the shunt is nonlinear.
        """
    @is_nonlinear.setter
    def is_nonlinear(self, arg1: bool) -> None:
        ...
    @property
    def step(self) -> ...:
        """
        Current step.
        """
    @step.setter
    def step(self, arg1: ...) -> None:
        ...
    @property
    def vset(self) -> Profiledouble:
        """
        Voltage setpoint.
        """
    @vset.setter
    def vset(self, arg1: Profiledouble) -> None:
        ...
class ConvergenceReport:
    @property
    def converged(self) -> list[bool]:
        ...
    @property
    def elapsed(self) -> list[float]:
        ...
    @property
    def error(self) -> list[float]:
        ...
    @property
    def iterations(self) -> list[int]:
        ...
    @property
    def methods(self) -> list[SolverType]:
        ...
class ConverterControlType:
    """
    Members:
    
      Vm_dc
    
      Vm_ac
    
      Va_ac
    
      Q_ac
    
      P_dc
    
      P_ac
    """
    P_ac: typing.ClassVar[ConverterControlType]  # value = <ConverterControlType.P_ac: 6>
    P_dc: typing.ClassVar[ConverterControlType]  # value = <ConverterControlType.P_dc: 5>
    Q_ac: typing.ClassVar[ConverterControlType]  # value = <ConverterControlType.Q_ac: 4>
    Va_ac: typing.ClassVar[ConverterControlType]  # value = <ConverterControlType.Va_ac: 3>
    Vm_ac: typing.ClassVar[ConverterControlType]  # value = <ConverterControlType.Vm_ac: 2>
    Vm_dc: typing.ClassVar[ConverterControlType]  # value = <ConverterControlType.Vm_dc: 1>
    __members__: typing.ClassVar[dict[str, ConverterControlType]]  # value = {'Vm_dc': <ConverterControlType.Vm_dc: 1>, 'Vm_ac': <ConverterControlType.Vm_ac: 2>, 'Va_ac': <ConverterControlType.Va_ac: 3>, 'Q_ac': <ConverterControlType.Q_ac: 4>, 'P_dc': <ConverterControlType.P_dc: 5>, 'P_ac': <ConverterControlType.P_ac: 6>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Country(GenericAreaGroup):
    def __init__(self, name: str = '', idtag: str = '', code: str = '') -> None:
        """
        Constructor for Country.
        
        :param name: Name of the country
        :param idtag: ID tag for the country
        :param code: Code for the country
        """
class CpfParametrization:
    """
    Members:
    
      Natural
    
      ArcLength
    
      PseudoArcLength
    """
    ArcLength: typing.ClassVar[CpfParametrization]  # value = <CpfParametrization.ArcLength: 1>
    Natural: typing.ClassVar[CpfParametrization]  # value = <CpfParametrization.Natural: 0>
    PseudoArcLength: typing.ClassVar[CpfParametrization]  # value = <CpfParametrization.PseudoArcLength: 2>
    __members__: typing.ClassVar[dict[str, CpfParametrization]]  # value = {'Natural': <CpfParametrization.Natural: 0>, 'ArcLength': <CpfParametrization.ArcLength: 1>, 'PseudoArcLength': <CpfParametrization.PseudoArcLength: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class CpfStopAt:
    """
    Members:
    
      Nose
    
      ExtraOverloads
    
      Full
    """
    ExtraOverloads: typing.ClassVar[CpfStopAt]  # value = <CpfStopAt.ExtraOverloads: 1>
    Full: typing.ClassVar[CpfStopAt]  # value = <CpfStopAt.Full: 2>
    Nose: typing.ClassVar[CpfStopAt]  # value = <CpfStopAt.Nose: 0>
    __members__: typing.ClassVar[dict[str, CpfStopAt]]  # value = {'Nose': <CpfStopAt.Nose: 0>, 'ExtraOverloads': <CpfStopAt.ExtraOverloads: 1>, 'Full': <CpfStopAt.Full: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class CurrentInjection(InjectionParent):
    def __init__(self, nt: int, bus: Bus = None, name: str = 'CurrentInjection', idtag: str = '', code: str = '', Ir: float = 0.0, Ii: float = 0.0, Cost: float = 1200.0, active: bool = True, mttf: float = 0.0, mttr: float = 0.0, capex: float = 0.0, opex: float = 0.0, build_status: BuildStatus = ...) -> None:
        """
        Constructor for CurrentInjection.
        
        :param nt: Number of simulation timesteps.
        :param bus: Pointer to the connected AC bus (*None* for unassigned).
        :param name/idtag/code: Readable name and identifiers.
        :param Ir/Ii: Initial real and imaginary current injections (pu).
        :param Cost: Linear cost coefficient for current injection.
        :param active: Whether the injection is enabled in the base case.
        :param mttf/mttr: Mean time to failure / repair (h).
        :param capex/opex: Capital and annual operating expenditure (currency units).
        :param build_status: Construction / service status enumeration.
        """
    def set_ii_val(self, val: float) -> None:
        """
        Set the imaginary current injection value.
        """
    def set_ir_val(self, val: float) -> None:
        """
        Set the real current injection value.
        """
    @property
    def Ii(self) -> Profiledouble:
        """
        Profile for imaginary current injection.
        """
    @Ii.setter
    def Ii(self, arg1: Profiledouble) -> None:
        ...
    @property
    def Ir(self) -> Profiledouble:
        """
        Profile for real current injection.
        """
    @Ir.setter
    def Ir(self, arg1: Profiledouble) -> None:
        ...
class DcLine(BranchParent):
    def __init__(self, nt: int, name: str = 'Dc Line', idtag: str = '', code: str = '', bus_from: Bus = None, bus_to: Bus = None, r: float = 1e-20, rate: float = 1.0, active: bool = True, tolerance: float = 0.0, cost: float = 0.0, mttf: float = 0.0, mttr: float = 0.0, r_fault: float = 0.0, fault_pos: float = 0.5, length: float = 1.0, temp_base: float = 20.0, temp_oper: float = 20.0, alpha: float = 0.0033, contingency_factor: float = 1.0, protection_rating_factor: float = 1.4, monitor_loading: bool = True, capex: float = 0.0, opex: float = 0.0, build_status: BuildStatus = ...) -> None:
        """
        Constructor for DcLine.
        
        :param nt: Number of simulation timesteps.
        :param name: Human-readable line name.
        :param idtag: Stable unique identifier tag.
        :param code: Engineering code or label.
        :param bus_from: Pointer to the *from* bus.
        :param bus_to: Pointer to the *to* bus.
        :param r: DC resistance per unit length **R** (Ω /km).
        :param rate: Continuous current rating **I<sub>max</sub>** (kA).
        :param active: Initial active state profile.
        :param tolerance: Power-flow convergence tolerance (pu).
        :param cost: Operating cost per unit energy or time.
        :param mttf: Mean time to failure (h).
        :param mttr: Mean time to repair (h).
        :param r_fault: Fault resistance used in contingency studies (Ω).
        :param fault_pos: Fault position as fraction (0 – 1) of line length.
        :param length: Physical line length (km).
        :param temp_base: Reference temperature for resistance (°C).
        :param temp_oper: Operating temperature profile (°C).
        :param alpha: Temperature coefficient of resistance (1/°C).
        :param contingency_factor: Multiplicative contingency rating factor.
        :param protection_rating_factor: Protection-based rating factor.
        :param monitor_loading: Enable automatic loading alarms.
        :param capex: Capital expenditure (currency units).
        :param opex: Annual operating expenditure (currency units).
        :param build_status: Construction / service status enumeration.
        """
    def get_r_corrected(self, t_idx: int) -> float:
        """
        Return temperature-corrected resistance at timestep *t_idx*.
        """
    @property
    def R(self) -> float:
        """
        DC resistance per unit length **R** (Ω /km).
        """
    @R.setter
    def R(self, arg1: float) -> None:
        ...
    @property
    def alpha(self) -> float:
        """
        Temperature coefficient of resistance (1/°C).
        """
    @alpha.setter
    def alpha(self, arg1: float) -> None:
        ...
    @property
    def fault_pos(self) -> float:
        """
        Fault position as fraction (0 – 1) of line length.
        """
    @fault_pos.setter
    def fault_pos(self, arg1: float) -> None:
        ...
    @property
    def length(self) -> float:
        """
        Line length (km).
        """
    @length.setter
    def length(self, arg1: float) -> None:
        ...
    @property
    def r_fault(self) -> float:
        """
        Fault resistance (Ω).
        """
    @r_fault.setter
    def r_fault(self, arg1: float) -> None:
        ...
    @property
    def temp_base(self) -> float:
        """
        Reference temperature for resistance (°C).
        """
    @temp_base.setter
    def temp_base(self, arg1: float) -> None:
        ...
    @property
    def temp_oper(self) -> Profiledouble:
        """
        Operating temperature profile (°C).
        """
    @temp_oper.setter
    def temp_oper(self, arg1: Profiledouble) -> None:
        ...
    @property
    def tolerance(self) -> float:
        """
        Branch tolerance value
        """
    @tolerance.setter
    def tolerance(self, arg1: float) -> None:
        ...
class DeviceType:
    """
    Members:
    
      NoDevice
    
      TimeDevice
    
      CircuitDevice
    
      BusDevice
    
      BranchDevice
    
      BranchTypeDevice
    
      LineDevice
    
      LineTypeDevice
    
      Transformer2WDevice
    
      Transformer3WDevice
    
      WindingDevice
    
      SeriesReactanceDevice
    
      HVDCLineDevice
    
      DCLineDevice
    
      VscDevice
    
      BatteryDevice
    
      LoadDevice
    
      CurrentInjectionDevice
    
      ControllableShuntDevice
    
      GeneratorDevice
    
      StaticGeneratorDevice
    
      ShuntDevice
    
      ShuntLikeDevice
    
      UpfcDevice
    
      ExternalGridDevice
    
      LoadLikeDevice
    
      BranchGroupDevice
    
      LambdaDevice
    
      PiMeasurementDevice
    
      QiMeasurementDevice
    
      PfMeasurementDevice
    
      QfMeasurementDevice
    
      VmMeasurementDevice
    
      IfMeasurementDevice
    
      WireDevice
    
      SequenceLineDevice
    
      UnderGroundLineDevice
    
      OverheadLineTypeDevice
    
      AnyLineTemplateDevice
    
      TransformerTypeDevice
    
      SwitchDevice
    
      GenericArea
    
      SubstationDevice
    
      ConnectivityNodeDevice
    
      AreaDevice
    
      ZoneDevice
    
      CountryDevice
    
      CommunityDevice
    
      RegionDevice
    
      MunicipalityDevice
    
      BusBarDevice
    
      VoltageLevelDevice
    
      VoltageLevelTemplate
    
      Technology
    
      TechnologyGroup
    
      TechnologyCategory
    
      ContingencyDevice
    
      ContingencyGroupDevice
    
      RemedialActionDevice
    
      RemedialActionGroupDevice
    
      InvestmentDevice
    
      InvestmentsGroupDevice
    
      FuelDevice
    
      EmissionGasDevice
    
      GeneratorEmissionAssociation
    
      GeneratorFuelAssociation
    
      GeneratorTechnologyAssociation
    
      DiagramDevice
    
      FluidInjectionDevice
    
      FluidTurbineDevice
    
      FluidPumpDevice
    
      FluidP2XDevice
    
      FluidPathDevice
    
      FluidNodeDevice
    
      LineLocation
    
      LineLocations
    
      ModellingAuthority
    
      FacilityDevice
    
      SimulationOptionsDevice
    
      InterAggregationInfo
    """
    AnyLineTemplateDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.AnyLineTemplateDevice: 38>
    AreaDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.AreaDevice: 44>
    BatteryDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.BatteryDevice: 15>
    BranchDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.BranchDevice: 4>
    BranchGroupDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.BranchGroupDevice: 26>
    BranchTypeDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.BranchTypeDevice: 5>
    BusBarDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.BusBarDevice: 50>
    BusDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.BusDevice: 3>
    CircuitDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.CircuitDevice: 2>
    CommunityDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.CommunityDevice: 47>
    ConnectivityNodeDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.ConnectivityNodeDevice: 43>
    ContingencyDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.ContingencyDevice: 56>
    ContingencyGroupDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.ContingencyGroupDevice: 57>
    ControllableShuntDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.ControllableShuntDevice: 18>
    CountryDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.CountryDevice: 46>
    CurrentInjectionDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.CurrentInjectionDevice: 17>
    DCLineDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.DCLineDevice: 13>
    DiagramDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.DiagramDevice: 67>
    EmissionGasDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.EmissionGasDevice: 63>
    ExternalGridDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.ExternalGridDevice: 24>
    FacilityDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.FacilityDevice: 77>
    FluidInjectionDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.FluidInjectionDevice: 68>
    FluidNodeDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.FluidNodeDevice: 73>
    FluidP2XDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.FluidP2XDevice: 71>
    FluidPathDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.FluidPathDevice: 72>
    FluidPumpDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.FluidPumpDevice: 70>
    FluidTurbineDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.FluidTurbineDevice: 69>
    FuelDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.FuelDevice: 62>
    GeneratorDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.GeneratorDevice: 19>
    GeneratorEmissionAssociation: typing.ClassVar[DeviceType]  # value = <DeviceType.GeneratorEmissionAssociation: 64>
    GeneratorFuelAssociation: typing.ClassVar[DeviceType]  # value = <DeviceType.GeneratorFuelAssociation: 65>
    GeneratorTechnologyAssociation: typing.ClassVar[DeviceType]  # value = <DeviceType.GeneratorTechnologyAssociation: 66>
    GenericArea: typing.ClassVar[DeviceType]  # value = <DeviceType.GenericArea: 41>
    HVDCLineDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.HVDCLineDevice: 12>
    IfMeasurementDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.IfMeasurementDevice: 33>
    InterAggregationInfo: typing.ClassVar[DeviceType]  # value = <DeviceType.InterAggregationInfo: 79>
    InvestmentDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.InvestmentDevice: 60>
    InvestmentsGroupDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.InvestmentsGroupDevice: 61>
    LambdaDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.LambdaDevice: 27>
    LineDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.LineDevice: 6>
    LineLocation: typing.ClassVar[DeviceType]  # value = <DeviceType.LineLocation: 74>
    LineLocations: typing.ClassVar[DeviceType]  # value = <DeviceType.LineLocations: 75>
    LineTypeDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.LineTypeDevice: 7>
    LoadDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.LoadDevice: 16>
    LoadLikeDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.LoadLikeDevice: 25>
    ModellingAuthority: typing.ClassVar[DeviceType]  # value = <DeviceType.ModellingAuthority: 76>
    MunicipalityDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.MunicipalityDevice: 49>
    NoDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.NoDevice: 0>
    OverheadLineTypeDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.OverheadLineTypeDevice: 37>
    PfMeasurementDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.PfMeasurementDevice: 30>
    PiMeasurementDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.PiMeasurementDevice: 28>
    QfMeasurementDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.QfMeasurementDevice: 31>
    QiMeasurementDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.QiMeasurementDevice: 29>
    RegionDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.RegionDevice: 48>
    RemedialActionDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.RemedialActionDevice: 58>
    RemedialActionGroupDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.RemedialActionGroupDevice: 59>
    SequenceLineDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.SequenceLineDevice: 35>
    SeriesReactanceDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.SeriesReactanceDevice: 11>
    ShuntDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.ShuntDevice: 21>
    ShuntLikeDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.ShuntLikeDevice: 22>
    SimulationOptionsDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.SimulationOptionsDevice: 78>
    StaticGeneratorDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.StaticGeneratorDevice: 20>
    SubstationDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.SubstationDevice: 42>
    SwitchDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.SwitchDevice: 40>
    Technology: typing.ClassVar[DeviceType]  # value = <DeviceType.Technology: 53>
    TechnologyCategory: typing.ClassVar[DeviceType]  # value = <DeviceType.TechnologyCategory: 55>
    TechnologyGroup: typing.ClassVar[DeviceType]  # value = <DeviceType.TechnologyGroup: 54>
    TimeDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.TimeDevice: 1>
    Transformer2WDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.Transformer2WDevice: 8>
    Transformer3WDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.Transformer3WDevice: 9>
    TransformerTypeDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.TransformerTypeDevice: 39>
    UnderGroundLineDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.UnderGroundLineDevice: 36>
    UpfcDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.UpfcDevice: 23>
    VmMeasurementDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.VmMeasurementDevice: 32>
    VoltageLevelDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.VoltageLevelDevice: 51>
    VoltageLevelTemplate: typing.ClassVar[DeviceType]  # value = <DeviceType.VoltageLevelTemplate: 52>
    VscDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.VscDevice: 14>
    WindingDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.WindingDevice: 10>
    WireDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.WireDevice: 34>
    ZoneDevice: typing.ClassVar[DeviceType]  # value = <DeviceType.ZoneDevice: 45>
    __members__: typing.ClassVar[dict[str, DeviceType]]  # value = {'NoDevice': <DeviceType.NoDevice: 0>, 'TimeDevice': <DeviceType.TimeDevice: 1>, 'CircuitDevice': <DeviceType.CircuitDevice: 2>, 'BusDevice': <DeviceType.BusDevice: 3>, 'BranchDevice': <DeviceType.BranchDevice: 4>, 'BranchTypeDevice': <DeviceType.BranchTypeDevice: 5>, 'LineDevice': <DeviceType.LineDevice: 6>, 'LineTypeDevice': <DeviceType.LineTypeDevice: 7>, 'Transformer2WDevice': <DeviceType.Transformer2WDevice: 8>, 'Transformer3WDevice': <DeviceType.Transformer3WDevice: 9>, 'WindingDevice': <DeviceType.WindingDevice: 10>, 'SeriesReactanceDevice': <DeviceType.SeriesReactanceDevice: 11>, 'HVDCLineDevice': <DeviceType.HVDCLineDevice: 12>, 'DCLineDevice': <DeviceType.DCLineDevice: 13>, 'VscDevice': <DeviceType.VscDevice: 14>, 'BatteryDevice': <DeviceType.BatteryDevice: 15>, 'LoadDevice': <DeviceType.LoadDevice: 16>, 'CurrentInjectionDevice': <DeviceType.CurrentInjectionDevice: 17>, 'ControllableShuntDevice': <DeviceType.ControllableShuntDevice: 18>, 'GeneratorDevice': <DeviceType.GeneratorDevice: 19>, 'StaticGeneratorDevice': <DeviceType.StaticGeneratorDevice: 20>, 'ShuntDevice': <DeviceType.ShuntDevice: 21>, 'ShuntLikeDevice': <DeviceType.ShuntLikeDevice: 22>, 'UpfcDevice': <DeviceType.UpfcDevice: 23>, 'ExternalGridDevice': <DeviceType.ExternalGridDevice: 24>, 'LoadLikeDevice': <DeviceType.LoadLikeDevice: 25>, 'BranchGroupDevice': <DeviceType.BranchGroupDevice: 26>, 'LambdaDevice': <DeviceType.LambdaDevice: 27>, 'PiMeasurementDevice': <DeviceType.PiMeasurementDevice: 28>, 'QiMeasurementDevice': <DeviceType.QiMeasurementDevice: 29>, 'PfMeasurementDevice': <DeviceType.PfMeasurementDevice: 30>, 'QfMeasurementDevice': <DeviceType.QfMeasurementDevice: 31>, 'VmMeasurementDevice': <DeviceType.VmMeasurementDevice: 32>, 'IfMeasurementDevice': <DeviceType.IfMeasurementDevice: 33>, 'WireDevice': <DeviceType.WireDevice: 34>, 'SequenceLineDevice': <DeviceType.SequenceLineDevice: 35>, 'UnderGroundLineDevice': <DeviceType.UnderGroundLineDevice: 36>, 'OverheadLineTypeDevice': <DeviceType.OverheadLineTypeDevice: 37>, 'AnyLineTemplateDevice': <DeviceType.AnyLineTemplateDevice: 38>, 'TransformerTypeDevice': <DeviceType.TransformerTypeDevice: 39>, 'SwitchDevice': <DeviceType.SwitchDevice: 40>, 'GenericArea': <DeviceType.GenericArea: 41>, 'SubstationDevice': <DeviceType.SubstationDevice: 42>, 'ConnectivityNodeDevice': <DeviceType.ConnectivityNodeDevice: 43>, 'AreaDevice': <DeviceType.AreaDevice: 44>, 'ZoneDevice': <DeviceType.ZoneDevice: 45>, 'CountryDevice': <DeviceType.CountryDevice: 46>, 'CommunityDevice': <DeviceType.CommunityDevice: 47>, 'RegionDevice': <DeviceType.RegionDevice: 48>, 'MunicipalityDevice': <DeviceType.MunicipalityDevice: 49>, 'BusBarDevice': <DeviceType.BusBarDevice: 50>, 'VoltageLevelDevice': <DeviceType.VoltageLevelDevice: 51>, 'VoltageLevelTemplate': <DeviceType.VoltageLevelTemplate: 52>, 'Technology': <DeviceType.Technology: 53>, 'TechnologyGroup': <DeviceType.TechnologyGroup: 54>, 'TechnologyCategory': <DeviceType.TechnologyCategory: 55>, 'ContingencyDevice': <DeviceType.ContingencyDevice: 56>, 'ContingencyGroupDevice': <DeviceType.ContingencyGroupDevice: 57>, 'RemedialActionDevice': <DeviceType.RemedialActionDevice: 58>, 'RemedialActionGroupDevice': <DeviceType.RemedialActionGroupDevice: 59>, 'InvestmentDevice': <DeviceType.InvestmentDevice: 60>, 'InvestmentsGroupDevice': <DeviceType.InvestmentsGroupDevice: 61>, 'FuelDevice': <DeviceType.FuelDevice: 62>, 'EmissionGasDevice': <DeviceType.EmissionGasDevice: 63>, 'GeneratorEmissionAssociation': <DeviceType.GeneratorEmissionAssociation: 64>, 'GeneratorFuelAssociation': <DeviceType.GeneratorFuelAssociation: 65>, 'GeneratorTechnologyAssociation': <DeviceType.GeneratorTechnologyAssociation: 66>, 'DiagramDevice': <DeviceType.DiagramDevice: 67>, 'FluidInjectionDevice': <DeviceType.FluidInjectionDevice: 68>, 'FluidTurbineDevice': <DeviceType.FluidTurbineDevice: 69>, 'FluidPumpDevice': <DeviceType.FluidPumpDevice: 70>, 'FluidP2XDevice': <DeviceType.FluidP2XDevice: 71>, 'FluidPathDevice': <DeviceType.FluidPathDevice: 72>, 'FluidNodeDevice': <DeviceType.FluidNodeDevice: 73>, 'LineLocation': <DeviceType.LineLocation: 74>, 'LineLocations': <DeviceType.LineLocations: 75>, 'ModellingAuthority': <DeviceType.ModellingAuthority: 76>, 'FacilityDevice': <DeviceType.FacilityDevice: 77>, 'SimulationOptionsDevice': <DeviceType.SimulationOptionsDevice: 78>, 'InterAggregationInfo': <DeviceType.InterAggregationInfo: 79>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class DiagramType:
    """
    Members:
    
      Schematic
    
      SubstationLineMap
    """
    Schematic: typing.ClassVar[DiagramType]  # value = <DiagramType.Schematic: 0>
    SubstationLineMap: typing.ClassVar[DiagramType]  # value = <DiagramType.SubstationLineMap: 1>
    __members__: typing.ClassVar[dict[str, DiagramType]]  # value = {'Schematic': <DiagramType.Schematic: 0>, 'SubstationLineMap': <DiagramType.SubstationLineMap: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class EditableDevice:
    def __init__(self, name: str, idtag: str, code: str, device_type: DeviceType, comment: str = '') -> None:
        """
        Constructor for EditableDevice.
        
        :param name: Asset's name
        :param idtag: Unique ID (generated if not provided)
        :param code: Alternative code for identifying in other databases
        :param device_type: DeviceType instance
        :param comment: Optional comment
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def get_action(self) -> ActionType:
        """
        Get the action type.
        
        :return: The action type.
        """
    def get_code(self) -> str:
        """
        Get the code.
        
        :return: The code as a string.
        """
    def get_comment(self) -> str:
        """
        Get the comment.
        
        :return: The comment as a string.
        """
    def get_device_type(self) -> DeviceType:
        """
        Get the device type.
        
        :return: The device type.
        """
    def get_idtag(self) -> str:
        """
        Get the ID tag.
        
        :return: The ID tag as a string.
        """
    def get_name(self) -> str:
        """
        Get the name.
        
        :return: The name as a string.
        """
    def set_action(self, action: ActionType) -> None:
        """
        Set the action type.
        
        :param action: The new action type.
        """
    def set_code(self, code: str) -> None:
        """
        Set the code.
        
        :param code: The new code.
        """
    def set_comment(self, comment: str) -> None:
        """
        Set the comment.
        
        :param comment: The new comment.
        """
    def set_device_type(self, device_type: DeviceType) -> None:
        """
        Set the device type.
        
        :param device_type: The new device type.
        """
    def set_idtag(self, idtag: str) -> None:
        """
        Set the ID tag.
        
        :param idtag: The new ID tag.
        """
    def set_name(self, name: str) -> None:
        """
        Set the name.
        
        :param name: The new name.
        """
class EmissionGas(EditableDevice):
    def __init__(self, name: str = 'Fuel', idtag: str = '', code: str = '') -> None:
        """
        Constructor for EmissionGas.
        
        :param name: Name of the emission gas
        :param idtag: ID tag for the emission gas
        :param code: Code for the emission gas
        """
    @property
    def color(self) -> str:
        """
        Color representation of the emission gas.
        
        :getter: Get the color.
        :setter: Set the color.
        """
    @color.setter
    def color(self, arg1: str) -> None:
        ...
    @property
    def cost(self) -> float:
        """
        Cost associated with the emission gas.
        
        :getter: Get the cost.
        :setter: Set the cost.
        """
    @cost.setter
    def cost(self, arg1: float) -> None:
        ...
class Expr:
    @typing.overload
    def __add__(self, arg0: Expr) -> Expr:
        ...
    @typing.overload
    def __add__(self, arg0: float) -> Expr:
        ...
    @typing.overload
    def __mul__(self, arg0: Expr) -> Expr:
        ...
    @typing.overload
    def __mul__(self, arg0: float) -> Expr:
        ...
    @typing.overload
    def __pow__(self, arg0: Expr) -> Expr:
        ...
    @typing.overload
    def __pow__(self, arg0: float) -> Expr:
        ...
    @typing.overload
    def __pow__(self, arg0: typing.Any) -> Expr:
        ...
    def __radd__(self, arg0: float) -> Expr:
        ...
    def __repr__(self) -> str:
        ...
    def __rmul__(self, arg0: float) -> Expr:
        ...
    @typing.overload
    def __rpow__(self, arg0: float) -> Expr:
        ...
    @typing.overload
    def __rpow__(self, arg0: float) -> Expr:
        ...
    def __rsub__(self, arg0: float) -> Expr:
        ...
    def __rtruediv__(self, arg0: float) -> Expr:
        ...
    def __str__(self) -> str:
        ...
    @typing.overload
    def __sub__(self, arg0: Expr) -> Expr:
        ...
    @typing.overload
    def __sub__(self, arg0: float) -> Expr:
        ...
    @typing.overload
    def __truediv__(self, arg0: Expr) -> Expr:
        ...
    @typing.overload
    def __truediv__(self, arg0: float) -> Expr:
        ...
    def diff(self, var: Expr, order: int = 1) -> Expr:
        ...
    def eval(self, **kwargs) -> float:
        ...
    def eval_ptr(self, arg0: dict) -> float:
        ...
    def simplify(self) -> Expr:
        ...
class ExternalGrid(LoadParent):
    def __init__(self, nt: int, bus: Bus = None, name: str = 'External grid', idtag: str = '', code: str = '', active: bool = True, substituted_device_id: str = '', Vm: float = 1.0, Va: float = 0.0, P: float = 0.0, Q: float = 0.0, mttf: float = 0.0, mttr: float = 0.0, mode: ExternalGridMode = ..., capex: float = 0.0, opex: float = 0.0, build_status: BuildStatus = ...) -> None:
        """
        Constructor for ExternalGrid.
        
        :param nt: Number of simulation timesteps.
        :param bus: Pointer to the connected AC bus (may be *None*).
        :param name/idtag/code: Readable name and identifiers.
        :param active: Whether the external grid is energised in the base case.
        :param substituted_device_id: ID of the device this grid substitutes (if any).
        :param Vm/Va: Initial voltage magnitude (pu) and angle (deg).
        :param P/Q: Fixed active and reactive power injections (MW / MVAr) in *PQ* mode.
        :param mttf/mttr: Mean time to failure / repair (h).
        :param mode: Operating mode (e.g. *PQ*, *PV*, *Slack*).
        :param capex/opex: Capital and annual operating expenditure (currency units).
        :param build_status: Construction / service status enumeration.
        """
    def set_va_val(self, val: float) -> None:
        """
        Set voltage angle value.
        """
    def set_vm_val(self, val: float) -> None:
        """
        Set voltage magnitude value.
        """
    @property
    def Va(self) -> Profiledouble:
        """
        Profile for voltage angle.
        """
    @Va.setter
    def Va(self, arg1: Profiledouble) -> None:
        ...
    @property
    def Vm(self) -> Profiledouble:
        """
        Profile for voltage magnitude.
        """
    @Vm.setter
    def Vm(self, arg1: Profiledouble) -> None:
        ...
    @property
    def mode(self) -> ExternalGridMode:
        """
        External grid operation mode.
        """
    @mode.setter
    def mode(self, arg1: ExternalGridMode) -> None:
        ...
    @property
    def substituted_device_id(self) -> str:
        """
        Substituted device ID.
        """
    @substituted_device_id.setter
    def substituted_device_id(self, arg1: str) -> None:
        ...
class ExternalGridMode:
    """
    Members:
    
      PQ
    
      PV
    
      VD
    """
    PQ: typing.ClassVar[ExternalGridMode]  # value = <ExternalGridMode.PQ: 0>
    PV: typing.ClassVar[ExternalGridMode]  # value = <ExternalGridMode.PV: 1>
    VD: typing.ClassVar[ExternalGridMode]  # value = <ExternalGridMode.VD: 2>
    __members__: typing.ClassVar[dict[str, ExternalGridMode]]  # value = {'PQ': <ExternalGridMode.PQ: 0>, 'PV': <ExternalGridMode.PV: 1>, 'VD': <ExternalGridMode.VD: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Facility(GenericAreaGroup):
    def __init__(self, name: str = '', idtag: str = '', code: str = '') -> None:
        """
        Constructor for Facility.
        
        :param name: Name of the facility
        :param idtag: ID tag for the facility
        :param code: Code for the facility
        """
class FastDecoupledAdmittanceMatrices:
    def __init__(self, B1: scipy.sparse.csc_matrix, B2: scipy.sparse.csc_matrix) -> None:
        ...
    @property
    def B1(self) -> scipy.sparse.csc_matrix:
        ...
    @property
    def B2(self) -> scipy.sparse.csc_matrix:
        ...
class FaultType:
    """
    Members:
    
      ph3
    
      LG
    
      LL
    
      LLG
    """
    LG: typing.ClassVar[FaultType]  # value = <FaultType.LG: 1>
    LL: typing.ClassVar[FaultType]  # value = <FaultType.LL: 2>
    LLG: typing.ClassVar[FaultType]  # value = <FaultType.LLG: 3>
    __members__: typing.ClassVar[dict[str, FaultType]]  # value = {'ph3': <FaultType.ph3: 0>, 'LG': <FaultType.LG: 1>, 'LL': <FaultType.LL: 2>, 'LLG': <FaultType.LLG: 3>}
    ph3: typing.ClassVar[FaultType]  # value = <FaultType.ph3: 0>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Fuel(EditableDevice):
    def __init__(self, name: str = 'Fuel', idtag: str = '', code: str = '') -> None:
        """
        Constructor for Fuel.
        
        :param name: Name of the fuel
        :param idtag: ID tag for the fuel
        :param code: Code for the fuel
        """
    @property
    def color(self) -> str:
        """
        Color representation of the fuel.
        
        :getter: Get the color.
        :setter: Set the color.
        """
    @color.setter
    def color(self, arg1: str) -> None:
        ...
    @property
    def cost(self) -> float:
        """
        Cost associated with the fuel.
        
        :getter: Get the cost.
        :setter: Set the cost.
        """
    @cost.setter
    def cost(self, arg1: float) -> None:
        ...
class GenerationNtcFormulation:
    """
    Members:
    
      Proportional
    
      Optimal
    """
    Optimal: typing.ClassVar[GenerationNtcFormulation]  # value = <GenerationNtcFormulation.Optimal: 1>
    Proportional: typing.ClassVar[GenerationNtcFormulation]  # value = <GenerationNtcFormulation.Proportional: 0>
    __members__: typing.ClassVar[dict[str, GenerationNtcFormulation]]  # value = {'Proportional': <GenerationNtcFormulation.Proportional: 0>, 'Optimal': <GenerationNtcFormulation.Optimal: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Generator(InjectionParent):
    def __init__(self, nt: int, bus: Bus = None, name: str = 'gen', idtag: str = '', code: str = '', P: float = 0.0, power_factor: float = 0.8, vset: float = 1.0, is_controlled: bool = True, Qmin: float = -9999, Qmax: float = 9999, Snom: float = 9999, active: bool = True, Pmin: float = 0.0, Pmax: float = 9999.0, Cost: float = 1.0, Cost2: float = 0.0, Cost0: float = 0.0, Sbase: float = 100, enabled_dispatch: bool = True, mttf: float = 0.0, mttr: float = 0.0, q_points: list[typing.Annotated[list[float], pybind11_stubgen.typing_ext.FixedSize(3)]] = [], use_reactive_power_curve: bool = False, r1: float = 1e-20, x1: float = 1e-20, r0: float = 1e-20, x0: float = 1e-20, r2: float = 1e-20, x2: float = 1e-20, capex: float = 0.0, opex: float = 0.0, srap_enabled: bool = True, build_status: BuildStatus = ...) -> None:
        """
        Constructor for Generator.
        
        :param nt: Number of simulation timesteps.
        :param bus: Pointer to the connected AC bus (may be *None*).
        :param name: Human-readable generator name.
        :param idtag: Stable unique identifier tag.
        :param code: Engineering code or label.
        :param P: Initial active-power set-point **P** (MW).
        :param power_factor: Initial power factor (*leading* < 1 < *lagging*).
        :param vset: Voltage set-point at the terminal bus (pu).
        :param is_controlled: If *true*, generator controls voltage/reactive power.
        :param Qmin/Qmax: Reactive-power capability limits (MVAr).
        :param Snom: Apparent-power rating **S<sub>n</sub>** (MVA).
        :param active: Whether the unit is in-service in the base case.
        :param Pmin/Pmax: Dispatchable active-power limits (MW).
        :param Cost/Cost2/Cost0: Linear, quadratic and constant production-cost terms.
        :param Sbase: System base power for per-unit calculations (MVA).
        :param enabled_dispatch: Allow optimisation to dispatch this generator.
        :param mttf/mttr: Mean time to failure / repair (h).
        :param q_points: Custom reactive-power capability curve points *(V, Qmin, Qmax)*.
        :param use_reactive_power_curve: Use *q_points* instead of quadratic limits.
        :param r1/x1: Positive-sequence impedance components (pu).
        :param r0/x0: Zero-sequence impedance components (pu).
        :param r2/x2: Negative-sequence impedance components (pu).
        :param capex/opex: Capital and annual operating expenditure (currency units).
        :param srap_enabled: Include unit in system-restoration or SRAP studies.
        :param build_status: Construction / service status enumeration.
        """
    def get_P_at(self, t: int) -> float:
        """
        Get active power at a specific timestep.
        """
    def get_Pmax_at(self, t: int) -> float:
        """
        Get maximum active power at a specific timestep.
        """
    def get_Pmin_at(self, t: int) -> float:
        """
        Get minimum active power at a specific timestep.
        """
    def set_P_val(self, val: float) -> None:
        """
        Set the active power value for the full profile.
        """
    def set_Pmax_val(self, val: float) -> None:
        """
        Set the maximum active power value for the full profile.
        """
    def set_Pmin_val(self, val: float) -> None:
        """
        Set the minimum active power value for the full profile.
        """
    def set_control_bus_val(self, val: ...) -> None:
        """
        Set the control bus value for the full profile.
        """
    def set_srap_enabled_val(self, val: bool) -> None:
        """
        Set the SRAP participation value for the full profile.
        """
    def set_cost0_val(self, val: float) -> None:
        """
        Set scalar value for constant cost profile.
        """
    def set_cost2_val(self, val: float) -> None:
        """
        Set scalar value for quadratic cost profile.
        """
    def set_pf_val(self, val: float) -> None:
        """
        Set scalar value for active power factor profile.
        """
    def set_qmax_set_val(self, val: float) -> None:
        """
        Set scalar value for reactive power maximum limit.
        """
    def set_qmin_set_val(self, val: float) -> None:
        """
        Set scalar value for reactive power minimum limit.
        """
    def set_vset_val(self, val: float) -> None:
        """
        Set scalar value for voltage setpoint profile.
        """
    @property
    def Cost0(self) -> Profiledouble:
        """
        Profile for constant cost.
        """
    @Cost0.setter
    def Cost0(self, arg1: Profiledouble) -> None:
        ...
    @property
    def Cost2(self) -> Profiledouble:
        """
        Profile for quadratic cost.
        """
    @Cost2.setter
    def Cost2(self, arg1: Profiledouble) -> None:
        ...
    @property
    def P(self) -> Profiledouble:
        """
        Active power profile (MW).
        """
    @P.setter
    def P(self, arg1: Profiledouble) -> None:
        ...
    @property
    def Pmax(self) -> Profiledouble:
        """
        Maximum active power profile (MW).
        """
    @Pmax.setter
    def Pmax(self, arg1: Profiledouble) -> None:
        ...
    @property
    def Pmin(self) -> Profiledouble:
        """
        Minimum active power profile (MW).
        """
    @Pmin.setter
    def Pmin(self, arg1: Profiledouble) -> None:
        ...
    @property
    def MinTimeDown(self) -> float:
        """
        Minimum down time.
        """
    @MinTimeDown.setter
    def MinTimeDown(self, arg1: float) -> None:
        ...
    @property
    def MinTimeUp(self) -> float:
        """
        Minimum up time.
        """
    @MinTimeUp.setter
    def MinTimeUp(self, arg1: float) -> None:
        ...
    @property
    def Pf(self) -> Profiledouble:
        """
        Profile for active power factor.
        """
    @Pf.setter
    def Pf(self, arg1: Profiledouble) -> None:
        ...
    @property
    def R0(self) -> float:
        """
        Zero sequence resistance.
        """
    @R0.setter
    def R0(self, arg1: float) -> None:
        ...
    @property
    def R1(self) -> float:
        """
        Positive sequence resistance.
        """
    @R1.setter
    def R1(self, arg1: float) -> None:
        ...
    @property
    def R2(self) -> float:
        """
        Negative sequence resistance.
        """
    @R2.setter
    def R2(self, arg1: float) -> None:
        ...
    @property
    def RampDown(self) -> float:
        """
        Ramp-down rate.
        """
    @RampDown.setter
    def RampDown(self, arg1: float) -> None:
        ...
    @property
    def RampUp(self) -> float:
        """
        Ramp-up rate.
        """
    @RampUp.setter
    def RampUp(self, arg1: float) -> None:
        ...
    @property
    def Sbase(self) -> float:
        """
        Base power for per-unit values.
        """
    @Sbase.setter
    def Sbase(self, arg1: float) -> None:
        ...
    @property
    def ShutdownCost(self) -> float:
        """
        Generator shutdown cost.
        """
    @ShutdownCost.setter
    def ShutdownCost(self, arg1: float) -> None:
        ...
    @property
    def Snom(self) -> float:
        """
        Nominal power in MVA.
        """
    @Snom.setter
    def Snom(self, arg1: float) -> None:
        ...
    @property
    def StartupCost(self) -> float:
        """
        Generator startup cost.
        """
    @StartupCost.setter
    def StartupCost(self, arg1: float) -> None:
        ...
    @property
    def Vset(self) -> Profiledouble:
        """
        Profile for voltage setpoint.
        """
    @Vset.setter
    def Vset(self, arg1: Profiledouble) -> None:
        ...
    @property
    def X0(self) -> float:
        """
        Zero sequence reactance.
        """
    @X0.setter
    def X0(self, arg1: float) -> None:
        ...
    @property
    def X1(self) -> float:
        """
        Positive sequence reactance.
        """
    @X1.setter
    def X1(self, arg1: float) -> None:
        ...
    @property
    def X2(self) -> float:
        """
        Negative sequence reactance.
        """
    @X2.setter
    def X2(self, arg1: float) -> None:
        ...
    @property
    def control_bus(self) -> ProfileBus:
        """
        Control bus profile.
        """
    @control_bus.setter
    def control_bus(self, arg1: ProfileBus) -> None:
        ...
    @property
    def custom_q_points(self) -> bool:
        """
        Enable custom reactive power points.
        """
    @custom_q_points.setter
    def custom_q_points(self, arg1: bool) -> None:
        ...
    @property
    def emissions(self) -> Associations:
        """
        Emissions associated with the generator.
        """
    @emissions.setter
    def emissions(self, arg1: Associations) -> None:
        ...
    @property
    def enabled_dispatch(self) -> bool:
        """
        Enable or disable dispatch.
        """
    @enabled_dispatch.setter
    def enabled_dispatch(self, arg1: bool) -> None:
        ...
    @property
    def fuels(self) -> Associations:
        """
        Fuels associated with the generator.
        """
    @fuels.setter
    def fuels(self, arg1: Associations) -> None:
        ...
    @property
    def is_controlled(self) -> bool:
        """
        Control mode of the generator.
        """
    @is_controlled.setter
    def is_controlled(self, arg1: bool) -> None:
        ...
    @property
    def q_curve(self) -> GeneratorQCurve:
        """
        Reactive power curve.
        """
    @q_curve.setter
    def q_curve(self, arg1: GeneratorQCurve) -> None:
        ...
    @property
    def qmax_set(self) -> Profiledouble:
        """
        Profile for reactive power maximum limit.
        """
    @qmax_set.setter
    def qmax_set(self, arg1: Profiledouble) -> None:
        ...
    @property
    def qmin_set(self) -> Profiledouble:
        """
        Profile for reactive power minimum limit.
        """
    @qmin_set.setter
    def qmin_set(self, arg1: Profiledouble) -> None:
        ...
    @property
    def srap_enabled(self) -> Profilebool:
        """
        SRAP participation profile.
        """
    @srap_enabled.setter
    def srap_enabled(self, arg1: Profilebool) -> None:
        ...
    @property
    def use_reactive_power_curve(self) -> bool:
        """
        Use reactive power curve.
        """
    @use_reactive_power_curve.setter
    def use_reactive_power_curve(self, arg1: bool) -> None:
        ...
class GeneratorData:
    active: Numpy.ndarray[]
    availability: Numpy.ndarray[]
    bus_idx: Numpy.ndarray[]
    controllable: Numpy.ndarray[]
    controllable_bus_idx: Numpy.ndarray[]
    cost_0: Numpy.ndarray[]
    cost_1: Numpy.ndarray[]
    cost_2: Numpy.ndarray[]
    dispatchable: Numpy.ndarray[]
    idtag: list[str]
    installed_p: Numpy.ndarray[]
    is_at_dc_bus: Numpy.ndarray[]
    min_time_down: Numpy.ndarray[]
    min_time_up: Numpy.ndarray[]
    mttf: Numpy.ndarray[]
    mttr: Numpy.ndarray[]
    name_to_idx: dict[str, int]
    names: list[str]
    nbus: int
    nelm: int
    original_idx: Numpy.ndarray[]
    p: Numpy.ndarray[]
    pf: Numpy.ndarray[]
    pmax: Numpy.ndarray[]
    pmin: Numpy.ndarray[]
    q_share: Numpy.ndarray[]
    qmax: Numpy.ndarray[]
    qmin: Numpy.ndarray[]
    r0: Numpy.ndarray[]
    r1: Numpy.ndarray[]
    r2: Numpy.ndarray[]
    ramp_down: Numpy.ndarray[]
    ramp_up: Numpy.ndarray[]
    snom: Numpy.ndarray[]
    startup_cost: Numpy.ndarray[]
    v: Numpy.ndarray[]
    x0: Numpy.ndarray[]
    x1: Numpy.ndarray[]
    x2: Numpy.ndarray[]
    def __init__(self, arg0: int, arg1: int) -> None:
        ...
class GeneratorQCurve:
    __hash__: typing.ClassVar[None] = None
    def __eq__(self, arg0: GeneratorQCurve) -> bool:
        """
        Compare two Q-curves for equality.
        """
    def __init__(self) -> None:
        ...
    def get_data(self) -> list[typing.Annotated[list[float], pybind11_stubgen.typing_ext.FixedSize(3)]]:
        """
        Retrieve the Q-curve data as a vector of arrays.
        """
    def get_data_by_type(self) -> tuple:
        """
        Retrieve Q-curve data as separate vectors for P, Qmin, and Qmax.
        """
    def get_q_limits(self, arg0: float) -> tuple[float, float]:
        """
        Get the Qmin and Qmax limits for a given P value.
        """
    def get_qmax(self, arg0: float) -> float:
        """
        Get the Qmax value for a given P.
        """
    def get_qmin(self, arg0: float) -> float:
        """
        Get the Qmin value for a given P.
        """
    def make_default_q_curve(self, Snom: float, Qmin: float, Qmax: float, n: int = 3) -> None:
        """
        Generate a default Q-curve based on the given parameters.
        """
class GenericAreaGroup(EditableDevice):
    def __init__(self, dtype: DeviceType, name: str = '', idtag: str = '', code: str = '') -> None:
        """
        Constructor for GenericAreaGroup.
        
        :param dtype: Device type
        :param name: Name of the group
        :param idtag: ID tag
        :param code: Code
        """
    @property
    def latitude(self) -> float:
        """
        Latitude of the area group.
        
        :getter: Get the latitude.
        :setter: Set the latitude.
        """
    @latitude.setter
    def latitude(self, arg1: float) -> None:
        ...
    @property
    def longitude(self) -> float:
        """
        Longitude of the area group.
        
        :getter: Get the longitude.
        :setter: Set the longitude.
        """
    @longitude.setter
    def longitude(self, arg1: float) -> None:
        ...
class HashMapsize_t_double:
    pass
class HvdcControlType:
    """
    Members:
    
      type_0_free
    
      type_1_Pset
    """
    __members__: typing.ClassVar[dict[str, HvdcControlType]]  # value = {'type_0_free': <HvdcControlType.type_0_free: 0>, 'type_1_Pset': <HvdcControlType.type_1_Pset: 1>}
    type_0_free: typing.ClassVar[HvdcControlType]  # value = <HvdcControlType.type_0_free: 0>
    type_1_Pset: typing.ClassVar[HvdcControlType]  # value = <HvdcControlType.type_1_Pset: 1>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class HvdcData(BranchParentData):
    Pset: Numpy.ndarray[]
    Pt: Numpy.ndarray[]
    Qmax_f: Numpy.ndarray[]
    Qmax_t: Numpy.ndarray[]
    Qmin_f: Numpy.ndarray[]
    Qmin_t: Numpy.ndarray[]
    Vnf: Numpy.ndarray[]
    Vnt: Numpy.ndarray[]
    Vset_f: Numpy.ndarray[]
    Vset_t: Numpy.ndarray[]
    angle_droop: Numpy.ndarray[]
    control_mode: list[HvdcControlType]
    dispatchable: Numpy.ndarray[]
    r: Numpy.ndarray[]
    def __init__(self, arg0: int, arg1: int) -> None:
        ...
class HvdcLine(BranchParent):
    def __init__(self, nt: int = 1, bus_from: Bus = None, bus_to: Bus = None, name: str = 'HVDC Line', idtag: str = '', active: bool = True, code: str = '', rate: float = 1.0, pset: float = 0.0, r: float = 1e-20, loss_factor: float = 0.0, Vset_f: float = 1.0, Vset_t: float = 1.0, length: float = 1.0, mttf: float = 0.0, mttr: float = 0.0, overload_cost: float = 1000.0, min_firing_angle_f: float = -1.0, max_firing_angle_f: float = 1.0, min_firing_angle_t: float = -1.0, max_firing_angle_t: float = 1.0, contingency_factor: float = 1.0, protection_rating_factor: float = 1.4, control_mode: HvdcControlType = ..., dispatchable: bool = True, angle_droop: float = 0.0, capex: float = 0.0, opex: float = 0.0, build_status: BuildStatus = ..., dc_link_voltage: float = 200.0) -> None:
        """
        Constructor for HvdcLine.
        
        :param nt: Number of simulation timesteps.
        :param bus_from: Pointer to the *from* AC bus.
        :param bus_to: Pointer to the *to* AC bus.
        :param name: Human-readable line name.
        :param idtag: Stable unique identifier tag.
        :param active: Initial active state profile.
        :param code: Engineering code or label.
        :param rate: Continuous power rating **P<sub>max</sub>** (MW).
        :param pset: Active-power set-point **P<sub>set</sub>** (MW).
        :param r: DC resistance of the link (Ω).
        :param loss_factor: Fractional loss factor (0 – 1).
        :param Vset_f: DC voltage set-point at the front converter (pu).
        :param Vset_t: DC voltage set-point at the terminal converter (pu).
        :param length: Physical line length (km).
        :param mttf: Mean time to failure (h).
        :param mttr: Mean time to repair (h).
        :param overload_cost: Penalty cost for overloads (cost units/MW).
        :param min_firing_angle_f: Minimum firing angle at front converter (deg).
        :param max_firing_angle_f: Maximum firing angle at front converter (deg).
        :param min_firing_angle_t: Minimum firing angle at terminal converter (deg).
        :param max_firing_angle_t: Maximum firing angle at terminal converter (deg).
        :param contingency_factor: Multiplicative contingency rating factor.
        :param protection_rating_factor: Protection-based rating factor.
        :param control_mode: HVDC control strategy enumeration.
        :param dispatchable: Whether the link can be redispatched by optimisation.
        :param angle_droop: Angle-droop control coefficient (deg/MW).
        :param capex: Capital expenditure (currency units).
        :param opex: Annual operating expenditure (currency units).
        :param build_status: Construction / service status enumeration.
        :param dc_link_voltage: Nominal DC link voltage (kV).
        """
    def set_Pset_val(self, val: float) -> None:
        """
        Set *Pset* to a single value (MW) across all timesteps.
        """
    def set_Vset_f_val(self, val: float) -> None:
        """
        Set *Vset_f* to a single value (pu) across all timesteps.
        """
    def set_Vset_t_val(self, val: float) -> None:
        """
        Set *Vset_t* to a single value (pu) across all timesteps.
        """
    def set_angle_droop_val(self, val: float) -> None:
        """
        Set *angle_droop* to a single value (deg/MW) across all timesteps.
        """
    @property
    def Pset(self) -> Profiledouble:
        """
        Active-power set-point profile (MW).
        """
    @Pset.setter
    def Pset(self, arg1: Profiledouble) -> None:
        ...
    @property
    def Vset_f(self) -> Profiledouble:
        """
        Front-converter voltage set-point profile (pu).
        """
    @Vset_f.setter
    def Vset_f(self, arg1: Profiledouble) -> None:
        ...
    @property
    def Vset_t(self) -> Profiledouble:
        """
        Terminal-converter voltage set-point profile (pu).
        """
    @Vset_t.setter
    def Vset_t(self, arg1: Profiledouble) -> None:
        ...
    @property
    def angle_droop(self) -> Profiledouble:
        """
        Angle-droop control coefficient profile (deg/MW).
        """
    @angle_droop.setter
    def angle_droop(self, arg1: Profiledouble) -> None:
        ...
    @property
    def build_status(self) -> BuildStatus:
        """
        Construction / service status.
        """
    @build_status.setter
    def build_status(self, arg1: BuildStatus) -> None:
        ...
    @property
    def capex(self) -> float:
        """
        Capital expenditure (currency units).
        """
    @capex.setter
    def capex(self, arg1: float) -> None:
        ...
    @property
    def control_mode(self) -> HvdcControlType:
        """
        HVDC control strategy enumeration.
        """
    @control_mode.setter
    def control_mode(self, arg1: HvdcControlType) -> None:
        ...
    @property
    def dc_link_voltage(self) -> float:
        """
        DC link voltage (kV).
        """
    @dc_link_voltage.setter
    def dc_link_voltage(self, arg1: float) -> None:
        ...
    @property
    def dispatchable(self) -> bool:
        """
        Dispatchable status of the link.
        """
    @dispatchable.setter
    def dispatchable(self, arg1: bool) -> None:
        ...
    @property
    def length(self) -> float:
        """
        Physical line length (km).
        """
    @length.setter
    def length(self, arg1: float) -> None:
        ...
    @property
    def loss_factor(self) -> float:
        """
        Fractional loss factor (0 – 1).
        """
    @loss_factor.setter
    def loss_factor(self, arg1: float) -> None:
        ...
    @property
    def max_firing_angle_f(self) -> float:
        """
        Maximum firing angle at front converter (deg).
        """
    @max_firing_angle_f.setter
    def max_firing_angle_f(self, arg1: float) -> None:
        ...
    @property
    def max_firing_angle_t(self) -> float:
        """
        Maximum firing angle at terminal converter (deg).
        """
    @max_firing_angle_t.setter
    def max_firing_angle_t(self, arg1: float) -> None:
        ...
    @property
    def min_firing_angle_f(self) -> float:
        """
        Minimum firing angle at front converter (deg).
        """
    @min_firing_angle_f.setter
    def min_firing_angle_f(self, arg1: float) -> None:
        ...
    @property
    def min_firing_angle_t(self) -> float:
        """
        Minimum firing angle at terminal converter (deg).
        """
    @min_firing_angle_t.setter
    def min_firing_angle_t(self, arg1: float) -> None:
        ...
    @property
    def mttf(self) -> float:
        """
        Mean time to failure (h).
        """
    @mttf.setter
    def mttf(self, arg1: float) -> None:
        ...
    @property
    def mttr(self) -> float:
        """
        Mean time to repair (h).
        """
    @mttr.setter
    def mttr(self, arg1: float) -> None:
        ...
    @property
    def opex(self) -> float:
        """
        Annual operating expenditure (currency units).
        """
    @opex.setter
    def opex(self, arg1: float) -> None:
        ...
    @property
    def r(self) -> float:
        """
        DC resistance of the link (Ω).
        """
    @r.setter
    def r(self, arg1: float) -> None:
        ...
class InjectionParent(PhysicalDevice):
    def __init__(self, nt: int, name: str, idtag: str, code: str, bus: ..., active: bool, cost: float, mttf: float, mttr: float, capex: float, opex: float, build_status: BuildStatus, device_type: DeviceType) -> None:
        """
        Constructor for InjectionParent.
        
        :param nt: Number of timesteps
        :param name: Name of the injection device
        :param idtag: ID tag for the injection device
        :param code: Code for the injection device
        :param bus: Associated bus
        :param active: Active state
        :param cost: Cost profile
        :param mttf: Mean time to failure
        :param mttr: Mean time to repair
        :param capex: Capital expenditure
        :param opex: Operational expenditure
        :param build_status: Build status
        :param device_type: Device type
        """
    def set_active_val(self, val: bool) -> None:
        """
        Set the active state value.
        """
    def set_cost_val(self, val: float) -> None:
        """
        Set the cost value.
        """
    @property
    def active(self) -> Profilebool:
        """
        The active state profile.
        """
    @active.setter
    def active(self, arg1: Profilebool) -> None:
        ...
    @property
    def build_status(self) -> BuildStatus:
        """
        Build status of the injection device.
        """
    @build_status.setter
    def build_status(self, arg1: BuildStatus) -> None:
        ...
    @property
    def bus(self) -> ...:
        """
        The associated bus.
        """
    @bus.setter
    def bus(self, arg1: ...) -> None:
        ...
    @property
    def capex(self) -> float:
        """
        Capital expenditure.
        """
    @capex.setter
    def capex(self, arg1: float) -> None:
        ...
    @property
    def cost(self) -> Profiledouble:
        """
        The cost profile.
        """
    @cost.setter
    def cost(self, arg1: Profiledouble) -> None:
        ...
    @property
    def facility(self) -> ...:
        """
        Associated facility.
        """
    @facility.setter
    def facility(self, arg1: ...) -> None:
        ...
    @property
    def mttf(self) -> float:
        """
        Mean time to failure.
        """
    @mttf.setter
    def mttf(self, arg1: float) -> None:
        ...
    @property
    def mttr(self) -> float:
        """
        Mean time to repair.
        """
    @mttr.setter
    def mttr(self, arg1: float) -> None:
        ...
    @property
    def opex(self) -> float:
        """
        Operational expenditure.
        """
    @opex.setter
    def opex(self, arg1: float) -> None:
        ...
    @property
    def technologies(self) -> ...:
        """
        Associated technologies.
        """
    @technologies.setter
    def technologies(self, arg1: ...) -> None:
        ...
class Investment(EditableDevice):
    def __init__(self, idtag: str = '', device_idtag: str = '', name: str = '', code: str = '', CAPEX: float = 0.0, OPEX: float = 0.0, status: bool = True, group: InvestmentGroup = None) -> None:
        """
        Constructor for Investment.
        
        :param idtag: Investment ID tag
        :param device_idtag: Device ID tag
        :param name: Name of the investment
        :param code: Code for the investment
        :param CAPEX: Capital expenditure
        :param OPEX: Operational expenditure
        :param status_: Investment status (active or not)
        :param group: Pointer to the associated InvestmentGroup
        """
    @property
    def CAPEX(self) -> float:
        """
        Capital expenditure of the investment.
        
        :getter: Get the CAPEX.
        :setter: Set the CAPEX.
        """
    @CAPEX.setter
    def CAPEX(self, arg1: float) -> None:
        ...
    @property
    def OPEX(self) -> float:
        """
        Operational expenditure of the investment.
        
        :getter: Get the OPEX.
        :setter: Set the OPEX.
        """
    @OPEX.setter
    def OPEX(self, arg1: float) -> None:
        ...
    @property
    def device_idtag(self) -> str:
        """
        Device ID tag associated with the investment.
        
        :getter: Get the device ID tag.
        :setter: Set the device ID tag.
        """
    @device_idtag.setter
    def device_idtag(self, arg1: str) -> None:
        ...
    @property
    def group(self) -> InvestmentGroup:
        """
        Pointer to the associated InvestmentGroup.
        
        :getter: Get the investment group pointer.
        :setter: Set the investment group pointer.
        """
    @group.setter
    def group(self, arg1: InvestmentGroup) -> None:
        ...
    @property
    def status(self) -> bool:
        """
        Status of the investment (active or inactive).
        
        :getter: Check if the investment is active.
        :setter: Set the investment status.
        """
    @status.setter
    def status(self, arg1: bool) -> None:
        ...
class InvestmentEvaluationMethod:
    """
    Members:
    
      Independent
    
      Hyperopt
    
      MVRSM
    
      NSGA3
    
      Random
    
      MixedVariableGA
    
      FromPlugin
    """
    FromPlugin: typing.ClassVar[InvestmentEvaluationMethod]  # value = <InvestmentEvaluationMethod.FromPlugin: 6>
    Hyperopt: typing.ClassVar[InvestmentEvaluationMethod]  # value = <InvestmentEvaluationMethod.Hyperopt: 1>
    Independent: typing.ClassVar[InvestmentEvaluationMethod]  # value = <InvestmentEvaluationMethod.Independent: 0>
    MVRSM: typing.ClassVar[InvestmentEvaluationMethod]  # value = <InvestmentEvaluationMethod.MVRSM: 2>
    MixedVariableGA: typing.ClassVar[InvestmentEvaluationMethod]  # value = <InvestmentEvaluationMethod.MixedVariableGA: 5>
    NSGA3: typing.ClassVar[InvestmentEvaluationMethod]  # value = <InvestmentEvaluationMethod.NSGA3: 3>
    Random: typing.ClassVar[InvestmentEvaluationMethod]  # value = <InvestmentEvaluationMethod.Random: 4>
    __members__: typing.ClassVar[dict[str, InvestmentEvaluationMethod]]  # value = {'Independent': <InvestmentEvaluationMethod.Independent: 0>, 'Hyperopt': <InvestmentEvaluationMethod.Hyperopt: 1>, 'MVRSM': <InvestmentEvaluationMethod.MVRSM: 2>, 'NSGA3': <InvestmentEvaluationMethod.NSGA3: 3>, 'Random': <InvestmentEvaluationMethod.Random: 4>, 'MixedVariableGA': <InvestmentEvaluationMethod.MixedVariableGA: 5>, 'FromPlugin': <InvestmentEvaluationMethod.FromPlugin: 6>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class InvestmentGroup(EditableDevice):
    def __init__(self, name: str = '', idtag: str = '', code: str = '', category: str = '') -> None:
        """
        Constructor for InvestmentGroup.
        
        :param name: Name of the investment group
        :param idtag: ID tag for the group
        :param code: Code for the group
        :param category: Category of the investment group
        """
    @property
    def category(self) -> str:
        """
        Category of the investment group.
        
        :getter: Get the category.
        :setter: Set the category.
        """
    @category.setter
    def category(self, arg1: str) -> None:
        ...
class InvestmentsEvaluationObjectives:
    """
    Members:
    
      PowerFlow
    
      TimeSeriesPowerFlow
    
      OptimalPowerFlow
    
      TimeSeriesOptimalPowerFlow
    
      FromPlugin
    """
    FromPlugin: typing.ClassVar[InvestmentsEvaluationObjectives]  # value = <InvestmentsEvaluationObjectives.FromPlugin: 4>
    OptimalPowerFlow: typing.ClassVar[InvestmentsEvaluationObjectives]  # value = <InvestmentsEvaluationObjectives.OptimalPowerFlow: 2>
    PowerFlow: typing.ClassVar[InvestmentsEvaluationObjectives]  # value = <InvestmentsEvaluationObjectives.PowerFlow: 0>
    TimeSeriesOptimalPowerFlow: typing.ClassVar[InvestmentsEvaluationObjectives]  # value = <InvestmentsEvaluationObjectives.TimeSeriesOptimalPowerFlow: 3>
    TimeSeriesPowerFlow: typing.ClassVar[InvestmentsEvaluationObjectives]  # value = <InvestmentsEvaluationObjectives.TimeSeriesPowerFlow: 1>
    __members__: typing.ClassVar[dict[str, InvestmentsEvaluationObjectives]]  # value = {'PowerFlow': <InvestmentsEvaluationObjectives.PowerFlow: 0>, 'TimeSeriesPowerFlow': <InvestmentsEvaluationObjectives.TimeSeriesPowerFlow: 1>, 'OptimalPowerFlow': <InvestmentsEvaluationObjectives.OptimalPowerFlow: 2>, 'TimeSeriesOptimalPowerFlow': <InvestmentsEvaluationObjectives.TimeSeriesOptimalPowerFlow: 3>, 'FromPlugin': <InvestmentsEvaluationObjectives.FromPlugin: 4>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class JobStatus:
    """
    Members:
    
      Done
    
      Running
    
      Failed
    
      Waiting
    
      Cancelled
    """
    Cancelled: typing.ClassVar[JobStatus]  # value = <JobStatus.Cancelled: 4>
    Done: typing.ClassVar[JobStatus]  # value = <JobStatus.Done: 0>
    Failed: typing.ClassVar[JobStatus]  # value = <JobStatus.Failed: 2>
    Running: typing.ClassVar[JobStatus]  # value = <JobStatus.Running: 1>
    Waiting: typing.ClassVar[JobStatus]  # value = <JobStatus.Waiting: 3>
    __members__: typing.ClassVar[dict[str, JobStatus]]  # value = {'Done': <JobStatus.Done: 0>, 'Running': <JobStatus.Running: 1>, 'Failed': <JobStatus.Failed: 2>, 'Waiting': <JobStatus.Waiting: 3>, 'Cancelled': <JobStatus.Cancelled: 4>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class LicenseResponse:
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def active(self) -> bool:
        """
        Indicates if the license is active.
        """
    @active.setter
    def active(self, arg0: bool) -> None:
        ...
    @property
    def msg(self) -> str:
        """
        Message associated with the license response.
        """
    @msg.setter
    def msg(self, arg0: str) -> None:
        ...
class Line(BranchParent):
    def __init__(self, nt: int, name: str = 'Line', idtag: str = '', code: str = '', bus_from: Bus = None, bus_to: Bus = None, r: float = 1e-20, x: float = 1e-05, b: float = 1e-20, rate: float = 1.0, active: bool = True, tolerance: float = 0.0, cost: float = 100.0, mttf: float = 0.0, mttr: float = 0.0, r_fault: float = 0.0, x_fault: float = 0.0, fault_pos: float = 0.5, length: float = 1.0, temp_base: float = 20.0, temp_oper: float = 20.0, alpha: float = 0.0033, overhead_template: OverheadLineType = None, underground_template: UndergroundLineType = None, sequence_template: SequenceLineType = None, contingency_factor: float = 1.0, protection_rating_factor: float = 1.4, monitor_loading: bool = True, r0: float = 1e-20, x0: float = 1e-20, b0: float = 1e-20, r2: float = 1e-20, x2: float = 1e-20, b2: float = 1e-20, capex: float = 0.0, opex: float = 0.0, build_status: BuildStatus = ...) -> None:
        """
        Constructor for Line.
        
        :param nt: Number of simulation timesteps.
        :param name: Human-readable line name.
        :param idtag: Stable unique identifier tag.
        :param code: Engineering code or label.
        :param bus_from: Pointer to the *from* bus.
        :param bus_to: Pointer to the *to* bus.
        :param r: Positive-sequence series resistance **R** (Ω/km).
        :param x: Positive-sequence series reactance **X** (Ω/km).
        :param b: Positive-sequence shunt susceptance **B/2** (µS/km).
        :param rate: Continuous thermal rating **I<sub>max</sub>** (kA).
        :param active: Initial active state profile.
        :param tolerance: Power-flow convergence tolerance (pu).
        :param cost: Operating cost per unit energy or time.
        :param mttf: Mean time to failure (h).
        :param mttr: Mean time to repair (h).
        :param r_fault: Fault resistance (Ω).
        :param x_fault: Fault reactance (Ω).
        :param fault_pos: Fault position as fraction (0 – 1) of line length.
        :param length: Physical line length (km).
        :param temp_base: Reference temperature for *R* values (°C).
        :param temp_oper: Operating temperature profile (°C).
        :param alpha: Temperature coefficient of resistance (1/°C).
        :param overhead_template: Pointer to overhead-line type template.
        :param underground_template: Pointer to underground-line type template.
        :param sequence_template: Pointer to sequence-line type template.
        :param contingency_factor: Multiplicative contingency rating factor.
        :param protection_rating_factor: Protection-based rating factor.
        :param monitor_loading: Enable automatic loading alarms.
        :param r0: Zero-sequence resistance **R₀** (Ω/km).
        :param x0: Zero-sequence reactance **X₀** (Ω/km).
        :param b0: Zero-sequence susceptance **B₀/2** (µS/km).
        :param r2: Negative-sequence resistance **R₂** (Ω/km).
        :param x2: Negative-sequence reactance **X₂** (Ω/km).
        :param b2: Negative-sequence susceptance **B₂/2** (µS/km).
        :param capex: Capital expenditure (currency units).
        :param opex: Annual operating expenditure (currency units).
        :param build_status: Construction / service status enumeration.
        """
    @property
    def B(self) -> float:
        """
        Positive-sequence susceptance **B/2** (µS/km).
        """
    @B.setter
    def B(self, arg1: float) -> None:
        ...
    @property
    def B0(self) -> float:
        """
        Zero-sequence susceptance **B₀/2** (µS/km).
        """
    @B0.setter
    def B0(self, arg1: float) -> None:
        ...
    @property
    def B2(self) -> float:
        """
        Negative-sequence susceptance **B₂/2** (µS/km).
        """
    @B2.setter
    def B2(self, arg1: float) -> None:
        ...
    @property
    def R(self) -> float:
        """
        Positive-sequence resistance **R** (Ω/km).
        """
    @R.setter
    def R(self, arg1: float) -> None:
        ...
    @property
    def R0(self) -> float:
        """
        Zero-sequence resistance **R₀** (Ω/km).
        """
    @R0.setter
    def R0(self, arg1: float) -> None:
        ...
    @property
    def R2(self) -> float:
        """
        Negative-sequence resistance **R₂** (Ω/km).
        """
    @R2.setter
    def R2(self, arg1: float) -> None:
        ...
    @property
    def X(self) -> float:
        """
        Positive-sequence reactance **X** (Ω/km).
        """
    @X.setter
    def X(self, arg1: float) -> None:
        ...
    @property
    def X0(self) -> float:
        """
        Zero-sequence reactance **X₀** (Ω/km).
        """
    @X0.setter
    def X0(self, arg1: float) -> None:
        ...
    @property
    def X2(self) -> float:
        """
        Negative-sequence reactance **X₂** (Ω/km).
        """
    @X2.setter
    def X2(self, arg1: float) -> None:
        ...
    @property
    def alpha(self) -> float:
        """
        Temperature coefficient of resistance (1/°C).
        """
    @alpha.setter
    def alpha(self, arg1: float) -> None:
        ...
    @property
    def fault_pos(self) -> float:
        """
        Fault position as fraction (0 – 1) of line length.
        """
    @fault_pos.setter
    def fault_pos(self, arg1: float) -> None:
        ...
    @property
    def length(self) -> float:
        """
        Length of the line (km).
        """
    @length.setter
    def length(self, arg1: float) -> None:
        ...
    @property
    def overhead_template(self) -> OverheadLineType:
        """
        Associated overhead-line type template.
        """
    @overhead_template.setter
    def overhead_template(self, arg1: OverheadLineType) -> None:
        ...
    @property
    def possible_sequence_line_types(self) -> Associations:
        """
        Possible sequence line types for the line.
        """
    @possible_sequence_line_types.setter
    def possible_sequence_line_types(self, arg1: Associations) -> None:
        ...
    @property
    def possible_tower_types(self) -> Associations:
        """
        Possible tower types for the line.
        """
    @possible_tower_types.setter
    def possible_tower_types(self, arg1: Associations) -> None:
        ...
    @property
    def possible_underground_line_types(self) -> Associations:
        """
        Possible underground line types for the line.
        """
    @possible_underground_line_types.setter
    def possible_underground_line_types(self, arg1: Associations) -> None:
        ...
    @property
    def r_fault(self) -> float:
        """
        Fault resistance (Ω).
        """
    @r_fault.setter
    def r_fault(self, arg1: float) -> None:
        ...
    @property
    def sequence_template(self) -> SequenceLineType:
        """
        Associated sequence-line type template.
        """
    @sequence_template.setter
    def sequence_template(self, arg1: SequenceLineType) -> None:
        ...
    @property
    def temp_base(self) -> float:
        """
        Reference temperature for resistance (°C).
        """
    @temp_base.setter
    def temp_base(self, arg1: float) -> None:
        ...
    @property
    def temp_oper(self) -> Profiledouble:
        """
        Operating temperature profile (°C).
        """
    @temp_oper.setter
    def temp_oper(self, arg1: Profiledouble) -> None:
        ...
    @property
    def tolerance(self) -> float:
        """
        Power-flow convergence tolerance (pu).
        """
    @tolerance.setter
    def tolerance(self, arg1: float) -> None:
        ...
    @property
    def underground_template(self) -> UndergroundLineType:
        """
        Associated underground-line type template.
        """
    @underground_template.setter
    def underground_template(self, arg1: UndergroundLineType) -> None:
        ...
    @property
    def x_fault(self) -> float:
        """
        Fault reactance (Ω).
        """
    @x_fault.setter
    def x_fault(self, arg1: float) -> None:
        ...
class LinearAdmittanceMatrices:
    def __init__(self, Bbus: scipy.sparse.csc_matrix, Bf: scipy.sparse.csc_matrix) -> None:
        ...
    def get_Bred(self, pqpv: Numpy.ndarray[]) -> scipy.sparse.csc_matrix:
        ...
    def get_Bslack(self, pqpv: Numpy.ndarray[], vd: Numpy.ndarray[]) -> scipy.sparse.csc_matrix:
        ...
    @property
    def Bbus(self) -> scipy.sparse.csc_matrix:
        ...
    @property
    def Bf(self) -> scipy.sparse.csc_matrix:
        ...
class LinearAnalysis:
    def __init__(self, nc: NumericalCircuit, distributed_slack_: bool, correct_values_: bool) -> None:
        ...
    @typing.overload
    def get_flows(self, Sbus: Numpy.ndarray[]) -> Numpy.ndarray[]:
        ...
    @typing.overload
    def get_flows(self, Sbus: Numpy.ndarray[]) -> Numpy.ndarray[]:
        ...
    @property
    def LODF(self) -> Numpy.ndarray[]:
        ...
    @property
    def PTDF(self) -> Numpy.ndarray[]:
        ...
    @property
    def logger(self) -> Logger:
        ...
class LinearAnalysisOptions:
    correct_values: bool
    distribute_slack: bool
    lodf_threshold: float
    ptdf_threshold: float
    def __init__(self, distributeSlack: bool = False, correctValues: bool = True, ptdfThreshold: float = 0.001, lodfThreshold: float = 0.001) -> None:
        ...
class LinearMultiContingencies:
    def __init__(self, grid: MultiCircuit, contingency_groups_used_: list[ContingencyGroup]) -> None:
        ...
    def compute(self, lodf: Numpy.ndarray[], ptdf: Numpy.ndarray[], ptdf_threshold: float, lodf_threshold: float) -> None:
        ...
    def queryGroup(self, cg: ContingencyGroup) -> list[Contingency]:
        ...
    @property
    def contingency_group_dict(self) -> dict[str, list[Contingency]]:
        ...
    @property
    def contingency_groups_used(self) -> list[ContingencyGroup]:
        ...
    @property
    def contingency_indices_list(self) -> list[ContingencyIndices]:
        ...
    @property
    def multi_contingencies(self) -> list[LinearMultiContingency]:
        ...
class LinearMultiContingency:
    def __init__(self, branch_indices_: Numpy.ndarray[], bus_indices_: Numpy.ndarray[], mlodf_factors_: scipy.sparse.csc_matrix, compensated_ptdf_factors_: scipy.sparse.csc_matrix, injections_factor_: Numpy.ndarray[]) -> None:
        ...
    @typing.overload
    def get_contingency_flows(self, arg0: Numpy.ndarray[], arg1: Numpy.ndarray[]) -> Numpy.ndarray[]:
        ...
    @typing.overload
    def get_contingency_flows(self, arg0: Numpy.ndarray[]) -> Numpy.ndarray[]:
        ...
    def has_injection_contingencies(self) -> bool:
        ...
class Load(LoadParent):
    def __init__(self, nt: int, bus: Bus = None, name: str = 'Load', idtag: str = '', code: str = '', G: float = 0.0, B: float = 0.0, Ir: float = 0.0, Ii: float = 0.0, P: float = 0.0, Q: float = 0.0, Cost: float = 1200.0, active: bool = True, mttf: float = 0.0, mttr: float = 0.0, capex: float = 0.0, opex: float = 0.0, build_status: BuildStatus = ...) -> None:
        """
        Constructor for Load.
        
        :param nt: Number of simulation timesteps.
        :param bus: Pointer to the connected AC bus.
        :param name: Human-readable load name.
        :param idtag: Stable unique identifier tag.
        :param code: Engineering code or label.
        :param G/B: Conductance and susceptance profiles (MW / MVAr).
        :param Ir/Ii: Real and imaginary current profiles (pu).
        :param P/Q: Constant-power components of the load (MW / MVAr).
        :param Cost: Operating cost per unit energy.
        :param active: Whether the load is energised in the base case.
        :param mttf/mttr: Mean time to failure / repair (h).
        :param capex/opex: Capital and annual operating expenditure.
        :param build_status: Construction / service status enumeration.
        """
    def set_B_val(self, val: float) -> None:
        """
        Set scalar value for susceptance profile.
        """
    def set_G_val(self, val: float) -> None:
        """
        Set scalar value for conductance profile.
        """
    def set_Ii_val(self, val: float) -> None:
        """
        Set scalar value for imaginary current profile.
        """
    def set_Ir_val(self, val: float) -> None:
        """
        Set scalar value for real current profile.
        """
    @property
    def B(self) -> Profiledouble:
        """
        Profile for susceptance in MVAr.
        """
    @B.setter
    def B(self, arg1: Profiledouble) -> None:
        ...
    @property
    def G(self) -> Profiledouble:
        """
        Profile for conductance in MW.
        """
    @G.setter
    def G(self, arg1: Profiledouble) -> None:
        ...
    @property
    def Ii(self) -> Profiledouble:
        """
        Profile for imaginary current in MVAr.
        """
    @Ii.setter
    def Ii(self, arg1: Profiledouble) -> None:
        ...
    @property
    def Ir(self) -> Profiledouble:
        """
        Profile for real current in MW.
        """
    @Ir.setter
    def Ir(self, arg1: Profiledouble) -> None:
        ...
class LoadData:
    I: Numpy.ndarray[]
    S: Numpy.ndarray[]
    Y: Numpy.ndarray[]
    active: Numpy.ndarray[]
    bus_idx: Numpy.ndarray[]
    cost: Numpy.ndarray[]
    idtag: list[str]
    mttf: Numpy.ndarray[]
    mttr: Numpy.ndarray[]
    names: list[str]
    nbus: int
    nelm: int
    original_idx: Numpy.ndarray[]
    def __init__(self, arg0: int, arg1: int) -> None:
        ...
class LoadParent(InjectionParent):
    def __init__(self, nt: int, name: str, idtag: str, code: str, bus: ..., active: bool, P: float, Q: float, cost: float, mttf: float, mttr: float, capex: float, opex: float, build_status: BuildStatus, device_type: DeviceType) -> None:
        """
        Constructor for LoadParent.
        
        :param nt: Number of timesteps
        :param name: Name of the load
        :param idtag: ID tag for the load
        :param code: Code for the load
        :param bus: Associated bus
        :param active: Active state
        :param P: Active power (MW)
        :param Q: Reactive power (MVAr)
        :param cost: Cost profile
        :param mttf: Mean time to failure
        :param mttr: Mean time to repair
        :param capex: Capital expenditure
        :param opex: Operational expenditure
        :param build_status: Build status
        :param device_type: Device type
        """
    def set_P_val(self, val: float) -> None:
        """
        Set the active power value.
        
        :param val: Active power value (MW).
        """
    def set_Q_val(self, val: float) -> None:
        """
        Set the reactive power value.
        
        :param val: Reactive power value (MVAr).
        """
    @property
    def P(self) -> Profiledouble:
        """
        Active power profile (MW).
        
        :getter: Get the active power profile.
        :setter: Set the active power profile.
        """
    @P.setter
    def P(self, arg1: Profiledouble) -> None:
        ...
    @property
    def Q(self) -> Profiledouble:
        """
        Reactive power profile (MVAr).
        
        :getter: Get the reactive power profile.
        :setter: Set the reactive power profile.
        """
    @Q.setter
    def Q(self, arg1: Profiledouble) -> None:
        ...
class LogEntry:
    device: str
    device_class: str
    device_property: str
    expected_value: str
    msg: str
    severity: LogSeverity
    time: str
    value: str
    def __init__(self, time: str = '', msg: str = '', severity: LogSeverity = ..., device: str = '', value: str = '', expected_value: str = '', device_class: str = '', device_property: str = '') -> None:
        ...
    def toString(self) -> str:
        """
        Get string representation of the log entry.
        """
    def to_list(self) -> list[str]:
        """
        Get the list representation of the log entry.
        """
    def to_list_reduced(self) -> list[str]:
        """
        Get a reduced list representation of the log entry.
        """
class LogSeverity:
    """
    Members:
    
      Error
    
      Warning
    
      Information
    
      Divergence
    """
    Divergence: typing.ClassVar[LogSeverity]  # value = <LogSeverity.Divergence: 3>
    Error: typing.ClassVar[LogSeverity]  # value = <LogSeverity.Error: 0>
    Information: typing.ClassVar[LogSeverity]  # value = <LogSeverity.Information: 2>
    Warning: typing.ClassVar[LogSeverity]  # value = <LogSeverity.Warning: 1>
    __members__: typing.ClassVar[dict[str, LogSeverity]]  # value = {'Error': <LogSeverity.Error: 0>, 'Warning': <LogSeverity.Warning: 1>, 'Information': <LogSeverity.Information: 2>, 'Divergence': <LogSeverity.Divergence: 3>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Logger:
    def __init__(self) -> None:
        ...
    def add_divergence(self, msg: str, device: str = '', value: float = 0.0, expected_value: float = 0.0, tol: float = 1e-06) -> None:
        """
        Add a divergence log entry.
        """
    def add_error(self, msg: str, device: str = '', value: str = '', expected_value: str = '', device_class: str = '', comment: str = '', device_property: str = '') -> None:
        """
        Add an error log entry.
        """
    def add_info(self, msg: str, device: str = '', value: str = '', expected_value: str = '', device_class: str = '', comment: str = '', device_property: str = '') -> None:
        """
        Add an info log entry.
        """
    def add_warning(self, msg: str, device: str = '', value: str = '', expected_value: str = '', device_class: str = '', comment: str = '', device_property: str = '') -> None:
        """
        Add a warning log entry.
        """
    def append(self, txt: str) -> None:
        """
        Append a log entry.
        """
    def has_logs(self) -> bool:
        """
        Check if there are logs.
        """
    def print(self) -> None:
        """
        Print all log entries.
        """
    def to_dict(self) -> dict[str, dict[str, list[tuple[str, str, str, str]]]]:
        """
        Convert logs to a dictionary.
        """
    @property
    def debug_entries(self) -> list[str]:
        """
        List of entries
        """
    @property
    def entries(self) -> list[LogEntry]:
        """
        List of entries
        """
class LpConstraintType:
    """
    Members:
    
      LEQ
    
      GEQ
    
      EQ
    """
    EQ: typing.ClassVar[LpConstraintType]  # value = <LpConstraintType.EQ: 2>
    GEQ: typing.ClassVar[LpConstraintType]  # value = <LpConstraintType.GEQ: 1>
    LEQ: typing.ClassVar[LpConstraintType]  # value = <LpConstraintType.LEQ: 0>
    __members__: typing.ClassVar[dict[str, LpConstraintType]]  # value = {'LEQ': <LpConstraintType.LEQ: 0>, 'GEQ': <LpConstraintType.GEQ: 1>, 'EQ': <LpConstraintType.EQ: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class LpCst:
    def __repr__(self, arg0: list[LpVar]) -> str:
        ...
    def __str__(self, arg0: list[LpVar]) -> str:
        ...
    @property
    def expr(self) -> LpExp:
        ...
    @property
    def idx(self) -> int:
        ...
    @property
    def sense(self) -> LpConstraintType:
        ...
    @property
    def val(self) -> float:
        ...
    @property
    def val_total(self) -> float:
        ...
class LpExp:
    __hash__: typing.ClassVar[None] = None
    offset: float
    @typing.overload
    def __add__(self, arg0: LpExp) -> LpExp:
        ...
    @typing.overload
    def __add__(self, arg0: LpVar) -> LpExp:
        ...
    @typing.overload
    def __add__(self, arg0: float) -> LpExp:
        ...
    @typing.overload
    def __eq__(self, arg0: LpExp) -> ...:
        ...
    @typing.overload
    def __eq__(self, arg0: LpVar) -> ...:
        ...
    @typing.overload
    def __eq__(self, arg0: float) -> ...:
        ...
    @typing.overload
    def __ge__(self, arg0: LpExp) -> ...:
        ...
    @typing.overload
    def __ge__(self, arg0: LpVar) -> ...:
        ...
    @typing.overload
    def __ge__(self, arg0: float) -> ...:
        ...
    @typing.overload
    def __iadd__(self, arg0: LpExp) -> LpExp:
        ...
    @typing.overload
    def __iadd__(self, arg0: LpVar) -> LpExp:
        ...
    @typing.overload
    def __iadd__(self, arg0: float) -> LpExp:
        ...
    def __imul__(self, arg0: float) -> LpExp:
        ...
    def __init__(self) -> None:
        ...
    @typing.overload
    def __isub__(self, arg0: LpExp) -> LpExp:
        ...
    @typing.overload
    def __isub__(self, arg0: LpVar) -> LpExp:
        ...
    @typing.overload
    def __isub__(self, arg0: float) -> LpExp:
        ...
    def __itruediv__(self, arg0: float) -> LpExp:
        ...
    @typing.overload
    def __le__(self, arg0: LpExp) -> ...:
        ...
    @typing.overload
    def __le__(self, arg0: LpVar) -> ...:
        ...
    @typing.overload
    def __le__(self, arg0: float) -> ...:
        ...
    def __mul__(self, arg0: float) -> LpExp:
        ...
    def __neg__(self) -> LpExp:
        ...
    def __radd__(self, arg0: float) -> LpExp:
        ...
    def __repr__(self, arg0: list[LpVar], arg1: bool) -> str:
        ...
    def __req__(self, arg0: float) -> ...:
        ...
    def __rge__(self, arg0: float) -> ...:
        ...
    def __rle__(self, arg0: float) -> ...:
        ...
    def __rmul__(self, arg0: float) -> LpExp:
        ...
    def __rsub__(self, arg0: float) -> LpExp:
        ...
    def __str__(self, arg0: list[LpVar], arg1: bool) -> str:
        ...
    @typing.overload
    def __sub__(self, arg0: LpExp) -> LpExp:
        ...
    @typing.overload
    def __sub__(self, arg0: LpVar) -> LpExp:
        ...
    @typing.overload
    def __sub__(self, arg0: float) -> LpExp:
        ...
    def __truediv__(self, arg0: float) -> LpExp:
        ...
    @property
    def coefficients(self) -> ...:
        ...
class LpModel:
    constraints: list[LpCst]
    name: str
    @staticmethod
    def col(var: LpVar) -> int:
        ...
    def __init__(self, name: str = '') -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def add_cst(self, c: LpCst, name: str = '') -> None:
        ...
    def add_var(self, name: str, lb: float = -1e+20, ub: float = 1e+20, is_int: bool = False) -> LpVar:
        ...
    def copy(self) -> LpModel:
        ...
    @typing.overload
    def maximize(self, expr: LpExp) -> None:
        ...
    @typing.overload
    def maximize(self, var: LpVar) -> None:
        ...
    @typing.overload
    def minimize(self, expr: LpExp) -> None:
        ...
    @typing.overload
    def minimize(self, var: LpVar) -> None:
        ...
    def objective(self, expr: LpExp) -> None:
        ...
    def print(self) -> None:
        ...
    def set_var_bounds(self, var: LpVar, lb: float, ub: float) -> None:
        ...
    def solve(self, solver: str = 'highs', verbose: bool = False) -> LpResult:
        ...
    def writeLP(self, filename: str) -> bool:
        ...
    @property
    def vars(self) -> list[LpVar]:
        ...
class LpResult:
    acceptable: bool
    col_dual: list[float]
    col_primal: list[float]
    objective: float
    optimal: bool
    row_dual: list[float]
    row_primal: list[float]
    def __init__(self, n_col: int, n_row: int) -> None:
        ...
    def getColDual(self) -> list[float]:
        ...
    def getColPrimal(self) -> list[float]:
        ...
    def getCstDual(self, cst: ...) -> float:
        ...
    def getCstPrimal(self, cst: ...) -> float:
        ...
    def getCstValue(self, cst: ...) -> float:
        ...
    def getDual(self, x: ...) -> float:
        ...
    def getExpValue(self, e: ...) -> float:
        ...
    def getObjective(self) -> float:
        ...
    def getPrimal(self, x: ...) -> float:
        ...
    def getRowDual(self) -> list[float]:
        ...
    def getRowPrimal(self) -> list[float]:
        ...
    def isAcceptable(self) -> bool:
        ...
    def isOptimal(self) -> bool:
        ...
    def setAcceptable(self, arg0: bool) -> None:
        ...
    def setColDual(self, arg0: list[float]) -> None:
        ...
    def setColPrimal(self, arg0: list[float]) -> None:
        ...
    def setObjective(self, arg0: float) -> None:
        ...
    def setOptimal(self, arg0: bool) -> None:
        ...
    def setRowDual(self, arg0: list[float]) -> None:
        ...
    def setRowPrimal(self, arg0: list[float]) -> None:
        ...
    @property
    def status_name(self) -> str:
        ...
class LpSense:
    """
    Members:
    
      MINIMIZE
    
      MAXIMIZE
    """
    MAXIMIZE: typing.ClassVar[LpSense]  # value = <LpSense.MAXIMIZE: 1>
    MINIMIZE: typing.ClassVar[LpSense]  # value = <LpSense.MINIMIZE: 0>
    __members__: typing.ClassVar[dict[str, LpSense]]  # value = {'MINIMIZE': <LpSense.MINIMIZE: 0>, 'MAXIMIZE': <LpSense.MAXIMIZE: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class LpVar:
    __hash__: typing.ClassVar[None] = None
    is_int: bool
    lb: float
    name: str
    ub: float
    @typing.overload
    def __add__(self, arg0: LpVar) -> ...:
        ...
    @typing.overload
    def __add__(self, arg0: ...) -> ...:
        ...
    @typing.overload
    def __add__(self, arg0: float) -> ...:
        ...
    @typing.overload
    def __eq__(self, arg0: LpVar) -> ...:
        ...
    @typing.overload
    def __eq__(self, arg0: ...) -> ...:
        ...
    @typing.overload
    def __eq__(self, arg0: float) -> ...:
        ...
    @typing.overload
    def __ge__(self, arg0: LpVar) -> ...:
        ...
    @typing.overload
    def __ge__(self, arg0: ...) -> ...:
        ...
    @typing.overload
    def __ge__(self, arg0: float) -> ...:
        ...
    @typing.overload
    def __iadd__(self, arg0: LpVar) -> ...:
        ...
    @typing.overload
    def __iadd__(self, arg0: ...) -> ...:
        ...
    @typing.overload
    def __iadd__(self, arg0: float) -> ...:
        ...
    def __imul__(self, arg0: float) -> ...:
        ...
    def __init__(self, i: int, name: str, lb: float = 1e-20, ub: float = 1e+20, is_int: bool = True) -> None:
        ...
    @typing.overload
    def __isub__(self, arg0: LpVar) -> ...:
        ...
    @typing.overload
    def __isub__(self, arg0: ...) -> ...:
        ...
    @typing.overload
    def __isub__(self, arg0: float) -> ...:
        ...
    def __itruediv__(self, arg0: float) -> ...:
        ...
    @typing.overload
    def __le__(self, arg0: LpVar) -> ...:
        ...
    @typing.overload
    def __le__(self, arg0: ...) -> ...:
        ...
    @typing.overload
    def __le__(self, arg0: float) -> ...:
        ...
    def __mul__(self, arg0: float) -> ...:
        ...
    def __neg__(self) -> ...:
        ...
    def __radd__(self, arg0: float) -> ...:
        ...
    def __repr__(self) -> str:
        ...
    def __req__(self, arg0: float) -> ...:
        ...
    def __rge__(self, arg0: float) -> ...:
        ...
    def __rle__(self, arg0: float) -> ...:
        ...
    def __rmul__(self, arg0: float) -> ...:
        ...
    def __rsub__(self, arg0: float) -> ...:
        ...
    def __str__(self) -> str:
        ...
    @typing.overload
    def __sub__(self, arg0: LpVar) -> ...:
        ...
    @typing.overload
    def __sub__(self, arg0: ...) -> ...:
        ...
    @typing.overload
    def __sub__(self, arg0: float) -> ...:
        ...
    def __truediv__(self, arg0: float) -> ...:
        ...
    @property
    def idx(self) -> int:
        ...
class MIPSolvers:
    """
    Members:
    
      HIGHS
    
      SCIP
    
      CPLEX
    
      GUROBI
    
      XPRESS
    """
    CPLEX: typing.ClassVar[MIPSolvers]  # value = <MIPSolvers.CPLEX: 2>
    GUROBI: typing.ClassVar[MIPSolvers]  # value = <MIPSolvers.GUROBI: 3>
    HIGHS: typing.ClassVar[MIPSolvers]  # value = <MIPSolvers.HIGHS: 0>
    SCIP: typing.ClassVar[MIPSolvers]  # value = <MIPSolvers.SCIP: 1>
    XPRESS: typing.ClassVar[MIPSolvers]  # value = <MIPSolvers.XPRESS: 4>
    __members__: typing.ClassVar[dict[str, MIPSolvers]]  # value = {'HIGHS': <MIPSolvers.HIGHS: 0>, 'SCIP': <MIPSolvers.SCIP: 1>, 'CPLEX': <MIPSolvers.CPLEX: 2>, 'GUROBI': <MIPSolvers.GUROBI: 3>, 'XPRESS': <MIPSolvers.XPRESS: 4>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class ModellingAuthority(EditableDevice):
    def __init__(self, name: str = '', idtag: str = '', code: str = '') -> None:
        """
        Constructor for ModellingAuthority.
        
        :param name: Name of the modelling authority
        :param idtag: ID tag for the authority
        :param code: Code for the authority
        """
class MultiCircuit(Assets):
    def __init__(self, nt: int = 1, name: str = '', Sbase: float = 100.0, fBase: float = 50.0, idtag: str = '') -> None:
        """
        Constructor for MultiCircuit.
        
        :param nt:    Number of timesteps.
        :param name:  Human-readable circuit name.
        :param Sbase: Base apparent power in **MVA** (default 100.0).
        :param fBase: Base frequency in **Hz** (default 50.0).
        :param idtag: Stable unique identifier tag.
        """
    def __repr__(self) -> str:
        """
        Return the canonical string representation (alias of :py:meth:`__str__`).
        """
    def __str__(self) -> str:
        """
        Return the circuit’s name.
        """
class Municipality(GenericAreaGroup):
    def __init__(self, name: str = '', idtag: str = '', code: str = '') -> None:
        """
        Constructor for Municipality.
        
        :param name: Name of the municipality
        :param idtag: ID tag for the municipality
        :param code: Code for the municipality
        """
class NodalCapacityMethod:
    """
    Members:
    
      NonlinearOptimization
    
      LinearOptimization
    
      CPF
    """
    CPF: typing.ClassVar[NodalCapacityMethod]  # value = <NodalCapacityMethod.CPF: 2>
    LinearOptimization: typing.ClassVar[NodalCapacityMethod]  # value = <NodalCapacityMethod.LinearOptimization: 1>
    NonlinearOptimization: typing.ClassVar[NodalCapacityMethod]  # value = <NodalCapacityMethod.NonlinearOptimization: 0>
    __members__: typing.ClassVar[dict[str, NodalCapacityMethod]]  # value = {'NonlinearOptimization': <NodalCapacityMethod.NonlinearOptimization: 0>, 'LinearOptimization': <NodalCapacityMethod.LinearOptimization: 1>, 'CPF': <NodalCapacityMethod.CPF: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class NumericalCircuit:
    @typing.overload
    def __init__(self, arg0: int, arg1: int, arg2: int, arg3: int, arg4: int, arg5: int, arg6: int, arg7: int, arg8: float, arg9: int) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: float, arg1: int, arg2: BusData, arg3: ActiveBranchData, arg4: PassiveBranchData, arg5: HvdcData, arg6: VscData, arg7: GeneratorData, arg8: BatteryData, arg9: LoadData, arg10: ShuntData) -> None:
        ...
    def get_adjacency(self, arg0: bool) -> scipy.sparse.csc_matrix:
        ...
    def get_admittance_injections(self) -> Numpy.ndarray[]:
        ...
    def get_admittance_injections_pu(self) -> Numpy.ndarray[]:
        ...
    def get_admittance_matrices(self) -> AdmittanceMatrices:
        ...
    def get_connectivity_matrices(self) -> ConnectivityMatrices:
        ...
    def get_current_injections(self) -> Numpy.ndarray[]:
        ...
    def get_current_injections_pu(self) -> Numpy.ndarray[]:
        ...
    def get_fast_decoupled_admittances(self, arg0: ConnectivityMatrices | None) -> FastDecoupledAdmittanceMatrices:
        ...
    def get_island(self, arg0: Numpy.ndarray[], arg1: Logger) -> NumericalCircuit:
        ...
    def get_power_injections(self) -> Numpy.ndarray[]:
        ...
    def get_power_injections_pu(self) -> Numpy.ndarray[]:
        ...
    def get_reactive_power_limits(self) -> tuple[Numpy.ndarray[], Numpy.ndarray[]]:
        ...
    def get_series_admittances(self, arg0: ConnectivityMatrices | None) -> SeriesAdmittanceMatrices:
        ...
    def get_simulation_indices(self, arg0: Numpy.ndarray[] | None) -> SimulationIndices:
        ...
    def get_yshunt_bus_pu(self) -> Numpy.ndarray[]:
        ...
    def process_reducible_branches(self) -> int:
        ...
    def set_contingencies_status(self, arg0: list[Contingency], arg1: bool) -> Numpy.ndarray[]:
        ...
    def set_remedial_actions_status(self, arg0: list[RemedialAction], arg1: bool) -> None:
        ...
    def split_into_islands(self, logger: Logger = ..., ignore_single_node_islands: bool = True, consider_hvdc_as_island_links: bool = False) -> list[NumericalCircuit]:
        ...
    @property
    def Sbase(self) -> float:
        ...
    @property
    def active_branch_data(self) -> ActiveBranchData:
        ...
    @property
    def battery_data(self) -> BatteryData:
        ...
    @property
    def bus_data(self) -> BusData:
        ...
    @property
    def generator_data(self) -> GeneratorData:
        ...
    @property
    def hvdc_data(self) -> HvdcData:
        ...
    @property
    def load_data(self) -> LoadData:
        ...
    @property
    def passive_branch_data(self) -> PassiveBranchData:
        ...
    @property
    def shunt_data(self) -> ShuntData:
        ...
    @property
    def t_idx(self) -> int:
        ...
    @property
    def vsc_data(self) -> VscData:
        ...
class OptionsTemplate(EditableDevice):
    def __init__(self, name: str) -> None:
        """
        Constructor for OptionsTemplate.
        
        :param name: The name of the options template.
        """
class OverheadLineType(EditableDevice):
    def __init__(self, name: str = 'Tower', idtag: str = '') -> None:
        """
        Constructor for OverheadLineType.
        
        :param name: Name of the overhead line type
        :param idtag: ID tag for the overhead line type
        """
    def add_wire_relationship(self, wire: Wire, xpos: float = 0.0, ypos: float = 0.0, phase: int = 1) -> None:
        """
        Add a wire relationship to the tower.
        
        :param wire: Wire instance
        :param xpos: x position in meters
        :param ypos: y position in meters
        :param phase: Phase (0 -> Neutral, 1 -> A, 2 -> B, 3 -> C)
        """
class PassiveBranchData(BranchParentData):
    B: Numpy.ndarray[]
    B0: Numpy.ndarray[]
    B2: Numpy.ndarray[]
    G: Numpy.ndarray[]
    G0: Numpy.ndarray[]
    G2: Numpy.ndarray[]
    R: Numpy.ndarray[]
    R0: Numpy.ndarray[]
    R2: Numpy.ndarray[]
    X: Numpy.ndarray[]
    X0: Numpy.ndarray[]
    X2: Numpy.ndarray[]
    conn: list[WindingsConnection]
    virtual_tap_f: Numpy.ndarray[]
    virtual_tap_t: Numpy.ndarray[]
    def __init__(self, arg0: int, arg1: int) -> None:
        ...
class PhysicalDevice(EditableDevice):
    def __init__(self, name: str, idtag: str, code: str, device_type: DeviceType, comment: str = '') -> None:
        """
        Constructor for PhysicalDevice.
        
        :param name: Name of the physical device
        :param idtag: Unique ID for the physical device
        :param code: Alternative code to identify the device
        :param device_type: The device type instance
        :param comment: Additional comment
        """
    @property
    def modelling_authority(self) -> ...:
        """
        Modelling authority associated with the physical device.
        
        :getter: Get the modelling authority.
        :setter: Set the modelling authority.
        """
    @modelling_authority.setter
    def modelling_authority(self, arg1: ...) -> None:
        ...
class PowerFlowOptions:
    apply_temperature_correction: bool
    backtracking_parameter: float
    branch_impedance_tolerance_mode: BranchImpedanceMode
    control_Q: bool
    control_remote_voltage: bool
    control_taps_modules: bool
    control_taps_phase: bool
    distributed_slack: bool
    generate_report: bool
    ignore_single_node_islands: bool
    initialize_angles: bool
    initialize_with_existing_solution: bool
    max_iter: int
    max_outer_loop_iter: int
    orthogonalize_controls: bool
    retry_with_other_methods: bool
    solver_type: SolverType
    tolerance: float
    trust_radius: float
    use_stored_guess: bool
    verbose: int
    def __init__(self, solver_type: SolverType = ..., retry_with_other_methods: bool = True, verbose: int = 0, initialize_with_existing_solution: bool = False, tolerance: float = 1e-06, max_iter: int = 25, max_outer_loop_iter: int = 100, control_Q: bool = True, control_taps_modules: bool = True, control_taps_phase: bool = True, control_remote_voltage: bool = True, orthogonalize_controls: bool = True, apply_temperature_correction: bool = True, branch_impedance_tolerance_mode: BranchImpedanceMode = ..., distributed_slack: bool = False, ignore_single_node_islands: bool = False, trust_radius: float = 1.0, backtracking_parameter: float = 0.05, use_stored_guess: bool = False, initialize_angles: bool = False, generate_report: bool = False) -> None:
        """
        Constructor for PowerFlowOptions.
        
        :param solver_type: Core algorithm to use (*NR*, *FDLF*, etc.).
        :param retry_with_other_methods: If the chosen solver fails, fall back to alternatives.
        :param verbose: Logging verbosity (0 = silent).
        :param initialize_with_existing_solution: Start from the values already stored in the network.
        :param tolerance: Convergence tolerance on the nodal power mismatch (pu).
        :param max_iter: Maximum Newton–Raphson iterations.
        :param max_outer_loop_iter: Maximum outer control loop iterations.
        :param control_Q / control_taps_modules / control_taps_phase / control_remote_voltage: Enable reactive-power, tap-magnitude, tap-phase and remote-voltage controls.
        :param orthogonalize_controls: Make interacting controls orthogonal to reduce oscillations.
        :param apply_temperature_correction: Adjust branches resistances with operating temperature.
        :param branch_impedance_tolerance_mode: How to handle very small impedances.
        :param distributed_slack: Distribute slack generation among multiple generators.
        :param ignore_single_node_islands: Skip isolated islands containing a single bus.
        :param trust_radius: Trust-region radius for damped NR and similar methods.
        :param backtracking_parameter: Back-tracking coefficient (0–1). Smaller = safer but slower.
        :param use_stored_guess: Use values saved from the previous PF run as an initial guess.
        :param initialize_angles: If *true*, initialise voltage angles from a linear power flow.
        :param generate_report: generate an analysis of the possible violations in the logger.
        """
class PowerFlowResults(ResultsTemplate):
    def __init__(self, nbus: int, nbr: int, nhvdc: int, nvsc: int, ngen: int, nbatt: int, nsh: int, time_array: list[int], clustering_results: ClusteringResults | None = None) -> None:
        """
        Container for time-series power-flow results.
        
        :param nbus: Number of buses in the solved network.
        :param nbr:  Number of AC branches (lines, transformers, etc.).
        :param nhvdc: Number of HVDC links.
        :param nvsc: Number of VSC (voltage-source) converters.
        :param ngen: Number of synchronous generators.
        :param nbatt: Number of battery units treated as generators.
        :param nsh:  Number of shunt devices (fixed + controllable).
        :param time_array: Deque containing the simulated time indices.
        :param clustering_results: Optional result object from network-reduction / clustering post-processing.
        """
    @property
    def If(self) -> Numpy.ndarray[]:
        """
        Sending-end current magnitude for each branch (pu).
        """
    @property
    def If_vsc(self) -> Numpy.ndarray[]:
        """
        VSC sending-end current (pu).
        """
    @property
    def It(self) -> Numpy.ndarray[]:
        """
        Receiving-end current magnitude for each branch (pu).
        """
    @property
    def It_vsc(self) -> Numpy.ndarray[]:
        """
        VSC receiving-end current (pu).
        """
    @property
    def Pf_hvdc(self) -> Numpy.ndarray[]:
        """
        HVDC sending-end active power (MW).
        """
    @property
    def Pf_vsc(self) -> Numpy.ndarray[]:
        """
        VSC sending-end active power (MW).
        """
    @property
    def Pt_hvdc(self) -> Numpy.ndarray[]:
        """
        HVDC receiving-end active power (MW).
        """
    @property
    def S(self) -> Numpy.ndarray[]:
        """
        Complex bus power injections **S = P + jQ** (MVA).
        """
    @property
    def Sf(self) -> Numpy.ndarray[]:
        """
        Sending-end complex power for each branch (MVA).
        """
    @property
    def St(self) -> Numpy.ndarray[]:
        """
        Receiving-end complex power for each branch (MVA).
        """
    @property
    def St_vsc(self) -> Numpy.ndarray[]:
        """
        VSC complex power (MVA).
        """
    @property
    def battery_q(self) -> Numpy.ndarray[]:
        """
        Reactive-power output of battery units (MVAr).
        """
    @property
    def converged_values(self) -> Numpy.ndarray[]:
        """
        Convergence flags per time step.
        """
    @property
    def error_values(self) -> Numpy.ndarray[]:
        """
        Iteration error metrics per time step.
        """
    @property
    def gen_q(self) -> Numpy.ndarray[]:
        """
        Reactive-power output of synchronous generators (MVAr).
        """
    @property
    def loading(self) -> Numpy.ndarray[]:
        """
        Branch loading percentage (p.u. of thermal rating).
        """
    @property
    def loading_hvdc(self) -> Numpy.ndarray[]:
        """
        HVDC link loading p.u.
        """
    @property
    def loading_vsc(self) -> Numpy.ndarray[]:
        """
        VSC loading p.u.
        """
    @property
    def losses(self) -> Numpy.ndarray[]:
        """
        System active-power losses (MW).
        """
    @property
    def losses_hvdc(self) -> Numpy.ndarray[]:
        """
        Active-power losses in HVDC links (MW).
        """
    @property
    def losses_vsc(self) -> Numpy.ndarray[]:
        """
        Total losses in VSC converters (MW).
        """
    @property
    def reports(self) -> list[list[ConvergenceReport]]:
        """
        Detailed convergence reports for each time step.
        """
    @property
    def shunt_q(self) -> Numpy.ndarray[]:
        """
        Reactive-power injection of shunt devices (MVAr).
        """
    @property
    def tap_angle(self) -> Numpy.ndarray[]:
        """
        Tap-changer phase-shift profile (deg).
        """
    @property
    def tap_module(self) -> Numpy.ndarray[]:
        """
        Tap-changer magnitude profile (pu).
        """
    @property
    def voltage(self) -> Numpy.ndarray[]:
        """
        Bus voltage phasors **V** (pu).
        """
class ProfileBus:
    sparsity_threshold: float
    def __init__(self, n: int, defaultVal: ..., is_sparse: bool) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: ...) -> None:
        ...
    def get(self, index: int) -> ...:
        ...
    def init_dense(self, arr: list[...]) -> None:
        ...
    def init_sparse(self, default_value: ..., data: dict[int, ...]) -> None:
        ...
    def set(self, index: int, value: ...) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[...]:
        ...
    @property
    def dense_array(self) -> list[...]:
        ...
    @property
    def is_sparse(self) -> bool:
        ...
    @property
    def sparse_array(self) -> SpaseArrayBus:
        ...
class ProfileConverterControlType:
    sparsity_threshold: float
    def __init__(self, n: int, defaultVal: ConverterControlType, is_sparse: bool) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: ConverterControlType) -> None:
        ...
    def get(self, index: int) -> ConverterControlType:
        ...
    def init_dense(self, arr: list[ConverterControlType]) -> None:
        ...
    def init_sparse(self, default_value: ConverterControlType, data: dict[int, ConverterControlType]) -> None:
        ...
    def set(self, index: int, value: ConverterControlType) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[ConverterControlType]:
        ...
    @property
    def dense_array(self) -> list[ConverterControlType]:
        ...
    @property
    def is_sparse(self) -> bool:
        ...
    @property
    def sparse_array(self) -> SpaseArrayConverterControlType:
        ...
class ProfilePhysicalDevicePtr:
    sparsity_threshold: float
    def __init__(self, n: int, defaultVal: ..., is_sparse: bool) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: ...) -> None:
        ...
    def get(self, index: int) -> ...:
        ...
    def init_dense(self, arr: list[...]) -> None:
        ...
    def init_sparse(self, default_value: ..., data: dict[int, ...]) -> None:
        ...
    def set(self, index: int, value: ...) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[...]:
        ...
    @property
    def dense_array(self) -> list[...]:
        ...
    @property
    def is_sparse(self) -> bool:
        ...
    @property
    def sparse_array(self) -> SpaseArrayPhysicalDevicePtr:
        ...
class ProfileTapModuleControl:
    sparsity_threshold: float
    def __init__(self, n: int, defaultVal: TapModuleControl, is_sparse: bool) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: TapModuleControl) -> None:
        ...
    def get(self, index: int) -> TapModuleControl:
        ...
    def init_dense(self, arr: list[TapModuleControl]) -> None:
        ...
    def init_sparse(self, default_value: TapModuleControl, data: dict[int, TapModuleControl]) -> None:
        ...
    def set(self, index: int, value: TapModuleControl) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[TapModuleControl]:
        ...
    @property
    def dense_array(self) -> list[TapModuleControl]:
        ...
    @property
    def is_sparse(self) -> bool:
        ...
    @property
    def sparse_array(self) -> SpaseArrayTapModuleControl:
        ...
class ProfileTapPhaseControl:
    sparsity_threshold: float
    def __init__(self, n: int, defaultVal: TapPhaseControl, is_sparse: bool) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: TapPhaseControl) -> None:
        ...
    def get(self, index: int) -> TapPhaseControl:
        ...
    def init_dense(self, arr: list[TapPhaseControl]) -> None:
        ...
    def init_sparse(self, default_value: TapPhaseControl, data: dict[int, TapPhaseControl]) -> None:
        ...
    def set(self, index: int, value: TapPhaseControl) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[TapPhaseControl]:
        ...
    @property
    def dense_array(self) -> list[TapPhaseControl]:
        ...
    @property
    def is_sparse(self) -> bool:
        ...
    @property
    def sparse_array(self) -> SpaseArrayTapPhaseControl:
        ...
class Profilebool:
    sparsity_threshold: float
    def __init__(self, n: int, defaultVal: bool, is_sparse: bool) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: bool) -> None:
        ...
    def get(self, index: int) -> bool:
        ...
    def init_dense(self, arr: list[bool]) -> None:
        ...
    def init_sparse(self, default_value: bool, data: dict[int, bool]) -> None:
        ...
    def set(self, index: int, value: bool) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[bool]:
        ...
    @property
    def dense_array(self) -> list[bool]:
        ...
    @property
    def is_sparse(self) -> bool:
        ...
    @property
    def sparse_array(self) -> SpaseArraybool:
        ...
class Profiledouble:
    sparsity_threshold: float
    def __init__(self, n: int, defaultVal: float, is_sparse: bool) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: float) -> None:
        ...
    def get(self, index: int) -> float:
        ...
    def init_dense(self, arr: list[float]) -> None:
        ...
    def init_sparse(self, default_value: float, data: dict[int, float]) -> None:
        ...
    def set(self, index: int, value: float) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[float]:
        ...
    @property
    def dense_array(self) -> list[float]:
        ...
    @property
    def is_sparse(self) -> bool:
        ...
    @property
    def sparse_array(self) -> SpaseArraydouble:
        ...
class Profileint:
    sparsity_threshold: float
    def __init__(self, n: int, defaultVal: int, is_sparse: bool) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: int) -> None:
        ...
    def get(self, index: int) -> int:
        ...
    def init_dense(self, arr: list[int]) -> None:
        ...
    def init_sparse(self, default_value: int, data: dict[int, int]) -> None:
        ...
    def set(self, index: int, value: int) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[int]:
        ...
    @property
    def dense_array(self) -> list[int]:
        ...
    @property
    def is_sparse(self) -> bool:
        ...
    @property
    def sparse_array(self) -> SpaseArrayint:
        ...
class Profileuint:
    sparsity_threshold: float
    def __init__(self, n: int, defaultVal: int, is_sparse: bool) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: int) -> None:
        ...
    def get(self, index: int) -> int:
        ...
    def init_dense(self, arr: list[int]) -> None:
        ...
    def init_sparse(self, default_value: int, data: dict[int, int]) -> None:
        ...
    def set(self, index: int, value: int) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[int]:
        ...
    @property
    def dense_array(self) -> list[int]:
        ...
    @property
    def is_sparse(self) -> bool:
        ...
    @property
    def sparse_array(self) -> SpaseArrayuint:
        ...
class Region(GenericAreaGroup):
    def __init__(self, name: str = '', idtag: str = '', code: str = '') -> None:
        """
        Constructor for Region.
        
        :param name: Name of the region
        :param idtag: ID tag for the region
        :param code: Code for the region
        """
class RemedialAction(EditableDevice):
    def __init__(self, idtag: str = '', device_idtag: str = '', name: str = '', code: str = '', prop: ContingencyOperationTypes = ..., value: float = 0.0, group: RemedialActionGroup = None) -> None:
        """
        Constructor for RemedialAction.
        
        :param idtag: Remedial action ID tag
        :param device_idtag: Device ID tag
        :param name: Name of the remedial action
        :param code: Code for the remedial action
        :param prop: Contingency operation type
        :param value: Value associated with the remedial action
        :param group: Pointer to the associated remedial action group
        """
    @property
    def device_idtag(self) -> str:
        """
        Device ID tag associated with the remedial action.
        
        :getter: Get the device ID tag.
        :setter: Set the device ID tag.
        """
    @device_idtag.setter
    def device_idtag(self, arg1: str) -> None:
        ...
    @property
    def group(self) -> RemedialActionGroup:
        """
        Pointer to the associated remedial action group.
        
        :getter: Get the group pointer.
        :setter: Set the group pointer.
        """
    @group.setter
    def group(self, arg1: RemedialActionGroup) -> None:
        ...
    @property
    def prop(self) -> ContingencyOperationTypes:
        """
        Property indicating the contingency operation type.
        
        :getter: Get the operation type.
        :setter: Set the operation type.
        """
    @prop.setter
    def prop(self, arg1: ContingencyOperationTypes) -> None:
        ...
    @property
    def value(self) -> float:
        """
        Value associated with the remedial action.
        
        :getter: Get the value.
        :setter: Set the value.
        """
    @value.setter
    def value(self, arg1: float) -> None:
        ...
class RemedialActionGroup(EditableDevice):
    def __init__(self, name: str = '', idtag: str = '', code: str = '', category: str = '') -> None:
        """
        Constructor for RemedialActionGroup.
        
        :param name: Name of the remedial action group
        :param idtag: ID tag for the group
        :param code: Code for the group
        :param category: Category of the remedial action group
        """
    @property
    def category(self) -> str:
        """
        Category of the remedial action group.
        
        :getter: Get the category.
        :setter: Set the category.
        """
    @category.setter
    def category(self, arg1: str) -> None:
        ...
class ResultsTemplate:
    def __init__(self, name: str, time_array: list[int], study_results_type: ..., clustering_results: ClusteringResults | None = None) -> None:
        ...
    def tic(self) -> None:
        ...
    def toc(self) -> None:
        ...
    @property
    def clustering_results(self) -> ClusteringResults | None:
        ...
    @property
    def elapsed(self) -> float:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def study_results_type(self) -> ...:
        ...
    @property
    def time_array(self) -> list[int]:
        ...
class SequenceLineType(EditableDevice):
    def __init__(self, name: str = 'SequenceLine', idtag: str = '', Imax: float = 1.0, Vnom: float = 1.0, R: float = 0.0, X: float = 0.0, B: float = 0.0, R0: float = 0.0, X0: float = 0.0, B0: float = 0.0) -> None:
        """
        Constructor for SequenceLineType.
        
        :param name: Name of the sequence line type
        :param idtag: ID tag for the sequence line type
        :param Imax: Line rating current in kA
        :param Vnom: Nominal voltage in kV
        :param R: Positive-sequence resistance per unit length
        :param X: Positive-sequence reactance per unit length
        :param B: Positive-sequence susceptance per unit length
        :param R0: Zero-sequence resistance per unit length
        :param X0: Zero-sequence reactance per unit length
        :param B0: Zero-sequence susceptance per unit length
        """
    def get_values(self, Sbase: float, length: float) -> ...:
        """
        Get the per-unit values for the sequence line.
        
        :param Sbase: Base power in MVA
        :param length: Line length in kilometers
        :return: PerUnitValues object.
        """
class SeriesAdmittanceMatrices:
    def __init__(self, Yseries: scipy.sparse.csc_matrix, Yshunt: Numpy.ndarray[]) -> None:
        ...
    @property
    def Yseries(self) -> scipy.sparse.csc_matrix:
        ...
    @property
    def Yshunt(self) -> Numpy.ndarray[]:
        ...
class SeriesReactance(BranchParent):
    def __init__(self, nt: int, name: str = 'Reactance', idtag: str = '', code: str = '', bus_from: Bus = None, bus_to: Bus = None, r: float = 1e-20, x: float = 1e-05, rate: float = 1.0, active: bool = True, tolerance: float = 0.0, cost: float = 100.0, mttf: float = 0.0, mttr: float = 0.0, r_fault: float = 0.0, x_fault: float = 0.0, fault_pos: float = 0.5, temp_base: float = 20.0, temp_oper: float = 20.0, alpha: float = 0.0033, contingency_factor: float = 1.0, protection_rating_factor: float = 1.4, monitor_loading: bool = True, r0: float = 1e-20, x0: float = 1e-20, r2: float = 1e-20, x2: float = 1e-20, capex: float = 0.0, opex: float = 0.0, build_status: BuildStatus = ...) -> None:
        """
        Constructor for SeriesReactance.
        
        :param nt: Number of simulation timesteps.
        :param name: Human-readable device name.
        :param idtag: Stable unique identifier tag.
        :param code: Engineering code or label.
        :param bus_from: Pointer to the *from* bus.
        :param bus_to: Pointer to the *to* bus.
        :param r: Positive-sequence series resistance **R** (Ω).
        :param x: Positive-sequence series reactance **X** (Ω).
        :param rate: Continuous current rating **I<sub>max</sub>** (kA).
        :param active: Initial active state profile.
        :param tolerance: Power-flow convergence tolerance (pu).
        :param cost: Operating cost per unit energy or time.
        :param mttf: Mean time to failure (h).
        :param mttr: Mean time to repair (h).
        :param r_fault: Fault resistance (Ω).
        :param x_fault: Fault reactance (Ω).
        :param fault_pos: Fault position as fraction (0 – 1) of device length.
        :param temp_base: Reference temperature for *R* values (°C).
        :param temp_oper: Operating temperature profile (°C).
        :param alpha: Temperature coefficient of resistance (1/°C).
        :param contingency_factor: Multiplicative contingency rating factor.
        :param protection_rating_factor: Protection-based rating factor.
        :param monitor_loading: Enable automatic loading alarms.
        :param r0: Zero-sequence resistance **R₀** (Ω).
        :param x0: Zero-sequence reactance **X₀** (Ω).
        :param r2: Negative-sequence resistance **R₂** (Ω).
        :param x2: Negative-sequence reactance **X₂** (Ω).
        :param capex: Capital expenditure (currency units).
        :param opex: Annual operating expenditure (currency units).
        :param build_status: Construction / service status enumeration.
        """
    def get_r_corrected(self, t_idx: int) -> float:
        """
        Return temperature-corrected resistance at timestep *t_idx*.
        """
    def set_temp_oper_val(self, val: float) -> None:
        """
        Set *temp_oper* to a single value (°C) across all timesteps.
        """
    @property
    def R(self) -> float:
        """
        Positive-sequence resistance **R** (Ω).
        """
    @R.setter
    def R(self, arg1: float) -> None:
        ...
    @property
    def R0(self) -> float:
        """
        Zero-sequence resistance **R₀** (Ω).
        """
    @R0.setter
    def R0(self, arg1: float) -> None:
        ...
    @property
    def R2(self) -> float:
        """
        Negative-sequence resistance **R₂** (Ω).
        """
    @R2.setter
    def R2(self, arg1: float) -> None:
        ...
    @property
    def X(self) -> float:
        """
        Positive-sequence reactance **X** (Ω).
        """
    @X.setter
    def X(self, arg1: float) -> None:
        ...
    @property
    def X0(self) -> float:
        """
        Zero-sequence reactance **X₀** (Ω).
        """
    @X0.setter
    def X0(self, arg1: float) -> None:
        ...
    @property
    def X2(self) -> float:
        """
        Negative-sequence reactance **X₂** (Ω).
        """
    @X2.setter
    def X2(self, arg1: float) -> None:
        ...
    @property
    def alpha(self) -> float:
        """
        Temperature coefficient of resistance (1/°C).
        """
    @alpha.setter
    def alpha(self, arg1: float) -> None:
        ...
    @property
    def fault_pos(self) -> float:
        """
        Fault position as fraction (0 – 1) of device length.
        """
    @fault_pos.setter
    def fault_pos(self, arg1: float) -> None:
        ...
    @property
    def r_fault(self) -> float:
        """
        Fault resistance (Ω).
        """
    @r_fault.setter
    def r_fault(self, arg1: float) -> None:
        ...
    @property
    def temp_base(self) -> float:
        """
        Reference temperature for resistance (°C).
        """
    @temp_base.setter
    def temp_base(self, arg1: float) -> None:
        ...
    @property
    def temp_oper(self) -> Profiledouble:
        """
        Operating temperature profile (°C).
        """
    @temp_oper.setter
    def temp_oper(self, arg1: Profiledouble) -> None:
        ...
    @property
    def tolerance(self) -> float:
        """
        Power-flow convergence tolerance (pu).
        """
    @tolerance.setter
    def tolerance(self, arg1: float) -> None:
        ...
    @property
    def x_fault(self) -> float:
        """
        Fault reactance (Ω).
        """
    @x_fault.setter
    def x_fault(self, arg1: float) -> None:
        ...
class Shunt(ShuntParent):
    def __init__(self, nt: int, bus: Bus = None, name: str = 'Load', idtag: str = '', code: str = '', G: float = 0.0, B: float = 0.0, active: bool = True, mttf: float = 0.0, mttr: float = 0.0, G0: float = 0.0, B0: float = 0.0, capex: float = 0.0, opex: float = 0.0, build_status: BuildStatus = ...) -> None:
        """
        Constructor for Shunt.
        
        :param nt: Number of simulation timesteps.
        :param bus: Pointer to the connected bus (may be *None*).
        :param name/idtag/code: Readable name and identifiers.
        :param G/B: Positive-sequence shunt conductance and susceptance (MW / MVAr at rated voltage).
        :param active: Whether the shunt is energised in the base case.
        :param mttf/mttr: Mean time to failure / repair (h).
        :param G0/B0: Zero-sequence conductance and susceptance (pu).
        :param capex/opex: Capital and annual operating expenditure.
        :param build_status: Construction / service status enumeration.
        """
class ShuntData:
    Y: Numpy.ndarray[]
    active: Numpy.ndarray[]
    bus_idx: Numpy.ndarray[]
    controllable: Numpy.ndarray[]
    controllable_bus_idx: Numpy.ndarray[]
    cost: Numpy.ndarray[]
    idtag: list[str]
    mttf: Numpy.ndarray[]
    mttr: Numpy.ndarray[]
    names: list[str]
    nbus: int
    nelm: int
    original_idx: Numpy.ndarray[]
    q_share: Numpy.ndarray[]
    qmax: Numpy.ndarray[]
    qmin: Numpy.ndarray[]
    vset: Numpy.ndarray[]
    def __init__(self, arg0: int, arg1: int) -> None:
        ...
class ShuntParent(InjectionParent):
    def __init__(self, nt: int, name: str, idtag: str, code: str, bus: ..., active: bool, G: float, B: float, G0: float, B0: float, cost: float, mttf: float, mttr: float, capex: float, opex: float, build_status: BuildStatus, device_type: DeviceType) -> None:
        """
        Constructor for ShuntParent.
        
        :param nt: Number of timesteps
        :param name: Name of the shunt
        :param idtag: ID tag for the shunt
        :param code: Code for the shunt
        :param bus: Associated bus
        :param active: Active state
        :param G: Positive conductance (MW @ v=1 p.u.)
        :param B: Positive susceptance (MVAr @ v=1 p.u.)
        :param G0: Zero-sequence conductance (MW @ v=1 p.u.)
        :param B0: Zero-sequence susceptance (MVAr @ v=1 p.u.)
        :param cost: Cost profile
        :param mttf: Mean time to failure
        :param mttr: Mean time to repair
        :param capex: Capital expenditure
        :param opex: Operational expenditure
        :param build_status: Build status
        :param device_type: Device type
        """
    def set_B0_val(self, val: float) -> None:
        """
        Set the zero-sequence susceptance value.
        
        :param val: Zero-sequence susceptance value (MVAr @ v=1 p.u.).
        """
    def set_B_val(self, val: float) -> None:
        """
        Set the positive susceptance value.
        
        :param val: Positive susceptance value (MVAr @ v=1 p.u.).
        """
    def set_G0_val(self, val: float) -> None:
        """
        Set the zero-sequence conductance value.
        
        :param val: Zero-sequence conductance value (MW @ v=1 p.u.).
        """
    def set_G_val(self, val: float) -> None:
        """
        Set the positive conductance value.
        
        :param val: Positive conductance value (MW @ v=1 p.u.).
        """
    @property
    def B(self) -> Profiledouble:
        """
        Positive susceptance profile (MVAr @ v=1 p.u.).
        
        :getter: Get the positive susceptance profile.
        :setter: Set the positive susceptance profile.
        """
    @B.setter
    def B(self, arg1: Profiledouble) -> None:
        ...
    @property
    def B0(self) -> Profiledouble:
        """
        Zero-sequence susceptance profile (MVAr @ v=1 p.u.).
        
        :getter: Get the zero-sequence susceptance profile.
        :setter: Set the zero-sequence susceptance profile.
        """
    @B0.setter
    def B0(self, arg1: Profiledouble) -> None:
        ...
    @property
    def G(self) -> Profiledouble:
        """
        Positive conductance profile (MW @ v=1 p.u.).
        
        :getter: Get the positive conductance profile.
        :setter: Set the positive conductance profile.
        """
    @G.setter
    def G(self, arg1: Profiledouble) -> None:
        ...
    @property
    def G0(self) -> Profiledouble:
        """
        Zero-sequence conductance profile (MW @ v=1 p.u.).
        
        :getter: Get the zero-sequence conductance profile.
        :setter: Set the zero-sequence conductance profile.
        """
    @G0.setter
    def G0(self, arg1: Profiledouble) -> None:
        ...
class SimulationIndices:
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, P: Numpy.ndarray[], bus_types: list[BusMode]) -> None:
        ...
    @typing.overload
    def update_bus_types(self, arg0: Numpy.ndarray[], arg1: Numpy.ndarray[], arg2: Numpy.ndarray[], arg3: Numpy.ndarray[]) -> None:
        ...
    @typing.overload
    def update_bus_types(self, arg0: Numpy.ndarray[], arg1: Numpy.ndarray[]) -> None:
        ...
    @property
    def no_slack(self) -> Numpy.ndarray[]:
        ...
    @property
    def p(self) -> Numpy.ndarray[]:
        ...
    @property
    def pq(self) -> Numpy.ndarray[]:
        ...
    @property
    def pqv(self) -> Numpy.ndarray[]:
        ...
    @property
    def pv(self) -> Numpy.ndarray[]:
        ...
    @property
    def types(self) -> list[BusMode]:
        ...
    @property
    def vd(self) -> Numpy.ndarray[]:
        ...
class SimulationType:
    """
    Members:
    
      DesignView
    
      TemplateDriver
    
      PowerFlow_run
    
      ShortCircuit_run
    
      MonteCarlo_run
    
      PowerFlowTimeSeries_run
    
      ClusteringAnalysis_run
    
      ContinuationPowerFlow_run
    
      LatinHypercube_run
    
      StochasticPowerFlow
    
      Cascade_run
    
      OPF_run
    
      OPF_NTC_run
    
      OPF_NTC_TS_run
    
      OPFTimeSeries_run
    
      TransientStability_run
    
      TopologyReduction_run
    
      LinearAnalysis_run
    
      LinearAnalysis_TS_run
    
      NonLinearAnalysis_run
    
      NonLinearAnalysis_TS_run
    
      ContingencyAnalysis_run
    
      ContingencyAnalysisTS_run
    
      Delete_and_reduce_run
    
      NetTransferCapacity_run
    
      NetTransferCapacityTS_run
    
      SigmaAnalysis_run
    
      NodeGrouping_run
    
      InputsAnalysis_run
    
      OptimalNetTransferCapacityTimeSeries_run
    
      InvestmentsEvaluation_run
    
      TopologyProcessor_run
    
      NodalCapacityTimeSeries_run
    
      NoSim
    """
    Cascade_run: typing.ClassVar[SimulationType]  # value = <SimulationType.Cascade_run: 10>
    ClusteringAnalysis_run: typing.ClassVar[SimulationType]  # value = <SimulationType.ClusteringAnalysis_run: 6>
    ContingencyAnalysisTS_run: typing.ClassVar[SimulationType]  # value = <SimulationType.ContingencyAnalysisTS_run: 22>
    ContingencyAnalysis_run: typing.ClassVar[SimulationType]  # value = <SimulationType.ContingencyAnalysis_run: 21>
    ContinuationPowerFlow_run: typing.ClassVar[SimulationType]  # value = <SimulationType.ContinuationPowerFlow_run: 7>
    Delete_and_reduce_run: typing.ClassVar[SimulationType]  # value = <SimulationType.Delete_and_reduce_run: 23>
    DesignView: typing.ClassVar[SimulationType]  # value = <SimulationType.DesignView: 0>
    InputsAnalysis_run: typing.ClassVar[SimulationType]  # value = <SimulationType.InputsAnalysis_run: 28>
    InvestmentsEvaluation_run: typing.ClassVar[SimulationType]  # value = <SimulationType.InvestmentsEvaluation_run: 30>
    LatinHypercube_run: typing.ClassVar[SimulationType]  # value = <SimulationType.LatinHypercube_run: 8>
    LinearAnalysis_TS_run: typing.ClassVar[SimulationType]  # value = <SimulationType.LinearAnalysis_TS_run: 18>
    LinearAnalysis_run: typing.ClassVar[SimulationType]  # value = <SimulationType.LinearAnalysis_run: 17>
    MonteCarlo_run: typing.ClassVar[SimulationType]  # value = <SimulationType.MonteCarlo_run: 4>
    NetTransferCapacityTS_run: typing.ClassVar[SimulationType]  # value = <SimulationType.NetTransferCapacityTS_run: 25>
    NetTransferCapacity_run: typing.ClassVar[SimulationType]  # value = <SimulationType.NetTransferCapacity_run: 24>
    NoSim: typing.ClassVar[SimulationType]  # value = <SimulationType.NoSim: 33>
    NodalCapacityTimeSeries_run: typing.ClassVar[SimulationType]  # value = <SimulationType.NodalCapacityTimeSeries_run: 32>
    NodeGrouping_run: typing.ClassVar[SimulationType]  # value = <SimulationType.NodeGrouping_run: 27>
    NonLinearAnalysis_TS_run: typing.ClassVar[SimulationType]  # value = <SimulationType.NonLinearAnalysis_TS_run: 20>
    NonLinearAnalysis_run: typing.ClassVar[SimulationType]  # value = <SimulationType.NonLinearAnalysis_run: 19>
    OPFTimeSeries_run: typing.ClassVar[SimulationType]  # value = <SimulationType.OPFTimeSeries_run: 14>
    OPF_NTC_TS_run: typing.ClassVar[SimulationType]  # value = <SimulationType.OPF_NTC_TS_run: 13>
    OPF_NTC_run: typing.ClassVar[SimulationType]  # value = <SimulationType.OPF_NTC_run: 12>
    OPF_run: typing.ClassVar[SimulationType]  # value = <SimulationType.OPF_run: 11>
    OptimalNetTransferCapacityTimeSeries_run: typing.ClassVar[SimulationType]  # value = <SimulationType.OptimalNetTransferCapacityTimeSeries_run: 29>
    PowerFlowTimeSeries_run: typing.ClassVar[SimulationType]  # value = <SimulationType.PowerFlowTimeSeries_run: 5>
    PowerFlow_run: typing.ClassVar[SimulationType]  # value = <SimulationType.PowerFlow_run: 2>
    ShortCircuit_run: typing.ClassVar[SimulationType]  # value = <SimulationType.ShortCircuit_run: 3>
    SigmaAnalysis_run: typing.ClassVar[SimulationType]  # value = <SimulationType.SigmaAnalysis_run: 26>
    StochasticPowerFlow: typing.ClassVar[SimulationType]  # value = <SimulationType.StochasticPowerFlow: 9>
    TemplateDriver: typing.ClassVar[SimulationType]  # value = <SimulationType.TemplateDriver: 1>
    TopologyProcessor_run: typing.ClassVar[SimulationType]  # value = <SimulationType.TopologyProcessor_run: 31>
    TopologyReduction_run: typing.ClassVar[SimulationType]  # value = <SimulationType.TopologyReduction_run: 16>
    TransientStability_run: typing.ClassVar[SimulationType]  # value = <SimulationType.TransientStability_run: 15>
    __members__: typing.ClassVar[dict[str, SimulationType]]  # value = {'DesignView': <SimulationType.DesignView: 0>, 'TemplateDriver': <SimulationType.TemplateDriver: 1>, 'PowerFlow_run': <SimulationType.PowerFlow_run: 2>, 'ShortCircuit_run': <SimulationType.ShortCircuit_run: 3>, 'MonteCarlo_run': <SimulationType.MonteCarlo_run: 4>, 'PowerFlowTimeSeries_run': <SimulationType.PowerFlowTimeSeries_run: 5>, 'ClusteringAnalysis_run': <SimulationType.ClusteringAnalysis_run: 6>, 'ContinuationPowerFlow_run': <SimulationType.ContinuationPowerFlow_run: 7>, 'LatinHypercube_run': <SimulationType.LatinHypercube_run: 8>, 'StochasticPowerFlow': <SimulationType.StochasticPowerFlow: 9>, 'Cascade_run': <SimulationType.Cascade_run: 10>, 'OPF_run': <SimulationType.OPF_run: 11>, 'OPF_NTC_run': <SimulationType.OPF_NTC_run: 12>, 'OPF_NTC_TS_run': <SimulationType.OPF_NTC_TS_run: 13>, 'OPFTimeSeries_run': <SimulationType.OPFTimeSeries_run: 14>, 'TransientStability_run': <SimulationType.TransientStability_run: 15>, 'TopologyReduction_run': <SimulationType.TopologyReduction_run: 16>, 'LinearAnalysis_run': <SimulationType.LinearAnalysis_run: 17>, 'LinearAnalysis_TS_run': <SimulationType.LinearAnalysis_TS_run: 18>, 'NonLinearAnalysis_run': <SimulationType.NonLinearAnalysis_run: 19>, 'NonLinearAnalysis_TS_run': <SimulationType.NonLinearAnalysis_TS_run: 20>, 'ContingencyAnalysis_run': <SimulationType.ContingencyAnalysis_run: 21>, 'ContingencyAnalysisTS_run': <SimulationType.ContingencyAnalysisTS_run: 22>, 'Delete_and_reduce_run': <SimulationType.Delete_and_reduce_run: 23>, 'NetTransferCapacity_run': <SimulationType.NetTransferCapacity_run: 24>, 'NetTransferCapacityTS_run': <SimulationType.NetTransferCapacityTS_run: 25>, 'SigmaAnalysis_run': <SimulationType.SigmaAnalysis_run: 26>, 'NodeGrouping_run': <SimulationType.NodeGrouping_run: 27>, 'InputsAnalysis_run': <SimulationType.InputsAnalysis_run: 28>, 'OptimalNetTransferCapacityTimeSeries_run': <SimulationType.OptimalNetTransferCapacityTimeSeries_run: 29>, 'InvestmentsEvaluation_run': <SimulationType.InvestmentsEvaluation_run: 30>, 'TopologyProcessor_run': <SimulationType.TopologyProcessor_run: 31>, 'NodalCapacityTimeSeries_run': <SimulationType.NodalCapacityTimeSeries_run: 32>, 'NoSim': <SimulationType.NoSim: 33>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SolverType:
    """
    Members:
    
      NR
    
      NRFD_XB
    
      NRFD_BX
    
      GAUSS
    
      DC
    
      HELM
    
      ZBUS
    
      PowellDogLeg
    
      IWAMOTO
    
      CONTINUATION_NR
    
      HELMZ
    
      LM
    
      FASTDECOUPLED
    
      LACPF
    
      LINEAR_OPF
    
      NONLINEAR_OPF
    
      SIMPLE_OPF
    
      Proportional_OPF
    
      DYCORS_OPF
    
      GA_OPF
    
      NELDER_MEAD_OPF
    
      BFS
    
      BFS_linear
    
      Constant_Impedance_linear
    
      NoSolver
    """
    BFS: typing.ClassVar[SolverType]  # value = <SolverType.BFS: 21>
    BFS_linear: typing.ClassVar[SolverType]  # value = <SolverType.BFS_linear: 22>
    CONTINUATION_NR: typing.ClassVar[SolverType]  # value = <SolverType.CONTINUATION_NR: 9>
    Constant_Impedance_linear: typing.ClassVar[SolverType]  # value = <SolverType.Constant_Impedance_linear: 23>
    DC: typing.ClassVar[SolverType]  # value = <SolverType.DC: 4>
    DYCORS_OPF: typing.ClassVar[SolverType]  # value = <SolverType.DYCORS_OPF: 18>
    FASTDECOUPLED: typing.ClassVar[SolverType]  # value = <SolverType.FASTDECOUPLED: 12>
    GAUSS: typing.ClassVar[SolverType]  # value = <SolverType.GAUSS: 3>
    GA_OPF: typing.ClassVar[SolverType]  # value = <SolverType.GA_OPF: 19>
    HELM: typing.ClassVar[SolverType]  # value = <SolverType.HELM: 5>
    HELMZ: typing.ClassVar[SolverType]  # value = <SolverType.HELMZ: 10>
    IWAMOTO: typing.ClassVar[SolverType]  # value = <SolverType.IWAMOTO: 8>
    LACPF: typing.ClassVar[SolverType]  # value = <SolverType.LACPF: 13>
    LINEAR_OPF: typing.ClassVar[SolverType]  # value = <SolverType.LINEAR_OPF: 14>
    LM: typing.ClassVar[SolverType]  # value = <SolverType.LM: 11>
    NELDER_MEAD_OPF: typing.ClassVar[SolverType]  # value = <SolverType.NELDER_MEAD_OPF: 20>
    NONLINEAR_OPF: typing.ClassVar[SolverType]  # value = <SolverType.NONLINEAR_OPF: 15>
    NR: typing.ClassVar[SolverType]  # value = <SolverType.NR: 0>
    NRFD_BX: typing.ClassVar[SolverType]  # value = <SolverType.NRFD_BX: 2>
    NRFD_XB: typing.ClassVar[SolverType]  # value = <SolverType.NRFD_XB: 1>
    NoSolver: typing.ClassVar[SolverType]  # value = <SolverType.NoSolver: 24>
    PowellDogLeg: typing.ClassVar[SolverType]  # value = <SolverType.PowellDogLeg: 7>
    Proportional_OPF: typing.ClassVar[SolverType]  # value = <SolverType.Proportional_OPF: 17>
    SIMPLE_OPF: typing.ClassVar[SolverType]  # value = <SolverType.SIMPLE_OPF: 16>
    ZBUS: typing.ClassVar[SolverType]  # value = <SolverType.ZBUS: 6>
    __members__: typing.ClassVar[dict[str, SolverType]]  # value = {'NR': <SolverType.NR: 0>, 'NRFD_XB': <SolverType.NRFD_XB: 1>, 'NRFD_BX': <SolverType.NRFD_BX: 2>, 'GAUSS': <SolverType.GAUSS: 3>, 'DC': <SolverType.DC: 4>, 'HELM': <SolverType.HELM: 5>, 'ZBUS': <SolverType.ZBUS: 6>, 'PowellDogLeg': <SolverType.PowellDogLeg: 7>, 'IWAMOTO': <SolverType.IWAMOTO: 8>, 'CONTINUATION_NR': <SolverType.CONTINUATION_NR: 9>, 'HELMZ': <SolverType.HELMZ: 10>, 'LM': <SolverType.LM: 11>, 'FASTDECOUPLED': <SolverType.FASTDECOUPLED: 12>, 'LACPF': <SolverType.LACPF: 13>, 'LINEAR_OPF': <SolverType.LINEAR_OPF: 14>, 'NONLINEAR_OPF': <SolverType.NONLINEAR_OPF: 15>, 'SIMPLE_OPF': <SolverType.SIMPLE_OPF: 16>, 'Proportional_OPF': <SolverType.Proportional_OPF: 17>, 'DYCORS_OPF': <SolverType.DYCORS_OPF: 18>, 'GA_OPF': <SolverType.GA_OPF: 19>, 'NELDER_MEAD_OPF': <SolverType.NELDER_MEAD_OPF: 20>, 'BFS': <SolverType.BFS: 21>, 'BFS_linear': <SolverType.BFS_linear: 22>, 'Constant_Impedance_linear': <SolverType.Constant_Impedance_linear: 23>, 'NoSolver': <SolverType.NoSolver: 24>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SpaseArrayBus:
    def __init__(self, n: int, default_value: ...) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: ...) -> None:
        ...
    def get(self, index: int) -> ...:
        ...
    def init(self, size: int, default_value: ..., data: dict[int, ...]) -> None:
        ...
    def resize(self, newSize: int) -> None:
        ...
    def set(self, index: int, value: ...) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[...]:
        ...
    @property
    def data(self) -> dict[int, ...]:
        ...
    @property
    def default_value(self) -> ...:
        ...
    @property
    def sparsity(self) -> float:
        ...
class SpaseArrayConverterControlType:
    def __init__(self, n: int, default_value: ConverterControlType) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: ConverterControlType) -> None:
        ...
    def get(self, index: int) -> ConverterControlType:
        ...
    def init(self, size: int, default_value: ConverterControlType, data: dict[int, ConverterControlType]) -> None:
        ...
    def resize(self, newSize: int) -> None:
        ...
    def set(self, index: int, value: ConverterControlType) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[ConverterControlType]:
        ...
    @property
    def data(self) -> dict[int, ConverterControlType]:
        ...
    @property
    def default_value(self) -> ConverterControlType:
        ...
    @property
    def sparsity(self) -> float:
        ...
class SpaseArrayPhysicalDevicePtr:
    def __init__(self, n: int, default_value: ...) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: ...) -> None:
        ...
    def get(self, index: int) -> ...:
        ...
    def init(self, size: int, default_value: ..., data: dict[int, ...]) -> None:
        ...
    def resize(self, newSize: int) -> None:
        ...
    def set(self, index: int, value: ...) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[...]:
        ...
    @property
    def data(self) -> dict[int, ...]:
        ...
    @property
    def default_value(self) -> ...:
        ...
    @property
    def sparsity(self) -> float:
        ...
class SpaseArrayTapModuleControl:
    def __init__(self, n: int, default_value: TapModuleControl) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: TapModuleControl) -> None:
        ...
    def get(self, index: int) -> TapModuleControl:
        ...
    def init(self, size: int, default_value: TapModuleControl, data: dict[int, TapModuleControl]) -> None:
        ...
    def resize(self, newSize: int) -> None:
        ...
    def set(self, index: int, value: TapModuleControl) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[TapModuleControl]:
        ...
    @property
    def data(self) -> dict[int, TapModuleControl]:
        ...
    @property
    def default_value(self) -> TapModuleControl:
        ...
    @property
    def sparsity(self) -> float:
        ...
class SpaseArrayTapPhaseControl:
    def __init__(self, n: int, default_value: TapPhaseControl) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: TapPhaseControl) -> None:
        ...
    def get(self, index: int) -> TapPhaseControl:
        ...
    def init(self, size: int, default_value: TapPhaseControl, data: dict[int, TapPhaseControl]) -> None:
        ...
    def resize(self, newSize: int) -> None:
        ...
    def set(self, index: int, value: TapPhaseControl) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[TapPhaseControl]:
        ...
    @property
    def data(self) -> dict[int, TapPhaseControl]:
        ...
    @property
    def default_value(self) -> TapPhaseControl:
        ...
    @property
    def sparsity(self) -> float:
        ...
class SpaseArraybool:
    def __init__(self, n: int, default_value: bool) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: bool) -> None:
        ...
    def get(self, index: int) -> bool:
        ...
    def init(self, size: int, default_value: bool, data: dict[int, bool]) -> None:
        ...
    def resize(self, newSize: int) -> None:
        ...
    def set(self, index: int, value: bool) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[bool]:
        ...
    @property
    def data(self) -> dict[int, bool]:
        ...
    @property
    def default_value(self) -> bool:
        ...
    @property
    def sparsity(self) -> float:
        ...
class SpaseArraydouble:
    def __init__(self, n: int, default_value: float) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: float) -> None:
        ...
    def get(self, index: int) -> float:
        ...
    def init(self, size: int, default_value: float, data: dict[int, float]) -> None:
        ...
    def resize(self, newSize: int) -> None:
        ...
    def set(self, index: int, value: float) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[float]:
        ...
    @property
    def data(self) -> dict[int, float]:
        ...
    @property
    def default_value(self) -> float:
        ...
    @property
    def sparsity(self) -> float:
        ...
class SpaseArrayint:
    def __init__(self, n: int, default_value: int) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: int) -> None:
        ...
    def get(self, index: int) -> int:
        ...
    def init(self, size: int, default_value: int, data: dict[int, int]) -> None:
        ...
    def resize(self, newSize: int) -> None:
        ...
    def set(self, index: int, value: int) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[int]:
        ...
    @property
    def data(self) -> dict[int, int]:
        ...
    @property
    def default_value(self) -> int:
        ...
    @property
    def sparsity(self) -> float:
        ...
class SpaseArrayuint:
    def __init__(self, n: int, default_value: int) -> None:
        ...
    def __len__(self) -> int:
        ...
    def fill(self, value: int) -> None:
        ...
    def get(self, index: int) -> int:
        ...
    def init(self, size: int, default_value: int, data: dict[int, int]) -> None:
        ...
    def resize(self, newSize: int) -> None:
        ...
    def set(self, index: int, value: int) -> None:
        ...
    def size(self) -> int:
        ...
    def to_list(self) -> list[int]:
        ...
    @property
    def data(self) -> dict[int, int]:
        ...
    @property
    def default_value(self) -> int:
        ...
    @property
    def sparsity(self) -> float:
        ...
class StaticGenerator(LoadParent):
    def __init__(self, nt: int, bus: Bus = None, name: str = 'Load', idtag: str = '', code: str = '', P: float = 0.0, Q: float = 0.0, Cost: float = 1200.0, active: bool = True, mttf: float = 0.0, mttr: float = 0.0, capex: float = 0.0, opex: float = 0.0, build_status: BuildStatus = ...) -> None:
        """
        Constructor for StaticGenerator.
        
        :param nt: Number of simulation timesteps.
        :param bus: Pointer to the connected AC bus (*None* for unassigned).
        :param name/idtag/code: Readable name and identifiers.
        :param P/Q: Fixed active and reactive power injections (MW / MVAr).
        :param Cost: Linear cost coefficient for generation.
        :param active: Whether the generator is energised in the base case.
        :param mttf/mttr: Mean time to failure / repair (h).
        :param capex/opex: Capital and annual operating expenditure (currency units).
        :param build_status: Construction / service status enumeration.
        """
class SubObjectType:
    """
    Members:
    
      Profile
    
      GeneratorQCurve
    
      LineLocations
    
      TapChanger
    
      Array
    
      ObjectsList
    
      Associations
    """
    Array: typing.ClassVar[SubObjectType]  # value = <SubObjectType.Array: 4>
    Associations: typing.ClassVar[SubObjectType]  # value = <SubObjectType.Associations: 6>
    GeneratorQCurve: typing.ClassVar[SubObjectType]  # value = <SubObjectType.GeneratorQCurve: 1>
    LineLocations: typing.ClassVar[SubObjectType]  # value = <SubObjectType.LineLocations: 2>
    ObjectsList: typing.ClassVar[SubObjectType]  # value = <SubObjectType.ObjectsList: 5>
    Profile: typing.ClassVar[SubObjectType]  # value = <SubObjectType.Profile: 0>
    TapChanger: typing.ClassVar[SubObjectType]  # value = <SubObjectType.TapChanger: 3>
    __members__: typing.ClassVar[dict[str, SubObjectType]]  # value = {'Profile': <SubObjectType.Profile: 0>, 'GeneratorQCurve': <SubObjectType.GeneratorQCurve: 1>, 'LineLocations': <SubObjectType.LineLocations: 2>, 'TapChanger': <SubObjectType.TapChanger: 3>, 'Array': <SubObjectType.Array: 4>, 'ObjectsList': <SubObjectType.ObjectsList: 5>, 'Associations': <SubObjectType.Associations: 6>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Substation(GenericAreaGroup):
    def __init__(self, nt: int, name: str = '', idtag: str = '', code: str = '') -> None:
        """
        Constructor for Substation.
        
        :param nt: Number of timesteps
        :param name: Name of the substation
        :param idtag: ID tag for the substation
        :param code: Code for the substation
        """
    @property
    def area(self) -> Area:
        """
        The associated area.
        
        :getter: Get the area.
        :setter: Set the area.
        """
    @area.setter
    def area(self, arg1: Area) -> None:
        ...
    @property
    def community(self) -> Community:
        """
        The associated community.
        
        :getter: Get the community.
        :setter: Set the community.
        """
    @community.setter
    def community(self, arg1: Community) -> None:
        ...
    @property
    def country(self) -> Country:
        """
        The associated country.
        
        :getter: Get the country.
        :setter: Set the country.
        """
    @country.setter
    def country(self, arg1: Country) -> None:
        ...
    @property
    def irradiation(self) -> Profiledouble:
        """
        The irradiation profile.
        
        :getter: Get the irradiation profile.
        :setter: Set the irradiation profile.
        """
    @irradiation.setter
    def irradiation(self, arg1: Profiledouble) -> None:
        ...
    @property
    def municipality(self) -> Municipality:
        """
        The associated municipality.
        
        :getter: Get the municipality.
        :setter: Set the municipality.
        """
    @municipality.setter
    def municipality(self, arg1: Municipality) -> None:
        ...
    @property
    def region(self) -> Region:
        """
        The associated region.
        
        :getter: Get the region.
        :setter: Set the region.
        """
    @region.setter
    def region(self, arg1: Region) -> None:
        ...
    @property
    def temperature(self) -> Profiledouble:
        """
        The temperature profile.
        
        :getter: Get the temperature profile.
        :setter: Set the temperature profile.
        """
    @temperature.setter
    def temperature(self, arg1: Profiledouble) -> None:
        ...
    @property
    def terrain_roughness(self) -> float:
        """
        The terrain roughness value.
        
        :getter: Get the terrain roughness.
        :setter: Set the terrain roughness.
        """
    @terrain_roughness.setter
    def terrain_roughness(self, arg1: float) -> None:
        ...
    @property
    def wind_speed(self) -> Profiledouble:
        """
        The wind speed profile.
        
        :getter: Get the wind speed profile.
        :setter: Set the wind speed profile.
        """
    @wind_speed.setter
    def wind_speed(self, arg1: Profiledouble) -> None:
        ...
    @property
    def zone(self) -> Zone:
        """
        The associated zone.
        
        :getter: Get the zone.
        :setter: Set the zone.
        """
    @zone.setter
    def zone(self, arg1: Zone) -> None:
        ...
class SubstationTypes:
    """
    Members:
    
      SingleBar
    
      SingleBarWithBypass
    
      SingleBarWithSplitter
    
      DoubleBar
    
      DoubleBarWithBypass
    
      DoubleBarWithTransference
    
      DoubleBarDuplex
    
      Ring
    
      BreakerAndAHalf
    """
    BreakerAndAHalf: typing.ClassVar[SubstationTypes]  # value = <SubstationTypes.BreakerAndAHalf: 8>
    DoubleBar: typing.ClassVar[SubstationTypes]  # value = <SubstationTypes.DoubleBar: 3>
    DoubleBarDuplex: typing.ClassVar[SubstationTypes]  # value = <SubstationTypes.DoubleBarDuplex: 6>
    DoubleBarWithBypass: typing.ClassVar[SubstationTypes]  # value = <SubstationTypes.DoubleBarWithBypass: 4>
    DoubleBarWithTransference: typing.ClassVar[SubstationTypes]  # value = <SubstationTypes.DoubleBarWithTransference: 5>
    Ring: typing.ClassVar[SubstationTypes]  # value = <SubstationTypes.Ring: 7>
    SingleBar: typing.ClassVar[SubstationTypes]  # value = <SubstationTypes.SingleBar: 0>
    SingleBarWithBypass: typing.ClassVar[SubstationTypes]  # value = <SubstationTypes.SingleBarWithBypass: 1>
    SingleBarWithSplitter: typing.ClassVar[SubstationTypes]  # value = <SubstationTypes.SingleBarWithSplitter: 2>
    __members__: typing.ClassVar[dict[str, SubstationTypes]]  # value = {'SingleBar': <SubstationTypes.SingleBar: 0>, 'SingleBarWithBypass': <SubstationTypes.SingleBarWithBypass: 1>, 'SingleBarWithSplitter': <SubstationTypes.SingleBarWithSplitter: 2>, 'DoubleBar': <SubstationTypes.DoubleBar: 3>, 'DoubleBarWithBypass': <SubstationTypes.DoubleBarWithBypass: 4>, 'DoubleBarWithTransference': <SubstationTypes.DoubleBarWithTransference: 5>, 'DoubleBarDuplex': <SubstationTypes.DoubleBarDuplex: 6>, 'Ring': <SubstationTypes.Ring: 7>, 'BreakerAndAHalf': <SubstationTypes.BreakerAndAHalf: 8>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Switch(BranchParent):
    def __init__(self, nt: int, bus_from: Bus = None, bus_to: Bus = None, name: str = 'Switch', idtag: str = '', code: str = '', r: float = 1e-20, x: float = 1e-20, rate: float = 1.0, active: bool = True, contingency_factor: float = 1.0, protection_rating_factor: float = 1.4, retained: bool = True, normal_open: bool = False, rated_current: float = 0.0) -> None:
        """
        Constructor for Switch.
        
        :param nt: Number of simulation timesteps.
        :param bus_from: Pointer to the *from* bus (may be *None*).
        :param bus_to: Pointer to the *to* bus (may be *None*).
        :param name: Human-readable switch name.
        :param idtag: Stable unique identifier tag.
        :param code: Engineering code or label.
        :param r: Series resistance **R** in per-unit.
        :param x: Series reactance **X** in per-unit.
        :param rate: Continuous current rating **I<sub>max</sub>** (pu).
        :param active: Initial active state profile.
        :param contingency_factor: Multiplicative contingency rating factor.
        :param protection_rating_factor: Protection-based rating factor.
        :param retained: Whether the switch remains in reduced equivalent networks.
        :param normal_open: Whether the switch is normally open in the base case.
        :param rated_current: Manufacturer’s rated current (pu).
        """
    @property
    def R(self) -> float:
        """
        Series resistance **R** (pu).
        """
    @R.setter
    def R(self, arg1: float) -> None:
        ...
    @property
    def X(self) -> float:
        """
        Series reactance **X** (pu).
        """
    @X.setter
    def X(self, arg1: float) -> None:
        ...
    @property
    def normal_open(self) -> bool:
        """
        Whether the switch is normally open in the base case.
        """
    @normal_open.setter
    def normal_open(self, arg1: bool) -> None:
        ...
    @property
    def rated_current(self) -> float:
        """
        Manufacturer’s rated current (pu).
        """
    @rated_current.setter
    def rated_current(self, arg1: float) -> None:
        ...
    @property
    def retained(self) -> bool:
        """
        Whether the switch is retained in reduced equivalents.
        """
    @retained.setter
    def retained(self, arg1: bool) -> None:
        ...
class TapChanger:
    def __init__(self, total_positions: int = 1, neutral_position: int = 0, normal_position: int = 0, dV: float = 0.01, asymmetry_angle: float = 90.0, tc_type: TapChangerTypes = ...) -> None:
        """
        Constructor for TapChanger.
        
        :param total_positions: Total number of discrete tap positions.
        :param neutral_position: Index of the neutral (0 pu) position.
        :param normal_position: Index of the normal operating position.
        :param dV: Voltage increment per tap step (pu).
        :param asymmetry_angle: Phase-asymmetry angle between tap limbs (deg).
        :param tc_type: Tap-changer type (e.g. on-load, off-load).
        """
    def from_dict(self, arg0: dict[str, float]) -> None:
        """
        Load the tap-changer state from a Python *dict*.
        """
    def get_tap_module_2(self, tap_position: int) -> float:
        """
        Return the magnitude (pu) at the specified *tap_position*.
        
        :param tap_position: Tap index (integer).
        """
    def get_tap_phase_2(self, tap_position: int) -> float:
        """
        Return the phase shift (deg) at the specified *tap_position*.
        
        :param tap_position: Tap index (integer).
        """
    def initialize(self, total_positions: int = 1, neutral_position: int = 0, normal_position: int = 0, dV: float = 0.01, asymmetry_angle: float = 90.0, tc_type: TapChangerTypes = ...) -> None:
        """
        Re-initialise the tap-changer with new settings.
        
        :param total_positions: Total number of discrete tap positions.
        :param neutral_position: Index of the neutral (0 pu) position.
        :param normal_position: Index of the normal operating position.
        :param dV: Voltage increment per tap step (pu).
        :param asymmetry_angle: Phase-asymmetry angle between tap limbs (deg).
        :param tc_type: Tap-changer type.
        """
    def print_details(self) -> None:
        """
        Print a detailed textual description to *stdout*.
        """
    def reset(self) -> None:
        """
        Reset the tap position to the neutral setting.
        """
    def tap_down(self) -> None:
        """
        Decrease the tap position by one step (if possible).
        """
    def tap_up(self) -> None:
        """
        Increase the tap position by one step (if possible).
        """
    def to_dict(self, arg0: dict[str, float]) -> None:
        """
        Serialise the tap-changer state to a Python *dict*.
        """
    @property
    def m_array(self) -> Numpy.ndarray[]:
        """
        Array of magnitude values (pu) for all positions.
        """
    @property
    def neutral_position(self) -> int:
        """
        Neutral (0 pu) tap position index.
        """
    @neutral_position.setter
    def neutral_position(self, arg1: int) -> None:
        ...
    @property
    def tap_position(self) -> int:
        """
        Current tap position index.
        """
    @tap_position.setter
    def tap_position(self, arg1: int) -> None:
        ...
    @property
    def tau_array(self) -> Numpy.ndarray[]:
        """
        Array of phase-shift values (deg) for all positions.
        """
    @property
    def total_positions(self) -> int:
        """
        Total number of discrete tap positions.
        """
    @total_positions.setter
    def total_positions(self, arg1: int) -> None:
        ...
class TapChangerTypes:
    """
    Members:
    
      NoRegulation
    
      VoltageRegulation
    
      Asymmetrical
    
      Symmetrical
    """
    Asymmetrical: typing.ClassVar[TapChangerTypes]  # value = <TapChangerTypes.Asymmetrical: 2>
    NoRegulation: typing.ClassVar[TapChangerTypes]  # value = <TapChangerTypes.NoRegulation: 0>
    Symmetrical: typing.ClassVar[TapChangerTypes]  # value = <TapChangerTypes.Symmetrical: 3>
    VoltageRegulation: typing.ClassVar[TapChangerTypes]  # value = <TapChangerTypes.VoltageRegulation: 1>
    __members__: typing.ClassVar[dict[str, TapChangerTypes]]  # value = {'NoRegulation': <TapChangerTypes.NoRegulation: 0>, 'VoltageRegulation': <TapChangerTypes.VoltageRegulation: 1>, 'Asymmetrical': <TapChangerTypes.Asymmetrical: 2>, 'Symmetrical': <TapChangerTypes.Symmetrical: 3>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class TapModuleControl:
    """
    Members:
    
      fixed
    
      Vm
    
      Qf
    
      Qt
    """
    Qf: typing.ClassVar[TapModuleControl]  # value = <TapModuleControl.Qf: 2>
    Qt: typing.ClassVar[TapModuleControl]  # value = <TapModuleControl.Qt: 3>
    Vm: typing.ClassVar[TapModuleControl]  # value = <TapModuleControl.Vm: 1>
    __members__: typing.ClassVar[dict[str, TapModuleControl]]  # value = {'fixed': <TapModuleControl.fixed: 0>, 'Vm': <TapModuleControl.Vm: 1>, 'Qf': <TapModuleControl.Qf: 2>, 'Qt': <TapModuleControl.Qt: 3>}
    fixed: typing.ClassVar[TapModuleControl]  # value = <TapModuleControl.fixed: 0>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class TapPhaseControl:
    """
    Members:
    
      fixed
    
      Pf
    
      Pt
    """
    Pf: typing.ClassVar[TapPhaseControl]  # value = <TapPhaseControl.Pf: 1>
    Pt: typing.ClassVar[TapPhaseControl]  # value = <TapPhaseControl.Pt: 2>
    __members__: typing.ClassVar[dict[str, TapPhaseControl]]  # value = {'fixed': <TapPhaseControl.fixed: 0>, 'Pf': <TapPhaseControl.Pf: 1>, 'Pt': <TapPhaseControl.Pt: 2>}
    fixed: typing.ClassVar[TapPhaseControl]  # value = <TapPhaseControl.fixed: 0>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Technology(EditableDevice):
    def __init__(self, name: str = 'Fuel', idtag: str = '', code: str = '') -> None:
        """
        Constructor for Technology.
        
        :param name: Name of the technology
        :param idtag: ID tag for the technology
        :param code: Code for the technology
        """
    @property
    def color(self) -> str:
        """
        Color representation of the technology.
        
        :getter: Get the color.
        :setter: Set the color.
        """
    @color.setter
    def color(self, arg1: str) -> None:
        ...
    @property
    def name2(self) -> str:
        """
        The secondary name of the technology.
        
        :getter: Get the secondary name.
        :setter: Set the secondary name.
        """
    @name2.setter
    def name2(self, arg1: str) -> None:
        ...
    @property
    def name3(self) -> str:
        """
        The tertiary name of the technology.
        
        :getter: Get the tertiary name.
        :setter: Set the tertiary name.
        """
    @name3.setter
    def name3(self, arg1: str) -> None:
        ...
    @property
    def name4(self) -> str:
        """
        The quaternary name of the technology.
        
        :getter: Get the quaternary name.
        :setter: Set the quaternary name.
        """
    @name4.setter
    def name4(self, arg1: str) -> None:
        ...
class TimeFrame:
    """
    Members:
    
      Continuous
    """
    Continuous: typing.ClassVar[TimeFrame]  # value = <TimeFrame.Continuous: 0>
    __members__: typing.ClassVar[dict[str, TimeFrame]]  # value = {'Continuous': <TimeFrame.Continuous: 0>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class TimeGrouping:
    """
    Members:
    
      NoGrouping
    
      Monthly
    
      Weekly
    
      Daily
    
      Hourly
    """
    Daily: typing.ClassVar[TimeGrouping]  # value = <TimeGrouping.Daily: 3>
    Hourly: typing.ClassVar[TimeGrouping]  # value = <TimeGrouping.Hourly: 4>
    Monthly: typing.ClassVar[TimeGrouping]  # value = <TimeGrouping.Monthly: 1>
    NoGrouping: typing.ClassVar[TimeGrouping]  # value = <TimeGrouping.NoGrouping: 0>
    Weekly: typing.ClassVar[TimeGrouping]  # value = <TimeGrouping.Weekly: 2>
    __members__: typing.ClassVar[dict[str, TimeGrouping]]  # value = {'NoGrouping': <TimeGrouping.NoGrouping: 0>, 'Monthly': <TimeGrouping.Monthly: 1>, 'Weekly': <TimeGrouping.Weekly: 2>, 'Daily': <TimeGrouping.Daily: 3>, 'Hourly': <TimeGrouping.Hourly: 4>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Transformer2W(ControllableBranchParent):
    def __init__(self, nt: int, name: str = 'Branch', idtag: str = '', code: str = '', bus_from: Bus = None, bus_to: Bus = None, HV: float = 10.0, LV: float = 10.0, nominal_power: float = 0.001, copper_losses: float = 0.0, iron_losses: float = 0.0, no_load_current: float = 0.0, short_circuit_voltage: float = 0.0, active: bool = True, rate: float = 1.0, r: float = 1e-20, x: float = 1e-20, g: float = 1e-20, b: float = 1e-20, tap_module: float = 1.0, tap_module_max: float = 1.1, tap_module_min: float = 0.9, tap_phase: float = 0.0, tap_phase_max: float = -0.5, tap_phase_min: float = 0.5, tolerance: float = 0.0, cost: float = 100.0, mttf: float = 0.0, mttr: float = 0.0, vset: float = 1.0, Pset: float = 0.0, Qset: float = 0.0, temp_base: float = 20.0, temp_oper: float = 20.0, alpha: float = 0.0033, tap_module_control_mode: TapModuleControl = ..., tap_phase_control_mode: TapPhaseControl = ..., contingency_factor: float = 1.0, protection_rating_factor: float = 1.4, monitor_loading: bool = True, r0: float = 1e-20, x0: float = 1e-20, g0: float = 1e-20, b0: float = 1e-20, r2: float = 1e-20, x2: float = 1e-20, g2: float = 1e-20, b2: float = 1e-20, conn: WindingsConnection = ..., capex: float = 0.0, opex: float = 0.0, build_status: BuildStatus = ..., tc_total_positions: int = 5, tc_neutral_position: int = 2, tc_normal_position: int = 2, tc_dV: float = 0.01, tc_asymmetry_angle: float = 90.0, tc_type: TapChangerTypes = ...) -> None:
        """
        Constructor for Transformer2W.
        
        :param nt: Number of simulation timesteps.
        :param name: Human-readable device name.
        :param idtag: Stable unique identifier tag.
        :param code: Engineering code or label.
        :param bus_from: Pointer to the high-voltage (HV) bus.
        :param bus_to: Pointer to the low-voltage (LV) bus.
        :param HV: Rated HV winding voltage (kV).
        :param LV: Rated LV winding voltage (kV).
        :param nominal_power: Rated apparent power **S<sub>n</sub>** (MVA).
        :param copper_losses: Full-load copper losses **P<sub>cu</sub>** (kW).
        :param iron_losses: No-load iron/core losses **P<sub>fe</sub>** (kW).
        :param no_load_current: Exciting current at no-load (**%** of rated).
        :param short_circuit_voltage: Short-circuit voltage **V<sub>sc</sub>** ( % ).
        :param active: Initial active state profile.
        :param rate: Continuous thermal rating **I<sub>max</sub>** (pu).
        :param r/x/g/b: Positive-sequence series impedance and shunt admittance components (pu).
        :param tap_module: Initial tap magnitude (pu).
        :param tap_module_max|min: Tap magnitude limits (pu).
        :param tap_phase: Initial tap phase shift (deg).
        :param tap_phase_max|min: Phase-shift limits (deg).
        :param tolerance: Power-flow convergence tolerance (pu).
        :param cost: Operating cost per unit energy or time.
        :param mttf/mttr: Mean time to failure / repair (h).
        :param vset, Pset, Qset: Voltage and power set-points.
        :param temp_base/temp_oper: Reference and operating temperatures (°C).
        :param alpha: Temperature coefficient of resistance (1/°C).
        :param tap_module_control_mode: Control strategy for tap magnitude.
        :param tap_phase_control_mode: Control strategy for tap phase.
        :param contingency_factor: Multiplicative contingency rating factor.
        :param protection_rating_factor: Protection-based rating factor.
        :param monitor_loading: Enable automatic loading alarms.
        :param r0/x0/g0/b0: Zero-sequence impedance/admittance components (pu).
        :param r2/x2/g2/b2: Negative-sequence impedance/admittance components (pu).
        :param conn: Winding connection enumeration (e.g. *YNd* ⇒ GG).
        :param capex/opex: Capital and annual operating expenditure (currency units).
        :param build_status: Construction / service status enumeration.
        :param tc_total_positions: Total discrete tap-changer positions.
        :param tc_neutral_position: Neutral (0 pu) tap index.
        :param tc_normal_position: Normal operating tap index.
        :param tc_dV: Voltage increment per tap step (pu).
        :param tc_asymmetry_angle: Phase-asymmetry angle between tap limbs (deg).
        :param tc_type: Tap-changer type (on-load, off-load, etc.).
        """
    def get_from_to_nominal_voltages(self) -> tuple[float, float]:
        """
        Return a tuple *(HV, LV)* of rated voltages (kV).
        """
    def get_virtual_taps(self) -> tuple[float, float]:
        """
        Return the vector of virtual tap positions (pu).
        """
    def set_hv_and_lv(self, HV_val: float, LV_val: float) -> None:
        """
        Set both HV and LV nominal voltages (kV).
        """
    @property
    def HV(self) -> float:
        """
        High-voltage winding rating (kV).
        """
    @HV.setter
    def HV(self, arg1: float) -> None:
        ...
    @property
    def LV(self) -> float:
        """
        Low-voltage winding rating (kV).
        """
    @LV.setter
    def LV(self, arg1: float) -> None:
        ...
    @property
    def conn(self) -> WindingsConnection:
        """
        Winding connection enumeration.
        """
    @conn.setter
    def conn(self, arg1: WindingsConnection) -> None:
        ...
    @property
    def copper_losses(self) -> float:
        """
        Full-load copper losses **P<sub>cu</sub>** (kW).
        """
    @copper_losses.setter
    def copper_losses(self, arg1: float) -> None:
        ...
    @property
    def iron_losses(self) -> float:
        """
        No-load iron/core losses **P<sub>fe</sub>** (kW).
        """
    @iron_losses.setter
    def iron_losses(self, arg1: float) -> None:
        ...
    @property
    def no_load_current(self) -> float:
        """
        Exciting current at no-load ( %  of rated).
        """
    @no_load_current.setter
    def no_load_current(self, arg1: float) -> None:
        ...
    @property
    def nominal_power(self) -> float:
        """
        Rated apparent power **S<sub>n</sub>** (MVA).
        """
    @nominal_power.setter
    def nominal_power(self, arg1: float) -> None:
        ...
    @property
    def possible_transformer_types(self) -> Associations:
        """
        Possible transformer-type templates that may be assigned.
        """
    @possible_transformer_types.setter
    def possible_transformer_types(self, arg1: Associations) -> None:
        ...
    @property
    def short_circuit_voltage(self) -> float:
        """
        Short-circuit voltage **V<sub>sc</sub>** ( % ).
        """
    @short_circuit_voltage.setter
    def short_circuit_voltage(self, arg1: float) -> None:
        ...
    @property
    def template(self) -> ...:
        """
        Associated transformer-type template (if any).
        """
    @template.setter
    def template(self, arg1: ...) -> None:
        ...
class Transformer3W(PhysicalDevice):
    def __init__(self, nt: int = 1, idtag: str = '', code: str = '', name: str = 'Branch', bus0: Bus = None, bus1: Bus = None, bus2: Bus = None, bus3: Bus = None, w1_idtag: str = '', w2_idtag: str = '', w3_idtag: str = '', V1: float = 10.0, V2: float = 10.0, V3: float = 10.0, active: bool = True, r12: float = 0.0, r23: float = 0.0, r31: float = 0.0, x12: float = 0.0, x23: float = 0.0, x31: float = 0.0, rate12: float = 0.0, rate23: float = 0.0, rate31: float = 0.0, x: float = 0.0, y: float = 0.0) -> None:
        """
        Constructor for Transformer3W.
        
        :param nt: Number of simulation timesteps.
        :param idtag: Stable unique identifier for the transformer.
        :param code: Short engineering code or label.
        :param name: Human-readable transformer name.
        :param bus0: Pointer to the reference bus (*star point* or neutral).
        :param bus1: Pointer to the first connected bus (winding 1).
        :param bus2: Pointer to the second connected bus (winding 2).
        :param bus3: Pointer to the third connected bus (winding 3).
        :param w1_idtag: Identifier tag for winding 1 object.
        :param w2_idtag: Identifier tag for winding 2 object.
        :param w3_idtag: Identifier tag for winding 3 object.
        :param V1: Rated voltage of winding 1 (kV).
        :param V2: Rated voltage of winding 2 (kV).
        :param V3: Rated voltage of winding 3 (kV).
        :param active: Whether the transformer is enabled in the base case.
        :param r12/r23/r31: Series resistances between winding pairs 1-2, 2-3, 3-1 (pu).
        :param x12/x23/x31: Series reactances between winding pairs 1-2, 2-3, 3-1 (pu).
        :param rate12/rate23/rate31: Apparent-power ratings of each winding pair (MVA).
        :param x, y: Optional graphical coordinates for single-line diagrams.
        """
    def recompute(self, Sbase: float = 100.0) -> None:
        """
        Recompute pair impedances from the stored short-circuit test values.
        """
        ...
    @property
    def R12(self) -> float:
        """
        Series resistance between windings 1 and 2 (pu).
        """
    @R12.setter
    def R12(self, arg1: float) -> None:
        ...
    @property
    def R23(self) -> float:
        """
        Series resistance between windings 2 and 3 (pu).
        """
    @R23.setter
    def R23(self, arg1: float) -> None:
        ...
    @property
    def R31(self) -> float:
        """
        Series resistance between windings 3 and 1 (pu).
        """
    @R31.setter
    def R31(self, arg1: float) -> None:
        ...
    @property
    def V1(self) -> float:
        """
        Nominal voltage of winding 1 (kV).
        """
    @V1.setter
    def V1(self, arg1: float) -> None:
        ...
    @property
    def V2(self) -> float:
        """
        Nominal voltage of winding 2 (kV).
        """
    @V2.setter
    def V2(self, arg1: float) -> None:
        ...
    @property
    def V3(self) -> float:
        """
        Nominal voltage of winding 3 (kV).
        """
    @V3.setter
    def V3(self, arg1: float) -> None:
        ...
    @property
    def X12(self) -> float:
        """
        Series reactance between windings 1 and 2 (pu).
        """
    @X12.setter
    def X12(self, arg1: float) -> None:
        ...
    @property
    def X23(self) -> float:
        """
        Series reactance between windings 2 and 3 (pu).
        """
    @X23.setter
    def X23(self, arg1: float) -> None:
        ...
    @property
    def X31(self) -> float:
        """
        Series reactance between windings 3 and 1 (pu).
        """
    @X31.setter
    def X31(self, arg1: float) -> None:
        ...
    @property
    def active(self) -> bool:
        """
        Whether the transformer is active.
        """
    @active.setter
    def active(self, arg1: bool) -> None:
        ...
    @property
    def bus0(self) -> Bus:
        """
        Reference bus (bus0).
        """
    @bus0.setter
    def bus0(self, arg1: Bus) -> None:
        ...
    @property
    def bus1(self) -> Bus:
        """
        First bus (bus1).
        """
    @bus1.setter
    def bus1(self, arg1: Bus) -> None:
        ...
    @property
    def bus2(self) -> Bus:
        """
        Second bus (bus2).
        """
    @bus2.setter
    def bus2(self, arg1: Bus) -> None:
        ...
    @property
    def bus3(self) -> Bus:
        """
        Third bus (bus3).
        """
    @bus3.setter
    def bus3(self, arg1: Bus) -> None:
        ...
    @property
    def I0(self) -> float:
        """
        No-load current (%).
        """
    @I0.setter
    def I0(self, arg1: float) -> None:
        ...
    @property
    def nt(self) -> int:
        """
        Number of timesteps.
        """
    @property
    def Pcu12(self) -> float:
        """
        Copper loss between windings 1 and 2 (kW).
        """
    @Pcu12.setter
    def Pcu12(self, arg1: float) -> None:
        ...
    @property
    def Pcu23(self) -> float:
        """
        Copper loss between windings 2 and 3 (kW).
        """
    @Pcu23.setter
    def Pcu23(self, arg1: float) -> None:
        ...
    @property
    def Pcu31(self) -> float:
        """
        Copper loss between windings 3 and 1 (kW).
        """
    @Pcu31.setter
    def Pcu31(self, arg1: float) -> None:
        ...
    @property
    def Pfe(self) -> float:
        """
        Iron loss (kW).
        """
    @Pfe.setter
    def Pfe(self, arg1: float) -> None:
        ...
    @property
    def rate1(self) -> float:
        """
        Apparent-power rating of winding 1 (MVA).
        """
    @rate1.setter
    def rate1(self, arg1: float) -> None:
        ...
    @property
    def rate2(self) -> float:
        """
        Apparent-power rating of winding 2 (MVA).
        """
    @rate2.setter
    def rate2(self, arg1: float) -> None:
        ...
    @property
    def rate3(self) -> float:
        """
        Apparent-power rating of winding 3 (MVA).
        """
    @rate3.setter
    def rate3(self, arg1: float) -> None:
        ...
    @property
    def Vsc12(self) -> float:
        """
        Short-circuit voltage between windings 1 and 2 (%).
        """
    @Vsc12.setter
    def Vsc12(self, arg1: float) -> None:
        ...
    @property
    def Vsc23(self) -> float:
        """
        Short-circuit voltage between windings 2 and 3 (%).
        """
    @Vsc23.setter
    def Vsc23(self, arg1: float) -> None:
        ...
    @property
    def Vsc31(self) -> float:
        """
        Short-circuit voltage between windings 3 and 1 (%).
        """
    @Vsc31.setter
    def Vsc31(self, arg1: float) -> None:
        ...
    @property
    def winding1(self) -> Winding:
        """
        First winding object.
        """
    @winding1.setter
    def winding1(self, arg1: Winding) -> None:
        ...
    @property
    def winding2(self) -> Winding:
        """
        Second winding object.
        """
    @winding2.setter
    def winding2(self, arg1: Winding) -> None:
        ...
    @property
    def winding3(self) -> Winding:
        """
        Third winding object.
        """
    @winding3.setter
    def winding3(self, arg1: Winding) -> None:
        ...
    @property
    def x(self) -> float:
        """
        X coordinate for graphical layout.
        """
    @x.setter
    def x(self, arg1: float) -> None:
        ...
    @property
    def y(self) -> float:
        """
        Y coordinate for graphical layout.
        """
    @y.setter
    def y(self, arg1: float) -> None:
        ...
class UndergroundLineType(EditableDevice):
    def __init__(self, name: str = 'UndergroundLine', idtag: str = '', Imax: float = 1.0, Vnom: float = 1.0, R: float = 0.0, X: float = 0.0, B: float = 0.0, R0: float = 0.0, X0: float = 0.0, B0: float = 0.0) -> None:
        """
        Constructor for UndergroundLineType.
        
        :param name: Readable type name.
        :param idtag: Stable unique identifier tag.
        :param Imax: Continuous current rating **I<sub>max</sub>** (kA).
        :param Vnom: Nominal voltage **V<sub>nom</sub>** (kV).
        :param R: Positive-sequence series resistance **R** (Ω/km).
        :param X: Positive-sequence series reactance **X** (Ω/km).
        :param B: Positive-sequence shunt susceptance **B/2** (µS/km).
        :param R0: Zero-sequence resistance **R₀** (Ω/km).
        :param X0: Zero-sequence reactance **X₀** (Ω/km).
        :param B0: Zero-sequence susceptance **B₀/2** (µS/km).
        """
    def change_base(self, Sbase_old: float, Sbase_new: float) -> None:
        """
        Convert the stored per-unit values to a new base.
        
        :param Sbase_old: Old base power (MVA).
        :param Sbase_new: New base power (MVA).
        """
    def get_values(self, Sbase: float, length: float) -> ...:
        """
        Get per-unit impedance/admittance values for the line.
        
        :param Sbase: System base power (MVA).
        :param length: Line length (km).
        :return: *PerUnitValues* object.
        """
    def y_shunt(self) -> complex:
        """
        Positive-sequence shunt admittance (S per km).
        """
    def z_series(self) -> complex:
        """
        Positive-sequence series impedance (Ω per km).
        """
    @property
    def B(self) -> float:
        """
        Positive-sequence susceptance **B/2** (µS/km).
        """
    @B.setter
    def B(self, arg1: float) -> None:
        ...
    @property
    def B0(self) -> float:
        """
        Zero-sequence susceptance **B₀/2** (µS/km).
        """
    @B0.setter
    def B0(self, arg1: float) -> None:
        ...
    @property
    def Imax(self) -> float:
        """
        Current rating **I<sub>max</sub>** (kA).
        """
    @Imax.setter
    def Imax(self, arg1: float) -> None:
        ...
    @property
    def R(self) -> float:
        """
        Positive-sequence resistance **R** (Ω/km).
        """
    @R.setter
    def R(self, arg1: float) -> None:
        ...
    @property
    def R0(self) -> float:
        """
        Zero-sequence resistance **R₀** (Ω/km).
        """
    @R0.setter
    def R0(self, arg1: float) -> None:
        ...
    @property
    def Vnom(self) -> float:
        """
        Nominal voltage **V<sub>nom</sub>** (kV).
        """
    @Vnom.setter
    def Vnom(self, arg1: float) -> None:
        ...
    @property
    def X(self) -> float:
        """
        Positive-sequence reactance **X** (Ω/km).
        """
    @X.setter
    def X(self, arg1: float) -> None:
        ...
    @property
    def X0(self) -> float:
        """
        Zero-sequence reactance **X₀** (Ω/km).
        """
    @X0.setter
    def X0(self, arg1: float) -> None:
        ...
class Upfc(BranchParent):
    def __init__(self, nt: int = 1, bus_from: Bus = None, bus_to: Bus = None, name: str = 'Upfc', code: str = '', idtag: str = '', active: bool = True, rs: float = 0.0, xs: float = 1e-05, rp: float = 0.0, xp: float = 0.0, vp: float = 1.0, Pset: float = 0.0, Qset: float = 0.0, rate: float = 9999, mttf: float = 0.0, mttr: float = 0.0, cost: float = 100.0, contingency_factor: float = 1.0, protection_rating_factor: float = 1.4, monitor_loading: bool = True, rs0: float = 0.0, xs0: float = 1e-05, rp0: float = 0.0, xp0: float = 0.0, rs2: float = 0.0, xs2: float = 1e-05, rp2: float = 0.0, xp2: float = 0.0, capex: float = 0.0, opex: float = 0.0, build_status: BuildStatus = ...) -> None:
        """
        Constructor for Upfc.
        
        :param nt: Number of simulation timesteps.
        :param bus_from: Pointer to the *from* AC bus.
        :param bus_to: Pointer to the *to* AC bus.
        :param name: Human-readable device name.
        :param code: Engineering code or label.
        :param idtag: Stable unique identifier tag.
        :param active: Whether the UPFC is energised in the base case.
        :param rs/xs: Series transformer resistance / reactance (pu).
        :param rp/xp: Shunt transformer resistance / reactance (pu).
        :param vp: Shunt-converter voltage magnitude set-point (pu).
        :param Pset, Qset: Active and reactive power set-points on the series side (MW / MVAr).
        :param rate: Continuous apparent-power rating of converters (MVA).
        :param mttf/mttr: Mean time to failure / repair (h).
        :param cost: Operating cost per unit energy or time.
        :param contingency_factor: Multiplicative contingency rating factor.
        :param protection_rating_factor: Protection-based rating factor.
        :param monitor_loading: Enable automatic loading alarms.
        :param rs0/xs0, rp0/xp0: Zero-sequence series / shunt impedances (pu).
        :param rs2/xs2, rp2/xp2: Negative-sequence series / shunt impedances (pu).
        :param capex/opex: Capital and annual operating expenditure (currency units).
        :param build_status: Construction / service status enumeration.
        """
    @property
    def Pfset(self) -> float:
        """
        Active power setpoint (MW).
        """
    @Pfset.setter
    def Pfset(self, arg1: float) -> None:
        ...
    @property
    def Qfset(self) -> float:
        """
        Reactive power setpoint (MVAr).
        """
    @Qfset.setter
    def Qfset(self, arg1: float) -> None:
        ...
    @property
    def R(self) -> float:
        """
        Series resistance (p.u.).
        """
    @R.setter
    def R(self, arg1: float) -> None:
        ...
    @property
    def R0(self) -> float:
        """
        Zero-sequence series resistance (p.u.).
        """
    @R0.setter
    def R0(self, arg1: float) -> None:
        ...
    @property
    def R2(self) -> float:
        """
        Negative-sequence series resistance (p.u.).
        """
    @R2.setter
    def R2(self, arg1: float) -> None:
        ...
    @property
    def Rsh(self) -> float:
        """
        Shunt resistance (p.u.).
        """
    @Rsh.setter
    def Rsh(self, arg1: float) -> None:
        ...
    @property
    def Rsh0(self) -> float:
        """
        Zero-sequence shunt resistance (p.u.).
        """
    @Rsh0.setter
    def Rsh0(self, arg1: float) -> None:
        ...
    @property
    def Rsh2(self) -> float:
        """
        Negative-sequence shunt resistance (p.u.).
        """
    @Rsh2.setter
    def Rsh2(self, arg1: float) -> None:
        ...
    @property
    def Vsh(self) -> float:
        """
        Shunt voltage magnitude (p.u.).
        """
    @Vsh.setter
    def Vsh(self, arg1: float) -> None:
        ...
    @property
    def X(self) -> float:
        """
        Series reactance (p.u.).
        """
    @X.setter
    def X(self, arg1: float) -> None:
        ...
    @property
    def X0(self) -> float:
        """
        Zero-sequence series reactance (p.u.).
        """
    @X0.setter
    def X0(self, arg1: float) -> None:
        ...
    @property
    def X2(self) -> float:
        """
        Negative-sequence series reactance (p.u.).
        """
    @X2.setter
    def X2(self, arg1: float) -> None:
        ...
    @property
    def Xsh(self) -> float:
        """
        Shunt reactance (p.u.).
        """
    @Xsh.setter
    def Xsh(self, arg1: float) -> None:
        ...
    @property
    def Xsh0(self) -> float:
        """
        Zero-sequence shunt reactance (p.u.).
        """
    @Xsh0.setter
    def Xsh0(self, arg1: float) -> None:
        ...
    @property
    def Xsh2(self) -> float:
        """
        Negative-sequence shunt reactance (p.u.).
        """
    @Xsh2.setter
    def Xsh2(self, arg1: float) -> None:
        ...
class Var(Expr):
    def __init__(self, name: str) -> None:
        ...
    @property
    def name(self) -> str:
        ...
class VoltageLevel(PhysicalDevice):
    def __init__(self, name: str = 'VoltageLevel', idtag: str = '', code: str = '', Vnom: float = 1.0, substation: Substation = None) -> None:
        """
        Constructor for VoltageLevel.
        
        :param name: Name of the voltage level
        :param idtag: ID tag for the voltage level
        :param code: Code for the voltage level
        :param Vnom: Nominal voltage
        :param substation: Associated substation
        """
    @property
    def Vnom(self) -> float:
        """
        Nominal voltage of the voltage level.
        
        :getter: Get the nominal voltage.
        :setter: Set the nominal voltage.
        """
    @Vnom.setter
    def Vnom(self, arg1: float) -> None:
        ...
    @property
    def substation(self) -> Substation:
        """
        Associated substation.
        
        :getter: Get the associated substation.
        :setter: Set the associated substation.
        """
    @substation.setter
    def substation(self, arg1: Substation) -> None:
        ...
class Vsc(BranchParent):
    def __init__(self, nt: int = 1, bus_from: Bus = None, bus_to: Bus = None, name: str = 'Vsc', idtag: str = '', code: str = '', active: bool = True, rate: float = 1e-09, kdp: float = -0.05, alpha1: float = 0.0001, alpha2: float = 0.015, alpha3: float = 0.2, mttf: float = 0.0, mttr: float = 0.0, overload_cost: float = 100.0, contingency_factor: float = 1.0, protection_rating_factor: float = 1.4, contingency_enabled: bool = True, monitor_loading: bool = True, capex: float = 0.0, opex: float = 0.0, build_status: BuildStatus = ..., control1: ConverterControlType = ..., control2: ConverterControlType = ..., control1_val: float = 1.0, control2_val: float = 0.0, control1_dev: PhysicalDevice = None, control2_dev: PhysicalDevice = None) -> None:
        """
        Constructor for Vsc (Voltage-Source Converter).
        
        :param nt: Number of simulation timesteps.
        :param bus_from: Pointer to the *from* AC bus.
        :param bus_to: Pointer to the *to* AC bus.
        :param name: Human-readable device name.
        :param idtag: Stable unique identifier tag.
        :param code: Engineering code or label.
        :param active: Whether the converter is energised in the base case.
        :param rate: Continuous apparent-power rating **S<sub>max</sub>** (MVA).
        :param kdp: Damping coefficient for DC voltage dynamics.
        :param alpha1–alpha3: Control-loop gains or filter coefficients.
        :param mttf/mttr: Mean time to failure / repair (h).
        :param overload_cost: Penalty cost for exceeding the rating.
        :param contingency_factor: Multiplicative contingency rating factor.
        :param protection_rating_factor: Protection-based rating factor.
        :param contingency_enabled: Include the device in N-1 studies.
        :param monitor_loading: Enable automatic loading alarms.
        :param capex/opex: Capital and annual operating expenditure.
        :param build_status: Construction / service status enumeration.
        :param control1/control2: Primary and secondary converter-control modes.
        :param control1_val/control2_val: Set-point values for each control mode.
        :param control1_dev/control2_dev: External devices that provide the control signals.
        """
    @property
    def alpha1(self) -> float:
        """
        Alpha1 parameter.
        """
    @alpha1.setter
    def alpha1(self, arg1: float) -> None:
        ...
    @property
    def alpha2(self) -> float:
        """
        Alpha2 parameter.
        """
    @alpha2.setter
    def alpha2(self, arg1: float) -> None:
        ...
    @property
    def alpha3(self) -> float:
        """
        Alpha3 parameter.
        """
    @alpha3.setter
    def alpha3(self, arg1: float) -> None:
        ...
    @property
    def control1(self) -> ProfileConverterControlType:
        """
        Primary control type.
        """
    @control1.setter
    def control1(self, arg1: ProfileConverterControlType) -> None:
        ...
    @property
    def control1_dev(self) -> ProfilePhysicalDevicePtr:
        """
        Primary control device.
        """
    @control1_dev.setter
    def control1_dev(self, arg1: ProfilePhysicalDevicePtr) -> None:
        ...
    @property
    def control1_val(self) -> Profiledouble:
        """
        Value of primary control.
        """
    @control1_val.setter
    def control1_val(self, arg1: Profiledouble) -> None:
        ...
    @property
    def control2(self) -> ProfileConverterControlType:
        """
        Secondary control type.
        """
    @control2.setter
    def control2(self, arg1: ProfileConverterControlType) -> None:
        ...
    @property
    def control2_dev(self) -> ProfilePhysicalDevicePtr:
        """
        Secondary control device.
        """
    @control2_dev.setter
    def control2_dev(self, arg1: ProfilePhysicalDevicePtr) -> None:
        ...
    @property
    def control2_val(self) -> Profiledouble:
        """
        Value of secondary control.
        """
    @control2_val.setter
    def control2_val(self, arg1: ConverterControlType) -> None:
        ...
    @property
    def kdp(self) -> float:
        """
        Damping coefficient (kdp).
        """
    @kdp.setter
    def kdp(self, arg1: float) -> None:
        ...
class VscData(BranchParentData):
    Kdp: Numpy.ndarray[]
    alpha1: Numpy.ndarray[]
    alpha2: Numpy.ndarray[]
    alpha3: Numpy.ndarray[]
    control1: list[ConverterControlType]
    control1_branch_idx: Numpy.ndarray[]
    control1_bus_idx: Numpy.ndarray[]
    control1_val: Numpy.ndarray[]
    control2: list[ConverterControlType]
    control2_branch_idx: Numpy.ndarray[]
    control2_bus_idx: Numpy.ndarray[]
    control2_val: Numpy.ndarray[]
    def __init__(self, arg0: int, arg1: int) -> None:
        ...
class Winding(Transformer2W):
    def __init__(self, nt: int, bus_from: Bus = None, bus_to: Bus = None, name: str = 'Winding', idtag: str = '', code: str = '', HV: float = 0.0, LV: float = 0.0, nominal_power: float = 0.001, copper_losses: float = 0.0, iron_losses: float = 0.0, no_load_current: float = 0.0, short_circuit_voltage: float = 0.0, r: float = 1e-20, x: float = 1e-20, g: float = 1e-20, b: float = 1e-20, rate: float = 1.0, tap_module: float = 1.0, tap_module_max: float = 1.2, tap_module_min: float = 0.5, tap_phase: float = 0.0, tap_phase_max: float = 6.28, tap_phase_min: float = -6.28, active: bool = True, tolerance: float = 0.0, cost: float = 100.0, mttf: float = 0.0, mttr: float = 0.0, vset: float = 1.0, Pset: float = 0.0, Qset: float = 0.0, temp_base: float = 20.0, temp_oper: float = 20.0, alpha: float = 0.0033, tap_module_control_mode: TapModuleControl = ..., tap_phase_control_mode: TapPhaseControl = ..., contingency_factor: float = 1.0, protection_rating_factor: float = 1.4, monitor_loading: bool = True, r0: float = 1e-20, x0: float = 1e-20, g0: float = 1e-20, b0: float = 1e-20, r2: float = 1e-20, x2: float = 1e-20, g2: float = 1e-20, b2: float = 1e-20, conn: WindingsConnection = ..., capex: float = 0.0, opex: float = 0.0, build_status: BuildStatus = ...) -> None:
        """
        Constructor for Winding.
        
        :param nt: Number of simulation timesteps.
        :param bus_from/bus_to: AC buses at each side of the winding.
        :param name, idtag, code: Readable name and identifiers.
        :param HV/LV: Rated voltages of the high- and low-voltage sides (kV).
        :param nominal_power: Rated apparent power **S<sub>n</sub>** (MVA).
        :param copper_losses / iron_losses: Losses at rated load and no-load (kW).
        :param no_load_current: Exciting current at no load ( %  of rated).
        :param short_circuit_voltage: Short-circuit voltage **V<sub>sc</sub>** ( % ).
        :param r/x/g/b: Positive-sequence impedance/admittance components (pu).
        :param rate: Continuous thermal rating **I<sub>max</sub>** (pu).
        :param tap_module & limits / tap_phase & limits: Initial tap settings and bounds.
        :param active: Whether the winding is energised in the base case.
        :param tolerance: Power-flow convergence tolerance (pu).
        :param cost, mttf, mttr: Economic and reliability parameters.
        :param vset, Pset, Qset: Voltage and power set-points.
        :param temp_base/temp_oper: Reference and operating temperatures (°C).
        :param alpha: Temperature coefficient of resistance (1/°C).
        :param tap_module_control_mode / tap_phase_control_mode: Tap-changer control strategies.
        :param contingency_factor / protection_rating_factor: Rating multipliers.
        :param monitor_loading: Enable automatic loading alarms.
        :param r0/x0/g0/b0 & r2/x2/g2/b2: Zero- and negative-sequence parameters (pu).
        :param conn: Winding connection enumeration.
        :param capex/opex: Capital and annual operating expenditure.
        :param build_status: Construction / service status enumeration.
        """
class WindingsConnection:
    """
    Members:
    
      GG
    
      GS
    
      GD
    
      SS
    
      SD
    
      DD
    """
    DD: typing.ClassVar[WindingsConnection]  # value = <WindingsConnection.DD: 5>
    GD: typing.ClassVar[WindingsConnection]  # value = <WindingsConnection.GD: 2>
    GG: typing.ClassVar[WindingsConnection]  # value = <WindingsConnection.GG: 0>
    GS: typing.ClassVar[WindingsConnection]  # value = <WindingsConnection.GS: 1>
    SD: typing.ClassVar[WindingsConnection]  # value = <WindingsConnection.SD: 4>
    SS: typing.ClassVar[WindingsConnection]  # value = <WindingsConnection.SS: 3>
    __members__: typing.ClassVar[dict[str, WindingsConnection]]  # value = {'GG': <WindingsConnection.GG: 0>, 'GS': <WindingsConnection.GS: 1>, 'GD': <WindingsConnection.GD: 2>, 'SS': <WindingsConnection.SS: 3>, 'SD': <WindingsConnection.SD: 4>, 'DD': <WindingsConnection.DD: 5>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Wire(EditableDevice):
    def __init__(self, name: str = '', idtag: str = '', gmr: float = 0.01, r: float = 0.01, x: float = 0.0, max_current: float = 1.0, stranding: str = '', material: str = '', diameter: float = 0.0, code: str = '') -> None:
        """
        Constructor for Wire.
        
        :param name: Readable wire name.
        :param idtag: Stable unique identifier tag.
        :param gmr: Geometric-mean radius **GMR** (m).
        :param r: AC resistance **R** (Ω/km) at operating temperature.
        :param x: Inductive reactance **X** (Ω/km).
        :param max_current: Continuous current rating **I<sub>max</sub>** (kA).
        :param stranding: Stranding description (e.g. "54/7" or "AAC").
        :param material: Conductor material (e.g. *Aluminium*, *Copper*).
        :param diameter: Overall outside diameter (mm).
        :param code: Utility or manufacturer code for this wire.
        """
    @property
    def GMR(self) -> float:
        """
        Geometric-mean radius **GMR** (m).
        """
    @GMR.setter
    def GMR(self, arg1: float) -> None:
        ...
    @property
    def R(self) -> float:
        """
        AC resistance **R** (Ω/km).
        """
    @R.setter
    def R(self, arg1: float) -> None:
        ...
    @property
    def X(self) -> float:
        """
        Inductive reactance **X** (Ω/km).
        """
    @X.setter
    def X(self, arg1: float) -> None:
        ...
    @property
    def diameter(self) -> float:
        """
        Outside diameter (mm).
        """
    @diameter.setter
    def diameter(self, arg1: float) -> None:
        ...
    @property
    def material(self) -> str:
        """
        Conductor material.
        """
    @material.setter
    def material(self, arg1: str) -> None:
        ...
    @property
    def max_current(self) -> float:
        """
        Maximum continuous current **I<sub>max</sub>** (kA).
        """
    @max_current.setter
    def max_current(self, arg1: float) -> None:
        ...
    @property
    def stranding(self) -> str:
        """
        Stranding configuration (e.g. "54/7").
        """
    @stranding.setter
    def stranding(self, arg1: str) -> None:
        ...
class WireInTower:
    def __init__(self, name: str = '', xpos: float = 0.0, ypos: float = 0.0, phase: int = 1) -> None:
        """
        Constructor for WireInTower.
        
        :param name: Name of the wire
        :param xpos: x position in meters
        :param ypos: y position in meters
        :param phase: Phase (0 -> Neutral, 1 -> A, 2 -> B, 3 -> C)
        """
    @property
    def device_type(self) -> int:
        """
        Device type (assumed to be WireDevice).
        """
    @device_type.setter
    def device_type(self, arg0: int) -> None:
        ...
    @property
    def name(self) -> str:
        """
        Name of the wire.
        """
    @name.setter
    def name(self, arg0: str) -> None:
        ...
    @property
    def phase(self) -> int:
        """
        Phase (0 -> Neutral, 1 -> A, 2 -> B, 3 -> C).
        """
    @phase.setter
    def phase(self, arg0: int) -> None:
        ...
    @property
    def wire(self) -> Wire:
        """
        The Wire instance.
        """
    @wire.setter
    def wire(self, arg0: Wire) -> None:
        ...
    @property
    def xpos(self) -> float:
        """
        x position in meters.
        """
    @xpos.setter
    def xpos(self, arg0: float) -> None:
        ...
    @property
    def ypos(self) -> float:
        """
        y position in meters.
        """
    @ypos.setter
    def ypos(self, arg0: float) -> None:
        ...
class ZonalGrouping:
    """
    Members:
    
      NoGrouping
    
      Area
    
      All
    """
    All: typing.ClassVar[ZonalGrouping]  # value = <ZonalGrouping.All: 2>
    Area: typing.ClassVar[ZonalGrouping]  # value = <ZonalGrouping.Area: 1>
    NoGrouping: typing.ClassVar[ZonalGrouping]  # value = <ZonalGrouping.NoGrouping: 0>
    __members__: typing.ClassVar[dict[str, ZonalGrouping]]  # value = {'NoGrouping': <ZonalGrouping.NoGrouping: 0>, 'Area': <ZonalGrouping.Area: 1>, 'All': <ZonalGrouping.All: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Zone(GenericAreaGroup):
    def __init__(self, name: str = '', idtag: str = '', code: str = '') -> None:
        """
        Constructor for Zone.
        
        :param name: Name of the zone
        :param idtag: ID tag for the zone
        :param code: Code for the zone
        """
def acos(arg0: Expr) -> Expr:
    ...
def activate(f_name: str, verbose: bool = False) -> bool:
    ...
def asin(arg0: Expr) -> Expr:
    ...
def atan(arg0: Expr) -> Expr:
    ...
def checkLicense(arg0: ..., arg1: bool) -> LicenseResponse:
    """
    Checks the status of a license
    """
def compile(grid: MultiCircuit, logger: Logger = ..., t_idx: int = 0, use_stored_guess: bool = False, control_remote_voltage: bool = True, apply_temperature: bool = False, branch_tolerance_mode: BranchImpedanceMode = ..., control_taps_modules: bool = True, control_taps_phase: bool = True) -> NumericalCircuit:
    """
    Compiles a NumericalCircuit from a MultiCircuit instance.
    """
def cos(arg0: Expr) -> Expr:
    ...
def cosh(arg0: Expr) -> Expr:
    ...
def exp(arg0: Expr) -> Expr:
    ...
def get_version() -> str:
    ...
def isLicensed() -> bool:
    ...
def log(arg0: Expr) -> Expr:
    ...
def make_const(value: float) -> Expr:
    ...
def make_var(name: str) -> Expr:
    ...
def multi_island_pf(grid: MultiCircuit, options: PowerFlowOptions = ..., n_threads: int = 0, time_indices: list[int] | None = None, logger: Logger | None = None, bus_dict: dict[Bus, int] | None = None, area_dict: dict[Area, int] | None = None, clustering_results: ClusteringResults | None = None, force_generalized: bool = False) -> PowerFlowResults:
    """
    Run a *parallel* power-flow on every electrically isolated island in *grid*.
    
    The network is first decomposed into disjoint islands.  Each island is then
    solved independently—optionally in multiple threads—and the individual results
    are merged into a single :class:`PowerFlowResults` container (one time slice per
    entry in *time_indices*).  This is useful for large grids with weakly coupled
    sub-systems or when contingency analysis breaks the network apart.
    
    Parameters
    ----------
    grid :
        A fully populated :class:`MultiCircuit` (or derived) object to solve.
    options : :class:`PowerFlowOptions`, optional
        Solver and control settings.  Defaults to
        :pycode:`PowerFlowOptions()` (Newton–Raphson, 1e-6 tolerance, etc.).
    n_threads : int, optional
        Number of threads for parallel islands.  *0* ⇒ auto-detect CPU cores.
    time_indices : Iterable[int] or None, optional
        Sub-set of time steps to solve.  *None* ⇒ all steps in *grid.time_array*.
    logger : Logger or None, optional
        Custom logger instance for progress / convergence messages.
    bus_dict, area_dict : dict or None, optional
        Optional lookup tables mapping original bus/area IDs to reduced IDs when
        pre-aggregation or clustering has been applied.
    clustering_results : ClusteringResults or None, optional
        Results object from prior network reduction; passed through to the
        :class:`PowerFlowResults` constructor so reduced indices align.
    force_generalized : bool, optional
        If *true*, always use the generalized (matrix-based) NR formulation, even
        when a faster specialized solver is available.
    
    Returns
    -------
    list[PowerFlowResults]
        One results object per island, in the order the islands were discovered.
    
    Notes
    -----
    *   When *n_threads* > 1, islands are dispatched to a thread-pool; thread
        safety is guaranteed because each island has its own local data.
    *   Call :pycode:`results[i].converged_values` to check convergence status for
        island *i* and each simulated time step.
    """
def pow(arg0: Expr, arg1: Expr) -> Expr:
    ...
def read_file(file_name: str, logger: Logger = ..., verbose: int = 0) -> MultiCircuit | None:
    """
    Reads a file and returns a MultiCircuit object
    """
def run_contingencies(grid: MultiCircuit, options: ContingencyAnalysisOptions, n_threads: int = 0, time_indices: list[int] | None = None, logger: Logger | None = None, clustering_results: ClusteringResults | None = None) -> ContingencyAnalysisResults:
    """
    Evaluate the declared contingency groups in parallel
    
    Each element in ``grid.contingency_groups`` (or an equivalent attribute) is applied
    and solved with the given *options*, and the outcome is stored in a :class:`PowerFlowResults`
    object.  Optionally, multiple contingencies are processed in parallel.
    
    Parameters
    ----------
    grid :
        The fully populated :class:`MultiCircuit` (or subclass) that defines the
        base case **and** embeds the list of contingencies to test.
    options : ContingencyAnalysisOptions
        Solver and control settings to use for every contingency run.
    n_threads : int, optional
        Number of parallel worker threads.  *0* ⇒ auto-detect number of CPU cores.
    time_indices : Iterable[int] or None, optional
        Sub-set of time steps to simulate for each contingency.  *None* ⇒ all steps
        in ``grid.time_array``.
    logger : Logger or None, optional
        Custom logger instance for progress messages.  If *None*, a default
        silent logger is used.
    clustering_results : ClusteringResults or None, optional
        Reduction / clustering metadata to attach to every
        :class:`PowerFlowResults` instance so bus or area indices remain aligned.
    
    Returns
    -------
    ContingencyAnalysisResults object with the contingency analysis results.
    """
def search_license_and_activate(f_name: str = '', verbose: bool = False) -> ...:
    ...
def sin(arg0: Expr) -> Expr:
    ...
def sinh(arg0: Expr) -> Expr:
    ...
def sqrt(arg0: Expr) -> Expr:
    ...
def sym_diff(expr: Expr, var: Expr, order: int = 1) -> Expr:
    ...
def sym_eval(expr: Expr, bindings: dict[Expr, float]) -> float:
    ...
def tan(arg0: Expr) -> Expr:
    ...
EQ: LpConstraintType  # value = <LpConstraintType.EQ: 2>
GEQ: LpConstraintType  # value = <LpConstraintType.GEQ: 1>
LEQ: LpConstraintType  # value = <LpConstraintType.LEQ: 0>
MAXIMIZE: LpSense  # value = <LpSense.MAXIMIZE: 1>
MINIMIZE: LpSense  # value = <LpSense.MINIMIZE: 0>
