# backup-my-agent

CLI tool to backup agent configuration files to a git repository.

## Installation

```bash
uv sync
```

## Usage

```bash
# Create a backup plan interactively
backup-my-agent discover claude

# List saved plans
backup-my-agent plans

# Preview what would be backed up
backup-my-agent status claude

# Run backup (clones repo, copies files, commits, pushes)
backup-my-agent backup claude

# Restore files from backup to original locations
backup-my-agent restore claude
```

## How it works

1. Run `discover` to scan your agent config directory and create a backup plan
2. The plan specifies which files to include/exclude and the destination git repo (SSH URL)
3. Run `backup` to clone the repo, copy your config files, commit, and push
4. Run `restore` to pull files from the backup repo back to their original locations

Plans are stored in `~/.backup-my-agent/plans/`.

File copying uses rsync when available, which skips unchanged files based on checksum comparison. Falls back to regular file copying otherwise.

## Commands

| Command | Description |
|---------|-------------|
| `discover <agent>` | Create a backup plan interactively |
| `plans` | List saved plans |
| `status [plan]` | Preview files that would be backed up |
| `backup [plan]` | Run backup to git repo |
| `restore [plan]` | Restore files from backup |
| `delete <plan>` | Delete a saved plan |

## Supported agents

- `claude` - Backs up `~/.claude/` (CLAUDE.md, settings, skills, etc.)

## Development

```bash
uv sync --extra dev       # install dev dependencies
uv run pytest             # run tests
uv run ruff check .       # lint
uv run ruff format .      # format
```
