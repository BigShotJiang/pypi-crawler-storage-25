"""Shared test fixtures."""

import os
import subprocess
import tempfile
from pathlib import Path

import pytest


@pytest.fixture(scope="session", autouse=True)
def git_env():
    """Isolate tests from user's global git config."""
    os.environ["GIT_CONFIG_GLOBAL"] = "/dev/null"
    os.environ["GIT_CONFIG_SYSTEM"] = "/dev/null"
    os.environ["GIT_AUTHOR_NAME"] = "Test"
    os.environ["GIT_AUTHOR_EMAIL"] = "test@test.com"
    os.environ["GIT_COMMITTER_NAME"] = "Test"
    os.environ["GIT_COMMITTER_EMAIL"] = "test@test.com"


@pytest.fixture
def bare_git_repo(tmp_path):
    """Create a bare git repo for use as backup destination."""
    repo = tmp_path / "dest.git"
    subprocess.run(["git", "init", "--bare", str(repo)], check=True, capture_output=True)
    return repo


@pytest.fixture
def mock_claude_config(tmp_path):
    """Create mock ~/.claude structure with files to backup."""
    claude_dir = tmp_path / ".claude"
    claude_dir.mkdir()
    (claude_dir / "CLAUDE.md").write_text("# Global")
    (claude_dir / "settings.json").write_text("{}")
    (claude_dir / "skills").mkdir()
    (claude_dir / "skills" / "test.md").write_text("# Skill")
    # Sensitive files that should be excluded
    (claude_dir / ".credentials.json").write_text("{}")
    return claude_dir


@pytest.fixture
def mock_project_repo(tmp_path):
    """Create a git repo with tracked/untracked/gitignored Claude configs."""
    project = tmp_path / "project"
    project.mkdir()
    subprocess.run(["git", "init"], cwd=project, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "test@test.com"],
        cwd=project,
        check=True,
        capture_output=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Test"],
        cwd=project,
        check=True,
        capture_output=True,
    )
    # Committed file
    (project / "README.md").write_text("# Project")
    subprocess.run(["git", "add", "."], cwd=project, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "init"],
        cwd=project,
        check=True,
        capture_output=True,
    )
    # Untracked Claude config
    (project / "CLAUDE.md").write_text("# Claude")
    # Gitignored .claude directory
    (project / ".gitignore").write_text(".claude/\n")
    (project / ".claude").mkdir()
    (project / ".claude" / "settings.json").write_text("{}")
    # Files/dirs that should be excluded by get_project_config_files
    (project / ".claude" / "plugins").mkdir()
    (project / ".claude" / "plugins" / "some-plugin.json").write_text("{}")
    (project / ".claude" / ".cache").mkdir()
    (project / ".claude" / ".cache" / "data.bin").write_text("cache")
    (project / ".claude" / ".git").mkdir()
    (project / ".claude" / ".git" / "HEAD").write_text("ref: refs/heads/main")
    (project / ".claude" / "cache").mkdir()
    (project / ".claude" / "cache" / "changelog.md").write_text("log")
    (project / ".claude" / "backups").mkdir()
    (project / ".claude" / "backups" / "backup.json").write_text("{}")
    (project / ".claude" / ".credentials.json").write_text("{}")
    (project / ".claude" / "history.jsonl").write_text("")
    subprocess.run(["git", "add", ".gitignore"], cwd=project, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "gitignore"],
        cwd=project,
        check=True,
        capture_output=True,
    )
    return project


@pytest.fixture
def mock_plans_dir(monkeypatch):
    """Patch PLANS_DIR to use temp directory with auto-cleanup."""
    from backup_my_agent import config

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        plans = tmp_path / "plans"
        plans.mkdir()
        monkeypatch.setattr(config, "CONFIG_DIR", tmp_path)
        monkeypatch.setattr(config, "PLANS_DIR", plans)
        yield plans
