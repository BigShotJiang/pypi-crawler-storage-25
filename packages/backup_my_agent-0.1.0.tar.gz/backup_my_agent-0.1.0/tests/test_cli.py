"""Integration tests for CLI commands."""

import subprocess

from typer.testing import CliRunner

from backup_my_agent.cli import app
from backup_my_agent.config import Plan, Source, save_plan

runner = CliRunner()


def test_status_shows_files(mock_plans_dir, mock_claude_config):
    """Test that status command lists files to backup."""
    source = Source(
        name="global",
        base_path=mock_claude_config,
        include=["*.md"],
        exclude=[],
    )
    plan = Plan(name="test-plan", destination="git@example.com:test.git", sources=[source])
    save_plan(plan)

    result = runner.invoke(app, ["status", "test-plan"])

    assert result.exit_code == 0
    assert "CLAUDE.md" in result.output
    assert "Files to backup" in result.output


def test_plans_lists_saved(mock_plans_dir):
    """Test that plans command shows plan names."""
    plan1 = Plan(name="plan-one", destination="dest1", sources=[])
    plan2 = Plan(name="plan-two", destination="dest2", sources=[])
    save_plan(plan1)
    save_plan(plan2)

    result = runner.invoke(app, ["plans"])

    assert result.exit_code == 0
    assert "plan-one" in result.output
    assert "plan-two" in result.output


def test_backup_full_workflow(mock_plans_dir, mock_claude_config, bare_git_repo, tmp_path):
    """Test full backup workflow: clone, copy, commit (skip push for local)."""
    source = Source(
        name="global",
        base_path=mock_claude_config,
        include=["*.md", "skills/**/*"],
        exclude=[],
    )
    plan = Plan(
        name="claude-backup",
        destination=str(bare_git_repo),
        sources=[source],
    )
    save_plan(plan)

    result = runner.invoke(app, ["backup", "claude-backup"])

    assert result.exit_code == 0
    assert "Backed up" in result.output


def test_backup_preserves_contents(mock_plans_dir, mock_claude_config, bare_git_repo, tmp_path):
    """Test that backup preserves file contents correctly."""
    # Write specific content to test file
    (mock_claude_config / "CLAUDE.md").write_text("# My Custom Config\nLine 2")

    source = Source(
        name="global",
        base_path=mock_claude_config,
        include=["*.md"],
        exclude=[],
    )
    # Plan name starts with "claude-" so agent_name becomes "claude"
    plan = Plan(
        name="claude-test",
        destination=str(bare_git_repo),
        sources=[source],
    )
    save_plan(plan)

    result = runner.invoke(app, ["backup", "claude-test"])
    assert result.exit_code == 0

    # Clone the bare repo to verify contents
    verify_path = tmp_path / "verify"
    subprocess.run(
        ["git", "clone", str(bare_git_repo), str(verify_path)],
        check=True,
        capture_output=True,
    )

    backed_up_file = verify_path / "claude" / "CLAUDE.md"
    assert backed_up_file.exists()
    assert backed_up_file.read_text() == "# My Custom Config\nLine 2"


def test_delete_command(mock_plans_dir):
    """Test delete command removes a plan."""
    plan = Plan(name="to-delete", destination="dest", sources=[])
    save_plan(plan)

    result = runner.invoke(app, ["delete", "to-delete", "--force"])

    assert result.exit_code == 0
    assert "Deleted" in result.output

    # Verify plan is gone
    result = runner.invoke(app, ["plans"])
    assert "to-delete" not in result.output


def test_version_flag():
    """Test --version flag shows version."""
    result = runner.invoke(app, ["--version"])

    assert result.exit_code == 0
    assert "backup-my-agent" in result.output


def test_restore_full_workflow(mock_plans_dir, mock_claude_config, bare_git_repo, tmp_path):
    """Test full restore workflow: backup, then restore to new location."""
    original_content = "# Original Content\nWith some data"
    (mock_claude_config / "CLAUDE.md").write_text(original_content)

    source = Source(
        name="global",
        base_path=mock_claude_config,
        include=["*.md", "skills/**/*"],
        exclude=[],
    )
    plan = Plan(
        name="claude-restore-test",
        destination=str(bare_git_repo),
        sources=[source],
    )
    save_plan(plan)

    result = runner.invoke(app, ["backup", "claude-restore-test"])
    assert result.exit_code == 0
    assert "Backed up" in result.output

    (mock_claude_config / "CLAUDE.md").unlink()
    (mock_claude_config / "skills" / "test.md").unlink()

    assert not (mock_claude_config / "CLAUDE.md").exists()
    assert not (mock_claude_config / "skills" / "test.md").exists()

    result = runner.invoke(app, ["restore", "claude-restore-test", "--force"])

    assert result.exit_code == 0
    assert "Restored" in result.output

    assert (mock_claude_config / "CLAUDE.md").exists()
    assert (mock_claude_config / "CLAUDE.md").read_text() == original_content

    assert (mock_claude_config / "skills" / "test.md").exists()


def test_restore_shows_preview(mock_plans_dir, mock_claude_config, bare_git_repo, tmp_path):
    """Test that restore command shows file preview before restoring."""
    source = Source(
        name="global",
        base_path=mock_claude_config,
        include=["*.md"],
        exclude=[],
    )
    plan = Plan(
        name="claude-preview",
        destination=str(bare_git_repo),
        sources=[source],
    )
    save_plan(plan)

    runner.invoke(app, ["backup", "claude-preview"])

    result = runner.invoke(app, ["restore", "claude-preview"], input="n\n")

    assert result.exit_code == 0
    assert "Files to restore" in result.output
    assert "CLAUDE.md" in result.output
    assert "Cancelled" in result.output
