"""Tests for git.py."""

import subprocess

from backup_my_agent.git import (
    clone_repo,
    commit,
    has_changes,
    is_file_ignored,
    is_file_tracked,
    is_local_path,
    stage_all,
)


def test_is_local_path_absolute():
    """Test that absolute paths are detected as local."""
    assert is_local_path("/home/user/repo.git") is True
    assert is_local_path("/tmp/backup") is True


def test_is_local_path_relative():
    """Test that relative paths starting with . are detected as local."""
    assert is_local_path("./local-repo") is True
    assert is_local_path("../parent-repo") is True


def test_is_local_path_tilde():
    """Test that tilde paths are detected as local."""
    assert is_local_path("~/repos/backup") is True


def test_is_local_path_remote():
    """Test that SSH and HTTPS URLs are not detected as local."""
    assert is_local_path("git@github.com:user/repo.git") is False
    assert is_local_path("https://github.com/user/repo.git") is False


def test_clone_local_bare_repo(bare_git_repo):
    """Test cloning a local bare repo."""
    with clone_repo(str(bare_git_repo)) as repo_path:
        assert repo_path.exists()
        assert (repo_path / ".git").exists()


def test_clone_cleans_up(bare_git_repo):
    """Test that temp directory is deleted after context manager exits."""
    repo_path = None
    with clone_repo(str(bare_git_repo)) as path:
        repo_path = path
        assert path.exists()

    assert not repo_path.exists()


def test_stage_all_stages_new_files(bare_git_repo):
    """Test that stage_all makes has_changes return true for new files."""
    with clone_repo(str(bare_git_repo)) as repo_path:
        assert has_changes(repo_path) is False

        (repo_path / "newfile.txt").write_text("content")
        stage_all(repo_path)

        assert has_changes(repo_path) is True


def test_commit_creates_commit(bare_git_repo, tmp_path):
    """Test that commit returns a 40-character hash."""
    # Configure git user for the bare repo (needed for commit)
    with clone_repo(str(bare_git_repo)) as repo_path:
        subprocess.run(
            ["git", "config", "user.email", "test@test.com"],
            cwd=repo_path,
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.name", "Test"],
            cwd=repo_path,
            check=True,
            capture_output=True,
        )

        (repo_path / "file.txt").write_text("content")
        stage_all(repo_path)

        commit_hash = commit(repo_path, "Test commit")

        assert len(commit_hash) == 40
        assert all(c in "0123456789abcdef" for c in commit_hash)


def test_is_file_tracked(mock_project_repo):
    """Test is_file_tracked returns true for committed files, false for untracked."""
    readme = mock_project_repo / "README.md"
    claude_md = mock_project_repo / "CLAUDE.md"

    assert is_file_tracked(mock_project_repo, readme) is True
    assert is_file_tracked(mock_project_repo, claude_md) is False


def test_is_file_ignored(mock_project_repo):
    """Test is_file_ignored returns true for files in .gitignore."""
    readme = mock_project_repo / "README.md"
    settings = mock_project_repo / ".claude" / "settings.json"

    assert is_file_ignored(mock_project_repo, readme) is False
    assert is_file_ignored(mock_project_repo, settings) is True
