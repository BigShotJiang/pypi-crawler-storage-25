"""Tests for ClaudeAgent."""

import subprocess

from backup_my_agent.agents.claude import ClaudeAgent


def test_encode_decode_project_path():
    """Test roundtrip encode/decode of project path."""
    agent = ClaudeAgent()

    original = "/home/user/workspace/Backend"
    encoded = agent.encode_project_path(original)
    decoded = agent.decode_project_path(encoded)

    assert encoded == "-home-user-workspace-Backend"
    assert decoded == original


def test_encode_project_path_with_tilde(tmp_path, monkeypatch):
    """Test encoding a path with ~ expands to full path."""
    agent = ClaudeAgent()

    # Patch home to a known value
    monkeypatch.setenv("HOME", str(tmp_path))

    encoded = agent.encode_project_path("~/workspace/project")

    assert encoded.startswith("-")
    assert "workspace" in encoded
    assert "project" in encoded


def test_get_projects(tmp_path):
    """Test get_projects finds projects from projects/ subdirectory."""
    agent = ClaudeAgent()

    projects_dir = tmp_path / "projects"
    projects_dir.mkdir()
    (projects_dir / "-home-user-project1").mkdir()
    (projects_dir / "-home-user-project2").mkdir()
    # Non-directory should be ignored
    (projects_dir / "somefile.txt").write_text("")

    projects = agent.get_projects(tmp_path)

    assert len(projects) == 2
    names = {p.name for p in projects}
    assert names == {"project1", "project2"}


def test_get_project_config_files(mock_project_repo):
    """Test get_project_config_files finds CLAUDE.md and .claude/*."""
    from backup_my_agent.agents.base import ProjectInfo

    agent = ClaudeAgent()

    project = ProjectInfo(
        name="project",
        encoded_name="-home-user-project",
        original_path=str(mock_project_repo),
        config_path=mock_project_repo,
    )

    config_files = agent.get_project_config_files(project)

    assert len(config_files) == 2
    paths = {cf.relative_path for cf in config_files}
    assert paths == {"CLAUDE.md", ".claude/settings.json"}


def test_get_project_config_files_skips_excluded(mock_project_repo):
    """Test that cache dirs, sensitive files, and other excludes are filtered."""
    from backup_my_agent.agents.base import ProjectInfo

    agent = ClaudeAgent()

    project = ProjectInfo(
        name="project",
        encoded_name="-home-user-project",
        original_path=str(mock_project_repo),
        config_path=mock_project_repo,
    )

    config_files = agent.get_project_config_files(project)
    paths = {cf.relative_path for cf in config_files}

    # Cache directories
    assert ".claude/plugins/some-plugin.json" not in paths
    assert ".claude/.cache/data.bin" not in paths
    assert ".claude/.git/HEAD" not in paths
    assert ".claude/cache/changelog.md" not in paths
    assert ".claude/backups/backup.json" not in paths
    # Sensitive patterns
    assert ".claude/.credentials.json" not in paths
    assert ".claude/history.jsonl" not in paths
    # Valid config should still be included
    assert ".claude/settings.json" in paths


def test_detects_gitignored_status(mock_project_repo):
    """Test that config files correctly report is_ignored status."""
    from backup_my_agent.agents.base import ProjectInfo

    agent = ClaudeAgent()

    project = ProjectInfo(
        name="project",
        encoded_name="-home-user-project",
        original_path=str(mock_project_repo),
        config_path=mock_project_repo,
    )

    config_files = agent.get_project_config_files(project)

    by_path = {cf.relative_path: cf for cf in config_files}

    # CLAUDE.md is not gitignored
    assert by_path["CLAUDE.md"].is_ignored is False
    # .claude/settings.json is gitignored
    assert by_path[".claude/settings.json"].is_ignored is True


def test_detects_tracked_status(mock_project_repo):
    """Test that config files correctly report is_tracked status."""
    from backup_my_agent.agents.base import ProjectInfo

    agent = ClaudeAgent()

    # Track CLAUDE.md by committing it
    subprocess.run(
        ["git", "add", "CLAUDE.md"],
        cwd=mock_project_repo,
        check=True,
        capture_output=True,
    )
    subprocess.run(
        ["git", "commit", "-m", "add claude.md"],
        cwd=mock_project_repo,
        check=True,
        capture_output=True,
    )

    project = ProjectInfo(
        name="project",
        encoded_name="-home-user-project",
        original_path=str(mock_project_repo),
        config_path=mock_project_repo,
    )

    config_files = agent.get_project_config_files(project)

    by_path = {cf.relative_path: cf for cf in config_files}

    # CLAUDE.md is now tracked
    assert by_path["CLAUDE.md"].is_tracked is True
    # .claude/settings.json is not tracked (ignored)
    assert by_path[".claude/settings.json"].is_tracked is False
