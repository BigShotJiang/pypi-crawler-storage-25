"""Tests for backup.py."""

from backup_my_agent.backup import (
    collect_files,
    create_file_mappings,
    run_backup,
    run_restore,
)
from backup_my_agent.config import Plan, Source


def test_collect_md_files(tmp_path):
    """Test basic glob matching for .md files."""
    source_dir = tmp_path / "source"
    source_dir.mkdir()
    (source_dir / "README.md").write_text("# Readme")
    (source_dir / "CLAUDE.md").write_text("# Claude")
    (source_dir / "other.txt").write_text("text")

    source = Source(
        name="test",
        base_path=source_dir,
        include=["*.md"],
        exclude=[],
    )

    files = collect_files(source)

    assert len(files) == 2
    names = {f.name for f in files}
    assert names == {"README.md", "CLAUDE.md"}


def test_collect_recursive_glob(tmp_path):
    """Test skills/**/* pattern for recursive matching."""
    source_dir = tmp_path / "source"
    source_dir.mkdir()
    skills = source_dir / "skills"
    skills.mkdir()
    (skills / "skill1.md").write_text("# Skill 1")
    nested = skills / "nested"
    nested.mkdir()
    (nested / "skill2.md").write_text("# Skill 2")

    source = Source(
        name="test",
        base_path=source_dir,
        include=["skills/**/*"],
        exclude=[],
    )

    files = collect_files(source)

    assert len(files) == 2
    names = {f.name for f in files}
    assert names == {"skill1.md", "skill2.md"}


def test_exclude_patterns(tmp_path):
    """Test that cache/** is excluded."""
    source_dir = tmp_path / "source"
    source_dir.mkdir()
    (source_dir / "CLAUDE.md").write_text("# Claude")
    cache = source_dir / "cache"
    cache.mkdir()
    (cache / "data.json").write_text("{}")

    source = Source(
        name="test",
        base_path=source_dir,
        include=["*.md", "**/*.json"],
        exclude=["cache/**"],
    )

    files = collect_files(source)

    assert len(files) == 1
    assert files[0].name == "CLAUDE.md"


def test_exclude_sensitive_files(mock_claude_config):
    """Test that sensitive files like .credentials.json can be excluded."""
    source = Source(
        name="global",
        base_path=mock_claude_config,
        include=["*.md", "*.json"],
        exclude=[".credentials.json"],
    )

    files = collect_files(source)

    names = {f.name for f in files}
    assert "CLAUDE.md" in names
    assert "settings.json" in names
    assert ".credentials.json" not in names


def test_mappings_include_agent_name(tmp_path):
    """Test that file mappings include agent name prefix (e.g., claude/CLAUDE.md)."""
    source_dir = tmp_path / "source"
    source_dir.mkdir()
    (source_dir / "CLAUDE.md").write_text("# Claude")

    source = Source(
        name="global",
        base_path=source_dir,
        include=["*.md"],
        exclude=[],
    )
    plan = Plan(name="test", destination="dest", sources=[source])

    mappings = create_file_mappings(plan, "claude")

    assert len(mappings) == 1
    assert mappings[0].relative_path == "claude/CLAUDE.md"


def test_project_sources_nested(tmp_path):
    """Test that project sources are nested under agent/project-name/."""
    source_dir = tmp_path / "source"
    source_dir.mkdir()
    (source_dir / "CLAUDE.md").write_text("# Claude")

    source = Source(
        name="project-myapp",
        base_path=source_dir,
        include=["*.md"],
        exclude=[],
    )
    plan = Plan(name="test", destination="dest", sources=[source])

    mappings = create_file_mappings(plan, "claude")

    assert len(mappings) == 1
    assert mappings[0].relative_path == "claude/project-myapp/CLAUDE.md"


def test_run_backup_copies_all_files(tmp_path, mock_claude_config):
    """Test end-to-end backup copies files to destination."""
    dest = tmp_path / "dest"
    dest.mkdir()

    source = Source(
        name="global",
        base_path=mock_claude_config,
        include=["*.md", "skills/**/*"],
        exclude=[],
    )
    plan = Plan(name="test", destination=str(dest), sources=[source])

    mappings = run_backup(plan, dest, "claude")

    assert len(mappings) == 2

    claude_md = dest / "claude" / "CLAUDE.md"
    assert claude_md.exists()
    assert claude_md.read_text() == "# Global"

    skill_md = dest / "claude" / "skills" / "test.md"
    assert skill_md.exists()
    assert skill_md.read_text() == "# Skill"


def test_run_restore_copies_files_back(tmp_path):
    """Test that run_restore copies files to original locations."""
    restore_dest = tmp_path / "restored"
    restore_dest.mkdir()

    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / "claude").mkdir()
    (repo / "claude" / "CLAUDE.md").write_text("# Restored Global")
    (repo / "claude" / "skills").mkdir()
    (repo / "claude" / "skills" / "test.md").write_text("# Restored Skill")

    source = Source(
        name="global",
        base_path=restore_dest,
        include=["*.md", "skills/**/*"],
        exclude=[],
    )
    plan = Plan(name="test", destination=str(repo), sources=[source])

    mappings = run_restore(plan, repo, "claude")

    assert len(mappings) == 2

    restored_md = restore_dest / "CLAUDE.md"
    assert restored_md.exists()
    assert restored_md.read_text() == "# Restored Global"

    restored_skill = restore_dest / "skills" / "test.md"
    assert restored_skill.exists()
    assert restored_skill.read_text() == "# Restored Skill"


def test_run_restore_with_named_source(tmp_path):
    """Test that run_restore handles named sources correctly."""
    restore_dest = tmp_path / "project"
    restore_dest.mkdir()

    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / "claude").mkdir()
    (repo / "claude" / "project-myapp").mkdir()
    (repo / "claude" / "project-myapp" / "CLAUDE.md").write_text("# Project Config")

    source = Source(
        name="project-myapp",
        base_path=restore_dest,
        include=["*.md"],
        exclude=[],
    )
    plan = Plan(name="test", destination=str(repo), sources=[source])

    mappings = run_restore(plan, repo, "claude")

    assert len(mappings) == 1
    restored_md = restore_dest / "CLAUDE.md"
    assert restored_md.exists()
    assert restored_md.read_text() == "# Project Config"


def test_run_restore_no_agent_dir(tmp_path):
    """Test that run_restore returns empty list when agent dir doesn't exist."""
    repo = tmp_path / "repo"
    repo.mkdir()

    source = Source(
        name="global",
        base_path=tmp_path / "dest",
        include=["*.md"],
        exclude=[],
    )
    plan = Plan(name="test", destination=str(repo), sources=[source])

    mappings = run_restore(plan, repo, "nonexistent")

    assert mappings == []
