"""Tests for config.py."""

from pathlib import Path

import pytest

from backup_my_agent.config import (
    Plan,
    Source,
    delete_plan,
    list_plans,
    load_plan,
    save_plan,
)


def test_save_and_load_plan(mock_plans_dir):
    """Test roundtrip save and load of a plan."""
    source = Source(
        name="global",
        base_path=Path("/home/user/.claude"),
        include=["*.md", "*.json"],
        exclude=["cache/**"],
    )
    plan = Plan(
        name="test-plan",
        destination="git@github.com:user/backup.git",
        sources=[source],
    )

    save_plan(plan)
    loaded = load_plan("test-plan")

    assert loaded.name == plan.name
    assert loaded.destination == plan.destination
    assert len(loaded.sources) == 1
    assert loaded.sources[0].name == "global"
    assert loaded.sources[0].include == ["*.md", "*.json"]
    assert loaded.sources[0].exclude == ["cache/**"]


def test_list_plans(mock_plans_dir):
    """Test listing saved plans."""
    plan1 = Plan(name="plan-a", destination="dest1", sources=[])
    plan2 = Plan(name="plan-b", destination="dest2", sources=[])

    save_plan(plan1)
    save_plan(plan2)

    names = list_plans()
    assert set(names) == {"plan-a", "plan-b"}


def test_delete_plan(mock_plans_dir):
    """Test deleting a plan."""
    plan = Plan(name="to-delete", destination="dest", sources=[])
    save_plan(plan)

    assert "to-delete" in list_plans()

    delete_plan("to-delete")

    assert "to-delete" not in list_plans()


def test_load_nonexistent_raises(mock_plans_dir):
    """Test that loading a nonexistent plan raises FileNotFoundError."""
    with pytest.raises(FileNotFoundError):
        load_plan("does-not-exist")
