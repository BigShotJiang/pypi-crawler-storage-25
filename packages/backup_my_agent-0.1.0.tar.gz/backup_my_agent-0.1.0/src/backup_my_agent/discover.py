"""Interactive discovery and plan creation."""

from pathlib import Path

from rich.console import Console
from rich.prompt import Confirm, Prompt
from rich.table import Table

from backup_my_agent.agents import get_agent
from backup_my_agent.agents.base import Agent, ProjectInfo
from backup_my_agent.config import Plan, Source, save_plan

console = Console()


def discover_agent(agent_name: str, path: Path | None = None) -> Plan | None:
    """Run interactive discovery for an agent.

    Args:
        agent_name: Name of the agent (e.g., 'claude')
        path: Optional path to search. Defaults to agent's default base path.

    Returns:
        The created plan, or None if cancelled
    """
    agent = get_agent(agent_name)
    base_path = path if path else agent.defaults.base_path

    console.print(f"\n[bold]Discovering {agent_name} configuration...[/bold]")
    console.print(f"[dim]Scanning: {base_path}[/dim]\n")

    if not base_path.exists():
        console.print(f"[red]Error:[/red] Path not found: {base_path}")
        return None

    _show_summary(agent, base_path)

    include_patterns = _select_includes(agent)
    exclude_patterns = _build_excludes(agent)
    selected_projects = _select_projects(agent, base_path)

    plan_name = Prompt.ask("\nPlan name", default=agent_name)

    while True:
        destination = Prompt.ask(
            "Destination (SSH URL)",
            default=f"git@github.com:user/{plan_name}-backup.git",
        )
        if destination.startswith("git@"):
            break
        console.print("[yellow]Invalid:[/yellow] Only SSH URLs supported (must start with git@)")

    sources = _build_sources(base_path, include_patterns, exclude_patterns, selected_projects)
    plan = Plan(name=plan_name, destination=destination, sources=sources)

    console.print("\n[bold]Plan summary:[/bold]")
    _show_plan_summary(plan)

    if not Confirm.ask("\nSave plan?", default=True):
        console.print("[yellow]Cancelled[/yellow]")
        return None

    plan_path = save_plan(plan)
    console.print(f"\n[green]Plan saved to:[/green] {plan_path}")

    return plan


def _show_summary(agent: Agent, base_path: Path) -> None:
    """Show summary of what was found."""
    md_files = list(base_path.glob("*.md"))
    json_files = [f for f in base_path.glob("*.json") if not f.name.startswith(".")]
    skill_dirs = list((base_path / "skills").glob("*")) if (base_path / "skills").exists() else []
    projects = agent.get_projects(base_path)

    table = Table(title="Detected Configuration")
    table.add_column("Type", style="cyan")
    table.add_column("Count", justify="right")
    table.add_column("Examples")

    if md_files:
        examples = ", ".join(f.name for f in md_files[:3])
        table.add_row("Markdown files", str(len(md_files)), examples)

    if json_files:
        examples = ", ".join(f.name for f in json_files[:3])
        table.add_row("JSON files", str(len(json_files)), examples)

    if skill_dirs:
        examples = ", ".join(d.name for d in skill_dirs[:3])
        table.add_row("Skills", str(len(skill_dirs)), examples)

    if projects:
        table.add_row("Projects", str(len(projects)), "")

    console.print(table)


def _select_includes(agent: Agent) -> list[str]:
    """Let user select which patterns to include."""
    console.print("\n[bold]Select patterns to include:[/bold]")

    defaults = agent.defaults
    patterns = defaults.include_patterns

    selected = []
    for pattern in patterns:
        if Confirm.ask(f"  Include [cyan]{pattern}[/cyan]?", default=True):
            selected.append(pattern)

    return selected


def _build_excludes(agent: Agent) -> list[str]:
    """Build exclude patterns from agent defaults."""
    defaults = agent.defaults
    excludes = []
    excludes.extend(defaults.sensitive_patterns)
    excludes.extend(defaults.cache_patterns)
    excludes.extend(defaults.exclude_patterns)
    return excludes


def _select_projects(agent: Agent, base_path: Path) -> list[ProjectInfo]:
    """Let user select which projects to include.

    Only shows projects that have uncommitted (untracked or gitignored) config files.
    """
    projects = agent.get_projects(base_path)
    if not projects:
        return []

    projects_with_configs = []
    for project in projects:
        config_files = agent.get_project_config_files(project)
        uncommitted = [f for f in config_files if not f.is_tracked]
        if uncommitted:
            project.config_files = uncommitted
            projects_with_configs.append(project)

    if not projects_with_configs:
        console.print("\n[dim]No projects with uncommitted config files found.[/dim]")
        return []

    console.print("\n[bold]Projects with uncommitted configs:[/bold]")

    selected = []
    for project in projects_with_configs:
        console.print(f"\n  [cyan]{project.name}[/cyan] ({project.original_path})")
        for cf in project.config_files:
            status = "[yellow]gitignored[/yellow]" if cf.is_ignored else "[dim]untracked[/dim]"
            console.print(f"    - {cf.relative_path} ({status})")

        if Confirm.ask("  Include this project?", default=False):
            selected.append(project)

    return selected


def _build_sources(
    base_path: Path,
    include_patterns: list[str],
    exclude_patterns: list[str],
    projects: list[ProjectInfo],
) -> list[Source]:
    """Build source list from selections."""
    sources = []

    sources.append(
        Source(
            name="global",
            base_path=base_path,
            include=include_patterns,
            exclude=exclude_patterns,
        )
    )

    for project in projects:
        if not project.config_files:
            continue

        include_files = [cf.relative_path for cf in project.config_files]
        sources.append(
            Source(
                name=f"project-{project.name}",
                base_path=Path(project.original_path),
                include=include_files,
                exclude=[],
            )
        )

    return sources


def _show_plan_summary(plan: Plan) -> None:
    """Show a summary of the plan."""
    console.print(f"  Name: [cyan]{plan.name}[/cyan]")
    console.print(f"  Destination: [cyan]{plan.destination}[/cyan]")
    console.print(f"  Sources: [cyan]{len(plan.sources)}[/cyan]")

    for source in plan.sources:
        console.print(f"    - {source.name}: {len(source.include)} patterns")
