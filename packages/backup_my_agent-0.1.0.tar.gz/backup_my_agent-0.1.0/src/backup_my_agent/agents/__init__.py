"""Agent definitions for backup-my-agent."""

from backup_my_agent.agents.base import Agent
from backup_my_agent.agents.claude import ClaudeAgent

AGENTS: dict[str, type[Agent]] = {
    "claude": ClaudeAgent,
}


def get_agent(name: str) -> Agent:
    """Get an agent instance by name."""
    if name not in AGENTS:
        raise ValueError(f"Unknown agent: {name}. Available: {list(AGENTS.keys())}")
    return AGENTS[name]()
