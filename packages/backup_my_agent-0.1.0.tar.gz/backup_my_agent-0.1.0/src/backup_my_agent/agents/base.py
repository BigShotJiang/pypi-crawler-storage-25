"""Base agent interface."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path


@dataclass
class AgentDefaults:
    """Default configuration for an agent."""

    base_path: Path
    include_patterns: list[str]
    exclude_patterns: list[str]
    sensitive_patterns: list[str]
    cache_patterns: list[str]


@dataclass
class ProjectConfigFile:
    """A config file found in a project repository."""

    path: Path
    relative_path: str
    is_tracked: bool
    is_ignored: bool


@dataclass
class ProjectInfo:
    """Information about a project."""

    name: str
    encoded_name: str
    original_path: str
    config_path: Path
    config_files: list[ProjectConfigFile] | None = None


class Agent(ABC):
    """Base class for agent configuration handlers."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Agent name (e.g., 'claude')."""
        ...

    @property
    @abstractmethod
    def defaults(self) -> AgentDefaults:
        """Default configuration for this agent."""
        ...

    @abstractmethod
    def get_projects(self, base_path: Path | None = None) -> list[ProjectInfo]:
        """Get list of available projects for this agent."""
        ...

    @abstractmethod
    def encode_project_path(self, path: str) -> str:
        """Convert a project path to its encoded form."""
        ...

    @abstractmethod
    def decode_project_path(self, encoded: str) -> str:
        """Convert an encoded project name back to original path."""
        ...

    @abstractmethod
    def get_project_config_files(self, project: "ProjectInfo") -> list[ProjectConfigFile]:
        """Get config files from the actual project repository.

        Scans the project's original repository path for agent config files
        and determines their git status (tracked/ignored).

        Args:
            project: The project info

        Returns:
            List of config files found with their git status
        """
        ...

    def is_encoded_path(self, value: str) -> bool:
        """Check if a value is an encoded project path."""
        return value.startswith("-")
