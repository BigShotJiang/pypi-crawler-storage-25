"""Claude agent configuration handler."""

from pathlib import Path

from backup_my_agent.agents.base import (
    Agent,
    AgentDefaults,
    ProjectConfigFile,
    ProjectInfo,
)
from backup_my_agent.backup import _matches_pattern
from backup_my_agent.git import (
    get_repo_root,
    is_file_ignored,
    is_file_tracked,
    is_git_repo,
)


class ClaudeAgent(Agent):
    """Handler for Claude configuration files."""

    @property
    def name(self) -> str:
        return "claude"

    @property
    def defaults(self) -> AgentDefaults:
        return AgentDefaults(
            base_path=Path.home() / ".claude",
            include_patterns=[
                "*.md",
                "*.json",
                "skills/**/*",
            ],
            exclude_patterns=[
                "projects/**",
            ],
            sensitive_patterns=[
                ".credentials.json",
                "*.jsonl",
                "stats-cache.json",
                "sessions-index.json",
            ],
            cache_patterns=[
                "**/.git/**",
                ".cache/**",
                "backups/**",
                "cache/**",
                "debug/**",
                "todos/**",
                "plans/**",
                "file-history/**",
                "paste-cache/**",
                "session-env/**",
                "shell-snapshots/**",
                "telemetry/**",
                "statsig/**",
                "ide/**",
                "downloads/**",
                "plugins/**",
                "tasks/**",
            ],
        )

    def get_projects(self, base_path: Path | None = None) -> list[ProjectInfo]:
        """Get list of Claude projects from projects/ subdirectory."""
        base = base_path if base_path else self.defaults.base_path
        projects_dir = base / "projects"
        if not projects_dir.exists():
            return []

        projects = []
        for path in sorted(projects_dir.iterdir()):
            if not path.is_dir():
                continue

            encoded_name = path.name
            original_path = self.decode_project_path(encoded_name)

            projects.append(
                ProjectInfo(
                    name=Path(original_path).name,
                    encoded_name=encoded_name,
                    original_path=original_path,
                    config_path=path,
                )
            )

        return projects

    def encode_project_path(self, path: str) -> str:
        """Convert a project path to Claude's encoded form.

        Claude encodes paths by replacing / with - and ~ with home path.
        Example: ~/workspace/Backend -> -home-user-workspace-Backend
        """
        expanded = Path(path).expanduser().resolve()
        return str(expanded).replace("/", "-")

    def decode_project_path(self, encoded: str) -> str:
        """Convert an encoded project name back to original path.

        Example: -home-user-workspace-Backend -> /home/user/workspace/Backend
        """
        if not encoded.startswith("-"):
            return encoded

        path = encoded.replace("-", "/")
        return path

    def get_project_config_files(self, project: ProjectInfo) -> list[ProjectConfigFile]:
        """Get Claude config files from the actual project repository.

        Scans for:
        - .claude/* (all files in .claude/ folder)
        - CLAUDE.md at repo root

        Returns only files that exist, with their git status.
        """
        repo_path = Path(project.original_path)
        if not repo_path.exists():
            return []

        config_files = []

        repo_root = get_repo_root(repo_path) if is_git_repo(repo_path) else None

        claude_md = repo_path / "CLAUDE.md"
        if claude_md.exists():
            tracked = is_file_tracked(repo_root, claude_md) if repo_root else False
            ignored = is_file_ignored(repo_root, claude_md) if repo_root else False
            config_files.append(
                ProjectConfigFile(
                    path=claude_md,
                    relative_path="CLAUDE.md",
                    is_tracked=tracked,
                    is_ignored=ignored,
                )
            )

        exclude_patterns = (
            self.defaults.cache_patterns
            + self.defaults.sensitive_patterns
            + self.defaults.exclude_patterns
        )
        claude_dir = repo_path / ".claude"
        if claude_dir.exists() and claude_dir.is_dir():
            for file_path in claude_dir.rglob("*"):
                if not file_path.is_file():
                    continue
                rel_to_claude = str(file_path.relative_to(claude_dir))
                if any(_matches_pattern(rel_to_claude, p) for p in exclude_patterns):
                    continue
                rel_path = file_path.relative_to(repo_path)
                tracked = is_file_tracked(repo_root, file_path) if repo_root else False
                ignored = is_file_ignored(repo_root, file_path) if repo_root else False
                config_files.append(
                    ProjectConfigFile(
                        path=file_path,
                        relative_path=str(rel_path),
                        is_tracked=tracked,
                        is_ignored=ignored,
                    )
                )

        return config_files
