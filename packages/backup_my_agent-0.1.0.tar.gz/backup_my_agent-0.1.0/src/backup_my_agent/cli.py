"""CLI entry point for backup-my-agent."""

from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

from backup_my_agent import __version__
from backup_my_agent.agents import AGENTS
from backup_my_agent.backup import create_file_mappings, run_backup, run_restore
from backup_my_agent.config import delete_plan, list_plans, load_plan
from backup_my_agent.discover import discover_agent
from backup_my_agent.git import clone_repo, commit, has_changes, push, stage_all

app = typer.Typer(
    name="backup-my-agent",
    help="Backup agent configuration files to a git repository.",
    no_args_is_help=True,
)
console = Console()


def version_callback(value: bool) -> None:
    if value:
        console.print(f"backup-my-agent {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        bool,
        typer.Option("--version", "-v", callback=version_callback, is_eager=True),
    ] = False,
) -> None:
    """Backup agent configuration files to a git repository."""
    pass


@app.command()
def discover(
    agent: Annotated[
        str,
        typer.Argument(help=f"Agent to discover. Available: {list(AGENTS.keys())}"),
    ],
    path: Annotated[
        Path | None,
        typer.Argument(help="Path to search. Defaults to agent's default location."),
    ] = None,
) -> None:
    """Interactively create a backup plan for an agent."""
    if agent not in AGENTS:
        console.print(f"[red]Unknown agent:[/red] {agent}")
        console.print(f"Available agents: {list(AGENTS.keys())}")
        raise typer.Exit(1)

    search_path = path.expanduser() if path else None
    plan = discover_agent(agent, search_path)
    if plan:
        console.print(f"\n[green]Run 'backup-my-agent backup {plan.name}' to backup[/green]")


@app.command()
def plans() -> None:
    """List available backup plans."""
    plan_names = list_plans()

    if not plan_names:
        console.print("[yellow]No plans found.[/yellow]")
        console.print("Run 'backup-my-agent discover <agent>' to create one.")
        return

    table = Table(title="Available Plans")
    table.add_column("Name", style="cyan")
    table.add_column("Destination")
    table.add_column("Sources", justify="right")

    for name in plan_names:
        try:
            plan = load_plan(name)
            table.add_row(plan.name, plan.destination, str(len(plan.sources)))
        except Exception as e:
            table.add_row(name, f"[red]Error: {e}[/red]", "-")

    console.print(table)


@app.command()
def delete(
    plan_name: Annotated[
        str,
        typer.Argument(help="Name of the plan to delete"),
    ],
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Skip confirmation"),
    ] = False,
) -> None:
    """Delete a backup plan."""
    from rich.prompt import Confirm

    try:
        load_plan(plan_name)  # Verify plan exists
    except FileNotFoundError:
        console.print(f"[red]Plan not found:[/red] {plan_name}")
        raise typer.Exit(1)

    if not force:
        if not Confirm.ask(f"Delete plan [cyan]{plan_name}[/cyan]?", default=False):
            console.print("[yellow]Cancelled[/yellow]")
            return

    delete_plan(plan_name)
    console.print(f"[green]Deleted plan:[/green] {plan_name}")


@app.command()
def status(
    plan_name: Annotated[
        str | None,
        typer.Argument(help="Plan name. If not specified, prompts for selection."),
    ] = None,
) -> None:
    """Show what would be backed up (dry-run)."""
    plan_name = _resolve_plan_name(plan_name)
    if not plan_name:
        return

    plan = load_plan(plan_name)

    console.print(f"\n[bold]Plan:[/bold] {plan.name}")
    console.print(f"[bold]Destination:[/bold] {plan.destination}")
    console.print()

    agent_name = plan_name.split("-")[0] if "-" in plan_name else plan_name
    mappings = create_file_mappings(plan, agent_name)

    console.print("[bold]Files to backup:[/bold]\n")
    for mapping in mappings:
        console.print(f"  {mapping.source} [dim]->[/dim] {mapping.relative_path}")

    console.print(f"\n[bold]Total files:[/bold] {len(mappings)}")


@app.command()
def backup(
    plan_name: Annotated[
        str | None,
        typer.Argument(help="Plan name. If not specified, prompts for selection."),
    ] = None,
    message: Annotated[
        str | None,
        typer.Option("--message", "-m", help="Commit message"),
    ] = None,
) -> None:
    """Run backup: clone, copy files, commit, push."""
    plan_name = _resolve_plan_name(plan_name)
    if not plan_name:
        return

    plan = load_plan(plan_name)
    agent_name = plan_name.split("-")[0] if "-" in plan_name else plan_name

    try:
        with console.status(f"[bold]Backing up {plan.name}...[/bold]"):
            repo_ctx = clone_repo(plan.destination)
            repo_path = repo_ctx.__enter__()

        try:
            with console.status("[bold]Copying files...[/bold]"):
                mappings = run_backup(plan, repo_path, agent_name)

            stage_all(repo_path)

            if not has_changes(repo_path):
                console.print("[yellow]No changes to commit[/yellow]")
                return

            with console.status("[bold]Pushing...[/bold]"):
                commit_hash = commit(repo_path, message)
                push(repo_path)

            console.print(
                f"[green]Backed up {len(mappings)} files[/green] ({commit_hash[:8]})"
            )

        finally:
            repo_ctx.__exit__(None, None, None)

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def restore(
    plan_name: Annotated[
        str | None,
        typer.Argument(help="Plan name. If not specified, prompts for selection."),
    ] = None,
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Skip confirmation prompt"),
    ] = False,
) -> None:
    """Restore files from backup repository to original locations."""
    plan_name = _resolve_plan_name(plan_name)
    if not plan_name:
        return

    plan = load_plan(plan_name)
    agent_name = plan_name.split("-")[0] if "-" in plan_name else plan_name

    try:
        with clone_repo(plan.destination) as repo_path:
            agent_dir = repo_path / agent_name
            if not agent_dir.exists():
                console.print(f"[yellow]No files found for agent '{agent_name}'[/yellow]")
                return

            sources_by_name = {s.name: s for s in plan.sources}
            preview_files = []

            for file_path in agent_dir.rglob("*"):
                if not file_path.is_file():
                    continue

                rel_to_agent = file_path.relative_to(agent_dir)
                parts = rel_to_agent.parts

                if parts[0] in sources_by_name and parts[0] != "global":
                    source = sources_by_name[parts[0]]
                    rel_path = Path(*parts[1:])
                elif "global" in sources_by_name:
                    source = sources_by_name["global"]
                    rel_path = rel_to_agent
                else:
                    continue

                dest_path = source.base_path / rel_path
                preview_files.append((rel_to_agent, dest_path))

            if not preview_files:
                console.print("[yellow]No matching files to restore[/yellow]")
                return

            console.print("\n[bold]Files to restore:[/bold]\n")
            for rel, dest in preview_files:
                console.print(f"  {rel} [dim]->[/dim] {dest}")

            console.print(f"\n[bold]Total files:[/bold] {len(preview_files)}")

            if not force:
                from rich.prompt import Confirm

                if not Confirm.ask("\nProceed with restore?", default=False):
                    console.print("[yellow]Cancelled[/yellow]")
                    return

            mappings = run_restore(plan, repo_path, agent_name)
            console.print(f"\n[green]Restored {len(mappings)} files[/green]")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


def _resolve_plan_name(plan_name: str | None) -> str | None:
    """Resolve plan name, prompting if necessary."""
    if plan_name:
        return plan_name

    available = list_plans()
    if not available:
        console.print("[yellow]No plans found.[/yellow]")
        console.print("Run 'backup-my-agent discover <agent>' to create one.")
        return None

    if len(available) == 1:
        return available[0]

    console.print("Available plans:")
    for i, name in enumerate(available, 1):
        console.print(f"  {i}. {name}")

    choice = typer.prompt("Select plan number", type=int)
    if choice < 1 or choice > len(available):
        console.print("[red]Invalid choice[/red]")
        return None

    return available[choice - 1]


if __name__ == "__main__":
    app()
