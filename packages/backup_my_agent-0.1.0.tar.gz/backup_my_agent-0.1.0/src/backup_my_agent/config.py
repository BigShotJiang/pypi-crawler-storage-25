"""Configuration and plan management."""

from dataclasses import dataclass, field
from pathlib import Path

import yaml

CONFIG_DIR = Path.home() / ".backup-my-agent"
PLANS_DIR = CONFIG_DIR / "plans"


@dataclass
class Source:
    """A source to backup."""

    name: str
    base_path: Path
    include: list[str]
    exclude: list[str] = field(default_factory=list)


@dataclass
class Plan:
    """A backup plan configuration."""

    name: str
    destination: str
    sources: list[Source]


def ensure_config_dirs() -> None:
    """Ensure configuration directories exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    PLANS_DIR.mkdir(parents=True, exist_ok=True)


def list_plans() -> list[str]:
    """List available plan names."""
    if not PLANS_DIR.exists():
        return []

    return [p.stem for p in PLANS_DIR.glob("*.yaml")]


def load_plan(name: str) -> Plan:
    """Load a plan by name."""
    plan_path = PLANS_DIR / f"{name}.yaml"
    if not plan_path.exists():
        raise FileNotFoundError(f"Plan not found: {name}")

    with open(plan_path) as f:
        data = yaml.safe_load(f)

    return _parse_plan(data)


def save_plan(plan: Plan) -> Path:
    """Save a plan to disk."""
    ensure_config_dirs()

    plan_path = PLANS_DIR / f"{plan.name}.yaml"
    data = _serialize_plan(plan)

    with open(plan_path, "w") as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)

    return plan_path


def delete_plan(name: str) -> None:
    """Delete a plan by name."""
    plan_path = PLANS_DIR / f"{name}.yaml"
    if not plan_path.exists():
        raise FileNotFoundError(f"Plan not found: {name}")

    plan_path.unlink()


def _parse_plan(data: dict) -> Plan:
    """Parse plan data into a Plan object."""
    sources = []
    for source_data in data.get("sources", []):
        sources.append(
            Source(
                name=source_data["name"],
                base_path=Path(source_data["base_path"]).expanduser(),
                include=source_data.get("include", []),
                exclude=source_data.get("exclude", []),
            )
        )

    return Plan(
        name=data["name"],
        destination=data["destination"],
        sources=sources,
    )


def _serialize_plan(plan: Plan) -> dict:
    """Serialize a Plan object to dict for YAML."""
    sources = []
    for source in plan.sources:
        source_data = {
            "name": source.name,
            "base_path": str(source.base_path),
            "include": source.include,
        }
        if source.exclude:
            source_data["exclude"] = source.exclude
        sources.append(source_data)

    return {
        "name": plan.name,
        "destination": plan.destination,
        "sources": sources,
    }
