"""Backup agent configuration files to a git repository."""

from importlib.metadata import version

__version__ = version("backup-my-agent")
