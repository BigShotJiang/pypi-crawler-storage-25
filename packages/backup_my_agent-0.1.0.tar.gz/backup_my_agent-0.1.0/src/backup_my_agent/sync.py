"""File synchronization utilities."""

import shutil
import subprocess
from pathlib import Path

_rsync_available: bool | None = None


def _check_rsync() -> bool:
    """Check if rsync is available."""
    global _rsync_available
    if _rsync_available is None:
        result = subprocess.run(["rsync", "--version"], capture_output=True)
        _rsync_available = result.returncode == 0
    return _rsync_available


def copy_file(source: Path, destination: Path) -> None:
    """Copy a file, using rsync if available, otherwise shutil."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    if _check_rsync():
        subprocess.run(
            ["rsync", "-a", "--checksum", str(source), str(destination)],
            check=True,
            capture_output=True,
        )
    else:
        shutil.copy2(source, destination)
