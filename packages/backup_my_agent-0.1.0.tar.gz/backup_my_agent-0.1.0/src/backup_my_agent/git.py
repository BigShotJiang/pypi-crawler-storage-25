"""Git operations for backup-my-agent."""

import datetime
import subprocess
import tempfile
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path


class GitError(Exception):
    """Git operation failed."""

    pass


_GIT_CONFIG_KEYS = [
    "user.name",
    "user.email",
    "user.signingkey",
    "commit.gpgsign",
    "gpg.format",
    "gpg.program",
    "gpg.ssh.defaultKeyCommand",
    "gpg.ssh.allowedSignersFile",
    "core.sshCommand",
]


def is_local_path(repo_url: str) -> bool:
    """Check if a repo URL is a local filesystem path."""
    return repo_url.startswith("/") or repo_url.startswith("~") or repo_url.startswith(".")


def _run_git(args: list[str], cwd: Path | None = None) -> str:
    """Run a git command and return output."""
    cmd = ["git"] + args
    try:
        result = subprocess.run(
            cmd,
            cwd=cwd,
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        raise GitError(f"Git command failed: {' '.join(cmd)}\n{e.stderr}") from e


def _read_git_config(key: str) -> str | None:
    """Read a git config value from the user's effective config."""
    try:
        return _run_git(["config", key])
    except GitError:
        return None


def _configure_repo_identity(repo_path: Path) -> None:
    """Copy git identity and signing config from user's environment to a repo."""
    for key in _GIT_CONFIG_KEYS:
        value = _read_git_config(key)
        if value:
            _run_git(["config", key, value], cwd=repo_path)


@contextmanager
def clone_repo(repo_url: str) -> Iterator[Path]:
    """Clone a repo to a temp directory, yield the path, then clean up.

    Args:
        repo_url: Repository URL (SSH, HTTPS, or local path)

    Yields:
        Path to the cloned repository
    """
    with tempfile.TemporaryDirectory(prefix="backup-my-agent-") as tmpdir:
        repo_path = Path(tmpdir) / "repo"
        _run_git(["clone", repo_url, str(repo_path)])
        _configure_repo_identity(repo_path)
        yield repo_path


def stage_all(repo_path: Path) -> None:
    """Stage all changes in the repository."""
    _run_git(["add", "-A"], cwd=repo_path)


def has_changes(repo_path: Path) -> bool:
    """Check if there are staged changes to commit."""
    result = _run_git(["status", "--porcelain"], cwd=repo_path)
    return bool(result)


def commit(repo_path: Path, message: str | None = None) -> str:
    """Commit staged changes.

    Args:
        repo_path: Path to the repository
        message: Commit message. If None, generates a timestamp message.

    Returns:
        The commit hash
    """
    if message is None:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"Backup: {timestamp}"

    _run_git(["commit", "-m", message], cwd=repo_path)
    return _run_git(["rev-parse", "HEAD"], cwd=repo_path)


def push(repo_path: Path) -> None:
    """Push commits to remote."""
    _run_git(["push"], cwd=repo_path)


def get_remote_url(repo_path: Path) -> str:
    """Get the remote URL of a repository."""
    return _run_git(["remote", "get-url", "origin"], cwd=repo_path)


def is_git_repo(path: Path) -> bool:
    """Check if a path is inside a git repository."""
    try:
        _run_git(["rev-parse", "--git-dir"], cwd=path)
        return True
    except GitError:
        return False


def get_repo_root(path: Path) -> Path | None:
    """Get the root directory of a git repository containing path."""
    try:
        root = _run_git(["rev-parse", "--show-toplevel"], cwd=path)
        return Path(root)
    except GitError:
        return None


def is_file_tracked(repo_path: Path, file_path: Path) -> bool:
    """Check if a file is tracked (committed) in git.

    Args:
        repo_path: Path to the git repository root
        file_path: Path to the file (absolute or relative to repo)

    Returns:
        True if the file is tracked by git
    """
    try:
        rel_path = file_path.relative_to(repo_path) if file_path.is_absolute() else file_path
        _run_git(["ls-files", "--error-unmatch", str(rel_path)], cwd=repo_path)
        return True
    except GitError:
        return False


def is_file_ignored(repo_path: Path, file_path: Path) -> bool:
    """Check if a file is ignored by .gitignore.

    Args:
        repo_path: Path to the git repository root
        file_path: Path to the file (absolute or relative to repo)

    Returns:
        True if the file is ignored by git
    """
    try:
        rel_path = file_path.relative_to(repo_path) if file_path.is_absolute() else file_path
        cmd = ["git", "check-ignore", "-q", str(rel_path)]
        result = subprocess.run(cmd, cwd=repo_path, capture_output=True)
        return result.returncode == 0
    except Exception:
        return False
