"""Backup file collection and copying."""

import fnmatch
from dataclasses import dataclass
from pathlib import Path

from backup_my_agent.config import Plan, Source
from backup_my_agent.sync import copy_file


@dataclass
class FileMapping:
    """Mapping from source file to destination."""

    source: Path
    destination: Path
    relative_path: str


def collect_files(source: Source) -> list[Path]:
    """Collect files matching include patterns, excluding exclude patterns."""
    if not source.base_path.exists():
        return []

    included: set[Path] = set()

    for pattern in source.include:
        if "**" in pattern:
            matches = source.base_path.glob(pattern)
        else:
            matches = source.base_path.glob(pattern)

        for path in matches:
            if path.is_file():
                included.add(path)

    excluded: set[Path] = set()
    for pattern in source.exclude:
        for path in included:
            rel_path = path.relative_to(source.base_path)
            if _matches_pattern(str(rel_path), pattern):
                excluded.add(path)

    return sorted(included - excluded)


def _matches_pattern(path: str, pattern: str) -> bool:
    """Check if a path matches a glob pattern."""
    if pattern.startswith("**/"):
        # Pattern like **/.git/** - match anywhere in path
        suffix = pattern[3:]  # Remove **/
        if suffix.endswith("/**"):
            # **/.git/** -> check if /.git/ appears in path or path starts with .git/
            segment = suffix[:-3]  # Remove /**
            return f"/{segment}/" in f"/{path}/" or path.startswith(f"{segment}/")
        return fnmatch.fnmatch(path, f"*{suffix}") or fnmatch.fnmatch(path, suffix)
    if "**" in pattern:
        parts = pattern.split("**")
        if len(parts) == 2:
            prefix, suffix = parts
            prefix = prefix.rstrip("/")
            suffix = suffix.lstrip("/")
            if prefix and not path.startswith(prefix):
                return False
            if suffix and not fnmatch.fnmatch(path, f"*{suffix}"):
                return False
            return True
    return fnmatch.fnmatch(path, pattern)


def create_file_mappings(
    plan: Plan, agent_name: str, destination_root: Path | None = None
) -> list[FileMapping]:
    """Create file mappings for all sources in a plan.

    Files are organized under {agent_name}/ in the destination.
    """
    mappings = []

    for source in plan.sources:
        files = collect_files(source)

        for file_path in files:
            rel_to_base = file_path.relative_to(source.base_path)

            if source.name == "global":
                dest_rel = Path(agent_name) / rel_to_base
            else:
                dest_rel = Path(agent_name) / source.name / rel_to_base

            if destination_root:
                dest_path = destination_root / dest_rel
            else:
                dest_path = dest_rel

            mappings.append(
                FileMapping(
                    source=file_path,
                    destination=dest_path,
                    relative_path=str(dest_rel),
                )
            )

    return mappings


def copy_files(mappings: list[FileMapping]) -> int:
    """Copy files according to mappings.

    Returns:
        Number of files copied
    """
    copied = 0

    for mapping in mappings:
        copy_file(mapping.source, mapping.destination)
        copied += 1

    return copied


def run_backup(plan: Plan, destination_root: Path, agent_name: str) -> list[FileMapping]:
    """Run a backup according to the plan.

    Args:
        plan: The backup plan
        destination_root: Root path of the destination repo
        agent_name: Name of the agent (e.g., 'claude')

    Returns:
        List of file mappings that were copied
    """
    mappings = create_file_mappings(plan, agent_name, destination_root)
    copy_files(mappings)
    return mappings


def run_restore(plan: Plan, repo_path: Path, agent_name: str) -> list[FileMapping]:
    """Restore files from backup repo to original locations.

    Args:
        plan: The backup plan (contains sources with base_paths)
        repo_path: Path to cloned backup repository
        agent_name: Name of the agent (e.g., 'claude')

    Returns:
        List of file mappings that were restored
    """
    mappings = []
    agent_dir = repo_path / agent_name

    if not agent_dir.exists():
        return mappings

    sources_by_name = {s.name: s for s in plan.sources}

    for file_path in agent_dir.rglob("*"):
        if not file_path.is_file():
            continue

        rel_to_agent = file_path.relative_to(agent_dir)
        parts = rel_to_agent.parts

        if parts[0] in sources_by_name and parts[0] != "global":
            source = sources_by_name[parts[0]]
            rel_path = Path(*parts[1:])
        elif "global" in sources_by_name:
            source = sources_by_name["global"]
            rel_path = rel_to_agent
        else:
            continue

        dest_path = source.base_path / rel_path
        mappings.append(
            FileMapping(
                source=file_path,
                destination=dest_path,
                relative_path=str(rel_to_agent),
            )
        )

    for mapping in mappings:
        copy_file(mapping.source, mapping.destination)

    return mappings
