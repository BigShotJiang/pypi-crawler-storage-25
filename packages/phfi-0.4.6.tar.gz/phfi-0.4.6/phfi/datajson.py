'''
© Todos direitos reservados
→ Por PudimDev

---> Esta função é sobre o json das palavras.
Ela contem:
- version()
- exportjson()

E o módulo de manipulações com as palavras
'''

import json
from importlib import resources


def version():
	'''Retorna a versão na tela'''
	return "Banco de dados 0.1.0 • 2026 © All rights reserved."

def exportjson():
	'''Retorna o json das palavras em lista.'''
	with resources.files("phfi").joinpath("main.json").open("r", encoding="utf-8") as f:
	        data = json.loads(f.read())

	return data


