'''
© Todos os direitos reservados.
Por PudimDev

---> Este modulo é sobre as palavras filosoficas
algumas funções disponivel (Por enquanto):

- datajson
'''

script = '''
from phfi import datajson
import json

data = datajson.exportjson
'''

def version():
	return "PHFI v0.4.5, All right reserves"
