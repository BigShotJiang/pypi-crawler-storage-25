# Autor
Nome: Pudim
Telefone: 5593381063822
Email: jonnas9908@gmail.com

## Nota:
Quero fazer o máximo pra ser um bom desenvolvedor!

# phfi — Frases filosoficas
## Pra que eu vou usar?
Está **CLI** está atualizando quase toda hora, você
acessa alguns banco de dados e frases, não é grande
mais também não é pequeno

## Instalação
Ela é uma biblioteca Python, talvez no futuro possa
existir para outras linguagens, como instalar:

* bash
pip install phfi


## Dentro da biblioteca phfi
Dentro de **phfi** você pode usar os:

### from phfi import datajson
Importa a biblioteca do json, este e oque você
vai mais usar

#### version()
Mostra para você a versão do phfi, é inútil.
mais pode provar pra você oque você está usando
não é bem inútil, uma hora você vai usar

#### exportjson(indent=0, 4, 8)
Isso exporta o json das palavras, no python
isso vira uma lista, mais tecnicamente é
json.

O **indent** da função marca qual estilos/espaços
você quer que apareça, exemplo:

- 0 — Isso fica só em uma linha, sem espaços.
- 4 — Isso marca 4 espaços de cada linha.
- 8 — Isso marca 8 espaços de cada linha.

## Final
No futuro podemos ter mais função, mais agora
ainda estamos sem condições sobre isso.
