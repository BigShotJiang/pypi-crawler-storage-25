## Usage

```python
import FlashyAPI

# Non-streaming
FlashyAPI.generate(
    apiKey="your-api-key",
    model="model-name",
    prompt="Your question here",
    streaming=False
)

# Streaming
FlashyAPI.generate(
    apiKey="your-api-key",
    model="model-name",
    prompt="Your question here",
    streaming=True
)
```

# Questions?
## How to get a api key?
Join our discord and open a ticket and ask for a api key! https://discord.gg/Y6aVDdyfm7
You will get 5k Credits for free.

## What happens to my prompts?
Your prompts will be send to a model from FloxyLabs.eu! All your data is secured. 

## What data will be published?
Your Used Model, Token Usage and Credit Usage will be saved to https://flashapi.floxylabs.eu/v1/activity

## What are Credits?
Credits is the currency system from FloxyLabs. Its TOTAL_TOKENS x MODEL_MULTIPLIER = TOTAL_CREDITS