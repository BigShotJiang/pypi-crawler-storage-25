"""Shared provider runtime wiring for product surfaces.

This module keeps surface-level provider profile parsing, encrypted local
credential lookup, endpoint model discovery, and runtime capability selection
in one place so CLI, API, and gateway do not each keep private copies of the
same rules.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
import json
import os
from pathlib import Path
from typing import Any
from urllib import error, request
from urllib.parse import quote

from packages.auth import (
    AuthProfile,
    LocalEncryptedSecretCipher,
    PersistentAuthProfileStore,
    ProfileCredentialResolver,
    ProviderCatalog,
    ProviderProfileFactory,
    ProviderProfileInput,
    SecretReference,
    SecretStore,
    profile_from_input,
)
from packages.capabilities.runtime import CapabilityDescriptor, ModelProviderCapability
from packages.contracts.runtime import ContextBundle, ExecutionResult, ProfileState, SessionState
from packages.models import ModelRequest, ProviderRuntimeResolver, build_model_adapter
from packages.storage import RuntimeStorageRepository
from packages.tools import ToolDefinition, ToolRuntime

_MODEL_CONTEXT_KEYS = (
    "context_length",
    "context_window",
    "max_context_length",
    "max_position_embeddings",
    "max_model_len",
    "max_input_tokens",
    "max_sequence_length",
    "max_seq_len",
    "n_ctx",
    "n_ctx_train",
)
_MODEL_OUTPUT_KEYS = (
    "max_completion_tokens",
    "max_output_tokens",
    "max_tokens",
)
DEFAULT_CONTEXT_WINDOW_TOKENS = 128_000


@dataclass(frozen=True, slots=True)
class DiscoveredProviderModel:
    model_id: str
    label: str
    context_window_tokens: int | None = None
    max_output_tokens: int | None = None
    source: str = "endpoint"
    metadata: Mapping[str, str] = field(default_factory=dict)


def _normalize_base_url(base_url: str | None) -> str:
    return str(base_url or "").strip().rstrip("/")


def _compose_provider_url(base_url: str, endpoint_path: str) -> str:
    trimmed_base = _normalize_base_url(base_url)
    trimmed_path = endpoint_path.lstrip("/")
    if trimmed_path.startswith("v1/") and trimmed_base.endswith("/v1"):
        trimmed_path = trimmed_path[3:]
    return f"{trimmed_base}/{trimmed_path}"


def _coerce_reasonable_int(value: Any, *, minimum: int = 1024, maximum: int = 10_000_000) -> int | None:
    try:
        if isinstance(value, bool):
            return None
        if isinstance(value, str):
            value = value.strip().replace(",", "")
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    if minimum <= parsed <= maximum:
        return parsed
    return None


def _iter_nested_mappings(value: Any):
    if isinstance(value, Mapping):
        yield value
        for nested in value.values():
            yield from _iter_nested_mappings(nested)
    elif isinstance(value, list):
        for item in value:
            yield from _iter_nested_mappings(item)


def _extract_nested_int(payload: Mapping[str, Any], keys: tuple[str, ...]) -> int | None:
    keyset = {key.casefold() for key in keys}
    for mapping in _iter_nested_mappings(payload):
        for key, value in mapping.items():
            if str(key).casefold() not in keyset:
                continue
            parsed = _coerce_reasonable_int(value)
            if parsed is not None:
                return parsed
    return None


def _context_window_from_payload(payload: Mapping[str, Any]) -> int | None:
    return _extract_nested_int(payload, _MODEL_CONTEXT_KEYS)


def _max_output_tokens_from_payload(payload: Mapping[str, Any]) -> int | None:
    return _extract_nested_int(payload, _MODEL_OUTPUT_KEYS)


def _provider_request_headers(
    *,
    provider_id: str,
    request_family: str,
    api_key: str | None,
) -> dict[str, str]:
    headers: dict[str, str] = {"Accept": "application/json"}
    if not api_key:
        return headers
    if request_family == "messages" or provider_id in {"anthropic", "minimax"}:
        headers["x-api-key"] = api_key
        headers["anthropic-version"] = "2023-06-01"
        return headers
    headers["Authorization"] = f"Bearer {api_key}"
    return headers


def _request_json(
    *,
    url: str,
    headers: Mapping[str, str],
    timeout_seconds: float = 10.0,
) -> dict[str, Any]:
    http_request = request.Request(
        url,
        headers=dict(headers),
        method="GET",
    )
    try:
        with request.urlopen(http_request, timeout=timeout_seconds) as response:
            raw_body = response.read().decode("utf-8")
            payload = json.loads(raw_body) if raw_body else {}
    except error.HTTPError as exc:  # pragma: no cover - exercised by integration tests
        detail = exc.read().decode("utf-8", errors="replace").strip()
        suffix = f" {detail[:200]}" if detail else ""
        raise RuntimeError(f"provider metadata request failed with status {exc.code}.{suffix}".strip()) from exc
    except error.URLError as exc:  # pragma: no cover - exercised by integration tests
        raise RuntimeError(f"provider metadata request failed for {url}: {exc.reason}") from exc
    if not isinstance(payload, dict):
        raise RuntimeError("provider metadata response must be a JSON object")
    return {str(key): value for key, value in payload.items()}


def provider_profile_from_payload(payload: Mapping[str, Any]) -> AuthProfile:
    secret_references = tuple(
        secret_reference_from_payload(item)
        for item in payload.get("secret_references", ())
    )
    profile_input = ProviderProfileInput(
        profile_id=str(payload["profile_id"]),
        provider_id=str(payload["provider_id"]),
        secret_references=secret_references,
        priority=int(payload.get("priority", 0)),
        session_pin=str(payload["session_pin"]) if payload.get("session_pin") is not None else None,
        cooldown_until=None,
        metadata={str(key): str(value) for key, value in dict(payload.get("metadata", {})).items()},
    )
    provider_id = profile_input.provider_id
    base_url = payload.get("base_url")
    default_model = payload.get("default_model")
    transport_id = payload.get("transport_id")
    auth_method = payload.get("auth_method")
    provider_kind = payload.get("provider_kind")
    extra_headers = payload.get("extra_headers")
    catalog = ProviderCatalog.with_defaults()
    provider_defaults = catalog.get(provider_id)
    if provider_id == "openai-compatible" and (base_url is None or default_model is None):
        raise ValueError("openai-compatible provider profiles require base_url and default_model")
    if any(value is not None for value in (base_url, default_model, transport_id, auth_method, provider_kind, extra_headers)):
        default_profile = None
        if provider_defaults is not None:
            default_profile = ProviderProfileFactory(catalog).from_provider_defaults(
                provider_id,
                profile_id=profile_input.profile_id,
                secret_references=profile_input.secret_references,
                priority=profile_input.priority,
                session_pin=profile_input.session_pin,
                cooldown_until=profile_input.cooldown_until,
                metadata=profile_input.metadata,
            )
        return profile_from_input(
            profile_input,
            base_url=(
                str(base_url)
                if base_url is not None
                else (default_profile.base_url if default_profile is not None else "")
            ),
            default_model=(
                str(default_model)
                if default_model is not None
                else (default_profile.default_model if default_profile is not None else "")
            ),
            transport_id=(
                str(transport_id)
                if transport_id is not None
                else (default_profile.transport_id if default_profile is not None else "openai-compatible")
            ),
            auth_method=(
                str(auth_method)
                if auth_method is not None
                else (default_profile.auth_method if default_profile is not None else "api_key")
            ),
            provider_kind=(
                str(provider_kind)
                if provider_kind is not None
                else (default_profile.provider_kind if default_profile is not None else "custom")
            ),
            extra_headers=(
                {
                    **(dict(default_profile.extra_headers) if default_profile is not None else {}),
                    **{str(key): str(value) for key, value in dict(extra_headers or {}).items()},
                }
            ),
        )
    factory = ProviderProfileFactory(catalog)
    return factory.from_provider_defaults(
        provider_id,
        profile_id=profile_input.profile_id,
        secret_references=profile_input.secret_references,
        priority=profile_input.priority,
        session_pin=profile_input.session_pin,
        cooldown_until=profile_input.cooldown_until,
        metadata=profile_input.metadata,
    )


def secret_reference_from_payload(payload: Mapping[str, Any]) -> SecretReference:
    return SecretReference(
        reference_id=str(payload["reference_id"]),
        provider_id=str(payload["provider_id"]),
        secret_name=str(payload["secret_name"]),
        secret_key=str(payload["secret_key"]),
        source=str(payload.get("source", "workspace")),
        metadata={str(key): str(value) for key, value in dict(payload.get("metadata", {})).items()},
    )


def load_provider_profile(profile_dir: Path) -> AuthProfile | None:
    manifest_path = profile_dir / "profile.json"
    if not manifest_path.exists():
        return None
    with manifest_path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError("profile.json must contain a JSON object")
    provider_payload = payload.get("provider_profile")
    if not isinstance(provider_payload, dict):
        return None
    return provider_profile_from_payload(provider_payload)


def provider_profile_summary(profile: AuthProfile) -> dict[str, Any]:
    context_window_tokens = _coerce_reasonable_int(profile.metadata.get("context_window_tokens"))
    return {
        "profile_id": profile.profile_id,
        "provider_id": profile.provider_id,
        "transport_id": profile.transport_id,
        "base_url": profile.base_url,
        "default_model": profile.default_model,
        "auth_method": profile.auth_method,
        "provider_kind": profile.provider_kind,
        "extra_headers": dict(profile.extra_headers),
        "secret_reference_ids": tuple(reference.reference_id for reference in profile.secret_references),
        "context_window_tokens": context_window_tokens,
        "context_window_mode": str(profile.metadata.get("context_window_mode", "auto")),
        "source": "configured",
    }


def provider_fallback_summary() -> dict[str, Any]:
    return {
        "profile_id": "",
        "provider_id": "preview",
        "transport_id": "preview",
        "base_url": None,
        "default_model": None,
        "auth_method": "preview",
        "provider_kind": "preview",
        "extra_headers": {},
        "secret_reference_ids": (),
        "context_window_tokens": None,
        "context_window_mode": "unset",
        "source": "preview-fallback",
    }


class EncryptedRepositorySecretStore(SecretStore):
    def __init__(
        self,
        repository: RuntimeStorageRepository,
        *,
        cipher: LocalEncryptedSecretCipher,
    ) -> None:
        self.repository = repository
        self.cipher = cipher

    def read(self, reference: SecretReference) -> str:
        stored = self.repository.load_auth_secret_value(reference.reference_id)
        if stored is not None:
            return self.cipher.decrypt(stored)
        for env_name in reference.env_var_candidates():
            value = os.environ.get(env_name)
            if value is not None:
                return value
        raise LookupError(f"missing stored secret for reference: {reference.reference_id}")


class SurfaceModelProviderCapability(ModelProviderCapability):
    def __init__(
        self,
        *,
        repository: RuntimeStorageRepository,
        fallback: ModelProviderCapability,
        secret_key_path: Path,
        credential_resolver: ProfileCredentialResolver | None = None,
        tool_runtime: ToolRuntime | None = None,
        active_provider_profile_id: str | None = None,
        active_provider_id: str | None = None,
        capability_id: str = "surface.model.runtime",
        surface_label: str = "surface",
    ) -> None:
        self.repository = repository
        self.fallback = fallback
        self.secret_cipher = LocalEncryptedSecretCipher.from_path(secret_key_path)
        self.credential_resolver = credential_resolver or ProfileCredentialResolver(
            EncryptedRepositorySecretStore(
                repository,
                cipher=self.secret_cipher,
            )
        )
        self.tool_runtime = tool_runtime
        self.active_provider_profile_id = active_provider_profile_id
        self.active_provider_id = active_provider_id
        self.runtime_resolver = ProviderRuntimeResolver.default()
        self._stream_observer = None
        self.descriptor = CapabilityDescriptor(
            capability_id=capability_id,
            kind="model_provider",
            version="1.0.0",
            metadata={"description": f"{surface_label} model provider runtime wired to persisted provider profiles."},
        )

    def set_active_profile(
        self,
        *,
        provider_profile_id: str | None,
        provider_id: str | None,
    ) -> None:
        self.active_provider_profile_id = provider_profile_id
        self.active_provider_id = provider_id

    def active_profile(self) -> AuthProfile | None:
        if self.active_provider_profile_id is not None:
            profile = self.repository.load_auth_profile(self.active_provider_profile_id)
            if profile is not None:
                return profile
        if self.active_provider_id is not None:
            try:
                return self.repository.select_auth_profile(self.active_provider_id)
            except LookupError:
                return None
        return None

    def resolve_credentials(self, provider_profile: AuthProfile) -> Mapping[str, str]:
        return self.credential_resolver.resolve(provider_profile).as_mapping()

    def has_stored_secret(self, reference_id: str) -> bool:
        return self.repository.has_auth_secret_value(reference_id)

    def store_secret_value(self, reference: SecretReference, value: str) -> None:
        encrypted = self.secret_cipher.encrypt(
            reference_id=reference.reference_id,
            value=value,
        )
        self.repository.upsert_auth_secret_value(encrypted)

    def set_stream_observer(self, observer) -> None:
        self._stream_observer = observer

    def describe(self) -> Mapping[str, object]:
        profile = self.active_profile()
        if profile is None:
            return provider_fallback_summary()
        summary = provider_profile_summary(profile)
        resolution = self.runtime_resolver.resolve(
            profile.provider_id,
            model_id=profile.default_model,
            base_url=profile.base_url,
        )
        summary.update(
            {
                "display_name": resolution.display_name,
                "transport_display_name": resolution.transport_display_name,
                "supports_streaming": resolution.supports_streaming,
                "secret_status": (
                    "not-required"
                    if not profile.secret_references
                    else (
                        "stored"
                        if all(self.has_stored_secret(reference.reference_id) for reference in profile.secret_references)
                        else "missing"
                    )
                ),
                "secret_source": (
                    "encrypted-local-store"
                    if profile.secret_references
                    else "not-required"
                ),
            }
        )
        return summary

    def discover_models(
        self,
        *,
        provider_id: str,
        base_url: str | None,
        api_key: str | None = None,
    ) -> tuple[DiscoveredProviderModel, ...]:
        resolved_base_url = _normalize_base_url(base_url)
        if not resolved_base_url:
            return ()
        resolution = self.runtime_resolver.resolve(
            provider_id,
            model_id=self._default_model_for(provider_id) or "model-id",
            base_url=resolved_base_url,
        )
        payload = _request_json(
            url=_compose_provider_url(resolved_base_url, "/v1/models"),
            headers=_provider_request_headers(
                provider_id=provider_id,
                request_family=resolution.request_family,
                api_key=api_key,
            ),
        )
        data = payload.get("data", ())
        if not isinstance(data, list):
            return ()
        models: list[DiscoveredProviderModel] = []
        for item in data:
            if not isinstance(item, Mapping):
                continue
            model_id = str(item.get("id") or "").strip()
            if not model_id:
                continue
            context_window_tokens = _context_window_from_payload(item)
            max_output_tokens = _max_output_tokens_from_payload(item)
            label = str(item.get("name") or model_id)
            models.append(
                DiscoveredProviderModel(
                    model_id=model_id,
                    label=label,
                    context_window_tokens=context_window_tokens,
                    max_output_tokens=max_output_tokens,
                    metadata={
                        "owned_by": str(item.get("owned_by", "")),
                    },
                )
            )
        return tuple(models)

    def detect_context_window(
        self,
        *,
        provider_id: str,
        base_url: str | None,
        model_id: str,
        api_key: str | None = None,
    ) -> int | None:
        models = self.discover_models(
            provider_id=provider_id,
            base_url=base_url,
            api_key=api_key,
        )
        for item in models:
            if item.model_id == model_id and item.context_window_tokens is not None:
                return item.context_window_tokens
        resolved_base_url = _normalize_base_url(base_url)
        if not resolved_base_url:
            return None
        resolution = self.runtime_resolver.resolve(
            provider_id,
            model_id=model_id,
            base_url=resolved_base_url,
        )
        try:
            payload = _request_json(
                url=_compose_provider_url(resolved_base_url, f"/v1/models/{quote(model_id, safe='')}"),
                headers=_provider_request_headers(
                    provider_id=provider_id,
                    request_family=resolution.request_family,
                    api_key=api_key,
                ),
            )
        except RuntimeError:
            return _heuristic_context_window(model_id)
        return _context_window_from_payload(payload) or _heuristic_context_window(model_id)

    def _default_model_for(self, provider_id: str) -> str | None:
        try:
            guide = self.runtime_resolver.build_setup_guide(provider_id)
        except LookupError:
            return None
        return guide.suggested_model_id

    def _model_visible_tools(self) -> tuple[ToolDefinition, ...]:
        if self.tool_runtime is None:
            return ()
        return self.tool_runtime.list_tools(
            audience="model",
            enabled_only=True,
            available_only=True,
        )

    def _fallback_tool_prompt(self, tools: tuple[ToolDefinition, ...]) -> str:
        summaries = "\n".join(f"- {tool.prompt_summary()}" for tool in tools)
        return (
            "## available runtime tools\n"
            "Native provider tool calling is unavailable on this transport. "
            "Use the governed built-in tool surface through fallback markup when tool work is necessary.\n"
            "Emit <tool_call><invoke name=\"tool.id\"><parameter name=\"arg\">value</parameter></invoke></tool_call>.\n"
            "When a parameter needs structured data such as arrays or objects, encode valid JSON inside the parameter body.\n"
            "Do not include raw tool markup in the final user-facing answer.\n"
            "Tool schemas:\n"
            f"{summaries}"
        )

    def generate(
        self,
        *,
        profile: ProfileState,
        session: SessionState,
        context: ContextBundle,
        prompt: str,
    ) -> ExecutionResult:
        active_profile = self.active_profile()
        if active_profile is None:
            return self.fallback.generate(
                profile=profile,
                session=session,
                context=context,
                prompt=prompt,
            )
        resolution = self.runtime_resolver.resolve(
            active_profile.provider_id,
            model_id=active_profile.default_model or None,
            base_url=active_profile.base_url,
        )
        visible_tools = self._model_visible_tools()
        request_tools = (
            tuple(tool.model_function_schema() for tool in visible_tools)
            if resolution.supports_tools
            else ()
        )
        rendered_prompt = context.rendered_prompt or ""
        if visible_tools and not resolution.supports_tools:
            fallback_prompt = self._fallback_tool_prompt(visible_tools)
            rendered_prompt = (
                f"{rendered_prompt}\n\n{fallback_prompt}".strip()
                if rendered_prompt.strip()
                else fallback_prompt
            )

        request = ModelRequest(
            request_id=f"{session.session_id}:model",
            profile_id=profile.profile_id,
            session_id=session.session_id,
            provider_id=active_profile.provider_id,
            model_id=active_profile.default_model or "",
            prompt=prompt,
            context={
                "bundle_id": context.bundle_id,
                "token_budget": str(context.token_budget),
                "instruction_refs": ",".join(context.instruction_refs),
                "goal_ids": ",".join(context.goal_ids),
                "memory_ids": ",".join(context.memory_ids),
                "artifact_ids": ",".join(context.artifact_ids),
                "rendered_prompt": rendered_prompt,
            },
            metadata={
                "profile_mode": profile.mode,
                "session_status": session.status,
                "provider_profile_id": active_profile.profile_id,
            },
            tools=request_tools,
        )

        credentials = self.credential_resolver.resolve(active_profile).as_mapping()
        adapter = build_model_adapter(
            active_profile,
            runtime_resolver=self.runtime_resolver,
            credentials=credentials,
            adapter_id=f"adapter.models.{active_profile.provider_id}.surface",
            stream_observer=self._stream_observer,
        )
        if adapter is None:
            return self.fallback.generate(
                profile=profile,
                session=session,
                context=context,
                prompt=prompt,
            )
        result = adapter.generate(request, credentials)
        return ExecutionResult(
            execution_id=result.result_id,
            session_id=session.session_id,
            outcome="ok" if result.failure_kind is None else "failed",
            summary=result.content,
            prompt_tokens=result.usage.prompt_tokens,
            completion_tokens=result.usage.completion_tokens,
            total_tokens=result.usage.total_tokens,
            telemetry_event_ids=(request.request_id,),
            side_effects=(
                f"provider={result.provider_id}",
                f"model={result.model_id}",
                f"transport={result.metadata.get('transport_id', 'unknown')}",
                f"credential_keys={result.metadata.get('credential_keys', 'unknown')}",
            ),
            tool_calls=result.tool_calls,
        )

def register_provider_profile(
    repository: RuntimeStorageRepository,
    payload: Mapping[str, Any],
) -> AuthProfile:
    profile = provider_profile_from_payload(payload)
    PersistentAuthProfileStore(repository).register(profile)
    return profile


def _heuristic_context_window(model_id: str) -> int | None:
    normalized = model_id.casefold()
    heuristics = (
        ("gpt-4.1", 1_047_576),
        ("gpt-4o", 128_000),
        ("gpt-5", 128_000),
        ("claude", 200_000),
        ("gemini", 1_048_576),
        ("minimax-m2.5", 1_048_576),
        ("minimax-m2.7", 1_048_576),
        ("llama", 131_072),
        ("qwen", 131_072),
        ("deepseek", 128_000),
        ("kimi", 262_144),
    )
    for prefix, size in heuristics:
        if prefix in normalized:
            return size
    return DEFAULT_CONTEXT_WINDOW_TOKENS
