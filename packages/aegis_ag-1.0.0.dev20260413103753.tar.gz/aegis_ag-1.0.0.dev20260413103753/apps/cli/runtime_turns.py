from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from typing import TYPE_CHECKING, Any
from uuid import uuid4

from packages.contracts.runtime import EventEnvelope, ProfileState, SessionState
from packages.kernel import KernelDependencies, KernelOutcome, KernelService, KernelTurnRequest
from packages.planning.runtime import PlanningService, build_plan_draft_from_decision
from packages.profile import LoadedProfile, profile_bundle_dir

if TYPE_CHECKING:
    from apps.cli.runtime import CliRuntime


def start_session(
    runtime: CliRuntime,
    *,
    profile_id: str | None = None,
    display_name: str | None = None,
    mode: str | None = None,
    session_id: str | None = None,
    initial_goal: str | None = None,
) -> SessionState:
    loaded = runtime.profile_loader.load(
        profile_id=profile_id,
        display_name=display_name,
        mode=mode,
    )
    profile_state = replace(loaded.state, preferences=loaded.state.preferences)
    session = runtime.session_service.start_session(
        profile_state,
        session_id=session_id,
    )
    if initial_goal:
        runtime.seed_initial_goal(session.session_id, initial_goal)
    runtime._write_snapshot(
        profile=profile_state,
        session=session,
        goals=runtime.inspect_goals(session.session_id),
        memories=(),
        plan=None,
        execution=None,
        delivery=None,
        stages=(),
        event=None,
        clone_text=loaded.clone_text,
    )
    return session


def create_clone_session(
    runtime: CliRuntime,
    *,
    clone_id: str,
    profile_id: str | None = None,
    display_name: str | None = None,
    mode: str | None = None,
    session_id: str | None = None,
    initial_goal: str | None = None,
    seed_clone_text,
) -> SessionState:
    resolved_clone_id = clone_id.strip()
    if not resolved_clone_id:
        raise ValueError("clone name is required")
    if runtime.latest_session_for_clone(resolved_clone_id) is not None:
        raise ValueError(f"clone already exists: {resolved_clone_id}")
    source_profile = runtime._load_profile(profile_id or runtime.current_profile().state.profile_id)
    clone_profile_id = f"clone:{resolved_clone_id}"
    if display_name is None:
        clone_display_name = resolved_clone_id.replace("-", " ").title()
    else:
        clone_display_name = display_name.strip()
    clone_mode = mode or source_profile.state.mode
    clone_her_mode = source_profile.her_mode if clone_mode == "her" else None
    clone_text = seed_clone_text(
        source_profile,
        display_name=clone_display_name,
        mode=clone_mode,
        her_mode=clone_her_mode,
    )
    cloned_profile = runtime._persist_profile(
        LoadedProfile(
            state=replace(
                source_profile.state,
                profile_id=clone_profile_id,
                display_name=clone_display_name,
                mode=clone_mode,
                clone_path=None,
            ),
            her_mode=clone_her_mode,
            profile_dir=str(profile_bundle_dir(runtime.paths.profile_dir, clone_profile_id)),
            manifest_path=None,
            clone_text=clone_text,
            friend_text=None,
            manifest=dict(source_profile.manifest),
        ),
        clone_text=clone_text,
        friend_text=None,
    )
    profile_state = replace(cloned_profile.state, preferences=cloned_profile.state.preferences)
    session = runtime.session_service.start_session(
        profile_state,
        workspace_id=resolved_clone_id,
        session_id=session_id,
    )
    if initial_goal:
        runtime.seed_initial_goal(session.session_id, initial_goal)
    runtime._write_snapshot(
        profile=profile_state,
        session=session,
        goals=runtime.inspect_goals(session.session_id),
        memories=(),
        plan=None,
        execution=None,
        delivery=None,
        stages=(),
        event=None,
        clone_text=cloned_profile.clone_text,
    )
    return session


def resume_session(
    runtime: CliRuntime,
    session_id: str,
    *,
    resumed_session_id: str | None = None,
):
    result = runtime.session_service.resume_session(
        session_id,
        child_session_id=resumed_session_id,
    )
    session = result.session
    profile = runtime._load_profile(session.profile_id)
    runtime._write_snapshot(
        profile=profile.state,
        session=session,
        goals=(),
        memories=(),
        plan=None,
        execution=None,
        delivery=None,
        stages=(),
        event=None,
        clone_text=profile.clone_text,
    )
    if session is result.session:
        return result
    return result.__class__(session=session, lineage=result.lineage)


def explain_next_step(
    runtime: CliRuntime,
    *,
    session_id: str,
    prompt: str,
    goal_query: str | None = None,
    tool_name: str | None = None,
    tool_arguments: Mapping[str, Any] | None = None,
    delivery_payload: Mapping[str, Any] | None = None,
) -> KernelOutcome:
    return runtime._run_turn(
        session_id=session_id,
        prompt=prompt,
        goal_query=goal_query,
        tool_name=tool_name,
        tool_arguments=tool_arguments,
        delivery_payload=delivery_payload,
    )


def generate_opening_reply(
    runtime: CliRuntime,
    *,
    session_id: str,
    prompt: str,
    opening_label: str,
) -> KernelOutcome | None:
    if runtime.model_provider.active_profile() is None:
        return None
    return runtime._run_turn(
        session_id=session_id,
        prompt=prompt,
        event_type="turn.internal",
        source="cli.startup",
        event_payload={
            "message": f"startup opening ({opening_label})",
            "summary": f"startup opening ({opening_label})",
            "content": "",
        },
        record_input_event=False,
        record_outcome_memory=False,
        capture_experience=False,
        apply_growth=False,
    )


def run_turn(
    runtime: CliRuntime,
    *,
    session_id: str,
    prompt: str,
    goal_query: str | None = None,
    tool_name: str | None = None,
    tool_arguments: Mapping[str, Any] | None = None,
    delivery_payload: Mapping[str, Any] | None = None,
    event_type: str = "turn.received",
    source: str = "cli",
    event_payload: Mapping[str, str] | None = None,
    record_input_event: bool = True,
    record_outcome_memory: bool = True,
    capture_experience: bool = True,
    apply_growth: bool = True,
) -> KernelOutcome:
    session = runtime._load_session(session_id)
    profile = runtime._load_profile(session.profile_id).state
    dependencies = runtime._build_kernel_dependencies(session, profile)
    service = KernelService(dependencies=dependencies)
    payload = {
        "message": prompt,
        "content": prompt,
        "summary": prompt,
        "goal_query": goal_query or "",
        "tool_name": tool_name or "",
    }
    if event_payload is not None:
        payload.update(dict(event_payload))
    event = EventEnvelope(
        event_id=f"event:{uuid4().hex}",
        event_type=event_type,
        session_id=session.session_id,
        source=source,
        payload=payload,
    )
    if record_input_event:
        runtime.memory_runtime.append_event(event)
    outcome = service.run(
        KernelTurnRequest(
            event=event,
            prompt=prompt,
            goal_query=goal_query,
            tool_name=tool_name,
            tool_arguments=dict(tool_arguments or {}),
            delivery_payload=dict(delivery_payload or {}),
        )
    )
    if record_outcome_memory:
        runtime._append_outcome_memory(outcome)
    experience = runtime._append_outcome_experience(outcome) if capture_experience else None
    if apply_growth:
        runtime._append_outcome_growth(outcome, experience=experience)
    runtime._write_snapshot(
        profile=outcome.profile,
        session=outcome.session,
        goals=outcome.goals,
        memories=outcome.memories,
        plan=outcome.plan,
        execution=outcome.execution,
        delivery=outcome.delivery,
        stages=outcome.stages,
        event=outcome.event,
        clone_text=runtime._load_profile(outcome.profile.profile_id).clone_text,
    )
    return outcome


def wake(runtime: CliRuntime, session_id: str, *, inspect_only: bool = False, result_cls):
    session = runtime._load_session(session_id)
    goal_graph = runtime.repository.load_goal_graph(session_id)
    if goal_graph is None:
        raise KeyError(session_id)
    profile = runtime._load_profile(session.profile_id)
    memories = runtime._planning_memories(session, goal_graph)
    service = PlanningService()
    decision, planned_goal_graph = service.wake_next_step(
        session=session,
        graph=goal_graph,
        memories=memories,
        initiative_hint=profile.her_mode.initiative if profile.her_mode is not None else None,
        continuity_notes=profile.her_mode.notes if profile.her_mode is not None else (),
    )
    plan = build_plan_draft_from_decision(decision)
    if not inspect_only:
        runtime.repository.upsert_goal_graph(planned_goal_graph)
        runtime._write_snapshot(
            profile=profile.state,
            session=session,
            goals=tuple(node.to_contract_goal() for node in planned_goal_graph.nodes),
            memories=memories,
            plan=plan,
            execution=None,
            delivery=None,
            stages=(),
            event=service.emit_rationale(decision),
            clone_text=profile.clone_text,
        )
    return result_cls(
        profile=profile.state,
        session=session,
        decision=decision,
        planned_goal_graph=planned_goal_graph,
        applied=not inspect_only,
        plan=plan,
    )


def build_kernel_dependencies(
    runtime: CliRuntime,
    session: SessionState,
    profile: ProfileState,
    *,
    memory_capability_cls,
    context_capability_cls,
    telemetry_cls,
    delivery_capability_cls,
) -> KernelDependencies:
    memory = memory_capability_cls(memory_runtime=runtime.memory_runtime, repository=runtime.repository)
    return KernelDependencies(
        storage=runtime.repository,
        context=context_capability_cls(
            profile_loader=runtime.profile_loader,
            repository=runtime.repository,
            prompt_mode="full",
            snapshot_path=runtime.snapshot_path,
            total_tokens=runtime.active_provider_context_window(),
            tool_runtime=runtime.tool_runtime,
            skill_runtime=runtime.skill_runtime,
        ),
        planning=PlanningService(),
        memory=memory,
        model_provider=runtime.model_provider,
        telemetry=telemetry_cls(runtime.snapshot_path),
        tools=runtime.tool_runtime,
        delivery=delivery_capability_cls(),
    )
