from __future__ import annotations

import argparse
from dataclasses import dataclass
import random
import re
import sys
from collections.abc import Iterable
from pathlib import Path

from packages.profile import DEFAULT_CLONE_TEXT, render_clone_charter

from .runtime import CliRuntime
from .provider_flow import (
    ProviderSelectionState,
    provider_choices as _shared_provider_choices,
    provider_setup_defaults,
    run_provider_selection_wizard,
)
from .shell import (
    Align,
    BRAND_ACCENT,
    BRAND_LIGHT,
    BRAND_MUTED,
    Console,
    Group,
    Panel,
    ProductizedShell,
    RICH_AVAILABLE,
    Table,
    Text,
    _resolve_aegis_version,
    render_guardian_mark,
)
from .wizard import (
    WIZARD_BACK,
    WizardChoice,
    _WizardBackSignal,
    _interactive_shell_supported,
    _wizard_choice_prompt,
    _wizard_dialogs_supported,
    _wizard_text_prompt,
)

DEFAULT_PROVIDER_ID = "openai-compatible"
PERSONALITY_PRESET_EMOJIS = {
    "core": "🪨",
    "companion": "🤝",
    "operator": "🛠️",
}
INITIATIVE_EMOJIS = {
    "gentle": "🌿",
    "proactive": "⚡",
}
PROVIDER_EMOJIS = {
    "openai": "🤖",
    "anthropic": "🧭",
    "openrouter": "🌐",
    "openai-compatible": "🔌",
    "google": "🔎",
    "groq": "⚡",
    "deepseek": "🔍",
    "xai": "🚀",
    "mistral": "🌬️",
    "together": "🤝",
    "fireworks": "🎆",
    "moonshot": "🌙",
    "minimax": "🎭",
    "ollama": "🦙",
    "vllm": "🧠",
}
DEFAULT_CLONE_NAME_SUGGESTIONS = (
    "Ada",
    "Asher",
    "Avery",
    "Caleb",
    "Chloe",
    "Eden",
    "Eli",
    "Eliza",
    "Felix",
    "Hazel",
    "Iris",
    "Jasper",
    "Julian",
    "Leah",
    "Lena",
    "Leo",
    "Maya",
    "Miles",
    "Milo",
    "Nina",
    "Nora",
    "Owen",
    "Ruby",
    "Rowan",
    "Simon",
    "Silas",
    "Theo",
    "Vera",
    "Zoe",
)


@dataclass(frozen=True, slots=True)
class CliCardSection:
    title: str
    lines: tuple[str, ...] = ()


class _WizardCancelledError(Exception):
    __slots__ = ("surface",)

    def __init__(self, surface: str) -> None:
        super().__init__(surface)
        self.surface = surface


@dataclass(slots=True)
class BirthWizardState:
    display_name: str
    initial_goal: str
    personality_preset: str
    initiative: str
    provider_id: str
    base_url: str
    default_model: str
    api_key: str | None
    context_window_mode: str
    context_window_tokens: int | None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="aegis",
        description="Aegis CLI with explicit born, clone, clones, health, and grow entrypoints.",
    )
    parser.add_argument("--state-dir", required=True, type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--profile-dir", required=True, type=Path, help=argparse.SUPPRESS)

    subparsers = parser.add_subparsers(dest="command")

    born = subparsers.add_parser(
        "born",
        help="Run the first-time onboard and persist identity, CLONE charter, and provider readiness.",
    )
    born.add_argument("--provider-id", default=DEFAULT_PROVIDER_ID)
    born.add_argument("--display-name", default=None)
    born.add_argument("--personality-preset", default=None)
    born.add_argument("--initiative", default=None)
    born.add_argument("--clone-text", default=None)
    born.add_argument("--clone-name", default=None)
    born.add_argument("--initial-goal", default=None)
    born.add_argument("--base-url", default=None)
    born.add_argument("--default-model", default=None)
    born.add_argument("--api-key", default=None)
    born.add_argument("--context-window-mode", default=None)
    born.add_argument("--context-window", default=None)
    born.add_argument("--non-interactive", action="store_true")

    subparsers.add_parser(
        "health",
        help="Review provider, voice, and security readiness before opening the grow surface.",
    )

    clone = subparsers.add_parser(
        "clone",
        help="Clone a fresh Aegis individual and optionally enter it immediately.",
    )
    clone.add_argument("clone_name", nargs="?", help="Name the new Aegis clone.")
    clone.add_argument("--profile-id", default=None)
    clone.add_argument("--display-name", default=None)
    clone.add_argument("--initial-goal", default=None, help="Seed the clone with its first durable goal.")
    clone.add_argument("--debug", action="store_true", help="Show runtime diagnostics inside the grow surface.")
    clone.add_argument("--message", default=None, help="Create the clone, run one turn, and exit.")

    clones = subparsers.add_parser(
        "clones",
        help="Inspect or retire existing Aegis clones.",
    )
    clones_subparsers = clones.add_subparsers(dest="clones_command")
    bye = clones_subparsers.add_parser(
        "bye",
        help="Retire one named clone or clear every clone.",
    )
    bye.add_argument("clone_id", nargs="?", help="Name the Aegis clone to retire.")
    bye.add_argument("--all", action="store_true", dest="delete_all", help="Retire every clone.")

    grow = subparsers.add_parser(
        "grow",
        help="Enter an existing Aegis clone through the branded TUI or run one provider-backed turn.",
    )
    grow.add_argument("--session-id", default=None, help="Open a known session directly.")
    grow.add_argument("--clone-id", default=None, help="Open the latest session for a known clone.")
    grow.add_argument("--debug", action="store_true", help="Show runtime diagnostics inside the grow surface.")
    grow.add_argument("--message", default=None, help="Run one grow turn and exit.")
    grow.add_argument(
        "--voice-input-file",
        default=None,
        type=Path,
        help="Run one provider-backed voice turn from an audio file and exit.",
    )
    grow.add_argument(
        "--voice-output-file",
        default=None,
        type=Path,
        help="Write one synthesized voice reply when voice output is enabled.",
    )
    grow.add_argument("--voice-input-model", default="gpt-4o-mini-transcribe")
    grow.add_argument("--voice-output-model", default="gpt-4o-mini-tts")
    grow.add_argument("--voice-name", default="alloy")

    return parser


def _print_heading(title: str, detail: str | None = None) -> None:
    print(title)
    if detail:
        print(f"  {detail}")


def _print_field(label: str, value: object) -> None:
    rendered = ""
    if value is not None:
        rendered = str(value)
    print(f"  {label}: {rendered}")


def _print_bullet(text: str) -> None:
    print(f"  - {text}")


def _print_command_hints(*commands: str) -> None:
    if not commands:
        return
    print("  next_commands:")
    for command in commands:
        _print_bullet(command)


def _print_cli_card(
    title: str,
    detail: str | None = None,
    *,
    sections: tuple[CliCardSection, ...] = (),
    next_commands: tuple[str, ...] = (),
) -> None:
    if RICH_AVAILABLE and Panel is not None and Group is not None:
        console = Console(highlight=False, soft_wrap=True)
        blocks: list[Text] = []
        header = Text()
        if detail:
            header.append(f"{detail}", style=BRAND_MUTED)
            blocks.append(header)
        for section in sections:
            if blocks:
                blocks.append(Text(" "))
            section_text = Text()
            section_text.append(f"{section.title}\n", style=f"bold {BRAND_ACCENT}")
            for line in section.lines:
                section_text.append(f"• {line}\n", style=BRAND_LIGHT)
            blocks.append(section_text)
        if next_commands:
            if blocks:
                blocks.append(Text(" "))
            command_text = Text()
            command_text.append("Next\n", style=f"bold {BRAND_ACCENT}")
            for command in next_commands:
                command_text.append(f"• {command}\n", style=BRAND_LIGHT)
            blocks.append(command_text)
        console.print(
            Panel(
                Group(*blocks) if blocks else Text(""),
                title=f"[bold {BRAND_ACCENT}] {title} [/bold {BRAND_ACCENT}]",
                subtitle=f"[bold {BRAND_LIGHT}]Your own persistent AI agent, growing with you.[/bold {BRAND_LIGHT}]",
                border_style=BRAND_ACCENT,
                padding=(1, 2),
            )
        )
        return

    _print_heading(title, detail)
    for section in sections:
        if section.title:
            print(f"  {section.title}:")
        for line in section.lines:
            _print_bullet(line)
    _print_command_hints(*next_commands)


def _slugify_clone_name(value: str) -> str:
    collapsed = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower()).strip("-")
    return collapsed or "aegis"


def _display_name_from_clone_name(value: str) -> str:
    collapsed = re.sub(r"[^a-zA-Z0-9]+", " ", value.strip()).strip()
    return collapsed.title() or "Aegis"


def _suggest_clone_name(runtime: CliRuntime | None = None) -> str:
    candidates = DEFAULT_CLONE_NAME_SUGGESTIONS
    if runtime is None:
        return random.choice(candidates)
    available = tuple(
        name
        for name in candidates
        if runtime.latest_session_for_clone(_slugify_clone_name(name)) is None
    )
    return random.choice(available or candidates)


def _unique_clone_name(runtime: CliRuntime, desired_name: str) -> str:
    base = _slugify_clone_name(desired_name)
    candidate = base
    index = 2
    while runtime.latest_session_for_clone(candidate) is not None:
        candidate = f"{base}-{index}"
        index += 1
    return candidate


def _provider_choices(runtime: CliRuntime) -> tuple[WizardChoice, ...]:
    return _shared_provider_choices(runtime)


def _personality_choices(runtime: CliRuntime) -> tuple[WizardChoice, ...]:
    return tuple(
        WizardChoice(
            value=preset.preset_id,
            label=preset.label,
            detail=preset.summary,
            emoji=PERSONALITY_PRESET_EMOJIS.get(preset.preset_id, "✨"),
        )
        for preset in runtime.personality_presets()
        if preset.preset_id != "custom"
    )


def _initiative_choices() -> tuple[WizardChoice, ...]:
    return (
        WizardChoice(
            value="gentle",
            label="Gentle Presence",
            detail="Waits for you first and keeps the thread calm, warm, and steady.",
            emoji=INITIATIVE_EMOJIS["gentle"],
        ),
        WizardChoice(
            value="proactive",
            label="Proactive Presence",
            detail="Surfaces the next durable step before the thread drifts too far.",
            emoji=INITIATIVE_EMOJIS["proactive"],
        ),
    )


def _prompt_initial_goal(
    display_name: str,
    *,
    existing: str | None = None,
    allow_back: bool = False,
) -> str | _WizardBackSignal:
    prompt = (
        f"What first goal should {display_name} carry when grow opens? "
        "This first durable goal is required before the thread begins."
    )
    current_value = (existing or "").strip()
    while True:
        answer = _wizard_text_prompt(
            "Seed Its First Goal",
            prompt,
            default=current_value,
            allow_back=allow_back,
        )
        if answer is WIZARD_BACK:
            return WIZARD_BACK
        current_value = str(answer).strip()
        if current_value:
            return current_value
        prompt = (
            f"What first goal should {display_name} carry when grow opens? "
            "Add one durable goal before continuing."
        )


def _default_personality_preset(runtime: CliRuntime, *, mode: str, current: str | None = None) -> str | None:
    if mode != "her":
        return None
    if current:
        return current
    for preset in runtime.personality_presets():
        if preset.preset_id == "companion":
            return preset.preset_id
    return runtime.personality_presets()[0].preset_id


def _print_birth_wizard_intro() -> None:
    if not RICH_AVAILABLE or Table is None or Panel is None or Group is None:
        _print_heading("Aegis born", "Let's bring your first Aegis to life.")
        _print_bullet("name the Aegis that will stay with your thread")
        _print_bullet("choose how it should naturally show up for you")
        _print_bullet("bind the first model path it will think through")
        _print_bullet("step straight into aegis grow")
        return
    console = Console(highlight=False, soft_wrap=True)
    brand = Table.grid(expand=True)
    brand.add_column(no_wrap=True)
    hero = Text(justify="center")
    hero.append("Let's bring your first Aegis to life.\n", style=f"bold {BRAND_LIGHT}")
    hero.append("Name it, shape its vibe, bind its first mind, then step into grow.", style=BRAND_MUTED)
    flow = Text()
    flow.append("Birth flow\n", style=f"bold {BRAND_ACCENT}")
    flow.append("1 · Name your first Aegis\n", style=BRAND_LIGHT)
    flow.append("2 · Choose its presence\n", style=BRAND_LIGHT)
    flow.append("3 · Bind its first model path\n", style=BRAND_LIGHT)
    flow.append("4 · Hand off to aegis grow", style=BRAND_LIGHT)
    brand.add_row(_center_brand_block(hero))
    brand.add_row(Text(" "))
    brand.add_row(_center_brand_block(render_guardian_mark()))
    brand.add_row(Text(" "))
    layout = Table.grid(expand=True)
    console_width = getattr(console.size, "width", 0)
    if console_width and console_width < 132:
        layout.add_column(ratio=1, min_width=48)
        layout.add_row(brand)
        layout.add_row(Text(" "))
        layout.add_row(flow)
    else:
        layout.add_column(ratio=11, min_width=44)
        layout.add_column(ratio=13, min_width=48)
        layout.add_row(brand, flow)
    console.print(
        Panel(
            layout,
            title=f"[bold {BRAND_ACCENT}] Aegis Born v{_resolve_aegis_version()} [/bold {BRAND_ACCENT}]",
            subtitle=f"[bold {BRAND_LIGHT}]Your own persistent AI agent, growing with you.[/bold {BRAND_LIGHT}]",
            border_style=BRAND_ACCENT,
            padding=(1, 2),
        )
    )


def _prompt_first_clone_name(default_name: str, *, allow_back: bool = False) -> str | _WizardBackSignal:
    return _wizard_text_prompt(
        "Name Your First Aegis",
        "This first Aegis is yours. What name feels right?",
        default=default_name,
        allow_back=allow_back,
    )


def _run_interactive_clone_wizard(
    runtime: CliRuntime,
    *,
    clone_name: str | None,
    initial_goal: str,
) -> tuple[str, str] | None:
    current_clone_name = clone_name or _suggest_clone_name(runtime)
    prompt_name = clone_name is None
    while True:
        if prompt_name:
            answer = _wizard_text_prompt(
                "Name Another Aegis",
                "What should this new Aegis be called?",
                default=current_clone_name,
                allow_back=True,
            )
            if answer is WIZARD_BACK:
                return None
            current_clone_name = str(answer).strip() or current_clone_name
        answered_goal = _prompt_initial_goal(
            _display_name_from_clone_name(current_clone_name),
            existing=initial_goal,
            allow_back=True,
        )
        if answered_goal is WIZARD_BACK:
            if prompt_name:
                continue
            return None
        return current_clone_name, str(answered_goal).strip()


def _run_interactive_birth_wizard(
    runtime: CliRuntime,
    *,
    display_name: str,
    initial_goal: str,
    personality_preset: str,
    initiative: str,
    provider_state: ProviderSelectionState,
) -> BirthWizardState | None:
    state = BirthWizardState(
        display_name=display_name,
        initial_goal=initial_goal,
        personality_preset=personality_preset,
        initiative=initiative,
        provider_id=provider_state.provider_id,
        base_url=provider_state.base_url,
        default_model=provider_state.default_model,
        api_key=provider_state.api_key,
        context_window_mode=provider_state.context_window_mode,
        context_window_tokens=provider_state.context_window_tokens,
    )
    steps = (
        "display_name",
        "initial_goal",
        "personality_preset",
        "initiative",
        "provider_setup",
    )
    step_index = 0
    while step_index < len(steps):
        step = steps[step_index]
        if step == "display_name":
            answer = _prompt_first_clone_name(state.display_name, allow_back=True)
            if answer is WIZARD_BACK:
                return None
            state.display_name = str(answer).strip() or state.display_name
            step_index += 1
            continue
        if step == "initial_goal":
            answer = _prompt_initial_goal(state.display_name, existing=state.initial_goal, allow_back=True)
            if answer is WIZARD_BACK:
                step_index -= 1
                continue
            state.initial_goal = str(answer).strip()
            step_index += 1
            continue
        if step == "personality_preset":
            answer = _wizard_choice_prompt(
                "Choose Its Presence",
                f"When {state.display_name} first speaks, how should it naturally feel?",
                _personality_choices(runtime),
                default=state.personality_preset,
                allow_back=True,
            )
            if answer is WIZARD_BACK:
                step_index -= 1
                continue
            state.personality_preset = str(answer)
            step_index += 1
            continue
        if step == "initiative":
            answer = _wizard_choice_prompt(
                "Choose Its Initiative",
                f"When the thread goes quiet, how should {state.display_name} stay with you?",
                _initiative_choices(),
                default=state.initiative,
                allow_back=True,
            )
            if answer is WIZARD_BACK:
                step_index -= 1
                continue
            state.initiative = str(answer)
            step_index += 1
            continue
        if step == "provider_setup":
            answer = run_provider_selection_wizard(
                runtime,
                initial_state=ProviderSelectionState(
                    provider_id=state.provider_id,
                    base_url=state.base_url,
                    api_key=state.api_key,
                    default_model=state.default_model,
                    context_window_mode=state.context_window_mode,
                    context_window_tokens=state.context_window_tokens,
                ),
                allow_back=True,
            )
            if answer is WIZARD_BACK:
                step_index -= 1
                continue
            state.provider_id = answer.provider_id
            state.base_url = answer.base_url
            state.api_key = answer.api_key
            state.default_model = answer.default_model
            state.context_window_mode = answer.context_window_mode
            state.context_window_tokens = answer.context_window_tokens
            step_index += 1
            continue
    return state


def _print_birth_paused() -> None:
    _print_cli_card(
        "Aegis birth paused",
        "No new identity or provider changes were written.",
        next_commands=("aegis born", "aegis health"),
    )


def _print_overview(runtime: CliRuntime) -> None:
    provider = dict(runtime.provider_summary())
    doctor = runtime.provider_doctor()
    clones = runtime.list_clones(limit=5)
    if RICH_AVAILABLE and Table is not None and Panel is not None and Group is not None:
        console = Console(highlight=False, soft_wrap=True)
        brand = Table.grid(expand=True)
        brand.add_column(no_wrap=True)
        headline = Text(no_wrap=True)
        headline.append("Welcome back !\n", style=f"bold {BRAND_LIGHT}")
        headline.append("Your own persistent AI agent, growing with you.", style=BRAND_MUTED)
        capability = Text("persistent memory · long-horizon decisions · long context", style=BRAND_MUTED)
        action_lines = Text()
        action_lines.append("Start here\n", style=f"bold {BRAND_ACCENT}")
        action_lines.append("aegis born  · name your first Aegis, shape its clone charter, and hatch it\n", style=BRAND_LIGHT)
        action_lines.append("aegis grow · re-enter the live Aegis clone that already knows the thread\n", style=BRAND_LIGHT)
        action_lines.append("aegis clone <name> · create another Aegis individual when you need one\n", style=BRAND_LIGHT)
        action_lines.append("aegis clones · inspect or retire named clones\n", style=BRAND_LIGHT)
        action_lines.append("aegis health · inspect provider, voice, and security readiness\n", style=BRAND_LIGHT)
        action_lines.append("\nCurrent posture\n", style=f"bold {BRAND_ACCENT}")
        action_lines.append(f"health · {doctor['status']}\n", style=BRAND_MUTED if doctor["status"] != "ready" else BRAND_LIGHT)
        action_lines.append(f"provider · {provider['provider_id']}\n", style=BRAND_MUTED)
        if clones:
            action_lines.append("clones · " + ", ".join(clone.clone_id for clone in clones), style=BRAND_MUTED)
        else:
            action_lines.append("clones · none yet", style=BRAND_MUTED)
        brand.add_row(_center_brand_block(headline))
        brand.add_row(Text(" "))
        brand.add_row(_center_brand_block(render_guardian_mark()))
        brand.add_row(Text(" "))
        brand.add_row(_center_brand_block(capability))
        layout = Table.grid(expand=True)
        layout.add_column(ratio=11, min_width=46)
        layout.add_column(ratio=11, min_width=44)
        layout.add_row(brand, action_lines)
        console.print(
            Panel(
                layout,
                title=f"[bold {BRAND_ACCENT}] Aegis v{_resolve_aegis_version()} [/bold {BRAND_ACCENT}]",
                subtitle=f"[bold {BRAND_LIGHT}]Your own persistent AI agent, growing with you.[/bold {BRAND_LIGHT}]",
                border_style=BRAND_ACCENT,
                padding=(1, 2),
            )
        )
        return

    _print_heading("Welcome back !", "Your own persistent AI agent, growing with you.")
    _print_bullet("persistent memory · long-horizon decisions · long context")
    _print_bullet("aegis born  - name your first Aegis, shape its clone charter, and hatch it")
    _print_bullet("aegis grow - enter the live Aegis clone that already holds the thread")
    _print_bullet("aegis clone <name> - create another Aegis individual when you need one")
    _print_bullet("aegis clones - inspect or retire clones")
    _print_bullet("aegis health - inspect provider, voice, and security readiness")
    _print_field("health", doctor["status"])
    _print_field("provider", provider["provider_id"])
    _print_field("clones", ", ".join(clone.clone_id for clone in clones) if clones else "none yet")


def _center_brand_block(renderable):
    if Align is None:
        return renderable
    return Align.center(renderable)


def _print_setup_intro(runtime: CliRuntime, *, provider_id: str) -> None:
    guide = runtime.provider_setup_guide(provider_id)
    loaded = runtime.current_profile()
    _print_cli_card(
        "Aegis born",
        "Bring your first Aegis to life and hand it off to grow.",
        sections=(
            CliCardSection(
                "Current shape",
                (
                    f"name · {loaded.state.display_name}",
                    f"provider · {guide.display_name}",
                    f"transport · {guide.transport_display_name}",
                ),
            ),
            CliCardSection(
                "Birth flow",
                (
                    "Give it a name and presence that feel like its own",
                    "Bind its first model path",
                    "Finish in aegis grow",
                ),
            ),
        ),
    )


def _default_born_args() -> argparse.Namespace:
    return argparse.Namespace(
        provider_id=DEFAULT_PROVIDER_ID,
        display_name=None,
        personality_preset=None,
        initiative=None,
        clone_text=None,
        clone_name=None,
        initial_goal=None,
        base_url=None,
        default_model=None,
        api_key=None,
        context_window_mode=None,
        context_window=None,
        non_interactive=False,
    )


def _default_grow_args() -> argparse.Namespace:
    return argparse.Namespace(
        session_id=None,
        clone_id=None,
        debug=False,
        message=None,
        voice_input_file=None,
        voice_output_file=None,
        voice_input_model="gpt-4o-mini-transcribe",
        voice_output_model="gpt-4o-mini-tts",
        voice_name="alloy",
    )


def _ensure_clone_ready(
    runtime: CliRuntime,
    *,
    clone_name: str,
    display_name: str,
    profile_id: str,
    initial_goal: str | None = None,
) -> tuple[object, str]:
    existing = runtime.latest_session_for_clone(clone_name)
    if existing is not None:
        runtime.seed_initial_goal(existing.session_id, initial_goal or "")
        return existing, "existing"
    session = runtime.create_clone(
        clone_id=clone_name,
        profile_id=profile_id,
        display_name=display_name,
        mode="her",
        initial_goal=initial_goal,
    )
    return session, "created"


def _run_setup(runtime: CliRuntime, args: argparse.Namespace) -> int:
    provider_id = args.provider_id
    loaded = runtime.current_profile()
    provider_state = provider_setup_defaults(runtime, provider_id)
    initial_clone_name = args.clone_name
    initial_goal = (args.initial_goal or "").strip()
    if args.display_name is not None:
        display_name = args.display_name
    elif initial_clone_name:
        display_name = _display_name_from_clone_name(initial_clone_name)
    else:
        display_name = _suggest_clone_name(runtime)
    mode = "her"
    personality_preset = _default_personality_preset(
        runtime,
        mode=mode,
        current=args.personality_preset or (loaded.her_mode.personality_preset if loaded.her_mode is not None else None),
    )
    initiative = args.initiative or (loaded.her_mode.initiative if loaded.her_mode is not None else "gentle")
    requested_clone_text = args.clone_text
    provider_state.base_url = args.base_url or provider_state.base_url
    provider_state.default_model = args.default_model or provider_state.default_model
    provider_state.api_key = args.api_key
    if args.context_window_mode is not None:
        provider_state.context_window_mode = args.context_window_mode
    if args.context_window is not None:
        provider_state.context_window_tokens = int(str(args.context_window).replace(",", ""))

    interactive_birth = _interactive_shell_supported() and not args.non_interactive
    if interactive_birth:
        _print_birth_wizard_intro()
        wizard_state = _run_interactive_birth_wizard(
            runtime,
            display_name=display_name,
            initial_goal=initial_goal,
            personality_preset=_default_personality_preset(runtime, mode=mode, current=personality_preset) or "companion",
            initiative=initiative,
            provider_state=provider_state,
        )
        if wizard_state is None:
            _print_birth_paused()
            return 0
        display_name = wizard_state.display_name
        initial_goal = wizard_state.initial_goal
        personality_preset = wizard_state.personality_preset
        initiative = wizard_state.initiative
        provider_id = wizard_state.provider_id
        provider_state = ProviderSelectionState(
            provider_id=wizard_state.provider_id,
            base_url=wizard_state.base_url,
            api_key=wizard_state.api_key,
            default_model=wizard_state.default_model,
            context_window_mode=wizard_state.context_window_mode,
            context_window_tokens=wizard_state.context_window_tokens,
        )
    else:
        _print_setup_intro(runtime, provider_id=provider_id)

    if not initial_goal:
        raise SystemExit("born requires an initial goal; rerun interactively or pass --initial-goal")

    base_url = provider_state.base_url
    default_model = provider_state.default_model
    api_key = provider_state.api_key
    context_window_mode = provider_state.context_window_mode or "auto"
    context_window_tokens = provider_state.context_window_tokens

    if not base_url or not default_model:
        raise SystemExit("born requires a provider base URL and default model")
    if context_window_tokens is None and default_model:
        context_window_tokens = runtime.detect_provider_context_window(
            provider_id=provider_id,
            model_id=default_model,
            base_url=base_url,
            api_key=api_key,
        )
    if context_window_tokens is None:
        context_window_tokens = 128_000
    guide = runtime.provider_setup_guide(provider_id)
    provider_summary = dict(runtime.provider_summary())
    has_stored_secret = (
        provider_summary.get("provider_id") == provider_id
        and provider_summary.get("secret_status") == "stored"
    )
    if guide.required_secret_keys and not api_key and not has_stored_secret:
        raise SystemExit("born requires a provider API key; rerun interactively or pass --api-key")

    updated_identity = runtime.update_identity(
        display_name=display_name,
        mode=mode,
    )
    updated_identity = runtime.update_her_mode(
        profile_id=updated_identity.state.profile_id,
        initiative=initiative,
        personality_preset=personality_preset,
    )
    clone_text = (
        requested_clone_text.strip()
        if requested_clone_text is not None and requested_clone_text.strip()
        else render_clone_charter(
            display_name=updated_identity.state.display_name,
            personality_preset=personality_preset,
            initiative=initiative,
            mode=updated_identity.state.mode,
        )
    )
    updated_identity = runtime.update_clone_text(
        profile_id=updated_identity.state.profile_id,
        clone_text=(clone_text or DEFAULT_CLONE_TEXT).strip(),
    )

    configured = runtime.set_default_provider(
        provider_id=provider_id,
        profile_id=updated_identity.state.profile_id,
        display_name=updated_identity.state.display_name,
        mode=updated_identity.state.mode,
        base_url=base_url,
        default_model=default_model,
        api_key=api_key,
        context_window_tokens=context_window_tokens,
        context_window_mode=context_window_mode,
    )

    report = runtime.provider_doctor()
    provider = report["provider"]
    clone_name = _unique_clone_name(runtime, initial_clone_name or display_name)
    first_clone, first_clone_status = _ensure_clone_ready(
        runtime,
        clone_name=clone_name,
        display_name=display_name,
        profile_id=configured.state.profile_id,
        initial_goal=initial_goal,
    )
    readiness_lines = [
        f"clone · {runtime.clone_id_for_session(first_clone)}",
        f"status · {first_clone_status}",
        f"provider · {provider['display_name'] if 'display_name' in provider else provider['provider_id']}",
        f"model · {provider['default_model'] or '<unset>'}",
        f"context · {provider.get('context_window_tokens') or '<unset>'}",
        f"health · {report['status']}",
    ]
    if configured.her_mode is not None:
        readiness_lines.extend(
            [
                f"presence · {configured.her_mode.personality_preset}",
                f"initiative · {configured.her_mode.initiative}",
            ]
        )
    if initial_goal:
        readiness_lines.append(f"initial_goal · {initial_goal}")
    if interactive_birth and report["status"] == "ready":
        runtime.prepare_session_surface(first_clone.session_id)
        return ProductizedShell(runtime, session_id=first_clone.session_id, opened="Born new").run()
    _print_cli_card(
        "Aegis is born",
        f"{display_name} is ready.",
        sections=(
            CliCardSection("Ready now", tuple(readiness_lines)),
        ),
        next_commands=("aegis grow", "aegis clone <name>", "aegis clones")
        if report["status"] == "ready"
        else ("aegis health", "aegis born"),
    )
    return 0


def _print_doctor(runtime: CliRuntime) -> None:
    provider = runtime.provider_doctor()
    voice = runtime.voice_doctor()
    security = runtime.security_doctor()
    clones = runtime.list_clones(limit=5)
    active = provider["provider"]
    status_lines = (
        f"provider_status · {provider['status']}",
        f"voice_status · {voice['status']}",
        f"security_status · {security['status']}",
        f"active_provider_id · {active['provider_id']}",
        f"active_provider_source · {active['source']}",
        f"active_provider_model_id · {active['default_model'] or '<unset>'}",
    )
    provider_checks = tuple(
        f"{check['check']} · {check['status']}{f' · {check['summary']}' if check.get('summary') else ''}"
        for check in provider["checks"]
    )
    voice_checks = tuple(
        f"{check['check']} · {check['status']}{f' · {check['summary']}' if check.get('summary') else ''}"
        for check in voice["checks"]
    )
    security_checks = tuple(
        f"{check['check']} · {check['status']}{f' · {check['summary']}' if check.get('summary') else ''}"
        for check in security["checks"]
    )
    voice_identity_lines = tuple(
        line
        for line in (
            f"voice_supported_path · {voice['supported_path']}" if voice.get("supported_path") else "",
            f"voice_identity_binding · {voice['identity_binding']}" if voice.get("identity_binding") else "",
            f"voice_identity_summary · {voice['voice_identity_summary']}" if voice.get("voice_identity_summary") else "",
        )
        if line
    )
    extra_lines = (
        (f"probe_summary · {provider['probe_summary']}",) if provider["probe_summary"] else ()
    )
    sections = [CliCardSection("Readiness", status_lines)]
    if provider_checks:
        sections.append(CliCardSection("Provider checks", provider_checks))
    if voice_checks:
        sections.append(CliCardSection("Voice checks", voice_checks))
    if voice_identity_lines:
        sections.append(CliCardSection("Voice identity", voice_identity_lines))
    if security_checks:
        sections.append(CliCardSection("Security checks", security_checks))
    if extra_lines:
        sections.append(CliCardSection("Probe", extra_lines))
    _print_cli_card(
        "Aegis health",
        "Readiness before the grow surface opens.",
        sections=tuple(sections),
        next_commands=("aegis grow", "aegis clone <name>", "aegis clones")
        if provider["status"] == "ready" and clones
        else ("aegis clone <name>", "aegis grow", "aegis clones")
        if provider["status"] == "ready"
        else ("aegis born",),
    )


def _print_clone_created(runtime: CliRuntime, session_id: str) -> None:
    session = runtime.inspect_session(session_id)
    clone_id = runtime.clone_id_for_session(session)
    goals = runtime.inspect_goals(session_id)
    ready_lines = [
        f"clone_id · {clone_id}",
        f"session_id · {session.session_id}",
        f"profile_id · {session.profile_id}",
        f"status · {session.status}",
    ]
    if goals:
        ready_lines.append(f"active_goal · {goals[0].title}")
    _print_cli_card(
        "Aegis clone",
        "A new Aegis individual is ready.",
        sections=(
            CliCardSection(
                "Ready now",
                tuple(ready_lines),
            ),
        ),
        next_commands=("aegis grow", f"aegis grow --clone-id {clone_id}", "aegis clones"),
    )


def _print_clone_paused() -> None:
    _print_cli_card(
        "Aegis clone paused",
        "No new clone was created.",
        next_commands=("aegis clone <name>", "aegis grow", "aegis clones"),
    )


def _print_clones(runtime: CliRuntime) -> None:
    clones = runtime.list_clones(limit=24)
    if not clones:
        _print_cli_card(
            "Aegis clones",
            "Named Aegis individuals with their own continuity lines.",
            sections=(CliCardSection("Current state", ("No clones yet.",)),),
            next_commands=("aegis clone <name>",),
        )
        return
    clone_lines = tuple(
        f"{clone.clone_id} · latest {clone.latest_session_id[:8]} · {clone.session_count} session{'s' if clone.session_count != 1 else ''} · {clone.latest_status}"
        for clone in clones
    )
    _print_cli_card(
        "Aegis clones",
        "Named Aegis individuals with their own continuity lines.",
        sections=(CliCardSection("Available clones", clone_lines),),
        next_commands=("aegis grow", "aegis clone <name>", "aegis clones bye <name>", "aegis clones bye --all"),
    )


def _print_clone_retired(clone_id: str, deleted_sessions: int) -> None:
    _print_cli_card(
        "Clone retired",
        "A named Aegis continuity line has been cleared.",
        sections=(
            CliCardSection(
                "Retired now",
                (
                    f"clone_id · {clone_id}",
                    f"deleted_sessions · {deleted_sessions}",
                ),
            ),
        ),
        next_commands=("aegis clones", "aegis clone <name>", "aegis grow"),
    )


def _print_clone_retire_paused() -> None:
    _print_cli_card(
        "Clone retire paused",
        "No clone was cleared.",
        next_commands=("aegis clones", "aegis grow", "aegis clone <name>"),
    )


def _print_all_clones_retired(deleted_clones: int, deleted_sessions: int) -> None:
    _print_cli_card(
        "All clones retired",
        "Every named Aegis clone has been cleared.",
        sections=(
            CliCardSection(
                "Retired now",
                (
                    f"deleted_clones · {deleted_clones}",
                    f"deleted_sessions · {deleted_sessions}",
                ),
            ),
        ),
        next_commands=("aegis clone <name>", "aegis born", "aegis health"),
    )


def _prompt_clone_choice(runtime: CliRuntime, clones, *, intent: str = "enter") -> object:
    prompt = (
        "Multiple Aegis clones are available. Pick one before entering grow."
        if intent == "enter"
        else "Multiple Aegis clones are available. Pick one before clearing it."
    )
    if _wizard_dialogs_supported():
        default_clone = clones[0].clone_id
        choices = tuple(
            WizardChoice(
                value=clone.clone_id,
                label=f"{clone.clone_id} · {clone.session_count} session{'s' if clone.session_count != 1 else ''}",
                detail=f"latest continuity {clone.latest_session_id[:8]} · {clone.latest_status}",
            )
            for clone in clones
        )
        selected_id = _wizard_choice_prompt(
            "Choose clone",
            prompt,
            choices,
            default=default_clone,
            allow_back=True,
        )
        if selected_id is WIZARD_BACK:
            return WIZARD_BACK
        for clone in clones:
            if clone.clone_id == selected_id:
                return clone
    _print_cli_card(
        "Choose clone",
        prompt,
        sections=(
            CliCardSection(
                "Available clones",
                tuple(
                    f"{index}. {clone.clone_id} · latest {clone.latest_session_id[:8]} · {clone.session_count} session{'s' if clone.session_count != 1 else ''} · {clone.latest_status}"
                    for index, clone in enumerate(clones, start=1)
                ),
            ),
        ),
    )
    while True:
        answer = input("clone: ").strip()
        if answer.isdigit():
            index = int(answer)
            if 1 <= index <= len(clones):
                return clones[index - 1]
        for clone in clones:
            if clone.clone_id == answer:
                return clone
        print("  enter a clone number or clone id from the list above")


def _resolve_growth_session(
    runtime: CliRuntime,
    *,
    session_id: str | None = None,
    clone_id: str | None = None,
) -> tuple[str, str]:
    if session_id is not None:
        return runtime.inspect_session(session_id).session_id, "Opened existing"
    if clone_id is not None:
        selected = runtime.latest_session_for_clone(clone_id)
        if selected is None:
            raise ValueError(f"unknown clone: {clone_id}")
        return selected.session_id, f"Opened clone {clone_id}"
    clones = runtime.list_clones(limit=16)
    if not clones:
        raise LookupError("no-clones")
    if len(clones) == 1:
        return clones[0].latest_session_id, f"Opened clone {clones[0].clone_id}"
    if _interactive_shell_supported():
        selected = _prompt_clone_choice(runtime, clones)
        if selected is WIZARD_BACK:
            raise _WizardCancelledError("grow")
        return selected.latest_session_id, f"Opened clone {selected.clone_id}"
    raise ValueError("multiple clones are available; pass --clone-id or enter grow from an interactive TTY")


def _print_clone_blocked(runtime: CliRuntime) -> None:
    report = runtime.provider_doctor()
    provider = report["provider"]
    checks = tuple(
        f"{check['check']} · {check['status']}{f' · {check['summary']}' if check.get('summary') else ''}"
        for check in report["checks"]
    )
    sections = [
        CliCardSection(
            "Current readiness",
            (
                f"provider_status · {report['status']}",
                f"active_provider_id · {provider['provider_id']}",
                f"active_provider_source · {provider['source']}",
            ),
        )
    ]
    if checks:
        sections.append(CliCardSection("Provider checks", checks))
    _print_cli_card(
        "Clone blocked",
        "Finish birth before hatching another Aegis.",
        sections=tuple(sections),
        next_commands=("aegis born", "aegis health"),
    )


def _print_grow_blocked(runtime: CliRuntime) -> None:
    report = runtime.provider_doctor()
    provider = report["provider"]
    checks = tuple(
        f"{check['check']} · {check['status']}{f' · {check['summary']}' if check.get('summary') else ''}"
        for check in report["checks"]
    )
    sections = [
        CliCardSection(
            "Current readiness",
            (
                f"provider_status · {report['status']}",
                f"active_provider_id · {provider['provider_id']}",
                f"active_provider_source · {provider['source']}",
            ),
        )
    ]
    if checks:
        sections.append(CliCardSection("Provider checks", checks))
    _print_cli_card(
        "Grow blocked",
        "Finish birth and health checks before entering the grow surface.",
        sections=tuple(sections),
        next_commands=("aegis born", "aegis health"),
    )


def _print_no_clones() -> None:
    _print_cli_card(
        "No clones yet",
        "Create an Aegis clone before entering the grow surface.",
        next_commands=("aegis clone <name>", "aegis health"),
    )


def _run_clone(runtime: CliRuntime, args: argparse.Namespace) -> int:
    if runtime.provider_doctor()["status"] != "ready":
        _print_clone_blocked(runtime)
        return 1
    raw_clone_name = args.clone_name
    initial_goal = (args.initial_goal or "").strip()
    interactive_shell = _interactive_shell_supported()
    if raw_clone_name is None and not interactive_shell:
        _print_heading("Name needed", "Run aegis clone <name>, or rerun in a TTY and Aegis will ask you.")
        _print_command_hints("aegis clone <name>", "aegis grow", "aegis clones")
        return 1
    if interactive_shell and (raw_clone_name is None or not initial_goal):
        _print_heading("Aegis clone", "Let's bring another Aegis individual online.")
        wizard_state = _run_interactive_clone_wizard(
            runtime,
            clone_name=raw_clone_name,
            initial_goal=initial_goal,
        )
        if wizard_state is None:
            _print_clone_paused()
            return 0
        raw_clone_name, initial_goal = wizard_state
    if not initial_goal:
        raise SystemExit("clone requires an initial goal; rerun in a TTY or pass --initial-goal")
    clone_id = _unique_clone_name(runtime, raw_clone_name)
    display_name = args.display_name or _display_name_from_clone_name(raw_clone_name)
    session = runtime.create_clone(
        clone_id=clone_id,
        profile_id=args.profile_id,
        display_name=display_name,
        mode="her",
        initial_goal=initial_goal,
    )
    runtime.prepare_session_surface(session.session_id)
    if args.message is not None:
        outcome = runtime.explain_next_step(session_id=session.session_id, prompt=args.message)
        _print_clone_created(runtime, session.session_id)
        _print_assistant_turn(runtime, outcome)
        return 0
    if _interactive_shell_supported():
        return ProductizedShell(runtime, session_id=session.session_id, opened="Cloned new", debug=args.debug).run()
    _print_clone_created(runtime, session.session_id)
    return 0


def _run_clones(runtime: CliRuntime, args: argparse.Namespace) -> int:
    if args.clones_command is None:
        _print_clones(runtime)
        return 0
    if args.clones_command != "bye":
        raise ValueError(f"unknown clones command: {args.clones_command}")
    if args.delete_all:
        if args.clone_id is not None:
            raise ValueError("aegis clones bye accepts either a clone name or --all")
        deleted_clones, deleted_sessions = runtime.delete_all_clones()
        _print_all_clones_retired(deleted_clones, deleted_sessions)
        return 0
    if args.clone_id is None:
        clones = runtime.list_clones(limit=16)
        if not clones:
            _print_no_clones()
            return 1
        if _interactive_shell_supported():
            selected = _prompt_clone_choice(runtime, clones, intent="retire")
            if selected is WIZARD_BACK:
                _print_clone_retire_paused()
                return 0
            clone_id = selected.clone_id
        else:
            raise ValueError("aegis clones bye requires <name> or --all")
    else:
        clone_id = args.clone_id
    deleted_sessions = runtime.delete_clone(clone_id)
    if deleted_sessions == 0:
        raise ValueError(f"unknown clone: {clone_id}")
    _print_clone_retired(clone_id, deleted_sessions)
    return 0


def _print_assistant_turn(runtime: CliRuntime, outcome, *, title: str = "Aegis turn") -> None:
    provider = dict(runtime.provider_summary())
    lines = [
        f"session_id · {outcome.session.session_id}",
        f"profile_id · {outcome.profile.profile_id}",
        f"provider_id · {provider['provider_id']}",
        f"provider_model_id · {provider['default_model'] or '<unset>'}",
        f"execution · {outcome.execution.summary}",
        f"goals_in_play · {len(outcome.goals)}",
        f"memory_hits · {len(outcome.memories)}",
    ]
    if outcome.plan is not None:
        lines.append(f"plan_rationale · {outcome.plan.rationale}")
    _print_cli_card(
        title,
        "One grow turn completed.",
        sections=(CliCardSection("Turn summary", tuple(lines)),),
    )


def _print_voice_turn(result, *, output_path: Path | None = None) -> None:
    lines = [
        f"voice_input_outcome · {result.input_resolution.outcome}",
        f"voice_input_summary · {result.input_resolution.summary}",
        f"voice_policy_decision · {result.voice_turn.policy_result.decision.value}",
    ]
    if result.voice_turn.output is not None:
        lines.append(f"voice_output_mode · {result.voice_turn.output.delivery_mode}")
        lines.append(f"voice_output_enabled · {result.voice_turn.output.voice_enabled}")
        if result.voice_turn.output.metadata.get("voice_identity_summary"):
            lines.append(
                f"voice_identity_summary · {result.voice_turn.output.metadata['voice_identity_summary']}"
            )
    if output_path is not None:
        lines.append(f"voice_output_file · {output_path}")
    _print_cli_card(
        "Voice turn",
        "Aegis completed one voice-first turn.",
        sections=(CliCardSection("Voice summary", tuple(lines)),),
    )


def _run_grow(runtime: CliRuntime, args: argparse.Namespace) -> int:
    if args.message is not None and args.voice_input_file is not None:
        raise ValueError("--message and --voice-input-file cannot be used together")
    if args.voice_output_file is not None and args.voice_input_file is None:
        raise ValueError("--voice-output-file requires --voice-input-file")
    if runtime.provider_doctor()["status"] != "ready":
        _print_grow_blocked(runtime)
        return 1

    try:
        session_id, opened = _resolve_growth_session(
            runtime,
            session_id=args.session_id,
            clone_id=args.clone_id,
        )
    except _WizardCancelledError:
        _print_cli_card(
            "Grow paused",
            "No clone was selected.",
            next_commands=("aegis grow", "aegis clones", "aegis clone <name>"),
        )
        return 0
    except LookupError:
        _print_no_clones()
        return 1
    runtime.prepare_session_surface(session_id)

    if args.voice_input_file is not None:
        audio_bytes = args.voice_input_file.read_bytes()
        result = runtime.run_voice_turn(
            session_id=session_id,
            audio_bytes=audio_bytes,
            audio_name=args.voice_input_file.name,
            audio_format=args.voice_input_file.suffix.lstrip(".") or None,
            voice_output_enabled=args.voice_output_file is not None,
            input_model_id=args.voice_input_model,
            output_model_id=args.voice_output_model,
            voice_name=args.voice_name,
            output_audio_format=(args.voice_output_file.suffix.lstrip(".") or "mp3")
            if args.voice_output_file is not None
            else "mp3",
        )
        if args.voice_output_file is not None and result.voice_turn.output is not None and result.voice_turn.output.audio_bytes is not None:
            args.voice_output_file.parent.mkdir(parents=True, exist_ok=True)
            args.voice_output_file.write_bytes(result.voice_turn.output.audio_bytes)
        _print_voice_turn(result, output_path=args.voice_output_file)
        if result.kernel_outcome is not None:
            _print_assistant_turn(runtime, result.kernel_outcome)
            return 0
        return 1

    if args.message is not None:
        outcome = runtime.explain_next_step(session_id=session_id, prompt=args.message)
        _print_assistant_turn(runtime, outcome)
        return 0

    if _interactive_shell_supported():
        return ProductizedShell(runtime, session_id=session_id, opened=opened, debug=args.debug).run()
    return _run_stream_grow_loop(runtime, session_id, sys.stdin)


def _run_stream_grow_loop(runtime: CliRuntime, session_id: str, stream: Iterable[str]) -> int:
    for line in stream:
        prompt = line.rstrip("\n").strip()
        if not prompt:
            continue
        outcome = runtime.explain_next_step(session_id=session_id, prompt=prompt)
        _print_assistant_turn(runtime, outcome)
    return 0


def _run_default_entry(runtime: CliRuntime) -> int:
    if not _interactive_shell_supported():
        _print_overview(runtime)
        return 0
    if runtime.list_clones(limit=16):
        return _run_grow(runtime, _default_grow_args())
    return _run_setup(runtime, _default_born_args())


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    runtime = CliRuntime.create(state_dir=args.state_dir, profile_dir=args.profile_dir)

    if args.command is None:
        return _run_default_entry(runtime)
    if args.command == "born":
        return _run_setup(runtime, args)
    if args.command == "health":
        _print_doctor(runtime)
        return 0
    if args.command == "clone":
        try:
            return _run_clone(runtime, args)
        except ValueError as error:
            parser.error(str(error))
    if args.command == "clones":
        try:
            return _run_clones(runtime, args)
        except ValueError as error:
            parser.error(str(error))
    if args.command == "grow":
        try:
            return _run_grow(runtime, args)
        except ValueError as error:
            parser.error(str(error))
    parser.error(f"unknown command: {args.command}")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
