from __future__ import annotations

from dataclasses import dataclass
import getpass
import os
import sys

from .shell_ui import BRAND_ACCENT, BRAND_ACCENT_STRONG, BRAND_LIGHT, BRAND_MUTED

try:
    from prompt_toolkit.application.current import get_app
    from prompt_toolkit.filters import has_focus
    from prompt_toolkit.application import Application
    from prompt_toolkit.key_binding import KeyBindings as PromptKeyBindings
    from prompt_toolkit.key_binding.bindings.focus import focus_next, focus_previous
    from prompt_toolkit.layout.containers import HSplit
    from prompt_toolkit.layout.layout import Layout
    from prompt_toolkit.shortcuts import input_dialog
    from prompt_toolkit.styles import Style as PromptStyle
    from prompt_toolkit.widgets import Button, Dialog, Label, RadioList, TextArea

    PROMPT_TOOLKIT_DIALOGS_AVAILABLE = True
except ModuleNotFoundError:  # pragma: no cover - optional wizard polish
    get_app = None
    has_focus = None
    Application = None
    PromptKeyBindings = None
    focus_next = None
    focus_previous = None
    HSplit = None
    Layout = None
    input_dialog = None
    PromptStyle = None
    Button = None
    Dialog = None
    Label = None
    RadioList = None
    TextArea = None
    PROMPT_TOOLKIT_DIALOGS_AVAILABLE = False

WIZARD_MAX_VISIBLE_CHOICES = 9


@dataclass(frozen=True, slots=True)
class WizardChoice:
    value: str
    label: str
    detail: str
    emoji: str = ""


class _WizardBackSignal:
    __slots__ = ()


WIZARD_BACK = _WizardBackSignal()


def _interactive_shell_supported() -> bool:
    return sys.stdin.isatty() and sys.stdout.isatty()


def _wizard_dialogs_supported() -> bool:
    return (
        _interactive_shell_supported()
        and PROMPT_TOOLKIT_DIALOGS_AVAILABLE
        and os.environ.get("AEGIS_NO_WIZARD_DIALOGS") != "1"
    )


def _wizard_style():
    if PromptStyle is None:
        return None
    return PromptStyle.from_dict(
        {
            "dialog": f"bg:#141922 {BRAND_LIGHT}",
            "dialog frame.label": f"bg:#141922 {BRAND_ACCENT} bold",
            "dialog.body": f"bg:#141922 {BRAND_LIGHT}",
            "dialog.body text-area": f"bg:#1a202b {BRAND_LIGHT}",
            "dialog.body radio": f"{BRAND_LIGHT}",
            "dialog.body radio-selected": f"{BRAND_ACCENT_STRONG} bold",
            "dialog.body button": f"bg:#1a202b {BRAND_LIGHT}",
            "dialog.body button.focused": f"bg:{BRAND_ACCENT_STRONG} #141922 bold",
            "dialog shadow": "bg:#0f1218",
            "title": f"{BRAND_ACCENT} bold",
            "prompt": f"{BRAND_LIGHT}",
            "item": f"{BRAND_LIGHT}",
            "selected": f"{BRAND_ACCENT_STRONG} bold",
            "detail": f"{BRAND_MUTED}",
            "selected-detail": f"{BRAND_LIGHT}",
            "hint": f"{BRAND_MUTED}",
        }
    )


def _wizard_choice_menu(
    title: str,
    prompt: str,
    choices: tuple[WizardChoice, ...],
    *,
    default: str,
    allow_back: bool = False,
) -> str | _WizardBackSignal:
    if not (
        PROMPT_TOOLKIT_DIALOGS_AVAILABLE
        and Application is not None
        and PromptKeyBindings is not None
        and get_app is not None
        and has_focus is not None
        and focus_next is not None
        and focus_previous is not None
        and HSplit is not None
        and Layout is not None
        and Button is not None
        and Dialog is not None
        and Label is not None
        and RadioList is not None
    ):
        return default
    default_value = next((choice.value for choice in choices if choice.value == default), choices[0].value)
    values = tuple(
        (
            choice.value,
            [
                ("class:item", f"{_wizard_choice_label(choice)}\n"),
                ("class:detail", f"  {choice.detail}"),
            ],
        )
        for choice in choices
    )
    radio_list = RadioList(
        values=values,
        default=default_value,
        select_on_focus=True,
        show_scrollbar=len(choices) > WIZARD_MAX_VISIBLE_CHOICES,
    )
    hint = "Enter continues · Esc goes back · ↑/↓ or j/k moves" if allow_back else "Enter continues · ↑/↓ or j/k moves"

    def _accept() -> None:
        get_app().exit(result=radio_list.current_value)

    def _cancel() -> None:
        get_app().exit(result=WIZARD_BACK)

    continue_button = Button(text="Continue", handler=_accept)
    cancel_button = Button(text="Back", handler=_cancel)
    dialog = Dialog(
        title=title,
        body=HSplit(
            [
                Label(text=prompt, dont_extend_height=True),
                radio_list,
                Label(text=hint, dont_extend_height=True),
            ],
            padding=1,
        ),
        buttons=[continue_button, cancel_button],
        with_background=True,
    )
    bindings = PromptKeyBindings()

    @bindings.add("tab")
    def _focus_next_binding(event) -> None:
        focus_next(event)

    @bindings.add("s-tab")
    def _focus_previous_binding(event) -> None:
        focus_previous(event)

    @bindings.add("enter", filter=has_focus(radio_list), eager=True)
    def _accept_binding(_event) -> None:
        _accept()

    @bindings.add("escape")
    def _cancel_binding(_event) -> None:
        _cancel()

    application = Application(
        layout=Layout(dialog, focused_element=radio_list),
        key_bindings=bindings,
        style=_wizard_style(),
        full_screen=True,
        mouse_support=True,
    )
    answer = application.run()
    if answer is WIZARD_BACK:
        return WIZARD_BACK
    return str(answer or radio_list.current_value or default_value)


def _wizard_choice_window(total: int, selected: int, *, max_visible: int = WIZARD_MAX_VISIBLE_CHOICES) -> tuple[int, int]:
    if total <= max_visible:
        return 0, total
    if selected < 0:
        selected = 0
    if selected >= total:
        selected = total - 1
    half = max_visible // 2
    start = max(0, selected - half)
    end = start + max_visible
    if end > total:
        end = total
        start = end - max_visible
    return start, end


def _wizard_choice_fragments(
    title: str,
    prompt: str,
    choices: tuple[WizardChoice, ...],
    *,
    selected: int,
    max_visible: int = WIZARD_MAX_VISIBLE_CHOICES,
    allow_back: bool = False,
) -> list[tuple[str, str]]:
    fragments: list[tuple[str, str]] = [
        ("class:title", f"{title}\n"),
        ("class:prompt", f"{prompt}\n\n"),
    ]
    start, end = _wizard_choice_window(len(choices), selected, max_visible=max_visible)
    if start > 0:
        fragments.append(("class:hint", f"↑ {start} more above\n"))
    for index in range(start, end):
        choice = choices[index]
        active = index == selected
        marker = "›" if active else " "
        label_style = "class:selected" if active else "class:item"
        detail_style = "class:selected-detail" if active else "class:detail"
        fragments.append((label_style, f"{marker} {_wizard_choice_label(choice)}\n"))
        fragments.append((detail_style, f"  {choice.detail}\n"))
    if end < len(choices):
        fragments.append(("class:hint", f"↓ {len(choices) - end} more below\n"))
    if allow_back:
        fragments.append(("class:hint", "\nEnter confirms · Esc goes back · ↑/↓ or j/k moves"))
    else:
        fragments.append(("class:hint", "\nEnter confirms · ↑/↓ or j/k moves"))
    return fragments


def _wizard_choice_label(choice: WizardChoice) -> str:
    if not choice.emoji:
        return choice.label
    return f"{choice.emoji} {choice.label}"


def _wizard_text_prompt(
    title: str,
    prompt: str,
    *,
    default: str | None = None,
    allow_back: bool = False,
    password: bool = False,
) -> str | _WizardBackSignal:
    if password:
        if _wizard_dialogs_supported():
            answer = _wizard_password_dialog(title, prompt, allow_back=allow_back)
            if answer is not None:
                return answer
        if os.environ.get("AEGIS_NO_WIZARD_DIALOGS") == "1":
            try:
                return input(f"{prompt}: ").strip()
            except (KeyboardInterrupt, EOFError):
                return WIZARD_BACK if allow_back else ""
        try:
            return getpass.getpass(f"{prompt}: ").strip()
        except (KeyboardInterrupt, EOFError):
            return WIZARD_BACK if allow_back else ""
    if _wizard_dialogs_supported() and input_dialog is not None:
        answer = input_dialog(
            title=title,
            text=prompt,
            default=default or "",
            style=_wizard_style(),
            ok_text="Continue",
            cancel_text="Back",
        ).run()
        if answer is None:
            return WIZARD_BACK
        resolved = str(answer or "").strip()
        return resolved or (default or "")
    suffix = f" [{default}]" if default else ""
    answer = input(f"{prompt}{suffix}: ").strip()
    return answer or (default or "")


def _wizard_password_dialog(
    title: str,
    prompt: str,
    *,
    allow_back: bool = False,
) -> str | _WizardBackSignal | None:
    if not (
        PROMPT_TOOLKIT_DIALOGS_AVAILABLE
        and Application is not None
        and PromptKeyBindings is not None
        and get_app is not None
        and has_focus is not None
        and focus_next is not None
        and focus_previous is not None
        and HSplit is not None
        and Layout is not None
        and Button is not None
        and Dialog is not None
        and Label is not None
        and TextArea is not None
    ):
        return None

    password_field = TextArea(
        multiline=False,
        password=True,
        wrap_lines=False,
        prompt="",
    )
    hint = "Enter continues · Esc goes back · Tab moves focus" if allow_back else "Enter continues · Esc cancels · Tab moves focus"

    def _accept() -> None:
        get_app().exit(result=password_field.text)

    def _cancel() -> None:
        get_app().exit(result=WIZARD_BACK)

    continue_button = Button(text="Continue", handler=_accept)
    cancel_button = Button(text="Back", handler=_cancel)
    dialog = Dialog(
        title=title,
        body=HSplit(
            [
                Label(text=prompt, dont_extend_height=True),
                password_field,
                Label(text=hint, dont_extend_height=True),
            ],
            padding=1,
        ),
        buttons=[continue_button, cancel_button],
        with_background=True,
    )
    bindings = PromptKeyBindings()

    @bindings.add("tab")
    def _focus_next_binding(event) -> None:
        focus_next(event)

    @bindings.add("s-tab")
    def _focus_previous_binding(event) -> None:
        focus_previous(event)

    @bindings.add("enter", filter=has_focus(password_field), eager=True)
    def _accept_binding(_event) -> None:
        _accept()

    @bindings.add("escape")
    def _cancel_binding(_event) -> None:
        _cancel()

    application = Application(
        layout=Layout(dialog, focused_element=password_field),
        key_bindings=bindings,
        style=_wizard_style(),
        full_screen=True,
        mouse_support=True,
    )
    answer = application.run()
    if answer is WIZARD_BACK:
        return WIZARD_BACK
    return str(answer or password_field.text).strip()


def _wizard_choice_prompt(
    title: str,
    prompt: str,
    choices: tuple[WizardChoice, ...],
    *,
    default: str | None = None,
    allow_back: bool = False,
) -> str | _WizardBackSignal:
    if not choices:
        return default or ""
    default_value = default or choices[0].value
    if _wizard_dialogs_supported():
        return _wizard_choice_menu(title, prompt, choices, default=default_value, allow_back=allow_back)
    print(prompt)
    for index, choice in enumerate(choices, start=1):
        marker = "*" if choice.value == default_value else " "
        print(f"  {marker} {index}. {_wizard_choice_label(choice)} :: {choice.detail}")
    while True:
        answer = input(f"choice [{default_value}]: ").strip()
        if not answer:
            return default_value
        if answer.isdigit():
            index = int(answer)
            if 1 <= index <= len(choices):
                return choices[index - 1].value
        normalized = answer.casefold()
        for choice in choices:
            if normalized in {choice.value.casefold(), choice.label.casefold()}:
                return choice.value
        print("  choose a listed number, provider id, or label.")
