"""CLI proving-surface runtime.

The CLI composes shared packages instead of reimplementing core behavior.
It keeps a tiny preview snapshot only so inspection commands can render the
latest durable state and the most recent turn outcome in a local-first way.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any
from uuid import uuid4

from apps.provider_runtime import (
    SurfaceModelProviderCapability,
    load_provider_profile,
    provider_profile_from_payload,
)
from apps.cli.runtime_extensions import (
    CliExtensionManifest,
    build_skill_runtime,
    build_tool_runtime,
    load_extension_manifest,
    load_json_file,
    sanitize_extension_manifest_payload,
    serialize_manifest_path,
)
from apps.cli.runtime_snapshot import (
    append_outcome_experience as _append_runtime_outcome_experience,
    append_outcome_growth as _append_runtime_outcome_growth,
    append_outcome_memory as _append_runtime_outcome_memory,
    load_snapshot as _load_runtime_snapshot,
    write_snapshot as _write_runtime_snapshot,
)
from apps.cli.runtime_turns import (
    build_kernel_dependencies as _build_runtime_kernel_dependencies,
    create_clone_session as _create_runtime_clone_session,
    explain_next_step as _explain_runtime_next_step,
    generate_opening_reply as _generate_runtime_opening_reply,
    resume_session as _resume_runtime_session,
    run_turn as _run_runtime_turn,
    start_session as _start_runtime_session,
    wake as _wake_runtime,
)
from packages.capabilities.runtime import CapabilityDescriptor
from packages.contracts.runtime import (
    ContextBundle,
    EventEnvelope,
    ExperienceRecord,
    ExecutionResult,
    GoalNode,
    MemoryRecord,
    PlanDraft,
    ProfileGrowthState,
    ProfileState,
    SessionContinuityState,
    SessionState,
)
from packages.context import ContextRuntime
from packages.cron import CronJob, CronJobExecution, CronRuntime
from packages.growth import (
    GrowthSnapshot,
    GrowthUpdate,
    build_growth_snapshot,
    default_growth_state,
)
from packages.models.provider_runtime import ProviderCatalogRecord, ProviderSetupGuide
from packages.kernel import KernelDependencies, KernelOutcome
from packages.planning.runtime import (
    GoalGraph,
    GoalGraphNode,
    PlanningDecision,
    PlanningService,
    build_goal_graph,
)
from packages.profile import (
    PROFILE_MANIFEST_FILENAME,
    PromptContract,
    PromptMode,
    HerModeSettings,
    LoadedProfile,
    ProfileLoader,
    build_prompt_contract,
    her_mode_manifest_payload,
    personality_presets,
    render_clone_charter,
    resolve_personality_preset,
    profile_manifest_payload,
    write_clone_text,
    write_friend_text,
    write_profile_manifest,
)
from packages.security import (
    ApprovalClass,
    SecurityPolicy,
    SecurityRequest,
    default_surface_policy_bundles,
    evaluate_with_telemetry,
)
from packages.memory import MemoryRuntime
from packages.session import (
    CompanionContinuityService,
    RelationshipMemoryPolicy,
    SessionLineageService,
    SessionResumeResult,
)
from packages.skills import (
    SkillDefinition,
    SkillHub,
    SkillHubEntry,
    SkillManifestLoadRecord,
    SkillPackageLoader,
    SkillRuntime,
    default_aegis_skill_source_root,
)
from packages.skills.authoring import write_skill_package
from packages.storage import RuntimeStorageRepository
from packages.tools.adapters import StructuredClarifySurface
from packages.tools.browser_backend import create_playwright_browser_backend
from packages.tools.surfaces import BrowserToolBackend
from packages.tools import (
    BuiltinToolDependencies,
    InMemorySessionTodoStore,
    ToolDefinition,
    ToolManifestLoadRecord,
    ToolRuntime,
)
from packages.voice import (
    VoiceInputRequest,
    VoiceInputResolution,
    VoiceTurnResult,
    build_provider_voice_service,
)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime) -> str:
    return value.isoformat()


def _restore_datetime(value: str) -> datetime:
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed


def _coerce_str_tuple(value: Any) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        if not value.strip():
            return ()
        return tuple(part.strip() for part in value.split(",") if part.strip())
    if isinstance(value, (list, tuple)):
        return tuple(str(item) for item in value if str(item))
    return (str(value),)


def _optional_datetime(value: Any) -> datetime | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    return datetime.fromisoformat(text)


_PROFILE_TEXT_UNSET = object()


def _normalized_profile_text(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None


def _current_clone_text(profile: LoadedProfile) -> str | None:
    return _normalized_profile_text(profile.clone_text)


def _default_clone_text(
    profile: LoadedProfile,
    *,
    display_name: str | None = None,
    mode: str | None = None,
    her_mode: HerModeSettings | None = None,
) -> str:
    effective_her_mode = her_mode or profile.her_mode or HerModeSettings()
    return render_clone_charter(
        display_name=display_name or profile.state.display_name,
        personality_preset=effective_her_mode.personality_preset,
        initiative=effective_her_mode.initiative,
        mode=mode or profile.state.mode,
    ).strip()


def _clone_text_uses_default(profile: LoadedProfile) -> bool:
    current = _current_clone_text(profile)
    if current is None:
        return True
    return current == _default_clone_text(profile)


def _seed_clone_text(
    profile: LoadedProfile,
    *,
    display_name: str | None = None,
    mode: str | None = None,
    her_mode: HerModeSettings | None = None,
) -> str:
    current = _current_clone_text(profile)
    if current is None or _clone_text_uses_default(profile):
        return _default_clone_text(
            profile,
            display_name=display_name,
            mode=mode,
            her_mode=her_mode,
        )
    return current


@dataclass(frozen=True, slots=True)
class CliPaths:
    state_dir: Path
    profile_dir: Path

    @property
    def database_path(self) -> Path:
        return self.state_dir / "aegis.sqlite3"

    @property
    def snapshot_path(self) -> Path:
        return self.state_dir / "preview-snapshot.json"

    @property
    def cron_jobs_path(self) -> Path:
        return self.state_dir / "cron-jobs.json"

    @property
    def secret_key_path(self) -> Path:
        return self.state_dir / "provider-secrets.key"


@dataclass(frozen=True, slots=True)
class WakeProgressionResult:
    profile: ProfileState
    session: SessionState
    decision: PlanningDecision
    planned_goal_graph: GoalGraph
    applied: bool
    plan: PlanDraft | None


@dataclass(frozen=True, slots=True)
class CliVoiceTurnResult:
    input_resolution: VoiceInputResolution
    kernel_outcome: KernelOutcome | None
    voice_turn: VoiceTurnResult


@dataclass(frozen=True, slots=True)
class ContinuityStatus:
    profile: LoadedProfile
    session: SessionState
    relationship_policy: RelationshipMemoryPolicy
    governance_summary: str
    proactive_summary: str
    wake_action: str
    wake_summary: str
    wake_factors: tuple[str, ...]
    reengagement_style: str
    reengagement_prompt: str
    continuity_summary: str
    voice_status: str
    voice_identity_binding: str
    voice_identity_summary: str


@dataclass(frozen=True, slots=True)
class CloneSummary:
    clone_id: str
    latest_session_id: str
    latest_status: str
    updated_at: datetime
    session_count: int


@dataclass(frozen=True, slots=True)
class CliRuntime:
    paths: CliPaths
    repository: RuntimeStorageRepository
    session_service: SessionLineageService
    profile_loader: ProfileLoader
    snapshot_path: Path
    memory_runtime: MemoryRuntime
    cron_runtime: CronRuntime
    model_provider: SurfaceModelProviderCapability
    tool_runtime: ToolRuntime
    skill_runtime: SkillRuntime
    skill_hub: SkillHub
    security_policy: SecurityPolicy
    todo_store: InMemorySessionTodoStore = field(default_factory=InMemorySessionTodoStore)
    browser_backend: BrowserToolBackend | None = None
    active_provider_profile_id: str | None = None
    active_provider_id: str | None = None
    growth_updates: dict[str, GrowthUpdate] = field(default_factory=dict, repr=False, compare=False)

    @classmethod
    def create(
        cls,
        *,
        state_dir: Path,
        profile_dir: Path,
    ) -> "CliRuntime":
        paths = CliPaths(state_dir=state_dir, profile_dir=profile_dir)
        repository = RuntimeStorageRepository(paths.database_path)
        repository.bootstrap()
        profile_loader = ProfileLoader(profile_dir)
        active_provider_profile = load_provider_profile(profile_dir)
        active_provider_profile_id = None
        active_provider_id = None
        if active_provider_profile is not None:
            repository.upsert_auth_profile(active_provider_profile)
            active_provider_profile_id = active_provider_profile.profile_id
            active_provider_id = active_provider_profile.provider_id
        raw_manifest, removed_legacy_keys = sanitize_extension_manifest_payload(
            load_json_file(profile_dir / PROFILE_MANIFEST_FILENAME)
        )
        if removed_legacy_keys:
            write_profile_manifest(profile_dir, raw_manifest)
        extension_manifest = load_extension_manifest(raw_manifest, profile_dir=profile_dir)
        cron_runtime = CronRuntime(paths.cron_jobs_path)
        skill_hub = SkillHub()
        security_policy = SecurityPolicy.default()
        todo_store = InMemorySessionTodoStore()
        browser_backend, _browser_reason = create_playwright_browser_backend()
        tool_runtime = build_tool_runtime(
            extension_manifest,
            dependencies=BuiltinToolDependencies(
                cwd=Path.cwd(),
                cron_runtime=cron_runtime,
                todo_store=todo_store,
                browser_backend=browser_backend,
                clarify_surface=StructuredClarifySurface(surface_label="cli"),
            ),
            snapshot_path=paths.snapshot_path,
            security_policy=security_policy,
        )
        skill_runtime = build_skill_runtime(
            extension_manifest,
            repository=repository,
            profile_loader=profile_loader,
        )
        runtime = cls(
            paths=paths,
            repository=repository,
            session_service=SessionLineageService(repository),
            profile_loader=profile_loader,
            snapshot_path=paths.snapshot_path,
            memory_runtime=MemoryRuntime.from_repository(repository),
            cron_runtime=cron_runtime,
            model_provider=SurfaceModelProviderCapability(
                repository=repository,
                fallback=_PreviewModelProviderCapability(),
                secret_key_path=paths.secret_key_path,
                tool_runtime=tool_runtime,
                capability_id="cli.model.runtime",
                surface_label="cli",
                active_provider_profile_id=active_provider_profile_id,
                active_provider_id=active_provider_id,
            ),
            tool_runtime=tool_runtime,
            skill_runtime=skill_runtime,
            skill_hub=skill_hub,
            security_policy=security_policy,
            todo_store=todo_store,
            browser_backend=browser_backend,
            active_provider_profile_id=active_provider_profile_id,
            active_provider_id=active_provider_id,
        )
        runtime._apply_extension_manifest(extension_manifest)
        return runtime

    def start(
        self,
        *,
        profile_id: str | None = None,
        display_name: str | None = None,
        mode: str | None = None,
        session_id: str | None = None,
        initial_goal: str | None = None,
    ) -> SessionState:
        return _start_runtime_session(
            self,
            profile_id=profile_id,
            display_name=display_name,
            mode=mode,
            session_id=session_id,
            initial_goal=initial_goal,
        )

    def create_clone(
        self,
        *,
        clone_id: str,
        profile_id: str | None = None,
        display_name: str | None = None,
        mode: str | None = None,
        session_id: str | None = None,
        initial_goal: str | None = None,
    ) -> SessionState:
        return _create_runtime_clone_session(
            self,
            clone_id=clone_id,
            profile_id=profile_id,
            display_name=display_name,
            mode=mode,
            session_id=session_id,
            initial_goal=initial_goal,
            seed_clone_text=_seed_clone_text,
        )

    def seed_initial_goal(self, session_id: str, initial_goal: str) -> GoalNode | None:
        normalized = initial_goal.strip()
        if not normalized:
            return None
        existing = self.inspect_goals(session_id)
        if existing:
            return existing[0]
        return self.create_goal(
            session_id,
            title=normalized,
            priority="high",
            owner="shared",
            reason="initial goal seeded during onboarding",
            activate=True,
        )

    def resume(self, session_id: str, *, resumed_session_id: str | None = None) -> SessionResumeResult:
        return _resume_runtime_session(
            self,
            session_id,
            resumed_session_id=resumed_session_id,
        )

    def explain_next_step(
        self,
        *,
        session_id: str,
        prompt: str,
        goal_query: str | None = None,
        tool_name: str | None = None,
        tool_arguments: Mapping[str, Any] | None = None,
        delivery_payload: Mapping[str, Any] | None = None,
    ) -> KernelOutcome:
        return _explain_runtime_next_step(
            self,
            session_id=session_id,
            prompt=prompt,
            goal_query=goal_query,
            tool_name=tool_name,
            tool_arguments=tool_arguments,
            delivery_payload=delivery_payload,
        )

    def generate_opening_reply(
        self,
        *,
        session_id: str,
        prompt: str,
        opening_label: str,
    ) -> KernelOutcome | None:
        return _generate_runtime_opening_reply(
            self,
            session_id=session_id,
            prompt=prompt,
            opening_label=opening_label,
        )

    def _run_turn(
        self,
        *,
        session_id: str,
        prompt: str,
        goal_query: str | None = None,
        tool_name: str | None = None,
        tool_arguments: Mapping[str, Any] | None = None,
        delivery_payload: Mapping[str, Any] | None = None,
        event_type: str = "turn.received",
        source: str = "cli",
        event_payload: Mapping[str, str] | None = None,
        record_input_event: bool = True,
        record_outcome_memory: bool = True,
        capture_experience: bool = True,
        apply_growth: bool = True,
    ) -> KernelOutcome:
        return _run_runtime_turn(
            self,
            session_id=session_id,
            prompt=prompt,
            goal_query=goal_query,
            tool_name=tool_name,
            tool_arguments=tool_arguments,
            delivery_payload=delivery_payload,
            event_type=event_type,
            source=source,
            event_payload=event_payload,
            record_input_event=record_input_event,
            record_outcome_memory=record_outcome_memory,
            capture_experience=capture_experience,
            apply_growth=apply_growth,
        )

    def wake(self, session_id: str, *, inspect_only: bool = False) -> WakeProgressionResult:
        return _wake_runtime(
            self,
            session_id,
            inspect_only=inspect_only,
            result_cls=WakeProgressionResult,
        )

    def inspect_continuity(self, *, session_id: str | None = None) -> ContinuityStatus:
        session = self.inspect_session(session_id) if session_id is not None else self.latest_session()
        if session is None:
            raise KeyError("latest-session")
        profile = self._load_profile(session.profile_id)
        lineage = self.session_service.lineage(session.session_id)
        voice_report = self.voice_doctor(profile_id=session.profile_id)
        goal_graph = self.repository.load_goal_graph(session.session_id)
        active_goal_id = goal_graph.active_goal_id if goal_graph is not None else None
        continuity_report = CompanionContinuityService(self.session_service).inspect(
            profile,
            session,
            lineage=lineage,
            active_goal_id=active_goal_id,
        )
        if goal_graph is None:
            wake_action = "idle"
            wake_summary = "No durable wake action is available yet; start or resume a goal-bearing session first."
            wake_factors: tuple[str, ...] = ("no-goal-graph",)
        else:
            decision, _ = PlanningService().wake_next_step(
                session=session,
                graph=goal_graph,
                memories=self._planning_memories(session, goal_graph),
                initiative_hint=profile.her_mode.initiative if profile.her_mode is not None else None,
                continuity_notes=profile.her_mode.notes if profile.her_mode is not None else (),
            )
            wake_action = decision.selected_move.kind
            wake_summary = decision.rationale.summary
            wake_factors = decision.rationale.factors
        return ContinuityStatus(
            profile=profile,
            session=session,
            relationship_policy=continuity_report.relationship_policy,
            governance_summary=continuity_report.governance.identity.governance_summary,
            proactive_summary=continuity_report.governance.identity.proactive_summary,
            wake_action=wake_action,
            wake_summary=wake_summary,
            wake_factors=wake_factors,
            reengagement_style=continuity_report.reengagement_style,
            reengagement_prompt=continuity_report.reengagement_prompt,
            continuity_summary=continuity_report.summary,
            voice_status=str(voice_report["status"]),
            voice_identity_binding=str(
                voice_report.get("identity_binding") or continuity_report.voice_identity_binding
            ),
            voice_identity_summary=str(
                voice_report.get("voice_identity_summary")
                or continuity_report.governance.identity.voice_identity_summary
            ),
        )

    def inspect_profile(self, profile_id: str) -> LoadedProfile:
        return self._load_profile(profile_id)

    def inspect_companion(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> LoadedProfile:
        resolved_profile_id = self._resolve_extension_profile_id(
            session_id=session_id,
            profile_id=profile_id,
        )
        return self._load_profile(resolved_profile_id)

    def current_profile(self) -> LoadedProfile:
        return self.profile_loader.load()

    def _authorize_write(
        self,
        *,
        operation: str,
        session_id: str | None = None,
        description: str | None = None,
        is_destructive: bool = False,
        metadata: Mapping[str, str] | None = None,
    ) -> None:
        result = evaluate_with_telemetry(
            self.security_policy,
            SecurityRequest(
                request_id=f"req:cli:{uuid4().hex[:8]}",
                approval_class=ApprovalClass.WRITE,
                operation=operation,
                session_id=session_id,
                description=description,
                consent_given=True,
                is_destructive=is_destructive,
                metadata=dict(metadata or {}),
            ),
            _PreviewTelemetrySink(self.snapshot_path),
            source="cli.operator",
        )
        if not result.approved:
            raise PermissionError(result.rationale)

    def update_identity(
        self,
        *,
        profile_id: str | None = None,
        display_name: str | None = None,
        mode: str | None = None,
    ) -> LoadedProfile:
        loaded = self._load_profile(profile_id or self.current_profile().state.profile_id)
        self._authorize_write(
            operation="cli.identity.update",
            session_id=self.latest_session().session_id if self.latest_session() is not None else None,
            description=display_name or loaded.state.display_name,
            metadata={"profile_id": loaded.state.profile_id},
        )
        resolved_mode = loaded.state.mode if mode is None else mode
        resolved_her_mode = loaded.her_mode
        if mode is not None and resolved_mode != "her":
            resolved_her_mode = None
        elif resolved_mode == "her" and resolved_her_mode is None:
            resolved_her_mode = HerModeSettings()
        updated_state = replace(
            loaded.state,
            display_name=loaded.state.display_name if display_name is None else display_name,
            mode=resolved_mode,
        )
        updated_clone_text = _current_clone_text(loaded)
        if display_name is not None or mode is not None:
            updated_clone_text = _seed_clone_text(
                loaded,
                display_name=updated_state.display_name,
                mode=resolved_mode,
                her_mode=resolved_her_mode,
            )
        return self._persist_profile(
            LoadedProfile(
                state=updated_state,
                her_mode=resolved_her_mode,
                profile_dir=loaded.profile_dir,
                manifest_path=loaded.manifest_path,
                clone_text=updated_clone_text,
                friend_text=loaded.friend_text,
                aegis_path=loaded.aegis_path,
                friend_path=loaded.friend_path,
                manifest=dict(loaded.manifest),
            ),
            clone_text=updated_clone_text,
            friend_text=loaded.friend_text,
        )

    def update_clone_text(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
        clone_text: str | None,
    ) -> LoadedProfile:
        resolved_profile_id = self._resolve_extension_profile_id(
            session_id=session_id,
            profile_id=profile_id,
        )
        loaded = self._load_profile(resolved_profile_id)
        self._authorize_write(
            operation="cli.clone.update",
            session_id=session_id or (self.latest_session().session_id if self.latest_session() is not None else None),
            description="update clone charter",
            metadata={"profile_id": loaded.state.profile_id},
        )
        return self._persist_profile(loaded, clone_text=_normalized_profile_text(clone_text))

    def update_friend_text(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
        friend_text: str | None,
    ) -> LoadedProfile:
        resolved_profile_id = self._resolve_extension_profile_id(
            session_id=session_id,
            profile_id=profile_id,
        )
        loaded = self._load_profile(resolved_profile_id)
        self._authorize_write(
            operation="cli.friend.update",
            session_id=session_id or (self.latest_session().session_id if self.latest_session() is not None else None),
            description="update friend profile",
            metadata={"profile_id": loaded.state.profile_id},
        )
        return self._persist_profile(loaded, friend_text=_normalized_profile_text(friend_text))

    def update_her_mode(
        self,
        *,
        profile_id: str | None = None,
        text_first: bool | None = None,
        initiative: str | None = None,
        personality_preset: str | None = None,
        personality: tuple[str, ...] | None = None,
        allow_voice_extension: bool | None = None,
        notes: tuple[str, ...] | None = None,
    ) -> LoadedProfile:
        loaded = self._load_profile(profile_id or self.current_profile().state.profile_id)
        self._authorize_write(
            operation="cli.personality.update",
            session_id=self.latest_session().session_id if self.latest_session() is not None else None,
            description=personality_preset or initiative or "update her mode",
            metadata={"profile_id": loaded.state.profile_id},
        )
        current = loaded.her_mode or HerModeSettings()
        resolved_preset = (
            current.personality_preset
            if personality_preset is None
            else resolve_personality_preset(personality_preset, mode=loaded.state.mode).preset_id
        )
        resolved_personality = current.personality if personality is None else personality
        if personality_preset is not None and personality is None:
            resolved_personality = resolve_personality_preset(resolved_preset, mode=loaded.state.mode).traits
        updated_her_mode = HerModeSettings(
            text_first=current.text_first if text_first is None else text_first,
            personality_preset=resolved_preset,
            personality=resolved_personality,
            initiative=current.initiative if initiative is None else initiative,
            preserve_relationship_timeline=current.preserve_relationship_timeline,
            preserve_preferences=current.preserve_preferences,
            preserve_corrections=current.preserve_corrections,
            preserve_emotional_context=current.preserve_emotional_context,
            allow_voice_extension=(
                current.allow_voice_extension
                if allow_voice_extension is None
                else allow_voice_extension
            ),
            notes=current.notes if notes is None else notes,
        )
        updated_clone_text = _seed_clone_text(
            loaded,
            display_name=loaded.state.display_name,
            mode=loaded.state.mode,
            her_mode=updated_her_mode,
        )
        return self._persist_profile(
            LoadedProfile(
                state=loaded.state,
                her_mode=updated_her_mode,
                profile_dir=loaded.profile_dir,
                manifest_path=loaded.manifest_path,
                clone_text=updated_clone_text,
                friend_text=loaded.friend_text,
                aegis_path=loaded.aegis_path,
                friend_path=loaded.friend_path,
                manifest=dict(loaded.manifest),
            ),
            clone_text=updated_clone_text,
            friend_text=loaded.friend_text,
        )

    def provider_summary(self) -> Mapping[str, object]:
        return self.model_provider.describe()

    def active_provider_context_window(self, *, default: int = 4096) -> int:
        summary = dict(self.provider_summary())
        value = summary.get("context_window_tokens")
        try:
            parsed = int(value) if value is not None else 0
        except (TypeError, ValueError):
            parsed = 0
        return parsed if parsed > 0 else default

    def discover_provider_models(
        self,
        *,
        provider_id: str,
        base_url: str | None = None,
        api_key: str | None = None,
    ):
        resolved_base_url = base_url
        active_profile = self.model_provider.active_profile()
        if resolved_base_url is None and active_profile is not None and active_profile.provider_id == provider_id:
            resolved_base_url = active_profile.base_url
        resolved_api_key = api_key
        if resolved_api_key is None and active_profile is not None:
            if active_profile.provider_id == provider_id and (resolved_base_url or active_profile.base_url) == active_profile.base_url:
                credentials = self.model_provider.resolve_credentials(active_profile)
                resolved_api_key = str(credentials.get("api_key", "")).strip() or None
        return self.model_provider.discover_models(
            provider_id=provider_id,
            base_url=resolved_base_url,
            api_key=resolved_api_key,
        )

    def detect_provider_context_window(
        self,
        *,
        provider_id: str,
        model_id: str,
        base_url: str | None = None,
        api_key: str | None = None,
    ) -> int | None:
        resolved_base_url = base_url
        active_profile = self.model_provider.active_profile()
        if resolved_base_url is None and active_profile is not None and active_profile.provider_id == provider_id:
            resolved_base_url = active_profile.base_url
        resolved_api_key = api_key
        if resolved_api_key is None and active_profile is not None:
            if active_profile.provider_id == provider_id and (resolved_base_url or active_profile.base_url) == active_profile.base_url:
                credentials = self.model_provider.resolve_credentials(active_profile)
                resolved_api_key = str(credentials.get("api_key", "")).strip() or None
        return self.model_provider.detect_context_window(
            provider_id=provider_id,
            base_url=resolved_base_url,
            model_id=model_id,
            api_key=resolved_api_key,
        )

    def set_model_stream_observer(self, observer) -> None:
        self.model_provider.set_stream_observer(observer)

    def provider_catalog(self) -> tuple[ProviderCatalogRecord, ...]:
        return self.model_provider.runtime_resolver.list_catalog()

    def provider_setup_guide(self, provider_id: str) -> ProviderSetupGuide:
        return self.model_provider.runtime_resolver.build_setup_guide(provider_id)

    def provider_test(self, *, prompt: str = "Summarize the current provider configuration.") -> ExecutionResult:
        active_profile = self.model_provider.active_profile()
        context_capability = _CliContextCapability(
            profile_loader=self.profile_loader,
            repository=self.repository,
            prompt_mode="minimal",
            snapshot_path=self.snapshot_path,
            total_tokens=self.active_provider_context_window(),
        )
        if active_profile is None:
            profile = ProfileState(
                profile_id="provider-test",
                display_name="Aegis",
                mode="her",
            )
            session = SessionState(
                session_id=f"session:provider-test:{uuid4().hex[:8]}",
                profile_id=profile.profile_id,
                workspace_id="provider-test",
                status="active",
                started_at=_utc_now(),
                updated_at=_utc_now(),
            )
            context = context_capability.assemble(session, (), ())
            return self.model_provider.generate(profile=profile, session=session, context=context, prompt=prompt)

        loaded_profile = self.profile_loader.load()
        profile = loaded_profile.state
        session = SessionState(
            session_id=f"session:provider-test:{uuid4().hex[:8]}",
            profile_id=profile.profile_id,
            workspace_id="provider-test",
            status="active",
            started_at=_utc_now(),
            updated_at=_utc_now(),
        )
        context = context_capability.assemble(session, (), ())
        return self.model_provider.generate(profile=profile, session=session, context=context, prompt=prompt)

    def provider_doctor(self) -> dict[str, Any]:
        summary = dict(self.provider_summary())
        guide: dict[str, Any] | None = None
        if summary["provider_id"] not in {"preview", ""}:
            guide = self.provider_setup_guide(str(summary["provider_id"])).as_mapping()
        secret_ready = summary.get("secret_status") in {"stored", "not-required"}
        checks = [
            {
                "check": "provider_profile",
                "status": "configured" if summary["source"] == "configured" else "missing",
            },
            {
                "check": "credentials",
                "status": (
                    "available"
                    if summary["source"] == "configured" and secret_ready
                    else ("missing" if summary["source"] == "configured" else "preview")
                ),
                "summary": str(summary.get("secret_source", "encrypted-local-store")),
            },
        ]
        probe = None
        probe_error: str | None = None
        if summary["source"] == "configured" and secret_ready:
            try:
                probe = self.provider_test(prompt="Doctor check")
            except Exception as error:  # pragma: no cover - defensive surface guard
                probe_error = str(error)
        if probe is not None:
            checks.append({"check": "runtime", "status": "ok", "summary": probe.summary})
        elif probe_error is not None:
            checks.append({"check": "runtime", "status": "not-ready", "summary": probe_error})
        return {
            "status": "ready"
            if summary["source"] == "configured" and secret_ready and probe_error is None
            else ("not-ready" if summary["source"] == "configured" else "preview"),
            "provider": summary,
            "setup_guide": guide,
            "checks": checks,
            "probe_summary": probe.summary if probe is not None else (probe_error or ""),
        }

    def security_doctor(self) -> dict[str, Any]:
        policy = SecurityPolicy.default()
        profile = self.model_provider.active_profile()
        provider = dict(self.provider_summary())
        secret_refs = ()
        if profile is not None:
            secret_refs = tuple(profile.secret_references)
        stored_reference_ids = tuple(
            reference.reference_id
            for reference in secret_refs
            if self.repository.has_auth_secret_value(reference.reference_id)
        )
        missing_reference_ids = tuple(
            reference.reference_id
            for reference in secret_refs
            if reference.reference_id not in stored_reference_ids
        )
        checks: list[dict[str, object]] = [
            {
                "check": "policy_rules",
                "status": "ok",
                "summary": ", ".join(bundle.surface_id for bundle in default_surface_policy_bundles()),
            },
            {
                "check": "secret_boundary",
                "status": (
                    "ok"
                    if provider["source"] != "configured" or not missing_reference_ids
                    else "warning"
                ),
                "summary": (
                    "preview fallback carries no runtime provider secrets"
                    if provider["source"] != "configured"
                    else (
                        "provider secrets are stored in the encrypted local vault"
                        if not missing_reference_ids
                        else (
                            "missing stored provider secrets for "
                            + ", ".join(missing_reference_ids)
                        )
                    )
                ),
            },
            {
                "check": "support_bundle",
                "status": "ok",
                "summary": "support bundle exports provider ids, models, and secret reference ids only",
            },
        ]
        return {
            "status": (
                "ready"
                if provider["source"] != "configured" or not missing_reference_ids
                else "not-ready"
            ),
            "provider": provider,
            "checks": checks,
            "surface_bundles": tuple(
                bundle.to_record(policy) for bundle in default_surface_policy_bundles()
            ),
            "support_bundle": self.security_support_bundle(),
        }

    def security_support_bundle(self) -> dict[str, Any]:
        profile = self.model_provider.active_profile()
        provider = dict(self.provider_summary())
        secret_reference_ids = ()
        stored_reference_ids = ()
        if profile is not None:
            secret_reference_ids = tuple(reference.reference_id for reference in profile.secret_references)
            stored_reference_ids = tuple(
                reference.reference_id
                for reference in profile.secret_references
                if self.repository.has_auth_secret_value(reference.reference_id)
            )
        return {
            "provider": {
                "provider_id": provider["provider_id"],
                "profile_id": provider["profile_id"],
                "transport_id": provider["transport_id"],
                "base_url": provider["base_url"],
                "default_model": provider["default_model"],
                "context_window_tokens": provider.get("context_window_tokens"),
                "context_window_mode": provider.get("context_window_mode"),
                "source": provider["source"],
                "secret_reference_ids": secret_reference_ids,
                "stored_secret_reference_ids": stored_reference_ids,
                "secret_store": "encrypted-local-store",
            },
            "surface_bundles": tuple(bundle.surface_id for bundle in default_surface_policy_bundles()),
            "generated_at": _iso(_utc_now()),
            "notes": (
                "secret values are never exported here",
                "set or rotate runtime credentials outside the support bundle",
            ),
        }

    def voice_summary(
        self,
        *,
        input_model_id: str = "gpt-4o-mini-transcribe",
        output_model_id: str = "gpt-4o-mini-tts",
        voice_name: str = "alloy",
    ) -> Mapping[str, object]:
        return self._build_voice_service(
            input_model_id=input_model_id,
            output_model_id=output_model_id,
            voice_name=voice_name,
        ).provider_summary()

    def voice_doctor(
        self,
        *,
        profile_id: str | None = None,
        input_model_id: str = "gpt-4o-mini-transcribe",
        output_model_id: str = "gpt-4o-mini-tts",
        voice_name: str = "alloy",
    ) -> dict[str, Any]:
        loaded = self.profile_loader.load(profile_id=profile_id)
        return self._build_voice_service(
            input_model_id=input_model_id,
            output_model_id=output_model_id,
            voice_name=voice_name,
        ).doctor(loaded)

    def run_voice_turn(
        self,
        *,
        session_id: str,
        audio_bytes: bytes,
        audio_name: str,
        audio_format: str | None = None,
        goal_query: str | None = None,
        voice_output_enabled: bool = False,
        input_model_id: str = "gpt-4o-mini-transcribe",
        output_model_id: str = "gpt-4o-mini-tts",
        voice_name: str = "alloy",
        output_audio_format: str = "mp3",
    ) -> CliVoiceTurnResult:
        session = self.repository.load_session(session_id)
        if session is None:
            raise KeyError(session_id)
        loaded_profile = self._load_profile(session.profile_id)
        voice_service = self._build_voice_service(
            telemetry=_PreviewTelemetrySink(self.snapshot_path),
            input_model_id=input_model_id,
            output_model_id=output_model_id,
            voice_name=voice_name,
        )
        voice_session = voice_service.open_session(loaded_profile, session_id)
        resolution = voice_service.resolve_input(
            loaded_profile,
            voice_session,
            VoiceInputRequest(
                request_id=f"voice-turn:{uuid4().hex[:8]}",
                session_id=session_id,
                profile_id=loaded_profile.state.profile_id,
                source="provider-backed",
                consent_given=True,
                recording_enabled=False,
                audio_bytes=audio_bytes,
                audio_format=audio_format,
                audio_name=audio_name,
            ),
        )
        if resolution.outcome != "ready":
            return CliVoiceTurnResult(
                input_resolution=resolution,
                kernel_outcome=None,
                voice_turn=voice_service.complete_output(
                    loaded_profile,
                    voice_session,
                    resolution,
                    voice_output_enabled=voice_output_enabled,
                    audio_format=output_audio_format,
                ),
            )
        outcome = self.explain_next_step(
            session_id=session_id,
            prompt=resolution.transcript,
            goal_query=goal_query,
        )
        voice_turn = voice_service.complete_output(
            loaded_profile,
            voice_session,
            resolution,
            response_transcript=outcome.execution.summary,
            voice_output_enabled=voice_output_enabled,
            audio_format=output_audio_format,
        )
        return CliVoiceTurnResult(
            input_resolution=resolution,
            kernel_outcome=outcome,
            voice_turn=voice_turn,
        )

    def set_default_provider(
        self,
        *,
        provider_id: str,
        profile_id: str | None = None,
        display_name: str | None = None,
        mode: str | None = None,
        base_url: str | None = None,
        default_model: str | None = None,
        auth_method: str | None = None,
        provider_kind: str | None = None,
        api_key: str | None = None,
        context_window_tokens: int | None = None,
        context_window_mode: str | None = None,
        extra_headers: Mapping[str, str] | None = None,
    ) -> LoadedProfile:
        loaded = self.profile_loader.load(profile_id=profile_id, display_name=display_name, mode=mode)
        provider_payload = self._build_provider_payload(
            provider_id=provider_id,
            base_url=base_url,
            default_model=default_model,
            auth_method=auth_method,
            provider_kind=provider_kind,
            context_window_tokens=context_window_tokens,
            context_window_mode=context_window_mode,
            extra_headers=extra_headers,
        )
        manifest = self._load_profile_manifest()
        manifest["profile_id"] = loaded.state.profile_id
        manifest["display_name"] = loaded.state.display_name
        manifest["mode"] = loaded.state.mode
        manifest["preferences"] = list(loaded.state.preferences)
        manifest["enabled_capabilities"] = list(loaded.state.enabled_capabilities)
        her_mode_payload = her_mode_manifest_payload(loaded.her_mode)
        if her_mode_payload is None:
            manifest.pop("her_mode", None)
        else:
            manifest["her_mode"] = her_mode_payload
        manifest["provider_profile"] = provider_payload
        self._write_profile_manifest(manifest)
        provider_profile = provider_profile_from_payload(provider_payload)
        self.repository.upsert_auth_profile(provider_profile)
        if api_key is not None:
            api_reference = next(
                (reference for reference in provider_profile.secret_references if reference.secret_key == "api_key"),
                None,
            )
            if api_reference is not None:
                self.model_provider.store_secret_value(api_reference, api_key)
        self.model_provider.set_active_profile(
            provider_profile_id=provider_profile.profile_id,
            provider_id=provider_profile.provider_id,
        )
        return self.profile_loader.load(
            profile_id=loaded.state.profile_id,
            display_name=loaded.state.display_name,
            mode=loaded.state.mode,
        )

    def relationship_memory_policy(self, loaded_profile: LoadedProfile) -> RelationshipMemoryPolicy:
        her_mode = loaded_profile.her_mode or HerModeSettings()
        return self.session_service.relationship_memory_policy(
            loaded_profile.state.mode,
            text_first=her_mode.text_first,
            preserve_relationship_timeline=her_mode.preserve_relationship_timeline,
            preserve_preferences=her_mode.preserve_preferences,
            preserve_corrections=her_mode.preserve_corrections,
            preserve_emotional_context=her_mode.preserve_emotional_context,
            allow_voice_extension=her_mode.allow_voice_extension,
        )

    def personality_presets(self):
        return personality_presets()

    def prompt_contract(
        self,
        *,
        profile_id: str | None = None,
        prompt_mode: PromptMode = "full",
    ) -> PromptContract:
        loaded = self._load_profile(profile_id or self.current_profile().state.profile_id)
        return build_prompt_contract(loaded, prompt_mode=prompt_mode)

    def prepare_session_surface(self, session_id: str) -> SessionState:
        session = self._load_session(session_id)
        self._refresh_extensions(profile_id=session.profile_id)
        return session

    def tool_catalog(self, *, session_id: str | None = None) -> tuple[ToolDefinition, ...]:
        if session_id is not None:
            self.prepare_session_surface(session_id)
        return self.tool_runtime.list_tools()

    def inspect_tool(self, tool_id: str, *, session_id: str | None = None) -> ToolDefinition:
        if session_id is not None:
            self.prepare_session_surface(session_id)
        tool = self.tool_runtime.describe(tool_id)
        if tool is None:
            raise KeyError(tool_id)
        return tool

    def set_tool_enabled(
        self,
        tool_id: str,
        enabled: bool,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> ToolDefinition:
        resolved_profile_id = self._resolve_extension_profile_id(session_id=session_id, profile_id=profile_id)
        self._refresh_extensions(profile_id=resolved_profile_id)
        updated = self.tool_runtime.set_enabled(tool_id, enabled)
        self._write_extension_override(
            "tool_overrides",
            tool_id,
            enabled,
            profile_id=resolved_profile_id,
        )
        return updated

    def install_tool_manifest(
        self,
        manifest_path: str | Path,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> ToolManifestLoadRecord:
        resolved_profile_id = self._resolve_extension_profile_id(session_id=session_id, profile_id=profile_id)
        target_profile = self._load_profile(resolved_profile_id)
        resolved_path = Path(manifest_path).expanduser().resolve()
        if not resolved_path.exists():
            raise FileNotFoundError(resolved_path)
        profile_dir = Path(target_profile.profile_dir)
        manifest = dict(target_profile.manifest)
        existing_paths = list(load_extension_manifest(manifest, profile_dir=profile_dir).tool_manifest_paths)
        if resolved_path not in existing_paths:
            existing_paths.append(resolved_path)
        manifest["tool_manifests"] = [
            serialize_manifest_path(path, profile_dir=profile_dir)
            for path in existing_paths
        ]
        write_profile_manifest(profile_dir, manifest)
        self._refresh_extensions(profile_id=resolved_profile_id)
        return self._tool_manifest_load_record(resolved_path)

    def run_tool(
        self,
        tool_id: str,
        arguments: Mapping[str, Any],
        *,
        session_id: str,
    ) -> ExecutionResult:
        self.prepare_session_surface(session_id)
        return self.tool_runtime.invoke(tool_id, arguments, session_id=session_id)

    def cron_jobs(self, *, session_id: str) -> tuple[CronJob, ...]:
        profile_id, clone_id = self._cron_scope(session_id)
        return self.cron_runtime.list_jobs(
            profile_id=profile_id,
            clone_id=clone_id,
        )

    def inspect_cron_job(self, job_id: str) -> CronJob:
        return self.cron_runtime.inspect_job(job_id)

    def create_cron_job(
        self,
        *,
        session_id: str,
        name: str,
        schedule: str,
        action_kind: str,
        payload: Mapping[str, Any],
    ) -> CronJob:
        self._authorize_write(
            operation="cli.cron.create",
            session_id=session_id,
            description=f"{name} @ {schedule}",
            metadata={"action_kind": action_kind},
        )
        profile_id, clone_id = self._cron_scope(session_id)
        return self.cron_runtime.create_job(
            name=name,
            schedule_text=schedule,
            action_kind=action_kind,
            payload=payload,
            profile_id=profile_id,
            clone_id=clone_id,
        )

    def pause_cron_job(self, job_id: str) -> CronJob:
        job = self.cron_runtime.inspect_job(job_id)
        scoped_session = self.latest_session_for_clone(job.clone_id or "") if job.clone_id else None
        self._authorize_write(
            operation="cli.cron.pause",
            session_id=scoped_session.session_id if scoped_session is not None else None,
            description=job.name,
            metadata={"job_id": job_id},
        )
        return self.cron_runtime.pause_job(job_id)

    def resume_cron_job(self, job_id: str) -> CronJob:
        job = self.cron_runtime.inspect_job(job_id)
        scoped_session = self.latest_session_for_clone(job.clone_id or "") if job.clone_id else None
        self._authorize_write(
            operation="cli.cron.resume",
            session_id=scoped_session.session_id if scoped_session is not None else None,
            description=job.name,
            metadata={"job_id": job_id},
        )
        return self.cron_runtime.resume_job(job_id)

    def remove_cron_job(self, job_id: str) -> CronJob:
        job = self.cron_runtime.inspect_job(job_id)
        scoped_session = self.latest_session_for_clone(job.clone_id or "") if job.clone_id else None
        self._authorize_write(
            operation="cli.cron.remove",
            session_id=scoped_session.session_id if scoped_session is not None else None,
            description=job.name,
            is_destructive=True,
            metadata={"job_id": job_id},
        )
        return self.cron_runtime.remove_job(job_id)

    def run_due_cron_jobs(self, *, session_id: str) -> tuple[CronJobExecution, ...]:
        session = self._load_session(session_id)
        loaded = self._load_profile(session.profile_id)
        display_name = loaded.state.display_name or self.clone_id_for_session(session)

        def executor(job: CronJob) -> tuple[str, str]:
            try:
                if job.action_kind == "greeting":
                    message = str(job.payload.get("message") or "").strip()
                    summary = message or f"{display_name} is checking in and keeping the thread warm."
                    return ("success", summary)
                if job.action_kind == "web_search":
                    query = str(job.payload.get("query") or "").strip()
                    if not query:
                        return ("success", f"{job.name} skipped because no query was stored.")
                    result = self.run_tool(
                        "tool.web.search",
                        {"query": query},
                        session_id=session_id,
                    )
                    return ("success", result.summary)
                if job.action_kind == "prompt":
                    prompt = str(job.payload.get("prompt") or "").strip()
                    if not prompt:
                        return ("success", f"{job.name} skipped because no prompt was stored.")
                    result = self.explain_next_step(session_id=session_id, prompt=prompt)
                    return ("success", result.execution.summary)
                return ("success", f"{job.name} is scheduled but uses an unknown action kind: {job.action_kind}")
            except Exception as error:
                return ("failed", f"{job.name} failed: {error}")

        return self.cron_runtime.run_due(
            executor,
            profile_id=loaded.state.profile_id,
            clone_id=self.clone_id_for_session(session),
        )

    def skill_catalog(self, *, session_id: str | None = None) -> tuple[SkillDefinition, ...]:
        if session_id is not None:
            self.prepare_session_surface(session_id)
        return self.skill_runtime.catalog.list()

    def search_skill_hub(self, query: str, *, limit: int = 12) -> tuple[SkillHubEntry, ...]:
        return self.skill_hub.search(query, limit=limit)

    def inspect_experiences(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
        statuses: tuple[str, ...] = (),
        limit: int | None = None,
    ) -> tuple[ExperienceRecord, ...]:
        return self.repository.list_experiences(
            session_id=session_id,
            profile_id=profile_id,
            statuses=statuses,
            limit=limit,
        )

    def inspect_growth(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> GrowthSnapshot:
        resolved_profile_id = profile_id
        if resolved_profile_id is None:
            if session_id is None:
                raise ValueError("inspect_growth requires session_id or profile_id")
            resolved_profile_id = self.inspect_session(session_id).profile_id
        state = self.repository.load_profile_growth(resolved_profile_id)
        if state is None:
            state = default_growth_state(resolved_profile_id)
        return build_growth_snapshot(state)

    def consume_growth_update(self, *, session_id: str) -> GrowthUpdate | None:
        return self.growth_updates.pop(session_id, None)

    def inspect_skill_hub_entry(self, reference: str) -> SkillHubEntry:
        entry = self.skill_hub.resolve(reference)
        if entry is None:
            raise KeyError(reference)
        return entry

    def inspect_skill(self, skill_id: str, *, session_id: str | None = None) -> SkillDefinition:
        if session_id is not None:
            self.prepare_session_surface(session_id)
        skill = self.skill_runtime.catalog.get(skill_id)
        if skill is None:
            raise KeyError(skill_id)
        return skill

    def set_skill_enabled(
        self,
        skill_id: str,
        enabled: bool,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> SkillDefinition:
        resolved_profile_id = self._resolve_extension_profile_id(session_id=session_id, profile_id=profile_id)
        self._refresh_extensions(profile_id=resolved_profile_id)
        updated = self.skill_runtime.set_enabled(skill_id, enabled)
        self._write_extension_override(
            "skill_overrides",
            skill_id,
            enabled,
            profile_id=resolved_profile_id,
        )
        return updated

    def install_skill_manifest(
        self,
        manifest_path: str | Path,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> SkillManifestLoadRecord:
        resolved_profile_id = self._resolve_extension_profile_id(session_id=session_id, profile_id=profile_id)
        target_profile = self._load_profile(resolved_profile_id)
        resolved_path = Path(manifest_path).expanduser().resolve()
        if not resolved_path.exists():
            raise FileNotFoundError(resolved_path)
        profile_dir = Path(target_profile.profile_dir)
        manifest = dict(target_profile.manifest)
        extension_manifest = load_extension_manifest(manifest, profile_dir=profile_dir)
        existing_paths = list(extension_manifest.skill_manifest_paths)
        if resolved_path not in existing_paths:
            existing_paths.append(resolved_path)
        manifest["skill_manifests"] = [
            serialize_manifest_path(path, profile_dir=profile_dir)
            for path in existing_paths
        ]
        write_profile_manifest(profile_dir, manifest)
        self._refresh_extensions(profile_id=resolved_profile_id)
        return self._skill_manifest_load_record(resolved_path)

    def install_skill_source(
        self,
        reference: str | Path,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> SkillManifestLoadRecord:
        raw = str(reference).strip()
        if not raw:
            raise ValueError("skill install requires a hub id, skill path, or manifest path")
        path_candidate = Path(raw).expanduser()
        if path_candidate.exists():
            resolved_path = path_candidate.resolve()
            if resolved_path.is_dir() or resolved_path.name == "SKILL.md":
                return self._install_skill_package_path(
                    resolved_path,
                    session_id=session_id,
                    profile_id=profile_id,
                )
            return self.install_skill_manifest(
                resolved_path,
                session_id=session_id,
                profile_id=profile_id,
            )
        entry = self.skill_hub.resolve(raw)
        if entry is None:
            raise KeyError(f"skill source was not found: {raw}")
        return self._install_skill_package_path(
            Path(entry.entry_path),
            session_id=session_id,
            profile_id=profile_id,
        )

    def create_experience_skill(
        self,
        *,
        skill_id: str,
        display_name: str,
        summary: str,
        instruction_text: str,
        category: str | None = None,
        install: bool = True,
        overwrite: bool = False,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> SkillManifestLoadRecord:
        package_path = write_skill_package(
            default_aegis_skill_source_root(),
            skill_id=skill_id,
            display_name=display_name,
            summary=summary,
            instruction_text=instruction_text,
            category=category or "experience",
            overwrite=overwrite,
        )
        if install:
            return self._install_skill_package_path(
                package_path,
                session_id=session_id,
                profile_id=profile_id,
            )
        manifest = SkillPackageLoader().load(package_path)
        return SkillManifestLoadRecord(
            source_path=manifest.source_path,
            skill_ids=tuple(skill.skill_id for skill in manifest.skills),
            loaded_at=_utc_now(),
            status="written",
            detail="shared Aegis experience skill package",
        )

    def inspect_session(self, session_id: str) -> SessionState:
        return self._load_session(session_id)

    def recent_sessions(self, *, limit: int = 5) -> tuple[SessionState, ...]:
        return self._list_sessions(limit=limit)

    def list_clones(self, *, limit: int = 12) -> tuple[CloneSummary, ...]:
        grouped: dict[str, list[SessionState]] = {}
        for session in self._list_sessions():
            grouped.setdefault(self.clone_id_for_session(session), []).append(session)
        clones = tuple(
            CloneSummary(
                clone_id=clone_id,
                latest_session_id=sessions[0].session_id,
                latest_status=sessions[0].status,
                updated_at=sessions[0].updated_at,
                session_count=len(sessions),
            )
            for clone_id, sessions in grouped.items()
        )
        ordered = tuple(sorted(clones, key=lambda item: (item.updated_at, item.clone_id), reverse=True))
        return ordered[:limit]

    def latest_session_for_clone(self, clone_id: str) -> SessionState | None:
        target = clone_id.strip()
        if not target:
            return None
        for session in self._list_sessions():
            if self.clone_id_for_session(session) == target:
                return session
        return None

    def session_ids_for_clone(self, clone_id: str) -> tuple[str, ...]:
        target = clone_id.strip()
        if not target:
            return ()
        return tuple(
            session.session_id
            for session in self._list_sessions()
            if self.clone_id_for_session(session) == target
        )

    def delete_clone(self, clone_id: str) -> int:
        session_ids = self.session_ids_for_clone(clone_id)
        if not session_ids:
            return 0
        return self.repository.delete_sessions(session_ids)

    def delete_all_clones(self) -> tuple[int, int]:
        clones = self.list_clones(limit=4096)
        session_ids = tuple(session.session_id for session in self._list_sessions())
        if not session_ids:
            return (0, 0)
        deleted_sessions = self.repository.delete_sessions(session_ids)
        return (len(clones), deleted_sessions)

    def clone_id_for_session(self, session: SessionState) -> str:
        if session.workspace_id:
            return session.workspace_id
        lineage = self.session_service.lineage(session.session_id)
        origin = lineage[0].session_id if lineage else session.session_id
        return f"clone-{origin[:8]}"

    def _list_sessions(self, *, limit: int | None = None) -> tuple[SessionState, ...]:
        with self.repository.connection() as connection:
            query = """
                SELECT session_id
                FROM sessions
                ORDER BY updated_at DESC, started_at DESC, session_id DESC
            """
            params: tuple[object, ...] = ()
            if limit is not None:
                query += "\nLIMIT ?"
                params = (limit,)
            rows = connection.execute(query, params).fetchall()
        sessions: list[SessionState] = []
        for row in rows:
            session = self.repository.load_session(str(row["session_id"]))
            if session is not None:
                sessions.append(session)
        return tuple(sessions)

    def latest_session(self) -> SessionState | None:
        sessions = self.recent_sessions(limit=1)
        if not sessions:
            return None
        return sessions[0]

    def _planning_memories(
        self,
        session: SessionState,
        goal_graph: GoalGraph,
        *,
        limit: int = 8,
    ) -> tuple[MemoryRecord, ...]:
        query = _memory_query_seed(goal_graph)
        goal_ids = _goal_ids_for_memory_search(goal_graph)
        retrieval = self.memory_runtime.retrieve(
            session.session_id,
            query,
            goal_ids=goal_ids,
            limit=limit,
        )
        memories = tuple(candidate.record for candidate in retrieval.candidates)
        if memories:
            return memories
        listed = tuple(self.repository.list_memory_records(session_id=session.session_id))
        if not listed:
            return ()
        return listed[-limit:]

    def inspect_goals(self, session_id: str) -> tuple[GoalNode, ...]:
        graph = self.repository.load_goal_graph(session_id)
        if graph is None:
            return ()
        return tuple(goal.to_contract_goal() for goal in graph.nodes)

    def inspect_memories(self, session_id: str) -> tuple[MemoryRecord, ...]:
        return tuple(self.memory_runtime.store.list(session_id=session_id))

    def search_memories(self, session_id: str, query: str, *, limit: int = 5) -> tuple[MemoryRecord, ...]:
        retrieval = self.memory_runtime.retrieve(session_id, query, limit=limit)
        return tuple(candidate.record for candidate in retrieval.candidates)

    def inspect_goal(self, session_id: str, goal_id: str) -> GoalNode:
        graph = self.repository.load_goal_graph(session_id)
        if graph is None:
            raise KeyError(session_id)
        goal = graph.goal(goal_id)
        if goal is None:
            raise KeyError(goal_id)
        return goal.to_contract_goal()

    def inspect_memory(self, session_id: str, memory_id: str) -> MemoryRecord:
        memory = self.memory_runtime.store.get(memory_id)
        if memory is None or memory.session_id != session_id:
            raise KeyError(memory_id)
        return memory

    def create_goal(
        self,
        session_id: str,
        *,
        title: str,
        status: str = "active",
        priority: str = "medium",
        owner: str = "shared",
        parent_goal_id: str | None = None,
        dependency_refs: Any = None,
        evidence_refs: Any = None,
        related_memory_ids: Any = None,
        review_checkpoint: str | None = None,
        deadline: Any = None,
        time_sensitivity: str | None = None,
        reason: str | None = None,
        activate: bool | None = None,
    ) -> GoalNode:
        normalized_title = title.strip()
        if not normalized_title:
            raise ValueError("goal title is required")
        self._authorize_write(
            operation="cli.goal.create",
            session_id=session_id,
            description=reason or normalized_title,
            metadata={"title": normalized_title},
        )
        updated_at = _utc_now()
        revision_id = f"goal:create:{uuid4().hex}"
        graph = self.repository.load_goal_graph(session_id) or build_goal_graph(session_id=session_id, goals=())
        root_goal_id = graph.root_goal_id or graph.active_goal_id or (graph.nodes[0].goal_id if graph.nodes else None)
        activate_goal = (status == "active") if activate is None else activate
        dependency_values = _coerce_str_tuple(dependency_refs) if dependency_refs is not None else ()
        evidence_values = _coerce_str_tuple(evidence_refs) if evidence_refs is not None else ()
        related_values = _coerce_str_tuple(related_memory_ids) if related_memory_ids is not None else ()
        new_goal = GoalGraphNode(
            goal_id=f"goal:{uuid4().hex[:12]}",
            session_id=session_id,
            title=normalized_title,
            status="active" if activate_goal else str(status),
            priority=str(priority),
            owner=owner,
            parent_goal_id=parent_goal_id if parent_goal_id is not None else (root_goal_id if graph.nodes else None),
            dependency_refs=dependency_values,
            evidence_refs=evidence_values,
            related_memory_ids=related_values,
            deadline=_optional_datetime(deadline),
            time_sensitivity="normal" if time_sensitivity is None else str(time_sensitivity),
            review_checkpoint=review_checkpoint,
            revision_id=revision_id,
            updated_at=updated_at,
        )
        active_goal = graph.active_goal()
        if activate_goal and active_goal is not None and active_goal.goal_id != new_goal.goal_id and active_goal.status == "active":
            graph = graph.transition_goal(
                active_goal.goal_id,
                status="queued",
                revision_id=revision_id,
                updated_at=updated_at,
                active_goal_id=active_goal.goal_id,
            )
        graph = graph.with_goal(new_goal)
        graph = replace(
            graph,
            root_goal_id=root_goal_id if root_goal_id is not None else new_goal.goal_id,
            active_goal_id=new_goal.goal_id if activate_goal else graph.active_goal_id,
            revision_id=revision_id,
            updated_at=updated_at,
        )
        self.repository.upsert_goal_graph(graph)
        created = graph.goal(new_goal.goal_id)
        if created is None:
            raise KeyError(new_goal.goal_id)
        return created.to_contract_goal()

    def update_goal(
        self,
        session_id: str,
        goal_id: str,
        *,
        title: str | None = None,
        status: str | None = None,
        priority: str | None = None,
        reason: str | None = None,
    ) -> tuple[GoalNode, GoalNode, str]:
        self._authorize_write(
            operation="cli.goal.update",
            session_id=session_id,
            description=reason or title or status or priority or goal_id,
            metadata={"goal_id": goal_id},
        )
        graph = self.repository.load_goal_graph(session_id)
        if graph is None:
            raise KeyError(session_id)
        goal = graph.goal(goal_id)
        if goal is None:
            raise KeyError(goal_id)
        before = goal.to_contract_goal()
        if status is not None:
            graph = graph.transition_goal(
                goal_id,
                status=status,
                revision_id=f"goal:update:{uuid4().hex}",
                updated_at=_utc_now(),
            )
            goal = graph.goal(goal_id)
            if goal is None:
                raise KeyError(goal_id)
        updated_goal = replace(
            goal,
            title=goal.title if title is None else title,
            priority=goal.priority if priority is None else priority,
            revision_id=f"goal:update:{uuid4().hex}",
            updated_at=_utc_now(),
        )
        graph = graph.with_goal(updated_goal)
        self.repository.upsert_goal_graph(graph)
        return before, updated_goal.to_contract_goal(), reason or "goal updated"

    def delete_goal(self, session_id: str, goal_id: str, *, reason: str) -> tuple[GoalNode, GoalNode]:
        self._authorize_write(
            operation="cli.goal.delete",
            session_id=session_id,
            description=reason,
            is_destructive=True,
            metadata={"goal_id": goal_id},
        )
        graph = self.repository.load_goal_graph(session_id)
        if graph is None:
            raise KeyError(session_id)
        goal = graph.goal(goal_id)
        if goal is None:
            raise KeyError(goal_id)
        before = goal.to_contract_goal()
        graph = graph.transition_goal(
            goal_id,
            status="dropped",
            revision_id=f"goal:delete:{uuid4().hex}",
            updated_at=_utc_now(),
        )
        self.repository.upsert_goal_graph(graph)
        updated = graph.goal(goal_id)
        if updated is None:
            raise KeyError(goal_id)
        return before, updated.to_contract_goal()

    def correct_memory(
        self,
        session_id: str,
        memory_id: str,
        *,
        corrected_content: str,
        reason: str = "",
    ) -> tuple[MemoryRecord | None, MemoryRecord | None, str, str | None]:
        self._authorize_write(
            operation="cli.memory.correct",
            session_id=session_id,
            description=reason or corrected_content,
            metadata={"memory_id": memory_id},
        )
        original = self.memory_runtime.store.get(memory_id)
        if original is None or original.session_id != session_id:
            raise KeyError(memory_id)
        result = self.memory_runtime.correct_memory(memory_id, corrected_content, reason=reason)
        corrected = result.record
        return original, corrected, result.decision.reason, self.memory_runtime.store.lineage(memory_id)

    def delete_memory(self, session_id: str, memory_id: str, *, reason: str) -> tuple[MemoryRecord, str | None]:
        self._authorize_write(
            operation="cli.memory.delete",
            session_id=session_id,
            description=reason,
            is_destructive=True,
            metadata={"memory_id": memory_id},
        )
        original = self.memory_runtime.store.get(memory_id)
        if original is None or original.session_id != session_id:
            raise KeyError(memory_id)
        result = self.memory_runtime.delete_memory(memory_id, reason=reason)
        return original, result.decision.reason

    def pin_memory(self, session_id: str, memory_id: str, *, reason: str = "") -> tuple[MemoryRecord, str]:
        self._authorize_write(
            operation="cli.memory.pin",
            session_id=session_id,
            description=reason or memory_id,
            metadata={"memory_id": memory_id},
        )
        record = self.memory_runtime.store.get(memory_id)
        if record is None or record.session_id != session_id:
            raise KeyError(memory_id)
        result = self.memory_runtime.pin_memory(memory_id, reason=reason)
        if result.record is None:
            raise RuntimeError(result.decision.reason)
        return result.record, result.decision.reason

    def unpin_memory(self, session_id: str, memory_id: str, *, reason: str = "") -> tuple[MemoryRecord, str]:
        self._authorize_write(
            operation="cli.memory.unpin",
            session_id=session_id,
            description=reason or memory_id,
            metadata={"memory_id": memory_id},
        )
        record = self.memory_runtime.store.get(memory_id)
        if record is None or record.session_id != session_id:
            raise KeyError(memory_id)
        result = self.memory_runtime.unpin_memory(memory_id, reason=reason)
        if result.record is None:
            raise RuntimeError(result.decision.reason)
        return result.record, result.decision.reason

    def memory_lineage(self, memory_id: str) -> str | None:
        return self.memory_runtime.store.lineage(memory_id)

    def memory_state(self, memory_id: str) -> str | None:
        return self.memory_runtime.store.state(memory_id)

    def _load_profile(self, profile_id: str) -> LoadedProfile:
        return self.profile_loader.load(profile_id=profile_id)

    def _load_session(self, session_id: str) -> SessionState:
        session = self.repository.load_session(session_id)
        if session is None:
            raise KeyError(session_id)
        return session

    def _load_profile_manifest(self) -> dict[str, Any]:
        manifest_path = self.paths.profile_dir / "profile.json"
        if not manifest_path.exists():
            return {}
        return json.loads(manifest_path.read_text(encoding="utf-8"))

    def _write_profile_manifest(self, manifest: Mapping[str, Any]) -> None:
        write_profile_manifest(self.paths.profile_dir, manifest)

    def _resolve_extension_profile_id(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> str:
        if session_id is not None:
            return self._load_session(session_id).profile_id
        if profile_id is not None:
            return profile_id
        return self.current_profile().state.profile_id

    def _install_skill_package_path(
        self,
        package_path: Path,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> SkillManifestLoadRecord:
        resolved_profile_id = self._resolve_extension_profile_id(session_id=session_id, profile_id=profile_id)
        target_profile = self._load_profile(resolved_profile_id)
        resolved_path = package_path.expanduser().resolve()
        if resolved_path.is_dir():
            resolved_path = resolved_path / "SKILL.md"
        if not resolved_path.exists():
            raise FileNotFoundError(resolved_path)
        profile_dir = Path(target_profile.profile_dir)
        manifest = dict(target_profile.manifest)
        extension_manifest = load_extension_manifest(manifest, profile_dir=profile_dir)
        existing_paths = list(extension_manifest.skill_package_paths)
        if resolved_path not in existing_paths:
            existing_paths.append(resolved_path)
        manifest["skill_packages"] = [
            serialize_manifest_path(path, profile_dir=profile_dir)
            for path in existing_paths
        ]
        write_profile_manifest(profile_dir, manifest)
        self._refresh_extensions(profile_id=resolved_profile_id)
        return self._skill_manifest_load_record(resolved_path)

    def _cron_scope(self, session_id: str) -> tuple[str, str]:
        session = self._load_session(session_id)
        return session.profile_id, self.clone_id_for_session(session)

    def _refresh_extensions(self, *, profile_id: str | None = None) -> None:
        if profile_id is None:
            loaded = self.current_profile()
        else:
            loaded = self._load_profile(profile_id)
        manifest_payload, removed_legacy_keys = sanitize_extension_manifest_payload(dict(loaded.manifest))
        if removed_legacy_keys:
            write_profile_manifest(Path(loaded.profile_dir), manifest_payload)
        self._apply_extension_manifest(
            load_extension_manifest(manifest_payload, profile_dir=Path(loaded.profile_dir))
        )

    def _apply_extension_manifest(self, manifest: CliExtensionManifest) -> None:
        object.__setattr__(
            self,
            "tool_runtime",
            build_tool_runtime(
                manifest,
                dependencies=BuiltinToolDependencies(
                    cwd=Path.cwd(),
                    cron_runtime=self.cron_runtime,
                    companion_management=self,
                    skill_management=self,
                    goal_management=self,
                    memory_management=self,
                    todo_store=self.todo_store,
                    browser_backend=self.browser_backend,
                    clarify_surface=StructuredClarifySurface(surface_label="cli"),
                ),
                snapshot_path=self.snapshot_path,
                security_policy=self.security_policy,
            ),
        )
        object.__setattr__(
            self,
            "skill_runtime",
            build_skill_runtime(
                manifest,
                repository=self.repository,
                profile_loader=self.profile_loader,
            ),
        )

    def _tool_manifest_load_record(self, manifest_path: Path) -> ToolManifestLoadRecord:
        for record in reversed(self.tool_runtime.list_manifest_loads()):
            if Path(record.source_path) == manifest_path:
                return record
        raise LookupError(f"tool manifest was not loaded: {manifest_path}")

    def _skill_manifest_load_record(self, manifest_path: Path) -> SkillManifestLoadRecord:
        for record in reversed(self.skill_runtime.list_manifest_loads()):
            if Path(record.source_path) == manifest_path:
                return record
        raise LookupError(f"skill manifest was not loaded: {manifest_path}")

    def _write_extension_override(
        self,
        section: str,
        item_id: str,
        enabled: bool,
        *,
        profile_id: str | None = None,
    ) -> None:
        loaded = self.current_profile() if profile_id is None else self._load_profile(profile_id)
        profile_dir = Path(loaded.profile_dir)
        manifest = dict(loaded.manifest)
        existing = manifest.get(section, {})
        overrides = dict(existing) if isinstance(existing, Mapping) else {}
        overrides[item_id] = {"enabled": enabled}
        manifest[section] = overrides
        write_profile_manifest(profile_dir, manifest)

    def _build_provider_payload(
        self,
        *,
        provider_id: str,
        base_url: str | None,
        default_model: str | None,
        auth_method: str | None,
        provider_kind: str | None,
        context_window_tokens: int | None,
        context_window_mode: str | None,
        extra_headers: Mapping[str, str] | None,
    ) -> dict[str, Any]:
        metadata: dict[str, str] = {}
        if context_window_mode is not None:
            metadata["context_window_mode"] = context_window_mode
        if context_window_tokens is not None:
            metadata["context_window_tokens"] = str(context_window_tokens)
        payload: dict[str, Any] = {
            "profile_id": f"provider-{provider_id}",
            "provider_id": provider_id,
            "secret_references": [],
            "metadata": metadata,
        }
        if provider_id == "openai-compatible":
            if base_url is None or default_model is None:
                raise ValueError("openai-compatible provider defaults require base_url and default_model")
            payload["base_url"] = base_url
            payload["default_model"] = default_model
        elif base_url is not None:
            payload["base_url"] = base_url
        if default_model is not None and provider_id != "openai-compatible":
            payload["default_model"] = default_model
        if auth_method is not None:
            payload["auth_method"] = auth_method
        if provider_kind is not None:
            payload["provider_kind"] = provider_kind
        if extra_headers:
            payload["extra_headers"] = dict(extra_headers)
        if self.provider_setup_guide(provider_id).required_secret_keys:
            payload["secret_references"] = [
                {
                    "reference_id": f"secret-{provider_id}-api-key",
                    "provider_id": provider_id,
                    "secret_name": "api_token",
                    "secret_key": "api_key",
                    "metadata": {"storage": "local-vault"},
                }
            ]
        return payload

    def _persist_profile(
        self,
        loaded_profile: LoadedProfile,
        *,
        clone_text: str | None | object = _PROFILE_TEXT_UNSET,
        friend_text: str | None | object = _PROFILE_TEXT_UNSET,
    ) -> LoadedProfile:
        manifest = profile_manifest_payload(
            loaded_profile,
            existing_manifest=loaded_profile.manifest,
        )
        profile_dir = Path(loaded_profile.profile_dir)
        resolved_clone_text = clone_text
        if resolved_clone_text is _PROFILE_TEXT_UNSET:
            resolved_clone_text = loaded_profile.clone_text
        resolved_friend_text = (
            loaded_profile.friend_text if friend_text is _PROFILE_TEXT_UNSET else friend_text
        )
        write_profile_manifest(profile_dir, manifest)
        write_clone_text(profile_dir, _normalized_profile_text(resolved_clone_text))
        write_friend_text(profile_dir, _normalized_profile_text(resolved_friend_text))
        reloaded = self._load_profile(
            profile_id=loaded_profile.state.profile_id,
        )
        self.repository.upsert_profile(reloaded.state)
        latest_session = self.latest_session()
        if latest_session is not None and latest_session.profile_id == reloaded.state.profile_id:
            self._write_snapshot(
                profile=reloaded.state,
                session=latest_session,
                goals=self.inspect_goals(latest_session.session_id),
                memories=self.inspect_memories(latest_session.session_id),
                plan=None,
                execution=None,
                delivery=None,
                stages=(),
                event=None,
                clone_text=reloaded.clone_text,
            )
        return reloaded

    def _build_voice_service(
        self,
        *,
        telemetry: Any = None,
        input_model_id: str = "gpt-4o-mini-transcribe",
        output_model_id: str = "gpt-4o-mini-tts",
        voice_name: str = "alloy",
    ):
        return build_provider_voice_service(
            provider_profile=self.model_provider.active_profile(),
            telemetry=telemetry,
            input_model_id=input_model_id,
            output_model_id=output_model_id,
            voice_name=voice_name,
        )

    def _build_kernel_dependencies(self, session: SessionState, profile: ProfileState) -> KernelDependencies:
        return _build_runtime_kernel_dependencies(
            self,
            session,
            profile,
            memory_capability_cls=_DurableMemoryCapability,
            context_capability_cls=_CliContextCapability,
            telemetry_cls=_PreviewTelemetrySink,
            delivery_capability_cls=_PreviewDeliveryCapability,
        )

    def _load_snapshot(self) -> dict[str, Any] | None:
        return _load_runtime_snapshot(self)

    def _append_outcome_memory(self, outcome: KernelOutcome) -> None:
        _append_runtime_outcome_memory(self, outcome)

    def _append_outcome_experience(self, outcome: KernelOutcome) -> ExperienceRecord | None:
        return _append_runtime_outcome_experience(self, outcome)

    def _append_outcome_growth(
        self,
        outcome: KernelOutcome,
        *,
        experience: ExperienceRecord | None,
    ) -> ProfileGrowthState:
        return _append_runtime_outcome_growth(
            self,
            outcome,
            experience=experience,
        )

    def _restore_goal(self, goal: Mapping[str, Any]) -> dict[str, Any]:
        payload = dict(goal)
        for field_name in ("dependencies", "evidence_refs"):
            value = payload.get(field_name)
            if value is not None:
                payload[field_name] = tuple(value)
        return payload

    def _write_snapshot(
        self,
        *,
        profile: ProfileState,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
        plan: PlanDraft | None,
        execution: ExecutionResult | None,
        delivery: ExecutionResult | None,
        stages: tuple[Any, ...],
        event: EventEnvelope | None,
        clone_text: str | None,
    ) -> None:
        _write_runtime_snapshot(
            self,
            profile=profile,
            session=session,
            goals=goals,
            memories=memories,
            plan=plan,
            execution=execution,
            delivery=delivery,
            stages=stages,
            event=event,
            clone_text=clone_text,
        )


def _goal_ids_for_memory_search(goal_graph: GoalGraph | None) -> tuple[str, ...]:
    if goal_graph is None:
        return ()
    goal_ids: list[str] = []
    if goal_graph.active_goal_id is not None:
        goal_ids.append(goal_graph.active_goal_id)
    active_goal = goal_graph.active_goal()
    if active_goal is not None and active_goal.parent_goal_id is not None:
        goal_ids.append(active_goal.parent_goal_id)
    for goal in goal_graph.nodes:
        if goal.status in {"active", "blocked", "queued", "proposed"}:
            goal_ids.append(goal.goal_id)
        if len(goal_ids) >= 5:
            break
    return tuple(dict.fromkeys(goal_ids))


def _memory_query_seed(goal_graph: GoalGraph | None) -> str:
    if goal_graph is None or not goal_graph.nodes:
        return "resume continuity next step"
    titles: list[str] = []
    active_goal = goal_graph.active_goal()
    if active_goal is not None:
        titles.append(active_goal.title)
    for goal in goal_graph.nodes:
        if goal.goal_id == goal_graph.active_goal_id:
            continue
        if goal.status in {"active", "blocked", "queued", "proposed"}:
            titles.append(goal.title)
        if len(titles) >= 3:
            break
    title_seed = " | ".join(title for title in titles if title)
    if not title_seed:
        return "resume continuity next step"
    return f"resume continuity next step {title_seed}"


def _load_snapshot_record(snapshot_path: Path | None) -> dict[str, Any] | None:
    if snapshot_path is None or not snapshot_path.exists():
        return None
    return json.loads(snapshot_path.read_text(encoding="utf-8"))


def _recent_hot_turns(snapshot_path: Path | None, *, session_id: str) -> tuple[str, ...]:
    snapshot = _load_snapshot_record(snapshot_path)
    if not snapshot:
        return ()
    session = snapshot.get("session")
    if not isinstance(session, Mapping) or str(session.get("session_id") or "") != session_id:
        return ()

    turns: list[str] = []
    event = snapshot.get("event")
    if isinstance(event, Mapping):
        payload = event.get("payload")
        if isinstance(payload, Mapping):
            message = str(payload.get("message") or payload.get("content") or payload.get("summary") or "").strip()
            if message:
                turns.append(f"user: {message}")

    execution = snapshot.get("execution")
    if isinstance(execution, Mapping):
        summary = str(execution.get("summary") or "").strip()
        if summary:
            turns.append(f"aegis: {summary}")

    delivery = snapshot.get("delivery")
    if isinstance(delivery, Mapping):
        summary = str(delivery.get("summary") or "").strip()
        if summary:
            turns.append(f"delivery: {summary}")

    return tuple(turns[:4])


@dataclass(frozen=True, slots=True)
class _DurableMemoryCapability:
    memory_runtime: MemoryRuntime
    repository: RuntimeStorageRepository
    descriptor: CapabilityDescriptor = CapabilityDescriptor(
        capability_id="cli.memory.runtime",
        kind="memory",
        version="1.0.0",
        metadata={"description": "Repo-backed memory adapter for CLI kernel flows."},
    )

    def record(self, memory: MemoryRecord) -> None:
        self.memory_runtime.store.upsert(memory)

    def search(self, session_id: str, query: str) -> tuple[MemoryRecord, ...]:
        goal_graph = self.repository.load_goal_graph(session_id)
        goal_ids = _goal_ids_for_memory_search(goal_graph)
        resolved_query = query.strip() or _memory_query_seed(goal_graph)
        result = self.memory_runtime.retrieve(
            session_id,
            resolved_query,
            goal_ids=goal_ids,
        )
        return tuple(candidate.record for candidate in result.candidates)


@dataclass(frozen=True, slots=True)
class _PreviewMemoryCapability:
    session: SessionState
    snapshot_path: Path
    descriptor: Any = None

    def search(self, session_id: str, query: str) -> tuple[MemoryRecord, ...]:
        snapshot = self._load_snapshot()
        if snapshot is not None:
            memories = snapshot.get("memories", ())
            if memories:
                return tuple(MemoryRecord(**self._restore_memory(memory)) for memory in memories)
        now = _utc_now()
        return (
            MemoryRecord(
                memory_id=f"memory:{session_id}:profile",
                session_id=session_id,
                kind="semantic",
                content=f"Profile continuity is bound to {self.session.profile_id}.",
                goal_refs=(),
                tags=("profile", "continuity"),
                created_at=now,
            ),
            MemoryRecord(
                memory_id=f"memory:{session_id}:query",
                session_id=session_id,
                kind="episodic",
                content=f"Most recent query: {query}",
                source_event_id=None,
                goal_refs=(),
                tags=("query",),
                created_at=now,
            ),
        )

    def _load_snapshot(self) -> dict[str, Any] | None:
        if not self.snapshot_path.exists():
            return None
        return json.loads(self.snapshot_path.read_text(encoding="utf-8"))

    def _restore_memory(self, memory: Mapping[str, Any]) -> dict[str, Any]:
        payload = dict(memory)
        created_at = payload.get("created_at")
        if created_at is not None:
            payload["created_at"] = _restore_datetime(str(created_at))
        for field_name in ("goal_refs", "tags"):
            value = payload.get(field_name)
            if value is not None:
                payload[field_name] = tuple(value)
        return payload


@dataclass(frozen=True, slots=True)
class _CliContextCapability:
    profile_loader: ProfileLoader
    repository: RuntimeStorageRepository
    prompt_mode: PromptMode = "full"
    snapshot_path: Path | None = None
    total_tokens: int = 4096
    tool_runtime: ToolRuntime | None = None
    skill_runtime: SkillRuntime | None = None
    descriptor: CapabilityDescriptor = CapabilityDescriptor(
        capability_id="cli.context.runtime",
        kind="context_assembler",
        version="1.0.0",
        metadata={"description": "CLI context runtime with Aegis identity and durable profile instructions."},
    )

    def assemble(
        self,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
    ) -> ContextBundle:
        loaded = self.profile_loader.load(profile_id=session.profile_id)
        return self._assemble_bundle(
            session=session,
            goals=goals,
            memories=memories,
            loaded=loaded,
            artifacts=self._capability_artifacts(
                session,
                loaded,
                goals=goals,
                memories=memories,
            ),
        )

    def augment_for_generation(
        self,
        *,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
        context: ContextBundle,
        decision: PlanningDecision | None,
        plan: PlanDraft | None,
        continuity: SessionContinuityState,
    ) -> ContextBundle:
        loaded = self.profile_loader.load(profile_id=session.profile_id)
        return self._assemble_bundle(
            session=session,
            goals=goals,
            memories=memories,
            loaded=loaded,
            artifacts=self._capability_artifacts(
                session,
                loaded,
                goals=goals,
                memories=memories,
                decision=decision,
                plan=plan,
                continuity=continuity,
            ),
            bundle_id=context.bundle_id,
        )

    def _assemble_bundle(
        self,
        *,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
        loaded: LoadedProfile,
        artifacts: tuple[str, ...],
        bundle_id: str | None = None,
    ) -> ContextBundle:
        prompt_contract = build_prompt_contract(loaded, prompt_mode=self.prompt_mode)
        runtime = ContextRuntime(
            instruction_refs=prompt_contract.instruction_refs,
            total_tokens=max(1024, self.total_tokens),
        )
        hot_turns = _recent_hot_turns(self.snapshot_path, session_id=session.session_id)
        assembled = runtime.assemble_detailed(session, goals, memories, hot_turns=hot_turns, artifacts=artifacts)
        return replace(
            assembled.bundle,
            bundle_id=bundle_id or f"bundle:{session.session_id}:{len(goals)}:{len(memories)}",
            instruction_refs=prompt_contract.instruction_refs,
        )

    def _capability_artifacts(
        self,
        session: SessionState,
        loaded: LoadedProfile,
        *,
        goals: tuple[GoalNode, ...] = (),
        memories: tuple[MemoryRecord, ...] = (),
        decision: PlanningDecision | None = None,
        plan: PlanDraft | None = None,
        continuity: SessionContinuityState | None = None,
    ) -> tuple[str, ...]:
        artifacts = list(
            self._generation_artifacts(
                goals=goals,
                memories=memories,
                decision=decision,
                plan=plan,
                continuity=continuity,
            )
        )
        if self.tool_runtime is not None:
            enabled_tools = self.tool_runtime.list_tools(
                audience="model",
                enabled_only=True,
                available_only=True,
            )
            if enabled_tools:
                tool_lines = "; ".join(
                    f"{tool.display_name} ({tool.tool_id}): {tool.description}"
                    for tool in enabled_tools
                )
                artifacts.append(
                    "available-tools: governed built-ins are available through the runtime; "
                    f"{tool_lines}"
                )
                artifacts.append(
                    "tool-call-protocol: call governed built-in tools directly when the active provider supports native "
                    "tool calling. Otherwise emit <tool_call><invoke name=\"tool.id\"><parameter name=\"arg\">value"
                    "</parameter></invoke></tool_call>; multiple invoke blocks are allowed, structured values may be "
                    "encoded as JSON inside a parameter body, and the final answer must not include raw tool markup."
                )
                artifacts.append(
                    "tool-parameter-schemas: " + " ".join(tool.prompt_summary() for tool in enabled_tools)
                )
        if self.skill_runtime is not None:
            active_skills = self.skill_runtime.resolve_for_context(
                profile_id=loaded.state.profile_id,
                workspace_id=session.workspace_id,
                session_id=session.session_id,
                mode=loaded.state.mode,
            )
            if active_skills:
                skill_lines = "; ".join(
                    f"{skill.display_name} ({skill.skill_id}): {skill.summary}"
                    for skill in active_skills
                )
                artifacts.append(
                    "active-skills: these profile-scoped guidance packages shape the session; "
                    f"{skill_lines}"
                )
                instructional_skills = [
                    skill for skill in active_skills if skill.instruction_text.strip()
                ]
                if instructional_skills:
                    instruction_lines = "; ".join(
                        f"{skill.display_name} ({skill.skill_id}): "
                        f"{_compact_runtime_text(skill.instruction_text, limit=220)}"
                        for skill in instructional_skills[:3]
                    )
                    artifacts.append(
                        "active-skill-instructions: the following installed skill packages add live procedural guidance; "
                        f"{instruction_lines}"
                    )
        active_run = self.repository.load_latest_open_agent_run(session.session_id)
        if active_run is not None:
            artifacts.append(
                "active-agent-run: there is unfinished long-horizon work in flight; "
                f"run={active_run.run_id}; status={active_run.status}; "
                f"objective={_compact_runtime_text(active_run.prompt, limit=180)}; "
                f"checkpoint={_compact_runtime_text(active_run.last_summary or active_run.waiting_reason or '<empty>', limit=220)}"
            )
            recent_steps = self.repository.list_agent_run_steps(active_run.run_id, limit=4)
            if recent_steps:
                step_lines = "; ".join(
                    f"{step.kind} {step.title}: {_compact_runtime_text(step.content, limit=120)}"
                    for step in recent_steps
                )
                artifacts.append(f"active-agent-run-steps: {step_lines}")
        return tuple(artifacts)

    def _generation_artifacts(
        self,
        *,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
        decision: PlanningDecision | None,
        plan: PlanDraft | None,
        continuity: SessionContinuityState | None,
    ) -> tuple[str, ...]:
        active_goal = _goal_for_generation(goals, decision)
        artifacts = [
            _decision_artifact(decision),
            _active_goal_artifact(active_goal, continuity=continuity),
            _memory_summary_artifact(memories),
        ]
        if plan is not None and plan.steps:
            step = plan.steps[0]
            artifacts.append(
                "runtime-plan-step: "
                f"{step.title}; rationale={_compact_runtime_text(step.rationale, limit=160)}"
            )
        return tuple(artifacts)


def _goal_for_generation(
    goals: tuple[GoalNode, ...],
    decision: PlanningDecision | None,
) -> GoalNode | None:
    preferred_goal_ids = (
        decision.rationale.planned_active_goal_id if decision is not None else None,
        decision.selected_move.goal_id if decision is not None else None,
    )
    for goal_id in preferred_goal_ids:
        if not goal_id:
            continue
        for goal in goals:
            if goal.goal_id == goal_id:
                return goal
    for goal in goals:
        if goal.status == "active":
            return goal
    return goals[0] if goals else None


def _decision_artifact(decision: PlanningDecision | None) -> str:
    if decision is None:
        return "runtime-planning-decision: no durable planning decision was selected for this turn."
    return (
        "runtime-planning-decision: "
        f"kind={decision.selected_move.kind}; "
        f"goal={decision.selected_move.goal_id or '<none>'}; "
        f"planned-active-goal={decision.rationale.planned_active_goal_id or '<none>'}; "
        f"rationale={_compact_runtime_text(decision.rationale.summary, limit=180)}"
    )


def _active_goal_artifact(
    goal: GoalNode | None,
    *,
    continuity: SessionContinuityState | None,
) -> str:
    continuity_hint = ""
    if continuity is not None and continuity.requires_recovery:
        continuity_hint = f"; continuity={_compact_runtime_text(continuity.summary, limit=120)}"
    if goal is None:
        return f"runtime-active-goal: <none>{continuity_hint}"
    return (
        "runtime-active-goal: "
        f"{goal.goal_id} -> {goal.title} [{goal.status}/{goal.priority}]"
        f"{continuity_hint}"
    )


def _memory_summary_artifact(memories: tuple[MemoryRecord, ...], *, limit: int = 3) -> str:
    if not memories:
        return "recovered-memory-summary: no durable memories were retrieved for this turn."
    preview = memories[:limit]
    entries = "; ".join(
        f"{memory.memory_id} [{memory.kind}] {_compact_runtime_text(memory.content, limit=90)}"
        for memory in preview
    )
    remainder = len(memories) - len(preview)
    suffix = f"; +{remainder} more" if remainder > 0 else ""
    return f"recovered-memory-summary: {len(memories)} retrieved for this turn; {entries}{suffix}"


def _compact_runtime_text(value: str, *, limit: int) -> str:
    compact = " ".join(value.split())
    if len(compact) <= limit:
        return compact
    return compact[: max(0, limit - 1)].rstrip() + "…"


@dataclass(frozen=True, slots=True)
class _PreviewModelProviderCapability:
    descriptor: Any = None

    def generate(
        self,
        *,
        profile: ProfileState,
        session: SessionState,
        context: ContextBundle,
        prompt: str,
    ) -> ExecutionResult:
        summary = (
            f"Next step for {profile.display_name} in {session.session_id}: "
            f"continue from {len(context.goal_ids)} goal(s) and {len(context.memory_ids)} memory item(s)."
        )
        return ExecutionResult(
            execution_id=f"exec:{session.session_id}:{uuid4().hex[:8]}",
            session_id=session.session_id,
            outcome="ok",
            summary=summary,
            prompt_tokens=len(prompt.split()),
            completion_tokens=len(summary.split()),
            total_tokens=len(prompt.split()) + len(summary.split()),
        )


@dataclass(frozen=True, slots=True)
class _PreviewTelemetrySink:
    snapshot_path: Path
    descriptor: Any = None

    def emit(self, event: Mapping[str, Any]) -> None:
        existing = {}
        if self.snapshot_path.exists():
            existing = json.loads(self.snapshot_path.read_text(encoding="utf-8"))
        telemetry = list(existing.get("telemetry", ()))
        telemetry.append(dict(event))
        existing["telemetry"] = telemetry
        self.snapshot_path.parent.mkdir(parents=True, exist_ok=True)
        self.snapshot_path.write_text(json.dumps(existing, indent=2, sort_keys=True), encoding="utf-8")


@dataclass(frozen=True, slots=True)
class _PreviewToolCapability:
    descriptor: Any = None

    def invoke(
        self,
        tool_name: str,
        arguments: Mapping[str, Any],
        *,
        session_id: str,
    ) -> ExecutionResult:
        summary = f"invoked {tool_name} with {dict(arguments)}"
        return ExecutionResult(
            execution_id=f"tool:{session_id}:{tool_name}",
            session_id=session_id,
            outcome="ok",
            summary=summary,
            side_effects=(tool_name,),
        )


@dataclass(frozen=True, slots=True)
class _PreviewDeliveryCapability:
    descriptor: Any = None

    def deliver(
        self,
        session_id: str,
        payload: Mapping[str, Any],
    ) -> ExecutionResult:
        return ExecutionResult(
            execution_id=f"delivery:{session_id}:{uuid4().hex[:8]}",
            session_id=session_id,
            outcome="ok",
            summary=f"delivered {payload.get('event_id', 'event')}",
        )
