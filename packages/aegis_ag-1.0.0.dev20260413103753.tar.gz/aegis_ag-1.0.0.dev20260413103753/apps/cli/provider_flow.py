from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .wizard import (
    WIZARD_BACK,
    WizardChoice,
    _WizardBackSignal,
    _wizard_choice_prompt,
    _wizard_text_prompt,
)

if TYPE_CHECKING:
    from .runtime import CliRuntime


PROVIDER_EMOJIS = {
    "openai": "🤖",
    "anthropic": "🧭",
    "openrouter": "🌐",
    "openai-compatible": "🔌",
    "google": "🔎",
    "groq": "⚡",
    "deepseek": "🔍",
    "xai": "🚀",
    "mistral": "🌬️",
    "together": "🤝",
    "fireworks": "🎆",
    "moonshot": "🌙",
    "minimax": "🎭",
    "ollama": "🦙",
    "vllm": "🧠",
}
DEFAULT_CONTEXT_WINDOW_TOKENS = 128_000
MANUAL_MODEL_SENTINEL = "__manual_model__"


@dataclass(slots=True)
class ProviderSelectionState:
    provider_id: str
    base_url: str
    api_key: str | None
    default_model: str
    context_window_mode: str
    context_window_tokens: int | None


def provider_setup_defaults(runtime: CliRuntime, provider_id: str) -> ProviderSelectionState:
    guide = runtime.provider_setup_guide(provider_id)
    summary = dict(runtime.provider_summary())
    same_provider = str(summary.get("provider_id", "")) == provider_id
    base_url = str(
        (summary.get("base_url") if same_provider else None)
        or guide.suggested_base_url
        or ""
    ).strip()
    default_model = str(
        (summary.get("default_model") if same_provider else None)
        or guide.suggested_model_id
        or ""
    ).strip()
    context_window_tokens = None
    if same_provider and summary.get("context_window_tokens") is not None:
        try:
            context_window_tokens = int(summary["context_window_tokens"])
        except (TypeError, ValueError):
            context_window_tokens = None
    context_window_mode = str(
        (summary.get("context_window_mode") if same_provider else None)
        or "auto"
    )
    return ProviderSelectionState(
        provider_id=provider_id,
        base_url=base_url,
        api_key=None,
        default_model=default_model,
        context_window_mode=context_window_mode,
        context_window_tokens=context_window_tokens,
    )


def provider_choices(runtime: CliRuntime) -> tuple[WizardChoice, ...]:
    return tuple(
        WizardChoice(
            value=record.provider_id,
            label=record.display_name,
            detail=record.catalog_summary,
            emoji=PROVIDER_EMOJIS.get(record.provider_id, "🧠"),
        )
        for record in runtime.provider_catalog()
    )


def run_provider_selection_wizard(
    runtime: CliRuntime,
    *,
    initial_state: ProviderSelectionState,
    allow_back: bool = False,
    provider_locked: bool = False,
) -> ProviderSelectionState | _WizardBackSignal:
    state = ProviderSelectionState(
        provider_id=initial_state.provider_id,
        base_url=initial_state.base_url,
        api_key=initial_state.api_key,
        default_model=initial_state.default_model,
        context_window_mode=initial_state.context_window_mode,
        context_window_tokens=initial_state.context_window_tokens,
    )
    steps = [
        "provider_id",
        "base_url",
        "api_key",
        "default_model",
        "context_window_mode",
        "context_window_tokens",
    ]
    if provider_locked:
        steps.remove("provider_id")
    step_index = 0
    while step_index < len(steps):
        step = steps[step_index]
        if step == "provider_id":
            answer = _wizard_choice_prompt(
                "Choose A Provider",
                "Where should Aegis think from next?",
                provider_choices(runtime),
                default=state.provider_id,
                allow_back=allow_back,
            )
            if answer is WIZARD_BACK:
                return WIZARD_BACK
            selected_provider = str(answer)
            if selected_provider != state.provider_id:
                state = provider_setup_defaults(runtime, selected_provider)
            step_index += 1
            continue

        guide = runtime.provider_setup_guide(state.provider_id)
        summary = dict(runtime.provider_summary())
        same_provider = str(summary.get("provider_id", "")) == state.provider_id
        has_stored_secret = same_provider and summary.get("secret_status") == "stored"

        if step == "base_url":
            if "base_url" not in guide.required_config_keys:
                step_index += 1
                continue
            answer = _wizard_text_prompt(
                "Set The Endpoint",
                "What endpoint should Aegis call?",
                default=state.base_url,
                allow_back=allow_back and step_index > 0,
            )
            if answer is WIZARD_BACK:
                step_index -= 1
                continue
            state.base_url = str(answer).strip()
            step_index += 1
            continue

        if step == "api_key":
            if not guide.required_secret_keys:
                state.api_key = None
                step_index += 1
                continue
            prompt = (
                "Enter the provider API key. Leave it blank to keep the encrypted key already stored for this provider."
                if has_stored_secret
                else "Enter the provider API key. Aegis stores it encrypted and will not ask again next time."
            )
            answer = _wizard_text_prompt(
                "Store The Provider Key",
                prompt,
                default=None,
                allow_back=allow_back and step_index > 0,
                password=True,
            )
            if answer is WIZARD_BACK:
                step_index -= 1
                continue
            entered = str(answer).strip()
            if entered:
                state.api_key = entered
                step_index += 1
                continue
            if has_stored_secret:
                state.api_key = None
                step_index += 1
                continue
            continue

        if step == "default_model":
            models = ()
            try:
                models = runtime.discover_provider_models(
                    provider_id=state.provider_id,
                    base_url=state.base_url or None,
                    api_key=state.api_key,
                )
            except Exception:
                models = ()
            if models:
                model_choices = tuple(
                    WizardChoice(
                        value=model.model_id,
                        label=model.model_id,
                        detail=_model_detail(model.context_window_tokens, model.max_output_tokens),
                    )
                    for model in models
                ) + (
                    WizardChoice(
                        value=MANUAL_MODEL_SENTINEL,
                        label="Manual model id",
                        detail="Type a model id that is not advertised by /v1/models.",
                    ),
                )
                default_value = (
                    state.default_model
                    if any(model.model_id == state.default_model for model in models)
                    else models[0].model_id
                )
                answer = _wizard_choice_prompt(
                    "Choose The Model",
                    "Pick one of the models exposed by the provider endpoint.",
                    model_choices,
                    default=default_value,
                    allow_back=allow_back and step_index > 0,
                )
                if answer is WIZARD_BACK:
                    step_index -= 1
                    continue
                selected = str(answer)
                if selected == MANUAL_MODEL_SENTINEL:
                    manual = _wizard_text_prompt(
                        "Type A Model Id",
                        "Enter the exact model id Aegis should use.",
                        default=state.default_model,
                        allow_back=allow_back and step_index > 0,
                    )
                    if manual is WIZARD_BACK:
                        continue
                    state.default_model = str(manual).strip()
                else:
                    state.default_model = selected
            else:
                answer = _wizard_text_prompt(
                    "Choose The Model",
                    "Aegis could not read /v1/models here, so enter the exact model id manually.",
                    default=state.default_model,
                    allow_back=allow_back and step_index > 0,
                )
                if answer is WIZARD_BACK:
                    step_index -= 1
                    continue
                state.default_model = str(answer).strip()
            step_index += 1
            continue

        if step == "context_window_mode":
            detected = runtime.detect_provider_context_window(
                provider_id=state.provider_id,
                model_id=state.default_model,
                base_url=state.base_url or None,
                api_key=state.api_key,
            )
            auto_value = detected or state.context_window_tokens or DEFAULT_CONTEXT_WINDOW_TOKENS
            answer = _wizard_choice_prompt(
                "Choose The Context Window",
                "How should Aegis size the model context budget?",
                (
                    WizardChoice(
                        value="auto",
                        label="Auto-detect",
                        detail=f"Use live endpoint metadata when available ({_format_context_tokens(auto_value)}).",
                    ),
                    WizardChoice(
                        value="manual",
                        label="Manual entry",
                        detail="Type the model's context window yourself.",
                    ),
                ),
                default=state.context_window_mode or "auto",
                allow_back=allow_back and step_index > 0,
            )
            if answer is WIZARD_BACK:
                step_index -= 1
                continue
            state.context_window_mode = str(answer)
            if state.context_window_mode == "auto":
                state.context_window_tokens = auto_value
            step_index += 1
            continue

        if step == "context_window_tokens":
            if state.context_window_mode != "manual":
                step_index += 1
                continue
            detected = runtime.detect_provider_context_window(
                provider_id=state.provider_id,
                model_id=state.default_model,
                base_url=state.base_url or None,
                api_key=state.api_key,
            )
            default_tokens = str(state.context_window_tokens or detected or DEFAULT_CONTEXT_WINDOW_TOKENS)
            answer = _wizard_text_prompt(
                "Enter The Context Window",
                "How many tokens of context should Aegis budget for this model?",
                default=default_tokens,
                allow_back=allow_back and step_index > 0,
            )
            if answer is WIZARD_BACK:
                step_index -= 1
                continue
            try:
                parsed = int(str(answer).strip().replace(",", ""))
            except ValueError:
                continue
            if parsed <= 0:
                continue
            state.context_window_tokens = parsed
            step_index += 1
            continue

    return state


def _format_context_tokens(value: int) -> str:
    if value >= 1_000_000 and value % 1_000_000 == 0:
        return f"{value // 1_000_000}M"
    if value >= 1_000 and value % 1_000 == 0:
        return f"{value // 1_000}K"
    if value >= 1024:
        return f"{round(value / 1024)}K"
    return str(value)


def _model_detail(context_window_tokens: int | None, max_output_tokens: int | None) -> str:
    bits = []
    if context_window_tokens is not None:
        bits.append(f"context {_format_context_tokens(context_window_tokens)}")
    if max_output_tokens is not None:
        bits.append(f"output {_format_context_tokens(max_output_tokens)}")
    if not bits:
        return "Live /v1/models entry"
    return " · ".join(bits)
