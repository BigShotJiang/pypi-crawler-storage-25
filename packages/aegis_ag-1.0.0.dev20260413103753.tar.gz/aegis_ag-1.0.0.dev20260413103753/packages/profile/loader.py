"""Filesystem profile loader.

The profile package owns long-lived identity state. A profile directory may
contain a ``profile.json`` manifest for stable preferences, a mutable
``CLONE.md`` for clone-specific persona, and a mutable ``FRIEND.md`` for
durable user-facing facts. The immutable Aegis charter lives in the packaged
``AEGIS.md`` file shipped with the repo.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import quote

from packages.contracts.runtime import ProfileState
from .files import (
    AEGIS_FILENAME,
    CLONE_FILENAME,
    FRIEND_FILENAME,
    PROFILE_BUNDLES_DIRNAME,
    PROFILE_MANIFEST_FILENAME,
    clone_text_path,
    friend_text_path,
    load_clone_text_file,
    profile_bundle_has_content,
    profile_manifest_path,
    write_clone_text_file,
    write_friend_text_file,
    write_profile_manifest_file,
)
from .policy import HerModeSettings, infer_personality_preset_id, resolve_personality_preset


@dataclass(frozen=True, slots=True)
class LoadedProfile:
    state: ProfileState
    her_mode: HerModeSettings | None
    profile_dir: str
    manifest_path: str | None
    clone_text: str | None = None
    friend_text: str | None = None
    aegis_path: str | None = None
    friend_path: str | None = None
    manifest: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ProfileLoader:
    profile_dir: Path

    def load(
        self,
        *,
        profile_id: str | None = None,
        display_name: str | None = None,
        mode: str | None = None,
    ) -> LoadedProfile:
        bundle_dir = resolve_profile_bundle_dir(self.profile_dir, profile_id)
        manifest_path = profile_manifest_path(bundle_dir)
        manifest = self._load_manifest(manifest_path)
        clone_path = clone_text_path(bundle_dir)
        friend_path = friend_text_path(bundle_dir)
        clone_text = load_clone_text_file(bundle_dir)
        friend_text = self._load_optional_text(friend_path)

        resolved_profile_id = profile_id or str(manifest.get("profile_id") or bundle_dir.name)
        resolved_display_name = (
            display_name
            or str(manifest.get("display_name") or resolved_profile_id.replace("-", " ").title())
        )
        if mode is not None:
            resolved_mode = mode
        elif manifest.get("mode") is not None:
            resolved_mode = str(manifest["mode"])
        elif manifest.get("her_mode") is not None:
            resolved_mode = "her"
        else:
            resolved_mode = "default"
        preferences = self._normalize_sequence(manifest.get("preferences", ()))
        enabled_capabilities = self._normalize_sequence(
            manifest.get("enabled_capabilities", ())
        )
        her_mode = self._load_her_mode(manifest.get("her_mode"), resolved_mode)

        state = ProfileState(
            profile_id=resolved_profile_id,
            display_name=resolved_display_name,
            mode=resolved_mode,
            clone_path=str(clone_path),
            preferences=preferences,
            enabled_capabilities=enabled_capabilities,
        )
        return LoadedProfile(
            state=state,
            her_mode=her_mode,
            profile_dir=str(bundle_dir),
            manifest_path=str(manifest_path) if manifest_path.exists() else None,
            clone_text=clone_text,
            friend_text=friend_text,
            aegis_path=str(packaged_aegis_path()),
            friend_path=str(friend_path),
            manifest=dict(manifest),
        )

    def load_state(
        self,
        *,
        profile_id: str | None = None,
        display_name: str | None = None,
        mode: str | None = None,
    ) -> ProfileState:
        return self.load(
            profile_id=profile_id,
            display_name=display_name,
            mode=mode,
        ).state

    def _load_manifest(self, manifest_path: Path) -> dict[str, Any]:
        if not manifest_path.exists():
            return {}
        with manifest_path.open("r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if not isinstance(payload, dict):
            raise ValueError(f"{manifest_path} must contain a JSON object")
        return payload

    def _load_optional_text(self, path: Path) -> str | None:
        if not path.exists():
            return None
        return path.read_text(encoding="utf-8")

    def _normalize_sequence(self, value: Any) -> tuple[str, ...]:
        if value is None:
            return ()
        if isinstance(value, str):
            return (value,)
        if not isinstance(value, (list, tuple)):
            raise ValueError("profile manifest sequence values must be arrays or strings")
        return tuple(str(item) for item in value)

    def _load_her_mode(self, value: Any, resolved_mode: str) -> HerModeSettings | None:
        if value is None and resolved_mode != "her":
            return None
        payload = value or {}
        if not isinstance(payload, dict):
            raise ValueError("her_mode manifest value must be a JSON object")
        raw_preset = str(payload.get("personality_preset") or "").strip() or None
        personality = self._normalize_sequence(payload.get("personality"))
        if personality:
            personality_preset = raw_preset or infer_personality_preset_id(personality, mode=resolved_mode)
        else:
            preset = resolve_personality_preset(raw_preset, mode=resolved_mode)
            personality_preset = preset.preset_id
            personality = preset.traits
        notes = self._normalize_sequence(payload.get("notes", ()))
        return HerModeSettings(
            text_first=bool(payload.get("text_first", True)),
            personality_preset=personality_preset,
            personality=personality,
            initiative=str(payload.get("initiative", "gentle")),
            preserve_relationship_timeline=bool(payload.get("preserve_relationship_timeline", True)),
            preserve_preferences=bool(payload.get("preserve_preferences", True)),
            preserve_corrections=bool(payload.get("preserve_corrections", True)),
            preserve_emotional_context=bool(payload.get("preserve_emotional_context", True)),
            allow_voice_extension=bool(payload.get("allow_voice_extension", False)),
            notes=notes,
        )


def her_mode_manifest_payload(her_mode: HerModeSettings | None) -> dict[str, Any] | None:
    if her_mode is None:
        return None
    return {
        "text_first": her_mode.text_first,
        "personality_preset": her_mode.personality_preset,
        "personality": list(her_mode.personality),
        "initiative": her_mode.initiative,
        "preserve_relationship_timeline": her_mode.preserve_relationship_timeline,
        "preserve_preferences": her_mode.preserve_preferences,
        "preserve_corrections": her_mode.preserve_corrections,
        "preserve_emotional_context": her_mode.preserve_emotional_context,
        "allow_voice_extension": her_mode.allow_voice_extension,
        "notes": list(her_mode.notes),
    }


def profile_manifest_payload(
    loaded_profile: LoadedProfile,
    *,
    existing_manifest: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    manifest = dict(existing_manifest or {})
    manifest["profile_id"] = loaded_profile.state.profile_id
    manifest["display_name"] = loaded_profile.state.display_name
    manifest["mode"] = loaded_profile.state.mode
    manifest["preferences"] = list(loaded_profile.state.preferences)
    manifest["enabled_capabilities"] = list(loaded_profile.state.enabled_capabilities)
    her_mode_payload = her_mode_manifest_payload(loaded_profile.her_mode)
    if her_mode_payload is None:
        manifest.pop("her_mode", None)
    else:
        manifest["her_mode"] = her_mode_payload
    return manifest


def profile_bundle_dir(profile_root: Path, profile_id: str) -> Path:
    key = quote(profile_id, safe="")
    return profile_root / PROFILE_BUNDLES_DIRNAME / key


def resolve_profile_bundle_dir(profile_root: Path, profile_id: str | None) -> Path:
    if profile_id is None:
        return profile_root
    candidate = profile_bundle_dir(profile_root, profile_id)
    if profile_bundle_has_content(candidate):
        return candidate
    return profile_root


def write_profile_manifest(profile_dir: Path, manifest: Mapping[str, Any]) -> Path:
    return write_profile_manifest_file(profile_dir, manifest)


def write_clone_text(profile_dir: Path, clone_text: str | None) -> Path:
    return write_clone_text_file(profile_dir, clone_text)


def write_friend_text(profile_dir: Path, friend_text: str | None) -> Path:
    return write_friend_text_file(profile_dir, friend_text)


def packaged_aegis_path() -> Path:
    return Path(__file__).with_name(AEGIS_FILENAME)


def load_packaged_aegis_text() -> str:
    path = packaged_aegis_path()
    if not path.exists():
        raise FileNotFoundError(f"missing packaged AEGIS charter: {path}")
    return path.read_text(encoding="utf-8")
