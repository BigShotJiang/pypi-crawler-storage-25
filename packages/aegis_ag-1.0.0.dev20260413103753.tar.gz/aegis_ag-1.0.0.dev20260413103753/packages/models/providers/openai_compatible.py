"""Generic OpenAI-compatible provider adapter.

This module provides one reusable path for endpoints that speak the common
OpenAI-compatible request shape. The adapter stays provider-neutral at the
kernel boundary while still exposing the transport, credential, and endpoint
metadata needed by product surfaces and integration tests.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping

from packages.contracts.runtime import ExecutionToolCall

from ..provider_runtime import ProviderRuntimeResolution, ProviderRuntimeResolver
from ..runtime import CredentialSource, ModelAdapterDescriptor, ModelEmbeddingResult, ModelRequest, ModelTextResult, ModelUsage
from .identity_contract import build_provider_identity_contract
from .http import JSONHTTPTransport, UrllibJSONHTTPTransport


@dataclass(frozen=True, slots=True)
class OpenAICompatibleProviderConfig:
    provider_id: str = "openai-compatible"
    base_url: str = ""
    model_id: str = ""
    extra_headers: Mapping[str, str] = field(default_factory=dict)
    auth_header_name: str = "Authorization"
    auth_scheme: str = "Bearer"

    def __post_init__(self) -> None:
        if not self.base_url:
            raise ValueError("base_url is required for an OpenAI-compatible provider")
        if not self.model_id:
            raise ValueError("model_id is required for an OpenAI-compatible provider")


@dataclass(frozen=True, slots=True)
class OpenAICompatibleRequestPlan:
    request_id: str
    provider_id: str
    model_id: str
    base_url: str
    endpoint_path: str
    url: str
    request_family: str
    transport_id: str
    headers: Mapping[str, str] = field(default_factory=dict)
    payload: Mapping[str, Any] = field(default_factory=dict)
    credential_keys: tuple[str, ...] = ()
    metadata: Mapping[str, str] = field(default_factory=dict)


class OpenAICompatibleProviderAdapter:
    """Plan and execute requests for OpenAI-compatible and OpenAI transports."""

    def __init__(
        self,
        *,
        config: OpenAICompatibleProviderConfig,
        runtime_resolver: ProviderRuntimeResolver | None = None,
        credential_source: CredentialSource | None = None,
        http_transport: JSONHTTPTransport | None = None,
        adapter_id: str = "adapter.models.openai-compatible",
        stream_observer: Callable[[str], None] | None = None,
    ) -> None:
        self.config = config
        self.runtime_resolver = runtime_resolver or ProviderRuntimeResolver.default()
        self.credential_source = credential_source
        self.http_transport = http_transport or UrllibJSONHTTPTransport()
        self.stream_observer = stream_observer
        self.descriptor = ModelAdapterDescriptor(
            adapter_id=adapter_id,
            provider_id=config.provider_id,
            model_id=config.model_id,
            kind="chat",
            supported_tasks=("generate", "summarize", "embed"),
            metadata={
                "provider_id": config.provider_id,
                "transport_id": "openai_chat_compatible",
                "base_url": config.base_url,
            },
        )

    def plan_request(
        self,
        request: ModelRequest,
        credentials: Mapping[str, str] | None = None,
    ) -> OpenAICompatibleRequestPlan:
        provider_id = self._resolve_provider_id(request)
        resolution = self.runtime_resolver.resolve(
            provider_id,
            model_id=request.model_id or self.config.model_id,
            base_url=self.config.base_url,
        )
        resolved_credentials = self._resolve_credentials(provider_id, credentials)
        if request.task == "embed" and not resolution.supports_embeddings:
            raise ValueError(f"transport {resolution.transport_id} does not support embeddings")
        endpoint_path = self._endpoint_path_for_task(request.task, resolution.endpoint_path)
        url = self._compose_url(self.config.base_url, endpoint_path)
        headers = self._build_headers(resolution, resolved_credentials)
        payload = self._build_payload(request, request.task, resolution)
        return OpenAICompatibleRequestPlan(
            request_id=request.request_id,
            provider_id=provider_id,
            model_id=resolution.model_id,
            base_url=self.config.base_url,
            endpoint_path=endpoint_path,
            url=url,
            request_family=resolution.request_family if request.task != "embed" else "embeddings",
            transport_id=resolution.transport_id,
            headers=headers,
            payload=payload,
            credential_keys=tuple(sorted(resolved_credentials)),
            metadata={
                "supports_streaming": str(resolution.supports_streaming).lower(),
                "supports_embeddings": str(resolution.supports_embeddings).lower(),
                "supports_tools": str(resolution.supports_tools).lower(),
                "supports_reasoning": str(resolution.supports_reasoning).lower(),
            },
        )

    def generate(
        self,
        request: ModelRequest,
        credentials: Mapping[str, str],
    ) -> ModelTextResult:
        plan = self.plan_request(request, credentials)
        if bool(plan.payload.get("stream")):
            return self._generate_streaming(request, plan)
        response = self.http_transport.post_json(url=plan.url, headers=plan.headers, payload=plan.payload)
        tool_calls = self._extract_tool_calls(response.payload, request_family=plan.request_family)
        content = self._extract_text_content(
            response.payload,
            request_family=plan.request_family,
            allow_empty=bool(tool_calls),
        )
        usage = self._usage_from_payload(response.payload)
        return ModelTextResult(
            result_id=str(response.payload.get("id", f"{request.request_id}:generate")),
            request_id=request.request_id,
            adapter_id=self.descriptor.adapter_id,
            provider_id=plan.provider_id,
            model_id=str(response.payload.get("model", plan.model_id)),
            task="generate",
            content=content,
            usage=usage,
            metadata={
                "endpoint_path": plan.endpoint_path,
                "url": plan.url,
                "credential_keys": ",".join(plan.credential_keys) or "no-credentials",
                "transport_id": plan.transport_id,
                "request_family": plan.request_family,
                "status_code": str(response.status_code),
            },
            tool_calls=tool_calls,
        )

    def _generate_streaming(
        self,
        request: ModelRequest,
        plan: OpenAICompatibleRequestPlan,
    ) -> ModelTextResult:
        transport = getattr(self.http_transport, "post_json_stream", None)
        if transport is None:
            fallback_response = self.http_transport.post_json(url=plan.url, headers=plan.headers, payload=plan.payload)
            return ModelTextResult(
                result_id=str(fallback_response.payload.get("id", f"{request.request_id}:generate")),
                request_id=request.request_id,
                adapter_id=self.descriptor.adapter_id,
                provider_id=plan.provider_id,
                model_id=str(fallback_response.payload.get("model", plan.model_id)),
                task="generate",
                content=self._extract_text_content(fallback_response.payload, request_family=plan.request_family),
                usage=self._usage_from_payload(fallback_response.payload),
                metadata={
                    "endpoint_path": plan.endpoint_path,
                    "url": plan.url,
                    "credential_keys": ",".join(plan.credential_keys) or "no-credentials",
                    "transport_id": plan.transport_id,
                    "request_family": plan.request_family,
                    "status_code": str(fallback_response.status_code),
                    "stream": "false",
                },
            )
        text_parts: list[str] = []
        usage = ModelUsage()
        result_id = f"{request.request_id}:generate"
        result_model = plan.model_id
        for chunk in transport(url=plan.url, headers=plan.headers, payload=plan.payload):
            payload = chunk.payload
            result_id = str(payload.get("id", result_id))
            result_model = str(payload.get("model", result_model))
            delta = self._extract_stream_text_delta(payload, request_family=plan.request_family)
            if delta:
                text_parts.append(delta)
                if self.stream_observer is not None:
                    self.stream_observer(delta)
            chunk_usage = self._usage_from_payload(payload)
            if any((chunk_usage.prompt_tokens, chunk_usage.completion_tokens, chunk_usage.total_tokens)):
                usage = chunk_usage
        content = "".join(text_parts)
        if not content:
            raise RuntimeError("chat-completions transport returned no streamed assistant text")
        return ModelTextResult(
            result_id=result_id,
            request_id=request.request_id,
            adapter_id=self.descriptor.adapter_id,
            provider_id=plan.provider_id,
            model_id=result_model,
            task="generate",
            content=content,
            usage=usage,
            metadata={
                "endpoint_path": plan.endpoint_path,
                "url": plan.url,
                "credential_keys": ",".join(plan.credential_keys) or "no-credentials",
                "transport_id": plan.transport_id,
                "request_family": plan.request_family,
                "status_code": "200",
                "stream": "true",
            },
        )

    def summarize(
        self,
        request: ModelRequest,
        credentials: Mapping[str, str],
    ) -> ModelTextResult:
        result = self.generate(
            ModelRequest(
                request_id=request.request_id,
                profile_id=request.profile_id,
                session_id=request.session_id,
                provider_id=request.provider_id,
                model_id=request.model_id,
                prompt=request.prompt,
                context=dict(request.context),
                task="summarize",
                metadata=dict(request.metadata),
            ),
            credentials,
        )
        return ModelTextResult(
            result_id=result.result_id,
            request_id=result.request_id,
            adapter_id=result.adapter_id,
            provider_id=result.provider_id,
            model_id=result.model_id,
            task="summarize",
            content=result.content,
            usage=result.usage,
            failure_kind=result.failure_kind,
            metadata=dict(result.metadata),
        )

    def embed(
        self,
        request: ModelRequest,
        credentials: Mapping[str, str],
    ) -> ModelEmbeddingResult:
        plan = self.plan_request(request, credentials)
        response = self.http_transport.post_json(url=plan.url, headers=plan.headers, payload=plan.payload)
        embeddings = self._extract_embeddings(response.payload)
        return ModelEmbeddingResult(
            result_id=str(response.payload.get("id", f"{request.request_id}:embed")),
            request_id=request.request_id,
            adapter_id=self.descriptor.adapter_id,
            provider_id=plan.provider_id,
            model_id=str(response.payload.get("model", plan.model_id)),
            task="embed",
            embeddings=embeddings,
            metadata={
                "endpoint_path": plan.endpoint_path,
                "url": plan.url,
                "credential_keys": ",".join(plan.credential_keys) or "no-credentials",
                "transport_id": plan.transport_id,
                "request_family": plan.request_family,
                "status_code": str(response.status_code),
            },
        )

    def _resolve_provider_id(self, request: ModelRequest) -> str:
        provider_id = request.provider_id or self.config.provider_id
        if provider_id != self.config.provider_id:
            raise ValueError(
                f"request provider_id {provider_id!r} does not match adapter provider_id "
                f"{self.config.provider_id!r}"
            )
        return provider_id

    def _resolve_credentials(
        self,
        provider_id: str,
        explicit_credentials: Mapping[str, str] | None,
    ) -> Mapping[str, str]:
        if explicit_credentials is not None:
            return dict(explicit_credentials)
        if self.credential_source is None:
            return {}
        return dict(self.credential_source.resolve(provider_id))

    def _build_headers(
        self,
        resolution: ProviderRuntimeResolution,
        credentials: Mapping[str, str],
    ) -> dict[str, str]:
        headers = dict(self.config.extra_headers)
        headers["Content-Type"] = "application/json"
        api_key = credentials.get("api_key")
        if api_key:
            headers[resolution.auth_header_name] = f"{self.config.auth_scheme} {api_key}"
        return headers

    def _build_payload(
        self,
        request: ModelRequest,
        task: str,
        resolution: ProviderRuntimeResolution,
    ) -> dict[str, Any]:
        if task == "embed":
            input_text = request.context.get("input") or request.context.get("text") or request.prompt
            return {
                "model": resolution.model_id,
                "input": input_text,
                "encoding_format": "float",
                "metadata": dict(request.metadata),
            }
        if resolution.request_family == "responses":
            payload: dict[str, Any] = {
                "model": resolution.model_id,
                "input": request.prompt,
                "metadata": dict(request.metadata),
            }
            payload["instructions"] = build_provider_identity_contract(request)
            if request.tools and resolution.supports_tools:
                payload["tools"] = list(request.tools)
                payload["tool_choice"] = "auto"
            return payload
        messages: list[dict[str, str]] = []
        messages.append({"role": "system", "content": build_provider_identity_contract(request)})
        messages.append({"role": "user", "content": request.prompt})
        should_stream = bool(self.stream_observer and resolution.supports_streaming and not request.tools)
        payload = {
            "model": resolution.model_id,
            "messages": messages,
            "stream": should_stream,
            "metadata": dict(request.metadata),
        }
        if request.tools and resolution.supports_tools:
            payload["tools"] = list(request.tools)
            payload["tool_choice"] = "auto"
            payload["parallel_tool_calls"] = True
        if payload["stream"]:
            payload["stream_options"] = {"include_usage": True}
        return payload

    def _endpoint_path_for_task(self, task: str, default_endpoint_path: str) -> str:
        if task == "embed":
            return "/v1/embeddings"
        return default_endpoint_path

    def _compose_url(self, base_url: str, endpoint_path: str) -> str:
        trimmed_base = base_url.rstrip("/")
        trimmed_path = endpoint_path.lstrip("/")
        if trimmed_path.startswith("v1/"):
            trimmed_path = trimmed_path[3:]
        return f"{trimmed_base}/{trimmed_path}"

    def _extract_text_content(
        self,
        payload: Mapping[str, Any],
        *,
        request_family: str,
        allow_empty: bool = False,
    ) -> str:
        if request_family == "responses":
            direct_text = payload.get("output_text")
            if isinstance(direct_text, str) and direct_text.strip():
                return direct_text
            output = payload.get("output", ())
            texts: list[str] = []
            if isinstance(output, list):
                for item in output:
                    if not isinstance(item, dict):
                        continue
                    content = item.get("content", ())
                    if isinstance(content, list):
                        for block in content:
                            if not isinstance(block, dict):
                                continue
                            if block.get("type") in {"output_text", "text"}:
                                text = block.get("text")
                                if isinstance(text, str):
                                    texts.append(text)
                    elif isinstance(item.get("text"), str):
                        texts.append(str(item["text"]))
            if texts:
                return "".join(texts)
            if allow_empty:
                return ""
            raise RuntimeError("responses transport returned no assistant text")
        choices = payload.get("choices", ())
        if isinstance(choices, list):
            for choice in choices:
                if not isinstance(choice, dict):
                    continue
                message = choice.get("message", {})
                if not isinstance(message, dict):
                    continue
                content = message.get("content")
                if isinstance(content, str):
                    return content
                if isinstance(content, list):
                    texts = [
                        str(block.get("text", ""))
                        for block in content
                        if isinstance(block, dict) and block.get("text")
                    ]
                    if texts:
                        return "".join(texts)
        if allow_empty:
            return ""
        raise RuntimeError("chat-completions transport returned no assistant text")

    def _extract_tool_calls(
        self,
        payload: Mapping[str, Any],
        *,
        request_family: str,
    ) -> tuple[ExecutionToolCall, ...]:
        if request_family != "chat_completions":
            if request_family != "responses":
                return ()
            output = payload.get("output", ())
            if not isinstance(output, list):
                return ()
            calls: list[ExecutionToolCall] = []
            for item in output:
                if not isinstance(item, Mapping):
                    continue
                call = self._tool_call_from_payload(item)
                if call is not None:
                    calls.append(call)
                    continue
                content = item.get("content")
                if isinstance(content, list):
                    for block in content:
                        call = self._tool_call_from_payload(block)
                        if call is not None:
                            calls.append(call)
            return tuple(calls)
        choices = payload.get("choices", ())
        if not isinstance(choices, list):
            return ()
        calls: list[ExecutionToolCall] = []
        for choice in choices:
            if not isinstance(choice, Mapping):
                continue
            message = choice.get("message")
            if not isinstance(message, Mapping):
                continue
            tool_calls = message.get("tool_calls")
            if isinstance(tool_calls, list):
                for item in tool_calls:
                    call = self._tool_call_from_payload(item)
                    if call is not None:
                        calls.append(call)
            function_call = message.get("function_call")
            if isinstance(function_call, Mapping):
                call = self._tool_call_from_payload({"function": function_call})
                if call is not None:
                    calls.append(call)
        return tuple(calls)

    def _tool_call_from_payload(self, payload: object) -> ExecutionToolCall | None:
        if not isinstance(payload, Mapping):
            return None
        function = payload.get("function")
        if isinstance(function, Mapping):
            name = str(function.get("name") or "").strip()
            arguments = self._tool_arguments_from_payload(function.get("arguments"))
        else:
            payload_type = str(payload.get("type") or "").strip()
            if payload_type and payload_type not in {"function_call", "tool_call", "function"} and "tool" not in payload_type:
                return None
            name = str(payload.get("name") or payload.get("tool_name") or "").strip()
            arguments = self._tool_arguments_from_payload(payload.get("arguments") or payload.get("input"))
        if not name:
            return None
        return ExecutionToolCall(tool_name=name, arguments=arguments)

    def _tool_arguments_from_payload(self, payload: object) -> dict[str, object]:
        if isinstance(payload, Mapping):
            return {str(key): value for key, value in payload.items()}
        if isinstance(payload, str):
            text = payload.strip()
            if not text:
                return {}
            try:
                decoded = json.loads(text)
            except json.JSONDecodeError:
                return {}
            if isinstance(decoded, Mapping):
                return {str(key): value for key, value in decoded.items()}
        return {}

    def _extract_stream_text_delta(self, payload: Mapping[str, Any], *, request_family: str) -> str:
        if request_family != "chat_completions":
            return ""
        choices = payload.get("choices", ())
        if not isinstance(choices, list):
            return ""
        fragments: list[str] = []
        for choice in choices:
            if not isinstance(choice, dict):
                continue
            delta = choice.get("delta")
            if not isinstance(delta, dict):
                continue
            content = delta.get("content")
            if isinstance(content, str):
                fragments.append(content)
                continue
            if isinstance(content, list):
                fragments.extend(
                    str(block.get("text", ""))
                    for block in content
                    if isinstance(block, dict) and block.get("text")
                )
        return "".join(fragments)

    def _extract_embeddings(self, payload: Mapping[str, Any]) -> tuple[tuple[float, ...], ...]:
        data = payload.get("data", ())
        if not isinstance(data, list):
            raise RuntimeError("embedding response did not include a data list")
        embeddings: list[tuple[float, ...]] = []
        for item in data:
            if not isinstance(item, dict):
                continue
            vector = item.get("embedding", ())
            if isinstance(vector, list):
                embeddings.append(tuple(float(value) for value in vector))
        if not embeddings:
            raise RuntimeError("embedding response did not include vectors")
        return tuple(embeddings)

    def _usage_from_payload(self, payload: Mapping[str, Any]) -> ModelUsage:
        usage_payload = payload.get("usage", {})
        if not isinstance(usage_payload, dict):
            return ModelUsage()
        prompt_tokens = int(usage_payload.get("prompt_tokens", usage_payload.get("input_tokens", 0)))
        completion_tokens = int(usage_payload.get("completion_tokens", usage_payload.get("output_tokens", 0)))
        total_tokens = int(usage_payload.get("total_tokens", prompt_tokens + completion_tokens))
        return ModelUsage(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
        )
