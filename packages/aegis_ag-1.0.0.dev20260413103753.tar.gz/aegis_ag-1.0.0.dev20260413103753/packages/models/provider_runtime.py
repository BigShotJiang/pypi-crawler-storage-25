"""Transport-aware provider catalog and runtime resolution primitives.

This module owns the shared seam between provider manifests, transport
definitions, catalog metadata, and runtime resolution. Provider-specific
network adapters can build on top of these structures without changing the
kernel or duplicating setup UX data.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping, Protocol, runtime_checkable


@dataclass(frozen=True, slots=True)
class ProviderTransportDefinition:
    transport_id: str
    display_name: str
    request_family: str
    endpoint_path: str
    auth_header_name: str = "Authorization"
    supports_streaming: bool = True
    supports_embeddings: bool = False
    supports_tools: bool = True
    supports_reasoning: bool = False
    supports_custom_base_url: bool = True
    metadata: Mapping[str, str] = field(default_factory=dict)

    def as_catalog_metadata(self) -> dict[str, str]:
        return {
            "transport_id": self.transport_id,
            "transport_display_name": self.display_name,
            "request_family": self.request_family,
            "endpoint_path": self.endpoint_path,
            "auth_header_name": self.auth_header_name,
            "supports_streaming": str(self.supports_streaming).lower(),
            "supports_embeddings": str(self.supports_embeddings).lower(),
            "supports_tools": str(self.supports_tools).lower(),
            "supports_reasoning": str(self.supports_reasoning).lower(),
            "supports_custom_base_url": str(self.supports_custom_base_url).lower(),
            **dict(self.metadata),
        }


@dataclass(frozen=True, slots=True)
class ProviderManifest:
    provider_id: str
    display_name: str
    transport_id: str
    catalog_summary: str
    onboarding_hint: str
    default_base_url: str | None = None
    default_model_id: str | None = None
    required_secret_keys: tuple[str, ...] = ("api_key",)
    required_config_keys: tuple[str, ...] = ()
    capability_flags: tuple[str, ...] = ()
    model_hints: tuple[str, ...] = ()
    supports_custom_base_url: bool = True
    listing_priority: int = 100
    docs_url: str | None = None
    metadata: Mapping[str, str] = field(default_factory=dict)

    def setup_fields(self) -> tuple[str, ...]:
        fields = list(self.required_config_keys)
        if self.supports_custom_base_url and "base_url" not in fields:
            fields.insert(0, "base_url")
        if self.default_model_id is not None and "model_id" not in fields:
            fields.append("model_id")
        return tuple(fields)

    def as_catalog_metadata(self) -> dict[str, str]:
        return {
            "provider_id": self.provider_id,
            "provider_display_name": self.display_name,
            "transport_id": self.transport_id,
            "catalog_summary": self.catalog_summary,
            "onboarding_hint": self.onboarding_hint,
            "default_base_url": self.default_base_url or "",
            "default_model_id": self.default_model_id or "",
            "required_secret_keys": ",".join(self.required_secret_keys),
            "required_config_keys": ",".join(self.required_config_keys),
            "capability_flags": ",".join(self.capability_flags),
            "model_hints": ",".join(self.model_hints),
            "supports_custom_base_url": str(self.supports_custom_base_url).lower(),
            "listing_priority": str(self.listing_priority),
            **dict(self.metadata),
        }


@dataclass(frozen=True, slots=True)
class ProviderCatalogRecord:
    provider_id: str
    display_name: str
    transport_id: str
    transport_display_name: str
    catalog_summary: str
    onboarding_hint: str
    default_base_url: str | None
    default_model_id: str | None
    required_secret_keys: tuple[str, ...]
    required_config_keys: tuple[str, ...]
    capability_flags: tuple[str, ...]
    model_hints: tuple[str, ...]
    supports_custom_base_url: bool
    listing_priority: int
    docs_url: str | None = None
    metadata: Mapping[str, str] = field(default_factory=dict)

    def as_mapping(self) -> dict[str, object]:
        return {
            "provider_id": self.provider_id,
            "display_name": self.display_name,
            "transport_id": self.transport_id,
            "transport_display_name": self.transport_display_name,
            "catalog_summary": self.catalog_summary,
            "onboarding_hint": self.onboarding_hint,
            "default_base_url": self.default_base_url,
            "default_model_id": self.default_model_id,
            "required_secret_keys": self.required_secret_keys,
            "required_config_keys": self.required_config_keys,
            "capability_flags": self.capability_flags,
            "model_hints": self.model_hints,
            "supports_custom_base_url": self.supports_custom_base_url,
            "listing_priority": self.listing_priority,
            "docs_url": self.docs_url,
            "metadata": dict(self.metadata),
        }


@dataclass(frozen=True, slots=True)
class ProviderSetupGuide:
    provider_id: str
    display_name: str
    transport_id: str
    transport_display_name: str
    required_secret_keys: tuple[str, ...]
    required_config_keys: tuple[str, ...]
    quickstart_steps: tuple[str, ...]
    verification_steps: tuple[str, ...]
    suggested_base_url: str | None
    suggested_model_id: str | None
    onboarding_hint: str
    metadata: Mapping[str, str] = field(default_factory=dict)

    def as_mapping(self) -> dict[str, object]:
        return {
            "provider_id": self.provider_id,
            "display_name": self.display_name,
            "transport_id": self.transport_id,
            "transport_display_name": self.transport_display_name,
            "required_secret_keys": self.required_secret_keys,
            "required_config_keys": self.required_config_keys,
            "quickstart_steps": self.quickstart_steps,
            "verification_steps": self.verification_steps,
            "suggested_base_url": self.suggested_base_url,
            "suggested_model_id": self.suggested_model_id,
            "onboarding_hint": self.onboarding_hint,
            "metadata": dict(self.metadata),
        }


@dataclass(frozen=True, slots=True)
class ProviderRuntimeResolution:
    provider_id: str
    display_name: str
    transport_id: str
    transport_display_name: str
    request_family: str
    model_id: str
    base_url: str | None
    endpoint_path: str
    auth_header_name: str
    supports_streaming: bool
    supports_embeddings: bool
    supports_tools: bool
    supports_reasoning: bool
    capability_flags: tuple[str, ...]
    provider_metadata: Mapping[str, str] = field(default_factory=dict)
    transport_metadata: Mapping[str, str] = field(default_factory=dict)

    def as_mapping(self) -> dict[str, object]:
        return {
            "provider_id": self.provider_id,
            "display_name": self.display_name,
            "transport_id": self.transport_id,
            "transport_display_name": self.transport_display_name,
            "request_family": self.request_family,
            "model_id": self.model_id,
            "base_url": self.base_url,
            "endpoint_path": self.endpoint_path,
            "auth_header_name": self.auth_header_name,
            "supports_streaming": self.supports_streaming,
            "supports_embeddings": self.supports_embeddings,
            "supports_tools": self.supports_tools,
            "supports_reasoning": self.supports_reasoning,
            "capability_flags": self.capability_flags,
            "provider_metadata": dict(self.provider_metadata),
            "transport_metadata": dict(self.transport_metadata),
        }


@runtime_checkable
class ProviderTransportRegistry(Protocol):
    def register(self, transport: ProviderTransportDefinition) -> None:
        """Register a transport definition."""

    def get(self, transport_id: str) -> ProviderTransportDefinition | None:
        """Return a transport definition by id."""

    def list(self) -> tuple[ProviderTransportDefinition, ...]:
        """Return all registered transport definitions."""


@runtime_checkable
class ProviderManifestRegistry(Protocol):
    def register(self, manifest: ProviderManifest) -> None:
        """Register a provider manifest."""

    def get(self, provider_id: str) -> ProviderManifest | None:
        """Return a provider manifest by id."""

    def list(self) -> tuple[ProviderManifest, ...]:
        """Return all registered provider manifests."""


class InMemoryProviderTransportRegistry:
    def __init__(self, transports: tuple[ProviderTransportDefinition, ...] = ()) -> None:
        self._transports: dict[str, ProviderTransportDefinition] = {}
        for transport in transports:
            self.register(transport)

    def register(self, transport: ProviderTransportDefinition) -> None:
        self._transports[transport.transport_id] = transport

    def get(self, transport_id: str) -> ProviderTransportDefinition | None:
        return self._transports.get(transport_id)

    def list(self) -> tuple[ProviderTransportDefinition, ...]:
        return tuple(self._transports.values())

    @classmethod
    def default(cls) -> "InMemoryProviderTransportRegistry":
        return cls(
            (
                ProviderTransportDefinition(
                    transport_id="openai_chat_compatible",
                    display_name="OpenAI Chat-Compatible",
                    request_family="chat_completions",
                    endpoint_path="/v1/chat/completions",
                    supports_streaming=True,
                    supports_embeddings=True,
                    supports_tools=True,
                    supports_reasoning=False,
                    supports_custom_base_url=True,
                    metadata={
                        "setup_style": "custom_endpoint",
                        "request_shape": "chat-completions",
                        "execution_surface": "streaming_chat_completions",
                    },
                ),
                ProviderTransportDefinition(
                    transport_id="openai_responses",
                    display_name="OpenAI Responses",
                    request_family="responses",
                    endpoint_path="/v1/responses",
                    supports_streaming=False,
                    supports_embeddings=False,
                    supports_tools=True,
                    supports_reasoning=False,
                    supports_custom_base_url=False,
                    metadata={
                        "setup_style": "first_party",
                        "request_shape": "responses",
                        "execution_surface": "non_streaming_text_responses",
                    },
                ),
                ProviderTransportDefinition(
                    transport_id="anthropic_messages",
                    display_name="Anthropic Messages",
                    request_family="messages",
                    endpoint_path="/v1/messages",
                    supports_streaming=False,
                    supports_embeddings=False,
                    supports_tools=True,
                    supports_reasoning=False,
                    supports_custom_base_url=False,
                    metadata={
                        "setup_style": "first_party",
                        "request_shape": "messages",
                        "execution_surface": "non_streaming_text_messages",
                    },
                ),
            )
        )


class InMemoryProviderManifestRegistry:
    def __init__(self, manifests: tuple[ProviderManifest, ...] = ()) -> None:
        self._manifests: dict[str, ProviderManifest] = {}
        for manifest in manifests:
            self.register(manifest)

    def register(self, manifest: ProviderManifest) -> None:
        self._manifests[manifest.provider_id] = manifest

    def get(self, provider_id: str) -> ProviderManifest | None:
        return self._manifests.get(provider_id)

    def list(self) -> tuple[ProviderManifest, ...]:
        return tuple(
            sorted(
                self._manifests.values(),
                key=lambda manifest: (manifest.listing_priority, manifest.provider_id),
            )
        )

    @classmethod
    def default(cls) -> "InMemoryProviderManifestRegistry":
        return cls(
            (
                ProviderManifest(
                    provider_id="openai-compatible",
                    display_name="OpenAI-Compatible API",
                    transport_id="openai_chat_compatible",
                    catalog_summary="Connect any OpenAI-compatible endpoint with one shared runtime path.",
                    onboarding_hint="Set a base URL, enter a provider key once, and choose a model from the live endpoint.",
                    default_base_url=None,
                    default_model_id="model-id",
                    required_secret_keys=("api_key",),
                    required_config_keys=("base_url", "model_id"),
                    capability_flags=("chat", "embeddings"),
                    model_hints=("Any OpenAI-compatible chat model",),
                    supports_custom_base_url=True,
                    listing_priority=10,
                    docs_url=None,
                    metadata={
                        "surface": "generic_endpoint",
                        "unsupported_capabilities": "reasoning",
                    },
                ),
                ProviderManifest(
                    provider_id="openai",
                    display_name="OpenAI",
                    transport_id="openai_responses",
                    catalog_summary="Use OpenAI's first-party API with the shared runtime resolver.",
                    onboarding_hint="Pick a model, add a secret reference, and optionally pin a workspace default.",
                    default_base_url="https://api.openai.com/v1",
                    default_model_id="gpt-4.1-mini",
                    required_secret_keys=("api_key",),
                    required_config_keys=("model_id",),
                    capability_flags=("chat",),
                    model_hints=("gpt-4.1-mini", "gpt-4.1", "o4-mini"),
                    supports_custom_base_url=False,
                    listing_priority=20,
                    docs_url=None,
                    metadata={
                        "surface": "first_party",
                        "unsupported_capabilities": "streaming,reasoning,embeddings",
                    },
                ),
                ProviderManifest(
                    provider_id="openrouter",
                    display_name="OpenRouter",
                    transport_id="openai_chat_compatible",
                    catalog_summary="Route Aegis through OpenRouter with one shared compatible endpoint.",
                    onboarding_hint="Pick a routed model, attach an API key, and validate the provider from the CLI.",
                    default_base_url="https://openrouter.ai/api/v1",
                    default_model_id="openai/gpt-4o-mini",
                    required_secret_keys=("api_key",),
                    required_config_keys=("model_id",),
                    capability_flags=("chat", "embeddings"),
                    model_hints=("openai/gpt-4o-mini", "anthropic/claude-3.7-sonnet", "google/gemini-2.5-pro"),
                    supports_custom_base_url=False,
                    listing_priority=25,
                    docs_url=None,
                    metadata={
                        "surface": "aggregator",
                        "unsupported_capabilities": "reasoning",
                    },
                ),
                ProviderManifest(
                    provider_id="anthropic",
                    display_name="Anthropic",
                    transport_id="anthropic_messages",
                    catalog_summary="Use Anthropic's native Messages API without changing kernel code.",
                    onboarding_hint="Choose a model, add a secret reference, and validate the provider from the CLI.",
                    default_base_url="https://api.anthropic.com",
                    default_model_id="claude-sonnet-4-0",
                    required_secret_keys=("api_key",),
                    required_config_keys=("model_id",),
                    capability_flags=("chat",),
                    model_hints=("claude-sonnet-4-0", "claude-opus-4-0", "claude-haiku-4-0"),
                    supports_custom_base_url=False,
                    listing_priority=30,
                    docs_url=None,
                    metadata={
                        "surface": "first_party",
                        "unsupported_capabilities": "streaming,reasoning,embeddings",
                    },
                ),
                ProviderManifest(
                    provider_id="google",
                    display_name="Google Gemini",
                    transport_id="openai_chat_compatible",
                    catalog_summary="Use Gemini through Google's OpenAI-compatible endpoint.",
                    onboarding_hint="Choose a Gemini model, attach an API key, and verify the direct Google route.",
                    default_base_url="https://generativelanguage.googleapis.com/v1beta/openai",
                    default_model_id="gemini-2.5-flash",
                    required_secret_keys=("api_key",),
                    required_config_keys=("model_id",),
                    capability_flags=("chat", "embeddings"),
                    model_hints=("gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash"),
                    supports_custom_base_url=False,
                    listing_priority=35,
                    docs_url=None,
                    metadata={
                        "surface": "first_party",
                        "unsupported_capabilities": "reasoning",
                    },
                ),
                ProviderManifest(
                    provider_id="groq",
                    display_name="Groq",
                    transport_id="openai_chat_compatible",
                    catalog_summary="Use Groq's fast OpenAI-compatible inference endpoint.",
                    onboarding_hint="Pick a Groq-served model, attach an API key, and validate the low-latency route.",
                    default_base_url="https://api.groq.com/openai/v1",
                    default_model_id="llama-3.3-70b-versatile",
                    required_secret_keys=("api_key",),
                    required_config_keys=("model_id",),
                    capability_flags=("chat", "embeddings"),
                    model_hints=("llama-3.3-70b-versatile", "qwen-qwq-32b", "deepseek-r1-distill-llama-70b"),
                    supports_custom_base_url=False,
                    listing_priority=40,
                    docs_url=None,
                    metadata={
                        "surface": "first_party",
                        "unsupported_capabilities": "reasoning",
                    },
                ),
                ProviderManifest(
                    provider_id="deepseek",
                    display_name="DeepSeek",
                    transport_id="openai_chat_compatible",
                    catalog_summary="Use DeepSeek's OpenAI-compatible hosted models directly.",
                    onboarding_hint="Choose a DeepSeek model, add an API key, and validate the provider from the CLI.",
                    default_base_url="https://api.deepseek.com/v1",
                    default_model_id="deepseek-chat",
                    required_secret_keys=("api_key",),
                    required_config_keys=("model_id",),
                    capability_flags=("chat", "embeddings"),
                    model_hints=("deepseek-chat", "deepseek-reasoner"),
                    supports_custom_base_url=False,
                    listing_priority=45,
                    docs_url=None,
                    metadata={
                        "surface": "first_party",
                        "unsupported_capabilities": "reasoning",
                    },
                ),
                ProviderManifest(
                    provider_id="xai",
                    display_name="xAI",
                    transport_id="openai_chat_compatible",
                    catalog_summary="Use xAI's hosted Grok models through a shared compatible runtime path.",
                    onboarding_hint="Choose a Grok model, add an API key, and validate the provider from the CLI.",
                    default_base_url="https://api.x.ai/v1",
                    default_model_id="grok-4-fast-reasoning",
                    required_secret_keys=("api_key",),
                    required_config_keys=("model_id",),
                    capability_flags=("chat", "embeddings"),
                    model_hints=("grok-4-fast-reasoning", "grok-3-mini", "grok-2-vision"),
                    supports_custom_base_url=False,
                    listing_priority=50,
                    docs_url=None,
                    metadata={
                        "surface": "first_party",
                        "unsupported_capabilities": "reasoning",
                    },
                ),
                ProviderManifest(
                    provider_id="mistral",
                    display_name="Mistral",
                    transport_id="openai_chat_compatible",
                    catalog_summary="Use Mistral's hosted models through the shared compatible runtime.",
                    onboarding_hint="Pick a Mistral model, attach an API key, and validate the provider from the CLI.",
                    default_base_url="https://api.mistral.ai/v1",
                    default_model_id="mistral-small-latest",
                    required_secret_keys=("api_key",),
                    required_config_keys=("model_id",),
                    capability_flags=("chat", "embeddings"),
                    model_hints=("mistral-small-latest", "mistral-medium-latest", "codestral-latest"),
                    supports_custom_base_url=False,
                    listing_priority=55,
                    docs_url=None,
                    metadata={
                        "surface": "first_party",
                        "unsupported_capabilities": "reasoning",
                    },
                ),
                ProviderManifest(
                    provider_id="together",
                    display_name="Together AI",
                    transport_id="openai_chat_compatible",
                    catalog_summary="Use Together AI's hosted open-model catalog through one compatible endpoint.",
                    onboarding_hint="Choose a Together model, add an API key, and validate the provider from the CLI.",
                    default_base_url="https://api.together.ai/v1",
                    default_model_id="meta-llama/Llama-4-Scout-17B-16E-Instruct",
                    required_secret_keys=("api_key",),
                    required_config_keys=("model_id",),
                    capability_flags=("chat", "embeddings"),
                    model_hints=("meta-llama/Llama-4-Scout-17B-16E-Instruct", "deepseek-ai/DeepSeek-V3.1", "Qwen/Qwen3-235B-A22B-Instruct-2507"),
                    supports_custom_base_url=False,
                    listing_priority=60,
                    docs_url=None,
                    metadata={
                        "surface": "aggregator",
                        "unsupported_capabilities": "reasoning",
                    },
                ),
                ProviderManifest(
                    provider_id="fireworks",
                    display_name="Fireworks AI",
                    transport_id="openai_chat_compatible",
                    catalog_summary="Use Fireworks' hosted open-model runtime through one compatible endpoint.",
                    onboarding_hint="Choose a Fireworks model, add an API key, and validate the provider from the CLI.",
                    default_base_url="https://api.fireworks.ai/inference/v1",
                    default_model_id="accounts/fireworks/models/deepseek-v3",
                    required_secret_keys=("api_key",),
                    required_config_keys=("model_id",),
                    capability_flags=("chat", "embeddings"),
                    model_hints=("accounts/fireworks/models/deepseek-v3", "accounts/fireworks/models/llama-v3p1-70b-instruct"),
                    supports_custom_base_url=False,
                    listing_priority=62,
                    docs_url=None,
                    metadata={
                        "surface": "aggregator",
                        "unsupported_capabilities": "reasoning",
                    },
                ),
                ProviderManifest(
                    provider_id="moonshot",
                    display_name="Moonshot Kimi",
                    transport_id="openai_chat_compatible",
                    catalog_summary="Use Moonshot Kimi models through Moonshot's OpenAI-compatible endpoint.",
                    onboarding_hint="Choose a Kimi model, add an API key, and validate the provider from the CLI.",
                    default_base_url="https://api.moonshot.ai/v1",
                    default_model_id="kimi-k2-0905-preview",
                    required_secret_keys=("api_key",),
                    required_config_keys=("model_id",),
                    capability_flags=("chat", "embeddings"),
                    model_hints=("kimi-k2-0905-preview", "kimi-k2-instruct", "moonshot-v1-8k"),
                    supports_custom_base_url=False,
                    listing_priority=65,
                    docs_url=None,
                    metadata={
                        "surface": "first_party",
                        "unsupported_capabilities": "reasoning",
                    },
                ),
                ProviderManifest(
                    provider_id="minimax",
                    display_name="MiniMax",
                    transport_id="anthropic_messages",
                    catalog_summary="Use MiniMax's Anthropic-compatible reasoning models without changing the kernel path.",
                    onboarding_hint="Choose a MiniMax model, add an API key, and validate the provider from the CLI.",
                    default_base_url="https://api.minimax.io/anthropic",
                    default_model_id="MiniMax-M2.7",
                    required_secret_keys=("api_key",),
                    required_config_keys=("model_id",),
                    capability_flags=("chat",),
                    model_hints=("MiniMax-M2.7", "MiniMax-M2.7-highspeed"),
                    supports_custom_base_url=False,
                    listing_priority=70,
                    docs_url=None,
                    metadata={
                        "surface": "first_party",
                        "unsupported_capabilities": "streaming,reasoning,embeddings",
                    },
                ),
                ProviderManifest(
                    provider_id="ollama",
                    display_name="Ollama",
                    transport_id="openai_chat_compatible",
                    catalog_summary="Use a local Ollama /v1 endpoint through the compatible runtime path.",
                    onboarding_hint="Point Aegis at your Ollama endpoint, choose a local model, and grow against the local runtime.",
                    default_base_url="http://127.0.0.1:11434/v1",
                    default_model_id="llama3.2",
                    required_secret_keys=(),
                    required_config_keys=("base_url", "model_id"),
                    capability_flags=("chat", "embeddings"),
                    model_hints=("llama3.2", "qwen2.5:7b", "gemma3:12b"),
                    supports_custom_base_url=True,
                    listing_priority=75,
                    docs_url=None,
                    metadata={
                        "surface": "local_runtime",
                        "unsupported_capabilities": "reasoning",
                    },
                ),
                ProviderManifest(
                    provider_id="vllm",
                    display_name="vLLM",
                    transport_id="openai_chat_compatible",
                    catalog_summary="Use a self-hosted vLLM OpenAI-compatible endpoint as Aegis' live mind.",
                    onboarding_hint="Point Aegis at your vLLM /v1 endpoint, choose a served model id, and validate the local route.",
                    default_base_url="http://127.0.0.1:8000/v1",
                    default_model_id="Qwen/Qwen2.5-7B-Instruct",
                    required_secret_keys=(),
                    required_config_keys=("base_url", "model_id"),
                    capability_flags=("chat", "embeddings"),
                    model_hints=("Qwen/Qwen2.5-7B-Instruct", "meta-llama/Llama-3.1-8B-Instruct", "deepseek-ai/DeepSeek-R1-Distill-Qwen-32B"),
                    supports_custom_base_url=True,
                    listing_priority=80,
                    docs_url=None,
                    metadata={
                        "surface": "self_hosted",
                        "unsupported_capabilities": "reasoning",
                    },
                ),
            )
        )


class ProviderRuntimeResolver:
    def __init__(
        self,
        *,
        transport_registry: ProviderTransportRegistry | None = None,
        manifest_registry: ProviderManifestRegistry | None = None,
    ) -> None:
        self.transport_registry = transport_registry or InMemoryProviderTransportRegistry.default()
        self.manifest_registry = manifest_registry or InMemoryProviderManifestRegistry.default()

    @classmethod
    def default(cls) -> "ProviderRuntimeResolver":
        return cls()

    def list_catalog(self) -> tuple[ProviderCatalogRecord, ...]:
        records: list[ProviderCatalogRecord] = []
        for manifest in self.manifest_registry.list():
            transport = self._transport_for_manifest(manifest)
            records.append(self._catalog_record(manifest, transport))
        return tuple(records)

    def build_setup_guide(self, provider_id: str) -> ProviderSetupGuide:
        manifest = self._manifest_for(provider_id)
        transport = self._transport_for_manifest(manifest)
        steps = [
            f"Create or select an auth profile for {manifest.display_name}.",
            (
                "Store the required provider secret(s) in Aegis' encrypted local vault: "
                f"{', '.join(manifest.required_secret_keys)}."
            ),
        ]
        if transport.supports_custom_base_url:
            steps.append("Set the endpoint base URL for your compatible API.")
        if manifest.default_model_id is not None:
            steps.append(f"Choose or override the default model id ({manifest.default_model_id}).")
        steps.append("Run a provider test or health flow before first use.")
        return ProviderSetupGuide(
            provider_id=manifest.provider_id,
            display_name=manifest.display_name,
            transport_id=transport.transport_id,
            transport_display_name=transport.display_name,
            required_secret_keys=manifest.required_secret_keys,
            required_config_keys=manifest.setup_fields(),
            quickstart_steps=tuple(steps),
            verification_steps=(
                "Check the provider listing entry.",
                "Run a connectivity test or health command.",
                "Set the provider as default if the check succeeds.",
            ),
            suggested_base_url=manifest.default_base_url,
            suggested_model_id=manifest.default_model_id,
            onboarding_hint=manifest.onboarding_hint,
            metadata=self._runtime_truth_metadata(manifest, transport),
        )

    def resolve(
        self,
        provider_id: str,
        *,
        model_id: str | None = None,
        base_url: str | None = None,
    ) -> ProviderRuntimeResolution:
        manifest = self._manifest_for(provider_id)
        transport = self._transport_for_manifest(manifest)
        resolved_model_id = model_id or manifest.default_model_id
        if resolved_model_id is None:
            raise ValueError(f"provider manifest is missing a default model id: {provider_id}")
        resolved_base_url = base_url if base_url is not None else manifest.default_base_url
        return ProviderRuntimeResolution(
            provider_id=manifest.provider_id,
            display_name=manifest.display_name,
            transport_id=transport.transport_id,
            transport_display_name=transport.display_name,
            request_family=transport.request_family,
            model_id=resolved_model_id,
            base_url=resolved_base_url,
            endpoint_path=transport.endpoint_path,
            auth_header_name=transport.auth_header_name,
            supports_streaming=transport.supports_streaming,
            supports_embeddings=transport.supports_embeddings,
            supports_tools=transport.supports_tools,
            supports_reasoning=transport.supports_reasoning,
            capability_flags=manifest.capability_flags,
            provider_metadata=self._runtime_truth_metadata(manifest, transport),
            transport_metadata=self._runtime_truth_metadata(manifest, transport),
        )

    def _manifest_for(self, provider_id: str) -> ProviderManifest:
        manifest = self.manifest_registry.get(provider_id)
        if manifest is None:
            raise LookupError(f"no provider manifest registered for provider: {provider_id}")
        return manifest

    def _transport_for_manifest(self, manifest: ProviderManifest) -> ProviderTransportDefinition:
        transport = self.transport_registry.get(manifest.transport_id)
        if transport is None:
            raise LookupError(
                f"no transport registered for manifest transport id: {manifest.transport_id}"
            )
        return transport

    def _catalog_record(
        self,
        manifest: ProviderManifest,
        transport: ProviderTransportDefinition,
    ) -> ProviderCatalogRecord:
        return ProviderCatalogRecord(
            provider_id=manifest.provider_id,
            display_name=manifest.display_name,
            transport_id=transport.transport_id,
            transport_display_name=transport.display_name,
            catalog_summary=manifest.catalog_summary,
            onboarding_hint=manifest.onboarding_hint,
            default_base_url=manifest.default_base_url,
            default_model_id=manifest.default_model_id,
            required_secret_keys=manifest.required_secret_keys,
            required_config_keys=manifest.setup_fields(),
            capability_flags=manifest.capability_flags,
            model_hints=manifest.model_hints,
            supports_custom_base_url=transport.supports_custom_base_url,
            listing_priority=manifest.listing_priority,
            docs_url=manifest.docs_url,
            metadata=self._runtime_truth_metadata(manifest, transport),
        )

    def _runtime_truth_metadata(
        self,
        manifest: ProviderManifest,
        transport: ProviderTransportDefinition,
    ) -> dict[str, str]:
        return {
            **dict(manifest.metadata),
            **dict(transport.metadata),
            "capability_truth_source": "runtime_execution",
        }
