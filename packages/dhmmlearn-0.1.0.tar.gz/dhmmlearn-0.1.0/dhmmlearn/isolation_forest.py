import os

def load_isolation_forest():
    path = os.path.join(os.path.dirname(__file__), "templates", "isolation_forest.txt")
    with open(path, "r") as f:
        return f.read()