import os

def load_wine_nb():
    path = os.path.join(os.path.dirname(__file__), "templates", "wine_nb.txt")
    with open(path, "r") as f:
        return f.read()