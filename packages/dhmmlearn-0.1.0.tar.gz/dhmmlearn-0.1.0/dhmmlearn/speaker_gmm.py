import os

def load_speaker_gmm():
    path = os.path.join(os.path.dirname(__file__), "templates", "speaker_gmm.txt")
    with open(path, "r") as f:
        return f.read()