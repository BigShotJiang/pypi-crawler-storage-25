import os

def load_hmm_dna():
    path = os.path.join(os.path.dirname(__file__), "templates", "hmm_dna.txt")
    with open(path, "r") as f:
        return f.read()