import os

def load_hmm_weather():
    path = os.path.join(os.path.dirname(__file__), "templates", "hmm_weather.txt")
    with open(path, "r") as f:
        return f.read()