import os

def load_digits_nb():
    path = os.path.join(os.path.dirname(__file__), "templates", "digits_nb.txt")
    with open(path, "r") as f:
        return f.read()