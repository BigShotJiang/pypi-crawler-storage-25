import os

def load_knn_iris():
    path = os.path.join(os.path.dirname(__file__), "templates", "knn_iris.txt")
    with open(path, "r") as f:
        return f.read()