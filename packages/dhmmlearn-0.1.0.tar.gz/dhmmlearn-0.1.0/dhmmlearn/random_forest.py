import os

def load_random_forest():
    path = os.path.join(os.path.dirname(__file__), "templates", "random_forest.txt")
    with open(path, "r") as f:
        return f.read()