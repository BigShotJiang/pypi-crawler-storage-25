import os

def load_text_nb():
    path = os.path.join(os.path.dirname(__file__), "templates", "text_nb.txt")
    with open(path, "r") as f:
        return f.read()