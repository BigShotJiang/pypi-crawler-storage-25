import os

def load_knn_shapes():
    path = os.path.join(os.path.dirname(__file__), "templates", "knn_shapes.txt")
    with open(path, "r") as f:
        return f.read()