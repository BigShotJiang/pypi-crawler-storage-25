import os

def load_bayesian_network():
    path = os.path.join(os.path.dirname(__file__), "templates", "bayesian_network.txt")
    with open(path, "r") as f:
        return f.read()