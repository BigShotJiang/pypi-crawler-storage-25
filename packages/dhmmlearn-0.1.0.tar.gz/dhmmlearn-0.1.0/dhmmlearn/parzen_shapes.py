import os

def load_parzen_shapes():
    path = os.path.join(os.path.dirname(__file__), "templates", "parzen_shapes.txt")
    with open(path, "r") as f:
        return f.read()