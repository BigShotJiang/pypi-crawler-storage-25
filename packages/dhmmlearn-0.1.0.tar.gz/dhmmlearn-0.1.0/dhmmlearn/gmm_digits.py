import os

def load_gmm_digits():
    path = os.path.join(os.path.dirname(__file__), "templates", "gmm_digits.txt")
    with open(path, "r") as f:
        return f.read()