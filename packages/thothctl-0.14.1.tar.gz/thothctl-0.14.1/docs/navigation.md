# Documentation Navigation

## Getting Started

- [Quick Start](quick_start.md) - Universal installation and setup
- [Windows Installation](installation/windows_installation.md) - Windows-specific setup guide
- [Windows Troubleshooting](troubleshooting/windows_troubleshooting.md) - Windows-specific issues

## Framework Documentation

- [Framework Overview](index.md) - Core concepts and architecture
- [Cross-Platform Support](framework/cross_platform_support.md) - Platform compatibility details
- [Commands Reference](index.md#commands) - All available commands
  - [Check Commands](framework/commands/check/check_overview.md) - Validation and compliance
    - [Blast Radius Assessment](framework/commands/check/blast-radius.md) - ITIL v4 risk assessment
    - [Drift Detection](framework/commands/check/drift-detection.md) - Infrastructure drift detection
  - [Scan Commands](framework/commands/scan/scan_overview.md) - Security scanning
  - [Inventory Commands](framework/commands/inventory/inventory_overview.md) - Infrastructure inventory
- [Use Cases](framework/use_cases/README.md) - Common usage scenarios

## Platform-Specific Guides

### Windows
- [Installation Guide](installation/windows_installation.md)
- [Troubleshooting](troubleshooting/windows_troubleshooting.md)
- [PowerShell Integration](framework/cross_platform_support.md#windows-support)

### Linux
- [Installation](quick_start.md#installation) - Standard pip installation
- [Shell Integration](framework/cross_platform_support.md#linux-support)

### macOS
- [Installation](quick_start.md#installation) - Standard pip installation
- [Shell Integration](framework/cross_platform_support.md#macos-support)

## Advanced Topics

- [AI Agent for IaC Security](framework/commands/ai-review/README.md) - Multi-agent AI analysis, auto-fix, and PR decisions
- [MCP Integration](mcp.md) - Model Context Protocol server
- [Template Engine](template_engine/template_engine.md) - Template system documentation
- [Telemetry](telemetry.md) - Usage analytics and privacy

## Support

- [GitHub Issues](https://github.com/thothforge/thothctl/issues)
- [Community Discussions](https://github.com/thothforge/thothctl/discussions)
- [Contributing Guide](https://github.com/thothforge/thothctl/blob/main/CONTRIBUTING.md)
