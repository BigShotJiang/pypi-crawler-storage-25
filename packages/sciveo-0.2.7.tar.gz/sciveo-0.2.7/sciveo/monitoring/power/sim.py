#
# Stanislav Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact s.georgiev@softel.bg.
#
# 2025
#

from sciveo.network.modbus import ModbusTcpEmulator


class SimulatorEMS300:
  def __init__(self, host="127.0.0.1", port=5020, period=1):
    self.emulator = ModbusTcpEmulator(profile_name="ems300", host=host, port=port, period=period)

  def start(self):
    self.emulator.start_updates()

  def stop(self):
    self.emulator.stop_updates()

  def start_server(self):
    self.emulator.serve()


if __name__ == "__main__":
  sim = SimulatorEMS300(host="127.0.0.1", port=1502)
  sim.start()
  sim.start_server()
