#!/usr/bin/env python
#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2024
#

import os
import time
import json
import argparse

from sciveo.version import __version__
from sciveo.tools.logger import *
from sciveo.tools.configuration import GlobalConfiguration


def _parse_bool(value):
  if isinstance(value, bool):
    return value

  text = str(value).strip().lower()
  if text in ("1", "true", "yes", "y", "on"):
    return True
  if text in ("0", "false", "no", "n", "off"):
    return False

  raise argparse.ArgumentTypeError("Expected one of: 1, 0, true, false, yes, no, on, off")


def main(argv=None):
  config = GlobalConfiguration.get()

  parser = argparse.ArgumentParser(description=f'{config.name} CLI')
  parser.add_argument(
    'command',
    choices=[
      'init', 'monitor', 'scan',
      'nvr', 'rtsp', 'capture',
      'predictors-server', 'media-server', 'media-run',
      'watchdog', 'read', 'write', 'agent', 'emulate',
    ],
    help='Command to execute')

  parser.add_argument('--period', type=float, default=120, help='Period in seconds')
  parser.add_argument('--block', type=bool, default=True, help='Block flag')
  parser.add_argument('--auth', type=str, default=config['secret_access_key'], help='Auth secret access key')
  parser.add_argument('--timeout', type=float, default=1.0, help='Timeout')
  parser.add_argument('--net', type=str, default=None, help='Network like 192.168.10.0/24')
  parser.add_argument('--url', type=str, default=None, help='URL')
  parser.add_argument('--host', type=str, default=None, help='Host ip or name')
  parser.add_argument('--port', type=int, default=22, help='Host port number, used for network ops')
  parser.add_argument('--ports', type=str, default="[]", help='Host ports list')
  parser.add_argument('--localhost', type=bool, default=False, help='Add localhost to list of hosts')
  parser.add_argument('--input-path', type=str, default=None, help='Input Path')
  parser.add_argument('--output-path', type=str, default=None, help='Output Path')
  parser.add_argument('--width', type=int, default=None, help='width')
  parser.add_argument('--height', type=int, default=None, help='height')
  parser.add_argument('--fps', type=int, help='FPS')
  parser.add_argument('--stream', type=str, default=None, help='Stream')
  parser.add_argument('--rate', type=int, help='Rate number')
  parser.add_argument('--processor', type=str, help='Processor name')
  parser.add_argument('--action', type=str, default=None, help='Action')
  parser.add_argument('--provider', type=str, default='auto', help='Provider name')
  parser.add_argument('--model', type=str, default=None, help='Model name')
  parser.add_argument('--device', type=str, default=None, help='Device')
  parser.add_argument('--context', type=int, default=None, help='Context')
  parser.add_argument('--alias', type=str, default=None, help='Alias')
  parser.add_argument('--file', type=str, default=None, help='File')
  parser.add_argument('--interactive', type=_parse_bool, default=None, help='Interactive')
  parser.add_argument('--prompt', type=str, default=None, help='One-shot prompt')
  parser.add_argument('--system-prompt', type=str, default=None, help='System prompt')
  parser.add_argument('--approve', type=str, default='auto', help='Agent approval mode: auto, ask, none, writes, or all')
  parser.add_argument('--approval-root', type=str, default=None, help='Agent approval root path')
  parser.add_argument('--src', type=str, default=None, help='Source')
  parser.add_argument('--src-id', type=int, default=None, help='Source Id')
  parser.add_argument('--dst', type=str, default=None, help='Destination')
  parser.add_argument('--value', type=json.loads, default=None, help='Value')
  parser.add_argument('--threshold', type=float, default=None, help='Threshold')
  parser.add_argument('--execute', type=str, default=None, help='Execute command')
  parser.add_argument('--pid', type=int, default=None, help='Process PID')
  parser.add_argument('--serial', type=str, default=None, help='Serial Name')
  parser.add_argument('--proto', type=str, default='modbus', help='Protocol type')
  parser.add_argument('--server', type=str, default='modbus', help='Server type')
  parser.add_argument('--profile', type=str, default='ems300', help='Emulator profile name')
  parser.add_argument('--transport', type=str, default=None, help='Transport type')
  parser.add_argument('--serial-port', '--tty', dest='serial_port', type=str, default=None, help='Serial device path, for example /dev/ttyUSB0')
  parser.add_argument('--baudrate', type=int, default=9600, help='Serial baudrate')
  parser.add_argument('--bytesize', type=int, default=8, help='Serial bytesize')
  parser.add_argument('--parity', type=str, default='N', help='Serial parity: N, E, or O')
  parser.add_argument('--stopbits', type=float, default=1, help='Serial stop bits')
  parser.add_argument('--mode', type=str, default=None, help='Mode')
  parser.add_argument('--id', '--device-id', dest='device_id', type=int, default=None, help='Target id')
  parser.add_argument('--address', type=int, default=None, help='Address')
  parser.add_argument('--count', type=int, default=None, help='Count')
  parser.add_argument('--kind', '--register-type', dest='register_type', type=str, default=None, help='Value kind')
  parser.add_argument('--type', '--data-type', dest='data_type', type=str, default=None, help='Value type')
  parser.add_argument('--factor', type=float, default=None, help='scaling factor')
  parser.add_argument('--reg', type=json.loads, default=None, help='Value spec')
  parser.add_argument('--retries', type=int, default=3, help='Number of retries')
  parser.add_argument('--reconnect-delay', type=float, default=0.1, help='reconnect delay')
  parser.add_argument('--reconnect-delay-max', type=float, default=300, help='reconnect delay max')
  parser.add_argument('--local-echo', '--handle-local-echo', dest='handle_local_echo', action='store_true', help='Enable local echo handling')
  parser.add_argument('--zero-based', action='store_true', help='Zero based')
  parser.add_argument('--data-json', type=json.loads, default={}, help='Json Data')
  parser.add_argument('--display', type=int, default=None, help='Display number')
  parser.add_argument('--list-shell', type=json.loads, default=[], help='List of Shell commands')
  parser.add_argument('--list-logs', type=json.loads, default=[], help='List of Log files')

  args = parser.parse_args(argv)

  if args.command == 'monitor':
    if args.src is None:
      from sciveo.monitoring.start import MonitorStart
      MonitorStart(period=args.period, block=args.block, output_path=args.output_path, shell=args.list_shell, logs=args.list_logs)()
    elif args.src.startswith("power"):
      from sciveo.monitoring.power.ems300 import PowerEMS300
      port = args.port if args.port not in (None, 22) else 502
      mon = PowerEMS300(serial=args.serial, host=args.host, port=port, period=args.period, output_path=args.output_path)
      mon.start()
      while(True):
        time.sleep(3600)
  elif args.command == 'scan':
    from sciveo.network.tools import NetworkTools
    host = args.host
    if host is None:
      NetworkTools(timeout=args.timeout, localhost=args.localhost).scan_port(port=args.port, network=args.net)
    else:
      NetworkTools(timeout=args.timeout, ports=json.loads(args.ports)).scan_host(host)
  elif args.command == 'init':
    info(f"init {config.name} ver {__version__}")
    home = os.path.expanduser('~')
    base_path = os.path.join(home, f'.{config.name}')
    if not os.path.exists(base_path):
      os.makedirs(base_path)
      default_lines = [
        "secret_access_key=<your secret access key>",
        f"api_base_url=https://{config.name}.com",
        "sci_log_level=DEBUG",
      ]
      with open(os.path.join(base_path, "default"), 'w') as fp:
        for line in default_lines:
          fp.write(line + '\n')
    else:
      info(f"init, [{base_path}] already there")
  elif args.command == 'nvr':
    from sciveo.media.capture.nvr import VideoRecorder
    VideoRecorder(args.input_path).start()
  elif args.command == 'rtsp':
    if args.src is None and args.src_id is None:
      from sciveo.media.capture.nvr import RTSPVideoPlayer
      if args.url is not None:
        url = args.url
      elif args.host is not None and args.stream is not None:
        url = f"rtsp://{args.host}:{args.port}/{args.stream}"
      else:
        warning("Invalid URL")
        return
      player = RTSPVideoPlayer(url)
      player.run()
    else:
      from sciveo.media.capture.gst_server import CamFactory, ColorBarFactory
      data = dict(args.data_json or {})
      if args.src_id is not None:
        server = CamFactory(args.src_id, args.width, args.height, args.fps, configuration=data, display=args.display)
      elif args.src is not None:
        if "color" in args.src:
          server = ColorBarFactory(args.width, args.height, args.fps, display=args.display)
        else:
          server = CamFactory(args.src, args.width, args.height, args.fps, configuration=data, display=args.display)
      server.serve(host=args.host, port=args.port, stream=args.stream)
  elif args.command == 'capture':
    from sciveo.media.capture.cam import CameraDaemon, ScreenDaemon, CapturePlayer
    if args.src == "screen":
      cap = ScreenDaemon(src=args.src_id, region=dict(args.data_json or {}))
    elif args.src == "cam":
      cap = CameraDaemon(cam_id=args.src_id)
    elif args.src == "rpi":
      from sciveo.media.capture.rpi import RPICamera
      cap = RPICamera(cam_id=args.src_id, width=args.width, height=args.height)
    else:
      cap = CameraDaemon(cam_id=args.src_id)
    player = CapturePlayer(cap=cap, tag=args.src, fps=args.fps or 0)
    player.play()
  elif args.command == 'media-server':
    from sciveo.media.pipelines.server import __START_SCIVEO_MEDIA_SERVER__
    __START_SCIVEO_MEDIA_SERVER__()
  elif args.command == 'media-run':
    if args.processor == "audio-plot":
      from sciveo.media.pipelines.processors.audio.audio_extractor_process import plot_audio
      plot_audio(args.width, args.height, args.rate, args.input_path, args.output_path)
  elif args.command == 'agent':
    action = str(args.action or 'console').strip().lower()
    try:
      if action == 'console':
        from sciveo.agents.console import run_agent_cli
        run_agent_cli(
          provider=args.provider,
          model=args.model,
          prompt=args.prompt,
          system_prompt=args.system_prompt,
          approve=args.approve,
          approval_root=args.approval_root,
          url=args.url,
          host=args.host,
          port=args.port,
          auth_token=args.auth,
          mode=args.mode,
          interactive=args.interactive,
          input_path=args.input_path,
          data_json=args.data_json,
        )
      elif action == 'pull':
        from sciveo.agents.runtime import pull_model
        data = dict(args.data_json or {})
        result = pull_model(
          model=args.model,
          alias=args.alias,
          file=args.file,
          mmproj_file=data.get("mmproj_file"),
        )
        print(json.dumps(result))
      elif action == 'models':
        from sciveo.agents.runtime import list_models
        print(json.dumps({"models": list_models()}))
      elif action == 'run':
        from sciveo.agents.runtime import DEFAULT_HF_HOST, DEFAULT_HF_PORT, run_hf_runtime_server
        port = args.port if args.port not in (None, 22) else DEFAULT_HF_PORT
        run_hf_runtime_server(
          model=args.model,
          host=args.host or DEFAULT_HF_HOST,
          port=port,
          auth_token=args.auth,
          device=args.device,
          context=args.context,
        )
      else:
        parser.error(f"Unsupported agent action '{args.action}'")
    except (ImportError, RuntimeError) as e:
      error(e)
      raise SystemExit(1)
  elif args.command == 'watchdog':
    daemons = []
    if args.execute is not None:
      if args.src is None or args.src.startswith("mem"):
        from sciveo.monitoring.watchdog.base import MemoryWatchDogDaemon
        daemons.append(MemoryWatchDogDaemon(threshold_percent=args.threshold, period=args.period, command=args.execute))
      elif args.src.startswith("disk") and args.input_path is not None:
        from sciveo.monitoring.watchdog.base import DiskWatchDogDaemon
        daemons.append(DiskWatchDogDaemon(path=args.input_path, threshold_percent=args.threshold, period=args.period, command=args.execute))
      elif args.src.startswith("process"):
        from sciveo.monitoring.watchdog.process import ProcessWatchDogDaemon
        daemons.append(ProcessWatchDogDaemon(pid=args.pid, process_cmd=args.dst, period=args.period, command=args.execute, thread_inactive_threshold=args.threshold))
    for daemon in daemons:
      daemon.start()
    while(True):
      time.sleep(3600)
  elif args.command == 'predictors-server':
    GlobalConfiguration.set("API_PREDICTORS", None)
    from sciveo.api.server import WebServerDaemon
    daemons = [
      WebServerDaemon(port=args.port)
    ]
    for daemon in daemons:
      debug("starting", type(daemon).__name__)
      daemon.start()
    while(True):
      time.sleep(3600)
  elif args.command in ('read', 'write'):
    try:
      proto = str(args.proto or 'modbus').strip().lower()
      if proto == 'modbus':
        from sciveo.network.modbus import execute_modbus_command
        args.framer = args.mode or 'rtu'
        result = execute_modbus_command(args.command, args)
      else:
        parser.error(f"Unsupported --proto '{args.proto}'")
    except ValueError as e:
      parser.error(str(e))
    except (ImportError, RuntimeError) as e:
      error(e)
      raise SystemExit(1)
    print(json.dumps(result))
  elif args.command == 'emulate':
    try:
      server = str(args.server or 'modbus').strip().lower()
      if server == 'modbus':
        from sciveo.network.modbus import run_modbus_emulator
        if args.port in (None, 22):
          args.port = 1502
        args.framer = args.mode or 'rtu'
        run_modbus_emulator(args)
      else:
        parser.error(f"Unsupported --server '{args.server}'")
    except ValueError as e:
      parser.error(str(e))
    except (ImportError, RuntimeError) as e:
      error(e)
      raise SystemExit(1)
  else:
    warning(args.command, "not implemented")


if __name__ == '__main__':
  main()
