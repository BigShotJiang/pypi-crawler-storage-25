#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import copy
import asyncio
import threading

from sciveo.network.modbus.tools import decode_registers
from sciveo.network.modbus.tools import encode_registers
from sciveo.network.modbus.tools import ensure_pymodbus
from sciveo.network.modbus.tools import normalize_register_type
from sciveo.network.modbus.tools import resolve_protocol_address
from sciveo.tools.logger import debug, info

try:
  from pymodbus.datastore import ModbusDeviceContext, ModbusServerContext, ModbusSparseDataBlock
  from pymodbus.server import ModbusTcpServer, StartTcpServer
  _PYMODBUS_SERVER_IMPORT_ERROR = None
except ImportError as exc:
  ModbusDeviceContext = None
  ModbusTcpServer = None
  ModbusServerContext = None
  ModbusSparseDataBlock = None
  StartTcpServer = None
  _PYMODBUS_SERVER_IMPORT_ERROR = exc


DEFAULT_EMULATOR_HOST = "127.0.0.1"
DEFAULT_EMULATOR_PORT = 1502
DEFAULT_EMULATOR_PROFILE = "ems300"
DEFAULT_EMULATOR_PERIOD = 1.0

REGISTER_BLOCK_KEYS = {
  "holding": "h",
  "input": "i",
}

LEGACY_REGISTER_BLOCK_KEYS = {
  "holding": "hr",
  "input": "ir",
}

REGISTER_FUNCTION_CODES = {
  "holding": 3,
  "input": 4,
}


def ensure_pymodbus_server():
  ensure_pymodbus()
  if _PYMODBUS_SERVER_IMPORT_ERROR is None:
    return
  raise ImportError("pymodbus server support is required for Modbus emulation. Install sciveo[net].") from _PYMODBUS_SERVER_IMPORT_ERROR


def _coerce_device_id(device_id):
  return int(device_id)


def _deep_merge(base, override):
  if not isinstance(base, dict):
    return copy.deepcopy(override)

  merged = copy.deepcopy(base)
  for key, value in dict(override or {}).items():
    if isinstance(value, dict) and isinstance(merged.get(key), dict):
      merged[key] = _deep_merge(merged[key], value)
    else:
      merged[key] = copy.deepcopy(value)
  return merged


def _normalize_register_words(words):
  normalized = []
  for word in list(words):
    if isinstance(word, bool):
      word = int(word)
    if not isinstance(word, int):
      raise ValueError("Modbus emulator register lists must contain integers")
    if word < 0 or word > 0xFFFF:
      raise ValueError("Modbus emulator register values must be between 0 and 65535")
    normalized.append(word)
  return normalized


def _encode_register_spec(spec):
  if isinstance(spec, bool):
    return [int(spec)]
  if isinstance(spec, int):
    return [spec]
  if isinstance(spec, (list, tuple)):
    return _normalize_register_words(spec)
  if not isinstance(spec, dict):
    raise ValueError(f"Unsupported Modbus emulator register spec {spec!r}")

  if "registers" in spec:
    return _normalize_register_words(spec.get("registers") or [])

  value = spec.get("value")
  data_type = spec.get("data_type", spec.get("type", "RAW"))
  factor = spec.get("factor", spec.get("scale", 1))
  return encode_registers(value=value, data_type=data_type, factor=factor)


def _normalize_register_block(registers, zero_based=False):
  normalized = {}
  for address, spec in dict(registers or {}).items():
    protocol_address = resolve_protocol_address(address, zero_based=zero_based)
    for offset, word in enumerate(_encode_register_spec(spec)):
      normalized[protocol_address + offset + 1] = word
  return normalized


def _extract_device_profile(config):
  config = dict(config or {})
  return {
    "holding": config.get("holding", config.get("holding_registers", {})),
    "input": config.get("input", config.get("input_registers", {})),
    "zero_based": config.get("zero_based"),
  }


def _resolve_device_profiles(profile):
  profile = dict(profile or {})
  devices = profile.get("devices")
  if devices is not None:
    return {
      _coerce_device_id(device_id): _extract_device_profile(device_profile)
      for device_id, device_profile in dict(devices).items()
    }

  device_id = _coerce_device_id(profile.get("device_id", 1))
  return {
    device_id: _extract_device_profile(profile),
  }


def build_modbus_server_context(profile=None, zero_based=False):
  ensure_pymodbus_server()

  profile = dict(profile or {})
  profile_zero_based = bool(profile.get("zero_based", zero_based))
  context_devices = {}

  for device_id, device_profile in _resolve_device_profiles(profile).items():
    device_zero_based = device_profile.get("zero_based")
    if device_zero_based is None:
      device_zero_based = profile_zero_based

    holding_block = _normalize_register_block(device_profile.get("holding"), zero_based=device_zero_based)
    input_block = _normalize_register_block(device_profile.get("input"), zero_based=device_zero_based)

    context_devices[device_id] = ModbusDeviceContext(
      di=ModbusSparseDataBlock({}),
      co=ModbusSparseDataBlock({}),
      hr=ModbusSparseDataBlock(holding_block),
      ir=ModbusSparseDataBlock(input_block),
    )

  return ModbusServerContext(devices=context_devices, single=False)


def _ems300_profile_definition():
  return {
    "name": "ems300",
    "device_id": 247,
    "input": {
      8026: {"value": 52.5, "data_type": "U32_LE", "factor": 0.1},
      8038: {"value": -1500, "data_type": "S32_LE", "factor": 1},
      8044: {"value": 12500, "data_type": "S32_LE", "factor": 1},
      8048: {"value": 600, "data_type": "S32_LE", "factor": 1},
      8060: {"value": 8200, "data_type": "S32_LE", "factor": 1},
      8776: {"value": 3456.7, "data_type": "U32_LE", "factor": 0.1},
      8778: {"value": 2987.2, "data_type": "U32_LE", "factor": 0.1},
      10101: {"value": 123.45, "data_type": "S32_LE", "factor": 0.01},
      10103: {"value": -12.34, "data_type": "S32_LE", "factor": 0.01},
      10105: {"value": 98.76, "data_type": "S32_LE", "factor": 0.01},
      10713: {"value": -5.5, "data_type": "S32_LE", "factor": 0.01},
      10715: {"value": 78.5, "data_type": "U16", "factor": 0.1},
      10716: {"value": 124.2, "data_type": "U32_LE", "factor": 0.1},
      10945: {"value": 9200, "data_type": "U64", "factor": 1},
    },
    "holding": {},
    "updater": _update_ems300_profile,
  }


def _logger1000_sg_profile_definition():
  return {
    "name": "logger1000-sg",
    "device_id": 247,
    "input": {
      8000: {"value": 0x0710, "data_type": "U16", "factor": 1},
      8001: {"value": 10209, "data_type": "U32_LE", "factor": 1},
      8003: {"value": 10209, "data_type": "U32_LE", "factor": 1},
      8005: {"value": 2, "data_type": "U16", "factor": 1},
      8006: {"value": 0, "data_type": "U16", "factor": 1},
      8021: {"value": 0, "data_type": "U32_LE", "factor": 1},
      8029: {"value": 24.0, "data_type": "S16", "factor": 0.01},
      8030: {"value": 12.0, "data_type": "S16", "factor": 0.01},
      8031: {"value": 24.1, "data_type": "S16", "factor": 0.01},
      8032: {"value": 11.8, "data_type": "S16", "factor": 0.01},
      8033: {"value": 23.9, "data_type": "S16", "factor": 0.01},
      8034: {"value": 24.2, "data_type": "S16", "factor": 0.01},
      8035: {"value": 4.5, "data_type": "S16", "factor": 0.01},
      8036: {"value": 4.6, "data_type": "S16", "factor": 0.01},
      8058: {"value": 100, "data_type": "U16", "factor": 1},
      8059: {"value": 0, "data_type": "U16", "factor": 1},
      8060: {"value": 60, "data_type": "U16", "factor": 1},
      8061: {"value": -60, "data_type": "S16", "factor": 1},
      8066: {"value": 80, "data_type": "U16", "factor": 1},
      8067: {"value": 0, "data_type": "S16", "factor": 1},
      8068: {"value": 1, "data_type": "U16", "factor": 1},
      8069: {"value": 1, "data_type": "U16", "factor": 1},
      8070: {"value": 8200, "data_type": "U64", "factor": 1},
      8074: {"value": 123.4, "data_type": "U32_LE", "factor": 0.1},
      8076: {"value": 500, "data_type": "S64", "factor": 1},
      8080: {"value": 98765.4, "data_type": "U64", "factor": 0.1},
      8084: {"value": 0, "data_type": "U32_LE", "factor": 0.1},
      8086: {"value": 100, "data_type": "U32_LE", "factor": 0.1},
      8088: {"value": -60, "data_type": "S32_LE", "factor": 0.1},
      8090: {"value": 60, "data_type": "S32_LE", "factor": 0.1},
      8092: {"value": 100, "data_type": "U32_LE", "factor": 0.1},
      8094: {"value": 60, "data_type": "U32_LE", "factor": 0.1},
      8096: {"value": 2, "data_type": "U16", "factor": 1},
      8097: {"value": 0, "data_type": "U16", "factor": 1},
      8098: {"value": 1234.5, "data_type": "U64", "factor": 0.1},
      8102: {"value": 4567.8, "data_type": "U64", "factor": 0.1},
      8106: {"value": 8300, "data_type": "U64", "factor": 1},
    },
    "holding": {
      8002: {"value": 1, "data_type": "U16", "factor": 1},
      8003: {"value": 80, "data_type": "U32_LE", "factor": 0.1},
      8005: {"value": 80, "data_type": "U32_LE", "factor": 0.1},
      8007: {"value": 0, "data_type": "S32_LE", "factor": 0.1},
      8009: {"value": 0, "data_type": "S32_LE", "factor": 0.1},
      8011: {"value": 1, "data_type": "S32_LE", "factor": 0.001},
      8013: {"value": 0, "data_type": "U16", "factor": 1},
      8014: {"value": 0, "data_type": "U16", "factor": 1},
      8015: {"value": 0, "data_type": "U16", "factor": 1},
      8016: {"value": 0, "data_type": "U16", "factor": 1},
    },
  }


def _logger1000_hw_profile_definition():
  return {
    "name": "logger1000-hw",
    "device_id": 0,
    "holding": {
      40204: {"value": 0, "data_type": "U16", "factor": 1},
      40205: {"value": 0, "data_type": "U16", "factor": 1},
      40420: {"value": 8.2, "data_type": "U32", "factor": 0.1},
      40422: {"value": 0.5, "data_type": "S32", "factor": 0.1},
      40424: {"value": 8.2, "data_type": "U32", "factor": 0.1},
      40426: {"value": 0.5, "data_type": "S32", "factor": 0.1},
      40428: {"value": 100, "data_type": "U16", "factor": 0.1},
      40429: {"value": 1, "data_type": "S16", "factor": 0.001},
      40500: {"value": 120.5, "data_type": "S16", "factor": 0.1},
      40521: {"value": 8.5, "data_type": "U32", "factor": 0.001},
      40523: {"value": 1234.5, "data_type": "U32", "factor": 0.1},
      40525: {"value": 8.2, "data_type": "S32", "factor": 0.001},
      40532: {"value": 0.98, "data_type": "S16", "factor": 0.001},
      40543: {"value": 1, "data_type": "U16", "factor": 1},
      40544: {"value": 0.5, "data_type": "S32", "factor": 0.001},
      40550: {"value": 12345.67, "data_type": "U64", "factor": 0.01},
      40554: {"value": 120.5, "data_type": "S32", "factor": 0.1},
      40560: {"value": 98765.4, "data_type": "U32", "factor": 0.1},
      40562: {"value": 123.4, "data_type": "U32", "factor": 0.1},
      40564: {"value": 8.5, "data_type": "U32", "factor": 0.1},
      40566: {"value": 1, "data_type": "U16", "factor": 1},
      40567: {"value": 1, "data_type": "U16", "factor": 1},
      40568: {"value": 0, "data_type": "U32", "factor": 1},
      40570: {"value": 0, "data_type": "U32", "factor": 1},
      40572: {"value": 18, "data_type": "S16", "factor": 1},
      40573: {"value": 18, "data_type": "S16", "factor": 1},
      40574: {"value": 18, "data_type": "S16", "factor": 1},
      40575: {"value": 400.1, "data_type": "U16", "factor": 0.1},
      40576: {"value": 399.8, "data_type": "U16", "factor": 0.1},
      40577: {"value": 400.0, "data_type": "U16", "factor": 0.1},
      40685: {"value": 98.5, "data_type": "U16", "factor": 0.01},
      40693: {"value": 60, "data_type": "U32", "factor": 0.1},
      40695: {"value": -60, "data_type": "S32", "factor": 0.1},
      40697: {"value": 100, "data_type": "U32", "factor": 0.1},
      40699: {"value": 1, "data_type": "U16", "factor": 1},
      40700: {"value": 0, "data_type": "U16", "factor": 1},
      40723: {"value": 0, "data_type": "U16", "factor": 1},
      40724: {"value": 0, "data_type": "U16", "factor": 1},
      40736: {"value": 0, "data_type": "U16", "factor": 1},
      40737: {"value": 0, "data_type": "U16", "factor": 1},
      40802: {"value": 100, "data_type": "U32", "factor": 1},
      41124: {"value": 0.997, "data_type": "U16", "factor": 0.001},
      41934: {"value": 100, "data_type": "U32", "factor": 0.001},
      41936: {"value": 100, "data_type": "U32", "factor": 0.001},
      41938: {"value": 100, "data_type": "U32", "factor": 0.001},
      41940: {"value": 1, "data_type": "U32", "factor": 0.001},
      41942: {"value": 0, "data_type": "U16", "factor": 1},
    },
    "input": {},
  }


def get_modbus_emulator_profile(profile_name=None, profile=None):
  profile_name = str(profile_name or (dict(profile or {}).get("name") or "custom")).strip().lower()

  if profile_name in ("", "custom"):
    base_profile = {}
  elif profile_name == "ems300":
    base_profile = _ems300_profile_definition()
  elif profile_name in ("logger1000-sg", "sungrow-logger1000", "sungrow-logger1000a", "sungrow-logger1000b"):
    base_profile = _logger1000_sg_profile_definition()
  elif profile_name in ("logger1000-hw", "huawei-logger1000", "huawei-smartlogger1000", "smartlogger1000", "smartlogger1000-hw"):
    base_profile = _logger1000_hw_profile_definition()
  else:
    raise ValueError(f"Unsupported Modbus emulator profile '{profile_name}'")

  merged = _deep_merge(base_profile, profile or {})
  if profile_name != "custom":
    merged.setdefault("name", profile_name)
  return merged


class ModbusTcpEmulator:
  def __init__(self, profile_name=DEFAULT_EMULATOR_PROFILE, profile=None, host=DEFAULT_EMULATOR_HOST, port=DEFAULT_EMULATOR_PORT, period=DEFAULT_EMULATOR_PERIOD, zero_based=False):
    ensure_pymodbus_server()
    self.profile_name = profile_name
    self.profile = get_modbus_emulator_profile(profile_name=profile_name, profile=profile)
    self.zero_based = bool(self.profile.get("zero_based", zero_based))
    self.host = host
    self.port = int(port)
    self.period = float(period)
    self.context = build_modbus_server_context(self.profile, zero_based=self.zero_based)
    self.updater = self.profile.get("updater")
    self.stop_event = threading.Event()
    self.update_thread = None
    self.server_thread = None
    self.server_ready = None
    self.server_error = None

  @property
  def device_ids(self):
    return sorted(_resolve_device_profiles(self.profile).keys())

  def _resolve_device_id(self, device_id=None):
    if device_id is not None:
      return _coerce_device_id(device_id)
    if len(self.device_ids) == 1:
      return self.device_ids[0]
    raise ValueError("Modbus emulator device id is required when multiple devices are configured")

  def get_device_store(self, device_id=None):
    device_id = self._resolve_device_id(device_id)
    return self.context[device_id]

  def get_block(self, register_type, device_id=None):
    register_type = normalize_register_type(register_type)
    device_store = self.get_device_store(device_id)
    if isinstance(device_store, dict):
      return device_store.get(REGISTER_BLOCK_KEYS[register_type]) or device_store[LEGACY_REGISTER_BLOCK_KEYS[register_type]]
    return device_store.store[REGISTER_BLOCK_KEYS[register_type]]

  def get_registers(self, address, count=1, register_type="holding", device_id=None, zero_based=None):
    if zero_based is None:
      zero_based = self.zero_based
    protocol_address = resolve_protocol_address(address, zero_based=zero_based)
    register_type = normalize_register_type(register_type)
    device_store = self.get_device_store(device_id)
    if isinstance(device_store, dict):
      return list(self.get_block(register_type, device_id=device_id).getValues(protocol_address + 1, count=count))
    return list(device_store.getValues(REGISTER_FUNCTION_CODES[register_type], protocol_address, count=count))

  def set_registers(self, address, registers, register_type="holding", device_id=None, zero_based=None):
    if zero_based is None:
      zero_based = self.zero_based
    protocol_address = resolve_protocol_address(address, zero_based=zero_based)
    register_type = normalize_register_type(register_type)
    values = _normalize_register_words(registers)
    device_store = self.get_device_store(device_id)
    if isinstance(device_store, dict):
      self.get_block(register_type, device_id=device_id).setValues(protocol_address + 1, values)
      return
    device_store.setValues(REGISTER_FUNCTION_CODES[register_type], protocol_address, values)

  def set_value(self, address, value, data_type="RAW", factor=1, register_type="holding", device_id=None, zero_based=None):
    self.set_registers(
      address=address,
      registers=encode_registers(value=value, data_type=data_type, factor=factor),
      register_type=register_type,
      device_id=device_id,
      zero_based=zero_based,
    )

  def start_updates(self):
    if not callable(self.updater) or self.period <= 0 or self.update_thread is not None:
      return

    self.stop_event.clear()
    self.update_thread = threading.Thread(target=self._run_updates, daemon=True)
    self.update_thread.start()

  def stop_updates(self):
    self.stop_event.set()
    if self.update_thread is not None:
      self.update_thread.join(timeout=max(self.period, 0.1) + 0.5)
      self.update_thread = None

  def _run_updates(self):
    while not self.stop_event.wait(self.period):
      self.updater(self)

  def serve(self):
    info(f"Starting Modbus TCP emulator '{self.profile.get('name', 'custom')}' on {self.host}:{self.port} devices={self.device_ids}")
    self.start_updates()
    try:
      StartTcpServer(context=self.context, address=(self.host, self.port))
    finally:
      self.stop_updates()

  def start_server(self, timeout=2.0):
    if self.server_thread is not None:
      return

    self.server_ready = threading.Event()
    self.server_error = None
    self.stop_event.clear()
    self.server_thread = threading.Thread(target=self._run_server_thread, daemon=True)
    self.server_thread.start()

    if not self.server_ready.wait(timeout=timeout):
      self.stop_server()
      raise RuntimeError(f"Timed out starting Modbus TCP emulator on {self.host}:{self.port}")
    if self.server_error is not None:
      self.stop_server()
      raise self.server_error

  def stop_server(self):
    self.stop_event.set()
    if self.server_thread is not None:
      self.server_thread.join(timeout=2.0)
      self.server_thread = None
    self.stop_updates()

  def _run_server_thread(self):
    try:
      asyncio.run(self._serve_async())
    except Exception as e:
      self.server_error = e
      if self.server_ready is not None:
        self.server_ready.set()

  async def _serve_async(self):
    server = ModbusTcpServer(context=self.context, address=(self.host, self.port))
    self.start_updates()
    try:
      await server.serve_forever(background=True)
      if self.server_ready is not None:
        self.server_ready.set()
      while not self.stop_event.is_set():
        await asyncio.sleep(0.05)
      await server.shutdown()
    finally:
      server.close()
      self.stop_updates()


def _update_ems300_profile(emulator):
  registers = emulator.get_registers(address=8060, count=2, register_type="input", device_id=247)
  current_power = decode_registers(registers, "S32_LE")
  next_power = (int(current_power) + 50) % 15000
  emulator.set_value(address=8060, value=next_power, data_type="S32_LE", register_type="input", device_id=247)
  emulator.set_value(address=8044, value=next_power + 4300, data_type="S32_LE", register_type="input", device_id=247)
  emulator.set_value(address=10101, value=(next_power + 4300) / 100, data_type="S32_LE", factor=0.01, register_type="input", device_id=247)
  debug("EMS300 emulator updated PV Active Power", next_power)


def run_modbus_emulator(args):
  profile_override = dict(getattr(args, "data_json", None) or {})
  emulator = ModbusTcpEmulator(
    profile_name=getattr(args, "profile", DEFAULT_EMULATOR_PROFILE),
    profile=profile_override,
    host=getattr(args, "host", DEFAULT_EMULATOR_HOST),
    port=getattr(args, "port", DEFAULT_EMULATOR_PORT),
    period=getattr(args, "period", DEFAULT_EMULATOR_PERIOD),
    zero_based=getattr(args, "zero_based", False),
  )
  emulator.serve()
  return emulator
