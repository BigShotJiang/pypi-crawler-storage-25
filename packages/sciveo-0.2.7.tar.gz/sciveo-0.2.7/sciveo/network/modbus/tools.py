#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import math
import struct

from sciveo.tools.logger import debug, info, warning

try:
  from pymodbus import FramerType
  from pymodbus.client import ModbusSerialClient, ModbusTcpClient
  _PYMODBUS_IMPORT_ERROR = None
except ImportError as exc:
  FramerType = None
  ModbusSerialClient = None
  ModbusTcpClient = None
  _PYMODBUS_IMPORT_ERROR = exc


SUPPORTED_DATA_TYPES = (
  "RAW",
  "U16",
  "S16",
  "U32",
  "S32",
  "U32_BE",
  "S32_BE",
  "U32_LE",
  "S32_LE",
  "U64",
  "S64",
  "U64_BE",
  "S64_BE",
  "U64_LE",
  "S64_LE",
  "FLOAT",
  "FLOAT_BE",
  "FLOAT_LE",
)

DEFAULT_DEVICE_ID = 1
DEFAULT_REGISTER_TYPE = "holding"
DEFAULT_DATA_TYPE = "RAW"
DEFAULT_FACTOR = 1.0


def ensure_pymodbus():
  if _PYMODBUS_IMPORT_ERROR is None:
    return
  raise ImportError("pymodbus is required for Modbus CLI support. Install sciveo[net].") from _PYMODBUS_IMPORT_ERROR


class ModbusTransportConfig:
  SERIAL_TRANSPORTS = ("rtu", "serial", "serial_rtu", "modbus-rtu")

  def __init__(self, config):
    self.config = dict(config or {})
    self.transport = self._normalise_transport(self.config.get("transport"), self.config)
    self.timeout = float(self.config.get("timeout", 1.0))
    self.reconnect_delay = float(self.config.get("reconnect_delay", 0.1))
    self.reconnect_delay_max = float(self.config.get("reconnect_delay_max", 300))
    self.retries = int(self.config.get("retries", 3))

    if self.transport == "serial":
      self.serial_port = self.config.get("serial_port") or self.config.get("device") or self.config.get("tty")
      if not self.serial_port:
        raise ValueError("Serial Modbus transport requires --serial-port or --tty")

      self.endpoint = self.config.get("name") or self.serial_port
      self.framer = str(self.config.get("framer", "rtu")).strip().lower()
      self.baudrate = int(self.config.get("baudrate", 9600))
      self.bytesize = int(self.config.get("bytesize", 8))
      self.parity = str(self.config.get("parity", "N")).strip().upper()
      self.stopbits = float(self.config.get("stopbits", 1))
      self.handle_local_echo = bool(self.config.get("handle_local_echo", False))
    else:
      self.host = self.config.get("host")
      if not self.host:
        raise ValueError("TCP Modbus transport requires --host")

      self.endpoint = self.config.get("name") or self.host
      self.port = int(self.config.get("port", 502))

  @classmethod
  def build(cls, transport_config=None, config=None, host=None, port=502):
    if isinstance(transport_config, cls):
      return transport_config

    merged = dict(config or {})
    merged.update(dict(transport_config or {}))

    if host is not None and "host" not in merged and "serial_port" not in merged:
      merged["host"] = host
    if port is not None and "port" not in merged:
      merged["port"] = port

    transport_name = cls._normalise_transport(merged.get("transport"), merged)
    if transport_name == "serial" and host is not None and "serial_port" not in merged:
      merged["serial_port"] = host

    return cls(merged)

  @classmethod
  def _normalise_transport(cls, transport=None, config=None):
    config = config or {}
    transport = transport or config.get("transport")
    if transport is None and any(k in config for k in ("serial_port", "device", "tty")):
      transport = "serial"
    transport = str(transport or "tcp").strip().lower()
    if transport in cls.SERIAL_TRANSPORTS:
      return "serial"
    return "tcp"

  @property
  def label(self):
    if self.transport == "serial":
      return (
        f"serial://{self.serial_port}"
        f" ({self.framer} {self.baudrate}/{self.parity}/{self.bytesize}/{self.stopbits})"
      )
    return f"tcp://{self.host}:{self.port}"

  def _resolve_framer(self):
    if FramerType is None:
      return self.framer

    enum_name = self.framer.upper()
    if hasattr(FramerType, enum_name):
      return getattr(FramerType, enum_name)
    raise ValueError(f"Unsupported Modbus framer '{self.framer}'")

  def create_client(self):
    ensure_pymodbus()

    if self.transport == "serial":
      kwargs = {
        "port": self.serial_port,
        "framer": self._resolve_framer(),
        "baudrate": self.baudrate,
        "bytesize": self.bytesize,
        "parity": self.parity,
        "stopbits": self.stopbits,
        "timeout": self.timeout,
        "retries": self.retries,
        "reconnect_delay": self.reconnect_delay,
        "reconnect_delay_max": self.reconnect_delay_max,
        "handle_local_echo": self.handle_local_echo,
      }
      info("CREATE SERIAL CLIENT", kwargs)
      return ModbusSerialClient(**kwargs)

    info("CREATE TCP CLIENT", self.host, self.port, self.timeout)
    return ModbusTcpClient(
      host=self.host,
      port=self.port,
      timeout=self.timeout,
      retries=self.retries,
      reconnect_delay=self.reconnect_delay,
      reconnect_delay_max=self.reconnect_delay_max,
    )


def normalize_register_type(register_type):
  register_type = str(register_type or "holding").strip().lower()
  if register_type not in ("holding", "input"):
    raise ValueError("--kind must be one of: holding, input")
  return register_type


def normalize_data_type(data_type):
  data_type = str(data_type or DEFAULT_DATA_TYPE).strip().upper()
  aliases = {
    "INT16": "S16",
    "UINT16": "U16",
    "INT32": "S32_BE",
    "UINT32": "U32_BE",
    "INT64": "S64_BE",
    "UINT64": "U64_BE",
    "FLOAT32": "FLOAT_BE",
  }
  data_type = aliases.get(data_type, data_type)
  if data_type not in SUPPORTED_DATA_TYPES:
    raise ValueError(f"Unsupported --type '{data_type}'")
  return data_type


def count_for_type(data_type):
  data_type = normalize_data_type(data_type)
  if data_type in ("RAW", "U16", "S16"):
    return 1
  if data_type in ("U32", "S32", "U32_BE", "S32_BE", "U32_LE", "S32_LE", "FLOAT", "FLOAT_BE", "FLOAT_LE"):
    return 2
  if data_type in ("U64", "S64", "U64_BE", "S64_BE", "U64_LE", "S64_LE"):
    return 4
  raise ValueError(f"Unsupported --type '{data_type}'")


def _register_type_from_flag(value):
  if isinstance(value, bool):
    return "input" if value else "holding"

  if isinstance(value, (int, float)) and value in (0, 1):
    return "input" if int(value) == 1 else "holding"

  if isinstance(value, str):
    normalized = value.strip().lower()
    if normalized in ("holding", "input"):
      return normalized
    if normalized in ("0", "false", "hold"):
      return "holding"
    if normalized in ("1", "true", "in"):
      return "input"
  return None


def parse_register_spec(reg):
  if reg is None:
    return {}

  if isinstance(reg, dict):
    parsed = {}

    if "address" in reg or "addr" in reg:
      parsed["address"] = reg.get("address", reg.get("addr"))
    if "data_type" in reg or "dtype" in reg or "type" in reg:
      parsed["data_type"] = reg.get("data_type", reg.get("dtype", reg.get("type")))
    if "factor" in reg or "scale" in reg:
      parsed["factor"] = reg.get("factor", reg.get("scale"))
    if "count" in reg:
      parsed["count"] = reg.get("count")
    if "device_id" in reg or "id" in reg or "unit" in reg or "slave" in reg:
      parsed["device_id"] = reg.get("device_id", reg.get("id", reg.get("unit", reg.get("slave"))))
    if "register_type" in reg or "kind" in reg:
      parsed["register_type"] = reg.get("register_type", reg.get("kind"))
    elif "is_input" in reg:
      parsed["register_type"] = _register_type_from_flag(reg.get("is_input"))

    return {k: v for k, v in parsed.items() if v is not None}

  if not isinstance(reg, (list, tuple)):
    raise ValueError("--reg must be a JSON list or object")

  values = list(reg)
  if len(values) == 0:
    raise ValueError("--reg list must not be empty")
  if len(values) > 6:
    raise ValueError("--reg list supports at most 6 values: [address, type, factor, count, kind, id]")

  parsed = {
    "address": values[0],
  }
  if len(values) > 1:
    parsed["data_type"] = values[1]
  if len(values) > 2:
    parsed["factor"] = values[2]
  if len(values) > 3:
    parsed["count"] = values[3]
  if len(values) > 4:
    parsed["register_type"] = values[4]
  if len(values) > 5:
    parsed["device_id"] = values[5]

  return {k: v for k, v in parsed.items() if v is not None}


def resolve_register_arguments(args):
  reg_spec = parse_register_spec(getattr(args, "reg", None))

  address = args.address if args.address is not None else reg_spec.get("address")
  data_type = args.data_type if args.data_type is not None else reg_spec.get("data_type", DEFAULT_DATA_TYPE)
  factor = args.factor if args.factor is not None else reg_spec.get("factor", DEFAULT_FACTOR)
  count = args.count if args.count is not None else reg_spec.get("count")
  register_type = args.register_type if args.register_type is not None else reg_spec.get("register_type", DEFAULT_REGISTER_TYPE)
  device_id = args.device_id if args.device_id is not None else reg_spec.get("device_id", DEFAULT_DEVICE_ID)

  if register_type is not None:
    register_type = _register_type_from_flag(register_type) or register_type
    register_type = normalize_register_type(register_type)
  data_type = normalize_data_type(data_type)

  if args.count is None and "count" in reg_spec and count is not None:
    reg_count = int(count)
    if reg_count <= 0:
      raise ValueError("--count must be greater than zero")

    # In compact register specs, count=1 commonly means one typed value.
    # For multi-register types, expand that to the effective Modbus word count
    # before passing it through the generic typed-count validation path.
    if data_type != "RAW" and reg_count == 1:
      count = count_for_type(data_type)
    else:
      count = reg_count

  return {
    "address": address,
    "data_type": data_type,
    "factor": float(factor),
    "count": count,
    "register_type": register_type,
    "device_id": int(device_id),
  }


def resolve_count(data_type, count=None):
  data_type = normalize_data_type(data_type)
  if data_type == "RAW":
    if count is None:
      return 1
    if int(count) <= 0:
      raise ValueError("--count must be greater than zero")
    return int(count)

  expected_count = count_for_type(data_type)
  if count is not None and int(count) != expected_count:
    raise ValueError(f"--count={count} does not match --type {data_type} ({expected_count} values)")
  return expected_count


def resolve_protocol_address(address, zero_based=False):
  if address is None:
    raise ValueError("Modbus operations require --address")

  protocol_address = int(address)
  if not zero_based:
    protocol_address -= 1
  if protocol_address < 0:
    raise ValueError("Resolved Modbus protocol address must be >= 0")
  return protocol_address


def _join_be_words(regs):
  return b"".join((int(reg) & 0xFFFF).to_bytes(2, "big") for reg in regs)


def _join_le_words(regs):
  return _join_be_words(list(regs)[::-1])


def decode_registers(regs, data_type):
  data_type = normalize_data_type(data_type)
  regs = list(regs)

  if data_type == "RAW":
    return regs

  if data_type == "U16":
    return int(regs[0]) & 0xFFFF
  if data_type == "S16":
    value = int(regs[0]) & 0xFFFF
    return value - 0x10000 if value & 0x8000 else value
  if data_type in ("U32", "U32_BE"):
    return struct.unpack(">I", _join_be_words(regs))[0]
  if data_type in ("S32", "S32_BE"):
    return struct.unpack(">i", _join_be_words(regs))[0]
  if data_type == "U32_LE":
    return struct.unpack(">I", _join_le_words(regs))[0]
  if data_type == "S32_LE":
    return struct.unpack(">i", _join_le_words(regs))[0]
  if data_type in ("U64", "U64_BE"):
    return struct.unpack(">Q", _join_be_words(regs))[0]
  if data_type in ("S64", "S64_BE"):
    return struct.unpack(">q", _join_be_words(regs))[0]
  if data_type == "U64_LE":
    return struct.unpack(">Q", _join_le_words(regs))[0]
  if data_type == "S64_LE":
    return struct.unpack(">q", _join_le_words(regs))[0]
  if data_type in ("FLOAT", "FLOAT_BE"):
    return struct.unpack(">f", _join_be_words(regs))[0]
  if data_type == "FLOAT_LE":
    return struct.unpack(">f", _join_le_words(regs))[0]
  raise ValueError(f"Unsupported --type '{data_type}'")


def _round_scaled_integer(value):
  if value >= 0:
    return int(math.floor(value + 0.5))
  return int(math.ceil(value - 0.5))


def _encode_unsigned(value, bits):
  max_value = (1 << bits) - 1
  value = int(value)
  if value < 0 or value > max_value:
    raise ValueError(f"Value {value} is outside unsigned {bits}-bit range")
  return value


def _encode_signed(value, bits):
  min_value = -(1 << (bits - 1))
  max_value = (1 << (bits - 1)) - 1
  value = int(value)
  if value < min_value or value > max_value:
    raise ValueError(f"Value {value} is outside signed {bits}-bit range")
  if value < 0:
    value += 1 << bits
  return value


def _split_be_words(value, word_count):
  words = []
  for shift in range(word_count - 1, -1, -1):
    words.append((value >> (shift * 16)) & 0xFFFF)
  return words


def encode_registers(value, data_type, factor=1):
  data_type = normalize_data_type(data_type)

  if data_type == "RAW":
    if isinstance(value, list):
      regs = value
    else:
      regs = [value]
    encoded = []
    for reg in regs:
      if isinstance(reg, bool):
        reg = int(reg)
      if not isinstance(reg, int):
        raise ValueError("RAW Modbus writes require an integer or a list of integers")
      if reg < 0 or reg > 0xFFFF:
        raise ValueError("RAW Modbus register values must be between 0 and 65535")
      encoded.append(reg)
    return encoded

  scaled_value = value
  if factor not in (0, 0.0):
    scaled_value = value / factor

  if data_type not in ("FLOAT", "FLOAT_BE", "FLOAT_LE"):
    scaled_value = _round_scaled_integer(float(scaled_value))

  if data_type == "U16":
    return [_encode_unsigned(scaled_value, 16)]
  if data_type == "S16":
    return [_encode_signed(scaled_value, 16)]
  if data_type in ("U32", "U32_BE"):
    return _split_be_words(_encode_unsigned(scaled_value, 32), 2)
  if data_type in ("S32", "S32_BE"):
    return _split_be_words(_encode_signed(scaled_value, 32), 2)
  if data_type == "U32_LE":
    return _split_be_words(_encode_unsigned(scaled_value, 32), 2)[::-1]
  if data_type == "S32_LE":
    return _split_be_words(_encode_signed(scaled_value, 32), 2)[::-1]
  if data_type in ("U64", "U64_BE"):
    return _split_be_words(_encode_unsigned(scaled_value, 64), 4)
  if data_type in ("S64", "S64_BE"):
    return _split_be_words(_encode_signed(scaled_value, 64), 4)
  if data_type == "U64_LE":
    return _split_be_words(_encode_unsigned(scaled_value, 64), 4)[::-1]
  if data_type == "S64_LE":
    return _split_be_words(_encode_signed(scaled_value, 64), 4)[::-1]
  if data_type in ("FLOAT", "FLOAT_BE"):
    packed = struct.pack(">f", float(scaled_value))
    return list(struct.unpack(">HH", packed))
  if data_type == "FLOAT_LE":
    packed = struct.pack(">f", float(scaled_value))
    return list(struct.unpack(">HH", packed))[::-1]
  raise ValueError(f"Unsupported --data-type '{data_type}'")


def _normalize_output_value(value):
  if isinstance(value, float) and math.isfinite(value) and value.is_integer():
    return int(value)
  return value


def read_modbus_registers(client, address, register_type="holding", count=None, data_type="RAW", factor=1, device_id=1, zero_based=False):
  register_type = normalize_register_type(register_type)
  data_type = normalize_data_type(data_type)
  count = resolve_count(data_type, count=count)
  protocol_address = resolve_protocol_address(address, zero_based=zero_based)

  if register_type == "holding":
    response = client.read_holding_registers(address=protocol_address, count=count, device_id=device_id)
  else:
    response = client.read_input_registers(address=protocol_address, count=count, device_id=device_id)

  if response is None:
    raise RuntimeError("No Modbus response received")
  if hasattr(response, "isError") and response.isError():
    raise RuntimeError(f"Modbus read failed: {response}")

  registers = list(getattr(response, "registers", []) or [])
  if len(registers) < count:
    raise RuntimeError(f"Incomplete register response: expected {count}, got {len(registers)}")

  raw_value = decode_registers(registers, data_type)
  value = raw_value if data_type == "RAW" else _normalize_output_value(raw_value * factor)
  debug("READ", register_type, address, protocol_address, device_id, data_type, registers, value)

  return {
    "address": int(address),
    "protocol_address": protocol_address,
    "register_type": register_type,
    "data_type": data_type,
    "count": count,
    "device_id": int(device_id),
    "factor": factor,
    "registers": registers,
    "value": value,
  }


def write_modbus_registers(client, address, value, data_type="RAW", factor=1, device_id=1, zero_based=False):
  if value is None:
    raise ValueError("write requires --value")

  data_type = normalize_data_type(data_type)
  protocol_address = resolve_protocol_address(address, zero_based=zero_based)
  registers = encode_registers(value, data_type, factor=factor)

  if len(registers) == 1:
    response = client.write_register(address=protocol_address, value=registers[0], device_id=device_id)
  else:
    response = client.write_registers(address=protocol_address, values=registers, device_id=device_id)

  if response is None:
    raise RuntimeError("No Modbus response received")
  if hasattr(response, "isError") and response.isError():
    raise RuntimeError(f"Modbus write failed: {response}")

  debug("WRITE", address, protocol_address, device_id, data_type, registers, value)
  return {
    "address": int(address),
    "protocol_address": protocol_address,
    "data_type": data_type,
    "count": len(registers),
    "device_id": int(device_id),
    "factor": factor,
    "registers": registers,
    "value": value,
    "status": "ok",
  }


def execute_modbus_command(command, args):
  command = str(command).strip().lower()
  register_args = resolve_register_arguments(args)
  transport = ModbusTransportConfig._normalise_transport(args.transport, {
    "transport": args.transport,
    "serial_port": args.serial_port,
  })
  port = args.port
  if transport == "tcp" and port in (None, 22):
    port = 502

  transport_config = ModbusTransportConfig.build(config={
    "transport": args.transport,
    "host": args.host,
    "port": port,
    "serial_port": args.serial_port,
    "baudrate": args.baudrate,
    "bytesize": args.bytesize,
    "parity": args.parity,
    "stopbits": args.stopbits,
    "framer": args.framer,
    "timeout": args.timeout,
    "retries": args.retries,
    "reconnect_delay": args.reconnect_delay,
    "reconnect_delay_max": args.reconnect_delay_max,
    "handle_local_echo": args.handle_local_echo,
  })

  client = transport_config.create_client()
  connected = client.connect()
  if not connected:
    warning("CONNECT FAIL", transport_config.label)
    raise RuntimeError(f"Unable to connect to {transport_config.label}")

  try:
    if command == "read":
      result = read_modbus_registers(
        client=client,
        address=register_args["address"],
        register_type=register_args["register_type"],
        count=register_args["count"],
        data_type=register_args["data_type"],
        factor=register_args["factor"],
        device_id=register_args["device_id"],
        zero_based=args.zero_based,
      )
    elif command == "write":
      if register_args["register_type"] != "holding":
        raise ValueError("write supports only --kind holding")
      result = write_modbus_registers(
        client=client,
        address=register_args["address"],
        value=args.value,
        data_type=register_args["data_type"],
        factor=register_args["factor"],
        device_id=register_args["device_id"],
        zero_based=args.zero_based,
      )
      result["register_type"] = "holding"
    else:
      raise ValueError(f"Unsupported Modbus command '{command}'")

    result["transport"] = transport_config.transport
    result["endpoint"] = transport_config.label
    return result
  finally:
    client.close()
