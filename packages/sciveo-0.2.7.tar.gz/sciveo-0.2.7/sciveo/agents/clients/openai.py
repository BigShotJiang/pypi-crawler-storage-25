#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

try:
  from openai import OpenAI
except ImportError:
  OpenAI = None

from sciveo.tools.logger import *
from sciveo.agents.base import LLMClientBase
from sciveo.agents.media import content_parts, image_data_url


class OpenAIClient(LLMClientBase):
  def __init__(
    self,
    api_key: str,
    model: str = "gpt-5.4",
    reasoning_effort: str = "medium",
    verbosity: str = "low",
    max_output_tokens: int = 4096,
    base_url: str = None,
  ):
    if OpenAI is None:
      raise ImportError("OpenAI provider requires the 'openai' package to be installed")

    client_kwargs = {"api_key": api_key}
    if base_url:
      client_kwargs["base_url"] = base_url

    self.client = OpenAI(**client_kwargs)
    self.model = model
    self.reasoning_effort = reasoning_effort
    self.verbosity = verbosity
    self.max_output_tokens = max_output_tokens

  def _format_message(self, role: str, content) -> dict:
    role = str(role or "user").strip().lower()
    if role not in ("user", "assistant", "system", "developer"):
      role = "user"
    content_type = "output_text" if role == "assistant" else "input_text"
    items = []
    for part in content_parts(content):
      if part.get("type") == "image":
        if role == "assistant":
          continue
        items.append({
          "type": "input_image",
          "image_url": image_data_url(part),
        })
      else:
        items.append({
          "type": content_type,
          "text": str(part.get("text", "")),
        })

    return {
      "role": role,
      "content": items or [{"type": content_type, "text": ""}],
    }

  def _extract_text(self, response) -> str:
    output_text = getattr(response, "output_text", None)
    if output_text:
      return output_text.strip()

    parts = []
    for item in getattr(response, "output", []) or []:
      item_type = getattr(item, "type", None)
      if item_type != "message":
        continue

      content_items = getattr(item, "content", None) or []
      for content in content_items:
        content_type = getattr(content, "type", None)
        if content_type in ("output_text", "text"):
          text = getattr(content, "text", None)
          if text:
            parts.append(text)

    if parts:
      return "\n".join(parts).strip()

    if hasattr(response, "model_dump_json"):
      return response.model_dump_json(indent=2)

    return str(response)

  def chat(self, messages: list[dict], tools=None, system_prompt: str = None) -> str:
    try:
      prompt_messages = []
      if system_prompt:
        prompt_messages.append(self._format_message("system", system_prompt))

      for message in messages:
        prompt_messages.append(
          self._format_message(
            message.get("role", "user"),
            message.get("content", ""),
          )
        )

      response = self.client.responses.create(
        model=self.model,
        input=prompt_messages,
        reasoning={"effort": self.reasoning_effort},
        text={"verbosity": self.verbosity},
        max_output_tokens=self.max_output_tokens,
      )

      text_out = self._extract_text(response)
      debug("OpenAIClient", {"model": self.model, "text": text_out})
      return text_out

    except Exception as e:
      return f"[OpenAI error] {e}"
