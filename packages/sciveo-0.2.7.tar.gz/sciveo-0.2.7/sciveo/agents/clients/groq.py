#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

from groq import Groq
from sciveo.tools.logger import *
from sciveo.agents.base import LLMClientBase
from sciveo.agents.media import content_text, messages_have_images


class GroqClient(LLMClientBase):
  def __init__(self, api_key, model="llama-3.3-70b-versatile", temperature=0.2, max_tokens=4096):
    self.client = Groq(api_key=api_key)
    self.model = model
    self.temperature = temperature
    self.max_tokens = max_tokens

  def chat(self, messages: list[dict], tools=None, system_prompt: str = None) -> str:
    try:
      if messages_have_images(messages):
        return "[Groq error] Image input is not supported by this provider adapter"

      chat_messages = list(messages)
      chat_messages = [
        {"role": message.get("role", "user"), "content": content_text(message.get("content", ""), image_placeholder=True)}
        for message in chat_messages
      ]
      if system_prompt:
        chat_messages = [{"role": "system", "content": system_prompt}] + chat_messages

      completion = self.client.chat.completions.create(
        model=self.model,
        messages=chat_messages,
        temperature=self.temperature,
        max_tokens=self.max_tokens
      )

      return completion.choices[0].message.content.strip()

    except Exception as e:
      return f"[Groq error] {e}"
