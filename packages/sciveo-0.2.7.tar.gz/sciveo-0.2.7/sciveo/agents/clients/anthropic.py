#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import json
try:
  from anthropic import Anthropic
except ImportError:
  Anthropic = None
from sciveo.tools.logger import *
from sciveo.agents.base import LLMClientBase
from sciveo.agents.media import content_parts


def _append_json_block(blocks: list, json_block):
  if not isinstance(json_block, dict):
    return

  if json_block.get("type") == "tool_use":
    blocks.append({
      "type": "tool_use",
      "name": json_block.get("name"),
      "input": json_block.get("input", {})
    })
  else:
    blocks.append({
      "type": "text",
      "text": json_block.get("text", "")
    })


def _parse_json_blocks_text(text: str) -> list:
  decoder = json.JSONDecoder()
  index = 0
  values = []
  text = text or ""

  while index < len(text):
    while index < len(text) and text[index].isspace():
      index += 1

    if index >= len(text):
      break

    value, next_index = decoder.raw_decode(text, index)
    values.append(value)
    index = next_index

  blocks = []
  for value in values:
    if isinstance(value, list):
      for item in value:
        _append_json_block(blocks, item)
    else:
      _append_json_block(blocks, value)

  return blocks


class AnthropicClient(LLMClientBase):
  """
  Anthropic client using Messages API with native tool support.
  Accepts structured tools list, handles tool_use and text blocks.
  """

  def __init__(self, api_key: str, model: str = "claude-sonnet-4-20250514", max_tokens: int = 4096, temperature: float = 0.2):
    """
    Initialize Anthropic Messages API client.
    """
    if Anthropic is None:
      raise ImportError("Anthropic provider requires the 'anthropic' package to be installed")
    self.client = Anthropic(api_key=api_key)
    self.model = model
    self.max_tokens = max_tokens
    self.temperature = temperature

  def _format_messages(self, messages: list[dict]) -> list[dict]:
    result = []
    for message in messages or []:
      role = message.get("role", "user")
      if role not in ("user", "assistant"):
        role = "user"
      blocks = []
      for part in content_parts(message.get("content", "")):
        if part.get("type") == "image":
          blocks.append({
            "type": "image",
            "source": {
              "type": "base64",
              "media_type": part.get("mime_type") or "image/png",
              "data": part.get("data") or "",
            },
          })
        else:
          blocks.append({"type": "text", "text": str(part.get("text", ""))})
      result.append({"role": role, "content": blocks or [{"type": "text", "text": ""}]})
    return result

  def chat(self, messages: list[dict], tools=None, system_prompt: str = None) -> list[dict]:
    """
    Send messages to Claude with optional tools.
    messages: [{"role": "user|assistant", "content": "..."}]
    tools: [{"name": str, "description": str, "input_schema": dict}, ...]
    Returns: list of blocks [{"type": "text|tool_use", ...}, ...]
    """
    try:
      message_tools = list(tools or [])

      resp = self.client.messages.create(
        model=self.model,
        messages=self._format_messages(messages),
        tools=message_tools,
        system=system_prompt,
        max_tokens=self.max_tokens,
        temperature=self.temperature
      )

      # resp.content is a list of TextBlock or ToolUseBlock
      blocks = []
      for block in resp.content:
        if block.type == "text":
          try:
            parsed_blocks = _parse_json_blocks_text(block.text)
            if parsed_blocks:
              blocks.extend(parsed_blocks)
            else:
              blocks.append({"type": "text", "text": block.text})
          except Exception:
            blocks.append({"type": "text", "text": block.text})
        elif block.type == "tool_use":
          blocks.append({
            "type": "tool_use",
            "name": block.name,
            "input": block.input
          })
        else:
          # Fallback: treat unknown blocks as text
          blocks.append({"type": "text", "text": str(block)})

      debug("AnthropicClient blocks", blocks)
      return blocks

    except Exception as e:
      return [{"type": "text", "text": f"[Anthropic error] {e}"}]
