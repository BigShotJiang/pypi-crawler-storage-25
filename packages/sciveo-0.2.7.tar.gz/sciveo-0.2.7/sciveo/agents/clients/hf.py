#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import json
import time

from sciveo.agents.base import LLMClientBase
from sciveo.tools.logger import *


DEFAULT_HF_RUNTIME_URL = "http://127.0.0.1:8910"


class HuggingFaceRuntimeClient(LLMClientBase):
  """
  Client for the Sciveo-owned Hugging Face runtime server.
  """

  def __init__(
    self,
    base_url: str = DEFAULT_HF_RUNTIME_URL,
    model: str = None,
    auth_token: str = None,
    temperature: float = 0.2,
    max_new_tokens: int = 65536,
    timeout: float = 600,
    stream: bool = True,
  ):
    self.base_url = str(base_url or DEFAULT_HF_RUNTIME_URL).rstrip("/")
    self.model = model or "server-default"
    self.request_model = model
    self.auth_token = auth_token
    self.temperature = temperature
    self.max_new_tokens = max_new_tokens
    self.timeout = timeout
    self.stream = bool(stream)
    self.stream_callback = None
    self.last_metrics = None

  def _headers(self) -> dict:
    headers = {}
    if self.auth_token:
      headers["Authorization"] = f"Bearer {self.auth_token}"
    return headers

  def chat(self, messages: list[dict], tools=None, system_prompt: str = None) -> str:
    if self.stream:
      return self._chat_stream(messages=messages, tools=tools, system_prompt=system_prompt)
    return self._chat_batch(messages=messages, tools=tools, system_prompt=system_prompt)

  def _payload(self, messages: list[dict], system_prompt: str = None) -> dict:
    payload = {
      "messages": list(messages or []),
      "system_prompt": system_prompt,
      "temperature": self.temperature,
      "max_new_tokens": self.max_new_tokens,
    }
    if self.request_model:
      payload["model"] = self.request_model
    return payload

  def _emit_stream(self, kind: str, data: dict):
    callback = getattr(self, "stream_callback", None)
    if callback is None:
      return
    try:
      callback(kind, data)
    except Exception as e:
      exception(e)

  def _chat_batch(self, messages: list[dict], tools=None, system_prompt: str = None) -> str:
    try:
      import requests

      self.last_metrics = None
      payload = self._payload(messages, system_prompt=system_prompt)

      request_start = time.perf_counter()
      response = requests.post(
        f"{self.base_url}/chat",
        json=payload,
        headers=self._headers(),
        timeout=self.timeout,
      )
      request_seconds = time.perf_counter() - request_start
      if response.status_code != 200:
        return f"[Hugging Face runtime error] HTTP {response.status_code}: {response.text}"

      data = response.json()
      if data.get("error"):
        return f"[Hugging Face runtime error] {data.get('error')}"

      metrics = data.get("metrics")
      if isinstance(metrics, dict):
        self.last_metrics = dict(metrics)
        self.last_metrics["request_seconds"] = request_seconds

      text = data.get("text")
      if text is None and isinstance(data.get("message"), dict):
        text = data["message"].get("content")
      return str(text or "").strip()

    except Exception as e:
      return f"[Hugging Face runtime error] {e}"

  def _chat_stream(self, messages: list[dict], tools=None, system_prompt: str = None) -> str:
    try:
      import requests

      self.last_metrics = None
      payload = self._payload(messages, system_prompt=system_prompt)

      request_start = time.perf_counter()
      response = requests.post(
        f"{self.base_url}/chat/stream",
        json=payload,
        headers=self._headers(),
        timeout=self.timeout,
        stream=True,
      )
      if response.status_code != 200:
        return f"[Hugging Face runtime error] HTTP {response.status_code}: {response.text}"

      pieces = []
      final_text = None
      final_metrics = None
      for raw_line in response.iter_lines(decode_unicode=True):
        if not raw_line:
          continue
        if isinstance(raw_line, bytes):
          raw_line = raw_line.decode("utf-8")
        try:
          event = json.loads(raw_line)
        except Exception:
          continue

        event_type = event.get("type")
        if event_type == "error":
          return f"[Hugging Face runtime error] {event.get('error')}"
        if event_type == "token":
          text = str(event.get("text") or "")
          if text:
            pieces.append(text)
          self._emit_stream("llm_token", {
            "text": text,
            "metrics": dict(event.get("metrics") or {}),
          })
        elif event_type == "progress":
          self._emit_stream("llm_progress", {
            "metrics": dict(event.get("metrics") or {}),
          })
        elif event_type == "done":
          final_text = event.get("text")
          final_metrics = dict(event.get("metrics") or {})

      request_seconds = time.perf_counter() - request_start
      if isinstance(final_metrics, dict) and final_metrics:
        self.last_metrics = final_metrics
        self.last_metrics["request_seconds"] = request_seconds

      if final_text is None:
        final_text = "".join(pieces)
      return str(final_text or "").strip()

    except Exception as e:
      return f"[Hugging Face runtime error] {e}"
