#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

from sciveo.agents.base import LLMClientBase
from sciveo.agents.media import content_parts


DEFAULT_OLLAMA_URL = "http://127.0.0.1:11434"
DEFAULT_OLLAMA_MODEL = "qwen2.5-coder:7b"


class OllamaClient(LLMClientBase):
  """
  Compatibility client for a local or remote Ollama server.
  """

  def __init__(
    self,
    base_url: str = DEFAULT_OLLAMA_URL,
    model: str = DEFAULT_OLLAMA_MODEL,
    temperature: float = 0.2,
    max_tokens: int = 65536,
    timeout: float = 600,
  ):
    self.base_url = str(base_url or DEFAULT_OLLAMA_URL).rstrip("/")
    self.model = model or DEFAULT_OLLAMA_MODEL
    self.temperature = temperature
    self.max_tokens = max_tokens
    self.timeout = timeout

  def chat(self, messages: list[dict], tools=None, system_prompt: str = None) -> str:
    try:
      import requests

      chat_messages = []
      for message in messages or []:
        item = {
          "role": message.get("role", "user"),
          "content": "",
        }
        images = []
        text = []
        for part in content_parts(message.get("content", "")):
          if part.get("type") == "image":
            images.append(part.get("data") or "")
          else:
            text.append(str(part.get("text", "")))
        item["content"] = "\n".join(part for part in text if part)
        if images:
          item["images"] = images
        chat_messages.append(item)
      if system_prompt:
        chat_messages = [{"role": "system", "content": system_prompt}] + chat_messages

      response = requests.post(
        f"{self.base_url}/api/chat",
        json={
          "model": self.model,
          "messages": chat_messages,
          "stream": False,
          "options": {
            "temperature": self.temperature,
            "num_predict": self.max_tokens,
          },
        },
        timeout=self.timeout,
      )
      if response.status_code != 200:
        return f"[Ollama error] HTTP {response.status_code}: {response.text}"

      data = response.json()
      if data.get("error"):
        return f"[Ollama error] {data.get('error')}"

      if isinstance(data.get("message"), dict):
        return str(data["message"].get("content", "")).strip()
      return str(data.get("response", "")).strip()

    except Exception as e:
      return f"[Ollama error] {e}"
