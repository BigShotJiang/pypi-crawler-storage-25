_CLIENT_IMPORTS = {
  "OpenAIClient": ("sciveo.agents.clients.openai", "OpenAIClient"),
  "HuggingFaceRuntimeClient": ("sciveo.agents.clients.hf", "HuggingFaceRuntimeClient"),
  "OllamaClient": ("sciveo.agents.clients.ollama", "OllamaClient"),
  "AnthropicClient": ("sciveo.agents.clients.anthropic", "AnthropicClient"),
  "GroqClient": ("sciveo.agents.clients.groq", "GroqClient"),
  "GeminiClient": ("sciveo.agents.clients.gemini", "GeminiClient"),
}

__all__ = list(_CLIENT_IMPORTS.keys())


def __getattr__(name):
  if name not in _CLIENT_IMPORTS:
    raise AttributeError(name)

  module_name, attr_name = _CLIENT_IMPORTS[name]
  from importlib import import_module
  module = import_module(module_name)
  value = getattr(module, attr_name)
  globals()[name] = value
  return value
