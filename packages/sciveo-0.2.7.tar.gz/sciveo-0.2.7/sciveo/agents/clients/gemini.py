#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import base64

try:
  from google import genai
  from google.genai import types
except ImportError:
  genai = None
  types = None
from sciveo.tools.logger import *
from sciveo.agents.base import LLMClientBase
from sciveo.agents.media import content_parts, messages_have_images


class GeminiClient(LLMClientBase):
  def __init__(
    self,
    api_key: str,
    model: str = "gemini-2.5-flash",
    temperature: float = 0.2,
    max_output_tokens: int = 4096,
  ):
    """
    Uses the new google-genai SDK.
    """
    if genai is None or types is None:
      raise ImportError("Gemini provider requires the 'google-genai' package to be installed")

    # Create the unified GenAI client
    self.client = genai.Client(api_key=api_key)
    self.model = model
    self.temperature = temperature
    self.max_output_tokens = max_output_tokens

  def chat(self, messages: list[dict], tools=None, system_prompt: str = None) -> str:
    """
    messages: list of {"role": "user"|"assistant", "content": "..."}
    returns: plain text
    """
    try:
      prompt = ""
      image_parts = []
      if system_prompt:
        prompt += f"system: {system_prompt}\n"
      for m in messages:
        role = m["role"]
        text_parts = []
        for part in content_parts(m.get("content", "")):
          if part.get("type") == "image":
            image_parts.append(part)
            text_parts.append(f"[Image: {part.get('name') or 'image'}]")
          else:
            text_parts.append(str(part.get("text", "")))
        prompt += f"{role}: {' '.join(text_parts).strip()}\n"

      # Call the GenAI text generation
      if types is not None:
        config = types.GenerateContentConfig(
          temperature=self.temperature,
          max_output_tokens=self.max_output_tokens,
        )
      else:
        config = {
          "temperature": self.temperature,
          "max_output_tokens": self.max_output_tokens,
        }

      contents = prompt
      if messages_have_images(messages):
        contents = [prompt]
        for part in image_parts:
          contents.append(types.Part.from_bytes(
            data=base64.b64decode(part.get("data") or ""),
            mime_type=part.get("mime_type") or "image/png",
          ))

      response = self.client.models.generate_content(
        model=self.model,
        contents=contents,
        config=config,
      )

      # `response.text` contains the full generated output
      text_out = str(getattr(response, "text", "") or "").strip()

      debug("GeminiClient", {"model": self.model, "text": text_out})
      return text_out

    except Exception as e:
      return f"[Gemini error] {e}"
