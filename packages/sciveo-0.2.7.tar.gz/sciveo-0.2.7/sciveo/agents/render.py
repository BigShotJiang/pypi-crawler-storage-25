#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import json
import io
import os
import re
import shutil
import sys
import time

try:
  from pygments import highlight
  from pygments.formatters import TerminalFormatter
  from pygments.lexers import BashLexer, JsonLexer, PythonLexer, TextLexer, get_lexer_by_name
  _PYGMENTS_IMPORT_ERROR = None
except ImportError as exc:
  highlight = None
  TerminalFormatter = None
  BashLexer = None
  JsonLexer = None
  PythonLexer = None
  TextLexer = None
  get_lexer_by_name = None
  _PYGMENTS_IMPORT_ERROR = exc

try:
  from PIL import Image
  _PIL_IMPORT_ERROR = None
except ImportError as exc:
  Image = None
  _PIL_IMPORT_ERROR = exc

from sciveo.agents.media import image_bytes


_ANSI_RESET = "\033[0m"
_ANSI_STYLES = {
  "banner": "\033[1;36m",
  "muted": "\033[38;5;245m",
  "accent": "\033[1;34m",
  "prompt": "\033[1;32m",
  "command": "\033[1;33m",
  "error": "\033[1;31m",
  "inline": "\033[38;5;214m",
  "strong": "\033[1m",
  "emphasis": "\033[3m",
  "heading1": "\033[1;37m",
  "heading2": "\033[1;38;5;250m",
  "heading3": "\033[1;38;5;245m",
  "heading4": "\033[38;5;244m",
  "heading5": "\033[38;5;242m",
  "heading6": "\033[38;5;240m",
  "quote": "\033[38;5;109m",
  "list": "\033[38;5;111m",
  "rule": "\033[38;5;240m",
  "assistant": "\033[1;36m",
  "system": "\033[1;35m",
  "gutter": "\033[38;5;240m",
  "activity": "\033[38;5;111m",
}
_CODE_BLOCK_RE = re.compile(r"```([a-zA-Z0-9_+.-]*)\n(.*?)```", re.DOTALL)
_INLINE_CODE_RE = re.compile(r"`([^`\n]+)`")
_STRONG_RE = re.compile(r"(\*\*|__)(.+?)\1")
_EMPHASIS_RE = re.compile(r"(?<!\*)\*([^*\n]+)\*(?!\*)|(?<![A-Za-z0-9_])_([^_\n]+)_(?![A-Za-z0-9_])")
_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*#*\s*$")
_ULIST_RE = re.compile(r"^(\s*)[-*+]\s+(.+)$")
_OLIST_RE = re.compile(r"^(\s*)(\d+[.)])\s+(.+)$")
_BLOCKQUOTE_RE = re.compile(r"^>\s?(.*)$")
_RULE_RE = re.compile(r"^\s{0,3}([-*_])(?:\s*\1){2,}\s*$")
_IMAGE_ASCII_RAMP = " .:-=+*#%@"
_IMAGE_COLOR_CELL = "█"


def _image_resampling_filter():
  if Image is None:
    return None
  try:
    return Image.Resampling.LANCZOS
  except AttributeError:
    return Image.LANCZOS


def _heading_tone(level: int) -> str:
  try:
    level = int(level)
  except Exception:
    level = 1
  level = max(1, min(6, level))
  return f"heading{level}"


def _supports_color(stream=None) -> bool:
  stream = stream or sys.stdout
  try:
    return bool(stream.isatty()) and str(os.getenv("TERM", "")).lower() != "dumb"
  except Exception:
    return False


def _is_interactive_stream(stream=None) -> bool:
  stream = stream or sys.stdin
  try:
    return bool(stream.isatty())
  except Exception:
    return False


def _ansi(text: str, tone: str, enabled: bool = True) -> str:
  text = str(text)
  if not enabled:
    return text
  return f"{_ANSI_STYLES.get(tone, '')}{text}{_ANSI_RESET}"


def _ansi_rgb(text: str, rgb, enabled: bool = True) -> str:
  text = str(text)
  if not enabled:
    return text
  r, g, b = rgb
  return f"\033[38;2;{int(r)};{int(g)};{int(b)}m{text}{_ANSI_RESET}"


def _quantize_channel(value, levels: int) -> int:
  levels = max(2, int(levels or 2))
  step = 255.0 / float(levels - 1)
  return int(round(round(float(value) / step) * step))


def _quantize_rgb(rgb, levels: int = 6):
  return tuple(max(0, min(255, _quantize_channel(value, levels))) for value in rgb)


def _image_ascii_char(rgb, levels: int = 7) -> str:
  r, g, b = rgb
  luminance = (0.2126 * r) + (0.7152 * g) + (0.0722 * b)
  bucket_count = max(2, min(int(levels or 7), len(_IMAGE_ASCII_RAMP)))
  bucket = int(round((luminance / 255.0) * (bucket_count - 1)))
  bucket = max(0, min(bucket_count - 1, bucket))
  index = int(round((bucket / float(bucket_count - 1)) * (len(_IMAGE_ASCII_RAMP) - 1)))
  return _IMAGE_ASCII_RAMP[index]


def terminal_image_preview(
  image_part: dict,
  width: int = None,
  max_width: int = 64,
  max_height: int = 32,
  color: bool = True,
  color_levels: int = 16,
  symbol_levels: int = 7,
) -> str:
  if _PIL_IMPORT_ERROR is not None:
    return f"[image preview unavailable: Pillow is not installed]"

  try:
    image = Image.open(io.BytesIO(image_bytes(image_part))).convert("RGB")
  except Exception as e:
    return f"[image preview unavailable: {e}]"

  source_width, source_height = image.size
  if source_width <= 0 or source_height <= 0:
    return "[image preview unavailable: invalid image size]"

  try:
    terminal_width = int(shutil.get_terminal_size((100, 24)).columns or 100)
  except Exception:
    terminal_width = 100

  if width is None:
    width = min(int(max_width), max(12, terminal_width - 8))
  width = max(4, min(int(width), int(max_width), max(4, terminal_width - 8)))
  height = max(1, int(round((source_height / float(source_width)) * width * 0.5)))
  height = max(1, min(height, int(max_height)))

  resized = image.resize((width, height), _image_resampling_filter())
  lines = []
  name = image_part.get("name") or "image"
  mime_type = image_part.get("mime_type") or "image"
  lines.append(f"Image preview: {name} ({mime_type}, {source_width}x{source_height})")
  for y in range(height):
    chars = []
    for x in range(width):
      rgb = resized.getpixel((x, y))
      if color:
        chars.append(_ansi_rgb(_IMAGE_COLOR_CELL, rgb, True))
      else:
        quantized_rgb = _quantize_rgb(rgb, levels=color_levels)
        chars.append(_image_ascii_char(quantized_rgb, levels=symbol_levels))
    lines.append("".join(chars).rstrip())
  return "\n".join(lines)


def _lexer_for_language(language: str):
  if _PYGMENTS_IMPORT_ERROR is not None:
    return None

  lang = str(language or "").strip().lower()
  aliases = {
    "sh": BashLexer,
    "bash": BashLexer,
    "shell": BashLexer,
    "zsh": BashLexer,
    "json": JsonLexer,
    "jsonc": JsonLexer,
    "js": JsonLexer,
    "python": PythonLexer,
    "py": PythonLexer,
    "text": TextLexer,
    "plain": TextLexer,
    "plaintext": TextLexer,
  }
  lexer_cls = aliases.get(lang)
  if lexer_cls is not None:
    return lexer_cls()

  if not lang or get_lexer_by_name is None:
    return TextLexer() if TextLexer is not None else None

  try:
    return get_lexer_by_name(lang)
  except Exception:
    return TextLexer() if TextLexer is not None else None


def _highlight_code(code: str, language: str = "", color: bool = True) -> str:
  text = str(code or "").rstrip("\n")
  if not text:
    return ""
  if not color or _PYGMENTS_IMPORT_ERROR is not None:
    return text

  lexer = _lexer_for_language(language)
  if lexer is None or highlight is None or TerminalFormatter is None:
    return text

  return highlight(text, lexer, TerminalFormatter()).rstrip("\n")


class _AgentStreamTextFilter:
  def __init__(self):
    self.raw = ""

  def feed(self, text: str) -> str:
    chunk = str(text or "")
    if not chunk:
      return ""

    self.raw += chunk
    return chunk


class RenderContext:
  def __init__(self, output_func=print, color: bool = True):
    self.output_func = output_func
    self.color = bool(color)

  def gutter(self, text: str) -> str:
    prefix = _ansi("│", "gutter", self.color)
    if not str(text):
      return prefix
    return f"{prefix} {text}"

  def code_line(self, text: str) -> str:
    prefix = _ansi("│", "gutter", self.color)
    value = str(text or "")
    if value:
      return f"{prefix} {value}"
    return prefix

  def style_inline_code(self, text: str) -> str:
    def repl(match):
      return _ansi(match.group(1), "inline", self.color)

    return _INLINE_CODE_RE.sub(repl, text)

  def style_inline_markdown(self, text: str) -> str:
    value = self.style_inline_code(str(text or ""))

    def strong_repl(match):
      return _ansi(match.group(2), "strong", self.color)

    def emphasis_repl(match):
      content = match.group(1) or match.group(2) or ""
      return _ansi(content, "emphasis", self.color)

    value = _STRONG_RE.sub(strong_repl, value)
    value = _EMPHASIS_RE.sub(emphasis_repl, value)
    return value

  def markdown_line(self, text: str, tone: str = None) -> str:
    value = self.style_inline_markdown(text)
    if tone:
      value = _ansi(value, tone, self.color)
    return self.gutter(value)


class ParagraphSectionRenderer:
  def render(self, text: str, context: RenderContext):
    value = str(text or "").strip("\n")
    if not value.strip():
      return
    for paragraph in value.split("\n\n"):
      paragraph = paragraph.strip()
      if not paragraph:
        continue
      for line in paragraph.splitlines():
        self.render_line(line.rstrip(), context)

  def render_line(self, line: str, context: RenderContext):
    if _RULE_RE.match(line):
      context.output_func(context.gutter(_ansi("─" * 34, "rule", context.color)))
      return

    match = _HEADING_RE.match(line)
    if match:
      level = len(match.group(1))
      text = context.style_inline_markdown(match.group(2).strip())
      prefix = "#" * level
      context.output_func(context.gutter(_ansi(f"{prefix} {text}", _heading_tone(level), context.color)))
      return

    match = _BLOCKQUOTE_RE.match(line)
    if match:
      text = context.style_inline_markdown(match.group(1).strip())
      context.output_func(context.gutter(_ansi(f"▏ {text}", "quote", context.color)))
      return

    match = _ULIST_RE.match(line)
    if match:
      indent = "  " * (len(match.group(1).replace("\t", "  ")) // 2)
      text = context.style_inline_markdown(match.group(2).strip())
      marker = _ansi("•", "list", context.color)
      context.output_func(context.gutter(f"{indent}{marker} {text}"))
      return

    match = _OLIST_RE.match(line)
    if match:
      indent = "  " * (len(match.group(1).replace("\t", "  ")) // 2)
      marker = _ansi(match.group(2), "list", context.color)
      text = context.style_inline_markdown(match.group(3).strip())
      context.output_func(context.gutter(f"{indent}{marker} {text}"))
      return

    context.output_func(context.markdown_line(line.rstrip()))


class CodeSectionRenderer:
  languages = set()

  def __init__(self, label: str = None, highlight_language: str = None):
    self.label = label
    self.highlight_language = highlight_language

  def render(self, code: str, context: RenderContext, language: str = ""):
    label = self.label or str(language or "text").strip() or "text"
    context.output_func(context.gutter(_ansi(label, "accent", context.color)))
    highlighted = _highlight_code(
      self.prepare_code(code),
      language=self.highlight_language or language,
      color=context.color,
    )
    for line in highlighted.splitlines() or [""]:
      context.output_func(context.code_line(line))

  def prepare_code(self, code: str) -> str:
    return str(code or "").rstrip("\n")


class PythonCodeSectionRenderer(CodeSectionRenderer):
  languages = {"python", "py"}

  def __init__(self):
    super().__init__(highlight_language="python")


class JsonCodeSectionRenderer(CodeSectionRenderer):
  languages = {"json", "jsonc"}

  def __init__(self):
    super().__init__(highlight_language="json")

  def prepare_code(self, code: str) -> str:
    text = str(code or "").strip()
    try:
      return json.dumps(json.loads(text), indent=2, ensure_ascii=False)
    except Exception:
      return str(code or "").rstrip("\n")


class ShellCodeSectionRenderer(CodeSectionRenderer):
  languages = {"bash", "sh", "shell", "zsh"}

  def __init__(self):
    super().__init__(highlight_language="bash")


class TextCodeSectionRenderer(CodeSectionRenderer):
  languages = {"text", "plain", "plaintext", ""}

  def __init__(self):
    super().__init__(highlight_language="text")


class TerminalDocumentRenderer:
  def __init__(self, output_func=print, color: bool = True):
    self.context = RenderContext(output_func=output_func, color=color)
    self.paragraph_renderer = ParagraphSectionRenderer()
    self.default_code_renderer = CodeSectionRenderer()
    self.code_renderers = []
    for renderer in (
      PythonCodeSectionRenderer(),
      JsonCodeSectionRenderer(),
      ShellCodeSectionRenderer(),
      TextCodeSectionRenderer(),
    ):
      self.register_code_renderer(renderer)

  def register_code_renderer(self, renderer: CodeSectionRenderer):
    self.code_renderers.append(renderer)

  def render(self, text: str):
    value = str(text or "")
    if not value.strip():
      return

    last_index = 0
    had_block = False
    for match in _CODE_BLOCK_RE.finditer(value):
      had_block = True
      before = value[last_index:match.start()]
      self.paragraph_renderer.render(before, self.context)

      language = (match.group(1) or "").strip()
      code = match.group(2) or ""
      self._code_renderer(language).render(code, self.context, language=language)
      last_index = match.end()

    tail = value[last_index:]
    if had_block or tail.strip():
      self.paragraph_renderer.render(tail, self.context)

  def _code_renderer(self, language: str):
    lang = str(language or "").strip().lower()
    for renderer in self.code_renderers:
      if lang in renderer.languages:
        return renderer
    return self.default_code_renderer


def has_renderable_sections(text: str) -> bool:
  return bool(_CODE_BLOCK_RE.search(str(text or "")))


class ConsoleRenderer:
  def __init__(self, output_func=print, color: bool = None, stream_output_func=None, interactive: bool = True):
    self.output_func = output_func
    self.interactive = bool(interactive)
    default_stream = self.interactive and stream_output_func is None and output_func is print
    if stream_output_func is not None:
      self.stream_output_func = stream_output_func
    elif output_func is print:
      self.stream_output_func = self._write_stream
    else:
      self.stream_output_func = output_func
    self.color = (self.interactive and _supports_color()) if color is None else bool(color)
    self._live_terminal = self.interactive and default_stream and _supports_color(sys.stdout)
    self._document_renderer = TerminalDocumentRenderer(output_func=output_func, color=self.color)
    self._streaming_text = False
    self._stream_rows = 0
    self._stream_col = 0
    self._stream_line_open = False
    self._stream_replaceable = False
    self._last_progress_at = 0.0
    self._last_stream_progress_label = ""
    self._status_active = False
    self._last_llm_end_line = ""
    self._last_llm_end_visible = False

  def header(self, provider: str, model: str):
    self.output_func(_ansi("sciveo agent", "banner", self.color))
    self.output_func(_ansi("SOFTEL labs", "muted", self.color))
    self.output_func(_ansi(f"provider {provider}  model {model}", "muted", self.color))
    self.output_func(_ansi(f"cwd {os.getcwd()}", "muted", self.color))
    self.output_func(_ansi("commands /help  /tools  /clear  /exit", "muted", self.color))

  def error(self, text: str):
    self.output_func(_ansi(str(text), "error", self.color))

  def image_preview_text(self, image_part: dict, width: int = None) -> str:
    return terminal_image_preview(image_part, width=width, color=self.color)

  def render_message(self, role: str, text: str):
    value = str(text or "")
    if not value.strip():
      return

    tone = "assistant" if role == "assistant" else "system"
    self.output_func(_ansi(role, tone, self.color))
    self.render_text(value)

  def render_activity(self, kind: str, **data):
    if kind == "llm_token":
      self.render_stream_token(data.get("text", ""))
      return
    if kind == "llm_progress":
      self.render_stream_progress(data.get("metrics"))
      return
    if kind == "image_preview":
      self._clear_status()
      self.finish_stream()
      self.render_text(self.image_preview_text(data.get("image") or {}))
      return

    label = self._activity_label(kind, data)
    if not label:
      return
    if kind == "llm_start":
      self._last_progress_at = 0.0
      self._last_stream_progress_label = ""
      if self._live_terminal:
        self._write_status(label, tone="activity")
        return
    if kind == "llm_end":
      self._clear_status()
      self.finish_stream()
      metrics = self._format_llm_metrics(data.get("metrics"))
      if metrics:
        self._last_llm_end_line = f"{_ansi(label, 'activity', self.color)}{_ansi('  ' + metrics, 'muted', self.color)}"
        self.output_func(self._last_llm_end_line)
        self._last_llm_end_visible = True
        return
      self._last_llm_end_line = _ansi(label, "activity", self.color)
      self._last_llm_end_visible = True
    self._clear_status()
    self.output_func(_ansi(label, "activity", self.color))

  def render_stream_token(self, text: str):
    value = str(text or "")
    if not value:
      return

    if not self._streaming_text:
      self._clear_status()
      header = "generation"
      if self._last_stream_progress_label:
        header = f"{header}  {self._last_stream_progress_label}"
      self.output_func(_ansi(header, "activity", self.color))
      self._start_stream_tracking()
      self._write_stream_text(f"{self._gutter('')} ")
      self._streaming_text = True
    else:
      self._clear_status()

    self._write_stream_text(value.replace("\n", f"\n{self._gutter('')} "))

  def render_stream_progress(self, metrics):
    label = self._format_llm_metrics(metrics)
    if not label:
      return
    self._last_stream_progress_label = label

    now = time.monotonic()
    if now - self._last_progress_at < 0.75:
      return
    self._last_progress_at = now

    if self._live_terminal and not self._streaming_text:
      self._write_status(f"thinking  {label}", tone="muted")
      return
    if self._live_terminal:
      return

    if self._streaming_text:
      self.stream_output_func("\n")
    self.output_func(_ansi(f"progress  {label}", "muted", self.color))
    if self._streaming_text:
      self.stream_output_func(f"{self._gutter('')} ")

  def finish_stream(self):
    if self._streaming_text:
      self._write_stream_text("\n")
      self._streaming_text = False

  def replace_stream_with_message(self, role: str, text: str) -> bool:
    if not self._can_replace_stream():
      self.render_message(role, text)
      return False

    rows = int(self._stream_rows or 0)
    if self._last_llm_end_visible:
      rows += 1

    if rows > 0:
      self.stream_output_func(f"\033[{rows}F\033[J")

    self._reset_stream_tracking()
    self._last_llm_end_visible = False
    self.render_message(role, text)
    if self._last_llm_end_line:
      self.output_func(self._last_llm_end_line)
      self._last_llm_end_visible = True
    return True

  def _can_replace_stream(self) -> bool:
    return bool(self._live_terminal and self._stream_replaceable and self._stream_rows > 0)

  def _start_stream_tracking(self):
    if not self._live_terminal:
      return
    self._stream_replaceable = True
    self._stream_rows = 1
    self._stream_col = 0
    self._stream_line_open = False

  def _reset_stream_tracking(self):
    self._stream_replaceable = False
    self._stream_rows = 0
    self._stream_col = 0
    self._stream_line_open = False

  def _write_stream_text(self, text: str):
    value = str(text or "")
    if not value:
      return
    self.stream_output_func(value)
    self._track_stream_text(value)

  def _track_stream_text(self, text: str):
    if not self._stream_replaceable:
      return

    try:
      width = max(20, int(shutil.get_terminal_size((100, 24)).columns or 100))
    except Exception:
      width = 100

    for ch in str(text or ""):
      if ch == "\n":
        self._stream_col = 0
        self._stream_line_open = False
        continue
      if not self._stream_line_open:
        self._stream_rows += 1
        self._stream_line_open = True
      self._stream_col += 1
      if self._stream_col >= width:
        self._stream_col = 0
        self._stream_line_open = False

  def _write_stream(self, text: str):
    sys.stdout.write(str(text))
    sys.stdout.flush()

  def _write_status(self, text: str, tone: str = "muted"):
    if not self._live_terminal:
      self.output_func(_ansi(str(text), tone, self.color))
      return
    self.stream_output_func(f"\r\033[2K{_ansi(str(text), tone, self.color)}")
    self._status_active = True

  def _clear_status(self):
    if self._status_active and self._live_terminal:
      self.stream_output_func("\r\033[2K")
    self._status_active = False

  def render_text(self, text: str):
    self._document_renderer.render(text)

  def _gutter(self, text: str) -> str:
    return self._document_renderer.context.gutter(text)

  def _activity_label(self, kind: str, data: dict) -> str:
    if kind == "llm_start":
      return "thinking"
    if kind == "llm_end":
      return "thought complete"
    if kind == "tool_round_limit":
      return f"continue requested: {data.get('summary', '')}".strip()
    if kind == "parse_error":
      return f"parse error: {data.get('error', '')}".strip()
    if kind == "tool_approval":
      name = data.get("name", "tool")
      summary = data.get("summary", "")
      return f"approval required for {name}: {summary}".strip()
    if kind == "tool_start":
      return self._tool_start_label(data.get("name"), data.get("input"))
    if kind == "tool_end":
      return self._tool_end_label(data.get("name"), data.get("result"))
    return ""

  def _format_llm_metrics(self, metrics) -> str:
    if not isinstance(metrics, dict):
      return ""

    parts = []
    elapsed_seconds = metrics.get("request_seconds")
    if elapsed_seconds is None:
      elapsed_seconds = metrics.get("total_seconds")
    context_tps = metrics.get("context_tokens_per_second")
    generation_tps = metrics.get("generation_tokens_per_second")
    input_tokens = metrics.get("input_tokens")
    output_tokens = metrics.get("output_tokens")

    if elapsed_seconds is not None:
      try:
        parts.append(f"took {float(elapsed_seconds):.2f} seconds")
      except Exception:
        pass

    if context_tps:
      label = f"ctx {float(context_tps):.1f} tok/s"
      if input_tokens:
        label += f" ({int(input_tokens)} tok)"
      parts.append(label)

    if generation_tps:
      label = f"gen {float(generation_tps):.1f} tok/s"
      if output_tokens:
        label += f" ({int(output_tokens)} tok)"
      parts.append(label)

    return "  ".join(parts)

  def _tool_start_label(self, name: str, tool_input) -> str:
    name = str(name or "tool")
    tool_input = dict(tool_input or {})

    if name == "bash":
      return f"running bash: {tool_input.get('command', '')}".strip()
    if name == "read_file":
      return f"reading file: {tool_input.get('path', '')}".strip()
    if name == "write_file":
      return f"writing file: {tool_input.get('path', '')}".strip()
    if name == "list_dir":
      return f"listing dir: {tool_input.get('path', '.')}".strip()
    if name == "http_read":
      return f"reading url: {tool_input.get('url', '')}".strip()
    if name == "web_search":
      query = tool_input.get("query", "")
      return f"searching web: {query}".strip()
    return f"running {name}"

  def _tool_end_label(self, name: str, result) -> str:
    name = str(name or "tool")
    if isinstance(result, dict) and result.get("error"):
      return f"{name} failed"
    return f"{name} done"
