#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import json
import os
import re
import time

from sciveo.agents.media import build_user_content, sanitize_content_for_history
from sciveo.tools.logger import debug, exception


DEFAULT_AGENT_PROMPT = """
You are a careful local agent working inside a project and on a local machine.
Stay focused on the user's current goal by using the conversation history and the available tools.
You may answer general questions directly, and you may also help with code, files, shell workflows, local inspection, and other practical tasks that fit the available tools and permissions.
Prefer the bash tool for directory listings, search, tests, system inspection, and shell workflows.
Use read_file for targeted file inspection and write_file for direct file updates.
Do not claim you are unable to help unless a required tool, permission, or capability is actually missing.
Be concise, accurate, and do not invent tool results.
""".strip()


class ToolCall:
  def __init__(self, name: str, input: dict):
    self.name = name
    self.input = input or {}


class AgentBlock:
  def __init__(self, block_type: str, content):
    self.type = block_type
    self.content = content


_JSON_FENCE_RE = re.compile(r"^```(?:json|jsonc)?\s*\n(.*?)\n?```\s*$", re.IGNORECASE | re.DOTALL)
_THINK_BLOCK_RE = re.compile(r"<think\b[^>]*>.*?</think>", re.IGNORECASE | re.DOTALL)


def _without_think_blocks(text: str) -> str:
  return _THINK_BLOCK_RE.sub("", str(text or "")).strip()


def canonical_agent_block_json(block) -> str:
  if isinstance(block, AgentBlock):
    if block.type == "tool_use":
      value = {
        "type": "tool_use",
        "name": block.content.name,
        "input": block.content.input or {},
      }
    elif block.type == "text":
      value = {
        "type": "text",
        "text": block.content or "",
      }
    else:
      value = {"type": block.type, "text": str(block.content or "")}
  else:
    value = block
  return json.dumps(value, ensure_ascii=False)


def _is_agent_block_item(item) -> bool:
  return isinstance(item, dict) and item.get("type") in ("text", "tool_use")


def _is_agent_block_payload(value) -> bool:
  if isinstance(value, dict):
    return _is_agent_block_item(value)
  if isinstance(value, list) and value:
    return all(_is_agent_block_item(item) for item in value)
  return False


def _agent_json_candidates(text: str):
  value = str(text or "").strip()
  if not value:
    return

  yield value
  stripped = _without_think_blocks(value)
  if stripped and stripped != value:
    yield stripped

  match = _JSON_FENCE_RE.match(value)
  if match:
    yield match.group(1).strip()

  lowered = value.lower()
  if lowered.startswith("json\n"):
    yield value.split("\n", 1)[1].strip()
  elif lowered.startswith("json\r\n"):
    yield value.split("\n", 1)[1].strip()

  for candidate in (stripped, value):
    for match in re.finditer(r"[\[{]\s*[\"']type[\"']", candidate):
      yield candidate[match.start():].strip()
    for marker in ("[", "{"):
      start = candidate.find(marker)
      if start > 0:
        yield candidate[start:].strip()


def _extract_lenient_json_string(text: str, key: str):
  match = re.search(rf"[\"']{re.escape(key)}[\"']\s*:\s*[\"']", str(text or ""))
  if not match:
    return None

  quote = text[match.end() - 1]
  index = match.end()
  chars = []
  while index < len(text):
    char = text[index]
    if char == "\\" and index + 1 < len(text):
      chars.append(text[index + 1])
      index += 2
      continue
    if char == quote:
      next_index = index + 1
      while next_index < len(text) and text[next_index].isspace():
        next_index += 1
      if next_index >= len(text) or text[next_index] in ",}]\n\r":
        return "".join(chars)
    chars.append(char)
    index += 1
  return None


def _parse_lenient_tool_json(text: str):
  value = str(text or "").strip()
  if not _looks_like_agent_json(value):
    return None

  start_match = re.search(r"[\[{]\s*[\"']type[\"']\s*:\s*[\"']tool_use[\"']", value)
  if not start_match:
    return None
  value = value[start_match.start():].strip()

  name = _extract_lenient_json_string(value, "name")
  if not name:
    return None

  input_value = {}
  input_match = re.search(r"[\"']input[\"']\s*:\s*(\{.*)", value, re.DOTALL)
  input_was_parsed = False
  if input_match:
    input_text = input_match.group(1).strip()
    for end in range(len(input_text), 0, -1):
      if input_text[end - 1] != "}":
        continue
      try:
        parsed_value = json.loads(input_text[:end])
      except Exception:
        continue
      if isinstance(parsed_value, dict):
        input_value = parsed_value
        input_was_parsed = True
        break

  if name == "bash" and "command" not in input_value:
    command = _extract_lenient_json_string(value, "command")
    if command is not None:
      input_value["command"] = command
    elif "cmd" not in input_value:
      command = _extract_lenient_json_string(value, "cmd")
      if command is not None:
        input_value["cmd"] = command

  if input_match and not input_was_parsed:
    if name != "bash" or not ("command" in input_value or "cmd" in input_value):
      return None

  if not isinstance(input_value, dict):
    input_value = {}
  return {"type": "tool_use", "name": name, "input": input_value}


def _parse_agent_json_string(text: str):
  for candidate in _agent_json_candidates(text):
    try:
      parsed = json.loads(candidate)
    except Exception:
      parsed = _parse_agent_json_documents(candidate)
      if parsed is None:
        parsed = _parse_lenient_tool_json(candidate)
        if parsed is None:
          continue
    if _is_agent_block_payload(parsed):
      return parsed
  return None


def _looks_like_agent_json(text: str) -> bool:
  value = str(text or "").strip().lower()
  if not value:
    return False
  return (
    '"tool_use"' in value
    or "'tool_use'" in value
    or (
      '"type"' in value
      and (
        '"input"' in value
        or '"name"' in value
        or '"text"' in value
      )
    )
  )


def _parse_agent_json_documents(text: str):
  decoder = json.JSONDecoder()
  index = 0
  blocks = []
  text = str(text or "")

  while index < len(text):
    while index < len(text) and text[index].isspace():
      index += 1
    if index >= len(text):
      break

    value_start = index
    try:
      value, index = decoder.raw_decode(text, index)
    except Exception:
      if not blocks:
        return None
      trailing_text = text[index:].strip()
      if trailing_text:
        blocks.append({"type": "text", "text": trailing_text})
      break

    if not _is_agent_block_payload(value):
      if not blocks:
        return None
      trailing_text = text[value_start:].strip()
      if trailing_text:
        blocks.append({"type": "text", "text": trailing_text})
      break

    if isinstance(value, list):
      blocks.extend(value)
    else:
      blocks.append(value)

  return blocks


def parse_agent_blocks(raw_result) -> list:
  """
  Parse structured agent output. The preferred format is a JSON array of blocks:
  [{"type": "text", "text": "..."}, {"type": "tool_use", "name": "...", "input": {...}}]

  Plain text is accepted as a fallback so weaker models can still answer without tools.
  """
  raw = raw_result

  if isinstance(raw_result, str):
    raw = _parse_agent_json_string(raw_result)
    if raw is None:
      text = raw_result.strip()
      if _looks_like_agent_json(text):
        raise ValueError(
          "Agent response looked like tool JSON but was not valid JSON. "
          "Escape quotes inside strings, or answer directly as text when no tool is needed."
        )
      return [AgentBlock("text", text)] if text else []

  if isinstance(raw, dict):
    raw = [raw]

  if not isinstance(raw, list):
    raise ValueError("Agent response must be a list of blocks, a single block object, or a plain text string")

  blocks = []
  for item in raw:
    if not isinstance(item, dict):
      raise ValueError("Each agent block must be an object")

    block_type = item.get("type")
    if block_type == "text":
      blocks.append(AgentBlock("text", item.get("text", "")))
    elif block_type == "tool_use":
      blocks.append(
        AgentBlock(
          "tool_use",
          ToolCall(
            name=item.get("name"),
            input=item.get("input", {}),
          )
        )
      )
    else:
      raise ValueError(f"Unknown block type: {block_type}")

  return blocks


class ToolBase:
  schema = {
    "name": "",
    "description": "",
    "input_schema": {
      "type": "object",
      "properties": {},
      "required": [],
    },
  }

  def run(self, tool_input: dict, agent):
    raise NotImplementedError

  def approval_request(self, tool_input: dict, agent):
    return None


class ToolApprovalRequest:
  def __init__(self, tool_name: str, scope: str, summary: str, details: list[str] = None):
    self.tool_name = tool_name
    self.scope = scope
    self.summary = summary
    self.details = list(details or [])


class ToolHelp(ToolBase):
  schema = {
    "name": "help",
    "description": "List available tools",
    "input_schema": {
      "type": "object",
      "properties": {},
      "required": [],
    },
  }

  def run(self, tool_input, agent):
    lines = []
    for tool in agent.tools.values():
      name = tool.schema.get("name", type(tool).__name__)
      description = tool.schema.get("description", "")
      lines.append(f"{name}: {description}")
    return "\n".join(lines)


class LLMClientBase:
  def chat(self, messages: list[dict], tools=None, system_prompt: str = None):
    raise NotImplementedError


class AgentBase:
  def __init__(
    self,
    llm: LLMClientBase,
    system_prompt: str = None,
    max_tool_rounds: int = 8,
    tool_output_limit: int = 4 * 65536,
    approval_callback=None,
    approval_root: str = None,
    activity_callback=None,
  ):
    self.llm = llm
    self.tools = {}
    self.messages = []
    self.system_prompt = system_prompt or DEFAULT_AGENT_PROMPT
    self.max_tool_rounds = max_tool_rounds
    self.tool_output_limit = tool_output_limit
    self.approval_callback = approval_callback
    self.approval_root = os.path.abspath(approval_root or os.getcwd())
    self.activity_callback = activity_callback

  @property
  def tool_schemas(self):
    return [tool.schema for tool in self.tools.values()]

  def register_tool(self, tool: ToolBase):
    debug("register_tool", tool.schema)
    self.tools[tool.schema["name"]] = tool

  def clear(self):
    self.messages = []

  def _emit_activity(self, kind: str, **data):
    callback = getattr(self, "activity_callback", None)
    if callback is None:
      return
    try:
      callback(kind, data, self)
    except Exception as e:
      exception(e)

  def _build_system_prompt(self) -> str:
    tool_lines = []
    for tool in self.tool_schemas:
      tool_name = tool.get("name", "")
      description = tool.get("description", "")
      input_schema = tool.get("input_schema") or {}
      properties = input_schema.get("properties") or {}
      required = set(input_schema.get("required") or [])
      if properties:
        args = []
        for key in properties.keys():
          suffix = " required" if key in required else " optional"
          args.append(f"{key} ({suffix})")
        tool_lines.append(f"- {tool_name}: {description}. Input: {', '.join(args)}")
      else:
        tool_lines.append(f"- {tool_name}: {description}. Input: none")

    tool_text = "\n".join(tool_lines)
    format_text = "\n".join([
      "When you need a tool, return only valid JSON as an array of blocks.",
      "Use tools only when you need to inspect, read, write, run, fetch, or verify something.",
      "For pure explanations or code snippets, answer directly with a text block and fenced code.",
      "User messages may include image attachments as structured content. Inspect them directly when the selected model supports image input.",
      "Do not call bash with echo/cat/printf just to produce answer text.",
      "A response is one turn. In one turn you may either answer with text, or request one tool.",
      "If you need a tool, return exactly one complete tool_use JSON object and no other text.",
      "After a tool_use object, stop generating. Wait for the tool result before deciding the next action.",
      "Never emit two tool_use objects in the same response. Never fabricate role labels such as user, assistant, or Tool result.",
      "",
      "Text block:",
      '{"type": "text", "text": "<response>"}',
      "",
      "Tool block:",
      '{"type": "tool_use", "name": "<tool_name>", "input": {"key": "value"}}',
      "",
      "Use exact tool names from the available tools list.",
      "If you do not need tools, return a single text block.",
    ])

    return f"{self.system_prompt}\n\nAvailable tools:\n{tool_text}\n\n{format_text}".strip()

  def _serialize_tool_result(self, result):
    if isinstance(result, (dict, list)):
      text = json.dumps(result, ensure_ascii=False)
    else:
      text = str(result)

    if len(text) > self.tool_output_limit:
      return text[:self.tool_output_limit] + "\n...[truncated]"
    return text

  def call_tool(self, name: str, tool_input):
    original_name = name
    name = self._resolve_tool_name(name)
    debug("TOOL", name, "input", tool_input)
    self._emit_activity("tool_start", name=name, input=tool_input)
    tool = self.tools.get(name)
    if tool is None:
      self._emit_activity("tool_end", name=name, input=tool_input, result={"error": f"Unknown tool: {original_name}"})
      return {"error": f"Unknown tool: {original_name}"}

    if tool_input is None:
      tool_input = {}
    if not isinstance(tool_input, dict):
      self._emit_activity("tool_end", name=name, input=tool_input, result={"error": f"Tool input for {name} must be an object"})
      return {"error": f"Tool input for {name} must be an object"}

    approval_request = tool.approval_request(tool_input, self)
    if approval_request is not None:
      self._emit_activity(
        "tool_approval",
        name=name,
        input=tool_input,
        scope=approval_request.scope,
        summary=approval_request.summary,
      )
      debug("TOOL APPROVAL", approval_request.tool_name, approval_request.scope, approval_request.summary)
      if self.approval_callback is None:
        result = {
          "error": f"Tool {name} requires approval",
          "scope": approval_request.scope,
          "summary": approval_request.summary,
        }
        self._emit_activity("tool_end", name=name, input=tool_input, result=result)
        return result

      is_approved = bool(self.approval_callback(approval_request, self))
      if not is_approved:
        result = {
          "error": f"Tool {name} denied by approval policy",
          "scope": approval_request.scope,
          "summary": approval_request.summary,
        }
        self._emit_activity("tool_end", name=name, input=tool_input, result=result)
        return result

    result = tool.run(tool_input, self)
    self._emit_activity("tool_end", name=name, input=tool_input, result=result)
    return result

  def _resolve_tool_name(self, name: str) -> str:
    value = str(name or "").strip()
    if value in self.tools:
      return value

    normalized = re.sub(r"[^a-z0-9_]+", " ", value.lower()).strip()
    aliases = {}
    for tool_name in self.tools.keys():
      lower_name = tool_name.lower()
      aliases[lower_name] = tool_name
      aliases[lower_name.replace("_", " ")] = tool_name

    if normalized in aliases:
      return aliases[normalized]

    for alias, tool_name in aliases.items():
      if normalized.startswith(alias + " "):
        return tool_name

    return value

  def _tool_round_limit_request(self):
    return ToolApprovalRequest(
      tool_name="agent",
      scope="tool_rounds",
      summary=f"Continue after {self.max_tool_rounds} tool rounds",
      details=[
        f"round_limit: {self.max_tool_rounds}",
        "reason: the agent is still using tools and needs another batch of tool rounds",
      ],
    )

  def _handle_tool_round_limit(self, final_text_parts):
    request = self._tool_round_limit_request()
    self._emit_activity("tool_round_limit", summary=request.summary)
    if self.approval_callback is None:
      return False

    is_approved = bool(self.approval_callback(request, self))
    if is_approved:
      return True

    partial_text = "\n\n".join(part for part in final_text_parts if part).strip()
    if partial_text:
      return partial_text + "\n\n[Agent stopped] Additional tool rounds were declined."
    return "[Agent stopped] Additional tool rounds were declined."

  def ask(self, user_input: str, reset: bool = False, attachments=None):
    if reset:
      self.clear()

    user_content = build_user_content(user_input, attachments=attachments)
    history_content = sanitize_content_for_history(user_content)
    request_messages = list(self.messages)
    request_messages.append({
      "role": "user",
      "content": user_content
    })
    self.messages.append({
      "role": "user",
      "content": history_content,
    })

    final_text_parts = []
    tool_rounds_used = 0
    parse_failures = 0

    while True:
      if tool_rounds_used >= self.max_tool_rounds:
        continuation = self._handle_tool_round_limit(final_text_parts)
        if continuation is not True:
          return continuation if isinstance(continuation, str) else "[Agent error] Exceeded maximum tool rounds"
        tool_rounds_used = 0

      self._emit_activity("llm_start", round=tool_rounds_used + 1)
      try:
        setattr(self.llm, "last_metrics", None)
      except Exception:
        pass
      previous_stream_callback = getattr(self.llm, "stream_callback", None)
      had_stream_callback = hasattr(self.llm, "stream_callback")

      def stream_callback(kind: str, data: dict):
        self._emit_activity(kind, **dict(data or {}))

      try:
        setattr(self.llm, "stream_callback", stream_callback)
      except Exception:
        pass
      request_started = time.perf_counter()
      try:
        response = self.llm.chat(
          request_messages,
          tools=self.tool_schemas,
          system_prompt=self._build_system_prompt(),
        )
      finally:
        request_seconds = time.perf_counter() - request_started
        try:
          if had_stream_callback:
            setattr(self.llm, "stream_callback", previous_stream_callback)
          else:
            delattr(self.llm, "stream_callback")
        except Exception:
          pass
      llm_metrics = getattr(self.llm, "last_metrics", None)
      llm_metrics = dict(llm_metrics) if isinstance(llm_metrics, dict) else {}
      llm_metrics.setdefault("request_seconds", request_seconds)
      self._emit_activity("llm_end", round=tool_rounds_used + 1, metrics=llm_metrics)

      assistant_content = response
      if not isinstance(assistant_content, str):
        assistant_content = json.dumps(assistant_content, ensure_ascii=False)

      self.messages.append({
        "role": "assistant",
        "content": assistant_content
      })
      request_messages = list(self.messages)

      try:
        blocks = parse_agent_blocks(response)
      except Exception as e:
        self._emit_activity("parse_error", error=str(e))
        if parse_failures < 1:
          parse_failures += 1
          self.messages.append({
            "role": "user",
            "content": (
              "Your previous response could not be parsed as agent output. "
              "If you need a tool, return only valid JSON as an array of blocks with properly escaped string values. "
              "If no tool is needed, return a text block with the answer."
            )
          })
          request_messages = list(self.messages)
          continue
        exception(e)
        return f"[Agent error] {e}"

      tool_used = False
      invalid_tool_call = False
      round_text_parts = []
      first_tool_block = None

      for block in blocks:
        if block.type == "text" and block.content:
          round_text_parts.append(block.content)
        elif block.type == "tool_use":
          tool_name = self._resolve_tool_name(block.content.name)
          if tool_name not in self.tools:
            invalid_tool_call = True
            continue
          first_tool_block = block
          break

      if first_tool_block is not None:
        tool_used = True
        self.messages[-1]["content"] = canonical_agent_block_json(first_tool_block)
        result = self.call_tool(first_tool_block.content.name, first_tool_block.content.input)
        serialized_result = self._serialize_tool_result(result)
        debug("TOOL RESULT", serialized_result)
        self.messages.append({
          "role": "user",
          "content": (
            f"Tool result for {first_tool_block.content.name}:\n{serialized_result}\n\n"
            "Next, either return one final text block, or if another tool is required, return exactly one tool_use block and stop."
          )
        })
        request_messages = list(self.messages)

      if not tool_used:
        final_text_parts.extend(round_text_parts)
      if invalid_tool_call and not tool_used and not final_text_parts:
        return assistant_content.strip()

      if not tool_used:
        return "\n\n".join(part for part in final_text_parts if part).strip()
      tool_rounds_used += 1

  def loop(self, user_input: str, is_clear=False):
    return self.ask(user_input, reset=is_clear)
