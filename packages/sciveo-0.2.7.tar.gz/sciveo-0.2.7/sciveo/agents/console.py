#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import os
import re
import sys
import time
from pathlib import Path

try:
  from prompt_toolkit import PromptSession
  from prompt_toolkit.history import FileHistory
  from prompt_toolkit.styles import Style
  _PROMPT_TOOLKIT_IMPORT_ERROR = None
except ImportError as exc:
  PromptSession = None
  FileHistory = None
  Style = None
  _PROMPT_TOOLKIT_IMPORT_ERROR = exc

from sciveo.agents.base import AgentBase, DEFAULT_AGENT_PROMPT, ToolApprovalRequest, ToolHelp
from sciveo.agents.media import build_user_content, normalize_image_input, normalize_image_inputs
from sciveo.agents.render import ConsoleRenderer, _AgentStreamTextFilter, _ansi, _is_interactive_stream, has_renderable_sections
from sciveo.agents.tools.images import ToolDescribeImages, ToolRenderImages
from sciveo.agents.tools.os import ToolBash, ToolPathList, ToolPwd, ToolReadFile, ToolWriteFile
from sciveo.agents.tools.web import ToolHttpRead, ToolWebSearch


DEFAULT_CONSOLE_PROMPT = """
You are a local general-purpose agent running inside a repository and on a local machine.
Current working directory: {cwd}

Adjust your focus to the user's current request and the conversation history.
You can handle both general conversation and practical local tasks when the available tools support them.
Prefer bash for search, listing, tests, lightweight automation, and local system inspection.
Use read_file for targeted file reads and write_file for direct file updates.
Use describe_images when the user asks about image files or directories on disk.
Use render_images when the user asks to list, show, preview, or render image files on disk.
Keep answers short, practical, and grounded in tool results.
""".strip()

DEFAULT_HF_RUNTIME_URL = "http://127.0.0.1:8910"
DEFAULT_OLLAMA_URL = "http://127.0.0.1:11434"
DEFAULT_OLLAMA_MODEL = "qwen2.5-coder:7b"
_AGENT_DEFAULT_PORT_SENTINEL = 22


_PROMPT_STYLE = Style.from_dict({
  "prompt": "bold ansigreen",
}) if Style is not None else None


def _first_env(*names):
  for name in names:
    value = os.getenv(name)
    if value:
      return value
  return None


def _history_path() -> str:
  base_path = Path(os.path.expanduser("~")) / ".sciveo"
  base_path.mkdir(parents=True, exist_ok=True)
  return str(base_path / "agent_history")


class ApprovalSession:
  def __init__(self, mode: str = "auto", input_func=input, output_func=print, is_tty=None):
    self.mode = str(mode or "auto").strip().lower()
    self.input_func = input_func
    self.output_func = output_func
    self.is_tty = is_tty
    self.allowed_scopes = set()
    self.allow_all = False

  def _is_interactive(self) -> bool:
    if self.is_tty is not None:
      return bool(self.is_tty)
    try:
      return sys.stdin.isatty()
    except Exception:
      return False

  def _allows_scope(self, scope: str) -> bool:
    if self.allow_all:
      return True

    if self.mode == "all":
      return True
    if self.mode == "writes":
      return scope in ("local_write", "external_write")
    if self.mode == "none":
      return False

    return scope in self.allowed_scopes

  def _print_request(self, request: ToolApprovalRequest):
    label = "approval required"
    self.output_func(label)
    self.output_func(f"  tool    {request.tool_name}")
    self.output_func(f"  risk    {request.scope}")
    self.output_func(f"  summary {request.summary}")
    for detail in request.details:
      self.output_func(f"  {detail}")

  def __call__(self, request: ToolApprovalRequest, agent) -> bool:
    if self._allows_scope(request.scope):
      return True

    if self.mode == "none":
      return False

    if self.mode == "auto" and not self._is_interactive():
      return False

    if self.mode not in ("auto", "ask"):
      return False

    while True:
      self._print_request(request)
      answer = str(self.input_func("Allow? [y]es / [n]o / [a]lways scope / [all] session: ") or "").strip()
      answer = answer.lower()

      if answer == "y":
        return True
      if answer == "n":
        return False
      if answer == "a":
        self.allowed_scopes.add(request.scope)
        return True
      if answer == "all":
        self.allow_all = True
        return True

      self.output_func("Please answer y, n, a, or all.")


class GenericToolAgent(AgentBase):
  def __init__(self, llm, system_prompt: str = None, approval_callback=None, approval_root: str = None):
    prompt = system_prompt or DEFAULT_CONSOLE_PROMPT.format(cwd=os.getcwd())
    full_prompt = f"{DEFAULT_AGENT_PROMPT}\n\n{prompt}".strip()
    super().__init__(
      llm=llm,
      system_prompt=full_prompt,
      approval_callback=approval_callback,
      approval_root=approval_root,
    )

    self.register_tool(ToolPwd())
    self.register_tool(ToolPathList())
    self.register_tool(ToolReadFile())
    self.register_tool(ToolWriteFile())
    self.register_tool(ToolDescribeImages())
    self.register_tool(ToolRenderImages())
    self.register_tool(ToolBash())
    self.register_tool(ToolHttpRead())
    self.register_tool(ToolWebSearch())
    self.register_tool(ToolHelp())


def _normalize_provider(provider: str) -> str:
  provider = str(provider or "auto").strip().lower()
  if provider == "local":
    return "hf"
  if provider == "olama":
    return "ollama"
  return provider


def _is_stream_mode(mode: str = None) -> bool:
  value = str(mode or "stream").strip().lower()
  batch_modes = {"batch", "current", "complete", "sync", "blocking", "plain", "direct", "raw", "llm"}
  return value not in batch_modes


def _is_direct_mode(mode: str = None) -> bool:
  return str(mode or "").strip().lower() in ("direct", "raw", "llm")


def _coerce_bool(value, default: bool = True) -> bool:
  if value is None:
    return bool(default)
  if isinstance(value, bool):
    return value
  if isinstance(value, (int, float)):
    return bool(value)

  text = str(value).strip().lower()
  if text in ("1", "true", "yes", "y", "on"):
    return True
  if text in ("0", "false", "no", "n", "off"):
    return False
  return bool(default)


def _normalize_stream_compare_text(text: str) -> str:
  value = str(text or "").strip()
  if not value:
    return ""
  value = value.replace("\r\n", "\n").replace("\r", "\n")
  lines = []
  previous_blank = False
  for line in value.splitlines():
    stripped = re.sub(r"\s+", " ", line.strip())
    if not stripped:
      previous_blank = True
      continue
    if stripped.startswith("- ") and lines and previous_blank:
      lines.append(stripped)
    else:
      lines.append(stripped)
    previous_blank = False
  return "\n".join(lines).strip()


def _agent_port_value(port):
  if port in (None, _AGENT_DEFAULT_PORT_SENTINEL):
    return None
  return int(port)


def _custom_endpoint_requested(url: str = None, host: str = None, port=None) -> bool:
  return bool(url or host or _agent_port_value(port) is not None)


def _build_http_base_url(default_url: str = None, url: str = None, host: str = None, port=None) -> str:
  if url:
    return str(url).rstrip("/")

  port = _agent_port_value(port)
  if host:
    host = str(host).strip()
    if "://" in host and port is None:
      return host.rstrip("/")
    if "://" in host:
      from urllib.parse import urlparse
      parsed = urlparse(host)
      scheme = parsed.scheme or "http"
      host_value = parsed.hostname or parsed.netloc
    else:
      scheme = "http"
      host_value = host
    if port is None and default_url:
      try:
        from urllib.parse import urlparse
        parsed = urlparse(default_url)
        port = parsed.port
      except Exception:
        port = None
    if port is None:
      return f"{scheme}://{host_value}".rstrip("/")
    return f"{scheme}://{host_value}:{port}".rstrip("/")

  if port is not None:
    return f"http://127.0.0.1:{port}"

  return str(default_url or "").rstrip("/") or None


def _resolve_llm_base_url(provider: str, url: str = None, host: str = None, port=None) -> str:
  provider = _normalize_provider(provider)
  if provider == "hf":
    return _build_http_base_url(DEFAULT_HF_RUNTIME_URL, url=url, host=host, port=port)
  if provider == "ollama":
    return _build_http_base_url(DEFAULT_OLLAMA_URL, url=url, host=host, port=port)
  if provider == "openai":
    return _build_http_base_url(None, url=url, host=host, port=port) if _custom_endpoint_requested(url, host, port) else None

  if _custom_endpoint_requested(url, host, port):
    raise RuntimeError(f"Provider '{provider}' does not support --url, --host, or --port")
  return None


def create_llm_client(
  provider: str = "auto",
  model: str = None,
  url: str = None,
  host: str = None,
  port=None,
  auth_token: str = None,
  mode: str = None,
):
  provider = str(provider or "auto").strip().lower()

  if provider == "auto":
    if _first_env("OPENAI_API_KEY", "API_KEY_OPENAI"):
      provider = "openai"
    elif _first_env("ANTHROPIC_API_KEY", "API_KEY_ANTHROPIC"):
      provider = "anthropic"
    elif _first_env("GROQ_API_KEY", "API_KEY_GROQ"):
      provider = "groq"
    elif _first_env("GEMINI_API_KEY", "GOOGLE_API_KEY", "API_KEY_GEMINI"):
      provider = "gemini"
    else:
      raise RuntimeError(
        "No agent provider configured. Set OPENAI_API_KEY, ANTHROPIC_API_KEY, GROQ_API_KEY, or GEMINI_API_KEY/GOOGLE_API_KEY."
      )

  provider = _normalize_provider(provider)
  base_url = _resolve_llm_base_url(provider, url=url, host=host, port=port)

  if provider == "openai":
    api_key = _first_env("OPENAI_API_KEY", "API_KEY_OPENAI")
    if not api_key:
      raise RuntimeError("OpenAI provider requires OPENAI_API_KEY or API_KEY_OPENAI")
    from sciveo.agents.clients.openai import OpenAIClient
    llm = OpenAIClient(
      api_key=api_key,
      model=model or "gpt-5.4",
      base_url=base_url or _first_env("OPENAI_BASE_URL", "API_BASE_URL_OPENAI"),
    )
  elif provider == "anthropic":
    api_key = _first_env("ANTHROPIC_API_KEY", "API_KEY_ANTHROPIC")
    if not api_key:
      raise RuntimeError("Anthropic provider requires ANTHROPIC_API_KEY or API_KEY_ANTHROPIC")
    from sciveo.agents.clients.anthropic import AnthropicClient
    llm = AnthropicClient(api_key=api_key, model=model or "claude-sonnet-4-20250514")
  elif provider == "groq":
    api_key = _first_env("GROQ_API_KEY", "API_KEY_GROQ")
    if not api_key:
      raise RuntimeError("Groq provider requires GROQ_API_KEY or API_KEY_GROQ")
    from sciveo.agents.clients.groq import GroqClient
    llm = GroqClient(api_key=api_key, model=model or "llama-3.3-70b-versatile")
  elif provider == "gemini":
    api_key = _first_env("GEMINI_API_KEY", "GOOGLE_API_KEY", "API_KEY_GEMINI")
    if not api_key:
      raise RuntimeError("Gemini provider requires GEMINI_API_KEY, GOOGLE_API_KEY, or API_KEY_GEMINI")
    from sciveo.agents.clients.gemini import GeminiClient
    llm = GeminiClient(api_key=api_key, model=model or "gemini-2.5-flash")
  elif provider == "hf":
    from sciveo.agents.clients.hf import HuggingFaceRuntimeClient
    llm = HuggingFaceRuntimeClient(
      base_url=base_url or DEFAULT_HF_RUNTIME_URL,
      model=model,
      auth_token=auth_token,
      stream=_is_stream_mode(mode),
    )
  elif provider == "ollama":
    from sciveo.agents.clients.ollama import OllamaClient
    llm = OllamaClient(
      base_url=base_url or DEFAULT_OLLAMA_URL,
      model=model or DEFAULT_OLLAMA_MODEL,
    )
  else:
    raise RuntimeError(f"Unsupported agent provider '{provider}'")

  llm.provider = provider
  return llm


def create_default_agent(
  provider: str = "auto",
  model: str = None,
  system_prompt: str = None,
  approval_callback=None,
  approval_root: str = None,
  url: str = None,
  host: str = None,
  port=None,
  auth_token: str = None,
  mode: str = None,
):
  llm = create_llm_client(
    provider=provider,
    model=model,
    url=url,
    host=host,
    port=port,
    auth_token=auth_token,
    mode=mode,
  )
  return GenericToolAgent(
    llm=llm,
    system_prompt=system_prompt,
    approval_callback=approval_callback,
    approval_root=approval_root,
  )


class AgentConsole:
  def __init__(self, agent, input_func=None, output_func=print, history_path: str = None, use_prompt_session: bool = True, interactive: bool = True):
    self.agent = agent
    self.output_func = output_func
    self.interactive = bool(interactive)
    self.renderer = ConsoleRenderer(output_func=output_func, interactive=self.interactive)
    self._input_func = input_func
    self._history_path = history_path or _history_path()
    self._session = None
    self._streamed_text = ""
    self._stream_filter = _AgentStreamTextFilter()
    self._pending_images = []

    if self.interactive and input_func is None and use_prompt_session and PromptSession is not None and _is_interactive_stream():
      try:
        self._session = PromptSession(
          history=FileHistory(self._history_path),
          style=_PROMPT_STYLE,
        )
      except Exception:
        self._session = None

    setattr(self.agent, "activity_callback", self._handle_activity)

  def help_text(self):
    return "\n".join([
      "Commands:",
      "  /help   Show console help",
      "  /tools  List agent tools",
      "  /image <path>  Attach an image file to the next prompt",
      "  /clear  Clear the conversation history",
      "  /exit   Exit the console",
      "",
      "Tips:",
      "  Ask the agent to describe images in a path to use the describe_images tool",
      "  Advanced image state commands: /images, /image-clear, /image-data",
      "  Up/Down browse prompt history",
      "  Use fenced code blocks in answers for syntax highlighting",
    ])

  def process_line(self, user_input: str):
    text = (user_input or "").strip()
    if not text:
      return True, None

    if text.lower() in ("exit", "quit", "/exit", "/quit"):
      return False, None

    if text.lower() == "/help":
      return True, self.help_text()

    if text.lower() == "/tools":
      return True, self.agent.call_tool("help", {})

    if text.lower().startswith("/image-data "):
      rest = text.split(" ", 1)[1].strip()
      if not rest:
        return True, "Usage: /image-data <mime_type> <base64-or-data-url>"
      if rest.startswith("data:"):
        image = normalize_image_input({"data": rest})
      else:
        parts = rest.split(None, 1)
        if len(parts) != 2:
          return True, "Usage: /image-data <mime_type> <base64-or-data-url>"
        image = normalize_image_input({"mime_type": parts[0], "data": parts[1]})
      self._pending_images.append(image)
      return True, self._attached_image_message(image)

    if text.lower() == "/images":
      if not self._pending_images:
        return True, "No pending image attachments."
      return True, "\n".join(
        f"{index + 1}. {image.get('name')} ({image.get('mime_type')})"
        for index, image in enumerate(self._pending_images)
      )

    if text.lower() == "/image-clear":
      count = len(self._pending_images)
      self._pending_images = []
      return True, f"Cleared {count} image attachment(s)."

    if text.lower().startswith("/image "):
      path = text.split(" ", 1)[1].strip()
      if not path:
        return True, "Usage: /image <path>"
      image = normalize_image_input({"path": path})
      self._pending_images.append(image)
      return True, self._attached_image_message(image)

    if text.lower() == "/clear":
      self.agent.clear()
      self._pending_images = []
      return True, "Conversation cleared."

    attachments = list(self._pending_images)
    self._pending_images = []
    if attachments:
      return True, self._ask_llm_direct(text, attachments=attachments)
    return True, self.agent.ask(text, reset=False)

  def _attached_image_message(self, image: dict):
    message = f"Attached image: {image.get('name')} ({image.get('mime_type')})"
    preview = self.renderer.image_preview_text(image)
    if preview:
      return f"{message}\n\n{preview}"
    return message

  def _ask_llm_direct(self, text: str, attachments=None):
    llm = getattr(self.agent, "llm", None)
    if llm is None:
      return self.agent.ask(text, reset=False, attachments=attachments)

    previous_stream_callback = getattr(llm, "stream_callback", None)
    had_stream_callback = hasattr(llm, "stream_callback")

    def stream_callback(kind: str, data: dict):
      self._handle_activity(kind, dict(data or {}), self.agent)

    try:
      setattr(llm, "stream_callback", stream_callback)
    except Exception:
      pass

    self._handle_activity("llm_start", {"round": 1}, self.agent)
    request_started = time.perf_counter()
    try:
      output = llm.chat(
        messages=[{
          "role": "user",
          "content": build_user_content(text, attachments),
        }],
      )
    finally:
      request_seconds = time.perf_counter() - request_started
      try:
        if had_stream_callback:
          setattr(llm, "stream_callback", previous_stream_callback)
        else:
          delattr(llm, "stream_callback")
      except Exception:
        pass

    metrics = getattr(llm, "last_metrics", None)
    metrics = dict(metrics) if isinstance(metrics, dict) else {}
    metrics.setdefault("request_seconds", request_seconds)
    self._handle_activity("llm_end", {"round": 1, "metrics": metrics}, self.agent)
    return str(output or "").strip()

  def _read_input(self) -> str:
    if self._input_func is not None:
      return self._input_func(_ansi("› ", "prompt", self.renderer.color))
    if self._session is not None:
      return self._session.prompt([("class:prompt", "› ")])
    return input(_ansi("› ", "prompt", self.renderer.color))

  def _handle_activity(self, kind: str, data: dict, agent):
    if kind == "llm_token":
      event_data = dict(data or {})
      visible_text = self._stream_filter.feed(event_data.get("text", ""))
      if not visible_text:
        return
      event_data["text"] = visible_text
      self._streamed_text += visible_text
      self.renderer.render_activity(kind, **event_data)
      return
    self.renderer.render_activity(kind, **dict(data or {}))

  def _should_render_output(self, role: str, output) -> bool:
    if not output:
      return False
    if role != "assistant":
      return True
    streamed = str(self._streamed_text or "").strip()
    if not streamed:
      return True
    if has_renderable_sections(output):
      return True
    return _normalize_stream_compare_text(streamed) != _normalize_stream_compare_text(output)

  def run(self):
    provider = getattr(self.agent.llm, "provider", "unknown")
    model = getattr(self.agent.llm, "model", "unknown")
    self.renderer.header(provider, model)

    while True:
      try:
        user_input = self._read_input()
      except EOFError:
        self.output_func("")
        break
      except KeyboardInterrupt:
        self.output_func("")
        break

      try:
        self._streamed_text = ""
        self._stream_filter = _AgentStreamTextFilter()
        is_continue, output = self.process_line(user_input)
      except KeyboardInterrupt:
        self.output_func("")
        break

      if output:
        role = "system" if str(user_input or "").strip().startswith("/") else "assistant"
        if self._should_render_output(role, output):
          if role == "assistant" and has_renderable_sections(output):
            self.renderer.replace_stream_with_message(role, output)
          else:
            self.renderer.render_message(role, output)

      if not is_continue:
        break


def run_agent_cli(
  provider: str = "auto",
  model: str = None,
  prompt: str = None,
  system_prompt: str = None,
  approve: str = "auto",
  approval_root: str = None,
  url: str = None,
  host: str = None,
  port=None,
  auth_token: str = None,
  mode: str = None,
  interactive: bool = True,
  input_path: str = None,
  data_json=None,
):
  interactive = _coerce_bool(interactive, default=True)
  attachments = normalize_image_inputs(input_path=input_path, data_json=data_json, base_dir=os.getcwd())

  if prompt and not interactive and (attachments or _is_direct_mode(mode)):
    llm = create_llm_client(
      provider=provider,
      model=model,
      url=url,
      host=host,
      port=port,
      auth_token=auth_token,
      mode=mode,
    )
    content = build_user_content(prompt, attachments) if attachments else prompt
    output = llm.chat(
      messages=[{"role": "user", "content": content}],
      system_prompt=system_prompt,
    )
    if output:
      print(output)
    return output

  approval = ApprovalSession(mode=approve, is_tty=interactive and _is_interactive_stream())
  agent = create_default_agent(
    provider=provider,
    model=model,
    system_prompt=system_prompt,
    approval_callback=approval,
    approval_root=approval_root,
    url=url,
    host=host,
    port=port,
    auth_token=auth_token,
    mode=mode,
  )

  if prompt:
    if not interactive:
      output = agent.ask(prompt, reset=False, attachments=attachments) if attachments else agent.ask(prompt, reset=False)
      if output:
        print(output)
      return output

    renderer = ConsoleRenderer()

    if _is_stream_mode(mode):
      streamed_text = []
      stream_filter = _AgentStreamTextFilter()

      def handle_activity(kind: str, data: dict, agent_ref):
        if kind == "llm_token":
          event_data = dict(data or {})
          visible_text = stream_filter.feed(event_data.get("text", ""))
          if not visible_text:
            return
          event_data["text"] = visible_text
          streamed_text.append(visible_text)
          renderer.render_activity(kind, **event_data)
          return
        renderer.render_activity(kind, **dict(data or {}))

      setattr(agent, "activity_callback", handle_activity)
      output = agent.ask(prompt, reset=False, attachments=attachments) if attachments else agent.ask(prompt, reset=False)
      streamed_output = "".join(streamed_text)
      if output and (
        has_renderable_sections(output)
        or _normalize_stream_compare_text(streamed_output) != _normalize_stream_compare_text(output)
      ):
        if has_renderable_sections(output):
          renderer.replace_stream_with_message("assistant", output)
        else:
          renderer.render_message("assistant", output)
      return output

    setattr(agent, "activity_callback", lambda kind, data, agent_ref: renderer.render_activity(kind, **dict(data or {})))
    output = agent.ask(prompt, reset=False, attachments=attachments) if attachments else agent.ask(prompt, reset=False)
    renderer.render_message("assistant", output)
    return output

  if not interactive:
    raise RuntimeError("Non-interactive mode requires --prompt")

  AgentConsole(agent, interactive=interactive).run()
  return None


BaseConsole = AgentConsole
TestAgent = GenericToolAgent


if __name__ == "__main__":
  run_agent_cli()
