#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import base64
import binascii
import os
import re


ALLOWED_IMAGE_MIME_TYPES = {
  "image/png",
  "image/jpeg",
  "image/webp",
}
DEFAULT_IMAGE_MAX_BYTES = 20 * 1024 * 1024
_DATA_URL_RE = re.compile(r"^data:(image/[a-zA-Z0-9.+-]+);base64,(.*)$", re.DOTALL)


def image_max_bytes() -> int:
  value = os.environ.get("SCIVEO_AGENT_IMAGE_MAX_BYTES")
  if value in (None, ""):
    return DEFAULT_IMAGE_MAX_BYTES
  try:
    return int(value)
  except Exception:
    return DEFAULT_IMAGE_MAX_BYTES


def _guess_mime_from_bytes(data: bytes, fallback: str = None) -> str:
  if data.startswith(b"\x89PNG\r\n\x1a\n"):
    return "image/png"
  if data.startswith(b"\xff\xd8\xff"):
    return "image/jpeg"
  if data.startswith(b"RIFF") and data[8:12] == b"WEBP":
    return "image/webp"
  return fallback or "application/octet-stream"


def _guess_mime_from_path(path: str, data: bytes) -> str:
  lower = str(path or "").lower()
  fallback = None
  if lower.endswith(".png"):
    fallback = "image/png"
  elif lower.endswith((".jpg", ".jpeg")):
    fallback = "image/jpeg"
  elif lower.endswith(".webp"):
    fallback = "image/webp"
  return _guess_mime_from_bytes(data, fallback=fallback)


def _validate_image_bytes(data: bytes, mime_type: str):
  if not data:
    raise RuntimeError("Image input is empty")
  if len(data) > image_max_bytes():
    raise RuntimeError(f"Image input is too large: {len(data)} bytes")
  if mime_type not in ALLOWED_IMAGE_MIME_TYPES:
    raise RuntimeError(f"Unsupported image type '{mime_type}'. Supported: png, jpeg, webp")


def _decode_base64_image(value: str, mime_type: str = None):
  text = str(value or "").strip()
  match = _DATA_URL_RE.match(text)
  if match:
    mime_type = match.group(1).lower()
    text = match.group(2).strip()

  try:
    data = base64.b64decode(text, validate=True)
  except binascii.Error as e:
    raise RuntimeError(f"Invalid base64 image data: {e}")

  mime_type = (mime_type or _guess_mime_from_bytes(data)).lower()
  _validate_image_bytes(data, mime_type)
  return data, mime_type


def _encode_file_image(path: str):
  path = os.path.abspath(os.path.expanduser(str(path or "")))
  if not os.path.isfile(path):
    raise RuntimeError(f"Image file not found: {path}")
  with open(path, "rb") as fp:
    data = fp.read()
  mime_type = _guess_mime_from_path(path, data)
  _validate_image_bytes(data, mime_type)
  return data, mime_type, path


def normalize_image_input(value, base_dir: str = None) -> dict:
  if isinstance(value, dict):
    if value.get("path"):
      path = str(value.get("path"))
      if base_dir and not os.path.isabs(path):
        path = os.path.join(base_dir, path)
      data, mime_type, path = _encode_file_image(path)
      name = value.get("name") or os.path.basename(path)
    else:
      raw_data = value.get("data") or value.get("base64") or value.get("image")
      data, mime_type = _decode_base64_image(raw_data, value.get("mime_type") or value.get("mime"))
      name = value.get("name") or "image"
  else:
    text = str(value or "").strip()
    path = text
    if base_dir and path and not os.path.isabs(path) and os.path.exists(os.path.join(base_dir, path)):
      path = os.path.join(base_dir, path)
    if path and os.path.isfile(os.path.expanduser(path)):
      data, mime_type, path = _encode_file_image(path)
      name = os.path.basename(path)
    else:
      data, mime_type = _decode_base64_image(text)
      name = "image"

  return {
    "type": "image",
    "mime_type": mime_type,
    "data": base64.b64encode(data).decode("ascii"),
    "name": str(name or "image"),
  }


def normalize_image_inputs(input_path: str = None, data_json=None, base_dir: str = None) -> list[dict]:
  images = []
  if input_path:
    images.append(normalize_image_input({"path": input_path}, base_dir=base_dir))

  data = dict(data_json or {})
  if data.get("image"):
    images.append(normalize_image_input(data.get("image"), base_dir=base_dir))

  for item in data.get("images") or []:
    images.append(normalize_image_input(item, base_dir=base_dir))
  return images


def content_parts(content) -> list[dict]:
  if isinstance(content, list):
    parts = []
    for part in content:
      if isinstance(part, dict):
        part_type = part.get("type")
        if part_type == "text":
          parts.append({"type": "text", "text": str(part.get("text", ""))})
        elif part_type == "image":
          item = dict(part)
          item["type"] = "image"
          item["mime_type"] = str(item.get("mime_type") or item.get("mime") or "").lower()
          item["data"] = str(item.get("data") or "")
          item["name"] = str(item.get("name") or "image")
          parts.append(item)
        else:
          parts.append({"type": "text", "text": str(part)})
      else:
        parts.append({"type": "text", "text": str(part)})
    return parts
  return [{"type": "text", "text": str(content or "")}]


def build_user_content(text: str, attachments=None):
  images = list(attachments or [])
  if not images:
    return str(text or "")
  parts = [{"type": "text", "text": str(text or "")}]
  for image in images:
    parts.append(dict(image))
  return parts


def content_has_images(content) -> bool:
  return any(part.get("type") == "image" for part in content_parts(content))


def messages_have_images(messages: list[dict]) -> bool:
  return any(content_has_images((message or {}).get("content")) for message in messages or [])


def content_text(content, image_placeholder: bool = True) -> str:
  parts = content_parts(content)
  text_parts = []
  for part in parts:
    if part.get("type") == "text":
      value = str(part.get("text") or "")
      if value:
        text_parts.append(value)
    elif part.get("type") == "image" and image_placeholder:
      name = part.get("name") or "image"
      mime_type = part.get("mime_type") or "image"
      text_parts.append(f"[Image: {name} ({mime_type})]")
  return "\n".join(text_parts).strip()


def sanitize_content_for_history(content):
  if not content_has_images(content):
    return content_text(content, image_placeholder=False)
  return content_text(content, image_placeholder=True)


def image_data_url(part: dict) -> str:
  mime_type = part.get("mime_type") or "image/png"
  return f"data:{mime_type};base64,{part.get('data', '')}"


def image_bytes(part: dict) -> bytes:
  try:
    return base64.b64decode(str(part.get("data") or ""), validate=True)
  except binascii.Error as e:
    raise RuntimeError(f"Invalid base64 image data: {e}")


def image_parts(messages: list[dict]) -> list[dict]:
  result = []
  for message in messages or []:
    for part in content_parts((message or {}).get("content")):
      if part.get("type") == "image":
        result.append(part)
  return result


def pil_images_from_messages(messages: list[dict]) -> list:
  try:
    from PIL import Image
    import io
  except ImportError:
    raise ImportError("Image input for local HF runtime requires Pillow. Install with sciveo[agent-local].")

  images = []
  for part in image_parts(messages):
    image = Image.open(io.BytesIO(image_bytes(part)))
    images.append(image.convert("RGB"))
  return images
