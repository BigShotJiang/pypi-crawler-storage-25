#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import os

from sciveo.agents.base import ToolBase
from sciveo.agents.media import build_user_content, normalize_image_input


IMAGE_EXTENSIONS = {
  ".jpeg",
  ".jpg",
  ".png",
  ".webp",
}


def _input_value(tool_input, key, default=None):
  if not isinstance(tool_input, dict):
    return default
  return tool_input.get(key, default)


def _bool_value(value, default=False):
  if value is None:
    return default
  if isinstance(value, bool):
    return value
  return str(value).strip().lower() in ("1", "true", "yes", "y", "on")


def _int_value(value, default):
  try:
    return int(value)
  except Exception:
    return default


def _is_image_path(path: str) -> bool:
  return os.path.splitext(str(path or ""))[1].lower() in IMAGE_EXTENSIONS


def _find_image_paths(path: str, recursive=False, limit=8):
  if os.path.isfile(path):
    return ([path], False) if _is_image_path(path) else ([], False)

  if not os.path.isdir(path):
    return [], False

  results = []
  truncated = False
  if recursive:
    walker = os.walk(path)
    for root, dirs, files in walker:
      dirs[:] = sorted(dirs)
      for name in sorted(files):
        candidate = os.path.join(root, name)
        if _is_image_path(candidate):
          if len(results) >= limit:
            truncated = True
            return results, truncated
          results.append(candidate)
    return results, truncated

  for name in sorted(os.listdir(path)):
    candidate = os.path.join(path, name)
    if os.path.isfile(candidate) and _is_image_path(candidate):
      if len(results) >= limit:
        truncated = True
        break
      results.append(candidate)
  return results, truncated


def _response_text(response):
  if isinstance(response, str):
    return response.strip()
  if isinstance(response, list):
    parts = []
    for item in response:
      if isinstance(item, dict) and item.get("type") == "text":
        parts.append(str(item.get("text") or ""))
      else:
        parts.append(str(item))
    return "\n".join(part for part in parts if part).strip()
  return str(response or "").strip()


class ToolDescribeImages(ToolBase):
  schema = {
    "name": "describe_images",
    "description": "Describe image files from a file or directory path using the selected vision-language model",
    "input_schema": {
      "type": "object",
      "properties": {
        "path": {"type": "string", "description": "Image file or directory path"},
        "prompt": {
          "type": "string",
          "description": "Prompt to ask for each image",
        },
        "recursive": {
          "type": "boolean",
          "description": "Whether to scan directories recursively",
        },
        "limit": {
          "type": "integer",
          "description": "Maximum number of images to describe",
        },
      },
      "required": ["path"],
    },
  }

  def run(self, tool_input, agent):
    path = _input_value(tool_input, "path")
    if not path:
      return {"error": "describe_images requires path"}

    path = os.path.abspath(os.path.expanduser(str(path)))
    if not os.path.exists(path):
      return {"error": f"Path not found: {path}"}

    prompt = _input_value(
      tool_input,
      "prompt",
      "Describe this image in one concise sentence.",
    )
    recursive = _bool_value(_input_value(tool_input, "recursive"), default=False)
    limit = max(1, min(_int_value(_input_value(tool_input, "limit"), 8), 32))
    image_paths, truncated = _find_image_paths(path, recursive=recursive, limit=limit)
    if not image_paths:
      return {
        "path": path,
        "count": 0,
        "descriptions": [],
        "message": "No supported image files found. Supported extensions: jpeg, jpg, png, webp.",
      }

    descriptions = []
    for image_path in image_paths:
      try:
        image = normalize_image_input({"path": image_path})
        response = agent.llm.chat(
          messages=[{
            "role": "user",
            "content": build_user_content(str(prompt), attachments=[image]),
          }],
          system_prompt="Answer directly. Do not call tools.",
        )
        item = {
          "path": image_path,
          "name": os.path.basename(image_path),
          "description": _response_text(response),
        }
        metrics = getattr(agent.llm, "last_metrics", None)
        if isinstance(metrics, dict):
          item["metrics"] = dict(metrics)
        descriptions.append(item)
      except Exception as e:
        descriptions.append({
          "path": image_path,
          "name": os.path.basename(image_path),
          "error": str(e),
        })

    return {
      "path": path,
      "recursive": recursive,
      "limit": limit,
      "count": len(descriptions),
      "truncated": truncated,
      "descriptions": descriptions,
    }


class ToolRenderImages(ToolBase):
  schema = {
    "name": "render_images",
    "description": "List and render image files from a file or directory path in the terminal",
    "input_schema": {
      "type": "object",
      "properties": {
        "path": {"type": "string", "description": "Image file or directory path"},
        "recursive": {
          "type": "boolean",
          "description": "Whether to scan directories recursively",
        },
        "limit": {
          "type": "integer",
          "description": "Maximum number of images to render",
        },
      },
      "required": ["path"],
    },
  }

  def run(self, tool_input, agent):
    path = _input_value(tool_input, "path")
    if not path:
      return {"error": "render_images requires path"}

    path = os.path.abspath(os.path.expanduser(str(path)))
    if not os.path.exists(path):
      return {"error": f"Path not found: {path}"}

    recursive = _bool_value(_input_value(tool_input, "recursive"), default=False)
    limit = max(1, min(_int_value(_input_value(tool_input, "limit"), 16), 64))
    image_paths, truncated = _find_image_paths(path, recursive=recursive, limit=limit)
    if not image_paths:
      return {
        "path": path,
        "count": 0,
        "images": [],
        "message": "No supported image files found. Supported extensions: jpeg, jpg, png, webp.",
      }

    images = []
    for image_path in image_paths:
      try:
        image = normalize_image_input({"path": image_path})
        agent._emit_activity("image_preview", image=image, path=image_path)
        images.append({
          "path": image_path,
          "name": os.path.basename(image_path),
          "mime_type": image.get("mime_type"),
        })
      except Exception as e:
        images.append({
          "path": image_path,
          "name": os.path.basename(image_path),
          "error": str(e),
        })

    return {
      "path": path,
      "recursive": recursive,
      "limit": limit,
      "count": len(images),
      "truncated": truncated,
      "images": images,
    }
