#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import os
import subprocess

from sciveo.agents.base import ToolApprovalRequest, ToolBase


def _input_value(tool_input, key, default=None):
  if not isinstance(tool_input, dict):
    return default
  return tool_input.get(key, default)


def _absolute_path(path: str) -> str:
  return os.path.abspath(os.path.expanduser(str(path)))


def _is_within_root(path: str, root: str) -> bool:
  try:
    return os.path.commonpath([path, root]) == root
  except Exception:
    return False


class ToolReadFile(ToolBase):
  schema = {
    "name": "read_file",
    "description": "Read the contents of a file",
    "input_schema": {
      "type": "object",
      "properties": {
        "path": {"type": "string", "description": "File path to read"},
      },
      "required": ["path"],
    }
  }

  def run(self, tool_input, agent):
    path = _input_value(tool_input, "path")
    if not path:
      return {"error": "read_file requires path"}
    if not os.path.exists(path):
      return {"error": f"File not found: {path}"}

    try:
      with open(path, "r", encoding="utf-8") as fp:
        return {
          "path": path,
          "content": fp.read(),
        }
    except Exception as e:
      return {"error": f"Error reading file: {e}"}


class ToolWriteFile(ToolBase):
  schema = {
    "name": "write_file",
    "description": "Write content to a file",
    "input_schema": {
      "type": "object",
      "properties": {
        "path": {"type": "string", "description": "File path to write"},
        "content": {"type": "string", "description": "Content to write"},
      },
      "required": ["path", "content"],
    }
  }

  def approval_request(self, tool_input, agent):
    path = _input_value(tool_input, "path")
    if not path:
      return None

    abs_path = _absolute_path(path)
    scope = "local_write" if _is_within_root(abs_path, agent.approval_root) else "external_write"
    content = _input_value(tool_input, "content", "")
    exists = os.path.exists(abs_path)

    return ToolApprovalRequest(
      tool_name=self.schema["name"],
      scope=scope,
      summary="Write file",
      details=[
        f"path: {abs_path}",
        f"action: {'overwrite' if exists else 'create'}",
        f"bytes: {len(str(content).encode('utf-8'))}",
      ],
    )

  def run(self, tool_input, agent):
    path = _input_value(tool_input, "path")
    content = _input_value(tool_input, "content", "")
    if not path:
      return {"error": "write_file requires path"}

    try:
      base_dir = os.path.dirname(path)
      if base_dir:
        os.makedirs(base_dir, exist_ok=True)

      with open(path, "w", encoding="utf-8") as fp:
        fp.write(content)

      return {
        "status": "ok",
        "path": path,
        "bytes": len(content.encode("utf-8")),
      }
    except Exception as e:
      return {"error": f"Error writing file: {e}"}


class ToolPathList(ToolBase):
  schema = {
    "name": "list_dir",
    "description": "List the contents of a directory",
    "input_schema": {
      "type": "object",
      "properties": {
        "path": {"type": "string", "description": "Directory path"},
        "limit": {"type": "integer", "description": "Maximum number of entries to return"},
        "offset": {"type": "integer", "description": "Number of sorted entries to skip"},
      },
      "required": [],
    },
  }

  def run(self, tool_input, agent):
    path = _input_value(tool_input, "path", ".")
    try:
      limit = int(_input_value(tool_input, "limit", 200) or 200)
    except Exception:
      limit = 200
    try:
      offset = int(_input_value(tool_input, "offset", 0) or 0)
    except Exception:
      offset = 0
    limit = max(1, min(limit, 1000))
    offset = max(0, offset)
    try:
      entries = sorted(os.listdir(path))
      selected = entries[offset:offset + limit]
      return {
        "path": path,
        "offset": offset,
        "limit": limit,
        "total_count": len(entries),
        "count": len(selected),
        "truncated": offset + len(selected) < len(entries),
        "entries": selected,
      }
    except Exception as e:
      return {"error": f"Error listing directory: {e}"}


class ToolPwd(ToolBase):
  schema = {
    "name": "pwd",
    "description": "Show the current working directory",
    "input_schema": {
      "type": "object",
      "properties": {},
      "required": [],
    },
  }

  def run(self, tool_input, agent):
    return {"cwd": os.getcwd()}


class ToolBash(ToolBase):
  schema = {
    "name": "bash",
    "description": "Run a shell command. Prefer this for search, listing, tests, and repo inspection.",
    "input_schema": {
      "type": "object",
      "properties": {
        "command": {"type": "string", "description": "Command to run"},
        "cmd": {"type": "string", "description": "Alias for command"},
        "cwd": {"type": "string", "description": "Optional working directory"},
        "workdir": {"type": "string", "description": "Alias for cwd"},
        "timeout": {"type": "number", "description": "Optional timeout in seconds"},
      },
      "required": ["command"],
    },
  }

  def approval_request(self, tool_input, agent):
    command = _input_value(tool_input, "command") or _input_value(tool_input, "cmd")
    if not command:
      return None

    cwd = _input_value(tool_input, "cwd") or _input_value(tool_input, "workdir")
    timeout = _input_value(tool_input, "timeout", 30)

    return ToolApprovalRequest(
      tool_name=self.schema["name"],
      scope="shell",
      summary="Run shell command",
      details=[
        f"cwd: {_absolute_path(cwd) if cwd else os.getcwd()}",
        f"timeout: {timeout}",
        f"command: {command}",
      ],
    )

  def run(self, tool_input, agent):
    command = _input_value(tool_input, "command") or _input_value(tool_input, "cmd")
    cwd = _input_value(tool_input, "cwd") or _input_value(tool_input, "workdir")
    timeout = _input_value(tool_input, "timeout", 30)

    if not command:
      return {"error": "bash requires command"}

    try:
      result = subprocess.run(
        command,
        shell=True,
        capture_output=True,
        text=True,
        cwd=cwd or None,
        timeout=float(timeout),
      )
      return {
        "command": command,
        "cwd": cwd or os.getcwd(),
        "code": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
      }
    except subprocess.TimeoutExpired as e:
      return {
        "error": f"Command timed out after {timeout} seconds",
        "command": command,
        "cwd": cwd or os.getcwd(),
        "stdout": e.stdout or "",
        "stderr": e.stderr or "",
      }
    except Exception as e:
      return {"error": f"Bash error: {e}"}
