#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import html
import re

from html.parser import HTMLParser
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

from sciveo.agents.base import ToolApprovalRequest, ToolBase


DEFAULT_TIMEOUT = 20
DEFAULT_MAX_CHARS = 12000
DEFAULT_SEARCH_LIMIT = 5
DEFAULT_USER_AGENT = (
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
  "AppleWebKit/537.36 (KHTML, like Gecko) "
  "Chrome/124.0 Safari/537.36"
)
DEFAULT_BROWSER_HEADERS = {
  "User-Agent": DEFAULT_USER_AGENT,
  "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,application/json;q=0.8,*/*;q=0.7",
  "Accept-Language": "en-US,en;q=0.9",
  "Cache-Control": "no-cache",
  "Pragma": "no-cache",
}


def _input_value(tool_input, key, default=None):
  if not isinstance(tool_input, dict):
    return default
  return tool_input.get(key, default)


def _clean_whitespace(text: str) -> str:
  return re.sub(r"\s+", " ", str(text or "")).strip()


def _normalize_url(url: str) -> str:
  url = str(url or "").strip()
  if not url:
    return url
  if "://" not in url:
    return f"https://{url}"
  return url


def _truncate_text(text: str, max_chars: int) -> str:
  text = str(text or "")
  limit = max(int(max_chars or DEFAULT_MAX_CHARS), 1)
  if len(text) <= limit:
    return text
  return text[:limit].rstrip() + "..."


def _get_requests_module():
  try:
    import requests
    return requests
  except ImportError:
    return None


def _browser_headers(headers: dict = None) -> dict:
  result = dict(DEFAULT_BROWSER_HEADERS)
  for key, value in dict(headers or {}).items():
    header = str(key)
    existing = None
    for current in result.keys():
      if current.lower() == header.lower():
        existing = current
        break
    if existing is not None:
      del result[existing]
    result[header] = str(value)
  return result


def _is_textual_content_type(content_type: str) -> bool:
  value = str(content_type or "").lower()
  return (
    value.startswith("text/")
    or "json" in value
    or "xml" in value
    or "javascript" in value
    or value == ""
  )


def _extract_title(html_text: str) -> str:
  match = re.search(r"<title[^>]*>(.*?)</title>", str(html_text or ""), flags=re.IGNORECASE | re.DOTALL)
  if not match:
    return ""
  return _clean_whitespace(html.unescape(match.group(1)))


def _strip_duckduckgo_redirect(url: str) -> str:
  value = str(url or "")
  parsed = urlparse(value)
  if "duckduckgo.com" not in parsed.netloc:
    return value

  query = parse_qs(parsed.query)
  redirected = query.get("uddg")
  if redirected:
    return redirected[0]
  return value


class _HTMLTextExtractor(HTMLParser):
  def __init__(self):
    super().__init__(convert_charrefs=True)
    self.parts = []
    self._ignored_depth = 0

  def handle_starttag(self, tag, attrs):
    tag = str(tag or "").lower()
    if tag in ("script", "style", "noscript", "head", "title"):
      self._ignored_depth += 1
      return

    if self._ignored_depth:
      return

    if tag in ("br", "p", "div", "section", "article", "main", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6"):
      self.parts.append("\n")

  def handle_endtag(self, tag):
    tag = str(tag or "").lower()
    if tag in ("script", "style", "noscript", "head", "title") and self._ignored_depth:
      self._ignored_depth -= 1
      return

    if self._ignored_depth:
      return

    if tag in ("p", "div", "section", "article", "main", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6"):
      self.parts.append("\n")

  def handle_data(self, data):
    if self._ignored_depth:
      return
    if data:
      self.parts.append(data)

  def get_text(self) -> str:
    text = "".join(self.parts)
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _html_to_text(html_text: str) -> str:
  parser = _HTMLTextExtractor()
  parser.feed(str(html_text or ""))
  return parser.get_text()


class _DuckDuckGoResultParser(HTMLParser):
  def __init__(self):
    super().__init__(convert_charrefs=True)
    self.results = []
    self._current = None
    self._capture_title = False
    self._capture_snippet = False
    self._title_depth = 0
    self._snippet_depth = 0

  def _class_tokens(self, attrs) -> set:
    class_value = dict(attrs).get("class", "")
    return {token.strip() for token in str(class_value).split() if token.strip()}

  def _commit_current(self):
    if not self._current:
      return

    title = _clean_whitespace("".join(self._current.get("title_parts", [])))
    url = _strip_duckduckgo_redirect(self._current.get("url", ""))
    snippet = _clean_whitespace("".join(self._current.get("snippet_parts", [])))
    if title and url:
      self.results.append({
        "title": title,
        "url": url,
        "snippet": snippet,
      })
    self._current = None

  def handle_starttag(self, tag, attrs):
    classes = self._class_tokens(attrs)
    attrs_dict = dict(attrs)

    if "result__a" in classes:
      self._commit_current()
      self._current = {
        "url": attrs_dict.get("href", ""),
        "title_parts": [],
        "snippet_parts": [],
      }
      self._capture_title = True
      self._title_depth = 1
      return

    if self._capture_title:
      self._title_depth += 1

    if self._current and "result__snippet" in classes:
      self._capture_snippet = True
      self._snippet_depth = 1
      return

    if self._capture_snippet:
      self._snippet_depth += 1

  def handle_endtag(self, tag):
    if self._capture_title:
      self._title_depth -= 1
      if self._title_depth <= 0:
        self._capture_title = False
        self._title_depth = 0

    if self._capture_snippet:
      self._snippet_depth -= 1
      if self._snippet_depth <= 0:
        self._capture_snippet = False
        self._snippet_depth = 0

  def handle_data(self, data):
    if self._current is None or not data:
      return
    if self._capture_title:
      self._current["title_parts"].append(data)
    if self._capture_snippet:
      self._current["snippet_parts"].append(data)

  def close(self):
    super().close()
    self._commit_current()


def _parse_duckduckgo_results(html_text: str, limit: int = DEFAULT_SEARCH_LIMIT) -> list:
  parser = _DuckDuckGoResultParser()
  parser.feed(str(html_text or ""))
  parser.close()
  return parser.results[:max(int(limit or DEFAULT_SEARCH_LIMIT), 1)]


class ToolHttpRead(ToolBase):
  schema = {
    "name": "http_read",
    "description": "Fetch a URL and return readable text content",
    "input_schema": {
      "type": "object",
      "properties": {
        "url": {"type": "string", "description": "URL to fetch"},
        "headers": {"type": "object", "description": "Optional request headers"},
        "timeout": {"type": "number", "description": "Timeout in seconds"},
        "max_chars": {"type": "integer", "description": "Maximum number of characters to return"},
      },
      "required": ["url"],
    },
  }

  def approval_request(self, tool_input, agent):
    url = _normalize_url(_input_value(tool_input, "url"))
    if not url:
      return None

    return ToolApprovalRequest(
      tool_name=self.schema["name"],
      scope="network_read",
      summary="Read URL",
      details=[
        f"url: {url}",
        f"timeout: {_input_value(tool_input, 'timeout', DEFAULT_TIMEOUT)}",
      ],
    )

  def run(self, tool_input, agent):
    url = _normalize_url(_input_value(tool_input, "url"))
    headers = dict(_input_value(tool_input, "headers", {}) or {})
    timeout = float(_input_value(tool_input, "timeout", DEFAULT_TIMEOUT))
    max_chars = int(_input_value(tool_input, "max_chars", DEFAULT_MAX_CHARS))
    requests = _get_requests_module()

    if not url:
      return {"error": "http_read requires url"}
    if requests is None:
      return {"error": "http_read requires the 'requests' package"}

    headers = _browser_headers(headers)

    try:
      response = requests.get(url, headers=headers, timeout=timeout)
      response.raise_for_status()
      content_type = response.headers.get("Content-Type", "")

      if not _is_textual_content_type(content_type):
        return {
          "url": response.url,
          "status": response.status_code,
          "content_type": content_type,
          "text": "",
          "title": "",
          "truncated": False,
          "note": "Non-text response",
        }

      raw_text = response.text or ""
      title = ""
      text = raw_text
      if "<html" in raw_text.lower() or "html" in str(content_type).lower():
        title = _extract_title(raw_text)
        text = _html_to_text(raw_text)

      truncated = len(text) > max_chars
      return {
        "url": response.url,
        "status": response.status_code,
        "content_type": content_type,
        "title": title,
        "text": _truncate_text(text, max_chars),
        "truncated": truncated,
      }
    except requests.RequestException as e:
      return {"error": f"http_read failed: {e}", "url": url}


class ToolWebSearch(ToolBase):
  schema = {
    "name": "web_search",
    "description": "Search the web and return result links with snippets",
    "input_schema": {
      "type": "object",
      "properties": {
        "query": {"type": "string", "description": "Search query"},
        "site": {"type": "string", "description": "Optional site filter, for example docs.python.org"},
        "limit": {"type": "integer", "description": "Maximum number of results"},
        "timeout": {"type": "number", "description": "Timeout in seconds"},
      },
      "required": ["query"],
    },
  }

  def approval_request(self, tool_input, agent):
    query = _clean_whitespace(_input_value(tool_input, "query"))
    if not query:
      return None

    site = _clean_whitespace(_input_value(tool_input, "site", ""))
    summary = f"Search the web for '{query}'"
    if site:
      summary += f" on {site}"

    return ToolApprovalRequest(
      tool_name=self.schema["name"],
      scope="network_read",
      summary=summary,
      details=[
        f"limit: {_input_value(tool_input, 'limit', DEFAULT_SEARCH_LIMIT)}",
        f"timeout: {_input_value(tool_input, 'timeout', DEFAULT_TIMEOUT)}",
      ],
    )

  def run(self, tool_input, agent):
    query = _clean_whitespace(_input_value(tool_input, "query"))
    site = _clean_whitespace(_input_value(tool_input, "site", ""))
    limit = max(int(_input_value(tool_input, "limit", DEFAULT_SEARCH_LIMIT)), 1)
    timeout = float(_input_value(tool_input, "timeout", DEFAULT_TIMEOUT))
    requests = _get_requests_module()

    if not query:
      return {"error": "web_search requires query"}
    if requests is None:
      return {"error": "web_search requires the 'requests' package"}

    search_query = query if not site else f"site:{site} {query}"
    headers = _browser_headers()
    search_url = urlunparse(("https", "duckduckgo.com", "/html/", "", urlencode({"q": search_query}), ""))

    try:
      response = requests.get(search_url, headers=headers, timeout=timeout)
      response.raise_for_status()
      return {
        "query": query,
        "site": site or None,
        "results": _parse_duckduckgo_results(response.text, limit=limit),
      }
    except requests.RequestException as e:
      return {"error": f"web_search failed: {e}", "query": query, "site": site or None}
