#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import json
import gc
import os
import re
import subprocess
import threading
import time

from sciveo.agents.media import content_parts, content_text, image_data_url, image_parts, messages_have_images, pil_images_from_messages
from sciveo.tools.configuration import GlobalConfiguration
from sciveo.tools.logger import *


DEFAULT_HF_MODEL = "Qwen/Qwen2.5-Coder-3B-Instruct"
DEFAULT_HF_HOST = "127.0.0.1"
DEFAULT_HF_PORT = 8910
DEFAULT_HF_CACHE_PATH = os.path.expanduser("~/.cache/huggingface/hub")
_THINK_BLOCK_RE = re.compile(r"<think\b[^>]*>.*?</think>\s*", re.IGNORECASE | re.DOTALL)


class _ThinkBlockStreamFilter:
  def __init__(self):
    self.buffer = ""
    self.in_think = False

  def feed(self, text: str) -> str:
    self.buffer += str(text or "")
    return self._drain(final=False)

  def finish(self) -> str:
    return self._drain(final=True)

  def _drain(self, final: bool = False) -> str:
    output = []
    marker_slop = 16
    while self.buffer:
      if self.in_think:
        match = re.search(r"</think\s*>", self.buffer, re.IGNORECASE)
        if match is None:
          self.buffer = "" if final else self.buffer[-marker_slop:]
          break
        self.buffer = self.buffer[match.end():]
        self.in_think = False
        continue

      match = re.search(r"<think\b", self.buffer, re.IGNORECASE)
      if match is None:
        if final or len(self.buffer) > marker_slop:
          keep = 0 if final else marker_slop
          output.append(self.buffer[:-keep] if keep else self.buffer)
          self.buffer = self.buffer[-keep:] if keep else ""
        break

      output.append(self.buffer[:match.start()])
      end = self.buffer.find(">", match.end())
      if end < 0:
        self.buffer = self.buffer[match.start():]
        break
      self.buffer = self.buffer[end + 1:]
      self.in_think = True
    return "".join(output)


def _strip_thinking_if_disabled(text: str) -> str:
  value = str(text or "")
  if _env_bool("SCIVEO_AGENT_ENABLE_THINKING", None) is False:
    return _THINK_BLOCK_RE.sub("", value).strip()
  return value.strip()


def _safe_name(value: str) -> str:
  value = str(value or "").strip()
  value = value.replace("/", "--")
  value = re.sub(r"[^a-zA-Z0-9_.-]+", "-", value)
  return value.strip("-") or "model"


def llm_models_base_path(base_path: str = None) -> str:
  if base_path:
    return os.path.abspath(os.path.expanduser(str(base_path)))

  config = GlobalConfiguration.get()
  configured = config["agent_models_base_path"]
  if configured:
    return os.path.abspath(os.path.join(os.path.expanduser(str(configured)), "llms"))

  return os.path.join(config.base_path, "models", "llms")


def hf_cache_path(cache_dir: str = None) -> str:
  if cache_dir:
    return os.path.abspath(os.path.expanduser(str(cache_dir)))
  return os.path.abspath(os.path.expanduser(
    os.environ.get("HF_HOME")
    or os.environ.get("HUGGINGFACE_HOME")
    or DEFAULT_HF_CACHE_PATH
  ))


def _manifest_dir(base_path: str = None, create: bool = True) -> str:
  path = os.path.join(llm_models_base_path(base_path), "manifests")
  if create:
    os.makedirs(path, exist_ok=True)
  return path


def _manifest_path(alias: str, base_path: str = None) -> str:
  return os.path.join(_manifest_dir(base_path), f"{_safe_name(alias)}.json")


def _write_manifest(manifest: dict, base_path: str = None) -> dict:
  path = _manifest_path(manifest["alias"], base_path)
  os.makedirs(os.path.dirname(path), exist_ok=True)
  manifest = dict(manifest)
  manifest["manifest_path"] = path
  with open(path, "w", encoding="utf-8") as fp:
    json.dump(manifest, fp, indent=2, sort_keys=True)
  return manifest


def _read_manifest(path: str) -> dict:
  with open(path, "r", encoding="utf-8") as fp:
    return json.load(fp)


def list_models(base_path: str = None) -> list[dict]:
  path = _manifest_dir(base_path, create=False)
  if not os.path.isdir(path):
    return []

  models = []
  for file_name in sorted(os.listdir(path)):
    if not file_name.endswith(".json"):
      continue
    try:
      models.append(_read_manifest(os.path.join(path, file_name)))
    except Exception as e:
      warning("Unable to read model manifest", file_name, e)
  return models


def find_model_manifest(model_or_alias: str, base_path: str = None):
  value = str(model_or_alias or "").strip()
  if not value:
    return None

  path = os.path.join(_manifest_dir(base_path, create=False), f"{_safe_name(value)}.json")
  if os.path.isfile(path):
    return _read_manifest(path)

  for manifest in list_models(base_path):
    if value in (manifest.get("alias"), manifest.get("model"), manifest.get("model_id")):
      return manifest
  return None


def resolve_model_path(model_or_alias: str, base_path: str = None) -> str:
  value = str(model_or_alias or "").strip() or DEFAULT_HF_MODEL
  manifest = find_model_manifest(value, base_path)
  if manifest:
    return manifest.get("local_path") or manifest.get("model") or value
  return value


def _manifest_file_path(manifest: dict, key: str):
  if not manifest:
    return None
  value = str(manifest.get(key) or "").strip()
  if not value:
    return None
  if os.path.isabs(value) and os.path.isfile(value):
    return value
  local_path = manifest.get("local_path")
  if local_path:
    candidate = os.path.join(os.path.abspath(os.path.expanduser(local_path)), value)
    if os.path.isfile(candidate):
      return candidate
  return value


def _snapshot_download(**kwargs):
  try:
    from huggingface_hub import snapshot_download
  except ImportError:
    raise ImportError("Sciveo local agent runtime requires 'huggingface_hub'. Install with sciveo[agent-local].")
  return snapshot_download(**kwargs)


def pull_model(
  model: str,
  alias: str = None,
  revision: str = None,
  base_path: str = None,
  token: str = None,
  cache_dir: str = None,
  file: str = None,
  mmproj_file: str = None,
) -> dict:
  model_id = str(model or "").strip()
  if not model_id:
    raise RuntimeError("agent pull requires --model")

  alias = str(alias or model_id.split("/")[-1]).strip()
  selected_file = str(file or "").strip() or None
  selected_mmproj_file = str(mmproj_file or "").strip() or None
  hf_cache = hf_cache_path(cache_dir)
  os.makedirs(hf_cache, exist_ok=True)

  download_kwargs = {
    "repo_id": model_id,
    "revision": revision,
    "cache_dir": hf_cache,
    "token": token,
  }
  patterns = []
  if selected_file:
    patterns.append(selected_file)
  if selected_mmproj_file:
    patterns.append(selected_mmproj_file)
  if patterns:
    download_kwargs["allow_patterns"] = patterns

  local_path = _snapshot_download(**download_kwargs)
  manifest = {
    "alias": alias,
    "model": model_id,
    "model_id": model_id,
    "revision": revision,
    "local_path": local_path,
    "cache_dir": hf_cache,
    "created_at": int(time.time()),
  }
  if selected_file:
    manifest["file"] = selected_file
  if selected_mmproj_file:
    manifest["mmproj_file"] = selected_mmproj_file
    manifest["vision"] = True
  return _write_manifest(manifest, base_path)


def _load_transformer_classes():
  try:
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
  except ImportError:
    raise ImportError("Sciveo local agent runtime requires torch and transformers. Install with sciveo[agent-local].")
  return torch, AutoTokenizer, AutoModelForCausalLM


def _load_transformer_vision_classes():
  try:
    import torch
    from transformers import AutoProcessor, AutoTokenizer
    try:
      from transformers import AutoModelForImageTextToText
      AutoVisionModel = AutoModelForImageTextToText
    except ImportError:
      try:
        from transformers import AutoModelForVision2Seq
        AutoVisionModel = AutoModelForVision2Seq
      except ImportError:
        from transformers import AutoModelForCausalLM
        AutoVisionModel = AutoModelForCausalLM
  except ImportError:
    raise ImportError("Sciveo local image runtime requires torch, transformers, and Pillow. Install with sciveo[agent-local].")
  return torch, AutoProcessor, AutoTokenizer, AutoVisionModel


def _load_llama_class():
  try:
    from llama_cpp import Llama
  except ImportError:
    raise ImportError(
      "GGUF models require llama-cpp-python. Install with sciveo[agent-local] or `pip install llama-cpp-python`."
    )
  return Llama


def _load_llama_chat_handler(name: str):
  try:
    import llama_cpp
  except ImportError:
    raise ImportError("GGUF image input requires llama-cpp-python with multimodal chat handler support.")

  handler = getattr(llama_cpp, name, None)
  if handler is not None:
    return handler

  try:
    from llama_cpp import llama_chat_format
  except ImportError:
    llama_chat_format = None

  if llama_chat_format is not None:
    handler = getattr(llama_chat_format, name, None)
    if handler is not None:
      return handler

  raise ImportError(f"GGUF image input requires llama-cpp-python with {name} support.")


def _gguf_vision_chat_handler_name(manifest: dict, model_path: str) -> str:
  values = [
    manifest.get("model") if manifest else None,
    manifest.get("model_id") if manifest else None,
    manifest.get("alias") if manifest else None,
    model_path,
  ]
  text = " ".join(str(value or "").lower() for value in values)

  if "qwen" in text:
    return "Qwen25VLChatHandler"
  if "llava-1.6" in text or "llava-v1.6" in text:
    return "Llava16ChatHandler"
  if "nanollava" in text or "nano-llava" in text:
    return "NanoLlavaChatHandler"
  if "minicpm" in text:
    return "MiniCPMv26ChatHandler"
  if "moondream" in text:
    return "MoondreamChatHandler"
  return "Llava15ChatHandler"


def _gguf_vision_image_min_tokens(handler_name: str):
  env_value = _env_int("SCIVEO_AGENT_IMAGE_MIN_TOKENS", None)
  if env_value is not None:
    return env_value
  if handler_name == "Qwen25VLChatHandler":
    return 1024
  return None


def _patch_chat_handler_mtmd_params(chat_handler, image_min_tokens=None, image_max_tokens=None, use_gpu=None):
  if image_min_tokens in (None, "") and image_max_tokens in (None, "") and use_gpu is None:
    return chat_handler
  if not hasattr(chat_handler, "_init_mtmd_context") or not hasattr(chat_handler, "_mtmd_cpp"):
    return chat_handler

  original_init = chat_handler._init_mtmd_context

  def init_with_image_tokens(llama_model):
    mtmd_cpp = chat_handler._mtmd_cpp
    original_default = mtmd_cpp.mtmd_context_params_default

    def params_default_with_image_tokens():
      params = original_default()
      if use_gpu is not None and hasattr(params, "use_gpu"):
        params.use_gpu = bool(use_gpu)
      if image_min_tokens not in (None, "") and hasattr(params, "image_min_tokens"):
        params.image_min_tokens = int(image_min_tokens)
      if image_max_tokens not in (None, "") and hasattr(params, "image_max_tokens"):
        params.image_max_tokens = int(image_max_tokens)
      return params

    mtmd_cpp.mtmd_context_params_default = params_default_with_image_tokens
    try:
      return original_init(llama_model)
    finally:
      mtmd_cpp.mtmd_context_params_default = original_default

  chat_handler._init_mtmd_context = init_with_image_tokens
  return chat_handler


def _make_llama_chat_handler(ChatHandler, clip_model_path: str, image_min_tokens=None, image_max_tokens=None, use_gpu=None):
  try:
    chat_handler = ChatHandler(clip_model_path=clip_model_path, verbose=False)
  except TypeError:
    chat_handler = ChatHandler(clip_model_path=clip_model_path)
  return _patch_chat_handler_mtmd_params(
    chat_handler,
    image_min_tokens=image_min_tokens,
    image_max_tokens=image_max_tokens,
    use_gpu=use_gpu,
  )


def _find_gguf_file(path: str):
  value = os.path.abspath(os.path.expanduser(str(path or "")))
  if os.path.isfile(value) and value.lower().endswith(".gguf"):
    return value
  if not os.path.isdir(value):
    return None

  files = []
  for root, _, file_names in os.walk(value):
    for file_name in file_names:
      lower_name = file_name.lower()
      if not lower_name.endswith(".gguf"):
        continue
      if "mmproj" in lower_name:
        continue
      file_path = os.path.join(root, file_name)
      try:
        size = os.path.getsize(file_path)
      except Exception:
        size = 0
      files.append((size, file_path))

  if not files:
    return None
  files.sort(reverse=True)
  return files[0][1]


def _env_int(name: str, default: int = None):
  value = os.environ.get(name)
  if value in (None, ""):
    return default
  try:
    return int(value)
  except Exception:
    return default


def _env_float_list(name: str):
  value = os.environ.get(name)
  if value in (None, ""):
    return None
  if str(value).strip().lower() in ("none", "off", "false", "0"):
    return None
  values = []
  for item in re.split(r"[,;:\s]+", str(value).strip()):
    if not item:
      continue
    try:
      values.append(float(item))
    except Exception:
      return None
  return values or None


def _gguf_gpu_layers(device: str):
  env_value = _env_int("SCIVEO_AGENT_GPU_LAYERS", None)
  if env_value is not None:
    return env_value

  value = str(device or "cpu").strip().lower()
  if value == "cpu":
    return 0
  if value in ("mps", "metal", "cuda", "gpu", "auto"):
    return -1
  return 0


def _gguf_tensor_split(device: str):
  env_value = _env_float_list("SCIVEO_AGENT_TENSOR_SPLIT")
  if env_value is not None:
    return env_value

  value = str(device or "cpu").strip().lower()
  if value not in ("cuda", "gpu", "auto"):
    return None

  try:
    result = subprocess.run(
      [
        "nvidia-smi",
        "--query-gpu=memory.total",
        "--format=csv,noheader,nounits",
      ],
      capture_output=True,
      text=True,
      timeout=3,
    )
  except Exception:
    return None

  if result.returncode != 0:
    return None

  values = []
  for line in result.stdout.splitlines():
    line = line.strip()
    if not line:
      continue
    try:
      values.append(float(line.split()[0]))
    except Exception:
      continue
  if len(values) < 2:
    return None
  return values


def _gguf_split_mode(device: str):
  env_value = _env_int("SCIVEO_AGENT_SPLIT_MODE", None)
  if env_value is not None:
    return env_value
  if _gguf_tensor_split(device):
    return 1
  return None


def _gguf_main_gpu():
  return _env_int("SCIVEO_AGENT_MAIN_GPU", None)


def _env_bool(name: str, default=None):
  value = os.environ.get(name)
  if value in (None, ""):
    return default
  return str(value).strip().lower() in ("1", "true", "yes", "y", "on")


def _gguf_flash_attn(device: str):
  env_value = _env_bool("SCIVEO_AGENT_FLASH_ATTN", None)
  if env_value is not None:
    return env_value
  value = str(device or "cpu").strip().lower()
  return value in ("cuda", "gpu", "auto")


def _move_inputs_to_device(inputs, device):
  if not device:
    return inputs
  moved = {}
  for key, value in dict(inputs).items():
    if hasattr(value, "to"):
      moved[key] = value.to(device)
    else:
      moved[key] = value
  return moved


def _module_device(module):
  if module is None:
    return None
  try:
    return next(module.parameters()).device
  except Exception:
    pass
  try:
    return next(module.buffers()).device
  except Exception:
    return None


def _module_by_path(module, path: str):
  current = module
  for name in str(path or "").split("."):
    if not name:
      continue
    current = getattr(current, name, None)
    if current is None:
      return None
  return current


def _device_from_map_value(value):
  if value in (None, "", "cpu", "disk"):
    return value if value == "cpu" else None
  if isinstance(value, int):
    return f"cuda:{value}"
  text = str(value)
  if text.isdigit():
    return f"cuda:{text}"
  return text


def _hf_input_device(model):
  try:
    device = _module_device(model.get_input_embeddings())
    if device is not None:
      return device
  except Exception:
    pass

  device_map = getattr(model, "hf_device_map", None)
  if isinstance(device_map, dict):
    for name in (
      "model.language_model.embed_tokens",
      "language_model.embed_tokens",
      "model.embed_tokens",
      "embed_tokens",
      "model.language_model",
      "language_model",
      "model",
    ):
      if name in device_map:
        return _device_from_map_value(device_map[name])
  return getattr(model, "device", None)


def _hf_visual_device(model):
  for path in ("model.visual", "visual", "vision_tower", "model.vision_tower"):
    device = _module_device(_module_by_path(model, path))
    if device is not None:
      return device

  device_map = getattr(model, "hf_device_map", None)
  if isinstance(device_map, dict):
    for name, value in device_map.items():
      if str(name).endswith(".visual") or "vision" in str(name):
        return _device_from_map_value(value)
  return None


def _move_hf_inputs_to_model_devices(inputs, model, fallback_device=None, vision=False):
  input_device = _hf_input_device(model) or fallback_device
  visual_device = _hf_visual_device(model) or input_device
  visual_keys = {
    "pixel_values",
    "pixel_values_videos",
  }

  moved = {}
  for key, value in dict(inputs).items():
    if not hasattr(value, "to"):
      moved[key] = value
      continue
    target_device = visual_device if vision and key in visual_keys else input_device
    moved[key] = value.to(target_device) if target_device else value
  return moved


def _hf_device_map_devices(model) -> set:
  device_map = getattr(model, "hf_device_map", None)
  if not isinstance(device_map, dict):
    return set()
  result = set()
  for value in device_map.values():
    device = _device_from_map_value(value)
    if device and device not in ("cpu", "disk"):
      result.add(str(device))
  return result


def _hf_uses_split_devices(model) -> bool:
  device_map = getattr(model, "hf_device_map", None)
  if isinstance(device_map, dict) and device_map:
    return True

  input_device = _hf_input_device(model)
  model_device = getattr(model, "device", None)
  if input_device is not None and model_device is not None and str(input_device) != str(model_device):
    return True

  return len(_hf_device_map_devices(model)) > 1


def _hf_chat_template_kwargs() -> dict:
  enable_thinking = _env_bool("SCIVEO_AGENT_ENABLE_THINKING", None)
  if enable_thinking is None:
    return {}
  return {"enable_thinking": enable_thinking}


def _torch_dtype_value(torch, value, default=None):
  text = str(value or "").strip().lower()
  if not text:
    return default
  if text in ("auto",):
    return "auto"
  if text in ("float16", "fp16", "half"):
    return getattr(torch, "float16", default)
  if text in ("bfloat16", "bf16"):
    return getattr(torch, "bfloat16", default)
  if text in ("float32", "fp32"):
    return getattr(torch, "float32", default)
  return default


def _hf_device_map(device: str, quantized: bool = False):
  env_value = os.environ.get("SCIVEO_AGENT_DEVICE_MAP")
  if env_value not in (None, ""):
    value = str(env_value).strip()
    if value.lower() in ("none", "off", "false", "0"):
      return None
    return value

  value = str(device or "cpu").strip().lower()
  if value == "auto":
    return "auto"
  if quantized and value in ("cuda", "gpu"):
    return "auto"
  return None


def _hf_quantization_config(torch):
  load_in_4bit = _env_bool("SCIVEO_AGENT_LOAD_IN_4BIT", False)
  load_in_8bit = _env_bool("SCIVEO_AGENT_LOAD_IN_8BIT", False)
  if not load_in_4bit and not load_in_8bit:
    return None

  try:
    from transformers import BitsAndBytesConfig
  except ImportError:
    raise ImportError("HF quantized loading requires transformers BitsAndBytesConfig and bitsandbytes.")

  if load_in_4bit:
    compute_dtype = _torch_dtype_value(
      torch,
      os.environ.get("SCIVEO_AGENT_BNB_4BIT_COMPUTE_DTYPE", "float16"),
      getattr(torch, "float16", None),
    )
    return BitsAndBytesConfig(
      load_in_4bit=True,
      bnb_4bit_quant_type=os.environ.get("SCIVEO_AGENT_BNB_4BIT_QUANT_TYPE", "nf4"),
      bnb_4bit_compute_dtype=compute_dtype,
      bnb_4bit_use_double_quant=_env_bool("SCIVEO_AGENT_BNB_4BIT_USE_DOUBLE_QUANT", True),
    )

  return BitsAndBytesConfig(load_in_8bit=True)


def _hf_model_kwargs(torch, device: str, torch_dtype: str, trust_remote_code: bool):
  quantization_config = _hf_quantization_config(torch)
  kwargs = {
    "trust_remote_code": trust_remote_code,
  }
  dtype_value = _torch_dtype_value(torch, torch_dtype, torch_dtype)
  if dtype_value:
    kwargs["torch_dtype"] = dtype_value
  if quantization_config is not None:
    kwargs["quantization_config"] = quantization_config
  device_map = _hf_device_map(device, quantized=quantization_config is not None)
  if device_map:
    kwargs["device_map"] = device_map
  return kwargs


def _input_length(inputs) -> int:
  try:
    input_ids = inputs.get("input_ids")
    shape = getattr(input_ids, "shape", None)
    if shape is not None:
      return int(shape[-1])
    if input_ids and isinstance(input_ids[0], (list, tuple)):
      return len(input_ids[0])
    return len(input_ids)
  except Exception:
    return 0


def _token_rate(tokens: int, seconds: float):
  try:
    tokens = int(tokens or 0)
    seconds = float(seconds or 0)
  except Exception:
    return None
  if tokens <= 0 or seconds <= 0:
    return None
  return tokens / seconds


def _json_line(value: dict) -> str:
  return json.dumps(value, ensure_ascii=False) + "\n"


class HuggingFaceLocalRuntime:
  def __init__(
    self,
    model: str = None,
    base_path: str = None,
    device: str = None,
    context: int = None,
    torch_dtype: str = "auto",
    trust_remote_code: bool = True,
  ):
    self.model = model or DEFAULT_HF_MODEL
    self.base_path = base_path
    self.device = device or os.environ.get("SCIVEO_AGENT_DEVICE") or os.environ.get("MEDIA_PROCESSING_BACKEND") or "cpu"
    self.context = context
    self.torch_dtype = torch_dtype
    self.trust_remote_code = trust_remote_code
    self.manifest = find_model_manifest(self.model, base_path=self.base_path)
    self.model_path = resolve_model_path(self.model, base_path=self.base_path)
    self.gguf_file = _find_gguf_file(self.model_path)
    self.mmproj_file = _manifest_file_path(self.manifest, "mmproj_file")
    self.tokenizer = None
    self.processor = None
    self.pipeline_model = None
    self.is_vision_model = False
    self.gguf_vision_handler_name = None
    self.gguf_vision_image_min_tokens = None
    self.gguf_vision_image_max_tokens = None

  def _load(self, vision: bool = False):
    if self.tokenizer is not None and self.pipeline_model is not None:
      if vision and not self.gguf_file and self.processor is None:
        info("reload Hugging Face runtime as vision model", self.model)
        self.tokenizer = None
        self.pipeline_model = None
        gc.collect()
        try:
          import torch
          if hasattr(torch, "cuda") and torch.cuda.is_available():
            torch.cuda.empty_cache()
        except Exception:
          pass
        self._load_transformer_vision()
      return

    if self.gguf_file:
      self._load_gguf()
      return

    if vision:
      self._load_transformer_vision()
      return

    torch, AutoTokenizer, AutoModelForCausalLM = _load_transformer_classes()
    self.tokenizer = AutoTokenizer.from_pretrained(
      self.model_path,
      trust_remote_code=self.trust_remote_code,
    )

    kwargs = _hf_model_kwargs(torch, self.device, self.torch_dtype, self.trust_remote_code)

    self.pipeline_model = AutoModelForCausalLM.from_pretrained(self.model_path, **kwargs)
    if "device_map" not in kwargs and self.device not in (None, "auto", "cpu") and hasattr(self.pipeline_model, "to"):
      self.pipeline_model = self.pipeline_model.to(self.device)

    if hasattr(self.pipeline_model, "eval"):
      self.pipeline_model.eval()

  def _load_transformer_vision(self):
    torch, AutoProcessor, AutoTokenizer, AutoVisionModel = _load_transformer_vision_classes()
    self.processor = AutoProcessor.from_pretrained(
      self.model_path,
      trust_remote_code=self.trust_remote_code,
    )
    self.tokenizer = getattr(self.processor, "tokenizer", None)
    if self.tokenizer is None:
      self.tokenizer = AutoTokenizer.from_pretrained(
        self.model_path,
        trust_remote_code=self.trust_remote_code,
      )

    kwargs = _hf_model_kwargs(torch, self.device, self.torch_dtype, self.trust_remote_code)

    self.pipeline_model = AutoVisionModel.from_pretrained(self.model_path, **kwargs)
    if "device_map" not in kwargs and self.device not in (None, "auto", "cpu") and hasattr(self.pipeline_model, "to"):
      self.pipeline_model = self.pipeline_model.to(self.device)
    if hasattr(self.pipeline_model, "eval"):
      self.pipeline_model.eval()
    self.is_vision_model = True

  def _load_gguf(self):
    Llama = _load_llama_class()
    n_ctx = self.context or _env_int("SCIVEO_AGENT_CONTEXT", _env_int("SCIVEO_AGENT_N_CTX", 65536))
    n_threads = _env_int("SCIVEO_AGENT_THREADS", None)
    n_gpu_layers = _gguf_gpu_layers(self.device)
    tensor_split = _gguf_tensor_split(self.device)
    split_mode = _gguf_split_mode(self.device)
    main_gpu = _gguf_main_gpu()
    flash_attn = _gguf_flash_attn(self.device)
    kwargs = {
      "model_path": self.gguf_file,
      "n_ctx": n_ctx,
      "n_gpu_layers": n_gpu_layers,
      "verbose": False,
    }
    if tensor_split is not None:
      kwargs["tensor_split"] = tensor_split
    if split_mode is not None:
      kwargs["split_mode"] = split_mode
    if main_gpu is not None:
      kwargs["main_gpu"] = main_gpu
    if flash_attn is not None:
      kwargs["flash_attn"] = flash_attn
    if n_threads is not None:
      kwargs["n_threads"] = n_threads
    if self.mmproj_file:
      handler_name = _gguf_vision_chat_handler_name(self.manifest, self.model_path)
      image_min_tokens = _gguf_vision_image_min_tokens(handler_name)
      image_max_tokens = _env_int("SCIVEO_AGENT_IMAGE_MAX_TOKENS", None)
      self.gguf_vision_handler_name = handler_name
      self.gguf_vision_image_min_tokens = image_min_tokens
      self.gguf_vision_image_max_tokens = image_max_tokens
      ChatHandler = _load_llama_chat_handler(handler_name)
      kwargs["chat_handler"] = _make_llama_chat_handler(
        ChatHandler,
        clip_model_path=self.mmproj_file,
        image_min_tokens=image_min_tokens,
        image_max_tokens=image_max_tokens,
        use_gpu=n_gpu_layers != 0,
      )

    self.pipeline_model = Llama(**kwargs)
    self.tokenizer = self.pipeline_model

  def _messages(self, messages: list[dict], system_prompt: str = None, keep_images: bool = False) -> list[dict]:
    result = []
    if system_prompt:
      result.append({"role": "system", "content": str(system_prompt)})
    for message in messages or []:
      role = message.get("role", "user")
      content = message.get("content", "")
      if keep_images:
        result.append({"role": role, "content": self._vision_content(content)})
      else:
        result.append({"role": role, "content": content_text(content, image_placeholder=True)})
    return result

  def _vision_content(self, content):
    parts = content_parts(content)
    if not any(part.get("type") == "image" for part in parts):
      return content_text(content, image_placeholder=False)

    result = []
    for part in parts:
      if part.get("type") == "image":
        result.append({
          "type": "image_url",
          "image_url": {"url": image_data_url(part)},
        })
      else:
        text = str(part.get("text") or "")
        if text:
          result.append({"type": "text", "text": text})
    return result

  def _hf_vision_content(self, content):
    parts = content_parts(content)
    if not any(part.get("type") == "image" for part in parts):
      return content_text(content, image_placeholder=False)
    result = []
    for part in parts:
      if part.get("type") == "image":
        result.append({"type": "image"})
      else:
        text = str(part.get("text") or "")
        if text:
          result.append({"type": "text", "text": text})
    return result

  def _hf_vision_messages(self, messages: list[dict], system_prompt: str = None) -> list[dict]:
    result = []
    if system_prompt:
      result.append({"role": "system", "content": str(system_prompt)})
    for message in messages or []:
      result.append({
        "role": message.get("role", "user"),
        "content": self._hf_vision_content(message.get("content", "")),
      })
    return result

  def _prompt(self, messages: list[dict], system_prompt: str = None) -> str:
    chat_messages = self._messages(messages, system_prompt=system_prompt)
    if hasattr(self.tokenizer, "apply_chat_template"):
      try:
        return self.tokenizer.apply_chat_template(
          chat_messages,
          tokenize=False,
          add_generation_prompt=True,
          **_hf_chat_template_kwargs(),
        )
      except Exception as e:
        warning("chat template failed, using plain prompt", e)

    lines = []
    for message in chat_messages:
      lines.append(f"{message.get('role', 'user')}: {message.get('content', '')}")
    lines.append("assistant:")
    return "\n".join(lines)

  def generate(
    self,
    messages: list[dict],
    system_prompt: str = None,
    max_new_tokens: int = _env_int("SCIVEO_AGENT_CONTEXT", _env_int("SCIVEO_AGENT_N_CTX", 65536)),
    temperature: float = 0.2,
  ) -> str:
    return self.generate_with_metrics(
      messages=messages,
      system_prompt=system_prompt,
      max_new_tokens=max_new_tokens,
      temperature=temperature,
    )["text"]

  def _prepare_generate_kwargs(
    self,
    messages: list[dict],
    system_prompt: str = None,
    max_new_tokens: int = _env_int("SCIVEO_AGENT_CONTEXT", _env_int("SCIVEO_AGENT_N_CTX", 65536)),
    temperature: float = 0.2,
  ):
    if messages_have_images(messages):
      return self._prepare_vision_generate_kwargs(
        messages=messages,
        system_prompt=system_prompt,
        max_new_tokens=max_new_tokens,
        temperature=temperature,
      )

    self._load()

    prompt = self._prompt(messages, system_prompt=system_prompt)
    tokenize_start = time.perf_counter()
    inputs = self.tokenizer(prompt, return_tensors="pt")
    tokenize_seconds = time.perf_counter() - tokenize_start
    input_len = _input_length(inputs)

    model_device = getattr(self.pipeline_model, "device", None)
    if self.device not in (None, "auto") and self.device != "cpu":
      inputs = _move_hf_inputs_to_model_devices(inputs, self.pipeline_model, fallback_device=self.device)
    elif model_device is not None:
      inputs = _move_hf_inputs_to_model_devices(inputs, self.pipeline_model, fallback_device=model_device)

    generate_kwargs = dict(inputs)
    generate_kwargs.update({
      "max_new_tokens": int(max_new_tokens),
      "do_sample": float(temperature or 0) > 0,
    })
    if float(temperature or 0) > 0:
      generate_kwargs["temperature"] = float(temperature)

    return generate_kwargs, input_len, tokenize_seconds

  def _prepare_vision_generate_kwargs(
    self,
    messages: list[dict],
    system_prompt: str = None,
    max_new_tokens: int = _env_int("SCIVEO_AGENT_CONTEXT", _env_int("SCIVEO_AGENT_N_CTX", 65536)),
    temperature: float = 0.2,
  ):
    self._load(vision=True)
    if self.processor is None:
      raise RuntimeError("Image input requires a vision-language Transformers model")

    chat_messages = self._hf_vision_messages(messages, system_prompt=system_prompt)
    images = pil_images_from_messages(messages)
    tokenize_start = time.perf_counter()
    if hasattr(self.processor, "apply_chat_template"):
      prompt = self.processor.apply_chat_template(
        chat_messages,
        tokenize=False,
        add_generation_prompt=True,
        **_hf_chat_template_kwargs(),
      )
    else:
      prompt = "\n".join(
        f"{message.get('role', 'user')}: {content_text(message.get('content', ''), image_placeholder=True)}"
        for message in messages or []
      ) + "\nassistant:"

    inputs = self.processor(
      text=[prompt],
      images=images,
      return_tensors="pt",
    )
    tokenize_seconds = time.perf_counter() - tokenize_start
    input_len = _input_length(inputs)

    model_device = getattr(self.pipeline_model, "device", None)
    if self.device not in (None, "auto") and self.device != "cpu":
      inputs = _move_hf_inputs_to_model_devices(inputs, self.pipeline_model, fallback_device=self.device, vision=True)
    elif model_device is not None:
      inputs = _move_hf_inputs_to_model_devices(inputs, self.pipeline_model, fallback_device=model_device, vision=True)

    generate_kwargs = dict(inputs)
    generate_kwargs.update({
      "max_new_tokens": int(max_new_tokens),
      "do_sample": float(temperature or 0) > 0,
    })
    if float(temperature or 0) > 0:
      generate_kwargs["temperature"] = float(temperature)
    return generate_kwargs, input_len, tokenize_seconds

  def _decode_outputs(self, outputs, input_len: int, fallback_text: str = ""):
    output_ids = []
    if outputs is not None:
      output_ids = outputs[0]
      try:
        output_ids = output_ids[input_len:]
      except Exception:
        pass
      text = _strip_thinking_if_disabled(self.tokenizer.decode(output_ids, skip_special_tokens=True))
      try:
        output_tokens = len(output_ids)
      except Exception:
        output_tokens = 0
      return text, output_tokens

    text = _strip_thinking_if_disabled(fallback_text)
    return text, self._count_text_tokens(text)

  def _count_text_tokens(self, text: str) -> int:
    if not text:
      return 0
    try:
      tokenized = self.tokenizer(text)
      return len(tokenized.get("input_ids", []))
    except Exception:
      return 0

  def _count_gguf_tokens(self, text: str) -> int:
    if not text:
      return 0
    try:
      return len(self.pipeline_model.tokenize(str(text).encode("utf-8"), add_bos=False))
    except Exception:
      return max(1, len(str(text).split()))

  def _gguf_prompt_text(self, messages: list[dict]) -> str:
    return "\n".join(
      f"{message.get('role', 'user')}: {content_text(message.get('content', ''), image_placeholder=True)}"
      for message in messages
    )

  def _gguf_image_metric_fields(self, messages: list[dict], reported_input_tokens: int = None) -> dict:
    parts = image_parts(messages)
    if not parts:
      return {}
    min_tokens = self.gguf_vision_image_min_tokens
    max_tokens = self.gguf_vision_image_max_tokens
    if min_tokens in (None, "") and self.mmproj_file:
      handler_name = self.gguf_vision_handler_name or _gguf_vision_chat_handler_name(self.manifest, self.model_path)
      min_tokens = _gguf_vision_image_min_tokens(handler_name)

    image_count = len(parts)
    estimated_image_tokens = int(min_tokens or 0) * image_count
    reported = int(reported_input_tokens or 0)
    estimated_total = reported + estimated_image_tokens if estimated_image_tokens else reported
    return {
      "image_count": image_count,
      "gguf_vision_handler": self.gguf_vision_handler_name,
      "gguf_image_min_tokens": min_tokens,
      "gguf_image_max_tokens": max_tokens,
      "reported_input_tokens": reported,
      "estimated_image_tokens": estimated_image_tokens,
      "estimated_total_input_tokens": estimated_total,
    }

  def _gguf_chat_completion_kwargs(
    self,
    messages: list[dict],
    system_prompt: str = None,
    max_new_tokens: int = _env_int("SCIVEO_AGENT_CONTEXT", _env_int("SCIVEO_AGENT_N_CTX", 65536)),
    temperature: float = 0.2,
    stream: bool = False,
  ):
    if messages_have_images(messages) and not self.mmproj_file:
      raise RuntimeError("GGUF image input requires a model manifest with mmproj_file")
    self._load()
    chat_messages = self._messages(messages, system_prompt=system_prompt, keep_images=messages_have_images(messages))
    tokenize_start = time.perf_counter()
    text_input_len = self._count_gguf_tokens(self._gguf_prompt_text(self._messages(messages, system_prompt=system_prompt)))
    image_metrics = self._gguf_image_metric_fields(messages, reported_input_tokens=text_input_len)
    input_len = int(image_metrics.get("estimated_total_input_tokens") or text_input_len)
    tokenize_seconds = time.perf_counter() - tokenize_start
    kwargs = {
      "messages": chat_messages,
      "max_tokens": int(max_new_tokens),
      "temperature": float(temperature or 0),
      "stream": bool(stream),
    }
    return kwargs, input_len, tokenize_seconds, image_metrics

  def _extract_gguf_text(self, response) -> str:
    try:
      return _strip_thinking_if_disabled(response["choices"][0]["message"].get("content") or "")
    except Exception:
      return ""

  def _extract_gguf_usage(self, response) -> dict:
    try:
      return dict(response.get("usage") or {})
    except Exception:
      return {}

  def _gguf_stream_token(self, event) -> str:
    try:
      choice = event.get("choices", [{}])[0]
      delta = choice.get("delta") or {}
      return str(delta.get("content") or choice.get("text") or "")
    except Exception:
      return ""

  def _metrics(
    self,
    input_len: int,
    output_tokens: int,
    tokenize_seconds: float,
    generation_seconds: float,
    total_seconds: float,
    first_token_seconds=None,
  ) -> dict:
    generation_tokens_for_rate = output_tokens
    generation_only_seconds = generation_seconds
    if first_token_seconds is not None:
      generation_tokens_for_rate = max(0, output_tokens - 1)
      generation_only_seconds = max(0, generation_seconds - first_token_seconds)

    generation_tps = _token_rate(generation_tokens_for_rate, generation_only_seconds)
    if generation_tps is None:
      generation_tps = _token_rate(output_tokens, generation_seconds)

    metrics = {
      "input_tokens": input_len,
      "output_tokens": output_tokens,
      "tokenize_seconds": tokenize_seconds,
      "generation_seconds": generation_seconds,
      "total_seconds": total_seconds,
      "generation_tokens_per_second": generation_tps,
    }
    if first_token_seconds is not None:
      metrics["first_token_seconds"] = first_token_seconds
      metrics["context_seconds"] = first_token_seconds
      metrics["context_tokens_per_second"] = _token_rate(input_len, first_token_seconds)
    return metrics

  def _generate_outputs(self, generate_kwargs: dict):
    start = time.perf_counter()
    outputs = self.pipeline_model.generate(**generate_kwargs)
    return outputs, time.perf_counter() - start, None, ""

  def generate_with_metrics(
    self,
    messages: list[dict],
    system_prompt: str = None,
    max_new_tokens: int = _env_int("SCIVEO_AGENT_CONTEXT", _env_int("SCIVEO_AGENT_N_CTX", 65536)),
    temperature: float = 0.2,
  ) -> dict:
    if self.gguf_file:
      return self._generate_gguf_with_metrics(
        messages=messages,
        system_prompt=system_prompt,
        max_new_tokens=max_new_tokens,
        temperature=temperature,
      )

    request_start = time.perf_counter()
    generate_kwargs, input_len, tokenize_seconds = self._prepare_generate_kwargs(
      messages=messages,
      system_prompt=system_prompt,
      max_new_tokens=max_new_tokens,
      temperature=temperature,
    )

    outputs, generation_seconds, first_token_seconds, streamed_text = self._generate_outputs(generate_kwargs)
    text, output_tokens = self._decode_outputs(outputs, input_len, fallback_text=streamed_text)
    total_seconds = time.perf_counter() - request_start
    metrics = self._metrics(
      input_len=input_len,
      output_tokens=output_tokens,
      tokenize_seconds=tokenize_seconds,
      generation_seconds=generation_seconds,
      total_seconds=total_seconds,
      first_token_seconds=first_token_seconds,
    )

    return {
      "text": text,
      "metrics": metrics,
    }

  def _generate_gguf_with_metrics(
    self,
    messages: list[dict],
    system_prompt: str = None,
    max_new_tokens: int = _env_int("SCIVEO_AGENT_CONTEXT", _env_int("SCIVEO_AGENT_N_CTX", 65536)),
    temperature: float = 0.2,
  ) -> dict:
    request_start = time.perf_counter()
    completion_kwargs, input_len, tokenize_seconds, image_metrics = self._gguf_chat_completion_kwargs(
      messages=messages,
      system_prompt=system_prompt,
      max_new_tokens=max_new_tokens,
      temperature=temperature,
      stream=False,
    )
    generation_start = time.perf_counter()
    response = self.pipeline_model.create_chat_completion(**completion_kwargs)
    generation_seconds = time.perf_counter() - generation_start
    total_seconds = time.perf_counter() - request_start
    text = self._extract_gguf_text(response)
    usage = self._extract_gguf_usage(response)
    reported_prompt_tokens = int(usage.get("prompt_tokens") or image_metrics.get("reported_input_tokens") or 0)
    if image_metrics:
      image_metrics = self._gguf_image_metric_fields(messages, reported_input_tokens=reported_prompt_tokens)
    input_tokens = int(image_metrics.get("estimated_total_input_tokens") or reported_prompt_tokens or input_len or 0)
    output_tokens = int(usage.get("completion_tokens") or self._count_gguf_tokens(text))
    metrics = self._metrics(
      input_len=input_tokens,
      output_tokens=output_tokens,
      tokenize_seconds=tokenize_seconds,
      generation_seconds=generation_seconds,
      total_seconds=total_seconds,
    )
    metrics["backend"] = "gguf"
    metrics.update(image_metrics)
    return {
      "text": text,
      "metrics": metrics,
    }

  def stream_with_metrics(
    self,
    messages: list[dict],
    system_prompt: str = None,
    max_new_tokens: int = _env_int("SCIVEO_AGENT_CONTEXT", _env_int("SCIVEO_AGENT_N_CTX", 65536)),
    temperature: float = 0.2,
  ):
    if self.gguf_file:
      yield from self._stream_gguf_with_metrics(
        messages=messages,
        system_prompt=system_prompt,
        max_new_tokens=max_new_tokens,
        temperature=temperature,
      )
      return

    request_start = time.perf_counter()
    generate_kwargs, input_len, tokenize_seconds = self._prepare_generate_kwargs(
      messages=messages,
      system_prompt=system_prompt,
      max_new_tokens=max_new_tokens,
      temperature=temperature,
    )

    if _hf_uses_split_devices(self.pipeline_model) and not _env_bool("SCIVEO_AGENT_STREAM_SPLIT_DEVICES", False):
      outputs, generation_seconds, first_token_seconds, streamed_text = self._generate_outputs(generate_kwargs)
      text, output_tokens = self._decode_outputs(outputs, input_len, fallback_text=streamed_text)
      total_seconds = time.perf_counter() - request_start
      metrics = self._metrics(
        input_len=input_len,
        output_tokens=output_tokens,
        tokenize_seconds=tokenize_seconds,
        generation_seconds=generation_seconds,
        total_seconds=total_seconds,
        first_token_seconds=first_token_seconds,
      )
      if text:
        yield {
          "type": "token",
          "text": text,
          "metrics": metrics,
        }
      yield {
        "type": "done",
        "text": text,
        "metrics": metrics,
      }
      return

    try:
      from transformers import TextIteratorStreamer
    except Exception:
      result = self.generate_with_metrics(
        messages=messages,
        system_prompt=system_prompt,
        max_new_tokens=max_new_tokens,
        temperature=temperature,
      )
      text = result.get("text", "")
      if text:
        yield {
          "type": "token",
          "text": text,
          "metrics": dict(result.get("metrics") or {}),
        }
      yield {
        "type": "done",
        "text": text,
        "metrics": dict(result.get("metrics") or {}),
      }
      return

    streamer = TextIteratorStreamer(self.tokenizer, skip_prompt=True, skip_special_tokens=True)
    holder = {}

    def target():
      try:
        holder["outputs"] = self.pipeline_model.generate(**generate_kwargs, streamer=streamer)
      except Exception as e:
        holder["error"] = e
        try:
          streamer.end()
        except Exception:
          pass

    generation_start = time.perf_counter()
    first_token_seconds = None
    chunks = []
    think_filter = _ThinkBlockStreamFilter() if _env_bool("SCIVEO_AGENT_ENABLE_THINKING", None) is False else None
    thread = threading.Thread(target=target)
    thread.start()

    for chunk in streamer:
      if not chunk:
        continue
      now = time.perf_counter()
      if first_token_seconds is None:
        first_token_seconds = now - generation_start
      chunks.append(chunk)
      text_so_far = "".join(chunks)
      output_tokens_so_far = self._count_text_tokens(text_so_far)
      generation_seconds = now - generation_start
      total_seconds = now - request_start
      metrics = self._metrics(
        input_len=input_len,
        output_tokens=output_tokens_so_far,
        tokenize_seconds=tokenize_seconds,
        generation_seconds=generation_seconds,
        total_seconds=total_seconds,
        first_token_seconds=first_token_seconds,
      )
      yield {
        "type": "progress",
        "metrics": metrics,
      }
      visible_chunk = think_filter.feed(chunk) if think_filter is not None else chunk
      if not visible_chunk:
        continue
      yield {
        "type": "token",
        "text": visible_chunk,
        "metrics": metrics,
      }

    thread.join()
    if holder.get("error") is not None:
      raise holder["error"]

    generation_seconds = time.perf_counter() - generation_start
    total_seconds = time.perf_counter() - request_start
    text, output_tokens = self._decode_outputs(
      holder.get("outputs"),
      input_len,
      fallback_text="".join(chunks),
    )
    metrics = self._metrics(
      input_len=input_len,
      output_tokens=output_tokens,
      tokenize_seconds=tokenize_seconds,
      generation_seconds=generation_seconds,
      total_seconds=total_seconds,
      first_token_seconds=first_token_seconds,
    )
    if think_filter is not None:
      visible_tail = think_filter.finish()
      if visible_tail:
        yield {
          "type": "token",
          "text": visible_tail,
          "metrics": metrics,
        }
    yield {
      "type": "done",
      "text": text,
      "metrics": metrics,
    }

  def _stream_gguf_with_metrics(
    self,
    messages: list[dict],
    system_prompt: str = None,
    max_new_tokens: int = _env_int("SCIVEO_AGENT_CONTEXT", _env_int("SCIVEO_AGENT_N_CTX", 65536)),
    temperature: float = 0.2,
  ):
    request_start = time.perf_counter()
    completion_kwargs, input_len, tokenize_seconds, image_metrics = self._gguf_chat_completion_kwargs(
      messages=messages,
      system_prompt=system_prompt,
      max_new_tokens=max_new_tokens,
      temperature=temperature,
      stream=True,
    )
    generation_start = time.perf_counter()
    first_token_seconds = None
    chunks = []
    think_filter = _ThinkBlockStreamFilter() if _env_bool("SCIVEO_AGENT_ENABLE_THINKING", None) is False else None

    for event in self.pipeline_model.create_chat_completion(**completion_kwargs):
      chunk = self._gguf_stream_token(event)
      if not chunk:
        continue
      now = time.perf_counter()
      if first_token_seconds is None:
        first_token_seconds = now - generation_start
      chunks.append(chunk)
      text_so_far = "".join(chunks)
      output_tokens_so_far = self._count_gguf_tokens(text_so_far)
      generation_seconds = now - generation_start
      total_seconds = now - request_start
      metrics = self._metrics(
        input_len=input_len,
        output_tokens=output_tokens_so_far,
        tokenize_seconds=tokenize_seconds,
        generation_seconds=generation_seconds,
        total_seconds=total_seconds,
        first_token_seconds=first_token_seconds,
      )
      metrics["backend"] = "gguf"
      metrics.update(image_metrics)
      yield {
        "type": "progress",
        "metrics": metrics,
      }
      visible_chunk = think_filter.feed(chunk) if think_filter is not None else chunk
      if not visible_chunk:
        continue
      yield {
        "type": "token",
        "text": visible_chunk,
        "metrics": metrics,
      }

    generation_seconds = time.perf_counter() - generation_start
    total_seconds = time.perf_counter() - request_start
    text = _strip_thinking_if_disabled("".join(chunks))
    output_tokens = self._count_gguf_tokens(text)
    metrics = self._metrics(
      input_len=input_len,
      output_tokens=output_tokens,
      tokenize_seconds=tokenize_seconds,
      generation_seconds=generation_seconds,
      total_seconds=total_seconds,
      first_token_seconds=first_token_seconds,
    )
    metrics["backend"] = "gguf"
    metrics.update(image_metrics)
    if think_filter is not None:
      visible_tail = think_filter.finish()
      if visible_tail:
        yield {
          "type": "token",
          "text": visible_tail,
          "metrics": metrics,
        }
    yield {
      "type": "done",
      "text": text,
      "metrics": metrics,
    }


class HuggingFaceRuntimeManager:
  def __init__(self, default_model: str = None, base_path: str = None, device: str = None, context: int = None):
    self.default_model = default_model or DEFAULT_HF_MODEL
    self.base_path = base_path
    self.device = device
    self.context = context
    self.runtimes = {}

  def _runtime(self, model: str = None) -> HuggingFaceLocalRuntime:
    model = str(model or self.default_model or DEFAULT_HF_MODEL)
    if model not in self.runtimes:
      self.runtimes[model] = HuggingFaceLocalRuntime(
        model=model,
        base_path=self.base_path,
        device=self.device,
        context=self.context,
      )
    return self.runtimes[model]

  def chat(
    self,
    messages: list[dict],
    system_prompt: str = None,
    model: str = None,
    max_new_tokens: int = _env_int("SCIVEO_AGENT_CONTEXT", _env_int("SCIVEO_AGENT_N_CTX", 65536)),
    temperature: float = 0.2,
  ) -> str:
    return self.chat_with_metrics(
      messages=messages,
      system_prompt=system_prompt,
      model=model,
      max_new_tokens=max_new_tokens,
      temperature=temperature,
    )["text"]

  def chat_with_metrics(
    self,
    messages: list[dict],
    system_prompt: str = None,
    model: str = None,
    max_new_tokens: int = _env_int("SCIVEO_AGENT_CONTEXT", _env_int("SCIVEO_AGENT_N_CTX", 65536)),
    temperature: float = 0.2,
  ) -> dict:
    return self._runtime(model).generate_with_metrics(
      messages=messages,
      system_prompt=system_prompt,
      max_new_tokens=max_new_tokens,
      temperature=temperature,
    )

  def stream_chat_with_metrics(
    self,
    messages: list[dict],
    system_prompt: str = None,
    model: str = None,
    max_new_tokens: int = _env_int("SCIVEO_AGENT_CONTEXT", _env_int("SCIVEO_AGENT_N_CTX", 65536)),
    temperature: float = 0.2,
  ):
    yield from self._runtime(model).stream_with_metrics(
      messages=messages,
      system_prompt=system_prompt,
      max_new_tokens=max_new_tokens,
      temperature=temperature,
    )


def create_hf_runtime_app(manager=None, auth_token: str = None, base_path: str = None):
  try:
    from flask import Flask, Response, abort, jsonify, request, stream_with_context
  except ImportError:
    raise ImportError("Sciveo local agent server requires flask. Install with sciveo[agent-local].")

  manager = manager or HuggingFaceRuntimeManager(base_path=base_path)
  app = Flask(__name__)

  def authenticate():
    if not auth_token:
      return
    token = request.headers.get("Authorization")
    if token != f"Bearer {auth_token}":
      abort(401, "Unauthorized")

  @app.before_request
  def before_request_func():
    authenticate()

  @app.route("/health", methods=["GET"])
  def health():
    return jsonify({"status": "ok", "runtime": "huggingface"})

  @app.route("/models", methods=["GET"])
  def models():
    return jsonify({"models": list_models(base_path=base_path)})

  @app.route("/chat", methods=["POST"])
  def chat():
    try:
      data = request.json or {}
      result = manager.chat_with_metrics(
        messages=data.get("messages", []),
        system_prompt=data.get("system_prompt"),
        model=data.get("model"),
        max_new_tokens=data.get("max_new_tokens", 65536),
        temperature=data.get("temperature", 0.2),
      )
      return jsonify({
        "text": result.get("text", ""),
        "metrics": result.get("metrics", {}),
        "model": data.get("model") or manager.default_model,
      })
    except Exception as e:
      exception("hf runtime chat", e)
      return jsonify({"error": str(e)}), 500

  @app.route("/chat/stream", methods=["POST"])
  def chat_stream():
    data = request.json or {}

    def events():
      try:
        for event in manager.stream_chat_with_metrics(
          messages=data.get("messages", []),
          system_prompt=data.get("system_prompt"),
          model=data.get("model"),
          max_new_tokens=data.get("max_new_tokens", _env_int("SCIVEO_AGENT_CONTEXT", _env_int("SCIVEO_AGENT_N_CTX", 65536))),
          temperature=data.get("temperature", 0.2),
        ):
          yield _json_line(event)
      except Exception as e:
        exception("hf runtime chat stream", e)
        yield _json_line({"type": "error", "error": str(e)})

    return Response(stream_with_context(events()), mimetype="application/x-ndjson")

  return app


def run_hf_runtime_server(
  model: str = None,
  host: str = DEFAULT_HF_HOST,
  port: int = DEFAULT_HF_PORT,
  auth_token: str = None,
  base_path: str = None,
  device: str = None,
  context: int = None,
):
  manager = HuggingFaceRuntimeManager(
    default_model=model or os.environ.get("SCIVEO_AGENT_MODEL") or DEFAULT_HF_MODEL,
    base_path=base_path,
    device=device,
    context=context,
  )
  app = create_hf_runtime_app(manager=manager, auth_token=auth_token, base_path=base_path)
  host = host or DEFAULT_HF_HOST
  port = int(port or DEFAULT_HF_PORT)
  info("run Hugging Face agent runtime", host, port, "model", manager.default_model)

  try:
    from waitress import serve
  except ImportError:
    warning("waitress is not installed; falling back to Flask development server")
    app.run(host=host, port=port)
    return

  serve(app, host=host, port=port, threads=1, connection_limit=10)
