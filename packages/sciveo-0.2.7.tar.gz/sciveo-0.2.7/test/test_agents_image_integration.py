import json
import os
import re
import statistics
import subprocess
import sys
import time
import unittest
from pathlib import Path

from sciveo.agents.clients.hf import HuggingFaceRuntimeClient
from sciveo.agents.media import build_user_content, normalize_image_input
from sciveo.tools.configuration import GlobalConfiguration


ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "test" / "assets"
DEFAULT_URL = "http://127.0.0.1:8910"
DEFAULT_OUTPUT_DIR = ASSETS / "agent_image_vqa_eval"


RUNTIME_CONFIGS = {
  "mps-gguf": {
    "description": "Apple MPS/Metal GGUF Qwen3.5 vision runtime",
    "model": "qwen3.5-4b-q4",
    "device": "mps",
    "context": 8192,
    "env": {
      "SCIVEO_AGENT_IMAGE_MIN_TOKENS": "1024",
    },
    "pull_command": (
      "PYENV_VERSION=sciveo python -m sciveo.cli agent --action pull "
      "--model unsloth/Qwen3.5-4B-GGUF --file Qwen3.5-4B-Q4_K_M.gguf "
      "--data-json '{\"mmproj_file\":\"mmproj-F16.gguf\"}' --alias qwen3.5-4b-q4"
    ),
  },
  "cpu-transformers": {
    "description": "CPU Transformers SmolVLM image-text runtime",
    "model": "smolvlm-256m",
    "device": "cpu",
    "context": 8192,
    "env": {},
    "pull_command": (
      "PYENV_VERSION=sciveo python -m sciveo.cli agent --action pull "
      "--model HuggingFaceTB/SmolVLM-256M-Instruct --alias smolvlm-256m"
    ),
  },
}


IMAGE_SPECS = {
  "ships_1.jpg": {
    "caption": "Several cargo ships and tankers are in the sea near fuel storage tanks.",
    "keywords": ["ship", "ships", "boat", "boats", "cargo", "tanker", "water", "sea", "vopak", "tank", "tanks"],
    "vqa": [
      {
        "question": "What vehicles are visible in the water? Answer with a short noun phrase.",
        "expected": "ships",
        "keywords": ["ship", "ships", "boat", "boats", "vessel", "vessels", "tanker"],
      },
      {
        "question": "What large white structures are visible on the shore? Answer briefly.",
        "expected": "storage tanks",
        "keywords": ["tank", "tanks", "storage", "fuel", "vopak"],
      },
    ],
  },
  "laion_coco_aesthetic_1k_1.jpg": {
    "keywords": ["iphone", "phone", "smartphone", "stand", "holder", "dock"],
    "vqa": [
      {
        "question": "What device is shown? Answer with the object name only.",
        "expected": "iPhone",
        "keywords": ["iphone", "phone", "smartphone"],
      },
      {
        "question": "What is the device sitting on? Answer briefly.",
        "expected": "stand",
        "keywords": ["stand", "holder", "dock"],
      },
    ],
  },
  "laion_coco_aesthetic_1k_2.jpg": {
    "keywords": ["dresser", "drawers", "ottoman", "furniture", "cabinet"],
    "vqa": [
      {
        "question": "What piece of furniture has drawers? Answer briefly.",
        "expected": "dresser",
        "keywords": ["dresser", "cabinet", "drawers"],
      },
      {
        "question": "What object is in front of the dresser? Answer briefly.",
        "expected": "ottoman",
        "keywords": ["ottoman", "stool", "seat", "bench"],
      },
    ],
  },
  "laion_coco_aesthetic_1k_3.jpg": {
    "keywords": ["desk", "white", "wheels", "table"],
    "vqa": [
      {
        "question": "What furniture item is shown? Answer with the object name only.",
        "expected": "desk",
        "keywords": ["desk", "table"],
      },
      {
        "question": "What color is the desk? Answer with one color.",
        "expected": "white",
        "keywords": ["white"],
      },
    ],
  },
}


def _read_caption_label(image_name):
  label_path = ASSETS / image_name.replace(".jpg", ".json")
  if not label_path.exists():
    return None
  try:
    return json.loads(label_path.read_text(encoding="utf-8")).get("caption")
  except Exception:
    return None


def image_specs():
  specs = {}
  for image_name, spec in IMAGE_SPECS.items():
    image_path = ASSETS / image_name
    if not image_path.exists():
      continue
    spec = dict(spec)
    spec["caption"] = _read_caption_label(image_name) or spec.get("caption", "")
    specs[image_name] = spec
  return specs


def build_cases():
  cases = []
  for image_name, spec in image_specs().items():
    cases.append({
      "image": image_name,
      "kind": "caption",
      "prompt": "Describe this image in one concise sentence.",
      "expected": spec.get("caption", ""),
      "keywords": list(spec.get("keywords", [])),
      "max_new_tokens": 48,
    })
    for item in spec.get("vqa", []):
      cases.append({
        "image": image_name,
        "kind": "vqa",
        "prompt": item["question"],
        "expected": item["expected"],
        "keywords": list(item.get("keywords", [])),
        "max_new_tokens": 32,
      })
  return cases


def clean_text(text):
  text = re.sub(r"<think>.*?</think>", "", str(text or ""), flags=re.S)
  return re.sub(r"\s+", " ", text).strip()


def _tokens(text):
  return re.findall(r"[a-z0-9]+", clean_text(text).lower())


def token_f1(predicted, expected):
  predicted_tokens = _tokens(predicted)
  expected_tokens = _tokens(expected)
  if not predicted_tokens or not expected_tokens:
    return 0.0
  predicted_counts = {}
  for token in predicted_tokens:
    predicted_counts[token] = predicted_counts.get(token, 0) + 1
  overlap = 0
  for token in expected_tokens:
    count = predicted_counts.get(token, 0)
    if count > 0:
      overlap += 1
      predicted_counts[token] = count - 1
  if overlap <= 0:
    return 0.0
  precision = overlap / len(predicted_tokens)
  recall = overlap / len(expected_tokens)
  return 2 * precision * recall / (precision + recall)


def keyword_hits(text, keywords):
  lower = clean_text(text).lower()
  hits = []
  for keyword in keywords:
    pattern = r"\b" + re.escape(str(keyword).lower()) + r"s?\b"
    if re.search(pattern, lower):
      hits.append(keyword)
  return hits


def score_case(text, expected, keywords):
  hits = keyword_hits(text, keywords)
  keyword_score = len(hits) / max(1, len(set(keywords)))
  return {
    "keyword_hits": hits,
    "keyword_score": keyword_score,
    "token_f1": token_f1(text, expected),
  }


def cli_env_prefix(runtime):
  env = RUNTIME_CONFIGS[runtime].get("env", {})
  pieces = [f"{key}={value}" for key, value in env.items()]
  pieces.append("PYENV_VERSION=sciveo")
  return " ".join(pieces)


def server_command(runtime, host="127.0.0.1", port=8910):
  config = RUNTIME_CONFIGS[runtime]
  return (
    f"{cli_env_prefix(runtime)} python -m sciveo.cli agent --action run "
    f"--host {host} --port {port} --device {config['device']} "
    f"--context {config['context']} --model {config['model']}"
  )


def client_command(runtime, url, image, prompt):
  model = RUNTIME_CONFIGS[runtime]["model"]
  prompt_json = json.dumps(prompt)
  return (
    "PYENV_VERSION=sciveo python -m sciveo.cli agent "
    f"--provider hf --url {url} --model {model} --mode batch --interactive false "
    f"--input-path test/assets/{image} --prompt {prompt_json}"
  )


def start_runtime(runtime, output_dir, url=DEFAULT_URL):
  from urllib.parse import urlparse

  parsed = urlparse(url)
  host = parsed.hostname or "127.0.0.1"
  port = parsed.port or 8910
  config = RUNTIME_CONFIGS[runtime]
  env = dict(os.environ)
  env.update(config.get("env", {}))
  env.setdefault("PYENV_VERSION", "sciveo")

  cmd = [
    sys.executable,
    "-m",
    "sciveo.cli",
    "agent",
    "--action",
    "run",
    "--host",
    host,
    "--port",
    str(port),
    "--device",
    config["device"],
    "--context",
    str(config["context"]),
    "--model",
    config["model"],
  ]
  log_path = output_dir / f"{runtime}_server.log"
  log_fp = log_path.open("w", encoding="utf-8")
  process = subprocess.Popen(
    cmd,
    cwd=str(ROOT),
    env=env,
    stdout=log_fp,
    stderr=subprocess.STDOUT,
    text=True,
  )
  return process, log_fp, log_path


def wait_for_health(url, auth_token, process, timeout=180):
  import requests

  deadline = time.time() + timeout
  headers = {"Authorization": f"Bearer {auth_token}"} if auth_token else {}
  last_error = None
  while time.time() < deadline:
    if process.poll() is not None:
      raise RuntimeError(f"runtime exited before health check: {process.returncode}")
    try:
      response = requests.get(f"{url.rstrip('/')}/health", headers=headers, timeout=5)
      if response.status_code == 200:
        return
      last_error = f"HTTP {response.status_code}: {response.text[:200]}"
    except Exception as exc:
      last_error = str(exc)
    time.sleep(1)
  raise RuntimeError(f"runtime health check timed out: {last_error}")


def stop_runtime(process, log_fp):
  if process.poll() is None:
    process.terminate()
    try:
      process.wait(timeout=20)
    except subprocess.TimeoutExpired:
      process.kill()
      process.wait(timeout=20)
  log_fp.close()


def evaluate_runtime(runtime, output_dir, url=DEFAULT_URL):
  config = RUNTIME_CONFIGS[runtime]
  auth_token = GlobalConfiguration.get()["secret_access_key"]
  cases = build_cases()
  jsonl_path = output_dir / f"{runtime}_agent_client_eval.jsonl"
  rows = []

  llm = HuggingFaceRuntimeClient(
    base_url=url,
    model=config["model"],
    auth_token=auth_token,
    stream=False,
    timeout=1800,
  )
  system_prompt = "Answer directly and briefly based only on the image. Do not invent invisible objects."

  with jsonl_path.open("w", encoding="utf-8") as fp:
    for index, case in enumerate(cases, 1):
      llm.max_new_tokens = int(case["max_new_tokens"])
      image_path = ASSETS / case["image"]
      image = normalize_image_input({"path": str(image_path)}, base_dir=str(ROOT))
      start = time.perf_counter()
      text = llm.chat(
        messages=[{
          "role": "user",
          "content": build_user_content(case["prompt"], [image]),
        }],
        system_prompt=system_prompt,
      )
      elapsed = time.perf_counter() - start
      text = clean_text(text)
      scores = score_case(text, case["expected"], case["keywords"])
      metrics = dict(llm.last_metrics or {})
      row = {
        "runtime": runtime,
        "runtime_description": config["description"],
        "model": config["model"],
        "device": config["device"],
        "context": config["context"],
        "index": index,
        "total": len(cases),
        "image": case["image"],
        "kind": case["kind"],
        "prompt": case["prompt"],
        "expected": case["expected"],
        "text": text,
        "elapsed_seconds": elapsed,
        "metrics": metrics,
        **scores,
      }
      rows.append(row)
      fp.write(json.dumps(row, sort_keys=True) + "\n")
      fp.flush()
      print(
        f"[{runtime} {index:02d}/{len(cases)}] {case['image']} {case['kind']} "
        f"elapsed={elapsed:.1f}s kw={row['keyword_score']:.2f} f1={row['token_f1']:.2f} text={text[:160]}",
        flush=True,
      )
  return rows, jsonl_path


def summarize(runtime, rows):
  latencies = [row["elapsed_seconds"] for row in rows]
  keyword_scores = [row["keyword_score"] for row in rows]
  token_f1_scores = [row["token_f1"] for row in rows]
  request_seconds = [
    row["metrics"].get("request_seconds")
    for row in rows
    if row["metrics"].get("request_seconds") is not None
  ]
  generation_tps = [
    row["metrics"].get("generation_tokens_per_second")
    for row in rows
    if row["metrics"].get("generation_tokens_per_second") is not None
  ]
  summary = {
    "runtime": runtime,
    "model": RUNTIME_CONFIGS[runtime]["model"],
    "device": RUNTIME_CONFIGS[runtime]["device"],
    "context": RUNTIME_CONFIGS[runtime]["context"],
    "total_cases": len(rows),
    "mean_latency_seconds": statistics.mean(latencies) if latencies else None,
    "median_latency_seconds": statistics.median(latencies) if latencies else None,
    "mean_request_seconds": statistics.mean(request_seconds) if request_seconds else None,
    "mean_generation_tokens_per_second": statistics.mean(generation_tps) if generation_tps else None,
    "mean_keyword_score": statistics.mean(keyword_scores) if keyword_scores else None,
    "mean_token_f1": statistics.mean(token_f1_scores) if token_f1_scores else None,
  }
  by_kind = {}
  for kind in sorted(set(row["kind"] for row in rows)):
    kind_rows = [row for row in rows if row["kind"] == kind]
    by_kind[kind] = {
      "cases": len(kind_rows),
      "mean_keyword_score": statistics.mean(row["keyword_score"] for row in kind_rows),
      "mean_token_f1": statistics.mean(row["token_f1"] for row in kind_rows),
      "mean_latency_seconds": statistics.mean(row["elapsed_seconds"] for row in kind_rows),
    }
  summary["by_kind"] = by_kind
  return summary


def write_report(output_dir, url, runtime_rows, summaries, paths):
  report_path = output_dir / "agent_image_vqa_integration_report.md"
  lines = [
    "# Agent Image VQA Integration Report",
    "",
    f"Remote URL: `{url}`",
    "",
    "## CLI Commands",
    "",
  ]
  for runtime in runtime_rows:
    config = RUNTIME_CONFIGS[runtime]
    first_case = build_cases()[0]
    lines.extend([
      f"### {runtime}",
      "",
      "Pull:",
      "",
      "```bash",
      config["pull_command"],
      "```",
      "",
      "Server:",
      "",
      "```bash",
      server_command(runtime),
      "```",
      "",
      "Agent client example:",
      "",
      "```bash",
      client_command(runtime, url, first_case["image"], first_case["prompt"]),
      "```",
      "",
    ])

  lines.extend(["## Summary", ""])
  for runtime, summary in summaries.items():
    lines.extend([
      f"### {runtime}",
      "",
      f"- Model: `{summary['model']}`",
      f"- Device: `{summary['device']}`",
      f"- Cases: `{summary['total_cases']}`",
      f"- Mean latency: `{summary['mean_latency_seconds']:.2f}s`",
      f"- Median latency: `{summary['median_latency_seconds']:.2f}s`",
      f"- Mean keyword score: `{summary['mean_keyword_score']:.3f}`",
      f"- Mean token F1: `{summary['mean_token_f1']:.3f}`",
      f"- Mean generation tokens/sec: `{summary['mean_generation_tokens_per_second']}`",
      "",
      "| Kind | Cases | Mean keyword score | Mean token F1 | Mean latency |",
      "| --- | ---: | ---: | ---: | ---: |",
    ])
    for kind, kind_summary in summary["by_kind"].items():
      lines.append(
        f"| {kind} | {kind_summary['cases']} | {kind_summary['mean_keyword_score']:.3f} | "
        f"{kind_summary['mean_token_f1']:.3f} | {kind_summary['mean_latency_seconds']:.2f}s |"
      )
    lines.append("")

  lines.extend(["## Cases", ""])
  for runtime, rows in runtime_rows.items():
    lines.extend([
      f"### {runtime}",
      "",
      "| Image | Kind | Latency | Keyword | F1 | Expected | Output |",
      "| --- | --- | ---: | ---: | ---: | --- | --- |",
    ])
    for row in rows:
      expected = row["expected"].replace("|", "\\|")
      text = row["text"].replace("|", "\\|")
      lines.append(
        f"| {row['image']} | {row['kind']} | {row['elapsed_seconds']:.1f}s | "
        f"{row['keyword_score']:.2f} | {row['token_f1']:.2f} | {expected} | {text} |"
      )
    lines.append("")

  lines.extend([
    "## Artifacts",
    "",
  ])
  for runtime, path in paths.items():
    lines.append(f"- `{runtime}` JSONL: `{path}`")
  lines.append(f"- Report: `{report_path}`")
  report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
  return report_path


def run_integration():
  runtimes = os.environ.get("SCIVEO_AGENT_IMAGE_INTEGRATION_RUNTIMES", "mps-gguf,cpu-transformers")
  runtimes = [item.strip() for item in runtimes.split(",") if item.strip()]
  unknown = [runtime for runtime in runtimes if runtime not in RUNTIME_CONFIGS]
  if unknown:
    raise RuntimeError(f"Unknown runtimes: {unknown}")

  output_dir = Path(os.environ.get("SCIVEO_AGENT_IMAGE_INTEGRATION_OUT", str(DEFAULT_OUTPUT_DIR)))
  output_dir.mkdir(parents=True, exist_ok=True)
  url = os.environ.get("SCIVEO_AGENT_IMAGE_INTEGRATION_URL", DEFAULT_URL).rstrip("/")

  all_rows = {}
  summaries = {}
  paths = {}
  for runtime in runtimes:
    process, log_fp, log_path = start_runtime(runtime, output_dir, url=url)
    try:
      wait_for_health(url, GlobalConfiguration.get()["secret_access_key"], process)
      rows, jsonl_path = evaluate_runtime(runtime, output_dir, url=url)
      all_rows[runtime] = rows
      summaries[runtime] = summarize(runtime, rows)
      paths[runtime] = jsonl_path
      paths[f"{runtime}-server-log"] = log_path
    finally:
      stop_runtime(process, log_fp)

  summary_path = output_dir / "agent_image_vqa_integration_summary.json"
  summary_path.write_text(json.dumps(summaries, indent=2, sort_keys=True) + "\n", encoding="utf-8")
  paths["summary"] = summary_path
  report_path = write_report(output_dir, url, all_rows, summaries, paths)
  return {
    "output_dir": str(output_dir),
    "report": str(report_path),
    "summary": str(summary_path),
    "summaries": summaries,
  }


@unittest.skipUnless(
  os.environ.get("SCIVEO_RUN_AGENT_IMAGE_INTEGRATION") == "1",
  "set SCIVEO_RUN_AGENT_IMAGE_INTEGRATION=1 to run slow local image/VQA agent integration tests",
)
class TestAgentImageVQAIntegration(unittest.TestCase):
  def test_mps_gguf_and_cpu_transformers_remote_agent_client(self):
    result = run_integration()
    self.assertTrue(Path(result["report"]).is_file())
    self.assertTrue(Path(result["summary"]).is_file())
    for summary in result["summaries"].values():
      self.assertGreater(summary["total_cases"], 0)


if __name__ == "__main__":
  if os.environ.get("SCIVEO_RUN_AGENT_IMAGE_INTEGRATION") != "1":
    os.environ["SCIVEO_RUN_AGENT_IMAGE_INTEGRATION"] = "1"
  unittest.main(verbosity=2)
