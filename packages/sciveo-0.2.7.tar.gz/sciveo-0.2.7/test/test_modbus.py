import sys
import socket
import unittest

from types import SimpleNamespace
from unittest.mock import patch

from sciveo import cli
from sciveo.monitoring.power.tools import EMS300_REG_MAP
from sciveo.monitoring.power.tools import read_input_registers as read_ems300_input_registers
from sciveo.network import modbus


def get_free_tcp_port():
  sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  try:
    try:
      sock.bind(("127.0.0.1", 0))
    except OSError as e:
      raise unittest.SkipTest(f"Unable to bind local TCP test socket: {e}")
    return sock.getsockname()[1]
  finally:
    sock.close()


class FakeResponse:
  def __init__(self, registers=None, error=False):
    self.registers = list(registers or [])
    self.error = error

  def isError(self):
    return self.error


class FakeClient:
  def __init__(self, holding_response=None, input_response=None, write_response=None):
    self.holding_response = holding_response or FakeResponse(registers=[0])
    self.input_response = input_response or FakeResponse(registers=[0])
    self.write_response = write_response or FakeResponse()
    self.connected = False
    self.connect_calls = 0
    self.close_calls = 0
    self.last_holding = None
    self.last_input = None
    self.last_write_single = None
    self.last_write_multi = None

  def connect(self):
    self.connect_calls += 1
    self.connected = True
    return True

  def close(self):
    self.close_calls += 1
    self.connected = False

  def read_holding_registers(self, address, count=1, device_id=1):
    self.last_holding = (address, count, device_id)
    return self.holding_response

  def read_input_registers(self, address, count=1, device_id=1):
    self.last_input = (address, count, device_id)
    return self.input_response

  def write_register(self, address, value, device_id=1):
    self.last_write_single = (address, value, device_id)
    return self.write_response

  def write_registers(self, address, values, device_id=1):
    self.last_write_multi = (address, list(values), device_id)
    return self.write_response


class ContextBackedClient:
  def __init__(self, context):
    self.context = context

  def _read(self, block_name, address, count, device_id):
    device_store = self.context[device_id]
    if isinstance(device_store, dict):
      result = device_store[block_name].getValues(address + 1, count=count)
    else:
      function_code = 4 if block_name == "ir" else 3
      result = device_store.getValues(function_code, address, count=count)
    error = not isinstance(result, list)
    return FakeResponse(registers=result if not error else [], error=error)

  def read_holding_registers(self, address, count=1, device_id=1):
    return self._read("hr", address, count, device_id)

  def read_input_registers(self, address, count=1, device_id=1):
    return self._read("ir", address, count, device_id)

  def write_register(self, address, value, device_id=1):
    device_store = self.context[device_id]
    if isinstance(device_store, dict):
      device_store["hr"].setValues(address + 1, [value])
    else:
      device_store.setValues(6, address, [value])
    return FakeResponse()

  def write_registers(self, address, values, device_id=1):
    device_store = self.context[device_id]
    if isinstance(device_store, dict):
      device_store["hr"].setValues(address + 1, list(values))
    else:
      device_store.setValues(16, address, list(values))
    return FakeResponse()


def make_args(**overrides):
  data = {
    "proto": "modbus",
    "transport": "tcp",
    "host": "127.0.0.1",
    "port": 502,
    "serial_port": None,
    "baudrate": 9600,
    "bytesize": 8,
    "parity": "N",
    "stopbits": 1,
    "framer": "rtu",
    "timeout": 1.0,
    "retries": 3,
    "reconnect_delay": 0.1,
    "reconnect_delay_max": 300,
    "handle_local_echo": False,
    "address": None,
    "count": None,
    "register_type": None,
    "data_type": None,
    "factor": None,
    "device_id": None,
    "zero_based": False,
    "reg": None,
    "value": None,
  }
  data.update(overrides)
  return SimpleNamespace(**data)


class FakeConfig(dict):
  def __init__(self):
    super().__init__({"secret_access_key": None})
    self.name = "sciveo"


class TestModbusTransportConfig(unittest.TestCase):
  def test_build_supports_serial_host_fallback(self):
    config = modbus.ModbusTransportConfig.build(config={"transport": "serial"}, host="/dev/ttyUSB-test")

    self.assertEqual(config.transport, "serial")
    self.assertEqual(config.serial_port, "/dev/ttyUSB-test")
    self.assertEqual(config.endpoint, "/dev/ttyUSB-test")


class TestModbusReadWrite(unittest.TestCase):
  def test_resolve_register_arguments_supports_compact_reg_list(self):
    result = modbus.resolve_register_arguments(make_args(reg=[5039, "U16", 0.1, 1], device_id=1))

    self.assertEqual(result, {
      "address": 5039,
      "data_type": "U16",
      "factor": 0.1,
      "count": 1,
      "register_type": "holding",
      "device_id": 1,
    })

  def test_resolve_register_arguments_treats_compact_count_one_as_single_typed_value(self):
    result = modbus.resolve_register_arguments(make_args(reg=[5033, "U32", 1, 1], device_id=1))

    self.assertEqual(result, {
      "address": 5033,
      "data_type": "U32",
      "factor": 1.0,
      "count": 2,
      "register_type": "holding",
      "device_id": 1,
    })

  def test_read_raw_holding_registers_uses_one_based_address_by_default(self):
    client = FakeClient(holding_response=FakeResponse(registers=[10, 20]))

    result = modbus.read_modbus_registers(
      client=client,
      address=100,
      register_type="holding",
      count=2,
      data_type="RAW",
      device_id=7,
    )

    self.assertEqual(client.last_holding, (99, 2, 7))
    self.assertEqual(result["registers"], [10, 20])
    self.assertEqual(result["value"], [10, 20])

  def test_read_decodes_u32_le(self):
    client = FakeClient(holding_response=FakeResponse(registers=[0x000A, 0x0000]))

    result = modbus.read_modbus_registers(
      client=client,
      address=5,
      data_type="U32_LE",
    )

    self.assertEqual(result["value"], 10)

  def test_write_raw_multi_registers_uses_write_registers(self):
    client = FakeClient(write_response=FakeResponse())

    result = modbus.write_modbus_registers(
      client=client,
      address=10,
      value=[1, 2],
      data_type="RAW",
      device_id=3,
    )

    self.assertEqual(client.last_write_multi, (9, [1, 2], 3))
    self.assertEqual(result["registers"], [1, 2])
    self.assertEqual(result["status"], "ok")

  def test_write_scaled_u16_uses_write_register(self):
    client = FakeClient(write_response=FakeResponse())

    result = modbus.write_modbus_registers(
      client=client,
      address=12,
      value=12.3,
      data_type="U16",
      factor=0.1,
    )

    self.assertEqual(client.last_write_single, (11, 123, 1))
    self.assertEqual(result["registers"], [123])


class TestExecuteModbusCommand(unittest.TestCase):
  def test_execute_modbus_command_opens_and_closes_client(self):
    client = FakeClient(holding_response=FakeResponse(registers=[42]))

    with patch.object(modbus.ModbusTransportConfig, "create_client", return_value=client):
      result = modbus.execute_modbus_command("read", make_args(address=7))

    self.assertEqual(client.connect_calls, 1)
    self.assertEqual(client.close_calls, 1)
    self.assertEqual(result["endpoint"], "tcp://127.0.0.1:502")
    self.assertEqual(result["value"], [42])

  def test_execute_modbus_command_supports_reg_shortcut(self):
    client = FakeClient(holding_response=FakeResponse(registers=[363]))

    args = make_args(
      transport="serial",
      serial_port="/dev/ttyUSB0",
      baudrate=9600,
      bytesize=8,
      parity="N",
      stopbits=1,
      device_id=1,
      reg=[5039, "U16", 0.1, 1],
    )

    with patch.object(modbus.ModbusTransportConfig, "create_client", return_value=client):
      result = modbus.execute_modbus_command("read", args)

    self.assertEqual(client.last_holding, (5038, 1, 1))
    self.assertAlmostEqual(result["value"], 36.3)
    self.assertEqual(result["transport"], "serial")


class TestModbusEmulator(unittest.TestCase):
  def start_emulator_or_skip(self, emulator):
    try:
      emulator.start_server()
    except Exception as e:
      self.skipTest(f"Unable to start local Modbus TCP emulator: {e}")

  def create_tcp_client(self, port):
    transport_config = modbus.ModbusTransportConfig.build(config={
      "transport": "tcp",
      "host": "127.0.0.1",
      "port": port,
      "timeout": 0.5,
      "retries": 1,
    })
    client = transport_config.create_client()
    if not client.connect():
      self.fail(f"Unable to connect to {transport_config.label}")
    return client

  def test_profile_loading_supports_overrides(self):
    profile = modbus.get_modbus_emulator_profile(
      profile_name="ems300",
      profile={"input": {8060: {"value": 9000, "data_type": "S32_LE"}}},
    )

    self.assertEqual(profile["name"], "ems300")
    self.assertEqual(profile["input"][8060]["value"], 9000)
    self.assertEqual(profile["device_id"], 247)

  def test_build_server_context_normalizes_one_based_addresses(self):
    context = modbus.build_modbus_server_context({
      "device_id": 247,
      "input": {
        8060: {"value": 8200, "data_type": "S32_LE"},
      },
    })

    self.assertEqual(
      context[247].getValues(4, 8059, count=2),
      modbus.encode_registers(8200, "S32_LE"),
    )

  def test_emulator_reads_input_registers_through_client_helpers(self):
    emulator = modbus.ModbusTcpEmulator(
      profile_name="custom",
      profile={
        "device_id": 7,
        "input": {
          30001: [10, 20],
        },
      },
      period=0,
    )
    client = ContextBackedClient(emulator.context)

    result = modbus.read_modbus_registers(
      client=client,
      address=30001,
      register_type="input",
      count=2,
      data_type="RAW",
      device_id=7,
    )

    self.assertEqual(result["registers"], [10, 20])
    self.assertEqual(result["value"], [10, 20])

  def test_emulator_writes_holding_registers_through_client_helpers(self):
    emulator = modbus.ModbusTcpEmulator(
      profile_name="custom",
      profile={
        "device_id": 3,
        "holding": {},
      },
      period=0,
    )
    client = ContextBackedClient(emulator.context)

    result = modbus.write_modbus_registers(
      client=client,
      address=40010,
      value=123,
      data_type="U16",
      device_id=3,
    )

    self.assertEqual(result["status"], "ok")
    self.assertEqual(emulator.get_registers(address=40010, count=1, register_type="holding", device_id=3), [123])

  def test_emulator_routes_device_ids(self):
    emulator = modbus.ModbusTcpEmulator(
      profile_name="custom",
      profile={
        "devices": {
          1: {"input": {100: 11}},
          2: {"input": {100: 22}},
        },
      },
      period=0,
    )

    self.assertEqual(emulator.get_registers(address=100, count=1, register_type="input", device_id=1), [11])
    self.assertEqual(emulator.get_registers(address=100, count=1, register_type="input", device_id=2), [22])

  def test_ems300_profile_matches_monitoring_reader_addressing(self):
    emulator = modbus.ModbusTcpEmulator(profile_name="ems300", period=0)
    client = ContextBackedClient(emulator.context)

    value, name, dtype = read_ems300_input_registers(client, EMS300_REG_MAP, 8060, 247)

    self.assertEqual(value, 8200)
    self.assertEqual(name, "PV Active Power")
    self.assertEqual(dtype, "S32")

  def test_logger1000_sg_profile_reads_input_and_writes_dispatch_registers(self):
    emulator = modbus.ModbusTcpEmulator(profile_name="logger1000-sg", period=0)
    client = ContextBackedClient(emulator.context)

    device_type = modbus.read_modbus_registers(
      client=client,
      address=8000,
      register_type="input",
      data_type="U16",
      device_id=247,
    )
    self.assertEqual(device_type["value"], 0x0710)

    total_active_power = modbus.read_modbus_registers(
      client=client,
      address=8070,
      register_type="input",
      data_type="U64",
      device_id=247,
    )
    self.assertEqual(total_active_power["value"], 8200)

    result = modbus.write_modbus_registers(
      client=client,
      address=8003,
      value=45.6,
      data_type="U32_LE",
      factor=0.1,
      device_id=247,
    )
    self.assertEqual(result["status"], "ok")

    active_setpoint = modbus.read_modbus_registers(
      client=client,
      address=8003,
      register_type="holding",
      data_type="U32_LE",
      factor=0.1,
      device_id=247,
    )
    self.assertEqual(active_setpoint["value"], 45.6)

  def test_logger1000_hw_profile_reads_holding_and_writes_dispatch_registers(self):
    emulator = modbus.ModbusTcpEmulator(profile_name="logger1000-hw", period=0)
    client = ContextBackedClient(emulator.context)

    active_power = modbus.read_modbus_registers(
      client=client,
      address=40525,
      register_type="holding",
      data_type="S32",
      factor=0.001,
      device_id=0,
    )
    self.assertEqual(active_power["value"], 8.2)

    total_yield = modbus.read_modbus_registers(
      client=client,
      address=40560,
      register_type="holding",
      data_type="U32",
      factor=0.1,
      device_id=0,
    )
    self.assertAlmostEqual(total_yield["value"], 98765.4)

    result = modbus.write_modbus_registers(
      client=client,
      address=40428,
      value=75,
      data_type="U16",
      factor=0.1,
      device_id=0,
    )
    self.assertEqual(result["status"], "ok")

    active_percentage = modbus.read_modbus_registers(
      client=client,
      address=40428,
      register_type="holding",
      data_type="U16",
      factor=0.1,
      device_id=0,
    )
    self.assertEqual(active_percentage["value"], 75)

  def test_tcp_ems300_emulator_reads_input_registers_with_real_client(self):
    port = get_free_tcp_port()
    emulator = modbus.ModbusTcpEmulator(profile_name="ems300", host="127.0.0.1", port=port, period=0)
    self.start_emulator_or_skip(emulator)
    client = self.create_tcp_client(port)

    try:
      value, name, dtype = read_ems300_input_registers(client, EMS300_REG_MAP, 8060, 247)

      self.assertEqual(value, 8200)
      self.assertEqual(name, "PV Active Power")
      self.assertEqual(dtype, "S32")
    finally:
      client.close()
      emulator.stop_server()

  def test_tcp_logger1000_profiles_read_with_real_client(self):
    port = get_free_tcp_port()
    emulator = modbus.ModbusTcpEmulator(profile_name="logger1000-sg", host="127.0.0.1", port=port, period=0)
    self.start_emulator_or_skip(emulator)
    client = self.create_tcp_client(port)

    try:
      device_type = modbus.read_modbus_registers(
        client=client,
        address=8000,
        register_type="input",
        data_type="U16",
        device_id=247,
      )
      self.assertEqual(device_type["value"], 0x0710)
    finally:
      client.close()
      emulator.stop_server()

    port = get_free_tcp_port()
    emulator = modbus.ModbusTcpEmulator(profile_name="logger1000-hw", host="127.0.0.1", port=port, period=0)
    self.start_emulator_or_skip(emulator)
    client = self.create_tcp_client(port)

    try:
      active_power = modbus.read_modbus_registers(
        client=client,
        address=40525,
        register_type="holding",
        data_type="S32",
        factor=0.001,
        device_id=0,
      )
      self.assertEqual(active_power["value"], 8.2)
    finally:
      client.close()
      emulator.stop_server()

  def test_tcp_custom_emulator_reads_and_writes_with_real_client(self):
    port = get_free_tcp_port()
    emulator = modbus.ModbusTcpEmulator(
      profile_name="custom",
      profile={
        "device_id": 7,
        "input": {
          30001: [10, 20],
          30010: {"value": 12.3, "data_type": "U16", "factor": 0.1},
        },
        "holding": {
          40001: [1, 2],
          40010: {"value": 45.6, "data_type": "U16", "factor": 0.1},
        },
      },
      host="127.0.0.1",
      port=port,
      period=0,
    )
    self.start_emulator_or_skip(emulator)
    client = self.create_tcp_client(port)

    try:
      input_raw = modbus.read_modbus_registers(
        client=client,
        address=30001,
        register_type="input",
        count=2,
        data_type="RAW",
        device_id=7,
      )
      self.assertEqual(input_raw["registers"], [10, 20])

      input_typed = modbus.read_modbus_registers(
        client=client,
        address=30010,
        register_type="input",
        data_type="U16",
        factor=0.1,
        device_id=7,
      )
      self.assertEqual(input_typed["value"], 12.3)

      holding_raw = modbus.read_modbus_registers(
        client=client,
        address=40001,
        register_type="holding",
        count=2,
        data_type="RAW",
        device_id=7,
      )
      self.assertEqual(holding_raw["registers"], [1, 2])

      holding_typed = modbus.read_modbus_registers(
        client=client,
        address=40010,
        register_type="holding",
        data_type="U16",
        factor=0.1,
        device_id=7,
      )
      self.assertEqual(holding_typed["value"], 45.6)

      write_single = modbus.write_modbus_registers(
        client=client,
        address=40010,
        value=78.9,
        data_type="U16",
        factor=0.1,
        device_id=7,
      )
      self.assertEqual(write_single["registers"], [789])

      read_single = modbus.read_modbus_registers(
        client=client,
        address=40010,
        register_type="holding",
        data_type="U16",
        factor=0.1,
        device_id=7,
      )
      self.assertEqual(read_single["value"], 78.9)

      write_multi = modbus.write_modbus_registers(
        client=client,
        address=40020,
        value=[7, 8, 9],
        data_type="RAW",
        device_id=7,
      )
      self.assertEqual(write_multi["registers"], [7, 8, 9])

      read_multi = modbus.read_modbus_registers(
        client=client,
        address=40020,
        register_type="holding",
        count=3,
        data_type="RAW",
        device_id=7,
      )
      self.assertEqual(read_multi["registers"], [7, 8, 9])
    finally:
      client.close()
      emulator.stop_server()


class TestCliAliases(unittest.TestCase):
  def test_cli_accepts_generic_argument_names(self):
    captured = {}

    def fake_execute(command, args):
      captured["command"] = command
      captured["proto"] = args.proto
      captured["transport"] = args.transport
      captured["serial_port"] = args.serial_port
      captured["framer"] = args.framer
      captured["device_id"] = args.device_id
      captured["register_type"] = args.register_type
      captured["data_type"] = args.data_type
      captured["handle_local_echo"] = args.handle_local_echo
      return {"status": "ok"}

    argv = [
      "sciveo",
      "read",
      "--proto", "modbus",
      "--transport", "serial",
      "--serial-port", "/dev/ttyUSB0",
      "--mode", "rtu",
      "--id", "1",
      "--kind", "holding",
      "--type", "U16",
      "--address", "5039",
      "--local-echo",
    ]

    with patch.object(sys, "argv", argv):
      with patch("sciveo.cli.GlobalConfiguration.get", return_value=FakeConfig()):
        with patch("sciveo.network.modbus.execute_modbus_command", side_effect=fake_execute):
          with patch("builtins.print"):
            cli.main()

    self.assertEqual(captured, {
      "command": "read",
      "proto": "modbus",
      "transport": "serial",
      "serial_port": "/dev/ttyUSB0",
      "framer": "rtu",
      "device_id": 1,
      "register_type": "holding",
      "data_type": "U16",
      "handle_local_echo": True,
    })

  def test_cli_emulate_dispatches_modbus_server(self):
    captured = {}

    def fake_run(args):
      captured["server"] = args.server
      captured["profile"] = args.profile
      captured["port"] = args.port

    argv = [
      "sciveo",
      "emulate",
      "--server", "modbus",
    ]

    with patch.object(sys, "argv", argv):
      with patch("sciveo.cli.GlobalConfiguration.get", return_value=FakeConfig()):
        with patch("sciveo.network.modbus.run_modbus_emulator", side_effect=fake_run):
          cli.main()

    self.assertEqual(captured, {
      "server": "modbus",
      "profile": "ems300",
      "port": 1502,
    })


if __name__ == "__main__":
  unittest.main()
