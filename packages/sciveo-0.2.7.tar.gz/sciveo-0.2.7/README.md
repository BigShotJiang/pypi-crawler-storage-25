# SCIVEO - ML/AI and Scientific tools

## Monitoring ML Infrastructure
sciveo monitoring of (ML) machines' CPU/RAM/GPU/NET/DISK/TEMP etc.
It is very easy to start and use with a single command line.

 - **Monitoring** of current machine with sampling period of 60 seconds
```shell
sciveo monitor --period 60
```
 - **Monitoring** of current machine, logging the samples to local file (in this case the ./sciveo_monitor.json default name when dir path is used)
```shell
sciveo monitor --period 120 --output-path ./
```

The monitor client is sendind the monitored samples to remote [sciveo](https://sciveo.com) api (init config located in ~/.sciveo/)

### Watchdog monitoring with action
 - **Memory usage** watchdog for 90% max memory, measure every 10 seconds and execute "<some command to handle the high memory event>"
```shell
sciveo watchdog --src memory --threshold 90 --period 10 --execute "<some command to handle the high memory event>"
```
 - **Disk usage** watchdog for 80% max disk usage on /some/path/to/watch path, measure every 600 seconds and execute "<some command to handle the high disk usage event>".
```shell
sciveo watchdog --src disk --input-path "/some/path/to/watch" --threshold 80 --period 600 --execute "find /some/path/to/watch -type f -mtime +1"
```


## Network tools

 - **Network Scan** Networks of hosts to scan for a single port
 ```shell
sciveo scan --port 22

sciveo scan --net 192.168.0.0/24 --port 22 --timeout 0.5
```

- **Network Scan** Single Host list of ports to scan
```shell
sciveo scan --host 192.168.0.10

sciveo scan --host 192.168.0.10 --ports [443,80]
```

- **Modbus Read** Holding or input registers over TCP
```shell
sciveo read --proto modbus --transport tcp --host 192.168.0.10 --port 502 --id 1 --address 30001 --kind input --type RAW --count 2

sciveo read --proto modbus --transport serial --serial-port /dev/ttyUSB0 --baudrate 9600 --bytesize 8 --parity N --stopbits 1 --id 1 --reg '[5039, "U16", 0.1, 1]'
```

- **Modbus Write** Holding registers over TCP or serial
```shell
sciveo write --proto modbus --transport tcp --host 192.168.0.10 --id 1 --reg '[40010, "U16", 1, 1]' --value 123

sciveo write --proto modbus --transport serial --serial-port /dev/ttyUSB0 --baudrate 9600 --bytesize 8 --parity N --stopbits 1 --id 1 --address 10 --type RAW --value "[1,2]"
```

`--reg` accepts a compact value spec like `[address, type, factor, count]`.
`--proto` currently defaults to `modbus`.

- **Modbus Emulate** Run a Modbus TCP emulator with a bundled profile or a custom profile override
```shell
sciveo emulate --server modbus --profile ems300 --host 0.0.0.0 --port 1502

sciveo emulate --server modbus --profile custom --host 0.0.0.0 --port 1502 --data-json '{"device_id": 7, "input": {"30001": [10, 20]}, "holding": {"40010": 123}}'
```

`--profile ems300` starts the bundled EMS300 preset.
Other bundled profiles include `logger1000-sg` for Sungrow Logger1000 and `logger1000-hw` for Huawei SmartLogger1000.
`--host 0.0.0.0` binds the emulator on all interfaces; use `127.0.0.1` for local-only testing.
`--data-json` can supply or override emulator register data using external register numbers.

## Agent console

- **Agent REPL** Start a local coding-agent console with basic tools like `bash`, `read_file`, `write_file`, `list_dir`, and `pwd`
```shell
sciveo agent --provider auto

OPENAI_API_KEY=<your-api-key> sciveo agent
```

- **Agent one-shot** Run a single prompt instead of opening the REPL
```shell
sciveo agent --provider auto --prompt "List the repo root and summarize the important files"

OPENAI_API_KEY=<your-api-key> sciveo agent --model gpt-5.4-mini --prompt "Summarize the latest changes in this repo"
```

- **Image input** Attach a local image path or base64 image to the next agent prompt. In the REPL, attachments are one-turn only.
```shell
sciveo agent --provider openai --prompt "Describe this image" --input-path ./screenshot.png
sciveo agent --provider hf --prompt "What is visible here?" --data-json '{"images":[{"path":"./screenshot.png"}]}'
sciveo agent --provider gemini --prompt "Read this chart" --data-json '{"images":[{"data":"data:image/png;base64,...","name":"chart.png"}]}'
```

Inside the REPL:
```text
/image ./screenshot.png
/image-data image/png iVBORw0KGgo...
/images
/image-clear
```

`openai` is now the default agent provider when `OPENAI_API_KEY` is configured, with `gpt-5.4` as the default model.
Install agent providers with the `agent` extra, for example `pip install "sciveo[agent]"`.
Install the owned local Hugging Face runtime with `pip install "sciveo[agent-local]"`.

- **Owned local Hugging Face runtime** Pull a model snapshot from Hugging Face, run the Sciveo local runtime server, then connect the agent console to it
```shell
sciveo agent --action pull --model Qwen/Qwen2.5-Coder-3B-Instruct --alias qwen-coder-3b
sciveo agent --action run --model qwen-coder-3b --host 127.0.0.1 --port 8910 --device mps --context 8192
sciveo agent --provider hf --prompt "Say hello in one sentence"
sciveo agent --provider hf --mode batch --prompt "Say hello in one sentence"
```

For GGUF repositories with many quantized files, use `--file` to pull only one model file:
```shell
sciveo agent --action pull --model unsloth/Qwen3.5-4B-GGUF --file Qwen3.5-4B-Q4_K_M.gguf --alias qwen3.5-4b-q4
```

For GGUF vision models, also pull the matching projector file:
```shell
sciveo agent --action pull \
  --model some/vlm-gguf \
  --file model-Q4_K_M.gguf \
  --data-json '{"mmproj_file":"mmproj-model.gguf"}' \
  --alias vlm-q4
```

`--provider local` is an alias for `hf`. `--provider ollama` and `--provider olama` are supported as explicit compatibility providers, but `--provider auto` remains API-key based and does not probe local runtimes.
Use `--url`, or `--host` with `--port`, to point `hf`, `ollama`, or OpenAI-compatible endpoints at a specific server.
The HF runtime streams live output by default; use `--mode batch` for the previous request/response style.
Use `--device cpu`, `--device mps`, `--device cuda`, or `--device auto` on `agent --action run` to choose where the local model runs.
Use `--context` on `agent --action run` to choose the llama.cpp context size for GGUF models; larger values use more memory.
GGUF model snapshots are supported through `llama-cpp-python`; on Apple Silicon, `--device mps` requests llama.cpp Metal acceleration when the installed llama.cpp backend supports it.

## Remote network video recorder

 - **NVR** RTSP cams video recorder
 ```shell
sciveo nvr --input-path cams.json
```

where cams.json has the cam and nvr configuration like
```json
{
  "video_retention_period": 5,
  "max_video_len": 60,
  "transport": "tcp",
  "path": {
    "tmp": "tmp/nvr/tmp",
    "video": "tmp/nvr/video"
  },
  "cam": {
    "cam_livingroom": {
      "url": "rtsp://192.168.1.11/stream1"
    },
    "cam_kitchen": {
      "url": "rtsp://rtsp://192.168.1.12"
    }
  }
}
```


## Media pipelines processing worker
 - **Media Pipelines processing** service
 ```shell
sciveo media-server
```


## Experiments Management Client
`sciveo` is a Python library that serves as a client for managing machine learning and scientific experiments on the sciveo.com platform. This library provides a convenient interface to interact with the sciveo.com API, enabling users to organize, track, and analyze their experiments efficiently.
There are few configuration params samplers, which allows easy parameter tuning. The "auto" sampler perhaps is the easiest to use, but also
"random" and "grid" ones are available.

#### Features

- **Experiment Tracking:** Easily log and track your machine learning experiments.
- **Experiment Comparison:** Compare different experiments and their results.
- **Data Visualization:** Visualize experiment metrics and results.
- **Integration with sciveo.com:** Seamlessly connect and synchronize with the sciveo.com platform.
- **Monitoring machines (from HPC to jetson nano):** Visualisation and metrics collection in sciveo platform.


## Installation

 - main sciveo
pip install sciveo

 - optional for sciveo monitoring
pip install sciveo[mon]
 - optional for sciveo network tools
pip install sciveo[net]
   includes `netifaces`, `scapy`, and `pymodbus`
 - for full installation, without media and ML support
pip install sciveo[all]

 - for media (images/video/audio/text)
pip install sciveo[media]
 - for media with ML processors
pip install sciveo[media-ml]


## Example usage

There are few public examples in sciveo.com.

The library has local and remote mode. The local one is ready to use, but for the remote one you will need a sciveo.com account.

When have sciveo account:
```shell
sciveo init
```
Where ~/.sciveo/ path and ~/.sciveo/default file will be created. Just need to change the secret_access_key value.

or
```shell
export SCIVEO_SECRET_ACCESS_KEY='my_sciveo_user_auth_token'
```
or create a file like ~/.sciveo/some_file_name where put:
secret_access_key=my_sciveo_user_auth_token

Sciveo Monitoring cli
```shell
sciveo monitor --period 120
```

Monitoring started along with other python code.
```python
import sciveo

# Non blocking monitoring, so continue the code execution after it.
sciveo.monitor(period=120, block=False)

#rest of your python code here

```


Experimental Projects management

```python

# These are experiment specific imports for the demo purposes only.
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score, mean_absolute_percentage_error
from ml.time_series import TimeSeriesTrainer, TimeSeriesPredictor

# This is the only needed import when using sciveo along with the experiment-related imports
import sciveo

def train():
    # sciveo.open() method returns current Experiment object, with its configuration sample
    with sciveo.open() as E:
        # Just an example time series trainer (using TF/Keras simple 1D conv model).
        trainer = TimeSeriesTrainer(
            ds,
            E.config.input_window, # Experiment.config is the configuration, so input_window as hyper parameter.
            E.config.input_window,
            E.config.steps # steps parameter.
        )
        trainer.create()

        history = trainer.train(E.config.max_epochs, E.config.patience)
        trainer_eval = trainer.evaluate()

        model_name, model_path = trainer.save("model-name-path.timeseries")

        # Experiment logging for everything which seems interesting for the experiment.
        E.log({"model_path": model_path})

        E.log({"train history": history.history})
        E.log({"trainer_eval": trainer_eval})

        # Plot data, various input types (dict, list etc.).
        # Showing data as charts (single and combined) and tables.
        # There is a more advanced render option which could be used for tables, charts definition.
        E.plot("train history", history.history)

        predictor = TimeSeriesPredictor(model_path)
        Y_predicted, Y_valid, x = predict_chunk(ds.dataset["test"], predictor)

        # Plot predicted and labeled
        for i, col_name in enumerate(ds.columns):
            y_predicted = Y_predicted[0,:,i].numpy().tolist()
            y_valid     = Y_valid[0,:,i].numpy().tolist()

            # Could provide x column for the plot, there are multiple options like timestamps etc.
            # The "X" is reserved for x column name, if not present default range [1, N]
            E.plot(col_name, { "predicted": y_predicted, "label": y_valid, "X": x })

        mse = mean_squared_error(y_valid, predictions)
        mae = mean_absolute_error(y_valid, predictions)
        rmse = np.sqrt(mean_squared_error(y_valid, predictions))
        r2 = r2_score(y_valid, predictions)
        mape = mean_absolute_percentage_error(y_valid, predictions)

        E.log({"R2": r2})
        E.log(f"RMSE: {rmse}")
        E.log("MAPE", mape)
        E.log("R2", r2, "RMSE", rmse, "MAPE", mape)

        # There is a sorting option for the Project's experiments
        # By default it is "score", so there is a method Experiment.score() which could be used for experiments evaluation.
        E.score(100 - mape)
        # There is explicit Experiment "eval" section where all available evaluation metrics could be logged.
        E.eval("R2", r2)
        E.eval("RMSE", rmse)
        E.eval("MAPE", mape)


# Configuration of the Project's experiments run.
configuration = {
    "input_window": {
        "values": [10, 20, 30, 40, 50, 100, 200] # "values" option provides selection from a list of values.
    },
    "steps": {
        # "min"/"max" is a range of values where sampling will get next value.
        # It is int/float sensitive, so if range is [1, 100], the sampled value will be integer.
        # If range is [1.0, 100.0], sampling float values.
        "min": 1, "max": 100
    },
    "max_epochs": (10, 50), # Same range of values but using a tuple (min, max).
    "patience": (1, 3),
    "idx": {
        "seq": 1 # Sequence sampling, so just increase it on every run, could be used as experiment index.
    }
}

# Dataset info
sciveo.dataset({"name": "EURUSD60.csv", "split": ds.ratios}) # any dict with params.

# sciveo.start() method starts the Project's experiments run.
sciveo.start(
    project="TimeSeriesTrainer param tune", # Project name, could be existing or a new one.
    configuration=configuration, # The hyper param configuration
    function=train, # Function which will be executed on every loop.
    remote=True, # There are 2 modes: local and remote. For remote option there is a need of sciveo.com authentication.
    count=20, # Number of experiments which will be run.
    sampler="random" # Configuration sampling method, options currently are "random" (by default), "grid" and "auto".
)

```




### Who do I talk to? ###

* Pavlin Georgiev
* pavlin@softel.bg
