# FILE:    ENCRYPTION_SERVICE.py
# PURPOSE: AES-256-CTR encryption and decryption utilities with deterministic IV generation.
# GOAL:    Provide encrypt / decrypt functions for strings and JSON fields.
# RUNS TO: Aes256CtrEncryption (class namespace — public API entry points are encrypt,
#          decrypt, and decrypt_json_field)
#
# ┌────────────────────────────────────────────────────────────────────────────────┐
# │ PERFORMANCE TEST RESULTS (10 RUN AVERAGE)                                      │
# ├──────────────────────┬──────────┬──────────┬─────────────┬──────────┬──────────┤
# │ Test                 │ Ops      │ Time     │ Throughput  │ Target   │ Status   │
# ├──────────────────────┼──────────┼──────────┼─────────────┼──────────┼──────────┤
# │ Encrypt (1-thread)   │  1,000   │ 0.038 s  │ 26,253/sec  │ 10k/sec  │ ✅ PASS  │
# │ Decrypt (1-thread)   │  1,000   │ 0.028 s  │ 35,920/sec  │ 10k/sec  │ ✅ PASS  │
# │ Round-trip           │    100   │ 0.058 ms │    avg/call │  < 1 ms  │ ✅ PASS  │
# │ JSON field decrypt   │    500   │ 0.014 s  │ 37,171/sec  │ 10k/sec  │ ✅ PASS  │
# │ Encrypt (4-thread)   │  1,000   │ 0.092 s  │ 11,052/sec  │ 10k/sec  │ ✅ PASS  │
# │ Encrypt (8-thread)   │  2,000   │ 0.197 s  │ 10,163/sec  │ 10k/sec  │ ✅ PASS  │
# └──────────────────────┴──────────┴──────────┴─────────────┴──────────┴──────────┘
# SYSTEM: Ubuntu 24.04.4 LTS | AMD Ryzen 7 5800H (16 cores, 13Gi RAM) | Python 3.12.3
# NOTE:   Multi-thread throughput limited by Python GIL — AES-CTR is CPU-bound;
#         threading does not provide linear scaling. Use multiprocessing for CPU-bound crypto.
# TESTED: 2026-04-03T16:56:48Z

# ═══════════════════════════════════════════════════════════════════════════════
# KEY FEATURES & DESIGN DECISIONS
# ═══════════════════════════════════════════════════════════════════════════════
#
# 1. Deterministic IV
#    - IV = SHA-256(plaintext || key)[:16] — same input always produces same ciphertext.
#    - WHY: Required to interoperate with the Rust sibling implementation that uses the
#           same deterministic IV scheme; a random IV would break cross-language decryption.
#
# 2. Key Derivation via SHA-256 (not PBKDF2/scrypt/argon2)
#    - ENCRYPTION_KEY passphrase is hashed with SHA-256 to produce the 256-bit AES key.
#    - WHY: Matches the Rust implementation's derive_key contract; changing to a KDF
#           would invalidate all existing ciphertexts.
#    - SECURITY NOTE: Because SHA-256 is fast, a low-entropy passphrase is vulnerable
#      to brute-force. ENCRYPTION_KEY MUST be a high-entropy secret (≥ 32 bytes,
#      randomly generated) — never a human-chosen password. A runtime warning fires
#      at import time if the key is shorter than 32 bytes.
#
# 3. No OOP State — class used as a namespace only
#    - Aes256CtrEncryption holds only @staticmethod functions; no __init__, no self.
#    - WHY: Class is used purely to group related functions under a discoverable name
#           and to preserve the public API surface expected by callers; it carries no
#           mutable state and all methods are independently testable without mocking.
#    - RULE OVERRIDE: §PYTHON no-oop — Aes256CtrEncryption uses the class keyword as a
#      pure namespace (all @staticmethod, no __init__, no instance state, no inheritance).
#      Restore when: callers are migrated to bare module-level function imports.
#
# 4. simple_retry Wraps Every Cryptographic Call
#    - WHY: Cryptographic backends (OpenSSL via cryptography library) can fail transiently
#           under memory pressure; retry guards against spurious backend errors without
#           masking real bugs (3 attempts, 1 s delay, all exceptions retryable here because
#           the domain has no 4xx-equivalent for local crypto ops).
#
# ═══════════════════════════════════════════════════════════════════════════════
#
# SECTION MAP:
#   SECTION 1 · ENVIRONMENT SETUP     — load env vars and validate required config
#   SECTION 2 · RETRY MECHANISM       — simple_retry helper for transient failures
#   SECTION 3 · KEY + IV DERIVATION   — pure cryptographic helpers (no IO)
#   SECTION 4 · ENCRYPTION UTILITIES  — Aes256CtrEncryption public API
#   SECTION 5 · PERFORMANCE TEST      — run_performance_test() live benchmark

# ═══════════════════════════════════════════════════════════════════════════════
# QUICK START
# ═══════════════════════════════════════════════════════════════════════════════
#
# Set environment variables in .env:
#   ENCRYPTION_KEY=your-secret-phrase   # MUST be ≥ 32 bytes, cryptographically random
#
# Import and use:
#   from ENCRYPTION_SERVICE import Aes256CtrEncryption
#
#   # Encrypt plaintext to base64
#   token = Aes256CtrEncryption.encrypt("s3cr3t")   # → "XXXXX..."
#
#   # Decrypt back to plaintext
#   plain = Aes256CtrEncryption.decrypt(token)      # → "s3cr3t"
#
#   # Decrypt a nested field in JSON
#   payload = {"db": {"pass": Aes256CtrEncryption.encrypt("hunter2")}}
#   pw = Aes256CtrEncryption.decrypt_json_field(payload, "db.pass")  # → "hunter2"
#
# ⚠️  SECURITY: ENCRYPTION_KEY must be ≥ 32 bytes of cryptographically random data.
#     Never use a human-chosen password. A warning fires at import if key is too short.
#
# ═══════════════════════════════════════════════════════════════════════════════
# ═══════════════════════════════════════════════════════════════════════════════

# ── IMPORTS ──────────────────────────────────────────────────────────────────
# Three groups: stdlib · third-party · internal

from __future__ import annotations

# ── stdlib ──────────────────────────────────────────────────────────────────
import base64
import binascii
import os
import threading
import time
import warnings
from typing import Any, Callable, TypeVar

# ── third-party ─────────────────────────────────────────────────────────────
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from dotenv import load_dotenv

# ── Test-only import (guarded for non-test environments) ────────────────────
try:
    import pytest
except ImportError:
    pytest = None

# ── Type variable for simple_retry generic return ────────────────────────────
T = TypeVar("T")

__all__ = ["Aes256CtrEncryption", "run_performance_test"]

# ── SECTION 1 · ENVIRONMENT SETUP ───────────────────────────────────────────
# Goal: Load and validate required environment variables before any crypto op.

load_dotenv()

ENCRYPTION_KEY: str = os.environ.get("ENCRYPTION_KEY", "")
# WHY: ENCRYPTION_KEY is required — all encrypt/decrypt ops are meaningless without it;
#      fail at import rather than at first call to avoid half-encrypted state.
if not ENCRYPTION_KEY:
    raise ValueError("ENCRYPTION_KEY environment variable not found")

# WHY: SHA-256 key derivation provides no brute-force resistance, so the
#      passphrase itself must supply the entropy. A key shorter than 32 bytes
#      materially reduces the effective key space; warn loudly so operators
#      catch misconfiguration in staging before it reaches production.
#      This is a warning (not an error) because existing deployments with
#      shorter keys must still be able to start and decrypt their data.
#      NOTE: Length is a proxy for entropy, not a guarantee — a 32-byte
#      all-zero key would pass this check but still be insecure. Always use
#      a cryptographically random secret, never a human-chosen password.
#
#      Python's default warning filter already deduplicates per
#      (message, category, module, lineno) — the same call site will not
#      fire twice in one process under normal usage. Passing stacklevel=2
#      attributes the warning to the importer's file rather than this
#      module, which is the correct location for operators to investigate.
_MINIMUM_KEY_BYTES = 32
if len(ENCRYPTION_KEY.encode("utf-8")) < _MINIMUM_KEY_BYTES:
    warnings.warn(
        f"ENCRYPTION_KEY is shorter than {_MINIMUM_KEY_BYTES} bytes. "
        "Because AES key derivation uses raw SHA-256 (no KDF), the key must "
        "supply all entropy itself. Use a cryptographically random secret of "
        f"at least {_MINIMUM_KEY_BYTES} bytes.",
        UserWarning,
        stacklevel=2,
    )


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestImportValidation:
        """WHY: Import-time guards are the only barrier between a misconfigured environment
        and silent operation with no key or wrong directory — a missed guard means every
        encrypt/decrypt call silently uses empty or wrong credentials."""

        def test_import_validation(self) -> None:
            import subprocess

            shared_lib_dir = os.path.dirname(os.path.abspath(__file__))

            # ── missing ENCRYPTION_KEY raises ValueError at import ────────────────
            env = os.environ.copy()
            env.pop("ENCRYPTION_KEY", None)
            env["PYTHONPATH"] = shared_lib_dir
            result = subprocess.run(
                ["python3", "-c", "import ENCRYPTION_SERVICE"],
                capture_output=True,
                text=True,
                env=env,
                cwd="/tmp",
            )
            assert result.returncode != 0, (
                f"Expected non-zero returncode, got {result.returncode}"
            )
            assert "ENCRYPTION_KEY" in result.stderr, (
                f"Expected 'ENCRYPTION_KEY' in stderr, got: {result.stderr}"
            )

            # ── key shorter than 32 bytes emits UserWarning at import ─────────────
            env = os.environ.copy()
            env["ENCRYPTION_KEY"] = "short"
            env["PYTHONPATH"] = shared_lib_dir
            result = subprocess.run(
                ["python3", "-W", "all", "-c", "import ENCRYPTION_SERVICE"],
                capture_output=True,
                text=True,
                env=env,
                cwd="/tmp",
            )
            assert result.returncode == 0, (
                f"Expected returncode 0, got {result.returncode}: {result.stderr}"
            )
            assert (
                "shorter than 32 bytes" in result.stderr
                or "ENCRYPTION_KEY" in result.stderr
            ), f"Expected key length warning in stderr, got: {result.stderr}"


# ── SECTION 2 · RETRY MECHANISM ─────────────────────────────────────────────
# Goal: Provide a reusable retry helper for transient cryptographic backend failures.


def simple_retry(func: Callable[[], T], max_attempts: int = 3, delay: float = 1.0) -> T:
    """
    [TIER 2] Provides a reusable retry helper for transient cryptographic backend failures.
    WHY: Cryptographic backend calls (OpenSSL via cryptography lib) can fail
    transiently under memory pressure; three attempts with a 1 s pause recovers
    from spikes without hiding real bugs.

    Retry policy: DOMAIN_RULES.md § RETRY — max 3 attempts, all exceptions
    retryable (local crypto has no 4xx-equivalent), 1 s fixed delay.
    """
    # WHY: Iterating up to max_attempts lets us distinguish last attempt (re-raise)
    #      from earlier attempts (sleep and retry) without a separate counter variable.
    for attempt in range(max_attempts):
        try:
            return func()
        except Exception as e:
            # WHY: Exception (not bare except) — catches all non-system-exit errors;
            #      local crypto ops have no 4xx-equivalent, so all exceptions are
            #      treated as transient retryable failures per DOMAIN_RULES retry policy.
            if attempt == max_attempts - 1:
                raise  # WHY: Re-raise original exception on final attempt — preserve traceback
            time.sleep(delay)
    raise RuntimeError(
        "simple_retry: all attempts exhausted — this line should be unreachable"
    )


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestSimpleRetry:
        """WHY: simple_retry is the only resilience layer for every cryptographic call —
        if it stops retrying on any exception type, a single transient backend failure
        surfaces as a data-loss event to the caller with no recovery path."""

        def test_simple_retry(self) -> None:
            assert pytest is not None  # Type guard for pyright
            # ── success on first attempt — no unnecessary delays ──────────────────
            call_count = 0

            def succeed_immediately() -> int:
                nonlocal call_count
                call_count += 1
                return 42

            result = simple_retry(succeed_immediately, max_attempts=3, delay=0.01)
            assert result == 42, f"Expected 42, got {result}"
            assert call_count == 1, f"Expected 1 call, got {call_count}"

            # ── success on third attempt — retries continue before exhaustion ──────
            call_count = 0

            def fail_twice_then_succeed() -> int:
                nonlocal call_count
                call_count += 1
                if call_count < 3:
                    raise RuntimeError("temporary failure")
                return 42

            result = simple_retry(fail_twice_then_succeed, max_attempts=3, delay=0.01)
            assert result == 42, f"Expected 42, got {result}"
            assert call_count == 3, f"Expected 3 calls, got {call_count}"

            # ── exhaustion propagates original exception ───────────────────────────
            call_count = 0

            def always_fail() -> int:
                nonlocal call_count
                call_count += 1
                raise RuntimeError("persistent failure")

            with pytest.raises(RuntimeError, match="persistent failure"):
                simple_retry(always_fail, max_attempts=3, delay=0.01)
            assert call_count == 3, f"Expected 3 calls, got {call_count}"

            # ── any exception type is retried (no 4xx-equivalent for local crypto) ─
            call_count = 0

            def raise_various_exceptions() -> str:
                nonlocal call_count
                call_count += 1
                if call_count == 1:
                    raise ValueError("not a crypto error")
                if call_count == 2:
                    raise TypeError("also not crypto")
                return "success"

            result = simple_retry(raise_various_exceptions, max_attempts=3, delay=0.01)
            assert result == "success", f"Expected 'success', got {result}"
            assert call_count == 3, f"Expected 3 calls, got {call_count}"


# ── SECTION 3 · KEY + IV DERIVATION ─────────────────────────────────────────
# Goal: Pure cryptographic helpers that derive key and IV from password and plaintext.


def _derive_256bit_key(password: str) -> bytes:
    """
    [TIER 2] Derives a deterministic 256-bit key from a password using SHA-256.
    WHY: SHA-256 over the passphrase produces a deterministic 256-bit key that
    matches the Rust sibling implementation's derive_key function exactly.
    Changing algorithm would invalidate all existing ciphertexts.
    """

    def _derive() -> bytes:
        digest = hashes.Hash(hashes.SHA256(), backend=default_backend())
        digest.update(password.encode("utf-8"))
        return digest.finalize()

    return simple_retry(_derive)


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestDeriveKey:
        """WHY: _derive_256bit_key is the foundation of every encryption and decryption
        op — a wrong length breaks AES-256, a non-deterministic result breaks Rust
        interop, and a collision between passwords breaks the security guarantee entirely."""

        def test_derive_256bit_key(self) -> None:
            # ── returns exactly 32 bytes (256-bit AES key requirement) ───────────
            key = _derive_256bit_key("test_password")
            assert isinstance(key, bytes), f"Expected bytes, got {type(key).__name__}"
            assert len(key) == 32, f"Expected 32 bytes, got {len(key)}"

            # ── deterministic: same password → same key ───────────────────────────
            assert _derive_256bit_key("my_secret_passphrase") == _derive_256bit_key(
                "my_secret_passphrase"
            ), "Same password must produce same key"

            # ── different passwords produce different keys ─────────────────────────
            assert _derive_256bit_key("password_one") != _derive_256bit_key(
                "password_two"
            ), "Different passwords must produce different keys"


def _generate_deterministic_iv(key: bytes, plaintext: str) -> bytes:
    """
    [TIER 2] Generates a deterministic 16-byte IV from key and plaintext.
    WHY: IV = SHA-256(plaintext || key)[:16] matches the Rust implementation's
    generate_deterministic_iv contract; same inputs always yield same ciphertext,
    which is required for cross-language interoperability.

    Security note: deterministic IV means identical plaintexts produce identical
    ciphertexts — acceptable here because the IV embeds the key, making collision
    analysis equivalent to breaking SHA-256 preimage resistance.
    """

    def _generate() -> bytes:
        iv_digest = hashes.Hash(hashes.SHA256(), backend=default_backend())
        iv_digest.update(plaintext.encode("utf-8"))
        iv_digest.update(key)
        return iv_digest.finalize()[
            :16
        ]  # WHY: AES-CTR requires a 16-byte (128-bit) nonce

    return simple_retry(_generate)


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestGenerateIV:
        """WHY: _generate_deterministic_iv is the cross-language interop contract —
        a non-deterministic IV breaks Rust decryption of Python ciphertexts, and a
        wrong size (not 16 bytes) causes an AES-CTR nonce error at cipher construction."""

        def test_generate_deterministic_iv(self) -> None:
            key = _derive_256bit_key("test_key")

            # ── returns exactly 16 bytes (AES-CTR 128-bit nonce requirement) ──────
            iv = _generate_deterministic_iv(key, "plaintext")
            assert isinstance(iv, bytes), f"Expected bytes, got {type(iv).__name__}"
            assert len(iv) == 16, f"Expected 16 bytes, got {len(iv)}"

            # ── deterministic: same key + plaintext → same IV ─────────────────────
            assert _generate_deterministic_iv(
                key, "hello"
            ) == _generate_deterministic_iv(key, "hello"), (
                "Same key+plaintext must produce same IV"
            )

            # ── different plaintexts produce different IVs ────────────────────────
            assert _generate_deterministic_iv(
                key, "hello"
            ) != _generate_deterministic_iv(key, "world"), (
                "Different plaintexts must produce different IVs"
            )


# ── SECTION 4 · ENCRYPTION UTILITIES ────────────────────────────────────────
# Goal: Expose encrypt, decrypt, and decrypt_json_field as the public API.


class Aes256CtrEncryption:
    """
    WHY: Groups AES-256-CTR encrypt/decrypt functions under a single discoverable
    name that matches the cross-language API contract (Rust sibling uses the same
    class name). All methods are @staticmethod — no instance state, no __init__.

    RULE OVERRIDE: §PYTHON no-oop — pure namespace class, see KEY FEATURES § 3.
    Restore when: callers are migrated to bare module-level function imports.
    """

    @staticmethod
    def encrypt(plaintext: str) -> str:
        """
        [TIER 1] Encrypts arbitrary plaintext to a base64 string.
        WHY: Encrypts arbitrary plaintext to a base64 string that is safe to store
        in JSON fields, environment variables, and database columns.

        Returns base64(IV || ciphertext) — the IV prefix is required by decrypt.
        """

        def _perform_encryption() -> str:
            key = _derive_256bit_key(ENCRYPTION_KEY)
            iv = _generate_deterministic_iv(key, plaintext)
            cipher = Cipher(
                algorithms.AES(key), modes.CTR(iv), backend=default_backend()
            )
            encryptor = cipher.encryptor()
            ciphertext = (
                encryptor.update(plaintext.encode("utf-8")) + encryptor.finalize()
            )
            encrypted_data = (
                iv + ciphertext
            )  # WHY: IV prepended so decrypt can extract it without side-channel
            return base64.b64encode(encrypted_data).decode("utf-8")

        return simple_retry(_perform_encryption)

    @staticmethod
    def decrypt(encoded_ciphertext: str) -> str:
        """
        [TIER 1] Decrypts base64-encoded ciphertext back to plaintext.
        WHY: Reverses encrypt — decodes base64, splits IV from ciphertext, and
        recovers the original plaintext using AES-256-CTR with the same derived key.

        Raises ValueError if the encoded_ciphertext is shorter than 16 bytes
        (i.e. it cannot contain a valid IV prefix).
        """

        def _perform_decryption() -> str:
            key = _derive_256bit_key(ENCRYPTION_KEY)
            encrypted_data = base64.b64decode(encoded_ciphertext)
            if len(encrypted_data) < 16:
                # WHY: Fewer than 16 bytes means the IV is truncated — decryption
                #      would produce garbage silently; fail explicitly instead.
                raise ValueError("Invalid encrypted data format (too short)")
            iv, ciphertext = encrypted_data[:16], encrypted_data[16:]
            cipher = Cipher(
                algorithms.AES(key), modes.CTR(iv), backend=default_backend()
            )
            decryptor = cipher.decryptor()
            return (decryptor.update(ciphertext) + decryptor.finalize()).decode("utf-8")

        return simple_retry(_perform_decryption)

    @staticmethod
    def decrypt_json_field(encrypted_json: dict[str, Any], json_path: str) -> str:
        """
        [TIER 1] Decrypts a single nested field in a JSON object.
        WHY: Allows callers to decrypt a single nested field using dot-notation path
        (e.g. "user.credentials.password") without writing their own traversal logic.
        Raises ValueError on invalid paths so callers get a clear error rather than
        a cryptic KeyError.
        """

        def _get_nested_field() -> str:
            # WHY: Return type is str (not Any) — this function's sole purpose is to
            #      extract a leaf value that decrypt expects to be a string. Typing it
            #      as Any would hide misuse (e.g. passing a dict path that resolves to
            #      a nested object instead of an encrypted string).
            current_value: Any = encrypted_json
            for part in json_path.split("."):
                if not isinstance(current_value, dict) or part not in current_value:
                    raise ValueError(f"Invalid JSON path: {json_path!r}")
                current_value = current_value[part]
            if not isinstance(current_value, str):
                # WHY: A non-string leaf means the path resolved to a nested dict or
                #      other type — decrypt would raise a confusing error deep inside
                #      base64 decoding; surface it here with a clear message instead.
                raise ValueError(
                    f"JSON path {json_path!r} resolved to {type(current_value).__name__!r}, "
                    "expected str (encrypted value)"
                )
            return current_value

        encrypted_value: str = _get_nested_field()
        return Aes256CtrEncryption.decrypt(encrypted_value)


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestEncrypt:
        """WHY: encrypt is the entry point for all data protection — if it produces
        non-deterministic output, cross-language decryption breaks; if it returns an
        invalid base64 shape, every downstream store and retrieve silently corrupts data."""

        def test_encrypt(self) -> None:
            # ── returns non-empty base64 string ───────────────────────────────────
            result = Aes256CtrEncryption.encrypt("hello")
            assert isinstance(result, str) and len(result) > 0, (
                f"Expected non-empty str, got {result!r}"
            )

            # ── deterministic: same input → same ciphertext ───────────────────────
            # WHY == here: verifying determinism is a property test, not a secret-comparison.
            # In production code, NEVER compare encrypted tokens with == —
            # use hmac.compare_digest(a, b) to prevent timing-oracle attacks.
            assert result == Aes256CtrEncryption.encrypt("hello"), (
                "Same input must produce same ciphertext (deterministic)"
            )

            # ── different inputs produce different outputs ─────────────────────────
            assert Aes256CtrEncryption.encrypt("hello") != Aes256CtrEncryption.encrypt(
                "world"
            ), "Different inputs must produce different outputs"

            # ── empty string produces a valid non-empty token ─────────────────────
            empty_result = Aes256CtrEncryption.encrypt("")
            assert isinstance(empty_result, str) and len(empty_result) > 0, (
                f"Empty string must produce non-empty token, got {empty_result!r}"
            )

    class TestDecrypt:
        """WHY: decrypt is the sole recovery path for encrypted data — a wrong
        round-trip, silent garbage output on malformed input, or broken unicode
        handling permanently loses data with no visible error."""

        def test_decrypt(self) -> None:
            assert pytest is not None  # Type guard for pyright
            # ── round-trip: decrypt(encrypt(x)) == x ─────────────────────────────
            original = "This is a secret message!"
            assert (
                Aes256CtrEncryption.decrypt(Aes256CtrEncryption.encrypt(original))
                == original
            ), f"Round-trip failed: expected {original!r}"

            # ── empty string round-trip ───────────────────────────────────────────
            assert Aes256CtrEncryption.decrypt(Aes256CtrEncryption.encrypt("")) == "", (
                "Empty string round-trip must return empty string"
            )

            # ── input shorter than 16 bytes raises ValueError ─────────────────────
            short = base64.b64encode(b"short").decode()
            with pytest.raises(ValueError, match="too short"):
                Aes256CtrEncryption.decrypt(short)

            # ── multi-byte UTF-8 unicode survives round-trip intact ───────────────
            unicode_text = "こんにちは世界"
            assert (
                Aes256CtrEncryption.decrypt(Aes256CtrEncryption.encrypt(unicode_text))
                == unicode_text
            ), f"Unicode round-trip failed: expected {unicode_text!r}"

            # ── invalid base64 raises binascii.Error after retries ────────────────
            with pytest.raises(binascii.Error):
                Aes256CtrEncryption.decrypt("!!!not-base64!!!")

    class TestDecryptJsonField:
        """WHY: decrypt_json_field is the only path for recovering secrets from nested
        JSON payloads — a wrong traversal, silent KeyError, or confusing type mismatch
        leaves callers unable to distinguish a missing field from a corrupt ciphertext."""

        def test_decrypt_json_field(self) -> None:
            assert pytest is not None  # Type guard for pyright
            # ── multi-level dot-notation path traversal works end-to-end ──────────
            payload: dict[str, Any] = {
                "user": {
                    "credentials": {
                        "password": Aes256CtrEncryption.encrypt("s3cr3tP@ss")
                    }
                }
            }
            assert (
                Aes256CtrEncryption.decrypt_json_field(
                    payload, "user.credentials.password"
                )
                == "s3cr3tP@ss"
            ), "Multi-level path traversal must decrypt correctly"

            # ── single-level path (no dots) works as boundary case ────────────────
            single_payload: dict[str, Any] = {
                "token": Aes256CtrEncryption.encrypt("abc")
            }
            assert (
                Aes256CtrEncryption.decrypt_json_field(single_payload, "token") == "abc"
            ), "Single-level path must decrypt correctly"

            # ── missing key raises ValueError with clear message ──────────────────
            missing_payload: dict[str, Any] = {
                "user": {"name": Aes256CtrEncryption.encrypt("alice")}
            }
            with pytest.raises(ValueError, match="Invalid JSON path"):
                Aes256CtrEncryption.decrypt_json_field(
                    missing_payload, "user.credentials.password"
                )

            # ── wrong-type leaf (dict not str) raises ValueError ──────────────────
            wrong_type_payload: dict[str, Any] = {
                "user": {"credentials": {"password": "s3cr3tP@ss"}}
            }
            with pytest.raises(ValueError, match="expected str"):
                Aes256CtrEncryption.decrypt_json_field(
                    wrong_type_payload, "user.credentials"
                )


# ── SECTION 5 · PERFORMANCE TEST ─────────────────────────────────────────────
# Goal: Provide live performance benchmarks for all public API operations.


def run_performance_test(
    single_thread_count: int = 1000,
    multi_thread_count: int = 250,
    num_threads: int = 4,
    show_logs: bool = True,
) -> dict:
    """
    Run live performance benchmarks for ENCRYPTION_SERVICE on current hardware.

    Tests:
      1. Single-thread encrypt throughput
      2. Single-thread decrypt throughput
      3. Round-trip (encrypt + decrypt) average latency
      4. JSON field decrypt throughput
      5. Message size impact (10 / 100 / 1000 / 10 000 bytes)
      6. Multi-thread encrypt throughput (4 threads)
      7. Multi-thread encrypt throughput (8 threads)
      8. Determinism check — same input always produces same output

    Args:
        single_thread_count: Number of ops for single-thread encrypt/decrypt tests.
        multi_thread_count:  Ops per thread for multi-thread tests.
        num_threads:         Worker thread count for the primary multi-thread test.
        show_logs:           Print per-test progress lines (set False for silent run).

    Returns:
        dict with keys: encrypt, decrypt, round_trip, json_field,
                        size_impact, multi_thread_4, multi_thread_8, determinism.
    """
    from datetime import datetime

    # WHY: Mirror JSONL_LOGGER.run_performance_test() header style exactly so both
    #      files produce identical-looking output when run from __main__
    print("\n" + "=" * 70)
    print("ENCRYPTION_SERVICE Live Performance Test")
    print(f"Started: {datetime.now().isoformat()}")
    print("=" * 70)

    results: dict = {}

    # ── 1. Single-Thread Encrypt ──────────────────────────────────────────────
    if show_logs:
        print(f"\n📊 Single-Thread Encrypt ({single_thread_count:,} ops):")
        print("-" * 40)

    messages = [f"msg_{i}" for i in range(single_thread_count)]
    start = time.time()
    for msg in messages:
        Aes256CtrEncryption.encrypt(msg)
    elapsed_enc = time.time() - start
    throughput_enc = single_thread_count / elapsed_enc

    results["encrypt"] = {
        "ops": single_thread_count,
        "time_seconds": round(elapsed_enc, 3),
        "throughput": round(throughput_enc, 0),
        "target": 10000,
    }

    if show_logs:
        print(f"   Ops:        {single_thread_count:,}")
        print(f"   Time:       {elapsed_enc:.3f} seconds")
        print(f"   Throughput: {throughput_enc:.0f} ops/sec")
        print("   Target: ≥10,000 ops/sec → ", end="")
        print("✅ PASS" if throughput_enc >= 10000 else "⚠️ Below target")

    # ── 2. Single-Thread Decrypt ──────────────────────────────────────────────
    if show_logs:
        print(f"\n📊 Single-Thread Decrypt ({single_thread_count:,} ops):")
        print("-" * 40)

    # WHY: Pre-encrypt tokens so decrypt test measures only decryption overhead,
    #      not the cost of prior encrypt calls skewing the timing
    tokens = [
        Aes256CtrEncryption.encrypt(f"msg_{i}") for i in range(single_thread_count)
    ]
    start = time.time()
    for token in tokens:
        Aes256CtrEncryption.decrypt(token)
    elapsed_dec = time.time() - start
    throughput_dec = single_thread_count / elapsed_dec

    results["decrypt"] = {
        "ops": single_thread_count,
        "time_seconds": round(elapsed_dec, 3),
        "throughput": round(throughput_dec, 0),
        "target": 10000,
    }

    if show_logs:
        print(f"   Ops:        {single_thread_count:,}")
        print(f"   Time:       {elapsed_dec:.3f} seconds")
        print(f"   Throughput: {throughput_dec:.0f} ops/sec")
        print("   Target: ≥10,000 ops/sec → ", end="")
        print("✅ PASS" if throughput_dec >= 10000 else "⚠️ Below target")

    # ── 3. Round-Trip Latency ─────────────────────────────────────────────────
    rt_count = 100
    if show_logs:
        print(f"\n📊 Round-Trip Latency ({rt_count:,} encrypt+decrypt cycles):")
        print("-" * 40)

    start = time.time()
    for i in range(rt_count):
        token = Aes256CtrEncryption.encrypt(f"test_{i}")
        Aes256CtrEncryption.decrypt(token)
    elapsed_rt = time.time() - start
    avg_ms = (elapsed_rt / rt_count) * 1000

    results["round_trip"] = {
        "ops": rt_count,
        "time_seconds": round(elapsed_rt, 3),
        "avg_ms": round(avg_ms, 3),
        "target_ms": 1.0,
    }

    if show_logs:
        print(f"   Ops:        {rt_count:,}")
        print(f"   Total time: {elapsed_rt:.3f} seconds")
        print(f"   Avg/call:   {avg_ms:.3f} ms")
        print("   Target: < 1 ms/call → ", end="")
        print("✅ PASS" if avg_ms < 1.0 else "⚠️ Below target")

    # ── 4. JSON Field Decrypt ─────────────────────────────────────────────────
    json_count = 500
    if show_logs:
        print(f"\n📊 JSON Field Decrypt ({json_count:,} ops):")
        print("-" * 40)

    # WHY: Pre-build payloads outside the timed block — we measure only the
    #      decrypt_json_field traversal + decryption, not payload construction
    payloads = []
    for i in range(json_count):
        tok = Aes256CtrEncryption.encrypt(f"secret_{i}")
        payloads.append({"user": {"data": {"field": tok}}})

    start = time.time()
    for p in payloads:
        Aes256CtrEncryption.decrypt_json_field(p, "user.data.field")
    elapsed_json = time.time() - start
    throughput_json = json_count / elapsed_json

    results["json_field"] = {
        "ops": json_count,
        "time_seconds": round(elapsed_json, 3),
        "throughput": round(throughput_json, 0),
        "target": 10000,
    }

    if show_logs:
        print(f"   Ops:        {json_count:,}")
        print(f"   Time:       {elapsed_json:.3f} seconds")
        print(f"   Throughput: {throughput_json:.0f} ops/sec")
        print("   Target: ≥10,000 ops/sec → ", end="")
        print("✅ PASS" if throughput_json >= 10000 else "⚠️ Below target")

    # ── 5. Message Size Impact ────────────────────────────────────────────────
    if show_logs:
        print("\n📊 Message Size Impact:")
        print("-" * 40)

    size_results: dict = {}
    for size in [10, 100, 1000, 10000]:
        msg = "x" * size

        start = time.time()
        tok = Aes256CtrEncryption.encrypt(msg)
        enc_time = time.time() - start

        start = time.time()
        Aes256CtrEncryption.decrypt(tok)
        dec_time = time.time() - start

        enc_ops = round(1 / enc_time, 0)
        dec_ops = round(1 / dec_time, 0)
        size_results[size] = {"encrypt_ops_sec": enc_ops, "decrypt_ops_sec": dec_ops}

        if show_logs:
            print(
                f"   {size:6} bytes: encrypt {enc_ops:.0f}/sec,  decrypt {dec_ops:.0f}/sec"
            )

    results["size_impact"] = size_results

    # ── 6. Multi-Thread Encrypt (4 threads) ───────────────────────────────────
    mt4_threads = 4
    mt4_ops_per_thread = multi_thread_count
    mt4_total = mt4_threads * mt4_ops_per_thread

    if show_logs:
        print(
            f"\n📊 Multi-Thread Encrypt ({mt4_threads} threads × {mt4_ops_per_thread:,} ops = {mt4_total:,} total):"
        )
        print("-" * 40)

    def _worker_encrypt(tid: int, count: int) -> None:
        # WHY: Each thread encrypts unique messages keyed by thread id and index
        #      so determinism doesn't mask any GIL-related timing artifacts
        for i in range(count):
            Aes256CtrEncryption.encrypt(f"thread_{tid}_{i}")

    threads_4 = [
        threading.Thread(target=_worker_encrypt, args=(i, mt4_ops_per_thread))
        for i in range(mt4_threads)
    ]
    start = time.time()
    for t in threads_4:
        t.start()
    for t in threads_4:
        t.join()
    elapsed_mt4 = time.time() - start
    throughput_mt4 = mt4_total / elapsed_mt4

    results["multi_thread_4"] = {
        "threads": mt4_threads,
        "ops_per_thread": mt4_ops_per_thread,
        "total_ops": mt4_total,
        "time_seconds": round(elapsed_mt4, 3),
        "throughput": round(throughput_mt4, 0),
        "target": 10000,
    }

    if show_logs:
        print(f"   Total ops:  {mt4_total:,}")
        print(f"   Time:       {elapsed_mt4:.3f} seconds")
        print(f"   Throughput: {throughput_mt4:.0f} ops/sec")
        print("   Target: ≥10,000 ops/sec → ", end="")
        print("✅ PASS" if throughput_mt4 >= 10000 else "⚠️ Below target")

    # ── 7. Multi-Thread Encrypt (8 threads) ───────────────────────────────────
    mt8_threads = 8
    mt8_ops_per_thread = multi_thread_count
    mt8_total = mt8_threads * mt8_ops_per_thread

    if show_logs:
        print(
            f"\n📊 Multi-Thread Encrypt ({mt8_threads} threads × {mt8_ops_per_thread:,} ops = {mt8_total:,} total):"
        )
        print("-" * 40)
        # WHY: Note appears here — directly before the 8-thread result — so the
        #      reader sees the GIL caveat immediately alongside the lower number
        print("   NOTE: Python GIL limits CPU-bound crypto scaling across threads.")

    threads_8 = [
        threading.Thread(target=_worker_encrypt, args=(i, mt8_ops_per_thread))
        for i in range(mt8_threads)
    ]
    start = time.time()
    for t in threads_8:
        t.start()
    for t in threads_8:
        t.join()
    elapsed_mt8 = time.time() - start
    throughput_mt8 = mt8_total / elapsed_mt8

    results["multi_thread_8"] = {
        "threads": mt8_threads,
        "ops_per_thread": mt8_ops_per_thread,
        "total_ops": mt8_total,
        "time_seconds": round(elapsed_mt8, 3),
        "throughput": round(throughput_mt8, 0),
        "target": 10000,
    }

    if show_logs:
        print(f"   Total ops:  {mt8_total:,}")
        print(f"   Time:       {elapsed_mt8:.3f} seconds")
        print(f"   Throughput: {throughput_mt8:.0f} ops/sec")
        print("   Target: ≥10,000 ops/sec → ", end="")
        print("✅ PASS" if throughput_mt8 >= 10000 else "⚠️ Below target")

    # ── 8. Determinism Check ──────────────────────────────────────────────────
    if show_logs:
        print("\n📊 Determinism Check:")
        print("-" * 40)

    t1 = Aes256CtrEncryption.encrypt("hello")
    t2 = Aes256CtrEncryption.encrypt("hello")
    is_deterministic = t1 == t2

    results["determinism"] = {"pass": is_deterministic}

    if show_logs:
        print(f"   Same input → same output: {is_deterministic}")
        print("   Target: 100% deterministic → ", end="")
        print("✅ PASS" if is_deterministic else "❌ FAIL")

    # ── Summary ───────────────────────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("✅ Performance Test Complete")
    print("=" * 70)

    return results


# ═══════════════════════════════════════════════════════════════════════════════
# TEST COVERAGE MATRIX
# ═══════════════════════════════════════════════════════════════════════════════
#
# Tier 1 = Public API      → must be exhaustive; called by application code
# Tier 2 = Internal Logic  → correctness + resilience; helpers & infrastructure
# Tier 3 = Dev/Debug       → lower priority; import-time validation
#
# Legend: ✅ covered  ⚠️ partial  ❌ not covered
#
# ┌─────────────────────────────────────┬──────┬───────────┬────────┬────────────────────────────────────────────────────────────────────────┐
# │ Function / Component                │ Tier │ Test Class│ Tests  │ What is tested                                                         │
# ├─────────────────────────────────────┼──────┼───────────┼────────┼────────────────────────────────────────────────────────────────────────┤
# │ Aes256CtrEncryption.encrypt()       │  1   │TestEncrypt│ 4  ✅  │ returns non-empty base64, deterministic, different inputs differ,      │
# │                                     │                  │        │ empty string handled                                                   │
# │ Aes256CtrEncryption.decrypt()       │  1   │TestDecrypt│ 5  ✅  │ round-trip encrypt/decrypt, empty string, too-short input raises       │
# │                                     │                  │        │ ValueError, unicode plaintext survives round-trip, invalid base64 raises   │
# │ Aes256CtrEncryption.decrypt_json_   │  1   │TestDcrptJF│ 4  ✅  │ nested path traversal, invalid path raises ValueError,                 │
# │             field()                 │                  │        │ non-string leaf raises ValueError, single-level path works             │
# ├─────────────────────────────────────┼──────┼───────────┼────────┼────────────────────────────────────────────────────────────────────────┤
# │ simple_retry()                      │  2   │TestSmpRet │ 4  ✅  │ success on attempt 1, success on attempt 3, exhaustion raises,         │
# │                                     │                  │        │ all exceptions retried                                                 │
# │ _derive_256bit_key()                │  2   │TestDerive │ 3  ✅  │ returns 32 bytes, deterministic, different passwords differ            │
# │ _generate_deterministic_iv()        │  2   │TestGenIV  │ 3  ✅  │ returns 16 bytes, deterministic, different plaintexts differ           │
# ├─────────────────────────────────────┼──────┼───────────┼────────┼────────────────────────────────────────────────────────────────────────┤
# │ ENCRYPTION_KEY validation           │  3   │TestImpVal │ 2  ✅  │ raises ValueError if missing; subprocess test                          │
# │ Key length warning (<32 bytes)      │  3   │TestImpVal │ 2  ✅  │ fires at import time if key too short; subprocess test                 │
# ├─────────────────────────────────────┼──────┼───────────┼────────┼────────────────────────────────────────────────────────────────────────┤
# │ TOTALS                              │                  │        │                                                                        │
# │   Tier 1 — Public API               │    3 functions   │ 13 ✅  │ All public functions fully covered                                     │
# │   Tier 2 — Internal Logic           │    3 functions   │ 10 ✅  │ All Tier 2 helpers now fully covered                                   │
# │   Tier 3 — Dev/Debug                │    2 components  │  4 ✅  │ All import-time validations now covered                                │
# └─────────────────────────────────────┴──────┴───────────┴────────┴────────────────────────────────────────────────────────────────────────┘


# ═══════════════════════════════════════════════════════════════════════════════
# USAGE GUIDE
# ═══════════════════════════════════════════════════════════════════════════════
#
# Quick Start:
#   from encryption import Aes256CtrEncryption
#
#   token = Aes256CtrEncryption.encrypt("s3cr3t")
#   plain = Aes256CtrEncryption.decrypt(token)                             # → "s3cr3t"
#
#   payload = {"db": {"pass": Aes256CtrEncryption.encrypt("hunter2")}}
#   pw      = Aes256CtrEncryption.decrypt_json_field(payload, "db.pass")   # → "hunter2"
#
# Environment Variables (.env):
#   ENCRYPTION_KEY=your-secret-phrase    # Required: NO space before =, MUST be ≥ 32 bytes,
#                                        # cryptographically random — never a human password
#
# ─────────────────────────────────────────────────────────────────────────────
# Cross-language interoperability (Rust sibling):
#   The IV derivation and key derivation algorithms MUST stay SHA-256-based
#   to remain compatible with the Rust implementation. Do not change _derive_256bit_key
#   or _generate_deterministic_iv without updating the Rust sibling simultaneously.
# ─────────────────────────────────────────────────────────────────────────────
#
# Run Tests:
#   python3 -m pytest ENCRYPTION_SERVICE.py -v
#
# Run Performance Test:
#   python3 ENCRYPTION_SERVICE.py
#
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("Testing encryption.py...")
    token = Aes256CtrEncryption.encrypt("This is a secret message!")
    assert Aes256CtrEncryption.decrypt(token) == "This is a secret message!"
    print(f"  encrypt/decrypt round-trip    ✅  ({token[:30]}...)")
    payload: dict[str, Any] = {
        "user": {"credentials": {"password": Aes256CtrEncryption.encrypt("s3cr3tP@ss")}}
    }
    assert (
        Aes256CtrEncryption.decrypt_json_field(payload, "user.credentials.password")
        == "s3cr3tP@ss"
    )
    print("  decrypt_json_field            ✅")
    empty_token = Aes256CtrEncryption.encrypt("")
    assert Aes256CtrEncryption.decrypt(empty_token) == ""
    print("  empty string round-trip       ✅")
    print("Done — check .env for ENCRYPTION_KEY if any errors appear.")

    # Run full performance test — shows all 8 benchmark categories
    print("\n" + "=" * 60)
    print("Running FULL Performance Test Suite")
    print("=" * 60)
    run_performance_test(show_logs=True)
