def hello_chart():
    print("欢迎使用自动化数据分析工具！")
