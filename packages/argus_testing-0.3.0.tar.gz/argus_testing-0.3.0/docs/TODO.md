# Current TODO

Last updated: 2026-04-11

## MCP mode — complete and verified

All 14 tools tested on real websites. Zero false positives. Ready for users.

## Next priorities

- [ ] **Record demo GIF** for README — show MCP session finding real bugs on a website
- [ ] **Code-driven CLI exploration** — auto-crawl nav links, find forms, systematic edge cases, LLM only generates test data
- [ ] **Responsive testing** — test at mobile/tablet viewports, detect overflow
- [ ] **More real-world testing** — test on e-commerce, SaaS, SPA apps to find edge cases
