# Current Status

Last updated: 2026-04-11

## What's done

### Detection (16 bug types, 12 detection methods)

**Passive (run automatically in get_errors):**
- [x] Console errors / exceptions
- [x] Network errors (HTTP 4xx/5xx)
- [x] Text anomaly (broken dates, NaN, eternal "Loading...")
- [x] Count consistency (displayed count vs actual items)
- [x] CSS state (alarming styling on success states)
- [x] Toast + network cross-check (success toast + HTTP 500)
- [x] Broken images (naturalWidth === 0)
- [x] SEO audit (missing meta/OG tags, heading hierarchy)
- [x] Accessibility (missing alt, unlabeled inputs, no lang — aggregated by type)
- [x] Mixed content (HTTP resources on HTTPS)

**On-demand MCP tools:**
- [x] `check_links()` — HEAD with GET fallback on 405, 403 = anti-bot
- [x] `check_performance()` — load time, TTFB, large resources, request count
- [x] `verify_action()` — verify delete/edit persisted after refresh

### MCP mode — 14 tools, verified working
- [x] All tools tested on real websites via MCP (VanLife, NALifeX, Hacker News)
- [x] get_errors() correctly runs all passive detectors
- [x] check_links() handles 405 fallback and 403 anti-bot
- [x] check_performance() reports load time and large resources
- [x] Zero false positives across all test sites

### Quality
- [x] A11y aggregated by type per page
- [x] Dead links aggregated by domain
- [x] NaN/date regex excludes quoted text
- [x] 403 = anti-bot, 405 → GET fallback

### Publishing
- [x] PyPI: `pip install argus-testing` (v0.2.2)
- [x] GitHub: https://github.com/chriswu727/argus
- [x] awesome-mcp-servers PR #4515

### MCP test results (verified 2026-04-11)
| Site | Bugs | Links checked | Performance | False positives |
|------|------|--------------|-------------|----------------|
| VanLife | 2 (SEO) | 40/40 OK | 0.64s | 0 |
| NALifeX | 3 (a11y, SEO, perf) | 64/64 OK | 1.03s | 0 |
| Hacker News | 5 (a11y, SEO) | 164/164 OK | — | 0 |

## What's NOT done yet
- [ ] CLI planner needs code-driven exploration
- [ ] No README demo GIF
- [ ] Responsive / viewport testing
