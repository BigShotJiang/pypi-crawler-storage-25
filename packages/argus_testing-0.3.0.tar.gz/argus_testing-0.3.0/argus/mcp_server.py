"""Argus MCP Server — exposes browser testing tools to Claude Code.

Claude Code becomes the AI planner. Argus provides the browser, DOM
extraction, error capture, and report generation. No API key needed.

Usage in Claude Code settings (~/.claude/settings.json):
    {
        "mcpServers": {
            "argus": {
                "command": "argus-mcp"
            }
        }
    }

Then in Claude Code just say:
    "Test my app at http://localhost:3000, focus on the login flow"
"""
from __future__ import annotations

import asyncio
import os
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from mcp.server.fastmcp import FastMCP

from .browser import BrowserDriver
from .detector import Detector
from .models import Bug, BugType, ExplorationResult, Screenshot, Severity
from .reporter import Reporter

mcp = FastMCP(
    "argus",
    instructions="""Argus is an AI-powered QA testing toolkit. Use these tools to explore a web application like a real user. Typical workflow:
1. start_session(url) — launch browser
2. get_page_state() — see interactive elements
3. click/type/navigate — interact with the page
4. get_errors() — check for console/network errors
5. screenshot() — capture the current state
6. Repeat 2-5, exploring systematically
7. end_session() — close browser and generate report

TESTING STRATEGY — Be thorough and systematic:

PAGE DISCOVERY: Visit every link in the navigation. Check for dead links (404s).

FORM TESTING — For every form you find, test ALL of these:
  - Empty submission: submit with no fields filled
  - Valid data: fill everything correctly and submit
  - Invalid emails: try "notanemail", "a@", "@b.com"
  - Password edge cases: try very short (1 char), very long (200+ chars), empty
  - Special characters: < > " ' & ; | \\ / {{ }} and unicode like 中文 émojis 🔥
  - SQL injection: try ' OR 1=1 -- and "; DROP TABLE users; --
  - XSS payloads: try <script>alert('xss')</script> and <img onerror=alert(1) src=x>
  - Very long input: paste 500+ characters into fields
  - Mismatched fields: if there's "confirm password", make them different
  - Boundary values: 0, -1, 999999999 for numeric fields
  - Required field bypass: fill some fields but skip required ones

NAVIGATION TESTING:
  - Click every navigation link
  - Try browser back/forward
  - Try navigating to pages directly by URL
  - Check what happens when accessing authenticated pages without login

INTERACTION TESTING:
  - Click every button, even ones that look decorative
  - Try double-clicking
  - Try actions in unexpected order (e.g., submit before filling form)
  - Try the same action multiple times rapidly

Always call get_errors() after form submissions and page navigations.
Always call screenshot() after important interactions to document findings.
Take a screenshot of EVERY page you visit and every error state you find.

VERIFICATION — After destructive actions, ALWAYS verify:
  - After DELETE: call verify_action("delete", "item text", verify_url="/list-page") to confirm item is gone
  - After EDIT/SAVE: call verify_action("edit", "new value", verify_url="/edit-page") to confirm changes persisted
  - The verify_url should be the page where you can SEE the data (e.g., the list page for delete, the edit form for edit)
  - After seeing a success toast: call get_errors() immediately to check for hidden server errors

CONTENT ANALYSIS — get_page_state() now returns:
  - Full page text (check for "Loading...", "NaN", broken dates)
  - Visible toast messages
  - Displayed counts (compare against actual item counts)
  - CSS state indicators

Look for these patterns:
  - "Loading..." text on a page that should have loaded
  - Numbers with decimals in dates ("1.52 days ago")
  - Count mismatches between totals and actual items
  - Success messages alongside server errors
  - Red/alarming styling on zero-remaining states

COMPREHENSIVE CHECKS — These run automatically with get_errors():
  - Broken images (failed to load)
  - Missing alt text on images
  - Form inputs without labels
  - Buttons/links with no accessible name
  - Missing meta description, OG tags
  - Heading hierarchy issues
  - Mixed content (HTTP on HTTPS)

ON-DEMAND CHECKS — Call these explicitly:
  - check_links(): Crawl all internal links, find 404s/5xx
  - check_performance(): Measure load time, find large resources""",
)


class Session:
    """Holds the state for one testing session."""

    def __init__(self):
        self.browser: Optional[BrowserDriver] = None
        self.detector = Detector()
        self.bugs: List[Bug] = []
        self.steps: List[str] = []
        self.pages_visited: List[str] = []
        self.screenshots: List[Screenshot] = []
        self.start_time: Optional[float] = None
        self.url: Optional[str] = None
        self.focus_areas: List[str] = []
        self._last_elements = []
        self._screenshot_counter = 0

    @property
    def active(self) -> bool:
        return self.browser is not None


_session = Session()


def _require_session() -> Session:
    if not _session.active:
        raise RuntimeError("No active session. Call start_session(url) first.")
    return _session


def _output_dir() -> str:
    return os.environ.get("ARGUS_OUTPUT_DIR", "./argus-reports")


async def _auto_screenshot(s: Session, name: str, step: str) -> str:
    """Take a screenshot and register it in the session."""
    s._screenshot_counter += 1
    safe_name = f"{s._screenshot_counter:03d}_{name}"
    path = str(Path(_output_dir()) / "screenshots" / f"{safe_name}.png")
    await s.browser.screenshot(path)
    url = s.browser._page.url if s.browser._page else ""
    s.screenshots.append(Screenshot(
        path=path, name=safe_name, step=step, url=url,
    ))
    return path


@mcp.tool()
async def start_session(
    url: str,
    headless: bool = True,
    viewport_width: int = 1280,
    viewport_height: int = 720,
) -> str:
    """Start a browser testing session and navigate to the given URL.

    Args:
        url: The URL to test (e.g. http://localhost:3000)
        headless: Run browser without visible window (default True)
        viewport_width: Browser viewport width in pixels
        viewport_height: Browser viewport height in pixels
    """
    global _session

    if _session.active:
        await _session.browser.stop()

    _session = Session()
    _session.url = url
    _session.start_time = asyncio.get_event_loop().time()
    _session.browser = BrowserDriver(
        headless=headless,
        viewport_width=viewport_width,
        viewport_height=viewport_height,
    )
    await _session.browser.start()
    await _session.browser.goto(url)
    _session.pages_visited.append(url)

    state = await _session.browser.get_state()
    _session._last_elements = state.elements
    element_count = len(state.elements)

    return (
        f"Session started.\n"
        f"Page: {state.title}\n"
        f"URL: {state.url}\n"
        f"Found {element_count} interactive elements. "
        f"Call get_page_state() to see them."
    )


@mcp.tool()
async def get_page_state() -> str:
    """Get the current page URL, title, and all interactive elements.

    Returns a numbered list of elements you can interact with using
    click(index), type_text(index, text), or select_option(index, value).
    """
    s = _require_session()
    state = await s.browser.get_state()
    s._last_elements = state.elements

    if state.url not in s.pages_visited:
        s.pages_visited.append(state.url)

    lines = [f"URL: {state.url}", f"Title: {state.title}", "", "Interactive elements:"]
    if not state.elements:
        lines.append("  (none found)")
    for el in state.elements:
        parts = [f"  [{el.index}] <{el.tag}"]
        if el.type:
            parts.append(f' type="{el.type}"')
        parts.append(">")
        if el.text:
            parts.append(f' "{el.text}"')
        if el.placeholder:
            parts.append(f' (placeholder: "{el.placeholder}")')
        if el.href:
            parts.append(f" -> {el.href}")
        if el.disabled:
            parts.append(" [disabled]")
        if el.value:
            parts.append(f' value="{el.value}"')
        lines.append("".join(parts))

    # Page content analysis
    if state.page_text:
        lines.append("")
        lines.append(f"Page text (first 1500 chars):")
        lines.append(state.page_text[:1500])
    if state.toast_messages:
        lines.append("")
        lines.append("Visible toasts/notifications:")
        for toast in state.toast_messages:
            lines.append(f"  [TOAST] {toast}")
    if state.counts:
        lines.append("")
        lines.append("Displayed counts:")
        for label, val in state.counts.items():
            lines.append(f"  {val} {label}")
    if state.css_indicators:
        lines.append("")
        lines.append("CSS state indicators:")
        for ind in state.css_indicators:
            lines.append(f"  .{ind}")

    return "\n".join(lines)


@mcp.tool()
async def click(element_index: int) -> str:
    """Click an interactive element by its index number from get_page_state().

    Args:
        element_index: The [N] index of the element to click
    """
    s = _require_session()
    if element_index < 0 or element_index >= len(s._last_elements):
        return f"Error: element index {element_index} out of range (0-{len(s._last_elements) - 1})"

    el = s._last_elements[element_index]
    label = el.text or el.aria_label or el.placeholder or f"{el.tag}#{el.id or '?'}"
    step = f'Click "{label}"'
    s.steps.append(step)

    ok = await s.browser.click(element_index, s._last_elements)
    if ok:
        new_state = await s.browser.get_state()
        s._last_elements = new_state.elements
        if new_state.url not in s.pages_visited:
            s.pages_visited.append(new_state.url)
        return f"Clicked \"{label}\". Now on: {new_state.url} ({len(new_state.elements)} elements)"
    return f"Failed to click \"{label}\" — element may be obscured or gone."


@mcp.tool()
async def type_text(element_index: int, text: str) -> str:
    """Type text into an input element.

    Args:
        element_index: The [N] index of the input element
        text: The text to type
    """
    s = _require_session()
    if element_index < 0 or element_index >= len(s._last_elements):
        return f"Error: element index {element_index} out of range"

    el = s._last_elements[element_index]
    label = el.placeholder or el.name or el.id or f"element [{element_index}]"
    step = f'Type "{text}" into {label}'
    s.steps.append(step)

    ok = await s.browser.type_text(element_index, text, s._last_elements)
    if ok:
        return f'Typed "{text}" into {label}'
    return f"Failed to type into {label}"


@mcp.tool()
async def select_option(element_index: int, value: str) -> str:
    """Select an option from a dropdown/select element.

    Args:
        element_index: The [N] index of the select element
        value: The value or visible text to select
    """
    s = _require_session()
    if element_index < 0 or element_index >= len(s._last_elements):
        return f"Error: element index {element_index} out of range"

    step = f'Select "{value}" in element [{element_index}]'
    s.steps.append(step)

    ok = await s.browser.select_option(element_index, value, s._last_elements)
    if ok:
        return f'Selected "{value}"'
    return "Failed to select option"


@mcp.tool()
async def navigate(url: str) -> str:
    """Navigate to a specific URL.

    Args:
        url: The URL to navigate to
    """
    s = _require_session()
    step = f"Navigate to {url}"
    s.steps.append(step)

    await s.browser.goto(url)
    state = await s.browser.get_state()
    s._last_elements = state.elements
    if state.url not in s.pages_visited:
        s.pages_visited.append(state.url)

    return f"Navigated to {state.url} — {state.title} ({len(state.elements)} elements)"


@mcp.tool()
async def go_back() -> str:
    """Go back to the previous page."""
    s = _require_session()
    s.steps.append("Go back")

    ok = await s.browser.go_back()
    if ok:
        state = await s.browser.get_state()
        s._last_elements = state.elements
        return f"Went back to {state.url}"
    return "Failed to go back"


@mcp.tool()
async def scroll_down() -> str:
    """Scroll the page down to reveal more content."""
    s = _require_session()
    s.steps.append("Scroll down")
    await s.browser.scroll_down()
    return "Scrolled down. Call get_page_state() to see updated elements."


@mcp.tool()
async def screenshot(name: str = "screenshot") -> str:
    """Take a screenshot of the current page.

    Args:
        name: Name for the screenshot file (without extension)
    """
    s = _require_session()
    last_step = s.steps[-1] if s.steps else "Initial state"
    path = await _auto_screenshot(s, name, last_step)
    return f"Screenshot saved: {path}"


@mcp.tool()
async def get_errors() -> str:
    """Get all console errors and network failures captured since the last check.

    Returns any JavaScript errors, unhandled exceptions, and HTTP 4xx/5xx
    responses detected during interaction. These are automatically recorded
    as bugs in the session report.
    """
    s = _require_session()
    console_errs, network_errs = s.browser.drain_errors()

    current_url = s.browser._page.url if s.browser._page else ""
    new_bugs = s.detector.process_console_errors(
        console_errs, current_url, s.steps
    )
    new_bugs.extend(s.detector.process_network_errors(
        network_errs, current_url, s.steps
    ))

    # Smart detection: page content, counts, CSS, toast cross-check
    state = await s.browser.get_state()
    s._last_elements = state.elements
    new_bugs.extend(s.detector.process_page_content(state, s.steps))
    new_bugs.extend(s.detector.process_count_consistency(state, s.steps))
    new_bugs.extend(s.detector.process_css_indicators(state, s.steps))
    if state.toast_messages:
        new_bugs.extend(s.detector.process_toast_network_crosscheck(
            state.toast_messages, network_errs, current_url, s.steps
        ))
    # Comprehensive detection: images, a11y, SEO, mixed content
    new_bugs.extend(s.detector.process_broken_images(state, s.steps))
    new_bugs.extend(s.detector.process_accessibility(state, s.steps))
    new_bugs.extend(s.detector.process_seo(state, s.steps))
    new_bugs.extend(s.detector.process_mixed_content(state, s.steps))

    # Auto-screenshot for new bugs and attach to them
    if new_bugs:
        ss_path = await _auto_screenshot(
            s, f"error_{len(s.bugs) + 1}", f"Error detected on {current_url}"
        )
        for bug in new_bugs:
            bug.screenshot_path = ss_path

    s.bugs.extend(new_bugs)

    if not new_bugs:
        return f"No new errors. Total bugs in session: {len(s.bugs)}"

    lines = []
    for err in console_errs:
        lines.append(f"[CONSOLE {err['type'].upper()}] {err['text']}")
    for err in network_errs:
        lines.append(f"[HTTP {err['status']}] {err['method']} {err['url']}")
    for bug in new_bugs:
        if bug.type not in (BugType.CONSOLE_ERROR, BugType.NETWORK_ERROR):
            lines.append(f"[{bug.type.value.upper()}] {bug.title}")
    lines.append(f"\nTotal bugs in session: {len(s.bugs)}")

    return "\n".join(lines)


@mcp.tool()
async def verify_action(action_type: str, target_text: str, verify_url: str = "") -> str:
    """Verify that a destructive action actually persisted by navigating to a page and checking.

    Call this AFTER performing a delete, edit, or toggle and seeing a success message.
    Navigates to verify_url (or the current page via GET) and checks whether the
    expected change is reflected in the page content.

    Args:
        action_type: One of "delete", "edit", or "toggle"
        target_text: For delete: the text of the deleted item. For edit: the NEW value you entered.
        verify_url: URL to navigate to for verification (e.g. the list page or edit page). If empty, navigates to the current URL via GET.
    """
    s = _require_session()
    s.steps.append(f'Verify {action_type}: "{target_text}"')

    # Navigate to verify URL (GET request, not reload which may re-POST)
    current_url = s.browser._page.url if s.browser._page else ""
    nav_url = verify_url or current_url
    await s.browser.goto(nav_url)
    after_state = await s.browser.get_state()
    s._last_elements = after_state.elements

    # For before_state, we use a minimal PageState since we already navigated away
    from .models import PageState
    before_state = PageState(url=current_url, title="", elements=[], page_text="")

    bugs = s.detector.process_state_verification(
        action_type, target_text, before_state, after_state, s.steps
    )

    if bugs:
        ss_path = await _auto_screenshot(
            s, f"verify_{action_type}", f"Verification failed: {action_type}"
        )
        for bug in bugs:
            bug.screenshot_path = ss_path
        s.bugs.extend(bugs)
        bug_msgs = [f"  [{b.severity.value.upper()}] {b.title}" for b in bugs]
        return "VERIFICATION FAILED:\n" + "\n".join(bug_msgs) + f"\n\nTotal bugs: {len(s.bugs)}"

    return f"Verification passed: {action_type} on '{target_text}' persisted correctly."


@mcp.tool()
async def check_links() -> str:
    """Crawl all internal links on the current page and check for dead links (404/5xx).

    Sends HEAD requests to each internal link found on the page.
    This can take several seconds on pages with many links.
    """
    s = _require_session()
    state = await s.browser.get_state()
    s._last_elements = state.elements

    link_results = await s.browser.check_links(state.links)
    new_bugs = s.detector.process_dead_links(link_results, state.url, s.steps)

    if new_bugs:
        ss_path = await _auto_screenshot(s, "dead_links", f"Dead links on {state.url}")
        for bug in new_bugs:
            bug.screenshot_path = ss_path
    s.bugs.extend(new_bugs)

    dead = [r for r in link_results if not r["ok"]]
    alive = [r for r in link_results if r["ok"]]
    external = [l for l in state.links if not l.get("isInternal")]

    lines = [f"Checked {len(link_results)} internal links on {state.url}"]
    lines.append(f"  OK: {len(alive)}")
    lines.append(f"  Dead: {len(dead)}")
    lines.append(f"  External (not checked): {len(external)}")
    if dead:
        lines.append("")
        for r in dead:
            lines.append(f"  [HTTP {r['status']}] {r['href']}")
    lines.append(f"\nTotal bugs in session: {len(s.bugs)}")
    return "\n".join(lines)


@mcp.tool()
async def check_performance() -> str:
    """Measure page performance: load time, resource count, large resources.

    Uses the browser's Performance API. Best called right after navigating to a page.
    """
    s = _require_session()
    current_url = s.browser._page.url if s.browser._page else ""
    perf_data = await s.browser.get_performance()
    new_bugs = s.detector.process_performance(perf_data, current_url, s.steps)

    if new_bugs:
        ss_path = await _auto_screenshot(s, "performance", f"Perf issues on {current_url}")
        for bug in new_bugs:
            bug.screenshot_path = ss_path
    s.bugs.extend(new_bugs)

    nav = perf_data.get("navigation", {})
    summary = perf_data.get("summary", {})
    lines = [f"Performance for {current_url}"]
    if nav:
        lines.append(f"  Load time: {nav.get('loadTime', 0)/1000:.2f}s")
        lines.append(f"  TTFB: {nav.get('ttfb', 0)/1000:.2f}s")
        lines.append(f"  DOM interactive: {nav.get('domInteractive', 0)/1000:.2f}s")
    lines.append(f"  Total requests: {summary.get('totalRequests', '?')}")
    lines.append(f"  Total size: {summary.get('totalSize', 0)/1024:.0f} KB")
    large = perf_data.get("resources", [])
    if large:
        lines.append(f"  Large resources (>500KB):")
        for r in large:
            lines.append(f"    {r['size']/1024:.0f}KB — {r['name'][:80]}")
    lines.append(f"\nTotal bugs in session: {len(s.bugs)}")
    return "\n".join(lines)


@mcp.tool()
async def crawl_site(max_pages: int = 20) -> str:
    """Crawl the entire site starting from the current page. Visits all internal links,
    runs all detectors on each page, and checks links and performance.

    This is the most thorough scan — it discovers pages automatically and tests everything.
    Can take 30-120 seconds depending on site size.

    Args:
        max_pages: Maximum number of pages to visit (default 20)
    """
    s = _require_session()
    start_url = s.browser._page.url if s.browser._page else s.url
    visited: set = set()
    to_visit: list = [start_url]
    page_results: list = []

    while to_visit and len(visited) < max_pages:
        url = to_visit.pop(0)
        if url in visited:
            continue
        visited.add(url)

        try:
            await s.browser.goto(url)
        except Exception:
            continue

        state = await s.browser.get_state()
        s._last_elements = state.elements
        if state.url not in s.pages_visited:
            s.pages_visited.append(state.url)

        # Run all passive detectors
        console_errs, network_errs = s.browser.drain_errors()
        new_bugs = s.detector.process_console_errors(console_errs, state.url, s.steps)
        new_bugs.extend(s.detector.process_network_errors(network_errs, state.url, s.steps))
        new_bugs.extend(s.detector.process_page_content(state, s.steps))
        new_bugs.extend(s.detector.process_count_consistency(state, s.steps))
        new_bugs.extend(s.detector.process_css_indicators(state, s.steps))
        new_bugs.extend(s.detector.process_broken_images(state, s.steps))
        new_bugs.extend(s.detector.process_accessibility(state, s.steps))
        new_bugs.extend(s.detector.process_seo(state, s.steps))
        new_bugs.extend(s.detector.process_mixed_content(state, s.steps))

        if state.toast_messages:
            new_bugs.extend(s.detector.process_toast_network_crosscheck(
                state.toast_messages, network_errs, state.url, s.steps
            ))

        # Check links
        link_results = await s.browser.check_links(state.links)
        new_bugs.extend(s.detector.process_dead_links(link_results, state.url, s.steps))

        # Performance
        perf = await s.browser.get_performance()
        new_bugs.extend(s.detector.process_performance(perf, state.url, s.steps))

        # Screenshot
        if new_bugs:
            page_name = state.url.split("/")[-1] or "index"
            ss_path = await _auto_screenshot(s, f"crawl_{page_name}", f"Crawl: {state.url}")
            for bug in new_bugs:
                bug.screenshot_path = ss_path

        s.bugs.extend(new_bugs)
        page_results.append((state.url, len(new_bugs)))

        # Discover new internal links to visit
        for link in state.links:
            href = link.get("href", "")
            if link.get("isInternal") and href not in visited and href not in to_visit:
                to_visit.append(href)

    lines = [f"Crawl complete: {len(visited)} pages visited, {len(s.bugs)} total bugs"]
    lines.append("")
    for url, count in page_results:
        marker = f" ({count} bugs)" if count else ""
        lines.append(f"  {url}{marker}")
    lines.append(f"\nTotal bugs in session: {len(s.bugs)}")
    return "\n".join(lines)


@mcp.tool()
async def end_session() -> str:
    """End the testing session, close the browser, and generate an HTML error report.

    Returns the path to the generated report and a summary of findings.
    """
    s = _require_session()

    # Final error drain
    console_errs, network_errs = s.browser.drain_errors()
    current_url = s.browser._page.url if s.browser._page else ""
    final_bugs = s.detector.process_console_errors(
        console_errs, current_url, s.steps
    )
    final_bugs.extend(s.detector.process_network_errors(
        network_errs, current_url, s.steps
    ))
    if final_bugs:
        ss_path = await _auto_screenshot(
            s, "final_errors", f"Final errors on {current_url}"
        )
        for bug in final_bugs:
            bug.screenshot_path = ss_path
    s.bugs.extend(final_bugs)

    await s.browser.stop()

    duration = asyncio.get_event_loop().time() - (s.start_time or 0)

    result = ExplorationResult(
        url=s.url or "",
        bugs=s.bugs,
        pages_visited=s.pages_visited,
        actions_taken=len(s.steps),
        duration_seconds=duration,
        focus_areas=s.focus_areas,
        screenshots=s.screenshots,
    )

    output_dir = _output_dir()
    reporter = Reporter()
    report_path = reporter.generate(result, output_dir)

    # Reset session
    global _session
    _session = Session()

    # Build summary
    lines = [
        f"Session ended. Report saved: {report_path}",
        f"",
        f"Summary:",
        f"  Actions taken: {result.actions_taken}",
        f"  Pages visited: {len(result.pages_visited)}",
        f"  Bugs found: {len(result.bugs)}",
        f"  Screenshots: {len(result.screenshots)}",
        f"  Duration: {duration:.1f}s",
    ]
    if result.bugs:
        lines.append("")
        lines.append("Bugs:")
        for bug in result.bugs:
            lines.append(f"  [{bug.severity.value.upper()}] {bug.title}")

    return "\n".join(lines)


def main():
    """Entry point for argus-mcp command."""
    mcp.run()


if __name__ == "__main__":
    main()
