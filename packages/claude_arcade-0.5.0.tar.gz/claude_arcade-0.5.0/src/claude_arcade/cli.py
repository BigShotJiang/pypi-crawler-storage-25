"""CLI entry point for claude-arcade."""

import argparse
import curses
import os
import sys


DESCRIPTION = """\
claude-arcade — play games while Claude thinks

Play a mini-game automatically every time Claude Code runs a tool,
or launch one manually whenever you feel like it.
"""

EPILOG = """\
examples:
  claude-arcade setup        configure Claude Code hooks (one-time setup)
  claude-arcade play         open the game menu
  claude-arcade play bird    jump straight into Bird Hunt
  claude-arcade play pong    jump straight into Pong
  claude-arcade unsetup      remove hooks from Claude Code settings
"""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _launch_game(game_key: str) -> None:
    """Run a game by key (used after menu selection and direct play)."""
    if game_key == "bird":
        from .bird_game import bird_game
        curses.wrapper(bird_game)
    elif game_key == "pong":
        from .pong import pong_game
        curses.wrapper(pong_game)


def _run_menu_then_game() -> None:
    """Show splash + menu, then launch the chosen game."""
    from .splash import show_menu

    def _inner(stdscr):
        game_key = show_menu(stdscr)
        if game_key is None:
            return
        # Clear screen before switching to game
        stdscr.clear()
        stdscr.refresh()
        _launch_game(game_key)

    try:
        curses.wrapper(_inner)
    except KeyboardInterrupt:
        pass


def _open_new_terminal(cmd: str) -> bool:
    """Open a new OS terminal window running cmd. Returns True on success."""
    import subprocess, shutil

    if sys.platform == "darwin":
        if shutil.which("osascript"):
            for app, script in [
                ("iTerm2",   f'tell application "iTerm2" to create window with default profile command "{cmd}"'),
                ("Terminal", f'tell application "Terminal" to do script "{cmd}"'),
            ]:
                try:
                    r = subprocess.run(["osascript", "-e", f'tell application "{app}" to activate'],
                                       capture_output=True, timeout=2)
                    if r.returncode == 0:
                        subprocess.Popen(["osascript", "-e", script])
                        return True
                except Exception:
                    continue
    else:
        for term, flag in [("gnome-terminal", "--"), ("xterm", "-e"),
                            ("konsole", "-e"), ("xfce4-terminal", "-e")]:
            if shutil.which(term):
                try:
                    subprocess.Popen([term, flag] + cmd.split())
                    return True
                except Exception:
                    continue
    return False


def _has_real_tty() -> bool:
    try:
        fd = os.open("/dev/tty", os.O_RDWR)
        os.close(fd)
        return True
    except OSError:
        return False


def _redirect_to_tty() -> None:
    tty_fd = os.open("/dev/tty", os.O_RDWR)
    for fd in (0, 1, 2):
        os.dup2(tty_fd, fd)
    if tty_fd > 2:
        os.close(tty_fd)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:  # noqa: C901
    if sys.platform == "win32":
        print("claude-arcade requires a Unix-like terminal (macOS / Linux).")
        sys.exit(1)

    # ── hidden internal commands (called by hooks / new-window launcher) ──
    if len(sys.argv) >= 2 and sys.argv[1] == "_play_direct":
        # Running inside a fresh terminal window — redirect to /dev/tty then
        # show menu (or jump to specific game if a key was passed as argv[2]).
        _redirect_to_tty()
        if len(sys.argv) >= 3:
            try:
                _launch_game(sys.argv[2])
            except KeyboardInterrupt:
                pass
        else:
            _run_menu_then_game()
        return

    if len(sys.argv) == 2 and sys.argv[1] in ("start", "stop"):
        if sys.argv[1] == "start":
            from .bird_game import start_background
            start_background()
        else:
            from .bird_game import stop_background
            stop_background()
        return

    # ── normal CLI ───────────────────────────────────────────────────────────
    parser = argparse.ArgumentParser(
        prog="claude-arcade",
        description=DESCRIPTION,
        epilog=EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="cmd", metavar="<command>")

    sub.add_parser("setup",   help="Configure Claude Code hooks (one-time setup)")
    sub.add_parser("unsetup", help="Remove Claude Code hooks")

    play_p = sub.add_parser("play", help="Open the game menu (or pass a game name)")
    play_p.add_argument(
        "game",
        nargs="?",
        default=None,
        choices=["bird", "pong"],
        help="Game to jump straight into: bird | pong",
    )

    args = parser.parse_args()

    if args.cmd == "setup":
        from .setup_hooks import setup
        setup()

    elif args.cmd == "unsetup":
        from .setup_hooks import unsetup
        unsetup()

    elif args.cmd == "play":
        import shutil
        bin_path = shutil.which("claude-arcade") or "claude-arcade"

        if _has_real_tty():
            _redirect_to_tty()
            if args.game:
                try:
                    _launch_game(args.game)
                except KeyboardInterrupt:
                    pass
            else:
                _run_menu_then_game()
        else:
            # No tty — open a new terminal window
            print("Opening claude-arcade in a new terminal window...")
            extra = f" {args.game}" if args.game else ""
            if not _open_new_terminal(f"{bin_path} _play_direct{extra}"):
                print("Could not open a terminal window automatically.")
                print(f"Please open a new terminal and run:  claude-arcade play")

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
