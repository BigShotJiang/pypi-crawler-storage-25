# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import base64
import os
import re
import hashlib
from dataclasses import dataclass

from asn1crypto import x509 as asn1_x509
from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, rsa, padding


@dataclass(slots=True)
class DeviceAttestationInputs:
    id: str
    key: str
    attestation_sig: str
    certificate_chain: str | None = None
    created: int | None = None
    attestation_alg: str | None = None
    attestation_payload_version: int | None = None
    trust_profile: str = os.environ.get("LUKUID_TRUST_PROFILE", "prod")
    allow_untrusted_roots: bool = False


@dataclass(slots=True)
class VerificationResult:
    ok: bool
    reason: str | None = None


@dataclass(slots=True)
class ExternalIdentityInputs:
    endorser_id: str
    root_fingerprint: str
    cert_chain_der: list[str]
    signature: str
    expected_payload: str
    trusted_fingerprints: list[str]


# Trusted Root Certificates (PEM)
TRUSTED_ROOT_CERTS_PEM = [
    """-----BEGIN CERTIFICATE-----
MIIVwTCCCL6gAwIBAgIUfooekdqQRLonTDsAm1pbSkPdQMMwCwYJYIZIAWUDBAMS
MDsxCzAJBgNVBAYTAkVVMQ8wDQYDVQQKDAZMdWt1SUQxGzAZBgNVBAMMEkx1a3VJ
RCBQUUMgUm9vdCBDQTAgFw0yNjA0MDExMTEwMjJaGA8yMDU2MDMyNDExMTAyMlow
OzELMAkGA1UEBhMCRVUxDzANBgNVBAoMBkx1a3VJRDEbMBkGA1UEAwwSTHVrdUlE
IFBRQyBSb290IENBMIIHsjALBglghkgBZQMEAxIDggehAPqY2UKfg+Gwft+MLz8K
CQb2Khq9pBNWi40DkSQ48AMr5e7U7OF4SHv1f51n0GxfECb7Rx7OSHaQJwuQL5Ro
aSp3/63gvm+YiHKeXwQcvSecYJIXqlvqfxHQvXyeoQtB4FEOS9fSGdixv1FrrobN
h+XqbZ/i2UBdoekQOM9bLSCbKJzpgNxzGCENRPlssBPpHeqxxOKAmy3zN1avoCzZ
tQt9sKLK/o43YLxwwCVtJSueRr6K2DTTyq/wfqiodGl2OTYSI3oShLkgBKUpQY63
iPJR9AIm7R6Zz+OQLzLwBVpe576vmjU6PmPvhP14V7wRvu7iBD2O438B+BCA2I8x
QY7ezqPF43cSNnIBxOAHlH2qDgVx2hjjKl/Z/VG/mViNuP/8J2pMEa+EktFXsJx8
PK5gehYfJIGp5sMO0KKu90EC7Gk1cfWTp1Aj5Cttb1TrWRiEN3G0QFjGdaqWyJKR
7Mw5RiYL9J8dNOiN2VTD1nepRx2bAhNopEa5KOXV+xo7Z0C2CcAL8K0PNgttFmMk
2rk6pzruxl11AmUC13txcQnI3v0lF1N+6TrAZJwCc0Cg7Nv4yi+V6V9OP2+oqCcw
Xd00aGbY3LxFkyDRC72NpbhShMSyaPaiodbk/R/JyefmDVCXXI0OhY8X3Uk2TFXS
KzXra34uc1578cymGc9RsqRGoq1dhE51UUK1DBEeY2pNvXPZdFs4f+XpSgWMaLZw
6myazHpkX3z7u4ooXBnCcNyTQDpG5WnNr3BVoV58yaaTMmvQV6h5qepb+TNpm7Gc
AIS2UlB8qq+8/p9qRxgriiSBuiP7rth0LHv1Nb7hx6op3j11rYQZ2T+fUj9VWDK4
41H41wlwtp2xDV1DJnvcba0DgjAbw7MTjACnTYDKpM5rFNABLgIXYQT48OKqV2L9
uXnc5mXmWgIhDqDhdSt5qex8N+/jU6pXt7nMA5k0Fu0rG1pSNHYuuWdJ2Tvz2bqb
/HYF15JZ7Xelev66UPaVe3/tz5OVWoXvf1XVPMSv3e9wePkainNeNoQ8aACGJhjM
AHVw1diISewDY916kKSMPpKiM7tHT3vFIPW0k6GGXoa85S/NIRtJE5o3x8ObGKDU
khJO4Kxqo1/w6LnypsvMlCIJsm+8YWjJzWkUlUokbfu4ZrJPRrhXZOYAMmh2hu44
P53bekSz68Unc1fTOPPkemjIp2jggjz9xD9A6WZrSAxorpjICh4pnWObWVP6dx6u
JEVRMe2d6IdhOa70muhqv/smZabYUE8i/7nQ32Tser9Rg6sW9xRCWeTtRpP2g6gN
2H1CU2LCfjatDLP3VN+kVF63dzxr/s8BxMUXcAlr57U+rB9FcHGpPXHTN+Z8qwRV
W06TW14Jk+rjlrAW0i5x9CxyP1pzh8EL/u3ysOUJ/jrK3vuK9h2vMyu5/cAPhWGa
jC4CVUB67t+hufpcPc++9rioG0UcPa+YE4EzTUKVhQO6DocAUcds7IZXcOP2/Zj4
yDQUOS8ATmSmoCbAAF+e1C4SVepuBUN1aCYaaFY3+yitEG67//DqvBiQOqu+f2xr
fBSNjfRglWmZy02AHmvY+fvb7HSFRMrVETRC6UCRqXHfzqz6poOigMAMXXM/7RJG
8sOmN40JvqYTwA8FnA/gPIRYZT8mXaGMndwP1Bhk4/MyH/jd4drIy8nUaWddfxH0
p14ld4zWyJQnUPDa5yQIBFZSegdI5p/kyOb74NgZQiRJSRK2hS821/O8qtdvCx/e
KPuXmyuordbCXVHIlZ2SaBIw/IlDyjNMvaejc5AfSL4XetQiFnO642nSn81T1NKT
nR2dsnQ2t3viNG86tfp0T35G2CQnPD+iEnyDRA817okjaa77idSBTPa3KF64vEK0
7D7NSYGTbBYEDxdTMSNVoup3n/AZfOvEsR5dKWwZvgbXmEMCAomcYLz8+Se/qn0L
rlOwbmKFKmTWMKAjMdv8sI+vlCW8XRYt0xVrGiQ35lljVm4lPuBM5+XIG97R9xNj
jdt1U8K8wW4OB8mg5r6rG1JJGAXBiKbwNWiddVS34tpjwpelKoov/vHacLj2gP53
kFOGBGnLaq1ACAqv9yn7UCdJ0h4nYPsd3Eevwz+ZI/2rVSrxnIPsCASheCeGtcMg
5LpewgavMOIZFSWEGnswblrLyPJD1kK5thT7TJiwqYA+PCJ+h6rJ0BTe8UiZOtvy
gLjvqTmjo+iypD6GZdMXKzLENI7UihmAfH9RavJXqcpIDm8vsfDMhm5TOJ+3hXhU
0a1jwNZKxKbULwcY77dpcNA07T+xWXxbJOmu0SMl7U5MO9+zNO5A/5qVO4j5lfz2
Qe6dXYJxc3jlWcfPKlw4PNCRFVR3CifduPZVcoglX0T5u9oO0NKXK2CtYlCEuGNA
pjOnCIPI2cMpiUf5lEH1QMVO/l9xZlT+su+vquoCUvMOv1VPze3fOPWUqM4NZLGH
An3vcUK1EKUcEwSS42kowvCKId1QL1QXdoUffG5K3zt+IfDMzYc6JufdUo+X3Bd5
KUlj1lc7dh8MKDK/jWjrxj8V7zZAq7Tc7/jde/fmKfMWFmxWG9U3nBjYb85AcSE5
vWn2BK/zwI8eimSdNLsY4o5Zo0IwQDAPBgNVHRMBAf8EBTADAQH/MA4GA1UdDwEB
/wQEAwIBBjAdBgNVHQ4EFgQUcW3eH6pWJcD+uoLcPr0TuOYQjXcwCwYJYIZIAWUD
BAMSA4IM7gAoefUnUDQbu8jhreiaeXW4B5nHFq4W0AKz8Tw8CceQxPwrOWwZ16nv
FJYwkMQ4QRU6BjTpAt9b1nZL0JGgbliW1NgJ25/loqlpWJsdGzzYBleKUiOpQvAE
iZaPk61niYug4g3X10iZ935XpvmraYXuRIOraMXaP1gJIbLy1EAAzRm6LEF5JBPZ
zIEbUg2mo1Q3Cm/rSWj4GnAdZ6MwqWoivbuoSBPTmx40uIY4dIm47AqNyl6BFEAD
gwbbI7wuSHWH9+LwdQ5+4SL38zK526fGpWB6NYyfRMLf7TjXvm+p5zcStsvN+SOY
+5xEFwN/EhMPnaqqIkPGNMnIPrdTJ9m0BtNuknSN2daiyLG2OQ7jg+V+ILYQPKXn
9qm+3QH61FgLQnVkxH2ep1RC2h5Z2ROIBCeaLtuQDZUQSYeHKSinIJVKhLQuIhPx
Re9JDfIqquHVuJPElqC5zEC68hWocrTEiIRD/BwfklvO4XSYmD05Mo8ULZYaH7/a
oEpFWCsuzBH7v5Pu2iHHC5OCMs8WcOh2GvnegzMTz0AWCLHg1/g9YOuTk7loGs9e
+vOL1LCdImabTcgEC4MIPZhP6u2puBEerh4X8iDP5NKEdudlyrKeKNAW2P9qfJie
nRgsBoICVlxnsM2rzBRnFCr5wJnJvt45HzG1jXqFL8taEe1IlwyzZEKzOOpmu4aJ
t7quFHcfH2gimwN0tUt1x7LFZ7WMAnRZVw8aadVxVEcht4qYFDWDZIoTpeZ5TniB
y106Jb+e1Rgb9e3e9JxqZUZlSABWJPN/ACDBEWxynGg2XxdD4YwMZwkZgresmGga
unNg6lZkLIrfn541wfS8HbIeG2MGCGeFlFytFHIH94HoSQ38RktY7Q+1mO9qSeSv
WDqpsVfHzBDCAtoM+M9X1etYcJOIXt+pMjn7J2Cngv3+BmPYpSRbhPT08VoJYmhU
YL1HW0RfPiLdVmzseIaL54i2agAbjZH96y1ssL/7iFptZIPdntm1On/mV18til8m
JfYtKRUv4lBU/8Cmc93c5d25jMmd2NoRTPw7h8ngoXtcujNbA1v8SuEwMSQUVj9U
OtNT2Fwng32kbrfyPnW8Xp8SknCM28JV0MjjkR0w6n1Csz7qf6skSbeVz75dJbyA
rMHAZz/Jf8jVekbFfUlpzOqPK8psK2YeTdzeSPM2Q+KXzJh0Gq3c2U3Masdx7G0E
o3V7gTD508r3Iw1dzezpPRNNPwMptiA6VkKXMgndNTKoC1HYOj39wiKnGQMlIYfu
exn8qstwXepbAS5wgMCvneyX8yumIxjrZI9j1bEx0bP6Y/u6RwJSMVPJiuLrme99
7UjR4Soi2O6JnQz7T1wRdTxLYUlg04TgckvJIEWKnGRxbxGpYmRtKK0UZ7Kpyu9h
hxgzm3GWzltU886QXukGdjdB9RRBOTJ5VAMfj5E7ZaeyhIH+zcDtC0v57JW70KUX
DaUfpqDWr0CyIbTOLsGBDl9U7LgKve93cH69ugPlTfTcwhGcgd/QbcKYnpfBII1L
KDE6v3rbSFoVyw3z31RRp2RaGrFy6NzA2HHTcXU4cPif/xfGEFsVDHHCsPT49q8D
c+hRu8SF7tde4kTBJJLezN1mdDBdnJjjTtd7wEsDRN6I+slSpyVHTqvOHvp9lff4
+JXLljMbH/BdOdJTd9EmpjQd5rHcJ9Wb6FQy2BQX5nOYXL+q1RGfLbGdpUcy3f+l
VOwH0e4ES7ovMlRLwfWWbSAmw5WR4qmoqEEOjQ0p3URU7j5L9rszsEJkydMRm6qi
sLtF0V1yX7Jr1SqhUh2I6O9g3+PcqRyb3p6a/ptr4CAytDKWAMTk+YRYL2WGJlmH
ExL3JbWFyaVKNg+H5B/peC59U9P1ixRoMSSAvhWTdgIpMKbwPiXU7V2SFi3H4K2F
Ni/PmLlmqJ5NnPwiM6wjkoTqIPiwgCpC+e0VLiwaY1YKI//sgK6TDX7ZxhN1gCGi
qunxYC9OIdS/wZgYyMg7NRir3IAAZCskMTTt7E3AIt9KLjwoIVB/I3YuDRW+JZPg
aXR4ws6SYk8ac25kw2nptyCRP9m9xCYVl+hmA52udqLPcVszXNU8TJUK+TGG+02M
rbBiHhBQ2xWCriHDcLrxh78nC8mMrL/jPg6RCAFZW+OVjfScT5SobBa4gX24nuZT
RjNpz38WyrBXbsbiTt3+QeEw9wBYSvZtJMO2Hn8EsWO3hjAbHAAFPceNZx/E08rX
4Qbn8zJFhx3O0wj8NolFdZ5vN5mUYoCQnSYKJ2nT5E2bkX+jcyOTC3o8hEzZH5K+
RhK2l5fUCZOyZcMbRlVl6Fu7WUoWTrsOmAp2+h1Tw/xBS6bOTKO+WdUC/S3IPApx
+lmGDbpzhLpgXViwsndmhsbf/1NFXWKkq6t7qjNtaWvMsi3fkESUS5aqAzr5OMOg
O7yCErs0/HDmz6Tq2QYFGpBg0ixgjPPc/IDfFaO9F0IesjGWX/CC58L1CoWKhr3+
daMjPtOlihwM0hAKYA64C9dB6NXBCVKJu3Gg0UyqLVxGzRHevzJcn+SNtFTs6fKW
mZMrR+O99CmFYapCFFPgekYkaOuj5IoHQVqXz2RipmZBYnCCPpAqpIE4DPTJ+f18
D5e8f2gD1/2mwj0kv11y6ao2xDoU2ip8WD8pePwMqF8E82UFdFImOVHAAew+eB2C
yhCBMgmILKjRA8RDsSgfTG8wNlN1FGqA4sjhq0uaP3eD9Gt/Ny+hKu+uRsrK1XOB
3ypPGXfgwv15nmj7XHnd5SORv9vJZrONwXQLTOSKj8au/R6b1zxOwarDrCVNv0mK
W+RXM/77HKqV97xLIGiCMdU71ZEhHjWFYEh87koSHQFOV+hPTv2uAtySJt/su5dL
oZMdzArGz4W3jlYEXFkBJa338c9PkPCFou1UuZ4UwE+yrFxxXkttfmpByKWOLkl+
gapypRbcYkmD+MzGG4i1qILI/+7xs2Td3zjD8blSuws1SHdA8rLojCbaOQID5Jjo
pT6HCq219KItp9u5DkT4NJLxDJm/fXgrFkN4Xn1iX6t4VG4ox4sawfDNiZbBI+uf
Vi/x16yLlPgP6SqcS+GZfwDlWeclwIUAF8ALMTJsL6vDJYTobie001uIDYdNZjfp
Sd9gQrF7Dv7Lm7KK4gtNAj1fkr4o5bu4Ii/jQywEY6XHS77unxlwXOl7SFEHw1q4
rvZhUUlaOYOCQD5jWzozJy/ZcHoZjc4A2wbvEVo/GbvovmFfdBOtN1x7WPSJ8M/e
shKZLMMWrIB0OzbyFvZ3ZtXFnJUq5eCHSV14g5KD2gTBCRBV2ztrOQ3K6UDtEHhO
cO8JInmvFcYeIV3tg3IvolxqvBoGrvDoDGNnQ8ALnBls62vDgeOddot/rLxL8yNS
MG05z9wBan4rOCwSVmADxOzdd9X08JTsrv+myBluc0rZ36rApvaxEDC8woohZXEi
/jx5CxLm1WIjnH6YQHZaD/e2947Q0FglcIg2LOWDJhfcnt+2/+L5ne3Bs9XMNwKC
ZFr68MQXHC9j1Fgf4HZcp3kfakeWt2YiSCTPjQNwlt+9oD1lNQnEA8wX8z39Uuh2
SwWN/Rn1cLZi2t/wMoTPiTi75jhOYVp3zsST4iTtoka0sOyVjBrCi4/eArPa/UTE
NwUQHvnIx/BRzNDkT0fw5GwcB3F4XfRkE4xDoUozFaltZEBSTDa8lI9BoTiCgcmP
atrqRkMhZIqaIst3TZTFOTQNUcLSF3smGANOFYENsU5jGoDB7D85DdiDnWqkYs94
oQCGIzyfjz1Z8kY6kOopAw80ZSn1bEkMLDpjiYwoKihzc8IY7cqVKJWRC9qJQYpR
cCB2e8TMS3f689TqoLsMKKEGe1jFX0M16iwXRJq9Oviz4AtT7hB18vJCy8RyHaIt
R0Z60uwdoDxnrqbKYxQaDvM+5C53uIST61isl9MEIVNaRHiDj3iQ2u1005h283ZX
4sric2DSqRx+AaogeXsZIZxaOJdiAhfx6DwQzXJ5DL4ObFfoSPjJ/CbHUXImU1yF
kl2h0SlPEKBPAhm9/PUN3wPVB1QehPnMeK7mnIFsguAzP34cOXwqPH+u/pCErlKp
FWHU5R3oSudVivNcPk7c9qrhOZDIzXsha5t0wWWESiBWGu5guL73z1psilk3nld8
EROMUkI09paLBpLBWKd0rJFpKhJWHqQHVYSH+Iv6Wc3F486rC51n/5q3ryJpvcu/
haYPGBrQyH4iiaC6OjOVP4H7JJ8jxWYS7Aa64ldqsygDXAQqznXdBIMHDRu5m+gY
ETdmmR0d7WfDe8lq/zPdEt8TbhjwmhKUDkjZlslFx61LJU1stQTcIzdXWn6MtNvh
7PQXQH7U2Gdqv97vWNl1zd8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAK
DxQWGRk=
-----END CERTIFICATE-----"""
]

_CERT_PATTERN = re.compile(
    r"-----BEGIN CERTIFICATE-----[\s\S]*?-----END CERTIFICATE-----"
)
_ED25519_SPKI_PREFIX = bytes.fromhex("302a300506032b6570032100")
_PQC_SIGNATURE_ALGORITHMS = {
    "2.16.840.1.101.3.4.3.17": "ML-DSA-44",
    "2.16.840.1.101.3.4.3.18": "ML-DSA-65",
    "2.16.840.1.101.3.4.3.19": "ML-DSA-87",
}
_oqs_module: object | None | bool = False


from .revocation import RevocationManager


def verify_device_attestation(
    inputs: DeviceAttestationInputs,
    revocation_manager: RevocationManager | None = None
) -> VerificationResult:
    if not inputs.attestation_sig:
        return VerificationResult(False, "attestationSig missing")

    try:
        signature_bytes = base64.b64decode(inputs.attestation_sig, validate=True)
    except Exception:
        return VerificationResult(False, "attestationSig is not valid base64")

    payload = f"{inputs.id}:{inputs.key}".encode("utf-8")
    leaf_public_key_pem: str | None = None

    if inputs.certificate_chain:
        certs_pem = _CERT_PATTERN.findall(inputs.certificate_chain)
        if not certs_pem:
            return VerificationResult(False, "Invalid certificate chain PEM")

        try:
            certs = [x509.load_pem_x509_certificate(p.encode("utf-8")) for p in certs_pem]

            leaf_meta = _certificate_metadata(certs_pem[0])

            leaf_public_key_pem = leaf_meta["public_key_pem"]

        except Exception as exc:
            return VerificationResult(False, f"Chain processing error: {exc}")

        required_ou = {
            "dev": "lukuid-dev",
            "test": "lukuid-test",
            "prod": "lukuid-production",
        }.get(inputs.trust_profile, "lukuid-production")

        has_valid_profile = False
        try:
            for cert_pem in certs_pem[1:]:
                subject = _certificate_metadata(cert_pem)["subject"]
                if required_ou in subject:
                    has_valid_profile = True
                    break
        except Exception as exc:
            return VerificationResult(False, f"Chain processing error: {exc}")

        if not has_valid_profile:
            return VerificationResult(
                False,
                f"Certificate chain does not match the requested trust profile: {inputs.trust_profile}",
            )

        # Enforce full end-to-end PQC chain-signature validation.
        for i in range(len(certs_pem)):
            cert_pem = certs_pem[i]
            verified = False
            if i + 1 < len(certs_pem):
                next_cert_pem = certs_pem[i+1]
                next_meta = _certificate_metadata(next_cert_pem)
                next_pub_pem = next_meta["public_key_pem"]
                if _verify_cert_signature(cert_pem, next_pub_pem, next_cert_pem):
                    verified = True
            else:
                for root_pem in TRUSTED_ROOT_CERTS_PEM:
                    try:
                        root_meta = _certificate_metadata(root_pem)
                        if _verify_cert_signature(cert_pem, root_meta["public_key_pem"], root_pem):
                            verified = True
                            break
                    except Exception:
                        continue
            
            if not verified:
                if i + 1 == len(certs) and inputs.allow_untrusted_roots:
                    # Only bypass if we are at the top of the chain (the root anchor)
                    verified = True

            if not verified:
                return VerificationResult(False, f"Signature verification failed at chain level {i}")

            # Revocation Check: Check every certificate in the chain (After verification)
            if revocation_manager:
                for cert in certs:
                    if revocation_manager.is_revoked(cert):
                        return VerificationResult(False, f"Certificate is revoked: {revocation_manager.get_fingerprint(cert)}")

            if inputs.created:
                try:
                    for cert_obj in certs:
                        valid_from = int(cert_obj.not_valid_before_utc.timestamp())
                        valid_to = int(cert_obj.not_valid_after_utc.timestamp())
                        if inputs.created < valid_from or inputs.created > valid_to:
                            return VerificationResult(
                                False,
                                f"Temporal birth check failed: created ({inputs.created}) is outside cert window [{valid_from} - {valid_to}]",
                            )
                except Exception as exc:
                    return VerificationResult(False, f"Chain processing error: {exc}")

    if leaf_public_key_pem is not None:
        if _verify_signature_with_pem(leaf_public_key_pem, payload, signature_bytes):
            return VerificationResult(True)
        return VerificationResult(False, "Attestation verification failed against leaf")

    for root_pem in TRUSTED_ROOT_CERTS_PEM:
        try:
            root_meta = _certificate_metadata(root_pem)
            if _verify_signature_with_pem(root_meta["public_key_pem"], payload, signature_bytes):
                return VerificationResult(True)
        except Exception:
            continue

    return VerificationResult(False, "Attestation verification failed")


def verify_detached_signature(public_key_base64: str, payload: bytes, signature_base64: str) -> bool:
    try:
        raw_public_key = base64.b64decode(public_key_base64, validate=True)
        signature = base64.b64decode(signature_base64, validate=True)
    except Exception:
        return False

    if len(raw_public_key) < 32:
        return False
    if len(signature) != 64:
        return False

    public_key_pem = _ed25519_public_key_pem(raw_public_key[:32])
    return _verify_signature_with_pem(public_key_pem, payload, signature)


def verify_external_identity(
    inputs: ExternalIdentityInputs,
    revocation_manager: RevocationManager | None = None
) -> VerificationResult:
    try:
        signature_bytes = base64.b64decode(inputs.signature, validate=True)
    except Exception:
        return VerificationResult(False, "signature is not valid base64")

    if not inputs.cert_chain_der:
        return VerificationResult(False, "Certificate chain is empty")

    certs = []
    for der_b64 in inputs.cert_chain_der:
        try:
            der = base64.b64decode(der_b64)
            cert = x509.load_der_x509_certificate(der)
            certs.append(cert)
        except Exception:
            return VerificationResult(False, "Failed to parse X509 certificate in chain")

    # Revocation Check: Check every certificate in the chain
    if revocation_manager:
        for cert in certs:
            if revocation_manager.is_revoked(cert):
                return VerificationResult(False, f"External identity certificate is revoked: {revocation_manager.get_fingerprint(cert)}")

    root_cert = certs[-1]
    root_der = root_cert.public_bytes(serialization.Encoding.DER)

    actual_root_fingerprint = hashlib.sha256(root_der).hexdigest()
    
    if actual_root_fingerprint != inputs.root_fingerprint.lower():
        return VerificationResult(False, f"Root fingerprint mismatch: expected {inputs.root_fingerprint}, got {actual_root_fingerprint}")

    trusted = actual_root_fingerprint in {f.lower() for f in inputs.trusted_fingerprints}
    
    if not trusted:
        for root_pem in TRUSTED_ROOT_CERTS_PEM:
            try:
                root_der_trusted = base64.b64decode(_pem_to_der_b64(root_pem))
                if hashlib.sha256(root_der_trusted).hexdigest() == actual_root_fingerprint:
                    leaf_pem = pem_from_der_string(inputs.cert_chain_der[0])
                    if leaf_pem:
                        leaf_cert = x509.load_pem_x509_certificate(leaf_pem.encode("utf-8"))
                        if any(
                            ext.oid.dotted_string == "1.3.6.1.4.1.65432.1.4"
                            for ext in leaf_cert.extensions
                        ):
                            trusted = True
                            break
            except Exception:
                continue

    if not trusted:
        return VerificationResult(False, f"Root fingerprint {actual_root_fingerprint} is not in the trusted list")

    leaf_pem = pem_from_der_string(inputs.cert_chain_der[0])
    if not leaf_pem:
        return VerificationResult(False, "Invalid leaf certificate")
    
    leaf_meta = _certificate_metadata(leaf_pem)
    if _verify_signature_with_pem(leaf_meta["public_key_pem"], inputs.expected_payload.encode("utf-8"), signature_bytes):
        return VerificationResult(True)    
    return VerificationResult(False, "External identity signature verification failed")


def sign_detached(private_key_pem: str, payload: bytes) -> str:
    private_key = serialization.load_pem_private_key(private_key_pem.encode("utf-8"), password=None)
    if not isinstance(private_key, ed25519.Ed25519PrivateKey):
        raise ValueError("Expected Ed25519 private key")
    return base64.b64encode(private_key.sign(payload)).decode("ascii")


def public_key_base64_from_private_key_pem(private_key_pem: str) -> str:
    private_key = serialization.load_pem_private_key(private_key_pem.encode("utf-8"), password=None)
    if not isinstance(private_key, ed25519.Ed25519PrivateKey):
        raise ValueError("Expected Ed25519 private key")
    public_key_bytes = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return base64.b64encode(public_key_bytes).decode("ascii")


def generate_signer() -> tuple[str, str]:
    private_key = ed25519.Ed25519PrivateKey.generate()
    private_key_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("utf-8")
    public_key_base64 = base64.b64encode(
        private_key.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
    ).decode("ascii")
    return private_key_pem, public_key_base64


def pem_from_der_string(value: str | None) -> str | None:
    if not value:
        return None
    try:
        der_bytes = base64.b64decode(value)
    except Exception:
        return None
    body = base64.encodebytes(der_bytes).decode("ascii").replace("\n", "")
    lines = [body[index:index + 64] for index in range(0, len(body), 64)]
    return "-----BEGIN CERTIFICATE-----\n" + "\n".join(lines) + "\n-----END CERTIFICATE-----\n"


def _verify_signature_with_pem(public_key_pem: str, payload: bytes, signature: bytes) -> bool:
    try:
        public_key = serialization.load_pem_public_key(public_key_pem.encode("utf-8"))
        return _verify_signature_with_public_key(public_key, payload, signature)
    except Exception:
        return False



def _verify_cert_signature(cert_pem: str, issuer_pub_pem: str | None, issuer_cert_pem: str | None = None) -> bool:
    try:
        cert = x509.load_pem_x509_certificate(cert_pem.encode('utf-8'))
        if issuer_pub_pem:
            issuer_pk = serialization.load_pem_public_key(issuer_pub_pem.encode('utf-8'))
            if _verify_certificate_signature_with_public_key(cert, issuer_pk):
                return True
    except Exception:
        pass

    if issuer_cert_pem:
        oqs_result = _verify_certificate_signature_with_oqs(cert_pem, issuer_cert_pem)
        if oqs_result is not None:
            return oqs_result

    return False


def _certificate_metadata(cert_pem: str, include_pubkey: bool = True) -> dict[str, any]:
    cert = x509.load_pem_x509_certificate(cert_pem.encode("utf-8"))
    public_key_pem = None
    if include_pubkey:
        try:
            public_key_pem = cert.public_key().public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo,
            ).decode("utf-8")
        except Exception:
            public_key_pem = None

    return {
        "subject": cert.subject.rfc4514_string(),
        "issuer": cert.issuer.rfc4514_string(),
        "not_before": int(cert.not_valid_before_utc.timestamp()),
        "not_after": int(cert.not_valid_after_utc.timestamp()),
        "public_key_pem": public_key_pem,
        "sig_len": len(cert.signature),
    }


def _ed25519_public_key_pem(raw_public_key: bytes) -> str:
    der = _ED25519_SPKI_PREFIX + raw_public_key
    body = base64.encodebytes(der).decode("ascii").replace("\n", "")
    lines = [body[index:index + 64] for index in range(0, len(body), 64)]
    return "-----BEGIN PUBLIC KEY-----\n" + "\n".join(lines) + "\n-----END PUBLIC KEY-----\n"


def _pem_to_der_b64(pem: str) -> str:
    return pem.replace("-----BEGIN CERTIFICATE-----", "").replace("-----END CERTIFICATE-----", "").replace("\n", "").replace("\r", "").replace(" ", "")


def _verify_signature_with_public_key(public_key: object, payload: bytes, signature: bytes) -> bool:
    try:
        if isinstance(public_key, ed25519.Ed25519PublicKey):
            public_key.verify(signature, payload)
            return True
        if isinstance(public_key, ec.EllipticCurvePublicKey):
            public_key.verify(signature, payload, ec.ECDSA(hashes.SHA256()))
            return True
        if isinstance(public_key, rsa.RSAPublicKey):
            public_key.verify(signature, payload, padding.PKCS1v15(), hashes.SHA256())
            return True
    except InvalidSignature:
        return False
    except Exception:
        return False
    return False


def _verify_certificate_signature_with_public_key(cert: x509.Certificate, issuer_public_key: object) -> bool:
    try:
        if isinstance(issuer_public_key, ec.EllipticCurvePublicKey):
            issuer_public_key.verify(
                cert.signature,
                cert.tbs_certificate_bytes,
                ec.ECDSA(cert.signature_hash_algorithm),
            )
            return True
        if isinstance(issuer_public_key, ed25519.Ed25519PublicKey):
            issuer_public_key.verify(cert.signature, cert.tbs_certificate_bytes)
            return True
        if isinstance(issuer_public_key, rsa.RSAPublicKey):
            issuer_public_key.verify(
                cert.signature,
                cert.tbs_certificate_bytes,
                padding.PKCS1v15(),
                cert.signature_hash_algorithm,
            )
            return True
    except InvalidSignature:
        return False
    except Exception:
        return False
    return False


def _verify_certificate_signature_with_oqs(cert_pem: str, issuer_cert_pem: str) -> bool | None:
    oqs_module = _get_oqs_module()
    if oqs_module is None:
        return None

    try:
        cert = x509.load_pem_x509_certificate(cert_pem.encode("utf-8"))
    except Exception:
        return None

    algorithm = _PQC_SIGNATURE_ALGORITHMS.get(cert.signature_algorithm_oid.dotted_string)
    if algorithm is None:
        return None

    try:
        enabled = set(oqs_module.get_enabled_sig_mechanisms())
    except Exception:
        return False

    if algorithm not in enabled:
        return False

    issuer_public_key = _extract_subject_public_key_bytes_from_cert(issuer_cert_pem)
    if not issuer_public_key:
        return False

    try:
        with oqs_module.Signature(algorithm) as verifier:
            return bool(verifier.verify(cert.tbs_certificate_bytes, cert.signature, issuer_public_key))
    except Exception:
        return False


def _extract_subject_public_key_bytes_from_cert(cert_pem: str) -> bytes | None:
    try:
        cert_der = base64.b64decode(_pem_to_der_b64(cert_pem), validate=True)
        cert = asn1_x509.Certificate.load(cert_der)
        spki = cert["tbs_certificate"]["subject_public_key_info"]

        # We parse the inner ASN.1 manually to avoid KeyError on unknown PQC algorithm OIDs 
        # that asn1crypto.keys.PublicKeyInfo throws when it tries to map the spec.
        from asn1crypto import parser
        spki_contents = spki.contents
        if not spki_contents:
            return None

        # SubjectPublicKeyInfo is SEQUENCE { algorithm AlgorithmIdentifier, subjectPublicKey BIT STRING }
        _, consumed = parser._parse(spki_contents, len(spki_contents), 0)
        pk_info, _ = parser._parse(spki_contents, len(spki_contents), consumed)

        # pk_info[4] is the contents of the BIT STRING
        contents = pk_info[4]
        if isinstance(contents, bytes) and len(contents) > 0:
            if contents[0] == 0:
                return contents[1:]
            return contents
    except Exception:
        return None

    return None


def _get_oqs_module() -> object | None:
    global _oqs_module
    if _oqs_module is False:
        try:
            import oqs as imported_oqs
            if hasattr(imported_oqs, "Signature") and hasattr(imported_oqs, "get_enabled_sig_mechanisms"):
                _oqs_module = imported_oqs
            else:
                _oqs_module = None
        except BaseException:
            _oqs_module = None
    return None if _oqs_module is False else _oqs_module
