"""Shell process entry point: `python -m meeting_helper.shell`.

Responsibilities:
  1. Load config (port, etc.) via the existing `get_config()`.
  2. Wait for the daemon to respond on /health (the user is expected to
     have run `meeting-helper start` already — same UX as today's Flet GUI).
  3. Open the pywebview window pointed at the daemon URL.
  4. Run a background supervisor thread: if the daemon dies (e.g. after a
     workspace switch via POST /workspace/activate sends itself SIGTERM)
     re-spawn it so the UI keeps working without manual intervention.
  5. Block on `webview.start()` until the window is closed.

Dev mode: if `MH_SHELL_DEV=1`, the URL points at the Next.js dev server
(`http://localhost:3000/`) instead of the daemon-served bundle. This lets the
frontend hot-reload during development. Plan 2 introduces the Next.js project.
"""

from __future__ import annotations

import asyncio
import atexit
import os
import subprocess
import sys
import threading
import time

from meeting_helper.config import GUI_PID_FILE, get_config
from meeting_helper.shell import daemon_link
from meeting_helper.shell.window import create_window


def _dev_url_override() -> str | None:
    if os.environ.get("MH_SHELL_DEV") == "1":
        return os.environ.get("MH_SHELL_DEV_URL", "http://localhost:3000/")
    return None


_SPAWN_COOLDOWN_S = 8.0  # Don't try to respawn more than once per 8s.
from meeting_helper.shell.spawn import (  # noqa: E402 — kept after _SPAWN_COOLDOWN_S to preserve module order
    DAEMON_SPAWN_LOG as _DAEMON_SPAWN_LOG,
    spawn_daemon as _spawn_daemon,
)


_SHELL_LOG_PATH = os.path.expanduser("~/.meeting-helper-shell.log")


def _supervisor_log(msg: str) -> None:
    """Append a timestamped line to the shell log so we can debug after the fact.

    Writes to ``~/.meeting-helper-shell.log`` directly so the log survives
    even when the shell was launched in a way that doesn't redirect stderr
    (e.g. via the auto-updater's ``meeting-helper gui`` Popen with stdout
    redirected to /dev/null, or from the .app bundle's LaunchServices).
    """
    from datetime import datetime
    line = f"[{datetime.now().isoformat(timespec='seconds')}] supervisor: {msg}\n"
    try:
        with open(_SHELL_LOG_PATH, "a") as fh:
            fh.write(line)
    except Exception:
        pass
    try:
        sys.stderr.write(line)
        sys.stderr.flush()
    except Exception:
        pass


def _daemon_healthy(health_url: str, timeout: float = 2.0) -> bool:
    import urllib.request
    import urllib.error
    try:
        with urllib.request.urlopen(health_url, timeout=timeout) as r:
            return r.status == 200
    except (urllib.error.URLError, OSError, TimeoutError):
        return False


def _supervise_daemon(daemon_url: str, stop_event: threading.Event) -> None:
    """Background watchdog: respawn the daemon if it dies (e.g. workspace switch).

    Polls /health every 3s. After the daemon is unreachable for >5s, runs
    `meeting-helper start` and then waits up to 15s for the new daemon to
    answer /health. Refuses to spawn more than once every 30s to avoid
    thrashing if the daemon keeps crashing on startup. Daemon stderr/stdout
    go to `~/.meeting-helper-daemon-spawn.log` so failures are diagnosable.
    """
    health_url = daemon_url.rstrip("/") + "/health"
    down_since: float | None = None
    last_spawn: float = 0.0
    while not stop_event.wait(3.0):
        if _daemon_healthy(health_url):
            down_since = None
            continue
        # Daemon unreachable.
        if down_since is None:
            down_since = time.monotonic()
            continue
        # Workspace switches and `meeting-helper stop` both kill the daemon
        # intentionally; we want to respawn quickly, so a 2s grace is enough
        # to distinguish a real crash from a transient hiccup.
        if time.monotonic() - down_since < 2.0:
            continue
        if time.monotonic() - last_spawn < _SPAWN_COOLDOWN_S:
            continue
        # Down >5s and outside cooldown — try to respawn.
        _supervisor_log(f"daemon at {daemon_url} is down — respawning")
        last_spawn = time.monotonic()
        try:
            _spawn_daemon()
        except Exception as exc:
            _supervisor_log(f"spawn failed: {exc!r}")
            continue
        # Wait up to 30s for the new daemon to become healthy. Cold start
        # can be slow when the audio init has to enumerate devices or the
        # MCP transport handshakes on the network.
        deadline = time.monotonic() + 30.0
        while time.monotonic() < deadline:
            if stop_event.wait(1.0):
                return
            if _daemon_healthy(health_url):
                _supervisor_log("daemon back online")
                down_since = None
                break
        else:
            _supervisor_log(
                "daemon did NOT become healthy after spawn — check "
                f"{_DAEMON_SPAWN_LOG} for the daemon's stderr"
            )
            # Reset the downtime clock so the next tick re-evaluates from
            # now (otherwise `down_since` stays pinned to the original
            # failure and the cooldown becomes the only gate).
            down_since = time.monotonic()


def _is_launched_from_app_bundle() -> bool:
    """True when this process was launched by macOS LaunchServices from
    Meeting Helper.app (vs invoked manually from a terminal or by the
    menubar).

    macOS sets ``__CFBundleIdentifier`` in the env of any process it
    spawns from an .app bundle. The launcher script uses ``exec`` so the
    env is inherited by the Python interpreter.
    """
    return os.environ.get("__CFBundleIdentifier") == "com.victor.meeting-helper"


def _evict_existing_shell(existing_pid: int) -> None:
    """SIGTERM the existing shell and wait for it to release GUI_PID_FILE.

    Used when the .app bundle launches a fresh shell while a stale one is
    still recorded in the pid file. A 5 s SIGTERM grace is followed by a
    SIGKILL if the old process is wedged.
    """
    import signal
    try:
        os.kill(existing_pid, signal.SIGTERM)
    except OSError:
        return
    deadline = time.monotonic() + 5.0
    while time.monotonic() < deadline:
        try:
            os.kill(existing_pid, 0)
        except OSError:
            return  # gone
        time.sleep(0.1)
    try:
        os.kill(existing_pid, signal.SIGKILL)
    except OSError:
        pass


def _enforce_single_instance() -> bool:
    """Refuse to start a second shell when one is already running.

    Returns True if this is the only shell instance; False if another
    shell already holds GUI_PID_FILE (caller should sys.exit).

    Two behaviours depending on how this process was launched:

    1. **Launched from Meeting Helper.app** (user double-clicked the
       app icon or hit it from Spotlight) — kill the existing shell and
       take over. Focus-and-exit looks fine from the terminal but causes
       macOS to remove the dock icon ~60ms after launch, because the
       .app's anchor process exits. The user just told the OS "open
       this app", so we honour that with a fresh, dock-anchored window.

    2. **Launched from a terminal or the menubar** — focus the existing
       shell's window via NSRunningApplication and exit. This keeps
       ``meeting-helper gui`` idempotent for power users.

    On a stale or missing pid file, writes our own PID and registers an
    atexit cleanup.
    """
    if GUI_PID_FILE.exists():
        try:
            existing_pid = int(GUI_PID_FILE.read_text().strip())
        except (ValueError, OSError):
            existing_pid = -1
        if existing_pid > 0 and existing_pid != os.getpid():
            try:
                os.kill(existing_pid, 0)  # raises if not alive
                alive = True
            except (ProcessLookupError, PermissionError, OSError):
                alive = False
            if alive:
                if _is_launched_from_app_bundle():
                    print(
                        f"meeting-helper: replacing stale shell (pid={existing_pid}) "
                        "— launched from .app",
                        file=sys.stderr,
                    )
                    _evict_existing_shell(existing_pid)
                    # Fall through to register ourselves below.
                else:
                    try:
                        from AppKit import (  # type: ignore
                            NSApplicationActivateIgnoringOtherApps,
                            NSRunningApplication,
                        )
                        app = NSRunningApplication.runningApplicationWithProcessIdentifier_(
                            existing_pid
                        )
                        if app is not None:
                            app.activateWithOptions_(NSApplicationActivateIgnoringOtherApps)
                            print(
                                f"meeting-helper: shell already running (pid={existing_pid}), focused it.",
                                file=sys.stderr,
                            )
                            return False
                    except Exception:
                        pass
                    print(
                        f"meeting-helper: shell already running (pid={existing_pid}). Quit it first.",
                        file=sys.stderr,
                    )
                    return False

    try:
        GUI_PID_FILE.parent.mkdir(parents=True, exist_ok=True)
        GUI_PID_FILE.write_text(str(os.getpid()))
    except OSError:
        return True

    def _cleanup_pid() -> None:
        try:
            if GUI_PID_FILE.exists():
                stored = GUI_PID_FILE.read_text().strip()
                if stored == str(os.getpid()):
                    GUI_PID_FILE.unlink(missing_ok=True)
        except Exception:
            pass

    atexit.register(_cleanup_pid)
    return True


def _kill_stale_shells() -> None:
    """SIGTERM any other `python -m meeting_helper.shell` processes.

    Belt-and-braces alongside the pid-file guard in
    ``_enforce_single_instance``. The pid file alone misses orphan shells
    whose pid file was cleaned up but whose Python process is still alive
    (a force-quit during cleanup, or a stale process from a previous version
    that didn't write a pid file).

    Iterates `psutil.process_iter` and sends SIGTERM to any process whose
    cmdline contains "meeting_helper.shell" and whose pid isn't ours. Errors
    on individual processes (gone, permission denied) are swallowed so a
    single weird process can't block startup.
    """
    import psutil
    import signal
    me = os.getpid()
    for proc in psutil.process_iter(["pid", "cmdline"]):
        try:
            info = proc.info
            cmdline_parts = info.get("cmdline") or []
            if not cmdline_parts:
                continue
            cmdline = " ".join(cmdline_parts)
            if info["pid"] != me and "meeting_helper.shell" in cmdline:
                try:
                    proc.send_signal(signal.SIGTERM)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue


def _set_macos_activation_policy() -> None:
    """Force NSApplicationActivationPolicyRegular so the dock shows our window.

    Without setting an explicit activation policy, pywebview-launched Python
    inherits the interpreter's default identity and the macOS dock displays
    a generic "Python" rocket icon. Setting `Regular` is the cleanest way to
    keep a real dock entry while making sure the process is the foreground
    application. Failures are silently swallowed — on non-mac platforms or
    when AppKit isn't importable we just keep the default behaviour.
    """
    try:
        from AppKit import (  # type: ignore
            NSApplication,
            NSApplicationActivationPolicyRegular,
        )
        NSApplication.sharedApplication().setActivationPolicy_(
            NSApplicationActivationPolicyRegular
        )
    except Exception:
        pass


def main() -> int:
    if not _enforce_single_instance():
        return 0

    # We're the chosen shell — torch any sibling shell processes that
    # somehow slipped past the pid-file guard before bringing up the UI.
    _kill_stale_shells()

    _set_macos_activation_policy()

    import webview  # imported lazily so tests can stub it

    config = get_config()
    daemon_url = daemon_link.resolve_url(config)
    url = _dev_url_override() or daemon_url

    ok = asyncio.run(daemon_link.wait_for_health(daemon_url, timeout=15.0))
    if not ok:
        print(
            f"meeting-helper: daemon at {daemon_url} did not respond. "
            "Start it first with `meeting-helper start`, then try again.",
            file=sys.stderr,
        )
        return 1

    stop_supervisor = threading.Event()
    supervisor = threading.Thread(
        target=_supervise_daemon,
        args=(daemon_url, stop_supervisor),
        daemon=True,
    )
    supervisor.start()

    create_window(url=url)
    debug = os.environ.get("MH_SHELL_DEBUG") == "1"
    # pywebview defaults to `private_mode=True` which keeps localStorage
    # in-memory only — every relaunch wipes it. We want sidebar collapse
    # state and similar UI preferences to survive a quit/relaunch, so
    # opt into a persistent WebKit storage path under the user's
    # config dir (alongside other meeting-helper state).
    storage_path = os.path.expanduser("~/.config/meeting-helper/webview")
    os.makedirs(storage_path, exist_ok=True)
    try:
        webview.start(debug=debug, private_mode=False, storage_path=storage_path)
    finally:
        stop_supervisor.set()
    return 0


if __name__ == "__main__":
    sys.exit(main())
