import pytest
from meeting_helper.chat.agent_loop import run_agent
from meeting_helper.chat.registry import Registry, Tool


class _StubProvider:
    """Drives a canned sequence of provider responses."""

    def __init__(self, sequence):
        self.sequence = list(sequence)
        self.calls = []

    async def stream_completion(self, *, system, messages, tools):
        self.calls.append({"messages": messages, "tools": tools})
        resp = self.sequence.pop(0)
        for chunk in resp.get("chunks", []):
            yield {"type": "chunk", "text": chunk}
        for tu in resp.get("tool_uses", []):
            yield {"type": "tool_use", "id": tu["id"], "name": tu["name"], "input": tu["input"]}
        yield {"type": "done", "stop_reason": resp.get("stop_reason", "end_turn")}


@pytest.mark.asyncio
async def test_simple_text_reply_no_tools():
    chunks_seen = []
    tool_calls = []
    tool_results = []

    async def on_chunk(t): chunks_seen.append(t)
    async def on_tool_call(name, args): tool_calls.append((name, args)); return None
    async def on_tool_result(name, result): tool_results.append((name, result))

    provider = _StubProvider([
        {"chunks": ["Hello ", "world."]},
    ])
    out = await run_agent(
        system="sys",
        messages=[{"role": "user", "content": "hi"}],
        registry=Registry(),
        provider=provider,
        on_chunk=on_chunk,
        on_tool_call=on_tool_call,
        on_tool_result=on_tool_result,
    )
    assert chunks_seen == ["Hello ", "world."]
    assert tool_calls == []
    assert out["text"] == "Hello world."
    assert out["error"] is None


@pytest.mark.asyncio
async def test_tool_use_then_final_text():
    calls = []

    async def _run(args, ctx): return {"status": "ok", "result": {"count": 3}}
    reg = Registry()
    reg.register(Tool(name="my.search", description="d", input_schema={"q": "string"}, run=_run))

    async def on_chunk(t): pass
    async def on_tool_call(name, args): calls.append((name, args)); return None
    async def on_tool_result(name, result): pass

    provider = _StubProvider([
        {"tool_uses": [{"id": "tu1", "name": "my.search", "input": {"q": "x"}}]},
        {"chunks": ["Found ", "3."]},
    ])
    out = await run_agent(
        system="sys",
        messages=[{"role": "user", "content": "search"}],
        registry=reg,
        provider=provider,
        on_chunk=on_chunk,
        on_tool_call=on_tool_call,
        on_tool_result=on_tool_result,
    )
    assert calls == [("my.search", {"q": "x"})]
    assert out["text"] == "Found 3."


@pytest.mark.asyncio
async def test_cycle_limit_stops_runaway():
    async def _run(args, ctx): return {"status": "ok", "result": {}}
    reg = Registry()
    reg.register(Tool(name="t", description="d", input_schema={}, run=_run))

    provider = _StubProvider([
        {"tool_uses": [{"id": f"tu{i}", "name": "t", "input": {}}]}
        for i in range(12)
    ])
    async def _noop(*a, **k): pass

    out = await run_agent(
        system="sys",
        messages=[{"role": "user", "content": "loop"}],
        registry=reg,
        provider=provider,
        on_chunk=_noop,
        on_tool_call=_noop,
        on_tool_result=_noop,
        max_cycles=10,
    )
    assert out["error"] == "tool_cycle_limit_exceeded"


@pytest.mark.asyncio
async def test_default_max_cycles_is_30():
    import inspect
    from meeting_helper.chat.agent_loop import run_agent
    sig = inspect.signature(run_agent)
    assert sig.parameters["max_cycles"].default == 30


@pytest.mark.asyncio
async def test_mutating_tool_calls_callback_and_uses_result():
    async def _run(args, ctx): return {"status": "ok", "result": {"posted": True}}
    reg = Registry()
    reg.register(Tool(name="m.post", description="d", input_schema={"b": "string"}, run=_run, is_mutation=True))

    confirmations = []
    async def on_tool_call(name, args):
        confirmations.append((name, args))
        return {"decision": "approve", "edited_args": None}
    async def on_chunk(t): pass
    async def on_tool_result(name, result): pass

    provider = _StubProvider([
        {"tool_uses": [{"id": "tu1", "name": "m.post", "input": {"b": "hi"}}]},
        {"chunks": ["OK."]},
    ])
    out = await run_agent(
        system="sys",
        messages=[{"role": "user", "content": "post"}],
        registry=reg,
        provider=provider,
        on_chunk=on_chunk,
        on_tool_call=on_tool_call,
        on_tool_result=on_tool_result,
    )
    assert confirmations == [("m.post", {"b": "hi"})]


@pytest.mark.asyncio
async def test_mutating_tool_cancelled_yields_cancelled_result():
    seen_results = []
    async def _run(args, ctx): return {"status": "ok"}
    reg = Registry()
    reg.register(Tool(name="m.post", description="d", input_schema={}, run=_run, is_mutation=True))

    async def on_tool_call(name, args):
        return {"decision": "cancel"}
    async def on_chunk(t): pass
    async def on_tool_result(name, result): seen_results.append((name, result))

    provider = _StubProvider([
        {"tool_uses": [{"id": "tu1", "name": "m.post", "input": {}}]},
        {"chunks": ["Got it."]},
    ])
    await run_agent(
        system="sys",
        messages=[{"role": "user", "content": "x"}],
        registry=reg,
        provider=provider,
        on_chunk=on_chunk,
        on_tool_call=on_tool_call,
        on_tool_result=on_tool_result,
    )
    assert seen_results[0][1]["status"] == "cancelled"


@pytest.mark.asyncio
async def test_no_tools_provider_ignores_tools_argument():
    from meeting_helper.chat.providers import NoToolsProvider

    captured = {}

    class _Inner:
        async def stream_completion(self, *, system, messages, tools):
            captured["tools"] = tools
            yield {"type": "chunk", "text": "ok"}
            yield {"type": "done"}

    prov = NoToolsProvider(inner=_Inner())
    chunks = []
    async for ev in prov.stream_completion(system="s", messages=[], tools=[{"name": "x"}]):
        if ev["type"] == "chunk":
            chunks.append(ev["text"])
    assert chunks == ["ok"]
    assert captured["tools"] == []


@pytest.mark.asyncio
async def test_build_provider_selects_gemini_when_preferred(monkeypatch):
    from meeting_helper.chat.handlers import _build_provider
    cfg = type("C", (), {
        "preferred_provider": "gemini",
        "google_api_key": "k", "gemini_model": "gemini-2.0-flash",
        "anthropic_api_key": None, "claude_model": None,
    })()
    monkeypatch.setattr(
        "meeting_helper.chat.providers.GeminiProvider",
        lambda **k: type("G", (), {"stream_completion": None})(),
    )
    p = _build_provider(cfg)
    assert p.__class__.__name__ == "G"


@pytest.mark.asyncio
async def test_claude_provider_translates_dotted_tool_names_to_underscores(monkeypatch):
    """Anthropic rejects dots in tool names. ClaudeProvider must translate
    `mcp.search_tasks` -> `mcp_search_tasks` outbound and back on tool_use."""
    from meeting_helper.chat.providers import ClaudeProvider

    captured = {}

    class _FakeStream:
        async def __aenter__(self):
            return self

        async def __aexit__(self, *a):
            return None

        def __aiter__(self):
            async def _gen():
                if False:
                    yield None
            return _gen()

    class _Msgs:
        def stream(self, **kwargs):
            captured["tools"] = kwargs.get("tools")
            return _FakeStream()

    class _Client:
        messages = _Msgs()

    prov = ClaudeProvider.__new__(ClaudeProvider)
    prov._client = _Client()  # type: ignore[attr-defined]
    prov._model = "claude-sonnet-4-6"

    tools = [{"name": "mcp.search_tasks", "description": "d", "input_schema": {"q": "string"}}]
    async for _ in prov.stream_completion(
        system="s", messages=[{"role": "user", "content": "x"}], tools=tools
    ):
        pass

    sent = captured["tools"]
    assert sent[0]["name"] == "mcp_search_tasks"


@pytest.mark.asyncio
async def test_build_provider_falls_back_to_no_tools_for_local(monkeypatch):
    from meeting_helper.chat.handlers import _build_provider
    cfg = type("C", (), {
        "preferred_provider": "local",
        "local_model": "llama3.1:8b", "local_host": "http://localhost:11434",
        "anthropic_api_key": None, "google_api_key": None,
    })()
    p = _build_provider(cfg)
    from meeting_helper.chat.providers import NoToolsProvider
    assert isinstance(p, NoToolsProvider)


@pytest.mark.asyncio
async def test_tool_result_content_is_json_string_not_dict():
    """Anthropic requires tool_result.content to be a string. We must
    json.dumps() the dict from the registry call."""
    async def _run(args, ctx): return {"status": "ok", "result": {"matches": [1, 2]}}
    reg = Registry()
    reg.register(Tool(name="my.search", description="d", input_schema={"q": "string"}, run=_run))

    captured = []

    class _Prov:
        def __init__(self): self._stage = 0
        async def stream_completion(self, *, system, messages, tools):
            captured.append(messages)
            if self._stage == 0:
                self._stage += 1
                yield {"type": "tool_use", "id": "tu1", "name": "my.search", "input": {"q": "x"}}
                yield {"type": "done"}
            else:
                yield {"type": "chunk", "text": "done"}
                yield {"type": "done"}

    async def _noop(*a, **k): return None

    await run_agent(
        system="s", messages=[{"role": "user", "content": "x"}],
        registry=reg, provider=_Prov(),
        on_chunk=_noop, on_tool_call=_noop, on_tool_result=_noop,
    )
    second_call = captured[1]
    tool_result_msg = second_call[-1]
    assert tool_result_msg["role"] == "user"
    assert tool_result_msg["content"][0]["type"] == "tool_result"
    content = tool_result_msg["content"][0]["content"]
    assert isinstance(content, str), f"expected str, got {type(content).__name__}"
    import json
    parsed = json.loads(content)
    assert parsed == {"status": "ok", "result": {"matches": [1, 2]}}
