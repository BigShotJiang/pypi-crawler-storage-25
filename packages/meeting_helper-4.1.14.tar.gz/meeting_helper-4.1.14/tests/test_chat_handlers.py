import json
import pytest
from aiohttp import web
from aiohttp.test_utils import make_mocked_request

from meeting_helper.chat import handlers as chat_handlers, paths as chat_paths


def _isolate(monkeypatch, tmp_path):
    monkeypatch.setattr(chat_paths, "CHAT_ROOT", tmp_path / "chat")
    monkeypatch.setattr(chat_paths, "_active_workspace_name", lambda: "test")


@pytest.mark.asyncio
async def test_create_then_list_then_get_then_rename_then_delete(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)

    # CREATE
    req = make_mocked_request("POST", "/chat/threads")
    async def _body(): return {"title": "Hello"}
    req.json = _body  # type: ignore[attr-defined]
    resp = await chat_handlers.threads_create_handler(req)
    created = json.loads(resp.text)
    tid = created["id"]
    assert created["title"] == "Hello"

    # LIST
    resp = await chat_handlers.threads_list_handler(make_mocked_request("GET", "/chat/threads"))
    listed = json.loads(resp.text)
    assert any(e["id"] == tid for e in listed["threads"])

    # GET
    req = make_mocked_request("GET", f"/chat/threads/{tid}", match_info={"thread_id": tid})
    resp = await chat_handlers.threads_get_handler(req)
    got = json.loads(resp.text)
    assert got["id"] == tid

    # RENAME
    req = make_mocked_request("POST", f"/chat/threads/{tid}/rename", match_info={"thread_id": tid})
    async def _body2(): return {"title": "Renamed"}
    req.json = _body2  # type: ignore[attr-defined]
    resp = await chat_handlers.threads_rename_handler(req)
    assert resp.status == 200

    # DELETE
    req = make_mocked_request("DELETE", f"/chat/threads/{tid}", match_info={"thread_id": tid})
    resp = await chat_handlers.threads_delete_handler(req)
    assert resp.status == 200

    # subsequent GET 404
    req = make_mocked_request("GET", f"/chat/threads/{tid}", match_info={"thread_id": tid})
    resp = await chat_handlers.threads_get_handler(req)
    assert resp.status == 404


@pytest.mark.asyncio
async def test_threads_model_set_and_clear(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    from meeting_helper.chat import store as chat_store

    th = chat_store.create_thread(title="t")
    assert th.provider is None and th.model is None

    # SET provider + model
    req = make_mocked_request(
        "POST", f"/chat/threads/{th.id}/model", match_info={"thread_id": th.id}
    )
    async def _body(): return {"provider": "gemini", "model": "gemini-2.5-pro"}
    req.json = _body  # type: ignore[attr-defined]
    resp = await chat_handlers.threads_model_handler(req)
    assert resp.status == 200
    payload = json.loads(resp.text)
    assert payload["provider"] == "gemini"
    assert payload["model"] == "gemini-2.5-pro"
    reloaded = chat_store.read_thread(th.id)
    assert reloaded.provider == "gemini"
    assert reloaded.model == "gemini-2.5-pro"

    # CLEAR provider, keep model
    req = make_mocked_request(
        "POST", f"/chat/threads/{th.id}/model", match_info={"thread_id": th.id}
    )
    async def _body2(): return {"provider": None, "model": "gemini-2.5-pro"}
    req.json = _body2  # type: ignore[attr-defined]
    resp = await chat_handlers.threads_model_handler(req)
    assert resp.status == 200
    reloaded = chat_store.read_thread(th.id)
    assert reloaded.provider is None
    assert reloaded.model == "gemini-2.5-pro"

    # Unknown thread → 404
    req = make_mocked_request(
        "POST", "/chat/threads/thr_missing/model", match_info={"thread_id": "thr_missing"}
    )
    async def _body3(): return {"provider": "claude", "model": None}
    req.json = _body3  # type: ignore[attr-defined]
    resp = await chat_handlers.threads_model_handler(req)
    assert resp.status == 404


def test_build_provider_honors_overrides(monkeypatch):
    """The provider builder must use the thread's override over the
    workspace default, falling back to the default when an override is None."""
    from meeting_helper.chat.handlers import _build_provider
    from meeting_helper.chat import providers as providers_mod

    # Stub the providers to avoid pulling in their SDKs. Track constructor args.
    class _StubClaude:
        def __init__(self, *, api_key, model):
            self.api_key = api_key
            self.model = model
    class _StubGemini:
        def __init__(self, *, api_key, model):
            self.api_key = api_key
            self.model = model

    monkeypatch.setattr(providers_mod, "ClaudeProvider", _StubClaude)
    monkeypatch.setattr(providers_mod, "GeminiProvider", _StubGemini)

    class _Cfg:
        preferred_provider = "claude"
        anthropic_api_key = "k"
        google_api_key = "k"
        claude_model = "claude-haiku-4-5-20251001"
        gemini_model = "gemini-2.5-flash"
        local_model = "llama"

    cfg = _Cfg()

    # No override → workspace default (claude, default model).
    p = _build_provider(cfg)
    assert isinstance(p, _StubClaude)
    assert p.model == "claude-haiku-4-5-20251001"

    # provider override → switch to Gemini with Gemini's default model.
    p = _build_provider(cfg, provider_override="gemini")
    assert isinstance(p, _StubGemini)
    assert p.model == "gemini-2.5-flash"

    # model override only → keep provider, swap model.
    p = _build_provider(cfg, model_override="claude-sonnet-4-6")
    assert isinstance(p, _StubClaude)
    assert p.model == "claude-sonnet-4-6"

    # Both → use both.
    p = _build_provider(cfg, provider_override="gemini", model_override="gemini-2.5-pro")
    assert isinstance(p, _StubGemini)
    assert p.model == "gemini-2.5-pro"


@pytest.mark.asyncio
async def test_state_endpoints(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    resp = await chat_handlers.state_get_handler(make_mocked_request("GET", "/chat/state"))
    assert json.loads(resp.text) == {"active_thread_id": None}

    req = make_mocked_request("POST", "/chat/state")
    async def _body(): return {"active_thread_id": "thr_xyz"}
    req.json = _body  # type: ignore[attr-defined]
    resp = await chat_handlers.state_set_handler(req)
    assert resp.status == 200

    resp = await chat_handlers.state_get_handler(make_mocked_request("GET", "/chat/state"))
    assert json.loads(resp.text) == {"active_thread_id": "thr_xyz"}


@pytest.mark.asyncio
async def test_messages_post_appends_user_turn_and_acks(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    from meeting_helper.chat import store as chat_store
    from meeting_helper.chat.registry import Registry
    th = chat_store.create_thread(title="t")

    broadcast_calls = []

    async def _stub_broadcast(msg): broadcast_calls.append(msg)

    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", _stub_broadcast)

    class _Prov:
        async def stream_completion(self, *, system, messages, tools):
            yield {"type": "done", "stop_reason": "end_turn"}

    monkeypatch.setattr(
        "meeting_helper.chat.handlers._build_provider", lambda cfg, **_: _Prov()
    )
    monkeypatch.setattr(
        "meeting_helper.chat.handlers._build_registry", lambda: Registry()
    )

    req = make_mocked_request(
        "POST", f"/chat/threads/{th.id}/messages", match_info={"thread_id": th.id}
    )
    async def _body(): return {"text": "hello"}
    req.json = _body  # type: ignore[attr-defined]
    resp = await chat_handlers.messages_post_handler(req)
    assert resp.status == 202

    loaded = chat_store.read_thread(th.id)
    assert loaded.turns[0].role == "user"
    assert loaded.turns[0].text == "hello"
    import asyncio
    await asyncio.sleep(0.05)
    types_emitted = {m["type"] for m in broadcast_calls}
    assert "chat.turn_started" in types_emitted
    assert "chat.turn_done" in types_emitted


@pytest.mark.asyncio
async def test_messages_post_streams_chunks_via_ws_with_stub_provider(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    from meeting_helper.chat import store as chat_store
    th = chat_store.create_thread(title="t")

    broadcasts: list[dict] = []

    async def _bcast(m): broadcasts.append(m)
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", _bcast)

    # Stub provider: yield chunks then done.
    class _Prov:
        async def stream_completion(self, *, system, messages, tools):
            yield {"type": "chunk", "text": "Hi"}
            yield {"type": "chunk", "text": " there."}
            yield {"type": "done", "stop_reason": "end_turn"}

    monkeypatch.setattr(
        "meeting_helper.chat.handlers._build_provider",
        lambda cfg, **_: _Prov(),
    )

    from meeting_helper.chat.registry import Registry
    monkeypatch.setattr(
        "meeting_helper.chat.handlers._build_registry",
        lambda: Registry(),
    )

    req = make_mocked_request(
        "POST", f"/chat/threads/{th.id}/messages", match_info={"thread_id": th.id}
    )
    async def _body(): return {"text": "hello"}
    req.json = _body  # type: ignore[attr-defined]
    resp = await chat_handlers.messages_post_handler(req)
    assert resp.status == 202

    import asyncio
    await asyncio.sleep(0.1)

    types = [m["type"] for m in broadcasts]
    assert "chat.turn_started" in types
    chunks = [m["text"] for m in broadcasts if m["type"] == "chat.chunk"]
    assert chunks == ["Hi", " there."]
    assert "chat.turn_done" in types

    loaded = chat_store.read_thread(th.id)
    assistant = next(t for t in loaded.turns if t.role == "assistant")
    assert assistant.text == "Hi there."


def test_default_registry_has_expected_tools(monkeypatch):
    """The static registry holds only non-local-todo tools — local-todo
    surface is added dynamically by ``_build_registry_async`` via the
    ``mcp.*`` passthrough, so ticket-specific tools are NOT expected here."""
    # We are not isolating tmp_path because _build_registry doesn't touch disk.
    from meeting_helper.chat.handlers import _build_registry
    names = {t.name for t in _build_registry().tools()}
    assert {
        "meeting.live",
        "meeting.full_transcript",
        "library.search_meetings",
        "library.list_recent",
        "library.get_meeting",
        "library.fetch_kb",
        "library.get_note",
        "web.search",
        "memory.read_all",
        "memory.add",
        "memory.update",
        "memory.delete",
    } <= names
    # No hand-wrapped ticket tools should leak in from the static registry.
    assert not any(n.startswith("tickets.") for n in names)


@pytest.mark.asyncio
async def test_mutation_pauses_until_confirm_received(monkeypatch, tmp_path):
    """The user-approval gate pauses any mutation tool call until a
    confirm decision arrives. Exercises ``mcp.add_comment`` via the
    dynamic MCP passthrough (the old hand-wrapped ``tickets.add_comment``
    wrapper was removed in the dynamic-passthrough refactor).

    Behaviors that were specific to the hand-wrap and are no longer
    asserted here:
    - alias mapping (``task_id`` -> wire ``id``) — the raw MCP requires
      callers to pass MCP-native field names directly.
    - forgiveness when ``board_id`` is omitted — the wrapper used to
      surface a friendly error, the raw MCP just rejects the call.
    """
    _isolate(monkeypatch, tmp_path)
    from meeting_helper.chat import store as chat_store
    from meeting_helper.chat.registry import Registry
    from meeting_helper.chat.tools.mcp_passthrough import build_mcp_passthrough_tools

    th = chat_store.create_thread(title="t")
    broadcasts: list[dict] = []
    async def _b(m): broadcasts.append(m)
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", _b)

    class _Prov:
        def __init__(self): self._stage = 0
        async def stream_completion(self, *, system, messages, tools):
            if self._stage == 0:
                self._stage += 1
                yield {"type": "tool_use", "id": "tu1", "name": "mcp.add_comment",
                       "input": {"board_id": 1, "id": "T-1", "body": "hi"}}
                yield {"type": "done"}
            else:
                yield {"type": "chunk", "text": "Posted."}
                yield {"type": "done"}

    monkeypatch.setattr("meeting_helper.chat.handlers._build_provider", lambda cfg, **_: _Prov())

    # Stub MCP: registers a single ``add_comment`` tool via list_tools and
    # records call_tool invocations. Mirrors the pattern used in
    # tests/test_chat_mcp_passthrough.py.
    class _StubTool:
        def __init__(self, name): self.name = name; self.description = ""; self.inputSchema = {"type": "object", "properties": {}}
    class _StubListResp:
        def __init__(self, tools): self.tools = tools
    class _StubSession:
        def __init__(self, tools): self._tools = tools
        async def list_tools(self): return _StubListResp(self._tools)
    class _MCP:
        def __init__(self):
            self.posted: list[tuple[str, dict]] = []
            self._session = _StubSession([_StubTool("add_comment")])
        async def _ensure_started(self): return None
        async def call_tool(self, name, args=None):
            self.posted.append((name, dict(args or {})))
            return {"id": "C-1"}

    mcp = _MCP()
    # Build a registry that contains *only* the dynamic mcp.add_comment
    # tool (no static tools needed for this test).
    reg = Registry()
    for t in await build_mcp_passthrough_tools(mcp):
        reg.register(t)
    # The handler calls _build_registry_async(app_state) — patch that to
    # return our pre-built registry so the test doesn't need a full
    # app_state with a real LocalTodoClient.
    async def _fake_async(app_state): return reg
    monkeypatch.setattr("meeting_helper.chat.handlers._build_registry_async", _fake_async)
    monkeypatch.setattr("meeting_helper.state.state.local_todo", mcp)

    req = make_mocked_request(
        "POST", f"/chat/threads/{th.id}/messages", match_info={"thread_id": th.id}
    )
    async def _body(): return {"text": "comment plz"}
    req.json = _body  # type: ignore[attr-defined]
    await chat_handlers.messages_post_handler(req)

    # Wait for the pending_confirm event.
    import asyncio
    for _ in range(50):
        if any(b["type"] == "chat.pending_confirm" for b in broadcasts):
            break
        await asyncio.sleep(0.05)
    confirm = next(b for b in broadcasts if b["type"] == "chat.pending_confirm")
    turn_id = confirm["turn_id"]
    assert mcp.posted == []  # nothing posted yet

    # Approve.
    req2 = make_mocked_request(
        "POST", f"/chat/threads/{th.id}/confirm", match_info={"thread_id": th.id}
    )
    async def _body2(): return {"turn_id": turn_id, "decision": "approve"}
    req2.json = _body2  # type: ignore[attr-defined]
    resp = await chat_handlers.messages_confirm_handler(req2)
    assert resp.status == 200

    for _ in range(50):
        if mcp.posted:
            break
        await asyncio.sleep(0.05)
    assert mcp.posted == [("add_comment", {"board_id": 1, "id": "T-1", "body": "hi"})]

    # A `chat.tool_call` event MUST fire alongside the `chat.pending_confirm`
    # so the UI gets a chip for the mutation (without it, the user sees zero
    # feedback for create/update/delete tools).
    tool_calls = [b for b in broadcasts if b["type"] == "chat.tool_call"]
    assert any(b.get("tool_name") == "mcp.add_comment" for b in tool_calls)


@pytest.mark.asyncio
async def test_n_consecutive_mutations_get_unique_pending_keys(monkeypatch, tmp_path):
    """Regression for the bug where the always-allow auto-approve flow
    broke after the first tool: ``pending_key`` was built as
    ``{thread}:{turn}:{name}`` so every ``create_task`` call in one
    assistant turn collided. The frontend's auto-approve dedupe (keyed
    off pending_key) then refused to approve calls 2..N and the daemon
    hung forever on the overwritten future."""
    _isolate(monkeypatch, tmp_path)
    from meeting_helper.chat import store as chat_store
    from meeting_helper.chat.registry import Registry
    from meeting_helper.chat.tools.mcp_passthrough import build_mcp_passthrough_tools

    th = chat_store.create_thread(title="t")
    broadcasts: list[dict] = []
    async def _b(m): broadcasts.append(m)
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", _b)

    NUM_CALLS = 3

    class _Prov:
        def __init__(self): self._stage = 0
        async def stream_completion(self, *, system, messages, tools):
            if self._stage == 0:
                self._stage += 1
                for i in range(NUM_CALLS):
                    yield {"type": "tool_use", "id": f"tu{i}", "name": "mcp.create_task",
                           "input": {"board_id": 1, "title": f"Test {i}"}}
                yield {"type": "done"}
            else:
                yield {"type": "chunk", "text": "Done."}
                yield {"type": "done"}

    monkeypatch.setattr("meeting_helper.chat.handlers._build_provider", lambda cfg, **_: _Prov())

    class _StubTool:
        def __init__(self, name): self.name = name; self.description = ""; self.inputSchema = {"type": "object", "properties": {}}
    class _StubListResp:
        def __init__(self, tools): self.tools = tools
    class _StubSession:
        def __init__(self, tools): self._tools = tools
        async def list_tools(self): return _StubListResp(self._tools)
    class _MCP:
        def __init__(self):
            self.posted: list[tuple[str, dict]] = []
            self._session = _StubSession([_StubTool("create_task")])
        async def _ensure_started(self): return None
        async def call_tool(self, name, args=None):
            self.posted.append((name, dict(args or {})))
            return {"id": f"T-{len(self.posted)}"}

    mcp = _MCP()
    reg = Registry()
    for t in await build_mcp_passthrough_tools(mcp):
        reg.register(t)
    async def _fake_async(app_state): return reg
    monkeypatch.setattr("meeting_helper.chat.handlers._build_registry_async", _fake_async)
    monkeypatch.setattr("meeting_helper.state.state.local_todo", mcp)

    req = make_mocked_request(
        "POST", f"/chat/threads/{th.id}/messages", match_info={"thread_id": th.id}
    )
    async def _body(): return {"text": "create N tickets"}
    req.json = _body  # type: ignore[attr-defined]
    await chat_handlers.messages_post_handler(req)

    # Approve each pending_confirm as it arrives.
    import asyncio
    seen_keys: set[str] = set()
    approvals_sent = 0
    deadline_iters = 200
    while approvals_sent < NUM_CALLS and deadline_iters > 0:
        deadline_iters -= 1
        await asyncio.sleep(0.02)
        for b in broadcasts:
            if b["type"] != "chat.pending_confirm":
                continue
            key = b.get("pending_key")
            if not key or key in seen_keys:
                continue
            seen_keys.add(key)
            req2 = make_mocked_request(
                "POST", f"/chat/threads/{th.id}/confirm",
                match_info={"thread_id": th.id},
            )
            async def _body2(k=key): return {"pending_key": k, "decision": "approve"}
            req2.json = _body2  # type: ignore[attr-defined]
            resp = await chat_handlers.messages_confirm_handler(req2)
            assert resp.status == 200, f"confirm failed for key {key}"
            approvals_sent += 1

    # Every call must have produced a UNIQUE pending_key (the bug was that
    # they all shared `{tid}:{turn}:{name}` and collided).
    assert len(seen_keys) == NUM_CALLS, (
        f"expected {NUM_CALLS} distinct pending_keys, got {len(seen_keys)}: {seen_keys}"
    )
    # All N tools should have actually run.
    for _ in range(100):
        if len(mcp.posted) >= NUM_CALLS:
            break
        await asyncio.sleep(0.02)
    assert len(mcp.posted) == NUM_CALLS, (
        f"expected {NUM_CALLS} create_task invocations, got {len(mcp.posted)}"
    )


@pytest.mark.asyncio
async def test_provider_exception_emits_turn_done_with_error(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    from meeting_helper.chat import store as chat_store
    from meeting_helper.chat.registry import Registry

    th = chat_store.create_thread(title="t")
    broadcasts: list[dict] = []
    async def _b(m): broadcasts.append(m)
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", _b)

    class _BadProv:
        async def stream_completion(self, *, system, messages, tools):
            raise RuntimeError("boom")
            yield  # makes it an async generator

    monkeypatch.setattr("meeting_helper.chat.handlers._build_provider", lambda cfg, **_: _BadProv())
    monkeypatch.setattr("meeting_helper.chat.handlers._build_registry", lambda: Registry())

    req = make_mocked_request("POST", f"/chat/threads/{th.id}/messages",
                              match_info={"thread_id": th.id})
    async def _body(): return {"text": "hi"}
    req.json = _body  # type: ignore[attr-defined]
    await chat_handlers.messages_post_handler(req)

    import asyncio
    for _ in range(40):
        if any(b["type"] == "chat.turn_done" for b in broadcasts):
            break
        await asyncio.sleep(0.05)

    done = next(b for b in broadcasts if b["type"] == "chat.turn_done")
    assert "boom" in (done.get("error") or "")


@pytest.mark.asyncio
async def test_memory_list_empty(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    resp = await chat_handlers.memory_list_handler(
        make_mocked_request("GET", "/chat/memory")
    )
    assert resp.status == 200
    assert json.loads(resp.text) == {"entries": []}


@pytest.mark.asyncio
async def test_memory_add_returns_entry(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    req = make_mocked_request("POST", "/chat/memory")
    async def _body(): return {"text": "remember this"}
    req.json = _body  # type: ignore[attr-defined]
    resp = await chat_handlers.memory_add_handler(req)
    assert resp.status == 200
    entry = json.loads(resp.text)
    assert entry["text"] == "remember this"
    assert entry["source"] == "user"

    # And the list endpoint returns it.
    resp2 = await chat_handlers.memory_list_handler(
        make_mocked_request("GET", "/chat/memory")
    )
    listed = json.loads(resp2.text)
    assert len(listed["entries"]) == 1
    assert listed["entries"][0]["id"] == entry["id"]


@pytest.mark.asyncio
async def test_memory_add_missing_text_400(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    req = make_mocked_request("POST", "/chat/memory")
    async def _body(): return {}
    req.json = _body  # type: ignore[attr-defined]
    resp = await chat_handlers.memory_add_handler(req)
    assert resp.status == 400


@pytest.mark.asyncio
async def test_memory_update_modifies_entry(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    from meeting_helper.chat import memory as chat_memory
    e = chat_memory.add(text="original")

    req = make_mocked_request(
        "POST", f"/chat/memory/{e['id']}", match_info={"mem_id": e["id"]}
    )
    async def _body(): return {"text": "updated", "pinned": True}
    req.json = _body  # type: ignore[attr-defined]
    resp = await chat_handlers.memory_update_handler(req)
    assert resp.status == 200
    body = json.loads(resp.text)
    assert body["text"] == "updated"
    assert body["pinned"] is True


@pytest.mark.asyncio
async def test_memory_update_not_found(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    req = make_mocked_request(
        "POST", "/chat/memory/mem_missing", match_info={"mem_id": "mem_missing"}
    )
    async def _body(): return {"text": "x"}
    req.json = _body  # type: ignore[attr-defined]
    resp = await chat_handlers.memory_update_handler(req)
    assert resp.status == 404


@pytest.mark.asyncio
async def test_memory_delete_removes(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    from meeting_helper.chat import memory as chat_memory
    e = chat_memory.add(text="bye")
    req = make_mocked_request(
        "DELETE", f"/chat/memory/{e['id']}", match_info={"mem_id": e["id"]}
    )
    resp = await chat_handlers.memory_delete_handler(req)
    assert resp.status == 200
    assert json.loads(resp.text) == {"ok": True}
    assert chat_memory.read_all() == []


@pytest.mark.asyncio
async def test_memory_delete_not_found(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    req = make_mocked_request(
        "DELETE", "/chat/memory/mem_missing", match_info={"mem_id": "mem_missing"}
    )
    resp = await chat_handlers.memory_delete_handler(req)
    assert resp.status == 404
