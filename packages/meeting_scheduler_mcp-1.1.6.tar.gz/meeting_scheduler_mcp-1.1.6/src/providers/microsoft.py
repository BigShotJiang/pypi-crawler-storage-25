"""
Microsoft Graph API adapter.

Authentication
--------------
Token lifecycle is fully managed by msal-extensions, which matches what
Microsoft Outlook uses on each platform:

  macOS:   KeychainPersistence — token cache stored in macOS Keychain with an
           ACL that restricts read access to the process that created it.
  Windows: FilePersistenceWithDataProtection — DPAPI-encrypted cache file,
           machine- and user-bound; cannot be decrypted on another machine.
  Linux:   FilePersistence — unencrypted file (fallback; not in scope).

On first use the MSAL cache is empty. _get_valid_token falls back to the
legacy keyring JSON blob (if present from the old implementation) to bootstrap
the cache, then clears the legacy entry.

Scopes
------
  Primary account (is_primary=True):
    Calendars.ReadWrite  — create, update, delete events
    MailboxSettings.Read — read working hours and timezone

  Shadow account (is_primary=False):
    Calendars.Read       — free/busy queries only
    MailboxSettings.Read — read working hours and timezone

Free/busy
---------
Uses the /me/calendar/getSchedule endpoint to batch-query schedules.

Mailbox settings
----------------
/users/{email}/mailboxSettings returns timezone and working-hours data,
enabling per-participant schedule awareness.

Events
------
Created on /me/events with isOnlineMeeting=true for Teams links.
"""

from __future__ import annotations

import json
import logging
import platform
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import httpx
import keyring
import msal

from src.providers.base import CalendarProvider
from src.scheduling.models import BusyInterval, EventPayload, MailboxSettings
from src.scheduling.timezone_utils import UTC

logger = logging.getLogger(__name__)

GRAPH_BASE = "https://graph.microsoft.com/v1.0"
_CACHE_DIR = Path.home() / ".config" / "meeting-scheduler" / "token_cache"
_KEYRING_SERVICE = "meeting-scheduler"

# Bundled OAuth client — registered as a multi-tenant public client app in Azure.
# No client secret needed for public client / delegated auth via MSAL.
_BUNDLED_CLIENT_ID = "d7bac78e-f0d2-4209-9dcb-2484b4a8f996"

# Scopes by account role.
_SCOPES_PRIMARY = [
    "https://graph.microsoft.com/Calendars.ReadWrite",
    "https://graph.microsoft.com/MailboxSettings.Read",
]
_SCOPES_SHADOW = [
    "https://graph.microsoft.com/Calendars.Read",
    "https://graph.microsoft.com/MailboxSettings.Read",
]

# Microsoft returns Windows timezone names; map the most common ones to IANA.
WINDOWS_TO_IANA: dict[str, str] = {
    "UTC": "UTC",
    "Greenwich Standard Time": "Europe/London",
    "GMT Standard Time": "Europe/London",
    "Romance Standard Time": "Europe/Paris",
    "W. Europe Standard Time": "Europe/Berlin",
    "Central Europe Standard Time": "Europe/Budapest",
    "Eastern Standard Time": "America/New_York",
    "Central Standard Time": "America/Chicago",
    "Mountain Standard Time": "America/Denver",
    "Pacific Standard Time": "America/Los_Angeles",
    "India Standard Time": "Asia/Kolkata",
    "Singapore Standard Time": "Asia/Singapore",
    "AUS Eastern Standard Time": "Australia/Sydney",
    "Tokyo Standard Time": "Asia/Tokyo",
    "China Standard Time": "Asia/Shanghai",
    "Arab Standard Time": "Asia/Riyadh",
}

GRAPH_DAY_NAMES: dict[str, str] = {
    "sunday": "Sunday", "monday": "Monday", "tuesday": "Tuesday",
    "wednesday": "Wednesday", "thursday": "Thursday",
    "friday": "Friday", "saturday": "Saturday",
}


def _windows_tz_to_iana(windows_tz: str) -> str:
    return WINDOWS_TO_IANA.get(windows_tz, windows_tz)


def _build_token_cache(email: str) -> "msal.SerializableTokenCache":
    """Return an msal-extensions PersistedTokenCache for *email*.

    Falls back to a plain SerializableTokenCache (in-memory only) if
    msal-extensions is not installed, logging a warning.
    """
    _CACHE_DIR.mkdir(parents=True, exist_ok=True)
    safe_name = email.replace("@", "_at_").replace(".", "_")
    cache_path = str(_CACHE_DIR / f"{safe_name}.bin")

    try:
        from msal_extensions import (  # type: ignore[import]
            FilePersistence,
            FilePersistenceWithDataProtection,
            KeychainPersistence,
            PersistedTokenCache,
        )

        system = platform.system()
        if system == "Darwin":
            persistence = KeychainPersistence(
                cache_path,
                service_name="meeting-scheduler",
                account_name=email,
            )
        elif system == "Windows":
            persistence = FilePersistenceWithDataProtection(cache_path)
        else:
            persistence = FilePersistence(cache_path)

        return PersistedTokenCache(persistence)

    except ImportError:
        logger.warning(
            "msal-extensions not installed. Microsoft tokens will be stored "
            "in memory only (not persisted across restarts). "
            "Run: pip install msal-extensions"
        )
        return msal.SerializableTokenCache()


class MicrosoftCalendarProvider(CalendarProvider):
    """Microsoft Graph adapter for Outlook / Exchange Online calendars."""

    def __init__(
        self,
        email: str,
        is_primary: bool = False,
        client_id: str = "",
        authority: str = "https://login.microsoftonline.com/common",
        default_working_hours_start: str = "09:00",
        default_working_hours_end: str = "17:00",
        default_working_days: Optional[list[str]] = None,
    ) -> None:
        self.email = email
        self.is_primary = is_primary
        self.client_id = client_id or _BUNDLED_CLIENT_ID
        self.authority = authority
        self.default_working_hours_start = default_working_hours_start
        self.default_working_hours_end = default_working_hours_end
        self.default_working_days = default_working_days or [
            "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"
        ]
        self._scopes = _SCOPES_PRIMARY if is_primary else _SCOPES_SHADOW
        self._token_cache = _build_token_cache(email)
        self._app = msal.PublicClientApplication(
            client_id=self.client_id,
            authority=self.authority,
            token_cache=self._token_cache,
        )

    # ── Token management ──────────────────────────────────────────────────────

    def _get_valid_token(self) -> str:
        """Return a valid access token, using the msal-extensions cache.

        Falls back to a legacy keyring JSON blob to bootstrap the cache on
        first run after migrating from the old implementation.
        """
        # Try MSAL cache first (handles silent refresh automatically).
        accounts = self._app.get_accounts(username=self.email)
        if accounts:
            result = self._app.acquire_token_silent(self._scopes, account=accounts[0])
            if result and "access_token" in result:
                return result["access_token"]

        # Migration: bootstrap from old keyring JSON blob if present.
        legacy_token = self._load_legacy_refresh_token()
        if legacy_token:
            result = self._app.acquire_token_by_refresh_token(legacy_token, self._scopes)
            if "access_token" in result:
                self._clear_legacy_token()
                logger.info(
                    "Migrated %s from legacy keyring to msal-extensions cache.", self.email
                )
                return result["access_token"]
            logger.warning(
                "Legacy refresh token for %s is no longer valid.", self.email
            )

        raise RuntimeError(
            f"No valid token for {self.email}. Run the OAuth flow to authorise this account."
        )

    def _load_legacy_refresh_token(self) -> Optional[str]:
        """Read a refresh token from the old JSON keyring entry, if it exists."""
        raw = keyring.get_password(_KEYRING_SERVICE, self.email)
        if not raw:
            return None
        try:
            return json.loads(raw).get("refresh_token")
        except (json.JSONDecodeError, AttributeError):
            return raw if isinstance(raw, str) else None

    def _clear_legacy_token(self) -> None:
        try:
            keyring.delete_password(_KEYRING_SERVICE, self.email)
        except Exception:
            pass

    def _auth_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._get_valid_token()}"}

    # ── CalendarProvider interface ─────────────────────────────────────────────

    def get_free_busy(
        self,
        email: str,
        start: datetime,
        end: datetime,
    ) -> list[BusyInterval]:
        """Query the Graph getSchedule endpoint for *email*."""
        url = f"{GRAPH_BASE}/me/calendar/getSchedule"
        body = {
            "schedules": [email],
            "startTime": {
                "dateTime": start.strftime("%Y-%m-%dT%H:%M:%S"),
                "timeZone": "UTC",
            },
            "endTime": {
                "dateTime": end.strftime("%Y-%m-%dT%H:%M:%S"),
                "timeZone": "UTC",
            },
            "availabilityViewInterval": 15,
        }
        response = httpx.post(url, json=body, headers=self._auth_headers(), timeout=20)
        if response.status_code != 200:
            raise RuntimeError(
                f"Microsoft getSchedule failed for {email}: "
                f"HTTP {response.status_code} — {response.text[:200]}"
            )
        data = response.json()
        intervals: list[BusyInterval] = []
        for schedule in data.get("value", []):
            for item in schedule.get("scheduleItems", []):
                if item.get("status", "free").lower() in ("busy", "tentative", "oof"):
                    s = item.get("start", {})
                    e = item.get("end", {})
                    s_dt = datetime.fromisoformat(s["dateTime"]).replace(tzinfo=UTC)
                    e_dt = datetime.fromisoformat(e["dateTime"]).replace(tzinfo=UTC)
                    intervals.append(BusyInterval(start=s_dt, end=e_dt))
        return intervals

    def get_mailbox_settings(self, email: str) -> MailboxSettings:
        """Fetch timezone and working hours from the mailboxSettings endpoint."""
        url = f"{GRAPH_BASE}/users/{email}/mailboxSettings"
        response = httpx.get(url, headers=self._auth_headers(), timeout=15)
        if response.status_code != 200:
            raise RuntimeError(
                f"Could not fetch mailbox settings for {email}: "
                f"HTTP {response.status_code}"
            )
        data = response.json()
        iana_tz = _windows_tz_to_iana(data.get("timeZone", "UTC"))
        working_hours = data.get("workingHours", {})
        days = [
            GRAPH_DAY_NAMES.get(d.lower(), d.capitalize())
            for d in working_hours.get("daysOfWeek", [])
        ]
        start_raw = working_hours.get("startTime", self.default_working_hours_start)
        end_raw = working_hours.get("endTime", self.default_working_hours_end)
        return MailboxSettings(
            timezone=iana_tz,
            working_hours_start=start_raw[:5] if start_raw else self.default_working_hours_start,
            working_hours_end=end_raw[:5] if end_raw else self.default_working_hours_end,
            working_days=days or self.default_working_days,
        )

    def create_event(self, event: EventPayload) -> str:
        """Create an Outlook event with an optional Teams link."""
        url = f"{GRAPH_BASE}/me/events"
        body: dict[str, Any] = {
            "subject": event.title,
            "body": {"contentType": "text", "content": event.description},
            "start": {
                "dateTime": event.start.strftime("%Y-%m-%dT%H:%M:%S"),
                "timeZone": "UTC",
            },
            "end": {
                "dateTime": event.end.strftime("%Y-%m-%dT%H:%M:%S"),
                "timeZone": "UTC",
            },
            "attendees": [
                {"emailAddress": {"address": e}, "type": "required"}
                for e in event.participant_emails
            ],
        }
        if event.generate_video_link and event.video_provider in ("auto", "teams"):
            body["isOnlineMeeting"] = True
            body["onlineMeetingProvider"] = "teamsForBusiness"

        response = httpx.post(url, json=body, headers=self._auth_headers(), timeout=20)
        if response.status_code not in (200, 201):
            raise RuntimeError(
                f"Microsoft create event failed: HTTP {response.status_code} — "
                f"{response.text[:300]}"
            )
        data = response.json()
        self._last_create_response = data
        return data["id"]

    def get_event(self, event_id: str) -> dict:
        """Fetch title, description, and attendees for an existing event."""
        url = f"{GRAPH_BASE}/me/events/{event_id}"
        response = httpx.get(url, headers=self._auth_headers(), timeout=15)
        if response.status_code != 200:
            raise RuntimeError(
                f"Microsoft get event {event_id} failed: HTTP {response.status_code}"
            )
        data = response.json()
        participants = [
            a["emailAddress"]["address"]
            for a in data.get("attendees", [])
            if a.get("emailAddress", {}).get("address")
            and a["emailAddress"]["address"].lower() != self.email.lower()
        ]
        return {
            "title": data.get("subject", ""),
            "description": data.get("body", {}).get("content", ""),
            "participants": participants,
        }

    def update_event(self, event_id: str, event: EventPayload) -> None:
        """Update an existing Outlook event (PATCH)."""
        url = f"{GRAPH_BASE}/me/events/{event_id}"
        body: dict[str, Any] = {
            "subject": event.title,
            "body": {"contentType": "text", "content": event.description},
            "start": {
                "dateTime": event.start.strftime("%Y-%m-%dT%H:%M:%S"),
                "timeZone": "UTC",
            },
            "end": {
                "dateTime": event.end.strftime("%Y-%m-%dT%H:%M:%S"),
                "timeZone": "UTC",
            },
            "attendees": [
                {"emailAddress": {"address": e}, "type": "required"}
                for e in event.participant_emails
            ],
        }
        response = httpx.patch(url, json=body, headers=self._auth_headers(), timeout=20)
        if response.status_code not in (200, 204):
            raise RuntimeError(
                f"Microsoft update event {event_id} failed: HTTP {response.status_code}"
            )

    def delete_event(self, event_id: str) -> None:
        """Delete an Outlook event."""
        url = f"{GRAPH_BASE}/me/events/{event_id}"
        response = httpx.delete(url, headers=self._auth_headers(), timeout=15)
        if response.status_code not in (200, 204):
            raise RuntimeError(
                f"Microsoft delete event {event_id} failed: HTTP {response.status_code}"
            )

    def health_check(self) -> bool:
        """Ping /me/mailboxSettings to verify token validity."""
        try:
            response = httpx.get(
                f"{GRAPH_BASE}/me/mailboxSettings", headers=self._auth_headers(), timeout=10
            )
            return response.status_code == 200
        except Exception as exc:
            logger.warning("Microsoft health check failed for %s: %s", self.email, exc)
            return False

    def authenticate(self) -> None:
        """Run the interactive OAuth flow via MSAL device-code or browser.

        Uses acquire_token_interactive which opens a browser window.
        MSAL writes the resulting tokens directly into the persisted cache
        (KeychainPersistence on macOS, DPAPI-protected file on Windows),
        so no extra persistence step is required here.
        """
        result = self._app.acquire_token_interactive(
            scopes=self._scopes,
            login_hint=self.email,
        )
        if "error" in result:
            raise RuntimeError(
                f"Microsoft authentication failed for {self.email}: "
                f"{result.get('error_description', result['error'])}"
            )
        logger.info("Microsoft OAuth complete for %s.", self.email)

    def get_video_link_from_response(self, response: dict) -> str | None:
        """Extract the Teams join URL from a create-event response."""
        online_meeting = response.get("onlineMeeting")
        if online_meeting:
            return online_meeting.get("joinUrl")
        return None
