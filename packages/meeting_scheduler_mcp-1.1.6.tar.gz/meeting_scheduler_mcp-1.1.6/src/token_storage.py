"""
Secure storage for Google OAuth refresh tokens.

Tokens are stored directly in the OS keyring (macOS Keychain, Windows
Credential Manager, or the system secret store on Linux).  The keyring
backend already encrypts items at rest and restricts access to the
current user, which is sufficient for a personal tool.

Public API
----------
    store_google_refresh_token(email, token)
    load_google_refresh_token(email)  -> str | None
    delete_google_refresh_token(email)
"""

from __future__ import annotations

import logging
from typing import Optional

import keyring

logger = logging.getLogger(__name__)

_KEYRING_SERVICE = "meeting-scheduler"
_TOKEN_SUFFIX = ":refresh-token"


def store_google_refresh_token(email: str, token: str) -> None:
    """Persist *token* for *email* in the OS keyring."""
    keyring.set_password(_KEYRING_SERVICE, email + _TOKEN_SUFFIX, token)
    logger.debug("Stored refresh token for %s.", email)


def load_google_refresh_token(email: str) -> Optional[str]:
    """Load the refresh token for *email*, or return None."""
    return keyring.get_password(_KEYRING_SERVICE, email + _TOKEN_SUFFIX)


def delete_google_refresh_token(email: str) -> None:
    """Remove stored credentials for *email*."""
    try:
        keyring.delete_password(_KEYRING_SERVICE, email + _TOKEN_SUFFIX)
    except Exception:
        pass
    logger.debug("Deleted stored credentials for %s.", email)
