"""
HTML artifact renderer for scheduling tool responses.

Generates self-contained HTML (inline CSS, no external deps) that
Claude Desktop renders as an artifact inside the chat.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Optional


# ── Colour palette ─────────────────────────────────────────────────────────────

_PARTICIPANT_PALETTES = [
    # (bg, border, text, dot)
    ("#eff6ff", "#bfdbfe", "#1d4ed8", "#3b82f6"),   # blue   – Google
    ("#faf5ff", "#e9d5ff", "#7c3aed", "#a855f7"),   # purple – Microsoft
    ("#fff7ed", "#fed7aa", "#c2410c", "#f97316"),   # orange
    ("#f0fdf4", "#bbf7d0", "#15803d", "#22c55e"),   # green
    ("#fdf2f8", "#fbcfe8", "#be185d", "#ec4899"),   # pink
]

_CARD_CSS = """
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif;
  max-width: 560px;
  border-radius: 12px;
  border: 1px solid #e2e8f0;
  overflow: hidden;
  box-shadow: 0 1px 4px rgba(0,0,0,0.08);
  font-size: 14px;
  color: #111827;
"""


# ── Helpers ───────────────────────────────────────────────────────────────────


def _initials(email: str) -> str:
    name = email.split("@")[0]
    parts = name.replace(".", " ").replace("_", " ").split()
    if len(parts) >= 2:
        return (parts[0][0] + parts[1][0]).upper()
    return name[:2].upper()


def _participant_chip(email: str, idx: int, subtitle: str = "") -> str:
    bg, border, text, _ = _PARTICIPANT_PALETTES[idx % len(_PARTICIPANT_PALETTES)]
    init = _initials(email)
    label = email
    if subtitle:
        label = f"{email} · {subtitle}"
    return (
        f'<span style="display:inline-flex;align-items:center;gap:6px;'
        f'background:{bg};border:1px solid {border};border-radius:20px;'
        f'padding:4px 10px 4px 6px;font-size:12px;color:{text};font-weight:500;">'
        f'<span style="width:20px;height:20px;border-radius:50%;background:{text};'
        f'color:white;display:inline-flex;align-items:center;justify-content:center;'
        f'font-size:9px;font-weight:700;flex-shrink:0;">{init}</span>'
        f'{label}</span>'
    )


def _participant_avatar(email: str, idx: int) -> str:
    _, _, text, dot = _PARTICIPANT_PALETTES[idx % len(_PARTICIPANT_PALETTES)]
    init = _initials(email)
    return (
        f'<div title="{email}" style="width:26px;height:26px;border-radius:50%;'
        f'background:{text};color:white;display:inline-flex;align-items:center;'
        f'justify-content:center;font-size:10px;font-weight:700;'
        f'border:2px solid white;margin-left:-4px;">{init}</div>'
    )


def _format_utc_range(start_utc: str, end_utc: str) -> str:
    s = datetime.fromisoformat(start_utc.replace("Z", "+00:00"))
    e = datetime.fromisoformat(end_utc.replace("Z", "+00:00"))
    day = s.strftime("%a %-d %b")
    t_start = s.strftime("%-I:%M %p")
    t_end = e.strftime("%-I:%M %p")
    return f"{day} · {t_start} – {t_end} UTC"


# ── Slot picker ───────────────────────────────────────────────────────────────


def render_slots_html(
    slots: list[dict],
    participants: list[str],
    duration_minutes: int,
    window_start: str,
    window_end: str,
) -> str:
    """Return a self-contained HTML artifact for the slot picker."""

    # Header summary
    ws = datetime.fromisoformat(window_start.replace("Z", "+00:00"))
    we = datetime.fromisoformat(window_end.replace("Z", "+00:00"))
    win_str = f"{ws.strftime('%-d %b')} → {we.strftime('%-d %b %Y')}"
    p_str = ", ".join(participants)

    # Slot rows
    rows_html = ""
    for slot in slots:
        idx = slot["slot_index"]
        time_range = _format_utc_range(slot["start_utc"], slot["end_utc"])
        local_times = slot.get("participants_local", {})

        # Participant avatars
        avatars = "".join(
            _participant_avatar(p, i) for i, p in enumerate(participants)
        )

        # Local time subtitles
        subtitles = "  ·  ".join(
            f"{p.split('@')[0]}: {t}" for p, t in local_times.items()
        )

        rows_html += f"""
        <div style="padding:14px 20px;border-bottom:1px solid #f1f5f9;
                    display:flex;align-items:center;gap:12px;">
          <div style="width:24px;height:24px;border-radius:50%;background:#f1f5f9;
                      color:#6b7280;display:flex;align-items:center;justify-content:center;
                      font-size:11px;font-weight:700;flex-shrink:0;">{idx}</div>
          <div style="flex:1;min-width:0;">
            <div style="font-weight:600;color:#111;">{time_range}</div>
            <div style="font-size:11px;color:#9ca3af;margin-top:2px;
                        white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">{subtitles}</div>
          </div>
          <div style="display:flex;flex-direction:row;margin-left:4px;">
            {avatars}
          </div>
          <span style="font-size:12px;font-weight:600;color:#16a34a;
                       white-space:nowrap;flex-shrink:0;">● All free</span>
        </div>"""

    if not rows_html:
        rows_html = """
        <div style="padding:32px 20px;text-align:center;color:#6b7280;">
          No available slots found in this window.
        </div>"""

    n = len(slots)
    slot_word = "slot" if n == 1 else "slots"

    return f"""<div style="{_CARD_CSS}">
  <!-- Header -->
  <div style="background:#1e293b;padding:14px 20px;">
    <div style="font-size:10px;font-weight:700;letter-spacing:0.1em;
                color:#94a3b8;margin-bottom:4px;">SEARCHING FOR</div>
    <div style="color:#f1f5f9;font-size:13px;">
      <strong>{duration_minutes} min</strong> · with {p_str} · {win_str}
    </div>
  </div>
  <!-- Available count -->
  <div style="background:#f0fdf4;border-bottom:1px solid #bbf7d0;
              padding:10px 20px;display:flex;justify-content:space-between;align-items:center;">
    <span style="font-weight:700;font-size:14px;color:#15803d;">{n} available {slot_word}</span>
    <span style="font-size:11px;color:#6b7280;">times shown in UTC</span>
  </div>
  <!-- Slots -->
  <div style="background:white;">{rows_html}</div>
</div>"""


# ── Booking confirmation ──────────────────────────────────────────────────────


def render_booking_html(
    title: str,
    start_utc: str,
    end_utc: str,
    participants: list[str],
    organiser: str,
    video_link: Optional[str],
    event_id: str,
) -> str:
    """Return a self-contained HTML artifact for a booking confirmation."""

    time_range = _format_utc_range(start_utc, end_utc)

    # Participant chips (exclude organiser)
    others = [p for p in participants if p.lower() != organiser.lower()]
    all_people = [organiser] + others
    chips = " ".join(
        _participant_chip(p, i) for i, p in enumerate(all_people)
    )

    meet_row = ""
    if video_link:
        display = video_link.replace("https://", "")
        meet_row = f"""
    <div style="padding:12px 20px;border-bottom:1px solid #f1f5f9;
                display:flex;gap:16px;align-items:center;">
      <span style="font-size:10px;font-weight:700;letter-spacing:0.08em;
                   color:#94a3b8;width:44px;flex-shrink:0;">MEET</span>
      <a href="{video_link}" style="font-size:13px;color:#4f46e5;text-decoration:none;
                font-weight:500;">{display}</a>
    </div>"""

    return f"""<div style="{_CARD_CSS}">
  <!-- Header -->
  <div style="background:#1e293b;padding:14px 20px;">
    <div style="font-size:10px;font-weight:700;letter-spacing:0.1em;
                color:#4ade80;margin-bottom:4px;">BOOKED ✓</div>
    <div style="font-size:16px;font-weight:700;color:white;">{title}</div>
  </div>
  <!-- Details -->
  <div style="background:white;">
    <div style="padding:12px 20px;border-bottom:1px solid #f1f5f9;
                display:flex;gap:16px;align-items:center;">
      <span style="font-size:10px;font-weight:700;letter-spacing:0.08em;
                   color:#94a3b8;width:44px;flex-shrink:0;">WHEN</span>
      <span style="font-size:13px;font-weight:600;">{time_range}</span>
    </div>
    {meet_row}
    <div style="padding:12px 20px;display:flex;gap:16px;align-items:flex-start;">
      <span style="font-size:10px;font-weight:700;letter-spacing:0.08em;
                   color:#94a3b8;width:44px;flex-shrink:0;padding-top:5px;">WITH</span>
      <div style="display:flex;flex-wrap:wrap;gap:6px;">{chips}</div>
    </div>
    <div style="padding:8px 20px 12px;border-top:1px solid #f1f5f9;">
      <span style="font-size:10px;color:#d1d5db;">Event ID: {event_id}</span>
    </div>
  </div>
</div>"""


# ── Reschedule confirmation ───────────────────────────────────────────────────


def render_reschedule_html(
    title: str,
    start_utc: str,
    end_utc: str,
    participants: list[str],
    organiser: str,
    event_id: str,
) -> str:
    """Return an HTML artifact for a reschedule confirmation."""

    time_range = _format_utc_range(start_utc, end_utc)
    all_people = [organiser] + [p for p in participants if p.lower() != organiser.lower()]
    chips = " ".join(_participant_chip(p, i) for i, p in enumerate(all_people))

    return f"""<div style="{_CARD_CSS}">
  <div style="background:#1e293b;padding:14px 20px;">
    <div style="font-size:10px;font-weight:700;letter-spacing:0.1em;
                color:#fbbf24;margin-bottom:4px;">RESCHEDULED ✓</div>
    <div style="font-size:16px;font-weight:700;color:white;">{title}</div>
  </div>
  <div style="background:white;">
    <div style="padding:12px 20px;border-bottom:1px solid #f1f5f9;
                display:flex;gap:16px;align-items:center;">
      <span style="font-size:10px;font-weight:700;letter-spacing:0.08em;
                   color:#94a3b8;width:44px;flex-shrink:0;">NEW TIME</span>
      <span style="font-size:13px;font-weight:600;">{time_range}</span>
    </div>
    <div style="padding:12px 20px;display:flex;gap:16px;align-items:flex-start;">
      <span style="font-size:10px;font-weight:700;letter-spacing:0.08em;
                   color:#94a3b8;width:44px;flex-shrink:0;padding-top:5px;">WITH</span>
      <div style="display:flex;flex-wrap:wrap;gap:6px;">{chips}</div>
    </div>
    <div style="padding:8px 20px 12px;border-top:1px solid #f1f5f9;">
      <span style="font-size:10px;color:#d1d5db;">Event ID: {event_id}</span>
    </div>
  </div>
</div>"""


# ── Cancellation confirmation ─────────────────────────────────────────────────


def render_cancel_html(event_id: str) -> str:
    """Return an HTML artifact for a cancellation confirmation."""
    return f"""<div style="{_CARD_CSS}">
  <div style="background:#1e293b;padding:14px 20px;">
    <div style="font-size:10px;font-weight:700;letter-spacing:0.1em;
                color:#f87171;margin-bottom:4px;">CANCELLED ✓</div>
    <div style="font-size:14px;color:#94a3b8;">The event has been removed from all calendars.</div>
  </div>
  <div style="background:white;padding:12px 20px;">
    <span style="font-size:11px;color:#d1d5db;">Event ID: {event_id}</span>
  </div>
</div>"""
