"""AppKit MCP BPMN component."""
