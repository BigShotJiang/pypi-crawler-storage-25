"""
Armanid Detection Results
Creator: Arman Guriyan | Epic Rabbit
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Tuple
import numpy as np


@dataclass
class BoundingBox:
    x1:float; y1:float; x2:float; y2:float
    conf:float; cls_id:int; label:str
    track_id:Optional[int]=None

    @property
    def xyxy(self): return (self.x1,self.y1,self.x2,self.y2)
    @property
    def xywh(self):
        return ((self.x1+self.x2)/2,(self.y1+self.y2)/2,self.x2-self.x1,self.y2-self.y1)
    @property
    def width(self):  return self.x2-self.x1
    @property
    def height(self): return self.y2-self.y1
    @property
    def area(self):   return self.width*self.height

    def __repr__(self):
        t = f",id={self.track_id}" if self.track_id is not None else ""
        return f"BoundingBox('{self.label}',{self.conf:.2f},{self.x1:.0f},{self.y1:.0f},{self.x2:.0f},{self.y2:.0f}{t})"


class DetectionResult:
    def __init__(self, raw):
        self._raw=raw; self.image=raw.orig_img
        self.path=getattr(raw,"path",""); self.speed=getattr(raw,"speed",{})
        self.names=raw.names; self.boxes=self._parse(raw)

    def _parse(self,raw):
        if raw.boxes is None: return []
        d=raw.boxes
        xy=d.xyxy.cpu().numpy() if hasattr(d.xyxy,"cpu") else np.array(d.xyxy)
        cf=d.conf.cpu().numpy() if hasattr(d.conf,"cpu") else np.array(d.conf)
        cl=d.cls.cpu().numpy().astype(int) if hasattr(d.cls,"cpu") else np.array(d.cls,dtype=int)
        ti=None
        if d.id is not None:
            ti=d.id.cpu().numpy().astype(int) if hasattr(d.id,"cpu") else np.array(d.id,dtype=int)
        return [BoundingBox(float(xy[i,0]),float(xy[i,1]),float(xy[i,2]),float(xy[i,3]),
                float(cf[i]),int(cl[i]),self.names.get(int(cl[i]),str(int(cl[i]))),
                int(ti[i]) if ti is not None else None) for i in range(len(xy))]

    def show(self,title="Armanid"):
        import cv2; cv2.imshow(title,self._raw.plot()); cv2.waitKey(0); cv2.destroyAllWindows()

    def save(self,path:str):
        import cv2; cv2.imwrite(path,self._raw.plot()); print(f"[Armanid] Saved \u2192 {path}")

    def plot(self): return self._raw.plot()

    def filter(self,labels=None,min_conf=0.0):
        self.boxes=[b for b in self.boxes if(not labels or b.label in labels) and b.conf>=min_conf]
        return self

    @property
    def labels(self):      return [b.label for b in self.boxes]
    @property
    def confidences(self): return [b.conf  for b in self.boxes]

    def summary(self):
        from collections import Counter; return dict(Counter(self.labels))

    def __len__(self):  return len(self.boxes)
    def __iter__(self): return iter(self.boxes)
    def __repr__(self): return f"DetectionResult(detections={len(self.boxes)}, path='{self.path}')"
