"""
Armanid Engine Patcher
Creator: Arman Guriyan | Epic Rabbit
"""
from pathlib import Path

# All byte sequences to replace in .pt files (stored as byte arrays)
_P = [
    (b"ultralytics.nn.tasks",           b"armanid._engine.nn.tasks "),
    (b"ultralytics.nn.modules.block",   b"armanid._engine.nn.mblock"),
    (b"ultralytics.nn.modules.conv",    b"armanid._engine.nn.mconv "),
    (b"ultralytics.nn.modules.head",    b"armanid._engine.nn.mhead "),
    (b"ultralytics.nn.modules",         b"armanid._engine.nn.module"),
    (b"ultralytics.engine.results",     b"armanid._engine.ng.result"),
    (b"ultralytics.utils.loss",         b"armanid._engine.utils.loss"),
    (b"ultralytics",                    b"armanid_eng"),
    (b"Ultralytics YOLO",               b"Armanid Model"),
    (b"Ultralytics",                    b"Armanid    "),
    (b"DetectionModel",                 b"ArDetectModel "),
    (b"SegmentationModel",              b"ArSegmentModel"),
    (b"PoseModel",                      b"ArPoseModel   "),
    (b"ClassificationModel",            b"ArClassModel   "),
    (b"BaseModel",                      b"ArBaseModel"),
    (b"Ensemble",                       b"ArEnsemble"),
    (b"YOLOv8",                         b"Armanid"),
    (b"yolov8",                         b"armanid"),
    (b"YOLO",                           b"ARMD"),
    (b"yolo",                           b"armd"),
]

_SUSPECT = [
    bytes([117,108,116,114,97,108,121,116,105,99,115]),
    bytes([89,79,76,79]),
    bytes([121,111,108,111,118]),
]


def patch_file(src: str, dst: str = None) -> str:
    s = Path(src)
    d = Path(dst) if dst else s
    print(f"[Armanid] Patching {s.name} ...", end=" ", flush=True)
    data = s.read_bytes()
    for old, new in _P:
        data = data.replace(old, new)
    d.parent.mkdir(parents=True, exist_ok=True)
    d.write_bytes(data)
    print("Done")
    return str(d)


def verify_file(path: str) -> dict:
    data  = Path(path).read_bytes()
    found = []
    for s in _SUSPECT:
        pos = 0
        while True:
            i = data.find(s, pos)
            if i == -1: break
            ctx = data[max(0,i-10):i+len(s)+10]
            found.append({"string": s.decode("ascii","replace"), "offset": i,
                          "context": ctx.decode("ascii","replace")})
            pos = i + len(s)
    return {"clean": not found, "found": found,
            "size_kb": Path(path).stat().st_size // 1024}
