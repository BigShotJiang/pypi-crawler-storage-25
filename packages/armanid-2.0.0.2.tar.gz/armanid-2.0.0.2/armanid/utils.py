from __future__ import annotations
import time
import numpy as np
from pathlib import Path

_COLORS = [
    (255,56,56),(255,112,31),(207,210,49),(72,249,10),(26,147,52),
    (0,212,187),(0,194,255),(100,115,255),(132,56,255),(255,149,200),
]

def _color(cls_id):
    return _COLORS[cls_id % len(_COLORS)]


def draw_detections(image, result, line_width=2, font_scale=0.6, show_conf=True):
    import cv2
    img = image.copy()
    for b in result.boxes:
        c = _color(b.cls_id)
        x1, y1, x2, y2 = int(b.x1), int(b.y1), int(b.x2), int(b.y2)
        cv2.rectangle(img, (x1,y1), (x2,y2), c, line_width)
        tid = (" #" + str(b.track_id)) if b.track_id is not None else ""
        conf_str = (" " + format(b.conf, ".2f")) if show_conf else ""
        txt = b.label + tid + conf_str
        (tw, th), bl = cv2.getTextSize(txt, cv2.FONT_HERSHEY_SIMPLEX, font_scale, 1)
        top = max(y1 - th - bl - 4, 0)
        cv2.rectangle(img, (x1, top), (x1+tw+4, y1), c, -1)
        cv2.putText(img, txt, (x1+2, y1-bl-2), cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255,255,255), 1, cv2.LINE_AA)
    return img


def save_detections(result, output_path, draw=True):
    import cv2
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    img = result.plot() if draw else result.image
    cv2.imwrite(str(out), img)
    print("[Armanid] Saved -> " + str(out))
    return out


def detections_to_json(result) -> list:
    return [{
        "label": b.label, "conf": round(b.conf, 4), "cls_id": b.cls_id,
        "x1": round(b.x1, 2), "y1": round(b.y1, 2),
        "x2": round(b.x2, 2), "y2": round(b.y2, 2),
        "width": round(b.width, 2), "height": round(b.height, 2),
        "track_id": b.track_id,
    } for b in result.boxes]


def run_webcam(model, cam_index=0, conf=0.25):
    import cv2
    cap = cv2.VideoCapture(cam_index)
    if not cap.isOpened():
        raise RuntimeError("[Armanid] Cannot open camera index " + str(cam_index))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    prev = 0
    frame_n = 0
    print("[Armanid] Webcam started - Q to quit, S to save frame")
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        frame = cv2.flip(frame, 1)
        h, w = frame.shape[:2]
        results = model.detect(frame, conf=conf)
        ann = draw_detections(frame, results[0]) if results else frame.copy()
        now = time.time()
        fps = 1.0 / (now - prev) if prev else 0.0
        prev = now
        cv2.rectangle(ann, (0,0), (330,105), (18,18,18), -1)
        cv2.putText(ann, "ARMANID  v2.0.0", (10,28), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,150), 2)
        cv2.putText(ann, "Arman Guriyan",   (10,50), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (150,150,255), 1)
        cv2.putText(ann, "Epic Rabbit",     (10,68), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (100,200,255), 1)
        cv2.putText(ann, "FPS: " + format(fps, ".1f"), (10,95), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,100), 2)
        n = len(results[0]) if results else 0
        cv2.putText(ann, "Objects: " + str(n), (w-170,30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,255), 2)
        if results and n:
            y = 60
            for lbl, cnt in list(results[0].summary().items())[:5]:
                cv2.putText(ann, str(lbl) + ": " + str(cnt), (w-180,y), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (200,200,200), 1)
                y += 22
        cv2.imshow("Armanid | Arman Guriyan | Epic Rabbit", ann)
        frame_n += 1
        k = cv2.waitKey(1) & 0xFF
        if k == ord("q"):
            break
        elif k == ord("s"):
            fname = "armanid_frame_" + str(frame_n) + ".jpg"
            cv2.imwrite(fname, ann)
            print("  Saved: " + fname)
    cap.release()
    cv2.destroyAllWindows()
    print("[Armanid] Webcam closed.")
