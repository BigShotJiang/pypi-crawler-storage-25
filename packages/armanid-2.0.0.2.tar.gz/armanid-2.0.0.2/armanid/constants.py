"""
Armanid Constants
Creator: Arman Guriyan | Epic Rabbit
"""
from enum import IntEnum


class HandLandmark(IntEnum):
    WRIST = 0
    THUMB_CMC = 1
    THUMB_MCP = 2
    THUMB_IP = 3
    THUMB_TIP = 4
    INDEX_FINGER_MCP = 5
    INDEX_FINGER_PIP = 6
    INDEX_FINGER_DIP = 7
    INDEX_FINGER_TIP = 8
    MIDDLE_FINGER_MCP = 9
    MIDDLE_FINGER_PIP = 10
    MIDDLE_FINGER_DIP = 11
    MIDDLE_FINGER_TIP = 12
    RING_FINGER_MCP = 13
    RING_FINGER_PIP = 14
    RING_FINGER_DIP = 15
    RING_FINGER_TIP = 16
    PINKY_MCP = 17
    PINKY_PIP = 18
    PINKY_DIP = 19
    PINKY_TIP = 20


class GestureType:
    THUMBS_UP    = "thumbs_up"
    THUMBS_DOWN  = "thumbs_down"
    VICTORY      = "victory"
    ROCK         = "rock"
    PAPER        = "paper"
    SCISSORS     = "scissors"
    OK           = "ok"
    POINTING     = "pointing"
    CALL_ME      = "call_me"
    FIST         = "fist"
    OPEN_HAND    = "open_hand"
    UNKNOWN      = "unknown"


MAX_HANDS = 2

HAND_CONNECTIONS = frozenset([
    (HandLandmark.WRIST,             HandLandmark.THUMB_CMC),
    (HandLandmark.THUMB_CMC,         HandLandmark.THUMB_MCP),
    (HandLandmark.THUMB_MCP,         HandLandmark.THUMB_IP),
    (HandLandmark.THUMB_IP,          HandLandmark.THUMB_TIP),
    (HandLandmark.WRIST,             HandLandmark.INDEX_FINGER_MCP),
    (HandLandmark.INDEX_FINGER_MCP,  HandLandmark.INDEX_FINGER_PIP),
    (HandLandmark.INDEX_FINGER_PIP,  HandLandmark.INDEX_FINGER_DIP),
    (HandLandmark.INDEX_FINGER_DIP,  HandLandmark.INDEX_FINGER_TIP),
    (HandLandmark.WRIST,             HandLandmark.MIDDLE_FINGER_MCP),
    (HandLandmark.MIDDLE_FINGER_MCP, HandLandmark.MIDDLE_FINGER_PIP),
    (HandLandmark.MIDDLE_FINGER_PIP, HandLandmark.MIDDLE_FINGER_DIP),
    (HandLandmark.MIDDLE_FINGER_DIP, HandLandmark.MIDDLE_FINGER_TIP),
    (HandLandmark.WRIST,             HandLandmark.RING_FINGER_MCP),
    (HandLandmark.RING_FINGER_MCP,   HandLandmark.RING_FINGER_PIP),
    (HandLandmark.RING_FINGER_PIP,   HandLandmark.RING_FINGER_DIP),
    (HandLandmark.RING_FINGER_DIP,   HandLandmark.RING_FINGER_TIP),
    (HandLandmark.WRIST,             HandLandmark.PINKY_MCP),
    (HandLandmark.PINKY_MCP,         HandLandmark.PINKY_PIP),
    (HandLandmark.PINKY_PIP,         HandLandmark.PINKY_DIP),
    (HandLandmark.PINKY_DIP,         HandLandmark.PINKY_TIP),
    (HandLandmark.INDEX_FINGER_MCP,  HandLandmark.MIDDLE_FINGER_MCP),
    (HandLandmark.MIDDLE_FINGER_MCP, HandLandmark.RING_FINGER_MCP),
    (HandLandmark.RING_FINGER_MCP,   HandLandmark.PINKY_MCP),
])

FINGER_TIPS = [
    HandLandmark.THUMB_TIP,
    HandLandmark.INDEX_FINGER_TIP,
    HandLandmark.MIDDLE_FINGER_TIP,
    HandLandmark.RING_FINGER_TIP,
    HandLandmark.PINKY_TIP,
]
