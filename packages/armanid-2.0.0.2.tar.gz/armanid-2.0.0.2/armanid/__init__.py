"""
Armanid — Object Detection Library
Creator  : Arman Guriyan
Company  : Epic Rabbit
Version  : 2.0.0
"""
__version__ = "2.1.0"
__author__  = "Arman Guriyan"
__company__ = "Epic Rabbit"
__email__   = "arman@epicrabbit.io"
__license__ = "MIT"

from armanid.model   import Armanid
from armanid.results import DetectionResult, BoundingBox
from armanid.utils   import draw_detections, save_detections, run_webcam

__all__ = [
    "Armanid","DetectionResult","BoundingBox",
    "draw_detections","save_detections","run_webcam",
    "__version__","__author__","__company__",
]
