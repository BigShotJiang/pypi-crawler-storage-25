# Armanid

**Professional Object Detection Library — by Epic Rabbit**

Armanid is a clean, simple, and powerful object detection library built on the Epic Rabbit engine. Detect objects in images, videos, and webcams with just a few lines of code.

## Installation

```bash
pip install epic-rabbit
pip install armanid
```

## Quick Start

```python
from armanid import Armanid

model = Armanid("armanid-nano")
results = model.detect("image.jpg")
results[0].show()
```

## Webcam Detection

```python
from armanid import Armanid
from armanid.utils import run_webcam

model = Armanid("armanid-nano")
run_webcam(model, cam_index=0, conf=0.25)
```

## All Features

```python
from armanid import Armanid

model = Armanid("armanid-nano")

results = model.detect("image.jpg", conf=0.25)

for box in results[0].boxes:
    print(box.label, box.conf, box.xyxy)

results[0].save("output.jpg")

for result in model.track("video.mp4", stream=True):
    for box in result.boxes:
        print(box.track_id, box.label)

model.train(data="dataset.yaml", epochs=100)

model.export(format="onnx")
```

## Available Models

| Model | Description |
|-------|-------------|
| `armanid-nano` | Fastest, smallest |
| `armanid-small` | Fast, good accuracy |
| `armanid-medium` | Balanced |
| `armanid-large` | High accuracy |
| `armanid-xlarge` | Maximum accuracy |
| `armanid-nano-seg` | Segmentation |
| `armanid-nano-pose` | Pose estimation |

## Detection Result API

```python
result = model.detect("image.jpg")[0]

result.boxes          # List of BoundingBox objects
result.labels         # ["person", "car", ...]
result.confidences    # [0.92, 0.87, ...]
result.summary()      # {"person": 2, "car": 1}
result.show()         # Display image
result.save("out.jpg")
result.plot()         # Returns annotated numpy array

box = result.boxes[0]
box.label             # "person"
box.conf              # 0.92
box.xyxy              # (x1, y1, x2, y2)
box.xywh              # (cx, cy, w, h)
box.width
box.height
box.area
box.track_id          # When tracking
```

## Creator

**Arman Guriyan** — Epic Rabbit

## License

MIT License
