"""
Per-domain security sub-scores for BOB.

Groups deductions from a finalized ScoreEngine by security domain and
computes a score (0–10) for each domain independently.

Domains:
  ssh        — SSH server/client configuration (checks/ssh.py)
  samba      — Samba security audit (checks/samba.py)
  file_perms — Sensitive file permissions and sudoers (checks/file_perms.py)
  updates    — System package updates (checks/updates.py)
  hardening  — Kernel hardening and security tools (checks/hardening.py)
  disk       — Disk health: SMART + partition usage (checks/disk.py)
  firewall   — Firewall rules, ports, services, logs (everything else)

Usage:
    from bob.domain_scores import compute_domain_scores, DOMAINS

    scores = compute_domain_scores(engine)
    for domain in DOMAINS:
        info = scores[domain]
        print(f"{info['label']}: {info['score']}/10")
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from bob.scoring import ScoreEngine

from bob.scoring import MAX_SCORE, FindingLevel

# ---------------------------------------------------------------------------
# Domain definitions
# ---------------------------------------------------------------------------

# Ordered list of canonical domain identifiers (display order).
DOMAINS: list[str] = ["ssh", "samba", "file_perms", "updates", "hardening", "disk", "firewall"]

# Human-readable English labels for each domain.
_LABELS: dict[str, str] = {
    "ssh":        "SSH",
    "samba":      "Samba Security",
    "file_perms": "Files & Access",
    "updates":    "Updates",
    "hardening":  "Hardening",
    "disk":       "Disk Health",
    "firewall":   "Firewall & Services",
}

# Maximum total deduction (in points) that a single tool can contribute to its
# domain score.  Prevents one poorly-maintained tool from dominating the domain
# score when it emits several independent findings (e.g. rkhunter: db outdated
# + no scan run = 2 findings for the same configuration problem → capped at 1).
_TOOL_CAPS: dict[str, int] = {
    "rootkit":        1,   # rkhunter/chkrootkit — db age + scan age
    "clamav":         1,   # ClamAV — db age + scan frequency
    "file_integrity": 1,   # AIDE/Tripwire — presence + freshness
}

# Known key prefixes that map to specific domains.
# Any prefix not listed here → "firewall" (catch-all).
_PREFIX_TO_DOMAIN: dict[str, str] = {
    "ssh":              "ssh",
    "samba":            "samba",
    "file_perms":       "file_perms",
    "updates":          "updates",
    "hardening":        "hardening",
    "kernel_hardening": "hardening",
    "kernel_modules":   "hardening",
    "cron_audit":       "hardening",
    "services_state":   "hardening",
    "user_accounts":    "file_perms",
    "password_policy":  "hardening",
    "memory":           "hardening",
    "clamav":           "hardening",
    "auditd":           "hardening",
    "secure_boot":      "hardening",
    "backup":           "disk",
    "file_integrity":   "hardening",
    "log_rotation":     "hardening",
    "mac_policy":       "hardening",
    "ntp":              "hardening",
    "rootkit":          "hardening",
    "suid_audit":       "hardening",
    "logs":             "hardening",
    "umask":            "hardening",
    "auth_log":         "ssh",
    "ssl_certs":        "hardening",
    "systemd_timers":   "hardening",
    "firmware":         "hardening",
    "disk":             "disk",
}


def _key_to_domain(key: str | None) -> str | None:
    """
    Map a deduction key (e.g. 'ssh.password_auth') to its domain.

    Returns None for synthetic/cap deductions (empty key), which are
    excluded from per-domain scoring.
    """
    if not key or not isinstance(key, str):
        return None
    prefix = key.split(".", 1)[0]
    return _PREFIX_TO_DOMAIN.get(prefix, "firewall")


# ---------------------------------------------------------------------------
# Main computation
# ---------------------------------------------------------------------------

def active_domains_from_engine(engine: "ScoreEngine") -> frozenset[str]:
    """
    Return the set of domain names that have at least one finding or deduction.

    Used to hide domains whose service is not installed (e.g. Samba absent →
    no samba.* findings → domain excluded from the score display).
    """
    _actionable = (FindingLevel.WARN, FindingLevel.ALERT)
    active: set[str] = set()
    for finding in engine.findings:
        if finding.level not in _actionable:
            continue
        domain = _key_to_domain(finding.key)
        if domain:
            active.add(domain)
    for finding in engine.ignored_findings:
        if finding.level not in _actionable:
            continue
        domain = _key_to_domain(finding.key)
        if domain:
            active.add(domain)
    for deduction in engine.breakdown:
        domain = _key_to_domain(deduction.key)
        if domain:
            active.add(domain)
    return frozenset(active)


def compute_domain_scores(engine: "ScoreEngine") -> dict[str, dict]:
    """
    Compute per-domain security sub-scores from a finalized ScoreEngine.

    Each domain score is computed independently as:
        max(0, MAX_SCORE - sum_of_deductions_for_domain)

    Deductions without a key (synthetic/cap) are excluded.

    Args:
        engine: A finalized ScoreEngine (engine.finalize() must have been called).

    Returns:
        Dict mapping domain identifier → {
            "score":      int  — 0 to 10,
            "deductions": int  — total points deducted in this domain,
            "label":      str  — human-readable English label,
        }
    """
    domain_deductions: dict[str, int] = {d: 0 for d in DOMAINS}
    tool_contributed:  dict[str, int] = {}   # key_prefix → points already counted

    for deduction in engine.breakdown:
        key    = deduction.key
        domain = _key_to_domain(key)
        if domain is None:
            continue
        points = deduction.points
        prefix = key.split(".", 1)[0] if key else ""
        cap    = _TOOL_CAPS.get(prefix)
        if cap is not None:
            already = tool_contributed.get(prefix, 0)
            allowed = min(points, cap - already)
            if allowed <= 0:
                deduction.was_capped = True
                continue
            if allowed < points:
                deduction.was_capped = True
            tool_contributed[prefix] = already + allowed
            points = allowed
        domain_deductions[domain] += points

    # Apply engine-level domain cap (e.g. firewall inactive → max 3/10 for the
    # firewall domain).  The cap delta is normally added to the breakdown when the
    # global raw_score exceeds the cap, but if many other deductions already push
    # the global raw_score below the cap threshold the delta is never appended.
    # We enforce it here at the domain level so the displayed score is always ≤ cap.
    engine_cap = engine.cap_info
    if engine_cap and engine_cap.key:
        cap_domain = _key_to_domain(engine_cap.key)
        if cap_domain and cap_domain in domain_deductions:
            raw_domain = MAX_SCORE - domain_deductions[cap_domain]
            if raw_domain > engine_cap.maximum:
                domain_deductions[cap_domain] += raw_domain - engine_cap.maximum

    return {
        domain: {
            "score":      max(0, min(MAX_SCORE, MAX_SCORE - domain_deductions[domain])),
            "deductions": domain_deductions[domain],
            "label":      _LABELS.get(domain, domain.capitalize()),
        }
        for domain in DOMAINS
    }


# ---------------------------------------------------------------------------
# Global score from domain average
# ---------------------------------------------------------------------------

def compute_global_from_domains(
    domain_scores: dict,
    active_domains: "frozenset[str]",
) -> int:
    """
    Compute the global security score as the mean of active domain scores.

    Only domains with at least one finding or deduction are included (i.e.
    domains whose service is not installed are excluded).  The result is
    rounded and clamped to [0, MAX_SCORE].

    Args:
        domain_scores:  Output of compute_domain_scores().
        active_domains: Output of active_domains_from_engine().

    Returns:
        Integer global score 0–10.
    """
    active = [d for d in DOMAINS if d in active_domains and d in domain_scores]
    if not active:
        return MAX_SCORE
    total = sum(domain_scores[d]["score"] for d in active)
    return max(0, min(MAX_SCORE, round(total / len(active))))


def apply_domain_score_override(engine: "ScoreEngine") -> None:
    """
    Compute the domain-averaged global score and set it on the engine.

    Must be called after engine.finalize().  All subsequent reads of
    engine.score will return the domain-averaged value.

    Args:
        engine: A finalized ScoreEngine instance.
    """
    scores = compute_domain_scores(engine)
    active = active_domains_from_engine(engine)
    engine.set_global_score(compute_global_from_domains(scores, active))
    engine._domain_scores  = scores
    engine._active_domains = active


# ---------------------------------------------------------------------------
# Text rendering
# ---------------------------------------------------------------------------

_BAR_WIDTH  = 10   # total bar characters
_BAR_FILLED = "█"
_BAR_EMPTY  = "░"


def render_domain_scores(
    scores: dict[str, dict],
    t=None,
    active_domains: "frozenset[str] | None" = None,
) -> list[str]:
    """
    Render domain scores as a list of indented text lines.

    Args:
        scores: Output of compute_domain_scores().
        t:      Optional translation function.  When provided the title line
                uses the locale key 'domain_scores.title'; otherwise the
                English default is used.

    Returns:
        List of strings (one per line), ready for print().
    """
    title = (t("domain_scores.title") if t else None) or "Domain Scores"

    lines: list[str] = [f"  {title}"]
    lines.append("  " + "─" * 40)

    if not scores:
        lines.append("  (no data)")
        return lines

    def _label(domain: str, fallback: str) -> str:
        if not t:
            return fallback
        translated = t(f"domain_scores.{domain}")
        return translated if translated != f"domain_scores.{domain}" else fallback

    labels = {d: _label(d, scores[d]["label"]) for d in DOMAINS if d in scores}
    label_width = max(len(lbl) for lbl in labels.values())

    for domain in DOMAINS:
        if domain not in scores:
            continue
        if active_domains is not None and domain not in active_domains:
            continue
        info   = scores[domain]
        score  = info["score"]
        label  = labels[domain]
        filled = int(score * _BAR_WIDTH / MAX_SCORE)
        empty  = _BAR_WIDTH - filled
        bar    = _BAR_FILLED * filled + _BAR_EMPTY * empty
        lines.append(
            f"  {label:<{label_width}}  {score:>2}/10  {bar}"
        )

    return lines
