#|
#|  Copyright The Telepact Authors
#|
#|  Licensed under the Apache License, Version 2.0 (the "License");
#|  you may not use this file except in compliance with the License.
#|  You may obtain a copy of the License at
#|
#|  https://www.apache.org/licenses/LICENSE-2.0
#|
#|  Unless required by applicable law or agreed to in writing, software
#|  distributed under the License is distributed on an "AS IS" BASIS,
#|  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#|  See the License for the specific language governing permissions and
#|  limitations under the License.
#|

import click
import os
import json
import argparse
import msgpack
import shutil
import yaml
from typing import cast, Pattern
import jinja2
import click
from importlib.metadata import PackageNotFoundError, version as package_version
from pathlib import Path
import re
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import Response
from starlette.routing import Route, WebSocketRoute
from starlette.websockets import WebSocket, WebSocketDisconnect, WebSocketState

import time
import secrets
import random
import uvicorn
from .telepact import Client, FunctionRouter, Server, Message, Serializer, TelepactSchema, MockTelepactSchema, MockServer, SerializationError
import asyncio
import requests

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .telepact.internal.types.TTypeDeclaration import TTypeDeclaration

from .resources import load_calculator_telepact_json


def _get_cli_version() -> str:
    return package_version('telepact-cli')


def _demo_unavailable_response() -> Message | None:
    if random.random() < 0.01:
        return Message({}, {'ErrorUnavailable': {}})
    return None


def bump_version(version: str) -> str:
    major, minor, patch = map(int, version.split('.'))
    patch += 1
    return f"{major}.{minor}.{patch}"


def _validate_package(ctx: click.Context, param: click.Parameter, value: str) -> str:
    lang = ctx.params.get('lang')
    if lang in ('java', 'go') and not value:
        raise click.BadParameter(
            '--package is required when --lang is {}'.format(lang))
    return value


@click.group()
@click.version_option(version=_get_cli_version(), prog_name='telepact')
def main() -> None:
    pass


@click.command()
@click.option('--schema-http-url', help='telepact schema directory', required=False)
@click.option('--schema-dir', help='telepact schema directory', required=False)
@click.option('--lang', help='Language target (one of "java", "py", "ts", or "go")', required=True)
@click.option('--out', help='Output directory', required=True)
@click.option('--package', help='Package name (required when --lang is "java" or "go")', callback=_validate_package)
def codegen(schema_http_url: str, schema_dir: str, lang: str, out: str, package: str) -> None:
    """
    Generate code bindings for a Telepact API schema.
    """

    print('Telepact CLI')
    if schema_http_url:
        print('Schema http url:', schema_http_url)
        api_schema = get_api_from_http(schema_http_url)
        telepact_schema = TelepactSchema.from_json(api_schema)
    elif schema_dir:
        print('Schema directory:', schema_dir)
        telepact_schema = TelepactSchema.from_directory(schema_dir)

    else:
        raise click.BadParameter('Either --schema-http-url or --schema-dir must be provided.')
    
    
    print('Language target:', lang)
    print('Output directory:', out)
    if package:
        print('Package:', package)


    target = lang
    output_directory = out

    schema_data: list[dict[str, object]] = cast(
        list[dict[str, object]], telepact_schema.original)

    select = telepact_schema.parsed['_ext.Select_']
    possible_fn_selects = select.possible_selects
    possible_fn_selects.pop('fn.ping_', None)
    possible_fn_selects.pop('fn.api_', None)

    # Call the generate function
    _generate_internal(schema_data, possible_fn_selects, target, output_directory, package)


# Define the custom filter
def _regex_replace(s: str, find: str, replace: str) -> str:
    """A custom Jinja2 filter to perform regex replacement."""
    return re.sub(find, replace, s)


def _find_schema_key(schema_data: dict[str, object]) -> str:
    for key in schema_data:
        if key.startswith("struct") or key.startswith("union") or key.startswith("fn") or key.startswith("headers") or key.startswith('info') or key.startswith('errors'):
            return key
    raise Exception("No schema key found for " + str(schema_data.keys()))


def _find_tag_key(tag_data: dict[str, object]) -> str:
    for key in tag_data:
        if key != '///':
            return key
    raise Exception("No tag key found")


def _raise_error(message: str) -> None:
    raise Exception(message)


def _to_pascal_case(name: str) -> str:
    tokens = re.split(r'[^0-9A-Za-z]+', name)
    result = ''.join(token[:1].upper() + token[1:] for token in tokens if token)
    if not result:
        result = name.title()
    if result and result[0].isdigit():
        result = f'Fn{result}'
    return result


_GO_RESERVED_KEYWORDS: set[str] = {
    'break', 'default', 'func', 'interface', 'select', 'case', 'defer', 'go',
    'map', 'struct', 'chan', 'else', 'goto', 'package', 'switch', 'const',
    'fallthrough', 'if', 'range', 'type', 'continue', 'for', 'import', 'return',
    'var', 'bool', 'int', 'string', 'float64', 'error', 'byte', 'rune', 'any',
}


def _to_camel_case(name: str) -> str:
    pascal = _to_pascal_case(name)
    if not pascal:
        return name
    return pascal[:1].lower() + pascal[1:]


def _sanitize_go_identifier(name: str) -> str:
    sanitized = re.sub(r'[^0-9A-Za-z_]', '', name)
    if not sanitized:
        sanitized = 'Field'
    if sanitized[0].isdigit():
        sanitized = f'Field{sanitized}'
    lower = sanitized.lower()
    if lower in _GO_RESERVED_KEYWORDS:
        sanitized = f'{sanitized}_'
    return sanitized


def _process_go_fields(fields: dict[str, object]) -> list[dict[str, object]]:
    processed: list[dict[str, object]] = []
    for field_name, field_type in fields.items():
        base_name = field_name.replace('!', '')
        sanitized = _sanitize_go_identifier(base_name)
        method_name = _to_pascal_case(sanitized)
        param_name = _to_camel_case(sanitized)
        if sanitized.endswith('_'):
            param_name = sanitized
        processed.append({
            'json_name': field_name,
            'method_name': method_name,
            'param_name': param_name,
            'type': field_type,
            'optional': '!' in field_name,
            'nullable': isinstance(field_type, str) and '?' in field_type,
        })
    return processed


def _process_go_tags(tag_entries: list[dict[str, object]]) -> list[dict[str, object]]:
    processed_tags: list[dict[str, object]] = []
    for tag_entry in tag_entries:
        tag_key = _find_tag_key(tag_entry)
        tag_fields = cast(dict[str, object], tag_entry[tag_key])
        processed_tags.append({
            'json_name': tag_key,
            'name': _to_pascal_case(tag_key),
            'doc': tag_entry.get('///'),
            'fields': _process_go_fields(tag_fields),
        })
    return processed_tags


def _generate_internal(schema_data: list[dict[str, object]], possible_fn_selects: dict[str, object], target: str, output_dir: str, package_name: str) -> None:

    # Load jinja template from file
    # Adjust the path to your template directory if necessary
    template_loader = jinja2.PackageLoader(
        'telepact_cli', 'templates')
    template_env = jinja2.Environment(
        loader=template_loader, extensions=['jinja2.ext.do'])

    template_env.filters['regex_replace'] = _regex_replace
    template_env.filters['find_schema_key'] = _find_schema_key
    template_env.filters['find_tag_key'] = _find_tag_key
    template_env.filters['to_pascal_case'] = _to_pascal_case
    template_env.filters['to_camel_case'] = _to_camel_case
    template_env.globals['raise_error'] = _raise_error

    # Find all errors. definitions, and append to function results
    errors: list[dict[str, object]] = []
    for schema_entry in schema_data:
        schema_key = _find_schema_key(schema_entry)
        if schema_key.startswith('errors'):
            errors.extend(cast(list[dict[str, object]], schema_entry[schema_key]))

    if errors:
        for schema_entry in schema_data:
            schema_key = _find_schema_key(schema_entry)
            if schema_key.startswith('fn'):
                results = cast(list[dict[str, object]], schema_entry['->'])
                results.extend(errors)

    if target == "java":

        functions: list[str] = []

        def _write_java_file(jinja_file: str, input: dict, output_file: str) -> None:
            template = template_env.get_template(jinja_file)

            output = template.render(input)

            # Write the output to a file
            if output_dir:
                # Create the Path object for the directory
                output_path = Path(output_dir)

                # Ensure the directory exists
                output_path.mkdir(parents=True, exist_ok=True)

                file_path = output_path / output_file

                # Open the file for writing
                with file_path.open("w") as f:
                    f.write(output)

            else:
                print(output)

        for schema_entry in schema_data:
            schema_key = _find_schema_key(schema_entry)
            if schema_key.startswith('info') or schema_key.startswith('headers'):
                continue

            if schema_key.startswith("fn"):
                functions.append(schema_key)

            _write_java_file('java_type_2.j2', {
                'package': package_name, 'data': schema_entry, 'possible_fn_selects': possible_fn_selects}, f"{schema_key.split('.')[1]}.java")

        _write_java_file('java_server.j2', {
                         'package': package_name, 'functions': functions, 'possible_fn_selects': possible_fn_selects}, f"TypedServerHandler.java")

        _write_java_file('java_client.j2', {
                         'package': package_name, 'functions': functions, 'possible_fn_selects': possible_fn_selects}, f"TypedClient.java")

        _write_java_file('java_utility.j2', {
                         'package': package_name}, f"Utility_.java")

        _write_java_file('java_select.j2', {'package': package_name, 'possible_fn_selects': possible_fn_selects}, f"Select_.java")

    elif target == 'py':

        functions = []

        schema_entries: list[dict[str, object]] = []
        for schema_entry in schema_data:
            schema_key = _find_schema_key(schema_entry)
            if schema_key.startswith('info'):
                continue

            if schema_key.startswith("fn"):
                functions.append(schema_key)

            schema_entries.append(schema_entry)

        type_template = template_env.get_template(
            'py_all_2.j2')  # Specify your template file name

        output = type_template.render({
            'input': schema_entries,
            'functions': functions,
            'possible_fn_selects': possible_fn_selects
        })

        # Write the output to a file
        if output_dir:
            # Create the Path object for the directory
            output_path = Path(output_dir)

            # Ensure the directory exists
            output_path.mkdir(parents=True, exist_ok=True)

            file_path = output_path / f"gen_types.py"

            # Open the file for writing
            with file_path.open("w") as f:
                f.write(output)

            init_file_path = output_path / f"__init__.py"

            with init_file_path.open("w") as f:
                f.write('')

        else:
            print(output)

    elif target == 'ts':

        functions = []

        ts_schema_entries: list[dict[str, object]] = []
        for schema_entry in schema_data:
            schema_key = _find_schema_key(schema_entry)
            if schema_key.startswith('info'):
                continue

            if schema_key.startswith("fn"):
                functions.append(schema_key)

            ts_schema_entries.append(schema_entry)

        ts_type_template = template_env.get_template(
            'ts_all_2.j2')

        output = ts_type_template.render({
            'input': ts_schema_entries,
            'functions': functions,
            'possible_fn_selects': possible_fn_selects
        })

        # Write the output to a file
        if output_dir:
            # Create the Path object for the directory
            output_path = Path(output_dir)

            # Ensure the directory exists
            output_path.mkdir(parents=True, exist_ok=True)

            file_path = output_path / f"genTypes.ts"

            # Open the file for writing
            with file_path.open("w") as f:
                f.write(output)

        else:
            print(output)

    elif target == 'go':

        if not package_name:
            raise Exception('Go code generation requires --package to be set')

        go_entries: list[dict[str, object]] = []
        go_functions: list[dict[str, object]] = []

        for schema_entry in schema_data:
            schema_key = _find_schema_key(schema_entry)
            if schema_key.startswith('info') or schema_key.startswith('headers'):
                continue

            base_name = schema_key.split('.')[1]
            go_name = _to_pascal_case(base_name)
            doc = schema_entry.get('///')

            if schema_key.startswith('struct'):
                fields = cast(dict[str, object], schema_entry[schema_key])
                go_entries.append({
                    'kind': 'struct',
                    'schema_key': schema_key,
                    'name': go_name,
                    'doc': doc,
                    'fields': _process_go_fields(fields),
                })

            elif schema_key.startswith('union'):
                tags = cast(list[dict[str, object]], schema_entry[schema_key])
                go_entries.append({
                    'kind': 'union',
                    'schema_key': schema_key,
                    'name': go_name,
                    'doc': doc,
                    'tags': _process_go_tags(tags),
                })

            elif schema_key.startswith('fn'):
                input_fields = cast(dict[str, object], schema_entry[schema_key])
                result_tags = cast(list[dict[str, object]], schema_entry['->'])
                fn_entry: dict[str, object] = {
                    'kind': 'function',
                    'schema_key': schema_key,
                    'name': go_name,
                    'doc': doc,
                    'input_fields': _process_go_fields(input_fields),
                    'output_tags': _process_go_tags(result_tags),
                    'select': possible_fn_selects.get(schema_key, {}),
                    'raw_name': schema_key,
                    'camel_name': _to_camel_case(base_name),
                }
                go_entries.append(fn_entry)
                go_functions.append(fn_entry)

        go_template = template_env.get_template('go_all.j2')
        output = go_template.render({
            'package': package_name,
            'entries': go_entries,
            'functions': go_functions,
            'possible_fn_selects': possible_fn_selects,
        })

        if output_dir:
            output_path = Path(output_dir)
            output_path.mkdir(parents=True, exist_ok=True)
            file_path = output_path / "generated.go"
            with file_path.open("w") as f:
                f.write(output)
        else:
            print(output)


@click.command()
@click.option('--port', default=8000, help='Port to run the mock server on', envvar='MOCK_SERVER_PORT')
def demo_server(port: int) -> None:
    """
    Start a demo Telepact server.
    """

    shared_namespace = '__unauthenticated__'
    user_variables: dict[str, dict[str, float]] = {}
    user_evaluations: dict[str, list[dict[str, object]]] = {}
    session_tokens: dict[str, str] = {}
    usernames_by_token: dict[str, str] = {}

    def get_username(message: Message, require_session: bool = False) -> str | None:
        auth = cast(dict[str, object] | None, message.headers.get('@auth_'))
        if auth is None:
            return None
        if 'Ephemeral' in auth:
            if require_session:
                return None
            return cast(str, cast(dict[str, object], auth['Ephemeral'])['username'])
        if 'Session' in auth:
            token = cast(str, cast(dict[str, object], auth['Session'])['token'])
            return usernames_by_token.get(token)
        return None

    def get_user_variables(username: str) -> dict[str, float]:
        return user_variables.setdefault(username, {})

    def get_user_evaluations(username: str) -> list[dict[str, object]]:
        return user_evaluations.setdefault(username, [])

    def unauthenticated_response() -> Message:
        return Message({}, {'ErrorUnauthenticated_': {'message!': 'Valid authentication is required.'}})

    def unauthorized_response(message: str) -> Message:
        return Message({}, {'ErrorUnauthorized_': {'message!': message}})

    async def require_namespace(request_message: Message) -> tuple[Message | None, str | None]:
        unavailable_response = _demo_unavailable_response()
        if unavailable_response is not None:
            return unavailable_response, None
        if '@auth_' not in request_message.headers:
            return None, shared_namespace
        username = get_username(request_message)
        if username is None:
            return unauthenticated_response(), None
        return None, username

    def record_evaluation(username: str, expression: dict[str, object], result: float, successful: bool) -> None:
        get_user_evaluations(username).append({
            'expression': expression,
            'result': result,
            'timestamp': int(time.time()),
            'successful': successful,
        })

    def export_namespace(username: str) -> bytes:
        return msgpack.packb({
            'variables': get_user_variables(username),
            'evaluations': get_user_evaluations(username),
        }, use_bin_type=True)

    def parse_namespace_blob(blob: bytes) -> tuple[dict[str, float], list[dict[str, object]]]:
        try:
            namespace = msgpack.unpackb(blob, raw=False, strict_map_key=False)
        except (ValueError, msgpack.ExtraData, msgpack.FormatError, msgpack.StackError) as e:
            raise ValueError('Imported namespace blob must use the expected msgpack format.') from e
        if not isinstance(namespace, dict):
            raise ValueError('Imported namespace blob must decode to a msgpack object.')
        variables = namespace.get('variables')
        evaluations = namespace.get('evaluations')
        if not isinstance(variables, dict):
            raise ValueError('Imported namespace blob must include a variables object.')
        if not isinstance(evaluations, list):
            raise ValueError('Imported namespace blob must include an evaluations list.')

        parsed_variables: dict[str, float] = {}
        for name, value in variables.items():
            if not isinstance(name, str):
                raise ValueError('Imported namespace variable names must be strings.')
            # Reject bool explicitly because bool is a subclass of int in Python.
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError('Imported namespace variable values must be numbers.')
            parsed_variables[name] = float(value)

        parsed_evaluations: list[dict[str, object]] = []
        for evaluation in evaluations:
            if not isinstance(evaluation, dict):
                raise ValueError('Imported namespace evaluations must be objects.')
            parsed_evaluations.append(cast(dict[str, object], evaluation))

        return parsed_variables, parsed_evaluations

    def replace_namespace(username: str, blob: bytes) -> None:
        variables, evaluations = parse_namespace_blob(blob)
        user_variables[username] = variables
        user_evaluations[username] = evaluations

    def evaluate_expression(expression: dict[str, object], variables: dict[str, float]) -> tuple[float, list[str], bool]:
        kind, payload = next(iter(expression.items()))
        payload_dict = cast(dict[str, object], payload)

        if kind == 'Constant':
            return cast(float, payload_dict['value']), [], False

        if kind == 'Variable':
            name = cast(str, payload_dict['name'])
            if name not in variables:
                return 0.0, [name], False
            return variables[name], [], False

        left_result, left_unknowns, left_divide_by_zero = evaluate_expression(
            cast(dict[str, object], payload_dict['left']), variables)
        right_result, right_unknowns, right_divide_by_zero = evaluate_expression(
            cast(dict[str, object], payload_dict['right']), variables)

        unknown_variables = list(dict.fromkeys(left_unknowns + right_unknowns))
        if unknown_variables:
            return 0.0, unknown_variables, False
        if left_divide_by_zero or right_divide_by_zero:
            return 0.0, [], True

        if kind == 'Add':
            return left_result + right_result, [], False
        if kind == 'Sub':
            return left_result - right_result, [], False
        if kind == 'Mul':
            return left_result * right_result, [], False
        if kind == 'Div':
            if right_result == 0:
                return 0.0, [], True
            return left_result / right_result, [], False

        raise Exception(f'Invalid expression kind: {kind}')

    async def add_route(function_name: str, request_message: Message) -> Message:
        arguments = cast(dict[str, object], request_message.body[function_name])
        unavailable_response = _demo_unavailable_response()
        if unavailable_response is not None:
            return unavailable_response
        x = cast(float, arguments['x'])
        y = cast(float, arguments['y'])
        return Message({}, {'Ok_': {'result': x + y}})

    async def login_route(function_name: str, request_message: Message) -> Message:
        arguments = cast(dict[str, object], request_message.body[function_name])
        unavailable_response = _demo_unavailable_response()
        if unavailable_response is not None:
            return unavailable_response
        username = cast(str, arguments['username'])
        if username in session_tokens:
            return Message({}, {'ErrorUsernameAlreadyInUse': {}})
        token = secrets.token_urlsafe(16)
        session_tokens[username] = token
        usernames_by_token[token] = username
        return Message({}, {'Ok_': {'token': token}})

    async def logout_route(function_name: str, request_message: Message) -> Message:
        arguments = cast(dict[str, object], request_message.body[function_name])
        unavailable_response = _demo_unavailable_response()
        if unavailable_response is not None:
            return unavailable_response
        message = Message(request_message.headers, {function_name: arguments})
        username = get_username(message, require_session=True)
        requested_username = cast(str, arguments['username'])
        if username is None:
            return unauthenticated_response()
        if username != requested_username:
            return unauthorized_response('Session authentication must match the requested username.')
        token = session_tokens.pop(username, None)
        if token is not None:
            usernames_by_token.pop(token, None)
        user_variables.pop(username, None)
        user_evaluations.pop(username, None)
        return Message({}, {'Ok_': {}})

    async def save_variable_route(function_name: str, request_message: Message) -> Message:
        arguments = cast(dict[str, object], request_message.body[function_name])
        unavailable_response, username = await require_namespace(request_message)
        if unavailable_response is not None:
            return unavailable_response
        get_user_variables(cast(str, username))[cast(str, arguments['name'])] = cast(float, arguments['value'])
        return Message({}, {'Ok_': {}})

    async def save_variables_route(function_name: str, request_message: Message) -> Message:
        arguments = cast(dict[str, object], request_message.body[function_name])
        unavailable_response, username = await require_namespace(request_message)
        if unavailable_response is not None:
            return unavailable_response
        get_user_variables(cast(str, username)).update(cast(dict[str, float], arguments['variables']))
        return Message({}, {'Ok_': {}})

    async def get_variable_route(function_name: str, request_message: Message) -> Message:
        arguments = cast(dict[str, object], request_message.body[function_name])
        unavailable_response, username = await require_namespace(request_message)
        if unavailable_response is not None:
            return unavailable_response
        value = get_user_variables(cast(str, username)).get(cast(str, arguments['name']))
        if value is None:
            return Message({}, {'Ok_': {}})
        return Message({}, {'Ok_': {'variable!': {'name': cast(str, arguments['name']), 'value': value}}})

    async def get_variables_route(function_name: str, request_message: Message) -> Message:
        arguments = cast(dict[str, object], request_message.body[function_name])
        unavailable_response, username = await require_namespace(request_message)
        if unavailable_response is not None:
            return unavailable_response
        variables = [
            {'name': name, 'value': value}
            for name, value in sorted(get_user_variables(cast(str, username)).items())
        ]
        return Message({}, {'Ok_': {'variables': variables}})

    async def delete_variable_route(function_name: str, request_message: Message) -> Message:
        arguments = cast(dict[str, object], request_message.body[function_name])
        unavailable_response, username = await require_namespace(request_message)
        if unavailable_response is not None:
            return unavailable_response
        get_user_variables(cast(str, username)).pop(cast(str, arguments['name']), None)
        return Message({}, {'Ok_': {}})

    async def delete_variables_route(function_name: str, request_message: Message) -> Message:
        arguments = cast(dict[str, object], request_message.body[function_name])
        unavailable_response, username = await require_namespace(request_message)
        if unavailable_response is not None:
            return unavailable_response
        these_variables = get_user_variables(cast(str, username))
        for name in cast(list[str], arguments['names']):
            these_variables.pop(name, None)
        return Message({}, {'Ok_': {}})

    async def evaluate_route(function_name: str, request_message: Message) -> Message:
        arguments = cast(dict[str, object], request_message.body[function_name])
        unavailable_response, username = await require_namespace(request_message)
        if unavailable_response is not None:
            return unavailable_response
        expression = cast(dict[str, object], arguments['expression'])
        result, unknown_variables, divide_by_zero = evaluate_expression(
            expression, get_user_variables(cast(str, username)))
        if unknown_variables:
            record_evaluation(cast(str, username), expression, 0.0, False)
            return Message({}, {'ErrorUnknownVariables': {'unknownVariables': unknown_variables}})
        if divide_by_zero:
            record_evaluation(cast(str, username), expression, 0.0, False)
            return Message({}, {'ErrorCannotDivideByZero': {}})
        record_evaluation(cast(str, username), expression, result, True)
        return Message({}, {'Ok_': {
            'result': result,
            'saveResult': {'fn.saveVariable': {'name': 'result', 'value': result}},
        }})

    async def get_paper_tape_route(function_name: str, request_message: Message) -> Message:
        arguments = cast(dict[str, object], request_message.body[function_name])
        unavailable_response, username = await require_namespace(request_message)
        if unavailable_response is not None:
            return unavailable_response
        limit = cast(int | None, arguments.get('limit!'))
        evaluations = list(reversed(get_user_evaluations(cast(str, username))))
        if limit is not None:
            evaluations = evaluations[:limit]
        return Message({}, {'Ok_': {'tape': evaluations}})

    async def export_route(function_name: str, request_message: Message) -> Message:
        unavailable_response, username = await require_namespace(request_message)
        if unavailable_response is not None:
            return unavailable_response
        return Message({}, {'Ok_': {'blob': export_namespace(cast(str, username))}})

    async def import_route(function_name: str, request_message: Message) -> Message:
        unavailable_response, username = await require_namespace(request_message)
        if unavailable_response is not None:
            return unavailable_response
        blob = cast(bytes, cast(dict[str, object], request_message.body[function_name])['blob'])
        replace_namespace(cast(str, username), blob)
        return Message({}, {'Ok_': {}})

    function_routes = {
        'fn.add': add_route,
        'fn.login': login_route,
        'fn.logout': logout_route,
        'fn.saveVariable': save_variable_route,
        'fn.saveVariables': save_variables_route,
        'fn.getVariable': get_variable_route,
        'fn.getVariables': get_variables_route,
        'fn.deleteVariable': delete_variable_route,
        'fn.deleteVariables': delete_variables_route,
        'fn.evaluate': evaluate_route,
        'fn.getPaperTape': get_paper_tape_route,
        'fn.export': export_route,
        'fn.import': import_route,
    }


    telepact_json = load_calculator_telepact_json()

    telepact_schema = TelepactSchema.from_json(telepact_json)

    server_options = Server.Options()
    server_options.auth_required = True
    server_options.on_error = lambda e: print(e)
    function_router = FunctionRouter(function_routes)
    telepact_server = Server(telepact_schema, function_router, server_options)

    print('Telepact Server running at /api')

    async def api_endpoint(request: Request) -> Response:
        request_bytes = await request.body()
        print(f'Request: {request_bytes}')

        # Use the pre-configured telepact_server instance
        response_bytes, extracted_headers = await telepact_server.process(request_bytes)
        print(f'Response: {response_bytes}')

        media_type = 'application/octet-stream' if 'bin_' in extracted_headers else 'application/json'
        print(f'Media type: {media_type}')

        return Response(content=response_bytes, media_type=media_type)

    routes = [
        Route('/api', endpoint=api_endpoint, methods=['POST']),
    ]

    app = Starlette(routes=routes)

    uvicorn.run(app, host='0.0.0.0', port=port)


def get_api_from_http(http_url: str, include_internal: bool = False) -> str:
    url: str = http_url

    async def adapter(m: Message, s: Serializer) -> Message:
        try:
            request_bytes = s.serialize(m)
        except SerializationError as e:
            # Handle potential serialization errors (e.g., number overflow)
            if isinstance(e.__cause__, OverflowError):
                # Example: Return a specific Telepact error message
                # Adjust the error format based on your Telepact schema
                return Message({}, {"ErrorUnknown_": {"detail": "Input number too large for serialization"}})
            else:
                # Re-raise other serialization errors
                    return Message({}, {"ErrorUnknown_": {"detail": f"Serialization Error: {e}"}})


        try:
            # Use a timeout for the request
            response = requests.post(
                url,
                data=request_bytes,
                timeout=10,
                headers={
                    'Content-Type': 'application/json',
                    'Accept': 'application/json, application/octet-stream',
                },
            )
            response.raise_for_status() # Raise an exception for bad status codes (4xx or 5xx)
            response_bytes = response.content
            response_message = s.deserialize(response_bytes)
            return response_message
        except requests.exceptions.RequestException as e:
            print(f"Error connecting to upstream API: {e}")
                # Return an appropriate Telepact error message
                # Adjust the error format based on your Telepact schema
            return Message({}, {"ErrorUpstreamUnavailable_": {"url": url, "error": str(e)}})
        except Exception as e: # Catch potential deserialization errors too
                print(f"Error processing upstream response: {e}")
                return Message({}, {"ErrorUnknown_": {"detail": f"Upstream response processing error: {e}"}})


    options = Client.Options()
    telepact_client = Client(adapter, options)

    retries = 3
    response_message = None
    for attempt in range(retries):
        try:
            # Ensure the async function is run correctly
            request_body: dict[str, dict[str, object]] = {'fn.api_': {}}
            if include_internal:
                request_body = {'fn.api_': {'includeInternal!': True}}
            response_message = asyncio.run(telepact_client.request(Message({}, request_body)))
            if 'Ok_' in response_message.body or 'Error' in next(iter(response_message.body.keys()), ""): # Check for valid Telepact response structure
                break
            else:
                    print(f"Attempt {attempt+1}: Received unexpected response structure: {response_message.body}")
                    if attempt < retries - 1: time.sleep(1)

        except Exception as e:
            print(f"Attempt {attempt+1} failed: {e}")
            if attempt < retries - 1:
                time.sleep(1) # Wait before retrying
            else:
                # If all retries fail, raise a clearer error
                raise ConnectionError(f"Failed to connect to Telepact API at {url} after {retries} attempts.") from e

    # Check if we successfully got a response
    if response_message is None:
            raise Exception(f"Could not retrieve API schema from {url}. No valid response received.")

    if 'Ok_' not in response_message.body:
        # Provide more context on failure
        error_key = next(iter(response_message.body.keys()), "UnknownError")
        error_details = response_message.body.get(error_key, {})
        raise Exception(f"Failed to fetch API schema from {url}. Server responded with error: {error_key} - {error_details}")

    api = cast(dict[str, object], response_message.body['Ok_'])['api']
    api_json = json.dumps(api)

    return api_json


@click.command()
@click.option('--http-url', help='HTTP URL of a Telepact API', required=False, envvar='TELEPACT_HTTP_URL')
@click.option('--dir', help='Directory of Telepact schemas', required=False, envvar='TELEPACT_DIRECTORY')
@click.option('--port', default=8080, help='Port to run the mock server on', envvar='MOCK_SERVER_PORT')
@click.option('--path', default='/api', help='Path to expose the mock API (default: /api)', envvar='MOCK_SERVER_PATH')
@click.option('--generated-collection-length-min', default=0, help='Minimum length of generated collections', envvar='GENERATED_COLLECTION_LENGTH_MIN')
@click.option('--generated-collection-length-max', default=3, help='Maximum length of generated collections', envvar='GENERATED_COLLECTION_LENGTH_MAX')
@click.option('--disable-optional-field-generation', is_flag=True, default=False, help='Disable generation of optional fields (enabled by default)', envvar='DISABLE_OPTIONAL_FIELD_GENERATION')
@click.option('--disable-message-response-generation', is_flag=True, default=False, help='Disable generation of message responses (enabled by default)', envvar='DISABLE_MESSAGE_RESPONSE_GENERATION')
@click.option('--disable-random-optional-field-generation', is_flag=True, default=False, help='Disable randomization of optional field generation (enabled by default)', envvar='DISABLE_RANDOMIZE_OPTIONAL_FIELD_GENERATION')
def mock(
    http_url: str,
    dir: str,
    port: int,
    path: str,
    generated_collection_length_min: int,
    generated_collection_length_max: int,
    disable_optional_field_generation: bool,
    disable_message_response_generation: bool,
    disable_random_optional_field_generation: bool
) -> None:
    """
    Start a mock server for a Telepact API schema.
    """

    schema: MockTelepactSchema
    if http_url:
        api_json = get_api_from_http(http_url)
        schema = MockTelepactSchema.from_json(api_json)   
    elif dir:
        directory: str = dir
        schema = MockTelepactSchema.from_directory(directory)
    else:
        raise click.BadParameter('Either --http-url or --dir must be provided.')

    print('Telepact JSON loaded for mock server:')
    # print(json.dumps(schema.original, indent=4)) # Optionally print the schema

    mock_server_options = MockServer.Options()
    mock_server_options.generated_collection_length_min = generated_collection_length_min
    mock_server_options.generated_collection_length_max = generated_collection_length_max
    mock_server_options.enable_optional_field_generation = not disable_optional_field_generation
    mock_server_options.enable_message_response_generation = not disable_message_response_generation
    mock_server_options.randomize_optional_field_generation = not disable_random_optional_field_generation
    mock_server = MockServer(schema, mock_server_options)

    async def mock_api_endpoint(request: Request) -> Response:
        request_bytes = await request.body()
        response = await mock_server.process(request_bytes)
        response_bytes: bytes = response.bytes
        media_type = 'application/octet-stream' if 'bin_' in response.headers else 'application/json'
        return Response(content=response_bytes, media_type=media_type)

    async def mock_ws_endpoint(websocket: WebSocket) -> None:
        await websocket.accept()

        try:
            while True:
                try:
                    message = await websocket.receive()
                except WebSocketDisconnect:
                    break

                message_type = message.get('type')

                if message_type == 'websocket.receive':
                    request_bytes: bytes | None = None
                    payload_bytes = message.get('bytes')
                    payload_text = message.get('text')

                    if payload_bytes is not None:
                        request_bytes = payload_bytes
                    elif payload_text is not None:
                        request_bytes = payload_text.encode('utf-8')

                    if request_bytes is None:
                        continue

                    response = await mock_server.process(request_bytes)
                    response_bytes: bytes = response.bytes

                    if 'bin_' in response.headers:
                        await websocket.send_bytes(response_bytes)
                    else:
                        await websocket.send_text(response_bytes.decode('utf-8'))

                elif message_type == 'websocket.disconnect':
                    break
        finally:
            if websocket.application_state != WebSocketState.DISCONNECTED:
                try:
                    await websocket.close(code=1000)
                except RuntimeError:
                    pass

    normalized_path = path if path.startswith('/') else f'/{path}'

    routes = [
        Route(normalized_path, endpoint=mock_api_endpoint, methods=['POST']),
        WebSocketRoute(normalized_path, endpoint=mock_ws_endpoint),
    ]

    app = Starlette(routes=routes)

    print(f"Starting mock server on port {port} at path '{normalized_path}' (HTTP & WebSocket)...")
    uvicorn.run(app, host='0.0.0.0', port=port)


@click.command()
@click.option('--http-url', help='HTTP URL of a Telepact API', required=True)
@click.option('--output-dir', help='Directory of Telepact schemas', required=True)
@click.option('--include-internal', is_flag=True, default=False, help='Include internal Telepact definitions in the fetched schema')
def fetch(
    http_url: str,
    output_dir: str,
    include_internal: bool
) -> None:
    """
    Fetch a Telepact API schema to store locally.
    """

    api_json = get_api_from_http(http_url, include_internal=include_internal)
    schema = MockTelepactSchema.from_json(api_json)      

    filepath = os.path.join(output_dir, 'api.telepact.json')

    final_api_json = json.dumps(schema.full if include_internal else schema.original)

    os.makedirs(output_dir, exist_ok=True)
    with open(filepath, 'w') as file:
        file.write(final_api_json)

def trace_type(type_declaration: 'TTypeDeclaration') -> list[str]:
    from .telepact.internal.types.TArray import TArray
    from .telepact.internal.types.TObject import TObject
    from .telepact.internal.types.TStruct import TStruct
    from .telepact.internal.types.TUnion import TUnion

    this_all_types: list[str] = []

    if isinstance(type_declaration.type, TArray):
        these_keys2 = trace_type(type_declaration.type_parameters[0])
        this_all_types.extend(these_keys2)
    elif isinstance(type_declaration.type, TObject):
        these_keys2 = trace_type(type_declaration.type_parameters[0])
        this_all_types.extend(these_keys2)
    elif isinstance(type_declaration.type, TStruct):
        this_all_types.append(type_declaration.type.name)
        struct_fields = type_declaration.type.fields
        for struct_field_key, struct_field in struct_fields.items():
            more_types = trace_type(struct_field.type_declaration)
            this_all_types.extend(more_types)
    elif isinstance(type_declaration.type, TUnion):
        this_all_types.append(type_declaration.type.name)
        union_tags = type_declaration.type.tags
        for tag_key, tag_value in union_tags.items():
            struct_fields = tag_value.fields
            for struct_field_key, struct_field in struct_fields.items():
                more_types = trace_type(struct_field.type_declaration)
                this_all_types.extend(more_types)

    return this_all_types



from .telepact.internal.types.TStruct import TStruct
from .telepact.internal.types.TUnion import TUnion
from typing import cast, Dict, Any, Set

def _get_original_schema_name(schema_original: list, type_name: str, field_name: str) -> str:
    """Helper to get the original type name from the schema's raw data."""
    cleaned_type_name = '.'.join(type_name.split('.')[0:2])
    for entry in schema_original:
        if cleaned_type_name in entry:
            type_def = entry[cleaned_type_name] if '->' not in type_name else entry['->']
            if isinstance(type_def, dict):
                value = type_def.get(field_name)
                if isinstance(value, str):
                    return value
                if value is not None:
                    return str(value)
                return "unknown_type"
            elif isinstance(type_def, list):
                tag_key = type_name.split('.')[-1]
                if tag_key:
                    for tag_entry in type_def:
                        if tag_key in tag_entry:
                            value = tag_entry[tag_key].get(field_name)
                            if isinstance(value, str):
                                return value
                            if value is not None:
                                return str(value)
                            return "unknown_type"
    return "unknown_type"

def _compare_structs(
    errors: list,
    old_struct: TStruct,
    new_struct: TStruct,
    type_name: str,
    is_arg_type: bool,
    old_schema_original: list,
    new_schema_original: list
):
    """Compare two TStruct objects."""
    for old_name, old_field in old_struct.fields.items():
        if old_name not in new_struct.fields:
            errors.append(f"Field '{old_name}' has been removed from struct '{type_name}'")
            continue

        new_field = new_struct.fields[old_name]
        old_schema_name = _get_original_schema_name(old_schema_original, type_name, old_name)
        new_schema_name = _get_original_schema_name(new_schema_original, type_name, old_name)
        if old_schema_name != new_schema_name:
            errors.append(
                f"Field '{old_name}' in struct '{type_name}' has changed type from '{old_schema_name}' to '{new_schema_name}'"
            )

        elif is_arg_type and old_field.optional and not new_field.optional:
            errors.append(
                f"Field '{old_name}' in struct '{type_name}' has changed from optional to required on argument path"
            )

    if is_arg_type:
        for new_name, new_field in new_struct.fields.items():
            if new_name not in old_struct.fields and not new_field.optional:
                errors.append(
                    f"New required field '{new_name}' has been added to struct '{type_name}' on argument path"
                )

def _compare_unions(
    errors: list,
    old_union: TUnion,
    new_union: TUnion,
    type_name: str,
    is_arg_type: bool,
    is_result_type: bool,
    old_schema_original: list,
    new_schema_original: list
):
    """Compare two TUnion objects."""
    for tag_key, old_tag in old_union.tags.items():
        if tag_key not in new_union.tags:
            errors.append(f"Tag '{tag_key}' has been removed from union '{type_name}'")
            continue

        _compare_structs(
            errors,
            old_tag,
            new_union.tags[tag_key],
            f"{type_name}.{tag_key}",
            is_arg_type,
            old_schema_original,
            new_schema_original
        )

    if is_result_type:
        for tag_key in new_union.tags.keys() - old_union.tags.keys():
            errors.append(f"New tag '{tag_key}' has been added to union '{type_name}' on result path")

def _get_types_by_path(telepact_schema: Any) -> tuple[Set[str], Set[str]]:
    """Determine which types are on the argument or result paths."""
    arg_types = set()
    result_types = set()

    for k, v in telepact_schema.parsed.items():
        if k.endswith('.->'):
            res = cast(TUnion, v)
            ok_struct = res.tags.get('Ok_')
            if ok_struct:
                for field in ok_struct.fields.values():
                    result_types.update(trace_type(field.type_declaration))

        elif k.startswith('fn'):
            fn = cast(TUnion, v)
            arg = fn.tags.get(k)
            if arg:
                for field in arg.fields.values():
                    arg_types.update(trace_type(field.type_declaration))

    return arg_types, result_types

@click.command()
@click.option('--new-schema-dir', help='New telepact schema directory', required=True)
@click.option('--old-schema-dir', help='Old telepact schema directory', required=True)
def compare(new_schema_dir: str, old_schema_dir: str) -> None:
    """
    Compare two Telepact API schemas for backwards compatibility.
    """
    from .telepact.internal.types.TType import TType
    from .telepact.TelepactSchema import TelepactSchema

    new_telepact_schema = TelepactSchema.from_directory(new_schema_dir)
    old_telepact_schema = TelepactSchema.from_directory(old_schema_dir)

    arg_types, result_types = _get_types_by_path(old_telepact_schema)
    errors = []

    for old_type_name, old_type in old_telepact_schema.parsed.items():
        new_type = new_telepact_schema.parsed.get(old_type_name)

        if not new_type:
            if old_type_name.endswith('.->'):
                continue
            
            errors.append(f"Type '{old_type_name}' has been removed")
            continue

        is_arg_type = old_type_name in arg_types or (old_type_name.startswith('fn') and not old_type_name.endswith('.->'))
        is_result_type = old_type_name in result_types

        # Handle function types which are unions with a single tag
        if old_type_name.startswith('fn') and not old_type_name.endswith('.->'):
            old_type = cast(TUnion, old_type).tags[old_type_name]
            new_type = cast(TUnion, new_type).tags[old_type_name]

        if isinstance(old_type, TStruct):
            _compare_structs(
                errors,
                cast(TStruct, old_type),
                cast(TStruct, new_type),
                old_type_name,
                is_arg_type,
                old_telepact_schema.original,
                new_telepact_schema.original
            )
        elif isinstance(old_type, TUnion):
            _compare_unions(
                errors,
                cast(TUnion, old_type),
                cast(TUnion, new_type),
                old_type_name,
                is_arg_type,
                is_result_type,
                old_telepact_schema.original,
                new_telepact_schema.original
            )
        # Note: No comparison for TType, as it's a base class

    if errors:
        print("Backwards incompatible change(s) found:")
        for error in errors:
            print(f" - {error}")
        exit(1)


main.add_command(codegen)
main.add_command(demo_server)
main.add_command(mock)
main.add_command(fetch)
main.add_command(compare)

if __name__ == "__main__":
    main()
