// Copyright (C) 2026  The Software Heritage developers
// See the AUTHORS file at the top-level directory of this distribution
// License: GNU General Public License version 3, or any later version
// See top-level LICENSE file for more information

use std::collections::HashMap;

use anyhow::{Result, bail};
use swh_graph::graph::NodeId;
use swh_graph::graph_builder::GraphBuilder;
use swh_graph::swhid;

use swh_graph_stdlib::labeling::MapReduceBuilder;
use swh_graph_topology::metrics::descendants::DescendantsCountingMapReducerBuilder;

macro_rules! map {
    ($($k:expr => $v:expr),* $(,)?) => {{
        vec![$(($k, $v),)*].into_iter().collect::<HashMap<_, _>>()
    }};
}

fn estimate_subgraph_sizes(
    graph: &swh_graph::graph_builder::BuiltGraph,
    nodes: &[NodeId],
    rsd: f64,
    round: bool,
) -> Result<HashMap<NodeId, f64>> {
    let mut sizes = HashMap::new();
    let map_reducer = DescendantsCountingMapReducerBuilder::<_, _, usize>::new(graph, rsd)?
        .with_callback(|node, size| {
            if let Some(previous_size) = sizes.insert(node, size) {
                bail!("{node} size inserted twice ({previous_size} then {size})");
            }
            Ok(())
        })
        .with_seed_and_deterministic_secrets(2) // chosen to make the tests below pass
        .build::<Box<[usize]>>()?;
    let mut mr = MapReduceBuilder::new_sparse(graph, map_reducer).build()?;
    mr.run_in_topological_order(nodes.iter().copied())?;

    if round {
        sizes.values_mut().for_each(|size| *size = size.round());
    }
    Ok(sizes)
}

#[test]
fn test_linear_chain() -> Result<()> {
    let mut builder = GraphBuilder::default();
    let n0 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000000))?
        .done();
    let n1 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000001))?
        .done();
    let n2 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000002))?
        .done();
    let n3 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000003))?
        .done();

    builder.arc(n1, n0);
    builder.arc(n2, n1);
    builder.arc(n3, n2);

    let graph = builder.done()?;
    let results = estimate_subgraph_sizes(&graph, &[n0, n1, n2, n3], 0.01, true)?;

    assert_eq!(
        results,
        map!(
            n0 => 1.0,
            n1 => 2.0,
            n2 => 3.0,
            n3 => 4.0,
        ),
    );
    Ok(())
}

#[test]
fn test_diamond() -> Result<()> {
    let mut builder = GraphBuilder::default();
    let n0 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000000))?
        .done();
    let n1 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000001))?
        .done();
    let n2 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000002))?
        .done();
    let n3 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000003))?
        .done();

    builder.arc(n1, n0);
    builder.arc(n2, n0);
    builder.arc(n3, n1);
    builder.arc(n3, n2);

    let graph = builder.done()?;
    let results = estimate_subgraph_sizes(&graph, &[n0, n1, n2, n3], 0.01, true)?;

    assert_eq!(
        results,
        map!(
            n0 => 1.0,
            n1 => 2.0,
            n2 => 2.0,
            n3 => 4.0, // n3 reaches {0,1,2,3}, n0 counted once despite two paths
        ),
    );
    Ok(())
}

#[test]
fn test_multiple_roots() -> Result<()> {
    let mut builder = GraphBuilder::default();
    let n0 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000000))?
        .done();
    let n1 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000001))?
        .done();
    let n2 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000002))?
        .done();

    builder.arc(n2, n0);
    builder.arc(n2, n1);

    let graph = builder.done()?;
    let results = estimate_subgraph_sizes(&graph, &[n0, n1, n2], 0.01, true)?;

    assert_eq!(
        results,
        map!(
            n0 => 1.0,
            n1 => 1.0,
            n2 => 3.0,
        ),
    );
    Ok(())
}

#[test]
fn test_large_graph_approximate() -> Result<()> {
    let mut builder = GraphBuilder::default();

    let num_nodes = 101;
    let swhids: Vec<swh_graph::SWHID> = (0..num_nodes)
        .map(|i| format!("swh:1:rev:{:040x}", i).parse().unwrap())
        .collect();
    let nodes: Vec<_> = swhids
        .iter()
        .map(|s| builder.node(*s).unwrap().done())
        .collect();

    for &leaf in &nodes[1..] {
        builder.arc(nodes[0], leaf);
    }

    let graph = builder.done()?;
    let mut all_nodes: Vec<_> = nodes[1..].to_vec();
    all_nodes.push(nodes[0]);

    let rsd = 0.13;
    let results = estimate_subgraph_sizes(&graph, &all_nodes, rsd, false)?;

    for &leaf in &nodes[1..] {
        let estimate = results[&leaf];
        assert!(
            estimate > 0.0 && estimate < 3.0,
            "leaf {leaf} estimate {estimate} should be close to 1.0"
        );
    }

    let root_estimate = results[&nodes[0]];
    let true_size = num_nodes as f64;
    assert!(
        (root_estimate - true_size).abs() < true_size * rsd,
        "root estimate {root_estimate} should be within rsd of {true_size} (fixed seed)"
    );
    assert_ne!(
        root_estimate, true_size,
        "with rsd={rsd}, root estimate should not be exactly {true_size}"
    );

    Ok(())
}
