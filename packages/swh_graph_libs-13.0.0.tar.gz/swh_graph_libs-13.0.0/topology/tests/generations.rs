// Copyright (C) 2026  The Software Heritage developers
// See the AUTHORS file at the top-level directory of this distribution
// License: GNU General Public License version 3, or any later version
// See top-level LICENSE file for more information

use std::borrow::Borrow;

use anyhow::Result;

use swh_graph::graph::NodeId;
use swh_graph::graph_builder::GraphBuilder;
use swh_graph::{NodeConstraint, swhid};

use swh_graph_topology::generations::*;

fn write_and_read(
    generations: &[impl IntoIterator<Item: Borrow<NodeId>> + Clone],
    direction: Direction,
    node_types: NodeConstraint,
) -> Result<GenerationsReader> {
    let dir = tempfile::tempdir()?;
    let path = dir.path().join("generations.bitstream");
    let mut writer = GenerationsWriter::new(&path, direction, node_types)?;
    for g in generations {
        writer.push_sorted_generation(g.clone())?;
    }
    writer.close()?;
    let reader = GenerationsReader::new(&path)?;
    drop(dir);

    assert_eq!(reader.properties().direction(), direction);
    assert_eq!(reader.properties().node_types(), node_types);
    Ok(reader)
}

#[test]
fn test_write_read_round_trip() -> Result<()> {
    let reader = write_and_read(
        &[vec![0, 2, 5], vec![1, 3], vec![4]],
        Direction::Forward,
        NodeConstraint::default(),
    )?;

    let generations: Vec<Vec<NodeId>> = reader.iter_generations()?.map(|g| g.collect()).collect();
    assert_eq!(generations, vec![vec![0, 2, 5], vec![1, 3], vec![4]]);

    let nodes: Vec<(u64, NodeId)> = reader.iter_nodes()?.collect();
    assert_eq!(nodes, vec![(0, 0), (0, 2), (0, 5), (1, 1), (1, 3), (2, 4)]);

    Ok(())
}

#[test]
fn test_sort_and_push() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let path = dir.path().join("generations.bitstream");
    let mut writer = GenerationsWriter::new(&path, Direction::Forward, NodeConstraint::default())?;
    writer.sort_and_push_generation(&mut [5, 1, 3])?;
    writer.close()?;

    let reader = GenerationsReader::new(&path)?;
    let result: Vec<Vec<NodeId>> = reader.iter_generations()?.map(|g| g.collect()).collect();
    assert_eq!(result, vec![vec![1, 3, 5]]);

    Ok(())
}

/// removes node
#[test]
fn test_type_aware_filter() -> Result<()> {
    let mut builder = GraphBuilder::default();
    let ori = builder
        .node(swhid!(swh:1:ori:0000000000000000000000000000000000000000))?
        .done();
    let snp = builder
        .node(swhid!(swh:1:snp:0000000000000000000000000000000000000001))?
        .done();
    let rel = builder
        .node(swhid!(swh:1:rel:0000000000000000000000000000000000000002))?
        .done();
    let rev1 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000003))?
        .done();
    let rev2 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000004))?
        .done();
    let dir1 = builder
        .node(swhid!(swh:1:dir:0000000000000000000000000000000000000005))?
        .done();
    let dir2 = builder
        .node(swhid!(swh:1:dir:0000000000000000000000000000000000000006))?
        .done();
    builder.arc(ori, snp);
    builder.arc(snp, rel);
    builder.arc(rel, rev1);
    builder.arc(rev1, rev2);
    builder.arc(rev1, dir1);
    builder.arc(rev2, dir2);
    let graph = builder.done()?;

    let all_types: NodeConstraint = "ori,snp,rel,rev,dir".parse().unwrap();
    let mut nodes = vec![
        vec![ori],
        vec![snp],
        vec![rel],
        vec![rev1],
        vec![rev2, dir1],
        vec![dir2],
    ];
    nodes.sort();
    let reader = write_and_read(&nodes, Direction::Forward, all_types)?;

    let subset: NodeConstraint = "ori,snp,rel,rev".parse().unwrap();
    let typed_reader = TypeAwareGenerationsReader::new(reader, &graph, subset)?;

    let result: Vec<Vec<NodeId>> = typed_reader
        .iter_generations()?
        .map(|g| g.collect())
        .collect();
    // TODO: avoid empty generations
    assert_eq!(
        result,
        vec![
            vec![ori],
            vec![snp],
            vec![rel],
            vec![rev1],
            vec![rev2],
            vec![]
        ]
    );

    Ok(())
}

/// adds contents at the end
#[test]
fn test_type_aware_content_forward() -> Result<()> {
    let mut builder = GraphBuilder::default();
    let rev = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000000))?
        .done();
    let dir = builder
        .node(swhid!(swh:1:dir:0000000000000000000000000000000000000001))?
        .done();
    let cnt1 = builder
        .node(swhid!(swh:1:cnt:0000000000000000000000000000000000000002))?
        .done();
    let cnt2 = builder
        .node(swhid!(swh:1:cnt:0000000000000000000000000000000000000003))?
        .done();
    builder.arc(rev, dir);
    builder.arc(dir, cnt1);
    builder.arc(dir, cnt2);
    let graph = builder.done()?;

    let written_types: NodeConstraint = "rev,dir".parse().unwrap();
    let nodes = vec![vec![rev], vec![dir]];
    let reader = write_and_read(&nodes, Direction::Forward, written_types)?;

    let want: NodeConstraint = "rev,dir,cnt".parse().unwrap();
    let typed_reader = TypeAwareGenerationsReader::new(reader, &graph, want)?;

    let result: Vec<Vec<NodeId>> = typed_reader
        .iter_generations()?
        .map(|g| g.collect())
        .collect();

    assert_eq!(result, vec![vec![rev], vec![dir], vec![cnt1, cnt2]]);

    Ok(())
}

/// adds contents at the beginning
#[test]
fn test_type_aware_content_backward() -> Result<()> {
    let mut builder = GraphBuilder::default();
    let rev = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000000))?
        .done();
    let dir = builder
        .node(swhid!(swh:1:dir:0000000000000000000000000000000000000001))?
        .done();
    let cnt = builder
        .node(swhid!(swh:1:cnt:0000000000000000000000000000000000000002))?
        .done();
    builder.arc(rev, dir);
    builder.arc(dir, cnt);
    let graph = builder.done()?;

    let written_types: NodeConstraint = "rev,dir".parse().unwrap();
    let nodes = &[vec![dir], vec![rev]];
    let reader = write_and_read(nodes, Direction::Backward, written_types)?;

    let want: NodeConstraint = "rev,dir,cnt".parse().unwrap();
    let typed_reader = TypeAwareGenerationsReader::new(reader, &graph, want)?;

    let result: Vec<Vec<NodeId>> = typed_reader
        .iter_generations()?
        .map(|g| g.collect())
        .collect();

    assert_eq!(result, vec![vec![cnt], vec![dir], vec![rev]]);

    Ok(())
}

#[test]
fn test_type_aware_missing_type_error() -> Result<()> {
    let mut builder = GraphBuilder::default();
    let ori = builder
        .node(swhid!(swh:1:ori:0000000000000000000000000000000000000000))?
        .done();
    let snp = builder
        .node(swhid!(swh:1:snp:0000000000000000000000000000000000000001))?
        .done();
    builder.arc(ori, snp);
    let graph = builder.done()?;

    let written_types: NodeConstraint = "ori,snp,rel,rev".parse().unwrap();
    let reader = write_and_read(&[&[ori]], Direction::Forward, written_types)?;

    // missing dir
    let want: NodeConstraint = "ori,snp,rel,rev,dir".parse().unwrap();
    let result = TypeAwareGenerationsReader::new(reader, &graph, want);
    assert!(result.is_err());

    Ok(())
}
