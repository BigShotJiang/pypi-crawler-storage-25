// Copyright (C) 2026  The Software Heritage developers
// See the AUTHORS file at the top-level directory of this distribution
// License: GNU General Public License version 3, or any later version
// See top-level LICENSE file for more information

use std::collections::HashMap;

use anyhow::Result;
use swh_graph::graph::NodeId;
use swh_graph::graph_builder::GraphBuilder;
use swh_graph::swhid;

use swh_graph_stdlib::labeling::{Labels, MapReduceBuilder, SparseLabels};
use swh_graph_topology::metrics::paths::{PathCount, PathCountingMapReducer};

macro_rules! map {
    ($($k:expr => $v:expr),* $(,)?) => {{
        vec![$(($k, $v),)*].into_iter().collect::<HashMap<_, _>>()
    }};
}

fn pc(paths_from_roots: f64, all_paths: f64) -> PathCount {
    PathCount {
        paths_from_roots,
        all_paths,
    }
}

fn count_paths(
    graph: &swh_graph::graph_builder::BuiltGraph,
    nodes: &[NodeId],
) -> Result<HashMap<NodeId, PathCount>> {
    let mut mr = MapReduceBuilder::new_sparse(graph, PathCountingMapReducer::new(graph))
        .keep_labels(true)
        .cheap_clones(true)
        .build()?;
    mr.run_in_topological_order(nodes.iter().copied())?;
    let labels: &SparseLabels<_> = mr.labels()?;
    Ok(nodes
        .iter()
        .map(|&n| (n, labels.get(n).copied().unwrap_or_default()))
        .collect())
}

#[test]
fn test_linear_chain() -> Result<()> {
    let mut builder = GraphBuilder::default();
    let n0 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000000))?
        .done();
    let n1 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000001))?
        .done();
    let n2 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000002))?
        .done();
    let n3 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000003))?
        .done();

    builder.arc(n1, n0);
    builder.arc(n2, n1);
    builder.arc(n3, n2);

    let graph = builder.done()?;
    let results = count_paths(&graph, &[n0, n1, n2, n3])?;

    assert_eq!(
        results,
        map!(
            n0 => pc(1., 1.),
            n1 => pc(1., 2.),
            n2 => pc(1., 3.),
            n3 => pc(1., 4.),
        ),
    );
    Ok(())
}

#[test]
fn test_diamond() -> Result<()> {
    let mut builder = GraphBuilder::default();
    let n0 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000000))?
        .done();
    let n1 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000001))?
        .done();
    let n2 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000002))?
        .done();
    let n3 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000003))?
        .done();

    builder.arc(n1, n0);
    builder.arc(n2, n0);
    builder.arc(n3, n1);
    builder.arc(n3, n2);

    let graph = builder.done()?;
    let results = count_paths(&graph, &[n0, n1, n2, n3])?;

    assert_eq!(
        results,
        map!(
            n0 => pc(1., 1.),
            n1 => pc(1., 2.),
            n2 => pc(1., 2.),
            n3 => pc(2., 5.), // itself + 2 + 2
        ),
    );
    Ok(())
}

#[test]
fn test_multiple_roots() -> Result<()> {
    let mut builder = GraphBuilder::default();
    let n0 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000000))?
        .done();
    let n1 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000001))?
        .done();
    let n2 = builder
        .node(swhid!(swh:1:rev:0000000000000000000000000000000000000002))?
        .done();

    builder.arc(n2, n0);
    builder.arc(n2, n1);

    let graph = builder.done()?;
    let results = count_paths(&graph, &[n0, n1, n2])?;

    assert_eq!(
        results,
        map!(
            n0 => pc(1., 1.),
            n1 => pc(1., 1.),
            n2 => pc(2., 3.),
        ),
    );
    Ok(())
}
