// Copyright (C) 2026  The Software Heritage developers
// See the AUTHORS file at the top-level directory of this distribution
// License: GNU General Public License version 3, or any later version
// See top-level LICENSE file for more information

//! Metrics that consider all nodes reachable (but not co-reachable) from a node; ie. its "subtree"
//! but generalized to DAGs.

use std::borrow::{Borrow, BorrowMut};
use std::convert::Infallible;
use std::marker::PhantomData;

use anyhow::{Context, Result, ensure};
use card_est_array::impls::{HyperLogLog, HyperLogLog8, HyperLogLog8Builder, HyperLogLogBuilder};
use card_est_array::traits::{MergeEstimationLogic, SliceEstimationLogic, Word};
use num_primitive::PrimitiveNumberAs;
use rapidhash::fast::SeedableState;
use swh_graph::graph::{NodeId, SwhGraph};
use swh_graph_stdlib::labeling::{BoxLabel, MapReducer, SliceLabel};

/// Ability to zero-initialize array-like structures
pub trait HllBackend: ToOwned {
    fn new_backend(len: usize) -> <Self as ToOwned>::Owned;
}

impl<W: Default> HllBackend for Box<[W]>
where
    Self: Clone,
{
    fn new_backend(len: usize) -> Self {
        (0..len).map(|_| W::default()).collect()
    }
}

impl<const N: usize, W: Default + Copy> HllBackend for [W; N] {
    fn new_backend(len: usize) -> Self {
        assert!(len == N, "Incompatible length");
        [W::default(); N]
    }
}

impl<W: Default + bytemuck::AnyBitPattern> HllBackend for SliceLabel<W> {
    fn new_backend(len: usize) -> BoxLabel<W> {
        BoxLabel((0..len).map(|_| W::default()).collect())
    }
}

/// Workaround for Rust not implementing [`Default`] for arrays longer than 32.
#[derive(Clone, Debug)]
pub struct DefaultArray<W: Copy, const N: usize>(pub [W; N]);

impl<W: Default + Copy, const N: usize> Default for DefaultArray<W, N> {
    #[inline(always)]
    fn default() -> Self {
        DefaultArray([W::default(); N])
    }
}

impl<W: Copy, const N: usize> AsRef<[W]> for DefaultArray<W, N> {
    #[inline(always)]
    fn as_ref(&self) -> &[W] {
        &self.0
    }
}

impl<W: Copy, const N: usize> AsMut<[W]> for DefaultArray<W, N> {
    #[inline(always)]
    fn as_mut(&mut self) -> &mut [W] {
        &mut self.0
    }
}

impl<W: Copy, const N: usize> HllBackend for DefaultArray<W, N>
where
    [W; N]: HllBackend + ToOwned<Owned = [W; N]>,
{
    #[inline(always)]
    fn new_backend(len: usize) -> Self {
        Self(<[W; N]>::new_backend(len))
    }
}

/// Generalization of `[W; N]` and `Box<[W]>`
pub trait EstimatorBackend<W>:
    AsRef<[W]> + AsMut<[W]> + ToOwned<Owned: BorrowMut<Self>> + HllBackend + 'static
{
}
impl<
    W: Word,
    B: AsRef<[W]> + AsMut<[W]> + ToOwned<Owned: BorrowMut<B>> + HllBackend + ?Sized + 'static,
> EstimatorBackend<W> for B
{
}

/// Generalization of [`HyperLogLog`] and [`HyperLogLog8`]
pub trait Estimator<W>:
    SliceEstimationLogic<W, Item = NodeId, Backend = [W]> + MergeEstimationLogic + 'static
{
    type Builder: EstimatorBuilder<W, Built = Self>;
}
impl<W: Word> Estimator<W> for Hll<W>
where
    u32: PrimitiveNumberAs<W>,
{
    type Builder = HllBuilder<W>;
}
impl Estimator<u8> for Hll8 {
    type Builder = Hll8Builder;
}

pub trait EstimatorBuilder<W>: Clone {
    type Built: Estimator<W>;

    fn build_hasher(self, build_hasher: SeedableState<'static>) -> Self;
    fn build(self) -> Result<Self::Built>;
}

impl<W: Word> EstimatorBuilder<W> for HllBuilder<W>
where
    u32: PrimitiveNumberAs<W>,
{
    type Built = Hll<W>;

    fn build_hasher(self, build_hasher: SeedableState<'static>) -> Self {
        self.build_hasher(build_hasher)
    }
    fn build(self) -> Result<Self::Built> {
        self.build().context("Could not build HyperLogLog")
    }
}
impl EstimatorBuilder<u8> for Hll8Builder {
    type Built = Hll8;

    fn build_hasher(self, build_hasher: SeedableState<'static>) -> Self {
        self.build_hasher(build_hasher)
    }
    fn build(self) -> Result<Self::Built> {
        Ok(self.build())
    }
}

type Hll<W> = HyperLogLog<NodeId, SeedableState<'static>, W>;
type Hll8 = HyperLogLog8<NodeId, SeedableState<'static>>;
type HllBuilder<W> = HyperLogLogBuilder<SeedableState<'static>, W>;
type Hll8Builder = HyperLogLog8Builder<SeedableState<'static>>;

/// `FnMut(NodeId, f64) -> Result<(), ERR>`
pub trait Callback<ERR>: FnMut(NodeId, f64) -> Result<(), ERR> {}
impl<ERR, CB: FnMut(NodeId, f64) -> Result<(), ERR>> Callback<ERR> for CB {}

fn no_callback(_node: NodeId, _count: f64) -> Result<(), Infallible> {
    Ok(())
}

/// Builder for [`DescendantsCountingMapReducer`].
pub struct DescendantsCountingMapReducerBuilder<
    ERR,
    CB: Callback<ERR>,
    W: Word = usize,
    EST: Estimator<W> = Hll<W>,
> where
    u32: PrimitiveNumberAs<W>,
{
    estimator_builder: <EST as Estimator<W>>::Builder,
    callback: CB,
    marker: PhantomData<(ERR, W)>,
}

impl<W: Word>
    DescendantsCountingMapReducerBuilder<
        Infallible,
        fn(NodeId, f64) -> Result<(), Infallible>,
        W,
        Hll<W>,
    >
where
    u32: PrimitiveNumberAs<W>,
{
    pub fn new<G: SwhGraph>(graph: G, rsd: f64) -> Result<Self> {
        let estimator_builder = HyperLogLogBuilder::new(graph.num_nodes())
            .build_hasher(SeedableState::random())
            .word_type::<W>()
            .rsd(rsd);
        estimator_builder.clone().build::<NodeId>()?; // return errors early

        Ok(Self {
            estimator_builder,
            callback: no_callback,
            marker: PhantomData,
        })
    }
}

impl
    DescendantsCountingMapReducerBuilder<
        Infallible,
        fn(NodeId, f64) -> Result<(), Infallible>,
        u8,
        Hll8,
    >
{
    pub fn new(rsd: f64) -> Result<Self> {
        let estimator_builder = HyperLogLog8Builder::new()
            .build_hasher(SeedableState::random())
            .rsd(rsd);

        Ok(Self {
            estimator_builder,
            callback: no_callback,
            marker: PhantomData,
        })
    }
}

// copied from https://github.com/hoxxep/rapidhash/blob/b49ea242c1aa907f2827654f240081c4dd1d2f9a/rapidhash/src/inner/seeding.rs
const DEFAULT_SECRETS: [u64; 7] = [
    0x2d358dccaa6c78a5,
    0x8bb84b93962eacc9,
    0x4b33a62ed433d4a3,
    0x4d5a2da51de1aa47,
    0xa0761d6478bd642f,
    0xe7037ed1a0b428db,
    0x90ed1765281c388c,
];

impl<ERR, CB: Callback<ERR>, W: Word, EST: Estimator<W>>
    DescendantsCountingMapReducerBuilder<ERR, CB, W, EST>
where
    u32: PrimitiveNumberAs<W>,
{
    pub fn with_callback<E2, CB2: Callback<E2>>(
        self,
        callback: CB2,
    ) -> DescendantsCountingMapReducerBuilder<E2, CB2, W, EST> {
        let Self {
            estimator_builder,
            callback: _,
            marker: _,
        } = self;
        DescendantsCountingMapReducerBuilder {
            estimator_builder,
            callback,
            marker: PhantomData,
        }
    }

    pub fn with_seed_and_deterministic_secrets(mut self, seed: u64) -> Self {
        self.estimator_builder = self
            .estimator_builder
            .build_hasher(SeedableState::custom(seed, &DEFAULT_SECRETS));
        self
    }

    /// Returns a [`DescendantsCountingMapReducer`].
    ///
    /// The type parameter `B` must either `[W; N]` where `N` is equal to `self.backend_len()`
    /// (or greater, but that's a waste of memory) or `Box<[W]>`.
    pub fn build<B: EstimatorBackend<W> + ?Sized>(
        self,
    ) -> Result<DescendantsCountingMapReducer<ERR, CB, W, B, EST>> {
        ensure!(
            B::new_backend(self.backend_len()).borrow().as_ref().len() >= self.backend_len(),
            "Called DescendantsCountingMapReducer::build<B>(), with B={}, but its length needs to be >= {}",
            std::any::type_name::<B>(),
            self.backend_len()
        );
        let Self {
            estimator_builder,
            callback,
            marker: _,
        } = self;
        let estimator = estimator_builder
            .build()
            .context("Failed to build estimator, but it worked before")?;
        Ok(DescendantsCountingMapReducer {
            estimator_helper: estimator.new_helper(),
            estimator,
            callback,
            marker: PhantomData,
        })
    }

    pub fn backend_len(&self) -> usize {
        self.estimator_builder
            .clone()
            .build()
            .expect("Failed to build estimator, but it worked before")
            .backend_len()
    }
}

pub struct DescendantsCountingMapReducer<
    ERR,
    CB: Callback<ERR>,
    W: Word,
    B: EstimatorBackend<W> + ?Sized,
    EST: Estimator<W> = Hll<W>,
> where
    u32: PrimitiveNumberAs<W>,
{
    estimator: EST,
    estimator_helper: <EST as MergeEstimationLogic>::Helper,
    callback: CB,
    marker: PhantomData<(ERR, Box<B>, W)>,
}

impl<
    ERR,
    CB: Callback<ERR> + Clone,
    W: Word + Clone,
    B: EstimatorBackend<W> + ?Sized,
    EST: Estimator<W> + Clone,
> Clone for DescendantsCountingMapReducer<ERR, CB, W, B, EST>
where
    u32: PrimitiveNumberAs<W>,
{
    fn clone(&self) -> Self {
        Self {
            estimator: self.estimator.clone(),
            estimator_helper: self.estimator.new_helper(),
            callback: self.callback.clone(),
            marker: PhantomData,
        }
    }
}

impl<ERR, CB: Callback<ERR>, W: Word, B: EstimatorBackend<W> + ?Sized, EST: Estimator<W>>
    DescendantsCountingMapReducer<ERR, CB, W, B, EST>
where
    u32: PrimitiveNumberAs<W>,
{
    #[inline(always)]
    pub fn backend_len(&self) -> usize {
        self.estimator.backend_len()
    }

    #[inline(always)]
    pub fn estimate(&self, label: &B) -> f64 {
        self.estimator.estimate(label.as_ref())
    }
}

impl<ERR, CB: Callback<ERR>, W: Word, B: EstimatorBackend<W> + ?Sized, EST: Estimator<W>> MapReducer
    for DescendantsCountingMapReducer<ERR, CB, W, B, EST>
where
    u32: PrimitiveNumberAs<W>,
{
    type Label = B;
    type Error = ERR;

    fn map(&mut self, node: NodeId) -> Result<Option<<B as ToOwned>::Owned>, Self::Error> {
        let mut data = B::new_backend(self.estimator.backend_len());
        self.estimator.add(data.borrow_mut().as_mut(), &node);
        Ok(Some(data))
    }

    fn reduce<'a, I: Iterator<Item = &'a B>>(
        &mut self,
        first_label: <B as ToOwned>::Owned,
        other_labels: I,
    ) -> Result<Option<<B as ToOwned>::Owned>, Self::Error>
    where
        B: 'a,
    {
        let mut merged = first_label;
        for label in other_labels {
            self.estimator.merge_with_helper(
                merged.borrow_mut().as_mut(),
                label.as_ref(),
                &mut self.estimator_helper,
            )
        }
        Ok(Some(merged))
    }

    fn map_reduce(
        &mut self,
        node: NodeId,
        mut successors_label: <B as ToOwned>::Owned,
    ) -> Result<Option<<B as ToOwned>::Owned>, Self::Error> {
        // equivalent to self.reduce(self.map(node), [successors_label]) but faster because this
        // avoids a merge.
        self.estimator
            .add(successors_label.borrow_mut().as_mut(), &node);
        Ok(Some(successors_label))
    }

    fn on_node_traversed(&mut self, node: NodeId, label: Option<&B>) -> Result<(), Self::Error> {
        let label = label.expect("DescendantsCountingMapReducer does not have None labels");
        (self.callback)(node, self.estimator.estimate(label.as_ref()))
    }
}
