// Copyright (C) 2026  The Software Heritage developers
// See the AUTHORS file at the top-level directory of this distribution
// License: GNU General Public License version 3, or any later version
// See top-level LICENSE file for more information

//! Size of subgraph of a node, disk size of a directory, etc.

pub mod descendants;
pub mod paths;
