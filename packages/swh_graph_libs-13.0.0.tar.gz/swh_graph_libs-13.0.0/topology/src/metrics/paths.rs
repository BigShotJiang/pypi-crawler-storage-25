// Copyright (C) 2026  The Software Heritage developers
// See the AUTHORS file at the top-level directory of this distribution
// License: GNU General Public License version 3, or any later version
// See top-level LICENSE file for more information

//! Metrics that consider the "expanded size" of a node's descendants as a tree

use swh_graph::graph::{NodeId, SwhForwardGraph};
use swh_graph_stdlib::labeling::MapReducer;

/// Path counts for a node, including the trivial self-path (zero-length path from a node
/// to itself).
#[derive(Debug, Clone, Copy, Default, PartialEq, derive_more::Add, derive_more::Sum)]
pub struct PathCount {
    /// Number of paths from a given node to any root (ie. nodes without successors)
    pub paths_from_roots: f64,
    /// Number of paths from a given node to any other node (including itself)
    pub all_paths: f64,
}

/// Implementation of [`MapReducer`] that counts paths (including self-paths).
pub struct PathCountingMapReducer<G: SwhForwardGraph> {
    graph: G,
}

impl<G: SwhForwardGraph> PathCountingMapReducer<G> {
    pub fn new(graph: G) -> Self {
        Self { graph }
    }
}

impl<G: SwhForwardGraph> MapReducer for PathCountingMapReducer<G> {
    type Label = PathCount;
    type Error = std::convert::Infallible;

    fn map(&mut self, node: NodeId) -> Result<Option<Self::Label>, Self::Error> {
        let is_root = self.graph.successors(node).into_iter().next().is_none();
        Ok(Some(PathCount {
            paths_from_roots: if is_root { 1. } else { 0. },
            all_paths: 1.,
        }))
    }

    fn reduce<'a, I: Iterator<Item = &'a Self::Label>>(
        &mut self,
        first_label: Self::Label,
        other_labels: I,
    ) -> Result<Option<Self::Label>, Self::Error>
    where
        Self::Label: 'a,
    {
        Ok(Some(first_label + other_labels.copied().sum()))
    }
}
