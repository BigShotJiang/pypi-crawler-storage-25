// Copyright (C) 2024-2026  The Software Heritage developers
// See the AUTHORS file at the top-level directory of this distribution
// License: GNU General Public License version 3, or any later version
// See top-level LICENSE file for more information

//! Access to precomputed depth of each node's sub-DAG and a topological order
//!
//! It is computed by `bin/generations.rs`.
//!
//! The algorithm to read it is roughly:
//!
//! 1. read first offset from the .offsets (check it's zero)
//! 2. get next offsets from the .offsets, if it is zero, stop. if not, add it to the previous offset.
//! 3. read values from the current position in the .bitstream to the offset (it can be consumed
//!    in parallel with either .par_bridge() or collecting to a Vec and .into_par_iter()).
//! 4. goto 2

use std::borrow::Borrow;
use std::collections::HashSet;
use std::fs::File;
use std::io::{BufReader, BufWriter};
use std::path::{Path, PathBuf};
use std::sync::Arc;

use anyhow::{Context, Result, ensure};
use clap::ValueEnum;
use dsi_bitstream::prelude::*;
use either::Either;
use mmap_rs::{Mmap, MmapFlags};
use rdst::RadixSort;
use serde::{Deserialize, Serialize};

use swh_graph::graph::{NodeId, SwhGraphWithProperties};
use swh_graph::properties;
use swh_graph::utils::suffix_path;
use swh_graph::{NodeConstraint, NodeType};

/// What direction a toposort should be in
///
/// # Examples
///
/// ```
/// use swh_graph_topology::generations::Direction;
///
/// assert_eq!(Direction::Forward.reverse(), Direction::Backward);
/// assert_eq!(serde_json::to_string(&Direction::Forward).unwrap(), r#""forward""#);
/// ```
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, ValueEnum, Deserialize, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum Direction {
    /// ori->snp->rel->rev->dir->cnt
    Forward,
    /// cnt->dir->rev->rel->snp->ori
    Backward,
}

impl std::fmt::Display for Direction {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Direction::Forward => write!(f, "forward"),
            Direction::Backward => write!(f, "backward"),
        }
    }
}

impl Direction {
    pub fn reverse(&self) -> Self {
        match self {
            Direction::Forward => Direction::Backward,
            Direction::Backward => Direction::Forward,
        }
    }
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct GenerationsProperties {
    direction: Direction,
    node_types: NodeConstraint,
}

impl GenerationsProperties {
    pub fn direction(&self) -> Direction {
        self.direction
    }

    pub fn node_types(&self) -> NodeConstraint {
        self.node_types
    }
}

pub struct GenerationsWriter {
    path: PathBuf,
    current_offset: u64,
    data_writer: BufBitWriter<BE, WordAdapter<u64, BufWriter<File>>>,
    offsets_writer: BufBitWriter<BE, WordAdapter<u64, BufWriter<File>>>,
    properties: GenerationsProperties,
    closed: bool,
}

impl GenerationsWriter {
    pub fn new(
        path: impl AsRef<Path>,
        direction: Direction,
        node_types: NodeConstraint,
    ) -> Result<Self, std::io::Error> {
        let path = path.as_ref();
        let offsets_path = suffix_path(path, ".offsets");
        let data_writer = BufBitWriter::new(WordAdapter::<u64, _>::new(BufWriter::new(
            File::create(path)?,
        )));
        let mut offsets_writer = BufBitWriter::new(WordAdapter::<u64, _>::new(BufWriter::new(
            File::create(offsets_path)?,
        )));
        let current_offset = 0;
        offsets_writer.write_gamma(current_offset)?;
        Ok(GenerationsWriter {
            path: path.to_path_buf(),
            current_offset,
            data_writer,
            offsets_writer,
            properties: GenerationsProperties {
                direction,
                node_types,
            },
            closed: false,
        })
    }

    /// Adds a **sorted** list of nodes as the next generation
    ///
    /// # Panics
    ///
    /// When nodes are not sorted
    pub fn push_sorted_generation<I: IntoIterator<Item: Borrow<NodeId>>>(
        &mut self,
        nodes: I,
    ) -> Result<(), std::io::Error> {
        if self.closed {
            return Err(std::io::Error::other(
                "Cannot push to closed GenerationsWriter",
            ));
        }
        let mut num_written_bits = 0;
        let mut previous_node = 0;
        for node in nodes {
            let node = *node.borrow();
            assert!(node >= previous_node, "Nodes are not sorted");
            num_written_bits += self.data_writer.write_gamma(
                (node - previous_node)
                    .try_into()
                    .expect("difference between nodes overflowed u64"),
            )?;
            previous_node = node;
        }

        let num_written_bits: u64 = num_written_bits
            .try_into()
            .expect("num_written_bits overflowed u64");

        self.offsets_writer.write_gamma(num_written_bits)?;

        self.current_offset = self
            .current_offset
            .checked_add(num_written_bits)
            .expect("file bit_size overflowed u64");

        Ok(())
    }

    /// Sorts the given list and passes it to [`Self::push_sorted_generation`]
    pub fn sort_and_push_generation(&mut self, nodes: &mut [NodeId]) -> Result<(), std::io::Error> {
        if self.closed {
            return Err(std::io::Error::other(
                "Cannot push to closed GenerationsWriter",
            ));
        }
        nodes.radix_sort_unstable();
        self.push_sorted_generation(nodes)
    }

    /// Flushes remaining writes, and writes the footer
    pub fn close(&mut self) -> Result<()> {
        ensure!(!self.closed, "GenerationsWriter is already closed");
        self.offsets_writer.write_gamma(0)?; // Marks the end of the file
        self.offsets_writer.flush()?;
        self.data_writer.flush()?;

        let properties_path = suffix_path(&self.path, ".properties.json");
        let mut properties_writer = BufWriter::new(
            File::create(&properties_path)
                .with_context(|| format!("Could not create {}", properties_path.display()))?,
        );
        serde_json::to_writer_pretty(&mut properties_writer, &self.properties)
            .context("Could not write properties")?;
        std::io::Write::flush(&mut properties_writer).context("Could not flush properties")?;
        self.closed = true;

        Ok(())
    }
}

impl Drop for GenerationsWriter {
    fn drop(&mut self) {
        if !self.closed {
            self.close().expect("Could not close GenerationsWriter")
        }
    }
}

/// Reads a compact representation of a topological order
///
/// Software Heritage [distributes a few precomputed topological
/// orders](https://datasets.softwareheritage.org/derived/topology/).
///
/// `GenerationsReader` can be wrapped in a [`TypeAwareGenerationsReader`] to read an existing
/// topological order for different node types.
///
/// # Example
///
/// ```
/// use swh_graph::graph::NodeId;
/// use swh_graph_topology::generations::*;
///
/// # fn main() -> anyhow::Result<()> {
///
/// let dir = tempfile::tempdir()?;
/// let path = dir.path().join("generations.bitstream");
/// let mut writer = GenerationsWriter::new(
///     &path,
///     Direction::Forward,
///     "rev,rel,snp,ori".parse().unwrap(),
/// )?;
/// writer.push_sorted_generation(&[0, 2, 5])?;
/// writer.push_sorted_generation(&[1, 3])?;
/// writer.push_sorted_generation(&[4])?;
/// writer.close()?;
///
/// let reader = GenerationsReader::new(&path)?;
///
/// let generations: Vec<Vec<NodeId>> = reader.iter_generations()?.map(|g| g.collect()).collect();
/// assert_eq!(generations, vec![vec![0, 2, 5], vec![1, 3], vec![4]]);
///
/// let nodes: Vec<(u64, NodeId)> = reader.iter_nodes()?.collect();
/// assert_eq!(nodes, vec![
///     // generation 0:
///     (0, 0), (0, 2), (0, 5),
///     // generation 1:
///     (1, 1), (1, 3),
///     // generation 2:
///     (2, 4)
/// ]);
///
/// # Ok(())
/// # }
/// ```
pub struct GenerationsReader {
    data: Mmap,
    offsets: Mmap,
    path: PathBuf,
    properties: Arc<GenerationsProperties>,
}

impl GenerationsReader {
    pub fn new(path: impl AsRef<Path>) -> Result<Self> {
        let path = path.as_ref();
        let offsets_path = suffix_path(path, ".offsets");
        let properties_path = suffix_path(path, ".properties.json");
        let properties_reader = BufReader::new(
            File::open(&properties_path)
                .with_context(|| format!("Could not open {}", properties_path.display()))?,
        );
        let properties = Arc::new(
            serde_json::from_reader(properties_reader).context("Could not parse properties")?,
        );
        let file_len = path
            .metadata()
            .with_context(|| format!("Could not stat {}", path.display()))?
            .len();
        let offsets_file_len = offsets_path
            .metadata()
            .with_context(|| format!("Could not stat {}", offsets_path.display()))?
            .len();
        let file =
            File::open(path).with_context(|| format!("Could not open {}", path.display()))?;
        let offsets_file = File::open(&offsets_path)
            .with_context(|| format!("Could not open {}", offsets_path.display()))?;
        let data = unsafe {
            mmap_rs::MmapOptions::new(file_len as _)
                .context("Could not initialize mmap")?
                .with_flags(MmapFlags::TRANSPARENT_HUGE_PAGES)
                .with_file(&file, 0)
                .map()
                .with_context(|| format!("Could not mmap {}", path.display()))?
        };
        let offsets = unsafe {
            mmap_rs::MmapOptions::new(offsets_file_len as _)
                .context("Could not initialize mmap")?
                .with_flags(MmapFlags::TRANSPARENT_HUGE_PAGES)
                .with_file(&offsets_file, 0)
                .map()
                .with_context(|| format!("Could not mmap {}", offsets_path.display()))?
        };
        Ok(GenerationsReader {
            data,
            offsets,
            path: path.to_path_buf(),
            properties,
        })
    }

    pub fn properties(&self) -> Arc<GenerationsProperties> {
        Arc::clone(&self.properties)
    }

    /// Returns an iterator of iterators of nodes, in topological order
    pub fn iter_generations(&self) -> Result<GenerationsIterator<'_>> {
        GenerationsIterator::new(
            bytemuck::cast_slice(self.data.as_ref()),
            bytemuck::cast_slice(self.offsets.as_ref()),
        )
    }

    /// Returns an iterator of `(generation, node)`, in increasing `generation` order.
    pub fn iter_nodes(&self) -> Result<impl Iterator<Item = (u64, NodeId)> + '_> {
        Ok(self
            .iter_generations()?
            .zip(0u64..)
            .flat_map(|(generation, depth)| generation.map(move |node| (depth, node))))
    }
}

type Bbr<'a> = BufBitReader<BE, MemWordReader<u64, &'a [u64]>>;

pub struct GenerationsIterator<'a> {
    data_reader: Bbr<'a>,
    offsets_reader: Bbr<'a>,
    next_generation_offset: u64,
}

impl<'a> GenerationsIterator<'a> {
    fn new(data: &'a [u64], offsets: &'a [u64]) -> Result<Self> {
        let data_reader = BufBitReader::<BE, _>::new(MemWordReader::new(data));
        let mut offsets_reader = BufBitReader::<BE, _>::new(MemWordReader::new(offsets));
        let next_generation_offset = offsets_reader
            .read_gamma()
            .context("Could not read offset")?;
        ensure!(
            next_generation_offset == 0,
            "first offset should be 0, but is {next_generation_offset}"
        );
        Ok(Self {
            data_reader,
            offsets_reader,
            next_generation_offset,
        })
    }
}

impl<'a> Iterator for GenerationsIterator<'a> {
    type Item = GenerationIterator<'a>;

    fn next(&mut self) -> Option<Self::Item> {
        if self.next_generation_offset == u64::MAX {
            None
        } else {
            let mut data_reader = self.data_reader.clone();
            data_reader
                .set_bit_pos(self.next_generation_offset)
                .expect("Could not set bit_pos");
            let generation_bit_size = self
                .offsets_reader
                .read_gamma()
                .expect("Could not read offset");
            if generation_bit_size == 0 {
                // End of file
                self.next_generation_offset = u64::MAX;
                return None;
            }
            self.next_generation_offset = self
                .next_generation_offset
                .checked_add(generation_bit_size)
                .expect("next_generation_offset overflowed u64");
            Some(GenerationIterator::new(
                data_reader,
                self.next_generation_offset,
            ))
        }
    }
}

#[derive(Clone)]
pub struct GenerationIterator<'a> {
    data_reader: Bbr<'a>,
    end_offset: u64,
    current_node: NodeId,
}

impl<'a> GenerationIterator<'a> {
    fn new(data_reader: Bbr<'a>, end_offset: u64) -> Self {
        Self {
            data_reader,
            end_offset,
            current_node: 0,
        }
    }
}

impl Iterator for GenerationIterator<'_> {
    type Item = NodeId;

    fn next(&mut self) -> Option<Self::Item> {
        if self.data_reader.bit_pos().expect("Could not get bit pos") >= self.end_offset {
            None
        } else {
            self.current_node = self
                .current_node
                .checked_add(
                    self.data_reader
                        .read_gamma()
                        .expect("Could not read node id")
                        .try_into()
                        .expect("Node id difference overflowed usize"),
                )
                .expect("Node id overflowed usize");
            Some(self.current_node)
        }
    }
}

/// Wrapper for [`GenerationsReader`] that filters out (or adds) nodes of a given type
///
/// # Example
///
/// ```
/// use swh_graph::graph::NodeId;
/// use swh_graph::graph_builder::GraphBuilder;
/// use swh_graph::swhid;
/// use swh_graph_topology::generations::*;
///
/// # fn main() -> anyhow::Result<()> {
/// // Create a fake graph to initialize TypeAwareGenerationsReader
/// let mut builder = GraphBuilder::default();
/// let ori = builder
///     .node(swhid!(swh:1:ori:0000000000000000000000000000000000000000))?
///     .done();
/// let snp = builder
///     .node(swhid!(swh:1:snp:0000000000000000000000000000000000000001))?
///     .done();
/// let rel = builder
///     .node(swhid!(swh:1:rel:0000000000000000000000000000000000000002))?
///     .done();
/// let rev1 = builder
///     .node(swhid!(swh:1:rev:0000000000000000000000000000000000000003))?
///     .done();
/// let rev2 = builder
///     .node(swhid!(swh:1:rev:0000000000000000000000000000000000000004))?
///     .done();
/// let dir1 = builder
///     .node(swhid!(swh:1:dir:0000000000000000000000000000000000000005))?
///     .done();
/// let dir2 = builder
///     .node(swhid!(swh:1:dir:0000000000000000000000000000000000000006))?
///     .done();
/// let cnt1 = builder
///     .node(swhid!(swh:1:cnt:0000000000000000000000000000000000000007))?
///     .done();
/// let cnt2 = builder
///     .node(swhid!(swh:1:cnt:0000000000000000000000000000000000000008))?
///     .done();
/// builder.arc(ori, snp);
/// builder.arc(snp, rel);
/// builder.arc(rel, rev1);
/// builder.arc(rev1, rev2);
/// builder.arc(rev1, dir1);
/// builder.arc(rev2, dir2);
/// builder.arc(dir1, cnt1);
/// builder.arc(dir2, cnt2);
/// let graph = builder.done()?;
///
/// // Write generations:
/// let dir = tempfile::tempdir()?;
/// let path = dir.path().join("generations.bitstream");
/// let mut writer = GenerationsWriter::new(
///     &path,
///     Direction::Forward,
///     "dir,rev,rel,snp,ori".parse().unwrap(),
/// )?;
/// writer.push_sorted_generation(&[ori])?;
/// writer.push_sorted_generation(&[snp])?;
/// writer.push_sorted_generation(&[rel])?;
/// writer.push_sorted_generation(&[rev1])?;
/// writer.push_sorted_generation(&[rev2, dir1])?;
/// writer.push_sorted_generation(&[dir2])?;
/// // not pushing contents, for space efficiency
/// writer.close()?;
///
/// // With the same node_types, we get exactly what we wrote:
/// let reader = TypeAwareGenerationsReader::new(
///     GenerationsReader::new(&path)?,
///     &graph,
///     "dir,rev,rel,snp,ori".parse().unwrap()
/// )?;
/// let generations: Vec<Vec<NodeId>> = reader.iter_generations()?.map(|g| g.collect()).collect();
/// assert_eq!(
///     generations,
///     vec![vec![ori], vec![snp], vec![rel], vec![rev1], vec![rev2, dir1], vec![dir2]]
/// );
///
/// let nodes: Vec<(u64, NodeId)> = reader.iter_nodes()?.collect();
/// assert_eq!(nodes, vec![
///     (0, ori),
///     (1, snp),
///     (2, rel),
///     (3, rev1),
///     (4, rev2), (4, dir1),
///     (5, dir2),
/// ]);
///
/// // We can filter out dirs:
/// let reader = TypeAwareGenerationsReader::new(
///     GenerationsReader::new(&path)?,
///     &graph,
///     "rev,rel,snp,ori".parse().unwrap()
/// )?;
/// let generations: Vec<Vec<NodeId>> = reader.iter_generations()?.map(|g| g.collect()).collect();
/// assert_eq!(
///     generations,
///     vec![vec![ori], vec![snp], vec![rel], vec![rev1], vec![rev2], vec![]]
/// );
///
/// let nodes: Vec<(u64, NodeId)> = reader.iter_nodes()?.collect();
/// assert_eq!(nodes, vec![
///     (0, ori),
///     (1, snp),
///     (2, rel),
///     (3, rev1),
///     (4, rev2),
/// ]);
///
/// // We can read contents even though they were not written to disk:
/// let reader = TypeAwareGenerationsReader::new(
///     GenerationsReader::new(&path)?,
///     &graph,
///     "cnt,dir,rev,rel,snp,ori".parse().unwrap()
/// )?;
/// let generations: Vec<Vec<NodeId>> = reader.iter_generations()?.map(|g| g.collect()).collect();
/// assert_eq!(
///     generations,
///     vec![vec![ori], vec![snp], vec![rel], vec![rev1], vec![rev2, dir1], vec![dir2], vec![cnt1, cnt2]]
/// );
///
/// let nodes: Vec<(u64, NodeId)> = reader.iter_nodes()?.collect();
/// assert_eq!(nodes, vec![
///     (0, ori),
///     (1, snp),
///     (2, rel),
///     (3, rev1),
///     (4, rev2), (4, dir1),
///     (5, dir2),
///     (6, cnt1), (6, cnt2),
/// ]);
///
/// # Ok(())
/// # }
/// ```
pub struct TypeAwareGenerationsReader<G: SwhGraphWithProperties<Maps: properties::Maps>> {
    reader: GenerationsReader,
    graph: G,
    /// `None` if the underlying node_types are (a superset of) the ones requested from this reader.
    /// This avoids unnecessary lookups of the node_type.
    node_types: Option<NodeConstraint>,
    add_content_at_beginning: bool,
    add_content_at_end: bool,
}

impl<G: SwhGraphWithProperties<Maps: properties::Maps>> TypeAwareGenerationsReader<G> {
    /// Builds a new `TypeAwareGenerationsReader` wrapping a [`GenerationsReader`]
    ///
    /// `node_types` must be a subset of the types of the underlying `GenerationsReader`;
    /// except [`NodeType::Content`] which can be freely added (content nodes are always at the
    /// beginning or the end of a topological order).
    pub fn new(reader: GenerationsReader, graph: G, node_types: NodeConstraint) -> Result<Self> {
        let have: HashSet<_> = reader.properties.node_types.to_vec().into_iter().collect();
        let want: HashSet<_> = node_types.to_vec().into_iter().collect();
        let mut missing: HashSet<_> = want.difference(&have).copied().collect();
        let to_remove: HashSet<_> = have.difference(&want).copied().collect();

        let mut add_content_at_beginning = false;
        let mut add_content_at_end = false;
        if missing.remove(&NodeType::Content) {
            match reader.properties.direction {
                Direction::Forward => add_content_at_end = true,
                Direction::Backward => add_content_at_beginning = true,
            }
        }

        ensure!(
            missing.is_empty(),
            "Expected to read {} nodes from {}, but it only has {}. Missing types: {}",
            node_types,
            reader.path.display(),
            reader.properties.node_types,
            NodeConstraint::from_types(missing),
        );

        Ok(Self {
            reader,
            graph,
            node_types: if to_remove.is_empty() {
                // optimization: we don't need to lookup node types in this case
                None
            } else {
                Some(node_types)
            },
            add_content_at_beginning,
            add_content_at_end,
        })
    }

    /// Returns an iterator of iterators of nodes, in topological order
    pub fn iter_generations(&self) -> Result<TypeAwareGenerationsIterator<'_, G>> {
        Ok(TypeAwareGenerationsIterator {
            iterator: self.reader.iter_generations()?,
            graph: &self.graph,
            node_types: self.node_types,
            add_content_at_beginning: self.add_content_at_beginning,
            add_content_at_end: self.add_content_at_end,
        })
    }

    /// Returns an iterator of `(generation, node)`, in increasing `generation` order.
    pub fn iter_nodes(&self) -> Result<impl Iterator<Item = (u64, NodeId)> + '_> {
        Ok(self
            .iter_generations()?
            .zip(0u64..)
            .flat_map(|(generation, depth)| generation.map(move |node| (depth, node))))
    }
}

/// Wrapper for [`GenerationsIterator`] that filters nodes based on type, and optionally
/// adds a generation with all contents at the beginning or the end.
pub struct TypeAwareGenerationsIterator<'a, G: SwhGraphWithProperties<Maps: properties::Maps>> {
    iterator: GenerationsIterator<'a>,
    graph: &'a G,
    /// `None` if there is no need to check node types
    node_types: Option<NodeConstraint>,
    add_content_at_beginning: bool,
    add_content_at_end: bool,
}

impl<'a, G: SwhGraphWithProperties<Maps: properties::Maps>> Iterator
    for TypeAwareGenerationsIterator<'a, G>
{
    type Item = Either<TypeAwareGenerationIterator<'a, G>, ContentEnumeratingIterator<'a, G>>;

    fn next(&mut self) -> Option<Self::Item> {
        if self.add_content_at_beginning {
            // first call to .next()
            self.add_content_at_beginning = false;
            Some(Either::Right(ContentEnumeratingIterator::new(self.graph)))
        } else {
            match self.iterator.next() {
                Some(it) => Some(Either::Left(TypeAwareGenerationIterator {
                    iterator: it,
                    graph: self.graph,
                    node_types: self.node_types,
                })),
                None if self.add_content_at_end => {
                    // ran out of non-content nodes
                    self.add_content_at_end = false;
                    Some(Either::Right(ContentEnumeratingIterator::new(self.graph)))
                }
                None => None,
            }
        }
    }
}

/// Wrapper for [`GenerationIterator`] that filters nodes based on type.
#[derive(Clone)]
pub struct TypeAwareGenerationIterator<'a, G: SwhGraphWithProperties<Maps: properties::Maps>> {
    iterator: GenerationIterator<'a>,
    graph: &'a G,
    /// `None` if there is no need to check node types
    node_types: Option<NodeConstraint>,
}

impl<G: SwhGraphWithProperties<Maps: properties::Maps>> Iterator
    for TypeAwareGenerationIterator<'_, G>
{
    type Item = NodeId;

    fn next(&mut self) -> Option<Self::Item> {
        self.iterator.by_ref().find(|&node| {
            if !self.graph.has_node(node) {
                // self.graph is a subgraph
                return false;
            }
            match self.node_types {
                Some(node_types) => node_types.matches(self.graph.properties().node_type(node)),
                None => true,
            }
        })
    }
}

pub struct ContentEnumeratingIterator<'a, G: SwhGraphWithProperties<Maps: properties::Maps>> {
    next_node: Option<NodeId>,
    graph: &'a G,
}

impl<'a, G: SwhGraphWithProperties<Maps: properties::Maps>> ContentEnumeratingIterator<'a, G> {
    fn new(graph: &'a G) -> Self {
        Self {
            next_node: Some(0),
            graph,
        }
    }
}

impl<G: SwhGraphWithProperties<Maps: properties::Maps>> Iterator
    for ContentEnumeratingIterator<'_, G>
{
    type Item = NodeId;

    fn next(&mut self) -> Option<Self::Item> {
        // TODO: parallelize search for content nodes? probably not worth it because half the nodes
        // are contents; but they are clustered by LLP so parallelism might be faster.
        let start = self.next_node?;
        for node in start..self.graph.num_nodes() {
            if self.graph.has_node(node)
                && self.graph.properties().node_type(node) == NodeType::Content
            {
                self.next_node = Some(node + 1);
                return Some(node);
            }
        }
        self.next_node = None;
        None
    }
}
