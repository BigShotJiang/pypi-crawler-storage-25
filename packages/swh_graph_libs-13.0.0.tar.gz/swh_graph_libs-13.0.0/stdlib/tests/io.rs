// Copyright (C) 2026  The Software Heritage developers
// See the AUTHORS file at the top-level directory of this distribution
// License: GNU General Public License version 3, or any later version
// See top-level LICENSE file for more information

use std::io::Cursor;
use std::sync::mpsc::sync_channel;

use anyhow::Result;
use swh_graph::graph::SwhGraphWithProperties;
use swh_graph::swhid;
use swh_graph_stdlib::io::queue_nodes_from_swhids_csv;

mod data;

#[test]
fn test_queue_nodes_from_swhids_csv() -> Result<()> {
    let graph = data::build_test_graph_1()?;
    let props = graph.properties();

    let csv = "\
swhid,other
swh:1:rev:0000000000000000000000000000000000000009,foo
swh:1:dir:0000000000000000000000000000000000000002,bar
swh:1:cnt:0000000000000000000000000000000000000001,baz
";

    let (tx, rx) = sync_channel(10);
    queue_nodes_from_swhids_csv(&graph, Cursor::new(csv), "swhid", tx, 2)?;

    let results: Vec<(String, _)> = rx.into_iter().flatten().collect();

    assert_eq!(
        results,
        vec![
            (
                "swh:1:rev:0000000000000000000000000000000000000009".to_string(),
                props.node_id(swhid!(swh:1:rev:0000000000000000000000000000000000000009))?,
            ),
            (
                "swh:1:dir:0000000000000000000000000000000000000002".to_string(),
                props.node_id(swhid!(swh:1:dir:0000000000000000000000000000000000000002))?,
            ),
            (
                "swh:1:cnt:0000000000000000000000000000000000000001".to_string(),
                props.node_id(swhid!(swh:1:cnt:0000000000000000000000000000000000000001))?,
            ),
        ]
    );

    Ok(())
}
