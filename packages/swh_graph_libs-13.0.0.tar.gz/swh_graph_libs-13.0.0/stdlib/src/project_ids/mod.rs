// Copyright (C) 2026  The Software Heritage developers
// See the AUTHORS file at the top-level directory of this distribution
// License: GNU General Public License version 3, or any later version
// See top-level LICENSE file for more information

use std::path::{Path, PathBuf};

use anyhow::{Context, Result};

mod write;
pub use write::*;

struct Database {
    base_path: PathBuf,
}

impl Database {
    fn rev_to_roots_path(&self) -> PathBuf {
        self.base_path.join("rev_to_roots")
    }

    fn project_id_to_roots_path(&self) -> PathBuf {
        self.base_path.join("project_id_to_roots")
    }

    fn rev_to_project_id_path(&self) -> PathBuf {
        self.base_path.join("rev_to_project_id")
    }

    fn index_rev_to_roots(&self) -> Result<()> {
        let path = self.rev_to_roots_path();
        compute_elias_fano_index(&path)
            .with_context(|| format!("Could not index {}", path.display()))
    }

    fn index_project_id_to_roots(&self) -> Result<()> {
        let path = self.project_id_to_roots_path();
        compute_elias_fano_index(&path)
            .with_context(|| format!("Could not index {}", path.display()))
    }
}

/// Compute an Elias-Fano index for a BVGraph stored at the given path
fn compute_elias_fano_index(path: &Path) -> Result<()> {
    use dsi_bitstream::traits::BigEndian;
    use webgraph_cli::GlobalArgs;
    use webgraph_cli::build::ef::{CliArgs as EfCliArgs, build_elias_fano};

    let global_args = GlobalArgs { log_interval: None };
    let cli_args = EfCliArgs {
        basename: path.to_path_buf(),
        number_of_nodes: None,
    };
    build_elias_fano::<BigEndian>(global_args, cli_args)
}
