Software Heritage - libraries for the graph service
===================================================

Rust libraries and utilities built around `swh-graph <https://docs.softwareheritage.org/devel/swh-graph/>`_.

* `swh-graph-stdlib <https://docs.rs/swh-graph-stdlib/>`_: algorithms to
  mine information from, and run common algorithms on, swh-graph
* `swh_graph_topology <https://docs.rs/swh_graph_topology>`_: currently
  just an implementation of reading nodes in (precomputed) topological order
