# Copyright (C) 2022-2026  The Software Heritage developers
# See the AUTHORS file at the top-level directory of this distribution
# License: GNU General Public License version 3, or any later version
# See top-level LICENSE file for more information

import itertools
import math
from pathlib import Path
import struct
import subprocess

import datafusion
import pyarrow.dataset
import pytest

from swh.graph.example_dataset import DATASET_DIR
from swh.graph.libs.luigi.topology import (
    ComputeGenerations,
    CountDescendants,
    CountPaths,
    TopoSort,
    inverse_direction,
)
from swh.graph.libs.shell import Rust
from swh.graph.shell import Sink

# FIXME: the order of sample ancestors should not be hardcoded
# FIXME: swh:1:snp:0000000000000000000000000000000000000022,3,1,swh has three possible
# sample ancestors; they should not be hardcoded here
TOPO_ORDER_BACKWARD = """\
SWHID,ancestors,successors,sample_ancestor1,sample_ancestor2
swh:1:rev:0000000000000000000000000000000000000003,0,1,,
swh:1:rev:0000000000000000000000000000000000000009,1,4,swh:1:rev:0000000000000000000000000000000000000003,
swh:1:rel:0000000000000000000000000000000000000010,1,2,swh:1:rev:0000000000000000000000000000000000000009,
swh:1:snp:0000000000000000000000000000000000000020,2,1,swh:1:rel:0000000000000000000000000000000000000010,swh:1:rev:0000000000000000000000000000000000000009
swh:1:ori:83404f995118bd25774f4ac14422a8f175e7a054,1,0,swh:1:snp:0000000000000000000000000000000000000020,
swh:1:rev:0000000000000000000000000000000000000013,1,1,swh:1:rev:0000000000000000000000000000000000000009,
swh:1:rev:0000000000000000000000000000000000000018,1,2,swh:1:rev:0000000000000000000000000000000000000013,
swh:1:rel:0000000000000000000000000000000000000019,1,0,swh:1:rev:0000000000000000000000000000000000000018,
swh:1:rel:0000000000000000000000000000000000000021,1,1,swh:1:rev:0000000000000000000000000000000000000018,
swh:1:snp:0000000000000000000000000000000000000022,3,1,swh:1:rel:0000000000000000000000000000000000000010,swh:1:rev:0000000000000000000000000000000000000009
swh:1:ori:8f50d3f60eae370ddbf85c86219c55108a350165,1,0,swh:1:snp:0000000000000000000000000000000000000022,
""".replace(
    "\n", "\r\n"
)

TOPO_ORDER_FORWARD = """\
SWHID,ancestors,successors,sample_ancestor1,sample_ancestor2
swh:1:rel:0000000000000000000000000000000000000019,0,1,,
swh:1:ori:83404f995118bd25774f4ac14422a8f175e7a054,0,1,,
swh:1:snp:0000000000000000000000000000000000000020,1,2,swh:1:ori:83404f995118bd25774f4ac14422a8f175e7a054,
swh:1:ori:8f50d3f60eae370ddbf85c86219c55108a350165,0,1,,
swh:1:snp:0000000000000000000000000000000000000022,1,3,swh:1:ori:8f50d3f60eae370ddbf85c86219c55108a350165,
swh:1:rel:0000000000000000000000000000000000000021,1,1,swh:1:snp:0000000000000000000000000000000000000022,
swh:1:rev:0000000000000000000000000000000000000018,2,1,swh:1:rel:0000000000000000000000000000000000000021,swh:1:rel:0000000000000000000000000000000000000019
swh:1:rev:0000000000000000000000000000000000000013,1,1,swh:1:rev:0000000000000000000000000000000000000018,
swh:1:rel:0000000000000000000000000000000000000010,2,1,swh:1:snp:0000000000000000000000000000000000000020,swh:1:snp:0000000000000000000000000000000000000022
swh:1:rev:0000000000000000000000000000000000000009,4,1,swh:1:snp:0000000000000000000000000000000000000020,swh:1:rel:0000000000000000000000000000000000000010
swh:1:rev:0000000000000000000000000000000000000003,1,0,swh:1:rev:0000000000000000000000000000000000000009,
""".replace(
    "\n", "\r\n"
)

TOPO_ORDER2_BACKWARD = """\
SWHID,depth
swh:1:rev:0000000000000000000000000000000000000003,0
swh:1:rev:0000000000000000000000000000000000000009,1
swh:1:rel:0000000000000000000000000000000000000010,2
swh:1:rev:0000000000000000000000000000000000000013,2
swh:1:snp:0000000000000000000000000000000000000020,3
swh:1:rev:0000000000000000000000000000000000000018,3
swh:1:ori:83404f995118bd25774f4ac14422a8f175e7a054,4
swh:1:rel:0000000000000000000000000000000000000021,4
swh:1:rel:0000000000000000000000000000000000000019,4
swh:1:snp:0000000000000000000000000000000000000022,5
swh:1:ori:8f50d3f60eae370ddbf85c86219c55108a350165,6

""".replace(
    "\n", "\r\n"
)

TOPO_ORDER2_FORWARD = """\
SWHID,depth
swh:1:ori:8f50d3f60eae370ddbf85c86219c55108a350165,0
swh:1:ori:83404f995118bd25774f4ac14422a8f175e7a054,0
swh:1:rel:0000000000000000000000000000000000000019,0
swh:1:snp:0000000000000000000000000000000000000022,1
swh:1:snp:0000000000000000000000000000000000000020,1
swh:1:rel:0000000000000000000000000000000000000010,2
swh:1:rel:0000000000000000000000000000000000000021,2
swh:1:rev:0000000000000000000000000000000000000018,3
swh:1:rev:0000000000000000000000000000000000000013,4
swh:1:rev:0000000000000000000000000000000000000009,5
swh:1:rev:0000000000000000000000000000000000000003,6
""".replace(
    "\n", "\r\n"
)

PATH_COUNTS_FORWARD = """\
SWHID,paths_from_roots,all_paths
swh:1:rev:0000000000000000000000000000000000000003,1.0,1.0
swh:1:rev:0000000000000000000000000000000000000009,1.0,2.0
swh:1:rel:0000000000000000000000000000000000000010,1.0,3.0
swh:1:snp:0000000000000000000000000000000000000020,2.0,6.0
swh:1:ori:83404f995118bd25774f4ac14422a8f175e7a054,2.0,7.0
swh:1:rev:0000000000000000000000000000000000000013,1.0,3.0
swh:1:rev:0000000000000000000000000000000000000018,1.0,4.0
swh:1:rel:0000000000000000000000000000000000000019,1.0,5.0
swh:1:rel:0000000000000000000000000000000000000021,1.0,5.0
swh:1:snp:0000000000000000000000000000000000000022,3.0,11.0
swh:1:ori:8f50d3f60eae370ddbf85c86219c55108a350165,3.0,12.0
""".replace(
    "\n", "\r\n"
)

PATH_COUNTS_BACKWARD = """\
SWHID,paths_from_roots,all_paths
swh:1:rel:0000000000000000000000000000000000000019,1.0,1.0
swh:1:ori:83404f995118bd25774f4ac14422a8f175e7a054,1.0,1.0
swh:1:snp:0000000000000000000000000000000000000020,1.0,2.0
swh:1:ori:8f50d3f60eae370ddbf85c86219c55108a350165,1.0,1.0
swh:1:snp:0000000000000000000000000000000000000022,1.0,2.0
swh:1:rel:0000000000000000000000000000000000000021,1.0,3.0
swh:1:rev:0000000000000000000000000000000000000018,2.0,5.0
swh:1:rev:0000000000000000000000000000000000000013,2.0,6.0
swh:1:rel:0000000000000000000000000000000000000010,2.0,5.0
swh:1:rev:0000000000000000000000000000000000000009,6.0,16.0
swh:1:rev:0000000000000000000000000000000000000003,6.0,17.0
""".replace(
    "\n", "\r\n"
)


def read_parquet(path, table_name, query):
    ctx = datafusion.SessionContext()
    ctx.register_dataset(table_name, pyarrow.dataset.dataset(path, format="parquet"))
    return ctx.sql(query)


@pytest.mark.parametrize(
    "direction,algorithm", itertools.product(["backward", "forward"], ["bfs", "dfs"])
)
def test_toposort(tmpdir, direction: str, algorithm: str):
    tmpdir = Path(tmpdir)

    topological_order_path = (
        tmpdir / f"topological_order_{algorithm}_{direction}_rev,rel,snp,ori.csv.zst"
    )

    task = TopoSort(
        local_graph_path=DATASET_DIR / "compressed",
        topology_dir=tmpdir,
        direction=direction,
        algorithm=algorithm,
        object_types="rev,rel,snp,ori",
        graph_name="example",
    )

    task.run()

    csv_text = subprocess.check_output(["zstdcat", topological_order_path]).decode()

    expected = TOPO_ORDER_BACKWARD if direction == "backward" else TOPO_ORDER_FORWARD

    (header, *rows) = csv_text.split("\r\n")
    (expected_header, *expected_lines) = expected.split("\r\n")
    assert header == expected_header

    assert set(rows) == set(expected_lines)

    assert rows.pop() == "", "Missing trailing newline"

    if direction == "backward":
        # Only one possible first row
        assert rows[0] == "swh:1:rev:0000000000000000000000000000000000000003,0,1,,"

        # The only three possible last rows
        assert rows[-1] in [
            "swh:1:ori:83404f995118bd25774f4ac14422a8f175e7a054,1,0"
            ",swh:1:snp:0000000000000000000000000000000000000020,",
            "swh:1:ori:8f50d3f60eae370ddbf85c86219c55108a350165,1,0"
            ",swh:1:snp:0000000000000000000000000000000000000022,",
            "swh:1:rel:0000000000000000000000000000000000000019,1,0"
            ",swh:1:rev:0000000000000000000000000000000000000018,",
        ]
    else:
        # Three possible first rows
        assert rows[0] in [
            "swh:1:rel:0000000000000000000000000000000000000019,0,1,,",
            "swh:1:ori:83404f995118bd25774f4ac14422a8f175e7a054,0,1,,",
            "swh:1:ori:8f50d3f60eae370ddbf85c86219c55108a350165,0,1,,",
        ]

        # The only possible last row
        assert rows[-1] == (
            "swh:1:rev:0000000000000000000000000000000000000003,1,0,"
            "swh:1:rev:0000000000000000000000000000000000000009,"
        )


@pytest.mark.parametrize("direction", ["backward", "forward"])
def test_generations(tmpdir, direction: str):
    tmpdir = Path(tmpdir)

    topological_order_path = (
        tmpdir / f"topological_order_{direction}_rev,rel,snp,ori.bitstream"
    )

    task = ComputeGenerations(
        local_graph_path=DATASET_DIR / "compressed",
        topology_dir=tmpdir,
        direction=direction,
        object_types="rev,rel,snp,ori",
        graph_name="example",
    )

    task.run()

    # fmt: off
    csv_text = (
        Rust(
            "topo-order-to-csv",
            DATASET_DIR / "compressed/example",
            "--order",
            topological_order_path,
        )
        > Sink()
    ).run().stdout
    # fmt: on

    expected = TOPO_ORDER2_BACKWARD if direction == "backward" else TOPO_ORDER2_FORWARD

    (header, *rows) = csv_text.decode().split("\r\n")
    (expected_header, *expected_lines) = expected.split("\r\n")
    assert header == expected_header

    assert set(rows) == set(expected_lines)

    assert rows.pop() == "", "Missing trailing newline"


@pytest.mark.parametrize(
    "direction,object_types",
    itertools.product(
        ["backward", "forward"], ["rev,rel,snp,ori", "cnt,dir,rev,rel,snp,ori"]
    ),
)
def test_countpaths(tmpdir, direction: str, object_types: str):
    tmpdir = Path(tmpdir)

    path_counts_path = tmpdir / f"path_counts_{direction}_{object_types}"

    gen_task = ComputeGenerations(
        local_graph_path=DATASET_DIR / "compressed",
        topology_dir=tmpdir,
        direction=inverse_direction(direction),
        object_types=object_types.removeprefix("cnt,"),
        graph_name="example",
    )
    gen_task.run()

    task = CountPaths(
        local_graph_path=DATASET_DIR / "compressed",
        topology_dir=tmpdir,
        direction=direction,
        object_types=object_types,
        graph_name="example",
    )

    task.run()

    assert path_counts_path.exists()

    # Check parquet CSV output
    df = read_parquet(
        path_counts_path / "parquet",
        "path_counts",
        "SELECT swhid, paths_from_roots, all_paths FROM path_counts ORDER BY swhid",
    )
    df.write_csv(str(tmpdir / "path_counts.csv"))

    csv_text = (tmpdir / "path_counts.csv").read_text()

    if object_types == "rev,rel,snp,ori":
        expected = (
            PATH_COUNTS_BACKWARD if direction == "backward" else PATH_COUNTS_FORWARD
        )
        assert sorted(csv_text.split("\n")) == sorted(expected.split("\r\n")[1:])
    elif direction == "backward":
        expected = PATH_COUNTS_BACKWARD.replace("\r\n", "\n")
        expected += """\
swh:1:dir:0000000000000000000000000000000000000012,2.0,7.0
swh:1:dir:0000000000000000000000000000000000000017,2.0,6.0
swh:1:dir:0000000000000000000000000000000000000002,6.0,18.0
swh:1:dir:0000000000000000000000000000000000000008,8.0,24.0
swh:1:dir:0000000000000000000000000000000000000016,2.0,7.0
swh:1:dir:0000000000000000000000000000000000000006,8.0,25.0
swh:1:cnt:0000000000000000000000000000000000000001,14.0,43.0
swh:1:cnt:0000000000000000000000000000000000000004,8.0,26.0
swh:1:cnt:0000000000000000000000000000000000000005,8.0,26.0
swh:1:cnt:0000000000000000000000000000000000000007,8.0,25.0
swh:1:cnt:0000000000000000000000000000000000000011,2.0,8.0
swh:1:cnt:0000000000000000000000000000000000000014,2.0,7.0
swh:1:cnt:0000000000000000000000000000000000000015,2.0,8.0
"""
        assert list(sorted(csv_text.split("\n"))) == list(
            sorted(expected.split("\n")[1:])
        )
    else:
        # can't reuse PATH_COUNTS_FORWARD because directories change the count
        # of other objects in this direction
        expected = """\
SWHID,paths_from_roots,all_paths
swh:1:cnt:0000000000000000000000000000000000000001,1.0,1.0
swh:1:cnt:0000000000000000000000000000000000000004,1.0,1.0
swh:1:cnt:0000000000000000000000000000000000000005,1.0,1.0
swh:1:cnt:0000000000000000000000000000000000000007,1.0,1.0
swh:1:cnt:0000000000000000000000000000000000000011,1.0,1.0
swh:1:cnt:0000000000000000000000000000000000000014,1.0,1.0
swh:1:cnt:0000000000000000000000000000000000000015,1.0,1.0
swh:1:dir:0000000000000000000000000000000000000006,2.0,3.0
swh:1:dir:0000000000000000000000000000000000000016,1.0,2.0
swh:1:dir:0000000000000000000000000000000000000008,4.0,6.0
swh:1:dir:0000000000000000000000000000000000000002,1.0,2.0
swh:1:dir:0000000000000000000000000000000000000017,2.0,4.0
swh:1:dir:0000000000000000000000000000000000000012,5.0,8.0
swh:1:rev:0000000000000000000000000000000000000003,1.0,3.0
swh:1:rev:0000000000000000000000000000000000000009,5.0,10.0
swh:1:rel:0000000000000000000000000000000000000010,5.0,11.0
swh:1:snp:0000000000000000000000000000000000000020,10.0,22.0
swh:1:ori:83404f995118bd25774f4ac14422a8f175e7a054,10.0,23.0
swh:1:rev:0000000000000000000000000000000000000013,10.0,19.0
swh:1:rev:0000000000000000000000000000000000000018,12.0,24.0
swh:1:rel:0000000000000000000000000000000000000019,12.0,25.0
swh:1:rel:0000000000000000000000000000000000000021,12.0,25.0
swh:1:snp:0000000000000000000000000000000000000022,22.0,47.0
swh:1:ori:8f50d3f60eae370ddbf85c86219c55108a350165,22.0,48.0
"""
        assert list(sorted(csv_text.split("\n"))) == list(
            sorted(expected.split("\n")[1:])
        )

    df = read_parquet(
        path_counts_path / "parquet",
        "path_counts2",
        "SELECT node, paths_from_roots, all_paths FROM path_counts2 ORDER BY node",
    )
    rows = df.collect()
    num_nodes = 24
    expected_from_roots = [NaN()] * num_nodes
    expected_all_paths = [NaN()] * num_nodes
    for batch in rows:
        for row in batch.to_pylist():
            expected_from_roots[row["node"]] = row["paths_from_roots"]
            expected_all_paths[row["node"]] = row["all_paths"]

    arrays_path = tmpdir / f"path_counts_{direction}_{object_types}"
    from_root_bytes = (arrays_path / "paths_from_root.bin").read_bytes()
    all_paths_bytes = (arrays_path / "all_paths.bin").read_bytes()

    n = len(from_root_bytes) // 8
    actual_from_roots = list(struct.unpack(f">{n}d", from_root_bytes))
    actual_all_paths = list(struct.unpack(f">{n}d", all_paths_bytes))

    assert actual_from_roots == expected_from_roots
    assert actual_all_paths == expected_all_paths


DESCENDANT_COUNTS_HISTHOST_FORWARD = {
    "swh:1:rev:0000000000000000000000000000000000000003": 1.0,
    "swh:1:rev:0000000000000000000000000000000000000009": 2.0,
    "swh:1:rel:0000000000000000000000000000000000000010": 3.0,
    "swh:1:rev:0000000000000000000000000000000000000013": 3.0,
    "swh:1:snp:0000000000000000000000000000000000000020": 4.0,
    "swh:1:rev:0000000000000000000000000000000000000018": 4.0,
    "swh:1:ori:83404f995118bd25774f4ac14422a8f175e7a054": 5.0,
    "swh:1:rel:0000000000000000000000000000000000000019": 5.0,
    "swh:1:rel:0000000000000000000000000000000000000021": 5.0,
    "swh:1:snp:0000000000000000000000000000000000000022": 7.0,
    "swh:1:ori:8f50d3f60eae370ddbf85c86219c55108a350165": 8.0,
}

DESCENDANT_COUNTS_HISTHOST_BACKWARD = {
    "swh:1:ori:83404f995118bd25774f4ac14422a8f175e7a054": 1.0,
    "swh:1:ori:8f50d3f60eae370ddbf85c86219c55108a350165": 1.0,
    "swh:1:rel:0000000000000000000000000000000000000019": 1.0,
    "swh:1:snp:0000000000000000000000000000000000000020": 2.0,
    "swh:1:snp:0000000000000000000000000000000000000022": 2.0,
    "swh:1:rel:0000000000000000000000000000000000000021": 3.0,
    "swh:1:rel:0000000000000000000000000000000000000010": 5.0,
    "swh:1:rev:0000000000000000000000000000000000000018": 5.0,
    "swh:1:rev:0000000000000000000000000000000000000013": 6.0,
    "swh:1:rev:0000000000000000000000000000000000000009": 10.0,
    "swh:1:rev:0000000000000000000000000000000000000003": 11.0,
}


DESCENDANT_COUNTS_ALL_FORWARD = {
    "swh:1:cnt:0000000000000000000000000000000000000001": 1.0,
    "swh:1:cnt:0000000000000000000000000000000000000004": 1.0,
    "swh:1:cnt:0000000000000000000000000000000000000005": 1.0,
    "swh:1:cnt:0000000000000000000000000000000000000007": 1.0,
    "swh:1:cnt:0000000000000000000000000000000000000011": 1.0,
    "swh:1:cnt:0000000000000000000000000000000000000014": 1.0,
    "swh:1:cnt:0000000000000000000000000000000000000015": 1.0,
    "swh:1:dir:0000000000000000000000000000000000000002": 2.0,
    "swh:1:dir:0000000000000000000000000000000000000006": 3.0,
    "swh:1:dir:0000000000000000000000000000000000000008": 6.0,
    "swh:1:dir:0000000000000000000000000000000000000012": 8.0,
    "swh:1:dir:0000000000000000000000000000000000000016": 2.0,
    "swh:1:dir:0000000000000000000000000000000000000017": 4.0,
    "swh:1:rev:0000000000000000000000000000000000000003": 3.0,
    "swh:1:rev:0000000000000000000000000000000000000009": 9.0,
    "swh:1:rel:0000000000000000000000000000000000000010": 10.0,
    "swh:1:rev:0000000000000000000000000000000000000013": 12.0,
    "swh:1:snp:0000000000000000000000000000000000000020": 11.0,
    "swh:1:rev:0000000000000000000000000000000000000018": 17.0,
    "swh:1:ori:83404f995118bd25774f4ac14422a8f175e7a054": 12.0,
    "swh:1:rel:0000000000000000000000000000000000000019": 18.0,
    "swh:1:rel:0000000000000000000000000000000000000021": 18.0,
    "swh:1:snp:0000000000000000000000000000000000000022": 20.0,
    "swh:1:ori:8f50d3f60eae370ddbf85c86219c55108a350165": 21.0,
}

DESCENDANT_COUNTS_ALL_BACKWARD = {
    "swh:1:ori:83404f995118bd25774f4ac14422a8f175e7a054": 1.0,
    "swh:1:ori:8f50d3f60eae370ddbf85c86219c55108a350165": 1.0,
    "swh:1:rel:0000000000000000000000000000000000000019": 1.0,
    "swh:1:snp:0000000000000000000000000000000000000020": 2.0,
    "swh:1:snp:0000000000000000000000000000000000000022": 2.0,
    "swh:1:rel:0000000000000000000000000000000000000021": 3.0,
    "swh:1:rel:0000000000000000000000000000000000000010": 5.0,
    "swh:1:rev:0000000000000000000000000000000000000018": 5.0,
    "swh:1:dir:0000000000000000000000000000000000000017": 6.0,
    "swh:1:rev:0000000000000000000000000000000000000013": 6.0,
    "swh:1:cnt:0000000000000000000000000000000000000014": 7.0,
    "swh:1:dir:0000000000000000000000000000000000000012": 7.0,
    "swh:1:dir:0000000000000000000000000000000000000016": 7.0,
    "swh:1:cnt:0000000000000000000000000000000000000011": 8.0,
    "swh:1:cnt:0000000000000000000000000000000000000015": 8.0,
    "swh:1:rev:0000000000000000000000000000000000000009": 10.0,
    "swh:1:rev:0000000000000000000000000000000000000003": 11.0,
    "swh:1:dir:0000000000000000000000000000000000000002": 12.0,
    "swh:1:dir:0000000000000000000000000000000000000008": 12.0,
    "swh:1:cnt:0000000000000000000000000000000000000007": 13.0,
    "swh:1:dir:0000000000000000000000000000000000000006": 13.0,
    "swh:1:cnt:0000000000000000000000000000000000000004": 14.0,
    "swh:1:cnt:0000000000000000000000000000000000000005": 14.0,
    "swh:1:cnt:0000000000000000000000000000000000000001": 15.0,
}

DESCENDANT_COUNTS = {
    "rev,rel,snp,ori": {
        "backward": DESCENDANT_COUNTS_HISTHOST_BACKWARD,
        "forward": DESCENDANT_COUNTS_HISTHOST_FORWARD,
    },
    "cnt,dir,rev,rel,snp,ori": {
        "backward": DESCENDANT_COUNTS_ALL_BACKWARD,
        "forward": DESCENDANT_COUNTS_ALL_FORWARD,
    },
}


@pytest.mark.parametrize(
    "direction,object_types,rsd",
    itertools.product(
        ["backward", "forward"],
        ["rev,rel,snp,ori", "cnt,dir,rev,rel,snp,ori"],
        [0.1, 0.2],
    ),
)
def test_countdescendants(tmpdir, direction: str, object_types: str, rsd: float):
    tmpdir = Path(tmpdir)

    gen_task = ComputeGenerations(
        local_graph_path=DATASET_DIR / "compressed",
        topology_dir=tmpdir,
        direction=inverse_direction(direction),
        object_types=object_types.removeprefix("cnt,"),
        graph_name="example",
    )
    gen_task.run()

    task = CountDescendants(
        local_graph_path=DATASET_DIR / "compressed",
        topology_dir=tmpdir,
        direction=direction,
        object_types=object_types,
        graph_name="example",
        rsd=rsd,
        seed=0,  # make the output deterministic
    )
    task.run()

    parquet_path = (
        tmpdir / f"descendant_counts_{direction}_{object_types}_rsd={rsd}/parquet"
    )
    assert parquet_path.exists()

    # Check parquet values
    df = read_parquet(
        parquet_path,
        "descendant_counts",
        "SELECT swhid, descendants FROM descendant_counts ORDER BY swhid",
    )

    actual = {}
    for batch in df.collect():
        for swhid, desc in zip(
            batch.column("swhid").to_pylist(), batch.column("descendants").to_pylist()
        ):
            actual[swhid] = desc

    expected = DESCENDANT_COUNTS[object_types][direction]
    assert set(actual.keys()) == set(expected.keys())
    for swhid, expected_count in expected.items():
        # this checks the counter is within the configured standard deviation from the
        # actual count; which has a 35% probability of being wrong.
        # But the code uses a rapidhash which has a constant seed, so this test is not actually
        # flaky.
        assert actual[swhid] == pytest.approx(
            expected_count, rel=expected_count * rsd * 1
        ), swhid

    df = read_parquet(
        parquet_path,
        "descendant_counts2",
        "SELECT node, descendants FROM descendant_counts2 ORDER BY node",
    )

    num_nodes = 24
    expected_arr = [NaN()] * num_nodes
    for batch in df.collect():
        for row in batch.to_pylist():
            expected_arr[row["node"]] = row["descendants"]

    array_path = (
        tmpdir
        / f"descendant_counts_{direction}_{object_types}_rsd={rsd}/descendants.bin"
    )
    raw = array_path.read_bytes()
    n = len(raw) // 8
    array = list(struct.unpack(f">{n}d", raw))

    assert array == expected_arr


class NaN:
    """Equals NaN and only NaN."""

    def __eq__(self, other):
        return math.isnan(other)
