# DMCP Setu

**Effortless Conversational Access to Dview MCP from Your Terminal**

DMCP Setu is a lightweight, terminal-first Python CLI tool that enables real-time interaction with Dview’s MCP (Message Control Plane). It abstracts authentication, WebSocket handling, and streaming so you can focus purely on communication.

> ⚡ Built for developers who prefer speed, simplicity, and the terminal.

---

## 🚀 Overview

DMCP Setu allows you to:

* Authenticate with Dview services
* Establish real-time WebSocket communication
* Send and receive messages interactively
* Stream live responses directly in your terminal

⚠️ This is a **CLI utility**, not a Python SDK.

---

## ✨ Features

* 🔐 **Flexible Authentication**

  * Email & Password
  * Cookie-based (`token=Bearer xxxx`)

* 🌐 **Real-Time Messaging**

  * WebSocket-based communication
  * Live streaming responses

* 💬 **Interactive CLI**

  * Chat-like interface
  * Built with Rich for clean output

* ⚙️ **Configurable**

  * Environment variable support
  * Custom endpoint support

---

## 📦 Installation

### Using pip

```bash
pip install dmcp-setu
```

### Using poetry

```bash
poetry add dmcp-setu
```

---

## ⚙️ Configuration

You must configure the Cosmos endpoint before using the CLI.

### Environment Variable (Recommended)

```bash
export DVIEW_COSMOS_ENDPOINT="https://<your-cosmos-endpoint>"
```

### Or via CLI

```bash
dmcp chat --cosmos <endpoint>
```

---

## 🔐 Authentication

### 1. Email & Password

```bash
dmcp chat --email <email> --password <password>
```

Or interactive mode:

```bash
dmcp chat
```

---

### 2. Cookie-Based Authentication

```bash
dmcp chat --cookie "token=Bearer xxxx"
```

Or via environment variable:

```bash
export DMCP_COOKIE="token=Bearer xxxx"
```

---

## 💬 Usage

Start the CLI:

```bash
dmcp chat
```

### Example

```text
you  ▶ Hello

⋯ Processing...

dmcp ▶ Hi! How can I help you today?
```

---

### Exit

* Type `exit` or `quit`
* Press `Ctrl + C`

---

## 🧠 How It Works

1. Credentials are validated via Cosmos API
2. WebSocket connection is established
3. Authentication token is sent
4. Server responds with `auth_ok`
5. Interactive chat session begins

---

## 🌍 Environment Variables

| Variable              | Description                    |
| --------------------- | ------------------------------ |
| DVIEW_COSMOS_ENDPOINT | Cosmos API endpoint (required) |
| DMCP_EMAIL            | Email for authentication       |
| DMCP_PASSWORD         | Password for authentication    |
| DMCP_COOKIE           | Cookie for authentication      |
| DMCP_WS_URL           | Override WebSocket URL         |

---

## 🛠 Error Handling

User-friendly CLI errors:

* ❌ Authentication Failed
* ❌ Missing Values
* ❌ Connection Error
* ❌ Unexpected Error

All internal exceptions are abstracted.

---

## 🎯 Use Cases

* Internal Dview tooling
* MCP debugging
* Workflow testing
* CLI-based automation

---

## ⚠️ Important Notes

* This is a **CLI-only tool**
* Internal classes like `_DMCP` are **not public APIs**
* Direct imports may break in future versions

---

## 🧾 Best Practices

* Use environment variables for credentials
* Prefer cookie-based auth for persistent sessions
* Avoid relying on internal modules

---

## 🔗 Repository

GitHub: [https://github.com/dview-io/dmcp-setu](https://github.com/dview-io/dmcp-setu)

---

## 📄 License

MIT License

---
