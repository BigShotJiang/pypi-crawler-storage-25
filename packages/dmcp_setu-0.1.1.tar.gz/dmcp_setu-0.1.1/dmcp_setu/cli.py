import getpass
import os
import sys

import click
from rich.align import Align
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text
from rich.text import Text as RText
from dmcp_setu.core.client.dmcp import _DMCP
from dmcp_setu.core.exceptions import (
    DmcpAuthenticationException,
    DmcpConnectionException,
    DmcpValueError,
)
from dmcp_setu.core.utils.dsense_renderer import _PhaseRenderer

console = Console()
renderer = _PhaseRenderer(console)


@click.group()
def main():
    """DMCP Setu — talk to dmcp.dview.io from your terminal."""


def print_error(title: str, error: Exception):
    message = getattr(error, "detail", str(error))
    console.print(f"\n[bold red]✖ {title}[/bold red]")
    console.print(f"[red]{message}[/red]\n")


def show_welcome():
    logo = Text(r"""
▗▄▄▄  ▗▖  ▗▖ ▗▄▄▖▗▄▄▖      ▗▄▄▖▗▄▄▄▖▗▄▄▄▖▗▖ ▗▖
▐▌  █ ▐▛▚▞▜▌▐▌   ▐▌ ▐▌    ▐▌   ▐▌     █  ▐▌ ▐▌
▐▌  █ ▐▌  ▐▌▐▌   ▐▛▀▘      ▝▀▚▖▐▛▀▀▘  █  ▐▌ ▐▌
▐▙▄▄▀ ▐▌  ▐▌▝▚▄▄▖▐▌       ▗▄▄▞▘▐▙▄▄▖  █  ▝▚▄▞▘

------------------------------------------""", style="bold magenta")
    sloka = Text(f"    The Bridge That Carries Knowledge", style="bold bright_yellow")

    divider = Text("------------------------------------------", style="bold magenta")
    info = RText.from_markup(
        "[bold]Welcome to DMCP Setu CLI[/bold]\n\n"
        "[cyan]Authenticate using:[/cyan]\n"
        " • Email & Password\n"
        " • Cookie (token=Bearer xxxx)\n\n"
        "[cyan]Options:[/cyan]\n"
        " --email      Your email\n"
        " --password   Your password\n"
        " --cookie     Auth cookie\n"
        " --cosmos     Cosmos DB endpoint\n\n"
        "[light_yellow3]Type 'exit' or Ctrl+C to quit.[/light_yellow3]"
    )

    panel = Panel(
        Align.center(info),
        title="[bold green]DMCP SETU[/bold green]",
        border_style="green",
        padding=(1, 4)
    )

    console.print(logo)
    console.print(sloka)
    console.print(divider)
    console.print()
    console.print(panel, justify="left")
    console.print()


def on_message(event: dict):
    """Handle a server event and print it to the console."""
    etype = event.get("type", "")

    if etype == "progress":
        msg = event.get("message") or "Processing..."
        console.print(f"[dim cyan]  ⋯ {msg}[/dim cyan]")

    elif etype == "tool_progress":
        msg = (event.get("data") or {}).get("message")
        with open("output_9.txt", "a", encoding="utf-8") as f:
            f.write(msg + "\n")
        renderer.handle_chunk(msg)

    elif etype == "notification":
        msg = event.get("message") or ""
        console.print(f"[bold cyan]🔔 {msg}[/bold cyan]")

    elif etype == "interrupt":
        msg = event.get("message") or ""
        console.print(f"\n[bold yellow]⚠ {msg}[/bold yellow]")

    elif etype == "assistant":
        renderer.reset()
        msg = event.get("message") or ""
        console.print(f"\n[bold green]dmcp ▶[/bold green]")
        console.print(Markdown(msg.strip()))

    else:
        msg = event.get("message") or str(event)
        console.print(f"[dim]dmcp ▶[/dim] {msg}")


@main.command()
@click.option("--email", default=None, help="Email address for authentication.")
@click.option("--password", default=None, hide_input=True,
              help="Password for authentication (prompted if not provided).")
@click.option("--cookie", default=None, help="Raw cookie string: 'token=Bearer xxxxx'")
@click.option("--cosmos", default=None, envvar="DVIEW_COSMOS_ENDPOINT")
@click.pass_context
def chat(ctx, email, password, cookie, cosmos):
    show_welcome()
    if not os.environ.get("DVIEW_COSMOS_ENDPOINT") and not cosmos:
        click.echo(
            "Error: Cosmos DB endpoint is not configured.\n"
            "Set the DVIEW_COSMOS_ENDPOINT environment variable or pass --cosmos <endpoint>.\n\n"
            "Run with --help for usage details.",
            err=True,
        )
        ctx.exit(1)

    email = email or os.getenv("DMCP_EMAIL")
    password = password or os.getenv("DMCP_PASSWORD")
    cookie = cookie or os.getenv("DMCP_COOKIE")

    if not email and not password and not cookie:
        auth_type = click.prompt(
            "Authentication type",
            type=click.Choice(["email", "cookie"], case_sensitive=False),
            default="email"
        )
        if auth_type == "cookie":
            cookie = click.prompt("Cookie (e.g. 'token=Bearer xxxxx')")
        else:
            email = click.prompt("Email")
            password = getpass.getpass("Password: ")

    use_cookie = bool(cookie)
    if email and password:
        use_cookie = False
    elif not cookie:
        if not email:
            email = click.prompt("Email")
        if not password:
            password = getpass.getpass("Password: ")
        use_cookie = False

    try:
        client = _DMCP(
            cosmos_endpoint=cosmos,
            email=email,
            password=password,
            cookie=cookie if use_cookie else None,
        )

        with console.status("Authenticating..."):
            verified_email = client.authenticate()
        console.print(f"[green]✓ Authenticated as {verified_email}[/green]\n")
        console.print("[cyan]Connected to Dview's MCP Server — type messages, Ctrl+C to quit.[/cyan]\n")

        client.chat(on_message=on_message)

        console.print("\n[dark_orange]✓ Thank you for using dmcp-setu. See you soon![/dark_orange]")

    except DmcpAuthenticationException as e:
        print_error("Authentication Failed", e)
        sys.exit(1)

    except DmcpValueError as e:
        print_error("Missing Values", e)
        sys.exit(1)

    except DmcpConnectionException as e:
        print_error("Connection Error", e)
        sys.exit(1)

    except Exception as e:
        print_error("Unexpected Error", e)
        sys.exit(1)
