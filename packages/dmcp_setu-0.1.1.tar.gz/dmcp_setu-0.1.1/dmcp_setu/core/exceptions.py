from typing import Any


class DmcpException(Exception):
    """Base exception for all Dmcp-related errors."""

    def __init__(self, error_type: Any, name: Any, detail: Any, module_code: int = 0x00):
        self.type = error_type
        self.name = name
        self.detail = detail
        self.module_code = module_code

    def __str__(self):
        return f"(Error Module Code: {self.module_code:02x}, Type: {self.type}, Name:{self.name}, Detail: {self.detail})"


class DmcpConnectionException(DmcpException):
    """Connection errors (e.g., failure to connect to Trino)."""
    module_code = 0x01

    def __init__(self, error_type: Any, name: Any, detail: Any):
        super().__init__(error_type, name, detail, self.module_code)


class DmcpValueError(DmcpException):
    """Value errors such as missing or invalid parameters."""
    module_code = 0x02

    def __init__(self, error_type: Any, name: Any, detail: Any):
        super().__init__(error_type, name, detail, self.module_code)


class DmcpAuthenticationException(DmcpException):
    """Errors related to authentication failures."""
    module_code = 0x05

    def __init__(self, error_type: Any, name: Any, detail: Any):
        super().__init__(error_type, name, detail, self.module_code)


