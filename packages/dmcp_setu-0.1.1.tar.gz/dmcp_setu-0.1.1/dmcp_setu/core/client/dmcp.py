import json
import os
import inspect
import websockets.sync.client as ws_sync
from dmcp_setu.core.client.cosmos_client import _CosmosClient
from dmcp_setu.core.exceptions import (
    DmcpAuthenticationException,
    DmcpConnectionException,
    DmcpValueError,
)

_WS_URL = os.getenv("DMCP_WS_URL", "ws://0.0.0.0:8002")


class _DMCP:

    def __init__(
        self,
        cosmos_endpoint: str = None,
        email: str = None,
        password: str = None,
        cookie: str | None = None,
    ):
        caller = inspect.stack()[1].filename
        if "cli.py" not in caller:
            raise RuntimeError("_DMCP is internal and can only be used from cli.py.")

        self._cosmos = _CosmosClient(cosmos_endpoint=cosmos_endpoint)
        self._email = email
        self._password = password
        self._cookie = cookie
        self._token: str | None = None

    def authenticate(self) -> str:
        if self._cookie:
            cookies = dict(
                pair.strip().split("=", 1)
                for pair in self._cookie.split(";")
                if "=" in pair
            )
            verified_email, jar = self._cosmos.authenticate_with_cookie(cookies)
        elif self._email and self._password:
            verified_email, jar = self._cosmos.authenticate_with_email_password(
                self._email, self._password
            )
        else:
            raise DmcpValueError(
                error_type="CONFIGURATION_ERROR",
                name="MISSING_CREDENTIALS",
                detail=(
                    "Provide email+password or cookies either as constructor args "
                    "or via DMCP_EMAIL/DMCP_PASSWORD or DMCP_COOKIE env vars."
                ),
            )

        self._token = next(
            (f"{name}={value}" for name, value in jar.items() if name == "token"),
            None,
        )
        if not self._token:
            raise DmcpAuthenticationException(
                error_type="AUTHENTICATION_ERROR",
                name="TOKEN_MISSING",
                detail="Authentication failed: No 'token' cookie found in server response."
            )

        return verified_email

    def chat(self, on_message: callable) -> None:
        if not self._token:
            raise DmcpAuthenticationException(error_type="AUTHENTICATION_ERROR",
                                              name="WS_AUTH_REJECTED",
                                              detail="Call authenticate() before chat().")

        try:
            endpoint = f"{_WS_URL}/ws/chat"
            with ws_sync.connect(endpoint) as ws:
                ws.send(json.dumps({"type": "auth", "token": self._token}))
                ack = json.loads(ws.recv())
                if ack.get("type") != "auth_ok":
                    raise DmcpAuthenticationException(
                        error_type="AUTHENTICATION_ERROR",
                        name="WS_AUTH_REJECTED",
                        detail=f"WebSocket authentication rejected by server: {ack}"
                    )

                while True:
                    try:
                        text = input("\033[1;34myou  ▶\033[0m ")
                    except (EOFError, KeyboardInterrupt):
                        break

                    text = text.strip()
                    if not text:
                        continue
                    if text.lower() in ("exit", "quit"):
                        break

                    ws.send(json.dumps({"message": text}))

                    while True:
                        event = json.loads(ws.recv())
                        on_message(event)
                        if event.get("type") == "assistant":
                            break

                        elif event.get("type") == "interrupt":
                            try:
                                reply = input("\033[1;35myou  ▶\033[0m ")
                            except (EOFError, KeyboardInterrupt):
                                break
                            ws.send(json.dumps({"message": reply.strip()}))

        except (DmcpAuthenticationException, DmcpConnectionException):
            raise
        except OSError as e:
            raise DmcpConnectionException(
                error_type="CONNECTION_ERROR",
                name="WS_CONNECTION_FAILED",
                detail=f"Unable to connect to DMCP server: {e}",
            )
        except Exception as e:
            raise DmcpConnectionException(
                error_type="UNKNOWN_ERROR",
                name="CHAT_FAILURE",
                detail=str(e),
            )
