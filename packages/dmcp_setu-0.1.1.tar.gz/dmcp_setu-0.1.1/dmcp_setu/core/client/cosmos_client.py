import os

import requests
from requests.cookies import RequestsCookieJar

from dmcp_setu.core.exceptions import DmcpValueError, \
    DmcpAuthenticationException
from dmcp_setu.core.models.constants import CosmosAuthEndpoint


class _CosmosClient:
    """
    This class represents a client that interacts with Cosmos API for authentication

    Attributes:
        _endpoint (str): Dfiber Cosmos API endpoint.
    """

    def __init__(self, cosmos_endpoint: str = None):
        """
        Initialize _CosmosClient with Dfiber Cosmos API endpoint.

        Args:
            cosmos_endpoint(str): Dfiber Cosmos API endpoint

        Raises:
            DfiberValueError: If DVIEW_COSMOS_ENDPOINT environment variable is not set.
        """
        if cosmos_endpoint:
            self._endpoint = cosmos_endpoint
        else:
            self._endpoint = os.getenv('DVIEW_COSMOS_ENDPOINT')
            if not self._endpoint:
                raise DmcpValueError(error_type="CONFIGURATION_ERROR",
                                     name="MISSING_ENDPOINT",
                                     detail="Either the DVIEW_COSMOS_ENDPOINT environment variable must be set, or 'cosmos_endpoint' must be passed during initialization."
                                     )
        self._endpoint = self._endpoint.rstrip('/') + "/api/v1/orchestrator"

    def authenticate_with_email_password(self, email: str, password: str):
        """
        Authenticate with email and password.

        Args:
            email (string): The email used to authenticate with Dfiber.
            password (string):  The password associated with the Dfiber account.

        Returns:
            string: email, cookies.

        Raises:
            DfiberAuthenticationException: If the authentication fails.
        """
        response = requests.post(
            f"{self._endpoint}{CosmosAuthEndpoint.AUTH_ENDPOINT_EMAIL_LOGIN}",
            json={"email": email, "pass": password})
        if response.status_code == 200:
            return self.authenticate_with_cookie(response.cookies)
        else:
            raise DmcpAuthenticationException(
                error_type='USER_AUTHENTICATION_FAILED',
                name='DFIBER_EMAIL_PASSWORD_AUTH_FAILED',
                detail=f"Failed to authenticate with email-password-based authentication: {response.text}")

    def authenticate_with_cookie(self, cookies: dict | RequestsCookieJar):
        """
        Authenticate with cookie.

        Args:
            cookies (dict/RequestsCookieJar): The cookies used to authenticate with Dfiber.

        Returns:
            string: email, cookies.

        Raises:
            DfiberAuthenticationException: If the authentication fails.
        """
        response = requests.get(
            f"{self._endpoint}{CosmosAuthEndpoint.AUTH_ENDPOINT_COOKIE}",
            cookies=cookies)
        if response.status_code == 200:
            email = response.json().get('email')
            return email, cookies
        else:
            raise DmcpAuthenticationException(
                error_type='USER_AUTHENTICATION_FAILED',
                name='DFIBER_COOKIE_AUTH_FAILED',
                detail=f"Failed to authenticate with cookie-based authentication: {response.text}")
