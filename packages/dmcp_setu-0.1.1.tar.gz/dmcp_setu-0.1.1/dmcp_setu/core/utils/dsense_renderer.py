import re
import html
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.rule import Rule
from rich.syntax import Syntax
from rich.text import Text

PHASES = {
    "USER_PROMPT_VALIDATION",
    "BASIC_SQL_GENERATION",
    "SQL_GENERATION_RETRY",
    "PANDAS_CODE_GENERATION",
    "PANDAS_CODE_RETRY",
    "RESULT_ANALYSIS",
}

PHASE_LABELS = {
    "USER_PROMPT_VALIDATION": ("\U0001f50d", "Validating Prompt", "cyan"),
    "BASIC_SQL_GENERATION": ("\U0001f6e0 ", "Generating SQL", "yellow"),
    "SQL_GENERATION_RETRY": ("\U0001f504", "Retrying SQL", "dark_orange"),
    "PANDAS_CODE_GENERATION": ("\U0001f43c", "Generating Analysis Code", "magenta"),
    "PANDAS_CODE_RETRY": ("\U0001f504", "Retrying Pandas Code", "dark_orange"),
    "RESULT_ANALYSIS": ("\U0001f4ca", "Analysing Results", "green"),
}

ERROR_OPEN = "<" + "error" + ">"
ERROR_CLOSE = "</" + "error" + ">"


def _fix_markdown_newlines(text: str) -> str:
    if not text:
        return ""

    text = text.replace('\t', ' ')

    # 2. ### and ## headers always on their own line
    text = re.sub(r'(?<!\n)(#{2,} )', r'\n\n\1', text)

    text = re.sub(r'(?<!\n)(- \*\*)', r'\n\1', text)
    text = re.sub(r'(?<!\n)(- [A-Z])', r'\n\1', text)
    text = re.sub(r'(?<!\n)(\*\*\d+\. [A-Z])', r'\n\n\1', text)

    text = re.sub(r'\n{3,}', '\n\n', text)

    return text.strip()


def _clean_token(raw: str):
    return html.unescape(raw)


class _PhaseRenderer:

    def __init__(self, console=None):
        self._console = console or Console(width=None, highlight=False)
        self._reset_state()

    def handle_chunk(self, raw: str) -> None:
        if not raw:
            return
        raw = _clean_token(raw)

        if self.current_phase == "USER_PROMPT_VALIDATION" and ERROR_OPEN in raw and ERROR_CLOSE in raw:
            error_msg = self._extract_tag(raw, "error")
            if error_msg:
                self._console.print()
                self._console.print(
                    Panel(
                        Text(error_msg, style="bold white"),
                        title="[bold red]\u26a0  Error[/bold red]",
                        border_style="red",
                        padding=(1, 2),
                    )
                )
                self._console.print()
            return

        if "<sql_execution>" in raw and "</sql_execution>" in raw:
            block = self._extract_block(raw, "sql_execution")
            status = self._extract_tag(block, "status").upper()
            retry = self._extract_tag(block, "retry") or "0"
            max_retries = self._extract_tag(block, "max_retries") or "3"

            if status == "RUNNING":
                sql = self._extract_tag(block, "sql")
                expl = self._extract_tag(self._answer_buffer, "sql_explanation")
                business = self._extract_tag(self._answer_buffer, "business_context")
                pandas_needed = self._extract_bool(block, "is_pandas_needed")
                label = "Corrected SQL" if self.current_phase == "SQL_GENERATION_RETRY" else "Generated SQL"
                label_color = "dark_orange" if self.current_phase == "SQL_GENERATION_RETRY" else "yellow"

                if sql:
                    self._console.print(f"\n  [bold {label_color}]{label}[/bold {label_color}]")
                    self._console.print(
                        Syntax(sql, "sql", theme="monokai", word_wrap=True, line_numbers=True)
                    )
                    self._console.print()
                # if expl:
                #     self._print_info_panel(expl, "\U0001f4cb  SQL Explanation", label_color)
                # if business:
                #     self._print_info_panel(business, "\U0001f4bc  Business Context", "cyan")

                self._console.print(
                    f"  [bold cyan]\u23f3 SQL Executing\u2026[/bold cyan]"
                    f"  [dim](attempt {int(retry) + 1}/{max_retries})[/dim]"
                )
                if pandas_needed:
                    self._console.print("\n  [magenta]\u21b3 Pandas analysis will follow\u2026[/magenta]\n")

            elif status == "SUCCESS":
                self._console.print(
                    f"  [bold green]\u2714  SQL Execution Successful[/bold green]"
                    f"  [dim](attempt {int(retry) + 1}/{max_retries})[/dim]"
                )
            elif status in ("FAILED", "ERROR"):
                self._console.print(
                    f"  [bold red]\u2716  SQL Execution Failed[/bold red]"
                    f"  [dim](attempt {int(retry) + 1}/{max_retries})[/dim]"
                )
            return

        if "<pandas_execution>" in raw and "</pandas_execution>" in raw:
            block = self._extract_block(raw, "pandas_execution")
            status = self._extract_tag(block, "status").upper()
            retry = self._extract_tag(block, "retry") or "0"
            max_retries = self._extract_tag(block, "max_retries") or "3"

            if status == "RUNNING":
                # FIX 3: send_pandas_stream_response uses <pandas_code>, not <code>.
                code = self._extract_tag(block, "pandas_code")
                expl = self._extract_tag(self._answer_buffer, "pandas_explanation")
                business = self._extract_tag(self._answer_buffer, "business_context")
                label = "Corrected Pandas Code" if self.current_phase == "PANDAS_CODE_RETRY" else "Pandas Code"
                label_color = "dark_orange" if self.current_phase == "PANDAS_CODE_RETRY" else "magenta"

                if code:
                    self._console.print(f"\n  [bold {label_color}]{label}[/bold {label_color}]")
                    self._console.print(
                        Syntax(code, "python", theme="monokai", word_wrap=True, line_numbers=True)
                    )
                if expl:
                    self._print_info_panel(expl, "\U0001f4cb  Pandas Explanation", label_color)
                if business:
                    self._print_info_panel(business, "\U0001f4bc  Business Context", "cyan")

                self._console.print(
                    f"  [bold cyan]\u23f3 Pandas Executing\u2026[/bold cyan]"
                    f"  [dim](attempt {int(retry) + 1}/{max_retries})[/dim]"
                )
            elif status == "SUCCESS":
                self._console.print(
                    f"  [bold green]\u2714  Pandas Execution Successful[/bold green]"
                    f"  [dim](attempt {int(retry) + 1}/{max_retries})[/dim]"
                )
            elif status in ("FAILED", "ERROR"):
                self._console.print(
                    f"  [bold red]\u2716  Pandas Execution Failed[/bold red]"
                    f"  [dim](attempt {int(retry) + 1}/{max_retries})[/dim]"
                )
            return

        phase = self._extract_phase_tag(raw)
        if phase and phase in PHASES:
            self._finalize_current_phase()
            self.current_phase = phase
            self._reset_state(keep_phase=True)
            emoji, label, color = PHASE_LABELS[phase]
            self._console.print()
            self._console.print(Rule(
                f"[bold {color}]{emoji}  {label}[/bold {color}]",
                style=color,
            ))
            return

        self._buffer += raw

        if "<reasoning>" in raw and not self._in_reasoning and not self._reasoning_done:
            self._in_reasoning = True
            after = re.sub(r"<[^>]+>", "", raw.split("<reasoning>", 1)[1])
            if after:
                self._reasoning_text += after
            return

        if "</reasoning>" in raw and self._in_reasoning:
            before = re.sub(r"<[^>]+>", "", raw.split("</reasoning>", 1)[0])
            if before:
                self._reasoning_text += before
            self._in_reasoning = False
            self._reasoning_done = True
            self._flush_reasoning()
            return

        if self._in_reasoning:
            text = re.sub(r"<[^>]+>", "", raw)
            if text:
                self._reasoning_text += text
            return

        if "<answer>" in raw:
            self._in_answer = True

        if self._in_answer and "</root>" in self._buffer and not self._answer_rendered:
            self._answer_rendered = True
            self._answer_buffer = self._buffer
            self._render_answer()

    def reset(self) -> None:
        self._finalize_current_phase()
        self.current_phase = None
        self._reset_state()

    def _print_info_panel(self, text: str, title: str, border_color: str) -> None:
        self._console.print(
            Panel(
                Markdown(_fix_markdown_newlines(text)),
                title=f"[bold {border_color}]{title}[/bold {border_color}]",
                border_style=border_color,
                padding=(1, 2),
            )
        )
        self._console.print()

    def _extract_block(self, text: str, tag: str) -> str:
        m = re.search(rf"<{tag}>(.*?)</{tag}>", text, re.DOTALL)
        return m.group(1) if m else ""

    def _extract_tag(self, xml_str: str, tag: str) -> str:
        m = re.search(rf"<{tag}[^>]*>(.*?)</{tag}>", xml_str, re.DOTALL)
        if not m:
            return ""
        return m.group(1).strip()

    def _extract_bool(self, xml_str: str, tag: str) -> bool:
        return self._extract_tag(xml_str, tag).lower() == "true"

    def _extract_phase_tag(self, text: str) -> str | None:
        m = re.search(r"<phase>\s*([A-Z_]+)\s*</phase>", text)
        return m.group(1) if m else None

    # ── Reasoning ───────────────────────────────────────────────────────

    def _flush_reasoning(self) -> None:
        text = self._reasoning_text
        if not text:
            self._console.print("  [dim]\u2713 Reasoning complete (empty)[/dim]\n")
            self._reasoning_text = ""
            return
        self._console.print(
            Panel(
                Text(text, style="dim italic"),
                title="[dim]reasoning[/dim]",
                border_style="dim",
                padding=(0, 2),
            )
        )
        self._console.print()
        self._reasoning_text = ""

    def _reset_state(self, keep_phase: bool = False, keep_answer_buffer: bool = False) -> None:
        if not keep_phase:
            self.current_phase = None
        self._buffer = ""
        if not keep_answer_buffer:
            self._answer_buffer = ""
        self._in_reasoning = False
        self._reasoning_done = False
        self._in_answer = False
        self._answer_rendered = False
        self._reasoning_text = ""

    def _finalize_current_phase(self) -> None:
        if self._in_reasoning and self._reasoning_text:
            self._in_reasoning = False
            self._reasoning_done = True
            self._flush_reasoning()
        if self._in_answer and not self._answer_rendered and "</root>" in self._buffer:
            self._answer_rendered = True
            self._answer_buffer = self._buffer
            self._render_answer()

    def _render_answer(self) -> None:
        dispatch = {
            "USER_PROMPT_VALIDATION": self._render_validation,
            "BASIC_SQL_GENERATION": self._render_sql_answer,
            "SQL_GENERATION_RETRY": self._render_sql_answer,
            "PANDAS_CODE_GENERATION": self._render_pandas_answer,
            "PANDAS_CODE_RETRY": self._render_pandas_answer,
            "RESULT_ANALYSIS": self._render_result_analysis,
        }
        fn = dispatch.get(self.current_phase or "")
        if fn:
            fn(self._buffer)

    # ── Phase renderers ──────────────────────────────────────────────────

    def _render_sql_answer(self, xml: str) -> None:
        """Store explanation + business context in answer_buffer so they are
        available when the sql_execution RUNNING event arrives later."""
        expl = self._extract_tag(xml, "sql_explanation")
        business = self._extract_tag(xml, "business_context")
        label_color = "dark_orange" if self.current_phase == "SQL_GENERATION_RETRY" else "yellow"
        if expl:
            self._print_info_panel(expl, "📋  SQL Explanation", label_color)
        if business:
            self._print_info_panel(business, "💼  Business Context", "cyan")

    def _render_pandas_answer(self, xml: str) -> None:
        """Store explanation + business context in answer_buffer so they are
        available when the pandas_execution RUNNING event arrives later."""
        expl = self._extract_tag(xml, "pandas_explanation")
        business = self._extract_tag(xml, "business_context")
        label_color = "dark_orange" if self.current_phase == "PANDAS_CODE_RETRY" else "magenta"
        if expl:
            self._print_info_panel(expl, "📋  Pandas Explanation", label_color)
        if business:
            self._print_info_panel(business, "💼  Business Context", "cyan")

    def _render_validation(self, xml: str) -> None:
        rejected = self._extract_bool(xml, "rejected")
        message = self._extract_tag(xml, "message")
        self._console.print(
            "  [bold red]\u2716  Rejected[/bold red]" if rejected
            else "  [bold green]\u2714  Request accepted[/bold green]"
        )
        if message:
            self._console.print(f"  {message}\n")

    def _render_result_analysis(self, xml: str) -> None:
        ra = self._extract_tag(xml, "result_analysis")
        if ra:
            self._console.print()
            self._console.print(Markdown(_fix_markdown_newlines(ra)))
            self._console.print()
