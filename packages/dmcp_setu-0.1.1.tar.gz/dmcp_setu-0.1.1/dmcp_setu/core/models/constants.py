import enum


class CosmosAuthEndpoint(enum.StrEnum):
    AUTH_ENDPOINT_EMAIL_LOGIN = "/auth/email-login"
    AUTH_ENDPOINT_COOKIE = "/apollo/auth/login"
