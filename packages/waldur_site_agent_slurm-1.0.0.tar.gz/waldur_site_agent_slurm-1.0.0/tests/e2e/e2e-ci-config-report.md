
# E2E API Optimization Test Report

**Date:** 2026-03-19T22:24:08.926793+00:00
**Config:** `ci/e2e-ci-config.yaml`
**Waldur:** http://docker:8080/api/
**Backend:** SLURM emulator
**Offering:** e2ef0000000000000000000000000001
**Components:** cpu (factor=60000.0), ram (factor=61440.0)


## Benchmark: CREATE order processing

API calls: **27**
Order state: `done`

## Benchmark: UPDATE order processing

API calls: **10**
Order state: `done`

## Benchmark: TERMINATE order processing

API calls: **10**
Order state: `done`

## Benchmark: Membership sync

API calls: **10**

## Benchmark: Usage reporting

API calls: **13**

## Multi-resource benchmark: setup (5 resources)

Submitted **5** orders in 1.1s
Processed in **1** cycles, 27.4s
Created **5** / 5 resources successfully.

## Multi-resource benchmark: membership sync (5 resources)

Resources: **5**
API calls: **28** (per resource: 5.6)
Response bytes: **7096** (per resource: 1419)
Duration: **18.6s**

## Multi-resource benchmark: reporting (5 resources)

Resources: **5**
API calls: **33** (per resource: 6.6)
Response bytes: **7229** (per resource: 1446)
Duration: **7.0s**

## Multi-resource benchmark: cleanup

Terminated **5** / 5 resources.

## API Call Summary

| Test | API Calls | Response Size |
|------|-----------|---------------|
| TestBenchmarkOrderProcessing::test_01_create | 31 | 62.6 KB |
| TestBenchmarkOrderProcessing::test_02_update | 11 | 21.9 KB |
| TestBenchmarkOrderProcessing::test_03_terminate | 11 | 20.6 KB |
| TestBenchmarkMembershipSync::test_01_sync | 13 | 6.7 KB |
| TestBenchmarkReporting::test_01_setup_resource | 26 | 44.6 KB |
| TestBenchmarkReporting::test_02_report | 16 | 7.2 KB |
| TestMultiResourceBenchmark::test_01_create_resources | 98 | 169.7 KB |
| TestMultiResourceBenchmark::test_02_membership_sync | 31 | 9.7 KB |
| TestMultiResourceBenchmark::test_03_reporting | 36 | 9.9 KB |
| TestMultiResourceBenchmark::test_04_cleanup | 35 | 78.1 KB |
| **TOTAL** | **308** | **431.0 KB** |
