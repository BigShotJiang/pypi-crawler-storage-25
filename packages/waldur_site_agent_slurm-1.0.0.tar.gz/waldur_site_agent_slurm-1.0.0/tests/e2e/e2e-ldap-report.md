# LDAP E2E Test — Call Sequences

**Date:** 2026-03-19T22:25:43.172588+00:00
**Config:** ``
**Payloads:** [e2e-ldap-report-payloads.md](e2e-ldap-report-payloads.md)

## TestLdapWelcomeEmail::test_03_emails_contain_credentials

> Verify captured emails contain username, VPN password, and home directory.

*No external calls recorded (test skipped or pure assertion).*

## TestLdapWelcomeEmail::test_04_email_recipients_match_offering_users

> Verify email recipients match the user emails from offering users.

*No external calls recorded (test skipped or pure assertion).*

## TestLdapMembershipSync::test_03_username_format_verification

> Verify username format matches first_letter_full_lastname (x.lastname).

*No external calls recorded (test skipped or pure assertion).*
