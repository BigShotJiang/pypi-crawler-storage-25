
# E2E STOMP Test Report

**Date:** 2026-03-19T22:25:56.776686+00:00
**Config:** `ci/e2e-ci-config-stomp.yaml`
**Waldur:** http://docker:8080/api/
**Backend:** SLURM emulator
**Offering:** e2ef0000000000000000000000000001


## Test 01: STOMP Connections Establish


**Consumer: order:**

| Field | Value |
|-------|-------|
| offering | `E2E SLURM STOMP` |
| connected | `True` |
| subscription_uuid | `40a357933ac242ea94b9d6ac278fd559` |


**Consumer: user_role:**

| Field | Value |
|-------|-------|
| offering | `E2E SLURM STOMP` |
| connected | `True` |
| subscription_uuid | `daf03994d68e4c3cb4160ce9d37fcf92` |


**Consumer: resource:**

| Field | Value |
|-------|-------|
| offering | `E2E SLURM STOMP` |
| connected | `True` |
| subscription_uuid | `f8714ca287ed4dc6a92c3181f1d3c3c6` |


**Consumer: service_account:**

| Field | Value |
|-------|-------|
| offering | `E2E SLURM STOMP` |
| connected | `True` |
| subscription_uuid | `fcb29019147b4c25be8145400456d13e` |


**Consumer: course_account:**

| Field | Value |
|-------|-------|
| offering | `E2E SLURM STOMP` |
| connected | `True` |
| subscription_uuid | `9eea0fa5a6d94869b5f0f799122919fa` |


**Consumer: offering_user:**

| Field | Value |
|-------|-------|
| offering | `E2E SLURM STOMP` |
| connected | `True` |
| subscription_uuid | `fd8ac3b28b8643258ea59e11650e8b67` |


**Connected:** 6/6


## Test 02: STOMP Order Event Received


**Setup API calls:**

| Method | URL | Status | Bytes |
|--------|-----|--------|-------|
| GET | `/api/marketplace-public-offerings/e2ef0000000000000000000000000001/` | 200 | 3.7 KB |
| GET | `/api/projects/e2eb0000000000000000000000000001/` | 200 | 1.2 KB |

**Created order:** `b590c56ecb5249418fa1b1fae0b9cb10`


**Order creation API calls:**

| Method | URL | Status | Bytes |
|--------|-----|--------|-------|
| POST | `/api/marketplace-orders/` | 201 | 2.4 KB |


**Received ORDER event:**

| Field | Value |
|-------|-------|
| order_uuid | `b590c56ecb5249418fa1b1fae0b9cb10` |
| order_state | `pending-consumer` |


## Test 03: STOMP-Driven Order Processing


**Final order state:** `done`


**Created resource:**

| Field | Value |
|-------|-------|
| uuid | `47f7730c40bb4505a5bf3362307a967e` |
| name | `stomp-event-test` |
| state | `OK` |
| backend_id | `e2e_alloc_stomp-even` |
| limits | `{'cpu': 100, 'ram': 200}` |
| offering | `E2E SLURM Usage` |
| project | `E2E Test Project` |


**API calls:**

| Method | URL | Status | Bytes |
|--------|-----|--------|-------|
| GET | `/api/marketplace-orders/b590c56ecb5249418fa1b1fae0b9cb10/` | 200 | 3.0 KB |
| GET | `/api/marketplace-orders/b590c56ecb5249418fa1b1fae0b9cb10/` | 200 | 3.1 KB |
| GET | `/api/marketplace-orders/b590c56ecb5249418fa1b1fae0b9cb10/` | 200 | 3.1 KB |
| GET | `/api/marketplace-orders/b590c56ecb5249418fa1b1fae0b9cb10/` | 200 | 3.1 KB |
| GET | `/api/marketplace-provider-resources/47f7730c40bb4505a5bf3362307a967e/` | 200 | 6.6 KB |


## Test 04: Cleanup

**Terminate order:** `12fda8db021a40579cbd8e3aa15e5c21`

**Terminate final state:** `done`


## API Call Summary

| Test | API Calls | Response Size |
|------|-----------|---------------|
| **TOTAL** | **13** | **44.1 KB** |
