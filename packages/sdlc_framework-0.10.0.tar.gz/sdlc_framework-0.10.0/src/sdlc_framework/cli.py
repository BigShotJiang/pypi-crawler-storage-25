"""sdlc — CLI entry point."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from importlib import resources
from pathlib import Path

from sdlc_framework import __version__


def _cmd_scan(argv: list[str]) -> int:
    from sdlc_framework import engine
    parser = argparse.ArgumentParser(prog="sdlc scan")
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--interval", type=float, default=3.0)
    parser.add_argument("--print", dest="print_summary", action="store_true")
    parser.add_argument("--root", type=Path, default=None)
    args = parser.parse_args(argv)

    engine.set_root(args.root or Path(os.environ.get("SDLC_LOG_ROOT") or os.getcwd()))
    sys_argv = ["engine"]
    if args.watch: sys_argv.append("--watch")
    if args.print_summary: sys_argv.append("--print")
    sys_argv += ["--interval", str(args.interval)]
    # The engine.main() reads sys.argv; replace temporarily.
    saved = sys.argv
    try:
        sys.argv = sys_argv
        return engine.main()
    finally:
        sys.argv = saved


def _cmd_dispatch(argv: list[str]) -> int:
    from sdlc_framework import dispatcher
    return dispatcher.main(argv)


COMMANDS = {
    "scan": _cmd_scan,
    "dispatch": _cmd_dispatch,
}


def _run_bundled_script(script_name: str, args: list[str]) -> int:
    """Locate a bundled bash script and exec it with args; cwd = user's project.

    Sets SDLC_LOG_ROOT=$PWD so the bash scripts (which otherwise resolve ROOT
    relative to the script's own location) operate against the user's repo
    instead of the installed package directory.
    """
    pkg_files = resources.files("sdlc_framework").joinpath("scripts")
    script_path = pkg_files / script_name
    # importlib.resources may return a MultiplexedPath / Traversable; convert
    # to a real filesystem path via as_file().
    with resources.as_file(script_path) as real_path:
        env = os.environ.copy()
        env.setdefault("SDLC_LOG_ROOT", os.getcwd())
        cmd = ["bash", str(real_path), *args]
        return subprocess.run(cmd, env=env).returncode


def _cmd_agent_log(argv: list[str]) -> int:
    return _run_bundled_script("agent-log.sh", argv)


def _cmd_notify(argv: list[str]) -> int:
    return _run_bundled_script("notify.sh", argv)


def _cmd_gh_issue(argv: list[str]) -> int:
    return _run_bundled_script("gh-issue.sh", argv)


def _cmd_gh_pr(argv: list[str]) -> int:
    return _run_bundled_script("gh-pr.sh", argv)


def _cmd_build_ai_configs(argv: list[str]) -> int:
    return _run_bundled_script("build-ai-configs.sh", argv)


_STACK_DETECTORS: list[tuple[str, str]] = [
    ("node", "package.json"),
    ("python", "pyproject.toml"),
    ("python", "requirements.txt"),
    ("python", "setup.py"),
    ("go", "go.mod"),
]


# Per-tool artifacts: (tool name, list of (relative-source, relative-dest, optional dir-only))
# dest is relative to project root; source is relative to the bundled scaffold/ tree.
_TOOL_ARTIFACTS: dict[str, list[tuple[str, str]]] = {
    "claude-code": [
        # Subagents (already in scaffold/.claude/agents/) + slash commands + skill
        (".claude/agents", ".claude/agents"),
        (".claude/commands", ".claude/commands"),
        (".claude/skills", ".claude/skills"),
        # Claude Code also reads CLAUDE.md from project root.
        ("ai-tools/claude/CLAUDE.md", "CLAUDE.md"),
    ],
    "cursor": [
        (".cursor/rules", ".cursor/rules"),
        # Cursor also reads .cursorrules at the project root for legacy compatibility.
        ("ai-tools/cursor/.cursorrules", ".cursorrules"),
    ],
    "copilot": [
        (".github/prompts", ".github/prompts"),
        # Copilot reads .github/copilot-instructions.md.
        ("ai-tools/github-copilot/copilot-instructions.md", ".github/copilot-instructions.md"),
    ],
    "codex": [
        # Codex/OpenAI agent reads AGENTS.md at project root.
        ("ai-tools/codex/AGENTS.md", "AGENTS.md"),
    ],
    "aider": [
        # Aider reads .aider.conf.yml + CONVENTIONS.md at project root.
        ("ai-tools/aider/.aider.conf.yml", ".aider.conf.yml"),
        ("ai-tools/aider/CONVENTIONS.md", "CONVENTIONS.md"),
    ],
    "continue": [
        ("ai-tools/continue/.continuerules", ".continuerules"),
        ("ai-tools/continue/config.json", ".continue/config.json"),
    ],
    "cline": [
        ("ai-tools/cline/.clinerules", ".clinerules"),
    ],
    "windsurf": [
        ("ai-tools/windsurf/.windsurfrules", ".windsurfrules"),
    ],
}

_TOOL_DISPLAY = {
    "claude-code": "Claude Code (slash commands + subagents + skill)",
    "cursor": "Cursor (rules)",
    "copilot": "GitHub Copilot Chat (prompt files)",
    "codex": "OpenAI Codex (text rules — uses sdlc CLI from terminal)",
    "aider": "Aider (CONVENTIONS.md — uses sdlc CLI from terminal)",
    "continue": "Continue (text rules — uses sdlc CLI from terminal)",
    "cline": "Cline (text rules — uses sdlc CLI from terminal)",
    "windsurf": "Windsurf (text rules — uses sdlc CLI from terminal)",
}


def _detect_stack(target: Path) -> tuple[str | None, str | None]:
    """Return (stack, evidence_file) or (None, None) when no signal."""
    for stack, marker in _STACK_DETECTORS:
        if (target / marker).exists():
            return (stack, marker)
    return (None, None)


def _detect_tools(target: Path) -> list[str]:
    """Best-effort: which AI tools is the user already using here?"""
    found: list[str] = []
    if (target / ".claude" / "agents").exists() or (target / "CLAUDE.md").exists():
        found.append("claude-code")
    if (target / ".cursor").exists() or (target / ".cursorrules").exists():
        found.append("cursor")
    if (target / ".github" / "copilot-instructions.md").exists():
        found.append("copilot")
    if (target / "AGENTS.md").exists():
        found.append("codex")
    if (target / ".aider.conf.yml").exists() or (target / "CONVENTIONS.md").exists():
        found.append("aider")
    if (target / ".continue").exists() or (target / ".continuerules").exists():
        found.append("continue")
    if (target / ".clinerules").exists():
        found.append("cline")
    if (target / ".windsurfrules").exists():
        found.append("windsurf")
    return found


def _generate_native_artifacts(tool: str, scaffold_root: Path, target: Path, force: bool) -> tuple[int, int]:
    """Generate slash-commands / skills / agents / workflows in each tool's native format.

    Pattern (BMAD / Spec-Kit): a single canonical source — `.claude/commands/*.md`
    (slash commands) and `.claude/agents/*.md` (agents) — gets translated into each
    tool's expected layout. Most tools tolerate the same markdown+frontmatter format,
    so the translation is mostly path remapping (with renames for Copilot's `.agent.md`).

    Returns (copied, skipped).
    """
    copied = 0
    skipped = 0

    def _copy_file(src: Path, dst: Path) -> None:
        nonlocal copied, skipped
        if dst.exists() and not force:
            skipped += 1
            return
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(src.read_bytes())
        copied += 1

    cmds_src = scaffold_root / ".claude" / "commands"
    agents_src = scaffold_root / ".claude" / "agents"

    if tool == "cursor":
        # Cursor commands at `.cursor/commands/sdlc/<cmd>.md`
        if cmds_src.exists():
            for f in cmds_src.glob("*.md"):
                _copy_file(f, target / ".cursor" / "commands" / "sdlc" / f.name)
        # Cursor skills at `.cursor/skills/<role>/SKILL.md`
        if agents_src.exists():
            for f in agents_src.glob("*.md"):
                _copy_file(f, target / ".cursor" / "skills" / f.stem / "SKILL.md")

    elif tool == "windsurf":
        # Windsurf workflows at `.windsurf/workflows/<cmd>.md` (commands are workflows here).
        if cmds_src.exists():
            for f in cmds_src.glob("*.md"):
                _copy_file(f, target / ".windsurf" / "workflows" / f.name)
        # Windsurf rules already wired via _TOOL_ARTIFACTS.

    elif tool == "copilot":
        # Copilot agents at `.github/agents/<role>.agent.md` (renamed).
        if agents_src.exists():
            for f in agents_src.glob("*.md"):
                _copy_file(f, target / ".github" / "agents" / f"{f.stem}.agent.md")
        # Copilot prompts already wired via _TOOL_ARTIFACTS.

    elif tool == "continue":
        # Continue customCommands inside .continue/config.json (JSON injection).
        config_path = target / ".continue" / "config.json"
        if config_path.exists() and cmds_src.exists():
            try:
                config = json.loads(config_path.read_text(encoding="utf-8"))
            except Exception:
                config = {}
            existing = {c.get("name") for c in (config.get("customCommands") or [])}
            cmds: list[dict] = list(config.get("customCommands") or [])
            for f in sorted(cmds_src.glob("*.md")):
                cmd_name = f.stem  # e.g. sdlc-start
                if cmd_name in existing and not force:
                    skipped += 1
                    continue
                # Strip frontmatter, keep body as the prompt.
                text = f.read_text(encoding="utf-8")
                body = text
                if text.startswith("---"):
                    parts = text.split("---", 2)
                    if len(parts) >= 3:
                        body = parts[2].strip()
                cmds.append({
                    "name": cmd_name,
                    "description": f"SDLC framework: {cmd_name}",
                    "prompt": body,
                })
                copied += 1
            if not existing:  # only when we changed something
                config["customCommands"] = cmds
            elif copied > 0:
                config["customCommands"] = cmds
            config_path.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")

    elif tool == "claude-code":
        # Claude Code already covered by _TOOL_ARTIFACTS.
        pass

    return copied, skipped


def _copy_tool_artifacts(tool: str, scaffold_root: Path, target: Path, force: bool) -> tuple[int, int]:
    """Copy a tool's artifacts from scaffold to target. Returns (copied, skipped).

    Handles both directory-to-directory copies (e.g. .claude/agents → .claude/agents)
    and file-to-file copies (e.g. ai-tools/codex/AGENTS.md → AGENTS.md).
    """
    copied = 0
    skipped = 0
    for src_rel, dst_rel in _TOOL_ARTIFACTS.get(tool, []):
        src_path_root = scaffold_root / src_rel
        if not src_path_root.exists():
            continue
        if src_path_root.is_file():
            # Single-file mapping (e.g. ai-tools/codex/AGENTS.md → AGENTS.md).
            dest_path = target / dst_rel
            if dest_path.exists() and not force:
                skipped += 1
                continue
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            dest_path.write_bytes(src_path_root.read_bytes())
            if os.access(src_path_root, os.X_OK):
                os.chmod(dest_path, 0o755)
            copied += 1
        else:
            # Directory mapping (e.g. .claude/agents → .claude/agents).
            for src_path in src_path_root.rglob("*"):
                if src_path.is_dir():
                    continue
                rel = src_path.relative_to(src_path_root)
                dest_path = target / dst_rel / rel
                if dest_path.exists() and not force:
                    skipped += 1
                    continue
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                dest_path.write_bytes(src_path.read_bytes())
                if os.access(src_path, os.X_OK):
                    os.chmod(dest_path, 0o755)
                copied += 1
    return copied, skipped


def _cmd_setup(argv: list[str]) -> int:
    """Interactive setup: scaffold + pick AI tools to install native artifacts for."""
    parser = argparse.ArgumentParser(prog="sdlc setup")
    parser.add_argument("--tools", default=None,
                        help="Comma-separated tool list (e.g. claude-code,cursor). "
                             "Skip the interactive prompt.")
    parser.add_argument("--stack", choices=["node", "python", "go"], default=None,
                        help="Override auto-detected stack.")
    parser.add_argument("--force", action="store_true",
                        help="Overwrite existing files.")
    args = parser.parse_args(argv)

    target = Path.cwd()

    # Step 1: scaffold (delegates to _cmd_init).
    init_argv: list[str] = []
    if args.stack:
        init_argv.append(f"--stack={args.stack}")
    if args.force:
        init_argv.append("--force")
    print("[sdlc setup] step 1/2 — scaffolding base project")
    rc = _cmd_init(init_argv)
    if rc != 0:
        print("[sdlc setup] init failed; aborting setup")
        return rc

    # Step 2: pick AI tools.
    print()
    print("[sdlc setup] step 2/2 — selecting AI tools")
    if args.tools:
        chosen = [t.strip() for t in args.tools.split(",") if t.strip()]
    else:
        detected = _detect_tools(target)
        all_tools = list(_TOOL_ARTIFACTS.keys())
        print()
        print("Which AI coding tools do you use? (multi-select)")
        for i, tool in enumerate(all_tools, 1):
            mark = " [detected]" if tool in detected else ""
            print(f"  {i}. {tool} — {_TOOL_DISPLAY[tool]}{mark}")
        print()
        print("Enter numbers separated by space, or press Enter for detected only.")
        try:
            raw = input("> ").strip()
        except EOFError:
            raw = ""
        if not raw:
            chosen = detected if detected else ["claude-code"]
            print(f"[sdlc setup] using {'detected' if detected else 'default'}: {', '.join(chosen)}")
        else:
            try:
                indices = [int(x) for x in raw.split()]
                chosen = [all_tools[i - 1] for i in indices if 1 <= i <= len(all_tools)]
            except (ValueError, IndexError):
                print("[sdlc setup] invalid selection; aborting")
                return 2

    # Step 3: copy artifacts for each chosen tool.
    pkg_files = resources.files("sdlc_framework").joinpath("scaffold")
    with resources.as_file(pkg_files) as scaffold_root:
        for tool in chosen:
            if tool not in _TOOL_ARTIFACTS:
                print(f"[sdlc setup] unknown tool: {tool}; skipping")
                continue
            artifacts = _TOOL_ARTIFACTS[tool]
            if not artifacts:
                # Tool has no native artifacts beyond the generic ones written by sdlc init.
                print(f"[sdlc setup] {tool}: no native slash-command surface; "
                      f"use the `sdlc` CLI from your tool's terminal")
                continue
            copied, skipped = _copy_tool_artifacts(tool, scaffold_root, target, args.force)
            # Per-tool native artifact generators (commands / skills / agents / workflows
            # for tools that expose those file conventions).
            n_copied, n_skipped = _generate_native_artifacts(tool, scaffold_root, target, args.force)
            copied += n_copied
            skipped += n_skipped
            print(f"[sdlc setup] {tool}: {copied} files copied, {skipped} skipped")

    # Step 4: tell the user what to do next, per tool.
    print()
    print("[sdlc setup] done. Next steps:")
    if "claude-code" in chosen:
        print("  Claude Code: open this folder, then use:")
        print("    /sdlc-start \"<your idea>\"   to begin Phase 1")
        print("    /sdlc-next                  to advance to the next pending item")
        print("    /sdlc-scan                  to refresh progress")
        print("    /sdlc-dashboard             to open the dashboard")
    if "cursor" in chosen:
        print("  Cursor: rules in .cursor/rules/sdlc.mdc + commands in .cursor/commands/sdlc/ + skills in .cursor/skills/<role>/")
        print("    Type / in chat to see commands, or share an idea (Cursor adopts pm-agent persona).")
    if "copilot" in chosen:
        print("  GitHub Copilot Chat: prompt files at .github/prompts/sdlc-*.prompt.md + agents at .github/agents/<role>.agent.md")
        print("    Use them via the Copilot Chat 'prompts' / 'agents' UI.")
    if "windsurf" in chosen:
        print("  Windsurf: workflows in .windsurf/workflows/sdlc-*.md")
        print("    Trigger via Cascade workflow runner.")
    if "continue" in chosen:
        print("  Continue: customCommands wired in .continue/config.json — type /sdlc-start, /sdlc-next, etc. in chat.")
    text_tools = [t for t in chosen if t in {"codex", "aider", "continue", "cline", "windsurf"}]
    if text_tools:
        print(f"  {', '.join(text_tools)}: text rules already wired by `sdlc init`.")
        print(f"    From the tool's terminal: sdlc start \"<idea>\" / sdlc next / sdlc scan.")
    return 0


def _cmd_init(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="sdlc init")
    parser.add_argument("--stack", choices=["node", "python", "go"], default=None,
                        help="Override auto-detected stack. Auto-detect from package.json / pyproject.toml / go.mod when omitted.")
    parser.add_argument("--force", action="store_true",
                        help="Overwrite existing files.")
    args = parser.parse_args(argv)

    target = Path.cwd()

    # Resolve stack: explicit flag wins, else auto-detect, else None (no CI wiring).
    stack: str | None = args.stack
    if stack:
        print(f"[sdlc init] stack={stack} (from --stack flag)")
    else:
        detected, evidence = _detect_stack(target)
        if detected:
            stack = detected
            print(f"[sdlc init] stack={stack} (auto-detected from {evidence})")
        else:
            print("[sdlc init] no stack auto-detected (no package.json / pyproject.toml / go.mod found)")
            print("[sdlc init] CI workflow will not be wired. Re-run with --stack=node|python|go to add one later.")

    pkg_files = resources.files("sdlc_framework").joinpath("scaffold")

    copied = 0
    skipped = 0
    with resources.as_file(pkg_files) as real_root:
        for src_path in real_root.rglob("*"):
            if src_path.is_dir():
                continue
            rel = src_path.relative_to(real_root)
            dest_path = target / rel
            if dest_path.exists() and not args.force:
                skipped += 1
                continue
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            dest_path.write_bytes(src_path.read_bytes())
            # preserve executable bit (best effort)
            if os.access(src_path, os.X_OK):
                os.chmod(dest_path, 0o755)
            copied += 1

    print(f"[sdlc init] copied {copied} files, skipped {skipped} existing")
    if copied == 0 and not args.force:
        print("[sdlc init] this looks like an already-initialized project — re-run with --force to overwrite, or `sdlc scan` to start.")

    if stack:
        # Ship the chosen CI workflow as .github/workflows/ci.yml
        ci_src = target / "04-Testing-Deploy" / "templates" / "ci-workflows" / f"{stack}-ci.yml"
        if ci_src.exists():
            ci_dest = target / ".github" / "workflows" / "ci.yml"
            ci_dest.parent.mkdir(parents=True, exist_ok=True)
            if args.force or not ci_dest.exists():
                ci_dest.write_bytes(ci_src.read_bytes())
                print(f"[sdlc init] wrote .github/workflows/ci.yml from {stack}-ci.yml")
            else:
                print(f"[sdlc init] .github/workflows/ci.yml exists; --force to overwrite")
    # Regenerate tool configs so the new headers from this version are picked up.
    rc = _run_bundled_script("build-ai-configs.sh", [])
    return rc


_PHASE_AGENT = {1: "pm-agent", 2: "architect-agent", 3: "developer-agent", 4: "sre-agent"}
_PHASE_FILE = {1: "phase-1-pm.md", 2: "phase-2-architect.md",
               3: "phase-3-developer.md", 4: "phase-4-sre.md"}


def _next_pending(state: dict) -> tuple[int, dict] | None:
    """Return (phase_id, item) for the first pending item, or None when done."""
    for ph in state.get("phases", []):
        if ph.get("complete"):
            continue
        for it in ph.get("items", []):
            if not it.get("done"):
                return (ph["id"], it)
    return None


def _cmd_start(argv: list[str]) -> int:
    """Save the user's idea and print a paste-ready instruction for the AI tool."""
    parser = argparse.ArgumentParser(prog="sdlc start")
    parser.add_argument("idea", nargs="?", help="One-line description of what you want to build.")
    args = parser.parse_args(argv)

    target = Path.cwd()
    if not (target / "automation" / "rules.json").exists():
        print("[sdlc start] this directory doesn't look like an sdlc project. Run `sdlc init` first.")
        return 1

    idea = args.idea
    if not idea:
        try:
            idea = input("What do you want to build? > ").strip()
        except EOFError:
            print("[sdlc start] no idea provided; usage: sdlc start \"<your idea>\"")
            return 2
    if not idea:
        print("[sdlc start] no idea provided; aborting.")
        return 2

    idea_file = target / "01-Planning" / "IDEA.md"
    idea_file.parent.mkdir(parents=True, exist_ok=True)
    idea_file.write_text(
        f"# Project idea\n\n{idea}\n\n"
        f"<!-- Captured by `sdlc start` on first run. Edit freely; the engine "
        f"does not enforce a structure here. -->\n",
        encoding="utf-8",
    )
    print(f"[sdlc start] saved your idea to {idea_file.relative_to(target)}")
    print()
    print("Next step — open this folder in your AI coding tool, then paste:")
    print()
    print("─" * 64)
    print(f"Use the pm-agent subagent to draft 01-Planning/01-PRD.md from")
    print(f"01-Planning/IDEA.md. Idea: {idea}")
    print("─" * 64)
    print()
    print("Why \"use the pm-agent subagent\" explicitly?")
    print("  Some AI tools (e.g. Claude Code with the 'superpowers' plugin)")
    print("  auto-fire other skills like 'brainstorming' when you share an")
    print("  idea. Naming the subagent forces Claude Code to use this repo's")
    print("  .claude/agents/pm-agent.md instead, which writes 01-Planning/01-PRD.md")
    print("  per automation/rules.json.")
    print()
    print("After the AI writes the PRD:")
    print("  sdlc scan --print     # verify DoD progress")
    print("  sdlc next             # paste-ready prompt for the next item")
    return 0


# Impact map: which DoD items get marked dirty when a particular concern changes.
_REPLAN_IMPACT: dict[str, list[str]] = {
    "requirements": [
        "user-stories", "nfr-targets", "stakeholder-map", "risks-identified",
        "api-contract", "database-schema", "security-threat-model",
        "tests-present",
    ],
    "ui-ux": [
        "screen-designs",
        "tests-present",
    ],
    "tech-stack": [
        "system-architecture", "api-contract", "database-schema", "architecture-decisions", "security-threat-model",
        "coding-standards-published", "git-workflow-documented", "security-checklist-available", "tests-present",
        "ci-pipeline-configured", "deployment-runbook-ready", "slo-targets-defined",
    ],
    "scale-nfr": [
        "nfr-targets",
        "system-architecture", "database-schema", "security-threat-model",
        "slo-targets-defined",
    ],
}

_REPLAN_CHOICES = [
    ("requirements", "Functional requirements / user stories changed"),
    ("ui-ux", "UI / UX scope or screens changed"),
    ("tech-stack", "Tech stack / language / framework changed"),
    ("scale-nfr", "Scale / NFR targets (RPS, latency, SLO) changed"),
    ("custom", "Custom — I'll list the item ids myself"),
    ("clear", "Clear all dirty markers (I've redone the work)"),
]


def _cmd_replan(argv: list[str]) -> int:
    """Mark downstream DoD items dirty after a major change."""
    parser = argparse.ArgumentParser(prog="sdlc replan")
    parser.add_argument("--scope", choices=[c for c, _ in _REPLAN_CHOICES if c != "custom"],
                        default=None, help="Skip the prompt; pick one impact preset.")
    parser.add_argument("--items", default=None,
                        help="Comma-separated DoD item ids to mark dirty (used with --scope=custom).")
    parser.add_argument("--reason", default=None, help="Free-text reason recorded with the replan.")
    parser.add_argument("--clear", action="store_true",
                        help="Clear all dirty markers (after you've redone the work).")
    args = parser.parse_args(argv)

    target = Path.cwd()
    state_path = target / "automation" / "state.json"
    if not state_path.exists():
        print("[sdlc replan] state.json not found. Run `sdlc scan` first.")
        return 1

    # Locate engine module to call clear/load/write_replan helpers.
    from sdlc_framework import engine
    engine.set_root(target)

    # Quick path: clear.
    if args.clear or args.scope == "clear":
        engine.clear_replan()
        print("[sdlc replan] cleared all dirty markers. Run `sdlc scan` to refresh state.")
        return 0

    # Resolve scope: flag or interactive.
    scope = args.scope
    if not scope:
        print("What changed? Pick one:")
        for i, (key, desc) in enumerate(_REPLAN_CHOICES, 1):
            print(f"  {i}. {desc}")
        try:
            raw = input("> ").strip()
        except EOFError:
            print("[sdlc replan] no selection; aborting")
            return 2
        try:
            idx = int(raw) - 1
            scope = _REPLAN_CHOICES[idx][0]
        except (ValueError, IndexError):
            print("[sdlc replan] invalid selection; aborting")
            return 2
        if scope == "clear":
            engine.clear_replan()
            print("[sdlc replan] cleared all dirty markers.")
            return 0

    # Compute affected items.
    if scope == "custom":
        if args.items:
            affected = [s.strip() for s in args.items.split(",") if s.strip()]
        else:
            print("Enter comma-separated DoD item ids (e.g. api-contract,tests-present):")
            try:
                raw = input("> ").strip()
            except EOFError:
                raw = ""
            affected = [s.strip() for s in raw.split(",") if s.strip()]
        if not affected:
            print("[sdlc replan] no items provided; aborting")
            return 2
    else:
        affected = list(_REPLAN_IMPACT.get(scope, []))
        if not affected:
            print(f"[sdlc replan] unknown scope '{scope}'; aborting")
            return 2

    # Validate items exist in rules.
    state = json.loads(state_path.read_text())
    known = {it["id"] for ph in state.get("phases") or [] for it in ph.get("items") or []}
    unknown = [a for a in affected if a not in known]
    if unknown:
        print(f"[sdlc replan] warning: these item ids are not in rules.json — they will be ignored:")
        for u in unknown:
            print(f"     · {u}")
        affected = [a for a in affected if a in known]
        if not affected:
            print("[sdlc replan] no valid items remain; aborting")
            return 2

    # Confirm with user.
    reason = args.reason
    if not reason:
        print(f"\nThis will mark {len(affected)} item(s) dirty:")
        for a in affected:
            print(f"     · {a}")
        try:
            reason = input("\nWhy (one line for the audit log)?\n> ").strip()
        except EOFError:
            reason = ""
        if not reason:
            reason = f"replan: scope={scope}"
        try:
            confirm = input("Apply? [Y/n] ").strip().lower()
        except EOFError:
            confirm = "y"
        if confirm and confirm not in ("y", "yes"):
            print("[sdlc replan] cancelled")
            return 0

    # Merge with any existing replan (union of dirty_items, latest reason wins).
    existing = engine.load_replan()
    merged_items = sorted(set((existing.get("dirty_items") or []) + affected))
    payload = {
        "dirty_items": merged_items,
        "reason": reason,
        "ts": json.loads(json.dumps(__import__("datetime").datetime.now(__import__("datetime").timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))),
        "scope": scope,
    }
    engine.write_replan(payload)

    # Drop a clarification file so the change is auditable on the dashboard.
    clarif_dir = target / "automation" / "clarifications"
    clarif_dir.mkdir(parents=True, exist_ok=True)
    ts_slug = payload["ts"].replace(":", "").replace("-", "")
    clarif_file = clarif_dir / f"replan-{ts_slug}.md"
    clarif_file.write_text(
        f"# Replan: {scope}\n\nSTATUS: open\n\n"
        f"Reason: {reason}\n\n"
        f"## Items marked dirty\n\n"
        + "\n".join(f"- `{a}`" for a in affected)
        + "\n\n"
        + "Resolve by re-doing the work for the dirty items, then running `sdlc replan --clear`.\n",
        encoding="utf-8",
    )

    print(f"\n[sdlc replan] marked {len(affected)} item(s) dirty.")
    print(f"[sdlc replan] wrote audit clarification: {clarif_file.relative_to(target)}")
    print(f"[sdlc replan] run `sdlc scan` to refresh state, then `sdlc resume` to see what to redo.")
    print(f"[sdlc replan] when done, run `sdlc replan --clear` to drop the dirty markers.")
    return 0


def _git_user_name() -> str:
    try:
        out = subprocess.run(
            ["git", "config", "user.name"],
            capture_output=True, text=True, timeout=2
        )
        if out.returncode == 0 and out.stdout.strip():
            return out.stdout.strip()
    except Exception:
        pass
    return os.environ.get("USER") or "unknown"


def _link_or_copy(src: Path, dst: Path) -> str:
    """Symlink src → dst when supported, else copy. Return 'symlink' or 'copy'."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        rel = os.path.relpath(src, dst.parent)
        dst.symlink_to(rel)
        return "symlink"
    except (OSError, NotImplementedError):
        dst.write_bytes(src.read_bytes())
        return "copy"


def _scan_existing_assets(target: Path) -> dict:
    """Inventory existing project assets that map to SDLC phases."""
    found: dict[str, list[Path]] = {
        "prd": [],
        "requirements": [],
        "user_stories": [],
        "architecture": [],
        "api_spec": [],
        "db_schema": [],
        "ui_spec": [],
        "threat_model": [],
        "test_plan": [],
        "runbook": [],
        "slo": [],
        "incident_response": [],
        "ci_workflow": [],
        "src_files": [],
        "test_files": [],
    }
    for p in target.rglob("*.md"):
        if any(part in {".git", "node_modules", ".venv", "venv", "__pycache__",
                        "01-Planning", "02-Design", "04-Testing-Deploy"}
               for part in p.parts):
            continue
        name_lower = p.name.lower()
        if "prd" in name_lower or "product-req" in name_lower:
            found["prd"].append(p)
        if "requirement" in name_lower:
            found["requirements"].append(p)
        if "user-stor" in name_lower or "user_stor" in name_lower or "stories" in name_lower:
            found["user_stories"].append(p)
        if "architecture" in name_lower or name_lower in ("design.md", "system-design.md"):
            found["architecture"].append(p)
        if "api" in name_lower and ("spec" in name_lower or name_lower.endswith("-api.md")):
            found["api_spec"].append(p)
        if "schema" in name_lower or "database" in name_lower or "db" in name_lower.split(".")[0].split("-"):
            found["db_schema"].append(p)
        if "ui" in name_lower.split(".")[0].split("-") or "ux" in name_lower.split(".")[0].split("-"):
            found["ui_spec"].append(p)
        if "threat" in name_lower:
            found["threat_model"].append(p)
        if "test-plan" in name_lower or "testplan" in name_lower:
            found["test_plan"].append(p)
        if "runbook" in name_lower:
            found["runbook"].append(p)
        if "slo" in name_lower or "sli" in name_lower:
            found["slo"].append(p)
        if "incident" in name_lower:
            found["incident_response"].append(p)
    # OpenAPI specs
    for ext in ("yaml", "yml", "json"):
        for p in target.rglob(f"openapi.{ext}"):
            found["api_spec"].append(p)
    # CI workflows
    workflows_dir = target / ".github" / "workflows"
    if workflows_dir.exists():
        found["ci_workflow"] = list(workflows_dir.glob("*.yml")) + list(workflows_dir.glob("*.yaml"))
    # Source + test counts (rough)
    src_dir = target / "src"
    if src_dir.exists():
        for ext in ("ts", "tsx", "js", "jsx", "py", "go"):
            found["src_files"].extend(src_dir.rglob(f"*.{ext}"))
    for pattern in ("**/*.test.*", "**/*.spec.*", "**/test_*.py", "**/*_test.go"):
        for p in target.rglob(pattern):
            if any(part in {".git", "node_modules", ".venv", "venv"} for part in p.parts):
                continue
            found["test_files"].append(p)
    return found


def _cmd_adopt(argv: list[str]) -> int:
    """Adopt SDLC framework on an existing running project.

    Detects existing assets, lets user claim them as evidence (auto-verifies
    with imported-from-existing marker), and configures legacy_code_globs.
    Idempotent.
    """
    parser = argparse.ArgumentParser(prog="sdlc adopt")
    parser.add_argument("--auto", action="store_true",
                        help="Non-interactive: accept all detected assets, mark all phases approved.")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print plan, write nothing.")
    args = parser.parse_args(argv)

    target = Path.cwd()

    print("[sdlc adopt] scanning your project for existing assets...")
    print()
    found = _scan_existing_assets(target)

    summary = []
    if found["prd"]:
        summary.append(f"  📋 {len(found['prd'])} PRD-like file(s): " + ", ".join(p.name for p in found["prd"][:3]))
    if found["requirements"]:
        summary.append(f"  📋 {len(found['requirements'])} requirements file(s): " + ", ".join(p.name for p in found["requirements"][:3]))
    if found["user_stories"]:
        summary.append(f"  📋 {len(found['user_stories'])} user-story file(s)")
    if found["architecture"]:
        summary.append(f"  📐 {len(found['architecture'])} architecture file(s)")
    if found["api_spec"]:
        summary.append(f"  📐 {len(found['api_spec'])} API spec file(s)")
    if found["test_plan"]:
        summary.append(f"  🧪 {len(found['test_plan'])} test plan(s)")
    if found["runbook"]:
        summary.append(f"  🚀 {len(found['runbook'])} runbook(s)")
    if found["slo"]:
        summary.append(f"  📊 {len(found['slo'])} SLO doc(s)")
    if found["ci_workflow"]:
        summary.append(f"  ⚙️  {len(found['ci_workflow'])} CI workflow(s)")
    if found["src_files"]:
        ratio = len(found["test_files"]) / max(1, len(found["src_files"]))
        summary.append(f"  💻 {len(found['src_files'])} source files, {len(found['test_files'])} tests (TDD ratio {ratio:.2f})")

    if not summary:
        print("[sdlc adopt] no existing SDLC-like assets detected.")
        print("[sdlc adopt] If this is a brand-new project, run `sdlc setup` instead.")
        return 0

    print("Found:")
    for s in summary:
        print(s)
    print()

    if args.dry_run:
        print("[sdlc adopt] --dry-run — no files written.")
        return 0

    # Ensure scaffold is in place (idempotent — sdlc init won't overwrite).
    if not (target / "automation" / "rules.json").exists():
        print("[sdlc adopt] scaffolding base SDLC structure first (delegates to `sdlc init`)...")
        _cmd_init([])
        print()

    auto = args.auto

    # Per-phase prompts.
    def ask(prompt: str, default_yes: bool = True) -> bool:
        if auto:
            return True
        try:
            choice = input(f"{prompt} [{'Y/n' if default_yes else 'y/N'}] ").strip().lower()
        except EOFError:
            return default_yes
        if not choice:
            return default_yes
        return choice in ("y", "yes")

    # Phase 1.
    p1_assets = found["prd"] + found["requirements"] + found["user_stories"]
    if p1_assets and ask("Phase 1 — claim these planning artifacts as drafted+verified?"):
        for p in found["prd"]:
            dst = target / "01-Planning" / "01-PRD.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["prd-drafted", "--auto"])
            break  # one file is enough
        for p in found["requirements"]:
            dst = target / "01-Planning" / "03-Requirements-Spec.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["nfr-targets", "--auto"])
            break
        for p in found["user_stories"]:
            dst = target / "01-Planning" / "02-User-Stories.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["user-stories", "--auto"])
            break

    # Phase 2.
    p2_assets = found["architecture"] + found["api_spec"] + found["db_schema"]
    if p2_assets and ask("Phase 2 — claim these design artifacts as drafted+verified?"):
        for p in found["architecture"]:
            dst = target / "02-Design" / "01-Architecture.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["system-architecture", "--auto"])
            break
        for p in found["api_spec"]:
            dst = target / "02-Design" / "02-API-Spec.md"
            if not dst.exists() and p.suffix == ".md":
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["api-contract", "--auto"])
            break

    # Phase 3 — legacy code policy.
    if found["src_files"]:
        print()
        print("Phase 3 — you have existing code. How should the framework treat it?")
        print("  a) Mark all existing src/ as legacy (no TDD enforcement); new code goes through tasks")
        print("  b) Skip — manage tasks manually")
        if not auto:
            try:
                choice = input("> ").strip().lower()
            except EOFError:
                choice = "a"
        else:
            choice = "a"
        if choice in ("a", ""):
            project_yaml = target / "project.yaml"
            if project_yaml.exists():
                text = project_yaml.read_text(encoding="utf-8")
                if "legacy_code_globs" not in text:
                    text += '\nlegacy_code_globs:\n  - "src/**"\n'
                    project_yaml.write_text(text, encoding="utf-8")
                    print(f"  [ok] added legacy_code_globs to project.yaml")

    # Phase 4.
    if found["test_plan"] and ask("Phase 4 — claim test plan as drafted+verified?"):
        for p in found["test_plan"]:
            dst = target / "04-Testing-Deploy" / "01-Test-Plan.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["test-plan-published", "--auto"])
            break

    # Phase 5.
    p5_assets = found["runbook"] + found["slo"] + found["incident_response"] + found["ci_workflow"]
    if p5_assets and ask("Phase 5 — claim deploy/monitor artifacts as drafted+verified?"):
        for p in found["runbook"]:
            dst = target / "04-Testing-Deploy" / "03-Deployment-Runbook.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["deployment-runbook-ready", "--auto"])
            break
        for p in found["slo"]:
            dst = target / "04-Testing-Deploy" / "04-Monitoring-SLO.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["slo-targets-defined", "--auto"])
            break
        for p in found["incident_response"]:
            dst = target / "04-Testing-Deploy" / "05-Incident-Response.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["incident-response-ready", "--auto"])
            break

    print()
    print("[sdlc adopt] done.")
    print("[sdlc adopt] run `sdlc resume` to see your starting point.")
    print("[sdlc adopt] run `sdlc next` to begin work on the next pending item.")
    return 0


def _cmd_migrate_v2(argv: list[str]) -> int:
    """Migrate a project on framework v0.6.x to the v2 phase model (5 phases).

    Steps:
      1. Back up automation/rules.json → automation/rules.json.v1.bak
      2. Replace rules.json with bundled v2 rules
      3. Rename automation/signoffs/phase4-prod.yaml → phase5-prod.yaml (preserve approval)
      4. Bump project.yaml.schema_version 1 → 2
      5. Optionally bootstrap automation/tasks/ from user stories

    Idempotent: re-running on an already-migrated project is a no-op.
    """
    parser = argparse.ArgumentParser(prog="sdlc migrate-v2")
    parser.add_argument("--auto", action="store_true",
                        help="Non-interactive — apply all migration steps without prompts.")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print what would change, write nothing.")
    args = parser.parse_args(argv)

    target = Path.cwd()
    rules_path = target / "automation" / "rules.json"
    if not rules_path.exists():
        print("[sdlc migrate-v2] automation/rules.json not found. Is this an SDLC project?")
        return 1

    rules = json.loads(rules_path.read_text(encoding="utf-8"))
    schema_version = rules.get("schema_version") or 1

    if schema_version >= 2:
        print(f"[sdlc migrate-v2] schema_version is already {schema_version}. Nothing to do.")
        return 0

    print(f"[sdlc migrate-v2] migrating from schema_version {schema_version} → 2")
    print()

    # Plan changes.
    changes: list[tuple[str, str]] = []
    bak_path = target / "automation" / "rules.json.v1.bak"
    if not bak_path.exists():
        changes.append(("backup", f"copy automation/rules.json → automation/rules.json.v1.bak"))
    changes.append(("replace", "replace automation/rules.json with v2 5-phase schema"))

    old_signoff = target / "automation" / "signoffs" / "phase4-prod.yaml"
    new_signoff = target / "automation" / "signoffs" / "phase5-prod.yaml"
    if old_signoff.exists() and not new_signoff.exists():
        changes.append(("rename", "rename automation/signoffs/phase4-prod.yaml → phase5-prod.yaml"))

    project_yaml = target / "project.yaml"
    if project_yaml.exists():
        text = project_yaml.read_text(encoding="utf-8")
        if "schema_version" not in text:
            changes.append(("project-version", "add `schema_version: 2` to project.yaml"))
        elif "schema_version: 1" in text or "schema_version:1" in text:
            changes.append(("project-version", "bump project.yaml schema_version 1 → 2"))

    user_stories = target / "01-Planning" / "02-User-Stories.md"
    tasks_dir = target / "automation" / "tasks"
    if user_stories.exists() and not tasks_dir.exists():
        changes.append(("bootstrap", "bootstrap automation/tasks/ from user stories"))

    print(f"[sdlc migrate-v2] {len(changes)} change(s) planned:")
    for kind, desc in changes:
        print(f"  · [{kind}] {desc}")
    print()

    if args.dry_run:
        print("[sdlc migrate-v2] --dry-run — no files written.")
        return 0

    if not args.auto:
        try:
            ans = input("Apply? [Y/n] ").strip().lower()
        except EOFError:
            ans = "y"
        if ans and ans not in ("y", "yes"):
            print("[sdlc migrate-v2] cancelled.")
            return 0

    # Apply.
    for kind, _desc in changes:
        if kind == "backup":
            bak_path.write_text(rules_path.read_text(encoding="utf-8"), encoding="utf-8")
            print(f"  [ok] backed up to {bak_path.relative_to(target)}")
        elif kind == "replace":
            pkg_rules = resources.files("sdlc_framework").joinpath("scaffold").joinpath("automation").joinpath("rules.json")
            with resources.as_file(pkg_rules) as real_path:
                rules_path.write_text(real_path.read_text(encoding="utf-8"), encoding="utf-8")
            print(f"  [ok] replaced rules.json with v2")
        elif kind == "rename":
            old_signoff.rename(new_signoff)
            print(f"  [ok] renamed signoff to phase5-prod.yaml")
        elif kind == "project-version":
            text = project_yaml.read_text(encoding="utf-8")
            if "schema_version: 1" in text:
                text = text.replace("schema_version: 1", "schema_version: 2", 1)
            elif "schema_version:1" in text:
                text = text.replace("schema_version:1", "schema_version: 2", 1)
            elif "schema_version" not in text:
                text = "schema_version: 2\n" + text
            project_yaml.write_text(text, encoding="utf-8")
            print(f"  [ok] project.yaml schema_version → 2")
        elif kind == "bootstrap":
            rc = _cmd_tasks(["bootstrap"])
            if rc == 0:
                print(f"  [ok] bootstrapped tasks from user stories")
            else:
                print(f"  [warn] tasks bootstrap returned {rc} — you can run `sdlc tasks bootstrap` later")

    print()
    print("[sdlc migrate-v2] done. Run `sdlc scan --print` to see your new phase model.")
    print("[sdlc migrate-v2] backup at automation/rules.json.v1.bak (delete when comfortable).")
    return 0


# v0.7/v0.8 → v0.9 ID rename map. Values from the v3 design spec.
_MIGRATE_V3_ID_RENAMES: dict[str, str] = {
    # Phase 1
    "prd-exists": "prd-drafted",
    "user-stories-with-ac": "user-stories",
    "nfr-quantified": "nfr-targets",
    "stakeholder-raci": "stakeholder-map",
    "risks-mitigated": "risks-identified",
    "phase1-prd-signoff": "phase1-signoff",
    # Phase 2
    "architecture-doc": "system-architecture",
    "api-spec": "api-contract",
    "db-schema": "database-schema",
    "adr-logged": "architecture-decisions",
    "threat-model": "security-threat-model",
    "ui-spec": "screen-designs",
    "accessibility": "accessibility-checklist",
    "phase2-design-signoff": "phase2-signoff",
    # Phase 3 setup (ai-disclosure-policy is dropped — its check folded into pr-template-configured)
    "coding-standards": "coding-standards-published",
    "git-workflow": "git-workflow-documented",
    "pr-template": "pr-template-configured",
    "security-checklist": "security-checklist-available",
    "ai-tool-configs": "ai-tool-configs-generated",
    "tdd-coverage": "tdd-coverage-active",
    # Phase 4
    "test-plan-written": "test-plan-published",
    "e2e-suite-present": "end-to-end-test-suite",
    "integration-tests": "integration-test-suite",
    "smoke-tests": "smoke-test-suite",
    "regression-baseline": "regression-test-baseline",
    # Phase 5
    "ci-pipeline": "ci-pipeline-configured",
    "ci-green": "ci-pipeline-green",
    "deploy-runbook-written": "deployment-runbook-ready",
    "slo-monitoring": "slo-targets-defined",
    "incident-response": "incident-response-ready",
    "observability-dashboard": "observability-wired",
    "prod-deploy-signoff": "phase5-signoff",
}

_MIGRATE_V3_SIGNOFF_RENAMES: dict[str, str] = {
    "phase1-prd.yaml": "phase1-signoff.yaml",
    "phase2-design.yaml": "phase2-signoff.yaml",
    "prod-deploy-signoff.yaml": "phase5-signoff.yaml",
    "phase5-prod.yaml": "phase5-signoff.yaml",
}


def _cmd_migrate_v3(argv: list[str]) -> int:
    """Migrate a project on framework v0.7/v0.8 to the v3 phase model.

    Steps:
      1. Back up automation/rules.json → automation/rules.json.v2.bak
      2. Replace rules.json with bundled v3 rules
      3. Rename keys in automation/.verifications.json (preserves verify history)
      4. Rename signoff filenames in automation/signoffs/
      5. Bump project.yaml.schema_version 2 → 3

    Idempotent: re-running on an already-migrated project is a no-op.
    """
    parser = argparse.ArgumentParser(prog="sdlc migrate-v3")
    parser.add_argument("--auto", action="store_true",
                        help="Non-interactive — apply all migration steps without prompts.")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print what would change, write nothing.")
    args = parser.parse_args(argv)

    target = Path.cwd()
    rules_path = target / "automation" / "rules.json"
    if not rules_path.exists():
        print("[sdlc migrate-v3] automation/rules.json not found. Is this an SDLC project?")
        return 1

    rules = json.loads(rules_path.read_text(encoding="utf-8"))
    schema_version = rules.get("schema_version") or 1

    if schema_version >= 3:
        print(f"[sdlc migrate-v3] schema_version is already {schema_version}. Nothing to do.")
        return 0

    print(f"[sdlc migrate-v3] migrating from schema_version {schema_version} → 3")
    print()

    # Plan changes.
    changes: list[tuple[str, str]] = []
    bak_path = target / "automation" / "rules.json.v2.bak"
    if not bak_path.exists():
        changes.append(("backup", "copy automation/rules.json → automation/rules.json.v2.bak"))
    changes.append(("replace", "replace automation/rules.json with v3 schema (renamed + reordered)"))

    verifications = target / "automation" / ".verifications.json"
    if verifications.exists():
        try:
            vdata = json.loads(verifications.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            vdata = {}
        rename_count = sum(1 for k in vdata if k in _MIGRATE_V3_ID_RENAMES)
        if rename_count > 0:
            changes.append(("verify-keys",
                            f"rename {rename_count} key(s) in .verifications.json (preserves history)"))

    signoffs_dir = target / "automation" / "signoffs"
    if signoffs_dir.exists():
        for old_name, new_name in _MIGRATE_V3_SIGNOFF_RENAMES.items():
            old = signoffs_dir / old_name
            new = signoffs_dir / new_name
            if old.exists() and not new.exists():
                changes.append(("signoff-rename",
                                f"rename automation/signoffs/{old_name} → {new_name}"))

    project_yaml = target / "project.yaml"
    if project_yaml.exists():
        text = project_yaml.read_text(encoding="utf-8")
        if "schema_version: 2" in text or "schema_version:2" in text:
            changes.append(("project-version", "bump project.yaml schema_version 2 → 3"))
        elif "schema_version" not in text:
            changes.append(("project-version", "add `schema_version: 3` to project.yaml"))

    print(f"[sdlc migrate-v3] {len(changes)} change(s) planned:")
    for kind, desc in changes:
        print(f"  · [{kind}] {desc}")
    print()

    if args.dry_run:
        print("[sdlc migrate-v3] --dry-run — no files written.")
        return 0

    if not args.auto:
        try:
            ans = input("Apply? [Y/n] ").strip().lower()
        except EOFError:
            ans = "y"
        if ans and ans not in ("y", "yes"):
            print("[sdlc migrate-v3] cancelled.")
            return 0

    # Apply.
    for kind, _desc in changes:
        if kind == "backup":
            bak_path.write_text(rules_path.read_text(encoding="utf-8"), encoding="utf-8")
            print(f"  [ok] backed up to {bak_path.relative_to(target)}")
        elif kind == "replace":
            pkg_rules = resources.files("sdlc_framework").joinpath("scaffold").joinpath("automation").joinpath("rules.json")
            with resources.as_file(pkg_rules) as real_path:
                rules_path.write_text(real_path.read_text(encoding="utf-8"), encoding="utf-8")
            print(f"  [ok] replaced rules.json with v3")
        elif kind == "verify-keys":
            vdata = json.loads(verifications.read_text(encoding="utf-8"))
            renamed: dict = {}
            for key, value in vdata.items():
                new_key = _MIGRATE_V3_ID_RENAMES.get(key, key)
                renamed[new_key] = value
            verifications.write_text(json.dumps(renamed, indent=2), encoding="utf-8")
            print(f"  [ok] renamed verification keys")
        elif kind == "signoff-rename":
            for old_name, new_name in _MIGRATE_V3_SIGNOFF_RENAMES.items():
                old = signoffs_dir / old_name
                new = signoffs_dir / new_name
                if old.exists() and not new.exists():
                    old.rename(new)
                    print(f"  [ok] renamed signoff {old_name} → {new_name}")
        elif kind == "project-version":
            text = project_yaml.read_text(encoding="utf-8")
            if "schema_version: 2" in text:
                text = text.replace("schema_version: 2", "schema_version: 3", 1)
            elif "schema_version:2" in text:
                text = text.replace("schema_version:2", "schema_version: 3", 1)
            elif "schema_version" not in text:
                text = "schema_version: 3\n" + text
            project_yaml.write_text(text, encoding="utf-8")
            print(f"  [ok] project.yaml schema_version → 3")

    print()
    print("[sdlc migrate-v3] done. Run `sdlc scan --print` to see your new phase model.")
    print("[sdlc migrate-v3] backup at automation/rules.json.v2.bak (delete when comfortable).")
    return 0


def _cmd_verify(argv: list[str]) -> int:
    """Verify a Phase 1/2/4 artifact: append `<!-- sdlc:verified-by: ... -->`
    marker to all files matching the rule's glob, and record in
    automation/.verifications.json.

    Usage:
        sdlc verify <item-id> [--name=<who>] [--auto]
    --auto sets the marker name to `imported-from-existing` (used by `sdlc adopt`).
    """
    parser = argparse.ArgumentParser(prog="sdlc verify")
    parser.add_argument("item_id", help="DoD item id to verify (e.g. prd-exists)")
    parser.add_argument("--name", default=None, help="Verifier name (default: git config user.name)")
    parser.add_argument("--auto", action="store_true",
                        help="Mark as imported-from-existing (for retrofits via `sdlc adopt`)")
    args = parser.parse_args(argv)

    target = Path.cwd()
    rules_path = target / "automation" / "rules.json"
    if not rules_path.exists():
        print("[sdlc verify] automation/rules.json not found. Run `sdlc init` first.")
        return 1

    rules = json.loads(rules_path.read_text())

    # Find the item across phases.
    item = None
    for ph in rules.get("phases") or []:
        for it in ph.get("items") or []:
            if it.get("id") == args.item_id:
                item = it
                break
        if item:
            break
    if item is None:
        print(f"[sdlc verify] item id `{args.item_id}` not in rules.json")
        return 2

    # Find the `verified` check to know which glob to mark.
    verify_check = None
    # rules_by_tier handling — pick tier 2 default if rules_by_tier exists.
    checks = item.get("checks")
    if not checks and item.get("rules_by_tier"):
        checks = item["rules_by_tier"].get("2") or item["rules_by_tier"].get("1") or []
    for c in (checks or []):
        if c.get("type") == "verified":
            verify_check = c
            break
    if verify_check is None:
        print(f"[sdlc verify] item `{args.item_id}` has no `verified` check — nothing to mark.")
        print("[sdlc verify] Hint: only Phase 1/2/4 artifacts use the verify mechanism.")
        return 2

    name = "imported-from-existing" if args.auto else (args.name or _git_user_name())
    ts = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    marker = f"<!-- sdlc:verified-by: {name} {ts} -->"

    glob_pattern = verify_check.get("glob")
    if not glob_pattern:
        print(f"[sdlc verify] item `{args.item_id}` has malformed verify check (no glob).")
        return 2

    # Use engine's globber for consistency.
    from sdlc_framework import engine
    engine.set_root(target)
    matches = engine._glob(glob_pattern)

    if not matches:
        print(f"[sdlc verify] no files match `{glob_pattern}`. Has the AI drafted the artifact yet?")
        return 1

    # Append marker to each match (skip if already present).
    affected = []
    for f in matches:
        text = f.read_text(encoding="utf-8", errors="replace")
        if engine.VERIFY_MARKER_RE.search(text):
            continue
        if not text.endswith("\n"):
            text += "\n"
        text += "\n" + marker + "\n"
        f.write_text(text, encoding="utf-8")
        affected.append(str(f.relative_to(target)))

    # Append to .verifications.json (audit log).
    vlog = target / "automation" / ".verifications.json"
    log_data = {}
    if vlog.exists():
        try:
            log_data = json.loads(vlog.read_text(encoding="utf-8"))
        except Exception:
            log_data = {}
    log_data[args.item_id] = {"verified_by": name, "ts": ts, "files": affected}
    vlog.parent.mkdir(parents=True, exist_ok=True)
    vlog.write_text(json.dumps(log_data, indent=2, ensure_ascii=False), encoding="utf-8")

    if affected:
        print(f"[sdlc verify] verified `{args.item_id}` as {name}")
        for f in affected:
            print(f"     · marker added to {f}")
    else:
        print(f"[sdlc verify] item `{args.item_id}` was already verified — no change.")
    return 0


_HIGH_RISK_KEYWORDS = ["auth", "crypto", "payment", "secrets", "iam", "migration"]


def _cmd_auto_step(argv: list[str]) -> int:
    """One step of the autopilot loop. Returns JSON describing the next action.

    Output shape:
        {
          "action": "invoke" | "stop" | "done",
          "agent": "<subagent-name>" | null,
          "phase": <int> | null,
          "item_id": "<id>" | null,
          "item_label": "<label>" | null,
          "stage": "<stage>" | null,        // for Phase 3 tasks
          "stop_reason": "verify_needed" | "gate" | "clarification" |
                         "high_risk" | "review_pending" | null,
          "instruction": "<paste-ready prompt for the AI>" | null,
          "user_action": "<what the human must do to unblock>" | null
        }

    The slash command `/sdlc-auto` calls this in a loop until action == "stop"
    or "done". Each invocation rescans state, so the loop is stateless.
    """
    parser = argparse.ArgumentParser(prog="sdlc auto-step")
    args = parser.parse_args(argv)

    target = Path.cwd()
    state_path = target / "automation" / "state.json"

    # Always re-scan to get fresh state.
    from sdlc_framework import engine
    engine.set_root(target)
    rules_path = target / "automation" / "rules.json"
    if not rules_path.exists():
        out = {"action": "stop", "stop_reason": "no_project",
               "user_action": "Run `sdlc setup` to scaffold the project first."}
        print(json.dumps(out, indent=2, ensure_ascii=False))
        return 1
    rules = json.loads(rules_path.read_text())
    state = engine.scan(rules)

    # Stop reason 1: open clarifications block all dispatch.
    clarifs = state.get("clarifications") or []
    if clarifs:
        first = clarifs[0]
        path = first.get("file") or first.get("title")
        out = {
            "action": "stop",
            "stop_reason": "clarification",
            "phase": None,
            "item_id": None,
            "user_action": f"Resolve the clarification at {path} (change `STATUS: open` to `STATUS: resolved`), then re-run `/sdlc-auto`.",
        }
        print(json.dumps(out, indent=2, ensure_ascii=False))
        return 0

    # Walk phases in order; collect first pending item + any STOP signal.
    for ph in state.get("phases") or []:
        if ph.get("complete"):
            continue

        # Phase 3 special case: when we *would* enter Phase 3 but no tasks are
        # bootstrapped yet, the loop would otherwise fall through silently.
        # Try inline bootstrap; fall back to a tasks_empty stop with a hint.
        if (ph.get("id") == 3
                and ph.get("tasks_total", 0) == 0
                and ph.get("setup_done", 0) == ph.get("setup_total", 0)):
            story_file = target / "01-Planning" / "02-User-Stories.md"
            bootstrap_failure_reason = None
            if not story_file.exists():
                bootstrap_failure_reason = (
                    f"`{story_file.relative_to(target)}` not found"
                )
            else:
                rc = _cmd_tasks(["bootstrap"])
                if rc != 0:
                    bootstrap_failure_reason = (
                        "`sdlc tasks bootstrap` returned a non-zero exit code "
                        "(likely no `## Story:` headings found in the user stories file)"
                    )
                else:
                    # Re-scan: state now has Phase 3 tasks injected.
                    state = engine.scan(rules)
                    # Refresh `ph` from the new state so the inner loop sees tasks.
                    ph = next(
                        (p for p in state.get("phases") or [] if p.get("id") == 3),
                        ph,
                    )
                    if ph.get("tasks_total", 0) == 0:
                        bootstrap_failure_reason = (
                            "bootstrap ran but produced 0 tasks "
                            "(no `## Story:` headings parsed)"
                        )

            if bootstrap_failure_reason:
                out = {
                    "action": "stop",
                    "stop_reason": "tasks_empty",
                    "phase": 3,
                    "item_id": None,
                    "user_action": (
                        f"Phase 3 has no tasks and we could not bootstrap them automatically "
                        f"({bootstrap_failure_reason}). Draft user stories at "
                        f"`01-Planning/02-User-Stories.md` (one `## Story: <title>` per story), "
                        f"then run `sdlc tasks bootstrap` and re-run `/sdlc-auto`."
                    ),
                }
                print(json.dumps(out, indent=2, ensure_ascii=False))
                return 0

        for it in ph.get("items") or []:
            if it.get("done"):
                continue

            # Stop reason 2: gate.
            if it.get("gate"):
                gate_id = it["gate"]
                gate = next((g for g in state.get("gates") or [] if g["id"] == gate_id), {})
                approvers = ", ".join(gate.get("approvers_required") or [])
                out = {
                    "action": "stop",
                    "stop_reason": "gate",
                    "phase": ph["id"],
                    "item_id": it["id"],
                    "item_label": it["label"],
                    "user_action": f"Approve gate `{gate_id}` by writing `automation/signoffs/{gate_id}.yaml` with `approved: true` (approvers: {approvers}). Then re-run `/sdlc-auto`.",
                }
                print(json.dumps(out, indent=2, ensure_ascii=False))
                return 0

            # Stop reason 3: high-risk path.
            label = (it.get("label") or "").lower() + " " + (it.get("id") or "").lower()
            if any(h in label for h in _HIGH_RISK_KEYWORDS):
                out = {
                    "action": "stop",
                    "stop_reason": "high_risk",
                    "phase": ph["id"],
                    "item_id": it["id"],
                    "item_label": it["label"],
                    "user_action": f"`{it['id']}` touches a high-risk path (auth/crypto/payment/secrets/migrations). Confirm explicitly that you want the AI to proceed, then re-run `/sdlc-auto` (or `/sdlc-next` for single-step).",
                }
                print(json.dumps(out, indent=2, ensure_ascii=False))
                return 0

            # Stop reason 4: Phase 3 task at `review` stage = waiting for human merge.
            if it.get("stage") == "review":
                out = {
                    "action": "stop",
                    "stop_reason": "review_pending",
                    "phase": ph["id"],
                    "item_id": it["id"],
                    "item_label": it["label"],
                    "stage": "review",
                    "user_action": f"Task `{it['id']}` has a PR open. Review and merge it, then re-run `/sdlc-auto`.",
                }
                print(json.dumps(out, indent=2, ensure_ascii=False))
                return 0

            # Stop reason 5: Phase 1/2/4 artifact drafted but not verified.
            #   The AI just drafted in a previous loop iteration. Pause for user to verify.
            if it.get("drafted") and not it.get("verified") and not it.get("stage"):
                out = {
                    "action": "stop",
                    "stop_reason": "verify_needed",
                    "phase": ph["id"],
                    "item_id": it["id"],
                    "item_label": it["label"],
                    "user_action": f"Artifact `{it['id']}` is drafted but awaits your verify. Review the file then run `sdlc verify {it['id']}` (or paste the marker `<!-- sdlc:verified-by: <name> <iso-date> -->` at the bottom). Then re-run `/sdlc-auto`.",
                }
                print(json.dumps(out, indent=2, ensure_ascii=False))
                return 0

            # Otherwise: invoke the right subagent.
            agent = (
                it.get("next_subagent")     # Phase 3 task stage agent
                or it.get("agent")           # per-item override
                or engine.PHASE_AGENT_MAP.get(ph["id"], "orchestrator")
            )
            stage = it.get("stage")
            item_id = it["id"]
            label = it.get("label") or item_id
            instruction = (
                f"Use the {agent} subagent. Read agents/<role>.md for the role spec "
                f"and automation/rules.json item `{item_id}` for evidence requirements. "
                f"Write the deliverable file (NOT into templates/). "
                + ("After writing the artifact, append a `<!-- sdlc:verified-by: <name> <iso-date> -->` marker so the user can review and the engine can re-verify on their side. " if not stage else "")
                + ("Stop and write a clarification file under automation/clarifications/ if you hit ambiguity, conflict, gate, or high-risk path. Do NOT modify code outside this item's scope.")
            )
            out = {
                "action": "invoke",
                "agent": agent,
                "phase": ph["id"],
                "item_id": item_id,
                "item_label": label,
                "stage": stage,
                "stop_reason": None,
                "instruction": instruction,
            }
            print(json.dumps(out, indent=2, ensure_ascii=False))
            return 0

    # No pending items found = done.
    out = {"action": "done", "stop_reason": None,
           "user_action": "All five phases complete. 🎉"}
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0


def _cmd_resume(argv: list[str]) -> int:
    """Print 'where you are' + last activity + next action. Use after stepping away."""
    parser = argparse.ArgumentParser(prog="sdlc resume")
    parser.add_argument("--json", action="store_true", help="Machine-readable output.")
    args = parser.parse_args(argv)

    target = Path.cwd()
    state_path = target / "automation" / "state.json"
    if not state_path.exists():
        print("[sdlc resume] state.json not found. Run `sdlc scan` first.")
        return 1

    state = json.loads(state_path.read_text())
    project = state.get("project") or {}
    runs = state.get("agent_runs") or []
    nxt = _next_pending(state)
    clarifs = state.get("clarifications") or []
    gates = [g for g in (state.get("gates") or []) if not g.get("approved")]

    last_done = next((r for r in runs if r.get("status") == "done"), None)
    last_any = runs[0] if runs else None

    if args.json:
        out = {
            "project": project.get("name"),
            "overall_pct": state.get("overall_pct"),
            "total_done": state.get("total_done"),
            "total_all": state.get("total_all"),
            "current": (
                {"phase": nxt[0], "item_id": nxt[1]["id"], "item_label": nxt[1]["label"]}
                if nxt else None
            ),
            "last_activity": last_any,
            "open_clarifications": len(clarifs),
            "pending_gates": len(gates),
        }
        print(json.dumps(out, indent=2, ensure_ascii=False))
        return 0

    name = project.get("name") or "(unnamed project)"
    pct = state.get("overall_pct", 0)
    done = state.get("total_done", 0)
    total = state.get("total_all", 0)

    print(f"📍 {name} — {pct}% done ({done}/{total} items)")

    if nxt is not None:
        phase_id, item = nxt
        stage = item.get("stage")
        stage_suffix = f" (stage: {stage})" if stage else ""
        print(f"⏳ Currently pending: phase {phase_id} · {item['id']} — {item['label']}{stage_suffix}")
    else:
        print("🎉 All phases complete. Nothing pending.")

    if last_done or last_any:
        r = last_done or last_any
        from datetime import datetime, timezone
        try:
            t = datetime.strptime(r["ts"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
            ago = datetime.now(timezone.utc) - t
            sec = int(ago.total_seconds())
            if sec < 60: rel = f"{sec}s ago"
            elif sec < 3600: rel = f"{sec // 60}m ago"
            elif sec < 86400: rel = f"{sec // 3600}h ago"
            else: rel = f"{sec // 86400}d ago"
        except Exception:
            rel = r.get("ts", "?")
        verb = "finished" if r.get("status") == "done" else r.get("status", "ran")
        print(f"🕐 Last activity: {r['agent']} {verb} `{r['item_id']}` · {rel}")
    else:
        print("🕐 No agent activity yet")

    if clarifs:
        print(f"✋ {len(clarifs)} open clarification(s):")
        for c in clarifs[:5]:
            print(f"     · {c.get('file') or c.get('title')}")
    if gates:
        print(f"🔒 {len(gates)} pending gate(s):")
        for g in gates[:5]:
            print(f"     · {g['id']} (phase {g.get('phase', '?')}) — needs {', '.join(g.get('approvers_required') or [])}")

    print()
    print("Next steps:")
    if clarifs:
        print(f"  → Resolve clarification first: edit {clarifs[0].get('file', '?')}")
        print("    Change `STATUS: open` → `STATUS: resolved`, then `sdlc scan`.")
    elif gates:
        gid = gates[0]["id"]
        print(f"  → Approve gate `{gid}` by writing automation/signoffs/{gid}.yaml")
        print("    with `approved: true`, then `sdlc scan`.")
    elif nxt is not None:
        print(f"  → /sdlc-next  (in your AI tool)")
        print(f"     OR sdlc next  (from terminal — prints a paste-ready prompt)")
    else:
        print("  → Done. Consider `sdlc dashboard` to admire your handiwork. 🎉")
    return 0


def _cmd_next(argv: list[str]) -> int:
    """Print a paste-ready instruction for the next pending DoD item."""
    parser = argparse.ArgumentParser(prog="sdlc next")
    parser.add_argument("--json", action="store_true", help="Machine-readable output.")
    args = parser.parse_args(argv)

    target = Path.cwd()
    state_path = target / "automation" / "state.json"
    if not state_path.exists():
        print("[sdlc next] state.json not found. Run `sdlc scan` first.")
        return 1

    state = json.loads(state_path.read_text())
    nxt = _next_pending(state)
    if nxt is None:
        msg = "All DoD items are done. Nothing to dispatch."
        print("🎉  " + msg)
        return 0
    phase_id, item = nxt
    # Resolution order: stage-specific subagent (Phase 3 task) > item.agent override > phase default.
    agent = (
        item.get("next_subagent")
        or item.get("agent")
        or _PHASE_AGENT.get(phase_id, "orchestrator")
    )
    role_file = f"agents/{_PHASE_FILE.get(phase_id, 'orchestrator.md')}"
    stage = item.get("stage")

    if args.json:
        out = {
            "phase": phase_id,
            "item_id": item["id"],
            "item_label": item["label"],
            "agent": agent,
            "role_file": role_file,
        }
        if stage:
            out["stage"] = stage
        print(json.dumps(out, indent=2, ensure_ascii=False))
        return 0

    stage_suffix = f" (stage: {stage})" if stage else ""
    print(f"🎯 Next pending: phase {phase_id} · {item['id']} — {item['label']}{stage_suffix}")
    print()
    print("📋 Open this folder in your AI coding tool and paste:")
    print()
    print("─" * 64)
    print(f"Use the {agent} subagent. Read automation/rules.json item")
    print(f"`{item['id']}` and write the deliverable file that satisfies")
    print("its checks. Do not edit anything outside the deliverable for")
    print("this item. Stop and write a clarification file under")
    print("automation/clarifications/ if you hit ambiguity, conflict,")
    print("gate, or a high-risk path.")
    print("─" * 64)
    print()
    print("(\"Use the <name> subagent\" forces Claude Code to invoke the")
    print(" matching .claude/agents/<name>.md and bypass any plugin skills")
    print(" that might also match the prompt.)")
    print()
    fail_msgs = [c["msg"] for c in item.get("checks", []) if not c.get("ok")]
    if fail_msgs:
        print("Why it's pending:")
        for m in fail_msgs[:3]:
            print(f"  · {m}")
        print()
    print(f"After the AI writes the file, verify with: sdlc scan --print")
    return 0


def _cmd_tasks(argv: list[str]) -> int:
    """sdlc tasks <bootstrap|list|new|rm> — manage Phase 3 task definitions."""
    parser = argparse.ArgumentParser(prog="sdlc tasks")
    sub = parser.add_subparsers(dest="action", required=True)

    sub.add_parser("list")
    p_new = sub.add_parser("new")
    p_new.add_argument("task_id")
    p_new.add_argument("--label", default=None)
    p_new.add_argument("--code-glob", default=None)
    p_new.add_argument("--test-glob", default=None)
    p_new.add_argument("--pr-branch", default=None)
    p_new.add_argument("--priority", default="medium")
    p_rm = sub.add_parser("rm")
    p_rm.add_argument("task_id")
    p_boot = sub.add_parser("bootstrap")
    p_boot.add_argument("--story-file", default=None,
                        help="User stories file (default: 01-Planning/02-User-Stories.md)")

    args = parser.parse_args(argv)
    target = Path.cwd()
    tasks_dir = target / "automation" / "tasks"

    if args.action == "list":
        from sdlc_framework.tasks_loader import load_tasks, detect_stage
        tasks = load_tasks(target)
        if not tasks:
            print("[sdlc tasks] no tasks declared yet. Run `sdlc tasks bootstrap` or `sdlc tasks new <id>`.")
            return 0
        for t in tasks:
            stage = detect_stage(t, target)
            print(f"  · {t['id']:30s} {stage:14s} priority={t.get('priority','medium'):6s} {t.get('label','')}")
        return 0

    if args.action == "new":
        tasks_dir.mkdir(parents=True, exist_ok=True)
        f = tasks_dir / f"{args.task_id}.yaml"
        if f.exists():
            print(f"[sdlc tasks] task {args.task_id} already exists at {f}")
            return 1
        ts = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        code_glob = args.code_glob or f"src/{args.task_id}/**/*.{{ts,py,go}}"
        test_glob = args.test_glob or f"src/{args.task_id}/**/*.{{test,spec,_test}}.{{ts,py,go}}"
        body = (
            f"id: {args.task_id}\n"
            f'label: "{args.label or args.task_id}"\n'
            f"priority: {args.priority}\n"
            f'code_glob: "{code_glob}"\n'
            f'test_glob: "{test_glob}"\n'
        )
        if args.pr_branch:
            body += f"pr_branch: {args.pr_branch}\n"
        body += f"created_at: {ts}\ncreated_by: {_git_user_name()}\n"
        f.write_text(body, encoding="utf-8")
        print(f"[sdlc tasks] created {f.relative_to(target)}")
        return 0

    if args.action == "rm":
        f = tasks_dir / f"{args.task_id}.yaml"
        if not f.exists():
            print(f"[sdlc tasks] task {args.task_id} not found")
            return 1
        f.unlink()
        print(f"[sdlc tasks] removed {f.relative_to(target)}")
        return 0

    if args.action == "bootstrap":
        story_file = Path(args.story_file) if args.story_file else (target / "01-Planning" / "02-User-Stories.md")
        if not story_file.exists():
            print(f"[sdlc tasks bootstrap] {story_file} not found. Pass --story-file=<path> or draft user stories first.")
            return 1
        text = story_file.read_text(encoding="utf-8")
        import re as _re
        stories = _re.findall(r"^##\s+(?:Story|US|User Story)\s*:?\s*(.+)$", text, _re.MULTILINE)
        if not stories:
            print(f"[sdlc tasks bootstrap] no `## Story: <title>` headings found in {story_file}")
            return 1
        tasks_dir.mkdir(parents=True, exist_ok=True)
        ts = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        created = 0
        for s in stories:
            slug = _re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:60] or "feature"
            f = tasks_dir / f"{slug}.yaml"
            if f.exists():
                print(f"  [skip] {f.name} already exists")
                continue
            body = (
                f"id: {slug}\n"
                f'label: "{s.strip()}"\n'
                f"story: {story_file.relative_to(target).as_posix()}\n"
                f"priority: medium\n"
                f'code_glob: "src/{slug}/**/*.{{ts,tsx,js,jsx,py,go}}"\n'
                f'test_glob: "src/{slug}/**/*.{{test,spec,_test}}.{{ts,tsx,js,jsx,py,go}}"\n'
                f"created_at: {ts}\n"
                f"created_by: bootstrap\n"
            )
            f.write_text(body, encoding="utf-8")
            created += 1
            print(f"  [ok] {f.relative_to(target)}")
        print(f"[sdlc tasks bootstrap] created {created} task(s).")
        return 0

    return 2


def _cmd_dashboard(argv: list[str]) -> int:
    """Serve the bundled dashboard HTML against the cwd's state.json."""
    parser = argparse.ArgumentParser(prog="sdlc dashboard")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args(argv)

    target = Path.cwd()
    state_file = target / "dashboard" / "state.json"
    if not state_file.exists():
        print(f"[sdlc dashboard] state.json not found at {state_file}.")
        print("[sdlc dashboard] run `sdlc scan` first.")
        return 1

    # Drop the bundled index.html into ./dashboard/index.html if missing.
    pkg_html = resources.files("sdlc_framework").joinpath("dashboard").joinpath("index.html")
    target_html = target / "dashboard" / "index.html"
    if not target_html.exists():
        with resources.as_file(pkg_html) as real_html:
            target_html.write_bytes(real_html.read_bytes())
        print(f"[sdlc dashboard] wrote {target_html}")

    print(f"[sdlc dashboard] serving http://localhost:{args.port}/dashboard/")
    print(f"[sdlc dashboard] Ctrl-C to stop.")
    cmd = ["python3", "-m", "http.server", str(args.port)]
    return subprocess.run(cmd, cwd=target).returncode


COMMANDS.update({
    "setup": _cmd_setup,
    "start": _cmd_start,
    "next": _cmd_next,
    "verify": _cmd_verify,
    "resume": _cmd_resume,
    "status": _cmd_resume,  # alias
    "where": _cmd_resume,   # alias
    "replan": _cmd_replan,
    "agent-log": _cmd_agent_log,
    "notify": _cmd_notify,
    "gh-issue": _cmd_gh_issue,
    "gh-pr": _cmd_gh_pr,
    "build-ai-configs": _cmd_build_ai_configs,
    "init": _cmd_init,
    "dashboard": _cmd_dashboard,
    "tasks": _cmd_tasks,
    "migrate-v2": _cmd_migrate_v2,
    "migrate-v3": _cmd_migrate_v3,
    "adopt": _cmd_adopt,
    "auto-step": _cmd_auto_step,
})


def main(argv: list[str] | None = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    if not argv or argv[0] in ("--help", "-h"):
        print("usage: sdlc <command> [args]")
        print()
        print("getting-started:")
        print("  setup             scaffold + pick which AI tool(s) to install commands for")
        print("                    (interactive; or --tools=claude-code,cursor,copilot,...)")
        print("  init              just scaffold (no AI-tool selection — use `setup` instead)")
        print("  start \"<idea>\"    save your idea + show how to start (used by /sdlc-start)")
        print("  next              show next pending DoD item (used by /sdlc-next)")
        print("  resume            \"where am I?\" — phase, last activity, what to do next")
        print("                    (aliases: status, where)")
        print("  replan            mark downstream DoD items dirty after a major change")
        print("                    (--scope=requirements|ui-ux|tech-stack|scale-nfr|custom, --clear)")
        print("  tasks             manage Phase 3 task definitions")
        print("                    (bootstrap | list | new <id> | rm <id>)")
        print("  verify <item-id>  mark a Phase 1/2/4 artifact as verified")
        print("                    (--name=<who> | --auto for retrofits)")
        print("  migrate-v2        upgrade a v0.6.x project to the v2 5-phase model")
        print("                    (--auto | --dry-run)")
        print("  migrate-v3        upgrade a v0.7/v0.8 project to v3 (rename + reorder)")
        print("                    (--auto | --dry-run)")
        print("  adopt             retrofit SDLC on an existing running project")
        print("                    (auto-detects PRDs, designs, code, runbooks; auto-verifies)")
        print("  auto-step         one step of the autopilot loop (used by /sdlc-auto)")
        print("                    returns JSON: action=invoke|stop|done + stop_reason + agent")
        print()
        print("workflow:")
        print("  scan              run engine, write state.json")
        print("  dispatch          read state.json and print next-agent brief")
        print("  dashboard         serve dashboard on --port (default 8765)")
        print()
        print("integrations:")
        print("  agent-log         start|done|fail wrapper for activity log")
        print("  notify            kind id title body — fire desktop notification")
        print("  gh-issue          --clarification PATH | --gate ID")
        print("  gh-pr             [--ready] [--base BRANCH]")
        print("  build-ai-configs  regenerate AI tool configs from shared sources")
        print()
        print("misc:")
        print("  --version         print version")
        return 0

    if argv[0] in ("--version", "-V"):
        print(f"sdlc {__version__}")
        return 0

    cmd = argv[0]
    rest = argv[1:]
    fn = COMMANDS.get(cmd)
    if fn is None:
        print(f"sdlc: unknown command: {cmd}", file=sys.stderr)
        return 2
    return fn(rest)


if __name__ == "__main__":
    sys.exit(main())
