---
mode: agent
description: Autopilot — auto-run through pending DoD items until a STOP condition.
---

The user wants the SDLC framework to run on autopilot through pending items.

## Loop logic

Run `sdlc auto-step` from the integrated terminal. Parse the JSON output:

- `action: "invoke"` → adopt the role from `agents/<role>.md` matching the `agent` field, follow the `instruction`, write the deliverable, then re-run `sdlc auto-step`.
- `action: "stop"` → report the `stop_reason` + `user_action` to the user. Exit the loop. Common reasons: `verify_needed`, `gate`, `clarification`, `high_risk`, `review_pending`.
- `action: "done"` → all phases complete. Celebrate.

Defensive cap: max 20 loop iterations per session.

## Hard rules

- Re-run `sdlc auto-step` between every deliverable. Don't trust your own state — re-scan after each step.
- Never skip a `stop`. The user must take the listed action before re-running.
- Don't dispatch a subagent without first running `auto-step` — the agent name in the JSON is computed from current state.

## Single-step alternative

If the user wants tighter control, run `sdlc next` (or in Copilot, the `sdlc-next` prompt) for one item at a time.
