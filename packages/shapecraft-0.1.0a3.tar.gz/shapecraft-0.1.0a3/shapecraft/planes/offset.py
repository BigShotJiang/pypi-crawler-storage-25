"""Offset plane relative to a base datum plane."""

from typing import Any

BASE_PLANE_IDS = {"Top": "JHD", "Front": "JFC", "Right": "JGC"}


def build_offset_plane_feature(
    *,
    name: str = "Offset Plane",
    base_plane: str = "Top",
    offset: float,
    opposite_direction: bool = False,
) -> dict[str, Any]:
    if base_plane not in BASE_PLANE_IDS:
        raise ValueError(f"base_plane must be one of {sorted(BASE_PLANE_IDS)}, got {base_plane!r}")

    parameters = [
        {
            "btType": "BTMParameterEnum-145",
            "parameterId": "cplaneType",
            "enumName": "CPlaneType",
            "value": "OFFSET",
        },
        {
            "btType": "BTMParameterQueryList-148",
            "parameterId": "entities",
            "queries": [
                {
                    "btType": "BTMIndividualQuery-138",
                    "deterministicIds": [BASE_PLANE_IDS[base_plane]],
                }
            ],
        },
        {
            "btType": "BTMParameterQuantity-147",
            "parameterId": "offset",
            "expression": f"{offset} in",
        },
        {
            "btType": "BTMParameterBoolean-144",
            "parameterId": "oppositeDirection",
            "value": opposite_direction,
        },
    ]

    return {
        "feature": {
            "btType": "BTMFeature-134",
            "featureType": "cPlane",
            "name": name,
            "parameters": parameters,
            "suppressed": False,
        }
    }
