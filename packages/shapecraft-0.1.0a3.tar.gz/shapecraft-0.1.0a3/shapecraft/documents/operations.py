"""Document / workspace / element operations (non-feature)."""

from typing import Any

from shapecraft.core.client import OnshapeClient


async def list_documents(
    client: OnshapeClient,
    limit: int = 20,
    filter_type: str = "all",
    sort_by: str = "modifiedAt",
    sort_order: str = "desc",
) -> list[dict[str, Any]]:
    filter_map = {"all": 0, "owned": 1, "created": 2, "shared": 3}
    params = {
        "limit": limit,
        "filter": filter_map.get(filter_type, 0),
        "sortColumn": sort_by,
        "sortOrder": sort_order,
        "offset": 0,
    }
    resp = await client.get("/documents", params=params)
    return resp.get("items", [])


async def create_document(
    client: OnshapeClient,
    name: str,
    is_public: bool = True,
    description: str = "",
) -> dict[str, Any]:
    body = {"name": name, "isPublic": is_public, "description": description}
    return await client.post("/documents", json=body)


async def create_part_studio(
    client: OnshapeClient,
    did: str,
    wid: str,
    name: str = "Part Studio",
) -> dict[str, Any]:
    path = f"/partstudios/d/{did}/w/{wid}"
    return await client.post(path, json={"name": name})
