"""Document-level query operations (non-feature, read-only)."""

import re
from typing import Any

from shapecraft.core.client import OnshapeClient


async def search_documents(
    client: OnshapeClient, query: str, limit: int = 20
) -> list[dict[str, Any]]:
    """Full-text search across the user's visible documents."""
    resp = await client.get("/documents/search", params={"q": query, "limit": limit})
    return resp.get("items", [])


async def get_document(client: OnshapeClient, did: str) -> dict[str, Any]:
    """Get a single document's metadata."""
    return await client.get(f"/documents/{did}")


async def get_document_summary(client: OnshapeClient, did: str) -> dict[str, Any]:
    """Aggregate document + workspaces + elements per workspace in one call."""
    document = await client.get(f"/documents/{did}")
    workspaces = await client.get(f"/documents/d/{did}/workspaces")
    workspace_details: list[dict[str, Any]] = []
    for ws in workspaces:
        elements = await client.get(f"/documents/d/{did}/w/{ws['id']}/elements")
        workspace_details.append({"workspace": ws, "elements": elements})
    return {
        "document": document,
        "workspaces": workspaces,
        "workspace_details": workspace_details,
    }


async def get_elements(
    client: OnshapeClient,
    did: str,
    wid: str,
    element_type: str | None = None,
) -> list[dict[str, Any]]:
    """List elements in a workspace, optionally filtered by elementType."""
    params = {"elementType": element_type} if element_type else None
    return await client.get(f"/documents/d/{did}/w/{wid}/elements", params=params)


async def find_part_studios(
    client: OnshapeClient,
    did: str,
    wid: str,
    name_pattern: str | None = None,
) -> list[dict[str, Any]]:
    """Return only PARTSTUDIO elements, optionally filtered by a regex name pattern."""
    elements = await get_elements(client, did=did, wid=wid, element_type="PARTSTUDIO")
    elements = [e for e in elements if e.get("elementType") == "PARTSTUDIO"]
    if name_pattern is None:
        return elements
    regex = re.compile(name_pattern)
    return [e for e in elements if regex.search(e.get("name", ""))]
