"""Shared helpers for building BTMFeature JSON payloads."""

from typing import Any

from shapecraft.core.client import OnshapeClient
from shapecraft.core.types import DocumentRef, FeatureRef


def make_parameter(param_id: str, value: Any, bt_type: str) -> dict[str, Any]:
    """Wrap a scalar/entity reference in the BTMParameter envelope."""
    return {
        "btType": bt_type,
        "parameterId": param_id,
        "value": value,
    }


def make_query(bt_type: str, **fields: Any) -> dict[str, Any]:
    """Produce an Onshape query object used as a parameter value."""
    return {"btType": bt_type, **fields}


def make_feature(
    *,
    name: str,
    feature_type: str,
    parameters: list[dict[str, Any]],
    bt_type: str = "BTMFeature-134",
) -> dict[str, Any]:
    """Full feature envelope ready to POST to /features."""
    return {
        "feature": {
            "btType": bt_type,
            "featureType": feature_type,
            "name": name,
            "parameters": parameters,
            "suppressed": False,
        }
    }


async def add_feature(
    client: OnshapeClient,
    doc: DocumentRef,
    feature_body: dict[str, Any],
) -> FeatureRef:
    resp = await client.post(doc.partstudio_features_path(), json=feature_body)
    feat = resp.get("feature", {})
    return FeatureRef(
        feature_id=feat.get("featureId", ""),
        name=feat.get("name", ""),
    )
