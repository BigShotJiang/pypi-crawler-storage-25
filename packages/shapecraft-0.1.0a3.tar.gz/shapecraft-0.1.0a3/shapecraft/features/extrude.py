"""Extrude feature builder with symmetric / reverse support (v0.1 scope)."""

from typing import Any

VALID_OPERATIONS = {"NEW", "ADD", "REMOVE", "INTERSECT"}


def build_extrude_feature(
    *,
    name: str = "Extrude",
    sketch_feature_id: str,
    depth: float,
    operation: str = "NEW",
    symmetric: bool = False,
    reverse: bool = False,
) -> dict[str, Any]:
    if operation not in VALID_OPERATIONS:
        raise ValueError(f"operation must be one of {sorted(VALID_OPERATIONS)}")

    parameters: list[dict[str, Any]] = [
        {
            "btType": "BTMParameterEnum-145",
            "parameterId": "operationType",
            "enumName": "NewBodyOperationType",
            "value": operation,
        },
        {
            "btType": "BTMParameterQueryList-148",
            "parameterId": "entities",
            "queries": [
                {
                    "btType": "BTMIndividualQuery-138",
                    "featureId": sketch_feature_id,
                }
            ],
        },
        {
            "btType": "BTMParameterQuantity-147",
            "parameterId": "depth",
            "expression": f"{depth} in",
        },
        {
            "btType": "BTMParameterBoolean-144",
            "parameterId": "symmetric",
            "value": symmetric,
        },
        {
            "btType": "BTMParameterBoolean-144",
            "parameterId": "oppositeDirection",
            "value": reverse,
        },
    ]

    return {
        "feature": {
            "btType": "BTMFeature-134",
            "featureType": "extrude",
            "name": name,
            "parameters": parameters,
            "suppressed": False,
        }
    }
