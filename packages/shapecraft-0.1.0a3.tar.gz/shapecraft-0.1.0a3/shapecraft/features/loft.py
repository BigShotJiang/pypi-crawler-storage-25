"""Loft feature that fits a solid through ordered sketch profiles."""

from typing import Any

VALID_OPERATIONS = {"NEW", "ADD", "REMOVE", "INTERSECT"}


def build_loft_feature(
    *,
    name: str = "Loft",
    profile_feature_ids: list[str],
    operation: str = "NEW",
    closed: bool = False,
) -> dict[str, Any]:
    if len(profile_feature_ids) < 2:
        raise ValueError("loft requires at least 2 profile sketches")
    if operation not in VALID_OPERATIONS:
        raise ValueError(f"operation must be one of {sorted(VALID_OPERATIONS)}")

    profiles_param = {
        "btType": "BTMParameterQueryList-148",
        "parameterId": "profiles",
        "queries": [
            {
                "btType": "BTMIndividualQuery-138",
                "featureId": fid,
            }
            for fid in profile_feature_ids
        ],
    }

    parameters = [
        {
            "btType": "BTMParameterEnum-145",
            "parameterId": "operationType",
            "enumName": "NewBodyOperationType",
            "value": operation,
        },
        profiles_param,
        {
            "btType": "BTMParameterBoolean-144",
            "parameterId": "closed",
            "value": closed,
        },
    ]

    return {
        "feature": {
            "btType": "BTMFeature-134",
            "featureType": "loft",
            "name": name,
            "parameters": parameters,
            "suppressed": False,
        }
    }
