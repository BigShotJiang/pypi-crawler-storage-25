"""shapecraft MCP stdio server.

Registers the v0.1.0-alpha tool set. Extended by follow-up batches.
"""

import asyncio
import sys
from typing import Any

from loguru import logger
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from shapecraft.core.client import OnshapeClient
from shapecraft.core.types import Credentials, DocumentRef
from shapecraft.documents.operations import (
    create_document,
    create_part_studio,
    list_documents,
)
from shapecraft.documents.query import (
    find_part_studios,
    get_document,
    get_document_summary,
    get_elements,
    search_documents,
)
from shapecraft.features._base import add_feature
from shapecraft.features.extrude import build_extrude_feature
from shapecraft.features.loft import build_loft_feature
from shapecraft.partstudio.query import delete_feature, get_features, get_parts
from shapecraft.planes.offset import build_offset_plane_feature
from shapecraft.sketch.rectangle import build_sketch_rectangle_feature
from shapecraft.sketch.spline import build_sketch_spline_feature

logger.remove()
logger.add(sys.stderr, level="INFO")

app = Server("shapecraft")
_creds = Credentials.from_env()
_client = OnshapeClient(access_key=_creds.access_key, secret_key=_creds.secret_key)


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="shapecraft_list_documents",
            description="List Onshape documents.",
            inputSchema={
                "type": "object",
                "properties": {
                    "limit": {"type": "integer", "default": 20},
                    "filter_type": {
                        "type": "string",
                        "enum": ["all", "owned", "created", "shared"],
                        "default": "all",
                    },
                },
            },
        ),
        Tool(
            name="shapecraft_create_document",
            description="Create a new (public) Onshape document.",
            inputSchema={
                "type": "object",
                "required": ["name"],
                "properties": {
                    "name": {"type": "string"},
                    "is_public": {"type": "boolean", "default": True},
                    "description": {"type": "string", "default": ""},
                },
            },
        ),
        Tool(
            name="shapecraft_create_part_studio",
            description="Create a Part Studio in a workspace.",
            inputSchema={
                "type": "object",
                "required": ["did", "wid", "name"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "name": {"type": "string"},
                },
            },
        ),
        Tool(
            name="shapecraft_sketch_rectangle",
            description="Sketch a rectangle on Top/Front/Right plane.",
            inputSchema={
                "type": "object",
                "required": ["did", "wid", "eid", "corner1", "corner2"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "eid": {"type": "string"},
                    "plane": {
                        "type": "string",
                        "enum": ["Top", "Front", "Right"],
                        "default": "Top",
                    },
                    "corner1": {
                        "type": "array",
                        "items": {"type": "number"},
                        "minItems": 2,
                        "maxItems": 2,
                    },
                    "corner2": {
                        "type": "array",
                        "items": {"type": "number"},
                        "minItems": 2,
                        "maxItems": 2,
                    },
                    "name": {"type": "string", "default": "Sketch"},
                },
            },
        ),
        Tool(
            name="shapecraft_sketch_spline",
            description="Sketch an interpolated spline through ordered points.",
            inputSchema={
                "type": "object",
                "required": ["did", "wid", "eid", "points"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "eid": {"type": "string"},
                    "plane": {
                        "type": "string",
                        "enum": ["Top", "Front", "Right"],
                        "default": "Top",
                    },
                    "points": {
                        "type": "array",
                        "items": {
                            "type": "array",
                            "items": {"type": "number"},
                            "minItems": 2,
                            "maxItems": 2,
                        },
                        "minItems": 2,
                    },
                    "name": {"type": "string", "default": "Sketch Spline"},
                },
            },
        ),
        Tool(
            name="shapecraft_offset_plane",
            description="Create an offset datum plane from a base plane.",
            inputSchema={
                "type": "object",
                "required": ["did", "wid", "eid", "offset"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "eid": {"type": "string"},
                    "base_plane": {
                        "type": "string",
                        "enum": ["Top", "Front", "Right"],
                        "default": "Top",
                    },
                    "offset": {"type": "number"},
                    "opposite_direction": {"type": "boolean", "default": False},
                    "name": {"type": "string", "default": "Offset Plane"},
                },
            },
        ),
        Tool(
            name="shapecraft_extrude",
            description="Extrude a sketch feature with optional symmetric/reverse.",
            inputSchema={
                "type": "object",
                "required": ["did", "wid", "eid", "sketch_feature_id", "depth"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "eid": {"type": "string"},
                    "sketch_feature_id": {"type": "string"},
                    "depth": {"type": "number"},
                    "operation": {
                        "type": "string",
                        "enum": ["NEW", "ADD", "REMOVE", "INTERSECT"],
                        "default": "NEW",
                    },
                    "symmetric": {"type": "boolean", "default": False},
                    "reverse": {"type": "boolean", "default": False},
                    "name": {"type": "string", "default": "Extrude"},
                },
            },
        ),
        Tool(
            name="shapecraft_loft",
            description="Loft a solid through two or more sketch profiles.",
            inputSchema={
                "type": "object",
                "required": ["did", "wid", "eid", "profile_feature_ids"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "eid": {"type": "string"},
                    "profile_feature_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "minItems": 2,
                    },
                    "operation": {
                        "type": "string",
                        "enum": ["NEW", "ADD", "REMOVE", "INTERSECT"],
                        "default": "NEW",
                    },
                    "closed": {"type": "boolean", "default": False},
                    "name": {"type": "string", "default": "Loft"},
                },
            },
        ),
        Tool(
            name="shapecraft_search_documents",
            description="Full-text search the user's Onshape documents.",
            inputSchema={
                "type": "object",
                "required": ["query"],
                "properties": {
                    "query": {"type": "string"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="shapecraft_get_document",
            description="Get a document's metadata by ID.",
            inputSchema={
                "type": "object",
                "required": ["did"],
                "properties": {"did": {"type": "string"}},
            },
        ),
        Tool(
            name="shapecraft_get_document_summary",
            description="Get document metadata + all workspaces + all elements in one call.",
            inputSchema={
                "type": "object",
                "required": ["did"],
                "properties": {"did": {"type": "string"}},
            },
        ),
        Tool(
            name="shapecraft_get_elements",
            description="List all elements in a workspace, optionally filtered by type (PARTSTUDIO, ASSEMBLY, etc.).",
            inputSchema={
                "type": "object",
                "required": ["did", "wid"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "element_type": {"type": "string"},
                },
            },
        ),
        Tool(
            name="shapecraft_find_part_studios",
            description="List Part Studio elements in a workspace, optionally filtered by a regex on element name.",
            inputSchema={
                "type": "object",
                "required": ["did", "wid"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "name_pattern": {"type": "string"},
                },
            },
        ),
        Tool(
            name="shapecraft_get_features",
            description="Get the full feature list of a Part Studio (sketches, extrudes, etc.).",
            inputSchema={
                "type": "object",
                "required": ["did", "wid", "eid"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "eid": {"type": "string"},
                },
            },
        ),
        Tool(
            name="shapecraft_get_parts",
            description="List solid/surface parts in a Part Studio.",
            inputSchema={
                "type": "object",
                "required": ["did", "wid", "eid"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "eid": {"type": "string"},
                },
            },
        ),
        Tool(
            name="shapecraft_delete_feature",
            description="Delete a feature from a Part Studio by its feature ID.",
            inputSchema={
                "type": "object",
                "required": ["did", "wid", "eid", "feature_id"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "eid": {"type": "string"},
                    "feature_id": {"type": "string"},
                },
            },
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    logger.info("tool={} args={}", name, arguments)

    if name == "shapecraft_list_documents":
        docs = await list_documents(
            _client,
            limit=arguments.get("limit", 20),
            filter_type=arguments.get("filter_type", "all"),
        )
        return [TextContent(type="text", text=f"{len(docs)} documents: {docs}")]

    if name == "shapecraft_create_document":
        d = await create_document(
            _client,
            name=arguments["name"],
            is_public=arguments.get("is_public", True),
            description=arguments.get("description", ""),
        )
        return [TextContent(type="text", text=f"Created document {d.get('id')}")]

    if name == "shapecraft_create_part_studio":
        e = await create_part_studio(
            _client,
            did=arguments["did"],
            wid=arguments["wid"],
            name=arguments["name"],
        )
        return [TextContent(type="text", text=f"Created part studio {e.get('id')}")]

    if name == "shapecraft_sketch_rectangle":
        doc = DocumentRef(did=arguments["did"], wid=arguments["wid"], eid=arguments["eid"])
        feat = build_sketch_rectangle_feature(
            name=arguments.get("name", "Sketch"),
            plane=arguments.get("plane", "Top"),
            corner1=tuple(arguments["corner1"]),
            corner2=tuple(arguments["corner2"]),
        )
        ref = await add_feature(_client, doc, feat)
        return [TextContent(type="text", text=f"Sketch {ref.feature_id}")]

    if name == "shapecraft_sketch_spline":
        doc = DocumentRef(did=arguments["did"], wid=arguments["wid"], eid=arguments["eid"])
        feat = build_sketch_spline_feature(
            name=arguments.get("name", "Sketch Spline"),
            plane=arguments.get("plane", "Top"),
            points=[tuple(p) for p in arguments["points"]],
        )
        ref = await add_feature(_client, doc, feat)
        return [TextContent(type="text", text=f"Spline {ref.feature_id}")]

    if name == "shapecraft_offset_plane":
        doc = DocumentRef(did=arguments["did"], wid=arguments["wid"], eid=arguments["eid"])
        feat = build_offset_plane_feature(
            name=arguments.get("name", "Offset Plane"),
            base_plane=arguments.get("base_plane", "Top"),
            offset=arguments["offset"],
            opposite_direction=arguments.get("opposite_direction", False),
        )
        ref = await add_feature(_client, doc, feat)
        return [TextContent(type="text", text=f"Plane {ref.feature_id}")]

    if name == "shapecraft_extrude":
        doc = DocumentRef(did=arguments["did"], wid=arguments["wid"], eid=arguments["eid"])
        feat = build_extrude_feature(
            name=arguments.get("name", "Extrude"),
            sketch_feature_id=arguments["sketch_feature_id"],
            depth=arguments["depth"],
            operation=arguments.get("operation", "NEW"),
            symmetric=arguments.get("symmetric", False),
            reverse=arguments.get("reverse", False),
        )
        ref = await add_feature(_client, doc, feat)
        return [TextContent(type="text", text=f"Extrude {ref.feature_id}")]

    if name == "shapecraft_loft":
        doc = DocumentRef(did=arguments["did"], wid=arguments["wid"], eid=arguments["eid"])
        feat = build_loft_feature(
            name=arguments.get("name", "Loft"),
            profile_feature_ids=arguments["profile_feature_ids"],
            operation=arguments.get("operation", "NEW"),
            closed=arguments.get("closed", False),
        )
        ref = await add_feature(_client, doc, feat)
        return [TextContent(type="text", text=f"Loft {ref.feature_id}")]

    if name == "shapecraft_search_documents":
        docs = await search_documents(
            _client, query=arguments["query"], limit=arguments.get("limit", 20)
        )
        return [TextContent(type="text", text=f"{len(docs)} documents: {docs}")]

    if name == "shapecraft_get_document":
        doc = await get_document(_client, did=arguments["did"])
        return [TextContent(type="text", text=str(doc))]

    if name == "shapecraft_get_document_summary":
        summary = await get_document_summary(_client, did=arguments["did"])
        return [TextContent(type="text", text=str(summary))]

    if name == "shapecraft_get_elements":
        els = await get_elements(
            _client,
            did=arguments["did"],
            wid=arguments["wid"],
            element_type=arguments.get("element_type"),
        )
        return [TextContent(type="text", text=f"{len(els)} elements: {els}")]

    if name == "shapecraft_find_part_studios":
        studios = await find_part_studios(
            _client,
            did=arguments["did"],
            wid=arguments["wid"],
            name_pattern=arguments.get("name_pattern"),
        )
        return [TextContent(type="text", text=f"{len(studios)} part studios: {studios}")]

    if name == "shapecraft_get_features":
        feats = await get_features(
            _client, did=arguments["did"], wid=arguments["wid"], eid=arguments["eid"]
        )
        return [TextContent(type="text", text=str(feats))]

    if name == "shapecraft_get_parts":
        parts = await get_parts(
            _client, did=arguments["did"], wid=arguments["wid"], eid=arguments["eid"]
        )
        return [TextContent(type="text", text=f"{len(parts)} parts: {parts}")]

    if name == "shapecraft_delete_feature":
        await delete_feature(
            _client,
            did=arguments["did"],
            wid=arguments["wid"],
            eid=arguments["eid"],
            feature_id=arguments["feature_id"],
        )
        return [TextContent(type="text", text=f"Deleted feature {arguments['feature_id']}")]

    raise ValueError(f"unknown tool: {name}")


def main() -> None:
    asyncio.run(_run())


async def _run() -> None:
    async with stdio_server() as (read, write):
        await app.run(read, write, app.create_initialization_options())


if __name__ == "__main__":
    main()
