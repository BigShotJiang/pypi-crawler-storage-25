"""Part Studio queries: features, parts, delete feature."""

from typing import Any

from shapecraft.core.client import OnshapeClient


async def get_features(client: OnshapeClient, did: str, wid: str, eid: str) -> dict[str, Any]:
    """Get all features (sketches, extrudes, etc.) in a Part Studio."""
    return await client.get(f"/partstudios/d/{did}/w/{wid}/e/{eid}/features")


async def get_parts(client: OnshapeClient, did: str, wid: str, eid: str) -> list[dict[str, Any]]:
    """Get all solid/surface parts in a Part Studio."""
    return await client.get(f"/parts/d/{did}/w/{wid}/e/{eid}")


async def delete_feature(
    client: OnshapeClient, did: str, wid: str, eid: str, feature_id: str
) -> Any:
    """Delete a feature by its feature ID."""
    return await client.delete(
        f"/partstudios/d/{did}/w/{wid}/e/{eid}/features/featureid/{feature_id}"
    )
