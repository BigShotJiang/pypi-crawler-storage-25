"""Sketch constraint builders (v0.1.0-alpha: coincident only).

v0.1.0-batch-2 adds parallel, perpendicular, tangent, horizontal, vertical, dimension.
"""

from typing import Any


def build_coincident_constraint(
    *,
    sketch_feature_id: str,
    entity_a: str,
    entity_b: str,
) -> dict[str, Any]:
    """Return a BTMSketchConstraint payload to merge into a sketch feature."""
    return {
        "btType": "BTMSketchConstraint-2",
        "sketchFeatureId": sketch_feature_id,
        "constraintType": "COINCIDENT",
        "parameters": [
            {
                "btType": "BTMParameterString-149",
                "parameterId": "localFirst",
                "value": entity_a,
            },
            {
                "btType": "BTMParameterString-149",
                "parameterId": "localSecond",
                "value": entity_b,
            },
        ],
    }
