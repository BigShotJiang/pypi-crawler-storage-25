"""Interpolated spline sketched through ordered points."""

from typing import Any

from shapecraft.sketch.rectangle import PLANE_IDS


def build_sketch_spline_feature(
    *,
    name: str = "Sketch Spline",
    plane: str = "Top",
    points: list[tuple[float, float]],
) -> dict[str, Any]:
    """Return BTMFeature JSON for a spline sketched on a default plane.

    The spline is an interpolated curve passing through the ordered points.
    Coordinates are in inches per Onshape convention.
    """
    if plane not in PLANE_IDS:
        raise ValueError(f"plane must be one of {sorted(PLANE_IDS)}")
    if len(points) < 2:
        raise ValueError("spline requires at least 2 points")

    control = [
        {
            "btType": "BTCurveGeometryInterpolatedSpline-140",
            "pointIndex": i,
            "x": float(x),
            "y": float(y),
        }
        for i, (x, y) in enumerate(points)
    ]

    entity = {
        "btType": "BTMSketchCurve-4",
        "entityId": "spline1",
        "geometry": {
            "btType": "BTCurveGeometryInterpolatedSpline-140",
            "controlPoints": control,
            "isPeriodic": False,
        },
    }

    return {
        "feature": {
            "btType": "BTMSketch-151",
            "featureType": "newSketch",
            "name": name,
            "parameters": [
                {
                    "btType": "BTMParameterQueryList-148",
                    "parameterId": "sketchPlane",
                    "queries": [
                        {
                            "btType": "BTMIndividualQuery-138",
                            "deterministicIds": [PLANE_IDS[plane]],
                        }
                    ],
                }
            ],
            "entities": [entity],
            "suppressed": False,
        }
    }
