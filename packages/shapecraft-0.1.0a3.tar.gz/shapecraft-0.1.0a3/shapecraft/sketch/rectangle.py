"""Rectangle primitive built into a new sketch feature."""

from typing import Any

PLANE_IDS = {"Top": "JHD", "Front": "JFC", "Right": "JGC"}


def build_sketch_rectangle_feature(
    *,
    name: str = "Sketch",
    plane: str = "Top",
    corner1: tuple[float, float],
    corner2: tuple[float, float],
) -> dict[str, Any]:
    """Return BTMFeature JSON for a rectangle sketched on a default plane.

    Coordinates are in inches per Onshape convention. The rectangle is built
    from four line segments with inferred corner coincidence (no explicit
    constraints in this primitive; add via `sketch/constraints.py`).
    """
    if plane not in PLANE_IDS:
        raise ValueError(f"plane must be one of {sorted(PLANE_IDS)}, got {plane!r}")

    x1, y1 = corner1
    x2, y2 = corner2

    entities = [
        _line_segment("line1", (x1, y1), (x2, y1)),
        _line_segment("line2", (x2, y1), (x2, y2)),
        _line_segment("line3", (x2, y2), (x1, y2)),
        _line_segment("line4", (x1, y2), (x1, y1)),
    ]

    return {
        "feature": {
            "btType": "BTMSketch-151",
            "featureType": "newSketch",
            "name": name,
            "parameters": [
                {
                    "btType": "BTMParameterQueryList-148",
                    "parameterId": "sketchPlane",
                    "queries": [
                        {
                            "btType": "BTMIndividualQuery-138",
                            "deterministicIds": [PLANE_IDS[plane]],
                        }
                    ],
                }
            ],
            "entities": entities,
            "suppressed": False,
        }
    }


def _line_segment(
    sketch_id: str, start: tuple[float, float], end: tuple[float, float]
) -> dict[str, Any]:
    return {
        "btType": "BTMSketchCurveSegment-155",
        "entityId": sketch_id,
        "startPointId": f"{sketch_id}.start",
        "endPointId": f"{sketch_id}.end",
        "geometry": {
            "btType": "BTCurveGeometryLine-117",
            "pntX": float(start[0]),
            "pntY": float(start[1]),
            "dirX": 1.0,
            "dirY": 0.0,
        },
        "startParam": 0.0,
        "endParam": float(((end[0] - start[0]) ** 2 + (end[1] - start[1]) ** 2) ** 0.5),
    }
