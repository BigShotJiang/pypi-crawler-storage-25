"""Typed references and credentials."""

import os
from typing import Annotated

from pydantic import BaseModel, Field, StringConstraints

NonEmpty = Annotated[str, StringConstraints(min_length=1)]


class Credentials(BaseModel):
    access_key: NonEmpty
    secret_key: NonEmpty

    @classmethod
    def from_env(cls) -> "Credentials":
        ak = os.getenv("ONSHAPE_ACCESS_KEY")
        sk = os.getenv("ONSHAPE_SECRET_KEY")
        if not ak or not sk:
            raise RuntimeError(
                "ONSHAPE_ACCESS_KEY and ONSHAPE_SECRET_KEY must be set in environment"
            )
        return cls(access_key=ak, secret_key=sk)


class DocumentRef(BaseModel):
    did: NonEmpty = Field(description="Document ID (24 chars)")
    wid: NonEmpty = Field(description="Workspace ID")
    eid: NonEmpty = Field(description="Element ID (Part Studio, Assembly, etc.)")

    def path(self) -> str:
        return f"/documents/{self.did}/w/{self.wid}/e/{self.eid}"

    def partstudio_features_path(self) -> str:
        return f"/partstudios/d/{self.did}/w/{self.wid}/e/{self.eid}/features"


class FeatureRef(BaseModel):
    feature_id: NonEmpty
    name: str = ""
