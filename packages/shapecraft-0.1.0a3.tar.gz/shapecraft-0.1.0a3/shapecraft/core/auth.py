"""HMAC-SHA256 request signing for Onshape API."""

import base64
import hashlib
import hmac
from urllib.parse import urlparse


def sign_request(
    *,
    method: str,
    url: str,
    body: bytes,
    access_key: str,
    secret_key: str,
    nonce: str,
    timestamp: str,
) -> dict[str, str]:
    """Return Authorization/Date/On-Nonce headers per Onshape API key spec.

    Follows the string-to-sign format documented at
    https://onshape-public.github.io/docs/auth/apikeys/.
    """
    parsed = urlparse(url)
    path = parsed.path
    query = parsed.query

    content_type = "application/json" if body else ""

    string_to_sign = "\n".join(
        [
            method.lower(),
            nonce,
            timestamp,
            content_type,
            path,
            query,
        ]
    ).lower()

    signature = hmac.new(
        secret_key.encode("utf-8"),
        string_to_sign.encode("utf-8") + body,
        hashlib.sha256,
    ).digest()
    signature_b64 = base64.b64encode(signature).decode("ascii")

    return {
        "Date": timestamp,
        "On-Nonce": nonce,
        "Authorization": f"On {access_key}:HmacSHA256:{signature_b64}",
    }
