"""HTTP client for the Onshape REST API."""

import asyncio
import json as stdjson
import secrets
from datetime import datetime, timezone
from typing import Any

import httpx
from loguru import logger

from shapecraft.core.auth import sign_request


class OnshapeError(Exception):
    """Raised for any 4xx/5xx response that exceeded retries."""


class OnshapeClient:
    def __init__(
        self,
        access_key: str,
        secret_key: str,
        base_url: str = "https://cad.onshape.com/api/v6",
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        self._access_key = access_key
        self._secret_key = secret_key
        self._base_url = base_url.rstrip("/")
        self._http = httpx.AsyncClient(timeout=timeout)
        self._max_retries = max_retries

    async def aclose(self) -> None:
        await self._http.aclose()

    async def get(self, path: str, params: dict | None = None) -> Any:
        return await self._request("GET", path, params=params)

    async def post(self, path: str, json: dict | None = None) -> Any:
        return await self._request("POST", path, json=json)

    async def delete(self, path: str) -> Any:
        return await self._request("DELETE", path)

    async def _request(
        self,
        method: str,
        path: str,
        params: dict | None = None,
        json: dict | None = None,
    ) -> Any:
        url = f"{self._base_url}{path}"
        body = b"" if json is None else stdjson.dumps(json, separators=(",", ":")).encode("utf-8")
        last_exc: Exception | None = None

        for attempt in range(self._max_retries):
            full_url_for_signing = url if not params else f"{url}?{httpx.QueryParams(params)}"
            headers = sign_request(
                method=method,
                url=full_url_for_signing,
                body=body,
                access_key=self._access_key,
                secret_key=self._secret_key,
                nonce=secrets.token_hex(16),
                timestamp=datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S GMT"),
            )
            headers["Accept"] = "application/json"
            if body:
                headers["Content-Type"] = "application/json"

            try:
                resp = await self._http.request(
                    method, url, params=params, content=body, headers=headers
                )
            except httpx.HTTPError as exc:
                last_exc = exc
                await asyncio.sleep(0.5 * (2**attempt))
                continue

            if resp.status_code >= 500:
                last_exc = OnshapeError(f"{resp.status_code}: {resp.text}")
                await asyncio.sleep(0.5 * (2**attempt))
                continue

            if resp.status_code >= 400:
                raise OnshapeError(f"{resp.status_code}: {resp.text}")

            remaining = resp.headers.get("X-Rate-Limit-Remaining")
            if remaining is not None and int(remaining) < 5:
                logger.warning("Onshape rate limit low: {} remaining", remaining)

            if resp.status_code == 204 or not resp.content:
                return None
            return resp.json()

        raise OnshapeError(f"exceeded {self._max_retries} retries") from last_exc
