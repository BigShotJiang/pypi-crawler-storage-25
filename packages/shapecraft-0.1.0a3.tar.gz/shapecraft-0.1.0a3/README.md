# shapecraft

> Craft real CAD with Claude. Any shape. Any tool.

**shapecraft** gives Claude (Claude Code, Claude Desktop, Anthropic API) a first-class set of tools to drive professional parametric CAD. v0.1.0-alpha targets Onshape and proves the full pipeline with 8 MCP tools — including the first killer upgrades over existing Onshape MCPs: **offset planes**, **sketch splines**, and **loft** — plus a coincident sketch-constraint builder helper (first of seven constraints landing in T1).

## Install

```bash
uvx shapecraft   # or: pip install shapecraft
```

## Register with Claude Code

```bash
claude mcp add shapecraft \
  -s user \
  -e ONSHAPE_ACCESS_KEY=<your_key> \
  -e ONSHAPE_SECRET_KEY=<your_secret> \
  -- uvx shapecraft
```

Get your keys at [dev-portal.onshape.com](https://dev-portal.onshape.com).

## v0.1.0-alpha tool list

- `shapecraft_list_documents`
- `shapecraft_create_document`
- `shapecraft_create_part_studio`
- `shapecraft_sketch_rectangle`
- `shapecraft_sketch_spline` *(NEW vs hedless)*
- `shapecraft_offset_plane` *(NEW)*
- `shapecraft_extrude` with symmetric + reverse flags *(upgraded)*
- `shapecraft_loft` *(NEW)*

Plus `build_coincident_constraint` helper (sketch constraint builder — first of 7 coming in T1).

See the [design spec](docs/superpowers/specs/2026-04-18-shapecraft-design.md) for the full T1 → T3 roadmap.

## Development

```bash
python3 -m venv venv
./venv/bin/pip install -e ".[dev]"
./venv/bin/pytest tests/unit -v
```

Integration tests (`tests/integration/`) hit live Onshape and require `ONSHAPE_ACCESS_KEY`/`ONSHAPE_SECRET_KEY` env vars.

## Releasing

1. Bump version in `pyproject.toml`
2. Update `CHANGELOG.md`
3. `git tag v0.1.0a1 && git push --tags`
4. `release.yml` publishes to PyPI via trusted publishing (configure once at pypi.org)

## License

MIT. See [LICENSE](LICENSE).

## Credits

Inspired by [hedless/onshape-mcp](https://github.com/hedless/onshape-mcp) (MIT per its README) — shapecraft is an independent reimplementation that covers a broader slice of the Onshape REST and FeatureScript API.
