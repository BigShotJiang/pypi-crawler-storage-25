import httpx
import pytest
import respx

from shapecraft.core.client import OnshapeClient
from shapecraft.partstudio.query import delete_feature, get_features, get_parts


@pytest.fixture
def client():
    return OnshapeClient(access_key="AK", secret_key="SK")


@respx.mock
async def test_get_features_returns_list(client):
    respx.get("https://cad.onshape.com/api/v6/partstudios/d/D1/w/W1/e/E1/features").mock(
        return_value=httpx.Response(
            200,
            json={"features": [{"featureId": "F1_0", "name": "Sketch 1"}]},
        )
    )
    feats = await get_features(client, did="D1", wid="W1", eid="E1")
    assert feats["features"][0]["featureId"] == "F1_0"


@respx.mock
async def test_get_parts_returns_list(client):
    respx.get("https://cad.onshape.com/api/v6/parts/d/D1/w/W1/e/E1").mock(
        return_value=httpx.Response(
            200,
            json=[{"partId": "JHD", "name": "Part 1", "bodyType": "solid"}],
        )
    )
    parts = await get_parts(client, did="D1", wid="W1", eid="E1")
    assert parts[0]["partId"] == "JHD"


@respx.mock
async def test_delete_feature_hits_correct_path(client):
    route = respx.delete(
        "https://cad.onshape.com/api/v6/partstudios/d/D1/w/W1/e/E1/features/featureid/FXYZ_0"
    ).mock(return_value=httpx.Response(200, json={}))
    await delete_feature(client, did="D1", wid="W1", eid="E1", feature_id="FXYZ_0")
    assert route.called


@respx.mock
async def test_get_features_empty(client):
    respx.get("https://cad.onshape.com/api/v6/partstudios/d/D1/w/W1/e/E1/features").mock(
        return_value=httpx.Response(200, json={"features": []})
    )
    feats = await get_features(client, did="D1", wid="W1", eid="E1")
    assert feats["features"] == []


@respx.mock
async def test_get_features_preserves_feature_order(client):
    respx.get("https://cad.onshape.com/api/v6/partstudios/d/D1/w/W1/e/E1/features").mock(
        return_value=httpx.Response(
            200,
            json={
                "features": [
                    {"featureId": "F_a", "name": "Sketch 1"},
                    {"featureId": "F_b", "name": "Extrude 1"},
                    {"featureId": "F_c", "name": "Fillet 1"},
                ]
            },
        )
    )
    feats = await get_features(client, did="D1", wid="W1", eid="E1")
    ids = [f["featureId"] for f in feats["features"]]
    assert ids == ["F_a", "F_b", "F_c"]


@respx.mock
async def test_get_parts_multi_body(client):
    respx.get("https://cad.onshape.com/api/v6/parts/d/D1/w/W1/e/E1").mock(
        return_value=httpx.Response(
            200,
            json=[
                {"partId": "PA", "name": "Leg 1", "bodyType": "solid"},
                {"partId": "PB", "name": "Leg 2", "bodyType": "solid"},
            ],
        )
    )
    parts = await get_parts(client, did="D1", wid="W1", eid="E1")
    assert {p["partId"] for p in parts} == {"PA", "PB"}


@respx.mock
async def test_delete_feature_404_raises(client):
    respx.delete(
        "https://cad.onshape.com/api/v6/partstudios/d/D1/w/W1/e/E1/features/featureid/GONE"
    ).mock(return_value=httpx.Response(404, json={"message": "not found"}))
    with pytest.raises(Exception, match="404"):
        await delete_feature(client, did="D1", wid="W1", eid="E1", feature_id="GONE")
