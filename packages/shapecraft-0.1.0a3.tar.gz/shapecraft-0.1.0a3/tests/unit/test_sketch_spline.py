import pytest

from shapecraft.sketch.spline import build_sketch_spline_feature


def test_spline_requires_at_least_two_points():
    with pytest.raises(ValueError):
        build_sketch_spline_feature(plane="Top", points=[(0.0, 0.0)])


def test_spline_feature_has_sketch_type():
    feat = build_sketch_spline_feature(plane="Top", points=[(0, 0), (1, 2), (3, 1)])
    assert feat["feature"]["featureType"] == "newSketch"


def test_spline_preserves_point_order():
    feat = build_sketch_spline_feature(plane="Top", points=[(0.0, 0.0), (4.2, 1.7), (8.0, 0.5)])
    text = repr(feat)
    # Points appear in order in the serialized payload
    first = text.find("4.2")
    second = text.find("8.0")
    assert 0 < first < second
