import pytest

from shapecraft.planes.offset import build_offset_plane_feature


def test_offset_plane_references_base_plane():
    feat = build_offset_plane_feature(name="Plane 1", base_plane="Top", offset=0.5)
    assert feat["feature"]["featureType"] == "cPlane"


def test_offset_plane_encodes_offset_distance():
    feat = build_offset_plane_feature(base_plane="Top", offset=2.5)
    params = {p["parameterId"]: p for p in feat["feature"]["parameters"]}
    assert "2.5" in params["offset"]["expression"]


def test_offset_plane_rejects_unknown_base():
    with pytest.raises(ValueError):
        build_offset_plane_feature(base_plane="Weird", offset=1.0)
