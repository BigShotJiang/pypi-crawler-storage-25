import httpx
import pytest
import respx

from shapecraft.core.auth import sign_request  # noqa: F401 — proves dependency resolves
from shapecraft.core.client import OnshapeClient, OnshapeError


@pytest.fixture
def client():
    return OnshapeClient(
        access_key="AK",
        secret_key="SK",
        base_url="https://cad.onshape.com/api/v6",
    )


@respx.mock
async def test_get_returns_json_on_200(client):
    respx.get("https://cad.onshape.com/api/v6/documents").mock(
        return_value=httpx.Response(200, json={"items": []})
    )
    result = await client.get("/documents")
    assert result == {"items": []}


@respx.mock
async def test_post_sends_body_and_signed_headers(client):
    route = respx.post("https://cad.onshape.com/api/v6/documents").mock(
        return_value=httpx.Response(200, json={"id": "D1"})
    )
    await client.post("/documents", json={"name": "test"})
    req = route.calls[-1].request
    assert req.headers.get("authorization", "").startswith("On AK:HmacSHA256:")
    assert b'"name"' in req.content


@respx.mock
async def test_retries_on_500_then_succeeds(client):
    respx.get("https://cad.onshape.com/api/v6/documents").mock(
        side_effect=[
            httpx.Response(500, json={"message": "server error"}),
            httpx.Response(200, json={"items": [1]}),
        ]
    )
    result = await client.get("/documents")
    assert result == {"items": [1]}


@respx.mock
async def test_raises_on_400(client):
    respx.get("https://cad.onshape.com/api/v6/documents").mock(
        return_value=httpx.Response(400, json={"message": "bad"})
    )
    with pytest.raises(Exception) as exc:
        await client.get("/documents")
    assert "400" in str(exc.value)


@respx.mock
async def test_raises_after_max_retries_on_500(client):
    respx.get("https://cad.onshape.com/api/v6/documents").mock(
        side_effect=[
            httpx.Response(500),
            httpx.Response(500),
            httpx.Response(500),
        ]
    )
    with pytest.raises(OnshapeError) as exc:
        await client.get("/documents")
    assert "exceeded" in str(exc.value)


@respx.mock
async def test_delete_sends_signed_request(client):
    route = respx.delete("https://cad.onshape.com/api/v6/documents/D1").mock(
        return_value=httpx.Response(204)
    )
    result = await client.delete("/documents/D1")
    assert result is None
    req = route.calls[-1].request
    assert "authorization" in req.headers
