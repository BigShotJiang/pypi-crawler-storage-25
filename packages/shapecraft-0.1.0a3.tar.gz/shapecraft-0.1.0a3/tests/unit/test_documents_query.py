import httpx
import pytest
import respx

from shapecraft.core.client import OnshapeClient
from shapecraft.documents.query import (
    find_part_studios,
    get_document,
    get_document_summary,
    get_elements,
    search_documents,
)


@pytest.fixture
def client():
    return OnshapeClient(access_key="AK", secret_key="SK")


@respx.mock
async def test_search_documents_passes_query(client):
    route = respx.get("https://cad.onshape.com/api/v6/documents/search").mock(
        return_value=httpx.Response(200, json={"items": [{"id": "D1", "name": "hanok"}]})
    )
    docs = await search_documents(client, query="hanok", limit=5)
    assert docs == [{"id": "D1", "name": "hanok"}]
    req = route.calls[-1].request
    assert "q=hanok" in str(req.url)
    assert "limit=5" in str(req.url)


@respx.mock
async def test_get_document_returns_metadata(client):
    respx.get("https://cad.onshape.com/api/v6/documents/D1").mock(
        return_value=httpx.Response(200, json={"id": "D1", "name": "hanok", "public": True})
    )
    doc = await get_document(client, did="D1")
    assert doc["id"] == "D1"
    assert doc["name"] == "hanok"


@respx.mock
async def test_get_document_summary_aggregates_workspaces_and_elements(client):
    respx.get("https://cad.onshape.com/api/v6/documents/D1").mock(
        return_value=httpx.Response(200, json={"id": "D1", "name": "hanok"})
    )
    respx.get("https://cad.onshape.com/api/v6/documents/d/D1/workspaces").mock(
        return_value=httpx.Response(200, json=[{"id": "W1", "name": "Main", "isMain": True}])
    )
    respx.get("https://cad.onshape.com/api/v6/documents/d/D1/w/W1/elements").mock(
        return_value=httpx.Response(
            200,
            json=[
                {"id": "E1", "name": "PS1", "elementType": "PARTSTUDIO"},
                {"id": "E2", "name": "Asm1", "elementType": "ASSEMBLY"},
            ],
        )
    )
    summary = await get_document_summary(client, did="D1")
    assert summary["document"]["id"] == "D1"
    assert len(summary["workspaces"]) == 1
    assert summary["workspace_details"][0]["workspace"]["id"] == "W1"
    assert len(summary["workspace_details"][0]["elements"]) == 2


@respx.mock
async def test_get_elements_filters_by_type(client):
    route = respx.get("https://cad.onshape.com/api/v6/documents/d/D1/w/W1/elements").mock(
        return_value=httpx.Response(
            200,
            json=[
                {"id": "E1", "name": "PS1", "elementType": "PARTSTUDIO"},
            ],
        )
    )
    elements = await get_elements(client, did="D1", wid="W1", element_type="PARTSTUDIO")
    assert len(elements) == 1
    assert elements[0]["elementType"] == "PARTSTUDIO"
    req = route.calls[-1].request
    assert "elementType=PARTSTUDIO" in str(req.url)


@respx.mock
async def test_find_part_studios_filters_by_name_pattern(client):
    respx.get("https://cad.onshape.com/api/v6/documents/d/D1/w/W1/elements").mock(
        return_value=httpx.Response(
            200,
            json=[
                {"id": "E1", "name": "Chair", "elementType": "PARTSTUDIO"},
                {"id": "E2", "name": "Table", "elementType": "PARTSTUDIO"},
                {"id": "E3", "name": "Chair Assembly", "elementType": "ASSEMBLY"},
            ],
        )
    )
    matches = await find_part_studios(client, did="D1", wid="W1", name_pattern="Chair")
    assert len(matches) == 1
    assert matches[0]["name"] == "Chair"


@respx.mock
async def test_search_documents_empty_result(client):
    respx.get("https://cad.onshape.com/api/v6/documents/search").mock(
        return_value=httpx.Response(200, json={"items": []})
    )
    docs = await search_documents(client, query="nothing", limit=10)
    assert docs == []


@respx.mock
async def test_search_documents_default_limit(client):
    route = respx.get("https://cad.onshape.com/api/v6/documents/search").mock(
        return_value=httpx.Response(200, json={"items": []})
    )
    await search_documents(client, query="x")
    assert "limit=20" in str(route.calls[-1].request.url)


@respx.mock
async def test_get_document_propagates_error(client):
    respx.get("https://cad.onshape.com/api/v6/documents/D_missing").mock(
        return_value=httpx.Response(404, json={"message": "not found"})
    )
    with pytest.raises(Exception, match="404"):
        await get_document(client, did="D_missing")


@respx.mock
async def test_get_document_summary_handles_empty_workspaces(client):
    respx.get("https://cad.onshape.com/api/v6/documents/D1").mock(
        return_value=httpx.Response(200, json={"id": "D1", "name": "empty"})
    )
    respx.get("https://cad.onshape.com/api/v6/documents/d/D1/workspaces").mock(
        return_value=httpx.Response(200, json=[])
    )
    summary = await get_document_summary(client, did="D1")
    assert summary["workspaces"] == []
    assert summary["workspace_details"] == []


@respx.mock
async def test_get_elements_without_filter_omits_query(client):
    route = respx.get("https://cad.onshape.com/api/v6/documents/d/D1/w/W1/elements").mock(
        return_value=httpx.Response(200, json=[])
    )
    await get_elements(client, did="D1", wid="W1")
    req = route.calls[-1].request
    # Params None → no ?elementType=... in URL
    assert "elementType" not in str(req.url)


@respx.mock
async def test_find_part_studios_returns_all_when_pattern_none(client):
    respx.get("https://cad.onshape.com/api/v6/documents/d/D1/w/W1/elements").mock(
        return_value=httpx.Response(
            200,
            json=[
                {"id": "E1", "name": "A", "elementType": "PARTSTUDIO"},
                {"id": "E2", "name": "B", "elementType": "PARTSTUDIO"},
            ],
        )
    )
    matches = await find_part_studios(client, did="D1", wid="W1")
    assert len(matches) == 2


@respx.mock
async def test_find_part_studios_regex_supports_alternation(client):
    respx.get("https://cad.onshape.com/api/v6/documents/d/D1/w/W1/elements").mock(
        return_value=httpx.Response(
            200,
            json=[
                {"id": "E1", "name": "Leg", "elementType": "PARTSTUDIO"},
                {"id": "E2", "name": "Arm", "elementType": "PARTSTUDIO"},
                {"id": "E3", "name": "Seat", "elementType": "PARTSTUDIO"},
            ],
        )
    )
    matches = await find_part_studios(client, did="D1", wid="W1", name_pattern="Leg|Arm")
    assert sorted(m["name"] for m in matches) == ["Arm", "Leg"]


@respx.mock
async def test_find_part_studios_filters_non_partstudios_out(client):
    respx.get("https://cad.onshape.com/api/v6/documents/d/D1/w/W1/elements").mock(
        return_value=httpx.Response(
            200,
            json=[
                {"id": "E1", "name": "PS", "elementType": "PARTSTUDIO"},
                {"id": "E2", "name": "PS Asm", "elementType": "ASSEMBLY"},
            ],
        )
    )
    matches = await find_part_studios(client, did="D1", wid="W1", name_pattern="PS")
    # ASSEMBLY element must be excluded — function requests PARTSTUDIO type only
    assert all(m["elementType"] == "PARTSTUDIO" for m in matches)
    req_url = str(respx.calls[-1].request.url)
    assert "elementType=PARTSTUDIO" in req_url
