from shapecraft.sketch.constraints import build_coincident_constraint


def test_coincident_constraint_names_both_entities():
    c = build_coincident_constraint(
        sketch_feature_id="FS_0",
        entity_a="line1.start",
        entity_b="line2.end",
    )
    text = repr(c)
    assert "line1.start" in text
    assert "line2.end" in text


def test_coincident_constraint_type_is_coincident():
    c = build_coincident_constraint(
        sketch_feature_id="FS_0",
        entity_a="p1",
        entity_b="p2",
    )
    assert c["constraintType"] == "COINCIDENT"
