import pytest
from pydantic import ValidationError

from shapecraft.core.types import Credentials, DocumentRef, FeatureRef


def test_document_ref_accepts_dwe():
    ref = DocumentRef(did="D1", wid="W1", eid="E1")
    assert ref.did == "D1"
    assert ref.path() == "/documents/D1/w/W1/e/E1"


def test_document_ref_partstudio_features_path():
    ref = DocumentRef(did="D", wid="W", eid="E")
    assert ref.partstudio_features_path() == "/partstudios/d/D/w/W/e/E/features"


def test_document_ref_rejects_empty_ids():
    with pytest.raises(ValidationError):
        DocumentRef(did="", wid="W", eid="E")


def test_feature_ref_roundtrip():
    f = FeatureRef(feature_id="FXYZ_0", name="Extrude 1")
    assert f.feature_id == "FXYZ_0"
    assert f.name == "Extrude 1"


def test_credentials_from_env(monkeypatch):
    monkeypatch.setenv("ONSHAPE_ACCESS_KEY", "AK")
    monkeypatch.setenv("ONSHAPE_SECRET_KEY", "SK")
    c = Credentials.from_env()
    assert c.access_key == "AK"
    assert c.secret_key == "SK"


def test_credentials_from_env_missing_raises(monkeypatch):
    monkeypatch.delenv("ONSHAPE_ACCESS_KEY", raising=False)
    monkeypatch.delenv("ONSHAPE_SECRET_KEY", raising=False)
    with pytest.raises(RuntimeError):
        Credentials.from_env()
