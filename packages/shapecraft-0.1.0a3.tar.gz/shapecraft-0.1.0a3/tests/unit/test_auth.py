from shapecraft.core.auth import sign_request


def test_sign_request_returns_required_headers():
    headers = sign_request(
        method="GET",
        url="https://cad.onshape.com/api/v6/documents",
        body=b"",
        access_key="AK123",
        secret_key="SK456",
        nonce="fixed-nonce-string-ok1",
        timestamp="Mon, 18 Apr 2026 12:00:00 GMT",
    )
    assert "On-Nonce" in headers
    assert "Date" in headers
    assert "Authorization" in headers
    assert headers["Authorization"].startswith("On AK123:HmacSHA256:")


def test_sign_request_is_deterministic_for_fixed_inputs():
    kwargs = dict(
        method="POST",
        url="https://cad.onshape.com/api/v6/documents",
        body=b'{"name":"x"}',
        access_key="AK",
        secret_key="SK",
        nonce="N",
        timestamp="T",
    )
    a = sign_request(**kwargs)
    b = sign_request(**kwargs)
    assert a["Authorization"] == b["Authorization"]


def test_sign_request_differs_when_body_changes():
    base = dict(
        method="POST",
        url="https://cad.onshape.com/api/v6/documents",
        access_key="AK",
        secret_key="SK",
        nonce="N",
        timestamp="T",
    )
    a = sign_request(body=b'{"a":1}', **base)
    b = sign_request(body=b'{"a":2}', **base)
    assert a["Authorization"] != b["Authorization"]
