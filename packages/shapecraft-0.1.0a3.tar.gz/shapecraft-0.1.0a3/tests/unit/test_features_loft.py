import pytest

from shapecraft.features.loft import build_loft_feature


def test_loft_requires_two_or_more_profiles():
    with pytest.raises(ValueError):
        build_loft_feature(profile_feature_ids=["F1_0"])


def test_loft_feature_type_is_loft():
    feat = build_loft_feature(profile_feature_ids=["F1_0", "F2_0"])
    assert feat["feature"]["featureType"] == "loft"


def test_loft_serializes_all_profile_queries():
    feat = build_loft_feature(profile_feature_ids=["FA_0", "FB_0", "FC_0"], operation="NEW")
    text = repr(feat)
    assert "FA_0" in text
    assert "FB_0" in text
    assert "FC_0" in text
