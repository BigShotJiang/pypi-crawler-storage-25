from shapecraft.sketch.rectangle import build_sketch_rectangle_feature


def test_build_sketch_rectangle_feature_has_correct_type():
    feat = build_sketch_rectangle_feature(
        name="Sketch 1",
        plane="Top",
        corner1=(0.0, 0.0),
        corner2=(1.0, 1.0),
    )
    assert feat["feature"]["featureType"] == "newSketch"
    assert feat["feature"]["name"] == "Sketch 1"


def test_build_sketch_rectangle_feature_encodes_plane():
    top = build_sketch_rectangle_feature(plane="Top", corner1=(0, 0), corner2=(1, 1))
    front = build_sketch_rectangle_feature(plane="Front", corner1=(0, 0), corner2=(1, 1))
    assert top != front  # plane deterministically changes payload


def test_build_sketch_rectangle_feature_contains_four_corners():
    feat = build_sketch_rectangle_feature(plane="Top", corner1=(0.0, 0.0), corner2=(2.0, 3.0))
    text = repr(feat)
    assert "2.0" in text
    assert "3.0" in text
