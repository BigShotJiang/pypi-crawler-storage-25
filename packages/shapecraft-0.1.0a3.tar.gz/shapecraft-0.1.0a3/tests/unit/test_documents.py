import httpx
import pytest
import respx

from shapecraft.core.client import OnshapeClient
from shapecraft.documents.operations import (
    create_document,
    create_part_studio,
    list_documents,
)


@pytest.fixture
def client():
    return OnshapeClient(access_key="AK", secret_key="SK")


@respx.mock
async def test_list_documents_passes_params(client):
    route = respx.get("https://cad.onshape.com/api/v6/documents").mock(
        return_value=httpx.Response(
            200,
            json={"items": [{"id": "D1", "name": "doc1"}]},
        )
    )
    docs = await list_documents(client, limit=10, filter_type="owned")
    assert docs == [{"id": "D1", "name": "doc1"}]
    req = route.calls[-1].request
    assert "limit=10" in str(req.url)


@respx.mock
async def test_create_document_posts_name(client):
    respx.post("https://cad.onshape.com/api/v6/documents").mock(
        return_value=httpx.Response(200, json={"id": "Dnew", "defaultWorkspace": {"id": "Wnew"}})
    )
    result = await create_document(client, name="hello", is_public=True)
    assert result["id"] == "Dnew"


@respx.mock
async def test_create_part_studio_returns_element(client):
    respx.post("https://cad.onshape.com/api/v6/partstudios/d/D1/w/W1").mock(
        return_value=httpx.Response(200, json={"id": "Enew", "name": "Part Studio 2"})
    )
    result = await create_part_studio(client, did="D1", wid="W1", name="Part Studio 2")
    assert result["id"] == "Enew"
