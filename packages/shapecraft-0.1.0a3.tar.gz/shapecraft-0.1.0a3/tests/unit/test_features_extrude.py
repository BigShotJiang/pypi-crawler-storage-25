import pytest

from shapecraft.features.extrude import build_extrude_feature


def test_new_body_extrude_has_correct_operation():
    feat = build_extrude_feature(
        name="Extrude 1",
        sketch_feature_id="F123_0",
        depth=1.0,
        operation="NEW",
    )
    params = {p["parameterId"]: p for p in feat["feature"]["parameters"]}
    assert params["operationType"]["value"] == "NEW"


def test_symmetric_flag_serialized():
    feat = build_extrude_feature(
        sketch_feature_id="F1_0",
        depth=2.0,
        operation="NEW",
        symmetric=True,
    )
    params = {p["parameterId"]: p for p in feat["feature"]["parameters"]}
    assert params["symmetric"]["value"] is True


def test_reverse_direction_serialized():
    feat = build_extrude_feature(sketch_feature_id="F1_0", depth=1.0, operation="NEW", reverse=True)
    params = {p["parameterId"]: p for p in feat["feature"]["parameters"]}
    assert params["oppositeDirection"]["value"] is True


def test_rejects_invalid_operation():
    with pytest.raises(ValueError):
        build_extrude_feature(sketch_feature_id="F1_0", depth=1.0, operation="BOGUS")
