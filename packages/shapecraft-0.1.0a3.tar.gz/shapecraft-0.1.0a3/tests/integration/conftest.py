import os

import pytest

from shapecraft.core.client import OnshapeClient


@pytest.fixture
def live_client():
    ak = os.getenv("ONSHAPE_ACCESS_KEY")
    sk = os.getenv("ONSHAPE_SECRET_KEY")
    if not ak or not sk:
        pytest.skip("Set ONSHAPE_ACCESS_KEY and ONSHAPE_SECRET_KEY to run integration tests")
    return OnshapeClient(access_key=ak, secret_key=sk)
