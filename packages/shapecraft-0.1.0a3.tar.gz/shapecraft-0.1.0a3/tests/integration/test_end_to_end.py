import pytest

from shapecraft.core.types import DocumentRef
from shapecraft.documents.operations import (
    create_document,
    create_part_studio,
    list_documents,
)
from shapecraft.features._base import add_feature
from shapecraft.features.extrude import build_extrude_feature
from shapecraft.sketch.rectangle import build_sketch_rectangle_feature


@pytest.mark.integration
async def test_list_documents_returns_list(live_client):
    docs = await list_documents(live_client, limit=1)
    assert isinstance(docs, list)


@pytest.mark.integration
async def test_cube_pipeline(live_client):
    doc = await create_document(live_client, name="shapecraft integration test", is_public=True)
    did = doc["id"]
    wid = doc["defaultWorkspace"]["id"]

    ps = await create_part_studio(live_client, did=did, wid=wid, name="IT Part Studio")
    eid = ps["id"]

    ref = DocumentRef(did=did, wid=wid, eid=eid)
    sketch_feat = build_sketch_rectangle_feature(
        name="IT Sketch", plane="Top", corner1=(0.0, 0.0), corner2=(1.0, 1.0)
    )
    sketch_ref = await add_feature(live_client, ref, sketch_feat)
    assert sketch_ref.feature_id

    extrude_feat = build_extrude_feature(
        sketch_feature_id=sketch_ref.feature_id, depth=1.0, operation="NEW"
    )
    ext_ref = await add_feature(live_client, ref, extrude_feat)
    assert ext_ref.feature_id
