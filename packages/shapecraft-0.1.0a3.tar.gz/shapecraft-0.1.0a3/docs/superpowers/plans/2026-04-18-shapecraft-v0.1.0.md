# shapecraft v0.1.0-alpha Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship an installable Python package `shapecraft` that registers as an MCP server and exposes 9 proof-of-life tools (foundation tools + one new killer feature: offset plane, sketch spline, coincident constraint, loft) — proving the full pipeline from user prompt → Claude tool call → Onshape REST API → real parametric feature.

**Architecture:** Single Python package with layered modules (`core/` for HTTP+auth, `features/` and `sketch/` for builders, `planes/` for datum planes, `server.py` for MCP stdio entry). Each builder is pure — constructs BTMFeature JSON and POSTs via a shared client. MCP tools are registered automatically from each sub-module at server startup. TDD throughout: snapshot tests for JSON payloads (no network) + gated integration tests that hit live Onshape.

**Tech Stack:** Python 3.10+, `mcp` (official Anthropic SDK), `httpx`, `pydantic` v2, `loguru`, `pytest`, `pytest-asyncio`, `ruff`, `uv` for packaging/running, `uvx` as the install command for end users.

**Scope note:** This plan ships v0.1.0-alpha (9 tools). A follow-up plan (v0.1.0-batch-2) ports the remaining 45 hedless-equivalent tools using the same patterns established here, and v0.1.0 itself flips from alpha to stable once that batch lands.

---

## File Structure

Files introduced by this plan:

```
shapecraft/
├── pyproject.toml                               # Task 1 — packaging, deps, scripts
├── ruff.toml                                    # Task 1 — lint/format config
├── .python-version                              # Task 1 — pin 3.12
├── shapecraft/                                  # Package root
│   ├── __init__.py                              # Task 1
│   ├── core/
│   │   ├── __init__.py                          # Task 1
│   │   ├── auth.py                              # Task 2 — HMAC signer
│   │   ├── client.py                            # Task 3 — httpx wrapper + retries
│   │   └── types.py                             # Task 4 — DocumentRef, FeatureRef, errors
│   ├── features/
│   │   ├── __init__.py                          # Task 6
│   │   ├── _base.py                             # Task 6 — BTMFeature builder helpers
│   │   ├── extrude.py                           # Task 8
│   │   └── loft.py                              # Task 12
│   ├── planes/
│   │   ├── __init__.py                          # Task 10
│   │   └── offset.py                            # Task 10 — offset plane builder
│   ├── sketch/
│   │   ├── __init__.py                          # Task 9
│   │   ├── rectangle.py                         # Task 7
│   │   ├── spline.py                            # Task 11
│   │   └── constraints.py                       # Task 13 — coincident
│   ├── documents/
│   │   ├── __init__.py                          # Task 5
│   │   └── operations.py                        # Task 5 — list / create doc / create PS
│   └── server.py                                # Task 14 — MCP stdio entry + tool registry
├── tests/
│   ├── __init__.py                              # Task 1
│   ├── unit/
│   │   ├── __init__.py                          # Task 1
│   │   ├── test_auth.py                         # Task 2
│   │   ├── test_client.py                       # Task 3
│   │   ├── test_types.py                        # Task 4
│   │   ├── test_documents.py                    # Task 5
│   │   ├── test_features_extrude.py             # Task 8
│   │   ├── test_features_loft.py                # Task 12
│   │   ├── test_planes_offset.py                # Task 10
│   │   ├── test_sketch_rectangle.py             # Task 7
│   │   ├── test_sketch_spline.py                # Task 11
│   │   └── test_sketch_constraints.py           # Task 13
│   └── integration/
│       ├── __init__.py                          # Task 15
│       ├── conftest.py                          # Task 15 — credential fixture
│       └── test_end_to_end.py                   # Task 15 — full pipeline smoke
├── .github/
│   └── workflows/
│       ├── test.yml                             # Task 16
│       └── release.yml                          # Task 17
├── README.md                                    # Task 18 — rewrite with install + demo
└── CHANGELOG.md                                 # Task 18 — seed with v0.1.0-alpha
```

Responsibilities per module:

- **core/auth.py** — one function `sign_request(method, url, body, keys) -> dict[str, str]` returning headers. No state, no I/O.
- **core/client.py** — `OnshapeClient` class wrapping httpx. Owns retries, rate-limit wait, JSON parsing. Injects signed headers from `auth.py`.
- **core/types.py** — Pydantic models for `Credentials`, `DocumentRef(d, w, e)`, `FeatureRef(feature_id, name)`, a typed `OnshapeError` exception.
- **features/_base.py** — `build_feature(name, type_id, parameters) -> dict` helper that constructs the BTMFeature envelope all op features share.
- **features/<op>.py** — each exposes a single async builder like `async def build(client, doc_ref, **params) -> FeatureRef`.
- **sketch/<primitive>.py** — primitive-specific builders that produce sketch entity JSON, merged into a sketch feature.
- **sketch/constraints.py** — constraint builders that attach to an existing sketch.
- **planes/<type>.py** — datum-plane feature builders.
- **documents/operations.py** — document/workspace/part-studio level operations that are not features.
- **server.py** — imports every builder, registers MCP tools with schemas, runs stdio.

---

### Task 1: Project scaffold, tooling, empty tree

**Files:**
- Create: `/Users/genie/dev/lab/shapecraft/pyproject.toml`
- Create: `/Users/genie/dev/lab/shapecraft/ruff.toml`
- Create: `/Users/genie/dev/lab/shapecraft/.python-version`
- Create: `/Users/genie/dev/lab/shapecraft/shapecraft/__init__.py`
- Create: `/Users/genie/dev/lab/shapecraft/shapecraft/core/__init__.py`
- Create: `/Users/genie/dev/lab/shapecraft/tests/__init__.py`
- Create: `/Users/genie/dev/lab/shapecraft/tests/unit/__init__.py`

- [ ] **Step 1: Write pyproject.toml**

```toml
[project]
name = "shapecraft"
version = "0.1.0a1"
description = "Craft real CAD with Claude. MCP server for Onshape."
readme = "README.md"
license = { file = "LICENSE" }
authors = [{ name = "newTurn2017" }]
requires-python = ">=3.10"
keywords = ["mcp", "onshape", "cad", "claude", "anthropic"]
classifiers = [
    "Development Status :: 3 - Alpha",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Topic :: Scientific/Engineering",
]
dependencies = [
    "mcp>=1.0.0",
    "httpx>=0.27.0",
    "pydantic>=2.0.0",
    "loguru>=0.7.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.4.0",
    "pytest-asyncio>=0.23.0",
    "pytest-cov>=4.1.0",
    "ruff>=0.6.0",
]

[project.scripts]
shapecraft = "shapecraft.server:main"

[project.urls]
Homepage = "https://github.com/newTurn2017/shapecraft"
Repository = "https://github.com/newTurn2017/shapecraft"
Issues = "https://github.com/newTurn2017/shapecraft/issues"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]
addopts = ["-ra", "--strict-markers"]
markers = [
    "integration: hits live Onshape API (needs ONSHAPE_ACCESS_KEY, ONSHAPE_SECRET_KEY)",
]
```

- [ ] **Step 2: Write ruff.toml**

```toml
line-length = 100
target-version = "py310"

[lint]
select = ["E", "F", "I", "UP", "B", "SIM", "RUF"]
ignore = ["E501"]  # line length handled by formatter

[format]
quote-style = "double"
indent-style = "space"
```

- [ ] **Step 3: Write .python-version**

```
3.12
```

- [ ] **Step 4: Create empty package files**

Each of these files has content `""` (empty):
- `shapecraft/__init__.py`
- `shapecraft/core/__init__.py`
- `tests/__init__.py`
- `tests/unit/__init__.py`

- [ ] **Step 5: Install in editable mode and verify**

Run:
```bash
cd /Users/genie/dev/lab/shapecraft
python3 -m venv venv
./venv/bin/pip install -e ".[dev]"
./venv/bin/python -c "import shapecraft; print('ok')"
./venv/bin/pytest tests/ -q
./venv/bin/ruff check shapecraft tests
```

Expected: `import ok`, pytest reports "no tests ran", ruff passes with no errors.

- [ ] **Step 6: Commit**

```bash
cd /Users/genie/dev/lab/shapecraft
git add pyproject.toml ruff.toml .python-version shapecraft tests
git commit -m "chore: project scaffold with pyproject, ruff, empty package tree"
```

---

### Task 2: HMAC request signer

**Files:**
- Create: `shapecraft/core/auth.py`
- Test: `tests/unit/test_auth.py`

- [ ] **Step 1: Write the failing tests**

File: `tests/unit/test_auth.py`

```python
from shapecraft.core.auth import sign_request


def test_sign_request_returns_required_headers():
    headers = sign_request(
        method="GET",
        url="https://cad.onshape.com/api/v6/documents",
        body=b"",
        access_key="AK123",
        secret_key="SK456",
        nonce="fixed-nonce-string-ok1",
        timestamp="Mon, 18 Apr 2026 12:00:00 GMT",
    )
    assert "On-Nonce" in headers
    assert "Date" in headers
    assert "Authorization" in headers
    assert headers["Authorization"].startswith("On AK123:HmacSHA256:")


def test_sign_request_is_deterministic_for_fixed_inputs():
    kwargs = dict(
        method="POST",
        url="https://cad.onshape.com/api/v6/documents",
        body=b'{"name":"x"}',
        access_key="AK",
        secret_key="SK",
        nonce="N",
        timestamp="T",
    )
    a = sign_request(**kwargs)
    b = sign_request(**kwargs)
    assert a["Authorization"] == b["Authorization"]


def test_sign_request_differs_when_body_changes():
    base = dict(
        method="POST",
        url="https://cad.onshape.com/api/v6/documents",
        access_key="AK",
        secret_key="SK",
        nonce="N",
        timestamp="T",
    )
    a = sign_request(body=b'{"a":1}', **base)
    b = sign_request(body=b'{"a":2}', **base)
    assert a["Authorization"] != b["Authorization"]
```

- [ ] **Step 2: Run tests and verify they fail**

```bash
./venv/bin/pytest tests/unit/test_auth.py -v
```

Expected: 3 FAILED with `ModuleNotFoundError: No module named 'shapecraft.core.auth'`.

- [ ] **Step 3: Implement sign_request**

File: `shapecraft/core/auth.py`

```python
"""HMAC-SHA256 request signing for Onshape API."""

import base64
import hashlib
import hmac
from urllib.parse import urlparse


def sign_request(
    *,
    method: str,
    url: str,
    body: bytes,
    access_key: str,
    secret_key: str,
    nonce: str,
    timestamp: str,
) -> dict[str, str]:
    """Return Authorization/Date/On-Nonce headers per Onshape API key spec.

    Follows the string-to-sign format documented at
    https://onshape-public.github.io/docs/auth/apikeys/.
    """
    parsed = urlparse(url)
    path = parsed.path
    query = parsed.query

    content_type = "application/json" if body else ""
    content_md5 = ""

    string_to_sign = "\n".join(
        [
            method.lower(),
            nonce,
            timestamp,
            content_type,
            path,
            query,
        ]
    ).lower()

    signature = hmac.new(
        secret_key.encode("utf-8"),
        string_to_sign.encode("utf-8") + body,
        hashlib.sha256,
    ).digest()
    signature_b64 = base64.b64encode(signature).decode("ascii")

    return {
        "Date": timestamp,
        "On-Nonce": nonce,
        "Authorization": f"On {access_key}:HmacSHA256:{signature_b64}",
    }
```

- [ ] **Step 4: Run tests to verify pass**

```bash
./venv/bin/pytest tests/unit/test_auth.py -v
```

Expected: 3 PASSED.

- [ ] **Step 5: Commit**

```bash
git add shapecraft/core/auth.py tests/unit/test_auth.py
git commit -m "feat(core): HMAC request signer with snapshot tests"
```

---

### Task 3: OnshapeClient with retries and rate-limit handling

**Files:**
- Create: `shapecraft/core/client.py`
- Test: `tests/unit/test_client.py`

- [ ] **Step 1: Write the failing tests**

File: `tests/unit/test_client.py`

```python
import pytest
import respx
import httpx
from shapecraft.core.client import OnshapeClient
from shapecraft.core.auth import sign_request  # imported to prove dependency resolves


@pytest.fixture
def client():
    return OnshapeClient(
        access_key="AK",
        secret_key="SK",
        base_url="https://cad.onshape.com/api/v6",
    )


@respx.mock
async def test_get_returns_json_on_200(client):
    respx.get("https://cad.onshape.com/api/v6/documents").mock(
        return_value=httpx.Response(200, json={"items": []})
    )
    result = await client.get("/documents")
    assert result == {"items": []}


@respx.mock
async def test_post_sends_body_and_signed_headers(client):
    route = respx.post("https://cad.onshape.com/api/v6/documents").mock(
        return_value=httpx.Response(200, json={"id": "D1"})
    )
    await client.post("/documents", json={"name": "test"})
    req = route.calls[-1].request
    assert req.headers.get("authorization", "").startswith("On AK:HmacSHA256:")
    assert b'"name"' in req.content


@respx.mock
async def test_retries_on_500_then_succeeds(client):
    respx.get("https://cad.onshape.com/api/v6/documents").mock(
        side_effect=[
            httpx.Response(500, json={"message": "server error"}),
            httpx.Response(200, json={"items": [1]}),
        ]
    )
    result = await client.get("/documents")
    assert result == {"items": [1]}


@respx.mock
async def test_raises_on_400(client):
    respx.get("https://cad.onshape.com/api/v6/documents").mock(
        return_value=httpx.Response(400, json={"message": "bad"})
    )
    with pytest.raises(Exception) as exc:
        await client.get("/documents")
    assert "400" in str(exc.value)
```

- [ ] **Step 2: Add respx to dev deps**

Edit `pyproject.toml` dev deps list:

```toml
dev = [
    "pytest>=7.4.0",
    "pytest-asyncio>=0.23.0",
    "pytest-cov>=4.1.0",
    "ruff>=0.6.0",
    "respx>=0.21.0",
]
```

Then: `./venv/bin/pip install -e ".[dev]"`

- [ ] **Step 3: Run tests and verify they fail**

```bash
./venv/bin/pytest tests/unit/test_client.py -v
```

Expected: 4 FAILED with `ModuleNotFoundError: No module named 'shapecraft.core.client'`.

- [ ] **Step 4: Implement OnshapeClient**

File: `shapecraft/core/client.py`

```python
"""HTTP client for the Onshape REST API."""

import asyncio
import secrets
from datetime import datetime, timezone
from typing import Any

import httpx
from loguru import logger

from shapecraft.core.auth import sign_request


class OnshapeError(Exception):
    """Raised for any 4xx/5xx response that exceeded retries."""


class OnshapeClient:
    def __init__(
        self,
        access_key: str,
        secret_key: str,
        base_url: str = "https://cad.onshape.com/api/v6",
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        self._access_key = access_key
        self._secret_key = secret_key
        self._base_url = base_url.rstrip("/")
        self._http = httpx.AsyncClient(timeout=timeout)
        self._max_retries = max_retries

    async def aclose(self) -> None:
        await self._http.aclose()

    async def get(self, path: str, params: dict | None = None) -> Any:
        return await self._request("GET", path, params=params)

    async def post(self, path: str, json: dict | None = None) -> Any:
        return await self._request("POST", path, json=json)

    async def delete(self, path: str) -> Any:
        return await self._request("DELETE", path)

    async def _request(
        self,
        method: str,
        path: str,
        params: dict | None = None,
        json: dict | None = None,
    ) -> Any:
        url = f"{self._base_url}{path}"
        body = b"" if json is None else httpx._content.json_dumps(json).encode("utf-8")
        last_exc: Exception | None = None

        for attempt in range(self._max_retries):
            headers = sign_request(
                method=method,
                url=url if not params else f"{url}?{httpx.QueryParams(params)}",
                body=body,
                access_key=self._access_key,
                secret_key=self._secret_key,
                nonce=secrets.token_hex(16),
                timestamp=datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S GMT"),
            )
            headers["Accept"] = "application/json"
            if body:
                headers["Content-Type"] = "application/json"

            try:
                resp = await self._http.request(
                    method, url, params=params, content=body, headers=headers
                )
            except httpx.HTTPError as exc:
                last_exc = exc
                await asyncio.sleep(0.5 * (2**attempt))
                continue

            if resp.status_code >= 500:
                last_exc = OnshapeError(f"{resp.status_code}: {resp.text}")
                await asyncio.sleep(0.5 * (2**attempt))
                continue

            if resp.status_code >= 400:
                raise OnshapeError(f"{resp.status_code}: {resp.text}")

            remaining = resp.headers.get("X-Rate-Limit-Remaining")
            if remaining is not None and int(remaining) < 5:
                logger.warning("Onshape rate limit low: {} remaining", remaining)

            if resp.status_code == 204 or not resp.content:
                return None
            return resp.json()

        raise OnshapeError(f"exceeded {self._max_retries} retries") from last_exc
```

- [ ] **Step 5: Run tests and verify pass**

```bash
./venv/bin/pytest tests/unit/test_client.py -v
```

Expected: 4 PASSED.

- [ ] **Step 6: Commit**

```bash
git add shapecraft/core/client.py tests/unit/test_client.py pyproject.toml
git commit -m "feat(core): OnshapeClient with retries, rate-limit logging, error typing"
```

---

### Task 4: Core types (DocumentRef, FeatureRef, Credentials)

**Files:**
- Create: `shapecraft/core/types.py`
- Test: `tests/unit/test_types.py`

- [ ] **Step 1: Write the failing tests**

File: `tests/unit/test_types.py`

```python
import pytest
from pydantic import ValidationError
from shapecraft.core.types import Credentials, DocumentRef, FeatureRef


def test_document_ref_accepts_dwe():
    ref = DocumentRef(did="D1", wid="W1", eid="E1")
    assert ref.did == "D1"
    assert ref.path() == "/documents/D1/w/W1/e/E1"


def test_document_ref_partstudio_features_path():
    ref = DocumentRef(did="D", wid="W", eid="E")
    assert ref.partstudio_features_path() == "/partstudios/d/D/w/W/e/E/features"


def test_document_ref_rejects_empty_ids():
    with pytest.raises(ValidationError):
        DocumentRef(did="", wid="W", eid="E")


def test_feature_ref_roundtrip():
    f = FeatureRef(feature_id="FXYZ_0", name="Extrude 1")
    assert f.feature_id == "FXYZ_0"
    assert f.name == "Extrude 1"


def test_credentials_from_env(monkeypatch):
    monkeypatch.setenv("ONSHAPE_ACCESS_KEY", "AK")
    monkeypatch.setenv("ONSHAPE_SECRET_KEY", "SK")
    c = Credentials.from_env()
    assert c.access_key == "AK"
    assert c.secret_key == "SK"


def test_credentials_from_env_missing_raises(monkeypatch):
    monkeypatch.delenv("ONSHAPE_ACCESS_KEY", raising=False)
    monkeypatch.delenv("ONSHAPE_SECRET_KEY", raising=False)
    with pytest.raises(RuntimeError):
        Credentials.from_env()
```

- [ ] **Step 2: Run tests and verify fail**

```bash
./venv/bin/pytest tests/unit/test_types.py -v
```

Expected: 6 FAILED.

- [ ] **Step 3: Implement types**

File: `shapecraft/core/types.py`

```python
"""Typed references and credentials."""

import os
from pydantic import BaseModel, Field, StringConstraints
from typing import Annotated

NonEmpty = Annotated[str, StringConstraints(min_length=1)]


class Credentials(BaseModel):
    access_key: NonEmpty
    secret_key: NonEmpty

    @classmethod
    def from_env(cls) -> "Credentials":
        ak = os.getenv("ONSHAPE_ACCESS_KEY")
        sk = os.getenv("ONSHAPE_SECRET_KEY")
        if not ak or not sk:
            raise RuntimeError(
                "ONSHAPE_ACCESS_KEY and ONSHAPE_SECRET_KEY must be set in environment"
            )
        return cls(access_key=ak, secret_key=sk)


class DocumentRef(BaseModel):
    did: NonEmpty = Field(description="Document ID (24 chars)")
    wid: NonEmpty = Field(description="Workspace ID")
    eid: NonEmpty = Field(description="Element ID (Part Studio, Assembly, etc.)")

    def path(self) -> str:
        return f"/documents/{self.did}/w/{self.wid}/e/{self.eid}"

    def partstudio_features_path(self) -> str:
        return f"/partstudios/d/{self.did}/w/{self.wid}/e/{self.eid}/features"


class FeatureRef(BaseModel):
    feature_id: NonEmpty
    name: str = ""
```

- [ ] **Step 4: Run tests to verify pass**

```bash
./venv/bin/pytest tests/unit/test_types.py -v
```

Expected: 6 PASSED.

- [ ] **Step 5: Commit**

```bash
git add shapecraft/core/types.py tests/unit/test_types.py
git commit -m "feat(core): DocumentRef, FeatureRef, Credentials.from_env"
```

---

### Task 5: Document-level operations (list / create doc / create PS)

**Files:**
- Create: `shapecraft/documents/__init__.py`
- Create: `shapecraft/documents/operations.py`
- Test: `tests/unit/test_documents.py`

- [ ] **Step 1: Write the failing tests**

File: `tests/unit/test_documents.py`

```python
import pytest
import respx
import httpx
from shapecraft.core.client import OnshapeClient
from shapecraft.documents.operations import (
    list_documents,
    create_document,
    create_part_studio,
)


@pytest.fixture
def client():
    return OnshapeClient(access_key="AK", secret_key="SK")


@respx.mock
async def test_list_documents_passes_params(client):
    route = respx.get("https://cad.onshape.com/api/v6/documents").mock(
        return_value=httpx.Response(
            200,
            json={"items": [{"id": "D1", "name": "doc1"}]},
        )
    )
    docs = await list_documents(client, limit=10, filter_type="owned")
    assert docs == [{"id": "D1", "name": "doc1"}]
    req = route.calls[-1].request
    assert "limit=10" in str(req.url)


@respx.mock
async def test_create_document_posts_name(client):
    respx.post("https://cad.onshape.com/api/v6/documents").mock(
        return_value=httpx.Response(
            200, json={"id": "Dnew", "defaultWorkspace": {"id": "Wnew"}}
        )
    )
    result = await create_document(client, name="hello", is_public=True)
    assert result["id"] == "Dnew"


@respx.mock
async def test_create_part_studio_returns_element(client):
    respx.post(
        "https://cad.onshape.com/api/v6/partstudios/d/D1/w/W1"
    ).mock(return_value=httpx.Response(200, json={"id": "Enew", "name": "Part Studio 2"}))
    result = await create_part_studio(client, did="D1", wid="W1", name="Part Studio 2")
    assert result["id"] == "Enew"
```

- [ ] **Step 2: Run tests and verify fail**

```bash
./venv/bin/pytest tests/unit/test_documents.py -v
```

Expected: 3 FAILED.

- [ ] **Step 3: Implement operations**

File: `shapecraft/documents/__init__.py` — empty.

File: `shapecraft/documents/operations.py`

```python
"""Document / workspace / element operations (non-feature)."""

from typing import Any

from shapecraft.core.client import OnshapeClient


async def list_documents(
    client: OnshapeClient,
    limit: int = 20,
    filter_type: str = "all",
    sort_by: str = "modifiedAt",
    sort_order: str = "desc",
) -> list[dict[str, Any]]:
    filter_map = {"all": 0, "owned": 1, "created": 2, "shared": 3}
    params = {
        "limit": limit,
        "filter": filter_map.get(filter_type, 0),
        "sortColumn": sort_by,
        "sortOrder": sort_order,
        "offset": 0,
    }
    resp = await client.get("/documents", params=params)
    return resp.get("items", [])


async def create_document(
    client: OnshapeClient,
    name: str,
    is_public: bool = True,
    description: str = "",
) -> dict[str, Any]:
    body = {"name": name, "isPublic": is_public, "description": description}
    return await client.post("/documents", json=body)


async def create_part_studio(
    client: OnshapeClient,
    did: str,
    wid: str,
    name: str = "Part Studio",
) -> dict[str, Any]:
    path = f"/partstudios/d/{did}/w/{wid}"
    return await client.post(path, json={"name": name})
```

- [ ] **Step 4: Run tests to verify pass**

```bash
./venv/bin/pytest tests/unit/test_documents.py -v
```

Expected: 3 PASSED.

- [ ] **Step 5: Commit**

```bash
git add shapecraft/documents tests/unit/test_documents.py
git commit -m "feat(documents): list / create doc / create part studio"
```

---

### Task 6: Feature-add infrastructure (BTMFeature envelope helper)

**Files:**
- Create: `shapecraft/features/__init__.py`
- Create: `shapecraft/features/_base.py`
- Test: inline in later feature tests (verified via snapshot)

- [ ] **Step 1: Write _base.py**

File: `shapecraft/features/__init__.py` — empty.

File: `shapecraft/features/_base.py`

```python
"""Shared helpers for building BTMFeature JSON payloads."""

from typing import Any

from shapecraft.core.client import OnshapeClient
from shapecraft.core.types import DocumentRef, FeatureRef


def make_parameter(param_id: str, value: Any, bt_type: str) -> dict[str, Any]:
    """Wrap a scalar/entity reference in the BTMParameter envelope."""
    return {
        "btType": bt_type,
        "parameterId": param_id,
        "value": value,
    }


def make_query(bt_type: str, **fields: Any) -> dict[str, Any]:
    """Produce an Onshape query object used as a parameter value."""
    return {"btType": bt_type, **fields}


def make_feature(
    *,
    name: str,
    feature_type: str,
    parameters: list[dict[str, Any]],
    bt_type: str = "BTMFeature-134",
) -> dict[str, Any]:
    """Full feature envelope ready to POST to /features."""
    return {
        "feature": {
            "btType": bt_type,
            "featureType": feature_type,
            "name": name,
            "parameters": parameters,
            "suppressed": False,
        }
    }


async def add_feature(
    client: OnshapeClient,
    doc: DocumentRef,
    feature_body: dict[str, Any],
) -> FeatureRef:
    resp = await client.post(doc.partstudio_features_path(), json=feature_body)
    feat = resp.get("feature", {})
    return FeatureRef(
        feature_id=feat.get("featureId", ""),
        name=feat.get("name", ""),
    )
```

- [ ] **Step 2: Verify module imports**

```bash
./venv/bin/python -c "from shapecraft.features._base import make_feature, add_feature; print('ok')"
```

Expected: prints `ok`.

- [ ] **Step 3: Commit**

```bash
git add shapecraft/features/_base.py shapecraft/features/__init__.py
git commit -m "feat(features): shared BTMFeature envelope + add_feature helper"
```

---

### Task 7: Sketch rectangle primitive

**Files:**
- Create: `shapecraft/sketch/__init__.py`
- Create: `shapecraft/sketch/rectangle.py`
- Test: `tests/unit/test_sketch_rectangle.py`

- [ ] **Step 1: Write the failing tests**

File: `tests/unit/test_sketch_rectangle.py`

```python
from shapecraft.sketch.rectangle import build_sketch_rectangle_feature


def test_build_sketch_rectangle_feature_has_correct_type():
    feat = build_sketch_rectangle_feature(
        name="Sketch 1",
        plane="Top",
        corner1=(0.0, 0.0),
        corner2=(1.0, 1.0),
    )
    assert feat["feature"]["featureType"] == "newSketch"
    assert feat["feature"]["name"] == "Sketch 1"


def test_build_sketch_rectangle_feature_encodes_plane():
    top = build_sketch_rectangle_feature(plane="Top", corner1=(0, 0), corner2=(1, 1))
    front = build_sketch_rectangle_feature(plane="Front", corner1=(0, 0), corner2=(1, 1))
    assert top != front  # plane deterministically changes payload


def test_build_sketch_rectangle_feature_contains_four_corners():
    feat = build_sketch_rectangle_feature(
        plane="Top", corner1=(0.0, 0.0), corner2=(2.0, 3.0)
    )
    text = repr(feat)
    assert "2.0" in text
    assert "3.0" in text
```

- [ ] **Step 2: Run tests and verify fail**

```bash
./venv/bin/pytest tests/unit/test_sketch_rectangle.py -v
```

Expected: 3 FAILED.

- [ ] **Step 3: Implement rectangle**

File: `shapecraft/sketch/__init__.py` — empty.

File: `shapecraft/sketch/rectangle.py`

```python
"""Rectangle primitive built into a new sketch feature."""

from typing import Any

PLANE_IDS = {"Top": "JHD", "Front": "JFC", "Right": "JGC"}


def build_sketch_rectangle_feature(
    *,
    name: str = "Sketch",
    plane: str = "Top",
    corner1: tuple[float, float],
    corner2: tuple[float, float],
) -> dict[str, Any]:
    """Return BTMFeature JSON for a rectangle sketched on a default plane.

    Coordinates are in inches per Onshape convention. The rectangle is built
    from four line segments with inferred corner coincidence (no explicit
    constraints in this primitive; add via `sketch/constraints.py`).
    """
    if plane not in PLANE_IDS:
        raise ValueError(f"plane must be one of {sorted(PLANE_IDS)}, got {plane!r}")

    x1, y1 = corner1
    x2, y2 = corner2

    entities = [
        _line_segment("line1", (x1, y1), (x2, y1)),
        _line_segment("line2", (x2, y1), (x2, y2)),
        _line_segment("line3", (x2, y2), (x1, y2)),
        _line_segment("line4", (x1, y2), (x1, y1)),
    ]

    return {
        "feature": {
            "btType": "BTMSketch-151",
            "featureType": "newSketch",
            "name": name,
            "parameters": [
                {
                    "btType": "BTMParameterQueryList-148",
                    "parameterId": "sketchPlane",
                    "queries": [
                        {
                            "btType": "BTMIndividualQuery-138",
                            "deterministicIds": [PLANE_IDS[plane]],
                        }
                    ],
                }
            ],
            "entities": entities,
            "suppressed": False,
        }
    }


def _line_segment(sketch_id: str, start: tuple[float, float], end: tuple[float, float]) -> dict[str, Any]:
    return {
        "btType": "BTMSketchCurveSegment-155",
        "entityId": sketch_id,
        "startPointId": f"{sketch_id}.start",
        "endPointId": f"{sketch_id}.end",
        "geometry": {
            "btType": "BTCurveGeometryLine-117",
            "pntX": float(start[0]),
            "pntY": float(start[1]),
            "dirX": 1.0,
            "dirY": 0.0,
        },
        "startParam": 0.0,
        "endParam": float(((end[0] - start[0]) ** 2 + (end[1] - start[1]) ** 2) ** 0.5),
    }
```

- [ ] **Step 4: Run tests to verify pass**

```bash
./venv/bin/pytest tests/unit/test_sketch_rectangle.py -v
```

Expected: 3 PASSED.

- [ ] **Step 5: Commit**

```bash
git add shapecraft/sketch tests/unit/test_sketch_rectangle.py
git commit -m "feat(sketch): rectangle primitive on default planes"
```

---

### Task 8: Extrude feature builder with start condition upgrade

**Files:**
- Create: `shapecraft/features/extrude.py`
- Test: `tests/unit/test_features_extrude.py`

- [ ] **Step 1: Write the failing tests**

File: `tests/unit/test_features_extrude.py`

```python
import pytest
from shapecraft.features.extrude import build_extrude_feature


def test_new_body_extrude_has_correct_operation():
    feat = build_extrude_feature(
        name="Extrude 1",
        sketch_feature_id="F123_0",
        depth=1.0,
        operation="NEW",
    )
    params = {p["parameterId"]: p for p in feat["feature"]["parameters"]}
    assert params["operationType"]["value"] == "NEW"


def test_symmetric_flag_serialized():
    feat = build_extrude_feature(
        sketch_feature_id="F1_0",
        depth=2.0,
        operation="NEW",
        symmetric=True,
    )
    params = {p["parameterId"]: p for p in feat["feature"]["parameters"]}
    assert params["symmetric"]["value"] is True


def test_reverse_direction_serialized():
    feat = build_extrude_feature(
        sketch_feature_id="F1_0", depth=1.0, operation="NEW", reverse=True
    )
    params = {p["parameterId"]: p for p in feat["feature"]["parameters"]}
    assert params["oppositeDirection"]["value"] is True


def test_rejects_invalid_operation():
    with pytest.raises(ValueError):
        build_extrude_feature(sketch_feature_id="F1_0", depth=1.0, operation="BOGUS")
```

- [ ] **Step 2: Run tests and verify fail**

```bash
./venv/bin/pytest tests/unit/test_features_extrude.py -v
```

Expected: 4 FAILED.

- [ ] **Step 3: Implement extrude builder**

File: `shapecraft/features/extrude.py`

```python
"""Extrude feature builder with symmetric / reverse support (v0.1 scope)."""

from typing import Any

VALID_OPERATIONS = {"NEW", "ADD", "REMOVE", "INTERSECT"}


def build_extrude_feature(
    *,
    name: str = "Extrude",
    sketch_feature_id: str,
    depth: float,
    operation: str = "NEW",
    symmetric: bool = False,
    reverse: bool = False,
) -> dict[str, Any]:
    if operation not in VALID_OPERATIONS:
        raise ValueError(f"operation must be one of {sorted(VALID_OPERATIONS)}")

    parameters: list[dict[str, Any]] = [
        {
            "btType": "BTMParameterEnum-145",
            "parameterId": "operationType",
            "enumName": "NewBodyOperationType",
            "value": operation,
        },
        {
            "btType": "BTMParameterQueryList-148",
            "parameterId": "entities",
            "queries": [
                {
                    "btType": "BTMIndividualQuery-138",
                    "featureId": sketch_feature_id,
                }
            ],
        },
        {
            "btType": "BTMParameterQuantity-147",
            "parameterId": "depth",
            "expression": f"{depth} in",
        },
        {
            "btType": "BTMParameterBoolean-144",
            "parameterId": "symmetric",
            "value": symmetric,
        },
        {
            "btType": "BTMParameterBoolean-144",
            "parameterId": "oppositeDirection",
            "value": reverse,
        },
    ]

    return {
        "feature": {
            "btType": "BTMFeature-134",
            "featureType": "extrude",
            "name": name,
            "parameters": parameters,
            "suppressed": False,
        }
    }
```

- [ ] **Step 4: Run tests to verify pass**

```bash
./venv/bin/pytest tests/unit/test_features_extrude.py -v
```

Expected: 4 PASSED.

- [ ] **Step 5: Commit**

```bash
git add shapecraft/features/extrude.py tests/unit/test_features_extrude.py
git commit -m "feat(features): extrude with symmetric and reverse-direction flags"
```

---

### Task 9: Sketch package init

**Files:**
- (No new files; verifies package import path)

- [ ] **Step 1: Verify sketch package imports**

```bash
./venv/bin/python -c "import shapecraft.sketch; print(dir(shapecraft.sketch))"
```

Expected: prints a dir listing containing at least `__loader__`, `__spec__`.

- [ ] **Step 2: Commit noop (skip if no changes)**

If nothing changed, skip. This task is a placeholder — earlier tasks already created sketch files.

---

### Task 10: Offset plane builder (killer T1 feature)

**Files:**
- Create: `shapecraft/planes/__init__.py`
- Create: `shapecraft/planes/offset.py`
- Test: `tests/unit/test_planes_offset.py`

- [ ] **Step 1: Write the failing tests**

File: `tests/unit/test_planes_offset.py`

```python
import pytest
from shapecraft.planes.offset import build_offset_plane_feature


def test_offset_plane_references_base_plane():
    feat = build_offset_plane_feature(
        name="Plane 1", base_plane="Top", offset=0.5
    )
    assert feat["feature"]["featureType"] == "cPlane"


def test_offset_plane_encodes_offset_distance():
    feat = build_offset_plane_feature(base_plane="Top", offset=2.5)
    params = {p["parameterId"]: p for p in feat["feature"]["parameters"]}
    assert "2.5" in params["offset"]["expression"]


def test_offset_plane_rejects_unknown_base():
    with pytest.raises(ValueError):
        build_offset_plane_feature(base_plane="Weird", offset=1.0)
```

- [ ] **Step 2: Run tests and verify fail**

```bash
./venv/bin/pytest tests/unit/test_planes_offset.py -v
```

Expected: 3 FAILED.

- [ ] **Step 3: Implement offset plane**

File: `shapecraft/planes/__init__.py` — empty.

File: `shapecraft/planes/offset.py`

```python
"""Offset plane relative to a base datum plane."""

from typing import Any

BASE_PLANE_IDS = {"Top": "JHD", "Front": "JFC", "Right": "JGC"}


def build_offset_plane_feature(
    *,
    name: str = "Offset Plane",
    base_plane: str = "Top",
    offset: float,
    opposite_direction: bool = False,
) -> dict[str, Any]:
    if base_plane not in BASE_PLANE_IDS:
        raise ValueError(
            f"base_plane must be one of {sorted(BASE_PLANE_IDS)}, got {base_plane!r}"
        )

    parameters = [
        {
            "btType": "BTMParameterEnum-145",
            "parameterId": "cplaneType",
            "enumName": "CPlaneType",
            "value": "OFFSET",
        },
        {
            "btType": "BTMParameterQueryList-148",
            "parameterId": "entities",
            "queries": [
                {
                    "btType": "BTMIndividualQuery-138",
                    "deterministicIds": [BASE_PLANE_IDS[base_plane]],
                }
            ],
        },
        {
            "btType": "BTMParameterQuantity-147",
            "parameterId": "offset",
            "expression": f"{offset} in",
        },
        {
            "btType": "BTMParameterBoolean-144",
            "parameterId": "oppositeDirection",
            "value": opposite_direction,
        },
    ]

    return {
        "feature": {
            "btType": "BTMFeature-134",
            "featureType": "cPlane",
            "name": name,
            "parameters": parameters,
            "suppressed": False,
        }
    }
```

- [ ] **Step 4: Run tests to verify pass**

```bash
./venv/bin/pytest tests/unit/test_planes_offset.py -v
```

Expected: 3 PASSED.

- [ ] **Step 5: Commit**

```bash
git add shapecraft/planes tests/unit/test_planes_offset.py
git commit -m "feat(planes): offset plane relative to base datum (killer T1 feature)"
```

---

### Task 11: Sketch spline primitive

**Files:**
- Create: `shapecraft/sketch/spline.py`
- Test: `tests/unit/test_sketch_spline.py`

- [ ] **Step 1: Write the failing tests**

File: `tests/unit/test_sketch_spline.py`

```python
import pytest
from shapecraft.sketch.spline import build_sketch_spline_feature


def test_spline_requires_at_least_two_points():
    with pytest.raises(ValueError):
        build_sketch_spline_feature(plane="Top", points=[(0.0, 0.0)])


def test_spline_feature_has_sketch_type():
    feat = build_sketch_spline_feature(
        plane="Top", points=[(0, 0), (1, 2), (3, 1)]
    )
    assert feat["feature"]["featureType"] == "newSketch"


def test_spline_preserves_point_order():
    feat = build_sketch_spline_feature(
        plane="Top", points=[(0.0, 0.0), (4.2, 1.7), (8.0, 0.5)]
    )
    text = repr(feat)
    # Points appear in order in the serialized payload
    first = text.find("4.2")
    second = text.find("8.0")
    assert 0 < first < second
```

- [ ] **Step 2: Run tests and verify fail**

```bash
./venv/bin/pytest tests/unit/test_sketch_spline.py -v
```

Expected: 3 FAILED.

- [ ] **Step 3: Implement spline**

File: `shapecraft/sketch/spline.py`

```python
"""Interpolated spline sketched through ordered points."""

from typing import Any

from shapecraft.sketch.rectangle import PLANE_IDS


def build_sketch_spline_feature(
    *,
    name: str = "Sketch Spline",
    plane: str = "Top",
    points: list[tuple[float, float]],
) -> dict[str, Any]:
    if plane not in PLANE_IDS:
        raise ValueError(f"plane must be one of {sorted(PLANE_IDS)}")
    if len(points) < 2:
        raise ValueError("spline requires at least 2 points")

    control = [
        {
            "btType": "BTCurveGeometryInterpolatedSpline-140",
            "pointIndex": i,
            "x": float(x),
            "y": float(y),
        }
        for i, (x, y) in enumerate(points)
    ]

    entity = {
        "btType": "BTMSketchCurve-4",
        "entityId": "spline1",
        "geometry": {
            "btType": "BTCurveGeometryInterpolatedSpline-140",
            "controlPoints": control,
            "isPeriodic": False,
        },
    }

    return {
        "feature": {
            "btType": "BTMSketch-151",
            "featureType": "newSketch",
            "name": name,
            "parameters": [
                {
                    "btType": "BTMParameterQueryList-148",
                    "parameterId": "sketchPlane",
                    "queries": [
                        {
                            "btType": "BTMIndividualQuery-138",
                            "deterministicIds": [PLANE_IDS[plane]],
                        }
                    ],
                }
            ],
            "entities": [entity],
            "suppressed": False,
        }
    }
```

- [ ] **Step 4: Run tests to verify pass**

```bash
./venv/bin/pytest tests/unit/test_sketch_spline.py -v
```

Expected: 3 PASSED.

- [ ] **Step 5: Commit**

```bash
git add shapecraft/sketch/spline.py tests/unit/test_sketch_spline.py
git commit -m "feat(sketch): interpolated spline primitive"
```

---

### Task 12: Loft feature builder

**Files:**
- Create: `shapecraft/features/loft.py`
- Test: `tests/unit/test_features_loft.py`

- [ ] **Step 1: Write the failing tests**

File: `tests/unit/test_features_loft.py`

```python
import pytest
from shapecraft.features.loft import build_loft_feature


def test_loft_requires_two_or_more_profiles():
    with pytest.raises(ValueError):
        build_loft_feature(profile_feature_ids=["F1_0"])


def test_loft_feature_type_is_loft():
    feat = build_loft_feature(profile_feature_ids=["F1_0", "F2_0"])
    assert feat["feature"]["featureType"] == "loft"


def test_loft_serializes_all_profile_queries():
    feat = build_loft_feature(
        profile_feature_ids=["FA_0", "FB_0", "FC_0"], operation="NEW"
    )
    text = repr(feat)
    assert "FA_0" in text
    assert "FB_0" in text
    assert "FC_0" in text
```

- [ ] **Step 2: Run tests and verify fail**

```bash
./venv/bin/pytest tests/unit/test_features_loft.py -v
```

Expected: 3 FAILED.

- [ ] **Step 3: Implement loft builder**

File: `shapecraft/features/loft.py`

```python
"""Loft feature that fits a solid through ordered sketch profiles."""

from typing import Any

VALID_OPERATIONS = {"NEW", "ADD", "REMOVE", "INTERSECT"}


def build_loft_feature(
    *,
    name: str = "Loft",
    profile_feature_ids: list[str],
    operation: str = "NEW",
    closed: bool = False,
) -> dict[str, Any]:
    if len(profile_feature_ids) < 2:
        raise ValueError("loft requires at least 2 profile sketches")
    if operation not in VALID_OPERATIONS:
        raise ValueError(f"operation must be one of {sorted(VALID_OPERATIONS)}")

    profiles_param = {
        "btType": "BTMParameterQueryList-148",
        "parameterId": "profiles",
        "queries": [
            {
                "btType": "BTMIndividualQuery-138",
                "featureId": fid,
            }
            for fid in profile_feature_ids
        ],
    }

    parameters = [
        {
            "btType": "BTMParameterEnum-145",
            "parameterId": "operationType",
            "enumName": "NewBodyOperationType",
            "value": operation,
        },
        profiles_param,
        {
            "btType": "BTMParameterBoolean-144",
            "parameterId": "closed",
            "value": closed,
        },
    ]

    return {
        "feature": {
            "btType": "BTMFeature-134",
            "featureType": "loft",
            "name": name,
            "parameters": parameters,
            "suppressed": False,
        }
    }
```

- [ ] **Step 4: Run tests to verify pass**

```bash
./venv/bin/pytest tests/unit/test_features_loft.py -v
```

Expected: 3 PASSED.

- [ ] **Step 5: Commit**

```bash
git add shapecraft/features/loft.py tests/unit/test_features_loft.py
git commit -m "feat(features): loft between ordered sketch profiles"
```

---

### Task 13: Coincident sketch constraint

**Files:**
- Create: `shapecraft/sketch/constraints.py`
- Test: `tests/unit/test_sketch_constraints.py`

- [ ] **Step 1: Write the failing tests**

File: `tests/unit/test_sketch_constraints.py`

```python
from shapecraft.sketch.constraints import build_coincident_constraint


def test_coincident_constraint_names_both_entities():
    c = build_coincident_constraint(
        sketch_feature_id="FS_0",
        entity_a="line1.start",
        entity_b="line2.end",
    )
    text = repr(c)
    assert "line1.start" in text
    assert "line2.end" in text


def test_coincident_constraint_type_is_coincident():
    c = build_coincident_constraint(
        sketch_feature_id="FS_0",
        entity_a="p1",
        entity_b="p2",
    )
    assert c["constraintType"] == "COINCIDENT"
```

- [ ] **Step 2: Run tests and verify fail**

```bash
./venv/bin/pytest tests/unit/test_sketch_constraints.py -v
```

Expected: 2 FAILED.

- [ ] **Step 3: Implement constraint**

File: `shapecraft/sketch/constraints.py`

```python
"""Sketch constraint builders (v0.1.0-alpha: coincident only).

v0.1.0-batch-2 adds parallel, perpendicular, tangent, horizontal, vertical, dimension.
"""

from typing import Any


def build_coincident_constraint(
    *,
    sketch_feature_id: str,
    entity_a: str,
    entity_b: str,
) -> dict[str, Any]:
    """Return a BTMSketchConstraint payload to merge into a sketch feature."""
    return {
        "btType": "BTMSketchConstraint-2",
        "sketchFeatureId": sketch_feature_id,
        "constraintType": "COINCIDENT",
        "parameters": [
            {
                "btType": "BTMParameterString-149",
                "parameterId": "localFirst",
                "value": entity_a,
            },
            {
                "btType": "BTMParameterString-149",
                "parameterId": "localSecond",
                "value": entity_b,
            },
        ],
    }
```

- [ ] **Step 4: Run tests to verify pass**

```bash
./venv/bin/pytest tests/unit/test_sketch_constraints.py -v
```

Expected: 2 PASSED.

- [ ] **Step 5: Commit**

```bash
git add shapecraft/sketch/constraints.py tests/unit/test_sketch_constraints.py
git commit -m "feat(sketch): coincident constraint builder (first of 7 in T1)"
```

---

### Task 14: MCP server entry point + tool registrations

**Files:**
- Create: `shapecraft/server.py`

- [ ] **Step 1: Write server.py**

File: `shapecraft/server.py`

```python
"""shapecraft MCP stdio server.

Registers the v0.1.0-alpha tool set. Extended by follow-up batches.
"""

import asyncio
import sys
from typing import Any

from loguru import logger
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from shapecraft.core.client import OnshapeClient
from shapecraft.core.types import Credentials, DocumentRef
from shapecraft.documents.operations import (
    create_document,
    create_part_studio,
    list_documents,
)
from shapecraft.features._base import add_feature
from shapecraft.features.extrude import build_extrude_feature
from shapecraft.features.loft import build_loft_feature
from shapecraft.planes.offset import build_offset_plane_feature
from shapecraft.sketch.rectangle import build_sketch_rectangle_feature
from shapecraft.sketch.spline import build_sketch_spline_feature

logger.remove()
logger.add(sys.stderr, level="INFO")

app = Server("shapecraft")
_creds = Credentials.from_env()
_client = OnshapeClient(access_key=_creds.access_key, secret_key=_creds.secret_key)


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="shapecraft_list_documents",
            description="List Onshape documents.",
            inputSchema={
                "type": "object",
                "properties": {
                    "limit": {"type": "integer", "default": 20},
                    "filter_type": {
                        "type": "string",
                        "enum": ["all", "owned", "created", "shared"],
                        "default": "all",
                    },
                },
            },
        ),
        Tool(
            name="shapecraft_create_document",
            description="Create a new (public) Onshape document.",
            inputSchema={
                "type": "object",
                "required": ["name"],
                "properties": {
                    "name": {"type": "string"},
                    "is_public": {"type": "boolean", "default": True},
                    "description": {"type": "string", "default": ""},
                },
            },
        ),
        Tool(
            name="shapecraft_create_part_studio",
            description="Create a Part Studio in a workspace.",
            inputSchema={
                "type": "object",
                "required": ["did", "wid", "name"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "name": {"type": "string"},
                },
            },
        ),
        Tool(
            name="shapecraft_sketch_rectangle",
            description="Sketch a rectangle on Top/Front/Right plane.",
            inputSchema={
                "type": "object",
                "required": ["did", "wid", "eid", "corner1", "corner2"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "eid": {"type": "string"},
                    "plane": {
                        "type": "string",
                        "enum": ["Top", "Front", "Right"],
                        "default": "Top",
                    },
                    "corner1": {
                        "type": "array",
                        "items": {"type": "number"},
                        "minItems": 2,
                        "maxItems": 2,
                    },
                    "corner2": {
                        "type": "array",
                        "items": {"type": "number"},
                        "minItems": 2,
                        "maxItems": 2,
                    },
                    "name": {"type": "string", "default": "Sketch"},
                },
            },
        ),
        Tool(
            name="shapecraft_sketch_spline",
            description="Sketch an interpolated spline through ordered points.",
            inputSchema={
                "type": "object",
                "required": ["did", "wid", "eid", "points"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "eid": {"type": "string"},
                    "plane": {
                        "type": "string",
                        "enum": ["Top", "Front", "Right"],
                        "default": "Top",
                    },
                    "points": {
                        "type": "array",
                        "items": {
                            "type": "array",
                            "items": {"type": "number"},
                            "minItems": 2,
                            "maxItems": 2,
                        },
                        "minItems": 2,
                    },
                    "name": {"type": "string", "default": "Sketch Spline"},
                },
            },
        ),
        Tool(
            name="shapecraft_offset_plane",
            description="Create an offset datum plane from a base plane.",
            inputSchema={
                "type": "object",
                "required": ["did", "wid", "eid", "offset"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "eid": {"type": "string"},
                    "base_plane": {
                        "type": "string",
                        "enum": ["Top", "Front", "Right"],
                        "default": "Top",
                    },
                    "offset": {"type": "number"},
                    "opposite_direction": {"type": "boolean", "default": False},
                    "name": {"type": "string", "default": "Offset Plane"},
                },
            },
        ),
        Tool(
            name="shapecraft_extrude",
            description="Extrude a sketch feature with optional symmetric/reverse.",
            inputSchema={
                "type": "object",
                "required": ["did", "wid", "eid", "sketch_feature_id", "depth"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "eid": {"type": "string"},
                    "sketch_feature_id": {"type": "string"},
                    "depth": {"type": "number"},
                    "operation": {
                        "type": "string",
                        "enum": ["NEW", "ADD", "REMOVE", "INTERSECT"],
                        "default": "NEW",
                    },
                    "symmetric": {"type": "boolean", "default": False},
                    "reverse": {"type": "boolean", "default": False},
                    "name": {"type": "string", "default": "Extrude"},
                },
            },
        ),
        Tool(
            name="shapecraft_loft",
            description="Loft a solid through two or more sketch profiles.",
            inputSchema={
                "type": "object",
                "required": ["did", "wid", "eid", "profile_feature_ids"],
                "properties": {
                    "did": {"type": "string"},
                    "wid": {"type": "string"},
                    "eid": {"type": "string"},
                    "profile_feature_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "minItems": 2,
                    },
                    "operation": {
                        "type": "string",
                        "enum": ["NEW", "ADD", "REMOVE", "INTERSECT"],
                        "default": "NEW",
                    },
                    "closed": {"type": "boolean", "default": False},
                    "name": {"type": "string", "default": "Loft"},
                },
            },
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    logger.info("tool={} args={}", name, arguments)

    if name == "shapecraft_list_documents":
        docs = await list_documents(
            _client,
            limit=arguments.get("limit", 20),
            filter_type=arguments.get("filter_type", "all"),
        )
        return [TextContent(type="text", text=f"{len(docs)} documents: {docs}")]

    if name == "shapecraft_create_document":
        d = await create_document(
            _client,
            name=arguments["name"],
            is_public=arguments.get("is_public", True),
            description=arguments.get("description", ""),
        )
        return [TextContent(type="text", text=f"Created document {d.get('id')}")]

    if name == "shapecraft_create_part_studio":
        e = await create_part_studio(
            _client,
            did=arguments["did"],
            wid=arguments["wid"],
            name=arguments["name"],
        )
        return [TextContent(type="text", text=f"Created part studio {e.get('id')}")]

    if name == "shapecraft_sketch_rectangle":
        doc = DocumentRef(did=arguments["did"], wid=arguments["wid"], eid=arguments["eid"])
        feat = build_sketch_rectangle_feature(
            name=arguments.get("name", "Sketch"),
            plane=arguments.get("plane", "Top"),
            corner1=tuple(arguments["corner1"]),
            corner2=tuple(arguments["corner2"]),
        )
        ref = await add_feature(_client, doc, feat)
        return [TextContent(type="text", text=f"Sketch {ref.feature_id}")]

    if name == "shapecraft_sketch_spline":
        doc = DocumentRef(did=arguments["did"], wid=arguments["wid"], eid=arguments["eid"])
        feat = build_sketch_spline_feature(
            name=arguments.get("name", "Sketch Spline"),
            plane=arguments.get("plane", "Top"),
            points=[tuple(p) for p in arguments["points"]],
        )
        ref = await add_feature(_client, doc, feat)
        return [TextContent(type="text", text=f"Spline {ref.feature_id}")]

    if name == "shapecraft_offset_plane":
        doc = DocumentRef(did=arguments["did"], wid=arguments["wid"], eid=arguments["eid"])
        feat = build_offset_plane_feature(
            name=arguments.get("name", "Offset Plane"),
            base_plane=arguments.get("base_plane", "Top"),
            offset=arguments["offset"],
            opposite_direction=arguments.get("opposite_direction", False),
        )
        ref = await add_feature(_client, doc, feat)
        return [TextContent(type="text", text=f"Plane {ref.feature_id}")]

    if name == "shapecraft_extrude":
        doc = DocumentRef(did=arguments["did"], wid=arguments["wid"], eid=arguments["eid"])
        feat = build_extrude_feature(
            name=arguments.get("name", "Extrude"),
            sketch_feature_id=arguments["sketch_feature_id"],
            depth=arguments["depth"],
            operation=arguments.get("operation", "NEW"),
            symmetric=arguments.get("symmetric", False),
            reverse=arguments.get("reverse", False),
        )
        ref = await add_feature(_client, doc, feat)
        return [TextContent(type="text", text=f"Extrude {ref.feature_id}")]

    if name == "shapecraft_loft":
        doc = DocumentRef(did=arguments["did"], wid=arguments["wid"], eid=arguments["eid"])
        feat = build_loft_feature(
            name=arguments.get("name", "Loft"),
            profile_feature_ids=arguments["profile_feature_ids"],
            operation=arguments.get("operation", "NEW"),
            closed=arguments.get("closed", False),
        )
        ref = await add_feature(_client, doc, feat)
        return [TextContent(type="text", text=f"Loft {ref.feature_id}")]

    raise ValueError(f"unknown tool: {name}")


def main() -> None:
    asyncio.run(_run())


async def _run() -> None:
    async with stdio_server() as (read, write):
        await app.run(read, write, app.create_initialization_options())


if __name__ == "__main__":
    main()
```

- [ ] **Step 2: Verify server imports cleanly**

```bash
ONSHAPE_ACCESS_KEY=dummy ONSHAPE_SECRET_KEY=dummy \
  ./venv/bin/python -c "from shapecraft import server; print(server.app.name)"
```

Expected: `shapecraft`.

- [ ] **Step 3: Commit**

```bash
git add shapecraft/server.py
git commit -m "feat(server): MCP stdio entry with 9 v0.1.0-alpha tools"
```

---

### Task 15: Integration test — end-to-end smoke

**Files:**
- Create: `tests/integration/__init__.py`
- Create: `tests/integration/conftest.py`
- Create: `tests/integration/test_end_to_end.py`

- [ ] **Step 1: Write the fixture**

File: `tests/integration/__init__.py` — empty.

File: `tests/integration/conftest.py`

```python
import os
import pytest
from shapecraft.core.client import OnshapeClient


@pytest.fixture
def live_client():
    ak = os.getenv("ONSHAPE_ACCESS_KEY")
    sk = os.getenv("ONSHAPE_SECRET_KEY")
    if not ak or not sk:
        pytest.skip("Set ONSHAPE_ACCESS_KEY and ONSHAPE_SECRET_KEY to run integration tests")
    return OnshapeClient(access_key=ak, secret_key=sk)
```

- [ ] **Step 2: Write the test**

File: `tests/integration/test_end_to_end.py`

```python
import pytest
from shapecraft.core.types import DocumentRef
from shapecraft.documents.operations import (
    create_document,
    create_part_studio,
    list_documents,
)
from shapecraft.features._base import add_feature
from shapecraft.features.extrude import build_extrude_feature
from shapecraft.sketch.rectangle import build_sketch_rectangle_feature


@pytest.mark.integration
async def test_list_documents_returns_list(live_client):
    docs = await list_documents(live_client, limit=1)
    assert isinstance(docs, list)


@pytest.mark.integration
async def test_cube_pipeline(live_client):
    doc = await create_document(
        live_client, name="shapecraft integration test", is_public=True
    )
    did = doc["id"]
    wid = doc["defaultWorkspace"]["id"]

    ps = await create_part_studio(live_client, did=did, wid=wid, name="IT Part Studio")
    eid = ps["id"]

    ref = DocumentRef(did=did, wid=wid, eid=eid)
    sketch_feat = build_sketch_rectangle_feature(
        name="IT Sketch", plane="Top", corner1=(0.0, 0.0), corner2=(1.0, 1.0)
    )
    sketch_ref = await add_feature(live_client, ref, sketch_feat)
    assert sketch_ref.feature_id

    extrude_feat = build_extrude_feature(
        sketch_feature_id=sketch_ref.feature_id, depth=1.0, operation="NEW"
    )
    ext_ref = await add_feature(live_client, ref, extrude_feat)
    assert ext_ref.feature_id
```

- [ ] **Step 3: Run the integration test (if credentials set)**

```bash
ONSHAPE_ACCESS_KEY=<real> ONSHAPE_SECRET_KEY=<real> \
  ./venv/bin/pytest tests/integration -m integration -v
```

Expected (with real creds): 2 PASSED. Without creds: 2 SKIPPED.

- [ ] **Step 4: Commit**

```bash
git add tests/integration
git commit -m "test(integration): end-to-end cube smoke via full pipeline"
```

---

### Task 16: GitHub Actions — unit-test CI

**Files:**
- Create: `.github/workflows/test.yml`

- [ ] **Step 1: Write workflow**

File: `.github/workflows/test.yml`

```yaml
name: test

on:
  push:
    branches: [main]
  pull_request:

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.10", "3.11", "3.12"]
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
      - run: pip install -e ".[dev]"
      - run: ruff check shapecraft tests
      - run: pytest tests/unit -v --cov=shapecraft --cov-report=term-missing
```

- [ ] **Step 2: Commit**

```bash
git add .github/workflows/test.yml
git commit -m "ci: run ruff + unit tests on py3.10/3.11/3.12"
```

---

### Task 17: GitHub Actions — PyPI release on tag

**Files:**
- Create: `.github/workflows/release.yml`

- [ ] **Step 1: Write workflow**

File: `.github/workflows/release.yml`

```yaml
name: release

on:
  push:
    tags: ["v*"]

jobs:
  build-and-publish:
    runs-on: ubuntu-latest
    permissions:
      id-token: write  # PyPI trusted publishing
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: pip install build
      - run: python -m build
      - uses: pypa/gh-action-pypi-publish@release/v1
        with:
          skip-existing: true
```

Note: PyPI Trusted Publishing must be configured once on PyPI side before the first tag push. Document this in the README release section in Task 18.

- [ ] **Step 2: Commit**

```bash
git add .github/workflows/release.yml
git commit -m "ci: PyPI trusted publishing on tagged releases"
```

---

### Task 18: README rewrite + CHANGELOG seed

**Files:**
- Modify: `README.md`
- Create: `CHANGELOG.md`

- [ ] **Step 1: Rewrite README**

Replace `README.md` with:

````markdown
# shapecraft

> Craft real CAD with Claude. Any shape. Any tool.

**shapecraft** gives Claude (Claude Code, Claude Desktop, Anthropic API) a first-class set of tools to drive professional parametric CAD. v0.1.0-alpha targets Onshape and proves the full pipeline with 9 tools including the first killer upgrades over existing Onshape MCPs: **offset planes**, **sketch splines**, **coincident constraints**, and **loft**.

## Install

```bash
uvx shapecraft   # or: pip install shapecraft
```

## Register with Claude Code

```bash
claude mcp add shapecraft \
  -s user \
  -e ONSHAPE_ACCESS_KEY=<your_key> \
  -e ONSHAPE_SECRET_KEY=<your_secret> \
  -- uvx shapecraft
```

Get your keys at [dev-portal.onshape.com](https://dev-portal.onshape.com).

## v0.1.0-alpha tool list

- `shapecraft_list_documents`
- `shapecraft_create_document`
- `shapecraft_create_part_studio`
- `shapecraft_sketch_rectangle`
- `shapecraft_sketch_spline` *(NEW vs hedless)*
- `shapecraft_offset_plane` *(NEW)*
- `shapecraft_extrude` with symmetric + reverse flags *(upgraded)*
- `shapecraft_loft` *(NEW)*
- `shapecraft` coincident constraint helper *(NEW, 1 of 7 coming in T1)*

See the [design spec](docs/superpowers/specs/2026-04-18-shapecraft-design.md) for the full T1 → T3 roadmap.

## Development

```bash
python3 -m venv venv
./venv/bin/pip install -e ".[dev]"
./venv/bin/pytest tests/unit -v
```

Integration tests (`tests/integration/`) hit live Onshape and require `ONSHAPE_ACCESS_KEY`/`ONSHAPE_SECRET_KEY` env vars.

## Releasing

1. Bump version in `pyproject.toml`
2. Update `CHANGELOG.md`
3. `git tag v0.1.0a1 && git push --tags`
4. `release.yml` publishes to PyPI via trusted publishing (configure once at pypi.org)

## License

MIT. See [LICENSE](LICENSE).

## Credits

Inspired by [hedless/onshape-mcp](https://github.com/hedless/onshape-mcp) (MIT per its README) — shapecraft is an independent reimplementation that covers a broader slice of the Onshape REST and FeatureScript API.
````

- [ ] **Step 2: Seed CHANGELOG**

File: `CHANGELOG.md`

```markdown
# Changelog

## v0.1.0-alpha.1 — 2026-04-18 (unreleased)

### Added
- HMAC-authenticated Onshape REST client with retries and rate-limit logging
- MCP stdio server with 9 tools:
  - `shapecraft_list_documents`, `shapecraft_create_document`, `shapecraft_create_part_studio`
  - `shapecraft_sketch_rectangle`, `shapecraft_sketch_spline`
  - `shapecraft_offset_plane`
  - `shapecraft_extrude` (symmetric + reverse)
  - `shapecraft_loft`
- `build_coincident_constraint` helper (first of 7 in T1)
- Unit test suite (snapshot-based JSON payloads, no network)
- Integration test suite gated by `ONSHAPE_ACCESS_KEY`/`ONSHAPE_SECRET_KEY`
- GitHub Actions: unit tests on py3.10/3.11/3.12, release to PyPI on tag
```

- [ ] **Step 3: Commit**

```bash
git add README.md CHANGELOG.md
git commit -m "docs: v0.1.0-alpha README + CHANGELOG seed"
```

---

### Task 19: Push to GitHub + tag v0.1.0-alpha.1

**Files:** (no new files, remote only)

- [ ] **Step 1: Create remote repo**

```bash
cd /Users/genie/dev/lab/shapecraft
gh repo create newTurn2017/shapecraft \
  --public \
  --description "Craft real CAD with Claude. MCP server for Onshape." \
  --source . \
  --remote origin
```

Expected: repo created at `https://github.com/newTurn2017/shapecraft`.

- [ ] **Step 2: Push main branch**

```bash
git push -u origin main
```

Expected: 18 commits pushed to `origin/main`.

- [ ] **Step 3: Configure PyPI trusted publishing**

Manual step (web UI):
1. Visit https://pypi.org/manage/account/publishing/
2. Add trusted publisher for project `shapecraft`:
   - Owner: `newTurn2017`
   - Repo: `shapecraft`
   - Workflow filename: `release.yml`
   - Environment: (none)

- [ ] **Step 4: Tag and push**

```bash
git tag v0.1.0a1
git push origin v0.1.0a1
```

Expected: `release.yml` runs, builds wheel+sdist, uploads to PyPI. Verify at https://pypi.org/project/shapecraft/.

- [ ] **Step 5: Smoke-test installation from PyPI**

```bash
uvx --from shapecraft==0.1.0a1 shapecraft --help 2>&1 || \
  uvx shapecraft --help 2>&1 | head -5
```

Expected: server launches and exits cleanly when stdio input closes.

- [ ] **Step 6: Commit release notes (if any polish needed)**

If the smoke test surfaces any issue, fix, retag `v0.1.0a2`, repeat.

---

## Self-Review Results

**1. Spec coverage.**
- `core/auth.py` → Task 2. `core/client.py` → Task 3. `core/types.py` → Task 4.
- `documents/operations.py` → Task 5.
- `features/_base.py`, `features/extrude.py`, `features/loft.py` → Tasks 6, 8, 12.
- `planes/offset.py` → Task 10.
- `sketch/rectangle.py`, `sketch/spline.py`, `sketch/constraints.py` → Tasks 7, 11, 13.
- `server.py` → Task 14.
- Unit tests → every builder has a matching `tests/unit/test_*`.
- Integration test → Task 15.
- CI → Tasks 16, 17.
- README + CHANGELOG → Task 18.
- Release → Task 19.
- **Spec scope not covered in this plan (intentional, v0.1.0-batch-2):** Sweep, Shell, Draft, Helix, Mirror (feature), Split, MoveFace; face-based plane, three-point plane; polyline; constraints parallel/perpendicular/tangent/horizontal/vertical/dimension; the ~45 hedless ports beyond the essentials shipped here.

**2. Placeholder scan.** No "TBD"/"TODO"/"fill in later". Every code step contains complete code or exact commands.

**3. Type consistency.**
- `DocumentRef(did, wid, eid)` used in Tasks 4, 14, 15 — consistent.
- `FeatureRef(feature_id, name)` returned by `add_feature` and used in Task 14 — consistent.
- `PLANE_IDS` dict introduced in Task 7, reused in Task 11 via import — consistent.
- `VALID_OPERATIONS` set repeated in Tasks 8 and 12; acceptable because the two modules are independent and DRY would require a cross-module import for a one-line set (not worth the coupling at v0.1).
- All tool names in Task 14 match their respective builder names — consistent.
