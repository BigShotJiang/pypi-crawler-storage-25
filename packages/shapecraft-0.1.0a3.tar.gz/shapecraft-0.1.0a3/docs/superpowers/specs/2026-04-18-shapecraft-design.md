# shapecraft — Design Spec

**Date**: 2026-04-18
**Status**: Draft, awaiting user review
**Author**: newTurn2017

## Context

Connecting Claude to CAD via MCP is a proven pattern — `hedless/onshape-mcp` exists (~51 stars, MIT per README, 45 tools) and demos like Adam AI Tools (LinkedIn post by Stanislav Beliaev, 2026-04) show it works. But every existing Onshape MCP covers only ~15–20% of what the Onshape REST API actually exposes: sketches are limited to rectangles/circles/lines/arcs with no constraints, only three default planes are usable, no Loft/Sweep/Shell/Draft/Rib, no Mirror feature (stable), no Drawings, no Appearance/Materials, no Configurations, no custom FeatureScript. Hands-on testing today (경복궁 massing, chibi robot, cube smoke-test) confirmed these gaps directly: we could produce only block-massing, no curved roofs, no rounded edges, no color — far from "professional CAD with Claude".

Onshape's REST API and FeatureScript Standard Library, in contrast, expose essentially everything the browser UI can do — `opLoft`, `opSweep`, `opShell`, `opDraft`, `opHelix`, `opMirror`, `opSplitPart`, `opMoveFace`, full sketch constraints, drawings with views/dimensions/annotations/BOM, appearance metadata, configurations, custom FeatureStudios, and the OpenAPI spec is public. Roughly 80% of Onshape capability is leave-on-the-table for current MCPs.

**shapecraft** closes that gap. It is an independent, MIT-licensed, Python MCP server that aims to cover the full modeling surface of Onshape first, then extend to Fusion 360 and FreeCAD, positioned as the standard "Claude ↔ CAD" bridge. The project targets 1,000+ GitHub stars within 6 months via staged releases (T1 → T2 → T3), high-impact demos, and inclusion in the official Anthropic MCP directory.

## Goals

1. Give Claude the ability to perform **every Onshape modeling operation the REST + FeatureScript API supports** — starting with the 80% gap listed above.
2. Ship as a **single open-source MIT repo** that installs in one command (`pip install shapecraft` or `uvx shapecraft`) and registers with Claude Code/Desktop in one command.
3. Earn **world-class recognition** in the MCP ecosystem: Anthropic official directory listing, `awesome-mcp-servers` inclusion, 1,000+ GitHub stars within 6 months.
4. **Extensible to multiple CAD platforms** — architecture must support adding Fusion 360, FreeCAD, SolidWorks backends later without reworking the tool contract.

## Non-goals

- Photorealistic rendering (Onshape API does not expose a render engine).
- FEA/CFD simulation (separate PTC product).
- Surface texturing, PBR material maps.
- Replacing the Onshape UI — shapecraft is a complement, not a competitor.
- Proprietary FeatureScript that is not published by Onshape.

## Users

- **Primary**: Engineers and makers who already use Onshape and want to script/automate modeling via natural language through Claude.
- **Secondary**: LLM/AI developers building CAD copilots who want a permissively licensed, battle-tested MCP server.
- **Tertiary**: Educators teaching parametric CAD who want an agent-driven tutor.

## Architecture

### Repository layout

```
shapecraft/
├── shapecraft/               # Python package (PyPI: shapecraft)
│   ├── core/                 # Onshape REST client, HMAC auth, types
│   │   ├── client.py
│   │   ├── auth.py
│   │   └── types.py
│   ├── features/             # Feature builders (one module per op)
│   │   ├── extrude.py        # + start condition, reverse, symmetric
│   │   ├── revolve.py
│   │   ├── loft.py           # NEW (T1)
│   │   ├── sweep.py          # NEW (T1)
│   │   ├── shell.py          # NEW (T1)
│   │   ├── draft.py          # NEW (T1)
│   │   ├── helix.py          # NEW (T1)
│   │   ├── mirror.py         # NEW (T1, feature-level)
│   │   ├── fillet.py
│   │   ├── chamfer.py
│   │   ├── pattern.py
│   │   ├── boolean.py
│   │   ├── thicken.py
│   │   ├── split.py          # NEW (T1)
│   │   └── move_face.py      # NEW (T1)
│   ├── planes/               # Datum planes (T1 extension)
│   │   ├── offset_plane.py   # NEW
│   │   ├── face_plane.py     # NEW
│   │   └── three_point.py    # NEW
│   ├── sketch/               # Sketch primitives + constraints
│   │   ├── rectangle.py
│   │   ├── circle.py
│   │   ├── line.py
│   │   ├── arc.py
│   │   ├── polyline.py       # NEW (T1)
│   │   ├── spline.py         # NEW (T1)
│   │   └── constraints.py    # NEW (T1: coincident, parallel, perpendicular, tangent, horizontal, vertical, dimension)
│   ├── assemblies/           # Assembly operations (port existing + expand)
│   ├── drawings/             # (T2) views, dims, annotations, BOM
│   ├── appearance/           # (T2) RGB color, transparency
│   ├── materials/            # (T2) material name assignment
│   ├── configurations/       # (T3) parametric variants
│   ├── custom_fs/            # (T3) FeatureStudio register/import/call
│   ├── metadata/             # (T3) properties, revisions, release
│   ├── exports/              # STL/STEP/PARASOLID/GLTF/OBJ/DXF/DWG
│   ├── backends/             # (T3+) multi-CAD abstraction
│   │   ├── onshape/          # default
│   │   ├── fusion360/        # (future)
│   │   └── freecad/          # (future)
│   └── server.py             # MCP stdio entrypoint, tool registrations
├── skills/                   # Claude Code plugin skills (published separately)
│   ├── shapecraft-cad-workflow/
│   ├── shapecraft-assembly/
│   └── shapecraft-featurescript/
├── tests/                    # pytest, unit + integration (gated by ONSHAPE_* env)
├── examples/                 # e2e: pi-case, hanok, mecha-robot
├── docs/                     # mkdocs site (published to gh-pages)
│   └── superpowers/specs/
├── .github/
│   └── workflows/            # test, lint (ruff), release to PyPI
├── CHANGELOG.md
├── CONTRIBUTING.md
├── LICENSE                   # MIT
├── README.md
└── pyproject.toml
```

### Components

- **core**: thin HTTP client over Onshape REST v6, HMAC-SHA256 signing, retries, rate-limit awareness (`X-Rate-Limit-Remaining`). Typed with Pydantic v2.
- **features/\***: each module owns one Onshape feature operation. Public surface is a single `async def build(...)` returning the feature-add JSON. The MCP server module registers a tool per build function; no builder is registered more than once.
- **planes/\***: datum-plane creation. Unlocks sketching on offset/face-based planes — removes the biggest current limitation.
- **sketch/\***: primitives + constraints. Constraint module is the key unlock for precise sketches — without it, sketches are unreliable at scale.
- **server.py**: stdio MCP server using the `mcp` Python SDK. Registers all tools from each sub-package. Tool names are `<category>_<action>` (e.g., `shapecraft_loft`, `shapecraft_add_constraint_coincident`) to avoid collision with other MCP servers.
- **skills/**: Claude Code plugin skills that pair with the MCP. They encode workflow knowledge (CAD brainstorming, 5-step assembly methodology, feature-recipe catalog) so Claude uses the tools well.

### Data flow

1. Claude decides to call `shapecraft_loft` with profiles, guides, end conditions.
2. `server.py` dispatches to `features/loft.py::build()`.
3. `build()` constructs a BTMFeature-JSON payload, posts to `/partstudios/d/{D}/w/{W}/e/{E}/features` via `core.client`.
4. Onshape responds with the new feature ID; `server.py` returns a concise summary to Claude (feature ID + key params).
5. Claude continues (e.g., chained fillet on the loft output).

Read operations (`get_body_details`, `get_bounding_box`) go through `eval_featurescript` with canned FS lambdas.

### Error handling

- **Validation** at boundaries only (tool arg schemas via Pydantic). No defensive checks on internal code paths.
- **Onshape errors** are surfaced verbatim (status code + body) — Claude is smart enough to adapt.
- **Retries** only on transient failures (5xx, timeouts) with exponential backoff. 4xx is never retried.
- **Rate limiting** honored via `X-Rate-Limit-Remaining` header; if low, sleep and retry once.

### Testing

- **Unit tests**: each builder has pure-function tests that snapshot the generated JSON payload (no network).
- **Integration tests**: opt-in via `ONSHAPE_ACCESS_KEY`/`ONSHAPE_SECRET_KEY` env. CI runs unit only; nightly integration in fork-protected workflow.
- **Example scripts** in `examples/` double as acceptance tests — each must produce a known bounding box.
- Coverage target: ≥80% unit; integration gated.

## Staged scope

### T1 (v0.1, target ~2 weeks)

**Port + expand**. Rewrite the 45 existing hedless tools with the new naming/structure, and add:

- **Features**: Loft, Sweep, Shell, Draft, Helix, Mirror (feature), Split, MoveFace (10 new)
- **Planes**: Offset Plane, Face Plane, Three-point Plane (3 new)
- **Sketch**: Polyline, Spline (2 new)
- **Sketch constraints**: Coincident, Parallel, Perpendicular, Tangent, Horizontal, Vertical, Dimension (7 new)
- **Extrude upgrades**: Start condition (plane/face/offset), symmetric, reverse direction

Tool count: **≈65**. This single release already eclipses all existing Onshape MCPs and makes curved, constrained, precisely-dimensioned modeling possible.

### T2 (v0.5, target 1 month after T1)

- **Drawings**: create drawing, add top/projected views, linear/radial/angular/ordinate/chamfer dimensions, annotations (note/callout/centerline/datum/surface finish), tolerances, BOM, title block (≈15 tools)
- **Appearance**: set RGB color and transparency on parts (≈3 tools)
- **Materials**: set material name from Onshape library (≈2 tools)

Tool count after T2: **≈85**. Unlocks manufacturing-ready outputs (2D drawings) and visual polish (color coding for ergonomics/review).

### T3 (v1.0, target 3 months from start)

- **Custom FeatureScript**: register/import/call custom FeatureStudios (≈5 tools) — reusable parametric modules (e.g., a "hanok-dougong" custom feature).
- **Configurations**: create/read/update configuration table, instantiate variants (≈5 tools) — parametric product families.
- **Metadata/PLM**: part properties, revisions, release workflow (≈5 tools).

Tool count after T3: **≈100**. At this point shapecraft covers the vast majority of Onshape's API and is the clear default for Claude-based CAD.

## Distribution

- **PyPI**: `pip install shapecraft`
- **uvx**: `uvx shapecraft` (zero-install run)
- **Claude Code**: `claude mcp add shapecraft -s user -e ONSHAPE_ACCESS_KEY=... -e ONSHAPE_SECRET_KEY=... -- uvx shapecraft`
- **Claude Desktop**: `uvx shapecraft` with env in config JSON
- **Skills**: published as separate `claude-plugins-` style skill pack (or bundled in a `shapecraft-skills` npm/pypi package)

## Go-to-market

1. **Demos (before or alongside v0.1)**: three GIFs in README — Raspberry Pi case (30s), Hanok hall (3 min), Chibi mecha robot (5 min). Each demonstrates a feature class that only shapecraft can do (loft/shell/curved profiles).
2. **Twitter/X launch**: tag `@adamdotnew` (Adam AI Tools creator) and MCP community accounts.
3. **Submissions**:
   - `awesome-mcp-servers` PR
   - Anthropic MCP official directory
   - Onshape App Store (wrapped as an app)
   - Hacker News ("Show HN: Claude driving real parametric CAD")
   - Reddit: r/CAD, r/LocalLLaMA, r/Onshape
4. **Content**: dev.to and Medium post "Teaching Claude to use CAD: What 100 tools unlock".
5. **Internationalization**: README in English, Korean, Japanese; examples with Korean/English comments side-by-side.

## Milestones

| Milestone | Target date (weeks from 2026-04-18) | Output |
|---|---|---|
| M0: Repo scaffold + design doc committed | 2026-04-18 (today) | `newTurn2017/shapecraft` on GitHub, initial commit on `main` |
| M1: T1 MVP (v0.1.0) — 65 tools | +2 weeks | PyPI release, README demo GIFs, private beta |
| M2: Public launch + awesome-mcp-servers PR | +3 weeks | 100+ stars target |
| M3: T2 (v0.5.0) — drawings + appearance | +6 weeks | 300+ stars target |
| M4: T3 (v1.0.0) — custom FS + configs + PLM | +12 weeks | 1,000+ stars target, Anthropic directory listing |
| M5: Multi-CAD backend (Fusion 360 PoC) | +24 weeks | v1.1 with backend abstraction |

## Risks and mitigations

- **Onshape API changes**: pin to REST v6, track changelog, CI nightly against live API.
- **Adam AI Tools / hedless direct competition**: differentiate on breadth (T2 drawings + T3 configs + multi-CAD) and quality (typed, tested, documented). Actively collaborate — submit LICENSE-file PR upstream; invite hedless to contribute.
- **Onshape rate limits**: implement `X-Rate-Limit-Remaining` handling; document usage patterns.
- **LLM hallucination of FeatureScript / sketches**: ship skill packs with curated recipes and a 5-step assembly workflow that prevents common failures.
- **License gray area on hedless inspiration**: no code copied; architecture and tool names redesigned from the public Onshape API docs; credits in README.

## Open questions (to resolve during writing-plans)

- Python MCP SDK choice: official `mcp` package vs. `fastmcp`. Affects code shape.
- uvx vs. `pipx run` vs. plain `pip install` as the recommended install path for end users.
- Skills packaging: separate repo, monorepo subdir, or Claude plugin store?
- Docs: mkdocs-material vs. Docusaurus vs. plain GitHub Pages README?

These are implementation decisions, not design changes, and are resolved in the next step (writing-plans).
