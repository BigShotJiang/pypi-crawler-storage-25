"""
cli/main.py — Unified CLI entry point for arcgis-item-graph.

Usage:
    python -m cli create [options]
    python -m cli update [options]
    python -m cli query --item-id <id> [options]
    python -m cli query --search <string> [options]

All values default to config/config.yaml. CLI flags override for a single run.
"""
import argparse
import json
import logging
import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

import yaml
from dotenv import load_dotenv
from arcgis.gis import GIS
from arcgis_item_graph import ItemGraphCreator, ItemGraphUpdater, ItemGraphQuery
from arcgis_item_graph.cache import MetadataCache


def _safe_title(title: str, max_len: int = 40) -> str:
    """Convert an item title to a Windows-safe folder name segment.

    Strips Windows-illegal chars (/ \\ : * ? " < > |), replaces spaces and
    remaining non-word chars with underscore, collapses runs of underscores,
    strips leading/trailing underscores, and truncates to max_len.
    """
    safe = re.sub(r'[/\\:*?"<>|]', "_", title)
    safe = re.sub(r"[^\w\-]", "_", safe)
    safe = re.sub(r"_+", "_", safe)
    safe = safe.strip("_")
    return safe[:max_len]


def _run_log_path(config: dict) -> Path:
    """Return path to graph_run_log.json; derived from gml_file dir if not set."""
    explicit = config.get("paths", {}).get("run_log", "")
    if explicit:
        return Path(explicit)
    return Path(config["paths"]["gml_file"]).parent / "graph_run_log.json"


def _read_run_log(path: Path) -> dict | None:
    """Read run_log.json; return None on missing or corrupt file."""
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return None
    except (json.JSONDecodeError, OSError):
        return None


def _write_run_log(path: Path, data: dict) -> None:
    """Write run-log JSON via temp file + os.replace().

    Falls back to a direct write on Windows UNC network shares where
    os.replace() may fail with PermissionError (WinError 5).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp.json")
    tmp.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
    try:
        os.replace(tmp, path)
    except PermissionError:
        # os.replace() can fail on Windows UNC network shares (WinError 5)
        # because MoveFileExW with MOVEFILE_REPLACE_EXISTING is denied by
        # some SMB configurations even when read/write access is granted.
        # Fall back to a non-atomic direct write.
        path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass


def _check_path_writable(path: Path, label: str) -> None:
    """Verify a path's parent directory is reachable and writable.

    Writes a sentinel file, reads it back to confirm the write actually
    landed on the expected filesystem (not silently redirected to a local
    path), then deletes it.  Calls sys.exit(1) with a descriptive message
    on any failure so the long-running crawl never starts against an
    inaccessible or mis-configured share.

    Args:
        path:  The target file path (e.g. the .gml file).  The parent
               directory is what gets tested.
        label: Human-readable name shown in error messages (e.g. "GML file").
    """
    resolved = path.resolve()
    directory = resolved.parent
    print(f"  {label}: {resolved}")

    # 1. Ensure directory exists (or can be created)
    try:
        directory.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        print(f"\n✗ Cannot create directory for {label}:")
        print(f"  Path : {directory}")
        print(f"  Error: {e}")
        print("  Check that the share is mounted and the path is correct.")
        sys.exit(1)

    # 2. Write sentinel, read back, delete
    sentinel = directory / ".arcgis_graph_write_check"
    token = "arcgis-graph-write-check"
    try:
        sentinel.write_text(token, encoding="utf-8")
        got = sentinel.read_text(encoding="utf-8")
        if got != token:
            raise OSError(
                f"Read-back mismatch: wrote {token!r}, read {got!r}. "
                "The path may be redirected to a different filesystem."
            )
    except OSError as e:
        try:
            sentinel.unlink(missing_ok=True)
        except OSError:
            pass
        print(f"\n✗ Cannot write to {label} directory:")
        print(f"  Path : {directory}")
        print(f"  Error: {e}")
        print("  Verify share permissions and that the UNC path is correct.")
        sys.exit(1)

    try:
        sentinel.unlink()
    except OSError:
        pass  # Non-fatal; file will be cleaned up eventually


def _local_staging_dir() -> Path:
    """Return ~/Documents/arcgis-graph — the local staging dir for --local-first."""
    return Path.home() / "Documents" / "arcgis-graph"


def _cache_path(cfg: dict) -> str:
    """Return path to the metadata SQLite database.

    Uses paths.metadata_db from config if set; otherwise derives from output_dir.
    """
    explicit = cfg.get("paths", {}).get("metadata_db", "")
    if explicit:
        return explicit
    return str(Path(cfg["paths"]["output_dir"]) / "meta.sqlite")


def _find_cache(
    cache_base: Path,
    item_id: str,
    cache_hours: float,
    formats: list,
) -> "tuple[Path, str] | None":
    """Return (run_dir, age_str) for a fresh cache hit, or None.

    Searches for any folder matching *_{item_id} under cache_base,
    then finds the most recent timestamped subfolder that is fresh
    and contains all required output files.
    """
    if not cache_base.exists():
        return None
    candidates = sorted(cache_base.glob(f"*_{item_id}"))
    if not candidates:
        return None
    item_dir = candidates[-1]
    file_map = {
        "excel": "dependency_report.xlsx",
        "html": "dependency_graph.html",
        "csv": "dependency_report.csv",
        "gml": "query_subgraph.gml",
    }
    run_dirs = sorted(
        (d for d in item_dir.iterdir() if d.is_dir()),
        key=lambda p: p.name,
        reverse=True,
    )
    for run_dir in run_dirs:
        missing = [
            file_map[f] for f in formats
            if f in file_map and not (run_dir / file_map[f]).exists()
        ]
        if missing:
            continue
        try:
            run_time = datetime.strptime(run_dir.name, "%Y%m%d_%H%M%S")
        except ValueError:
            continue
        age_s = (datetime.now() - run_time).total_seconds()
        if age_s <= cache_hours * 3600:
            mins = int(age_s / 60)
            age_str = f"{mins // 60}h {mins % 60}m" if mins >= 60 else f"{mins}m"
            return run_dir, age_str
    return None


DEFAULT_CONFIG = Path("config/config.yaml")


# ── Config ────────────────────────────────────────────────────────────────────

def load_config(config_path: Path) -> dict:
    """Load and return the YAML config dict.

    Exits with a helpful message if the file is not found.
    """
    from arcgis_item_graph.console import print_error_panel
    if not config_path.exists():
        print_error_panel(
            "Configuration Error",
            f"No config found at {config_path}.",
            hint=(
                "Run [cyan]arcgis-graph setup[/] to create one, "
                "or copy [cyan]config/config.example.yaml[/] manually."
            ),
        )
        sys.exit(1)
    with open(config_path) as f:
        data = yaml.safe_load(f)
    if not isinstance(data, dict):
        print_error_panel(
            "Configuration Error",
            f"Invalid config at {config_path}: expected a YAML mapping, "
            f"got {type(data).__name__}.",
            hint="Check that your config/config.yaml is properly formatted.",
        )
        sys.exit(1)
    return data


def validate_config(config: dict, config_path: Path) -> None:
    """Exit with a helpful message if required config sections or keys are missing."""
    from arcgis_item_graph.console import print_error_panel
    required_sections = ["auth", "paths", "create", "update", "query"]
    missing_sections = [key for key in required_sections if key not in config]
    if missing_sections:
        print_error_panel(
            "Configuration Error",
            f"Config at {config_path} is missing required sections: "
            f"{', '.join(missing_sections)}.",
            hint="Copy config/config.example.yaml to config/config.yaml "
                 "and fill in all sections.",
        )
        sys.exit(1)

    required_keys: dict[str, list[str]] = {
        "paths": ["gml_file", "timestamp_file", "output_dir"],
        "create": ["max_items"],
        "update": ["max_retries", "retry_delay"],
        "query": ["output_formats"],
    }
    missing_keys = []
    for section, keys in required_keys.items():
        if not isinstance(config.get(section), dict):
            missing_keys.extend(f"{section}.{key}" for key in keys)
            continue
        for key in keys:
            if key not in config[section]:
                missing_keys.append(f"{section}.{key}")
    if missing_keys:
        print_error_panel(
            "Configuration Error",
            f"Config at {config_path} is missing required keys: "
            f"{', '.join(missing_keys)}.",
            hint="Copy config/config.example.yaml to config/config.yaml "
                 "and fill in all sections.",
        )
        sys.exit(1)

    # Validate output_formats is a YAML list, not a scalar
    if isinstance(config.get("query"), dict):
        output_formats = config["query"].get("output_formats")
        if output_formats is not None and not isinstance(output_formats, list):
            print_error_panel(
                "Configuration Error",
                f"Config at {config_path}: query.output_formats must be a YAML list "
                "(e.g. '- csv\\n- html').",
                hint="Check config/config.example.yaml for the correct format.",
            )
            sys.exit(1)


# ── Auth ──────────────────────────────────────────────────────────────────────

def resolve_gis(config: dict, args: argparse.Namespace) -> "GIS":
    """Build a GIS connection from config + CLI flag overrides.

    Priority: CLI flag > config.yaml auth.profile > .env / env vars.
    """
    from arcgis_item_graph.console import print_error_panel
    verify_cert = config["auth"].get("verify_cert", True)

    # CLI --profile flag takes priority over everything
    profile = getattr(args, "profile", None) or config["auth"].get("profile", "")
    if profile:
        try:
            return GIS(profile=profile, verify_cert=verify_cert)
        except Exception as e:
            print_error_panel(
                "Authentication Failed",
                f"Profile '{profile}': {e}",
                hint="Check portal URL, profile name, and verify_cert setting in config.",
            )
            sys.exit(1)

    # Fall back to env vars (loaded from .env or shell environment)
    url = getattr(args, "url", None) or os.environ.get("ARCGIS_URL")
    user = getattr(args, "user", None) or os.environ.get("ARCGIS_USER")
    password = getattr(args, "password", None) or os.environ.get("ARCGIS_PASSWORD")
    if getattr(args, "password", None):
        logging.warning(
            "--password used. Your password may appear in shell history. "
            "Prefer: a .env file or --profile (named credential store)."
        )

    missing = [
        name for name, val in [
            ("ARCGIS_URL", url),
            ("ARCGIS_USER", user),
            ("ARCGIS_PASSWORD", password),
        ]
        if not val
    ]
    if missing:
        print_error_panel(
            "Authentication Failed",
            f"Missing credentials: {', '.join(missing)}.",
            hint=(
                "Options:\n"
                "  1. Set auth.profile in config/config.yaml\n"
                "  2. Set ARCGIS_URL, ARCGIS_USER, ARCGIS_PASSWORD in your .env\n"
                "  3. Pass --profile or --url/--user/--password"
            ),
        )
        sys.exit(1)

    try:
        return GIS(url=url, username=user, password=password, verify_cert=verify_cert)
    except Exception as e:
        print_error_panel(
            "Authentication Failed",
            str(e),
            hint="Check portal URL, credentials, and verify_cert setting.",
        )
        sys.exit(1)


# ── Subcommands ───────────────────────────────────────────────────────────────

def cmd_setup(args: argparse.Namespace) -> None:
    """Interactive wizard to create config/config.yaml."""
    import getpass as _getpass

    config_path = Path(args.config)

    if config_path.exists():
        answer = input(f"{config_path} already exists. Overwrite? [y/N] ").strip().lower()
        if answer != "y":
            print("Setup cancelled.")
            return

    print("\nArcGIS Item Graph — Setup Wizard")
    print("Press Enter to accept the default shown in [brackets].\n")

    portal_url = (
        input("Portal URL [https://www.arcgis.com]: ").strip()
        or "https://www.arcgis.com"
    )

    print("\nAuthentication method:")
    print("  1  Named ArcGIS profile (recommended for GIS admins)")
    print("  2  Username and password (stored in .env)")
    auth_choice = input("Choice [1]: ").strip() or "1"

    profile = ""
    env_content = None

    if auth_choice == "1":
        profile = input("Profile name: ").strip()
    else:
        username = input("Username: ").strip()
        password = _getpass.getpass("Password: ")
        env_content = (
            f"ARCGIS_URL={portal_url}\n"
            f"ARCGIS_USER={username}\n"
            f"ARCGIS_PASSWORD={password}\n"
        )

    verify_cert_raw = input("\nVerify SSL certificate? [Y/n]: ").strip().lower()
    verify_cert = verify_cert_raw != "n"

    output_dir = (
        input(
            "Output directory (local path or UNC share, e.g. \\\\server\\share\\arcgis-graph\\outputs)\n"
            "  [outputs]: "
        ).strip() or "outputs"
    ).replace("\\", "/")

    config_content = f"""\
# ArcGIS Item Dependency Graph — Configuration
# Generated by: arcgis-graph setup

auth:
  profile: "{profile}"
  verify_cert: {str(verify_cert).lower()}

paths:
  gml_file: "{output_dir}/graph.gml"
  timestamp_file: "{output_dir}/graph.timestamp"
  output_dir: "{output_dir}"
  run_log: ""

create:
  max_items: 10000

update:
  max_retries: 5
  retry_delay: 5.0

cache:
  update_warn_hours: 24
  query_cache_hours: 24

query:
  max_depth: null
  traversal_direction: both   # upstream | downstream | both
  output_formats:
    - excel
    - html
    - gml
"""
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(config_content)
    print(f"\n✓ Config written to {config_path}")

    if env_content is not None:
        Path(".env").write_text(env_content)
        print("✓ Credentials written to .env (gitignored)")

    print("\nNext steps:")
    print("  arcgis-graph create              # Build the dependency graph (run once)")
    print("  arcgis-graph query --item-id ID  # Query the graph")


def cmd_create(args: argparse.Namespace, config: dict) -> None:
    """Build the org-wide dependency graph from scratch."""
    from arcgis_item_graph.console import (
        CommandProgress, print_completion_table, print_error_panel, print_step,
    )

    gml_file = args.gml_file or config["paths"]["gml_file"]
    timestamp_file = getattr(args, "timestamp_file", None) or config["paths"]["timestamp_file"]
    max_items = args.max_items if args.max_items is not None else config["create"]["max_items"]
    local_first = getattr(args, "local_first", False)

    if local_first:
        # ── Local-first mode: crawl → local staging dir, then copy to share ──
        local_dir = _local_staging_dir()
        local_gml = local_dir / Path(gml_file).name
        local_ts  = local_dir / Path(timestamp_file).name

        print_step(f"Local-first mode: staging to {local_dir}")
        print_step("Checking write access to local staging directory…")
        _check_path_writable(local_gml, "local GML file")
        print_step("Local write access confirmed")

        gis = resolve_gis(config, args)
        print_step(f"Connected as: {gis.users.me.username}")

        include_reverse = config.get("create", {}).get("include_reverse", True)
        outside_org = config.get("create", {}).get("outside_org", True)
        with CommandProgress("Create", total=max_items) as prog:
            creator = ItemGraphCreator(
                gis=gis,
                gml_file=str(local_gml),
                timestamp_file=str(local_ts),
                max_items=max_items,
                on_progress=prog.on_item,
                on_warning=prog.on_warning,
                include_reverse=include_reverse,
                outside_org=outside_org,
                cache_path=_cache_path(config),
            )
            result = creator.create()

        if not result["success"]:
            print_error_panel(
                "Create failed",
                result.get("error", "Unknown error"),
                hint="Check logs for details.",
            )
            sys.exit(1)

        # Local archive snapshot
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        local_gml_path = Path(result["gml_file"])
        local_archive = local_gml_path.with_stem(f"{local_gml_path.stem}_{ts}")
        shutil.copy2(local_gml_path, local_archive)

        # ── Attempt share copy ────────────────────────────────────────────────
        print_step("Copying to share…")
        share_ok = True
        for src, dst, label in [
            (local_gml, Path(gml_file),       "GML file"),
            (local_ts,  Path(timestamp_file),  "Timestamp"),
        ]:
            try:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
                print_step(f"{label}: {dst}")
            except OSError as e:
                print_step(f"{label} copy failed: {e}")
                share_ok = False

        if share_ok:
            now_iso = datetime.now().isoformat(timespec="seconds")
            _write_run_log(_run_log_path(config), {
                "last_create": now_iso,
                "last_update": now_iso,
                "create_items_indexed": result["items_indexed"],
                "update_stats": None,
            })

        broken = prog.warning_count
        healthy = result["items_indexed"] - broken
        print_completion_table("Create complete", [
            ("Items indexed", str(result["items_indexed"])),
            ("Healthy",       f"[green]{healthy}[/]"),
            ("Broken",        f"[red]{broken}[/]" if broken else "0"),
            ("Graph file",    str(Path(result["gml_file"]))),
            ("Local archive", str(local_archive)),
            ("Share copy",    "✓ complete" if share_ok else "⚠ failed — check share"),
            ("Next step",     "[dim]arcgis-graph update[/]"),
        ], result["duration"])

        if not share_ok:
            print_step(f"Share copy failed. Local files preserved at: {local_dir}")

    else:
        # ── Default mode: pre-flight check, then write directly to share ──────
        print_step("Checking write access to output paths…")
        _check_path_writable(Path(gml_file), "GML file")
        _check_path_writable(Path(timestamp_file), "Timestamp file")
        _check_path_writable(_run_log_path(config), "Run log")
        print_step("Write access confirmed")

        gis = resolve_gis(config, args)
        print_step(f"Connected as: {gis.users.me.username}")

        Path(gml_file).parent.mkdir(parents=True, exist_ok=True)

        include_reverse = config.get("create", {}).get("include_reverse", True)
        outside_org = config.get("create", {}).get("outside_org", True)
        with CommandProgress("Create", total=max_items) as prog:
            creator = ItemGraphCreator(
                gis=gis,
                gml_file=gml_file,
                timestamp_file=timestamp_file,
                max_items=max_items,
                on_progress=prog.on_item,
                on_warning=prog.on_warning,
                include_reverse=include_reverse,
                outside_org=outside_org,
                cache_path=_cache_path(config),
            )
            result = creator.create()

        if not result["success"]:
            print_error_panel(
                "Create failed",
                result.get("error", "Unknown error"),
                hint="Check logs for details.",
            )
            sys.exit(1)

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        gml_path = Path(result["gml_file"])
        archive = gml_path.with_stem(f"{gml_path.stem}_{ts}")
        shutil.copy2(gml_path, archive)
        now_iso = datetime.now().isoformat(timespec="seconds")
        _write_run_log(_run_log_path(config), {
            "last_create": now_iso,
            "last_update": now_iso,
            "create_items_indexed": result["items_indexed"],
            "update_stats": None,
        })

        broken = prog.warning_count
        healthy = result["items_indexed"] - broken
        print_completion_table("Create complete", [
            ("Items indexed", str(result["items_indexed"])),
            ("Healthy",       f"[green]{healthy}[/]"),
            ("Broken",        f"[red]{broken}[/]" if broken else "0"),
            ("Graph file",    str(Path(result["gml_file"]))),
            ("Next step",     "[dim]arcgis-graph update[/]"),
        ], result["duration"])


def cmd_update(args: argparse.Namespace, config: dict) -> None:
    """Incrementally update the graph with items changed since last run."""
    from arcgis_item_graph.console import (
        CommandProgress, print_completion_table, print_error_panel, print_step,
    )

    # --skip-if-fresh: no-op if updated within the warn window
    if getattr(args, "skip_if_fresh", False):
        run_log = _read_run_log(_run_log_path(config))
        if run_log and run_log.get("last_update"):
            try:
                last_dt = datetime.fromisoformat(run_log["last_update"])
                warn_hours = config.get("cache", {}).get("update_warn_hours", 24)
                age_hours = (datetime.now() - last_dt).total_seconds() / 3600
                if age_hours < warn_hours:
                    print_step(
                        f"Graph updated {age_hours:.1f}h ago — skipping (--skip-if-fresh)"
                    )
                    return
            except (ValueError, TypeError):
                pass  # malformed timestamp — proceed with update

    gis = resolve_gis(config, args)
    print_step(f"Connected as: {gis.users.me.username}")

    gml_file = args.gml_file or config["paths"]["gml_file"]
    timestamp_file = getattr(args, "timestamp_file", None) or config["paths"]["timestamp_file"]
    max_retries = args.max_retries if args.max_retries is not None else config["update"]["max_retries"]
    retry_delay = args.retry_delay if args.retry_delay is not None else config["update"]["retry_delay"]
    max_items = config["create"]["max_items"]   # reuse same cap as the create step

    include_reverse = config.get("create", {}).get("include_reverse", True)
    outside_org = config.get("create", {}).get("outside_org", True)
    with CommandProgress("Update", total=None) as prog:
        updater = ItemGraphUpdater(
            gis=gis,
            gml_file=gml_file,
            timestamp_file=timestamp_file,
            max_retries=max_retries,
            retry_delay=retry_delay,
            max_items=max_items,
            on_progress=prog.on_item,
            on_warning=prog.on_warning,
            include_reverse=include_reverse,
            outside_org=outside_org,
            cache_path=_cache_path(config),
        )
        try:
            stats = updater.update()
        except FileNotFoundError:
            print_error_panel(
                "Graph Not Found",
                f"No graph file at {gml_file}.",
                hint="Run 'arcgis-graph create' first to build the initial graph.",
            )
            sys.exit(1)
        except Exception as e:
            print_error_panel("Update Failed", str(e))
            sys.exit(1)

    # Merge run-log: preserve last_create, update last_update + stats
    run_log_path_val = _run_log_path(config)
    existing = _read_run_log(run_log_path_val) or {}
    existing["last_update"] = datetime.now().isoformat(timespec="seconds")
    items_processed = stats.get("modified_items_found", 0)
    items_removed = stats.get("items_deleted", 0)
    items_added = (
        stats.get("new_graph_items", 0)
        - stats.get("old_graph_items", 0)
        + items_removed
    )
    existing["update_stats"] = {
        "added": items_added,
        "modified": items_processed,
        "removed": items_removed,
    }
    _write_run_log(run_log_path_val, existing)

    print_completion_table("Update complete", [
        ("Items processed", str(items_processed)),
        ("Net new nodes",   str(items_added)),
        ("Removed",         str(items_removed)),
        ("Next step",       "[dim]arcgis-graph query --item-id <id>[/]"),
    ], stats["duration"])


def cmd_query(args: argparse.Namespace, config: dict) -> None:
    """Query the graph by item ID or search string, write configured outputs."""
    import pandas as pd  # deferred — only needed for query; keeps create/update startup fast
    from arcgis_item_graph.console import (
        CommandProgress, print_completion_table, print_error_panel,
        console as rich_console,
    )

    if not args.item_id and not args.search:
        print_error_panel(
            "Missing argument",
            "Provide --item-id or --search to query the graph.",
            hint="Example: arcgis-graph query --item-id <32-char-id>",
        )
        sys.exit(1)

    gis = resolve_gis(config, args)
    rich_console.print(f"[dim]▸[/] Connected as: {gis.users.me.username}")

    gml_file = args.gml_file or config["paths"]["gml_file"]
    base_output_dir = Path(args.output_dir or config["paths"]["output_dir"])

    # CLI --format flags override config output_formats entirely
    formats = args.format or config["query"]["output_formats"]

    # ── Staleness check ────────────────────────────────────────────────────────
    _warn_hours = config.get("cache", {}).get("update_warn_hours", 24)
    _run_log = _read_run_log(_run_log_path(config))
    if _run_log is None:
        rich_console.print("[yellow]⚠[/]  run_log.json not found — staleness check skipped")
        rich_console.print("   [dim](Run 'arcgis-graph create' to initialize the shared graph)[/]")
    elif _run_log.get("last_update"):
        try:
            _last_dt = datetime.fromisoformat(_run_log["last_update"])
            _age_h = (datetime.now() - _last_dt).total_seconds() / 3600
            if _age_h > _warn_hours:
                _last_str = _last_dt.strftime("%H:%M")
                _age_str = f"{int(_age_h)}h {int((_age_h % 1) * 60)}m"
                rich_console.print(
                    f"[yellow]⚠[/]  Graph is {_age_str} old (last update: {_last_str})"
                    " — run 'arcgis-graph update' to refresh"
                )
        except (ValueError, TypeError):
            pass  # malformed timestamp — skip silently

    # ── Query cache lookup (--item-id only) ────────────────────────────────────
    _cache_hours = config.get("cache", {}).get("query_cache_hours", 24)
    _force_refresh = getattr(args, "force_refresh", False)

    if args.item_id and not _force_refresh and _cache_hours > 0:
        _cache_base = base_output_dir / "reports" / "query"
        _hit = _find_cache(_cache_base, args.item_id, _cache_hours, formats)
        if _hit is not None:
            _hit_dir, _hit_age = _hit
            rich_console.print(f"\n[green]✓[/] Using cached result from {_hit_age} ago")
            rich_console.print(f"  {_hit_dir}")
            _file_map = {
                "excel": "dependency_report.xlsx",
                "html": "dependency_graph.html",
                "csv": "dependency_report.csv",
                "gml": "query_subgraph.gml",
            }
            for fmt in formats:
                _fname = _file_map.get(fmt)
                if _fname and (_hit_dir / _fname).exists():
                    rich_console.print(f"  {_fname}")
            if getattr(args, "serve", False):
                _cached_html = _hit_dir / "dependency_graph.html"
                if _cached_html.exists():
                    rich_console.print(
                        "  [dim](serving cached dashboard — use --force-refresh to re-run query)[/]"
                    )
                    from cli.server import serve_dashboard
                    serve_dashboard(
                        html_bytes=_cached_html.read_bytes(),
                        gis=gis,
                        config=config,
                        port=args.port,
                    )
                    return
                # HTML missing from cache — fall through to fresh query
                rich_console.print("  [dim](cached HTML not found — re-running query)[/]")
            else:
                return

    with CommandProgress("Query") as prog:
        prog.set_step("Traversing graph…")
        max_depth = config["query"].get("max_depth")
        traversal_direction = config["query"].get("traversal_direction", "both")
        q = ItemGraphQuery(gis=gis, gml_file=gml_file, max_depth=max_depth,
                           traversal_direction=traversal_direction)
        result = (
            q.query(ids=[args.item_id]) if args.item_id
            else q.query(search=args.search)
        )

        prog.set_step("Hydrating nodes…")
        df = result.to_dataframe()

        prog.set_step("Writing outputs…")

        # Output folder: {safe_title}_{item_id}/{ts}/ for --item-id; ts/ for --search
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        if args.item_id:
            _item_title = ""
            if not df.empty and "title" in df.columns:
                _queried = df[df["queried_item"] == True] if "queried_item" in df.columns else df
                if not _queried.empty:
                    _item_title = str(_queried["title"].iloc[0])
            _safe = _safe_title(_item_title) if _item_title else ""
            _folder = f"{_safe}_{args.item_id}" if _safe else args.item_id
            run_dir = base_output_dir / "reports" / "query" / _folder / ts
        else:
            run_dir = base_output_dir / "reports" / "query" / ts
        run_dir.mkdir(parents=True, exist_ok=True)

        # ── Run audit if requested ─────────────────────────────────────────────
        audit_report = None
        if getattr(args, "audit", False):
            from arcgis_item_graph.auditor import ItemDependencyAuditor
            prog.set_step("Running audit…")
            try:
                auditor = ItemDependencyAuditor(gis=gis)
                audit_report = auditor.audit(result)
                prog.set_step(
                    f"Audit complete: {audit_report.total_missing_from_graph} missing, "
                    f"{audit_report.total_extra_in_graph} phantom, "
                    f"{audit_report.skipped_count} skipped"
                )
            except Exception as exc:
                logging.warning("Audit failed — continuing without audit data: %s", exc)

        # Build cache reference for risk scoring (optional — only if db exists)
        cache_db = _cache_path(config)
        cache_obj = MetadataCache(cache_db) if Path(cache_db).exists() else None
        # ── Probe service URL liveness if requested ─────────────────────────────
        if getattr(args, "service_check", False) and cache_obj:
            prog.set_step("Probing service URL liveness…")
            verify = config["auth"].get("verify_cert", True)
            result._probe_url_nodes(cache_obj, verify_cert=verify)

        try:
            if "excel" in formats:
                xlsx_path = str(run_dir / "dependency_report.xlsx")
                from arcgis_item_graph.reporter import ItemGraphReporter
                ItemGraphReporter(result).to_excel(xlsx_path, audit_report=audit_report,
                                                   cache=cache_obj)
                prog.set_step("✓ dependency_report.xlsx")

            if "csv" in formats:
                csv_path = str(run_dir / "dependency_report.csv")
                result.to_csv(csv_path)
                prog.set_step("✓ dependency_report.csv")

            if "gml" in formats:
                gml_path = str(run_dir / "query_subgraph.gml")
                result.save_subgraph(gml_path)
                prog.set_step("✓ query_subgraph.gml")

            html_path = str(run_dir / "dependency_graph.html")
            if "html" in formats:
                result.visualize(output_file=html_path, audit_report=audit_report,
                                 cache=cache_obj)
                prog.set_step("✓ dependency_graph.html")
            elif getattr(args, "serve", False):
                # Need HTML for --serve even when not in configured output_formats
                result.visualize(output_file=html_path, audit_report=audit_report,
                                 cache=cache_obj)
        finally:
            if cache_obj is not None:
                cache_obj.close()

    # ── Compute summary metrics for completion table ───────────────────────────
    node_count = len(result.nodes)
    broken_count = 0
    if not df.empty and "status" in df.columns:
        broken_count = int((df["status"] == "broken").sum())

    print_completion_table("Query complete", [
        ("Item queried",   args.item_id or f"search: {args.search}"),
        ("Nodes found",    str(node_count)),
        ("Broken deps",    str(broken_count) if broken_count else "0"),
        ("Output formats", ", ".join(formats)),
        ("Output path",    str(run_dir)),
        ("Next step",      "[dim]arcgis-graph query --item-id <id> --serve[/]"),
    ], prog.elapsed())

    if getattr(args, "serve", False):
        from cli.server import serve_dashboard
        serve_dashboard(
            html_bytes=Path(html_path).read_bytes(),
            gis=gis,
            config=config,
            port=args.port,
        )


def cmd_triage(args: argparse.Namespace, config: dict) -> None:
    """Query the graph for high-traffic items and classify their service dependencies."""
    import networkx as nx
    from arcgis_item_graph.triage import ItemTriageRunner
    from arcgis_item_graph.console import (
        CommandProgress, print_completion_table, print_error_panel, print_step,
        console as rich_console,
    )

    gis = resolve_gis(config, args)
    rich_console.print(f"[dim]▸[/] Connected as: {gis.users.me.username}")

    gml_file = args.gml_file or config["paths"]["gml_file"]
    base_output_dir = Path(args.output_dir or config["paths"]["output_dir"])

    # ── Run-log + staleness check ──────────────────────────────────────────────
    _warn_hours = config.get("cache", {}).get("update_warn_hours", 24)
    _triage_cache_hours = config.get("cache", {}).get("triage_cache_hours", 24)
    _run_log = _read_run_log(_run_log_path(config))
    graph_age_hours = 0.0
    if _run_log is None:
        rich_console.print("[yellow]⚠[/]  run_log.json not found — staleness check skipped")
        rich_console.print("   [dim](Run 'arcgis-graph create' to initialize the shared graph)[/]")
    else:
        if _run_log.get("last_update"):
            try:
                _last_dt = datetime.fromisoformat(_run_log["last_update"])
                graph_age_hours = (datetime.now() - _last_dt).total_seconds() / 3600
                if graph_age_hours > _warn_hours:
                    _age_str = f"{int(graph_age_hours)}h {int((graph_age_hours % 1) * 60)}m"
                    rich_console.print(
                        f"[yellow]⚠[/]  Graph is {_age_str} old (last update: "
                        f"{_last_dt.strftime('%H:%M')})"
                        " — run 'arcgis-graph update' to refresh"
                    )
            except (ValueError, TypeError):
                pass

        # ── Triage cache check ─────────────────────────────────────────────────
        _force_refresh = getattr(args, "force_refresh", False)
        if not _force_refresh and _triage_cache_hours > 0 and _run_log.get("last_triage"):
            try:
                _triage_dt = datetime.fromisoformat(_run_log["last_triage"])
                _triage_age = (datetime.now() - _triage_dt).total_seconds() / 3600
                if _triage_age < _triage_cache_hours:
                    _age_str = f"{int(_triage_age)}h {int((_triage_age % 1) * 60)}m"
                    _latest = sorted(
                        (base_output_dir / "reports" / "triage").glob("*/triage_report.xlsx")
                        if (base_output_dir / "reports" / "triage").exists() else []
                    )
                    _latest_dir = str(_latest[-1].parent) if _latest else str(
                        base_output_dir / "reports" / "triage"
                    )
                    rich_console.print(
                        f"[green]⚡[/] Triage ran {_age_str} ago "
                        f"(< {_triage_cache_hours}h threshold).\n"
                        f"   Outputs: {_latest_dir}\n"
                        "   Use --force-refresh to re-run."
                    )
                    return
            except (ValueError, TypeError):
                pass

    if not Path(gml_file).exists():
        print_error_panel(
            "Graph Not Found",
            f"No graph file at {gml_file}.",
            hint="Run arcgis-graph create first.",
        )
        sys.exit(1)

    print_step(f"Loading graph from {gml_file}…")
    graph = nx.read_gml(gml_file, label="label")

    # Apply CLI overrides to triage config
    triage_cfg = dict(config.get("triage", {}))
    top_n = args.top_n if args.top_n is not None else triage_cfg.get("top_n", 10)
    if args.top_n is not None:
        triage_cfg["top_n"] = args.top_n
    if getattr(args, "min_dependents", None) is not None:
        triage_cfg["min_dependents"] = args.min_dependents
    if args.deep:
        triage_cfg["deep_inspect"] = True
    if getattr(args, "no_usage_stats", False):
        triage_cfg["use_usage_stats"] = False
    merged_config = dict(config)
    merged_config["triage"] = triage_cfg

    with CommandProgress("Triage", total=top_n) as prog:
        runner = ItemTriageRunner(
            gis=gis,
            config=merged_config,
            on_progress=prog.on_item,
            on_warning=prog.on_warning,
        )
        result = runner.run(graph, graph_age_hours=graph_age_hours)

    hotspots = [s for s in result.services
                if len(s.referenced_by) >= triage_cfg.get("min_hotspot_refs", 2)]

    # Output folder
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = base_output_dir / "reports" / "triage" / ts
    run_dir.mkdir(parents=True, exist_ok=True)

    json_path = str(run_dir / "triage_manifest.json")
    runner.to_json(result, json_path)

    xlsx_path = str(run_dir / "triage_report.xlsx")
    runner.to_excel(result, xlsx_path)

    # Update run log
    if _run_log is not None:
        _run_log["last_triage"] = datetime.now().isoformat(timespec="seconds")
        _write_run_log(_run_log_path(config), _run_log)

    print_completion_table("Triage complete", [
        ("Items ranked",   str(len(result.ranked_items))),
        ("Services found", str(len(result.services))),
        ("Hotspots",       str(len(hotspots))),
        ("Report path",    str(run_dir)),
        ("Next step",      "[dim]arcgis-graph query --item-id <id>[/]"),
    ], prog.elapsed())


def cmd_remap(args: argparse.Namespace, cfg: dict) -> None:
    """Remap item data references across all dependents.

    Replaces every reference to --from-id with --to-id in all dependent items,
    or when --from-health-report is set, iterates all broken nodes from the
    metadata cache and remaps each one (requires --to-id per item_id to be
    provided, or is best used for a single targeted fix).
    """
    from arcgis_item_graph.remapper import ItemGraphRemapper
    from arcgis_item_graph.console import (
        print_completion_table, print_error_panel, print_step, console as rich_console,
    )

    gml_file = args.gml_file or cfg["paths"]["gml_file"]

    # ── Collect item IDs to remap from ────────────────────────────────────────
    if getattr(args, "from_health_report", False):
        db = _cache_path(cfg)
        if not Path(db).exists():
            print_error_panel(
                "No metadata cache found",
                f"Run 'arcgis-graph create' first to build the cache at:\n{db}",
            )
            return
        cache = MetadataCache(db)
        try:
            from_ids = cache.broken_nodes()
        finally:
            cache.close()
        if not from_ids:
            print_step("No broken nodes found in cache — nothing to remap.")
            return
        rich_console.print(
            f"[yellow]⚠[/]  {len(from_ids)} broken node(s) loaded from health cache"
        )
    else:
        if not args.from_id:
            print_error_panel(
                "Missing argument",
                "Provide --from-id <item_id> or use --from-health-report.",
                hint="Example: arcgis-graph remap --from-id <old_id> --to-id <new_id>",
            )
            return
        from_ids = [args.from_id]

    if not args.to_id:
        print_error_panel(
            "Missing argument",
            "Provide --to-id <item_id> (the replacement item).",
            hint="Example: arcgis-graph remap --from-id <old_id> --to-id <new_id>",
        )
        return

    gis = resolve_gis(cfg, args)
    rich_console.print(f"[dim]▸[/] Connected as: {gis.users.me.username}")

    remapper = ItemGraphRemapper(gis=gis, gml_file=gml_file)
    base_output_dir = Path(args.output_dir or cfg["paths"]["output_dir"])

    total_succeeded = 0
    total_failed = 0

    for from_id in from_ids:
        rich_console.print(f"\n[bold]Remap:[/] {from_id} → {args.to_id}")
        try:
            preview = remapper.preview(from_id=from_id, to_id=args.to_id)
        except ValueError as exc:
            rich_console.print(f"  [red]✗[/] Preview failed: {exc}")
            total_failed += 1
            continue

        rich_console.print(
            f"  {len(preview.dependents)} dependent(s) will be updated"
        )

        if not preview.dependents:
            rich_console.print("  [dim]No dependents — skipping.[/]")
            continue

        if getattr(args, "dry_run", False):
            rich_console.print("  [dim]--dry-run: skipping execute()[/]")
            for dep in preview.dependents:
                rich_console.print(f"    would update: {dep.item_id} ({dep.title})")
            continue

        outcomes = remapper.execute(preview, force=getattr(args, "force", False))
        succeeded = sum(1 for o in outcomes if o.success)
        failed = sum(1 for o in outcomes if not o.success)
        total_succeeded += succeeded
        total_failed += failed

        for o in outcomes:
            if o.success:
                rich_console.print(f"  [green]✓[/] {o.item_id} ({o.title})")
            else:
                rich_console.print(f"  [red]✗[/] {o.item_id} ({o.title}): {o.error}")

        # Write rollback manifest for this from_id
        manifest_path = remapper.write_manifest(
            preview, outcomes, output_dir=str(base_output_dir / "remap"),
            force=getattr(args, "force", False),
        )
        if manifest_path:
            rich_console.print(f"  [dim]Rollback manifest: {manifest_path}[/]")

    print_completion_table("Remap complete", [
        ("From IDs processed", str(len(from_ids))),
        ("Dependents updated",  str(total_succeeded)),
        ("Failures",            str(total_failed) if total_failed else "0"),
    ], 0.0)


def cmd_health(args: argparse.Namespace, cfg: dict) -> None:
    """Print an org-wide broken reference and orphan summary from the metadata cache."""
    import time
    import pandas as pd
    from arcgis_item_graph.console import console, print_error_panel, print_completion_table

    db = _cache_path(cfg)
    if not Path(db).exists():
        print_error_panel(
            "No metadata cache found",
            f"Run 'arcgis-graph create' first to build the cache at:\n{db}",
        )
        return

    cache = MetadataCache(db)
    try:
        broken = cache.broken_nodes()
        orphans = cache.orphan_candidates()
        # Fetch URL service health data while cache is still open
        inaccessible = cache.url_nodes_by_status("inaccessible")
        dead = cache.url_nodes_by_status("dead")
        live_no_item = cache.url_nodes_by_status("live_no_item")
        # Score and sort broken nodes by risk (descending) while cache is still open
        from arcgis_item_graph.risk import score_item
        risk_sorted = sorted(
            broken,
            key=lambda nid: score_item(nid, cache, []).score,
            reverse=True,
        )
        risk_map = {nid: score_item(nid, cache, []) for nid in risk_sorted[:10]}
    finally:
        cache.close()

    console.print(f"\n[bold]Health Summary[/bold]")
    console.print(f"  Broken nodes      : [red]{len(broken)}[/red]")
    console.print(f"  Orphan candidates : [yellow]{len(orphans)}[/yellow]")

    if broken:
        console.print("\n[bold red]Broken Nodes (first 10, sorted by risk):[/bold red]")
        for node_id in risk_sorted[:10]:
            rs = risk_map[node_id]
            console.print(f"  {node_id}  [dim]({rs.tier}, {rs.score})[/dim]")

    # URL service health sections
    if not inaccessible and not dead and not live_no_item:
        console.print(
            "\n[dim]No service URL probes on record. "
            "Run [bold]arcgis-graph query --service-check[/bold] to probe service URLs.[/dim]"
        )
    else:
        if inaccessible or dead:
            console.print(
                f"\n[bold]── Inaccessible Services "
                f"({len(inaccessible) + len(dead)}) ──────────────────────[/bold]"
            )
            for url in sorted(inaccessible):
                console.print(f"  [red]{url}[/red]  [dim](inaccessible)[/dim]")
            for url in sorted(dead):
                console.print(f"  [red]{url}[/red]  [dim](dead - connection failure)[/dim]")

        if live_no_item:
            console.print(
                f"\n[bold]── Live Services / No Portal Item "
                f"({len(live_no_item)}) ──────────────────[/bold]"
            )
            for url in sorted(live_no_item):
                console.print(f"  [yellow]{url}[/yellow]  [dim](service up, not registered in portal)[/dim]")

    out_dir = Path(cfg["paths"]["output_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = out_dir / f"health_report_{ts}.xlsx"

    broken_rows = [{"id": b, "status": "broken_no_item"} for b in broken]

    with pd.ExcelWriter(str(report_path), engine="openpyxl") as writer:
        pd.DataFrame(broken_rows).to_excel(writer, sheet_name="Broken References", index=False)
        pd.DataFrame(orphans).to_excel(writer, sheet_name="Orphan Candidates", index=False)

    print_completion_table("health", [
        ("Broken nodes",      str(len(broken))),
        ("Orphan candidates", str(len(orphans))),
        ("report",            str(report_path)),
    ], 0.0)


# ── Argument Parser ───────────────────────────────────────────────────────────

def _add_shared_args(parser: argparse.ArgumentParser) -> None:
    """Add auth + path override flags shared by all subcommands."""
    parser.add_argument("--profile", help="ArcGIS named profile (overrides config)")
    parser.add_argument("--url", help="ArcGIS portal URL")
    parser.add_argument("--user", help="ArcGIS username")
    parser.add_argument("--password", help="ArcGIS password (avoid: visible in shell history; prefer .env or --profile)")
    parser.add_argument("--gml-file", dest="gml_file", help="Override graph GML file path")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="arcgis-graph",
        description="ArcGIS Item Dependency Graph CLI",
    )
    parser.add_argument(
        "--config",
        default=str(DEFAULT_CONFIG),
        help=f"Path to config YAML (default: {DEFAULT_CONFIG})",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # ── create ────────────────────────────────────────────────────────────────
    create_p = subparsers.add_parser("create", help="Build the dependency graph (run once)")
    _add_shared_args(create_p)
    create_p.add_argument("--max-items", dest="max_items", type=int,
                          help="Override create.max_items from config")
    create_p.add_argument("--timestamp-file", dest="timestamp_file",
                          help="Override paths.timestamp_file from config")
    create_p.add_argument(
        "--local-first",
        dest="local_first",
        action="store_true",
        default=False,
        help=(
            "Write the graph to ~/Documents/arcgis-graph/ first, then copy to the "
            "configured share. If the share copy fails the local files are preserved "
            "so the crawl does not need to be re-run."
        ),
    )

    # ── update ────────────────────────────────────────────────────────────────
    update_p = subparsers.add_parser("update", help="Incrementally update the graph")
    _add_shared_args(update_p)
    update_p.add_argument("--max-retries", dest="max_retries", type=int,
                          help="Override update.max_retries from config")
    update_p.add_argument("--retry-delay", dest="retry_delay", type=float,
                          help="Override update.retry_delay from config")
    update_p.add_argument("--timestamp-file", dest="timestamp_file",
                          help="Override paths.timestamp_file from config")
    update_p.add_argument(
        "--skip-if-fresh",
        dest="skip_if_fresh",
        action="store_true",
        default=False,
        help="No-op if graph was updated within update_warn_hours (safe for scheduled automation)",
    )

    # ── query ─────────────────────────────────────────────────────────────────
    query_p = subparsers.add_parser("query", help="Query the graph by item ID or search string")
    _add_shared_args(query_p)
    # required=True intentionally omitted: cmd_query enforces "at least one"
    # with a friendlier message (exit 1) than argparse would give (exit 2).
    qex = query_p.add_mutually_exclusive_group()
    qex.add_argument("--item-id", dest="item_id",
                     help="ArcGIS item ID to query")
    qex.add_argument("--search",
                     help="Portal search string (e.g. 'owner:jsmith type:Dashboard')")
    query_p.add_argument("--format", action="append", choices=["csv", "excel", "html", "gml"],
                         help="Output format (repeatable); overrides config output_formats")
    query_p.add_argument("--output-dir", dest="output_dir",
                         help="Override paths.output_dir from config")
    query_p.add_argument("--serve", action="store_true", default=False,
                         help="Start a local HTTP server and open the dashboard in the browser")
    query_p.add_argument("--port", type=int, default=8765,
                         help="Port for --serve mode (default: 8765)")
    query_p.add_argument(
        "--force-refresh",
        dest="force_refresh",
        action="store_true",
        default=False,
        help="Skip cached outputs and re-run the query even if a fresh cache exists",
    )
    query_p.add_argument(
        "--audit",
        action="store_true",
        default=False,
        help=(
            "Compare ItemGraph upstream edges against live Item.dependencies.dependent_to() "
            "and write discrepancies to an 'Audit Diff' Excel sheet. "
            "Enterprise only — not supported on ArcGIS Online."
        ),
    )

    query_p.add_argument(
        "--service-check",
        dest="service_check",
        action="store_true",
        default=False,
        help=(
            "Probe URL-type dependencies for HTTP liveness. "
            "Results (live_no_item / inaccessible / dead) are cached in meta.sqlite "
            "and surfaced in the Excel Dependency Edges sheet and health report."
        ),
    )

    # ── triage ────────────────────────────────────────────────────────────────
    triage_p = subparsers.add_parser(
        "triage",
        help="Identify high-traffic items and their service dependencies for migration planning",
    )
    _add_shared_args(triage_p)
    triage_p.add_argument(
        "--top-n", dest="top_n", type=int, default=None,
        help="Override triage.top_n from config",
    )
    triage_p.add_argument(
        "--min-dependents", dest="min_dependents", type=int, default=None,
        help="Exclude items with fewer than N service dependencies",
    )
    triage_p.add_argument(
        "--deep", action="store_true", default=False,
        help="Enable Tier 3 layer introspection for ambiguous services (slower)",
    )
    triage_p.add_argument(
        "--no-usage-stats", dest="no_usage_stats", action="store_true", default=False,
        help="Skip portal usage stats API (use dependency count only for ranking)",
    )
    triage_p.add_argument(
        "--output-dir", dest="output_dir",
        help="Override paths.output_dir from config",
    )
    triage_p.add_argument(
        "--force-refresh", dest="force_refresh", action="store_true", default=False,
        help="Re-run triage even if a fresh cached result exists",
    )

    # ── remap ─────────────────────────────────────────────────────────────────
    remap_p = subparsers.add_parser(
        "remap",
        help="Remap item data references from one item to another across all dependents",
    )
    _add_shared_args(remap_p)
    remap_p.add_argument(
        "--from-id",
        dest="from_id",
        help="Item ID of the item to replace (source)",
    )
    remap_p.add_argument(
        "--to-id",
        dest="to_id",
        required=True,
        help="Item ID of the replacement item (target)",
    )
    remap_p.add_argument(
        "--from-health-report",
        dest="from_health_report",
        action="store_true",
        default=False,
        help=(
            "Load broken item IDs from meta.sqlite health table instead of "
            "specifying --from-id. Remaps all broken nodes to --to-id."
        ),
    )
    remap_p.add_argument(
        "--dry-run",
        dest="dry_run",
        action="store_true",
        default=False,
        help="Show what would be remapped without making any changes",
    )
    remap_p.add_argument(
        "--force",
        action="store_true",
        default=False,
        help="Pass force=True to remap_data() — bypasses item type validation",
    )
    remap_p.add_argument(
        "--output-dir",
        dest="output_dir",
        help="Override paths.output_dir from config (for rollback manifests)",
    )

    # ── setup ─────────────────────────────────────────────────────────────────
    subparsers.add_parser("setup", help="Interactively create config/config.yaml")

    # ── health ────────────────────────────────────────────────────────────────
    health_parser = subparsers.add_parser(
        "health",
        help="Org-wide broken reference and orphan summary",
    )
    health_parser.set_defaults(subcommand="health")

    return parser


# ── Entry Point ───────────────────────────────────────────────────────────────

def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[logging.StreamHandler(sys.stderr)],
    )
    parser = build_parser()
    args = parser.parse_args()

    # Load .env from the project root (directory containing config/).
    # Resolved to an absolute path so this works when the user runs
    # arcgis-graph from a directory other than the project root, and so
    # that .env values override any pre-existing system environment variables
    # (e.g. a stale ARCGIS_PASSWORD set for a different account on Windows).
    load_dotenv(dotenv_path=Path(args.config).resolve().parent.parent / ".env", override=True)

    if args.command == "setup":
        cmd_setup(args)
        return

    config = load_config(Path(args.config))
    validate_config(config, Path(args.config))

    dispatch = {
        "create": cmd_create,
        "update": cmd_update,
        "query": cmd_query,
        "triage": cmd_triage,
        "health": cmd_health,
        "remap": cmd_remap,
    }
    dispatch[args.command](args, config)


if __name__ == "__main__":
    main()
