"""arcgis_item_graph/risk.py — Governance risk scoring (pure function, no REST calls)."""
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from arcgis_item_graph.cache import MetadataCache


@dataclass
class RiskScore:
    item_id: str
    score: int
    tier: str                          # 'green' | 'yellow' | 'red'
    signals: list = field(default_factory=list)


def score_item(
    item_id: str,
    cache: "MetadataCache",
    required_by_ids: list,
) -> "RiskScore":
    """Compute governance risk score. Reads only from MetadataCache — no REST calls."""
    signals: list = []
    score = 0

    fanout = len(required_by_ids)
    if fanout > 50:
        score += 40
        signals.append(f"very high fanout: {fanout} dependents")
    elif fanout > 10:
        score += 20
        signals.append(f"high fanout: {fanout} dependents")

    for dep_id in required_by_ids:
        dep = cache.get_item(dep_id)
        if dep and dep.get("access") == "public":
            score += 20
            signals.append("depended on by public-facing item")
            break

    item = cache.get_item(item_id)
    if item:
        if item.get("content_status") == "deprecated":
            score += 10
            signals.append("content_status: deprecated")
        if not item.get("delete_protected") and score > 40:
            score += 5
            signals.append("not delete-protected with elevated score")

    score = min(score, 100)

    if score <= 30:
        tier = "green"
    elif score <= 60:
        tier = "yellow"
    else:
        tier = "red"

    return RiskScore(item_id=item_id, score=score, tier=tier, signals=signals)
