"""
Shared utilities for arcgis_item_graph modules.
"""
import time
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, Optional, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")

# ---------------------------------------------------------------------------
# Hydration error categorization
# ---------------------------------------------------------------------------

_NETWORK_KEYWORDS = ("socket", "timeout", "connection", "keyboardinterrupt")
_PERMISSION_KEYWORDS = ("permission", "unauthorized", "403")


def categorize_hydration_error(error_str: str, item_id: str) -> str:
    """
    Classify a hydration failure into one of six categories so callers
    can decide whether to retry, skip, or remove the node.

    Categories:
        'malformed_url'  — item ID is a REST service URL, not a portal ID
        'deleted'        — item no longer exists in the portal (ArcGIS iteminfo error)
        'not_found'      — HTTP 404: item genuinely missing from the portal
        'degraded'       — HTTP 500 server error (e.g. overloaded ArcSOC); may be transient
        'network'        — transient connectivity failure; worth retrying
        'permission'     — caller lacks access; retrying will not help
        'unknown'        — unrecognised error; treat conservatively (keep node)

    Args:
        error_str: str(exception) from the failed gis.content.get() call.
        item_id:   The portal item ID that was being fetched.

    Returns:
        One of the six category strings listed above.
    """
    # URL-shaped IDs are REST service references, not portal item IDs.
    if item_id.startswith("http://") or item_id.startswith("https://"):
        if "/rest/services/" in item_id:
            return "malformed_url"

    error_lower = error_str.lower()

    if "no connection adapters" in error_lower:
        return "malformed_url"

    # ArcGIS-specific item-not-found message — check BEFORE the generic 500 check
    # so "unable to find iteminfo. error code: 500" is correctly classified as deleted.
    if "unable to find iteminfo" in error_lower:
        return "deleted"

    # HTTP 404 — item exists in the URL space but was not found.
    if "error code: 404" in error_lower or "404 not found" in error_lower:
        return "not_found"

    # Generic HTTP 500 (e.g. ArcGIS Server overloaded, no ArcSOC available).
    # These are server-side failures, not evidence the item is gone.
    if "error code: 500" in error_lower:
        return "degraded"

    if any(kw in error_lower for kw in _NETWORK_KEYWORDS):
        return "network"

    if any(kw in error_lower for kw in _PERMISSION_KEYWORDS):
        return "permission"

    return "unknown"


# ---------------------------------------------------------------------------
# Retry helper
# ---------------------------------------------------------------------------

def retry_with_backoff(
    fn: Callable[[], T],
    *,
    max_attempts: int = 3,
    initial_delay: float = 1.0,
    backoff_factor: float = 2.0,
    label: str = "",
    should_retry: Optional[Callable[[Exception], bool]] = None,
) -> T:
    """
    Call *fn* up to *max_attempts* times, sleeping between failures.

    Uses exponential backoff: delay doubles after each failed attempt.
    Non-retryable exceptions (as determined by *should_retry*) are re-raised
    immediately without consuming retry budget.

    Args:
        fn:             Zero-argument callable to attempt.
        max_attempts:   Maximum number of tries (default 3).
        initial_delay:  Seconds to wait after the first failure (default 1).
        backoff_factor: Multiplier applied to delay after each failure (default 2).
        label:          Human-readable label for log messages.
        should_retry:   Optional predicate ``(exc) -> bool``. When provided,
                        exceptions for which it returns False are re-raised
                        immediately without retrying. If None, all exceptions
                        are retried up to *max_attempts*.

    Returns:
        The return value of *fn* on success.

    Raises:
        The last exception raised by *fn* if all attempts fail, or immediately
        if *should_retry* returns False for that exception.
    """
    delay = initial_delay
    last_exc: Exception = RuntimeError("retry_with_backoff: no attempts made")

    for attempt in range(1, max_attempts + 1):
        try:
            return fn()
        except Exception as exc:
            if should_retry is not None and not should_retry(exc):
                raise
            last_exc = exc
            if attempt < max_attempts:
                logger.warning(
                    f"Attempt {attempt}/{max_attempts} failed"
                    f"{f' ({label})' if label else ''}: {exc}. "
                    f"Retrying in {delay:.1f}s..."
                )
                time.sleep(delay)
                delay *= backoff_factor
            else:
                logger.error(
                    f"All {max_attempts} attempts failed"
                    f"{f' ({label})' if label else ''}: {exc}"
                )

    raise last_exc


# ---------------------------------------------------------------------------
# Node ID classification
# ---------------------------------------------------------------------------

def classify_node_id(node_id: str) -> str:
    """Classify a graph node ID as a portal item ID or an external URL reference.

    ArcGIS items can declare dependencies on REST service URLs rather than portal
    item IDs. These URL strings become node IDs in the dependency graph.

    Returns:
        'portal_id'        — 32-char hex string; standard ArcGIS portal item
        'arcgis_rest_url'  — URL containing /rest/services/
        'external_url'     — any other http(s):// URL (WMS, tile server, etc.)
    """
    if node_id.startswith("http://") or node_id.startswith("https://"):
        if "/rest/services/" in node_id:
            return "arcgis_rest_url"
        return "external_url"
    return "portal_id"


# ---------------------------------------------------------------------------
# Batched item fetch
# ---------------------------------------------------------------------------

def batch_fetch_items(
    gis,
    ids: list,
    *,
    workers: int = 10,
) -> dict:
    """Fetch portal metadata for a list of item IDs using parallel content.get() calls.

    Uses parallel direct fetches rather than batched Lucene search queries.
    The ``id:xxx OR id:yyy`` Lucene syntax is unreliable on ArcGIS Portal —
    the hex ID strings are tokenised incorrectly, causing wrong items to be
    returned.  Direct ``content.get()`` is authoritative and always correct.

    URL-shaped IDs (http/https) are excluded automatically — they are not portal
    items and cannot be fetched this way.

    Args:
        gis:     Authenticated ArcGIS GIS connection.
        ids:     List of portal item ID strings (mix of real IDs and URLs is fine).
        workers: Number of concurrent fetch requests (default 10).

    Returns:
        Dict mapping ``item_id`` (str) → ``Item`` for successfully fetched items.
        IDs absent from the portal are not included in the returned dict.
    """
    portal_ids = [
        i for i in ids
        if not (i.startswith("http://") or i.startswith("https://"))
    ]
    if not portal_ids:
        return {}

    def _fetch_one(item_id: str):
        try:
            item = gis.content.get(item_id)
            return (item_id, item)
        except Exception as exc:
            logger.warning("Fetch failed for %s: %s", item_id[:8], exc)
            return (item_id, None)

    result: dict = {}
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(_fetch_one, item_id): item_id for item_id in portal_ids}
        for future in as_completed(futures):
            item_id, item = future.result()
            if item is not None:
                result[item_id] = item

    return result


# ---------------------------------------------------------------------------
# URL layer-index stripping and service name extraction
# ---------------------------------------------------------------------------

def strip_layer_index(url: str) -> str:
    """Strip a trailing numeric layer/table index from an ArcGIS REST URL.

    ArcGIS layers inside a web map are often stored with a layer index
    (e.g. /FeatureServer/0).  The portal item for that service is indexed
    at the base URL (/FeatureServer), so search queries must use the base URL.

    Examples:
        https://portal/rest/services/Hosted/Roads/FeatureServer/0
            → https://portal/rest/services/Hosted/Roads/FeatureServer
        https://portal/rest/services/Hosted/Roads/FeatureServer
            → unchanged
    """
    url = url.rstrip("/")
    parts = url.rsplit("/", 1)
    if len(parts) == 2 and parts[1].isdigit():
        return parts[0]
    return url


def extract_service_name(url: str) -> str:
    """Extract a readable service name from an ArcGIS REST service URL.

    Used as a human-readable dep_title for URL nodes that could not be
    resolved to portal items.

    Examples:
        https://portal/rest/services/Hosted/MyRoads/FeatureServer/0
            → 'MyRoads/FeatureServer'
        https://portal/rest/services/MyService/MapServer
            → 'MyService/MapServer'
        https://other-server/no-rest-path
            → 'https://other-server/no-rest-path'  (unchanged)
    """
    base = strip_layer_index(url)
    if "/rest/services/" in base:
        after = base.split("/rest/services/", 1)[1]
        segments = [s for s in after.split("/") if s]
        return "/".join(segments[-2:]) if len(segments) >= 2 else (segments[0] if segments else base)
    return base


# ---------------------------------------------------------------------------
# Service URL liveness probing
# ---------------------------------------------------------------------------

def probe_service_url(url: str, verify_cert: bool = True, timeout: int = 10) -> str:
    """Probe a service URL for HTTP liveness.

    Makes an HTTP GET request to the service URL with ?f=json appended.
    Used only during `arcgis-graph query --service-check` to classify
    unreachable service URLs (inaccessible vs dead).

    Args:
        url:         Service URL to probe (e.g. https://services.com/rest/services/X/FeatureServer)
        verify_cert: Whether to verify SSL certificates (default True)
        timeout:     Request timeout in seconds (default 10)

    Returns:
        One of three strings:
        - 'live_no_item'    — HTTP 200 response; service is reachable
        - 'inaccessible'    — HTTP non-200 status or SSL certificate error; service exists but not accessible
        - 'dead'            — DNS, connection, or timeout failure; service unreachable

    Never raises. All exceptions map to 'dead'.
    """
    import requests

    probe = url.split("?")[0].rstrip("/") + "?f=json"
    try:
        resp = requests.get(probe, verify=verify_cert, timeout=timeout)
        if resp.status_code == 200:
            return "live_no_item"
        return "inaccessible"
    except requests.exceptions.SSLError:
        return "inaccessible"
    except Exception:
        return "dead"
