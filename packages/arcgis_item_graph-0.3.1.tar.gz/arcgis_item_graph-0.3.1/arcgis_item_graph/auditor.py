"""
ItemDependencyAuditor — compares Item.dependencies.dependent_to() against
the ItemGraph's contained_by() edges for accuracy auditing.

Enterprise only: dependent_to() is not supported on ArcGIS Online.
"""
from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class NodeDiff:
    """Audit result for a single node."""

    node_id: str
    node_title: str
    graph_only: set = field(default_factory=set)
    """IDs in ItemGraph contained_by() but absent from dependent_to() — phantom edges."""
    api_only: set = field(default_factory=set)
    """IDs in dependent_to() but absent from ItemGraph — missing edges (migration risk)."""
    in_both: set = field(default_factory=set)
    """IDs confirmed accurate in both sources."""
    audit_skipped: Optional[str] = None
    """Reason node was skipped: 'broken_node', 'unsupported', 'error', or None."""


@dataclass
class AuditReport:
    """Aggregated audit results across all nodes."""

    diffs: list = field(default_factory=list)

    @property
    def nodes_with_discrepancies(self) -> list:
        return [d for d in self.diffs if d.api_only or d.graph_only]

    @property
    def skipped_count(self) -> int:
        return sum(1 for d in self.diffs if d.audit_skipped)

    @property
    def total_missing_from_graph(self) -> int:
        """Sum of api_only counts — edges the graph is missing (migration risk)."""
        return sum(len(d.api_only) for d in self.diffs)

    @property
    def total_extra_in_graph(self) -> int:
        """Sum of graph_only counts — phantom edges in the graph."""
        return sum(len(d.graph_only) for d in self.diffs)


class ItemDependencyAuditor:
    """
    Audits dependency accuracy by comparing ItemGraph contained_by() edges
    against live Item.dependencies.dependent_to() calls.

    Enterprise only: dependent_to() is not available on ArcGIS Online.

    Args:
        gis:     Authenticated ArcGIS GIS connection.
        workers: Max concurrent dependent_to() requests (default 10).
    """

    def __init__(self, gis, workers: int = 10) -> None:
        self.gis = gis
        self.workers = workers

    def _audit_node(self, node) -> NodeDiff:
        """Audit a single node — compare graph edges against live API."""
        title = ""
        if node.item is not None:
            title = getattr(node.item, "title", "")
        else:
            return NodeDiff(node_id=node.id, node_title="", audit_skipped="broken_node")

        # ── ItemGraph upstream edges ──────────────────────────────────────────
        try:
            graph_neighbors: set = set(node.contained_by("id"))
        except Exception:
            graph_neighbors = set()

        # ── Live API: Item.dependencies ───────────────────────────────────────
        # ArcGIS Python API v2.4.x exposes upstream dependents as a property:
        #   item.dependencies.to_dependencies → list of {dependencyType, id/url}
        # Newer API versions may use a method instead:
        #   item.dependencies.dependent_to() → {"total": N, "list": [...]}
        # We try the v2.4.x property first and fall back to the newer method.
        try:
            portal_item = self.gis.content.get(node.id)
            if portal_item is None:
                return NodeDiff(node_id=node.id, node_title=title,
                                audit_skipped="broken_node")
            try:
                raw = portal_item.dependencies.to_dependencies      # v2.4.x property → list
            except AttributeError:
                raw = portal_item.dependencies.dependent_to().get("list", [])  # newer API
            api_neighbors: set = {
                dep["id"]
                for dep in raw
                if dep.get("dependencyType") == "id" and "id" in dep
            }
        except AttributeError:
            logger.debug("dependencies API unsupported for %s", node.id[:8])
            return NodeDiff(node_id=node.id, node_title=title,
                            audit_skipped="unsupported")
        except Exception as exc:
            logger.debug("dependencies API error for %s: %s", node.id[:8], exc)
            return NodeDiff(node_id=node.id, node_title=title,
                            audit_skipped="error")

        return NodeDiff(
            node_id=node.id,
            node_title=title,
            graph_only=graph_neighbors - api_neighbors,
            api_only=api_neighbors - graph_neighbors,
            in_both=graph_neighbors & api_neighbors,
        )

    def audit(self, result) -> AuditReport:
        """
        Audit all portal-ID result nodes by comparing ItemGraph contained_by()
        against live Item.dependencies.dependent_to().

        Args:
            result: QueryResult from ItemGraphQuery.query().

        Returns:
            AuditReport with per-node diffs and summary counts.
        """
        auditable = [
            n for n in result.nodes
            if n is not None
            and not (n.id.startswith("http://") or n.id.startswith("https://"))
        ]

        logger.info(
            "Auditing %d node(s) via Item.dependencies.dependent_to()...",
            len(auditable),
        )

        diffs: list = []
        with ThreadPoolExecutor(max_workers=self.workers) as executor:
            futures = {executor.submit(self._audit_node, node): node
                       for node in auditable}
            for future in as_completed(futures):
                diffs.append(future.result())

        report = AuditReport(diffs=diffs)
        logger.info(
            "Audit complete: %d audited, %d skipped, "
            "%d missing from graph, %d extra in graph",
            len(diffs),
            report.skipped_count,
            report.total_missing_from_graph,
            report.total_extra_in_graph,
        )
        return report
