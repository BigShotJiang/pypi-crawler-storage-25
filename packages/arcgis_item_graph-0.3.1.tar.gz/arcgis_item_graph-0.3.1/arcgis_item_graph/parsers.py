"""arcgis_item_graph/parsers.py — Custom JSON parser layer for graph augmentation.

Discovers edges that create_dependency_graph() misses:
  - parse_view_admin:  hosted feature layer view → parent service (admin endpoint)
  - parse_dashboard:   Dashboard widget datasets
  - parse_exb:         Experience Builder data sources + widget configs
"""
import logging
import re

logger = logging.getLogger(__name__)

_HEX32 = re.compile(r"^[a-f0-9]{32}$")


def _is_portal_id(s: str) -> bool:
    """Return True if *s* looks like an ArcGIS portal item ID (strict 32-char lowercase hex)."""
    return bool(s and _HEX32.match(str(s)))


def parse_view_admin(item: object, graph: object, gis: object) -> list[tuple[str, str, str]]:
    """Resolve View Service → parent service(s) via admin endpoint."""
    if "View Service" not in (item.typeKeywords or []):
        return []
    edges = []
    try:
        svc_url = item.url or ""
        if not svc_url:
            return []
        admin_url = svc_url.replace("/rest/services/", "/rest/admin/services/")
        if not admin_url.rstrip("/").endswith("/FeatureServer"):
            admin_url = admin_url.rstrip("/") + "/FeatureServer"
        resp = gis._con.get(admin_url, {"f": "json"})
        vld = resp.get("adminLayerInfo", {}).get("viewLayerDefinition", {})

        source_names: set = set()
        sn = vld.get("sourceServiceName") or vld.get("table", {}).get("sourceServiceName")
        if sn:
            source_names.add(sn)
        for rt in vld.get("table", {}).get("relatedTables", []):
            rsn = rt.get("sourceServiceName")
            if rsn:
                source_names.add(rsn)

        for name in source_names:
            results = gis.content.search(
                f'name:"{name}" AND type:"Feature Service"', max_items=5
            )
            if not results:
                logger.warning("view_admin: no item found for service '%s'", name)
                continue
            if len(results) > 1:
                logger.warning(
                    "view_admin: ambiguous match for '%s' (%d results), using first",
                    name, len(results),
                )
            edges.append((item.itemid, results[0].itemid, "view_admin"))
    except Exception as e:
        logger.warning("view_admin parser failed for %s: %s", item.itemid, e)
    return edges


def parse_dashboard(item: object, graph: object, gis: object) -> list[tuple[str, str, str]]:
    """Extract item IDs from Dashboard widget datasets."""
    if item.type != "Dashboard":
        return []
    edges = []
    existing = {n.id for n in graph.all_items()}
    try:
        data = item.get_data() or {}

        def _walk(obj):
            if isinstance(obj, dict):
                for key in ("itemId", "mapItemId"):
                    val = obj.get(key)
                    if (
                        val
                        and isinstance(val, str)
                        and _HEX32.match(val)
                        and val != item.itemid
                        and val not in existing
                    ):
                        edges.append((item.itemid, val, "dashboard_widget"))
                for v in obj.values():
                    _walk(v)
            elif isinstance(obj, list):
                for v in obj:
                    _walk(v)

        _walk(data)
    except Exception as e:
        logger.warning("dashboard parser failed for %s: %s", item.itemid, e)
    return edges


def parse_exb(item: object, graph: object, gis: object) -> list[tuple[str, str, str]]:
    """Extract item IDs from Experience Builder data sources and widget configs."""
    if item.type != "Web Experience":
        return []
    edges = []
    existing = {n.id for n in graph.all_items()}

    def _add(child_id):
        if (
            child_id
            and isinstance(child_id, str)
            and _HEX32.match(child_id)
            and child_id != item.itemid
            and child_id not in existing
        ):
            edges.append((item.itemid, child_id, "exb_widget"))

    try:
        data = item.get_data() or {}
        for ds in (data.get("dataSources") or {}).values():
            _add(ds.get("itemId"))
        for w in (data.get("widgets") or {}).values():
            for uds in w.get("useDataSources", []):
                _add(uds.get("dataSourceId"))
    except Exception as e:
        logger.warning("exb parser (item data) failed for %s: %s", item.itemid, e)

    try:
        resources = item.resources.list()
        if any(r.get("resource") == "config/config.json" for r in resources):
            cfg = item.resources.get("config/config.json")
            if isinstance(cfg, dict):
                for ds in (cfg.get("dataSources") or {}).values():
                    _add(ds.get("itemId"))
    except Exception as e:
        logger.warning("exb parser (resource) failed for %s: %s", item.itemid, e)

    return edges


def parse_webmap(item: object, graph: object, gis: object) -> list[tuple[str, str, str]]:
    """Walk web map JSON and emit (parent_id, dep_id_or_url, source) edges.

    Supplements create_dependency_graph() for nested group layers, basemap
    layers, tables, and URL-only layers that ItemGraph misses.
    """
    if item.type != "Web Map":
        return []
    try:
        data = item.get_data() or {}
    except Exception as e:
        logger.warning("parse_webmap: get_data failed for %s: %s", item.itemid, e)
        return []

    edges = []
    parent = item.itemid

    def _walk(layers):
        for layer in layers or []:
            ref = layer.get("itemId")
            url = layer.get("url")
            if ref and _is_portal_id(ref):
                edges.append((parent, ref, "webmap_layer"))
            if url and str(url).startswith("http"):
                edges.append((parent, url, "webmap_url"))
            _walk(layer.get("layers", []))

    _walk(data.get("operationalLayers", []))
    _walk(data.get("baseMap", {}).get("baseMapLayers", []))
    _walk(data.get("tables", []))

    routing_id = (data.get("applicationProperties", {})
                      .get("viewing", {})
                      .get("routing", {})
                      .get("itemId"))
    if routing_id and _is_portal_id(routing_id):
        edges.append((parent, routing_id, "webmap_routing"))

    return edges


def augment_graph(graph: object, items: list, gis: object, cache: object = None) -> None:
    """Run all parsers and merge discovered edges into graph and optionally cache."""
    parsers = [parse_view_admin, parse_dashboard, parse_exb, parse_webmap]
    all_edges = []

    for item in (items or []):
        if item is None:
            continue
        for parser in parsers:
            try:
                all_edges.extend(parser(item, graph, gis))
            except Exception as e:
                logger.warning(
                    "Parser %s failed for %s: %s",
                    parser.__name__, getattr(item, "itemid", "?"), e,
                )

    for parent_id, child_id, source in all_edges:
        try:
            parent_node = graph.get_node(parent_id) or graph.add_item(parent_id)
            child_node = graph.get_node(child_id) or graph.add_item(child_id)
            graph.add_relationship(parent_node, child_node)
        except Exception as e:
            logger.warning("Could not add edge %s→%s: %s", parent_id, child_id, e)

    if cache is not None:
        for parent_id, child_id, source in all_edges:
            try:
                cache.upsert_relationship(parent_id, child_id, source)
            except Exception as e:
                logger.warning("Could not write edge to cache: %s", e)

    logger.info("augment_graph: added %d edges from custom parsers", len(all_edges))
