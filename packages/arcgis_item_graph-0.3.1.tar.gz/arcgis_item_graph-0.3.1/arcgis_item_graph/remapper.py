"""
arcgis_item_graph/remapper.py — Remap item data references across dependents.

Usage:
    r = ItemGraphRemapper(gis=gis, gml_file="outputs/graph.gml")
    preview = r.preview(from_id="abc123", to_id="xyz789")
    outcomes = r.execute(preview)
    manifest_path = r.write_manifest(preview, outcomes, output_dir="outputs")
"""
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class RemapCandidate:
    """A portal item involved in a remap operation."""
    item_id: str
    title: str
    type: str
    owner: str


@dataclass
class RemapPreview:
    """Describes a pending remap — shown to the user before any changes are made."""
    from_item: RemapCandidate
    to_item: RemapCandidate
    dependents: list = field(default_factory=list)  # list[RemapCandidate]


@dataclass
class RemapOutcome:
    """Per-item result after remap executes."""
    item_id: str
    title: str
    success: bool
    error: Optional[str]


from arcgis_item_graph.query import ItemGraphQuery


class ItemGraphRemapper:
    """
    Remap item data references across all dependent items.

    Uses Item.remap_data() to substitute one item ID for another throughout
    every item that directly references the source item.
    """

    def __init__(self, gis, gml_file: str) -> None:
        self.gis = gis
        self.gml_file = Path(gml_file)

    def preview(self, from_id: str, to_id: str) -> RemapPreview:
        """
        Resolve both items and find all dependents. No changes are made.

        Args:
            from_id: Item ID of the item to replace.
            to_id:   Item ID of the replacement item.

        Returns:
            RemapPreview with from_item, to_item, and list of dependent items.

        Raises:
            ValueError: If either item is not found in the portal.
        """
        from_api = self.gis.content.get(from_id)
        if from_api is None:
            raise ValueError(f"Item {from_id!r} not found in portal")

        to_api = self.gis.content.get(to_id)
        if to_api is None:
            raise ValueError(f"Item {to_id!r} not found in portal")

        from_item = RemapCandidate(
            item_id=from_id,
            title=from_api.title,
            type=from_api.type,
            owner=from_api.owner,
        )
        to_item = RemapCandidate(
            item_id=to_id,
            title=to_api.title,
            type=to_api.type,
            owner=to_api.owner,
        )

        # Query the graph to find all items connected to from_id, then filter
        # to only those that directly reference it (node.contains() includes from_id).
        q = ItemGraphQuery(gis=self.gis, gml_file=str(self.gml_file))
        result = q.query(ids=[from_id])

        dependents = []
        for node in result.nodes:
            if node.id == from_id:
                continue
            if from_id in node.contains():
                dependents.append(RemapCandidate(
                    item_id=node.id,
                    title=node.item.title if node.item else node.id,
                    type=node.item.type if node.item else "Unknown",
                    owner=node.item.owner if node.item else "Unknown",
                ))

        logger.info(
            f"Remap preview: {from_id!r} → {to_id!r}  "
            f"({len(dependents)} dependent(s) found)"
        )
        return RemapPreview(from_item=from_item, to_item=to_item, dependents=dependents)

    def execute(
        self, preview: RemapPreview, force: bool = False
    ) -> list:  # list[RemapOutcome]
        """
        Call Item.remap_data() on each dependent item.

        Continues processing remaining items if one fails — partial failures
        are recorded in the returned outcomes.

        Args:
            preview: RemapPreview from preview() or preview_rollback().
            force:   If True, passes force=True to remap_data() (bypasses type
                     validation). Advanced use only.

        Returns:
            list[RemapOutcome] — one entry per dependent item.
        """
        outcomes = []
        mapping = {preview.from_item.item_id: preview.to_item.item_id}

        for candidate in preview.dependents:
            item = self.gis.content.get(candidate.item_id)
            if item is None:
                outcomes.append(RemapOutcome(
                    item_id=candidate.item_id,
                    title=candidate.title,
                    success=False,
                    error=f"Item {candidate.item_id!r} not found in portal",
                ))
                continue

            try:
                success = item.remap_data(mapping, force=force)
                outcomes.append(RemapOutcome(
                    item_id=candidate.item_id,
                    title=candidate.title,
                    success=bool(success),
                    error=None if success else (
                        "remap_data returned False — possible type mismatch; "
                        "use --force to bypass validation"
                    ),
                ))
            except Exception as exc:
                logger.warning(f"remap_data failed for {candidate.item_id}: {exc}")
                outcomes.append(RemapOutcome(
                    item_id=candidate.item_id,
                    title=candidate.title,
                    success=False,
                    error=str(exc),
                ))

        succeeded = sum(1 for o in outcomes if o.success)
        logger.info(
            f"Remap execute complete: {succeeded}/{len(outcomes)} succeeded"
        )
        return outcomes

    def write_manifest(
        self, preview: RemapPreview, outcomes: list, output_dir: str, force: bool = False
    ) -> Optional[Path]:
        """
        Write a rollback manifest for all successfully remapped items.

        Returns the manifest Path, or None if nothing succeeded (nothing to roll back).
        """
        succeeded = [o.item_id for o in outcomes if o.success]
        if not succeeded:
            logger.info("No successful remaps — skipping manifest write")
            return None

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        manifest = {
            "from_id": preview.from_item.item_id,
            "to_id": preview.to_item.item_id,
            "timestamp": datetime.now().isoformat(),
            "remapped": succeeded,
            "force": force,
        }
        path = Path(output_dir) / f"rollback_{ts}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(manifest, indent=2))
        logger.info(f"Rollback manifest written: {path}")
        return path

    def preview_rollback(self, manifest_path: str) -> RemapPreview:
        """
        Load a rollback manifest and return a RemapPreview for the reverse operation.

        The from/to IDs are swapped relative to the original remap, and the
        dependents list is built from the items that were successfully remapped.

        Args:
            manifest_path: Path to a rollback_<timestamp>.json file.

        Raises:
            FileNotFoundError: If the manifest file does not exist.
            ValueError: If from or to item is not found in the portal.
        """
        path = Path(manifest_path)
        if not path.exists():
            raise FileNotFoundError(f"Rollback manifest not found: {manifest_path}")

        manifest = json.loads(path.read_text())

        # Reverse the mapping: original to_id is the new from_id
        from_id = manifest["to_id"]
        to_id = manifest["from_id"]

        from_api = self.gis.content.get(from_id)
        if from_api is None:
            raise ValueError(f"Item {from_id!r} not found in portal")

        to_api = self.gis.content.get(to_id)
        if to_api is None:
            raise ValueError(f"Item {to_id!r} not found in portal")

        dependents = []
        for item_id in manifest["remapped"]:
            item = self.gis.content.get(item_id)
            if item:
                dependents.append(RemapCandidate(
                    item_id=item_id,
                    title=item.title,
                    type=item.type,
                    owner=item.owner,
                ))
            else:
                logger.warning(f"Rollback: item {item_id!r} no longer found in portal")
                dependents.append(RemapCandidate(
                    item_id=item_id, title=item_id, type="Unknown", owner="Unknown"
                ))

        return RemapPreview(
            from_item=RemapCandidate(
                item_id=from_id, title=from_api.title,
                type=from_api.type, owner=from_api.owner,
            ),
            to_item=RemapCandidate(
                item_id=to_id, title=to_api.title,
                type=to_api.type, owner=to_api.owner,
            ),
            dependents=dependents,
        )
