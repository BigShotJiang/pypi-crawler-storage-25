"""arcgis_item_graph/console.py — Shared Rich output surface for all CLI commands.

All user-facing terminal output flows through this module. Library classes
(creator, updater, triage) remain UI-free and call into this via callbacks.
"""
from __future__ import annotations

import time
from typing import Optional

from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.table import Table
from rich.text import Text

# Shared console — module-level so it can be patched in tests.
console = Console(highlight=False)


# ── Standalone helpers ────────────────────────────────────────────────────────

def print_step(label: str) -> None:
    """Dim prefixed status line — used outside Live contexts."""
    console.print(f"[dim]▸[/] {label}")


def print_error_panel(
    title: str,
    message: str,
    hint: Optional[str] = None,
) -> None:
    """Render a red-bordered error panel, stopping any active Live display first."""
    global _active_progress
    if _active_progress is not None:
        try:
            _active_progress._live.__exit__(None, None, None)
        except Exception:
            pass
        _active_progress = None

    body = message
    if hint:
        body += f"\n[dim]─────────────────────────────[/]\n[dim]💡 {hint}[/]"

    console.print(
        Panel(body, title=f"[bold red]✗  {title}[/]", border_style="red")
    )


def print_completion_table(
    title: str,
    rows: list[tuple[str, str]],
    elapsed: float,
) -> None:
    """Render a borderless Rich Table with label/value rows and elapsed in the title."""
    total_s = int(elapsed)
    hrs, rem = divmod(total_s, 3600)
    mins, secs = divmod(rem, 60)
    if hrs:
        elapsed_str = f"{hrs}h {mins}m {secs}s"
    elif mins:
        elapsed_str = f"{mins}m {secs}s"
    else:
        elapsed_str = f"{secs}s"

    table = Table(
        title=f"[bold green]✓ {title}[/] — {elapsed_str}",
        show_header=False,
        show_edge=False,
        box=None,
        padding=(0, 1),
    )
    table.add_column("label", style="cyan", min_width=18)
    table.add_column("value", min_width=20)
    for label, value in rows:
        table.add_row(label, value)
    console.print(table)


# ── CommandProgress — Live display ────────────────────────────────────────────

_active_progress: Optional["CommandProgress"] = None


class CommandProgress:
    """Hybrid Live display: scrolling amber warnings above a sticky progress bar.

    Usage::

        with CommandProgress("Create", total=10000) as prog:
            ItemGraphCreator(gis, ..., on_progress=prog.on_item,
                             on_warning=prog.on_warning).create()
    """

    _MAX_LOG = 20

    def __init__(self, command_name: str, total: Optional[int] = None) -> None:
        self._command_name = command_name
        self._total = total
        self._count = 0
        self.warning_count = 0
        self._start = time.monotonic()
        self._log_lines: list = []
        self._layout: Optional[Layout] = None
        self._live: Optional[Live] = None

        self._progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=None),
            TextColumn(
                "[cyan]{task.completed}[/cyan]/[cyan]{task.total}[/cyan]"
                if total is not None
                else "[cyan]{task.completed}[/cyan]"
            ),
            TimeElapsedColumn(),
            console=console,
            transient=False,
        )
        self._task_id = self._progress.add_task(command_name, total=total)

    def __enter__(self) -> "CommandProgress":
        global _active_progress
        self._layout = Layout()
        self._layout.split_column(
            Layout(name="log"),
            Layout(name="prog", size=3),
        )
        self._layout["log"].update(Text(""))
        self._layout["prog"].update(self._progress)
        self._live = Live(self._layout, console=console, refresh_per_second=8)
        self._live.__enter__()
        _active_progress = self
        return self

    def __exit__(self, *args) -> None:
        global _active_progress
        if self._live is not None:
            self._live.__exit__(*args)
            self._live = None
        if _active_progress is self:
            _active_progress = None

    def _refresh_log(self) -> None:
        if self._layout is None:
            return
        from rich.console import Group
        visible = self._log_lines[-self._MAX_LOG:]
        self._layout["log"].update(Group(*visible) if visible else Text(""))

    def on_item(self, *, count: int, title: str, item_type: str = "") -> None:
        """Advance the progress bar and update the current-item description."""
        self._count = count
        desc = f"{self._command_name}: {title[:40]}"
        if item_type:
            desc += f" [{item_type}]"
        self._progress.update(self._task_id, completed=count, description=desc)

    def on_warning(self, *, title: str, reason: str, item_id: str = "") -> None:
        """Append an amber callout to the scrolling log region."""
        self.warning_count += 1
        line = Text.assemble(
            ("⚠ ", "bold yellow"),
            (title[:50], "white"),
            " — ",
            (reason, "red"),
        )
        self._log_lines.append(line)
        self._refresh_log()

    def set_step(self, label: str) -> None:
        """Append a dim step-transition line and update the bar description."""
        line = Text.assemble(("▸ ", "dim"), (label, "dim"))
        self._log_lines.append(line)
        self._refresh_log()
        self._progress.update(self._task_id, description=label)

    def set_total(self, total: int) -> None:
        """Switch from indeterminate spinner to a determinate bar."""
        self._total = total
        self._progress.update(self._task_id, total=total)

    def elapsed(self) -> float:
        """Seconds elapsed since the context was entered (or object was created)."""
        return time.monotonic() - self._start
