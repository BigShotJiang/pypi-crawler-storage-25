"""arcgis_item_graph/triage.py — High-traffic item triage for migration planning."""
from __future__ import annotations

import json
import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

from arcgis_item_graph.utils import batch_fetch_items

logger = logging.getLogger(__name__)

CONSUMER_TYPES = {
    "Web Mapping Application",
    "Dashboard",
    "Experience Builder Web App",
    "Web Map",
    "Hub Site Application",
    "StoryMap",
}

# Data source type values
DS_HOSTED_RELATIONAL = "hosted_relational"
DS_HOSTED_SPATIOTEMPORAL = "hosted_spatiotemporal"
DS_EGDB = "egdb"
DS_FGDB = "fgdb"
DS_FEDERATED = "federated_server"
DS_EXTERNAL = "external"
DS_UNKNOWN = "unknown"


@dataclass
class RankedItem:
    item_id: str
    title: str
    item_type: str
    portal_url: str
    view_count: int            # from usage stats API (0 if unavailable)
    dependency_count: int      # number of service dependencies this item has
    traffic_rank: float        # composite score 0.0–1.0
    last_modified: str


@dataclass
class ServiceDep:
    service_url: str
    item_id: Optional[str]
    item_title: Optional[str]
    hosting_server: str
    data_source_type: str      # one of DS_* constants above
    classifier_tier: int       # 1, 2, or 3
    layer_count: Optional[int]
    referenced_by: list        # item_ids of RankedItems that use this service


@dataclass
class TriageResult:
    generated_at: str
    portal_url: str
    graph_age_hours: float
    ranked_items: list         # list[RankedItem]
    services: list             # list[ServiceDep] — deduplicated across all items
    dependency_matrix: list    # list[dict] — flat join: one row per item→service
    consumer_map: dict = field(default_factory=dict)  # item_id → list[{id,title,type}]


# Tier 1 URL patterns — order matters (spatiotemporal checked before hosted)
_TIER1_SPATIOTEMPORAL = re.compile(
    r"GeoAnalyticsServer|GeoEvent|spatiotemporal", re.IGNORECASE
)
_TIER1_HOSTED_ARCGIS_ONLINE = re.compile(
    r"services\.arcgis\.com", re.IGNORECASE
)
_TIER1_HOSTED_PORTAL = re.compile(
    # /hosting/ web-adaptor  OR  /rest/services/Hosted/ service-folder
    r"/hosting/|/rest/services/hosted/", re.IGNORECASE
)


class ItemRanker:
    """Scores and filters consumer items from the NetworkX graph."""

    def __init__(self, gis, portal_url: str):
        self._gis = gis
        self._portal_url = portal_url.rstrip("/")

    def _fetch_view_count(self, item_id: str) -> int:
        """Fetch total view count for one item.

        Tries the time-series usage API first (ArcGIS Online only).
        Falls back to item.numViews, which is available on Enterprise Portal
        and represents the all-time view count stored in the portal database.
        Returns 0 on failure.
        """
        try:
            item = self._gis.content.get(item_id)
            if item is None:
                return 0
            # Try rolling 6-month usage (ArcGIS Online only)
            try:
                usage = item.usage(date_range="6M")
                if usage:
                    return sum(int(period.get("num", 0)) for period in usage)
            except Exception:
                pass
            # Fallback: all-time view count (works on Enterprise Portal)
            return int(getattr(item, "numViews", 0) or 0)
        except Exception as exc:
            logger.debug("Usage stats unavailable for %s: %s", item_id, exc)
            return 0

    def rank(
        self,
        graph,
        top_n: int = 50,
        min_dependents: int = 0,
        use_usage_stats: bool = True,
        workers: int = 10,
    ) -> list:
        """Return ranked list of RankedItem for consumer nodes in graph.

        Args:
            graph: networkx.DiGraph loaded from graph.gml
            top_n: maximum number of items to return (after filtering)
            min_dependents: exclude items with fewer than this many outgoing edges
            use_usage_stats: if True, fetch view counts via portal API
            workers: thread pool size for parallel usage stat calls
        """
        # Build item metadata: prefer graph-embedded attrs (tests / future graph
        # versions); fall back to portal search when GML has no type attributes
        # (the current GML format intentionally omits item metadata).
        node_has_type = any(
            data.get("type") for _, data in graph.nodes(data=True)
        )
        if node_has_type:
            item_meta = {
                nid: {"title": attrs.get("title", nid),
                      "type": attrs.get("type", ""),
                      "modified": attrs.get("modified", 0)}
                for nid, attrs in graph.nodes(data=True)
                if attrs.get("type") in CONSUMER_TYPES
            }
        else:
            logger.info(
                "Graph has no type attributes — fetching consumer items from portal"
            )
            type_clauses = " OR ".join(f'type:"{t}"' for t in sorted(CONSUMER_TYPES))
            try:
                portal_items = self._gis.content.search(
                    type_clauses, max_items=10000
                )
            except Exception as exc:
                logger.warning("Portal search for consumer types failed: %s", exc)
                return []
            all_node_ids = set(graph.nodes())
            item_meta = {
                item.itemid: {
                    "title": item.title or item.itemid,
                    "type": item.type or "",
                    "modified": getattr(item, "modified", 0) or 0,
                }
                for item in portal_items
                if item.itemid in all_node_ids
            }

        # Apply min_dependents filter
        candidates = [
            (nid, graph.out_degree(nid))
            for nid in item_meta
            if graph.out_degree(nid) >= min_dependents
        ]
        if not candidates:
            return []

        # Fetch usage stats in parallel if requested
        view_counts: dict = {}
        if use_usage_stats:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                future_map = {
                    pool.submit(self._fetch_view_count, nid): nid
                    for nid, _ in candidates
                }
                for future in as_completed(future_map):
                    nid = future_map[future]
                    try:
                        view_counts[nid] = future.result()
                    except Exception as exc:
                        logger.debug("Failed to get usage for %s: %s", nid, exc)
                        view_counts[nid] = 0
        else:
            view_counts = {nid: 0 for nid, _ in candidates}

        # Normalise to [0, 1] for composite score
        max_views = max(view_counts.values(), default=1) or 1
        max_deps = max(dep for _, dep in candidates) or 1

        def _score(nid: str, dep_count: int) -> float:
            v_norm = view_counts.get(nid, 0) / max_views
            d_norm = dep_count / max_deps
            if use_usage_stats:
                return 0.6 * v_norm + 0.4 * d_norm
            return d_norm

        ranked = []
        for nid, dep_count in candidates:
            meta = item_meta[nid]
            try:
                modified_str = datetime.fromtimestamp(
                    int(meta["modified"]) / 1000
                ).isoformat(timespec="seconds")
            except (ValueError, OSError):
                modified_str = ""
            portal_url = f"{self._portal_url}/home/item.html?id={nid}"
            ranked.append(
                RankedItem(
                    item_id=nid,
                    title=meta["title"],
                    item_type=meta["type"],
                    portal_url=portal_url,
                    view_count=view_counts.get(nid, 0),
                    dependency_count=dep_count,
                    traffic_rank=_score(nid, dep_count),
                    last_modified=modified_str,
                )
            )

        ranked.sort(key=lambda r: r.traffic_rank, reverse=True)
        return ranked[:top_n]


class DataSourceClassifier:
    """Three-tier data source type detection for ArcGIS service URLs."""

    def __init__(self, gis, portal_url: str):
        self._gis = gis
        self._portal_host = self._extract_host(portal_url)

    @staticmethod
    def _extract_host(url: str) -> str:
        """Return lowercase hostname from a URL."""
        try:
            from urllib.parse import urlparse
            return urlparse(url).hostname or ""
        except Exception:
            return ""

    @staticmethod
    def _extract_hosting_server(url: str) -> str:
        """Return 'hostname/web_adaptor' from an ArcGIS REST service URL.

        ArcGIS Server URLs follow the pattern:
            https://{hostname}/{web_adaptor}/rest/services/{...}/{ServiceType}

        The web adaptor (e.g. 'mapping3', 'gis', 'arcgis') identifies which
        server instance hosts the service and is more useful than the bare
        hostname for inventory and migration planning.
        """
        from urllib.parse import urlparse
        parsed = urlparse(url)
        hostname = parsed.hostname or ""
        # Walk path segments; web adaptor is the last segment before 'rest'
        parts = [p for p in parsed.path.split("/") if p]
        web_adaptor = ""
        for part in parts:
            if part.lower() == "rest":
                break
            web_adaptor = part
        if web_adaptor:
            return f"{hostname}/{web_adaptor}"
        return hostname

    def _classify_tier1(self, url: str) -> tuple:
        """Pattern-match the URL. Returns (type, tier) or (DS_UNKNOWN, 0) if no match."""
        if _TIER1_SPATIOTEMPORAL.search(url):
            return DS_HOSTED_SPATIOTEMPORAL, 1
        if _TIER1_HOSTED_ARCGIS_ONLINE.search(url):
            return DS_HOSTED_RELATIONAL, 1
        if _TIER1_HOSTED_PORTAL.search(url):
            return DS_HOSTED_RELATIONAL, 1
        # Check hostname relationship to portal
        url_host = self._extract_host(url)
        if not url_host or not self._portal_host:
            return DS_UNKNOWN, 0
        if url_host != self._portal_host:
            return DS_EXTERNAL, 1
        # Same hostname as the portal → enterprise ArcGIS Server (federated).
        # Services published via a web adaptor to /rest/services/ are backed by
        # Enterprise GDB in the vast majority of on-premises deployments.
        from urllib.parse import urlparse
        path = urlparse(url).path
        if "/rest/services/" in path:
            return DS_EGDB, 1
        return DS_UNKNOWN, 0

    def _classify_tier2(self, service_url: str) -> tuple:
        """Fetch service root JSON and classify. Returns (type, 2)."""
        try:
            data = self._gis._con.get(service_url, params={"f": "json"})
            if not isinstance(data, dict):
                return DS_UNKNOWN, 2
        except Exception as exc:
            logger.debug("Tier 2 fetch failed for %s: %s", service_url, exc)
            return DS_UNKNOWN, 2

        # Spatiotemporal via capabilities
        if "spatiotemporal" in str(data).lower():
            return DS_HOSTED_SPATIOTEMPORAL, 2

        # EGDB: advanced analytic query capability (most reliable enterprise indicator;
        # present at service root for FeatureServer, layer root for MapServer)
        adv = data.get("advancedQueryCapabilities", {})
        if isinstance(adv, dict) and adv.get("supportsQueryAnalytic"):
            return DS_EGDB, 2

        # FGDB / static file-based data source
        if data.get("hasStaticData") is True:
            return DS_FGDB, 2

        # Hosted relational: only when EGDB/FGDB indicators are absent AND the
        # service has been reached here (i.e. it is NOT on the portal's own server —
        # those are caught at Tier 1).  PBF format support is intentionally NOT used
        # as an indicator: ArcGIS Server 10.6+ returns PBF for all service types,
        # making it unreliable for distinguishing EGDB from hosted feature services.
        return DS_UNKNOWN, 2

    def _classify_tier3(self, service_url: str) -> tuple:
        """Inspect layers endpoint for SQL type fields. Returns (type, 3)."""
        layers_url = service_url.rstrip("/") + "/layers"
        try:
            data = self._gis._con.get(layers_url, params={"f": "json"})
        except Exception as exc:
            logger.debug("Tier 3 fetch failed for %s: %s", layers_url, exc)
            return DS_UNKNOWN, 3

        if not isinstance(data, dict):
            return DS_UNKNOWN, 3

        layers = data.get("layers", [])
        for layer in layers:
            fields = layer.get("fields", [])
            for field in fields:
                if "sqlType" in field:
                    return DS_EGDB, 3
        # Layers found but no sqlType → FGDB
        if layers:
            return DS_FGDB, 3
        return DS_UNKNOWN, 3

    def classify(self, service_url: str, deep: bool = False,
                 _tier1_only: bool = False) -> tuple:
        """Classify a service URL. Returns (data_source_type, classifier_tier)."""
        ds_type, tier = self._classify_tier1(service_url)
        if tier == 1 or _tier1_only:
            return ds_type, tier
        ds_type, tier = self._classify_tier2(service_url)
        if ds_type != DS_UNKNOWN or not deep:
            return ds_type, tier
        return self._classify_tier3(service_url)

    def classify_many(self, service_urls: list, deep: bool = False,
                      workers: int = 10) -> dict:
        """Classify a list of service URLs in parallel, deduplicating first.

        Returns:
            dict mapping service_url -> (data_source_type, classifier_tier)
        """
        unique_urls = list(dict.fromkeys(service_urls))  # preserve order, deduplicate
        results: dict = {}

        with ThreadPoolExecutor(max_workers=workers) as pool:
            future_map = {
                pool.submit(self.classify, url, deep): url
                for url in unique_urls
            }
            for future in as_completed(future_map):
                url = future_map[future]
                try:
                    results[url] = future.result()
                except Exception as exc:
                    logger.warning("classify failed for %s: %s", url, exc)
                    results[url] = (DS_UNKNOWN, 2)

        return results


class ItemTriageRunner:
    """Orchestrates the full triage pipeline."""

    def __init__(self, gis, config: dict, on_progress=None, on_warning=None):
        self._gis = gis
        self._cfg = config.get("triage", {})
        self._portal_url = gis.url.rstrip("/")
        self._on_progress = on_progress or (lambda **kw: None)
        self._on_warning = on_warning or (lambda **kw: None)

    def _get_service_url(self, graph, node_id: str) -> Optional[str]:
        """Return the REST endpoint URL for a graph node.

        Checks node 'url' attribute first, then attempts portal lookup.
        Returns None if no URL can be resolved.
        """
        attrs = graph.nodes.get(node_id, {})
        # Prefer the stored url attribute (set during create/update)
        url = attrs.get("url") or attrs.get("serviceUrl")
        if url:
            return url
        # Fallback: look up item in portal
        try:
            item = self._gis.content.get(node_id)
            if item and item.url:
                return item.url
        except Exception as exc:
            logger.debug("Portal lookup failed for %s: %s", node_id, exc)
        return None

    def run(self, graph, graph_age_hours: float = 0.0) -> TriageResult:
        """Run the full triage pipeline against a networkx DiGraph.

        Args:
            graph: networkx.DiGraph loaded from graph.gml
            graph_age_hours: staleness of the graph in hours (for metadata)
        """
        top_n = self._cfg.get("top_n", 50)
        min_dependents = self._cfg.get("min_dependents", 0)
        deep = self._cfg.get("deep_inspect", False)
        use_usage = self._cfg.get("use_usage_stats", True)

        # Stage 1: rank consumer items
        ranker = ItemRanker(gis=self._gis, portal_url=self._portal_url)
        ranked_items = ranker.rank(
            graph, top_n=top_n, min_dependents=min_dependents,
            use_usage_stats=use_usage,
        )

        # Fire progress callbacks for each ranked item
        for i, ri in enumerate(ranked_items, 1):
            self._on_progress(count=i, title=ri.title, item_type=ri.item_type)

        if not ranked_items:
            return TriageResult(
                generated_at=datetime.utcnow().isoformat(timespec="seconds") + "Z",
                portal_url=self._portal_url,
                graph_age_hours=graph_age_hours,
                ranked_items=[],
                services=[],
                dependency_matrix=[],
            )

        # Stage 2: collect all service URLs from ranked items' outgoing edges
        item_to_service_urls: dict = {}
        all_service_urls = []
        for ranked in ranked_items:
            successors = list(graph.successors(ranked.item_id))
            svc_urls = []
            for svc_id in successors:
                url = self._get_service_url(graph, svc_id)
                if url:
                    svc_urls.append(url)
                    all_service_urls.append(url)
            item_to_service_urls[ranked.item_id] = svc_urls

        # Stage 3: classify all service URLs (deduplicated)
        classifier = DataSourceClassifier(
            gis=self._gis, portal_url=self._portal_url
        )
        url_classifications = classifier.classify_many(all_service_urls, deep=deep)

        # Stage 4: build ServiceDep list (deduplicated)
        # Track which high-traffic items reference each service
        service_refs: dict = {}  # url → [item_ids]
        for ranked in ranked_items:
            for url in item_to_service_urls.get(ranked.item_id, []):
                service_refs.setdefault(url, []).append(ranked.item_id)

        services = []
        for url, item_ids in service_refs.items():
            ds_type, tier = url_classifications.get(url, (DS_UNKNOWN, 0))
            hosting_server = DataSourceClassifier._extract_hosting_server(url)
            services.append(ServiceDep(
                service_url=url,
                item_id=None,
                item_title=None,
                hosting_server=hosting_server,
                data_source_type=ds_type,
                classifier_tier=tier,
                layer_count=None,
                referenced_by=item_ids,
            ))

        # Stage 5: build flat dependency matrix
        matrix = []
        for rank_idx, ranked in enumerate(ranked_items):
            for url in item_to_service_urls.get(ranked.item_id, []):
                ds_type, tier = url_classifications.get(url, (DS_UNKNOWN, 0))
                matrix.append({
                    "item_rank": rank_idx + 1,
                    "item_id": ranked.item_id,
                    "item_title": ranked.title,
                    "item_type": ranked.item_type,
                    "view_count": ranked.view_count,
                    "traffic_rank": round(ranked.traffic_rank, 4),
                    "service_url": url,
                    "service_title": None,
                    "hosting_server": DataSourceClassifier._extract_hosting_server(url),
                    "data_source_type": ds_type,
                    "classifier_tier": tier,
                })

        # Stage 6: build consumer map — for each ranked item, which portal items
        # depend on it (graph predecessors = items that have an edge pointing TO it).
        # Batch-fetch their titles for readable output.
        all_pred_ids: set = set()
        raw_consumer_map: dict = {}
        for ranked in ranked_items:
            preds = list(graph.predecessors(ranked.item_id))
            raw_consumer_map[ranked.item_id] = preds
            all_pred_ids.update(preds)

        pred_meta: dict = {}
        if all_pred_ids:
            try:
                fetched = batch_fetch_items(self._gis, list(all_pred_ids))
                pred_meta = {
                    iid: {"title": it.title, "type": it.type}
                    for iid, it in fetched.items()
                }
            except Exception as exc:
                logger.warning("Could not fetch consumer metadata: %s", exc)

        consumer_map = {
            item_id: [
                {
                    "id": pid,
                    "title": pred_meta.get(pid, {}).get("title", pid),
                    "type": pred_meta.get(pid, {}).get("type", "Unknown"),
                }
                for pid in pred_ids
            ]
            for item_id, pred_ids in raw_consumer_map.items()
        }

        return TriageResult(
            generated_at=datetime.utcnow().isoformat(timespec="seconds") + "Z",
            portal_url=self._portal_url,
            graph_age_hours=graph_age_hours,
            ranked_items=ranked_items,
            services=services,
            dependency_matrix=matrix,
            consumer_map=consumer_map,
        )

    def to_json(self, result: TriageResult, path: str) -> None:
        """Write triage result as a JSON manifest file."""
        # Build item → service_url lookup for per-item dependencies
        item_service_map: dict = {r.item_id: [] for r in result.ranked_items}
        for row in result.dependency_matrix:
            item_id = row["item_id"]
            if item_id in item_service_map:
                item_service_map[item_id].append({
                    "service_url": row["service_url"],
                    "item_id": None,
                    "item_title": row.get("service_title"),
                    "hosting_server": row["hosting_server"],
                    "data_source_type": row["data_source_type"],
                    "classifier_tier": row["classifier_tier"],
                    "layer_count": None,
                })

        output = {
            "meta": {
                "generated_at": result.generated_at,
                "portal_url": result.portal_url,
                "graph_age_hours": result.graph_age_hours,
                "top_n": self._cfg.get("top_n", 50),
                "deep_inspect": self._cfg.get("deep_inspect", False),
                "total_ranked_items": len(result.ranked_items),
                "total_unique_services": len(result.services),
            },
            "items": [
                {
                    "item_id": r.item_id,
                    "title": r.title,
                    "item_type": r.item_type,
                    "portal_url": r.portal_url,
                    "view_count": r.view_count,
                    "dependency_count": r.dependency_count,
                    "traffic_rank": round(r.traffic_rank, 4),
                    "last_modified": r.last_modified,
                    "dependencies": item_service_map.get(r.item_id, []),
                    "consumers": result.consumer_map.get(r.item_id, []),
                }
                for r in result.ranked_items
            ],
            "services": [
                {
                    "service_url": s.service_url,
                    "item_id": s.item_id,
                    "item_title": s.item_title,
                    "hosting_server": s.hosting_server,
                    "data_source_type": s.data_source_type,
                    "classifier_tier": s.classifier_tier,
                    "layer_count": s.layer_count,
                    "referenced_by_count": len(s.referenced_by),
                    "referenced_by_ids": s.referenced_by,
                }
                for s in result.services
            ],
        }
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(output, f, indent=2, default=str)
        logger.info("Triage manifest written to %s", path)

    def to_excel(self, result: TriageResult, path: str) -> None:
        """Write triage result as a 4-sheet Excel workbook."""
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment

        wb = openpyxl.Workbook()
        wb.remove(wb.active)  # remove default sheet

        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        header_font_white = Font(bold=True, color="FFFFFF")

        def _write_sheet(ws, headers, rows):
            ws.append(headers)
            for cell in ws[1]:
                cell.font = header_font_white
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal="center")
            for row in rows:
                ws.append([row.get(h) for h in headers])

        # ── Sheet 1: High Traffic Items ───────────────────────────────────────────
        ws1 = wb.create_sheet("High Traffic Items")
        ht_headers = ["rank", "item_id", "title", "item_type", "view_count",
                      "dependency_count", "traffic_rank", "portal_url", "last_modified"]
        ht_rows = [
            {
                "rank": i + 1,
                "item_id": r.item_id,
                "title": r.title,
                "item_type": r.item_type,
                "view_count": r.view_count,
                "dependency_count": r.dependency_count,
                "traffic_rank": round(r.traffic_rank, 4),
                "portal_url": r.portal_url,
                "last_modified": r.last_modified,
            }
            for i, r in enumerate(result.ranked_items)
        ]
        _write_sheet(ws1, ht_headers, ht_rows)

        # Build shared lookups used across sheets
        title_map = {r.item_id: r.title for r in result.ranked_items}
        type_map  = {r.item_id: r.item_type for r in result.ranked_items}
        view_map  = {r.item_id: r.view_count for r in result.ranked_items}

        # ── Sheet 2: Service Inventory ────────────────────────────────────────────
        ws2 = wb.create_sheet("Service Inventory")
        svc_headers = ["service_url", "item_id", "item_title", "hosting_server",
                       "data_source_type", "classifier_tier", "layer_count",
                       "referenced_by_count", "combined_view_impact",
                       "referenced_by_titles"]
        svc_rows = [
            {
                "service_url": s.service_url,
                "item_id": s.item_id,
                "item_title": s.item_title,
                "hosting_server": s.hosting_server,
                "data_source_type": s.data_source_type,
                "classifier_tier": s.classifier_tier,
                "layer_count": s.layer_count,
                "referenced_by_count": len(s.referenced_by),
                "combined_view_impact": sum(view_map.get(iid, 0) for iid in s.referenced_by),
                "referenced_by_titles": ", ".join(
                    title_map.get(i, i) for i in s.referenced_by
                ),
            }
            for s in result.services
        ]
        _write_sheet(ws2, svc_headers, svc_rows)

        # ── Sheet 3: Dependency Matrix ────────────────────────────────────────────
        ws3 = wb.create_sheet("Dependency Matrix")
        mat_headers = ["item_rank", "item_id", "item_title", "item_type",
                       "view_count", "traffic_rank",
                       "service_url", "service_title", "hosting_server",
                       "data_source_type", "classifier_tier"]
        _write_sheet(ws3, mat_headers, result.dependency_matrix)

        # ── Sheet 4: Migration Hotspots ───────────────────────────────────────────
        ws4 = wb.create_sheet("Migration Hotspots")
        min_refs = self._cfg.get("min_hotspot_refs", 2)
        hotspots = sorted(
            [s for s in result.services if len(s.referenced_by) >= min_refs],
            key=lambda s: sum(view_map.get(iid, 0) for iid in s.referenced_by),
            reverse=True,
        )
        hs_headers = ["impact_rank", "service_url", "item_title", "data_source_type",
                      "hosting_server", "referenced_by_count", "combined_view_impact",
                      "affected_item_titles", "affected_item_types"]
        from collections import Counter
        hs_rows = []
        for i, s in enumerate(hotspots):
            type_counts = Counter(type_map.get(iid, "Unknown") for iid in s.referenced_by)
            affected_types = ", ".join(
                f"{t} \u00d7{c}" if c > 1 else t for t, c in type_counts.most_common()
            )
            hs_rows.append({
                "impact_rank": i + 1,
                "service_url": s.service_url,
                "item_title": s.item_title,
                "data_source_type": s.data_source_type,
                "hosting_server": s.hosting_server,
                "referenced_by_count": len(s.referenced_by),
                "combined_view_impact": sum(view_map.get(iid, 0) for iid in s.referenced_by),
                "affected_item_titles": ", ".join(
                    title_map.get(iid, iid) for iid in s.referenced_by
                ),
                "affected_item_types": affected_types,
            })
        _write_sheet(ws4, hs_headers, hs_rows)

        # ── Sheet 5: Consumer Chain ───────────────────────────────────────────────
        # For each ranked item, shows which portal items depend on it (predecessors
        # in the dependency graph). Useful for migration planning: "if I retire or
        # modify this item, these downstream consumers will be affected."
        ws5 = wb.create_sheet("Consumer Chain")
        cc_headers = ["item_rank", "item_id", "item_title", "item_type",
                      "view_count", "traffic_rank",
                      "consumer_id", "consumer_title", "consumer_type"]
        cc_rows = []
        for i, r in enumerate(result.ranked_items):
            consumers = result.consumer_map.get(r.item_id, [])
            if consumers:
                for c in consumers:
                    cc_rows.append({
                        "item_rank": i + 1,
                        "item_id": r.item_id,
                        "item_title": r.title,
                        "item_type": r.item_type,
                        "view_count": r.view_count,
                        "traffic_rank": round(r.traffic_rank, 4),
                        "consumer_id": c["id"],
                        "consumer_title": c["title"],
                        "consumer_type": c["type"],
                    })
            else:
                cc_rows.append({
                    "item_rank": i + 1,
                    "item_id": r.item_id,
                    "item_title": r.title,
                    "item_type": r.item_type,
                    "view_count": r.view_count,
                    "traffic_rank": round(r.traffic_rank, 4),
                    "consumer_id": None,
                    "consumer_title": "(no consumers in graph — accessed directly)",
                    "consumer_type": None,
                })
        _write_sheet(ws5, cc_headers, cc_rows)

        Path(path).parent.mkdir(parents=True, exist_ok=True)
        wb.save(path)
        logger.info("Triage report written to %s", path)
