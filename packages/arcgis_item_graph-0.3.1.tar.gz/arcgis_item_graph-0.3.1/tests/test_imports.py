# tests/test_imports.py
def test_all_public_classes_importable():
    """All public classes should be importable from the top-level package."""
    from arcgis_item_graph import (
        ItemGraphCreator,
        ItemGraphUpdater,
        ItemGraphQuery,
        QueryResult,
        ItemGraphReporter,
        ItemGraphVisualizer,
    )


def test_auditor_importable():
    from arcgis_item_graph import ItemDependencyAuditor, NodeDiff, AuditReport
    assert ItemDependencyAuditor is not None
    assert NodeDiff is not None
    assert AuditReport is not None


def test_triage_exports():
    from arcgis_item_graph import ItemTriageRunner, TriageResult, RankedItem, ServiceDep
    assert ItemTriageRunner is not None
    assert TriageResult is not None
    assert RankedItem is not None
    assert ServiceDep is not None


def test_metadata_cache_exported():
    from arcgis_item_graph import MetadataCache
    assert MetadataCache is not None


def test_metadata_cache_has_expected_methods():
    from arcgis_item_graph import MetadataCache
    assert hasattr(MetadataCache, "build")
    assert hasattr(MetadataCache, "update")
    assert hasattr(MetadataCache, "broken_nodes")
    assert hasattr(MetadataCache, "orphan_candidates")
    assert hasattr(MetadataCache, "fanout")


def test_item_graph_remapper_exported():
    from arcgis_item_graph import ItemGraphRemapper, RemapPreview, RemapOutcome
    assert ItemGraphRemapper is not None
    assert RemapPreview is not None
    assert RemapOutcome is not None


def test_risk_score_exported():
    from arcgis_item_graph import RiskScore, score_item
    assert RiskScore is not None
    assert score_item is not None
