# tests/test_query.py
from unittest.mock import MagicMock, patch
import pytest
from arcgis_item_graph.query import ItemGraphQuery, QueryResult
from tests.conftest import make_mock_node, make_mock_graph, make_mock_unhydrated_node


@pytest.fixture(autouse=True)
def _patch_child_gis(mock_gis):
    """Patch GIS constructor so thread-local children reuse the mock session."""
    with patch("arcgis_item_graph.query.GIS", return_value=mock_gis):
        yield


@pytest.fixture
def two_node_graph():
    """Graph: node_a contains node_b (node_a depends on node_b)."""
    node_a = make_mock_node("id_a", title="Dashboard A", item_type="Dashboard",
                            contains_ids=["id_b"],
                            contained_by_ids=[],
                            required_by_ids=[])
    node_b = make_mock_node("id_b", title="Web Map B", item_type="Web Map",
                            contains_ids=[],
                            contained_by_ids=["id_a"],
                            required_by_ids=["id_a"])
    return make_mock_graph([node_a, node_b])


@patch("arcgis_item_graph.query.load_from_file")
def test_query_by_id_returns_query_result(mock_load, two_node_graph, mock_gis, tmp_path):
    """query(ids=[...]) should return a QueryResult.
    Default 'both' mode returns the queried item plus upstream AND downstream deps.
    node_a contains node_b, so both appear in the result."""
    mock_load.return_value = two_node_graph
    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    result = q.query(ids=["id_a"])

    assert isinstance(result, QueryResult)
    result_ids = {n.id for n in result.nodes}
    assert "id_a" in result_ids   # queried item always in result
    # id_b is a downstream dep of id_a (id_a contains id_b)
    # "both" direction includes forward deps — id_b should appear
    assert "id_b" in result_ids


@patch("arcgis_item_graph.query.load_from_file")
def test_query_by_search_returns_query_result(mock_load, two_node_graph, mock_gis, tmp_path):
    """query(search=...) should search portal and return matching items' sub-graph."""
    mock_load.return_value = two_node_graph

    mock_item = MagicMock()
    mock_item.itemid = "id_a"
    mock_gis.content.search.return_value = [mock_item]

    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    result = q.query(search="type:Dashboard")

    mock_gis.content.search.assert_called_once_with("type:Dashboard")
    result_ids = {n.id for n in result.nodes}
    assert "id_a" in result_ids


@patch("arcgis_item_graph.query.load_from_file")
@patch("arcgis_item_graph.query.create_dependency_graph")
@patch("arcgis_item_graph.query.nx.compose")
def test_missing_id_triggers_live_api_fallback(mock_compose, mock_cdg, mock_load, mock_gis, tmp_path):
    """Items not found in GML should fall back to live create_dependency_graph()."""
    # Graph only has id_a
    node_a = make_mock_node("id_a", contains_ids=[], required_by_ids=[])
    node_b = make_mock_node("id_b", contains_ids=[], required_by_ids=[])
    gml_graph = make_mock_graph([node_a])
    mock_load.return_value = gml_graph

    # Live API returns id_b
    live_graph = make_mock_graph([node_b])
    mock_cdg.return_value = live_graph

    # nx.compose returns a merged graph with both nodes
    merged = make_mock_graph([node_a, node_b])
    mock_compose.return_value = merged

    live_item = MagicMock()
    live_item.itemid = "id_b"
    mock_gis.content.get.return_value = live_item

    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    result = q.query(ids=["id_b"])

    mock_cdg.assert_called_once()


@patch("arcgis_item_graph.query.load_from_file")
def test_queried_ids_flagged_in_result(mock_load, two_node_graph, mock_gis, tmp_path):
    """QueryResult.queried_ids should only contain explicitly queried IDs."""
    mock_load.return_value = two_node_graph
    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    result = q.query(ids=["id_a"])

    assert "id_a" in result.queried_ids
    assert "id_b" not in result.queried_ids


@patch("arcgis_item_graph.query.load_from_file")
def test_query_raises_if_no_input(mock_load, mock_gis, tmp_path):
    """query() with no ids and no search should raise ValueError."""
    mock_load.return_value = make_mock_graph([])
    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    with pytest.raises(ValueError, match="Provide at least one of"):
        q.query()


@patch("arcgis_item_graph.query.load_from_file")
def test_result_nodes_are_hydrated(mock_load, mock_gis, tmp_path):
    """Nodes with item=None should be hydrated via parallel content.get() after query."""
    # Node with no item data (as returned by load_from_file with include_items=False)
    unhydrated = MagicMock()
    unhydrated.id = "id_a"
    unhydrated.item = None
    unhydrated.contains = MagicMock(return_value=[])
    unhydrated.required_by = MagicMock(return_value=[])

    mock_load.return_value = make_mock_graph([unhydrated])

    # Portal returns real item metadata via direct content.get()
    portal_item = MagicMock()
    portal_item.title = "My Dashboard"
    portal_item.type = "Dashboard"
    portal_item.owner = "jsmith"
    mock_gis.content.get.return_value = portal_item

    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    result = q.query(ids=["id_a"])

    # gis.content.get should have been called (parallel fetch approach)
    mock_gis.content.get.assert_called()
    # The node's item should now be populated
    assert result.nodes[0].item.title == "My Dashboard"


@patch("arcgis_item_graph.query.load_from_file")
def test_hydration_skips_url_ids(mock_load, mock_gis, tmp_path):
    """Nodes whose ID is a URL (malformed REST references) should not be hydrated."""
    url_node = MagicMock()
    url_node.id = "https://services.arcgis.com/rest/services/SomeLayer/FeatureServer/0"
    url_node.item = None
    url_node.contains = MagicMock(return_value=[])
    url_node.required_by = MagicMock(return_value=[])

    mock_load.return_value = make_mock_graph([url_node])

    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    q.query(ids=[url_node.id])

    # content.get should NOT be called for URL-style IDs
    mock_gis.content.get.assert_not_called()


@patch("arcgis_item_graph.query.load_from_file")
def test_hydration_failure_does_not_abort_other_nodes(mock_load, mock_gis, tmp_path):
    """A missing item in batch search must not prevent other nodes from hydrating."""
    node_a = MagicMock()
    node_a.id = "id_a"
    node_a.item = None
    node_a.contains = MagicMock(return_value=[])
    node_a.contained_by = MagicMock(return_value=["id_b"])  # id_b references id_a (upstream)
    node_a.required_by = MagicMock(return_value=[])

    node_b = MagicMock()
    node_b.id = "id_b"
    node_b.item = None
    node_b.contains = MagicMock(return_value=[])
    node_b.contained_by = MagicMock(return_value=[])
    node_b.required_by = MagicMock(return_value=[])

    mock_load.return_value = make_mock_graph([node_a, node_b])

    portal_item = MagicMock()
    portal_item.title = "Good Item"
    portal_item.type = "Web Map"

    # content.get returns portal_item for id_b, None for id_a (absent from portal)
    mock_gis.content.get.side_effect = lambda item_id: portal_item if item_id == "id_b" else None

    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    result = q.query(ids=["id_a"])  # upstream traversal: contained_by leads to id_b

    # Should not raise; id_b must be hydrated despite id_a being absent
    hydrated = {n.id: n for n in result.nodes}
    assert hydrated["id_b"].item.title == "Good Item"
    # id_a's item should remain unset (not in portal)
    assert hydrated["id_a"].item is None


@patch("arcgis_item_graph.query.load_from_file")
def test_hydration_network_error_sets_broken_reason(mock_load, mock_gis, tmp_path):
    """When batch search fails (network error), node gets broken_reason='not_found'.

    With batched hydration, exceptions in content.search() are caught inside
    batch_fetch_items() and logged as warnings — the node is marked 'not_found'
    since no item data was returned, even if the root cause was a network error.
    """
    node_a = MagicMock()
    node_a.id = "id_a"
    node_a.item = None
    node_a.contains = MagicMock(return_value=[])
    node_a.required_by = MagicMock(return_value=[])

    mock_load.return_value = make_mock_graph([node_a])
    # Simulate network failure during batch search
    mock_gis.content.search.side_effect = ConnectionError("socket timeout")

    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    result = q.query(ids=["id_a"])

    assert result.nodes[0].item is None
    # Batch failures surface as 'not_found' (exception swallowed in batch_fetch_items)
    assert result.nodes[0].broken_reason == "not_found"


def test_traverse_forward_visits_full_chain(mock_gis, tmp_path):
    """_traverse_forward (downstream BFS) must visit all nodes in a contains chain."""
    from arcgis_item_graph.query import ItemGraphQuery
    from unittest.mock import MagicMock

    # Build a 5-node linear chain: a → b → c → d → e (a contains b, b contains c, …)
    def make_node(nid, children=None):
        n = MagicMock()
        n.id = nid
        n.contains = MagicMock(return_value=children or [])
        return n

    nodes = {
        "a": make_node("a", children=["b"]),
        "b": make_node("b", children=["c"]),
        "c": make_node("c", children=["d"]),
        "d": make_node("d", children=["e"]),
        "e": make_node("e"),
    }

    mock_graph = MagicMock()
    mock_graph.get_node = MagicMock(side_effect=lambda nid: nodes.get(nid))

    gml_path = tmp_path / "g.gml"
    gml_path.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml_path))
    q._graph = mock_graph

    visited = q._traverse_forward({"a"})
    assert visited == {"a", "b", "c", "d", "e"}


def test_traverse_forward_respects_max_depth(mock_gis, tmp_path):
    """_traverse_forward must stop expanding nodes once max_depth is reached."""
    from arcgis_item_graph.query import ItemGraphQuery

    def make_node(nid, children=None):
        n = MagicMock()
        n.id = nid
        n.contains = MagicMock(return_value=children or [])
        return n

    # Linear chain a→b→c→d→e; seed="a", max_depth=2 should return {a, b, c}
    nodes = {
        "a": make_node("a", children=["b"]),
        "b": make_node("b", children=["c"]),
        "c": make_node("c", children=["d"]),
        "d": make_node("d", children=["e"]),
        "e": make_node("e"),
    }
    mock_graph = MagicMock()
    mock_graph.get_node = MagicMock(side_effect=lambda nid: nodes.get(nid))

    gml_path = tmp_path / "g.gml"
    gml_path.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml_path))
    q._graph = mock_graph

    visited = q._traverse_forward({"a"}, max_depth=2)
    assert visited == {"a", "b", "c"}


def test_query_respects_max_depth_config(mock_gis, tmp_path):
    """query() must pass max_depth to traversal, limiting nodes returned.
    Uses downstream direction (contains chain) to verify depth limiting."""
    from arcgis_item_graph.query import ItemGraphQuery

    def make_node(nid, children=None):
        n = MagicMock()
        n.id = nid
        n.item = None
        n.contains = MagicMock(return_value=children or [])
        n.required_by = MagicMock(return_value=[])
        return n

    nodes = {
        "a": make_node("a", children=["b"]),
        "b": make_node("b", children=["c"]),
        "c": make_node("c", children=["d"]),
        "d": make_node("d"),
    }
    mock_graph = MagicMock()
    mock_graph.get_node = MagicMock(side_effect=lambda nid: nodes.get(nid))
    mock_graph.all_items = MagicMock(return_value=list(nodes.values()))

    with patch("arcgis_item_graph.query.load_from_file", return_value=mock_graph):
        gml_path = tmp_path / "g.gml"
        gml_path.write_text("")
        q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml_path),
                           max_depth=1, traversal_direction="downstream")
        result = q.query(ids=["a"])

    assert {n.id for n in result.nodes} == {"a", "b"}


def test_resolve_missing_items_uses_thread_pool(mock_gis, tmp_path):
    """Verify _resolve_missing_items fetches items concurrently."""
    from arcgis_item_graph.query import ItemGraphQuery

    # Make content.get return a distinct mock item per ID
    def fake_get(item_id):
        m = MagicMock()
        m.itemid = item_id
        return m

    mock_gis.content.get.side_effect = fake_get

    # Patch graph-building helpers so we don't need real NetworkX/ArcGIS objects
    with patch("arcgis_item_graph.query.create_dependency_graph") as mock_cdg, \
         patch("arcgis_item_graph.query.nx") as mock_nx, \
         patch("arcgis_item_graph.query.ItemGraph"):
        mock_cdg.return_value = MagicMock(all_items=MagicMock(return_value=[]))
        mock_nx.compose.return_value = MagicMock()

        gml_path = tmp_path / "g.gml"
        gml_path.write_text("")

        q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml_path), fetch_workers=4)
        q._graph = MagicMock()
        q._graph.all_items.return_value = []  # nothing in the GML

        missing = {"id1", "id2", "id3"}
        q._resolve_missing_items(missing)

    # All 3 items should have been fetched
    assert mock_gis.content.get.call_count == 3


def test_hydrate_single_node_sets_broken_reason_on_exception():
    """broken_reason is set to the error category when hydration raises."""
    import types
    from unittest.mock import MagicMock, patch
    from arcgis_item_graph.query import ItemGraphQuery

    node = types.SimpleNamespace(id="abc123def456abc1", item=None)
    q = ItemGraphQuery.__new__(ItemGraphQuery)
    q.gis = MagicMock()
    q.fetch_workers = 1

    with patch(
        "arcgis_item_graph.query.retry_with_backoff",
        side_effect=Exception("unable to find iteminfo"),
    ):
        q._hydrate_single_node(node)

    assert node.broken_reason == "deleted"
    assert not hasattr(node, "deprecated")


def test_hydrate_single_node_sets_not_found_when_item_none():
    """broken_reason='not_found' when portal returns None without raising."""
    import types
    from unittest.mock import MagicMock, patch
    from arcgis_item_graph.query import ItemGraphQuery

    node = types.SimpleNamespace(id="abc123def456abc1", item=None)
    q = ItemGraphQuery.__new__(ItemGraphQuery)
    q.gis = MagicMock()
    q.fetch_workers = 1

    with patch("arcgis_item_graph.query.retry_with_backoff", return_value=None):
        q._hydrate_single_node(node)

    assert node.broken_reason == "not_found"
    assert not hasattr(node, "deprecated")


def test_hydrate_single_node_sets_deprecated_on_success():
    """deprecated is set from item.deprecated when hydration succeeds."""
    import types
    from unittest.mock import MagicMock, patch
    from arcgis_item_graph.query import ItemGraphQuery

    node = types.SimpleNamespace(id="abc123def456abc1", item=None)
    mock_item = MagicMock()
    mock_item.deprecated = True
    mock_item.title = "Test Item"
    mock_item.type = "Feature Service"

    q = ItemGraphQuery.__new__(ItemGraphQuery)
    q.gis = MagicMock()
    q.fetch_workers = 1

    with patch("arcgis_item_graph.query.retry_with_backoff", return_value=mock_item):
        q._hydrate_single_node(node)

    assert node.item is mock_item
    assert node.deprecated is True
    assert not hasattr(node, "broken_reason")


def test_hydrate_single_node_stub_property_access_raises():
    """node marked broken when item stub is returned but property access raises.

    Reproduces the production failure where gis.content.get() returns an Item
    object but accessing item.deprecated triggers the ArcGIS SDK's lazy-load
    _hydrate(), which then fails with 'Item does not exist or is inaccessible'.
    """
    import types
    from unittest.mock import MagicMock, PropertyMock, patch
    from arcgis_item_graph.query import ItemGraphQuery

    node = types.SimpleNamespace(id="abc123def456abc1", item=None)

    # Simulate an Item stub whose property access triggers a portal error
    mock_item = MagicMock()
    type(mock_item).deprecated = PropertyMock(
        side_effect=Exception("Item does not exist or is inaccessible.")
    )

    q = ItemGraphQuery.__new__(ItemGraphQuery)
    q.gis = MagicMock()
    q.fetch_workers = 1

    with patch("arcgis_item_graph.query.retry_with_backoff", return_value=mock_item):
        q._hydrate_single_node(node)

    assert node.item is None
    assert hasattr(node, "broken_reason")


def test_hydrate_result_nodes_stub_property_access_raises():
    """_hydrate_result_nodes marks node broken when item property access raises.

    Mirrors test_hydrate_single_node_stub_property_access_raises but exercises
    the batch + fallback path used by the main query flow.
    """
    import types
    from unittest.mock import MagicMock, PropertyMock, patch
    from arcgis_item_graph.query import ItemGraphQuery

    node = types.SimpleNamespace(id="abc123def456abc1", item=None)

    mock_item = MagicMock()
    type(mock_item).deprecated = PropertyMock(
        side_effect=Exception("Item does not exist or is inaccessible.")
    )

    q = ItemGraphQuery.__new__(ItemGraphQuery)
    q.gis = MagicMock()
    q.gis.content.get.return_value = mock_item   # fallback returns the stubby item
    q.hydration_workers = 1

    # Batch finds nothing → fallback uses gis.content.get → stub property raises
    with patch("arcgis_item_graph.query.batch_fetch_items", return_value={}):
        q._hydrate_result_nodes([node])

    assert node.item is None
    assert hasattr(node, "broken_reason")


class TestResolveUrlNodes:
    """_resolve_url_nodes() populates node.item by searching the portal."""

    def _make_query(self, mock_gis):
        """Helper: ItemGraphQuery with GML loading bypassed."""
        from arcgis_item_graph.query import ItemGraphQuery
        q = ItemGraphQuery(gis=mock_gis, gml_file="fake.gml")
        q._graph = make_mock_graph([])
        return q

    def test_resolves_url_node_to_portal_item(self, mock_gis):
        url = "https://portal/rest/services/Hosted/Roads/FeatureServer/0"
        mock_item = MagicMock()
        mock_item.title = "Roads Layer"
        mock_item.type = "Feature Layer Collection"
        mock_gis.content.search.return_value = [mock_item]

        node = make_mock_unhydrated_node(url)
        q = self._make_query(mock_gis)
        q._resolve_url_nodes([node])

        assert node.item is mock_item
        # Search was called with the base URL (layer index stripped)
        mock_gis.content.search.assert_called_once_with(
            'url:"https://portal/rest/services/Hosted/Roads/FeatureServer"',
            max_items=5,
        )

    def test_skips_portal_id_nodes(self, mock_gis):
        """Portal ID nodes (32-char hex) are not touched."""
        portal_node = make_mock_unhydrated_node("a" * 32)
        q = self._make_query(mock_gis)
        q._resolve_url_nodes([portal_node])

        mock_gis.content.search.assert_not_called()
        assert portal_node.item is None

    def test_skips_already_hydrated_url_nodes(self, mock_gis):
        """URL nodes with item already set are not searched again."""
        url = "https://portal/rest/services/Data/SVC/MapServer"
        node = MagicMock()
        node.id = url
        node.item = MagicMock()  # already hydrated

        q = self._make_query(mock_gis)
        q._resolve_url_nodes([node])

        mock_gis.content.search.assert_not_called()

    def test_handles_search_failure_gracefully(self, mock_gis):
        """Portal search failure leaves node.item as None without raising."""
        mock_gis.content.search.side_effect = Exception("Portal unavailable")
        url = "https://portal/rest/services/Broken/FeatureServer"
        node = make_mock_unhydrated_node(url)

        q = self._make_query(mock_gis)
        q._resolve_url_nodes([node])  # must not raise

        assert node.item is None

    def test_handles_empty_search_result(self, mock_gis):
        """Empty portal search leaves node.item as None."""
        mock_gis.content.search.return_value = []
        url = "https://portal/rest/services/Orphan/FeatureServer"
        node = make_mock_unhydrated_node(url)

        q = self._make_query(mock_gis)
        q._resolve_url_nodes([node])

        assert node.item is None

    def test_deduplicates_same_service_url(self, mock_gis):
        """Two nodes with the same base URL (different layer indices) trigger only one search."""
        mock_item = MagicMock()
        mock_gis.content.search.return_value = [mock_item]

        node0 = make_mock_unhydrated_node(
            "https://portal/rest/services/Hosted/Roads/FeatureServer/0"
        )
        node1 = make_mock_unhydrated_node(
            "https://portal/rest/services/Hosted/Roads/FeatureServer/1"
        )

        q = self._make_query(mock_gis)
        q._resolve_url_nodes([node0, node1])

        assert mock_gis.content.search.call_count == 1
        assert node0.item is mock_item
        assert node1.item is mock_item

    def test_noop_when_no_url_nodes(self, mock_gis):
        """If there are no URL nodes, no search is performed."""
        q = self._make_query(mock_gis)
        q._resolve_url_nodes([])
        mock_gis.content.search.assert_not_called()

    def test_skips_external_url_nodes(self, mock_gis):
        """Non-ArcGIS external URLs (classify_node_id == 'external_url') are skipped."""
        external_node = make_mock_unhydrated_node("https://example.com/data.zip")
        q = self._make_query(mock_gis)
        q._resolve_url_nodes([external_node])
        mock_gis.content.search.assert_not_called()
        assert external_node.item is None

    def test_first_result_used_when_search_returns_multiple(self, mock_gis):
        """When portal search returns multiple items, the first one is assigned."""
        item_a = MagicMock()
        item_a.title = "Primary Layer"
        item_b = MagicMock()
        item_b.title = "Derived View"
        mock_gis.content.search.return_value = [item_a, item_b]

        url = "https://portal/rest/services/Hosted/Roads/FeatureServer"
        node = make_mock_unhydrated_node(url)
        q = self._make_query(mock_gis)
        q._resolve_url_nodes([node])

        assert node.item is item_a   # first result wins


class TestProbeUrlNodes:
    def _make_result_with_nodes(self, nodes):
        result = QueryResult.__new__(QueryResult)
        result.nodes = nodes
        return result

    def test_probes_unresolved_url_nodes(self):
        """Calls probe_service_url for URL nodes with item=None and persists result."""
        mock_cache = MagicMock()
        url_node = MagicMock()
        url_node.id = "https://server/arcgis/rest/services/Roads/FeatureServer"
        url_node.item = None
        result = self._make_result_with_nodes([url_node])

        with patch("arcgis_item_graph.query.classify_node_id", return_value="arcgis_rest_url"), \
             patch("arcgis_item_graph.query.probe_service_url", return_value="inaccessible") as mock_probe:
            result._probe_url_nodes(mock_cache, verify_cert=True)

        mock_probe.assert_called_once_with(url_node.id, verify_cert=True)
        mock_cache.update_service_health.assert_called_once_with(url_node.id, "inaccessible")

    def test_skips_url_nodes_already_resolved_to_item(self):
        """Skips URL nodes that already have a resolved .item (resolved_to_item)."""
        mock_cache = MagicMock()
        url_node = MagicMock()
        url_node.id = "https://server/arcgis/rest/services/Roads/FeatureServer"
        url_node.item = MagicMock()  # resolved — should not be probed
        result = self._make_result_with_nodes([url_node])

        with patch("arcgis_item_graph.query.classify_node_id", return_value="arcgis_rest_url"), \
             patch("arcgis_item_graph.query.probe_service_url") as mock_probe:
            result._probe_url_nodes(mock_cache, verify_cert=True)

        mock_probe.assert_not_called()

    def test_skips_portal_id_nodes(self):
        """Skips portal ID nodes (only probes arcgis_rest_url nodes)."""
        mock_cache = MagicMock()
        portal_node = MagicMock()
        portal_node.id = "abc123def456abc123def456abc123de"
        portal_node.item = None
        result = self._make_result_with_nodes([portal_node])

        with patch("arcgis_item_graph.query.classify_node_id", return_value="portal_id"), \
             patch("arcgis_item_graph.query.probe_service_url") as mock_probe:
            result._probe_url_nodes(mock_cache, verify_cert=True)

        mock_probe.assert_not_called()


class TestBatchHydration:
    """_hydrate_result_nodes uses batch_fetch_items, not individual content.get."""

    def test_batch_fetch_called_not_content_get(self):
        """Verify batch_fetch_items is called and content.get is not."""
        import types
        from unittest.mock import MagicMock, patch
        from arcgis_item_graph.query import ItemGraphQuery

        gis = MagicMock()
        gis.url = "https://arcgis.com"

        node = types.SimpleNamespace(id="aabbccdd" * 4, item=None)

        with patch("arcgis_item_graph.query.batch_fetch_items") as mock_batch:
            item = MagicMock()
            item.title = "Test"
            item.type = "Web Map"
            mock_batch.return_value = {node.id: item}

            q = ItemGraphQuery.__new__(ItemGraphQuery)
            q.gis = gis
            q.hydration_workers = 10
            q._hydrate_result_nodes([node])

        mock_batch.assert_called_once()
        gis.content.get.assert_not_called()
        assert node.item == item

    def test_url_nodes_skipped(self):
        """URL-shaped node IDs are excluded from batch fetch."""
        import types
        from unittest.mock import MagicMock, patch
        from arcgis_item_graph.query import ItemGraphQuery

        gis = MagicMock()
        gis.url = "https://arcgis.com"

        url_node = types.SimpleNamespace(
            id="https://services.arcgis.com/rest/services/Layer/FeatureServer",
            item=None,
        )

        with patch("arcgis_item_graph.query.batch_fetch_items") as mock_batch:
            mock_batch.return_value = {}
            q = ItemGraphQuery.__new__(ItemGraphQuery)
            q.gis = gis
            q.hydration_workers = 10
            q._hydrate_result_nodes([url_node])

        mock_batch.assert_not_called()

    def test_missing_item_sets_broken_reason(self):
        """Node not in batch AND not found via content.get gets broken_reason = 'not_found'."""
        import types
        from unittest.mock import MagicMock, patch
        from arcgis_item_graph.query import ItemGraphQuery

        gis = MagicMock()
        gis.url = "https://arcgis.com"
        gis.content.get.return_value = None   # fallback also fails

        node = types.SimpleNamespace(id="aabbccdd" * 4, item=None)

        with patch("arcgis_item_graph.query.batch_fetch_items", return_value={}):
            q = ItemGraphQuery.__new__(ItemGraphQuery)
            q.gis = gis
            q.hydration_workers = 10
            q._hydrate_result_nodes([node])

        assert node.broken_reason == "not_found"

    def test_batch_hit_does_not_call_content_get(self):
        """When batch_fetch_items returns the item, no additional content.get call should be made."""
        import types
        from unittest.mock import MagicMock, patch
        from arcgis_item_graph.query import ItemGraphQuery

        gis = MagicMock()
        node = types.SimpleNamespace(id="aabbccdd" * 4, item=None)

        batch_item = MagicMock()
        batch_item.title = "Batch Item"
        batch_item.type = "Web Map"

        with patch("arcgis_item_graph.query.batch_fetch_items",
                   return_value={node.id: batch_item}):
            q = ItemGraphQuery.__new__(ItemGraphQuery)
            q.gis = gis
            q.hydration_workers = 10
            q._hydrate_result_nodes([node])

        gis.content.get.assert_not_called()
        assert node.item == batch_item


# ── Direction-aware traversal fixtures ────────────────────────────────────────

@pytest.fixture
def three_tier_graph():
    """Graph: App → WebMap → Layer (App references WebMap; WebMap references Layer).

    contained_by relationships (immediate upstream):
      layer.contained_by  = [webmap_id]   (WebMap references Layer)
      webmap.contained_by = [app_id]      (App references WebMap)
      app.contained_by    = []            (nothing references App)

    contains relationships (immediate downstream):
      app.contains    = [webmap_id]
      webmap.contains = [layer_id]
      layer.contains  = []
    """
    layer  = make_mock_node("id_layer",  title="My Layer",  item_type="Feature Layer",
                            contains_ids=[],
                            contained_by_ids=["id_webmap"])
    webmap = make_mock_node("id_webmap", title="My WebMap", item_type="Web Map",
                            contains_ids=["id_layer"],
                            contained_by_ids=["id_app"])
    app    = make_mock_node("id_app",    title="My App",    item_type="Dashboard",
                            contains_ids=["id_webmap"],
                            contained_by_ids=[])
    return make_mock_graph([layer, webmap, app])


@pytest.fixture
def contamination_graph():
    """Graph exposing the cross-directional contamination bug.

    X contains [A] — X's own dep (unrelated to X's impact on others)
    C contained_by X — C references X (will break if X removed)
    C contains [D]  — C's own dep (completely unrelated to X)

    Correct upstream result for query(X): {X, C}
    Buggy (old) result: {X, A, C, D}
    """
    x = make_mock_node("id_x", title="X", item_type="Web Map",
                       contains_ids=["id_a"],
                       contained_by_ids=["id_c"])
    a = make_mock_node("id_a", title="A", item_type="Feature Layer",
                       contains_ids=[],
                       contained_by_ids=["id_x"])
    c = make_mock_node("id_c", title="C", item_type="Dashboard",
                       contains_ids=["id_d"],
                       contained_by_ids=[])
    d = make_mock_node("id_d", title="D", item_type="Feature Layer",
                       contains_ids=[],
                       contained_by_ids=["id_c"])
    return make_mock_graph([x, a, c, d])


# ── _traverse_backward tests ───────────────────────────────────────────────────

@patch("arcgis_item_graph.query.load_from_file")
def test_traverse_backward_includes_upstream_items(
        mock_load, three_tier_graph, mock_gis, tmp_path):
    """upstream query of WebMap should include App (references WebMap) and
    WebMap itself, but NOT Layer (Layer is what WebMap depends on, not upstream)."""
    mock_load.return_value = three_tier_graph
    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml),
                       traversal_direction="upstream")
    result = q.query(ids=["id_webmap"])

    result_ids = {n.id for n in result.nodes}
    assert "id_webmap" in result_ids, "queried item must be in result"
    assert "id_app" in result_ids,    "App references WebMap — must appear"
    assert "id_layer" not in result_ids, \
        "Layer is WebMap's dep, not upstream — must NOT appear in upstream result"


@patch("arcgis_item_graph.query.load_from_file")
def test_traverse_backward_calls_contained_by_not_required_by(
        mock_load, three_tier_graph, mock_gis, tmp_path):
    """BFS must use contained_by() (immediate) not required_by() (recursive)."""
    mock_load.return_value = three_tier_graph
    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml),
                       traversal_direction="upstream")
    q.query(ids=["id_webmap"])

    webmap_node = three_tier_graph.get_node("id_webmap")
    webmap_node.contained_by.assert_called()
    webmap_node.required_by.assert_not_called()


@patch("arcgis_item_graph.query.load_from_file")
def test_traverse_backward_no_cross_contamination(
        mock_load, contamination_graph, mock_gis, tmp_path):
    """upstream query of X must not pull in X's own deps (A) or
    the deps of X's referencing items (D)."""
    mock_load.return_value = contamination_graph
    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml),
                       traversal_direction="upstream")
    result = q.query(ids=["id_x"])

    result_ids = {n.id for n in result.nodes}
    assert "id_x" in result_ids, "queried item must be present"
    assert "id_c" in result_ids, "C references X — should be in upstream result"
    assert "id_a" not in result_ids, "A is X's dep, not upstream — must NOT appear"
    assert "id_d" not in result_ids, "D is C's dep, unrelated to X — must NOT appear"


# ── _traverse_forward tests ────────────────────────────────────────────────────

@patch("arcgis_item_graph.query.load_from_file")
def test_traverse_forward_includes_downstream_items(
        mock_load, three_tier_graph, mock_gis, tmp_path):
    """downstream query of WebMap should include Layer (WebMap depends on it)
    but NOT App (App is upstream of WebMap, not a dependency)."""
    mock_load.return_value = three_tier_graph
    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml),
                       traversal_direction="downstream")
    result = q.query(ids=["id_webmap"])

    result_ids = {n.id for n in result.nodes}
    assert "id_webmap" in result_ids, "queried item must be in result"
    assert "id_layer" in result_ids,  "Layer is WebMap's dep — must appear"
    assert "id_app" not in result_ids, \
        "App references WebMap (upstream) — must NOT appear in downstream result"


# ── 'both' direction tests ─────────────────────────────────────────────────────

@patch("arcgis_item_graph.query.load_from_file")
def test_traverse_both_includes_all_without_cross_contamination(
        mock_load, contamination_graph, mock_gis, tmp_path):
    """'both' mode returns forward deps + backward refs of the seed,
    but must NOT expand forward deps of backward-reached items."""
    mock_load.return_value = contamination_graph
    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml),
                       traversal_direction="both")
    result = q.query(ids=["id_x"])

    result_ids = {n.id for n in result.nodes}
    assert "id_x" in result_ids, "queried item must be present"
    assert "id_a" in result_ids, "A is X's dep (downstream) — must appear in 'both'"
    assert "id_c" in result_ids, "C references X (upstream) — must appear in 'both'"
    assert "id_d" not in result_ids, \
        "D is C's dep, unrelated to X — must NOT appear even in 'both' mode"

