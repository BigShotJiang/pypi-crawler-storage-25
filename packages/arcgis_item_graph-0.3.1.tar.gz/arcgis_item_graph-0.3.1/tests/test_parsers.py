"""Tests for arcgis_item_graph/parsers.py."""
from unittest.mock import MagicMock, patch

import pytest

from arcgis_item_graph.parsers import parse_view_admin, parse_dashboard, parse_exb, augment_graph, parse_webmap


def make_item(itemid, itype="Feature Service", type_keywords=None, url=""):
    item = MagicMock()
    item.itemid = itemid
    item.type = itype
    item.typeKeywords = type_keywords or []
    item.url = url
    return item


def make_graph(node_ids=None):
    graph = MagicMock()
    nodes = []
    for nid in (node_ids or []):
        n = MagicMock()
        n.id = nid
        nodes.append(n)
    graph.all_items.return_value = nodes
    graph.get_node.return_value = None
    graph.add_item.return_value = MagicMock()
    return graph


class TestParseViewAdmin:
    def test_skips_non_view_service(self):
        item = make_item("abc" * 11, type_keywords=["Feature Service"])
        graph = make_graph()
        gis = MagicMock()
        edges = parse_view_admin(item, graph, gis)
        assert edges == []

    def test_extracts_single_source(self):
        item = make_item(
            "abc" * 11,
            type_keywords=["View Service", "Feature Service"],
            url="https://portal/server/rest/services/MyView/FeatureServer"
        )
        graph = make_graph()
        gis = MagicMock()
        gis._con.get.return_value = {
            "adminLayerInfo": {
                "viewLayerDefinition": {
                    "sourceServiceName": "MySource"
                }
            }
        }
        source_item = MagicMock()
        source_item.itemid = "src" * 11
        gis.content.search.return_value = [source_item]
        edges = parse_view_admin(item, graph, gis)
        assert len(edges) == 1
        assert edges[0] == (item.itemid, source_item.itemid, "view_admin")

    def test_extracts_joined_view_multiple_parents(self):
        item = make_item(
            "abc" * 11,
            type_keywords=["View Service", "Feature Service"],
            url="https://portal/server/rest/services/JoinedView/FeatureServer"
        )
        graph = make_graph()
        gis = MagicMock()
        gis._con.get.return_value = {
            "adminLayerInfo": {
                "viewLayerDefinition": {
                    "table": {
                        "relatedTables": [
                            {"sourceServiceName": "Parent1"},
                            {"sourceServiceName": "Parent2"},
                        ]
                    }
                }
            }
        }
        parent1 = MagicMock()
        parent1.itemid = "par" * 11
        parent2 = MagicMock()
        parent2.itemid = "pr2" * 11
        gis.content.search.side_effect = [[parent1], [parent2]]
        edges = parse_view_admin(item, graph, gis)
        assert len(edges) == 2

    def test_skips_when_search_returns_empty(self):
        item = make_item(
            "abc" * 11,
            type_keywords=["View Service"],
            url="https://portal/server/rest/services/V/FeatureServer"
        )
        graph = make_graph()
        gis = MagicMock()
        gis._con.get.return_value = {
            "adminLayerInfo": {"viewLayerDefinition": {"sourceServiceName": "Unknown"}}
        }
        gis.content.search.return_value = []
        edges = parse_view_admin(item, graph, gis)
        assert edges == []

    def test_returns_empty_on_admin_endpoint_error(self):
        item = make_item(
            "abc" * 11,
            type_keywords=["View Service"],
            url="https://portal/rest/services/V/FeatureServer"
        )
        graph = make_graph()
        gis = MagicMock()
        gis._con.get.side_effect = Exception("403 Forbidden")
        edges = parse_view_admin(item, graph, gis)
        assert edges == []


class TestParseDashboard:
    def test_skips_non_dashboard(self):
        item = make_item("abc" * 11, itype="Web Map")
        graph = make_graph()
        gis = MagicMock()
        edges = parse_dashboard(item, graph, gis)
        assert edges == []

    def test_extracts_widget_item_ids(self):
        item = make_item("aaa" * 11, itype="Dashboard")
        item.get_data.return_value = {
            "widgets": [
                {"itemId": "b" * 32},
                {"datasets": [{"dataSource": {"itemId": "c" * 32}}]},
            ]
        }
        graph = make_graph()
        gis = MagicMock()
        edges = parse_dashboard(item, graph, gis)
        child_ids = {e[1] for e in edges}
        assert "b" * 32 in child_ids
        assert "c" * 32 in child_ids
        assert all(e[2] == "dashboard_widget" for e in edges)

    def test_skips_self_reference(self):
        item_id = "a" * 32
        item = make_item(item_id, itype="Dashboard")
        item.get_data.return_value = {"widgets": [{"itemId": item_id}]}
        graph = make_graph()
        gis = MagicMock()
        edges = parse_dashboard(item, graph, gis)
        assert edges == []

    def test_skips_already_in_graph(self):
        known_id = "b" * 32
        item = make_item("a" * 32, itype="Dashboard")
        item.get_data.return_value = {"widgets": [{"itemId": known_id}]}
        graph = make_graph(node_ids=[known_id])
        gis = MagicMock()
        edges = parse_dashboard(item, graph, gis)
        assert edges == []

    def test_returns_empty_on_get_data_failure(self):
        item = make_item("a" * 32, itype="Dashboard")
        item.get_data.side_effect = Exception("Network error")
        graph = make_graph()
        gis = MagicMock()
        edges = parse_dashboard(item, graph, gis)
        assert edges == []


class TestParseExb:
    def test_skips_non_exb(self):
        item = make_item("a" * 32, itype="Web Map")
        graph = make_graph()
        gis = MagicMock()
        edges = parse_exb(item, graph, gis)
        assert edges == []

    def test_extracts_data_source_item_ids(self):
        item = make_item("a" * 32, itype="Web Experience")
        item.get_data.return_value = {
            "dataSources": {"ds1": {"itemId": "b" * 32}},
            "widgets": {"w1": {"useDataSources": [{"dataSourceId": "c" * 32}]}},
        }
        item.resources = MagicMock()
        item.resources.list.return_value = []
        graph = make_graph()
        gis = MagicMock()
        edges = parse_exb(item, graph, gis)
        child_ids = {e[1] for e in edges}
        assert "b" * 32 in child_ids
        assert "c" * 32 in child_ids
        assert all(e[2] == "exb_widget" for e in edges)

    def test_extracts_from_config_resource(self):
        item = make_item("a" * 32, itype="Web Experience")
        item.get_data.return_value = {}
        item.resources = MagicMock()
        item.resources.list.return_value = [{"resource": "config/config.json"}]
        item.resources.get.return_value = {
            "dataSources": {"ds1": {"itemId": "d" * 32}}
        }
        graph = make_graph()
        gis = MagicMock()
        edges = parse_exb(item, graph, gis)
        assert any(e[1] == "d" * 32 for e in edges)

    def test_returns_empty_on_failure(self):
        item = make_item("a" * 32, itype="Web Experience")
        item.get_data.side_effect = Exception("error")
        item.resources = MagicMock()
        item.resources.list.side_effect = Exception("error")
        graph = make_graph()
        gis = MagicMock()
        edges = parse_exb(item, graph, gis)
        assert edges == []


class TestAugmentGraph:
    def test_augment_graph_calls_all_parsers_without_raising(self):
        """augment_graph must not raise even on parser errors."""
        items = [make_item("a" * 32, itype="Dashboard")]
        items[0].get_data.return_value = {}
        graph = make_graph()
        gis = MagicMock()
        augment_graph(graph, items, gis)  # Should not raise

    def test_augment_graph_writes_to_cache(self, tmp_path):
        import sqlite3
        from arcgis_item_graph.cache import MetadataCache
        db = str(tmp_path / "meta.sqlite")
        cache = MetadataCache(db)

        item = make_item("a" * 32, itype="Dashboard")
        item.get_data.return_value = {"widgets": [{"itemId": "b" * 32}]}
        graph = make_graph()
        gis = MagicMock()

        augment_graph(graph, [item], gis, cache=cache)

        conn = sqlite3.connect(db)
        rows = conn.execute("SELECT * FROM relationships WHERE source = 'dashboard_widget'").fetchall()
        conn.close()
        cache.close()
        assert len(rows) == 1


class TestParseWebmap:
    # Valid 32-char lowercase hex IDs used across all TestParseWebmap tests
    WEBMAP_ID = "abcdef1234567890abcdef1234567890"
    LAYER_ID   = "11111111111111111111111111111111"
    CHILD_ID   = "22222222222222222222222222222222"
    BASEMAP_ID = "33333333333333333333333333333333"
    TABLE_ID   = "44444444444444444444444444444444"

    def _make_item(self, item_type="Web Map", item_id=None):
        item = MagicMock()
        item.type = item_type
        item.itemid = item_id if item_id is not None else self.WEBMAP_ID
        return item

    def test_flat_operational_layers_item_id(self):
        """Extracts itemId from flat operationalLayers."""
        item = self._make_item()
        item.get_data.return_value = {
            "operationalLayers": [
                {"itemId": self.LAYER_ID, "url": "https://s/FS/0"},
            ]
        }
        edges = parse_webmap(item, MagicMock(), MagicMock())
        ids = [(p, c) for p, c, _ in edges]
        assert (self.WEBMAP_ID, self.LAYER_ID) in ids

    def test_flat_operational_layers_url_only(self):
        """Extracts url from layers that have no itemId."""
        item = self._make_item()
        item.get_data.return_value = {
            "operationalLayers": [{"url": "https://s/MS/0"}]
        }
        edges = parse_webmap(item, MagicMock(), MagicMock())
        ids = [(p, c) for p, c, _ in edges]
        assert (self.WEBMAP_ID, "https://s/MS/0") in ids

    def test_nested_group_layer_children(self):
        """Recurses into group layer .layers[] children."""
        item = self._make_item()
        item.get_data.return_value = {
            "operationalLayers": [
                {
                    "layerType": "GroupLayer",
                    "layers": [
                        {"itemId": self.CHILD_ID},
                        {"url": "https://s/child/FS/0"},
                    ]
                }
            ]
        }
        edges = parse_webmap(item, MagicMock(), MagicMock())
        ids = [(p, c) for p, c, _ in edges]
        assert (self.WEBMAP_ID, self.CHILD_ID) in ids
        assert (self.WEBMAP_ID, "https://s/child/FS/0") in ids

    def test_basemap_layers(self):
        """Extracts references from baseMap.baseMapLayers."""
        item = self._make_item()
        item.get_data.return_value = {
            "baseMap": {
                "baseMapLayers": [
                    {"itemId": self.BASEMAP_ID},
                ]
            }
        }
        edges = parse_webmap(item, MagicMock(), MagicMock())
        ids = [(p, c) for p, c, _ in edges]
        assert (self.WEBMAP_ID, self.BASEMAP_ID) in ids

    def test_tables(self):
        """Extracts references from tables[]."""
        item = self._make_item()
        item.get_data.return_value = {
            "tables": [{"itemId": self.TABLE_ID}]
        }
        edges = parse_webmap(item, MagicMock(), MagicMock())
        ids = [(p, c) for p, c, _ in edges]
        assert (self.WEBMAP_ID, self.TABLE_ID) in ids

    def test_skips_non_webmap_items(self):
        """Returns [] for non-Web Map item types."""
        item = self._make_item(item_type="Dashboard")
        edges = parse_webmap(item, MagicMock(), MagicMock())
        assert edges == []

    def test_handles_get_data_returns_none(self):
        """Returns [] gracefully when get_data() returns None."""
        item = self._make_item()
        item.get_data.return_value = None
        edges = parse_webmap(item, MagicMock(), MagicMock())
        assert edges == []
