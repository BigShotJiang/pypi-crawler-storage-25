"""Tests for arcgis_item_graph/cache.py — MetadataCache."""
import sqlite3
import time
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from arcgis_item_graph.cache import MetadataCache


@pytest.fixture
def tmp_db(tmp_path):
    return str(tmp_path / "test_meta.sqlite")


@pytest.fixture
def cache(tmp_db):
    c = MetadataCache(tmp_db)
    yield c
    c.close()


def make_mock_item(itemid="abc" * 10 + "ab", title="Test Item",
                   itype="Web Map", owner="jsmith", access="org"):
    item = MagicMock()
    item.itemid = itemid
    item.title = title
    item.type = itype
    item.owner = owner
    item.access = access
    item.modified = 1700000000000
    item.created = 1600000000000
    item.content_status = ""
    item.protected = False
    item.numViews = 42
    item.size = 1024
    item.url = ""
    return item


def make_mock_node(itemid, item=None):
    node = MagicMock()
    node.id = itemid
    node.item = item
    node.contains.return_value = []
    return node


class TestMetadataCacheSchema:
    def test_creates_all_tables(self, tmp_db):
        cache = MetadataCache(tmp_db)
        conn = sqlite3.connect(tmp_db)
        tables = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()}
        conn.close()
        cache.close()
        assert {"items", "relationships", "health", "run_metrics"} <= tables

    def test_idempotent_creation(self, tmp_db):
        """Creating MetadataCache twice on same db does not raise."""
        c1 = MetadataCache(tmp_db)
        c1.close()
        c2 = MetadataCache(tmp_db)
        c2.close()


class TestMetadataCacheBuild:
    def test_build_populates_items(self, cache):
        item = make_mock_item()
        node = make_mock_node(item.itemid, item)
        graph = MagicMock()
        graph.all_items.return_value = [node]
        cache.build(graph, [item])
        result = cache.get_item(item.itemid)
        assert result is not None
        assert result["title"] == "Test Item"
        assert result["owner"] == "jsmith"

    def test_build_marks_broken_nodes(self, cache):
        broken_node = make_mock_node("broken123", item=None)
        graph = MagicMock()
        graph.all_items.return_value = [broken_node]
        cache.build(graph, [])
        assert "broken123" in cache.broken_nodes()

    def test_build_populates_relationships(self, cache):
        parent_item = make_mock_item("aaa" * 10 + "aa")
        child_item = make_mock_item("bbb" * 10 + "bb")
        child_node = make_mock_node(child_item.itemid, child_item)
        parent_node = make_mock_node(parent_item.itemid, parent_item)
        parent_node.contains.return_value = [child_node]
        graph = MagicMock()
        graph.all_items.return_value = [parent_node, child_node]
        cache.build(graph, [parent_item, child_item])
        fanout = cache.fanout(child_item.itemid)
        assert fanout == 1

    def test_build_clears_previous_data(self, cache):
        item1 = make_mock_item("aaa" * 10 + "aa", title="Old")
        node1 = make_mock_node(item1.itemid, item1)
        graph1 = MagicMock()
        graph1.all_items.return_value = [node1]
        cache.build(graph1, [item1])

        item2 = make_mock_item("bbb" * 10 + "bb", title="New")
        node2 = make_mock_node(item2.itemid, item2)
        graph2 = MagicMock()
        graph2.all_items.return_value = [node2]
        cache.build(graph2, [item2])

        assert cache.get_item(item1.itemid) is None
        assert cache.get_item(item2.itemid) is not None


class TestMetadataCacheRead:
    def test_get_item_returns_none_for_missing(self, cache):
        assert cache.get_item("nonexistent") is None

    def test_get_health_returns_ok_for_healthy(self, cache):
        item = make_mock_item()
        node = make_mock_node(item.itemid, item)
        graph = MagicMock()
        graph.all_items.return_value = [node]
        cache.build(graph, [item])
        assert cache.get_health(item.itemid) == "ok"

    def test_fanout_zero_for_root_item(self, cache):
        item = make_mock_item()
        node = make_mock_node(item.itemid, item)
        graph = MagicMock()
        graph.all_items.return_value = [node]
        cache.build(graph, [item])
        assert cache.fanout(item.itemid) == 0

    def test_broken_nodes_empty_when_all_healthy(self, cache):
        item = make_mock_item()
        node = make_mock_node(item.itemid, item)
        graph = MagicMock()
        graph.all_items.return_value = [node]
        cache.build(graph, [item])
        assert cache.broken_nodes() == []

    def test_orphan_candidates_excludes_items_with_dependents(self, cache):
        parent_item = make_mock_item("aaa" * 10 + "aa")
        child_item = make_mock_item("bbb" * 10 + "bb")
        child_node = make_mock_node(child_item.itemid, child_item)
        parent_node = make_mock_node(parent_item.itemid, parent_item)
        parent_node.contains.return_value = [child_node]
        graph = MagicMock()
        graph.all_items.return_value = [parent_node, child_node]
        cache.build(graph, [parent_item, child_item])
        orphans = cache.orphan_candidates(days_inactive=0)
        orphan_ids = [o["id"] for o in orphans]
        assert child_item.itemid not in orphan_ids


class TestMetadataCacheRunMetrics:
    def test_record_run_inserts_row(self, cache):
        cache.record_run("create", int(time.time() * 1000), 100, 500, 3)
        conn = sqlite3.connect(str(cache._path))
        rows = conn.execute("SELECT * FROM run_metrics").fetchall()
        conn.close()
        assert len(rows) == 1
        assert rows[0][1] == "create"
