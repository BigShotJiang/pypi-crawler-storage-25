# tests/test_reporter.py
from unittest.mock import MagicMock
import pytest
import pandas as pd
from arcgis_item_graph.reporter import ItemGraphReporter
from arcgis_item_graph.query import QueryResult
from tests.conftest import make_mock_node, make_mock_graph, make_mock_unhydrated_node


@pytest.fixture
def simple_result():
    """QueryResult with two nodes: node_a (queried) contains node_b (dependency)."""
    node_a = make_mock_node(
        "id_a", title="My Dashboard", item_type="Dashboard",
        owner="jsmith", contains_ids=["id_b"], required_by_ids=[]
    )
    node_b = make_mock_node(
        "id_b", title="Base Map", item_type="Web Map",
        owner="esri", contains_ids=[], required_by_ids=["id_a"]
    )
    graph = make_mock_graph([node_a, node_b])
    return QueryResult(
        nodes=[node_a, node_b],
        graph=graph,
        queried_ids={"id_a"},
    )


@pytest.fixture
def empty_result():
    """QueryResult with zero nodes and zero edges."""
    return QueryResult(
        nodes=[],
        graph=make_mock_graph([]),
        queried_ids=set(),
    )


@pytest.fixture
def not_in_result_result():
    """QueryResult where node_a references id_x via contains but id_x is absent from result.nodes."""
    node_a = make_mock_node(
        "id_a", title="My Dashboard", item_type="Dashboard",
        owner="jsmith", contains_ids=["id_x"], required_by_ids=[]
    )
    graph = make_mock_graph([node_a])
    return QueryResult(
        nodes=[node_a],
        graph=graph,
        queried_ids={"id_a"},
    )


@pytest.fixture
def broken_result():
    """QueryResult where node_a contains node_b (healthy) and node_c (broken)."""
    node_a = make_mock_node(
        "id_a", title="My Dashboard", item_type="Dashboard",
        owner="jsmith", contains_ids=["id_b", "id_c"]
    )
    node_b = make_mock_node(
        "id_b", title="Base Map", item_type="Web Map",
        owner="esri", contains_ids=[]
    )
    node_c = make_mock_unhydrated_node("id_c")  # broken — could not be hydrated
    graph = make_mock_graph([node_a, node_b, node_c])
    return QueryResult(
        nodes=[node_a, node_b, node_c],
        graph=graph,
        queried_ids={"id_a"},
    )


# ── to_dataframe ─────────────────────────────────────────────────────────────

def test_to_dataframe_returns_dataframe(simple_result):
    """to_dataframe() should return a pandas DataFrame."""
    reporter = ItemGraphReporter(simple_result)
    df = reporter.to_dataframe()
    assert isinstance(df, pd.DataFrame)


def test_to_dataframe_has_expected_columns(simple_result):
    """DataFrame should contain all required columns including status."""
    reporter = ItemGraphReporter(simple_result)
    df = reporter.to_dataframe()
    expected_cols = {
        "item_id", "title", "type", "owner", "status",
        "contains_count", "required_by_count",
        "direct_dependencies", "queried_item",
    }
    assert expected_cols.issubset(set(df.columns))


def test_to_dataframe_queried_item_flag(simple_result):
    """queried_item column should be True only for explicitly queried items."""
    reporter = ItemGraphReporter(simple_result)
    df = reporter.to_dataframe()
    assert df.loc[df["item_id"] == "id_a", "queried_item"].iloc[0] == True
    assert df.loc[df["item_id"] == "id_b", "queried_item"].iloc[0] == False


def test_to_dataframe_counts(simple_result):
    """contains_count and required_by_count should match mock node data."""
    reporter = ItemGraphReporter(simple_result)
    df = reporter.to_dataframe()
    row_a = df[df["item_id"] == "id_a"].iloc[0]
    assert row_a["contains_count"] == 1
    assert row_a["required_by_count"] == 0


def test_to_dataframe_status_healthy(simple_result):
    """Hydrated nodes should have status='healthy'."""
    reporter = ItemGraphReporter(simple_result)
    df = reporter.to_dataframe()
    assert (df["status"] == "healthy").all()


def test_to_dataframe_status_broken(broken_result):
    """Unhydrated nodes (item=None) should have status='broken'."""
    reporter = ItemGraphReporter(broken_result)
    df = reporter.to_dataframe()
    row_c = df[df["item_id"] == "id_c"].iloc[0]
    assert row_c["status"] == "broken"
    # Other nodes should still be healthy
    row_a = df[df["item_id"] == "id_a"].iloc[0]
    assert row_a["status"] == "healthy"


# ── to_csv ────────────────────────────────────────────────────────────────────

def test_to_csv_writes_file(simple_result, tmp_path):
    """to_csv() should write a CSV file at the given path."""
    reporter = ItemGraphReporter(simple_result)
    out = tmp_path / "report.csv"
    reporter.to_csv(str(out))
    assert out.exists()
    df = pd.read_csv(str(out))
    assert len(df) == 2


# ── to_excel ─────────────────────────────────────────────────────────────────

def test_to_excel_writes_file(simple_result, tmp_path):
    """to_excel() should write an .xlsx file at the given path."""
    reporter = ItemGraphReporter(simple_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    assert out.exists()


def test_to_excel_has_three_sheets(simple_result, tmp_path):
    """to_excel() workbook should contain All Items, Dependency Edges, and Broken Dependencies sheets."""
    reporter = ItemGraphReporter(simple_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    xl = pd.ExcelFile(str(out))
    assert "All Items" in xl.sheet_names
    assert "Dependency Edges" in xl.sheet_names
    assert "Broken Dependencies" in xl.sheet_names


def test_to_excel_all_items_row_count(simple_result, tmp_path):
    """All Items sheet should have one row per node."""
    reporter = ItemGraphReporter(simple_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    df = pd.read_excel(str(out), sheet_name="All Items")
    assert len(df) == 2


def test_to_excel_dependency_edges_columns(simple_result, tmp_path):
    """Dependency Edges sheet should include source, dep, and dep_status columns."""
    reporter = ItemGraphReporter(simple_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    df = pd.read_excel(str(out), sheet_name="Dependency Edges")
    for col in ("source_id", "source_title", "dep_id", "dep_title", "dep_type", "dep_status"):
        assert col in df.columns, f"Missing column: {col}"


def test_to_excel_dependency_edge_status_healthy(simple_result, tmp_path):
    """Healthy deps (hydrated node_b) should have dep_status='healthy'."""
    reporter = ItemGraphReporter(simple_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    df = pd.read_excel(str(out), sheet_name="Dependency Edges")
    # node_a contains node_b; node_b is hydrated → healthy
    assert len(df) == 1
    assert df.iloc[0]["source_id"] == "id_a"
    assert df.iloc[0]["dep_id"] == "id_b"
    assert df.iloc[0]["dep_status"] == "healthy"


def test_to_excel_broken_dependencies_sheet(broken_result, tmp_path):
    """Broken Dependencies sheet should contain only edges where dep_status='broken'."""
    reporter = ItemGraphReporter(broken_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    df_broken = pd.read_excel(str(out), sheet_name="Broken Dependencies")
    df_edges  = pd.read_excel(str(out), sheet_name="Dependency Edges")
    # Only the id_c dep is broken
    assert len(df_broken) == 1
    assert df_broken.iloc[0]["dep_id"] == "id_c"
    assert df_broken.iloc[0]["dep_status"] == "broken"
    # Edges sheet should have both id_b (healthy) and id_c (broken)
    assert len(df_edges) == 2


def test_to_excel_broken_dep_title_is_null(broken_result, tmp_path):
    """Broken dep entries should have null dep_title since item data is missing."""
    reporter = ItemGraphReporter(broken_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    df_edges = pd.read_excel(str(out), sheet_name="Dependency Edges")
    broken_row = df_edges[df_edges["dep_id"] == "id_c"].iloc[0]
    assert pd.isna(broken_row["dep_title"])


def test_to_excel_all_items_no_direct_dependencies_column(simple_result, tmp_path):
    """All Items sheet should not have a direct_dependencies column (not Excel-friendly)."""
    reporter = ItemGraphReporter(simple_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    df = pd.read_excel(str(out), sheet_name="All Items")
    assert "direct_dependencies" not in df.columns


def test_to_excel_empty_result(empty_result, tmp_path):
    """to_excel() with zero nodes should write a valid file with correct edge columns and zero data rows."""
    reporter = ItemGraphReporter(empty_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    assert out.exists()
    df_items = pd.read_excel(str(out), sheet_name="All Items")
    df_edges = pd.read_excel(str(out), sheet_name="Dependency Edges")
    df_broken = pd.read_excel(str(out), sheet_name="Broken Dependencies")
    assert len(df_items) == 0
    assert len(df_edges) == 0
    assert len(df_broken) == 0
    for col in ("source_id", "dep_id", "dep_status"):
        assert col in df_edges.columns, f"Missing column in Dependency Edges: {col}"
        assert col in df_broken.columns, f"Missing column in Broken Dependencies: {col}"


def test_to_excel_bytes_returns_valid_xlsx(simple_result):
    """to_excel_bytes() returns bytes that constitute a valid xlsx workbook."""
    reporter = ItemGraphReporter(simple_result)
    data = reporter.to_excel_bytes()
    assert isinstance(data, bytes)
    # xlsx files are ZIP archives; magic bytes are PK\x03\x04
    assert data[:4] == b"PK\x03\x04", "Expected xlsx (ZIP) magic bytes"
    # Round-trip: read back the bytes and verify sheet names / content
    import io
    df_items = pd.read_excel(io.BytesIO(data), sheet_name="All Items")
    df_edges = pd.read_excel(io.BytesIO(data), sheet_name="Dependency Edges")
    df_broken = pd.read_excel(io.BytesIO(data), sheet_name="Broken Dependencies")
    assert len(df_items) >= 1
    assert "item_id" in df_items.columns
    assert "dep_status" in df_edges.columns or len(df_edges) == 0


def test_to_excel_bytes_matches_to_excel(simple_result, tmp_path):
    """to_excel_bytes() produces identical sheet shapes as to_excel()."""
    import io
    reporter = ItemGraphReporter(simple_result)
    file_path = str(tmp_path / "report.xlsx")
    reporter.to_excel(file_path)
    buf_bytes = reporter.to_excel_bytes()

    df_file  = pd.read_excel(file_path,           sheet_name="All Items")
    df_bytes = pd.read_excel(io.BytesIO(buf_bytes), sheet_name="All Items")
    assert list(df_file.columns) == list(df_bytes.columns)
    assert len(df_file) == len(df_bytes)


def test_to_excel_dep_status_not_in_result(not_in_result_result, tmp_path):
    """A dep_id present in contains but absent from result.nodes should have dep_status='not_in_result'."""
    reporter = ItemGraphReporter(not_in_result_result)
    out = tmp_path / "report.xlsx"
    reporter.to_excel(str(out))
    df = pd.read_excel(str(out), sheet_name="Dependency Edges")
    assert len(df) == 1
    assert df.iloc[0]["dep_id"] == "id_x"
    assert df.iloc[0]["dep_status"] == "not_in_result"


def test_to_excel_does_not_call_contains_twice(tmp_path):
    """node.contains() should be called once per node, not twice (DataFrame + edge sheet)."""
    from arcgis_item_graph.reporter import ItemGraphReporter
    from arcgis_item_graph.query import QueryResult
    from tests.conftest import make_mock_node, make_mock_graph

    node_a = make_mock_node("aaa", contains_ids=["bbb"])
    node_b = make_mock_node("bbb", contains_ids=[])
    graph = make_mock_graph([node_a, node_b])

    result = QueryResult(
        nodes=[node_a, node_b],
        graph=graph,
        queried_ids={"aaa"},
    )

    reporter = ItemGraphReporter(result)
    reporter.to_excel(str(tmp_path / "out.xlsx"))

    # Each node.contains() should be called exactly once (from to_dataframe())
    # If called twice, call_count would be 2 per node.
    assert node_a.contains.call_count == 1, (
        f"node_a.contains called {node_a.contains.call_count} times; expected 1"
    )
    assert node_b.contains.call_count == 1, (
        f"node_b.contains called {node_b.contains.call_count} times; expected 1"
    )


def test_to_dataframe_includes_broken_reason_column():
    """to_dataframe() must include a broken_reason column populated for broken nodes."""
    from arcgis_item_graph.reporter import ItemGraphReporter
    from arcgis_item_graph.query import QueryResult
    from tests.conftest import make_mock_node, make_mock_graph

    node = make_mock_node("aaa", contains_ids=[])
    node.item = None
    node.broken_reason = "deleted"

    graph = make_mock_graph([node])
    result = QueryResult(nodes=[node], graph=graph, queried_ids={"aaa"})

    df = ItemGraphReporter(result).to_dataframe()

    assert "broken_reason" in df.columns
    assert df.loc[df["item_id"] == "aaa", "broken_reason"].iloc[0] == "deleted"


def test_to_dataframe_includes_deprecated_column():
    """to_dataframe() must include a deprecated column populated for hydrated nodes."""
    from arcgis_item_graph.reporter import ItemGraphReporter
    from arcgis_item_graph.query import QueryResult
    from tests.conftest import make_mock_node, make_mock_graph
    from unittest.mock import MagicMock

    node = make_mock_node("bbb", contains_ids=[])
    mock_item = MagicMock()
    mock_item.title = "My Layer"
    mock_item.type = "Feature Service"
    mock_item.owner = "testuser"
    node.item = mock_item
    node.deprecated = True

    graph = make_mock_graph([node])
    result = QueryResult(nodes=[node], graph=graph, queried_ids={"bbb"})

    df = ItemGraphReporter(result).to_dataframe()

    assert "deprecated" in df.columns
    assert df.loc[df["item_id"] == "bbb", "deprecated"].iloc[0] == True


# ── New tests for url-normalization-hydration-perf ─────────────────────────

import io as _io
import openpyxl as _openpyxl


class TestIdTypeColumn:
    """id_type column appears in All Items sheet."""

    def test_to_dataframe_has_id_type_column(self):
        from arcgis_item_graph.query import QueryResult
        from tests.conftest import make_mock_node, make_mock_graph
        node = make_mock_node("abc123def456abc123def456abc123de")
        graph = make_mock_graph([node])
        result = QueryResult(nodes=[node], graph=graph)
        df = ItemGraphReporter(result).to_dataframe()
        assert "id_type" in df.columns

    def test_portal_id_classified_correctly(self):
        from arcgis_item_graph.query import QueryResult
        from tests.conftest import make_mock_node, make_mock_graph
        node = make_mock_node("abc123def456abc123def456abc123de")
        graph = make_mock_graph([node])
        result = QueryResult(nodes=[node], graph=graph)
        df = ItemGraphReporter(result).to_dataframe()
        assert (df["id_type"] == "portal_id").all()


class TestExternalReferencesSheet:
    """Excel workbook has a 4th sheet for URL-type dependencies."""

    def _wb(self, raw: bytes):
        return _openpyxl.load_workbook(_io.BytesIO(raw))

    def test_sheet_exists(self):
        from arcgis_item_graph.query import QueryResult
        from tests.conftest import make_mock_node, make_mock_graph
        node = make_mock_node("abc123def456abc123def456abc123de")
        graph = make_mock_graph([node])
        result = QueryResult(nodes=[node], graph=graph)
        wb = self._wb(ItemGraphReporter(result).to_excel_bytes())
        assert "External References" in wb.sheetnames

    def test_external_refs_sheet_has_expected_columns(self):
        from arcgis_item_graph.query import QueryResult
        from tests.conftest import make_mock_node, make_mock_graph
        node = make_mock_node("abc123def456abc123def456abc123de")
        graph = make_mock_graph([node])
        result = QueryResult(nodes=[node], graph=graph)
        wb = self._wb(ItemGraphReporter(result).to_excel_bytes())
        ws = wb["External References"]
        headers = [cell.value for cell in ws[1]]
        assert "url" in headers
        assert "url_type" in headers
        assert "referenced_by_count" in headers
        assert "referenced_by_titles" in headers


class TestBrokenDependenciesIncludesUrls:
    """Broken Dependencies sheet must include URL-type dep_ids (Task 3 behavior)."""

    def _wb(self, raw: bytes):
        return _openpyxl.load_workbook(_io.BytesIO(raw))

    def test_url_dep_included_in_broken(self):
        """A URL-type dep_id that is unhydrated (item=None) must appear in Broken Dependencies."""
        from arcgis_item_graph.query import QueryResult
        from tests.conftest import make_mock_node, make_mock_graph
        from unittest.mock import MagicMock

        url_dep = "https://services.arcgis.com/org/ArcGIS/rest/services/Roads/FeatureServer/0"
        node = make_mock_node("aabbccdd" * 4)
        node.contains = MagicMock(return_value=[url_dep])
        node.required_by = MagicMock(return_value=[])

        # Include url_dep as unhydrated node — should now appear in Broken Dependencies
        url_node = MagicMock()
        url_node.id = url_dep
        url_node.item = None
        url_node.contains = MagicMock(return_value=[])
        url_node.required_by = MagicMock(return_value=[])

        graph = make_mock_graph([node, url_node])
        result = QueryResult(nodes=[node, url_node], graph=graph)
        wb = self._wb(ItemGraphReporter(result).to_excel_bytes())

        broken_ws = wb["Broken Dependencies"]
        dep_ids = [broken_ws.cell(row=r, column=5).value for r in range(2, broken_ws.max_row + 1)]
        assert url_dep in dep_ids, "URL dep_id must appear in Broken Dependencies"


# ── Audit Diff Excel sheet tests ──────────────────────────────────────────────

from arcgis_item_graph.auditor import AuditReport, NodeDiff


class TestExcelAuditSheet:
    def _simple_result(self):
        node = make_mock_node("id_a", title="Item A", item_type="Web Map",
                              owner="user")
        result = MagicMock()
        result.nodes = [node]
        result.graph = make_mock_graph([node])
        return result

    def test_audit_diff_sheet_absent_when_no_report(self, tmp_path):
        """to_excel() without audit_report produces no 'Audit Diff' sheet."""
        import openpyxl
        reporter = ItemGraphReporter(self._simple_result())
        path = str(tmp_path / "report.xlsx")
        reporter.to_excel(path)
        wb = openpyxl.load_workbook(path)
        assert "Audit Diff" not in wb.sheetnames

    def test_audit_diff_sheet_present_with_report(self, tmp_path):
        """to_excel(audit_report=...) adds an 'Audit Diff' sheet."""
        import openpyxl
        diff = NodeDiff(
            node_id="id_a", node_title="Item A",
            api_only={"missing_dep"}, graph_only={"phantom_dep"},
        )
        report = AuditReport(diffs=[diff])
        reporter = ItemGraphReporter(self._simple_result())
        path = str(tmp_path / "report.xlsx")
        reporter.to_excel(path, audit_report=report)
        wb = openpyxl.load_workbook(path)
        assert "Audit Diff" in wb.sheetnames

    def test_audit_diff_sheet_columns(self, tmp_path):
        """Audit Diff sheet has correct column headers."""
        import openpyxl
        diff = NodeDiff(node_id="id_a", node_title="Item A", api_only={"dep1"})
        report = AuditReport(diffs=[diff])
        reporter = ItemGraphReporter(self._simple_result())
        path = str(tmp_path / "report.xlsx")
        reporter.to_excel(path, audit_report=report)
        wb = openpyxl.load_workbook(path)
        ws = wb["Audit Diff"]
        headers = [ws.cell(1, c).value for c in range(1, 5)]
        assert "node_id" in headers
        assert "node_title" in headers
        assert "direction" in headers
        assert "neighbor_id" in headers

    def test_audit_diff_sheet_rows(self, tmp_path):
        """Each api_only/graph_only edge becomes a row with correct direction."""
        import openpyxl
        diff = NodeDiff(
            node_id="id_a", node_title="Item A",
            api_only={"missing_dep"}, graph_only={"phantom_dep"},
        )
        report = AuditReport(diffs=[diff])
        reporter = ItemGraphReporter(self._simple_result())
        path = str(tmp_path / "report.xlsx")
        reporter.to_excel(path, audit_report=report)
        wb = openpyxl.load_workbook(path)
        ws = wb["Audit Diff"]
        rows = [[ws.cell(r, c).value for c in range(1, 5)]
                for r in range(2, ws.max_row + 1)]
        directions = [row[2] for row in rows]
        assert "missing_from_graph" in directions
        assert "extra_in_graph" in directions

    def test_audit_diff_empty_report_no_rows(self, tmp_path):
        """AuditReport with no diffs produces sheet with only headers."""
        import openpyxl
        reporter = ItemGraphReporter(self._simple_result())
        path = str(tmp_path / "report.xlsx")
        reporter.to_excel(path, audit_report=AuditReport())
        wb = openpyxl.load_workbook(path)
        ws = wb["Audit Diff"]
        assert ws.max_row == 1


class TestUrlDepsInBrokenDependencies:
    """URL-type broken deps are included in the Broken Dependencies sheet."""

    def _result_with_url_dep(self):
        """QueryResult: web map → unresolved service URL dep."""
        url_dep_id = "https://portal/rest/services/Hosted/Roads/FeatureServer"
        web_map_id = "a" * 32

        web_map_node = make_mock_node(
            web_map_id,
            title="My Map",
            item_type="Web Map",
            contains_ids=[url_dep_id],
        )
        url_node = make_mock_unhydrated_node(url_dep_id)
        url_node.contains = MagicMock(return_value=[])
        url_node.required_by = MagicMock(return_value=[])

        return QueryResult(
            nodes=[web_map_node, url_node],
            graph=make_mock_graph([web_map_node, url_node]),
            queried_ids={web_map_id},
        )

    def test_url_dep_appears_in_broken_dependencies_sheet(self):
        result = self._result_with_url_dep()
        _, _, df_broken, _ = ItemGraphReporter(result)._build_excel_data()

        assert not df_broken.empty
        url = "https://portal/rest/services/Hosted/Roads/FeatureServer"
        assert url in df_broken["dep_id"].values

    def test_url_dep_has_service_name_as_dep_title(self):
        result = self._result_with_url_dep()
        _, df_edges, _, _ = ItemGraphReporter(result)._build_excel_data()

        url = "https://portal/rest/services/Hosted/Roads/FeatureServer"
        row = df_edges[df_edges["dep_id"] == url].iloc[0]
        assert row["dep_title"] == "Roads/FeatureServer"
        assert row["dep_type"] == "Service URL"

    def test_resolved_url_dep_shows_item_metadata(self):
        """After Task-2 resolution, URL node with .item set → healthy dep with real title."""
        url_dep_id = "https://portal/rest/services/Hosted/Roads/FeatureServer"
        web_map_id = "b" * 32

        web_map_node = make_mock_node(
            web_map_id,
            title="My Map",
            item_type="Web Map",
            contains_ids=[url_dep_id],
        )
        # URL node was resolved in Task 2 — has a real item now
        url_node = make_mock_node(
            url_dep_id,
            title="Roads Feature Layer",
            item_type="Feature Layer Collection",
            contains_ids=[],
        )

        result = QueryResult(
            nodes=[web_map_node, url_node],
            graph=make_mock_graph([web_map_node, url_node]),
            queried_ids={web_map_id},
        )
        _, df_edges, df_broken, _ = ItemGraphReporter(result)._build_excel_data()

        row = df_edges[df_edges["dep_id"] == url_dep_id].iloc[0]
        assert row["dep_title"] == "Roads Feature Layer"
        assert row["dep_type"] == "Feature Layer Collection"
        assert row["dep_status"] == "healthy"
        # Resolved URL dep is healthy → should NOT appear in broken sheet
        assert url_dep_id not in df_broken["dep_id"].values

    def test_portal_id_broken_dep_still_in_broken_sheet(self):
        """Portal ID broken deps continue to appear (no regression)."""
        broken_dep_id = "c" * 32
        parent_id = "d" * 32

        parent_node = make_mock_node(
            parent_id,
            title="Parent",
            item_type="Dashboard",
            contains_ids=[broken_dep_id],
        )
        broken_node = make_mock_unhydrated_node(broken_dep_id)
        broken_node.contains = MagicMock(return_value=[])
        broken_node.required_by = MagicMock(return_value=[])

        result = QueryResult(
            nodes=[parent_node, broken_node],
            graph=make_mock_graph([parent_node, broken_node]),
            queried_ids={parent_id},
        )
        _, _, df_broken, _ = ItemGraphReporter(result)._build_excel_data()

        assert broken_dep_id in df_broken["dep_id"].values


# ── Risk score column tests ────────────────────────────────────────────────────

class TestExcelRiskColumns:
    """Risk score columns added to All Items sheet when cache is provided."""

    def _simple_result(self):
        node = make_mock_node("id_a", title="My Dashboard", item_type="Dashboard",
                              owner="jsmith", contains_ids=[], required_by_ids=[])
        result = MagicMock()
        result.nodes = [node]
        result.queried_ids = {"id_a"}
        result.graph = make_mock_graph([node])
        return result

    def test_excel_all_items_has_risk_columns(self, tmp_path):
        """All Items sheet must include risk_score and risk_tier columns when cache provided."""
        import openpyxl
        from arcgis_item_graph.reporter import ItemGraphReporter
        from arcgis_item_graph.cache import MetadataCache

        result = self._simple_result()
        reporter = ItemGraphReporter(result)

        db_path = str(tmp_path / "meta.sqlite")
        cache = MetadataCache(db_path)
        path = str(tmp_path / "report.xlsx")
        reporter.to_excel(path, cache=cache)
        cache.close()

        wb = openpyxl.load_workbook(path)
        ws = wb["All Items"]
        headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
        assert "risk_score" in headers
        assert "risk_tier" in headers

    def test_excel_all_items_no_risk_columns_without_cache(self, tmp_path):
        """All Items sheet must NOT have risk columns when cache is not provided."""
        import openpyxl
        from arcgis_item_graph.reporter import ItemGraphReporter

        result = self._simple_result()
        reporter = ItemGraphReporter(result)
        path = str(tmp_path / "report.xlsx")
        reporter.to_excel(path)

        wb = openpyxl.load_workbook(path)
        ws = wb["All Items"]
        headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
        assert "risk_score" not in headers
        assert "risk_tier" not in headers


class TestUrlNodeStatus:
    """Tests for URL-type dep node status in Excel output (Task 5)."""

    def _make_url_result(self):
        """QueryResult where parent depends on a URL-type node (no portal item)."""
        url_id = "https://server/arcgis/rest/services/Roads/FeatureServer"
        parent = make_mock_node(
            "parentid00000000000000000000001a",
            contains_ids=[url_id],
        )
        url_dep = make_mock_unhydrated_node(url_id)  # .item = None
        url_dep.contains = MagicMock(return_value=[])
        url_dep.required_by = MagicMock(return_value=[])
        graph = make_mock_graph([parent, url_dep])
        result = QueryResult(
            nodes=[parent, url_dep],
            graph=graph,
            queried_ids={"parentid00000000000000000000001a"},
        )
        return result, url_id

    def test_dep_status_live_no_item_in_dependency_edges(self, tmp_path):
        """URL node probed as live_no_item appears with that dep_status in Dependency Edges."""
        from unittest.mock import MagicMock

        result, url_id = self._make_url_result()
        mock_cache = MagicMock()
        mock_cache.get_health.return_value = "live_no_item"
        reporter = ItemGraphReporter(result)

        out = tmp_path / "out.xlsx"
        reporter.to_excel(str(out), cache=mock_cache)

        wb = _openpyxl.load_workbook(str(out))
        ws = wb["Dependency Edges"]
        headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
        dep_status_col = headers.index("dep_status") + 1
        statuses = [ws.cell(r, dep_status_col).value for r in range(2, ws.max_row + 1)]
        assert "live_no_item" in statuses

    def test_broken_deps_sheet_includes_inaccessible_url_nodes(self, tmp_path):
        """URL nodes with status 'inaccessible' appear in Broken Dependencies sheet."""
        from unittest.mock import MagicMock

        result, url_id = self._make_url_result()
        mock_cache = MagicMock()
        mock_cache.get_health.return_value = "inaccessible"
        reporter = ItemGraphReporter(result)

        out = tmp_path / "out.xlsx"
        reporter.to_excel(str(out), cache=mock_cache)

        wb = _openpyxl.load_workbook(str(out))
        ws = wb["Broken Dependencies"]
        assert ws.max_row >= 2, "Expected at least one row in Broken Dependencies"
        headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
        dep_status_col = headers.index("dep_status") + 1
        statuses = [ws.cell(r, dep_status_col).value for r in range(2, ws.max_row + 1)]
        assert "inaccessible" in statuses

    def test_broken_deps_sheet_includes_dead_url_nodes(self, tmp_path):
        """URL nodes with status 'dead' appear in Broken Dependencies sheet."""
        from unittest.mock import MagicMock

        result, url_id = self._make_url_result()
        mock_cache = MagicMock()
        mock_cache.get_health.return_value = "dead"
        reporter = ItemGraphReporter(result)

        out = tmp_path / "out.xlsx"
        reporter.to_excel(str(out), cache=mock_cache)

        wb = _openpyxl.load_workbook(str(out))
        ws = wb["Broken Dependencies"]
        assert ws.max_row >= 2
        headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
        dep_status_col = headers.index("dep_status") + 1
        statuses = [ws.cell(r, dep_status_col).value for r in range(2, ws.max_row + 1)]
        assert "dead" in statuses

    def test_unchecked_url_node_shows_unchecked_status(self, tmp_path):
        """URL nodes with no health record show dep_status='unchecked'."""
        from unittest.mock import MagicMock

        result, url_id = self._make_url_result()
        mock_cache = MagicMock()
        mock_cache.get_health.return_value = "unchecked"
        reporter = ItemGraphReporter(result)

        out = tmp_path / "out.xlsx"
        reporter.to_excel(str(out), cache=mock_cache)

        wb = _openpyxl.load_workbook(str(out))
        ws = wb["Dependency Edges"]
        headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
        dep_status_col = headers.index("dep_status") + 1
        statuses = [ws.cell(r, dep_status_col).value for r in range(2, ws.max_row + 1)]
        assert "unchecked" in statuses

    def test_url_node_dep_title_uses_service_name(self, tmp_path):
        """URL-type dep nodes show extract_service_name(url) as dep_title, not the full URL."""
        from unittest.mock import MagicMock

        result, url_id = self._make_url_result()
        mock_cache = MagicMock()
        mock_cache.get_health.return_value = "live_no_item"
        reporter = ItemGraphReporter(result)

        out = tmp_path / "out.xlsx"
        reporter.to_excel(str(out), cache=mock_cache)

        wb = _openpyxl.load_workbook(str(out))
        ws = wb["Dependency Edges"]
        headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
        dep_title_col = headers.index("dep_title") + 1
        titles = [ws.cell(r, dep_title_col).value for r in range(2, ws.max_row + 1)]
        # Should show "Roads/FeatureServer" not the full URL
        assert any(t and "Roads" in str(t) for t in titles)
        assert not any(t and t == url_id for t in titles)
