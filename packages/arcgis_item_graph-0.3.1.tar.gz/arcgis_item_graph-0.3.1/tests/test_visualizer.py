# tests/test_visualizer.py
from pathlib import Path
from unittest.mock import MagicMock
import pytest
from arcgis_item_graph.visualizer import ItemGraphVisualizer
from arcgis_item_graph.query import QueryResult
from tests.conftest import make_mock_node, make_mock_graph, make_mock_unhydrated_node, make_mock_cycle_graph


@pytest.fixture
def simple_result():
    node_a = make_mock_node("id_a", title="My Dashboard", item_type="Dashboard",
                            contains_ids=["id_b"])
    node_b = make_mock_node("id_b", title="Base Map", item_type="Web Map",
                            contains_ids=[])
    graph = make_mock_graph([node_a, node_b])
    # Mock NetworkX edges
    graph.edges = MagicMock(return_value=[("id_a", "id_b")])
    return QueryResult(
        nodes=[node_a, node_b],
        graph=graph,
        queried_ids={"id_a"},
    )


def test_render_writes_file(simple_result, tmp_path):
    """render(output_file=...) should write a self-contained HTML file."""
    out = tmp_path / "out.html"
    vis = ItemGraphVisualizer(simple_result)
    vis.render(output_file=str(out))
    assert out.exists()
    content = out.read_text(encoding="utf-8")
    assert "let G =" in content              # GRAPH_DATA blob present
    assert "cytoscape(" in content          # Cytoscape init present


def test_render_html_contains_all_node_ids(simple_result, tmp_path):
    """render() output HTML should contain all node IDs in the GRAPH_DATA blob."""
    out = tmp_path / "out.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    content = out.read_text(encoding="utf-8")
    assert '"id_a"' in content
    assert '"id_b"' in content


def test_render_html_contains_edge(simple_result, tmp_path):
    """render() output HTML should contain the edge between id_a and id_b."""
    out = tmp_path / "out.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    content = out.read_text(encoding="utf-8")
    assert '"source":"id_a"' in content
    assert '"target":"id_b"' in content


def test_render_raises_if_no_output_and_no_inline(simple_result):
    """render() with neither output_file nor show_inline should raise ValueError."""
    vis = ItemGraphVisualizer(simple_result)
    with pytest.raises(ValueError, match="Provide output_file"):
        vis.render()


def test_query_result_portal_url_defaults_none():
    """QueryResult should default portal_url to None."""
    from arcgis_item_graph.query import QueryResult
    result = QueryResult(nodes=[], graph=MagicMock(), queried_ids=set())
    assert result.portal_url is None


def test_serialize_nodes_present(simple_result):
    """_serialize() should include every node from the result."""
    vis = ItemGraphVisualizer(simple_result)
    data = vis.serialize()
    ids = {n["id"] for n in data["nodes"]}
    assert ids == {"id_a", "id_b"}


def test_serialize_queried_flag(simple_result):
    """_serialize() should mark queried nodes with queried=True."""
    vis = ItemGraphVisualizer(simple_result)
    data = vis.serialize()
    node_a = next(n for n in data["nodes"] if n["id"] == "id_a")
    node_b = next(n for n in data["nodes"] if n["id"] == "id_b")
    assert node_a["queried"] is True
    assert node_b["queried"] is False


def test_serialize_item_types(simple_result):
    """_serialize() meta.item_types should list unique types in sorted order."""
    vis = ItemGraphVisualizer(simple_result)
    data = vis.serialize()
    assert "Dashboard" in data["meta"]["item_types"]
    assert "Web Map" in data["meta"]["item_types"]


def test_serialize_edges_direction(simple_result):
    """
    _serialize() edges should have direction='forward' for edges outgoing
    from the queried node.

    simple_result has: id_a (queried) → id_b
    id_a is the queried node with no ancestors → edge is 'forward'.
    """
    vis = ItemGraphVisualizer(simple_result)
    data = vis.serialize()
    assert len(data["edges"]) == 1
    edge = data["edges"][0]
    assert edge["source"] == "id_a"
    assert edge["target"] == "id_b"
    assert edge["direction"] == "forward"


def test_serialize_backward_edge():
    """
    _serialize() should mark edges from ancestor nodes as direction='backward'.

    Graph: upstream (queried=False) → queried_node
    upstream is an ancestor of queried_node → its edge is 'backward'.
    """
    upstream = make_mock_node("upstream", title="Upstream", item_type="Dashboard")
    queried = make_mock_node("queried", title="My Map", item_type="Web Map")
    graph = make_mock_graph([upstream, queried])
    graph.edges = MagicMock(return_value=[("upstream", "queried")])
    result = QueryResult(nodes=[upstream, queried], graph=graph, queried_ids={"queried"})

    vis = ItemGraphVisualizer(result)
    data = vis.serialize()
    assert len(data["edges"]) == 1
    assert data["edges"][0]["direction"] == "backward"


def test_serialize_cycles_detected():
    """_serialize() meta.cycles should be non-empty when the graph has a cycle."""
    node_a = make_mock_node("a", title="A", item_type="Dashboard")
    node_b = make_mock_node("b", title="B", item_type="Web Map")
    node_c = make_mock_node("c", title="C", item_type="Form")
    graph = make_mock_cycle_graph()
    result = QueryResult(nodes=[node_a, node_b, node_c], graph=graph, queried_ids={"a"})

    vis = ItemGraphVisualizer(result)
    data = vis.serialize()
    assert len(data["meta"]["cycles"]) >= 1
    flat = [item for cycle in data["meta"]["cycles"] for item in cycle]
    assert "a" in flat and "b" in flat and "c" in flat


def test_serialize_no_cycles(simple_result):
    """_serialize() meta.cycles should be empty when the graph is acyclic."""
    vis = ItemGraphVisualizer(simple_result)
    data = vis.serialize()
    assert data["meta"]["cycles"] == []


def test_serialize_unhydrated_node():
    """_serialize() should mark nodes with item=None as hydrated=False."""
    unhydrated = make_mock_unhydrated_node("ghost_id")
    graph = make_mock_graph([unhydrated])
    graph.edges = MagicMock(return_value=[])
    result = QueryResult(nodes=[unhydrated], graph=graph, queried_ids={"ghost_id"})

    vis = ItemGraphVisualizer(result)
    data = vis.serialize()
    node = data["nodes"][0]
    assert node["hydrated"] is False
    assert node["id"] == "ghost_id"
    assert node["type"] == "Unknown"


def test_serialize_portal_url():
    """_serialize() should build portal_url from result.portal_url + node id."""
    node = make_mock_node("abc123", title="My Layer", item_type="Feature Service")
    graph = make_mock_graph([node])
    graph.edges = MagicMock(return_value=[])
    result = QueryResult(
        nodes=[node],
        graph=graph,
        queried_ids={"abc123"},
        portal_url="https://myorg.arcgis.com",
    )

    vis = ItemGraphVisualizer(result)
    data = vis.serialize()
    node_data = data["nodes"][0]
    assert node_data["portal_url"] == "https://myorg.arcgis.com/home/item.html?id=abc123"


def test_serialize_portal_url_none_when_no_portal(simple_result):
    """_serialize() should set portal_url=None when result.portal_url is None."""
    vis = ItemGraphVisualizer(simple_result)
    data = vis.serialize()
    for n in data["nodes"]:
        assert n["portal_url"] is None


def test_visualizer_renders_impact_panel(tmp_path):
    """Rendered HTML must contain the impact panel structure."""
    from arcgis_item_graph.visualizer import ItemGraphVisualizer
    from arcgis_item_graph.query import QueryResult
    from tests.conftest import make_mock_node, make_mock_graph

    node = make_mock_node("aaa", contains_ids=["bbb"])
    graph = make_mock_graph([node])
    result = QueryResult(nodes=[node], graph=graph, queried_ids={"aaa"})

    out = tmp_path / "g.html"
    ItemGraphVisualizer(result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")

    assert 'id="impact-panel"' in html
    assert 'id="panel-inner"' in html
    assert 'id="panel-back"' in html
    assert 'id="collapse-btn"' in html


def test_visualizer_renders_panel_js_functions(tmp_path):
    """Rendered HTML must contain the panel JavaScript functions."""
    from arcgis_item_graph.visualizer import ItemGraphVisualizer
    from arcgis_item_graph.query import QueryResult
    from tests.conftest import make_mock_node, make_mock_graph

    node = make_mock_node("aaa", contains_ids=[])
    graph = make_mock_graph([node])
    result = QueryResult(nodes=[node], graph=graph, queried_ids={"aaa"})

    out = tmp_path / "g.html"
    ItemGraphVisualizer(result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")

    assert 'PANEL_CONTAINS' in html
    assert 'PANEL_REQUIRED_BY' in html
    assert 'function renderPanel(' in html
    assert 'function panelRowClick(' in html
    assert 'function showQueried(' in html


def test_visualizer_panel_maps_use_all_edges(tmp_path):
    """PANEL_CONTAINS/REQUIRED_BY must be built from all edges (not forward-only).

    The 'direction' field is only a visual hint for Cytoscape layout; filtering it
    out of the panel data breaks Migration Impact for items that are depended upon
    (whose edges are classified as 'backward').
    """
    from arcgis_item_graph.visualizer import ItemGraphVisualizer
    from arcgis_item_graph.query import QueryResult
    from tests.conftest import make_mock_node, make_mock_graph

    node = make_mock_node("aaa", contains_ids=["bbb"])
    graph = make_mock_graph([node])
    result = QueryResult(nodes=[node], graph=graph, queried_ids={"aaa"})

    out = tmp_path / "g.html"
    ItemGraphVisualizer(result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")

    # Direction filter must NOT be present — all edges populate the panel maps
    assert "e.direction !== 'forward'" not in html
    # Both panel maps must still be built
    assert 'PANEL_CONTAINS[e.source]' in html
    assert 'PANEL_REQUIRED_BY[e.target]' in html


def test_visualizer_no_detail_panel(tmp_path):
    """The old right-side #detail panel must be removed."""
    from arcgis_item_graph.visualizer import ItemGraphVisualizer
    from arcgis_item_graph.query import QueryResult
    from tests.conftest import make_mock_node, make_mock_graph

    node = make_mock_node("aaa", contains_ids=[])
    graph = make_mock_graph([node])
    result = QueryResult(nodes=[node], graph=graph, queried_ids={"aaa"})

    out = tmp_path / "g.html"
    ItemGraphVisualizer(result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")

    assert 'id="detail"' not in html
    assert 'id="detail-title"' not in html


def test_serialize_includes_broken_reason_field(simple_result):
    """_serialize() must include broken_reason in each node dict."""
    for node in simple_result.nodes:
        node.broken_reason = "deleted"

    data = ItemGraphVisualizer(simple_result).serialize()

    assert "broken_reason" in data["nodes"][0]
    assert data["nodes"][0]["broken_reason"] == "deleted"


def test_serialize_includes_deprecated_field(simple_result):
    """_serialize() must include deprecated in each node dict."""
    for node in simple_result.nodes:
        node.deprecated = True

    data = ItemGraphVisualizer(simple_result).serialize()

    assert "deprecated" in data["nodes"][0]
    assert data["nodes"][0]["deprecated"] is True


def test_visualizer_renders_broken_reason_and_deprecated_in_graph_data(tmp_path):
    """broken_reason and deprecated must appear as keys in the embedded G.nodes JSON."""
    node = make_mock_node("aaa", contains_ids=[])
    node.item = None
    node.broken_reason = "permission"

    graph = make_mock_graph([node])
    result = QueryResult(nodes=[node], graph=graph, queried_ids={"aaa"})

    out = tmp_path / "g.html"
    ItemGraphVisualizer(result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")

    assert '"broken_reason"' in html
    assert '"deprecated"' in html


def test_visualizer_renders_requery_input(simple_result, tmp_path):
    """Rendered HTML must include the 'Go to Item' input element."""
    v = ItemGraphVisualizer(simple_result)
    out = tmp_path / "g.html"
    v.render(output_file=str(out))
    html = out.read_text(encoding="utf-8")
    assert 'id="requery-wrap"' in html
    assert 'id="requery-input"' in html
    assert 'reQueryItem' in html


def test_serialize_is_public(simple_result):
    """serialize() must be callable as a public method."""
    v = ItemGraphVisualizer(simple_result)
    data = v.serialize()
    assert set(data.keys()) == {"nodes", "edges", "meta"}
    assert isinstance(data["nodes"], list)
    assert isinstance(data["edges"], list)
    assert "queried_ids" in data["meta"]


def test_retest_records_timestamp_on_404(tmp_path):
    """retestItem() must record a timestamp even when the server returns 404.

    Previously the !resp.ok branch returned early without updating RETEST_TIMESTAMPS,
    leaving the button stuck on '↺ Retest' with no confirmation that the check ran.
    """
    node = make_mock_node("aaa", contains_ids=[])
    graph = make_mock_graph([node])
    result = QueryResult(nodes=[node], graph=graph, queried_ids={"aaa"})

    out = tmp_path / "g.html"
    ItemGraphVisualizer(result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")

    # The !resp.ok branch must set RETEST_TIMESTAMPS[itemId] and call renderPanel
    # before returning so the button shows "✓ HH:MM" on confirmed-gone items.
    assert "RETEST_TIMESTAMPS[itemId] = _time" in html
    # Verify the timestamp + renderPanel call appears BEFORE the first `return`
    # inside the !resp.ok block (not just in the success path).
    not_ok_idx = html.index("if (!resp.ok)")
    next_return_idx = html.index("return;", not_ok_idx)
    block = html[not_ok_idx:next_return_idx]
    assert "RETEST_TIMESTAMPS[itemId] = _time" in block
    assert "renderPanel" in block


def test_visualizer_renders_zoom_overlay(simple_result, tmp_path):
    """Rendered HTML must include the floating zoom control overlay."""
    out = tmp_path / "g.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")
    assert 'id="zoom-ctrl"' in html
    assert 'id="zoom-slider"' in html
    assert 'id="btn-zoom-in"' in html
    assert 'id="btn-zoom-out"' in html
    assert 'id="zoom-label"' in html


def test_visualizer_renders_zoom_js(simple_result, tmp_path):
    """Rendered HTML must include the setZoom function and cy.on('zoom') sync."""
    out = tmp_path / "g.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")
    assert 'function setZoom(' in html
    assert "cy.zoom(" in html               # Cytoscape zoom behavior


def test_visualizer_tap_pivots_graph(simple_result, tmp_path):
    """Single-click tap handler must update QUERIED and re-render around the clicked node."""
    out = tmp_path / "g.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")
    assert 'QUERIED = new Set([nid])' in html
    assert 'ctrlKey' in html


def test_visualizer_no_dblclick_handler(simple_result, tmp_path):
    """Double-click expand handler must be removed."""
    out = tmp_path / "g.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")
    assert "cy.on('dblclick'" not in html


def test_visualizer_renders_d3_node_builder(simple_result, tmp_path):
    """Rendered HTML must contain D3 node/link builder and depth computation."""
    out = tmp_path / "g.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")
    assert 'function buildGraph(' in html
    assert 'function nodeRadius(' in html
    assert 'computeDepths' in html


def test_visualizer_renders_cytoscape_container(simple_result, tmp_path):
    """Rendered HTML must use a Cytoscape div container and inject Cytoscape.js."""
    out = tmp_path / "g.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")
    assert 'id="cy"' in html
    assert 'cytoscape(' in html             # Cytoscape init call present
    assert 'function getLayout(' in html   # layout helper must be defined before use


# ── Audit summary banner tests ────────────────────────────────────────────────

from arcgis_item_graph.auditor import AuditReport, NodeDiff


def test_visualizer_renders_audit_summary(simple_result, tmp_path):
    """When audit_report is provided, HTML includes audit summary banner."""
    diff = NodeDiff(node_id="id_a", node_title="My Dashboard", api_only={"missing1"})
    audit_report = AuditReport(diffs=[diff])

    out = tmp_path / "audit_out.html"
    vis = ItemGraphVisualizer(simple_result)
    vis.render(output_file=str(out), audit_report=audit_report)
    html = out.read_text(encoding="utf-8")

    assert "audit-summary" in html
    assert "missing_from_graph" in html or "missing from graph" in html.lower()


def test_visualizer_no_audit_summary_without_report(simple_result, tmp_path):
    """Without audit_report, no audit-summary element in HTML."""
    out = tmp_path / "no_audit_out.html"
    vis = ItemGraphVisualizer(simple_result)
    vis.render(output_file=str(out))
    html = out.read_text(encoding="utf-8")

    assert "audit-summary" not in html


# ── URL health data tests ─────────────────────────────────────────────────────

class TestUrlHealthData:
    def _make_result_with_url_node(self):
        url_id = "https://server/arcgis/rest/services/Roads/FeatureServer"
        parent = make_mock_node("abcdef1234567890abcdef1234567891", contains_ids=[url_id])
        url_dep = make_mock_unhydrated_node(url_id)
        graph = make_mock_graph([parent, url_dep])
        return QueryResult(
            nodes=[parent, url_dep],
            graph=graph,
            queried_ids={"abcdef1234567890abcdef1234567891"},
        )

    def test_url_health_data_injected_when_cache_provided(self, tmp_path):
        """URL_HEALTH_DATA JS constant is present in HTML when cache is provided."""
        from unittest.mock import MagicMock, patch
        result = self._make_result_with_url_node()
        mock_cache = MagicMock()
        mock_cache.get_health.return_value = "inaccessible"
        viz = ItemGraphVisualizer(result)
        out = tmp_path / "graph.html"

        with patch("arcgis_item_graph.visualizer.classify_node_id",
                   side_effect=lambda x: "arcgis_rest_url" if x.startswith("http") else "portal_id"):
            viz.render(str(out), cache=mock_cache)

        html = out.read_text(encoding="utf-8")
        assert "URL_HEALTH_DATA" in html
        assert "inaccessible" in html

    def test_url_health_data_empty_dict_when_no_cache(self, tmp_path):
        """URL_HEALTH_DATA is an empty JS object when no cache is provided."""
        result = self._make_result_with_url_node()
        viz = ItemGraphVisualizer(result)
        out = tmp_path / "graph.html"
        viz.render(str(out))

        html = out.read_text(encoding="utf-8")
        assert "URL_HEALTH_DATA" in html
        # Should be empty dict
        assert "URL_HEALTH_DATA = {}" in html or "URL_HEALTH_DATA={}" in html or '"URL_HEALTH_DATA"' not in html
