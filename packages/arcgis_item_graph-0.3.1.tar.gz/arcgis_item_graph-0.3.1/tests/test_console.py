"""tests/test_console.py — Tests for arcgis_item_graph/console.py."""
import io
import time
from unittest.mock import MagicMock, patch

import pytest
from rich.console import Console


def _buf_console():
    """Return a (buf, Console) pair writing to a StringIO — no TTY needed."""
    buf = io.StringIO()
    return buf, Console(file=buf, highlight=False, force_terminal=False)


# ── Standalone helpers ────────────────────────────────────────────────────────

class TestPrintStep:
    def test_renders_without_raising(self):
        from arcgis_item_graph import console as mod
        buf, con = _buf_console()
        with patch.object(mod, "console", con):
            mod.print_step("Connecting to portal…")
        assert "Connecting to portal" in buf.getvalue()

    def test_dim_arrow_prefix(self):
        from arcgis_item_graph import console as mod
        buf, con = _buf_console()
        with patch.object(mod, "console", con):
            mod.print_step("Step label")
        # plain-text Console strips markup; check text content
        assert "Step label" in buf.getvalue()


class TestPrintErrorPanel:
    def test_renders_title_and_message(self):
        from arcgis_item_graph import console as mod
        buf, con = _buf_console()
        with patch.object(mod, "console", con):
            mod.print_error_panel("Config Error", "File not found at config/config.yaml")
        out = buf.getvalue()
        assert "Config Error" in out
        assert "File not found" in out

    def test_renders_hint_when_provided(self):
        from arcgis_item_graph import console as mod
        buf, con = _buf_console()
        with patch.object(mod, "console", con):
            mod.print_error_panel(
                "Configuration Error",
                "Missing key: paths.gml_file",
                hint="run arcgis-graph setup",
            )
        out = buf.getvalue()
        assert "arcgis-graph setup" in out

    def test_no_hint_renders_cleanly(self):
        from arcgis_item_graph import console as mod
        buf, con = _buf_console()
        with patch.object(mod, "console", con):
            mod.print_error_panel("Auth Failed", "Bad credentials")
        # Should not raise even without hint
        assert "Auth Failed" in buf.getvalue()


class TestPrintCompletionTable:
    def test_renders_all_rows(self):
        from arcgis_item_graph import console as mod
        buf, con = _buf_console()
        rows = [
            ("Items indexed", "6665"),
            ("Elapsed", "57m 12s"),
            ("Graph file", "outputs/graph.gml"),
        ]
        with patch.object(mod, "console", con):
            mod.print_completion_table("Create complete", rows, elapsed=3432.0)
        out = buf.getvalue()
        assert "6665" in out
        assert "outputs/graph.gml" in out

    def test_elapsed_format_minutes(self):
        from arcgis_item_graph import console as mod
        buf, con = _buf_console()
        with patch.object(mod, "console", con):
            mod.print_completion_table("Done", [], elapsed=125.0)
        out = buf.getvalue()
        assert "2m" in out

    def test_elapsed_format_seconds_only(self):
        from arcgis_item_graph import console as mod
        buf, con = _buf_console()
        with patch.object(mod, "console", con):
            mod.print_completion_table("Done", [], elapsed=45.0)
        out = buf.getvalue()
        assert "45s" in out

    def test_elapsed_format_hours(self):
        from arcgis_item_graph import console as mod
        buf, con = _buf_console()
        with patch.object(mod, "console", con):
            mod.print_completion_table("Done", [], elapsed=3672.0)
        out = buf.getvalue()
        assert "1h" in out


# ── CommandProgress ───────────────────────────────────────────────────────────

class TestCommandProgress:
    def test_enter_exit_lifecycle(self):
        from arcgis_item_graph.console import CommandProgress
        mock_live = MagicMock()
        mock_live.__enter__ = MagicMock(return_value=mock_live)
        mock_live.__exit__ = MagicMock(return_value=False)
        with patch("arcgis_item_graph.console.Live", return_value=mock_live):
            with CommandProgress("Test", total=5) as prog:
                assert prog is not None
        mock_live.__enter__.assert_called_once()
        mock_live.__exit__.assert_called_once()

    def test_on_item_advances_count(self):
        from arcgis_item_graph.console import CommandProgress
        with patch("arcgis_item_graph.console.Live"):
            with CommandProgress("Test", total=10) as prog:
                prog.on_item(count=3, title="My Dashboard", item_type="Dashboard")
                assert prog._count == 3

    def test_on_warning_increments_warning_count(self):
        from arcgis_item_graph.console import CommandProgress
        with patch("arcgis_item_graph.console.Live"):
            with CommandProgress("Test", total=10) as prog:
                prog._layout = MagicMock()
                prog.on_warning(title="Broken Item", reason="not_found")
                prog.on_warning(title="Another Item", reason="forbidden")
                assert prog.warning_count == 2

    def test_set_step_appends_to_log(self):
        from arcgis_item_graph.console import CommandProgress
        with patch("arcgis_item_graph.console.Live"):
            with CommandProgress("Test") as prog:
                prog._layout = MagicMock()
                initial_len = len(prog._log_lines)
                prog.set_step("Loading graph…")
                assert len(prog._log_lines) == initial_len + 1

    def test_set_total_switches_to_determinate(self):
        from arcgis_item_graph.console import CommandProgress
        with patch("arcgis_item_graph.console.Live"):
            with CommandProgress("Test", total=None) as prog:
                assert prog._total is None
                prog.set_total(50)
                assert prog._total == 50

    def test_elapsed_returns_positive_float(self):
        from arcgis_item_graph.console import CommandProgress
        with patch("arcgis_item_graph.console.Live"):
            with CommandProgress("Test") as prog:
                time.sleep(0.01)
                assert prog.elapsed() > 0.0
