"""Tests for arcgis_item_graph/auditor.py — ItemDependencyAuditor."""
import types
from unittest.mock import MagicMock

from arcgis_item_graph.auditor import (
    NodeDiff, AuditReport, ItemDependencyAuditor,
)


# ── NodeDiff / AuditReport dataclass tests ────────────────────────────────────

def test_node_diff_defaults():
    diff = NodeDiff(node_id="abc123", node_title="My Map")
    assert diff.node_id == "abc123"
    assert diff.node_title == "My Map"
    assert diff.graph_only == set()
    assert diff.api_only == set()
    assert diff.in_both == set()
    assert diff.audit_skipped is None


def test_node_diff_with_sets():
    diff = NodeDiff(
        node_id="abc",
        node_title="X",
        graph_only={"g1"},
        api_only={"a1", "a2"},
        in_both={"b1"},
    )
    assert len(diff.graph_only) == 1
    assert len(diff.api_only) == 2
    assert len(diff.in_both) == 1


def test_node_diff_skipped():
    diff = NodeDiff(node_id="abc", node_title="", audit_skipped="unsupported")
    assert diff.audit_skipped == "unsupported"


def test_audit_report_empty():
    report = AuditReport()
    assert report.diffs == []
    assert report.nodes_with_discrepancies == []
    assert report.skipped_count == 0
    assert report.total_missing_from_graph == 0
    assert report.total_extra_in_graph == 0


def test_audit_report_aggregates():
    diffs = [
        NodeDiff("a", "A", graph_only={"g1"}, api_only={"a1", "a2"}, in_both={"b1"}),
        NodeDiff("b", "B", graph_only=set(), api_only=set()),
        NodeDiff("c", "C", audit_skipped="error"),
    ]
    report = AuditReport(diffs=diffs)
    assert report.total_missing_from_graph == 2     # a1, a2
    assert report.total_extra_in_graph == 1         # g1
    assert report.skipped_count == 1                # node C
    # only node A has discrepancies
    assert len(report.nodes_with_discrepancies) == 1
    assert report.nodes_with_discrepancies[0].node_id == "a"


# ── _audit_node() tests ───────────────────────────────────────────────────────

def _make_node(node_id, title="Test Item", item=True, graph_neighbors=None):
    """Build a minimal mock node."""
    node = types.SimpleNamespace(
        id=node_id,
        item=MagicMock(title=title) if item else None,
    )
    neighbors = graph_neighbors or []
    node.contained_by = MagicMock(return_value=neighbors)
    return node


def _make_gis(dependent_to_list=None, get_raises=False):
    """Build a minimal mock GIS where content.get returns an item with dependencies.

    Mocks the v2.4.x API: item.dependencies.to_dependencies is a list property.
    """
    gis = MagicMock()
    item = MagicMock()
    if get_raises:
        gis.content.get.side_effect = Exception("portal error")
    else:
        gis.content.get.return_value = item
        # to_dependencies is a property (list) in arcgis v2.4.x
        item.dependencies.to_dependencies = dependent_to_list or []
    return gis


class TestAuditNode:
    def test_no_discrepancy(self):
        """Graph and API agree — all in_both, no api_only or graph_only."""
        gis = _make_gis([{"dependencyType": "id", "id": "dep1"}])
        node = _make_node("node1", graph_neighbors=["dep1"])

        auditor = ItemDependencyAuditor(gis=gis)
        diff = auditor._audit_node(node)

        assert diff.node_id == "node1"
        assert diff.in_both == {"dep1"}
        assert diff.api_only == set()
        assert diff.graph_only == set()
        assert diff.audit_skipped is None

    def test_api_only_edges(self):
        """API knows about dep2 but graph doesn't — missing from graph."""
        gis = _make_gis([
            {"dependencyType": "id", "id": "dep1"},
            {"dependencyType": "id", "id": "dep2"},
        ])
        node = _make_node("node1", graph_neighbors=["dep1"])

        auditor = ItemDependencyAuditor(gis=gis)
        diff = auditor._audit_node(node)

        assert "dep2" in diff.api_only
        assert diff.graph_only == set()

    def test_graph_only_edges(self):
        """Graph has dep2 but API doesn't — phantom edge in graph."""
        gis = _make_gis([{"dependencyType": "id", "id": "dep1"}])
        node = _make_node("node1", graph_neighbors=["dep1", "dep2"])

        auditor = ItemDependencyAuditor(gis=gis)
        diff = auditor._audit_node(node)

        assert "dep2" in diff.graph_only
        assert diff.api_only == set()

    def test_url_deps_excluded(self):
        """URL-type dependencies from API are not included in comparison."""
        gis = _make_gis([
            {"dependencyType": "url", "url": "https://services.arcgis.com/layer"},
            {"dependencyType": "id", "id": "dep1"},
        ])
        node = _make_node("node1", graph_neighbors=["dep1"])

        auditor = ItemDependencyAuditor(gis=gis)
        diff = auditor._audit_node(node)

        assert diff.in_both == {"dep1"}
        assert diff.api_only == set()

    def test_broken_node_skipped(self):
        """Nodes with item=None are skipped without API call."""
        gis = MagicMock()
        node = _make_node("node1", item=False)

        auditor = ItemDependencyAuditor(gis=gis)
        diff = auditor._audit_node(node)

        assert diff.audit_skipped == "broken_node"
        gis.content.get.assert_not_called()

    def test_dependencies_api_raises_attribute_error(self):
        """Both to_dependencies and dependent_to() unavailable → audit_skipped='unsupported'."""
        gis = MagicMock()
        item = MagicMock()
        gis.content.get.return_value = item
        # Simulate neither v2.4.x property nor newer method being available
        del item.dependencies.to_dependencies      # raises AttributeError on access
        item.dependencies.dependent_to.side_effect = AttributeError("not supported")
        node = _make_node("node1")

        auditor = ItemDependencyAuditor(gis=gis)
        diff = auditor._audit_node(node)

        assert diff.audit_skipped == "unsupported"

    def test_dependencies_api_raises_other_exception(self):
        """to_dependencies missing, dependent_to() raises RuntimeError → audit_skipped='error'."""
        gis = MagicMock()
        item = MagicMock()
        gis.content.get.return_value = item
        # to_dependencies not available → falls back to dependent_to() → raises RuntimeError
        del item.dependencies.to_dependencies
        item.dependencies.dependent_to.side_effect = RuntimeError("portal unavailable")
        node = _make_node("node1")

        auditor = ItemDependencyAuditor(gis=gis)
        diff = auditor._audit_node(node)

        assert diff.audit_skipped == "error"

    def test_content_get_returns_none(self):
        """content.get() returns None → audit_skipped='broken_node'."""
        gis = MagicMock()
        gis.content.get.return_value = None
        node = _make_node("node1")

        auditor = ItemDependencyAuditor(gis=gis)
        diff = auditor._audit_node(node)

        assert diff.audit_skipped == "broken_node"


# ── audit() method tests ──────────────────────────────────────────────────────

def _make_query_result(nodes):
    """Minimal QueryResult stub."""
    result = MagicMock()
    result.nodes = nodes
    return result


class TestAuditMethod:
    def test_returns_audit_report(self):
        gis = _make_gis([])
        node = _make_node("n1", graph_neighbors=[])
        result = _make_query_result([node])

        auditor = ItemDependencyAuditor(gis=gis)
        report = auditor.audit(result)

        assert isinstance(report, AuditReport)
        assert len(report.diffs) == 1

    def test_url_nodes_excluded_from_audit(self):
        """Nodes with URL-shaped IDs are never audited."""
        gis = MagicMock()
        url_node = types.SimpleNamespace(id="https://services.arcgis.com/layer",
                                         item=MagicMock())
        result = _make_query_result([url_node])

        auditor = ItemDependencyAuditor(gis=gis)
        report = auditor.audit(result)

        assert len(report.diffs) == 0
        gis.content.get.assert_not_called()

    def test_none_nodes_excluded(self):
        """None entries in result.nodes are skipped."""
        gis = _make_gis([])
        result = _make_query_result([None, _make_node("n1")])

        auditor = ItemDependencyAuditor(gis=gis)
        report = auditor.audit(result)

        assert len(report.diffs) == 1

    def test_multiple_nodes_all_audited(self):
        gis = _make_gis([])
        nodes = [_make_node(f"node{i}") for i in range(5)]
        result = _make_query_result(nodes)

        auditor = ItemDependencyAuditor(gis=gis)
        report = auditor.audit(result)

        assert len(report.diffs) == 5

    def test_partial_failure_does_not_abort(self):
        """If one node raises, others are still audited."""
        gis = MagicMock()
        gis.content.get.side_effect = RuntimeError("network error")

        nodes = [_make_node(f"node{i}") for i in range(3)]
        result = _make_query_result(nodes)

        auditor = ItemDependencyAuditor(gis=gis, workers=1)
        report = auditor.audit(result)

        assert len(report.diffs) == 3
        assert report.skipped_count == 3

    def test_summary_counts_correct(self):
        gis = _make_gis([{"dependencyType": "id", "id": "missing1"},
                          {"dependencyType": "id", "id": "missing2"}])
        node = _make_node("n1", graph_neighbors=["phantom1"])
        result = _make_query_result([node])

        auditor = ItemDependencyAuditor(gis=gis)
        report = auditor.audit(result)

        assert report.total_missing_from_graph == 2
        assert report.total_extra_in_graph == 1
