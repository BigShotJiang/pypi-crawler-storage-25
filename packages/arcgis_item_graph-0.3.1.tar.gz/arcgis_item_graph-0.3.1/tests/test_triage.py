"""Tests for arcgis_item_graph/triage.py — ItemTriageRunner and helpers."""
import pytest
from arcgis_item_graph.triage import RankedItem, ServiceDep, TriageResult, CONSUMER_TYPES


def test_consumer_types_contains_expected():
    assert "Dashboard" in CONSUMER_TYPES
    assert "Web Mapping Application" in CONSUMER_TYPES
    assert "Experience Builder Web App" in CONSUMER_TYPES
    assert "Web Map" in CONSUMER_TYPES
    assert "Hub Site Application" in CONSUMER_TYPES
    assert "StoryMap" in CONSUMER_TYPES


def test_ranked_item_is_dataclass():
    item = RankedItem(
        item_id="abc123",
        title="Test Dashboard",
        item_type="Dashboard",
        portal_url="https://portal/home/item.html?id=abc123",
        view_count=500,
        dependency_count=8,
        traffic_rank=0.75,
        last_modified="2026-04-01T00:00:00",
    )
    assert item.item_id == "abc123"
    assert item.traffic_rank == 0.75


def test_service_dep_is_dataclass():
    dep = ServiceDep(
        service_url="https://server/rest/services/Svc/FeatureServer",
        item_id="def456",
        item_title="My Service",
        hosting_server="server",
        data_source_type="egdb",
        classifier_tier=2,
        layer_count=3,
        referenced_by=[],
    )
    assert dep.data_source_type == "egdb"
    assert dep.classifier_tier == 2


def test_triage_result_is_dataclass():
    result = TriageResult(
        generated_at="2026-04-24T00:00:00Z",
        portal_url="https://portal",
        graph_age_hours=1.5,
        ranked_items=[],
        services=[],
        dependency_matrix=[],
    )
    assert result.graph_age_hours == 1.5


# ── Task 2: ItemRanker tests ──────────────────────────────────────────────────

import networkx as nx
from unittest.mock import MagicMock, patch
from arcgis_item_graph.triage import ItemRanker


def _make_triage_graph():
    """Small graph: 2 dashboards + 1 web map + 2 feature services."""
    G = nx.DiGraph()
    # Consumer items
    G.add_node("dash1", title="Dashboard A", type="Dashboard",
               owner="user1", modified=1700000000000)
    G.add_node("dash2", title="Dashboard B", type="Dashboard",
               owner="user1", modified=1700000000000)
    G.add_node("wmap1", title="Web Map A", type="Web Map",
               owner="user1", modified=1700000000000)
    # Services (non-consumer)
    G.add_node("svc1", title="Service 1", type="Feature Service",
               owner="user1", modified=1700000000000)
    G.add_node("svc2", title="Service 2", type="Feature Service",
               owner="user1", modified=1700000000000)
    # Edges: dash1 depends on svc1+svc2, dash2 on svc1, wmap1 on svc2
    G.add_edge("dash1", "svc1")
    G.add_edge("dash1", "svc2")
    G.add_edge("dash2", "svc1")
    G.add_edge("wmap1", "svc2")
    return G


def test_ranker_only_returns_consumer_types():
    G = _make_triage_graph()
    gis = MagicMock()
    gis.url = "https://test.portal.arcgis.com"
    ranker = ItemRanker(gis=gis, portal_url="https://test.portal.arcgis.com")
    results = ranker.rank(G, top_n=10, min_dependents=0, use_usage_stats=False)
    returned_types = {r.item_type for r in results}
    assert "Feature Service" not in returned_types
    assert "Dashboard" in returned_types
    assert "Web Map" in returned_types


def test_ranker_top_n_limits_results():
    G = _make_triage_graph()
    gis = MagicMock()
    gis.url = "https://test.portal.arcgis.com"
    ranker = ItemRanker(gis=gis, portal_url="https://test.portal.arcgis.com")
    results = ranker.rank(G, top_n=2, min_dependents=0, use_usage_stats=False)
    assert len(results) <= 2


def test_ranker_min_dependents_filter():
    G = _make_triage_graph()
    gis = MagicMock()
    gis.url = "https://test.portal.arcgis.com"
    ranker = ItemRanker(gis=gis, portal_url="https://test.portal.arcgis.com")
    # wmap1 has 1 dependency (svc2), dash1 has 2, dash2 has 1
    # min_dependents=2 should return only dash1
    results = ranker.rank(G, top_n=10, min_dependents=2, use_usage_stats=False)
    ids = {r.item_id for r in results}
    assert "dash1" in ids
    assert "wmap1" not in ids


def test_ranker_falls_back_to_dependency_count_when_no_usage_stats():
    G = _make_triage_graph()
    gis = MagicMock()
    gis.url = "https://test.portal.arcgis.com"
    ranker = ItemRanker(gis=gis, portal_url="https://test.portal.arcgis.com")
    results = ranker.rank(G, top_n=10, min_dependents=0, use_usage_stats=False)
    # dash1 has most dependencies (2) — should rank highest
    assert results[0].item_id == "dash1"
    # All view_counts should be 0
    assert all(r.view_count == 0 for r in results)


def test_ranker_uses_usage_stats_when_available():
    G = _make_triage_graph()
    gis = MagicMock()
    gis.url = "https://test.portal.arcgis.com"
    # dash2 has 1 dependency but high usage
    mock_item_dash2 = MagicMock()
    mock_item_dash2.usage.return_value = [{"num": 10000}]
    mock_item_dash1 = MagicMock()
    mock_item_dash1.usage.return_value = [{"num": 100}]
    mock_item_wmap1 = MagicMock()
    mock_item_wmap1.usage.return_value = [{"num": 50}]

    def fake_get(item_id):
        return {"dash1": mock_item_dash1, "dash2": mock_item_dash2,
                "wmap1": mock_item_wmap1}.get(item_id)

    gis.content.get = MagicMock(side_effect=fake_get)
    ranker = ItemRanker(gis=gis, portal_url="https://test.portal.arcgis.com")
    results = ranker.rank(G, top_n=10, min_dependents=0, use_usage_stats=True)
    # dash2 should rank above dash1 due to high usage
    ids = [r.item_id for r in results]
    assert ids.index("dash2") < ids.index("dash1")


# ── Task 3: DataSourceClassifier Tier 1 tests ────────────────────────────────

from arcgis_item_graph.triage import DataSourceClassifier, DS_HOSTED_RELATIONAL, \
    DS_HOSTED_SPATIOTEMPORAL, DS_EXTERNAL, DS_UNKNOWN


def _make_classifier(portal_url="https://myportal.arcgis.com"):
    gis = MagicMock()
    gis.url = portal_url
    return DataSourceClassifier(gis=gis, portal_url=portal_url)


def test_classifier_tier1_arcgis_online_hosted():
    c = _make_classifier()
    ds_type, tier = c.classify(
        "https://services.arcgis.com/abc/arcgis/rest/services/Svc/FeatureServer"
    )
    assert ds_type == DS_HOSTED_RELATIONAL
    assert tier == 1


def test_classifier_tier1_portal_hosting_server():
    c = _make_classifier("https://myportal.arcgis.com")
    ds_type, tier = c.classify(
        "https://myportal.arcgis.com/hosting/rest/services/Svc/FeatureServer"
    )
    assert ds_type == DS_HOSTED_RELATIONAL
    assert tier == 1


def test_classifier_tier1_spatiotemporal_geoanalytics():
    c = _make_classifier()
    ds_type, tier = c.classify(
        "https://myserver.com/arcgis/rest/services/GeoAnalyticsServer/Svc/FeatureServer"
    )
    assert ds_type == DS_HOSTED_SPATIOTEMPORAL
    assert tier == 1


def test_classifier_tier1_geoevent():
    c = _make_classifier()
    ds_type, tier = c.classify(
        "https://myserver.com/arcgis/rest/services/GeoEvent/Svc/StreamServer"
    )
    assert ds_type == DS_HOSTED_SPATIOTEMPORAL
    assert tier == 1


def test_classifier_tier1_external_different_host():
    c = _make_classifier("https://myportal.arcgis.com")
    ds_type, tier = c.classify(
        "https://completely-different-server.com/arcgis/rest/services/Svc/FeatureServer"
    )
    assert ds_type == DS_EXTERNAL
    assert tier == 1


def test_classifier_tier1_enterprise_server_returns_egdb():
    """Same portal host + /rest/services/ path → enterprise ArcGIS Server → DS_EGDB at Tier 1."""
    c = _make_classifier("https://myportal.arcgis.com")
    ds_type, tier = c.classify(
        "https://myportal.arcgis.com/arcgis/rest/services/MyFolder/MySvc/FeatureServer",
    )
    assert ds_type == DS_EGDB
    assert tier == 1


def test_classifier_tier1_no_rest_services_path_is_unknown():
    """Same portal host but path lacks /rest/services/ — Tier 1 cannot classify (returns unknown)."""
    c = _make_classifier("https://myportal.arcgis.com")
    # Same host, path without /rest/services/ — ambiguous, needs Tier 2
    ds_type, tier = c.classify(
        "https://myportal.arcgis.com/portal/home/item.html",
        _tier1_only=True,  # test helper flag to skip Tier 2+
    )
    assert ds_type == DS_UNKNOWN
    assert tier == 0  # 0 = not yet classified


# ── Task 4: DataSourceClassifier Tier 2 tests ────────────────────────────────

from arcgis_item_graph.triage import DS_FGDB, DS_EGDB


def test_classifier_tier2_fgdb_static_data():
    c = _make_classifier("https://myportal.arcgis.com")
    url = "https://myportal.arcgis.com/arcgis/rest/services/MyFolder/MySvc/FeatureServer"
    c._gis._con.get = MagicMock(return_value={
        "hasStaticData": True,
        "capabilities": "Query",
        "maxRecordCount": 1000,
    })
    # Call Tier 2 directly — Tier 1 catches same-host /rest/services/ URLs as EGDB
    ds_type, tier = c._classify_tier2(url)
    assert ds_type == DS_FGDB
    assert tier == 2


def test_classifier_tier2_egdb_query_analytic():
    c = _make_classifier("https://myportal.arcgis.com")
    url = "https://myportal.arcgis.com/arcgis/rest/services/MyFolder/MySvc/FeatureServer"
    c._gis._con.get = MagicMock(return_value={
        "hasStaticData": False,
        "capabilities": "Query,Create,Update,Delete,Editing",
        "advancedQueryCapabilities": {"supportsQueryAnalytic": True},
    })
    # Call Tier 2 directly — Tier 1 catches same-host /rest/services/ URLs as EGDB
    ds_type, tier = c._classify_tier2(url)
    assert ds_type == DS_EGDB
    assert tier == 2


def test_classifier_tier1_hosted_services_folder():
    """URLs with /rest/services/Hosted/ path are caught at Tier 1 as hosted relational."""
    c = _make_classifier("https://myportal.arcgis.com")
    url = "https://myportal.arcgis.com/arcgis/rest/services/Hosted/MySvc/FeatureServer"
    # No network call needed — _TIER1_HOSTED_PORTAL regex catches /rest/services/hosted/
    ds_type, tier = c.classify(url)
    assert ds_type == DS_HOSTED_RELATIONAL
    assert tier == 1


def test_classifier_tier2_unreachable_returns_unknown():
    c = _make_classifier("https://myportal.arcgis.com")
    url = "https://myportal.arcgis.com/arcgis/rest/services/Dead/Svc/FeatureServer"
    c._gis._con.get = MagicMock(side_effect=Exception("Connection refused"))
    # Call Tier 2 directly — Tier 1 catches same-host /rest/services/ URLs as EGDB
    ds_type, tier = c._classify_tier2(url)
    assert ds_type == DS_UNKNOWN
    assert tier == 2


# ── Task 5: DataSourceClassifier Tier 3 + classify_many tests ────────────────

def test_classifier_tier3_egdb_sql_fields():
    c = _make_classifier("https://myportal.arcgis.com")
    url = "https://myportal.arcgis.com/arcgis/rest/services/MyFolder/MySvc/FeatureServer"
    # Call Tier 3 directly — only layers endpoint response needed
    c._gis._con.get = MagicMock(return_value={
        "layers": [{"fields": [{"name": "OBJECTID", "sqlType": "sqlTypeInteger"}]}],
    })
    ds_type, tier = c._classify_tier3(url)
    assert ds_type == DS_EGDB
    assert tier == 3


def test_classifier_tier3_fgdb_no_sql_type():
    c = _make_classifier("https://myportal.arcgis.com")
    url = "https://myportal.arcgis.com/arcgis/rest/services/MyFolder/MySvc/FeatureServer"
    # Call Tier 3 directly — layers have fields but no sqlType → FGDB
    c._gis._con.get = MagicMock(return_value={
        "layers": [{"fields": [{"name": "OBJECTID"}]}],
    })
    ds_type, tier = c._classify_tier3(url)
    assert ds_type == DS_FGDB
    assert tier == 3


def test_classifier_tier2_returns_unknown_tier3_not_called():
    """When Tier 2 returns DS_UNKNOWN, the layers endpoint is NOT fetched (only root JSON)."""
    c = _make_classifier("https://myportal.arcgis.com")
    url = "https://myportal.arcgis.com/arcgis/rest/services/MyFolder/MySvc/FeatureServer"
    # Tier 2 root JSON has no recognisable indicators → DS_UNKNOWN
    c._gis._con.get = MagicMock(return_value={"hasStaticData": False, "capabilities": "Query"})
    ds_type, tier = c._classify_tier2(url)
    assert ds_type == DS_UNKNOWN
    # Only ONE call made (Tier 2 root JSON) — Tier 3 layers call not made
    assert c._gis._con.get.call_count == 1


def test_classifier_deduplicates_services():
    """classify_many() calls classify() once per unique URL regardless of how
    many items reference the same service."""
    c = _make_classifier("https://myportal.arcgis.com")
    url = "https://myportal.arcgis.com/arcgis/rest/services/MyFolder/MySvc/FeatureServer"
    c._gis._con.get = MagicMock(return_value={"hasStaticData": True})

    # Call classify_many with same URL appearing 5 times
    results = c.classify_many([url, url, url, url, url], deep=False)

    # URL is caught at Tier 1 (same portal host + /rest/services/ → EGDB) — no network calls
    assert c._gis._con.get.call_count == 0
    # Result should still have exactly one entry (deduplication)
    assert len(results) == 1
    assert results[url][0] == DS_EGDB


# ── Task 6: ItemTriageRunner tests ───────────────────────────────────────────

from arcgis_item_graph.triage import ItemTriageRunner


def _make_runner_config():
    return {
        "triage": {
            "top_n": 10,
            "min_dependents": 0,
            "deep_inspect": False,
            "use_usage_stats": False,
            "usage_lookback_days": 90,
            "traffic_weight": 0.6,
            "min_hotspot_refs": 2,
            "consumer_types": list(CONSUMER_TYPES),
        }
    }


def test_runner_produces_triage_result():
    G = _make_triage_graph()
    gis = MagicMock()
    gis.url = "https://test.portal.arcgis.com"
    # Service nodes have no portal item — url attribute contains the REST URL
    G.nodes["svc1"]["url"] = "https://test.portal.arcgis.com/arcgis/rest/services/Svc1/FeatureServer"
    G.nodes["svc2"]["url"] = "https://test.portal.arcgis.com/arcgis/rest/services/Svc2/FeatureServer"

    gis._con.get = MagicMock(return_value={"hasStaticData": True})

    runner = ItemTriageRunner(gis=gis, config=_make_runner_config())
    result = runner.run(G, graph_age_hours=1.0)

    assert isinstance(result, TriageResult)
    assert len(result.ranked_items) > 0
    assert len(result.services) == 2  # svc1 + svc2, deduplicated
    assert len(result.dependency_matrix) > 0


def test_runner_dependency_matrix_has_one_row_per_item_service_pair():
    G = _make_triage_graph()
    gis = MagicMock()
    gis.url = "https://test.portal.arcgis.com"
    G.nodes["svc1"]["url"] = "https://test.portal.arcgis.com/rest/services/Svc1/FeatureServer"
    G.nodes["svc2"]["url"] = "https://test.portal.arcgis.com/rest/services/Svc2/FeatureServer"
    gis._con.get = MagicMock(return_value={"hasStaticData": False})

    runner = ItemTriageRunner(gis=gis, config=_make_runner_config())
    result = runner.run(G, graph_age_hours=0.5)

    # dash1→svc1, dash1→svc2, dash2→svc1, wmap1→svc2 = 4 rows
    assert len(result.dependency_matrix) == 4
    row_keys = set(result.dependency_matrix[0].keys())
    assert "item_id" in row_keys
    assert "service_url" in row_keys
    assert "data_source_type" in row_keys


def test_runner_hotspots_threshold():
    G = _make_triage_graph()
    gis = MagicMock()
    gis.url = "https://test.portal.arcgis.com"
    G.nodes["svc1"]["url"] = "https://test.portal.arcgis.com/rest/services/Svc1/FeatureServer"
    G.nodes["svc2"]["url"] = "https://test.portal.arcgis.com/rest/services/Svc2/FeatureServer"
    gis._con.get = MagicMock(return_value={"hasStaticData": False})

    cfg = _make_runner_config()
    cfg["triage"]["min_hotspot_refs"] = 2
    runner = ItemTriageRunner(gis=gis, config=cfg)
    result = runner.run(G, graph_age_hours=0.5)

    # svc1 referenced by dash1+dash2 (2 items) — qualifies
    # svc2 referenced by dash1+wmap1 (2 items) — qualifies
    hotspot_urls = {s.service_url for s in result.services if len(s.referenced_by) >= 2}
    assert len(hotspot_urls) == 2


class TestTriageRunnerCallbacks:
    def test_callbacks_accepted_without_error(self):
        from arcgis_item_graph.triage import ItemTriageRunner
        from unittest.mock import MagicMock

        gis = MagicMock()
        gis.url = "https://gis.example.com"
        config = {"triage": {"top_n": 5}}
        on_progress = MagicMock()
        on_warning = MagicMock()

        runner = ItemTriageRunner(
            gis=gis, config=config,
            on_progress=on_progress,
            on_warning=on_warning,
        )
        assert runner._on_progress is on_progress
        assert runner._on_warning is on_warning

    def test_on_progress_defaults_to_noop(self):
        from arcgis_item_graph.triage import ItemTriageRunner
        from unittest.mock import MagicMock

        gis = MagicMock()
        gis.url = "https://gis.example.com"
        runner = ItemTriageRunner(gis=gis, config={})
        runner._on_progress(count=1, title="Test", item_type="Dashboard")
        runner._on_warning(title="Bad", reason="missing")


# ── Task 7: to_json() tests ───────────────────────────────────────────────────

import json
import tempfile
from pathlib import Path


def _make_minimal_result():
    return TriageResult(
        generated_at="2026-04-24T00:00:00Z",
        portal_url="https://test.portal.arcgis.com",
        graph_age_hours=1.5,
        ranked_items=[
            RankedItem(
                item_id="abc123",
                title="Test Dashboard",
                item_type="Dashboard",
                portal_url="https://test.portal.arcgis.com/home/item.html?id=abc123",
                view_count=500,
                dependency_count=2,
                traffic_rank=0.75,
                last_modified="2026-04-01T00:00:00",
            )
        ],
        services=[
            ServiceDep(
                service_url="https://test.portal.arcgis.com/rest/services/Svc/FeatureServer",
                item_id=None,
                item_title=None,
                hosting_server="test.portal.arcgis.com",
                data_source_type="egdb",
                classifier_tier=2,
                layer_count=None,
                referenced_by=["abc123"],
            )
        ],
        dependency_matrix=[{
            "item_id": "abc123",
            "item_title": "Test Dashboard",
            "item_type": "Dashboard",
            "item_rank": 1,
            "view_count": 500,
            "traffic_rank": 0.75,
            "service_url": "https://test.portal.arcgis.com/rest/services/Svc/FeatureServer",
            "service_title": None,
            "hosting_server": "test.portal.arcgis.com",
            "data_source_type": "egdb",
            "classifier_tier": 2,
        }],
    )


def test_to_json_writes_valid_json():
    result = _make_minimal_result()
    gis = MagicMock()
    gis.url = "https://test.portal.arcgis.com"
    runner = ItemTriageRunner(gis=gis, config=_make_runner_config())

    with tempfile.TemporaryDirectory() as tmpdir:
        path = str(Path(tmpdir) / "manifest.json")
        runner.to_json(result, path)
        with open(path) as f:
            data = json.load(f)

    assert data["meta"]["portal_url"] == "https://test.portal.arcgis.com"
    assert data["meta"]["total_ranked_items"] == 1
    assert data["meta"]["total_unique_services"] == 1
    assert len(data["items"]) == 1
    assert data["items"][0]["item_id"] == "abc123"
    assert len(data["items"][0]["dependencies"]) == 1
    assert len(data["services"]) == 1
    assert data["services"][0]["data_source_type"] == "egdb"


def test_to_json_required_keys_present():
    result = _make_minimal_result()
    gis = MagicMock()
    gis.url = "https://test.portal.arcgis.com"
    runner = ItemTriageRunner(gis=gis, config=_make_runner_config())

    with tempfile.TemporaryDirectory() as tmpdir:
        path = str(Path(tmpdir) / "manifest.json")
        runner.to_json(result, path)
        data = json.load(open(path))

    meta_keys = {"generated_at", "portal_url", "graph_age_hours",
                 "total_ranked_items", "total_unique_services"}
    assert meta_keys.issubset(data["meta"].keys())
    item_keys = {"item_id", "title", "item_type", "portal_url",
                 "view_count", "traffic_rank", "dependencies"}
    assert item_keys.issubset(data["items"][0].keys())


# ── Task 8: to_excel() tests ─────────────────────────────────────────────────

import openpyxl


def test_to_excel_has_five_sheets():
    result = _make_minimal_result()
    gis = MagicMock()
    gis.url = "https://test.portal.arcgis.com"
    runner = ItemTriageRunner(gis=gis, config=_make_runner_config())

    with tempfile.TemporaryDirectory() as tmpdir:
        path = str(Path(tmpdir) / "report.xlsx")
        runner.to_excel(result, path)
        wb = openpyxl.load_workbook(path)

    assert set(wb.sheetnames) == {
        "High Traffic Items",
        "Service Inventory",
        "Dependency Matrix",
        "Migration Hotspots",
        "Consumer Chain",
    }


def test_to_excel_high_traffic_items_columns():
    result = _make_minimal_result()
    gis = MagicMock()
    gis.url = "https://test.portal.arcgis.com"
    runner = ItemTriageRunner(gis=gis, config=_make_runner_config())

    with tempfile.TemporaryDirectory() as tmpdir:
        path = str(Path(tmpdir) / "report.xlsx")
        runner.to_excel(result, path)
        wb = openpyxl.load_workbook(path)
        ws = wb["High Traffic Items"]

    headers = [cell.value for cell in ws[1]]
    for col in ["rank", "item_id", "title", "item_type", "view_count",
                "dependency_count", "traffic_rank", "portal_url", "last_modified"]:
        assert col in headers, f"Missing column: {col}"


def test_to_excel_hotspots_sorted_by_impact():
    """Migration Hotspots sheet should be sorted by combined_view_impact descending."""
    def _make_ranked(item_id, view_count):
        return RankedItem(
            item_id=item_id, title=f"Item {item_id}", item_type="Dashboard",
            portal_url=f"https://portal/home/item.html?id={item_id}",
            view_count=view_count, dependency_count=1, traffic_rank=0.5,
            last_modified="2026-04-01T00:00:00",
        )

    svc_high = ServiceDep(
        service_url="https://portal/rest/services/High/FeatureServer",
        item_id=None, item_title=None, hosting_server="portal",
        data_source_type="egdb", classifier_tier=2, layer_count=None,
        referenced_by=["a", "b"],  # combined_view_impact = 300+200 = 500
    )
    svc_low = ServiceDep(
        service_url="https://portal/rest/services/Low/FeatureServer",
        item_id=None, item_title=None, hosting_server="portal",
        data_source_type="fgdb", classifier_tier=1, layer_count=None,
        referenced_by=["c"],  # combined_view_impact = 100
    )
    result = TriageResult(
        generated_at="2026-04-24T00:00:00Z",
        portal_url="https://portal",
        graph_age_hours=1.0,
        ranked_items=[
            _make_ranked("a", 300),
            _make_ranked("b", 200),
            _make_ranked("c", 100),
        ],
        services=[svc_low, svc_high],  # intentionally low first
        dependency_matrix=[],
    )
    gis = MagicMock()
    gis.url = "https://portal"
    cfg = _make_runner_config()
    cfg["triage"]["min_hotspot_refs"] = 1
    runner = ItemTriageRunner(gis=gis, config=cfg)

    with tempfile.TemporaryDirectory() as tmpdir:
        path = str(Path(tmpdir) / "report.xlsx")
        runner.to_excel(result, path)
        wb = openpyxl.load_workbook(path)
        ws = wb["Migration Hotspots"]

    headers = [cell.value for cell in ws[1]]
    impact_col = headers.index("combined_view_impact") + 1
    rows = list(ws.iter_rows(min_row=2, values_only=True))
    impacts = [row[impact_col - 1] for row in rows if row[impact_col - 1] is not None]
    assert impacts == sorted(impacts, reverse=True)
    assert impacts[0] == 500  # svc_high: a(300) + b(200)


def test_to_excel_consumer_chain_has_columns():
    """Consumer Chain sheet should exist with correct column headers."""
    result = TriageResult(
        generated_at="2026-04-24T00:00:00Z",
        portal_url="https://test.portal.arcgis.com",
        graph_age_hours=1.0,
        ranked_items=[
            RankedItem(
                item_id="abc123",
                title="Test Dashboard",
                item_type="Dashboard",
                portal_url="https://test.portal.arcgis.com/home/item.html?id=abc123",
                view_count=500,
                dependency_count=1,
                traffic_rank=0.75,
                last_modified="2026-04-01T00:00:00",
            )
        ],
        services=[],
        dependency_matrix=[],
        consumer_map={
            "abc123": [
                {"id": "def456", "title": "Consumer Map", "type": "Web Map"},
            ]
        },
    )
    gis = MagicMock()
    gis.url = "https://test.portal.arcgis.com"
    runner = ItemTriageRunner(gis=gis, config=_make_runner_config())

    with tempfile.TemporaryDirectory() as tmpdir:
        path = str(Path(tmpdir) / "report.xlsx")
        runner.to_excel(result, path)
        wb = openpyxl.load_workbook(path)
        ws = wb["Consumer Chain"]

    headers = [cell.value for cell in ws[1]]
    for col in ["item_rank", "item_id", "item_title", "item_type",
                "view_count", "traffic_rank",
                "consumer_id", "consumer_title", "consumer_type"]:
        assert col in headers, f"Missing column: {col}"

    rows = list(ws.iter_rows(min_row=2, values_only=True))
    assert len(rows) == 1
    row = rows[0]
    assert row[headers.index("item_id")] == "abc123"
    assert row[headers.index("consumer_id")] == "def456"
    assert row[headers.index("consumer_title")] == "Consumer Map"
