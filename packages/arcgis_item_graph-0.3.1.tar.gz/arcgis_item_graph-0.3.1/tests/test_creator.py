# tests/test_creator.py
from unittest.mock import MagicMock, patch, mock_open
import pytest
from arcgis_item_graph.creator import ItemGraphCreator


def test_creator_init_creates_directories(tmp_path):
    """Creator should create parent directories for gml and timestamp files."""
    gml = tmp_path / "subdir" / "graph.gml"
    ts = tmp_path / "subdir" / "ts.txt"
    creator = ItemGraphCreator(
        gis=MagicMock(),
        gml_file=str(gml),
        timestamp_file=str(ts)
    )
    assert gml.parent.exists()
    assert ts.parent.exists()


@patch("arcgis_item_graph.creator.create_dependency_graph")
def test_create_returns_success_dict(mock_cdg, tmp_path):
    """create() should return a dict with success=True and correct keys."""
    mock_gis = MagicMock()
    mock_gis.content.search.return_value = ["item1", "item2"]

    mock_graph = MagicMock()
    mock_graph.all_items.return_value = ["item1", "item2"]
    mock_graph.write_to_file = MagicMock()
    mock_cdg.return_value = mock_graph

    creator = ItemGraphCreator(
        gis=mock_gis,
        gml_file=str(tmp_path / "graph.gml"),
        timestamp_file=str(tmp_path / "ts.txt"),
        max_items=100
    )
    result = creator.create()

    assert result["success"] is True
    assert result["items_indexed"] == 2
    assert "gml_file" in result
    assert "timestamp" in result


@patch("arcgis_item_graph.creator.create_dependency_graph")
def test_create_returns_failure_dict_on_exception(mock_cdg, tmp_path):
    """create() should catch exceptions and return success=False."""
    mock_cdg.side_effect = RuntimeError("API error")
    mock_gis = MagicMock()
    mock_gis.content.search.return_value = []

    creator = ItemGraphCreator(
        gis=mock_gis,
        gml_file=str(tmp_path / "graph.gml"),
        timestamp_file=str(tmp_path / "ts.txt")
    )
    result = creator.create()

    assert result["success"] is False
    assert "error" in result


class TestCreatorCallbacks:
    def test_on_progress_callback_called_per_item(self, tmp_path):
        from arcgis_item_graph.creator import ItemGraphCreator
        from unittest.mock import MagicMock, patch

        mock_item = MagicMock()
        mock_item.title = "Test Layer"
        mock_item.type = "Feature Layer"
        mock_item.itemid = "abc123"

        mock_graph = MagicMock()
        mock_graph.all_items.return_value = [mock_item] * 2
        mock_graph.write_to_file = MagicMock()

        on_progress = MagicMock()
        on_warning = MagicMock()

        with patch("arcgis_item_graph.creator.create_dependency_graph",
                   return_value=mock_graph):
            gis = MagicMock()
            gis.content.search.return_value = [mock_item, mock_item]

            creator = ItemGraphCreator(
                gis=gis,
                gml_file=str(tmp_path / "graph.gml"),
                timestamp_file=str(tmp_path / "graph.timestamp"),
                on_progress=on_progress,
                on_warning=on_warning,
            )
            result = creator.create()

        assert result["success"] is True
        assert on_progress.call_count == 2
        # First call: count=1
        first_call_kwargs = on_progress.call_args_list[0][1]
        assert first_call_kwargs["count"] == 1
        assert first_call_kwargs["title"] == "Test Layer"
        assert first_call_kwargs["item_type"] == "Feature Layer"

    def test_on_progress_defaults_to_noop(self, tmp_path):
        from arcgis_item_graph.creator import ItemGraphCreator
        from unittest.mock import MagicMock, patch

        mock_item = MagicMock()
        mock_item.title = "Item"
        mock_item.type = "Web Map"
        mock_graph = MagicMock()
        mock_graph.all_items.return_value = [mock_item]
        mock_graph.write_to_file = MagicMock()

        with patch("arcgis_item_graph.creator.create_dependency_graph",
                   return_value=mock_graph):
            gis = MagicMock()
            gis.content.search.return_value = [mock_item]
            creator = ItemGraphCreator(
                gis=gis,
                gml_file=str(tmp_path / "graph.gml"),
                timestamp_file=str(tmp_path / "graph.timestamp"),
            )
            result = creator.create()
        assert result["success"] is True  # no callback = no error


class TestCreatorKwargs:
    def test_create_passes_include_reverse_and_outside_org(self, tmp_path):
        """create_dependency_graph must be called with include_reverse and outside_org."""
        with patch("arcgis_item_graph.creator.create_dependency_graph") as mock_cdg:
            mock_graph = MagicMock()
            mock_graph.all_items.return_value = []
            mock_graph.write_to_file = MagicMock()
            mock_cdg.return_value = mock_graph

            mock_gis = MagicMock()
            mock_gis.content.search.return_value = []

            creator = ItemGraphCreator(
                gis=mock_gis,
                gml_file=str(tmp_path / "graph.gml"),
                timestamp_file=str(tmp_path / "graph.timestamp"),
                include_reverse=True,
                outside_org=True,
            )
            result = creator.create()

        assert result["success"] is True
        assert mock_cdg.called
        _, kwargs = mock_cdg.call_args
        assert kwargs.get("include_reverse") is True
        assert kwargs.get("outside_org") is True

    def test_create_respects_false_kwargs(self, tmp_path):
        """include_reverse=False and outside_org=False must be forwarded as-is."""
        with patch("arcgis_item_graph.creator.create_dependency_graph") as mock_cdg:
            mock_graph = MagicMock()
            mock_graph.all_items.return_value = []
            mock_graph.write_to_file = MagicMock()
            mock_cdg.return_value = mock_graph

            mock_gis = MagicMock()
            mock_gis.content.search.return_value = []

            creator = ItemGraphCreator(
                gis=mock_gis,
                gml_file=str(tmp_path / "graph.gml"),
                timestamp_file=str(tmp_path / "graph.timestamp"),
                include_reverse=False,
                outside_org=False,
            )
            result = creator.create()

        assert result["success"] is True
        _, kwargs = mock_cdg.call_args
        assert kwargs.get("include_reverse") is False
        assert kwargs.get("outside_org") is False
