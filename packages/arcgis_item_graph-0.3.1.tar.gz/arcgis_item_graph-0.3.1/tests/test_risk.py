"""Tests for arcgis_item_graph/risk.py — score_item."""
from unittest.mock import MagicMock

import pytest

from arcgis_item_graph.risk import RiskScore, score_item


def make_cache(item_data=None, broken_ids=None):
    cache = MagicMock()
    cache.get_item.return_value = item_data
    cache.get_health.return_value = "ok"
    cache.broken_nodes.return_value = broken_ids or []
    return cache


class TestScoreItem:
    def test_zero_dependents_returns_green(self):
        cache = make_cache(item_data={"access": "org", "content_status": "",
                                      "delete_protected": 1})
        result = score_item("abc", cache, required_by_ids=[])
        assert result.score == 0
        assert result.tier == "green"
        assert result.signals == []

    def test_high_fanout_adds_20(self):
        cache = make_cache()
        cache.get_item.return_value = {"access": "org", "content_status": "",
                                       "delete_protected": 1}
        dep_ids = [f"dep{i:028}" for i in range(15)]
        result = score_item("abc", cache, required_by_ids=dep_ids)
        assert result.score >= 20
        assert any("fanout" in s for s in result.signals)

    def test_very_high_fanout_adds_40(self):
        cache = make_cache()
        cache.get_item.return_value = {"access": "org", "content_status": "",
                                       "delete_protected": 1}
        dep_ids = [f"dep{i:028}" for i in range(55)]
        result = score_item("abc", cache, required_by_ids=dep_ids)
        assert result.score >= 40

    def test_public_dependent_adds_20(self):
        cache = MagicMock()
        dep_id = "pub" + "a" * 29
        cache.get_item.side_effect = lambda id: {
            "access": "public" if id == dep_id else "org",
            "content_status": "",
            "delete_protected": 1,
        }
        cache.broken_nodes.return_value = []
        result = score_item("abc", cache, required_by_ids=[dep_id])
        assert result.score >= 20
        assert any("public" in s for s in result.signals)

    def test_deprecated_content_status_adds_10(self):
        cache = make_cache(item_data={"access": "org", "content_status": "deprecated",
                                      "delete_protected": 1})
        result = score_item("abc", cache, required_by_ids=[])
        assert result.score >= 10
        assert any("deprecated" in s for s in result.signals)

    def test_tier_boundary_31_is_yellow(self):
        cache = make_cache()
        cache.get_item.return_value = {"access": "org", "content_status": "deprecated",
                                       "delete_protected": 1}
        dep_ids = [f"dep{i:028}" for i in range(15)]
        cache.broken_nodes.return_value = []
        result = score_item("abc", cache, required_by_ids=dep_ids)
        # 20 (high fanout) + 10 (deprecated) = 30 → green boundary
        # score of 31 would be yellow — this test may be green or yellow
        assert result.tier in ("green", "yellow")

    def test_tier_boundary_61_is_red(self):
        cache = MagicMock()
        dep_ids = [f"dep{i:028}" for i in range(55)]
        pub_dep = dep_ids[0]
        cache.get_item.side_effect = lambda id: {
            "access": "public" if id == pub_dep else "org",
            "content_status": "deprecated",
            "delete_protected": 1,
        }
        cache.broken_nodes.return_value = []
        result = score_item("abc", cache, required_by_ids=dep_ids)
        assert result.tier == "red"
        assert result.score >= 61

    def test_score_capped_at_100(self):
        cache = MagicMock()
        dep_ids = [f"dep{i:028}" for i in range(100)]
        cache.get_item.side_effect = lambda id: {
            "access": "public",
            "content_status": "deprecated",
            "delete_protected": 0,
        }
        cache.broken_nodes.return_value = dep_ids[:5]
        result = score_item("abc", cache, required_by_ids=dep_ids)
        assert result.score <= 100

    def test_missing_item_in_cache_does_not_raise(self):
        cache = make_cache(item_data=None, broken_ids=[])
        result = score_item("abc", cache, required_by_ids=[])
        assert isinstance(result, RiskScore)
