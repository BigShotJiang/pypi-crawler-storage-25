# tests/test_utils.py
"""Tests for arcgis_item_graph/utils.py."""
import pytest
from arcgis_item_graph.utils import categorize_hydration_error, strip_layer_index, extract_service_name


class TestCategorizeHydrationError:
    """categorize_hydration_error() must map error strings to correct categories."""

    # ── malformed_url ──────────────────────────────────────────────────────

    def test_http_url_rest_services(self):
        """/rest/services/ URLs are malformed item IDs."""
        assert categorize_hydration_error(
            "some error", "https://example.com/arcgis/rest/services/MyService/MapServer"
        ) == "malformed_url"

    def test_no_connection_adapters(self):
        """'no connection adapters' signals a URL used as an item ID."""
        assert categorize_hydration_error("No connection adapters were found", "abc123") == "malformed_url"

    # ── deleted (ArcGIS-specific item-not-found) ───────────────────────────

    def test_unable_to_find_iteminfo(self):
        """ArcGIS 'unable to find iteminfo' message → deleted."""
        assert categorize_hydration_error("Unable to find iteminfo for abc123", "abc123") == "deleted"

    def test_unable_to_find_iteminfo_with_500(self):
        """ArcGIS-specific message takes precedence over generic 500."""
        assert categorize_hydration_error(
            "Unable to find iteminfo. Error code: 500", "abc123"
        ) == "deleted"

    # ── not_found (HTTP 404) ───────────────────────────────────────────────

    def test_error_code_404(self):
        """HTTP 404 from portal → not_found (item genuinely missing)."""
        assert categorize_hydration_error("Error code: 404", "abc123") == "not_found"

    def test_404_not_found_string(self):
        """'404 not found' string → not_found."""
        assert categorize_hydration_error("404 not found", "abc123") == "not_found"

    # ── degraded (HTTP 500 server error, NOT item-missing) ────────────────

    def test_error_code_500_alone_is_degraded_not_deleted(self):
        """Generic HTTP 500 without ArcGIS iteminfo message → degraded, not deleted."""
        assert categorize_hydration_error("Error code: 500", "abc123") == "degraded"

    def test_server_error_500_message(self):
        """ArcGIS Server 'Unable to complete operation. (Error code: 500)' → degraded."""
        assert categorize_hydration_error(
            "Unable to complete operation. (Error code: 500)", "abc123"
        ) == "degraded"

    # ── network ───────────────────────────────────────────────────────────

    def test_timeout(self):
        assert categorize_hydration_error("Read timeout occurred", "abc123") == "network"

    def test_connection_error(self):
        assert categorize_hydration_error("Connection reset by peer", "abc123") == "network"

    def test_socket_error(self):
        assert categorize_hydration_error("socket.timeout: timed out", "abc123") == "network"

    # ── permission ────────────────────────────────────────────────────────

    def test_403_forbidden(self):
        assert categorize_hydration_error("403 Forbidden", "abc123") == "permission"

    def test_unauthorized(self):
        assert categorize_hydration_error("Unauthorized access", "abc123") == "permission"

    def test_permission_keyword(self):
        assert categorize_hydration_error("User does not have permission", "abc123") == "permission"

    # ── unknown ───────────────────────────────────────────────────────────

    def test_unrecognised_error(self):
        assert categorize_hydration_error("Something completely unexpected", "abc123") == "unknown"


from arcgis_item_graph.utils import classify_node_id

class TestClassifyNodeId:
    def test_32char_hex_is_portal_id(self):
        assert classify_node_id("abc123def456abc123def456abc123de") == "portal_id"

    def test_arcgis_rest_url(self):
        url = "https://services.arcgis.com/org/ArcGIS/rest/services/MyLayer/FeatureServer/0"
        assert classify_node_id(url) == "arcgis_rest_url"

    def test_http_arcgis_rest_url(self):
        url = "http://gis.example.com/arcgis/rest/services/Roads/MapServer"
        assert classify_node_id(url) == "arcgis_rest_url"

    def test_external_url_https(self):
        assert classify_node_id("https://example.com/wms?SERVICE=WMS") == "external_url"

    def test_external_url_http(self):
        assert classify_node_id("http://tiles.example.com/tiles/{z}/{x}/{y}") == "external_url"

    def test_short_id_no_slash_is_portal(self):
        # Non-hex short strings still treated as portal_id (not our job to validate format)
        assert classify_node_id("shortid") == "portal_id"


from unittest.mock import MagicMock, patch
from arcgis_item_graph.utils import batch_fetch_items

class TestBatchFetchItems:
    def _make_item(self, itemid):
        item = MagicMock()
        item.itemid = itemid
        return item

    def test_all_found(self):
        gis = MagicMock()
        item_a = self._make_item("aaa")
        item_b = self._make_item("bbb")
        gis.content.get.side_effect = lambda item_id: {"aaa": item_a, "bbb": item_b}[item_id]

        result = batch_fetch_items(gis, ["aaa", "bbb"])

        assert result == {"aaa": item_a, "bbb": item_b}

    def test_partial_hit(self):
        gis = MagicMock()
        item_a = self._make_item("aaa")
        gis.content.get.side_effect = lambda item_id: item_a if item_id == "aaa" else None

        result = batch_fetch_items(gis, ["aaa", "bbb"])

        assert "aaa" in result
        assert "bbb" not in result

    def test_skips_url_ids(self):
        gis = MagicMock()
        result = batch_fetch_items(
            gis,
            ["https://services.arcgis.com/org/ArcGIS/rest/services/Layer/FeatureServer"],
        )
        gis.content.get.assert_not_called()
        assert result == {}

    def test_empty_list(self):
        gis = MagicMock()
        result = batch_fetch_items(gis, [])
        gis.content.get.assert_not_called()
        assert result == {}

    def test_parallel_fetches_large_list(self):
        gis = MagicMock()
        ids = [f"{'a' * 30}{i:02d}" for i in range(120)]
        gis.content.get.return_value = None

        batch_fetch_items(gis, ids, workers=10)

        # Each ID gets its own content.get() call
        assert gis.content.get.call_count == 120

    def test_fetch_failure_returns_partial(self):
        gis = MagicMock()
        item_a = self._make_item("aaa")
        ids = ["aaa", "bbb"]

        def _get(item_id):
            if item_id == "aaa":
                return item_a
            raise Exception("portal unavailable")

        gis.content.get.side_effect = _get

        result = batch_fetch_items(gis, ids)

        # Should return partial results without raising
        assert result.get("aaa") is item_a
        assert "bbb" not in result


class TestStripLayerIndex:
    """strip_layer_index() must remove numeric layer/table indices from URLs."""

    def test_removes_numeric_suffix(self):
        """Trailing numeric layer index is removed."""
        assert (
            strip_layer_index(
                "https://portal/rest/services/Hosted/Roads/FeatureServer/0"
            )
            == "https://portal/rest/services/Hosted/Roads/FeatureServer"
        )

    def test_removes_multi_digit_suffix(self):
        """Multi-digit layer indices are also removed."""
        assert (
            strip_layer_index(
                "https://portal/rest/services/Data/SVC/MapServer/123"
            )
            == "https://portal/rest/services/Data/SVC/MapServer"
        )

    def test_noop_when_no_layer_index(self):
        """URL without numeric suffix is unchanged."""
        url = "https://portal/rest/services/Hosted/Roads/FeatureServer"
        assert strip_layer_index(url) == url

    def test_noop_when_path_ends_with_non_numeric(self):
        """Non-numeric trailing segment is not stripped."""
        url = "https://portal/rest/services/MyService123/FeatureServer"
        assert strip_layer_index(url) == url

    def test_strips_trailing_slash_before_checking(self):
        """Trailing slashes are stripped before layer-index check."""
        assert (
            strip_layer_index(
                "https://portal/rest/services/Hosted/Roads/FeatureServer/0/"
            )
            == "https://portal/rest/services/Hosted/Roads/FeatureServer"
        )


class TestExtractServiceName:
    """extract_service_name() must return readable service names from REST URLs."""

    def test_folder_and_service(self):
        """Extract last two path segments from /rest/services/ URLs."""
        assert (
            extract_service_name(
                "https://portal/rest/services/Hosted/MyRoads/FeatureServer/0"
            )
            == "MyRoads/FeatureServer"
        )

    def test_no_folder(self):
        """Single-segment service names are extracted correctly."""
        assert (
            extract_service_name(
                "https://portal/rest/services/MyService/MapServer"
            )
            == "MyService/MapServer"
        )

    def test_external_no_rest_path(self):
        """URLs without /rest/services/ are returned unchanged."""
        url = "https://other-server.com/wms?service=WMS"
        assert extract_service_name(url) == url

    def test_strips_layer_index_before_extracting(self):
        """Layer index is stripped before extracting service name."""
        assert (
            extract_service_name(
                "https://portal/rest/services/Data/Parcels/FeatureServer/2"
            )
            == "Parcels/FeatureServer"
        )


import requests as req
from arcgis_item_graph.utils import probe_service_url


class TestProbeServiceUrl:
    """probe_service_url() must probe service URLs for HTTP liveness."""

    def test_returns_live_no_item_on_200(self):
        """HTTP 200 response returns 'live_no_item'."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        with patch("requests.get", return_value=mock_resp):
            assert probe_service_url("https://s/rest/services/X/FeatureServer") == "live_no_item"

    def test_appends_f_json_to_url(self):
        """Appends ?f=json to the probe URL."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        with patch("requests.get", return_value=mock_resp) as mock_get:
            probe_service_url("https://s/rest/services/X/FeatureServer")
            call_url = mock_get.call_args[0][0]
            assert "f=json" in call_url

    def test_strips_existing_query_params_before_appending(self):
        """Strips existing query params before appending f=json."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        with patch("requests.get", return_value=mock_resp) as mock_get:
            probe_service_url("https://s/rest/services/X/FS?token=abc")
            call_url = mock_get.call_args[0][0]
            assert "token=abc" not in call_url
            assert "f=json" in call_url

    def test_returns_inaccessible_on_403(self):
        """HTTP 403 Forbidden returns 'inaccessible'."""
        mock_resp = MagicMock()
        mock_resp.status_code = 403
        with patch("requests.get", return_value=mock_resp):
            assert probe_service_url("https://s/rest/services/X/FS") == "inaccessible"

    def test_returns_inaccessible_on_ssl_error(self):
        """SSLError returns 'inaccessible'."""
        with patch("requests.get", side_effect=req.exceptions.SSLError()):
            assert probe_service_url("https://s/rest/services/X/FS") == "inaccessible"

    def test_returns_dead_on_connection_error(self):
        """ConnectionError returns 'dead'."""
        with patch("requests.get", side_effect=req.exceptions.ConnectionError()):
            assert probe_service_url("https://s/rest/services/X/FS") == "dead"

    def test_returns_dead_on_timeout(self):
        """Timeout returns 'dead'."""
        with patch("requests.get", side_effect=req.exceptions.Timeout()):
            assert probe_service_url("https://s/rest/services/X/FS") == "dead"
