"""Tests for ItemGraphRemapper."""
from arcgis_item_graph.remapper import RemapCandidate, RemapPreview, RemapOutcome


def test_remap_candidate_fields():
    c = RemapCandidate(item_id="abc", title="My Layer", type="Feature Service", owner="jsmith")
    assert c.item_id == "abc"
    assert c.title == "My Layer"
    assert c.type == "Feature Service"
    assert c.owner == "jsmith"


def test_remap_preview_fields():
    from_c = RemapCandidate("aaa", "Old Layer", "Feature Service", "jsmith")
    to_c   = RemapCandidate("bbb", "New Layer", "Feature Service", "jsmith")
    dep    = RemapCandidate("ccc", "Dashboard", "Dashboard", "kwilson")
    preview = RemapPreview(from_item=from_c, to_item=to_c, dependents=[dep])
    assert preview.from_item.item_id == "aaa"
    assert preview.to_item.item_id == "bbb"
    assert len(preview.dependents) == 1


def test_remap_outcome_success():
    o = RemapOutcome(item_id="ccc", title="Dashboard", success=True, error=None)
    assert o.success is True
    assert o.error is None


def test_remap_outcome_failure():
    o = RemapOutcome(item_id="ccc", title="Dashboard", success=False, error="type mismatch")
    assert o.success is False
    assert o.error == "type mismatch"


# ── Task 2: ItemGraphRemapper.__init__ and preview() ───────────────────────
from unittest.mock import MagicMock, patch
from tests.conftest import make_mock_node, make_mock_graph


def _make_gis(from_item=None, to_item=None, extra_items=None):
    """Return a mock GIS whose content.get() returns items by ID."""
    items = {}
    if from_item:
        items[from_item.itemid] = from_item
    if to_item:
        items[to_item.itemid] = to_item
    if extra_items:
        items.update(extra_items)
    gis = MagicMock()
    gis.content.get = MagicMock(side_effect=lambda item_id: items.get(item_id))
    return gis


def _make_portal_item(item_id, title, item_type, owner):
    """Return a mock portal Item object."""
    item = MagicMock()
    item.itemid = item_id
    item.title = title
    item.type = item_type
    item.owner = owner
    return item


def test_preview_resolves_both_items():
    from_portal = _make_portal_item("aaa", "Old Layer", "Feature Service", "jsmith")
    to_portal   = _make_portal_item("bbb", "New Layer", "Feature Service", "jsmith")
    gis = _make_gis(from_portal, to_portal)

    # node for "aaa" (the from item); node "ccc" depends on it
    node_aaa = make_mock_node("aaa", "Old Layer", "Feature Service", "jsmith")
    node_ccc = make_mock_node("ccc", "Dashboard", "Dashboard", "kwilson",
                              contains_ids=["aaa"])

    mock_result = MagicMock()
    mock_result.nodes = [node_aaa, node_ccc]

    with patch("arcgis_item_graph.remapper.ItemGraphQuery") as MockQ:
        MockQ.return_value.query.return_value = mock_result
        from arcgis_item_graph.remapper import ItemGraphRemapper
        r = ItemGraphRemapper(gis=gis, gml_file="outputs/graph.gml")
        preview = r.preview("aaa", "bbb")

    assert preview.from_item.item_id == "aaa"
    assert preview.from_item.title == "Old Layer"
    assert preview.to_item.item_id == "bbb"
    assert preview.to_item.title == "New Layer"
    assert len(preview.dependents) == 1
    assert preview.dependents[0].item_id == "ccc"


def test_preview_from_item_not_found():
    gis = MagicMock()
    gis.content.get = MagicMock(return_value=None)
    from arcgis_item_graph.remapper import ItemGraphRemapper
    r = ItemGraphRemapper(gis=gis, gml_file="outputs/graph.gml")
    import pytest
    with pytest.raises(ValueError, match="not found in portal"):
        r.preview("missing_id", "bbb")


def test_preview_to_item_not_found():
    from_portal = _make_portal_item("aaa", "Old Layer", "Feature Service", "jsmith")
    gis = MagicMock()
    gis.content.get = MagicMock(side_effect=lambda i: from_portal if i == "aaa" else None)
    from arcgis_item_graph.remapper import ItemGraphRemapper
    r = ItemGraphRemapper(gis=gis, gml_file="outputs/graph.gml")
    import pytest
    with pytest.raises(ValueError, match="not found in portal"):
        r.preview("aaa", "missing_id")


def test_preview_no_dependents():
    from_portal = _make_portal_item("aaa", "Old Layer", "Feature Service", "jsmith")
    to_portal   = _make_portal_item("bbb", "New Layer", "Feature Service", "jsmith")
    gis = _make_gis(from_portal, to_portal)

    # No node contains "aaa"
    node_aaa = make_mock_node("aaa", "Old Layer", "Feature Service", "jsmith")
    mock_result = MagicMock()
    mock_result.nodes = [node_aaa]

    with patch("arcgis_item_graph.remapper.ItemGraphQuery") as MockQ:
        MockQ.return_value.query.return_value = mock_result
        from arcgis_item_graph.remapper import ItemGraphRemapper
        r = ItemGraphRemapper(gis=gis, gml_file="outputs/graph.gml")
        preview = r.preview("aaa", "bbb")

    assert preview.dependents == []


# ── Task 3: execute() ──────────────────────────────────────────────────────

def _make_preview(from_id="aaa", to_id="bbb", dependent_ids=None):
    """Helper to build a RemapPreview for execute() tests."""
    from arcgis_item_graph.remapper import RemapCandidate, RemapPreview
    from_item = RemapCandidate(from_id, "Old Layer", "Feature Service", "jsmith")
    to_item   = RemapCandidate(to_id,   "New Layer", "Feature Service", "jsmith")
    dependents = [
        RemapCandidate(d, f"Item {d}", "Dashboard", "kwilson")
        for d in (dependent_ids or ["ccc"])
    ]
    return RemapPreview(from_item=from_item, to_item=to_item, dependents=dependents)


def test_execute_all_success():
    preview = _make_preview(dependent_ids=["ccc", "ddd"])
    mock_item = MagicMock()
    mock_item.remap_data = MagicMock(return_value=True)

    gis = MagicMock()
    gis.content.get = MagicMock(return_value=mock_item)

    from arcgis_item_graph.remapper import ItemGraphRemapper
    r = ItemGraphRemapper(gis=gis, gml_file="outputs/graph.gml")
    outcomes = r.execute(preview)

    assert len(outcomes) == 2
    assert all(o.success for o in outcomes)
    assert all(o.error is None for o in outcomes)
    mock_item.remap_data.assert_called_with({"aaa": "bbb"}, force=False)


def test_execute_partial_failure():
    preview = _make_preview(dependent_ids=["ccc", "ddd"])

    ok_item = MagicMock()
    ok_item.remap_data = MagicMock(return_value=True)
    fail_item = MagicMock()
    fail_item.remap_data = MagicMock(return_value=False)

    gis = MagicMock()
    gis.content.get = MagicMock(side_effect=lambda i: ok_item if i == "ccc" else fail_item)

    from arcgis_item_graph.remapper import ItemGraphRemapper
    r = ItemGraphRemapper(gis=gis, gml_file="outputs/graph.gml")
    outcomes = r.execute(preview)

    succeeded = [o for o in outcomes if o.success]
    failed    = [o for o in outcomes if not o.success]
    assert len(succeeded) == 1
    assert len(failed) == 1
    assert failed[0].error is not None


def test_execute_force_flag():
    preview = _make_preview()
    mock_item = MagicMock()
    mock_item.remap_data = MagicMock(return_value=True)

    gis = MagicMock()
    gis.content.get = MagicMock(return_value=mock_item)

    from arcgis_item_graph.remapper import ItemGraphRemapper
    r = ItemGraphRemapper(gis=gis, gml_file="outputs/graph.gml")
    r.execute(preview, force=True)

    mock_item.remap_data.assert_called_with({"aaa": "bbb"}, force=True)


def test_execute_item_not_found_in_portal():
    preview = _make_preview()
    gis = MagicMock()
    gis.content.get = MagicMock(return_value=None)  # item vanished

    from arcgis_item_graph.remapper import ItemGraphRemapper
    r = ItemGraphRemapper(gis=gis, gml_file="outputs/graph.gml")
    outcomes = r.execute(preview)

    assert outcomes[0].success is False
    assert "not found" in outcomes[0].error


# ── Task 4: write_manifest() and preview_rollback() ───────────────────────
import json
import tempfile
from pathlib import Path


def test_write_manifest_returns_path(tmp_path):
    preview  = _make_preview(dependent_ids=["ccc", "ddd"])
    outcomes = [
        __import__("arcgis_item_graph.remapper", fromlist=["RemapOutcome"]).RemapOutcome(
            "ccc", "Item ccc", True, None
        ),
        __import__("arcgis_item_graph.remapper", fromlist=["RemapOutcome"]).RemapOutcome(
            "ddd", "Item ddd", False, "type mismatch"
        ),
    ]
    from arcgis_item_graph.remapper import ItemGraphRemapper
    r = ItemGraphRemapper(gis=MagicMock(), gml_file="outputs/graph.gml")
    path = r.write_manifest(preview, outcomes, output_dir=str(tmp_path))

    assert path is not None
    assert path.exists()
    data = json.loads(path.read_text())
    assert data["from_id"] == "aaa"
    assert data["to_id"] == "bbb"
    assert data["remapped"] == ["ccc"]   # only succeeded
    assert "timestamp" in data


def test_write_manifest_returns_none_when_all_failed(tmp_path):
    preview  = _make_preview()
    from arcgis_item_graph.remapper import RemapOutcome, ItemGraphRemapper
    outcomes = [RemapOutcome("ccc", "Item ccc", False, "error")]
    r = ItemGraphRemapper(gis=MagicMock(), gml_file="outputs/graph.gml")
    path = r.write_manifest(preview, outcomes, output_dir=str(tmp_path))
    assert path is None


def test_preview_rollback_reverses_mapping(tmp_path):
    # Write a manifest
    manifest = {
        "from_id": "aaa",
        "to_id": "bbb",
        "timestamp": "2026-03-24T10:00:00",
        "remapped": ["ccc"],
        "force": False,
    }
    manifest_path = tmp_path / "rollback_test.json"
    manifest_path.write_text(json.dumps(manifest))

    # Mock portal items
    item_bbb = _make_portal_item("bbb", "New Layer", "Feature Service", "jsmith")
    item_aaa = _make_portal_item("aaa", "Old Layer", "Feature Service", "jsmith")
    item_ccc = _make_portal_item("ccc", "Dashboard", "Dashboard", "kwilson")

    gis = MagicMock()
    lookup = {"bbb": item_bbb, "aaa": item_aaa, "ccc": item_ccc}
    gis.content.get = MagicMock(side_effect=lambda i: lookup.get(i))

    from arcgis_item_graph.remapper import ItemGraphRemapper
    r = ItemGraphRemapper(gis=gis, gml_file="outputs/graph.gml")
    preview = r.preview_rollback(str(manifest_path))

    # Rollback reverses direction: from=bbb, to=aaa
    assert preview.from_item.item_id == "bbb"
    assert preview.to_item.item_id == "aaa"
    assert len(preview.dependents) == 1
    assert preview.dependents[0].item_id == "ccc"


# ── Task 5: package exports ────────────────────────────────────────────────

def test_package_exports():
    from arcgis_item_graph import ItemGraphRemapper, RemapPreview, RemapOutcome
    assert ItemGraphRemapper is not None
    assert RemapPreview is not None
    assert RemapOutcome is not None
