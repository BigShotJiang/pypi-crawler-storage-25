"""MCP Server exposing task orchestrator tools."""

import json
from mcp.server.fastmcp import FastMCP
from . import db, engine
from .schemas import get_schemas, load_schemas, get_schema_for_item

mcp = FastMCP(
    "task-orchestrator",
    instructions="""Task Orchestrator — persistent work item graph for AI agents.
WorkItems flow: queue → work → review → done. Use triggers: start, complete, block, resume, cancel, reopen.
Start sessions with get_context() to see current state. Use get_next_item() for priority-ranked next action.""",
)


def _json(obj) -> str:
    return json.dumps(obj, default=str)


def _err(e: Exception) -> str:
    return _json({"error": str(e)})


@mcp.tool()
def manage_items(operation: str, title: str = "", item_id: str = "", description: str = "",
                 parent_id: str = "", priority: str = "medium", item_type: str = "", tags: str = "") -> str:
    """Create, update, or delete work items.

    Operations: create, update, delete.
    Priority: critical, high, medium, low.
    Items support hierarchy via parent_id (max 4 levels deep).
    """
    try:
        if operation == "create":
            return _json(engine.create_item(title=title, description=description,
                                            parent_id=parent_id or None, priority=priority,
                                            item_type=item_type, tags=tags))
        elif operation == "update":
            kwargs = {}
            if title: kwargs["title"] = title
            if description: kwargs["description"] = description
            if priority: kwargs["priority"] = priority
            if item_type: kwargs["item_type"] = item_type
            if tags: kwargs["tags"] = tags
            return _json(engine.update_item(item_id, **kwargs))
        elif operation == "delete":
            return _json({"deleted": engine.delete_item(item_id)})
        return _json({"error": f"Invalid operation: {operation}. Use: create, update, delete"})
    except Exception as e:
        return _err(e)


@mcp.tool()
def query_items(operation: str = "list", item_id: str = "", status: str = "",
                parent_id: str = "", priority: str = "", search: str = "",
                include_ancestors: bool = False, limit: int = 50, offset: int = 0) -> str:
    """Query work items. Operations: get (by id), list (with filters), children (of parent), overview (status counts).

    Filters: status (queue/work/review/done/blocked/cancelled), priority, parent_id, search text.
    Use include_ancestors=true with get to see the full parent chain.
    """
    try:
        if operation == "get":
            result = engine.get_item(item_id)
            if not result:
                return _json({"error": f"Item {item_id} not found"})
            if include_ancestors:
                result["ancestors"] = engine.get_ancestors(item_id)
            return _json(result)
        elif operation == "children":
            return _json(engine.get_children(parent_id or item_id))
        elif operation == "overview":
            ctx = engine.get_context()
            return _json({"counts": ctx["counts"], "active_count": len(ctx["active"]),
                          "blocked_count": len(ctx["blocked"])})
        return _json(engine.query_items(status=status or None, parent_id=parent_id or None,
                                        priority=priority or None, search=search or None,
                                        limit=limit, offset=offset))
    except Exception as e:
        return _err(e)


@mcp.tool()
def advance_item(item_id: str, trigger: str) -> str:
    """Advance a work item through its workflow using a trigger.

    Triggers: start (next phase), complete (jump to done), block (pause), resume (unblock),
    cancel (close), reopen (done/cancelled → queue).
    Flow: queue → work → review → done. Checks dependency satisfaction before advancing.
    Returns the updated item plus any newly unblocked items.
    """
    try:
        return _json(engine.advance_item(item_id, trigger))
    except Exception as e:
        return _err(e)


@mcp.tool()
def get_next_status(item_id: str, trigger: str) -> str:
    """Read-only preview of what would happen with a given trigger.

    Returns can_advance (bool), current status, next status, and any blockers.
    Use before advance_item to check feasibility without side effects.
    """
    return _json(engine.get_next_status(item_id, trigger))


@mcp.tool()
def get_next_item() -> str:
    """Get the highest-priority actionable item with no unsatisfied dependencies.

    Returns the single best next item to work on, or null if nothing is actionable.
    Priority: items already in 'work' first, then by priority (critical > high > medium > low).
    """
    result = engine.get_next_item()
    return _json(result) if result else _json({"message": "No actionable items"})


@mcp.tool()
def get_context(item_id: str = "", include_ancestors: bool = False) -> str:
    """Get context snapshot for session resume or item inspection.

    Without item_id: global dashboard — status counts, active items, blocked items, next action.
    With item_id: item detail — children, notes, blockers, can_advance flag.
    Use include_ancestors=true to get the full parent chain.
    Call this at session start to understand current work state.
    """
    try:
        return _json(engine.get_context(item_id or None, include_ancestors=include_ancestors))
    except Exception as e:
        return _err(e)


@mcp.tool()
def get_blocked_items() -> str:
    """Get all blocked items — both explicitly blocked and those with unsatisfied dependencies.

    Use to identify what's stuck and what needs to be resolved to unblock progress.
    """
    return _json(engine.get_blocked_items())


@mcp.tool()
def manage_notes(operation: str, item_id: str, key: str = "", body: str = "", role: str = "queue") -> str:
    """Manage notes on work items. Notes are persistent documentation per phase.

    Operations: upsert (create/update by key), delete, list (all notes for item).
    Role: queue, work, review — indicates which phase the note belongs to.
    Use notes to capture requirements, decisions, done-criteria, and handoff context.
    """
    try:
        if operation == "upsert":
            return _json(engine.upsert_note(item_id, key, body, role))
        elif operation == "delete":
            return _json({"deleted": engine.delete_note(item_id, key)})
        elif operation == "list":
            return _json(engine.get_notes(item_id))
        return _json({"error": f"Invalid operation: {operation}. Use: upsert, delete, list"})
    except Exception as e:
        return _err(e)


@mcp.tool()
def query_notes(item_id: str, key: str = "", include_body: bool = True) -> str:
    """Query notes for a work item. Use include_body=false for token-efficient metadata checks.

    With key: get a single note. Without key: list all notes for the item.
    """
    try:
        if key:
            from .db import get_connection
            conn = get_connection()
            try:
                row = conn.execute("SELECT * FROM notes WHERE item_id=? AND key=?", (item_id, key)).fetchone()
                return _json(dict(row) if row else {"error": f"Note '{key}' not found on item {item_id}"})
            finally:
                conn.close()
        return _json(engine.get_notes(item_id, include_body=include_body))
    except Exception as e:
        return _err(e)


@mcp.tool()
def manage_dependencies(operation: str, from_id: str = "", to_id: str = "",
                        item_id: str = "", direction: str = "both",
                        item_ids: str = "", pattern: str = "linear") -> str:
    """Manage dependency edges between work items.

    Operations: add (from_id blocks to_id), remove, query (get deps for item_id), pattern.
    Direction for query: inbound, outbound, both.
    Pattern operation: create deps using shortcuts — linear, fan-out, fan-in.
      item_ids: comma-separated list of item IDs for pattern creation.
    Dependencies enforce ordering — blocked items cannot advance until blockers are done.
    """
    try:
        if operation == "add":
            return _json(engine.add_dependency(from_id, to_id))
        elif operation == "remove":
            return _json({"removed": engine.remove_dependency(from_id, to_id)})
        elif operation == "query":
            return _json(engine.get_dependencies(item_id or from_id, direction))
        elif operation == "pattern":
            ids = [i.strip() for i in item_ids.split(",") if i.strip()]
            return _json(engine.add_dependency_pattern(ids, pattern))
        return _json({"error": f"Invalid operation: {operation}. Use: add, remove, query, pattern"})
    except Exception as e:
        return _err(e)


@mcp.tool()
def query_dependencies(item_id: str, direction: str = "outbound",
                       neighbors_only: bool = True, max_depth: int = 10) -> str:
    """Query dependencies with optional BFS traversal.

    neighbors_only=true: direct edges only (fast). false: full BFS graph traversal.
    Direction: outbound (what this blocks), inbound (what blocks this).
    """
    try:
        if neighbors_only:
            return _json(engine.get_dependencies(item_id, direction))
        return _json(engine.query_dependencies_bfs(item_id, direction, max_depth))
    except Exception as e:
        return _err(e)


@mcp.tool()
def create_work_tree(root_title: str, root_description: str = "", root_priority: str = "medium",
                     children_json: str = "[]", deps_json: str = "[]") -> str:
    """Atomically create a root item + children + dependencies in one call.

    children_json: JSON array of {ref, title, description, priority} objects.
    deps_json: JSON array of {from, to} objects using ref names.
    Example: children=[{"ref":"a","title":"Schema"},{"ref":"b","title":"API"}], deps=[{"from":"a","to":"b"}]
    """
    try:
        children = json.loads(children_json) if isinstance(children_json, str) else children_json
        deps = json.loads(deps_json) if isinstance(deps_json, str) else deps_json
        return _json(engine.create_work_tree(
            root={"title": root_title, "description": root_description, "priority": root_priority},
            children=children, deps=deps,
        ))
    except Exception as e:
        return _err(e)


@mcp.tool()
def complete_tree(parent_id: str) -> str:
    """Batch-complete all descendants of a parent item in topological order.

    Skips items already in terminal status. Reports items that couldn't be completed (e.g., blocked by deps).
    """
    try:
        return _json(engine.complete_tree(parent_id))
    except Exception as e:
        return _err(e)


@mcp.tool()
def manage_schemas(operation: str = "list", schema_name: str = "", item_id: str = "") -> str:
    """View note schemas and check gate status for items.

    Operations:
    - list: show all loaded schemas
    - get: show a specific schema by name
    - check: check gate status for an item (requires item_id)
    - reload: reload schemas from config file
    """
    try:
        if operation == "list":
            return _json(get_schemas())
        elif operation == "get":
            schemas = get_schemas()
            if schema_name not in schemas:
                return _json({"error": f"Schema '{schema_name}' not found", "available": list(schemas.keys())})
            return _json(schemas[schema_name])
        elif operation == "check":
            item = engine.get_item(item_id)
            if not item:
                return _json({"error": f"Item {item_id} not found"})
            schema = get_schema_for_item(item.get("item_type", ""), item.get("tags", ""))
            if not schema:
                return _json({"has_schema": False, "can_advance": True})
            from .db import get_connection
            conn = get_connection()
            try:
                notes = [dict(r) for r in conn.execute(
                    "SELECT * FROM notes WHERE item_id=?", (item_id,)).fetchall()]
            finally:
                conn.close()
            from .schemas import check_gate
            # Check gate for next natural transition
            next_status = engine.TRANSITIONS.get("start", {}).get(item["status"])
            if not next_status:
                return _json({"has_schema": True, "schema": schema["name"],
                              "status": item["status"], "can_advance": item["status"] in engine.TERMINAL})
            gate = check_gate(item, notes, next_status)
            return _json({"has_schema": True, "schema": schema["name"], "lifecycle": schema["lifecycle"],
                          **gate})
        elif operation == "reload":
            result = load_schemas()
            return _json({"reloaded": True, "schemas": list(result.keys())})
        return _json({"error": f"Invalid operation: {operation}. Use: list, get, check, reload"})
    except Exception as e:
        return _err(e)


def main():
    db.init_db()
    mcp.run()


if __name__ == "__main__":
    main()
