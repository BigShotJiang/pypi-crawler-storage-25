# -*- coding: utf-8 -*-
"""Round-trip test that locks down the v2 NeXus on-disk format.

Acts as the safety net for the upcoming nexusformat-based writer
migration: we exercise the *current* h5py-based writer end-to-end,
then open the result with ``nexusformat.nxload`` and assert the tree
shape (NX_class, signal/axes, dataset shapes, units, mandatory
groups).  Any future writer that produces the same assertions will
be format-compatible with everything that already reads these files.

Why a synthetic sphere (not a real EwaldArch + pyFAI integrator):
constructing :class:`EwaldArch` pulls in pyFAI's azimuthal
integrator just to satisfy ``setup_integrator()`` in __init__.  The
writer never touches the integrator — it only reads attribute trees
off arches.  Duck-typed objects with the right attrs are enough and
keep the test fast / dep-free.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

# nexusformat is the read-side gate.  If it isn't installed, skip;
# the test is the format-validation contract and only meaningful
# with the library present.
nx = pytest.importorskip("nexusformat.nexus")


# ---------------------------------------------------------------------------
# Synthetic sphere fixture
# ---------------------------------------------------------------------------

N_FRAMES = 4
N_Q = 32
N_CHI = 16


class _DuckResult1D:
    """Duck-typed IntegrationResult1D — only the attrs the writer reads."""

    def __init__(self, radial, intensity, sigma=None, unit="q_A^-1"):
        self.radial = np.asarray(radial, dtype=np.float32)
        self.intensity = np.asarray(intensity, dtype=np.float32)
        self.sigma = (
            np.asarray(sigma, dtype=np.float32) if sigma is not None else None
        )
        self.unit = unit


class _DuckResult2D:
    """Duck-typed IntegrationResult2D — note xdart's per-frame shape is
    ``(nq, nchi)`` so the writer transposes to ``(nchi, nq)`` before
    stacking into the (N, nchi, nq) tensor."""

    def __init__(self, radial, azimuthal, intensity,
                 unit="q_A^-1", azimuthal_unit="deg"):
        self.radial = np.asarray(radial, dtype=np.float32)
        self.azimuthal = np.asarray(azimuthal, dtype=np.float32)
        self.intensity = np.asarray(intensity, dtype=np.float32)
        self.unit = unit
        self.azimuthal_unit = azimuthal_unit
        self.sigma = None


class _DuckPONI:
    """Duck-typed PONI — six pyFAI geometry scalars."""

    def __init__(self):
        self.dist = 0.1
        self.poni1 = 0.05
        self.poni2 = 0.05
        self.rot1 = 0.0
        self.rot2 = 0.0
        self.rot3 = 0.0


class _DuckArch:
    """Minimal duck-typed EwaldArch."""

    def __init__(self, idx, *, nq=N_Q, nchi=N_CHI, seed=0):
        rng = np.random.default_rng(seed + idx)
        radial = np.linspace(0.5, 5.0, nq, dtype=np.float32)
        azim = np.linspace(-180.0, 180.0, nchi, endpoint=False, dtype=np.float32)

        self.idx = int(idx)
        self.poni = _DuckPONI()
        self.source_file = f"frame_{idx:04d}.tif"
        # R2: per-file frame index — for single-frame TIFs always 0.
        # Test cases for multi-frame sources (e.g. Eiger external links)
        # set this to the offset within the source file.
        self.source_frame_idx = 0
        self.skip_map_raw = True
        self.map_raw = None
        self.bg_raw = 0
        self.mask = None
        self.int_1d = _DuckResult1D(
            radial=radial,
            intensity=rng.random(nq, dtype=np.float32),
            sigma=rng.random(nq, dtype=np.float32) * 0.1,
        )
        self.int_2d = _DuckResult2D(
            radial=radial,
            azimuthal=azim,
            intensity=rng.random((nq, nchi), dtype=np.float32),  # (nq, nchi)
        )
        self.gi_1d = {}
        self.gi_2d = {}
        # Thumbnail mirrors what arch.make_thumbnail produces — small 2D float.
        self.thumbnail = rng.random((64, 64), dtype=np.float32)


class _DuckArches:
    """Minimal ArchSeries stand-in for the writer tests.

    Provides the three interfaces the writer needs:

    * ``.index`` — list of frame indices, matching
      :class:`ArchSeries.index` (an attribute, not the inherited
      ``list.index`` method that the previous fixture exposed).
    * ``arches[idx]`` — fetch the arch with that *frame* index.
    * ``list(arches)`` — iterate arches in index order.

    Real ArchSeries adds lazy-disk-load + an in-memory cache; this
    duck stores everything in a dict for in-memory speed.
    """

    def __init__(self, arches):
        self._by_idx = {a.idx: a for a in arches}
        self.index = [a.idx for a in arches]
        # Mirror ArchSeries._in_memory — the writer's R4 helpers
        # (_representative_poni, _write_per_frame_metadata) read this
        # directly to avoid materialising the full arch list on every
        # save.  Tests use the same dict as _by_idx so every arch is
        # always "in memory" (real ArchSeries caps this at 64 with
        # FIFO eviction; tests don't need to exercise that path).
        self._in_memory = self._by_idx

    def __iter__(self):
        return (self._by_idx[i] for i in self.index)

    def __getitem__(self, idx):
        return self._by_idx[idx]

    def __len__(self):
        return len(self.index)

    def append(self, arch):
        """Extend the series — used by the new write-then-extend test."""
        self._by_idx[arch.idx] = arch
        if arch.idx not in self.index:
            self.index.append(arch.idx)


class _DuckSphere:
    """Minimal duck-typed EwaldSphere."""

    def __init__(self, arches, *, scan_data=None, geometry=None,
                 global_mask=None):
        self.arches = _DuckArches(arches)
        self.scan_data = scan_data if scan_data is not None else pd.DataFrame()
        self.bai_1d_args = {"numpoints": N_Q}
        self.bai_2d_args = {"npt_rad": N_Q, "npt_azim": N_CHI}
        self.mg_args = {"wavelength": 1.0e-10}
        self.geometry = geometry
        self.global_mask = global_mask
        self.stitched_1d = None
        self.stitched_2d = None
        # Stitching writes only happen with finalize=True; not exercised here.


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def written_nxs(tmp_path):
    """Build a synthetic 4-frame sphere and run it through the writer."""
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus

    arches = [_DuckArch(idx=i) for i in range(N_FRAMES)]
    scan_data = pd.DataFrame({
        "tth": np.linspace(10.0, 14.0, N_FRAMES, dtype=np.float32),
        "th": np.linspace(0.0, 0.3, N_FRAMES, dtype=np.float32),
        "i0": np.linspace(1e6, 1.2e6, N_FRAMES, dtype=np.float32),
    })
    # Mark a couple of pixels as masked so we can assert the mask group
    # is written.  Indices are flat-relative to a notional (256, 256)
    # detector — the values are arbitrary; the writer just stores them.
    global_mask = np.array([0, 1, 256, 65535], dtype=np.int64)

    sphere = _DuckSphere(arches, scan_data=scan_data, global_mask=global_mask)

    path = tmp_path / "roundtrip.nxs"
    save_sphere_to_nexus(sphere, path, mode="w", finalize=False)
    return path


@pytest.fixture
def written_nxs_with_stitched(tmp_path):
    """4-frame sphere whose ``stitched_1d``/``stitched_2d`` are populated.

    Exercises the ``finalize=True`` path of
    :func:`save_sphere_to_nexus`, which writes the stitched outputs
    only on the final save of the scan.
    """
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus

    nq, nchi = 64, 24
    s1 = _DuckResult1D(
        radial=np.linspace(0.5, 5.0, nq, dtype=np.float32),
        intensity=np.random.default_rng(7).random(nq, dtype=np.float32),
        sigma=np.full(nq, 0.05, dtype=np.float32),
    )
    s2 = _DuckResult2D(
        radial=np.linspace(0.5, 5.0, nq, dtype=np.float32),
        azimuthal=np.linspace(-180, 180, nchi, endpoint=False,
                              dtype=np.float32),
        # Stitched 2D intensity is stored in the natural (nchi, nq) shape
        # (no transpose); this matches how stitch_2d returns its result.
        intensity=np.random.default_rng(8).random((nchi, nq), dtype=np.float32),
    )

    arches = [_DuckArch(idx=i) for i in range(N_FRAMES)]
    sphere = _DuckSphere(
        arches,
        scan_data=pd.DataFrame({"tth": np.linspace(10, 14, N_FRAMES,
                                                   dtype=np.float32)}),
    )
    sphere.stitched_1d = s1
    sphere.stitched_2d = s2

    path = tmp_path / "stitched.nxs"
    save_sphere_to_nexus(sphere, path, mode="w", finalize=True)
    return path, nq, nchi


@pytest.fixture
def written_nxs_with_geometry(tmp_path):
    """4-frame sphere WITH a DiffractometerGeometry attached.

    Exercises the positioner + per-frame-geometry write paths that the
    bare ``written_nxs`` fixture doesn't touch.
    """
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus
    from ssrl_xrd_tools.core.geometry import DiffractometerGeometry

    geom = DiffractometerGeometry.two_circle(tth="tth", th="th")

    arches = [_DuckArch(idx=i) for i in range(N_FRAMES)]
    scan_data = pd.DataFrame({
        "tth": np.linspace(10.0, 14.0, N_FRAMES, dtype=np.float32),
        "th": np.linspace(0.0, 0.3, N_FRAMES, dtype=np.float32),
    })
    sphere = _DuckSphere(arches, scan_data=scan_data, geometry=geom)

    path = tmp_path / "geometry.nxs"
    save_sphere_to_nexus(sphere, path, mode="w", finalize=False)
    return path


# ---------------------------------------------------------------------------
# Tree-shape assertions via nexusformat
# ---------------------------------------------------------------------------

def test_nxload_opens_cleanly(written_nxs):
    """The file is at minimum a valid NeXus tree per nxload."""
    root = nx.nxload(str(written_nxs))
    assert "entry" in root
    assert root["entry"].nxclass == "NXentry"


def test_entry_attrs(written_nxs):
    """NXentry has the expected class + default plot pointer."""
    root = nx.nxload(str(written_nxs))
    e = root["entry"]
    assert e.nxclass == "NXentry"
    # @default points at the auto-plot target — convention says NXdata.
    assert e.attrs.get("default") == "integrated_1d"


def test_integrated_1d_nxdata(written_nxs):
    """The stacked 1D pattern is an NXdata with signal/axes/units."""
    root = nx.nxload(str(written_nxs))
    g = root["entry/integrated_1d"]
    assert g.nxclass == "NXdata"
    assert g.attrs["signal"] == "intensity"
    axes = list(g.attrs["axes"])
    assert axes == ["frame_index", "q"]

    # Shape: (N_FRAMES, N_Q)
    assert g["intensity"].shape == (N_FRAMES, N_Q)
    assert g["q"].shape == (N_Q,)
    assert g["frame_index"].shape == (N_FRAMES,)
    assert g["sigma"].shape == (N_FRAMES, N_Q)

    # Units on the radial axis
    q_units = g["q"].attrs.get("units", "")
    assert q_units in ("1/angstrom", "1/nm")


def test_integrated_2d_nxdata(written_nxs):
    """The stacked 2D cake is an NXdata with axes [frame_index, chi, q]."""
    root = nx.nxload(str(written_nxs))
    g = root["entry/integrated_2d"]
    assert g.nxclass == "NXdata"
    assert g.attrs["signal"] == "intensity"
    axes = list(g.attrs["axes"])
    assert axes == ["frame_index", "chi", "q"]

    # Writer transposes per-frame from xdart's (nq, nchi) into (nchi, nq),
    # so the stacked tensor is (N_FRAMES, N_CHI, N_Q).
    assert g["intensity"].shape == (N_FRAMES, N_CHI, N_Q)
    assert g["q"].shape == (N_Q,)
    assert g["chi"].shape == (N_CHI,)

    assert g["chi"].attrs.get("units") in ("deg", "rad")


def test_frames_group_and_thumbnails(written_nxs):
    """Per-frame metadata lives under NXcollection/frames/frame_NNNN."""
    root = nx.nxload(str(written_nxs))
    frames = root["entry/frames"]
    assert frames.nxclass == "NXcollection"
    for i in range(N_FRAMES):
        sub = frames[f"frame_{i:04d}"]
        assert sub.nxclass == "NXcollection"
        # Thumbnail is uncompressed uint8/16 with vmin/vmax/dtype attrs.
        thumb = sub["thumbnail"]
        assert "vmin" in thumb.attrs
        assert "vmax" in thumb.attrs
        assert thumb.attrs["dtype"] in ("uint8", "uint16")
        # R2 source ref: path + frame_index always present when the
        # arch carried a source_file (every test arch does).
        assert "source" in sub
        src = sub["source"]
        assert src.nxclass == "NXcollection"
        assert "path" in src
        assert "frame_index" in src
        # The duck fixture sets source_file = "frame_NNNN.tif" and
        # source_frame_idx = 0 — those should round-trip verbatim.
        path = src["path"].nxdata
        if isinstance(path, bytes):
            path = path.decode("utf-8")
        assert path == f"frame_{i:04d}.tif"
        assert int(src["frame_index"].nxdata) == 0


def test_source_ref_multiframe(tmp_path):
    """Eiger-shaped source ref: same source_file, varying frame_index."""
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus
    import h5py

    arches = [_DuckArch(idx=i) for i in range(N_FRAMES)]
    # Mimic a NeXus wrangler stamp: every frame points to the same
    # master file, source_frame_idx = global index within the master.
    for i, a in enumerate(arches):
        a.source_file = "scan_001_master.h5"
        a.source_frame_idx = 1000 + i  # arbitrary global offset

    sphere = _DuckSphere(arches)
    path = tmp_path / "multiframe.nxs"
    save_sphere_to_nexus(sphere, path, entry="entry", finalize=False)

    with h5py.File(path, "r") as f:
        for i in range(N_FRAMES):
            src = f[f"entry/frames/frame_{i:04d}/source"]
            v = src["path"][()]
            if isinstance(v, bytes):
                v = v.decode("utf-8")
            assert v == "scan_001_master.h5"
            assert int(src["frame_index"][()]) == 1000 + i


def test_replace_frame_indices_updates_only_targets(tmp_path):
    """Replace mode: slice-assign new int_1d/int_2d over the listed
    frames; leave all other rows byte-identical.
    """
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus
    import h5py

    n = 5
    arches = [_DuckArch(idx=i) for i in range(n)]
    sphere = _DuckSphere(arches)
    path = tmp_path / "replace.nxs"
    save_sphere_to_nexus(sphere, path, entry="entry", finalize=False)

    # Snapshot original on-disk rows so we can verify untouched frames.
    with h5py.File(path, "r") as f:
        orig_1d = np.asarray(f["entry/integrated_1d/intensity"][()])
        orig_2d = np.asarray(f["entry/integrated_2d/intensity"][()])
        orig_frame_idx = list(f["entry/integrated_1d/frame_index"][()])
        assert orig_frame_idx == list(range(n))

    # Simulate a GUI reintegration: change int_1d/int_2d on frames 1 and 3.
    rng = np.random.default_rng(999)
    new_1d_arr = rng.random(N_Q, dtype=np.float32)
    new_2d_arr = rng.random((N_Q, N_CHI), dtype=np.float32)
    targets = [1, 3]
    for fi in targets:
        a = arches[fi]
        a.int_1d = _DuckResult1D(
            radial=np.asarray(a.int_1d.radial),
            intensity=new_1d_arr.copy(),
            sigma=a.int_1d.sigma,
        )
        a.int_2d = _DuckResult2D(
            radial=np.asarray(a.int_2d.radial),
            azimuthal=np.asarray(a.int_2d.azimuthal),
            intensity=new_2d_arr.copy(),
        )

    save_sphere_to_nexus(
        sphere, path, entry="entry", finalize=False,
        replace_frame_indices=targets,
    )

    with h5py.File(path, "r") as f:
        # Frame_index order is unchanged (replace doesn't reorder).
        assert list(f["entry/integrated_1d/frame_index"][()]) == list(range(n))
        new_on_disk_1d = np.asarray(f["entry/integrated_1d/intensity"][()])
        new_on_disk_2d = np.asarray(f["entry/integrated_2d/intensity"][()])

    # Targets: rows updated to the new values.
    for fi in targets:
        assert np.allclose(new_on_disk_1d[fi], new_1d_arr)
        # 2D layout on disk is (frame, chi, q); arch int_2d is (q, chi).
        assert np.allclose(new_on_disk_2d[fi], new_2d_arr.T)

    # Non-targets: rows byte-identical to original.
    untouched = [i for i in range(n) if i not in targets]
    for fi in untouched:
        assert np.array_equal(new_on_disk_1d[fi], orig_1d[fi])
        assert np.array_equal(new_on_disk_2d[fi], orig_2d[fi])


def test_replace_with_no_existing_file_degrades_to_append(tmp_path):
    """First save with replace_frame_indices set should still succeed —
    no on-disk dataset means there's nothing to replace, so the writer
    falls back to append mode for those frames."""
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus
    import h5py

    arches = [_DuckArch(idx=i) for i in range(3)]
    sphere = _DuckSphere(arches)
    path = tmp_path / "replace_first.nxs"
    # User somehow calls replace before any append save existed.
    save_sphere_to_nexus(
        sphere, path, entry="entry", finalize=False,
        replace_frame_indices=[0, 1, 2],
    )
    # Result: the file was created via the append fallback; all rows
    # present.
    with h5py.File(path, "r") as f:
        assert "entry/integrated_1d/intensity" in f
        assert f["entry/integrated_1d/intensity"].shape == (3, N_Q)


def test_reload_only_flag_round_trips(tmp_path):
    """Frames loaded from disk via _load_arch_v2 should carry
    is_reload_only=True; freshly-integrated arches handed from the
    wrangler should not.
    """
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus
    from xdart.modules.ewald.arch_series import _load_arch_v2
    import h5py

    arches = [_DuckArch(idx=i) for i in range(2)]
    sphere = _DuckSphere(arches)
    path = tmp_path / "reload_flag.nxs"
    save_sphere_to_nexus(sphere, path, entry="entry", finalize=False)

    # Fresh arches (from the wrangler) — default is_reload_only=False.
    from xdart.modules.ewald.arch import EwaldArch
    fresh = EwaldArch(idx=0)
    assert fresh.is_reload_only is False

    # Reloaded arches — the loader stamps the flag.
    with h5py.File(path, "r") as f:
        loaded = _load_arch_v2(f, 0, static=False, gi=False)
    assert loaded.is_reload_only is True


def test_has_reload_only_frames_sphere_helper(tmp_path):
    """EwaldSphere.has_reload_only_frames mirrors the in-memory cache."""
    from xdart.modules.ewald.sphere import EwaldSphere
    from xdart.modules.ewald.arch import EwaldArch

    sphere = EwaldSphere(name='t', data_file=str(tmp_path / 'none.nxs'))

    # No arches → False (nothing to re-integrate, but nothing flagged).
    assert sphere.has_reload_only_frames() is False

    # A fresh arch (wrangler hand-off) — flag stays False.
    fresh = EwaldArch(idx=0)
    sphere.arches.stash(fresh)
    sphere.arches.index.append(0)
    assert sphere.has_reload_only_frames() is False

    # Mark one as reload-only → True.
    fresh.is_reload_only = True
    assert sphere.has_reload_only_frames() is True


def test_acquire_save_reload_reintegrate_save_reload(tmp_path):
    """End-to-end: simulate the acquire → save → reload → reintegrate
    → save → reload workflow that the GUI exercises, verifying that
    the second reload sees the post-reintegration values on disk.

    Uses the real ArchSeries (not the duck) so the test covers the
    actual lazy-load + replace-frames code path.  Re-integration
    here is faked by mutating the int_1d values on the in-memory
    arches — we're testing the writer's replace mode, not pyFAI.
    """
    import h5py
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus
    from xdart.modules.ewald.arch_series import _load_arch_v2

    # --- Phase 1: acquire + save -------------------------------------
    arches = [_DuckArch(idx=i) for i in range(4)]
    sphere = _DuckSphere(arches)
    path = tmp_path / "lifecycle.nxs"
    save_sphere_to_nexus(sphere, path, entry="entry", finalize=True)

    # --- Phase 2: reload --------------------------------------------
    with h5py.File(path, "r") as f:
        original_intensity = f["entry/integrated_1d/intensity"][1].copy()

    # --- Phase 3: simulate reintegration on frames 1 + 2 ------------
    new_intensity_frame1 = np.full(N_Q, 7.0, dtype=np.float32)
    new_intensity_frame2 = np.full(N_Q, 9.0, dtype=np.float32)
    arches[1].int_1d = _DuckResult1D(
        radial=np.asarray(arches[1].int_1d.radial),
        intensity=new_intensity_frame1.copy(),
        sigma=arches[1].int_1d.sigma,
    )
    arches[2].int_1d = _DuckResult1D(
        radial=np.asarray(arches[2].int_1d.radial),
        intensity=new_intensity_frame2.copy(),
        sigma=arches[2].int_1d.sigma,
    )

    # --- Phase 4: save replace --------------------------------------
    save_sphere_to_nexus(
        sphere, path, entry="entry", finalize=False,
        replace_frame_indices=[1, 2],
    )

    # --- Phase 5: reload again, confirm updates persisted -----------
    with h5py.File(path, "r") as f:
        assert np.allclose(f["entry/integrated_1d/intensity"][1],
                           new_intensity_frame1)
        assert np.allclose(f["entry/integrated_1d/intensity"][2],
                           new_intensity_frame2)
        # Frame 1's old value should be different from the new one.
        assert not np.allclose(original_intensity, new_intensity_frame1)
        # The replace save also re-wrote /entry/reduction so the
        # persisted args reflect the (possibly tweaked) integration
        # parameters.
        assert "entry/reduction" in f


def test_replace_with_shape_change_falls_back_to_full_rewrite(tmp_path):
    """C3: when reintegration changes numpoints/npt_*, slice-assign
    can't work — writer should delete the group and rewrite from
    scratch so the q/chi axes refresh too.
    """
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus
    import h5py

    n = 3
    arches = [_DuckArch(idx=i, nq=N_Q, nchi=N_CHI) for i in range(n)]
    sphere = _DuckSphere(arches)
    path = tmp_path / "shape_change.nxs"
    save_sphere_to_nexus(sphere, path, entry="entry", finalize=False)

    with h5py.File(path, "r") as f:
        assert f["entry/integrated_1d/intensity"].shape == (n, N_Q)
        assert f["entry/integrated_2d/intensity"].shape == (n, N_CHI, N_Q)

    # Simulate user changing numpoints from N_Q to N_Q * 2.
    NQ2 = N_Q * 2
    NCHI2 = N_CHI * 2
    rng = np.random.default_rng(7)
    radial_new = np.linspace(0.5, 5.0, NQ2, dtype=np.float32)
    chi_new = np.linspace(-180.0, 180.0, NCHI2, endpoint=False,
                          dtype=np.float32)
    for a in arches:
        a.int_1d = _DuckResult1D(
            radial=radial_new,
            intensity=rng.random(NQ2, dtype=np.float32),
            sigma=rng.random(NQ2, dtype=np.float32) * 0.1,
        )
        a.int_2d = _DuckResult2D(
            radial=radial_new,
            azimuthal=chi_new,
            intensity=rng.random((NQ2, NCHI2), dtype=np.float32),
        )

    # Trigger replace mode for all frames.  Shape change should be
    # detected and the writer should rewrite the stacked datasets +
    # refresh the q/chi axes.
    save_sphere_to_nexus(
        sphere, path, entry="entry", finalize=False,
        replace_frame_indices=[0, 1, 2],
    )

    with h5py.File(path, "r") as f:
        # 1D: new shape, new q axis.
        assert f["entry/integrated_1d/intensity"].shape == (n, NQ2)
        assert f["entry/integrated_1d/q"].shape == (NQ2,)
        # 2D: new (chi, q) row shape, new chi axis.
        assert f["entry/integrated_2d/intensity"].shape == (n, NCHI2, NQ2)
        assert f["entry/integrated_2d/chi"].shape == (NCHI2,)


def test_replace_unknown_frame_idx_is_silent(tmp_path):
    """Listing a frame_idx that doesn't exist on disk: no error, no
    write, other targets still processed."""
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus
    import h5py

    arches = [_DuckArch(idx=i) for i in range(3)]
    sphere = _DuckSphere(arches)
    path = tmp_path / "replace_unknown.nxs"
    save_sphere_to_nexus(sphere, path, entry="entry", finalize=False)

    # Mutate frame 1 only.
    new_arr = np.full(N_Q, 99.0, dtype=np.float32)
    arches[1].int_1d = _DuckResult1D(
        radial=np.asarray(arches[1].int_1d.radial),
        intensity=new_arr.copy(),
        sigma=arches[1].int_1d.sigma,
    )
    # Pass valid + invalid frame idx.
    save_sphere_to_nexus(
        sphere, path, entry="entry", finalize=False,
        replace_frame_indices=[1, 999],
    )
    with h5py.File(path, "r") as f:
        assert np.allclose(f["entry/integrated_1d/intensity"][1], new_arr)


def test_source_ref_omitted_when_no_source_file(tmp_path):
    """No source/ subgroup is written when arch.source_file is empty."""
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus
    import h5py

    arches = [_DuckArch(idx=i) for i in range(2)]
    for a in arches:
        a.source_file = ""  # no source
    sphere = _DuckSphere(arches)
    path = tmp_path / "no_source.nxs"
    save_sphere_to_nexus(sphere, path, entry="entry", finalize=False)

    with h5py.File(path, "r") as f:
        for i in range(2):
            assert "source" not in f[f"entry/frames/frame_{i:04d}"]


def test_instrument_groups(written_nxs):
    """Instrument tree: NXinstrument/NXdetector with mask + PONI scalars."""
    root = nx.nxload(str(written_nxs))
    instr = root["entry/instrument"]
    assert instr.nxclass == "NXinstrument"
    det = instr["detector"]
    assert det.nxclass == "NXdetector"

    # PONI scalars from arches[0] (six numbers)
    for k in ("dist", "poni1", "poni2", "rot1", "rot2", "rot3"):
        assert k in det

    # Global mask (flat pixel indices)
    assert "mask" in det
    assert det["mask"].nxdata.tolist() == [0, 1, 256, 65535]

    # Source/wavelength
    src = instr["source"]
    assert src.nxclass == "NXsource"
    assert "wavelength_A" in src


def test_reduction_provenance(written_nxs):
    """/entry/reduction is an NXprocess with program + versions + config."""
    root = nx.nxload(str(written_nxs))
    red = root["entry/reduction"]
    assert red.nxclass == "NXprocess"
    assert "program" in red
    assert "version" in red
    assert "date" in red
    assert red["versions"].nxclass == "NXcollection"
    assert "config" in red


def test_positioners_groups(written_nxs_with_geometry):
    """With a geometry set, motor positioners get NXsample / NXdetector trees.

    Locks down:
    * ``/entry/sample`` is :class:`NXsample` (not :class:`NXcollection`).
    * ``/entry/instrument/detector`` is :class:`NXdetector` (not
      :class:`NXinstrument` — the old h5py code had this stamped
      wrongly; the typed constructor port fixed it).
    * Each motor is an :class:`NXpositioner` with a ``value`` field
      whose ``@units`` attr is set.
    """
    root = nx.nxload(str(written_nxs_with_geometry))
    e = root["entry"]

    sample = e["sample"]
    assert sample.nxclass == "NXsample"
    assert sample["positioners"].nxclass == "NXcollection"
    th = sample["positioners/th"]
    assert th.nxclass == "NXpositioner"
    assert th["value"].shape == (N_FRAMES,)
    assert th["value"].attrs.get("units") == "deg"

    det = e["instrument/detector"]
    assert det.nxclass == "NXdetector"
    assert det["positioners"].nxclass == "NXcollection"
    tth = det["positioners/tth"]
    assert tth.nxclass == "NXpositioner"
    assert tth["value"].shape == (N_FRAMES,)


def test_per_frame_geometry(written_nxs_with_geometry):
    """``/entry/per_frame_geometry`` is an :class:`NXcollection` of
    derived rot1/rot2/rot3 + optional incident_angle, plus
    ``frame_index``.  Each derived array has a ``@units`` attr.
    """
    root = nx.nxload(str(written_nxs_with_geometry))
    g = root["entry/per_frame_geometry"]
    assert g.nxclass == "NXcollection"
    assert "frame_index" in g
    assert g["frame_index"].shape == (N_FRAMES,)
    # At minimum rot1/rot2/rot3 (the pyFAI per-frame rotations).
    for k in ("rot1", "rot2", "rot3"):
        assert k in g
        assert g[k].shape == (N_FRAMES,)
        assert g[k].attrs.get("units") == "rad"


def test_stitched_outputs(written_nxs_with_stitched):
    """``finalize=True`` writes ``stitched_1d`` / ``stitched_2d`` as
    NXdata with the same signal/axes conventions as their per-frame
    siblings (intensity signal; q on the 1D axis; chi+q on 2D).
    """
    path, nq, nchi = written_nxs_with_stitched
    root = nx.nxload(str(path))
    e = root["entry"]

    s1 = e["stitched_1d"]
    assert s1.nxclass == "NXdata"
    assert s1["intensity"].shape == (nq,)
    assert s1["q"].shape == (nq,)
    assert s1["q"].attrs.get("units") in ("1/angstrom", "1/nm")
    assert s1["sigma"].shape == (nq,)

    s2 = e["stitched_2d"]
    assert s2.nxclass == "NXdata"
    assert s2["intensity"].shape == (nchi, nq)
    assert s2["q"].shape == (nq,)
    assert s2["chi"].shape == (nchi,)
    assert s2["chi"].attrs.get("units") in ("deg", "rad")


def test_h5py_layout_is_idempotent(tmp_path):
    """Calling save_sphere_to_nexus twice on the same file is safe — the
    stacked datasets get replaced cleanly with no leftover ghost entries.

    This guards the idempotent ``_replace_ds`` pattern that the live-
    mode + batch flushes both rely on.
    """
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus

    arches = [_DuckArch(idx=i) for i in range(N_FRAMES)]
    scan_data = pd.DataFrame({
        "tth": np.linspace(10.0, 14.0, N_FRAMES, dtype=np.float32),
    })
    sphere = _DuckSphere(arches, scan_data=scan_data)

    path = tmp_path / "idempotent.nxs"
    save_sphere_to_nexus(sphere, path, mode="w")
    save_sphere_to_nexus(sphere, path, mode="a")

    # Second write should not have produced duplicate keys or shape drift.
    root = nx.nxload(str(path))
    assert root["entry/integrated_1d/intensity"].shape == (N_FRAMES, N_Q)
    assert len(list(root["entry/frames"])) == N_FRAMES


def test_incremental_save_appends_only_new_frames(tmp_path):
    """P1: per-save Python prep should be O(new frames), not O(all frames).

    Writes K=4 frames, then *extends* the sphere with another 4 and
    re-saves.  Verifies:

    * Final on-disk shape is (8, nq) — both batches landed.
    * The first 4 rows are bit-identical between the two checkpoints
      (i.e. the second save didn't rewrite them — append-only).
    * The frame_index dataset extends correctly.

    Without the P1 incremental refactor the second save still wrote
    correct *values* (full-array rewrite was idempotent), but it
    re-stacked all N arches every time.  This test pins down the
    append-only behaviour so future refactors don't regress.
    """
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus

    scan_data = pd.DataFrame({
        "tth": np.linspace(10.0, 14.0, N_FRAMES, dtype=np.float32),
    })
    # Phase 1 — 4 frames + initial save.
    arches = [_DuckArch(idx=i) for i in range(N_FRAMES)]
    sphere = _DuckSphere(arches, scan_data=scan_data)
    path = tmp_path / "incremental.nxs"
    save_sphere_to_nexus(sphere, path, mode="w")

    # Snapshot row 0 of intensity from the first checkpoint — must
    # survive the second save unchanged.
    root_a = nx.nxload(str(path))
    intensity_a = np.asarray(root_a["entry/integrated_1d/intensity"])
    frame_index_a = np.asarray(root_a["entry/integrated_1d/frame_index"])
    assert intensity_a.shape == (N_FRAMES, N_Q)
    intensity_a_rows = intensity_a.copy()

    # Phase 2 — extend the sphere by another N_FRAMES frames + re-save.
    for i in range(N_FRAMES, 2 * N_FRAMES):
        sphere.arches.append(_DuckArch(idx=i, seed=100))
    save_sphere_to_nexus(sphere, path, mode="a")

    # Verify the extended file.
    root_b = nx.nxload(str(path))
    intensity_b = np.asarray(root_b["entry/integrated_1d/intensity"])
    frame_index_b = np.asarray(root_b["entry/integrated_1d/frame_index"])
    assert intensity_b.shape == (2 * N_FRAMES, N_Q)
    assert frame_index_b.shape == (2 * N_FRAMES,)
    # The pre-existing rows are byte-identical to the first checkpoint.
    np.testing.assert_array_equal(intensity_b[:N_FRAMES], intensity_a_rows)
    np.testing.assert_array_equal(frame_index_b[:N_FRAMES], frame_index_a)
    # The new rows have the new arches' frame indices.
    assert frame_index_b[N_FRAMES:].tolist() == list(range(N_FRAMES, 2 * N_FRAMES))

    # 2D side also extends correctly (parallel append).
    intensity_2d_b = np.asarray(root_b["entry/integrated_2d/intensity"])
    assert intensity_2d_b.shape == (2 * N_FRAMES, N_CHI, N_Q)


def test_append_with_shape_change_full_rewrites(tmp_path):
    """O3: a follow-up save whose new arches have a different
    integration row shape than the on-disk dataset must NOT silently
    drop the previously-saved rows.  Instead it falls back to a
    full rewrite from all sphere arches with refreshed q/chi axes.

    Pre-O3 ``_append_new_rows`` recreated the dataset with only
    the new tail when shape changed — so e.g. saving 4 frames at
    nq=32 then 4 more at nq=64 produced a 4-row file (the first
    4 lost).  Post-O3 the file ends at 8 rows of nq=64 (all
    arches re-stacked with the new shape).
    """
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus
    import h5py

    nq1 = N_Q          # 32
    nq2 = N_Q * 2      # 64 — different!
    nchi1 = N_CHI      # 16
    nchi2 = N_CHI + 4  # 20 — different!

    # Phase 1: 4 frames at original shape.
    arches = [_DuckArch(idx=i, nq=nq1, nchi=nchi1) for i in range(N_FRAMES)]
    sphere = _DuckSphere(
        arches,
        scan_data=pd.DataFrame({"tth": np.linspace(10, 14, N_FRAMES,
                                                   dtype=np.float32)}),
    )
    path = tmp_path / "shape_drift.nxs"
    save_sphere_to_nexus(sphere, path, mode="w")

    with h5py.File(path, "r") as f:
        assert f["entry/integrated_1d/intensity"].shape == (N_FRAMES, nq1)
        assert f["entry/integrated_2d/intensity"].shape == (N_FRAMES,
                                                            nchi1, nq1)

    # Phase 2: replace the in-memory arches with new ones at a
    # different shape — and *also* extend the series.  This is the
    # bug scenario: a user reintegrating with new numpoints mid-scan,
    # then continuing to acquire frames.
    new_arches = [
        _DuckArch(idx=i, nq=nq2, nchi=nchi2, seed=50)
        for i in range(2 * N_FRAMES)
    ]
    # Re-seat sphere.arches to point at the reshaped arches.
    sphere.arches = _DuckArches(new_arches)
    save_sphere_to_nexus(sphere, path, mode="a")

    # File contains 8 rows at the *new* shape; the original 4 rows
    # at nq1 are gone (correctly — full rewrite refreshed both rows
    # and axes).  Pre-O3 the file would have been *4* rows at nq2
    # (the helper rebuilt from just the "new tail" of 4 arches).
    with h5py.File(path, "r") as f:
        assert f["entry/integrated_1d/intensity"].shape == (
            2 * N_FRAMES, nq2,
        ), "O3 regression: integrated_1d full rewrite must include all arches"
        assert f["entry/integrated_2d/intensity"].shape == (
            2 * N_FRAMES, nchi2, nq2,
        ), "O3 regression: integrated_2d full rewrite must include all arches"
        # frame_index also rebuilt — covers the parallel _append_new_rows
        # call for the index array.
        assert f["entry/integrated_1d/frame_index"].shape == (2 * N_FRAMES,)
        assert f["entry/integrated_1d/q"].shape == (nq2,)


def test_scan_data_index_aligns_with_gapped_frame_ids(tmp_path):
    """O1 / N2 regression: after writer → loader round-trip, the
    reloaded ``sphere.scan_data`` DataFrame must be indexed by the
    actual frame IDs (``arch.idx``), not a default 0..N-1 range
    index.

    Live acquisition does ``scan_data.loc[arch.idx] = ser``.  If
    reload built a default RangeIndex, ``loc[arch.idx]`` after
    reload would silently misalign whenever the IDs were not
    ``range(N)`` — e.g. 1-based SPEC, gapped Eiger external links,
    or post-deletion holes.

    Test gaps the IDs to ``[10, 12, 17, 22]`` and asserts they
    appear as the reloaded ``scan_data`` index.
    """
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus
    from xdart.modules.ewald.sphere import EwaldSphere
    from ssrl_xrd_tools.core.geometry import DiffractometerGeometry

    gapped = [10, 12, 17, 22]
    geom = DiffractometerGeometry.two_circle(tth="tth", th="th")

    arches = [_DuckArch(idx=i) for i in gapped]
    scan_data = pd.DataFrame(
        {
            "tth": np.array([11.0, 12.5, 14.0, 15.5], dtype=np.float32),
            "th":  np.array([0.10, 0.15, 0.20, 0.25], dtype=np.float32),
        }
    )
    sphere = _DuckSphere(arches, scan_data=scan_data, geometry=geom)

    path = tmp_path / "gapped.nxs"
    save_sphere_to_nexus(sphere, path, mode="w", finalize=False)

    # Round-trip through the real EwaldSphere loader.
    reloaded = EwaldSphere(name="gapped", data_file=str(path))
    reloaded.load_from_h5(replace=True, mode="r")

    # The reloaded scan_data index *is* the gapped frame IDs.
    assert list(reloaded.scan_data.index) == gapped
    # And the columns survived with the right values.
    assert "tth" in reloaded.scan_data.columns
    assert "th" in reloaded.scan_data.columns
    np.testing.assert_allclose(
        reloaded.scan_data.loc[17, "tth"], 14.0, atol=1e-5,
    )
    # Most importantly: a ``.loc[arch.idx]`` lookup pattern that
    # the GUI uses produces the right row, not row-position 17.
    np.testing.assert_allclose(
        reloaded.scan_data.loc[22, "th"], 0.25, atol=1e-5,
    )


def test_incremental_save_with_no_new_frames_is_noop(tmp_path):
    """Re-saving with no new arches must not change anything on disk.

    Specifically: dataset shapes stay constant, contents stay
    byte-identical.  Guards the ``if not new_arches: return`` early
    exit in :func:`_write_integrated_1d` / :func:`_write_integrated_2d`.
    """
    from xdart.modules.ewald.nexus_writer import save_sphere_to_nexus

    arches = [_DuckArch(idx=i) for i in range(N_FRAMES)]
    sphere = _DuckSphere(
        arches,
        scan_data=pd.DataFrame({"tth": np.zeros(N_FRAMES, dtype=np.float32)}),
    )
    path = tmp_path / "noop.nxs"
    save_sphere_to_nexus(sphere, path, mode="w")

    before = np.asarray(nx.nxload(str(path))["entry/integrated_1d/intensity"])
    save_sphere_to_nexus(sphere, path, mode="a")  # no new arches added
    after = np.asarray(nx.nxload(str(path))["entry/integrated_1d/intensity"])

    assert after.shape == before.shape == (N_FRAMES, N_Q)
    np.testing.assert_array_equal(after, before)
