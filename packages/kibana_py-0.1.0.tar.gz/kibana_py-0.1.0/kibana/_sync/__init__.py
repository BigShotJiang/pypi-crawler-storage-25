# Synchronous client module
