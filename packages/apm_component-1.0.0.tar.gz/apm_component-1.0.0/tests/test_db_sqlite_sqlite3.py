import pytest
from apm_component import db_sqlite_sqlite3 as mod


class TestConnect:
    def test_connect(self):
        result = mod.connect()
        assert result["status"] == "connected"

    def test_connect_memory(self):
        result = mod.connect_memory()
        assert result["status"] == "memory_connected"


class TestPool:
    def test_connect_pool(self):
        result = mod.connect_pool()
        assert result["status"] == "pool_created"

    def test_get_connection_from_pool(self):
        result = mod.get_connection_from_pool()
        assert result["status"] == "pool_connection_ok"

    def test_close_pool(self):
        mod.connect_pool()
        result = mod.close_pool()
        assert result["status"] == "pool_closed"


class TestConnectionErrors:
    def test_invalid_path(self):
        result = mod.connect_error_invalid_path()
        assert result["status"] == "error"
        assert "msg" in result

    def test_readonly(self):
        mod.execute_create_table()
        result = mod.connect_error_readonly()
        assert result["status"] == "error"
        assert "msg" in result

    def test_corrupt_db(self):
        result = mod.connect_error_corrupt_db()
        assert result["status"] == "error"
        assert "msg" in result

    def test_timeout(self):
        result = mod.connect_error_timeout()
        assert result["status"] == "error"
        assert "msg" in result


class TestExecution:
    def test_create_table(self):
        result = mod.execute_create_table()
        assert result["status"] == "table_created"

    def test_insert(self):
        mod.execute_create_table()
        result = mod.execute_insert()
        assert result["status"] == "inserted"
        assert "lastrowid" in result

    def test_insert_many(self):
        mod.execute_create_table()
        result = mod.execute_insert_many()
        assert result["status"] == "inserted_many"
        assert result["rowcount"] == 3

    def test_update(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.execute_update()
        assert result["status"] == "updated"

    def test_delete(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.execute_delete()
        assert result["status"] == "deleted"

    def test_select(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.execute_select()
        assert result["status"] == "selected"
        assert isinstance(result["rows"], list)

    def test_parameterized(self):
        mod.execute_create_table()
        mod.execute_insert_many()
        result = mod.execute_parameterized()
        assert result["status"] == "parameterized_ok"

    def test_transaction(self):
        mod.execute_create_table()
        result = mod.execute_transaction()
        assert result["status"] == "transaction_ok"
        names = [r[0] if isinstance(r, tuple) else r for r in result["committed_rows"]]
        assert "txn_item" in names
        assert "txn_rollback" not in names

    def test_execute_script(self):
        mod.execute_create_table()
        result = mod.execute_script()
        assert result["status"] == "script_executed"
        assert result["inserted_count"] == 3


class TestFetching:
    @pytest.fixture(autouse=True)
    def setup_table(self):
        mod.execute_create_table()
        mod.execute_insert_many()

    def test_fetch_one(self):
        result = mod.fetch_one()
        assert result["status"] == "fetch_one"
        assert result["row"] is not None

    def test_fetch_all(self):
        result = mod.fetch_all()
        assert result["status"] == "fetch_all"
        assert result["count"] >= 1

    def test_fetch_many(self):
        result = mod.fetch_many()
        assert result["status"] == "fetch_many"
        assert len(result["batch"]) <= 2

    def test_fetch_row_factory(self):
        result = mod.fetch_row_factory()
        assert result["status"] == "row_factory"
        if result["rows"]:
            assert isinstance(result["rows"][0], dict)


class TestAdvanced:
    @pytest.fixture(autouse=True)
    def setup_table(self):
        mod.execute_create_table()
        mod.execute_insert_many()

    def test_create_user_function(self):
        result = mod.create_user_function()
        assert result["status"] == "user_function_ok"
        assert "rows" in result

    def test_create_aggregate_function(self):
        result = mod.create_aggregate_function()
        assert result["status"] == "aggregate_function_ok"
        assert "total" in result

    def test_iterdump_database(self):
        result = mod.iterdump_database()
        assert result["status"] == "iterdump_ok"
        assert result["line_count"] > 0

    def test_backup_database(self):
        result = mod.backup_database()
        assert result["status"] == "backup_ok"

    def test_dynamic_query(self):
        result = mod.dynamic_query()
        assert result["status"] == "dynamic_query_ok"

    def test_dynamic_query_with_columns(self):
        result = mod.dynamic_query(columns=["id", "name"])
        assert result["status"] == "dynamic_query_ok"

    def test_dynamic_query_with_where(self):
        result = mod.dynamic_query(
            where_clause={"condition": "value > ?", "params": [5]}
        )
        assert result["status"] == "dynamic_query_ok"

    def test_delayed_insert(self):
        result = mod.delayed_insert()
        assert result["status"] == "delayed_insert_ok"
        assert "lastrowid" in result

    def test_race_condition(self):
        result = mod.race_condition_test()
        assert result["status"] == "race_test_ok"
        assert result["final_value"] == 2
