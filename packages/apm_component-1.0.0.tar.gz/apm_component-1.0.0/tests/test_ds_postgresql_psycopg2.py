import pytest
from apm_component import ds_postgresql_psycopg2 as mod


class TestConnect:
    def test_connect(self):
        result = mod.connect()
        assert result["status"] == "connected"

    def test_connect_dsn(self):
        result = mod.connect_dsn()
        assert result["status"] == "connected_dsn"


class TestPool:
    def test_connect_pool(self):
        result = mod.connect_pool()
        assert result["status"] == "pool_created"

    def test_connect_threaded_pool(self):
        result = mod.connect_threaded_pool()
        assert result["status"] == "threaded_pool_created"

    def test_get_connection_from_pool(self):
        result = mod.get_connection_from_pool()
        assert result["status"] == "pool_connection_ok"


class TestConnectionErrors:
    def test_wrong_password(self):
        result = mod.connect_error_wrong_password()
        assert result["status"] == "error"

    def test_wrong_host(self):
        result = mod.connect_error_wrong_host()
        assert result["status"] == "error"

    def test_unknown_db(self):
        result = mod.connect_error_unknown_db()
        assert result["status"] == "error"

    def test_timeout(self):
        result = mod.connect_error_timeout()
        assert result["status"] == "error"

    def test_pool_exhaustion(self):
        result = mod.pool_error_exhaustion()
        assert result["status"] == "pool_exhausted"


class TestSchema:
    def test_create_table(self):
        result = mod.execute_create_table()
        assert result["status"] == "table_created"

    def test_drop_table(self):
        mod.execute_create_table()
        result = mod.execute_drop_table()
        assert result["status"] == "table_dropped"


class TestInsert:
    def test_insert(self):
        mod.execute_create_table()
        result = mod.execute_insert()
        assert result["status"] == "inserted"
        assert "id" in result

    def test_insert_many(self):
        mod.execute_create_table()
        result = mod.execute_insert_many()
        assert result["status"] == "inserted_many"

    def test_insert_values(self):
        mod.execute_create_table()
        result = mod.execute_insert_values()
        assert result["status"] == "insert_values_ok"
        assert result["count"] == 5

    def test_insert_returning(self):
        mod.execute_create_table()
        result = mod.execute_insert_returning()
        assert result["status"] == "insert_returning_ok"


class TestFetch:
    def test_fetch_one(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.fetch_one()
        assert result["status"] == "fetch_one"

    def test_fetch_all(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.fetch_all()
        assert result["status"] == "fetch_all"

    def test_fetch_many(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.fetch_many()
        assert result["status"] == "fetch_many"

    def test_dict_cursor(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.fetch_dict_cursor()
        assert result["status"] == "dict_cursor"

    def test_named_tuple_cursor(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.fetch_named_tuple_cursor()
        assert result["status"] == "named_tuple_cursor"

    def test_server_side_cursor(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.fetch_server_side_cursor()
        assert result["status"] == "server_side_cursor"


class TestUpdate:
    def test_update(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.execute_update()
        assert result["status"] == "updated"

    def test_update_returning(self):
        mod.execute_create_table()
        result = mod.execute_update_returning()
        assert result["status"] == "update_returning_ok"
        assert result["value"] == 888


class TestDelete:
    def test_delete(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.execute_delete()
        assert result["status"] == "deleted"

    def test_delete_all(self):
        mod.execute_create_table()
        result = mod.execute_delete_all()
        assert result["status"] == "truncated"


class TestTransaction:
    def test_transaction(self):
        mod.execute_create_table()
        result = mod.execute_transaction()
        assert result["status"] == "transaction_ok"

    def test_savepoint(self):
        mod.execute_create_table()
        result = mod.execute_savepoint()
        assert result["status"] == "savepoint_ok"


class TestDataTypes:
    def test_jsonb(self):
        mod.execute_create_table()
        result = mod.insert_jsonb()
        assert result["status"] == "jsonb_ok"

    def test_array(self):
        mod.execute_create_table()
        result = mod.insert_array()
        assert result["status"] == "array_ok"
        assert len(result["tags"]) == 3


class TestIndex:
    def test_create_index(self):
        mod.execute_create_table()
        result = mod.create_index()
        assert result["status"] == "index_created"

    def test_drop_index(self):
        result = mod.drop_index()
        assert result["status"] == "index_dropped"


class TestErrors:
    def test_query_syntax(self):
        result = mod.error_query_syntax()
        assert result["status"] == "error"

    def test_duplicate_key(self):
        mod.execute_create_table()
        result = mod.error_duplicate_key()
        assert result["status"] == "error"

    def test_table_not_found(self):
        result = mod.error_table_not_found()
        assert result["status"] == "error"


class TestAdvanced:
    def test_parameterized(self):
        mod.execute_create_table()
        result = mod.parameterized_query()
        assert result["status"] == "parameterized_ok"

    def test_mogrify(self):
        result = mod.mogrify_query()
        assert result["status"] == "mogrify_ok"

    def test_connection_status(self):
        result = mod.connection_status()
        assert result["status"] == "status_ok"

    def test_copy(self):
        mod.execute_create_table()
        result = mod.copy_from_to()
        assert result["status"] == "copy_ok"

    def test_delayed_insert(self):
        mod.execute_create_table()
        result = mod.delayed_insert()
        assert result["status"] == "delayed_insert_ok"

    def test_race_condition(self):
        mod.execute_create_table()
        result = mod.race_condition_test()
        assert result["status"] == "race_test_ok"
