import pytest
from apm_component import db_mysql_sqlalchemy as mod


class TestConnect:
    def test_connect(self):
        result = mod.connect()
        assert result["status"] == "connected"
        assert result["result"] == 1

    def test_connect_pool(self):
        result = mod.connect_pool()
        assert result["status"] == "pool_active"
        assert "pool_class" in result
        assert "size" in result

    def test_connect_nullpool(self):
        result = mod.connect_nullpool()
        assert result["status"] == "nullpool_ok"


class TestConnectionErrors:
    def test_wrong_password(self):
        result = mod.connect_error_wrong_password()
        assert result["status"] == "error"
        assert "msg" in result

    def test_wrong_host(self):
        result = mod.connect_error_wrong_host()
        assert result["status"] == "error"
        assert "msg" in result

    def test_unknown_db(self):
        result = mod.connect_error_unknown_db()
        assert result["status"] == "error"
        assert "msg" in result

    def test_timeout(self):
        result = mod.connect_error_timeout()
        assert result["status"] == "error"
        assert "msg" in result

    def test_pool_overflow(self):
        result = mod.pool_error_overflow()
        assert result["status"] == "pool_overflow"
        assert "msg" in result


class TestRawExecution:
    def test_create_table(self):
        result = mod.execute_raw_create_table()
        assert result["status"] == "table_created"

    def test_insert(self):
        mod.execute_raw_create_table()
        result = mod.execute_raw_insert()
        assert result["status"] == "inserted"
        assert "lastrowid" in result

    def test_insert_params(self):
        mod.execute_raw_create_table()
        result = mod.execute_raw_insert_params()
        assert result["status"] == "inserted_many"
        assert result["rowcount"] == 3

    def test_select(self):
        mod.execute_raw_create_table()
        mod.execute_raw_insert()
        result = mod.execute_raw_select()
        assert result["status"] == "selected"
        assert isinstance(result["rows"], list)

    def test_update(self):
        mod.execute_raw_create_table()
        mod.execute_raw_insert()
        result = mod.execute_raw_update()
        assert result["status"] == "updated"

    def test_delete(self):
        mod.execute_raw_create_table()
        mod.execute_raw_insert()
        result = mod.execute_raw_delete()
        assert result["status"] == "deleted"


class TestCoreExecution:
    @pytest.fixture(autouse=True)
    def setup_table(self):
        mod.execute_raw_create_table()

    def test_core_insert(self):
        result = mod.execute_core_insert()
        assert result["status"] == "core_inserted"

    def test_core_insert_many(self):
        result = mod.execute_core_insert_many()
        assert result["status"] == "core_inserted_many"
        assert result["rowcount"] == 2

    def test_core_select(self):
        mod.execute_core_insert()
        result = mod.execute_core_select()
        assert result["status"] == "core_selected"

    def test_core_update(self):
        mod.execute_core_insert()
        result = mod.execute_core_update()
        assert result["status"] == "core_updated"

    def test_core_delete(self):
        mod.execute_core_insert()
        result = mod.execute_core_delete()
        assert result["status"] == "core_deleted"


class TestTransactions:
    @pytest.fixture(autouse=True)
    def setup_table(self):
        mod.execute_raw_create_table()

    def test_transaction(self):
        result = mod.execute_transaction()
        assert result["status"] == "transaction_ok"
        assert "txn_item" in result["committed_rows"]
        assert "txn_rollback" not in result["committed_rows"]

    def test_savepoint(self):
        result = mod.execute_savepoint()
        assert result["status"] == "savepoint_ok"
        assert "sp_outer" in result["rows"]
        assert "sp_inner_commit" in result["rows"]
        assert "sp_inner_rollback" not in result["rows"]


class TestFetching:
    @pytest.fixture(autouse=True)
    def setup_table(self):
        mod.execute_raw_create_table()
        mod.execute_raw_insert_params()

    def test_fetch_one(self):
        result = mod.fetch_one()
        assert result["status"] == "fetch_one"
        assert result["row"] is not None

    def test_fetch_all(self):
        result = mod.fetch_all()
        assert result["status"] == "fetch_all"
        assert result["count"] >= 1

    def test_fetch_many(self):
        result = mod.fetch_many()
        assert result["status"] == "fetch_many"
        assert len(result["batch"]) <= 2

    def test_fetch_mappings(self):
        result = mod.fetch_mappings()
        assert result["status"] == "fetch_mappings"
        if result["rows"]:
            assert isinstance(result["rows"][0], dict)

    def test_fetch_scalars(self):
        result = mod.fetch_scalars()
        assert result["status"] == "fetch_scalars"
        assert isinstance(result["names"], list)

    def test_fetch_stream(self):
        result = mod.fetch_stream()
        assert result["status"] == "fetch_stream"
        assert "batch_count" in result


class TestORM:
    def test_orm_create_table(self):
        result = mod.orm_create_table()
        assert result["status"] == "orm_table_created"

    def test_orm_insert(self):
        mod.orm_create_table()
        result = mod.orm_insert()
        assert result["status"] == "orm_inserted"

    def test_orm_select(self):
        mod.orm_create_table()
        mod.orm_insert()
        result = mod.orm_select()
        assert result["status"] == "orm_selected"
        assert len(result["rows"]) >= 1

    def test_orm_update(self):
        mod.orm_create_table()
        mod.orm_insert()
        result = mod.orm_update()
        assert result["status"] == "orm_updated"

    def test_orm_delete(self):
        mod.orm_create_table()
        mod.orm_insert()
        result = mod.orm_delete()
        assert result["status"] == "orm_deleted"


class TestAdvanced:
    @pytest.fixture(autouse=True)
    def setup_table(self):
        mod.execute_raw_create_table()
        mod.execute_raw_insert_params()

    def test_reflect_table(self):
        result = mod.reflect_table()
        assert result["status"] == "reflected"
        assert mod._TABLE in result["tables"]
        assert "id" in result["columns"]

    def test_event_hook(self):
        result = mod.event_hook()
        assert result["status"] == "event_hook_ok"
        assert len(result["captured"]) >= 2

    def test_insert_on_duplicate(self):
        result = mod.insert_on_duplicate()
        assert result["status"] == "on_duplicate_ok"

    def test_dynamic_query(self):
        result = mod.dynamic_query()
        assert result["status"] == "dynamic_query_ok"

    def test_dynamic_query_with_columns(self):
        result = mod.dynamic_query(columns=["id", "name"])
        assert result["status"] == "dynamic_query_ok"

    def test_delayed_insert(self):
        result = mod.delayed_insert()
        assert result["status"] == "delayed_insert_ok"
        assert "lastrowid" in result

    def test_race_condition(self):
        result = mod.race_condition_test()
        assert result["status"] == "race_test_ok"
        assert result["final_value"] == 2
