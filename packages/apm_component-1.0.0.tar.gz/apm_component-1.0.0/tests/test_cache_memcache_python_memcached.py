import pytest
from apm_component import cache_memcache_python_memcached as mod


class TestConnect:
    def test_connect(self):
        result = mod.connect()
        assert result["status"] == "connected"
        assert result["pid"]


class TestConnectionErrors:
    def test_wrong_host(self):
        result = mod.connect_error_wrong_host()
        assert result["status"] == "error"
        assert "msg" in result

    def test_wrong_port(self):
        result = mod.connect_error_wrong_port()
        assert result["status"] == "error"
        assert "msg" in result

    def test_timeout(self):
        result = mod.connect_error_timeout()
        assert result["status"] == "error"
        assert "msg" in result


class TestKeyValueOps:
    def test_set_get(self):
        result = mod.set_get()
        assert result["status"] == "success"
        assert result["value"] == "hello"

    def test_delete_key(self):
        result = mod.delete_key()
        assert result["status"] == "success"
        assert result["value_after"] is None

    def test_add_key(self):
        result = mod.add_key()
        assert result["status"] == "success"
        assert result["first_add"] is True
        assert result["second_add"] is False
        assert result["value"] == "first"

    def test_replace_key(self):
        result = mod.replace_key()
        assert result["status"] == "success"
        assert result["replaced"] is True
        assert result["value"] == "replaced"

    def test_append_prepend(self):
        result = mod.append_prepend()
        assert result["status"] == "success"
        assert result["value"] == "say: hello world"


class TestBulkOps:
    def test_set_multi_get_multi(self):
        result = mod.set_multi_get_multi()
        assert result["status"] == "success"
        assert result["failed_keys"] == []

    def test_delete_multi(self):
        result = mod.delete_multi()
        assert result["status"] == "success"
        assert result["remaining_count"] == 0


class TestCounters:
    def test_incr_decr(self):
        result = mod.incr_decr()
        assert result["status"] == "success"
        assert result["after_incr"] == 15
        assert result["after_decr"] == 12


class TestTTL:
    def test_set_with_ttl(self):
        result = mod.set_with_ttl()
        assert result["status"] == "success"
        assert result["before"] == "expires_soon"
        assert result["after"] is None


class TestKeyManagement:
    def test_key_exists(self):
        result = mod.key_exists()
        assert result["status"] == "success"
        assert result["exists"] is True
        assert result["not_exists"] is False


class TestCAS:
    def test_cas_operations(self):
        result = mod.cas_operations()
        assert result["status"] == "success"
        assert result["original"] == "original"
        assert result["cas_success"] is True
        assert result["final"] == "updated"


class TestSerialization:
    def test_json_serialization(self):
        result = mod.json_serialization()
        assert result["status"] == "success"
        assert result["data"]["name"] == "test"

    def test_pickle_serialization(self):
        result = mod.pickle_serialization()
        assert result["status"] == "success"
        assert result["data"]["complex"] == [1, 2.5, True, None]


class TestFlush:
    def test_flush_all(self):
        result = mod.flush_all()
        assert result["status"] == "success"
        assert result["after_flush"] is None


class TestStats:
    def test_get_stats(self):
        result = mod.get_stats()
        assert result["status"] == "success"
        assert result["pid"]


class TestDisconnect:
    def test_disconnect_all(self):
        result = mod.disconnect_all()
        assert result["status"] == "success"
        assert result["disconnected"] is True


class TestAdvanced:
    def test_dynamic_key_ops(self):
        result = mod.dynamic_key_ops()
        assert result["status"] == "success"
        assert result["key_count"] == 5

    def test_delayed_operations(self):
        result = mod.delayed_operations()
        assert result["status"] == "success"
        assert result["value"] == "updated"

    def test_race_condition_test(self):
        result = mod.race_condition_test()
        assert result["status"] == "success"
        assert result["final_value"] == 3
