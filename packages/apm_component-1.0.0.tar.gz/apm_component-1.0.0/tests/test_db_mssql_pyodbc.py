import pytest
from apm_component import db_mssql_pyodbc as mod


class TestConnect:
    def test_connect(self):
        result = mod.connect()
        assert result["status"] == "connected"


class TestPool:
    def test_connect_pool(self):
        result = mod.connect_pool()
        assert result["status"] == "pool_created"

    def test_get_connection_from_pool(self):
        result = mod.get_connection_from_pool()
        assert result["status"] == "pool_connection_ok"

    def test_toggle_odbc_pooling(self):
        result = mod.toggle_odbc_pooling()
        assert result["status"] == "pooling_toggled"


class TestConnectionErrors:
    def test_wrong_password(self):
        result = mod.connect_error_wrong_password()
        assert result["status"] == "error"
        assert "msg" in result

    def test_wrong_host(self):
        result = mod.connect_error_wrong_host()
        assert result["status"] == "error"
        assert "msg" in result

    def test_unknown_db(self):
        result = mod.connect_error_unknown_db()
        assert result["status"] == "error"
        assert "msg" in result

    def test_timeout(self):
        result = mod.connect_error_timeout()
        assert result["status"] == "error"
        assert "msg" in result

    def test_pool_exhaustion(self):
        result = mod.pool_error_exhaustion()
        assert result["status"] == "pool_exhausted"
        assert "msg" in result


class TestExecution:
    def test_create_table(self):
        result = mod.execute_create_table()
        assert result["status"] == "table_created"

    def test_insert(self):
        mod.execute_create_table()
        result = mod.execute_insert()
        assert result["status"] == "inserted"
        assert "lastrowid" in result

    def test_insert_many(self):
        mod.execute_create_table()
        result = mod.execute_insert_many()
        assert result["status"] == "inserted_many"
        assert result["rowcount"] == 3

    def test_fast_executemany(self):
        mod.execute_create_table()
        result = mod.execute_fast_executemany()
        assert result["status"] == "fast_inserted"
        assert result["rowcount"] == 3

    def test_update(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.execute_update()
        assert result["status"] == "updated"

    def test_delete(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.execute_delete()
        assert result["status"] == "deleted"

    def test_select(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.execute_select()
        assert result["status"] == "selected"
        assert isinstance(result["rows"], list)

    def test_parameterized(self):
        mod.execute_create_table()
        mod.execute_insert_many()
        result = mod.execute_parameterized()
        assert result["status"] == "parameterized_ok"

    def test_transaction(self):
        mod.execute_create_table()
        result = mod.execute_transaction()
        assert result["status"] == "transaction_ok"
        names = [r[0] if isinstance(r, tuple) else r for r in result["committed_rows"]]
        assert "txn_item" in names
        assert "txn_rollback" not in names


class TestFetching:
    @pytest.fixture(autouse=True)
    def setup_table(self):
        mod.execute_create_table()
        mod.execute_insert_many()

    def test_fetch_one(self):
        result = mod.fetch_one()
        assert result["status"] == "fetch_one"
        assert result["row"] is not None

    def test_fetch_all(self):
        result = mod.fetch_all()
        assert result["status"] == "fetch_all"
        assert result["count"] >= 3

    def test_fetch_many(self):
        result = mod.fetch_many()
        assert result["status"] == "fetch_many"
        assert len(result["batch"]) == 2

    def test_fetch_as_dict(self):
        result = mod.fetch_as_dict()
        assert result["status"] == "fetch_as_dict"
        assert isinstance(result["rows"], list)
        if result["rows"]:
            assert "name" in result["rows"][0]

    def test_fetch_column_metadata(self):
        result = mod.fetch_column_metadata()
        assert result["status"] == "column_metadata_ok"
        assert isinstance(result["columns"], list)
        col_names = [c["name"] for c in result["columns"]]
        assert "name" in col_names


class TestAdvanced:
    @pytest.fixture(autouse=True)
    def setup_table(self):
        mod.execute_create_table()
        mod.execute_insert_many()

    def test_call_stored_procedure(self):
        result = mod.call_stored_procedure()
        assert result["status"] == "stored_proc_ok"
        assert "total" in result

    def test_multiple_result_sets(self):
        result = mod.multiple_result_sets()
        assert result["status"] == "multiple_result_sets_ok"
        assert isinstance(result["first"], list)
        assert isinstance(result["second"], list)

    def test_dynamic_query(self):
        result = mod.dynamic_query()
        assert result["status"] == "dynamic_query_ok"
        assert isinstance(result["rows"], list)

    def test_delayed_insert(self):
        result = mod.delayed_insert()
        assert result["status"] == "delayed_insert_ok"
        assert "lastrowid" in result

    def test_race_condition(self):
        result = mod.race_condition_test()
        assert result["status"] == "race_test_ok"
        assert result["final_value"] == 2
