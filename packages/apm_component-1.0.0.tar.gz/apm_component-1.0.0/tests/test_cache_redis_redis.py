import pytest
from apm_component import cache_redis_redis as mod


class TestConnect:
    def test_connect(self):
        result = mod.connect()
        assert result["status"] == "connected"
        assert result["ping"] is True

    def test_connect_url(self):
        result = mod.connect_url()
        assert result["status"] == "connected_url"
        assert result["ping"] is True


class TestPool:
    def test_connect_pool(self):
        result = mod.connect_pool()
        assert result["status"] == "pool_connected"

    def test_connect_blocking_pool(self):
        result = mod.connect_blocking_pool()
        assert result["status"] == "blocking_pool_connected"


class TestConnectionErrors:
    def test_wrong_host(self):
        result = mod.connect_error_wrong_host()
        assert result["status"] == "error"
        assert "msg" in result

    def test_wrong_port(self):
        result = mod.connect_error_wrong_port()
        assert result["status"] == "error"
        assert "msg" in result

    def test_wrong_password(self):
        result = mod.connect_error_wrong_password()
        assert result["status"] == "error"
        assert "msg" in result

    def test_timeout(self):
        result = mod.connect_error_timeout()
        assert result["status"] == "error"
        assert "msg" in result

    def test_pool_exhaustion(self):
        result = mod.pool_exhaustion_error()
        assert result["status"] == "error"
        assert "msg" in result


class TestKeyValueOps:
    def test_set_get(self):
        result = mod.set_get()
        assert result["status"] == "success"
        assert result["value"] == "hello"

    def test_delete_key(self):
        result = mod.delete_key()
        assert result["status"] == "success"
        assert result["deleted"] == 1
        assert result["value_after"] is None

    def test_setnx(self):
        result = mod.setnx()
        assert result["status"] == "success"
        assert result["first_set"] is True
        assert result["second_set"] is False
        assert result["value"] == "first"

    def test_getset(self):
        result = mod.getset()
        assert result["status"] == "success"
        assert result["old"] == "old_value"
        assert result["current"] == "new_value"

    def test_append_value(self):
        result = mod.append_value()
        assert result["status"] == "success"
        assert result["value"] == "hello world"


class TestBulkOps:
    def test_mset_mget(self):
        result = mod.mset_mget()
        assert result["status"] == "success"
        assert result["values"] == ["a", "b", "c"]


class TestCounters:
    def test_incr_decr(self):
        result = mod.incr_decr()
        assert result["status"] == "success"
        # 10 +1 +5 -1 -3 = 12
        assert result["value"] == 12


class TestTTL:
    def test_set_with_ttl(self):
        result = mod.set_with_ttl()
        assert result["status"] == "success"
        assert result["ttl"] > 0

    def test_expire_and_persist(self):
        result = mod.expire_and_persist()
        assert result["status"] == "success"
        assert result["ttl_before"] > 0
        assert result["ttl_after"] == -1

    def test_ttl_expiry_check(self):
        result = mod.ttl_expiry_check()
        assert result["status"] == "success"
        assert result["before"] == "vanish"
        assert result["after"] is None


class TestKeyManagement:
    def test_key_exists(self):
        result = mod.key_exists()
        assert result["status"] == "success"
        assert result["exists"] == 1
        assert result["not_exists"] == 0

    def test_key_type(self):
        result = mod.key_type()
        assert result["status"] == "success"
        assert result["string_type"] == "string"
        assert result["list_type"] == "list"

    def test_scan_keys(self):
        result = mod.scan_keys()
        assert result["status"] == "success"
        assert result["found_count"] == 5


class TestDataTypes:
    def test_hash_operations(self):
        result = mod.hash_operations()
        assert result["status"] == "success"
        assert result["single"] == "val1"
        assert "field1" in result["all"]
        assert "field3" not in result["after_del"]

    def test_list_operations(self):
        result = mod.list_operations()
        assert result["status"] == "success"
        assert result["length"] == 4
        assert result["lpop"] == "a"
        assert result["rpop"] == "d"

    def test_set_operations(self):
        result = mod.set_operations()
        assert result["status"] == "success"
        assert result["is_member"]
        assert result["cardinality"] == 3

    def test_sorted_set_operations(self):
        result = mod.sorted_set_operations()
        assert result["status"] == "success"
        assert len(result["all_with_scores"]) == 3


class TestSerialization:
    def test_json_serialization(self):
        result = mod.json_serialization()
        assert result["status"] == "success"
        assert result["data"]["name"] == "test"
        assert result["data"]["values"] == [1, 2, 3]


class TestFlush:
    def test_flush_db(self):
        result = mod.flush_db()
        assert result["status"] == "success"
        assert result["remaining_keys"] == 0


class TestPipeline:
    def test_pipeline_operations(self):
        result = mod.pipeline_operations()
        assert result["status"] == "success"
        assert result["results"] == [True, True, "a", "b"]


class TestTransaction:
    def test_transaction_operations(self):
        result = mod.transaction_operations()
        assert result["status"] == "success"
        assert result["value"] == "1"


class TestPubSub:
    def test_pubsub_operations(self):
        result = mod.pubsub_operations()
        assert result["status"] == "success"
        assert result["message"] == "hello_pubsub"


class TestLua:
    def test_lua_script(self):
        result = mod.lua_script()
        assert result["status"] == "success"
        assert result["result"] == 20


class TestAdvanced:
    def test_dynamic_key_ops(self):
        result = mod.dynamic_key_ops()
        assert result["status"] == "success"
        assert result["key_count"] == 5

    def test_delayed_operations(self):
        result = mod.delayed_operations()
        assert result["status"] == "success"
        assert result["value"] == "updated"

    def test_race_condition_test(self):
        result = mod.race_condition_test()
        assert result["status"] == "success"
        assert result["final_value"] == 3
