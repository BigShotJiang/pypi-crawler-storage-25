import pytest
from apm_component import ds_elasticsearch_elasticsearch as mod


class TestConnect:
    def test_connect(self):
        result = mod.connect()
        assert result["status"] == "connected"

    def test_connect_health(self):
        result = mod.connect_health()
        assert result["status"] == "connected"


class TestConnectionErrors:
    def test_wrong_host(self):
        result = mod.connect_error_wrong_host()
        assert result["status"] == "error"

    def test_wrong_port(self):
        result = mod.connect_error_wrong_port()
        assert result["status"] == "error"

    def test_timeout(self):
        result = mod.connect_error_timeout()
        assert result["status"] == "error"


class TestIndexManagement:
    def test_create_index(self):
        result = mod.create_index()
        assert result["status"] == "index_created"

    def test_delete_index(self):
        mod.create_index()
        result = mod.delete_index()
        assert result["status"] == "index_deleted"

    def test_index_exists(self):
        result = mod.index_exists()
        assert result["status"] == "checked"
        assert result["exists"] is True

    def test_get_mapping(self):
        result = mod.get_mapping()
        assert result["status"] == "mapping_ok"
        assert result["has_properties"] is True

    def test_refresh_index(self):
        result = mod.refresh_index()
        assert result["status"] == "refreshed"


class TestDocumentCRUD:
    def test_insert_one(self):
        mod.create_index()
        result = mod.insert_one()
        assert result["status"] == "inserted"

    def test_insert_many(self):
        mod.create_index()
        result = mod.insert_many()
        assert result["status"] == "inserted_many"
        assert result["success"] == 5

    def test_find_one(self):
        mod.create_index()
        result = mod.find_one()
        assert result["status"] == "found"

    def test_find_missing(self):
        mod.create_index()
        result = mod.find_missing()
        assert result["status"] == "not_found"

    def test_document_exists(self):
        mod.create_index()
        result = mod.document_exists()
        assert result["status"] == "checked"
        assert result["exists"] is True

    def test_update_one(self):
        mod.create_index()
        result = mod.update_one()
        assert result["status"] == "updated"
        assert result["value"] == 999

    def test_delete_one(self):
        mod.create_index()
        result = mod.delete_one()
        assert result["status"] == "deleted"

    def test_delete_many(self):
        mod.create_index()
        result = mod.delete_many()
        assert result["status"] == "deleted_many"


class TestSearch:
    def test_search_match(self):
        mod.create_index()
        result = mod.search_match()
        assert result["status"] == "search_ok"
        assert result["hits"] >= 1

    def test_search_term(self):
        mod.create_index()
        result = mod.search_term()
        assert result["status"] == "term_ok"

    def test_search_range(self):
        mod.create_index()
        result = mod.search_range()
        assert result["status"] == "range_ok"

    def test_search_bool(self):
        mod.create_index()
        result = mod.search_bool()
        assert result["status"] == "bool_ok"

    def test_search_pagination(self):
        result = mod.search_pagination()
        assert result["status"] == "pagination_ok"
        assert result["page1_hits"] == 3

    def test_search_aggregation(self):
        result = mod.search_aggregation()
        assert result["status"] == "aggregation_ok"

    def test_search_sort(self):
        result = mod.search_sort()
        assert result["status"] == "sort_ok"
        assert result["values"] == sorted(result["values"])


class TestDataTypes:
    def test_nested_object(self):
        mod.create_index()
        result = mod.insert_nested_object()
        assert result["status"] == "nested_ok"

    def test_various_data_types(self):
        mod.create_index()
        result = mod.insert_various_data_types()
        assert result["status"] == "data_types_ok"


class TestErrors:
    def test_query_syntax_error(self):
        result = mod.error_query_syntax()
        assert result["status"] == "error"

    def test_index_not_found(self):
        result = mod.error_index_not_found()
        assert result["status"] == "error"


class TestAdvanced:
    def test_count_documents(self):
        mod.create_index()
        result = mod.count_documents()
        assert result["status"] == "count_ok"

    def test_multi_search(self):
        mod.create_index()
        result = mod.multi_search()
        assert result["status"] == "msearch_ok"
        assert result["responses"] == 2

    def test_delayed_index(self):
        mod.create_index()
        result = mod.delayed_index()
        assert result["status"] == "delayed_index_ok"

    def test_race_condition(self):
        mod.create_index()
        result = mod.race_condition_test()
        assert result["status"] == "race_test_ok"
