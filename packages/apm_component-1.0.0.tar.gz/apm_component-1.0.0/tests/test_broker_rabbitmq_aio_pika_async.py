import pytest
from apm_component import broker_rabbitmq_aio_pika_async as mod


@pytest.fixture(autouse=True, scope="module")
def setup_teardown():
    yield
    try:
        mod.cleanup()
    except Exception:
        pass


class TestConnect:
    def test_connect(self):
        result = mod.connect()
        assert result["status"] == "connected"
        assert result["is_closed"] is False

    def test_connect_basic(self):
        result = mod.connect_basic()
        assert result["status"] == "connected_basic"
        assert result["is_closed"] is False


class TestConnectionErrors:
    def test_wrong_host(self):
        result = mod.connect_error_wrong_host()
        assert result["status"] == "error"
        assert "msg" in result

    def test_wrong_port(self):
        result = mod.connect_error_wrong_port()
        assert result["status"] == "error"
        assert "msg" in result

    def test_wrong_credentials(self):
        result = mod.connect_error_wrong_credentials()
        assert result["status"] == "error"
        assert "msg" in result


class TestQueueManagement:
    def test_declare_queue(self):
        result = mod.declare_queue()
        assert result["status"] == "queue_declared"
        assert "queue" in result

    def test_purge_queue(self):
        result = mod.purge_queue()
        assert result["status"] == "queue_purged"

    def test_delete_queue(self):
        result = mod.delete_queue()
        assert result["status"] == "queue_deleted"


class TestExchangeManagement:
    def test_declare_exchange(self):
        result = mod.declare_exchange()
        assert result["status"] == "exchange_declared"

    def test_bind_queue_to_exchange(self):
        result = mod.bind_queue_to_exchange()
        assert result["status"] == "queue_bound"

    def test_delete_exchange(self):
        result = mod.delete_exchange()
        assert result["status"] == "exchange_deleted"


class TestPublishing:
    def test_publish_basic(self):
        result = mod.publish_basic()
        assert result["status"] == "published"

    def test_publish_to_exchange(self):
        result = mod.publish_to_exchange()
        assert result["status"] == "published_to_exchange"

    def test_publish_with_properties(self):
        result = mod.publish_with_properties()
        assert result["status"] == "published_with_properties"

    def test_publish_bulk(self):
        result = mod.publish_bulk()
        assert result["status"] == "bulk_published"
        assert result["count"] == 10

    def test_publish_json(self):
        result = mod.publish_json()
        assert result["status"] == "json_published"

    def test_publish_with_confirm(self):
        result = mod.publish_with_confirm()
        assert result["status"] == "publish_confirmed"

    def test_publish_binary(self):
        result = mod.publish_binary()
        assert result["status"] == "binary_ok"
        assert result["length"] == 256


class TestConsuming:
    def test_consume_basic_get(self):
        result = mod.consume_basic_get()
        assert result["status"] == "consumed"
        assert result["body"] == "consume_me"

    def test_consume_with_ack(self):
        result = mod.consume_with_ack()
        assert result["status"] == "consumed_acked"

    def test_consume_with_nack(self):
        result = mod.consume_with_nack()
        assert result["status"] == "consumed_nacked"

    def test_consume_with_reject(self):
        result = mod.consume_with_reject()
        assert result["status"] == "consumed_rejected"

    def test_consume_with_qos(self):
        result = mod.consume_with_qos()
        assert result["status"] == "qos_consumed"
        assert result["count"] == 2

    def test_consume_json(self):
        result = mod.consume_json()
        assert result["status"] == "json_consumed"
        assert isinstance(result["payload"], dict)


class TestAdvanced:
    def test_dead_letter_queue(self):
        result = mod.dead_letter_queue()
        assert result["status"] == "dead_letter_ok"
        assert result["body"] == "will_be_dead_lettered"

    def test_error_consume_nonexistent_queue(self):
        result = mod.error_consume_nonexistent_queue()
        assert result["status"] == "error"
        assert "msg" in result

    def test_delayed_publish(self):
        result = mod.delayed_publish()
        assert result["status"] == "delayed_publish_ok"
