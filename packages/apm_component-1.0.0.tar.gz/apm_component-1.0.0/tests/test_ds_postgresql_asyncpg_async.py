import pytest
from apm_component import ds_postgresql_asyncpg_async as mod


class TestConnect:
    def test_connect(self):
        result = mod.connect()
        assert result["status"] == "connected"

    def test_connect_dsn(self):
        result = mod.connect_dsn()
        assert result["status"] == "connected_dsn"


class TestPool:
    def test_connect_pool(self):
        result = mod.connect_pool()
        assert result["status"] == "pool_created"

    def test_get_connection_from_pool(self):
        result = mod.get_connection_from_pool()
        assert result["status"] == "pool_connection_ok"


class TestConnectionErrors:
    def test_wrong_password(self):
        result = mod.connect_error_wrong_password()
        assert result["status"] == "error"

    def test_wrong_host(self):
        result = mod.connect_error_wrong_host()
        assert result["status"] == "error"

    def test_unknown_db(self):
        result = mod.connect_error_unknown_db()
        assert result["status"] == "error"

    def test_timeout(self):
        result = mod.connect_error_timeout()
        assert result["status"] == "error"


class TestSchema:
    def test_create_table(self):
        result = mod.execute_create_table()
        assert result["status"] == "table_created"

    def test_drop_table(self):
        mod.execute_create_table()
        result = mod.execute_drop_table()
        assert result["status"] == "table_dropped"


class TestInsert:
    def test_insert(self):
        mod.execute_create_table()
        result = mod.execute_insert()
        assert result["status"] == "inserted"

    def test_insert_many(self):
        mod.execute_create_table()
        result = mod.execute_insert_many()
        assert result["status"] == "inserted_many"
        assert result["count"] == 3


class TestFetch:
    def test_fetch_one(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.fetch_one()
        assert result["status"] == "fetch_one"

    def test_fetch_all(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.fetch_all()
        assert result["status"] == "fetch_all"

    def test_fetchval(self):
        mod.execute_create_table()
        result = mod.fetchval()
        assert result["status"] == "fetchval"


class TestUpdate:
    def test_update(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.execute_update()
        assert result["status"] == "updated"


class TestDelete:
    def test_delete(self):
        mod.execute_create_table()
        mod.execute_insert()
        result = mod.execute_delete()
        assert result["status"] == "deleted"

    def test_delete_all(self):
        mod.execute_create_table()
        result = mod.execute_delete_all()
        assert result["status"] == "truncated"


class TestTransaction:
    def test_transaction(self):
        mod.execute_create_table()
        result = mod.execute_transaction()
        assert result["status"] == "transaction_ok"

    def test_savepoint(self):
        mod.execute_create_table()
        result = mod.execute_savepoint()
        assert result["status"] == "savepoint_ok"


class TestPrepared:
    def test_prepared_insert(self):
        mod.execute_create_table()
        result = mod.prepared_insert()
        assert result["status"] == "prepared_insert_ok"

    def test_prepared_select(self):
        mod.execute_create_table()
        result = mod.prepared_select()
        assert result["status"] == "prepared_select_ok"


class TestDataTypes:
    def test_jsonb(self):
        mod.execute_create_table()
        result = mod.insert_jsonb()
        assert result["status"] == "jsonb_ok"

    def test_array(self):
        mod.execute_create_table()
        result = mod.insert_array()
        assert result["status"] == "array_ok"
        assert len(result["tags"]) == 3


class TestErrors:
    def test_query_syntax(self):
        result = mod.error_query_syntax()
        assert result["status"] == "error"

    def test_table_not_found(self):
        result = mod.error_table_not_found()
        assert result["status"] == "error"


class TestAdvanced:
    def test_delayed_insert(self):
        mod.execute_create_table()
        result = mod.delayed_insert()
        assert result["status"] == "delayed_insert_ok"

    def test_concurrent_queries(self):
        mod.execute_create_table()
        result = mod.concurrent_queries()
        assert result["status"] == "concurrent_ok"
        assert result["results"] == [1, 2, 3]
