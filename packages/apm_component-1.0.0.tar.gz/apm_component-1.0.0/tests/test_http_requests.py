import pytest
from apm_component import http_requests as mod


class TestHTTPMethods:
    def test_http_get(self):
        result = mod.http_get()
        assert result["status"] == "success"
        assert result["status_code"] == 200

    def test_http_get_with_params(self):
        result = mod.http_get_with_params()
        assert result["status"] == "success"
        assert result["status_code"] == 200

    def test_http_post_json(self):
        result = mod.http_post_json()
        assert result["status"] == "success"
        assert result["status_code"] == 200

    def test_http_post_form(self):
        result = mod.http_post_form()
        assert result["status"] == "success"
        assert result["status_code"] == 200

    def test_http_put(self):
        result = mod.http_put()
        assert result["status"] == "success"
        assert result["status_code"] == 200

    def test_http_delete(self):
        result = mod.http_delete()
        assert result["status"] == "success"
        assert result["status_code"] == 200

    def test_http_patch(self):
        result = mod.http_patch()
        assert result["status"] == "success"
        assert result["status_code"] == 200


class TestHeadersAuth:
    def test_http_custom_headers(self):
        result = mod.http_custom_headers()
        assert result["status"] == "success"
        assert result["status_code"] == 200

    def test_http_bearer_auth(self):
        result = mod.http_bearer_auth()
        assert result["status"] == "success"
        assert result["status_code"] == 200

    def test_http_basic_auth(self):
        result = mod.http_basic_auth()
        assert result["status"] == "success"
        assert result["status_code"] == 200


class TestErrorHandling:
    def test_http_timeout_error(self):
        result = mod.http_timeout_error()
        assert result["status"] == "error"
        assert "msg" in result

    def test_http_connection_error(self):
        result = mod.http_connection_error()
        assert result["status"] == "error"
        assert "msg" in result

    def test_http_status_error(self):
        result = mod.http_status_error()
        assert result["status"] == "success"
        assert result["status_code"] == 404

    def test_http_retry_logic(self):
        result = mod.http_retry_logic()
        assert result["status"] in ("success", "error")


class TestResponseTypes:
    def test_http_response_json(self):
        result = mod.http_response_json()
        assert result["status"] == "success"

    def test_http_response_text(self):
        result = mod.http_response_text()
        assert result["status"] == "success"

    def test_http_response_binary(self):
        result = mod.http_response_binary()
        assert result["status"] == "success"

    def test_http_response_stream(self):
        result = mod.http_response_stream()
        assert result["status"] == "success"

    def test_http_response_html(self):
        result = mod.http_response_html()
        assert result["status"] == "success"

    def test_http_response_xml(self):
        result = mod.http_response_xml()
        assert result["status"] == "success"

    def test_http_response_headers(self):
        result = mod.http_response_headers()
        assert result["status"] == "success"


class TestAdvanced:
    def test_http_session_reuse(self):
        result = mod.http_session_reuse()
        assert result["status"] == "success"

    def test_http_connection_pool(self):
        result = mod.http_connection_pool()
        assert result["status"] == "success"
        assert result["status_code"] == 200

    def test_http_ssl_verify(self):
        result = mod.http_ssl_verify()
        assert result["status"] == "success"

    def test_http_ssl_no_verify(self):
        result = mod.http_ssl_no_verify()
        assert result["status"] == "success"

    def test_http_redirect(self):
        result = mod.http_redirect()
        assert result["status"] == "success"

    def test_http_cookies(self):
        result = mod.http_cookies()
        assert result["status"] == "success"

    def test_http_prepared_request(self):
        result = mod.http_prepared_request()
        assert result["status"] == "success"
        assert result["status_code"] == 200

    def test_http_delay_request(self):
        result = mod.http_delay_request()
        assert result["status"] == "success"
        assert result["status_code"] == 200

    def test_http_dynamic_request(self):
        result = mod.http_dynamic_request()
        assert result["status"] == "success"
        assert result["status_code"] == 200
