import pytest
from apm_component import ds_cassandra_cassandra_driver as mod


class TestConnect:
    def test_connect(self):
        result = mod.connect()
        assert result["status"] == "connected"

    def test_connect_keyspace(self):
        result = mod.connect_keyspace()
        assert result["status"] == "connected_keyspace"


class TestConnectionErrors:
    def test_wrong_host(self):
        result = mod.connect_error_wrong_host()
        assert result["status"] == "error"

    def test_wrong_port(self):
        result = mod.connect_error_wrong_port()
        assert result["status"] == "error"

    def test_timeout(self):
        result = mod.connect_error_timeout()
        assert result["status"] == "error"

    def test_wrong_auth(self):
        result = mod.connect_error_wrong_auth()
        assert result["status"] in ("error", "unexpected_success")


class TestSchema:
    def test_create_keyspace(self):
        result = mod.create_keyspace()
        assert result["status"] == "keyspace_created"

    def test_drop_keyspace(self):
        result = mod.drop_keyspace()
        assert result["status"] == "keyspace_dropped_and_recreated"

    def test_create_table(self):
        result = mod.create_table()
        assert result["status"] == "table_created"

    def test_drop_table(self):
        result = mod.drop_table()
        assert result["status"] == "table_dropped"


class TestInsert:
    def test_insert_one(self):
        mod.create_table()
        result = mod.insert_one()
        assert result["status"] == "inserted"
        assert "id" in result

    def test_insert_many(self):
        mod.create_table()
        result = mod.insert_many()
        assert result["status"] == "inserted_many"
        assert result["count"] == 5

    def test_insert_with_ttl(self):
        mod.create_table()
        result = mod.insert_with_ttl()
        assert result["status"] == "inserted_with_ttl"

    def test_insert_if_not_exists(self):
        mod.create_table()
        result = mod.insert_if_not_exists()
        assert result["status"] == "insert_if_not_exists"
        assert result["applied"] is True


class TestRead:
    def test_find_one(self):
        mod.create_table()
        result = mod.find_one()
        assert result["status"] == "found"
        assert result["name"] == "find_me"

    def test_find_all(self):
        mod.create_table()
        mod.insert_one()
        result = mod.find_all()
        assert result["status"] == "found_all"
        assert result["count"] >= 1

    def test_find_with_filter(self):
        mod.create_table()
        result = mod.find_with_filter()
        assert result["status"] == "filtered"
        assert result["count"] == 3

    def test_find_with_pagination(self):
        mod.create_table()
        result = mod.find_with_pagination()
        assert result["status"] == "paginated"
        assert result["total_rows"] == 10


class TestUpdate:
    def test_update_one(self):
        mod.create_table()
        result = mod.update_one()
        assert result["status"] == "updated"
        assert result["value"] == 999

    def test_update_with_condition(self):
        mod.create_table()
        result = mod.update_with_condition()
        assert result["status"] == "conditional_update"
        assert result["applied"] is True


class TestDelete:
    def test_delete_one(self):
        mod.create_table()
        result = mod.delete_one()
        assert result["status"] == "deleted"

    def test_delete_many(self):
        mod.create_table()
        result = mod.delete_many()
        assert result["status"] == "deleted_many"
        assert result["count"] == 3

    def test_truncate(self):
        mod.create_table()
        result = mod.truncate_table()
        assert result["status"] == "truncated"


class TestPrepared:
    def test_prepared_insert(self):
        mod.create_table()
        result = mod.prepared_insert()
        assert result["status"] == "prepared_insert_ok"

    def test_prepared_select(self):
        mod.create_table()
        result = mod.prepared_select()
        assert result["status"] == "prepared_select_ok"


class TestDataTypes:
    def test_collection_types(self):
        mod.create_table()
        result = mod.insert_collection_types()
        assert result["status"] == "collection_types_ok"
        assert len(result["tags"]) == 3

    def test_various_data_types(self):
        mod.create_table()
        result = mod.insert_various_data_types()
        assert result["status"] == "data_types_ok"


class TestErrors:
    def test_query_syntax_error(self):
        result = mod.error_query_syntax()
        assert result["status"] == "error"

    def test_table_not_found(self):
        result = mod.error_table_not_found()
        assert result["status"] == "error"


class TestAdvanced:
    def test_async_execute(self):
        mod.create_table()
        result = mod.async_execute()
        assert result["status"] == "async_ok"

    def test_consistency_level(self):
        mod.create_table()
        result = mod.consistency_level_query()
        assert result["status"] == "consistency_ok"

    def test_delayed_insert(self):
        mod.create_table()
        result = mod.delayed_insert()
        assert result["status"] == "delayed_insert_ok"

    def test_race_condition(self):
        mod.create_table()
        result = mod.race_condition_test()
        assert result["status"] == "race_test_ok"
