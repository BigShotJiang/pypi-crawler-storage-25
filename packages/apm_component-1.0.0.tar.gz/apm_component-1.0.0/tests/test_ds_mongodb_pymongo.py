import pytest
from apm_component import ds_mongodb_pymongo as mod


class TestConnect:
    def test_connect(self):
        result = mod.connect()
        assert result["status"] == "connected"

    def test_connect_uri(self):
        result = mod.connect_uri()
        assert result["status"] == "connected_uri"

    def test_server_info(self):
        result = mod.server_info()
        assert result["status"] == "info_ok"


class TestPool:
    def test_connect_pool(self):
        result = mod.connect_pool()
        assert result["status"] == "pool_connected"


class TestConnectionErrors:
    def test_wrong_host(self):
        result = mod.connect_error_wrong_host()
        assert result["status"] == "error"

    def test_wrong_port(self):
        result = mod.connect_error_wrong_port()
        assert result["status"] == "error"

    def test_timeout(self):
        result = mod.connect_error_timeout()
        assert result["status"] == "error"

    def test_bad_uri(self):
        result = mod.connect_error_bad_uri()
        assert result["status"] == "error"


class TestSchema:
    def test_create_collection(self):
        result = mod.create_collection()
        assert result["status"] == "collection_created"

    def test_drop_collection(self):
        mod.create_collection()
        result = mod.drop_collection()
        assert result["status"] == "collection_dropped"

    def test_list_collections(self):
        result = mod.list_collections()
        assert result["status"] == "listed"


class TestInsert:
    def test_insert_one(self):
        result = mod.insert_one()
        assert result["status"] == "inserted"
        assert "id" in result

    def test_insert_many(self):
        result = mod.insert_many()
        assert result["status"] == "inserted_many"
        assert result["count"] == 5


class TestRead:
    def test_find_one(self):
        result = mod.find_one()
        assert result["status"] == "found"

    def test_find_one_by_id(self):
        result = mod.find_one_by_id()
        assert result["status"] == "found_by_id"

    def test_find_many(self):
        result = mod.find_many()
        assert result["status"] == "found_many"
        assert result["count"] == 3

    def test_find_with_projection(self):
        result = mod.find_with_projection()
        assert result["status"] == "projection_ok"
        assert "_id" not in result["keys"]

    def test_find_with_sort_skip_limit(self):
        result = mod.find_with_sort_skip_limit()
        assert result["status"] == "sort_skip_limit_ok"
        assert result["count"] == 3

    def test_find_with_operators(self):
        result = mod.find_with_operators()
        assert result["status"] == "operators_ok"

    def test_count_documents(self):
        mod.insert_many()
        result = mod.count_documents()
        assert result["status"] == "count_ok"

    def test_distinct_values(self):
        result = mod.distinct_values()
        assert result["status"] == "distinct_ok"
        assert sorted(result["values"]) == ["x", "y"]


class TestUpdate:
    def test_update_one(self):
        result = mod.update_one()
        assert result["status"] == "updated"

    def test_update_many(self):
        result = mod.update_many()
        assert result["status"] == "updated_many"
        assert result["modified"] == 3

    def test_replace_one(self):
        result = mod.replace_one()
        assert result["status"] == "replaced"

    def test_find_one_and_update(self):
        result = mod.find_one_and_update()
        assert result["status"] == "find_update_ok"
        assert result["value"] == 888


class TestDelete:
    def test_delete_one(self):
        result = mod.delete_one()
        assert result["status"] == "deleted"
        assert result["count"] == 1

    def test_delete_many(self):
        result = mod.delete_many()
        assert result["status"] == "deleted_many"

    def test_find_one_and_delete(self):
        result = mod.find_one_and_delete()
        assert result["status"] == "find_delete_ok"


class TestBulk:
    def test_bulk_write(self):
        result = mod.bulk_write()
        assert result["status"] == "bulk_ok"


class TestIndex:
    def test_create_index(self):
        mod.create_collection()
        result = mod.create_index()
        assert result["status"] == "index_created"

    def test_create_unique_index(self):
        mod.drop_collection()
        mod.create_collection()
        result = mod.create_unique_index()
        assert result["status"] == "unique_index_created"

    def test_create_compound_index(self):
        result = mod.create_compound_index()
        assert result["status"] == "compound_index_created"

    def test_list_indexes(self):
        result = mod.list_indexes()
        assert result["status"] == "listed"

    def test_drop_index(self):
        result = mod.drop_index()
        assert result["status"] == "index_dropped"


class TestAggregation:
    def test_aggregate_pipeline(self):
        result = mod.aggregate_pipeline()
        assert result["status"] == "aggregation_ok"
        assert result["groups"] == 2


class TestDataTypes:
    def test_nested_document(self):
        result = mod.insert_nested_document()
        assert result["status"] == "nested_ok"

    def test_various_data_types(self):
        result = mod.insert_various_data_types()
        assert result["status"] == "data_types_ok"


class TestErrors:
    def test_duplicate_key(self):
        mod.drop_collection()
        result = mod.error_duplicate_key()
        assert result["status"] == "error"

    def test_document_not_found(self):
        result = mod.error_document_not_found()
        assert result["status"] == "not_found"
        assert result["doc"] is None

    def test_invalid_operation(self):
        result = mod.error_invalid_operation()
        assert result["status"] == "error"


class TestAdvanced:
    def test_find_one_and_replace(self):
        result = mod.find_one_and_replace()
        assert result["status"] == "find_replace_ok"

    def test_upsert(self):
        result = mod.upsert()
        assert result["status"] == "upsert_ok"

    def test_delayed_insert(self):
        result = mod.delayed_insert()
        assert result["status"] == "delayed_insert_ok"

    def test_race_condition(self):
        result = mod.race_condition_test()
        assert result["status"] == "race_test_ok"
        assert result["final_counter"] == 2
