"""
Oracle Datastore Component - oracledb module (python-oracledb)
Covers: connection, pool, error handling, CRUD, batch, transactions,
        cursors, data types, schema management, stored procedures, unique cases
"""

import time
import oracledb
from apm_component.config import get_oracle_config


_TABLE = "ct_oracledb"


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------
def _get_config():
    return get_oracle_config()


def _get_dsn():
    cfg = _get_config()
    return f"{cfg['host']}:{cfg['port']}/{cfg['service_name']}"


def _get_connection(**overrides):
    cfg = _get_config()
    params = {
        "user": cfg["user"],
        "password": cfg["password"],
        "dsn": _get_dsn(),
    }
    params.update(overrides)
    return oracledb.connect(**params)


def _ensure_table(conn):
    cursor = conn.cursor()
    try:
        cursor.execute(f"SELECT COUNT(*) FROM user_tables WHERE table_name = '{_TABLE.upper()}'")
        if cursor.fetchone()[0] == 0:
            cursor.execute(f"""
                CREATE TABLE {_TABLE} (
                    id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                    name VARCHAR2(100) NOT NULL,
                    value NUMBER DEFAULT 0,
                    data CLOB,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()
    finally:
        cursor.close()


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------
def connect():
    """Basic connection to Oracle."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM dual")
        result = cursor.fetchone()
        cursor.close()
        return {"status": "connected", "result": result[0]}
    finally:
        conn.close()


def connect_thin():
    """Connect using thin mode (default, no Oracle Client)."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT banner FROM v$version WHERE ROWNUM = 1")
        row = cursor.fetchone()
        cursor.close()
        return {"status": "connected_thin", "banner": row[0][:80] if row else "N/A"}
    except oracledb.DatabaseError:
        return {"status": "connected_thin", "banner": "permission_denied_on_v$version"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Connection pooling
# ---------------------------------------------------------------------------
_pool = None


def connect_pool():
    """Create a connection pool."""
    global _pool
    cfg = _get_config()
    _pool = oracledb.create_pool(
        user=cfg["user"],
        password=cfg["password"],
        dsn=_get_dsn(),
        min=1,
        max=cfg["pool_size"],
        increment=1,
    )
    conn = _pool.acquire()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM dual")
        cursor.close()
        return {"status": "pool_created"}
    finally:
        _pool.release(conn)


def get_connection_from_pool():
    """Acquire a connection from the pool."""
    if _pool is None:
        connect_pool()
    conn = _pool.acquire()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM dual")
        result = cursor.fetchone()
        cursor.close()
        return {"status": "pool_connection_ok", "result": result[0]}
    finally:
        _pool.release(conn)


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
def connect_error_wrong_password():
    """Attempt connection with wrong password."""
    try:
        conn = _get_connection(password="wrong_password_xyz")
        conn.close()
        return {"status": "unexpected_success"}
    except oracledb.DatabaseError as e:
        error = e.args[0]
        return {"status": "error", "code": getattr(error, "code", None), "msg": str(e)[:200]}


def connect_error_wrong_host():
    """Attempt connection to unreachable host."""
    try:
        conn = oracledb.connect(
            user="x", password="x", dsn="192.0.2.1:1521/FREEPDB1",
            tcp_connect_timeout=3,
        )
        conn.close()
        return {"status": "unexpected_success"}
    except oracledb.DatabaseError as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_wrong_service():
    """Attempt connection to non-existent service."""
    cfg = _get_config()
    try:
        conn = oracledb.connect(
            user=cfg["user"],
            password=cfg["password"],
            dsn=f"{cfg['host']}:{cfg['port']}/NONEXISTENT_SVC",
        )
        conn.close()
        return {"status": "unexpected_success"}
    except oracledb.DatabaseError as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_timeout():
    """Attempt connection with very short timeout."""
    try:
        conn = oracledb.connect(
            user="x", password="x", dsn="192.0.2.1:1521/FREEPDB1",
            tcp_connect_timeout=1,
        )
        conn.close()
        return {"status": "unexpected_success"}
    except oracledb.DatabaseError as e:
        return {"status": "error", "msg": str(e)[:200]}


def pool_error_exhaustion():
    """Exhaust pool connections."""
    cfg = _get_config()
    small_pool = oracledb.create_pool(
        user=cfg["user"],
        password=cfg["password"],
        dsn=_get_dsn(),
        min=1,
        max=1,
        increment=0,
        getmode=oracledb.POOL_GETMODE_NOWAIT,
    )
    held = []
    try:
        held.append(small_pool.acquire())
        held.append(small_pool.acquire())
        return {"status": "unexpected_success"}
    except oracledb.DatabaseError as e:
        return {"status": "pool_exhausted", "msg": str(e)[:200]}
    finally:
        for c in held:
            small_pool.release(c)
        small_pool.close()


# ---------------------------------------------------------------------------
# Schema management
# ---------------------------------------------------------------------------
def execute_create_table():
    """Create the test table."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        try:
            cursor.execute(f"DROP TABLE {_TABLE} PURGE")
        except oracledb.DatabaseError:
            pass
        cursor.execute(f"""
            CREATE TABLE {_TABLE} (
                id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                name VARCHAR2(100) NOT NULL,
                value NUMBER DEFAULT 0,
                data CLOB,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        cursor.close()
        return {"status": "table_created"}
    finally:
        conn.close()


def execute_drop_table():
    """Drop the test table."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        try:
            cursor.execute(f"DROP TABLE {_TABLE} PURGE")
            conn.commit()
        except oracledb.DatabaseError:
            pass
        cursor.close()
        return {"status": "table_dropped"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Insert operations
# ---------------------------------------------------------------------------
def execute_insert():
    """Single row insert."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        row_id_var = cursor.var(oracledb.NUMBER)
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (:1, :2) RETURNING id INTO :3",
            ("test_item", 42, row_id_var),
        )
        conn.commit()
        row_id = row_id_var.getvalue()[0]
        cursor.close()
        return {"status": "inserted", "id": int(row_id)}
    finally:
        conn.close()


def execute_insert_many():
    """Batch insert using executemany."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        data = [("batch_1", 10), ("batch_2", 20), ("batch_3", 30)]
        cursor.executemany(
            f"INSERT INTO {_TABLE} (name, value) VALUES (:1, :2)", data
        )
        conn.commit()
        count = cursor.rowcount
        cursor.close()
        return {"status": "inserted_many", "rowcount": count}
    finally:
        conn.close()


def execute_insert_named_params():
    """Insert using named bind variables."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (:name, :value)",
            {"name": "named_item", "value": 77},
        )
        conn.commit()
        cursor.close()
        return {"status": "inserted_named"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Read operations
# ---------------------------------------------------------------------------
def fetch_one():
    """Fetch a single row."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE} WHERE ROWNUM = 1")
        row = cursor.fetchone()
        cursor.close()
        if row:
            return {"status": "fetch_one", "id": row[0], "name": row[1], "value": row[2]}
        return {"status": "fetch_one", "row": None}
    finally:
        conn.close()


def fetch_all():
    """Fetch all rows."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE}")
        rows = cursor.fetchall()
        cursor.close()
        return {"status": "fetch_all", "count": len(rows)}
    finally:
        conn.close()


def fetch_many():
    """Fetch a batch of rows."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE}")
        batch = cursor.fetchmany(2)
        cursor.close()
        return {"status": "fetch_many", "batch_size": len(batch)}
    finally:
        conn.close()


def fetch_with_row_factory():
    """Fetch rows with custom row factory (dict-like)."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE} WHERE ROWNUM <= 5")
        columns = [col[0].lower() for col in cursor.description]
        rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
        cursor.close()
        return {"status": "row_factory_ok", "rows": rows}
    finally:
        conn.close()


def fetch_with_prefetch():
    """Fetch with prefetchrows and arraysize configuration."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        cursor.prefetchrows = 5
        cursor.arraysize = 5
        cursor.execute(f"SELECT id, name, value FROM {_TABLE}")
        rows = cursor.fetchall()
        cursor.close()
        return {"status": "prefetch_ok", "count": len(rows)}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Update operations
# ---------------------------------------------------------------------------
def execute_update():
    """Update rows."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        cursor.execute(
            f"UPDATE {_TABLE} SET value = :1 WHERE name = :2",
            (99, "test_item"),
        )
        conn.commit()
        count = cursor.rowcount
        cursor.close()
        return {"status": "updated", "rowcount": count}
    finally:
        conn.close()


def execute_update_returning():
    """Update with RETURNING clause."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (:1, :2)",
            ("upd_ret", 1),
        )
        conn.commit()
        id_var = cursor.var(oracledb.NUMBER)
        val_var = cursor.var(oracledb.NUMBER)
        cursor.execute(
            f"UPDATE {_TABLE} SET value = :1 WHERE name = :2 RETURNING id, value INTO :3, :4",
            (888, "upd_ret", id_var, val_var),
        )
        conn.commit()
        cursor.close()
        return {"status": "update_returning_ok", "id": int(id_var.getvalue()[0]), "value": int(val_var.getvalue()[0])}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Delete operations
# ---------------------------------------------------------------------------
def execute_delete():
    """Delete rows."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        cursor.execute(f"DELETE FROM {_TABLE} WHERE name = :1", ("test_item",))
        conn.commit()
        count = cursor.rowcount
        cursor.close()
        return {"status": "deleted", "rowcount": count}
    finally:
        conn.close()


def execute_delete_all():
    """Delete all rows (truncate)."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        cursor.execute(f"TRUNCATE TABLE {_TABLE}")
        cursor.close()
        return {"status": "truncated"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Transactions
# ---------------------------------------------------------------------------
def execute_transaction():
    """Explicit transaction with commit and rollback."""
    conn = _get_connection()
    conn.autocommit = False
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (:1, :2)",
            ("txn_item", 100),
        )
        conn.commit()

        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (:1, :2)",
            ("txn_rollback", 200),
        )
        conn.rollback()

        cursor.execute(f"SELECT name FROM {_TABLE} WHERE name LIKE 'txn_%'")
        rows = cursor.fetchall()
        cursor.close()
        return {"status": "transaction_ok", "committed_rows": [r[0] for r in rows]}
    finally:
        conn.close()


def execute_savepoint():
    """Transaction with savepoints."""
    conn = _get_connection()
    conn.autocommit = False
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (:1, :2)",
            ("sp_item1", 10),
        )
        cursor.execute("SAVEPOINT sp1")
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (:1, :2)",
            ("sp_item2", 20),
        )
        cursor.execute("ROLLBACK TO SAVEPOINT sp1")
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (:1, :2)",
            ("sp_item3", 30),
        )
        conn.commit()
        cursor.execute(f"SELECT name FROM {_TABLE} WHERE name LIKE 'sp_%' ORDER BY name")
        rows = cursor.fetchall()
        cursor.close()
        return {"status": "savepoint_ok", "rows": [r[0] for r in rows]}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Index management
# ---------------------------------------------------------------------------
def create_index():
    """Create an index."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        try:
            cursor.execute(f"DROP INDEX idx_{_TABLE}_name")
        except oracledb.DatabaseError:
            pass
        cursor.execute(f"CREATE INDEX idx_{_TABLE}_name ON {_TABLE} (name)")
        conn.commit()
        cursor.close()
        return {"status": "index_created"}
    finally:
        conn.close()


def drop_index():
    """Drop an index."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        try:
            cursor.execute(f"DROP INDEX idx_{_TABLE}_name")
            conn.commit()
        except oracledb.DatabaseError:
            pass
        cursor.close()
        return {"status": "index_dropped"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Stored procedures / PL/SQL
# ---------------------------------------------------------------------------
def call_stored_procedure():
    """Create and call a stored procedure."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        try:
            cursor.execute(f"DROP PROCEDURE sp_get_{_TABLE}_count")
        except oracledb.DatabaseError:
            pass
        cursor.execute(f"""
            CREATE PROCEDURE sp_get_{_TABLE}_count (p_count OUT NUMBER) AS
            BEGIN
                SELECT COUNT(*) INTO p_count FROM {_TABLE};
            END;
        """)
        conn.commit()
        count_var = cursor.var(oracledb.NUMBER)
        cursor.callproc(f"sp_get_{_TABLE}_count", [count_var])
        cursor.close()
        return {"status": "stored_proc_ok", "count": int(count_var.getvalue())}
    finally:
        conn.close()


def call_function():
    """Create and call a stored function."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        try:
            cursor.execute(f"DROP FUNCTION fn_get_{_TABLE}_count")
        except oracledb.DatabaseError:
            pass
        cursor.execute(f"""
            CREATE FUNCTION fn_get_{_TABLE}_count RETURN NUMBER AS
                v_count NUMBER;
            BEGIN
                SELECT COUNT(*) INTO v_count FROM {_TABLE};
                RETURN v_count;
            END;
        """)
        conn.commit()
        result = cursor.callfunc(f"fn_get_{_TABLE}_count", oracledb.NUMBER)
        cursor.close()
        return {"status": "function_ok", "count": int(result)}
    finally:
        conn.close()


def execute_plsql_block():
    """Execute a PL/SQL anonymous block."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        count_var = cursor.var(oracledb.NUMBER)
        cursor.execute(f"""
            BEGIN
                SELECT COUNT(*) INTO :out_count FROM {_TABLE};
            END;
        """, {"out_count": count_var})
        cursor.close()
        return {"status": "plsql_ok", "count": int(count_var.getvalue())}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Data types / serialization
# ---------------------------------------------------------------------------
def insert_clob():
    """Insert and read CLOB data."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        large_text = "x" * 1000
        cursor = conn.cursor()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value, data) VALUES (:1, :2, :3)",
            ("clob_item", 1, large_text),
        )
        conn.commit()
        cursor.execute(f"SELECT data FROM {_TABLE} WHERE name = :1", ("clob_item",))
        row = cursor.fetchone()
        clob_val = row[0]
        if hasattr(clob_val, "read"):
            clob_val = clob_val.read()
        cursor.close()
        return {"status": "clob_ok", "length": len(clob_val)}
    finally:
        conn.close()


def insert_various_data_types():
    """Verify storing different data types."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (:1, :2)",
            ("type_test", 2147483647),
        )
        conn.commit()
        cursor.execute(f"SELECT name, value FROM {_TABLE} WHERE name = :1", ("type_test",))
        row = cursor.fetchone()
        cursor.close()
        return {"status": "data_types_ok", "name": row[0], "value": int(row[1])}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Error scenarios
# ---------------------------------------------------------------------------
def error_query_syntax():
    """Execute a malformed query."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELEC * FORM nonexistent")
        return {"status": "unexpected_success"}
    except oracledb.DatabaseError as e:
        return {"status": "error", "msg": str(e)[:200]}
    finally:
        conn.close()


def error_table_not_found():
    """Query a non-existent table."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM nonexistent_table_xyz")
        return {"status": "unexpected_success"}
    except oracledb.DatabaseError as e:
        return {"status": "error", "msg": str(e)[:200]}
    finally:
        conn.close()


def error_duplicate_key():
    """Insert a duplicate primary key (via unique constraint)."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        try:
            cursor.execute(f"ALTER TABLE {_TABLE} ADD CONSTRAINT uq_{_TABLE}_name UNIQUE (name)")
            conn.commit()
        except oracledb.DatabaseError:
            conn.rollback()

        cursor.execute(f"DELETE FROM {_TABLE} WHERE name = :1", ("dup_test",))
        conn.commit()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (:1, :2)", ("dup_test", 1)
        )
        conn.commit()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (:1, :2)", ("dup_test", 2)
        )
        conn.commit()
        return {"status": "unexpected_success"}
    except oracledb.IntegrityError as e:
        conn.rollback()
        return {"status": "error", "msg": str(e)[:200]}
    finally:
        try:
            cursor = conn.cursor()
            cursor.execute(f"ALTER TABLE {_TABLE} DROP CONSTRAINT uq_{_TABLE}_name")
            conn.commit()
        except oracledb.DatabaseError:
            pass
        conn.close()


# ---------------------------------------------------------------------------
# Unique / advanced cases
# ---------------------------------------------------------------------------
def parameterized_query():
    """Parameterized query execution."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        cursor.execute(
            f"SELECT id, name FROM {_TABLE} WHERE value > :1", (5,)
        )
        rows = cursor.fetchall()
        cursor.close()
        return {"status": "parameterized_ok", "count": len(rows)}
    finally:
        conn.close()


def ping_connection():
    """Ping the database connection."""
    conn = _get_connection()
    try:
        conn.ping()
        return {"status": "ping_ok"}
    finally:
        conn.close()


def connection_info():
    """Get connection info."""
    conn = _get_connection()
    try:
        return {
            "status": "info_ok",
            "version": conn.version,
            "thin": conn.thin,
        }
    finally:
        conn.close()


def delayed_insert():
    """Insert after a server-side delay."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        cursor = conn.cursor()
        cursor.execute("""
            BEGIN
                DBMS_SESSION.SLEEP(1);
            END;
        """)
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (:1, :2)",
            ("delayed_item", 555),
        )
        conn.commit()
        cursor.close()
        return {"status": "delayed_insert_ok"}
    finally:
        conn.close()


def race_condition_test():
    """Simulate a race condition using two connections and FOR UPDATE."""
    conn1 = _get_connection()
    conn2 = _get_connection()
    conn1.autocommit = False
    conn2.autocommit = False
    try:
        _ensure_table(conn1)
        cur1 = conn1.cursor()
        cur1.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (:1, :2)",
            ("race_item", 0),
        )
        conn1.commit()

        cur1.execute(f"SELECT id, value FROM {_TABLE} WHERE name = :1 FOR UPDATE", ("race_item",))
        row = cur1.fetchone()
        row_id, current = row[0], row[1]
        cur1.execute(
            f"UPDATE {_TABLE} SET value = :1 WHERE id = :2", (current + 1, row_id)
        )
        conn1.commit()

        cur2 = conn2.cursor()
        cur2.execute(f"SELECT value FROM {_TABLE} WHERE id = :1 FOR UPDATE", (row_id,))
        current2 = cur2.fetchone()[0]
        cur2.execute(
            f"UPDATE {_TABLE} SET value = :1 WHERE id = :2", (current2 + 1, row_id)
        )
        conn2.commit()

        cur1.execute(f"SELECT value FROM {_TABLE} WHERE id = :1", (row_id,))
        final = cur1.fetchone()[0]
        cur1.close()
        cur2.close()
        return {"status": "race_test_ok", "final_value": int(final)}
    finally:
        conn1.close()
        conn2.close()
