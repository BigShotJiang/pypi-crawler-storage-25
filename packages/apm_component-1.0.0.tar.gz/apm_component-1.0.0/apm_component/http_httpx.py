"""
HTTP Component - httpx module
Covers: GET/POST/PUT/DELETE/PATCH, headers, auth, client reuse, pooling,
        timeouts, errors, response types, SSL, redirects, cookies, HTTP/2,
        event hooks, streaming
"""

import httpx

from apm_component.config import get_http_config
from apm_component.http_urls import (
    GET_URL, GET_PARAMS,
    POST_URL, POST_JSON_BODY, POST_FORM_DATA,
    PUT_URL, PUT_JSON_BODY, DELETE_URL, PATCH_URL, PATCH_JSON_BODY,
    HEADERS_URL, CUSTOM_HEADERS,
    BEARER_AUTH_URL, BEARER_TOKEN, BASIC_AUTH_URL, BASIC_AUTH_USER, BASIC_AUTH_PASS,
    JSON_RESPONSE_URL, TEXT_RESPONSE_URL, BINARY_RESPONSE_URL,
    HTML_RESPONSE_URL, XML_RESPONSE_URL, STREAM_RESPONSE_URL,
    RESPONSE_HEADERS_URL, RESPONSE_HEADERS_PARAMS,
    STATUS_CODE_URL, TIMEOUT_URL, DELAY_URL, CONNECTION_ERROR_URL,
    REDIRECT_URL, COOKIES_SET_URL, COOKIES_GET_URL, COOKIE_PARAMS,
    SSL_VALID_URL, SSL_SELF_SIGNED_URL,
)


def _get_config():
    return get_http_config()


# ---------------------------------------------------------------------------
# Basic HTTP methods
# ---------------------------------------------------------------------------
def http_get():
    cfg = _get_config()
    r = httpx.get(GET_URL, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


def http_get_with_params():
    cfg = _get_config()
    r = httpx.get(GET_URL, params=GET_PARAMS, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "args": r.json().get("args")}


def http_post_json():
    cfg = _get_config()
    r = httpx.post(POST_URL, json=POST_JSON_BODY, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


def http_post_form():
    cfg = _get_config()
    r = httpx.post(POST_URL, data=POST_FORM_DATA, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "form": r.json().get("form")}


def http_put():
    cfg = _get_config()
    r = httpx.put(PUT_URL, json=PUT_JSON_BODY, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


def http_delete():
    cfg = _get_config()
    r = httpx.delete(DELETE_URL, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


def http_patch():
    cfg = _get_config()
    r = httpx.patch(PATCH_URL, json=PATCH_JSON_BODY, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


# ---------------------------------------------------------------------------
# Headers & Auth
# ---------------------------------------------------------------------------
def http_custom_headers():
    cfg = _get_config()
    r = httpx.get(HEADERS_URL, headers=CUSTOM_HEADERS, timeout=cfg["timeout"])
    echoed = r.json().get("headers", {})
    return {"status": "success", "status_code": r.status_code, "echoed_headers": echoed}


def http_bearer_auth():
    cfg = _get_config()
    headers = {"Authorization": f"Bearer {BEARER_TOKEN}"}
    r = httpx.get(BEARER_AUTH_URL, headers=headers, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


def http_basic_auth():
    cfg = _get_config()
    auth = httpx.BasicAuth(BASIC_AUTH_USER, BASIC_AUTH_PASS)
    r = httpx.get(BASIC_AUTH_URL, auth=auth, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


# ---------------------------------------------------------------------------
# Client reuse & Pooling
# ---------------------------------------------------------------------------
def http_client_reuse():
    cfg = _get_config()
    with httpx.Client(timeout=cfg["timeout"]) as client:
        r1 = client.get(GET_URL)
        r2 = client.post(POST_URL, json=POST_JSON_BODY)
        return {
            "status": "success",
            "get_status": r1.status_code,
            "post_status": r2.status_code,
        }


def http_connection_pool():
    cfg = _get_config()
    limits = httpx.Limits(
        max_connections=cfg["pool_maxsize"],
        max_keepalive_connections=cfg["pool_connections"],
    )
    with httpx.Client(limits=limits, timeout=cfg["timeout"]) as client:
        r = client.get(GET_URL)
        return {
            "status": "success",
            "status_code": r.status_code,
            "max_connections": cfg["pool_maxsize"],
            "max_keepalive": cfg["pool_connections"],
        }


# ---------------------------------------------------------------------------
# Error scenarios
# ---------------------------------------------------------------------------
def http_timeout_error():
    try:
        httpx.get(TIMEOUT_URL, timeout=1)
        return {"status": "no_timeout"}
    except httpx.TimeoutException as e:
        return {"status": "error", "msg": str(e)}


def http_connection_error():
    try:
        httpx.get(CONNECTION_ERROR_URL, timeout=3)
        return {"status": "no_error"}
    except (httpx.ConnectError, httpx.TimeoutException, Exception) as e:
        return {"status": "error", "msg": str(e)}


def http_status_error():
    cfg = _get_config()
    r = httpx.get(f"{STATUS_CODE_URL}/404", timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "is_client_error": r.status_code == 404}


# ---------------------------------------------------------------------------
# Response types
# ---------------------------------------------------------------------------
def http_response_json():
    cfg = _get_config()
    r = httpx.get(JSON_RESPONSE_URL, timeout=cfg["timeout"])
    return {"status": "success", "json": r.json()}


def http_response_text():
    cfg = _get_config()
    r = httpx.get(TEXT_RESPONSE_URL, timeout=cfg["timeout"])
    return {"status": "success", "text": r.text[:200]}


def http_response_binary():
    cfg = _get_config()
    r = httpx.get(BINARY_RESPONSE_URL, timeout=cfg["timeout"])
    return {"status": "success", "content_length": len(r.content)}


def http_response_stream():
    cfg = _get_config()
    chunks = []
    with httpx.Client(timeout=cfg["timeout"]) as client:
        with client.stream("GET", STREAM_RESPONSE_URL) as r:
            for chunk in r.iter_bytes(chunk_size=1024):
                if chunk:
                    chunks.append(len(chunk))
    return {"status": "success", "chunk_count": len(chunks), "total_bytes": sum(chunks)}


def http_response_html():
    cfg = _get_config()
    r = httpx.get(HTML_RESPONSE_URL, timeout=cfg["timeout"])
    return {"status": "success", "html": r.text[:200]}


def http_response_xml():
    cfg = _get_config()
    r = httpx.get(XML_RESPONSE_URL, timeout=cfg["timeout"])
    return {"status": "success", "xml": r.text[:200]}


def http_response_headers():
    cfg = _get_config()
    r = httpx.get(RESPONSE_HEADERS_URL, params=RESPONSE_HEADERS_PARAMS, timeout=cfg["timeout"])
    return {"status": "success", "headers": dict(r.headers)}


# ---------------------------------------------------------------------------
# SSL
# ---------------------------------------------------------------------------
def http_ssl_verify():
    cfg = _get_config()
    r = httpx.get(SSL_VALID_URL, verify=True, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code}


def http_ssl_no_verify():
    cfg = _get_config()
    r = httpx.get(SSL_SELF_SIGNED_URL, verify=False, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code}


# ---------------------------------------------------------------------------
# Redirects & Cookies
# ---------------------------------------------------------------------------
def http_redirect():
    cfg = _get_config()
    r = httpx.get(REDIRECT_URL, follow_redirects=True, timeout=cfg["timeout"])
    return {"status": "success", "history_length": len(r.history), "final_url": str(r.url)}


def http_cookies():
    cfg = _get_config()
    with httpx.Client(timeout=cfg["timeout"], follow_redirects=True) as client:
        client.get(COOKIES_SET_URL, params=COOKIE_PARAMS)
        r = client.get(COOKIES_GET_URL)
        return {"status": "success", "cookies": r.json().get("cookies", {})}


# ---------------------------------------------------------------------------
# Advanced
# ---------------------------------------------------------------------------
def http_http2():
    cfg = _get_config()
    try:
        with httpx.Client(http2=True, timeout=cfg["timeout"]) as client:
            r = client.get(GET_URL)
            return {"status": "success", "status_code": r.status_code, "http_version": r.http_version}
    except Exception as e:
        return {"status": "error", "msg": f"HTTP/2 not available: {e}"}


def http_event_hooks():
    cfg = _get_config()
    log = []

    def on_request(request):
        log.append(f"Request: {request.method} {request.url}")

    def on_response(response):
        log.append(f"Response: {response.status_code}")

    with httpx.Client(
        timeout=cfg["timeout"],
        event_hooks={"request": [on_request], "response": [on_response]},
    ) as client:
        r = client.get(GET_URL)
        return {"status": "success", "status_code": r.status_code, "hooks_log": log}


def http_delay_request():
    cfg = _get_config()
    r = httpx.get(DELAY_URL, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


def http_dynamic_request(method="GET", url=None, **kwargs):
    cfg = _get_config()
    kwargs.setdefault("timeout", cfg["timeout"])
    if url is None:
        url = GET_URL
    with httpx.Client() as client:
        r = client.request(method, url, **kwargs)
        return {"status": "success", "method": method, "status_code": r.status_code}


# ---------------------------------------------------------------------------
# ROUTE_MAP
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/http/httpx/http_get": http_get,
    "/http/httpx/http_get_with_params": http_get_with_params,
    "/http/httpx/http_post_json": http_post_json,
    "/http/httpx/http_post_form": http_post_form,
    "/http/httpx/http_put": http_put,
    "/http/httpx/http_delete": http_delete,
    "/http/httpx/http_patch": http_patch,
    "/http/httpx/http_custom_headers": http_custom_headers,
    "/http/httpx/http_bearer_auth": http_bearer_auth,
    "/http/httpx/http_basic_auth": http_basic_auth,
    "/http/httpx/http_client_reuse": http_client_reuse,
    "/http/httpx/http_connection_pool": http_connection_pool,
    "/http/httpx/http_timeout_error": http_timeout_error,
    "/http/httpx/http_connection_error": http_connection_error,
    "/http/httpx/http_status_error": http_status_error,
    "/http/httpx/http_response_json": http_response_json,
    "/http/httpx/http_response_text": http_response_text,
    "/http/httpx/http_response_binary": http_response_binary,
    "/http/httpx/http_response_stream": http_response_stream,
    "/http/httpx/http_response_html": http_response_html,
    "/http/httpx/http_response_xml": http_response_xml,
    "/http/httpx/http_response_headers": http_response_headers,
    "/http/httpx/http_ssl_verify": http_ssl_verify,
    "/http/httpx/http_ssl_no_verify": http_ssl_no_verify,
    "/http/httpx/http_redirect": http_redirect,
    "/http/httpx/http_cookies": http_cookies,
    "/http/httpx/http_http2": http_http2,
    "/http/httpx/http_event_hooks": http_event_hooks,
    "/http/httpx/http_delay_request": http_delay_request,
    "/http/httpx/http_dynamic_request": http_dynamic_request,
}
