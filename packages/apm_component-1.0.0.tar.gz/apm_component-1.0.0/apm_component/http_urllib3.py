"""
HTTP Component - urllib3 module
Covers: GET/POST/PUT/DELETE/PATCH, headers, auth, pool manager, timeouts,
        errors, retry logic, response types, SSL, redirects, streaming
"""

import json
import urllib3
from urllib3.util.retry import Retry

from apm_component.config import get_http_config
from apm_component.http_urls import (
    GET_URL, GET_PARAMS,
    POST_URL, POST_JSON_BODY, POST_FORM_DATA,
    PUT_URL, PUT_JSON_BODY, DELETE_URL, PATCH_URL, PATCH_JSON_BODY,
    HEADERS_URL, CUSTOM_HEADERS,
    BEARER_AUTH_URL, BEARER_TOKEN, BASIC_AUTH_URL, BASIC_AUTH_USER, BASIC_AUTH_PASS,
    JSON_RESPONSE_URL, TEXT_RESPONSE_URL, BINARY_RESPONSE_URL,
    HTML_RESPONSE_URL, XML_RESPONSE_URL, STREAM_RESPONSE_URL,
    RESPONSE_HEADERS_URL, RESPONSE_HEADERS_PARAMS,
    STATUS_CODE_URL, TIMEOUT_URL, DELAY_URL, CONNECTION_ERROR_URL,
    REDIRECT_URL,
    SSL_VALID_URL, SSL_SELF_SIGNED_URL,
)


def _get_config():
    return get_http_config()


def _pool():
    cfg = _get_config()
    return urllib3.PoolManager(
        num_pools=cfg["pool_connections"],
        maxsize=cfg["pool_maxsize"],
        timeout=cfg["timeout"],
    )


# ---------------------------------------------------------------------------
# Basic HTTP methods
# ---------------------------------------------------------------------------
def http_get():
    http = _pool()
    r = http.request("GET", GET_URL)
    return {"status": "success", "status_code": r.status, "data": r.json()}


def http_get_with_params():
    http = _pool()
    r = http.request("GET", GET_URL, fields=GET_PARAMS)
    return {"status": "success", "status_code": r.status, "args": r.json().get("args")}


def http_post_json():
    http = _pool()
    r = http.request("POST", POST_URL, json=POST_JSON_BODY)
    return {"status": "success", "status_code": r.status, "data": r.json()}


def http_post_form():
    http = _pool()
    r = http.request("POST", POST_URL, fields=POST_FORM_DATA)
    return {"status": "success", "status_code": r.status, "form": r.json().get("form")}


def http_put():
    http = _pool()
    r = http.request("PUT", PUT_URL, json=PUT_JSON_BODY)
    return {"status": "success", "status_code": r.status, "data": r.json()}


def http_delete():
    http = _pool()
    r = http.request("DELETE", DELETE_URL)
    return {"status": "success", "status_code": r.status, "data": r.json()}


def http_patch():
    http = _pool()
    r = http.request("PATCH", PATCH_URL, json=PATCH_JSON_BODY)
    return {"status": "success", "status_code": r.status, "data": r.json()}


# ---------------------------------------------------------------------------
# Headers & Auth
# ---------------------------------------------------------------------------
def http_custom_headers():
    http = _pool()
    r = http.request("GET", HEADERS_URL, headers=CUSTOM_HEADERS)
    echoed = r.json().get("headers", {})
    return {"status": "success", "status_code": r.status, "echoed_headers": echoed}


def http_bearer_auth():
    http = _pool()
    headers = {"Authorization": f"Bearer {BEARER_TOKEN}"}
    r = http.request("GET", BEARER_AUTH_URL, headers=headers)
    return {"status": "success", "status_code": r.status, "data": r.json()}


def http_basic_auth():
    http = _pool()
    headers = urllib3.make_headers(basic_auth=f"{BASIC_AUTH_USER}:{BASIC_AUTH_PASS}")
    r = http.request("GET", BASIC_AUTH_URL, headers=headers)
    return {"status": "success", "status_code": r.status, "data": r.json()}


# ---------------------------------------------------------------------------
# Pool Manager
# ---------------------------------------------------------------------------
def http_pool_manager():
    cfg = _get_config()
    http = urllib3.PoolManager(
        num_pools=cfg["pool_connections"],
        maxsize=cfg["pool_maxsize"],
    )
    r = http.request("GET", GET_URL)
    return {
        "status": "success",
        "status_code": r.status,
        "num_pools": cfg["pool_connections"],
        "maxsize": cfg["pool_maxsize"],
    }


# ---------------------------------------------------------------------------
# Error scenarios
# ---------------------------------------------------------------------------
def http_timeout_error():
    http = urllib3.PoolManager()
    try:
        http.request("GET", TIMEOUT_URL, timeout=urllib3.Timeout(total=1.0), retries=False)
        return {"status": "no_timeout"}
    except (urllib3.exceptions.MaxRetryError, urllib3.exceptions.TimeoutError, urllib3.exceptions.ReadTimeoutError) as e:
        return {"status": "error", "msg": str(e)}


def http_connection_error():
    http = urllib3.PoolManager()
    try:
        http.request("GET", CONNECTION_ERROR_URL, timeout=urllib3.Timeout(total=3.0), retries=False)
        return {"status": "no_error"}
    except (urllib3.exceptions.MaxRetryError, urllib3.exceptions.NewConnectionError, Exception) as e:
        return {"status": "error", "msg": str(e)}


def http_status_error():
    http = _pool()
    r = http.request("GET", f"{STATUS_CODE_URL}/404")
    return {"status": "success", "status_code": r.status, "is_client_error": r.status == 404}


# ---------------------------------------------------------------------------
# Retry logic
# ---------------------------------------------------------------------------
def http_retry_logic():
    retry = Retry(total=3, backoff_factor=0.1, status_forcelist=[500, 502, 503])
    http = urllib3.PoolManager(retries=retry)
    try:
        r = http.request("GET", f"{STATUS_CODE_URL}/500")
        return {"status": "success", "status_code": r.status, "retries_configured": 3}
    except Exception as e:
        return {"status": "error", "msg": str(e), "retries_configured": 3}


# ---------------------------------------------------------------------------
# Response types
# ---------------------------------------------------------------------------
def http_response_json():
    http = _pool()
    r = http.request("GET", JSON_RESPONSE_URL)
    return {"status": "success", "json": r.json()}


def http_response_text():
    http = _pool()
    r = http.request("GET", TEXT_RESPONSE_URL)
    return {"status": "success", "text": r.data.decode("utf-8")[:200]}


def http_response_binary():
    http = _pool()
    r = http.request("GET", BINARY_RESPONSE_URL)
    return {"status": "success", "content_length": len(r.data)}


def http_response_stream():
    http = _pool()
    r = http.request("GET", STREAM_RESPONSE_URL, preload_content=False)
    chunks = []
    try:
        for chunk in r.stream(1024):
            if chunk:
                chunks.append(len(chunk))
    finally:
        r.release_conn()
    return {"status": "success", "chunk_count": len(chunks), "total_bytes": sum(chunks)}


def http_response_html():
    http = _pool()
    r = http.request("GET", HTML_RESPONSE_URL)
    return {"status": "success", "html": r.data.decode("utf-8")[:200]}


def http_response_xml():
    http = _pool()
    r = http.request("GET", XML_RESPONSE_URL)
    return {"status": "success", "xml": r.data.decode("utf-8")[:200]}


def http_response_headers():
    http = _pool()
    r = http.request("GET", RESPONSE_HEADERS_URL, fields=RESPONSE_HEADERS_PARAMS)
    return {"status": "success", "headers": dict(r.headers)}


# ---------------------------------------------------------------------------
# SSL
# ---------------------------------------------------------------------------
def http_ssl_verify():
    http = urllib3.PoolManager(cert_reqs="CERT_REQUIRED")
    r = http.request("GET", SSL_VALID_URL)
    return {"status": "success", "status_code": r.status}


def http_ssl_no_verify():
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    http = urllib3.PoolManager(cert_reqs="CERT_NONE")
    r = http.request("GET", SSL_SELF_SIGNED_URL)
    return {"status": "success", "status_code": r.status}


# ---------------------------------------------------------------------------
# Redirects & Delay
# ---------------------------------------------------------------------------
def http_redirect():
    http = _pool()
    r = http.request("GET", REDIRECT_URL, redirect=True)
    return {"status": "success", "status_code": r.status, "final_url": r.geturl()}


def http_delay_request():
    http = _pool()
    r = http.request("GET", DELAY_URL)
    return {"status": "success", "status_code": r.status, "data": r.json()}


# ---------------------------------------------------------------------------
# Dynamic request
# ---------------------------------------------------------------------------
def http_dynamic_request(method="GET", url=None, **kwargs):
    http = _pool()
    if url is None:
        url = GET_URL
    r = http.request(method, url, **kwargs)
    return {"status": "success", "method": method, "status_code": r.status}


# ---------------------------------------------------------------------------
# ROUTE_MAP
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/http/urllib3/http_get": http_get,
    "/http/urllib3/http_get_with_params": http_get_with_params,
    "/http/urllib3/http_post_json": http_post_json,
    "/http/urllib3/http_post_form": http_post_form,
    "/http/urllib3/http_put": http_put,
    "/http/urllib3/http_delete": http_delete,
    "/http/urllib3/http_patch": http_patch,
    "/http/urllib3/http_custom_headers": http_custom_headers,
    "/http/urllib3/http_bearer_auth": http_bearer_auth,
    "/http/urllib3/http_basic_auth": http_basic_auth,
    "/http/urllib3/http_pool_manager": http_pool_manager,
    "/http/urllib3/http_timeout_error": http_timeout_error,
    "/http/urllib3/http_connection_error": http_connection_error,
    "/http/urllib3/http_status_error": http_status_error,
    "/http/urllib3/http_retry_logic": http_retry_logic,
    "/http/urllib3/http_response_json": http_response_json,
    "/http/urllib3/http_response_text": http_response_text,
    "/http/urllib3/http_response_binary": http_response_binary,
    "/http/urllib3/http_response_stream": http_response_stream,
    "/http/urllib3/http_response_html": http_response_html,
    "/http/urllib3/http_response_xml": http_response_xml,
    "/http/urllib3/http_response_headers": http_response_headers,
    "/http/urllib3/http_ssl_verify": http_ssl_verify,
    "/http/urllib3/http_ssl_no_verify": http_ssl_no_verify,
    "/http/urllib3/http_redirect": http_redirect,
    "/http/urllib3/http_delay_request": http_delay_request,
    "/http/urllib3/http_dynamic_request": http_dynamic_request,
}
