"""
Elasticsearch Datastore Component - elasticsearch module
Covers: connection, error handling, document CRUD, bulk operations,
        search, aggregations, index management, pagination, data types, unique cases
"""

import json
import time
from elasticsearch import Elasticsearch, helpers, NotFoundError, ConnectionError as ESConnectionError
from apm_component.config import get_elasticsearch_config


_INDEX = None


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------
def _get_config():
    cfg = get_elasticsearch_config()
    global _INDEX
    _INDEX = cfg["index"]
    return cfg


def _get_client(**overrides):
    cfg = _get_config()
    params = {
        "hosts": [{"host": cfg["host"], "port": cfg["port"], "scheme": "http"}],
        "request_timeout": cfg["timeout"],
    }
    params.update(overrides)
    return Elasticsearch(**params)


def _ensure_index(es):
    if not es.indices.exists(index=_INDEX):
        es.indices.create(
            index=_INDEX,
            body={
                "mappings": {
                    "properties": {
                        "name": {"type": "text", "fields": {"keyword": {"type": "keyword"}}},
                        "value": {"type": "integer"},
                        "description": {"type": "text"},
                        "tags": {"type": "keyword"},
                        "metadata": {"type": "object"},
                        "created_at": {"type": "date"},
                    }
                }
            },
        )


def _cleanup(es):
    if es.indices.exists(index=_INDEX):
        es.indices.delete(index=_INDEX)


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------
def connect():
    """Basic connection to Elasticsearch."""
    es = _get_client()
    try:
        info = es.info()
        return {"status": "connected", "version": info["version"]["number"]}
    finally:
        es.close()


def connect_health():
    """Check cluster health."""
    es = _get_client()
    try:
        health = es.cluster.health()
        return {"status": "connected", "cluster_status": health["status"]}
    finally:
        es.close()


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
def connect_error_wrong_host():
    """Attempt connection to unreachable host."""
    try:
        es = Elasticsearch(
            hosts=[{"host": "192.0.2.1", "port": 9200, "scheme": "http"}],
            request_timeout=3,
            max_retries=0,
        )
        es.info()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_wrong_port():
    """Attempt connection to wrong port."""
    try:
        es = Elasticsearch(
            hosts=[{"host": _get_config()["host"], "port": 59999, "scheme": "http"}],
            request_timeout=3,
            max_retries=0,
        )
        es.info()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_timeout():
    """Attempt connection with very short timeout."""
    try:
        es = Elasticsearch(
            hosts=[{"host": "192.0.2.1", "port": 9200, "scheme": "http"}],
            request_timeout=1,
            max_retries=0,
        )
        es.info()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)[:200]}


# ---------------------------------------------------------------------------
# Index management
# ---------------------------------------------------------------------------
def create_index():
    """Create the test index with mappings."""
    es = _get_client()
    try:
        _cleanup(es)
        _ensure_index(es)
        return {"status": "index_created"}
    finally:
        es.close()


def delete_index():
    """Delete the test index."""
    es = _get_client()
    try:
        _cleanup(es)
        return {"status": "index_deleted"}
    finally:
        es.close()


def index_exists():
    """Check if the test index exists."""
    es = _get_client()
    try:
        _ensure_index(es)
        exists = bool(es.indices.exists(index=_INDEX))
        return {"status": "checked", "exists": exists}
    finally:
        es.close()


def get_mapping():
    """Get index mapping."""
    es = _get_client()
    try:
        _ensure_index(es)
        mapping = es.indices.get_mapping(index=_INDEX)
        return {"status": "mapping_ok", "has_properties": "properties" in mapping[_INDEX]["mappings"]}
    finally:
        es.close()


def refresh_index():
    """Refresh the index to make documents searchable."""
    es = _get_client()
    try:
        _ensure_index(es)
        es.indices.refresh(index=_INDEX)
        return {"status": "refreshed"}
    finally:
        es.close()


# ---------------------------------------------------------------------------
# Document CRUD
# ---------------------------------------------------------------------------
def insert_one():
    """Index a single document."""
    es = _get_client()
    try:
        _ensure_index(es)
        doc = {"name": "test_item", "value": 42, "tags": ["tag1"], "description": "A test document"}
        result = es.index(index=_INDEX, id="doc_1", body=doc, refresh=True)
        return {"status": "inserted", "id": result["_id"], "result": result["result"]}
    finally:
        es.close()


def insert_many():
    """Bulk index multiple documents."""
    es = _get_client()
    try:
        _ensure_index(es)
        actions = [
            {"_index": _INDEX, "_id": f"bulk_{i}", "_source": {"name": f"bulk_item_{i}", "value": i * 10}}
            for i in range(5)
        ]
        success, errors = helpers.bulk(es, actions, refresh=True)
        return {"status": "inserted_many", "success": success, "errors": len(errors) if isinstance(errors, list) else 0}
    finally:
        es.close()


def find_one():
    """Retrieve a document by ID."""
    es = _get_client()
    try:
        _ensure_index(es)
        es.index(index=_INDEX, id="find_1", body={"name": "find_me", "value": 77}, refresh=True)
        doc = es.get(index=_INDEX, id="find_1")
        return {"status": "found", "id": doc["_id"], "name": doc["_source"]["name"]}
    finally:
        es.close()


def find_missing():
    """Attempt to retrieve a non-existent document."""
    es = _get_client()
    try:
        _ensure_index(es)
        es.get(index=_INDEX, id="nonexistent_doc_xyz")
        return {"status": "unexpected_success"}
    except NotFoundError as e:
        return {"status": "not_found", "msg": str(e)[:200]}
    finally:
        es.close()


def document_exists():
    """Check if a document exists."""
    es = _get_client()
    try:
        _ensure_index(es)
        es.index(index=_INDEX, id="exists_1", body={"name": "exists_check"}, refresh=True)
        exists = bool(es.exists(index=_INDEX, id="exists_1"))
        return {"status": "checked", "exists": exists}
    finally:
        es.close()


def update_one():
    """Partial update of a document."""
    es = _get_client()
    try:
        _ensure_index(es)
        es.index(index=_INDEX, id="update_1", body={"name": "update_me", "value": 1}, refresh=True)
        es.update(index=_INDEX, id="update_1", body={"doc": {"value": 999}}, refresh=True)
        doc = es.get(index=_INDEX, id="update_1")
        return {"status": "updated", "value": doc["_source"]["value"]}
    finally:
        es.close()


def delete_one():
    """Delete a document by ID."""
    es = _get_client()
    try:
        _ensure_index(es)
        es.index(index=_INDEX, id="delete_1", body={"name": "delete_me"}, refresh=True)
        result = es.delete(index=_INDEX, id="delete_1", refresh=True)
        return {"status": "deleted", "result": result["result"]}
    finally:
        es.close()


def delete_many():
    """Bulk delete multiple documents."""
    es = _get_client()
    try:
        _ensure_index(es)
        for i in range(3):
            es.index(index=_INDEX, id=f"del_{i}", body={"name": f"del_item_{i}"}, refresh=True)
        actions = [{"_op_type": "delete", "_index": _INDEX, "_id": f"del_{i}"} for i in range(3)]
        success, _ = helpers.bulk(es, actions, refresh=True)
        return {"status": "deleted_many", "success": success}
    finally:
        es.close()


# ---------------------------------------------------------------------------
# Search & querying
# ---------------------------------------------------------------------------
def search_match():
    """Full-text search with match query."""
    es = _get_client()
    try:
        _ensure_index(es)
        es.index(index=_INDEX, id="search_1", body={"name": "searchable document", "value": 10}, refresh=True)
        result = es.search(index=_INDEX, body={"query": {"match": {"name": "searchable"}}})
        hits = result["hits"]["total"]["value"]
        return {"status": "search_ok", "hits": hits}
    finally:
        es.close()


def search_term():
    """Exact term search."""
    es = _get_client()
    try:
        _ensure_index(es)
        es.index(index=_INDEX, id="term_1", body={"name": "exact_term", "value": 20, "tags": ["alpha"]}, refresh=True)
        result = es.search(index=_INDEX, body={"query": {"term": {"tags": "alpha"}}})
        hits = result["hits"]["total"]["value"]
        return {"status": "term_ok", "hits": hits}
    finally:
        es.close()


def search_range():
    """Range query."""
    es = _get_client()
    try:
        _ensure_index(es)
        for i in range(5):
            es.index(index=_INDEX, id=f"range_{i}", body={"name": f"range_{i}", "value": i * 10}, refresh=True)
        result = es.search(index=_INDEX, body={"query": {"range": {"value": {"gte": 20, "lte": 40}}}})
        hits = result["hits"]["total"]["value"]
        return {"status": "range_ok", "hits": hits}
    finally:
        es.close()


def search_bool():
    """Boolean query combining must, should, filter."""
    es = _get_client()
    try:
        _ensure_index(es)
        es.index(index=_INDEX, id="bool_1", body={"name": "bool test", "value": 50, "tags": ["beta"]}, refresh=True)
        result = es.search(
            index=_INDEX,
            body={
                "query": {
                    "bool": {
                        "must": [{"match": {"name": "bool"}}],
                        "filter": [{"range": {"value": {"gte": 40}}}],
                    }
                }
            },
        )
        hits = result["hits"]["total"]["value"]
        return {"status": "bool_ok", "hits": hits}
    finally:
        es.close()


def search_pagination():
    """Paginated search using from/size."""
    es = _get_client()
    try:
        _ensure_index(es)
        _cleanup(es)
        _ensure_index(es)
        for i in range(10):
            es.index(index=_INDEX, id=f"page_{i}", body={"name": f"page_item_{i}", "value": i}, refresh=True)
        page1 = es.search(index=_INDEX, body={"query": {"match_all": {}}, "from": 0, "size": 3, "sort": [{"value": "asc"}]})
        page2 = es.search(index=_INDEX, body={"query": {"match_all": {}}, "from": 3, "size": 3, "sort": [{"value": "asc"}]})
        return {
            "status": "pagination_ok",
            "page1_hits": len(page1["hits"]["hits"]),
            "page2_hits": len(page2["hits"]["hits"]),
        }
    finally:
        es.close()


def search_aggregation():
    """Aggregation query (terms + avg)."""
    es = _get_client()
    try:
        _ensure_index(es)
        _cleanup(es)
        _ensure_index(es)
        for i in range(6):
            es.index(
                index=_INDEX,
                id=f"agg_{i}",
                body={"name": "agg_item", "value": i * 10, "tags": ["group_a" if i % 2 == 0 else "group_b"]},
                refresh=True,
            )
        result = es.search(
            index=_INDEX,
            body={
                "size": 0,
                "aggs": {
                    "by_tag": {"terms": {"field": "tags"}},
                    "avg_value": {"avg": {"field": "value"}},
                },
            },
        )
        return {
            "status": "aggregation_ok",
            "buckets": len(result["aggregations"]["by_tag"]["buckets"]),
            "avg": result["aggregations"]["avg_value"]["value"],
        }
    finally:
        es.close()


def search_sort():
    """Search with sorting."""
    es = _get_client()
    try:
        _ensure_index(es)
        _cleanup(es)
        _ensure_index(es)
        for i in range(5):
            es.index(index=_INDEX, id=f"sort_{i}", body={"name": f"sort_{i}", "value": (5 - i) * 10}, refresh=True)
        result = es.search(index=_INDEX, body={"query": {"match_all": {}}, "sort": [{"value": "asc"}]})
        values = [h["_source"]["value"] for h in result["hits"]["hits"]]
        return {"status": "sort_ok", "values": values}
    finally:
        es.close()


# ---------------------------------------------------------------------------
# Data types / serialization
# ---------------------------------------------------------------------------
def insert_nested_object():
    """Insert a document with nested/object fields."""
    es = _get_client()
    try:
        _ensure_index(es)
        doc = {
            "name": "nested_doc",
            "value": 100,
            "metadata": {"key1": "val1", "key2": "val2", "nested": {"deep": True}},
            "tags": ["x", "y", "z"],
        }
        es.index(index=_INDEX, id="nested_1", body=doc, refresh=True)
        retrieved = es.get(index=_INDEX, id="nested_1")
        return {"status": "nested_ok", "metadata": retrieved["_source"]["metadata"]}
    finally:
        es.close()


def insert_various_data_types():
    """Verify various data types are stored correctly."""
    es = _get_client()
    try:
        _ensure_index(es)
        doc = {"name": "types_test", "value": 2147483647, "tags": ["a", "b"], "description": "Special chars: éàü"}
        es.index(index=_INDEX, id="types_1", body=doc, refresh=True)
        retrieved = es.get(index=_INDEX, id="types_1")
        src = retrieved["_source"]
        return {"status": "data_types_ok", "value": src["value"], "tags": src["tags"]}
    finally:
        es.close()


# ---------------------------------------------------------------------------
# Error scenarios
# ---------------------------------------------------------------------------
def error_query_syntax():
    """Execute a malformed query."""
    es = _get_client()
    try:
        _ensure_index(es)
        es.search(index=_INDEX, body={"query": {"invalid_query_type": {}}})
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)[:200]}
    finally:
        es.close()


def error_index_not_found():
    """Search a non-existent index."""
    es = _get_client()
    try:
        es.search(index="nonexistent_index_xyz", body={"query": {"match_all": {}}})
        return {"status": "unexpected_success"}
    except NotFoundError as e:
        return {"status": "error", "msg": str(e)[:200]}
    finally:
        es.close()


# ---------------------------------------------------------------------------
# Unique / advanced cases
# ---------------------------------------------------------------------------
def count_documents():
    """Count documents in the index."""
    es = _get_client()
    try:
        _ensure_index(es)
        result = es.count(index=_INDEX)
        return {"status": "count_ok", "count": result["count"]}
    finally:
        es.close()


def multi_search():
    """Execute multiple searches in one request."""
    es = _get_client()
    try:
        _ensure_index(es)
        es.index(index=_INDEX, id="ms_1", body={"name": "multi_1", "value": 10}, refresh=True)
        es.index(index=_INDEX, id="ms_2", body={"name": "multi_2", "value": 20}, refresh=True)
        body = [
            {"index": _INDEX},
            {"query": {"match": {"name": "multi_1"}}},
            {"index": _INDEX},
            {"query": {"match": {"name": "multi_2"}}},
        ]
        result = es.msearch(body=body)
        return {"status": "msearch_ok", "responses": len(result["responses"])}
    finally:
        es.close()


def delayed_index():
    """Index a document after a deliberate delay."""
    es = _get_client()
    try:
        _ensure_index(es)
        time.sleep(1)
        es.index(index=_INDEX, id="delayed_1", body={"name": "delayed_doc", "value": 555}, refresh=True)
        doc = es.get(index=_INDEX, id="delayed_1")
        return {"status": "delayed_index_ok", "name": doc["_source"]["name"]}
    finally:
        es.close()


def race_condition_test():
    """Simulate a race with optimistic concurrency (seq_no / primary_term)."""
    es = _get_client()
    try:
        _ensure_index(es)
        es.index(index=_INDEX, id="race_1", body={"name": "race_item", "value": 0}, refresh=True)
        doc = es.get(index=_INDEX, id="race_1")
        seq = doc["_seq_no"]
        pt = doc["_primary_term"]

        # First update succeeds
        es.index(
            index=_INDEX,
            id="race_1",
            body={"name": "race_item", "value": 1},
            if_seq_no=seq,
            if_primary_term=pt,
            refresh=True,
        )

        # Second update with stale seq_no should fail
        try:
            es.index(
                index=_INDEX,
                id="race_1",
                body={"name": "race_item", "value": 2},
                if_seq_no=seq,
                if_primary_term=pt,
                refresh=True,
            )
            conflict = False
        except Exception:
            conflict = True

        return {"status": "race_test_ok", "conflict_detected": conflict}
    finally:
        es.close()
