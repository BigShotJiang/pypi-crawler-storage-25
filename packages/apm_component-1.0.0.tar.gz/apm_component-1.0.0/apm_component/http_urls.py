"""
Shared HTTP request URLs and payloads for all HTTP component modules.
All modules use httpbin.org as the target domain.
"""

BASE_URL = "https://httpbin.org"

# ---------------------------------------------------------------------------
# GET endpoints
# ---------------------------------------------------------------------------
GET_URL = f"{BASE_URL}/get"
GET_WITH_PARAMS_URL = f"{BASE_URL}/get"
GET_PARAMS = {"key": "value", "page": "1"}

# ---------------------------------------------------------------------------
# POST endpoints
# ---------------------------------------------------------------------------
POST_URL = f"{BASE_URL}/post"
POST_JSON_BODY = {"name": "component_test", "value": 42}
POST_FORM_DATA = {"username": "testuser", "password": "testpass"}

# ---------------------------------------------------------------------------
# PUT / DELETE / PATCH endpoints
# ---------------------------------------------------------------------------
PUT_URL = f"{BASE_URL}/put"
PUT_JSON_BODY = {"name": "updated_item", "value": 99}

DELETE_URL = f"{BASE_URL}/delete"

PATCH_URL = f"{BASE_URL}/patch"
PATCH_JSON_BODY = {"value": 100}

# ---------------------------------------------------------------------------
# Headers & Auth
# ---------------------------------------------------------------------------
HEADERS_URL = f"{BASE_URL}/headers"
CUSTOM_HEADERS = {"X-Custom-Header": "component-test", "Accept": "application/json"}

BEARER_AUTH_URL = f"{BASE_URL}/bearer"
BEARER_TOKEN = "test-bearer-token-12345"

BASIC_AUTH_USER = "testuser"
BASIC_AUTH_PASS = "testpass"
BASIC_AUTH_URL = f"{BASE_URL}/basic-auth/{BASIC_AUTH_USER}/{BASIC_AUTH_PASS}"

# ---------------------------------------------------------------------------
# Response types
# ---------------------------------------------------------------------------
JSON_RESPONSE_URL = f"{BASE_URL}/get"
TEXT_RESPONSE_URL = f"{BASE_URL}/robots.txt"
BINARY_RESPONSE_URL = f"{BASE_URL}/image/png"
HTML_RESPONSE_URL = f"{BASE_URL}/html"
XML_RESPONSE_URL = f"{BASE_URL}/xml"
STREAM_RESPONSE_URL = f"{BASE_URL}/stream/3"

# ---------------------------------------------------------------------------
# Response headers
# ---------------------------------------------------------------------------
RESPONSE_HEADERS_URL = f"{BASE_URL}/response-headers"
RESPONSE_HEADERS_PARAMS = {"X-Test-Header": "hello", "X-Another": "world"}

# ---------------------------------------------------------------------------
# Status codes & errors
# ---------------------------------------------------------------------------
STATUS_CODE_URL = f"{BASE_URL}/status"  # append /{code}
TIMEOUT_URL = f"{BASE_URL}/delay/10"
DELAY_URL = f"{BASE_URL}/delay/1"
CONNECTION_ERROR_URL = "http://192.0.2.1:1"  # non-routable, guaranteed to fail

# ---------------------------------------------------------------------------
# Redirects & cookies
# ---------------------------------------------------------------------------
REDIRECT_URL = f"{BASE_URL}/redirect/2"
ABSOLUTE_REDIRECT_URL = f"{BASE_URL}/absolute-redirect/2"
COOKIES_SET_URL = f"{BASE_URL}/cookies/set"
COOKIES_GET_URL = f"{BASE_URL}/cookies"
COOKIE_PARAMS = {"session_id": "abc123", "theme": "dark"}

# ---------------------------------------------------------------------------
# SSL
# ---------------------------------------------------------------------------
SSL_VALID_URL = "https://httpbin.org/get"
SSL_SELF_SIGNED_URL = "https://self-signed.badssl.com/"
