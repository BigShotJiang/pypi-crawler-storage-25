"""
MySQL Component - mysql-connector-python module
Covers: connection, pool, error handling, execution, fetching, advanced features
"""

import mysql.connector
from mysql.connector import pooling, Error, errorcode
from apm_component.config import get_mysql_config


_TABLE = "ct_connector"


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------
def _get_config():
    cfg = get_mysql_config()
    return {
        "host": cfg["host"],
        "port": cfg["port"],
        "user": cfg["user"],
        "password": cfg["password"],
        "database": cfg["database"],
        "connect_timeout": cfg["connect_timeout"],
        "use_pure": True,
    }


def connect():
    """Basic connection using keyword arguments."""
    cfg = _get_config()
    conn = mysql.connector.connect(**cfg)
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        result = cursor.fetchone()
        return {"status": "connected", "result": result}
    finally:
        conn.close()


def connect_with_dict():
    """Connection using a config dictionary."""
    cfg = _get_config()
    conn = mysql.connector.connect(**cfg)
    try:
        return {"status": "connected", "server_info": conn.get_server_info()}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Connection pooling
# ---------------------------------------------------------------------------
_pool = None


def connect_pool():
    """Create a connection pool."""
    global _pool
    cfg = _get_config()
    _pool = pooling.MySQLConnectionPool(
        pool_name="component_pool",
        pool_size=cfg.pop("connect_timeout") and get_mysql_config()["pool_size"],
        pool_reset_session=True,
        **{k: v for k, v in cfg.items() if k != "connect_timeout"},
    )
    return {"status": "pool_created", "pool_name": _pool.pool_name}


def get_connection_from_pool():
    """Acquire a connection from the pool."""
    if _pool is None:
        connect_pool()
    conn = _pool.get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        return {"status": "pool_connection_ok", "result": cursor.fetchone()}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
def connect_error_wrong_password():
    """Attempt connection with wrong password."""
    cfg = _get_config()
    cfg["password"] = "wrong_password_xyz"
    try:
        conn = mysql.connector.connect(**cfg)
        conn.close()
        return {"status": "unexpected_success"}
    except Error as e:
        return {"status": "error", "errno": e.errno, "msg": str(e)}


def connect_error_wrong_host():
    """Attempt connection to unreachable host."""
    cfg = _get_config()
    cfg["host"] = "192.0.2.1"
    cfg["connect_timeout"] = 3
    try:
        conn = mysql.connector.connect(**cfg)
        conn.close()
        return {"status": "unexpected_success"}
    except Error as e:
        return {"status": "error", "errno": e.errno, "msg": str(e)}


def connect_error_unknown_db():
    """Attempt connection to non-existent database."""
    cfg = _get_config()
    cfg["database"] = "non_existent_db_xyz"
    try:
        conn = mysql.connector.connect(**cfg)
        conn.close()
        return {"status": "unexpected_success"}
    except Error as e:
        return {"status": "error", "errno": e.errno, "msg": str(e)}


def connect_error_timeout():
    """Attempt connection with very short timeout to a non-routable address."""
    cfg = _get_config()
    cfg["host"] = "192.0.2.1"
    cfg["connect_timeout"] = 1
    try:
        conn = mysql.connector.connect(**cfg)
        conn.close()
        return {"status": "unexpected_success"}
    except Error as e:
        return {"status": "error", "errno": e.errno, "msg": str(e)}


def pool_error_exhaustion():
    """Exhaust all connections in the pool to trigger PoolError."""
    cfg = _get_config()
    small_pool = pooling.MySQLConnectionPool(
        pool_name="exhaustion_test",
        pool_size=1,
        **{k: v for k, v in cfg.items() if k != "connect_timeout"},
    )
    held = []
    try:
        held.append(small_pool.get_connection())
        held.append(small_pool.get_connection())  # should raise
        return {"status": "unexpected_success"}
    except Error as e:
        return {"status": "pool_exhausted", "msg": str(e)}
    finally:
        for c in held:
            c.close()


# ---------------------------------------------------------------------------
# Query execution
# ---------------------------------------------------------------------------
def _get_connection():
    return mysql.connector.connect(**_get_config())


def execute_create_table():
    """DDL - create a test table."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"DROP TABLE IF EXISTS {_TABLE}")
        cursor.execute(f"""
            CREATE TABLE {_TABLE} (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                value INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        return {"status": "table_created"}
    finally:
        conn.close()


def execute_insert():
    """DML - single row insert."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
            ("test_item", 42),
        )
        conn.commit()
        return {"status": "inserted", "lastrowid": cursor.lastrowid}
    finally:
        conn.close()


def execute_insert_many():
    """DML - batch insert using executemany."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        data = [("batch_1", 10), ("batch_2", 20), ("batch_3", 30)]
        cursor.executemany(
            f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)", data
        )
        conn.commit()
        return {"status": "inserted_many", "rowcount": cursor.rowcount}
    finally:
        conn.close()


def execute_update():
    """DML - update rows."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"UPDATE {_TABLE} SET value = %s WHERE name = %s",
            (99, "test_item"),
        )
        conn.commit()
        return {"status": "updated", "rowcount": cursor.rowcount}
    finally:
        conn.close()


def execute_delete():
    """DML - delete rows."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"DELETE FROM {_TABLE} WHERE name = %s", ("test_item",))
        conn.commit()
        return {"status": "deleted", "rowcount": cursor.rowcount}
    finally:
        conn.close()


def execute_select():
    """DML - select query."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 10")
        rows = cursor.fetchall()
        return {"status": "selected", "rows": rows}
    finally:
        conn.close()


def execute_multi_statement():
    """Execute multiple SQL statements sequentially."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        results = []
        for stmt in ("SELECT 1", "SELECT 2", "SELECT 3"):
            cursor.execute(stmt)
            results.append(cursor.fetchall())
        return {"status": "multi_ok", "results": results}
    finally:
        conn.close()


def execute_parameterized():
    """Parameterized / prepared-style query execution."""
    conn = _get_connection()
    try:
        cursor = conn.cursor(prepared=True)
        cursor.execute(
            f"SELECT id, name FROM {_TABLE} WHERE value > %s", (5,)
        )
        rows = cursor.fetchall()
        return {"status": "parameterized_ok", "rows": rows}
    finally:
        conn.close()


def execute_transaction():
    """Explicit transaction with commit and rollback."""
    conn = _get_connection()
    conn.autocommit = False
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
            ("txn_item", 100),
        )
        conn.commit()

        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
            ("txn_rollback", 200),
        )
        conn.rollback()

        cursor.execute(f"SELECT name FROM {_TABLE} WHERE name LIKE 'txn_%'")
        rows = cursor.fetchall()
        return {"status": "transaction_ok", "committed_rows": rows}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Data fetching
# ---------------------------------------------------------------------------
def fetch_one():
    """Fetch a single row."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 1")
        row = cursor.fetchone()
        return {"status": "fetch_one", "row": row}
    finally:
        conn.close()


def fetch_all():
    """Fetch all rows."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE}")
        rows = cursor.fetchall()
        return {"status": "fetch_all", "count": len(rows), "rows": rows}
    finally:
        conn.close()


def fetch_many():
    """Fetch a batch of rows."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE}")
        batch = cursor.fetchmany(2)
        return {"status": "fetch_many", "batch": batch}
    finally:
        conn.close()


def fetch_dict_cursor():
    """Fetch rows as dictionaries."""
    conn = _get_connection()
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 5")
        rows = cursor.fetchall()
        return {"status": "dict_cursor", "rows": rows}
    finally:
        conn.close()


def fetch_named_tuple():
    """Fetch rows as named tuples."""
    from collections import namedtuple
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 5")
        columns = [desc[0] for desc in cursor.description]
        Row = namedtuple("Row", columns)
        rows = [Row(*r) for r in cursor.fetchall()]
        return {"status": "named_tuple", "rows": [str(r) for r in rows]}
    finally:
        conn.close()


def fetch_buffered():
    """Fetch using buffered cursor."""
    conn = _get_connection()
    try:
        cursor = conn.cursor(buffered=True)
        cursor.execute(f"SELECT id, name, value FROM {_TABLE}")
        count = cursor.rowcount
        rows = cursor.fetchall()
        return {"status": "buffered", "rowcount": count, "rows": rows}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Advanced / unique cases
# ---------------------------------------------------------------------------
def call_stored_procedure():
    """Call a stored procedure (creates one first for testing)."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("DROP PROCEDURE IF EXISTS sp_get_count")
        cursor.execute(f"""
            CREATE PROCEDURE sp_get_count(OUT total INT)
            BEGIN
                SELECT COUNT(*) INTO total FROM {_TABLE};
            END
        """)
        conn.commit()

        cursor.callproc("sp_get_count", (0,))
        for result in cursor.stored_results():
            pass
        cursor.execute("SELECT @_sp_get_count_arg1")
        total = cursor.fetchone()
        return {"status": "stored_proc_ok", "total": total}
    finally:
        conn.close()


def dynamic_query(table_name=_TABLE, columns=None, where_clause=None):
    """Build and execute a query dynamically from parameters."""
    conn = _get_connection()
    try:
        cursor = conn.cursor(dictionary=True)
        cols = ", ".join(columns) if columns else "*"
        query = f"SELECT {cols} FROM `{table_name}`"
        params = ()
        if where_clause:
            query += " WHERE " + where_clause["condition"]
            params = tuple(where_clause.get("params", ()))
        cursor.execute(query, params)
        rows = cursor.fetchall()
        return {"status": "dynamic_query_ok", "rows": rows}
    finally:
        conn.close()


def delayed_insert():
    """Insert with a server-side delay to simulate slow operations."""
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT SLEEP(1)")
        cursor.fetchall()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
            ("delayed_item", 555),
        )
        conn.commit()
        return {"status": "delayed_insert_ok", "lastrowid": cursor.lastrowid}
    finally:
        conn.close()


def race_condition_test():
    """Simulate a race condition using two connections on the same row."""
    conn1 = _get_connection()
    conn2 = _get_connection()
    conn1.autocommit = False
    conn2.autocommit = False
    try:
        cur1 = conn1.cursor()
        cur2 = conn2.cursor()

        cur1.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
            ("race_item", 0),
        )
        conn1.commit()

        cur1.execute(f"SELECT value FROM {_TABLE} WHERE name = 'race_item' FOR UPDATE")
        current = cur1.fetchone()[0]
        cur1.execute(
            f"UPDATE {_TABLE} SET value = %s WHERE name = 'race_item'",
            (current + 1,),
        )
        conn1.commit()

        cur2.execute(f"SELECT value FROM {_TABLE} WHERE name = 'race_item' FOR UPDATE")
        current2 = cur2.fetchone()[0]
        cur2.execute(
            f"UPDATE {_TABLE} SET value = %s WHERE name = 'race_item'",
            (current2 + 1,),
        )
        conn2.commit()

        cur1.execute(f"SELECT value FROM {_TABLE} WHERE name = 'race_item'")
        final = cur1.fetchone()[0]
        return {"status": "race_test_ok", "final_value": final}
    finally:
        conn1.close()
        conn2.close()


# ---------------------------------------------------------------------------
# Global route-to-function mapping
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/db/mysql/mysql_connector_python/connect": connect,
    "/db/mysql/mysql_connector_python/connect_with_dict": connect_with_dict,
    "/db/mysql/mysql_connector_python/connect_pool": connect_pool,
    "/db/mysql/mysql_connector_python/get_connection_from_pool": get_connection_from_pool,
    "/db/mysql/mysql_connector_python/connect_error_wrong_password": connect_error_wrong_password,
    "/db/mysql/mysql_connector_python/connect_error_wrong_host": connect_error_wrong_host,
    "/db/mysql/mysql_connector_python/connect_error_unknown_db": connect_error_unknown_db,
    "/db/mysql/mysql_connector_python/connect_error_timeout": connect_error_timeout,
    "/db/mysql/mysql_connector_python/pool_error_exhaustion": pool_error_exhaustion,
    "/db/mysql/mysql_connector_python/execute_create_table": execute_create_table,
    "/db/mysql/mysql_connector_python/execute_insert": execute_insert,
    "/db/mysql/mysql_connector_python/execute_insert_many": execute_insert_many,
    "/db/mysql/mysql_connector_python/execute_update": execute_update,
    "/db/mysql/mysql_connector_python/execute_delete": execute_delete,
    "/db/mysql/mysql_connector_python/execute_select": execute_select,
    "/db/mysql/mysql_connector_python/execute_multi_statement": execute_multi_statement,
    "/db/mysql/mysql_connector_python/execute_parameterized": execute_parameterized,
    "/db/mysql/mysql_connector_python/execute_transaction": execute_transaction,
    "/db/mysql/mysql_connector_python/fetch_one": fetch_one,
    "/db/mysql/mysql_connector_python/fetch_all": fetch_all,
    "/db/mysql/mysql_connector_python/fetch_many": fetch_many,
    "/db/mysql/mysql_connector_python/fetch_dict_cursor": fetch_dict_cursor,
    "/db/mysql/mysql_connector_python/fetch_named_tuple": fetch_named_tuple,
    "/db/mysql/mysql_connector_python/fetch_buffered": fetch_buffered,
    "/db/mysql/mysql_connector_python/call_stored_procedure": call_stored_procedure,
    "/db/mysql/mysql_connector_python/dynamic_query": dynamic_query,
    "/db/mysql/mysql_connector_python/delayed_insert": delayed_insert,
    "/db/mysql/mysql_connector_python/race_condition_test": race_condition_test,
}
