"""
RabbitMQ Broker Component - pika module
Covers: connection, errors, queue/exchange management, publish, consume,
        ack/nack, message properties, bulk publish, dead letter, serialization
"""

import json
import time
import pika
from apm_component.config import get_rabbitmq_config


_PREFIX = "ct_pika_"


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------
def _get_config():
    return get_rabbitmq_config()


def _get_connection_params():
    cfg = _get_config()
    credentials = pika.PlainCredentials(cfg["user"], cfg["password"])
    return pika.ConnectionParameters(
        host=cfg["host"],
        port=cfg["port"],
        virtual_host=cfg["vhost"],
        credentials=credentials,
        blocked_connection_timeout=cfg["connect_timeout"],
        socket_timeout=cfg["connect_timeout"],
    )


def _get_connection():
    return pika.BlockingConnection(_get_connection_params())


def _queue_name(suffix):
    return f"{_PREFIX}{suffix}"


def _exchange_name(suffix):
    return f"{_PREFIX}ex_{suffix}"


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------
def connect():
    conn = _get_connection()
    try:
        channel = conn.channel()
        return {"status": "connected", "is_open": conn.is_open}
    finally:
        conn.close()


def connect_url():
    cfg = _get_config()
    url = f"amqp://{cfg['user']}:{cfg['password']}@{cfg['host']}:{cfg['port']}{cfg['vhost']}"
    params = pika.URLParameters(url)
    conn = pika.BlockingConnection(params)
    try:
        return {"status": "connected_url", "is_open": conn.is_open}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
def connect_error_wrong_host():
    credentials = pika.PlainCredentials("guest", "guest")
    params = pika.ConnectionParameters(
        host="192.0.2.1",
        port=5672,
        credentials=credentials,
        socket_timeout=3,
        blocked_connection_timeout=3,
    )
    try:
        conn = pika.BlockingConnection(params)
        conn.close()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def connect_error_wrong_port():
    cfg = _get_config()
    credentials = pika.PlainCredentials(cfg["user"], cfg["password"])
    params = pika.ConnectionParameters(
        host=cfg["host"],
        port=55672,
        credentials=credentials,
        socket_timeout=3,
    )
    try:
        conn = pika.BlockingConnection(params)
        conn.close()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def connect_error_wrong_credentials():
    cfg = _get_config()
    credentials = pika.PlainCredentials("bad_user", "bad_pass")
    params = pika.ConnectionParameters(
        host=cfg["host"],
        port=cfg["port"],
        credentials=credentials,
        socket_timeout=5,
    )
    try:
        conn = pika.BlockingConnection(params)
        conn.close()
        return {"status": "unexpected_success"}
    except pika.exceptions.ProbableAuthenticationError as e:
        return {"status": "error", "msg": str(e)}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


# ---------------------------------------------------------------------------
# Queue management
# ---------------------------------------------------------------------------
def declare_queue():
    conn = _get_connection()
    try:
        channel = conn.channel()
        q = _queue_name("basic")
        result = channel.queue_declare(queue=q, durable=True)
        return {
            "status": "queue_declared",
            "queue": result.method.queue,
            "message_count": result.method.message_count,
            "consumer_count": result.method.consumer_count,
        }
    finally:
        conn.close()


def purge_queue():
    conn = _get_connection()
    try:
        channel = conn.channel()
        q = _queue_name("basic")
        channel.queue_declare(queue=q, durable=True)
        result = channel.queue_purge(queue=q)
        return {"status": "queue_purged", "messages_purged": result.method.message_count}
    finally:
        conn.close()


def delete_queue():
    conn = _get_connection()
    try:
        channel = conn.channel()
        q = _queue_name("delete_test")
        channel.queue_declare(queue=q)
        channel.queue_delete(queue=q)
        return {"status": "queue_deleted"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Exchange management
# ---------------------------------------------------------------------------
def declare_exchange():
    conn = _get_connection()
    try:
        channel = conn.channel()
        ex = _exchange_name("direct")
        channel.exchange_declare(exchange=ex, exchange_type="direct", durable=True)
        return {"status": "exchange_declared", "exchange": ex}
    finally:
        conn.close()


def bind_queue_to_exchange():
    conn = _get_connection()
    try:
        channel = conn.channel()
        ex = _exchange_name("direct")
        q = _queue_name("bound")
        channel.exchange_declare(exchange=ex, exchange_type="direct", durable=True)
        channel.queue_declare(queue=q, durable=True)
        channel.queue_bind(queue=q, exchange=ex, routing_key="test_key")
        return {"status": "queue_bound", "queue": q, "exchange": ex, "routing_key": "test_key"}
    finally:
        conn.close()


def delete_exchange():
    conn = _get_connection()
    try:
        channel = conn.channel()
        ex = _exchange_name("del_test")
        channel.exchange_declare(exchange=ex, exchange_type="fanout")
        channel.exchange_delete(exchange=ex)
        return {"status": "exchange_deleted"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Publishing
# ---------------------------------------------------------------------------
def publish_basic():
    conn = _get_connection()
    try:
        channel = conn.channel()
        q = _queue_name("pub_basic")
        channel.queue_declare(queue=q, durable=True)
        channel.queue_purge(queue=q)
        channel.basic_publish(
            exchange="",
            routing_key=q,
            body="hello pika",
            properties=pika.BasicProperties(delivery_mode=2),
        )
        return {"status": "published"}
    finally:
        conn.close()


def publish_to_exchange():
    conn = _get_connection()
    try:
        channel = conn.channel()
        ex = _exchange_name("pub")
        q = _queue_name("pub_ex")
        channel.exchange_declare(exchange=ex, exchange_type="direct", durable=True)
        channel.queue_declare(queue=q, durable=True)
        channel.queue_bind(queue=q, exchange=ex, routing_key="pub_key")
        channel.queue_purge(queue=q)
        channel.basic_publish(
            exchange=ex,
            routing_key="pub_key",
            body="exchange message",
            properties=pika.BasicProperties(delivery_mode=2),
        )
        return {"status": "published_to_exchange"}
    finally:
        conn.close()


def publish_with_properties():
    conn = _get_connection()
    try:
        channel = conn.channel()
        q = _queue_name("pub_props")
        channel.queue_declare(queue=q, durable=True)
        channel.queue_purge(queue=q)
        props = pika.BasicProperties(
            delivery_mode=2,
            content_type="application/json",
            headers={"x-custom": "test_header"},
            priority=5,
            expiration="60000",
        )
        channel.basic_publish(
            exchange="",
            routing_key=q,
            body=json.dumps({"key": "value"}),
            properties=props,
        )
        return {"status": "published_with_properties"}
    finally:
        conn.close()


def publish_bulk():
    conn = _get_connection()
    try:
        channel = conn.channel()
        q = _queue_name("pub_bulk")
        channel.queue_declare(queue=q, durable=True)
        channel.queue_purge(queue=q)
        count = 10
        for i in range(count):
            channel.basic_publish(
                exchange="",
                routing_key=q,
                body=f"bulk_msg_{i}",
                properties=pika.BasicProperties(delivery_mode=2),
            )
        return {"status": "bulk_published", "count": count}
    finally:
        conn.close()


def publish_json():
    conn = _get_connection()
    try:
        channel = conn.channel()
        q = _queue_name("pub_json")
        channel.queue_declare(queue=q, durable=True)
        channel.queue_purge(queue=q)
        payload = {"name": "test", "values": [1, 2, 3], "nested": {"a": True}}
        channel.basic_publish(
            exchange="",
            routing_key=q,
            body=json.dumps(payload),
            properties=pika.BasicProperties(
                content_type="application/json",
                delivery_mode=2,
            ),
        )
        return {"status": "json_published"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Consuming
# ---------------------------------------------------------------------------
def consume_basic_get():
    conn = _get_connection()
    try:
        channel = conn.channel()
        q = _queue_name("pub_basic")
        channel.queue_declare(queue=q, durable=True)
        channel.queue_purge(queue=q)
        channel.basic_publish(exchange="", routing_key=q, body="consume_me")

        method, properties, body = channel.basic_get(queue=q, auto_ack=True)
        if method:
            return {"status": "consumed", "body": body.decode()}
        return {"status": "no_message"}
    finally:
        conn.close()


def consume_with_ack():
    conn = _get_connection()
    try:
        channel = conn.channel()
        q = _queue_name("ack_test")
        channel.queue_declare(queue=q, durable=True)
        channel.queue_purge(queue=q)
        channel.basic_publish(exchange="", routing_key=q, body="ack_me")

        method, properties, body = channel.basic_get(queue=q, auto_ack=False)
        if method:
            channel.basic_ack(delivery_tag=method.delivery_tag)
            return {"status": "consumed_acked", "body": body.decode()}
        return {"status": "no_message"}
    finally:
        conn.close()


def consume_with_nack():
    conn = _get_connection()
    try:
        channel = conn.channel()
        q = _queue_name("nack_test")
        channel.queue_declare(queue=q, durable=True)
        channel.queue_purge(queue=q)
        channel.basic_publish(exchange="", routing_key=q, body="nack_me")

        method, properties, body = channel.basic_get(queue=q, auto_ack=False)
        if method:
            channel.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
            return {"status": "consumed_nacked", "body": body.decode()}
        return {"status": "no_message"}
    finally:
        conn.close()


def consume_with_reject():
    conn = _get_connection()
    try:
        channel = conn.channel()
        q = _queue_name("reject_test")
        channel.queue_declare(queue=q, durable=True)
        channel.queue_purge(queue=q)
        channel.basic_publish(exchange="", routing_key=q, body="reject_me")

        method, properties, body = channel.basic_get(queue=q, auto_ack=False)
        if method:
            channel.basic_reject(delivery_tag=method.delivery_tag, requeue=False)
            return {"status": "consumed_rejected", "body": body.decode()}
        return {"status": "no_message"}
    finally:
        conn.close()


def consume_with_qos():
    conn = _get_connection()
    try:
        channel = conn.channel()
        q = _queue_name("qos_test")
        channel.queue_declare(queue=q, durable=True)
        channel.queue_purge(queue=q)
        for i in range(5):
            channel.basic_publish(exchange="", routing_key=q, body=f"qos_{i}")

        channel.basic_qos(prefetch_count=2)
        messages = []
        for _ in range(2):
            method, properties, body = channel.basic_get(queue=q, auto_ack=False)
            if method:
                messages.append(body.decode())
                channel.basic_ack(delivery_tag=method.delivery_tag)
        return {"status": "qos_consumed", "messages": messages, "count": len(messages)}
    finally:
        conn.close()


def consume_json():
    conn = _get_connection()
    try:
        channel = conn.channel()
        q = _queue_name("pub_json")
        channel.queue_declare(queue=q, durable=True)
        channel.queue_purge(queue=q)
        payload = {"type": "json_test", "data": [1, 2, 3]}
        channel.basic_publish(
            exchange="",
            routing_key=q,
            body=json.dumps(payload),
            properties=pika.BasicProperties(content_type="application/json"),
        )

        method, properties, body = channel.basic_get(queue=q, auto_ack=True)
        if method:
            parsed = json.loads(body.decode())
            return {"status": "json_consumed", "payload": parsed}
        return {"status": "no_message"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Publisher confirms
# ---------------------------------------------------------------------------
def publish_with_confirm():
    conn = _get_connection()
    try:
        channel = conn.channel()
        channel.confirm_delivery()
        q = _queue_name("confirm_test")
        channel.queue_declare(queue=q, durable=True)
        channel.queue_purge(queue=q)
        channel.basic_publish(
            exchange="",
            routing_key=q,
            body="confirmed_msg",
            properties=pika.BasicProperties(delivery_mode=2),
            mandatory=True,
        )
        return {"status": "publish_confirmed"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Dead letter queue
# ---------------------------------------------------------------------------
def dead_letter_queue():
    conn = _get_connection()
    try:
        channel = conn.channel()
        dlx = _exchange_name("dlx")
        dlq = _queue_name("dlq")
        main_q = _queue_name("dl_main")

        channel.exchange_declare(exchange=dlx, exchange_type="direct", durable=True)
        channel.queue_declare(queue=dlq, durable=True)
        channel.queue_bind(queue=dlq, exchange=dlx, routing_key="dead")

        channel.queue_delete(queue=main_q)
        channel.queue_declare(
            queue=main_q,
            durable=True,
            arguments={
                "x-dead-letter-exchange": dlx,
                "x-dead-letter-routing-key": "dead",
            },
        )
        channel.queue_purge(queue=dlq)

        channel.basic_publish(exchange="", routing_key=main_q, body="will_be_dead_lettered")
        method, properties, body = channel.basic_get(queue=main_q, auto_ack=False)
        if method:
            channel.basic_nack(delivery_tag=method.delivery_tag, requeue=False)

        time.sleep(0.5)

        method, properties, body = channel.basic_get(queue=dlq, auto_ack=True)
        if method:
            return {"status": "dead_letter_ok", "body": body.decode()}
        return {"status": "dead_letter_no_message"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Error scenarios
# ---------------------------------------------------------------------------
def error_consume_nonexistent_queue():
    conn = _get_connection()
    try:
        channel = conn.channel()
        try:
            channel.queue_declare(queue="nonexistent_q_xyz_12345", passive=True)
            return {"status": "unexpected_success"}
        except pika.exceptions.ChannelClosedByBroker as e:
            return {"status": "error", "msg": str(e)}
    finally:
        try:
            conn.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Unique / advanced
# ---------------------------------------------------------------------------
def delayed_publish():
    conn = _get_connection()
    try:
        channel = conn.channel()
        q = _queue_name("delayed")
        channel.queue_declare(queue=q, durable=True)
        channel.queue_purge(queue=q)
        time.sleep(1)
        channel.basic_publish(exchange="", routing_key=q, body="delayed_msg")
        method, properties, body = channel.basic_get(queue=q, auto_ack=True)
        if method:
            return {"status": "delayed_publish_ok", "body": body.decode()}
        return {"status": "no_message"}
    finally:
        conn.close()


def publish_binary():
    conn = _get_connection()
    try:
        channel = conn.channel()
        q = _queue_name("binary")
        channel.queue_declare(queue=q, durable=True)
        channel.queue_purge(queue=q)
        binary_data = bytes(range(256))
        channel.basic_publish(
            exchange="",
            routing_key=q,
            body=binary_data,
            properties=pika.BasicProperties(content_type="application/octet-stream"),
        )
        method, properties, body = channel.basic_get(queue=q, auto_ack=True)
        if method:
            return {"status": "binary_ok", "length": len(body)}
        return {"status": "no_message"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Cleanup helper
# ---------------------------------------------------------------------------
def cleanup():
    conn = _get_connection()
    try:
        channel = conn.channel()
        queues = [
            "basic", "pub_basic", "pub_ex", "pub_props", "pub_bulk", "pub_json",
            "ack_test", "nack_test", "reject_test", "qos_test", "confirm_test",
            "dl_main", "dlq", "delete_test", "bound", "delayed", "binary",
        ]
        for q_suffix in queues:
            try:
                channel.queue_delete(queue=_queue_name(q_suffix))
            except Exception:
                channel = conn.channel()

        exchanges = ["direct", "pub", "dlx", "del_test"]
        for ex_suffix in exchanges:
            try:
                channel.exchange_delete(exchange=_exchange_name(ex_suffix))
            except Exception:
                channel = conn.channel()
        return {"status": "cleanup_done"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Global route-to-function mapping
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/broker/rabbitmq/pika/connect": connect,
    "/broker/rabbitmq/pika/connect_url": connect_url,
    "/broker/rabbitmq/pika/connect_error_wrong_host": connect_error_wrong_host,
    "/broker/rabbitmq/pika/connect_error_wrong_port": connect_error_wrong_port,
    "/broker/rabbitmq/pika/connect_error_wrong_credentials": connect_error_wrong_credentials,
    "/broker/rabbitmq/pika/declare_queue": declare_queue,
    "/broker/rabbitmq/pika/purge_queue": purge_queue,
    "/broker/rabbitmq/pika/delete_queue": delete_queue,
    "/broker/rabbitmq/pika/declare_exchange": declare_exchange,
    "/broker/rabbitmq/pika/bind_queue_to_exchange": bind_queue_to_exchange,
    "/broker/rabbitmq/pika/delete_exchange": delete_exchange,
    "/broker/rabbitmq/pika/publish_basic": publish_basic,
    "/broker/rabbitmq/pika/publish_to_exchange": publish_to_exchange,
    "/broker/rabbitmq/pika/publish_with_properties": publish_with_properties,
    "/broker/rabbitmq/pika/publish_bulk": publish_bulk,
    "/broker/rabbitmq/pika/publish_json": publish_json,
    "/broker/rabbitmq/pika/consume_basic_get": consume_basic_get,
    "/broker/rabbitmq/pika/consume_with_ack": consume_with_ack,
    "/broker/rabbitmq/pika/consume_with_nack": consume_with_nack,
    "/broker/rabbitmq/pika/consume_with_reject": consume_with_reject,
    "/broker/rabbitmq/pika/consume_with_qos": consume_with_qos,
    "/broker/rabbitmq/pika/consume_json": consume_json,
    "/broker/rabbitmq/pika/publish_with_confirm": publish_with_confirm,
    "/broker/rabbitmq/pika/dead_letter_queue": dead_letter_queue,
    "/broker/rabbitmq/pika/error_consume_nonexistent_queue": error_consume_nonexistent_queue,
    "/broker/rabbitmq/pika/delayed_publish": delayed_publish,
    "/broker/rabbitmq/pika/publish_binary": publish_binary,
    "/broker/rabbitmq/pika/cleanup": cleanup,
}
