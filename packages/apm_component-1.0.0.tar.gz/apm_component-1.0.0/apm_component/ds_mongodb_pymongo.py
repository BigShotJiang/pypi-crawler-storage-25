"""
MongoDB Datastore Component - pymongo module
Covers: connection, pool, error handling, document CRUD, bulk operations,
        querying, aggregation, index management, data types, unique cases
"""

import json
import time
from datetime import datetime, timezone
from bson import ObjectId
from pymongo import MongoClient, ASCENDING, DESCENDING, IndexModel
from pymongo.errors import (
    ConnectionFailure,
    OperationFailure,
    ServerSelectionTimeoutError,
    DuplicateKeyError,
    ConfigurationError,
)
from pymongo.operations import InsertOne, UpdateOne, DeleteOne, ReplaceOne
from apm_component.config import get_mongodb_config


_COLLECTION = "ct_pymongo"


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------
def _get_config():
    return get_mongodb_config()


def _get_client(**overrides):
    cfg = _get_config()
    params = {
        "host": cfg["host"],
        "port": cfg["port"],
        "username": cfg["user"],
        "password": cfg["password"],
        "serverSelectionTimeoutMS": cfg["connect_timeout"] * 1000,
    }
    params.update(overrides)
    return MongoClient(**params)


def _get_db():
    cfg = _get_config()
    client = _get_client()
    return client, client[cfg["database"]]


def _get_collection():
    client, db = _get_db()
    return client, db[_COLLECTION]


def _cleanup(collection):
    collection.drop()


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------
def connect():
    """Basic connection to MongoDB."""
    client = _get_client()
    try:
        result = client.admin.command("ping")
        return {"status": "connected", "ping": result.get("ok")}
    finally:
        client.close()


def connect_uri():
    """Connect using URI string."""
    cfg = _get_config()
    uri = f"mongodb://{cfg['host']}:{cfg['port']}"
    client = MongoClient(uri, serverSelectionTimeoutMS=cfg["connect_timeout"] * 1000)
    try:
        result = client.admin.command("ping")
        return {"status": "connected_uri", "ping": result.get("ok")}
    finally:
        client.close()


def server_info():
    """Get server info."""
    client = _get_client()
    try:
        info = client.server_info()
        return {"status": "info_ok", "version": info.get("version")}
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Connection pooling
# ---------------------------------------------------------------------------
def connect_pool():
    """Connection with pool configuration."""
    cfg = _get_config()
    client = MongoClient(
        host=cfg["host"],
        port=cfg["port"],
        maxPoolSize=10,
        minPoolSize=1,
        serverSelectionTimeoutMS=cfg["connect_timeout"] * 1000,
    )
    try:
        result = client.admin.command("ping")
        return {"status": "pool_connected", "ping": result.get("ok")}
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
def connect_error_wrong_host():
    """Attempt connection to unreachable host."""
    try:
        client = MongoClient(
            host="192.0.2.1",
            port=27017,
            serverSelectionTimeoutMS=3000,
        )
        client.admin.command("ping")
        return {"status": "unexpected_success"}
    except ServerSelectionTimeoutError as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_wrong_port():
    """Attempt connection to wrong port."""
    try:
        client = MongoClient(
            host=_get_config()["host"],
            port=59999,
            serverSelectionTimeoutMS=3000,
        )
        client.admin.command("ping")
        return {"status": "unexpected_success"}
    except ServerSelectionTimeoutError as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_timeout():
    """Attempt connection with very short timeout."""
    try:
        client = MongoClient(
            host="192.0.2.1",
            port=27017,
            serverSelectionTimeoutMS=1000,
        )
        client.admin.command("ping")
        return {"status": "unexpected_success"}
    except ServerSelectionTimeoutError as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_bad_uri():
    """Attempt connection with invalid URI."""
    try:
        client = MongoClient("mongodb://invalid:uri:bad", serverSelectionTimeoutMS=2000)
        client.admin.command("ping")
        return {"status": "unexpected_success"}
    except (ConfigurationError, Exception) as e:
        return {"status": "error", "msg": str(e)[:200]}


# ---------------------------------------------------------------------------
# Schema management (collection / database)
# ---------------------------------------------------------------------------
def create_collection():
    """Create the test collection."""
    client, db = _get_db()
    try:
        if _COLLECTION not in db.list_collection_names():
            db.create_collection(_COLLECTION)
        return {"status": "collection_created"}
    finally:
        client.close()


def drop_collection():
    """Drop the test collection."""
    client, db = _get_db()
    try:
        db.drop_collection(_COLLECTION)
        return {"status": "collection_dropped"}
    finally:
        client.close()


def list_collections():
    """List all collections in the database."""
    client, db = _get_db()
    try:
        names = db.list_collection_names()
        return {"status": "listed", "collections": names}
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Insert operations
# ---------------------------------------------------------------------------
def insert_one():
    """Insert a single document."""
    client, col = _get_collection()
    try:
        doc = {
            "name": "test_item",
            "value": 42,
            "tags": ["tag1", "tag2"],
            "metadata": {"key1": "val1"},
            "created_at": datetime.now(timezone.utc),
        }
        result = col.insert_one(doc)
        return {"status": "inserted", "id": str(result.inserted_id)}
    finally:
        client.close()


def insert_many():
    """Insert multiple documents."""
    client, col = _get_collection()
    try:
        docs = [
            {"name": f"batch_{i}", "value": i * 10, "tags": [f"tag_{i}"]}
            for i in range(5)
        ]
        result = col.insert_many(docs)
        return {"status": "inserted_many", "count": len(result.inserted_ids)}
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Read operations
# ---------------------------------------------------------------------------
def find_one():
    """Find a single document."""
    client, col = _get_collection()
    try:
        col.insert_one({"name": "find_me", "value": 77})
        doc = col.find_one({"name": "find_me"})
        return {"status": "found", "name": doc["name"], "value": doc["value"]}
    finally:
        client.close()


def find_one_by_id():
    """Find a document by ObjectId."""
    client, col = _get_collection()
    try:
        result = col.insert_one({"name": "find_by_id", "value": 88})
        doc = col.find_one({"_id": result.inserted_id})
        return {"status": "found_by_id", "id": str(doc["_id"]), "name": doc["name"]}
    finally:
        client.close()


def find_many():
    """Find multiple documents with query filters."""
    client, col = _get_collection()
    try:
        col.delete_many({"name": {"$regex": "^query_"}})
        col.insert_many([
            {"name": "query_a", "value": 10},
            {"name": "query_b", "value": 20},
            {"name": "query_c", "value": 30},
        ])
        docs = list(col.find({"name": {"$regex": "^query_"}}).sort("value", ASCENDING))
        return {"status": "found_many", "count": len(docs)}
    finally:
        client.close()


def find_with_projection():
    """Find with field projection."""
    client, col = _get_collection()
    try:
        col.insert_one({"name": "proj_item", "value": 55, "extra": "hidden"})
        doc = col.find_one({"name": "proj_item"}, {"name": 1, "value": 1, "_id": 0})
        return {"status": "projection_ok", "keys": list(doc.keys())}
    finally:
        client.close()


def find_with_sort_skip_limit():
    """Find with sort, skip, and limit."""
    client, col = _get_collection()
    try:
        col.delete_many({"name": {"$regex": "^pag_"}})
        col.insert_many([{"name": f"pag_{i}", "value": i} for i in range(10)])
        docs = list(
            col.find({"name": {"$regex": "^pag_"}})
            .sort("value", ASCENDING)
            .skip(3)
            .limit(3)
        )
        return {"status": "sort_skip_limit_ok", "count": len(docs), "first_value": docs[0]["value"] if docs else None}
    finally:
        client.close()


def find_with_operators():
    """Query with comparison operators."""
    client, col = _get_collection()
    try:
        col.delete_many({"name": {"$regex": "^op_"}})
        col.insert_many([{"name": f"op_{i}", "value": i * 10} for i in range(5)])
        docs = list(col.find({"value": {"$gte": 20, "$lte": 40}}))
        return {"status": "operators_ok", "count": len(docs)}
    finally:
        client.close()


def count_documents():
    """Count documents with filter."""
    client, col = _get_collection()
    try:
        count = col.count_documents({"name": {"$regex": "^batch_"}})
        return {"status": "count_ok", "count": count}
    finally:
        client.close()


def distinct_values():
    """Get distinct values for a field."""
    client, col = _get_collection()
    try:
        col.delete_many({"name": {"$regex": "^dist_"}})
        col.insert_many([
            {"name": "dist_a", "category": "x"},
            {"name": "dist_b", "category": "y"},
            {"name": "dist_c", "category": "x"},
        ])
        vals = col.distinct("category", {"name": {"$regex": "^dist_"}})
        return {"status": "distinct_ok", "values": sorted(vals)}
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Update operations
# ---------------------------------------------------------------------------
def update_one():
    """Update a single document."""
    client, col = _get_collection()
    try:
        col.insert_one({"name": "update_me", "value": 1})
        result = col.update_one({"name": "update_me"}, {"$set": {"value": 999}})
        return {"status": "updated", "modified": result.modified_count}
    finally:
        client.close()


def update_many():
    """Update multiple documents."""
    client, col = _get_collection()
    try:
        col.delete_many({"name": {"$regex": "^upd_"}})
        col.insert_many([{"name": f"upd_{i}", "value": i} for i in range(3)])
        result = col.update_many(
            {"name": {"$regex": "^upd_"}}, {"$inc": {"value": 100}}
        )
        return {"status": "updated_many", "modified": result.modified_count}
    finally:
        client.close()


def replace_one():
    """Replace an entire document."""
    client, col = _get_collection()
    try:
        col.insert_one({"name": "replace_me", "value": 1, "extra": "old"})
        result = col.replace_one(
            {"name": "replace_me"},
            {"name": "replace_me", "value": 999, "extra": "new"},
        )
        return {"status": "replaced", "modified": result.modified_count}
    finally:
        client.close()


def find_one_and_update():
    """Atomic find and update."""
    client, col = _get_collection()
    try:
        col.insert_one({"name": "atomic_update", "value": 1})
        doc = col.find_one_and_update(
            {"name": "atomic_update"},
            {"$set": {"value": 888}},
            return_document=True,
        )
        return {"status": "find_update_ok", "value": doc["value"]}
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Delete operations
# ---------------------------------------------------------------------------
def delete_one():
    """Delete a single document."""
    client, col = _get_collection()
    try:
        col.insert_one({"name": "delete_me", "value": 1})
        result = col.delete_one({"name": "delete_me"})
        return {"status": "deleted", "count": result.deleted_count}
    finally:
        client.close()


def delete_many():
    """Delete multiple documents."""
    client, col = _get_collection()
    try:
        col.insert_many([{"name": f"del_{i}", "value": i} for i in range(3)])
        result = col.delete_many({"name": {"$regex": "^del_"}})
        return {"status": "deleted_many", "count": result.deleted_count}
    finally:
        client.close()


def find_one_and_delete():
    """Atomic find and delete."""
    client, col = _get_collection()
    try:
        col.insert_one({"name": "atomic_del", "value": 1})
        doc = col.find_one_and_delete({"name": "atomic_del"})
        return {"status": "find_delete_ok", "name": doc["name"]}
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Bulk operations
# ---------------------------------------------------------------------------
def bulk_write():
    """Mixed bulk operations."""
    client, col = _get_collection()
    try:
        col.delete_many({"name": {"$regex": "^bulk_"}})
        ops = [
            InsertOne({"name": "bulk_1", "value": 10}),
            InsertOne({"name": "bulk_2", "value": 20}),
            UpdateOne({"name": "bulk_1"}, {"$set": {"value": 15}}),
            DeleteOne({"name": "bulk_2"}),
        ]
        result = col.bulk_write(ops)
        return {
            "status": "bulk_ok",
            "inserted": result.inserted_count,
            "modified": result.modified_count,
            "deleted": result.deleted_count,
        }
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Index management
# ---------------------------------------------------------------------------
def create_index():
    """Create an index."""
    client, col = _get_collection()
    try:
        idx_name = col.create_index([("name", ASCENDING)], name="idx_name")
        return {"status": "index_created", "name": idx_name}
    finally:
        client.close()


def create_unique_index():
    """Create a unique index."""
    client, col = _get_collection()
    try:
        idx_name = col.create_index(
            [("name", ASCENDING)],
            name="idx_name_unique",
            unique=True,
            sparse=True,
        )
        return {"status": "unique_index_created", "name": idx_name}
    finally:
        client.close()


def create_compound_index():
    """Create a compound index."""
    client, col = _get_collection()
    try:
        idx_name = col.create_index(
            [("name", ASCENDING), ("value", DESCENDING)],
            name="idx_name_value",
        )
        return {"status": "compound_index_created", "name": idx_name}
    finally:
        client.close()


def list_indexes():
    """List all indexes on the collection."""
    client, col = _get_collection()
    try:
        indexes = list(col.list_indexes())
        return {"status": "listed", "count": len(indexes), "names": [i["name"] for i in indexes]}
    finally:
        client.close()


def drop_index():
    """Drop an index."""
    client, col = _get_collection()
    try:
        col.create_index([("name", ASCENDING)], name="idx_to_drop")
        col.drop_index("idx_to_drop")
        return {"status": "index_dropped"}
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------
def aggregate_pipeline():
    """Aggregation pipeline with match, group, sort."""
    client, col = _get_collection()
    try:
        col.delete_many({"name": {"$regex": "^agg_"}})
        col.insert_many([
            {"name": "agg_a", "category": "x", "value": 10},
            {"name": "agg_b", "category": "x", "value": 20},
            {"name": "agg_c", "category": "y", "value": 30},
            {"name": "agg_d", "category": "y", "value": 40},
        ])
        pipeline = [
            {"$match": {"name": {"$regex": "^agg_"}}},
            {"$group": {"_id": "$category", "total": {"$sum": "$value"}, "count": {"$sum": 1}}},
            {"$sort": {"_id": 1}},
        ]
        results = list(col.aggregate(pipeline))
        return {"status": "aggregation_ok", "groups": len(results), "results": [{"cat": r["_id"], "total": r["total"]} for r in results]}
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Data types / serialization
# ---------------------------------------------------------------------------
def insert_nested_document():
    """Insert a deeply nested document."""
    client, col = _get_collection()
    try:
        doc = {
            "name": "nested_doc",
            "value": 100,
            "profile": {
                "address": {"city": "TestCity", "zip": "12345"},
                "scores": [95, 87, 91],
            },
            "tags": ["important", "test"],
        }
        result = col.insert_one(doc)
        retrieved = col.find_one({"_id": result.inserted_id})
        return {
            "status": "nested_ok",
            "city": retrieved["profile"]["address"]["city"],
            "scores": retrieved["profile"]["scores"],
        }
    finally:
        client.close()


def insert_various_data_types():
    """Verify storing different data types."""
    client, col = _get_collection()
    try:
        doc = {
            "name": "types_test",
            "int_val": 2147483647,
            "float_val": 3.14159,
            "bool_val": True,
            "null_val": None,
            "list_val": [1, "two", 3.0],
            "date_val": datetime.now(timezone.utc),
        }
        result = col.insert_one(doc)
        retrieved = col.find_one({"_id": result.inserted_id})
        return {
            "status": "data_types_ok",
            "int": retrieved["int_val"],
            "float": retrieved["float_val"],
            "bool": retrieved["bool_val"],
            "null": retrieved["null_val"],
        }
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Error scenarios
# ---------------------------------------------------------------------------
def error_duplicate_key():
    """Insert a document violating unique constraint."""
    client, col = _get_collection()
    try:
        col.drop_indexes()
        col.create_index([("unique_field", ASCENDING)], unique=True, name="idx_unique_temp")
        col.delete_many({"unique_field": "dup_val"})
        col.insert_one({"unique_field": "dup_val", "name": "first"})
        col.insert_one({"unique_field": "dup_val", "name": "second"})
        return {"status": "unexpected_success"}
    except DuplicateKeyError as e:
        return {"status": "error", "msg": str(e)[:200]}
    finally:
        col.drop_index("idx_unique_temp")
        client.close()


def error_document_not_found():
    """Attempt to find a non-existent document."""
    client, col = _get_collection()
    try:
        doc = col.find_one({"_id": ObjectId()})
        return {"status": "not_found", "doc": doc}
    finally:
        client.close()


def error_invalid_operation():
    """Execute an invalid update operation."""
    client, col = _get_collection()
    try:
        col.insert_one({"name": "invalid_op"})
        col.update_one({"name": "invalid_op"}, {"name": "direct_set"})
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)[:200]}
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Unique / advanced cases
# ---------------------------------------------------------------------------
def find_one_and_replace():
    """Atomic find and replace."""
    client, col = _get_collection()
    try:
        col.insert_one({"name": "atomic_replace", "value": 1})
        doc = col.find_one_and_replace(
            {"name": "atomic_replace"},
            {"name": "atomic_replace", "value": 777, "replaced": True},
            return_document=True,
        )
        return {"status": "find_replace_ok", "value": doc["value"], "replaced": doc["replaced"]}
    finally:
        client.close()


def upsert():
    """Upsert (insert if not exists, update if exists)."""
    client, col = _get_collection()
    try:
        col.delete_many({"name": "upsert_item"})
        result = col.update_one(
            {"name": "upsert_item"},
            {"$set": {"value": 123}},
            upsert=True,
        )
        return {
            "status": "upsert_ok",
            "upserted_id": str(result.upserted_id) if result.upserted_id else None,
            "modified": result.modified_count,
        }
    finally:
        client.close()


def delayed_insert():
    """Insert after a deliberate delay."""
    client, col = _get_collection()
    try:
        time.sleep(1)
        result = col.insert_one({"name": "delayed_item", "value": 555})
        return {"status": "delayed_insert_ok", "id": str(result.inserted_id)}
    finally:
        client.close()


def race_condition_test():
    """Simulate a race with find_one_and_update (atomic)."""
    client, col = _get_collection()
    try:
        col.delete_many({"name": "race_item"})
        col.insert_one({"name": "race_item", "counter": 0})
        doc1 = col.find_one_and_update(
            {"name": "race_item"},
            {"$inc": {"counter": 1}},
            return_document=True,
        )
        doc2 = col.find_one_and_update(
            {"name": "race_item"},
            {"$inc": {"counter": 1}},
            return_document=True,
        )
        return {"status": "race_test_ok", "final_counter": doc2["counter"]}
    finally:
        client.close()
