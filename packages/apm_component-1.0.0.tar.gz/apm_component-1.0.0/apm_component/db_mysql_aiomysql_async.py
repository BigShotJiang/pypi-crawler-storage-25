"""
MySQL Component - aiomysql module (async)
Covers: async connection, async pool, error handling, execution, fetching, advanced features
"""

import asyncio
import aiomysql
from apm_component.config import get_mysql_config

_TABLE = "ct_aiomysql"

# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------
def _get_config():
    cfg = get_mysql_config()
    return {
        "host": cfg["host"],
        "port": cfg["port"],
        "user": cfg["user"],
        "password": cfg["password"],
        "db": cfg["database"],
        "connect_timeout": cfg["connect_timeout"],
    }


# ---------------------------------------------------------------------------
# Async connection
# ---------------------------------------------------------------------------
async def _async_connect(**overrides):
    cfg = _get_config()
    cfg.update(overrides)
    return await aiomysql.connect(**cfg)


async def _connect():
    """Basic async connection."""
    conn = await _async_connect()
    try:
        async with conn.cursor() as cur:
            await cur.execute("SELECT 1")
            result = await cur.fetchone()
        return {"status": "connected", "result": result}
    finally:
        conn.close()


def connect():
    return asyncio.run(_connect())


# ---------------------------------------------------------------------------
# Async connection pooling
# ---------------------------------------------------------------------------
async def _create_pool():
    cfg = _get_config()
    mysql_cfg = get_mysql_config()
    return await aiomysql.create_pool(
        host=cfg["host"],
        port=cfg["port"],
        user=cfg["user"],
        password=cfg["password"],
        db=cfg["db"],
        minsize=1,
        maxsize=mysql_cfg["pool_size"],
        pool_recycle=3600,
    )


async def _connect_pool():
    pool = await _create_pool()
    pool.close()
    await pool.wait_closed()
    return {"status": "pool_created"}


def connect_pool():
    return asyncio.run(_connect_pool())


async def _get_connection_from_pool():
    pool = await _create_pool()
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute("SELECT 1")
                result = await cur.fetchone()
        return {"status": "pool_connection_ok", "result": result}
    finally:
        pool.close()
        await pool.wait_closed()


def get_connection_from_pool():
    return asyncio.run(_get_connection_from_pool())


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
async def _connect_error_wrong_password():
    try:
        conn = await _async_connect(password="wrong_password_xyz")
        conn.close()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def connect_error_wrong_password():
    return asyncio.run(_connect_error_wrong_password())


async def _connect_error_wrong_host():
    try:
        conn = await _async_connect(host="192.0.2.1", connect_timeout=3)
        conn.close()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def connect_error_wrong_host():
    return asyncio.run(_connect_error_wrong_host())


async def _connect_error_unknown_db():
    try:
        conn = await _async_connect(db="non_existent_db_xyz")
        conn.close()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def connect_error_unknown_db():
    return asyncio.run(_connect_error_unknown_db())


async def _connect_error_timeout():
    try:
        conn = await _async_connect(host="192.0.2.1", connect_timeout=1)
        conn.close()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def connect_error_timeout():
    return asyncio.run(_connect_error_timeout())


async def _pool_error_exhaustion():
    cfg = _get_config()
    small_pool = await aiomysql.create_pool(
        host=cfg["host"],
        port=cfg["port"],
        user=cfg["user"],
        password=cfg["password"],
        db=cfg["db"],
        minsize=0,
        maxsize=1,
    )
    held = []
    try:
        conn1 = await small_pool.acquire()
        held.append(conn1)
        try:
            conn2 = await asyncio.wait_for(small_pool.acquire(), timeout=2)
            held.append(conn2)
            return {"status": "unexpected_success"}
        except asyncio.TimeoutError:
            return {"status": "pool_exhausted", "msg": "pool acquire timed out"}
    finally:
        for c in held:
            small_pool.release(c)
        small_pool.close()
        await small_pool.wait_closed()


def pool_error_exhaustion():
    return asyncio.run(_pool_error_exhaustion())


# ---------------------------------------------------------------------------
# Query execution (async)
# ---------------------------------------------------------------------------
async def _execute(sql, params=None, commit=False, fetch=None):
    conn = await _async_connect()
    try:
        async with conn.cursor() as cur:
            await cur.execute(sql, params)
            if commit:
                await conn.commit()
            if fetch == "one":
                return await cur.fetchone()
            if fetch == "all":
                return await cur.fetchall()
            if fetch == "many":
                return await cur.fetchmany(2)
            return {"rowcount": cur.rowcount, "lastrowid": cur.lastrowid}
    finally:
        conn.close()


async def _execute_create_table():
    conn = await _async_connect()
    try:
        async with conn.cursor() as cur:
            await cur.execute(f"DROP TABLE IF EXISTS {_TABLE}")
            await cur.execute(f"""
                CREATE TABLE {_TABLE} (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    value INT DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
        await conn.commit()
        return {"status": "table_created"}
    finally:
        conn.close()


def execute_create_table():
    return asyncio.run(_execute_create_table())


async def _execute_insert():
    conn = await _async_connect()
    try:
        async with conn.cursor() as cur:
            await cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
                ("test_item", 42),
            )
            lastrowid = cur.lastrowid
        await conn.commit()
        return {"status": "inserted", "lastrowid": lastrowid}
    finally:
        conn.close()


def execute_insert():
    return asyncio.run(_execute_insert())


async def _execute_insert_many():
    conn = await _async_connect()
    try:
        async with conn.cursor() as cur:
            data = [("batch_1", 10), ("batch_2", 20), ("batch_3", 30)]
            await cur.executemany(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)", data
            )
            rowcount = cur.rowcount
        await conn.commit()
        return {"status": "inserted_many", "rowcount": rowcount}
    finally:
        conn.close()


def execute_insert_many():
    return asyncio.run(_execute_insert_many())


async def _execute_update():
    conn = await _async_connect()
    try:
        async with conn.cursor() as cur:
            await cur.execute(
                f"UPDATE {_TABLE} SET value = %s WHERE name = %s",
                (99, "test_item"),
            )
            rowcount = cur.rowcount
        await conn.commit()
        return {"status": "updated", "rowcount": rowcount}
    finally:
        conn.close()


def execute_update():
    return asyncio.run(_execute_update())


async def _execute_delete():
    conn = await _async_connect()
    try:
        async with conn.cursor() as cur:
            await cur.execute(
                f"DELETE FROM {_TABLE} WHERE name = %s", ("test_item",)
            )
            rowcount = cur.rowcount
        await conn.commit()
        return {"status": "deleted", "rowcount": rowcount}
    finally:
        conn.close()


def execute_delete():
    return asyncio.run(_execute_delete())


async def _execute_select():
    conn = await _async_connect()
    try:
        async with conn.cursor() as cur:
            await cur.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 10")
            rows = await cur.fetchall()
        return {"status": "selected", "rows": rows}
    finally:
        conn.close()


def execute_select():
    return asyncio.run(_execute_select())


async def _execute_parameterized():
    conn = await _async_connect()
    try:
        async with conn.cursor() as cur:
            await cur.execute(
                f"SELECT id, name FROM {_TABLE} WHERE value > %s", (5,)
            )
            rows = await cur.fetchall()
        return {"status": "parameterized_ok", "rows": rows}
    finally:
        conn.close()


def execute_parameterized():
    return asyncio.run(_execute_parameterized())


async def _execute_transaction():
    conn = await _async_connect()
    await conn.autocommit(False)
    try:
        async with conn.cursor() as cur:
            await cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
                ("txn_item", 100),
            )
        await conn.commit()

        async with conn.cursor() as cur:
            await cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
                ("txn_rollback", 200),
            )
        await conn.rollback()

        async with conn.cursor() as cur:
            await cur.execute(f"SELECT name FROM {_TABLE} WHERE name LIKE 'txn_%'")
            rows = await cur.fetchall()
        return {"status": "transaction_ok", "committed_rows": rows}
    finally:
        conn.close()


def execute_transaction():
    return asyncio.run(_execute_transaction())


# ---------------------------------------------------------------------------
# Data fetching (async)
# ---------------------------------------------------------------------------
async def _fetch_one():
    conn = await _async_connect()
    try:
        async with conn.cursor() as cur:
            await cur.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 1")
            row = await cur.fetchone()
        return {"status": "fetch_one", "row": row}
    finally:
        conn.close()


def fetch_one():
    return asyncio.run(_fetch_one())


async def _fetch_all():
    conn = await _async_connect()
    try:
        async with conn.cursor() as cur:
            await cur.execute(f"SELECT id, name, value FROM {_TABLE}")
            rows = await cur.fetchall()
        return {"status": "fetch_all", "count": len(rows), "rows": rows}
    finally:
        conn.close()


def fetch_all():
    return asyncio.run(_fetch_all())


async def _fetch_many():
    conn = await _async_connect()
    try:
        async with conn.cursor() as cur:
            await cur.execute(f"SELECT id, name, value FROM {_TABLE}")
            batch = await cur.fetchmany(2)
        return {"status": "fetch_many", "batch": batch}
    finally:
        conn.close()


def fetch_many():
    return asyncio.run(_fetch_many())


async def _fetch_dict_cursor():
    conn = await _async_connect()
    try:
        async with conn.cursor(aiomysql.DictCursor) as cur:
            await cur.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 5")
            rows = await cur.fetchall()
        return {"status": "dict_cursor", "rows": rows}
    finally:
        conn.close()


def fetch_dict_cursor():
    return asyncio.run(_fetch_dict_cursor())


async def _fetch_ss_cursor():
    conn = await _async_connect()
    try:
        async with conn.cursor(aiomysql.SSCursor) as cur:
            await cur.execute(f"SELECT id, name, value FROM {_TABLE}")
            rows = await cur.fetchall()
        return {"status": "ss_cursor", "rows": rows}
    finally:
        conn.close()


def fetch_ss_cursor():
    return asyncio.run(_fetch_ss_cursor())


# ---------------------------------------------------------------------------
# Advanced / unique cases (async)
# ---------------------------------------------------------------------------
async def _call_stored_procedure():
    conn = await _async_connect()
    try:
        async with conn.cursor() as cur:
            await cur.execute("DROP PROCEDURE IF EXISTS sp_get_count")
            await cur.execute(f"""
                CREATE PROCEDURE sp_get_count(OUT total INT)
                BEGIN
                    SELECT COUNT(*) INTO total FROM {_TABLE};
                END
            """)
        await conn.commit()

        async with conn.cursor() as cur:
            await cur.callproc("sp_get_count", (0,))
            await cur.execute("SELECT @_sp_get_count_0")
            total = await cur.fetchone()
        return {"status": "stored_proc_ok", "total": total}
    finally:
        conn.close()


def call_stored_procedure():
    return asyncio.run(_call_stored_procedure())


async def _concurrent_queries():
    """Execute multiple queries concurrently using asyncio.gather."""
    async def run_query(query):
        conn = await _async_connect()
        try:
            async with conn.cursor() as cur:
                await cur.execute(query)
                return await cur.fetchone()
        finally:
            conn.close()

    results = await asyncio.gather(
        run_query("SELECT 1 AS a"),
        run_query("SELECT 2 AS b"),
        run_query("SELECT 3 AS c"),
    )
    return {"status": "concurrent_ok", "results": results}


def concurrent_queries():
    return asyncio.run(_concurrent_queries())


async def _timeout_query():
    """Execute a slow query with asyncio.wait_for timeout."""
    conn = await _async_connect()
    try:
        async with conn.cursor() as cur:
            try:
                await asyncio.wait_for(cur.execute("SELECT SLEEP(5)"), timeout=2)
                return {"status": "unexpected_complete"}
            except asyncio.TimeoutError:
                return {"status": "timeout_ok", "msg": "query timed out as expected"}
    finally:
        conn.close()


def timeout_query():
    return asyncio.run(_timeout_query())


async def _dynamic_query(table_name=_TABLE, columns=None, where_clause=None):
    conn = await _async_connect()
    try:
        async with conn.cursor(aiomysql.DictCursor) as cur:
            cols = ", ".join(columns) if columns else "*"
            query = f"SELECT {cols} FROM `{table_name}`"
            params = ()
            if where_clause:
                query += " WHERE " + where_clause["condition"]
                params = tuple(where_clause.get("params", ()))
            await cur.execute(query, params)
            rows = await cur.fetchall()
        return {"status": "dynamic_query_ok", "rows": rows}
    finally:
        conn.close()


def dynamic_query(table_name=_TABLE, columns=None, where_clause=None):
    return asyncio.run(_dynamic_query(table_name, columns, where_clause))


async def _delayed_insert():
    conn = await _async_connect()
    try:
        async with conn.cursor() as cur:
            await cur.execute("SELECT SLEEP(1)")
            await cur.fetchall()
            await cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
                ("delayed_item", 555),
            )
            lastrowid = cur.lastrowid
        await conn.commit()
        return {"status": "delayed_insert_ok", "lastrowid": lastrowid}
    finally:
        conn.close()


def delayed_insert():
    return asyncio.run(_delayed_insert())


async def _race_condition_test():
    conn1 = await _async_connect()
    conn2 = await _async_connect()
    try:
        async with conn1.cursor() as cur1:
            await cur1.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
                ("race_item", 0),
            )
        await conn1.commit()

        async with conn1.cursor() as cur1:
            await cur1.execute(
                f"SELECT value FROM {_TABLE} WHERE name = 'race_item' FOR UPDATE"
            )
            current = (await cur1.fetchone())[0]
            await cur1.execute(
                f"UPDATE {_TABLE} SET value = %s WHERE name = 'race_item'",
                (current + 1,),
            )
        await conn1.commit()

        async with conn2.cursor() as cur2:
            await cur2.execute(
                f"SELECT value FROM {_TABLE} WHERE name = 'race_item' FOR UPDATE"
            )
            current2 = (await cur2.fetchone())[0]
            await cur2.execute(
                f"UPDATE {_TABLE} SET value = %s WHERE name = 'race_item'",
                (current2 + 1,),
            )
        await conn2.commit()

        async with conn1.cursor() as cur1:
            await cur1.execute(
                f"SELECT value FROM {_TABLE} WHERE name = 'race_item'"
            )
            final = (await cur1.fetchone())[0]
        return {"status": "race_test_ok", "final_value": final}
    finally:
        conn1.close()
        conn2.close()


def race_condition_test():
    return asyncio.run(_race_condition_test())


# ---------------------------------------------------------------------------
# Global route-to-function mapping
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/db/mysql/aiomysql/connect": connect,
    "/db/mysql/aiomysql/connect_pool": connect_pool,
    "/db/mysql/aiomysql/get_connection_from_pool": get_connection_from_pool,
    "/db/mysql/aiomysql/connect_error_wrong_password": connect_error_wrong_password,
    "/db/mysql/aiomysql/connect_error_wrong_host": connect_error_wrong_host,
    "/db/mysql/aiomysql/connect_error_unknown_db": connect_error_unknown_db,
    "/db/mysql/aiomysql/connect_error_timeout": connect_error_timeout,
    "/db/mysql/aiomysql/pool_error_exhaustion": pool_error_exhaustion,
    "/db/mysql/aiomysql/execute_create_table": execute_create_table,
    "/db/mysql/aiomysql/execute_insert": execute_insert,
    "/db/mysql/aiomysql/execute_insert_many": execute_insert_many,
    "/db/mysql/aiomysql/execute_update": execute_update,
    "/db/mysql/aiomysql/execute_delete": execute_delete,
    "/db/mysql/aiomysql/execute_select": execute_select,
    "/db/mysql/aiomysql/execute_parameterized": execute_parameterized,
    "/db/mysql/aiomysql/execute_transaction": execute_transaction,
    "/db/mysql/aiomysql/fetch_one": fetch_one,
    "/db/mysql/aiomysql/fetch_all": fetch_all,
    "/db/mysql/aiomysql/fetch_many": fetch_many,
    "/db/mysql/aiomysql/fetch_dict_cursor": fetch_dict_cursor,
    "/db/mysql/aiomysql/fetch_ss_cursor": fetch_ss_cursor,
    "/db/mysql/aiomysql/call_stored_procedure": call_stored_procedure,
    "/db/mysql/aiomysql/concurrent_queries": concurrent_queries,
    "/db/mysql/aiomysql/timeout_query": timeout_query,
    "/db/mysql/aiomysql/dynamic_query": dynamic_query,
    "/db/mysql/aiomysql/delayed_insert": delayed_insert,
    "/db/mysql/aiomysql/race_condition_test": race_condition_test,
}
