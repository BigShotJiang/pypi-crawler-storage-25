"""
PostgreSQL Datastore Component - psycopg2 module
Covers: connection, pool, error handling, CRUD, batch, transactions,
        cursors, data types, schema management, COPY, unique cases
"""

import json
import time
import psycopg2
from psycopg2 import pool, sql, extras, errors
from psycopg2.extras import RealDictCursor, NamedTupleCursor, execute_values
from apm_component.config import get_postgresql_config


_TABLE = "ct_psycopg2"


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------
def _get_config():
    return get_postgresql_config()


def _get_connection(**overrides):
    cfg = _get_config()
    params = {
        "host": cfg["host"],
        "port": cfg["port"],
        "user": cfg["user"],
        "password": cfg["password"],
        "dbname": cfg["database"],
        "connect_timeout": cfg["connect_timeout"],
    }
    params.update(overrides)
    return psycopg2.connect(**params)


def _ensure_table(conn):
    with conn.cursor() as cur:
        cur.execute(f"""
            CREATE TABLE IF NOT EXISTS {_TABLE} (
                id SERIAL PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                value INTEGER DEFAULT 0,
                data JSONB,
                tags TEXT[],
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
    conn.commit()


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------
def connect():
    """Basic connection to PostgreSQL."""
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT 1")
            result = cur.fetchone()
        return {"status": "connected", "result": result[0]}
    finally:
        conn.close()


def connect_dsn():
    """Connect using DSN string."""
    cfg = _get_config()
    dsn = f"host={cfg['host']} port={cfg['port']} user={cfg['user']} password={cfg['password']} dbname={cfg['database']}"
    conn = psycopg2.connect(dsn)
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT version()")
            ver = cur.fetchone()
        return {"status": "connected_dsn", "version": ver[0][:50]}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Connection pooling
# ---------------------------------------------------------------------------
_pool = None


def connect_pool():
    """Create a connection pool using SimpleConnectionPool."""
    global _pool
    cfg = _get_config()
    _pool = pool.SimpleConnectionPool(
        minconn=1,
        maxconn=cfg["pool_size"],
        host=cfg["host"],
        port=cfg["port"],
        user=cfg["user"],
        password=cfg["password"],
        dbname=cfg["database"],
    )
    conn = _pool.getconn()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT 1")
        return {"status": "pool_created"}
    finally:
        _pool.putconn(conn)


def connect_threaded_pool():
    """Create a threaded connection pool."""
    cfg = _get_config()
    tpool = pool.ThreadedConnectionPool(
        minconn=1,
        maxconn=cfg["pool_size"],
        host=cfg["host"],
        port=cfg["port"],
        user=cfg["user"],
        password=cfg["password"],
        dbname=cfg["database"],
    )
    conn = tpool.getconn()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT 1")
        return {"status": "threaded_pool_created"}
    finally:
        tpool.putconn(conn)
        tpool.closeall()


def get_connection_from_pool():
    """Acquire a connection from the pool."""
    if _pool is None:
        connect_pool()
    conn = _pool.getconn()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT 1")
            return {"status": "pool_connection_ok", "result": cur.fetchone()[0]}
    finally:
        _pool.putconn(conn)


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
def connect_error_wrong_password():
    """Attempt connection with wrong password."""
    try:
        conn = _get_connection(password="wrong_password_xyz")
        conn.close()
        return {"status": "unexpected_success"}
    except psycopg2.OperationalError as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_wrong_host():
    """Attempt connection to unreachable host."""
    try:
        conn = _get_connection(host="192.0.2.1", connect_timeout=3)
        conn.close()
        return {"status": "unexpected_success"}
    except psycopg2.OperationalError as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_unknown_db():
    """Attempt connection to non-existent database."""
    try:
        conn = _get_connection(dbname="nonexistent_db_xyz")
        conn.close()
        return {"status": "unexpected_success"}
    except psycopg2.OperationalError as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_timeout():
    """Attempt connection with very short timeout."""
    try:
        conn = _get_connection(host="192.0.2.1", connect_timeout=1)
        conn.close()
        return {"status": "unexpected_success"}
    except psycopg2.OperationalError as e:
        return {"status": "error", "msg": str(e)[:200]}


def pool_error_exhaustion():
    """Exhaust pool connections to trigger error."""
    cfg = _get_config()
    small_pool = pool.SimpleConnectionPool(
        minconn=1,
        maxconn=1,
        host=cfg["host"],
        port=cfg["port"],
        user=cfg["user"],
        password=cfg["password"],
        dbname=cfg["database"],
    )
    held = []
    try:
        held.append(small_pool.getconn())
        held.append(small_pool.getconn())  # should raise
        return {"status": "unexpected_success"}
    except pool.PoolError as e:
        return {"status": "pool_exhausted", "msg": str(e)}
    finally:
        for c in held:
            small_pool.putconn(c)
        small_pool.closeall()


# ---------------------------------------------------------------------------
# Schema management
# ---------------------------------------------------------------------------
def execute_create_table():
    """Create the test table."""
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(f"DROP TABLE IF EXISTS {_TABLE}")
            cur.execute(f"""
                CREATE TABLE {_TABLE} (
                    id SERIAL PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    value INTEGER DEFAULT 0,
                    data JSONB,
                    tags TEXT[],
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
        conn.commit()
        return {"status": "table_created"}
    finally:
        conn.close()


def execute_drop_table():
    """Drop the test table."""
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(f"DROP TABLE IF EXISTS {_TABLE}")
        conn.commit()
        return {"status": "table_dropped"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Insert operations
# ---------------------------------------------------------------------------
def execute_insert():
    """Single row insert."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s) RETURNING id",
                ("test_item", 42),
            )
            row_id = cur.fetchone()[0]
        conn.commit()
        return {"status": "inserted", "id": row_id}
    finally:
        conn.close()


def execute_insert_many():
    """Batch insert using executemany."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            data = [("batch_1", 10), ("batch_2", 20), ("batch_3", 30)]
            cur.executemany(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)", data
            )
        conn.commit()
        return {"status": "inserted_many", "rowcount": 3}
    finally:
        conn.close()


def execute_insert_values():
    """Fast batch insert using execute_values from psycopg2.extras."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            data = [(f"fast_{i}", i * 5) for i in range(5)]
            execute_values(
                cur,
                f"INSERT INTO {_TABLE} (name, value) VALUES %s",
                data,
            )
        conn.commit()
        return {"status": "insert_values_ok", "count": 5}
    finally:
        conn.close()


def execute_insert_returning():
    """Insert with RETURNING clause."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s) RETURNING id, name, created_at",
                ("returning_item", 99),
            )
            row = cur.fetchone()
        conn.commit()
        return {"status": "insert_returning_ok", "id": row[0], "name": row[1]}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Read operations
# ---------------------------------------------------------------------------
def fetch_one():
    """Fetch a single row."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 1")
            row = cur.fetchone()
        return {"status": "fetch_one", "row": row}
    finally:
        conn.close()


def fetch_all():
    """Fetch all rows."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(f"SELECT id, name, value FROM {_TABLE}")
            rows = cur.fetchall()
        return {"status": "fetch_all", "count": len(rows)}
    finally:
        conn.close()


def fetch_many():
    """Fetch a batch of rows."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(f"SELECT id, name, value FROM {_TABLE}")
            batch = cur.fetchmany(2)
        return {"status": "fetch_many", "batch_size": len(batch)}
    finally:
        conn.close()


def fetch_dict_cursor():
    """Fetch rows as dictionaries using RealDictCursor."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 5")
            rows = cur.fetchall()
        return {"status": "dict_cursor", "rows": [dict(r) for r in rows]}
    finally:
        conn.close()


def fetch_named_tuple_cursor():
    """Fetch rows as named tuples."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor(cursor_factory=NamedTupleCursor) as cur:
            cur.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 5")
            rows = cur.fetchall()
        result = [{"id": r.id, "name": r.name, "value": r.value} for r in rows]
        return {"status": "named_tuple_cursor", "rows": result}
    finally:
        conn.close()


def fetch_server_side_cursor():
    """Fetch using a server-side (named) cursor."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor(name="server_cursor") as cur:
            cur.itersize = 2
            cur.execute(f"SELECT id, name, value FROM {_TABLE}")
            rows = cur.fetchall()
        return {"status": "server_side_cursor", "count": len(rows)}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Update operations
# ---------------------------------------------------------------------------
def execute_update():
    """Update rows."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(
                f"UPDATE {_TABLE} SET value = %s WHERE name = %s",
                (99, "test_item"),
            )
        conn.commit()
        return {"status": "updated", "rowcount": cur.rowcount}
    finally:
        conn.close()


def execute_update_returning():
    """Update with RETURNING clause."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s) RETURNING id",
                ("update_ret", 1),
            )
            row_id = cur.fetchone()[0]
            cur.execute(
                f"UPDATE {_TABLE} SET value = %s WHERE id = %s RETURNING id, value",
                (888, row_id),
            )
            updated = cur.fetchone()
        conn.commit()
        return {"status": "update_returning_ok", "id": updated[0], "value": updated[1]}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Delete operations
# ---------------------------------------------------------------------------
def execute_delete():
    """Delete rows."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(f"DELETE FROM {_TABLE} WHERE name = %s", ("test_item",))
        conn.commit()
        return {"status": "deleted", "rowcount": cur.rowcount}
    finally:
        conn.close()


def execute_delete_all():
    """Delete all rows (truncate)."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(f"TRUNCATE {_TABLE} RESTART IDENTITY")
        conn.commit()
        return {"status": "truncated"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Transactions
# ---------------------------------------------------------------------------
def execute_transaction():
    """Explicit transaction with commit and rollback."""
    conn = _get_connection()
    conn.autocommit = False
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
                ("txn_item", 100),
            )
        conn.commit()

        with conn.cursor() as cur:
            cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
                ("txn_rollback", 200),
            )
        conn.rollback()

        with conn.cursor() as cur:
            cur.execute(f"SELECT name FROM {_TABLE} WHERE name LIKE 'txn_%'")
            rows = cur.fetchall()
        return {"status": "transaction_ok", "committed_rows": [r[0] for r in rows]}
    finally:
        conn.close()


def execute_savepoint():
    """Transaction with savepoints."""
    conn = _get_connection()
    conn.autocommit = False
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
                ("sp_item1", 10),
            )
            cur.execute("SAVEPOINT sp1")
            cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
                ("sp_item2", 20),
            )
            cur.execute("ROLLBACK TO SAVEPOINT sp1")
            cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
                ("sp_item3", 30),
            )
        conn.commit()
        with conn.cursor() as cur:
            cur.execute(f"SELECT name FROM {_TABLE} WHERE name LIKE 'sp_%' ORDER BY name")
            rows = cur.fetchall()
        return {"status": "savepoint_ok", "rows": [r[0] for r in rows]}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Data types / serialization (JSONB, arrays)
# ---------------------------------------------------------------------------
def insert_jsonb():
    """Insert and query JSONB data."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        data = {"key1": "val1", "nested": {"deep": True}, "list": [1, 2, 3]}
        with conn.cursor() as cur:
            cur.execute(
                f"INSERT INTO {_TABLE} (name, value, data) VALUES (%s, %s, %s) RETURNING id",
                ("json_item", 1, extras.Json(data)),
            )
            row_id = cur.fetchone()[0]
        conn.commit()
        with conn.cursor() as cur:
            cur.execute(f"SELECT data FROM {_TABLE} WHERE id = %s", (row_id,))
            result = cur.fetchone()[0]
        return {"status": "jsonb_ok", "data": result}
    finally:
        conn.close()


def insert_array():
    """Insert and query array data."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(
                f"INSERT INTO {_TABLE} (name, value, tags) VALUES (%s, %s, %s) RETURNING id",
                ("array_item", 1, ["tag1", "tag2", "tag3"]),
            )
            row_id = cur.fetchone()[0]
        conn.commit()
        with conn.cursor() as cur:
            cur.execute(f"SELECT tags FROM {_TABLE} WHERE id = %s", (row_id,))
            result = cur.fetchone()[0]
        return {"status": "array_ok", "tags": result}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Index management
# ---------------------------------------------------------------------------
def create_index():
    """Create an index on the table."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(f"CREATE INDEX IF NOT EXISTS idx_{_TABLE}_name ON {_TABLE} (name)")
        conn.commit()
        return {"status": "index_created"}
    finally:
        conn.close()


def drop_index():
    """Drop an index."""
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(f"DROP INDEX IF EXISTS idx_{_TABLE}_name")
        conn.commit()
        return {"status": "index_dropped"}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Error scenarios
# ---------------------------------------------------------------------------
def error_query_syntax():
    """Execute a malformed query."""
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELEC * FORM nonexistent")
        return {"status": "unexpected_success"}
    except psycopg2.errors.SyntaxError as e:
        conn.rollback()
        return {"status": "error", "msg": str(e)[:200]}
    finally:
        conn.close()


def error_duplicate_key():
    """Insert a duplicate primary key."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s) RETURNING id",
                ("dup_test", 1),
            )
            row_id = cur.fetchone()[0]
        conn.commit()
        with conn.cursor() as cur:
            cur.execute(
                f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s)",
                (row_id, "dup_test2", 2),
            )
        conn.commit()
        return {"status": "unexpected_success"}
    except psycopg2.errors.UniqueViolation as e:
        conn.rollback()
        return {"status": "error", "msg": str(e)[:200]}
    finally:
        conn.close()


def error_table_not_found():
    """Query a non-existent table."""
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM nonexistent_table_xyz")
        return {"status": "unexpected_success"}
    except psycopg2.errors.UndefinedTable as e:
        conn.rollback()
        return {"status": "error", "msg": str(e)[:200]}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Unique / advanced cases
# ---------------------------------------------------------------------------
def parameterized_query():
    """Parameterized query execution."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(
                f"SELECT id, name FROM {_TABLE} WHERE value > %s", (5,)
            )
            rows = cur.fetchall()
        return {"status": "parameterized_ok", "count": len(rows)}
    finally:
        conn.close()


def mogrify_query():
    """Use mogrify to inspect a query without executing it."""
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            query = cur.mogrify(
                f"SELECT * FROM {_TABLE} WHERE name = %s AND value > %s",
                ("test", 10),
            )
        return {"status": "mogrify_ok", "query": query.decode()}
    finally:
        conn.close()


def connection_status():
    """Check connection status."""
    conn = _get_connection()
    try:
        status = conn.status
        info = conn.info
        return {
            "status": "status_ok",
            "conn_status": status,
            "server_version": info.server_version,
        }
    finally:
        conn.close()


def copy_from_to():
    """Test COPY protocol using copy_expert."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute(f"TRUNCATE {_TABLE}")
            cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES ('copy1', 10), ('copy2', 20)"
            )
        conn.commit()
        import io
        buf = io.StringIO()
        with conn.cursor() as cur:
            cur.copy_expert(f"COPY {_TABLE} (name, value) TO STDOUT WITH CSV", buf)
        csv_data = buf.getvalue()
        return {"status": "copy_ok", "csv_lines": len(csv_data.strip().split("\n"))}
    finally:
        conn.close()


def delayed_insert():
    """Insert after a server-side delay."""
    conn = _get_connection()
    try:
        _ensure_table(conn)
        with conn.cursor() as cur:
            cur.execute("SELECT pg_sleep(1)")
            cur.fetchall()
            cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s) RETURNING id",
                ("delayed_item", 555),
            )
            row_id = cur.fetchone()[0]
        conn.commit()
        return {"status": "delayed_insert_ok", "id": row_id}
    finally:
        conn.close()


def race_condition_test():
    """Simulate a race condition using two connections and FOR UPDATE."""
    conn1 = _get_connection()
    conn2 = _get_connection()
    conn1.autocommit = False
    conn2.autocommit = False
    try:
        _ensure_table(conn1)
        with conn1.cursor() as cur:
            cur.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s) RETURNING id",
                ("race_item", 0),
            )
            row_id = cur.fetchone()[0]
        conn1.commit()

        with conn1.cursor() as cur:
            cur.execute(f"SELECT value FROM {_TABLE} WHERE id = %s FOR UPDATE", (row_id,))
            current = cur.fetchone()[0]
            cur.execute(
                f"UPDATE {_TABLE} SET value = %s WHERE id = %s", (current + 1, row_id)
            )
        conn1.commit()

        with conn2.cursor() as cur:
            cur.execute(f"SELECT value FROM {_TABLE} WHERE id = %s FOR UPDATE", (row_id,))
            current2 = cur.fetchone()[0]
            cur.execute(
                f"UPDATE {_TABLE} SET value = %s WHERE id = %s", (current2 + 1, row_id)
            )
        conn2.commit()

        with conn1.cursor() as cur:
            cur.execute(f"SELECT value FROM {_TABLE} WHERE id = %s", (row_id,))
            final = cur.fetchone()[0]
        return {"status": "race_test_ok", "final_value": final}
    finally:
        conn1.close()
        conn2.close()
