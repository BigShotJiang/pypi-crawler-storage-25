"""
HTTP Component - urllib (stdlib) module
Covers: GET/POST/PUT/DELETE/PATCH, headers, auth, timeouts,
        response types, SSL, redirects, streaming
"""

import json
import ssl
import urllib.error
import urllib.parse
import urllib.request

from apm_component.config import get_http_config
from apm_component.http_urls import (
    GET_URL, GET_PARAMS,
    POST_URL, POST_JSON_BODY, POST_FORM_DATA,
    PUT_URL, PUT_JSON_BODY, DELETE_URL, PATCH_URL, PATCH_JSON_BODY,
    HEADERS_URL, CUSTOM_HEADERS,
    BEARER_AUTH_URL, BEARER_TOKEN, BASIC_AUTH_URL, BASIC_AUTH_USER, BASIC_AUTH_PASS,
    JSON_RESPONSE_URL, TEXT_RESPONSE_URL, BINARY_RESPONSE_URL,
    HTML_RESPONSE_URL, XML_RESPONSE_URL, STREAM_RESPONSE_URL,
    RESPONSE_HEADERS_URL, RESPONSE_HEADERS_PARAMS,
    STATUS_CODE_URL, TIMEOUT_URL, DELAY_URL, CONNECTION_ERROR_URL,
    SSL_VALID_URL, SSL_SELF_SIGNED_URL,
    REDIRECT_URL,
)


def _get_config():
    return get_http_config()


# ---------------------------------------------------------------------------
# Basic HTTP methods
# ---------------------------------------------------------------------------
def http_get():
    cfg = _get_config()
    with urllib.request.urlopen(GET_URL, timeout=cfg["timeout"]) as resp:
        data = json.loads(resp.read().decode())
    return {"status": "success", "status_code": resp.status, "data": data}


def http_get_with_params():
    cfg = _get_config()
    qs = urllib.parse.urlencode(GET_PARAMS)
    url = f"{GET_URL}?{qs}"
    with urllib.request.urlopen(url, timeout=cfg["timeout"]) as resp:
        data = json.loads(resp.read().decode())
    return {"status": "success", "status_code": resp.status, "args": data.get("args")}


def http_post_json():
    cfg = _get_config()
    body = json.dumps(POST_JSON_BODY).encode()
    req = urllib.request.Request(POST_URL, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=cfg["timeout"]) as resp:
        data = json.loads(resp.read().decode())
    return {"status": "success", "status_code": resp.status, "data": data}


def http_post_form():
    cfg = _get_config()
    body = urllib.parse.urlencode(POST_FORM_DATA).encode()
    req = urllib.request.Request(POST_URL, data=body, method="POST")
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    with urllib.request.urlopen(req, timeout=cfg["timeout"]) as resp:
        data = json.loads(resp.read().decode())
    return {"status": "success", "status_code": resp.status, "form": data.get("form")}


def http_put():
    cfg = _get_config()
    body = json.dumps(PUT_JSON_BODY).encode()
    req = urllib.request.Request(PUT_URL, data=body, method="PUT")
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=cfg["timeout"]) as resp:
        data = json.loads(resp.read().decode())
    return {"status": "success", "status_code": resp.status, "data": data}


def http_delete():
    cfg = _get_config()
    req = urllib.request.Request(DELETE_URL, method="DELETE")
    with urllib.request.urlopen(req, timeout=cfg["timeout"]) as resp:
        data = json.loads(resp.read().decode())
    return {"status": "success", "status_code": resp.status, "data": data}


def http_patch():
    cfg = _get_config()
    body = json.dumps(PATCH_JSON_BODY).encode()
    req = urllib.request.Request(PATCH_URL, data=body, method="PATCH")
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=cfg["timeout"]) as resp:
        data = json.loads(resp.read().decode())
    return {"status": "success", "status_code": resp.status, "data": data}


# ---------------------------------------------------------------------------
# Headers & Auth
# ---------------------------------------------------------------------------
def http_custom_headers():
    cfg = _get_config()
    req = urllib.request.Request(HEADERS_URL)
    for key, value in CUSTOM_HEADERS.items():
        req.add_header(key, value)
    with urllib.request.urlopen(req, timeout=cfg["timeout"]) as resp:
        data = json.loads(resp.read().decode())
    return {"status": "success", "status_code": resp.status, "headers": data.get("headers")}


def http_bearer_auth():
    cfg = _get_config()
    req = urllib.request.Request(BEARER_AUTH_URL)
    req.add_header("Authorization", f"Bearer {BEARER_TOKEN}")
    with urllib.request.urlopen(req, timeout=cfg["timeout"]) as resp:
        data = json.loads(resp.read().decode())
    return {"status": "success", "status_code": resp.status, "data": data}


def http_basic_auth():
    cfg = _get_config()
    password_mgr = urllib.request.HTTPPasswordMgrWithDefaultRealm()
    password_mgr.add_password(None, BASIC_AUTH_URL, BASIC_AUTH_USER, BASIC_AUTH_PASS)
    auth_handler = urllib.request.HTTPBasicAuthHandler(password_mgr)
    opener = urllib.request.build_opener(auth_handler)
    with opener.open(BASIC_AUTH_URL, timeout=cfg["timeout"]) as resp:
        data = json.loads(resp.read().decode())
    return {"status": "success", "status_code": resp.status, "data": data}


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------
def http_timeout_error():
    try:
        urllib.request.urlopen(TIMEOUT_URL, timeout=1)
        return {"status": "fail", "error": "expected timeout"}
    except urllib.error.URLError as e:
        return {"status": "error", "msg": str(e.reason)}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def http_connection_error():
    try:
        urllib.request.urlopen(CONNECTION_ERROR_URL, timeout=3)
        return {"status": "fail", "error": "expected connection error"}
    except urllib.error.URLError as e:
        return {"status": "error", "msg": str(e.reason)}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def http_status_error():
    url = f"{STATUS_CODE_URL}/404"
    try:
        urllib.request.urlopen(url)
        return {"status": "fail", "error": "expected HTTPError"}
    except urllib.error.HTTPError as e:
        return {"status": "success", "status_code": e.code, "reason": e.reason}
    except Exception as e:
        return {"status": "fail", "error_type": type(e).__name__, "message": str(e)}


# ---------------------------------------------------------------------------
# Response types
# ---------------------------------------------------------------------------
def http_response_json():
    cfg = _get_config()
    with urllib.request.urlopen(JSON_RESPONSE_URL, timeout=cfg["timeout"]) as resp:
        data = json.loads(resp.read().decode())
    return {"status": "success", "status_code": resp.status, "data": data}


def http_response_text():
    cfg = _get_config()
    with urllib.request.urlopen(TEXT_RESPONSE_URL, timeout=cfg["timeout"]) as resp:
        text = resp.read().decode()
    return {"status": "success", "status_code": resp.status, "length": len(text), "preview": text[:200]}


def http_response_binary():
    cfg = _get_config()
    with urllib.request.urlopen(BINARY_RESPONSE_URL, timeout=cfg["timeout"]) as resp:
        raw = resp.read()
    return {"status": "success", "status_code": resp.status, "size": len(raw), "type": "binary"}


def http_response_stream():
    cfg = _get_config()
    chunks = []
    with urllib.request.urlopen(STREAM_RESPONSE_URL, timeout=cfg["timeout"]) as resp:
        while True:
            chunk = resp.read(1024)
            if not chunk:
                break
            chunks.append(chunk)
    full = b"".join(chunks)
    return {"status": "success", "chunks_read": len(chunks), "total_size": len(full)}


def http_response_html():
    cfg = _get_config()
    with urllib.request.urlopen(HTML_RESPONSE_URL, timeout=cfg["timeout"]) as resp:
        html = resp.read().decode()
    return {"status": "success", "status_code": resp.status, "contains_html": "<html" in html.lower(), "length": len(html)}


def http_response_xml():
    cfg = _get_config()
    with urllib.request.urlopen(XML_RESPONSE_URL, timeout=cfg["timeout"]) as resp:
        xml = resp.read().decode()
    return {"status": "success", "status_code": resp.status, "contains_xml": "<?xml" in xml or "<" in xml, "length": len(xml)}


def http_response_headers():
    cfg = _get_config()
    qs = urllib.parse.urlencode(RESPONSE_HEADERS_PARAMS)
    url = f"{RESPONSE_HEADERS_URL}?{qs}"
    with urllib.request.urlopen(url, timeout=cfg["timeout"]) as resp:
        headers = dict(resp.headers)
    return {"status": "success", "status_code": resp.status, "headers": headers}


# ---------------------------------------------------------------------------
# SSL
# ---------------------------------------------------------------------------
def http_ssl_verify():
    cfg = _get_config()
    with urllib.request.urlopen(SSL_VALID_URL, timeout=cfg["timeout"]) as resp:
        data = json.loads(resp.read().decode())
    return {"status": "success", "status_code": resp.status, "verified": True}


def http_ssl_no_verify():
    cfg = _get_config()
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    with urllib.request.urlopen(SSL_SELF_SIGNED_URL, timeout=cfg["timeout"], context=ctx) as resp:
        content = resp.read().decode()
    return {"status": "success", "status_code": resp.status, "verified": False, "length": len(content)}


# ---------------------------------------------------------------------------
# Redirects & delays
# ---------------------------------------------------------------------------
def http_redirect():
    cfg = _get_config()
    with urllib.request.urlopen(REDIRECT_URL, timeout=cfg["timeout"]) as resp:
        data = resp.read().decode()
        final_url = resp.url
    return {"status": "success", "status_code": resp.status, "final_url": final_url, "redirected": final_url != REDIRECT_URL}


def http_delay_request():
    cfg = _get_config()
    with urllib.request.urlopen(DELAY_URL, timeout=cfg["timeout"]) as resp:
        data = json.loads(resp.read().decode())
    return {"status": "success", "status_code": resp.status, "data": data}


# ---------------------------------------------------------------------------
# Dynamic request
# ---------------------------------------------------------------------------
def http_dynamic_request(method="GET", url=None, **kwargs):
    cfg = _get_config()
    if url is None:
        url = GET_URL

    headers = kwargs.get("headers", {})
    body = kwargs.get("body")
    timeout = kwargs.get("timeout", cfg["timeout"])

    data = None
    if body is not None:
        if isinstance(body, dict):
            data = json.dumps(body).encode()
            headers.setdefault("Content-Type", "application/json")
        elif isinstance(body, str):
            data = body.encode()
        elif isinstance(body, bytes):
            data = body

    req = urllib.request.Request(url, data=data, method=method.upper())
    for key, value in headers.items():
        req.add_header(key, value)

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            try:
                resp_data = json.loads(raw.decode())
            except (json.JSONDecodeError, UnicodeDecodeError):
                resp_data = raw.decode(errors="replace")
        return {"status": "success", "status_code": resp.status, "method": method.upper(), "data": resp_data}
    except urllib.error.HTTPError as e:
        return {"status": "error", "status_code": e.code, "reason": e.reason, "method": method.upper()}
    except urllib.error.URLError as e:
        return {"status": "error", "error_type": "URLError", "message": str(e.reason), "method": method.upper()}


# ---------------------------------------------------------------------------
# Route map
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/http/urllib/http_get": http_get,
    "/http/urllib/http_get_with_params": http_get_with_params,
    "/http/urllib/http_post_json": http_post_json,
    "/http/urllib/http_post_form": http_post_form,
    "/http/urllib/http_put": http_put,
    "/http/urllib/http_delete": http_delete,
    "/http/urllib/http_patch": http_patch,
    "/http/urllib/http_custom_headers": http_custom_headers,
    "/http/urllib/http_bearer_auth": http_bearer_auth,
    "/http/urllib/http_basic_auth": http_basic_auth,
    "/http/urllib/http_timeout_error": http_timeout_error,
    "/http/urllib/http_connection_error": http_connection_error,
    "/http/urllib/http_status_error": http_status_error,
    "/http/urllib/http_response_json": http_response_json,
    "/http/urllib/http_response_text": http_response_text,
    "/http/urllib/http_response_binary": http_response_binary,
    "/http/urllib/http_response_stream": http_response_stream,
    "/http/urllib/http_response_html": http_response_html,
    "/http/urllib/http_response_xml": http_response_xml,
    "/http/urllib/http_response_headers": http_response_headers,
    "/http/urllib/http_ssl_verify": http_ssl_verify,
    "/http/urllib/http_ssl_no_verify": http_ssl_no_verify,
    "/http/urllib/http_redirect": http_redirect,
    "/http/urllib/http_delay_request": http_delay_request,
    "/http/urllib/http_dynamic_request": http_dynamic_request,
}
