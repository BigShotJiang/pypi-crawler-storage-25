"""
Redis Cache Component - redis module (redis-py)
Covers: connection, pool, errors, KV ops, TTL, bulk, counters, data types,
        serialization, key management, pipeline, transactions, pub/sub, Lua, flush
"""

import json
import time
import redis
from apm_component.config import get_redis_config


_PREFIX = "ct_redis:"


def _get_config():
    cfg = get_redis_config()
    return cfg


def _get_client():
    cfg = _get_config()
    return redis.Redis(
        host=cfg["host"],
        port=cfg["port"],
        db=cfg["db"],
        password=cfg["password"],
        socket_timeout=cfg["socket_timeout"],
        decode_responses=True,
    )


def _cleanup(r, pattern=None):
    pat = pattern or f"{_PREFIX}*"
    keys = r.keys(pat)
    if keys:
        r.delete(*keys)


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------
def connect():
    r = _get_client()
    try:
        pong = r.ping()
        return {"status": "connected", "ping": pong}
    finally:
        r.close()


def connect_url():
    cfg = _get_config()
    pwd_part = f":{cfg['password']}@" if cfg["password"] else ""
    url = f"redis://{pwd_part}{cfg['host']}:{cfg['port']}/{cfg['db']}"
    r = redis.from_url(url, decode_responses=True)
    try:
        pong = r.ping()
        return {"status": "connected_url", "ping": pong}
    finally:
        r.close()


# ---------------------------------------------------------------------------
# Connection pooling
# ---------------------------------------------------------------------------
def connect_pool():
    cfg = _get_config()
    pool = redis.ConnectionPool(
        host=cfg["host"],
        port=cfg["port"],
        db=cfg["db"],
        password=cfg["password"],
        max_connections=cfg["pool_size"],
        decode_responses=True,
    )
    r = redis.Redis(connection_pool=pool)
    try:
        pong = r.ping()
        return {"status": "pool_connected", "ping": pong}
    finally:
        r.close()
        pool.disconnect()


def connect_blocking_pool():
    cfg = _get_config()
    pool = redis.BlockingConnectionPool(
        host=cfg["host"],
        port=cfg["port"],
        db=cfg["db"],
        password=cfg["password"],
        max_connections=2,
        timeout=2,
        decode_responses=True,
    )
    r = redis.Redis(connection_pool=pool)
    try:
        pong = r.ping()
        return {"status": "blocking_pool_connected", "ping": pong}
    finally:
        r.close()
        pool.disconnect()


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
def connect_error_wrong_host():
    try:
        r = redis.Redis(host="192.0.2.1", port=6379, socket_timeout=2, socket_connect_timeout=2)
        r.ping()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def connect_error_wrong_port():
    try:
        r = redis.Redis(host="127.0.0.1", port=59999, socket_timeout=2, socket_connect_timeout=2)
        r.ping()
        return {"status": "unexpected_success"}
    except redis.ConnectionError as e:
        return {"status": "error", "msg": str(e)}


def connect_error_wrong_password():
    cfg = _get_config()
    try:
        r = redis.Redis(
            host=cfg["host"],
            port=cfg["port"],
            password="wrong_password_xxx",
            socket_timeout=2,
        )
        r.ping()
        return {"status": "unexpected_success"}
    except (redis.AuthenticationError, redis.ConnectionError) as e:
        return {"status": "error", "msg": str(e)}


def connect_error_timeout():
    try:
        r = redis.Redis(host="192.0.2.1", port=6379, socket_timeout=1, socket_connect_timeout=1)
        r.ping()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def pool_exhaustion_error():
    cfg = _get_config()
    pool = redis.BlockingConnectionPool(
        host=cfg["host"],
        port=cfg["port"],
        db=cfg["db"],
        password=cfg["password"],
        max_connections=1,
        timeout=1,
        decode_responses=True,
    )
    try:
        conn = pool.get_connection("PING")
        r2 = redis.Redis(connection_pool=pool)
        r2.ping()
        return {"status": "unexpected_success"}
    except redis.ConnectionError as e:
        return {"status": "error", "msg": str(e)}
    finally:
        pool.disconnect()


# ---------------------------------------------------------------------------
# Key-Value operations
# ---------------------------------------------------------------------------
def set_get():
    r = _get_client()
    try:
        r.set(f"{_PREFIX}key1", "hello")
        val = r.get(f"{_PREFIX}key1")
        return {"status": "success", "value": val}
    finally:
        _cleanup(r)
        r.close()


def delete_key():
    r = _get_client()
    try:
        r.set(f"{_PREFIX}del_key", "to_delete")
        deleted = r.delete(f"{_PREFIX}del_key")
        val = r.get(f"{_PREFIX}del_key")
        return {"status": "success", "deleted": deleted, "value_after": val}
    finally:
        _cleanup(r)
        r.close()


def setnx():
    r = _get_client()
    try:
        r.delete(f"{_PREFIX}nx_key")
        first = r.setnx(f"{_PREFIX}nx_key", "first")
        second = r.setnx(f"{_PREFIX}nx_key", "second")
        val = r.get(f"{_PREFIX}nx_key")
        return {"status": "success", "first_set": first, "second_set": second, "value": val}
    finally:
        _cleanup(r)
        r.close()


def getset():
    r = _get_client()
    try:
        r.set(f"{_PREFIX}gs_key", "old_value")
        old = r.getset(f"{_PREFIX}gs_key", "new_value")
        current = r.get(f"{_PREFIX}gs_key")
        return {"status": "success", "old": old, "current": current}
    finally:
        _cleanup(r)
        r.close()


def append_value():
    r = _get_client()
    try:
        r.set(f"{_PREFIX}append_key", "hello")
        r.append(f"{_PREFIX}append_key", " world")
        val = r.get(f"{_PREFIX}append_key")
        return {"status": "success", "value": val}
    finally:
        _cleanup(r)
        r.close()


# ---------------------------------------------------------------------------
# Bulk operations
# ---------------------------------------------------------------------------
def mset_mget():
    r = _get_client()
    try:
        data = {f"{_PREFIX}m1": "a", f"{_PREFIX}m2": "b", f"{_PREFIX}m3": "c"}
        r.mset(data)
        vals = r.mget(list(data.keys()))
        return {"status": "success", "values": vals}
    finally:
        _cleanup(r)
        r.close()


# ---------------------------------------------------------------------------
# Counters
# ---------------------------------------------------------------------------
def incr_decr():
    r = _get_client()
    try:
        r.set(f"{_PREFIX}counter", 10)
        r.incr(f"{_PREFIX}counter")
        r.incrby(f"{_PREFIX}counter", 5)
        r.decr(f"{_PREFIX}counter")
        r.decrby(f"{_PREFIX}counter", 3)
        val = int(r.get(f"{_PREFIX}counter"))
        return {"status": "success", "value": val}
    finally:
        _cleanup(r)
        r.close()


# ---------------------------------------------------------------------------
# Expiration / TTL
# ---------------------------------------------------------------------------
def set_with_ttl():
    r = _get_client()
    try:
        r.set(f"{_PREFIX}ttl_key", "expires_soon", ex=10)
        ttl = r.ttl(f"{_PREFIX}ttl_key")
        return {"status": "success", "ttl": ttl}
    finally:
        _cleanup(r)
        r.close()


def expire_and_persist():
    r = _get_client()
    try:
        r.set(f"{_PREFIX}ep_key", "value")
        r.expire(f"{_PREFIX}ep_key", 60)
        ttl_before = r.ttl(f"{_PREFIX}ep_key")
        r.persist(f"{_PREFIX}ep_key")
        ttl_after = r.ttl(f"{_PREFIX}ep_key")
        return {"status": "success", "ttl_before": ttl_before, "ttl_after": ttl_after}
    finally:
        _cleanup(r)
        r.close()


def ttl_expiry_check():
    r = _get_client()
    try:
        r.set(f"{_PREFIX}exp_key", "vanish", ex=1)
        val_before = r.get(f"{_PREFIX}exp_key")
        time.sleep(1.5)
        val_after = r.get(f"{_PREFIX}exp_key")
        return {"status": "success", "before": val_before, "after": val_after}
    finally:
        _cleanup(r)
        r.close()


# ---------------------------------------------------------------------------
# Key existence
# ---------------------------------------------------------------------------
def key_exists():
    r = _get_client()
    try:
        r.set(f"{_PREFIX}ex_key", "yes")
        exists = r.exists(f"{_PREFIX}ex_key")
        r.delete(f"{_PREFIX}ex_key")
        not_exists = r.exists(f"{_PREFIX}ex_key")
        return {"status": "success", "exists": exists, "not_exists": not_exists}
    finally:
        _cleanup(r)
        r.close()


def key_type():
    r = _get_client()
    try:
        r.set(f"{_PREFIX}str_key", "val")
        r.lpush(f"{_PREFIX}list_key", "item")
        str_type = r.type(f"{_PREFIX}str_key")
        list_type = r.type(f"{_PREFIX}list_key")
        return {"status": "success", "string_type": str_type, "list_type": list_type}
    finally:
        _cleanup(r)
        r.close()


def scan_keys():
    r = _get_client()
    try:
        for i in range(5):
            r.set(f"{_PREFIX}scan_{i}", i)
        found = []
        cursor = 0
        while True:
            cursor, keys = r.scan(cursor, match=f"{_PREFIX}scan_*", count=10)
            found.extend(keys)
            if cursor == 0:
                break
        return {"status": "success", "found_count": len(found)}
    finally:
        _cleanup(r)
        r.close()


# ---------------------------------------------------------------------------
# Data types — Hashes
# ---------------------------------------------------------------------------
def hash_operations():
    r = _get_client()
    key = f"{_PREFIX}hash1"
    try:
        r.hset(key, "field1", "val1")
        r.hset(key, mapping={"field2": "val2", "field3": "val3"})
        val = r.hget(key, "field1")
        all_vals = r.hgetall(key)
        exists = r.hexists(key, "field2")
        r.hdel(key, "field3")
        remaining = r.hgetall(key)
        return {
            "status": "success",
            "single": val,
            "all": all_vals,
            "exists": exists,
            "after_del": remaining,
        }
    finally:
        _cleanup(r)
        r.close()


# ---------------------------------------------------------------------------
# Data types — Lists
# ---------------------------------------------------------------------------
def list_operations():
    r = _get_client()
    key = f"{_PREFIX}list1"
    try:
        r.lpush(key, "c", "b", "a")
        r.rpush(key, "d")
        length = r.llen(key)
        items = r.lrange(key, 0, -1)
        left = r.lpop(key)
        right = r.rpop(key)
        return {
            "status": "success",
            "length": length,
            "items": items,
            "lpop": left,
            "rpop": right,
        }
    finally:
        _cleanup(r)
        r.close()


# ---------------------------------------------------------------------------
# Data types — Sets
# ---------------------------------------------------------------------------
def set_operations():
    r = _get_client()
    key = f"{_PREFIX}set1"
    try:
        r.sadd(key, "a", "b", "c", "d")
        members = r.smembers(key)
        is_member = r.sismember(key, "b")
        r.srem(key, "d")
        card = r.scard(key)
        return {
            "status": "success",
            "members": sorted(list(members)),
            "is_member": is_member,
            "cardinality": card,
        }
    finally:
        _cleanup(r)
        r.close()


# ---------------------------------------------------------------------------
# Data types — Sorted Sets
# ---------------------------------------------------------------------------
def sorted_set_operations():
    r = _get_client()
    key = f"{_PREFIX}zset1"
    try:
        r.zadd(key, {"alice": 100, "bob": 200, "carol": 150})
        top = r.zrange(key, 0, -1, withscores=True)
        by_score = r.zrangebyscore(key, 100, 160)
        r.zrem(key, "bob")
        remaining = r.zrange(key, 0, -1)
        return {
            "status": "success",
            "all_with_scores": top,
            "score_range": by_score,
            "after_rem": remaining,
        }
    finally:
        _cleanup(r)
        r.close()


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------
def json_serialization():
    r = _get_client()
    key = f"{_PREFIX}json_key"
    try:
        data = {"name": "test", "values": [1, 2, 3], "nested": {"a": True}}
        r.set(key, json.dumps(data))
        raw = r.get(key)
        parsed = json.loads(raw)
        return {"status": "success", "data": parsed}
    finally:
        _cleanup(r)
        r.close()


# ---------------------------------------------------------------------------
# Flush
# ---------------------------------------------------------------------------
def flush_db():
    r = _get_client()
    try:
        r.set(f"{_PREFIX}flush_1", "a")
        r.set(f"{_PREFIX}flush_2", "b")
        r.flushdb()
        remaining = r.dbsize()
        return {"status": "success", "remaining_keys": remaining}
    finally:
        r.close()


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------
def pipeline_operations():
    r = _get_client()
    try:
        pipe = r.pipeline(transaction=False)
        pipe.set(f"{_PREFIX}pipe1", "a")
        pipe.set(f"{_PREFIX}pipe2", "b")
        pipe.get(f"{_PREFIX}pipe1")
        pipe.get(f"{_PREFIX}pipe2")
        results = pipe.execute()
        return {"status": "success", "results": results}
    finally:
        _cleanup(r)
        r.close()


# ---------------------------------------------------------------------------
# Transaction (MULTI/EXEC)
# ---------------------------------------------------------------------------
def transaction_operations():
    r = _get_client()
    key = f"{_PREFIX}txn_key"
    try:
        r.set(key, "0")

        def incr_txn(pipe):
            val = int(pipe.get(key))
            pipe.multi()
            pipe.set(key, str(val + 1))

        r.transaction(incr_txn, key)
        final = r.get(key)
        return {"status": "success", "value": final}
    finally:
        _cleanup(r)
        r.close()


# ---------------------------------------------------------------------------
# Pub/Sub
# ---------------------------------------------------------------------------
def pubsub_operations():
    r = _get_client()
    channel = f"{_PREFIX}channel"
    try:
        ps = r.pubsub()
        ps.subscribe(channel)
        msg = ps.get_message(timeout=1)

        r.publish(channel, "hello_pubsub")
        received = ps.get_message(timeout=2)

        ps.unsubscribe(channel)
        ps.close()
        data = received["data"] if received else None
        return {"status": "success", "message": data}
    finally:
        r.close()


# ---------------------------------------------------------------------------
# Lua scripting
# ---------------------------------------------------------------------------
def lua_script():
    r = _get_client()
    key = f"{_PREFIX}lua_key"
    try:
        r.set(key, "10")
        script = "local val = redis.call('GET', KEYS[1]); return tonumber(val) * 2"
        result = r.eval(script, 1, key)
        return {"status": "success", "result": result}
    finally:
        _cleanup(r)
        r.close()


# ---------------------------------------------------------------------------
# Dynamic / Delay / Race
# ---------------------------------------------------------------------------
def dynamic_key_ops():
    r = _get_client()
    try:
        keys = {f"{_PREFIX}dyn_{i}": f"val_{i}" for i in range(5)}
        r.mset(keys)
        pattern = f"{_PREFIX}dyn_*"
        found = r.keys(pattern)
        vals = r.mget(found)
        return {"status": "success", "key_count": len(found), "values": vals}
    finally:
        _cleanup(r)
        r.close()


def delayed_operations():
    r = _get_client()
    key = f"{_PREFIX}delay_key"
    try:
        r.set(key, "initial")
        time.sleep(0.5)
        r.set(key, "updated")
        val = r.get(key)
        return {"status": "success", "value": val}
    finally:
        _cleanup(r)
        r.close()


def race_condition_test():
    cfg = _get_config()
    r1 = redis.Redis(host=cfg["host"], port=cfg["port"], db=cfg["db"],
                     password=cfg["password"], decode_responses=True)
    r2 = redis.Redis(host=cfg["host"], port=cfg["port"], db=cfg["db"],
                     password=cfg["password"], decode_responses=True)
    key = f"{_PREFIX}race_key"
    try:
        r1.set(key, "0")
        r1.incr(key)
        r2.incr(key)
        r1.incr(key)
        final = int(r1.get(key))
        return {"status": "success", "final_value": final}
    finally:
        r1.delete(key)
        r1.close()
        r2.close()


# ---------------------------------------------------------------------------
# Global route-to-function mapping
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/cache/redis/redis/connect": connect,
    "/cache/redis/redis/connect_url": connect_url,
    "/cache/redis/redis/connect_pool": connect_pool,
    "/cache/redis/redis/connect_blocking_pool": connect_blocking_pool,
    "/cache/redis/redis/connect_error_wrong_host": connect_error_wrong_host,
    "/cache/redis/redis/connect_error_wrong_port": connect_error_wrong_port,
    "/cache/redis/redis/connect_error_wrong_password": connect_error_wrong_password,
    "/cache/redis/redis/connect_error_timeout": connect_error_timeout,
    "/cache/redis/redis/pool_exhaustion_error": pool_exhaustion_error,
    "/cache/redis/redis/set_get": set_get,
    "/cache/redis/redis/delete_key": delete_key,
    "/cache/redis/redis/setnx": setnx,
    "/cache/redis/redis/getset": getset,
    "/cache/redis/redis/append_value": append_value,
    "/cache/redis/redis/mset_mget": mset_mget,
    "/cache/redis/redis/incr_decr": incr_decr,
    "/cache/redis/redis/set_with_ttl": set_with_ttl,
    "/cache/redis/redis/expire_and_persist": expire_and_persist,
    "/cache/redis/redis/ttl_expiry_check": ttl_expiry_check,
    "/cache/redis/redis/key_exists": key_exists,
    "/cache/redis/redis/key_type": key_type,
    "/cache/redis/redis/scan_keys": scan_keys,
    "/cache/redis/redis/hash_operations": hash_operations,
    "/cache/redis/redis/list_operations": list_operations,
    "/cache/redis/redis/set_operations": set_operations,
    "/cache/redis/redis/sorted_set_operations": sorted_set_operations,
    "/cache/redis/redis/json_serialization": json_serialization,
    "/cache/redis/redis/flush_db": flush_db,
    "/cache/redis/redis/pipeline_operations": pipeline_operations,
    "/cache/redis/redis/transaction_operations": transaction_operations,
    "/cache/redis/redis/pubsub_operations": pubsub_operations,
    "/cache/redis/redis/lua_script": lua_script,
    "/cache/redis/redis/dynamic_key_ops": dynamic_key_ops,
    "/cache/redis/redis/delayed_operations": delayed_operations,
    "/cache/redis/redis/race_condition_test": race_condition_test,
}
