import configparser
import os

_ini_path = os.environ.get(
    "APM_COMPONENT_INI_FILEPATH",
    os.path.join(os.path.dirname(__file__), "components.ini"),
)
_config = configparser.ConfigParser()
_config.read(_ini_path)


def get_mysql_config():
    return {
        "host": os.environ.get("MYSQL_HOST", _config.get("mysql", "host")),
        "port": int(os.environ.get("MYSQL_PORT", _config.getint("mysql", "port"))),
        "user": os.environ.get("MYSQL_USER", _config.get("mysql", "user")),
        "password": os.environ.get("MYSQL_PASSWORD", _config.get("mysql", "password")),
        "database": os.environ.get("MYSQL_DATABASE", _config.get("mysql", "database")),
        "pool_size": _config.getint("mysql", "pool_size"),
        "connect_timeout": _config.getint("mysql", "connect_timeout"),
    }


def get_http_config():
    return {
        "base_url": os.environ.get("HTTP_BASE_URL", _config.get("http", "base_url")),
        "timeout": _config.getint("http", "timeout"),
        "retries": _config.getint("http", "retries"),
        "pool_connections": _config.getint("http", "pool_connections"),
        "pool_maxsize": _config.getint("http", "pool_maxsize"),
    }


def get_sqlite_config():
    return {
        "database": os.environ.get(
            "SQLITE_DATABASE", _config.get("sqlite", "database")
        ),
    }


def get_mssql_config():
    return {
        "host": os.environ.get("MSSQL_HOST", _config.get("mssql", "host")),
        "port": int(os.environ.get("MSSQL_PORT", _config.getint("mssql", "port"))),
        "user": os.environ.get("MSSQL_USER", _config.get("mssql", "user")),
        "password": os.environ.get("MSSQL_PASSWORD", _config.get("mssql", "password")),
        "database": os.environ.get("MSSQL_DATABASE", _config.get("mssql", "database")),
        "pool_size": _config.getint("mssql", "pool_size"),
        "connect_timeout": _config.getint("mssql", "connect_timeout"),
    }


def get_redis_config():
    pwd = os.environ.get("REDIS_PASSWORD", _config.get("redis", "password"))
    return {
        "host": os.environ.get("REDIS_HOST", _config.get("redis", "host")),
        "port": int(os.environ.get("REDIS_PORT", _config.getint("redis", "port"))),
        "db": _config.getint("redis", "db"),
        "password": pwd if pwd else None,
        "pool_size": _config.getint("redis", "pool_size"),
        "socket_timeout": _config.getint("redis", "socket_timeout"),
    }


def get_memcached_config():
    return {
        "host": os.environ.get("MEMCACHED_HOST", _config.get("memcached", "host")),
        "port": int(os.environ.get("MEMCACHED_PORT", _config.getint("memcached", "port"))),
        "connect_timeout": _config.getint("memcached", "connect_timeout"),
        "timeout": _config.getint("memcached", "timeout"),
    }


def get_cassandra_config():
    return {
        "host": os.environ.get("CASSANDRA_HOST", _config.get("cassandra", "host")),
        "port": int(os.environ.get("CASSANDRA_PORT", _config.getint("cassandra", "port"))),
        "keyspace": os.environ.get("CASSANDRA_KEYSPACE", _config.get("cassandra", "keyspace")),
        "connect_timeout": _config.getint("cassandra", "connect_timeout"),
    }


def get_elasticsearch_config():
    return {
        "host": os.environ.get("ELASTICSEARCH_HOST", _config.get("elasticsearch", "host")),
        "port": int(os.environ.get("ELASTICSEARCH_PORT", _config.getint("elasticsearch", "port"))),
        "index": os.environ.get("ELASTICSEARCH_INDEX", _config.get("elasticsearch", "index")),
        "timeout": _config.getint("elasticsearch", "timeout"),
    }


def get_postgresql_config():
    return {
        "host": os.environ.get("POSTGRESQL_HOST", _config.get("postgresql", "host")),
        "port": int(os.environ.get("POSTGRESQL_PORT", _config.getint("postgresql", "port"))),
        "user": os.environ.get("POSTGRESQL_USER", _config.get("postgresql", "user")),
        "password": os.environ.get("POSTGRESQL_PASSWORD", _config.get("postgresql", "password")),
        "database": os.environ.get("POSTGRESQL_DATABASE", _config.get("postgresql", "database")),
        "pool_size": _config.getint("postgresql", "pool_size"),
        "connect_timeout": _config.getint("postgresql", "connect_timeout"),
    }


def get_mongodb_config():
    return {
        "host": os.environ.get("MONGODB_HOST", _config.get("mongodb", "host")),
        "port": int(os.environ.get("MONGODB_PORT", _config.getint("mongodb", "port"))),
        "user": os.environ.get("MONGODB_USER", _config.get("mongodb", "user")),
        "password": os.environ.get("MONGODB_PASSWORD", _config.get("mongodb", "password")),
        "database": os.environ.get("MONGODB_DATABASE", _config.get("mongodb", "database")),
        "collection": os.environ.get("MONGODB_COLLECTION", _config.get("mongodb", "collection")),
        "connect_timeout": _config.getint("mongodb", "connect_timeout"),
    }


def get_oracle_config():
    return {
        "host": os.environ.get("ORACLE_HOST", _config.get("oracle", "host")),
        "port": int(os.environ.get("ORACLE_PORT", _config.getint("oracle", "port"))),
        "user": os.environ.get("ORACLE_USER", _config.get("oracle", "user")),
        "password": os.environ.get("ORACLE_PASSWORD", _config.get("oracle", "password")),
        "service_name": os.environ.get("ORACLE_SERVICE_NAME", _config.get("oracle", "service_name")),
        "pool_size": _config.getint("oracle", "pool_size"),
        "connect_timeout": _config.getint("oracle", "connect_timeout"),
    }


def get_rabbitmq_config():
    return {
        "host": os.environ.get("RABBITMQ_HOST", _config.get("rabbitmq", "host")),
        "port": int(os.environ.get("RABBITMQ_PORT", _config.getint("rabbitmq", "port"))),
        "user": os.environ.get("RABBITMQ_USER", _config.get("rabbitmq", "user")),
        "password": os.environ.get("RABBITMQ_PASSWORD", _config.get("rabbitmq", "password")),
        "vhost": os.environ.get("RABBITMQ_VHOST", _config.get("rabbitmq", "virtual_host")),
        "connect_timeout": _config.getint("rabbitmq", "connect_timeout"),
    }
