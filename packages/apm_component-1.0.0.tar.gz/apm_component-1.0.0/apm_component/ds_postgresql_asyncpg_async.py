"""
PostgreSQL Datastore Component - asyncpg module (async)
Covers: connection, pool, error handling, CRUD, batch, transactions,
        data types, schema management, prepared statements, unique cases
"""

import asyncio
import json
import time
import asyncpg
from apm_component.config import get_postgresql_config


_TABLE = "ct_asyncpg"


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------
def _get_config():
    return get_postgresql_config()


async def _get_connection(**overrides):
    cfg = _get_config()
    params = {
        "host": cfg["host"],
        "port": cfg["port"],
        "user": cfg["user"],
        "password": cfg["password"],
        "database": cfg["database"],
        "timeout": cfg["connect_timeout"],
    }
    params.update(overrides)
    return await asyncpg.connect(**params)


async def _ensure_table(conn):
    await conn.execute(f"""
        CREATE TABLE IF NOT EXISTS {_TABLE} (
            id SERIAL PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            value INTEGER DEFAULT 0,
            data JSONB,
            tags TEXT[],
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)


def _run(coro):
    """Run an async coroutine synchronously."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                return pool.submit(asyncio.run, coro).result()
        return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------
async def _connect():
    conn = await _get_connection()
    try:
        val = await conn.fetchval("SELECT 1")
        return {"status": "connected", "result": val}
    finally:
        await conn.close()


def connect():
    """Basic connection to PostgreSQL via asyncpg."""
    return _run(_connect())


async def _connect_dsn():
    cfg = _get_config()
    dsn = f"postgresql://{cfg['user']}:{cfg['password']}@{cfg['host']}:{cfg['port']}/{cfg['database']}"
    conn = await asyncpg.connect(dsn)
    try:
        ver = await conn.fetchval("SELECT version()")
        return {"status": "connected_dsn", "version": ver[:50]}
    finally:
        await conn.close()


def connect_dsn():
    """Connect using DSN URI string."""
    return _run(_connect_dsn())


# ---------------------------------------------------------------------------
# Connection pooling
# ---------------------------------------------------------------------------
async def _connect_pool():
    cfg = _get_config()
    pool = await asyncpg.create_pool(
        host=cfg["host"],
        port=cfg["port"],
        user=cfg["user"],
        password=cfg["password"],
        database=cfg["database"],
        min_size=1,
        max_size=cfg["pool_size"],
    )
    try:
        async with pool.acquire() as conn:
            val = await conn.fetchval("SELECT 1")
        return {"status": "pool_created", "result": val}
    finally:
        await pool.close()


def connect_pool():
    """Create an async connection pool."""
    return _run(_connect_pool())


async def _get_connection_from_pool():
    cfg = _get_config()
    pool = await asyncpg.create_pool(
        host=cfg["host"],
        port=cfg["port"],
        user=cfg["user"],
        password=cfg["password"],
        database=cfg["database"],
        min_size=1,
        max_size=cfg["pool_size"],
    )
    try:
        async with pool.acquire() as conn:
            val = await conn.fetchval("SELECT 1")
        return {"status": "pool_connection_ok", "result": val}
    finally:
        await pool.close()


def get_connection_from_pool():
    """Acquire a connection from the async pool."""
    return _run(_get_connection_from_pool())


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
async def _connect_error_wrong_password():
    try:
        conn = await _get_connection(password="wrong_password_xyz")
        await conn.close()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_wrong_password():
    """Attempt connection with wrong password."""
    return _run(_connect_error_wrong_password())


async def _connect_error_wrong_host():
    try:
        conn = await asyncpg.connect(host="192.0.2.1", port=5432, user="x", password="x", database="x", timeout=3)
        await conn.close()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_wrong_host():
    """Attempt connection to unreachable host."""
    return _run(_connect_error_wrong_host())


async def _connect_error_unknown_db():
    try:
        conn = await _get_connection(database="nonexistent_db_xyz")
        await conn.close()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_unknown_db():
    """Attempt connection to non-existent database."""
    return _run(_connect_error_unknown_db())


async def _connect_error_timeout():
    try:
        conn = await asyncpg.connect(host="192.0.2.1", port=5432, user="x", password="x", database="x", timeout=1)
        await conn.close()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_timeout():
    """Attempt connection with very short timeout."""
    return _run(_connect_error_timeout())


# ---------------------------------------------------------------------------
# Schema management
# ---------------------------------------------------------------------------
async def _execute_create_table():
    conn = await _get_connection()
    try:
        await conn.execute(f"DROP TABLE IF EXISTS {_TABLE}")
        await conn.execute(f"""
            CREATE TABLE {_TABLE} (
                id SERIAL PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                value INTEGER DEFAULT 0,
                data JSONB,
                tags TEXT[],
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        return {"status": "table_created"}
    finally:
        await conn.close()


def execute_create_table():
    """Create the test table."""
    return _run(_execute_create_table())


async def _execute_drop_table():
    conn = await _get_connection()
    try:
        await conn.execute(f"DROP TABLE IF EXISTS {_TABLE}")
        return {"status": "table_dropped"}
    finally:
        await conn.close()


def execute_drop_table():
    """Drop the test table."""
    return _run(_execute_drop_table())


# ---------------------------------------------------------------------------
# Insert operations
# ---------------------------------------------------------------------------
async def _execute_insert():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        row_id = await conn.fetchval(
            f"INSERT INTO {_TABLE} (name, value) VALUES ($1, $2) RETURNING id",
            "test_item", 42,
        )
        return {"status": "inserted", "id": row_id}
    finally:
        await conn.close()


def execute_insert():
    """Single row insert."""
    return _run(_execute_insert())


async def _execute_insert_many():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        data = [("batch_1", 10), ("batch_2", 20), ("batch_3", 30)]
        await conn.executemany(
            f"INSERT INTO {_TABLE} (name, value) VALUES ($1, $2)", data
        )
        return {"status": "inserted_many", "count": len(data)}
    finally:
        await conn.close()


def execute_insert_many():
    """Batch insert using executemany."""
    return _run(_execute_insert_many())


# ---------------------------------------------------------------------------
# Read operations
# ---------------------------------------------------------------------------
async def _fetch_one():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        row = await conn.fetchrow(f"SELECT id, name, value FROM {_TABLE} LIMIT 1")
        if row:
            return {"status": "fetch_one", "id": row["id"], "name": row["name"]}
        return {"status": "fetch_one", "row": None}
    finally:
        await conn.close()


def fetch_one():
    """Fetch a single row using fetchrow."""
    return _run(_fetch_one())


async def _fetch_all():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        rows = await conn.fetch(f"SELECT id, name, value FROM {_TABLE}")
        return {"status": "fetch_all", "count": len(rows)}
    finally:
        await conn.close()


def fetch_all():
    """Fetch all rows using fetch."""
    return _run(_fetch_all())


async def _fetchval():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        count = await conn.fetchval(f"SELECT COUNT(*) FROM {_TABLE}")
        return {"status": "fetchval", "count": count}
    finally:
        await conn.close()


def fetchval():
    """Fetch a single value using fetchval."""
    return _run(_fetchval())


# ---------------------------------------------------------------------------
# Update operations
# ---------------------------------------------------------------------------
async def _execute_update():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        result = await conn.execute(
            f"UPDATE {_TABLE} SET value = $1 WHERE name = $2", 99, "test_item"
        )
        return {"status": "updated", "result": result}
    finally:
        await conn.close()


def execute_update():
    """Update rows."""
    return _run(_execute_update())


# ---------------------------------------------------------------------------
# Delete operations
# ---------------------------------------------------------------------------
async def _execute_delete():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        result = await conn.execute(
            f"DELETE FROM {_TABLE} WHERE name = $1", "test_item"
        )
        return {"status": "deleted", "result": result}
    finally:
        await conn.close()


def execute_delete():
    """Delete rows."""
    return _run(_execute_delete())


async def _execute_delete_all():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        await conn.execute(f"TRUNCATE {_TABLE} RESTART IDENTITY")
        return {"status": "truncated"}
    finally:
        await conn.close()


def execute_delete_all():
    """Truncate the table."""
    return _run(_execute_delete_all())


# ---------------------------------------------------------------------------
# Transactions
# ---------------------------------------------------------------------------
async def _execute_transaction():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        async with conn.transaction():
            await conn.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES ($1, $2)",
                "txn_item", 100,
            )

        # Rollback case
        try:
            async with conn.transaction():
                await conn.execute(
                    f"INSERT INTO {_TABLE} (name, value) VALUES ($1, $2)",
                    "txn_rollback", 200,
                )
                raise Exception("force rollback")
        except Exception:
            pass

        rows = await conn.fetch(f"SELECT name FROM {_TABLE} WHERE name LIKE 'txn_%'")
        return {"status": "transaction_ok", "committed_rows": [r["name"] for r in rows]}
    finally:
        await conn.close()


def execute_transaction():
    """Transaction with commit and rollback."""
    return _run(_execute_transaction())


async def _execute_savepoint():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        async with conn.transaction():
            await conn.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES ($1, $2)",
                "sp_item1", 10,
            )
            try:
                async with conn.transaction():
                    await conn.execute(
                        f"INSERT INTO {_TABLE} (name, value) VALUES ($1, $2)",
                        "sp_item2", 20,
                    )
                    raise Exception("rollback savepoint")
            except Exception:
                pass
            await conn.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES ($1, $2)",
                "sp_item3", 30,
            )
        rows = await conn.fetch(f"SELECT name FROM {_TABLE} WHERE name LIKE 'sp_%' ORDER BY name")
        return {"status": "savepoint_ok", "rows": [r["name"] for r in rows]}
    finally:
        await conn.close()


def execute_savepoint():
    """Transaction with savepoints (nested transaction blocks)."""
    return _run(_execute_savepoint())


# ---------------------------------------------------------------------------
# Prepared statements
# ---------------------------------------------------------------------------
async def _prepared_insert():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        stmt = await conn.prepare(
            f"INSERT INTO {_TABLE} (name, value) VALUES ($1, $2) RETURNING id"
        )
        row_id = await stmt.fetchval("prepared_item", 55)
        return {"status": "prepared_insert_ok", "id": row_id}
    finally:
        await conn.close()


def prepared_insert():
    """Insert using a prepared statement."""
    return _run(_prepared_insert())


async def _prepared_select():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        await conn.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES ($1, $2)", "prep_sel", 66
        )
        stmt = await conn.prepare(
            f"SELECT id, name, value FROM {_TABLE} WHERE name = $1"
        )
        rows = await stmt.fetch("prep_sel")
        return {"status": "prepared_select_ok", "count": len(rows)}
    finally:
        await conn.close()


def prepared_select():
    """Select using a prepared statement."""
    return _run(_prepared_select())


# ---------------------------------------------------------------------------
# Data types / serialization
# ---------------------------------------------------------------------------
async def _insert_jsonb():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        data = json.dumps({"key1": "val1", "nested": {"deep": True}})
        row_id = await conn.fetchval(
            f"INSERT INTO {_TABLE} (name, data) VALUES ($1, $2::jsonb) RETURNING id",
            "json_item", data,
        )
        result = await conn.fetchval(f"SELECT data FROM {_TABLE} WHERE id = $1", row_id)
        return {"status": "jsonb_ok", "data": json.loads(result)}
    finally:
        await conn.close()


def insert_jsonb():
    """Insert and query JSONB data."""
    return _run(_insert_jsonb())


async def _insert_array():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        row_id = await conn.fetchval(
            f"INSERT INTO {_TABLE} (name, tags) VALUES ($1, $2) RETURNING id",
            "array_item", ["tag1", "tag2", "tag3"],
        )
        result = await conn.fetchval(f"SELECT tags FROM {_TABLE} WHERE id = $1", row_id)
        return {"status": "array_ok", "tags": list(result)}
    finally:
        await conn.close()


def insert_array():
    """Insert and query array data."""
    return _run(_insert_array())


# ---------------------------------------------------------------------------
# Error scenarios
# ---------------------------------------------------------------------------
async def _error_query_syntax():
    conn = await _get_connection()
    try:
        await conn.execute("SELEC * FORM nonexistent")
        return {"status": "unexpected_success"}
    except asyncpg.PostgresSyntaxError as e:
        return {"status": "error", "msg": str(e)[:200]}
    finally:
        await conn.close()


def error_query_syntax():
    """Execute a malformed query."""
    return _run(_error_query_syntax())


async def _error_table_not_found():
    conn = await _get_connection()
    try:
        await conn.execute("SELECT * FROM nonexistent_table_xyz")
        return {"status": "unexpected_success"}
    except asyncpg.UndefinedTableError as e:
        return {"status": "error", "msg": str(e)[:200]}
    finally:
        await conn.close()


def error_table_not_found():
    """Query a non-existent table."""
    return _run(_error_table_not_found())


# ---------------------------------------------------------------------------
# Unique / advanced cases
# ---------------------------------------------------------------------------
async def _delayed_insert():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        await conn.execute("SELECT pg_sleep(1)")
        row_id = await conn.fetchval(
            f"INSERT INTO {_TABLE} (name, value) VALUES ($1, $2) RETURNING id",
            "delayed_item", 555,
        )
        return {"status": "delayed_insert_ok", "id": row_id}
    finally:
        await conn.close()


def delayed_insert():
    """Insert after a server-side delay."""
    return _run(_delayed_insert())


async def _concurrent_queries():
    cfg = _get_config()
    pool = await asyncpg.create_pool(
        host=cfg["host"],
        port=cfg["port"],
        user=cfg["user"],
        password=cfg["password"],
        database=cfg["database"],
        min_size=2,
        max_size=5,
    )
    try:
        async def _query(val):
            async with pool.acquire() as conn:
                await _ensure_table(conn)
                return await conn.fetchval("SELECT $1::int", val)

        results = await asyncio.gather(_query(1), _query(2), _query(3))
        return {"status": "concurrent_ok", "results": list(results)}
    finally:
        await pool.close()


def concurrent_queries():
    """Execute multiple queries concurrently using a pool."""
    return _run(_concurrent_queries())


async def _copy_to():
    conn = await _get_connection()
    try:
        await _ensure_table(conn)
        await conn.execute(f"TRUNCATE {_TABLE}")
        await conn.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES ('copy1', 10), ('copy2', 20)"
        )
        records = await conn.copy_from_query(
            f"SELECT name, value FROM {_TABLE}", output=None
        )
        return {"status": "copy_ok", "bytes": len(records)}
    finally:
        await conn.close()


def copy_to():
    """Test COPY protocol."""
    return _run(_copy_to())
