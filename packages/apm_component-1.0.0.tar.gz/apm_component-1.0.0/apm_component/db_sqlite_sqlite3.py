"""
SQLite Component - sqlite3 module (built-in)
Covers: connection, error handling, execution, fetching, advanced features
"""

import sqlite3
import os
import threading
from apm_component.config import get_sqlite_config


_TABLE = "ct_sqlite3"


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------
def _get_config():
    cfg = get_sqlite_config()
    return cfg["database"]


def _get_connection():
    db_path = _get_config()
    conn = sqlite3.connect(db_path, timeout=10)
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------
def connect():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        result = cursor.fetchone()
        return {"status": "connected", "result": result}
    finally:
        conn.close()


def connect_memory():
    conn = sqlite3.connect(":memory:")
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        result = cursor.fetchone()
        return {"status": "memory_connected", "result": result}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Connection pooling (simulated - reusable connection holder)
# ---------------------------------------------------------------------------
_pool_conn = None
_pool_lock = threading.Lock()


def connect_pool():
    global _pool_conn
    with _pool_lock:
        db_path = _get_config()
        _pool_conn = sqlite3.connect(db_path, check_same_thread=False, timeout=10)
        _pool_conn.execute("PRAGMA journal_mode=WAL")
    return {"status": "pool_created"}


def get_connection_from_pool():
    global _pool_conn
    if _pool_conn is None:
        connect_pool()
    with _pool_lock:
        cursor = _pool_conn.cursor()
        cursor.execute("SELECT 1")
        result = cursor.fetchone()
    return {"status": "pool_connection_ok", "result": result}


def close_pool():
    global _pool_conn
    with _pool_lock:
        if _pool_conn:
            _pool_conn.close()
            _pool_conn = None
    return {"status": "pool_closed"}


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
def connect_error_invalid_path():
    try:
        conn = sqlite3.connect("/nonexistent/path/db.sqlite3")
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE _err_test (id INTEGER)")
        conn.commit()
        conn.close()
        return {"status": "unexpected_success"}
    except sqlite3.OperationalError as e:
        return {"status": "error", "msg": str(e)}


def connect_error_readonly():
    db_path = _get_config()
    conn = sqlite3.connect(db_path)
    conn.execute(f"CREATE TABLE IF NOT EXISTS {_TABLE} (id INTEGER PRIMARY KEY)")
    conn.commit()
    conn.close()

    uri = f"file:{db_path}?mode=ro"
    try:
        conn = sqlite3.connect(uri, uri=True)
        cursor = conn.cursor()
        cursor.execute(f"INSERT INTO {_TABLE} (id) VALUES (99999)")
        conn.commit()
        conn.close()
        return {"status": "unexpected_success"}
    except sqlite3.OperationalError as e:
        return {"status": "error", "msg": str(e)}


def connect_error_corrupt_db():
    corrupt_path = _get_config() + ".corrupt"
    try:
        with open(corrupt_path, "wb") as f:
            f.write(b"this is not a database file at all")
        conn = sqlite3.connect(corrupt_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM sqlite_master")
        cursor.fetchall()
        conn.close()
        return {"status": "unexpected_success"}
    except sqlite3.DatabaseError as e:
        return {"status": "error", "msg": str(e)}
    finally:
        if os.path.exists(corrupt_path):
            os.remove(corrupt_path)


def connect_error_timeout():
    db_path = _get_config()
    conn1 = sqlite3.connect(db_path, timeout=1)
    conn1.execute("PRAGMA journal_mode=DELETE")
    conn1.execute(f"CREATE TABLE IF NOT EXISTS {_TABLE} (id INTEGER PRIMARY KEY, name TEXT, value INTEGER DEFAULT 0)")
    conn1.commit()
    try:
        conn1.execute("BEGIN EXCLUSIVE")
        try:
            conn2 = sqlite3.connect(db_path, timeout=1)
            conn2.execute(f"INSERT INTO {_TABLE} (name, value) VALUES ('timeout_test', 1)")
            conn2.commit()
            conn2.close()
            return {"status": "unexpected_success"}
        except sqlite3.OperationalError as e:
            return {"status": "error", "msg": str(e)}
        finally:
            try:
                conn2.close()
            except Exception:
                pass
    finally:
        conn1.rollback()
        conn1.execute("PRAGMA journal_mode=WAL")
        conn1.close()


# ---------------------------------------------------------------------------
# Query execution
# ---------------------------------------------------------------------------
def execute_create_table():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"DROP TABLE IF EXISTS {_TABLE}")
        cursor.execute(f"""
            CREATE TABLE {_TABLE} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                value INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        return {"status": "table_created"}
    finally:
        conn.close()


def execute_insert():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (?, ?)",
            ("test_item", 42),
        )
        conn.commit()
        return {"status": "inserted", "lastrowid": cursor.lastrowid}
    finally:
        conn.close()


def execute_insert_many():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        data = [("batch_1", 10), ("batch_2", 20), ("batch_3", 30)]
        cursor.executemany(
            f"INSERT INTO {_TABLE} (name, value) VALUES (?, ?)", data
        )
        conn.commit()
        return {"status": "inserted_many", "rowcount": cursor.rowcount}
    finally:
        conn.close()


def execute_update():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"UPDATE {_TABLE} SET value = ? WHERE name = ?",
            (99, "test_item"),
        )
        conn.commit()
        return {"status": "updated", "rowcount": cursor.rowcount}
    finally:
        conn.close()


def execute_delete():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"DELETE FROM {_TABLE} WHERE name = ?", ("test_item",)
        )
        conn.commit()
        return {"status": "deleted", "rowcount": cursor.rowcount}
    finally:
        conn.close()


def execute_select():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 10")
        rows = cursor.fetchall()
        return {"status": "selected", "rows": rows}
    finally:
        conn.close()


def execute_parameterized():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"SELECT id, name FROM {_TABLE} WHERE value > ?", (5,)
        )
        rows = cursor.fetchall()
        return {"status": "parameterized_ok", "rows": rows}
    finally:
        conn.close()


def execute_transaction():
    conn = _get_connection()
    conn.isolation_level = "DEFERRED"
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (?, ?)",
            ("txn_item", 100),
        )
        conn.commit()

        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (?, ?)",
            ("txn_rollback", 200),
        )
        conn.rollback()

        cursor.execute(f"SELECT name FROM {_TABLE} WHERE name LIKE 'txn_%'")
        rows = cursor.fetchall()
        return {"status": "transaction_ok", "committed_rows": rows}
    finally:
        conn.close()


def execute_script():
    conn = _get_connection()
    try:
        conn.executescript(f"""
            INSERT INTO {_TABLE} (name, value) VALUES ('script_1', 1);
            INSERT INTO {_TABLE} (name, value) VALUES ('script_2', 2);
            INSERT INTO {_TABLE} (name, value) VALUES ('script_3', 3);
        """)
        cursor = conn.cursor()
        cursor.execute(f"SELECT COUNT(*) FROM {_TABLE} WHERE name LIKE 'script_%'")
        count = cursor.fetchone()[0]
        return {"status": "script_executed", "inserted_count": count}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Data fetching
# ---------------------------------------------------------------------------
def fetch_one():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 1")
        row = cursor.fetchone()
        return {"status": "fetch_one", "row": row}
    finally:
        conn.close()


def fetch_all():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE}")
        rows = cursor.fetchall()
        return {"status": "fetch_all", "count": len(rows), "rows": rows}
    finally:
        conn.close()


def fetch_many():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE}")
        batch = cursor.fetchmany(2)
        return {"status": "fetch_many", "batch": batch}
    finally:
        conn.close()


def fetch_row_factory():
    conn = _get_connection()
    conn.row_factory = sqlite3.Row
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 5")
        rows = cursor.fetchall()
        result_rows = [dict(r) for r in rows]
        return {"status": "row_factory", "rows": result_rows}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Advanced / unique cases
# ---------------------------------------------------------------------------
def create_user_function():
    conn = _get_connection()
    try:
        conn.create_function("double_val", 1, lambda x: x * 2 if x else 0)
        cursor = conn.cursor()
        cursor.execute(f"SELECT name, double_val(value) FROM {_TABLE} LIMIT 5")
        rows = cursor.fetchall()
        return {"status": "user_function_ok", "rows": rows}
    finally:
        conn.close()


class _SumAggregate:
    def __init__(self):
        self.total = 0

    def step(self, value):
        if value:
            self.total += value

    def finalize(self):
        return self.total


def create_aggregate_function():
    conn = _get_connection()
    try:
        conn.create_aggregate("my_sum", 1, _SumAggregate)
        cursor = conn.cursor()
        cursor.execute(f"SELECT my_sum(value) FROM {_TABLE}")
        result = cursor.fetchone()[0]
        return {"status": "aggregate_function_ok", "total": result}
    finally:
        conn.close()


def iterdump_database():
    conn = _get_connection()
    try:
        lines = list(conn.iterdump())
        return {"status": "iterdump_ok", "line_count": len(lines)}
    finally:
        conn.close()


def backup_database():
    conn = _get_connection()
    backup_path = _get_config() + ".backup"
    try:
        backup_conn = sqlite3.connect(backup_path)
        conn.backup(backup_conn)
        backup_conn.close()
        return {"status": "backup_ok", "backup_path": backup_path}
    finally:
        conn.close()
        if os.path.exists(backup_path):
            os.remove(backup_path)


def dynamic_query(table_name=_TABLE, columns=None, where_clause=None):
    conn = _get_connection()
    try:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cols = ", ".join(columns) if columns else "*"
        query = f"SELECT {cols} FROM `{table_name}`"
        params = ()
        if where_clause:
            query += " WHERE " + where_clause["condition"]
            params = tuple(where_clause.get("params", ()))
        cursor.execute(query, params)
        rows = [dict(r) for r in cursor.fetchall()]
        return {"status": "dynamic_query_ok", "rows": rows}
    finally:
        conn.close()


def delayed_insert():
    import time
    conn = _get_connection()
    try:
        time.sleep(1)
        cursor = conn.cursor()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (?, ?)",
            ("delayed_item", 555),
        )
        conn.commit()
        return {"status": "delayed_insert_ok", "lastrowid": cursor.lastrowid}
    finally:
        conn.close()


def race_condition_test():
    conn1 = _get_connection()
    conn2 = _get_connection()
    try:
        cur1 = conn1.cursor()
        cur1.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (?, ?)",
            ("race_item", 0),
        )
        conn1.commit()

        cur1.execute(f"SELECT value FROM {_TABLE} WHERE name = 'race_item'")
        current = cur1.fetchone()[0]
        cur1.execute(
            f"UPDATE {_TABLE} SET value = ? WHERE name = 'race_item'",
            (current + 1,),
        )
        conn1.commit()

        cur2 = conn2.cursor()
        cur2.execute(f"SELECT value FROM {_TABLE} WHERE name = 'race_item'")
        current2 = cur2.fetchone()[0]
        cur2.execute(
            f"UPDATE {_TABLE} SET value = ? WHERE name = 'race_item'",
            (current2 + 1,),
        )
        conn2.commit()

        cur1.execute(f"SELECT value FROM {_TABLE} WHERE name = 'race_item'")
        final = cur1.fetchone()[0]
        return {"status": "race_test_ok", "final_value": final}
    finally:
        conn1.close()
        conn2.close()


# ---------------------------------------------------------------------------
# Global route-to-function mapping
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/db/sqlite/sqlite3/connect": connect,
    "/db/sqlite/sqlite3/connect_memory": connect_memory,
    "/db/sqlite/sqlite3/connect_pool": connect_pool,
    "/db/sqlite/sqlite3/get_connection_from_pool": get_connection_from_pool,
    "/db/sqlite/sqlite3/close_pool": close_pool,
    "/db/sqlite/sqlite3/connect_error_invalid_path": connect_error_invalid_path,
    "/db/sqlite/sqlite3/connect_error_readonly": connect_error_readonly,
    "/db/sqlite/sqlite3/connect_error_corrupt_db": connect_error_corrupt_db,
    "/db/sqlite/sqlite3/connect_error_timeout": connect_error_timeout,
    "/db/sqlite/sqlite3/execute_create_table": execute_create_table,
    "/db/sqlite/sqlite3/execute_insert": execute_insert,
    "/db/sqlite/sqlite3/execute_insert_many": execute_insert_many,
    "/db/sqlite/sqlite3/execute_update": execute_update,
    "/db/sqlite/sqlite3/execute_delete": execute_delete,
    "/db/sqlite/sqlite3/execute_select": execute_select,
    "/db/sqlite/sqlite3/execute_parameterized": execute_parameterized,
    "/db/sqlite/sqlite3/execute_transaction": execute_transaction,
    "/db/sqlite/sqlite3/execute_script": execute_script,
    "/db/sqlite/sqlite3/fetch_one": fetch_one,
    "/db/sqlite/sqlite3/fetch_all": fetch_all,
    "/db/sqlite/sqlite3/fetch_many": fetch_many,
    "/db/sqlite/sqlite3/fetch_row_factory": fetch_row_factory,
    "/db/sqlite/sqlite3/create_user_function": create_user_function,
    "/db/sqlite/sqlite3/create_aggregate_function": create_aggregate_function,
    "/db/sqlite/sqlite3/iterdump_database": iterdump_database,
    "/db/sqlite/sqlite3/backup_database": backup_database,
    "/db/sqlite/sqlite3/dynamic_query": dynamic_query,
    "/db/sqlite/sqlite3/delayed_insert": delayed_insert,
    "/db/sqlite/sqlite3/race_condition_test": race_condition_test,
}
