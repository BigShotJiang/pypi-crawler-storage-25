"""
Memcache Cache Component - python-memcached module (memcache)
Covers: connection, errors, KV ops, TTL, bulk, counters, CAS,
        serialization, flush, stats, disconnect
"""

import json
import time
import memcache
from apm_component.config import get_memcached_config


_PREFIX = "ct_pymcd_"


def _get_config():
    return get_memcached_config()


def _get_client():
    cfg = _get_config()
    return memcache.Client(
        [f"{cfg['host']}:{cfg['port']}"],
        socket_timeout=cfg["timeout"],
    )


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------
def connect():
    client = _get_client()
    try:
        stats = client.get_stats()
        if stats:
            pid = stats[0][1].get("pid", "")
            return {"status": "connected", "pid": pid}
        return {"status": "error", "msg": "no stats returned"}
    finally:
        client.disconnect_all()


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
def connect_error_wrong_host():
    try:
        client = memcache.Client(["192.0.2.1:11211"], socket_timeout=2)
        client.set("test", "val")
        val = client.get("test")
        if val is None:
            return {"status": "error", "msg": "connection failed silently"}
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def connect_error_wrong_port():
    try:
        client = memcache.Client(["127.0.0.1:59999"], socket_timeout=2)
        client.set("test", "val")
        val = client.get("test")
        if val is None:
            return {"status": "error", "msg": "connection failed silently"}
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def connect_error_timeout():
    try:
        client = memcache.Client(["192.0.2.1:11211"], socket_timeout=1)
        client.set("test", "val")
        val = client.get("test")
        if val is None:
            return {"status": "error", "msg": "connection timed out silently"}
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


# ---------------------------------------------------------------------------
# Key-Value operations
# ---------------------------------------------------------------------------
def set_get():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}key1", "hello")
        val = client.get(f"{_PREFIX}key1")
        return {"status": "success", "value": val}
    finally:
        client.delete(f"{_PREFIX}key1")
        client.disconnect_all()


def delete_key():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}del_key", "to_delete")
        deleted = client.delete(f"{_PREFIX}del_key")
        val = client.get(f"{_PREFIX}del_key")
        return {"status": "success", "deleted": deleted, "value_after": val}
    finally:
        client.disconnect_all()


def add_key():
    client = _get_client()
    try:
        client.delete(f"{_PREFIX}add_key")
        first = client.add(f"{_PREFIX}add_key", "first")
        second = client.add(f"{_PREFIX}add_key", "second")
        val = client.get(f"{_PREFIX}add_key")
        return {"status": "success", "first_add": bool(first), "second_add": bool(second), "value": val}
    finally:
        client.delete(f"{_PREFIX}add_key")
        client.disconnect_all()


def replace_key():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}rep_key", "original")
        replaced = client.replace(f"{_PREFIX}rep_key", "replaced")
        val = client.get(f"{_PREFIX}rep_key")
        return {"status": "success", "replaced": bool(replaced), "value": val}
    finally:
        client.delete(f"{_PREFIX}rep_key")
        client.disconnect_all()


def append_prepend():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}ap_key", "hello")
        client.append(f"{_PREFIX}ap_key", " world")
        client.prepend(f"{_PREFIX}ap_key", "say: ")
        val = client.get(f"{_PREFIX}ap_key")
        return {"status": "success", "value": val}
    finally:
        client.delete(f"{_PREFIX}ap_key")
        client.disconnect_all()


# ---------------------------------------------------------------------------
# Bulk operations
# ---------------------------------------------------------------------------
def set_multi_get_multi():
    client = _get_client()
    try:
        data = {
            f"{_PREFIX}bulk_1": "a",
            f"{_PREFIX}bulk_2": "b",
            f"{_PREFIX}bulk_3": "c",
        }
        failed = client.set_multi(data)
        keys = list(data.keys())
        vals = client.get_multi(keys)
        return {"status": "success", "failed_keys": failed, "values": vals}
    finally:
        client.delete_multi(list(data.keys()))
        client.disconnect_all()


def delete_multi():
    client = _get_client()
    try:
        data = {f"{_PREFIX}dm_1": "x", f"{_PREFIX}dm_2": "y"}
        client.set_multi(data)
        keys = list(data.keys())
        deleted = client.delete_multi(keys)
        remaining = client.get_multi(keys)
        return {"status": "success", "deleted": deleted, "remaining_count": len(remaining)}
    finally:
        client.disconnect_all()


# ---------------------------------------------------------------------------
# Counters
# ---------------------------------------------------------------------------
def incr_decr():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}counter", 10)
        val1 = client.incr(f"{_PREFIX}counter", 5)
        val2 = client.decr(f"{_PREFIX}counter", 3)
        return {"status": "success", "after_incr": val1, "after_decr": val2}
    finally:
        client.delete(f"{_PREFIX}counter")
        client.disconnect_all()


# ---------------------------------------------------------------------------
# Expiration / TTL
# ---------------------------------------------------------------------------
def set_with_ttl():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}ttl_key", "expires_soon", time=2)
        val_before = client.get(f"{_PREFIX}ttl_key")
        time.sleep(2.5)
        val_after = client.get(f"{_PREFIX}ttl_key")
        return {"status": "success", "before": val_before, "after": val_after}
    finally:
        client.delete(f"{_PREFIX}ttl_key")
        client.disconnect_all()


# ---------------------------------------------------------------------------
# Key existence
# ---------------------------------------------------------------------------
def key_exists():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}ex_key", "yes")
        exists = client.get(f"{_PREFIX}ex_key") is not None
        client.delete(f"{_PREFIX}ex_key")
        not_exists = client.get(f"{_PREFIX}ex_key") is not None
        return {"status": "success", "exists": exists, "not_exists": not_exists}
    finally:
        client.disconnect_all()


# ---------------------------------------------------------------------------
# CAS
# ---------------------------------------------------------------------------
def cas_operations():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}cas_key", "original")
        val = client.gets(f"{_PREFIX}cas_key")
        success = client.cas(f"{_PREFIX}cas_key", "updated")
        final = client.get(f"{_PREFIX}cas_key")
        return {
            "status": "success",
            "original": val,
            "cas_success": bool(success),
            "final": final,
        }
    finally:
        client.delete(f"{_PREFIX}cas_key")
        client.disconnect_all()


# ---------------------------------------------------------------------------
# Serialization (automatic pickle for complex types)
# ---------------------------------------------------------------------------
def json_serialization():
    client = _get_client()
    try:
        data = {"name": "test", "values": [1, 2, 3], "nested": {"a": True}}
        client.set(f"{_PREFIX}json_key", json.dumps(data))
        raw = client.get(f"{_PREFIX}json_key")
        parsed = json.loads(raw)
        return {"status": "success", "data": parsed}
    finally:
        client.delete(f"{_PREFIX}json_key")
        client.disconnect_all()


def pickle_serialization():
    client = _get_client()
    try:
        data = {"complex": [1, 2.5, True, None]}
        client.set(f"{_PREFIX}pickle_key", data)
        val = client.get(f"{_PREFIX}pickle_key")
        return {"status": "success", "data": val}
    finally:
        client.delete(f"{_PREFIX}pickle_key")
        client.disconnect_all()


# ---------------------------------------------------------------------------
# Flush
# ---------------------------------------------------------------------------
def flush_all():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}flush_1", "a")
        client.set(f"{_PREFIX}flush_2", "b")
        client.flush_all()
        val = client.get(f"{_PREFIX}flush_1")
        return {"status": "success", "after_flush": val}
    finally:
        client.disconnect_all()


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------
def get_stats():
    client = _get_client()
    try:
        stats = client.get_stats()
        if stats:
            s = stats[0][1]
            return {
                "status": "success",
                "pid": s.get("pid", ""),
                "curr_items": int(s.get("curr_items", 0)),
            }
        return {"status": "error", "msg": "no stats"}
    finally:
        client.disconnect_all()


# ---------------------------------------------------------------------------
# Disconnect
# ---------------------------------------------------------------------------
def disconnect_all():
    client = _get_client()
    client.set(f"{_PREFIX}disc_key", "val")
    client.disconnect_all()
    return {"status": "success", "disconnected": True}


# ---------------------------------------------------------------------------
# Dynamic / Delay / Race
# ---------------------------------------------------------------------------
def dynamic_key_ops():
    client = _get_client()
    try:
        data = {f"{_PREFIX}dyn_{i}": f"val_{i}" for i in range(5)}
        client.set_multi(data)
        vals = client.get_multi(list(data.keys()))
        return {"status": "success", "key_count": len(vals), "values": vals}
    finally:
        client.delete_multi(list(data.keys()))
        client.disconnect_all()


def delayed_operations():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}delay_key", "initial")
        time.sleep(0.5)
        client.set(f"{_PREFIX}delay_key", "updated")
        val = client.get(f"{_PREFIX}delay_key")
        return {"status": "success", "value": val}
    finally:
        client.delete(f"{_PREFIX}delay_key")
        client.disconnect_all()


def race_condition_test():
    cfg = _get_config()
    server = f"{cfg['host']}:{cfg['port']}"
    c1 = memcache.Client([server], socket_timeout=cfg["timeout"])
    c2 = memcache.Client([server], socket_timeout=cfg["timeout"])
    key = f"{_PREFIX}race_key"
    try:
        c1.set(key, 0)
        c1.incr(key, 1)
        c2.incr(key, 1)
        c1.incr(key, 1)
        val = c1.get(key)
        return {"status": "success", "final_value": val}
    finally:
        c1.delete(key)
        c1.disconnect_all()
        c2.disconnect_all()


# ---------------------------------------------------------------------------
# Global route-to-function mapping
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/cache/memcache/python_memcached/connect": connect,
    "/cache/memcache/python_memcached/connect_error_wrong_host": connect_error_wrong_host,
    "/cache/memcache/python_memcached/connect_error_wrong_port": connect_error_wrong_port,
    "/cache/memcache/python_memcached/connect_error_timeout": connect_error_timeout,
    "/cache/memcache/python_memcached/set_get": set_get,
    "/cache/memcache/python_memcached/delete_key": delete_key,
    "/cache/memcache/python_memcached/add_key": add_key,
    "/cache/memcache/python_memcached/replace_key": replace_key,
    "/cache/memcache/python_memcached/append_prepend": append_prepend,
    "/cache/memcache/python_memcached/set_multi_get_multi": set_multi_get_multi,
    "/cache/memcache/python_memcached/delete_multi": delete_multi,
    "/cache/memcache/python_memcached/incr_decr": incr_decr,
    "/cache/memcache/python_memcached/set_with_ttl": set_with_ttl,
    "/cache/memcache/python_memcached/key_exists": key_exists,
    "/cache/memcache/python_memcached/cas_operations": cas_operations,
    "/cache/memcache/python_memcached/json_serialization": json_serialization,
    "/cache/memcache/python_memcached/pickle_serialization": pickle_serialization,
    "/cache/memcache/python_memcached/flush_all": flush_all,
    "/cache/memcache/python_memcached/get_stats": get_stats,
    "/cache/memcache/python_memcached/disconnect_all": disconnect_all,
    "/cache/memcache/python_memcached/dynamic_key_ops": dynamic_key_ops,
    "/cache/memcache/python_memcached/delayed_operations": delayed_operations,
    "/cache/memcache/python_memcached/race_condition_test": race_condition_test,
}
