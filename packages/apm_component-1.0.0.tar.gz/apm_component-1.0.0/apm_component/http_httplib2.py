"""
HTTP Component - httplib2 module
Covers: GET/POST/PUT/DELETE/PATCH, headers, auth, connection reuse, caching,
        timeouts, errors, response types, SSL, redirects
"""

import json
import socket
from urllib.parse import urlencode

import httplib2

from apm_component.config import get_http_config
from apm_component.http_urls import (
    GET_URL, GET_PARAMS,
    POST_URL, POST_JSON_BODY, POST_FORM_DATA,
    PUT_URL, PUT_JSON_BODY, DELETE_URL, PATCH_URL, PATCH_JSON_BODY,
    HEADERS_URL, CUSTOM_HEADERS,
    BEARER_AUTH_URL, BEARER_TOKEN, BASIC_AUTH_URL, BASIC_AUTH_USER, BASIC_AUTH_PASS,
    JSON_RESPONSE_URL, TEXT_RESPONSE_URL, BINARY_RESPONSE_URL,
    HTML_RESPONSE_URL, XML_RESPONSE_URL,
    RESPONSE_HEADERS_URL, RESPONSE_HEADERS_PARAMS,
    STATUS_CODE_URL, TIMEOUT_URL, DELAY_URL, CONNECTION_ERROR_URL,
    SSL_VALID_URL, SSL_SELF_SIGNED_URL,
    REDIRECT_URL,
)


def _get_config():
    return get_http_config()


# ---------------------------------------------------------------------------
# Basic HTTP methods
# ---------------------------------------------------------------------------
def http_get():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    response, content = h.request(GET_URL, "GET")
    return {"status": "success", "status_code": response.status, "data": json.loads(content.decode())}


def http_get_with_params():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    url = f"{GET_URL}?{urlencode(GET_PARAMS)}"
    response, content = h.request(url, "GET")
    data = json.loads(content.decode())
    return {"status": "success", "status_code": response.status, "args": data.get("args")}


def http_post_json():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    headers = {"Content-Type": "application/json"}
    response, content = h.request(POST_URL, "POST", body=json.dumps(POST_JSON_BODY), headers=headers)
    return {"status": "success", "status_code": response.status, "data": json.loads(content.decode())}


def http_post_form():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    response, content = h.request(POST_URL, "POST", body=urlencode(POST_FORM_DATA), headers=headers)
    data = json.loads(content.decode())
    return {"status": "success", "status_code": response.status, "form": data.get("form")}


def http_put():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    headers = {"Content-Type": "application/json"}
    response, content = h.request(PUT_URL, "PUT", body=json.dumps(PUT_JSON_BODY), headers=headers)
    return {"status": "success", "status_code": response.status, "data": json.loads(content.decode())}


def http_delete():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    response, content = h.request(DELETE_URL, "DELETE")
    return {"status": "success", "status_code": response.status, "data": json.loads(content.decode())}


def http_patch():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    headers = {"Content-Type": "application/json"}
    response, content = h.request(PATCH_URL, "PATCH", body=json.dumps(PATCH_JSON_BODY), headers=headers)
    return {"status": "success", "status_code": response.status, "data": json.loads(content.decode())}


# ---------------------------------------------------------------------------
# Headers & Auth
# ---------------------------------------------------------------------------
def http_custom_headers():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    response, content = h.request(HEADERS_URL, "GET", headers=CUSTOM_HEADERS)
    echoed = json.loads(content.decode()).get("headers", {})
    return {"status": "success", "status_code": response.status, "echoed_headers": echoed}


def http_bearer_auth():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    headers = {"Authorization": f"Bearer {BEARER_TOKEN}"}
    response, content = h.request(BEARER_AUTH_URL, "GET", headers=headers)
    return {"status": "success", "status_code": response.status, "data": json.loads(content.decode())}


def http_basic_auth():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    h.add_credentials(BASIC_AUTH_USER, BASIC_AUTH_PASS)
    response, content = h.request(BASIC_AUTH_URL, "GET")
    return {"status": "success", "status_code": response.status, "data": json.loads(content.decode())}


# ---------------------------------------------------------------------------
# Connection reuse
# ---------------------------------------------------------------------------
def http_connection_reuse():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    r1, c1 = h.request(GET_URL, "GET")
    headers = {"Content-Type": "application/json"}
    r2, c2 = h.request(POST_URL, "POST", body=json.dumps(POST_JSON_BODY), headers=headers)
    return {
        "status": "success",
        "get_status": r1.status,
        "post_status": r2.status,
    }


# ---------------------------------------------------------------------------
# Error scenarios
# ---------------------------------------------------------------------------
def http_timeout_error():
    try:
        h = httplib2.Http(timeout=1)
        h.request(TIMEOUT_URL, "GET")
        return {"status": "no_timeout"}
    except (httplib2.ServerNotFoundError, socket.timeout) as e:
        return {"status": "error", "msg": str(e)}


def http_connection_error():
    try:
        h = httplib2.Http(timeout=3)
        h.request(CONNECTION_ERROR_URL, "GET")
        return {"status": "no_error"}
    except (httplib2.ServerNotFoundError, httplib2.HttpLib2Error, OSError) as e:
        return {"status": "error", "msg": str(e)}


def http_status_error():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    response, content = h.request(f"{STATUS_CODE_URL}/404", "GET")
    return {"status": "success", "status_code": response.status, "is_client_error": response.status == 404}


# ---------------------------------------------------------------------------
# Response types
# ---------------------------------------------------------------------------
def http_response_json():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    response, content = h.request(JSON_RESPONSE_URL, "GET")
    return {"status": "success", "json": json.loads(content.decode())}


def http_response_text():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    response, content = h.request(TEXT_RESPONSE_URL, "GET")
    return {"status": "success", "text": content.decode()[:200]}


def http_response_binary():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    response, content = h.request(BINARY_RESPONSE_URL, "GET")
    return {"status": "success", "content_length": len(content)}


def http_response_html():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    response, content = h.request(HTML_RESPONSE_URL, "GET")
    return {"status": "success", "html": content.decode()[:200]}


def http_response_xml():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    response, content = h.request(XML_RESPONSE_URL, "GET")
    return {"status": "success", "xml": content.decode()[:200]}


def http_response_headers():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    url = f"{RESPONSE_HEADERS_URL}?{urlencode(RESPONSE_HEADERS_PARAMS)}"
    response, content = h.request(url, "GET")
    return {"status": "success", "headers": dict(response)}


# ---------------------------------------------------------------------------
# SSL
# ---------------------------------------------------------------------------
def http_ssl_verify():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    response, content = h.request(SSL_VALID_URL, "GET")
    return {"status": "success", "status_code": response.status}


def http_ssl_no_verify():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"], disable_ssl_certificate_validation=True)
    response, content = h.request(SSL_SELF_SIGNED_URL, "GET")
    return {"status": "success", "status_code": response.status}


# ---------------------------------------------------------------------------
# Redirects & Caching
# ---------------------------------------------------------------------------
def http_redirect():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    response, content = h.request(REDIRECT_URL, "GET")
    return {
        "status": "success",
        "status_code": response.status,
        "final_url": response.get("content-location", ""),
    }


def http_caching():
    cfg = _get_config()
    h = httplib2.Http(cache=".cache", timeout=cfg["timeout"])
    r1, c1 = h.request(GET_URL, "GET")
    r2, c2 = h.request(GET_URL, "GET")
    return {
        "status": "success",
        "first_from_cache": getattr(r1, "fromcache", False),
        "second_from_cache": getattr(r2, "fromcache", False),
    }


# ---------------------------------------------------------------------------
# Delay & Dynamic
# ---------------------------------------------------------------------------
def http_delay_request():
    cfg = _get_config()
    h = httplib2.Http(timeout=cfg["timeout"])
    response, content = h.request(DELAY_URL, "GET")
    return {"status": "success", "status_code": response.status, "data": json.loads(content.decode())}


def http_dynamic_request(method="GET", url=None, **kwargs):
    cfg = _get_config()
    if url is None:
        url = GET_URL
    h = httplib2.Http(timeout=kwargs.pop("timeout", cfg["timeout"]))
    body = kwargs.pop("body", None)
    headers = kwargs.pop("headers", None)
    response, content = h.request(url, method, body=body, headers=headers)
    return {"status": "success", "method": method, "status_code": response.status}


# ---------------------------------------------------------------------------
# ROUTE_MAP
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/http/httplib2/http_get": http_get,
    "/http/httplib2/http_get_with_params": http_get_with_params,
    "/http/httplib2/http_post_json": http_post_json,
    "/http/httplib2/http_post_form": http_post_form,
    "/http/httplib2/http_put": http_put,
    "/http/httplib2/http_delete": http_delete,
    "/http/httplib2/http_patch": http_patch,
    "/http/httplib2/http_custom_headers": http_custom_headers,
    "/http/httplib2/http_bearer_auth": http_bearer_auth,
    "/http/httplib2/http_basic_auth": http_basic_auth,
    "/http/httplib2/http_connection_reuse": http_connection_reuse,
    "/http/httplib2/http_timeout_error": http_timeout_error,
    "/http/httplib2/http_connection_error": http_connection_error,
    "/http/httplib2/http_status_error": http_status_error,
    "/http/httplib2/http_response_json": http_response_json,
    "/http/httplib2/http_response_text": http_response_text,
    "/http/httplib2/http_response_binary": http_response_binary,
    "/http/httplib2/http_response_html": http_response_html,
    "/http/httplib2/http_response_xml": http_response_xml,
    "/http/httplib2/http_response_headers": http_response_headers,
    "/http/httplib2/http_ssl_verify": http_ssl_verify,
    "/http/httplib2/http_ssl_no_verify": http_ssl_no_verify,
    "/http/httplib2/http_redirect": http_redirect,
    "/http/httplib2/http_caching": http_caching,
    "/http/httplib2/http_delay_request": http_delay_request,
    "/http/httplib2/http_dynamic_request": http_dynamic_request,
}
