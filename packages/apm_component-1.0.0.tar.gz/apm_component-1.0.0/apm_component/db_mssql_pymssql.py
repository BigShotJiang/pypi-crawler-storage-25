"""
MSSQL Component - pymssql module
Covers: connection, pool (via DBUtils), error handling, execution, fetching, advanced features
"""

import pymssql
from apm_component.config import get_mssql_config


_TABLE = "ct_pymssql"


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------
def _get_config():
    cfg = get_mssql_config()
    return {
        "server": cfg["host"],
        "port": str(cfg["port"]),
        "user": cfg["user"],
        "password": cfg["password"],
        "database": cfg["database"],
        "login_timeout": cfg["connect_timeout"],
    }


def _get_connection(as_dict=False):
    cfg = _get_config()
    return pymssql.connect(
        server=cfg["server"],
        port=cfg["port"],
        user=cfg["user"],
        password=cfg["password"],
        database=cfg["database"],
        login_timeout=cfg["login_timeout"],
        as_dict=as_dict,
    )


def _ensure_database():
    cfg = _get_config()
    conn = pymssql.connect(
        server=cfg["server"],
        port=cfg["port"],
        user=cfg["user"],
        password=cfg["password"],
        login_timeout=cfg["login_timeout"],
        autocommit=True,
    )
    try:
        cursor = conn.cursor()
        cursor.execute(
            "IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = %s) "
            "CREATE DATABASE component_test_db",
            (cfg["database"],),
        )
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------
def connect():
    _ensure_database()
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        result = cursor.fetchone()
        return {"status": "connected", "result": result}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Connection pooling (via DBUtils)
# ---------------------------------------------------------------------------
_pool = None


def connect_pool():
    global _pool
    from dbutils.pooled_db import PooledDB

    _ensure_database()
    cfg = _get_config()
    _pool = PooledDB(
        creator=pymssql,
        maxconnections=get_mssql_config()["pool_size"],
        mincached=1,
        maxcached=3,
        blocking=True,
        server=cfg["server"],
        port=cfg["port"],
        user=cfg["user"],
        password=cfg["password"],
        database=cfg["database"],
        login_timeout=cfg["login_timeout"],
    )
    return {"status": "pool_created"}


def get_connection_from_pool():
    if _pool is None:
        connect_pool()
    conn = _pool.connection() # pyright: ignore[reportOptionalMemberAccess]
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        return {"status": "pool_connection_ok", "result": cursor.fetchone()}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
def connect_error_wrong_password():
    cfg = _get_config()
    cfg["password"] = "wrong_password_xyz"
    try:
        conn = pymssql.connect(**cfg)
        conn.close()
        return {"status": "unexpected_success"}
    except pymssql.OperationalError as e:
        return {"status": "error", "msg": str(e)}


def connect_error_wrong_host():
    cfg = _get_config()
    cfg["server"] = "192.0.2.1"
    cfg["login_timeout"] = 3
    try:
        conn = pymssql.connect(**cfg)
        conn.close()
        return {"status": "unexpected_success"}
    except pymssql.OperationalError as e:
        return {"status": "error", "msg": str(e)}


def connect_error_unknown_db():
    cfg = _get_config()
    cfg["database"] = "non_existent_db_xyz"
    try:
        conn = pymssql.connect(**cfg)
        conn.close()
        return {"status": "unexpected_success"}
    except (pymssql.OperationalError, pymssql.DatabaseError) as e:
        return {"status": "error", "msg": str(e)}


def connect_error_timeout():
    cfg = _get_config()
    cfg["server"] = "192.0.2.1"
    cfg["login_timeout"] = 1
    try:
        conn = pymssql.connect(**cfg)
        conn.close()
        return {"status": "unexpected_success"}
    except pymssql.OperationalError as e:
        return {"status": "error", "msg": str(e)}


def pool_error_exhaustion():
    from dbutils.pooled_db import PooledDB

    _ensure_database()
    cfg = _get_config()
    small_pool = PooledDB(
        creator=pymssql,
        maxconnections=1,
        mincached=0,
        maxcached=0,
        blocking=False,
        server=cfg["server"],
        port=cfg["port"],
        user=cfg["user"],
        password=cfg["password"],
        database=cfg["database"],
        login_timeout=cfg["login_timeout"],
    )
    held = []
    try:
        held.append(small_pool.connection())
        held.append(small_pool.connection())
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "pool_exhausted", "msg": str(e)}
    finally:
        for c in held:
            c.close()


# ---------------------------------------------------------------------------
# Query execution
# ---------------------------------------------------------------------------
def execute_create_table():
    _ensure_database()
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"""
            IF OBJECT_ID('{_TABLE}', 'U') IS NOT NULL
                DROP TABLE {_TABLE}
        """)
        cursor.execute(f"""
            CREATE TABLE {_TABLE} (
                id INT IDENTITY(1,1) PRIMARY KEY,
                name NVARCHAR(100) NOT NULL,
                value INT DEFAULT 0,
                created_at DATETIME DEFAULT GETDATE()
            )
        """)
        conn.commit()
        return {"status": "table_created"}
    finally:
        conn.close()


def execute_insert():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
            ("test_item", 42),
        )
        conn.commit()
        cursor.execute("SELECT SCOPE_IDENTITY()")
        lastrowid = cursor.fetchone()[0] # pyright: ignore[reportArgumentType, reportOptionalSubscript]
        return {"status": "inserted", "lastrowid": lastrowid}
    finally:
        conn.close()


def execute_insert_many():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        data = [("batch_1", 10), ("batch_2", 20), ("batch_3", 30)]
        cursor.executemany(
            f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)", data
        )
        conn.commit()
        return {"status": "inserted_many", "rowcount": cursor.rowcount}
    finally:
        conn.close()


def execute_update():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"UPDATE {_TABLE} SET value = %s WHERE name = %s",
            (99, "test_item"),
        )
        conn.commit()
        return {"status": "updated", "rowcount": cursor.rowcount}
    finally:
        conn.close()


def execute_delete():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"DELETE FROM {_TABLE} WHERE name = %s", ("test_item",)
        )
        conn.commit()
        return {"status": "deleted", "rowcount": cursor.rowcount}
    finally:
        conn.close()


def execute_select():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT TOP 10 id, name, value FROM {_TABLE}")
        rows = cursor.fetchall()
        return {"status": "selected", "rows": rows}
    finally:
        conn.close()


def execute_parameterized():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"SELECT id, name FROM {_TABLE} WHERE value > %s", (5,)
        )
        rows = cursor.fetchall()
        return {"status": "parameterized_ok", "rows": rows}
    finally:
        conn.close()


def execute_transaction():
    conn = _get_connection()
    conn.autocommit(False)
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
            ("txn_item", 100),
        )
        conn.commit()

        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
            ("txn_rollback", 200),
        )
        conn.rollback()

        cursor.execute(f"SELECT name FROM {_TABLE} WHERE name LIKE 'txn_%'")
        rows = cursor.fetchall()
        return {"status": "transaction_ok", "committed_rows": rows}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Data fetching
# ---------------------------------------------------------------------------
def fetch_one():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT TOP 1 id, name, value FROM {_TABLE}")
        row = cursor.fetchone()
        return {"status": "fetch_one", "row": row}
    finally:
        conn.close()


def fetch_all():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE}")
        rows = cursor.fetchall()
        return {"status": "fetch_all", "count": len(rows), "rows": rows}
    finally:
        conn.close()


def fetch_many():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE}")
        batch = cursor.fetchmany(2)
        return {"status": "fetch_many", "batch": batch}
    finally:
        conn.close()


def fetch_as_dict():
    conn = _get_connection(as_dict=True)
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT TOP 5 id, name, value FROM {_TABLE}")
        rows = cursor.fetchall()
        return {"status": "fetch_as_dict", "rows": rows}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Advanced / unique cases
# ---------------------------------------------------------------------------
def call_stored_procedure():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"""
            IF OBJECT_ID('sp_get_count', 'P') IS NOT NULL
                DROP PROCEDURE sp_get_count
        """)
        cursor.execute(f"""
            CREATE PROCEDURE sp_get_count
                @total INT OUTPUT
            AS
            BEGIN
                SELECT @total = COUNT(*) FROM {_TABLE}
            END
        """)
        conn.commit()

        cursor.execute("DECLARE @out INT; EXEC sp_get_count @total = @out OUTPUT; SELECT @out")
        total = cursor.fetchone()[0] # pyright: ignore[reportArgumentType, reportOptionalSubscript]
        return {"status": "stored_proc_ok", "total": total}
    finally:
        conn.close()


def multiple_result_sets():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"SELECT TOP 2 id, name FROM {_TABLE}; "
            f"SELECT COUNT(*) AS cnt FROM {_TABLE}"
        )
        first = cursor.fetchall()
        cursor.nextset()
        second = cursor.fetchall()
        return {"status": "multiple_result_sets_ok", "first": first, "second": second}
    finally:
        conn.close()


def dynamic_query(table_name=_TABLE, columns=None, where_clause=None):
    conn = _get_connection(as_dict=True)
    try:
        cursor = conn.cursor()
        cols = ", ".join(columns) if columns else "*"
        query = f"SELECT {cols} FROM [{table_name}]"
        params = ()
        if where_clause:
            query += " WHERE " + where_clause["condition"]
            params = tuple(where_clause.get("params", ()))
        cursor.execute(query, params)
        rows = cursor.fetchall()
        return {"status": "dynamic_query_ok", "rows": rows}
    finally:
        conn.close()


def delayed_insert():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("WAITFOR DELAY '00:00:01'")
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
            ("delayed_item", 555),
        )
        conn.commit()
        cursor.execute("SELECT SCOPE_IDENTITY()")
        lastrowid = cursor.fetchone()[0] # pyright: ignore[reportArgumentType, reportOptionalSubscript]
        return {"status": "delayed_insert_ok", "lastrowid": lastrowid}
    finally:
        conn.close()


def race_condition_test():
    conn1 = _get_connection()
    conn2 = _get_connection()
    conn1.autocommit(False)
    conn2.autocommit(False)
    try:
        cursor1 = conn1.cursor()
        cursor1.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
            ("race_item", 0),
        )
        conn1.commit()

        cursor1.execute(
            f"SELECT value FROM {_TABLE} WITH (UPDLOCK, ROWLOCK) WHERE name = 'race_item'"
        )
        current = cursor1.fetchone()[0] # pyright: ignore[reportOptionalSubscript, reportArgumentType]
        cursor1.execute(
            f"UPDATE {_TABLE} SET value = %s WHERE name = 'race_item'",
            (current + 1,), # pyright: ignore[reportOperatorIssue]
        )
        conn1.commit()

        cursor2 = conn2.cursor()
        cursor2.execute(
            f"SELECT value FROM {_TABLE} WITH (UPDLOCK, ROWLOCK) WHERE name = 'race_item'"
        )
        current2 = cursor2.fetchone()[0] # pyright: ignore[reportArgumentType, reportOptionalSubscript]
        cursor2.execute(
            f"UPDATE {_TABLE} SET value = %s WHERE name = 'race_item'",
            (current2 + 1,), # pyright: ignore[reportOperatorIssue]
        )
        conn2.commit()

        cursor1.execute(f"SELECT value FROM {_TABLE} WHERE name = 'race_item'")
        final = cursor1.fetchone()[0] # pyright: ignore[reportOptionalSubscript, reportArgumentType]
        return {"status": "race_test_ok", "final_value": final}
    finally:
        conn1.close()
        conn2.close()


# ---------------------------------------------------------------------------
# Global route-to-function mapping
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/db/mssql/pymssql/connect": connect,
    "/db/mssql/pymssql/connect_pool": connect_pool,
    "/db/mssql/pymssql/get_connection_from_pool": get_connection_from_pool,
    "/db/mssql/pymssql/connect_error_wrong_password": connect_error_wrong_password,
    "/db/mssql/pymssql/connect_error_wrong_host": connect_error_wrong_host,
    "/db/mssql/pymssql/connect_error_unknown_db": connect_error_unknown_db,
    "/db/mssql/pymssql/connect_error_timeout": connect_error_timeout,
    "/db/mssql/pymssql/pool_error_exhaustion": pool_error_exhaustion,
    "/db/mssql/pymssql/execute_create_table": execute_create_table,
    "/db/mssql/pymssql/execute_insert": execute_insert,
    "/db/mssql/pymssql/execute_insert_many": execute_insert_many,
    "/db/mssql/pymssql/execute_update": execute_update,
    "/db/mssql/pymssql/execute_delete": execute_delete,
    "/db/mssql/pymssql/execute_select": execute_select,
    "/db/mssql/pymssql/execute_parameterized": execute_parameterized,
    "/db/mssql/pymssql/execute_transaction": execute_transaction,
    "/db/mssql/pymssql/fetch_one": fetch_one,
    "/db/mssql/pymssql/fetch_all": fetch_all,
    "/db/mssql/pymssql/fetch_many": fetch_many,
    "/db/mssql/pymssql/fetch_as_dict": fetch_as_dict,
    "/db/mssql/pymssql/call_stored_procedure": call_stored_procedure,
    "/db/mssql/pymssql/multiple_result_sets": multiple_result_sets,
    "/db/mssql/pymssql/dynamic_query": dynamic_query,
    "/db/mssql/pymssql/delayed_insert": delayed_insert,
    "/db/mssql/pymssql/race_condition_test": race_condition_test,
}
