"""
Memcache Cache Component - pymemcache module
Covers: connection, pool, errors, KV ops, TTL, bulk, counters, CAS,
        serialization, flush, stats, retry
"""

import json
import time
from pymemcache.client.base import Client, PooledClient
from pymemcache.client.retrying import RetryingClient
from pymemcache import exceptions as mc_exc
from apm_component.config import get_memcached_config


_PREFIX = "ct_pymemcache_"


def _get_config():
    return get_memcached_config()


def _get_client():
    cfg = _get_config()
    return Client(
        (cfg["host"], cfg["port"]),
        connect_timeout=cfg["connect_timeout"],
        timeout=cfg["timeout"],
    )


def _cleanup(client, pattern_prefix=None):
    client.flush_all()


# ---------------------------------------------------------------------------
# JSON serde for pymemcache
# ---------------------------------------------------------------------------
class _JsonSerde:
    def serialize(self, key, value):
        if isinstance(value, str):
            return value.encode("utf-8"), 1
        return json.dumps(value).encode("utf-8"), 2

    def deserialize(self, key, value, flags):
        if flags == 1:
            return value.decode("utf-8")
        if flags == 2:
            return json.loads(value.decode("utf-8"))
        return value


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------
def connect():
    client = _get_client()
    try:
        stats = client.stats()
        pid = stats.get(b"pid", b"")
        return {"status": "connected", "pid": str(pid)}
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Connection pooling
# ---------------------------------------------------------------------------
def connect_pool():
    cfg = _get_config()
    client = PooledClient(
        (cfg["host"], cfg["port"]),
        connect_timeout=cfg["connect_timeout"],
        timeout=cfg["timeout"],
        max_pool_size=5,
    )
    try:
        client.set(f"{_PREFIX}pool_test", b"ok")
        val = client.get(f"{_PREFIX}pool_test")
        return {"status": "pool_connected", "value": val.decode() if val else None}
    finally:
        client.delete(f"{_PREFIX}pool_test", noreply=False)
        client.close()


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
def connect_error_wrong_host():
    try:
        client = Client(("192.0.2.1", 11211), connect_timeout=2, timeout=2)
        client.set("test", b"val")
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def connect_error_wrong_port():
    try:
        client = Client(("127.0.0.1", 59999), connect_timeout=2, timeout=2)
        client.set("test", b"val")
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def connect_error_timeout():
    try:
        client = Client(("192.0.2.1", 11211), connect_timeout=1, timeout=1)
        client.set("test", b"val")
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


# ---------------------------------------------------------------------------
# Key-Value operations
# ---------------------------------------------------------------------------
def set_get():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}key1", b"hello")
        val = client.get(f"{_PREFIX}key1")
        return {"status": "success", "value": val.decode() if val else None}
    finally:
        client.delete(f"{_PREFIX}key1", noreply=False)
        client.close()


def delete_key():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}del_key", b"to_delete")
        deleted = client.delete(f"{_PREFIX}del_key", noreply=False)
        val = client.get(f"{_PREFIX}del_key")
        return {"status": "success", "deleted": deleted, "value_after": val}
    finally:
        client.close()


def add_key():
    client = _get_client()
    try:
        client.delete(f"{_PREFIX}add_key", noreply=False)
        first = client.add(f"{_PREFIX}add_key", b"first", noreply=False)
        second = client.add(f"{_PREFIX}add_key", b"second", noreply=False)
        val = client.get(f"{_PREFIX}add_key")
        return {"status": "success", "first_add": bool(first), "second_add": bool(second), "value": val.decode() if val else None}
    finally:
        client.delete(f"{_PREFIX}add_key", noreply=False)
        client.close()


def replace_key():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}rep_key", b"original")
        replaced = client.replace(f"{_PREFIX}rep_key", b"replaced")
        val = client.get(f"{_PREFIX}rep_key")
        return {"status": "success", "replaced": replaced, "value": val.decode() if val else None}
    finally:
        client.delete(f"{_PREFIX}rep_key", noreply=False)
        client.close()


def append_prepend():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}ap_key", b"hello")
        client.append(f"{_PREFIX}ap_key", b" world")
        client.prepend(f"{_PREFIX}ap_key", b"say: ")
        val = client.get(f"{_PREFIX}ap_key")
        return {"status": "success", "value": val.decode() if val else None}
    finally:
        client.delete(f"{_PREFIX}ap_key", noreply=False)
        client.close()


# ---------------------------------------------------------------------------
# Bulk operations
# ---------------------------------------------------------------------------
def set_many_get_many():
    client = _get_client()
    try:
        data = {
            f"{_PREFIX}bulk_1": b"a",
            f"{_PREFIX}bulk_2": b"b",
            f"{_PREFIX}bulk_3": b"c",
        }
        failed = client.set_many(data)
        keys = list(data.keys())
        vals = client.get_many(keys)
        decoded = {k: v.decode() if v else None for k, v in vals.items()}
        return {"status": "success", "failed_keys": failed, "values": decoded}
    finally:
        client.delete_many(list(data.keys()))
        client.close()


def delete_many():
    client = _get_client()
    try:
        data = {f"{_PREFIX}dm_1": b"x", f"{_PREFIX}dm_2": b"y"}
        client.set_many(data)
        keys = list(data.keys())
        deleted = client.delete_many(keys)
        remaining = client.get_many(keys)
        return {"status": "success", "deleted": deleted, "remaining": len(remaining)}
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Counters
# ---------------------------------------------------------------------------
def incr_decr():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}counter", b"10")
        val1 = client.incr(f"{_PREFIX}counter", 5)
        val2 = client.decr(f"{_PREFIX}counter", 3)
        return {"status": "success", "after_incr": val1, "after_decr": val2}
    finally:
        client.delete(f"{_PREFIX}counter", noreply=False)
        client.close()


# ---------------------------------------------------------------------------
# Expiration / TTL
# ---------------------------------------------------------------------------
def set_with_ttl():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}ttl_key", b"expires_soon", expire=2)
        val_before = client.get(f"{_PREFIX}ttl_key")
        time.sleep(2.5)
        val_after = client.get(f"{_PREFIX}ttl_key")
        return {
            "status": "success",
            "before": val_before.decode() if val_before else None,
            "after": val_after,
        }
    finally:
        client.delete(f"{_PREFIX}ttl_key", noreply=False)
        client.close()


# ---------------------------------------------------------------------------
# Key existence (get returns None if not found)
# ---------------------------------------------------------------------------
def key_exists():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}ex_key", b"yes")
        exists = client.get(f"{_PREFIX}ex_key") is not None
        client.delete(f"{_PREFIX}ex_key", noreply=False)
        not_exists = client.get(f"{_PREFIX}ex_key") is not None
        return {"status": "success", "exists": exists, "not_exists": not_exists}
    finally:
        client.close()


# ---------------------------------------------------------------------------
# CAS (Compare and Swap)
# ---------------------------------------------------------------------------
def cas_operations():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}cas_key", b"original")
        val, cas_token = client.gets(f"{_PREFIX}cas_key")
        success = client.cas(f"{_PREFIX}cas_key", b"updated", cas_token)
        final = client.get(f"{_PREFIX}cas_key")
        return {
            "status": "success",
            "original": val.decode() if val else None,
            "cas_success": success,
            "final": final.decode() if final else None,
        }
    finally:
        client.delete(f"{_PREFIX}cas_key", noreply=False)
        client.close()


# ---------------------------------------------------------------------------
# Serialization (JSON via custom serde)
# ---------------------------------------------------------------------------
def json_serialization():
    cfg = _get_config()
    client = Client(
        (cfg["host"], cfg["port"]),
        serde=_JsonSerde(),
        connect_timeout=cfg["connect_timeout"],
        timeout=cfg["timeout"],
    )
    try:
        data = {"name": "test", "values": [1, 2, 3], "nested": {"a": True}}
        client.set(f"{_PREFIX}json_key", data)
        parsed = client.get(f"{_PREFIX}json_key")
        return {"status": "success", "data": parsed}
    finally:
        client.delete(f"{_PREFIX}json_key", noreply=False)
        client.close()


# ---------------------------------------------------------------------------
# Flush
# ---------------------------------------------------------------------------
def flush_all():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}flush_1", b"a")
        client.set(f"{_PREFIX}flush_2", b"b")
        client.flush_all()
        val = client.get(f"{_PREFIX}flush_1")
        return {"status": "success", "after_flush": val}
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------
def get_stats():
    client = _get_client()
    try:
        stats = client.stats()
        return {
            "status": "success",
            "pid": str(stats.get(b"pid", "")),
            "curr_items": int(stats.get(b"curr_items", 0)),
        }
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Retry client
# ---------------------------------------------------------------------------
def retry_client():
    cfg = _get_config()
    base = Client(
        (cfg["host"], cfg["port"]),
        connect_timeout=cfg["connect_timeout"],
        timeout=cfg["timeout"],
    )
    client = RetryingClient(
        base,
        attempts=3,
        retry_delay=0.1,
    )
    try:
        client.set(f"{_PREFIX}retry_key", b"retried")
        val = client.get(f"{_PREFIX}retry_key")
        return {"status": "success", "value": val.decode() if val else None}
    finally:
        client.delete(f"{_PREFIX}retry_key", noreply=False)
        client.close()


# ---------------------------------------------------------------------------
# Dynamic / Delay / Race
# ---------------------------------------------------------------------------
def dynamic_key_ops():
    client = _get_client()
    try:
        data = {f"{_PREFIX}dyn_{i}": f"val_{i}".encode() for i in range(5)}
        client.set_many(data)
        vals = client.get_many(list(data.keys()))
        decoded = {k: v.decode() if v else None for k, v in vals.items()}
        return {"status": "success", "key_count": len(vals), "values": decoded}
    finally:
        client.delete_many(list(data.keys()))
        client.close()


def delayed_operations():
    client = _get_client()
    try:
        client.set(f"{_PREFIX}delay_key", b"initial")
        time.sleep(0.5)
        client.set(f"{_PREFIX}delay_key", b"updated")
        val = client.get(f"{_PREFIX}delay_key")
        return {"status": "success", "value": val.decode() if val else None}
    finally:
        client.delete(f"{_PREFIX}delay_key", noreply=False)
        client.close()


def race_condition_test():
    cfg = _get_config()
    c1 = Client((cfg["host"], cfg["port"]), connect_timeout=cfg["connect_timeout"], timeout=cfg["timeout"])
    c2 = Client((cfg["host"], cfg["port"]), connect_timeout=cfg["connect_timeout"], timeout=cfg["timeout"])
    key = f"{_PREFIX}race_key"
    try:
        c1.set(key, b"0")
        c1.incr(key, 1)
        c2.incr(key, 1)
        c1.incr(key, 1)
        val = c1.get(key)
        return {"status": "success", "final_value": int(val) if val else None}
    finally:
        c1.delete(key, noreply=False)
        c1.close()
        c2.close()


# ---------------------------------------------------------------------------
# Global route-to-function mapping
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/cache/memcache/pymemcache/connect": connect,
    "/cache/memcache/pymemcache/connect_pool": connect_pool,
    "/cache/memcache/pymemcache/connect_error_wrong_host": connect_error_wrong_host,
    "/cache/memcache/pymemcache/connect_error_wrong_port": connect_error_wrong_port,
    "/cache/memcache/pymemcache/connect_error_timeout": connect_error_timeout,
    "/cache/memcache/pymemcache/set_get": set_get,
    "/cache/memcache/pymemcache/delete_key": delete_key,
    "/cache/memcache/pymemcache/add_key": add_key,
    "/cache/memcache/pymemcache/replace_key": replace_key,
    "/cache/memcache/pymemcache/append_prepend": append_prepend,
    "/cache/memcache/pymemcache/set_many_get_many": set_many_get_many,
    "/cache/memcache/pymemcache/delete_many": delete_many,
    "/cache/memcache/pymemcache/incr_decr": incr_decr,
    "/cache/memcache/pymemcache/set_with_ttl": set_with_ttl,
    "/cache/memcache/pymemcache/key_exists": key_exists,
    "/cache/memcache/pymemcache/cas_operations": cas_operations,
    "/cache/memcache/pymemcache/json_serialization": json_serialization,
    "/cache/memcache/pymemcache/flush_all": flush_all,
    "/cache/memcache/pymemcache/get_stats": get_stats,
    "/cache/memcache/pymemcache/retry_client": retry_client,
    "/cache/memcache/pymemcache/dynamic_key_ops": dynamic_key_ops,
    "/cache/memcache/pymemcache/delayed_operations": delayed_operations,
    "/cache/memcache/pymemcache/race_condition_test": race_condition_test,
}
