"""
MySQL Component - PyMySQL module
Covers: connection, pool (via DBUtils), error handling, execution, fetching, advanced features
"""

import pymysql
from pymysql.cursors import DictCursor, SSCursor, SSDictCursor
from apm_component.config import get_mysql_config


_TABLE = "ct_pymysql"


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------
def _get_config():
    cfg = get_mysql_config()
    return {
        "host": cfg["host"],
        "port": cfg["port"],
        "user": cfg["user"],
        "password": cfg["password"],
        "database": cfg["database"],
        "connect_timeout": cfg["connect_timeout"],
    }


def _get_connection():
    return pymysql.connect(**_get_config())


def connect():
    """Basic connection to MySQL."""
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT 1")
            result = cursor.fetchone()
        return {"status": "connected", "result": result}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Connection pooling (via DBUtils)
# ---------------------------------------------------------------------------
_pool = None


def connect_pool():
    """Create a connection pool using DBUtils.PooledDB."""
    global _pool
    from dbutils.pooled_db import PooledDB

    cfg = _get_config()
    _pool = PooledDB(
        creator=pymysql,
        maxconnections=get_mysql_config()["pool_size"],
        mincached=1,
        maxcached=3,
        blocking=True,
        host=cfg["host"],
        port=cfg["port"],
        user=cfg["user"],
        password=cfg["password"],
        database=cfg["database"],
        connect_timeout=cfg["connect_timeout"],
    )
    return {"status": "pool_created"}


def get_connection_from_pool():
    """Acquire a connection from the pool."""
    if _pool is None:
        connect_pool()
    conn = _pool.connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT 1")
            return {"status": "pool_connection_ok", "result": cursor.fetchone()}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
def connect_error_wrong_password():
    """Attempt connection with wrong password."""
    cfg = _get_config()
    cfg["password"] = "wrong_password_xyz"
    try:
        conn = pymysql.connect(**cfg)
        conn.close()
        return {"status": "unexpected_success"}
    except pymysql.err.OperationalError as e:
        return {"status": "error", "errno": e.args[0], "msg": str(e)}


def connect_error_wrong_host():
    """Attempt connection to unreachable host."""
    cfg = _get_config()
    cfg["host"] = "192.0.2.1"
    cfg["connect_timeout"] = 3
    try:
        conn = pymysql.connect(**cfg)
        conn.close()
        return {"status": "unexpected_success"}
    except pymysql.err.OperationalError as e:
        return {"status": "error", "errno": e.args[0], "msg": str(e)}


def connect_error_unknown_db():
    """Attempt connection to non-existent database."""
    cfg = _get_config()
    cfg["database"] = "non_existent_db_xyz"
    try:
        conn = pymysql.connect(**cfg)
        conn.close()
        return {"status": "unexpected_success"}
    except pymysql.err.OperationalError as e:
        return {"status": "error", "errno": e.args[0], "msg": str(e)}


def connect_error_timeout():
    """Attempt connection with very short timeout."""
    cfg = _get_config()
    cfg["host"] = "192.0.2.1"
    cfg["connect_timeout"] = 1
    try:
        conn = pymysql.connect(**cfg)
        conn.close()
        return {"status": "unexpected_success"}
    except pymysql.err.OperationalError as e:
        return {"status": "error", "errno": e.args[0], "msg": str(e)}


def pool_error_exhaustion():
    """Exhaust pool connections to trigger error."""
    from dbutils.pooled_db import PooledDB
    cfg = _get_config()
    small_pool = PooledDB(
        creator=pymysql,
        maxconnections=1,
        mincached=0,
        maxcached=0,
        blocking=False,
        host=cfg["host"],
        port=cfg["port"],
        user=cfg["user"],
        password=cfg["password"],
        database=cfg["database"],
    )
    held = []
    try:
        held.append(small_pool.connection())
        held.append(small_pool.connection())  # should raise
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "pool_exhausted", "msg": str(e)}
    finally:
        for c in held:
            c.close()


# ---------------------------------------------------------------------------
# Query execution
# ---------------------------------------------------------------------------
def execute_create_table():
    """DDL - create a test table."""
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(f"DROP TABLE IF EXISTS {_TABLE}")
            cursor.execute(f"""
                CREATE TABLE {_TABLE} (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    value INT DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
        conn.commit()
        return {"status": "table_created"}
    finally:
        conn.close()


def execute_insert():
    """DML - single row insert."""
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
                ("test_item", 42),
            )
        conn.commit()
        return {"status": "inserted", "lastrowid": cursor.lastrowid}
    finally:
        conn.close()


def execute_insert_many():
    """DML - batch insert using executemany."""
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            data = [("batch_1", 10), ("batch_2", 20), ("batch_3", 30)]
            cursor.executemany(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)", data
            )
        conn.commit()
        return {"status": "inserted_many", "rowcount": cursor.rowcount}
    finally:
        conn.close()


def execute_update():
    """DML - update rows."""
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                f"UPDATE {_TABLE} SET value = %s WHERE name = %s",
                (99, "test_item"),
            )
        conn.commit()
        return {"status": "updated", "rowcount": cursor.rowcount}
    finally:
        conn.close()


def execute_delete():
    """DML - delete rows."""
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                f"DELETE FROM {_TABLE} WHERE name = %s", ("test_item",)
            )
        conn.commit()
        return {"status": "deleted", "rowcount": cursor.rowcount}
    finally:
        conn.close()


def execute_select():
    """DML - select query."""
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 10")
            rows = cursor.fetchall()
        return {"status": "selected", "rows": rows}
    finally:
        conn.close()


def execute_parameterized():
    """Parameterized query execution."""
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                f"SELECT id, name FROM {_TABLE} WHERE value > %s", (5,)
            )
            rows = cursor.fetchall()
        return {"status": "parameterized_ok", "rows": rows}
    finally:
        conn.close()


def execute_transaction():
    """Explicit transaction with commit and rollback."""
    conn = _get_connection()
    conn.autocommit(False)
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
                ("txn_item", 100),
            )
        conn.commit()

        with conn.cursor() as cursor:
            cursor.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
                ("txn_rollback", 200),
            )
        conn.rollback()

        with conn.cursor() as cursor:
            cursor.execute(f"SELECT name FROM {_TABLE} WHERE name LIKE 'txn_%'")
            rows = cursor.fetchall()
        return {"status": "transaction_ok", "committed_rows": rows}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Data fetching
# ---------------------------------------------------------------------------
def fetch_one():
    """Fetch a single row."""
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 1")
            row = cursor.fetchone()
        return {"status": "fetch_one", "row": row}
    finally:
        conn.close()


def fetch_all():
    """Fetch all rows."""
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(f"SELECT id, name, value FROM {_TABLE}")
            rows = cursor.fetchall()
        return {"status": "fetch_all", "count": len(rows), "rows": rows}
    finally:
        conn.close()


def fetch_many():
    """Fetch a batch of rows."""
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(f"SELECT id, name, value FROM {_TABLE}")
            batch = cursor.fetchmany(2)
        return {"status": "fetch_many", "batch": batch}
    finally:
        conn.close()


def fetch_dict_cursor():
    """Fetch rows as dictionaries using DictCursor."""
    conn = _get_connection()
    try:
        with conn.cursor(DictCursor) as cursor:
            cursor.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 5")
            rows = cursor.fetchall()
        return {"status": "dict_cursor", "rows": rows}
    finally:
        conn.close()


def fetch_ss_cursor():
    """Fetch using server-side (unbuffered) cursor."""
    conn = _get_connection()
    try:
        with conn.cursor(SSCursor) as cursor:
            cursor.execute(f"SELECT id, name, value FROM {_TABLE}")
            rows = cursor.fetchall()
        return {"status": "ss_cursor", "rows": rows}
    finally:
        conn.close()


def fetch_ss_dict_cursor():
    """Fetch using server-side dictionary cursor."""
    conn = _get_connection()
    try:
        with conn.cursor(SSDictCursor) as cursor:
            cursor.execute(f"SELECT id, name, value FROM {_TABLE} LIMIT 5")
            rows = cursor.fetchall()
        return {"status": "ss_dict_cursor", "rows": rows}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Advanced / unique cases
# ---------------------------------------------------------------------------
def call_stored_procedure():
    """Call a stored procedure."""
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("DROP PROCEDURE IF EXISTS sp_get_count")
            cursor.execute(f"""
                CREATE PROCEDURE sp_get_count(OUT total INT)
                BEGIN
                    SELECT COUNT(*) INTO total FROM {_TABLE};
                END
            """)
        conn.commit()

        with conn.cursor() as cursor:
            cursor.callproc("sp_get_count", (0,))
            cursor.execute("SELECT @_sp_get_count_0")
            total = cursor.fetchone()
        return {"status": "stored_proc_ok", "total": total}
    finally:
        conn.close()


def mogrify_query():
    """Use mogrify to inspect a query without executing it."""
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            query = cursor.mogrify(
                f"SELECT * FROM {_TABLE} WHERE name = %s AND value > %s",
                ("test", 10),
            )
        return {"status": "mogrify_ok", "query": query.decode() if isinstance(query, bytes) else query}
    finally:
        conn.close()


def ping_reconnect():
    """Ping the server and reconnect if needed."""
    conn = _get_connection()
    try:
        conn.ping(reconnect=True)
        return {"status": "ping_ok"}
    finally:
        conn.close()


def dynamic_query(table_name=_TABLE, columns=None, where_clause=None):
    """Build and execute a query dynamically."""
    conn = _get_connection()
    try:
        with conn.cursor(DictCursor) as cursor:
            cols = ", ".join(columns) if columns else "*"
            query = f"SELECT {cols} FROM `{table_name}`"
            params = ()
            if where_clause:
                query += " WHERE " + where_clause["condition"]
                params = tuple(where_clause.get("params", ()))
            cursor.execute(query, params)
            rows = cursor.fetchall()
        return {"status": "dynamic_query_ok", "rows": rows}
    finally:
        conn.close()


def delayed_insert():
    """Insert after a server-side delay."""
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT SLEEP(1)")
            cursor.fetchall()
            cursor.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
                ("delayed_item", 555),
            )
        conn.commit()
        return {"status": "delayed_insert_ok", "lastrowid": cursor.lastrowid}
    finally:
        conn.close()


def race_condition_test():
    """Simulate a race condition using two connections."""
    conn1 = _get_connection()
    conn2 = _get_connection()
    conn1.autocommit(False)
    conn2.autocommit(False)
    try:
        with conn1.cursor() as cur1:
            cur1.execute(
                f"INSERT INTO {_TABLE} (name, value) VALUES (%s, %s)",
                ("race_item", 0),
            )
        conn1.commit()

        with conn1.cursor() as cur1:
            cur1.execute(f"SELECT value FROM {_TABLE} WHERE name = 'race_item' FOR UPDATE")
            current = cur1.fetchone()[0]
            cur1.execute(
                f"UPDATE {_TABLE} SET value = %s WHERE name = 'race_item'",
                (current + 1,),
            )
        conn1.commit()

        with conn2.cursor() as cur2:
            cur2.execute(f"SELECT value FROM {_TABLE} WHERE name = 'race_item' FOR UPDATE")
            current2 = cur2.fetchone()[0]
            cur2.execute(
                f"UPDATE {_TABLE} SET value = %s WHERE name = 'race_item'",
                (current2 + 1,),
            )
        conn2.commit()

        with conn1.cursor() as cur1:
            cur1.execute(f"SELECT value FROM {_TABLE} WHERE name = 'race_item'")
            final = cur1.fetchone()[0]
        return {"status": "race_test_ok", "final_value": final}
    finally:
        conn1.close()
        conn2.close()


# ---------------------------------------------------------------------------
# Global route-to-function mapping
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/db/mysql/pymysql/connect": connect,
    "/db/mysql/pymysql/connect_pool": connect_pool,
    "/db/mysql/pymysql/get_connection_from_pool": get_connection_from_pool,
    "/db/mysql/pymysql/connect_error_wrong_password": connect_error_wrong_password,
    "/db/mysql/pymysql/connect_error_wrong_host": connect_error_wrong_host,
    "/db/mysql/pymysql/connect_error_unknown_db": connect_error_unknown_db,
    "/db/mysql/pymysql/connect_error_timeout": connect_error_timeout,
    "/db/mysql/pymysql/pool_error_exhaustion": pool_error_exhaustion,
    "/db/mysql/pymysql/execute_create_table": execute_create_table,
    "/db/mysql/pymysql/execute_insert": execute_insert,
    "/db/mysql/pymysql/execute_insert_many": execute_insert_many,
    "/db/mysql/pymysql/execute_update": execute_update,
    "/db/mysql/pymysql/execute_delete": execute_delete,
    "/db/mysql/pymysql/execute_select": execute_select,
    "/db/mysql/pymysql/execute_parameterized": execute_parameterized,
    "/db/mysql/pymysql/execute_transaction": execute_transaction,
    "/db/mysql/pymysql/fetch_one": fetch_one,
    "/db/mysql/pymysql/fetch_all": fetch_all,
    "/db/mysql/pymysql/fetch_many": fetch_many,
    "/db/mysql/pymysql/fetch_dict_cursor": fetch_dict_cursor,
    "/db/mysql/pymysql/fetch_ss_cursor": fetch_ss_cursor,
    "/db/mysql/pymysql/fetch_ss_dict_cursor": fetch_ss_dict_cursor,
    "/db/mysql/pymysql/call_stored_procedure": call_stored_procedure,
    "/db/mysql/pymysql/mogrify_query": mogrify_query,
    "/db/mysql/pymysql/ping_reconnect": ping_reconnect,
    "/db/mysql/pymysql/dynamic_query": dynamic_query,
    "/db/mysql/pymysql/delayed_insert": delayed_insert,
    "/db/mysql/pymysql/race_condition_test": race_condition_test,
}
