"""
MySQL Component - SQLAlchemy module
Covers: connection, pool, error handling, execution, fetching, ORM, advanced features
"""

from sqlalchemy import (
    create_engine,
    text,
    MetaData,
    Table,
    Column,
    Integer,
    String,
    TIMESTAMP,
    insert,
    select,
    update,
    delete,
    func,
    event,
    exc,
    pool as sa_pool,
)
from sqlalchemy.orm import Session, DeclarativeBase, Mapped, mapped_column
from apm_component.config import get_mysql_config


_TABLE = "ct_sqlalchemy"


# ---------------------------------------------------------------------------
# ORM model
# ---------------------------------------------------------------------------
class Base(DeclarativeBase):
    pass


class ComponentTest(Base):
    __tablename__ = "component_test_orm"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    value: Mapped[int] = mapped_column(Integer, default=0)


# ---------------------------------------------------------------------------
# Engine / connection helpers
# ---------------------------------------------------------------------------
def _build_url(override=None):
    cfg = get_mysql_config()
    if override:
        cfg.update(override)
    return (
        f"mysql+pymysql://{cfg['user']}:{cfg['password']}"
        f"@{cfg['host']}:{cfg['port']}/{cfg['database']}"
    )


_engine = None


def _get_engine():
    global _engine
    if _engine is None:
        cfg = get_mysql_config()
        _engine = create_engine(
            _build_url(),
            pool_size=cfg["pool_size"],
            max_overflow=2,
            pool_recycle=3600,
            pool_pre_ping=True,
            connect_args={"connect_timeout": cfg["connect_timeout"]},
        )
    return _engine


# Core table object (used by Core-style queries)
_metadata = MetaData()
_component_table = Table(
    _TABLE,
    _metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("name", String(100), nullable=False),
    Column("value", Integer, default=0),
)


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------
def connect():
    """Basic engine connection test."""
    engine = _get_engine()
    with engine.connect() as conn:
        result = conn.execute(text("SELECT 1"))
        row = result.fetchone()
    return {"status": "connected", "result": row[0]}


def connect_pool():
    """Engine with QueuePool (default) - verify pool status."""
    engine = _get_engine()
    pool = engine.pool
    return {
        "status": "pool_active",
        "pool_class": type(pool).__name__,
        "size": pool.size(),
        "checkedin": pool.checkedin(),
        "checkedout": pool.checkedout(),
    }


def connect_nullpool():
    """Engine with NullPool (no pooling)."""
    engine = create_engine(_build_url(), poolclass=sa_pool.NullPool)
    with engine.connect() as conn:
        result = conn.execute(text("SELECT 1"))
        row = result.fetchone()
    engine.dispose()
    return {"status": "nullpool_ok", "result": row[0]}


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
def connect_error_wrong_password():
    """Attempt connection with wrong password."""
    engine = create_engine(
        _build_url({"password": "wrong_password_xyz"}),
        pool_pre_ping=False,
    )
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return {"status": "unexpected_success"}
    except exc.OperationalError as e:
        return {"status": "error", "msg": str(e.orig)}
    finally:
        engine.dispose()


def connect_error_wrong_host():
    """Attempt connection to unreachable host."""
    engine = create_engine(
        _build_url({"host": "192.0.2.1"}),
        connect_args={"connect_timeout": 3},
        pool_pre_ping=False,
    )
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return {"status": "unexpected_success"}
    except exc.OperationalError as e:
        return {"status": "error", "msg": str(e.orig)}
    finally:
        engine.dispose()


def connect_error_unknown_db():
    """Attempt connection to non-existent database."""
    engine = create_engine(
        _build_url({"database": "non_existent_db_xyz"}),
        pool_pre_ping=False,
    )
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return {"status": "unexpected_success"}
    except exc.OperationalError as e:
        return {"status": "error", "msg": str(e.orig)}
    finally:
        engine.dispose()


def connect_error_timeout():
    """Attempt connection with very short timeout."""
    engine = create_engine(
        _build_url({"host": "192.0.2.1"}),
        connect_args={"connect_timeout": 1},
        pool_pre_ping=False,
    )
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return {"status": "unexpected_success"}
    except exc.OperationalError as e:
        return {"status": "error", "msg": str(e.orig)}
    finally:
        engine.dispose()


def pool_error_overflow():
    """Exhaust pool + overflow to trigger timeout."""
    engine = create_engine(
        _build_url(),
        pool_size=1,
        max_overflow=0,
        pool_timeout=2,
    )
    held = []
    try:
        held.append(engine.connect())
        held.append(engine.connect())  # should timeout
        return {"status": "unexpected_success"}
    except exc.TimeoutError as e:
        return {"status": "pool_overflow", "msg": str(e)}
    finally:
        for c in held:
            c.close()
        engine.dispose()


# ---------------------------------------------------------------------------
# Raw SQL execution
# ---------------------------------------------------------------------------
def execute_raw_create_table():
    """DDL via raw SQL."""
    engine = _get_engine()
    with engine.connect() as conn:
        conn.execute(text(f"DROP TABLE IF EXISTS {_TABLE}"))
        conn.execute(text(f"""
            CREATE TABLE {_TABLE} (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                value INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """))
        conn.commit()
    return {"status": "table_created"}


def execute_raw_insert():
    """DML - raw insert."""
    engine = _get_engine()
    with engine.connect() as conn:
        result = conn.execute(
            text(f"INSERT INTO {_TABLE} (name, value) VALUES (:name, :value)"),
            {"name": "test_item", "value": 42},
        )
        conn.commit()
    return {"status": "inserted", "lastrowid": result.lastrowid}


def execute_raw_insert_params():
    """DML - raw parameterized batch insert."""
    engine = _get_engine()
    data = [
        {"name": "batch_1", "value": 10},
        {"name": "batch_2", "value": 20},
        {"name": "batch_3", "value": 30},
    ]
    with engine.connect() as conn:
        result = conn.execute(
            text(f"INSERT INTO {_TABLE} (name, value) VALUES (:name, :value)"),
            data,
        )
        conn.commit()
    return {"status": "inserted_many", "rowcount": result.rowcount}


def execute_raw_select():
    """DML - raw select."""
    engine = _get_engine()
    with engine.connect() as conn:
        result = conn.execute(text(f"SELECT id, name, value FROM {_TABLE} LIMIT 10"))
        rows = result.fetchall()
    return {"status": "selected", "rows": [tuple(r) for r in rows]}


def execute_raw_update():
    """DML - raw update."""
    engine = _get_engine()
    with engine.connect() as conn:
        result = conn.execute(
            text(f"UPDATE {_TABLE} SET value = :val WHERE name = :name"),
            {"val": 99, "name": "test_item"},
        )
        conn.commit()
    return {"status": "updated", "rowcount": result.rowcount}


def execute_raw_delete():
    """DML - raw delete."""
    engine = _get_engine()
    with engine.connect() as conn:
        result = conn.execute(
            text(f"DELETE FROM {_TABLE} WHERE name = :name"),
            {"name": "test_item"},
        )
        conn.commit()
    return {"status": "deleted", "rowcount": result.rowcount}


# ---------------------------------------------------------------------------
# Core expression execution
# ---------------------------------------------------------------------------
def execute_core_insert():
    """Core - single insert using expression."""
    engine = _get_engine()
    with engine.connect() as conn:
        result = conn.execute(
            _component_table.insert().values(name="core_item", value=50)
        )
        conn.commit()
    return {"status": "core_inserted", "lastrowid": result.lastrowid}


def execute_core_insert_many():
    """Core - batch insert."""
    engine = _get_engine()
    data = [
        {"name": "core_batch_1", "value": 11},
        {"name": "core_batch_2", "value": 22},
    ]
    with engine.connect() as conn:
        result = conn.execute(_component_table.insert(), data)
        conn.commit()
    return {"status": "core_inserted_many", "rowcount": result.rowcount}


def execute_core_select():
    """Core - select using expression."""
    engine = _get_engine()
    with engine.connect() as conn:
        stmt = select(_component_table).where(_component_table.c.value > 0).limit(10)
        result = conn.execute(stmt)
        rows = result.fetchall()
    return {"status": "core_selected", "rows": [tuple(r) for r in rows]}


def execute_core_update():
    """Core - update using expression."""
    engine = _get_engine()
    with engine.connect() as conn:
        stmt = (
            update(_component_table)
            .where(_component_table.c.name == "core_item")
            .values(value=999)
        )
        result = conn.execute(stmt)
        conn.commit()
    return {"status": "core_updated", "rowcount": result.rowcount}


def execute_core_delete():
    """Core - delete using expression."""
    engine = _get_engine()
    with engine.connect() as conn:
        stmt = delete(_component_table).where(_component_table.c.name == "core_item")
        result = conn.execute(stmt)
        conn.commit()
    return {"status": "core_deleted", "rowcount": result.rowcount}


# ---------------------------------------------------------------------------
# Transactions
# ---------------------------------------------------------------------------
def execute_transaction():
    """Explicit transaction with commit and rollback."""
    engine = _get_engine()
    with engine.connect() as conn:
        with conn.begin():
            conn.execute(
                text(f"INSERT INTO {_TABLE} (name, value) VALUES (:n, :v)"),
                {"n": "txn_item", "v": 100},
            )

        trans = conn.begin()
        conn.execute(
            text(f"INSERT INTO {_TABLE} (name, value) VALUES (:n, :v)"),
            {"n": "txn_rollback", "v": 200},
        )
        trans.rollback()

        result = conn.execute(
            text(f"SELECT name FROM {_TABLE} WHERE name LIKE 'txn_%'")
        )
        rows = result.fetchall()
    return {"status": "transaction_ok", "committed_rows": [r[0] for r in rows]}


def execute_savepoint():
    """Transaction with nested savepoints."""
    engine = _get_engine()
    with engine.connect() as conn:
        with conn.begin():
            conn.execute(
                text(f"INSERT INTO {_TABLE} (name, value) VALUES (:n, :v)"),
                {"n": "sp_outer", "v": 1},
            )
            savepoint = conn.begin_nested()
            conn.execute(
                text(f"INSERT INTO {_TABLE} (name, value) VALUES (:n, :v)"),
                {"n": "sp_inner_rollback", "v": 2},
            )
            savepoint.rollback()

            conn.execute(
                text(f"INSERT INTO {_TABLE} (name, value) VALUES (:n, :v)"),
                {"n": "sp_inner_commit", "v": 3},
            )

        result = conn.execute(
            text(f"SELECT name FROM {_TABLE} WHERE name LIKE 'sp_%'")
        )
        rows = result.fetchall()
    return {"status": "savepoint_ok", "rows": [r[0] for r in rows]}


# ---------------------------------------------------------------------------
# Data fetching
# ---------------------------------------------------------------------------
def fetch_one():
    """Fetch a single row."""
    engine = _get_engine()
    with engine.connect() as conn:
        result = conn.execute(text(f"SELECT id, name, value FROM {_TABLE} LIMIT 1"))
        row = result.fetchone()
    return {"status": "fetch_one", "row": tuple(row) if row else None}


def fetch_all():
    """Fetch all rows."""
    engine = _get_engine()
    with engine.connect() as conn:
        result = conn.execute(text(f"SELECT id, name, value FROM {_TABLE}"))
        rows = result.fetchall()
    return {"status": "fetch_all", "count": len(rows)}


def fetch_many():
    """Fetch a batch of rows."""
    engine = _get_engine()
    with engine.connect() as conn:
        result = conn.execute(text(f"SELECT id, name, value FROM {_TABLE}"))
        batch = result.fetchmany(2)
    return {"status": "fetch_many", "batch": [tuple(r) for r in batch]}


def fetch_mappings():
    """Fetch rows as dictionaries via mappings()."""
    engine = _get_engine()
    with engine.connect() as conn:
        result = conn.execute(text(f"SELECT id, name, value FROM {_TABLE} LIMIT 5"))
        rows = [dict(r) for r in result.mappings()]
    return {"status": "fetch_mappings", "rows": rows}


def fetch_scalars():
    """Fetch single column using scalars()."""
    engine = _get_engine()
    with engine.connect() as conn:
        result = conn.execute(text(f"SELECT name FROM {_TABLE} LIMIT 5"))
        names = result.scalars().all()
    return {"status": "fetch_scalars", "names": names}


def fetch_stream():
    """Stream results with yield_per for large datasets."""
    engine = _get_engine()
    with engine.connect() as conn:
        result = conn.execute(text(f"SELECT id, name, value FROM {_TABLE}"))
        batches = []
        for partition in result.partitions(2):
            batches.append([tuple(r) for r in partition])
    return {"status": "fetch_stream", "batch_count": len(batches)}


# ---------------------------------------------------------------------------
# ORM operations
# ---------------------------------------------------------------------------
def orm_create_table():
    """Create ORM-mapped table."""
    engine = _get_engine()
    Base.metadata.drop_all(engine, tables=[ComponentTest.__table__], checkfirst=True)
    Base.metadata.create_all(engine, tables=[ComponentTest.__table__])
    return {"status": "orm_table_created"}


def orm_insert():
    """ORM - insert rows via session."""
    engine = _get_engine()
    with Session(engine) as session:
        session.add(ComponentTest(name="orm_item_1", value=10))
        session.add(ComponentTest(name="orm_item_2", value=20))
        session.commit()
    return {"status": "orm_inserted"}


def orm_select():
    """ORM - query rows."""
    engine = _get_engine()
    with Session(engine) as session:
        rows = session.execute(
            select(ComponentTest).where(ComponentTest.value > 0)
        ).scalars().all()
    return {"status": "orm_selected", "rows": [{"name": r.name, "value": r.value} for r in rows]}


def orm_update():
    """ORM - update a row."""
    engine = _get_engine()
    with Session(engine) as session:
        obj = session.execute(
            select(ComponentTest).where(ComponentTest.name == "orm_item_1")
        ).scalars().first()
        if obj:
            obj.value = 999
            session.commit()
    return {"status": "orm_updated"}


def orm_delete():
    """ORM - delete a row."""
    engine = _get_engine()
    with Session(engine) as session:
        obj = session.execute(
            select(ComponentTest).where(ComponentTest.name == "orm_item_1")
        ).scalars().first()
        if obj:
            session.delete(obj)
            session.commit()
    return {"status": "orm_deleted"}


# ---------------------------------------------------------------------------
# Advanced / unique cases
# ---------------------------------------------------------------------------
def reflect_table():
    """Reflect (autoload) an existing table from the database."""
    engine = _get_engine()
    meta = MetaData()
    meta.reflect(bind=engine, only=[_TABLE])
    table_names = list(meta.tables.keys())
    cols = [c.name for c in meta.tables[_TABLE].columns] if _TABLE in meta.tables else []
    return {"status": "reflected", "tables": table_names, "columns": cols}


def event_hook():
    """Attach before_execute event hook to engine."""
    engine = _get_engine()
    log = []

    @event.listens_for(engine, "before_cursor_execute")
    def before_cursor_execute(conn, cursor, statement, parameters, context, executemany):
        log.append(statement[:80])

    with engine.connect() as conn:
        conn.execute(text("SELECT 1"))
        conn.execute(text("SELECT 2"))

    event.remove(engine, "before_cursor_execute", before_cursor_execute)
    return {"status": "event_hook_ok", "captured": log}


def insert_on_duplicate():
    """MySQL-specific INSERT ... ON DUPLICATE KEY UPDATE."""
    from sqlalchemy.dialects.mysql import insert as mysql_insert
    engine = _get_engine()
    with engine.connect() as conn:
        stmt = mysql_insert(_component_table).values(name="dup_item", value=1)
        stmt = stmt.on_duplicate_key_update(value=stmt.inserted.value + 1)
        conn.execute(stmt)
        conn.commit()
    return {"status": "on_duplicate_ok"}


def dynamic_query(table_name=_TABLE, columns=None, where_clause=None):
    """Build and execute a query dynamically."""
    engine = _get_engine()
    cols = ", ".join(columns) if columns else "*"
    query = f"SELECT {cols} FROM `{table_name}`"
    params = {}
    if where_clause:
        query += " WHERE " + where_clause["condition"]
        if where_clause.get("params"):
            params = dict(zip(
                [f"p{i}" for i in range(len(where_clause["params"]))],
                where_clause["params"],
            ))
    with engine.connect() as conn:
        result = conn.execute(text(query), params)
        rows = [tuple(r) for r in result.fetchall()]
    return {"status": "dynamic_query_ok", "rows": rows}


def delayed_insert():
    """Insert after a server-side delay."""
    engine = _get_engine()
    with engine.connect() as conn:
        conn.execute(text("SELECT SLEEP(1)"))
        result = conn.execute(
            text(f"INSERT INTO {_TABLE} (name, value) VALUES (:n, :v)"),
            {"n": "delayed_item", "v": 555},
        )
        conn.commit()
    return {"status": "delayed_insert_ok", "lastrowid": result.lastrowid}


def race_condition_test():
    """Simulate a race condition with two separate connections."""
    engine = _get_engine()
    conn1 = engine.connect()
    conn2 = engine.connect()
    try:
        with conn1.begin():
            conn1.execute(
                text(f"INSERT INTO {_TABLE} (name, value) VALUES (:n, :v)"),
                {"n": "race_item", "v": 0},
            )

        with conn1.begin():
            row = conn1.execute(
                text(f"SELECT value FROM {_TABLE} WHERE name = 'race_item' FOR UPDATE")
            ).fetchone()
            conn1.execute(
                text(f"UPDATE {_TABLE} SET value = :v WHERE name = 'race_item'"),
                {"v": row[0] + 1},
            )

        with conn2.begin():
            row2 = conn2.execute(
                text(f"SELECT value FROM {_TABLE} WHERE name = 'race_item' FOR UPDATE")
            ).fetchone()
            conn2.execute(
                text(f"UPDATE {_TABLE} SET value = :v WHERE name = 'race_item'"),
                {"v": row2[0] + 1},
            )

        result = conn1.execute(
            text(f"SELECT value FROM {_TABLE} WHERE name = 'race_item'")
        ).fetchone()
        return {"status": "race_test_ok", "final_value": result[0]}
    finally:
        conn1.close()
        conn2.close()


# ---------------------------------------------------------------------------
# Global route-to-function mapping
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/db/mysql/sqlalchemy/connect": connect,
    "/db/mysql/sqlalchemy/connect_pool": connect_pool,
    "/db/mysql/sqlalchemy/connect_nullpool": connect_nullpool,
    "/db/mysql/sqlalchemy/connect_error_wrong_password": connect_error_wrong_password,
    "/db/mysql/sqlalchemy/connect_error_wrong_host": connect_error_wrong_host,
    "/db/mysql/sqlalchemy/connect_error_unknown_db": connect_error_unknown_db,
    "/db/mysql/sqlalchemy/connect_error_timeout": connect_error_timeout,
    "/db/mysql/sqlalchemy/pool_error_overflow": pool_error_overflow,
    "/db/mysql/sqlalchemy/execute_raw_create_table": execute_raw_create_table,
    "/db/mysql/sqlalchemy/execute_raw_insert": execute_raw_insert,
    "/db/mysql/sqlalchemy/execute_raw_insert_params": execute_raw_insert_params,
    "/db/mysql/sqlalchemy/execute_raw_select": execute_raw_select,
    "/db/mysql/sqlalchemy/execute_raw_update": execute_raw_update,
    "/db/mysql/sqlalchemy/execute_raw_delete": execute_raw_delete,
    "/db/mysql/sqlalchemy/execute_core_insert": execute_core_insert,
    "/db/mysql/sqlalchemy/execute_core_insert_many": execute_core_insert_many,
    "/db/mysql/sqlalchemy/execute_core_select": execute_core_select,
    "/db/mysql/sqlalchemy/execute_core_update": execute_core_update,
    "/db/mysql/sqlalchemy/execute_core_delete": execute_core_delete,
    "/db/mysql/sqlalchemy/execute_transaction": execute_transaction,
    "/db/mysql/sqlalchemy/execute_savepoint": execute_savepoint,
    "/db/mysql/sqlalchemy/fetch_one": fetch_one,
    "/db/mysql/sqlalchemy/fetch_all": fetch_all,
    "/db/mysql/sqlalchemy/fetch_many": fetch_many,
    "/db/mysql/sqlalchemy/fetch_mappings": fetch_mappings,
    "/db/mysql/sqlalchemy/fetch_scalars": fetch_scalars,
    "/db/mysql/sqlalchemy/fetch_stream": fetch_stream,
    "/db/mysql/sqlalchemy/orm_create_table": orm_create_table,
    "/db/mysql/sqlalchemy/orm_insert": orm_insert,
    "/db/mysql/sqlalchemy/orm_select": orm_select,
    "/db/mysql/sqlalchemy/orm_update": orm_update,
    "/db/mysql/sqlalchemy/orm_delete": orm_delete,
    "/db/mysql/sqlalchemy/reflect_table": reflect_table,
    "/db/mysql/sqlalchemy/event_hook": event_hook,
    "/db/mysql/sqlalchemy/insert_on_duplicate": insert_on_duplicate,
    "/db/mysql/sqlalchemy/dynamic_query": dynamic_query,
    "/db/mysql/sqlalchemy/delayed_insert": delayed_insert,
    "/db/mysql/sqlalchemy/race_condition_test": race_condition_test,
}
