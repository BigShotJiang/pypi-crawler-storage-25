"""
Redis Cache Component - aioredis / redis.asyncio module (async)
Covers: async connection, pool, errors, KV ops, TTL, bulk, counters, data types,
        serialization, key management, pipeline, pub/sub, flush
"""

import asyncio
import json
import time
import redis.asyncio as aioredis
import redis as sync_redis
from apm_component.config import get_redis_config


_PREFIX = "ct_aioredis:"


def _get_config():
    return get_redis_config()


async def _get_client():
    cfg = _get_config()
    return aioredis.Redis(
        host=cfg["host"],
        port=cfg["port"],
        db=cfg["db"],
        password=cfg["password"],
        socket_timeout=cfg["socket_timeout"],
        decode_responses=True,
    )


async def _cleanup(r, pattern=None):
    pat = pattern or f"{_PREFIX}*"
    keys = await r.keys(pat)
    if keys:
        await r.delete(*keys)


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------
async def _connect():
    r = await _get_client()
    try:
        pong = await r.ping()
        return {"status": "connected", "ping": pong}
    finally:
        await r.close()


def connect():
    return asyncio.run(_connect())


async def _connect_url():
    cfg = _get_config()
    pwd_part = f":{cfg['password']}@" if cfg["password"] else ""
    url = f"redis://{pwd_part}{cfg['host']}:{cfg['port']}/{cfg['db']}"
    r = aioredis.from_url(url, decode_responses=True)
    try:
        pong = await r.ping()
        return {"status": "connected_url", "ping": pong}
    finally:
        await r.close()


def connect_url():
    return asyncio.run(_connect_url())


# ---------------------------------------------------------------------------
# Connection pooling
# ---------------------------------------------------------------------------
async def _connect_pool():
    cfg = _get_config()
    pool = aioredis.ConnectionPool(
        host=cfg["host"],
        port=cfg["port"],
        db=cfg["db"],
        password=cfg["password"],
        max_connections=cfg["pool_size"],
        decode_responses=True,
    )
    r = aioredis.Redis(connection_pool=pool)
    try:
        pong = await r.ping()
        return {"status": "pool_connected", "ping": pong}
    finally:
        await r.close()
        await pool.disconnect()


def connect_pool():
    return asyncio.run(_connect_pool())


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
async def _connect_error_wrong_host():
    try:
        r = aioredis.Redis(host="192.0.2.1", port=6379, socket_timeout=2, socket_connect_timeout=2)
        await r.ping()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def connect_error_wrong_host():
    return asyncio.run(_connect_error_wrong_host())


async def _connect_error_wrong_port():
    try:
        r = aioredis.Redis(host="127.0.0.1", port=59999, socket_timeout=2, socket_connect_timeout=2)
        await r.ping()
        return {"status": "unexpected_success"}
    except sync_redis.ConnectionError as e:
        return {"status": "error", "msg": str(e)}


def connect_error_wrong_port():
    return asyncio.run(_connect_error_wrong_port())


async def _connect_error_timeout():
    try:
        r = aioredis.Redis(host="192.0.2.1", port=6379, socket_timeout=1, socket_connect_timeout=1)
        await r.ping()
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)}


def connect_error_timeout():
    return asyncio.run(_connect_error_timeout())


# ---------------------------------------------------------------------------
# Key-Value operations
# ---------------------------------------------------------------------------
async def _set_get():
    r = await _get_client()
    try:
        await r.set(f"{_PREFIX}key1", "hello_async")
        val = await r.get(f"{_PREFIX}key1")
        return {"status": "success", "value": val}
    finally:
        await _cleanup(r)
        await r.close()


def set_get():
    return asyncio.run(_set_get())


async def _delete_key():
    r = await _get_client()
    try:
        await r.set(f"{_PREFIX}del_key", "to_delete")
        deleted = await r.delete(f"{_PREFIX}del_key")
        val = await r.get(f"{_PREFIX}del_key")
        return {"status": "success", "deleted": deleted, "value_after": val}
    finally:
        await _cleanup(r)
        await r.close()


def delete_key():
    return asyncio.run(_delete_key())


async def _setnx():
    r = await _get_client()
    try:
        await r.delete(f"{_PREFIX}nx_key")
        first = await r.setnx(f"{_PREFIX}nx_key", "first")
        second = await r.setnx(f"{_PREFIX}nx_key", "second")
        val = await r.get(f"{_PREFIX}nx_key")
        return {"status": "success", "first_set": first, "second_set": second, "value": val}
    finally:
        await _cleanup(r)
        await r.close()


def setnx():
    return asyncio.run(_setnx())


# ---------------------------------------------------------------------------
# Bulk operations
# ---------------------------------------------------------------------------
async def _mset_mget():
    r = await _get_client()
    try:
        data = {f"{_PREFIX}m1": "a", f"{_PREFIX}m2": "b", f"{_PREFIX}m3": "c"}
        await r.mset(data)
        vals = await r.mget(list(data.keys()))
        return {"status": "success", "values": vals}
    finally:
        await _cleanup(r)
        await r.close()


def mset_mget():
    return asyncio.run(_mset_mget())


# ---------------------------------------------------------------------------
# Counters
# ---------------------------------------------------------------------------
async def _incr_decr():
    r = await _get_client()
    try:
        await r.set(f"{_PREFIX}counter", 10)
        await r.incr(f"{_PREFIX}counter")
        await r.incrby(f"{_PREFIX}counter", 5)
        await r.decr(f"{_PREFIX}counter")
        await r.decrby(f"{_PREFIX}counter", 3)
        val = int(await r.get(f"{_PREFIX}counter"))
        return {"status": "success", "value": val}
    finally:
        await _cleanup(r)
        await r.close()


def incr_decr():
    return asyncio.run(_incr_decr())


# ---------------------------------------------------------------------------
# Expiration / TTL
# ---------------------------------------------------------------------------
async def _set_with_ttl():
    r = await _get_client()
    try:
        await r.set(f"{_PREFIX}ttl_key", "expires_soon", ex=10)
        ttl = await r.ttl(f"{_PREFIX}ttl_key")
        return {"status": "success", "ttl": ttl}
    finally:
        await _cleanup(r)
        await r.close()


def set_with_ttl():
    return asyncio.run(_set_with_ttl())


async def _expire_and_persist():
    r = await _get_client()
    try:
        await r.set(f"{_PREFIX}ep_key", "value")
        await r.expire(f"{_PREFIX}ep_key", 60)
        ttl_before = await r.ttl(f"{_PREFIX}ep_key")
        await r.persist(f"{_PREFIX}ep_key")
        ttl_after = await r.ttl(f"{_PREFIX}ep_key")
        return {"status": "success", "ttl_before": ttl_before, "ttl_after": ttl_after}
    finally:
        await _cleanup(r)
        await r.close()


def expire_and_persist():
    return asyncio.run(_expire_and_persist())


async def _ttl_expiry_check():
    r = await _get_client()
    try:
        await r.set(f"{_PREFIX}exp_key", "vanish", ex=1)
        val_before = await r.get(f"{_PREFIX}exp_key")
        await asyncio.sleep(1.5)
        val_after = await r.get(f"{_PREFIX}exp_key")
        return {"status": "success", "before": val_before, "after": val_after}
    finally:
        await _cleanup(r)
        await r.close()


def ttl_expiry_check():
    return asyncio.run(_ttl_expiry_check())


# ---------------------------------------------------------------------------
# Key existence
# ---------------------------------------------------------------------------
async def _key_exists():
    r = await _get_client()
    try:
        await r.set(f"{_PREFIX}ex_key", "yes")
        exists = await r.exists(f"{_PREFIX}ex_key")
        await r.delete(f"{_PREFIX}ex_key")
        not_exists = await r.exists(f"{_PREFIX}ex_key")
        return {"status": "success", "exists": exists, "not_exists": not_exists}
    finally:
        await _cleanup(r)
        await r.close()


def key_exists():
    return asyncio.run(_key_exists())


# ---------------------------------------------------------------------------
# Data types — Hashes
# ---------------------------------------------------------------------------
async def _hash_operations():
    r = await _get_client()
    key = f"{_PREFIX}hash1"
    try:
        await r.hset(key, "field1", "val1")
        await r.hset(key, mapping={"field2": "val2", "field3": "val3"})
        val = await r.hget(key, "field1")
        all_vals = await r.hgetall(key)
        await r.hdel(key, "field3")
        remaining = await r.hgetall(key)
        return {"status": "success", "single": val, "all": all_vals, "after_del": remaining}
    finally:
        await _cleanup(r)
        await r.close()


def hash_operations():
    return asyncio.run(_hash_operations())


# ---------------------------------------------------------------------------
# Data types — Lists
# ---------------------------------------------------------------------------
async def _list_operations():
    r = await _get_client()
    key = f"{_PREFIX}list1"
    try:
        await r.lpush(key, "c", "b", "a")
        await r.rpush(key, "d")
        length = await r.llen(key)
        items = await r.lrange(key, 0, -1)
        left = await r.lpop(key)
        right = await r.rpop(key)
        return {"status": "success", "length": length, "items": items, "lpop": left, "rpop": right}
    finally:
        await _cleanup(r)
        await r.close()


def list_operations():
    return asyncio.run(_list_operations())


# ---------------------------------------------------------------------------
# Data types — Sets
# ---------------------------------------------------------------------------
async def _set_operations():
    r = await _get_client()
    key = f"{_PREFIX}set1"
    try:
        await r.sadd(key, "a", "b", "c", "d")
        members = await r.smembers(key)
        is_member = await r.sismember(key, "b")
        await r.srem(key, "d")
        card = await r.scard(key)
        return {"status": "success", "members": sorted(list(members)), "is_member": is_member, "cardinality": card}
    finally:
        await _cleanup(r)
        await r.close()


def set_operations():
    return asyncio.run(_set_operations())


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------
async def _json_serialization():
    r = await _get_client()
    key = f"{_PREFIX}json_key"
    try:
        data = {"name": "test", "values": [1, 2, 3], "nested": {"a": True}}
        await r.set(key, json.dumps(data))
        raw = await r.get(key)
        parsed = json.loads(raw)
        return {"status": "success", "data": parsed}
    finally:
        await _cleanup(r)
        await r.close()


def json_serialization():
    return asyncio.run(_json_serialization())


# ---------------------------------------------------------------------------
# Flush
# ---------------------------------------------------------------------------
async def _flush_db():
    r = await _get_client()
    try:
        await r.set(f"{_PREFIX}flush_1", "a")
        await r.set(f"{_PREFIX}flush_2", "b")
        await r.flushdb()
        remaining = await r.dbsize()
        return {"status": "success", "remaining_keys": remaining}
    finally:
        await r.close()


def flush_db():
    return asyncio.run(_flush_db())


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------
async def _pipeline_operations():
    r = await _get_client()
    try:
        pipe = r.pipeline(transaction=False)
        pipe.set(f"{_PREFIX}pipe1", "a")
        pipe.set(f"{_PREFIX}pipe2", "b")
        pipe.get(f"{_PREFIX}pipe1")
        pipe.get(f"{_PREFIX}pipe2")
        results = await pipe.execute()
        return {"status": "success", "results": results}
    finally:
        await _cleanup(r)
        await r.close()


def pipeline_operations():
    return asyncio.run(_pipeline_operations())


# ---------------------------------------------------------------------------
# Pub/Sub
# ---------------------------------------------------------------------------
async def _pubsub_operations():
    r = await _get_client()
    channel = f"{_PREFIX}channel"
    try:
        ps = r.pubsub()
        await ps.subscribe(channel)
        await ps.get_message(timeout=1)

        await r.publish(channel, "hello_async_pubsub")
        received = await ps.get_message(timeout=2)

        await ps.unsubscribe(channel)
        await ps.close()
        data = received["data"] if received else None
        return {"status": "success", "message": data}
    finally:
        await r.close()


def pubsub_operations():
    return asyncio.run(_pubsub_operations())


# ---------------------------------------------------------------------------
# Concurrent operations
# ---------------------------------------------------------------------------
async def _concurrent_operations():
    r = await _get_client()
    try:
        keys = [f"{_PREFIX}conc_{i}" for i in range(5)]

        async def set_key(k, v):
            await r.set(k, v)

        await asyncio.gather(*[set_key(k, f"val_{i}") for i, k in enumerate(keys)])
        vals = await r.mget(keys)
        return {"status": "success", "values": vals}
    finally:
        await _cleanup(r)
        await r.close()


def concurrent_operations():
    return asyncio.run(_concurrent_operations())


# ---------------------------------------------------------------------------
# Dynamic / Delay / Race
# ---------------------------------------------------------------------------
async def _dynamic_key_ops():
    r = await _get_client()
    try:
        keys = {f"{_PREFIX}dyn_{i}": f"val_{i}" for i in range(5)}
        await r.mset(keys)
        found = await r.keys(f"{_PREFIX}dyn_*")
        vals = await r.mget(found)
        return {"status": "success", "key_count": len(found), "values": vals}
    finally:
        await _cleanup(r)
        await r.close()


def dynamic_key_ops():
    return asyncio.run(_dynamic_key_ops())


async def _delayed_operations():
    r = await _get_client()
    key = f"{_PREFIX}delay_key"
    try:
        await r.set(key, "initial")
        await asyncio.sleep(0.5)
        await r.set(key, "updated")
        val = await r.get(key)
        return {"status": "success", "value": val}
    finally:
        await _cleanup(r)
        await r.close()


def delayed_operations():
    return asyncio.run(_delayed_operations())


async def _race_condition_test():
    cfg = _get_config()
    r1 = aioredis.Redis(host=cfg["host"], port=cfg["port"], db=cfg["db"],
                        password=cfg["password"], decode_responses=True)
    r2 = aioredis.Redis(host=cfg["host"], port=cfg["port"], db=cfg["db"],
                        password=cfg["password"], decode_responses=True)
    key = f"{_PREFIX}race_key"
    try:
        await r1.set(key, "0")
        await r1.incr(key)
        await r2.incr(key)
        await r1.incr(key)
        final = int(await r1.get(key))
        return {"status": "success", "final_value": final}
    finally:
        await r1.delete(key)
        await r1.close()
        await r2.close()


def race_condition_test():
    return asyncio.run(_race_condition_test())


# ---------------------------------------------------------------------------
# Global route-to-function mapping
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/cache/redis/aioredis/connect": connect,
    "/cache/redis/aioredis/connect_url": connect_url,
    "/cache/redis/aioredis/connect_pool": connect_pool,
    "/cache/redis/aioredis/connect_error_wrong_host": connect_error_wrong_host,
    "/cache/redis/aioredis/connect_error_wrong_port": connect_error_wrong_port,
    "/cache/redis/aioredis/connect_error_timeout": connect_error_timeout,
    "/cache/redis/aioredis/set_get": set_get,
    "/cache/redis/aioredis/delete_key": delete_key,
    "/cache/redis/aioredis/setnx": setnx,
    "/cache/redis/aioredis/mset_mget": mset_mget,
    "/cache/redis/aioredis/incr_decr": incr_decr,
    "/cache/redis/aioredis/set_with_ttl": set_with_ttl,
    "/cache/redis/aioredis/expire_and_persist": expire_and_persist,
    "/cache/redis/aioredis/ttl_expiry_check": ttl_expiry_check,
    "/cache/redis/aioredis/key_exists": key_exists,
    "/cache/redis/aioredis/hash_operations": hash_operations,
    "/cache/redis/aioredis/list_operations": list_operations,
    "/cache/redis/aioredis/set_operations": set_operations,
    "/cache/redis/aioredis/json_serialization": json_serialization,
    "/cache/redis/aioredis/flush_db": flush_db,
    "/cache/redis/aioredis/pipeline_operations": pipeline_operations,
    "/cache/redis/aioredis/pubsub_operations": pubsub_operations,
    "/cache/redis/aioredis/concurrent_operations": concurrent_operations,
    "/cache/redis/aioredis/dynamic_key_ops": dynamic_key_ops,
    "/cache/redis/aioredis/delayed_operations": delayed_operations,
    "/cache/redis/aioredis/race_condition_test": race_condition_test,
}
