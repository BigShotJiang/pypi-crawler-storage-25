"""
Cassandra Datastore Component - cassandra-driver module
Covers: connection, error handling, CRUD, batch, prepared statements,
        TTL, pagination, schema management, data types, unique cases
"""

import time
import uuid
from cassandra.cluster import Cluster, NoHostAvailable
from cassandra.auth import PlainTextAuthProvider
from cassandra.query import SimpleStatement, BatchStatement, BatchType, ConsistencyLevel
from apm_component.config import get_cassandra_config


_KEYSPACE = None
_TABLE = "ct_cassandra"


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------
def _get_config():
    return get_cassandra_config()


def _get_cluster(**overrides):
    cfg = _get_config()
    params = {
        "contact_points": [cfg["host"]],
        "port": cfg["port"],
        "connect_timeout": cfg["connect_timeout"],
    }
    params.update(overrides)
    return Cluster(**params)


def _get_session():
    cfg = _get_config()
    cluster = _get_cluster()
    session = cluster.connect()
    session.execute(
        f"CREATE KEYSPACE IF NOT EXISTS {cfg['keyspace']} "
        "WITH replication = {'class': 'SimpleStrategy', 'replication_factor': 1}"
    )
    session.set_keyspace(cfg["keyspace"])
    return session, cluster


def _ensure_table(session):
    session.execute(f"""
        CREATE TABLE IF NOT EXISTS {_TABLE} (
            id uuid PRIMARY KEY,
            name text,
            value int,
            tags list<text>,
            metadata map<text, text>,
            created_at timestamp
        )
    """)


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------
def connect():
    """Basic connection to Cassandra."""
    session, cluster = _get_session()
    try:
        row = session.execute("SELECT release_version FROM system.local").one()
        return {"status": "connected", "version": row.release_version}
    finally:
        cluster.shutdown()


def connect_keyspace():
    """Connect to a specific keyspace."""
    cfg = _get_config()
    cluster = _get_cluster()
    try:
        session = cluster.connect()
        session.execute(
            f"CREATE KEYSPACE IF NOT EXISTS {cfg['keyspace']} "
            "WITH replication = {'class': 'SimpleStrategy', 'replication_factor': 1}"
        )
        session.set_keyspace(cfg["keyspace"])
        return {"status": "connected_keyspace", "keyspace": cfg["keyspace"]}
    finally:
        cluster.shutdown()


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
def connect_error_wrong_host():
    """Attempt connection to unreachable host."""
    try:
        cluster = Cluster(contact_points=["192.0.2.1"], connect_timeout=3)
        cluster.connect()
        cluster.shutdown()
        return {"status": "unexpected_success"}
    except NoHostAvailable as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_wrong_port():
    """Attempt connection to wrong port."""
    try:
        cluster = Cluster(contact_points=[_get_config()["host"]], port=59999, connect_timeout=3)
        cluster.connect()
        cluster.shutdown()
        return {"status": "unexpected_success"}
    except NoHostAvailable as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_timeout():
    """Attempt connection with very short timeout."""
    try:
        cluster = Cluster(contact_points=["192.0.2.1"], connect_timeout=1)
        cluster.connect()
        cluster.shutdown()
        return {"status": "unexpected_success"}
    except NoHostAvailable as e:
        return {"status": "error", "msg": str(e)[:200]}


def connect_error_wrong_auth():
    """Attempt connection with wrong credentials (if auth enabled)."""
    try:
        auth = PlainTextAuthProvider(username="wrong_user", password="wrong_pass")
        cluster = Cluster(
            contact_points=[_get_config()["host"]],
            port=_get_config()["port"],
            auth_provider=auth,
            connect_timeout=5,
        )
        cluster.connect()
        cluster.shutdown()
        return {"status": "unexpected_success"}
    except (NoHostAvailable, Exception) as e:
        return {"status": "error", "msg": str(e)[:200]}


# ---------------------------------------------------------------------------
# Schema management
# ---------------------------------------------------------------------------
def create_keyspace():
    """Create a keyspace."""
    cfg = _get_config()
    cluster = _get_cluster()
    try:
        session = cluster.connect()
        session.execute(
            f"CREATE KEYSPACE IF NOT EXISTS {cfg['keyspace']} "
            "WITH replication = {'class': 'SimpleStrategy', 'replication_factor': 1}"
        )
        return {"status": "keyspace_created"}
    finally:
        cluster.shutdown()


def drop_keyspace():
    """Drop and recreate the test keyspace."""
    cfg = _get_config()
    cluster = _get_cluster()
    try:
        session = cluster.connect()
        session.execute(f"DROP KEYSPACE IF EXISTS {cfg['keyspace']}")
        session.execute(
            f"CREATE KEYSPACE IF NOT EXISTS {cfg['keyspace']} "
            "WITH replication = {'class': 'SimpleStrategy', 'replication_factor': 1}"
        )
        return {"status": "keyspace_dropped_and_recreated"}
    finally:
        cluster.shutdown()


def create_table():
    """Create the test table."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        return {"status": "table_created"}
    finally:
        cluster.shutdown()


def drop_table():
    """Drop the test table."""
    session, cluster = _get_session()
    try:
        session.execute(f"DROP TABLE IF EXISTS {_TABLE}")
        return {"status": "table_dropped"}
    finally:
        cluster.shutdown()


# ---------------------------------------------------------------------------
# Insert operations
# ---------------------------------------------------------------------------
def insert_one():
    """Insert a single record."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        row_id = uuid.uuid4()
        session.execute(
            f"INSERT INTO {_TABLE} (id, name, value, created_at) VALUES (%s, %s, %s, toTimestamp(now()))",
            (row_id, "test_item", 42),
        )
        return {"status": "inserted", "id": str(row_id)}
    finally:
        cluster.shutdown()


def insert_many():
    """Batch insert multiple records."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        batch = BatchStatement(batch_type=BatchType.UNLOGGED)
        ids = []
        for i in range(5):
            row_id = uuid.uuid4()
            ids.append(str(row_id))
            batch.add(
                SimpleStatement(
                    f"INSERT INTO {_TABLE} (id, name, value, created_at) VALUES (%s, %s, %s, toTimestamp(now()))"
                ),
                (row_id, f"batch_{i}", i * 10),
            )
        session.execute(batch)
        return {"status": "inserted_many", "count": len(ids), "ids": ids}
    finally:
        cluster.shutdown()


def insert_with_ttl():
    """Insert a record with TTL."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        row_id = uuid.uuid4()
        session.execute(
            f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s) USING TTL 60",
            (row_id, "ttl_item", 100),
        )
        return {"status": "inserted_with_ttl", "id": str(row_id)}
    finally:
        cluster.shutdown()


def insert_if_not_exists():
    """Lightweight transaction: INSERT IF NOT EXISTS."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        row_id = uuid.uuid4()
        result = session.execute(
            f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s) IF NOT EXISTS",
            (row_id, "unique_item", 1),
        )
        applied = result.one().applied
        return {"status": "insert_if_not_exists", "applied": applied, "id": str(row_id)}
    finally:
        cluster.shutdown()


# ---------------------------------------------------------------------------
# Read operations
# ---------------------------------------------------------------------------
def find_one():
    """Find a single record by ID."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        row_id = uuid.uuid4()
        session.execute(
            f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s)",
            (row_id, "find_me", 77),
        )
        row = session.execute(
            f"SELECT id, name, value FROM {_TABLE} WHERE id = %s", (row_id,)
        ).one()
        return {"status": "found", "id": str(row.id), "name": row.name, "value": row.value}
    finally:
        cluster.shutdown()


def find_all():
    """Find all records (full table scan)."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        rows = session.execute(f"SELECT id, name, value FROM {_TABLE}")
        results = [{"id": str(r.id), "name": r.name, "value": r.value} for r in rows]
        return {"status": "found_all", "count": len(results)}
    finally:
        cluster.shutdown()


def find_with_filter():
    """Query with ALLOW FILTERING."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        session.execute(f"TRUNCATE {_TABLE}")
        for i in range(3):
            session.execute(
                f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s)",
                (uuid.uuid4(), "filter_item", (i + 1) * 10),
            )
        rows = session.execute(
            f"SELECT id, name, value FROM {_TABLE} WHERE name = %s ALLOW FILTERING",
            ("filter_item",),
        )
        results = [{"name": r.name, "value": r.value} for r in rows]
        return {"status": "filtered", "count": len(results)}
    finally:
        cluster.shutdown()


def find_with_pagination():
    """Paginated query using fetch_size."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        session.execute(f"TRUNCATE {_TABLE}")
        for i in range(10):
            session.execute(
                f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s)",
                (uuid.uuid4(), f"page_{i}", i),
            )
        stmt = SimpleStatement(f"SELECT id, name FROM {_TABLE}", fetch_size=3)
        result = session.execute(stmt)
        pages = 0
        total = 0
        while True:
            page_rows = result.current_rows
            total += len(page_rows)
            pages += 1
            if result.has_more_pages:
                result.fetch_next_page()
            else:
                break
        return {"status": "paginated", "pages": pages, "total_rows": total}
    finally:
        cluster.shutdown()


# ---------------------------------------------------------------------------
# Update operations
# ---------------------------------------------------------------------------
def update_one():
    """Update a single record."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        row_id = uuid.uuid4()
        session.execute(
            f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s)",
            (row_id, "update_me", 1),
        )
        session.execute(
            f"UPDATE {_TABLE} SET value = %s WHERE id = %s",
            (999, row_id),
        )
        row = session.execute(
            f"SELECT value FROM {_TABLE} WHERE id = %s", (row_id,)
        ).one()
        return {"status": "updated", "value": row.value}
    finally:
        cluster.shutdown()


def update_with_condition():
    """Lightweight transaction: UPDATE IF value = X."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        row_id = uuid.uuid4()
        session.execute(
            f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s)",
            (row_id, "conditional", 10),
        )
        result = session.execute(
            f"UPDATE {_TABLE} SET value = %s WHERE id = %s IF value = %s",
            (20, row_id, 10),
        )
        applied = result.one().applied
        return {"status": "conditional_update", "applied": applied}
    finally:
        cluster.shutdown()


# ---------------------------------------------------------------------------
# Delete operations
# ---------------------------------------------------------------------------
def delete_one():
    """Delete a single record."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        row_id = uuid.uuid4()
        session.execute(
            f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s)",
            (row_id, "delete_me", 1),
        )
        session.execute(f"DELETE FROM {_TABLE} WHERE id = %s", (row_id,))
        row = session.execute(
            f"SELECT id FROM {_TABLE} WHERE id = %s", (row_id,)
        ).one()
        return {"status": "deleted", "exists_after": row is not None}
    finally:
        cluster.shutdown()


def delete_many():
    """Batch delete multiple records."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        ids = []
        for i in range(3):
            row_id = uuid.uuid4()
            ids.append(row_id)
            session.execute(
                f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s)",
                (row_id, f"del_batch_{i}", i),
            )
        batch = BatchStatement()
        for row_id in ids:
            batch.add(SimpleStatement(f"DELETE FROM {_TABLE} WHERE id = %s"), (row_id,))
        session.execute(batch)
        return {"status": "deleted_many", "count": len(ids)}
    finally:
        cluster.shutdown()


def truncate_table():
    """Truncate the test table."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        session.execute(f"TRUNCATE {_TABLE}")
        return {"status": "truncated"}
    finally:
        cluster.shutdown()


# ---------------------------------------------------------------------------
# Prepared statements
# ---------------------------------------------------------------------------
def prepared_insert():
    """Insert using a prepared statement."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        prepared = session.prepare(
            f"INSERT INTO {_TABLE} (id, name, value) VALUES (?, ?, ?)"
        )
        row_id = uuid.uuid4()
        session.execute(prepared, (row_id, "prepared_item", 55))
        row = session.execute(
            f"SELECT name, value FROM {_TABLE} WHERE id = %s", (row_id,)
        ).one()
        return {"status": "prepared_insert_ok", "name": row.name, "value": row.value}
    finally:
        cluster.shutdown()


def prepared_select():
    """Select using a prepared statement."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        row_id = uuid.uuid4()
        session.execute(
            f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s)",
            (row_id, "prep_select", 66),
        )
        prepared = session.prepare(
            f"SELECT id, name, value FROM {_TABLE} WHERE id = ?"
        )
        row = session.execute(prepared, (row_id,)).one()
        return {"status": "prepared_select_ok", "name": row.name}
    finally:
        cluster.shutdown()


# ---------------------------------------------------------------------------
# Data types / serialization
# ---------------------------------------------------------------------------
def insert_collection_types():
    """Insert records with list, map collection types."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        row_id = uuid.uuid4()
        session.execute(
            f"INSERT INTO {_TABLE} (id, name, tags, metadata) VALUES (%s, %s, %s, %s)",
            (row_id, "collection_item", ["tag1", "tag2", "tag3"], {"key1": "val1", "key2": "val2"}),
        )
        row = session.execute(
            f"SELECT tags, metadata FROM {_TABLE} WHERE id = %s", (row_id,)
        ).one()
        return {
            "status": "collection_types_ok",
            "tags": list(row.tags),
            "metadata": dict(row.metadata),
        }
    finally:
        cluster.shutdown()


def insert_various_data_types():
    """Verify storing different data types."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        row_id = uuid.uuid4()
        session.execute(
            f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s)",
            (row_id, "type_test", 2147483647),
        )
        row = session.execute(
            f"SELECT name, value FROM {_TABLE} WHERE id = %s", (row_id,)
        ).one()
        return {"status": "data_types_ok", "name": row.name, "value": row.value}
    finally:
        cluster.shutdown()


# ---------------------------------------------------------------------------
# Error scenarios
# ---------------------------------------------------------------------------
def error_query_syntax():
    """Execute a malformed CQL query."""
    session, cluster = _get_session()
    try:
        session.execute("SELEC * FORM nonexistent")
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)[:200]}
    finally:
        cluster.shutdown()


def error_table_not_found():
    """Query a non-existent table."""
    session, cluster = _get_session()
    try:
        session.execute("SELECT * FROM nonexistent_table_xyz")
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "error", "msg": str(e)[:200]}
    finally:
        cluster.shutdown()


# ---------------------------------------------------------------------------
# Unique / advanced cases
# ---------------------------------------------------------------------------
def async_execute():
    """Execute a query asynchronously using execute_async."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        row_id = uuid.uuid4()
        future = session.execute_async(
            f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s)",
            (row_id, "async_item", 88),
        )
        future.result()  # block until done
        row = session.execute(
            f"SELECT name FROM {_TABLE} WHERE id = %s", (row_id,)
        ).one()
        return {"status": "async_ok", "name": row.name}
    finally:
        cluster.shutdown()


def consistency_level_query():
    """Execute with explicit consistency level."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        stmt = SimpleStatement(
            f"SELECT * FROM {_TABLE} LIMIT 1",
            consistency_level=ConsistencyLevel.ONE,
        )
        result = session.execute(stmt)
        return {"status": "consistency_ok", "rows": len(list(result))}
    finally:
        cluster.shutdown()


def delayed_insert():
    """Insert after a deliberate delay."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        time.sleep(1)
        row_id = uuid.uuid4()
        session.execute(
            f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s)",
            (row_id, "delayed_item", 555),
        )
        return {"status": "delayed_insert_ok", "id": str(row_id)}
    finally:
        cluster.shutdown()


def race_condition_test():
    """Simulate concurrent inserts with lightweight transactions."""
    session, cluster = _get_session()
    try:
        _ensure_table(session)
        row_id = uuid.uuid4()
        r1 = session.execute(
            f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s) IF NOT EXISTS",
            (row_id, "race_item", 1),
        )
        r2 = session.execute(
            f"INSERT INTO {_TABLE} (id, name, value) VALUES (%s, %s, %s) IF NOT EXISTS",
            (row_id, "race_item_dup", 2),
        )
        return {
            "status": "race_test_ok",
            "first_applied": r1.one().applied,
            "second_applied": r2.one().applied,
        }
    finally:
        cluster.shutdown()
