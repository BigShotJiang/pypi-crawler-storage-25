"""
HTTP Component - http.client (stdlib)
Covers: GET/POST/PUT/DELETE/PATCH, headers, auth, connection reuse,
        timeouts, errors, response types, SSL, redirects, streaming
"""

import base64
import http.client
import json
import socket
import ssl
from urllib.parse import urlencode, urlparse

from apm_component.config import get_http_config
from apm_component.http_urls import (
    GET_URL, GET_PARAMS,
    POST_URL, POST_JSON_BODY, POST_FORM_DATA,
    PUT_URL, PUT_JSON_BODY, DELETE_URL, PATCH_URL, PATCH_JSON_BODY,
    HEADERS_URL, CUSTOM_HEADERS,
    BEARER_AUTH_URL, BEARER_TOKEN, BASIC_AUTH_URL, BASIC_AUTH_USER, BASIC_AUTH_PASS,
    TEXT_RESPONSE_URL, BINARY_RESPONSE_URL,
    HTML_RESPONSE_URL, XML_RESPONSE_URL, STREAM_RESPONSE_URL,
    RESPONSE_HEADERS_URL, RESPONSE_HEADERS_PARAMS,
    STATUS_CODE_URL, TIMEOUT_URL, DELAY_URL, CONNECTION_ERROR_URL,
    REDIRECT_URL,
    SSL_VALID_URL, SSL_SELF_SIGNED_URL,
)


def _get_config():
    return get_http_config()


def _parse_url(url):
    parsed = urlparse(url)
    host = parsed.hostname
    port = parsed.port
    path = parsed.path or "/"
    if parsed.query:
        path = f"{path}?{parsed.query}"
    is_https = parsed.scheme == "https"
    if port:
        host = f"{host}:{port}"
    return host, path, is_https


def _make_connection(host, is_https=True, timeout=10, context=None):
    if is_https:
        return http.client.HTTPSConnection(host, timeout=timeout, context=context)
    return http.client.HTTPConnection(host, timeout=timeout)


# ---------------------------------------------------------------------------
# Basic HTTP methods
# ---------------------------------------------------------------------------
def http_get():
    cfg = _get_config()
    host, path, is_https = _parse_url(GET_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        body = json.loads(resp.read().decode())
        return {"status": "success", "status_code": resp.status, "data": body}
    finally:
        conn.close()


def http_get_with_params():
    cfg = _get_config()
    host, path, is_https = _parse_url(GET_URL)
    path = f"{path}?{urlencode(GET_PARAMS)}"
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        body = json.loads(resp.read().decode())
        return {"status": "success", "status_code": resp.status, "args": body.get("args")}
    finally:
        conn.close()


def http_post_json():
    cfg = _get_config()
    host, path, is_https = _parse_url(POST_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        headers = {"Content-Type": "application/json"}
        conn.request("POST", path, body=json.dumps(POST_JSON_BODY), headers=headers)
        resp = conn.getresponse()
        body = json.loads(resp.read().decode())
        return {"status": "success", "status_code": resp.status, "data": body}
    finally:
        conn.close()


def http_post_form():
    cfg = _get_config()
    host, path, is_https = _parse_url(POST_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        conn.request("POST", path, body=urlencode(POST_FORM_DATA), headers=headers)
        resp = conn.getresponse()
        body = json.loads(resp.read().decode())
        return {"status": "success", "status_code": resp.status, "form": body.get("form")}
    finally:
        conn.close()


def http_put():
    cfg = _get_config()
    host, path, is_https = _parse_url(PUT_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        headers = {"Content-Type": "application/json"}
        conn.request("PUT", path, body=json.dumps(PUT_JSON_BODY), headers=headers)
        resp = conn.getresponse()
        body = json.loads(resp.read().decode())
        return {"status": "success", "status_code": resp.status, "data": body}
    finally:
        conn.close()


def http_delete():
    cfg = _get_config()
    host, path, is_https = _parse_url(DELETE_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        conn.request("DELETE", path)
        resp = conn.getresponse()
        body = json.loads(resp.read().decode())
        return {"status": "success", "status_code": resp.status, "data": body}
    finally:
        conn.close()


def http_patch():
    cfg = _get_config()
    host, path, is_https = _parse_url(PATCH_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        headers = {"Content-Type": "application/json"}
        conn.request("PATCH", path, body=json.dumps(PATCH_JSON_BODY), headers=headers)
        resp = conn.getresponse()
        body = json.loads(resp.read().decode())
        return {"status": "success", "status_code": resp.status, "data": body}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Headers & Auth
# ---------------------------------------------------------------------------
def http_custom_headers():
    cfg = _get_config()
    host, path, is_https = _parse_url(HEADERS_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        conn.request("GET", path, headers=CUSTOM_HEADERS)
        resp = conn.getresponse()
        body = json.loads(resp.read().decode())
        return {"status": "success", "status_code": resp.status, "echoed_headers": body.get("headers", {})}
    finally:
        conn.close()


def http_bearer_auth():
    cfg = _get_config()
    host, path, is_https = _parse_url(BEARER_AUTH_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        headers = {"Authorization": f"Bearer {BEARER_TOKEN}"}
        conn.request("GET", path, headers=headers)
        resp = conn.getresponse()
        body = json.loads(resp.read().decode())
        return {"status": "success", "status_code": resp.status, "data": body}
    finally:
        conn.close()


def http_basic_auth():
    cfg = _get_config()
    host, path, is_https = _parse_url(BASIC_AUTH_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        credentials = base64.b64encode(f"{BASIC_AUTH_USER}:{BASIC_AUTH_PASS}".encode()).decode()
        headers = {"Authorization": f"Basic {credentials}"}
        conn.request("GET", path, headers=headers)
        resp = conn.getresponse()
        body = json.loads(resp.read().decode())
        return {"status": "success", "status_code": resp.status, "data": body}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Connection reuse
# ---------------------------------------------------------------------------
def http_connection_reuse():
    cfg = _get_config()
    host, path, is_https = _parse_url(GET_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        conn.request("GET", path)
        resp1 = conn.getresponse()
        body1 = json.loads(resp1.read().decode())

        conn.request("GET", path)
        resp2 = conn.getresponse()
        body2 = json.loads(resp2.read().decode())

        return {
            "status": "success",
            "request_1_status": resp1.status,
            "request_2_status": resp2.status,
            "reused": True,
        }
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Error scenarios
# ---------------------------------------------------------------------------
def http_timeout_error():
    host, path, is_https = _parse_url(TIMEOUT_URL)
    conn = _make_connection(host, is_https, timeout=1)
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        resp.read()
        return {"status": "success", "msg": "no timeout occurred"}
    except socket.timeout as e:
        return {"status": "error", "error_type": "timeout", "msg": str(e)}
    finally:
        conn.close()


def http_connection_error():
    host, path, is_https = _parse_url(CONNECTION_ERROR_URL)
    conn = _make_connection(host, is_https=False, timeout=2)
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        resp.read()
        return {"status": "success", "msg": "connection succeeded unexpectedly"}
    except (ConnectionRefusedError, OSError) as e:
        return {"status": "error", "error_type": "connection_error", "msg": str(e)}
    finally:
        conn.close()


def http_status_error():
    cfg = _get_config()
    host, _, is_https = _parse_url(STATUS_CODE_URL)
    path = "/status/404"
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        resp.read()
        return {"status": "success", "status_code": resp.status, "reason": resp.reason}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Response types
# ---------------------------------------------------------------------------
def http_response_json():
    cfg = _get_config()
    host, path, is_https = _parse_url(GET_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        body = json.loads(resp.read().decode())
        return {"status": "success", "status_code": resp.status, "parsed_json": body}
    finally:
        conn.close()


def http_response_text():
    cfg = _get_config()
    host, path, is_https = _parse_url(TEXT_RESPONSE_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        text = resp.read().decode()
        return {"status": "success", "status_code": resp.status, "length": len(text), "snippet": text[:200]}
    finally:
        conn.close()


def http_response_binary():
    cfg = _get_config()
    host, path, is_https = _parse_url(BINARY_RESPONSE_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        data = resp.read()
        return {"status": "success", "status_code": resp.status, "byte_length": len(data)}
    finally:
        conn.close()


def http_response_stream():
    cfg = _get_config()
    host, path, is_https = _parse_url(STREAM_RESPONSE_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        chunks = []
        while True:
            chunk = resp.read(1024)
            if not chunk:
                break
            chunks.append(chunk)
        full = b"".join(chunks)
        return {"status": "success", "status_code": resp.status, "chunks_read": len(chunks), "total_bytes": len(full)}
    finally:
        conn.close()


def http_response_html():
    cfg = _get_config()
    host, path, is_https = _parse_url(HTML_RESPONSE_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        html = resp.read().decode()
        return {"status": "success", "status_code": resp.status, "contains_html": "<html" in html.lower(), "length": len(html)}
    finally:
        conn.close()


def http_response_xml():
    cfg = _get_config()
    host, path, is_https = _parse_url(XML_RESPONSE_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        xml = resp.read().decode()
        return {"status": "success", "status_code": resp.status, "contains_xml": "<?xml" in xml or "<" in xml, "length": len(xml)}
    finally:
        conn.close()


def http_response_headers():
    cfg = _get_config()
    host, _, is_https = _parse_url(RESPONSE_HEADERS_URL)
    path = f"/response-headers?{urlencode(RESPONSE_HEADERS_PARAMS)}"
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        resp.read()
        headers = dict(resp.getheaders())
        return {"status": "success", "status_code": resp.status, "headers": headers}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# SSL
# ---------------------------------------------------------------------------
def http_ssl_verify():
    cfg = _get_config()
    host, path, is_https = _parse_url(SSL_VALID_URL)
    ctx = ssl.create_default_context()
    conn = _make_connection(host, is_https, timeout=cfg["timeout"], context=ctx)
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        resp.read()
        return {"status": "success", "status_code": resp.status, "ssl_verified": True}
    finally:
        conn.close()


def http_ssl_no_verify():
    cfg = _get_config()
    host, path, is_https = _parse_url(SSL_SELF_SIGNED_URL)
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    conn = _make_connection(host, is_https, timeout=cfg["timeout"], context=ctx)
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        resp.read()
        return {"status": "success", "status_code": resp.status, "ssl_verified": False}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Redirects
# ---------------------------------------------------------------------------
def http_redirect():
    cfg = _get_config()
    host, path, is_https = _parse_url(REDIRECT_URL)
    max_hops = 5
    hops = 0
    history = []

    while hops < max_hops:
        conn = _make_connection(host, is_https, timeout=cfg["timeout"])
        try:
            conn.request("GET", path)
            resp = conn.getresponse()
            resp.read()
            history.append({"url": f"{'https' if is_https else 'http'}://{host}{path}", "status": resp.status})

            if resp.status in (301, 302, 303, 307, 308):
                location = resp.getheader("Location")
                if not location:
                    break
                parsed_loc = urlparse(location)
                if parsed_loc.hostname:
                    host, path, is_https = _parse_url(location)
                else:
                    path = parsed_loc.path or "/"
                    if parsed_loc.query:
                        path = f"{path}?{parsed_loc.query}"
                hops += 1
            else:
                break
        finally:
            conn.close()

    return {"status": "success", "hops": hops, "final_status": resp.status, "history": history}


# ---------------------------------------------------------------------------
# Delay
# ---------------------------------------------------------------------------
def http_delay_request():
    cfg = _get_config()
    host, path, is_https = _parse_url(DELAY_URL)
    conn = _make_connection(host, is_https, timeout=cfg["timeout"])
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        body = json.loads(resp.read().decode())
        return {"status": "success", "status_code": resp.status, "data": body}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Dynamic request
# ---------------------------------------------------------------------------
def http_dynamic_request(method="GET", url=None, **kwargs):
    cfg = _get_config()
    url = url or GET_URL
    host, path, is_https = _parse_url(url)
    timeout = kwargs.get("timeout", cfg["timeout"])
    headers = kwargs.get("headers", {})
    body = kwargs.get("body")

    if body is not None and isinstance(body, dict):
        body = json.dumps(body)
        headers.setdefault("Content-Type", "application/json")

    conn = _make_connection(host, is_https, timeout=timeout)
    try:
        conn.request(method.upper(), path, body=body, headers=headers)
        resp = conn.getresponse()
        raw = resp.read()
        try:
            data = json.loads(raw.decode())
        except (json.JSONDecodeError, UnicodeDecodeError):
            data = raw.decode(errors="replace")
        return {"status": "success", "status_code": resp.status, "data": data}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# ROUTE_MAP
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/http/httpclient/http_get": http_get,
    "/http/httpclient/http_get_with_params": http_get_with_params,
    "/http/httpclient/http_post_json": http_post_json,
    "/http/httpclient/http_post_form": http_post_form,
    "/http/httpclient/http_put": http_put,
    "/http/httpclient/http_delete": http_delete,
    "/http/httpclient/http_patch": http_patch,
    "/http/httpclient/http_custom_headers": http_custom_headers,
    "/http/httpclient/http_bearer_auth": http_bearer_auth,
    "/http/httpclient/http_basic_auth": http_basic_auth,
    "/http/httpclient/http_connection_reuse": http_connection_reuse,
    "/http/httpclient/http_timeout_error": http_timeout_error,
    "/http/httpclient/http_connection_error": http_connection_error,
    "/http/httpclient/http_status_error": http_status_error,
    "/http/httpclient/http_response_json": http_response_json,
    "/http/httpclient/http_response_text": http_response_text,
    "/http/httpclient/http_response_binary": http_response_binary,
    "/http/httpclient/http_response_stream": http_response_stream,
    "/http/httpclient/http_response_html": http_response_html,
    "/http/httpclient/http_response_xml": http_response_xml,
    "/http/httpclient/http_response_headers": http_response_headers,
    "/http/httpclient/http_ssl_verify": http_ssl_verify,
    "/http/httpclient/http_ssl_no_verify": http_ssl_no_verify,
    "/http/httpclient/http_redirect": http_redirect,
    "/http/httpclient/http_delay_request": http_delay_request,
    "/http/httpclient/http_dynamic_request": http_dynamic_request,
}
