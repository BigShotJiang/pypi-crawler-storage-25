"""
MSSQL Component - pyodbc module
Covers: connection, pool (built-in ODBC + DBUtils), error handling, execution, fetching, advanced features
"""

import pyodbc
from apm_component.config import get_mssql_config


_TABLE = "ct_pyodbc"

# Try ODBC 18 first, fall back to 17
_DRIVER = None
for _d in ["ODBC Driver 18 for SQL Server", "ODBC Driver 17 for SQL Server"]:
    if _d in pyodbc.drivers():
        _DRIVER = _d
        break

if _DRIVER is None:
    _available = pyodbc.drivers()
    for _d in _available:
        if "SQL Server" in _d or "FreeTDS" in _d:
            _DRIVER = _d
            break


def _conn_str(database=None, timeout=None):
    cfg = get_mssql_config()
    db = database or cfg["database"]
    t = timeout or cfg["connect_timeout"]
    driver = _DRIVER or "ODBC Driver 18 for SQL Server"
    return (
        f"DRIVER={{{driver}}};"
        f"SERVER={cfg['host']},{cfg['port']};"
        f"DATABASE={db};"
        f"UID={cfg['user']};"
        f"PWD={cfg['password']};"
        f"TrustServerCertificate=yes;"
        f"LoginTimeout={t};"
    )


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------
def _get_connection(autocommit=False):
    return pyodbc.connect(_conn_str(), autocommit=autocommit)


def _ensure_database():
    cfg = get_mssql_config()
    master_str = _conn_str(database="master")
    conn = pyodbc.connect(master_str, autocommit=True)
    try:
        cursor = conn.cursor()
        cursor.execute(
            "IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = ?) "
            "CREATE DATABASE component_test_db",
            (cfg["database"],),
        )
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------
def connect():
    _ensure_database()
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        result = cursor.fetchone()
        return {"status": "connected", "result": tuple(result)}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Connection pooling
# ---------------------------------------------------------------------------
_pool = None


class _PyodbcCreator:
    """Wrapper so DBUtils PooledDB can create pyodbc connections."""

    threadsafety = 1
    paramstyle = pyodbc.paramstyle if hasattr(pyodbc, "paramstyle") else "qmark"
    apilevel = pyodbc.apilevel if hasattr(pyodbc, "apilevel") else "2.0"

    # DB-API exception hierarchy
    Error = pyodbc.Error
    DatabaseError = pyodbc.DatabaseError
    OperationalError = pyodbc.OperationalError
    InterfaceError = pyodbc.InterfaceError
    ProgrammingError = pyodbc.ProgrammingError
    IntegrityError = pyodbc.IntegrityError
    InternalError = pyodbc.InternalError
    NotSupportedError = pyodbc.NotSupportedError
    DataError = pyodbc.DataError

    def __init__(self, conn_str):
        self._conn_str = conn_str

    def connect(self, *args, **kwargs):
        return pyodbc.connect(self._conn_str, autocommit=False)


def connect_pool():
    global _pool
    from dbutils.pooled_db import PooledDB

    _ensure_database()
    _pool = PooledDB(
        creator=_PyodbcCreator(_conn_str()),
        maxconnections=get_mssql_config()["pool_size"],
        mincached=1,
        maxcached=3,
        blocking=True,
    )
    return {"status": "pool_created"}


def get_connection_from_pool():
    if _pool is None:
        connect_pool()
    conn = _pool.connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        return {"status": "pool_connection_ok", "result": tuple(cursor.fetchone())}
    finally:
        conn.close()


def toggle_odbc_pooling():
    original = pyodbc.pooling
    pyodbc.pooling = not original
    current = pyodbc.pooling
    pyodbc.pooling = original
    return {"status": "pooling_toggled", "original": original, "toggled": current}


# ---------------------------------------------------------------------------
# Connection error scenarios
# ---------------------------------------------------------------------------
def connect_error_wrong_password():
    cfg = get_mssql_config()
    driver = _DRIVER or "ODBC Driver 18 for SQL Server"
    bad_str = (
        f"DRIVER={{{driver}}};"
        f"SERVER={cfg['host']},{cfg['port']};"
        f"DATABASE={cfg['database']};"
        f"UID={cfg['user']};"
        f"PWD=wrong_password_xyz;"
        f"TrustServerCertificate=yes;"
        f"LoginTimeout=5;"
    )
    try:
        conn = pyodbc.connect(bad_str)
        conn.close()
        return {"status": "unexpected_success"}
    except pyodbc.Error as e:
        return {"status": "error", "msg": str(e)}


def connect_error_wrong_host():
    driver = _DRIVER or "ODBC Driver 18 for SQL Server"
    bad_str = (
        f"DRIVER={{{driver}}};"
        f"SERVER=192.0.2.1,1433;"
        f"DATABASE=master;"
        f"UID=sa;"
        f"PWD=x;"
        f"TrustServerCertificate=yes;"
        f"LoginTimeout=3;"
    )
    try:
        conn = pyodbc.connect(bad_str)
        conn.close()
        return {"status": "unexpected_success"}
    except pyodbc.Error as e:
        return {"status": "error", "msg": str(e)}


def connect_error_unknown_db():
    try:
        conn = pyodbc.connect(_conn_str(database="non_existent_db_xyz"))
        conn.close()
        return {"status": "unexpected_success"}
    except pyodbc.Error as e:
        return {"status": "error", "msg": str(e)}


def connect_error_timeout():
    driver = _DRIVER or "ODBC Driver 18 for SQL Server"
    bad_str = (
        f"DRIVER={{{driver}}};"
        f"SERVER=192.0.2.1,1433;"
        f"DATABASE=master;"
        f"UID=sa;"
        f"PWD=x;"
        f"TrustServerCertificate=yes;"
        f"LoginTimeout=1;"
    )
    try:
        conn = pyodbc.connect(bad_str)
        conn.close()
        return {"status": "unexpected_success"}
    except pyodbc.Error as e:
        return {"status": "error", "msg": str(e)}


def pool_error_exhaustion():
    from dbutils.pooled_db import PooledDB

    _ensure_database()
    small_pool = PooledDB(
        creator=_PyodbcCreator(_conn_str()),
        maxconnections=1,
        mincached=0,
        maxcached=0,
        blocking=False,
    )
    held = []
    try:
        held.append(small_pool.connection())
        held.append(small_pool.connection())
        return {"status": "unexpected_success"}
    except Exception as e:
        return {"status": "pool_exhausted", "msg": str(e)}
    finally:
        for c in held:
            c.close()


# ---------------------------------------------------------------------------
# Query execution
# ---------------------------------------------------------------------------
def execute_create_table():
    _ensure_database()
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"""
            IF OBJECT_ID('{_TABLE}', 'U') IS NOT NULL
                DROP TABLE {_TABLE}
        """)
        cursor.execute(f"""
            CREATE TABLE {_TABLE} (
                id INT IDENTITY(1,1) PRIMARY KEY,
                name NVARCHAR(100) NOT NULL,
                value INT DEFAULT 0,
                created_at DATETIME DEFAULT GETDATE()
            )
        """)
        conn.commit()
        return {"status": "table_created"}
    finally:
        conn.close()


def execute_insert():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (?, ?)",
            ("test_item", 42),
        )
        conn.commit()
        cursor.execute("SELECT SCOPE_IDENTITY()")
        lastrowid = cursor.fetchone()[0]
        return {"status": "inserted", "lastrowid": lastrowid}
    finally:
        conn.close()


def execute_insert_many():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        data = [("batch_1", 10), ("batch_2", 20), ("batch_3", 30)]
        cursor.executemany(
            f"INSERT INTO {_TABLE} (name, value) VALUES (?, ?)", data
        )
        conn.commit()
        rowcount = cursor.rowcount if cursor.rowcount >= 0 else len(data)
        return {"status": "inserted_many", "rowcount": rowcount}
    finally:
        conn.close()


def execute_fast_executemany():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.fast_executemany = True
        data = [("fast_1", 100), ("fast_2", 200), ("fast_3", 300)]
        cursor.executemany(
            f"INSERT INTO {_TABLE} (name, value) VALUES (?, ?)", data
        )
        conn.commit()
        rowcount = cursor.rowcount if cursor.rowcount >= 0 else len(data)
        return {"status": "fast_inserted", "rowcount": rowcount}
    finally:
        conn.close()


def execute_update():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"UPDATE {_TABLE} SET value = ? WHERE name = ?",
            (99, "test_item"),
        )
        conn.commit()
        return {"status": "updated", "rowcount": cursor.rowcount}
    finally:
        conn.close()


def execute_delete():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"DELETE FROM {_TABLE} WHERE name = ?", ("test_item",)
        )
        conn.commit()
        return {"status": "deleted", "rowcount": cursor.rowcount}
    finally:
        conn.close()


def execute_select():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT TOP 10 id, name, value FROM {_TABLE}")
        rows = [tuple(r) for r in cursor.fetchall()]
        return {"status": "selected", "rows": rows}
    finally:
        conn.close()


def execute_parameterized():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"SELECT id, name FROM {_TABLE} WHERE value > ?", (5,)
        )
        rows = [tuple(r) for r in cursor.fetchall()]
        return {"status": "parameterized_ok", "rows": rows}
    finally:
        conn.close()


def execute_transaction():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (?, ?)",
            ("txn_item", 100),
        )
        conn.commit()

        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (?, ?)",
            ("txn_rollback", 200),
        )
        conn.rollback()

        cursor.execute(f"SELECT name FROM {_TABLE} WHERE name LIKE 'txn_%'")
        rows = [tuple(r) for r in cursor.fetchall()]
        return {"status": "transaction_ok", "committed_rows": rows}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Data fetching
# ---------------------------------------------------------------------------
def fetch_one():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT TOP 1 id, name, value FROM {_TABLE}")
        row = cursor.fetchone()
        return {"status": "fetch_one", "row": tuple(row) if row else None}
    finally:
        conn.close()


def fetch_all():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE}")
        rows = [tuple(r) for r in cursor.fetchall()]
        return {"status": "fetch_all", "count": len(rows), "rows": rows}
    finally:
        conn.close()


def fetch_many():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, name, value FROM {_TABLE}")
        batch = [tuple(r) for r in cursor.fetchmany(2)]
        return {"status": "fetch_many", "batch": batch}
    finally:
        conn.close()


def fetch_as_dict():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT TOP 5 id, name, value FROM {_TABLE}")
        columns = [col[0] for col in cursor.description]
        rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
        return {"status": "fetch_as_dict", "rows": rows}
    finally:
        conn.close()


def fetch_column_metadata():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT TOP 1 * FROM {_TABLE}")
        meta = [
            {"name": col[0], "type": str(col[1]), "size": col[3]}
            for col in cursor.description
        ]
        return {"status": "column_metadata_ok", "columns": meta}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Advanced / unique cases
# ---------------------------------------------------------------------------
def call_stored_procedure():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"""
            IF OBJECT_ID('sp_get_count_pyodbc', 'P') IS NOT NULL
                DROP PROCEDURE sp_get_count_pyodbc
        """)
        cursor.execute(f"""
            CREATE PROCEDURE sp_get_count_pyodbc
                @total INT OUTPUT
            AS
            BEGIN
                SELECT @total = COUNT(*) FROM {_TABLE}
            END
        """)
        conn.commit()

        cursor.execute(
            "DECLARE @out INT; EXEC sp_get_count_pyodbc @total = @out OUTPUT; SELECT @out"
        )
        total = cursor.fetchone()[0]
        return {"status": "stored_proc_ok", "total": total}
    finally:
        conn.close()


def multiple_result_sets():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"SELECT TOP 2 id, name FROM {_TABLE}; "
            f"SELECT COUNT(*) AS cnt FROM {_TABLE}"
        )
        first = [tuple(r) for r in cursor.fetchall()]
        cursor.nextset()
        second = [tuple(r) for r in cursor.fetchall()]
        return {"status": "multiple_result_sets_ok", "first": first, "second": second}
    finally:
        conn.close()


def dynamic_query(table_name=_TABLE, columns=None, where_clause=None):
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cols = ", ".join(columns) if columns else "*"
        query = f"SELECT {cols} FROM [{table_name}]"
        params = ()
        if where_clause:
            query += " WHERE " + where_clause["condition"]
            params = tuple(where_clause.get("params", ()))
        cursor.execute(query, params)
        col_names = [col[0] for col in cursor.description]
        rows = [dict(zip(col_names, row)) for row in cursor.fetchall()]
        return {"status": "dynamic_query_ok", "rows": rows}
    finally:
        conn.close()


def delayed_insert():
    conn = _get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("WAITFOR DELAY '00:00:01'")
        cursor.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (?, ?)",
            ("delayed_item", 555),
        )
        conn.commit()
        cursor.execute("SELECT SCOPE_IDENTITY()")
        lastrowid = cursor.fetchone()[0]
        return {"status": "delayed_insert_ok", "lastrowid": lastrowid}
    finally:
        conn.close()


def race_condition_test():
    conn1 = _get_connection()
    conn2 = _get_connection()
    try:
        cursor1 = conn1.cursor()
        cursor1.execute(
            f"INSERT INTO {_TABLE} (name, value) VALUES (?, ?)",
            ("race_item", 0),
        )
        conn1.commit()

        cursor1.execute(
            f"SELECT value FROM {_TABLE} WITH (UPDLOCK, ROWLOCK) WHERE name = 'race_item'"
        )
        current = cursor1.fetchone()[0]
        cursor1.execute(
            f"UPDATE {_TABLE} SET value = ? WHERE name = 'race_item'",
            (current + 1,),
        )
        conn1.commit()

        cursor2 = conn2.cursor()
        cursor2.execute(
            f"SELECT value FROM {_TABLE} WITH (UPDLOCK, ROWLOCK) WHERE name = 'race_item'"
        )
        current2 = cursor2.fetchone()[0]
        cursor2.execute(
            f"UPDATE {_TABLE} SET value = ? WHERE name = 'race_item'",
            (current2 + 1,),
        )
        conn2.commit()

        cursor1.execute(f"SELECT value FROM {_TABLE} WHERE name = 'race_item'")
        final = cursor1.fetchone()[0] # pyright: ignore[reportOptionalSubscript]
        return {"status": "race_test_ok", "final_value": final}
    finally:
        conn1.close()
        conn2.close()


# ---------------------------------------------------------------------------
# Global route-to-function mapping
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/db/mssql/pyodbc/connect": connect,
    "/db/mssql/pyodbc/connect_pool": connect_pool,
    "/db/mssql/pyodbc/get_connection_from_pool": get_connection_from_pool,
    "/db/mssql/pyodbc/toggle_odbc_pooling": toggle_odbc_pooling,
    "/db/mssql/pyodbc/connect_error_wrong_password": connect_error_wrong_password,
    "/db/mssql/pyodbc/connect_error_wrong_host": connect_error_wrong_host,
    "/db/mssql/pyodbc/connect_error_unknown_db": connect_error_unknown_db,
    "/db/mssql/pyodbc/connect_error_timeout": connect_error_timeout,
    "/db/mssql/pyodbc/pool_error_exhaustion": pool_error_exhaustion,
    "/db/mssql/pyodbc/execute_create_table": execute_create_table,
    "/db/mssql/pyodbc/execute_insert": execute_insert,
    "/db/mssql/pyodbc/execute_insert_many": execute_insert_many,
    "/db/mssql/pyodbc/execute_fast_executemany": execute_fast_executemany,
    "/db/mssql/pyodbc/execute_update": execute_update,
    "/db/mssql/pyodbc/execute_delete": execute_delete,
    "/db/mssql/pyodbc/execute_select": execute_select,
    "/db/mssql/pyodbc/execute_parameterized": execute_parameterized,
    "/db/mssql/pyodbc/execute_transaction": execute_transaction,
    "/db/mssql/pyodbc/fetch_one": fetch_one,
    "/db/mssql/pyodbc/fetch_all": fetch_all,
    "/db/mssql/pyodbc/fetch_many": fetch_many,
    "/db/mssql/pyodbc/fetch_as_dict": fetch_as_dict,
    "/db/mssql/pyodbc/fetch_column_metadata": fetch_column_metadata,
    "/db/mssql/pyodbc/call_stored_procedure": call_stored_procedure,
    "/db/mssql/pyodbc/multiple_result_sets": multiple_result_sets,
    "/db/mssql/pyodbc/dynamic_query": dynamic_query,
    "/db/mssql/pyodbc/delayed_insert": delayed_insert,
    "/db/mssql/pyodbc/race_condition_test": race_condition_test,
}
