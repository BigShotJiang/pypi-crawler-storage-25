"""
HTTP Component - aiohttp module (async)
Covers: GET/POST/PUT/DELETE/PATCH, headers, auth, session reuse, pooling,
        timeouts, errors, response types, SSL, redirects, cookies,
        concurrent requests, streaming
"""

import asyncio
import ssl

import aiohttp

from apm_component.config import get_http_config
from apm_component.http_urls import (
    GET_URL, GET_PARAMS,
    POST_URL, POST_JSON_BODY, POST_FORM_DATA,
    PUT_URL, PUT_JSON_BODY, DELETE_URL, PATCH_URL, PATCH_JSON_BODY,
    HEADERS_URL, CUSTOM_HEADERS,
    BEARER_AUTH_URL, BEARER_TOKEN, BASIC_AUTH_URL, BASIC_AUTH_USER, BASIC_AUTH_PASS,
    JSON_RESPONSE_URL, TEXT_RESPONSE_URL, BINARY_RESPONSE_URL,
    HTML_RESPONSE_URL, XML_RESPONSE_URL, STREAM_RESPONSE_URL,
    RESPONSE_HEADERS_URL, RESPONSE_HEADERS_PARAMS,
    STATUS_CODE_URL, TIMEOUT_URL, DELAY_URL, CONNECTION_ERROR_URL,
    REDIRECT_URL, COOKIES_SET_URL, COOKIES_GET_URL, COOKIE_PARAMS,
    SSL_VALID_URL, SSL_SELF_SIGNED_URL,
)


def _get_config():
    return get_http_config()


# ---------------------------------------------------------------------------
# Basic HTTP methods
# ---------------------------------------------------------------------------
async def _http_get():
    async with aiohttp.ClientSession() as session:
        async with session.get(GET_URL) as resp:
            data = await resp.json()
            return {"status": "success", "status_code": resp.status, "data": data}


def http_get():
    return asyncio.run(_http_get())


async def _http_get_with_params():
    async with aiohttp.ClientSession() as session:
        async with session.get(GET_URL, params=GET_PARAMS) as resp:
            data = await resp.json()
            return {"status": "success", "status_code": resp.status, "args": data.get("args")}


def http_get_with_params():
    return asyncio.run(_http_get_with_params())


async def _http_post_json():
    async with aiohttp.ClientSession() as session:
        async with session.post(POST_URL, json=POST_JSON_BODY) as resp:
            data = await resp.json()
            return {"status": "success", "status_code": resp.status, "data": data}


def http_post_json():
    return asyncio.run(_http_post_json())


async def _http_post_form():
    async with aiohttp.ClientSession() as session:
        form = aiohttp.FormData(POST_FORM_DATA)
        async with session.post(POST_URL, data=form) as resp:
            data = await resp.json()
            return {"status": "success", "status_code": resp.status, "form": data.get("form")}


def http_post_form():
    return asyncio.run(_http_post_form())


async def _http_put():
    async with aiohttp.ClientSession() as session:
        async with session.put(PUT_URL, json=PUT_JSON_BODY) as resp:
            data = await resp.json()
            return {"status": "success", "status_code": resp.status, "data": data}


def http_put():
    return asyncio.run(_http_put())


async def _http_delete():
    async with aiohttp.ClientSession() as session:
        async with session.delete(DELETE_URL) as resp:
            data = await resp.json()
            return {"status": "success", "status_code": resp.status, "data": data}


def http_delete():
    return asyncio.run(_http_delete())


async def _http_patch():
    async with aiohttp.ClientSession() as session:
        async with session.patch(PATCH_URL, json=PATCH_JSON_BODY) as resp:
            data = await resp.json()
            return {"status": "success", "status_code": resp.status, "data": data}


def http_patch():
    return asyncio.run(_http_patch())


# ---------------------------------------------------------------------------
# Headers & Auth
# ---------------------------------------------------------------------------
async def _http_custom_headers():
    async with aiohttp.ClientSession() as session:
        async with session.get(HEADERS_URL, headers=CUSTOM_HEADERS) as resp:
            data = await resp.json()
            echoed = data.get("headers", {})
            return {"status": "success", "status_code": resp.status, "echoed_headers": echoed}


def http_custom_headers():
    return asyncio.run(_http_custom_headers())


async def _http_bearer_auth():
    headers = {"Authorization": f"Bearer {BEARER_TOKEN}"}
    async with aiohttp.ClientSession() as session:
        async with session.get(BEARER_AUTH_URL, headers=headers) as resp:
            data = await resp.json()
            return {"status": "success", "status_code": resp.status, "data": data}


def http_bearer_auth():
    return asyncio.run(_http_bearer_auth())


async def _http_basic_auth():
    auth = aiohttp.BasicAuth(BASIC_AUTH_USER, BASIC_AUTH_PASS)
    async with aiohttp.ClientSession(auth=auth) as session:
        async with session.get(BASIC_AUTH_URL) as resp:
            data = await resp.json()
            return {"status": "success", "status_code": resp.status, "data": data}


def http_basic_auth():
    return asyncio.run(_http_basic_auth())


# ---------------------------------------------------------------------------
# Session reuse & Pooling
# ---------------------------------------------------------------------------
async def _http_session_reuse():
    async with aiohttp.ClientSession() as session:
        async with session.get(GET_URL) as r1:
            status1 = r1.status
        async with session.post(POST_URL, json=POST_JSON_BODY) as r2:
            status2 = r2.status
        return {"status": "success", "get_status": status1, "post_status": status2}


def http_session_reuse():
    return asyncio.run(_http_session_reuse())


async def _http_connection_pool():
    cfg = _get_config()
    connector = aiohttp.TCPConnector(limit=cfg["pool_maxsize"])
    async with aiohttp.ClientSession(connector=connector) as session:
        async with session.get(GET_URL) as resp:
            data = await resp.json()
            return {
                "status": "success",
                "status_code": resp.status,
                "pool_limit": cfg["pool_maxsize"],
            }


def http_connection_pool():
    return asyncio.run(_http_connection_pool())


# ---------------------------------------------------------------------------
# Error scenarios
# ---------------------------------------------------------------------------
async def _http_timeout_error():
    timeout = aiohttp.ClientTimeout(total=1)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(TIMEOUT_URL) as resp:
                await resp.text()
                return {"status": "no_timeout"}
    except asyncio.TimeoutError:
        return {"status": "error", "msg": "Request timed out"}


def http_timeout_error():
    return asyncio.run(_http_timeout_error())


async def _http_connection_error():
    timeout = aiohttp.ClientTimeout(total=3)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(CONNECTION_ERROR_URL) as resp:
                await resp.text()
                return {"status": "no_error"}
    except (aiohttp.ClientConnectorError, asyncio.TimeoutError, Exception) as e:
        return {"status": "error", "msg": str(e)}


def http_connection_error():
    return asyncio.run(_http_connection_error())


async def _http_status_error():
    async with aiohttp.ClientSession() as session:
        async with session.get(f"{STATUS_CODE_URL}/404") as resp:
            return {"status": "success", "status_code": resp.status, "is_client_error": resp.status == 404}


def http_status_error():
    return asyncio.run(_http_status_error())


# ---------------------------------------------------------------------------
# Response types
# ---------------------------------------------------------------------------
async def _http_response_json():
    async with aiohttp.ClientSession() as session:
        async with session.get(JSON_RESPONSE_URL) as resp:
            data = await resp.json()
            return {"status": "success", "json": data}


def http_response_json():
    return asyncio.run(_http_response_json())


async def _http_response_text():
    async with aiohttp.ClientSession() as session:
        async with session.get(TEXT_RESPONSE_URL) as resp:
            text = await resp.text()
            return {"status": "success", "text": text[:200]}


def http_response_text():
    return asyncio.run(_http_response_text())


async def _http_response_binary():
    async with aiohttp.ClientSession() as session:
        async with session.get(BINARY_RESPONSE_URL) as resp:
            content = await resp.read()
            return {"status": "success", "content_length": len(content)}


def http_response_binary():
    return asyncio.run(_http_response_binary())


async def _http_response_stream():
    chunks = []
    async with aiohttp.ClientSession() as session:
        async with session.get(STREAM_RESPONSE_URL) as resp:
            async for chunk in resp.content.iter_chunked(1024):
                if chunk:
                    chunks.append(len(chunk))
    return {"status": "success", "chunk_count": len(chunks), "total_bytes": sum(chunks)}


def http_response_stream():
    return asyncio.run(_http_response_stream())


async def _http_response_html():
    async with aiohttp.ClientSession() as session:
        async with session.get(HTML_RESPONSE_URL) as resp:
            html = await resp.text()
            return {"status": "success", "html": html[:200]}


def http_response_html():
    return asyncio.run(_http_response_html())


async def _http_response_xml():
    async with aiohttp.ClientSession() as session:
        async with session.get(XML_RESPONSE_URL) as resp:
            xml = await resp.text()
            return {"status": "success", "xml": xml[:200]}


def http_response_xml():
    return asyncio.run(_http_response_xml())


async def _http_response_headers():
    async with aiohttp.ClientSession() as session:
        async with session.get(RESPONSE_HEADERS_URL, params=RESPONSE_HEADERS_PARAMS) as resp:
            return {"status": "success", "headers": dict(resp.headers)}


def http_response_headers():
    return asyncio.run(_http_response_headers())


# ---------------------------------------------------------------------------
# SSL
# ---------------------------------------------------------------------------
async def _http_ssl_verify():
    async with aiohttp.ClientSession() as session:
        async with session.get(SSL_VALID_URL, ssl=True) as resp:
            return {"status": "success", "status_code": resp.status}


def http_ssl_verify():
    return asyncio.run(_http_ssl_verify())


async def _http_ssl_no_verify():
    async with aiohttp.ClientSession() as session:
        async with session.get(SSL_SELF_SIGNED_URL, ssl=False) as resp:
            return {"status": "success", "status_code": resp.status}


def http_ssl_no_verify():
    return asyncio.run(_http_ssl_no_verify())


# ---------------------------------------------------------------------------
# Redirects & Cookies
# ---------------------------------------------------------------------------
async def _http_redirect():
    async with aiohttp.ClientSession() as session:
        async with session.get(REDIRECT_URL) as resp:
            return {
                "status": "success",
                "history_length": len(resp.history),
                "final_url": str(resp.url),
            }


def http_redirect():
    return asyncio.run(_http_redirect())


async def _http_cookies():
    async with aiohttp.ClientSession() as session:
        async with session.get(COOKIES_SET_URL, params=COOKIE_PARAMS, allow_redirects=True) as _:
            pass
        async with session.get(COOKIES_GET_URL) as resp:
            data = await resp.json()
            return {"status": "success", "cookies": data.get("cookies", {})}


def http_cookies():
    return asyncio.run(_http_cookies())


# ---------------------------------------------------------------------------
# Advanced
# ---------------------------------------------------------------------------
async def _http_concurrent_requests():
    async with aiohttp.ClientSession() as session:
        tasks = [session.get(GET_URL) for _ in range(5)]
        responses = await asyncio.gather(*tasks)
        results = []
        for resp in responses:
            results.append({"status_code": resp.status})
            resp.release()
        return {"status": "success", "request_count": len(results), "results": results}


def http_concurrent_requests():
    return asyncio.run(_http_concurrent_requests())


async def _http_delay_request():
    async with aiohttp.ClientSession() as session:
        async with session.get(DELAY_URL) as resp:
            data = await resp.json()
            return {"status": "success", "status_code": resp.status, "data": data}


def http_delay_request():
    return asyncio.run(_http_delay_request())


async def _http_dynamic_request(method="GET", url=None, **kwargs):
    if url is None:
        url = GET_URL
    async with aiohttp.ClientSession() as session:
        async with session.request(method, url, **kwargs) as resp:
            try:
                data = await resp.json()
            except aiohttp.ContentTypeError:
                data = await resp.text()
            return {"status": "success", "method": method, "status_code": resp.status}


def http_dynamic_request(method="GET", url=None, **kwargs):
    return asyncio.run(_http_dynamic_request(method=method, url=url, **kwargs))


# ---------------------------------------------------------------------------
# ROUTE_MAP
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/http/aiohttp/http_get": http_get,
    "/http/aiohttp/http_get_with_params": http_get_with_params,
    "/http/aiohttp/http_post_json": http_post_json,
    "/http/aiohttp/http_post_form": http_post_form,
    "/http/aiohttp/http_put": http_put,
    "/http/aiohttp/http_delete": http_delete,
    "/http/aiohttp/http_patch": http_patch,
    "/http/aiohttp/http_custom_headers": http_custom_headers,
    "/http/aiohttp/http_bearer_auth": http_bearer_auth,
    "/http/aiohttp/http_basic_auth": http_basic_auth,
    "/http/aiohttp/http_session_reuse": http_session_reuse,
    "/http/aiohttp/http_connection_pool": http_connection_pool,
    "/http/aiohttp/http_timeout_error": http_timeout_error,
    "/http/aiohttp/http_connection_error": http_connection_error,
    "/http/aiohttp/http_status_error": http_status_error,
    "/http/aiohttp/http_response_json": http_response_json,
    "/http/aiohttp/http_response_text": http_response_text,
    "/http/aiohttp/http_response_binary": http_response_binary,
    "/http/aiohttp/http_response_stream": http_response_stream,
    "/http/aiohttp/http_response_html": http_response_html,
    "/http/aiohttp/http_response_xml": http_response_xml,
    "/http/aiohttp/http_response_headers": http_response_headers,
    "/http/aiohttp/http_ssl_verify": http_ssl_verify,
    "/http/aiohttp/http_ssl_no_verify": http_ssl_no_verify,
    "/http/aiohttp/http_redirect": http_redirect,
    "/http/aiohttp/http_cookies": http_cookies,
    "/http/aiohttp/http_concurrent_requests": http_concurrent_requests,
    "/http/aiohttp/http_delay_request": http_delay_request,
    "/http/aiohttp/http_dynamic_request": http_dynamic_request,
}
