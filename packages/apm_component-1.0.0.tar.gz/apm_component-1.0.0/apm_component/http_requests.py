"""
HTTP Component - requests module
Covers: GET/POST/PUT/DELETE/PATCH, headers, auth, sessions, pooling,
        timeouts, retries, response types, SSL, redirects, cookies
"""

import requests
from requests.adapters import HTTPAdapter
from requests.auth import HTTPBasicAuth
from urllib3.util.retry import Retry

from apm_component.config import get_http_config
from apm_component.http_urls import (
    GET_URL, GET_WITH_PARAMS_URL, GET_PARAMS,
    POST_URL, POST_JSON_BODY, POST_FORM_DATA,
    PUT_URL, PUT_JSON_BODY, DELETE_URL, PATCH_URL, PATCH_JSON_BODY,
    HEADERS_URL, CUSTOM_HEADERS,
    BEARER_AUTH_URL, BEARER_TOKEN, BASIC_AUTH_URL, BASIC_AUTH_USER, BASIC_AUTH_PASS,
    JSON_RESPONSE_URL, TEXT_RESPONSE_URL, BINARY_RESPONSE_URL,
    HTML_RESPONSE_URL, XML_RESPONSE_URL, STREAM_RESPONSE_URL,
    RESPONSE_HEADERS_URL, RESPONSE_HEADERS_PARAMS,
    STATUS_CODE_URL, TIMEOUT_URL, DELAY_URL, CONNECTION_ERROR_URL,
    REDIRECT_URL, COOKIES_SET_URL, COOKIES_GET_URL, COOKIE_PARAMS,
    SSL_VALID_URL, SSL_SELF_SIGNED_URL,
)


def _get_config():
    return get_http_config()


# ---------------------------------------------------------------------------
# Basic HTTP methods
# ---------------------------------------------------------------------------
def http_get():
    cfg = _get_config()
    r = requests.get(GET_URL, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


def http_get_with_params():
    cfg = _get_config()
    r = requests.get(GET_WITH_PARAMS_URL, params=GET_PARAMS, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "args": r.json().get("args")}


def http_post_json():
    cfg = _get_config()
    r = requests.post(POST_URL, json=POST_JSON_BODY, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


def http_post_form():
    cfg = _get_config()
    r = requests.post(POST_URL, data=POST_FORM_DATA, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "form": r.json().get("form")}


def http_put():
    cfg = _get_config()
    r = requests.put(PUT_URL, json=PUT_JSON_BODY, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


def http_delete():
    cfg = _get_config()
    r = requests.delete(DELETE_URL, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


def http_patch():
    cfg = _get_config()
    r = requests.patch(PATCH_URL, json=PATCH_JSON_BODY, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


# ---------------------------------------------------------------------------
# Headers & Auth
# ---------------------------------------------------------------------------
def http_custom_headers():
    cfg = _get_config()
    r = requests.get(HEADERS_URL, headers=CUSTOM_HEADERS, timeout=cfg["timeout"])
    echoed = r.json().get("headers", {})
    return {"status": "success", "status_code": r.status_code, "echoed_headers": echoed}


def http_bearer_auth():
    cfg = _get_config()
    headers = {"Authorization": f"Bearer {BEARER_TOKEN}"}
    r = requests.get(BEARER_AUTH_URL, headers=headers, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


def http_basic_auth():
    cfg = _get_config()
    r = requests.get(BASIC_AUTH_URL, auth=HTTPBasicAuth(BASIC_AUTH_USER, BASIC_AUTH_PASS), timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


# ---------------------------------------------------------------------------
# Session & Pooling
# ---------------------------------------------------------------------------
def http_session_reuse():
    cfg = _get_config()
    session = requests.Session()
    try:
        r1 = session.get(GET_URL, timeout=cfg["timeout"])
        r2 = session.post(POST_URL, json=POST_JSON_BODY, timeout=cfg["timeout"])
        return {
            "status": "success",
            "get_status": r1.status_code,
            "post_status": r2.status_code,
        }
    finally:
        session.close()


def http_connection_pool():
    cfg = _get_config()
    session = requests.Session()
    adapter = HTTPAdapter(pool_connections=cfg["pool_connections"], pool_maxsize=cfg["pool_maxsize"])
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    try:
        r = session.get(GET_URL, timeout=cfg["timeout"])
        return {"status": "success", "status_code": r.status_code, "pool_connections": cfg["pool_connections"], "pool_maxsize": cfg["pool_maxsize"]}
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Error scenarios
# ---------------------------------------------------------------------------
def http_timeout_error():
    try:
        requests.get(TIMEOUT_URL, timeout=1)
        return {"status": "no_timeout"}
    except requests.exceptions.Timeout as e:
        return {"status": "error", "msg": str(e)}


def http_connection_error():
    try:
        requests.get(CONNECTION_ERROR_URL, timeout=3)
        return {"status": "no_error"}
    except (requests.exceptions.ConnectionError, requests.exceptions.Timeout, Exception) as e:
        return {"status": "error", "msg": str(e)}


def http_status_error():
    cfg = _get_config()
    r = requests.get(f"{STATUS_CODE_URL}/404", timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "is_client_error": r.status_code == 404}


def http_retry_logic():
    cfg = _get_config()
    session = requests.Session()
    retry = Retry(total=3, backoff_factor=0.1, status_forcelist=[500, 502, 503])
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    try:
        r = session.get(f"{STATUS_CODE_URL}/500", timeout=cfg["timeout"])
        return {"status": "success", "status_code": r.status_code, "retries_configured": 3}
    except requests.exceptions.RetryError as e:
        return {"status": "error", "msg": str(e)}
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Response types
# ---------------------------------------------------------------------------
def http_response_json():
    cfg = _get_config()
    r = requests.get(JSON_RESPONSE_URL, timeout=cfg["timeout"])
    return {"status": "success", "json": r.json()}


def http_response_text():
    cfg = _get_config()
    r = requests.get(TEXT_RESPONSE_URL, timeout=cfg["timeout"])
    return {"status": "success", "text": r.text[:200]}


def http_response_binary():
    cfg = _get_config()
    r = requests.get(BINARY_RESPONSE_URL, timeout=cfg["timeout"])
    return {"status": "success", "content_length": len(r.content)}


def http_response_stream():
    cfg = _get_config()
    r = requests.get(STREAM_RESPONSE_URL, stream=True, timeout=cfg["timeout"])
    chunks = []
    try:
        for chunk in r.iter_content(chunk_size=1024):
            if chunk:
                chunks.append(len(chunk))
        return {"status": "success", "chunk_count": len(chunks), "total_bytes": sum(chunks)}
    finally:
        r.close()


def http_response_html():
    cfg = _get_config()
    r = requests.get(HTML_RESPONSE_URL, timeout=cfg["timeout"])
    return {"status": "success", "html": r.text[:200]}


def http_response_xml():
    cfg = _get_config()
    r = requests.get(XML_RESPONSE_URL, timeout=cfg["timeout"])
    return {"status": "success", "xml": r.text[:200]}


def http_response_headers():
    cfg = _get_config()
    r = requests.get(RESPONSE_HEADERS_URL, params=RESPONSE_HEADERS_PARAMS, timeout=cfg["timeout"])
    return {"status": "success", "headers": dict(r.headers)}


# ---------------------------------------------------------------------------
# SSL
# ---------------------------------------------------------------------------
def http_ssl_verify():
    cfg = _get_config()
    r = requests.get(SSL_VALID_URL, verify=True, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code}


def http_ssl_no_verify():
    cfg = _get_config()
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    r = requests.get(SSL_SELF_SIGNED_URL, verify=False, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code}


# ---------------------------------------------------------------------------
# Redirects & Cookies
# ---------------------------------------------------------------------------
def http_redirect():
    cfg = _get_config()
    r = requests.get(REDIRECT_URL, allow_redirects=True, timeout=cfg["timeout"])
    return {"status": "success", "history_length": len(r.history), "final_url": r.url}


def http_cookies():
    cfg = _get_config()
    session = requests.Session()
    try:
        session.get(COOKIES_SET_URL, params=COOKIE_PARAMS, timeout=cfg["timeout"])
        r = session.get(COOKIES_GET_URL, timeout=cfg["timeout"])
        return {"status": "success", "cookies": r.json().get("cookies", {})}
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Advanced
# ---------------------------------------------------------------------------
def http_prepared_request():
    cfg = _get_config()
    session = requests.Session()
    try:
        req = requests.Request("POST", POST_URL, json=POST_JSON_BODY)
        prepared = session.prepare_request(req)
        r = session.send(prepared, timeout=cfg["timeout"])
        return {"status": "success", "status_code": r.status_code, "data": r.json()}
    finally:
        session.close()


def http_delay_request():
    cfg = _get_config()
    r = requests.get(DELAY_URL, timeout=cfg["timeout"])
    return {"status": "success", "status_code": r.status_code, "data": r.json()}


def http_dynamic_request(method="GET", url=None, **kwargs):
    cfg = _get_config()
    kwargs.setdefault("timeout", cfg["timeout"])
    if url is None:
        url = GET_URL
    r = requests.request(method, url, **kwargs)
    return {"status": "success", "method": method, "status_code": r.status_code}


# ---------------------------------------------------------------------------
# ROUTE_MAP
# ---------------------------------------------------------------------------
ROUTE_MAP = {
    "/http/requests/http_get": http_get,
    "/http/requests/http_get_with_params": http_get_with_params,
    "/http/requests/http_post_json": http_post_json,
    "/http/requests/http_post_form": http_post_form,
    "/http/requests/http_put": http_put,
    "/http/requests/http_delete": http_delete,
    "/http/requests/http_patch": http_patch,
    "/http/requests/http_custom_headers": http_custom_headers,
    "/http/requests/http_bearer_auth": http_bearer_auth,
    "/http/requests/http_basic_auth": http_basic_auth,
    "/http/requests/http_session_reuse": http_session_reuse,
    "/http/requests/http_connection_pool": http_connection_pool,
    "/http/requests/http_timeout_error": http_timeout_error,
    "/http/requests/http_connection_error": http_connection_error,
    "/http/requests/http_status_error": http_status_error,
    "/http/requests/http_retry_logic": http_retry_logic,
    "/http/requests/http_response_json": http_response_json,
    "/http/requests/http_response_text": http_response_text,
    "/http/requests/http_response_binary": http_response_binary,
    "/http/requests/http_response_stream": http_response_stream,
    "/http/requests/http_response_html": http_response_html,
    "/http/requests/http_response_xml": http_response_xml,
    "/http/requests/http_response_headers": http_response_headers,
    "/http/requests/http_ssl_verify": http_ssl_verify,
    "/http/requests/http_ssl_no_verify": http_ssl_no_verify,
    "/http/requests/http_redirect": http_redirect,
    "/http/requests/http_cookies": http_cookies,
    "/http/requests/http_prepared_request": http_prepared_request,
    "/http/requests/http_delay_request": http_delay_request,
    "/http/requests/http_dynamic_request": http_dynamic_request,
}
