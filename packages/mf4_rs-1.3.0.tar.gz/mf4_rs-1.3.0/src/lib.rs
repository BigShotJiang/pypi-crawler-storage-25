//! Minimal utilities for reading and writing ASAM MDF 4 files.
//!
//! The crate exposes a high level API under [`api`] to inspect existing
//! recordings as well as a [`writer::MdfWriter`] to generate new files.  Only a
//! fraction of the MDF 4 specification is implemented.

pub mod blocks;
pub mod error;
pub mod writer;
/// File-cutting utilities (native only; not available on `wasm32-unknown-unknown`).
#[cfg(not(target_arch = "wasm32"))]
pub mod cut;
/// File-merging utilities (native only; not available on `wasm32-unknown-unknown`).
#[cfg(not(target_arch = "wasm32"))]
pub mod merge;
pub mod index;
pub mod block_layout;

pub mod parsing {
    pub mod decoder;
    pub mod mdf_file;
    pub mod raw_channel_group;
    pub mod raw_data_group;
    pub mod raw_channel;
    pub mod source_info;
}

pub mod api {
    pub mod mdf;
    pub mod channel_group;
    pub mod channel;
}

// Python bindings module
#[cfg(feature = "pyo3")]
pub mod python;

// Re-export the Python module when building as an extension
#[cfg(feature = "pyo3")]
use pyo3::prelude::*;

#[cfg(feature = "pyo3")]
#[pymodule]
fn mf4_rs(m: &Bound<'_, PyModule>) -> PyResult<()> {
    python::init_mf4_rs_module(m)
}
