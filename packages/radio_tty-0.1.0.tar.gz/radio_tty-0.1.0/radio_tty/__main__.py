import dataclasses
import math
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any

import requests
import tomllib

CONFIG_PATH = (
    Path(
        os.environ.get(
            "RADIO_TTY_CONFIG_PATH",
            "~/.config/radio-tty/config.toml",
        )
    )
    .expanduser()
    .resolve()
)


@dataclasses.dataclass
class Station:
    name: str
    url: str


@dataclasses.dataclass
class Config:
    stations: list[Station]


# AIDEV-NOTE: raw audio piped via stdin; works for aac/mp3/other raw streams
def stream_raw(url: str) -> None:
    try:
        r = requests.get(url, stream=True)
        ffplay = subprocess.Popen(
            ["ffplay", "-nodisp", "-autoexit", "-i", "pipe:0"],
            stdin=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
        for block in r.iter_content(4096):
            if block:
                ffplay.stdin.write(block)  # ty: ignore
                ffplay.stdin.flush()  # ty: ignore
    except KeyboardInterrupt:
        pass
    finally:
        try:
            ffplay.stdin.close()  # ty: ignore
        except BrokenPipeError:
            pass
        ffplay.wait()


# AIDEV-NOTE: HLS playlists must be fetched by ffplay directly (not piped)
def stream_hls(url: str) -> None:
    try:
        ffplay = subprocess.Popen(
            ["ffplay", "-nodisp", "-autoexit", "-i", url],
            stderr=subprocess.DEVNULL,
        )
        ffplay.wait()
    except KeyboardInterrupt:
        pass


def stream(url: str) -> None:
    if url.endswith(".m3u8"):
        stream_hls(url)
    else:
        stream_raw(url)


def validate_config_value_stations(config_raw: dict[str, Any]):
    if (
        "stations" not in config_raw
        or not isinstance(config_raw["stations"], list)
        or len(config_raw["stations"]) == 0
        or any(
            "name" not in s or "url" not in s for s in config_raw["stations"]
        )
    ):
        raise ValueError(
            "Config requires key 'stations' with type list[{name=.., url=..}]"
        )


def get_config(config_path=CONFIG_PATH) -> Config:
    if not config_path.exists():
        raise FileNotFoundError(
            f"Configuration not found, please create one at {config_path}"
        )

    with open(config_path, "rb") as f:
        config_raw = tomllib.load(f)

    validate_config_value_stations(config_raw)

    return Config(stations=[Station(**s) for s in config_raw["stations"]])


def select_station(stations: list[Station]) -> Station:
    n_digits = math.ceil(math.log(len(stations), 10))
    for i, station in enumerate(stations):
        print(f"{str(i).rjust(n_digits)}: {station.name}")

    idx = None
    while not idx or not idx.isdigit():
        try:
            idx = input("Select station: ")
        except KeyboardInterrupt as err:
            raise err

    return stations[int(idx)]


def main() -> int:
    if not shutil.which("ffplay"):
        raise SystemExit(
            "ffplay not found. Install ffmpeg with your system package "
            "manager (e.g. apt install ffmpeg / brew install ffmpeg)."
        )
    config = get_config()

    if len(config.stations) == 1:
        station = config.stations[1]
    else:
        try:
            station = select_station(config.stations)
        except KeyboardInterrupt:
            return 1

    print(f"Playing {station.name}..")
    stream(url=station.url)
    return 0


if __name__ == "__main__":
    main()
