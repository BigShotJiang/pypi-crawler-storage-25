# radio-tty

Stream internet radio from the terminal using `ffplay`.

## Installation

Install via `uv tool install` (requires [uv](https://github.com/astral-sh/uv)):

```bash
uv tool install git+https://github.com/yourusername/radio-tty
```

Or directly from a local checkout:

```bash
cd radio-tty
uv tool install .
```

This creates a command `radio-tty` that runs the script.

## Usage

```bash
radio-tty
```

Press `Ctrl+C` to stop.

## Configuration

Create `~/.config/radio-tty/config.toml` (or set `RADIO_TTY_CONFIG_PATH`):

```toml
stations = [
    { name = "3PBS", url = "https://23093.live.streamtheworld.com/3PBS_FMAAC.aac" },
    { name = "Triple R", url = "https://realtime.rrr.org.au/p13" },
    { name = "Double J", url = "https://mediaserviceslive.akamaized.net/hls/live/2038342/doublejqld/index.m3u8" },
]
```

Each station requires `name` and `url`. If only one station is defined, it plays immediately.

## Supported formats

- Raw audio streams (AAC, MP3, etc.) - piped via HTTP
- HLS playlists (`.m3u8`) - handled directly by ffplay

## Requirements

- Python ≥3.8
- `ffmpeg` / `ffplay` installed and in `PATH` (e.g. `apt install ffmpeg`, `brew install ffmpeg`)
- `requests` (installed automatically)
