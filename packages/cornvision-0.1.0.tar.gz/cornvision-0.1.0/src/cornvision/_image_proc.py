import numpy as np
import torch
from torchvision.transforms import v2 as T
from torchvision.tv_tensors import Image as TVImage
from torchvision.ops import nms
from torchvision.utils import draw_bounding_boxes


def _prep_image(image):
    image = TVImage(image)
    transforms = [T.ToDtype(torch.float, scale=True), T.ToPureTensor()]
    return T.Compose(transforms)(image)


def detection(image_tensor, model, diagonal_scale=2, nms_iou_thresh=0.1, device="cpu"):
    image_tensor = image_tensor.to(device)

    with torch.no_grad():
        prediction = model([image_tensor])[0]

    pred_boxes = prediction["boxes"].cpu()
    pred_scores = prediction["scores"].cpu()

    keep = nms(pred_boxes, pred_scores, iou_threshold=nms_iou_thresh)
    pred_boxes = pred_boxes[keep]

    if len(pred_boxes) > 0:
        diagonals = torch.sqrt(
            (pred_boxes[:, 2] - pred_boxes[:, 0]) ** 2
            + (pred_boxes[:, 3] - pred_boxes[:, 1]) ** 2
        )
        avg_diagonal = diagonals.mean()
        pred_boxes = pred_boxes[diagonals <= diagonal_scale * avg_diagonal]

    return pred_boxes


def row_viz(clusters, image_tensor, pred_boxes, outlier_indices=None):
    image_for_drawing = (image_tensor * 255).to(torch.uint8)
    boxes_np = pred_boxes.numpy()
    num_nodes = len(boxes_np)

    final_groups_sorted = sorted(
        [group for group in clusters if group],
        key=lambda group: np.mean(boxes_np[group, 1]),
    )

    fixed_color_palette = [
        "red", "green", "blue", "yellow", "orange", "purple",
        "cyan", "magenta", "lime", "pink", "teal", "brown", "navy",
    ]
    num_colors = len(fixed_color_palette)

    colors = ["gray"] * num_nodes
    labels = [""] * num_nodes
    outlier_set = set(outlier_indices) if outlier_indices is not None else set()

    for group_order, group in enumerate(final_groups_sorted):
        group_color = fixed_color_palette[group_order % num_colors]
        for node_index in group:
            if node_index in outlier_set:
                continue
            colors[node_index] = group_color
            labels[node_index] = f"{group_order}"

    for node_index in outlier_set:
        colors[node_index] = "gray"
        labels[node_index] = "X"

    return draw_bounding_boxes(
        image=image_for_drawing,
        boxes=pred_boxes,
        colors=colors,
        labels=labels,
        width=3,
    )


def get_best_matching_row(image_np, row_index, exclude_margin=10):
    h = image_np.shape[0]
    if row_index >= h:
        return None
    start_row = row_index + exclude_margin
    if start_row >= h:
        return None
    ref_row = image_np[row_index].astype(np.float32)
    candidates = image_np[start_row:].astype(np.float32)
    distances = ((candidates - ref_row) ** 2).mean(axis=(1, 2))
    return int(np.argmin(distances)) + start_row


def find_nearest_index(sorted_centers, line):
    if not sorted_centers:
        return -1
    differences = [abs(c_y - line) for c_y in sorted_centers]
    return differences.index(min(differences))
