import logging
from pathlib import Path

import requests

logger = logging.getLogger(__name__)

_MODEL_URL = "https://huggingface.co/crab27/corn-kernel-detection/resolve/main/model.pth"


def default_model_path() -> Path:
    return Path.home() / ".cornvision" / "model.pth"


def download_model(dest: Path | str, url: str = _MODEL_URL) -> None:
    dest = Path(dest)
    if dest.exists():
        logger.info("Using cached model at %s.", dest)
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    logger.info("Downloading model from %s ...", url)
    response = requests.get(url, stream=True)
    response.raise_for_status()
    with open(dest, "wb") as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)
    logger.info("Model downloaded to %s.", dest)
