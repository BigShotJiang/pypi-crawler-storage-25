import bisect
from collections import deque

import numpy as np


def _build_y_sweep_edges(bboxes, edges):
    """
    Sweep line along the Y axis (both directions) to find candidate neighbor pairs.
    Boxes that overlap in Y and are adjacent in X-center order are linked.
    """
    def sweep(direction):
        active_set = []
        inserted_map = {}

        events = []
        for i, box in enumerate(bboxes):
            y1, y2 = box[1], box[3]
            if direction == -1:
                y1, y2 = -y2, -y1
            events.append((y1, 1, i))
            events.append((y2, -1, i))
        events.sort()

        for _, event_type, box_index in events:
            box = bboxes[box_index]
            x_center = (box[0] + box[2]) / 2.0
            entry = (x_center, box_index)

            if event_type == 1:
                pos = bisect.bisect_left(active_set, entry)
                candidates = []
                if pos > 0:
                    candidates.append(active_set[pos - 1][1])
                if pos < len(active_set):
                    candidates.append(active_set[pos][1])
                for cand_index in candidates:
                    u, v = sorted((box_index, cand_index))
                    edges.add((u, v))
                bisect.insort_left(active_set, entry)
                inserted_map[box_index] = entry
            else:
                if box_index in inserted_map:
                    entry = inserted_map.pop(box_index)
                    pos = bisect.bisect_left(active_set, entry)
                    if pos < len(active_set) and active_set[pos] == entry:
                        active_set.pop(pos)

    sweep(1)
    sweep(-1)


def build_neighborhood_graph(bboxes):
    num_boxes = len(bboxes)
    if num_boxes < 2:
        return {i: [] for i in range(num_boxes)}

    edges = set()
    _build_y_sweep_edges(bboxes, edges)

    adj_list = {i: [] for i in range(num_boxes)}
    for u, v in edges:
        adj_list[u].append(v)
        adj_list[v].append(u)

    centers = np.array([[(x1 + x2) / 2, (y1 + y2) / 2] for x1, y1, x2, y2 in bboxes])
    all_edges = []

    for i in range(num_boxes):
        cx_i, cy_i = centers[i]
        x1_i, y1_i, x2_i, y2_i = bboxes[i]

        for j in adj_list[i]:
            cx_j = centers[j][0]
            x1_j, y1_j, x2_j, y2_j = bboxes[j]

            y_overlap = max(0, min(y2_i, y2_j) - max(y1_i, y1_j))
            if y_overlap <= 0:
                continue

            dx = abs(cx_i - cx_j)
            dy = abs(cy_i - centers[j][1])
            x_overlap = max(0, min(x2_i, x2_j) - max(x1_i, x1_j))
            score = y_overlap / (dx + dy + x_overlap + 1e-6)

            direction = "left" if cx_j < cx_i else "right"
            all_edges.append((score, i, j, direction))

    all_edges.sort(reverse=True)

    used_as_left = set()
    used_as_right = set()
    has_left = set()
    has_right = set()
    bidir_adj_list = {i: [] for i in range(num_boxes)}

    for score, wanting_node, candidate_node, direction in all_edges:
        if direction == "left":
            if wanting_node not in has_left and candidate_node not in used_as_left:
                bidir_adj_list[wanting_node].append(candidate_node)
                bidir_adj_list[candidate_node].append(wanting_node)
                has_left.add(wanting_node)
                used_as_left.add(candidate_node)
        else:
            if wanting_node not in has_right and candidate_node not in used_as_right:
                if candidate_node not in bidir_adj_list[wanting_node]:
                    bidir_adj_list[wanting_node].append(candidate_node)
                if wanting_node not in bidir_adj_list[candidate_node]:
                    bidir_adj_list[candidate_node].append(wanting_node)
                has_right.add(wanting_node)
                used_as_right.add(candidate_node)

    return bidir_adj_list


def cluster_by_connectivity(graph, num_nodes):
    remaining_nodes = set(range(num_nodes))
    all_clusters = []

    while remaining_nodes:
        start_node = remaining_nodes.pop()
        current_cluster = []
        queue = deque([start_node])
        visited_in_bfs = {start_node}

        while queue:
            current_node = queue.popleft()
            current_cluster.append(current_node)
            for neighbor in graph.get(current_node, []):
                if neighbor not in visited_in_bfs:
                    visited_in_bfs.add(neighbor)
                    queue.append(neighbor)
                    remaining_nodes.discard(neighbor)

        all_clusters.append(current_cluster)

    return all_clusters


def row_clustering(pred_boxes):
    pred_boxes_np = pred_boxes.numpy()
    num_nodes = len(pred_boxes_np)
    neighborhood_graph = build_neighborhood_graph(pred_boxes_np)
    return cluster_by_connectivity(neighborhood_graph, num_nodes)


def flag_outlier_rows_by_xrange(clusters, bboxes, x_range_ratio_thresh=0.7):
    if not clusters:
        return [], []

    bboxes_np = bboxes.cpu().numpy() if hasattr(bboxes, "cpu") else bboxes

    cluster_meta = []
    for cluster in clusters:
        if not cluster:
            continue
        xs = [bboxes_np[i][0] for i in cluster] + [bboxes_np[i][2] for i in cluster]
        cluster_meta.append({"members": cluster, "x_range": max(xs) - min(xs)})

    if not cluster_meta:
        return [], []

    max_x_range = max(c["x_range"] for c in cluster_meta)
    if max_x_range == 0:
        return [c["members"] for c in cluster_meta], []

    normal_clusters = []
    outlier_indices = []
    for meta in cluster_meta:
        if meta["x_range"] >= x_range_ratio_thresh * max_x_range:
            normal_clusters.append(meta["members"])
        else:
            outlier_indices.extend(meta["members"])

    return normal_clusters, outlier_indices


def compute_row_centers(clusters, pred_boxes_np):
    centers = []
    for cluster in clusters:
        if not cluster:
            centers.append(None)
        else:
            ys = [(pred_boxes_np[i][1] + pred_boxes_np[i][3]) / 2 for i in cluster]
            centers.append(np.mean(ys))
    return centers
