from __future__ import annotations

import logging
from pathlib import Path
from typing import Union

import numpy as np
import torch
from PIL import Image as PILImage

from cornvision._download import default_model_path, download_model
from cornvision._model import load_model
from cornvision._inference import run_inference
from cornvision._result import AnalysisResult

logger = logging.getLogger(__name__)


def _get_device() -> str:
    if torch.cuda.is_available():
        return "cuda"
    if torch.backends.mps.is_available():
        return "mps"
    return "cpu"


class CornAnalyzer:
    """Load the model once, analyze as many images as needed.

    Args:
        device: Inference device. ``"auto"`` picks CUDA → MPS → CPU.
        model_path: Path to ``model.pth``. Defaults to ``~/.cornvision/model.pth``.
        download: Download weights from HuggingFace if not found locally.
    """

    def __init__(
        self,
        device: str = "auto",
        model_path: str | Path | None = None,
        download: bool = True,
    ) -> None:
        if device == "auto":
            device = _get_device()
        self.device = device

        if model_path is None:
            model_path = default_model_path()
        model_path = Path(model_path)

        if not model_path.exists():
            if not download:
                raise FileNotFoundError(
                    f"Model weights not found at {model_path}. "
                    "Pass download=True or point model_path at an existing file."
                )
            download_model(model_path)

        logger.info("Loading model from %s on %s.", model_path, device)
        self._model = load_model(str(model_path), device=device)
        logger.info("Model ready.")

    def analyze(
        self,
        image: Union[str, Path, PILImage.Image, np.ndarray],
        file: str | None = None,
    ) -> AnalysisResult:
        """Analyze a single corn ear image.

        Args:
            image: File path, PIL Image, or numpy array (H×W×C, uint8).
            file: Override the filename recorded in the result.

        Returns:
            :class:`AnalysisResult` with counts, measurements, and a
            visualization image accessible via :meth:`~AnalysisResult.save_viz`.
        """
        if isinstance(image, (str, Path)):
            file = file or Path(image).name
            image = PILImage.open(image).convert("RGB")
        elif isinstance(image, np.ndarray):
            image = PILImage.fromarray(image).convert("RGB")
        elif isinstance(image, PILImage.Image):
            image = image.convert("RGB")
        else:
            raise TypeError(f"Unsupported image type: {type(image)}")

        raw = run_inference(image, self._model, device=self.device)
        return AnalysisResult._from_raw(raw, file=file)
