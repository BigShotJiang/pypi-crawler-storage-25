"""CornVision GUI — single and batch inference."""
from __future__ import annotations

import csv
import io
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from PIL import Image, ImageTk

from cornvision._analyzer import CornAnalyzer
from cornvision._result import AnalysisResult

_IMG_TYPES = [
    ("Images", "*.jpg *.jpeg *.png *.tif *.tiff *.bmp"),
    ("All files", "*.*"),
]

# per-item state labels shown in the queue list
_ICON = {"pending": "○", "running": "↻", "done": "✓", "error": "✗"}


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("CornVision")
        self.resizable(True, True)

        self._analyzer: CornAnalyzer | None = None
        self._queue: list[str] = []
        self._results: dict[str, AnalysisResult] = {}
        self._errors: dict[str, str] = {}
        self._item_status: dict[str, str] = {}
        self._selected: str | None = None
        self._stop = threading.Event()

        self._build()

    # ------------------------------------------------------------------ layout

    def _build(self):
        # ── top bar ──────────────────────────────────────────────────────────
        top = ttk.Frame(self, padding=(10, 8))
        top.pack(fill=tk.X)

        ttk.Button(top, text="Add Images…", command=self._add_images).pack(side=tk.LEFT)
        ttk.Button(top, text="Remove", command=self._remove_selected).pack(side=tk.LEFT, padx=4)
        ttk.Button(top, text="Clear All", command=self._clear_all).pack(side=tk.LEFT)

        ttk.Separator(top, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=12)

        ttk.Label(top, text="Device:").pack(side=tk.LEFT)
        self._device_var = tk.StringVar(value="auto")
        ttk.Combobox(
            top, textvariable=self._device_var,
            values=["auto", "cpu", "cuda", "mps"],
            width=7, state="readonly",
        ).pack(side=tk.LEFT, padx=(4, 12))

        # ── main area: queue list + image previews ────────────────────────────
        main = ttk.Frame(self, padding=(10, 0))
        main.pack(fill=tk.BOTH, expand=True)

        # queue list
        list_frame = ttk.LabelFrame(main, text="Queue", padding=4)
        list_frame.pack(side=tk.LEFT, fill=tk.BOTH, padx=(0, 6))
        list_frame.configure(width=220)
        list_frame.pack_propagate(False)

        self._listbox = tk.Listbox(list_frame, selectmode=tk.SINGLE,
                                   activestyle="none", width=26)
        sb = ttk.Scrollbar(list_frame, orient=tk.VERTICAL,
                            command=self._listbox.yview)
        self._listbox.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self._listbox.pack(fill=tk.BOTH, expand=True)
        self._listbox.bind("<<ListboxSelect>>", self._on_list_select)

        # image panels
        panels = ttk.Frame(main)
        panels.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        lf_in = ttk.LabelFrame(panels, text="Input", padding=4)
        lf_in.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 4))
        self._input_lbl = ttk.Label(lf_in, anchor="center")
        self._input_lbl.pack(fill=tk.BOTH, expand=True)

        lf_out = ttk.LabelFrame(panels, text="Annotated", padding=4)
        lf_out.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._output_lbl = ttk.Label(lf_out, anchor="center")
        self._output_lbl.pack(fill=tk.BOTH, expand=True)

        # ── results treeview ─────────────────────────────────────────────────
        rf = ttk.LabelFrame(self, text="Results", padding=(6, 4))
        rf.pack(fill=tk.X, padx=10, pady=(6, 0))

        cols = ("file", "kernels", "rows", "kernels_per_row", "time_s")
        self._tree = ttk.Treeview(rf, columns=cols, show="headings", height=5)
        for col, heading, width in [
            ("file",           "File",             200),
            ("kernels",        "Kernels",           70),
            ("rows",           "Rows",              50),
            ("kernels_per_row","Kernels / Row",     300),
            ("time_s",         "Time (s)",          70),
        ]:
            self._tree.heading(col, text=heading)
            self._tree.column(col, width=width, anchor=tk.W)

        tree_sb = ttk.Scrollbar(rf, orient=tk.VERTICAL, command=self._tree.yview)
        self._tree.configure(yscrollcommand=tree_sb.set)
        tree_sb.pack(side=tk.RIGHT, fill=tk.Y)
        self._tree.pack(fill=tk.X)
        self._tree.bind("<<TreeviewSelect>>", self._on_tree_select)

        # ── action bar ───────────────────────────────────────────────────────
        actions = ttk.Frame(self, padding=(10, 6))
        actions.pack(fill=tk.X)

        self._run_btn = ttk.Button(actions, text="Analyze All",
                                   command=self._run_batch, width=14)
        self._run_btn.pack(side=tk.LEFT)

        self._stop_btn = ttk.Button(actions, text="Stop",
                                    command=self._request_stop,
                                    state=tk.DISABLED, width=8)
        self._stop_btn.pack(side=tk.LEFT, padx=6)

        self._save_btn = ttk.Button(actions, text="Save Annotated…",
                                    command=self._save_viz,
                                    state=tk.DISABLED, width=16)
        self._save_btn.pack(side=tk.LEFT, padx=6)

        ttk.Button(actions, text="Export CSV…",
                   command=self._export_csv).pack(side=tk.LEFT)

        self._status_var = tk.StringVar(value="")
        ttk.Label(actions, textvariable=self._status_var,
                  foreground="gray").pack(side=tk.LEFT, padx=12)

        self.update_idletasks()
        self.minsize(980, 620)

    # ------------------------------------------------------------------ queue management

    def _add_images(self):
        paths = filedialog.askopenfilenames(filetypes=_IMG_TYPES)
        for p in paths:
            if p not in self._item_status:
                self._queue.append(p)
                self._item_status[p] = "pending"
                self._listbox.insert(tk.END, f"{_ICON['pending']}  {Path(p).name}")
        self._status_var.set(f"{len(self._queue)} image(s) in queue.")

    def _remove_selected(self):
        sel = self._listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        path = self._queue[idx]
        if self._item_status.get(path) == "running":
            return
        self._queue.pop(idx)
        self._item_status.pop(path, None)
        self._results.pop(path, None)
        self._errors.pop(path, None)
        self._listbox.delete(idx)
        self._tree_remove(path)
        if self._selected == path:
            self._selected = None
            self._input_lbl.config(image="")
            self._output_lbl.config(image="")
            self._save_btn.config(state=tk.DISABLED)

    def _clear_all(self):
        running = any(s == "running" for s in self._item_status.values())
        if running:
            messagebox.showwarning("Busy", "Stop the current run before clearing.")
            return
        self._queue.clear()
        self._item_status.clear()
        self._results.clear()
        self._errors.clear()
        self._listbox.delete(0, tk.END)
        for row in self._tree.get_children():
            self._tree.delete(row)
        self._selected = None
        self._input_lbl.config(image="")
        self._output_lbl.config(image="")
        self._save_btn.config(state=tk.DISABLED)
        self._status_var.set("")

    # ------------------------------------------------------------------ list / tree interaction

    def _on_list_select(self, _event=None):
        sel = self._listbox.curselection()
        if not sel:
            return
        path = self._queue[sel[0]]
        self._select_path(path)

    def _on_tree_select(self, _event=None):
        sel = self._tree.selection()
        if not sel:
            return
        path = self._tree.item(sel[0], "values")[0]
        # find full path (tree stores basename; match via queue)
        for p in self._queue:
            if p == path or Path(p).name == path:
                self._select_path(p)
                return

    def _select_path(self, path: str):
        self._selected = path
        try:
            self._show_image(path, self._input_lbl)
        except Exception:
            self._input_lbl.config(image="")

        result = self._results.get(path)
        if result and result.viz_image:
            self._show_image(result.viz_image, self._output_lbl)
            self._save_btn.config(state=tk.NORMAL)
        else:
            self._output_lbl.config(image="")
            self._save_btn.config(state=tk.DISABLED)

    # ------------------------------------------------------------------ analysis

    def _run_batch(self):
        pending = [p for p in self._queue if self._item_status[p] == "pending"]
        if not pending:
            messagebox.showinfo("Nothing to do",
                                "No pending images. Add images or check queue status.")
            return
        self._stop.clear()
        self._run_btn.config(state=tk.DISABLED)
        self._stop_btn.config(state=tk.NORMAL)
        threading.Thread(target=self._batch_worker, args=(pending,), daemon=True).start()

    def _request_stop(self):
        self._stop.set()
        self._status_var.set("Stopping after current image…")

    def _batch_worker(self, paths: list[str]):
        total = len(paths)
        try:
            if self._analyzer is None:
                self.after(0, lambda: self._status_var.set("Loading model…"))
                self._analyzer = CornAnalyzer(device=self._device_var.get())
        except Exception as exc:
            self.after(0, lambda: self._on_batch_error(str(exc)))
            return

        for i, path in enumerate(paths, 1):
            if self._stop.is_set():
                break
            self.after(0, lambda p=path, n=i, t=total: self._mark_running(p, n, t))
            try:
                result = self._analyzer.analyze(path)
                self.after(0, lambda p=path, r=result: self._mark_done(p, r))
            except Exception as exc:
                self.after(0, lambda p=path, e=str(exc): self._mark_error(p, e))

        self.after(0, self._on_batch_finished)

    def _mark_running(self, path: str, n: int, total: int):
        self._item_status[path] = "running"
        self._refresh_list_item(path)
        self._status_var.set(f"Processing {n}/{total}: {Path(path).name}")

    def _mark_done(self, path: str, result: AnalysisResult):
        self._item_status[path] = "done"
        self._results[path] = result
        self._refresh_list_item(path)
        self._tree_upsert(path, result)
        if self._selected == path:
            if result.viz_image:
                self._show_image(result.viz_image, self._output_lbl)
                self._save_btn.config(state=tk.NORMAL)

    def _mark_error(self, path: str, msg: str):
        self._item_status[path] = "error"
        self._errors[path] = msg
        self._refresh_list_item(path)

    def _on_batch_error(self, msg: str):
        self._run_btn.config(state=tk.NORMAL)
        self._stop_btn.config(state=tk.DISABLED)
        self._status_var.set("Error.")
        messagebox.showerror("Failed to load model", msg)

    def _on_batch_finished(self):
        self._run_btn.config(state=tk.NORMAL)
        self._stop_btn.config(state=tk.DISABLED)
        done = sum(1 for s in self._item_status.values() if s == "done")
        errors = sum(1 for s in self._item_status.values() if s == "error")
        parts = [f"{done} done"]
        if errors:
            parts.append(f"{errors} error(s)")
        self._status_var.set("  ·  ".join(parts))

    # ------------------------------------------------------------------ list / tree helpers

    def _refresh_list_item(self, path: str):
        idx = self._queue.index(path)
        status = self._item_status[path]
        self._listbox.delete(idx)
        self._listbox.insert(idx, f"{_ICON[status]}  {Path(path).name}")
        if status == "error":
            self._listbox.itemconfig(idx, foreground="red")
        elif status == "done":
            self._listbox.itemconfig(idx, foreground="green")

    def _tree_upsert(self, path: str, r: AnalysisResult):
        row_id = path
        values = (
            Path(path).name,
            r.total_kernels,
            r.total_rows,
            str(r.kernels_per_row),
            f"{r.inference_time_sec:.2f}",
        )
        if self._tree.exists(row_id):
            self._tree.item(row_id, values=values)
        else:
            self._tree.insert("", tk.END, iid=row_id, values=values)

    def _tree_remove(self, path: str):
        if self._tree.exists(path):
            self._tree.delete(path)

    # ------------------------------------------------------------------ image display

    def _show_image(self, source, label: ttk.Label,
                    max_size: tuple[int, int] = (380, 340)):
        img = Image.open(source) if isinstance(source, (str, Path)) else source
        img = img.copy()
        img.thumbnail(max_size, Image.LANCZOS)
        photo = ImageTk.PhotoImage(img)
        label.config(image=photo)
        label._photo = photo

    # ------------------------------------------------------------------ file actions

    def _save_viz(self):
        if not self._selected:
            return
        result = self._results.get(self._selected)
        if result is None:
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg *.jpeg")],
            initialfile=Path(self._selected).stem + "_annotated.png",
        )
        if path:
            result.save_viz(path)
            self._status_var.set(f"Saved → {Path(path).name}")

    def _export_csv(self):
        done = {p: r for p, r in self._results.items()}
        if not done:
            messagebox.showinfo("No results", "Run analysis first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV", "*.csv")],
            initialfile="cornvision_results.csv",
        )
        if not path:
            return
        buf = io.StringIO()
        fieldnames = ["file", "total_kernels", "total_rows",
                      "kernels_per_row", "inference_time_sec",
                      "average_kernel_width_mm", "average_kernel_height_mm"]
        writer = csv.DictWriter(buf, fieldnames=fieldnames)
        writer.writeheader()
        for img_path, r in done.items():
            writer.writerow({
                "file": Path(img_path).name,
                "total_kernels": r.total_kernels,
                "total_rows": r.total_rows,
                "kernels_per_row": str(r.kernels_per_row),
                "inference_time_sec": round(r.inference_time_sec, 3),
                "average_kernel_width_mm": round(r.average_kernel_width_mm, 2),
                "average_kernel_height_mm": round(r.average_kernel_height_mm, 2),
            })
        Path(path).write_text(buf.getvalue(), encoding="utf-8")
        self._status_var.set(f"Exported {len(done)} row(s) → {Path(path).name}")


def main():
    App().mainloop()


if __name__ == "__main__":
    main()
