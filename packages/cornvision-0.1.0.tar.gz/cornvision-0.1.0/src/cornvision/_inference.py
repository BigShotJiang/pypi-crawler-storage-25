import time
from typing import Any

import numpy as np
import torch
from PIL import Image
from torchvision.transforms import v2 as T

from cornvision._config import (
    DIAGONAL_SCALE,
    EXCLUDE_MARGIN,
    NMS_IOU_THRESH,
    PX_TO_MM,
    X_RANGE_RATIO_THRESH,
)
from cornvision._clustering import (
    compute_row_centers,
    flag_outlier_rows_by_xrange,
    row_clustering,
)
from cornvision._image_proc import (
    _prep_image,
    detection,
    find_nearest_index,
    get_best_matching_row,
    row_viz,
)


def _build_response(
    *,
    total_kernels: int,
    total_rows: int,
    kernels_per_row: list[int],
    inference_time_sec: float,
    result_image: Image.Image | None,
    all_boxes: np.ndarray | None = None,
    initial_clusters: list[list[int]] | None = None,
    final_clusters: list[list[int]] | None = None,
    message: str | None = None,
    average_kernel_height_mm: float = 0.0,
    average_kernel_width_mm: float = 0.0,
) -> dict[str, Any]:
    output: dict[str, Any] = {
        "total_kernels": total_kernels,
        "total_rows": total_rows,
        "kernels_per_row": kernels_per_row,
        "inference_time_sec": inference_time_sec,
        "result_image": result_image,
        "average_kernel_height_mm": average_kernel_height_mm,
        "average_kernel_width_mm": average_kernel_width_mm,
    }
    if message:
        output["message"] = message
    if all_boxes is not None:
        output["all_boxes"] = all_boxes.tolist()
    if initial_clusters is not None:
        output["initial_clusters"] = initial_clusters
    if final_clusters is not None:
        output["final_clusters"] = final_clusters
    return output


def _early_result(
    pred_boxes: torch.Tensor,
    pred_boxes_np: np.ndarray,
    image_tensor: torch.Tensor,
    sorted_initial_clusters: list[list[int]],
    start_time: float,
    message: str,
) -> dict[str, Any]:
    vis = row_viz(sorted_initial_clusters, image_tensor, pred_boxes)
    return _build_response(
        total_kernels=len(pred_boxes),
        total_rows=len(sorted_initial_clusters),
        kernels_per_row=[len(c) for c in sorted_initial_clusters],
        inference_time_sec=time.time() - start_time,
        result_image=T.ToPILImage()(vis),
        all_boxes=pred_boxes_np,
        initial_clusters=sorted_initial_clusters,
        message=message,
    )


def run_inference(image: Image.Image, model: torch.nn.Module, device: str = "cpu") -> dict[str, Any]:
    start_time = time.time()
    image_tensor = _prep_image(image)
    pred_boxes = detection(
        image_tensor, model,
        diagonal_scale=DIAGONAL_SCALE,
        nms_iou_thresh=NMS_IOU_THRESH,
        device=device,
    )
    pred_boxes_np = pred_boxes.numpy()

    if len(pred_boxes) == 0:
        return _build_response(
            message="No objects detected.",
            total_kernels=0,
            total_rows=0,
            kernels_per_row=[],
            inference_time_sec=time.time() - start_time,
            result_image=None,
        )

    initial_clusters = row_clustering(pred_boxes)

    sorted_initial_clusters = sorted(
        initial_clusters,
        key=lambda c: np.mean([(pred_boxes_np[i][1] + pred_boxes_np[i][3]) / 2 for i in c]),
    )

    centers = compute_row_centers(initial_clusters, pred_boxes_np)
    valid_centers = sorted(
        [(i, c) for i, c in enumerate(centers) if c is not None],
        key=lambda x: x[1],
    )

    if len(valid_centers) < 3:
        return _early_result(
            pred_boxes, pred_boxes_np, image_tensor,
            sorted_initial_clusters, start_time,
            "Insufficient valid cluster centers found.",
        )

    sorted_indices, sorted_centers = zip(*valid_centers)
    y_center = int(sorted_centers[2])
    img_np = image_tensor.permute(1, 2, 0).cpu().numpy()
    best_match_y = get_best_matching_row(img_np, y_center, exclude_margin=EXCLUDE_MARGIN)

    if best_match_y is None:
        return _early_result(
            pred_boxes, pred_boxes_np, image_tensor,
            sorted_initial_clusters, start_time,
            "Could not find a best matching row.",
        )

    top_line, bottom_line = sorted((y_center, best_match_y))
    start_idx = find_nearest_index(sorted_centers, top_line)
    end_idx = find_nearest_index(sorted_centers, bottom_line)

    if not (0 <= start_idx < end_idx < len(sorted_centers)):
        return _early_result(
            pred_boxes, pred_boxes_np, image_tensor,
            sorted_initial_clusters, start_time,
            "Invalid region of interest determined.",
        )

    inlier_cluster_indices = sorted_indices[start_idx:end_idx]
    inlier_box_indices = [
        box_idx for idx in inlier_cluster_indices for box_idx in initial_clusters[idx]
    ]

    if not inlier_box_indices:
        return _build_response(
            message="No inlier boxes found after filtering.",
            total_kernels=0,
            total_rows=0,
            kernels_per_row=[],
            inference_time_sec=time.time() - start_time,
            result_image=None,
            all_boxes=pred_boxes_np,
            initial_clusters=sorted_initial_clusters,
        )

    filtered_pred_boxes = pred_boxes[inlier_box_indices]
    box_idx_map = {old: new for new, old in enumerate(inlier_box_indices)}

    filtered_clusters = [
        [box_idx_map[i] for i in initial_clusters[idx] if i in box_idx_map]
        for idx in inlier_cluster_indices
    ]
    filtered_clusters = [c for c in filtered_clusters if c]

    final_clusters, outlier_indices = flag_outlier_rows_by_xrange(
        filtered_clusters, filtered_pred_boxes, x_range_ratio_thresh=X_RANGE_RATIO_THRESH
    )

    vis_image_tensor = row_viz(final_clusters, image_tensor, filtered_pred_boxes, outlier_indices)
    elapsed = time.time() - start_time

    total_kernels = len(filtered_pred_boxes)
    kernel_height, kernel_width = 0.0, 0.0
    if total_kernels > 0:
        kernel_height = (filtered_pred_boxes[:, 3] - filtered_pred_boxes[:, 1]).mean().item() * PX_TO_MM
        kernel_width = (filtered_pred_boxes[:, 2] - filtered_pred_boxes[:, 0]).mean().item() * PX_TO_MM

    remapped_final_clusters = [
        [inlier_box_indices[i] for i in cluster] for cluster in final_clusters
    ]

    return _build_response(
        total_kernels=total_kernels,
        total_rows=len(final_clusters),
        kernels_per_row=[len(cluster) for cluster in final_clusters],
        inference_time_sec=elapsed,
        average_kernel_height_mm=kernel_height,
        average_kernel_width_mm=kernel_width,
        result_image=T.ToPILImage()(vis_image_tensor),
        all_boxes=pred_boxes_np,
        initial_clusters=sorted_initial_clusters,
        final_clusters=remapped_final_clusters,
    )
