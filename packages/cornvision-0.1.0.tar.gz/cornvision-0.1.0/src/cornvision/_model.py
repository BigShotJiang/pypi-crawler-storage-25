import torch
import torchvision
from torchvision.models.detection.faster_rcnn import (
    AnchorGenerator,
    RPNHead,
    RegionProposalNetwork,
    FastRCNNPredictor,
)


def _build_model(num_classes: int = 2, target_proposals: int = 2000) -> torchvision.models.detection.FasterRCNN:
    model = torchvision.models.detection.fasterrcnn_resnet50_fpn_v2(weights=None)

    anchor_generator = AnchorGenerator(
        sizes=((8,), (10,), (12,), (14,), (16,)),
        aspect_ratios=((0.5, 1.0, 2.0),) * 5,
    )

    backbone_out_channels = model.backbone.out_channels
    rpn_head = RPNHead(backbone_out_channels, anchor_generator.num_anchors_per_location()[0])

    model.rpn = RegionProposalNetwork(
        anchor_generator=anchor_generator,
        head=rpn_head,
        fg_iou_thresh=0.7,
        bg_iou_thresh=0.3,
        batch_size_per_image=256,
        positive_fraction=0.5,
        pre_nms_top_n={"training": 2000, "testing": 2000},
        post_nms_top_n={"training": target_proposals, "testing": target_proposals},
        nms_thresh=0.7,
        score_thresh=0.0,
    )

    in_features = model.roi_heads.box_predictor.cls_score.in_features
    model.roi_heads.box_predictor = FastRCNNPredictor(in_features, num_classes)
    model.roi_heads.detections_per_img = 1500

    return model


def load_model(model_path: str, device: str = "cpu") -> torch.nn.Module:
    model = _build_model(num_classes=2, target_proposals=2000)
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.to(device)
    model.eval()
    return model
