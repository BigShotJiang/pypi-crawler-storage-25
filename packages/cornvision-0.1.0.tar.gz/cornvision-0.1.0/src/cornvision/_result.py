from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from PIL import Image as PILImage


@dataclass
class AnalysisResult:
    total_kernels: int
    total_rows: int
    kernels_per_row: list[int]
    inference_time_sec: float
    average_kernel_height_mm: float
    average_kernel_width_mm: float
    file: str | None = None
    # power-user fields: raw detection data
    all_boxes: list[list[float]] = field(default_factory=list)
    initial_clusters: list[list[int]] = field(default_factory=list)
    final_clusters: list[list[int]] = field(default_factory=list)
    viz_image: "PILImage.Image | None" = field(default=None, repr=False)

    def save_viz(self, path: str | Path) -> None:
        """Save the annotated result image to disk."""
        if self.viz_image is None:
            raise RuntimeError("No visualization image available.")
        self.viz_image.save(str(path))

    def to_dict(self) -> dict[str, Any]:
        """JSON-serializable summary; excludes raw detection data and viz image."""
        d: dict[str, Any] = {
            "total_kernels": self.total_kernels,
            "total_rows": self.total_rows,
            "kernels_per_row": self.kernels_per_row,
            "inference_time_sec": round(self.inference_time_sec, 3),
            "average_kernel_height_mm": round(self.average_kernel_height_mm, 2),
            "average_kernel_width_mm": round(self.average_kernel_width_mm, 2),
        }
        if self.file is not None:
            d = {"file": self.file, **d}
        return d

    def to_json(self, indent: int | None = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    @classmethod
    def _from_raw(cls, raw: dict[str, Any], file: str | None = None) -> AnalysisResult:
        return cls(
            file=file,
            total_kernels=raw.get("total_kernels", 0),
            total_rows=raw.get("total_rows", 0),
            kernels_per_row=raw.get("kernels_per_row", []),
            inference_time_sec=raw.get("inference_time_sec", 0.0),
            average_kernel_height_mm=raw.get("average_kernel_height_mm", 0.0),
            average_kernel_width_mm=raw.get("average_kernel_width_mm", 0.0),
            all_boxes=raw.get("all_boxes", []),
            initial_clusters=raw.get("initial_clusters", []),
            final_clusters=raw.get("final_clusters", []),
            viz_image=raw.get("result_image"),
        )
