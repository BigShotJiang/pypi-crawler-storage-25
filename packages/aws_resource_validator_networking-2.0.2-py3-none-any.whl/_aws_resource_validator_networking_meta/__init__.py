"""Metapackage marker for aws-resource-validator-networking."""
