"""Generated resource modules."""
