"""
Symbol catalog example - discover available instruments before subscribing.

The catalog() method queries the REST API, so no WebSocket connection is
needed. Use it to build symbol pickers, validate user input, or browse
what is available.

Usage:
    pip install lse-data
    python catalog_lookup.py
"""

from lse import LSE

client = LSE(api_key="YOUR_API_KEY")

# Get everything
all_symbols = client.catalog()
print(f"{len(all_symbols)} total instruments\n")

# Browse by category
for category in ["crypto", "forex", "stock", "etf", "commodity", "index"]:
    items = client.catalog(category=category)
    print(f"{category:12s} {len(items):>5} symbols")
    # Show first 3 as examples
    for s in items[:3]:
        print(f"  {s['symbol']:12s} {s['display_name']}")
    print()
