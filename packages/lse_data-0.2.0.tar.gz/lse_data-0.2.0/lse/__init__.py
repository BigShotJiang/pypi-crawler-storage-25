"""
London Strategic Edge - Python SDK for real-time market data.

Usage:
    from lse import LSE

    client = LSE(api_key="your_api_key")

    # Stream live ticks
    for tick in client.stream(["BTC/USD", "AAPL", "EUR/USD"]):
        print(f"{tick.symbol} {tick.price}")

    # Async streaming
    async for tick in client.stream_async(["BTC/USD"]):
        print(tick)
"""

from lse.client import LSE, Tick

__version__ = "0.2.0"
__all__ = ["LSE", "Tick"]
