"""
LSE WebSocket client for real-time market data streaming.

Connects to wss://data-ws.londonstrategicedge.com and provides a clean
interface for subscribing to symbols and receiving live price ticks.
"""

import asyncio
import json
import threading
import time
import urllib.request
import urllib.parse
from dataclasses import dataclass, field
from typing import Callable, Dict, Iterator, List, Optional, Set

import websockets
import websockets.client


WS_URL = "wss://data-ws.londonstrategicedge.com"

# REST API for querying the symbol catalog (x_websocket table via PostgREST).
# No auth required for read-only symbol lookups.
API_URL = "https://api.londonstrategicedge.com"
API_KEY_HEADER = "x-api-key"
API_KEY_VALUE = "71f880e1d2ef471664f3b6c04c6dc1e618f94e51f68c87522bc6dcbc0ca173a5"

# Ping interval to keep the connection alive. The server expects a ping
# within its idle timeout window (currently 600s). We send every 25s to
# stay well under the server's 30s protocol-level ping interval.
PING_INTERVAL = 25


@dataclass
class Tick:
    """A single price tick from the LSE feed."""
    symbol: str
    price: float
    bid: Optional[float] = None
    ask: Optional[float] = None
    volume: Optional[float] = None
    timestamp: Optional[float] = None
    name: Optional[str] = None

    def __repr__(self) -> str:
        return f"Tick({self.symbol} {self.price})"


class LSE:
    """Client for London Strategic Edge real-time market data.

    Args:
        api_key: Your LSE API key. Get one at https://londonstrategicedge.com/data
        url: WebSocket endpoint. Defaults to the production server.

    Examples:
        Synchronous streaming (simplest):

            from lse import LSE

            client = LSE(api_key="your_key")
            for tick in client.stream(["BTC/USD", "AAPL"]):
                print(tick.symbol, tick.price)

        With a callback:

            def on_tick(tick):
                print(f"{tick.symbol}: {tick.price}")

            client = LSE(api_key="your_key")
            client.on("tick", on_tick)
            client.subscribe(["BTC/USD", "ETH/USD"])
            client.connect()  # blocks forever

        Async streaming:

            import asyncio
            from lse import LSE

            async def main():
                client = LSE(api_key="your_key")
                async for tick in client.stream_async(["BTC/USD"]):
                    print(tick)

            asyncio.run(main())
    """

    def __init__(self, api_key: str, url: str = WS_URL):
        self._api_key = api_key
        self._url = url
        self._ws: Optional[websockets.client.WebSocketClientProtocol] = None
        self._callbacks: Dict[str, List[Callable]] = {}
        self._symbols: List[dict] = []
        self._tier: str = ""
        self._authenticated = False
        self._subscriptions: Set[str] = set()

    # ------------------------------------------------------------------
    # Symbol Catalog (REST, no WebSocket needed)
    # ------------------------------------------------------------------

    def catalog(self, category: Optional[str] = None) -> List[dict]:
        """Query the full symbol catalog from the LSE API.

        Returns every instrument available on the WebSocket feed. Works
        without a WebSocket connection, so you can inspect the catalog
        before subscribing. Like Databento's metadata.list_datasets().

        Args:
            category: Optional filter. One of: stock, crypto, forex,
                      etf, commodity, index. None returns all.

        Returns:
            List of dicts with 'symbol', 'display_name', 'category'.

        Example:
            client = LSE(api_key="your_key")
            stocks = client.catalog(category="stock")
            print(f"{len(stocks)} stocks available")
            # [{'symbol': 'AAPL', 'display_name': 'Apple Inc.', 'category': 'stock'}, ...]
        """
        params = {"select": "symbol,display_name,category", "order": "symbol"}
        if category:
            params["category"] = f"eq.{category.lower()}"

        url = f"{API_URL}/x_websocket?{urllib.parse.urlencode(params)}"
        req = urllib.request.Request(url, headers={
            "Accept": "application/json",
            API_KEY_HEADER: API_KEY_VALUE,
            # User-Agent required to pass Cloudflare WAF, which blocks
            # Python's default "Python-urllib/3.x" agent string
            "User-Agent": "lse-data/0.2.0",
        })
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read().decode())
        except Exception as e:
            raise ConnectionError(f"Failed to fetch symbol catalog: {e}") from e

    # ------------------------------------------------------------------
    # Public properties
    # ------------------------------------------------------------------

    @property
    def symbols(self) -> List[dict]:
        """List of available symbols returned after authentication."""
        return self._symbols

    @property
    def tier(self) -> str:
        """Account tier (e.g. 'basic', 'pro')."""
        return self._tier

    @property
    def authenticated(self) -> bool:
        """Whether the client has successfully authenticated."""
        return self._authenticated

    @property
    def subscriptions(self) -> Set[str]:
        """Set of currently subscribed symbols."""
        return self._subscriptions.copy()

    # ------------------------------------------------------------------
    # Event callbacks
    # ------------------------------------------------------------------

    def on(self, event: str, callback: Callable) -> "LSE":
        """Register a callback for an event.

        Supported events:
            - "tick": called with a Tick object on each price update
            - "connected": called when WebSocket connects
            - "authenticated": called when auth succeeds
            - "disconnected": called when connection drops
            - "error": called with error message string

        Args:
            event: Event name.
            callback: Function to call.

        Returns:
            self, for chaining.
        """
        self._callbacks.setdefault(event, []).append(callback)
        return self

    def _emit(self, event: str, *args):
        for cb in self._callbacks.get(event, []):
            try:
                cb(*args)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Synchronous API (blocking)
    # ------------------------------------------------------------------

    def stream(self, symbols: List[str], reconnect: bool = True) -> Iterator[Tick]:
        """Stream live ticks. Blocks forever, yields Tick objects.

        This is the simplest way to consume live data. It handles connection,
        authentication, subscription, ping/pong, and auto-reconnect internally.

        Args:
            symbols: List of symbols to subscribe to (e.g. ["BTC/USD", "AAPL"]).
            reconnect: If True, automatically reconnect on disconnect.

        Yields:
            Tick objects as they arrive.

        Example:
            from lse import LSE

            client = LSE(api_key="your_key")
            for tick in client.stream(["BTC/USD", "ETH/USD", "AAPL"]):
                print(f"{tick.symbol}: ${tick.price}")
        """
        while True:
            try:
                # Run the async generator in a new event loop.
                # We suppress "task was destroyed" warnings that occur when
                # the caller breaks out of the iterator mid-stream, which is
                # normal usage (e.g. "for tick in stream: if done: break").
                import warnings
                loop = asyncio.new_event_loop()
                try:
                    gen = self.stream_async(symbols, reconnect=False).__aiter__()
                    while True:
                        tick = loop.run_until_complete(gen.__anext__())
                        yield tick
                except StopAsyncIteration:
                    pass
                except GeneratorExit:
                    return
                finally:
                    # Shut down pending tasks cleanly to avoid warnings
                    pending = asyncio.all_tasks(loop)
                    for task in pending:
                        task.cancel()
                    if pending:
                        with warnings.catch_warnings():
                            warnings.simplefilter("ignore")
                            loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
                    loop.close()
            except Exception as e:
                self._emit("error", str(e))
                if not reconnect:
                    raise
                time.sleep(3)

    def connect(self, symbols: Optional[List[str]] = None):
        """Connect and block forever, dispatching events via callbacks.

        Use this with .on("tick", callback) for event-driven usage.
        For iterator-style usage, use .stream() instead.

        Args:
            symbols: Optional list of symbols to subscribe to on connect.
                     You can also call .subscribe() separately.
        """
        asyncio.run(self._run_forever(symbols or []))

    def subscribe(self, symbols: List[str]):
        """Subscribe to additional symbols (only works during .connect()).

        For most use cases, pass symbols directly to .stream() or .connect().
        """
        for sym in symbols:
            self._subscriptions.add(sym)
            if self._ws:
                asyncio.get_event_loop().run_until_complete(
                    self._ws.send(json.dumps({"action": "subscribe", "symbol": sym}))
                )

    # ------------------------------------------------------------------
    # Async API
    # ------------------------------------------------------------------

    async def stream_async(self, symbols: List[str], reconnect: bool = True):
        """Async generator that yields Tick objects.

        Args:
            symbols: List of symbols to subscribe to.
            reconnect: If True, automatically reconnect on disconnect.

        Yields:
            Tick objects as they arrive.

        Example:
            import asyncio
            from lse import LSE

            async def main():
                client = LSE(api_key="your_key")
                async for tick in client.stream_async(["BTC/USD"]):
                    print(tick)

            asyncio.run(main())
        """
        while True:
            try:
                async for tick in self._stream_once(symbols):
                    yield tick
            except Exception as e:
                self._emit("error", str(e))
                self._emit("disconnected")
                if not reconnect:
                    return
                await asyncio.sleep(3)

    async def connect_async(self, symbols: Optional[List[str]] = None):
        """Async version of connect(). Blocks forever."""
        await self._run_forever(symbols or [])

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _stream_once(self, symbols: List[str]):
        """Single connection session. Yields ticks until disconnect."""
        async with websockets.connect(
            self._url,
            ping_interval=PING_INTERVAL,
            ping_timeout=30,
        ) as ws:
            self._ws = ws
            self._authenticated = False

            # Wait for welcome
            raw = await ws.recv()
            msg = json.loads(raw)
            if msg.get("type") == "welcome":
                self._emit("connected")

            # Authenticate
            await ws.send(json.dumps({
                "action": "auth",
                "api_key": self._api_key,
            }))

            # Start keepalive pings in background
            ping_task = asyncio.create_task(self._ping_loop(ws))

            try:
                async for raw in ws:
                    msg = json.loads(raw)
                    msg_type = msg.get("type")

                    if msg_type == "authenticated":
                        self._authenticated = True
                        self._tier = msg.get("tier", "")
                        self._symbols = msg.get("symbols", [])
                        self._emit("authenticated")

                        # Subscribe to requested symbols
                        for sym in symbols:
                            self._subscriptions.add(sym)
                            await ws.send(json.dumps({
                                "action": "subscribe",
                                "symbol": sym,
                            }))

                    elif msg_type == "tick":
                        tick = Tick(
                            symbol=msg.get("symbol", ""),
                            price=msg.get("price", 0.0),
                            bid=msg.get("bid"),
                            ask=msg.get("ask"),
                            volume=msg.get("volume"),
                            timestamp=msg.get("ts"),
                            name=msg.get("name"),
                        )
                        self._emit("tick", tick)
                        yield tick

                    elif msg_type == "error":
                        self._emit("error", msg.get("message", "Unknown error"))

                    elif msg_type == "pong":
                        pass  # keepalive response, ignore

            finally:
                ping_task.cancel()
                self._ws = None
                self._authenticated = False

    async def _run_forever(self, symbols: List[str]):
        """Connect, subscribe, and dispatch events forever with auto-reconnect."""
        while True:
            try:
                async for tick in self._stream_once(symbols):
                    pass  # ticks dispatched via callbacks in _stream_once
            except Exception as e:
                self._emit("error", str(e))
                self._emit("disconnected")
                await asyncio.sleep(3)

    async def _ping_loop(self, ws):
        """Send application-level pings to keep the connection alive."""
        try:
            while True:
                await asyncio.sleep(PING_INTERVAL)
                try:
                    await ws.send(json.dumps({"action": "ping"}))
                except Exception:
                    break
        except asyncio.CancelledError:
            pass
