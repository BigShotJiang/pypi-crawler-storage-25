# prompt_resolver

![PyPI version](https://img.shields.io/pypi/v/prompt-resolver.svg)

Prompt resolver

* GitHub: https://github.com/innivic/prompt-resolver/
* PyPI package: https://pypi.org/project/prompt-resolver/
* Created by: **[innivic](innivic.org)** | GitHub https://github.com/innivic | PyPI https://pypi.org/user/innivic/
* Free software: MIT License

## Features

* TODO

## Documentation

Documentation is built with [Zensical](https://zensical.org/) and deployed to GitHub Pages.

* **Live site:** https://innivic.github.io/prompt_resolver/
* **Preview locally:** `just docs-serve` (serves at http://localhost:8000)
* **Build:** `just docs-build`

API documentation is auto-generated from docstrings using [mkdocstrings](https://mkdocstrings.github.io/).

Docs deploy automatically on push to `main` via GitHub Actions. To enable this, go to your repo's Settings > Pages and set the source to **GitHub Actions**.

## Development

To set up for local development:

```bash
# Clone your fork
git clone git@github.com:your_username/prompt-resolver.git
cd prompt-resolver

# Install in editable mode with live updates
uv tool install --editable .
```

This installs the CLI globally but with live updates - any changes you make to the source code are immediately available when you run `prompt_resolver`.

Run tests:

```bash
uv run pytest
```

Run quality checks (format, lint, type check, test):

```bash
just qa
```

## Author

innivic.
