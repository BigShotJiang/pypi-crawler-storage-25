"""Public data types the SDK returns to callers.

These dataclasses are the contract between the SDK and its users —
``execute()`` returns an ``ExecutionResult``, ``stream()`` yields
``StreamEvent``\\ s, and so on. They live in their own module because:

* The shape here is a stable promise; the client implementation in
  :mod:`fruxon.fruxon` evolves freely behind it.
* Top-class SDKs we benchmarked (anthropic, openai, stripe) all separate
  types from clients for exactly this reason — it makes the public
  surface area auditable in one place.
* Adding a new field to a model is a one-file diff; consumers re-import
  from :mod:`fruxon` and pick it up.

Everything is ``@dataclass(frozen=True)`` because these are values, not
state — there's no scenario where you want to mutate an
``ExecutionResult`` after the API returns it.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ExecutionTrace:
    """Execution trace metadata."""

    agent_id: str
    agent_revision: int
    duration: int
    input_cost: float
    output_cost: float
    total_cost: float


@dataclass(frozen=True)
class ExecutionResult:
    """Result of an agent execution."""

    response: str
    trace: ExecutionTrace
    session_id: str
    links: list[dict[str, object]]
    execution_record_id: str


@dataclass(frozen=True)
class Agent:
    """Subset of an agent's metadata that the SDK exposes.

    We pick only the fields a programmatic caller is likely to care
    about — identifier, human label, enable state, and the
    currently-deployed revision. Everything else (timestamps,
    eval-metric configs, the full external-agent config blob) is
    reachable on the raw API response if needed, but isn't part of the
    SDK contract because the shape on the server side is allowed to
    evolve faster than this dataclass.
    """

    id: str
    display_name: str
    description: str
    enabled: bool
    current_revision: int
    tags: list[str]


@dataclass(frozen=True)
class ExecutionRecord:
    """A record of a past agent execution — what ``fruxon trace`` displays.

    Narrow subset of the API's ``AgentExecutionRecordResponse``: just the
    fields a user inspecting a past run actually wants (when, how long,
    cost, status). The full server payload also carries delivery status,
    redaction flags, and provider metadata; those are reachable via the
    raw HTTP layer if needed but aren't part of the SDK contract.
    """

    id: str
    agent_id: str
    agent_revision: int
    status: str
    start_time: int  # epoch ms
    end_time: int | None  # epoch ms; None if still running
    input_tokens: int
    output_tokens: int
    total_cost: float

    @property
    def duration_ms(self) -> int | None:
        if self.end_time is None:
            return None
        return self.end_time - self.start_time


@dataclass(frozen=True)
class StreamEvent:
    """A single Server-Sent Event from a streaming execution.

    Backend emits typed events as the run progresses — text chunks,
    tool dispatches, tool completions, step traces, and a final
    ``done`` event. The full event list and payload shapes are
    documented at ``/api/agents/execution/stream`` and mirrored in
    ``SseWriter`` on the backend.

    For most callers, watching for ``event == "text"`` and pulling
    ``data["chunk"]`` is enough; use
    :meth:`fruxon.FruxonClient.stream_text` if that's all you need.
    """

    event: str
    data: dict[str, Any]
