"""Fruxon API client for executing agents on the Fruxon platform.

Public types (``ExecutionResult``, ``Agent``, ``StreamEvent``, …) live
in :mod:`fruxon.models`. They're re-exported below so existing
``from fruxon.fruxon import ExecutionResult`` callers keep working.
"""

import json
import urllib.error
import urllib.request
from collections.abc import Iterator
from typing import Any

from fruxon.exceptions import (
    AuthenticationError,
    ForbiddenError,
    FruxonAPIError,
    FruxonConnectionError,
    NotFoundError,
    ValidationError,
)
from fruxon.models import Agent, ExecutionRecord, ExecutionResult, ExecutionTrace, StreamEvent

# Re-exported so internal code and direct callers can keep importing from
# ``fruxon.fruxon``. Tests pin these for `isinstance` checks; the public
# import path (``from fruxon import ...``) is the supported one.
__all__ = [
    "Agent",
    "ExecutionRecord",
    "ExecutionResult",
    "ExecutionTrace",
    "FruxonClient",
    "StreamEvent",
]

_STATUS_EXCEPTIONS: dict[int, type[FruxonAPIError]] = {
    400: ValidationError,
    401: AuthenticationError,
    403: ForbiddenError,
    404: NotFoundError,
    422: ValidationError,
}


class FruxonClient:
    """Client for the Fruxon platform API."""

    DEFAULT_BASE_URL = "https://api.fruxon.com"

    def __init__(
        self,
        *,
        api_key: str,
        org: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 120.0,
    ) -> None:
        self._api_key = api_key
        # Stored as ``_org`` to match the user-facing noun. The URL path
        # the backend still uses (``/v1/tenants/...``) is an
        # implementation detail of the server's multi-tenant architecture
        # and isn't exposed in the SDK or CLI surface.
        self._org = org
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout

    def execute(
        self,
        agent: str,
        *,
        parameters: dict[str, object] | None = None,
        attachments: list[dict[str, object]] | None = None,
        chat_user: dict[str, object] | None = None,
        session_id: str | None = None,
    ) -> ExecutionResult:
        """Execute an agent's currently deployed revision and return the result.

        Hits ``POST /v1/tenants/{tenant}/agents/{agent}:execute``. Synchronous
        — the whole run completes before this returns. Use
        :meth:`stream` (or :meth:`stream_text`) if you want to surface
        progress while the agent is still running.

        Args:
            agent: The agent identifier.
            parameters: Execution parameters and inputs.
            attachments: File attachments.
            chat_user: Chat user information.
            session_id: Session identifier for multi-turn conversations.
        """
        url = self._agent_url(agent, ":execute")
        body = self._build_execution_body(
            parameters=parameters,
            attachments=attachments,
            chat_user=chat_user,
            session_id=session_id,
        )
        return _parse_execution_result(self._post_json(url, body))

    def execute_revision(
        self,
        agent: str,
        revision: str,
        *,
        parameters: dict[str, object] | None = None,
        attachments: list[dict[str, object]] | None = None,
        chat_user: dict[str, object] | None = None,
        session_id: str | None = None,
    ) -> ExecutionResult:
        """Execute a specific revision of an agent, regardless of which one is deployed.

        Hits ``POST /v1/tenants/{tenant}/agents/{agent}/revisions/{revision}:execute``.
        Useful for A/B testing or for replaying historical traffic against a
        prior revision. Same auth and parameter contract as :meth:`execute`.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/agents/{agent}/revisions/{revision}:execute"
        body = self._build_execution_body(
            parameters=parameters,
            attachments=attachments,
            chat_user=chat_user,
            session_id=session_id,
        )
        return _parse_execution_result(self._post_json(url, body))

    def stream(
        self,
        agent: str,
        *,
        parameters: dict[str, object] | None = None,
        attachments: list[dict[str, object]] | None = None,
        chat_user: dict[str, object] | None = None,
        session_id: str | None = None,
    ) -> Iterator[StreamEvent]:
        """Execute an agent and yield typed Server-Sent Events as they arrive.

        Hits ``POST /v1/tenants/{tenant}/agents/{agent}:stream``. Returns an
        iterator of :class:`StreamEvent` objects. Iteration finishes when the
        backend closes the stream — typically after a terminal ``done`` event.

        For the common case of "stream and print the model's text chunks,"
        prefer :meth:`stream_text`, which yields just the concatenable text
        pieces.
        """
        url = self._agent_url(agent, ":stream")
        body = self._build_execution_body(
            parameters=parameters,
            attachments=attachments,
            chat_user=chat_user,
            session_id=session_id,
        )
        return self._post_sse(url, body)

    def stream_text(
        self,
        agent: str,
        *,
        parameters: dict[str, object] | None = None,
        attachments: list[dict[str, object]] | None = None,
        chat_user: dict[str, object] | None = None,
        session_id: str | None = None,
    ) -> Iterator[str]:
        """Convenience wrapper around :meth:`stream` that yields only text chunks.

        Filters the event stream down to ``text`` events and yields their
        ``chunk`` payload as a string. Use this when you want to mirror the
        chat-style streaming UX without dealing with tool calls, step traces,
        or terminal events.
        """
        for event in self.stream(
            agent,
            parameters=parameters,
            attachments=attachments,
            chat_user=chat_user,
            session_id=session_id,
        ):
            if event.event == "text":
                chunk = event.data.get("chunk")
                if isinstance(chunk, str):
                    yield chunk

    def test(self, agent: str, request: dict[str, object]) -> ExecutionResult:
        """Run a draft flow against an existing agent without publishing it.

        Hits ``POST /v1/tenants/{tenant}/agents/{agent}:test``. Unlike
        :meth:`execute` — which runs the agent's *deployed* revision —
        this runs an inline draft: ``request`` is the full
        ``AgentTestRequest`` body (the candidate ``flow`` plus its
        ``subAgents``, ``assets``, ``integrationConfigs``, ``llmConfigs``,
        ``baseRevision``, and runtime ``parameters``). The ``agent`` path
        segment scopes the run to that agent — it gates Editor access and
        resolves any masked secrets from ``baseRevision``'s stored configs.

        Returns the same :class:`ExecutionResult` shape as :meth:`execute`.
        The SDK stays deliberately thin here: it posts ``request``
        verbatim rather than modelling the broad, fast-evolving
        ``AgentTestRequest`` schema — the caller assembles the body.
        """
        url = self._agent_url(agent, ":test")
        return _parse_execution_result(self._post_json(url, request))

    def stream_test(self, agent: str, request: dict[str, object]) -> Iterator[StreamEvent]:
        """Streaming counterpart of :meth:`test`.

        Hits ``POST /v1/tenants/{tenant}/agents/{agent}:streamTest`` and
        yields the same typed :class:`StreamEvent` objects as
        :meth:`stream`. ``request`` is the ``AgentTestRequest`` body, same
        as :meth:`test`.
        """
        url = self._agent_url(agent, ":streamTest")
        return self._post_sse(url, request)

    def list_agents(self) -> list[Agent]:
        """Fetch every agent in the current org.

        Hits ``GET /v1/tenants/{org}/agents``. Each item is mapped to
        :class:`Agent`, which is intentionally a narrow subset of the API
        payload — we only expose the fields a CLI/SDK caller is likely to
        use (id, display name, enable state, current revision, tags).
        Soft-deleted agents are filtered out client-side.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/agents"
        raw = self._get_json(url)
        if not isinstance(raw, list):
            raise FruxonAPIError(
                status=200,
                title="Unexpected response",
                detail="Expected a list of agents, got a different shape.",
            )
        return [_parse_agent(item) for item in raw if _is_active_agent(item)]

    def get_execution_record(self, agent: str, record_id: str) -> ExecutionRecord:
        """Fetch a single past execution's record.

        Hits ``GET /v1/tenants/{tenant}/agents/{agent}/executionRecords/{recordId}``.
        Returns the narrow :class:`ExecutionRecord` view — start/end times,
        token counts, cost, status — for the ``fruxon trace`` surface and
        any user-level diagnostics.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/agents/{agent}/executionRecords/{record_id}"
        return _parse_execution_record(self._get_json(url))

    def get_execution_trace(self, agent: str, record_id: str) -> dict:
        """Fetch the step-by-step trace for a past execution.

        Hits the ``:trace`` action on the execution record. The trace
        payload is intentionally returned as a raw dict because the
        shape — nested step trees, tool metadata, provider-specific
        fields — is broad and evolves faster than a typed model would
        gracefully handle. Callers wanting structured access should
        peel into the dict; ``fruxon trace`` does so for rendering.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/agents/{agent}/executionRecords/{record_id}:trace"
        result = self._get_json(url)
        if isinstance(result, dict):
            return result
        raise FruxonAPIError(
            status=200,
            title="Unexpected response",
            detail="Expected an object from the trace endpoint.",
        )

    def get_agent(self, agent: str) -> Agent:
        """Fetch a single agent's metadata by ID.

        Hits ``GET /v1/tenants/{tenant}/agents/{agent}``. 404s surface as
        :class:`NotFoundError` so callers can distinguish "no such agent"
        from other failures.
        """
        url = self._agent_url(agent, "")
        return _parse_agent(self._get_json(url))

    def get_agent_parameters(self, agent: str, revision: int | str) -> list[str]:
        """Fetch the input parameter names a revision of an agent expects.

        Hits ``GET /v1/tenants/{tenant}/agents/{agent}/revisions/{rev}:parameters``.
        The server returns an ``{"parameters": ["user_query", …]}`` shape — we
        unwrap it to a flat list because callers overwhelmingly want the names,
        not the wrapper object. Missing or non-string entries are filtered out
        so a partial server response doesn't pollute the list.

        Used by ``fruxon agents get`` so users can see which keys to pass to
        ``fruxon run <agent> -p <key>=…`` without having to fail a request to
        learn the right name.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/agents/{agent}/revisions/{revision}:parameters"
        raw = self._get_json(url)
        if isinstance(raw, dict):
            params = raw.get("parameters") or []
            if isinstance(params, list):
                return [str(p) for p in params if isinstance(p, str) and p]
        return []

    # ------------------------------------------------------------------ internals

    def _agent_url(self, agent: str, action: str) -> str:
        return f"{self._base_url}/v1/tenants/{self._org}/agents/{agent}{action}"

    @staticmethod
    def _build_execution_body(
        *,
        parameters: dict[str, object] | None,
        attachments: list[dict[str, object]] | None,
        chat_user: dict[str, object] | None,
        session_id: str | None,
    ) -> dict[str, object]:
        body: dict[str, object] = {}
        if parameters is not None:
            body["parameters"] = parameters
        if attachments is not None:
            body["attachments"] = attachments
        if chat_user is not None:
            body["chatUser"] = chat_user
        if session_id is not None:
            body["sessionId"] = session_id
        return body

    def _post_json(self, url: str, body: dict[str, object]) -> dict:
        req = self._build_request(url, body, accept="application/json")
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            _raise_api_error(e)
        except urllib.error.URLError as e:
            raise FruxonConnectionError(str(e.reason)) from e

    def _get_json(self, url: str) -> object:
        """GET an API endpoint and return the parsed JSON body.

        Mirrors :meth:`_post_json` but without a request body and forced
        to GET. Same error-mapping pipeline so callers see the same typed
        exceptions regardless of HTTP method.
        """
        req = urllib.request.Request(
            url,
            headers={
                "Accept": "application/json",
                "X-API-KEY": self._api_key,
            },
            method="GET",
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            _raise_api_error(e)
        except urllib.error.URLError as e:
            raise FruxonConnectionError(str(e.reason)) from e

    def _post_sse(self, url: str, body: dict[str, object]) -> Iterator[StreamEvent]:
        req = self._build_request(url, body, accept="text/event-stream")
        try:
            resp = urllib.request.urlopen(req, timeout=self._timeout)
        except urllib.error.HTTPError as e:
            _raise_api_error(e)
        except urllib.error.URLError as e:
            raise FruxonConnectionError(str(e.reason)) from e
        return _iter_sse_events(resp)

    def _build_request(
        self,
        url: str,
        body: dict[str, object],
        *,
        accept: str,
    ) -> urllib.request.Request:
        return urllib.request.Request(
            url,
            data=json.dumps(body).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Accept": accept,
                "X-API-KEY": self._api_key,
            },
            method="POST",
        )


def _iter_sse_events(resp: Any) -> Iterator[StreamEvent]:
    """Parse the SSE response stream into ``StreamEvent`` objects.

    Backend emits events as ``event: <type>\\ndata: <json>\\n\\n``. We
    accumulate ``event:`` / ``data:`` lines until a blank-line separator,
    then yield. The response is closed when iteration ends or when the
    caller breaks early.
    """
    try:
        event_type = "message"
        data_lines: list[str] = []
        for raw in resp:
            line = raw.decode("utf-8").rstrip("\n").rstrip("\r")
            if line == "":
                # Dispatch only if we collected at least an event or data line —
                # heartbeat keep-alives are emitted as blank lines.
                if event_type != "message" or data_lines:
                    payload_raw = "\n".join(data_lines)
                    try:
                        payload = json.loads(payload_raw) if payload_raw else {}
                    except json.JSONDecodeError:
                        payload = {"_raw": payload_raw}
                    yield StreamEvent(
                        event=event_type,
                        data=payload if isinstance(payload, dict) else {"value": payload},
                    )
                event_type = "message"
                data_lines = []
                continue
            if line.startswith(":"):
                # SSE comment / keep-alive — ignore.
                continue
            if line.startswith("event:"):
                event_type = line[6:].strip()
            elif line.startswith("data:"):
                data_lines.append(line[5:].lstrip(" "))
    finally:
        resp.close()


def _raise_api_error(error: urllib.error.HTTPError) -> None:
    """Parse an HTTP error response and raise the appropriate exception."""
    try:
        body = json.loads(error.read().decode("utf-8"))
        title = body.get("title") or body.get("message") or "Error"
        detail = body.get("detail") or body.get("details") or ""
    except (json.JSONDecodeError, UnicodeDecodeError):
        title = "Error"
        detail = str(error)

    exc_class = _STATUS_EXCEPTIONS.get(error.code, FruxonAPIError)
    raise exc_class(status=error.code, title=title, detail=detail) from error


def _parse_agent(data: object) -> Agent:
    """Map the raw Agent payload into the SDK's narrow Agent dataclass.

    Defaults are deliberately lenient — the server may add or remove
    fields over time, and a missing field shouldn't cause the SDK to
    crash on what's otherwise a perfectly usable response.
    """
    if not isinstance(data, dict):
        raise FruxonAPIError(
            status=200,
            title="Unexpected response",
            detail="Expected an agent object, got a different shape.",
        )
    tags = data.get("tags") or []
    return Agent(
        id=str(data.get("id") or ""),
        display_name=str(data.get("displayName") or ""),
        description=str(data.get("description") or ""),
        enabled=bool(data.get("enabled", False)),
        current_revision=int(data.get("currentRevision") or 0),
        tags=[str(t) for t in tags if isinstance(t, str)],
    )


def _is_active_agent(data: object) -> bool:
    """Filter predicate for the list endpoint — drop soft-deleted agents.

    The API returns ``deletedAt`` on agents pending deletion in the grace
    period. Callers of ``list_agents`` overwhelmingly want the *active*
    set, so we hide them by default. Callers that need everything can
    drop down to the raw HTTP layer.
    """
    return isinstance(data, dict) and not data.get("deletedAt")


def _parse_execution_record(data: object) -> ExecutionRecord:
    """Map the raw ``AgentExecutionRecordResponse`` payload to our
    narrower :class:`ExecutionRecord` dataclass.

    The full server response has many fields (delivery status, redaction
    flags, provider-specific data) we don't surface; the parser
    deliberately ignores them so additions on the server side don't
    require an SDK release.
    """
    if not isinstance(data, dict):
        raise FruxonAPIError(
            status=200,
            title="Unexpected response",
            detail="Expected an execution-record object.",
        )
    return ExecutionRecord(
        id=str(data.get("id") or ""),
        agent_id=str(data.get("agentId") or ""),
        agent_revision=int(data.get("agentRevision") or 0),
        status=str(data.get("status") or ""),
        start_time=int(data.get("startTime") or 0),
        end_time=int(data["endTime"]) if data.get("endTime") is not None else None,
        input_tokens=int(data.get("inputTokens") or 0),
        output_tokens=int(data.get("outputTokens") or 0),
        total_cost=float(data.get("totalCost") or 0.0),
    )


def _parse_execution_result(data: dict) -> ExecutionResult:
    """Parse raw API response into an ExecutionResult."""
    trace_data: dict = data.get("trace", {})
    trace = ExecutionTrace(
        agent_id=trace_data.get("agentId", ""),
        agent_revision=trace_data.get("agentRevision", 0),
        duration=trace_data.get("duration", 0),
        input_cost=trace_data.get("inputCost", 0.0),
        output_cost=trace_data.get("outputCost", 0.0),
        total_cost=trace_data.get("totalCost", 0.0),
    )
    return ExecutionResult(
        response=data.get("response", ""),
        trace=trace,
        session_id=data.get("sessionId", ""),
        links=data.get("links", []),
        execution_record_id=data.get("executionRecordId", ""),
    )
