"""``fruxon run`` — execute an agent.

Streams text chunks by default (hits the ``:stream`` endpoint). The
streaming UI mirrors Claude Code's Ink-based model: a single Rich Live
region on stderr owns the bottom of the terminal (in-progress paragraph
+ a footer of spinner rows for currently-running tools with live elapsed
time). Completed paragraphs and tool blocks commit to scrollback above
the live region via ``console.print`` (Rich's "log above live" routing).

Why one surface: stdout and stderr share the same physical TTY. Mixing
raw ``sys.stdout.write`` with stderr cursor-control codes from a Live
region races on the cursor and produces flicker / token-on-its-own-line
artifacts. The new path writes *everything* through Rich on stderr when
the terminal is interactive; the raw stdout path is reserved for pipes
(``fruxon run agent > out.txt``) so consumers still get clean bytes.

Helpers:

* ``run``                          — argument parsing + orchestration
* ``_run_stream``                  — SSE event loop dispatching to ``_StreamView``
* ``_StreamView``                  — the Claude-Code-style live surface
* ``_LiveRegion``                  — custom renderable: in-progress text + footer
* ``_build_tool_block``            — committed tool block (⏺ name; ⎿ tree only when expanded)
* ``_format_args`` / ``_short_repr`` — argument-preview formatting (verbose mode only)
* ``_hint_for_error``              — actionable next-step text per error class
"""

from __future__ import annotations

import json
import sys
import time
from collections.abc import Callable, Iterator
from typing import Annotated

import typer

from fruxon import credentials
from fruxon.cli import app
from fruxon.exceptions import FruxonError
from fruxon.fruxon import ExecutionResult, FruxonClient, StreamEvent
from fruxon.ui import (
    format_duration,
    print_banner,
    render_markdown,
    resolve_output_format,
    say_err,
    stderr,
    stdout_is_tty,
)


@app.command(
    short_help="Execute an agent and print the response (one-shot — pair with `chat` for multi-turn).",
)
def run(
    agent: Annotated[str, typer.Argument(help="Agent identifier to execute")],
    org: Annotated[
        str | None,
        typer.Option(
            "--org",
            help="Organization identifier. Falls back to $FRUXON_ORG or `fruxon login`-stored default.",
        ),
    ] = None,
    api_key: Annotated[
        str | None,
        typer.Option(
            "--api-key",
            "-k",
            envvar="FRUXON_API_KEY",
            help="API key. Falls back to $FRUXON_API_KEY or `fruxon login`-stored value.",
        ),
    ] = None,
    param: Annotated[
        list[str] | None,
        typer.Option(
            "--param",
            "-p",
            help=(
                "Parameter input — accepts `key=value` (string), `key:=42` (typed JSON), "
                "`key=@file.json` (read from file), or `@file.json` (splat whole object). Repeatable."
            ),
        ),
    ] = None,
    params_file: Annotated[
        str | None,
        typer.Option(
            "--params",
            help="Load parameters from a JSON file. Pass `-` to read from stdin.",
        ),
    ] = None,
    stdin_input: Annotated[
        bool,
        typer.Option(
            "--stdin",
            help="Read the full parameters JSON object from stdin (alias for `--params -`).",
        ),
    ] = False,
    session_id: Annotated[str | None, typer.Option("--session", "-s", help="Session ID")] = None,
    revision: Annotated[
        str | None,
        typer.Option(
            "--revision",
            "-r",
            help="Pin execution to a specific agent revision instead of the deployed one. Implies --no-stream.",
        ),
    ] = None,
    stream: Annotated[
        bool,
        typer.Option(
            "--stream/--no-stream",
            help=(
                "Stream text chunks as the agent generates them (default). "
                "Use --no-stream to wait for the full response — required for --output json/table, "
                "--revision, and the duration/cost footer."
            ),
        ),
    ] = True,
    output: Annotated[
        str | None,
        typer.Option(
            "--output",
            "-o",
            help=(
                "Output format: text (default for humans — response body only), "
                "json (full result, default in agent mode), table (humans). "
                "When unset, json is the implicit default under FRUXON_AGENT_MODE / "
                "CLAUDECODE / CI so AI agents get parseable output without extra flags."
            ),
        ),
    ] = None,
    base_url: Annotated[
        str | None,
        typer.Option(
            "--base-url",
            help="API base URL. Falls back to $FRUXON_BASE_URL, stored value, or the prod default.",
        ),
    ] = None,
    edit: Annotated[
        list[str] | None,
        typer.Option(
            "--edit",
            "-e",
            help=(
                "Open $EDITOR to compose the value of a parameter (repeatable). "
                "Useful for multi-line prompts. Saved value overrides any -p / --params input "
                "for the same key."
            ),
        ),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            "-v",
            help=(
                "Expand tool calls in the streaming view — show full arguments "
                "and full result payloads on indented lines under each call. "
                "Failures auto-expand regardless of this flag."
            ),
        ),
    ] = False,
):
    """Execute a Fruxon agent and print the response.

    One-shot: send parameters, get the response, exit. For multi-turn
    conversation with session continuity, use `fruxon chat` instead.

    Streams text chunks by default (hits the `:stream` endpoint). Pass
    `--no-stream` to wait for the full response, `--output json` for a
    machine-readable result, `--output table` for a human-readable
    breakdown, or `--revision` to pin execution to a specific revision
    (these all imply `--no-stream`).

    Markdown rendering for `--output text` is automatic — enabled when
    stdout is a TTY, disabled when piped so consumers get raw bytes.

    Examples:
        fruxon run my-agent
        fruxon run my-agent -p question="Hello" -p lang=en
        fruxon run my-agent -p temp:=0.7 -p tags:='["a","b"]'
        fruxon run my-agent -p prompt=@./prompt.md
        fruxon run my-agent --params ./params.json
        cat params.json | fruxon run my-agent --stdin
        fruxon run my-agent --output table
        fruxon run my-agent --output json
        fruxon run my-agent --revision 42
    """
    from fruxon.output import FORMATS

    # Agent mode (CLAUDECODE / CI / FRUXON_AGENT_MODE) flips the
    # default to ``json`` so LLMs and scripts get parseable output
    # without having to pass ``--output json`` every time. Explicit
    # ``--output X`` still wins.
    output = resolve_output_format(output, human_default="text", agent_default="json")
    if output not in FORMATS:
        say_err(
            f"Unknown output format: [bold]{output}[/bold]",
            hint=f"Valid formats: {', '.join(FORMATS)}.",
        )
        raise typer.Exit(code=1)

    api_key = credentials.resolve_api_key(api_key)
    org = credentials.resolve_org(org)
    resolved_base_url = credentials.resolve_base_url(base_url) or FruxonClient.DEFAULT_BASE_URL

    if not api_key:
        say_err(
            "No API key found.",
            hint="Run [bold]fruxon login[/bold], pass [bold]--api-key[/bold], or set [bold]$FRUXON_API_KEY[/bold].",
        )
        raise typer.Exit(code=1)
    if not org:
        say_err(
            "No org found.",
            hint="Run [bold]fruxon login --org <id>[/bold], pass [bold]--org[/bold], or set [bold]$FRUXON_ORG[/bold].",
        )
        raise typer.Exit(code=1)

    # `json`/`table` output and `--revision` all require the full sync
    # response. Honor them by silently disabling streaming rather than
    # erroring — they all clearly imply "give me the full result," and
    # forcing the user to also type --no-stream would be busywork.
    if output != "text" or revision is not None:
        stream = False

    # Branded header. Stays on stderr, so pipes / --json output / streamed
    # stdout are all unaffected. Skip when stderr is being redirected too —
    # if both streams are captured the user is almost certainly scripting
    # and doesn't want ANSI chrome in their log file.
    if stderr.is_terminal:
        mode_subtitle = "streaming" if stream else (f"revision {revision}" if revision else "sync")
        print_banner(subtitle=mode_subtitle)

    # Parse all the param input forms — flag values, JSON file, stdin —
    # into a single dict the SDK can hand to the API.
    from fruxon.params import ParamError
    from fruxon.params import parse as parse_params

    try:
        parameters = parse_params(
            flag_values=param,
            params_file=params_file,
            stdin_input=stdin_input,
        )
    except ParamError as exc:
        say_err(
            str(exc),
            hint="Run [bold]fruxon run --help[/bold] for accepted parameter forms.",
        )
        raise typer.Exit(code=1) from exc

    # `--edit KEY` pops $EDITOR for each named key and overlays the result.
    # Runs after regular param parsing so the editor sees any existing value
    # (e.g. from `--params file.json`) as a starting point.
    if edit:
        parameters = parameters or {}
        for key in edit:
            existing = parameters.get(key)
            initial = existing if isinstance(existing, str) else ""
            try:
                parameters[key] = _edit_in_editor(initial, key=key)
            except _EditorError as exc:
                say_err(
                    str(exc),
                    hint="Set $EDITOR (or $VISUAL) to your preferred editor.",
                )
                raise typer.Exit(code=1) from exc

    client = FruxonClient(api_key=api_key, org=org, base_url=resolved_base_url)

    if stream:
        _run_stream(
            lambda: client.stream(agent, parameters=parameters, session_id=session_id),
            agent=agent,
            client=client,
            verbose=verbose,
        )
        return

    with stderr.status(f"[bold]Executing agent [cyan]{agent}[/cyan]...[/bold]"):
        try:
            if revision is not None:
                result = client.execute_revision(agent, revision, parameters=parameters, session_id=session_id)
            else:
                result = client.execute(agent, parameters=parameters, session_id=session_id)
        except FruxonError as e:
            say_err(str(e), hint=_hint_for_run_error(e, agent=agent, client=client))
            raise typer.Exit(code=1) from e

    _render_sync_result(result, output, agent=agent)


def _render_sync_result(result: ExecutionResult, output: str, *, agent: str) -> None:
    """Render a completed (non-streamed) execution result.

    Shared by ``fruxon run`` and ``fruxon agents test`` — both get back
    the same :class:`ExecutionResult`, so the body rendering, the
    optional ``--output table`` block, and the duration/cost/record
    footer are identical regardless of which endpoint produced it.
    """
    from fruxon.output import format_result

    formatted = format_result(result, output)
    if formatted.stdout:
        # Markdown rendering is automatic — enabled when (1) the format is
        # text (json/table are structured already) and (2) stdout is a TTY
        # (a piped consumer wants raw bytes, not rich's ANSI). Otherwise
        # plain ``print`` so ``fruxon run … > file.txt`` saves the
        # unstyled response with a trailing newline.
        if output == "text" and stdout_is_tty():
            render_markdown(formatted.stdout)
        else:
            print(formatted.stdout)
    if formatted.stderr_table is not None and stderr.is_terminal:
        stderr.print()
        stderr.print(formatted.stderr_table)

    # Lightweight summary on stderr (only for `text` format — `json`/`table`
    # already carry the trace info, no need to repeat). The execution record
    # ID is the missing piece that lets users follow up with `fruxon trace`,
    # so it's always surfaced when present.
    if output == "text":
        duration = result.trace.duration
        cost = result.trace.total_cost
        parts: list[str] = []
        if duration:
            parts.append(format_duration(duration))
        if cost:
            parts.append(f"${cost:.4f}")
        if result.execution_record_id:
            parts.append(f"record [cyan]{result.execution_record_id}[/cyan]")
        if parts:
            stderr.print(f"[dim]{'  ·  '.join(parts)}[/dim]")
        if result.execution_record_id:
            # Make the trace command copy-pasteable rather than just naming
            # the record ID. Closes the loop from `run` → `trace` without
            # asking the user to remember the agent argument.
            stderr.print(f"[dim]→ fruxon trace [bold]{agent}[/bold] [cyan]{result.execution_record_id}[/cyan][/dim]")


# ─────────────────────────────────────────────────────────────────────────────
# Streaming
# ─────────────────────────────────────────────────────────────────────────────


def _run_stream(
    stream_factory: Callable[[], Iterator[StreamEvent]],
    *,
    agent: str,
    client: FruxonClient,
    verbose: bool = False,
) -> None:
    """Render an SSE stream through a single Claude-Code-style surface.

    Takes a ``stream_factory`` — a zero-arg callable that returns the
    event iterator — rather than building the stream itself, so the same
    rendering surface serves both ``fruxon run`` (``client.stream``) and
    ``fruxon agents test`` (``client.stream_test``). The factory is
    invoked *inside* the try block: opening the SSE connection can raise
    a :class:`FruxonError`, and that failure needs the same hint path as
    a mid-stream error. ``agent`` + ``client`` are kept only to build
    that hint.

    The :class:`_StreamView` owns all terminal output decisions: in TTY
    mode it drives a Rich ``Live`` region with an append-only transcript
    above (text paragraphs + ``⏺`` tool blocks committed via
    ``console.print``) and a live footer below (in-progress paragraph +
    spinner rows with elapsed time). In pipe mode (``fruxon run … > f``)
    it falls back to raw stdout writes + plain stderr tool rows so
    consumers get parseable output.
    """
    view = _StreamView(
        live=stderr.is_terminal and stdout_is_tty(),
        verbose=verbose,
    )

    try:
        for event in stream_factory():
            if event.event == "text":
                chunk = event.data.get("chunk")
                if isinstance(chunk, str) and chunk:
                    view.push_text(chunk)
                continue

            if event.event == "tool_call":
                view.push_tool_call(event.data)
                continue

            if event.event == "tool_result":
                view.push_tool_result(event.data)
                continue

            if event.event == "error":
                view.close()
                message = event.data.get("message") or "Unknown error"
                code = event.data.get("code")
                label = f"{message} [{code}]" if code else message
                say_err(label)
                raise typer.Exit(code=1)

            if event.event == "done":
                view.close()
                _render_done(event.data, agent=agent)
                continue

            # Other event types (usage, status, step_trace) are intentionally
            # silent — the trace footer at the end is enough for a CLI run.

    except FruxonError as e:
        view.close()
        say_err(str(e), hint=_hint_for_run_error(e, agent=agent, client=client))
        raise typer.Exit(code=1) from e

    view.close()


def _hint_for_run_error(
    error: FruxonError,
    *,
    agent: str,
    client: FruxonClient,
) -> str | None:
    """Map a run-time API exception to an actionable, copy-pasteable hint.

    Top-class CLIs don't just relay the error — they tell the user how to
    fix it. Each ``FruxonError`` subclass corresponds to a known failure
    mode, so we can be cheaply precise. Two cases get extra care:

    * **Missing parameter.** The backend's message
      (``Parameter X is required``) carries the param name; we extract
      it and synthesize a ``fruxon run <agent> -p X=<value>`` line the
      user can copy verbatim.
    * **Agent not found.** We fetch the org's agent list (best effort)
      and use ``difflib.get_close_matches`` to suggest the most likely
      typo correction.
    """
    from fruxon.exceptions import (
        AuthenticationError,
        ForbiddenError,
        NotFoundError,
        ValidationError,
    )

    if isinstance(error, AuthenticationError):
        return (
            "Check that your API key is still active. "
            "Run [bold]fruxon whoami[/bold] to confirm; refresh with [bold]fruxon login[/bold]."
        )
    if isinstance(error, ForbiddenError):
        return (
            "Your key is valid but doesn't grant access to this resource. "
            "Confirm the org/agent with [bold]fruxon whoami[/bold]."
        )
    if isinstance(error, NotFoundError):
        # The agent might exist but simply have no deployed revision —
        # the backend surfaces both cases as 404 with the same message.
        # Disambiguate by re-fetching the agent before falling back to a
        # typo suggestion. Without this, a user with a draft-only agent
        # gets "double-check the identifier" — misleading, the ID is fine.
        try:
            fetched = client.get_agent(agent)
        except Exception:
            fetched = None
        if fetched is not None and not fetched.current_revision:
            return (
                f"Agent [bold]{agent}[/bold] has no deployed revision yet. "
                f"Deploy one in the dashboard, or pin a specific revision with "
                f"[bold]--revision <N>[/bold]."
            )
        suggestion = _suggest_close_agent(agent, client)
        if suggestion:
            return f"Did you mean [bold]{suggestion}[/bold]?  See [bold]fruxon agents list[/bold]."
        return "Double-check the agent identifier. Run [bold]fruxon agents list[/bold] to see available agents."
    if isinstance(error, ValidationError):
        # Backend currently emits the human-readable message in
        # ``ErrorResponse.Message`` which the SDK maps to
        # :attr:`FruxonAPIError.title`. ``detail`` is usually empty.
        # Scan both so the hint works no matter which field carries
        # the actionable text.
        haystack = f"{error.title} {error.detail or ''}"
        param = _extract_missing_parameter(haystack)
        if param:
            return (
                f"Pass it with: [bold]fruxon run {agent} -p {param}=<value>[/bold]\n"
                f"Schema:      [bold]fruxon agents get {agent}[/bold]"
            )
        return "Inspect the request body — invalid parameters or missing required fields."
    return None


# Backwards-compatible name retained for chat.py (and any other callers that
# import the older single-arg form). New code should call
# ``_hint_for_run_error`` so it can supply agent + client for better hints.
def _hint_for_error(error: FruxonError) -> str | None:
    """Generic hint helper without ``run``-specific context.

    Kept for ``fruxon chat`` and other call sites that don't have the
    ``(agent, client)`` pair handy. Less helpful than
    :func:`_hint_for_run_error` but still better than re-printing the
    raw API message alone.
    """
    from fruxon.exceptions import (
        AuthenticationError,
        ForbiddenError,
        NotFoundError,
        ValidationError,
    )

    if isinstance(error, AuthenticationError):
        return (
            "Check that your API key is still active. "
            "Run [bold]fruxon whoami[/bold] to confirm; refresh with [bold]fruxon login[/bold]."
        )
    if isinstance(error, ForbiddenError):
        return "Your key is valid but doesn't grant access to this resource."
    if isinstance(error, NotFoundError):
        return "Run [bold]fruxon agents list[/bold] to see what's available."
    if isinstance(error, ValidationError):
        haystack = f"{getattr(error, 'title', '') or ''} {getattr(error, 'detail', '') or ''}"
        param = _extract_missing_parameter(haystack)
        if param:
            return f"Missing parameter: [bold]{param}[/bold]. Pass it with [bold]-p {param}=<value>[/bold]."
        return "Inspect the request body — invalid parameters or missing required fields."
    return None


def _extract_missing_parameter(detail: str) -> str | None:
    """Pull the param name out of the backend's ``Parameter X is required`` message.

    The backend currently emits unstructured prose for validation
    errors (see ``ExecutionRequestBuilder.cs`` — the throw site reads
    ``Parameter {m.Name} is required``). Until that surface gains a
    structured ``code``/``data`` envelope we extract the parameter
    name with a regex so the CLI can still produce a copy-pasteable
    fix line. Falls through silently when the message shape changes.
    """
    import re

    match = re.search(r"Parameter\s+(\w+)\s+is\s+required", detail)
    return match.group(1) if match else None


def _suggest_close_agent(agent: str, client: FruxonClient) -> str | None:
    """Best-effort "did you mean?" for a missing agent identifier.

    Pulls the org's agent list and runs the requested name through
    :func:`difflib.get_close_matches`. Returns the single closest
    match if any. Network failures here are swallowed — the user's
    already getting an error; we don't want this to turn into a
    second one.
    """
    import difflib

    try:
        agents = client.list_agents()
    except Exception:
        return None
    candidates = [a.id for a in agents]
    matches = difflib.get_close_matches(agent, candidates, n=1, cutoff=0.6)
    return matches[0] if matches else None


# ─────────────────────────────────────────────────────────────────────────────
# StreamView — Claude-Code-style single Live surface
# ─────────────────────────────────────────────────────────────────────────────


class _StreamView:
    """Single rendering surface for the whole streaming run.

    Mirrors Claude Code's Ink layout:

    * **Transcript** (append-only): completed paragraphs and committed
      tool blocks live in scrollback. They reach there via
      ``stderr.print`` which Rich routes *above* an active Live region.
    * **Live region** (transient, bottom of screen): the in-progress
      streamed paragraph plus a footer of one spinner row per running
      tool with live-ticking elapsed time.

    Why one surface: stdout and stderr share the same physical TTY in
    an interactive session. Writing to both concurrently while Rich is
    moving the cursor on stderr produces the broken-text bugs we've
    been chasing. Routing everything through one Rich console on stderr
    eliminates the race entirely.

    Pipe mode (``live=False``): no Live region, no Markdown. Text
    chunks go raw to stdout, tool blocks print as plain rows on stderr.
    Same contract as before — ``fruxon run agent > out.txt`` still
    saves the response text verbatim.
    """

    def __init__(self, *, live: bool, verbose: bool) -> None:
        self._live_enabled = live
        self._verbose = verbose
        # In-progress streamed paragraph. Commits to scrollback on
        # ``\n\n`` (paragraph break) or at the boundary of any non-text
        # event so tool blocks always appear *after* the text that
        # preceded them.
        self._buffer = ""
        # Running tools, keyed by id. Insertion-ordered (Py3.7+ dict)
        # so footer rows render in dispatch order.
        self._running: dict[str, dict[str, object]] = {}
        # Per-run monotonic counter for the ``#N`` tag. Sticky even
        # after tools complete — same UX rationale as before.
        self._next_index = 1
        # rich.live.Live | None — lazy-started on first content.
        self._live = None

    # -- event ingress ----------------------------------------------------

    def push_text(self, chunk: str) -> None:
        """Append a streamed text chunk."""
        if not self._live_enabled:
            sys.stdout.write(chunk)
            sys.stdout.flush()
            return
        self._buffer += chunk
        # Commit each complete paragraph to scrollback (rendered as
        # markdown). Anything after the last ``\n\n`` is still in
        # progress and stays in the live region.
        while "\n\n" in self._buffer:
            head, _, tail = self._buffer.partition("\n\n")
            if head.strip():
                self._commit(self._render_markdown(head))
            self._buffer = tail
        self._refresh()

    def push_tool_call(self, data: dict[str, object]) -> None:
        """Register a dispatched tool and surface it in the footer."""
        tool_id = self._tool_id(data)
        if not tool_id:
            return
        trace = data.get("toolTrace") if isinstance(data.get("toolTrace"), dict) else {}
        display_name = trace.get("displayName") if isinstance(trace, dict) else None
        name = str(display_name) if isinstance(display_name, str) and display_name else "tool"
        start = data.get("startTime")
        start_ms = float(start) if isinstance(start, (int, float)) else _now_ms()
        info: dict[str, object] = {
            "name": name,
            "index": self._next_index,
            "start_ms": start_ms,
            "args": data.get("arguments"),
        }
        self._next_index += 1
        self._running[tool_id] = info

        if self._live_enabled:
            self._refresh()

    def push_tool_result(self, data: dict[str, object]) -> None:
        """Commit a finished tool as a ``⏺``/``⎿`` block to scrollback."""
        tool_id = self._tool_id(data)
        info = self._running.pop(tool_id, None)
        if info is None:
            return
        status = str(data.get("status") or "")
        end = data.get("endTime")
        duration_ms: int | None = None
        if isinstance(end, (int, float)) and isinstance(info.get("start_ms"), (int, float)):
            duration_ms = int(end - info["start_ms"])  # type: ignore[operator]
        block = _build_tool_block(info, status, duration_ms, data.get("result"), verbose=self._verbose)
        if self._live_enabled:
            # Commit any in-progress text so the tool block lands after
            # the text that triggered it, not interleaved with it.
            self._flush_buffer()
            self._commit(block)
            self._refresh()
        else:
            stderr.print(block)

    def close(self) -> None:
        """Tear down. Commit any leftover paragraph + stop the Live."""
        if self._live_enabled:
            self._flush_buffer()
            if self._live is not None:
                self._live.stop()
                self._live = None

    # -- internals --------------------------------------------------------

    @staticmethod
    def _tool_id(data: dict[str, object]) -> str:
        raw = data.get("id")
        return str(raw) if raw is not None else ""

    def _flush_buffer(self) -> None:
        if self._buffer.strip():
            self._commit(self._render_markdown(self._buffer))
        self._buffer = ""

    def _commit(self, renderable) -> None:
        """Append a renderable to scrollback above the live region.

        Rich routes ``console.print`` calls *above* an active Live area
        (cursor-up, insert, redraw). When the Live isn't running yet,
        this is just an ordinary print — same end-user result.
        """
        stderr.print(renderable)

    def _render_markdown(self, text: str):
        """Render a completed text segment as markdown.

        Lazy import keeps cold-start cheap when streaming isn't used.
        Falls back to raw text on any markdown-parse weirdness so a
        malformed chunk never blows up the whole stream.
        """
        from rich.markdown import Markdown

        try:
            return Markdown(text)
        except Exception:
            from rich.text import Text

            return Text(text)

    def _refresh(self) -> None:
        """Push a fresh renderable into the Live region.

        The Live is lazy: started when there's content (buffer or
        running tools), stopped when neither has anything. Closing on
        emptiness matters — an idle Live keeps writing cursor codes on
        every auto-refresh tick, which is exactly what caused the
        streaming-text corruption before this refactor.
        """
        if not self._live_enabled:
            return
        has_content = bool(self._buffer) or bool(self._running)
        if not has_content:
            if self._live is not None:
                self._live.stop()
                self._live = None
            return
        renderable = _LiveRegion(
            buffer=self._buffer,
            running=list(self._running.values()),
        )
        if self._live is None:
            from rich.live import Live

            # ``refresh_per_second=6`` ticks the elapsed-time counters
            # without being expensive — Markdown re-renders run on
            # every frame. ``transient=True`` clears the live area on
            # stop; the transcript above persists.
            self._live = Live(
                renderable,
                console=stderr,
                refresh_per_second=6,
                transient=True,
            )
            self._live.start()
        else:
            self._live.update(renderable)


class _LiveRegion:
    """Renderable for the live region (in-progress text + footer).

    Custom ``__rich_console__`` so Rich recomputes the elapsed-time
    string on each refresh tick — a static renderable would freeze the
    timer between updates. The spinner glyph animates on its own via
    Rich's internal frame counter.
    """

    def __init__(self, *, buffer: str, running: list[dict[str, object]]) -> None:
        self.buffer = buffer
        self.running = running

    def __rich_console__(self, console, options):  # noqa: ARG002 — Rich protocol
        from rich.spinner import Spinner
        from rich.text import Text

        if self.buffer:
            yield self._render_buffer()

        if self.running:
            now = _now_ms()
            for info in self.running:
                start = info.get("start_ms")
                elapsed_ms = int(max(0, now - float(start))) if isinstance(start, (int, float)) else 0
                elapsed = format_duration(elapsed_ms) if elapsed_ms > 0 else "…"
                idx = info.get("index")
                tag = f"[dim]#{idx}[/dim] " if isinstance(idx, int) else ""
                # Name + elapsed only — args are part of the verbose
                # expansion that lands once the tool finishes. While
                # running, "which tool" + "for how long" is enough.
                label = f"{tag}[bold]{info.get('name', 'tool')}[/bold] [dim]({elapsed})[/dim]"
                yield Spinner("dots", text=Text.from_markup(label), style="cyan")

    def _render_buffer(self):
        """In-progress paragraph — render as markdown when stable.

        We render the *whole* buffer each frame. That's a touch of
        wasted work compared to ink-style diffing, but Rich's Markdown
        is cheap enough at paragraph scale that it doesn't show up in
        practice.
        """
        from rich.markdown import Markdown
        from rich.text import Text

        try:
            return Markdown(self.buffer)
        except Exception:
            return Text(self.buffer)


# ─────────────────────────────────────────────────────────────────────────────
# Tool block — committed ⏺ / ⎿ tree per Claude Code's layout
# ─────────────────────────────────────────────────────────────────────────────


def _build_tool_block(
    info: dict[str, object],
    status: str,
    duration_ms: int | None,
    result: object,
    *,
    verbose: bool,
):
    """Render a finished tool as a single committed renderable.

    Compact (default) — just *which* tool ran and how long it took.
    Args and result body are deliberately hidden: the user deployed
    this agent because they trust it; what they want is the final
    answer, not the work log. The tool name alone gives "the agent is
    doing X" reassurance without flooding the stream::

        ⏺ list_commits  (320ms)
        ⏺ search_events  (1.6s)

    Verbose (``-v``) — full tree with args + result body::

        ⏺ list_commits  (320ms)
          ⎿  args:
              owner  fruxon-ai
              repo   fruxon-backend
          ⎿  result:
              { … full json … }

    Failures (any mode) auto-expand to the verbose form: when something
    goes wrong, the args + error message are exactly what the user
    needs, and asking them to rerun with ``-v`` is hostile UX.
    """
    from rich.console import Group
    from rich.text import Text

    name = str(info.get("name") or "tool")
    index = info.get("index")
    arguments = info.get("args")

    is_failure = status.upper() in {"ERROR", "FAILED", "CANCELLED"}
    glyph = "[red]⏺[/red]" if is_failure else "[green]⏺[/green]"
    name_style = "bold red" if is_failure else "bold"

    tag = f"[dim]#{index}[/dim] " if isinstance(index, int) else ""
    header = f"{tag}{glyph} [{name_style}]{name}[/{name_style}]"

    if duration_ms is not None and duration_ms >= 0:
        header += f"  [dim]({format_duration(duration_ms)})[/dim]"

    lines: list = [Text.from_markup(header)]

    # Expansion path — only on ``-v`` or failure. Compact mode stops
    # at the header line.
    if verbose or is_failure:
        if arguments is not None:
            arg_lines = _args_detail_lines(arguments)
            if arg_lines:
                lines.append(Text.from_markup("  [dim]⎿[/dim]  [dim]args:[/dim]"))
                lines.extend(Text.from_markup(line) for line in arg_lines)
        result_lines = _result_detail_lines(result, is_failure=is_failure)
        if result_lines:
            lines.append(Text.from_markup("  [dim]⎿[/dim]  [dim]result:[/dim]"))
            lines.extend(Text.from_markup(line) for line in result_lines)

    return Group(*lines)


def _now_ms() -> float:
    """Wall-clock time in ms — same units the backend sends."""
    return time.time() * 1000


# ─────────────────────────────────────────────────────────────────────────────
# Detail blocks (the "dropdown" content)
# ─────────────────────────────────────────────────────────────────────────────


_DETAIL_INDENT = "    "  # 4 spaces — visually nests under the #N tag column
_DETAIL_VALUE_MAX = 200  # per-value cap; full payloads still live in `trace`


def _args_detail_lines(arguments: object) -> list[str]:
    """Produce the formatted line strings for an args detail block.

    Pure function — returns lines, doesn't print. The lines are
    rich-markup-aware (``[dim]…[/dim]`` etc.) and use ``_DETAIL_INDENT``
    so they nest visually under whatever they appear below.

    Shared by the permanent completion row (bundled into a single
    Group print to avoid Live redraw flicker) and the live spinner
    area (wraps the lines inside the Live renderable while a tool is
    still running).

    Three argument shapes:
      ``dict`` — ``key  value`` rows, key column padded to longest key.
      ``str``  — single quoted-ish line, truncated to value cap.
      other   — JSON-dump on one line.
    """
    if arguments is None:
        return []
    if isinstance(arguments, dict):
        if not arguments:
            return []
        # Pad keys to the longest one so values line up — same trick the
        # ``whoami`` and ``agents get`` views use for kv rows.
        key_width = max(len(str(k)) for k in arguments)
        return [
            f"[dim]{_DETAIL_INDENT}{str(key):<{key_width}}[/dim]  {_render_detail_value(value)}"
            for key, value in arguments.items()
        ]
    if isinstance(arguments, str):
        return [f"[dim]{_DETAIL_INDENT}{_truncate(arguments, _DETAIL_VALUE_MAX)}[/dim]"]
    return [f"[dim]{_DETAIL_INDENT}{_render_detail_value(arguments)}[/dim]"]


def _result_detail_lines(result: object, *, is_failure: bool) -> list[str]:
    """Produce formatted line strings for a tool-result detail block.

    Pure function — returns rich-markup lines. Strings render as-is;
    structured payloads are JSON-dumped one item per line, capped at 20.
    Failures get a red tint so they're scannable in a wall of green
    checks. The caller decides whether to print line-by-line or bundle
    into one renderable (the streaming path bundles to avoid Live
    redraw flicker).
    """
    if result is None:
        return []
    style = "red" if is_failure else "dim"
    if isinstance(result, str):
        text = _truncate(result, _DETAIL_VALUE_MAX * 3)  # results can be longer than args
        return [f"[{style}]{_DETAIL_INDENT}{line}[/{style}]" for line in (text.splitlines() or [text])]
    try:
        rendered = json.dumps(result, indent=2, ensure_ascii=False)
    except (TypeError, ValueError):
        rendered = str(result)
    return [f"[{style}]{_DETAIL_INDENT}{line}[/{style}]" for line in rendered.splitlines()[:20]]


def _render_detail_value(value: object) -> str:
    """Render one value for an args row — short string, JSON-encoded otherwise."""
    if isinstance(value, str):
        return _truncate(value, _DETAIL_VALUE_MAX)
    try:
        return _truncate(json.dumps(value, ensure_ascii=False), _DETAIL_VALUE_MAX)
    except (TypeError, ValueError):
        return _truncate(str(value), _DETAIL_VALUE_MAX)


def _truncate(text: str, max_len: int) -> str:
    text = text.replace("\n", " ") if max_len < 50 else text
    if len(text) <= max_len:
        return text
    return text[: max_len - 1] + "…"


def _render_done(data: dict[str, object], *, agent: str | None = None) -> None:
    """Render the final-event footer with duration, cost, and record ID.

    The execution record ID is the user's handle to follow up via
    ``fruxon trace`` — printing it here is what makes that command
    discoverable in practice. When the agent name is known we follow up
    with a copy-pasteable ``fruxon trace`` line so the user doesn't have
    to assemble it themselves. Falls back gracefully when any of the
    three are absent so partial server payloads still produce a useful
    line.
    """
    trace = data.get("trace") if isinstance(data.get("trace"), dict) else {}
    duration = trace.get("duration") if isinstance(trace, dict) else None
    total_cost = trace.get("totalCost") if isinstance(trace, dict) else None
    record_id = data.get("executionRecordId")
    parts: list[str] = []
    if isinstance(duration, (int, float)) and duration:
        parts.append(format_duration(duration))
    if isinstance(total_cost, (int, float)) and total_cost:
        parts.append(f"${float(total_cost):.4f}")
    if isinstance(record_id, str) and record_id:
        parts.append(f"record [cyan]{record_id}[/cyan]")
    if parts:
        stderr.print(f"[dim]{'  ·  '.join(parts)}[/dim]")
    if agent and isinstance(record_id, str) and record_id:
        stderr.print(f"[dim]→ fruxon trace [bold]{agent}[/bold] [cyan]{record_id}[/cyan][/dim]")


def _format_args(args: object, *, max_len: int = 80) -> str:
    """Render tool arguments as a single-line preview, truncated for readability."""
    if args is None:
        return ""
    if isinstance(args, dict):
        if not args:
            return ""
        rendered = ", ".join(f"{k}={_short_repr(v)}" for k, v in args.items())
    else:
        rendered = _short_repr(args)
    if len(rendered) > max_len:
        return rendered[: max_len - 1] + "…"
    return rendered


def _short_repr(value: object, *, max_len: int = 40) -> str:
    if isinstance(value, str):
        text = value
    else:
        try:
            text = json.dumps(value, ensure_ascii=False)
        except (TypeError, ValueError):
            text = str(value)
    text = text.replace("\n", " ")
    if len(text) > max_len:
        return text[: max_len - 1] + "…"
    return text


# ─────────────────────────────────────────────────────────────────────────────
# Multi-line prompt editor
# ─────────────────────────────────────────────────────────────────────────────


class _EditorError(RuntimeError):
    """Raised when the editor pop-up fails (missing $EDITOR, non-zero exit, …).

    Internal — the CLI surface converts these into a styled error line.
    """


def _edit_in_editor(initial: str, *, key: str) -> str:
    """Open $EDITOR (or $VISUAL, or vi as a last resort) on a temp file
    pre-filled with ``initial``, return whatever the user saved.

    Modeled after ``git commit``'s editor pop-up: a comment header at the
    top of the file tells the user which parameter they're editing, and
    lines starting with ``#`` are stripped from the saved value so the
    header doesn't leak into the parameter.

    Trailing whitespace is trimmed; trailing newlines beyond a single one
    are removed. Empty saved values raise (the user almost certainly
    cancelled).
    """
    import os
    import subprocess
    import tempfile

    editor = os.environ.get("VISUAL") or os.environ.get("EDITOR") or _default_editor()
    if not editor:
        raise _EditorError("No editor configured. Set $EDITOR (or $VISUAL) to your preferred command.")

    header = (
        f"# Editing parameter: {key}\n"
        "# Lines starting with `#` will be removed.\n"
        "# Save and exit to use this value; close without saving to keep the previous one.\n"
        "\n"
    )

    with tempfile.NamedTemporaryFile(
        prefix=f"fruxon-{key}-",
        suffix=".md",
        mode="w",
        delete=False,
        encoding="utf-8",
    ) as tmp:
        tmp.write(header)
        tmp.write(initial)
        tmp_path = tmp.name

    try:
        # ``shell=False`` and a list args splits common editor commands
        # correctly (``code --wait``, ``nano``, ``vim``, etc.).
        cmd = editor.split() + [tmp_path]
        try:
            result = subprocess.run(cmd, check=False)
        except FileNotFoundError as exc:
            raise _EditorError(f"Editor `{editor}` not found on $PATH.") from exc
        if result.returncode != 0:
            raise _EditorError(f"Editor `{editor}` exited with status {result.returncode}.")

        with open(tmp_path, encoding="utf-8") as f:
            saved = f.read()
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass

    # Strip our header comment lines and surrounding blank lines.
    body = "\n".join(line for line in saved.splitlines() if not line.startswith("#"))
    body = body.strip("\n")
    if not body.strip():
        raise _EditorError(f"No value entered for [bold]{key}[/bold].")
    return body


def _default_editor() -> str | None:
    """Pick a sensible editor when $EDITOR isn't set.

    We avoid using ``vim`` as a default because users without prior vim
    experience can't escape it. ``nano`` is much friendlier as a fallback;
    on Windows ``notepad`` is the safe pick. Return ``None`` if nothing
    plausible is installed so the caller can raise a clear "set $EDITOR"
    error.
    """
    import shutil

    for candidate in ("nano", "notepad", "vim", "vi"):
        if shutil.which(candidate):
            return candidate
    return None
