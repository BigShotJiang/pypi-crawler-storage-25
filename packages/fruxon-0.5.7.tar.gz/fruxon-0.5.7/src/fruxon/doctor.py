"""Health checks the ``fruxon doctor`` command runs.

Each check is a small function that returns a ``CheckResult`` so the CLI
can render the list uniformly (✓ pass, ✗ fail, ▲ warn, with a one-line
hint when applicable). Pure logic — the CLI side handles the rendering
and exit code, this module just knows how to ask the questions.

Adding a new check is a single function + one ``checks.append(...)`` line
in :func:`run_checks`. Each check is independent and can't poison the
others; if connectivity is down the version check still runs.
"""

from __future__ import annotations

import os
import ssl
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from fruxon import credentials
from fruxon.fruxon import FruxonClient

Status = Literal["ok", "warn", "fail"]


@dataclass(frozen=True)
class CheckResult:
    """A single health-check outcome.

    ``status`` drives the glyph the CLI prints; ``hint`` is rendered dim
    underneath the title when set, and tends to carry either the actual
    value (e.g. resolved API base URL) or a "to fix this..." suggestion.
    """

    title: str
    status: Status
    detail: str
    hint: str | None = None


# ─────────────────────────────────────────────────────────────────────────────
# Individual checks
# ─────────────────────────────────────────────────────────────────────────────


def check_shell_completion() -> CheckResult:
    """Detect whether shell completion is installed for ``fruxon``.

    Best-effort: we look for a "fruxon" fragment in the user's shell rc /
    completion-directory files. False negatives are fine — if we miss
    it, the user runs ``fruxon --install-completion`` and the next
    ``doctor`` will find it. The check exists so the install instruction
    surfaces automatically the first time a user runs doctor on a fresh
    machine.
    """
    home = Path.home()
    candidates = [
        home / ".bashrc",
        home / ".bash_profile",
        home / ".zshrc",
        home / ".config" / "fish" / "completions" / "fruxon.fish",
    ]
    for path in candidates:
        try:
            if path.exists() and "fruxon" in path.read_text(errors="ignore"):
                return CheckResult("Shell completion", "ok", f"installed in {path.name}")
        except OSError:
            continue

    # Optional feature — never fail or warn the overall doctor status just
    # because completion isn't installed. The hint surfaces the install
    # command so users who want it can find it without leaving the terminal.
    shell = os.environ.get("SHELL", "").rsplit("/", 1)[-1] or "your shell"
    return CheckResult(
        "Shell completion",
        "ok",
        "not installed (optional)",
        hint=f"Run `fruxon --install-completion` to enable tab completion for {shell}.",
    )


def check_python_version() -> CheckResult:
    """Surface the interpreter version. Not a hard pass/fail — pyproject pins
    the minimum, so the runtime would have refused to install on too-old
    versions; this is informational so the user can see what's in play."""
    import sys

    version = ".".join(str(n) for n in sys.version_info[:3])
    return CheckResult(
        title="Python interpreter",
        status="ok",
        detail=version,
        hint=sys.executable,
    )


def check_sdk_version(*, skip_network: bool = False) -> CheckResult:
    """Show the active Fruxon SDK version.

    Routes through :func:`fruxon.ui.get_version` rather than calling
    ``importlib.metadata.version`` directly so the value matches what
    the rest of the CLI surfaces — including the dev-from-source case
    where ``hatch-vcs`` knows we're past the last tag and reports
    ``X.Y.Z-dev``. Without this, ``fruxon doctor`` would happily lie
    about being v0.4.0 while the banner displayed the truthful
    ``v0.5.2-dev``.

    Doctor is the natural place to surface "your fruxon is out of date"
    inline rather than waiting on the at-exit notifier — users run
    doctor specifically to confirm their setup is healthy, and a stale
    SDK is exactly the kind of thing they want to hear about. We reuse
    the cached PyPI version from :mod:`fruxon.update_check` so this is
    free on the warm path (one HTTP call per 24h).
    """
    from fruxon.ui import get_version

    version = get_version()
    if version == "dev":
        return CheckResult(
            "Fruxon SDK",
            "warn",
            "running from source (no installed distribution)",
            hint="Install via `pip install -e .` for accurate version reporting.",
        )

    upgrade_hint: str | None = None
    if not skip_network:
        try:
            from fruxon.update_check import maybe_notify

            notice = maybe_notify(current=version)
            if notice:
                # ``maybe_notify`` returns a full sentence; extract the
                # ``vX → vY`` segment for terseness in the doctor row.
                import re

                match = re.search(r"v[\d.]+\s*→\s*v([\d.]+)", notice)
                latest = match.group(1) if match else None
                if latest:
                    return CheckResult(
                        "Fruxon SDK",
                        "warn",
                        f"v{version} (newer available: v{latest})",
                        hint="Upgrade with `pip install -U fruxon`.",
                    )
        except Exception:
            # Doctor must never fail because of a side check — same
            # silent-on-error contract the at-exit notifier uses.
            pass

    return CheckResult("Fruxon SDK", "ok", f"v{version}", hint=upgrade_hint)


def check_credentials_file() -> CheckResult:
    """Verify the credentials file exists and is readable."""
    path = credentials.credentials_path()
    if not path.exists():
        return CheckResult(
            "Credentials file",
            "warn",
            "not created yet",
            hint=f"Run `fruxon login` to create {path}.",
        )
    creds = credentials.load()
    if not creds.api_key:
        return CheckResult(
            "Credentials file",
            "warn",
            f"present but no API key stored ({path})",
            hint="Run `fruxon login` to populate it.",
        )
    return CheckResult("Credentials file", "ok", str(path))


def check_api_key() -> CheckResult:
    """Confirm an API key resolves from somewhere — flag, env, or file."""
    api_key = credentials.resolve_api_key(None)
    if not api_key:
        return CheckResult(
            "API key",
            "fail",
            "no API key resolved",
            hint="Run `fruxon login`, pass `--api-key`, or set `$FRUXON_API_KEY`.",
        )
    from fruxon.ui import redact_key

    return CheckResult("API key", "ok", redact_key(api_key), hint=_source_of("FRUXON_API_KEY", api_key))


def check_org() -> CheckResult:
    """Confirm an organization identifier resolves."""
    org = credentials.resolve_org(None)
    if not org:
        return CheckResult(
            "Organization",
            "warn",
            "no org resolved",
            hint="Pass `--org`, set `$FRUXON_ORG`, or store a default with `fruxon login --org <id>`.",
        )
    return CheckResult("Organization", "ok", org, hint=_source_of("FRUXON_ORG", org))


def check_base_url() -> CheckResult:
    """Surface the API base URL the CLI will talk to."""
    base_url = credentials.resolve_base_url(None) or FruxonClient.DEFAULT_BASE_URL
    return CheckResult("Base URL", "ok", base_url, hint=_source_of("FRUXON_BASE_URL", base_url))


def check_auth(*, opener=None, timeout: float = 5.0) -> CheckResult:
    """Hit an authenticated endpoint to confirm the API key actually works.

    Reachability (above) only proves we can reach the server. This check
    catches the much more common "I have a key set up but it's expired /
    deactivated / wrong org" failure mode by making a low-cost
    authenticated request (``GET /agents``) and inspecting the status:

    * 2xx → the key is valid for this org.
    * 401 → the key is rejected. ``fruxon login`` to refresh.
    * 403 → the key works, but this org isn't accessible to it.
    * 404 → org ID doesn't exist server-side.
    * other → surfaces as a warning so users see the raw status.

    Skipped (returns ``warn``) when there's no resolved API key or
    org, since we'd have nothing to authenticate with — the
    standalone API-key / org checks already report that condition.
    """
    api_key = credentials.resolve_api_key(None)
    org = credentials.resolve_org(None)
    if not api_key or not org:
        return CheckResult(
            "Authenticated probe",
            "warn",
            "skipped — missing API key or org",
            hint="Resolve the credential / org checks above first.",
        )

    base_url = credentials.resolve_base_url(None) or FruxonClient.DEFAULT_BASE_URL
    # The backend still uses ``/v1/tenants/{X}/...`` as its URL — that's
    # an implementation detail of the server's multi-tenant architecture
    # and unrelated to what users call their org in the CLI.
    probe_url = f"{base_url.rstrip('/')}/v1/tenants/{org}/agents"
    request = urllib.request.Request(
        probe_url,
        headers={"Accept": "application/json", "X-API-KEY": api_key},
        method="GET",
    )

    try:
        opener = opener or urllib.request.urlopen
        with opener(request, timeout=timeout):
            return CheckResult("Authenticated probe", "ok", "API key accepted")
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            return CheckResult(
                "Authenticated probe",
                "fail",
                "API key rejected (401)",
                hint="Run `fruxon login` to refresh, or `fruxon whoami` to confirm which key is in play.",
            )
        if exc.code == 403:
            return CheckResult(
                "Authenticated probe",
                "fail",
                f"Org access denied (403) for `{org}`",
                hint="The key is valid but doesn't grant access to this org.",
            )
        if exc.code == 404:
            return CheckResult(
                "Authenticated probe",
                "fail",
                f"Org `{org}` not found (404)",
                hint="Confirm the org ID with `fruxon whoami` or your dashboard.",
            )
        return CheckResult(
            "Authenticated probe",
            "warn",
            f"Server replied {exc.code}",
            hint="Unexpected status — the key may still be fine. Try `fruxon agents list` to confirm.",
        )
    except (TimeoutError, urllib.error.URLError, ssl.SSLError, OSError) as exc:
        # Don't double-report what `check_connectivity` already covers —
        # just note that we couldn't reach the server. Reachability has
        # the actionable hint.
        reason = getattr(exc, "reason", exc)
        return CheckResult(
            "Authenticated probe",
            "warn",
            f"network error: {reason}",
            hint="See the API reachability check above.",
        )


def check_connectivity(*, opener=None, timeout: float = 5.0) -> CheckResult:
    """TCP+TLS reachability check against the configured base URL.

    We deliberately do *not* hit an authenticated endpoint here — auth
    issues should fall to ``check_api_key`` separately. A simple HEAD to
    the root surfaces DNS / firewall / TLS problems without requiring a
    valid key.

    ``opener`` is injected for tests; production callers leave it ``None``.
    """
    base_url = credentials.resolve_base_url(None) or FruxonClient.DEFAULT_BASE_URL
    parsed = urllib.parse.urlparse(base_url)
    if not parsed.scheme or not parsed.netloc:
        return CheckResult(
            "API reachability",
            "fail",
            f"base URL is malformed: {base_url}",
            hint="Run `fruxon config set base_url=https://api.fruxon.com`.",
        )

    request = urllib.request.Request(base_url, method="HEAD")
    try:
        opener = opener or urllib.request.urlopen
        with opener(request, timeout=timeout):
            return CheckResult("API reachability", "ok", base_url)
    except urllib.error.HTTPError:
        # Any HTTP response means we reached the server. Even 401/403/404
        # is a passing reachability check — the auth/route status is the
        # job of ``check_auth`` below, not this one. We deliberately
        # don't surface the status code here: showing "server replied 401"
        # next to a green ✓ reads as alarming even though it's fine.
        return CheckResult("API reachability", "ok", base_url)
    except (TimeoutError, urllib.error.URLError, ssl.SSLError, OSError) as exc:
        reason = getattr(exc, "reason", exc)
        return CheckResult(
            "API reachability",
            "fail",
            f"could not reach {base_url}: {reason}",
            hint="Check network / VPN / firewall. "
            "Override with `--base-url` or `$FRUXON_BASE_URL` if you're testing staging.",
        )


# ─────────────────────────────────────────────────────────────────────────────
# Orchestrator
# ─────────────────────────────────────────────────────────────────────────────


def run_checks(*, skip_network: bool = False) -> list[CheckResult]:
    """Run every check in display order, returning their results.

    Skipping the network check is useful in tests and in environments
    where the user explicitly wants a fast offline diagnosis.
    """
    checks: list[CheckResult] = [
        check_python_version(),
        check_sdk_version(skip_network=skip_network),
        check_credentials_file(),
        check_api_key(),
        check_org(),
        check_base_url(),
        check_shell_completion(),
    ]
    if not skip_network:
        checks.append(check_connectivity())
        checks.append(check_auth())
    return checks


def overall_status(results: list[CheckResult]) -> Status:
    """Roll-up: fail trumps warn trumps ok. Drives the CLI exit code."""
    if any(r.status == "fail" for r in results):
        return "fail"
    if any(r.status == "warn" for r in results):
        return "warn"
    return "ok"


# ─────────────────────────────────────────────────────────────────────────────
# Internals
# ─────────────────────────────────────────────────────────────────────────────


def _source_of(env_name: str, active: str) -> str:
    if os.environ.get(env_name) == active:
        return f"from ${env_name}"
    file_creds = credentials.load()
    if getattr(file_creds, env_name.removeprefix("FRUXON_").lower(), None) == active:
        return "from credentials file"
    return "from default"
