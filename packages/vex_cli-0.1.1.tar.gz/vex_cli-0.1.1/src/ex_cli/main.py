"""
ex — 主入口
处理 CLI 参数，分发到各子功能
"""

import sys
import os

def main():
    args = sys.argv[1:]

    # ── 管理命令 ──────────────────────────────────────
    if not args or args[0] in ("-h", "--help"):
        _print_help()
        return

    if args[0] in ("-v", "--version"):
        from ex_cli import __version__
        print(f"vex {__version__}")
        return

    if args[0] == "--setup":
        from ex_cli.setup import run_setup
        run_setup()
        return

    if args[0] == "--config":
        from ex_cli.setup import run_config
        run_config()
        return

    if args[0] == "--shell-plugin":
        from ex_cli.setup import get_plugin_path
        print(get_plugin_path())
        return

    if args[0] == "--update":
        _run_update()
        return

    # ── AI 执行模式 ────────────────────────────────────
    if args:
        query = args[0]
        mode  = args[1] if len(args) > 1 else "confirm"

        # 首次运行检测：没有配置任何 API Key
        if not _has_any_key():
            _prompt_key_setup()
            return

        from ex_cli.engine import run
        run(query, mode)
        return

    _print_help()


def _has_any_key() -> bool:
    """检查是否配置了任意 LLM API Key（包括本地 ollama）"""
    import shutil
    return bool(
        os.environ.get("DEEPSEEK_API_KEY") or
        os.environ.get("MOONSHOT_API_KEY") or
        os.environ.get("OPENAI_API_KEY") or
        os.environ.get("ANTHROPIC_API_KEY") or
        shutil.which("ollama")   # 本地 ollama 也算
    )


def _prompt_key_setup():
    """首次运行时，引导用户填入 API Key"""
    B="\033[1m"; D="\033[2m"; R="\033[0m"
    Y="\033[33m"; C="\033[36m"; G="\033[32m"; GY="\033[90m"

    print(f"""
{B}vex{R} 需要一个 LLM API Key 才能运行。

vex 本身{B}完全免费{R}，你只需要自己的 API Key。
以下提供商都有免费额度，按需选择：

  {C}1{R}  {B}DeepSeek{R}   {GY}api.deepseek.com{R}
         注册即送余额，¥0.001/千 tokens，最便宜
         适合：追求低成本，国内访问稳定

  {C}2{R}  {B}Kimi{R}       {GY}platform.moonshot.cn{R}
         月之暗面，注册有免费额度
         适合：国内用户，中文理解好

  {C}3{R}  {B}OpenAI{R}     {GY}platform.openai.com{R}
         GPT-4o-mini，按量付费
         适合：需要最强模型效果

  {C}4{R}  {B}Ollama{R}     {GY}ollama.com{R}
         本地运行，{B}完全免费{R}，无需 API Key
         适合：注重隐私，不想花钱

""")

    choice = input(f"  选择 [{C}1{R}-{C}4{R}，回车取消]: ").strip()
    if not choice:
        return

    key_map = {
        "1": ("DEEPSEEK_API_KEY",  "DeepSeek",  "https://platform.deepseek.com/api_keys"),
        "2": ("MOONSHOT_API_KEY",  "Kimi",       "https://platform.moonshot.cn/console/api-keys"),
        "3": ("OPENAI_API_KEY",    "OpenAI",     "https://platform.openai.com/api-keys"),
    }

    if choice == "4":
        print(f"""
  {B}安装 Ollama：{R}

    curl -fsSL https://ollama.com/install.sh | sh
    ollama run qwen2.5-coder:7b    {GY}# 拉取推荐模型（约 5GB）{R}

  安装完成后重新运行 vex 即可，无需 API Key。
""")
        return

    if choice not in key_map:
        return

    env_var, name, url = key_map[choice]
    print(f"\n  打开以下链接获取 API Key：\n  {G}{url}{R}\n")

    key = input(f"  粘贴你的 {name} API Key: ").strip()
    if not key:
        print(f"\n  {Y}已取消。之后运行 vex --config 重新配置。{R}\n")
        return

    # 写入 shell rc 文件
    from ex_cli.setup import detect_shell, _set_env_in_rc
    shell, rc_file = detect_shell()
    _set_env_in_rc(env_var, key, rc_file)
    os.environ[env_var] = key   # 当前进程立即生效

    print(f"\n  {G}✓{R} 已保存到 {D}{rc_file}{R}")
    print(f"\n  {D}（首次配置需要 source {rc_file} 或重开终端后永久生效）{R}")
    print(f"\n  现在重新执行你的命令即可。\n")


def _print_help():
    from ex_cli import __version__
    B="\033[1m"; D="\033[2m"; C="\033[36m"; G="\033[32m"; GY="\033[90m"; R="\033[0m"
    print(f"""
{B}vex{R} {D}v{__version__}{R} — 自然语言驱动 CLI   {GY}(完全免费，使用你自己的 API Key){R}

{B}使用方式{R}
  在空白行输入 {C}:{R} 进入 AI 命令模式：
  {C}:{R}找出所有超过200行的Python文件
  {C}:{R}把 demo.mp4 每秒截一帧
  {C}:!{R}ls -la          {D}# 直通 shell（Vim :! 语义）{R}
  {C}:q{R}                {D}# 什么都不发生{R}

{B}命令{R}
  vex --setup       初始化 shell 集成（首次安装后运行一次）
  vex --config      管理 API Key / 执行模式
  vex --version     显示版本

{B}API Key{R}   {GY}vex 不收费，使用你自己的 Key{R}
  {G}1{R}  DeepSeek   platform.deepseek.com   {D}最便宜{R}
  {G}2{R}  Kimi       platform.moonshot.cn
  {G}3{R}  OpenAI     platform.openai.com
  {G}4{R}  Ollama     ollama.com              {D}本地，完全免费{R}

{B}快速开始{R}
  pipx install ex-cli
  vex --setup
  {D}重开终端，输入 : 即可{R}
""")


def _run_update():
    import subprocess
    print("正在更新 ex-cli ...")
    r = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--upgrade", "ex-cli"],
        capture_output=True, text=True
    )
    if r.returncode == 0:
        print("✓ 已更新到最新版本")
    else:
        print("✗ 更新失败：", r.stderr[:200])
