"""
ex — AI 规划与执行引擎
"""

import os, sys, json, shutil, subprocess
from pathlib import Path

# ─── 颜色 ─────────────────────────────────────────────
R="\033[0m"; B="\033[1m"; D="\033[2m"
CY="\033[36m"; YL="\033[33m"; GR="\033[32m"; RD="\033[31m"; WH="\033[97m"
BG_DARK="\033[48;5;235m"; BG_ST="\033[48;5;238m"
BG_GR="\033[42m"; BG_YL="\033[43m"
FG_BK="\033[30m"; FG_GY="\033[90m"

def tw():
    try: return os.get_terminal_size().columns
    except: return 80

# ─── Vim 风格 UI ──────────────────────────────────────

def statusline(mode="DONE", left="", right="smart-cli/ex"):
    w = tw()
    mc = {
        "AI CMD":  f"{BG_GR}{FG_BK}",
        "RUNNING": f"{BG_YL}{FG_BK}",
        "DONE":    f"{BG_GR}{FG_BK}",
        "ERROR":   f"\033[41m{WH}",
    }.get(mode, f"{BG_ST}{WH}")

    ml   = len(f"  {mode}  ")
    fill = "─" * max(0, w - ml - len(left) - len(right) - 4)
    print(f"{mc}{B}  {mode}  {R}{BG_ST}{FG_GY}  {left}{fill}{right}  {R}")

def print_plan(plan: dict, user_input: str):
    print(f"\n{D}:{user_input}{R}\n")
    print(f"  {CY}{B}▌{R} {B}{plan.get('summary','')}{R}\n")

    for s in plan.get("steps", []):
        print(f"  {BG_DARK}{YL}  {s['id']}  {R} {WH}{s['cmd']}{R}")
        print(f"       {D}\" {s['desc']}{R}\n")

    if plan.get("pipeline"):
        w = tw()
        print(f"  {D}{'─'*(w-4)}{R}")
        print(f"  {FG_GY}管道:{R}  {YL}{B}{plan['pipeline']}{R}\n")

    for msg in plan.get("warnings", []):
        print(f"  {RD}{B}W:{R}{RD}  {msg}{R}")
    if plan.get("warnings"): print()

    for alt in plan.get("alternatives", []):
        print(f"  {CY}\"  {alt}{R}")
    if plan.get("alternatives"): print()

def print_output(text: str, max_lines: int = 25):
    lines = text.strip().split("\n")
    for l in lines[:max_lines]:
        print(f"  {D}│{R} {l}")
    if len(lines) > max_lines:
        print(f"  {D}│ ... {len(lines)-max_lines} 行已折叠{R}")

# ─── 工具知识库 ───────────────────────────────────────
TOOLS = """
ripgrep(rg): rg "p" path | rg --json "p" | rg -t py "p" | rg -l "p"
fd: fd -e py . | fd -t d name | fd -e log . -x rm {}
jq: jq '.field' | jq '.[]|.name' | jq 'select(.x>1)' | jq '{a,b}'
yq: yq '.k' f.yaml | yq -o json f.yaml
markitdown: markitdown in.pdf | markitdown in.docx > out.md
pandoc: pandoc in.pdf -o out.md | pandoc in.docx -o out.md
ffmpeg: ffmpeg -i in.mp4 -vf fps=1 frame_%04d.jpg | ffmpeg -i in.mp4 -vn out.aac
imagemagick(magick): magick in.png out.jpg | magick mogrify -resize 50% *.jpg
gh: gh pr list --json number,title | gh issue create -t "t" -b "b" | gh run list
stripe: stripe listen --forward-to localhost:3000/webhook | stripe events list
supabase: supabase start | supabase db push | supabase gen types typescript
semgrep: semgrep --json --config auto . | jq '.results[]'
ruff: ruff check . | ruff check --fix . | ruff check --output-format json .
trivy: trivy fs . | trivy image nginx | trivy fs --format json . | jq '.Results[]'
shellcheck: shellcheck -f json script.sh | jq '.'
hyperfine: hyperfine 'cmd1' 'cmd2' | hyperfine --export-json res.json 'cmd'
docker: docker build -t name . | docker ps --format json | jq '.' | docker logs -f id
kubectl: kubectl get pods -o json | jq '.items[].metadata.name' | kubectl apply -f f.yaml
ollama: ollama run llama3.2 | ollama list
llm: llm "q" | llm -m gpt-4o "q" | cat f | llm "总结"
uv: uv pip install pkg | uv venv | uv run script.py
terraform: terraform init | terraform plan | terraform apply -auto-approve
curl: curl -s url | jq '.' | curl -sX POST -H "Content-Type: application/json" -d '{}' url
sort/awk/sed: sort -rn | awk '{print $1}' | sed 's/old/new/g'
find: find . -size +10M | find . -mtime -7 | find . -name "*.log" -exec rm {} +
"""

SYSTEM = f"""你是 CLI 专家。根据需求输出 JSON 执行计划。

工具列表：
{TOOLS}

输出格式：
{{"summary":"一句话目标","steps":[{{"id":1,"cmd":"完整命令","desc":"说明","output_to_next":false}}],"pipeline":"管道命令或null","warnings":[],"alternatives":[]}}

规则：只用上述工具，命令完整可执行，删除操作必须在warnings说明。
"""

# ─── LLM ──────────────────────────────────────────────
def call_llm(query: str, cwd: str) -> dict:
    prompt = f"当前目录：{cwd}\n需求：{query}"

    deep = os.environ.get("DEEPSEEK_API_KEY")
    kimi = os.environ.get("MOONSHOT_API_KEY")
    oai  = os.environ.get("OPENAI_API_KEY")

    if deep:
        return _compat("https://api.deepseek.com", deep, "deepseek-chat", prompt)
    if kimi:
        return _compat("https://api.moonshot.cn/v1", kimi, "moonshot-v1-8k", prompt)
    if oai:
        return _compat("https://api.openai.com/v1", oai, "gpt-4o-mini", prompt)
    return _ollama(prompt)

def _compat(base, key, model, prompt):
    import urllib.request
    data = json.dumps({
        "model": model,
        "messages": [{"role":"system","content":SYSTEM},
                     {"role":"user","content":prompt}],
        "temperature": 0.1,
        "response_format": {"type":"json_object"}
    }).encode()
    req = urllib.request.Request(
        f"{base}/chat/completions", data=data,
        headers={"Content-Type":"application/json",
                 "Authorization":f"Bearer {key}"}
    )
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(json.loads(r.read())["choices"][0]["message"]["content"])

def _ollama(prompt):
    import urllib.request
    data = json.dumps({
        "model":"qwen2.5-coder:7b",
        "prompt":f"{SYSTEM}\n\n{prompt}",
        "stream":False,"format":"json"
    }).encode()
    try:
        req = urllib.request.Request(
            "http://localhost:11434/api/generate", data=data,
            headers={"Content-Type":"application/json"}
        )
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(json.loads(r.read())["response"])
    except Exception:
        raise RuntimeError(
            "未找到可用的 LLM。请运行 vex --config 配置 API Key。\n\n"
            "  免费选项：\n"
            "  · DeepSeek  platform.deepseek.com   最便宜\n"
            "  · Kimi      platform.moonshot.cn\n"
            "  · Ollama    ollama.com               本地，完全免费\n"
        )

# ─── Vim 命令处理 ──────────────────────────────────────
VIM = {
    "q": "什么都不发生", "q!": None, "qa": None,
    "wq": None, "x": None, "w": "已保存",
    "noh":"(noh)", "set":"这不是 Vim", "vs":"没有窗口", "sp":"没有窗口",
}

def handle_vim(s: str) -> bool:
    """返回 True=已处理，不需要 AI"""
    if s.startswith("!"):
        print(f"\n  {D}:{s}{R}")
        subprocess.run(s[1:].strip(), shell=True)
        print()
        return True
    base = s.split()[0] if s else ""
    if base in VIM:
        msg = VIM[base]
        if msg:
            print(f"\n  {D}\" {msg}{R}\n")
        else:
            sys.exit(0)
        return True
    if s.isdigit():
        print(f"\n  {D}\" {s}G — 这不是 Vim{R}\n")
        return True
    return False

# ─── 执行引擎 ─────────────────────────────────────────
def missing_tools(plan):
    builtins = {"for","while","if","echo","cat","grep","sort","awk","sed",
                "find","wc","xargs","cut","tr","head","tail","mkdir","rm",
                "cp","mv","chmod","curl","wget","npm","npx","pip","python3",
                "node","go","sh","bash","printf","read","export"}
    seen = set()
    for s in plan.get("steps", []):
        t = s["cmd"].split()[0].lstrip("(")
        if t not in builtins and t not in seen:
            if not shutil.which(t):
                seen.add(t)
    return list(seen)

def run_cmd(cmd, cwd, stdin=None):
    r = subprocess.run(cmd, shell=True, cwd=cwd,
                       input=stdin, capture_output=True)
    return r.returncode == 0, r.stdout, r.stderr

def exec_pipeline(cmd, cwd):
    ok, out, err = run_cmd(cmd, cwd)
    if out: print_output(out.decode(errors="replace"))
    if not ok and err:
        print(f"\n  {RD}E:{R} {err.decode(errors='replace')[:300]}")
    return ok

def exec_steps(steps, cwd, auto=False):
    n   = len(steps)
    buf = None
    for s in steps:
        print(f"\n  {BG_ST}{YL}  {s['id']}/{n}  {R} {D}{s['desc']}{R}")
        print(f"  {FG_GY}:{R}{WH}{s['cmd']}{R}")
        if not auto:
            print(f"\n  {D}[Y]执行  [n]跳过  [e]编辑  [q]退出{R}  ", end="")
            try:    ch = input().strip().lower()
            except: print(); return
            if ch == "q": print(f"  {D}:q{R}\n"); return
            if ch == "n": print(f"  {D}\" 跳过{R}"); continue
            if ch == "e":
                print(f"  {FG_GY}:{R}", end="")
                nc = input().strip()
                if nc: s["cmd"] = nc
        ok, out, err = run_cmd(s["cmd"], cwd, buf if s.get("output_to_next") else None)
        if out:
            print(); print_output(out.decode(errors="replace")); buf = out
        if not ok:
            print(f"\n  {RD}E:{R} {err.decode(errors='replace')[:200]}")
            if auto: return

# ─── 主函数 ───────────────────────────────────────────
def run(query: str, mode: str = "confirm"):
    cwd = os.getcwd()

    # h前缀 → dry run
    dry = False
    import re
    if re.match(r'^h(elp)?\s+', query):
        query = re.sub(r'^h(elp)?\s+', '', query)
        dry = True

    if handle_vim(query):
        return

    # 规划
    print(f"\n  {D}:{query}{R}")
    print(f"  {FG_GY}规划中...{R}", end="\r", flush=True)
    try:
        plan = call_llm(query, cwd)
        print(f"  {'           '}\r", end="")
    except RuntimeError as e:
        print(f"\n  {RD}E:{R} {e}\n"); return
    except Exception as e:
        print(f"\n  {RD}E:{R} {e}\n"); return

    print_plan(plan, query)

    # 缺失工具
    miss = missing_tools(plan)
    if miss:
        HINTS = {
            "rg":"brew install ripgrep","fd":"brew install fd",
            "bat":"brew install bat","eza":"brew install eza",
            "jq":"brew install jq","yq":"brew install yq",
            "semgrep":"pip install semgrep","ruff":"pip install ruff",
            "trivy":"brew install trivy","hyperfine":"brew install hyperfine",
        }
        print(f"  {YL}W:{R}  未安装：{', '.join(miss)}")
        for m in miss:
            print(f"       {D}:!{HINTS.get(m, f'# 请安装 {m}')}{R}")
        print()

    if dry or mode == "dry":
        print(f"  {D}\" 演习模式{R}\n"); return

    has_pipe = bool(plan.get("pipeline"))
    steps    = plan.get("steps", [])

    if mode == "auto":
        exec_pipeline(plan["pipeline"], cwd) if has_pipe else exec_steps(steps, cwd, auto=True)
        print(); statusline("DONE", left=f" {query[:40]}"); return

    if has_pipe and len(steps) > 1:
        print(f"  {D}[p]管道执行  [s]逐步确认  [h]只看计划  [q]退出{R}  ", end="")
        try:    ch = input().strip().lower()
        except: print(); return
        if ch == "q": return
        if ch == "h": return
        if ch == "p":
            print(); exec_pipeline(plan["pipeline"], cwd)
            print(); statusline("DONE", left=f" {query[:40]}"); return

    exec_steps(steps, cwd)
    print(); statusline("DONE", left=f" {query[:40]}")
