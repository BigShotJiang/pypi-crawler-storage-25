# vex.zsh — 由 vex --setup 自动写入 ~/.zshrc
# 不要手动编辑此文件
#
# 工作原理：
#   正常输入 :查询  →  按回车  →  vex 处理
#   : 键不再被拦截，输入更自然

: "${EX_MODE:=confirm}"
: "${EX_QUIET:=0}"

_VEX_BIN="$(command -v vex 2>/dev/null)"

# ─── 核心：拦截回车键 ─────────────────────────────────
_vex_accept_line() {
  local buf="${BUFFER}"

  # 不以 : 开头，或 :: 开头 → 正常执行
  if [[ "${buf}" != :* ]] || [[ "${buf}" == ::* ]]; then
    zle accept-line
    return
  fi

  # 取出 : 后面的查询内容
  local query="${buf:1}"

  # 只有 : 没有内容 → 正常执行
  if [[ -z "${query// /}" ]]; then
    zle accept-line
    return
  fi

  # 清空缓冲区，交给 vex
  BUFFER=""
  zle reset-prompt
  echo

  # 写入历史
  print -s ":${query}"
  echo "${query}" >> "${HOME}/.vex_history"

  # Vim 特殊命令
  case "${query}" in
    q|wq|w|noh)
      print -P "%F{240}  \" (${query})%f"
      echo; return ;;
    "q!"|qa|x)
      exit 0 ;;
  esac

  # :! → 直通 shell
  if [[ "${query}" == !* ]]; then
    eval "${query:1}"
    echo; return
  fi

  # :h → dry-run
  if [[ "${query}" == h\ * ]]; then
    "${_VEX_BIN}" "${query}" "dry"
    echo; return
  fi

  # 正常 AI 查询
  "${_VEX_BIN}" "${query}" "${EX_MODE}"
  echo
}

zle -N _vex_accept_line
bindkey '^M' _vex_accept_line
bindkey '^J' _vex_accept_line

# ─── 快捷别名 ──────────────────────────────────────────
function vq() { [[ -z "$*" ]] && return; "${_VEX_BIN}" "$*" "${EX_MODE}"; }

# ─── 启动提示 ──────────────────────────────────────────
[[ "${EX_QUIET}" != "1" && -o interactive ]] && \
  print -P "%F{240}  vex ready · 输入 :查询 回车触发%f"
