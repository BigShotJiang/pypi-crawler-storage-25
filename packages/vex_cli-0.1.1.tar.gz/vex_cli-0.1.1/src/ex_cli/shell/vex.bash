# vex.bash — 由 vex --setup 自动写入 ~/.bashrc

: "${EX_MODE:=confirm}"
: "${EX_QUIET:=0}"

_EX_BIN="$(command -v vex 2>/dev/null)"

_ex_readline() {
  if [[ -n "${READLINE_LINE// /}" ]]; then
    READLINE_LINE="${READLINE_LINE}:"; READLINE_POINT=${#READLINE_LINE}; return
  fi
  printf "\r\033[2K"
  local w="${COLUMNS:-80}"
  printf "\033[42m\033[30m\033[1m  AI CMD  \033[0m"
  printf "\033[48;5;238m\033[90m  %-$((w-20))s  \033[0m\r" ""
  printf "\033[1m\033[97m:\033[0m\033[97m"

  local input; IFS= read -re input 2>/dev/null; printf "\033[0m"
  [[ -z "${input// /}" ]] && { READLINE_LINE=""; return; }

  case "${input}" in
    "q"|"wq"|"w") READLINE_LINE=""; return ;;
    "q!"|"qa"|"x") exit 0 ;;
  esac

  history -s ":${input}"
  echo "${input}" >> "${HOME}/.vex_history"
  echo
  "${_EX_BIN}" "${input}" "${EX_MODE}"
  echo
  READLINE_LINE=""; READLINE_POINT=0
}

bind -x '":":_ex_readline'

function : () { [[ -z "$*" ]] && return; "${_EX_BIN}" "$*" "${EX_MODE}"; }

[[ "${EX_QUIET}" != "1" && "$-" == *i* ]] && \
  printf "\\033[90m  vex  :自然语言  :!cmd  :q\\033[0m\\n"
