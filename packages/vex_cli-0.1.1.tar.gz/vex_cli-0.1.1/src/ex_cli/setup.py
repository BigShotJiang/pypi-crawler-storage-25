"""
vex --setup / --config
负责 shell 集成和 LLM 配置
"""

import os
import sys
import shutil
import subprocess
from pathlib import Path

# ─── 颜色 ─────────────────────────────────────────────
B  = "\033[1m"; D  = "\033[2m"; R  = "\033[0m"
G  = "\033[32m"; Y  = "\033[33m"; C  = "\033[36m"; RED = "\033[31m"

def ok(t):   print(f"{G}✓{R} {t}")
def info(t): print(f"{C}▷{R} {t}")
def warn(t): print(f"{Y}⚠{R} {t}")
def err(t):  print(f"{RED}✗{R} {t}")
def ask(prompt): return input(f"  {D}{prompt}{R} ").strip()


def get_plugin_path() -> str:
    """返回 shell 插件文件的绝对路径"""
    pkg_dir = Path(__file__).parent
    shell   = Path(os.environ.get("SHELL", "")).name
    if shell == "zsh":
        return str(pkg_dir / "shell" / "vex.zsh")
    else:
        return str(pkg_dir / "shell" / "vex.bash")


def detect_shell() -> tuple[str, Path]:
    """返回 (shell名称, rc文件路径)"""
    shell = Path(os.environ.get("SHELL", "/bin/bash")).name
    home  = Path.home()
    rc_map = {
        "zsh":  home / ".zshrc",
        "bash": home / ".bashrc",
        "fish": home / ".config/fish/config.fish",
    }
    rc = rc_map.get(shell, home / ".bashrc")
    return shell, rc


def run_setup():
    """首次安装向导"""
    print(f"\n{B}vex 初始化向导{R}")
    print(f"{D}vex 本身完全免费，使用你自己的 API Key{R}\n")

    # 1. 检测 shell
    shell, rc_file = detect_shell()
    info(f"Shell：{B}{shell}{R}  配置文件：{D}{rc_file}{R}")

    if shell == "fish":
        warn("Fish shell 需要手动配置，请参考 README")
        return

    # 2. 配置 LLM
    print(f"\n{B}选择 LLM 提供商{R}  {D}（选一个，填入你自己的 API Key）{R}\n")
    print(f"  {C}1{R}  {B}DeepSeek{R}   platform.deepseek.com")
    print(f"           注册即送余额，¥0.001/千 tokens，{B}最便宜{R}")
    print()
    print(f"  {C}2{R}  {B}Kimi{R}       platform.moonshot.cn")
    print(f"           月之暗面，注册有免费额度，国内访问稳定")
    print()
    print(f"  {C}3{R}  {B}OpenAI{R}     platform.openai.com")
    print(f"           GPT-4o-mini，按量付费，效果最强")
    print()
    print(f"  {C}4{R}  {B}Ollama{R}     ollama.com")
    print(f"           本地运行，{B}完全免费{R}，无需 API Key，注重隐私")
    print()
    print(f"  {C}5{R}  稍后手动配置")
    print()

    choice = ask("选择 [1-5]:")
    _configure_llm(choice, rc_file)

    # 3. 写入 shell 插件
    _install_shell_plugin(shell, rc_file)

    # 4. 完成
    print(f"\n{G}{B}✓ 初始化完成{R}\n")
    print(f"  {D}执行以下命令立即生效：{R}")
    print(f"  source {rc_file}\n")
    print(f"  然后在空白行输入 {B}:{R} 即可使用\n")


def run_config():
    """修改已有配置"""
    print(f"\n{B}ex 配置{R}\n")
    shell, rc_file = detect_shell()

    print(f"  {C}1{R}  更换 LLM 提供商")
    print(f"  {C}2{R}  修改执行模式（当前：{os.environ.get('EX_MODE','confirm')}）")
    print(f"  {C}3{R}  重新安装 Shell 插件")
    print(f"  {C}4{R}  卸载 ex")

    choice = ask("选择 [1-4]:")

    if choice == "1":
        _configure_llm(ask("LLM [1=DeepSeek 2=Kimi 3=OpenAI 4=Ollama]:"), rc_file)
        ok("LLM 配置已更新")
    elif choice == "2":
        mode = ask("执行模式 [confirm/auto/dry]:")
        if mode in ("confirm", "auto", "dry"):
            _set_env_in_rc("EX_MODE", mode, rc_file)
            ok(f"执行模式已设为 {mode}")
    elif choice == "3":
        _install_shell_plugin(shell, rc_file)
    elif choice == "4":
        _uninstall(rc_file)


def _configure_llm(choice: str, rc_file: Path):
    llm_map = {
        "1": ("DEEPSEEK_API_KEY",  "DeepSeek", "https://platform.deepseek.com/api_keys"),
        "2": ("MOONSHOT_API_KEY",  "Kimi",      "https://platform.moonshot.cn/console/api-keys"),
        "3": ("OPENAI_API_KEY",    "OpenAI",    "https://platform.openai.com/api-keys"),
    }
    if choice in llm_map:
        env_var, name, url = llm_map[choice]
        print(f"\n  {G}→{R} 在浏览器中打开：{B}{url}{R}")
        print(f"    注册/登录后创建 API Key，然后粘贴到这里\n")
        key = ask(f"粘贴你的 {name} API Key:")
        if key:
            _set_env_in_rc(env_var, key, rc_file)
            ok(f"{name} API Key 已保存")
        else:
            warn("未填写，跳过。之后运行 vex --config 配置。")
    elif choice == "4":
        print(f"\n  {B}安装 Ollama（本地免费运行）：{R}")
        print(f"  curl -fsSL https://ollama.com/install.sh | sh")
        print(f"  ollama run qwen2.5-coder:7b    {D}# 拉取推荐模型{R}\n")
        if shutil.which("ollama"):
            ok("ollama 已安装")
            r = subprocess.run(["ollama", "list"], capture_output=True, text=True)
            if "qwen2.5-coder" not in r.stdout:
                info("正在拉取推荐模型（约 5GB）...")
                subprocess.run(["ollama", "pull", "qwen2.5-coder:7b"])
        else:
            warn("请按上方步骤安装 ollama 后重新运行 vex --setup")


def _install_shell_plugin(shell: str, rc_file: Path):
    """将 source 命令写入 rc 文件"""
    plugin_path = get_plugin_path()

    # 检查是否已安装
    if rc_file.exists() and "ex-cli" in rc_file.read_text():
        ok(f"Shell 插件已在 {rc_file} 中")
        return

    source_line = f'source "{plugin_path}"'
    with rc_file.open("a") as f:
        f.write(f"\n# vex-cli: 自然语言 CLI（输入 : 触发）\n")
        f.write(f"{source_line}\n")

    ok(f"Shell 插件已写入 {rc_file}")


def _set_env_in_rc(var: str, val: str, rc_file: Path):
    """在 rc 文件中设置环境变量"""
    content = rc_file.read_text() if rc_file.exists() else ""
    line    = f'export {var}="{val}"'

    if f"export {var}=" in content:
        # 替换已有行
        lines = content.splitlines()
        lines = [line if l.startswith(f"export {var}=") else l for l in lines]
        rc_file.write_text("\n".join(lines) + "\n")
    else:
        with rc_file.open("a") as f:
            f.write(f"\n{line}\n")

    # 立即生效（当前进程）
    os.environ[var] = val


def _uninstall(rc_file: Path):
    if not rc_file.exists():
        return
    content = rc_file.read_text()
    lines   = [l for l in content.splitlines()
               if "ex-cli" not in l and "ex.zsh" not in l and "ex.bash" not in l]
    rc_file.write_text("\n".join(lines) + "\n")
    ok(f"已从 {rc_file} 移除 vex 配置")
    info("运行 pipx uninstall ex-cli 完成卸载")
