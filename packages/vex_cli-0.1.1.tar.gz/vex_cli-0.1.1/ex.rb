class ExCli < Formula
  include Language::Python::Virtualenv

  desc     "Natural language CLI — type : and speak your intent"
  homepage "https://github.com/yourusername/ex"
  url      "https://files.pythonhosted.org/packages/.../ex-cli-0.1.0.tar.gz"
  sha256   "FILL_IN_AFTER_PYPI_PUBLISH"
  license  "MIT"

  depends_on "python@3.11"

  def install
    virtualenv_install_with_resources
  end

  def post_install
    ohai "ex 已安装！运行以下命令完成初始化："
    ohai "  ex --setup"
  end

  test do
    system "#{bin}/ex", "--version"
  end
end

# ══════════════════════════════════════════════════════
# 发布到 Homebrew 的步骤：
#
# 1. 先发布到 PyPI，获得 tar.gz 的 sha256
#    pip download ex-cli --no-deps
#    shasum -a 256 ex-cli-*.tar.gz
#
# 2. 更新上方的 url 和 sha256
#
# 3. 创建自己的 tap（一次性操作）：
#    brew tap-new yourusername/homebrew-tap
#    cp ex.rb ~/.homebrew/Library/Taps/yourusername/homebrew-tap/Formula/
#    cd ~/.homebrew/Library/Taps/yourusername/homebrew-tap
#    git add . && git commit -m "Add ex formula" && git push
#
# 4. 用户安装：
#    brew tap yourusername/tap
#    brew install ex
# ══════════════════════════════════════════════════════
