"""
VaultLayer job_runs logger — records every execution to Supabase.

Every GPU instance provisioned through VaultLayer (smoke test, real job,
warm pool) gets one row in job_runs. This is the authoritative source for:
  - Admin dashboard: all jobs, all providers, all statuses
  - User billing dashboard: account_id filtered view
  - FinOps: provider cost breakdown
  - Compliance: audit trail for every cloud spend event

Flow:
  provision_*() returns instance_id  → open_run()   → INSERT row (status=provisioning)
  instance becomes usable             → update_run() → status=running, started_at
  job finishes                        → update_run() → status=completed/failed
  _hard_fence_and_confirm() returns   → close_run()  → status=terminated, billing fields
  _hard_fence fails                   → mark_termination_failed() → status=termination_failed

IMPORTANT: All functions are non-fatal. A DB failure must never abort provisioning
or termination. Log the error and return None.
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timezone
from typing import Optional, Any

logger = logging.getLogger(__name__)

# VaultLayer margin — must match spend.py
VL_MARGIN_PCT = float(os.environ.get("VL_MARGIN_PCT", "0.40"))
CREDITS_PER_USD = 100


def _get_db():
    """Return Supabase client or None if not configured."""
    try:
        from api.db import get_db
        return get_db()
    except Exception:
        return None


def _db_call(fn, label: str):
    """Execute with retry if available, otherwise direct."""
    try:
        from api.db import _db_call as _retry
        return _retry(fn, label=label)
    except ImportError:
        return fn()


def open_run(
    *,
    job_id: str,
    provider: str,
    gpu_type: str,
    instance_id: str,
    provisioned_at: datetime,
    rate_per_hr: float,
    run_type: str = "real",          # 'real' | 'smoke_test' | 'warm_pool'
    account_id: str = "",
    job_name: str = "",
    command: str = "",
    docker_image: str = "",
    model_params_billion: Optional[float] = None,
    training_mode: Optional[str] = None,
    dataset_size_gb: Optional[float] = None,
    gpu_count: int = 1,
    region: str = "",
    job_triggered_at: Optional[datetime] = None,  # when user ran vaultlayer run
    spend_ledger_id: Optional[str] = None,
    migrated_from_run_id: Optional[str] = None,
    metadata: Optional[dict] = None,
    initial_status: str = "provisioning",
    queue_state: Optional[dict] = None,
) -> Optional[str]:
    """
    Insert a job_runs row when an instance is successfully provisioned.
    Returns the run_id UUID, or None if Supabase is not configured / insert fails.

    Call immediately after provision_*() returns a non-None instance_id.
    """
    db = _get_db()
    if db is None:
        logger.debug("[job_runs] Supabase not configured — run not stored")
        return None

    _meta = dict(metadata or {})
    if job_triggered_at:
        _meta["job_triggered_at"] = job_triggered_at.isoformat()

    row: dict[str, Any] = {
        "job_id":          job_id,
        "account_id":      account_id or None,
        "run_type":        run_type,
        "provider":        provider,
        "gpu_type":        gpu_type,
        "instance_id":     instance_id,
        "provisioned_at":  provisioned_at.isoformat(),
        "rate_per_hr":     rate_per_hr,
        "status":          initial_status or "provisioning",
        "termination_confirmed": False,
        "metadata":        _meta,
    }
    if queue_state is not None:
        row["queue_state"] = queue_state
    if job_name:
        row["job_name"] = job_name
    if command:
        row["command"] = command
    if docker_image:
        row["docker_image"] = docker_image
    if model_params_billion is not None:
        row["model_params_billion"] = model_params_billion
    if training_mode:
        row["training_mode"] = training_mode
    if dataset_size_gb is not None:
        row["dataset_size_gb"] = dataset_size_gb
    if gpu_count != 1:
        row["gpu_count"] = gpu_count
    if region:
        row["region"] = region
    if spend_ledger_id:
        row["spend_ledger_id"] = spend_ledger_id
    if migrated_from_run_id:
        row["migrated_from_run_id"] = migrated_from_run_id

    try:
        res = _db_call(
            lambda: db.table("job_runs").insert(row).execute(),
            label="job_runs:open_run",
        )
        if res.data:
            run_id = res.data[0]["run_id"]
            logger.info(
                f"[job_runs] OPEN  run_id={run_id}  job_id={job_id}  "
                f"provider={provider}  gpu={gpu_type}  instance={instance_id}  "
                f"run_type={run_type}  account={account_id or 'anon'}"
            )
            return run_id
    except Exception as e:
        logger.warning(f"[job_runs] open_run failed (non-fatal): {e}")

    return None


def update_run(run_id: str, **fields) -> None:
    """
    Update arbitrary fields on a job_runs row.
    Use for status transitions (provisioning → running) and mid-run metadata.

    Common calls:
      update_run(run_id, status="running", started_at=datetime.now(utc))
      update_run(run_id, status="completed", completed_at=datetime.now(utc))
      update_run(run_id, status="failed", failed_at=datetime.now(utc), failure_reason="OOM")
    """
    if not run_id or not fields:
        return

    db = _get_db()
    if db is None:
        return

    # Serialize datetime objects to ISO strings
    serialized: dict[str, Any] = {}
    for k, v in fields.items():
        if isinstance(v, datetime):
            serialized[k] = v.isoformat()
        else:
            serialized[k] = v

    try:
        _db_call(
            lambda: db.table("job_runs").update(serialized).eq("run_id", run_id).execute(),
            label="job_runs:update_run",
        )
        logger.debug(f"[job_runs] UPDATE run_id={run_id} fields={list(fields.keys())}")
    except Exception as e:
        logger.warning(f"[job_runs] update_run failed (non-fatal): {e}")


def close_run(
    run_id: str,
    *,
    terminated_at: datetime,
    billing_seconds: float,
    rate_per_hr: float,
    estimated_cost_usd: float,
    user_charged_usd: float,
    credits_charged: float,  # NUMERIC(12,4) after migration 0019
    provider_billed_usd: Optional[float] = None,
    run_duration_seconds: Optional[float] = None,  # triggered → terminated
    status: str = "terminated",
    provider: str = "",
    failure_reason: Optional[str] = None,
    termination_confirmed: bool = False,
) -> None:
    """
    Finalize a job_runs row after the termination attempt completes.
    Sets billing fields and status. Sets termination_confirmed only if
    the caller confirms the fence actually succeeded — otherwise the
    row keeps termination_confirmed=False so zombie-instance sweeps
    can find leaked resources later.

    status must be one of the values allowed by the job_runs CHECK constraint:
      'provisioning' | 'running' | 'completed' | 'failed' | 'terminated' | 'termination_failed'.
    Use failure_reason to preserve semantic info like 'migrated' or 'stuck_requeue'
    (the caller in job_worker._settle_in_db maps non-canonical statuses before calling).

    Call immediately after _hard_fence_and_confirm() returns.
    """
    if not run_id:
        return

    db = _get_db()
    if db is None:
        return

    updates: dict[str, Any] = {
        "terminated_at":         terminated_at.isoformat(),
        "billing_seconds":       round(billing_seconds, 1),
        "estimated_cost_usd":    estimated_cost_usd,
        "user_charged_usd":      user_charged_usd,
        "credits_charged":       credits_charged,
        "status":                status,
        "termination_confirmed": termination_confirmed,
    }
    if provider_billed_usd is not None:
        updates["provider_billed_usd"] = provider_billed_usd
    if run_duration_seconds is not None:
        updates["run_duration_seconds"] = round(run_duration_seconds, 1)
    if failure_reason:
        updates["failure_reason"] = failure_reason

    try:
        _db_call(
            lambda: db.table("job_runs").update(updates).eq("run_id", run_id).execute(),
            label="job_runs:close_run",
        )
        logger.info(
            f"[job_runs] CLOSED run_id={run_id}  {billing_seconds:.0f}s  "
            f"@ ${rate_per_hr}/hr = ${estimated_cost_usd:.4f} provider  "
            f"user_charged=${user_charged_usd:.4f} ({credits_charged:.4f} credits)"
        )
    except Exception as e:
        logger.warning(f"[job_runs] close_run failed (non-fatal): {e}")

    # Bill audit — non-fatal, runs after DB write
    try:
        from shared.bill_auditor import audit_bill
        audit_bill(
            run_id=run_id,
            provider=provider or "unknown",
            billing_seconds=int(billing_seconds),
            rate_per_hr=rate_per_hr,
            estimated_cost_usd=estimated_cost_usd,
            provider_billed_usd=provider_billed_usd,
        )
    except Exception:
        pass

    # GPU-hour usage tracking — persist monthly summary to Redis + R2 (Issue #30)
    try:
        _account = updates.get("account_id") or ""
        if _account:
            from shared.usage_tracker import record_job_end
            record_job_end(
                user_id=_account,
                billing_seconds=float(billing_seconds),
                rate_per_hr=rate_per_hr,
                estimated_cost_usd=estimated_cost_usd,
            )
    except Exception:
        pass


def mark_termination_failed(run_id: str, error: str = "") -> None:
    """
    Mark a job_runs row when termination was NOT confirmed.
    The instance may still be running and accumulating cost.
    Triggers manual review via admin dashboard (status=termination_failed).
    """
    if not run_id:
        return

    db = _get_db()
    if db is None:
        return

    try:
        _db_call(
            lambda: db.table("job_runs").update({
                "status":                "termination_failed",
                "termination_confirmed": False,
                "failure_reason":        error[:500] if error else "",
            }).eq("run_id", run_id).execute(),
            label="job_runs:mark_termination_failed",
        )
        logger.error(
            f"[job_runs] TERMINATION FAILED run_id={run_id}: {error}. "
            f"Instance may still be running — manual check required."
        )
    except Exception as e:
        logger.warning(f"[job_runs] mark_termination_failed itself failed: {e}")


def record_provision(
    *,
    job_id: str,
    provider: str,
    gpu_type: str,
    instance_id: str,
    provisioned_at: datetime,
    rate_per_hr: float,
    account_id: str,
    job_name: str = "",
    run_type: str = "real",
    region: str = "",
    existing_run_id: Optional[str] = None,
    spend_ledger_id: Optional[str] = None,
    docker_image: str = "",
    metadata: Optional[dict] = None,
) -> Optional[str]:
    """Open or update the job_runs row immediately after a successful provision.

    This is the ONE place the "provision succeeded → DB row exists" invariant
    is enforced. Every code path that creates a real cloud instance (API
    ingress, worker recovery, smoke tests, CLI) must call this helper so we
    never leak an instance without an audit row.

    If `existing_run_id` is given (set at API submit time with status=provisioning
    and instance_id=pending), we UPDATE it to status=running with the real
    instance_id. Otherwise we INSERT a new row and return the generated run_id.

    Returns the run_id on success, or None if Supabase is unavailable (non-fatal).
    """
    if existing_run_id:
        updates: dict[str, Any] = {
            "status": "running",
            "provider": provider,
            "gpu_type": gpu_type,
            "instance_id": instance_id,
            "provisioned_at": provisioned_at,
            "rate_per_hr": rate_per_hr,
            "spend_ledger_id": spend_ledger_id,
        }
        if metadata is not None:
            updates["metadata"] = metadata
        update_run(
            existing_run_id,
            **updates,
        )
        return existing_run_id

    run_id = open_run(
        job_id=job_id,
        provider=provider,
        gpu_type=gpu_type,
        instance_id=instance_id,
        provisioned_at=provisioned_at,
        rate_per_hr=rate_per_hr,
        run_type=run_type,
        account_id=account_id,
        job_name=job_name or f"job-{job_id[:8]}",
        region=region,
        spend_ledger_id=spend_ledger_id,
        docker_image=docker_image,
        metadata=metadata,
    )
    if run_id:
        # Transition provisioning → running in the same helper call so the
        # dashboard never shows the brief "provisioning" state for instances
        # that are already up and heartbeating.
        update_run(run_id, status="running")
    return run_id


def record_termination(
    *,
    run_id: Optional[str],
    provider: str,
    provisioned_at: datetime,
    terminated_at: datetime,
    rate_per_hr: float,
    status: str = "terminated",
    termination_confirmed: bool = True,
    fallback_reason: Optional[str] = None,
    provider_billed_usd: Optional[float] = None,
    failure_reason: Optional[str] = None,
    settled: Optional[dict] = None,
) -> None:
    """Close the job_runs row after hard_fence succeeds. Mirror of record_provision.

    If `settled` is provided (from shared.spend.settle_instance), we use its
    canonical billing numbers so spend_ledger and job_runs never drift.
    Otherwise we compute from the timestamps + rate_per_hr, applying 0%
    markup when fallback_reason is set (OD fallback — user pays raw cost)
    and VL_MARGIN_PCT otherwise.
    """
    if not run_id:
        return

    if settled is not None:
        billing_seconds = settled["billing_seconds"]
        rate            = settled["rate_per_hr"]
        estimated_cost  = settled["estimated_cost_usd"]
        user_charged    = settled["user_charged_usd"]
        credits_charged = settled["credits_charged"]
    else:
        # No settle_ledger row — compute from scratch. OD fallback legs pay
        # raw provider cost (no gainshare) per the product SLA guarantee.
        margin = 0.0 if fallback_reason else VL_MARGIN_PCT
        billing_seconds, estimated_cost, user_charged, credits_charged = compute_billing(
            provisioned_at, terminated_at, rate_per_hr, vl_margin_pct=margin,
        )
        rate = rate_per_hr

    close_run(
        run_id=run_id,
        terminated_at=terminated_at,
        billing_seconds=billing_seconds,
        rate_per_hr=rate,
        estimated_cost_usd=estimated_cost,
        user_charged_usd=user_charged,
        credits_charged=credits_charged,
        provider_billed_usd=provider_billed_usd,
        status=status,
        provider=provider,
        failure_reason=failure_reason,
        termination_confirmed=termination_confirmed,
    )


def compute_billing(
    provisioned_at: datetime,
    terminated_at: datetime,
    rate_per_hr: float,
    vl_margin_pct: float = VL_MARGIN_PCT,
) -> tuple[float, float, float, float]:
    """
    Helper: compute billing figures from timestamps + rate.
    Returns (billing_seconds, estimated_cost_usd, user_charged_usd, credits_charged).
    credits_charged is a float with 4 decimal places (NUMERIC(12,4) column).
    """
    if not provisioned_at.tzinfo:
        provisioned_at = provisioned_at.replace(tzinfo=timezone.utc)
    if not terminated_at.tzinfo:
        terminated_at = terminated_at.replace(tzinfo=timezone.utc)

    billing_seconds = max(0.0, (terminated_at - provisioned_at).total_seconds())
    estimated_cost_usd = round((billing_seconds / 3600.0) * rate_per_hr, 6)
    user_charged_usd = round(estimated_cost_usd * (1.0 + vl_margin_pct), 4)
    credits_charged = round(user_charged_usd * CREDITS_PER_USD, 4)
    return billing_seconds, estimated_cost_usd, user_charged_usd, credits_charged
