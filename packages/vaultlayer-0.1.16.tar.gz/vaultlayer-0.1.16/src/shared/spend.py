"""
VaultLayer spend tracker — records every instance lifecycle to Supabase.

Every GPU instance that VaultLayer provisions gets one row in spend_ledger.
This is the source of truth for:
  - Provider costs (what VaultLayer pays)
  - User charges (provider cost + VL margin)
  - Billing reconciliation
  - Real-time spend dashboard

Flow:
  provision_*() succeeds   → record_provision()  → INSERT open row
  _hard_fence_*() succeeds → settle_instance()   → UPDATE row + write credit_events

IMPORTANT: These functions are non-fatal — a logging failure must never
abort a provision or termination. Log the error and continue.
"""
from __future__ import annotations

import logging
import math
import os
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

# VaultLayer margin on top of provider cost (default 40%)
VL_MARGIN_PCT = float(os.environ.get("VL_MARGIN_PCT", "0.40"))

# 1 credit = $0.01
CREDITS_PER_USD = 100


def _get_db():
    """Return Supabase client or None if not configured."""
    try:
        from api.db import get_db
        return get_db()
    except Exception:
        return None


def _db_call(fn, label: str):
    """Execute with retry if available, direct otherwise."""
    try:
        from api.db import _db_call as _retry
        return _retry(fn, label=label)
    except ImportError:
        return fn()


def record_provision(
    job_id: str,
    provider: str,
    gpu_type: str,
    instance_id: str,
    provisioned_at: datetime,
    rate_per_hr: float,
    user_id: str = "",
    is_test: bool = False,
    metadata: Optional[dict] = None,
    vl_margin_pct: Optional[float] = None,
) -> Optional[str]:
    """
    Insert an open spend_ledger row when an instance is successfully provisioned.
    Returns the spend_ledger UUID (spend_id) to pass to settle_instance() later.

    Must be called immediately after provision_*() returns a non-None instance_id.
    provisioned_at should be captured just before the provision call returns
    (this is the start of the provider billing window).
    """
    db = _get_db()
    if db is None:
        logger.debug("[spend] Supabase not configured — provision event not stored")
        return None

    row = {
        "job_id":          job_id,
        "user_id":         user_id or None,
        "is_test":         is_test,
        "provider":        provider,
        "gpu_type":        gpu_type,
        "instance_id":     instance_id,
        "provisioned_at":  provisioned_at.isoformat(),
        "rate_per_hr":     rate_per_hr,
        "termination_confirmed": False,
        "settled":         False,
        "metadata":        metadata or {},
    }
    if vl_margin_pct is not None:
        row["vl_margin_pct"] = vl_margin_pct

    try:
        res = _db_call(
            lambda: db.table("spend_ledger").insert(row).execute(),
            label="spend:record_provision",
        )
        if res.data:
            spend_id = res.data[0]["id"]
            logger.info(
                f"[spend] OPEN  {provider} {gpu_type} instance={instance_id} "
                f"@ ${rate_per_hr}/hr  job={job_id}  is_test={is_test}  "
                f"spend_id={spend_id}"
            )
            return spend_id
    except Exception as e:
        logger.warning(f"[spend] record_provision failed (non-fatal, billing not lost): {e}")

    return None


def settle_instance(
    spend_id: str,
    terminated_at: datetime,
    provider_billed_usd: Optional[float] = None,
    egress_cost_usd: float = 0.0,
    termination_confirmed: bool = False,
) -> Optional[dict]:
    """
    Close a spend_ledger row when an instance is confirmed terminated.
    Calculates actual billing, updates the row, and deducts user credits.

    Returns a dict of the computed values (so callers can mirror the exact
    numbers onto job_runs without re-deriving them) or None on failure:

        {
            "user_charged_usd":   float,
            "billing_seconds":    float,
            "estimated_cost_usd": float,
            "credits_charged":    float,  # NUMERIC(12,4) — 4 dp, was int
            "vl_margin_pct":      float,   # tier markup actually applied
            "rate_per_hr":        float,
        }

    Previously this returned a bare float (user_charged_usd), which forced
    _close_run and similar callers to recompute billing locally with a
    hardcoded 20% markup — that's why a Failover (40%) or Scarcity (30%)
    job showed different user_charged_usd values in spend_ledger vs
    job_runs. Returning the dict makes spend_ledger the single source of
    truth for billing; every other row mirrors it.

    Must be called after _hard_fence_*() completes. terminated_at should
    be captured just after the fence call returns. provider_billed_usd is
    the actual amount from the provider's billing API (RunPod, Hyperstack,
    Vast.ai — others estimate). egress_cost_usd is a one-time data
    transfer cost from emergency migration.

    termination_confirmed defaults to False — callers must explicitly set
    it True only when the fence returned without raising. Hardcoding True
    previously masked a fence-signature bug that let AWS/GCP/Azure
    instances keep running (and billing) after a job was "completed".
    """
    db = _get_db()
    if db is None:
        return None

    try:
        # Fetch the open row
        res = _db_call(
            lambda: db.table("spend_ledger").select("*").eq("id", spend_id).execute(),
            label="spend:settle_fetch",
        )
        if not res.data:
            logger.warning(f"[spend] settle_instance: spend_id {spend_id} not found")
            return None

        row = res.data[0]

        # Parse provisioned_at — robust handling of all Supabase timestamp formats
        prov_str = row["provisioned_at"]
        for _tz_suffix in ("+00:00", "+00", "Z"):
            prov_str = prov_str.replace(_tz_suffix, "")
        # Truncate microseconds to 6 digits (Supabase sometimes sends 5)
        if "." in prov_str:
            base, frac = prov_str.rsplit(".", 1)
            prov_str = f"{base}.{frac[:6]}"
        try:
            provisioned_at = datetime.fromisoformat(prov_str).replace(tzinfo=timezone.utc)
        except ValueError:
            # Last resort: strip everything after T and seconds
            provisioned_at = datetime.strptime(prov_str[:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc)
        if not terminated_at.tzinfo:
            terminated_at = terminated_at.replace(tzinfo=timezone.utc)

        billing_seconds = max(0.0, (terminated_at - provisioned_at).total_seconds())
        rate_per_hr = float(row.get("rate_per_hr") or 0.0)
        estimated_cost_usd = round((billing_seconds / 3600.0) * rate_per_hr, 6)

        # User is charged provider cost + markup.
        # For cost_plus users: use their per-account compute_markup_pct.
        # For gainshare users (or fallback): use the global VL_MARGIN_PCT.
        margin = float(row.get("vl_margin_pct") or VL_MARGIN_PCT)
        user_id = row.get("user_id")
        if user_id:
            try:
                _db2 = _get_db()
                if _db2:
                    _ur = _db_call(
                        lambda: _db2.table("users")
                            .select("billing_model, compute_markup_pct")
                            .eq("user_id", user_id)
                            .execute(),
                        label="spend:fetch_user_billing",
                    )
                    if _ur.data and _ur.data[0].get("billing_model") == "cost_plus":
                        margin = float(_ur.data[0].get("compute_markup_pct") or margin)
            except Exception:
                pass  # non-fatal, fall through to global margin
        # Cost basis: prefer the REAL provider bill over our estimate.
        # When _fetch_provider_billing returned a value (RunPod / Vast.ai /
        # Hyperstack / Crusoe / Voltage Park), we charge the user based on
        # that. When it returned None (provider has no per-instance API, or
        # charges haven't settled yet), we fall back to the estimate so the
        # invoice isn't blocked — a later backfill run (e.g.
        # scripts/reconcile_vast_charges.py) patches provider_billed_usd
        # and re-issues user_charged_usd via this same function.
        cost_basis = provider_billed_usd if provider_billed_usd is not None else estimated_cost_usd
        user_charged_usd = round(cost_basis * (1.0 + margin) + egress_cost_usd, 4)
        # Store credits with 4 decimal places so sub-cent jobs (e.g. a
        # $0.0014 Vast.ai run = 0.14 credits) don't round to zero in
        # spend_ledger. Schema migration 0019 widened the column to
        # NUMERIC(12,4). credit_events.amount_credits is still INT, so
        # the actual balance debit ceils to the next whole credit
        # (see usage below).
        credits_charged = round(user_charged_usd * CREDITS_PER_USD, 4)

        updates: dict = {
            "terminated_at":         terminated_at.isoformat(),
            "billing_seconds":       round(billing_seconds, 1),
            "estimated_cost_usd":    estimated_cost_usd,
            "user_charged_usd":      user_charged_usd,
            "credits_charged":       credits_charged,
            "termination_confirmed": termination_confirmed,
            "settled":               True,
        }
        if provider_billed_usd is not None:
            updates["provider_billed_usd"] = provider_billed_usd
        if egress_cost_usd > 0:
            updates["egress_cost_usd"] = round(egress_cost_usd, 4)

        # Atomic conditional UPDATE: only succeeds if settled=False.
        # This acts as a CAS — exactly one concurrent caller wins and becomes
        # responsible for inserting the credit_event. Losers (0 rows returned)
        # fall into the partial-failure recovery path below.
        _idempotency_key = f"settle:{spend_id}"
        _settle_res = _db_call(
            lambda: db.table("spend_ledger")
                .update(updates)
                .eq("id", spend_id)
                .eq("settled", False)
                .execute(),
            label="spend:settle_update",
        )
        _won_settle = bool(_settle_res and _settle_res.data)

        if not _won_settle:
            # Another caller settled first (or this is a retry after partial failure).
            # Re-fetch the committed billing values so we return accurate numbers.
            _refetch = _db_call(
                lambda: db.table("spend_ledger").select("*").eq("id", spend_id).execute(),
                label="spend:settle_refetch",
            )
            _committed = _refetch.data[0] if _refetch and _refetch.data else {}
            user_charged_usd  = float(_committed.get("user_charged_usd")  or user_charged_usd)
            credits_charged   = float(_committed.get("credits_charged")    or credits_charged)
            billing_seconds   = float(_committed.get("billing_seconds")    or billing_seconds)
            estimated_cost_usd = float(_committed.get("estimated_cost_usd") or estimated_cost_usd)

        # Deduct credits for real (non-test) jobs with a known user.
        # We use stripe_payment_id=_idempotency_key as a per-settle guard so we
        # can check for an existing event in both the winner and recovery paths.
        # credit_events.amount_credits is INT: round UP fractional credits (see docstring).
        user_id = row.get("user_id")
        if user_id and not row.get("is_test"):
            try:
                from api.db import add_credit_event
                # Partial-failure recovery: check whether a settle credit_event was
                # already inserted for this spend_id (e.g. ledger updated but DB
                # returned error on event insert, then caller retried).
                _existing = _db_call(
                    lambda: db.table("credit_events")
                        .select("id")
                        .eq("stripe_payment_id", _idempotency_key)
                        .limit(1)
                        .execute(),
                    label="spend:settle_event_check",
                )
                if _existing and _existing.data:
                    logger.info(
                        f"[spend] settle_instance: credit_event already exists for "
                        f"spend_id={spend_id} — skipping duplicate deduction"
                    )
                else:
                    # #149 P1-fix: Reconcile against ALL prior charges for this job (all legs).
                    # For multi-leg migrations each leg is a separate spend_ledger row.
                    # Without cumulative accounting, a prior leg's settle event (keyed
                    # "settle:{prior_spend_id}") inflates _prior_burned and can make the
                    # current leg appear fully paid -- zero-charging for real compute.
                    #
                    # Fix: cumulative_due = this leg + all prior settled legs for same job.
                    _this_leg_due = math.ceil(credits_charged) if credits_charged > 0 else 0
                    _cumulative_due = _this_leg_due
                    try:
                        # Prior settled legs for the same job. neq(id, spend_id) excludes
                        # the current leg which may already be marked settled=True by CAS.
                        _prior_legs_res = _db_call(
                            lambda: db.table("spend_ledger")
                                .select("credits_charged")
                                .eq("job_id", row.get("job_id"))
                                .eq("settled", True)
                                .neq("id", spend_id)
                                .execute(),
                            label="spend:prior_settled_legs",
                        )
                        _cumulative_due += sum(
                            math.ceil(float(r.get("credits_charged") or 0))
                            for r in (_prior_legs_res.data or [])
                        )
                    except Exception as _pl_err:
                        logger.warning(
                            f"[spend] prior legs query failed (non-fatal, "
                            f"using single-leg total): {_pl_err}"
                        )

                    _prior_burned = 0
                    try:
                        # ALL burned events for this job across all legs.
                        # Excludes only the current settle event by its idempotency key.
                        _burns_res = _db_call(
                            lambda: db.table("credit_events")
                                .select("amount_credits, stripe_payment_id")
                                .eq("job_id", row.get("job_id"))
                                .eq("event_type", "burned")
                                .execute(),
                            label="spend:prior_burns_query",
                        )
                        if _burns_res and _burns_res.data:
                            _prior_burned = abs(sum(
                                int(e.get("amount_credits") or 0)
                                for e in _burns_res.data
                                if e.get("stripe_payment_id") != _idempotency_key
                            ))
                    except Exception as _br_err:
                        logger.warning(f"[spend] prior burns query failed (non-fatal): {_br_err}")

                    _residual = max(0, _cumulative_due - _prior_burned)
                    if _residual > 0:
                        try:
                            add_credit_event(
                                user_id=user_id,
                                event_type="burned",
                                amount_credits=-_residual,
                                job_id=row.get("job_id"),
                                stripe_payment_id=_idempotency_key,
                                description=(
                                    f"{row['provider']} {row.get('gpu_type', '')} "
                                    f"{billing_seconds / 3600:.4f}h "
                                    f"@ ${rate_per_hr}/hr = ${estimated_cost_usd:.4f} provider cost"
                                    + (f" (cumulative {_cumulative_due}cr due, "
                                       f"{_prior_burned}cr already burned)"
                                       if _prior_burned else "")
                                ),
                            )
                        except Exception as _ce_err:
                            # Unique constraint violation = concurrent caller already inserted.
                            _err_str = str(_ce_err).lower()
                            if "unique" in _err_str or "duplicate" in _err_str:
                                logger.info(
                                    f"[spend] settle credit event for {spend_id} already exists "
                                    f"(unique constraint -- concurrent settle); skipping"
                                )
                            else:
                                raise
                    else:
                        logger.info(
                            f"[spend] settle_instance: all prior charges cover "
                            f"cumulative {_cumulative_due}cr ({_prior_burned}cr burned) "
                            f"for spend_id={spend_id} -- no additional deduction"
                        )
            except Exception as e:
                logger.warning(f"[spend] credit deduction failed for {user_id}: {e}")

        logger.info(
            f"[spend] CLOSED {spend_id}: {billing_seconds:.0f}s "
            f"@ ${rate_per_hr}/hr = ${estimated_cost_usd:.6f} provider cost  "
            f"user_charged=${user_charged_usd:.4f} ({credits_charged:.4f} credits)  "
            f"margin={margin * 100:.0f}%  "
            f"egress=${egress_cost_usd:.4f}  "
            f"provider_billed={f'${provider_billed_usd:.4f}' if provider_billed_usd is not None else 'N/A'}  "
            f"is_test={row.get('is_test')}"
        )
        return {
            "user_charged_usd":   user_charged_usd,
            "billing_seconds":    round(billing_seconds, 1),
            "estimated_cost_usd": estimated_cost_usd,
            "credits_charged":    credits_charged,
            "vl_margin_pct":      margin,
            "rate_per_hr":        rate_per_hr,
        }

    except Exception as e:
        logger.warning(f"[spend] settle_instance failed (non-fatal): {e}")

    return None


def mark_termination_failed(spend_id: str, error: str = "") -> None:
    """
    Mark a spend_ledger row when termination was NOT confirmed.
    The instance may still be running and billing. Triggers manual review.
    """
    db = _get_db()
    if db is None:
        return
    try:
        _db_call(
            lambda: db.table("spend_ledger").update({
                "termination_confirmed": False,
                "metadata": {"termination_error": error[:500]},
            }).eq("id", spend_id).execute(),
            label="spend:mark_failed",
        )
        logger.error(
            f"[spend] TERMINATION FAILED for spend_id={spend_id}: {error}. "
            f"Instance may still be running — manual check required."
        )
    except Exception as e:
        logger.warning(f"[spend] mark_termination_failed itself failed: {e}")
