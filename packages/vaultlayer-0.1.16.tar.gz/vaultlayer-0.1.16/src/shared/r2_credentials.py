"""
VaultLayer — Job-Scoped R2 Temporary Credentials

Generates short-lived, prefix-scoped Cloudflare R2 credentials for each job.
Master API keys NEVER leave VaultLayer's secure Broker infrastructure.
GPU nodes receive only a token that is cryptographically restricted to:

    checkpoints/{job_id}/

Any attempt by a compromised node to access checkpoints/{other_job_id}/ or list
the bucket root returns a 403 Forbidden from the Cloudflare R2 edge — no
VaultLayer code is involved in the rejection.

API Reference:
    POST /accounts/{account_id}/r2/temp-credentials
    https://developers.cloudflare.com/r2/api/s3/tokens/#create-temporary-credentials
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Optional

import requests

logger = logging.getLogger(__name__)

# Cloudflare R2 maximum TTL for temporary credentials
R2_MAX_TTL_SECONDS = 4 * 3600          # 4 hours (CF hard limit)
# Default TTL — request the CF maximum so long-running jobs don't 403 mid-training.
# (Previously 2h; raised to 4h after observing credential expiry on jobs > 2h.)
R2_DEFAULT_TTL_SECONDS = R2_MAX_TTL_SECONDS
# Proactive refresh margin: re-mint credentials this many seconds before expiry
R2_REFRESH_MARGIN_SECONDS = 15 * 60    # 15 minutes


@dataclass
class ScopedCredentials:
    """
    Short-lived R2 credentials scoped to a single job prefix.
    Compatible with the AWS S3 STS credential format so rclone / boto3 / AWS
    SDKs accept them without modification (just set session_token alongside
    the access_key_id and secret_access_key).
    """
    access_key_id: str
    secret_access_key: str
    session_token: str
    job_id: str
    prefix: str                   # primary checkpoint prefix, e.g. "checkpoints/abc123/"
    expires_at: float             # Unix timestamp (UTC)
    # All prefixes this credential covers (checkpoint + any read-only dataset prefixes).
    # Stored so refresh_if_needed can re-mint with the same scope.
    all_prefixes: list = field(default_factory=list)
    permission: str = "objectReadWrite"

    @property
    def is_expired(self) -> bool:
        return time.time() >= self.expires_at

    @property
    def needs_refresh(self) -> bool:
        """True when within R2_REFRESH_MARGIN_SECONDS of expiry."""
        return time.time() >= (self.expires_at - R2_REFRESH_MARGIN_SECONDS)

    def to_env_dict(self) -> dict[str, str]:
        """
        Return a dict suitable for injecting into a subprocess environment or
        a UserData script.  These are the canonical AWS STS env var names —
        rclone, boto3, and the AWS CLI all recognise them automatically.
        """
        return {
            "AWS_ACCESS_KEY_ID":     self.access_key_id,
            "AWS_SECRET_ACCESS_KEY": self.secret_access_key,
            "AWS_SESSION_TOKEN":     self.session_token,
            "VAULTLAYER_R2_PREFIX":  self.prefix,
            "VAULTLAYER_JOB_ID":     self.job_id,
        }

    def to_rclone_config(self, endpoint: str) -> str:
        """
        Produce an rclone `[r2]` stanza using scoped credentials + session_token.
        The session_token line is required — without it, Cloudflare R2 rejects
        STS-style credentials (it looks for the X-Amz-Security-Token header).
        """
        return (
            "[r2]\n"
            "type = s3\n"
            "provider = Cloudflare\n"
            f"access_key_id = {self.access_key_id}\n"
            f"secret_access_key = {self.secret_access_key}\n"
            f"session_token = {self.session_token}\n"
            f"endpoint = {endpoint}\n"
        )


def _scope_cache_key(job_id: str, all_prefixes: list, permission: str) -> tuple:
    """Deterministic cache key that includes the full requested scope."""
    return (job_id, tuple(sorted(all_prefixes)), permission)


class R2CredentialsMinter:
    """
    Calls the Cloudflare API to mint job-scoped temporary R2 credentials.

    Instantiated once per Broker Agent process.  Master credentials are held
    only here, in VaultLayer's secure infrastructure — they never appear in
    UserData scripts, environment variables on GPU nodes, or log files.

    Usage:
        minter = R2CredentialsMinter.from_config(config.cloudflare)
        creds = minter.mint(job_id="abc123")
        # Inject creds.to_rclone_config() into the GPU node UserData
    """

    CF_TEMP_CREDS_URL = (
        "https://api.cloudflare.com/client/v4/accounts/{account_id}/r2/temp-credentials"
    )

    def __init__(
        self,
        account_id: str,
        master_token: str,
        parent_access_key_id: str,
        bucket: str,
        r2_endpoint: str,
    ):
        self._account_id = account_id
        self._master_token = master_token
        self._parent_access_key_id = parent_access_key_id
        self._bucket = bucket
        self._r2_endpoint = r2_endpoint
        # Keyed by _scope_cache_key() — includes all_prefixes and permission so
        # different scopes for the same job never collide in the cache (P1 fix).
        self._cache: dict[tuple, ScopedCredentials] = {}

    @classmethod
    def from_config(cls, cf_config) -> "R2CredentialsMinter":
        """Construct from a CloudflareConfig dataclass."""
        return cls(
            account_id=cf_config.account_id,
            master_token=cf_config.cf_master_token,
            parent_access_key_id=cf_config.r2_access_key_id,
            bucket=cf_config.r2_bucket,
            r2_endpoint=cf_config.r2_endpoint,
        )

    def mint(
        self,
        job_id: str,
        ttl_seconds: int = R2_DEFAULT_TTL_SECONDS,
        permission: str = "objectReadWrite",
        extra_prefixes: Optional[list] = None,
    ) -> ScopedCredentials:
        """
        Mint short-lived R2 credentials scoped to checkpoints/{job_id}/ plus any
        server-verified extra_prefixes (e.g. datasets/{dataset_id}/ for warmup).

        Security model:
          - The checkpoint prefix checkpoints/{job_id}/ always uses `permission`
            (default objectReadWrite — nodes must be able to write checkpoints).
          - extra_prefixes should contain only server-side-verified paths. Never
            populate from user-supplied environment variables — callers are
            responsible for validating ownership before passing extra prefixes.
          - The cache key includes all_prefixes + permission, so different scopes
            for the same job are always independent cache entries.  A checkpoint-
            only token will never be returned when a dataset-scoped token was
            requested, and vice versa.

        Args:
            job_id:        VaultLayer job UUID — used as the checkpoint prefix.
            ttl_seconds:   Lifetime for the token (max 4h per Cloudflare limits).
            permission:    "objectReadWrite" (default) or "objectRead".
            extra_prefixes: Additional server-verified R2 prefixes to include,
                           e.g. ["datasets/my-dataset/"] for dataset warmup.
                           Caller MUST verify that the job owner has access to
                           each prefix before adding it here.

        Returns:
            ScopedCredentials — contains accessKeyId, secretAccessKey,
            sessionToken, and helpers for rclone config + env injection.

        Raises:
            RuntimeError: If the Cloudflare API returns an error response.
        """
        prefix = f"checkpoints/{job_id}/"
        all_prefixes = [prefix] + list(extra_prefixes or [])
        cache_key = _scope_cache_key(job_id, all_prefixes, permission)

        cached = self._cache.get(cache_key)
        if cached and not cached.needs_refresh:
            return cached

        ttl_seconds = min(ttl_seconds, R2_MAX_TTL_SECONDS)
        url = self.CF_TEMP_CREDS_URL.format(account_id=self._account_id)

        payload = {
            "bucket": self._bucket,
            "parent_access_key_id": self._parent_access_key_id,
            "permission": permission,
            "ttl_seconds": ttl_seconds,
            "prefixes": all_prefixes,       # ← cryptographic isolation
        }
        headers = {
            "Authorization": f"Bearer {self._master_token}",
            "Content-Type": "application/json",
        }

        logger.info(
            f"[R2Credentials] Minting scoped token for job={job_id} "
            f"prefixes={all_prefixes!r} permission={permission} ttl={ttl_seconds}s"
        )

        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=10)
            resp.raise_for_status()
        except requests.RequestException as e:
            raise RuntimeError(
                f"Cloudflare R2 temp-credentials API error for job {job_id}: {e}"
            ) from e

        body = resp.json()
        if not body.get("success"):
            errors = body.get("errors", [])
            raise RuntimeError(
                f"Cloudflare R2 temp-credentials API returned errors for job {job_id}: {errors}"
            )

        result = body["result"]
        creds = ScopedCredentials(
            access_key_id=result["accessKeyId"],
            secret_access_key=result["secretAccessKey"],
            session_token=result["sessionToken"],
            job_id=job_id,
            prefix=prefix,
            expires_at=time.time() + ttl_seconds,
            all_prefixes=all_prefixes,
            permission=permission,
        )
        self._cache[cache_key] = creds
        logger.info(
            f"[R2Credentials] Token minted for job={job_id} "
            f"expires_in={ttl_seconds//60}m  access_key={creds.access_key_id[:8]}..."
        )
        return creds

    def revoke_cached(self, job_id: str) -> None:
        """
        Remove all cached credentials for a job (called on job termination).
        The Cloudflare token itself expires at TTL — this just prevents reuse
        within the Broker process after the job ends.
        """
        keys_to_delete = [k for k in self._cache if k[0] == job_id]
        for k in keys_to_delete:
            del self._cache[k]
        if keys_to_delete:
            logger.info(
                f"[R2Credentials] Cleared {len(keys_to_delete)} cached token(s) for job={job_id}"
            )

    def refresh_if_needed(self, job_id: str) -> Optional[ScopedCredentials]:
        """
        Proactively refresh any cached credentials for a job that are within the
        refresh window.  Preserves the original scope (prefixes + permission) so
        long-running dataset jobs don't lose dataset access after refresh.
        Called by the Broker's heartbeat loop.
        """
        refreshed = None
        for cache_key, cached in list(self._cache.items()):
            if cache_key[0] == job_id and cached.needs_refresh:
                logger.info(
                    f"[R2Credentials] Proactively refreshing token for job={job_id} "
                    f"prefixes={cached.all_prefixes!r}"
                )
                # Re-mint with the same scope that was originally requested
                extra = [p for p in cached.all_prefixes if p != cached.prefix]
                refreshed = self.mint(
                    job_id,
                    permission=cached.permission,
                    extra_prefixes=extra,
                )
        return refreshed
