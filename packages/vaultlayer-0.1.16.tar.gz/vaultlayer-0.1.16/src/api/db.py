"""
Supabase client + query helpers.

Uses the supabase-py library with the service role key (bypasses RLS).
All public-facing queries go through Row Level Security via the anon key in
the frontend dashboard — this module is backend-only.
"""
from __future__ import annotations

import hashlib
import logging
import os
import secrets
from functools import lru_cache
from typing import Any, Callable, Optional

from supabase import create_client, Client

logger = logging.getLogger(__name__)


def _db_call(fn: Callable[[], Any], label: str = "supabase") -> Any:
    """
    Execute a Supabase call with exponential-backoff retry.
    Retries up to 3 times with delays of 1s / 5s / 10s on transient errors.
    """
    try:
        from shared.retry import sync_retry
        return sync_retry(fn, label=label)
    except ImportError:
        # shared package not on path (e.g. in isolated API tests) — run directly
        return fn()

SUPABASE_URL = os.environ.get("SUPABASE_URL", "")
SUPABASE_SERVICE_KEY = os.environ.get("SUPABASE_SERVICE_KEY", "")

# Free credits at signup — controlled by SIGNUP_BONUS_CREDITS env var.
# 1,000 credits ($10) — enough for a few short test jobs.
SIGNUP_BONUS_IMMEDIATE_CREDITS = int(os.environ.get("SIGNUP_BONUS_CREDITS", "1000"))
SIGNUP_BONUS_STAGED_CREDITS    = 0
SIGNUP_BONUS_TOTAL_CREDITS     = SIGNUP_BONUS_IMMEDIATE_CREDITS


@lru_cache(maxsize=1)
def get_db() -> Client:
    return create_client(SUPABASE_URL, SUPABASE_SERVICE_KEY)


# ── Token helpers ─────────────────────────────────────────────────────────────

def generate_token(env: str = "live") -> tuple[str, str]:
    """
    Generate a new API token.
    Returns (raw_token, token_hash).
    raw_token is shown to the user once and never stored.
    token_hash is stored in the database.
    """
    raw = f"vl_{env}_{secrets.token_hex(32)}"
    hashed = hashlib.sha256(raw.encode()).hexdigest()
    return raw, hashed


def hash_token(raw_token: str) -> str:
    return hashlib.sha256(raw_token.encode()).hexdigest()


# ── User queries ──────────────────────────────────────────────────────────────

async def create_user(
    user_id: str,
    email: str,
    signup_ip: Optional[str] = None,
    signup_device_fp: Optional[str] = None,
    referred_by_code: Optional[str] = None,
) -> dict:
    db = get_db()

    # Resolve referral code → user_id
    referred_by_user_id = None
    if referred_by_code:
        res = db.table("users").select("user_id").eq("referral_code", referred_by_code).execute()
        if res.data:
            referred_by_user_id = res.data[0]["user_id"]

    user_row = {
        "user_id":          user_id,
        "email":            email,
        "signup_ip":        signup_ip,
        "signup_device_fp": signup_device_fp,
        "referred_by":      referred_by_user_id,
    }
    db.table("users").insert(user_row).execute()

    # Immediate signup bonus
    add_credit_event(
        user_id=user_id,
        event_type="signup_bonus",
        amount_credits=SIGNUP_BONUS_IMMEDIATE_CREDITS,
        description=f"Signup bonus ({SIGNUP_BONUS_IMMEDIATE_CREDITS} of {SIGNUP_BONUS_TOTAL_CREDITS} free credits)",
    )

    # Referral bonus to referrer
    if referred_by_user_id:
        add_credit_event(
            user_id=referred_by_user_id,
            event_type="referral_bonus",
            amount_credits=500,
            description=f"Referral bonus — {email} signed up",
        )

    logger.info(f"[db] Created user {user_id} ({email}), "
                f"{SIGNUP_BONUS_IMMEDIATE_CREDITS} credits issued immediately")
    return user_row


async def get_user(user_id: str) -> Optional[dict]:
    db = get_db()
    res = db.table("users").select("*").eq("user_id", user_id).execute()
    return res.data[0] if res.data else None


async def get_user_by_token(raw_token: str) -> Optional[dict]:
    """Validate a raw API token and return the associated user row."""
    db = get_db()
    token_hash = hash_token(raw_token)
    res = _db_call(
        lambda: db.table("api_tokens")
        .select("user_id, revoked_at")
        .eq("token_hash", token_hash)
        .execute(),
        label="get_user_by_token",
    )
    if not res.data:
        return None
    token_row = res.data[0]
    if token_row["revoked_at"] is not None:
        return None

    # Update last_used_at (fire-and-forget, non-critical)
    try:
        from datetime import datetime, timezone
        db.table("api_tokens").update({
            "last_used_at": datetime.now(timezone.utc).isoformat(),
        }).eq("token_hash", token_hash).execute()
    except Exception:
        pass

    return await get_user(token_row["user_id"])


async def create_api_token(user_id: str) -> str:
    """Generate a new API token for a user. Returns the raw token (shown once)."""
    db = get_db()
    raw_token, token_hash = generate_token()
    db.table("api_tokens").insert({
        "user_id":      user_id,
        "token_hash":   token_hash,
        "token_prefix": raw_token[:16],
    }).execute()
    return raw_token


async def release_staged_bonus(user_id: str):
    """
    Release the remaining 800 staged signup credits.
    Called when the user's first job has been running for >10 minutes.
    Idempotent — checks signup_bonus_released flag.
    """
    db = get_db()
    user = await get_user(user_id)
    if not user or user.get("signup_bonus_released"):
        return

    add_credit_event(
        user_id=user_id,
        event_type="signup_bonus_staged",
        amount_credits=SIGNUP_BONUS_STAGED_CREDITS,
        description=f"Signup bonus unlocked — first job running ({SIGNUP_BONUS_STAGED_CREDITS} credits)",
    )
    db.table("users").update({"signup_bonus_released": True}).eq("user_id", user_id).execute()
    logger.info(f"[db] Released {SIGNUP_BONUS_STAGED_CREDITS} staged credits for {user_id}")


# ── Credit queries ────────────────────────────────────────────────────────────

def add_credit_event(
    user_id: str,
    event_type: str,
    amount_credits: int,
    job_id: Optional[str] = None,
    stripe_payment_id: Optional[str] = None,
    stripe_card_fp: Optional[str] = None,
    description: Optional[str] = None,
):
    """Append a row to the credit_events ledger. Synchronous — safe to call anywhere."""
    db = get_db()
    row = {
        "user_id":           user_id,
        "event_type":        event_type,
        "amount_credits":    amount_credits,
        "job_id":            job_id,
        "stripe_payment_id": stripe_payment_id,
        "stripe_card_fp":    stripe_card_fp,
        "description":       description,
    }
    _db_call(
        lambda: db.table("credit_events").insert(row).execute(),
        label=f"add_credit_event:{event_type}",
    )


def reserve_credits_for_job(
    user_id: str,
    amount_credits: int,
    job_id: str,
    idempotency_key: str,
    description: str = "",
) -> dict:
    """Atomically check-and-reserve credits via DB stored procedure (migration 0029).

    The reserve_credits_for_job() SQL function acquires a per-user advisory
    lock, reads the current balance, rejects if the reservation would push it
    negative, and inserts the credit event — all in one transaction. This
    prevents concurrent-submit overcommit.

    Returns:
        {"ok": True, "idempotent": False}  — reserved
        {"ok": True, "idempotent": True}   — already reserved (idempotent)
        {"ok": False, "reason": "insufficient_balance", "available": N}  — rejected

    Raises if the RPC is unavailable. Falling back to a direct insert would
    re-open the concurrent overcommit window this function closes.
    """
    db = get_db()
    try:
        res = _db_call(
            lambda: db.rpc("reserve_credits_for_job", {
                "p_user_id":         user_id,
                "p_amount_credits":  amount_credits,
                "p_job_id":          job_id,
                "p_idempotency_key": idempotency_key,
                "p_description":     description,
            }).execute(),
            label="reserve_credits_for_job",
        )
        data = res.data if res else {}
        if isinstance(data, list):
            data = data[0] if data else {}
        return data if isinstance(data, dict) else {}
    except Exception as _rpc_err:
        import logging as _logging
        _logging.getLogger(__name__).error(
            "reserve_credits_for_job RPC unavailable; failing closed: %s",
            _rpc_err,
        )
        raise


def get_balance(user_id: str) -> dict:
    """
    Return current credit balance from the ledger view.
    Falls back to raw SUM if the view is not yet created.
    """
    db = get_db()
    try:
        res = db.table("user_credit_balance").select("*").eq("user_id", user_id).execute()
        if res.data:
            row = res.data[0]
            balance   = int(row.get("balance_credits") or 0)
            purchased = int(row.get("total_purchased") or 0)
            spent     = int(row.get("total_spent") or 0)
        else:
            balance = purchased = spent = 0
    except Exception:
        # Fallback: compute from raw table
        res = db.table("credit_events").select("amount_credits").eq("user_id", user_id).execute()
        amounts = [int(r["amount_credits"]) for r in (res.data or [])]
        balance   = sum(amounts)
        purchased = sum(a for a in amounts if a > 0)
        spent     = abs(sum(a for a in amounts if a < 0))

    # Active reservation = reserved minus settled/released/burned, computed
    # PER-JOB and then summed. Grouping by job_id keeps each reservation
    # isolated — a prior bug summed reserved and settled across the whole
    # user, so an over-burn on Job A clamped total_active_reserved to zero
    # and made Job B's still-live reservation vanish from the calculation.
    #
    # active_reserved here is INFORMATIONAL (exposed as reserved_credits
    # in the response for dashboards/telemetry). It is intentionally NOT
    # subtracted from balance_credits: the ledger view already sums EVERY
    # row including reservations, so a -100 reservation event has already
    # reduced balance_credits. Subtracting active_reserved again would
    # double-count — e.g. a user with +1000 purchased and -100 reserved
    # would be told available=800 (wrong) instead of 900.
    events = (
        db.table("credit_events")
        .select("job_id,event_type,amount_credits")
        .eq("user_id", user_id)
        .in_("event_type", ["reserved", "settled", "released", "burned"])
        .execute()
    )
    per_job_reserved: dict[str, int] = {}
    per_job_closed:   dict[str, int] = {}
    for r in (events.data or []):
        jid = r.get("job_id") or ""
        amt = abs(int(r["amount_credits"]))
        if r["event_type"] == "reserved":
            per_job_reserved[jid] = per_job_reserved.get(jid, 0) + amt
        else:
            per_job_closed[jid] = per_job_closed.get(jid, 0) + amt
    # Per-job clamp: a single job cannot contribute negative active_reserved.
    active_reserved = sum(
        max(0, per_job_reserved.get(jid, 0) - per_job_closed.get(jid, 0))
        for jid in per_job_reserved
    )

    # balance_credits from the view already nets out reservations (they're
    # stored as negative-amount rows). The view IS the available balance.
    available = max(0, balance)
    return {
        "user_id":           user_id,
        "balance_credits":   balance,
        "reserved_credits":  active_reserved,
        "spent_credits":     spent,
        "available_credits": available,
        "available_usd":     round(available / 100, 2),
    }


# ── Job queries ───────────────────────────────────────────────────────────────

def upsert_job(job_id: str, user_id: str, fields: dict):
    db = get_db()
    db.table("jobs").upsert({"job_id": job_id, "user_id": user_id, **fields}).execute()


def update_job(job_id: str, fields: dict):
    try:
        db = get_db()
        db.table("jobs").update(fields).eq("job_id", job_id).execute()
    except Exception as e:
        logger.error(f"[db] update_job failed for {job_id}: {e}")


# ── Invoice queries ───────────────────────────────────────────────────────────

def get_invoices_for_user(user_id: str, limit: int = 50) -> list:
    """Fetch all invoices for a user, newest first. Delegates to shared.invoice."""
    from shared.invoice import get_invoices_for_user as _get
    return _get(user_id, limit=limit)


def get_invoice(invoice_id: str) -> Optional[dict]:
    """Fetch a single invoice by ID. Delegates to shared.invoice."""
    from shared.invoice import get_invoice as _get
    return _get(invoice_id)


# ── Checkpoint queries ────────────────────────────────────────────────────────

def insert_checkpoint(checkpoint: dict):
    try:
        db = get_db()
        db.table("checkpoints").insert(checkpoint).execute()
    except Exception as e:
        logger.error(f"[db] insert_checkpoint failed: {e}")
