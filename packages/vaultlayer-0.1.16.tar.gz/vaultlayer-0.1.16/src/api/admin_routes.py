"""
VaultLayer — Admin Endpoints

Admin operations for instance cleanup and worker diagnostics.
Extracted from job_routes.py.
"""
import logging
import re

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from api.auth import require_internal_admin
from api.job_worker import _init_broker, _active_jobs, _job_queue, _worker_debug

logger = logging.getLogger(__name__)

admin_jobs_router = APIRouter(prefix="/api/v1/jobs", tags=["admin"])
admin_gcp_router = APIRouter(prefix="/api/v1/admin", tags=["admin"])


# ── Request models ───────────────────────────────────────────────────────────

class TerminatePodsRequest(BaseModel):
    pod_ids: list[str] = []
    provider: str = "runpod"


class TestEmailRequest(BaseModel):
    to: str = ""  # Optional override — defaults to user's email


# ── Worker debug endpoint ───────────────────────────────────────────────────

@admin_jobs_router.get("/worker/debug")
async def worker_debug(_admin: None = Depends(require_internal_admin)):
    """Worker state — operator diagnostics. Requires X-Internal-Admin-Token.

    Previously unauthenticated and exposed: queue size, active job count,
    last_provision_attempts (with provider names + error strings), and a
    sample of active job IDs. That feed paired with the cross-tenant
    job lookup (now fixed) was a one-shot reconnaissance tool for an
    attacker. Now gated by the same internal admin token as cleanup /
    terminate-pods.
    """
    import os as _os
    return {
        **_worker_debug,
        "queue_size": len(_job_queue),
        "active_jobs": len(_active_jobs),
        "job_ids": list(_active_jobs.keys())[:5],
        "provisioning_paused": _os.environ.get("VL_PAUSE_PROVISIONING", "").strip() == "1",
    }


# ── Admin: cleanup zombie instances across ALL providers ──────────────────

async def _run_cleanup_all_providers(broker) -> dict:
    """Core cleanup logic — terminates all instances on Vast.ai, RunPod, and Lambda Labs.
    Extracted so both the manual POST and the cron GET can share it."""
    import base64 as _b64
    import aiohttp

    results = {}

    async with aiohttp.ClientSession() as session:
        # ── Vast.ai ──────────────────────────────────────────────────────
        _vast_cfg = broker._get_provider_config("vast_ai")
        if _vast_cfg and getattr(_vast_cfg, "api_key", ""):
            vast_destroyed = []
            try:
                async with session.get(
                    "https://console.vast.ai/api/v0/instances/",
                    headers={"Authorization": f"Bearer {_vast_cfg.api_key}"},
                    timeout=aiohttp.ClientTimeout(total=15),
                ) as resp:
                    if resp.status == 200:
                        for inst in (await resp.json()).get("instances", []):
                            iid = inst.get("id")
                            if not iid:
                                continue
                            try:
                                async with session.delete(
                                    f"https://console.vast.ai/api/v0/instances/{iid}/",
                                    headers={"Authorization": f"Bearer {_vast_cfg.api_key}"},
                                    timeout=aiohttp.ClientTimeout(total=10),
                                ) as dr:
                                    vast_destroyed.append({"id": iid, "status": dr.status})
                            except Exception:
                                pass
            except Exception as e:
                vast_destroyed = [{"error": str(e)[:100]}]
            results["vast_ai"] = {"destroyed": len(vast_destroyed), "instances": vast_destroyed}

        # ── RunPod ───────────────────────────────────────────────────────
        _rp_cfg = broker._get_provider_config("runpod")
        if _rp_cfg and getattr(_rp_cfg, "api_key", ""):
            rp_destroyed = []
            try:
                # List pods via GraphQL
                async with session.post(
                    f"https://api.runpod.io/graphql?api_key={_rp_cfg.api_key}",
                    json={"query": "{ myself { pods { id name desiredStatus runtime { uptimeInSeconds } gpuDisplayName } } }"},
                    timeout=aiohttp.ClientTimeout(total=15),
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        pods = data.get("data", {}).get("myself", {}).get("pods", [])
                        for pod in pods:
                            pid = pod.get("id")
                            if not pid:
                                continue
                            # DELETE the pod
                            async with session.delete(
                                f"https://rest.runpod.io/v1/pods/{pid}",
                                headers={"Authorization": f"Bearer {_rp_cfg.api_key}"},
                                timeout=aiohttp.ClientTimeout(total=10),
                            ) as dr:
                                rp_destroyed.append({
                                    "id": pid,
                                    "name": pod.get("name", ""),
                                    "gpu": pod.get("gpuDisplayName", ""),
                                    "status": dr.status,
                                })
                                logger.info(f"[cleanup] Destroyed RunPod pod {pid} -> {dr.status}")
            except Exception as e:
                rp_destroyed = [{"error": str(e)[:100]}]
            # Also try GraphQL terminatePod mutation for stopped pods
            # The REST DELETE only works on running pods
            if not rp_destroyed and pods:
                for pod in pods:
                    pid = pod.get("id")
                    if pid:
                        try:
                            async with session.post(
                                f"https://api.runpod.io/graphql?api_key={_rp_cfg.api_key}",
                                json={"query": f'mutation {{ podTerminate(input: {{podId: "{pid}"}}) }}'},
                                timeout=aiohttp.ClientTimeout(total=10),
                            ) as tr:
                                rp_destroyed.append({"id": pid, "method": "graphql_terminate", "status": tr.status})
                        except Exception:
                            pass
            results["runpod"] = {"destroyed": len(rp_destroyed), "pods_found": len(pods) if 'pods' in dir() else 0, "instances": rp_destroyed}

        # ── Lambda Labs ──────────────────────────────────────────────────
        _ll_cfg = broker._get_provider_config("lambda_labs")
        if _ll_cfg and getattr(_ll_cfg, "api_key", ""):
            ll_destroyed = []
            _ll_base_url = getattr(_ll_cfg, "base_url", "https://cloud.lambdalabs.com/api/v1")
            _ll_basic = _b64.b64encode(f"{_ll_cfg.api_key}:".encode()).decode()
            _ll_headers = {"Authorization": f"Basic {_ll_basic}"}
            try:
                async with session.get(
                    f"{_ll_base_url}/instances",
                    headers=_ll_headers,
                    timeout=aiohttp.ClientTimeout(total=15),
                ) as resp:
                    if resp.status == 200:
                        instances = (await resp.json()).get("data", [])
                        ids_to_terminate = [
                            i.get("id") for i in instances
                            if i.get("id") and i.get("status") not in ("terminated",)
                        ]
                        if ids_to_terminate:
                            async with session.post(
                                f"{_ll_base_url}/instance-operations/terminate",
                                headers=_ll_headers,
                                json={"instance_ids": ids_to_terminate},
                                timeout=aiohttp.ClientTimeout(total=30),
                            ) as tr:
                                tr_body = (await tr.text())[:200]
                                for iid in ids_to_terminate:
                                    ll_destroyed.append({"id": iid, "status": tr.status, "response": tr_body})
                                logger.info(f"[cleanup] Lambda Labs terminate {len(ids_to_terminate)} instances -> {tr.status}")
            except Exception as e:
                ll_destroyed = [{"error": str(e)[:100]}]
            results["lambda_labs"] = {"destroyed": len(ll_destroyed), "instances": ll_destroyed}

    total = sum(r.get("destroyed", 0) for r in results.values())
    return {"ok": True, "destroyed": total, "providers": results}


@admin_jobs_router.post("/admin/cleanup-instances")
async def admin_cleanup_instances(_admin: None = Depends(require_internal_admin)):
    """Destroy ALL active instances across Vast.ai, RunPod, and Lambda Labs.
    Use to clean up zombie instances that weren't properly terminated."""
    broker = _init_broker()
    if not broker:
        return {"ok": False, "error": "Broker not available"}
    return await _run_cleanup_all_providers(broker)


@admin_jobs_router.get("/admin/cron-cleanup")
async def admin_cron_cleanup(token: str = Query(..., description="VL_INTERNAL_ADMIN_TOKEN value")):
    """GET endpoint for Railway cron — terminates all zombie instances across all providers.

    Called automatically every 10 minutes via Railway cron config:
      Schedule: */10 * * * *
      Command:  curl -s "$VL_API_URL/api/v1/jobs/admin/cron-cleanup?token=$VL_INTERNAL_ADMIN_TOKEN"

    Accepts the admin token as a query param (not header) so Railway cron's
    simple curl command doesn't need custom header support. The token is the
    same VL_INTERNAL_ADMIN_TOKEN used by the POST /admin/cleanup-instances endpoint.
    """
    import os
    _expected = os.environ.get("VL_INTERNAL_ADMIN_TOKEN", "")
    if not _expected or token != _expected:
        # Return 404 (not 401/403) to hide the endpoint's existence from scanners
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Not found")

    broker = _init_broker()
    if not broker:
        return {"ok": False, "error": "Broker not available"}

    result = await _run_cleanup_all_providers(broker)
    logger.info(f"[cron-cleanup] Auto-cleanup fired: destroyed={result.get('destroyed', 0)}")
    return result


@admin_jobs_router.post("/admin/terminate-pods")
async def admin_terminate_pods(
    body: TerminatePodsRequest,
    _admin: None = Depends(require_internal_admin),
):
    """Directly terminate specific pods by ID. Use for stale/stopped pods that cleanup misses."""
    import aiohttp
    broker = _init_broker()
    if not broker:
        return {"ok": False, "error": "Broker not available"}

    results = []
    if body.provider == "runpod":
        _cfg = broker._get_provider_config("runpod")
        if not _cfg or not getattr(_cfg, "api_key", ""):
            return {"ok": False, "error": "RunPod API key not configured"}
        async with aiohttp.ClientSession() as session:
            for pid in body.pod_ids:
                # Try REST DELETE first, then GraphQL terminate
                for method, req in [
                    ("rest_delete", lambda: session.delete(
                        f"https://rest.runpod.io/v1/pods/{pid}",
                        headers={"Authorization": f"Bearer {_cfg.api_key}"},
                        timeout=aiohttp.ClientTimeout(total=10),
                    )),
                    ("graphql_terminate", lambda: session.post(
                        f"https://api.runpod.io/graphql?api_key={_cfg.api_key}",
                        json={"query": f'mutation {{ podTerminate(input: {{podId: "{pid}"}}) }}'},
                        timeout=aiohttp.ClientTimeout(total=10),
                    )),
                ]:
                    try:
                        async with req() as resp:
                            status = resp.status
                            body_text = (await resp.text())[:200]
                            results.append({"pod_id": pid, "method": method, "status": status, "response": body_text})
                            if status in (200, 202, 204):
                                break  # success, no need to try next method
                    except Exception as e:
                        results.append({"pod_id": pid, "method": method, "error": str(e)[:100]})
    return {"ok": True, "results": results}


# ── Admin: GCE serial console output (diagnosis) ─────────────────────────────
#
# compute.instances.getSerialPortOutput returns the rolling ~1 MB serial log
# from a GCE instance. Port 1 is where the guest agent, cloud-init, and
# google-startup-scripts.service write output — i.e., every clue you'd want
# when a job provisions but never posts a heartbeat. Ports 2-4 are for
# application-level serial I/O and are only useful if user code writes to
# /dev/ttyS{1,2,3} explicitly; reject anything outside 1-4.
#
# Gated by VL_INTERNAL_ADMIN_TOKEN so ordinary authenticated users can't
# harvest startup-script contents (which can include injected env vars) via
# a job_id they happen to know.

_INSTANCE_NAME_RE = re.compile(r"^[a-z][a-z0-9-]{0,62}$")
_ZONE_RE          = re.compile(r"^[a-z]+-[a-z0-9]+-[a-z]$")


@admin_gcp_router.get("/gcp-serial-console/{zone}/{instance}")
async def gcp_serial_console(
    zone: str,
    instance: str,
    port: int = Query(1, ge=1, le=4),
    start: int = Query(0, ge=0),
    _admin: None = Depends(require_internal_admin),
):
    """Fetch rolling serial port output from a GCE instance.

    Use for diagnosing stuck provisions — the VaultLayer heartbeat won't
    stream logs if cloud-init or google-startup-scripts.service is blocked,
    and serial port 1 is where the guest agent writes boot output verbatim.

    Parameters:
      zone     — GCE zone, e.g. "us-central1-a"
      instance — the VM's `name` field from instances.insert (we use the
                 pattern "vl-{job_id[:8]}-{gpu[:3].lower()}")
      port     — serial port number (1-4). Default 1 = console. 2-4 are
                 application-level ports and typically empty.
      start    — byte offset into the rolling buffer. 0 for first fetch;
                 use the `next` value from the previous response for
                 incremental polling.

    Response (pass-through of the GCE REST shape):
      {
        "kind": "compute#serialPortOutput",
        "contents": "<log bytes>",
        "start": "<byte offset where contents begins>",
        "next":  "<byte offset to pass on the next call>"
      }

    Source: https://docs.cloud.google.com/compute/docs/reference/rest/v1/
            instances/getSerialPortOutput
    """
    if not _ZONE_RE.match(zone):
        raise HTTPException(status_code=400, detail="Invalid zone format")
    if not _INSTANCE_NAME_RE.match(instance):
        raise HTTPException(status_code=400, detail="Invalid instance name format")

    # Reuse the broker's in-process GCP credential path. Never logs the
    # service account key or contents — only metadata about the fetch.
    from api.credentials import _read_provider_credentials
    creds = _read_provider_credentials("gcp")
    if creds is None:
        raise HTTPException(
            status_code=503,
            detail="GCP managed credentials not configured (set VL_GCP_* on Railway).",
        )

    try:
        from google.oauth2 import service_account
        from googleapiclient import discovery
        from googleapiclient.errors import HttpError
    except ImportError:
        raise HTTPException(
            status_code=500,
            detail="google-api-python-client not installed on server.",
        )

    sa_info = {
        "type":         "service_account",
        "project_id":   creds["project_id"],
        "private_key":  creds["private_key"].replace("\\n", "\n"),
        "client_email": creds["client_email"],
        "token_uri":    "https://oauth2.googleapis.com/token",
    }
    gcp_creds = service_account.Credentials.from_service_account_info(
        sa_info, scopes=["https://www.googleapis.com/auth/compute"],
    )
    compute = discovery.build("compute", "v1", credentials=gcp_creds, cache_discovery=False)

    try:
        resp = compute.instances().getSerialPortOutput(
            project=creds["project_id"],
            zone=zone,
            instance=instance,
            port=port,
            start=str(start),
        ).execute()
    except HttpError as e:
        status_code = getattr(e.resp, "status", 502)
        detail = f"GCE API error ({status_code}): {str(e)[:200]}"
        logger.warning("[admin] gcp-serial-console %s/%s port=%s: %s", zone, instance, port, detail)
        # Surface 404 (instance not found / wrong zone) directly.
        raise HTTPException(
            status_code=404 if status_code == 404 else 502,
            detail=detail,
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"getSerialPortOutput failed: {str(e)[:200]}")

    # Don't let the response balloon beyond 1 MB — GCE caps at 1 MB but we
    # double-check in case the client ever returns more on a quirky response.
    contents = (resp.get("contents") or "")[:1_048_576]
    return {
        "kind":     resp.get("kind", "compute#serialPortOutput"),
        "contents": contents,
        "start":    resp.get("start"),
        "next":     resp.get("next"),
        "port":     port,
        "instance": instance,
        "zone":     zone,
    }


@admin_gcp_router.get("/gcp-instances")
async def gcp_list_instances_all_zones(
    _admin: None = Depends(require_internal_admin),
):
    """List all compute instances across every zone in the project.

    Purpose: diagnose CPUS_ALL_REGIONS quota exhaustion. That quota is
    global, so leftover instances in ANY zone count against it. This
    endpoint calls instances.aggregatedList to scan every zone.
    """
    from api.credentials import _read_provider_credentials
    creds = _read_provider_credentials("gcp")
    if creds is None:
        raise HTTPException(status_code=503, detail="GCP managed credentials not configured.")

    try:
        from google.oauth2 import service_account
        from googleapiclient import discovery
        from googleapiclient.errors import HttpError
    except ImportError:
        raise HTTPException(status_code=500, detail="google-api-python-client not installed.")

    sa_info = {
        "type":         "service_account",
        "project_id":   creds["project_id"],
        "private_key":  creds["private_key"].replace("\\n", "\n"),
        "client_email": creds["client_email"],
        "token_uri":    "https://oauth2.googleapis.com/token",
    }
    gcp_creds = service_account.Credentials.from_service_account_info(
        sa_info, scopes=["https://www.googleapis.com/auth/compute"],
    )
    compute = discovery.build("compute", "v1", credentials=gcp_creds, cache_discovery=False)

    try:
        resp = compute.instances().aggregatedList(project=creds["project_id"]).execute()
    except HttpError as e:
        raise HTTPException(status_code=502, detail=f"aggregatedList failed: {str(e)[:200]}")

    instances_by_zone = {}
    total_vcpus = 0
    for zone_path, info in (resp.get("items") or {}).items():
        zone_name = zone_path.replace("zones/", "")
        items = info.get("instances") or []
        if items:
            slim = []
            for i in items:
                mt = i.get("machineType", "").split("/")[-1]
                # Rough vCPU count from machine type (n1-standard-4 → 4, n1-standard-8 → 8)
                vcpus = 0
                for s in mt.split("-"):
                    if s.isdigit():
                        vcpus = int(s)
                        break
                slim.append({
                    "name":        i.get("name"),
                    "status":      i.get("status"),
                    "machineType": mt,
                    "vcpus":       vcpus,
                    "creationTimestamp": i.get("creationTimestamp"),
                })
                if i.get("status") in ("RUNNING", "PROVISIONING", "STAGING", "REPAIRING"):
                    total_vcpus += vcpus
            instances_by_zone[zone_name] = slim

    return {
        "project":     creds["project_id"],
        "total_zones_with_instances": len(instances_by_zone),
        "total_active_vcpus": total_vcpus,
        "instances":   instances_by_zone,
    }


@admin_gcp_router.post("/gcp-terminate/{zone}/{instance}")
async def gcp_terminate_instance(
    zone: str,
    instance: str,
    _admin: None = Depends(require_internal_admin),
):
    """Force-terminate a GCE instance that VaultLayer's hard_fence leaked.

    When hard_fence fails or a job is marked failed before fence fires,
    the GCE VM keeps running and keeps consuming CPUS_ALL_REGIONS quota
    (which then blocks new provisions). Operators use this to manually
    clean up.
    """
    if not _ZONE_RE.match(zone):
        raise HTTPException(status_code=400, detail="Invalid zone format")
    if not _INSTANCE_NAME_RE.match(instance):
        raise HTTPException(status_code=400, detail="Invalid instance name format")

    from api.credentials import _read_provider_credentials
    creds = _read_provider_credentials("gcp")
    if creds is None:
        raise HTTPException(status_code=503, detail="GCP managed credentials not configured.")

    try:
        from google.oauth2 import service_account
        from googleapiclient import discovery
        from googleapiclient.errors import HttpError
    except ImportError:
        raise HTTPException(status_code=500, detail="google-api-python-client not installed.")

    sa_info = {
        "type":         "service_account",
        "project_id":   creds["project_id"],
        "private_key":  creds["private_key"].replace("\\n", "\n"),
        "client_email": creds["client_email"],
        "token_uri":    "https://oauth2.googleapis.com/token",
    }
    gcp_creds = service_account.Credentials.from_service_account_info(
        sa_info, scopes=["https://www.googleapis.com/auth/compute"],
    )
    compute = discovery.build("compute", "v1", credentials=gcp_creds, cache_discovery=False)

    try:
        op = compute.instances().delete(
            project=creds["project_id"], zone=zone, instance=instance
        ).execute()
        return {"ok": True, "operation": op.get("name"), "instance": instance, "zone": zone}
    except HttpError as e:
        code = getattr(e.resp, "status", 502)
        if code == 404:
            raise HTTPException(status_code=404, detail=f"Instance {instance} not found in {zone}.")
        raise HTTPException(status_code=502, detail=f"delete failed ({code}): {str(e)[:200]}")


@admin_gcp_router.get("/gcp-operations/{zone}")
async def gcp_list_operations(
    zone: str,
    filter_: str = Query("", alias="filter"),
    max_results: int = Query(20, ge=1, le=100),
    _admin: None = Depends(require_internal_admin),
):
    """List recent zoneOperations for diagnosing failed async inserts.

    When instances.insert returns an Operation name but the instance is
    never actually created (async failure), the error lives on the
    Operation object, not the instance. This endpoint lists recent ops
    in a zone so operators can spot failed inserts.

    Filter examples:
      operationType=insert
      status=DONE
      targetLink~.*vl-abc123.*
    """
    if not _ZONE_RE.match(zone):
        raise HTTPException(status_code=400, detail="Invalid zone format")

    from api.credentials import _read_provider_credentials
    creds = _read_provider_credentials("gcp")
    if creds is None:
        raise HTTPException(
            status_code=503,
            detail="GCP managed credentials not configured (set VL_GCP_* on Railway).",
        )

    try:
        from google.oauth2 import service_account
        from googleapiclient import discovery
        from googleapiclient.errors import HttpError
    except ImportError:
        raise HTTPException(status_code=500, detail="google-api-python-client not installed.")

    sa_info = {
        "type":         "service_account",
        "project_id":   creds["project_id"],
        "private_key":  creds["private_key"].replace("\\n", "\n"),
        "client_email": creds["client_email"],
        "token_uri":    "https://oauth2.googleapis.com/token",
    }
    gcp_creds = service_account.Credentials.from_service_account_info(
        sa_info, scopes=["https://www.googleapis.com/auth/compute"],
    )
    compute = discovery.build("compute", "v1", credentials=gcp_creds, cache_discovery=False)

    try:
        kwargs = dict(
            project=creds["project_id"],
            zone=zone,
            orderBy="creationTimestamp desc",
            maxResults=max_results,
        )
        if filter_:
            kwargs["filter"] = filter_
        resp = compute.zoneOperations().list(**kwargs).execute()
    except HttpError as e:
        raise HTTPException(status_code=502, detail=f"zoneOperations.list failed: {str(e)[:200]}")
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"zoneOperations.list exception: {str(e)[:200]}")

    # Return a slim view of each op — full GCE op responses are verbose.
    items = []
    for op in (resp.get("items") or [])[:max_results]:
        items.append({
            "name":           op.get("name"),
            "operationType":  op.get("operationType"),
            "status":         op.get("status"),
            "targetLink":     op.get("targetLink"),
            "progress":       op.get("progress"),
            "insertTime":     op.get("insertTime"),
            "startTime":      op.get("startTime"),
            "endTime":        op.get("endTime"),
            "error":          op.get("error"),
            "warnings":       op.get("warnings"),
            "statusMessage":  op.get("statusMessage"),
            "httpErrorStatusCode":  op.get("httpErrorStatusCode"),
            "httpErrorMessage":     op.get("httpErrorMessage"),
        })
    return {"zone": zone, "count": len(items), "operations": items}


# ── Bill reconciliation (manual sweep) ────────────────────────────────────

@admin_gcp_router.post("/bill-reconcile")
async def bill_reconcile_now(
    day: str = Query(None, description="UTC day YYYY-MM-DD. Default = today - VL_RECONCILE_LAG_DAYS (typically 2)."),
    _admin: None = Depends(require_internal_admin),
):
    """Trigger AWS bill reconciliation for a single UTC day.

    The background loop runs this daily at VL_RECONCILE_HOUR_UTC (default 08:00).
    Use this endpoint to sweep a specific historical day, or to force a run
    outside the scheduled window (e.g. after bumping quota / fixing creds).

    Returns the reconciliation summary (instances_returned, rows_updated,
    drifts_flagged, ce_api_calls, error). Safe to call repeatedly — the
    `provider_billed_usd IS NULL` idempotency filter ensures rows aren't
    overwritten on re-runs.

    Query params:
      day — optional. Pass YYYY-MM-DD to reconcile that specific UTC day.
            Omit to use the default lag window.
    """
    from datetime import date as _date
    from api.bill_reconcile import reconcile_aws_day

    target_day = None
    if day:
        try:
            target_day = _date.fromisoformat(day)
        except Exception:
            raise HTTPException(status_code=400, detail="day must be YYYY-MM-DD")

    summary = reconcile_aws_day(target_day=target_day)
    return summary.as_dict()


@admin_gcp_router.get("/bill-drift-flagged")
async def bill_drift_flagged(
    limit: int = Query(50, ge=1, le=500),
    _admin: None = Depends(require_internal_admin),
):
    """List job_runs rows where bill reconciliation flagged a drift > 25%.

    These rows are waiting for ops review. We haven't auto-corrected the
    user's charge (per product decision — VaultLayer absorbs drift silently),
    but each one represents a margin delta that might warrant investigation
    (e.g. systematic drift in a specific region = wrong rate_per_hr in config).
    """
    from api.db import get_db
    db = get_db()
    if db is None:
        raise HTTPException(status_code=503, detail="Supabase unavailable")

    try:
        # Supabase PostgREST: filter on metadata->>'audit_status'
        res = (
            db.table("job_runs")
            .select("run_id, job_id, account_id, provider, instance_id, region, "
                    "provisioned_at, terminated_at, billing_seconds, rate_per_hr, "
                    "estimated_cost_usd, provider_billed_usd, user_charged_usd, metadata")
            .filter("metadata->>audit_status", "eq", "drift_flagged")
            .order("terminated_at", desc=True)
            .limit(limit)
            .execute()
        )
        rows = res.data or []
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"query failed: {str(e)[:200]}")

    # Compute a summary on the way out so the dashboard doesn't have to
    total_drift_usd = 0.0
    overcharges = 0
    undercharges = 0
    for r in rows:
        meta = r.get("metadata") or {}
        total_drift_usd += float(meta.get("audit_delta_usd") or 0.0)
        kind = meta.get("audit_kind", "")
        if kind == "OVERCHARGE":
            overcharges += 1
        elif kind == "UNDERCHARGE":
            undercharges += 1

    return {
        "count": len(rows),
        "total_drift_usd": round(total_drift_usd, 4),
        "overcharges": overcharges,
        "undercharges": undercharges,
        "rows": rows,
    }

