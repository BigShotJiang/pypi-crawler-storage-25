"""
vaultlayer login — Log into an existing VaultLayer account from the CLI.

Flow:
  1. Enter your email
  2. We send a 6-digit verification code
  3. Paste the code
  4. New token issued and saved, ready to use

Use this when:
  - You're on a new machine
  - You lost your token
  - You want to switch accounts
"""
from __future__ import annotations

import os
from pathlib import Path

import click


from shared.api_utils import get_api_url as _api_url


def _save_token(token: str) -> None:
    cfg_dir = Path.home() / ".vaultlayer"
    cfg_dir.mkdir(mode=0o700, exist_ok=True)
    config_env = cfg_dir / "config.env"

    lines = []
    if config_env.exists():
        lines = [l for l in config_env.read_text().splitlines() if not l.startswith("VAULTLAYER_TOKEN=")]
    lines.append(f"VAULTLAYER_TOKEN={token}")
    config_env.write_text("\n".join(lines) + "\n")
    config_env.chmod(0o600)


@click.command(hidden=True)
@click.option("--email", default=None, help="Your email address (prompted if not provided)")
def login(email: str | None):
    """(Disabled) Use vaultlayer init instead."""
    click.echo("")
    click.echo("  vaultlayer login is not available.")
    click.echo("  To authenticate:       vaultlayer init")
    click.echo("  To rotate your token:  vaultlayer init --reauth")
    click.echo("")
    raise SystemExit(1)

    click.echo("")
    click.echo("  VaultLayer Login")
    click.echo("  ================")
    click.echo("")

    if not email:
        email = click.prompt("  Email").strip()

    if not email or "@" not in email:
        click.echo("  Invalid email address.")
        raise SystemExit(1)

    # Step 1: Request verification code
    click.echo(f"  Sending verification code to {email}...")
    try:
        resp = httpx.post(f"{api}/api/v1/auth/login", json={"email": email}, timeout=15)
        if resp.status_code == 404:
            click.echo("")
            click.echo("  No account found for this email.")
            click.echo("  Run: vaultlayer signup")
            raise SystemExit(0)
        if resp.status_code == 429:
            click.echo("")
            click.echo("  Too many attempts. Try again in an hour.")
            raise SystemExit(1)
        resp.raise_for_status()
    except httpx.HTTPStatusError as e:
        msg = ""
        try:
            msg = e.response.json().get("detail", "")
        except Exception:
            pass
        click.echo(f"  Error: {msg or e}")
        raise SystemExit(1)
    except httpx.ConnectError:
        click.echo("  Could not connect to VaultLayer API. Check your internet connection.")
        raise SystemExit(1)

    # Step 2: Get code from user
    click.echo("")
    click.echo("  Check your email inbox (also check spam).")
    click.echo("")
    code = click.prompt("  Verification code").strip()

    # Step 3: Verify code
    try:
        resp = httpx.post(f"{api}/api/v1/auth/verify", json={
            "email": email, "code": code, "action": "login",
        }, timeout=15)
        if resp.status_code == 401:
            click.echo("  Invalid code. Check your email and try again.")
            raise SystemExit(1)
        if resp.status_code == 410:
            click.echo("  Code expired. Run 'vaultlayer login' again.")
            raise SystemExit(1)
        resp.raise_for_status()
    except httpx.HTTPStatusError as e:
        msg = ""
        try:
            msg = e.response.json().get("detail", "")
        except Exception:
            pass
        click.echo(f"  Error: {msg or e}")
        raise SystemExit(1)

    data = resp.json()
    token = data.get("token", "")
    balance = data.get("balance_credits", 0)

    # Step 4: Save token
    _save_token(token)

    click.echo("")
    click.echo(f"  Welcome back!")
    click.echo(f"  Email:   {email}")
    click.echo(f"  Credits: {balance} (${balance/100:.2f})")
    click.echo(f"  Token:   saved to ~/.vaultlayer/config.env")
    click.echo("")
