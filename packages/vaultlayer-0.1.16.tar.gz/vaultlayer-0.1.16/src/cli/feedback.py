"""
VaultLayer CLI — feedback command and inline crash reporting prompt.
"""
from __future__ import annotations

import os
from typing import Optional

import click

from cli.crash_reporter import load_crash_report, mark_submitted, scrub


from shared.api_utils import get_api_url as _api_url


def _load_token() -> Optional[str]:
    """Load stored VaultLayer token, returning None if not found."""
    token = os.environ.get("VAULTLAYER_TOKEN", "")
    if token:
        return token
    from pathlib import Path
    # Primary: config.env written by `vaultlayer init`
    config_env = Path.home() / ".vaultlayer" / "config.env"
    if config_env.exists():
        for line in config_env.read_text().splitlines():
            if line.startswith("VAULTLAYER_TOKEN="):
                token = line.split("=", 1)[1].strip().strip('"').strip("'")
                if token:
                    return token
    # Legacy: plain token file
    token_file = Path.home() / ".vaultlayer" / "token"
    if token_file.exists():
        return token_file.read_text().strip()
    return None


def _fetch_r2_logs(job_id: str) -> Optional[str]:
    """
    Fetch the last 50 lines from R2 for a given job, returning a scrubbed string.
    Returns None on any error.
    """
    try:
        from shared.config import load_config
        from agents.vault.r2 import R2Client
        config = load_config()
        r2 = R2Client(
            endpoint=config.cloudflare.r2_endpoint,
            access_key_id=config.cloudflare.r2_access_key_id,
            secret_access_key=config.cloudflare.r2_secret_access_key,
            bucket=config.cloudflare.r2_bucket,
        )
        response = r2._s3.get_object(
            Bucket=config.cloudflare.r2_bucket,
            Key=f"logs/{job_id}/tail.txt",
        )
        content = response["Body"].read().decode("utf-8", errors="replace")
        lines = content.splitlines()
        last_50 = "\n".join(lines[-50:])
        return scrub(last_50)
    except Exception:
        return None


def submit_report(report: dict, token: str, log_snippet: Optional[str] = None) -> Optional[str]:
    """
    POST crash/feedback report to /api/v1/feedback.
    Returns feedback_id (e.g. "fb_abc12345") or None on failure.
    """
    import httpx

    payload = {
        "type": "auto_crash",
        "message": report.get("error_message", ""),
        "job_id": report.get("job_id"),
        "log_snippet": log_snippet,
        "command": " ".join(report.get("command", [])),
        "gpu_type": report.get("gpu_type"),
        "provider": report.get("provider"),
        "error_type": report.get("error_type"),
        "traceback": report.get("traceback"),
        "fingerprint": report.get("fingerprint"),
        "source": "cli_crash",
    }
    # Remove None values
    payload = {k: v for k, v in payload.items() if v is not None}

    try:
        resp = httpx.post(
            f"{_api_url()}/api/v1/feedback",
            json=payload,
            headers={"Authorization": f"Bearer {token}"},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
        return data.get("id")
    except Exception:
        return None


def prompt_crash_report(
    report_id: str,
    command: list[str],
    job_id: Optional[str] = None,
) -> None:
    """
    Called inline after a CLI error. Loads the crash report, shows a summary,
    asks user to submit, and either submits or prints skip message.
    """
    report = load_crash_report(report_id)
    if not report:
        return

    token = _load_token()

    # Fetch R2 logs if job_id is available
    log_snippet: Optional[str] = None
    if job_id:
        log_snippet = _fetch_r2_logs(job_id)

    # Print summary box
    click.echo("")
    click.echo("  ┌─ Crash Report " + "─" * 40)
    click.echo(f"  │  ID:        {report_id}")
    click.echo(f"  │  Error:     {report.get('error_type', 'Unknown')}: "
               f"{report.get('error_message', '')[:80]}")
    if report.get("fingerprint"):
        click.echo(f"  │  Fingerprint: {report['fingerprint']}")
    if log_snippet:
        click.echo(f"  │  Logs:      (last 50 lines attached)")
    click.echo("  │")
    click.echo("  │  This report contains: error type, traceback, command,")
    click.echo("  │  GPU type, and provider. No credentials or PII.")
    click.echo("  └" + "─" * 54)
    click.echo("")

    answer = click.prompt(
        "  Submit crash report to help us fix this? [Y/n]",
        default="Y",
        show_default=False,
    ).strip().lower()

    if answer in ("", "y", "yes"):
        if not token:
            click.echo("  Not authenticated — run 'vaultlayer init' to enable crash reporting.")
            return
        feedback_id = submit_report(report, token, log_snippet)
        if feedback_id:
            mark_submitted(report_id)
            click.echo(f"  Report submitted ({feedback_id}). We'll notify you when it's fixed.")
        else:
            click.echo(f"  Could not submit report. Run 'vaultlayer feedback --report {report_id}' to retry.")
    else:
        click.echo(f"  Skipped. Run 'vaultlayer feedback --report {report_id}' anytime.")


@click.command()
@click.option("--report", "report_id", default=None, metavar="REPORT_ID",
              help="Submit a saved crash report (e.g. cr_abc12345)")
def feedback(report_id: Optional[str]) -> None:
    """Submit feedback or a crash report to VaultLayer."""
    token = _load_token()

    if report_id:
        # Load saved crash report, show summary, ask Y/N
        report = load_crash_report(report_id)
        if not report:
            click.echo(f"  Crash report '{report_id}' not found.", err=True)
            raise SystemExit(1)

        if report.get("submitted"):
            click.echo(f"  Report '{report_id}' has already been submitted.")
            return

        # Show summary
        click.echo("")
        click.echo("  ┌─ Crash Report " + "─" * 40)
        click.echo(f"  │  ID:        {report_id}")
        click.echo(f"  │  Time:      {report.get('timestamp', 'unknown')}")
        click.echo(f"  │  Error:     {report.get('error_type', 'Unknown')}: "
                   f"{report.get('error_message', '')[:80]}")
        click.echo(f"  │  Command:   {' '.join(report.get('command', []))}")
        if report.get("fingerprint"):
            click.echo(f"  │  Fingerprint: {report['fingerprint']}")
        click.echo("  └" + "─" * 54)
        click.echo("")

        answer = click.prompt(
            "  Submit this report? [Y/n]",
            default="Y",
            show_default=False,
        ).strip().lower()

        if answer not in ("", "y", "yes"):
            click.echo("  Skipped.")
            return

        if not token:
            click.echo("  Not authenticated — run 'vaultlayer init' first.")
            raise SystemExit(1)

        feedback_id = submit_report(report, token)
        if feedback_id:
            mark_submitted(report_id)
            click.echo(f"  Report submitted ({feedback_id}). We'll notify you when it's fixed.")
        else:
            click.echo("  Submission failed. Check your connection and try again.")

    else:
        # Interactive: ask the user to describe the issue
        click.echo("")
        click.echo("  VaultLayer Feedback")
        click.echo("  " + "─" * 40)
        message = click.prompt("  Describe the issue")
        message = scrub(message)

        if not token:
            click.echo("  Not authenticated — run 'vaultlayer init' first.")
            raise SystemExit(1)

        import httpx
        payload = {
            "type": "feedback",
            "message": message,
            "source": "cli_feedback",
        }
        try:
            resp = httpx.post(
                f"{_api_url()}/api/v1/feedback",
                json=payload,
                headers={"Authorization": f"Bearer {token}"},
                timeout=15,
            )
            resp.raise_for_status()
            data = resp.json()
            feedback_id = data.get("id", "unknown")
            click.echo(f"  Feedback submitted ({feedback_id}). Thank you!")
        except Exception as e:
            click.echo(f"  Submission failed: {e}")
