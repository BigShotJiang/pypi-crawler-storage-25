"""
vaultlayer download — Download job results (checkpoints, artifacts, manifest) from R2.

Usage:
    vaultlayer download --job-id <id>                  # download to ./vaultlayer-results/<job_id>/
    vaultlayer download --job-id <id> --output ./out   # download to ./out/
"""
from __future__ import annotations

import os
import json
import logging
from pathlib import Path

import click

logger = logging.getLogger(__name__)


@click.command()
@click.option("--job-id", required=True, help="Job ID to download results for.")
@click.option("--output", "-o", default=None,
              help="Output directory. Defaults to ./vaultlayer-results/<job-id>/")
def download(job_id: str, output: str | None):
    """Download job checkpoints, artifacts, and manifest from VaultLayer R2.

    \b
    Downloads the entire R2 prefix for the given job, including:
      - Final checkpoint (weights, optimizer state)
      - Training artifacts (logs, metrics)
      - Job Manifest (JSON with full billing + hop history)
    """
    output_dir = Path(output) if output else Path(f"./vaultlayer-results/{job_id}")
    output_dir.mkdir(parents=True, exist_ok=True)

    # ── Generate Job Manifest (if DB is available) ───────────────────────────
    try:
        from shared.manifest import generate_manifest
        token = os.environ.get("VAULTLAYER_TOKEN", "")
        user_id = os.environ.get("VAULTLAYER_USER_ID", "default")
        manifest = generate_manifest(job_id, user_id)
        if "error" not in manifest:
            manifest_path = output_dir / "manifest.json"
            with open(manifest_path, "w") as f:
                json.dump(manifest, f, indent=2, default=str)
            click.echo(f"  Job Manifest saved to {manifest_path}")
    except Exception as _m_err:
        click.echo(f"  Note: could not generate manifest ({_m_err}). Downloading files only.")

    # Load R2 credentials from environment / config
    from shared.env_utils import load_vaultlayer_env
    load_vaultlayer_env()

    from shared.r2_utils import get_r2_credentials
    _r2 = get_r2_credentials(job_id)
    r2_endpoint = _r2.get("endpoint", "")
    r2_access_key = _r2.get("access_key_id", "")
    r2_secret_key = _r2.get("secret_access_key", "")
    r2_bucket = _r2.get("bucket", "vaultlayer-checkpoints")

    if not all([r2_endpoint, r2_access_key, r2_secret_key]):
        # Try to fetch job-scoped credentials from API
        from shared.api_utils import get_token, get_api_url
        token = get_token()
        api_url = get_api_url()
        if token:
            _download_via_api(api_url, token, job_id, r2_bucket, output_dir)
        else:
            click.echo("  Error: R2 credentials not configured and no VAULTLAYER_TOKEN found.")
            click.echo("  Run: vaultlayer init")
            raise SystemExit(1)
        return

    _download_via_s3(r2_endpoint, r2_access_key, r2_secret_key, r2_bucket, job_id, output_dir)


def _download_via_s3(endpoint: str, access_key: str, secret_key: str,
                      bucket: str, job_id: str, output_dir: Path) -> None:
    """Download using boto3 S3 API (direct R2 access)."""
    try:
        import boto3
    except ImportError:
        click.echo("  Error: boto3 required for download. pip install boto3")
        raise SystemExit(1)

    s3 = boto3.client(
        "s3",
        endpoint_url=endpoint,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
    )

    prefix = f"checkpoints/{job_id}/"
    click.echo(f"  Downloading R2 prefix: {prefix}")
    click.echo(f"  Output: {output_dir}")

    paginator = s3.get_paginator("list_objects_v2")
    total_files = 0
    total_bytes = 0

    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for obj in page.get("Contents", []):
            key = obj["Key"]
            # Strip the prefix to get relative path
            rel_path = key[len(prefix):]
            if not rel_path:
                continue

            local_path = (output_dir / rel_path).resolve()
            # Prevent path traversal (e.g. "../../etc/passwd" in R2 key)
            if not str(local_path).startswith(str(output_dir.resolve())):
                logger.warning(f"Skipping path-traversal key: {key}")
                continue
            local_path.parent.mkdir(parents=True, exist_ok=True)

            s3.download_file(bucket, key, str(local_path))
            total_files += 1
            total_bytes += obj.get("Size", 0)

            if total_files % 10 == 0:
                click.echo(f"  ... {total_files} files downloaded")

    if total_files == 0:
        click.echo(f"  No files found for job {job_id}.")
    else:
        size_mb = total_bytes / (1024 * 1024)
        click.echo(f"  Done: {total_files} files ({size_mb:.1f} MB) → {output_dir}")


def _download_via_api(api_url: str, token: str, job_id: str,
                       bucket: str, output_dir: Path) -> None:
    """Download checkpoints using R2 credentials from environment variables.

    The /api/v1/credentials/provider endpoint was removed (security redesign —
    it vended company cloud-account keys to end users). R2 credentials are now
    read from env vars set by `vaultlayer init` / `vaultlayer connect storage`.
    """
    from shared.r2_utils import get_r2_credentials
    creds = get_r2_credentials(job_id)
    if not creds:
        click.echo(
            "  Error: R2 credentials not found in environment.\n"
            "  Run: vaultlayer connect storage  (or set R2_ENDPOINT, "
            "R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY in your .env)"
        )
        raise SystemExit(1)

    click.echo(f"  Downloading checkpoints for job {job_id} from R2...")
    _download_via_s3(
        endpoint=creds.get("endpoint", ""),
        access_key=creds.get("access_key_id", ""),
        secret_key=creds.get("secret_access_key", ""),
        bucket=creds.get("bucket", bucket),
        job_id=job_id,
        output_dir=output_dir,
    )
