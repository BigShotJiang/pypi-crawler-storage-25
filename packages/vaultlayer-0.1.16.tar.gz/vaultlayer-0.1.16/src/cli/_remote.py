"""
VaultLayer CLI — Remote GPU execution.

Thin display client: submits jobs to the VaultLayer API server and polls
for status updates + log streaming. The server handles all provisioning,
monitoring, termination, and recovery.

Local provisioning fallback is legacy BYOC/self-hosted behavior and is
disabled by default for managed runs.
"""
from __future__ import annotations

import asyncio
import base64
import logging
import os
import shlex
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from cli.run import RunCommand
    from agents.broker.agent import BrokerAgent
    from shared.models import Job, Provider, GPUType
    from shared.queue import AgentQueue

logger = logging.getLogger(__name__)

_PYTHON_EXECUTABLE_NAMES = {"python", "python3"}
_PYTHON_FLAGS_WITHOUT_VALUE = {"-u", "-B", "-E", "-I", "-O", "-OO", "-s", "-S"}
_PYTHON_FLAGS_WITH_VALUE = {"-W", "-X"}
_ALLOWED_REMOTE_MODULE_LAUNCHERS = {
    "torch.distributed.launch",
    "torch.distributed.run",
    "accelerate.commands.launch",
    "accelerate",
    "deepspeed",
    "deepspeed.launcher.runner",
    "torchrun",
}


def _python_module_invocation(command: list[str]) -> Optional[str]:
    """Return the module for `python [-opts] -m module`, if command uses it."""
    for idx, arg in enumerate(command[:-1]):
        if Path(arg).name not in _PYTHON_EXECUTABLE_NAMES:
            continue
        pos = idx + 1
        while pos < len(command):
            token = command[pos]
            if token == "-m":
                return command[pos + 1] if pos + 1 < len(command) else ""
            if token in _PYTHON_FLAGS_WITHOUT_VALUE:
                pos += 1
                continue
            if token in _PYTHON_FLAGS_WITH_VALUE:
                pos += 2
                continue
            if any(token.startswith(flag) for flag in _PYTHON_FLAGS_WITH_VALUE):
                pos += 1
                continue
            if token.startswith("-"):
                pos += 1
                continue
            return None
    return None


def _local_fallback_enabled() -> bool:
    return os.environ.get("VAULTLAYER_ENABLE_LOCAL_FALLBACK", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


async def run_remote(
    run_cmd: "RunCommand",
    job: "Job",
    broker: "BrokerAgent",
    queue: "AgentQueue",
) -> int:
    """Submit job to server and poll for status. CLI is a thin display client."""
    from shared.api_utils import get_api_url, get_token
    from shared.models import GPUType
    import httpx

    gpu_type = job.gpu_type
    command = run_cmd.command

    # Reject unsupported command shapes before upload.
    # The managed path uploads exactly one .py file to /workspace. Commands
    # that reference additional local files (second .py argument, local config
    # files, python -m module) would silently fail on the remote node because
    # only the single script is materialized there.
    _local_py_args = [
        arg for arg in command
        if Path(arg).suffix == ".py" and Path(arg).exists() and Path(arg).is_file()
    ]
    if len(_local_py_args) > 1:
        raise SystemExit(
            "vaultlayer run: the managed path supports exactly one local .py "
            "script per job, but multiple local .py files were detected in the "
            f"command: {_local_py_args}.\n"
            "Tip: refactor helper modules into your main script or use "
            "VAULTLAYER_DATASET_ID to ship a project bundle."
        )
    # Detect `python -m module` invocations — the module directory is not
    # uploaded, so the command would fail with ModuleNotFoundError on the node.
    _m_module = _python_module_invocation(command)
    if _m_module and _m_module not in _ALLOWED_REMOTE_MODULE_LAUNCHERS:
        # Check if it looks like a local module (no dots = top-level local)
        if "." not in _m_module or Path(_m_module.replace(".", "/")).exists():
            raise SystemExit(
                f"vaultlayer run: 'python -m {_m_module}' requires the module "
                "directory to be present on the remote node, but the managed "
                "path only uploads a single .py file.\n"
                "Tip: convert the module invocation to a direct script path "
                "(e.g. python train.py) or ship a project bundle."
            )

    # Read and encode the training script
    script_b64 = ""
    script_name = ""
    script_arg_index = None
    for idx, arg in enumerate(command):
        p = Path(arg)
        if p.exists() and p.is_file() and p.suffix == ".py":
            script_b64 = base64.b64encode(p.read_text().encode()).decode()
            script_name = p.name
            script_arg_index = idx
            break

    # Build the full quoted command so the server preserves launcher semantics
    # (torchrun, accelerate launch, python -u, flags, etc.). The script is
    # materialized on the node as its basename, so rewrite only that argv slot.
    server_command = list(command)
    if script_arg_index is not None:
        server_command[script_arg_index] = script_name
    script_args = " ".join(shlex.quote(a) for a in server_command)

    # Forward user env vars
    env = dict(job.environment or {})
    _FORWARD_PREFIXES = ("VL_USER_", "WANDB_", "HF_", "HUGGING_FACE_")
    _FORWARD_EXACT = {
        "MAX_STEPS", "NUM_EPOCHS", "BATCH_SIZE", "LEARNING_RATE", "SEED", "MODEL_NAME",
        "VAULTLAYER_DATASET_ID", "VAULTLAYER_DATASET_VERSION",
    }
    for k, v in os.environ.items():
        if k in _FORWARD_EXACT or any(k.startswith(p) for p in _FORWARD_PREFIXES):
            if k not in env:
                env[k] = v

    # Submit job to server
    api = get_api_url()
    token = get_token()
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    print(f"\n  Submitting job to server...")
    try:
        resp = httpx.post(f"{api}/api/v1/jobs/run", headers=headers, json={
            "gpu_type": gpu_type.value,
            "script_b64": script_b64,
            "script_name": script_name,
            "script_args": script_args,
            "environment": env,
            "docker_image": job.docker_image or "",
            "failover": job.failover_enabled,
            "preferred_providers": list(job.preferred_providers or []),
            "excluded_providers":  list(job.excluded_providers or []),
            "regions":             list(job.regions or []),
            "excluded_regions":    list(job.excluded_regions or []),
            "resume_from_job_id":   getattr(run_cmd, "resume_from_job_id", "")
                                    or getattr(job, "resume_from_job_id", "")
                                    or "",
            "min_vram_gb":         float(getattr(run_cmd, "min_vram_gb", 0)),
            "gpu_auto_selected":   bool(getattr(run_cmd, "gpu_auto_selected", False)),
            "dataset_id":          env.get("VAULTLAYER_DATASET_ID", ""),
        }, timeout=15)
        if resp.status_code == 400:
            # Validation error (unknown provider, empty-after-excludes, etc.) —
            # surface the detail and stop. No fallback makes sense here.
            try:
                _detail = resp.json().get("detail", resp.text[:200])
            except Exception:
                _detail = resp.text[:200]
            print(f"  Error: {_detail}")
            return 1
        if resp.status_code == 202:
            # Server couldn't find capacity within the filter — prompt the user
            # to widen the search. Returns the final exit code from the
            # consent flow (0 on success, 1 on decline/timeout).
            data = resp.json()
            return await _handle_expand_consent(
                api=api, headers=headers, data=data, job=job,
            )
        if resp.status_code != 200:
            print(f"  Error: Server returned {resp.status_code}: {resp.text[:200]}")
            if _local_fallback_enabled():
                print(f"  Local provisioning fallback enabled by VAULTLAYER_ENABLE_LOCAL_FALLBACK.")
                return await _run_remote_local_fallback(run_cmd, job, broker, queue)
            print("  Managed job submission failed. Not falling back to local provisioning.")
            print("  Retry later, or set VAULTLAYER_ENABLE_LOCAL_FALLBACK=1 only for explicit BYOC/self-hosted debugging.")
            return 1
        data = resp.json()
        job_id = data["job_id"]
        _email = getattr(run_cmd, "user_email", "")
        _who = f" ({_email})" if _email else ""
        print(f"  Job submitted{_who}")
        print(f"  Job ID: {job_id[:8]}...")  # short ID for vaultlayer ps lookup
    except Exception as e:
        print(f"  Error submitting to server: {e}")
        if _local_fallback_enabled():
            print(f"  Local provisioning fallback enabled by VAULTLAYER_ENABLE_LOCAL_FALLBACK.")
            return await _run_remote_local_fallback(run_cmd, job, broker, queue)
        print("  Managed job submission failed. Not falling back to local provisioning.")
        print("  Retry later, or set VAULTLAYER_ENABLE_LOCAL_FALLBACK=1 only for explicit BYOC/self-hosted debugging.")
        return 1

    # Poll for status + stream logs
    _last_status = ""
    _last_log_count = 0
    _start = time.monotonic()
    _last_periodic = 0      # monotonic time of last periodic update
    _queue_warned = False   # suppress repeat queue-timeout warnings

    print(f"  Waiting for GPU assignment...")
    sys.stdout.flush()

    while True:
        try:
            await asyncio.sleep(5)
        except (KeyboardInterrupt, asyncio.CancelledError):
            print(f"\n  Cancelling job...")
            try:
                httpx.post(
                    f"{api}/api/v1/jobs/{job_id}/cancel",
                    headers=headers, params={"reason": "user_request"}, timeout=5,
                )
            except BaseException:
                # Use BaseException (not Exception) — a second KeyboardInterrupt
                # can arrive during the synchronous cancel POST (signal on socket
                # read), and KeyboardInterrupt is not a subclass of Exception.
                # Swallowing it here lets the coroutine return cleanly so asyncio
                # doesn't log "Task exception was never retrieved".
                pass
            if _last_status in ("running", "provisioning"):
                print(f"  Job cancelled. Instance terminated.")
            else:
                print(f"  Job removed from queue. No instance was provisioned — no charge.")
            return 1

        # Fetch status
        try:
            sr = httpx.get(f"{api}/api/v1/jobs/{job_id}/status", headers=headers, timeout=8)
            if sr.status_code != 200:
                continue
            st = sr.json()
        except Exception:
            continue

        status = st.get("status", "unknown")
        elapsed = int(time.monotonic() - _start)

        # Print status changes
        if status != _last_status:
            if status == "queued":
                pos = st.get("queue_position", "?")
                _err = (st.get("error") or "").strip()
                if _err:
                    # Re-queued after a provision attempt — show the error reason
                    print(f"  [{elapsed}s] In queue (position #{pos}) — {_err}")
                else:
                    print(f"  Queued (position #{pos}). Waiting for GPU...")
            elif status == "provisioning":
                print(f"  Provisioning on {st.get('provider', '?')}...")
            elif status == "running":
                print(f"\n  Training on {st.get('provider', '?')}")
                print(f"  Instance: {st.get('instance_id', '?')}  |  Rate: ${st.get('price_per_hr', 0):.2f}/hr")
                print(f"\n  Training output:")
                print(f"  {'─' * 50}")
            elif status == "recovering":
                ckpt = st.get("checkpoint_step", "?")
                print(f"\n  ── Instance lost. Recovering from step {ckpt} ──")
                print(f"  Re-queued for GPU assignment...")
            elif status == "completed":
                duration = st.get("duration", 0)
                print(f"\n  {'─' * 50}")
                print(f"  Training completed successfully.")
                print(f"  Duration: {duration:.0f}s  |  Rate: ${st.get('price_per_hr', 0):.2f}/hr")
                return 0
            elif status == "failed":
                print(f"\n  {'─' * 50}")
                print(f"  Job failed: {st.get('error', 'unknown')}")
                return 1
            elif status == "cancelled":
                print(f"\n  Job cancelled.")
                return 1
            _last_status = status

        # Stream new log lines using server-side offset so large jobs (>500
        # lines) are not truncated. Previously fetched limit=500 from offset 0
        # and sliced lines[_last_log_count:] — any job with >500 total lines
        # produced an empty slice. Now we pass offset=_last_log_count so the
        # server returns only unseen lines, and advance the cursor by the
        # actual count returned (not the total count, which can skip ahead
        # past lines not yet delivered in a page).
        log_count = st.get("log_line_count", 0)
        if log_count > _last_log_count and status == "running":
            try:
                lr = httpx.get(f"{api}/api/v1/jobs/{job_id}/logs",
                              headers=headers,
                              params={"limit": 500, "offset": _last_log_count},
                              timeout=8)
                if lr.status_code == 200:
                    lines = lr.json().get("lines", [])
                    for line_data in lines:
                        line = line_data.get("line", str(line_data)) if isinstance(line_data, dict) else str(line_data)
                        print(f"  {line}")
                    sys.stdout.flush()
                    _last_log_count += len(lines)
            except Exception:
                pass

        # Exit immediately on terminal states even if status unchanged
        if status in ("failed", "cancelled", "completed") and status == _last_status:
            if status == "failed":
                print(f"\n  Job failed.")
            elif status == "cancelled":
                print(f"\n  Job cancelled.")
            return 0 if status == "completed" else 1

        # Periodic heartbeat every 30s so the terminal never looks frozen
        _now = time.monotonic()
        if _now - _last_periodic >= 30 and status in ("queued", "provisioning", "running"):
            mins, secs = divmod(elapsed, 60)
            _elapsed_str = f"{mins}m{secs:02d}s" if mins else f"{secs}s"
            if status == "queued":
                pos = st.get("queue_position", "?")
                _err = (st.get("error") or "").strip()
                if _err:
                    print(f"  [{_elapsed_str}] In queue (position #{pos}) — {_err}")
                else:
                    print(f"  [{_elapsed_str}] In queue (position #{pos}), waiting for GPU...")
            elif status == "provisioning":
                provider = st.get("provider", "?")
                print(f"  [{_elapsed_str}] Provisioning on {provider} (typically 1–3 min)...")
            else:
                print(f"  [{_elapsed_str}] Running — {log_count} log lines so far")
            _last_periodic = _now
            sys.stdout.flush()

        # Queue timeout warning: after 15 min still queued, nudge the user
        if not _queue_warned and status == "queued" and elapsed >= 900:
            gpu_hint = getattr(job, "gpu_type", None)
            gpu_str = gpu_hint.value if hasattr(gpu_hint, "value") else str(gpu_hint or "H100")
            print(f"\n  ⚠  No {gpu_str} found after 15 minutes.")
            print(f"  Options:")
            print(f"    • Press Ctrl+C to cancel (no charge) and retry with a different GPU:")
            print(f"        vaultlayer run --gpu A100_40GB python train.py ...")
            print(f"        vaultlayer run --gpu A100_80GB python train.py ...")
            print(f"    • Keep waiting — job will start automatically if capacity opens\n")
            _queue_warned = True
            sys.stdout.flush()


# ── Expand-consent prompt (HTTP 202 from /jobs/run) ──────────────────────────

CONSENT_TIMEOUT_SECONDS = 900  # 15 minutes — matches the spec's CLI-side timer


async def _handle_expand_consent(
    *, api: str, headers: dict, data: dict, job: "Job"
) -> int:
    """Block on stdin for the user to widen their --provider/--regions filter.

    The server has parked the job in `awaiting_expand_consent` because the
    initial filter yielded no candidates. We present the suggestion list, wait
    up to 15 minutes for input, and then either:
      - POST /expand-consent with the chosen widening (returns 200 → re-poll
        status; or 202 → recurse with new suggestions)
      - POST /cancel?reason=user_declined (Cancel option or Ctrl-C)
      - POST /cancel?reason=consent_timeout (no input within 900s)

    Returns the CLI exit code (0 if eventually provisioned, 1 otherwise).
    """
    import select
    import httpx as _httpx
    job_id = data["job_id"]
    suggestions = data.get("suggestions") or {}
    regions = (suggestions.get("add_regions") or {}).get("nearby") or []
    all_regions = (suggestions.get("add_regions") or {}).get("all") or []
    providers = (suggestions.get("add_providers") or {}).get("add") or []

    # Build the menu. Layout (numbers are the user-typed answer):
    #   1..R    = add nearby region R
    #   R+1     = add ALL routable regions
    #   R+2..   = add provider P
    #   final   = Cancel
    print(f"\n  Job {job_id} — no GPU capacity within your --provider/--regions filter.")
    print(f"  Pick an option below to widen the search (or [c] to cancel).")
    print("")
    options: list[tuple[str, dict]] = []  # (label, payload)
    n = 1
    for r in regions:
        print(f"    [{n}]  add region: {r}")
        options.append((f"add region {r}", {"add_regions": [r]}))
        n += 1
    if all_regions:
        print(f"    [{n}]  add ALL routable regions ({len(all_regions)} total)")
        options.append(("add ALL regions", {"add_regions": list(all_regions)}))
        n += 1
    for p in providers:
        print(f"    [{n}]  add provider: {p}")
        options.append((f"add provider {p}", {"add_providers": [p]}))
        n += 1
    print(f"    [c]  cancel job")
    print("")
    sys.stdout.flush()

    # 15-minute stdin block. select() handles the timeout; KeyboardInterrupt
    # falls through to the cancel path below.
    answer: Optional[str] = None
    try:
        ready, _, _ = select.select([sys.stdin], [], [], CONSENT_TIMEOUT_SECONDS)
        if ready:
            answer = sys.stdin.readline().strip().lower()
    except KeyboardInterrupt:
        answer = "c"

    if answer is None:
        # Timeout
        print(f"\n  No response within {CONSENT_TIMEOUT_SECONDS // 60} minutes — cancelling.")
        try:
            _httpx.post(
                f"{api}/api/v1/jobs/{job_id}/cancel",
                headers=headers, params={"reason": "consent_timeout"}, timeout=5,
            )
        except Exception:
            pass
        return 1

    if answer in ("c", "cancel", "no", "n"):
        print("\n  Cancelling job at user request.")
        try:
            _httpx.post(
                f"{api}/api/v1/jobs/{job_id}/cancel",
                headers=headers, params={"reason": "user_declined"}, timeout=5,
            )
        except Exception:
            pass
        return 1

    try:
        idx = int(answer) - 1
    except ValueError:
        print(f"\n  Unrecognised input '{answer}' — cancelling.")
        try:
            _httpx.post(
                f"{api}/api/v1/jobs/{job_id}/cancel",
                headers=headers, params={"reason": "user_declined"}, timeout=5,
            )
        except Exception:
            pass
        return 1

    if idx < 0 or idx >= len(options):
        print(f"\n  Choice {answer} out of range — cancelling.")
        try:
            _httpx.post(
                f"{api}/api/v1/jobs/{job_id}/cancel",
                headers=headers, params={"reason": "user_declined"}, timeout=5,
            )
        except Exception:
            pass
        return 1

    label, payload = options[idx]
    print(f"\n  Widening: {label}. Resubmitting...")
    try:
        cresp = _httpx.post(
            f"{api}/api/v1/jobs/{job_id}/expand-consent",
            headers=headers, json=payload, timeout=15,
        )
        if cresp.status_code == 202:
            # Still infeasible after widening — recurse with the fresh
            # suggestion payload.
            return await _handle_expand_consent(
                api=api, headers=headers, data=cresp.json(), job=job,
            )
        if cresp.status_code != 200:
            print(f"  expand-consent failed: {cresp.status_code} {cresp.text[:200]}")
            return 1
    except Exception as e:
        print(f"  expand-consent failed: {e}")
        return 1

    # Success: the job is now queued. Hand back to the normal poll loop by
    # re-entering run_remote's status loop — but we don't have direct access
    # to it here. Instead, we open a minimal poll loop for this job.
    print(f"  Job re-queued. Polling status...")
    sys.stdout.flush()
    return await _poll_until_terminal(api=api, headers=headers, job_id=job_id)


async def _poll_until_terminal(*, api: str, headers: dict, job_id: str) -> int:
    """Minimal poll loop used after expand-consent re-queues a job. Mirrors
    the terminal states from run_remote()'s main loop."""
    import httpx as _httpx
    last_status = ""
    while True:
        try:
            await asyncio.sleep(5)
        except (KeyboardInterrupt, asyncio.CancelledError):
            try:
                _httpx.post(
                    f"{api}/api/v1/jobs/{job_id}/cancel",
                    headers=headers, params={"reason": "user_request"}, timeout=5,
                )
            except Exception:
                pass
            print(f"\n  Job cancelled.")
            return 1
        try:
            sr = _httpx.get(f"{api}/api/v1/jobs/{job_id}/status", headers=headers, timeout=8)
            if sr.status_code != 200:
                continue
            st = sr.json()
        except Exception:
            continue
        status = st.get("status", "unknown")
        if status != last_status:
            print(f"  Status: {status}")
            sys.stdout.flush()
            last_status = status
        if status == "completed":
            return 0
        if status in ("failed", "cancelled"):
            err = st.get("error") or st.get("cancel_reason") or ""
            if err:
                print(f"  {err}")
            return 1


# ── Local fallback (old run_remote logic) ────────────────────────────────────

async def _run_remote_local_fallback(
    run_cmd: "RunCommand",
    job: "Job",
    broker: "BrokerAgent",
    queue: "AgentQueue",
) -> int:
    """
    Provision a remote GPU, upload script, run training, stream logs.
    Automatically recovers on instance death: finds checkpoint in R2,
    provisions a new node on a different provider, resumes training.
    Returns exit code (0 = success).

    This is the original run_remote logic, kept only for explicit
    VAULTLAYER_ENABLE_LOCAL_FALLBACK=1 BYOC/self-hosted debugging.
    """
    from shared.models import Provider, GPUType
    from shared.data_loader import get_provider_prices, resolve_gpu_key, is_gpu_available

    gpu_type = job.gpu_type
    command = run_cmd.command

    # Suppress noisy broker/pricing warnings (expected: no local provider config)
    from shared.logging_utils import setup_cli_logging
    setup_cli_logging()

    # ── Step 1: Find best GPU across all providers ────────────────────────
    # Search ALL providers for the requested GPU, then fall back to alternatives
    print(f"\n  Finding best option for {gpu_type.value}...")

    _gpu_key = resolve_gpu_key(gpu_type.value)
    prices = get_provider_prices()
    from shared.data_loader import get_instance_string

    # Build candidate list: (provider_name, gpu_key, price, is_exact_match)
    # No static instance string gate — let the actual provision call determine availability.
    # Dynamic providers (Vast.ai, RunPod) do fuzzy GPU matching at provision time.
    candidates = []
    for provider_name, gpu_prices in prices.items():
        if provider_name.startswith("_") or "Reserved" in provider_name or "On-Demand" in provider_name:
            continue
        for gk, price in gpu_prices.items():
            if not isinstance(price, (int, float)) or price <= 0:
                continue
            is_exact = (gk == _gpu_key)
            candidates.append((provider_name, gk, price, is_exact))

    # Sort: exact matches first (by price), then alternatives (by price)
    candidates.sort(key=lambda x: (0 if x[3] else 1, x[2]))

    if not candidates:
        print(f"  Error: No GPU available on any provider.")
        return 1

    # Show what we found
    exact_matches = [c for c in candidates if c[3]]
    if exact_matches:
        print(f"  {gpu_type.value} available on {len(exact_matches)} providers (cheapest: ${exact_matches[0][2]:.2f}/hr)")
    else:
        # No exact match — suggest best alternative
        best_alt = candidates[0]
        print(f"  {gpu_type.value} not available on any provider.")
        print(f"  Best alternative: {best_alt[1]} on {best_alt[0]} at ${best_alt[2]:.2f}/hr")
        # Update GPU type to the alternative
        try:
            gpu_type = GPUType(best_alt[1]) if best_alt[1] in [g.value for g in GPUType] else gpu_type
        except ValueError:
            pass

    # Map provider display names to Provider enum
    _PROVIDER_MAP = {
        "Lambda Labs": Provider.LAMBDA_LABS,
        "RunPod": Provider.RUNPOD,
        "Vast.ai": Provider.VAST_AI,
        "CoreWeave": Provider.COREWEAVE,
        "Crusoe": Provider.CRUSOE,
        "Hyperstack": Provider.HYPERSTACK,
        "Voltage Park": Provider.VOLTAGE_PARK,
        "Nebius (EU)": Provider.NEBIUS,
        "AWS Spot": Provider.AWS,
    }

    # Map Provider enum to provision method name
    _PROVISION_FN = {
        Provider.LAMBDA_LABS: "provision_lambda",
        Provider.RUNPOD: "provision_runpod",
        Provider.VAST_AI: "provision_vast",
        Provider.COREWEAVE: "provision_coreweave",
        Provider.AWS: "provision_aws",
        Provider.GCP: "provision_gcp",
        Provider.AZURE: "provision_azure",
        Provider.CRUSOE: "provision_crusoe",
        Provider.NEBIUS: "provision_nebius",
        Provider.HYPERSTACK: "provision_hyperstack",
        Provider.VOLTAGE_PARK: "provision_voltage_park",
    }

    # ── Step 2: Embed training script in job environment ──────────────────
    # Find the script file in the command
    script_content = None
    script_name = None
    for arg in command:
        p = Path(arg)
        if p.exists() and p.is_file() and p.suffix == ".py":
            script_content = p.read_text()
            script_name = p.name
            break

    if script_content:
        # Encode script as base64 env var — onstart decodes it
        encoded = base64.b64encode(script_content.encode()).decode()
        job.environment = job.environment or {}
        job.environment["VL_SCRIPT_B64"] = encoded
        job.environment["VL_SCRIPT_NAME"] = script_name
        job.command = f"python /workspace/{script_name}"

        # Checkpoint helper is embedded in the onstart script (NOT as env var
        # — Vast.ai has a 32KB env var limit and the helper is ~24KB)

    # Forward user-defined env vars to the container (training hyperparams etc.)
    # Anything prefixed with VL_USER_ or common training vars gets forwarded
    _FORWARD_PREFIXES = ("VL_USER_", "WANDB_", "HF_", "HUGGING_FACE_")
    _FORWARD_EXACT = {"MAX_STEPS", "NUM_EPOCHS", "BATCH_SIZE", "LEARNING_RATE",
                      "GRADIENT_ACCUMULATION_STEPS", "SEED", "MODEL_NAME"}
    job.environment = job.environment or {}
    for k, v in os.environ.items():
        if k in _FORWARD_EXACT or any(k.startswith(p) for p in _FORWARD_PREFIXES):
            if k not in job.environment:  # don't override VL-set vars
                job.environment[k] = v

    # R2 credentials for checkpoint sentinel checks
    from shared.r2_utils import get_r2_credentials
    _r2 = get_r2_credentials(job.job_id)
    _r2_endpoint = _r2.get("endpoint", "")
    _r2_key = _r2.get("access_key_id", "")
    _r2_secret = _r2.get("secret_access_key", "")
    _r2_bucket = _r2.get("bucket", "vaultlayer-checkpoints")

    # Inject R2 credentials into broker config so onstart script includes them
    if _r2_endpoint and _r2_key and _r2_secret:
        from shared.config import CloudflareConfig
        if not broker.config.cloudflare:
            broker.config.cloudflare = CloudflareConfig(
                account_id=os.environ.get("CLOUDFLARE_ACCOUNT_ID", "managed"),
                r2_access_key_id=_r2_key,
                r2_secret_access_key=_r2_secret,
                r2_bucket=_r2_bucket or "vaultlayer-checkpoints",
                r2_endpoint=_r2_endpoint,
                cf_master_token="",
            )

    # ── Recovery loop — provision, run, recover on failure ──────────────
    MAX_RECOVERY_ATTEMPTS = 3
    excluded_providers: set = set()
    resume_step: int | None = None
    attempt = 0

    while attempt <= MAX_RECOVERY_ATTEMPTS:
        if attempt > 0:
            print(f"\n  ── Recovery attempt {attempt}/{MAX_RECOVERY_ATTEMPTS} ──")
            print(f"  Resuming from checkpoint step {resume_step}")
            sys.stdout.flush()

        # ── Provision — cheapest first, exclude failed providers ─────────
        instance_id = None
        actual_provider = None
        actual_price = 0.0
        actual_gpu_key = _gpu_key

        # ── Server-side provisioning via queue ────────────────────────────
        # CLI submits to the API queue. Server broker provisions FIFO.
        # CLI polls for result. No provider API calls from the CLI.
        from shared.api_utils import get_token as _qt, get_api_url as _qa
        import httpx as _qh

        _excluded_list = [p.value for p in excluded_providers] if excluded_providers else []
        print(f"  Submitting to GPU queue...", end="", flush=True)

        try:
            _qr = _qh.post(f"{_qa()}/api/v1/jobs/{job.job_id}/queue",
                     headers={"Authorization": f"Bearer {_qt()}"},
                     json={
                         "gpu_type": gpu_type.value,
                         "docker_image": job.docker_image or "",
                         "environment": job.environment or {},
                         "failover": job.failover_enabled,
                         "excluded_providers": _excluded_list,
                     },
                     timeout=8)
            if _qr.status_code == 200:
                _qd = _qr.json()
                _pos = _qd.get("position", 1)
                if _qd.get("status") == "provisioned":
                    # Already provisioned (from a previous attempt)
                    instance_id = _qd.get("instance_id")
                    actual_provider_str = _qd.get("provider", "")
                    actual_price = _qd.get("price_per_hr", 0)
                    actual_gpu_key = _qd.get("gpu_type", _gpu_key)
                    print(f" already provisioned: {actual_provider_str} ({instance_id})")
                else:
                    if _pos > 1:
                        print(f" queued (position #{_pos}, {_pos - 1} job(s) ahead)")
                    else:
                        print(f" queued (position #1)")
            else:
                print(f" queue API unavailable, trying locally...")
                # Fallback: try provisioning directly from CLI
                # (This keeps backward compatibility if the API queue isn't deployed)
                for provider_name, gk, price, is_exact in candidates[:5]:
                    provider_enum = _PROVIDER_MAP.get(provider_name)
                    if not provider_enum or provider_enum in excluded_providers:
                        continue
                    fn_name = _PROVISION_FN.get(provider_enum)
                    fn = getattr(broker, fn_name, None) if fn_name else None
                    if not fn:
                        continue
                    try:
                        _cg = GPUType(gk) if gk in [g.value for g in GPUType] else gpu_type
                    except ValueError:
                        _cg = gpu_type
                    try:
                        instance_id = await fn(_cg, job)
                    except Exception:
                        instance_id = None
                    if instance_id:
                        actual_provider = provider_enum
                        actual_price = price
                        actual_gpu_key = gk
                        break
        except Exception as _qe:
            logger.warning(f"Queue submission failed: {_qe}")
            print(f" failed ({_qe})")

        # ── Poll for server-side provisioning result ─────────────────────
        if not instance_id:
            _QUEUE_POLL = 10 if attempt > 0 else 15  # Faster for recovery
            _queue_start = time.monotonic()
            print(f"  Waiting for GPU assignment (server is provisioning)...")
            print(f"  Press Ctrl+C to cancel.\n")
            sys.stdout.flush()

            while True:
                try:
                    await asyncio.sleep(_QUEUE_POLL)
                except (KeyboardInterrupt, asyncio.CancelledError):
                    print(f"\n  Cancelled by user.")
                    try:
                        _qh.delete(f"{_qa()}/api/v1/jobs/{job.job_id}/queue",
                                   headers={"Authorization": f"Bearer {_qt()}"}, timeout=5)
                    except Exception:
                        pass
                    return 1

                _elapsed_q = int(time.monotonic() - _queue_start)
                _min = _elapsed_q // 60

                # Poll for result
                try:
                    _sr = _qh.get(f"{_qa()}/api/v1/jobs/{job.job_id}/queue-status",
                                  headers={"Authorization": f"Bearer {_qt()}"}, timeout=8)
                    if _sr.status_code == 200:
                        _sd = _sr.json()
                        if _sd.get("status") == "provisioned":
                            instance_id = _sd["instance_id"]
                            actual_provider_str = _sd.get("provider", "")
                            actual_price = _sd.get("price_per_hr", 0)
                            actual_gpu_key = _sd.get("gpu_type", _gpu_key)
                            # Map provider string to enum
                            _rev_map = {v.value: v for v in Provider}
                            for _pname, _penum in _PROVIDER_MAP.items():
                                if _pname == actual_provider_str:
                                    actual_provider = _penum
                                    break
                            print(f"  [{_min}m] GPU assigned: {actual_provider_str} at ${actual_price:.2f}/hr ({instance_id})")
                            break
                        elif _sd.get("status") == "queued":
                            _pos = _sd.get("position", "?")
                            _qs = _sd.get("queue_size", "?")
                            if _elapsed_q % 60 < _QUEUE_POLL:  # Print once per minute
                                print(f"  [{_min}m] Waiting for GPU... (position #{_pos}/{_qs})")
                except Exception:
                    if _elapsed_q % 60 < _QUEUE_POLL:
                        print(f"  [{_min}m] Waiting for GPU...")

        # If resuming, inject checkpoint path into environment
        if resume_step is not None:
            job.environment = job.environment or {}
            job.environment["VAULTLAYER_RESUME_CHECKPOINT"] = (
                f"/mnt/vaultlayer/checkpoints/{job.job_id}"
            )

        # Update job with actual provisioned GPU
        try:
            actual_gpu_enum = GPUType(actual_gpu_key)
            job.gpu_type = actual_gpu_enum
        except ValueError:
            pass

        job.instance_id = instance_id
        job.provider = actual_provider
        job.current_hourly_rate = actual_price
        _leg_start = time.monotonic()

        # Record spend for this leg
        try:
            broker._record_provision_spend(
                job=job, provider=actual_provider.value, gpu_type=gpu_type.value,
                instance_id=instance_id, provisioned_at=datetime.utcnow(),
                rate_per_hr=actual_price, is_hop_leg=(attempt > 0),
                migrated_from_run_id=getattr(broker, '_run_ids', {}).get(job.instance_id) if attempt > 0 else None,
            )
        except Exception as e:
            logger.warning(f"[remote] Spend recording failed (non-fatal): {e}")

        # Create jobs row via API (first attempt only)
        if attempt == 0:
            try:
                import httpx as _jobs_httpx
                from shared.api_utils import get_token as _get_token, get_api_url as _get_api_url
                _token = _get_token()
                _api = _get_api_url()
                _jobs_httpx.post(f"{_api}/api/v1/jobs/start",
                    headers={"Authorization": f"Bearer {_token}"},
                    json={"job_id": job.job_id, "gpu_type": gpu_type.value,
                          "hourly_rate_usd": actual_price, "estimated_hours": 1}, timeout=8)
            except Exception:
                pass

        await queue.set_job_state(job.job_id, job.model_dump(mode="json"))

        # Close broker's aiohttp session
        try:
            if hasattr(broker, '_http_session') and broker._http_session:
                if not broker._http_session.closed:
                    await broker._http_session.close()
                broker._http_session = None
        except Exception:
            pass

        # ── Wait + stream logs ────────────────────────────────────────────
        _leg_label = f"Leg {attempt + 1}" if attempt > 0 else "Training"
        print(f"\n  {_leg_label} on {actual_provider.value}")
        print(f"  Instance: {instance_id}  |  Rate: ${actual_price:.2f}/hr")
        if resume_step:
            print(f"  Resuming from checkpoint step {resume_step}")
        print(f"  Waiting for training to start...")
        sys.stdout.flush()
        await asyncio.sleep(10)

        print(f"\n  Training output:")
        print(f"  {'─' * 50}")
        sys.stdout.flush()

        # Fetch provider API key for log streaming
        _api_key = None
        try:
            _managed = await broker._get_managed_credentials(
                actual_provider.value.replace("_", " ").lower().replace(" ", "_"), job.job_id)
            if _managed:
                _api_key = _managed.get("api_key", "")
            if hasattr(broker, '_http_session') and broker._http_session:
                if not broker._http_session.closed:
                    await broker._http_session.close()
                broker._http_session = None
        except Exception:
            pass

        _log_kwargs = dict(job_id=job.job_id, r2_endpoint=_r2_endpoint, r2_key=_r2_key,
                           r2_secret=_r2_secret, r2_bucket=_r2_bucket)

        _fetch_and_print_logs_sync(actual_provider, instance_id, _api_key or "", 0, **_log_kwargs)
        sys.stdout.flush()

        exit_code, reason = await _poll_remote_job(
            job, queue, broker, actual_provider, instance_id, api_key=_api_key,
            log_kwargs=_log_kwargs,
        )

        _leg_elapsed = time.monotonic() - _leg_start

        # ── Terminate + settle ────────────────────────────────────────────
        print(f"\n  Terminating instance {instance_id}...")
        _FENCE_FN = {
            Provider.LAMBDA_LABS: "_hard_fence_lambda", Provider.RUNPOD: "_hard_fence_runpod",
            Provider.VAST_AI: "_hard_fence_vast_ai", Provider.AWS: "_hard_fence_aws",
            Provider.GCP: "_hard_fence_gcp", Provider.AZURE: "_hard_fence_azure",
            Provider.CRUSOE: "_hard_fence_crusoe", Provider.NEBIUS: "_hard_fence_nebius",
            Provider.HYPERSTACK: "_hard_fence_hyperstack", Provider.VOLTAGE_PARK: "_hard_fence_voltage_park",
            Provider.COREWEAVE: "_hard_fence_coreweave",
        }
        # Track fence success so settle_instance only marks
        # termination_confirmed=True when the provider actually confirmed
        # the instance is gone. AWS / GCP / Azure hard_fence takes a
        # second `job` argument; the rest take only instance_id. Try
        # 2-arg first, fall back to 1-arg on TypeError.
        _fence_success = False
        try:
            fence_fn = getattr(broker, _FENCE_FN.get(actual_provider, ""), None)
            if fence_fn:
                try:
                    await fence_fn(instance_id, job)
                except TypeError:
                    await fence_fn(instance_id)
                _fence_success = True
                print("  Instance terminated. Billing stopped.")
        except Exception as e:
            print(f"  Warning: Could not terminate: {e}")

        # Settle spend for this leg
        try:
            _terminated_at = datetime.utcnow()
            _spend_id = getattr(broker, '_spend_ids', {}).get(instance_id)
            if _spend_id:
                from shared.spend import settle_instance
                settle_instance(_spend_id, _terminated_at, termination_confirmed=_fence_success)
            _run_id = getattr(broker, '_run_ids', {}).get(instance_id)
            if _run_id:
                from shared.job_run_logger import close_run, compute_billing
                _prov_at = getattr(broker, '_provision_info', {}).get(instance_id, {}).get("provisioned_at", _terminated_at)
                billing_s, cost_usd, uc_usd, credits = compute_billing(_prov_at, _terminated_at, rate_per_hr=actual_price)
                close_run(_run_id, terminated_at=_terminated_at, billing_seconds=billing_s,
                          rate_per_hr=actual_price, estimated_cost_usd=cost_usd,
                          user_charged_usd=uc_usd, credits_charged=credits, run_duration_seconds=billing_s,
                          termination_confirmed=_fence_success)
        except Exception as e:
            logger.warning(f"[remote] Spend settlement failed (non-fatal): {e}")

        print(f"  Leg duration: {_leg_elapsed:.0f}s")

        # ── Recovery decision ─────────────────────────────────────────────
        if reason == "completed":
            return exit_code

        if reason == "instance_lost" and job.failover_enabled:
            # Check R2 for latest checkpoint
            ckpt = _find_checkpoint_in_r2(job.job_id, _r2_endpoint, _r2_key, _r2_secret, _r2_bucket)
            if ckpt:
                print(f"\n  Checkpoint found in R2: step {ckpt['step']} ({ckpt['size_label']})")
                print(f"  Recovering on a different provider...")
                sys.stdout.flush()
                excluded_providers.add(actual_provider)
                resume_step = ckpt["step"]
                attempt += 1
                continue
            else:
                print(f"\n  No checkpoint found in R2. Cannot recover.")
                return 1

        if reason == "instance_lost" and not job.failover_enabled:
            print(f"\n  Instance lost. Failover disabled (--no-failover).")
            print(f"  Checkpoint may be available: vaultlayer restart --job-id {job.job_id}")
            return 1

        return exit_code

    print(f"\n  Max recovery attempts ({MAX_RECOVERY_ATTEMPTS}) reached.")
    return 1


async def _poll_remote_job(
    job: "Job",
    queue: "AgentQueue",
    broker: "BrokerAgent",
    provider: "Provider",
    instance_id: str,
    poll_interval: int = 5,
    max_wait: int = 3600,
    api_key: str = "",
    log_kwargs: dict = None,
) -> int:
    """
    Poll for job completion on the remote node.
    Returns (exit_code, reason) where reason is one of:
      "completed" — training finished normally (_COMPLETED sentinel found or clean exit)
      "instance_lost" — instance died without completion (spot kill, OOM, etc.)
      "timeout" — max_wait exceeded, job may still be running
    """
    import httpx

    start = time.monotonic()
    _log_kwargs = log_kwargs or {}
    _last_log_lines = 0
    _log_fetch_interval = 10

    _sentinel_check_interval = 15  # Check R2 sentinel every 15s
    _last_sentinel_check = 0
    _fetch_and_print_logs_sync.completed = False  # Reset completion flag
    _last_new_log_time = 0  # Track when we last saw new log output

    while time.monotonic() - start < max_wait:
        elapsed = int(time.monotonic() - start)

        # Check: Instance still running?
        try:
            alive = _check_instance_alive_sync(provider, instance_id, api_key)
            if not alive:
                # Instance gone — check if training completed or was killed
                await asyncio.sleep(3)
                # Try to fetch final logs
                for _retry in range(3):
                    _new = _fetch_and_print_logs_sync(provider, instance_id, api_key, _last_log_lines, **_log_kwargs)
                    if _new > _last_log_lines:
                        _last_log_lines = _new
                        break
                    await asyncio.sleep(2)

                # Wait for rclone copy / FUSE flush before checking R2 sentinel
                await asyncio.sleep(8)

                # Check for _COMPLETED sentinel in R2
                _completed = _check_completed_sentinel(
                    _log_kwargs.get("job_id", ""),
                    _log_kwargs.get("r2_endpoint", ""),
                    _log_kwargs.get("r2_key", ""),
                    _log_kwargs.get("r2_secret", ""),
                    _log_kwargs.get("r2_bucket", ""),
                )

                print(f"\n  {'─' * 50}")
                sys.stdout.flush()
                if _completed:
                    print("  Training completed successfully.")
                    return 0, "completed"
                else:
                    print("  Instance lost (spot reclaim or failure).")
                    return 1, "instance_lost"
        except Exception:
            pass

        # Periodically check R2 sentinel (training may finish while container stays alive)
        if elapsed - _last_sentinel_check >= _sentinel_check_interval and elapsed > 30:
            _last_sentinel_check = elapsed
            _completed = _check_completed_sentinel(
                _log_kwargs.get("job_id", ""),
                _log_kwargs.get("r2_endpoint", ""),
                _log_kwargs.get("r2_key", ""),
                _log_kwargs.get("r2_secret", ""),
                _log_kwargs.get("r2_bucket", ""),
            )
            if _completed:
                # Fetch final logs
                _fetch_and_print_logs_sync(provider, instance_id, api_key, _last_log_lines, **_log_kwargs)
                print(f"\n  {'─' * 50}")
                print("  Training completed successfully.")
                sys.stdout.flush()
                return 0, "completed"

        # Fetch and stream logs periodically
        if elapsed > 0 and elapsed % _log_fetch_interval == 0:
            _prev_lines = _last_log_lines
            _last_log_lines = _fetch_and_print_logs_sync(provider, instance_id, api_key, _last_log_lines, **_log_kwargs)
            if _last_log_lines > _prev_lines:
                _last_new_log_time = elapsed  # Got new output
            sys.stdout.flush()
            # Check if completion was detected in logs
            if getattr(_fetch_and_print_logs_sync, 'completed', False):
                print(f"\n  {'─' * 50}")
                print("  Training completed successfully.")
                sys.stdout.flush()
                return 0, "completed"

        # Print periodic status with last log line count
        if elapsed > 0 and elapsed % 60 == 0:
            _no_new = elapsed - _last_new_log_time if _last_log_lines > 0 else 0
            _status = f"  ... running ({elapsed}s, {_last_log_lines} log lines"
            if _no_new > 300:
                _status += f", WARNING: no new output for {_no_new}s"
            _status += ")"
            print(_status)
            sys.stdout.flush()

        # Stall detection: if no new logs for 10 min, warn
        if _last_log_lines > 0 and elapsed - _last_new_log_time > 600:
            print(f"\n  No new training output for 10 minutes.")
            print(f"  Job may be stalled. Check: vaultlayer logs --job-id {_log_kwargs.get('job_id', '')}")
            sys.stdout.flush()
            _last_new_log_time = elapsed  # Reset to avoid spamming

        await asyncio.sleep(poll_interval)

    print(f"\n  {'─' * 50}")
    print(f"  Still running after {max_wait}s. Job continues remotely.")
    return 0, "timeout"


_COMPLETION_MARKERS = {"[VaultLayer] Training finished (exit 0)"}


def _fetch_and_print_logs_sync(provider, instance_id: str, api_key: str, skip_lines: int = 0,
                                job_id: str = "", r2_endpoint: str = "", r2_key: str = "",
                                r2_secret: str = "", r2_bucket: str = "") -> int:
    """Fetch logs from R2 (persistent) or provider API (live). Returns total lines seen.
    Sets _fetch_and_print_logs_sync.completed = True if completion marker is found."""
    import httpx

    # Try Railway API first -- container POSTs logs to /api/v1/jobs/{id}/logs
    if job_id:
        try:
            from shared.api_utils import get_token as _get_token, get_api_url as _get_api_url
            _token = _get_token()
            _api = _get_api_url()
            if _token:
                resp = httpx.get(
                    f"{_api}/api/v1/jobs/{job_id}/logs",
                    headers={"Authorization": f"Bearer {_token}"},
                    params={"limit": 500},
                    timeout=8,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    lines = [r.get("line", "") if isinstance(r, dict) else str(r)
                             for r in (data.get("lines", []) if isinstance(data, dict) else data)]
                    for line in lines[skip_lines:]:
                        print(f"  {line}")
                        if any(m in line for m in _COMPLETION_MARKERS):
                            _fetch_and_print_logs_sync.completed = True
                    sys.stdout.flush()
                    if len(lines) > skip_lines:
                        return len(lines)
        except Exception:
            pass  # API not available, fall through to provider API

    # Fallback: provider-specific log API (only works while instance is alive)
    from cli.remote_providers import fetch_logs_from_provider
    total_lines, completed = fetch_logs_from_provider(provider, instance_id, api_key, skip_lines)
    if completed:
        _fetch_and_print_logs_sync.completed = True
    return total_lines


def _check_instance_alive_sync(provider, instance_id: str, api_key: str) -> bool:
    """Check instance status using httpx (synchronous). Returns False if terminated."""
    from cli.remote_providers import check_instance_alive
    return check_instance_alive(provider, instance_id, api_key)


def _check_completed_sentinel(job_id: str, r2_endpoint: str, r2_key: str,
                               r2_secret: str, r2_bucket: str) -> bool:
    """Check if training finished — tries API events first, then R2 sentinel."""
    if not job_id:
        return False

    # Method 1: Check API for completion event (fastest, most reliable)
    try:
        import httpx
        from shared.api_utils import get_token as _get_token, get_api_url as _get_api_url
        _token = _get_token()
        _api = _get_api_url()
        if _token:
            resp = httpx.get(
                f"{_api}/api/v1/jobs/{job_id}/logs",
                headers={"Authorization": f"Bearer {_token}"},
                params={"limit": 5},
                timeout=5,
            )
            if resp.status_code == 200:
                data = resp.json()
                lines = data.get("lines", [])
                # Check if logs contain completion marker
                for line in lines:
                    if "[VaultLayer] Training finished (exit 0)" in str(line):
                        return True
    except Exception:
        pass

    # Method 2: Check R2 sentinel
    if all([r2_endpoint, r2_key, r2_secret, r2_bucket]):
        try:
            import boto3
            s3 = boto3.client("s3", endpoint_url=r2_endpoint,
                              aws_access_key_id=r2_key, aws_secret_access_key=r2_secret)
            s3.head_object(Bucket=r2_bucket, Key=f"checkpoints/{job_id}/_COMPLETED")
            return True
        except Exception:
            pass

    return False


def _find_checkpoint_in_r2(job_id: str, r2_endpoint: str, r2_key: str,
                            r2_secret: str, r2_bucket: str) -> dict | None:
    """Find the latest valid checkpoint in R2. Returns {"step": N, "prefix": "..."} or None."""
    if not all([job_id, r2_endpoint, r2_key, r2_secret, r2_bucket]):
        return None
    try:
        import boto3
        s3 = boto3.client("s3", endpoint_url=r2_endpoint,
                          aws_access_key_id=r2_key, aws_secret_access_key=r2_secret)

        prefix = f"checkpoints/{job_id}/"
        resp = s3.list_objects_v2(Bucket=r2_bucket, Prefix=prefix, Delimiter="/")
        prefixes = resp.get("CommonPrefixes", [])
        if not prefixes:
            return None

        # Parse step numbers from both checkpoint formats:
        #   HF canonical: checkpoint-<N>/   (SFTTrainer, Trainer, Lightning)
        #   Raw PyTorch:  step-<N>/         (vaultlayer_checkpoint.py)
        # The server worker (_find_checkpoint) recognises both; this CLI fallback
        # previously only handled step-<N>/ causing "no checkpoint found" on HF jobs.
        steps: dict[int, str] = {}  # step → dir prefix
        for p in prefixes:
            dirname = p["Prefix"].rstrip("/").split("/")[-1]
            if dirname.startswith("checkpoint-"):
                try:
                    step = int(dirname.split("-", 1)[1])
                    steps[step] = p["Prefix"]
                except ValueError:
                    pass
            elif dirname.startswith("step-"):
                try:
                    step = int(dirname.split("-", 1)[1])
                    steps[step] = p["Prefix"]
                except ValueError:
                    pass

        if not steps:
            return None

        latest_step = max(steps)
        step_prefix = steps[latest_step]

        # Estimate checkpoint size
        size_resp = s3.list_objects_v2(Bucket=r2_bucket, Prefix=step_prefix)
        total_bytes = sum(obj.get("Size", 0) for obj in size_resp.get("Contents", []))
        size_mb = total_bytes / (1024 * 1024)
        size_label = f"{size_mb:.0f} MB" if size_mb < 1024 else f"{size_mb / 1024:.1f} GB"

        return {"step": latest_step, "prefix": step_prefix, "size_bytes": total_bytes, "size_label": size_label}
    except Exception as e:
        logger.debug(f"[remote] R2 checkpoint lookup failed: {e}")
        return None
