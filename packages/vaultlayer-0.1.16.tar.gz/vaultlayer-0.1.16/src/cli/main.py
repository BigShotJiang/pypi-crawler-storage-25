"""
VaultLayer CLI -- entry point for the 'vaultlayer' command.
pip install vaultlayer  ->  vaultlayer init  ->  vaultlayer run python train.py
"""
import asyncio
import logging
import sys
from pathlib import Path

import click

logging.basicConfig(
    level=logging.WARNING,  # suppress noise in CLI output
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)


@click.group()

@click.version_option(version="0.1.16", prog_name="vaultlayer")

def cli():
    """VaultLayer -- AI compute arbitrage. Train anywhere, reliably, cheaply."""
    pass


@cli.command()
@click.option("--token", envvar="VAULTLAYER_TOKEN", default=None,
              help="Your VaultLayer API token (or set VAULTLAYER_TOKEN env var)")
@click.option("--reauth", is_flag=True, default=False,
              help="Force re-authentication even if a token is already stored")
@click.option("--output-dir", default=".", show_default=True,
              help="Directory to write vaultlayer_checkpoint.py (default: current dir)")
def init(token, reauth, output_dir):
    """Authenticate with VaultLayer and generate the checkpoint helper."""
    import httpx

    cfg_dir = Path.home() / ".vaultlayer"
    cfg_dir.mkdir(mode=0o700, exist_ok=True)
    config_env = cfg_dir / "config.env"
    api_url = _api_url()

    # ── Resolve token ─────────────────────────────────────────────────────────
    # Click reads --token from env var VAULTLAYER_TOKEN if not passed on CLI.
    # When --reauth is set, we want to ignore stored tokens but respect
    # explicitly passed --token values. Check if token matches stored value
    # to distinguish "from env/config" vs "explicitly passed".
    if reauth and token:
        stored = _read_token_from_config_env(config_env)
        if token == stored:
            token = None  # came from config, not CLI — clear it for re-auth

    if not token and not reauth:
        # Try existing config.env first
        stored = _read_token_from_config_env(config_env)
        if stored:
            token = stored
        else:
            old_token_file = cfg_dir / "token"
            if old_token_file.exists():
                token = old_token_file.read_text().strip()

    if not token:
        click.echo("")
        if reauth:
            # --reauth: user already had a token but wants to replace it.
            # Option 1: paste a new token directly (e.g. admin issued one manually).
            # Option 3: rotate — server generates a fresh token and revokes the old one.
            # Signup is hidden — VaultLayer is invite-only, no self-serve signup.
            choice = click.prompt(
                "  Do you have a VaultLayer token?\n"
                "  [1] Yes — paste my token\n"
                "  [2] No — request a new token\n\n"
                "  Choose",
                type=click.Choice(["1", "2"]),
            )
            if choice == "2":
                # Rotate: need the old token to authenticate the rotation request.
                stored = _read_token_from_config_env(cfg_dir / "config.env")
                old_token = stored
                if not old_token:
                    old_token_file = cfg_dir / "token"
                    if old_token_file.exists():
                        old_token = old_token_file.read_text().strip()
                if not old_token:
                    click.echo("")
                    click.echo("  No stored token found — cannot rotate without an existing token.")
                    click.echo("  Paste your current token first:  vaultlayer init")
                    raise SystemExit(1)
                click.echo("")
                click.echo("  Rotating token...")
                try:
                    import httpx as _httpx
                    resp = _httpx.post(
                        f"{api_url}/api/v1/auth/rotate-token",
                        json={"token": old_token},
                        timeout=15,
                    )
                    if resp.status_code == 401:
                        click.echo("  Current token is already revoked or not recognised.")
                        click.echo("  Ask your VaultLayer admin for a fresh invite token.")
                        raise SystemExit(1)
                    resp.raise_for_status()
                    data = resp.json()
                except _httpx.HTTPStatusError as e:
                    click.echo(f"  API error ({e.response.status_code}). Try again later.")
                    raise SystemExit(1)
                except _httpx.HTTPError as e:
                    click.echo(f"  Could not reach VaultLayer API: {e}")
                    raise SystemExit(1)
                token = data["token"]
                click.echo(f"  ✓ New token issued for {data.get('email', '')}")
                click.echo(f"    Old token has been revoked.")
                click.echo("")
            else:
                click.echo("")
                token = click.prompt("  Enter your VaultLayer token", hide_input=True)
        else:
            # Plain `vaultlayer init` with no stored token — invite-only onboarding.
            # Just ask for the token; no signup/login menu.
            click.echo("  Enter the token you received from VaultLayer.")
            click.echo("  (Don't have one? Request access at vaultlayer.com)")
            click.echo("")
            token = click.prompt("  VaultLayer token", hide_input=True)

    token = token.strip()

    # ── Invite-token redemption path (closed-beta onboarding) ─────────────────
    # When the user pastes a vl_invite_... token (emailed manually by the admin
    # after they're allowlisted), redeem it once to get a long-lived
    # vl_live_... token. Afterward the flow is identical to a returning user.
    if token.startswith("vl_invite_"):
        try:
            resp = httpx.post(
                f"{api_url}/api/v1/auth/redeem-invite",
                json={"invite_token": token},
                timeout=10,
            )
            resp.raise_for_status()
            redeem = resp.json()
        except httpx.HTTPStatusError as e:
            if e.response.status_code in (400, 404):
                click.echo("  Invite token invalid, already used, revoked, or expired.")
                click.echo("  Check with whoever sent you the token, or request a fresh one.")
            else:
                click.echo(f"  API error ({e.response.status_code}) redeeming invite. Try again later.")
            raise SystemExit(1)
        except httpx.HTTPError as e:
            click.echo(f"  Could not reach VaultLayer API: {e}")
            raise SystemExit(1)

        # Swap the invite token for the long-lived user token. Everything
        # downstream (validate, config.env write, training flow) expects
        # vl_live_... shape.
        token = redeem["user_token"]
        email = redeem.get("email", "")
        click.echo("")
        click.echo(f"  ✓ Invite redeemed for {email}")
        click.echo(f"    Store this in your .env to skip the invite step next time:")
        click.echo(f"    VAULTLAYER_TOKEN={token}")
        click.echo("")
        # If the user exported the invite token to their shell, it will override
        # the newly saved vl_live_... token in config.env and break vaultlayer run.
        import os as _os
        if _os.environ.get("VAULTLAYER_TOKEN", "").startswith("vl_invite_"):
            click.echo("  ⚠  Your shell has the old invite token exported.")
            click.echo("     Run this before continuing:")
            click.echo(f"     unset VAULTLAYER_TOKEN")
            click.echo("")

    if not token.startswith(("vl_live_", "vl_test_")):
        click.echo("  Invalid token format. Tokens start with 'vl_live_' or 'vl_test_'.")
        click.echo("  If you were given an invite token (vl_invite_...), pass it to `vaultlayer init`")
        click.echo("  directly — it will be redeemed automatically.")
        raise SystemExit(1)

    # ── Validate against API ──────────────────────────────────────────────────
    try:
        resp = httpx.post(
            f"{api_url}/api/v1/auth/validate",
            json={"token": token},
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            click.echo("  Token revoked. Run:  vaultlayer init --reauth")
        else:
            click.echo(f"  API error ({e.response.status_code}). Try again later.")
        raise SystemExit(1)
    except httpx.HTTPError as e:
        click.echo(f"  Could not reach VaultLayer API: {e}")
        click.echo("  Check your internet connection or try again later.")
        raise SystemExit(1)

    if not data.get("valid"):
        msg = data.get("message", "unknown error")
        if "revoked" in msg.lower():
            click.echo("  Token revoked. Run:  vaultlayer init --reauth")
        else:
            click.echo(f"  Token invalid: {msg}")
            click.echo("  Contact your VaultLayer admin for a fresh token.")
        raise SystemExit(1)

    email = data.get("email", "")
    balance = data.get("balance_credits", 0)

    # ── Write config.env ──────────────────────────────────────────────────────
    _write_token_to_config_env(config_env, token)
    # Remove legacy token file if present
    old_token_file = cfg_dir / "token"
    if old_token_file.exists():
        old_token_file.unlink()

    if email:
        click.echo(f"  Authenticated as: {email}  (credits: {balance:,})")
        click.echo("")

    # ── Generate checkpoint helpers ───────────────────────────────────────────
    from cli.checkpoint_template import CHECKPOINT_HELPER_TEMPLATE
    from cli.checkpoint_template_deepspeed import DEEPSPEED_CHECKPOINT_TEMPLATE
    from cli.checkpoint_template_jax import JAX_CHECKPOINT_TEMPLATE
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    helper = out_dir / "vaultlayer_checkpoint.py"
    helper.write_text(CHECKPOINT_HELPER_TEMPLATE)
    click.echo(f"  Checkpoint helper (PyTorch)    -> {helper.resolve()}")

    ds_helper = out_dir / "vaultlayer_checkpoint_deepspeed.py"
    ds_helper.write_text(DEEPSPEED_CHECKPOINT_TEMPLATE)
    click.echo(f"  Checkpoint helper (DeepSpeed)  -> {ds_helper.resolve()}")

    jax_helper = out_dir / "vaultlayer_checkpoint_jax.py"
    jax_helper.write_text(JAX_CHECKPOINT_TEMPLATE)
    click.echo(f"  Checkpoint helper (JAX/Flax)   -> {jax_helper.resolve()}")

    click.echo("")
    click.echo("  ── Step 1: Add checkpoint integration to your training script ─────────")
    click.echo("")
    click.echo("  Raw PyTorch (3 lines):")
    click.echo("    from vaultlayer_checkpoint import checkpoint, restore")
    click.echo("    start_step = restore('./checkpoints', model=model, optimizer=optimizer)")
    click.echo("    # inside your loop:")
    click.echo("    checkpoint(step=step, model=model, optimizer=optimizer, save_path='./checkpoints')")
    click.echo("")
    click.echo("  HuggingFace Trainer: checkpoints auto-save; for resume add:")
    click.echo("    trainer.train(resume_from_checkpoint=os.environ.get('VAULTLAYER_RESUME_CHECKPOINT'))")
    click.echo("  PyTorch Lightning:   checkpoints auto-save; for resume pass:")
    click.echo("    trainer.fit(model, ckpt_path=os.environ.get('VAULTLAYER_RESUME_CHECKPOINT'))")
    click.echo("")
    click.echo("  DeepSpeed (2 lines):")
    click.echo("    from vaultlayer_checkpoint_deepspeed import vl_init, vl_checkpoint")
    click.echo("    start_step = vl_init(engine)                  # resume after migration")
    click.echo("    vl_checkpoint(engine, step, loss=loss.item()) # save every N steps")
    click.echo("")
    click.echo("  JAX / Flax (3 lines):")
    click.echo("    from vaultlayer_checkpoint_jax import vl_restore, vl_checkpoint")
    click.echo("    params, opt_state, start_step = vl_restore(params, opt_state)")
    click.echo("    vl_checkpoint(step, params, opt_state, loss=float(loss))")
    click.echo("")
    click.echo("  ── Step 2: Replace 'python' with 'vaultlayer run' ────────────────────")
    click.echo("")
    click.echo("  Before:  python train.py --lr 3e-4 --epochs 10")
    click.echo("  After:   vaultlayer run python train.py --lr 3e-4 --epochs 10")
    click.echo("")
    click.echo("  That's it. VaultLayer will warn you if Step 1 is missing when you run.")
    click.echo("  ──────────────────────────────────────────────────────────────────────")


def _api_url() -> str:
    """Return the VaultLayer API base URL (override via VAULTLAYER_API_URL for dev)."""
    import os
    return os.environ.get("VAULTLAYER_API_URL", "https://vaultlayer-production.up.railway.app").rstrip("/")


def _read_token_from_config_env(config_env: Path) -> str:
    """Read VAULTLAYER_TOKEN from ~/.vaultlayer/config.env. Returns "" if not found."""
    if not config_env.exists():
        return ""
    for line in config_env.read_text().splitlines():
        line = line.strip()
        if line.startswith("VAULTLAYER_TOKEN="):
            return line.split("=", 1)[1].strip().strip('"').strip("'")
    return ""


def _write_token_to_config_env(config_env: Path, token: str) -> None:
    """Write or update VAULTLAYER_TOKEN in ~/.vaultlayer/config.env (chmod 600)."""
    existing_lines: list[str] = []
    if config_env.exists():
        existing_lines = config_env.read_text().splitlines()

    # Replace or append the token line
    token_line = f'VAULTLAYER_TOKEN={token}'
    new_lines = [l for l in existing_lines if not l.startswith("VAULTLAYER_TOKEN=")]
    new_lines.insert(0, token_line)

    config_env.write_text("\n".join(new_lines) + "\n")
    config_env.chmod(0o600)



def _load_token() -> str:
    """Load stored token. Raises SystemExit with helpful message if not found."""
    import os
    token = os.environ.get("VAULTLAYER_TOKEN", "")
    if token:
        return token
    # Try config.env
    config_env = Path.home() / ".vaultlayer" / "config.env"
    token = _read_token_from_config_env(config_env)
    if token:
        return token
    # Legacy fallback
    token_file = Path.home() / ".vaultlayer" / "token"
    if token_file.exists():
        return token_file.read_text().strip()
    click.echo("  Not authenticated. Run:  vaultlayer init")
    raise SystemExit(1)


def _validate_token_or_exit(token: str) -> dict:
    """
    Validate token against API. Returns user data dict.
    Exits with a clear message on 401 (revoked) or network error.
    Warns and continues on transient errors.
    """
    import httpx
    api_url = _api_url()
    try:
        resp = httpx.post(
            f"{api_url}/api/v1/auth/validate",
            json={"token": token},
            timeout=8,
        )
        if resp.status_code == 401:
            click.echo("  Token revoked. Run:  vaultlayer init --reauth")
            raise SystemExit(1)
        resp.raise_for_status()
        data = resp.json()
        if not data.get("valid"):
            msg = data.get("message", "unknown error")
            if "revoked" in msg.lower():
                click.echo("  Token revoked. Run:  vaultlayer init --reauth")
            else:
                click.echo(f"  Token invalid: {msg}. Run:  vaultlayer init")
            raise SystemExit(1)
        return data
    except httpx.HTTPStatusError:
        raise  # already handled above
    except httpx.HTTPError as e:
        # Network error — warn but don't block the job
        click.echo(f"  Warning: could not validate token ({e}). Proceeding.")
        return {}


@cli.command(
    context_settings={"ignore_unknown_options": True, "allow_extra_args": True}
)
@click.argument("command", nargs=-1, required=True)
@click.option("--job-name",     default=None,            help="Label shown in dashboard")
@click.option("--gpu",          default=None, help="GPU type (auto-selects best available if omitted)")
@click.option("--model-params", default=7.0, type=float, help="Model size (billions of params)")
@click.option("--provider",     default=None, metavar="PROVIDER[,PROVIDER...]",
              help="Comma-separated list of providers to consider (whitelist). "
                   "If omitted, every routable provider is considered. "
                   "Names match config/vaultlayer_data.json:provider_prices keys "
                   "(e.g. 'AWS Spot', 'Lambda Labs', 'RunPod'). "
                   "Combined AND with --regions; if no provider+region pair has "
                   "capacity the CLI prompts to widen the search.")
@click.option("--excluded-providers", default=None, metavar="PROVIDER[,PROVIDER...]",
              help="Comma-separated list of providers to never use (denylist). "
                   "Hard constraint — never relaxed by the expand-consent flow. "
                   "Use for compliance or budget guardrails.")
@click.option("--train-mode", default="qlora", type=click.Choice(["qlora","lora","full"]), show_default=True, help="Training mode: qlora (default, cheapest), lora, or full")
@click.option("--yes", "-y",      is_flag=True, default=False, help="Skip pre-flight confirmation prompt (use in scripts/CI)")
@click.option("--data",           default=None,
              help="Training dataset location. Supports s3://, gs://, az://, and r2:// URIs. "
                   "Cloud sources (s3://, gs://, az://) are auto-mirrored to R2 before training "
                   "starts (one-time egress cost, then $0 on all providers). "
                   "Use r2://dataset-id if already mirrored.")
@click.option("--image",             default=None, envvar="VAULTLAYER_DOCKER_IMAGE",
              help="Docker image to pull on provisioned node (e.g. nvcr.io/nvidia/pytorch:24.01-py3). "
                   "Can also be set via VAULTLAYER_DOCKER_IMAGE env var.")
@click.option("--regions",           default=None, metavar="REGION[,REGION...]",
              help="Comma-separated list of regions where nodes may be provisioned. "
                   "If omitted, any region is allowed. "
                   "Example: --regions eu-central-1,eu-west-1  (GDPR-only). "
                   "Run 'vaultlayer regions list-all' to see valid region codes.")
@click.option("--excluded-regions",  default=None, metavar="REGION[,REGION...]",
              help="Comma-separated list of regions to never provision in (takes priority over --regions). "
                   "Example: --excluded-regions cn-north-1,cn-northwest-1")
@click.option("--failover/--no-failover", default=True,
              help="Auto-recover on interruption by retrying on the next available provider "
                   "(default: on). Use --no-failover to disable.")
def run(command, job_name, gpu, model_params, provider, excluded_providers,
        train_mode, yes, data, image,
        regions, excluded_regions, failover):
    """
    Run any training command under VaultLayer protection.

    \b
    Examples:
        vaultlayer run python train.py
        vaultlayer run --gpu A100_40GB --model-params 13 torchrun --nproc_per_node=4 train.py
        vaultlayer run --data s3://my-bucket/train python train.py
        vaultlayer run --data gs://my-bucket/train python train.py
        vaultlayer run --data az://container/train python train.py
        vaultlayer run --regions eu-central-1,eu-west-1 python train.py
    """
    import math
    import httpx

    token = _load_token()

    # ── Token check before doing anything ────────────────────────────────────
    _user_data = _validate_token_or_exit(token)
    _user_email = _user_data.get("email", "")

    # ── GPU type validation (only when explicitly specified) ──────────────────
    _gpu_specified = gpu is not None
    if _gpu_specified:
        _VALID_GPUS = set(_GPU_RATES.keys())
        try:
            from shared.data_loader import get_gpu_aliases
            _VALID_GPUS.update(get_gpu_aliases().keys())
            _VALID_GPUS.update(get_gpu_aliases().values())
        except Exception:
            pass
        try:
            from shared.models import GPUType as _GT
            _VALID_GPUS.update(g.value for g in _GT)
        except Exception:
            pass
        if gpu not in _VALID_GPUS:
            click.echo(f"\n  Error: Unknown GPU type '{gpu}'")
            click.echo(f"  Valid options: {', '.join(sorted(_GPU_RATES.keys()))}")
            click.echo(f"  Run: vaultlayer estimate --help  for GPU pricing info")
            raise SystemExit(1)

    # ── Storage scanner: warn if script accesses S3/GCS/Azure with no creds ──
    _script_path = None
    for arg in command:
        p = Path(arg)
        if p.suffix == ".py" and p.exists():
            _script_path = p
            break
    if _script_path:
        from cli.inject import warn_if_storage_unconfigured
        _config_env = Path.home() / ".vaultlayer" / "config.env"
        warn_if_storage_unconfigured(_script_path, _config_env)

    # ── GPU selection + availability ──────────────────────────────────────────
    # Availability is checked against the PricingAgent's Redis cache (refreshed
    # every ~60s from live provider APIs). We intentionally do NOT call provider
    # APIs in real-time here — that would add 2–5s of latency per provider for
    # every `vaultlayer run`. Cache age is shown so the user can judge staleness.
    # Fail-closed: if the cache is missing entirely (PricingAgent not running)
    # we warn rather than silently queue.
    api_url = _api_url()
    estimated_hours = 2.0
    _hop_target_gpu   = None
    _hop_fallback_gpu = None

    def _check_avail(gpu_type: str) -> dict:
        """Query availability endpoint. Returns the JSON dict or {} on error."""
        try:
            r = httpx.get(f"{api_url}/api/v1/pricing/gpu/{gpu_type}/availability", timeout=8)
            if r.status_code == 200:
                return r.json()
        except Exception:
            pass
        return {}

    min_vram = _min_vram_for_model(model_params, train_mode)
    _gpu_is_cache_fallback = False  # set True when pricing cache unavailable

    if not _gpu_specified:
        # ── Auto-select: cheapest GPU with enough VRAM for the model ─────────
        # Single call to fetch all currently-available GPUs, then filter by
        # VRAM floor and sort cheapest-first. Cache-backed (~60s freshness).
        gpu = None
        try:
            _all_resp = httpx.get(f"{api_url}/api/v1/pricing/gpu?available_only=true", timeout=8)
            if _all_resp.status_code == 200:
                _data = _all_resp.json()
                _all_gpus = _data.get("gpus", [])
                _cache_age = _data.get("cache_age_seconds")
                # Filter to GPUs with sufficient VRAM and live providers, sort cheapest first.
                # Unknown GPU types default to inf so they're included rather than silently
                # dropped — the server will validate actual fit at provision time.
                _valid = sorted(
                    [g for g in _all_gpus
                     if _GPU_VRAM_GB.get(g["gpu_type"], float("inf")) >= min_vram
                     and g.get("providers")],
                    key=lambda g: g.get("best_vaultlayer_rate", 9999),
                )
                if _valid:
                    _best = _valid[0]
                    gpu = _best["gpu_type"]
                    _vl_rate = _best.get("best_vaultlayer_rate", 0)
                    click.echo(f"  Auto-selected: {gpu} (${_vl_rate:.2f}/hr, "
                               f"cheapest with ≥{min_vram:.0f}GB VRAM for "
                               f"{model_params}B {train_mode})")
                elif _cache_age is None:
                    # Pricing cache missing (PricingAgent not running / Redis cold).
                    # Default to A100_40GB — most available across included providers,
                    # cheaper than H100, and the server's BFS walk reaches it faster.
                    click.echo("  Warning: pricing cache unavailable — defaulting to A100_40GB.")
                    gpu = "A100_40GB"
                    _gpu_is_cache_fallback = True
                else:
                    # Cache is live but all GPUs show no capacity right now.
                    # Still submit — job will wait in queue until capacity opens.
                    gpu = "A100_40GB"
                    _gpu_is_cache_fallback = True
                    click.echo(f"  No capacity confirmed right now (cache {_cache_age}s old) — "
                               f"submitting to queue. Job starts when a GPU becomes available.")
            else:
                click.echo("  Warning: pricing cache unavailable — defaulting to A100_40GB.")
                gpu = "A100_40GB"
                _gpu_is_cache_fallback = True
        except SystemExit:
            raise
        except Exception:
            click.echo("  Warning: pricing cache unavailable — defaulting to A100_40GB.")
            gpu = "A100_40GB"
            _gpu_is_cache_fallback = True
    else:
        # ── Specified GPU: check availability, BFS for VRAM-compatible fallback ─
        avail = _check_avail(gpu)
        cache_age = avail.get("cache_age_seconds")
        if cache_age is not None and cache_age > 300:
            click.echo(f"  Note: pricing cache is {cache_age}s old — availability may be stale.")

        if avail and not avail.get("available"):
            click.echo("")
            click.echo(f"  {gpu} is not available right now.")
            fb_gpu = _bfs_gpu_fallback(gpu, min_vram, _check_avail)
            if fb_gpu:
                fb_avail = _check_avail(fb_gpu)
                fb_rate = fb_avail.get("vaultlayer_rate_per_hr", _GPU_RATES.get(fb_gpu, 0))
                click.echo(f"  Best alternative: {fb_gpu} at ${fb_rate:.2f}/hr "
                           f"(≥{min_vram:.0f}GB VRAM, nearest available)")
                click.echo(f"  → Auto-upgrades to {gpu} when capacity opens. Migration is $0.00.")
                click.echo("")
                if yes:
                    click.echo(f"  --yes flag: starting on {fb_gpu}")
                    _start_fb = True
                else:
                    _start_fb = click.confirm(f"  Start on {fb_gpu} instead?", default=True)
                if _start_fb:
                    _hop_target_gpu   = gpu
                    _hop_fallback_gpu = fb_gpu
                    gpu             = fb_gpu
                    click.echo(f"  ✓  Will start on {fb_gpu}, auto-upgrade to {_hop_target_gpu}")
                else:
                    click.echo("  Job cancelled.")
                    raise SystemExit(0)
            else:
                click.echo(f"  No alternative GPU with ≥{min_vram:.0f}GB VRAM is available right now.")
                click.echo(f"  Try again later or reduce model size (--model-params).")
                raise SystemExit(1)

    hourly_rate_usd = _gpu_hourly_rate(gpu, provider)
    credits_needed  = math.ceil(hourly_rate_usd * estimated_hours * 1.20 * 100)

    # ── Credit preflight ──────────────────────────────────────────────────────
    click.echo("")
    click.echo("  VaultLayer — pre-flight check")
    click.echo("  " + "─" * 40)

    try:
        bal_resp = httpx.get(
            f"{api_url}/api/v1/credits",
            headers={"Authorization": f"Bearer {token}"},
            timeout=8,
        )
        bal_resp.raise_for_status()
        bal = bal_resp.json()
        available = bal["available_credits"]
        available_usd = bal["available_usd"]
    except httpx.HTTPError as e:
        click.echo(f"  Warning: could not fetch credit balance ({e}). Proceeding anyway.")
        available = credits_needed + 1
        available_usd = available / 100

    _gpu_label = gpu + ("  (cache fallback — actual GPU assigned at provision)" if _gpu_is_cache_fallback else "")
    click.echo(f"  GPU:       {_gpu_label}")
    click.echo(f"  Rate:      ~{int(hourly_rate_usd * 100)} credits/hr (${hourly_rate_usd:.2f}/hr)")
    click.echo(f"  Estimate:  {estimated_hours:.0f}hr job → ~{credits_needed:,} credits reserved "
               f"(includes 20% buffer)")
    click.echo(f"  Balance:   {available:,} credits available (${available_usd:.2f})")

    if _hop_target_gpu:
        click.echo(f"  Hop:       {gpu} → {_hop_target_gpu} (auto-upgrade when available, Tier 3)")

    if available <= 0:
        click.echo(f"\n  Insufficient credits. Balance: $0.00")
        click.echo("  Contact support to top up credits.")
        raise SystemExit(1)
    elif available < credits_needed:
        click.echo(f"  Note: credits may not cover full estimated run ({available:,} available, ~{credits_needed:,} estimated).")
        click.echo("  Job will pause if credits run out (checkpoint saved, resume anytime).")

    if not yes:
        click.echo("")
        click.confirm("  Start job?", default=True, abort=True)

    click.echo("")

    def _split_csv(value):
        return [v.strip() for v in value.split(",") if v.strip()] if value else []

    _regions             = _split_csv(regions)
    _excluded_regions    = _split_csv(excluded_regions)
    _preferred_providers = _split_csv(provider)
    _excluded_providers  = _split_csv(excluded_providers)

    from cli.run import RunCommand
    runner = RunCommand(
        command=list(command),
        job_name=job_name or " ".join(command[:3]),
        gpu_type=gpu,
        model_params_billion=model_params,
        preferred_providers=_preferred_providers,
        excluded_providers=_excluded_providers,
        data_uri=data,
        docker_image=image or "",
        regions=_regions,
        excluded_regions=_excluded_regions,
    )
    runner.yes = True              # already confirmed above
    runner._skip_preflight = True  # main.py already showed preflight + got confirmation
    runner.user_email = _user_email
    runner.train_mode = train_mode
    runner.gpu_auto_selected = not _gpu_specified
    runner.min_vram_gb = min_vram
    runner.vaultlayer_token = token
    runner.api_url = api_url
    runner.hourly_rate_usd = hourly_rate_usd
    # Pass hop metadata so RunCommand can call /hop-consent after job is registered
    runner.hop_target_gpu   = _hop_target_gpu
    runner.hop_fallback_gpu = _hop_fallback_gpu
    runner.failover_enabled = failover
    try:
        asyncio.run(runner.execute())
    except KeyboardInterrupt:
        click.echo("\n  Interrupted.")
    except Exception as exc:
        import traceback as _tb
        click.echo(f"\n  Error: {exc}", err=True)
        from cli.crash_reporter import save_crash_report
        from cli.feedback import prompt_crash_report
        report_id = save_crash_report(
            exc,
            command=list(command),
            job_id=getattr(runner, 'job_id', None),
            gpu_type=gpu,
            provider=provider,
        )
        prompt_crash_report(report_id, list(command), job_id=getattr(runner, 'job_id', None))
        raise SystemExit(1)


# GPU → approximate spot price in USD/hr (VaultLayer-managed infra rates + 15% margin)
def _build_gpu_rates() -> dict[str, float]:
    """Build GPU rate lookup from live provider prices (cheapest per GPU)."""
    try:
        from shared.data_loader import get_provider_prices, get_gpu_aliases
        prices = get_provider_prices()
        aliases = get_gpu_aliases()
        rates = {}
        for provider, gpus in prices.items():
            if provider.startswith("_") or "Reserved" in provider or "On-Demand" in provider:
                continue
            for gpu, price in gpus.items():
                if isinstance(price, (int, float)) and price > 0:
                    if gpu not in rates or price < rates[gpu]:
                        rates[gpu] = price
        # Add alias mappings (e.g. H100_80GB_SXM → same as H100)
        for alias, canonical in aliases.items():
            if canonical in rates and alias not in rates:
                rates[alias] = rates[canonical]
        return rates
    except Exception:
        # Fallback if data_loader unavailable
        return {"H100": 2.86, "A100": 2.18, "A10G": 0.86, "A6000": 0.79}

_GPU_RATES: dict[str, float] = _build_gpu_rates()

# VRAM capacity (GB) for each GPU type. Used to filter candidates by model requirements.
# Includes both canonical GPUType enum names and short aliases used in the pricing cache.
# Unknown GPU types are treated as having infinite VRAM (fail-open) — we'd rather
# let the server try an unknown GPU than silently exclude it.
_GPU_VRAM_GB: dict[str, float] = {
    # Canonical names (GPUType enum)
    "H100_80GB_SXM":  80.0,
    "H100_80GB_PCIE": 80.0,
    "H100_80GB_NVL":  80.0,
    "A100_80GB_SXM":  80.0,
    "A100_40GB":      40.0,
    "L40S":           48.0,
    "A10G":           24.0,
    "A40":            48.0,
    "RTX4090":        24.0,
    "RTX3090":        24.0,
    # Short aliases commonly seen in the pricing cache
    "H100":    80.0,
    "H200":   141.0,
    "GH200":   96.0,
    "B200":   192.0,
    "A100":    40.0,   # conservative — 40GB floor (could be 80GB SXM variant)
    "A10":     24.0,
    "L40":     48.0,
    "V100":    16.0,
    "T4":      16.0,
}

# Fallback adjacency list — mirrors pricing_routes._FALLBACK_CHAIN.
# Update both files together whenever the set of routable GPUs changes.
_FALLBACK_CHAIN: dict[str, list[str]] = {
    "H100_80GB_SXM":  ["H100_80GB_PCIE", "H100_80GB_NVL", "A100_80GB_SXM", "A100_40GB", "A10G"],
    "H100_80GB_PCIE": ["H100_80GB_SXM",  "H100_80GB_NVL", "A100_80GB_SXM", "A100_40GB", "A10G"],
    "H100_80GB_NVL":  ["H100_80GB_SXM",  "H100_80GB_PCIE", "A100_80GB_SXM", "A100_40GB", "A10G"],
    "A100_80GB_SXM":  ["A100_40GB", "A10G", "A40", "L40S"],
    "A100_40GB":      ["A100_80GB_SXM", "A10G", "A40", "L40S"],
    "L40S":           ["A100_40GB", "A10G", "A40"],
    "A10G":           ["A40", "L40S", "A100_40GB"],
    "A40":            ["A10G", "L40S", "A100_40GB"],
    "RTX4090":        ["A10G", "A40", "RTX3090"],
    "RTX3090":        ["RTX4090", "A10G", "A40"],
}


def _min_vram_for_model(model_params: float, train_mode: str) -> float:
    """Minimum GPU VRAM (GB) needed to train a model_params-billion-parameter model."""
    if train_mode == "qlora":
        return model_params * 0.5 + 4.0
    elif train_mode == "lora":
        return model_params * 1.0 + 4.0
    else:  # full
        return model_params * 2.0 + 8.0


def _bfs_gpu_fallback(
    start_gpu: str,
    min_vram: float,
    check_avail_fn,
) -> "Optional[str]":
    """
    BFS over _FALLBACK_CHAIN to find the nearest available GPU with VRAM >= min_vram.
    Returns the first available GPU found in BFS order, or None if exhausted.
    Nodes with insufficient VRAM are skipped (but their neighbors are still explored).
    """
    from collections import deque
    visited: set = {start_gpu}
    queue: deque = deque(_FALLBACK_CHAIN.get(start_gpu, []))
    while queue:
        candidate = queue.popleft()
        if candidate in visited:
            continue
        visited.add(candidate)
        if _GPU_VRAM_GB.get(candidate, float("inf")) < min_vram:
            # Too little VRAM — skip this node but keep exploring its neighbors
            for neighbor in _FALLBACK_CHAIN.get(candidate, []):
                if neighbor not in visited:
                    queue.append(neighbor)
            continue
        avail = check_avail_fn(candidate)
        if avail.get("available"):
            return candidate
        for neighbor in _FALLBACK_CHAIN.get(candidate, []):
            if neighbor not in visited:
                queue.append(neighbor)
    return None


def _gpu_hourly_rate(gpu_type: str, provider: "Optional[str]" = None) -> float:
    return _GPU_RATES.get(gpu_type, 1.50)


@cli.command()
@click.option("--all", "include_all", is_flag=True, default=False,
              help="Include completed jobs (default: active only)")
def status(include_all):
    """Show all active and recent jobs."""
    import httpx as _httpx
    token = _load_token()
    api_url = _api_url()
    try:
        resp = _httpx.get(
            f"{api_url}/api/v1/jobs",
            headers={"Authorization": f"Bearer {token}"},
            params={"limit": 20, "include_completed": "true" if include_all else "false"},
            timeout=8,
        )
        resp.raise_for_status()
        jobs = resp.json().get("jobs", [])
    except _httpx.HTTPError as e:
        click.echo(f"  Error fetching jobs: {e}", err=True)
        click.echo("  (Full view: https://vaultlayer.pages.dev)")
        return

    if not jobs:
        click.echo("\n  No active jobs.")
        if not include_all:
            click.echo("  To include completed jobs: vaultlayer status --all")
        click.echo("  (Full view: https://vaultlayer.pages.dev)")
        return

    click.echo(f"\n  {'JOB ID':<36} {'STATUS':<14} {'GPU':<18} {'PROVIDER':<14}  BILLED")
    click.echo(f"  {'-'*36} {'-'*14} {'-'*18} {'-'*14}  {'-'*10}")
    for j in jobs:
        gpu = j.get("gpu_type", "?")
        provider = j.get("provider", "?") or "?"
        status_val = j.get("status", "?")
        job_id = j.get("job_id", "?")
        billed_sec = j.get("billing_seconds", 0) or 0
        billed_hr = billed_sec / 3600
        billed_str = f"{billed_hr:.1f}h" if billed_hr >= 0.1 else f"{billed_sec}s"
        click.echo(
            f"  {job_id:<36} {status_val:<14} {gpu:<18} {provider:<14}  {billed_str}"
        )
    click.echo(f"\n  {len(jobs)} job(s) shown.  Full view: https://vaultlayer.pages.dev\n")


@cli.command()
@click.argument("job_id")
@click.option("--tail", default=50, type=int, help="Number of lines to show (default: 50)")
@click.option("--follow", "-f", is_flag=True, help="Poll for new lines every 5s")
def logs(job_id, tail, follow):
    """Show recent training output for a job (reads from R2 log buffer)."""
    env_file = Path.home() / ".vaultlayer" / "config.env"
    if env_file.exists():
        from dotenv import load_dotenv
        load_dotenv(env_file)

    import time

    def _fetch_and_print(r2_client, last_lines_shown):
        try:
            response = r2_client.get_object(
                Bucket=r2_client._bucket,
                Key=f"logs/{job_id}/tail.txt",
            )
            content = response["Body"].read().decode("utf-8", errors="replace")
            lines = content.splitlines()
            to_show = lines[-tail:]
            # When following, only print new lines
            if follow and last_lines_shown is not None:
                new_lines = to_show[last_lines_shown:]
                for line in new_lines:
                    click.echo(line)
                return len(to_show)
            else:
                for line in to_show:
                    click.echo(line)
                return len(to_show)
        except Exception as e:
            if "NoSuchKey" in str(e) or "404" in str(e):
                click.echo(f"  No logs found for job {job_id}. "
                           "Logs are uploaded at each checkpoint.", err=True)
            else:
                click.echo(f"  Error fetching logs: {e}", err=True)
            return 0

    # ── Try API first (works for managed-service users with no local R2 config) ─
    try:
        from shared.api_utils import get_token, get_api_url
        import httpx as _httpx
        _token = get_token()
        if _token:
            _api_url = get_api_url()
            _headers = {"Authorization": f"Bearer {_token}"}
            _lr = _httpx.get(
                f"{_api_url}/api/v1/jobs/{job_id}/logs",
                headers=_headers, params={"limit": tail}, timeout=8,
            )
            if _lr.status_code == 200:
                _lines = _lr.json().get("lines", [])
                if _lines:
                    for _ld in _lines[-tail:]:
                        _line = _ld.get("line", str(_ld)) if isinstance(_ld, dict) else str(_ld)
                        click.echo(f"  {_line}")
                else:
                    click.echo(f"  No logs yet for job {job_id}.")
                if follow:
                    click.echo(f"  Following logs for job {job_id} (Ctrl+C to stop)...")
                    _seen = len(_lines)
                    try:
                        while True:
                            time.sleep(5)
                            _fr = _httpx.get(
                                f"{_api_url}/api/v1/jobs/{job_id}/logs",
                                headers=_headers, params={"limit": 500, "offset": _seen}, timeout=8,
                            )
                            if _fr.status_code == 200:
                                _new = _fr.json().get("lines", [])
                                for _ld in _new:
                                    click.echo(f"  {_ld.get('line', str(_ld)) if isinstance(_ld, dict) else str(_ld)}")
                                _seen += len(_new)
                    except KeyboardInterrupt:
                        pass
                return
            elif _lr.status_code == 404:
                click.echo(f"  No logs found for job {job_id}.")
                return
    except Exception:
        pass  # fall through to direct R2 access

    # ── Fall back to direct R2 access (self-hosted users) ────────────────────
    try:
        from shared.config import load_config
        from agents.vault.r2 import R2Client
        config = load_config()
        r2 = R2Client(
            endpoint=config.cloudflare.r2_endpoint,
            access_key_id=config.cloudflare.r2_access_key_id,
            secret_access_key=config.cloudflare.r2_secret_access_key,
            bucket=config.cloudflare.r2_bucket,
        )
        _s3 = r2._s3
        _s3._bucket = config.cloudflare.r2_bucket

        class _R2Accessor:
            def __init__(self, s3, bucket):
                self._s3 = s3
                self._bucket = bucket
            def get_object(self, **kwargs):
                return self._s3.get_object(**kwargs)

        accessor = _R2Accessor(r2._s3, config.cloudflare.r2_bucket)
    except Exception as e:
        click.echo(f"  Config error: {e}", err=True)
        return

    last_shown = _fetch_and_print(accessor, None)
    if follow:
        click.echo(f"  Following logs for job {job_id} (Ctrl+C to stop)...")
        try:
            while True:
                time.sleep(5)
                last_shown = _fetch_and_print(accessor, last_shown)
        except KeyboardInterrupt:
            pass


@cli.command()
@click.argument("job_id")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def stop(job_id, yes):
    """Stop a running job (checkpoints before terminating)."""
    if not yes:
        click.confirm(
            f"Stop job {job_id}? This will checkpoint and terminate the instance.",
            abort=True,
        )

    # ── Try managed cancel API first (works for all managed-service users) ───
    try:
        import httpx as _httpx
        token = _load_token()
        api_url = _api_url()
        resp = _httpx.post(
            f"{api_url}/api/v1/jobs/{job_id}/cancel",
            headers={"Authorization": f"Bearer {token}"},
            params={"reason": "user_request"},
            timeout=10,
        )
        if resp.status_code == 200:
            click.echo(f"  Job {job_id} cancelled.")
            click.echo(f"  The job will checkpoint and terminate within ~2 minutes.")
            return
        elif resp.status_code == 404:
            click.echo(f"  Job {job_id} not found or already completed.")
            return
        # Other errors — fall through to Redis path
    except Exception:
        pass

    # ── Fallback: Redis pub/sub (self-hosted deployments) ────────────────────
    env_file = Path.home() / ".vaultlayer" / "config.env"
    if env_file.exists():
        from dotenv import load_dotenv
        load_dotenv(env_file)

    async def _stop():
        from shared.config import load_config
        from shared.queue import AgentQueue
        from shared.models import AgentEvent, EventType
        config = load_config()
        queue = AgentQueue(config.redis.url)
        await queue.connect()
        event = AgentEvent(
            event_type=EventType.STOP_REQUESTED,
            source_agent="cli",
            job_id=job_id,
            payload={"requested_by": "cli"},
        )
        await queue.publish("orchestration", event)
        click.echo(f"  Stop signal sent for job {job_id}.")
        click.echo(f"  The job will checkpoint and terminate within ~2 minutes.")
        await queue.disconnect()

    asyncio.run(_stop())


from cli.feedback import feedback as feedback_cmd
cli.add_command(feedback_cmd, name="feedback")
from cli.sync import sync as sync_cmd
cli.add_command(sync_cmd, name="sync")
cli.add_command(sync_cmd, name="upload")  # alias: vaultlayer upload == vaultlayer sync
from cli.download import download as download_cmd
cli.add_command(download_cmd, name="download")
from cli.smoke_history import smoke_history as smoke_history_cmd
cli.add_command(smoke_history_cmd, name="smoke-history")
from cli.restart import restart as restart_cmd
cli.add_command(restart_cmd, name="restart")
from cli.signup import signup as signup_cmd
cli.add_command(signup_cmd, name="signup")
from cli.login_cmd import login as login_cmd
cli.add_command(login_cmd, name="login")
from cli.examples import examples as examples_cmd
cli.add_command(examples_cmd, name="examples")
from cli.estimate import estimate as estimate_cmd
cli.add_command(estimate_cmd, name="estimate")
from cli.ps import ps as ps_cmd
cli.add_command(ps_cmd, name="ps")
from cli.delete import delete_job, rotate_key
cli.add_command(delete_job)
cli.add_command(rotate_key)

# Extracted command groups
from cli.connect import connect
cli.add_command(connect)
from cli.data import datasets, regions
cli.add_command(datasets)
cli.add_command(regions)
from cli.admin_cmd import admin as admin_group
cli.add_command(admin_group)

def main():
    cli()


if __name__ == "__main__":
    main()
