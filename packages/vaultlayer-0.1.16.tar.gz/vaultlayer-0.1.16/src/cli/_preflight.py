"""
VaultLayer CLI — pre-flight checks and confirmation UI.

Extracted from run.py to keep RunCommand slim.

Public API:
  check_multi_node(command)           → aborts if distributed training detected
  check_script_integration(command)   → returns integration status dict
  print_preflight(run_cmd, yes, ...)  → shows pre-flight table, returns True if confirmed
"""
from __future__ import annotations

import logging
import os
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cli.run import RunCommand

logger = logging.getLogger(__name__)


# ── Admin guard ───────────────────────────────────────────────────────────────

def require_admin_token() -> None:
    """Abort with a clear error if VL_INTERNAL_ADMIN_TOKEN is not set or empty.

    Hidden operator commands (rotate-key, smoke-history, signup) call this at
    the top of their handler so they fail-closed when run by a regular user.
    """
    import click
    token = os.environ.get("VL_INTERNAL_ADMIN_TOKEN", "").strip()
    if not token:
        click.echo("  This command is restricted to VaultLayer operators.")
        click.echo("  Set VL_INTERNAL_ADMIN_TOKEN to proceed.")
        raise SystemExit(1)


# ── Multi-node guard ──────────────────────────────────────────────────────────

def check_multi_node(command: list[str]) -> None:
    """
    Detect multi-node / distributed training and abort with a clear error.

    VaultLayer V0 supports single-node failover only.  If a user runs a
    multi-node job (torchrun --nnodes>1, deepspeed, WORLD_SIZE>1, …) and
    VaultLayer migrates one node, the remaining nodes hang indefinitely
    while still billing — a "ghost bill" incident.
    """
    import re

    cmd_str = " ".join(str(c) for c in command)

    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    node_rank  = int(os.environ.get("NODE_RANK",  "0"))
    rank       = int(os.environ.get("RANK",       "0"))
    if world_size > 1 or node_rank > 0 or rank > 0:
        _multi_node_abort(
            command,
            f"WORLD_SIZE={world_size}, NODE_RANK={node_rank}, RANK={rank} detected in environment.",
        )

    m = re.search(r"--nnodes[=\s]+(\d+)", cmd_str)
    if m and int(m.group(1)) > 1:
        _multi_node_abort(command, f"torchrun --nnodes={m.group(1)} detected in command.")

    m = re.search(r"--num_nodes[=\s]+(\d+)", cmd_str)
    if m and int(m.group(1)) > 1:
        _multi_node_abort(command, f"--num_nodes={m.group(1)} detected in command.")

    if ("torchrun" in cmd_str or "deepspeed" in cmd_str) and "--hostfile" in cmd_str:
        _multi_node_abort(command, "--hostfile flag detected — multi-node launch inferred.")


def _multi_node_abort(command: list[str], reason: str) -> None:
    R, Y, BO = "\033[0m", "\033[97m", "\033[1m"
    print(f"\n  {BO}VaultLayer — Multi-Node Training Detected{R}")
    print(f"  {Y}{'─'*52}{R}")
    print(f"  {reason}")
    print()
    print(f"  {BO}VaultLayer V0 supports single-node failover only.{R}")
    print(f"  Running a multi-node job risks a 'ghost bill':")
    print(f"  if VaultLayer migrates one node, the remaining")
    print(f"  nodes hang (but keep billing) waiting for the ring.")
    print()
    print(f"  Options:")
    print(f"    1. Run on a single node with multiple GPUs (--nproc_per_node)")
    print(f"    2. Wait for VaultLayer V1 (multi-node / NCCL-aware watchdog)")
    print(f"    3. Override with: VAULTLAYER_ALLOW_MULTINODE=1 vaultlayer run ...")
    print()
    if os.environ.get("VAULTLAYER_ALLOW_MULTINODE") == "1":
        logger.warning("VAULTLAYER_ALLOW_MULTINODE=1 set — proceeding anyway. "
                       "Ghost bills are your responsibility.")
        return
    sys.exit(1)


# ── Script integration check ──────────────────────────────────────────────────

def check_script_integration(command: list[str]) -> dict:
    """
    Scan the user's training script for VaultLayer checkpoint integration.

    Returns a dict with keys:
      status  : "ok"        — VaultLayer helper is imported
                "zero_code" — framework checkpointing detected; resume needs env-var handoff
                "missing"   — Python script found but no integration detected
                "unknown"   — not a .py file (inline -c, shell script, etc.) — skip check
      framework       : human-readable framework name
      script          : path to the scanned file
      deepspeed       : True if deepspeed is imported
      deepspeed_helper: True if vaultlayer_checkpoint_deepspeed is imported
    """
    import pathlib

    result: dict = {"status": "unknown", "framework": "", "script": "",
                    "deepspeed": False, "deepspeed_helper": False}

    script_path = None
    skip_next = False
    for token in command:
        if skip_next:
            skip_next = False
            continue
        if token in ("-c", "-m"):
            skip_next = True
            continue
        if token.endswith(".py") and not token.startswith("-"):
            script_path = pathlib.Path(token)
            break

    if script_path is None or not script_path.exists():
        return result

    result["script"] = script_path.name
    try:
        src = script_path.read_text(errors="replace")
    except Exception:
        return result

    lines = src.lower()

    result["deepspeed"] = "import deepspeed" in lines or "from deepspeed" in lines
    result["deepspeed_helper"] = "vaultlayer_checkpoint_deepspeed" in lines

    if "vaultlayer_checkpoint" in lines:
        result["status"] = "ok"
        if result["deepspeed_helper"]:
            result["framework"] = "DeepSpeed + VaultLayer helper"
        else:
            result["framework"] = "PyTorch + VaultLayer helper"
        return result

    hf_patterns = ["from transformers import trainer", "from transformers import autotrainer",
                   "transformers.trainer", "seq2seqtrainer",
                   "import transformers"]
    if any(p in lines for p in hf_patterns):
        # HF Trainer auto-saves checkpoints (zero-code for saving). Resume requires
        # one line: trainer.train(resume_from_checkpoint=os.environ.get("VAULTLAYER_RESUME_CHECKPOINT"))
        # VaultLayer sets VAULTLAYER_RESUME_CHECKPOINT on failover legs automatically.
        result["status"] = "zero_code"
        result["framework"] = "HuggingFace Trainer"
        result["resume_hint"] = "VAULTLAYER_RESUME_CHECKPOINT"
        result["resume_example"] = (
            "trainer.train(resume_from_checkpoint="
            "os.environ.get('VAULTLAYER_RESUME_CHECKPOINT'))"
        )
        return result

    lightning_patterns = ["import pytorch_lightning", "from pytorch_lightning",
                           "import lightning", "from lightning", "pl.trainer", "pl.lightningmodule"]
    if any(p in lines for p in lightning_patterns):
        result["status"] = "zero_code"
        result["framework"] = "PyTorch Lightning"
        result["resume_hint"] = "VAULTLAYER_RESUME_CHECKPOINT"
        result["resume_example"] = (
            "trainer.fit(model, ckpt_path="
            "os.environ.get('VAULTLAYER_RESUME_CHECKPOINT'))"
        )
        return result

    if "import jax" in lines or "import flax" in lines or "from flax" in lines:
        result["status"] = "missing"
        result["framework"] = "JAX/Flax"
        result["jax"] = True
        return result

    result["status"] = "missing"
    return result


# ── Pre-flight UI ─────────────────────────────────────────────────────────────

def print_preflight(run_cmd: "RunCommand", yes: bool = False, train_mode: str = "qlora") -> bool:
    """
    Show pre-flight GPU recommendation, cost estimate, and ask for confirmation.
    Returns True if user confirmed (or --yes was passed), False to abort.

    Flow:
      1. Scan script for integration — if missing, offer to inject (Y/n) FIRST.
      2. Show the pre-flight table (GPU, cost, protections, integration status).
      3. Ask "Start job? [Y/n]" — the single final confirmation.
    """
    import pathlib as _pl
    import click

    G, Y, R, B, BO = "\033[97m", "\033[97m", "\033[0m", "\033[97m", "\033[1m"

    # Step 1: Integration check + injection offer
    integration = check_script_integration(run_cmd.command)

    _script_path = None
    _skip = False
    for _tok in run_cmd.command:
        if _skip:
            _skip = False; continue
        if _tok in ("-c", "-m"):
            _skip = True; continue
        if _tok.endswith(".py") and not _tok.startswith("-"):
            _p = _pl.Path(_tok)
            if _p.exists():
                _script_path = _p
            break

    if integration.get("status") == "missing" and _script_path:
        try:
            from cli.inject import run_interactive_injection, detect_framework
            _fw = detect_framework(integration)
            print("")
            _injected = run_interactive_injection(_script_path, _fw)
            if _injected:
                integration = check_script_integration(run_cmd.command)
        except Exception as _inj_err:
            logger.debug(f"Auto-inject failed: {_inj_err}")

    # Step 2: Pre-flight table
    try:
        from shared.data_loader import get_provider_prices, get_gpu_aliases, recommend_gpu, get_meta
    except ImportError:
        import json
        for _p in [_pl.Path("config/vaultlayer_data.json"),
                   _pl.Path(__file__).parent.parent.parent / "config" / "vaultlayer_data.json"]:
            if _p.exists():
                _d = json.load(open(_p))
                break
        else:
            _d = {"provider_prices": {}, "gpu_aliases": {}, "gpu_profiles": {"tiers": []}}

        def get_provider_prices(): return _d["provider_prices"]
        def get_gpu_aliases():     return _d["gpu_aliases"]
        def get_meta():            return _d.get("_meta", {})
        def recommend_gpu(p, m="qlora"): return ("H100_80GB_SXM", 80, "Defaulting to H100", 1)

    PROVIDER_PRICES = get_provider_prices()
    GPU_ALIASES     = get_gpu_aliases()

    gpu_type = run_cmd.gpu_type
    gpu_key  = GPU_ALIASES.get(gpu_type, gpu_type)
    rec_gpu, _rec_vram, _rec_reason, _rec_multi = recommend_gpu(run_cmd.model_params_billion, train_mode)
    gpu_was_explicit  = (gpu_type != "auto" and gpu_type is not None)
    effective_gpu_key = GPU_ALIASES.get(rec_gpu, rec_gpu) if not gpu_was_explicit else gpu_key
    display_gpu       = gpu_type if gpu_was_explicit else rec_gpu

    aws_od = PROVIDER_PRICES.get("AWS On-Demand", {}).get(effective_gpu_key, 0)
    non_aws = {p: v[effective_gpu_key] for p, v in PROVIDER_PRICES.items()
               if isinstance(v, dict) and "AWS" not in p and v.get(effective_gpu_key) is not None}
    best_p      = min(non_aws, key=lambda p: non_aws[p]) if non_aws else None
    vl_price    = non_aws.get(best_p, aws_od) * 1.15 if best_p else aws_od
    savings_pct = int((aws_od - vl_price) / aws_od * 100) if aws_od and best_p else 0

    if best_p and savings_pct > 0:
        cost_line = (f"${vl_price:.2f}/hr via {best_p}"
                     f"  {G}·  saves {savings_pct}% vs AWS{R}  "
                     f"{Y}(est.){R}")
    else:
        cost_line = f"${aws_od:.2f}/hr (AWS On-Demand)  {Y}(est.){R}"

    ckpt_interval = os.environ.get("VAULTLAYER_CHECKPOINT_INTERVAL", "300")
    _st = integration.get("status")
    if _st == "ok":
        integ_line = f"{G}{integration.get('framework', 'PyTorch')} ✓{R}"
    elif _st == "zero_code":
        _fw = integration.get("framework", "")
        _hint = integration.get("resume_hint")
        if _hint:
            # Checkpoint saving is automatic; resume requires one line in the script.
            _example = integration.get("resume_example") or (
                f"os.environ.get('{_hint}')"
            )
            integ_line = (
                f"{G}{_fw} — checkpoints auto-saved ✓{R}  "
                f"{Y}(for resume: {_example}){R}"
            )
        else:
            integ_line = f"{G}{_fw} — zero-code ✓{R}"
    elif _st == "missing":
        _helper = ("vaultlayer_checkpoint_deepspeed.py" if integration.get("deepspeed")
                   else "vaultlayer_checkpoint_jax.py" if integration.get("jax")
                   else "vaultlayer_checkpoint.py")
        integ_line = f"{Y}not set up  (add manually: {_helper}){R}"
    else:
        integ_line = None

    gpu_label = display_gpu if gpu_was_explicit else f"{display_gpu}  (recommended)"

    SEP     = f"  {Y}{chr(9472)*54}{R}"
    cmd_str = " ".join(run_cmd.command)
    if len(cmd_str) > 60:
        cmd_str = cmd_str[:57] + "..."

    print("")
    print(f"  {BO}VaultLayer{R}")
    print(SEP)
    print(f"  {BO}Command:{R}     {cmd_str}")
    print(f"  {BO}GPU:{R}         {gpu_label}")
    print(f"  {BO}Cost:{R}        {cost_line}")
    print(f"  {BO}Checkpoint:{R}  every {ckpt_interval}s  ·  auto-migration  ·  99.9% SLA")
    if integ_line is not None:
        print(f"  {BO}Integration:{R} {integ_line}")
    # Transparency: quoted rate is an estimate. Final provider bill
    # (AWS / GCP actuals) reconciles ~48h after termination. Any delta
    # is absorbed by VaultLayer — the number you pay matches the quote.
    print(f"  {BO}Billing:{R}     rate is an estimate; reconciled vs provider's actual "
          f"bill within 48h.\n              You pay the quoted rate — VaultLayer absorbs any delta.")
    print(SEP)
    print("")

    # Step 3: Final confirmation
    if yes:
        print(f"  {G}Starting...{R}")
        print("")
        return True

    confirmed = click.confirm("  Start job?")
    print("")
    if not confirmed:
        print(f"  Aborted.")
    return confirmed
