"""
VaultLayer CLI — 'vaultlayer run' implementation.

RunCommand is the thin orchestrator that:
  1. Validates the command (multi-node guard, integration check)
  2. Sets up the job + agents
  3. Delegates subprocess management to cli._subprocess
  4. Produces the post-job invoice and FinOps report

Heavy logic lives in:
  cli._preflight   — multi-node guard, script integration check, pre-flight UI
  cli._subprocess  — process spawning, spinner, heartbeat, log buffering
  cli._dataset     — S3 → R2 dataset mirroring
"""
from __future__ import annotations

import asyncio
import logging
import os
import sys
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class RunCommand:
    """
    Wraps a training command under full VaultLayer protection.
    Zero changes required to the user's PyTorch/JAX code.
    """

    def __init__(
        self,
        command: list[str],
        job_name: str,
        gpu_type: str = "H100_80GB_SXM",
        model_params_billion: float = 7.0,
        preferred_providers: Optional[list] = None,
        excluded_providers: Optional[list] = None,
        data_uri: Optional[str] = None,
        docker_image: str = "",
        regions: Optional[list] = None,
        excluded_regions: Optional[list] = None,
    ):
        self.command              = command
        self.job_name             = job_name
        self.gpu_type             = gpu_type
        self.model_params_billion = model_params_billion
        self.preferred_providers  = preferred_providers or []   # provider_prices keys
        self.excluded_providers   = excluded_providers or []
        self.data_uri             = data_uri       # s3://bucket/prefix | r2://dataset-id | None
        self.docker_image         = docker_image   # container image for env replication
        self.regions              = regions or []
        self.excluded_regions     = excluded_regions or []
        self.failover_enabled     = False          # set by main.py --failover flag
        self.notify_webhook       = None
        self.yes                  = False          # set by main.py --yes flag
        self._training_proc       = None           # subprocess.Popen for SIGTERM
        self.train_mode           = "qlora"        # set by main.py --train-mode flag
        self.job_id               = str(uuid.uuid4())
        # Set by main.py after GPU hop consent flow
        self.hop_target_gpu       = None
        self.hop_fallback_gpu     = None
        # Set by main.py for API calls during execute
        self.vaultlayer_token     = ""
        self.api_url              = ""
        self.hourly_rate_usd      = 0.0
        self._tel                 = None           # telemetry — set during execute

    # ── Public entry point ────────────────────────────────────────────────────

    async def execute(self):
        """Entry point for 'vaultlayer run'."""
        from cli._preflight import check_multi_node, print_preflight

        check_multi_node(self.command)

        if not getattr(self, "_skip_preflight", False):
            confirmed = print_preflight(
                self,
                yes=getattr(self, "yes", False),
                train_mode=getattr(self, "train_mode", "qlora"),
            )
            if not confirmed:
                return

        # ── Dataset mirror ────────────────────────────────────────────────────
        await self._handle_dataset()

        # ── Agent / job setup ─────────────────────────────────────────────────
        try:
            from shared.config import load_config
            from shared.models import Job, JobStatus, Provider, GPUType
            from shared.queue import AgentQueue
            from agents.vault.agent import VaultAgent
            from agents.watchdog.agent import WatchdogAgent
            from agents.orchestration.agent import OrchestrationAgent
            from agents.finops.agent import FinOpsAgent
            from shared.telemetry import make_telemetry, MetricCategory
            from cli.notify import JobNotifier
            from shared.security import validate_credentials, print_credential_report, get_audit
            from agents.broker.agent import BrokerAgent
            from agents.pricing.agent import PricingAgent
            from agents.namespace.agent import NamespaceAgent
        except ImportError as e:
            print(f"  Import error: {e}")
            print("  Run: pip install vaultlayer")
            sys.exit(1)

        from shared.env_utils import load_vaultlayer_env
        load_vaultlayer_env()

        try:
            config = load_config()
        except EnvironmentError as e:
            print(f"  Config error: {e}")
            print("  Run: vaultlayer init --help")
            sys.exit(1)

        if self.model_params_billion > config.supported_max_params_billion:
            print(f"  Warning: {self.model_params_billion}B params exceeds MVP cap "
                  f"({config.supported_max_params_billion}B full fine-tune).")
            print("  Tip: use QLoRA (4-bit) to stay within supported range.\n")

        # ── Auto-detect: local GPU or provision remote? ────────────────────
        # If user has a GPU → run locally. If not → provision remote automatically.
        try:
            import torch
            _should_remote = not torch.cuda.is_available()
        except ImportError:
            _should_remote = True  # no torch = no GPU = remote

        if _should_remote:
            # Remote mode: minimal setup, no Redis, no agents
            # Only need broker for provisioning (uses managed credentials from API)
            from agents.broker.agent import BrokerAgent
            from shared.queue import AgentQueue as _AQ
            _dummy_queue = _AQ.__new__(_AQ)
            _dummy_queue.published = []
            _dummy_queue._job_states = {}
            _dummy_queue._price_cache = []
            async def _noop(*a, **kw): pass
            async def _noop_dict(*a, **kw): return {}
            async def _noop_list(*a, **kw): return []
            _dummy_queue.connect = _noop
            _dummy_queue.publish = _noop
            _dummy_queue.publish_critical = _noop
            _dummy_queue.set_job_state = _noop
            _dummy_queue.get_job_state = _noop_dict
            _dummy_queue.get_price_cache = _noop_list
            _dummy_queue.set_price_cache = _noop
            _dummy_queue.hget = _noop
            _dummy_queue.subscribe = _noop

            broker = BrokerAgent(config, _dummy_queue)

            # Resolve actual user_id from token via API (not config)
            _user_id = getattr(config, "user_id", "") or "default"
            _token = self.vaultlayer_token or os.environ.get("VAULTLAYER_TOKEN", "")
            if _token and _user_id == "default":
                try:
                    import httpx as _httpx_uid
                    _api = self.api_url or os.environ.get(
                        "VAULTLAYER_API_URL", "https://vaultlayer-production.up.railway.app")
                    _r = _httpx_uid.post(f"{_api}/api/v1/auth/validate", json={"token": _token}, timeout=8)
                    if _r.status_code == 200:
                        _uid = _r.json().get("user_id", "")
                        if _uid:
                            _user_id = _uid
                except Exception:
                    pass

            # Resolve GPU type — pricing keys may differ from enum values
            from shared.data_loader import resolve_gpu_enum
            _gpu_type_enum = resolve_gpu_enum(self.gpu_type)

            job = Job(
                job_id=self.job_id,
                user_id=_user_id,
                name=self.job_name,
                status=JobStatus.RUNNING,
                provider=Provider.AWS,  # placeholder; dispatcher picks the real one
                gpu_type=_gpu_type_enum,
                instance_id="pending",
                region=getattr(config.aws, "region", "us-east-1") if config.aws else "us-east-1",
                model_params_billion=self.model_params_billion,
                command=" ".join(self.command),
                docker_image=self.docker_image,
                environment={
                    **{k: os.environ[k] for k in [
                        "WANDB_API_KEY", "HF_TOKEN", "HUGGING_FACE_HUB_TOKEN",
                    ] if k in os.environ},
                    # Pass token + API URL so container can POST logs back
                    "VAULTLAYER_TOKEN": _token,
                    "VAULTLAYER_API_URL": self.api_url or os.environ.get(
                        "VAULTLAYER_API_URL", "https://vaultlayer-production.up.railway.app"),
                },
                preferred_providers=list(self.preferred_providers),
                excluded_providers=list(self.excluded_providers),
                regions=list(self.regions),
                excluded_regions=list(self.excluded_regions),
                failover_enabled=self.failover_enabled,
            )

            from datetime import datetime
            start = datetime.utcnow()
            from cli._remote import run_remote
            exit_code = await run_remote(self, job, broker, _dummy_queue)

            # Post-job reporting
            duration_h = (datetime.utcnow() - start).total_seconds() / 3600
            from shared.compute_tiers import get_aws_od_rate
            _aws_rate = get_aws_od_rate(job.gpu_type.value) if job.gpu_type else 0
            if exit_code == 0:
                print(f"\n  Job complete: {' '.join(self.command)}")
            else:
                print(f"\n  Job failed: {' '.join(self.command)}")
            print(f"  Duration: {duration_h:.1f} hours")
            print(f"  Rate: ${job.current_hourly_rate:.2f}/hr")

            # Restore config
            cp_path = Path.home() / ".vaultlayer" / "config.env.backup2"
            if cp_path.exists():
                import shutil
                shutil.copy(cp_path, Path.home() / ".vaultlayer" / "config.env")
            raise SystemExit(exit_code)

        # Redis URL must be set via UPSTASH_REDIS_URL in the local environment.
        # The /api/v1/config/runtime endpoint no longer vends redis_url (removed
        # intentionally — exposing shared-tenant Redis URLs to users is a security
        # boundary violation). Users must set UPSTASH_REDIS_URL in their .env.
        if not config.redis or not getattr(config.redis, "url", ""):
            raise RuntimeError(
                "Redis URL not configured. Set UPSTASH_REDIS_URL in your .env file.\n"
                "Run: vaultlayer init  to reconfigure."
            )

        queue = AgentQueue(config.redis.url)
        await queue.connect()

        _env_keys = [
            "WANDB_API_KEY", "HF_TOKEN", "HUGGING_FACE_HUB_TOKEN",
            "VAULTLAYER_DATASET_ID", "NCCL_DEBUG", "CUDA_VISIBLE_DEVICES",
            # Storage credentials — forwarded to GPU nodes for training data access
            "VL_S3_ACCESS_KEY_ID", "VL_S3_SECRET_ACCESS_KEY", "VL_S3_REGION",
            "VL_S3_ENDPOINT", "VL_S3_BUCKET",
            "VL_GCS_CREDENTIALS_JSON", "VL_GCS_PROJECT",
            "VL_AZURE_CONNECTION_STRING", "VL_AZURE_ACCOUNT_NAME", "VL_AZURE_ACCOUNT_KEY",
        ]
        job_environment = {k: os.environ[k] for k in _env_keys if k in os.environ}

        job = Job(
            job_id=self.job_id,
            user_id=getattr(config, "user_id", "default"),
            name=self.job_name,
            status=JobStatus.RUNNING,
            provider=Provider.AWS,  # placeholder; dispatcher picks the real one
            gpu_type=GPUType(self.gpu_type),
            instance_id="i-" + self.job_id[:8],
            region=config.aws.region,
            model_params_billion=self.model_params_billion,
            command=" ".join(self.command),
            docker_image=self.docker_image,
            environment=job_environment,
            preferred_providers=list(self.preferred_providers),
            excluded_providers=list(self.excluded_providers),
            regions=list(self.regions),
            excluded_regions=list(self.excluded_regions),
            failover_enabled=self.failover_enabled,
        )
        await queue.set_job_state(self.job_id, job.model_dump(mode="json"))

        vault              = VaultAgent(config, queue)
        watchdog           = WatchdogAgent(config, queue)
        orchestration      = OrchestrationAgent(config, queue)
        finops             = FinOpsAgent(config, queue)
        self._broker       = BrokerAgent(config, queue)
        self._pricing      = PricingAgent(config, queue)
        self._namespace    = NamespaceAgent(config, queue)
        self._tel          = make_telemetry(config)
        tel                = self._tel
        notifier           = JobNotifier(webhook_url=getattr(self, "notify_webhook", None))

        async def on_checkpoint(j: Job):
            model_path = os.environ.get("VAULTLAYER_MODEL_PATH", "/workspace/model")
            opt_path   = os.environ.get("VAULTLAYER_OPT_PATH",   "/workspace/optimizer")
            await vault.checkpoint(
                j, model_path,
                opt_path if Path(opt_path).exists() else None,
            )

        watchdog.register_job(job, on_checkpoint)
        orchestration.register_job(job)
        self._broker.register_job(job)
        self._pricing.register_job(job)

        # ── GPU hop consent ───────────────────────────────────────────────────
        await self._record_hop_consent()

        print("  Watchdog active  --  job is protected")
        await notifier.job_started(self.job_name, self.gpu_type, job.provider.value)
        get_audit().record("job_started", resource=job.job_id,
                           detail=f"gpu={self.gpu_type} provider={job.provider.value}")
        tel.event("job.started", tags={
            "job_id": job.job_id, "gpu": self.gpu_type,
            "model_params": str(self.model_params_billion),
            "provider": job.provider.value,
        }, job_id=job.job_id, category=MetricCategory.JOB)
        print("  Broker active    --  migration engine ready")
        print("  Pricing active   --  scanning for arbitrage")
        print("  Namespace active --  Neutral Zone mounted")
        print("  Starting your command...\n")

        # ── Capacity slot ─────────────────────────────────────────────────────
        _provider_display = job.provider.value.replace("_", " ").title() if job.provider else ""
        try:
            from shared.provider_capacity import claim_provider_slot
            if _provider_display and not claim_provider_slot(_provider_display, job.job_id):
                raise RuntimeError(
                    f"{_provider_display} is at concurrent job capacity. "
                    f"Try again shortly or choose a different provider with --gpu."
                )
        except ImportError:
            pass

        start = datetime.utcnow()
        try:
            exit_code = await self._run_subprocess(job, vault, watchdog, orchestration)
        finally:
            try:
                from shared.provider_capacity import release_provider_slot
                released = release_provider_slot(job.job_id)
                if released:
                    logger.info(f"Capacity slot released for {released} (job {job.job_id} finished)")
            except ImportError:
                pass

        # ── Post-job state update ─────────────────────────────────────────────
        terminal_status = JobStatus.COMPLETED if exit_code == 0 else JobStatus.FAILED
        try:
            _local_state = await queue.get_job_state(self.job_id)
            if _local_state:
                _local_state["status"] = terminal_status.value
                await queue.set_job_state(self.job_id, _local_state)
        except Exception as _upd_err:
            logger.debug(f"Could not update job state in Redis (non-fatal): {_upd_err}")

        # ── R2 log tail (if job migrated to new node) ─────────────────────────
        await self._tail_migrated_logs(queue, vault)

        # ── Invoice + FinOps report ───────────────────────────────────────────
        duration_h = (datetime.utcnow() - start).total_seconds() / 3600
        job.status             = JobStatus.COMPLETED
        job.completed_at       = datetime.utcnow()
        # Compute actual spend + AWS OD equivalent using real per-GPU rates
        from shared.compute_tiers import get_aws_od_rate
        _hourly_rate = job.current_hourly_rate or 0.0
        _aws_od_rate = get_aws_od_rate(job.gpu_type.value) if job.gpu_type else 0.0
        job.total_spend_usd    = round(duration_h * _hourly_rate, 4)
        job.aws_equivalent_usd = round(duration_h * _aws_od_rate, 4)

        # Generate invoice via API (user's machine) or direct (Railway)
        try:
            import httpx as _inv_httpx
            _inv_token = self.vaultlayer_token or os.environ.get("VAULTLAYER_TOKEN", "")
            _inv_api = self.api_url or os.environ.get("VAULTLAYER_API_URL",
                                                       "https://vaultlayer-production.up.railway.app")
            if _inv_token:
                _inv_resp = _inv_httpx.post(
                    f"{_inv_api}/api/v1/jobs/{job.job_id}/invoice",
                    headers={"Authorization": f"Bearer {_inv_token}"},
                    timeout=15,
                )
                if _inv_resp.status_code == 200:
                    _invoice_id = _inv_resp.json().get("invoice_id")
                    if _invoice_id:
                        logger.info(f"Invoice created: {_invoice_id} for job {job.job_id}")
        except Exception as _inv_err:
            logger.debug(f"Invoice creation failed (non-fatal): {_inv_err}")

        tel.event("job.completed", tags={
            "exit_code": str(exit_code),
            "duration_h": str(round(duration_h, 2)),
            "savings_usd": str(round(job.aws_equivalent_usd - job.total_spend_usd, 2)),
        }, job_id=job.job_id, category=MetricCategory.JOB)
        tel.timing("job.total_duration_ms", duration_h * 3600 * 1000,
                   job_id=job.job_id, category=MetricCategory.JOB)
        await tel.flush_now()
        savings_usd = job.aws_equivalent_usd - job.total_spend_usd
        savings_pct = (savings_usd / job.aws_equivalent_usd * 100) if job.aws_equivalent_usd else 0
        await notifier.job_complete(self.job_name, duration_h, savings_usd, savings_pct)
        report = await finops.generate_job_report(job)
        print(finops.format_cli_summary(report))

        await queue.disconnect()
        sys.exit(exit_code)

    # ── Private helpers ───────────────────────────────────────────────────────

    async def _handle_dataset(self) -> None:
        """Mirror cloud dataset to R2 (if needed) before training starts."""
        from cli._dataset import mirror_cloud_data

        uri = self.data_uri or ""
        if uri.startswith(("s3://", "gs://", "az://")):
            dataset_id = await mirror_cloud_data(uri, yes=self.yes)
            if dataset_id:
                os.environ["VAULTLAYER_DATASET_ID"] = dataset_id
                logger.info(f"Dataset mirrored → dataset_id={dataset_id}")
        elif uri.startswith("r2://"):
            dataset_id = uri[len("r2://"):]
            os.environ["VAULTLAYER_DATASET_ID"] = dataset_id
            logger.info(f"Using existing R2 dataset: {dataset_id}")

    async def _record_hop_consent(self) -> None:
        """POST /hop-consent after the job is registered, so PricingAgent watcher picks it up."""
        if not (self.hop_target_gpu and self.hop_fallback_gpu):
            return
        try:
            import httpx as _httpx
            _token = self.vaultlayer_token or os.environ.get("VAULTLAYER_TOKEN", "")
            _api   = self.api_url or os.environ.get("VAULTLAYER_API_URL",
                                                      "https://vaultlayer-api.railway.app")
            resp = _httpx.post(
                f"{_api}/api/v1/jobs/{self.job_id}/hop-consent",
                json={
                    "fallback_gpu": self.hop_fallback_gpu,
                    "target_gpu":   self.hop_target_gpu,
                    "consented":    True,
                },
                headers={"Authorization": f"Bearer {_token}"},
                timeout=8,
            )
            resp.raise_for_status()
            logger.info(
                f"[hop-consent] recorded: job={self.job_id} "
                f"{self.hop_fallback_gpu} → {self.hop_target_gpu}"
            )
        except Exception as _hce:
            logger.warning(f"[hop-consent] failed to record consent (non-fatal): {_hce}")

    async def _run_subprocess(self, job, vault, watchdog, orchestration) -> int:
        """Delegate subprocess management to cli._subprocess."""
        from cli._subprocess import run_subprocess
        return await run_subprocess(self, job, vault, watchdog, orchestration)

    async def _tail_migrated_logs(self, queue, vault) -> None:
        """
        After the local subprocess exits, poll R2 log tail if the job is still
        RUNNING (meaning it migrated to a new node).
        """
        from shared.models import JobStatus
        try:
            _tail_state  = await queue.get_job_state(self.job_id)
            _tail_status = (_tail_state or {}).get("status", "")
            if _tail_status != JobStatus.RUNNING.value:
                return
            print("\n  ── migrated to new node, streaming from R2 log tail ──\n")
            _last_line = 0
            while True:
                try:
                    _obj = vault.r2._s3.get_object(
                        Bucket=vault.r2.bucket,
                        Key=f"logs/{self.job_id}/tail.txt",
                    )
                    _lines = _obj["Body"].read().decode("utf-8", errors="replace").splitlines()
                    for _line in _lines[_last_line:]:
                        print(_line)
                    _last_line = len(_lines)
                except Exception:
                    pass
                await asyncio.sleep(3)
                _tail_state  = await queue.get_job_state(self.job_id)
                _tail_status = (_tail_state or {}).get("status", "")
                if _tail_status in (JobStatus.COMPLETED.value, JobStatus.FAILED.value):
                    break
        except Exception as _tail_err:
            logger.debug(f"R2 log tail error (non-fatal): {_tail_err}")

    # ── Legacy compat ─────────────────────────────────────────────────────────

    def _check_multi_node(self) -> None:
        """Kept for backward compat — delegates to cli._preflight."""
        from cli._preflight import check_multi_node
        check_multi_node(self.command)

    def _check_script_integration(self) -> dict:
        """Kept for backward compat — delegates to cli._preflight."""
        from cli._preflight import check_script_integration
        return check_script_integration(self.command)

    def _print_preflight(self, yes: bool = False, train_mode: str = "qlora") -> bool:
        """Kept for backward compat — delegates to cli._preflight."""
        from cli._preflight import print_preflight
        return print_preflight(self, yes=yes, train_mode=train_mode)

    async def _maybe_mirror_s3_data(self, s3_uri: str) -> Optional[str]:
        """Kept for backward compat — delegates to cli._dataset.mirror_s3_data."""
        from cli._dataset import mirror_s3_data
        return await mirror_s3_data(s3_uri, yes=self.yes)

    def _print_banner(self):
        pass  # replaced by _print_preflight
