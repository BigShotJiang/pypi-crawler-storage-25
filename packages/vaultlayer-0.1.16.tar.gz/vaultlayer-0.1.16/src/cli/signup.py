"""
vaultlayer signup — Create a new VaultLayer account from the CLI.

Flow:
  1. Enter your email
  2. We send a 6-digit verification code
  3. Paste the code
  4. Account created, token saved, ready to run jobs
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import click


from shared.api_utils import get_api_url as _api_url


def _save_token(token: str) -> None:
    cfg_dir = Path.home() / ".vaultlayer"
    cfg_dir.mkdir(mode=0o700, exist_ok=True)
    config_env = cfg_dir / "config.env"

    lines = []
    if config_env.exists():
        lines = [l for l in config_env.read_text().splitlines() if not l.startswith("VAULTLAYER_TOKEN=")]
    lines.append(f"VAULTLAYER_TOKEN={token}")
    config_env.write_text("\n".join(lines) + "\n")
    config_env.chmod(0o600)


@click.command(hidden=True)
@click.option("--email", default=None, help="Your email address (prompted if not provided)")
def signup(email: str | None):
    """(Disabled) VaultLayer is invite-only."""
    click.echo("")
    click.echo("  vaultlayer signup is not available.")
    click.echo("  VaultLayer is invite-only. Request access at vaultlayer.com")
    click.echo("  Once invited, run:  vaultlayer init")
    click.echo("")
    raise SystemExit(1)

    import httpx

    api = _api_url()

    click.echo("")
    click.echo("  Create a VaultLayer account")
    click.echo("  ===========================")
    click.echo("")

    if not email:
        email = click.prompt("  Email").strip()

    if not email or "@" not in email:
        click.echo("  Invalid email address.")
        raise SystemExit(1)

    # Step 1: Request verification code
    click.echo(f"  Sending verification code to {email}...")
    try:
        resp = httpx.post(f"{api}/api/v1/auth/signup", json={"email": email}, timeout=15)
        if resp.status_code == 409:
            click.echo("")
            click.echo("  Account already exists for this email.")
            click.echo("  Run: vaultlayer login")
            raise SystemExit(0)
        if resp.status_code == 429:
            click.echo("")
            click.echo("  Too many attempts. Try again in an hour.")
            raise SystemExit(1)
        resp.raise_for_status()
    except httpx.HTTPStatusError as e:
        msg = ""
        try:
            msg = e.response.json().get("detail", "")
        except Exception:
            pass
        click.echo(f"  Error: {msg or e}")
        raise SystemExit(1)
    except httpx.ConnectError:
        click.echo("  Could not connect to VaultLayer API. Check your internet connection.")
        raise SystemExit(1)

    # Step 2: Get code from user
    click.echo("")
    click.echo("  Check your email inbox (also check spam).")
    click.echo("")
    code = click.prompt("  Verification code").strip()

    # Step 3: Verify code
    try:
        resp = httpx.post(f"{api}/api/v1/auth/verify", json={
            "email": email, "code": code, "action": "signup",
        }, timeout=15)
        if resp.status_code == 401:
            click.echo("  Invalid code. Check your email and try again.")
            raise SystemExit(1)
        if resp.status_code == 410:
            click.echo("  Code expired. Run 'vaultlayer signup' again.")
            raise SystemExit(1)
        resp.raise_for_status()
    except httpx.HTTPStatusError as e:
        msg = ""
        try:
            msg = e.response.json().get("detail", "")
        except Exception:
            pass
        click.echo(f"  Error: {msg or e}")
        raise SystemExit(1)

    data = resp.json()
    token = data.get("token", "")
    balance = data.get("balance_credits", 0)

    # Step 4: Save token
    _save_token(token)

    click.echo("")
    click.echo("  Account created!")
    click.echo(f"  Email:   {email}")
    click.echo(f"  Credits: {balance} (${balance/100:.2f})")
    click.echo(f"  Token:   saved to ~/.vaultlayer/config.env")
    click.echo("")
    click.echo("  You're ready to go. Try:")
    click.echo("    vaultlayer run --gpu A10G python examples/train_quick.py")
    click.echo("")
