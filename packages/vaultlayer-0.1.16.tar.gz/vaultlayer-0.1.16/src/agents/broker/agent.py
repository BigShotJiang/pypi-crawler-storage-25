from __future__ import annotations
"""
VaultLayer - Broker Agent
Provisions nodes and executes migrations ordered by Orchestration Agent.
Claude coverage: ~0% (all provisioning logic is deterministic code; no LLM required)
"""
import asyncio
import os
import logging
import json
import shlex
from datetime import datetime
from typing import Optional
import time
import aiohttp
import boto3
from shared.config import VaultLayerConfig
from shared.models import AgentEvent, EventType, Job, JobStatus, Provider, GPUType
from shared.queue import AgentQueue, make_event
from shared.telemetry import make_telemetry, MetricCategory
from shared.sts import STSSessionManager
from shared.r2_credentials import R2CredentialsMinter, ScopedCredentials
from shared.job_logger import log_event
from shared.retry import sync_retry
from agents.broker.warm_pool import WarmPoolManager, WarmNode  # P0-L3

logger = logging.getLogger(__name__)


_paramiko = None  # always defined so tests can patch agents.broker.agent._paramiko
try:
    import paramiko as _paramiko
    _HAS_PARAMIKO = True
except ImportError:
    _HAS_PARAMIKO = False
    logger.debug("paramiko not installed -- SSH-based job restart disabled. pip install paramiko")

from shared.data_loader import get_instance_string, resolve_gpu_key, is_gpu_available, get_provider_prices
try:
    from shared.provider_capacity import claim_provider_slot, release_provider_slot
    _HAS_CAPACITY = True
except ImportError:
    _HAS_CAPACITY = False
    def claim_provider_slot(p, j): return True
    def release_provider_slot(j): return None

try:
    from shared.price_guard import check_margin, check_price_freshness, MarginViolation, PriceStaleError, VL_MARGIN
    _PRICE_GUARD = True
except ImportError:
    _PRICE_GUARD = False
    VL_MARGIN = 1.15

AWS_INSTANCE_MAP = {
    GPUType.H100_80GB_SXM: "p4de.24xlarge",
    GPUType.A100_80GB_SXM: "p4d.24xlarge",
    GPUType.A100_40GB:     "p4d.24xlarge",
    GPUType.A10G:          "g5.xlarge",
}

# ---------------------------------------------------------------------------
# Level 2 cold-start fix: Pre-baked AMIs
#
# These AMIs have the listed Docker images pre-pulled and cached on-disk.
# Using a pre-baked AMI eliminates the 5-7 minute docker pull entirely,
# reducing time-to-first-training-step from ~7 min -> < 60s.
#
# Key format: docker_image_substring -> {region -> ami_id}
# Match is checked via substring to handle tags (e.g. "pytorch/pytorch:2.1-cuda12.1-*")
#
# To add a new pre-baked AMI:
#   1. Launch a Deep Learning AMI
#   2. Run: docker pull {your_image}
#   3. Create an AMI from that instance
#   4. Add the AMI ID here
# ---------------------------------------------------------------------------
PREBAKED_AMI_MAP: dict[str, dict[str, str]] = {
    # PyTorch 2.1 + CUDA 12.1 -- the most common fine-tuning base image
    "pytorch/pytorch:2.1": {
        "us-east-1":      "ami-vl-pytorch21-cuda121-use1",   # placeholder -- replace with real AMI IDs
        "us-west-2":      "ami-vl-pytorch21-cuda121-usw2",
        "eu-west-1":      "ami-vl-pytorch21-cuda121-euw1",
    },
    # NVIDIA NGC PyTorch 23.10 -- common for large-scale training
    "nvcr.io/nvidia/pytorch:23.10": {
        "us-east-1":      "ami-vl-ngc2310-use1",
        "us-west-2":      "ami-vl-ngc2310-usw2",
    },
}

class RegionNotAllowedError(Exception):
    """Raised when a target region violates the job's allowed/blocked_regions constraint."""


def _find_prebaked_ami(docker_image: str, region: str) -> Optional[str]:
    """
    Return a pre-baked AMI ID if the docker_image matches a known cached image
    in the given region.  Returns None if no pre-baked AMI is available.

    Pre-baked AMIs skip docker pull entirely -- the image is already on the
    instance's local storage, reducing cold-start time from 5-7 min to <60s.
    """
    if not docker_image:
        return None
    for image_key, region_map in PREBAKED_AMI_MAP.items():
        if image_key in docker_image:
            ami = region_map.get(region)
            if ami and not ami.startswith("ami-vl-"):   # skip placeholder IDs
                return ami
    return None



class BrokerAgent:
    """
    Agent 5 - The Broker.
    Executes migrations commanded by Orchestration Agent.
    Publishes to:  vaultlayer:broker.status
    Listens to:    vaultlayer:orchestration.command
    """
    AGENT_NAME = "broker_agent"

    # Tag applied to all VaultLayer-managed AWS resources for least-privilege RBAC
    MANAGED_TAG = {"Key": "Project", "Value": "VaultLayer-Managed"}

    def __init__(self, config: VaultLayerConfig, queue: AgentQueue):
        self.config = config
        self.queue = queue
        self._active_migrations: dict[str, dict] = {}
        self._migration_locks: dict = {}
        # spend_ids: instance_id -> spend_ledger UUID
        # Set by _record_provision_spend(), consumed by _hard_fence_and_confirm().
        self._spend_ids: dict[str, str] = {}
        # run_ids: instance_id -> job_runs UUID
        # Set by _record_provision_spend(), consumed by _hard_fence_and_confirm().
        self._run_ids: dict[str, str] = {}
        # provision_info: instance_id -> {rate_per_hr, provisioned_at}
        # Stored at provision time; used by close_run() to compute billing.
        self._provision_info: dict[str, dict] = {}
        # nebius_token_cache: (token, expiry_timestamp) -- IAM tokens are valid 12h.
        self._nebius_token_cache: Optional[tuple[str, float]] = None
        # gcp_sa_info: instance_id -> service_account_info dict for managed-creds GCP jobs.
        # Populated by provision_gcp() when using managed (Railway) credentials so that
        # _hard_fence_gcp() can terminate even when self.config.gcp is None.
        self._gcp_sa_info: dict[str, dict] = {}
        self._http_session = None
        self._tel = make_telemetry(queue=queue, agent_name="broker_agent") if queue else None
        self._sts = STSSessionManager(config)
        # Dynamic GPU name resolution with caching (replaces hardcoded provider_instance_maps)
        from shared.gpu_resolver import GPUResolver
        self.gpu_resolver = GPUResolver()
        # P0-L1: Per-job asyncio.Events set when CHECKPOINT_READY arrives from orchestration.
        self._checkpoint_events: dict[str, asyncio.Event] = {}

        # P0-L3: Warm pool manager -- pre-warmed standby nodes to eliminate cold-start latency.
        self._warm_pool: Optional[WarmPoolManager] = None
        # Job-scoped R2 credential minter.
        cf = config.cloudflare
        self._r2_minter: Optional[R2CredentialsMinter] = (
            R2CredentialsMinter.from_config(cf) if (cf and cf.cf_master_token) else None
        )

    def register_job(self, job) -> None:
        """Called by CLI to associate a job with this broker instance."""
        self._active_migrations.setdefault(job.job_id, {})
        # P0-L3: Trigger background pre-warming
        if self._warm_pool is not None:
            provider = getattr(job, "provider", Provider.LAMBDA_LABS)
            gpu_type = getattr(job, "gpu_type", None)
            if gpu_type is not None:
                asyncio.create_task(
                    self._warm_pool.prewarm(gpu_type, provider),
                    name=f"warm-pool-prewarm-{job.job_id[:8]}",
                )

    def _get_provider_config(self, attr: str):
        """
        Safely get provider config. Returns None and logs warning if not configured.
        Prevents AttributeError crashes when API key is missing from .env.
        """
        cfg = getattr(self.config, attr, None)
        if cfg is None:
            logger.warning(f"Provider config missing: {attr}. Set the API key in .env to enable this provider.")
        return cfg

    # ---------------------------------------------------------------------------
    # Billing / spend recording  (delegated to agents.broker.billing)
    # ---------------------------------------------------------------------------

    def _record_provision_spend(
        self,
        job: "Job",
        provider: str,
        gpu_type: str,
        instance_id: str,
        provisioned_at: "datetime",
        rate_per_hr: float,
        is_test: bool = False,
        is_hop_leg: bool = False,
        migrated_from_run_id: str | None = None,
    ) -> None:
        from agents.broker.billing import record_provision_spend
        record_provision_spend(
            self, job, provider, gpu_type, instance_id, provisioned_at,
            rate_per_hr, is_test, is_hop_leg, migrated_from_run_id,
        )

    def _get_live_price(self, provider, gpu_type):
        from agents.broker.billing import get_live_price
        return get_live_price(self, provider, gpu_type)

    def _get_user_charge(self, provider_name: str, gpu_key: str,
                         baseline_provider: Optional[str] = None) -> Optional[float]:
        from agents.broker.billing import get_user_charge
        return get_user_charge(self, provider_name, gpu_key, baseline_provider)

    # ---------------------------------------------------------------------------
    # Managed credentials
    # ---------------------------------------------------------------------------

    async def _get_managed_credentials(self, provider: str, job_id: str) -> Optional[dict]:
        """
        Read VaultLayer's managed credentials for a cloud provider.

        Called from provider modules (lambda_labs.py, runpod.py, aws.py, …)
        when no local BYOC key is configured. Returns the credentials dict
        (e.g. {"api_key": "ll-xxx..."}) or None if the provider isn't
        configured on this deployment.

        Previously this made an HTTP POST to /api/v1/credentials/provider
        — a Railway→Railway round trip that also exposed a public
        credential-vending endpoint to any authed user. The endpoint was
        removed in the security audit. Now we read env vars directly,
        same Railway process, no network, no public surface.

        job_id is accepted for audit-log compatibility but no longer used.
        """
        from api.credentials import _read_provider_credentials
        creds = _read_provider_credentials(provider)
        if creds is None:
            logger.warning(
                "[broker] Managed credentials not configured for provider=%s "
                "(set VL_* env vars on Railway)",
                provider,
            )
            return None
        logger.info(
            "[broker] Read managed credentials for provider=%s job=%s keys=%s",
            provider, job_id, list(creds.keys()),
        )
        return creds

    async def _http(self):
        """Lazy-init shared aiohttp session for connection pooling."""
        import aiohttp
        if self._http_session is None or self._http_session.closed:
            self._http_session = aiohttp.ClientSession()
        return self._http_session

    # ---------------------------------------------------------------------------
    # Provider provision wrappers (thin delegation to provider modules)
    # ---------------------------------------------------------------------------

    async def provision_lambda(self, gpu_type: GPUType, job: Job) -> Optional[str]:
        """Provision a Lambda Labs instance. Returns instance ID or None."""
        from agents.broker.providers import lambda_labs
        return await lambda_labs.provision(self, gpu_type, job)

    async def provision_coreweave(self, gpu_type: GPUType, job: Job) -> Optional[str]:
        """Provision a CoreWeave VM. Returns instance name or None."""
        from agents.broker.providers import coreweave
        return await coreweave.provision(self, gpu_type, job)

    def _get_r2_credentials_for_node(self, job: Job) -> tuple[str, str, str]:
        from agents.broker.startup_scripts import get_r2_credentials_for_node
        return get_r2_credentials_for_node(self, job)

    def prepare_startup(self, provider: Provider, job: Job):
        """Prepare startup script for any provider -- single entry point.

        Selects the correct builder (VM vs container) and applies the correct
        encoding (plain, base64, RunPod pre_start) based on the provider registry.

        Returns a StartupPayload that provision_*() methods use directly.
        """
        from agents.broker.provider_startup import (
            PROVIDER_DEPLOY_REGISTRY, DeploymentType, ScriptEncoding,
            StartupPayload, encode_script, build_runpod_docker_args,
        )

        config = PROVIDER_DEPLOY_REGISTRY.get(provider)
        if not config:
            raise ValueError(f"Provider {provider} not in deployment registry")

        # Step 1: Select builder based on deployment type
        if config.deployment_type == DeploymentType.CONTAINER:
            raw_script = self._build_container_onstart(job)
        else:
            raw_script = self._build_vm_startup_script(job)

        # Step 2: Encode per provider spec
        encoded = encode_script(raw_script, config.encoding)

        # Step 3: Build payload
        payload = StartupPayload(
            script=encoded,
            deployment_type=config.deployment_type,
            encoding=config.encoding,
            raw_script=raw_script,
        )

        # Step 4: RunPod-specific packaging
        if config.encoding == ScriptEncoding.RUNPOD_PRE_START:
            env_vars = {"VAULTLAYER_JOB_ID": job.job_id, "VL_ONSTART_B64": encoded}
            env_vars.update(job.environment or {})
            # Remove VL_SCRIPT_B64 from env to stay under GraphQL payload limit
            env_vars.pop("VL_SCRIPT_B64", None)
            payload.runpod_env = env_vars
            payload.runpod_docker_args = build_runpod_docker_args()

        return payload

    def _build_vm_startup_script(self, job: Job) -> str:
        from agents.broker.startup_scripts import build_vm_startup_script
        return build_vm_startup_script(self, job)

    def _build_container_onstart(self, job: Job) -> str:
        from agents.broker.startup_scripts import build_container_onstart
        return build_container_onstart(self, job)

    def _build_userdata(self, job: Job) -> str:
        from agents.broker.startup_scripts import build_userdata
        return build_userdata(self, job)

    def _create_launch_template(self, ec2, job: Job, gpu_type: GPUType, region: str) -> str:
        """Create a dynamic EC2 Launch Template for this job. Returns template name."""
        instance_type = AWS_INSTANCE_MAP.get(gpu_type, "p4d.24xlarge")
        template_name = f"vl-{job.job_id[:8]}-{gpu_type.value[:12]}"
        prebaked_ami = _find_prebaked_ami(job.docker_image or "", region) if job.docker_image else None
        if prebaked_ami:
            base_ami = prebaked_ami
            logger.info(f"Cold-start: using pre-baked AMI {prebaked_ami} for {job.docker_image!r}")
        else:
            try:
                _res = ec2.describe_images(
                    Owners=["099720109477"],
                    Filters=[
                        {"Name": "name", "Values": ["ubuntu/images/hvm-ssd/ubuntu-jammy-22.04-amd64-server-*"]},
                        {"Name": "state", "Values": ["available"]},
                        {"Name": "architecture", "Values": ["x86_64"]},
                    ],
                )
                _imgs = sorted(_res["Images"], key=lambda x: x["CreationDate"], reverse=True)
                if not _imgs:
                    raise ValueError("No Ubuntu 22.04 AMIs found in region")
                base_ami = _imgs[0]["ImageId"]
            except Exception as _ami_err:
                base_ami = os.environ.get("VL_AWS_AMI_ID", "")
                if not base_ami:
                    logger.error(f"[AWS] Cannot resolve AMI for region {region} ({_ami_err}).")
                    return None
        _instance_profile = os.environ.get("VL_AWS_INSTANCE_PROFILE", "")
        _key_name = f"vaultlayer-{region}"
        try:
            ec2.describe_key_pairs(KeyNames=[_key_name])
        except Exception:
            try:
                _kp = ec2.create_key_pair(KeyName=_key_name)
                _key_dir = os.path.expanduser("~/.vaultlayer/keys")
                os.makedirs(_key_dir, mode=0o700, exist_ok=True)
                _pem_path = os.path.join(_key_dir, f"{_key_name}.pem")
                with open(_pem_path, "w") as _f:
                    _f.write(_kp["KeyMaterial"])
                os.chmod(_pem_path, 0o600)
            except Exception as _kp_err:
                _key_name = ""
        _launch_template_data: dict = {
            "ImageId": base_ami, "InstanceType": instance_type,
            "UserData": self._build_userdata(job),
        }
        if _key_name:
            _launch_template_data["KeyName"] = _key_name
        if _instance_profile:
            _launch_template_data["IamInstanceProfile"] = {"Name": _instance_profile}
        ec2.create_launch_template(
            LaunchTemplateName=template_name,
            LaunchTemplateData={
                **_launch_template_data,
                "TagSpecifications": [{
                    "ResourceType": "instance",
                    "Tags": [self.MANAGED_TAG, {"Key": "VaultLayerJob", "Value": job.job_id},
                             {"Key": "VaultLayerName", "Value": job.name}],
                }],
            },
            TagSpecifications=[{
                "ResourceType": "launch-template",
                "Tags": [self.MANAGED_TAG, {"Key": "VaultLayerJob", "Value": job.job_id}],
            }],
        )
        logger.info(f"Launch template created: {template_name}")
        return template_name

    def _check_region_allowed(self, region: str, job: Job) -> None:
        """Raise RegionNotAllowedError if region violates job's compliance constraints."""
        if job.excluded_regions and region in job.excluded_regions:
            raise RegionNotAllowedError(
                f"Region '{region}' is excluded for job {job.job_id} "
                f"(excluded_regions={job.excluded_regions})"
            )
        if job.regions and region not in job.regions:
            raise RegionNotAllowedError(
                f"Region '{region}' is not in allowed regions for job {job.job_id} "
                f"(regions={job.regions})"
            )

    def _resolve_target_region(self, job: Job) -> str:
        """Return the optimal AWS region for spot provisioning."""
        dataset_region = getattr(job, "dataset_region", "") or ""
        if dataset_region and dataset_region.startswith("us-") or dataset_region.startswith("eu-") or \
                dataset_region.startswith("ap-") or dataset_region.startswith("ca-") or \
                dataset_region.startswith("sa-") or dataset_region.startswith("af-") or \
                dataset_region.startswith("me-"):
            logger.info(
                f"[Broker] Region pinning: targeting {dataset_region} (S3 bucket region) "
                f"for job {job.job_id} to eliminate egress costs"
            )
            return dataset_region
        if self.config.aws:
            return self.config.aws.region
        return os.environ.get("AWS_DEFAULT_REGION", "us-west-2")

    async def provision_aws(self, gpu_type: GPUType, job: Job,
                            preferred_az: str = "") -> Optional[str]:
        from agents.broker.providers import aws
        return await aws.provision(self, gpu_type, job, preferred_az=preferred_az)

    async def provision_aws_on_demand(self, gpu_type: GPUType, job: Job) -> Optional[str]:
        from agents.broker.providers import aws
        return await aws.provision_on_demand(self, gpu_type, job)

    async def provision_runpod(self, gpu_type: GPUType, job: Job) -> Optional[str]:
        from agents.broker.providers import runpod
        return await runpod.provision(self, gpu_type, job)

    async def _runpod_find_gpu_id(self, api_key: str, gpu_key: str) -> Optional[str]:
        from agents.broker.providers import runpod
        return await runpod.find_gpu_id(self, api_key, gpu_key)

    async def provision_vast(self, gpu_type: GPUType, job: Job) -> Optional[str]:
        from agents.broker.providers import vast_ai
        return await vast_ai.provision(self, gpu_type, job)

    async def provision_voltage_park(self, gpu_type: GPUType, job: Job) -> Optional[str]:
        from agents.broker.providers import voltage_park
        return await voltage_park.provision(self, gpu_type, job)

    async def provision_crusoe(self, gpu_type: GPUType, job: Job) -> Optional[str]:
        from agents.broker.providers import crusoe
        return await crusoe.provision(self, gpu_type, job)

    async def provision_nebius(self, gpu_type: GPUType, job: Job) -> Optional[str]:
        from agents.broker.providers import nebius
        return await nebius.provision(self, gpu_type, job)

    async def provision_hyperstack(self, gpu_type: GPUType, job: Job) -> Optional[str]:
        from agents.broker.providers import hyperstack
        return await hyperstack.provision(self, gpu_type, job)

    async def provision_gcp(self, gpu_type: GPUType, job: Job) -> Optional[str]:
        from agents.broker.providers import gcp
        return await gcp.provision(self, gpu_type, job)

    async def provision_azure(self, gpu_type: GPUType, job: Job) -> Optional[str]:
        from agents.broker.providers import azure
        return await azure.provision(self, gpu_type, job)

    # ---------------------------------------------------------------------------
    # SSH / node interaction wrappers  (delegated to agents.broker.ssh)
    # ---------------------------------------------------------------------------

    @staticmethod
    def _parse_command(command) -> list:
        from agents.broker.ssh import parse_command
        return parse_command(command)

    async def _wait_for_ssh(self, host: str, timeout: int = 180) -> bool:
        from agents.broker.ssh import wait_for_ssh
        return await wait_for_ssh(self, host, timeout)

    async def _ssh_exec(self, host: str, ssh_key: str, cmd: str, timeout: float = 30.0) -> str:
        from agents.broker.ssh import ssh_exec
        return await ssh_exec(self, host, ssh_key, cmd, timeout)

    async def _resolve_instance_host(self, instance_id: str, provider: Provider) -> Optional[str]:
        from agents.broker.ssh import resolve_instance_host
        return await resolve_instance_host(self, instance_id, provider)

    async def _wait_for_image_ready(
        self, host: str, ssh_key: str, job: Job,
        poll_interval: int = 10, timeout: int = 600,
    ) -> bool:
        from agents.broker.ssh import wait_for_image_ready
        return await wait_for_image_ready(self, host, ssh_key, job, poll_interval, timeout)

    async def _wait_for_bootstrap(
        self, host: str, ssh_key: str, job: Job, timeout: int = 300,
    ) -> bool:
        from agents.broker.ssh import wait_for_bootstrap
        return await wait_for_bootstrap(self, host, ssh_key, job, timeout)

    async def _prefetch_checkpoint(self, host: str, ssh_key: str, job: Job, resume_checkpoint: str) -> None:
        from agents.broker.ssh import prefetch_checkpoint
        return await prefetch_checkpoint(self, host, ssh_key, job, resume_checkpoint)

    async def _probe_cuda(
        self,
        host: str,
        ssh_key: str,
        min_driver_version: str = "525.0",
        job: Optional["Job"] = None,
    ) -> tuple[bool, str]:
        from agents.broker.ssh import probe_cuda
        return await probe_cuda(self, host, ssh_key, min_driver_version, job)

    async def _restart_job_on_node(self, host: str, ssh_key: str,
                                    command, job_id: str,
                                    resume_checkpoint: str = "") -> bool:
        from agents.broker.ssh import restart_job_on_node
        return await restart_job_on_node(self, host, ssh_key, command, job_id, resume_checkpoint)

    # ---------------------------------------------------------------------------
    # Fencing / termination
    # ---------------------------------------------------------------------------

    async def _fence_old_node(self, job: Job) -> None:
        """STONITH: terminate the old training process before provisioning new node.
        Kept for backward compatibility -- delegates to _hard_fence_and_confirm."""
        await self._hard_fence_and_confirm(job)

    async def _fence_old_node_by_id(self, instance_id: str, provider: Provider) -> None:
        """P0-L3: Terminate a specific instance (e.g. an unclaimed warm-pool node)."""
        stub = Job(
            job_id=f"warm-pool-fence-{instance_id[:8]}",
            user_id="vaultlayer-system",
            name="warm-pool-fence",
            command="",
            provider=provider,
            instance_id=instance_id,
            gpu_type=GPUType.A100,  # sentinel — fence stubs don't run training
        )
        await self._hard_fence_and_confirm(stub)

    async def _hard_fence_and_confirm(self, job: Job) -> None:
        """Hard STONITH via provider terminate API (not SSH).

        Calls the provider's terminate API and waits for confirmed termination before
        returning.  This eliminates split-brain writes to R2.

        Always writes spend_ledger settle record after confirmed termination.
        """
        if not job.instance_id or not job.provider:
            logger.warning(
                f"[Broker] _hard_fence_and_confirm: missing instance_id={job.instance_id!r} "
                f"or provider={job.provider!r} for job "
                f"{str(getattr(job, 'job_id', 'unknown'))[:8]} — cannot fence, potential billing leak"
            )
            return

        instance_id = job.instance_id
        provider = job.provider
        _fence_start = datetime.utcnow().replace(tzinfo=__import__("datetime").timezone.utc)

        _FENCE_MAX_ATTEMPTS = 3
        _FENCE_BACKOFF_BASE = 5  # seconds; doubled each retry (5s, 10s)

        async def _call_fence_with_retry() -> None:
            """Call the provider fence API with up to _FENCE_MAX_ATTEMPTS attempts."""
            last_exc: Optional[Exception] = None
            for attempt in range(1, _FENCE_MAX_ATTEMPTS + 1):
                try:
                    _FENCE_DISPATCH = {
                        Provider.AWS:          lambda: self._hard_fence_aws(instance_id, job),
                        Provider.LAMBDA_LABS:   lambda: self._hard_fence_lambda(instance_id),
                        Provider.COREWEAVE:     lambda: self._hard_fence_coreweave(instance_id),
                        Provider.RUNPOD:        lambda: self._hard_fence_runpod(instance_id),
                        Provider.GCP:           lambda: self._hard_fence_gcp(instance_id, job),
                        Provider.AZURE:         lambda: self._hard_fence_azure(instance_id, job),
                        Provider.VAST_AI:       lambda: self._hard_fence_vast_ai(instance_id),
                        Provider.VOLTAGE_PARK:  lambda: self._hard_fence_voltage_park(instance_id),
                        Provider.CRUSOE:        lambda: self._hard_fence_crusoe(instance_id),
                        Provider.NEBIUS:        lambda: self._hard_fence_nebius(instance_id),
                        Provider.HYPERSTACK:    lambda: self._hard_fence_hyperstack(instance_id),
                    }
                    _fence_fn = _FENCE_DISPATCH.get(provider)
                    if not _fence_fn:
                        return  # SSH fallback handled below
                    await _fence_fn()
                    return  # success
                except Exception as exc:
                    last_exc = exc
                    if attempt < _FENCE_MAX_ATTEMPTS:
                        delay = _FENCE_BACKOFF_BASE * (2 ** (attempt - 1))
                        logger.warning(
                            f"[Broker] Fence attempt {attempt}/{_FENCE_MAX_ATTEMPTS} failed "
                            f"for {instance_id} ({provider}): {exc}. Retrying in {delay}s..."
                        )
                        await asyncio.sleep(delay)
            raise last_exc  # all attempts exhausted

        try:
            await _call_fence_with_retry()
            # SSH fallback for truly unknown providers (not retried)
            if provider not in (
                Provider.AWS, Provider.LAMBDA_LABS, Provider.COREWEAVE, Provider.RUNPOD,
                Provider.GCP, Provider.AZURE, Provider.VAST_AI, Provider.VOLTAGE_PARK,
                Provider.CRUSOE, Provider.NEBIUS, Provider.HYPERSTACK,
            ):
                try:
                    old_host = job.ssh_host or await self._resolve_instance_host(instance_id, provider)
                    if old_host:
                        ssh_key = getattr(self.config.aws, "ssh_key_path", None) or os.environ.get(
                            "VAULTLAYER_SSH_KEY_PATH", os.path.expanduser("~/.ssh/id_rsa")
                        )
                        cmd = "pkill -SIGTERM -f 'python.*train' || pkill -SIGTERM -f 'torchrun' || true"
                        await asyncio.wait_for(self._ssh_exec(old_host, ssh_key, cmd), timeout=30.0)
                        logger.info(f"[Broker] SSH fallback fence applied to {old_host} for job {job.job_id}")
                    else:
                        logger.info(f"[Broker] STONITH: no host resolved for {instance_id}, skipping SSH fallback")
                except Exception as ssh_err:
                    logger.warning(f"[Broker] SSH fallback fence failed (proceeding): {ssh_err}")
        except Exception as e:
            logger.warning(f"[Broker] _hard_fence_and_confirm failed for {instance_id} (proceeding): {e}")
            # Mark termination failed in spend_ledger and job_runs for manual review
            spend_id = self._spend_ids.get(instance_id)
            if spend_id:
                try:
                    from shared.spend import mark_termination_failed
                    mark_termination_failed(spend_id, str(e))
                except Exception:
                    pass
            run_id = self._run_ids.get(instance_id)
            if run_id:
                try:
                    from shared.job_run_logger import mark_termination_failed as jrl_fail
                    jrl_fail(run_id, str(e))
                except Exception:
                    pass
            # Publish ESCALATION -- instance may still be running and billing.
            try:
                await self.queue.publish("escalate", make_event(
                    event_type=EventType.ESCALATION,
                    source_agent=self.AGENT_NAME,
                    job_id=job.job_id,
                    payload={
                        "reason": "termination_failed",
                        "instance_id": instance_id,
                        "provider": provider.value if hasattr(provider, "value") else str(provider),
                        "error": str(e)[:500],
                        "run_id": run_id,
                        "spend_id": spend_id,
                        "message": (
                            f"BILLING ALERT: {provider} instance {instance_id} may still be running. "
                            f"Termination API failed: {str(e)[:200]}. Manual confirmation required."
                        ),
                    },
                    priority=1,
                ))
                logger.error(
                    f"[Broker] ESCALATION published: {provider} instance {instance_id} "
                    f"termination unconfirmed -- manual review required"
                )
            except Exception as pub_err:
                logger.error(f"[Broker] Failed to publish ESCALATION for {instance_id}: {pub_err}")
            return

        # -- Settle spend_ledger + job_runs rows --
        _terminated_at = datetime.utcnow().replace(tzinfo=__import__("datetime").timezone.utc)

        # -- Fetch actual provider bill (best-effort) --
        provider_billed_usd: Optional[float] = None
        pinfo = self._provision_info.get(instance_id, {})
        try:
            from shared.provider_billing import fetch_provider_bill
            _prov_name = provider.value.lower().replace(" ", "_") if hasattr(provider, "value") else str(provider)
            _api_key = ""
            _cfg = self._get_provider_config(_prov_name)
            if _cfg:
                _api_key = getattr(_cfg, "api_key", "")
            if _api_key:
                provider_billed_usd = await fetch_provider_bill(
                    provider=_prov_name,
                    instance_id=instance_id,
                    api_key=_api_key,
                    provisioned_at=pinfo.get("provisioned_at"),
                    terminated_at=_terminated_at,
                )
        except Exception as _bill_err:
            logger.debug(f"[Broker] provider billing fetch failed (non-fatal): {_bill_err}")

        spend_id = self._spend_ids.pop(instance_id, None)
        # Settle spend_ledger (canonical billing row) and capture the exact
        # computed values. Those values then mirror onto job_runs — the
        # earlier version recomputed billing locally with a hardcoded 20%
        # markup via compute_billing(), so Failover (40%) or Scarcity (30%)
        # jobs got mismatched user_charged_usd across the two tables.
        user_charged_usd = 0.0
        settled: Optional[dict] = None
        if spend_id:
            try:
                from shared.spend import settle_instance
                settled = settle_instance(
                    spend_id, _terminated_at,
                    provider_billed_usd=provider_billed_usd,
                )
                if settled is not None:
                    user_charged_usd = settled.get("user_charged_usd", 0.0)
            except Exception as e:
                logger.warning(f"[Broker] spend settle failed (non-fatal): {e}")

        run_id = self._run_ids.pop(instance_id, None)
        pinfo = self._provision_info.pop(instance_id, {})
        if run_id:
            try:
                from shared.job_run_logger import close_run, compute_billing
                prov_at = pinfo.get("provisioned_at", _fence_start)
                triggered_at = pinfo.get("job_triggered_at")
                rate = pinfo.get("rate_per_hr", 0.0)
                run_duration = (
                    (_terminated_at - triggered_at).total_seconds()
                    if triggered_at else None
                )
                # Prefer the canonical values from spend_ledger if settle
                # succeeded; fall back to local compute_billing() only when
                # spend settlement failed entirely.
                if settled is not None:
                    billing_seconds    = settled["billing_seconds"]
                    estimated_cost_usd = settled["estimated_cost_usd"]
                    uc_usd             = settled["user_charged_usd"]
                    credits_charged    = settled["credits_charged"]
                    rate               = settled.get("rate_per_hr", rate)
                else:
                    billing_seconds, estimated_cost_usd, uc_usd, credits_charged = compute_billing(
                        prov_at, _terminated_at, rate_per_hr=rate,
                    )
                close_run(
                    run_id,
                    terminated_at=_terminated_at,
                    billing_seconds=billing_seconds,
                    rate_per_hr=rate,
                    estimated_cost_usd=estimated_cost_usd,
                    user_charged_usd=uc_usd,
                    credits_charged=credits_charged,
                    run_duration_seconds=run_duration,
                    provider_billed_usd=provider_billed_usd,
                )
            except Exception as e:
                logger.warning(f"[Broker] job_runs close_run failed (non-fatal): {e}")

    # -- Provider-specific hard fence wrappers --

    async def _hard_fence_aws(self, instance_id: str, job: Job) -> None:
        from agents.broker.providers import aws
        await aws.hard_fence(self, instance_id, job)

    async def _hard_fence_lambda(self, instance_id: str) -> None:
        from agents.broker.providers import lambda_labs
        await lambda_labs.hard_fence(self, instance_id)

    async def _hard_fence_coreweave(self, instance_id: str) -> None:
        from agents.broker.providers import coreweave
        await coreweave.hard_fence(self, instance_id)

    async def _hard_fence_runpod(self, instance_id: str) -> None:
        from agents.broker.providers import runpod
        await runpod.hard_fence(self, instance_id)

    async def _hard_fence_gcp(self, instance_id: str, job: Job) -> None:
        from agents.broker.providers import gcp
        await gcp.hard_fence(self, instance_id, job)

    async def _hard_fence_azure(self, instance_id: str, job: Job) -> None:
        from agents.broker.providers import azure
        await azure.hard_fence(self, instance_id, job)

    async def _hard_fence_vast_ai(self, instance_id: str) -> None:
        from agents.broker.providers import vast_ai
        await vast_ai.hard_fence(self, instance_id)

    async def _hard_fence_voltage_park(self, instance_id: str) -> None:
        from agents.broker.providers import voltage_park
        await voltage_park.hard_fence(self, instance_id)

    async def _hard_fence_crusoe(self, instance_id: str) -> None:
        from agents.broker.providers import crusoe
        await crusoe.hard_fence(self, instance_id)

    async def _hard_fence_nebius(self, instance_id: str) -> None:
        from agents.broker.providers import nebius
        await nebius.hard_fence(self, instance_id)

    async def _hard_fence_hyperstack(self, instance_id: str) -> None:
        from agents.broker.providers import hyperstack
        await hyperstack.hard_fence(self, instance_id)

    async def _cleanup_old_instance(self, old_instance_id: str, old_provider: Provider, job: Job) -> None:
        """Terminate old instance, revoke its scoped R2 credentials, and release storage."""
        from agents.broker.migration import cleanup_old_instance
        return await cleanup_old_instance(self, old_instance_id, old_provider, job)

    # -- Flow C: Deterministic GPU fallback ladder --
    _FALLBACK_LADDER: dict = {
        GPUType.H100_80GB_SXM:  GPUType.A100_80GB_SXM,
        GPUType.H100_80GB_PCIE: GPUType.A100_80GB_SXM,
        GPUType.H100_80GB_NVL:  GPUType.A100_80GB_SXM,
        GPUType.H200:           GPUType.A100_80GB_SXM,
        GPUType.B200:           GPUType.A100_80GB_SXM,
        GPUType.A100_80GB_SXM:  GPUType.L40S,
        GPUType.A100_40GB:      GPUType.L40S,
        GPUType.L40S:           GPUType.A6000,
    }

    _IDENTICAL_SCAN_TIMEOUT_SECS = 60

    def _get_fallback_gpu(self, requested_gpu: GPUType) -> GPUType | None:
        return self._FALLBACK_LADDER.get(requested_gpu)

    async def _provision_with_failover(
        self,
        job: "Job",
        target_gpu: GPUType,
        provision_fn,
        price_cache: list[dict] | None = None,
    ) -> tuple[str | None, GPUType, "Provider | None"]:
        """
        Failover-aware provisioning: try identical GPU for 60s, then walk the
        deterministic fallback ladder, then fall to price-sorted alternatives.
        """
        import time as _time

        # Phase 1: Try identical GPU across all providers for 60s
        deadline = _time.monotonic() + self._IDENTICAL_SCAN_TIMEOUT_SECS
        _prices = price_cache or (await self.queue.get_price_cache() or [])
        _identical_providers = sorted(
            [p for p in _prices
             if isinstance(p, dict)
             and (p.get("gpu") or p.get("gpu_type", "")) == target_gpu.value
             and p.get("availability") != "unavailable"],
            key=lambda p: p.get("price_per_hour", 9999),
        )
        for entry in _identical_providers:
            if _time.monotonic() > deadline:
                break
            try:
                prov = Provider(entry["provider"])
                iid = await provision_fn(prov, target_gpu)
                if iid:
                    return iid, target_gpu, prov
            except Exception:
                continue

        # Phase 2: Deterministic fallback ladder
        fallback_gpu = self._get_fallback_gpu(target_gpu)
        while fallback_gpu is not None:
            _fb_providers = sorted(
                [p for p in _prices
                 if isinstance(p, dict)
                 and (p.get("gpu") or p.get("gpu_type", "")) == fallback_gpu.value
                 and p.get("availability") != "unavailable"],
                key=lambda p: p.get("price_per_hour", 9999),
            )
            for entry in _fb_providers[:3]:
                try:
                    prov = Provider(entry["provider"])
                    iid = await provision_fn(prov, fallback_gpu)
                    if iid:
                        logger.info(
                            f"[Broker] Failover: {target_gpu.value} unavailable, "
                            f"using fallback {fallback_gpu.value} on {prov.value}"
                        )
                        return iid, fallback_gpu, prov
                except Exception:
                    continue
            fallback_gpu = self._get_fallback_gpu(fallback_gpu)

        return None, target_gpu, None

    async def _check_quota(self, provider: Provider, gpu_type: GPUType) -> bool:
        """Check if provider has quota/capacity for this GPU type. Returns True if available."""
        from agents.broker.migration import check_quota
        return await check_quota(self, provider, gpu_type)

    # -- Same-provider-first retry (Issue #12) --

    _AWS_AZS_BY_REGION: dict[str, list[str]] = {
        "us-east-1":      ["us-east-1a", "us-east-1b", "us-east-1c", "us-east-1d"],
        "us-east-2":      ["us-east-2a", "us-east-2b", "us-east-2c"],
        "us-west-2":      ["us-west-2a", "us-west-2b", "us-west-2c", "us-west-2d"],
        "eu-west-1":      ["eu-west-1a", "eu-west-1b", "eu-west-1c"],
        "eu-central-1":   ["eu-central-1a", "eu-central-1b", "eu-central-1c"],
        "ap-southeast-1": ["ap-southeast-1a", "ap-southeast-1b", "ap-southeast-1c"],
        "ap-northeast-1": ["ap-northeast-1a", "ap-northeast-1c", "ap-northeast-1d"],
    }

    _LAMBDA_REGIONS: list[str] = [
        "us-east-1", "us-west-2", "us-south-1",
        "europe-central-1", "asia-south-1",
    ]

    async def _try_same_provider_different_az(
        self, job: Job, gpu_type: GPUType
    ) -> Optional[str]:
        """Attempt to re-provision on the SAME provider in a different AZ/region."""
        current_provider = job.provider
        current_az = getattr(job, "availability_zone", "") or ""

        if current_provider == Provider.AWS:
            region = self._resolve_target_region(job)
            candidate_azs = [
                az for az in self._AWS_AZS_BY_REGION.get(region, [])
                if az != current_az
            ]
            if not candidate_azs:
                candidate_azs = [f"{region}a", f"{region}b", f"{region}c"]
                candidate_azs = [az for az in candidate_azs if az != current_az]

            for az in candidate_azs:
                try:
                    instance_id = await self.provision_aws(gpu_type, job, preferred_az=az)
                    if instance_id:
                        logger.info(
                            f"[Broker] Same-provider retry succeeded: AWS {az} "
                            f"(job={job.job_id}, left={current_az or 'unknown'})"
                        )
                        return instance_id
                    logger.debug(f"[Broker] Same-provider AWS AZ {az} had no capacity")
                except Exception as e:
                    logger.debug(f"[Broker] Same-provider AWS AZ {az} failed: {e}")
            logger.info(
                f"[Broker] All same-region AWS AZs exhausted for {job.job_id} "
                f"-- falling through to cross-cloud"
            )
            return None

        if current_provider == Provider.LAMBDA_LABS:
            try:
                instance_id = await self.provision_lambda(gpu_type, job)
                if instance_id:
                    logger.info(f"[Broker] Same-provider Lambda Labs retry succeeded (job={job.job_id})")
                    return instance_id
            except Exception as e:
                logger.debug(f"[Broker] Same-provider Lambda retry failed: {e}")
            return None

        if current_provider == Provider.RUNPOD:
            try:
                instance_id = await self.provision_runpod(gpu_type, job)
                if instance_id:
                    logger.info(f"[Broker] Same-provider RunPod retry succeeded (job={job.job_id})")
                    return instance_id
            except Exception as e:
                logger.debug(f"[Broker] Same-provider RunPod retry failed: {e}")
            return None

        return None

    # ---------------------------------------------------------------------------
    # Migration execution  (delegated to agents.broker.migration)
    # ---------------------------------------------------------------------------

    async def execute_migration(self, job: Job, target_provider: Provider, target_gpu: GPUType,
                                decision_id: str, event_type: Optional[str] = None):
        """Full migration sequence: checkpoint -> provision -> restore -> resume."""
        from agents.broker.migration import execute_migration
        return await execute_migration(self, job, target_provider, target_gpu, decision_id, event_type)

    # ---------------------------------------------------------------------------
    # Command listener / lifecycle
    # ---------------------------------------------------------------------------

    async def listen_for_commands(self):
        async def handle(event: AgentEvent):
            # P0-L1: CHECKPOINT_READY
            if event.event_type == EventType.CHECKPOINT_READY and event.job_id:
                ev = self._checkpoint_events.get(event.job_id)
                if ev and not ev.is_set():
                    logger.info(
                        f"[Broker] P0-L1: checkpoint ready for job {event.job_id} -- unblocking restore"
                    )
                    ev.set()
                return

            if event.payload.get("target_agent") != self.AGENT_NAME:
                return
            cmd = event.payload.get("command")
            is_migrate = (cmd == "migrate") or (event.event_type and "migration_request" in str(event.event_type).lower())
            if is_migrate and event.job_id:
                job_state = await self.queue.get_job_state(event.job_id)
                if job_state:
                    job = Job(**job_state)
                    tp = event.payload.get("target_provider")
                    tg = event.payload.get("target_gpu")
                    if tp and tg:
                        await self.execute_migration(
                            job, Provider(tp), GPUType(tg), event.payload.get("decision_id", "")
                        )
        await self.queue.subscribe(["orchestration"], handle)

    async def _consume_critical_loop(self) -> None:
        """Consume MIGRATION_REQUESTED events from the broker-specific critical stream."""
        consumer_name = f"broker-{os.getpid()}"
        try:
            await self.queue.consume_critical(consumer_name, self._handle_critical_event, channel_key="broker")
        except Exception as e:
            logger.error(f"Broker critical consumer failed: {e}")

    async def _handle_critical_event(self, fields: dict) -> None:
        """Handle MIGRATION_REQUESTED from the broker critical stream."""
        import json as _json
        event_type_str = fields.get("event_type", "").lower()
        if "migration_request" not in event_type_str:
            return
        job_id = fields.get("job_id", "")
        if not job_id:
            return
        payload = _json.loads(fields.get("payload", "{}"))
        tp = payload.get("target_provider", "")
        tg = payload.get("target_gpu", "")
        if not tp or not tg:
            logger.error(f"MIGRATION_REQUESTED missing target_provider or target_gpu: {payload}")
            return
        job_state = await self.queue.get_job_state(job_id)
        if not job_state:
            logger.error(f"Job {job_id} not found in state store for migration")
            return
        from shared.models import Job, Provider, GPUType
        _gpu_aliases = {"h100": "H100_80GB_SXM", "a100": "A100_80GB_SXM",
                        "a100_40": "A100_40GB", "a10g": "A10G", "a10": "A10G"}
        tg = _gpu_aliases.get(tg.lower(), tg) if tg else tg
        try:
            job = Job(**job_state)
            target_provider = Provider(tp)
            target_gpu = GPUType(tg)
        except (ValueError, KeyError) as e:
            logger.error(f"Invalid provider/gpu in migration request: {e}")
            return
        decision_id = payload.get("decision_confidence", "auto")
        logger.info(f"Critical stream: executing migration {job_id} -> {tp}/{tg}")
        await self.execute_migration(job, target_provider, target_gpu, str(decision_id))

    async def start(self):
        logger.info("Broker Agent starting")
        import asyncio as _a

        # P0-L3: Initialize warm pool.
        async def _warm_provision(gpu_type: GPUType, job: Job) -> Optional[str]:
            """Provision a single warm node using the cheapest non-AWS provider."""
            try:
                return await self.provision_lambda(gpu_type, job)
            except Exception as _e:
                logger.warning("[WarmPool] provision_lambda failed: %s", _e)
                return None

        async def _warm_terminate(instance_id: str, provider: Provider) -> None:
            """Terminate a warm node via provider API."""
            try:
                await self._fence_old_node_by_id(instance_id, provider)
            except Exception as _e:
                logger.warning("[WarmPool] terminate %s failed: %s", instance_id, _e)

        ssh_key_path = os.environ.get("VAULTLAYER_SSH_KEY_PATH", os.path.expanduser("~/.ssh/id_rsa"))
        self._warm_pool = WarmPoolManager(
            provision_fn=_warm_provision,
            terminate_fn=_warm_terminate,
            ssh_key_path=ssh_key_path,
        )
        await self._warm_pool.start()

        await self._sts.start_background_refresh()
        await _a.gather(
            self.listen_for_commands(),
            self._consume_critical_loop(),
        )

    async def stop(self):
        logger.info("Broker Agent stopping.")
        if self._warm_pool is not None:
            await self._warm_pool.stop()
