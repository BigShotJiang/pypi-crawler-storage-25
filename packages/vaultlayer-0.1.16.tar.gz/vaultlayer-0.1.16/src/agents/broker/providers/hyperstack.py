"""Hyperstack provider -- provision + fence."""
from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Optional

import aiohttp

if TYPE_CHECKING:
    from shared.models import GPUType, Job

logger = logging.getLogger(__name__)


async def provision(broker, gpu_type: "GPUType", job: "Job") -> Optional[str]:
    """Provision a Hyperstack instance. Returns VM ID or None."""
    from shared.data_loader import get_instance_string, resolve_gpu_key, is_gpu_available

    _cfg = broker._get_provider_config("hyperstack")
    if not _cfg:
        _managed = await broker._get_managed_credentials("hyperstack", job.job_id)
        if not _managed:
            job.last_provision_error = "Hyperstack: no credentials available"
            return None
        from types import SimpleNamespace
        _cfg = SimpleNamespace(api_key=_managed["api_key"])
    _gpu_key = resolve_gpu_key(gpu_type.value)
    if not is_gpu_available("Hyperstack", _gpu_key):
        job.last_provision_error = f"Hyperstack: GPU {_gpu_key} not available"
        return None
    flavor_name = get_instance_string("Hyperstack", _gpu_key)
    if not flavor_name:
        job.last_provision_error = f"Hyperstack: no flavor mapped for {_gpu_key}"
        return None
    try:
        hyperstack_startup = broker._build_vm_startup_script(job)
        _hs_headers = {"api_key": _cfg.api_key}
        _env_name = os.environ.get("VL_HYPERSTACK_ENV", "default-NORWAY-1")
        _key_name = os.environ.get("VL_HYPERSTACK_KEY_NAME", "vaultlayer-prod")

        async def _hs_provision(session, env_name, key_name):
            async with session.post(
                "https://infrahub-api.nexgencloud.com/v1/core/virtual-machines",
                headers=_hs_headers,
                json={"name": f"vl-{job.job_id[:8]}",
                      "environment_name": env_name,
                      "image_name": "Ubuntu Server 22.04 LTS R535 CUDA 12.2",
                      "flavor_name": flavor_name,
                      "key_name": key_name,
                      "user_data": hyperstack_startup,
                      "count": 1},
                timeout=aiohttp.ClientTimeout(total=30)
            ) as r:
                try:
                    data = await r.json()
                except Exception:
                    data = {}
                return r.status, data

        async with aiohttp.ClientSession() as session:
            status, data = await _hs_provision(session, _env_name, _key_name)
            # If environment, keypair, or flavor not found (404), auto-discover and retry once
            # Source: https://infrahub-doc.nexgencloud.com/docs/api-reference/core-resources/flavors/retrieve-flavors
            #   GET /v1/core/environments  -> environments[].name
            #   GET /v1/core/keypairs      -> keypairs[].name
            #   GET /v1/core/flavors       -> flavors[].name  (filter by GPU keyword)
            if status == 404:
                err_msg = str(data.get("message", ""))
                logger.warning(f"[Hyperstack] 404 ({err_msg}) -- auto-discovering env/keypair/flavor")
                try:
                    async with session.get(
                        "https://infrahub-api.nexgencloud.com/v1/core/environments",
                        headers=_hs_headers, timeout=aiohttp.ClientTimeout(total=10)
                    ) as env_r:
                        if env_r.status == 200:
                            envs = (await env_r.json()).get("environments", [])
                            if envs:
                                _env_name = envs[0].get("name", _env_name)
                                logger.info(f"[Hyperstack] Auto-selected environment: {_env_name}")
                except Exception as _e:
                    logger.warning(f"[Hyperstack] Environment discovery failed: {_e}")
                try:
                    async with session.get(
                        "https://infrahub-api.nexgencloud.com/v1/core/keypairs",
                        headers=_hs_headers, timeout=aiohttp.ClientTimeout(total=10)
                    ) as key_r:
                        if key_r.status == 200:
                            keys = (await key_r.json()).get("keypairs", [])
                            if keys:
                                _key_name = keys[0].get("name", _key_name)
                                logger.info(f"[Hyperstack] Auto-selected key_name: {_key_name}")
                except Exception as _e:
                    logger.warning(f"[Hyperstack] Keypair discovery failed: {_e}")
                # If flavor wasn't found, discover available flavors and pick best match
                # GET /v1/core/flavors -> flavors[].name (e.g. "n3-A100x1", "n3-H100x1")
                if "flavor" in err_msg.lower() or "not exist" in err_msg.lower():
                    try:
                        # GPU keyword derived from requested GPU type (e.g. "A100", "H100", "L40S")
                        _gpu_keyword = _gpu_key.split("_")[0].upper()  # "A100", "H100", etc.
                        async with session.get(
                            "https://infrahub-api.nexgencloud.com/v1/core/flavors",
                            headers=_hs_headers, timeout=aiohttp.ClientTimeout(total=10)
                        ) as flav_r:
                            if flav_r.status == 200:
                                flavors_data = await flav_r.json()
                                all_flavors = flavors_data.get("flavors", [])
                                # Filter to single-GPU (x1) flavors matching our GPU type
                                _candidates = [
                                    f["name"] for f in all_flavors
                                    if _gpu_keyword in f.get("name", "").upper()
                                    and "x1" in f.get("name", "")
                                    and "spot" not in f.get("name", "").lower()
                                ]
                                if _candidates:
                                    flavor_name = _candidates[0]
                                    logger.info(f"[Hyperstack] Auto-selected flavor: {flavor_name} "
                                                f"(from {len(_candidates)} candidates for {_gpu_keyword})")
                                else:
                                    # Fall back to any single-GPU flavor available
                                    _any = [f["name"] for f in all_flavors if "x1" in f.get("name", "")]
                                    if _any:
                                        flavor_name = _any[0]
                                        logger.warning(f"[Hyperstack] No {_gpu_keyword} x1 flavor found, "
                                                       f"falling back to {flavor_name}")
                    except Exception as _e:
                        logger.warning(f"[Hyperstack] Flavor discovery failed: {_e}")
                status, data = await _hs_provision(session, _env_name, _key_name)

            if status not in (200, 201):
                job.last_provision_error = f"Hyperstack: HTTP {status} -- {str(data)[:150]}"
                logger.error(f"Hyperstack provision {status}: {str(data)[:300]}")
                return None
            vms = data.get("virtual_machines", [{}])
            return str(vms[0].get("id", "")) if vms else None
    except Exception as e:
        job.last_provision_error = f"Hyperstack: {type(e).__name__}: {str(e)[:150]}"
        logger.error(f"Hyperstack provision error: {e}"); return None


async def hard_fence(broker, instance_id: str, job=None) -> None:
    """Delete a Hyperstack VM via API."""
    _cfg = broker._get_provider_config("hyperstack")
    if not _cfg:
        raise RuntimeError(f"Hyperstack config not found for fence of {instance_id}")
    try:
        async with aiohttp.ClientSession() as s:
            resp = await s.delete(
                f"https://infrahub-api.nexgencloud.com/v1/core/virtual-machines/{instance_id}",
                headers={"api_key": _cfg.api_key},
                timeout=aiohttp.ClientTimeout(total=15),
            )
            if resp.status in (200, 202, 204):
                logger.info(f"[Broker] Hyperstack VM {instance_id} fence sent (status={resp.status})")
            elif resp.status == 404:
                logger.info(f"[Broker] Hyperstack VM {instance_id} already gone (404) — treating as deleted")
            else:
                body = await resp.text()
                raise RuntimeError(f"Hyperstack fence HTTP {resp.status}: {body[:200]}")
    except Exception as e:
        logger.error(f"[Broker] Hyperstack fence error for {instance_id}: {e}")
        raise

async def _placeholder_hyperstack():
    pass
