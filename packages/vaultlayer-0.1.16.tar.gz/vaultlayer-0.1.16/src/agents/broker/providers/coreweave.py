"""CoreWeave provider -- provision + fence."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

import aiohttp

if TYPE_CHECKING:
    from shared.models import GPUType, Job

logger = logging.getLogger(__name__)


async def provision(broker, gpu_type: "GPUType", job: "Job") -> Optional[str]:
    """Provision a CoreWeave VM. Returns instance name or None."""
    # Guard against missing config — CoreWeave is a BYOC-only provider today
    # (no managed creds path), so callers that route here without a config
    # would previously crash with `'NoneType' object has no attribute 'namespace'`
    # on line 30. Surfaced on 2026-04-20 during a multi-provider failover:
    # the broker tried CoreWeave between GCP and Lambda Labs even though the
    # account had no coreweave config — the AttributeError killed the
    # failover chain for that attempt. Return None so the broker moves on.
    if not getattr(broker.config, "coreweave", None):
        logger.info(
            f"[CoreWeave] No coreweave config on this deployment — skipping "
            f"provision for job {job.job_id}"
        )
        job.last_provision_error = "CoreWeave: not configured on this deployment"
        return None

    from shared.models import GPUType as _GT

    gpu_map = {
        _GT.H100_80GB_SXM: "H100_NVLINK_80GB",
        _GT.A100_80GB_SXM: "A100_NVLINK_80GB",
        _GT.A100_40GB: "A100_NVLINK",
        _GT.A10G: "RTX_A6000",
    }
    gpu_resource = gpu_map.get(gpu_type, "H100_NVLINK_80GB")
    # CoreWeave VMs are Kubernetes VirtualServer CRDs -- no proprietary REST endpoint exists.
    # base_url must point to the CoreWeave k8s API server from the user's kubeconfig.
    _cw_k8s_path = (
        f"/apis/virtualservers.coreweave.com/v1alpha1"
        f"/namespaces/{broker.config.coreweave.namespace}/virtualservers"
    )
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{broker.config.coreweave.base_url}{_cw_k8s_path}",
                headers={
                    "Authorization": f"Bearer {broker.config.coreweave.api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "apiVersion": "virtualservers.coreweave.com/v1alpha1",
                    "kind": "VirtualServer",
                    "metadata": {
                        "name": f"vaultlayer-{job.job_id[:8]}",
                        "namespace": broker.config.coreweave.namespace,
                        "labels": {
                            "vaultlayer-job": job.job_id[:63],
                            "managed-by": "vaultlayer",
                        },
                    },
                    "spec": {
                        "resources": {"requests": {gpu_resource: "1"}},
                        "affinity": {"nodeAffinity": {"preferred": [{"weight": 1}]}},
                        "volumes": [{
                            "name": "cloudinitdisk",
                            "cloudInitNoCloud": {
                                "userData": broker._build_vm_startup_script(job),
                            },
                        }],
                        "domain": {
                            "devices": {
                                "disks": [{"name": "cloudinitdisk", "disk": {"bus": "virtio"}}],
                            },
                        },
                    },
                },
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                if resp.status in (200, 201):
                    data = await resp.json()
                    name = data.get("metadata", {}).get("name")
                    logger.info(f"CoreWeave VM provisioned: {name}")
                    return name
        job.last_provision_error = "CoreWeave: API returned non-200/201 status"
        return None
    except Exception as e:
        job.last_provision_error = f"CoreWeave: {type(e).__name__}: {e}"
        logger.error(f"CoreWeave provision error: {e}")
        return None


async def hard_fence(broker, instance_id: str, job=None) -> None:
    """Delete a CoreWeave VirtualServer via the Kubernetes CRD API.

    CoreWeave VMs are Kubernetes VirtualServer custom resources
    (group: virtualservers.coreweave.com/v1alpha1). There is no
    proprietary REST endpoint -- deletion goes through the standard
    Kubernetes API against CoreWeave's API server.

    base_url must be set to the CoreWeave k8s API server (from kubeconfig),
    api_key is the kubeconfig Bearer token, namespace is the CW namespace.
    instance_id is the VirtualServer name (returned by provision).
    """
    _cfg = broker._get_provider_config("coreweave")
    if not _cfg:
        raise RuntimeError(f"CoreWeave config not found for fence of {instance_id}")
    try:
        async with aiohttp.ClientSession() as s:
            resp = await s.delete(
                f"{_cfg.base_url}/apis/virtualservers.coreweave.com/v1alpha1"
                f"/namespaces/{_cfg.namespace}/virtualservers/{instance_id}",
                headers={"Authorization": f"Bearer {_cfg.api_key}"},
                timeout=aiohttp.ClientTimeout(total=30),
            )
            if resp.status in (200, 202, 204):
                logger.info(f"[Broker] CoreWeave VirtualServer {instance_id} delete issued (status={resp.status})")
            elif resp.status == 404:
                logger.info(f"[Broker] CoreWeave VirtualServer {instance_id} already gone (404) — treating as deleted")
            else:
                body = await resp.text()
                raise RuntimeError(f"CoreWeave fence HTTP {resp.status}: {body[:200]}")
    except Exception as e:
        logger.error(f"[Broker] CoreWeave fence error for {instance_id}: {e}")
        raise
