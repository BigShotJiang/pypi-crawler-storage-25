"""Vast.ai provider — provision + fence.

Provision uses PUT /api/v0/asks/{offer_id}/ with:
  - runtype: "ssh_direct" (SSH mode — Vast injects SSH daemon + runs onstart)
  - onstart: bootstrap script (env vars, rclone, R2 mount, training)
  - env: JSON dict {KEY: "value"}. Vast.ai's docs describe `env` as a
    Docker-flag string ("-e K=v"), but the deployed API requires the
    dict form in practice — the string form triggered 100% bid rejection
    in our 2026-04-17 E2E test.

Offers search uses POST /api/v0/bundles/ with a flat JSON body of filters
(gpu_name, rentable, reliability2, dph_total, num_gpus). The legacy
GET /bundles/?q=<json> form is deprecated.

Key Vast.ai behaviors (from docs):
  - SSH/Jupyter modes OVERRIDE Docker ENTRYPOINT — onstart is the script hook
  - Env vars set via `env` field are NOT visible in SSH sessions by default
  - Must add `env >> /etc/environment` in onstart for SSH visibility
  - Not billed during `loading` state (image pull)
  - CONTAINER_ID and CONTAINER_API_KEY are auto-injected for self-termination
  - gpu_name filter values use underscores, e.g. "RTX_4090" (not "RTX 4090")

Source: https://docs.vast.ai/api-reference/instances/create-instance
        https://docs.vast.ai/api-reference/search/search-offers
        https://docs.vast.ai/documentation/instances/launch-modes
"""
from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Optional

import aiohttp

if TYPE_CHECKING:
    from shared.models import GPUType, Job

logger = logging.getLogger(__name__)


async def provision(broker, gpu_type: "GPUType", job: "Job") -> Optional[str]:
    """Provision a Vast.ai instance. Returns instance ID or None."""
    from shared.data_loader import resolve_gpu_key
    from shared.models import Provider

    _cfg = broker._get_provider_config("vast_ai")
    if not _cfg:
        _managed = await broker._get_managed_credentials("vast_ai", job.job_id)
        if not _managed:
            job.last_provision_error = "Vast.ai: no credentials available (BYOC or managed)"
            return None
        from types import SimpleNamespace
        _cfg = SimpleNamespace(api_key=_managed["api_key"])
    _gpu_key = resolve_gpu_key(gpu_type.value)
    # Dynamic GPU resolution: cache → API → static fallback → raw key.
    # Vast.ai gpu_name filter values use underscores (e.g. "RTX_4090"), so
    # preserve the key as-is when the resolver comes back empty.
    gpu_name = await broker.gpu_resolver.resolve("Vast.ai", _gpu_key, api_key=_cfg.api_key)
    if not gpu_name:
        gpu_name = _gpu_key
    try:
        async with aiohttp.ClientSession() as session:
            # Pre-flight: check Vast.ai account balance
            async with session.get(
                "https://console.vast.ai/api/v0/users/current/",
                headers={"Authorization": f"Bearer {_cfg.api_key}"},
                timeout=aiohttp.ClientTimeout(total=5)
            ) as bal_r:
                if bal_r.status == 200:
                    _bal = (await bal_r.json()).get("credit", 0)
                    if _bal <= 0:
                        job.last_provision_error = f"Vast.ai: insufficient balance (${_bal:.2f})"
                        from shared.failure_codes import JobFailureCode
                        job.failure_code = JobFailureCode.PROV_MANAGED_BALANCE.value
                        job.failure_detail = (
                            f"Vast.ai managed account has ${_bal:.2f} balance. "
                            "Top up at console.vast.ai."
                        )[:500]
                        logger.error(f"Vast.ai MANAGED BALANCE EMPTY (${_bal:.2f}) — cannot provision. Top up at console.vast.ai")
                        return None

            # Search Vast.ai marketplace via POST /api/v0/bundles/ (filters
            # are flat top-level fields per current docs). Sort client-side
            # by dph_total so we don't depend on the server's order keyword.
            # Source: https://docs.vast.ai/api-reference/search/search-offers
            offers = []
            for _search_name in [gpu_name]:
                _body = {
                    "rentable": {"eq": True},
                    "reliability2": {"gte": 0.95},
                    "gpu_name": {"eq": _search_name},
                    "limit": 20,
                }
                async with session.post(
                    "https://console.vast.ai/api/v0/bundles/",
                    headers={"Authorization": f"Bearer {_cfg.api_key}"},
                    json=_body,
                    timeout=aiohttp.ClientTimeout(total=15)
                ) as r:
                    if r.status == 200:
                        resp_data = await r.json()
                        if not resp_data.get("error"):
                            offers = resp_data.get("offers", [])
                            offers.sort(key=lambda o: o.get("dph_total") or float("inf"))
                if offers:
                    break

            # Fallback: search all offers and match by GPU key substring
            if not offers:
                _body_all = {
                    "rentable": {"eq": True},
                    "reliability2": {"gte": 0.8},
                    "limit": 100,
                }
                async with session.post(
                    "https://console.vast.ai/api/v0/bundles/",
                    headers={"Authorization": f"Bearer {_cfg.api_key}"},
                    json=_body_all,
                    timeout=aiohttp.ClientTimeout(total=15)
                ) as r:
                    if r.status == 200:
                        all_data = await r.json()
                        all_offers = all_data.get("offers", [])
                        _key = _gpu_key.lower()
                        _key_space = _key.replace("_", " ")
                        offers = [o for o in all_offers
                                  if _key in o.get("gpu_name", "").lower()
                                  or _key_space in o.get("gpu_name", "").lower()
                                  or o.get("gpu_name", "").lower().startswith(_key)]
                        offers.sort(key=lambda o: o.get("dph_total") or float("inf"))
                        if offers:
                            logger.info(f"Vast.ai fuzzy match: '{_gpu_key}' → '{offers[0].get('gpu_name')}' ({len(offers)} offers)")

            if not offers:
                job.last_provision_error = f"Vast.ai: no offers found for {gpu_name} / {_gpu_key}"
                logger.warning(f"No Vast.ai offers for {gpu_name} / {_gpu_key} (0 matches after fuzzy)")
                return None

            # Default image: vl-training-base ships torch 2.1.2 + full HF stack
            # (transformers, peft, trl, datasets, bitsandbytes, accelerate, numpy<2)
            # pre-baked. Proven end-to-end on Vast.ai 2026-04-25.
            # The plain pytorch:-devel image lacks these deps — training scripts
            # exit at import time (exit 1) before any logs appear.
            vast_image = job.docker_image or "ghcr.io/hector25/vl-training-base:1.0"
            # Use unified prepare_startup() — registry says PLAIN for Vast.ai
            _startup_payload = broker.prepare_startup(Provider.VAST_AI, job)

            # Build env as a dict. Vast.ai's docs describe `env` as a
            # Docker-flag string (e.g. "-e K=v"), but their deployed API
            # historically accepts — and in prod apparently requires — the
            # JSON dict form; the string form triggered 100% rejection of
            # PUT /api/v0/asks/<id>/ bids in our 2026-04-17 E2E test.
            _vast_env = {"VAULTLAYER_JOB_ID": job.job_id}
            _vast_env.update(job.environment or {})
            # Remove VL_SCRIPT_B64 — already embedded in onstart script.
            # Vast.ai has a 32KB env var limit; large scripts would be truncated.
            _vast_env.pop("VL_SCRIPT_B64", None)

            # Prepend env persistence to onstart script.
            # Vast.ai env vars are NOT visible in SSH/tmux sessions by default.
            # `env >> /etc/environment` makes them available everywhere.
            # Source: https://docs.vast.ai/documentation/instances/docker-environment
            _onstart = "env >> /etc/environment\n" + _startup_payload.script

            # P0-C4: Try up to 10 offers — if one is rejected, fall back to next.
            # Capture the last rejection's response body so operators can see
            # the actual Vast.ai error instead of a generic "10 rejected".
            _last_reject = ""
            for offer in offers[:10]:
                offer_id = offer["id"]
                async with session.put(
                    f"https://console.vast.ai/api/v0/asks/{offer_id}/",
                    headers={"Authorization": f"Bearer {_cfg.api_key}"},
                    json={
                        "client_id": "me",
                        "image": vast_image,
                        # Vast.ai support 2026-04-19: 50 GB is tight for
                        # LLaMA-3B-class runs. Model (~6 GB in fp16) + dataset
                        # (~1-25 GB) + 13 × 2 GB checkpoints + intermediate
                        # CUDA kernel caches + docker image (~6 GB devel tag)
                        # easily crosses 50 GB. 100 GB gives headroom; 150 GB
                        # for 7B+ models. 100 GB costs negligible extra on
                        # marketplace offers vs the retry cost of "out of disk".
                        "disk": 100,
                        "runtype": "ssh_direct",
                        "onstart": _onstart,
                        "env": {k: str(v) for k, v in _vast_env.items()},
                    },
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as r:
                    if r.status not in (200, 201):
                        _body = (await r.text())[:200]
                        _last_reject = f"status={r.status} body={_body}"
                        logger.warning(f"Vast.ai bid on offer {offer_id} rejected: {_last_reject}")
                        continue
                    resp_data = await r.json()
                    instance_id = str(resp_data.get("new_contract", offer_id))
                # Record the actual dph_total of the accepted offer onto the
                # Job so the worker can bill the user at the real bid rate
                # instead of the stale config rate. Vast.ai's /charges/ API
                # settles this for real post-hoc; this is the best signal
                # we have at provision time.
                try:
                    _dph = float(offer.get("dph_total") or 0)
                except (TypeError, ValueError):
                    _dph = 0.0
                if _dph > 0:
                    job.current_hourly_rate = _dph
                logger.info(
                    f"Vast.ai bid accepted: offer={offer_id} instance={instance_id} "
                    f"dph_total=${_dph:.4f}/hr"
                )
                return instance_id

            job.last_provision_error = (
                f"Vast.ai: all 10 offers rejected for {gpu_name} "
                f"(last: {_last_reject or 'unknown'})"
            )
            logger.warning(f"Vast.ai: all 10 offers exhausted for {gpu_name}; last reject: {_last_reject}")
            return None
    except Exception as e:
        job.last_provision_error = f"Vast.ai: {type(e).__name__}: {str(e)[:150]}"
        logger.error(f"Vast.ai provision error: {e}"); return None


async def hard_fence(broker, instance_id: str, job=None) -> None:
    """Delete a Vast.ai instance via API and verify destruction.

    Endpoint: DELETE https://console.vast.ai/api/v0/instances/{id}/
    Post-delete: polls GET /api/v0/instances/{id}/ until 404.

    Source: https://docs.vast.ai/api-reference/instances/destroy-instance
    """
    _cfg = broker._get_provider_config("vast_ai")
    if not _cfg:
        _managed = await broker._get_managed_credentials("vast_ai", f"fence-{instance_id}")
        if _managed:
            from types import SimpleNamespace
            _cfg = SimpleNamespace(api_key=_managed["api_key"])
        else:
            logger.warning(f"[Broker] Vast.ai config not found, skipping fence for {instance_id}")
            return
    try:
        _headers = {"Authorization": f"Bearer {_cfg.api_key}"}
        async with aiohttp.ClientSession() as s:
            resp = await s.delete(
                f"https://console.vast.ai/api/v0/instances/{instance_id}/",
                headers=_headers,
                timeout=aiohttp.ClientTimeout(total=15),
            )
            if resp.status == 404:
                logger.info(f"[Broker] Vast.ai instance {instance_id} already gone (404)")
                return
            logger.info(f"[Broker] Vast.ai instance {instance_id} fence sent (status={resp.status})")

            # Post-delete verification: poll until 404 (instance gone)
            for _attempt in range(12):  # 60s max
                await asyncio.sleep(5)
                try:
                    check = await s.get(
                        f"https://console.vast.ai/api/v0/instances/{instance_id}/",
                        headers=_headers,
                        timeout=aiohttp.ClientTimeout(total=10),
                    )
                    if check.status == 404:
                        logger.info(f"[Broker] Vast.ai instance {instance_id} confirmed destroyed (404)")
                        return
                    if check.status == 200:
                        _data = await check.json()
                        _status = _data.get("actual_status", "unknown")
                        logger.debug(f"[Broker] Vast.ai instance {instance_id} still exists (status={_status})")
                except Exception:
                    pass  # Network blip — keep polling
            raise RuntimeError(
                f"[Broker] Vast.ai instance {instance_id} NOT confirmed destroyed after 60s — "
                f"potential billing leak"
            )
    except Exception as e:
        logger.error(f"[Broker] Vast.ai fence failed for {instance_id}: {e}")
        raise
