"""Lambda Labs provider — provision + fence."""
from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Optional

import aiohttp

if TYPE_CHECKING:
    from shared.models import GPUType, Job

logger = logging.getLogger(__name__)


async def provision(broker, gpu_type: "GPUType", job: "Job") -> Optional[str]:
    """Provision a Lambda Labs instance. Returns instance ID or None.

    Uses BYOC key (broker.config.lambda_labs) when present. Falls back to
    VaultLayer's managed key fetched from the credential server.
    """
    from shared.data_loader import resolve_gpu_key
    from shared.models import Provider

    _gpu_key = resolve_gpu_key(gpu_type.value)

    # ── Resolve API key: BYOC first, then VaultLayer managed ─────────────
    _ll_cfg = broker.config.lambda_labs
    if _ll_cfg:
        _ll_api_key = _ll_cfg.api_key
        _ll_base_url = _ll_cfg.base_url
    else:
        _managed = await broker._get_managed_credentials("lambda_labs", job.job_id)
        if not _managed:
            job.last_provision_error = "Lambda: no credentials available (BYOC or managed)"
            logger.error("[broker] No Lambda Labs credentials available (BYOC or managed)")
            return None
        _ll_api_key = _managed.get("api_key", "")
        _ll_base_url = "https://cloud.lambdalabs.com/api/v1"

    # Dynamic GPU resolution: cache → API → static fallback
    instance_type = await broker.gpu_resolver.resolve("Lambda Labs", _gpu_key, api_key=_ll_api_key)
    if not instance_type:
        job.last_provision_error = f"Lambda: no instance type mapped for GPU {gpu_type.value}"
        logger.error(f"No Lambda instance type for GPU: {gpu_type}")
        return None

    try:
        import base64 as _b64
        # Use unified prepare_startup() — registry says PLAIN encoding for Lambda
        _startup_payload = broker.prepare_startup(Provider.LAMBDA_LABS, job)
        _ll_auth = _b64.b64encode(f"{_ll_api_key}:".encode()).decode()
        _ll_headers = {"Authorization": f"Basic {_ll_auth}"}

        async with aiohttp.ClientSession() as session:
            # ── Resolve SSH key name ──────────────────────────────────────
            # Check if "vaultlayer-key" exists; if not, auto-discover or create one.
            _ssh_key_name = "vaultlayer-key"
            async with session.get(
                f"{_ll_base_url}/ssh-keys", headers=_ll_headers,
                timeout=aiohttp.ClientTimeout(total=10)
            ) as kr:
                if kr.status == 200:
                    existing = (await kr.json()).get("data", [])
                    names = [k.get("name", "") for k in existing]
                    if _ssh_key_name not in names:
                        if names:
                            # Use first existing key
                            _ssh_key_name = names[0]
                            logger.info(f"[Lambda] Using existing SSH key: {_ssh_key_name}")
                        else:
                            # No keys — create one (Lambda generates the keypair)
                            async with session.post(
                                f"{_ll_base_url}/ssh-keys", headers=_ll_headers,
                                json={"name": "vaultlayer-key"},
                                timeout=aiohttp.ClientTimeout(total=10)
                            ) as ck:
                                if ck.status == 200:
                                    logger.info("[Lambda] Created SSH key 'vaultlayer-key'")
                                else:
                                    logger.warning(f"[Lambda] SSH key creation failed {ck.status}: {(await ck.text())[:200]}")

            # ── Find region with capacity ─────────────────────────────────
            _region = "us-east-1"
            _regions_checked = False
            async with session.get(
                f"{_ll_base_url}/instance-types", headers=_ll_headers,
                timeout=aiohttp.ClientTimeout(total=10)
            ) as it:
                if it.status == 200:
                    _regions_checked = True
                    it_data = (await it.json()).get("data", {})
                    info = it_data.get(instance_type, {})
                    regions = info.get("regions_with_capacity_available", [])
                    # Filter by job placement constraints (regions whitelist and
                    # excluded_regions blacklist) before picking the first available.
                    _job_regions = list(getattr(job, "regions", None) or [])
                    _job_excl   = set(getattr(job, "excluded_regions", None) or [])
                    _allowed = [
                        r for r in regions
                        if r["name"] not in _job_excl
                        and (not _job_regions or r["name"] in _job_regions)
                    ]
                    if _allowed:
                        _region = _allowed[0]["name"]
                        logger.info(f"[Lambda] Using region {_region} for {instance_type}")
                    elif regions and not _job_regions and not _job_excl:
                        # No constraints — use first available
                        _region = regions[0]["name"]
                        logger.info(f"[Lambda] Using region {_region} for {instance_type}")
                    elif regions:
                        # Capacity exists but all regions blocked by constraints
                        job.last_provision_error = (
                            f"Lambda: no region satisfies placement constraints "
                            f"(regions={_job_regions}, excluded={list(_job_excl)})"
                        )
                        logger.info(f"[Lambda] Regions with capacity {[r['name'] for r in regions]} "
                                    f"all blocked by job placement constraints")
                        return None
                    else:
                        # No region has capacity — skip the launch attempt entirely
                        job.last_provision_error = f"Lambda: no capacity available for {instance_type} in any region"
                        logger.info(f"[Lambda] No capacity for {instance_type} in any region")
                        return None

            # ── Launch instance ───────────────────────────────────────────
            async with session.post(
                f"{_ll_base_url}/instance-operations/launch",
                headers=_ll_headers,
                json={
                    "region_name": _region,
                    "instance_type_name": instance_type,
                    "ssh_key_names": [_ssh_key_name],
                    "name": f"vaultlayer-{job.job_id[:8]}",
                    "user_data": _startup_payload.script,
                },
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                if resp.status == 200:
                    data_resp = await resp.json()
                    instance_ids = data_resp.get("data", {}).get("instance_ids", [])
                    if instance_ids:
                        logger.info(f"Lambda instance provisioned: {instance_ids[0]}")
                        return instance_ids[0]
                _err_body = (await resp.text())[:300]
                job.last_provision_error = f"Lambda: HTTP {resp.status} — {_err_body[:150]}"
                from shared.failure_codes import JobFailureCode
                # Detect balance/billing errors. "insufficient" is intentionally excluded
                # because Lambda capacity errors say "insufficient capacity" — matching
                # that word would mark no-GPU-capacity as non-retryable (billing leak risk).
                _balance_signals = ("balance", "funds", "payment", "credit", "billing")
                if resp.status == 402 or any(s in _err_body.lower() for s in _balance_signals):
                    job.failure_code = JobFailureCode.PROV_MANAGED_BALANCE.value
                    job.failure_detail = (
                        f"Lambda managed account has insufficient balance "
                        f"(HTTP {resp.status}). Top up cloud.lambdalabs.com. Body: {_err_body[:200]}"
                    )[:500]
                    logger.error(f"Lambda MANAGED BALANCE EMPTY — provision blocked (HTTP {resp.status}): {_err_body}")
                else:
                    logger.error(f"Lambda provision failed: {resp.status} — {_err_body}")
                return None
    except Exception as e:
        job.last_provision_error = f"Lambda: {type(e).__name__}: {e}"
        logger.error(f"Lambda provision error: {e}")
        return None


async def hard_fence(broker, instance_id: str, job=None) -> None:
    """Terminate a Lambda Labs instance via API and verify destruction.

    Lambda Labs HTTP Basic Auth: API key is the username with an empty password.
    RFC-correct encoding: base64("<api_key>:") — the colon is required.

    Post-delete: polls GET /api/v1/instances/{id} until status=terminated or 404.
    Source: https://cloud.lambda.ai/api/v1/openapi.json
    InstanceStatus enum: "booting" | "active" | "unhealthy" | "terminated" | "terminating" | "preempted"
    """
    import base64 as _b64
    _cfg = broker._get_provider_config("lambda_labs")
    _ll_base_url = "https://cloud.lambdalabs.com/api/v1"
    if _cfg:
        _ll_api_key = _cfg.api_key
        _ll_base_url = _cfg.base_url
    else:
        # No local config — fetch key from managed credential server
        _managed = await broker._get_managed_credentials("lambda_labs", instance_id)
        if not _managed:
            logger.warning(f"[Broker] Lambda Labs credentials unavailable, skipping fence for {instance_id}")
            return
        _ll_api_key = _managed.get("api_key", "")
    # Lambda Basic auth: base64("api_key:") — key as username, empty password
    _ll_basic = _b64.b64encode(f"{_ll_api_key}:".encode()).decode()
    _headers = {"Authorization": f"Basic {_ll_basic}"}
    try:
        async with aiohttp.ClientSession() as s:
            resp = await s.post(
                f"{_ll_base_url}/instance-operations/terminate",
                headers=_headers,
                json={"instance_ids": [instance_id]},
            )
            if resp.status == 200:
                logger.info(f"[Broker] Instance {instance_id} terminate request accepted via Lambda Labs API")
            else:
                body = await resp.text()
                logger.warning(f"[Broker] Lambda Labs terminate returned {resp.status}: {body}")

            # Post-delete verification: poll GET /instances/{id} until terminated or 404
            for _attempt in range(12):  # 60s max
                await asyncio.sleep(5)
                try:
                    check = await s.get(
                        f"{_ll_base_url}/instances/{instance_id}",
                        headers=_headers,
                        timeout=aiohttp.ClientTimeout(total=10),
                    )
                    if check.status == 404:
                        logger.info(f"[Broker] Lambda instance {instance_id} confirmed gone (404)")
                        return
                    if check.status == 200:
                        _data = await check.json()
                        _status = _data.get("data", {}).get("status", "")
                        if _status in ("terminated",):
                            logger.info(f"[Broker] Lambda instance {instance_id} confirmed terminated")
                            return
                        logger.debug(f"[Broker] Lambda instance {instance_id} still {_status}")
                except Exception:
                    pass  # Network blip — keep polling
            raise RuntimeError(
                f"[Broker] Lambda instance {instance_id} NOT confirmed terminated after 60s — "
                f"potential billing leak"
            )
    except Exception as e:
        logger.error(f"[Broker] Lambda Labs fence failed for {instance_id}: {e}")
        raise
