"""
VaultLayer — Watchdog Agent
Monitors all active nodes. Intercepts termination signals.
Triggers emergency checkpoint sequences. Notifies Orchestration Agent.
Claude coverage: ~0% (all signal detection and narration is deterministic code)
"""

import asyncio
import os
import logging
from typing import Optional
from datetime import datetime

from shared.config import VaultLayerConfig
from shared.models import AgentEvent, EventType, Job, JobStatus
from shared.queue import AgentQueue, make_event
from shared.telemetry import make_telemetry, MetricCategory
from shared.job_logger import log_event
from agents.watchdog.signals import TerminationDetector, HeartbeatMonitor

logger = logging.getLogger(__name__)


class WatchdogAgent:
    """
    Agent 2 — The Watchdog.
    Responsibility: Detect interruptions, trigger checkpoints, alert Orchestration Agent.
    Claude coverage: ~0% — all logic is deterministic code; no LLM required.

    Publishes to:   vaultlayer:watchdog.alert
    Listens to:     (nothing — purely event-driven by polling)
    """

    AGENT_NAME = "watchdog_agent"
    HEARTBEAT_CHECK_INTERVAL = 15  # seconds between heartbeat checks

    def __init__(self, config: VaultLayerConfig, queue: AgentQueue):
        self.config = config
        self.queue = queue
        self._detector = TerminationDetector()
        self._heartbeat = HeartbeatMonitor()
        self._tel = make_telemetry(queue=queue, agent_name="watchdog_agent")
        self._active_jobs: dict[str, Job] = {}
        self._checkpoint_callbacks: dict[str, callable] = {}
        from collections import deque as _deque
        self._gpu_util_samples: dict = {}  # job_id -> deque of (timestamp, util_pct)

    # ?? Job Registration ????????????????????????????????????????????????????????

    def register_job(self, job: Job, checkpoint_callback: callable):
        """
        Register a job for protection.
        checkpoint_callback(job) is called when an emergency checkpoint is needed.
        """
        self._active_jobs[job.job_id] = job
        self._checkpoint_callbacks[job.job_id] = checkpoint_callback
        self._heartbeat.register_job(job.job_id)
        logger.info(f"Watchdog protecting job: {job.name} ({job.job_id})")

    def record_heartbeat(self, job_id: str, step: int = 0, loss: Optional[float] = None):
        """Called by the CLI sidecar every 30 seconds to signal the job is alive."""
        self._heartbeat.record_heartbeat(job_id)

    async def async_record_heartbeat(self, job_id: str, step: int = 0, loss: Optional[float] = None):
        """Record heartbeat locally AND persist to Redis for cloud-hosted watchdog (GAP-8b)."""
        self._heartbeat.record_heartbeat(job_id)
        # Persist to Redis so monitoring survives laptop crash.
        # Key "ts" is a Unix timestamp float — read by orchestration _heartbeat_monitor_loop
        # via hget(key, "ts") and compared against time.time(). Must match that field name.
        import time as _time
        try:
            await self.queue.hset(
                f"vl:heartbeat:{job_id}",
                mapping={
                    "ts": str(_time.time()),
                    "step": str(step),
                    "loss": str(loss) if loss is not None else "",
                },
            )
            await self.queue.expire(f"vl:heartbeat:{job_id}", 3600)  # 1h TTL
        except Exception as _e:
            logger.warning(f"[Watchdog] Redis heartbeat persist failed for {job_id}: {_e}")

    def update_job_progress(self, job_id: str, step: int, epoch: float, loss: Optional[float] = None):
        """Update job progress ? called by the CLI sidecar."""
        if job_id in self._active_jobs:
            self._active_jobs[job_id].current_step = step
            self._active_jobs[job_id].current_epoch = epoch

    # ?? Emergency Checkpoint ???????????????????????????????????????????????????

    async def _emergency_checkpoint(self, job: Job, reason: str, termination_time: Optional[str] = None):
        """
        Trigger an emergency checkpoint and notify Orchestration Agent.
        This is the critical path ? must complete within the termination window.
        """
        logger.critical(f"[{job.job_id}] Emergency checkpoint triggered: {reason}")
        if self._tel:
            self._tel.event("watchdog.termination_detected",
                            tags={"reason": reason, "provider": job.provider.value},
                            job_id=job.job_id, category=MetricCategory.PROVIDER)
        event_type = "heartbeat_miss" if reason.startswith("heartbeat_miss") else "interruption_detected"
        await log_event(
            job_id=job.job_id,
            user_id=job.user_id,
            event_type=event_type,
            message=f"Emergency checkpoint triggered: {reason}",
            metadata={"reason": reason, "provider": job.provider.value,
                      "step": job.current_step, "termination_time": termination_time},
        )

        # 1. Call the checkpoint callback (invokes Vault Agent)
        callback = self._checkpoint_callbacks.get(job.job_id)
        if callback:
            try:
                await callback(job)
                checkpoint_success = True
                if self._tel:
                    self._tel.timing("watchdog.checkpoint_triggered_ms", 0,
                                     job_id=job.job_id)  # timestamp marker
            except Exception as e:
                logger.error(f"Checkpoint failed: {e}")
                checkpoint_success = False
                if self._tel:
                    self._tel.error("watchdog.checkpoint_failed", exc=e,
                                    tags={"provider": job.provider.value}, job_id=job.job_id)
        else:
            checkpoint_success = False
            logger.error(f"No checkpoint callback registered for job {job.job_id}")

        # 2. Generate Claude narration
        event_data = {
            "reason": reason,
            "job_name": job.name,
            "job_id": job.job_id,
            "current_step": job.current_step,
            "current_epoch": job.current_epoch,
            "provider": job.provider.value,
            "termination_time": termination_time,
            "checkpoint_success": checkpoint_success,
            "timestamp": datetime.utcnow().isoformat(),
        }
        narration = self._narrate_event(event_data, job)

        # 3. Publish alert to Orchestration Agent
        await self.queue.publish(
            "watchdog",
            make_event(
                event_type=EventType.TERMINATION_SIGNAL,
                source_agent=self.AGENT_NAME,
                job_id=job.job_id,
                payload={
                    "reason": reason,
                    "termination_time": termination_time,
                    "checkpoint_success": checkpoint_success,
                    "current_step": job.current_step,
                    "current_epoch": job.current_epoch,
                    "narration": narration,
                    "requires_migration": True,
                },
                priority=1,  # highest priority
            ),
        )

        # 4. Publish NAMESPACE_SYNC_COMPLETE if checkpoint succeeded — triggers immediate warm-start
        if checkpoint_success:
            await self.queue.publish(
                "watchdog",
                make_event(
                    event_type=EventType.NAMESPACE_SYNC_COMPLETE,
                    source_agent=self.AGENT_NAME,
                    job_id=job.job_id,
                    payload={
                        "checkpoint_step": job.current_step,
                        "checkpoint_epoch": job.current_epoch,
                        "reason": reason,
                        "termination_time": termination_time,
                    },
                    priority=1,
                ),
            )

        logger.info(f"[{job.job_id}] Orchestration Agent notified: {narration}")
        return checkpoint_success

    # ?? Heartbeat Check Loop ???????????????????????????????????????????????????

    async def _heartbeat_loop(self):
        """Periodically check all jobs for missed heartbeats."""
        while True:
            await asyncio.sleep(self.HEARTBEAT_CHECK_INTERVAL)
            unhealthy = self._heartbeat.check_all()
            for item in unhealthy:
                job_id = item["job_id"]
                job = self._active_jobs.get(job_id)
                if not job:
                    continue
                miss_count = item["miss_count"]

                if miss_count >= HeartbeatMonitor.MISS_THRESHOLD_CHECKPOINT:
                    logger.warning(
                        f"[{job_id}] {miss_count} missed heartbeats ? forcing checkpoint"
                    )
                    await self._emergency_checkpoint(job, f"heartbeat_miss_{miss_count}")

                elif miss_count >= HeartbeatMonitor.MISS_THRESHOLD_WARN:
                    # Publish warning — Orchestration Agent will log but not act yet
                    await self.queue.publish(
                        "watchdog",
                        make_event(
                            event_type=EventType.HEARTBEAT_MISS,
                            source_agent=self.AGENT_NAME,
                            job_id=job_id,
                            payload=item,
                            priority=3,
                        ),
                    )

    # ?? Termination Signal Loop ????????????????????????????????????????????????

    async def _watch_termination_signals(self):
        """
        Poll for spot interruption signals from all active providers.
        - AWS: polls instance metadata endpoint (169.254.169.254) every 5s
        - RunPod: polls /runpod-volume/termination or checks pod status API
        - Vast.ai: polls vast API for instance state change
        Runs as a background task for the lifetime of the job.
        """
        """Start polling for AWS Spot termination signals on all active jobs."""

        import aiohttp

        async def check_aws_spot_termination() -> bool:
            """Poll AWS instance metadata for spot termination notice via IMDSv2."""
            is_terminating, _ = await self._detector.check_termination()
            return is_terminating

        async def check_runpod_termination(job) -> bool:
            """Check if RunPod has reclaimed or is reclaiming this instance."""
            api_key = os.environ.get("RUNPOD_API_KEY", "")
            if not api_key or not job.instance_id:
                return False
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5)) as s:
                    async with s.get(
                        f"https://rest.runpod.io/v2/pod/{job.instance_id}",
                        headers={"Authorization": f"Bearer {api_key}"}
                    ) as r:
                        if r.status != 200:
                            return False
                        data = await r.json()
                        status = data.get("desiredStatus", "")
                        # EXITED or TERMINATED means RunPod reclaimed the pod
                        return status in ("EXITED", "TERMINATED", "STOPPED")
            except Exception:
                return False

        async def check_vast_termination(job) -> bool:
            """Check if Vast.ai host has interrupted this instance."""
            api_key = os.environ.get("VAST_AI_API_KEY", "")
            if not api_key or not job.instance_id:
                return False
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5)) as s:
                    async with s.get(
                        f"https://console.vast.ai/api/v0/instances/{job.instance_id}/",
                        headers={"Authorization": f"Bearer {api_key}"}
                    ) as r:
                        if r.status != 200:
                            return False
                        data = await r.json()
                        status = data.get("actual_status", "")
                        # "stopped" or "deleted" means interruption
                        return status in ("stopped", "deleted", "exited")
            except Exception:
                return False

        async def on_signal(termination_time: str):
            for job in list(self._active_jobs.values()):
                provider_val = job.provider.value if job.provider else ""
                interrupted = False
                if "aws" in provider_val:
                    interrupted = await check_aws_spot_termination()
                elif "runpod" in provider_val:
                    interrupted = await check_runpod_termination(job)
                elif "vast" in provider_val:
                    interrupted = await check_vast_termination(job)
                if interrupted:
                    # Fix-3: Signal the training process to finish its current step
                    # and save an emergency checkpoint before we upload to R2.
                    _training_pid = os.environ.get("VAULTLAYER_TRAINING_PID", "")
                    if _training_pid:
                        try:
                            import signal as _sig
                            _pid = int(_training_pid)
                            os.kill(_pid, _sig.SIGUSR1)
                            logger.info(
                                f"[Watchdog] Sent SIGUSR1 to training process "
                                f"PID={_pid} — waiting up to 10s for graceful save"
                            )
                            # Brief wait — gives the training process time to finish
                            # its current optimizer.step() and save the checkpoint
                            await asyncio.sleep(10)
                        except (ValueError, ProcessLookupError, PermissionError) as _e:
                            logger.warning(f"[Watchdog] Could not signal training PID: {_e}")
                    await self._emergency_checkpoint(
                        job,
                        reason="aws_spot_termination",
                        termination_time=termination_time,
                    )

        await self._detector.poll(on_signal=on_signal)

    # ?? Claude Narration ???????????????????????????????????????????????????????


    # ??????????????????????????????????????????????????????????????????????
    # OOM Detection
    # ??????????????????????????????????????????????????????????????????????

    def _sync_job(self, job):
        """
        Return the most up-to-date job reference.
        run.py may have updated job.current_step or job.status on the original object.
        Since all agents share the same process, we check _active_jobs by job_id
        to ensure we are looking at the canonical reference, not a stale copy.
        """
        return self._active_jobs.get(job.job_id, job)

    async def check_oom(self, job: Job) -> bool:
        job = self._sync_job(job)  # always use canonical reference
        """
        Detect out-of-memory events by scanning dmesg and process logs.
        Returns True if OOM or CUDA OOM detected for this job.
        """
        oom_patterns = [
            "Out of memory: Kill process",
            "CUDA out of memory",
            "RuntimeError: CUDA error: out of memory",
            "torch.cuda.OutOfMemoryError",
        ]
        try:
            # Check dmesg for kernel OOM killer
            proc = await asyncio.create_subprocess_exec(
                "dmesg", "--level=err,crit",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
            dmesg_output = stdout.decode(errors="replace")

            for pattern in oom_patterns:
                if pattern in dmesg_output:
                    logger.warning(f"OOM detected for job {job.job_id}: {pattern}")
                    if self._tel:
                        self._tel.event("watchdog.oom_detected",
                                        tags={"pattern": pattern[:60], "provider": job.provider.value},
                                        job_id=job.job_id, category=MetricCategory.ERROR)
                    await self._handle_failure(job, reason="OOM", detail=pattern)
                    return True
        except Exception as e:
            logger.debug(f"OOM check skipped: {e}")
        return False

    # ??????????????????????????????????????????????????????????????????????
    # GPU Hardware Failure Detection
    # ??????????????????????????????????????????????????????????????????????

    async def check_gpu_failure(self, job: Job) -> bool:
        job = self._sync_job(job)  # always use canonical reference
        """
        Detect GPU hardware failures: CUDA errors, Xid events, process crashes.
        Returns True if a GPU hardware failure is detected.
        """
        gpu_error_patterns = [
            "NVRM: Xid",          # NVIDIA Xid error (hardware fault)
            "cuda: error",
            "CUDA Error",
            "GPU has fallen off the bus",
            "ECC error",
        ]
        try:
            proc = await asyncio.create_subprocess_exec(
                "dmesg", "--level=err,crit,warn",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
            output = stdout.decode(errors="replace")

            for pattern in gpu_error_patterns:
                if pattern.lower() in output.lower():
                    logger.error(f"GPU hardware failure detected for job {job.job_id}: {pattern}")
                    if self._tel:
                        self._tel.error("watchdog.gpu_failure",
                                        tags={"pattern": pattern[:60], "provider": job.provider.value},
                                        job_id=job.job_id)
                    await self._handle_failure(job, reason="GPU_HARDWARE_FAILURE", detail=pattern)
                    return True
        except Exception as e:
            logger.debug(f"GPU failure check skipped: {e}")
        return False

    # ??????????????????????????????????????????????????????????????????????
    # Hung Job Timeout Detection
    # ??????????????????????????????????????????????????????????????????????

    # Market standard: DCGM polls every 15s; Nebius MTTR=12min (detect+provision+start);
    # TorchPass migration=2min. 5min detection leaves 7min for recovery within 12min MTTR.
    # Large model checkpointing can pause GPU for 30-60s -- 5min safely clears that.
    # Override: VL_HUNG_JOB_TIMEOUT_SECS env var.
    HUNG_JOB_TIMEOUT_SECONDS = int(os.environ.get("VL_HUNG_JOB_TIMEOUT_SECS", "300"))  # 5 min default
    _HUNG_JOB_GRACE_FACTOR = 1.1  # 10% grace period to avoid false positives near threshold

    async def check_hung_job(self, job: Job) -> bool:
        """
        Detect jobs that have stopped making training progress.
        Uses last_heartbeat_at on the Job object as the progress timestamp.
        Returns True if the job appears hung.
        """
        job = self._sync_job(job)  # always use canonical reference
        if not hasattr(job, "last_heartbeat_at") or job.last_heartbeat_at is None:
            return False
        elapsed = (datetime.utcnow() - job.last_heartbeat_at).total_seconds()
        if elapsed > self.HUNG_JOB_TIMEOUT_SECONDS:
            if self._tel:
                self._tel.event("watchdog.hung_job_detected",
                         tags={"elapsed_min": str(round(elapsed/60, 1)), "provider": job.provider.value},
                         job_id=job.job_id, category=MetricCategory.ERROR)
            logger.error(
                f"Hung job detected: {job.job_id} has not made progress in "
                f"{elapsed / 60:.1f} min (threshold: {self.HUNG_JOB_TIMEOUT_SECONDS / 60:.0f} min)"
            )
            await self._handle_failure(job, reason="hung_job", detail=f"No progress for {elapsed/60:.1f} min")
            return True
        return False

    async def _poll_gpu_utilization(self, job_id: str) -> float:
        """
        Poll GPU utilization via nvidia-smi subprocess.
        Returns utilization % (0-100) or -1 if unavailable (no GPU / nvidia-smi not installed).
        Uses "nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits"
        which is the standard lightweight check used before DCGM integration.
        DCGM is the production standard (15s polls, cluster-wide) but requires NVIDIA GPU Operator.
        nvidia-smi subprocess is the correct fallback for single-node discount cloud providers.
        """
        import asyncio as _asyncio
        try:
            proc = await _asyncio.create_subprocess_exec(
                "nvidia-smi", "--query-gpu=utilization.gpu",
                "--format=csv,noheader,nounits",
                stdout=_asyncio.subprocess.PIPE,
                stderr=_asyncio.subprocess.DEVNULL,
            )
            stdout, _ = await _asyncio.wait_for(proc.communicate(), timeout=5)
            lines = stdout.decode().strip().splitlines()
            if lines:
                # Multi-GPU: average across all GPUs
                utils = [float(u.strip()) for u in lines if u.strip().isdigit() or u.strip().replace(".", "").isdigit()]
                return sum(utils) / len(utils) if utils else -1
        except (FileNotFoundError, _asyncio.TimeoutError, ValueError):
            pass  # nvidia-smi not available (CPU-only instance or not in PATH)
        except Exception as e:
            logger.debug(f"GPU util poll failed for {job_id}: {e}")
        return -1

    async def _check_gpu_zero_utilization(self, job: Job) -> bool:
        """
        Detect silent zombie: GPU util=0% for VL_GPU_UTIL_ZERO_SECS (default 150s = 5 consecutive 30s polls).
        Complementary to heartbeat check -- catches CUDA hangs where the process is alive but GPU is frozen.
        Does NOT fire during normal checkpoint pauses (typically 30-60s) because threshold is 150s.
        Returns True if GPU has been at 0% for the full threshold duration.
        """
        import time as _time
        from collections import deque
        THRESHOLD_SECS = int(os.environ.get("VL_GPU_UTIL_ZERO_SECS", "150"))
        now = _time.monotonic()
        if job.job_id not in self._gpu_util_samples:
            self._gpu_util_samples[job.job_id] = deque(maxlen=20)
        # Only poll GPU if we don't already have a fresh sample in the last 25s
        samples = self._gpu_util_samples[job.job_id]
        last_sample_age = (now - samples[-1][0]) if samples else float("inf")
        if last_sample_age > 25:
            util = await self._poll_gpu_utilization(job.job_id)
            if util < 0:
                # nvidia-smi unavailable -- skip check only if no pre-existing samples
                if not samples:
                    return False
            else:
                self._gpu_util_samples[job.job_id].append((now, util))
                samples = self._gpu_util_samples[job.job_id]
        # Check if all samples in the last THRESHOLD_SECS are zero
        cutoff = now - THRESHOLD_SECS
        recent = [(t, u) for t, u in samples if t >= cutoff]
        if len(recent) < 3:
            return False  # not enough samples yet
        all_zero = all(u == 0 for _, u in recent)
        if all_zero:
            logger.warning(f"Silent zombie detected: job {job.job_id} GPU util=0% for {THRESHOLD_SECS}s")
            if self._tel:
                self._tel.event("watchdog.silent_zombie_detected",
                    tags={"job_id": job.job_id, "provider": getattr(job.provider,"value","unknown"),
                          "threshold_secs": str(THRESHOLD_SECS)})
            return True
        return False
    async def _handle_failure(self, job: Job, reason: str, detail: str):
        """Shared handler: trigger emergency checkpoint and publish alert."""
        checkpoint_success = False
        try:
            await self.queue.publish("vault", make_event(
                event_type=EventType.CHECKPOINT_REQUESTED,
                source_agent=self.AGENT_NAME,
                job_id=job.job_id,
                payload={"reason": reason, "detail": detail, "priority": "emergency"},
                priority=1,
            ))
            checkpoint_success = True
        except Exception as e:
            logger.error(f"Emergency checkpoint failed for {job.job_id}: {e}")

        await self.queue.publish("watchdog", make_event(
            event_type=EventType.TERMINATION_SIGNAL,
            source_agent=self.AGENT_NAME,
            job_id=job.job_id,
            payload={
                "reason": reason,
                "detail": detail,
                "checkpoint_success": checkpoint_success,
                "timestamp": datetime.utcnow().isoformat(),
            },
            priority=1,
        ))

    @staticmethod
    def _narrate_event(event_data: dict, job: Job) -> str:
        """Build a structured event log line from known fields. No LLM needed."""
        reason = event_data.get("reason", "unknown signal")
        checkpoint_ok = event_data.get("checkpoint_success", False)
        checkpoint_str = "checkpoint saved" if checkpoint_ok else "checkpoint failed"
        detail = event_data.get("detail", "")
        detail_str = f" ({detail})" if detail else ""
        return (
            f"[{job.provider.value}] '{job.name}' — {reason}{detail_str} "
            f"at step {job.current_step}. {checkpoint_str.capitalize()}."
        )

    # ?? Periodic Health Broadcast ??????????????????????????????????????????????

    async def _health_check_loop(self) -> None:
        """
        Core active monitoring loop. Runs every 30s, calls all health checks for every active job.
        This is the main zombie-detection engine. Without this loop, check_hung_job and
        check_gpu_failure are dead code -- they exist but are never invoked.
        Market standard: DCGM polls every 15s; we poll every 30s as a lightweight alternative.
        """
        import asyncio as _asyncio
        while True:
            await _asyncio.sleep(30)
            for job in list(self._active_jobs.values()):
                try:
                    # 1. GPU utilization zero-detection (silent zombie)
                    if await self._check_gpu_zero_utilization(job):
                        continue
                    # 2. Hung job (no heartbeat progress)
                    if await self.check_hung_job(job):
                        continue
                    # 3. GPU hardware failure (XID errors / CUDA errors)
                    if await self.check_gpu_failure(job):
                        continue
                    # 4. OOM
                    if await self.check_oom(job):
                        continue
                except Exception as _e:
                    logger.error(f"Health check error for job {job.job_id}: {_e}")
    async def _health_broadcast_loop(self):
        """Broadcast healthy status every 60s so Orchestration Agent knows Watchdog is alive."""
        while True:
            await asyncio.sleep(60)
            if self._active_jobs:
                await self.queue.publish(
                    "watchdog",
                    make_event(
                        event_type=EventType.NODE_HEALTHY,
                        source_agent=self.AGENT_NAME,
                        payload={
                            "active_jobs": len(self._active_jobs),
                            "jobs": list(self._active_jobs.keys()),
                        },
                        priority=8,
                    ),
                )

    # ?? Lifecycle ??????????????????????????????????????????????????????????????

    async def _listen_credits_events(self):
        """
        Subscribe to the watchdog channel for CREDITS_EXHAUSTED events published
        by OrchestrationAgent's credit burn loop. Dispatches to handle_credits_exhausted().
        """
        async def _on_event(event: AgentEvent):
            if event.event_type != EventType.CREDITS_EXHAUSTED:
                return
            job_id = event.job_id
            if not job_id:
                return
            job = self._active_jobs.get(job_id)
            if not job:
                logger.warning(f"[Watchdog] CREDITS_EXHAUSTED for unknown job {job_id}")
                return
            available = event.payload.get("available_credits", 0) if event.payload else 0
            await self.handle_credits_exhausted(job, available_credits=available)

        await self.queue.subscribe(["watchdog"], _on_event)

    async def _listen_broker_events(self):
        """
        GAP-8: Subscribe to broker channel for MIGRATION_COMPLETE / NODE_PROVISIONED events.
        Re-attaches heartbeat monitoring to the new node after a successful migration,
        so the watchdog doesn't go blind after arbitrage moves the job.
        """
        async def _on_broker_event(event: AgentEvent):
            if event.event_type == EventType.MIGRATION_COMPLETE:
                # Broker publishes MIGRATION_COMPLETE with instance_id/provider of the NEW node.
                # Reuse handle_node_provisioned to reset heartbeat grace period.
                reattach_event = AgentEvent(
                    event_type=EventType.NODE_PROVISIONED,
                    source_agent=event.source_agent,
                    job_id=event.job_id,
                    payload={
                        "reattach_watchdog": True,
                        "new_instance_id": (event.payload or {}).get("instance_id", ""),
                        "new_provider": (event.payload or {}).get("target_provider", ""),
                    },
                )
                await self.handle_node_provisioned(reattach_event)
            elif event.event_type == EventType.NODE_PROVISIONED:
                await self.handle_node_provisioned(event)

        await self.queue.subscribe(["broker"], _on_broker_event)

    async def start(self):
        """Start all Watchdog loops concurrently."""
        logger.info(f"Watchdog Agent starting — protecting {len(self._active_jobs)} jobs")
        await asyncio.gather(
            self._watch_termination_signals(),
            self._heartbeat_loop(),
            self._health_broadcast_loop(),
            self._health_check_loop(),
            self._listen_credits_events(),
            self._listen_broker_events(),
        )

    async def stop(self):
        logger.info("Watchdog Agent stopping.")
    async def handle_termination(self, job, signal_type=None, reason=None, termination_time=None):
        """Trigger emergency checkpoint and publish termination signal to watchdog channel."""
        effective_reason = signal_type or reason or "SPOT_INTERRUPTION"
        return await self._emergency_checkpoint(job, reason=effective_reason, termination_time=termination_time)

    async def handle_credits_exhausted(self, job: Job, available_credits: int = 0) -> None:
        """
        Credits exhausted — emergency checkpoint then suspend.

        Unlike termination (which migrates to a new node), credit exhaustion
        suspends the job in place. The checkpoint is saved to R2. When the user
        tops up, OrchestrationAgent receives CREDITS_TOPPED_UP and resumes from
        the last checkpoint.
        """
        logger.warning(
            f"[Watchdog] Credits exhausted for job {job.job_id} "
            f"({available_credits} credits remaining). Emergency checkpoint → suspend."
        )
        await self._emergency_checkpoint(job, reason="CREDITS_EXHAUSTED")
        suspend_event = AgentEvent(
            event_type=EventType.CREDITS_EXHAUSTED,
            source_agent="watchdog",
            job_id=job.job_id,
            payload={
                "action": "suspended",
                "available_credits": available_credits,
                "checkpoint_step": job.current_step,
                "message": (
                    f"Job suspended — credits exhausted. "
                    f"Checkpoint saved at step {job.current_step}. "
                    f"Top up at https://vaultlayer.ai/credits then run: "
                    f"vaultlayer restart --job-id {job.job_id}"
                ),
            },
        )
        await self.queue.publish("finops", suspend_event)
        await self.queue.publish("escalate", suspend_event)

    async def handle_node_provisioned(self, event: AgentEvent) -> None:
        """
        GAP-8: Handle NODE_PROVISIONED events with reattach_watchdog=True.
        Re-registers the job's heartbeat monitoring after migration to a new node,
        resetting last_heartbeat_at so the job gets a fresh grace period.
        """
        if not event.payload.get("reattach_watchdog"):
            return
        job_id = event.job_id
        if not job_id:
            return
        job = self._active_jobs.get(job_id)
        if not job:
            logger.warning(f"[Watchdog] NODE_PROVISIONED reattach: job {job_id} not in active_jobs — ignoring")
            return
        # Reset heartbeat so the job gets a fresh grace period on the new node
        self._heartbeat.register_job(job_id)
        if hasattr(job, "last_heartbeat_at"):
            job.last_heartbeat_at = datetime.utcnow()
        new_instance_id = event.payload.get("new_instance_id", "")
        new_provider = event.payload.get("new_provider", "")
        logger.info(
            f"[Watchdog] Reattached heartbeat monitoring for job {job_id} "
            f"on new node {new_instance_id} ({new_provider})"
        )

