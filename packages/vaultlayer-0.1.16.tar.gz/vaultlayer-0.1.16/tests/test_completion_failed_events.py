"""Regression coverage for failed completion events and provision-failure holds."""
from __future__ import annotations

import inspect


def test_check_completion_accepts_failed_events_and_preserves_message():
    """A failed job event must be treated as terminal even if final logs fail."""
    from api import job_worker

    src = inspect.getsource(job_worker._check_completion)
    assert '.select("event_type, message")' in src
    assert '.in_("event_type", ["completed", "failed"])' in src
    assert 'job["_completion_event_type"] = _evt_type' in src
    assert 'job["_completion_event_message"] = _evt.get("message", "")' in src


def test_worker_uses_failed_event_as_exit_code_fallback():
    """Without the Training-finished log line, failed events still settle failed."""
    from api import job_worker

    src = inspect.getsource(job_worker._job_worker)
    assert 'job.get("_completion_event_type") == "failed"' in src
    assert 'exit_code=(-?\\d+)' in src
    assert '_exit = int(_m.group(1)) if _m else 1' in src
    assert 'exit code from failed event' in src


def test_terminal_provision_failures_release_submit_reservation():
    """Jobs that never launch must release the submit-time reservation."""
    from api import job_worker

    src = inspect.getsource(job_worker._handle_provision_result)
    assert src.count('_release_submit_reservation(job, "failed")') >= 2
    exhausted_idx = src.index("provision budget exhausted")
    nonretry_idx = src.index("non-retryable failure")
    assert '_release_submit_reservation(job, "failed")' in src[exhausted_idx - 500:exhausted_idx]
    assert '_release_submit_reservation(job, "failed")' in src[nonretry_idx - 500:nonretry_idx]
