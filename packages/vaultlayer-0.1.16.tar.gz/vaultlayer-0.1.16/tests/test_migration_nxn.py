"""
VaultLayer — Full N×N Provider Migration Matrix
================================================

Tests every source → destination pair across all 11 compute providers.

  11 sources × 11 destinations = 121 migration paths
  (includes same-cloud spot replacement, e.g. RunPod → RunPod)

For each path the test verifies:
  ✓ execute_migration() completes without exception
  ✓ MIGRATION_STARTED published
  ✓ correct provision_<dest>() called with the job
  ✓ job.instance_id updated to new node
  ✓ job.provider updated to destination
  ✓ NODE_PROVISIONED published to broker → OrchestrationAgent forwards to Vault
  ✓ NODE_PROVISIONED carries command=restore + dataset_id
  ✓ MIGRATION_COMPLETE published with correct target_provider
  ✓ STONITH fires for voluntary migrations (not for termination_signal)
  ✓ bootstrap script on the new node has rclone + R2 creds + dataset

Two event_type paths per cell:
  • "termination_signal" → fence skipped (source already dead)
  • "arbitrage_opportunity" → fence fired before provision

Total assertions: 121 paths × 10 checks × 2 event-type paths = 2420 assertions
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import base64
import contextlib
import pytest
from unittest.mock import patch, AsyncMock, MagicMock
from itertools import product

from conftest import MockAgentQueue, make_job
from shared.models import Job, JobStatus, Provider, GPUType, EventType, AgentEvent
from shared.config import (
    VaultLayerConfig, AWSConfig, LambdaLabsConfig, CoreWeaveConfig,
    CloudflareConfig, RedisConfig, AnthropicConfig,
)


# ── Provider catalogue ────────────────────────────────────────────────────────

ALL_PROVIDERS = [
    # (label,           Provider enum,          provision_method,          instance_id)
    ("AWS",            Provider.AWS,            "provision_aws",            "i-aws-{idx}"),
    ("Lambda Labs",    Provider.LAMBDA_LABS,    "provision_lambda",         "ll-{idx}"),
    ("CoreWeave",      Provider.COREWEAVE,      "provision_coreweave",      "cw-{idx}"),
    ("GCP",            Provider.GCP,            "provision_gcp",            "vl-gcp-{idx}"),
    ("Azure",          Provider.AZURE,          "provision_azure",          "vl-az-{idx}/10.0.0.{idx}"),
    ("RunPod",         Provider.RUNPOD,         "provision_runpod",         "rp-{idx}"),
    ("Vast.ai",        Provider.VAST_AI,        "provision_vast",           "vast-{idx}"),
    ("Voltage Park",   Provider.VOLTAGE_PARK,   "provision_voltage_park",   "vp-{idx}"),
    ("Crusoe",         Provider.CRUSOE,         "provision_crusoe",         "crusoe-{idx}"),
    ("Nebius",         Provider.NEBIUS,         "provision_nebius",         "nebius-{idx}"),
    ("Hyperstack",     Provider.HYPERSTACK,     "provision_hyperstack",     "hs-{idx}"),
]

# Build the 11×11 matrix
MIGRATION_MATRIX = []
for idx, ((src_lbl, src_prov, _, __), (dst_lbl, dst_prov, dst_method, dst_id_tpl)) in \
        enumerate(product(ALL_PROVIDERS, ALL_PROVIDERS)):
    MIGRATION_MATRIX.append((
        src_lbl, src_prov,
        dst_lbl, dst_prov, dst_method,
        dst_id_tpl.replace("{idx}", str(idx)),
    ))

MATRIX_IDS = [f"{s}→{d}" for s, _, d, *_ in MIGRATION_MATRIX]


# ── Config & helpers ──────────────────────────────────────────────────────────

def _cfg():
    cfg = VaultLayerConfig(
        token="vl_test_" + "a" * 64,
        user_id="nxn-user",
        aws=AWSConfig(access_key_id="AK_NXN", secret_access_key="SK_NXN", region="us-east-1"),
        lambda_labs=LambdaLabsConfig(api_key="ll-nxn-key"),
        coreweave=CoreWeaveConfig(api_key="cw-nxn-key", namespace="nxn-ns"),
        cloudflare=CloudflareConfig(
            account_id="nxn-cf",
            r2_access_key_id="R2_NXN_KEY",
            r2_secret_access_key="R2_NXN_SECRET",
            r2_bucket="vl-nxn",
            r2_endpoint="https://nxn.r2.cloudflarestorage.com",
        ),
        redis=RedisConfig(url="redis://localhost:6379"),
        anthropic=AnthropicConfig(api_key="ant-nxn-key"),
    )
    for attr, key in [
        ("runpod",       "rp-nxn"),   ("vast_ai",      "vast-nxn"),
        ("voltage_park", "vp-nxn"),   ("crusoe",        "crusoe-nxn"),
        ("nebius",       "nebius-nxn"),("hyperstack",   "hs-nxn"),
    ]:
        m = MagicMock(); m.api_key = key; setattr(cfg, attr, m)
    gcp = MagicMock()
    gcp.service_account_json = "/fake/sa.json"
    gcp.project_id = "vl-nxn"; gcp.zone = "us-central1-a"
    cfg.gcp = gcp
    az = MagicMock()
    az.tenant_id = "t"; az.client_id = "c"; az.client_secret = "s"
    az.subscription_id = "sub"; az.resource_group = "rg"; az.location = "eastus"
    cfg.azure = az
    return cfg


def _job(src_provider: Provider, src_label: str) -> Job:
    """Synthetic training job on the source provider."""
    j = Job(
        job_id=f"nxn-job-{src_label.lower().replace(' ', '-')[:12]}",
        name=f"NxN test ({src_label})",
        status=JobStatus.RUNNING,
        provider=src_provider,
        gpu_type=GPUType.H100_80GB_SXM,
        instance_id=f"src-inst-{src_label.lower()[:6]}",
        region="us-east-1",
        model_params_billion=7.0,
        command="torchrun train.py",
        docker_image="pytorch/pytorch:2.3-cuda12.1",
        dataset_id="ds-nxn",
        environment={"ENV_A": "val_a"},
        current_step=5000,
        user_id="nxn-user",
        ssh_host="",    # no SSH → skip SSH branch in execute_migration
    )
    return j


def _published_types(queue, channel):
    return [
        e.event_type
        for (ch, e) in queue.published
        if ch == channel or ch == f"critical:{channel}"
    ]


def _event_payload(queue, channel, event_type):
    for (ch, e) in queue.published:
        if (ch == channel or ch == f"critical:{channel}") and e.event_type == event_type:
            return e.payload
    return None


def _make_broker(cfg):
    from agents.broker.agent import BrokerAgent
    return BrokerAgent(cfg, MockAgentQueue())


# ── Core migration context manager ────────────────────────────────────────────

def _migration_stack(broker, dst_method, new_instance_id, fence_mock):
    """Return an ExitStack with all network boundaries patched."""
    stack = contextlib.ExitStack()
    stack.enter_context(patch.object(broker, dst_method, AsyncMock(return_value=new_instance_id)))
    stack.enter_context(patch.object(broker, "_fence_old_node", fence_mock))
    stack.enter_context(patch.object(broker, "_check_quota", AsyncMock(return_value=True)))
    stack.enter_context(patch.object(broker, "_resolve_instance_host", AsyncMock(return_value="10.0.0.10")))
    stack.enter_context(patch.object(broker, "_try_same_provider_different_az", AsyncMock(return_value=None)))
    stack.enter_context(patch.object(broker, "_wait_for_ssh", AsyncMock(return_value=True)))
    stack.enter_context(patch.object(broker, "_wait_for_bootstrap", AsyncMock(return_value=True)))
    stack.enter_context(patch.object(broker, "_prefetch_checkpoint", AsyncMock()))
    stack.enter_context(patch.object(broker, "_probe_cuda", AsyncMock(return_value=(True, "530.30"))))
    stack.enter_context(patch.object(broker, "_restart_job_on_node", AsyncMock(return_value=True)))
    stack.enter_context(patch("agents.broker.migration.asyncio.sleep", new_callable=AsyncMock))
    stack.enter_context(patch("agents.broker.migration.log_event", new_callable=AsyncMock))
    stack.enter_context(patch("agents.broker.migration._PRICE_GUARD", False))
    stack.enter_context(patch("agents.broker.migration._HAS_CAPACITY", False))
    return stack


# ─────────────────────────────────────────────────────────────────────────────
# Test 1 — Spot termination path (source already dead, fence skipped)
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
@pytest.mark.parametrize(
    "src_lbl,src_prov,dst_lbl,dst_prov,dst_method,new_id",
    MIGRATION_MATRIX,
    ids=MATRIX_IDS,
)
async def test_spot_termination_path(
    src_lbl, src_prov, dst_lbl, dst_prov, dst_method, new_id
):
    """
    Source provider spot-terminates → migrate to destination.
    STONITH skipped (instance already dead).
    All 121 paths must complete with MIGRATION_COMPLETE.
    """
    cfg = _cfg()
    queue = MockAgentQueue()
    job = _job(src_prov, src_lbl)
    broker = _make_broker(cfg)
    broker.queue = queue

    fence_mock = AsyncMock()

    with _migration_stack(broker, dst_method, new_id, fence_mock):
        await broker.execute_migration(
            job=job,
            target_provider=dst_prov,
            target_gpu=GPUType.H100_80GB_SXM,
            decision_id=f"nxn-term-{src_lbl[:3]}-{dst_lbl[:3]}",
            event_type="termination_signal",
        )

    path = f"{src_lbl} → {dst_lbl}"

    # No fence (spot already dead)
    fence_mock.assert_not_called(), \
        f"[{path}] STONITH must NOT fire for termination_signal"

    # Job state updated
    assert job.instance_id == new_id, \
        f"[{path}] job.instance_id not updated"
    assert job.provider == dst_prov, \
        f"[{path}] job.provider not updated to {dst_prov.value}"

    # Full event trail
    broker_types = _published_types(queue, "broker")
    assert EventType.MIGRATION_STARTED in broker_types, \
        f"[{path}] MIGRATION_STARTED missing"
    assert EventType.MIGRATION_COMPLETE in broker_types, \
        f"[{path}] MIGRATION_COMPLETE missing"

    # NODE_PROVISIONED is now published to "broker" (Rule 3: only OrchestrationAgent
    # publishes to "orchestration"; OrchestrationAgent forwards to VaultAgent from there)
    assert EventType.NODE_PROVISIONED in broker_types, \
        f"[{path}] NODE_PROVISIONED missing — Vault restore won't trigger"

    # Payload correctness
    np_payload = _event_payload(queue, "broker", EventType.NODE_PROVISIONED)
    assert np_payload["command"] == "restore", \
        f"[{path}] NODE_PROVISIONED missing command=restore"
    assert np_payload["dataset_id"] == "ds-nxn", \
        f"[{path}] NODE_PROVISIONED missing dataset_id"

    mc_payload = _event_payload(queue, "broker", EventType.MIGRATION_COMPLETE)
    assert mc_payload["target_provider"] == dst_prov.value, \
        f"[{path}] MIGRATION_COMPLETE has wrong target_provider"
    assert mc_payload["instance_id"] == new_id, \
        f"[{path}] MIGRATION_COMPLETE has wrong instance_id"


# ─────────────────────────────────────────────────────────────────────────────
# Test 2 — Voluntary / arbitrage path (STONITH must fire)
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
@pytest.mark.parametrize(
    "src_lbl,src_prov,dst_lbl,dst_prov,dst_method,new_id",
    MIGRATION_MATRIX,
    ids=MATRIX_IDS,
)
async def test_voluntary_migration_path(
    src_lbl, src_prov, dst_lbl, dst_prov, dst_method, new_id
):
    """
    Cost-arbitrage migration (voluntary). Source instance still alive →
    STONITH must fire before provisioning the new node.
    All 121 paths must fence-then-provision in correct order.
    """
    cfg = _cfg()
    queue = MockAgentQueue()
    job = _job(src_prov, src_lbl)
    broker = _make_broker(cfg)
    broker.queue = queue

    order = []
    async def _fence(j):   order.append("fence")
    async def _provision(*a, **kw): order.append("provision"); return new_id

    with contextlib.ExitStack() as stack:
        stack.enter_context(patch.object(broker, dst_method, _provision))
        stack.enter_context(patch.object(broker, "_fence_old_node", _fence))
        stack.enter_context(patch.object(broker, "_check_quota", AsyncMock(return_value=True)))
        stack.enter_context(patch.object(broker, "_resolve_instance_host", AsyncMock(return_value="10.0.0.10")))
        stack.enter_context(patch.object(broker, "_try_same_provider_different_az", AsyncMock(return_value=None)))
        stack.enter_context(patch.object(broker, "_wait_for_ssh", AsyncMock(return_value=True)))
        stack.enter_context(patch.object(broker, "_wait_for_bootstrap", AsyncMock(return_value=True)))
        stack.enter_context(patch.object(broker, "_prefetch_checkpoint", AsyncMock()))
        stack.enter_context(patch.object(broker, "_probe_cuda", AsyncMock(return_value=(True, "530.30"))))
        stack.enter_context(patch.object(broker, "_restart_job_on_node", AsyncMock(return_value=True)))
        stack.enter_context(patch("agents.broker.migration.asyncio.sleep", new_callable=AsyncMock))
        stack.enter_context(patch("agents.broker.migration.log_event", new_callable=AsyncMock))
        stack.enter_context(patch("agents.broker.migration._PRICE_GUARD", False))
        stack.enter_context(patch("agents.broker.migration._HAS_CAPACITY", False))

        await broker.execute_migration(
            job=job,
            target_provider=dst_prov,
            target_gpu=GPUType.H100_80GB_SXM,
            decision_id=f"nxn-arb-{src_lbl[:3]}-{dst_lbl[:3]}",
            event_type="arbitrage_opportunity",
        )

    path = f"{src_lbl} → {dst_lbl}"

    assert "fence" in order, \
        f"[{path}] STONITH must fire for voluntary migration (split-brain guard)"
    assert "provision" in order, \
        f"[{path}] Provision must run after fence"
    assert order.index("fence") < order.index("provision"), \
        f"[{path}] STONITH must precede provision — got order: {order}"

    broker_types = _published_types(queue, "broker")
    assert EventType.MIGRATION_COMPLETE in broker_types, \
        f"[{path}] MIGRATION_COMPLETE missing after voluntary migration"


# ─────────────────────────────────────────────────────────────────────────────
# Test 3 — Bootstrap script carries R2 creds on all destination nodes
# ─────────────────────────────────────────────────────────────────────────────

# One row per destination (source doesn't affect the bootstrap content)
DST_ONLY = [
    (dst_lbl, dst_prov, dst_method, dst_id_tpl)
    for dst_lbl, dst_prov, dst_method, dst_id_tpl in [
        (lbl, prov, meth, iid) for lbl, prov, meth, iid in
        [(r[2], r[3], r[4], r[5]) for r in MIGRATION_MATRIX[:11]]
    ]
]

@pytest.mark.parametrize(
    "dst_lbl,dst_prov,dst_method,dst_id",
    [(lbl, prov, meth, iid) for lbl, prov, meth, iid in
     [(row[2], row[3], row[4], row[5]) for row in MIGRATION_MATRIX[:11]]],
    ids=[row[2] for row in MIGRATION_MATRIX[:11]],
)
def test_new_node_bootstrap_has_r2(dst_lbl, dst_prov, dst_method, dst_id):
    """
    Regardless of where the job came FROM, the bootstrap script delivered
    to the new node must have rclone + R2 credentials + dataset copy.
    Without this the new node can't restore the checkpoint or read training data.
    """
    cfg = _cfg()
    # Use AWS as an arbitrary source for the job
    job = _job(Provider.AWS, "AWS")
    broker = _make_broker(cfg)

    if dst_prov in (Provider.RUNPOD, Provider.VAST_AI):
        script = broker._build_container_onstart(job)
    elif dst_prov == Provider.AWS:
        script = base64.b64decode(broker._build_userdata(job)).decode()
    else:
        script = broker._build_vm_startup_script(job)

    assert "rclone" in script,          f"[→{dst_lbl}] bootstrap missing rclone"
    assert "R2_NXN_KEY" in script,      f"[→{dst_lbl}] bootstrap missing R2 access key"
    assert "R2_NXN_SECRET" in script,   f"[→{dst_lbl}] bootstrap missing R2 secret"
    assert "nxn.r2.cloudflarestorage.com" in script, \
                                         f"[→{dst_lbl}] bootstrap missing R2 endpoint"
    assert "CHECKPOINT_DIR" in script or "/mnt/vaultlayer" in script, \
        f"[→{dst_lbl}] bootstrap missing checkpoint path"
    assert "ds-nxn" in script,           f"[→{dst_lbl}] bootstrap missing dataset copy"


# ─────────────────────────────────────────────────────────────────────────────
# Test 4 — Provision method dispatch exists for every destination
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.parametrize(
    "dst_lbl,dst_prov,dst_method,_",
    [(row[2], row[3], row[4], row[5]) for row in MIGRATION_MATRIX[:11]],
    ids=[row[2] for row in MIGRATION_MATRIX[:11]],
)
def test_dispatch_branch_exists(dst_lbl, dst_prov, dst_method, _):
    """
    execute_migration's _provision_on() must have a branch for every provider.
    A missing branch silently returns None → all 3 retry attempts fail →
    ESCALATION event → user sees "ACTION REQUIRED".
    """
    import inspect
    from agents.broker.migration import execute_migration
    src = inspect.getsource(execute_migration)
    assert f"Provider.{dst_prov.name}" in src or dst_method in src, \
        f"[→{dst_lbl}] No dispatch branch in execute_migration for {dst_prov.value}"


# ─────────────────────────────────────────────────────────────────────────────
# Test 5 — Same-cloud spot replacement (source == destination)
# ─────────────────────────────────────────────────────────────────────────────

SAME_CLOUD = [
    (lbl, prov, meth, iid.replace("{idx}", "99"))
    for lbl, prov, meth, iid in [
        (row[2], row[3], row[4], row[5]) for row in MIGRATION_MATRIX[:11]
    ]
]

@pytest.mark.asyncio
@pytest.mark.parametrize(
    "label,provider,provision_method,new_id",
    SAME_CLOUD,
    ids=[row[0] for row in SAME_CLOUD],
)
async def test_same_cloud_spot_replacement(label, provider, provision_method, new_id):
    """
    Same-cloud replacement (e.g. RunPod → RunPod when a pod is evicted).
    STONITH skipped (instance already dead from spot preemption).
    New instance on same provider must be provisioned successfully.
    """
    cfg = _cfg()
    queue = MockAgentQueue()
    job = _job(provider, label)
    broker = _make_broker(cfg)
    broker.queue = queue

    with _migration_stack(broker, provision_method, new_id, AsyncMock()):
        await broker.execute_migration(
            job=job,
            target_provider=provider,          # same as source
            target_gpu=GPUType.H100_80GB_SXM,
            decision_id=f"same-cloud-{label[:6]}",
            event_type="termination_signal",
        )

    assert job.instance_id == new_id, \
        f"[{label}→{label}] job.instance_id not updated to replacement node"
    assert job.provider == provider

    broker_types = _published_types(queue, "broker")
    assert EventType.MIGRATION_COMPLETE in broker_types, \
        f"[{label}→{label}] MIGRATION_COMPLETE missing for same-cloud replacement"


# ─────────────────────────────────────────────────────────────────────────────
# Summary: matrix shape
# ─────────────────────────────────────────────────────────────────────────────

def test_matrix_is_complete():
    """Sanity check: the matrix covers all 11×11 = 121 paths."""
    assert len(MIGRATION_MATRIX) == 121, \
        f"Expected 121 paths (11×11), got {len(MIGRATION_MATRIX)}"

    providers_as_src = {row[1] for row in MIGRATION_MATRIX}
    providers_as_dst = {row[3] for row in MIGRATION_MATRIX}
    all_providers = {p for _, p, _, __ in ALL_PROVIDERS}

    assert providers_as_src == all_providers, \
        f"Missing sources: {all_providers - providers_as_src}"
    assert providers_as_dst == all_providers, \
        f"Missing destinations: {all_providers - providers_as_dst}"


# ─────────────────────────────────────────────────────────────────────────────
# Tests merged from test_migration_all_providers.py (unique coverage only)
# ─────────────────────────────────────────────────────────────────────────────

# Destination-only parametrization (one row per provider)
_DST_TARGETS = [
    (lbl, prov, meth, iid.replace("{idx}", str(i)))
    for i, (lbl, prov, meth, iid) in enumerate(ALL_PROVIDERS)
]
_DST_IDS = [row[0] for row in _DST_TARGETS]


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "label,target_provider,provision_method,new_instance_id",
    _DST_TARGETS,
    ids=_DST_IDS,
)
async def test_provision_failure_escalates(
    label, target_provider, provision_method, new_instance_id,
):
    """
    When provision fails on all attempts AND no alternatives exist AND
    AWS On-Demand is disabled, the broker publishes ESCALATION (never MIGRATION_COMPLETE).
    """
    cfg = _cfg()
    queue = MockAgentQueue()
    job = _job(Provider.AWS, "AWS")
    broker = _make_broker(cfg)
    broker.queue = queue

    with contextlib.ExitStack() as stack:
        for method in [
            "provision_aws", "provision_lambda", "provision_coreweave",
            "provision_gcp", "provision_azure", "provision_runpod",
            "provision_vast", "provision_voltage_park", "provision_crusoe",
            "provision_nebius", "provision_hyperstack", "provision_aws_on_demand",
        ]:
            stack.enter_context(patch.object(broker, method, AsyncMock(return_value=None)))

        stack.enter_context(patch.object(broker, "_fence_old_node", AsyncMock()))
        stack.enter_context(patch.object(broker, "_check_quota", AsyncMock(return_value=True)))
        stack.enter_context(patch.object(broker, "_try_same_provider_different_az", AsyncMock(return_value=None)))
        stack.enter_context(patch("agents.broker.migration.asyncio.sleep", new_callable=AsyncMock))
        stack.enter_context(patch("agents.broker.migration.log_event", new_callable=AsyncMock))
        stack.enter_context(patch("agents.broker.migration._PRICE_GUARD", False))
        stack.enter_context(patch("agents.broker.migration._HAS_CAPACITY", False))
        stack.enter_context(patch.dict(os.environ, {"VL_AWS_OD_FALLBACK_ENABLED": "false"}))
        queue._price_cache = []
        job.provision_failure_count = job.max_provision_failures - 1

        await broker.execute_migration(
            job=job,
            target_provider=target_provider,
            target_gpu=GPUType.H100_80GB_SXM,
            decision_id="test-fail-decision",
        )

    escalate_types = _published_types(queue, "escalate")
    assert EventType.ESCALATION in escalate_types, \
        f"[{label}] ESCALATION must be published when all provision attempts fail"

    broker_types = _published_types(queue, "broker")
    assert EventType.MIGRATION_COMPLETE not in broker_types, \
        f"[{label}] MIGRATION_COMPLETE must NOT be published when provision fails"

    assert job.status == JobStatus.FAILED, \
        f"[{label}] job.status must be FAILED when all provision attempts are exhausted"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "label,target_provider,provision_method,new_instance_id",
    _DST_TARGETS,
    ids=_DST_IDS,
)
async def test_quota_block_skips_provision(
    label, target_provider, provision_method, new_instance_id,
):
    """
    When _check_quota returns False (no capacity), no provision call is made
    and no MIGRATION_COMPLETE is published.
    """
    cfg = _cfg()
    queue = MockAgentQueue()
    job = _job(Provider.AWS, "AWS")
    broker = _make_broker(cfg)
    broker.queue = queue

    provision_mock = AsyncMock(return_value=new_instance_id)

    with contextlib.ExitStack() as stack:
        stack.enter_context(patch.object(broker, provision_method, provision_mock))
        stack.enter_context(patch.object(broker, "_fence_old_node", AsyncMock()))
        stack.enter_context(patch.object(broker, "_check_quota", AsyncMock(return_value=False)))
        stack.enter_context(patch("agents.broker.migration.asyncio.sleep", new_callable=AsyncMock))
        stack.enter_context(patch("agents.broker.migration.log_event", new_callable=AsyncMock))
        stack.enter_context(patch("agents.broker.migration._PRICE_GUARD", False))
        stack.enter_context(patch("agents.broker.migration._HAS_CAPACITY", False))

        result = await broker.execute_migration(
            job=job,
            target_provider=target_provider,
            target_gpu=GPUType.H100_80GB_SXM,
            decision_id="test-quota-decision",
        )

    assert result is None, f"[{label}] execute_migration must return None when quota is blocked"
    provision_mock.assert_not_called(), \
        f"[{label}] {provision_method} must NOT be called when quota check fails"
    broker_types = _published_types(queue, "broker")
    assert EventType.MIGRATION_COMPLETE not in broker_types, \
        f"[{label}] MIGRATION_COMPLETE must NOT be published when quota is blocked"


@pytest.mark.asyncio
async def test_event_ordering_aws_to_lambda():
    """
    MIGRATION_STARTED must be published BEFORE MIGRATION_COMPLETE.
    NODE_PROVISIONED must appear BETWEEN them.
    Validates pipeline ordering for one representative cross-provider path.
    """
    cfg = _cfg()
    queue = MockAgentQueue()
    job = _job(Provider.AWS, "AWS")
    broker = _make_broker(cfg)
    broker.queue = queue

    with _migration_stack(broker, "provision_lambda", "ll-i-order-test", AsyncMock()):
        await broker.execute_migration(
            job=job,
            target_provider=Provider.LAMBDA_LABS,
            target_gpu=GPUType.H100_80GB_SXM,
            decision_id="order-test-decision",
        )

    all_events = [(ch, e.event_type) for ch, e in queue.published]
    event_types_flat = [et for _, et in all_events]

    started_idx = next(
        (i for i, et in enumerate(event_types_flat) if et == EventType.MIGRATION_STARTED), -1
    )
    provisioned_idx = next(
        (i for i, et in enumerate(event_types_flat) if et == EventType.NODE_PROVISIONED), -1
    )
    complete_idx = next(
        (i for i, et in enumerate(event_types_flat) if et == EventType.MIGRATION_COMPLETE), -1
    )

    assert started_idx != -1, "MIGRATION_STARTED must be published"
    assert provisioned_idx != -1, "NODE_PROVISIONED must be published"
    assert complete_idx != -1, "MIGRATION_COMPLETE must be published"

    assert started_idx < provisioned_idx, \
        "MIGRATION_STARTED must precede NODE_PROVISIONED"
    assert provisioned_idx < complete_idx, \
        "NODE_PROVISIONED must precede MIGRATION_COMPLETE"


@pytest.mark.asyncio
async def test_migration_id_in_complete_payload():
    """
    MIGRATION_COMPLETE payload must carry migration_id in format
    '{job_id}:{decision_id[:8]}' so telemetry can correlate events.
    """
    cfg = _cfg()
    queue = MockAgentQueue()
    job = _job(Provider.AWS, "AWS")
    broker = _make_broker(cfg)
    broker.queue = queue

    decision_id = "abcdef1234567890"

    with _migration_stack(broker, "provision_coreweave", "cw-mid-test", AsyncMock()):
        await broker.execute_migration(
            job=job,
            target_provider=Provider.COREWEAVE,
            target_gpu=GPUType.H100_80GB_SXM,
            decision_id=decision_id,
        )

    mc_payload = _event_payload(queue, "broker", EventType.MIGRATION_COMPLETE)
    assert mc_payload is not None, "MIGRATION_COMPLETE must be published"
    migration_id = mc_payload.get("migration_id", "")
    assert job.job_id in migration_id, \
        "migration_id must contain job_id"
    assert decision_id[:8] in migration_id, \
        "migration_id must contain first 8 chars of decision_id"
