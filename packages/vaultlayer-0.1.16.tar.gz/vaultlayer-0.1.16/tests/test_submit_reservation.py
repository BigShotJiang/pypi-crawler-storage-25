"""Tests for issue #151: submit-time credit reservation is enforcing.

Key properties tested:
1. Reservation happens BEFORE queue insertion - failure returns 402/503, job never queued
2. Insufficient balance (reserve_credits_for_job returns ok=False) -> 402
3. DB error on reservation -> 503 before job enters queue
4. Idempotent: duplicate key treated as already reserved (no 503)
5. Cancel refund uses ACTUAL reservation amount (not floor)
6. No-reservation cancel does NOT grant an unearned refund
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
import pytest


def _make_user(uid="u-1"):
    return {"user_id": uid, "email": f"{uid}@test.com"}


def _make_body(gpu_type="A100_80GB_SXM"):
    body = MagicMock()
    body.gpu_type = gpu_type
    body.preferred_providers = []
    body.excluded_providers = []
    body.regions = []
    body.excluded_regions = []
    body.dataset_id = ""
    body.script_b64 = "cHJpbnQoJ2hpJyk="
    body.script_name = "train.py"
    body.environment = {}
    body.docker_image = ""
    body.failover = True
    body.resume_from_job_id = None
    body.min_vram_gb = 0
    body.gpu_auto_selected = False
    return body


def _run_submit(monkeypatch, reserve_result=None, reserve_raises=None):
    import api.flags as _flags
    monkeypatch.setattr(_flags, "TESTING_MODE", False)
    from api import job_routes
    mock_reserve = MagicMock()
    if reserve_raises is not None:
        mock_reserve.side_effect = reserve_raises
    else:
        mock_reserve.return_value = reserve_result if reserve_result is not None else {"ok": True}
    with patch.object(job_routes, "_has_dispatchable_candidate", return_value=True), \
         patch.object(job_routes, "_validate_provider_names"), \
         patch("api.db.get_balance", return_value={"available_credits": 500}), \
         patch("api.db.reserve_credits_for_job", mock_reserve), \
         patch.object(job_routes, "_active_jobs", {}), \
         patch.object(job_routes, "_job_queue", []), \
         patch("shared.job_run_logger.open_run", return_value="run-1"), \
         patch("shared.data_loader.get_provider_prices", return_value={}), \
         patch("shared.data_loader.resolve_gpu_key", return_value="A100"):
        import asyncio
        return asyncio.run(job_routes.submit_job(_make_body(), _make_user())), mock_reserve


def test_reservation_insufficient_balance_returns_402(monkeypatch):
    """reserve_credits_for_job returning ok=False/insufficient_balance must return 402."""
    from fastapi import HTTPException
    with pytest.raises(HTTPException) as exc_info:
        _run_submit(monkeypatch, reserve_result={"ok": False, "reason": "insufficient_balance", "available": 10})
    assert exc_info.value.status_code == 402


def test_reservation_db_error_returns_503(monkeypatch):
    """Non-idempotency DB error during reservation must return 503, job never queued."""
    from fastapi import HTTPException
    with pytest.raises(HTTPException) as exc_info:
        _run_submit(monkeypatch, reserve_raises=Exception("connection timeout"))
    assert exc_info.value.status_code == 503


def test_reservation_duplicate_key_is_idempotent(monkeypatch):
    """Duplicate key violation on reservation treated as already reserved, job queued."""
    result, _ = _run_submit(
        monkeypatch,
        reserve_raises=Exception('duplicate key value violates unique constraint "credit_events_stripe_payment_id_uq"'),
    )
    assert result.get("status") == "queued"


def test_reservation_success_job_is_queued(monkeypatch):
    """Successful reservation results in job being queued."""
    result, mock_reserve = _run_submit(monkeypatch, reserve_result={"ok": True, "idempotent": False})
    assert result.get("status") == "queued"
    mock_reserve.assert_called_once()


def test_reservation_idempotency_key_format(monkeypatch):
    """Reservation must use idempotency_key='submit:{job_id}' format."""
    result, mock_reserve = _run_submit(monkeypatch, reserve_result={"ok": True})
    call_kwargs = mock_reserve.call_args.kwargs
    assert call_kwargs["idempotency_key"].startswith("submit:")
    assert call_kwargs["amount_credits"] < 0


def _run_cancel(monkeypatch, reserved_amount, job_status="queued"):
    import api.flags as _flags_cancel
    monkeypatch.setattr(_flags_cancel, "TESTING_MODE", False)
    from api import job_routes
    job_id = "job-cancel-1"
    user = _make_user()
    mock_job = {"job_id": job_id, "user_id": user["user_id"], "status": job_status,
                "instance_id": None, "provider": None, "_run_id": None}
    mock_ev_data = ([{"amount_credits": -reserved_amount}] if reserved_amount is not None else [])
    mock_db = MagicMock()
    (mock_db.table.return_value.select.return_value
     .eq.return_value.limit.return_value.execute.return_value) = MagicMock(data=mock_ev_data)
    refund_calls = []
    def _mock_add_ev(*args, **kwargs):
        refund_calls.append(kwargs)
    with patch.object(job_routes, "_job_queue", [job_id] if job_status == "queued" else []), \
         patch("api.db.add_credit_event", side_effect=_mock_add_ev), \
         patch.object(job_routes, "get_db", return_value=mock_db), \
         patch.object(job_routes, "_db_call", side_effect=lambda fn, label="": fn()), \
         patch.object(job_routes, "require_job_ownership", return_value=mock_job), \
         patch.object(job_routes, "_settle_in_db"), \
         patch.object(job_routes, "_sync_job_status"):
        import asyncio
        asyncio.run(job_routes.cancel_job(job_id, user=user))
    return refund_calls


def test_cancel_refund_uses_actual_reservation_amount(monkeypatch):
    """Cancel refund uses the actual reserved amount, not the floor."""
    refund_calls = _run_cancel(monkeypatch, reserved_amount=350)
    refund_ev = next((c for c in refund_calls if c.get("event_type") == "refund"), None)
    assert refund_ev is not None, "A refund credit event must be issued on cancel"
    assert refund_ev["amount_credits"] == 350, f"Expected 350, got {refund_ev.get('amount_credits')}"
    assert refund_ev["stripe_payment_id"] == "submit_cancel_refund:job-cancel-1"


def test_cancel_no_reservation_skips_refund(monkeypatch):
    """If no reservation exists, cancel must not grant an unearned refund."""
    refund_calls = _run_cancel(monkeypatch, reserved_amount=None)
    refund_ev = next((c for c in refund_calls if c.get("event_type") == "refund"), None)
    assert refund_ev is None, "No refund must be issued when no reservation exists"


def test_cancel_floor_amount_reservation_refunds_correctly(monkeypatch):
    """A floor-amount reservation (50 credits) must refund exactly 50."""
    refund_calls = _run_cancel(monkeypatch, reserved_amount=50)
    refund_ev = next((c for c in refund_calls if c.get("event_type") == "refund"), None)
    assert refund_ev is not None
    assert refund_ev["amount_credits"] == 50
