"""Tests for issue #146: provision lock must be extended during long migration steps.

The distributed provision lock has a fixed 5-min TTL (acquire_provision_lock default).
Migration can exceed 5 minutes due to:
  - _wait_for_ssh (up to 180s)
  - _wait_for_bootstrap (variable)
  - CHECKPOINT_READY wait (up to 600s)
  - Docker image pull wait (10-20+ min)

Without lock renewal a second process can acquire the expired lock and provision
a duplicate node for the same job.

Fix: add extend_provision_lock() to provider_capacity.py and call it in
execute_migration() before the long checkpoint and docker pull waits.
"""
import pytest
import inspect


def test_extend_provision_lock_exists():
    """extend_provision_lock must be exported from shared.provider_capacity."""
    from shared.provider_capacity import extend_provision_lock
    assert callable(extend_provision_lock)


def test_extend_provision_lock_returns_true_when_no_redis():
    """extend_provision_lock must fail open (return True) when Redis is not configured."""
    from shared import provider_capacity as pc
    import unittest.mock

    with unittest.mock.patch.object(pc, "_get_redis", return_value=None):
        result = pc.extend_provision_lock("test-job-id", ttl_seconds=300)
    assert result is True


def test_extend_provision_lock_returns_false_when_key_missing():
    """extend_provision_lock returns False when the lock key no longer exists."""
    from shared import provider_capacity as pc
    import unittest.mock

    mock_redis = unittest.mock.MagicMock()
    mock_redis.expire.return_value = 0  # key does not exist

    with unittest.mock.patch.object(pc, "_get_redis", return_value=mock_redis):
        result = pc.extend_provision_lock("test-job-id", ttl_seconds=300)

    assert result is False
    mock_redis.expire.assert_called_once_with("vaultlayer:provlock:test-job-id", 300)


def test_extend_provision_lock_returns_true_when_key_exists():
    """extend_provision_lock returns True when the TTL was successfully extended."""
    from shared import provider_capacity as pc
    import unittest.mock

    mock_redis = unittest.mock.MagicMock()
    mock_redis.expire.return_value = 1  # key exists, TTL set

    with unittest.mock.patch.object(pc, "_get_redis", return_value=mock_redis):
        result = pc.extend_provision_lock("test-job-id", ttl_seconds=600)

    assert result is True


def test_migration_imports_extend_provision_lock():
    """execute_migration must import extend_provision_lock."""
    from agents.broker import migration
    src = inspect.getsource(migration)
    assert "extend_provision_lock" in src, (
        "migration.py must import and use extend_provision_lock"
    )


def test_migration_calls_extend_before_checkpoint_wait():
    """extend_provision_lock must be called before the 600s CHECKPOINT_READY wait."""
    from agents.broker import migration
    src = inspect.getsource(migration.execute_migration)

    extend_idx = src.find("extend_provision_lock")
    checkpoint_wait_idx = src.find("wait_for(_ckpt_event.wait")

    assert extend_idx != -1, "extend_provision_lock must be called in execute_migration"
    assert checkpoint_wait_idx != -1, "CHECKPOINT_READY wait must exist"
    assert extend_idx < checkpoint_wait_idx, (
        "extend_provision_lock must be called BEFORE the 600s checkpoint wait"
    )


def test_migration_calls_extend_before_bootstrap_wait():
    """extend_provision_lock must cover wait_for_ssh + wait_for_bootstrap too."""
    from agents.broker import migration
    src = inspect.getsource(migration.execute_migration)

    extend_idx = src.find("extend_provision_lock")
    bootstrap_idx = src.find("_wait_for_bootstrap")

    assert extend_idx != -1, "extend_provision_lock must be called in execute_migration"
    assert bootstrap_idx != -1, "_wait_for_bootstrap must exist"
    assert extend_idx < bootstrap_idx, (
        "extend_provision_lock must be called before wait_for_bootstrap; "
        "otherwise SSH+bootstrap can outlive the original lock TTL"
    )


def test_migration_calls_extend_before_docker_wait():
    """extend_provision_lock must be called before the Docker pull wait."""
    from agents.broker import migration
    src = inspect.getsource(migration.execute_migration)

    # Find the second extend call (after docker prefetch starts)
    first_extend = src.find("extend_provision_lock")
    second_extend = src.find("extend_provision_lock", first_extend + 1)
    docker_wait_idx = src.find("_wait_for_image_ready")

    assert second_extend != -1, "extend_provision_lock must be called at least twice"
    assert docker_wait_idx != -1, "_wait_for_image_ready must exist"
    assert second_extend < docker_wait_idx, (
        "The second extend_provision_lock call must appear before _wait_for_image_ready"
    )
