"""Tests for issue #150: burn and settle must verify job ownership before credit mutations."""
import pytest
from unittest.mock import patch, MagicMock
from fastapi import HTTPException


def _make_db_hit(owner_user_id: str):
    """Return a mock DB that says the job belongs to owner_user_id."""
    mock_row = MagicMock()
    mock_row.data = {"user_id": owner_user_id}
    mock_table = MagicMock()
    mock_table.select.return_value.eq.return_value.maybe_single.return_value.execute.return_value = mock_row
    mock_db = MagicMock()
    mock_db.table.return_value = mock_table
    return mock_db


def _make_db_miss():
    """Return a mock DB that returns no job row (404 scenario)."""
    mock_row = MagicMock()
    mock_row.data = None
    mock_table = MagicMock()
    mock_table.select.return_value.eq.return_value.maybe_single.return_value.execute.return_value = mock_row
    mock_db = MagicMock()
    mock_db.table.return_value = mock_table
    return mock_db


# ── _verify_job_ownership unit tests ─────────────────────────────────────────

def test_ownership_passes_for_job_owner():
    """Owner can burn/settle their own job without error."""
    from api.credits import _verify_job_ownership

    with patch("api.db.get_db", return_value=_make_db_hit("user-abc")):
        # Should not raise
        _verify_job_ownership("job-123", "user-abc")


def test_ownership_raises_403_for_wrong_user():
    """Non-owner gets 403 when trying to burn/settle another user's job."""
    from api.credits import _verify_job_ownership

    with patch("api.db.get_db", return_value=_make_db_hit("user-owner")):
        with pytest.raises(HTTPException) as exc_info:
            _verify_job_ownership("job-123", "user-attacker")
    assert exc_info.value.status_code == 403


def test_ownership_raises_404_for_unknown_job():
    """Non-existent job returns 404."""
    from api.credits import _verify_job_ownership

    with patch("api.db.get_db", return_value=_make_db_miss()):
        with pytest.raises(HTTPException) as exc_info:
            _verify_job_ownership("job-unknown", "user-abc")
    assert exc_info.value.status_code == 404


def test_ownership_raises_403_on_db_error():
    """DB error → 403 rather than leaking error details."""
    from api.credits import _verify_job_ownership

    with patch("api.db.get_db", side_effect=RuntimeError("db down")):
        with pytest.raises(HTTPException) as exc_info:
            _verify_job_ownership("job-123", "user-abc")
    assert exc_info.value.status_code == 403


# ── Source-level checks: ownership check is called in burn and settle ─────────

def test_burn_credits_calls_verify_ownership():
    """burn_credits() source includes _verify_job_ownership call."""
    import inspect
    from api import credits

    src = inspect.getsource(credits.burn_credits)
    assert "_verify_job_ownership" in src, "burn_credits must call _verify_job_ownership"


def test_settle_job_calls_verify_ownership():
    """settle_job() source includes _verify_job_ownership call."""
    import inspect
    from api import credits

    src = inspect.getsource(credits.settle_job)
    assert "_verify_job_ownership" in src, "settle_job must call _verify_job_ownership"


def test_ownership_check_before_credit_mutation_in_burn():
    """_verify_job_ownership is called before add_credit_event in burn_credits."""
    import inspect
    from api import credits

    src = inspect.getsource(credits.burn_credits)
    verify_idx = src.find("_verify_job_ownership")
    credit_idx = src.find("add_credit_event")
    assert verify_idx != -1
    assert credit_idx != -1
    assert verify_idx < credit_idx, "Ownership check must precede add_credit_event"


def test_ownership_check_before_job_update_in_settle():
    """_verify_job_ownership is called before update_job in settle_job."""
    import inspect
    from api import credits

    src = inspect.getsource(credits.settle_job)
    verify_idx = src.find("_verify_job_ownership")
    update_idx = src.find("update_job")
    assert verify_idx != -1
    assert update_idx != -1
    assert verify_idx < update_idx, "Ownership check must precede update_job"
