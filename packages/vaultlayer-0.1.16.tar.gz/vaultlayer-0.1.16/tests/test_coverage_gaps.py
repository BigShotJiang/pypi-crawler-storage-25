"""
Coverage gap tests for VaultLayer money-handling, termination, API endpoints,
and restart helpers.

Covers:
  Priority 1 — Money handling: settle_job, post_job_invoice
  Priority 2 — Termination: cancel running/completed jobs
  Priority 3 — API endpoints: logs, events, list_jobs, runtime_config, delete_dataset
  Priority 4 — Restart helpers: _find_checkpoint_in_r2
"""
import math
import os
import time
from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helper: seed an in-memory job owned by the testing user. Required by all
# job-id-scoped endpoints (status, cancel, logs, events, invoice, …) since
# the tenant-ownership fix added in commit 1 of the security audit. Without
# a matching _active_jobs entry the API responds 404 (correctly).
# ---------------------------------------------------------------------------

def _seed_owned_job(job_id: str, status: str = "running", user_id: str = "vl_test_user") -> None:
    """Insert a minimal job owned by the test user into _active_jobs."""
    import api.job_worker as jw
    jw._active_jobs[job_id] = {
        "job_id": job_id,
        "user_id": user_id,
        "status": status,
        "gpu_type": "A10G",
    }


# ---------------------------------------------------------------------------
# Autouse fixture: isolate env vars and reset global state between tests
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _isolate_env(monkeypatch):
    """Ensure test env vars AND global state don't leak between tests."""
    monkeypatch.setenv("VL_TESTING_MODE", "1")
    monkeypatch.setenv("SUPABASE_URL", os.environ.get("SUPABASE_URL", "https://fake.supabase.co"))
    monkeypatch.setenv("SUPABASE_KEY", os.environ.get("SUPABASE_KEY", "fake-key"))
    monkeypatch.setenv("SUPABASE_SERVICE_KEY", os.environ.get("SUPABASE_SERVICE_KEY", "fake-svc-key"))
    # Force TESTING_MODE=True at module level (flags are cached at import time,
    # so env var alone is not sufficient when running in full suite)
    import api.flags
    monkeypatch.setattr(api.flags, "TESTING_MODE", True)
    import api.credits
    monkeypatch.setattr(api.credits, "TESTING_MODE", True)
    import api.auth
    monkeypatch.setattr(api.auth, "TESTING_MODE", True)
    yield
    # Reset job_worker global state
    import api.job_worker as jw
    jw._broker_instance = None
    jw._active_jobs.clear()
    jw._job_queue.clear()
    jw._worker_debug.update({
        "started": False, "last_error": None, "broker_ok": False,
        "cycle_count": 0, "last_provision_attempts": [],
    })
    # Clear cached Supabase client
    try:
        from api.db import get_db
        get_db.cache_clear()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

def _fake_auth():
    """Override for require_auth — returns a mock user."""
    return {"user_id": "test-user-001", "email": "test@vaultlayer.dev"}


@pytest.fixture
def credits_client():
    """TestClient wired to the credits router (settle_job endpoint)."""
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from api.credits import router as credits_router
    from api.auth import require_auth

    app = FastAPI()
    app.dependency_overrides[require_auth] = _fake_auth
    app.include_router(credits_router)
    with patch("api.credits._verify_job_ownership"):
        yield TestClient(app)


@pytest.fixture
def jobs_client():
    """TestClient wired to jobs + admin + config + datasets routers."""
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from api.job_routes import jobs_router, config_router, datasets_router
    from api.admin_routes import admin_jobs_router, admin_gcp_router
    from api.auth import require_auth

    app = FastAPI()
    app.dependency_overrides[require_auth] = _fake_auth
    app.include_router(jobs_router)
    app.include_router(admin_jobs_router)
    app.include_router(admin_gcp_router)
    app.include_router(config_router)
    app.include_router(datasets_router)
    return TestClient(app)


# ===========================================================================
# Priority 1: Money-handling — settle_job
# ===========================================================================

class TestSettleJob:
    """Tests for POST /api/v1/jobs/{job_id}/settle (api.credits.settle_job)."""

    def test_normal_settlement(self, credits_client):
        """Credits deducted correctly for a normal job settlement."""
        resp = credits_client.post(
            "/api/v1/jobs/job-settle-001/settle",
            json={
                "job_id": "job-settle-001",
                "actual_seconds": 3600,       # 1 hour
                "hourly_rate_usd": 2.50,
                "final_status": "completed",
            },
            headers={"Authorization": "Bearer vl_test_xxx"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["job_id"] == "job-settle-001"
        # 1 hour * $2.50/hr = $2.50 => 250 credits (ceil)
        assert data["credits_charged"] == 250
        assert "available_credits" in data

    def test_settlement_with_gainshare_markup(self, credits_client):
        """When aws_equivalent_usd is provided, gainshare is calculated correctly."""
        resp = credits_client.post(
            "/api/v1/jobs/job-settle-002/settle",
            json={
                "job_id": "job-settle-002",
                "actual_seconds": 7200,       # 2 hours
                "hourly_rate_usd": 1.50,
                "final_status": "completed",
                "aws_equivalent_usd": 20.0,   # explicit AWS equiv
            },
            headers={"Authorization": "Bearer vl_test_xxx"},
        )
        assert resp.status_code == 200
        data = resp.json()
        # 2 hours * $1.50/hr = $3.00 => 300 credits
        assert data["credits_charged"] == 300

    def test_settlement_zero_duration(self, credits_client):
        """Zero duration should not overcharge (0 credits)."""
        resp = credits_client.post(
            "/api/v1/jobs/job-settle-003/settle",
            json={
                "job_id": "job-settle-003",
                "actual_seconds": 0,
                "hourly_rate_usd": 10.0,
                "final_status": "cancelled",
            },
            headers={"Authorization": "Bearer vl_test_xxx"},
        )
        assert resp.status_code == 200
        data = resp.json()
        # 0 seconds => 0 credits
        assert data["credits_charged"] == 0

    def test_settlement_insufficient_credits(self, credits_client):
        """Settlement should succeed even when user has very low credits."""
        resp = credits_client.post(
            "/api/v1/jobs/job-settle-004/settle",
            json={
                "job_id": "job-settle-004",
                "actual_seconds": 36000,       # 10 hours
                "hourly_rate_usd": 5.00,
                "final_status": "completed",
            },
            headers={"Authorization": "Bearer vl_test_xxx"},
        )
        assert resp.status_code == 200
        data = resp.json()
        # 10h * $5/hr = $50 => 5000 credits charged
        assert data["credits_charged"] == 5000
        # Should NOT crash — settle always succeeds

    def test_settlement_fractional_seconds(self, credits_client):
        """Fractional seconds should round up credits (ceil)."""
        resp = credits_client.post(
            "/api/v1/jobs/job-settle-005/settle",
            json={
                "job_id": "job-settle-005",
                "actual_seconds": 1,         # 1 second
                "hourly_rate_usd": 3.60,
                "final_status": "completed",
            },
            headers={"Authorization": "Bearer vl_test_xxx"},
        )
        assert resp.status_code == 200
        data = resp.json()
        # 1/3600 hours * $3.60/hr = $0.001 => ceil(0.1) = 1 credit
        assert data["credits_charged"] == 1

    def test_settlement_with_optional_fields(self, credits_client):
        """Settlement with all optional fields (checkpoint_count, etc.)."""
        resp = credits_client.post(
            "/api/v1/jobs/job-settle-006/settle",
            json={
                "job_id": "job-settle-006",
                "actual_seconds": 1800,
                "hourly_rate_usd": 2.00,
                "final_status": "completed",
                "final_step": 5000,
                "checkpoint_count": 10,
                "interruption_count": 2,
            },
            headers={"Authorization": "Bearer vl_test_xxx"},
        )
        assert resp.status_code == 200
        data = resp.json()
        # 0.5h * $2/hr = $1.00 => 100 credits
        assert data["credits_charged"] == 100


# ===========================================================================
# Priority 1: Money-handling — post_job_invoice
# ===========================================================================

class TestPostJobInvoice:
    """Tests for POST /api/v1/jobs/{job_id}/invoice."""

    def test_normal_invoice_generation(self, jobs_client):
        """Invoice endpoint returns ok when create_invoice succeeds."""
        with patch("api.job_routes.get_db") as mock_db:
            with patch("shared.invoice.create_invoice", return_value="inv-001"):
                resp = jobs_client.post(
                    "/api/v1/jobs/job-inv-001/invoice",
                    headers={"Authorization": "Bearer vl_test_xxx"},
                )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["invoice_id"] == "inv-001"

    def test_invoice_returns_error_when_no_invoice(self, jobs_client):
        """Invoice endpoint returns ok=False when create_invoice returns None."""
        with patch("shared.invoice.create_invoice", return_value=None):
            resp = jobs_client.post(
                "/api/v1/jobs/job-inv-002/invoice",
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is False

    def test_invoice_generation_failure_returns_500(self, jobs_client):
        """Invoice endpoint returns 500 when create_invoice raises."""
        with patch("shared.invoice.create_invoice", side_effect=RuntimeError("DB down")):
            resp = jobs_client.post(
                "/api/v1/jobs/job-inv-003/invoice",
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 500


# ===========================================================================
# Priority 2: Termination — cancel job expansions
# ===========================================================================

class TestCancelJobExpanded:
    """Extended cancel tests beyond test_server_lifecycle.py."""

    @pytest.fixture(autouse=True)
    def _setup(self):
        from api import job_routes as jr
        jr._active_jobs.clear()
        jr._job_queue.clear()
        yield
        jr._active_jobs.clear()
        jr._job_queue.clear()

    def test_cancel_running_calls_terminate_and_settle(self, jobs_client):
        """Cancel of a running job calls _terminate_and_settle with the broker."""
        from api import job_routes as jr

        # Submit a job, then manually set it to running
        r1 = jobs_client.post("/api/v1/jobs/run", json={
            "gpu_type": "H100",
        }, headers={"Authorization": "Bearer vl_test_xxx"})
        job_id = r1.json()["job_id"]
        jr._active_jobs[job_id]["status"] = "running"
        jr._active_jobs[job_id]["instance_id"] = "inst-term-001"
        jr._active_jobs[job_id]["provider"] = "runpod"

        mock_broker = MagicMock()
        mock_broker._hard_fence_runpod = AsyncMock()

        with patch("api.job_routes._init_broker", return_value=mock_broker):
            resp = jobs_client.post(
                f"/api/v1/jobs/{job_id}/cancel",
                headers={"Authorization": "Bearer vl_test_xxx"},
            )

        assert resp.status_code == 200
        assert resp.json()["status"] == "cancelled"
        # Fence should have been called exactly once. _terminate_and_settle
        # now tries a 2-arg form (for AWS/GCP/Azure) and falls back to
        # 1-arg via TypeError for providers that don't take a job. The
        # AsyncMock accepts either form — assert by await_count + first arg.
        assert mock_broker._hard_fence_runpod.await_count == 1
        assert mock_broker._hard_fence_runpod.await_args[0][0] == "inst-term-001"

    def test_cancel_already_completed_job(self, jobs_client):
        """Cancel of an already-completed job marks it cancelled (no crash)."""
        from api import job_routes as jr

        r1 = jobs_client.post("/api/v1/jobs/run", json={
            "gpu_type": "A100_40",
        }, headers={"Authorization": "Bearer vl_test_xxx"})
        job_id = r1.json()["job_id"]
        jr._active_jobs[job_id]["status"] = "completed"

        resp = jobs_client.post(
            f"/api/v1/jobs/{job_id}/cancel",
            headers={"Authorization": "Bearer vl_test_xxx"},
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "cancelled"
        assert jr._active_jobs[job_id]["status"] == "cancelled"

    def test_cancel_provisioning_job(self, jobs_client):
        """Cancel of a provisioning job triggers termination attempt."""
        from api import job_routes as jr

        r1 = jobs_client.post("/api/v1/jobs/run", json={
            "gpu_type": "H100",
        }, headers={"Authorization": "Bearer vl_test_xxx"})
        job_id = r1.json()["job_id"]
        jr._active_jobs[job_id]["status"] = "provisioning"
        jr._active_jobs[job_id]["instance_id"] = "inst-prov-001"
        jr._active_jobs[job_id]["provider"] = "vast_ai"

        mock_broker = MagicMock()
        mock_broker._hard_fence_vast_ai = AsyncMock()

        with patch("api.job_routes._init_broker", return_value=mock_broker):
            resp = jobs_client.post(
                f"/api/v1/jobs/{job_id}/cancel",
                headers={"Authorization": "Bearer vl_test_xxx"},
            )

        assert resp.status_code == 200
        assert resp.json()["status"] == "cancelled"


# ===========================================================================
# Priority 3: API endpoints — post_job_logs
# ===========================================================================

class TestPostJobLogs:
    """Tests for POST /api/v1/jobs/{job_id}/logs."""

    def test_normal_log_insertion(self, jobs_client):
        """Normal log insertion returns ok with correct count."""
        _seed_owned_job("job-log-001")
        mock_result = MagicMock()
        mock_db = MagicMock()
        mock_db.table.return_value.insert.return_value.execute.return_value = mock_result

        with patch("api.job_routes.get_db", return_value=mock_db):
            resp = jobs_client.post(
                "/api/v1/jobs/job-log-001/logs",
                json={"lines": ["epoch 1 loss=0.5", "epoch 2 loss=0.3"], "source": "training"},
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["count"] == 2

    def test_empty_lines_returns_zero(self, jobs_client):
        """Empty lines list should return ok with count=0."""
        _seed_owned_job("job-log-002")
        resp = jobs_client.post(
            "/api/v1/jobs/job-log-002/logs",
            json={"lines": [], "source": "training"},
            headers={"Authorization": "Bearer vl_test_xxx"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["count"] == 0

    def test_whitespace_only_lines_returns_zero(self, jobs_client):
        """Lines that are only whitespace are filtered out, count=0."""
        _seed_owned_job("job-log-003")
        mock_db = MagicMock()
        with patch("api.job_routes.get_db", return_value=mock_db):
            resp = jobs_client.post(
                "/api/v1/jobs/job-log-003/logs",
                json={"lines": ["   ", "\t", "\n"], "source": "training"},
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["count"] == 0

    def test_db_failure_returns_partial_failure(self, jobs_client):
        """DB failure during log insert is non-fatal — returns 200 with ok=False and count=0."""
        _seed_owned_job("job-log-004")
        with patch("api.job_routes.get_db", side_effect=Exception("DB down")):
            resp = jobs_client.post(
                "/api/v1/jobs/job-log-004/logs",
                json={"lines": ["some log line"], "source": "training"},
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is False
        assert data["count"] == 0
        assert data["total"] == 1

    def test_cross_tenant_log_post_blocked(self, jobs_client):
        """A user posting logs to another user's job_id is rejected (404 — same as missing)."""
        _seed_owned_job("job-log-other", user_id="other-user")
        resp = jobs_client.post(
            "/api/v1/jobs/job-log-other/logs",
            json={"lines": ["should not be inserted"], "source": "training"},
            headers={"Authorization": "Bearer vl_test_xxx"},
        )
        assert resp.status_code == 404


# ===========================================================================
# Priority 3: API endpoints — post_job_event
# ===========================================================================

class TestPostJobEvent:
    """Tests for POST /api/v1/jobs/{job_id}/events."""

    def test_normal_event_recording(self, jobs_client):
        """Normal event recording returns ok."""
        _seed_owned_job("job-evt-001")
        mock_db = MagicMock()
        mock_db.table.return_value.insert.return_value.execute.return_value = MagicMock()

        with patch("api.job_routes.get_db", return_value=mock_db):
            resp = jobs_client.post(
                "/api/v1/jobs/job-evt-001/events",
                json={
                    "event_type": "checkpoint_saved",
                    "message": "Saved step 1000",
                    "metadata": {"step": 1000, "size_mb": 512},
                },
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 200
        assert resp.json()["ok"] is True

    def test_event_with_empty_metadata(self, jobs_client):
        """Event with no metadata still works."""
        _seed_owned_job("job-evt-002")
        mock_db = MagicMock()
        mock_db.table.return_value.insert.return_value.execute.return_value = MagicMock()

        with patch("api.job_routes.get_db", return_value=mock_db):
            resp = jobs_client.post(
                "/api/v1/jobs/job-evt-002/events",
                json={"event_type": "migration_started", "message": "hop to RunPod"},
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 200
        assert resp.json()["ok"] is True

    def test_event_db_failure_nonfatal(self, jobs_client):
        """DB failure during event insert returns 503 so the container retries
        rather than silently discarding the terminal event (issue #218)."""
        _seed_owned_job("job-evt-003")
        with patch("api.job_routes.get_db", side_effect=Exception("DB down")):
            resp = jobs_client.post(
                "/api/v1/jobs/job-evt-003/events",
                json={"event_type": "heartbeat", "message": "still alive"},
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 503

    def test_cross_tenant_event_post_blocked(self, jobs_client):
        """A user posting events to another user's job_id is rejected (404)."""
        _seed_owned_job("job-evt-other", user_id="other-user")
        resp = jobs_client.post(
            "/api/v1/jobs/job-evt-other/events",
            json={"event_type": "checkpoint_saved", "message": "spoofed"},
            headers={"Authorization": "Bearer vl_test_xxx"},
        )
        assert resp.status_code == 404


# ===========================================================================
# Priority 3: API endpoints — list_jobs
# ===========================================================================

class TestListJobs:
    """Tests for GET /api/v1/jobs."""

    def test_returns_jobs_for_user(self, jobs_client):
        """list_jobs returns job rows from DB."""
        mock_result = MagicMock()
        mock_result.data = [
            {"job_id": "j-1", "provider": "Vast.ai", "gpu_type": "H100",
             "status": "running", "provisioned_at": None, "terminated_at": None,
             "billing_seconds": 0, "estimated_cost_usd": 0, "instance_id": "i-1",
             "run_type": "managed"},
        ]
        mock_db = MagicMock()
        mock_db.table.return_value.select.return_value.eq.return_value.order.return_value.limit.return_value.neq.return_value.execute.return_value = mock_result

        with patch("api.job_routes.get_db", return_value=mock_db):
            resp = jobs_client.get(
                "/api/v1/jobs",
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 200
        data = resp.json()
        assert "jobs" in data
        assert len(data["jobs"]) == 1
        assert data["jobs"][0]["job_id"] == "j-1"

    def test_empty_list_when_no_jobs(self, jobs_client):
        """list_jobs returns empty list when DB has no rows."""
        mock_result = MagicMock()
        mock_result.data = []
        mock_db = MagicMock()
        mock_db.table.return_value.select.return_value.eq.return_value.order.return_value.limit.return_value.neq.return_value.execute.return_value = mock_result

        with patch("api.job_routes.get_db", return_value=mock_db):
            resp = jobs_client.get(
                "/api/v1/jobs",
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 200
        assert resp.json()["jobs"] == []

    def test_db_failure_returns_empty_list(self, jobs_client):
        """list_jobs returns empty list on DB error (not crash)."""
        with patch("api.job_routes.get_db", side_effect=Exception("DB down")):
            resp = jobs_client.get(
                "/api/v1/jobs",
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 200
        assert resp.json()["jobs"] == []


# ===========================================================================
# Priority 3: API endpoints — get_runtime_config
# ===========================================================================

class TestSubmitJobPreflight:
    """Tests for the balance pre-flight check on POST /jobs/run (P2-new)."""

    def test_submit_rejected_with_zero_credits(self, jobs_client, monkeypatch):
        """402 when available_credits <= 0 (pre-flight check)."""
        import api.flags
        monkeypatch.setattr(api.flags, "TESTING_MODE", False)
        with patch("api.db.get_balance", return_value={"available_credits": 0}):
            resp = jobs_client.post(
                "/api/v1/jobs/run",
                json={"gpu_type": "A10G"},
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 402
        assert "credits" in resp.json().get("detail", "").lower()

    def test_submit_accepted_with_positive_credits(self, jobs_client, monkeypatch):
        """200 when available_credits > 0 (pre-flight passes)."""
        import api.flags
        monkeypatch.setattr(api.flags, "TESTING_MODE", False)
        # Mock reserve_credits_for_job: the atomic RPC gate (#151/#0029) now runs
        # before queue insertion. Without a real DB, we mock it to return success.
        with patch("api.db.get_balance", return_value={"available_credits": 500}), \
             patch("api.db.reserve_credits_for_job", return_value={"ok": True, "idempotent": False}):
            resp = jobs_client.post(
                "/api/v1/jobs/run",
                json={"gpu_type": "A10G"},
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 200
        assert resp.json()["status"] == "queued"

    def test_submit_fails_closed_when_balance_lookup_errors(self, jobs_client, monkeypatch):
        """503 (not 200) when the balance lookup itself fails — fail-closed."""
        import api.flags
        monkeypatch.setattr(api.flags, "TESTING_MODE", False)
        with patch("api.db.get_balance", side_effect=Exception("supabase down")):
            resp = jobs_client.post(
                "/api/v1/jobs/run",
                json={"gpu_type": "A10G"},
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 503


class TestAdminGateAccess:
    """Tests for the require_internal_admin gate.

    Admin endpoints (cleanup-instances, terminate-pods, worker/debug,
    provider-status) are gated by VL_INTERNAL_ADMIN_TOKEN. In TESTING_MODE
    the gate is bypassed so the rest of the suite still runs.
    """

    def test_admin_gate_returns_404_without_token(self, jobs_client, monkeypatch):
        """With TESTING_MODE off and no env token, admin endpoints look like 404."""
        # Disable testing-mode for this test only
        import api.auth
        monkeypatch.setattr(api.auth, "TESTING_MODE", False)
        monkeypatch.setattr(api.auth, "INTERNAL_ADMIN_TOKEN", "")

        # Without env token configured, every admin call should 503
        # ("admin disabled by operator").
        with patch("api.auth.get_user_by_token", return_value={"user_id": "u-1", "email": "u@x"}):
            resp = jobs_client.get(
                "/api/v1/jobs/worker/debug",
                headers={"Authorization": "Bearer vl_live_xxxxxxxxxxxxxxxxxxxxxxx"},
            )
        assert resp.status_code == 503

    def test_admin_gate_404_with_wrong_token(self, jobs_client, monkeypatch):
        """Wrong X-Internal-Admin-Token returns 404 (not 403, to prevent enumeration)."""
        import api.auth
        monkeypatch.setattr(api.auth, "TESTING_MODE", False)
        monkeypatch.setattr(api.auth, "INTERNAL_ADMIN_TOKEN", "correct-secret")

        resp = jobs_client.get(
            "/api/v1/jobs/worker/debug",
            headers={
                "Authorization": "Bearer vl_live_xxxxxxxxxxxxxxxxxxxxxxx",
                "X-Internal-Admin-Token": "wrong-secret",
            },
        )
        assert resp.status_code == 404

    def test_admin_gate_passes_with_correct_token(self, jobs_client, monkeypatch):
        """Correct X-Internal-Admin-Token allows access to worker/debug."""
        import api.auth
        monkeypatch.setattr(api.auth, "TESTING_MODE", False)
        monkeypatch.setattr(api.auth, "INTERNAL_ADMIN_TOKEN", "correct-secret")

        resp = jobs_client.get(
            "/api/v1/jobs/worker/debug",
            headers={"X-Internal-Admin-Token": "correct-secret"},
        )
        assert resp.status_code == 200
        # Worker debug shape — should always include these keys
        data = resp.json()
        assert "queue_size" in data
        assert "active_jobs" in data

    def test_gcp_serial_console_requires_admin_token(self, jobs_client, monkeypatch):
        """GCP serial-console endpoint is admin-gated (503 if env var unset)."""
        import api.auth
        monkeypatch.setattr(api.auth, "TESTING_MODE", False)
        monkeypatch.setattr(api.auth, "INTERNAL_ADMIN_TOKEN", "")
        resp = jobs_client.get("/api/v1/admin/gcp-serial-console/us-central1-a/vl-abc")
        assert resp.status_code == 503

    def test_gcp_serial_console_rejects_bad_zone(self, jobs_client, monkeypatch):
        """Malformed zone is rejected 400 before hitting the GCP API."""
        import api.auth
        monkeypatch.setattr(api.auth, "TESTING_MODE", False)
        monkeypatch.setattr(api.auth, "INTERNAL_ADMIN_TOKEN", "tok")
        resp = jobs_client.get(
            "/api/v1/admin/gcp-serial-console/not-a-zone/vl-abc",
            headers={"X-Internal-Admin-Token": "tok"},
        )
        assert resp.status_code == 400

    def test_gcp_serial_console_rejects_bad_instance_name(self, jobs_client, monkeypatch):
        """Instance names must match GCE naming rules (no uppercase, no dots)."""
        import api.auth
        monkeypatch.setattr(api.auth, "TESTING_MODE", False)
        monkeypatch.setattr(api.auth, "INTERNAL_ADMIN_TOKEN", "tok")
        resp = jobs_client.get(
            "/api/v1/admin/gcp-serial-console/us-central1-a/Invalid.Name",
            headers={"X-Internal-Admin-Token": "tok"},
        )
        assert resp.status_code == 400

    def test_gcp_serial_console_rejects_port_out_of_range(self, jobs_client, monkeypatch):
        """Port must be 1-4 (GCE limit)."""
        import api.auth
        monkeypatch.setattr(api.auth, "TESTING_MODE", False)
        monkeypatch.setattr(api.auth, "INTERNAL_ADMIN_TOKEN", "tok")
        resp = jobs_client.get(
            "/api/v1/admin/gcp-serial-console/us-central1-a/vl-abc?port=5",
            headers={"X-Internal-Admin-Token": "tok"},
        )
        assert resp.status_code == 422  # FastAPI's built-in range validation

    def test_gcp_serial_console_returns_503_when_gcp_unconfigured(self, jobs_client, monkeypatch):
        """If VL_GCP_* env vars aren't set, endpoint returns 503 (not 500)."""
        import api.auth
        monkeypatch.setattr(api.auth, "TESTING_MODE", False)
        monkeypatch.setattr(api.auth, "INTERNAL_ADMIN_TOKEN", "tok")
        # _read_provider_credentials is imported at module scope from
        # api.credentials — patch at the source.
        with patch("api.credentials._read_provider_credentials", return_value=None):
            resp = jobs_client.get(
                "/api/v1/admin/gcp-serial-console/us-central1-a/vl-abc",
                headers={"X-Internal-Admin-Token": "tok"},
            )
        assert resp.status_code == 503

    def test_admin_gate_reads_env_per_request(self, jobs_client, monkeypatch):
        """Token rotation via env var takes effect immediately (no restart).

        Before the fix INTERNAL_ADMIN_TOKEN was read once at module import.
        Operators changing the env var had to wait for the next process
        restart to see the new value. After the fix, each request reads
        os.environ fresh via _current_internal_admin_token().
        """
        import api.auth
        monkeypatch.setattr(api.auth, "TESTING_MODE", False)
        # Ensure the module-level shim doesn't satisfy the check — force
        # the dependency to fall through to os.environ.
        monkeypatch.setattr(api.auth, "INTERNAL_ADMIN_TOKEN", "")
        # First request: env token 'old-token'
        monkeypatch.setenv("VL_INTERNAL_ADMIN_TOKEN", "old-token")
        r1 = jobs_client.get(
            "/api/v1/jobs/worker/debug",
            headers={"X-Internal-Admin-Token": "old-token"},
        )
        assert r1.status_code == 200

        # Rotate env var — no restart, no re-import
        monkeypatch.setenv("VL_INTERNAL_ADMIN_TOKEN", "new-token")
        r2 = jobs_client.get(
            "/api/v1/jobs/worker/debug",
            headers={"X-Internal-Admin-Token": "old-token"},  # stale header
        )
        assert r2.status_code == 404, "Old token should no longer be accepted after env rotation"

        r3 = jobs_client.get(
            "/api/v1/jobs/worker/debug",
            headers={"X-Internal-Admin-Token": "new-token"},
        )
        assert r3.status_code == 200, "New env token should work immediately without restart"


class TestGetRuntimeConfig:
    """Tests for GET /api/v1/config/runtime."""

    def test_returns_runtime_config(self, jobs_client, monkeypatch):
        """Runtime config returns r2_endpoint and r2_bucket only.

        redis_url was previously included here but was removed for the
        security audit (P2-7) — it leaked the company's full pub/sub
        access to any authenticated user. The CLI no longer relies on
        the server vending Redis URLs.
        """
        monkeypatch.setenv("UPSTASH_REDIS_URL", "redis://fake-redis:6379")
        monkeypatch.setenv("R2_ENDPOINT", "https://fake-r2.example.com")
        monkeypatch.setenv("R2_BUCKET", "test-bucket")

        resp = jobs_client.get(
            "/api/v1/config/runtime",
            headers={"Authorization": "Bearer vl_test_xxx"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "redis_url" not in data
        assert data["r2_endpoint"] == "https://fake-r2.example.com"
        assert data["r2_bucket"] == "test-bucket"

    def test_returns_defaults_when_env_unset(self, jobs_client, monkeypatch):
        """Runtime config returns empty/default values when env vars are unset."""
        monkeypatch.delenv("UPSTASH_REDIS_URL", raising=False)
        monkeypatch.delenv("R2_ENDPOINT", raising=False)
        monkeypatch.delenv("VAULTLAYER_R2_ENDPOINT", raising=False)
        monkeypatch.delenv("R2_BUCKET", raising=False)
        monkeypatch.delenv("VAULTLAYER_R2_BUCKET", raising=False)

        resp = jobs_client.get(
            "/api/v1/config/runtime",
            headers={"Authorization": "Bearer vl_test_xxx"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "redis_url" not in data
        assert data["r2_bucket"] == "vaultlayer-checkpoints"  # default


# ===========================================================================
# Priority 3: API endpoints — delete_dataset
# ===========================================================================

class TestDeleteDataset:
    """Tests for DELETE /api/v1/datasets/{dataset_id}."""

    def test_soft_delete_dataset(self, jobs_client):
        """Soft-delete sets deleted_at timestamp."""
        mock_db = MagicMock()
        mock_db.table.return_value.update.return_value.eq.return_value.eq.return_value.execute.return_value = MagicMock()

        with patch("api.job_routes.get_db", return_value=mock_db):
            resp = jobs_client.delete(
                "/api/v1/datasets/ds-001",
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 200
        assert resp.json()["ok"] is True
        # Verify update was called with deleted_at
        mock_db.table.assert_called_with("datasets")
        call_args = mock_db.table.return_value.update.call_args
        assert "deleted_at" in call_args[0][0]

    def test_delete_dataset_db_failure(self, jobs_client):
        """DB failure on dataset delete raises 500."""
        with patch("api.job_routes.get_db", side_effect=Exception("DB down")):
            resp = jobs_client.delete(
                "/api/v1/datasets/ds-002",
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert resp.status_code == 500


# ===========================================================================
# Priority 4: Restart helpers — _find_checkpoint_in_r2
# ===========================================================================

class TestFindCheckpointInR2:
    """Tests for cli._remote._find_checkpoint_in_r2."""

    def test_returns_checkpoint_info_when_objects_exist(self):
        """Returns step, prefix, size_bytes when checkpoints found."""
        from cli._remote import _find_checkpoint_in_r2

        mock_s3 = MagicMock()
        # First call: list_objects_v2 with Delimiter => CommonPrefixes
        mock_s3.list_objects_v2.side_effect = [
            # First call: listing step directories
            {
                "CommonPrefixes": [
                    {"Prefix": "checkpoints/job-r2-001/step-00000100/"},
                    {"Prefix": "checkpoints/job-r2-001/step-00000500/"},
                    {"Prefix": "checkpoints/job-r2-001/step-00001000/"},
                ],
            },
            # Second call: listing objects in latest step dir
            {
                "Contents": [
                    {"Key": "checkpoints/job-r2-001/step-00001000/model.safetensors", "Size": 1024 * 1024 * 500},
                    {"Key": "checkpoints/job-r2-001/step-00001000/optimizer.pt", "Size": 1024 * 1024 * 200},
                ],
            },
        ]

        with patch("boto3.client", return_value=mock_s3):
            result = _find_checkpoint_in_r2(
                job_id="job-r2-001",
                r2_endpoint="https://r2.example.com",
                r2_key="AKID",
                r2_secret="SECRET",
                r2_bucket="test-bucket",
            )

        assert result is not None
        assert result["step"] == 1000
        assert result["prefix"] == "checkpoints/job-r2-001/step-00001000/"
        assert result["size_bytes"] == 1024 * 1024 * 700

    def test_returns_none_when_no_checkpoints(self):
        """Returns None when R2 has no checkpoint prefixes."""
        from cli._remote import _find_checkpoint_in_r2

        mock_s3 = MagicMock()
        mock_s3.list_objects_v2.return_value = {"CommonPrefixes": []}

        with patch("boto3.client", return_value=mock_s3):
            result = _find_checkpoint_in_r2(
                job_id="job-r2-002",
                r2_endpoint="https://r2.example.com",
                r2_key="AKID",
                r2_secret="SECRET",
                r2_bucket="test-bucket",
            )

        assert result is None

    def test_returns_none_when_missing_params(self):
        """Returns None when required parameters are missing."""
        from cli._remote import _find_checkpoint_in_r2

        assert _find_checkpoint_in_r2("", "ep", "k", "s", "b") is None
        assert _find_checkpoint_in_r2("job", "", "k", "s", "b") is None
        assert _find_checkpoint_in_r2("job", "ep", "", "s", "b") is None
        assert _find_checkpoint_in_r2("job", "ep", "k", "", "b") is None
        assert _find_checkpoint_in_r2("job", "ep", "k", "s", "") is None

    def test_returns_none_on_boto3_exception(self):
        """Returns None when boto3 raises (not crash)."""
        from cli._remote import _find_checkpoint_in_r2

        with patch("boto3.client", side_effect=Exception("no creds")):
            result = _find_checkpoint_in_r2(
                job_id="job-r2-003",
                r2_endpoint="https://r2.example.com",
                r2_key="AKID",
                r2_secret="SECRET",
                r2_bucket="test-bucket",
            )

        assert result is None

    def test_returns_none_when_no_step_dirs(self):
        """Returns None when prefixes exist but none match step-NNN pattern."""
        from cli._remote import _find_checkpoint_in_r2

        mock_s3 = MagicMock()
        mock_s3.list_objects_v2.return_value = {
            "CommonPrefixes": [
                {"Prefix": "checkpoints/job-r2-004/logs/"},
                {"Prefix": "checkpoints/job-r2-004/config/"},
            ],
        }

        with patch("boto3.client", return_value=mock_s3):
            result = _find_checkpoint_in_r2(
                job_id="job-r2-004",
                r2_endpoint="https://r2.example.com",
                r2_key="AKID",
                r2_secret="SECRET",
                r2_bucket="test-bucket",
            )

        assert result is None


# ===========================================================================
# Credit math unit tests
# ===========================================================================

class TestCreditMath:
    """Unit tests for credit conversion helpers in api.credits."""

    def test_usd_to_credits_rounds_up(self):
        from api.credits import _usd_to_credits
        assert _usd_to_credits(0.001) == 1   # ceil(0.1) = 1
        assert _usd_to_credits(1.00) == 100
        assert _usd_to_credits(2.50) == 250
        assert _usd_to_credits(0.0) == 0

    def test_credits_to_usd(self):
        from api.credits import _credits_to_usd
        assert _credits_to_usd(100) == 1.0
        assert _credits_to_usd(250) == 2.5
        assert _credits_to_usd(0) == 0.0

    def test_estimate_credits_includes_buffer(self):
        from api.credits import _estimate_credits
        # $2/hr * 1hr = $2.00 * 1.20 buffer = $2.40 => 240 credits
        assert _estimate_credits(2.0, 1.0) == 240
        # $0/hr => 0
        assert _estimate_credits(0.0, 10.0) == 0


# ===========================================================================
# _find_checkpoint (job_routes version — uses ckpt_step_ pattern)
# ===========================================================================

class TestFindCheckpointJobRoutes:
    """Tests for api.job_routes._find_checkpoint (R2 checkpoint lookup)."""

    def test_finds_latest_checkpoint(self):
        from api.job_worker import _find_checkpoint

        mock_s3 = MagicMock()
        mock_s3.list_objects_v2.return_value = {
            "Contents": [
                {"Key": "checkpoints/j1/ckpt_step_100.pt", "Size": 1000},
                {"Key": "checkpoints/j1/ckpt_step_500.pt", "Size": 2000},
                {"Key": "checkpoints/j1/ckpt_step_200.pt", "Size": 1500},
            ],
        }

        with patch("boto3.client", return_value=mock_s3), \
             patch.dict(os.environ, {
                 "R2_ENDPOINT": "https://r2.example.com",
                 "R2_ACCESS_KEY_ID": "K",
                 "R2_SECRET_ACCESS_KEY": "S",
                 "R2_BUCKET": "b",
             }):
            result = _find_checkpoint("j1")

        assert result is not None
        assert result["step"] == 500
        assert result["size_bytes"] == 4500  # sum of all sizes

    def test_returns_none_when_no_contents(self):
        from api.job_worker import _find_checkpoint

        mock_s3 = MagicMock()
        mock_s3.list_objects_v2.return_value = {"Contents": []}

        with patch("boto3.client", return_value=mock_s3), \
             patch.dict(os.environ, {
                 "R2_ENDPOINT": "https://r2.example.com",
                 "R2_ACCESS_KEY_ID": "K",
                 "R2_SECRET_ACCESS_KEY": "S",
                 "R2_BUCKET": "b",
             }):
            result = _find_checkpoint("j2")

        assert result is None

    def test_returns_none_when_no_r2_creds(self, monkeypatch):
        from api.job_worker import _find_checkpoint

        monkeypatch.delenv("R2_ENDPOINT", raising=False)
        monkeypatch.delenv("R2_ACCESS_KEY_ID", raising=False)
        monkeypatch.delenv("R2_SECRET_ACCESS_KEY", raising=False)

        result = _find_checkpoint("j3")
        assert result is None
