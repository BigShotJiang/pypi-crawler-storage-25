"""Regression tests for audit gaps that remained after issues #124-#154."""
from __future__ import annotations

import inspect
import os
import sys
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


def _broker_and_job(docker_image: str = "ghcr.io/hector25/vl-training-base:1.0"):
    job = SimpleNamespace(
        job_id="job-audit-123",
        name="audit",
        environment={
            "VL_SCRIPT_NAME": "train.py",
            "VL_SCRIPT_ARGS": "torchrun --nproc_per_node=2 train.py --epochs 3",
        },
        docker_image=docker_image,
        command="torchrun --nproc_per_node=2 train.py --epochs 3",
        checkpoint_step=25,
        resume_from_job_id=None,
        dataset_id="ds-audit",
        model_params_billion=None,
        training_mode="full",
        dataset_size_gb=None,
        dataset_location="",
        dataset_region="",
    )
    broker = MagicMock()
    broker.config = SimpleNamespace(
        cloudflare=SimpleNamespace(
            r2_bucket="test-bucket",
            r2_access_key_id="parent-key",
            r2_secret_access_key="parent-secret",
            r2_endpoint="https://r2.example",
        ),
        redis=SimpleNamespace(url="redis://test"),
    )
    broker._r2_minter.mint.return_value = SimpleNamespace(
        access_key_id="scoped-key",
        secret_access_key="scoped-secret",
        session_token="scoped-token",
        expires_at=9999999999,
    )
    return broker, job


def test_run_job_request_accepts_script_args_and_persists_queue_state():
    from api.job_routes import RunJobRequest, submit_job
    from api import job_worker

    assert "script_args" in RunJobRequest.model_fields
    assert "script_args" in inspect.getsource(submit_job)
    assert "script_args" in inspect.getsource(job_worker._sync_queue_state)


def test_startup_scripts_execute_preserved_script_args():
    from agents.broker.startup_scripts import build_container_onstart, build_vm_startup_script

    broker, job = _broker_and_job()
    vm_script = build_vm_startup_script(broker, job)
    container_script = build_container_onstart(broker, job)

    assert "VL_SCRIPT_ARGS" in vm_script
    assert "sh -lc \"cd /workspace && ${VL_SCRIPT_ARGS:-$_VL_INTERP /workspace/${VL_SCRIPT_NAME}}\"" in vm_script
    assert "VL_SCRIPT_ARGS" in container_script
    assert "sh -lc \"${VL_SCRIPT_ARGS:-$_VL_INTERP /workspace/${VL_SCRIPT_NAME}}\"" in container_script


def test_raw_checkpoint_resume_points_to_checkpoint_file():
    from agents.broker import ssh
    from agents.broker.startup_scripts import build_container_onstart, build_vm_startup_script

    broker, job = _broker_and_job()
    assert "step-$_VL_CKPT_STEP/checkpoint.pt" in build_vm_startup_script(broker, job)
    assert "step-$_VL_CKPT_STEP/checkpoint.pt" in build_container_onstart(broker, job)
    assert "checkpoint.pt" in inspect.getsource(ssh.restart_job_on_node)


def test_vm_docker_jobs_mount_data_root_for_dataset_paths():
    from agents.broker.startup_scripts import build_vm_startup_script

    broker, job = _broker_and_job()
    script = build_vm_startup_script(broker, job)

    assert "-v $VL_DATA_ROOT:$VL_DATA_ROOT" in script
    assert "VAULTLAYER_LOCAL_DATA" in script


def test_node_r2_credentials_refresh_and_final_sync_fail_closed():
    from agents.broker.startup_scripts import build_container_onstart, build_vm_startup_script

    broker, job = _broker_and_job()
    vm_script = build_vm_startup_script(broker, job)
    container_script = build_container_onstart(broker, job)

    assert "/api/v1/jobs/credentials" in vm_script
    assert "X-Job-Token" in vm_script
    assert "/api/v1/jobs/credentials" in container_script
    assert "X-Job-Token" in container_script
    assert "FATAL: final checkpoint sync to R2 failed" in vm_script
    assert "FATAL: final checkpoint sync to R2 failed" in container_script
    assert "rclone sync $CHECKPOINT_DIR r2:test-bucket/checkpoints/job-audit-123/ --config /tmp/vaultlayer-rclone.conf --transfers 4 --checkers 2 2>/dev/null || true" not in vm_script


def test_r2_credential_endpoint_allows_db_fallback_and_job_token():
    from api import credits

    src = inspect.getsource(credits.get_job_credentials)
    assert "X-Job-Token" in src
    assert "allow_db_fallback=True" in src
    assert "_generate_job_token" in src


def test_settle_wires_missing_spend_fallback_and_reservation_release():
    from api import job_worker

    job = {
        "job_id": "job-settle-1",
        "user_id": "user-1",
        "started_at": 1000.0,
        "completed_at": 1060.0,
        "price_per_hr": 1.0,
    }
    with patch("api.job_worker._deduct_credits") as deduct, \
         patch("api.job_worker._release_submit_reservation") as release:
        job_worker._settle_in_db(job, status="completed")

    deduct.assert_called_once_with(job)
    release.assert_called_once_with(job, "completed")


def test_recovery_queries_running_rows_without_age_cutoff_and_checks_liveness():
    from api import job_worker

    src = inspect.getsource(job_worker._job_worker)
    recovery_query = src[src.index("job_worker:recover") - 500:src.index("job_worker:recover") + 500]
    assert ".gte(" not in recovery_query
    assert "_check_alive" in src
    assert "not recovered: provider reports instance" in src


def test_migration_failure_paths_unfreeze_billing():
    from agents.broker import migration

    src = inspect.getsource(migration.execute_migration)
    for marker in ("failed_restart", "failed_no_ssh", "CHECKPOINT_READY timeout"):
        idx = src.index(marker)
        window = src[idx:idx + 1200]
        assert "_unfreeze_billing" in window
