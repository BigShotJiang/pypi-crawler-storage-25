"""Tests that billing_frozen_at is cleared on all migration failure paths."""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch, call


def _make_job(job_id="job-test-123", billing_frozen=True):
    job = MagicMock()
    job.job_id = job_id
    job.user_id = "user-test"
    job.name = "test-job"
    job.status = None
    job.billing_frozen_at = "2026-04-26T10:00:00" if billing_frozen else None
    job.provision_failure_count = 0
    job.max_provision_failures = 3
    job.current_step = 100
    job.last_provision_error = "some error"
    job.model_dump = MagicMock(return_value={})
    return job


def _make_broker():
    broker = MagicMock()
    broker.queue = MagicMock()
    broker.queue.set_job_state = AsyncMock()
    broker._active_migrations = {}
    return broker


@pytest.mark.asyncio
async def test_unfreeze_billing_clears_frozen_at():
    """_unfreeze_billing should clear billing_frozen_at and update job state."""
    from agents.broker.migration import _unfreeze_billing

    broker = _make_broker()
    job = _make_job(billing_frozen=True)

    mock_db = MagicMock()
    mock_update_chain = MagicMock()
    mock_db.table.return_value.update.return_value.eq.return_value.execute.return_value = {}

    with patch("agents.broker.migration._unfreeze_billing", wraps=_unfreeze_billing):
        with patch("api.db.get_db", return_value=mock_db), \
             patch("api.db._db_call", side_effect=lambda fn, label: fn()):
            await _unfreeze_billing(broker, job)

    assert job.billing_frozen_at is None
    broker.queue.set_job_state.assert_called_once()


@pytest.mark.asyncio
async def test_unfreeze_billing_noop_when_not_frozen():
    """_unfreeze_billing should be a no-op if billing_frozen_at is not set."""
    from agents.broker.migration import _unfreeze_billing

    broker = _make_broker()
    job = _make_job(billing_frozen=False)

    await _unfreeze_billing(broker, job)

    broker.queue.set_job_state.assert_not_called()


@pytest.mark.asyncio
async def test_unfreeze_billing_tolerates_db_error():
    """_unfreeze_billing should not raise on DB errors (non-fatal)."""
    from agents.broker.migration import _unfreeze_billing

    broker = _make_broker()
    job = _make_job(billing_frozen=True)

    with patch("api.db.get_db", side_effect=RuntimeError("db down")):
        # Should not raise
        await _unfreeze_billing(broker, job)


def test_dlq_failure_path_calls_unfreeze():
    """DLQ retry failure path calls _unfreeze_billing before returning."""
    import ast, inspect
    from agents.broker import migration

    src = inspect.getsource(migration.execute_migration)
    # Find the DLQ retry return block — it contains "dlq_at" assignment
    assert "_unfreeze_billing" in src, "_unfreeze_billing must be called in execute_migration"

    # Verify it appears before the DLQ return (dlq_at block)
    dlq_idx = src.find("job.dlq_at")
    unfreeze_after_dlq = src.find("_unfreeze_billing", dlq_idx)
    assert unfreeze_after_dlq != -1, "_unfreeze_billing must appear after DLQ path"


def test_quota_failure_path_calls_unfreeze():
    """Quota failure path calls _unfreeze_billing before returning."""
    import inspect
    from agents.broker import migration

    src = inspect.getsource(migration.execute_migration)

    quota_idx = src.find("failed_quota")
    assert quota_idx != -1

    unfreeze_after_quota = src.find("_unfreeze_billing", quota_idx)
    assert unfreeze_after_quota != -1, "_unfreeze_billing must appear after quota failure path"


def test_permanent_failed_path_calls_unfreeze():
    """Permanent FAILED path calls _unfreeze_billing before returning."""
    import inspect
    from agents.broker import migration

    src = inspect.getsource(migration.execute_migration)

    # "all retries exhausted" block marks the permanent failure
    perm_fail_idx = src.find("All retries exhausted")
    assert perm_fail_idx != -1

    unfreeze_after_perm = src.find("_unfreeze_billing", perm_fail_idx)
    assert unfreeze_after_perm != -1, "_unfreeze_billing must appear after permanent-FAILED path"


def test_ssh_failure_path_calls_unfreeze():
    """SSH failure path calls _unfreeze_billing before returning."""
    import inspect
    from agents.broker import migration

    src = inspect.getsource(migration.execute_migration)

    ssh_fail_idx = src.find("failed_ssh")
    assert ssh_fail_idx != -1

    unfreeze_after_ssh = src.find("_unfreeze_billing", ssh_fail_idx)
    assert unfreeze_after_ssh != -1, "_unfreeze_billing must appear after SSH failure path"


def test_all_unfreeze_calls_present():
    """All known failure return paths unfreeze billing before returning."""
    import inspect
    from agents.broker import migration

    src = inspect.getsource(migration.execute_migration)
    count = src.count("await _unfreeze_billing(broker, job)")
    assert count >= 7, f"Expected at least 7 _unfreeze_billing calls in execute_migration, found {count}"
