"""
Tests for #144 — Checkpoint readiness fence before DLQ retry.

When CHECKPOINT_READY times out AND the job has prior progress (current_step > 0),
execute_migration must fence the newly provisioned instance before requeueing for
DLQ retry. Without fencing the instance keeps billing while orphaned.

When current_step == 0, cold restart is safe and the timeout is logged as a warning.
"""

import inspect
import pytest


def _migration_src():
    from agents.broker import migration
    return inspect.getsource(migration)


def test_ckpt_timeout_with_prior_step_fences_instance():
    """When timeout occurs with current_step > 0, code must call _fence_old_node_by_id."""
    src = _migration_src()
    # Must check _has_prior_step
    assert "_has_prior_step" in src, "migration.py must check _has_prior_step on TimeoutError"
    # Must fence
    assert "_fence_old_node_by_id" in src, (
        "migration.py must call _fence_old_node_by_id when checkpoint timeout + prior step"
    )


def test_ckpt_timeout_with_prior_step_clears_instance_id_only_after_successful_fence():
    """After a successful fence, job.instance_id must be set to None before DLQ retry."""
    src = _migration_src()
    lines = src.splitlines()

    # Find the fence call
    fence_idx = next(
        (i for i, l in enumerate(lines) if "_fence_old_node_by_id" in l), None
    )
    assert fence_idx is not None

    # instance_id = None must be guarded by the successful-fence flag.
    flag_idx = next(
        (i for i, l in enumerate(lines) if "_fenced_checkpoint_timeout_node = True" in l),
        None,
    )
    assert flag_idx is not None, (
        "checkpoint-timeout path must track whether fencing actually succeeded"
    )
    clear_idx = next(
        (i for i, l in enumerate(lines) if i > flag_idx and "job.instance_id = None" in l),
        None,
    )
    assert clear_idx is not None, (
        "job.instance_id must be cleared to None after fencing the provisioned node"
    )


def test_ckpt_timeout_with_prior_step_sets_dlq_at():
    """After fence, job must be requeued with INTERRUPTED status and dlq_at set."""
    src = _migration_src()
    assert "job.dlq_at" in src, "migration.py must set job.dlq_at before DLQ retry"
    assert "JobStatus.INTERRUPTED" in src, (
        "migration.py must set job.status = JobStatus.INTERRUPTED before DLQ retry"
    )


def test_ckpt_timeout_no_prior_step_allows_cold_restart():
    """When current_step == 0, cold restart (warning, no fence) is the correct path."""
    src = _migration_src()
    assert "cold restart is safe" in src, (
        "migration.py must log 'cold restart is safe' for jobs with no prior checkpoint"
    )


def test_ckpt_timeout_fence_before_set_job_state():
    """Fence must happen before set_job_state() so Redis never sees the live instance_id."""
    src = _migration_src()
    lines = src.splitlines()

    fence_idx = next(
        (i for i, l in enumerate(lines) if "_fence_old_node_by_id" in l), None
    )
    persist_idx = next(
        (i for i, l in enumerate(lines)
         if i > (fence_idx or 0) and "set_job_state(" in l
         and "job.model_dump" in l),
        None,
    )
    assert fence_idx is not None, "_fence_old_node_by_id not found"
    assert persist_idx is not None, "set_job_state(job.model_dump()) not found after fence"
    assert fence_idx < persist_idx, (
        f"Fence (line {fence_idx}) must occur before set_job_state (line {persist_idx})"
    )


def test_ckpt_timeout_releases_provision_lock():
    """DLQ retry path must release the provision lock before returning."""
    src = _migration_src()
    lines = src.splitlines()

    fence_idx = next(
        (i for i, l in enumerate(lines) if "_fence_old_node_by_id" in l), None
    )
    assert fence_idx is not None

    release_idx = next(
        (i for i, l in enumerate(lines)
         if i > fence_idx and "release_provision_lock" in l),
        None,
    )
    assert release_idx is not None, (
        "release_provision_lock() must be called on the checkpoint-timeout DLQ path"
    )
