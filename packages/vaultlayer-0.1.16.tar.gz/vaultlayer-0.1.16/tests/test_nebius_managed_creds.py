"""Tests for issue #132: Nebius managed credential field mapping.

The old code mapped service_account_key → api_key, but _get_iam_token()
reads service_account_key. This caused every managed Nebius provision to
fail with 'could not obtain IAM token'. The fence path also silently skipped
termination when BYOC config was absent.
"""
from __future__ import annotations

import os
import sys
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


def _make_broker(managed_creds: dict | None = None, byoc_cfg=None):
    broker = MagicMock()
    broker._get_provider_config.return_value = byoc_cfg
    broker._nebius_token_cache = None
    if managed_creds is not None:
        broker._get_managed_credentials = AsyncMock(return_value=managed_creds)
    else:
        broker._get_managed_credentials = AsyncMock(return_value=None)
    return broker


def _make_job(job_id: str = "job-neb-1"):
    job = MagicMock()
    job.job_id = job_id
    job.last_provision_error = None
    job.failure_code = None
    job._provision_attempts = []
    return job


# ── provision: managed credentials map onto correct _get_iam_token fields ────

@pytest.mark.asyncio
async def test_managed_provision_maps_service_account_key():
    """Managed credentials must set service_account_key (not api_key) on cfg."""
    from agents.broker.providers import nebius as neb

    managed_creds = {
        "service_account_key": "-----BEGIN RSA PRIVATE KEY-----\nFAKE\n-----END RSA PRIVATE KEY-----",
        "key_id": "key-001",
        "service_account_id": "sa-001",
        "region": "eu",
        "folder_id": "folder-001",
    }
    broker = _make_broker(managed_creds=managed_creds)
    job = _make_job()

    captured_cfg = {}

    async def _fake_iam_token(b, cfg):
        captured_cfg["service_account_key"] = getattr(cfg, "service_account_key", None)
        captured_cfg["key_id"] = getattr(cfg, "key_id", None)
        captured_cfg["service_account_id"] = getattr(cfg, "service_account_id", None)
        captured_cfg["region"] = getattr(cfg, "region", None)
        # Return None to abort provision early — we only test cfg mapping
        return None

    with patch.object(neb, "_get_iam_token", new=_fake_iam_token):
        result = await neb.provision(broker, MagicMock(value="A100"), job)

    assert result is None  # aborted because token is None
    assert job.last_provision_error == "Nebius: could not obtain IAM token"
    assert captured_cfg["service_account_key"] == managed_creds["service_account_key"], \
        "service_account_key must be mapped from managed credentials"
    assert captured_cfg["key_id"] == "key-001"
    assert captured_cfg["service_account_id"] == "sa-001"
    assert captured_cfg["region"] == "eu"


@pytest.mark.asyncio
async def test_managed_provision_missing_service_account_key_is_auth_error():
    """Empty service_account_key from managed creds must produce a non-retryable
    PROV_AUTH_BAD failure, not a generic provision error."""
    from agents.broker.providers import nebius as neb
    from shared.failure_codes import JobFailureCode

    managed_creds = {
        "service_account_key": "",  # missing
        "key_id": "key-001",
        "service_account_id": "sa-001",
        "folder_id": "folder-001",
    }
    broker = _make_broker(managed_creds=managed_creds)
    job = _make_job()

    result = await neb.provision(broker, MagicMock(value="A100"), job)

    assert result is None
    assert "missing service_account_key" in (job.last_provision_error or "")
    assert job.failure_code == JobFailureCode.PROV_AUTH_BAD.value, \
        "Missing service_account_key must produce PROV_AUTH_BAD (non-retryable)"


@pytest.mark.asyncio
async def test_managed_provision_no_credentials_returns_none():
    """No managed credentials → clear error, no exception."""
    from agents.broker.providers import nebius as neb

    broker = _make_broker(managed_creds=None)
    job = _make_job()

    result = await neb.provision(broker, MagicMock(value="A100"), job)

    assert result is None
    assert "no credentials" in (job.last_provision_error or "")


# ── hard_fence: managed credentials used when BYOC config absent ──────────────

@pytest.mark.asyncio
async def test_fence_uses_managed_credentials_when_no_byoc():
    """hard_fence() must attempt managed creds when BYOC config is absent,
    so VL-managed Nebius instances can be terminated without BYOC setup."""
    from agents.broker.providers import nebius as neb

    managed_creds = {
        "service_account_key": "-----BEGIN RSA PRIVATE KEY-----\nFAKE\n-----END RSA PRIVATE KEY-----",
        "key_id": "key-001",
        "service_account_id": "sa-001",
        "region": "eu",
    }
    broker = _make_broker(managed_creds=managed_creds)
    job = _make_job()

    captured_cfg = {}

    async def _fake_iam_token(b, cfg):
        captured_cfg["service_account_key"] = getattr(cfg, "service_account_key", None)
        return "fake-token"

    delete_called = []

    class _FakeResp:
        status = 202
        async def text(self): return ""
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    class _FakeSession:
        async def delete(self, *a, **kw): return _FakeResp()
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    with patch.object(neb, "_get_iam_token", new=_fake_iam_token), \
         patch("aiohttp.ClientSession", return_value=_FakeSession()):
        await neb.hard_fence(broker, "inst-123", job=job)

    assert captured_cfg.get("service_account_key") == managed_creds["service_account_key"], \
        "Fence must use managed service_account_key when BYOC config is absent"


@pytest.mark.asyncio
async def test_fence_raises_when_no_config_and_no_managed_creds():
    """Missing BYOC and managed credentials must leave deletion unconfirmed."""
    from agents.broker.providers import nebius as neb

    broker = _make_broker(managed_creds=None)
    job = _make_job()

    with pytest.raises(RuntimeError, match="config not found"):
        await neb.hard_fence(broker, "inst-xyz", job=job)


@pytest.mark.asyncio
async def test_fence_raises_when_no_config_and_no_job():
    """Without config or job context, deletion cannot be confirmed."""
    from agents.broker.providers import nebius as neb

    broker = _make_broker(managed_creds=None)

    with pytest.raises(RuntimeError, match="config not found"):
        await neb.hard_fence(broker, "inst-xyz", job=None)
