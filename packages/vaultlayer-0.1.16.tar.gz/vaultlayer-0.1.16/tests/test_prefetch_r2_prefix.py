"""Tests for issue #141: checkpoint prefetch must use R2 prefix not local NVMe path.

Migration builds resume_ckpt as a local NVMe path. Previously it passed that
same value to _prefetch_checkpoint(), generating an invalid rclone source
like r2:<bucket>/${VL_DATA_ROOT}/vl-checkpoints/<job_id>.

The correct R2 source is checkpoints/<job_id>/ — the canonical layout used
by startup_scripts.py:317, startup_scripts.py:831, and r2.py:105.
"""
import inspect
import pytest


def _get_prefetch_call_source() -> str:
    """Extract the migration.py source around the _prefetch_checkpoint call."""
    from agents.broker import migration
    return inspect.getsource(migration)


def test_prefetch_uses_r2_prefix_not_local_path():
    """_prefetch_checkpoint must be called with the R2 prefix, not the NVMe path."""
    src = _get_prefetch_call_source()

    # The correct R2 prefix variable must appear in source
    assert "_r2_ckpt_prefix" in src, (
        "migration.py must define _r2_ckpt_prefix for the R2 checkpoint prefix"
    )
    assert 'f"checkpoints/{job.job_id}/"' in src or "checkpoints/" in src, (
        "_r2_ckpt_prefix must contain the canonical R2 layout 'checkpoints/{job_id}/'"
    )


def test_prefetch_call_uses_r2_variable():
    """The asyncio.create_task(_prefetch_checkpoint) call must pass _r2_ckpt_prefix."""
    src = _get_prefetch_call_source()

    # Find the prefetch call block
    assert "_prefetch_checkpoint" in src, "_prefetch_checkpoint must be called in migration.py"

    # The call should use _r2_ckpt_prefix, not resume_ckpt
    prefetch_idx = src.index("_prefetch_checkpoint")
    # Get surrounding context (200 chars after the function name)
    context = src[prefetch_idx:prefetch_idx + 200]
    assert "_r2_ckpt_prefix" in context, (
        "_prefetch_checkpoint must be called with _r2_ckpt_prefix, not resume_ckpt"
    )
    assert "resume_ckpt" not in context, (
        "_prefetch_checkpoint must NOT be called with resume_ckpt (that is the local NVMe path)"
    )


def test_r2_prefix_format():
    """Verify the R2 prefix format matches canonical checkpoint layout."""
    job_id = "abc12345-1234-1234-1234-abcdef012345"
    # Simulate what migration.py does
    _r2_ckpt_prefix = f"checkpoints/{job_id}/"
    assert _r2_ckpt_prefix == f"checkpoints/{job_id}/"
    # Must NOT be an NVMe-style path
    assert "/tmp" not in _r2_ckpt_prefix
    assert "VL_DATA_ROOT" not in _r2_ckpt_prefix
    assert "vl-checkpoints" not in _r2_ckpt_prefix


def test_resume_ckpt_still_used_for_local_restart():
    """resume_ckpt (local path) must still be passed to _restart_job_on_node."""
    src = _get_prefetch_call_source()
    assert "resume_ckpt" in src, "resume_ckpt local path must still exist"
    assert "_restart_job_on_node" in src, "_restart_job_on_node must still be called"

    restart_idx = src.index("_restart_job_on_node")
    context = src[restart_idx:restart_idx + 300]
    assert "resume_ckpt" in context, (
        "_restart_job_on_node must still receive resume_ckpt (local NVMe path)"
    )


def test_prefetch_ssh_command_uses_r2_remote():
    """The rclone command in prefetch_checkpoint must use r2:<bucket>/{r2_prefix}."""
    from agents.broker.ssh import prefetch_checkpoint
    src = inspect.getsource(prefetch_checkpoint)

    assert "r2:{_r2_bucket}/{resume_checkpoint}" in src or \
           "r2:" in src, "prefetch rclone command must use r2: remote"
    # Must NOT hardcode a local path pattern
    assert "VL_DATA_ROOT" not in src.split("rclone copy")[1][:100], (
        "rclone source must not be a local path (VL_DATA_ROOT)"
    )
