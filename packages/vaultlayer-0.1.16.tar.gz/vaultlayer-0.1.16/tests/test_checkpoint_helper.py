"""
VaultLayer — vaultlayer_checkpoint.py helper tests

Tests the generated checkpoint helper WITHOUT running under vaultlayer (no env vars set).
Also tests the init command writes the helper file correctly.
"""
import sys, os, importlib
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import json
import tempfile
from pathlib import Path
import pytest

# Mark torch-requiring tests so they are skipped when torch is not installed
_torch_available = importlib.util.find_spec("torch") is not None
requires_torch = pytest.mark.skipif(not _torch_available, reason="torch not installed")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _import_helper(tmp_path):
    """Write the template to a temp dir and import it fresh."""
    from cli.checkpoint_template import CHECKPOINT_HELPER_TEMPLATE
    helper_file = tmp_path / "vaultlayer_checkpoint.py"
    helper_file.write_text(CHECKPOINT_HELPER_TEMPLATE)
    import importlib.util
    spec = importlib.util.spec_from_file_location("vaultlayer_checkpoint", helper_file)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _make_mock_model():
    """Return a minimal nn.Module-like object with state_dict/load_state_dict."""
    class FakeModel:
        def state_dict(self): return {"w": [1.0, 2.0, 3.0]}
        def load_state_dict(self, state): self._loaded = state
    return FakeModel()


def _make_mock_optimizer():
    class FakeOptimizer:
        def state_dict(self): return {"lr": 3e-4, "step": 42}
        def load_state_dict(self, state): self._loaded = state
    return FakeOptimizer()


def _make_mock_scheduler():
    class FakeScheduler:
        def state_dict(self): return {"last_epoch": 5}
        def load_state_dict(self, state): self._loaded = state
    return FakeScheduler()


def _make_mock_scaler():
    class FakeScaler:
        def state_dict(self): return {"scale": 65536.0}
        def load_state_dict(self, state): self._loaded = state
    return FakeScaler()


# ── 1. Template is importable and has public API ──────────────────────────────

def test_template_exports_public_api(tmp_path):
    """Generated file must expose checkpoint, restore, heartbeat."""
    mod = _import_helper(tmp_path)
    assert callable(mod.checkpoint), "checkpoint() must be callable"
    assert callable(mod.restore),    "restore() must be callable"
    assert callable(mod.heartbeat),  "heartbeat() must be callable"


# ── 2. checkpoint() saves a .pt file ─────────────────────────────────────────

@requires_torch
def test_checkpoint_saves_pt_file(tmp_path):
    """checkpoint() must create checkpoint.pt under save_path/step-N/."""
    import torch
    mod = _import_helper(tmp_path)
    model = _make_mock_model()
    optimizer = _make_mock_optimizer()

    ckpt_path = mod.checkpoint(
        step=100,
        model=model,
        optimizer=optimizer,
        save_path=str(tmp_path / "ckpts"),
    )
    assert Path(ckpt_path).exists(), f"checkpoint.pt not found at {ckpt_path}"
    state = torch.load(ckpt_path, map_location="cpu")
    assert state["step"] == 100
    assert "model" in state
    assert "optimizer" in state


# ── 3. checkpoint() writes _MANIFEST.json LAST ───────────────────────────────

@requires_torch
def test_checkpoint_writes_manifest_after_weights(tmp_path):
    """_MANIFEST.json must exist and contain the correct step number."""
    import torch
    mod = _import_helper(tmp_path)
    mod.checkpoint(step=200, model=_make_mock_model(), save_path=str(tmp_path / "ckpts"))
    manifest_path = tmp_path / "ckpts" / "step-200" / "_MANIFEST.json"
    assert manifest_path.exists(), "_MANIFEST.json not written"
    manifest = json.loads(manifest_path.read_text())
    assert manifest["step"] == 200


# ── 4. restore() returns 0 when no checkpoint exists ─────────────────────────

def test_restore_returns_zero_when_no_checkpoint(tmp_path):
    """restore() on an empty directory must return 0 (start from scratch)."""
    mod = _import_helper(tmp_path)
    step = mod.restore(save_path=str(tmp_path / "ckpts"))
    assert step == 0, f"Expected 0 for missing checkpoint, got {step}"


# ── 5. restore() picks up the latest committed checkpoint ────────────────────

@requires_torch
def test_restore_loads_latest_checkpoint(tmp_path):
    """restore() must find and load the highest step with a _MANIFEST.json."""
    import torch
    mod = _import_helper(tmp_path)
    ckpt_dir = str(tmp_path / "ckpts")

    # Save two checkpoints
    mod.checkpoint(step=100, model=_make_mock_model(), optimizer=_make_mock_optimizer(),
                   save_path=ckpt_dir)
    mod.checkpoint(step=200, model=_make_mock_model(), optimizer=_make_mock_optimizer(),
                   save_path=ckpt_dir)

    model = _make_mock_model()
    optimizer = _make_mock_optimizer()
    step = mod.restore(ckpt_dir, model=model, optimizer=optimizer)
    assert step == 200, f"Expected latest step 200, got {step}"


# ── 6. restore() respects VAULTLAYER_RESUME_CHECKPOINT env var ───────────────

@requires_torch
def test_restore_uses_vaultlayer_resume_env(tmp_path, monkeypatch):
    """When VAULTLAYER_RESUME_CHECKPOINT is set, restore() must use that path."""
    import torch
    mod = _import_helper(tmp_path)

    # Manually create a checkpoint at step 999
    ckpt_dir = tmp_path / "managed"
    ckpt_dir.mkdir()
    state = {"step": 999, "model": {"w": [9.0]}, "optimizer": {"lr": 1e-4}}
    ckpt_file = ckpt_dir / "checkpoint.pt"
    torch.save(state, ckpt_file)

    # Patch env var on the module (module-level constant)
    monkeypatch.setattr(mod, "_RESUME_CHECKPOINT", str(ckpt_file))
    step = mod.restore(str(tmp_path / "empty"), model=_make_mock_model())
    assert step == 999, f"Expected step 999 from env var path, got {step}"


# ── 7. restore() skips directories without _MANIFEST.json ───────────────────

@requires_torch
def test_restore_ignores_partial_checkpoints(tmp_path):
    """Checkpoint dirs without _MANIFEST.json (partial writes) must be skipped."""
    import torch
    ckpt_dir = tmp_path / "ckpts"

    # Create a partial checkpoint (no _MANIFEST.json)
    partial = ckpt_dir / "step-500"
    partial.mkdir(parents=True)
    torch.save({"step": 500}, partial / "checkpoint.pt")
    # NO _MANIFEST.json written

    # Create a valid checkpoint at step 100
    mod = _import_helper(tmp_path)
    mod.checkpoint(step=100, model=_make_mock_model(), save_path=str(ckpt_dir))

    step = mod.restore(str(ckpt_dir))
    assert step == 100, f"Must skip partial step-500, return step 100, got {step}"


# ── 8. checkpoint() handles DDP-wrapped models (unwraps .module) ─────────────

@requires_torch
def test_checkpoint_unwraps_ddp_model(tmp_path):
    """DDP models expose .module — checkpoint() must call .module.state_dict()."""
    import torch
    mod = _import_helper(tmp_path)

    class DDPModel:
        """Mimics torch.nn.parallel.DistributedDataParallel."""
        class module:
            @staticmethod
            def state_dict(): return {"weight": [1.0]}
            @staticmethod
            def load_state_dict(s): pass

    ddp_model = DDPModel()
    ckpt_path = mod.checkpoint(step=50, model=ddp_model, save_path=str(tmp_path / "ckpts"))
    state = torch.load(ckpt_path, map_location="cpu")
    assert "model" in state, "DDP model state_dict not saved"
    assert state["model"] == {"weight": [1.0]}


# ── 9. checkpoint() saves all optional states ─────────────────────────────────

@requires_torch
def test_checkpoint_saves_all_states(tmp_path):
    """checkpoint() must save model, optimizer, lr_scheduler, scaler, and extras."""
    import torch
    mod = _import_helper(tmp_path)
    ckpt_path = mod.checkpoint(
        step=300,
        model=_make_mock_model(),
        optimizer=_make_mock_optimizer(),
        lr_scheduler=_make_mock_scheduler(),
        scaler=_make_mock_scaler(),
        save_path=str(tmp_path / "ckpts"),
        loss=0.42,
        extra={"epoch": 3, "custom_key": "hello"},
    )
    state = torch.load(ckpt_path, map_location="cpu")
    assert "model"        in state
    assert "optimizer"    in state
    assert "lr_scheduler" in state
    assert "scaler"       in state
    assert state["loss"]  == pytest.approx(0.42)
    assert state["epoch"] == 3
    assert state["custom_key"] == "hello"


# ── 10. restore() loads all optional states back ─────────────────────────────

@requires_torch
def test_restore_loads_all_states(tmp_path):
    """restore() must call load_state_dict on model, optimizer, scheduler, scaler."""
    import torch
    mod = _import_helper(tmp_path)
    ckpt_dir = str(tmp_path / "ckpts")

    mod.checkpoint(
        step=400,
        model=_make_mock_model(),
        optimizer=_make_mock_optimizer(),
        lr_scheduler=_make_mock_scheduler(),
        scaler=_make_mock_scaler(),
        save_path=ckpt_dir,
    )

    model     = _make_mock_model()
    optimizer = _make_mock_optimizer()
    scheduler = _make_mock_scheduler()
    scaler    = _make_mock_scaler()

    step = mod.restore(ckpt_dir, model=model, optimizer=optimizer,
                       lr_scheduler=scheduler, scaler=scaler)
    assert step == 400
    assert hasattr(model,     "_loaded"), "model.load_state_dict not called"
    assert hasattr(optimizer,  "_loaded"), "optimizer.load_state_dict not called"
    assert hasattr(scheduler, "_loaded"), "lr_scheduler.load_state_dict not called"
    assert hasattr(scaler,    "_loaded"), "scaler.load_state_dict not called"


# ── 11. heartbeat() is rate-limited ──────────────────────────────────────────

def test_heartbeat_is_rate_limited(tmp_path, monkeypatch):
    """
    _send_heartbeat() must only make a network call once per HEARTBEAT_INTERVAL_SECS.
    Patch only the network layer (urllib.request.urlopen) so the rate-limit guard runs.
    """
    import urllib.request
    mod = _import_helper(tmp_path)
    monkeypatch.setattr(mod, "_JOB_ID", "test-job-id")
    mod._last_heartbeat_ts = float("-inf")  # reset so first call fires (0.0 fails: monotonic() ~0.3s < 30s interval)

    network_calls = []
    monkeypatch.setattr(urllib.request, "urlopen",
                        lambda req, timeout=None: network_calls.append(req))

    mod._send_heartbeat(step=1)  # should fire network call (ts=0 -> elapsed=inf)
    mod._send_heartbeat(step=2)  # should be rate-limited (ts just set)
    mod._send_heartbeat(step=3)  # should be rate-limited

    assert len(network_calls) == 1, \
        f"Network called {len(network_calls)} times; expected 1 (rate-limited)"


# ── 12. vaultlayer init writes the helper file ────────────────────────────────

def test_init_command_writes_helper_file(tmp_path, monkeypatch):
    """vaultlayer init must write vaultlayer_checkpoint.py to --output-dir."""
    from click.testing import CliRunner
    from unittest.mock import patch, MagicMock
    from cli.main import init

    # Mock the HTTP token validation so we don't hit the real API
    mock_resp = MagicMock()
    mock_resp.json.return_value = {"valid": True, "email": "test@example.com", "balance_credits": 1000}
    mock_resp.raise_for_status = MagicMock()

    runner = CliRunner()
    with patch("httpx.post", return_value=mock_resp):
        result = runner.invoke(init, [
            "--token",      "vl_test_abc123",
            "--output-dir", str(tmp_path),
        ])

    assert result.exit_code == 0, f"init failed: {result.output}"
    helper = tmp_path / "vaultlayer_checkpoint.py"
    assert helper.exists(), "vaultlayer_checkpoint.py was not written"
    content = helper.read_text()
    assert "def checkpoint(" in content
    assert "def restore(" in content
    assert "def heartbeat(" in content
    assert "_MANIFEST.json" in content, "Atomic commit marker must be present"


# ── 13. Generated helper has no vaultlayer package dependency ─────────────────

def test_helper_has_no_vaultlayer_import(tmp_path):
    """Generated vaultlayer_checkpoint.py must not import from the vaultlayer package."""
    from cli.checkpoint_template import CHECKPOINT_HELPER_TEMPLATE
    lines = CHECKPOINT_HELPER_TEMPLATE.splitlines()
    import_lines = [l for l in lines if l.strip().startswith(("import ", "from "))
                    and "vaultlayer" in l.lower() and "vaultlayer_checkpoint" not in l.lower()]
    assert import_lines == [], \
        f"Helper imports vaultlayer package (must be standalone):\n" + "\n".join(import_lines)


# ── 14. RNG state collection and restoration ──────────────────────────────────

@requires_torch
def test_collect_rng_state_returns_torch_key():
    """_collect_rng_state must always include 'torch' key when torch is available."""
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    import importlib.util, pathlib
    spec = importlib.util.spec_from_file_location(
        "vaultlayer_checkpoint_root",
        str(pathlib.Path(__file__).parent.parent / "vaultlayer_checkpoint.py"),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    rng = mod._collect_rng_state()
    assert "torch" in rng, "torch RNG state must always be present"
    assert "python" in rng, "Python random state must always be present"


@requires_torch
def test_rng_state_round_trips_through_checkpoint(tmp_path):
    """Saving a checkpoint must include RNG state; _load must restore it."""
    import sys, os, random, importlib.util, pathlib
    import torch

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    spec = importlib.util.spec_from_file_location(
        "vaultlayer_checkpoint_rng",
        str(pathlib.Path(__file__).parent.parent / "vaultlayer_checkpoint.py"),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    model = torch.nn.Linear(4, 4)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)

    # Advance RNG past some draws, record what the NEXT draw would be, then checkpoint
    torch.manual_seed(42)
    torch.rand(7)               # advance state past the initial seed position
    expected = torch.rand(1).item()   # this is the "next" value at checkpoint time
    # Reset to the position just before `expected` was drawn so checkpoint captures that state
    torch.manual_seed(42)
    torch.rand(7)               # re-advance to the same position

    save_dir = str(tmp_path)
    mod.checkpoint(step=1, model=model, optimizer=optimizer, save_path=save_dir)

    # Scramble RNG to simulate a different node / process restart
    torch.manual_seed(999)
    torch.rand(20)

    # Restore — RNG must snap back to the state captured at checkpoint time
    start = mod.restore(save_dir, model=model, optimizer=optimizer)
    assert start == 1

    # First draw after restore must match what we captured as `expected`
    actual_after_restore = torch.rand(1).item()
    assert abs(actual_after_restore - expected) < 1e-5, (
        f"RNG not restored: expected {expected:.6f}, got {actual_after_restore:.6f}"
    )


@requires_torch
def test_checkpoint_rng_state_survives_async_save(tmp_path):
    """RNG state must be included in checkpoints saved with async_save=True."""
    import sys, os, importlib.util, pathlib
    import torch

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    spec = importlib.util.spec_from_file_location(
        "vaultlayer_checkpoint_async_rng",
        str(pathlib.Path(__file__).parent.parent / "vaultlayer_checkpoint.py"),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    model = torch.nn.Linear(2, 2)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)

    mod.checkpoint(step=10, model=model, optimizer=optimizer,
                   save_path=str(tmp_path), async_save=True)

    # Join the async thread
    if mod._ASYNC_THREAD[0] is not None:
        mod._ASYNC_THREAD[0].join()

    ckpt_file = tmp_path / "step-10" / "checkpoint.pt"
    assert ckpt_file.exists()
    state = torch.load(ckpt_file, map_location="cpu")
    assert "rng" in state, "async checkpoint must contain RNG state"
    assert "torch" in state["rng"]


# ── R2 upload rate-limiting (cost guardrail) ─────────────────────────────────

def test_r2_notify_rate_limited(tmp_path, monkeypatch):
    """_notify_checkpoint() must gate R2 uploads within the interval window.

    Cloudflare R2 charges $0.36/M Class A ops.  Frequent checkpoint() calls
    (every step) must NOT generate proportional R2 writes.

    Strategy: verify the timestamp gate directly — first call should update
    _last_r2_upload_ts, rapid subsequent calls should leave it unchanged
    (proving they were suppressed before reaching the HTTP layer).
    """
    import sys, os, importlib.util, pathlib, time

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    spec = importlib.util.spec_from_file_location(
        "vaultlayer_checkpoint_ratelimit",
        str(pathlib.Path(__file__).parent.parent / "vaultlayer_checkpoint.py"),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    # Activate the module (simulate running under vaultlayer run)
    monkeypatch.setattr(mod, "_JOB_ID", "test-job-rate-limit")
    # Set a 60-second R2 interval
    monkeypatch.setattr(mod, "_R2_UPLOAD_INTERVAL_SECS", 60)
    # Force last-upload to -inf (never uploaded) so first call fires.
    # Using float('-inf') rather than 0.0 because time.monotonic() in a
    # fresh test process is only ~0.3s — subtracting 0.0 gives elapsed=0.3s
    # which is < the 60s interval and would cause a spurious gate trigger.
    mod._last_r2_upload_ts = float("-inf")

    # First call: should pass the gate and update _last_r2_upload_ts to now
    t_before = time.monotonic()
    mod._notify_checkpoint(step=0, path="/mnt/nvme/vl-checkpoints/step-0")
    t_after = time.monotonic()
    ts_after_first = mod._last_r2_upload_ts

    assert ts_after_first >= t_before, (
        "First call must update _last_r2_upload_ts (gate should have passed)"
    )

    # Subsequent calls in rapid succession: must NOT update _last_r2_upload_ts
    for i in range(1, 5):
        mod._notify_checkpoint(step=i, path=f"/mnt/nvme/vl-checkpoints/step-{i}")

    ts_after_rapid = mod._last_r2_upload_ts
    assert ts_after_rapid == ts_after_first, (
        f"Rapid subsequent calls must NOT update _last_r2_upload_ts. "
        f"Expected {ts_after_first:.3f}, got {ts_after_rapid:.3f}. "
        "Rate-limiting is broken — excess R2 Class A ops would be generated."
    )


def test_r2_notify_emergency_bypasses_ratelimit(tmp_path, monkeypatch):
    """emergency=True must bypass the rate-limit gate (spot-kill path)."""
    import sys, os, importlib.util, pathlib

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    spec = importlib.util.spec_from_file_location(
        "vaultlayer_checkpoint_emergency",
        str(pathlib.Path(__file__).parent.parent / "vaultlayer_checkpoint.py"),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    monkeypatch.setattr(mod, "_JOB_ID", "test-job-emergency")
    monkeypatch.setattr(mod, "_R2_UPLOAD_INTERVAL_SECS", 3600)  # 1 hour window
    monkeypatch.setattr(mod, "_last_r2_upload_ts", 9999999.0)   # pretend recent upload

    notified_count = [0]

    def fake_urlopen(req, timeout=None):
        notified_count[0] += 1
        class FakeResp:
            def read(self): return b""
        return FakeResp()

    import urllib.request
    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)

    # Emergency=True must fire even though _last_r2_upload_ts is very recent
    mod._notify_checkpoint(step=999, path="/mnt/nvme/vl-checkpoints/step-999",
                           emergency=True)

    assert notified_count[0] == 1, (
        "emergency=True must bypass the rate-limit gate for spot-kill uploads"
    )


def test_nvme_checkpoint_dir_uses_vl_data_root(tmp_path, monkeypatch):
    """CHECKPOINT_DIR must resolve to $VL_DATA_ROOT/vl-checkpoints on GPU nodes."""
    import sys, os, importlib.util, pathlib

    monkeypatch.setenv("VL_DATA_ROOT", str(tmp_path / "nvme"))
    spec = importlib.util.spec_from_file_location(
        "vaultlayer_checkpoint_nvme",
        str(pathlib.Path(__file__).parent.parent / "vaultlayer_checkpoint.py"),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    expected = str(tmp_path / "nvme" / "vl-checkpoints")
    assert mod.CHECKPOINT_DIR == expected, (
        f"CHECKPOINT_DIR should be {expected}, got {mod.CHECKPOINT_DIR}"
    )


# ── Async checkpoint metadata fix (issue #134) ───────────────────────────────

@requires_torch
def test_async_checkpoint_step_in_manifest(tmp_path):
    """Async checkpoints must write step to _MANIFEST.json (was always null).

    restore() reads int(state.get("step", 0)) — previously this was 0 for
    async saves because step was never injected into the state dict.
    """
    import sys, importlib.util, pathlib, json
    import torch

    spec = importlib.util.spec_from_file_location(
        "vaultlayer_checkpoint_async_step",
        str(pathlib.Path(__file__).parent.parent / "vaultlayer_checkpoint.py"),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    mod._notify_checkpoint = lambda *a, **kw: None

    model = torch.nn.Linear(2, 2)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)

    mod.checkpoint(step=42, model=model, optimizer=optimizer,
                   save_path=str(tmp_path), async_save=True, loss=0.5)

    if mod._ASYNC_THREAD[0] is not None:
        mod._ASYNC_THREAD[0].join()

    manifest_path = tmp_path / "step-42" / "_MANIFEST.json"
    assert manifest_path.exists(), "_MANIFEST.json must be written by async save"
    manifest = json.loads(manifest_path.read_text())
    assert manifest["step"] == 42, f"manifest.step must be 42, got {manifest.get('step')}"

    ckpt_file = tmp_path / "step-42" / "checkpoint.pt"
    state = torch.load(ckpt_file, map_location="cpu")
    assert state.get("step") == 42, f"state[step] must be 42, got {state.get('step')}"


@requires_torch
def test_async_checkpoint_calls_notify_after_save(tmp_path):
    """_notify_checkpoint must be called after the background thread commits.

    Previously async saves never called _notify_checkpoint so R2 upload
    notifications were never triggered.
    """
    import sys, importlib.util, pathlib
    import torch

    spec = importlib.util.spec_from_file_location(
        "vaultlayer_checkpoint_async_notify",
        str(pathlib.Path(__file__).parent.parent / "vaultlayer_checkpoint.py"),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    notified = []
    mod._notify_checkpoint = lambda step, path, emergency=False: notified.append((step, path))

    model = torch.nn.Linear(2, 2)

    mod.checkpoint(step=7, model=model, save_path=str(tmp_path), async_save=True)

    if mod._ASYNC_THREAD[0] is not None:
        mod._ASYNC_THREAD[0].join()

    assert len(notified) == 1, f"_notify_checkpoint must be called once; got {notified}"
    assert notified[0][0] == 7, "notify must be called with correct step"
