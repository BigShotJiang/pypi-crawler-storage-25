"""
VaultLayer — GCS→R2 and Azure→R2 mirror tests

Tests for:
  - GCS / Azure URI parsing
  - Egress cost estimation (both providers)
  - mirror_cloud_data dispatcher routes to the right function
  - _sync_from_gcs streams blobs to R2 (mocked google-cloud-storage)
  - _sync_from_azure streams blobs to R2 (mocked azure-storage-blob)
  - Manifest written to R2 after mirror
  - Abort on user decline
  - _dataset.py: gs:// and az:// URIs set VAULTLAYER_DATASET_ID
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import json
import pytest
from unittest.mock import MagicMock, AsyncMock, patch


# ── URI parsers ───────────────────────────────────────────────────────────────

def test_parse_gcs_uri_bucket_only():
    from cli.sync import _parse_gcs_uri
    bucket, prefix = _parse_gcs_uri("gs://my-bucket")
    assert bucket == "my-bucket"
    assert prefix == ""


def test_parse_gcs_uri_with_prefix():
    from cli.sync import _parse_gcs_uri
    bucket, prefix = _parse_gcs_uri("gs://my-bucket/data/train")
    assert bucket == "my-bucket"
    assert prefix == "data/train"


def test_parse_azure_uri_container_only():
    from cli.sync import _parse_azure_uri
    container, prefix = _parse_azure_uri("az://my-container")
    assert container == "my-container"
    assert prefix == ""


def test_parse_azure_uri_with_prefix():
    from cli.sync import _parse_azure_uri
    container, prefix = _parse_azure_uri("az://my-container/raw/2024")
    assert container == "my-container"
    assert prefix == "raw/2024"


# ── Egress cost estimators ────────────────────────────────────────────────────

def test_gcs_egress_cost_within_free_tier():
    from cli.sync import _estimate_gcs_egress_cost
    assert _estimate_gcs_egress_cost(0.5) == 0.0   # 0.5 GB < 1 GB free


def test_gcs_egress_cost_above_free_tier():
    from cli.sync import _estimate_gcs_egress_cost
    cost = _estimate_gcs_egress_cost(11.0)          # 10 billable GB @ $0.10
    assert abs(cost - 1.00) < 0.001


def test_azure_egress_cost_within_free_tier():
    from cli.sync import _estimate_azure_egress_cost
    assert _estimate_azure_egress_cost(3.0) == 0.0  # 3 GB < 5 GB free


def test_azure_egress_cost_above_free_tier():
    from cli.sync import _estimate_azure_egress_cost
    cost = _estimate_azure_egress_cost(15.0)        # 10 billable GB @ $0.085
    assert abs(cost - 0.85) < 0.001


# ── mirror_cloud_data dispatcher ──────────────────────────────────────────────

@pytest.mark.asyncio
async def test_mirror_cloud_data_routes_s3():
    from cli._dataset import mirror_cloud_data
    with patch("cli._dataset.mirror_s3_data", new_callable=AsyncMock, return_value="ds-id") as m:
        result = await mirror_cloud_data("s3://bucket/prefix", yes=True)
    m.assert_called_once_with("s3://bucket/prefix", yes=True, config=None)
    assert result == "ds-id"


@pytest.mark.asyncio
async def test_mirror_cloud_data_routes_gcs():
    from cli._dataset import mirror_cloud_data
    with patch("cli._dataset._mirror_gcs_data", new_callable=AsyncMock, return_value="gcs-ds") as m:
        result = await mirror_cloud_data("gs://bucket/data", yes=True)
    m.assert_called_once_with("gs://bucket/data", yes=True, config=None)
    assert result == "gcs-ds"


@pytest.mark.asyncio
async def test_mirror_cloud_data_routes_azure():
    from cli._dataset import mirror_cloud_data
    with patch("cli._dataset._mirror_azure_data", new_callable=AsyncMock, return_value="az-ds") as m:
        result = await mirror_cloud_data("az://container/data", yes=True)
    m.assert_called_once_with("az://container/data", yes=True, config=None)
    assert result == "az-ds"


@pytest.mark.asyncio
async def test_mirror_cloud_data_unknown_scheme_returns_none():
    from cli._dataset import mirror_cloud_data
    result = await mirror_cloud_data("ftp://somewhere/data")
    assert result is None


# ── dataset_id derivation ─────────────────────────────────────────────────────

def test_derive_dataset_id_gcs():
    from cli._dataset import _derive_dataset_id
    assert _derive_dataset_id("gs://my-bucket/train") == "my-bucket-train"


def test_derive_dataset_id_azure():
    from cli._dataset import _derive_dataset_id
    assert _derive_dataset_id("az://container/raw/2024") == "container-raw-2024"


def test_derive_dataset_id_capped_at_64():
    from cli._dataset import _derive_dataset_id
    long_uri = "gs://" + "a" * 100
    assert len(_derive_dataset_id(long_uri)) <= 64


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_mock_config():
    cfg = MagicMock()
    cfg.cloudflare.r2_endpoint          = "https://r2.example.com"
    cfg.cloudflare.r2_access_key_id     = "key"
    cfg.cloudflare.r2_secret_access_key = "secret"
    cfg.cloudflare.r2_bucket            = "vl-bucket"
    cfg.storage = MagicMock()
    cfg.storage.gcs_credentials_json    = ""
    cfg.storage.azure_connection_string = ""
    cfg.storage.azure_account_name      = ""
    cfg.storage.azure_account_key       = ""
    return cfg


def _make_gcs_blob(name: str, size: int, content: bytes = b"data"):
    blob = MagicMock()
    blob.name = name
    blob.size = size
    blob.download_as_bytes.return_value = content
    return blob


def _make_azure_blob_props(name: str, size: int):
    """Azure BlobProperties is subscriptable like a dict."""
    d = {"name": name, "size": size}
    props = MagicMock()
    # MagicMock magic methods must be set via .side_effect, not direct assignment,
    # because Python looks up __getitem__ on the *type*, not the instance.
    props.__getitem__.side_effect = d.__getitem__
    props.name = name
    return props


def _gcs_sys_modules_patch(mock_gcs_client):
    """
    Return a patch.dict context that injects a fake google.cloud.storage module.
    Used because google-cloud-storage may not be installed in the test environment.
    """
    mock_gcs_module = MagicMock()
    mock_gcs_module.Client.return_value = mock_gcs_client
    mock_gcs_module.Client.from_service_account_json.return_value = mock_gcs_client
    return patch.dict("sys.modules", {"google.cloud.storage": mock_gcs_module})


# ── _sync_from_gcs: blob streaming to R2 ─────────────────────────────────────

@pytest.mark.asyncio
async def test_sync_from_gcs_streams_blobs_to_r2():
    """All GCS blobs must be PUT to R2 under datasets/{dataset_id}/."""
    from cli.sync import _sync_from_gcs

    blobs  = [_make_gcs_blob("train/file1.bin", 1000),
              _make_gcs_blob("train/file2.bin", 2000)]
    config = _make_mock_config()

    mock_gcs_client = MagicMock()
    mock_gcs_client.list_blobs.return_value = blobs
    mock_r2_boto    = MagicMock()

    with _gcs_sys_modules_patch(mock_gcs_client), \
         patch("boto3.client", return_value=mock_r2_boto), \
         patch("shared.storage_billing.get_current_storage_rate", return_value=0.02), \
         patch("cli.sync._register_dataset"):
        await _sync_from_gcs(
            gcs_uri="gs://my-bucket/train",
            dataset_id="my-dataset",
            name="My Dataset",
            config=config,
            r2=MagicMock(),
            yes=True,
        )

    # Data blobs go through upload_fileobj (issue #137); only manifest uses put_object
    assert mock_r2_boto.upload_fileobj.call_count == 2, (
        f"Expected 2 upload_fileobj calls, got {mock_r2_boto.upload_fileobj.call_count}"
    )
    assert mock_r2_boto.put_object.call_count >= 1, "manifest.json must use put_object"


@pytest.mark.asyncio
async def test_sync_from_gcs_writes_manifest():
    """A gcs_mirror_manifest.json must be written to R2 after mirroring."""
    from cli.sync import _sync_from_gcs

    blobs      = [_make_gcs_blob("data/file.bin", 500)]
    config     = _make_mock_config()
    put_calls  = []

    mock_gcs_client = MagicMock()
    mock_gcs_client.list_blobs.return_value = blobs
    mock_r2_boto    = MagicMock()
    mock_r2_boto.put_object.side_effect = lambda **kw: put_calls.append(kw)

    with _gcs_sys_modules_patch(mock_gcs_client), \
         patch("boto3.client", return_value=mock_r2_boto), \
         patch("shared.storage_billing.get_current_storage_rate", return_value=0.02), \
         patch("cli.sync._register_dataset"):
        await _sync_from_gcs("gs://my-bucket/data", "ds1", None, config, MagicMock(), True)

    # Issue #135: must write canonical manifest.json, not gcs_mirror_manifest.json
    manifest_calls = [c for c in put_calls if c.get("Key", "").endswith("manifest.json")]
    assert manifest_calls, "canonical manifest.json must be written to R2"
    assert not any("gcs_mirror_manifest" in c.get("Key", "") for c in put_calls), (
        "Provider-specific manifest name must not be used"
    )
    manifest = json.loads(manifest_calls[0]["Body"])
    assert manifest["dataset_id"] == "ds1"
    assert "source_uri" in manifest


@pytest.mark.asyncio
async def test_sync_from_gcs_aborts_on_decline():
    """User declining the confirmation prompt must abort without any R2 writes."""
    from cli.sync import _sync_from_gcs

    blobs  = [_make_gcs_blob("train/x.bin", 50_000_000_000)]  # 50 GB — costly
    config = _make_mock_config()

    mock_gcs_client = MagicMock()
    mock_gcs_client.list_blobs.return_value = blobs
    mock_r2_boto    = MagicMock()

    with _gcs_sys_modules_patch(mock_gcs_client), \
         patch("boto3.client", return_value=mock_r2_boto), \
         patch("click.confirm", return_value=False):
        await _sync_from_gcs("gs://my-bucket/train", "ds2", None, config, MagicMock(), False)

    mock_r2_boto.put_object.assert_not_called()


@pytest.mark.asyncio
async def test_sync_from_gcs_registers_dataset():
    """_register_dataset must be called with source_type='gcs_mirror'."""
    from cli.sync import _sync_from_gcs

    blobs  = [_make_gcs_blob("a.bin", 100)]
    config = _make_mock_config()

    mock_gcs_client = MagicMock()
    mock_gcs_client.list_blobs.return_value = blobs

    with _gcs_sys_modules_patch(mock_gcs_client), \
         patch("boto3.client", return_value=MagicMock()), \
         patch("shared.storage_billing.get_current_storage_rate", return_value=0.02), \
         patch("cli.sync._register_dataset") as mock_reg:
        await _sync_from_gcs("gs://b/p", "dsX", "My DS", config, MagicMock(), True)

    mock_reg.assert_called_once()
    kwargs = mock_reg.call_args[1]
    assert kwargs["source_type"] == "gcs_mirror"
    assert kwargs["dataset_id"]  == "dsX"


# ── _sync_from_azure: blob streaming to R2 ───────────────────────────────────

def _make_azure_mock(blob_props_list):
    """Build a complete Azure mock stack: service → container → blob clients."""
    mock_blob_data   = MagicMock()
    mock_blob_data.readall.return_value = b"blob-content"
    mock_blob_client = MagicMock()
    mock_blob_client.download_blob.return_value = mock_blob_data

    mock_container = MagicMock()
    mock_container.list_blobs.return_value = blob_props_list
    mock_container.get_blob_client.return_value = mock_blob_client

    mock_az_service = MagicMock()
    mock_az_service.get_container_client.return_value = mock_container

    mock_az_module = MagicMock()
    mock_az_module.BlobServiceClient.from_connection_string.return_value = mock_az_service

    return mock_az_module, mock_az_service, mock_container, mock_blob_client


@pytest.mark.asyncio
async def test_sync_from_azure_streams_blobs_to_r2():
    """All Azure blobs must be PUT to R2 under datasets/{dataset_id}/."""
    from cli.sync import _sync_from_azure

    blob_props = [_make_azure_blob_props("raw/a.bin", 1000),
                  _make_azure_blob_props("raw/b.bin", 2000)]
    config = _make_mock_config()
    config.storage.azure_connection_string = "DefaultEndpointsProtocol=https;..."

    mock_az_module, *_ = _make_azure_mock(blob_props)
    mock_r2_boto = MagicMock()

    with patch.dict("sys.modules", {"azure.storage.blob": mock_az_module,
                                    "azure.storage": MagicMock(),
                                    "azure": MagicMock()}), \
         patch("boto3.client", return_value=mock_r2_boto), \
         patch("shared.storage_billing.get_current_storage_rate", return_value=0.02), \
         patch("cli.sync._register_dataset"):
        await _sync_from_azure("az://my-container/raw", "az-ds", None, config, MagicMock(), True)

    # Data blobs go through upload_fileobj (issue #137); only manifest uses put_object
    assert mock_r2_boto.upload_fileobj.call_count == 2, (
        f"Expected 2 upload_fileobj calls, got {mock_r2_boto.upload_fileobj.call_count}"
    )
    assert mock_r2_boto.put_object.call_count >= 1, "manifest.json must use put_object"


@pytest.mark.asyncio
async def test_sync_from_azure_writes_manifest():
    """Canonical manifest.json must be written to R2 after Azure mirroring (issue #135)."""
    from cli.sync import _sync_from_azure

    blob_props = [_make_azure_blob_props("data/x.bin", 100)]
    config     = _make_mock_config()
    config.storage.azure_connection_string = "DefaultEndpointsProtocol=https;..."
    put_calls  = []

    mock_az_module, *_ = _make_azure_mock(blob_props)
    mock_r2_boto = MagicMock()
    mock_r2_boto.put_object.side_effect = lambda **kw: put_calls.append(kw)

    with patch.dict("sys.modules", {"azure.storage.blob": mock_az_module,
                                    "azure.storage": MagicMock(),
                                    "azure": MagicMock()}), \
         patch("boto3.client", return_value=mock_r2_boto), \
         patch("shared.storage_billing.get_current_storage_rate", return_value=0.02), \
         patch("cli.sync._register_dataset"):
        await _sync_from_azure("az://my-container/data", "az-ds2", None, config, MagicMock(), True)

    # Issue #135: must write canonical manifest.json, not azure_mirror_manifest.json
    manifest_calls = [c for c in put_calls if c.get("Key", "").endswith("manifest.json")]
    assert manifest_calls, "canonical manifest.json must be written to R2"
    assert not any("azure_mirror_manifest" in c.get("Key", "") for c in put_calls), (
        "Provider-specific manifest name must not be used"
    )
    manifest = json.loads(manifest_calls[0]["Body"])
    assert manifest["dataset_id"] == "az-ds2"
    assert "source_uri" in manifest


@pytest.mark.asyncio
async def test_sync_from_azure_aborts_on_decline():
    """User declining confirmation must abort without any R2 writes."""
    from cli.sync import _sync_from_azure

    blob_props = [_make_azure_blob_props("data/huge.bin", 100_000_000_000)]
    config     = _make_mock_config()
    config.storage.azure_connection_string = "DefaultEndpointsProtocol=https;..."

    mock_az_module, *_ = _make_azure_mock(blob_props)
    mock_r2_boto = MagicMock()

    with patch.dict("sys.modules", {"azure.storage.blob": mock_az_module,
                                    "azure.storage": MagicMock(),
                                    "azure": MagicMock()}), \
         patch("boto3.client", return_value=mock_r2_boto), \
         patch("click.confirm", return_value=False):
        await _sync_from_azure("az://my-container/data", "az-ds3", None, config, MagicMock(), False)

    mock_r2_boto.put_object.assert_not_called()


@pytest.mark.asyncio
async def test_sync_from_azure_registers_dataset():
    """_register_dataset must be called with source_type='azure_mirror'."""
    from cli.sync import _sync_from_azure

    blob_props = [_make_azure_blob_props("a.bin", 50)]
    config     = _make_mock_config()
    config.storage.azure_connection_string = "DefaultEndpointsProtocol=https;..."

    mock_az_module, *_ = _make_azure_mock(blob_props)

    with patch.dict("sys.modules", {"azure.storage.blob": mock_az_module,
                                    "azure.storage": MagicMock(),
                                    "azure": MagicMock()}), \
         patch("boto3.client", return_value=MagicMock()), \
         patch("shared.storage_billing.get_current_storage_rate", return_value=0.02), \
         patch("cli.sync._register_dataset") as mock_reg:
        await _sync_from_azure("az://container/p", "azX", "My DS", config, MagicMock(), True)

    mock_reg.assert_called_once()
    kwargs = mock_reg.call_args[1]
    assert kwargs["source_type"] == "azure_mirror"
    assert kwargs["dataset_id"]  == "azX"


# ── Streaming (not buffering) enforcement ─────────────────────────────────────

def test_gcs_mirror_does_not_use_bytesio_buffer():
    """GCS mirror must use blob.open('rb') for streaming, not BytesIO + download_to_file."""
    import inspect
    from cli.sync import _sync_from_gcs
    src = inspect.getsource(_sync_from_gcs)
    assert "blob.open" in src, (
        "_sync_from_gcs must use blob.open('rb') for streaming (not BytesIO + download_to_file)"
    )
    assert "download_to_file" not in src, (
        "_sync_from_gcs must not use download_to_file (downloads entire blob into BytesIO)"
    )


def test_azure_mirror_does_not_use_bytesio_buffer():
    """Azure mirror must pass download_blob() directly to upload_fileobj, not BytesIO + readinto."""
    import inspect
    from cli.sync import _sync_from_azure
    src = inspect.getsource(_sync_from_azure)
    assert "readinto" not in src, (
        "_sync_from_azure must not use readinto(buf) — that buffers the full object in memory"
    )
    # download_blob() should be passed directly to upload_fileobj
    assert "download_blob()" in src, "download_blob() must be called"


# ── RunCommand._handle_dataset routes gs:// and az:// ────────────────────────

@pytest.mark.asyncio
async def test_handle_dataset_routes_gcs_uri():
    """--data gs://... must call mirror_cloud_data and set VAULTLAYER_DATASET_ID."""
    from cli.run import RunCommand
    import os

    runner = RunCommand(["python", "train.py"], "test-job", data_uri="gs://bucket/train")
    runner.yes = True

    with patch("cli._dataset.mirror_cloud_data", new_callable=AsyncMock, return_value="gcs-ds") as m:
        await runner._handle_dataset()
        assert os.environ.get("VAULTLAYER_DATASET_ID") == "gcs-ds"

    m.assert_called_once_with("gs://bucket/train", yes=True)


@pytest.mark.asyncio
async def test_handle_dataset_routes_azure_uri():
    """--data az://... must call mirror_cloud_data and set VAULTLAYER_DATASET_ID."""
    from cli.run import RunCommand
    import os

    runner = RunCommand(["python", "train.py"], "test-job", data_uri="az://container/raw")
    runner.yes = True

    with patch("cli._dataset.mirror_cloud_data", new_callable=AsyncMock, return_value="az-ds") as m:
        await runner._handle_dataset()
        assert os.environ.get("VAULTLAYER_DATASET_ID") == "az-ds"

    m.assert_called_once_with("az://container/raw", yes=True)
