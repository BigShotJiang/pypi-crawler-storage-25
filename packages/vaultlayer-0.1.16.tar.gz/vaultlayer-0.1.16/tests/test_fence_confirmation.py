"""Tests for issue #130 — provider hard_fence() must raise on failure.

Before this fix every provider's hard_fence() caught all exceptions and
non-2xx HTTP responses with logger.warning(...) and returned None normally.
_terminate_and_settle() in job_worker.py relies on an exception being raised
to set fence_success=False (and hence termination_confirmed=False in DB).
When providers swallowed errors the DB always claimed termination_confirmed=True
even when the cloud instance was never actually deleted — causing billing leaks.

These tests verify that:
  1. A non-2xx HTTP response raises (caller sets fence_success=False)
  2. A 404 response is treated as already-deleted (no raise — idempotent delete)
  3. A network exception propagates (no swallowing)
  4. A successful 2xx response does NOT raise (fence_success stays True)
"""
from __future__ import annotations

import asyncio
import os
import sys
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


def _run(coro):
    return asyncio.run(coro)


def _make_broker(provider="coreweave"):
    broker = MagicMock()
    broker._get_provider_config = MagicMock(return_value=SimpleNamespace(
        api_key="test-key",
        base_url="https://test.example.com",
        namespace="test-ns",
        api_secret="dGVzdA==",
        project_id="proj-123",
    ))
    broker._nebius_token_cache = None
    return broker


def _fake_resp(status: int, body: str = "error"):
    """Build a mock aiohttp response for `resp = await session.delete(...)`."""
    resp = MagicMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    return resp


def _mock_session(resp):
    """Patch aiohttp.ClientSession so `await s.delete(...)` returns resp."""
    mock_sess_cm = MagicMock()
    session = MagicMock()
    session.delete = AsyncMock(return_value=resp)
    session.get = AsyncMock(return_value=resp)
    mock_sess_cm.__aenter__ = AsyncMock(return_value=session)
    mock_sess_cm.__aexit__ = AsyncMock(return_value=False)
    mock_sess_cm.return_value = mock_sess_cm
    return mock_sess_cm


# ── CoreWeave ────────────────────────────────────────────────────────────────

class TestCoreWeaveFence:
    def test_non_2xx_raises(self):
        from agents.broker.providers import coreweave
        broker = _make_broker()
        with patch("aiohttp.ClientSession", _mock_session(_fake_resp(500))):
            with pytest.raises((RuntimeError, Exception)):
                _run(coreweave.hard_fence(broker, "vs-abc"))

    def test_404_no_raise(self):
        from agents.broker.providers import coreweave
        broker = _make_broker()
        with patch("aiohttp.ClientSession", _mock_session(_fake_resp(404))):
            _run(coreweave.hard_fence(broker, "vs-abc"))

    def test_success_no_raise(self):
        from agents.broker.providers import coreweave
        broker = _make_broker()
        with patch("aiohttp.ClientSession", _mock_session(_fake_resp(204))):
            _run(coreweave.hard_fence(broker, "vs-abc"))

    def test_network_error_propagates(self):
        from agents.broker.providers import coreweave
        broker = _make_broker()
        mock_sess_cm = MagicMock()
        session = MagicMock()
        session.delete = AsyncMock(side_effect=Exception("connection refused"))
        mock_sess_cm.__aenter__ = AsyncMock(return_value=session)
        mock_sess_cm.__aexit__ = AsyncMock(return_value=False)
        mock_sess_cm.return_value = mock_sess_cm
        with patch("aiohttp.ClientSession", mock_sess_cm):
            with pytest.raises(Exception, match="connection refused"):
                _run(coreweave.hard_fence(broker, "vs-abc"))


# ── Voltage Park ─────────────────────────────────────────────────────────────

class TestVoltageParkFence:
    def test_non_2xx_raises(self):
        from agents.broker.providers import voltage_park
        broker = _make_broker()
        with patch("aiohttp.ClientSession", _mock_session(_fake_resp(403))):
            with pytest.raises((RuntimeError, Exception)):
                _run(voltage_park.hard_fence(broker, "vm-123"))

    def test_404_no_raise(self):
        from agents.broker.providers import voltage_park
        broker = _make_broker()
        with patch("aiohttp.ClientSession", _mock_session(_fake_resp(404))):
            _run(voltage_park.hard_fence(broker, "vm-123"))

    def test_success_no_raise(self):
        from agents.broker.providers import voltage_park
        broker = _make_broker()
        with patch("aiohttp.ClientSession", _mock_session(_fake_resp(202))):
            _run(voltage_park.hard_fence(broker, "vm-123"))


# ── Crusoe ───────────────────────────────────────────────────────────────────

class TestCrusoeFence:
    def test_non_2xx_raises(self):
        from agents.broker.providers import crusoe
        broker = _make_broker()
        with patch("aiohttp.ClientSession", _mock_session(_fake_resp(500))):
            with pytest.raises((RuntimeError, Exception)):
                _run(crusoe.hard_fence(broker, "inst-abc"))

    def test_404_no_raise(self):
        from agents.broker.providers import crusoe
        broker = _make_broker()
        with patch("aiohttp.ClientSession", _mock_session(_fake_resp(404))):
            _run(crusoe.hard_fence(broker, "inst-abc"))

    def test_success_no_raise(self):
        from agents.broker.providers import crusoe
        broker = _make_broker()
        with patch("aiohttp.ClientSession", _mock_session(_fake_resp(200))):
            _run(crusoe.hard_fence(broker, "inst-abc"))


# ── Hyperstack ───────────────────────────────────────────────────────────────

class TestHyperstackFence:
    def test_non_2xx_raises(self):
        from agents.broker.providers import hyperstack
        broker = _make_broker()
        with patch("aiohttp.ClientSession", _mock_session(_fake_resp(422))):
            with pytest.raises((RuntimeError, Exception)):
                _run(hyperstack.hard_fence(broker, "12345"))

    def test_404_no_raise(self):
        from agents.broker.providers import hyperstack
        broker = _make_broker()
        with patch("aiohttp.ClientSession", _mock_session(_fake_resp(404))):
            _run(hyperstack.hard_fence(broker, "12345"))

    def test_success_no_raise(self):
        from agents.broker.providers import hyperstack
        broker = _make_broker()
        with patch("aiohttp.ClientSession", _mock_session(_fake_resp(200))):
            _run(hyperstack.hard_fence(broker, "12345"))

    def test_network_error_propagates(self):
        from agents.broker.providers import hyperstack
        broker = _make_broker()
        mock_sess_cm = MagicMock()
        session = MagicMock()
        session.delete = AsyncMock(side_effect=Exception("timeout"))
        mock_sess_cm.__aenter__ = AsyncMock(return_value=session)
        mock_sess_cm.__aexit__ = AsyncMock(return_value=False)
        mock_sess_cm.return_value = mock_sess_cm
        with patch("aiohttp.ClientSession", mock_sess_cm):
            with pytest.raises(Exception, match="timeout"):
                _run(hyperstack.hard_fence(broker, "12345"))


# ── Nebius ───────────────────────────────────────────────────────────────────

class TestNebiusFence:
    def test_missing_config_raises(self):
        """Missing BYOC/managed config must not be treated as confirmed deletion."""
        from agents.broker.providers import nebius
        broker = _make_broker()
        broker._get_provider_config = MagicMock(return_value=None)
        broker._get_managed_credentials = AsyncMock(return_value=None)

        with pytest.raises(RuntimeError, match="config not found"):
            _run(nebius.hard_fence(broker, "inst-xyz", job=SimpleNamespace(job_id="job-1")))

    def test_non_2xx_raises(self):
        from agents.broker.providers import nebius
        broker = _make_broker()
        from types import SimpleNamespace as _NS
        broker._get_provider_config = MagicMock(return_value=_NS(
            service_account_key="sk", key_id="kid",
            service_account_id="said", region="eu",
            base_url="https://compute.api.eu.nebius.cloud/compute/v1",
        ))
        with patch.object(nebius, "_get_iam_token", new=AsyncMock(return_value="tok")):
            with patch("aiohttp.ClientSession", _mock_session(_fake_resp(500))):
                with pytest.raises((RuntimeError, Exception)):
                    _run(nebius.hard_fence(broker, "inst-xyz"))

    def test_404_no_raise(self):
        from agents.broker.providers import nebius
        broker = _make_broker()
        from types import SimpleNamespace as _NS
        broker._get_provider_config = MagicMock(return_value=_NS(
            service_account_key="sk", key_id="kid",
            service_account_id="said", region="eu",
            base_url="https://compute.api.eu.nebius.cloud/compute/v1",
        ))
        with patch.object(nebius, "_get_iam_token", new=AsyncMock(return_value="tok")):
            with patch("aiohttp.ClientSession", _mock_session(_fake_resp(404))):
                _run(nebius.hard_fence(broker, "inst-xyz"))

    def test_iam_token_failure_raises(self):
        """No IAM token must now raise instead of silently returning."""
        from agents.broker.providers import nebius
        broker = _make_broker()
        from types import SimpleNamespace as _NS
        broker._get_provider_config = MagicMock(return_value=_NS(
            service_account_key="sk", key_id="kid",
            service_account_id="said", region="eu",
            base_url="https://compute.api.eu.nebius.cloud/compute/v1",
        ))
        with patch.object(nebius, "_get_iam_token", new=AsyncMock(return_value=None)):
            with pytest.raises(RuntimeError, match="IAM token"):
                _run(nebius.hard_fence(broker, "inst-xyz"))


# ── GCP ──────────────────────────────────────────────────────────────────────

class TestGCPFence:
    def test_no_creds_raises(self):
        """No credentials means deletion is unconfirmed, not successful."""
        from agents.broker.providers import gcp

        broker = MagicMock()
        broker._gcp_sa_info = {}
        broker.config.gcp = None

        with patch("api.credentials._read_provider_credentials", return_value=None):
            with pytest.raises(RuntimeError, match="no credentials available"):
                _run(gcp.hard_fence(broker, "vl-abc12345-a10g", job=None))

    def test_delete_op_confirmed_returns_normally(self):
        """When delete op completes DONE with no error, hard_fence returns without raising."""
        from agents.broker.providers import gcp

        broker = MagicMock()
        broker._gcp_sa_info = {
            "vl-abc12345-a10g": {
                "sa_info": {
                    "type": "service_account",
                    "project_id": "proj",
                    "private_key": "k",
                    "client_email": "sa@proj.iam.gserviceaccount.com",
                    "token_uri": "https://oauth2.googleapis.com/token",
                },
                "project_id": "proj",
                "zone": "us-central1-a",
            }
        }

        mock_delete_op = {"name": "op-123", "status": "RUNNING"}
        mock_done_op = {"name": "op-123", "status": "DONE"}

        mock_instances = MagicMock()
        mock_instances.delete = MagicMock(return_value=MagicMock(execute=MagicMock(return_value=mock_delete_op)))
        mock_zone_ops = MagicMock()
        mock_zone_ops.get = MagicMock(return_value=MagicMock(execute=MagicMock(return_value=mock_done_op)))
        mock_compute = MagicMock()
        mock_compute.instances = MagicMock(return_value=mock_instances)
        mock_compute.zoneOperations = MagicMock(return_value=mock_zone_ops)

        with patch("google.oauth2.service_account.Credentials.from_service_account_info", return_value=MagicMock()), \
             patch("googleapiclient.discovery.build", return_value=mock_compute):
            _run(gcp.hard_fence(broker, "vl-abc12345-a10g", job=None))

    def test_poll_error_raises(self):
        """If zoneOperations.get raises during poll loop, RuntimeError propagates."""
        from agents.broker.providers import gcp

        broker = MagicMock()
        broker._gcp_sa_info = {
            "vl-abc12345-a10g": {
                "sa_info": {
                    "type": "service_account",
                    "project_id": "proj",
                    "private_key": "k",
                    "client_email": "sa@proj.iam.gserviceaccount.com",
                    "token_uri": "https://oauth2.googleapis.com/token",
                },
                "project_id": "proj",
                "zone": "us-central1-a",
            }
        }

        mock_delete_op = {"name": "op-123", "status": "RUNNING"}
        mock_instances = MagicMock()
        mock_instances.delete = MagicMock(return_value=MagicMock(execute=MagicMock(return_value=mock_delete_op)))
        mock_zone_ops = MagicMock()
        # zoneOperations.get().execute() raises
        mock_zone_ops.get = MagicMock(return_value=MagicMock(execute=MagicMock(side_effect=Exception("api error"))))
        mock_compute = MagicMock()
        mock_compute.instances = MagicMock(return_value=mock_instances)
        mock_compute.zoneOperations = MagicMock(return_value=mock_zone_ops)

        with patch("google.oauth2.service_account.Credentials.from_service_account_info", return_value=MagicMock()), \
             patch("googleapiclient.discovery.build", return_value=mock_compute):
            with pytest.raises((RuntimeError, Exception)):
                _run(gcp.hard_fence(broker, "vl-abc12345-a10g", job=None))
