"""
VaultLayer — High/Medium/Low severity gap fix tests (batch 2).
Covers: GAP-1, GAP-4, GAP-5, GAP-6, GAP-8b, GAP-9, GAP-10, GAP-11,
        GAP-13, GAP-15, GAP-16, GAP-17, GAP-19, GAP-20, GAP-21, GAP-22,
        GAP-24, GAP-25, GAP-26, GAP-28, GAP-29, GAP-31
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import asyncio
import json
import time
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch, call
from typing import Optional

import pytest
from conftest import MockAgentQueue, make_job, dummy_config


# ── Helpers ──────────────────────────────────────────────────────────────────

def _make_config():
    from shared.config import (VaultLayerConfig, AWSConfig, LambdaLabsConfig,
                               CoreWeaveConfig, CloudflareConfig, RedisConfig, AnthropicConfig)
    return VaultLayerConfig(
        token="vl_test_" + "a" * 64,
        user_id="test-user",
        aws=AWSConfig(access_key_id="k", secret_access_key="s"),
        lambda_labs=LambdaLabsConfig(api_key="lk"),
        coreweave=CoreWeaveConfig(api_key="ck", namespace="ns"),
        cloudflare=CloudflareConfig(
            account_id="acct",
            r2_access_key_id="rk",
            r2_secret_access_key="rs",
            r2_bucket="test-bucket",
            r2_endpoint="https://test.r2.cloudflarestorage.com",
        ),
        redis=RedisConfig(url="redis://localhost:6379"),
        anthropic=AnthropicConfig(api_key="ak"),
    )


# ═══════════════════════════════════════════════════════════════════════════
# GAP-31: Event schema versioning
# ═══════════════════════════════════════════════════════════════════════════

def test_agent_event_has_schema_version():
    """AgentEvent must include schema_version field defaulting to 1."""
    from shared.models import AgentEvent, EventType
    event = AgentEvent(
        event_type=EventType.HEARTBEAT_MISS,
        source_agent="test",
    )
    assert event.schema_version == 1


def test_agent_accepts_current_schema_version():
    """OrchestrationAgent must accept events with schema_version == SUPPORTED_SCHEMA_VERSION."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import AgentEvent, EventType
    config = _make_config()
    queue = MockAgentQueue()
    agent = OrchestrationAgent(config, queue)

    event = AgentEvent(
        schema_version=1,
        event_type=EventType.NODE_HEALTHY,
        source_agent="test",
    )
    assert agent._check_schema_version(event) is True


def test_agent_rejects_events_with_higher_schema_version():
    """OrchestrationAgent must reject events with schema_version > SUPPORTED_SCHEMA_VERSION."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import AgentEvent, EventType
    config = _make_config()
    queue = MockAgentQueue()
    agent = OrchestrationAgent(config, queue)

    event = AgentEvent(
        schema_version=99,
        event_type=EventType.NODE_HEALTHY,
        source_agent="future_cli",
    )
    assert agent._check_schema_version(event) is False


@pytest.mark.asyncio
async def test_handle_event_drops_future_schema_version():
    """handle_event must return early and not process events with unknown schema version."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import AgentEvent, EventType
    config = _make_config()
    queue = MockAgentQueue()
    agent = OrchestrationAgent(config, queue)

    event = AgentEvent(
        schema_version=999,
        event_type=EventType.TERMINATION_SIGNAL,
        source_agent="attacker",
        job_id="job-x",
    )
    # Should not raise; should silently drop
    await agent.handle_event(event)
    # No escalation or migration should have been published
    assert len(queue.published) == 0


# ═══════════════════════════════════════════════════════════════════════════
# GAP-28: Rapid failure detection
# ═══════════════════════════════════════════════════════════════════════════

def test_single_crash_not_rapid_failure():
    """One crash should NOT trigger rapid failure."""
    from agents.orchestration.agent import OrchestrationAgent
    config = _make_config()
    queue = MockAgentQueue()
    agent = OrchestrationAgent(config, queue)

    agent._record_crash("job-1")
    assert not agent._is_rapid_failure("job-1")


def test_three_crashes_trigger_rapid_failure():
    """Three crashes within the window should trigger rapid failure."""
    from agents.orchestration.agent import OrchestrationAgent
    config = _make_config()
    queue = MockAgentQueue()
    agent = OrchestrationAgent(config, queue)

    for _ in range(3):
        agent._record_crash("job-1")
    assert agent._is_rapid_failure("job-1")


def test_crash_history_window_expires():
    """Crashes older than RAPID_FAILURE_WINDOW_SECS should be ignored."""
    from agents.orchestration.agent import OrchestrationAgent
    config = _make_config()
    queue = MockAgentQueue()
    agent = OrchestrationAgent(config, queue)

    old_time = time.time() - agent.RAPID_FAILURE_WINDOW_SECS - 60
    agent._job_crash_history["job-1"] = [old_time, old_time, old_time]
    # Old crashes should not count
    assert not agent._is_rapid_failure("job-1")


@pytest.mark.asyncio
async def test_rapid_failure_detection_escalates_instead_of_migrating():
    """After THRESHOLD crashes, orchestration must escalate instead of migrate."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import AgentEvent, EventType
    config = _make_config()
    queue = MockAgentQueue()
    agent = OrchestrationAgent(config, queue)
    agent.register_job(make_job())

    # Pre-load crash history to threshold - 1
    job_id = "test-001"
    for _ in range(agent.RAPID_FAILURE_THRESHOLD - 1):
        agent._record_crash(job_id)

    # This event causes the Nth crash, triggering escalation
    event = AgentEvent(
        event_type=EventType.TERMINATION_SIGNAL,
        source_agent="watchdog",
        job_id=job_id,
        payload={},
    )
    decision = await agent._route_event(event)
    # Should escalate
    assert decision is not None
    assert decision.action == "escalate"
    # Escalation event published
    escalate_events = [e for (ch, e) in queue.published if ch == "escalate"]
    assert len(escalate_events) > 0


@pytest.mark.asyncio
async def test_single_crash_still_migrates():
    """Single crash (no rapid failure) should still trigger migration."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import AgentEvent, EventType
    config = _make_config()
    queue = MockAgentQueue()
    agent = OrchestrationAgent(config, queue)
    agent.register_job(make_job())

    event = AgentEvent(
        event_type=EventType.TERMINATION_SIGNAL,
        source_agent="watchdog",
        job_id="test-001",
        payload={},
    )
    decision = await agent._route_event(event)
    assert decision is not None
    assert decision.action == "migrate"


# ═══════════════════════════════════════════════════════════════════════════
# GAP-6: STONITH — fencing old node before provisioning
# ═══════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_execute_migration_fences_old_node_before_provisioning():
    """For arbitrage events, _fence_old_node must be called before provision_*."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    config = _make_config()
    queue = MockAgentQueue()
    agent = BrokerAgent(config=config, queue=queue)
    job = make_job()
    job.ssh_host = "10.0.0.1"
    await queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    call_order = []

    async def mock_fence(j):
        call_order.append("fence")

    async def mock_provision(*a, **kw):
        call_order.append("provision")
        return "i-new-001"

    async def _quota_ok(*a, **kw): return True
    async def _ssh_ok(*a, **kw): return True
    async def _restart_ok(*a, **kw): return True
    async def _prefetch_noop(*a, **kw): pass
    async def _sleep_noop(*a, **kw): pass

    created_tasks: list = []
    _orig_create_task = asyncio.create_task

    def _capture_task(coro, **kw):
        t = _orig_create_task(coro)
        created_tasks.append(t)
        return t

    with patch.object(agent, '_fence_old_node', side_effect=mock_fence), \
         patch.object(agent, 'provision_lambda', side_effect=mock_provision), \
         patch.object(agent, '_check_quota', side_effect=_quota_ok), \
         patch.object(agent, '_wait_for_ssh', side_effect=_ssh_ok), \
         patch.object(agent, '_restart_job_on_node', side_effect=_restart_ok), \
         patch.object(agent, '_prefetch_checkpoint', side_effect=_prefetch_noop), \
         patch.object(agent, '_try_same_provider_different_az', new_callable=AsyncMock, return_value=None), \
         patch('asyncio.sleep', side_effect=_sleep_noop), \
         patch('asyncio.create_task', side_effect=_capture_task):
        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM,
            decision_id="dec-123", event_type="arbitrage_opportunity"
        )

    # Drain any tasks created_task was called with so no coroutine is left unawaited
    if created_tasks:
        await asyncio.gather(*created_tasks, return_exceptions=True)

    assert "fence" in call_order
    assert call_order.index("fence") < call_order.index("provision")


@pytest.mark.asyncio
async def test_termination_signal_does_not_fence():
    """For spot termination events, _fence_old_node must NOT be called."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    config = _make_config()
    queue = MockAgentQueue()
    agent = BrokerAgent(config=config, queue=queue)
    job = make_job()
    job.ssh_host = "10.0.0.1"
    await queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    fence_called = []

    async def mock_fence(j):
        fence_called.append(True)

    async def _provision_ok(*a, **kw): return "i-new-002"
    async def _quota_ok(*a, **kw): return True
    async def _ssh_ok(*a, **kw): return True
    async def _restart_ok(*a, **kw): return True
    async def _prefetch_noop(*a, **kw): pass
    async def _sleep_noop(*a, **kw): pass

    created_tasks: list = []
    _orig_create_task = asyncio.create_task

    def _capture_task(coro, **kw):
        t = _orig_create_task(coro)
        created_tasks.append(t)
        return t

    with patch.object(agent, '_fence_old_node', side_effect=mock_fence), \
         patch.object(agent, 'provision_lambda', side_effect=_provision_ok), \
         patch.object(agent, '_check_quota', side_effect=_quota_ok), \
         patch.object(agent, '_wait_for_ssh', side_effect=_ssh_ok), \
         patch.object(agent, '_restart_job_on_node', side_effect=_restart_ok), \
         patch.object(agent, '_prefetch_checkpoint', side_effect=_prefetch_noop), \
         patch.object(agent, '_try_same_provider_different_az', new_callable=AsyncMock, return_value=None), \
         patch('asyncio.sleep', side_effect=_sleep_noop), \
         patch('asyncio.create_task', side_effect=_capture_task):
        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM,
            decision_id="dec-456", event_type="termination_signal"
        )

    # Drain any tasks so no coroutine is left unawaited
    if created_tasks:
        await asyncio.gather(*created_tasks, return_exceptions=True)

    assert len(fence_called) == 0, "_fence_old_node must not be called for spot termination"


# ═══════════════════════════════════════════════════════════════════════════
# GAP-22: Storage cleanup after migration
# ═══════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_cleanup_old_instance_called_after_migration_complete():
    """_cleanup_old_instance must be scheduled after MIGRATION_COMPLETE."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    config = _make_config()
    queue = MockAgentQueue()
    agent = BrokerAgent(config=config, queue=queue)
    job = make_job()
    await queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    cleanup_calls = []

    async def mock_cleanup(old_id, old_prov, j):
        cleanup_calls.append(old_id)

    async def _fence_noop(*a, **kw): pass
    async def _provision_ok(*a, **kw): return "i-new-003"
    async def _quota_ok(*a, **kw): return True
    async def _ssh_ok(*a, **kw): return True
    async def _restart_ok(*a, **kw): return True
    async def _prefetch_noop(*a, **kw): pass
    async def _sleep_noop(*a, **kw): pass

    scheduled_coros: list = []
    task_call_count = [0]

    def _capture_coro(coro, **kw):
        task_call_count[0] += 1
        scheduled_coros.append(coro)
        return MagicMock()

    async def _resolve_host_ok(*a, **kw): return "test-node.example.com"
    async def _bootstrap_ok(*a, **kw): return True
    async def _probe_ok(*a, **kw): return (True, "530.30")

    with patch.object(agent, '_cleanup_old_instance', side_effect=mock_cleanup), \
         patch.object(agent, '_fence_old_node', side_effect=_fence_noop), \
         patch.object(agent, 'provision_lambda', side_effect=_provision_ok), \
         patch.object(agent, '_check_quota', side_effect=_quota_ok), \
         patch.object(agent, '_resolve_instance_host', side_effect=_resolve_host_ok), \
         patch.object(agent, '_wait_for_ssh', side_effect=_ssh_ok), \
         patch.object(agent, '_wait_for_bootstrap', side_effect=_bootstrap_ok), \
         patch.object(agent, '_prefetch_checkpoint', side_effect=_prefetch_noop), \
         patch.object(agent, '_probe_cuda', side_effect=_probe_ok), \
         patch.object(agent, '_restart_job_on_node', side_effect=_restart_ok), \
         patch.object(agent, '_try_same_provider_different_az', new_callable=AsyncMock, return_value=None), \
         patch('asyncio.sleep', side_effect=_sleep_noop), \
         patch('asyncio.create_task', side_effect=_capture_coro):
        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM,
            decision_id="dec-789"
        )

    # Await all scheduled coroutines to prevent unawaited-coroutine warnings
    for coro in scheduled_coros:
        try:
            await coro
        except Exception:
            pass

    # create_task should have been called (at least once for cleanup)
    assert task_call_count[0] > 0


# ═══════════════════════════════════════════════════════════════════════════
# GAP-25: Pre-flight quota check
# ═══════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_migration_skips_provider_with_no_quota():
    """execute_migration must return early when _check_quota returns False."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    config = _make_config()
    queue = MockAgentQueue()
    agent = BrokerAgent(config=config, queue=queue)
    job = make_job()
    await queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    provision_called = []

    async def _quota_false(*a, **kw): return False
    async def _provision_spy(*a, **kw):
        provision_called.append(True)
        return None

    with patch.object(agent, '_check_quota', side_effect=_quota_false), \
         patch.object(agent, 'provision_lambda', side_effect=_provision_spy):
        result = await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id="dec-quota"
        )

    # provision_lambda must NOT have been called
    assert provision_called == [], "provision_lambda should not be called when quota check fails"
    # No MIGRATION_COMPLETE event
    event_types = queue.event_types_on("broker")
    assert "migration_complete" not in event_types


# ═══════════════════════════════════════════════════════════════════════════
# GAP-19: Compute capability check
# ═══════════════════════════════════════════════════════════════════════════

def test_probe_cuda_returns_compute_cap():
    """_probe_cuda must query compute capability from nvidia-smi."""
    import inspect
    from agents.broker.agent import BrokerAgent
    from agents.broker.ssh import probe_cuda
    source = inspect.getsource(probe_cuda)
    assert "compute_cap" in source, "_probe_cuda must query compute_cap"
    assert "nvidia-smi --query-gpu=compute_cap" in source


# ═══════════════════════════════════════════════════════════════════════════
# GAP-20: Checkpoint prefetch
# ═══════════════════════════════════════════════════════════════════════════

def test_checkpoint_prefetch_method_exists():
    """BrokerAgent must have _prefetch_checkpoint method."""
    from agents.broker.agent import BrokerAgent
    assert hasattr(BrokerAgent, '_prefetch_checkpoint')
    assert asyncio.iscoroutinefunction(BrokerAgent._prefetch_checkpoint)


def test_checkpoint_prefetch_starts_before_training():
    """_prefetch_checkpoint is called via create_task before _restart_job_on_node."""
    import inspect
    from agents.broker.agent import BrokerAgent
    from agents.broker.migration import execute_migration
    source = inspect.getsource(execute_migration)
    assert "_prefetch_checkpoint" in source
    assert "create_task" in source


# ═══════════════════════════════════════════════════════════════════════════
# GAP-8b: Heartbeat Redis persistence
# ═══════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_heartbeat_persists_to_redis():
    """async_record_heartbeat must call queue.hset and queue.expire."""
    from agents.watchdog.agent import WatchdogAgent
    config = _make_config()
    queue = MockAgentQueue()
    agent = WatchdogAgent(config, queue)
    job = make_job()
    agent._heartbeat.register_job(job.job_id)

    await agent.async_record_heartbeat(job.job_id, step=42, loss=1.23)

    assert hasattr(queue, '_hash_store'), "MockAgentQueue._hash_store not populated"
    key = f"vl:heartbeat:{job.job_id}"
    assert key in queue._hash_store
    hb = queue._hash_store[key]
    assert hb["step"] == "42"
    assert hb["loss"] == "1.23"


# ═══════════════════════════════════════════════════════════════════════════
# GAP-4: DataLoader skip on resume
# ═══════════════════════════════════════════════════════════════════════════

def test_dataloader_skip_applied_on_resume():
    """_patch_dataloader_skip must wrap DataLoader.__iter__ to skip N batches."""
    try:
        import torch.utils.data
    except ImportError:
        pytest.skip("torch not available")

    from vaultlayer._resume_hook import _patch_dataloader_skip

    # Reset any previous patch
    original_iter = torch.utils.data.DataLoader.__iter__
    try:
        _patch_dataloader_skip(5)
        patched = torch.utils.data.DataLoader.__iter__
        assert patched is not original_iter, "DataLoader.__iter__ must be patched"
    finally:
        torch.utils.data.DataLoader.__iter__ = original_iter


# ═══════════════════════════════════════════════════════════════════════════
# GAP-16: TransformerEngine extra states
# ═══════════════════════════════════════════════════════════════════════════

def test_checkpoint_saves_extra_states():
    """_save_extra_states must call get_extra_state on modules that have it."""
    try:
        import torch
        import torch.nn as nn
    except ImportError:
        pytest.skip("torch not available")

    from vaultlayer._resume_hook import _save_extra_states
    import tempfile, pathlib

    class FakeModule(nn.Module):
        def __init__(self):
            super().__init__()
            self._extra = {"fp8_scale": 1.0}
        def get_extra_state(self):
            return self._extra
        def forward(self, x): return x

    model = FakeModule()
    with tempfile.TemporaryDirectory() as tmpdir:
        _save_extra_states(model, pathlib.Path(tmpdir))
        assert (pathlib.Path(tmpdir) / "extra_states.pt").exists()
        loaded = torch.load(pathlib.Path(tmpdir) / "extra_states.pt", map_location="cpu")
        assert "" in loaded  # root module key is ""


def test_restore_loads_extra_states():
    """_load_extra_states must call set_extra_state on modules that have it."""
    try:
        import torch
        import torch.nn as nn
    except ImportError:
        pytest.skip("torch not available")

    from vaultlayer._resume_hook import _save_extra_states, _load_extra_states
    import tempfile, pathlib

    class FakeModule(nn.Module):
        def __init__(self):
            super().__init__()
            self._extra = {"fp8_scale": 1.0}
            self._loaded_extra = None
        def get_extra_state(self):
            return self._extra
        def set_extra_state(self, state):
            self._loaded_extra = state
        def forward(self, x): return x

    model = FakeModule()
    with tempfile.TemporaryDirectory() as tmpdir:
        _save_extra_states(model, pathlib.Path(tmpdir))
        model._loaded_extra = None  # reset
        _load_extra_states(model, pathlib.Path(tmpdir))
        assert model._loaded_extra == {"fp8_scale": 1.0}


# ═══════════════════════════════════════════════════════════════════════════
# GAP-9: Delta manifest
# ═══════════════════════════════════════════════════════════════════════════

def test_delta_upload_writes_delta_manifest():
    """upload_delta must write a _DELTA_MANIFEST.json alongside the delta file."""
    from agents.vault.r2 import R2Client

    r2 = R2Client.__new__(R2Client)
    r2.bucket = "test-bucket"

    put_calls = []

    mock_s3 = MagicMock()
    _put_sizes: dict = {}
    def mock_put(**kwargs):
        put_calls.append(kwargs)
        _put_sizes[kwargs.get("Key", "")] = len(kwargs.get("Body", b""))

    mock_s3.put_object.side_effect = mock_put
    # P0-C2: head_object must echo back the size so integrity check passes
    mock_s3.head_object.side_effect = lambda **kw: {
        "ContentLength": _put_sizes.get(kw.get("Key", ""), 0),
        "Metadata": {},
    }
    r2._s3 = mock_s3

    import tempfile, pathlib, zlib, os
    with tempfile.TemporaryDirectory() as tmpdir:
        prev = pathlib.Path(tmpdir) / "prev.pt"
        curr = pathlib.Path(tmpdir) / "curr.pt"
        # Same size, different bytes
        prev.write_bytes(b'\x00' * 1024)
        curr.write_bytes(b'\x01' * 1024)

        r2.upload_delta(
            job_id="job-delta-test",
            step=100,
            base_step=0,
            prev_local_path=str(prev),
            curr_local_path=str(curr),
            model_params_billion=7.0,
        )

    # Check _DELTA_MANIFEST.json was written
    manifest_calls = [c for c in put_calls if "_DELTA_MANIFEST.json" in c.get("Key", "")]
    assert len(manifest_calls) == 1, "Expected exactly one _DELTA_MANIFEST.json put_object call"
    body = json.loads(manifest_calls[0]["Body"].decode())
    assert body["complete"] is True
    assert body["step"] == 100
    assert body["base_step"] == 0


# ═══════════════════════════════════════════════════════════════════════════
# GAP-10: Atomic namespace manifest update
# ═══════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_namespace_manifest_update_retries_on_etag_conflict():
    """update_namespace_manifest_atomic must retry on PreconditionFailed (412)."""
    from agents.vault.r2 import R2Client
    from botocore.exceptions import ClientError

    r2 = R2Client.__new__(R2Client)
    r2.bucket = "test-bucket"

    call_count = [0]
    mock_s3 = MagicMock()

    def mock_get_object(**kwargs):
        return {
            "ETag": '"abc"',
            "Body": MagicMock(read=lambda: json.dumps({"job_id": "j", "checkpoint_chain": []}).encode())
        }

    def mock_put_object(**kwargs):
        call_count[0] += 1
        if call_count[0] < 3:
            # Simulate ETag conflict
            raise ClientError({"Error": {"Code": "PreconditionFailed", "Message": "412"}}, "PutObject")

    mock_s3.get_object.side_effect = mock_get_object
    mock_s3.put_object.side_effect = mock_put_object
    r2._s3 = mock_s3

    await r2.update_namespace_manifest_atomic("job-1", {"step": 100, "type": "full", "r2_key": "k"})
    assert call_count[0] == 3  # first two fail, third succeeds


# ═══════════════════════════════════════════════════════════════════════════
# GAP-11: Orphaned multipart upload cleanup
# ═══════════════════════════════════════════════════════════════════════════

def test_cleanup_orphaned_multipart_uploads():
    """cleanup_orphaned_multipart_uploads must abort uploads older than max_age_hours."""
    from agents.vault.r2 import R2Client
    from datetime import timezone, timedelta

    r2 = R2Client.__new__(R2Client)
    r2.bucket = "test-bucket"
    mock_s3 = MagicMock()

    old_time = datetime.now(timezone.utc) - timedelta(hours=48)
    new_time = datetime.now(timezone.utc) - timedelta(hours=1)

    uploads_list = [
        {"Key": "old-upload.pt", "UploadId": "uid-old", "Initiated": old_time},
        {"Key": "new-upload.pt", "UploadId": "uid-new", "Initiated": new_time},
    ]
    mock_s3.list_multipart_uploads.return_value = {"Uploads": uploads_list}
    # Also set up paginator to return the same uploads (code prefers paginator)
    mock_page = {"Uploads": uploads_list}
    mock_paginator = MagicMock()
    mock_paginator.paginate.return_value = [mock_page]
    mock_s3.get_paginator.return_value = mock_paginator
    r2._s3 = mock_s3

    aborted = r2.cleanup_orphaned_multipart_uploads(max_age_hours=24)

    assert aborted == 1
    mock_s3.abort_multipart_upload.assert_called_once_with(
        Bucket="test-bucket",
        Key="old-upload.pt",
        UploadId="uid-old",
    )


# ═══════════════════════════════════════════════════════════════════════════
# GAP-13: Bucket public access verification
# ═══════════════════════════════════════════════════════════════════════════

def test_vault_warns_on_public_bucket():
    """VaultAgent.start() must log a critical warning if R2 bucket is public."""
    from agents.vault.r2 import R2Client

    r2 = R2Client.__new__(R2Client)
    mock_s3 = MagicMock()
    # Simulate bucket with AllUsers grant
    mock_s3.get_bucket_acl.return_value = {
        "Grants": [
            {"Grantee": {"URI": "http://acs.amazonaws.com/groups/global/AllUsers"}, "Permission": "READ"}
        ]
    }
    r2._s3 = mock_s3
    r2.bucket = "test-bucket"

    result = r2.verify_bucket_private()
    assert result is False


def test_verify_bucket_private_returns_true_for_private():
    """verify_bucket_private must return True when no AllUsers/AuthenticatedUsers grants exist."""
    from agents.vault.r2 import R2Client

    r2 = R2Client.__new__(R2Client)
    mock_s3 = MagicMock()
    mock_s3.get_bucket_acl.return_value = {
        "Grants": [
            {"Grantee": {"ID": "owner-canonical-id"}, "Permission": "FULL_CONTROL"}
        ]
    }
    r2._s3 = mock_s3
    r2.bucket = "test-bucket"

    assert r2.verify_bucket_private() is True


# ═══════════════════════════════════════════════════════════════════════════
# GAP-21: Checkpoint mutex
# ═══════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_concurrent_checkpoint_calls_are_deduplicated():
    """Concurrent checkpoint() calls must not both execute — second must be skipped."""
    from agents.vault.agent import VaultAgent
    from shared.models import Job, JobStatus, Provider, GPUType
    import asyncio

    config = _make_config()
    queue = MockAgentQueue()
    agent = VaultAgent(config, queue)
    agent.r2 = MagicMock()
    agent.r2.healthcheck.return_value = True

    job = make_job()

    # Simulate a slow checkpoint already in progress using the atomic dedup flag
    # (replaces lock.locked() check — that was a TOCTOU race; see BUG-2 fix)
    agent._checkpoint_in_progress[job.job_id] = True
    result = await agent.checkpoint(job, "/tmp/nonexistent_model.pt")
    agent._checkpoint_in_progress[job.job_id] = False

    assert result is None, "Concurrent checkpoint should return None (deduplicated)"


# ═══════════════════════════════════════════════════════════════════════════
# GAP-17: Stale file check
# ═══════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_vault_skips_upload_when_file_unchanged():
    """checkpoint() must return None when model file has same SHA256 as last upload."""
    from agents.vault.agent import VaultAgent
    import tempfile, pathlib

    config = _make_config()
    queue = MockAgentQueue()
    agent = VaultAgent(config, queue)
    agent.r2 = MagicMock()
    agent.r2.healthcheck.return_value = True

    job = make_job()

    with tempfile.NamedTemporaryFile(delete=False, suffix=".pt") as f:
        f.write(b"fake model weights")
        model_path = f.name

    try:
        # Compute SHA and pre-load it as if we already uploaded
        import hashlib
        sha = hashlib.sha256(pathlib.Path(model_path).read_bytes()).hexdigest()
        agent._last_uploaded_sha256[job.job_id] = sha

        result = await agent.checkpoint(job, model_path)
        assert result is None, "Should skip upload when file unchanged"
    finally:
        os.unlink(model_path)


# ═══════════════════════════════════════════════════════════════════════════
# GAP-24: Billing granularity sunk cost
# ═══════════════════════════════════════════════════════════════════════════

def test_sunk_cost_zero_for_per_second_billing():
    """AWS per-second billing should have near-zero sunk cost (< $0.01)."""
    from agents.pricing.agent import PricingAgent
    from shared.models import Provider

    config = _make_config()
    queue = MockAgentQueue()
    agent = PricingAgent(config, queue)

    job = make_job()
    job.current_hourly_rate = 98.32
    # Force AWS billing granularity (60s)
    sunk = agent.compute_sunk_cost_usd(job, Provider.AWS)
    # Should be at most 98.32 * (60/3600) = ~1.64, but usually much less
    assert sunk >= 0.0
    assert sunk < 2.0  # per-second billing keeps sunk cost low


def test_sunk_cost_nonzero_for_hourly_billing():
    """Lambda Labs hourly billing should show non-trivial sunk cost mid-hour."""
    from agents.pricing.agent import PricingAgent
    from shared.models import Provider
    import time

    config = _make_config()
    queue = MockAgentQueue()
    agent = PricingAgent(config, queue)

    job = make_job()
    job.current_hourly_rate = 24.99
    # Set started_at to 30 minutes ago (mid-hour)
    job.started_at = datetime.utcfromtimestamp(time.time() - 1800)

    sunk = agent.compute_sunk_cost_usd(job, Provider.LAMBDA_LABS)
    # For hourly billing at $24.99/hr, 30 min into hour: ~$12.50 sunk
    assert sunk > 1.0, f"Expected significant sunk cost for hourly billing, got {sunk}"


def test_arbitrage_held_when_sunk_cost_exceeds_savings():
    """Sunk cost reduces effective savings; must be available for orchestration to use."""
    from agents.pricing.agent import PricingAgent
    from shared.models import Provider
    import time

    config = _make_config()
    queue = MockAgentQueue()
    agent = PricingAgent(config, queue)

    job = make_job()
    job.current_hourly_rate = 100.0
    # Start at 1 second into hourly period (almost all hour is sunk)
    job.started_at = datetime.utcfromtimestamp(time.time() - 1)

    sunk = agent.compute_sunk_cost_usd(job, Provider.LAMBDA_LABS)
    # ~$100/hr * (3599/3600) ≈ $99.97
    assert sunk > 90.0, "Sunk cost should be near-full hourly rate at start of period"


# ═══════════════════════════════════════════════════════════════════════════
# GAP-29: Cross-region latency penalty
# ═══════════════════════════════════════════════════════════════════════════

def test_cross_region_penalty_applied():
    """_cross_region_penalty must return non-zero for known cross-region pairs."""
    from agents.pricing.agent import PricingAgent

    config = _make_config()
    queue = MockAgentQueue()
    agent = PricingAgent(config, queue)

    penalty = agent._cross_region_penalty("us-east-1", "eu-west-1")
    assert penalty > 0.0, "Expected positive penalty for us-east-1 → eu-west-1"


def test_same_region_no_penalty():
    """_cross_region_penalty must return 0 for same-region or unknown pairs."""
    from agents.pricing.agent import PricingAgent

    config = _make_config()
    queue = MockAgentQueue()
    agent = PricingAgent(config, queue)

    penalty = agent._cross_region_penalty("us-east-1", "us-east-1")
    assert penalty == 0.0, "No penalty expected for same region"

    unknown_penalty = agent._cross_region_penalty("mars-west-1", "venus-east-2")
    assert unknown_penalty == 0.0, "Unknown region pair should return 0 penalty"


# ═══════════════════════════════════════════════════════════════════════════
# GAP-26: Hidden fees in FinOps
# ═══════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_finops_includes_secondary_cost_estimates():
    """generate_job_report must include secondary_costs in report.__dict__."""
    from agents.finops.agent import FinOpsAgent
    from shared.models import Job, Provider, GPUType, JobStatus
    from unittest.mock import MagicMock

    config = _make_config()
    queue = MockAgentQueue()
    agent = FinOpsAgent(config, queue)
    # Mock Claude to avoid API calls
    agent._claude = MagicMock()
    agent._claude.messages.create.return_value = MagicMock(
        content=[MagicMock(text="Test narrative.")]
    )

    job = make_job()
    job.completed_at = datetime.utcnow()
    job.total_spend_usd = 10.0
    job.aws_equivalent_usd = 32.0

    report = await agent.generate_job_report(job)

    assert hasattr(report, "__dict__")
    secondary = report.__dict__.get("secondary_costs", {})
    assert "r2_put_ops_usd" in secondary
    assert "r2_get_ops_usd" in secondary
    assert "ec2_ipv4_usd" in secondary


# ═══════════════════════════════════════════════════════════════════════════
# GAP-15: Async save in checkpoint helper
# ═══════════════════════════════════════════════════════════════════════════

def test_checkpoint_async_save_does_not_block():
    """checkpoint(async_save=True) must start a background thread and return immediately."""
    try:
        import torch
        import torch.nn as nn
    except ImportError:
        pytest.skip("torch not available")

    import tempfile, sys
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src', 'cli'))

    # Load the template module directly to get checkpoint function
    import importlib.util, pathlib
    template_path = pathlib.Path(__file__).parent.parent / "src" / "cli" / "checkpoint_template.py"
    spec = importlib.util.spec_from_file_location("ckpt_tmpl", str(template_path))
    tmpl = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tmpl)

    # Extract the checkpoint helper source and exec it
    helper_src = tmpl.CHECKPOINT_HELPER_TEMPLATE
    exec_globals = {}
    exec(helper_src, exec_globals)

    _checkpoint = exec_globals.get("checkpoint")
    if _checkpoint is None:
        pytest.skip("checkpoint function not found in template")

    class TinyModel(nn.Module):
        def __init__(self):
            super().__init__()
            self.fc = nn.Linear(4, 2)
        def forward(self, x):
            return self.fc(x)

    model = TinyModel()
    with tempfile.TemporaryDirectory() as tmpdir:
        start = time.time()
        result = _checkpoint(step=1, model=model, save_path=tmpdir, async_save=True)
        elapsed = time.time() - start
        # async_save should return quickly (< 2s even on slow hardware)
        assert elapsed < 5.0, f"async_save took too long: {elapsed:.2f}s"
        assert result is not None
        # Join the background thread before tempdir cleanup to avoid OSError
        bg_thread = exec_globals.get("_ASYNC_THREAD", [None])[0]
        if bg_thread is not None and bg_thread.is_alive():
            bg_thread.join(timeout=10)


# ═══════════════════════════════════════════════════════════════════════════
# GAP-5: vaultlayer stop command
# ═══════════════════════════════════════════════════════════════════════════

def test_stop_command_exists_in_cli():
    """CLI must have a 'stop' command registered."""
    import inspect
    from cli.main import cli
    command_names = [c for c in cli.commands.keys()]
    assert "stop" in command_names, f"'stop' command not found in CLI. Found: {command_names}"


def test_logs_command_exists_in_cli():
    """CLI must have a 'logs' command registered."""
    from cli.main import cli
    command_names = [c for c in cli.commands.keys()]
    assert "logs" in command_names, f"'logs' command not found in CLI. Found: {command_names}"


def test_stop_requested_event_type_exists():
    """EventType must include STOP_REQUESTED."""
    from shared.models import EventType
    assert hasattr(EventType, "STOP_REQUESTED")
    assert EventType.STOP_REQUESTED.value == "stop_requested"


# ═══════════════════════════════════════════════════════════════════════════
# GAP-1: Log forwarding
# ═══════════════════════════════════════════════════════════════════════════

def test_log_buffer_in_run_py():
    """subprocess runner must maintain a deque log buffer."""
    import inspect
    import cli._subprocess as _sub
    source = inspect.getsource(_sub.run_subprocess)
    assert "deque" in source or "_deque" in source, "No deque buffer found in run_subprocess"
    assert "_log_buffer" in source


def test_flush_log_buffer_to_r2_defined():
    """subprocess runner must define _flush_log_buffer_to_r2 coroutine."""
    import inspect
    import cli._subprocess as _sub
    source = inspect.getsource(_sub.run_subprocess)
    assert "_flush_log_buffer_to_r2" in source


# ═══════════════════════════════════════════════════════════════════════════
# Model field existence
# ═══════════════════════════════════════════════════════════════════════════

def test_job_has_ssh_host_field():
    """Job model must have ssh_host field."""
    from shared.models import Job, Provider, GPUType
    job = make_job()
    assert hasattr(job, "ssh_host")
    assert job.ssh_host is None


def test_job_has_source_compute_cap_field():
    """Job model must have source_compute_cap field."""
    job = make_job()
    assert hasattr(job, "source_compute_cap")
    assert job.source_compute_cap is None


def test_job_has_current_hourly_rate_field():
    """Job model must have current_hourly_rate field."""
    job = make_job()
    assert hasattr(job, "current_hourly_rate")
    assert job.current_hourly_rate == 0.0


def test_job_has_dataset_region_field():
    """Job model must have dataset_region field."""
    job = make_job()
    assert hasattr(job, "dataset_region")
    assert job.dataset_region == ""
