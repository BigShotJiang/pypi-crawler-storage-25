"""Tests for issue #128: region/exclusion constraint enforcement in provider adapters.

Verifies that AWS, Lambda Labs, and GCP correctly filter candidate regions/zones
against job.regions (whitelist) and job.excluded_regions (blacklist) before
attempting to provision, rather than silently landing in a non-compliant region.
"""
from __future__ import annotations

import asyncio
import pytest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_job(regions=None, excluded_regions=None, job_id="test-job-1234"):
    """Return a SimpleNamespace mimicking shared.models.Job placement fields."""
    return SimpleNamespace(
        job_id=job_id,
        regions=regions or [],
        excluded_regions=excluded_regions or [],
        last_provision_error=None,
        failure_code=None,
        failure_detail=None,
        environment={},
        docker_image=None,
        dataset_region=None,
        dataset_location=None,
        _provision_attempts=[],
    )


# ---------------------------------------------------------------------------
# AWS constraint enforcement
# ---------------------------------------------------------------------------

class TestAWSRegionConstraintEnforcement:
    """Tests for the region filtering block added after aws_capacity.rank_regions()."""

    def test_excluded_region_dropped_from_fallback(self):
        """A region in excluded_regions must be removed from regions_to_try."""
        from agents.broker.providers.aws import _check_region_allowed, RegionNotAllowedError

        job = _make_job(excluded_regions=["us-west-2"])

        # Simulate what the filtering block does
        regions_to_try = ["us-east-1", "us-west-2", "eu-west-1"]
        filtered = []
        dropped = []
        for r in regions_to_try:
            try:
                _check_region_allowed(r, job)
                filtered.append(r)
            except RegionNotAllowedError:
                dropped.append(r)

        assert "us-west-2" not in filtered
        assert "us-west-2" in dropped
        assert filtered == ["us-east-1", "eu-west-1"]

    def test_whitelist_allows_only_matching_regions(self):
        """When regions whitelist is set, only whitelisted regions pass."""
        from agents.broker.providers.aws import _check_region_allowed, RegionNotAllowedError

        job = _make_job(regions=["us-east-1"])

        regions_to_try = ["us-east-1", "us-west-2", "eu-west-1"]
        filtered = []
        for r in regions_to_try:
            try:
                _check_region_allowed(r, job)
                filtered.append(r)
            except RegionNotAllowedError:
                pass

        assert filtered == ["us-east-1"]

    def test_no_constraints_all_regions_pass(self):
        """With empty regions and excluded_regions, all candidates survive."""
        from agents.broker.providers.aws import _check_region_allowed, RegionNotAllowedError

        job = _make_job()

        regions_to_try = ["us-east-1", "us-west-2", "eu-west-1"]
        filtered = []
        for r in regions_to_try:
            try:
                _check_region_allowed(r, job)
                filtered.append(r)
            except RegionNotAllowedError:
                pass

        assert filtered == regions_to_try

    def test_excluded_takes_priority_over_whitelist(self):
        """excluded_regions overrides regions whitelist."""
        from agents.broker.providers.aws import _check_region_allowed, RegionNotAllowedError

        # us-east-1 is in both whitelist and blacklist — excluded wins
        job = _make_job(regions=["us-east-1", "us-west-2"], excluded_regions=["us-east-1"])

        regions_to_try = ["us-east-1", "us-west-2"]
        filtered = []
        for r in regions_to_try:
            try:
                _check_region_allowed(r, job)
                filtered.append(r)
            except RegionNotAllowedError:
                pass

        assert "us-east-1" not in filtered
        assert "us-west-2" in filtered

    def test_all_regions_blocked_returns_none_error(self):
        """If all regions violate constraints, last_provision_error must be set."""
        from agents.broker.providers.aws import RegionNotAllowedError

        job = _make_job(excluded_regions=["us-east-1", "us-west-2", "eu-west-1"])

        regions_to_try = ["us-east-1", "us-west-2", "eu-west-1"]
        filtered = []
        for r in regions_to_try:
            try:
                from agents.broker.providers.aws import _check_region_allowed
                _check_region_allowed(r, job)
                filtered.append(r)
            except RegionNotAllowedError:
                pass

        if not filtered:
            job.last_provision_error = (
                f"AWS: no region satisfies job placement constraints "
                f"(regions={job.regions}, excluded={job.excluded_regions})"
            )

        assert filtered == []
        assert job.last_provision_error is not None
        assert "no region satisfies" in job.last_provision_error


# ---------------------------------------------------------------------------
# Lambda Labs constraint enforcement
# ---------------------------------------------------------------------------

class TestLambdaLabsRegionConstraintEnforcement:
    """Tests for the region filtering block added inside lambda_labs.provision()."""

    def _filter_regions(self, regions_from_api, job):
        """Replicate the filtering logic from lambda_labs.provision()."""
        _job_regions = list(getattr(job, "regions", None) or [])
        _job_excl = set(getattr(job, "excluded_regions", None) or [])
        _allowed = [
            r for r in regions_from_api
            if r["name"] not in _job_excl
            and (not _job_regions or r["name"] in _job_regions)
        ]
        return _allowed

    def test_excluded_region_filtered_out(self):
        """A region in excluded_regions must be dropped from available list."""
        job = _make_job(excluded_regions=["us-east-1"])
        regions = [{"name": "us-east-1"}, {"name": "us-west-1"}, {"name": "eu-west-1"}]

        allowed = self._filter_regions(regions, job)
        names = [r["name"] for r in allowed]
        assert "us-east-1" not in names
        assert "us-west-1" in names

    def test_whitelist_keeps_only_matching(self):
        """Only regions in the whitelist survive."""
        job = _make_job(regions=["us-west-1"])
        regions = [{"name": "us-east-1"}, {"name": "us-west-1"}, {"name": "eu-west-1"}]

        allowed = self._filter_regions(regions, job)
        assert len(allowed) == 1
        assert allowed[0]["name"] == "us-west-1"

    def test_no_constraints_all_allowed(self):
        """Without constraints all regions pass through."""
        job = _make_job()
        regions = [{"name": "us-east-1"}, {"name": "us-west-1"}]

        allowed = self._filter_regions(regions, job)
        assert len(allowed) == 2

    def test_all_regions_blocked_means_no_allowed(self):
        """When all regions are excluded, allowed list is empty (provision returns None)."""
        job = _make_job(excluded_regions=["us-east-1", "us-west-1"])
        regions = [{"name": "us-east-1"}, {"name": "us-west-1"}]

        allowed = self._filter_regions(regions, job)
        assert allowed == []

    def test_whitelist_and_no_capacity_means_no_allowed(self):
        """If whitelist region has no capacity (not in API list), allowed is empty."""
        job = _make_job(regions=["ap-southeast-1"])
        regions = [{"name": "us-east-1"}, {"name": "us-west-1"}]

        allowed = self._filter_regions(regions, job)
        assert allowed == []


# ---------------------------------------------------------------------------
# GCP zone constraint enforcement
# ---------------------------------------------------------------------------

class TestGCPZoneConstraintEnforcement:
    """Tests for the zone filtering block added inside gcp.provision()."""

    def _filter_zones(self, zones, job):
        """Replicate the filtering logic added to gcp.provision()."""
        _job_regions = list(getattr(job, "regions", None) or [])
        _job_excl_regions = set(getattr(job, "excluded_regions", None) or [])
        if not (_job_regions or _job_excl_regions):
            return zones, []
        dropped = []
        kept = []
        for z in zones:
            z_region = z.rsplit("-", 1)[0]
            if z_region in _job_excl_regions:
                dropped.append(z)
            elif _job_regions and z_region not in _job_regions:
                dropped.append(z)
            else:
                kept.append(z)
        return kept, dropped

    def test_excluded_region_drops_its_zones(self):
        """All zones in an excluded region must be dropped."""
        job = _make_job(excluded_regions=["us-east1"])
        zones = ["us-central1-a", "us-east1-b", "us-east1-c", "europe-west4-a"]

        kept, dropped = self._filter_zones(zones, job)
        assert "us-east1-b" not in kept
        assert "us-east1-c" not in kept
        assert "us-central1-a" in kept
        assert "europe-west4-a" in kept

    def test_whitelist_region_keeps_only_matching_zones(self):
        """Only zones in whitelisted regions survive."""
        job = _make_job(regions=["us-central1"])
        zones = ["us-central1-a", "us-central1-b", "us-east1-b", "europe-west4-a"]

        kept, dropped = self._filter_zones(zones, job)
        assert kept == ["us-central1-a", "us-central1-b"]
        assert "us-east1-b" in dropped
        assert "europe-west4-a" in dropped

    def test_no_constraints_all_zones_kept(self):
        """With no constraints all zones pass through unchanged."""
        job = _make_job()
        zones = ["us-central1-a", "us-east1-b", "europe-west4-a"]

        kept, dropped = self._filter_zones(zones, job)
        assert kept == zones
        assert dropped == []

    def test_zone_region_extraction(self):
        """Verify zone → region extraction logic handles standard GCP zone names."""
        zones = ["us-central1-a", "us-east1-b", "europe-west4-c", "asia-east1-a"]
        expected_regions = ["us-central1", "us-east1", "europe-west4", "asia-east1"]
        for zone, expected in zip(zones, expected_regions):
            assert zone.rsplit("-", 1)[0] == expected

    def test_all_zones_blocked_returns_empty(self):
        """When all zones are in excluded regions, kept list is empty."""
        job = _make_job(excluded_regions=["us-central1", "us-east1"])
        zones = ["us-central1-a", "us-central1-b", "us-east1-b"]

        kept, dropped = self._filter_zones(zones, job)
        assert kept == []
        assert len(dropped) == 3

    def test_combined_whitelist_and_exclusion(self):
        """Exclusion overrides whitelist: excluded zone stays out even if region whitelisted."""
        # regions=["us-central1"] + excluded=["us-central1"] → nothing passes
        job = _make_job(regions=["us-central1"], excluded_regions=["us-central1"])
        zones = ["us-central1-a", "us-central1-b"]

        kept, dropped = self._filter_zones(zones, job)
        # excluded_regions wins, so all us-central1 zones are dropped
        assert kept == []
