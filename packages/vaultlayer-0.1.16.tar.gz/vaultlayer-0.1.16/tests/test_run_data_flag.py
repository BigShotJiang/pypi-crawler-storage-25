"""
VaultLayer — vaultlayer run --data flag tests

Tests for:
  - --data s3://... triggers S3→R2 mirror before training
  - --data r2://dataset-id sets VAULTLAYER_DATASET_ID without mirror
  - Mirror skipped when dataset already exists in R2 (idempotent)
  - User decline aborts training
  - --yes propagated to mirror confirmation
  - dataset_id derived correctly from S3 URI
  - VAULTLAYER_DATASET_ID env var set after successful mirror
  - No --data flag → no mirror, no env var
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
from unittest.mock import MagicMock, AsyncMock, patch


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_runner(data_uri=None, yes=False):
    from cli.run import RunCommand
    runner = RunCommand(
        command=["python", "train.py"],
        job_name="test-run",
        data_uri=data_uri,
    )
    runner.yes = yes
    return runner


# ── 1. dataset_id derived from S3 URI ────────────────────────────────────────

@pytest.mark.asyncio
async def test_dataset_id_derived_from_s3_uri_bucket_only():
    """s3://my-bucket → dataset_id = 'my-bucket'."""
    runner = _make_runner(data_uri="s3://my-bucket")
    with patch("shared.config.load_config"), \
         patch("agents.vault.r2.R2Client"), \
         patch("agents.namespace.ingestion.DatasetIngester.load_manifest",
               new_callable=AsyncMock, return_value=MagicMock()):
        result = await runner._maybe_mirror_s3_data("s3://my-bucket")
    assert result == "my-bucket"


@pytest.mark.asyncio
async def test_dataset_id_derived_from_s3_uri_with_prefix():
    """s3://bucket/data/train → dataset_id = 'bucket-data-train'."""
    runner = _make_runner()
    with patch("shared.config.load_config"), \
         patch("agents.vault.r2.R2Client"), \
         patch("agents.namespace.ingestion.DatasetIngester.load_manifest",
               new_callable=AsyncMock, return_value=MagicMock()):
        result = await runner._maybe_mirror_s3_data("s3://bucket/data/train")
    assert result == "bucket-data-train"


# ── 2. Mirror skipped when dataset already in R2 ─────────────────────────────

@pytest.mark.asyncio
async def test_mirror_skipped_when_dataset_exists_in_r2():
    """If dataset already exists in R2, _sync_from_s3 must NOT be called."""
    runner = _make_runner(data_uri="s3://my-bucket/data")

    existing_manifest = MagicMock()  # truthy — dataset exists
    mock_sync = AsyncMock()

    with patch("shared.config.load_config"), \
         patch("agents.vault.r2.R2Client"), \
         patch("agents.namespace.ingestion.DatasetIngester.load_manifest",
               new_callable=AsyncMock, return_value=existing_manifest), \
         patch("cli.sync._sync_from_s3", mock_sync):
        result = await runner._maybe_mirror_s3_data("s3://my-bucket/data")

    assert result == "my-bucket-data", f"Expected dataset_id, got {result}"
    mock_sync.assert_not_called(), "Mirror must be skipped when dataset already in R2"


# ── 3. Mirror called when dataset NOT in R2 ──────────────────────────────────

@pytest.mark.asyncio
async def test_mirror_called_when_dataset_not_in_r2():
    """If dataset is not in R2, _sync_from_s3 must be called."""
    runner = _make_runner(data_uri="s3://my-bucket/data")
    mock_sync = AsyncMock()

    with patch("shared.config.load_config"), \
         patch("agents.vault.r2.R2Client"), \
         patch("agents.namespace.ingestion.DatasetIngester.load_manifest",
               new_callable=AsyncMock, return_value=None), \
         patch("cli.sync._sync_from_s3", mock_sync):
        result = await runner._maybe_mirror_s3_data("s3://my-bucket/data")

    mock_sync.assert_called_once()
    assert result == "my-bucket-data"


# ── 4. --yes flag propagated to mirror ───────────────────────────────────────

@pytest.mark.asyncio
async def test_yes_flag_propagated_to_mirror():
    """The --yes flag on 'vaultlayer run' must be forwarded to _sync_from_s3."""
    runner = _make_runner(data_uri="s3://my-bucket/data", yes=True)
    mock_sync = AsyncMock()

    with patch("shared.config.load_config"), \
         patch("agents.vault.r2.R2Client"), \
         patch("agents.namespace.ingestion.DatasetIngester.load_manifest",
               new_callable=AsyncMock, return_value=None), \
         patch("cli.sync._sync_from_s3", mock_sync):
        await runner._maybe_mirror_s3_data("s3://my-bucket/data")

    _, kwargs = mock_sync.call_args
    assert kwargs.get("yes") is True, \
        f"--yes not forwarded to mirror. got yes={kwargs.get('yes')}"


# ── 5. User decline aborts training ──────────────────────────────────────────

@pytest.mark.asyncio
async def test_user_decline_returns_none():
    """If _sync_from_s3 raises SystemExit (user declined), propagate the exit
    so training does not start without data (issue #218)."""
    runner = _make_runner(data_uri="s3://my-bucket/data")

    async def sync_raises(*args, **kwargs):
        raise SystemExit(1)

    with patch("shared.config.load_config"), \
         patch("agents.vault.r2.R2Client"), \
         patch("agents.namespace.ingestion.DatasetIngester.load_manifest",
               new_callable=AsyncMock, return_value=None), \
         patch("cli.sync._sync_from_s3", side_effect=sync_raises):
        with pytest.raises(SystemExit):
            await runner._maybe_mirror_s3_data("s3://my-bucket/data")


# ── 6. Mirror failure aborts training ────────────────────────────────────────

@pytest.mark.asyncio
async def test_mirror_failure_is_non_fatal():
    """If the mirror fails, training is aborted rather than starting without
    data (issue #218: --data mirror failure must propagate as SystemExit)."""
    runner = _make_runner(data_uri="s3://my-bucket/data")

    async def sync_raises(*args, **kwargs):
        raise Exception("boto3 credentials expired")

    with patch("shared.config.load_config"), \
         patch("agents.vault.r2.R2Client"), \
         patch("agents.namespace.ingestion.DatasetIngester.load_manifest",
               new_callable=AsyncMock, return_value=None), \
         patch("cli.sync._sync_from_s3", side_effect=sync_raises):
        with pytest.raises(SystemExit):
            await runner._maybe_mirror_s3_data("s3://my-bucket/data")


# ── 7. r2://dataset-id sets env var without mirror ───────────────────────────

@pytest.mark.asyncio
async def test_r2_uri_sets_dataset_env_var_without_mirror(monkeypatch):
    """--data r2://dataset-id must set VAULTLAYER_DATASET_ID without calling mirror."""
    captured_env = {}
    monkeypatch.setattr(os, "environ", {**os.environ, **captured_env})

    runner = _make_runner(data_uri="r2://my-existing-dataset")

    mock_mirror = AsyncMock()
    mock_execute_rest = AsyncMock()  # prevent actual execution

    # Patch _maybe_mirror_s3_data to verify it's NOT called
    with patch.object(runner, "_maybe_mirror_s3_data", mock_mirror), \
         patch("cli._preflight.print_preflight", return_value=False):
        await runner.execute()  # returns early because preflight returns False

    mock_mirror.assert_not_called()


# ── 8. dataset_id capped at 64 chars ─────────────────────────────────────────

@pytest.mark.asyncio
async def test_dataset_id_capped_at_64_chars():
    """dataset_id derived from long S3 URIs must be at most 64 characters."""
    long_uri = "s3://my-very-long-bucket-name/with/a/very/deep/prefix/that/is/way/too/long"
    runner = _make_runner(data_uri=long_uri)

    with patch("shared.config.load_config"), \
         patch("agents.vault.r2.R2Client"), \
         patch("agents.namespace.ingestion.DatasetIngester.load_manifest",
               new_callable=AsyncMock, return_value=MagicMock()):
        result = await runner._maybe_mirror_s3_data(long_uri)

    assert len(result) <= 64, f"dataset_id too long: {len(result)} chars: {result}"


# ── 9. dataset_id contains only safe chars ───────────────────────────────────

@pytest.mark.asyncio
async def test_dataset_id_sanitized():
    """dataset_id must contain only [a-zA-Z0-9_-] characters."""
    import re
    uri = "s3://my.bucket/some/path with spaces/and.dots"
    runner = _make_runner(data_uri=uri)

    with patch("shared.config.load_config"), \
         patch("agents.vault.r2.R2Client"), \
         patch("agents.namespace.ingestion.DatasetIngester.load_manifest",
               new_callable=AsyncMock, return_value=MagicMock()):
        result = await runner._maybe_mirror_s3_data(uri)

    assert re.match(r"^[a-zA-Z0-9_\-]+$", result), \
        f"Unsafe chars in dataset_id: {result}"


# ── 10. RunCommand accepts data_uri parameter ─────────────────────────────────

def test_run_command_accepts_data_uri():
    """RunCommand.__init__ must accept data_uri without raising."""
    from cli.run import RunCommand
    runner = RunCommand(
        command=["python", "train.py"],
        job_name="test",
        data_uri="s3://my-bucket/data",
    )
    assert runner.data_uri == "s3://my-bucket/data"


def test_run_command_data_uri_defaults_to_none():
    """data_uri must default to None when not provided."""
    from cli.run import RunCommand
    runner = RunCommand(command=["python", "train.py"], job_name="test")
    assert runner.data_uri is None


# ── 11. RunCommand accepts docker_image parameter ────────────────────────────

def test_run_command_accepts_docker_image():
    """RunCommand must accept docker_image and store it."""
    from cli.run import RunCommand
    runner = RunCommand(
        command=["python", "train.py"],
        job_name="test",
        docker_image="nvcr.io/nvidia/pytorch:24.01-py3",
    )
    assert runner.docker_image == "nvcr.io/nvidia/pytorch:24.01-py3"


def test_run_command_docker_image_defaults_to_empty():
    """docker_image must default to empty string when not provided."""
    from cli.run import RunCommand
    runner = RunCommand(command=["python", "train.py"], job_name="test")
    assert runner.docker_image == ""


def test_job_environment_captured_from_env_vars(monkeypatch):
    """Job.environment must include known env vars set in the environment."""
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))
    monkeypatch.setenv("WANDB_API_KEY", "test-wandb-key")
    monkeypatch.setenv("HF_TOKEN", "test-hf-token")
    # Verify env vars are captured by the key list in run.py
    _env_keys = ["WANDB_API_KEY", "HF_TOKEN", "HUGGING_FACE_HUB_TOKEN",
                 "VAULTLAYER_DATASET_ID", "NCCL_DEBUG", "CUDA_VISIBLE_DEVICES"]
    captured = {k: os.environ[k] for k in _env_keys if k in os.environ}
    assert captured["WANDB_API_KEY"] == "test-wandb-key"
    assert captured["HF_TOKEN"] == "test-hf-token"
