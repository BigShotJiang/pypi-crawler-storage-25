"""Tests for issue #147: heartbeat writer must use 'ts' field (not 'last_seen').

The orchestration cloud monitor reads hget("vl:heartbeat:{job_id}", "ts") and
parses it as a float Unix timestamp. The watchdog writer must write the same field.
"""
import pytest
import time


def test_heartbeat_mapping_uses_ts_key():
    """async_record_heartbeat must map 'ts' not 'last_seen' in the Redis hset call."""
    import inspect
    from agents.watchdog.agent import WatchdogAgent

    source = inspect.getsource(WatchdogAgent.async_record_heartbeat)
    assert '"ts"' in source or "'ts'" in source, (
        "async_record_heartbeat must write 'ts' field to Redis so orchestration "
        "_heartbeat_monitor_loop can read it via hget(key, 'ts')"
    )
    assert "last_seen" not in source, (
        "async_record_heartbeat must not write 'last_seen' — orchestration reads 'ts'"
    )


def test_heartbeat_ts_is_numeric_string():
    """The 'ts' value written must be parseable as a float (Unix timestamp)."""
    import time
    ts_value = str(time.time())
    parsed = float(ts_value)
    assert parsed > 0
    assert abs(parsed - time.time()) < 5  # within 5s of now


def test_orchestration_reads_ts_field():
    """Orchestration _heartbeat_monitor_loop must read 'ts' field — verify the source."""
    import inspect
    from agents.orchestration.agent import OrchestrationAgent

    source = inspect.getsource(OrchestrationAgent._heartbeat_monitor_loop)
    assert '"ts"' in source or "'ts'" in source, (
        "_heartbeat_monitor_loop must read 'ts' field from Redis heartbeat hash"
    )
    assert "float(raw)" in source or "float(" in source, (
        "_heartbeat_monitor_loop must parse 'ts' as float for age calculation"
    )
