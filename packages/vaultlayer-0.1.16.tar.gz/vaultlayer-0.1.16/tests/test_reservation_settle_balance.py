"""
Tests for issue #148: BYOC settle_job() releases reservation to fix double-debit.

The double-debit bug:
  - start_job()  → reserved  event: -100 credits  (balance -100)
  - burn() x 3   → burned events: -60 credits total (balance -160)
  - settle_job() → settled event: 0 credits          (balance -160)
  Net deduction: 160 credits, actual cost was only 60 burns.

The fix: settle_job() adds a `released` event (+reservation) so net = -burns.
  - start_job()  → reserved  event: -100 credits  (balance -100)
  - burn() x 3   → burned events: -60 credits total (balance -160)
  - settle_job() → released  event: +100 credits   (balance -60)
  Net deduction: 60 credits = actual burns only. ✓

Verifies:
  - settle adds a `released` event with amount = +credits_reserved
  - released event uses stripe_payment_id="settle:{job_id}" (idempotency)
  - duplicate settle call raises UniqueViolation → caught, no second release
  - no reservation → released amount is 0 (no-op net effect)
  - settled marker with amount=0 still added for audit trail
"""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_settle_req(actual_seconds=3600.0, hourly_rate_usd=1.0):
    req = MagicMock()
    req.actual_seconds = actual_seconds
    req.hourly_rate_usd = hourly_rate_usd
    req.final_status = "completed"
    req.final_step = 100
    req.checkpoint_count = 5
    req.interruption_count = 0
    req.aws_equivalent_usd = None
    req.gpu_type = "RTX4090"
    return req


def _build_credits_mocks(reserved_amount: int = 100, unique_violation: bool = False):
    """
    Build a mock db that returns a reservation event of -reserved_amount credits.
    If unique_violation=True, add_credit_event raises on the first call.
    """
    mock_db = MagicMock()

    # Reservation lookup: .select("amount_credits").eq(...).limit(1).execute()
    reservation_data = [{"amount_credits": -reserved_amount}] if reserved_amount > 0 else []
    (
        mock_db.table.return_value
        .select.return_value
        .eq.return_value
        .eq.return_value
        .eq.return_value
        .limit.return_value
        .execute.return_value
    ) = MagicMock(data=reservation_data)

    return mock_db


# ── Tests ─────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_settle_releases_reservation():
    """settle_job() must add a `released` event with amount=+credits_reserved."""
    from api import credits as cr

    released_calls = []

    def fake_add_event(**kwargs):
        released_calls.append(kwargs)

    mock_db = _build_credits_mocks(reserved_amount=100)

    with patch("api.credits.TESTING_MODE", False), \
         patch("api.credits.add_credit_event", side_effect=fake_add_event), \
         patch("api.credits.update_job"), \
         patch("api.credits._verify_job_ownership"), \
         patch("api.credits.get_balance", return_value={"available_credits": 800}), \
         patch("api.db.get_db", return_value=mock_db), \
         patch("api.credits._report_gainshare_to_stripe"), \
         patch("api.credits.get_db", return_value=mock_db, create=True):

        user = {"user_id": "u1", "email": "u@test.com"}
        req = _make_settle_req(actual_seconds=3600.0, hourly_rate_usd=1.0)
        await cr.settle_job("job-1", req, user)

    release_events = [c for c in released_calls if c.get("event_type") == "released"]
    assert len(release_events) == 1, f"Expected 1 released event, got {len(release_events)}"
    assert release_events[0]["amount_credits"] == 100, (
        f"Expected +100 credits released, got {release_events[0]['amount_credits']}"
    )


@pytest.mark.asyncio
async def test_settle_released_event_has_idempotency_key():
    """released event must use stripe_payment_id='settle:{job_id}'."""
    from api import credits as cr

    released_calls = []

    def fake_add_event(**kwargs):
        released_calls.append(kwargs)

    mock_db = _build_credits_mocks(reserved_amount=100)

    with patch("api.credits.TESTING_MODE", False), \
         patch("api.credits.add_credit_event", side_effect=fake_add_event), \
         patch("api.credits.update_job"), \
         patch("api.credits._verify_job_ownership"), \
         patch("api.credits.get_balance", return_value={"available_credits": 800}), \
         patch("api.db.get_db", return_value=mock_db), \
         patch("api.credits._report_gainshare_to_stripe"), \
         patch("api.credits.get_db", return_value=mock_db, create=True):

        user = {"user_id": "u1", "email": "u@test.com"}
        req = _make_settle_req()
        await cr.settle_job("job-99", req, user)

    release_event = next(c for c in released_calls if c.get("event_type") == "released")
    assert release_event.get("stripe_payment_id") == "settle:job-99"


@pytest.mark.asyncio
async def test_duplicate_settle_swallows_unique_violation():
    """If released event already exists (UniqueViolation), second settle must not raise."""
    from api import credits as cr

    call_count = {"n": 0}

    def fake_add_event(**kwargs):
        call_count["n"] += 1
        if kwargs.get("event_type") == "released" and call_count["n"] >= 1:
            raise Exception("duplicate key value violates unique constraint")

    mock_db = _build_credits_mocks(reserved_amount=100)

    with patch("api.credits.TESTING_MODE", False), \
         patch("api.credits.add_credit_event", side_effect=fake_add_event), \
         patch("api.credits.update_job"), \
         patch("api.credits._verify_job_ownership"), \
         patch("api.credits.get_balance", return_value={"available_credits": 800}), \
         patch("api.db.get_db", return_value=mock_db), \
         patch("api.credits._report_gainshare_to_stripe"), \
         patch("api.credits.get_db", return_value=mock_db, create=True):

        user = {"user_id": "u1", "email": "u@test.com"}
        req = _make_settle_req()
        # Should not raise
        await cr.settle_job("job-1", req, user)


@pytest.mark.asyncio
async def test_settle_with_no_reservation_releases_zero():
    """If no reservation exists, released event has amount=0 (no balance impact)."""
    from api import credits as cr

    released_calls = []

    def fake_add_event(**kwargs):
        released_calls.append(kwargs)

    mock_db = _build_credits_mocks(reserved_amount=0)  # no reservation

    with patch("api.credits.TESTING_MODE", False), \
         patch("api.credits.add_credit_event", side_effect=fake_add_event), \
         patch("api.credits.update_job"), \
         patch("api.credits._verify_job_ownership"), \
         patch("api.credits.get_balance", return_value={"available_credits": 800}), \
         patch("api.db.get_db", return_value=mock_db), \
         patch("api.credits._report_gainshare_to_stripe"), \
         patch("api.credits.get_db", return_value=mock_db, create=True):

        user = {"user_id": "u1", "email": "u@test.com"}
        req = _make_settle_req()
        await cr.settle_job("job-1", req, user)

    release_events = [c for c in released_calls if c.get("event_type") == "released"]
    assert len(release_events) == 1
    assert release_events[0]["amount_credits"] == 0


@pytest.mark.asyncio
async def test_settle_adds_settled_marker():
    """settle_job() must always add a settled audit-trail event."""
    from api import credits as cr

    all_calls = []

    def fake_add_event(**kwargs):
        all_calls.append(kwargs)

    mock_db = _build_credits_mocks(reserved_amount=100)

    with patch("api.credits.TESTING_MODE", False), \
         patch("api.credits.add_credit_event", side_effect=fake_add_event), \
         patch("api.credits.update_job"), \
         patch("api.credits._verify_job_ownership"), \
         patch("api.credits.get_balance", return_value={"available_credits": 800}), \
         patch("api.db.get_db", return_value=mock_db), \
         patch("api.credits._report_gainshare_to_stripe"), \
         patch("api.credits.get_db", return_value=mock_db, create=True):

        user = {"user_id": "u1", "email": "u@test.com"}
        req = _make_settle_req()
        await cr.settle_job("job-1", req, user)

    settled_events = [c for c in all_calls if c.get("event_type") == "settled"]
    assert len(settled_events) == 1
    assert settled_events[0]["amount_credits"] == 0
