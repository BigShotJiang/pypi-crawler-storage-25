"""Tier-1 tests for issue #71 — R2-backed onstart for large user scripts.

Covers:
  * should_route_via_r2() — size threshold decision
  * upload_script_and_sign() happy path via mocked boto3
  * upload_script_and_sign() gracefully returns None when R2 creds missing
  * upload_script_and_sign() gracefully returns None when put_object raises
  * _sanitize_name() strips path traversal + caps length
  * Startup-script generator prefers VL_SCRIPT_URL over VL_SCRIPT_B64
"""
from __future__ import annotations

import base64
from unittest.mock import MagicMock, patch

import pytest

from shared.script_upload import (
    should_route_via_r2,
    upload_script_and_sign,
    _sanitize_name,
    _content_type_for,
    INLINE_THRESHOLD_BYTES,
)


# ─── should_route_via_r2 ────────────────────────────────────────────────────

def test_small_script_stays_inline():
    tiny = base64.b64encode(b"print('hi')").decode()
    assert should_route_via_r2(tiny) is False


def test_large_script_routes_via_r2():
    # 10 KB > 4 KB threshold
    big = base64.b64encode(b"x" * 10_000).decode()
    assert should_route_via_r2(big) is True


def test_empty_script_stays_inline():
    assert should_route_via_r2("") is False


def test_threshold_is_about_4k():
    just_under = base64.b64encode(b"x" * (INLINE_THRESHOLD_BYTES - 1)).decode()
    just_over  = base64.b64encode(b"x" * (INLINE_THRESHOLD_BYTES + 1)).decode()
    assert should_route_via_r2(just_under) is False
    assert should_route_via_r2(just_over)  is True


# ─── upload_script_and_sign ─────────────────────────────────────────────────

@pytest.fixture
def _r2_env(monkeypatch):
    monkeypatch.setenv("R2_ENDPOINT", "https://r2.test")
    monkeypatch.setenv("R2_ACCESS_KEY_ID", "ak")
    monkeypatch.setenv("R2_SECRET_ACCESS_KEY", "sk")


def test_upload_returns_signed_url_on_success(_r2_env):
    mock_s3 = MagicMock()
    mock_s3.generate_presigned_url.return_value = "https://r2.test/jobs/j1/train.py?sig=x"
    with patch("boto3.client", return_value=mock_s3):
        url = upload_script_and_sign(
            job_id="j1",
            script_b64=base64.b64encode(b"print('hello')").decode(),
            script_name="train.py",
        )
    assert url == "https://r2.test/jobs/j1/train.py?sig=x"
    # put_object was called with the right key
    put_kwargs = mock_s3.put_object.call_args.kwargs
    assert put_kwargs["Key"] == "jobs/j1/train.py"
    assert put_kwargs["Body"] == b"print('hello')"
    assert put_kwargs["ContentType"] == "text/x-python"


def test_upload_returns_none_when_no_creds(monkeypatch):
    for var in ("R2_ENDPOINT", "R2_ACCESS_KEY_ID", "R2_SECRET_ACCESS_KEY",
                "CLOUDFLARE_R2_ENDPOINT", "CLOUDFLARE_R2_ACCESS_KEY_ID",
                "CLOUDFLARE_R2_SECRET_ACCESS_KEY"):
        monkeypatch.delenv(var, raising=False)
    url = upload_script_and_sign(
        job_id="j1",
        script_b64=base64.b64encode(b"hi").decode(),
        script_name="t.py",
    )
    assert url is None


def test_upload_returns_none_on_put_error(_r2_env):
    mock_s3 = MagicMock()
    mock_s3.put_object.side_effect = Exception("R2 503")
    with patch("boto3.client", return_value=mock_s3):
        url = upload_script_and_sign(
            job_id="j1",
            script_b64=base64.b64encode(b"hi").decode(),
            script_name="t.py",
        )
    # upload_script_and_sign itself returns None on failure — the
    # job_worker raises RuntimeError when None is returned for a large
    # script (see test_large_script_upload_failure_raises_in_job_worker).
    assert url is None


def test_upload_auto_creates_missing_bucket(_r2_env):
    """Bucket is pre-probed; when head_bucket 404s, helper creates it then puts.

    Real Railway symptom (2026-04-18): vaultlayer-jobs bucket didn't exist,
    R2 head failed, helper returned None, job_worker fell back to inline
    VL_SCRIPT_B64, AWS UserData busted 16 KB cap.
    """
    from botocore.exceptions import ClientError
    mock_s3 = MagicMock()
    # head_bucket says 404 → create_bucket succeeds → put_object succeeds
    mock_s3.head_bucket.side_effect = ClientError(
        error_response={"Error": {"Code": "404", "Message": "bucket missing"}},
        operation_name="HeadBucket",
    )
    mock_s3.generate_presigned_url.return_value = "https://r2.test/jobs/j1/train.py?sig=x"
    with patch("boto3.client", return_value=mock_s3):
        url = upload_script_and_sign(
            job_id="j1",
            script_b64=base64.b64encode(b"hi").decode(),
            script_name="train.py",
        )
    assert url == "https://r2.test/jobs/j1/train.py?sig=x"
    # Exactly one create_bucket call, one put_object call after bucket exists.
    assert mock_s3.create_bucket.call_count == 1
    assert mock_s3.put_object.call_count == 1


def test_upload_tolerates_bucket_race_on_create(_r2_env):
    """Two concurrent workers both see head_bucket 404 and race on create;
    whoever loses the race gets BucketAlreadyOwnedByYou — treat as success
    and continue the put. Protects multi-worker Railway deploys."""
    from botocore.exceptions import ClientError
    mock_s3 = MagicMock()
    mock_s3.head_bucket.side_effect = ClientError(
        error_response={"Error": {"Code": "NoSuchBucket"}},
        operation_name="HeadBucket",
    )
    mock_s3.create_bucket.side_effect = ClientError(
        error_response={"Error": {"Code": "BucketAlreadyOwnedByYou"}},
        operation_name="CreateBucket",
    )
    mock_s3.generate_presigned_url.return_value = "https://r2.test/j/k?s=1"
    with patch("boto3.client", return_value=mock_s3):
        url = upload_script_and_sign(
            job_id="j1",
            script_b64=base64.b64encode(b"x").decode(),
            script_name="t.py",
        )
    assert url == "https://r2.test/j/k?s=1"
    assert mock_s3.put_object.call_count == 1


def test_upload_skips_create_when_bucket_exists(_r2_env):
    """When head_bucket succeeds, we must NOT call create_bucket — some
    deployments revoke CreateBucket permission after initial bootstrap."""
    mock_s3 = MagicMock()
    mock_s3.head_bucket.return_value = {}  # exists, no raise
    mock_s3.generate_presigned_url.return_value = "https://r2.test/ok"
    with patch("boto3.client", return_value=mock_s3):
        url = upload_script_and_sign(
            job_id="j1",
            script_b64=base64.b64encode(b"x").decode(),
            script_name="t.py",
        )
    assert url == "https://r2.test/ok"
    assert mock_s3.create_bucket.call_count == 0
    assert mock_s3.put_object.call_count == 1


def test_upload_with_empty_script_returns_none(_r2_env):
    assert upload_script_and_sign(job_id="j1", script_b64="", script_name="t.py") is None


def test_upload_passes_ttl_to_presign(_r2_env):
    mock_s3 = MagicMock()
    mock_s3.generate_presigned_url.return_value = "https://x"
    with patch("boto3.client", return_value=mock_s3):
        upload_script_and_sign(
            job_id="j1",
            script_b64=base64.b64encode(b"hi").decode(),
            script_name="t.py",
            ttl_seconds=3600,
        )
    assert mock_s3.generate_presigned_url.call_args.kwargs["ExpiresIn"] == 3600


# ─── Name sanitization ──────────────────────────────────────────────────────

def test_sanitize_strips_path_traversal():
    assert _sanitize_name("../../etc/passwd") == "passwd"
    assert _sanitize_name("/abs/path/x.py")   == "x.py"
    assert _sanitize_name("..\\Windows\\x.sh") == "x.sh"


def test_sanitize_replaces_weird_chars():
    assert _sanitize_name("file with spaces.py") == "file-with-spaces.py"


def test_sanitize_caps_length_preserves_extension():
    long_name = "a" * 200 + ".py"
    safe = _sanitize_name(long_name)
    assert len(safe) <= 128
    assert safe.endswith(".py")


def test_sanitize_empty_fallback():
    assert _sanitize_name("") == "script.py"


def test_content_type_inference():
    assert _content_type_for("train.py")  == "text/x-python"
    assert _content_type_for("setup.sh")  == "text/x-shellscript"
    assert _content_type_for("weights.bin") == "application/octet-stream"


# ─── Startup script selects URL over B64 ────────────────────────────────────

def _stub_broker_and_job():
    from types import SimpleNamespace
    job = SimpleNamespace(
        job_id="j1", name="j1", environment={},
        docker_image="pytorch/pytorch:2.3-cuda12.1-cudnn8-runtime",
        model_params_billion=None, training_mode="full",
        dataset_size_gb=None, dataset_location="", dataset_region="",
    )
    broker = MagicMock()
    broker.config = SimpleNamespace(
        cloudflare=SimpleNamespace(
            r2_bucket="b", r2_access_key_id="k", r2_secret_access_key="s",
            r2_endpoint="https://r2.test",
        ),
        redis=SimpleNamespace(url="redis://t"),
    )
    broker._get_managed_credentials = MagicMock(return_value=None)
    return broker, job


def test_vm_startup_script_handles_VL_SCRIPT_URL():
    from agents.broker.startup_scripts import build_vm_startup_script
    broker, job = _stub_broker_and_job()
    out = build_vm_startup_script(broker, job)
    # New branch: curl from signed URL when VL_SCRIPT_URL is set
    assert '${VL_SCRIPT_URL:-}' in out, "VM startup must check VL_SCRIPT_URL"
    assert 'curl -fsSL "${VL_SCRIPT_URL}"' in out, \
        "VM startup must curl from VL_SCRIPT_URL"
    # Legacy branch still present for small scripts
    assert '${VL_SCRIPT_B64:-}' in out, "VM startup must keep VL_SCRIPT_B64 fallback"


def test_container_onstart_handles_VL_SCRIPT_URL():
    from agents.broker.startup_scripts import build_container_onstart
    broker, job = _stub_broker_and_job()
    out = build_container_onstart(broker, job)
    assert '${VL_SCRIPT_URL:-}' in out
    assert 'curl -fsSL "${VL_SCRIPT_URL}"' in out
    assert '${VL_SCRIPT_B64:-}' in out  # fallback still wired


# ─── Auto-start guard: fire on EITHER URL or B64 path ──────────────────────

def test_vm_autostart_fires_on_url_only():
    """Bug caught 2026-04-18: the auto-start trigger checked VL_SCRIPT_B64
    alone, so the R2 URL path fetched the script but never executed it."""
    from agents.broker.startup_scripts import build_vm_startup_script
    broker, job = _stub_broker_and_job()
    out = build_vm_startup_script(broker, job)
    # The auto-start guard must accept VL_SCRIPT_URL, not only VL_SCRIPT_B64.
    # Otherwise the R2 path materializes the script then exits without running it.
    assert '[ -n "${VL_SCRIPT_URL:-}" ]' in out, \
        "VM autostart guard must check VL_SCRIPT_URL"
    # And must still accept B64 for the small-script path.
    assert '[ -n "${VL_SCRIPT_B64:-}" ]' in out


def test_container_autostart_fires_on_url_only():
    from agents.broker.startup_scripts import build_container_onstart
    broker, job = _stub_broker_and_job()
    out = build_container_onstart(broker, job)
    assert '[ -n "${VL_SCRIPT_URL:-}" ]' in out, \
        "container autostart guard must check VL_SCRIPT_URL"
    assert '[ -n "${VL_SCRIPT_B64:-}" ]' in out


# ─── job_worker fail-fast on R2 upload failure for large scripts (issue #139) ─

def test_large_script_upload_failure_does_not_set_vl_script_b64():
    """When a script needs R2 routing and upload fails, job_worker must
    NOT silently fall back to inline VL_SCRIPT_B64 — that re-enters the
    exact payload limits the R2 path was meant to bypass.

    The worker now raises RuntimeError, which surfaces immediately as a
    job failure rather than a late opaque provider error.
    """
    big_b64 = base64.b64encode(b"x" * 10_000).decode()  # > INLINE_THRESHOLD_BYTES
    assert should_route_via_r2(big_b64), "precondition: big script needs R2 routing"

    env: dict = {}
    with patch("shared.script_upload.upload_script_and_sign", return_value=None):
        with pytest.raises(RuntimeError, match="R2 upload failed"):
            # Simulate the job_worker code path directly
            from shared.script_upload import should_route_via_r2 as _r2, upload_script_and_sign as _upload
            if _r2(big_b64):
                url = _upload(job_id="j1", script_b64=big_b64, script_name="train.py")
                if url:
                    env["VL_SCRIPT_URL"] = url
                else:
                    from shared import script_upload as _su
                    _reason = _su.LAST_UPLOAD_ERROR or "unknown"
                    raise RuntimeError(
                        f"Script exceeds inline size limit and R2 upload failed "
                        f"({_reason}). Check R2_ENDPOINT / R2_ACCESS_KEY_ID / "
                        f"R2_SECRET_ACCESS_KEY config and retry."
                    )

    # VL_SCRIPT_B64 must NOT have been set as a fallback
    assert "VL_SCRIPT_B64" not in env
