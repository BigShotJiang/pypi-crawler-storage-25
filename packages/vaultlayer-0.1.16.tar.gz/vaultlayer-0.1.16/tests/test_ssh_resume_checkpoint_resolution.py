"""Tests for issue #142: SSH resume must export resolved checkpoint path, not root dir.

_restart_job_on_node() used to export VAULTLAYER_RESUME_CHECKPOINT pointing at
the job-level checkpoint root (e.g. $VL_DATA_ROOT/vl-checkpoints/<job_id>).
torch.load() receives a directory and fails; HF Trainer misses the concrete
checkpoint-<N>/ subdir.

Fix: inject bash logic that walks the root dir, finds the latest checkpoint-<N>/
or step-<N>/ subdir (mirroring startup_scripts.py format detection), and exports
the resolved concrete path.
"""
import inspect
import pytest


def _get_restart_source():
    from agents.broker.ssh import restart_job_on_node
    return inspect.getsource(restart_job_on_node)


def test_hf_checkpoint_resolution_present():
    """The restart command must try to resolve checkpoint-N/ (HF format)."""
    src = _get_restart_source()
    assert "checkpoint-[0-9]" in src or "checkpoint-$" in src or "checkpoint-" in src, (
        "SSH restart must resolve HF-style checkpoint-N/ directories"
    )


def test_raw_step_checkpoint_resolution_present():
    """The restart command must try to resolve step-N/ (raw format)."""
    src = _get_restart_source()
    assert "step-[0-9]" in src or "step-$" in src or "step-" in src, (
        "SSH restart must resolve raw step-N/ checkpoint directories"
    )


def test_resolved_variable_used_for_export():
    """VAULTLAYER_RESUME_CHECKPOINT must be set from the resolved variable, not raw root."""
    src = _get_restart_source()

    # The export line should reference a resolved variable, not the raw root directly
    # (before the fix it was: export VAULTLAYER_RESUME_CHECKPOINT={resume_checkpoint})
    assert "_VL_RESOLVED_CKPT" in src or "_VL_LATEST" in src, (
        "A resolution variable must be introduced before the VAULTLAYER_RESUME_CHECKPOINT export"
    )


def test_fallback_to_root_when_no_subdir():
    """If no checkpoint-N/ or step-N/ found, fall back to the root dir."""
    src = _get_restart_source()
    # The fallback line should assign the root when no subdir is found
    assert "_VL_RESOLVED_CKPT" in src, "Resolution variable _VL_RESOLVED_CKPT must exist"
    # Fallback: when latest is empty, use ckpt_root
    assert "_VL_CKPT_ROOT" in src, "Checkpoint root variable _VL_CKPT_ROOT must be set"


def test_both_env_vars_exported():
    """Both VAULTLAYER_RESUME_CHECKPOINT and RESUME_FROM_CHECKPOINT must be exported."""
    src = _get_restart_source()
    assert "VAULTLAYER_RESUME_CHECKPOINT" in src
    assert "RESUME_FROM_CHECKPOINT" in src


def test_resolution_uses_sort_to_pick_latest():
    """The bash snippet must sort numerically to pick the highest checkpoint step."""
    src = _get_restart_source()
    assert "sort" in src and ("-k2,2n" in src or "sort -t" in src), (
        "Checkpoint directory resolution must use numeric sort to pick the latest step"
    )


def test_resolution_sorts_checkpoint_basename_not_full_path():
    """Root paths contain hyphens, so sorting must happen after basename extraction."""
    src = _get_restart_source()
    assert "awk -F/ '{print $NF}'" in src, (
        "Checkpoint sorting must extract the basename before sort -t-; "
        "the root path may contain hyphens such as vl-checkpoints"
    )
