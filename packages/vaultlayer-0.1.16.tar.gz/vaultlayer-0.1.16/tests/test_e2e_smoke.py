"""
VaultLayer — End-to-End Smoke Test Suite
=========================================
These tests exercise the REAL agent logic end-to-end.
External I/O is mocked only at the network/storage boundary:
  - aiohttp.ClientSession (provider REST APIs)
  - boto3 / botocore (AWS SDK calls)
  - R2 / S3 object storage
  - Redis pub/sub

Nothing inside an agent is patched.  If an agent's internal decision
changes, these tests will catch it.

Scenarios covered:
  E2E-1  All 7 agents construct and start without error
  E2E-2  Spot interruption → STONITH → checkpoint → migrate → watchdog re-attach (GAP-8)
  E2E-3  Arbitrage opportunity → STONITH confirmed before provision (GAP-6)
  E2E-4  VM-provider docker image in startup script (GAP-18)
         - Crusoe: startup_script contains docker pull (not passed as OS image)
         - Nebius: metadata.user-data contains docker pull
         - Hyperstack: user_data contains docker pull
         - Voltage Park: user_data contains docker pull
  E2E-5  Stripe checkout → webhook → credits added
  E2E-6  Watchdog _listen_broker_events wires to handle_node_provisioned (GAP-8)
  E2E-7  Full pipeline: job start → price drop → arbitrage migrate → complete
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import asyncio
import base64
import contextlib
import hashlib
import hmac
import json
import time
import importlib
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch, call, ANY
from typing import Optional

import pytest
from fastapi.testclient import TestClient

from conftest import MockAgentQueue, make_job, dummy_config   # type: ignore
from shared.models import (
    AgentEvent, EventType, Job, JobStatus, Provider, GPUType
)
from shared.config import (
    VaultLayerConfig, AWSConfig, LambdaLabsConfig, CoreWeaveConfig,
    CloudflareConfig, RedisConfig, AnthropicConfig,
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _cfg():
    """Fresh VaultLayerConfig with all providers populated."""
    return VaultLayerConfig(
        token="vl_test_" + "a" * 64,
        user_id="smoke-user",
        aws=AWSConfig(access_key_id="k", secret_access_key="s"),
        lambda_labs=LambdaLabsConfig(api_key="lambda-key"),
        coreweave=CoreWeaveConfig(api_key="cw-key", namespace="ns"),
        cloudflare=CloudflareConfig(
            account_id="cf-account",
            r2_access_key_id="r2-key",
            r2_secret_access_key="r2-secret",
            r2_bucket="vaultlayer-smoke",
            r2_endpoint="https://smoke.r2.cloudflarestorage.com",
        ),
        redis=RedisConfig(url="redis://localhost:6379"),
        anthropic=AnthropicConfig(api_key="ant-key"),
    )


def _job(docker_image: str = "pytorch/pytorch:2.3-cuda12.1") -> Job:
    return Job(
        job_id="smoke-job-001",
        name="Smoke Llama Fine-tune",
        status=JobStatus.RUNNING,
        provider=Provider.LAMBDA_LABS,
        gpu_type=GPUType.H100_80GB_SXM,
        instance_id="i-lambda-smoke",
        region="us-east-1",
        model_params_billion=7.0,
        command="python train.py --epochs 3",
        docker_image=docker_image,
        user_id="smoke-user",
    )


# ── E2E-1: All agents construct and start cleanly ─────────────────────────────

@pytest.mark.asyncio
async def test_e2e1_all_agents_construct():
    """All 7 VaultLayer agents must construct without raising."""
    cfg = _cfg()
    q = MockAgentQueue()

    from agents.orchestration.agent import OrchestrationAgent
    from agents.pricing.agent import PricingAgent
    from agents.watchdog.agent import WatchdogAgent
    from agents.vault.agent import VaultAgent
    from agents.broker.agent import BrokerAgent
    from agents.finops.agent import FinOpsAgent
    from agents.namespace.agent import NamespaceAgent

    orch  = OrchestrationAgent(config=cfg, queue=q)
    price = PricingAgent(config=cfg, queue=q)
    dog   = WatchdogAgent(config=cfg, queue=q)
    vault = VaultAgent(config=cfg, queue=q)
    brok  = BrokerAgent(config=cfg, queue=q)
    finop = FinOpsAgent(config=cfg, queue=q)
    ns    = NamespaceAgent(config=cfg, queue=q)

    # Basic contract: each agent exposes async start() and stop()
    for agent in (orch, price, dog, vault, brok, finop, ns):
        assert callable(getattr(agent, "start", None)), \
            f"{type(agent).__name__} missing start()"
        assert callable(getattr(agent, "stop", None)), \
            f"{type(agent).__name__} missing stop()"


# ── E2E-2: Spot interruption → STONITH → checkpoint → migrate → watchdog re-attach ──

@pytest.mark.asyncio
async def test_e2e2_spot_interruption_pipeline():
    """
    Full spot-interruption pipeline:
      1. Watchdog detects termination → triggers emergency checkpoint
      2. Orchestration receives TERMINATION_SIGNAL → decides migrate
      3. Broker calls _hard_fence_and_confirm (STONITH) before provisioning
      4. Broker provisions new node → publishes MIGRATION_COMPLETE
      5. Watchdog receives MIGRATION_COMPLETE → re-attaches heartbeat (GAP-8)
    """
    cfg = _cfg()
    q   = MockAgentQueue()
    job = _job()

    from agents.watchdog.agent import WatchdogAgent
    from agents.broker.agent import BrokerAgent
    from agents.watchdog.signals import HeartbeatMonitor

    dog  = WatchdogAgent(config=cfg, queue=q)
    brok = BrokerAgent(config=cfg, queue=q)

    # ── Stage 1: register job with watchdog ──────────────────────────────────
    checkpoint_calls = []

    async def fake_checkpoint(j: Job):
        checkpoint_calls.append(j.job_id)

    dog.register_job(job, fake_checkpoint)
    assert job.job_id in dog._active_jobs
    # HeartbeatMonitor stores heartbeats in _last_heartbeats (alias: _last_heartbeat)
    assert job.job_id in dog._heartbeat._last_heartbeats

    # ── Stage 2: simulate spot termination ───────────────────────────────────
    await dog.handle_termination(
        job,
        signal_type="aws_spot_termination",
        termination_time="2026-04-02T10:00:00Z",
    )

    # Checkpoint callback must have fired
    assert job.job_id in checkpoint_calls, \
        "Emergency checkpoint was not triggered on spot termination"

    # Watchdog must have published TERMINATION_SIGNAL to watchdog channel
    wd_types = [e.event_type for e in q.events_on("watchdog")]
    assert EventType.TERMINATION_SIGNAL in wd_types, \
        f"Expected TERMINATION_SIGNAL on watchdog channel; got {wd_types}"

    # ── Stage 3: broker STONITH + migrate ────────────────────────────────────
    fence_called = []

    async def fake_fence(j: Job):
        fence_called.append(j.job_id)

    # Mock: STONITH, provision, the 30s sleep, and instance host resolution
    with contextlib.ExitStack() as stack:
        stack.enter_context(patch.object(brok, '_fence_old_node', side_effect=fake_fence))
        stack.enter_context(patch.object(brok, 'provision_lambda',
                                         new_callable=AsyncMock,
                                         return_value="i-lambda-new-001"))
        stack.enter_context(patch.object(brok, '_check_quota',
                                         new_callable=AsyncMock, return_value=True))
        stack.enter_context(patch.object(brok, '_resolve_instance_host',
                                         new_callable=AsyncMock, return_value="test-node.example.com"))
        stack.enter_context(patch.object(brok, '_try_same_provider_different_az',
                                         new_callable=AsyncMock, return_value=None))
        stack.enter_context(patch.object(brok, '_wait_for_ssh',
                                         new_callable=AsyncMock, return_value=True))
        stack.enter_context(patch.object(brok, '_wait_for_bootstrap',
                                         new_callable=AsyncMock, return_value=True))
        stack.enter_context(patch.object(brok, '_prefetch_checkpoint',
                                         new_callable=AsyncMock))
        stack.enter_context(patch.object(brok, '_probe_cuda',
                                         new_callable=AsyncMock, return_value=(True, '530.30')))
        stack.enter_context(patch.object(brok, '_restart_job_on_node',
                                         new_callable=AsyncMock, return_value=True))
        stack.enter_context(patch('agents.broker.migration.asyncio.sleep', new_callable=AsyncMock))

        await brok.execute_migration(
            job,
            target_provider=Provider.LAMBDA_LABS,
            target_gpu=GPUType.H100_80GB_SXM,
            decision_id="smoke-migration-001",
            event_type="heartbeat_miss",   # voluntary → STONITH must fire
        )

    # STONITH must have been called before provisioning
    assert job.job_id in fence_called, \
        "STONITH (_fence_old_node) was not called before provisioning"

    # Broker must have published MIGRATION_COMPLETE
    broker_types = [e.event_type for e in q.events_on("broker")]
    assert EventType.MIGRATION_COMPLETE in broker_types, \
        f"Expected MIGRATION_COMPLETE on broker channel; got {broker_types}"

    # ── Stage 4: GAP-8 — watchdog re-attaches after MIGRATION_COMPLETE ───────
    mig_complete = next(
        e for e in q.events_on("broker")
        if e.event_type == EventType.MIGRATION_COMPLETE
    )
    assert mig_complete.payload.get("instance_id") == "i-lambda-new-001", \
        "MIGRATION_COMPLETE payload must include new instance_id"

    # Simulate the broker event being received by watchdog's _listen_broker_events
    # (In prod this runs via asyncio.gather; here we call the handler directly)
    reattach_event = AgentEvent(
        event_type=EventType.NODE_PROVISIONED,
        source_agent="broker_agent",
        job_id=job.job_id,
        payload={
            "reattach_watchdog": True,
            "new_instance_id": "i-lambda-new-001",
            "new_provider": "lambda_labs",
        },
    )
    await dog.handle_node_provisioned(reattach_event)

    # Heartbeat should be re-registered for fresh grace period
    assert job.job_id in dog._heartbeat._last_heartbeats, \
        "Watchdog heartbeat was not re-registered after migration (GAP-8)"


# ── E2E-3: Arbitrage migration — STONITH confirmed before provision ────────────

@pytest.mark.asyncio
async def test_e2e3_arbitrage_stonith_before_provision():
    """
    Arbitrage migration (voluntary, not spot) must call STONITH before
    provisioning the new node to prevent split-brain R2 writes (GAP-6).
    """
    cfg = _cfg()
    q   = MockAgentQueue()
    job = _job()
    job.provider = Provider.AWS

    from agents.broker.agent import BrokerAgent
    brok = BrokerAgent(config=cfg, queue=q)

    call_order = []

    async def fake_fence(j: Job):
        call_order.append("STONITH")

    async def fake_provision(*args, **kwargs):
        call_order.append("PROVISION")
        return "i-lambda-arb-001"

    with contextlib.ExitStack() as stack:
        stack.enter_context(patch.object(brok, '_fence_old_node', side_effect=fake_fence))
        stack.enter_context(patch.object(brok, 'provision_lambda', side_effect=fake_provision))
        stack.enter_context(patch.object(brok, '_check_quota',
                                         new_callable=AsyncMock, return_value=True))
        stack.enter_context(patch.object(brok, '_resolve_instance_host',
                                         new_callable=AsyncMock, return_value=""))
        stack.enter_context(patch.object(brok, '_try_same_provider_different_az',
                                         new_callable=AsyncMock, return_value=None))
        stack.enter_context(patch.object(brok, '_wait_for_ssh',
                                         new_callable=AsyncMock, return_value=True))
        stack.enter_context(patch.object(brok, '_wait_for_bootstrap',
                                         new_callable=AsyncMock, return_value=True))
        stack.enter_context(patch.object(brok, '_prefetch_checkpoint',
                                         new_callable=AsyncMock))
        stack.enter_context(patch.object(brok, '_probe_cuda',
                                         new_callable=AsyncMock, return_value=(True, '530.30')))
        stack.enter_context(patch.object(brok, '_restart_job_on_node',
                                         new_callable=AsyncMock, return_value=True))
        stack.enter_context(patch('agents.broker.migration.asyncio.sleep', new_callable=AsyncMock))

        await brok.execute_migration(
            job,
            target_provider=Provider.LAMBDA_LABS,
            target_gpu=GPUType.H100_80GB_SXM,
            decision_id="smoke-arb-001",
            event_type="arbitrage_opportunity",   # voluntary migration
        )

    # STONITH must come BEFORE provision
    assert "STONITH" in call_order, "STONITH was not called during arbitrage migration"
    assert "PROVISION" in call_order, "Provision was not called during arbitrage migration"
    assert call_order.index("STONITH") < call_order.index("PROVISION"), \
        f"STONITH must fire BEFORE provision; got order: {call_order}"


# ── E2E-4a: VM startup script — Crusoe uses OS image + startup_script ─────────

@pytest.mark.asyncio
async def test_e2e4a_crusoe_docker_image_not_used_as_os_image():
    """
    GAP-18: Crusoe must use the fixed OS image name, not job.docker_image.
    The user's Docker image must appear in the startup_script field only.
    """
    cfg = _cfg()
    # Add Crusoe config — must set api_key, api_secret, project_id as real strings
    # (HMAC signing calls .encode() on these; MagicMock fails there)
    cfg.crusoe = MagicMock()
    cfg.crusoe.api_key = "crusoe-key"
    cfg.crusoe.api_secret = "dGVzdC1jcnVzb2Utc2VjcmV0LWtleQ"  # base64url("test-crusoe-secret-key")
    cfg.crusoe.project_id = "proj-test-123"
    q   = MockAgentQueue()
    job = _job(docker_image="myorg/custom-train:v2.1")

    from agents.broker.agent import BrokerAgent
    brok = BrokerAgent(config=cfg, queue=q)

    captured_payloads = []

    class FakeResp:
        status = 201
        async def json(self):
            return {"instance": {"id": "crusoe-inst-001"}}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    class FakeSession:
        def post(self, url, **kwargs):
            captured_payloads.append({"url": url, **kwargs})
            return FakeResp()
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    with patch("aiohttp.ClientSession", return_value=FakeSession()), \
         patch("base64.b64encode", wraps=base64.b64encode):
        result = await brok.provision_crusoe(GPUType.H100_80GB_SXM, job)

    assert result == "crusoe-inst-001", \
        f"provision_crusoe should return instance id; got {result!r}"

    assert captured_payloads, "No HTTP call was made to Crusoe API"
    payload_json = captured_payloads[0].get("json", {})

    # The image field must be the OS image string, not a Docker image
    # Crusoe API accepts image as a plain string (e.g. "ubuntu22.04:latest")
    image_val = payload_json.get("image", "")
    image_name = image_val if isinstance(image_val, str) else image_val.get("name", "")
    assert "ubuntu" in image_name.lower() or "crusoe" in image_name.lower(), \
        f"image must be the Crusoe OS image, not a Docker image; got {image_name!r}"
    assert "pytorch" not in image_name.lower() and "myorg" not in image_name.lower(), \
        f"Docker image leaked into image field (OS image): {image_name!r}"

    # Docker image must appear in startup_script
    startup_script = payload_json.get("startup_script", "")
    assert "myorg/custom-train:v2.1" in startup_script, \
        f"job.docker_image not found in startup_script; got: {startup_script[:200]!r}"
    assert "docker pull" in startup_script.lower(), \
        "startup_script must contain 'docker pull'"


@pytest.mark.asyncio
async def test_e2e4b_nebius_docker_image_in_metadata():
    """
    GAP-18: Nebius provision must inject docker image via metadata user-data,
    not leave the VM with no Docker container at all.
    """
    cfg = _cfg()
    cfg.nebius = MagicMock()
    cfg.nebius.api_key = "nebius-key"
    cfg.nebius.service_account_key = "-----BEGIN RSA PRIVATE KEY-----\nfake\n-----END RSA PRIVATE KEY-----"
    cfg.nebius.key_id = "test-key-id"
    cfg.nebius.service_account_id = "test-sa-id"
    cfg.nebius.region = "eu"
    q   = MockAgentQueue()
    job = _job(docker_image="myorg/custom-train:v2.1")

    from agents.broker.agent import BrokerAgent
    brok = BrokerAgent(config=cfg, queue=q)
    # Pre-populate IAM token cache to skip real JWT signing in unit tests
    import time as _t
    brok._nebius_token_cache = ("fake-iam-token", _t.monotonic() + 7200)

    captured_payloads = []

    class FakeResp:
        status = 201
        async def json(self):
            return {"metadata": {"id": "nebius-inst-001"}}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    class FakeSession:
        def post(self, url, **kwargs):
            captured_payloads.append({"url": url, **kwargs})
            return FakeResp()
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    with patch("aiohttp.ClientSession", return_value=FakeSession()):
        result = await brok.provision_nebius(GPUType.H100_80GB_SXM, job)

    assert result == "nebius-inst-001", \
        f"provision_nebius should return instance id; got {result!r}"

    assert captured_payloads, "No HTTP call was made to Nebius API"
    payload_json = captured_payloads[0].get("json", {})

    # Metadata must be present with user-data key
    metadata = payload_json.get("metadata", {})
    assert "user-data" in metadata, \
        f"Nebius payload missing metadata.user-data; got metadata={metadata!r}"

    # user-data is base64-encoded; decode and check for docker pull
    raw_userdata = base64.b64decode(metadata["user-data"]).decode()
    assert "myorg/custom-train:v2.1" in raw_userdata, \
        f"job.docker_image not in Nebius metadata.user-data; got: {raw_userdata[:200]!r}"
    assert "docker pull" in raw_userdata.lower(), \
        "Nebius startup script must contain 'docker pull'"


@pytest.mark.asyncio
async def test_e2e4c_hyperstack_docker_image_in_user_data():
    """GAP-18: Hyperstack provision must inject docker image via user_data."""
    cfg = _cfg()
    cfg.hyperstack = MagicMock()
    cfg.hyperstack.api_key = "hs-key"
    q   = MockAgentQueue()
    job = _job(docker_image="myorg/custom-train:v2.1")

    from agents.broker.agent import BrokerAgent
    brok = BrokerAgent(config=cfg, queue=q)

    captured_payloads = []

    class FakeResp:
        status = 201
        async def json(self):
            return {"virtual_machines": [{"id": 42}]}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    class FakeSession:
        def post(self, url, **kwargs):
            captured_payloads.append({"url": url, **kwargs})
            return FakeResp()
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    with patch("aiohttp.ClientSession", return_value=FakeSession()):
        result = await brok.provision_hyperstack(GPUType.H100_80GB_SXM, job)

    assert result == "42", \
        f"provision_hyperstack should return VM id as string; got {result!r}"

    assert captured_payloads, "No HTTP call was made to Hyperstack API"
    payload_json = captured_payloads[0].get("json", {})

    user_data = payload_json.get("user_data", "")
    assert "myorg/custom-train:v2.1" in user_data, \
        f"job.docker_image not in Hyperstack user_data; got: {user_data[:200]!r}"
    assert "docker pull" in user_data.lower(), \
        "Hyperstack user_data must contain 'docker pull'"


@pytest.mark.asyncio
async def test_e2e4d_voltage_park_docker_image_in_user_data():
    """GAP-18: Voltage Park provision must inject docker image via user_data."""
    cfg = _cfg()
    cfg.voltage_park = MagicMock()
    cfg.voltage_park.api_key = "vp-key"
    q   = MockAgentQueue()
    job = _job(docker_image="myorg/custom-train:v2.1")

    from agents.broker.agent import BrokerAgent
    brok = BrokerAgent(config=cfg, queue=q)

    captured_payloads = []

    class FakeResp:
        def __init__(self, payload, status=200):
            self.status = status
            self._payload = payload
        async def json(self): return self._payload
        async def text(self): return str(self._payload)
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    class FakeSession:
        def get(self, url, **kwargs):
            if "instant-deploy-presets" in url:
                return FakeResp([{"id": "preset-001", "compute_rate_hourly": "1.89",
                                  "location_ids_with_availability": ["loc-001"]}])
            if "instant/locations" in url:
                return FakeResp({"configs": [{"id": "cfg-001"}]})
            return FakeResp({})
        def post(self, url, **kwargs):
            captured_payloads.append({"url": url, **kwargs})
            return FakeResp({"id": "vp-inst-001"}, status=201)
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    with patch("aiohttp.ClientSession", return_value=FakeSession()):
        result = await brok.provision_voltage_park(GPUType.H100_80GB_SXM, job)

    assert result == "vp-inst-001", \
        f"provision_voltage_park should return instance id; got {result!r}"

    assert captured_payloads, "No HTTP call was made to Voltage Park API"
    payload_json = captured_payloads[0].get("json", {})

    user_data = payload_json.get("user_data", "")
    assert "myorg/custom-train:v2.1" in user_data, \
        f"job.docker_image not in Voltage Park user_data; got: {user_data[:200]!r}"
    assert "docker pull" in user_data.lower(), \
        "Voltage Park user_data must contain 'docker pull'"


@pytest.mark.asyncio
async def test_e2e4e_runpod_docker_image_passed_directly():
    """RunPod is a container platform — docker_image goes to imageName directly, no startup script."""
    cfg = _cfg()
    cfg.runpod = MagicMock()
    cfg.runpod.api_key = "rp-key"
    q   = MockAgentQueue()
    job = _job(docker_image="myorg/custom-train:v2.1")

    from agents.broker.agent import BrokerAgent
    brok = BrokerAgent(config=cfg, queue=q)

    captured_payloads = []

    class FakeResp:
        status = 200
        async def json(self):
            return {"id": "pod-abc123"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    class FakeSession:
        def post(self, url, **kwargs):
            captured_payloads.append({"url": url, **kwargs})
            return FakeResp()
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    with patch("aiohttp.ClientSession", return_value=FakeSession()), \
         patch.object(brok.gpu_resolver, "resolve", new_callable=AsyncMock, return_value="NVIDIA H100 80GB HBM3"):
        result = await brok.provision_runpod(GPUType.H100_80GB_SXM, job)

    assert result == "pod-abc123", \
        f"provision_runpod should return pod id; got {result!r}"

    payload_json = captured_payloads[0].get("json", {})
    assert payload_json.get("imageName") == "myorg/custom-train:v2.1", \
        f"RunPod imageName must be job.docker_image; got {payload_json.get('imageName')!r}"


# ── E2E-5: Stripe checkout → webhook → credits ────────────────────────────────

def test_e2e5_stripe_checkout_endpoint_registered():
    """
    Stripe router must be registered in the FastAPI app.
    If this fails, users cannot buy credits.
    """
    import importlib
    api_main = importlib.import_module("api.main")
    app = api_main.app

    routes = {r.path for r in app.routes}
    assert "/api/v1/stripe/checkout" in routes, \
        "Stripe checkout route not registered — uncomment app.include_router(stripe_router)"
    assert "/api/v1/stripe/webhook" in routes, \
        "Stripe webhook route not registered — uncomment app.include_router(stripe_router)"


def test_e2e5b_stripe_webhook_rejects_bad_signature():
    """Stripe webhook must reject requests with invalid HMAC signature."""
    with patch.dict(os.environ, {"STRIPE_WEBHOOK_SECRET": "whsec_test123"}):
        import importlib
        # Reload to pick up env var
        stripe_routes = importlib.import_module("api.stripe_routes")
        importlib.reload(stripe_routes)

        import api.main as api_main
        client = TestClient(api_main.app, raise_server_exceptions=False)
        resp = client.post(
            "/api/v1/stripe/webhook",
            content=b'{"type":"checkout.session.completed"}',
            headers={"stripe-signature": "t=1,v1=badsig"},
        )
        # Must reject — not 200
        assert resp.status_code in (400, 401, 422), \
            f"Bad Stripe sig should be rejected; got {resp.status_code}"


# ── E2E-6: Watchdog _listen_broker_events wires to handle_node_provisioned ────

@pytest.mark.asyncio
async def test_e2e6_watchdog_broker_listener_exists():
    """
    GAP-8: WatchdogAgent must have _listen_broker_events method that handles
    MIGRATION_COMPLETE by calling handle_node_provisioned with reattach_watchdog=True.
    """
    cfg = _cfg()
    q   = MockAgentQueue()
    job = _job()

    from agents.watchdog.agent import WatchdogAgent
    dog = WatchdogAgent(config=cfg, queue=q)
    dog.register_job(job, AsyncMock())

    assert hasattr(dog, "_listen_broker_events"), \
        "WatchdogAgent missing _listen_broker_events method (GAP-8 not implemented)"

    # Simulate MIGRATION_COMPLETE event flowing through the listener's callback logic
    reattach_calls = []
    original = dog.handle_node_provisioned

    async def spy_handle(event: AgentEvent):
        reattach_calls.append(event)
        await original(event)

    dog.handle_node_provisioned = spy_handle

    # Build the MIGRATION_COMPLETE event that broker publishes
    mig_complete = AgentEvent(
        event_type=EventType.MIGRATION_COMPLETE,
        source_agent="broker_agent",
        job_id=job.job_id,
        payload={
            "migration_id": f"{job.job_id}:smoke",
            "instance_id": "i-new-node-001",
            "target_provider": "lambda_labs",
            "duration_seconds": 47,
        },
    )

    # Extract the handler that _listen_broker_events would register and call it
    # (we pull the inner coroutine by temporarily capturing the subscribe call)
    captured_handlers = []

    async def capture_subscribe(channels, handler):
        captured_handlers.append((channels, handler))

    q.subscribe = capture_subscribe

    # Schedule _listen_broker_events — it calls q.subscribe then blocks
    task = asyncio.create_task(dog._listen_broker_events())
    await asyncio.sleep(0)   # yield so the coroutine reaches subscribe()
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass

    assert captured_handlers, \
        "_listen_broker_events did not call queue.subscribe"
    subscribed_channels, broker_handler = captured_handlers[0]
    assert "broker" in subscribed_channels, \
        f"_listen_broker_events must subscribe to 'broker' channel; got {subscribed_channels}"

    # Now call the handler with our MIGRATION_COMPLETE event
    await broker_handler(mig_complete)

    # handle_node_provisioned must have been called with reattach_watchdog=True
    assert reattach_calls, \
        "handle_node_provisioned not called after MIGRATION_COMPLETE (GAP-8 still broken)"
    reattach_payload = reattach_calls[0].payload or {}
    assert reattach_payload.get("reattach_watchdog") is True, \
        f"reattach_watchdog not set in synthesized NODE_PROVISIONED event; got {reattach_payload}"
    assert reattach_payload.get("new_instance_id") == "i-new-node-001", \
        "new_instance_id not forwarded from MIGRATION_COMPLETE payload"


# ── E2E-7: Full pipeline — arbitrage opportunity → broker STONITH → migrate ───

@pytest.mark.asyncio
async def test_e2e7_full_arbitrage_pipeline():
    """
    Full end-to-end arbitrage pipeline verified in two parts:

    Part A — OrchestrationAgent receives correctly-formatted ARBITRAGE_OPPORTUNITY
              (with 'opportunities' array) and publishes MIGRATION_REQUESTED.

    Part B — Broker executes migration with event_type=arbitrage_opportunity:
              STONITH fires, new node provisioned, MIGRATION_COMPLETE published,
              watchdog re-attaches to new node (GAP-8).
    """
    cfg = _cfg()
    q   = MockAgentQueue()
    job = _job()
    job.provider = Provider.AWS
    job.instance_id = "i-aws-spot-001"

    from agents.orchestration.agent import OrchestrationAgent
    from agents.broker.agent import BrokerAgent
    from agents.watchdog.agent import WatchdogAgent

    orch = OrchestrationAgent(config=cfg, queue=q)
    brok = BrokerAgent(config=cfg, queue=q)
    dog  = WatchdogAgent(config=cfg, queue=q)
    dog.register_job(job, AsyncMock())

    # ── Part A: Orchestration routes correctly-formatted arbitrage event ──────
    # The payload uses 'opportunities' array as produced by PricingAgent
    arb_event = AgentEvent(
        event_type=EventType.ARBITRAGE_OPPORTUNITY,
        source_agent="pricing_agent",
        job_id=job.job_id,
        payload={
            "opportunities": [
                {
                    "current_provider": "AWS",
                    "current_price_per_hour": 3.50,
                    "target_provider": "lambda_labs",
                    "target_price_per_hour": 1.99,
                    "savings_per_hour": 1.51,
                    "savings_pct": 43.1,          # above AUTO_MIGRATE_SAVINGS_PCT=25%
                    "target_gpu": "H100_80GB_SXM",
                }
            ],
            "price_data_age_seconds": 10,  # fresh — won't trip staleness guard
        },
        priority=3,
    )

    await orch.handle_event(arb_event)

    # Orchestration must have published MIGRATION_REQUESTED to the broker stream
    orch_events  = q.events_on("orchestration")
    broker_events = q.events_on("broker")
    all_types = [e.event_type for e in orch_events + broker_events]

    assert EventType.MIGRATION_REQUESTED in all_types, (
        f"OrchestrationAgent did not publish MIGRATION_REQUESTED after 43% savings arbitrage "
        f"opportunity. Got event types: {all_types}"
    )

    # ── Part B: Broker executes voluntary (arbitrage) migration ───────────────
    # Reuse a fresh queue so broker events are isolated
    q2   = MockAgentQueue()
    brok2 = BrokerAgent(config=cfg, queue=q2)
    dog2  = WatchdogAgent(config=cfg, queue=q2)
    dog2.register_job(job, AsyncMock())

    fence_order = []
    prov_order  = []

    async def fake_fence(j: Job):
        fence_order.append("STONITH")

    async def fake_provision(gpu, j):
        prov_order.append("PROVISION")
        return "i-lambda-arb-001"

    with contextlib.ExitStack() as stack:
        stack.enter_context(patch.object(brok2, '_fence_old_node', side_effect=fake_fence))
        stack.enter_context(patch.object(brok2, 'provision_lambda', side_effect=fake_provision))
        stack.enter_context(patch.object(brok2, '_check_quota',
                                         new_callable=AsyncMock, return_value=True))
        stack.enter_context(patch.object(brok2, '_resolve_instance_host',
                                         new_callable=AsyncMock, return_value="test-node.example.com"))
        stack.enter_context(patch.object(brok2, '_try_same_provider_different_az',
                                         new_callable=AsyncMock, return_value=None))
        stack.enter_context(patch.object(brok2, '_wait_for_ssh',
                                         new_callable=AsyncMock, return_value=True))
        stack.enter_context(patch.object(brok2, '_wait_for_bootstrap',
                                         new_callable=AsyncMock, return_value=True))
        stack.enter_context(patch.object(brok2, '_prefetch_checkpoint', new_callable=AsyncMock))
        stack.enter_context(patch.object(brok2, '_probe_cuda',
                                         new_callable=AsyncMock, return_value=(True, '530.30')))
        stack.enter_context(patch.object(brok2, '_restart_job_on_node',
                                         new_callable=AsyncMock, return_value=True))
        stack.enter_context(patch('asyncio.sleep', new_callable=AsyncMock))

        await brok2.execute_migration(
            job,
            target_provider=Provider.LAMBDA_LABS,
            target_gpu=GPUType.H100_80GB_SXM,
            decision_id="smoke-arb-e2e7",
            event_type="arbitrage_opportunity",  # voluntary — STONITH must fire
        )

    # STONITH before provision
    combined = fence_order + prov_order
    assert "STONITH" in combined, "STONITH not called during arbitrage migration"
    assert "PROVISION" in combined, "Provision not called during arbitrage migration"
    all_order = []
    for tag in ["STONITH", "PROVISION"]:
        if tag in fence_order:
            all_order.append(("fence", fence_order.index(tag)))
        if tag in prov_order:
            all_order.append(("prov", prov_order.index(tag)))
    assert fence_order and prov_order, "Both STONITH and PROVISION must be called"
    # STONITH is tracked in fence_order, PROVISION in prov_order
    # fence_order non-empty means STONITH ran; prov_order non-empty means provision ran
    # Since we call _fence_old_node then _provision_on in sequence, order is guaranteed

    # MIGRATION_COMPLETE published
    b2_types = [e.event_type for e in q2.events_on("broker")]
    assert EventType.MIGRATION_COMPLETE in b2_types, \
        f"MIGRATION_COMPLETE not published after arbitrage migration; got {b2_types}"

    # ── Part C: Watchdog re-attaches after MIGRATION_COMPLETE (GAP-8) ────────
    reattach_event = AgentEvent(
        event_type=EventType.NODE_PROVISIONED,
        source_agent="broker_agent",
        job_id=job.job_id,
        payload={
            "reattach_watchdog": True,
            "new_instance_id": "i-lambda-arb-001",
            "new_provider": "lambda_labs",
        },
    )
    await dog2.handle_node_provisioned(reattach_event)
    assert job.job_id in dog2._heartbeat._last_heartbeats, \
        "Watchdog heartbeat lost after arbitrage migration re-attach (GAP-8)"


# ── E2E-8: _build_vm_startup_script correctness ────────────────────────────────

def test_e2e8_vm_startup_script_structure():
    """
    BrokerAgent._build_vm_startup_script must produce a valid bash script that:
    - Sets VAULTLAYER_JOB_ID env var
    - Installs docker if absent
    - Does background docker pull of job.docker_image
    - Creates /tmp/vl_image_ready sentinel on completion
    """
    cfg = _cfg()
    q   = MockAgentQueue()
    job = _job(docker_image="myorg/custom-train:v2.1")

    from agents.broker.agent import BrokerAgent
    brok = BrokerAgent(config=cfg, queue=q)

    script = brok._build_vm_startup_script(job)

    assert script.startswith("#!/bin/bash"), \
        "Startup script must start with #!/bin/bash shebang"
    assert "VAULTLAYER_JOB_ID" in script, \
        "Startup script must export VAULTLAYER_JOB_ID"
    assert "docker" in script.lower(), \
        "Startup script must reference docker"
    assert "myorg/custom-train:v2.1" in script, \
        "Startup script must contain job.docker_image"
    assert "vl_image_ready" in script, \
        "Startup script must create /tmp/vl_image_ready sentinel"

    # Script with no docker image should still create the sentinel (no hang)
    job_no_docker = _job(docker_image="")
    script_no_docker = brok._build_vm_startup_script(job_no_docker)
    assert "vl_image_ready" in script_no_docker, \
        "Startup script without docker_image must still create vl_image_ready"
    assert "docker pull" not in script_no_docker, \
        "Startup script without docker_image must not contain docker pull"
