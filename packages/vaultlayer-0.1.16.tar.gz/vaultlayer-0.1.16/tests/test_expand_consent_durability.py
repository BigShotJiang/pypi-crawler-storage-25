"""Regression coverage for durable expand-consent requeue behavior."""
from __future__ import annotations

import inspect


def test_expand_consent_persists_queue_state_before_requeue():
    """Widened constraints must survive a worker restart before provisioning."""
    from api import job_routes

    src = inspect.getsource(job_routes.expand_consent)
    queue_state_idx = src.index("_sync_queue_state(run_id, job)")
    status_idx = src.index('_sync_job_status(run_id, "queued")')
    append_idx = src.index("_job_queue.append(job_id)")

    assert queue_state_idx < append_idx
    assert status_idx < append_idx
    assert '_sync_job_status(run_id, "provisioning")' not in src


def test_expand_consent_reserves_submit_hold_before_requeue():
    """Jobs parked for expand consent skipped submit-time reservation initially."""
    from api import job_routes

    src = inspect.getsource(job_routes.expand_consent)
    reserve_idx = src.index("reserve_credits_for_job")
    append_idx = src.index("_job_queue.append(job_id)")

    assert 'stripe_payment_id=f"submit:{job_id}"' in src
    assert "Insufficient credits to start job" in src
    assert reserve_idx < append_idx


def test_expand_consent_reservation_errors_fail_closed():
    """Unexpected reservation errors must not queue an unreserved managed job."""
    from api import job_routes

    src = inspect.getsource(job_routes.expand_consent)
    err_idx = src.index("credit reservation failed")
    window = src[err_idx:err_idx + 300]

    assert "raise HTTPException" in window
    assert "status_code=503" in window
    assert "Could not reserve credits before re-queueing job" in window
