"""Tier-1 tests for broker startup_scripts — interpreter selection (issue #75).

Regression coverage:
  * Python scripts (.py) invoke python3, not bash
  * Shell scripts (.sh) invoke bash
  * Unknown extensions default to bash (current behavior)
  * Both build_vm_startup_script (AWS/EC2 path) and build_container_onstart
    (RunPod/Vast.ai path) pick interpreter correctly
"""
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import MagicMock


def _mock_broker_and_job(script_name: str = "train.py", docker_image: str | None = "pytorch/pytorch:2.3.0-cuda12.1-cudnn8-runtime"):
    """Minimal broker + job for startup-script generation."""
    job = SimpleNamespace(
        job_id="test-job-1234",
        name="test-job",
        environment={},
        docker_image=docker_image or "",
        model_params_billion=None,
        training_mode="full",
        dataset_size_gb=None,
        dataset_location="",
        dataset_region="",
    )
    broker = MagicMock()
    broker.config = SimpleNamespace(
        cloudflare=SimpleNamespace(
            r2_bucket="test", r2_access_key_id="k", r2_secret_access_key="s",
            r2_endpoint="https://r2.test",
        ),
        redis=SimpleNamespace(url="redis://test"),
    )
    broker._get_managed_credentials = MagicMock(return_value=None)
    return broker, job


def test_vm_startup_exports_both_checkpoint_dir_names():
    """Broker must export BOTH CHECKPOINT_DIR (broker contract) and
    VAULTLAYER_CHECKPOINT_DIR (vaultlayer-examples training-script convention)
    with the same value, so user scripts in the wild don't fall back to
    ${VL_DATA_ROOT}/vl-checkpoints/... — which on a no-NVMe Lambda host
    resolves to /tmp/... and the checkpoint dies with the container.

    Caught 2026-04-20 on Lambda Qwen2.5-7B job a6855b08: final model
    saved to /tmp/vl-checkpoints/tinyllama/final instead of /mnt/vaultlayer/...
    """
    from agents.broker.startup_scripts import build_vm_startup_script
    broker, job = _mock_broker_and_job(docker_image="ghcr.io/hector25/vl-training-base:1.0")
    script = build_vm_startup_script(broker, job)
    assert "export CHECKPOINT_DIR=" in script
    assert "export VAULTLAYER_CHECKPOINT_DIR=$CHECKPOINT_DIR" in script, \
        "VAULTLAYER_CHECKPOINT_DIR must be exported alongside CHECKPOINT_DIR"
    # And it must be in the docker run -e list
    assert "VAULTLAYER_CHECKPOINT_DIR" in script.split("docker run")[1] if "docker run" in script else False, \
        "VAULTLAYER_CHECKPOINT_DIR must be passed into docker via -e"


def test_container_onstart_exports_both_checkpoint_dir_names():
    """Same contract on container-provider path (RunPod / Vast.ai)."""
    from agents.broker.startup_scripts import build_container_onstart
    broker, job = _mock_broker_and_job()
    onstart = build_container_onstart(broker, job)
    assert "export CHECKPOINT_DIR=" in onstart
    assert "export VAULTLAYER_CHECKPOINT_DIR=$CHECKPOINT_DIR" in onstart


def test_vm_startup_pulls_r2_checkpoints_unconditionally():
    """Per docs/job_contract.md §4 (2026-04-21): FUSE mount removed, every
    leg unconditionally rclone-copies from R2 FROM the start (first leg
    no-ops on empty path; subsequent legs restore). Without this, cross-
    provider failover reads an empty CHECKPOINT_DIR and restarts at step 0
    (job 7f680ee3 Lambda leg: 15 min billed, 3 log lines, zero training)."""
    from agents.broker.startup_scripts import build_vm_startup_script
    broker, job = _mock_broker_and_job(docker_image="ghcr.io/hector25/vl-training-base:1.0")
    script = build_vm_startup_script(broker, job)
    # inbound restore must exist AND precede the background persist loop
    assert "rclone copy r2:" in script, \
        "VM builder must pull from r2 before training starts"
    assert "while true; do rclone sync $CHECKPOINT_DIR r2:" in script, \
        "VM builder must run background outbound sync"
    inbound_pos = script.find("rclone copy r2:")
    outbound_pos = script.find("while true; do rclone sync $CHECKPOINT_DIR r2:")
    assert 0 <= inbound_pos < outbound_pos, \
        f"restore must precede persist loop (got inbound={inbound_pos} outbound={outbound_pos})"
    # FUSE removed entirely
    assert "rclone mount" not in script, \
        "rclone mount must NOT be used — sync-only path per contract"


def test_container_onstart_pulls_r2_checkpoints_unconditionally():
    """Same contract for container-provider path (RunPod / Vast.ai)."""
    from agents.broker.startup_scripts import build_container_onstart
    broker, job = _mock_broker_and_job()
    onstart = build_container_onstart(broker, job)
    assert "rclone copy r2:" in onstart, \
        "container builder must pull from r2 before training starts"
    assert "while true; do rclone sync $CHECKPOINT_DIR r2:" in onstart, \
        "container builder must run background outbound sync"
    inbound_pos = onstart.find("rclone copy r2:")
    outbound_pos = onstart.find("while true; do rclone sync $CHECKPOINT_DIR r2:")
    assert 0 <= inbound_pos < outbound_pos, \
        "restore must precede persist loop in container onstart"
    assert "rclone mount" not in onstart, \
        "rclone mount must NOT be used in containers — sync-only per contract"


def test_container_onstart_no_legacy_ckpt_step_helper():
    """ckpt_step_N.pt legacy helper removed 2026-04-21. Only HF checkpoint-N/
    format is supported — see docs/job_contract.md §3."""
    from agents.broker.startup_scripts import build_container_onstart
    broker, job = _mock_broker_and_job()
    onstart = build_container_onstart(broker, job)
    assert "ckpt_step_" not in onstart, \
        "legacy ckpt_step_N.pt format must not be referenced"
    assert "vaultlayer_checkpoint.py" not in onstart, \
        "legacy helper module must not be injected"


def test_vm_startup_gcp_driver_install_block():
    """GCP plain-Ubuntu path: bootstrap must apt-install the NVIDIA driver
    when VL_GCP_NEEDS_DRIVER_INSTALL=1. Introduced with the 2026-04-19
    image swap from ubuntu-accelerator to ubuntu-2204-lts."""
    from agents.broker.startup_scripts import build_vm_startup_script
    broker, job = _mock_broker_and_job(docker_image=None)
    s = build_vm_startup_script(broker, job)
    assert "VL_GCP_NEEDS_DRIVER_INSTALL" in s, "new driver-install gate must be emitted"
    assert "ubuntu-drivers install" in s, "prefer ubuntu-drivers for kernel-header resolution"
    assert "nvidia-driver-535" in s, "fallback explicit driver pin required"
    assert "modprobe nvidia" in s, "kernel module load must happen after install"
    assert "nvidia-smi -pm 1" in s, "persistence mode enables driver once GPU is up"
    # Legacy VL_GCP_GPU_WAIT gate is kept for in-flight jobs from older
    # provider code paths — should NOT run the apt-install branch.
    assert "VL_GCP_GPU_WAIT" in s, "legacy gate must remain for in-flight older provisions"


def test_vm_startup_early_curl_probe_present():
    """Early-life curl probe must run BEFORE rclone/docker/nvidia-ctk so we can
    distinguish "VM userData never ran" from "bootstrap ran but heartbeat POST
    fails". GCP smoke jobs (caad81a0, 82e558aa, d22638c8 on 2026-04-19) all
    silently died with 0 logs — probe diagnoses that class."""
    from agents.broker.startup_scripts import build_vm_startup_script
    broker, job = _mock_broker_and_job(docker_image=None)
    script = build_vm_startup_script(broker, job)
    # Probe uses bare curl (no python / urllib) so it works even on minimal AMIs
    assert "bootstrap-probe" in script, "early curl probe line must be emitted"
    assert "curl -fsS -X POST" in script
    assert "early curl probe POSTed" in script, \
        "success sentinel must be written to $_VL_LOG for later diagnosis"
    # Probe must come BEFORE the Python heartbeat block so we can tell the difference
    idx_probe = script.find("bootstrap-probe")
    idx_python_heartbeat = script.find("urllib.request.Request(api")
    assert idx_probe < idx_python_heartbeat, \
        "probe must come before python heartbeat to diagnose bootstrap-entered signal"


def test_vm_startup_py_script_runs_python3_host_path():
    """BUG #75 on the HOST launch path (no docker_image)."""
    from agents.broker.startup_scripts import build_vm_startup_script
    broker, job = _mock_broker_and_job(docker_image=None)
    script = build_vm_startup_script(broker, job)

    # The exec block selects interpreter by extension
    assert '*.py)  _VL_INTERP="python3"' in script, \
        "python3 must be the interpreter for .py files"
    assert '*.sh)  _VL_INTERP="bash"' in script, \
        ".sh files should use bash"
    # Host path: training runs directly on the VM
    assert "$_VL_INTERP $_VL_WORK/${VL_SCRIPT_NAME}" in script, \
        "host launch line must use $_VL_INTERP + $_VL_WORK"
    # Old bug pattern should be gone
    assert "bash $_VL_WORK/${VL_SCRIPT_NAME}" not in script, \
        "must not hardcode bash for script exec (regression guard for #75)"
    # Host path must NOT docker-run
    assert "docker run" not in script.split("Training finished")[0], \
        "no docker_image → must not use docker run"


def test_vm_startup_docker_image_runs_in_container():
    """When docker_image is set, VM training runs INSIDE the image via
    `docker run --gpus all` — bypasses host-OS dep hell. See build_vm_startup_script
    branch introduced alongside training-base:1.0."""
    from agents.broker.startup_scripts import build_vm_startup_script
    broker, job = _mock_broker_and_job(docker_image="ghcr.io/hector25/vl-training-base:1.0")
    script = build_vm_startup_script(broker, job)

    # Docker install + nvidia-container-toolkit present
    assert "curl -fsSL https://get.docker.com | bash" in script
    assert "nvidia-container-toolkit" in script, \
        "must install nvidia-container-toolkit — needed for --gpus all on GCP/Crusoe AMIs"
    # Training launch wrapped in docker run with the right flags
    assert "docker run --rm --gpus all" in script
    assert "--shm-size=4g" in script, \
        "shm-size needed for torch DataLoader workers"
    assert "-v $_VL_WORK:/workspace" in script
    assert "-v $CHECKPOINT_DIR:$CHECKPOINT_DIR" in script, \
        "CHECKPOINT_DIR must be bind-mounted into the container for checkpoint writes"
    assert "ghcr.io/hector25/vl-training-base:1.0" in script
    assert "$_VL_INTERP /workspace/${VL_SCRIPT_NAME}" in script, \
        "interpreter picked by extension, invoked on the in-container path"
    # Wait for pull to complete before running
    assert "/tmp/vl_image_ready" in script
    # Pipefail + PIPESTATUS for correct exit propagation
    assert "set -o pipefail" in script
    assert "_EXIT=${PIPESTATUS[0]}" in script
    # Key infra env vars propagated into the container
    for k in ("VL_JOB_TOKEN", "VAULTLAYER_API_URL", "CHECKPOINT_DIR", "VAULTLAYER_JOB_ID"):
        assert f"-e {k}" in script, f"{k} must pass through to the container"


def test_container_onstart_py_script_runs_python3():
    """BUG #75 applies to container path (RunPod / Vast.ai) too."""
    from agents.broker.startup_scripts import build_container_onstart
    broker, job = _mock_broker_and_job()
    onstart = build_container_onstart(broker, job)

    assert '*.py)  _VL_INTERP="python3"' in onstart
    assert "$_VL_INTERP /workspace/${VL_SCRIPT_NAME}" in onstart
    # The previous bug was `python ... ${VL_SCRIPT_NAME}` (bare python, not
    # python3 — some minimal images don't ship `python`). Regression guard:
    assert "python /workspace/${VL_SCRIPT_NAME}" not in onstart, \
        "must not hardcode 'python' (image may only have python3)"


def test_vm_completion_emits_durable_sentinel_and_event():
    """VM jobs need completion signals independent of the final /logs POST."""
    from agents.broker.startup_scripts import build_vm_startup_script
    broker, job = _mock_broker_and_job(docker_image=None)
    script = build_vm_startup_script(broker, job)

    assert "checkpoints/test-job-1234/_COMPLETED" in script
    assert "checkpoints/test-job-1234/_FAILED" in script
    assert "rclone copyto /tmp/_VL_EXIT_SENTINEL r2:test/$_VL_SENTINEL_KEY" in script
    assert "/api/v1/jobs/test-job-1234/events" in script
    assert "event_type=evt_type" in script
    assert "evt_type = 'completed' if exit_code == 0 else 'failed'" in script


def test_container_training_appends_log_instead_of_truncating():
    """Container training tee must append so heartbeat offsets stay valid."""
    from agents.broker.startup_scripts import build_container_onstart
    broker, job = _mock_broker_and_job()
    onstart = build_container_onstart(broker, job)

    assert '2>&1 | tee -a $_VL_LOG' in onstart
    assert '2>&1 | tee $_VL_LOG' not in onstart
