"""Tests for issue #127 — node-auth logs/events resolve owner from DB after restart.

Before this fix, the X-Job-Token path for /events and /logs fell back to
user_id='system' when _active_jobs did not contain the job. After an API
restart that loses _active_jobs state, all node-posted rows were attributed to
'system', making them invisible to the real owner (GET /logs filters on owner id).

The fix: _resolve_job_owner_id() checks _active_jobs first, then falls back to
a job_runs DB lookup, returning 'system' only when the DB has no row.
"""
from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


def _mock_db(account_id: str | None):
    db = MagicMock()
    result = MagicMock()
    result.data = [{"account_id": account_id}] if account_id else []
    db.table.return_value.select.return_value.eq.return_value.eq.return_value.limit.return_value.execute.return_value = result
    db.table.return_value.select.return_value.eq.return_value.limit.return_value.execute.return_value = result
    return db


def test_resolve_from_active_jobs():
    """When job is in _active_jobs, return user_id without touching DB."""
    from api import job_routes
    with patch.dict(job_routes._active_jobs, {"job-abc": {"user_id": "user-123"}}):
        uid = job_routes._resolve_job_owner_id("job-abc")
    assert uid == "user-123"


def test_resolve_from_db_when_not_in_active_jobs():
    """After restart, job not in _active_jobs — must fall back to DB."""
    from api import job_routes
    db = _mock_db("user-456")
    with patch.dict(job_routes._active_jobs, {}):
        with patch("api.job_routes.get_db", return_value=db), \
             patch("api.job_routes._db_call", side_effect=lambda fn, **kw: fn()):
            uid = job_routes._resolve_job_owner_id("job-xyz")
    assert uid == "user-456"


def test_resolve_falls_back_to_system_when_no_db_row():
    """If DB has no row for job_id, return 'system' gracefully."""
    from api import job_routes
    db = _mock_db(None)
    with patch.dict(job_routes._active_jobs, {}):
        with patch("api.job_routes.get_db", return_value=db), \
             patch("api.job_routes._db_call", side_effect=lambda fn, **kw: fn()):
            uid = job_routes._resolve_job_owner_id("job-gone")
    assert uid == "system"


def test_resolve_falls_back_to_system_on_db_error():
    """If DB lookup raises, return 'system' rather than 500."""
    from api import job_routes
    with patch.dict(job_routes._active_jobs, {}):
        with patch("api.job_routes.get_db", side_effect=Exception("db down")):
            uid = job_routes._resolve_job_owner_id("job-err")
    assert uid == "system"


def test_resolve_prefers_active_jobs_over_db():
    """active_jobs takes priority even if DB has a different account_id."""
    from api import job_routes
    db = _mock_db("user-db-version")
    with patch.dict(job_routes._active_jobs, {"job-pref": {"user_id": "user-memory-version"}}):
        with patch("api.job_routes.get_db", return_value=db):
            uid = job_routes._resolve_job_owner_id("job-pref")
    assert uid == "user-memory-version"
    # DB should not have been called
    db.table.assert_not_called()
