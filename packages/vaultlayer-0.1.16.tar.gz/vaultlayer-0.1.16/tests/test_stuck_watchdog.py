"""Unit tests for _vast_check_log_progress — stuck watchdog liveness probe.

Codex review requirements:
  1. Stale logs (unchanged content) → proceed with kill
  2. Fresh progress (content changed) → skip kill
  3. Same byte length but different content → treated as active (skip kill)
     [regression guard for rolling-tail window with >200 log lines]

_fetch_fn returns Optional[str]: a "len:md5hash" marker or None on failure.
"""
import pytest


@pytest.mark.asyncio
async def test_vast_check_log_progress_first_snapshot():
    """First stuck-check cycle: snapshot marker, return True (defer kill)."""
    from api.job_worker import _vast_check_log_progress

    job = {"job_id": "abc123def456"}
    result = await _vast_check_log_progress(job, "inst1", _fetch_fn=lambda: "500:abc123")

    assert result is True, "First cycle must skip kill to allow one more observation"
    assert job["_vast_log_marker"] == "500:abc123"


@pytest.mark.asyncio
async def test_vast_check_log_progress_content_changed():
    """Log content changed since last cycle → instance active → skip kill."""
    from api.job_worker import _vast_check_log_progress

    job = {"job_id": "abc123def456", "_vast_log_marker": "500:abc123"}
    result = await _vast_check_log_progress(job, "inst1", _fetch_fn=lambda: "750:def456")

    assert result is True, "Changed content must skip kill"
    assert job["_vast_log_marker"] == "750:def456"


@pytest.mark.asyncio
async def test_vast_check_log_progress_stale_logs():
    """Log content unchanged since last cycle → no progress → proceed with kill.

    This is the key regression guard: a job that emitted startup lines and then
    hung must NOT be kept alive indefinitely by those stale logs.
    """
    from api.job_worker import _vast_check_log_progress

    job = {"job_id": "abc123def456", "_vast_log_marker": "300:aaa111"}
    result = await _vast_check_log_progress(job, "inst1", _fetch_fn=lambda: "300:aaa111")

    assert result is False, "Stale marker (unchanged content) must not skip kill"


@pytest.mark.asyncio
async def test_vast_check_log_progress_same_length_different_content():
    """Rolling tail: same byte length but different content → active → skip kill.

    This is the specific regression from Codex review: a job with >200 log lines
    has a rolling tail window where new lines replace old lines. Byte count stays
    the same but the content (and MD5) changes — must be treated as active.
    """
    from api.job_worker import _vast_check_log_progress

    # Both markers have the same byte length (302) but different MD5 hashes
    job = {"job_id": "abc123def456", "_vast_log_marker": "302:oldhashabc"}
    result = await _vast_check_log_progress(job, "inst1", _fetch_fn=lambda: "302:newhashabc")

    assert result is True, "Same-length but different content must skip kill (rolling tail window)"
    assert job["_vast_log_marker"] == "302:newhashabc"


@pytest.mark.asyncio
async def test_vast_check_log_progress_api_failure():
    """API returns None (fetch failed) → fall through → return False (proceed with kill)."""
    from api.job_worker import _vast_check_log_progress

    job = {"job_id": "abc123def456"}
    result = await _vast_check_log_progress(job, "inst1", _fetch_fn=lambda: None)

    assert result is False, "API failure must not block the kill path"


@pytest.mark.asyncio
async def test_vast_check_log_progress_no_api_key(monkeypatch):
    """No API key and no _fetch_fn → return False (fall through to existing kill path)."""
    monkeypatch.delenv("VAST_AI_API_KEY", raising=False)
    monkeypatch.delenv("VL_VAST_AI_API_KEY", raising=False)

    from api.job_worker import _vast_check_log_progress

    job = {"job_id": "abc123def456"}
    result = await _vast_check_log_progress(job, "inst1")

    assert result is False, "Missing API key with no override must not skip kill"


@pytest.mark.asyncio
async def test_vast_check_log_progress_empty_log_first_snapshot():
    """Instance returned empty log (container still starting) → snapshot and defer."""
    from api.job_worker import _vast_check_log_progress

    job = {"job_id": "abc123def456"}
    # Empty log: len=0, md5 of ""
    result = await _vast_check_log_progress(job, "inst1", _fetch_fn=lambda: "0:d41d8cd98f00b204e9800998ecf8427e")

    assert result is True, "Empty log on first check must defer kill (image may still be pulling)"
    assert "_vast_log_marker" in job


@pytest.mark.asyncio
async def test_vast_check_log_progress_empty_log_stale():
    """0-byte log on both checks → no progress → kill."""
    from api.job_worker import _vast_check_log_progress

    empty_marker = "0:d41d8cd98f00b204e9800998ecf8427e"
    job = {"job_id": "abc123def456", "_vast_log_marker": empty_marker}
    result = await _vast_check_log_progress(job, "inst1", _fetch_fn=lambda: empty_marker)

    assert result is False, "Empty log on second check (no change) must proceed with kill"
