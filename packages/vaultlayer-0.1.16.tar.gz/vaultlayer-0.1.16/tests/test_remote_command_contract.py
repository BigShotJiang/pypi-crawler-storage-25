"""Regression coverage for managed remote command and log contracts."""
from __future__ import annotations

import asyncio
import inspect
from types import SimpleNamespace

import pytest


def test_python_module_invocation_detects_interpreter_options():
    from cli._remote import _python_module_invocation

    assert _python_module_invocation(["python", "-m", "trainer"]) == "trainer"
    assert _python_module_invocation(["python", "-u", "-m", "trainer"]) == "trainer"
    assert _python_module_invocation(["python3", "-X", "dev", "-m", "trainer"]) == "trainer"
    assert _python_module_invocation(["python", "train.py", "-m", "model"]) is None


def test_known_remote_launchers_are_allowlisted():
    from cli import _remote

    assert "torch.distributed.run" in _remote._ALLOWED_REMOTE_MODULE_LAUNCHERS
    assert "accelerate.commands.launch" in _remote._ALLOWED_REMOTE_MODULE_LAUNCHERS
    assert "deepspeed.launcher.runner" in _remote._ALLOWED_REMOTE_MODULE_LAUNCHERS


def test_run_remote_rejects_multiple_local_python_files(tmp_path):
    from cli._remote import run_remote

    train = tmp_path / "train.py"
    helper = tmp_path / "helper.py"
    train.write_text("print('train')\n")
    helper.write_text("print('helper')\n")

    run_cmd = SimpleNamespace(command=["python", str(train), str(helper)])
    job = SimpleNamespace(gpu_type=SimpleNamespace(value="A10G"), environment={})

    with pytest.raises(SystemExit) as exc_info:
        asyncio.run(run_remote(run_cmd, job, broker=None, queue=None))

    assert "supports exactly one local .py script" in str(exc_info.value)


def test_run_remote_rejects_python_dash_m_local_module():
    from cli._remote import run_remote

    run_cmd = SimpleNamespace(command=["python", "-u", "-m", "trainer"])
    job = SimpleNamespace(gpu_type=SimpleNamespace(value="A10G"), environment={})

    with pytest.raises(SystemExit) as exc_info:
        asyncio.run(run_remote(run_cmd, job, broker=None, queue=None))

    assert "'python -m trainer'" in str(exc_info.value)


def test_log_endpoint_and_cli_use_server_side_offset():
    from api import job_routes
    from cli import _remote

    route_src = inspect.getsource(job_routes.get_job_logs)
    cli_src = inspect.getsource(_remote.run_remote)

    assert "offset: int = 0" in route_src
    assert ".range(offset, offset + limit - 1)" in route_src
    assert 'params={"limit": 500, "offset": _last_log_count}' in cli_src
    assert "for line_data in lines:" in cli_src
    assert "_last_log_count += len(lines)" in cli_src
    assert "for line_data in lines[_last_log_count:]" not in cli_src
