"""
Tests for #140 — VL_MIGRATION double-launch prevention.

VL_MIGRATION=1 is injected into job.environment before provisioning so that
the auto-start blocks in startup_scripts.py are skipped.  SSH resume then
launches training once, preventing a double-launch.
"""

import ast
import textwrap
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Startup-script guard tests
# ---------------------------------------------------------------------------

def _vm_builder_lines():
    """Return the VM UserData lines from startup_scripts.py."""
    from agents.broker.startup_scripts import build_vm_user_data
    from shared.models import Job, Provider, GPUType

    job = Job(
        job_id="test-job-vl",
        user_id="u1",
        name="test",
        command="python3 train.py",
        provider=Provider.AWS,
        gpu_type=GPUType.A100,
    )
    config = MagicMock()
    config.r2_bucket_name = "test-bucket"
    config.r2_access_key_id = "KEY"
    config.r2_secret_access_key = "SECRET"
    config.r2_account_id = "ACCT"
    config.vaultlayer_api_url = "https://api.test"
    return build_vm_user_data(job=job, config=config)


def _container_builder_lines():
    """Return container bootstrap lines from startup_scripts.py."""
    from agents.broker.startup_scripts import build_container_start_script
    from shared.models import Job, Provider, GPUType

    job = Job(
        job_id="test-job-cont",
        user_id="u1",
        name="test",
        command="python3 train.py",
        provider=Provider.RUNPOD,
        gpu_type=GPUType.A100,
    )
    config = MagicMock()
    config.r2_bucket_name = "test-bucket"
    config.r2_access_key_id = "KEY"
    config.r2_secret_access_key = "SECRET"
    config.r2_account_id = "ACCT"
    config.vaultlayer_api_url = "https://api.test"
    return build_container_start_script(job=job, config=config)


def test_vm_auto_start_guarded_by_vl_migration():
    """VM UserData auto-start block must check VL_MIGRATION != 1."""
    try:
        lines = _vm_builder_lines()
    except Exception:
        pytest.skip("build_vm_user_data not callable in this env")
    text = "\n".join(lines) if isinstance(lines, list) else lines
    assert 'VL_MIGRATION' in text, "VL_MIGRATION guard missing from VM auto-start block"
    assert '"1"' in text or "'1'" in text or '!= "1"' in text or "!= '1'" in text


def test_container_auto_start_guarded_by_vl_migration():
    """Container bootstrap auto-start block must check VL_MIGRATION != 1."""
    try:
        lines = _container_builder_lines()
    except Exception:
        pytest.skip("build_container_start_script not callable in this env")
    text = "\n".join(lines) if isinstance(lines, list) else lines
    assert 'VL_MIGRATION' in text, "VL_MIGRATION guard missing from container auto-start block"


def test_both_auto_start_blocks_guarded():
    """Both VM and container auto-start blocks must have the VL_MIGRATION guard."""
    import inspect
    from agents.broker import startup_scripts
    src = inspect.getsource(startup_scripts)
    # Count occurrences of VL_MIGRATION in auto-start guard position
    count = src.count('VL_MIGRATION:-0}')
    assert count >= 2, (
        f"Expected VL_MIGRATION guard in both VM and container auto-start blocks, "
        f"found {count} occurrence(s)"
    )


# ---------------------------------------------------------------------------
# Migration.py environment injection tests
# ---------------------------------------------------------------------------

def _make_job(**kwargs):
    from shared.models import Job, Provider, GPUType
    defaults = dict(
        job_id="job-123",
        user_id="u1",
        name="test",
        command="python3 train.py",
        provider=Provider.RUNPOD,
        gpu_type=GPUType.A100,
        instance_id="inst-old",
    )
    defaults.update(kwargs)
    return Job(**defaults)


def _migration_src():
    import inspect
    from agents.broker import migration
    return inspect.getsource(migration)


def test_migration_sets_vl_migration_env_before_provision():
    """execute_migration must set VL_MIGRATION=1 before any provision call."""
    src = _migration_src()
    # Check VL_MIGRATION is set on job.environment
    assert 'VL_MIGRATION' in src, "VL_MIGRATION not referenced in migration.py"
    assert 'job.environment["VL_MIGRATION"] = "1"' in src or \
           "job.environment['VL_MIGRATION'] = '1'" in src, \
           "VL_MIGRATION=1 not stamped into job.environment in migration.py"


def test_migration_clears_vl_migration_after_restart():
    """execute_migration must remove VL_MIGRATION from env after SSH resume."""
    src = _migration_src()
    assert 'VL_MIGRATION' in src
    # Clean-up should be present
    assert 'pop("VL_MIGRATION"' in src or "pop('VL_MIGRATION'" in src, \
        "VL_MIGRATION not cleaned up after _restart_job_on_node"


def test_migration_handles_none_environment():
    """VL_MIGRATION injection must handle job.environment = None gracefully."""
    src = _migration_src()
    # Must initialise dict when None
    assert 'job.environment is None' in src or \
           'if job.environment is None' in src, \
        "migration.py must handle job.environment = None before injecting VL_MIGRATION"


def test_migration_restores_none_environment_on_cleanup():
    """If job.environment was None before migration, restore it to None after."""
    src = _migration_src()
    assert '_env_was_none' in src, \
        "migration.py must track whether environment was None before injection"


def test_vl_migration_cleared_before_set_job_state():
    """VL_MIGRATION must be cleared from job.environment BEFORE any set_job_state()
    call — it must NEVER persist to Redis.

    Strategy: verify that in migration.py source, the pop("VL_MIGRATION") line
    appears at least once BEFORE any 'set_job_state' line that follows the
    VL_MIGRATION injection point.
    """
    src = _migration_src()
    lines = src.splitlines()

    inject_idx = next(
        (i for i, l in enumerate(lines) if 'job.environment["VL_MIGRATION"] = "1"' in l or
         "job.environment['VL_MIGRATION'] = '1'" in l),
        None,
    )
    assert inject_idx is not None, "VL_MIGRATION injection not found in migration.py"

    # Find the FIRST cleanup (pop) after the injection point
    pop_idx = next(
        (i for i, l in enumerate(lines) if i > inject_idx and 'pop("VL_MIGRATION"' in l),
        None,
    )
    assert pop_idx is not None, "VL_MIGRATION cleanup (pop) not found after injection"

    # Find the FIRST set_job_state call after the injection point
    persist_idx = next(
        (i for i, l in enumerate(lines) if i > inject_idx and "set_job_state(" in l),
        None,
    )
    assert persist_idx is not None, "No set_job_state() found after VL_MIGRATION injection"

    assert pop_idx < persist_idx, (
        f"VL_MIGRATION cleanup (line {pop_idx}) must occur BEFORE first set_job_state "
        f"(line {persist_idx}) — currently set_job_state fires first, leaking VL_MIGRATION into Redis"
    )
