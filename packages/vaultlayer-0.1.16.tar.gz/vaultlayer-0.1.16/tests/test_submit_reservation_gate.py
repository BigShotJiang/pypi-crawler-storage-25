"""
Tests for #151 — atomic submit-time credit reservation + exact cancel refund.

Key properties tested:
1. Reservation uses reserve_credits_for_job() DB RPC (atomic check-and-reserve)
2. Reservation is BEFORE queue insertion (_active_jobs + _job_queue)
3. Reservation failure raises 402 (insufficient) or 503 (error)
4. Cancel refund looks up the ACTUAL reservation amount (not VL_MIN_CREDITS_TO_START)
5. Cancel with no reservation event skips refund (no windfall)
6. math.ceil() used for credits calculation (IEEE 754 fix)
"""
import inspect
import math
import uuid
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Source-level structural checks (fast, no DB)
# ---------------------------------------------------------------------------

def test_reservation_uses_rpc_not_direct_insert():
    """Reservation must use reserve_credits_for_job RPC, not add_credit_event directly."""
    from api import job_routes as jr
    src = inspect.getsource(jr.submit_job)
    assert "reserve_credits_for_job" in src, (
        "submit_job must call reserve_credits_for_job (atomic RPC), not add_credit_event directly"
    )


def test_reserve_wrapper_fails_closed_when_rpc_unavailable():
    """The Python wrapper must not fall back to a non-atomic ledger insert."""
    from api import db
    src = inspect.getsource(db.reserve_credits_for_job)
    assert "add_credit_event(" not in src, (
        "reserve_credits_for_job must fail closed when RPC is unavailable, "
        "not fall back to a direct non-atomic insert"
    )
    assert "raise" in src


def test_rpc_migration_restricts_execute_and_validates_amount():
    """SECURITY DEFINER reservation RPC must be backend-only and reject credit grants."""
    from pathlib import Path
    sql = Path("schema/migrations/0029_reserve_credits_rpc.sql").read_text()
    assert "SECURITY DEFINER" in sql
    assert "SET search_path = public, pg_temp" in sql
    assert "p_amount_credits IS NULL OR p_amount_credits >= 0" in sql
    assert "p_amount_credits >= 0" in sql
    assert "invalid_amount" in sql
    assert "REVOKE ALL ON FUNCTION public.reserve_credits_for_job" in sql
    assert "authenticated" in sql
    assert "service_role" in sql


def test_reservation_is_before_queue_insertion():
    """Reservation must appear BEFORE '_active_jobs[job_id] =' in submit_job source."""
    from api import job_routes as jr
    src = inspect.getsource(jr.submit_job)
    reserve_pos = src.find("reserve_credits_for_job")
    queue_pos = src.find("_active_jobs[job_id] =")
    assert reserve_pos != -1, "reserve_credits_for_job call not found in submit_job"
    assert queue_pos != -1, "_active_jobs[job_id] insertion not found in submit_job"
    assert reserve_pos < queue_pos, (
        "Reservation must be BEFORE '_active_jobs[job_id] =' (queue insertion), "
        f"but found at pos {reserve_pos} vs queue-insert at {queue_pos}"
    )


def test_reservation_raises_402_on_insufficient_balance():
    """Insufficient balance response from RPC must raise 402 (not 503)."""
    from api import job_routes as jr
    src = inspect.getsource(jr.submit_job)
    assert "insufficient_balance" in src, (
        "submit_job must handle 'insufficient_balance' reason from RPC and raise 402"
    )
    assert "status_code=402" in src, (
        "submit_job must raise HTTPException(402) on insufficient balance"
    )


def test_reservation_uses_math_ceil():
    """Credits calculation must use math.ceil() to avoid IEEE754 truncation."""
    from api import job_routes as jr
    src = inspect.getsource(jr.submit_job)
    assert "math.ceil" in src, (
        "Credits calculation must use math.ceil() — int(2.0 * 1.15 * 100) == 229, not 230"
    )


def test_cancel_refund_not_using_floor_constant():
    """Cancel refund must NOT use VL_MIN_CREDITS_TO_START as refund amount."""
    from api import job_routes as jr
    src = inspect.getsource(jr.cancel_job)
    assert "MIN_FLOOR" not in src, (
        "cancel_job must not use VL_MIN_CREDITS_TO_START floor as refund — use actual reservation"
    )


def test_cancel_refund_looks_up_reservation():
    """Cancel refund must look up the actual reservation via stripe_payment_id."""
    from api import job_routes as jr
    src = inspect.getsource(jr.cancel_job)
    assert 'submit:{job_id}' in src or 'f"submit:{job_id}"' in src, (
        "cancel_job must query reservation via stripe_payment_id='submit:{job_id}'"
    )
    assert "amount_credits" in src, (
        "cancel_job must read amount_credits from reservation event"
    )


def test_cancel_refund_happens_before_terminal_settle():
    """Queued cancel must release submit reservation before terminalizing the job."""
    from api import job_routes as jr
    src = inspect.getsource(jr.cancel_job)
    lookup_pos = src.find('submit:{job_id}')
    settle_pos = src.find('_settle_in_db(job, status="cancelled")')
    assert lookup_pos != -1, "cancel_job must look up the submit reservation"
    assert settle_pos != -1, "cancel_job must settle queued jobs as cancelled"
    assert lookup_pos < settle_pos, (
        "cancel_job must release/refund the reservation before terminalizing the job"
    )


def test_cancel_refund_skips_when_no_reservation():
    """Cancel refund must skip (no windfall) when no reservation event is found."""
    from api import job_routes as jr
    src = inspect.getsource(jr.cancel_job)
    assert "_reserved_cr > 0" in src or "reserved_cr > 0" in src, (
        "cancel_job must guard the refund insert with 'if _reserved_cr > 0'"
    )


# ---------------------------------------------------------------------------
# Functional tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_cancel_queued_job_refunds_exact_reservation(monkeypatch):
    """Cancel of queued job refunds the exact amount from the reservation event."""
    import api.job_routes as jr

    monkeypatch.setattr("api.flags.TESTING_MODE", False)

    job_id = str(uuid.uuid4())
    user = {"user_id": "u-test", "email": "test@example.com"}
    job = {
        "job_id": job_id,
        "user_id": user["user_id"],
        "status": "queued",
        "gpu_type": "A100",
        "instance_id": None,
        "provider": None,
    }

    jr._active_jobs[job_id] = job

    mock_db = MagicMock()
    mock_ce = MagicMock()
    # Reservation lookup returns 120 credits reserved
    lookup_res = MagicMock(data=[{"amount_credits": -120}])
    mock_ce.select.return_value.eq.return_value.limit.return_value.execute.return_value = lookup_res
    mock_db.table.return_value = mock_ce
    monkeypatch.setattr("api.job_routes.get_db", lambda: mock_db)
    monkeypatch.setattr("api.job_routes._db_call", lambda fn, label="": fn())

    refund_calls = []

    def mock_add_ev(**kwargs):
        refund_calls.append(kwargs)

    monkeypatch.setattr("api.db.add_credit_event", mock_add_ev)

    def mock_settle(job, status=None):
        pass
    monkeypatch.setattr(jr, "_settle_in_db", mock_settle)

    try:
        result = await jr.cancel_job(
            job_id=job_id,
            reason="user_request",
            user=user,
        )
    finally:
        jr._active_jobs.pop(job_id, None)

    refund_events = [c for c in refund_calls if c.get("event_type") == "refund"]
    assert len(refund_events) == 1, f"Expected 1 refund event, got {len(refund_events)}: {refund_calls}"
    assert refund_events[0]["amount_credits"] == 120, (
        f"Expected refund of 120 (exact reservation), got {refund_events[0]['amount_credits']}"
    )
    assert refund_events[0]["stripe_payment_id"] == f"submit_cancel_refund:{job_id}"


@pytest.mark.asyncio
async def test_cancel_no_reservation_skips_refund(monkeypatch):
    """Cancel when no reservation exists must issue no refund (no windfall)."""
    import api.job_routes as jr

    monkeypatch.setattr("api.flags.TESTING_MODE", False)

    job_id = str(uuid.uuid4())
    user = {"user_id": "u-test", "email": "test@example.com"}
    job = {
        "job_id": job_id,
        "user_id": user["user_id"],
        "status": "queued",
        "gpu_type": "A100",
        "instance_id": None,
        "provider": None,
    }

    jr._active_jobs[job_id] = job

    mock_db = MagicMock()
    mock_ce = MagicMock()
    # No reservation found
    empty_res = MagicMock(data=[])
    mock_ce.select.return_value.eq.return_value.limit.return_value.execute.return_value = empty_res
    mock_db.table.return_value = mock_ce
    monkeypatch.setattr("api.job_routes.get_db", lambda: mock_db)
    monkeypatch.setattr("api.job_routes._db_call", lambda fn, label="": fn())

    refund_calls = []

    def mock_add_ev(**kwargs):
        refund_calls.append(kwargs)

    monkeypatch.setattr("api.db.add_credit_event", mock_add_ev)

    def mock_settle(job, status=None):
        pass
    monkeypatch.setattr(jr, "_settle_in_db", mock_settle)

    try:
        result = await jr.cancel_job(
            job_id=job_id,
            reason="user_request",
            user=user,
        )
    finally:
        jr._active_jobs.pop(job_id, None)

    refund_events = [c for c in refund_calls if c.get("event_type") == "refund"]
    assert len(refund_events) == 0, (
        f"Expected no refund when no reservation exists, got {len(refund_events)}"
    )
