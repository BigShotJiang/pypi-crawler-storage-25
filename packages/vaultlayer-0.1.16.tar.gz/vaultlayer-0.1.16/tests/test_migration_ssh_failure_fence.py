"""Tests for issue #145: SSH failure after migration provision must fence the new instance.

When _wait_for_ssh() raises, the code used to clear job.instance_id and return
without terminating the newly provisioned node. The node kept billing while the
control plane had already lost track of it.

Fix: call _fence_old_node_by_id(instance_id, actual_provider) before clearing
job.instance_id in the SSH failure rollback path.
"""
import inspect
import pytest


def _get_migration_source():
    from agents.broker import migration
    return inspect.getsource(migration.execute_migration)


def test_fence_called_before_instance_id_cleared():
    """_fence_old_node_by_id must appear before job.instance_id = None in SSH error branch."""
    src = _get_migration_source()

    fence_idx = src.find("_fence_old_node_by_id")
    clear_idx = src.find("job.instance_id = None")

    assert fence_idx != -1, (
        "_fence_old_node_by_id must be called in execute_migration SSH failure branch"
    )
    assert clear_idx != -1, "job.instance_id = None must be present"
    assert fence_idx < clear_idx, (
        "_fence_old_node_by_id must be called BEFORE job.instance_id = None "
        "to avoid losing the instance reference before the fence is issued"
    )


def test_fence_error_is_logged_not_silenced():
    """Fence failure in the SSH error path must be logged as an error (billing leak)."""
    src = _get_migration_source()

    # Find the fence try/except block
    assert "billing leak" in src.lower() or "billing leak risk" in src.lower(), (
        "Fence failure must log 'billing leak' warning so operators can manually clean up"
    )
    assert "Manual cleanup required" in src or "manual" in src.lower(), (
        "Fence failure log must mention manual cleanup"
    )


def test_fence_receives_actual_provider():
    """_fence_old_node_by_id must receive actual_provider (not target_provider)."""
    src = _get_migration_source()

    fence_idx = src.find("_fence_old_node_by_id")
    assert fence_idx != -1

    # Get the call context (next 100 chars)
    call_context = src[fence_idx:fence_idx + 150]
    assert "actual_provider" in call_context, (
        "_fence_old_node_by_id must receive actual_provider — the provider "
        "that was actually used (may differ from target_provider on warm-pool hits)"
    )


def test_fence_receives_instance_id():
    """_fence_old_node_by_id must receive the newly provisioned instance_id."""
    src = _get_migration_source()

    fence_idx = src.find("_fence_old_node_by_id")
    call_context = src[fence_idx:fence_idx + 150]
    assert "instance_id" in call_context, (
        "_fence_old_node_by_id must receive instance_id (the new node, not job.instance_id "
        "which is about to be cleared)"
    )
