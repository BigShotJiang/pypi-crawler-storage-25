"""
Tests for issue #153: _deduct_credits() fallback when _spend_id is missing.

Verifies:
- fallback event uses event_type="burned" (visible to balance view)
- fallback event includes job_id for reconciliation
- fallback event uses stripe_payment_id="fallback:{job_id}" for idempotency
- duplicate call is a no-op (idempotency pre-check)
- math.ceil(round(..., 4)) avoids IEEE 754 truncation
- zero-cost jobs are skipped
"""
import math
import os
from unittest.mock import MagicMock, call, patch

import pytest


def _build_db_mock(idempotency_event_exists: bool = False, user_row: dict | None = None):
    """
    Build a db mock that routes the two select chains correctly:
    - credit_events.select("id").eq("stripe_payment_id",...).limit(1).execute()
      → idempotency check
    - credit_events.insert(...).execute()
      → insert path
    """
    mock_db = MagicMock()
    credit_events = MagicMock()
    users = MagicMock()

    # Track insert calls so tests can assert on them
    insert_execute = MagicMock()
    insert_execute.return_value = MagicMock(data=[{"id": "evt-1"}])
    credit_events.insert.return_value.execute = insert_execute

    # Idempotency check chain: .select().eq().limit().execute()
    idem_execute = MagicMock()
    idem_execute.return_value = MagicMock(
        data=[{"id": "existing-evt"}] if idempotency_event_exists else []
    )
    credit_events.select.return_value.eq.return_value.limit.return_value.execute = idem_execute

    users.select.return_value.eq.return_value.execute.return_value = MagicMock(
        data=[user_row] if user_row else []
    )

    def _table(name):
        if name == "credit_events":
            return credit_events
        if name == "users":
            return users
        return MagicMock()

    mock_db.table.side_effect = _table
    mock_db._credit_events = credit_events

    return mock_db


def _run_deduct(job: dict, mock_db):
    """Patch get_db and _db_call to run _deduct_credits synchronously."""
    from api import job_worker

    # _db_call just calls fn() directly
    with patch("api.job_worker.get_db", return_value=mock_db), \
         patch("api.job_worker._db_call", side_effect=lambda fn, **kw: fn()):
        job_worker._deduct_credits(job)


def _inserted_event(mock_db):
    return mock_db._credit_events.insert.call_args[0][0]


# ── Tests ─────────────────────────────────────────────────────────────────────

def test_event_type_is_burned():
    """Fallback event must use event_type='burned' so balance view picks it up."""
    job = {
        "job_id": "abc12345-0000-0000-0000-000000000000",
        "user_id": "u1",
        "started_at": 1_000_000.0,
        "completed_at": 1_003_600.0,  # 1h later
        "price_per_hr": 1.0,
        "vl_margin_pct": 0.20,
        "provider": "vast",
        "actual_gpu_type": "RTX4090",
    }
    mock_db = _build_db_mock(idempotency_event_exists=False)
    _run_deduct(job, mock_db)
    inserted = _inserted_event(mock_db)
    assert inserted["event_type"] == "burned"


def test_job_id_is_included():
    """Fallback event must include job_id for reconciliation."""
    job = {
        "job_id": "abc12345-0000-0000-0000-000000000000",
        "user_id": "u1",
        "started_at": 1_000_000.0,
        "completed_at": 1_003_600.0,
        "price_per_hr": 1.0,
        "vl_margin_pct": 0.20,
        "provider": "vast",
        "actual_gpu_type": "RTX4090",
    }
    mock_db = _build_db_mock(idempotency_event_exists=False)
    _run_deduct(job, mock_db)
    inserted = _inserted_event(mock_db)
    assert inserted["job_id"] == job["job_id"]


def test_idempotency_key_set():
    """stripe_payment_id must be 'fallback:{job_id}'."""
    job = {
        "job_id": "abc12345-0000-0000-0000-000000000000",
        "user_id": "u1",
        "started_at": 1_000_000.0,
        "completed_at": 1_003_600.0,
        "price_per_hr": 1.0,
        "vl_margin_pct": 0.20,
        "provider": "vast",
        "actual_gpu_type": "RTX4090",
    }
    mock_db = _build_db_mock(idempotency_event_exists=False)
    _run_deduct(job, mock_db)
    inserted = _inserted_event(mock_db)
    assert inserted["stripe_payment_id"] == f"fallback:{job['job_id']}"


def test_duplicate_call_skipped():
    """If fallback event already exists, insert must NOT be called again."""
    job = {
        "job_id": "abc12345-0000-0000-0000-000000000000",
        "user_id": "u1",
        "started_at": 1_000_000.0,
        "completed_at": 1_003_600.0,
        "price_per_hr": 1.0,
        "vl_margin_pct": 0.20,
        "provider": "vast",
        "actual_gpu_type": "RTX4090",
    }
    mock_db = _build_db_mock(idempotency_event_exists=True)
    _run_deduct(job, mock_db)
    mock_db._credit_events.insert.assert_not_called()


def test_credits_ceil_not_truncated():
    """math.ceil(round(..., 4)) must not truncate e.g. 2.0 * 1.15 * 100 = 230."""
    # 2h @ $1/hr = $2, with 15% margin = $2.30 = 230 credits
    # int(2.0 * 1.15 * 100) = 229 due to IEEE 754 — must be 230
    job = {
        "job_id": "abc12345-0000-0000-0000-000000000000",
        "user_id": "u1",
        "started_at": 1_000_000.0,
        "completed_at": 1_007_200.0,  # 2h later
        "price_per_hr": 1.0,
        "vl_margin_pct": 0.15,
        "provider": "vast",
        "actual_gpu_type": "RTX4090",
    }
    mock_db = _build_db_mock(idempotency_event_exists=False)
    _run_deduct(job, mock_db)
    inserted = _inserted_event(mock_db)
    assert inserted["amount_credits"] == -230


def test_zero_cost_job_skipped():
    """If credits <= 0, no insert should be made."""
    job = {
        "job_id": "abc12345-0000-0000-0000-000000000000",
        "user_id": "u1",
        "started_at": 1_000_000.0,
        "completed_at": 1_000_000.0,  # 0 duration
        "price_per_hr": 0.0,
        "vl_margin_pct": 0.20,
        "provider": "vast",
        "actual_gpu_type": "RTX4090",
    }
    mock_db = _build_db_mock(idempotency_event_exists=False)
    _run_deduct(job, mock_db)
    mock_db._credit_events.insert.assert_not_called()


def test_default_margin_uses_vl_margin_pct_env():
    """When vl_margin_pct is missing, use VL_MARGIN_PCT like settle_instance()."""
    # 1h @ $1/hr with 40% margin = $1.40 = 140 credits
    job = {
        "job_id": "abc12345-0000-0000-0000-000000000000",
        "user_id": "u1",
        "started_at": 1_000_000.0,
        "completed_at": 1_003_600.0,
        "price_per_hr": 1.0,
        # no vl_margin_pct — default 0.20 should apply
        "provider": "vast",
        "actual_gpu_type": "RTX4090",
    }
    mock_db = _build_db_mock(idempotency_event_exists=False)
    with patch.dict(os.environ, {"VL_MARGIN_PCT": "0.40"}):
        _run_deduct(job, mock_db)
    inserted = _inserted_event(mock_db)
    assert inserted["amount_credits"] == -140


def test_cost_plus_user_overrides_margin():
    """cost_plus users use compute_markup_pct, matching settle_instance()."""
    job = {
        "job_id": "abc12345-0000-0000-0000-000000000000",
        "user_id": "u1",
        "started_at": 1_000_000.0,
        "completed_at": 1_003_600.0,
        "price_per_hr": 1.0,
        "provider": "vast",
        "actual_gpu_type": "RTX4090",
    }
    mock_db = _build_db_mock(
        idempotency_event_exists=False,
        user_row={"billing_model": "cost_plus", "compute_markup_pct": 0.15},
    )
    with patch.dict(os.environ, {"VL_MARGIN_PCT": "0.40"}):
        _run_deduct(job, mock_db)
    inserted = _inserted_event(mock_db)
    assert inserted["amount_credits"] == -115
