"""Tests for issue #131: dataset warmup rclone must be guarded by exit check.

Before this fix, rclone copy ran without checking its exit code, and
VAULTLAYER_LOCAL_DATA was always exported even on failure. Training could
start on an empty or partial dataset directory.

After this fix:
  - rclone copy is guarded with `|| { echo ...; exit 1; }`
  - VAULTLAYER_LOCAL_DATA is only exported after a successful copy
  - The background sync (rclone sync) remains non-fatal
  - All three startup paths are covered: VM-NVMe, container, and alternate-VM
"""
from __future__ import annotations

import os
import sys
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


def _make_broker_and_job(dataset_id: str = "ds-warmup-1"):
    """Broker + job with a dataset_id to exercise warmup paths."""
    job = SimpleNamespace(
        job_id="job-warmup-1",
        dataset_id=dataset_id,
        script_b64="",
        script_name="train.py",
        environment={},
        docker_image="ghcr.io/hector25/vl-training-base:1.0",
        resume_from_job_id=None,
        gpu_type=SimpleNamespace(value="RTX4090"),
        model_params_billion=None,
        training_mode="full",
        dataset_size_gb=None,
        dataset_location="",
        dataset_region="",
    )
    broker = MagicMock()
    broker.config = SimpleNamespace(
        cloudflare=SimpleNamespace(
            r2_bucket="vl-test-bucket",
            r2_access_key_id="key",
            r2_secret_access_key="secret",
            r2_endpoint="https://r2.test",
        ),
        redis=SimpleNamespace(url="redis://test"),
    )
    broker._get_managed_credentials = MagicMock(return_value=None)
    return broker, job


def _make_broker_and_job_no_dataset():
    broker, job = _make_broker_and_job()
    job.dataset_id = None
    return broker, job


# ── VM startup (NVMe path) ────────────────────────────────────────────────────

def test_vm_startup_dataset_warmup_has_exit_guard():
    """VM startup script must guard rclone copy with an exit 1 on failure."""
    from agents.broker.startup_scripts import build_vm_startup_script

    broker, job = _make_broker_and_job()
    script = build_vm_startup_script(broker, job)

    assert "rclone copy" in script, "rclone copy must be present for dataset warmup"
    assert "exit 1" in script, "warmup failure must call exit 1"
    # The guard `|| {` must appear on the same logical shell command
    assert "|| {" in script, "rclone copy must be guarded with || { ...; exit 1; }"


def test_vm_startup_vaultlayer_local_data_exported_after_rclone():
    """VAULTLAYER_LOCAL_DATA must appear AFTER the rclone copy guard in the script."""
    from agents.broker.startup_scripts import build_vm_startup_script

    broker, job = _make_broker_and_job()
    script = build_vm_startup_script(broker, job)

    rclone_pos = script.find("rclone copy")
    export_pos = script.find("export VAULTLAYER_LOCAL_DATA")
    assert rclone_pos != -1, "rclone copy must be present"
    assert export_pos != -1, "VAULTLAYER_LOCAL_DATA must be exported"
    assert export_pos > rclone_pos, \
        "VAULTLAYER_LOCAL_DATA must be exported AFTER the rclone copy (not before)"


def test_vm_startup_background_sync_is_nonfatal():
    """Background rclone sync must NOT call exit 1 — it is non-fatal."""
    from agents.broker.startup_scripts import build_vm_startup_script

    broker, job = _make_broker_and_job()
    script = build_vm_startup_script(broker, job)

    lines = script.split("\n")
    sync_lines = [l for l in lines if "rclone sync" in l and "nohup" in l]
    assert len(sync_lines) >= 1, "background rclone sync must be present"
    for l in sync_lines:
        assert "exit 1" not in l, \
            f"background sync must NOT call exit 1 (it is non-fatal): {l}"


def test_vm_startup_no_dataset_no_local_data_export():
    """Without a dataset_id, VAULTLAYER_LOCAL_DATA must not be shell-exported."""
    from agents.broker.startup_scripts import build_vm_startup_script

    broker, job = _make_broker_and_job_no_dataset()
    script = build_vm_startup_script(broker, job)

    assert "export VAULTLAYER_LOCAL_DATA" not in script, \
        "VAULTLAYER_LOCAL_DATA must not be exported without a dataset_id"


# ── Container startup ─────────────────────────────────────────────────────────

def test_container_startup_dataset_warmup_has_exit_guard():
    """Container startup script must guard rclone copy with exit 1."""
    from agents.broker.startup_scripts import build_container_onstart

    broker, job = _make_broker_and_job()
    script = build_container_onstart(broker, job)

    assert "rclone copy" in script, "rclone copy must be present"
    assert "exit 1" in script, "container warmup failure must call exit 1"
    assert "|| {" in script, "container rclone copy must be guarded with || { ...; exit 1; }"


def test_container_startup_vaultlayer_local_data_after_rclone():
    """Container: VAULTLAYER_LOCAL_DATA exported only after successful rclone."""
    from agents.broker.startup_scripts import build_container_onstart

    broker, job = _make_broker_and_job()
    script = build_container_onstart(broker, job)

    rclone_pos = script.find("rclone copy")
    export_pos = script.find("export VAULTLAYER_LOCAL_DATA")
    assert rclone_pos != -1
    assert export_pos != -1
    assert export_pos > rclone_pos, \
        "VAULTLAYER_LOCAL_DATA must be exported AFTER rclone copy in container script"
