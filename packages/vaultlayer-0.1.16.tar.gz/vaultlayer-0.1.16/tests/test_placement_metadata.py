"""Tests for issue #129 — provider placement metadata persisted and used for fencing.

Before this fix, provisioning selected a concrete zone/region (e.g. GCP us-central1-a
or AWS us-west-2 via spot fallback) but stored only a bare instance_id on job_runs.
The fence path built a minimal job shim with only job_id, so after a restart the GCP
fence would fall back to the config default zone instead of the actual zone — the DELETE
call would target the wrong zone, get NOT_FOUND, and (before #130) treat it as success.

The fix: capture the actual placement (zone/region) from the provider's in-process cache
immediately after provision, store it on job["_placement"], persist it to
job_runs.metadata["placement"] during the provisioning update, and include it in
the fence job shim. On recovery, the placement is loaded back from job_runs.metadata.
"""
from __future__ import annotations

import os
import sys
import time
from types import SimpleNamespace
from unittest.mock import MagicMock, patch, AsyncMock

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


# ── Placement capture after provision ────────────────────────────────────────

def test_gcp_placement_captured_from_sa_info():
    """After GCP provision, zone is extracted from broker._gcp_sa_info and set on job."""
    # Simulate the placement-capture code from _try_provision_job
    broker = MagicMock()
    broker._gcp_sa_info = {
        "vl-abc12345-a10g": {
            "zone": "us-central1-a",
            "project_id": "vaultlayer-prod",
        }
    }
    result = "vl-abc12345-a10g"
    provider_db_name = "gcp"
    job = {}

    # Reproduce the capture logic
    _placement = {}
    if provider_db_name == "gcp":
        _gcp_info = getattr(broker, "_gcp_sa_info", {}).get(result, {})
        if _gcp_info.get("zone"):
            _placement["zone"] = _gcp_info["zone"]
            _placement["project_id"] = _gcp_info.get("project_id", "")
    if _placement:
        job["_placement"] = _placement

    assert job["_placement"]["zone"] == "us-central1-a"
    assert job["_placement"]["project_id"] == "vaultlayer-prod"


def test_aws_placement_captures_region():
    """After AWS provision, region is captured from model_job."""
    model_job = SimpleNamespace(region="us-west-2", current_hourly_rate=0)
    provider_db_name = "aws"
    job = {}

    _placement = {}
    if provider_db_name == "aws":
        _placement["region"] = (
            getattr(model_job, "region", "") or job.get("region", "")
        )
    if _placement:
        job["_placement"] = _placement

    assert job["_placement"]["region"] == "us-west-2"


def test_no_placement_for_lambda():
    """Lambda Labs (and other non-GCP/AWS providers) do not set _placement."""
    provider_db_name = "lambda_labs"
    job = {}

    _placement = {}
    # Only GCP and AWS are captured in the current implementation
    if provider_db_name == "gcp":
        _placement["zone"] = "us-central1-a"
    elif provider_db_name == "aws":
        _placement["region"] = "us-east-1"
    if _placement:
        job["_placement"] = _placement

    assert "_placement" not in job


# ── Fence job shim includes placement ────────────────────────────────────────

def test_fence_shim_includes_zone():
    """The fence job shim constructed in _terminate_and_settle includes zone."""
    # Reproduce the shim construction logic
    job = {
        "job_id": "job-abc123",
        "_placement": {"zone": "us-central1-a", "project_id": "proj"},
    }
    _placement = job.get("_placement") or {}
    _job_shim = SimpleNamespace(
        job_id=job.get("job_id", ""),
        zone=_placement.get("zone"),
        region=_placement.get("region"),
    )
    assert _job_shim.zone == "us-central1-a"
    assert _job_shim.job_id == "job-abc123"
    assert _job_shim.region is None


def test_fence_shim_empty_placement():
    """Fence job shim handles missing _placement gracefully."""
    job = {"job_id": "job-xyz", "_placement": {}}
    _placement = job.get("_placement") or {}
    _job_shim = SimpleNamespace(
        job_id=job.get("job_id", ""),
        zone=_placement.get("zone"),
        region=_placement.get("region"),
    )
    assert _job_shim.zone is None
    assert _job_shim.region is None


# ── Recovery loads placement from DB metadata ─────────────────────────────────

def test_recovery_loads_placement_from_metadata():
    """Recovered running jobs include _placement from job_runs.metadata."""
    import time
    from datetime import datetime, timezone

    prov_ts = time.time() - 60
    prov_iso = datetime.fromtimestamp(prov_ts, tz=timezone.utc).isoformat()
    row = {
        "run_id": "run-abc",
        "job_id": "job-gcp-1",
        "account_id": "user-1",
        "instance_id": "vl-abc12345-a10g",
        "provider": "gcp",
        "gpu_type": "A100_40GB",
        "rate_per_hr": 3.5,
        "status": "running",
        "spend_ledger_id": "sl-1",
        "provisioned_at": prov_iso,
        "docker_image": "",
        "queue_state": {},
        "metadata": {"placement": {"zone": "us-central1-c", "project_id": "vaultlayer-prod"}},
    }

    # Simulate recovery dict construction
    _meta = row.get("metadata") or {}
    _recovered_placement = _meta.get("placement") or {}
    job = {
        "job_id": row["job_id"],
        "_placement": _recovered_placement,
        "_run_id": row["run_id"],
    }

    assert job["_placement"]["zone"] == "us-central1-c"
    assert job["_placement"]["project_id"] == "vaultlayer-prod"


def test_recovery_handles_no_metadata():
    """Recovery works for rows without metadata (pre-fix rows)."""
    import time
    from datetime import datetime, timezone

    prov_ts = time.time() - 60
    prov_iso = datetime.fromtimestamp(prov_ts, tz=timezone.utc).isoformat()
    row = {
        "run_id": "run-old",
        "job_id": "job-old-1",
        "account_id": "user-1",
        "instance_id": "inst-old",
        "provider": "lambda_labs",
        "gpu_type": "A100_40GB",
        "rate_per_hr": 2.5,
        "status": "running",
        "spend_ledger_id": "sl-1",
        "provisioned_at": prov_iso,
        "docker_image": "",
        "queue_state": {},
        "metadata": None,  # Old row without metadata
    }

    _meta = row.get("metadata") or {}
    _recovered_placement = _meta.get("placement") or {}
    job = {
        "job_id": row["job_id"],
        "_placement": _recovered_placement,
    }

    assert job["_placement"] == {}


def test_record_provision_persists_placement_for_existing_run(monkeypatch):
    """Submit-time queued rows receive placement metadata when provisioned."""
    from datetime import datetime, timezone
    from shared import job_run_logger as jrl

    updates = []
    monkeypatch.setattr(jrl, "update_run", lambda run_id, **fields: updates.append((run_id, fields)))

    run_id = jrl.record_provision(
        job_id="job-gcp-1",
        provider="gcp",
        gpu_type="A100_40GB",
        instance_id="vl-abc12345-a10g",
        provisioned_at=datetime.now(timezone.utc),
        rate_per_hr=3.5,
        account_id="user-1",
        existing_run_id="run-abc",
        metadata={"placement": {"zone": "us-central1-c", "project_id": "vaultlayer-prod"}},
    )

    assert run_id == "run-abc"
    assert updates[0][0] == "run-abc"
    assert updates[0][1]["metadata"]["placement"]["zone"] == "us-central1-c"
