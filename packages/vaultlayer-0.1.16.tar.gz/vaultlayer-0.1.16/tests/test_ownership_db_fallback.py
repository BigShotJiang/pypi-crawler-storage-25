"""
Tests for issue #127: require_job_ownership() DB fallback.

Verifies:
- In-memory hit is returned directly (no DB call)
- DB fallback fires when explicitly enabled and job is absent from _active_jobs
- DB fallback returns a minimal job dict with correct fields
- Cross-tenant DB row raises 404 (same as missing job)
- DB error falls through to 404 (fail-closed)
- _db_only sentinel is set on DB-backed jobs
"""
from unittest.mock import MagicMock, patch

import pytest
from fastapi import HTTPException


def _make_db_mock(row=None, raise_exc=None):
    """Build a db mock for the chained .select().eq().order().limit().execute() call."""
    mock_db = MagicMock()
    exec_mock = MagicMock()
    if raise_exc:
        exec_mock.side_effect = raise_exc
    else:
        exec_mock.return_value = MagicMock(data=[row] if row else [])
    (
        mock_db.table.return_value
        .select.return_value
        .eq.return_value
        .order.return_value
        .limit.return_value
        .execute
    ) = exec_mock
    return mock_db


USER = {"user_id": "u1"}
OTHER_USER = {"user_id": "u2"}
JOB_ID = "job-abc-123"

IN_MEMORY_JOB = {
    "job_id": JOB_ID,
    "user_id": "u1",
    "status": "running",
}

DB_ROW = {
    "job_id": JOB_ID,
    "account_id": "u1",
    "status": "completed",
    "provider": "vast",
    "gpu_type": "RTX4090",
    "rate_per_hr": 0.5,
    "instance_id": None,
    "created_at": "2026-01-01T00:00:00Z",
    "provisioned_at": None,
    "completed_at": None,
    "failed_at": None,
    "failure_reason": None,
    "metadata": {},
    "queue_state": {"script_b64": "abc", "environment": {"KEY": "val"}},
}


def _run(job_id, user, active_jobs, *, allow_db_fallback=False):
    from api.auth import require_job_ownership
    return require_job_ownership(
        job_id,
        user,
        active_jobs,
        allow_db_fallback=allow_db_fallback,
    )


def test_in_memory_hit_no_db_call():
    """When job is in _active_jobs, DB must NOT be queried."""
    mock_db = _make_db_mock(DB_ROW)
    with patch("api.auth.get_db", return_value=mock_db):
        result = _run(JOB_ID, USER, {JOB_ID: IN_MEMORY_JOB})
    mock_db.table.assert_not_called()
    assert result is IN_MEMORY_JOB


def test_missing_job_without_fallback_raises_404_no_db_call():
    """Mutation callers keep live-job-only behavior unless fallback is explicit."""
    mock_db = _make_db_mock(DB_ROW)
    with patch("api.auth.get_db", return_value=mock_db):
        with pytest.raises(HTTPException) as exc_info:
            _run(JOB_ID, USER, {})
    mock_db.table.assert_not_called()
    assert exc_info.value.status_code == 404


def test_db_fallback_returns_job():
    """When job absent from _active_jobs, DB fallback returns a job dict."""
    mock_db = _make_db_mock(DB_ROW)
    with patch("api.auth.get_db", return_value=mock_db):
        result = _run(JOB_ID, USER, {}, allow_db_fallback=True)
    assert result["job_id"] == JOB_ID
    assert result["status"] == "completed"
    assert result["user_id"] == "u1"


def test_db_fallback_sets_db_only_sentinel():
    """DB-backed jobs must have _db_only=True so callers can detect them."""
    mock_db = _make_db_mock(DB_ROW)
    with patch("api.auth.get_db", return_value=mock_db):
        result = _run(JOB_ID, USER, {}, allow_db_fallback=True)
    assert result.get("_db_only") is True


def test_db_fallback_preserves_queue_state():
    """script_b64 and environment from queue_state must be in the returned dict."""
    mock_db = _make_db_mock(DB_ROW)
    with patch("api.auth.get_db", return_value=mock_db):
        result = _run(JOB_ID, USER, {}, allow_db_fallback=True)
    assert result["script_b64"] == "abc"
    assert result["environment"] == {"KEY": "val"}


def test_db_fallback_cross_tenant_raises_404():
    """DB row owned by another user must raise 404 (same as missing job)."""
    mock_db = _make_db_mock(DB_ROW)
    with patch("api.auth.get_db", return_value=mock_db):
        with pytest.raises(HTTPException) as exc_info:
            _run(JOB_ID, OTHER_USER, {}, allow_db_fallback=True)
    assert exc_info.value.status_code == 404


def test_db_fallback_missing_row_raises_404():
    """When DB returns no rows, must raise 404."""
    mock_db = _make_db_mock(row=None)
    with patch("api.auth.get_db", return_value=mock_db):
        with pytest.raises(HTTPException) as exc_info:
            _run(JOB_ID, USER, {}, allow_db_fallback=True)
    assert exc_info.value.status_code == 404


def test_db_error_raises_404():
    """DB exception must fail-closed: raise 404, not 500."""
    mock_db = _make_db_mock(raise_exc=RuntimeError("connection refused"))
    with patch("api.auth.get_db", return_value=mock_db):
        with pytest.raises(HTTPException) as exc_info:
            _run(JOB_ID, USER, {}, allow_db_fallback=True)
    assert exc_info.value.status_code == 404


def test_in_memory_cross_tenant_raises_404():
    """Cross-tenant in-memory job must still raise 404."""
    with pytest.raises(HTTPException) as exc_info:
        _run(JOB_ID, OTHER_USER, {JOB_ID: IN_MEMORY_JOB})
    assert exc_info.value.status_code == 404


def test_db_fallback_tolerates_null_metadata():
    """Historical rows can have null metadata; status fallback must not 500."""
    row = dict(DB_ROW)
    row["metadata"] = None
    row["queue_state"] = {}
    mock_db = _make_db_mock(row)
    with patch("api.auth.get_db", return_value=mock_db):
        result = _run(JOB_ID, USER, {}, allow_db_fallback=True)
    assert result["docker_image"] == ""
