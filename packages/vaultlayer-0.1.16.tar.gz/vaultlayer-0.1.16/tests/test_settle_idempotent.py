"""
Tests for #149/#152 — settle_instance() atomicity, idempotency, and reconciliation.

Key properties tested:
1. Atomic conditional UPDATE (settled=False CAS): only one concurrent caller wins
2. Idempotent credit event: keyed by stripe_payment_id="settle:{spend_id}"
3. Partial-failure recovery: if ledger settled but credit event missing, create it
4. Double-settle: loser with existing event skips credit insert (no double-charge)
5. Burn-loop reconciliation: settle charges only the residual after prior burns (#149)
6. Multi-leg migration: cumulative reconciliation prevents zero-charge on later legs
7. Unique constraint: concurrent credit event insert treated as idempotent success
"""
import math
from datetime import datetime, timezone
from unittest.mock import MagicMock, call

import pytest


def _make_row(
    spend_id="sp-1",
    user_id="u-1",
    job_id="job-1",
    provider="runpod",
    gpu_type="A100",
    rate_per_hr=2.0,
    is_test=False,
    settled=False,
    vl_margin_pct=0.40,
):
    return {
        "id": spend_id,
        "user_id": user_id,
        "job_id": job_id,
        "provider": provider,
        "gpu_type": gpu_type,
        "rate_per_hr": rate_per_hr,
        "is_test": is_test,
        "settled": settled,
        "vl_margin_pct": vl_margin_pct,
        "provisioned_at": "2026-04-26T10:00:00",
    }


def _build_db_mock(
    row,
    settle_wins=True,
    event_exists=False,
    prior_burn_credits=0,
    prior_leg_credits=0,
):
    db = MagicMock()
    sl = MagicMock()

    settled_row = dict(
        row,
        settled=True,
        user_charged_usd=2.80,
        credits_charged=280.0,
        billing_seconds=3600.0,
        estimated_cost_usd=2.0,
    )

    fetch_res = MagicMock(data=[row])
    refetch_res = MagicMock(data=[settled_row])
    prior_legs_res = MagicMock(
        data=[{"credits_charged": prior_leg_credits}] if prior_leg_credits > 0 else []
    )

    fetch_call_count = [0]

    def _sl_select(columns="*"):
        m = MagicMock()
        if "credits_charged" in str(columns) and "*" not in str(columns):
            m.eq.return_value.eq.return_value.neq.return_value.execute.return_value = prior_legs_res
        else:
            fetch_call_count[0] += 1
            if fetch_call_count[0] == 1:
                m.eq.return_value.execute.return_value = fetch_res
            else:
                m.eq.return_value.execute.return_value = refetch_res
        return m

    sl.select.side_effect = _sl_select

    update_res = MagicMock(data=[row] if settle_wins else [])
    _sl_update = MagicMock()
    _sl_update.eq.return_value.eq.return_value.execute.return_value = update_res
    sl.update.return_value = _sl_update

    ce = MagicMock()
    event_check_res = MagicMock(data=[{"id": "ev-existing"}] if event_exists else [])

    burn_events = []
    if prior_burn_credits > 0:
        burn_events = [{"amount_credits": -prior_burn_credits, "stripe_payment_id": None}]
    prior_burns_res = MagicMock(data=burn_events)

    def _ce_select(*args, **kwargs):
        m = MagicMock()
        col = args[0] if args else ""
        if col == "id":
            m.eq.return_value.limit.return_value.execute.return_value = event_check_res
        else:
            m.eq.return_value.eq.return_value.execute.return_value = prior_burns_res
        return m

    ce.select.side_effect = _ce_select
    ce.insert.return_value.execute.return_value = MagicMock(data=[{"id": "ev-new"}])

    um = MagicMock()
    um.select.return_value.eq.return_value.execute.return_value = MagicMock(data=[])

    def _table(name):
        if name == "spend_ledger":
            return sl
        if name == "credit_events":
            return ce
        if name == "users":
            return um
        return MagicMock()

    db.table.side_effect = _table
    return db, sl, ce


@pytest.fixture(autouse=True)
def _patch_internals(monkeypatch):
    monkeypatch.setattr("shared.spend._db_call", lambda fn, label="": fn())
    try:
        import api.db as _api_db
        _mock_ace = MagicMock(return_value=None)
        _orig_ace = _api_db.add_credit_event
        _api_db.add_credit_event = _mock_ace
        yield _mock_ace
        _api_db.add_credit_event = _orig_ace
    except Exception:
        yield MagicMock()


_TERMINATED = datetime(2026, 4, 26, 11, 0, 0, tzinfo=timezone.utc)


def test_settle_uses_conditional_update_filter(monkeypatch):
    row = _make_row()
    db, sl, ce = _build_db_mock(row, settle_wins=True)
    monkeypatch.setattr("shared.spend._get_db", lambda: db)

    from shared.spend import settle_instance
    result = settle_instance(spend_id="sp-1", terminated_at=_TERMINATED)

    assert result is not None
    sl.update.return_value.eq.return_value.eq.assert_called_with("settled", False)


def test_settle_winner_inserts_credit_event_with_idempotency_key(_patch_internals, monkeypatch):
    row = _make_row()
    db, sl, ce = _build_db_mock(row, settle_wins=True, event_exists=False)
    monkeypatch.setattr("shared.spend._get_db", lambda: db)

    from shared.spend import settle_instance
    settle_instance(spend_id="sp-1", terminated_at=_TERMINATED)

    _patch_internals.assert_called_once()
    kwargs = _patch_internals.call_args.kwargs
    assert kwargs["stripe_payment_id"] == "settle:sp-1"
    assert kwargs["event_type"] == "burned"
    assert kwargs["amount_credits"] < 0


def test_settle_loser_skips_insert_when_event_exists(_patch_internals, monkeypatch):
    row = _make_row()
    db, sl, ce = _build_db_mock(row, settle_wins=False, event_exists=True)
    monkeypatch.setattr("shared.spend._get_db", lambda: db)

    from shared.spend import settle_instance
    settle_instance(spend_id="sp-1", terminated_at=_TERMINATED)

    _patch_internals.assert_not_called()


def test_partial_failure_recovery_inserts_missing_event(_patch_internals, monkeypatch):
    row = _make_row()
    db, sl, ce = _build_db_mock(row, settle_wins=False, event_exists=False)
    monkeypatch.setattr("shared.spend._get_db", lambda: db)

    from shared.spend import settle_instance
    settle_instance(spend_id="sp-1", terminated_at=_TERMINATED)

    _patch_internals.assert_called_once()
    kwargs = _patch_internals.call_args.kwargs
    assert kwargs["stripe_payment_id"] == "settle:sp-1"


def test_test_jobs_skip_credit_deduction(_patch_internals, monkeypatch):
    row = _make_row(is_test=True)
    db, sl, ce = _build_db_mock(row, settle_wins=True)
    monkeypatch.setattr("shared.spend._get_db", lambda: db)

    from shared.spend import settle_instance
    settle_instance(spend_id="sp-1", terminated_at=_TERMINATED)

    _patch_internals.assert_not_called()


def test_settle_charges_residual_after_partial_burn(_patch_internals, monkeypatch):
    row = _make_row()
    db, sl, ce = _build_db_mock(row, settle_wins=True, prior_burn_credits=100)
    monkeypatch.setattr("shared.spend._get_db", lambda: db)

    from shared.spend import settle_instance
    settle_instance(spend_id="sp-1", terminated_at=_TERMINATED)

    _patch_internals.assert_called_once()
    kwargs = _patch_internals.call_args.kwargs
    assert kwargs["amount_credits"] == -180


def test_settle_skips_deduction_when_burns_cover_full_amount(_patch_internals, monkeypatch):
    row = _make_row()
    db, sl, ce = _build_db_mock(row, settle_wins=True, prior_burn_credits=300)
    monkeypatch.setattr("shared.spend._get_db", lambda: db)

    from shared.spend import settle_instance
    settle_instance(spend_id="sp-1", terminated_at=_TERMINATED)

    _patch_internals.assert_not_called()


def test_settle_multileg_cumulative_due_covers_prior_legs(_patch_internals, monkeypatch):
    """
    2-leg migration: leg2 settle must include leg1 credits_charged in cumulative_due.

    Leg 1 settled: credits_charged=200
    Leg 1 settle event: -200cr (stripe_payment_id='settle:sp-leg1')
    Submit reservation: -100cr (stripe_payment_id='submit:job-1')
    Leg 2 settling: credits_charged=280cr

    cumulative_due = 280 (leg2) + 200 (leg1) = 480
    prior_burned = 200 (leg1 settle) + 100 (submit) = 300
    residual = 480 - 300 = 180
    """
    row = _make_row(spend_id="sp-2", job_id="job-1")
    db = MagicMock()
    sl = MagicMock()

    settled_row = dict(row, settled=True, user_charged_usd=2.80, credits_charged=280.0,
                       billing_seconds=3600.0, estimated_cost_usd=2.0)
    fetch_res = MagicMock(data=[row])
    prior_legs_res = MagicMock(data=[{"credits_charged": 200.0}])

    fetch_call_count = [0]

    def _sl_select(columns="*"):
        m = MagicMock()
        if "credits_charged" in str(columns) and "*" not in str(columns):
            m.eq.return_value.eq.return_value.neq.return_value.execute.return_value = prior_legs_res
        else:
            fetch_call_count[0] += 1
            m.eq.return_value.execute.return_value = fetch_res
        return m

    sl.select.side_effect = _sl_select
    update_res = MagicMock(data=[row])
    sl.update.return_value.eq.return_value.eq.return_value.execute.return_value = update_res

    ce = MagicMock()
    event_check_res = MagicMock(data=[])
    prior_burns = [
        {"amount_credits": -200, "stripe_payment_id": "settle:sp-leg1"},
        {"amount_credits": -100, "stripe_payment_id": "submit:job-1"},
    ]
    prior_burns_res = MagicMock(data=prior_burns)

    def _ce_select(*args, **kwargs):
        m = MagicMock()
        col = args[0] if args else ""
        if col == "id":
            m.eq.return_value.limit.return_value.execute.return_value = event_check_res
        else:
            m.eq.return_value.eq.return_value.execute.return_value = prior_burns_res
        return m

    ce.select.side_effect = _ce_select
    um = MagicMock()
    um.select.return_value.eq.return_value.execute.return_value = MagicMock(data=[])

    def _table(name):
        if name == "spend_ledger": return sl
        if name == "credit_events": return ce
        if name == "users": return um
        return MagicMock()

    db.table.side_effect = _table
    monkeypatch.setattr("shared.spend._get_db", lambda: db)

    from shared.spend import settle_instance
    settle_instance(spend_id="sp-2", terminated_at=_TERMINATED)

    _patch_internals.assert_called_once()
    kwargs = _patch_internals.call_args.kwargs
    assert kwargs["amount_credits"] == -180, (
        f"Expected -180 (cumulative residual), got {kwargs['amount_credits']}. "
        "Multi-leg reconciliation must include prior settled legs in cumulative_due."
    )


def test_settle_multileg_prior_legs_query_excludes_current_leg(monkeypatch):
    """prior_settled_legs query must use .neq('id', spend_id) to exclude the current leg."""
    import inspect
    from shared import spend

    src = inspect.getsource(spend.settle_instance)
    assert '.neq("id", spend_id)' in src or ".neq('id', spend_id)" in src, (
        "prior_settled_legs query must exclude current leg with .neq('id', spend_id)"
    )


def test_settle_unique_violation_treated_as_idempotent_success(_patch_internals, monkeypatch):
    """Unique constraint violation on credit event insert is treated as idempotent success."""
    row = _make_row()
    db, sl, ce = _build_db_mock(row, settle_wins=True, event_exists=False)
    monkeypatch.setattr("shared.spend._get_db", lambda: db)

    _patch_internals.side_effect = Exception(
        'duplicate key value violates unique constraint "credit_events_stripe_payment_id_uq"'
    )

    from shared.spend import settle_instance
    result = settle_instance(spend_id="sp-1", terminated_at=_TERMINATED)

    assert result is not None
    assert result.get("credits_charged") is not None
