import os
from unittest.mock import AsyncMock, MagicMock, patch

from click.testing import CliRunner


def test_restart_uses_api_url_before_fetch(monkeypatch):
    """Restart must use the managed API URL for the initial status lookup."""
    from cli.restart import restart

    monkeypatch.setenv("VAULTLAYER_TOKEN", "vl_test_restart")
    monkeypatch.setenv("VAULTLAYER_API_URL", "https://api.test")

    job_info = {
        "status": "suspended",
        "job_name": "job-one",
        "provider": "runpod",
        "gpu_type": "H100_80GB_SXM",
        "price_per_hr": 1.23,
        "command": "python train.py",
        "docker_image": "",
    }

    runner = CliRunner()
    with patch("shared.env_utils.load_vaultlayer_env"), \
         patch("cli.restart._fetch_job_info", return_value=job_info) as fetch, \
         patch("cli.restart._check_balance", return_value=10.0), \
         patch("cli.restart._find_latest_checkpoint", return_value=None), \
         patch("cli.run.RunCommand.execute", new_callable=AsyncMock):
        result = runner.invoke(restart, ["--job-id", "job-123", "--yes"])

    assert result.exit_code == 0, result.output
    fetch.assert_called_once_with(
        "job-123",
        token="vl_test_restart",
        api_url="https://api.test",
    )


def test_restart_preserves_quoted_command_and_resume_namespace(monkeypatch):
    """Restart must pass structured argv and the prior job namespace to run."""
    from cli.restart import restart

    monkeypatch.setenv("VAULTLAYER_TOKEN", "vl_test_restart")
    monkeypatch.setenv("VAULTLAYER_API_URL", "https://api.test")

    job_info = {
        "status": "failed",
        "job_name": "job-two",
        "provider": "runpod",
        "gpu_type": "H100_80GB_SXM",
        "price_per_hr": 1.23,
        "command": 'python train.py --run-name "my run"',
        "docker_image": "",
    }
    captured = {}

    class FakeRunCommand:
        def __init__(self, **kwargs):
            captured["kwargs"] = kwargs
        async def execute(self):
            captured["resume_from_job_id"] = self.resume_from_job_id

    runner = CliRunner()
    with patch("shared.env_utils.load_vaultlayer_env"), \
         patch("cli.restart._fetch_job_info", return_value=job_info), \
         patch("cli.restart._check_balance", return_value=10.0), \
         patch("cli.restart._find_latest_checkpoint", return_value=None), \
         patch("cli.run.RunCommand", FakeRunCommand):
        result = runner.invoke(restart, ["--job-id", "job-old", "--yes"])

    assert result.exit_code == 0, result.output
    assert captured["kwargs"]["command"] == [
        "python",
        "train.py",
        "--run-name",
        "my run",
    ]
    assert captured["resume_from_job_id"] == "job-old"


def test_check_balance_uses_available_usd_without_cent_conversion():
    """Credits API exposes available_usd in dollars, not cents."""
    from cli.restart import _check_balance

    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {"available_usd": 99.99, "available_credits": 9999}

    with patch("httpx.get", return_value=resp):
        assert _check_balance("https://api.test", "vl_test") == 99.99


def test_check_balance_falls_back_to_available_credits_cents():
    """When available_usd is absent, available_credits still converts cents to dollars."""
    from cli.restart import _check_balance

    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {"available_credits": 1234}

    with patch("httpx.get", return_value=resp):
        assert _check_balance("https://api.test", "vl_test") == 12.34


def test_find_latest_checkpoint_supports_hf_and_raw_prefixes():
    """Restart display should find current HF checkpoint-N and raw step-N dirs."""
    from cli.restart import _find_latest_checkpoint

    r2 = {
        "endpoint": "https://r2.test",
        "access_key_id": "key",
        "secret_access_key": "secret",
        "bucket": "bucket",
    }
    s3 = MagicMock()
    s3.list_objects_v2.side_effect = [
        {
            "CommonPrefixes": [
                {"Prefix": "checkpoints/job-1/step-9/"},
                {"Prefix": "checkpoints/job-1/checkpoint-12/"},
            ]
        },
        {"Contents": [{"Key": "checkpoints/job-1/checkpoint-12/model.bin", "Size": 2048}]},
    ]

    with patch("shared.r2_utils.get_r2_credentials", return_value=r2), \
         patch("boto3.client", return_value=s3):
        result = _find_latest_checkpoint("job-1")

    assert result["step"] == 12
    assert result["size_bytes"] == 2048
    assert s3.list_objects_v2.call_args_list[1].kwargs["Prefix"] == (
        "checkpoints/job-1/checkpoint-12/"
    )
