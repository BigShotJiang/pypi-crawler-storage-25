"""
API layer coverage tests — targeting 99% coverage across:
  src/api/auth.py, credits.py, db.py, main.py, feedback_routes.py,
  email.py, stripe_routes.py, fraud.py, models.py

Strategy: FastAPI TestClient + aggressive mocking of Supabase / Stripe / Resend.
"""
from __future__ import annotations

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import hashlib
import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch, call


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_db_mock():
    """Return a MagicMock that chains .table().select().eq().execute() etc."""
    db = MagicMock()
    # Default: empty result
    _empty = MagicMock(data=[])
    db.table.return_value.select.return_value.eq.return_value.execute.return_value = _empty
    db.table.return_value.insert.return_value.execute.return_value = MagicMock(data=[{"id": "fb_001"}])
    db.table.return_value.update.return_value.eq.return_value.execute.return_value = MagicMock(data=[])
    db.table.return_value.upsert.return_value.execute.return_value = MagicMock(data=[])
    return db


def _user_row(user_id="usr_test", email="user@example.com"):
    return {"user_id": user_id, "email": email, "plan": "pro",
            "signup_bonus_released": False, "stripe_customer_id": None}


def _balance(available=5000, balance=5000, reserved=0, spent=0):
    return {
        "user_id": "usr_test",
        "available_credits": available,
        "balance_credits": balance,
        "reserved_credits": reserved,
        "spent_credits": spent,
        "available_usd": round(available / 100, 2),
    }


# ---------------------------------------------------------------------------
# TestClient fixture
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def client():
    """Build the FastAPI test client with all external I/O mocked."""
    mock_db = _make_db_mock()

    # Patch supabase create_client and resend at import time so the app can load
    with patch("api.db.create_client", return_value=mock_db), \
         patch("api.email.resend"):
        import api.db as db_mod
        db_mod.get_db.cache_clear()

        from fastapi.testclient import TestClient
        from api.main import app
        yield TestClient(app)


# ===========================================================================
# 1. main.py — routes
# ===========================================================================

class TestMainRoutes:
    def test_health(self, client, monkeypatch):
        # Clear any connectivity env vars leaked by other tests so health returns "ok"
        monkeypatch.delenv("UPSTASH_REDIS_URL", raising=False)
        monkeypatch.delenv("REDIS_URL", raising=False)
        monkeypatch.delenv("SUPABASE_URL", raising=False)
        monkeypatch.delenv("SUPABASE_SERVICE_KEY", raising=False)
        r = client.get("/health")
        assert r.status_code == 200
        assert r.json().get("status") == "ok"

    def test_clerk_webhook_other_event(self, client):
        """Non-user.created events should return {received: true} immediately."""
        payload = json.dumps({"type": "user.deleted", "data": {}}).encode()
        with patch("api.main.parse_clerk_webhook", new_callable=AsyncMock,
                   return_value={"type": "user.deleted", "data": {}}):
            r = client.post("/api/v1/auth/clerk-webhook",
                            content=payload,
                            headers={"content-type": "application/json"})
        assert r.status_code == 200
        assert r.json()["received"] is True

    def test_clerk_webhook_user_created_success(self, client):
        event = {
            "type": "user.created",
            "data": {
                "id": "usr_new",
                "email_addresses": [{"email_address": "new@example.com"}],
                "unsafe_metadata": {},
            },
        }
        with patch("api.main.parse_clerk_webhook", new_callable=AsyncMock, return_value=event), \
             patch("api.main.check_ip_rate_limit", new_callable=AsyncMock, return_value=(True, "ok")), \
             patch("api.main.create_user", new_callable=AsyncMock), \
             patch("api.main.create_api_token", new_callable=AsyncMock, return_value="vl_live_token123"), \
             patch("api.main.send_welcome", new_callable=AsyncMock):
            r = client.post("/api/v1/auth/clerk-webhook",
                            content=b"{}",
                            headers={"content-type": "application/json"})
        assert r.status_code == 200
        body = r.json()
        assert body["received"] is True
        assert body["user_id"] == "usr_new"

    def test_clerk_webhook_blocked_ip(self, client):
        event = {
            "type": "user.created",
            "data": {
                "id": "usr_blocked",
                "email_addresses": [{"email_address": "bad@example.com"}],
                "unsafe_metadata": {"signup_ip": "1.2.3.4"},
            },
        }
        with patch("api.main.parse_clerk_webhook", new_callable=AsyncMock, return_value=event), \
             patch("api.main.check_ip_rate_limit", new_callable=AsyncMock,
                   return_value=(False, "Too many accounts")):
            r = client.post("/api/v1/auth/clerk-webhook",
                            content=b"{}",
                            headers={"content-type": "application/json"})
        assert r.status_code == 200
        body = r.json()
        assert body["action"] == "blocked"

    def test_clerk_webhook_stale_timestamp_rejected(self, client, monkeypatch):
        """Webhook with svix-timestamp > 5 min old is rejected as replay."""
        import api.auth as auth_mod
        # Signature stub that would otherwise pass so only staleness is tested
        monkeypatch.setattr(auth_mod, "_verify_clerk_signature", lambda *a, **k: True)

        import time
        stale_ts = str(int(time.time()) - (10 * 60))  # 10 min old
        r = client.post(
            "/api/v1/auth/clerk-webhook",
            content=b'{"type": "user.created", "data": {}}',
            headers={
                "content-type": "application/json",
                "svix-id":        "msg_stale_001",
                "svix-timestamp": stale_ts,
                "svix-signature": "v1,AAAA",
            },
        )
        assert r.status_code == 400
        assert "too old" in r.json().get("detail", "").lower()

    def test_clerk_webhook_replay_suppressed(self, client, monkeypatch):
        """Second delivery of the same svix_id returns 200 without re-processing."""
        import api.auth as auth_mod
        monkeypatch.setattr(auth_mod, "_verify_clerk_signature", lambda *a, **k: True)
        # Clear the seen-id set for a clean test
        auth_mod._clerk_seen_ids.clear()
        auth_mod._clerk_seen_order.clear()

        import time
        ts = str(int(time.time()))
        headers = {
            "content-type": "application/json",
            "svix-id":        "msg_replay_001",
            "svix-timestamp": ts,
            "svix-signature": "v1,AAAA",
        }
        body = b'{"type": "user.updated", "data": {}}'

        # First delivery processes normally (user.updated is a no-op path)
        r1 = client.post("/api/v1/auth/clerk-webhook", content=body, headers=headers)
        assert r1.status_code == 200

        # Second delivery with same svix_id should be suppressed — main.py sees
        # None from parse_clerk_webhook and early-returns.
        r2 = client.post("/api/v1/auth/clerk-webhook", content=body, headers=headers)
        assert r2.status_code == 200
        # Confirm the suppression path was taken (received: true, no user_id)
        assert r2.json().get("received") is True

    def test_clerk_webhook_missing_user_id(self, client):
        """Missing user_id or email in data raises 400."""
        event = {
            "type": "user.created",
            "data": {
                "id": "",
                "email_addresses": [],
                "unsafe_metadata": {},
            },
        }
        with patch("api.main.parse_clerk_webhook", new_callable=AsyncMock, return_value=event), \
             patch("api.main.check_ip_rate_limit", new_callable=AsyncMock, return_value=(True, "ok")):
            r = client.post("/api/v1/auth/clerk-webhook",
                            content=b"{}",
                            headers={"content-type": "application/json"})
        assert r.status_code == 400

    def test_validate_token_valid(self, client):
        from api.models import TokenValidateResponse
        resp = TokenValidateResponse(valid=True, user_id="usr_1", email="x@x.com", balance_credits=1000)
        with patch("api.main.validate_token", new_callable=AsyncMock, return_value=resp):
            r = client.post("/api/v1/auth/validate", json={"token": "vl_live_abc"})
        assert r.status_code == 200

    def test_validate_token_invalid(self, client):
        from api.models import TokenValidateResponse
        resp = TokenValidateResponse(valid=False, message="Token not found or revoked")
        with patch("api.main.validate_token", new_callable=AsyncMock, return_value=resp):
            r = client.post("/api/v1/auth/validate",
                            json={"token": "bad_token"})
        assert r.status_code == 200
        assert r.json()["valid"] is False


# ===========================================================================
# 2. auth.py — require_auth, validate_token, webhook helpers
# ===========================================================================

class TestRequireAuth:
    @pytest.mark.asyncio
    async def test_missing_bearer_prefix(self):
        from fastapi import HTTPException
        from api.auth import require_auth
        with pytest.raises(HTTPException) as exc:
            await require_auth("Token abc")
        assert exc.value.status_code == 401

    @pytest.mark.asyncio
    async def test_invalid_token_format(self):
        from fastapi import HTTPException
        from api.auth import require_auth
        with pytest.raises(HTTPException) as exc:
            await require_auth("Bearer notavalidtoken")
        assert exc.value.status_code == 401

    @pytest.mark.asyncio
    async def test_invalid_token_rejected(self):
        """Invalid tokens must be rejected — no dev bypass exists."""
        from fastapi import HTTPException
        from api.auth import require_auth
        with patch("api.auth.get_user_by_token", new_callable=AsyncMock, return_value=None):
            with pytest.raises(HTTPException) as exc:
                await require_auth("Bearer vl_test_invalidtoken")
        assert exc.value.status_code == 401

    @pytest.mark.asyncio
    async def test_supabase_lookup_success(self):
        from api.auth import require_auth
        user = _user_row()
        with patch("api.auth.get_user_by_token", new_callable=AsyncMock, return_value=user):
            result = await require_auth("Bearer vl_live_goodtoken")
        assert result["user_id"] == "usr_test"

    @pytest.mark.asyncio
    async def test_supabase_lookup_returns_none(self):
        from fastapi import HTTPException
        from api.auth import require_auth
        with patch("api.auth.get_user_by_token", new_callable=AsyncMock, return_value=None):
            with pytest.raises(HTTPException) as exc:
                await require_auth("Bearer vl_live_unknown")
        assert exc.value.status_code == 401

    @pytest.mark.asyncio
    async def test_supabase_lookup_raises_exception(self):
        from fastapi import HTTPException
        from api.auth import require_auth
        with patch("api.auth.get_user_by_token", new_callable=AsyncMock,
                   side_effect=RuntimeError("db down")):
            with pytest.raises(HTTPException) as exc:
                await require_auth("Bearer vl_live_crash")
        assert exc.value.status_code == 503


class TestValidateToken:
    @pytest.mark.asyncio
    async def test_invalid_format(self):
        from api.auth import validate_token
        r = await validate_token("bad_token")
        assert r.valid is False
        assert "format" in r.message

    @pytest.mark.asyncio
    async def test_unknown_token_returns_invalid(self):
        """Unknown tokens must return valid=False — no dev bypass exists."""
        from api.auth import validate_token
        with patch("api.auth.get_user_by_token", new_callable=AsyncMock, return_value=None):
            r = await validate_token("vl_test_unknowntoken")
        assert r.valid is False

    @pytest.mark.asyncio
    async def test_supabase_error_returns_invalid(self):
        from api.auth import validate_token
        with patch("api.auth.get_user_by_token", new_callable=AsyncMock,
                   side_effect=Exception("db error")):
            r = await validate_token("vl_live_sometoken")
        assert r.valid is False
        assert "unavailable" in r.message

    @pytest.mark.asyncio
    async def test_token_not_found(self):
        from api.auth import validate_token
        with patch("api.auth.get_user_by_token", new_callable=AsyncMock, return_value=None):
            r = await validate_token("vl_live_unknown")
        assert r.valid is False

    @pytest.mark.asyncio
    async def test_valid_token_returns_balance(self):
        from api.auth import validate_token
        user = _user_row()
        with patch("api.auth.get_user_by_token", new_callable=AsyncMock, return_value=user), \
             patch("api.auth.get_balance", return_value={"available_credits": 999}):
            r = await validate_token("vl_live_valid")
        assert r.valid is True
        assert r.balance_credits == 999

    @pytest.mark.asyncio
    async def test_valid_token_balance_error_falls_back_to_zero(self):
        from api.auth import validate_token
        user = _user_row()
        with patch("api.auth.get_user_by_token", new_callable=AsyncMock, return_value=user), \
             patch("api.auth.get_balance", side_effect=Exception("view missing")):
            r = await validate_token("vl_live_valid2")
        assert r.valid is True
        assert r.balance_credits == 0


class TestClerkWebhookHelpers:
    def test_verify_clerk_signature_no_secret_returns_false(self):
        """When CLERK_WEBHOOK_SECRET is not configured, webhook verification fails-closed."""
        import api.auth as auth_mod
        original = auth_mod.CLERK_WEBHOOK_SECRET
        try:
            auth_mod.CLERK_WEBHOOK_SECRET = ""
            result = auth_mod._verify_clerk_signature(b"body", "id", "ts", "sig")
            assert result is False, "Must fail-closed when no webhook secret is configured"
        finally:
            auth_mod.CLERK_WEBHOOK_SECRET = original

    def test_verify_clerk_signature_bad_sig_returns_false(self):
        import api.auth as auth_mod
        original = auth_mod.CLERK_WEBHOOK_SECRET
        try:
            auth_mod.CLERK_WEBHOOK_SECRET = "testsecret"
            result = auth_mod._verify_clerk_signature(b"hello", "id1", "12345", "v1,badsig==")
            assert result is False
        finally:
            auth_mod.CLERK_WEBHOOK_SECRET = original

    def test_verify_clerk_signature_correct_sig(self):
        import api.auth as auth_mod
        import hmac
        import hashlib
        import base64
        original = auth_mod.CLERK_WEBHOOK_SECRET
        try:
            secret = "mysecret"
            auth_mod.CLERK_WEBHOOK_SECRET = secret
            body = b'{"type":"user.created"}'
            svix_id = "msg_001"
            svix_ts = "1700000000"
            signed_content = f"{svix_id}.{svix_ts}.{body.decode()}".encode()
            expected = hmac.new(secret.encode(), signed_content, hashlib.sha256).digest()
            sig = "v1," + base64.b64encode(expected).decode()
            result = auth_mod._verify_clerk_signature(body, svix_id, svix_ts, sig)
            assert result is True
        finally:
            auth_mod.CLERK_WEBHOOK_SECRET = original

    @pytest.mark.asyncio
    async def test_parse_clerk_webhook_bad_signature(self):
        from fastapi import HTTPException, Request
        import api.auth as auth_mod
        original = auth_mod.CLERK_WEBHOOK_SECRET
        try:
            auth_mod.CLERK_WEBHOOK_SECRET = "secret"
            # Build a minimal Request mock
            mock_request = MagicMock(spec=Request)
            mock_request.body = AsyncMock(return_value=b'{"type":"test"}')
            mock_request.headers = {"svix-id": "x", "svix-timestamp": "1",
                                    "svix-signature": "v1,invalidsig"}
            from api.auth import parse_clerk_webhook
            with pytest.raises(HTTPException) as exc:
                await parse_clerk_webhook(mock_request)
            assert exc.value.status_code == 400
        finally:
            auth_mod.CLERK_WEBHOOK_SECRET = original

    @pytest.mark.asyncio
    async def test_parse_clerk_webhook_no_secret_rejects(self):
        """When CLERK_WEBHOOK_SECRET is not set, webhooks must be rejected (fail-closed)."""
        from fastapi import Request, HTTPException
        import api.auth as auth_mod
        original = auth_mod.CLERK_WEBHOOK_SECRET
        try:
            auth_mod.CLERK_WEBHOOK_SECRET = ""
            mock_request = MagicMock(spec=Request)
            body = b'{"type":"user.created","data":{}}'
            mock_request.body = AsyncMock(return_value=body)
            mock_request.headers = {"svix-id": "", "svix-timestamp": "", "svix-signature": ""}
            from api.auth import parse_clerk_webhook
            with pytest.raises(HTTPException) as exc:
                await parse_clerk_webhook(mock_request)
            assert exc.value.status_code == 400
        finally:
            auth_mod.CLERK_WEBHOOK_SECRET = original


# ===========================================================================
# 3. db.py — helpers and async functions
# ===========================================================================

class TestDbHelpers:
    def test_generate_token_live(self):
        from api.db import generate_token
        raw, hashed = generate_token("live")
        assert raw.startswith("vl_live_")
        assert hashed == hashlib.sha256(raw.encode()).hexdigest()

    def test_generate_token_test(self):
        from api.db import generate_token
        raw, _ = generate_token("test")
        assert raw.startswith("vl_test_")

    def test_hash_token(self):
        from api.db import hash_token
        assert hash_token("abc") == hashlib.sha256(b"abc").hexdigest()

    @pytest.mark.asyncio
    async def test_create_user_no_referral(self):
        from api.db import create_user
        db = _make_db_mock()
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = MagicMock(data=[])
        with patch("api.db.get_db", return_value=db), \
             patch("api.db.add_credit_event") as mock_add:
            row = await create_user("usr_1", "a@b.com")
        assert row["user_id"] == "usr_1"
        mock_add.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_user_with_referral(self):
        from api.db import create_user
        db = _make_db_mock()
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = \
            MagicMock(data=[{"user_id": "usr_referrer"}])
        with patch("api.db.get_db", return_value=db), \
             patch("api.db.add_credit_event") as mock_add:
            await create_user("usr_new", "new@b.com", referred_by_code="REF123")
        # 2 calls: signup bonus + referral bonus
        assert mock_add.call_count == 2

    @pytest.mark.asyncio
    async def test_get_user_found(self):
        from api.db import get_user
        db = _make_db_mock()
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = \
            MagicMock(data=[{"user_id": "usr_1"}])
        with patch("api.db.get_db", return_value=db):
            result = await get_user("usr_1")
        assert result["user_id"] == "usr_1"

    @pytest.mark.asyncio
    async def test_get_user_not_found(self):
        from api.db import get_user
        db = _make_db_mock()
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = \
            MagicMock(data=[])
        with patch("api.db.get_db", return_value=db):
            result = await get_user("usr_missing")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_user_by_token_not_found(self):
        from api.db import get_user_by_token
        db = _make_db_mock()
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = \
            MagicMock(data=[])
        with patch("api.db.get_db", return_value=db):
            result = await get_user_by_token("vl_live_missing")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_user_by_token_revoked(self):
        from api.db import get_user_by_token
        db = _make_db_mock()
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = \
            MagicMock(data=[{"user_id": "usr_1", "revoked_at": "2024-01-01"}])
        with patch("api.db.get_db", return_value=db):
            result = await get_user_by_token("vl_live_revoked")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_user_by_token_valid(self):
        """Valid non-revoked token returns the user row."""
        from api.db import get_user_by_token
        token_row = {"user_id": "usr_1", "revoked_at": None}
        user_row = _user_row("usr_1")

        # Mock get_user_by_token's sub-dependencies directly
        with patch("api.db.get_db") as mock_get_db, \
             patch("api.db.get_user", new_callable=AsyncMock, return_value=user_row):
            db = _make_db_mock()
            # api_tokens lookup returns valid token row
            db.table.return_value.select.return_value.eq.return_value.execute.return_value = \
                MagicMock(data=[token_row])
            db.table.return_value.update.return_value.eq.return_value.execute.return_value = \
                MagicMock()
            mock_get_db.return_value = db

            result = await get_user_by_token("vl_live_good")
        assert result is not None
        assert result["user_id"] == "usr_1"

    @pytest.mark.asyncio
    async def test_create_api_token(self):
        from api.db import create_api_token
        db = _make_db_mock()
        with patch("api.db.get_db", return_value=db):
            token = await create_api_token("usr_1")
        assert token.startswith("vl_live_")

    def test_add_credit_event(self):
        from api.db import add_credit_event
        db = _make_db_mock()
        with patch("api.db.get_db", return_value=db):
            add_credit_event("usr_1", "burned", -100, job_id="job_1",
                             description="test burn")
        db.table.assert_called_with("credit_events")

    def test_get_balance_from_view(self):
        from api.db import get_balance
        db = _make_db_mock()
        # View returns data
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = \
            MagicMock(data=[{
                "user_id": "usr_1",
                "balance_credits": 5000,
                "total_purchased": 5000,
                "total_spent": 0,
            }])
        with patch("api.db.get_db", return_value=db):
            bal = get_balance("usr_1")
        assert bal["balance_credits"] == 5000

    def test_get_balance_per_job_reservation_isolation(self):
        """P2-8 fix: over-burn on Job A cannot reduce Job B's apparent reservation.

        Before the fix: reserved and settled were summed across the whole
        user, so if Job A reserved 100 and burned 200 (settled=200), the
        user's total active_reserved clamped to max(0, sum_reserved -
        sum_settled) = max(0, 100+50 - 200) = 0 when Job B also had 50
        reserved. Job B's live reservation effectively vanished and the
        user could start more jobs against credits that were already
        committed.

        After the fix: active_reserved is computed per-job and the
        per-job clamp sums individually. Job A contributes 0 (its closed
        events exceed its reservation), Job B still contributes 50.
        """
        from api.db import get_balance
        db = MagicMock()
        # View returns purchased=1000 credits total
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = \
            MagicMock(data=[{
                "user_id": "usr_race",
                "balance_credits": 1000,
                "total_purchased": 1000,
                "total_spent": 250,
            }])
        # credit_events: Job A over-burned (reserved 100, burned 200);
        # Job B still reserved (50, 0 closed).
        events_result = MagicMock(data=[
            {"job_id": "job_A", "event_type": "reserved", "amount_credits": 100},
            {"job_id": "job_A", "event_type": "burned",   "amount_credits": -200},
            {"job_id": "job_B", "event_type": "reserved", "amount_credits": 50},
        ])
        db.table.return_value.select.return_value.eq.return_value.in_.return_value.execute.return_value = \
            events_result

        with patch("api.db.get_db", return_value=db):
            bal = get_balance("usr_race")

        # Per-job clamp: Job A = max(0, 100 - 200) = 0; Job B = max(0, 50 - 0) = 50
        assert bal["reserved_credits"] == 50, (
            "Pre-fix bug would report 0 here (total_reserved 150 - total_closed 200 "
            "clamped to 0). The fix guarantees Job B's 50 credits stay reserved."
        )
        # available = view-provided balance (reservations already netted out).
        # Pre-double-subtract fix would report 950 here.
        assert bal["available_credits"] == 1000

    def test_get_balance_does_not_double_subtract_reservation(self):
        """P1-new fix: the ledger view already nets reservations as negative rows.

        The ledger view sums EVERY credit_events row, including the
        negative-amount 'reserved' rows. So a user with +1000 purchased
        and -100 reserved already sees balance_credits=900 via the view.
        The pre-fix code subtracted active_reserved again → 800, which
        understated the user's real spendable balance (a reservation
        should commit 100 exactly once, not twice).

        Concrete: 1000 purchased, Job X reserved 100. balance=900,
        active_reserved=100, available MUST be 900 (one subtraction,
        via the view), not 800.
        """
        from api.db import get_balance
        db = MagicMock()
        # View already nets: 1000 (purchased) + -100 (reserved) = 900
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = \
            MagicMock(data=[{
                "user_id": "usr_reserve",
                "balance_credits": 900,
                "total_purchased": 1000,
                "total_spent": 100,  # reservation counted as "spent" in the view
            }])
        events_result = MagicMock(data=[
            {"job_id": "job_X", "event_type": "reserved", "amount_credits": -100},
        ])
        db.table.return_value.select.return_value.eq.return_value.in_.return_value.execute.return_value = \
            events_result

        with patch("api.db.get_db", return_value=db):
            bal = get_balance("usr_reserve")

        # Informational: the reservation is open
        assert bal["reserved_credits"] == 100
        # Key invariant: available is the view balance, NOT view balance minus
        # reserved again. Pre-fix this was 800; the fix makes it 900.
        assert bal["available_credits"] == 900, (
            "Pre-fix bug: available = balance(900) - active_reserved(100) = 800. "
            "The view already subtracted the reservation once (it's stored as a "
            "negative credit_events row); subtracting again double-counts."
        )

    def test_get_balance_fallback_to_raw(self):
        """When the view raises, fall back to summing credit_events."""
        from api.db import get_balance
        db = MagicMock()
        # First call (user_credit_balance view) raises
        # Subsequent calls (credit_events raw table) succeed
        call_n = {"n": 0}
        empty_result = MagicMock(data=[])

        def execute_side_effect(*a, **k):
            call_n["n"] += 1
            if call_n["n"] == 1:
                raise Exception("view not found")
            return empty_result

        db.table.return_value.select.return_value.eq.return_value.execute.side_effect = \
            execute_side_effect
        db.table.return_value.select.return_value.eq.return_value.eq.return_value.execute.return_value = \
            empty_result
        db.table.return_value.select.return_value.eq.return_value.in_.return_value.execute.return_value = \
            empty_result

        with patch("api.db.get_db", return_value=db):
            bal = get_balance("usr_1")
        assert "available_credits" in bal

    def test_upsert_job(self):
        from api.db import upsert_job
        db = _make_db_mock()
        with patch("api.db.get_db", return_value=db):
            upsert_job("job_1", "usr_1", {"status": "queued"})
        db.table.assert_called_with("jobs")

    def test_update_job(self):
        from api.db import update_job
        db = _make_db_mock()
        with patch("api.db.get_db", return_value=db):
            update_job("job_1", {"status": "completed"})
        db.table.assert_called_with("jobs")

    @pytest.mark.asyncio
    async def test_release_staged_bonus_skipped_if_already_released(self):
        from api.db import release_staged_bonus
        db = _make_db_mock()
        with patch("api.db.get_db", return_value=db), \
             patch("api.db.get_user", new_callable=AsyncMock,
                   return_value={"user_id": "usr_1", "signup_bonus_released": True}), \
             patch("api.db.add_credit_event") as mock_add:
            await release_staged_bonus("usr_1")
        mock_add.assert_not_called()

    @pytest.mark.asyncio
    async def test_release_staged_bonus_skipped_if_no_user(self):
        from api.db import release_staged_bonus
        db = _make_db_mock()
        with patch("api.db.get_db", return_value=db), \
             patch("api.db.get_user", new_callable=AsyncMock, return_value=None), \
             patch("api.db.add_credit_event") as mock_add:
            await release_staged_bonus("usr_missing")
        mock_add.assert_not_called()


# ===========================================================================
# 4. credits.py — routes
# ===========================================================================

class TestCreditsRoutes:
    @pytest.fixture(autouse=True)
    def _allow_owned_jobs(self):
        """Most credits route tests target accounting math, not ownership lookup."""
        with patch("api.credits._verify_job_ownership"):
            yield

    def _auth_headers(self, token="vl_live_testtoken"):
        return {"Authorization": f"Bearer {token}"}

    @pytest.mark.asyncio
    async def test_get_credits_ok(self):
        from api.credits import get_credits
        user = _user_row()
        with patch("api.credits.get_balance", return_value=_balance()):
            result = await get_credits(user)
        assert result.available_credits == 5000

    @pytest.mark.asyncio
    async def test_get_credits_db_error_returns_default(self):
        from api.credits import get_credits
        user = _user_row()
        with patch("api.credits.get_balance", side_effect=Exception("db down")):
            result = await get_credits(user)
        # Falls back to SIGNUP_BONUS_IMMEDIATE_CREDITS
        assert result.available_credits >= 0

    @pytest.mark.asyncio
    async def test_start_job_sufficient_credits(self):
        from api.credits import start_job
        from api.models import JobStartRequest
        user = _user_row()
        req = JobStartRequest(
            job_id="job_001",
            gpu_type="H100_80GB_SXM",
            provider="lambda_labs",
            estimated_hours=2.0,
            hourly_rate_usd=2.86,
        )
        with patch("api.credits.get_balance", return_value=_balance(10000)), \
             patch("api.credits.add_credit_event"), \
             patch("api.credits.upsert_job"):
            result = await start_job(req, user)
        assert result.approved is True

    @pytest.mark.asyncio
    async def test_start_job_insufficient_credits_soft_allows(self):
        """During testing phase, jobs start even with 0 credits (soft check)."""
        from api.credits import start_job
        from api.models import JobStartRequest
        user = _user_row()
        req = JobStartRequest(
            job_id="job_002",
            gpu_type="H100_80GB_SXM",
            provider="lambda_labs",
            estimated_hours=2.0,
            hourly_rate_usd=2.86,
        )
        with patch("api.credits.get_balance", return_value=_balance(0, 0, 0, 0)), \
             patch("api.credits.add_credit_event"), \
             patch("api.credits.upsert_job"):
            result = await start_job(req, user)
        assert result.approved is True
        assert result.credits_reserved == 0

    @pytest.mark.asyncio
    async def test_start_job_rate_limited(self):
        from fastapi import HTTPException
        from api.credits import start_job, _start_timestamps
        from api.models import JobStartRequest
        user = _user_row()
        req = JobStartRequest(
            job_id="job_rl", gpu_type="A10G", provider="aws",
            estimated_hours=1.0, hourly_rate_usd=0.86,
        )
        # Fill the rate limit deque
        import time
        _start_timestamps["usr_test"].clear()
        for _ in range(5):
            _start_timestamps["usr_test"].append(time.monotonic())

        with pytest.raises(HTTPException) as exc:
            await start_job(req, user)
        assert exc.value.status_code == 429
        _start_timestamps["usr_test"].clear()

    @pytest.mark.asyncio
    async def test_burn_ok_status(self):
        from api.credits import burn_credits
        from api.models import BurnRequest
        user = _user_row()
        req = BurnRequest(job_id="job_1", elapsed_seconds=3600, hourly_rate_usd=1.0)
        with patch("api.credits.add_credit_event"), \
             patch("api.credits.maybe_release_staged_bonus", new_callable=AsyncMock), \
             patch("api.credits.get_balance", return_value=_balance(9000)), \
             patch("api.credits.update_job"), \
             patch("api.credits.send_job_suspended", new_callable=AsyncMock), \
             patch("api.credits.send_credits_low", new_callable=AsyncMock):
            result = await burn_credits("job_1", req, user)
        assert result.status == "ok"

    @pytest.mark.asyncio
    async def test_burn_low_status(self):
        from api.credits import burn_credits
        from api.models import BurnRequest
        user = _user_row()
        req = BurnRequest(job_id="job_2", elapsed_seconds=3600, hourly_rate_usd=1.0)
        with patch("api.credits.add_credit_event"), \
             patch("api.credits.maybe_release_staged_bonus", new_callable=AsyncMock), \
             patch("api.credits.get_balance", return_value=_balance(500)), \
             patch("api.credits.update_job"), \
             patch("api.credits.send_job_suspended", new_callable=AsyncMock), \
             patch("api.credits.send_credits_low", new_callable=AsyncMock) as mock_low:
            result = await burn_credits("job_2", req, user)
        assert result.status == "low"
        mock_low.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_burn_exhausted_status(self):
        from api.credits import burn_credits
        from api.models import BurnRequest
        user = _user_row()
        req = BurnRequest(job_id="job_3", elapsed_seconds=3600, hourly_rate_usd=1.0)
        with patch("api.credits.add_credit_event"), \
             patch("api.credits.maybe_release_staged_bonus", new_callable=AsyncMock), \
             patch("api.credits.get_balance", return_value=_balance(10)), \
             patch("api.credits.update_job") as mock_upd, \
             patch("api.credits.send_job_suspended", new_callable=AsyncMock) as mock_susp, \
             patch("api.credits.send_credits_low", new_callable=AsyncMock):
            result = await burn_credits("job_3", req, user)
        assert result.status == "exhausted"
        mock_upd.assert_called_once()
        mock_susp.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_burn_zero_elapsed(self):
        """elapsed_seconds=0 → credits_burned=0, skips add_credit_event."""
        from api.credits import burn_credits
        from api.models import BurnRequest
        user = _user_row()
        req = BurnRequest(job_id="job_z", elapsed_seconds=0, hourly_rate_usd=1.0)
        with patch("api.credits.add_credit_event") as mock_add, \
             patch("api.credits.maybe_release_staged_bonus", new_callable=AsyncMock), \
             patch("api.credits.get_balance", return_value=_balance(5000)):
            result = await burn_credits("job_z", req, user)
        mock_add.assert_not_called()
        assert result.credits_burned == 0

    @pytest.mark.asyncio
    async def test_burn_rate_limited(self):
        from fastapi import HTTPException
        from api.credits import burn_credits, _burn_timestamps
        from api.models import BurnRequest
        user = _user_row()
        req = BurnRequest(job_id="job_rl2", elapsed_seconds=60, hourly_rate_usd=1.0)
        import time
        _burn_timestamps["usr_test"].clear()
        for _ in range(10):
            _burn_timestamps["usr_test"].append(time.monotonic())
        with pytest.raises(HTTPException) as exc:
            await burn_credits("job_rl2", req, user)
        assert exc.value.status_code == 429
        _burn_timestamps["usr_test"].clear()

    @pytest.mark.asyncio
    async def test_settle_job_no_gainshare(self):
        from api.credits import settle_job
        from api.models import SettleRequest
        user = _user_row()
        req = SettleRequest(
            job_id="job_s1",
            actual_seconds=7200,
            hourly_rate_usd=2.86,
            final_status="completed",
        )
        db = _make_db_mock()
        db.table.return_value.select.return_value.eq.return_value.single.return_value.execute.return_value = \
            MagicMock(data={"stripe_customer_id": None})
        with patch("api.credits.add_credit_event"), \
             patch("api.credits.update_job"), \
             patch("api.credits.get_balance", return_value=_balance(3000)), \
             patch("api.db.get_db", return_value=db):
            result = await settle_job("job_s1", req, user)
        assert result.job_id == "job_s1"

    @pytest.mark.asyncio
    async def test_settle_job_with_gainshare(self):
        from api.credits import settle_job, _report_gainshare_to_stripe
        from api.models import SettleRequest
        user = _user_row()
        req = SettleRequest(
            job_id="job_s2",
            actual_seconds=7200,
            hourly_rate_usd=2.86,
            final_status="completed",
            aws_equivalent_usd=20.0,
        )
        db = _make_db_mock()
        db.table.return_value.select.return_value.eq.return_value.single.return_value.execute.return_value = \
            MagicMock(data={"stripe_customer_id": "cus_abc"})
        with patch("api.credits.add_credit_event"), \
             patch("api.credits.update_job"), \
             patch("api.credits.get_balance", return_value=_balance(3000)), \
             patch("api.db.get_db", return_value=db), \
             patch("api.credits._report_gainshare_to_stripe") as mock_gs:
            result = await settle_job("job_s2", req, user)
        mock_gs.assert_called_once()

    @pytest.mark.asyncio
    async def test_settle_job_db_error_for_gainshare(self):
        """If fetching stripe_customer_id fails, settle still returns OK."""
        from api.credits import settle_job
        from api.models import SettleRequest
        user = _user_row()
        req = SettleRequest(
            job_id="job_s3", actual_seconds=3600,
            hourly_rate_usd=1.0, final_status="completed",
        )
        with patch("api.credits.add_credit_event"), \
             patch("api.credits.update_job"), \
             patch("api.credits.get_balance", return_value=_balance(3000)), \
             patch("api.db.get_db", side_effect=Exception("db down")):
            result = await settle_job("job_s3", req, user)
        assert result.job_id == "job_s3"


class TestReportGainshare:
    def test_no_stripe_key_skips(self):
        from api.credits import _report_gainshare_to_stripe
        with patch.dict(os.environ, {"STRIPE_SECRET_KEY": ""}):
            # Should not raise
            _report_gainshare_to_stripe("cus_abc", 5.0, "job_1")

    def test_zero_gainshare_skips(self):
        from api.credits import _report_gainshare_to_stripe
        # gainshare_usd=0.0 → early return before any stripe call
        mock_stripe = MagicMock()
        with patch.dict(os.environ, {"STRIPE_SECRET_KEY": "sk_test_key"}), \
             patch.dict(sys.modules, {"stripe": mock_stripe}):
            _report_gainshare_to_stripe("cus_abc", 0.0, "job_1")
            mock_stripe.billing.MeterEvent.create.assert_not_called()

    def test_stripe_error_is_non_fatal(self):
        from api.credits import _report_gainshare_to_stripe
        mock_stripe = MagicMock()
        mock_stripe.billing.MeterEvent.create.side_effect = Exception("api error")
        with patch.dict(os.environ, {"STRIPE_SECRET_KEY": "sk_test_key"}), \
             patch.dict(sys.modules, {"stripe": mock_stripe}):
            # Should not raise
            _report_gainshare_to_stripe("cus_abc", 10.0, "job_1")

    def test_gainshare_reports_correctly(self):
        from api.credits import _report_gainshare_to_stripe
        mock_stripe = MagicMock()
        with patch.dict(os.environ, {"STRIPE_SECRET_KEY": "sk_test_key",
                                      "STRIPE_GAINSHARE_METER_NAME": "vaultlayer_gainshare_usd"}), \
             patch.dict(sys.modules, {"stripe": mock_stripe}):
            _report_gainshare_to_stripe("cus_abc", 5.0, "job_1")
            mock_stripe.billing.MeterEvent.create.assert_called_once()


# ===========================================================================
# 5. email.py — fire-and-forget (no RESEND_API_KEY)
# ===========================================================================

class TestEmailFunctions:
    @pytest.mark.asyncio
    async def test_send_welcome_no_key(self):
        with patch("api.email.resend") as mock_resend:
            mock_resend.Emails.send.side_effect = Exception("No API key")
            from api.email import send_welcome
            # Must not raise even when Resend fails
            await send_welcome("a@b.com", "vl_live_token", 1000)

    @pytest.mark.asyncio
    async def test_send_credits_low_no_key(self):
        with patch("api.email.resend") as mock_resend:
            mock_resend.Emails.send.side_effect = Exception("No API key")
            from api.email import send_credits_low
            await send_credits_low("a@b.com", 500)

    @pytest.mark.asyncio
    async def test_send_job_suspended_no_key(self):
        with patch("api.email.resend") as mock_resend:
            mock_resend.Emails.send.side_effect = Exception("No API key")
            from api.email import send_job_suspended
            await send_job_suspended("a@b.com", "job_1", 10)

    @pytest.mark.asyncio
    async def test_send_welcome_success(self):
        with patch("api.email.resend") as mock_resend:
            mock_resend.Emails.send.return_value = {"id": "email_123"}
            from api.email import send_welcome
            await send_welcome("x@y.com", "vl_live_token", 1000)
            mock_resend.Emails.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_send_credits_low_success(self):
        with patch("api.email.resend") as mock_resend:
            mock_resend.Emails.send.return_value = {"id": "email_124"}
            from api.email import send_credits_low
            await send_credits_low("x@y.com", 500)
            mock_resend.Emails.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_send_job_suspended_success(self):
        with patch("api.email.resend") as mock_resend:
            mock_resend.Emails.send.return_value = {"id": "email_125"}
            from api.email import send_job_suspended
            await send_job_suspended("x@y.com", "job_123", 25)
            mock_resend.Emails.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_send_needs_more_info(self):
        with patch("api.email.resend") as mock_resend:
            mock_resend.Emails.send.return_value = {"id": "email_126"}
            from api.email import send_needs_more_info
            await send_needs_more_info("x@y.com", "fb_001", "Can you share your logs?")
            mock_resend.Emails.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_send_bug_fixed(self):
        with patch("api.email.resend") as mock_resend:
            mock_resend.Emails.send.return_value = {"id": "email_127"}
            from api.email import send_bug_fixed
            await send_bug_fixed("x@y.com", "fb_001", "https://github.com/pr/1")
            mock_resend.Emails.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_send_topup_confirmation(self):
        with patch("api.email.resend") as mock_resend:
            mock_resend.Emails.send.return_value = {"id": "email_128"}
            from api.email import send_topup_confirmation
            await send_topup_confirmation("x@y.com", 1000, 2000, "starter")
            mock_resend.Emails.send.assert_called_once()


# ===========================================================================
# 6. fraud.py — cover lines 67-71 (subnet increment branch)
# ===========================================================================

class TestFraudCoverage:
    @pytest.mark.asyncio
    async def test_subnet_below_limit_increments_counter(self):
        """Lines 67-71: existing row with count < MAX → update counter."""
        from api.fraud import check_ip_rate_limit, MAX_ACCOUNTS_PER_SUBNET
        db = _make_db_mock()
        existing_count = MAX_ACCOUNTS_PER_SUBNET - 1
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = \
            MagicMock(data=[{"subnet": "10.0.1", "account_count": existing_count}])
        update_mock = MagicMock()
        db.table.return_value.update.return_value.eq.return_value.execute.return_value = update_mock

        with patch("api.fraud.get_db", return_value=db):
            allowed, reason = await check_ip_rate_limit("10.0.1.50")

        assert allowed is True
        assert reason == "ok"
        # Ensure update was called with incremented count
        db.table.return_value.update.assert_called_once_with({
            "account_count": existing_count + 1,
            "last_seen_at": "now()",
        })

    def test_extract_subnet_ipv6_returns_none(self):
        """_extract_subnet returns None for IPv6 — causing ip check to allow."""
        from api.fraud import _extract_subnet
        assert _extract_subnet("2001:db8::1") is None

    def test_extract_subnet_invalid_returns_none(self):
        from api.fraud import _extract_subnet
        assert _extract_subnet("not.an.ip") is None

    def test_extract_subnet_valid_ipv4(self):
        from api.fraud import _extract_subnet
        assert _extract_subnet("192.168.10.5") == "192.168.10"

    @pytest.mark.asyncio
    async def test_maybe_release_at_exactly_600s(self):
        from api.fraud import maybe_release_staged_bonus
        with patch("api.fraud.release_staged_bonus", new_callable=AsyncMock) as mock_rel:
            await maybe_release_staged_bonus("usr_1", 600)
            mock_rel.assert_called_once_with("usr_1")

    @pytest.mark.asyncio
    async def test_maybe_release_below_600s_no_call(self):
        from api.fraud import maybe_release_staged_bonus
        with patch("api.fraud.release_staged_bonus", new_callable=AsyncMock) as mock_rel:
            await maybe_release_staged_bonus("usr_1", 599.9)
            mock_rel.assert_not_called()


# ===========================================================================
# 7. feedback_routes.py — submit and status endpoints
# ===========================================================================

class TestFeedbackRoutes:
    def _db_for_feedback(self, feedback_id="fb_001", existing_rows=None, dup_rows=None):
        db = _make_db_mock()
        # insert returns the new feedback id
        db.table.return_value.insert.return_value.execute.return_value = \
            MagicMock(data=[{"id": feedback_id}])
        return db

    @pytest.mark.asyncio
    async def test_submit_feedback_minimal(self):
        from api.feedback_routes import submit_feedback
        from fastapi import Request
        db = self._db_for_feedback()

        mock_request = MagicMock(spec=Request)
        mock_request.json = AsyncMock(return_value={"message": "Test bug report"})

        with patch("api.feedback_routes.get_db", return_value=db):
            result = await submit_feedback(mock_request, authorization=None)

        assert result["status"] == "received"

    @pytest.mark.asyncio
    async def test_submit_feedback_missing_message(self):
        from fastapi import HTTPException
        from api.feedback_routes import submit_feedback
        from fastapi import Request
        db = self._db_for_feedback()

        mock_request = MagicMock(spec=Request)
        mock_request.json = AsyncMock(return_value={"type": "bug"})

        with patch("api.feedback_routes.get_db", return_value=db):
            with pytest.raises(HTTPException) as exc:
                await submit_feedback(mock_request, authorization=None)
        assert exc.value.status_code == 422

    @pytest.mark.asyncio
    async def test_submit_feedback_invalid_type_falls_back(self):
        from api.feedback_routes import submit_feedback
        from fastapi import Request
        db = self._db_for_feedback()

        mock_request = MagicMock(spec=Request)
        mock_request.json = AsyncMock(return_value={"message": "hello", "type": "notvalid"})

        with patch("api.feedback_routes.get_db", return_value=db):
            result = await submit_feedback(mock_request, authorization=None)
        assert result["status"] == "received"

    @pytest.mark.asyncio
    async def test_submit_feedback_with_fingerprint_dedup(self):
        """Duplicate fingerprint sets status=duplicate."""
        from api.feedback_routes import submit_feedback
        from fastapi import Request
        db = self._db_for_feedback()

        # Dedup query returns existing feedback
        dup_result = MagicMock(data=[{"id": "fb_original", "status": "pending",
                                       "primary_feedback_id": None}])
        # First call (dedup query), second call (insert)
        call_n = {"n": 0}
        def side_eff(*a, **k):
            call_n["n"] += 1
            if call_n["n"] == 1:
                return dup_result
            return MagicMock(data=[{"id": "fb_002"}])
        db.table.return_value.select.return_value.eq.return_value.not_.in_.return_value\
            .order.return_value.limit.return_value.execute.return_value = dup_result

        mock_request = MagicMock(spec=Request)
        mock_request.json = AsyncMock(return_value={
            "message": "Same crash again",
            "fingerprint": "fp_crash_001",
        })

        with patch("api.feedback_routes.get_db", return_value=db):
            result = await submit_feedback(mock_request, authorization=None)
        assert result["status"] == "received"

    @pytest.mark.asyncio
    async def test_submit_feedback_with_auth_token(self):
        """Feedback with valid auth resolves user_id and upserts feedback_reporters."""
        from api.feedback_routes import submit_feedback
        from fastapi import Request
        db = self._db_for_feedback()

        # Token resolution returns a user
        db.table.return_value.select.return_value.eq.return_value\
            .eq.return_value.execute.return_value = MagicMock(data=[{"user_id": "usr_1"}])

        mock_request = MagicMock(spec=Request)
        mock_request.json = AsyncMock(return_value={"message": "Bug with auth"})

        with patch("api.feedback_routes.get_db", return_value=db):
            result = await submit_feedback(mock_request, authorization="Bearer vl_live_token")
        assert result["status"] == "received"

    @pytest.mark.asyncio
    async def test_submit_feedback_with_all_optional_fields(self):
        from api.feedback_routes import submit_feedback
        from fastapi import Request
        db = self._db_for_feedback()
        mock_request = MagicMock(spec=Request)
        mock_request.json = AsyncMock(return_value={
            "message": "Detailed crash",
            "type": "auto_crash",
            "log_snippet": "Error at line 42",
            "traceback": "Traceback...",
            "job_id": "job_001",
            "command": "python train.py",
            "gpu_type": "H100_80GB_SXM",
            "provider": "lambda_labs",
            "error_type": "CUDA OOM",
            "source": "cli",
        })
        with patch("api.feedback_routes.get_db", return_value=db):
            result = await submit_feedback(mock_request, authorization=None)
        assert result["status"] == "received"

    @pytest.mark.asyncio
    async def test_submit_feedback_insert_error_raises_500(self):
        from fastapi import HTTPException
        from api.feedback_routes import submit_feedback
        from fastapi import Request
        db = _make_db_mock()
        db.table.return_value.insert.return_value.execute.side_effect = Exception("db error")

        mock_request = MagicMock(spec=Request)
        mock_request.json = AsyncMock(return_value={"message": "crash"})

        with patch("api.feedback_routes.get_db", return_value=db):
            with pytest.raises(HTTPException) as exc:
                await submit_feedback(mock_request, authorization=None)
        assert exc.value.status_code == 500

    @pytest.mark.asyncio
    async def test_get_feedback_status_found(self):
        from api.feedback_routes import get_feedback_status
        db = _make_db_mock()
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = \
            MagicMock(data=[{
                "id": "fb_001",
                "status": "resolved",
                "pr_url": "https://github.com/pr/1",
                "resolved_at": "2026-01-01",
                "needs_more_info": False,
            }])
        with patch("api.feedback_routes.get_db", return_value=db):
            result = await get_feedback_status("fb_001")
        assert result["status"] == "resolved"

    @pytest.mark.asyncio
    async def test_get_feedback_status_not_found(self):
        from fastapi import HTTPException
        from api.feedback_routes import get_feedback_status
        db = _make_db_mock()
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = \
            MagicMock(data=[])
        with patch("api.feedback_routes.get_db", return_value=db):
            with pytest.raises(HTTPException) as exc:
                await get_feedback_status("fb_missing")
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_get_feedback_status_db_error(self):
        from fastapi import HTTPException
        from api.feedback_routes import get_feedback_status
        db = _make_db_mock()
        db.table.return_value.select.return_value.eq.return_value.execute.side_effect = \
            Exception("db down")
        with patch("api.feedback_routes.get_db", return_value=db):
            with pytest.raises(HTTPException) as exc:
                await get_feedback_status("fb_err")
        assert exc.value.status_code == 500

    @pytest.mark.asyncio
    async def test_resolve_user_id_no_auth(self):
        from api.feedback_routes import _resolve_user_id
        result = await _resolve_user_id(None)
        assert result is None

    @pytest.mark.asyncio
    async def test_resolve_user_id_invalid_bearer(self):
        from api.feedback_routes import _resolve_user_id
        result = await _resolve_user_id("Token abc")
        assert result is None

    @pytest.mark.asyncio
    async def test_resolve_user_id_empty_token(self):
        from api.feedback_routes import _resolve_user_id
        result = await _resolve_user_id("Bearer ")
        assert result is None

    @pytest.mark.asyncio
    async def test_resolve_user_id_db_error_returns_none(self):
        from api.feedback_routes import _resolve_user_id
        db = _make_db_mock()
        db.table.return_value.select.return_value.eq.return_value\
            .is_.return_value.execute.side_effect = Exception("db down")
        with patch("api.feedback_routes.get_db", return_value=db):
            result = await _resolve_user_id("Bearer vl_live_token")
        assert result is None


# ===========================================================================
# 8. stripe_routes.py — checkout + webhook
# ===========================================================================

class TestStripeRoutes:
    @pytest.mark.asyncio
    async def test_create_checkout_unknown_package(self):
        from fastapi import HTTPException
        from api.stripe_routes import create_checkout
        from api.models import CheckoutRequest
        user = _user_row()
        req = CheckoutRequest(package="unknown", success_url="https://x.com/ok",
                               cancel_url="https://x.com/cancel")
        with pytest.raises(HTTPException) as exc:
            await create_checkout(req, user)
        assert exc.value.status_code == 400

    @pytest.mark.asyncio
    async def test_create_checkout_missing_price_id(self):
        from fastapi import HTTPException
        from api.stripe_routes import create_checkout
        from api.models import CheckoutRequest
        user = _user_row()
        req = CheckoutRequest(package="starter", success_url="https://x.com/ok",
                               cancel_url="https://x.com/cancel")
        import api.stripe_routes as sr
        original = sr.STRIPE_PRICES.get("starter", "")
        try:
            sr.STRIPE_PRICES["starter"] = ""
            with pytest.raises(HTTPException) as exc:
                await create_checkout(req, user)
            assert exc.value.status_code == 503
        finally:
            sr.STRIPE_PRICES["starter"] = original

    @pytest.mark.asyncio
    async def test_create_checkout_stripe_error(self):
        from fastapi import HTTPException
        from api.stripe_routes import create_checkout
        from api.models import CheckoutRequest
        import stripe as real_stripe
        user = _user_row()
        req = CheckoutRequest(package="starter", success_url="https://x.com/ok",
                               cancel_url="https://x.com/cancel")
        with patch("api.stripe_routes.STRIPE_PRICES", {"starter": "price_test"}):
            with patch("api.stripe_routes.stripe") as mock_stripe:
                mock_stripe.checkout.Session.create.side_effect = \
                    real_stripe.error.StripeError("stripe error")
                mock_stripe.error = real_stripe.error
                with pytest.raises(HTTPException) as exc:
                    await create_checkout(req, user)
                assert exc.value.status_code == 502

    @pytest.mark.asyncio
    async def test_create_checkout_success(self):
        from api.stripe_routes import create_checkout
        from api.models import CheckoutRequest
        user = _user_row()
        req = CheckoutRequest(package="starter", success_url="https://x.com/ok",
                               cancel_url="https://x.com/cancel")
        mock_session = MagicMock(url="https://stripe.com/pay/xxx", id="cs_test")
        with patch("api.stripe_routes.STRIPE_PRICES", {"starter": "price_test123"}):
            with patch("api.stripe_routes.stripe") as mock_stripe:
                mock_stripe.checkout.Session.create.return_value = mock_session
                mock_stripe.error.StripeError = Exception
                result = await create_checkout(req, user)
        assert result.checkout_url == "https://stripe.com/pay/xxx"

    @pytest.mark.asyncio
    async def test_stripe_webhook_invalid_signature(self):
        from fastapi import HTTPException, Request
        from api.stripe_routes import stripe_webhook
        import stripe as real_stripe
        mock_request = MagicMock(spec=Request)
        mock_request.body = AsyncMock(return_value=b"{}")
        mock_request.headers = {"stripe-signature": "bad_sig"}

        with patch("api.stripe_routes.stripe") as mock_stripe:
            mock_stripe.error = real_stripe.error
            mock_stripe.Webhook.construct_event.side_effect = \
                real_stripe.error.SignatureVerificationError("bad sig", "sig_header")
            with pytest.raises(HTTPException) as exc:
                await stripe_webhook(mock_request)
        assert exc.value.status_code == 400

    @pytest.mark.asyncio
    async def test_stripe_webhook_checkout_completed(self):
        from fastapi import Request
        from api.stripe_routes import stripe_webhook
        mock_request = MagicMock(spec=Request)
        mock_request.body = AsyncMock(return_value=b"{}")
        mock_request.headers = {"stripe-signature": "sig"}

        event = {
            "type": "checkout.session.completed",
            "data": {"object": {
                "metadata": {"user_id": "usr_1", "package": "starter", "credits": "1000"},
                "payment_intent": "pi_test",
                "customer": None,
                "id": "cs_test",
            }},
        }
        with patch("api.stripe_routes.stripe") as mock_stripe, \
             patch("api.stripe_routes._handle_checkout_completed", new_callable=AsyncMock) as mock_hcc:
            mock_stripe.Webhook.construct_event.return_value = event
            result = await stripe_webhook(mock_request)
        assert result["received"] is True
        mock_hcc.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_stripe_webhook_payment_failed(self):
        from fastapi import Request
        from api.stripe_routes import stripe_webhook
        mock_request = MagicMock(spec=Request)
        mock_request.body = AsyncMock(return_value=b"{}")
        mock_request.headers = {"stripe-signature": "sig"}

        event = {
            "type": "payment_intent.payment_failed",
            "data": {"object": {"id": "pi_failed", "receipt_email": "x@y.com"}},
        }
        with patch("api.stripe_routes.stripe") as mock_stripe, \
             patch("api.stripe_routes._handle_payment_failed", new_callable=AsyncMock) as mock_hpf:
            mock_stripe.Webhook.construct_event.return_value = event
            result = await stripe_webhook(mock_request)
        assert result["received"] is True
        mock_hpf.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_handle_checkout_incomplete_metadata(self):
        """Missing user_id/package/credits → early return, no credits added."""
        from api.stripe_routes import _handle_checkout_completed
        with patch("api.stripe_routes.add_credit_event") as mock_add:
            await _handle_checkout_completed({
                "metadata": {"user_id": "", "package": "", "credits": "0"},
                "payment_intent": "pi_x",
                "customer": None,
                "id": "cs_x",
            })
        mock_add.assert_not_called()

    @pytest.mark.asyncio
    async def test_handle_checkout_user_not_found(self):
        from api.stripe_routes import _handle_checkout_completed
        with patch("api.stripe_routes.get_user", new_callable=AsyncMock, return_value=None), \
             patch("api.stripe_routes.add_credit_event") as mock_add:
            await _handle_checkout_completed({
                "metadata": {"user_id": "usr_ghost", "package": "starter", "credits": "1000"},
                "payment_intent": "pi_ghost",
                "customer": None,
                "id": "cs_ghost",
            })
        mock_add.assert_not_called()

    @pytest.mark.asyncio
    async def test_handle_checkout_card_blocked(self):
        """Card fingerprint blocked → refund, no credit event."""
        from api.stripe_routes import _handle_checkout_completed
        mock_pi = MagicMock()
        mock_pi.payment_method.card.fingerprint = "fp_blocked"

        with patch("api.stripe_routes.get_user", new_callable=AsyncMock,
                   return_value=_user_row()), \
             patch("api.stripe_routes.stripe") as mock_stripe, \
             patch("api.stripe_routes.check_card_fingerprint", new_callable=AsyncMock,
                   return_value=(False, "card already used")), \
             patch("api.stripe_routes.add_credit_event") as mock_add:
            mock_stripe.PaymentIntent.retrieve.return_value = mock_pi
            await _handle_checkout_completed({
                "metadata": {"user_id": "usr_test", "package": "starter", "credits": "1000"},
                "payment_intent": "pi_bad_card",
                "customer": None,
                "id": "cs_x",
            })
        mock_add.assert_not_called()
        mock_stripe.Refund.create.assert_called_once()

    @pytest.mark.asyncio
    async def test_handle_payment_failed_logs_warning(self):
        """_handle_payment_failed should complete without error."""
        from api.stripe_routes import _handle_payment_failed
        # Just ensure it doesn't raise
        await _handle_payment_failed({"id": "pi_failed", "receipt_email": "x@y.com"})


# ===========================================================================
# 9. models.py — line 42 (is_low property)
# ===========================================================================

class TestModels:
    def test_credit_balance_is_low_true(self):
        from api.models import CreditBalanceResponse
        r = CreditBalanceResponse(
            user_id="u", balance_credits=500, reserved_credits=0,
            spent_credits=0, available_credits=500, available_usd=5.0,
        )
        assert r.is_low is True   # < 1000

    def test_credit_balance_is_low_false(self):
        from api.models import CreditBalanceResponse
        r = CreditBalanceResponse(
            user_id="u", balance_credits=5000, reserved_credits=0,
            spent_credits=0, available_credits=5000, available_usd=50.0,
        )
        assert r.is_low is False

    def test_credit_balance_is_low_boundary(self):
        from api.models import CreditBalanceResponse
        r = CreditBalanceResponse(
            user_id="u", balance_credits=1000, reserved_credits=0,
            spent_credits=0, available_credits=1000, available_usd=10.0,
        )
        assert r.is_low is False  # exactly 1000 is NOT low (< 1000)

    def test_token_validate_response_defaults(self):
        from api.models import TokenValidateResponse
        r = TokenValidateResponse(valid=False)
        assert r.user_id is None
        assert r.message is None
