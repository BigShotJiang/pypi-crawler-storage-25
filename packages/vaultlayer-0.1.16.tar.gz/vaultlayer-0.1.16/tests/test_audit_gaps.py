"""Regression tests for the six audit gaps identified 2026-04-26.

P1: Raw PyTorch checkpoint discovery on failover
P1: Container completion detection fallbacks (R2 sentinel + job_events)
P1: VM path final checkpoint sync before exit
P1: VAULTLAYER_RESUME_CHECKPOINT injected on resume legs
P2: Checkpoint lookup paginated across >1000 R2 objects
P2: CLI local fallback recognises HF checkpoint-N/ format
"""
from __future__ import annotations

import os
import sys
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


# ── Helpers ──────────────────────────────────────────────────────────────────

def _make_r2_env(monkeypatch):
    monkeypatch.setenv("R2_ENDPOINT", "https://fake.r2.com")
    monkeypatch.setenv("R2_ACCESS_KEY_ID", "key")
    monkeypatch.setenv("R2_SECRET_ACCESS_KEY", "secret")
    monkeypatch.setenv("R2_BUCKET", "test-bucket")


def _mock_broker_and_job(script_name="train.py", checkpoint_step=None):
    job = SimpleNamespace(
        job_id="audit-job-1234",
        name="audit-job",
        environment={},
        docker_image="ghcr.io/hector25/vl-training-base:1.0",
        model_params_billion=None,
        training_mode="full",
        dataset_size_gb=None,
        dataset_location="",
        dataset_region="",
        checkpoint_step=checkpoint_step,
        resume_from_job_id=None,
    )
    broker = MagicMock()
    broker.config = SimpleNamespace(
        cloudflare=SimpleNamespace(
            r2_bucket="test-bucket",
            r2_access_key_id="key",
            r2_secret_access_key="secret",
            r2_endpoint="https://r2.test",
        ),
        redis=SimpleNamespace(url="redis://test"),
    )
    broker._get_managed_credentials = MagicMock(return_value=None)
    return broker, job


# ── P1.1: Raw PyTorch step-<N>/ format ───────────────────────────────────────

def test_find_checkpoint_raw_pytorch_format(monkeypatch):
    """_find_checkpoint() must recognise step-<N>/checkpoint.pt (vaultlayer_checkpoint.py output).

    vaultlayer init generates vaultlayer_checkpoint.py which writes:
      checkpoints/{job_id}/step-500/checkpoint.pt
    Before this fix the server only looked for checkpoint-N/ and ckpt_step_N.pt,
    so raw PyTorch users always got 'Instance lost, no checkpoint found'.
    """
    _make_r2_env(monkeypatch)
    contents = [
        {"Key": "checkpoints/job-raw/step-250/checkpoint.pt", "Size": 2000},
        {"Key": "checkpoints/job-raw/step-500/checkpoint.pt", "Size": 2000},
        {"Key": "checkpoints/job-raw/step-500/optimizer.pt", "Size": 1000},
    ]
    s3 = MagicMock()
    s3.list_objects_v2 = MagicMock(return_value={"Contents": contents, "IsTruncated": False})
    with patch("boto3.client", return_value=s3):
        from api.job_worker import _find_checkpoint
        result = _find_checkpoint("job-raw")
    assert result is not None, "step-N/ format must be recognized"
    assert result["step"] == 500, f"expected latest step 500, got {result['step']}"


def test_find_checkpoint_raw_pytorch_and_hf_mixed(monkeypatch):
    """Mixed job: raw PyTorch at step 200, HF at step 400. Latest must win."""
    _make_r2_env(monkeypatch)
    contents = [
        {"Key": "checkpoints/job-mix/step-200/checkpoint.pt", "Size": 1000},
        {"Key": "checkpoints/job-mix/checkpoint-400/model.safetensors", "Size": 5000},
    ]
    s3 = MagicMock()
    s3.list_objects_v2 = MagicMock(return_value={"Contents": contents, "IsTruncated": False})
    with patch("boto3.client", return_value=s3):
        from api.job_worker import _find_checkpoint
        result = _find_checkpoint("job-mix")
    assert result["step"] == 400


# ── P2.1: Pagination ─────────────────────────────────────────────────────────

def test_find_checkpoint_follows_pagination(monkeypatch):
    """With >1000 R2 objects _find_checkpoint must follow ContinuationToken.

    A 7B FSDP checkpoint writes ~100 shard files per step. With 3 saved steps
    that's ~300 objects — but with more steps or more shards it exceeds 1000.
    Before the fix, only the first page was read and a stale step could be returned.
    """
    _make_r2_env(monkeypatch)
    page1_contents = [
        {"Key": "checkpoints/job-pg/checkpoint-50/model.safetensors", "Size": 100},
    ]
    page2_contents = [
        {"Key": "checkpoints/job-pg/checkpoint-200/model.safetensors", "Size": 200},
    ]

    call_count = [0]
    def _list_side_effect(**kwargs):
        call_count[0] += 1
        if call_count[0] == 1:
            return {
                "Contents": page1_contents,
                "IsTruncated": True,
                "NextContinuationToken": "token123",
            }
        else:
            assert kwargs.get("ContinuationToken") == "token123", "must pass continuation token"
            return {"Contents": page2_contents, "IsTruncated": False}

    s3 = MagicMock()
    s3.list_objects_v2 = MagicMock(side_effect=_list_side_effect)
    with patch("boto3.client", return_value=s3):
        from api.job_worker import _find_checkpoint
        result = _find_checkpoint("job-pg")

    assert call_count[0] == 2, "must make two list calls for two pages"
    assert result is not None
    assert result["step"] == 200, f"must find step 200 from page 2, got {result}"


# ── P1.2: Completion detection fallbacks ─────────────────────────────────────

@pytest.mark.asyncio
async def test_check_completion_r2_sentinel_fallback(monkeypatch):
    """_check_completion() must return True when R2 _COMPLETED sentinel exists,
    even if DB has no 'Training finished' log.

    If the container's final /logs POST fails, the DB stays empty but the sentinel
    was written to R2 before the POST. Without this fallback a successful job gets
    re-queued as lost.
    """
    _make_r2_env(monkeypatch)

    def _db_no_data():
        result = MagicMock()
        result.data = []
        return result

    def _r2_sentinel_found(**kwargs):
        # head_object returns without raising → sentinel exists
        return {}

    s3 = MagicMock()
    s3.head_object = MagicMock(side_effect=_r2_sentinel_found)

    # DB returns empty for job_logs AND job_events
    db = MagicMock()
    db.table.return_value.select.return_value.eq.return_value.like.return_value.limit.return_value.execute = MagicMock(return_value=_db_no_data())
    db.table.return_value.select.return_value.eq.return_value.eq.return_value.limit.return_value.execute = MagicMock(return_value=_db_no_data())

    with patch("boto3.client", return_value=s3), \
         patch("api.job_worker.get_db", return_value=db):
        from api.job_worker import _check_completion
        result = await _check_completion("sentinel-job-123")

    assert result is True, "R2 _COMPLETED sentinel must signal completion"


@pytest.mark.asyncio
async def test_check_completion_job_events_fallback(monkeypatch):
    """_check_completion() must return True when job_events has event_type=completed.

    The container posts /events separately from /logs. If /logs fails but /events
    succeeds, completion should still be detected.
    """
    _make_r2_env(monkeypatch)

    empty_result = MagicMock()
    empty_result.data = []

    events_result = MagicMock()
    events_result.data = [{"event_type": "completed", "message": "exit_code=0"}]

    # head_object raises (sentinel not found)
    s3 = MagicMock()
    s3.head_object = MagicMock(side_effect=Exception("NoSuchKey"))

    db_call_count = [0]
    def _db_table(table_name):
        mock = MagicMock()
        if table_name == "job_events":
            # chain: .select().eq(job_id).in_(event_type).order().limit().execute()
            (
                mock.select.return_value
                .eq.return_value
                .in_.return_value
                .order.return_value
                .limit.return_value
                .execute
            ) = MagicMock(return_value=events_result)
        else:
            mock.select.return_value.eq.return_value.like.return_value.limit.return_value.execute = MagicMock(return_value=empty_result)
        return mock

    db = MagicMock()
    db.table = MagicMock(side_effect=_db_table)

    with patch("boto3.client", return_value=s3), \
         patch("api.job_worker.get_db", return_value=db):
        from api.job_worker import _check_completion
        result = await _check_completion("events-job-456")

    assert result is True, "job_events completed entry must signal completion"


# ── P1.3: VM startup script final sync ───────────────────────────────────────

def test_vm_startup_final_sync_before_completion_signal():
    """VM startup script must force a final rclone sync BEFORE 'Training finished'.

    The worker polls job_logs for 'Training finished' and calls _terminate_and_settle()
    immediately on detection. If the sync ran after that echo it would race with
    instance termination and checkpoints written near the end of training would be lost.
    The sync must appear before any worker-visible completion signal.
    """
    from agents.broker.startup_scripts import build_vm_startup_script
    broker, job = _mock_broker_and_job()
    script = build_vm_startup_script(broker, job)

    sync_pos = script.find("Final checkpoint sync to R2 complete")
    finished_pos = script.find("Training finished")
    assert sync_pos > 0, "script must contain final checkpoint sync"
    assert finished_pos > 0, "script must contain 'Training finished'"
    assert sync_pos < finished_pos, (
        "final rclone sync must appear BEFORE 'Training finished' echo — "
        "worker terminates immediately on 'Training finished' detection"
    )


def test_container_startup_final_sync_before_completion_signals():
    """Container startup script must sync checkpoints BEFORE _COMPLETED sentinel and log POST.

    Worker can detect completion via _COMPLETED (R2), job_events.completed, or
    'Training finished' in logs — all three must come AFTER the sync completes.
    """
    from agents.broker.startup_scripts import build_container_onstart
    broker, job = _mock_broker_and_job()
    script = build_container_onstart(broker, job)

    sync_pos = script.find("Final checkpoint sync to R2 complete")
    sentinel_pos = script.find("_COMPLETED_SENTINEL")
    finished_pos = script.find("Training finished")
    assert sync_pos > 0, "container script must contain final checkpoint sync"
    assert sync_pos < sentinel_pos, "sync must appear before _COMPLETED sentinel write"
    assert sync_pos < finished_pos, "sync must appear before 'Training finished' echo"


# ── P1.4: VAULTLAYER_RESUME_CHECKPOINT injection ─────────────────────────────

def test_vm_startup_injects_resume_checkpoint_when_checkpoint_step_set():
    """VM startup script must export VAULTLAYER_RESUME_CHECKPOINT when checkpoint_step is set.

    HF Trainer and Lightning scripts use:
      trainer.train(resume_from_checkpoint=os.environ.get("VAULTLAYER_RESUME_CHECKPOINT"))
    Without this env var, a script that follows the CLI 'zero_code' guidance will
    restart from step 0 even though the checkpoint files are in CHECKPOINT_DIR.
    """
    from agents.broker.startup_scripts import build_vm_startup_script
    broker, job = _mock_broker_and_job(checkpoint_step=200)
    script = build_vm_startup_script(broker, job)

    assert "VAULTLAYER_RESUME_CHECKPOINT" in script, "must export VAULTLAYER_RESUME_CHECKPOINT"
    # Step number is baked in via _VL_CKPT_STEP; path uses runtime format detection
    assert "_VL_CKPT_STEP=200" in script, "must embed checkpoint step number"
    assert "checkpoint-$_VL_CKPT_STEP" in script, "must reference checkpoint dir via variable"


def test_vm_startup_no_resume_checkpoint_when_no_checkpoint_step():
    """On first legs (checkpoint_step=None), VAULTLAYER_RESUME_CHECKPOINT must NOT be set."""
    from agents.broker.startup_scripts import build_vm_startup_script
    broker, job = _mock_broker_and_job(checkpoint_step=None)
    script = build_vm_startup_script(broker, job)

    assert "VAULTLAYER_RESUME_CHECKPOINT" not in script, (
        "must not set VAULTLAYER_RESUME_CHECKPOINT on first legs "
        "(no checkpoint to resume from)"
    )


def test_container_startup_injects_resume_checkpoint_when_checkpoint_step_set():
    """Container (RunPod/Vast.ai) startup must also inject VAULTLAYER_RESUME_CHECKPOINT."""
    from agents.broker.startup_scripts import build_container_onstart
    broker, job = _mock_broker_and_job(checkpoint_step=400)
    script = build_container_onstart(broker, job)

    assert "VAULTLAYER_RESUME_CHECKPOINT" in script
    # Step number is baked in via _VL_CKPT_STEP; path uses runtime format detection
    assert "_VL_CKPT_STEP=400" in script, "must embed checkpoint step number"
    assert "checkpoint-$_VL_CKPT_STEP" in script, "must reference checkpoint dir via variable"


def test_init_output_does_not_claim_hf_lightning_zero_code_resume(tmp_path):
    """`vaultlayer init` must not tell HF/Lightning users resume is automatic."""
    from click.testing import CliRunner
    from cli.main import cli

    resp = MagicMock()
    resp.json.return_value = {
        "valid": True,
        "email": "test@example.com",
        "balance_credits": 100,
    }
    resp.raise_for_status = MagicMock()

    runner = CliRunner()
    with patch("httpx.post", return_value=resp):
        result = runner.invoke(
            cli,
            [
                "init",
                "--token",
                "vl_test_initresume",
                "--output-dir",
                str(tmp_path / "helpers"),
            ],
            env={"HOME": str(tmp_path)},
        )

    assert result.exit_code == 0, result.output
    assert "zero-code resume is automatic" not in result.output
    assert "resume_from_checkpoint=os.environ.get('VAULTLAYER_RESUME_CHECKPOINT')" in result.output
    assert "ckpt_path=os.environ.get('VAULTLAYER_RESUME_CHECKPOINT')" in result.output


# ── P2.2: CLI local fallback checkpoint format ────────────────────────────────

def test_cli_find_checkpoint_in_r2_recognises_hf_format():
    """CLI _find_checkpoint_in_r2() must recognise checkpoint-<N>/ (HF canonical format).

    The CLI fallback path was only scanning step-<N>/ prefixes. HF Trainer jobs
    write checkpoint-<N>/ so the CLI showed 'no checkpoint found' on resume for
    all HF jobs, even when checkpoint-200/ existed in R2.
    """
    s3 = MagicMock()
    s3.list_objects_v2 = MagicMock(side_effect=[
        # CommonPrefixes listing
        {
            "CommonPrefixes": [
                {"Prefix": "checkpoints/cli-job/checkpoint-100/"},
                {"Prefix": "checkpoints/cli-job/checkpoint-300/"},
            ]
        },
        # Size listing for checkpoint-300/
        {"Contents": [{"Size": 4096}, {"Size": 8192}]},
    ])
    with patch("boto3.client", return_value=s3):
        from cli._remote import _find_checkpoint_in_r2
        result = _find_checkpoint_in_r2(
            "cli-job", "https://r2.test", "key", "secret", "test-bucket"
        )
    assert result is not None, "HF checkpoint-N/ must be found by CLI fallback"
    assert result["step"] == 300, f"expected latest step 300, got {result}"


def test_cli_find_checkpoint_in_r2_step_format_still_works():
    """CLI fallback must still recognise step-<N>/ for raw PyTorch jobs."""
    s3 = MagicMock()
    s3.list_objects_v2 = MagicMock(side_effect=[
        {
            "CommonPrefixes": [
                {"Prefix": "checkpoints/cli-job2/step-100/"},
                {"Prefix": "checkpoints/cli-job2/step-500/"},
            ]
        },
        {"Contents": [{"Size": 2048}]},
    ])
    with patch("boto3.client", return_value=s3):
        from cli._remote import _find_checkpoint_in_r2
        result = _find_checkpoint_in_r2(
            "cli-job2", "https://r2.test", "key", "secret", "test-bucket"
        )
    assert result is not None
    assert result["step"] == 500


def test_cli_find_checkpoint_in_r2_hf_beats_older_step():
    """If both formats exist, latest step wins regardless of format."""
    s3 = MagicMock()
    s3.list_objects_v2 = MagicMock(side_effect=[
        {
            "CommonPrefixes": [
                {"Prefix": "checkpoints/mix-job/step-100/"},
                {"Prefix": "checkpoints/mix-job/checkpoint-250/"},
            ]
        },
        {"Contents": [{"Size": 1000}]},
    ])
    with patch("boto3.client", return_value=s3):
        from cli._remote import _find_checkpoint_in_r2
        result = _find_checkpoint_in_r2(
            "mix-job", "https://r2.test", "key", "secret", "test-bucket"
        )
    assert result["step"] == 250


def test_sync_queue_state_preserves_validated_dataset_scope():
    """Backoff persistence must not drop the server-validated dataset fields.

    Without this, a queued dataset job that backs off and then survives a worker
    restart loses dataset_id from queue_state. The recovered job then mints only
    checkpoint-scoped R2 credentials and dataset warmup 403s.
    """
    from api.job_worker import _sync_queue_state

    job = {
        "job_id": "job-ds",
        "user_id": "user-1",
        "gpu_type": "A100",
        "environment": {"VAULTLAYER_DATASET_ID": "ds-owned"},
        "dataset_id": "ds-owned",
        "dataset_r2_prefix": "datasets/ds-owned/",
        "_provision_retry_count": 2,
    }

    with patch("shared.job_run_logger.update_run") as mock_update:
        _sync_queue_state("run-1", job)

    queue_state = mock_update.call_args.kwargs["queue_state"]
    assert queue_state["dataset_id"] == "ds-owned"
    assert queue_state["dataset_r2_prefix"] == "datasets/ds-owned/"
