import re

from .base import BaseDetector
from injectguard.models import DetectorMatch


class HeuristicDetector(BaseDetector):
    def detect(self, text, categories=None):
        matches = []
        allowed = None if not categories or categories == ["all"] else set(categories)

        def enabled(flag: str) -> bool:
            return allowed is None or flag in allowed

        if enabled("encoding_attack") and self._has_base64(text):
            matches.append(
                DetectorMatch("encoding_attack", 0.70, "base64 detected", "heuristic")
            )
        if enabled("unicode_homoglyph") and self._has_homoglyphs(text):
            matches.append(
                DetectorMatch("unicode_homoglyph", 0.65, "lookalike chars", "heuristic")
            )
        if enabled("special_char_abuse") and self._high_special_char_ratio(text):
            matches.append(
                DetectorMatch("special_char_abuse", 0.50, "excessive specials", "heuristic")
            )
        return matches

    def _has_base64(self, text):
        return bool(re.search(r"(?:[A-Za-z0-9+/]{40,}={0,2})", text))

    def _has_homoglyphs(self, text):
        suspicious = set("аеіорсух")
        return any(char.lower() in suspicious for char in text)

    def _high_special_char_ratio(self, text):
        if not text:
            return False
        specials = sum(1 for char in text if char in "!@#$%^&*|<>{}[]")
        return specials / len(text) > 0.3
