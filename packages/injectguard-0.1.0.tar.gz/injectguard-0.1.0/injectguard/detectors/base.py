from abc import ABC, abstractmethod

from injectguard.models import DetectorMatch


class BaseDetector(ABC):
    @abstractmethod
    def detect(self, text: str, categories: list[str] | None = None) -> list[DetectorMatch]:
        raise NotImplementedError
