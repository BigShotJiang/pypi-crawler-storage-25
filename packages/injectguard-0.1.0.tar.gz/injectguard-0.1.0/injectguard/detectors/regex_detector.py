import re

from .base import BaseDetector
from injectguard.models import DetectorMatch
from injectguard.rules import RULES


class RegexDetector(BaseDetector):
    def detect(self, text, categories=None):
        matches = []
        allowed = None if not categories or categories == ["all"] else set(categories)

        for rule in RULES:
            if allowed is not None and rule["flag"] not in allowed:
                continue

            match = re.search(rule["pattern"], text, re.IGNORECASE)
            if match:
                matches.append(
                    DetectorMatch(
                        flag=rule["flag"],
                        weight=rule["weight"],
                        matched=match.group(),
                        detector="regex",
                    )
                )
        return matches
