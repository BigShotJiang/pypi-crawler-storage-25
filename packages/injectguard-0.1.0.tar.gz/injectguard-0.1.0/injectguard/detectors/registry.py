class DetectorRegistry:
    _detectors = []

    @classmethod
    def register(cls, detector):
        detector_type = type(detector)
        if any(isinstance(existing, detector_type) for existing in cls._detectors):
            return
        cls._detectors.append(detector)

    @classmethod
    def run_all(cls, text, categories=None):
        results = []
        for detector in cls._detectors:
            results.extend(detector.detect(text, categories=categories))
        return results
