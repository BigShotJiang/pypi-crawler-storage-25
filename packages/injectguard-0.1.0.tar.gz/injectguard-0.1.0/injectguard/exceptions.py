class PromptInjectionError(Exception):
    def __init__(self, result):
        self.result = result
        super().__init__(f"Blocked: {result.flags}")
