from dataclasses import dataclass, field


@dataclass
class DetectorMatch:
    flag: str
    weight: float
    matched: str
    detector: str


@dataclass
class ScanResult:
    is_injection: bool
    risk_score: float
    confidence: str
    flags: list[str] = field(default_factory=list)
    explanation: str = "Clean"
