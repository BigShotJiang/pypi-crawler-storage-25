RULES = [
    {
        "pattern": r"ignore (all )?(previous|prior) instructions",
        "flag": "instruction_override",
        "weight": 0.85,
    },
    {
        "pattern": r"(reveal|show|dump|print).*(system prompt|instructions)",
        "flag": "system_prompt_leak",
        "weight": 0.90,
    },
    {
        "pattern": r"you are now|act as|pretend to be",
        "flag": "role_hijack",
        "weight": 0.80,
    },
    {
        "pattern": r"<\|im_start\|>|<\|im_end\|>|\[INST\]|\[/INST\]",
        "flag": "delimiter_injection",
        "weight": 0.75,
    },
    {
        "pattern": r"(assistant|system)\s*:",
        "flag": "context_manipulation",
        "weight": 0.85,
    },
]
