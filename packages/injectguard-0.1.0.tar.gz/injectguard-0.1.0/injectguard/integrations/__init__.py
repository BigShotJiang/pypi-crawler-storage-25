"""Integration entry points for framework-specific adapters."""
