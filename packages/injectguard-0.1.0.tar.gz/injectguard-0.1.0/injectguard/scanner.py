from .config import Config
from .exceptions import PromptInjectionError
from .models import ScanResult
from .detectors.heuristic_detector import HeuristicDetector
from .detectors.regex_detector import RegexDetector
from .detectors.registry import DetectorRegistry
from .utils import calculate_score, get_confidence, normalize_text

# Register default detectors once for the default registry.
DetectorRegistry.register(RegexDetector())
DetectorRegistry.register(HeuristicDetector())


class Scanner:
    def __init__(self, **kwargs):
        self.config = Config(**kwargs)

    def scan(self, text):
        text = normalize_text(text)
        lowered = text.lower()

        if len(text) > self.config.max_length:
            return ScanResult(True, 1.0, "high", ["max_length"], "Input too long")

        if any(safe in lowered for safe in self.config.allowlist):
            return ScanResult(False, 0.0, "low", [], "Allowlisted")

        if any(bad in lowered for bad in self.config.blocklist):
            return ScanResult(True, 1.0, "high", ["blocklisted"], "Blocklisted")

        matches = DetectorRegistry.run_all(text, categories=self.config.categories)
        score = calculate_score(matches)
        flags = sorted({match.flag for match in matches})

        result = ScanResult(
            is_injection=score >= self.config.threshold,
            risk_score=score,
            confidence=get_confidence(score),
            flags=flags,
            explanation=f"Detected: {', '.join(flags)}" if flags else "Clean",
        )

        if self.config.on_detect == "block" and result.is_injection:
            raise PromptInjectionError(result)

        if self.config.on_detect == "sanitize" and result.is_injection:
            result.explanation = "Potential prompt injection detected; input should be sanitized"

        return result
