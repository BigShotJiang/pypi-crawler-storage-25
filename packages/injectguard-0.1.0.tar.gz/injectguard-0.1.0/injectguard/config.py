from dataclasses import dataclass, field

from .categories import CATEGORIES

PRESETS = {"strict": 0.4, "moderate": 0.6, "relaxed": 0.8}


@dataclass
class Config:
    threshold: float = 0.6
    categories: list[str] = field(default_factory=lambda: ["all"])
    on_detect: str = "flag"
    allowlist: list[str] = field(default_factory=list)
    blocklist: list[str] = field(default_factory=list)
    max_length: int = 10000

    def __post_init__(self):
        if isinstance(self.threshold, str):
            if self.threshold not in PRESETS:
                raise ValueError(f"Unknown threshold preset: {self.threshold}")
            self.threshold = PRESETS[self.threshold]

        if not 0 <= self.threshold <= 1:
            raise ValueError("threshold must be between 0 and 1")

        if self.on_detect not in {"flag", "block", "sanitize"}:
            raise ValueError("on_detect must be 'flag', 'block', or 'sanitize'")

        if self.max_length <= 0:
            raise ValueError("max_length must be positive")

        if self.categories != ["all"]:
            invalid = [name for name in self.categories if name not in CATEGORIES]
            if invalid:
                raise ValueError(f"Unknown categories: {invalid}")

        self.allowlist = [item.lower() for item in self.allowlist]
        self.blocklist = [item.lower() for item in self.blocklist]
