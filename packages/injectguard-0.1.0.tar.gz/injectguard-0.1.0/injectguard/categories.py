CATEGORIES = {
    "instruction_override": "Attempts to override system instructions",
    "system_prompt_leak": "Tries to extract system prompt",
    "role_hijack": "Attempts to change AI role",
    "delimiter_injection": "Uses fake delimiters/tags",
    "encoding_attack": "Hides payload in base64/hex/rot13",
    "unicode_homoglyph": "Uses lookalike unicode characters",
    "special_char_abuse": "Excessive special characters",
    "context_manipulation": "Fakes assistant/system messages",
}
