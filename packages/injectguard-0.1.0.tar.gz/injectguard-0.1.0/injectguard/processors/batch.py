from .base import BaseProcessor


class BatchProcessor(BaseProcessor):
    def process(self, texts, scanner):
        if not isinstance(texts, (list, tuple)):
            raise TypeError("texts must be a list or tuple")
        return [scanner.scan(text) for text in texts]


def process(texts, scanner):
    return BatchProcessor().process(texts, scanner)
