from .base import BaseProcessor
from .text import process as process_text


class MessagesProcessor(BaseProcessor):
    def process(self, messages, scanner):
        if not isinstance(messages, (list, tuple)):
            raise TypeError("messages must be a list or tuple")

        lines = []
        for item in messages:
            if isinstance(item, dict):
                role = item.get("role", "user")
                content = item.get("content", "")
                lines.append(f"{role}: {content}")
            else:
                lines.append(str(item))

        return process_text("\n".join(lines), scanner)


def process(messages, scanner):
    return MessagesProcessor().process(messages, scanner)
