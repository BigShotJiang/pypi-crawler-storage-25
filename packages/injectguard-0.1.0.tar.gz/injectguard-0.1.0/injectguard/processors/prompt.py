from .base import BaseProcessor
from .text import process as process_text


class PromptProcessor(BaseProcessor):
    def process(self, template, variables, scanner):
        if variables is None:
            variables = {}

        try:
            rendered = template.format(**variables)
        except Exception:
            rendered = template

        return process_text(rendered, scanner)


def process(template, variables, scanner):
    return PromptProcessor().process(template, variables, scanner)
