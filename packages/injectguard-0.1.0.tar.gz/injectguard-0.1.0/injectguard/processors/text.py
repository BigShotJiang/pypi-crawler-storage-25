from .base import BaseProcessor
from injectguard.utils import normalize_text


class TextProcessor(BaseProcessor):
    def process(self, value, scanner):
        return scanner.scan(normalize_text(value))


def process(value, scanner):
    return TextProcessor().process(value, scanner)
