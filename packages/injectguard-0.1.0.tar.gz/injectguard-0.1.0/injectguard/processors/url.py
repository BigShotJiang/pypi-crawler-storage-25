from urllib.parse import parse_qs, unquote, urlparse

from .base import BaseProcessor
from .text import process as process_text


class URLProcessor(BaseProcessor):
    def process(self, url, scanner):
        parsed = urlparse(url)
        parts = [parsed.path, unquote(parsed.query)]

        for values in parse_qs(parsed.query).values():
            parts.extend(values)

        payload = "\n".join(part for part in parts if part)
        return process_text(payload, scanner)


def process(url, scanner):
    return URLProcessor().process(url, scanner)
