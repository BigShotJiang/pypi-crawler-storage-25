from .scanner import Scanner

_default = Scanner()


def scan(text: str):
    return _default.scan(text)


def scan_messages(messages):
    from .processors.messages import process

    return process(messages, _default)


def scan_prompt(template: str, variables):
    from .processors.prompt import process

    return process(template, variables, _default)


def scan_url(url: str):
    from .processors.url import process

    return process(url, _default)


def scan_batch(texts):
    from .processors.batch import process

    return process(texts, _default)


__all__ = [
    "Scanner",
    "scan",
    "scan_messages",
    "scan_prompt",
    "scan_url",
    "scan_batch",
]
