def calculate_score(matches):
    if not matches:
        return 0.0

    weights = [match.weight for match in matches]
    base = max(weights)
    boost = (len(weights) - 1) * 0.08
    return min(round(base + boost, 2), 1.0)


def get_confidence(score):
    if score > 0.8:
        return "high"
    if score > 0.5:
        return "medium"
    return "low"


def normalize_text(value) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return str(value)
