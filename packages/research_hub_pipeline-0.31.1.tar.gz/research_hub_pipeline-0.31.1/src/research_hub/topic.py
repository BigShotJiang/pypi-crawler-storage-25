"""Topic overview notes: emit digests, scaffold, and manage cluster sub-topics."""

from __future__ import annotations

from dataclasses import dataclass, field
import logging
from pathlib import Path
import re

from research_hub.security import safe_join


logger = logging.getLogger(__name__)

OVERVIEW_FILENAME = "00_overview.md"
SUBTOPICS_DIRNAME = "topics"
OVERVIEW_TEMPLATE = """---
type: topic-overview
cluster: {cluster_slug}
title: {cluster_title}
status: draft
---

# {cluster_title}

## TL;DR

一到兩句話說清楚這個 cluster 在研究什麼、解決什麼問題。

## 核心問題

> 用 blockquote 寫下這個領域的中心開放問題。

## 範圍定義

**涵蓋:**
-
-

**不涵蓋:**
-
-

## 領域地圖

| 子主題 | 連結 | 一行摘要 |
|---|---|---|
|  |  |  |

## 關鍵概念詞彙表

| 術語 | 定義 |
|---|---|
|  |  |

## 必讀論文

| 論文 | 年份 | 為何必讀 |
|---|---|---|
|  |  |  |

## 時間線

| 時期 | 里程碑 |
|---|---|
|  |  |

## 開放問題

1. **問題** — 一句話描述為何還沒解
2. **問題** — 一句話描述

## 連結

-

## 延伸閱讀

-
"""
SUBTOPIC_TEMPLATE = """---
type: cluster-subtopic
cluster: {cluster_slug}
subtopic: {subtopic_slug}
title: {subtopic_title}
papers: {paper_count}
status: draft
---

# {subtopic_title}

## TL;DR

一到兩句話說清楚這個子主題在幹嘛、為何重要。

## 核心問題

> 用一句話 blockquote 寫下這個子主題要回答的核心研究問題。

## 範圍

**涵蓋:**
-
-

**不涵蓋:**
-
-

## 關鍵概念

| 術語 | 定義 |
|---|---|
|  |  |

## 分類法

| 類別 | 範例 | 特色 |
|---|---|---|
|  |  |  |

## 代表論文

| 論文 | 作者 (年) | 貢獻 |
|---|---|---|
|  |  |  |

## Papers

{papers_markdown}

## 時間線

| 期間 | 里程碑 |
|---|---|
|  |  |

## 開放問題

1. **問題** — 一句話描述為何還沒解
2. **問題** — 一句話描述

## 連結

- [[00_overview]] — cluster 總覽

## See also

-
"""


@dataclass
class PaperDigestEntry:
    slug: str
    title: str
    authors: list[str]
    year: int | None
    doi: str
    abstract: str


@dataclass
class TopicDigest:
    cluster_slug: str
    cluster_title: str
    paper_count: int
    papers: list[PaperDigestEntry] = field(default_factory=list)

    def to_markdown(self) -> str:
        """Render a single markdown blob an AI can read."""
        lines = [f"# {self.cluster_title}", "", f"{self.paper_count} papers.", ""]
        for paper in self.papers:
            lines.append(f"### {paper.title}")
            authors = ", ".join(paper.authors[:5])
            if len(paper.authors) > 5:
                authors += f" +{len(paper.authors) - 5} more"
            lines.append(f"*{authors}* - {paper.year or '????'} - {paper.doi or '(no DOI)'}")
            lines.append("")
            if paper.abstract:
                lines.append("> " + paper.abstract.replace("\n", "\n> "))
            else:
                lines.append("> (no abstract)")
            lines.append("")
        return "\n".join(lines)


@dataclass
class SubtopicProposal:
    slug: str
    title: str
    description: str = ""


@dataclass
class SubtopicDescriptor:
    slug: str
    title: str
    path: Path
    paper_count: int


def hub_cluster_dir(cfg, cluster_slug: str) -> Path:
    hub_root = getattr(cfg, "hub", None)
    if hub_root is None:
        root = getattr(cfg, "root", None)
        if root is None:
            raise AttributeError("config must define either 'hub' or 'root'")
        hub_root = Path(root) / "research_hub" / "hub"
    return safe_join(Path(hub_root), cluster_slug)


def overview_path(cfg, cluster_slug: str) -> Path:
    return hub_cluster_dir(cfg, cluster_slug) / OVERVIEW_FILENAME


def subtopics_dir(cfg, cluster_slug: str) -> Path:
    """<vault>/raw/<cluster>/topics/"""
    return safe_join(cfg.raw, cluster_slug, SUBTOPICS_DIRNAME)


def get_topic_digest(cfg, cluster_slug: str) -> TopicDigest:
    """Build a digest of every paper note in the cluster."""
    from research_hub.clusters import ClusterRegistry

    registry = ClusterRegistry(cfg.clusters_file)
    cluster = registry.get(cluster_slug)
    if cluster is None:
        raise ValueError(f"unknown cluster: {cluster_slug}")

    cluster_dir = safe_join(cfg.raw, cluster_slug)
    if not cluster_dir.exists():
        return TopicDigest(cluster_slug=cluster_slug, cluster_title=cluster.name, paper_count=0)

    papers: list[PaperDigestEntry] = []
    for note_path in sorted(cluster_dir.glob("*.md")):
        if note_path.name in {OVERVIEW_FILENAME, "index.md"}:
            continue
        meta, abstract = _parse_note(note_path)
        year_text = meta.get("year", "")
        papers.append(
            PaperDigestEntry(
                slug=note_path.stem,
                title=meta.get("title", note_path.stem),
                authors=_split_authors(meta.get("authors", "")),
                year=int(year_text) if year_text.isdigit() else None,
                doi=meta.get("doi", ""),
                abstract=abstract,
            )
        )

    return TopicDigest(
        cluster_slug=cluster_slug,
        cluster_title=cluster.name,
        paper_count=len(papers),
        papers=papers,
    )


def scaffold_overview(cfg, cluster_slug: str, *, force: bool = False) -> Path:
    """Create the overview template for a cluster."""
    from research_hub.clusters import ClusterRegistry

    registry = ClusterRegistry(cfg.clusters_file)
    cluster = registry.get(cluster_slug)
    if cluster is None:
        raise ValueError(f"unknown cluster: {cluster_slug}")

    path = overview_path(cfg, cluster_slug)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not force:
        raise FileExistsError(f"overview already exists at {path}")
    path.write_text(
        OVERVIEW_TEMPLATE.format(cluster_slug=cluster_slug, cluster_title=cluster.name),
        encoding="utf-8",
    )
    return path


def read_overview(cfg, cluster_slug: str) -> str | None:
    """Return overview markdown or None if it does not exist."""
    path = overview_path(cfg, cluster_slug)
    if not path.exists():
        return None
    return path.read_text(encoding="utf-8")


def emit_propose_prompt(cfg, cluster_slug: str, target_count: int = 5) -> str:
    """Build a Phase 1 prompt that asks an AI to propose N sub-topics."""
    digest = get_topic_digest(cfg, cluster_slug)
    return (
        f'# Sub-topic proposal: cluster "{cluster_slug}"\n\n'
        "## Cluster digest\n\n"
        f"{digest.to_markdown()}\n\n"
        "## Instructions\n\n"
        f"Propose {target_count} natural sub-topics for this cluster. Each sub-topic\n"
        "should have a short slug (kebab-case, lowercase), a display title, and a\n"
        "one-paragraph description. Pick groupings that cover as many papers as\n"
        "possible without being so broad they lose meaning.\n\n"
        "Identify 3-6 natural groupings that cover most papers.\n\n"
        "## Your output\n\n"
        "Emit ONE JSON object:\n\n"
        "```json\n"
        '{\n'
        '  "subtopics": [\n'
        "    {\n"
        '      "slug": "benchmarks",\n'
        '      "title": "Benchmarks",\n'
        '      "description": "Standardized evaluation datasets for LLM agents on SE tasks."\n'
        "    },\n"
        "    {\n"
        '      "slug": "agent-interfaces",\n'
        '      "title": "Agent-Computer Interfaces",\n'
        '      "description": "How agents interact with files, terminals, and repositories."\n'
        "    }\n"
        "  ]\n"
        "}\n"
        "```"
    )


def emit_assign_prompt(
    cfg,
    cluster_slug: str,
    subtopics: list[SubtopicProposal],
) -> str:
    """Build a Phase 2 prompt that asks an AI to map papers to sub-topics."""
    digest = get_topic_digest(cfg, cluster_slug)
    subtopic_lines: list[str] = []
    for subtopic in subtopics:
        subtopic_lines.append(f"- `{subtopic.slug}` - {subtopic.title}")
        if subtopic.description:
            subtopic_lines.append(f"  {subtopic.description}")
    return (
        f'# Sub-topic assignment: cluster "{cluster_slug}"\n\n'
        "## Proposed sub-topics\n\n"
        f"{chr(10).join(subtopic_lines) if subtopic_lines else '(none)'}\n\n"
        "## Papers\n\n"
        f"{digest.to_markdown()}\n\n"
        "## Instructions\n\n"
        "Map each paper to one or more sub-topic slugs from the proposed list.\n"
        "A paper can belong to multiple sub-topics when that reflects the actual\n"
        "content. Typical range is 1-3 slugs per paper, max 4.\n\n"
        "## Your output\n\n"
        "Emit ONE JSON object:\n\n"
        "```json\n"
        "{\n"
        '  "assignments": {\n'
        '    "2024-jimenez-swe-bench": ["benchmarks", "evaluation-methods"],\n'
        '    "2024-yang-swe-agent": ["agent-interfaces"],\n'
        '    "2024-wang-opendevin": ["agent-interfaces", "multi-agent-coordination"]\n'
        "  }\n"
        "}\n"
        "```"
    )


def apply_assignments(
    cfg,
    cluster_slug: str,
    assignments: dict[str, list[str]],
) -> dict[str, int]:
    """Write `subtopics:` frontmatter field to each paper note."""
    cluster_dir = safe_join(cfg.raw, cluster_slug)
    report: dict[str, int] = {}
    for paper_slug, values in assignments.items():
        note_path = cluster_dir / f"{paper_slug}.md"
        if not note_path.exists():
            logger.warning("unknown paper slug for cluster %s: %s", cluster_slug, paper_slug)
            continue
        cleaned = _normalize_subtopic_values(values)
        text = note_path.read_text(encoding="utf-8")
        updated = _upsert_frontmatter_subtopics(text, cleaned)
        note_path.write_text(updated, encoding="utf-8")
        report[paper_slug] = len(cleaned)
    return report


def build_subtopic_notes(cfg, cluster_slug: str) -> list[Path]:
    """Generate topics/NN_<slug>.md files for each unique sub-topic present in paper frontmatter."""
    from research_hub.clusters import ClusterRegistry

    registry = ClusterRegistry(cfg.clusters_file)
    cluster = registry.get(cluster_slug)
    if cluster is None:
        raise ValueError(f"unknown cluster: {cluster_slug}")

    cluster_dir = safe_join(cfg.raw, cluster_slug)
    topics_root = subtopics_dir(cfg, cluster_slug)
    topics_root.mkdir(parents=True, exist_ok=True)

    subtopic_to_papers: dict[str, list[PaperDigestEntry]] = {}
    paper_meta_by_slug: dict[str, dict[str, str]] = {}
    for note_path in sorted(cluster_dir.glob("*.md")):
        if note_path.name in {OVERVIEW_FILENAME, "index.md"}:
            continue
        meta, abstract = _parse_note(note_path)
        meta["__body_text__"] = _strip_frontmatter(note_path.read_text(encoding="utf-8"))
        paper = PaperDigestEntry(
            slug=note_path.stem,
            title=meta.get("title", note_path.stem),
            authors=_split_authors(meta.get("authors", "")),
            year=int(meta["year"]) if meta.get("year", "").isdigit() else None,
            doi=meta.get("doi", ""),
            abstract=abstract,
        )
        paper_meta_by_slug[paper.slug] = meta
        for subtopic_slug in _read_subtopics_from_paper_note(note_path):
            subtopic_to_papers.setdefault(subtopic_slug, []).append(paper)

    number_map = _existing_subtopic_numbers(topics_root)
    used_numbers = set(number_map.values())
    next_number = 1
    written: list[Path] = []

    for slug in sorted(subtopic_to_papers):
        if slug in number_map:
            number = number_map[slug]
        else:
            while next_number in used_numbers:
                next_number += 1
            number = next_number
            used_numbers.add(number)
        path = topics_root / f"{number:02d}_{slug}.md"
        title = _existing_subtopic_title(path) or _humanize_slug(slug)
        papers = subtopic_to_papers[slug]
        papers_markdown = _render_papers_markdown(papers, paper_meta_by_slug)
        if path.exists():
            text = path.read_text(encoding="utf-8")
            text = _update_subtopic_frontmatter(
                text,
                cluster_slug=cluster_slug,
                subtopic_slug=slug,
                subtopic_title=title,
                paper_count=len(papers),
            )
            path.write_text(text, encoding="utf-8")
            _write_papers_section(path, papers, paper_meta_by_slug)
        else:
            path.write_text(
                SUBTOPIC_TEMPLATE.format(
                    cluster_slug=cluster_slug,
                    subtopic_slug=slug,
                    subtopic_title=title,
                    paper_count=len(papers),
                    papers_markdown=papers_markdown,
                ),
                encoding="utf-8",
            )
        written.append(path)

    return written


def list_subtopics(cfg, cluster_slug: str) -> list[SubtopicDescriptor]:
    """Enumerate existing sub-topic notes for a cluster."""
    topics_root = subtopics_dir(cfg, cluster_slug)
    if not topics_root.exists():
        return []
    descriptors: list[SubtopicDescriptor] = []
    for path in sorted(topics_root.glob("[0-9][0-9]_*.md")):
        slug = _slug_from_topic_filename(path)
        title = _existing_subtopic_title(path) or _humanize_slug(slug)
        paper_count = _existing_subtopic_paper_count(path)
        descriptors.append(SubtopicDescriptor(slug=slug, title=title, path=path, paper_count=paper_count))
    return descriptors


def _read_subtopics_from_paper_note(note_path: Path) -> list[str]:
    """Parse the `subtopics:` frontmatter field."""
    text = note_path.read_text(encoding="utf-8")
    pre_sections = _extract_sections_excluding_papers(text)
    frontmatter = _extract_frontmatter_block(text)
    if frontmatter is None:
        return []
    inline_match = re.search(r"^subtopics:[ \t]*(.*?)[ \t]*$", frontmatter, re.MULTILINE)
    if inline_match:
        value = inline_match.group(1).strip()
    else:
        value = ""
    if value:
        if value.startswith("[") and value.endswith("]"):
            inner = value[1:-1].strip()
            return [part.strip().strip("\"'") for part in inner.split(",") if part.strip()]
        if value not in {"|", ">"}:
            return [part.strip() for part in value.split(",") if part.strip()]
    block_match = re.search(
        r"^subtopics:\s*$\n(?P<body>(?:^[ \t]+-\s+.+\n?)*)",
        frontmatter,
        re.MULTILINE,
    )
    if not block_match:
        return []
    return [
        line.strip()[2:].strip().strip("\"'")
        for line in block_match.group("body").splitlines()
        if line.strip().startswith("- ")
    ]


def _write_papers_section(
    note_path: Path,
    papers: list["PaperDigestEntry"],
    paper_meta_by_slug: dict[str, dict[str, str]] | None = None,
) -> None:
    """Replace the `## Papers` section content in a sub-topic note."""
    paper_meta_by_slug = paper_meta_by_slug or {}
    text = note_path.read_text(encoding="utf-8")
    pre_sections = _extract_sections_excluding_papers(text)
    body = _render_papers_markdown(papers, paper_meta_by_slug)
    replacement = (
        "## Papers\n\n"
        f"{body}\n\n"
    )
    start_match = re.search(r"^##\s+Papers\s*$", text, re.MULTILINE)
    if not start_match:
        raise ValueError(f"sub-topic note is missing a '## Papers' section: {note_path}")
    next_match = re.search(r"^##\s+", text[start_match.end():], re.MULTILINE)
    end = start_match.end() + next_match.start() if next_match else len(text)
    prefix = text[:start_match.start()]
    suffix = text[end:]
    new_text = prefix + replacement + suffix.lstrip("\n")
    post_sections = _extract_sections_excluding_papers(new_text)
    for heading, content in pre_sections.items():
        if heading not in post_sections:
            raise ValueError(
                f"_write_papers_section would delete section {heading!r} in {note_path.name} - refusing to write."
            )
        if post_sections[heading] != content:
            raise ValueError(
                f"_write_papers_section would modify section {heading!r} in {note_path.name} - refusing to write."
            )
    note_path.write_text(new_text, encoding="utf-8")


def _parse_note(path: Path) -> tuple[dict[str, str | list[str]], str]:
    """Return note frontmatter plus abstract section text."""
    text = path.read_text(encoding="utf-8")
    meta = _parse_frontmatter(text)
    body = _strip_frontmatter(text)
    meta["__body_text__"] = body
    match = re.search(r"^##\s+Abstract\s*\n(.*?)(?=^##\s|\Z)", body, re.MULTILINE | re.DOTALL)
    abstract = match.group(1).strip() if match else ""
    return meta, abstract


def _extract_sections_excluding_papers(text: str) -> dict[str, str]:
    sections: dict[str, str] = {}
    matches = list(re.finditer(r"^##\s+(.+?)\s*$", text, re.MULTILINE))
    for index, match in enumerate(matches):
        heading = match.group(1).strip()
        if heading == "Papers":
            continue
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        sections[heading] = text[start:end].strip()
    return sections


def _split_authors(authors_str: str) -> list[str]:
    if not authors_str:
        return []
    return [author.strip() for author in authors_str.replace(";", ",").split(",") if author.strip()]


def _parse_frontmatter(text: str) -> dict[str, str | list[str]]:
    frontmatter = _extract_frontmatter_block(text)
    meta: dict[str, str | list[str]] = {}
    if frontmatter is None:
        return meta
    lines = frontmatter.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if ":" not in line:
            i += 1
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip()
        if value.startswith("[") and value.endswith("]"):
            meta[key] = [part.strip().strip("\"'") for part in value[1:-1].split(",") if part.strip()]
            i += 1
            continue
        if value == "":
            children: list[str] = []
            j = i + 1
            while j < len(lines) and re.match(r"^[ \t]+-\s+", lines[j]):
                children.append(re.sub(r"^[ \t]+-\s+", "", lines[j]).strip().strip("\"'"))
                j += 1
            meta[key] = children if children else ""
            i = j
            continue
        meta[key] = value.strip('"')
        i += 1
    return meta


def _extract_frontmatter_block(text: str) -> str | None:
    if not text.startswith("---\n"):
        return None
    end = text.find("\n---\n", 4)
    if end == -1:
        return None
    return text[4:end]


def _strip_frontmatter(text: str) -> str:
    if not text.startswith("---\n"):
        return text
    end = text.find("\n---\n", 4)
    if end == -1:
        return text
    return text[end + 5:]


def _normalize_subtopic_values(values: list[str] | str | None) -> list[str]:
    if values is None:
        return []
    if isinstance(values, str):
        raw = [part.strip() for part in values.split(",")]
    else:
        raw = [str(part).strip() for part in values]
    out: list[str] = []
    for item in raw:
        if item and item not in out:
            out.append(item)
    return out


def _upsert_frontmatter_subtopics(text: str, values: list[str]) -> str:
    block = "subtopics:\n" + "".join(f"  - {item}\n" for item in values)
    if text.startswith("---\n"):
        end = text.find("\n---\n", 4)
        if end != -1:
            frontmatter = text[4:end]
            body = text[end + 5:]
            pattern = re.compile(
                r"^subtopics:\s*(?:\[[^\]]*\]|[^\n]*)\n(?:^[ \t]+-\s+.*\n?)*",
                re.MULTILINE,
            )
            if pattern.search(frontmatter):
                new_frontmatter = pattern.sub(block, frontmatter, count=1)
            else:
                new_frontmatter = frontmatter
                if new_frontmatter and not new_frontmatter.endswith("\n"):
                    new_frontmatter += "\n"
                new_frontmatter += block
            return f"---\n{new_frontmatter}---\n{body}"
    return f"---\n{block}---\n\n{text}"


def _existing_subtopic_numbers(topics_root: Path) -> dict[str, int]:
    mapping: dict[str, int] = {}
    for path in sorted(topics_root.glob("[0-9][0-9]_*.md")):
        match = re.match(r"(?P<num>\d{2})_(?P<slug>.+)\.md$", path.name)
        if not match:
            continue
        mapping[match.group("slug")] = int(match.group("num"))
    return mapping


def _slug_from_topic_filename(path: Path) -> str:
    match = re.match(r"\d{2}_(.+)\.md$", path.name)
    return match.group(1) if match else path.stem


def _existing_subtopic_title(path: Path) -> str:
    if not path.exists():
        return ""
    meta = _parse_frontmatter(path.read_text(encoding="utf-8"))
    return meta.get("title", "")


def _existing_subtopic_paper_count(path: Path) -> int:
    if not path.exists():
        return 0
    meta = _parse_frontmatter(path.read_text(encoding="utf-8"))
    value = meta.get("papers", "0")
    return int(value) if value.isdigit() else 0


def _humanize_slug(slug: str) -> str:
    return " ".join(part.capitalize() for part in slug.split("-") if part)


def _render_papers_markdown(
    papers: list[PaperDigestEntry],
    paper_meta_by_slug: dict[str, dict[str, str | list[str]]],
) -> str:
    lines: list[str] = []
    for paper in papers:
        meta = paper_meta_by_slug.get(paper.slug, {})
        summary = _paper_one_line_take(meta, paper.abstract)
        badge = _render_label_badge(meta)
        link = f"[[{paper.slug}|{_paper_link_label(paper)}]]"
        if badge:
            lines.append(f"- {link} {badge} — {summary}")
        else:
            lines.append(f"- {link} — {summary}")
    return "\n".join(lines) if lines else "- (no papers assigned)"


def _render_label_badge(meta: dict[str, str | list[str]]) -> str:
    labels_raw = meta.get("labels", "")
    if isinstance(labels_raw, list):
        labels = [str(item) for item in labels_raw if str(item).strip()]
    elif isinstance(labels_raw, str) and labels_raw.startswith("[") and labels_raw.endswith("]"):
        labels = [item.strip().strip("\"'") for item in labels_raw[1:-1].split(",") if item.strip()]
    else:
        labels = []
    if not labels:
        return ""
    return "`[" + ", ".join(labels) + "]`"


def _paper_link_label(paper: PaperDigestEntry) -> str:
    short_title = paper.title[:50]
    authors = paper.authors or [""]
    last_name = authors[0].split()[-1] if authors[0].strip() else "Unknown"
    year = str(paper.year) if paper.year is not None else "????"
    return f"{short_title} ({last_name} {year})"


def _paper_one_line_take(meta: dict[str, str], abstract: str) -> str:
    summary = meta.get("summary", "").strip().strip('"')
    if summary:
        return summary
    body_text = meta.get("__body_text__", "")
    summary_section = _extract_section(body_text, "Summary")
    if summary_section:
        return _single_line(summary_section, 120)
    abstract_section = _extract_section(body_text, "Abstract")
    if abstract_section:
        return _single_line(abstract_section, 120)
    if abstract:
        return _single_line(abstract, 120)
    return "(no summary)"


def _extract_section(body: str, heading: str) -> str:
    if not body:
        return ""
    match = re.search(
        rf"^##\s+{re.escape(heading)}\s*\n(.*?)(?=^##\s|\Z)",
        body,
        re.MULTILINE | re.DOTALL,
    )
    return match.group(1).strip() if match else ""


def _single_line(text: str, limit: int) -> str:
    normalized = re.sub(r"\s+", " ", text).strip()
    if len(normalized) <= limit:
        return normalized
    return normalized[:limit].rstrip() + "..."


def _update_subtopic_frontmatter(
    text: str,
    *,
    cluster_slug: str,
    subtopic_slug: str,
    subtopic_title: str,
    paper_count: int,
) -> str:
    replacements = {
        "cluster": cluster_slug,
        "subtopic": subtopic_slug,
        "title": subtopic_title,
        "papers": str(paper_count),
    }
    if not text.startswith("---\n"):
        return text
    end = text.find("\n---\n", 4)
    if end == -1:
        return text
    frontmatter = text[4:end]
    for key, value in replacements.items():
        frontmatter, changed = re.subn(
            rf"^{re.escape(key)}:\s*.*$",
            f"{key}: {value}",
            frontmatter,
            count=1,
            flags=re.MULTILINE,
        )
        if not changed:
            if frontmatter and not frontmatter.endswith("\n"):
                frontmatter += "\n"
            frontmatter += f"{key}: {value}\n"
    return f"---\n{frontmatter}\n---\n{text[end + 5:]}"
