from typing import Any, Dict, List, Optional

from .connection import Connection


class IdpClient:
    def __init__(self, connection: Connection):
        self._connection = connection

    def queue_batch(
        self,
        namespace_id: str,
        source_paths: List[str],
        name: Optional[str] = None,
        extraction_schema: Optional[Dict[str, Any]] = None,
        extract_diagrams: bool = False,
        extract_images: bool = False,
        response_detail: str = "full",
    ) -> Dict[str, Any]:
        response = self._connection.request(
            "POST",
            f"/namespaces/{namespace_id}/idp/document-runs/queue/batch",
            json={
                "source_paths": source_paths,
                "name": name,
                "extraction_schema": extraction_schema,
                "extract_diagrams": extract_diagrams,
                "extract_images": extract_images,
                "response_detail": response_detail,
            },
        )
        return response.json()

    def get_stored_response(self, namespace_id: str, document_id: str) -> Dict[str, Any]:
        response = self._connection.request(
            "GET",
            f"/namespaces/{namespace_id}/idp/document-runs/{document_id}/response",
        )
        return response.json()

    def annotate_stored(
        self,
        namespace_id: str,
        document_id: str,
        detail: Optional[str] = None,
        show_labels: bool = True,
    ) -> Dict[str, Any]:
        response = self._connection.request(
            "POST",
            f"/namespaces/{namespace_id}/idp/document-runs/{document_id}/annotate",
            json={"detail": detail, "show_labels": show_labels},
        )
        return response.json()

    def retry_run(self, namespace_id: str, document_id: str) -> Dict[str, Any]:
        response = self._connection.request(
            "POST",
            f"/namespaces/{namespace_id}/idp/document-runs/{document_id}/retry",
        )
        return response.json()

    def delete_stored_response(self, namespace_id: str, document_id: str) -> None:
        self._connection.request(
            "DELETE",
            f"/namespaces/{namespace_id}/idp/document-runs/{document_id}/response",
        )
