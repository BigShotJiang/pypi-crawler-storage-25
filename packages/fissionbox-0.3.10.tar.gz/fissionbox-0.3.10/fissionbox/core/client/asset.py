from pathlib import Path

import requests

from .connection import Connection


class AssetClient:
    def __init__(self, connection: Connection):
        self._connection = connection

    def get_download_url(self, namespace_id: str, path: str) -> str:
        storage_key = self._storage_key(namespace_id, path)
        response = self._connection.request(
            "GET",
            f"/namespaces/{namespace_id}/assets/downloadurl/{storage_key}",
        )
        return response.json()["url"]

    def download(self, namespace_id: str, path: str, output_path: str) -> str:
        url = self.get_download_url(namespace_id, path)
        r = requests.get(url)
        r.raise_for_status()
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(r.content)
        return str(out)

    @staticmethod
    def _storage_key(namespace_id: str, path: str) -> str:
        if path.startswith("namespaces/"):
            return path
        return f"namespaces/{namespace_id}/{path.lstrip('/')}"
