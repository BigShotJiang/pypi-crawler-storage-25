import os

from fissionbox.cli.utils.config_store import CliConfigStore, CONFIG_STORE
from fissionbox.core.client.connection import Connection
from fissionbox.core.client.client import Client
from fissionbox.core.client.document import DocumentClient
from fissionbox.core.client.account import AccountClient
from fissionbox.core.client.idp import IdpClient
from fissionbox.core.client.asset import AssetClient


DEFAULT_FISSIONBOX_HOST = "https://api.beta.fissionbox.ai"
DEFAULT_FISSIONBOX_API_KEY = ""
DEFAULT_PLATFORM_HOST = "https://api.beta.platform.fissionbox.ai"
DEFAULT_AUTH_HOST = "https://www.beta.platform.fissionbox.ai"
NAMESPACE_ENV_NAME = "FISSIONBOX_NAMESPACE_ID"
FISSIONBOX_NAMESPACE_HEADER = "X-FissionBox-Namespace-Id"


class CliRuntime:
    def __init__(self, config_store: CliConfigStore):
        self.config_store = config_store

    def get_setting(self, env_name: str, *, config_key: str | None = None, default: str = "") -> str:
        env_value = os.getenv(env_name)
        if env_value is not None:
            return env_value
        if config_key is not None:
            config_value = self.config_store.get(config_key)
            if config_value:
                return str(config_value)
        return default

    def get_fissionbox_host(self) -> str:
        return self.get_setting("FISSIONBOX_HOST", default=DEFAULT_FISSIONBOX_HOST)

    def get_fissionbox_api_key(self) -> str:
        return os.getenv("FISSIONBOX_API_KEY", DEFAULT_FISSIONBOX_API_KEY)

    def get_platform_host(self) -> str:
        return self.get_setting("FISSIONBOX_PLATFORM_HOST", default=DEFAULT_PLATFORM_HOST)

    def get_auth_host(self) -> str:
        return self.get_setting("FISSIONBOX_AUTH_HOST", default=DEFAULT_AUTH_HOST)

    def get_platform_api_key(self) -> str:
        return self.get_setting("FISSIONBOX_PLATFORM_API_KEY", config_key="platform_api_key")

    def get_platform_user_token(self) -> str:
        return self.get_setting("FISSIONBOX_PLATFORM_USER_TOKEN", config_key="platform_user_token")

    def get_default_namespace_id(self) -> str:
        return self.get_setting(NAMESPACE_ENV_NAME, config_key="default_namespace_id")

    def resolve_namespace_id(self, namespace_id: str | None) -> str:
        resolved_namespace_id = namespace_id or self.get_default_namespace_id()
        if resolved_namespace_id:
            return resolved_namespace_id
        raise ValueError(
            "Workspace namespace ID is required. Pass --namespace-id or set a default with `fissionbox namespace use --namespace-id=<id>`.",
        )

    def get_platform_connection(self) -> Connection:
        platform_api_key = self.get_platform_api_key()
        platform_user_token = self.get_platform_user_token()
        auth_token = platform_api_key or platform_user_token
        auth_header_name = "x-api-key" if platform_api_key else "Authorization"
        auth_scheme = "" if platform_api_key else "Bearer"
        return Connection(
            host=self.get_platform_host(),
            auth_token=auth_token,
            auth_header_name=auth_header_name,
            auth_scheme=auth_scheme,
        )

    def get_direct_fissionbox_connection(self) -> Connection:
        return Connection(
            host=self.get_fissionbox_host(),
            auth_token=self.get_fissionbox_api_key(),
        )

    def get_platform_user_connection(self) -> Connection:
        return Connection(
            host=self.get_platform_host(),
            auth_token=self.get_platform_user_token(),
            auth_header_name="Authorization",
            auth_scheme="Bearer",
        )

    def get_namespace_scoped_fissionbox_connection(self, namespace_id: str) -> Connection:
        if self.get_platform_user_token() or self.get_platform_api_key():
            session_response = self.get_platform_connection().request(
                "POST",
                "/sessions",
                json={
                    "service": "fissionbox",
                    "namespaceId": namespace_id,
                },
            )
            session_token = session_response.json()["token"]
            return Connection(
                host=self.get_fissionbox_host(),
                auth_token=session_token,
                auth_header_name="Authorization",
                auth_scheme="Bearer",
                default_headers={FISSIONBOX_NAMESPACE_HEADER: namespace_id},
            )

        return self.get_direct_fissionbox_connection()

    def get_namespace_client(self, namespace_id: str) -> Client:
        return Client(connection=self.get_namespace_scoped_fissionbox_connection(namespace_id))

    def get_document_client(self, namespace_id: str) -> DocumentClient:
        return DocumentClient(self.get_namespace_scoped_fissionbox_connection(namespace_id))

    def get_account_client(self) -> AccountClient:
        return AccountClient(self.get_platform_user_connection())

    def get_idp_client(self) -> IdpClient:
        return IdpClient(self.get_platform_connection())

    def get_idp_client_via_fissionbox(self, namespace_id: str) -> IdpClient:
        return IdpClient(self.get_namespace_scoped_fissionbox_connection(namespace_id))

    def get_asset_client(self) -> AssetClient:
        return AssetClient(self.get_platform_connection())


RUNTIME = CliRuntime(CONFIG_STORE)


def get_fissionbox_host() -> str:
    return RUNTIME.get_fissionbox_host()


def get_fissionbox_api_key() -> str:
    return RUNTIME.get_fissionbox_api_key()


def get_platform_host() -> str:
    return RUNTIME.get_platform_host()


def get_auth_host() -> str:
    return RUNTIME.get_auth_host()


def get_platform_api_key() -> str:
    return RUNTIME.get_platform_api_key()


def get_platform_user_token() -> str:
    return RUNTIME.get_platform_user_token()


def get_default_namespace_id() -> str:
    return RUNTIME.get_default_namespace_id()


def resolve_namespace_id(namespace_id: str | None) -> str:
    return RUNTIME.resolve_namespace_id(namespace_id)


def get_direct_fissionbox_connection() -> Connection:
    return RUNTIME.get_direct_fissionbox_connection()


def get_platform_connection() -> Connection:
    return RUNTIME.get_platform_connection()


def get_platform_user_connection() -> Connection:
    return RUNTIME.get_platform_user_connection()


def get_namespace_scoped_fissionbox_connection(namespace_id: str) -> Connection:
    return RUNTIME.get_namespace_scoped_fissionbox_connection(namespace_id)


def get_namespace_client(namespace_id: str) -> Client:
    return RUNTIME.get_namespace_client(namespace_id)


def get_document_client(namespace_id: str) -> DocumentClient:
    return RUNTIME.get_document_client(namespace_id)


def get_account_client() -> AccountClient:
    return RUNTIME.get_account_client()


def get_idp_client() -> IdpClient:
    return RUNTIME.get_idp_client()


def get_idp_client_via_fissionbox(namespace_id: str) -> IdpClient:
    return RUNTIME.get_idp_client_via_fissionbox(namespace_id)


def get_asset_client() -> AssetClient:
    return RUNTIME.get_asset_client()
