import argparse
import importlib.util
import io
import json
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import Mock, patch


MODULE_PATH = (
    Path(__file__).resolve().parents[1] / "fissionbox" / "cli" / "document" / "module.py"
)


def load_document_cli_module():
    env_module = types.ModuleType("fissionbox.cli.utils.env")
    env_module.get_document_client = lambda namespace_id: None
    env_module.resolve_namespace_id = lambda namespace_id: namespace_id
    env_module.get_idp_client = lambda: None
    env_module.get_asset_client = lambda: None

    cli_utils_package = types.ModuleType("fissionbox.cli.utils")
    cli_package = types.ModuleType("fissionbox.cli")
    fissionbox_package = types.ModuleType("fissionbox")

    # Capture console for test assertions
    captured_output = io.StringIO()

    class CapturingConsole:
        def __init__(self, *a, **k):
            pass
        def print(self, *args, **kwargs):
            captured_output.write(" ".join(str(a) for a in args) + "\n")
        def __enter__(self):
            return self
        def __exit__(self, *a):
            pass

    class MockProgress:
        def __init__(self, *a, **k):
            pass
        def add_task(self, *a, **k):
            return 0
        def update(self, *a, **k):
            pass
        def advance(self, *a, **k):
            pass
        def __enter__(self):
            return self
        def __exit__(self, *a):
            pass

    class MockLive:
        def __init__(self, *a, **k):
            pass
        def update(self, *a, **k):
            pass
        def __enter__(self):
            return self
        def __exit__(self, *a):
            pass

    # Mock rich modules
    rich_module = types.ModuleType("rich")
    rich_console_module = types.ModuleType("rich.console")
    rich_console_module.Console = CapturingConsole
    rich_console_module.Group = Mock
    rich_live_module = types.ModuleType("rich.live")
    rich_live_module.Live = MockLive
    rich_panel_module = types.ModuleType("rich.panel")
    rich_panel_module.Panel = Mock
    rich_progress_module = types.ModuleType("rich.progress")
    rich_progress_module.BarColumn = Mock
    rich_progress_module.MofNCompleteColumn = Mock
    rich_progress_module.Progress = MockProgress
    rich_progress_module.SpinnerColumn = Mock
    rich_progress_module.TaskProgressColumn = Mock
    rich_progress_module.TextColumn = Mock
    rich_progress_module.TimeElapsedColumn = Mock
    rich_rule_module = types.ModuleType("rich.rule")
    rich_rule_module.Rule = Mock
    rich_table_module = types.ModuleType("rich.table")
    rich_table_module.Table = Mock
    rich_text_module = types.ModuleType("rich.text")
    rich_text_module.Text = Mock
    rich_tree_module = types.ModuleType("rich.tree")
    rich_tree_module.Tree = Mock
    rich_box_module = types.ModuleType("rich.box")

    previous_modules = {
        name: sys.modules.get(name)
        for name in [
            "fissionbox",
            "fissionbox.cli",
            "fissionbox.cli.utils",
            "fissionbox.cli.utils.env",
            "rich",
            "rich.console",
            "rich.live",
            "rich.panel",
            "rich.progress",
            "rich.rule",
            "rich.table",
            "rich.text",
            "rich.tree",
            "rich.box",
            "test_document_cli_module_runtime",
        ]
    }

    sys.modules["fissionbox"] = fissionbox_package
    sys.modules["fissionbox.cli"] = cli_package
    sys.modules["fissionbox.cli.utils"] = cli_utils_package
    sys.modules["fissionbox.cli.utils.env"] = env_module
    sys.modules["rich"] = rich_module
    sys.modules["rich.console"] = rich_console_module
    sys.modules["rich.live"] = rich_live_module
    sys.modules["rich.panel"] = rich_panel_module
    sys.modules["rich.progress"] = rich_progress_module
    sys.modules["rich.rule"] = rich_rule_module
    sys.modules["rich.table"] = rich_table_module
    sys.modules["rich.text"] = rich_text_module
    sys.modules["rich.tree"] = rich_tree_module
    sys.modules["rich.box"] = rich_box_module

    try:
        spec = importlib.util.spec_from_file_location(
            "test_document_cli_module_runtime",
            MODULE_PATH,
        )
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)
        return module, captured_output
    finally:
        for name, previous in previous_modules.items():
            if previous is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = previous


class DocumentCliModuleTest(unittest.TestCase):
    def test_process_forwards_extract_images(self):
        module, captured_output = load_document_cli_module()
        client = Mock()
        client.process.return_value = {"status": "queued"}
        args = argparse.Namespace(
            command="process",
            namespace_id="ns-123",
            source_path="documents/source/invoice.pdf",
            name=None,
            schema_json=None,
            schema_file=None,
            extract_diagrams=False,
            extract_images=True,
            response_detail="full",
        )

        with patch.object(module, "resolve_namespace_id", return_value="ns-123"), patch.object(
            module, "get_document_client", return_value=client
        ), patch("sys.stdout", new_callable=io.StringIO) as stdout:
            module.main(args)

        client.process.assert_called_once_with(
            namespace_id="ns-123",
            source_path="documents/source/invoice.pdf",
            name=None,
            extraction_schema=None,
            extract_diagrams=False,
            extract_images=True,
            response_detail="full",
        )
        self.assertEqual({"status": "queued"}, json.loads(stdout.getvalue()))

    def test_response_command_prints_json(self):
        module, captured_output = load_document_cli_module()
        idp_client = Mock()
        idp_client.get_stored_response.return_value = {
            "markdown": "# Test",
            "chunks": [{"chunk_id": "c1", "text": "Hello"}],
        }

        args = argparse.Namespace(
            command="response",
            namespace_id="ns-123",
            id="art-123",
            response_format="json",
            output=None,
        )

        with patch.object(module, "resolve_namespace_id", return_value="ns-123"), patch.object(
            module, "get_idp_client", return_value=idp_client
        ), patch("sys.stdout", new_callable=io.StringIO) as stdout:
            module.main(args)

        idp_client.get_stored_response.assert_called_once_with("ns-123", "art-123")
        output = json.loads(stdout.getvalue())
        self.assertEqual(output["markdown"], "# Test")
        self.assertEqual(len(output["chunks"]), 1)

    def test_response_command_prints_summary(self):
        module, captured_output = load_document_cli_module()
        idp_client = Mock()
        idp_client.get_stored_response.return_value = {
            "markdown": "# Test document",
            "chunks": [{"chunk_id": "c1", "text": "Hello"}],
            "images": [{"image_id": "img1"}],
            "diagrams": {"d1": "graph TD;"},
            "extracted": {"field1": "value1"},
        }

        args = argparse.Namespace(
            command="response",
            namespace_id="ns-123",
            id="art-123",
            response_format="summary",
            output=None,
        )

        with patch.object(module, "resolve_namespace_id", return_value="ns-123"), patch.object(
            module, "get_idp_client", return_value=idp_client
        ):
            module.main(args)

        output = captured_output.getvalue()
        self.assertIn("Chunks:", output)
        self.assertIn("Images:", output)
        self.assertIn("Diagrams:", output)
        self.assertIn("Extracted fields:", output)

    def test_annotate_command_with_if_missing_skips_when_exists(self):
        module, captured_output = load_document_cli_module()
        doc_client = Mock()
        doc_client.get.return_value = {
            "metadata": {"annotatedPdfPath": "documents/runs/art-123/annotated.pdf"}
        }
        idp_client = Mock()

        args = argparse.Namespace(
            command="annotate",
            namespace_id="ns-123",
            id="art-123",
            detail=None,
            no_labels=False,
            download=None,
            open=False,
            if_missing=True,
        )

        with patch.object(module, "resolve_namespace_id", return_value="ns-123"), patch.object(
            module, "get_document_client", return_value=doc_client
        ), patch.object(
            module, "get_idp_client", return_value=idp_client
        ):
            module.main(args)

        idp_client.annotate_stored.assert_not_called()
        output = captured_output.getvalue()
        self.assertIn("already exists", output)


if __name__ == "__main__":
    unittest.main()
