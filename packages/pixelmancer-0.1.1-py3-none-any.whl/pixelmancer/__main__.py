def main() -> int:
    print(
        "Pixelmancer is not publicly released yet. "
        "This PyPI package name is reserved by Remgrandt Games LLC."
    )
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
