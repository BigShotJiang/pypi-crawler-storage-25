"""Placeholder package for Pixelmancer."""

__version__ = "0.1.1"


class PixelmancerNotReleasedError(RuntimeError):
    """Raised when trying to use the placeholder package."""


def unavailable() -> None:
    """Explain that the public package is not released yet."""
    raise PixelmancerNotReleasedError(
        "Pixelmancer is not publicly released yet. "
        "This PyPI package name is reserved by Remgrandt Games LLC."
    )
