"""Token management service (Auth & OTP) — async and sync."""

from __future__ import annotations

import logging
import time

from ssi_sdk.config import Config
from ssi_sdk.constant import EP_ACCESS_TOKEN, EP_REFRESH_TOKEN, EP_REQUEST_OTP
from ssi_sdk.exceptions import AuthenticationError, APIError, SSIError
from ssi_sdk.models import Token, TokenRequest, OTPRequest, RefreshTokenRequest
from ssi_sdk.transport.rest_client import AsyncRestClient, RestClient

logger = logging.getLogger("ssi_sdk.services.token_manager")


class AsyncTokenManager:
    """Async token manager — authentication tokens and OTP verification.

    Handles:
    - Initial authentication (consumer credentials → access token)
    - OTP verification for trading operations
    - Token refresh when expired
    """

    def __init__(self, rest_client: AsyncRestClient, config: Config):
        self._rest = rest_client
        self._config = config
        self._token: Token | None = None

    @property
    def token(self) -> Token | None:
        """Current token object, or None if not authenticated."""
        return self._token

    @property
    def access_token(self) -> str | None:
        """Current access token, or None if not authenticated."""
        if self._token is None:
            return None
        return self._token.access_token

    @property
    def is_token_expired(self) -> bool:
        """Check if the current token has expired."""
        if self._token is None:
            return True
        if self._token.expires_at <= 0:
            return False
        return time.time() >= self._token.expires_at

    @property
    def has_refresh_token(self) -> bool:
        """Return True if a refresh token is available."""
        return bool(self._token and self._token.refresh_token)

    async def refresh(self) -> Token:
        """Obtain a new access token using the current refresh token."""
        if not self._config.api_key or not self._config.api_secret:
            raise AuthenticationError(
                "api_key and api_secret are required for token refresh"
            )

        if not self.has_refresh_token:
            raise AuthenticationError("No refresh token available — authenticate first")

        refresh_token = self._token.refresh_token  # type: ignore[union-attr]

        try:
            data = await self._rest.post(
                EP_REFRESH_TOKEN,
                json_body=RefreshTokenRequest(refresh_token=refresh_token).to_dict(),
            )
        except SSIError:
            logger.error("Failed to refresh token for endpoint %s", EP_REFRESH_TOKEN)
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error refreshing token for endpoint %s: %s",
                EP_REFRESH_TOKEN,
                exc,
            )
            raise APIError(f"Unexpected error refreshing token: {exc}") from exc

        if not isinstance(data, dict):
            logger.error(
                "Unexpected refresh response type for endpoint %s: %s",
                EP_REFRESH_TOKEN,
                type(data).__name__,
            )
            raise APIError("Unexpected response format while refreshing token")

        payload = data.get("data", data)
        if not isinstance(payload, dict):
            logger.error(
                "Unexpected refresh payload type for endpoint %s: %s",
                EP_REFRESH_TOKEN,
                type(payload).__name__,
            )
            raise APIError("Unexpected token payload format while refreshing token")

        self._token = Token.from_dict(payload)
        if not self._token.access_token:
            raise APIError("Refreshed token payload is missing access token")
        self._rest.set_auth_header(self._token.access_token)

        logger.info("Token refreshed successfully")
        return self._token

    async def authenticate(self, otp: str | None = None) -> Token:
        """Authenticate using consumer credentials + OTP and obtain an access token."""
        if not self._config.api_key or not self._config.api_secret:
            raise AuthenticationError(
                "api_key and api_secret are required for authentication"
            )
        try:
            data = await self._rest.post(
                EP_ACCESS_TOKEN,
                json_body=TokenRequest(
                    api_key=self._config.api_key,
                    api_secret=self._config.api_secret,
                    otp=otp,
                ).to_dict(),
            )
        except SSIError:
            logger.error("Failed to authenticate for endpoint %s", EP_ACCESS_TOKEN)
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error authenticating for endpoint %s: %s",
                EP_ACCESS_TOKEN,
                exc,
            )
            raise APIError(f"Unexpected error authenticating: {exc}") from exc

        if not isinstance(data, dict):
            logger.error(
                "Unexpected auth response type for endpoint %s: %s",
                EP_ACCESS_TOKEN,
                type(data).__name__,
            )
            raise APIError("Unexpected response format while authenticating")

        payload = data.get("data", data)
        if not isinstance(payload, dict):
            logger.error(
                "Unexpected auth payload type for endpoint %s: %s",
                EP_ACCESS_TOKEN,
                type(payload).__name__,
            )
            raise APIError("Unexpected token payload format while authenticating")

        self._token = Token.from_dict(payload)
        if not self._token.access_token:
            raise APIError("Authentication payload is missing access token")

        self._rest.set_auth_header(self._token.access_token)

        logger.info("Authentication successful")
        logger.debug(
            "Token details: token=%s, expires_at=%s, refresh_token_expires_at=%s",
            self._token.access_token,
            self._token.expires_at,
            self._token.refresh_token_expires_at,
        )
        return self._token

    async def set_token(self, token: Token) -> None:
        """Manually set the access token (for advanced use cases)."""
        self._token = token
        self._rest.set_auth_header(token.access_token)
        logger.info("Access token set manually")

    async def request_otp(self) -> dict:
        """Request an OTP to be sent to the registered channel."""
        if not self._config.api_key or not self._config.api_secret:
            raise AuthenticationError(
                "api_key and api_secret are required for OTP request"
            )

        try:
            data = await self._rest.post(
                EP_REQUEST_OTP,
                json_body=OTPRequest(
                    api_key=self._config.api_key,
                    api_secret=self._config.api_secret,
                ).to_dict(),
            )
        except SSIError:
            logger.error("Failed to request OTP for endpoint %s", EP_REQUEST_OTP)
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error requesting OTP for endpoint %s: %s",
                EP_REQUEST_OTP,
                exc,
            )
            raise APIError(f"Unexpected error requesting OTP: {exc}") from exc

        if not isinstance(data, dict):
            logger.error(
                "Unexpected OTP response type for endpoint %s: %s",
                EP_REQUEST_OTP,
                type(data).__name__,
            )
            raise APIError("Unexpected response format while requesting OTP")

        return data

    async def ensure_authenticated(self, otp: str | None = None) -> str:
        """Ensure a valid token is available, refreshing if needed.

        If the token is expired and a refresh token is available, the token is
        refreshed automatically without requiring an OTP.  A fresh OTP is only
        required when no refresh token exists or when this is the first login.
        """
        if self._token is None or self.is_token_expired:
            if self.has_refresh_token:
                await self.refresh()
            elif otp:
                await self.authenticate(otp)
            else:
                raise AuthenticationError(
                    "OTP is required to authenticate — no refresh token available"
                )
        return self._token.access_token  # type: ignore[union-attr]


class TokenManager:
    """Synchronous token manager — authentication tokens and OTP verification.

    Handles:
    - Initial authentication (consumer credentials → access token)
    - OTP verification for trading operations
    - Token refresh when expired
    """

    def __init__(self, rest_client: RestClient, config: Config):
        self._rest = rest_client
        self._config = config
        self._token: Token | None = None

    @property
    def token(self) -> Token | None:
        """Current token object, or None if not authenticated."""
        return self._token

    @property
    def access_token(self) -> str | None:
        """Current access token, or None if not authenticated."""
        if self._token is None:
            return None
        return self._token.access_token

    @property
    def is_token_expired(self) -> bool:
        """Check if the current token has expired."""
        if self._token is None:
            return True
        if self._token.expires_at <= 0:
            return False
        return time.time() >= self._token.expires_at

    @property
    def has_refresh_token(self) -> bool:
        """Return True if a refresh token is available."""
        return bool(self._token and self._token.refresh_token)

    def refresh(self) -> Token:
        """Obtain a new access token using the current refresh token."""
        if not self._config.api_key or not self._config.api_secret:
            raise AuthenticationError(
                "api_key and api_secret are required for token refresh"
            )

        if not self.has_refresh_token:
            raise AuthenticationError("No refresh token available — authenticate first")

        refresh_token = self._token.refresh_token  # type: ignore[union-attr]

        try:
            data = self._rest.post(
                EP_REFRESH_TOKEN,
                json_body=RefreshTokenRequest(refresh_token=refresh_token).to_dict()
            )
            logger.debug("Refresh token response data: %s", data)
        except SSIError:
            logger.error("Failed to refresh token for endpoint %s", EP_REFRESH_TOKEN)
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error refreshing token for endpoint %s: %s",
                EP_REFRESH_TOKEN, exc
            )
            raise APIError(f"Unexpected error refreshing token: {exc}") from exc

        if not isinstance(data, dict):
            logger.error(
                "Unexpected refresh response type for endpoint %s: %s",
                EP_REFRESH_TOKEN,
                type(data).__name__,
            )
            raise APIError("Unexpected response format while refreshing token")

        payload = data.get("data", data)
        if not isinstance(payload, dict):
            logger.error(
                "Unexpected refresh payload type for endpoint %s: %s",
                EP_REFRESH_TOKEN,
                type(payload).__name__,
            )
            raise APIError("Unexpected token payload format while refreshing token")

        self._token = Token.from_dict(payload)
        if not self._token.access_token:
            raise APIError("Refreshed token payload is missing access token")

        self._rest.set_auth_header(self._token.access_token)

        logger.info("Token refreshed successfully")
        return self._token

    def authenticate(self, otp: str | None = None) -> Token:
        """Authenticate using consumer credentials + OTP and obtain an access token."""
        if not self._config.api_key or not self._config.api_secret:
            raise AuthenticationError(
                "api_key and api_secret are required for authentication"
            )
        try:
            data = self._rest.post(
                EP_ACCESS_TOKEN,
                json_body=TokenRequest(
                    api_key=self._config.api_key,
                    api_secret=self._config.api_secret,
                    otp=otp,
                ).to_dict(),
            )
        except SSIError:
            logger.error("Failed to authenticate for endpoint %s", EP_ACCESS_TOKEN)
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error authenticating for endpoint %s: %s",
                EP_ACCESS_TOKEN, exc
            )
            raise APIError(f"Unexpected error authenticating: {exc}") from exc

        if not isinstance(data, dict):
            logger.error(
                "Unexpected auth response type for endpoint %s: %s",
                EP_ACCESS_TOKEN,
                type(data).__name__,
            )
            raise APIError("Unexpected response format while authenticating")

        payload = data.get("data", data)
        if not isinstance(payload, dict):
            logger.error(
                "Unexpected auth payload type for endpoint %s: %s",
                EP_ACCESS_TOKEN,
                type(payload).__name__,
            )
            raise APIError("Unexpected token payload format while authenticating")

        self._token = Token.from_dict(payload)
        if not self._token.access_token:
            raise APIError("Authentication payload is missing access token")

        self._rest.set_auth_header(self._token.access_token)

        logger.info("Authentication successful")
        logger.debug(
            "Token details: token=%s, expires_at=%s, refresh_token_expires_at=%s",
            self._token.access_token,
            self._token.expires_at,
            self._token.refresh_token_expires_at,
        )
        return self._token

    def set_token(self, token: Token) -> None:
        """Manually set the access token (for advanced use cases)."""
        self._token = token
        self._rest.set_auth_header(token.access_token)
        logger.info("Access token set manually")

    def request_otp(self) -> dict:
        """Request an OTP to be sent to the registered channel."""
        if not self._config.api_key or not self._config.api_secret:
            raise AuthenticationError(
                "api_key and api_secret are required for OTP request"
            )

        try:
            data = self._rest.post(
                EP_REQUEST_OTP,
                json_body=OTPRequest(
                    api_key=self._config.api_key,
                    api_secret=self._config.api_secret,
                ).to_dict(),
            )
        except SSIError:
            logger.error("Failed to request OTP for endpoint %s", EP_REQUEST_OTP)
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error requesting OTP for endpoint %s: %s",
                EP_REQUEST_OTP,
                exc,
            )
            raise APIError(f"Unexpected error requesting OTP: {exc}") from exc

        if not isinstance(data, dict):
            logger.error(
                "Unexpected OTP response type for endpoint %s: %s",
                EP_REQUEST_OTP,
                type(data).__name__,
            )
            raise APIError("Unexpected response format while requesting OTP")

        return data

    def ensure_authenticated(self, otp: str | None = None) -> str:
        """Ensure a valid token is available, refreshing if needed.

        If the token is expired and a refresh token is available, the token is
        refreshed automatically without requiring an OTP.  A fresh OTP is only
        required when no refresh token exists or when this is the first login.
        """
        if self._token is None or self.is_token_expired:
            if self.has_refresh_token:
                self.refresh()
            elif otp:
                self.authenticate(otp)
            else:
                raise AuthenticationError(
                    "OTP is required to authenticate — no refresh token available"
                )
        return self._token.access_token  # type: ignore[union-attr]
