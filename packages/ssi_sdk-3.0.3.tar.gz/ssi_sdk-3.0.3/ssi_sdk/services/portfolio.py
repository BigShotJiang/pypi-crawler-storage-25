"""Portfolio service — async and sync."""

from __future__ import annotations

import logging

from ssi_sdk.config import Config
from ssi_sdk.constant import (
    EP_ACCOUNT_BALANCE,
    EP_POSITIONS,
    EP_ACCOUNT_PPMMR,
    EP_ORDER_HISTORY,

    DEFAULT_PAGE,
    DEFAULT_SIZE,
)
from ssi_sdk.exceptions import APIError, SSIError
from ssi_sdk.models import (
    AccountBalanceRequest,
    AccountBalance,
    EquityAccountBalance,
    DerivativeAccountBalance,

    PositionsRequest,
    Position,
    EquityPosition,
    AllDerivativePosition,
    DerivativePosition,

    PPMMRRequest,
    PPMMR,
    EquityPPMMR,
    DerivativePPMMR,

    OrderBookRequest,
    OrderBook,
    Order,
)
from ssi_sdk.transport.rest_client import AsyncRestClient, RestClient
from ssi_sdk.utils import require_non_empty, today_date_str

logger = logging.getLogger("ssi_sdk.services.portfolio")

class AsyncPortfolioService:
    """Async portfolio operations."""

    def __init__(self, rest_client: AsyncRestClient, config: Config):
        self._rest = rest_client
        self.__client_id = config.client_id

    async def __get_balance(self, account_no:str) -> AccountBalance:
        """Get account balance and asset summary."""
        params = AccountBalanceRequest(
            client_id=self.__client_id,
            account_no=account_no
        ).to_dict()
        try:
            logger.debug("Fetching account balance with params: %s", params)
            data = await self._rest.get(EP_ACCOUNT_BALANCE, params=params)
            logger.debug("Received account balance data: %s", data)
        except SSIError:
            logger.error("Failed to fetch balance for account %s", account_no)
            raise
        except Exception as exc:
            logger.error("Unexpected error fetching balance for account %s: %s", account_no, exc)
            raise APIError(f"Unexpected error fetching account balance: {exc}") from exc
        return AccountBalance.from_dict(data)

    async def get_equity_balance(self, account_no:str) -> EquityAccountBalance:
        """Get equity account balance."""
        require_non_empty(account_no, "Account number must be provided")
        balance = await self.__get_balance(account_no)
        return balance.equity

    async def get_derivative_balance(self, account_no:str) -> DerivativeAccountBalance:
        """Get derivative account balance."""
        require_non_empty(account_no, "Account number must be provided")
        balance = await self.__get_balance(account_no)
        return balance.derivative

    # Order book endpoints are not available yet,
    # so these methods will raise NotImplementedError for now
    async def __get_order_book(
        self, account_no:str, from_date: str | None = None, to_date: str | None = None
    ) -> OrderBook:
        """Get order book for the account."""
        order_book_request = OrderBookRequest(
            account_no=account_no,
            from_date=from_date,
            to_date=to_date,
            page=DEFAULT_PAGE,
            size=DEFAULT_SIZE
        ).to_dict()
        logger.debug("Fetching order book with params: %s", order_book_request)
        order_book_response = await self._rest.get(EP_ORDER_HISTORY, params=order_book_request)
        logger.debug("Received order book data: %s", order_book_response)
        return OrderBook.from_dict(order_book_response)

    async def get_today_orders(self, account_no:str) -> list[Order]:
        """Get today's orders for the account."""
        require_non_empty(account_no, "Account number must be provided")
        from_date = today_date_str()
        to_date = today_date_str()
        return (
            await self.__get_order_book(account_no, from_date=from_date, to_date=to_date)
        ).orders

    async def get_historical_orders(
        self, account_no:str, from_date: str, to_date: str
    ) -> list[Order]:
        """Get historical orders for the account."""
        require_non_empty(account_no, "Account number must be provided")
        require_non_empty(from_date, "From date (yyyy/mm/dd) must be provided")
        require_non_empty(to_date, "To date (yyyy/mm/dd) must be provided")
        return (
            await self.__get_order_book(account_no, from_date=from_date, to_date=to_date)
        ).orders

    async def __get_positions(
            self, client_id: str | None = None, account_no:str | None = None
    ) -> Position:
        """Get positions for the account."""
        params = PositionsRequest(
            client_id=client_id,
            account_no=account_no
        ).to_dict()
        try:
            logger.debug("Fetching positions with params: %s", params)
            data = await self._rest.get(EP_POSITIONS, params=params)
            logger.debug("Received position data: %s", data)
            return Position.from_dict(data)
        except SSIError:
            logger.error("Failed to fetch positions for account %s", account_no)
            raise
        except Exception as exc:
            logger.error("Unexpected error fetching positions for account %s: %s", account_no, exc)
            raise APIError(f"Unexpected error fetching positions: {exc}") from exc

    async def get_equity_positions(self, account_no:str) -> list[EquityPosition]:
        """Get equity positions for the account."""
        require_non_empty(account_no, "Account number must be provided")
        position = await self.__get_positions(client_id=self.__client_id, account_no=account_no)
        return position.equity

    async def get_derivative_positions(self, account_no:str) -> list[AllDerivativePosition]:
        """Get derivative positions for the account."""
        require_non_empty(account_no, "Account number must be provided")
        position = await self.__get_positions(client_id=self.__client_id, account_no=account_no)
        return position.derivative

    async def get_open_derivative_positions(self, account_no:str) -> list[DerivativePosition]:
        """Get open derivative positions for the account."""
        require_non_empty(account_no, "Account number must be provided")
        position = await self.__get_positions(client_id=self.__client_id, account_no=account_no)
        return position.derivative.open_positions

    async def get_closed_derivative_positions(self, account_no:str) -> list[DerivativePosition]:
        """Get closed derivative positions for the account."""
        require_non_empty(account_no, "Account number must be provided")
        position = await self.__get_positions(client_id=self.__client_id, account_no=account_no)
        return position.derivative.closed_positions

    async def __get_ppmmr(
        self, account_no:str | None = None
    ) -> PPMMR:
        """Get PPMMR for the client."""
        params = PPMMRRequest(
            account_no=account_no
        ).to_dict()
        try:
            logger.debug("Fetching PPMMR with params: %s", params)
            data = await self._rest.get(EP_ACCOUNT_PPMMR, params=params)
            logger.debug("Received PPMMR data: %s", data)
            return PPMMR.from_dict(data)
        except SSIError:
            logger.error("Failed to fetch PPMMR for account %s", account_no)
            raise
        except Exception as exc:
            logger.error("Unexpected error fetching PPMMR for account %s: %s", account_no, exc)
            raise APIError(f"Unexpected error fetching PPMMR: {exc}") from exc

    async def get_equity_ppmmr(self, account_no:str) -> EquityPPMMR:
        """Get equity PPMMR for the account."""
        require_non_empty(account_no, "Account number must be provided")
        ppmmr = await self.__get_ppmmr(account_no=account_no)
        return ppmmr.equity

    async def get_derivative_ppmmr(self, account_no:str) -> DerivativePPMMR:
        """Get derivative PPMMR for the account."""
        require_non_empty(account_no, "Account number must be provided")
        ppmmr = await self.__get_ppmmr(account_no=account_no)
        return ppmmr.derivative

class PortfolioService:
    """Synchronous portfolio operations."""

    def __init__(self, rest_client: RestClient, config: Config):
        self._rest = rest_client
        self.__client_id = config.client_id

    def __get_balance(self, account_no:str) -> AccountBalance:
        """Get account balance and asset summary."""
        params = AccountBalanceRequest(
            client_id=self.__client_id,
            account_no=account_no
        ).to_dict()
        try:
            logger.debug("Fetching account balance with params: %s", params)
            data = self._rest.get(EP_ACCOUNT_BALANCE, params=params)
            logger.debug("Received account balance data: %s", data)
            return AccountBalance.from_dict(data)
        except SSIError:
            logger.error("Failed to fetch balance for account %s", account_no)
            raise
        except Exception as exc:
            logger.error("Unexpected error fetching balance for account %s: %s", account_no, exc)
            raise APIError(f"Unexpected error fetching account balance: {exc}") from exc

    def get_equity_balance(self, account_no:str) -> EquityAccountBalance:
        """Get equity account balance."""
        require_non_empty(account_no, "Account number must be provided")
        balance = self.__get_balance(account_no)
        return balance.equity

    def get_derivative_balance(self, account_no:str) -> DerivativeAccountBalance:
        """Get derivative account balance."""
        require_non_empty(account_no, "Account number must be provided")
        balance = self.__get_balance(account_no)
        return balance.derivative

    # Order book endpoints are not available yet,
    # so these methods will raise NotImplementedError for now
    def __get_order_book(
        self, account_no:str, from_date: str | None = None, to_date: str | None = None
    ) -> OrderBook:
        """Get order book for the account."""
        order_book_request = OrderBookRequest(
            account_no=account_no,
            from_date=from_date,
            to_date=to_date,
            page=DEFAULT_PAGE,
            size=DEFAULT_SIZE
        ).to_dict()
        logger.debug("Fetching order book with params: %s", order_book_request)
        order_book_response = self._rest.get(EP_ORDER_HISTORY, params=order_book_request)
        logger.debug("Received order book data: %s", order_book_response)
        return OrderBook.from_dict(order_book_response)

    def get_today_orders(self, account_no:str) -> list[Order]:
        """Get today's orders for the account."""
        require_non_empty(account_no, "Account number must be provided")
        today = today_date_str()
        return self.__get_order_book(account_no, from_date=today, to_date=today).orders

    def get_historical_orders(
        self, account_no:str, from_date: str, to_date: str
    ) -> list[Order]:
        """Get historical orders for the account."""
        require_non_empty(account_no, "Account number must be provided")
        require_non_empty(from_date, "From date (yyyy/mm/dd) must be provided")
        require_non_empty(to_date, "To date (yyyy/mm/dd) must be provided")
        return self.__get_order_book(account_no, from_date=from_date, to_date=to_date).orders

    def __get_positions(
            self, client_id: str | None = None, account_no:str | None = None
    ) -> Position:
        """Get positions for the account."""
        params = PositionsRequest(
            client_id=client_id,
            account_no=account_no
        ).to_dict()
        try:
            logger.debug("Fetching positions with params: %s", params)
            data = self._rest.get(EP_POSITIONS, params=params)
            logger.debug("Received position data: %s", data)
            return Position.from_dict(data)
        except SSIError:
            logger.error("Failed to fetch positions for account %s", account_no)
            raise
        except Exception as exc:
            logger.error("Unexpected error fetching positions for account %s: %s", account_no, exc)
            raise APIError(f"Unexpected error fetching positions: {exc}") from exc

    def get_equity_positions(self, account_no:str) -> list[EquityPosition]:
        """Get equity positions for the account."""
        require_non_empty(account_no, "Account number must be provided")
        position = self.__get_positions(client_id=self.__client_id, account_no=account_no)
        return position.equity

    def get_derivative_positions(self, account_no:str) -> list[AllDerivativePosition]:
        """Get derivative positions for the account."""
        require_non_empty(account_no, "Account number must be provided")
        position = self.__get_positions(client_id=self.__client_id, account_no=account_no)
        return position.derivative

    def get_open_derivative_positions(self, account_no:str) -> list[DerivativePosition]:
        """Get open derivative positions for the account."""
        require_non_empty(account_no, "Account number must be provided")
        position = self.__get_positions(client_id=self.__client_id, account_no=account_no)
        return position.derivative.open_positions

    def get_closed_derivative_positions(self, account_no:str) -> list[DerivativePosition]:
        """Get closed derivative positions for the account."""
        require_non_empty(account_no, "Account number must be provided")
        position = self.__get_positions(client_id=self.__client_id, account_no=account_no)
        return position.derivative.closed_positions

    def __get_ppmmr(
        self, account_no:str | None = None
    ) -> PPMMR:
        """Get PPMMR for the client."""
        params = PPMMRRequest(
            account_no=account_no
        ).to_dict()
        try:
            logger.debug("Fetching PPMMR with params: %s", params)
            data = self._rest.get(EP_ACCOUNT_PPMMR, params=params)
            logger.debug("Received PPMMR data: %s", data)
            return PPMMR.from_dict(data)
        except SSIError:
            logger.error("Failed to fetch PPMMR for account %s", account_no)
            raise
        except Exception as exc:
            logger.error("Unexpected error fetching PPMMR for account %s: %s", account_no, exc)
            raise APIError(f"Unexpected error fetching PPMMR: {exc}") from exc

    def get_equity_ppmmr(self, account_no:str) -> EquityPPMMR:
        """Get equity PPMMR for the account."""
        require_non_empty(account_no, "Account number must be provided")
        ppmmr = self.__get_ppmmr(account_no=account_no)
        return ppmmr.equity

    def get_derivative_ppmmr(self, account_no:str) -> DerivativePPMMR:
        """Get derivative PPMMR for the account."""
        require_non_empty(account_no, "Account number must be provided")
        ppmmr = self.__get_ppmmr(account_no=account_no)
        return ppmmr.derivative
