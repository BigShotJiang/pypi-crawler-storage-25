"""
Module: ssi_sdk.services.streaming
Provides the StreamingService class for real-time market data and trading updates via WebSocket.
The StreamingService allows subscribing to various channels
(trade, quote, order status, portfolio, etc.)
and handles incoming messages with user-defined callbacks.
"""

from __future__ import annotations


import asyncio
import logging
import threading
from collections.abc import Callable
from typing import Any

from ssi_sdk.models import (
    RequestMessage,
    HeartbeatMessage,

    ForeignRoomMessage,
    MarketStatusMessage,
    OddLotMessage,
    PutMessage,
    QuoteMessage,
    TradeMessage,

    OrderStatusMessage,
    PortfolioMessage,
)
from ssi_sdk.enums import (
    StreamingChannel,
    StreamingMethod,
    Board,
    DataTopic,
    Timeframe
)
from ssi_sdk.models.streaming import IntervalMessage
from ssi_sdk.transport.websocket_client import AsyncWebSocketClient, WebSocketClient


logger = logging.getLogger("ssi_sdk.services.streaming")


class AsyncStreamingService:
    """Unified real-time streaming via a single WebSocket connection.

    Market data channels: trade, quote, market-status, foreign-room, put, oddlot.
    Portfolio channels: order-status, portfolio.
    """

    def __init__(self, ws_client: AsyncWebSocketClient):
        self._ws = ws_client
        self.__on_data_callbacks: Callable[[dict], Any] | None = None
        self.__on_trading_callbacks: Callable[
            [OrderStatusMessage | PortfolioMessage], Any
        ] | None = None
        self.__on_heartbeat_callbacks: Callable[[HeartbeatMessage], Any] | None = None
        self._ping_task: asyncio.Task | None = None

    @property
    def on_data(self) -> Callable[[dict], Any] | None:
        """Get the current callback for market data messages."""
        return self.__on_data_callbacks

    @on_data.setter
    def on_data(self, callback: Callable[[dict], Any] | None) -> None:
        """Set a callback for market data messages."""
        self.__on_data_callbacks = callback

        def _wrap_data(msg: dict) -> Any:
            topic: str = msg.get("topic", "")
            if topic.startswith(DataTopic.TRADE.value):
                if any(topic.endswith(tf.value) for tf in Timeframe):
                    return callback(IntervalMessage.from_dict(msg.get("data", {})))
                else:
                    return callback(TradeMessage.from_dict(msg.get("data", {})))
            if topic.startswith(DataTopic.QUOTE.value):
                return callback(QuoteMessage.from_dict(msg.get("data", {})))
            if topic.startswith(DataTopic.ROOM.value):
                return callback(ForeignRoomMessage.from_dict(msg.get("data", {})))
            if topic.startswith(DataTopic.MARKET.value):
                return callback(MarketStatusMessage.from_dict(msg.get("data", {})))
            if topic.startswith(DataTopic.PUT.value):
                return callback(PutMessage.from_dict(msg.get("data", {})))
            if topic.startswith(DataTopic.ODD_LOT.value):
                return callback(OddLotMessage.from_dict(msg.get("data", {})))
            return callback(msg)

        self._ws.on(StreamingChannel.DATA.value, _wrap_data if callback is not None else None)

    @property
    def on_trading(self) -> Callable[[OrderStatusMessage | PortfolioMessage], Any] | None:
        """Get the current callback for trading messages."""
        return self.__on_trading_callbacks

    @on_trading.setter
    def on_trading(
        self, callback: Callable[[OrderStatusMessage | PortfolioMessage], Any] | None
    ) -> None:
        """Set a callback for trading messages."""
        self.__on_trading_callbacks = callback

        def _wrap_trading(msg: dict) -> Any:
            topic: str = msg.get("topic", "")
            if topic.startswith("order."):
                return callback(OrderStatusMessage.from_dict(msg.get("data", {})))
            if topic.startswith("portfolio."):
                return callback(PortfolioMessage.from_dict(msg.get("data", {})))
            return callback(msg)

        self._ws.on(
            StreamingChannel.TRADING.value, _wrap_trading if callback is not None else None
        )

    @property
    def on_heartbeat(self) -> Callable[[HeartbeatMessage], Any] | None:
        """Get the current callback for heartbeat messages."""
        return self.__on_heartbeat_callbacks

    @on_heartbeat.setter
    def on_heartbeat(self, callback: Callable[[HeartbeatMessage], Any] | None) -> None:
        """Set a callback for heartbeat messages."""
        self.__on_heartbeat_callbacks = callback
        self._ws.on(
            StreamingChannel.HEARTBEAT.value,
            (
                lambda msg: callback(HeartbeatMessage.from_dict(msg))
            ) if callback is not None else None,
        )

    async def __subscribe(
        self,
        request: RequestMessage,
        on_response: Callable[[dict], Any] | None = None,
    ) -> None:
        """Helper to subscribe to a channel with an optional callback."""
        if on_response is not None:
            self._ws.on(request.channel.value, on_response)
        await self._ws.send(request.to_dict())

    async def ping(
        self,
        on_response: Callable[[dict], Any] | None = None,
        interval: float | None = None,
    ) -> None:
        """Send a ping to the WebSocket server.

        Args:
            on_response: Optional callback for the ping response.
            interval: If provided, send a ping every *interval* seconds in the
                background.  Calling ping() again cancels the previous loop.
                Pass ``interval=None`` to send a single ping.
        """
        async def _send_once() -> None:
            logger.debug("Sending ping to WebSocket server")
            await self.__subscribe(
                RequestMessage(
                    method=StreamingMethod.PING_PONG,
                    channel=StreamingChannel.HEARTBEAT,
                ),
                on_response,
            )
            logger.debug("Ping sent to WebSocket server")

        if interval is None:
            await _send_once()
            return

        # Cancel any existing ping loop
        if self._ping_task and not self._ping_task.done():
            self._ping_task.cancel()

        async def _ping_loop() -> None:
            try:
                while True:
                    await _send_once()
                    await asyncio.sleep(interval)
            except asyncio.CancelledError:
                logger.debug("Ping loop cancelled")

        self._ping_task = asyncio.create_task(_ping_loop())
        logger.debug("Ping loop started with interval=%.1fs", interval)

    async def subscribe_symbol_ohlcv(
        self,
        symbols: list[str],
        interval: Timeframe,
        on_response: Callable[[dict], Any] | None = None,
    ) -> None:
        """Subscribe to OHLCV channels for the given symbols."""
        logger.debug("Subscribing to OHLCV channels: %s", symbols)
        topics = [f"trade.{symbol}@{interval.value}" for symbol in symbols]
        await self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics,
            ),
            on_response,
        )
        logger.debug("Subscribed to OHLCV channels: %s", topics)

    async def subscribe_symbol_trade(
        self,
        symbols: list[str],
        on_response: Callable[[dict], Any] | None = None,
    ) -> None:
        """Subscribe to trade channels for the given symbols."""
        logger.debug("Subscribing to market trade channels: %s", symbols)
        topics = [f"trade.{symbol}" for symbol in symbols]
        await self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics,
            ),
            on_response,
        )
        logger.debug("Subscribed to market trade channels: %s", topics)

    async def subscribe_symbol_quote(
        self,
        symbols: list[str],
        on_response: Callable[[dict], Any] | None = None,
    ) -> None:
        """Subscribe to quote channels for the given symbols."""
        logger.debug("Subscribing to market quote channels: %s", symbols)
        topics = [f"quote.{symbol}" for symbol in symbols]
        await self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics,
            ),
            on_response,
        )
        logger.debug("Subscribed to market quote channels: %s", topics)

    async def subscribe_symbol_room(
        self,
        symbols: list[str],
        on_response: Callable[[dict], Any] | None = None,
    ) -> None:
        """Subscribe to foreign room channels for the given symbols."""
        logger.debug("Subscribing to foreign room channels: %s", symbols)
        topics = [f"room.{symbol}" for symbol in symbols]
        await self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics,
            ),
            on_response,
        )
        logger.debug("Subscribed to foreign room channels: %s", topics)

    async def subscribe_symbol_put_through(
        self,
        symbols: list[str],
        on_response: Callable[[dict], Any] | None = None,
    ) -> None:
        """Subscribe to put-through channels for the given symbols."""
        logger.debug("Subscribing to put channels: %s", symbols)
        topics = [f"put.{symbol}" for symbol in symbols]
        await self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics,
            ),
            on_response,
        )
        logger.debug("Subscribed to put channels: %s", topics)

    async def subscribe_symbol_odd_lot(
        self,
        symbols: list[str],
        on_response: Callable[[dict], Any] | None = None,
    ) -> None:
        """Subscribe to odd-lot channels for the given symbols."""
        logger.debug("Subscribing to odd lot channels: %s", symbols)
        topics = [f"oddlot.{symbol}" for symbol in symbols]
        await self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics,
            ),
            on_response,
        )
        logger.debug("Subscribed to odd lot channels: %s", topics)

    async def subscribe_symbol(
        self,
        symbols: list[str],
        on_response: Callable[[dict], Any] | None = None,
    ) -> None:
        """Subscribe to trade, quote, and foreign-room channels for the given symbols."""
        await self.subscribe_symbol_trade(symbols, on_response)
        await self.subscribe_symbol_quote(symbols, on_response)
        await self.subscribe_symbol_room(symbols, on_response)

    async def subscribe_board(
        self,
        boards: list[Board],
        on_response: Callable[[dict], Any] | None = None,
    ) -> None:
        """Subscribe to trade, quote, and foreign-room channels for the given boards."""
        board_values = [board.value for board in boards]
        await self.subscribe_symbol_trade(board_values, on_response)
        await self.subscribe_symbol_quote(board_values, on_response)
        await self.subscribe_symbol_room(board_values, on_response)

    async def subscribe_index(
        self,
        indices: list[str],
        on_response: Callable[[dict], Any] | None = None,
    ) -> None:
        """Subscribe to trade, quote, and foreign-room channels for the given indices."""
        await self.subscribe_symbol_trade(indices, on_response)
        await self.subscribe_symbol_quote(indices, on_response)
        await self.subscribe_symbol_room(indices, on_response)

    async def unsubscribe_symbol_trade(self, symbols: list[str]) -> None:
        """Unsubscribe from trade channels for the given symbols."""
        logger.debug("Unsubscribing from market trade channels: %s", symbols)
        topics = [f"trade.{symbol}" for symbol in symbols]
        await self._ws.send(
            RequestMessage(
                method=StreamingMethod.UNSUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics,
            ).to_dict()
        )
        logger.debug("Unsubscribed from market trade channels: %s", topics)

    async def unsubscribe_symbol_quote(self, symbols: list[str]) -> None:
        """Unsubscribe from quote channels for the given symbols."""
        logger.debug("Unsubscribing from market quote channels: %s", symbols)
        topics = [f"quote.{symbol}" for symbol in symbols]
        await self._ws.send(
            RequestMessage(
                method=StreamingMethod.UNSUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics,
            ).to_dict()
        )
        logger.debug("Unsubscribed from market quote channels: %s", topics)

    async def unsubscribe_symbol_room(self, symbols: list[str]) -> None:
        """Unsubscribe from foreign room channels for the given symbols."""
        logger.debug("Unsubscribing from foreign room channels: %s", symbols)
        topics = [f"room.{symbol}" for symbol in symbols]
        await self._ws.send(
            RequestMessage(
                method=StreamingMethod.UNSUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics,
            ).to_dict()
        )
        logger.debug("Unsubscribed from foreign room channels: %s", topics)

    async def unsubscribe_symbol_put_through(self, symbols: list[str]) -> None:
        """Unsubscribe from put-through channels for the given symbols."""
        logger.debug("Unsubscribing from put channels: %s", symbols)
        topics = [f"put.{symbol}" for symbol in symbols]
        await self._ws.send(
            RequestMessage(
                method=StreamingMethod.UNSUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics,
            ).to_dict()
        )
        logger.debug("Unsubscribed from put channels: %s", topics)

    async def unsubscribe_symbol_odd_lot(self, symbols: list[str]) -> None:
        """Unsubscribe from odd-lot channels for the given symbols."""
        logger.debug("Unsubscribing from odd lot channels: %s", symbols)
        topics = [f"oddlot.{symbol}" for symbol in symbols]
        await self._ws.send(
            RequestMessage(
                method=StreamingMethod.UNSUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics,
            ).to_dict()
        )
        logger.debug("Unsubscribed from odd lot channels: %s", topics)

    async def unsubscribe_symbol(self, symbols: list[str]) -> None:
        """Unsubscribe from trade, quote, and foreign-room channels for the given symbols."""
        await self.unsubscribe_symbol_trade(symbols)
        await self.unsubscribe_symbol_quote(symbols)
        await self.unsubscribe_symbol_room(symbols)

    async def unsubscribe_board(self, boards: list[Board]) -> None:
        """Unsubscribe from trade, quote, and foreign-room channels for the given boards."""
        board_values = [board.value for board in boards]
        await self.unsubscribe_symbol_trade(board_values)
        await self.unsubscribe_symbol_quote(board_values)
        await self.unsubscribe_symbol_room(board_values)

    async def unsubscribe_index(self, indices: list[str]) -> None:
        """Unsubscribe from trade, quote, and foreign-room channels for the given indices."""
        await self.unsubscribe_symbol_trade(indices)
        await self.unsubscribe_symbol_quote(indices)
        await self.unsubscribe_symbol_room(indices)

    async def subscribe_order_status(
        self,
        account_no: str = "*",
        on_response: Callable[[dict], Any] | None = None,
    ) -> None:
        """Subscribe to order status updates."""
        logger.debug("Subscribing to order status updates")
        await self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.TRADING,
                topics=[f"order.{account_no}"],
            ),
            on_response,
        )
        logger.debug("Subscribed to order status updates")

    async def subscribe_portfolio(
        self,
        account_no: str = "*",
        on_response: Callable[[dict], Any] | None = None,
    ) -> None:
        """Subscribe to portfolio updates."""
        logger.debug("Subscribing to portfolio updates")
        await self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.TRADING,
                topics=[f"portfolio.{account_no}"],
            ),
            on_response,
        )
        logger.debug("Subscribed to portfolio updates")

    async def connect(self) -> None:
        """Open the WebSocket connection."""
        await self._ws.connect()

    async def disconnect(self) -> None:
        """Close the WebSocket connection."""
        await self._ws.disconnect()

    async def wait(self, timeout: float | None = None) -> None:
        """Await until the connection is closed or *timeout* seconds elapse."""
        await self._ws.wait(timeout)


class StreamingService:
    """Synchronous unified real-time streaming via a single WebSocket connection.

    Market data channels: trade, quote, market-status, foreign-room, put, oddlot.
    Portfolio channels: order-status, portfolio.
    """

    def __init__(self, ws_client: WebSocketClient):
        self._ws = ws_client
        self.__on_data_callbacks: Callable[[dict], Any] | None = None
        self.__on_trading_callbacks: Callable[
            [OrderStatusMessage | PortfolioMessage], Any
        ] | None = None
        self.__on_heartbeat_callbacks: Callable[[HeartbeatMessage], Any] | None = None
        self._ping_thread: threading.Thread | None = None
        self._ping_stop = threading.Event()

    @property
    def on_data(self) -> Callable[[dict], Any] | None:
        """Get the current callback for market data messages."""
        return self.__on_data_callbacks
    @on_data.setter
    def on_data(self, callback: Callable[[dict], Any] | None) -> None:
        """Set a callback for market data messages.
        The callback will be invoked with the raw message dict whenever a new
        market data message is received on the DATA channel.
        """
        self.__on_data_callbacks = callback
        def _wrap_data(msg: dict) -> Any:
            topic: str = msg.get("topic", "")
            if topic.startswith(DataTopic.TRADE.value):
                if any(topic.endswith(tf.value) for tf in Timeframe):
                    return callback(IntervalMessage.from_dict(msg.get("data", {})))
                else:
                    return callback(TradeMessage.from_dict(msg.get("data", {})))
            if topic.startswith(DataTopic.QUOTE.value):
                return callback(QuoteMessage.from_dict(msg.get("data", {})))
            if topic.startswith(DataTopic.ROOM.value):
                return callback(ForeignRoomMessage.from_dict(msg.get("data", {})))
            if topic.startswith(DataTopic.MARKET.value):
                return callback(MarketStatusMessage.from_dict(msg.get("data", {})))
            if topic.startswith(DataTopic.PUT.value):
                return callback(PutMessage.from_dict(msg.get("data", {})))
            if topic.startswith(DataTopic.ODD_LOT.value):
                return callback(OddLotMessage.from_dict(msg.get("data", {})))
            return callback(msg)
        self._ws.on(StreamingChannel.DATA.value, _wrap_data if callback is not None else None)

    @property
    def on_trading(self) -> Callable[[OrderStatusMessage | PortfolioMessage], Any] | None:
        """Get the current callback for trading messages."""
        return self.__on_trading_callbacks
    @on_trading.setter
    def on_trading(
        self, callback: Callable[[OrderStatusMessage | PortfolioMessage], Any] | None
    ) -> None:
        """Set a callback for trading messages.
        The callback will be invoked with an OrderStatusMessage or PortfolioMessage
        depending on the topic, whenever a new message is received on the TRADING channel.
        """
        self.__on_trading_callbacks = callback

        def _wrap_trading(msg: dict) -> Any:
            topic: str = msg.get("topic", "")
            if topic.startswith("order."):
                return callback(OrderStatusMessage.from_dict(msg.get("data", {})))
            if topic.startswith("portfolio."):
                return callback(PortfolioMessage.from_dict(msg.get("data", {})))
            return callback(msg)

        self._ws.on(
            StreamingChannel.TRADING.value, _wrap_trading if callback is not None else None
        )

    @property
    def on_heartbeat(self) -> Callable[[HeartbeatMessage], Any] | None:
        """Get the current callback for heartbeat messages."""
        return self.__on_heartbeat_callbacks
    @on_heartbeat.setter
    def on_heartbeat(self, callback: Callable[[HeartbeatMessage], Any] | None) -> None:
        """Set a callback for heartbeat messages.
        The callback will be invoked with a HeartbeatMessage whenever a new
        heartbeat message is received on the HEARTBEAT channel.
        """
        self.__on_heartbeat_callbacks = callback
        self._ws.on(
            StreamingChannel.HEARTBEAT.value,
            (
                lambda msg: callback(HeartbeatMessage.from_dict(msg))
            ) if callback is not None else None,
        )
    # ------------------------------------------------------------------
    # Market data subscriptions
    # ------------------------------------------------------------------

    def __subscribe(
        self,
        request: RequestMessage,
        on_response: Callable[[dict], Any] | None = None
    ) -> None:
        """Helper to subscribe to a channel with an optional callback."""
        if on_response is not None:
            self._ws.on(request.channel.value, on_response)
        self._ws.send(request.to_dict())

    # Heartbeat channel is special - we want to allow pinging without needing to set a callback
    def ping(
        self,
        on_response: Callable[[dict], Any] | None = None,
        interval: float | None = None,
    ) -> None:
        """Send a ping to the WebSocket server.

        Args:
            on_response: Optional callback for the ping response.
            interval: If provided, send a ping every *interval* seconds in the
                background.  Calling ping() again cancels the previous loop.
                Pass ``interval=None`` to send a single ping.
        """
        def _send_once() -> None:
            logger.debug("Sending ping to WebSocket server")
            self.__subscribe(
                RequestMessage(
                    method=StreamingMethod.PING_PONG,
                    channel=StreamingChannel.HEARTBEAT,
                ),
                on_response,
            )
            logger.debug("Ping sent to WebSocket server")

        if interval is None:
            _send_once()
            return

        # Stop any existing ping loop
        self._ping_stop.set()
        if self._ping_thread and self._ping_thread.is_alive():
            self._ping_thread.join(timeout=interval + 1)

        self._ping_stop.clear()

        def _ping_loop() -> None:
            while not self._ping_stop.wait(timeout=interval):
                _send_once()

        self._ping_thread = threading.Thread(
            target=_ping_loop, daemon=True, name="ssi-ping-loop"
        )
        self._ping_thread.start()
        logger.debug("Ping loop started with interval=%.1fs", interval)

    # Data channels: trade, quote, market-status, foreign-room, put, oddlot
    def subscribe_symbol_ohlcv(
        self,
        symbols: list[str],
        interval: Timeframe,
        on_response: Callable[[dict], Any] | None = None
    ) -> None:
        """Subscribe to OHLCV channels."""
        logger.debug("Subscribing to OHLCV channels: %s", symbols)
        topics = [f"trade.{symbol}@{interval.value}" for symbol in symbols]
        print(topics)
        self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics
            ),
            on_response
        )
        logger.debug("Subscribed to OHLCV channels: %s", topics)

    def subscribe_symbol_trade(
        self,
        symbols: list[str],
        on_response: Callable[[dict], Any] | None = None
    ) -> None:
        """Subscribe to market data channels."""
        logger.debug("Subscribing to market trade channels: %s", symbols)
        topics = [f"trade.{symbol}" for symbol in symbols]
        self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics
            ),
            on_response
        )
        logger.debug("Subscribed to market trade channels: %s", topics)

    def subscribe_symbol_quote(
        self,
        symbols: list[str],
        on_response: Callable[[dict], Any] | None = None
    ) -> None:
        """Subscribe to market quote channels."""
        logger.debug("Subscribing to market quote channels: %s", symbols)
        topics = [f"quote.{symbol}" for symbol in symbols]
        self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics
            ),
            on_response
        )
        logger.debug("Subscribed to market quote channels: %s", topics)

    def subscribe_symbol_room(
        self, symbols: list[str],
        on_response: Callable[[dict], Any] | None = None
    ) -> None:
        """Subscribe to foreign room channels."""
        logger.debug("Subscribing to foreign room channels: %s", symbols)
        topics = [f"room.{symbol}" for symbol in symbols]
        self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics
            ),
            on_response
        )
        logger.debug("Subscribed to foreign room channels: %s", topics)

    def subscribe_symbol_put_through(
        self, symbols: list[str],
        on_response: Callable[[dict], Any] | None = None
    ) -> None:
        """Subscribe to put channels."""
        logger.debug("Subscribing to put channels: %s", symbols)
        topics = [f"put.{symbol}" for symbol in symbols]
        self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics
            ),
            on_response
        )
        logger.debug("Subscribed to put channels: %s", topics)

    def subscribe_symbol_odd_lot(
        self, symbols: list[str],
        on_response: Callable[[dict], Any] | None = None
    ) -> None:
        """Subscribe to odd lot channels."""
        logger.debug("Subscribing to odd lot channels: %s", symbols)
        topics = [f"oddlot.{symbol}" for symbol in symbols]
        self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics
            ),
            on_response
        )
        logger.debug("Subscribed to odd lot channels: %s", topics)

    def subscribe_symbol(
        self,
        symbols: list[str], on_response: Callable[[dict], Any] | None = None
    ) -> None:
        """Subscribe to all market data channels for the given symbols."""
        self.subscribe_symbol_trade(symbols, on_response)
        self.subscribe_symbol_quote(symbols, on_response)
        self.subscribe_symbol_room(symbols, on_response)

    def subscribe_board(
        self,
        boards: list[Board],
        on_response: Callable[[dict], Any] | None = None
    ) -> None:
        """Subscribe to board."""
        boards = [board.value for board in boards]
        self.subscribe_symbol_trade(boards, on_response)
        self.subscribe_symbol_quote(boards, on_response)
        self.subscribe_symbol_room(boards, on_response)

    def subscribe_index(
        self,
        indices: list[str],
        on_response: Callable[[dict], Any] | None = None
    ) -> None:
        """Subscribe to index."""
        self.subscribe_symbol_trade(indices, on_response)
        self.subscribe_symbol_quote(indices, on_response)
        self.subscribe_symbol_room(indices, on_response)

    def unsubscribe_symbol_trade(self, symbols: list[str]) -> None:
        """Unsubscribe from market data channels."""
        logger.debug("Unsubscribing from market trade channels: %s", symbols)
        topics = [f"trade.{symbol}" for symbol in symbols]
        self._ws.send(
            RequestMessage(
                method=StreamingMethod.UNSUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics
            ).to_dict()
        )
        logger.debug("Unsubscribed from market trade channels: %s", topics)

    def unsubscribe_symbol_quote(self, symbols: list[str]) -> None:
        """Unsubscribe from market quote channels."""
        logger.debug("Unsubscribing from market quote channels: %s", symbols)
        topics = [f"quote.{symbol}" for symbol in symbols]
        self._ws.send(
            RequestMessage(
                method=StreamingMethod.UNSUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics
            ).to_dict()
        )
        logger.debug("Unsubscribed from market quote channels: %s", topics)

    def unsubscribe_symbol_room(self, symbols: list[str]) -> None:
        """Unsubscribe from foreign room channels."""
        logger.debug("Unsubscribing from foreign room channels: %s", symbols)
        topics = [f"room.{symbol}" for symbol in symbols]
        self._ws.send(
            RequestMessage(
                method=StreamingMethod.UNSUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics
            ).to_dict()
        )
        logger.debug("Unsubscribed from foreign room channels: %s", topics)

    def unsubscribe_symbol_put_through(self, symbols: list[str]) -> None:
        """Unsubscribe from put channels."""
        logger.debug("Unsubscribing from put channels: %s", symbols)
        topics = [f"put.{symbol}" for symbol in symbols]
        self._ws.send(
            RequestMessage(
                method=StreamingMethod.UNSUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics
            ).to_dict()
        )
        logger.debug("Unsubscribed from put channels: %s", topics)

    def unsubscribe_symbol_odd_lot(self, symbols: list[str]) -> None:
        """Unsubscribe from odd lot channels."""
        logger.debug("Unsubscribing from odd lot channels: %s", symbols)
        topics = [f"oddlot.{symbol}" for symbol in symbols]
        self._ws.send(
            RequestMessage(
                method=StreamingMethod.UNSUBSCRIBE,
                channel=StreamingChannel.DATA,
                topics=topics
            ).to_dict()
        )
        logger.debug("Unsubscribed from odd lot channels: %s", topics)

    def unsubscribe_symbol(self, symbols: list[str]) -> None:
        """Unsubscribe from all market data channels for the given symbols."""
        self.unsubscribe_symbol_trade(symbols)
        self.unsubscribe_symbol_quote(symbols)
        self.unsubscribe_symbol_room(symbols)

    def unsubscribe_board(self, boards: list[Board]) -> None:
        """Unsubscribe from board."""
        boards = [board.value for board in boards]
        self.unsubscribe_symbol_trade(boards)
        self.unsubscribe_symbol_quote(boards)
        self.unsubscribe_symbol_room(boards)

    def unsubscribe_index(self, indices: list[str]) -> None:
        """Unsubscribe from index."""
        self.unsubscribe_symbol_trade(indices)
        self.unsubscribe_symbol_quote(indices)
        self.unsubscribe_symbol_room(indices)

    # Trading channels: order-status, portfolio
    def subscribe_order_status(
        self, account_no: str = "*", on_response: Callable[[dict], Any] | None = None
    ) -> None:
        """Subscribe to order status updates.
        The callback will be invoked with the raw message dict whenever a new
        order status message is received on the TRADING channel.
        """
        logger.debug("Subscribing to order status updates")
        self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.TRADING,
                topics=[f"order.{account_no}"]
            ),
            on_response
        )
        logger.debug("Subscribed to order status updates")

    def subscribe_portfolio(
        self,
        account_no: str = "*",
        on_response: Callable[[dict], Any] | None = None
    ) -> None:
        """Subscribe to portfolio updates.
        The callback will be invoked with the raw message dict whenever a new
        portfolio message is received on the TRADING channel.
        """
        logger.debug("Subscribing to portfolio updates")
        self.__subscribe(
            RequestMessage(
                method=StreamingMethod.SUBSCRIBE,
                channel=StreamingChannel.TRADING,
                topics=[f"portfolio.{account_no}"]
            ),
            on_response
        )
        logger.debug("Subscribed to portfolio updates")

    # Waiting for messages
    def connect(self) -> None:
        """Open the WebSocket connection."""
        self._ws.connect()

    def disconnect(self) -> None:
        """Close the WebSocket connection."""
        self._ws.disconnect()

    def wait(self, timeout: float | None = None) -> None:
        """
        Block the current thread, listening for messages until *timeout* seconds
        elapse or the connection is closed.
        """
        self._ws.wait(timeout)
