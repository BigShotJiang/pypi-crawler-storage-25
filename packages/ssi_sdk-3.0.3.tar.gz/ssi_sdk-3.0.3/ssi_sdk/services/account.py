"""Account service — async and sync."""

from __future__ import annotations

import logging

from ssi_sdk.constant import EP_ACCOUNT_INFO
from ssi_sdk.models.account import Account
from ssi_sdk.exceptions import APIError, SSIError
from ssi_sdk.transport.rest_client import AsyncRestClient, RestClient

logger = logging.getLogger("ssi_sdk.services.account")


class AsyncAccountService:
    """Async account operations."""

    def __init__(self, rest_client: AsyncRestClient):
        self._rest = rest_client

    async def get_account_info(self) -> list[Account]:
        """Get list of accessible trading accounts."""
        try:
            logger.debug("Fetching account info from endpoint %s", EP_ACCOUNT_INFO)
            data = await self._rest.get(EP_ACCOUNT_INFO)
            logger.debug("Received account info data: %s", data)
        except SSIError:
            logger.error("Failed to fetch account info for endpoint %s", EP_ACCOUNT_INFO)
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error fetching account info for endpoint %s: %s",
                EP_ACCOUNT_INFO, exc
            )
            raise APIError(f"Unexpected error fetching account info: {exc}") from exc

        return Account.from_list(data)


class AccountService:
    """Synchronous account operations."""

    def __init__(self, rest_client: RestClient):
        self._rest = rest_client

    def get_account_info(self) -> list[Account]:
        """Get list of accessible trading accounts."""
        try:
            logger.debug("Fetching account info from endpoint %s", EP_ACCOUNT_INFO)
            data = self._rest.get(EP_ACCOUNT_INFO)
            logger.debug("Received account info data: %s", data)
        except SSIError:
            logger.error("Failed to fetch account info for endpoint %s", EP_ACCOUNT_INFO)
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error fetching account info for endpoint %s: %s",
                EP_ACCOUNT_INFO, exc
            )
            raise APIError(f"Unexpected error fetching account info: {exc}") from exc

        return Account.from_list(data)
