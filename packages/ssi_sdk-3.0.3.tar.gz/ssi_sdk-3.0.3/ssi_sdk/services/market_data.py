"""Market data service (OHLC, Index, Security, Download, FA, TA) — async and sync."""

from __future__ import annotations

import logging

from ssi_sdk.constant import (
    DEFAULT_PAGE,
    DEFAULT_SIZE,
    EP_DATA_OHLC,
    EP_DATA_INDEX_LIST,
    EP_DATA_INDEX_SUMMARY,
    EP_DATA_SECURITIES_BY_BOARD,
    EP_DATA_SECURITIES_SUMMARY
)
from ssi_sdk.models import (
    OHLCRequest,
    OHLCData,
    MarketIndexesRequest,
    MarketIndexes,
    MarketIndexSummaryRequest,
    MarketIndexSummary,
    SecuritiesInfoRequest,
    SecuritiesInfo,
    SecuritiesSummaryRequest,
    SecuritiesSummary,
)
from ssi_sdk.enums import Board, Timeframe
from ssi_sdk.exceptions import APIError, SSIError
from ssi_sdk.transport.rest_client import AsyncRestClient, RestClient
from ssi_sdk.utils import (
    require_non_empty,
    from_beginning_of_day,
    from_end_of_day,
    today_date_str,
)


logger = logging.getLogger("ssi_sdk.services.market_data")


class AsyncMarketDataService:
    """Async market data: OHLC, index info, security info, FA, TA."""

    def __init__(self, rest_client: AsyncRestClient):
        self._rest = rest_client

    # TODO: Implement OHLC download when API is available
    async def __download_ohlc(
        self,
        symbol: str,
        timeframe: Timeframe,
    ) -> dict:
        """Bulk-download market data."""
        raise NotImplementedError("OHLC download is not implemented yet")

    async def download_ohlc_1minute(self, symbol: str) -> dict:
        """Download 1-minute OHLC data for a symbol."""
        return await self.__download_ohlc(symbol, Timeframe.MINUTE_1)

    async def download_ohlc_1day(self, symbol: str) -> dict:
        """Download 1-day OHLC data for a symbol."""
        return await self.__download_ohlc(symbol, Timeframe.DAY_1)

    # Implement OHLC retrieval when API is available
    async def __get_ohlc(
        self, symbol: str, from_date: str, to_date: str, timeframe: Timeframe,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get OHLC data for a symbol and timeframe."""
        params = OHLCRequest(
            symbol=symbol,
            from_date=from_date,
            to_date=to_date,
            timeframe=timeframe,
            page=page,
            size=size
        ).to_dict()
        try:
            logger.debug(
                "Fetching OHLC data for symbol %s, timeframe %s, from %s to %s",
                symbol, timeframe, from_date, to_date
            )
            data = await self._rest.get(EP_DATA_OHLC, params=params)
            logger.debug(
                "Fetched OHLC data for symbol %s, timeframe %s, from %s to %s",
                symbol, timeframe, from_date, to_date
            )
            return OHLCData.from_list(data=data.get("data", []))
        except SSIError:
            logger.error(
                "Error fetching OHLC data for symbol %s, timeframe %s, from %s to %s",
                symbol, timeframe, from_date, to_date
            )
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error fetching OHLC data for symbol %s, timeframe %s, "
                "from %s to %s: %s",
                symbol, timeframe, from_date, to_date, exc
            )
            raise APIError(f"Unexpected error fetching OHLC data: {exc}") from exc

    async def get_ohlc_1minute(self, symbol: str) -> list[OHLCData]:
        """Get 1-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        from_date = from_beginning_of_day()
        to_date = from_end_of_day()
        return await self.__get_ohlc(
            symbol=symbol,
            from_date=from_date,
            to_date=to_date,
            timeframe=Timeframe.MINUTE_1,
            page=DEFAULT_PAGE,
            size=DEFAULT_SIZE
        )

    async def get_ohlc_1minute_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 1-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return await self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MINUTE_1,
            page=page, size=size
        )

    async def get_ohlc_3minute(self, symbol: str) -> list[OHLCData]:
        """Get 3-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        from_date = from_beginning_of_day()
        to_date = from_end_of_day()
        return await self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MINUTE_3,
            page=DEFAULT_PAGE, size=DEFAULT_SIZE
        )

    async def get_ohlc_3minute_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 3-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return await self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MINUTE_3,
            page=page, size=size
        )

    async def get_ohlc_5minute(self, symbol: str) -> list[OHLCData]:
        """Get 5-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        from_date = from_beginning_of_day()
        to_date = from_end_of_day()
        return await self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MINUTE_5,
            page=DEFAULT_PAGE, size=DEFAULT_SIZE
        )

    async def get_ohlc_5minute_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 5-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return await self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MINUTE_5,
            page=page, size=size
        )

    async def get_ohlc_15minute(self, symbol: str) -> list[OHLCData]:
        """Get 15-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        from_date = from_beginning_of_day()
        to_date = from_end_of_day()
        return await self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MINUTE_15,
            page=DEFAULT_PAGE, size=DEFAULT_SIZE
        )

    async def get_ohlc_15minute_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 15-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return await self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MINUTE_15,
            page=page, size=size
        )

    async def get_ohlc_1hour(self, symbol: str) -> list[OHLCData]:
        """Get 1-hour OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        from_date = from_beginning_of_day()
        to_date = from_end_of_day()
        return await self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.HOUR_1,
            page=DEFAULT_PAGE, size=DEFAULT_SIZE
        )

    async def get_ohlc_1hour_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 1-hour OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return await self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.HOUR_1,
            page=page, size=size
        )

    async def get_ohlc_1day_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 1-day OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return await self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.DAY_1,
            page=page, size=size
        )

    async def get_ohlc_1week_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 1-week OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return await self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.WEEK_1,
            page=page, size=size
        )

    async def get_ohlc_1month_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 1-month OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return await self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MONTH_1,
            page=page, size=size
        )

    # Implement index retrieval when API is available
    async def __get_indexes(self, board: Board | None = None) -> list[MarketIndexes]:
        """Get list of market indices."""
        params = MarketIndexesRequest(board=board).to_dict()
        try:
            logger.debug(
                "Fetching market indexes for board %s with params: %s",
                board.value if board else None, params
            )
            data = await self._rest.get(EP_DATA_INDEX_LIST, params=params)
            logger.debug(
                "Fetched market indexes for board %s: %s",
                board.value if board else None, data
            )
        except SSIError:
            logger.error(
                "Error fetching market indexes for board %s",
                board.value if board else None
            )
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error fetching market indexes for board %s: %s",
                board.value if board else None, exc
            )
            raise APIError(f"Unexpected error fetching market indexes: {exc}") from exc

        return MarketIndexes.from_list(data)

    async def get_indexes(self) -> list[MarketIndexes]:
        """Get list of market indices."""
        return await self.__get_indexes()

    async def get_indexes_by_board(self, board: Board) -> list[MarketIndexes]:
        """Get list of market indices filtered by board."""
        require_non_empty(board, "Board must be provided")
        return await self.__get_indexes(board=board)

    # Implement index summary when API is available
    async def __get_index_summary(
        self, index: str | None = None, board: Board | None = None, trading_date: str | None = None
    ) -> list[MarketIndexSummary]:
        """Get summary information for a specific index."""
        params = MarketIndexSummaryRequest(
            index=index, board=board, trading_date=trading_date
        ).to_dict()
        try:
            logger.debug("Fetching index summary for %s", params)
            data = await self._rest.get(EP_DATA_INDEX_SUMMARY, params=params)
            logger.debug("Received index summary data for %s: %s", params, data)
        except SSIError:
            logger.error(
                "Error fetching index summary for index %s, board %s, trading date %s",
                index, board.value if board else None, trading_date
            )
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error fetching index summary for index %s, board %s, "
                "trading date %s: %s",
                index, board.value if board else None, trading_date, exc
            )
            raise APIError(f"Unexpected error fetching index summary: {exc}") from exc
        return MarketIndexSummary.from_list(data)

    async def get_index_summary(self, index: str) -> MarketIndexSummary | None:
        """Get summary information for a specific index."""
        require_non_empty(index, "Index code must be provided")
        index_summary = await self.__get_index_summary(index=index)
        return index_summary[0] if index_summary else None

    async def get_index_summary_historical(
        self, index: str, trading_date: str
    ) -> MarketIndexSummary | None:
        """Get historical summary information for a specific index on a given trading date."""
        require_non_empty(index, "Index code must be provided")
        require_non_empty(trading_date, "Trading date must be provided")
        index_summary = await self.__get_index_summary(index=index, trading_date=trading_date)
        return index_summary[0] if index_summary else None

    async def get_board_summary(self, board: Board) -> MarketIndexSummary:
        """Get summary information for a specific board."""
        require_non_empty(board, "Board must be provided")
        board_summary = await self.__get_index_summary(board=board)
        return board_summary[0] if board_summary else None

    async def get_board_summary_historical(
        self, board: Board, trading_date: str
    ) -> MarketIndexSummary | None:
        """Get historical summary information for a specific board on a given trading date."""
        require_non_empty(board, "Board must be provided")
        require_non_empty(trading_date, "Trading date must be provided")
        board_summary = await self.__get_index_summary(board=board, trading_date=trading_date)
        return board_summary[0] if board_summary else None

    # Implement securities information when API is available
    async def __get_securities_info(self,
        index: str | None = None, board: Board | None = None, symbol: str | None = None
    ) -> list[SecuritiesInfo]:
        """Get list of securities information."""
        params = SecuritiesInfoRequest(index=index, board=board, symbol=symbol).to_dict()
        try:
            logger.debug(
                "Fetching securities information for symbol %s, index %s, board %s with params: %s",
                symbol, index, board.value if isinstance(board, Board) else board, params
            )
            data = await self._rest.get(EP_DATA_SECURITIES_BY_BOARD, params=params)
            logger.debug(
                "Received securities information for symbol %s, index %s, board %s: %s",
                symbol, index, board.value if isinstance(board, Board) else board, data
            )
            return SecuritiesInfo.from_list(data)
        except SSIError:
            logger.error(
                "Error fetching securities information for symbol %s, index %s, board %s",
                symbol, index, board.value if isinstance(board, Board) else board
            )
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error fetching securities information for symbol %s, "
                "index %s, board %s: %s",
                symbol, index, board.value if isinstance(board, Board) else board, exc
            )
            raise APIError(f"Unexpected error fetching securities information: {exc}") from exc

    async def get_securities_info(self, symbol: str) -> SecuritiesInfo | None:
        """Get securities information for a symbol."""
        require_non_empty(symbol, "Symbol must be provided")
        securities_info = await self.__get_securities_info(symbol=symbol)
        return securities_info[0] if securities_info else None

    async def get_securities_info_by_index(self, index: str) -> list[SecuritiesInfo]:
        """Get list of securities information filtered by index."""
        require_non_empty(index, "Index code must be provided")
        return await self.__get_securities_info(index=index)

    async def get_securities_info_by_board(self, board: Board) -> list[SecuritiesInfo]:
        """Get list of securities information filtered by board."""
        require_non_empty(board, "Board must be provided")
        return await self.__get_securities_info(board=board)

    # Implement securities summary when API is available
    async def __get_securities_summary(
        self, from_date: str, to_date: str,
        symbol: str | None = None, index: str | None = None,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[SecuritiesSummary]:
        """Get summary information for a specific security."""
        params = SecuritiesSummaryRequest(
            symbol=symbol, index=index, from_date=from_date, to_date=to_date,
            page=page, size=size
        ).to_dict()
        try:
            logger.debug(
                "Fetching securities summary for symbol %s, index %s, "
                "from %s to %s with params: %s",
                symbol, index, from_date, to_date, params
            )
            data = await self._rest.get(EP_DATA_SECURITIES_SUMMARY, params=params)
            logger.debug(
                "Received securities summary for symbol %s, index %s, from %s to %s: %s",
                symbol, index, from_date, to_date, data
            )
            return SecuritiesSummary.from_list(data.get("data", []))
        except Exception as exc:
            logger.error(
                "Unexpected error fetching securities summary for symbol %s, "
                "index %s, from %s to %s: %s",
                symbol, index, from_date, to_date, exc
            )
            raise APIError(f"Unexpected error fetching securities summary: {exc}") from exc

    async def get_securities_summary(self, symbol: str) -> list[SecuritiesSummary]:
        """Get summary information for a specific security."""
        require_non_empty(symbol, "Symbol must be provided")
        from_date = today_date_str()
        to_date = today_date_str()
        return await self.__get_securities_summary(
            symbol=symbol, from_date=from_date, to_date=to_date
        )

    async def get_securities_summary_historical(
        self, symbol: str, from_date: str, to_date: str
    ) -> list[SecuritiesSummary]:
        """Get historical summary information for securities filtered by date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return await self.__get_securities_summary(
            symbol=symbol, from_date=from_date, to_date=to_date
        )

    async def get_securities_summary_by_index(self, index: str) -> list[SecuritiesSummary]:
        """Get summary information for securities filtered by index."""
        require_non_empty(index, "Index code must be provided")
        from_date = today_date_str()
        to_date = today_date_str()
        return await self.__get_securities_summary(
            index=index, from_date=from_date, to_date=to_date
        )

    async def get_securities_summary_by_index_historical(
        self, index: str, from_date: str, to_date: str
    ) -> list[SecuritiesSummary]:
        """Get historical summary information for securities filtered by index and date range."""
        require_non_empty(index, "Index code must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return await self.__get_securities_summary(
            index=index, from_date=from_date, to_date=to_date
        )


class MarketDataService:
    """Synchronous market data: OHLC, index info, security info, FA, TA."""

    def __init__(self, rest_client: RestClient):
        self._rest = rest_client

    # TODO: Implement OHLC download when API is available
    def __download_ohlc(
        self,
        symbol: str,
        timeframe: Timeframe,
    ) -> dict:
        """Bulk-download market data."""
        raise NotImplementedError("OHLC download is not implemented yet")

    def download_ohlc_1minute(self, symbol: str) -> dict:
        """Download 1-minute OHLC data for a symbol."""
        return self.__download_ohlc(symbol, Timeframe.MINUTE_1)

    def download_ohlc_1day(self, symbol: str) -> dict:
        """Download 1-day OHLC data for a symbol."""
        return self.__download_ohlc(symbol, Timeframe.DAY_1)

    # Implement OHLC retrieval when API is available
    def __get_ohlc(
        self, symbol: str, from_date: str, to_date: str, timeframe: Timeframe,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get OHLC data for a symbol and timeframe."""
        params = OHLCRequest(
            symbol=symbol,
            from_date=from_date,
            to_date=to_date,
            timeframe=timeframe,
            page=page,
            size=size
        ).to_dict()
        try:
            logger.debug(
                "Fetching OHLC data for symbol %s, timeframe %s, from %s to %s",
                symbol, timeframe, from_date, to_date
            )
            data = self._rest.get(EP_DATA_OHLC, params=params)
            logger.debug(
                "Fetched OHLC data for symbol %s, timeframe %s, from %s to %s",
                symbol, timeframe, from_date, to_date
            )
            return OHLCData.from_list(data=data.get("data", []))
        except SSIError:
            logger.error(
                "Error fetching OHLC data for symbol %s, timeframe %s, from %s to %s",
                symbol, timeframe, from_date, to_date
            )
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error fetching OHLC data for symbol %s, timeframe %s, "
                "from %s to %s: %s",
                symbol, timeframe, from_date, to_date, exc
            )
            raise APIError(f"Unexpected error fetching OHLC data: {exc}") from exc

    def get_ohlc_1minute(self, symbol: str) -> list[OHLCData]:
        """Get 1-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        from_date = from_beginning_of_day()
        to_date = from_end_of_day()
        return self.__get_ohlc(
            symbol=symbol,
            from_date=from_date,
            to_date=to_date,
            timeframe=Timeframe.MINUTE_1,
            page=DEFAULT_PAGE,
            size=DEFAULT_SIZE
        )

    def get_ohlc_1minute_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 1-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MINUTE_1,
            page=page, size=size
        )

    def get_ohlc_3minute(self, symbol: str) -> list[OHLCData]:
        """Get 3-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        from_date = from_beginning_of_day()
        to_date = from_end_of_day()
        return self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MINUTE_3,
            page=DEFAULT_PAGE, size=DEFAULT_SIZE
        )

    def get_ohlc_3minute_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 3-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MINUTE_3,
            page=page, size=size
        )

    def get_ohlc_5minute(self, symbol: str) -> list[OHLCData]:
        """Get 5-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        from_date = from_beginning_of_day()
        to_date = from_end_of_day()
        return self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MINUTE_5,
            page=DEFAULT_PAGE, size=DEFAULT_SIZE
        )

    def get_ohlc_5minute_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 5-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MINUTE_5,
            page=page, size=size
        )

    def get_ohlc_15minute(self, symbol: str) -> list[OHLCData]:
        """Get 15-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        from_date = from_beginning_of_day()
        to_date = from_end_of_day()
        return self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MINUTE_15,
            page=DEFAULT_PAGE, size=DEFAULT_SIZE
        )

    def get_ohlc_15minute_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 15-minute OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MINUTE_15,
            page=page, size=size
        )

    def get_ohlc_1hour(self, symbol: str) -> list[OHLCData]:
        """Get 1-hour OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        from_date = from_beginning_of_day()
        to_date = from_end_of_day()
        return self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.HOUR_1,
            page=DEFAULT_PAGE, size=DEFAULT_SIZE
        )

    def get_ohlc_1hour_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 1-hour OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.HOUR_1,
            page=page, size=size
        )

    def get_ohlc_1day_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 1-day OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.DAY_1,
            page=page, size=size
        )

    def get_ohlc_1week_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 1-week OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.WEEK_1,
            page=page, size=size
        )

    def get_ohlc_1month_historical(
        self, symbol: str, from_date: str, to_date: str,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[OHLCData]:
        """Get historical 1-month OHLC data for a symbol and date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return self.__get_ohlc(
            symbol=symbol, from_date=from_date, to_date=to_date, timeframe=Timeframe.MONTH_1,
            page=page, size=size
        )

    # Implement index retrieval when API is available
    def __get_indexes(self, board: Board | None = None) -> list[MarketIndexes]:
        """Get list of market indices."""
        params = MarketIndexesRequest(board=board).to_dict()
        data: list = list()
        try:
            logger.debug(
                "Fetching market indexes for board %s with params: %s",
                board.value if board else None, params
            )
            data = self._rest.get(EP_DATA_INDEX_LIST, params=params)
            logger.debug(
                "Fetched market indexes for board %s: %s",
                board.value if board else None, data
            )
        except SSIError:
            logger.error(
                "Error fetching market indexes for board %s",
                board.value if board else None
            )
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error fetching market indexes for board %s: %s",
                board.value if board else None, exc
            )
            raise APIError(f"Unexpected error fetching market indexes: {exc}") from exc

        return MarketIndexes.from_list(data)

    def get_indexes(self) -> list[MarketIndexes]:
        """Get list of market indices."""
        return self.__get_indexes()

    def get_indexes_by_board(self, board: Board) -> list[MarketIndexes]:
        """Get list of market indices filtered by board."""
        require_non_empty(board, "Board must be provided")
        return self.__get_indexes(board=board)

    # Implement index summary when API is available
    def __get_index_summary(
        self, index: str | None = None, board: Board | None = None, trading_date: str | None = None
    ) -> list[MarketIndexSummary]:
        """Get summary information for a specific index."""
        params = MarketIndexSummaryRequest(
            index=index, board=board, trading_date=trading_date
        ).to_dict()
        try:
            logger.debug("Fetching index summary for %s", params)
            data = self._rest.get(EP_DATA_INDEX_SUMMARY, params=params)
            logger.debug("Received index summary data for %s: %s", params, data)
        except SSIError:
            logger.error(
                "Error fetching index summary for index %s, board %s, trading date %s",
                index, board.value if board else None, trading_date
            )
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error fetching index summary for index %s, board %s, "
                "trading date %s: %s",
                index, board.value if board else None, trading_date, exc
            )
            raise APIError(f"Unexpected error fetching index summary: {exc}") from exc
        return MarketIndexSummary.from_list(data)

    def get_index_summary(self, index: str) -> MarketIndexSummary | None:
        """Get summary information for a specific index."""
        require_non_empty(index, "Index code must be provided")
        index_summary = self.__get_index_summary(index=index)
        return index_summary[0] if index_summary else None

    def get_index_summary_historical(
        self, index: str, trading_date: str
    ) -> MarketIndexSummary | None:
        """Get historical summary information for a specific index on a given trading date."""
        require_non_empty(index, "Index code must be provided")
        require_non_empty(trading_date, "Trading date must be provided")
        index_summary = self.__get_index_summary(index=index, trading_date=trading_date)
        return index_summary[0] if index_summary else None

    def get_board_summary(self, board: Board) -> MarketIndexSummary:
        """Get summary information for a specific board."""
        require_non_empty(board, "Board must be provided")
        board_summary = self.__get_index_summary(board=board)
        return board_summary[0] if board_summary else None

    def get_board_summary_historical(
        self, board: Board, trading_date: str
    ) -> MarketIndexSummary | None:
        """Get historical summary information for a specific board on a given trading date."""
        require_non_empty(board, "Board must be provided")
        require_non_empty(trading_date, "Trading date must be provided")
        board_summary = self.__get_index_summary(board=board, trading_date=trading_date)
        return board_summary[0] if board_summary else None

    # Implement securities information when API is available
    def __get_securities_info(self,
        index: str | None = None, board: Board | None = None, symbol: str | None = None
    ) -> list[SecuritiesInfo]:
        """Get list of securities information."""
        params = SecuritiesInfoRequest(index=index, board=board, symbol=symbol).to_dict()
        try:
            logger.debug(
                "Fetching securities information for symbol %s, index %s, board %s with params: %s",
                symbol, index, board.value if isinstance(board, Board) else board, params
            )
            data = self._rest.get(EP_DATA_SECURITIES_BY_BOARD, params=params)
            logger.debug(
                "Received securities information for symbol %s, index %s, board %s: %s",
                symbol, index, board.value if isinstance(board, Board) else board, data
            )
            return SecuritiesInfo.from_list(data)
        except SSIError:
            logger.error(
                "Error fetching securities information for symbol %s, index %s, board %s",
                symbol, index, board.value if isinstance(board, Board) else board
            )
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error fetching securities information for symbol %s, "
                "index %s, board %s: %s",
                symbol, index, board.value if isinstance(board, Board) else board, exc
            )
            raise APIError(f"Unexpected error fetching securities information: {exc}") from exc

    def get_securities_info(self, symbol: str) -> SecuritiesInfo | None:
        """Get securities information for a symbol."""
        require_non_empty(symbol, "Symbol must be provided")
        securities_info = self.__get_securities_info(symbol=symbol)
        return securities_info[0] if securities_info else None

    def get_securities_info_by_index(self, index: str) -> list[SecuritiesInfo]:
        """Get list of securities information filtered by index."""
        require_non_empty(index, "Index code must be provided")
        return self.__get_securities_info(index=index)

    def get_securities_info_by_board(self, board: Board) -> list[SecuritiesInfo]:
        """Get list of securities information filtered by board."""
        require_non_empty(board, "Board must be provided")
        return self.__get_securities_info(board=board)

    # Implement securities summary when API is available
    def __get_securities_summary(
        self, from_date: str, to_date: str,
        symbol: str | None = None, index: str | None = None,
        page: int = DEFAULT_PAGE, size: int = DEFAULT_SIZE
    ) -> list[SecuritiesSummary]:
        """Get summary information for a specific security."""
        params = SecuritiesSummaryRequest(
            symbol=symbol, index=index, from_date=from_date, to_date=to_date,
            page=page, size=size
        ).to_dict()
        try:
            logger.debug(
                "Fetching securities summary for symbol %s, index %s, "
                "from %s to %s with params: %s",
                symbol, index, from_date, to_date, params
            )
            data = self._rest.get(EP_DATA_SECURITIES_SUMMARY, params=params)
            logger.debug(
                "Received securities summary for symbol %s, index %s, from %s to %s: %s",
                symbol, index, from_date, to_date, data
            )
            return SecuritiesSummary.from_list(data.get("data", []))
        except Exception as exc:
            logger.error(
                "Unexpected error fetching securities summary for symbol %s, "
                "index %s, from %s to %s: %s",
                symbol, index, from_date, to_date, exc
            )
            raise APIError(f"Unexpected error fetching securities summary: {exc}") from exc

    def get_securities_summary(self, symbol: str) -> list[SecuritiesSummary]:
        """Get summary information for a specific security."""
        require_non_empty(symbol, "Symbol must be provided")
        from_date = today_date_str()
        to_date = today_date_str()
        return self.__get_securities_summary(symbol=symbol, from_date=from_date, to_date=to_date)

    def get_securities_summary_historical(
        self, symbol: str, from_date: str, to_date: str
    ) -> list[SecuritiesSummary]:
        """Get historical summary information for securities filtered by date range."""
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return self.__get_securities_summary(symbol=symbol, from_date=from_date, to_date=to_date)

    def get_securities_summary_by_index(self, index: str) -> list[SecuritiesSummary]:
        """Get summary information for securities filtered by index."""
        require_non_empty(index, "Index code must be provided")
        from_date = today_date_str()
        to_date = today_date_str()
        return self.__get_securities_summary(index=index, from_date=from_date, to_date=to_date)

    def get_securities_summary_by_index_historical(
        self, index: str, from_date: str, to_date: str
    ) -> list[SecuritiesSummary]:
        """Get historical summary information for securities filtered by index and date range."""
        require_non_empty(index, "Index code must be provided")
        require_non_empty(from_date, "From date must be provided")
        require_non_empty(to_date, "To date must be provided")
        return self.__get_securities_summary(index=index, from_date=from_date, to_date=to_date)
