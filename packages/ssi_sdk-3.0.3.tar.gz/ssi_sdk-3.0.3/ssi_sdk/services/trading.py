"""Trading service (Order, Condition Order, Max Buy/Sell) — async and sync."""

from __future__ import annotations

import logging
from ssi_sdk.constant import EP_TRADING_ORDER, EP_TRADING_MAX_BUY_SELL
from ssi_sdk.enums import OrderSide, OrderType
from ssi_sdk.models import (
    PlaceOrderRequest,
    PlaceOrderResponse,
    ModifyOrderRequest,
    ModifyOrderResponse,
    CancelOrderRequest,
    CancelOrderResponse,
    MaxBuySellRequest,
    MaxBuySellResponse,
)
from ssi_sdk.transport.rest_client import AsyncRestClient, RestClient
from ssi_sdk.exceptions import APIError, SSIError
from ssi_sdk.utils import (
    require_empty,
    require_non_empty,
    require_positive,
    require_non_negative,
    sign,
    generate_request_id,
)

logger = logging.getLogger("ssi_sdk.services.trading")


class AsyncTradingService:
    """Async trading operations: place/cancel/modify orders."""

    def __init__(self, rest_client: AsyncRestClient):
        self._rest = rest_client

    # Place order methods
    async def __place_order(
        self, account_no: str, symbol: str, side: OrderSide,
        quantity: int, price: float, order_type: OrderType,
    ) -> PlaceOrderResponse:
        """Internal method to place an order."""
        require_non_empty(account_no, "Account number must be provided")
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(side, "Order side must be provided")
        require_non_empty(order_type, "Order type must be provided")
        order_request = PlaceOrderRequest(
            account_no=account_no,
            symbol=symbol,
            side=side,
            quantity=quantity,
            price=price,
            order_type=order_type,
            client_request_id=generate_request_id()
        ).to_str()
        signature = sign(order_request, self._rest.get_private_key())
        self._rest.set_signature_header(signature=signature)
        try:
            logger.debug('Placing order with request: %s', order_request)
            order_info = await self._rest.post(
                EP_TRADING_ORDER,
                content=order_request.encode('utf-8'),
                headers=self._rest.get_headers()
            )
            logger.debug("Order placed successfully: %s", order_info)
            return PlaceOrderResponse.from_dict(order_info)
        except SSIError as exc:
            logger.error(
                "Error placing order: %s | status_code=%s | response_body=%s",
                exc, exc.status_code, exc.response_body,
            )
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error placing order for symbol %s, side %s, quantity %d, price %f: %s",
                symbol, side.value, quantity, price, exc
            )
            raise APIError(f"Unexpected error placing order: {exc}") from exc

    async def place_order(
        self, account_no: str, symbol: str, side: OrderSide,
        quantity: int, price: float, order_type: OrderType
    ) -> PlaceOrderResponse:
        """Place a new order."""
        require_non_negative(price, "Price must be positive")
        return await self.__place_order(account_no, symbol, side, quantity, price, order_type)

    async def place_limit_order(
        self, account_no: str, symbol: str, side: OrderSide,
        quantity: int, price: float
    ) -> PlaceOrderResponse:
        """Place a limit order."""
        require_positive(price, "Price must be positive")
        return await self.place_order(account_no, symbol, side, quantity, price, OrderType.LO)

    async def place_market_order(
        self, account_no: str, symbol: str, side: OrderSide,
        quantity: int
    ) -> PlaceOrderResponse:
        """Place a market order."""
        return await self.place_order(
            account_no, symbol, side, quantity, price=0, order_type=OrderType.MTL
        )

    async def place_ato_order(
        self, account_no: str, symbol: str, side: OrderSide,
        quantity: int
    ) -> PlaceOrderResponse:
        """Place an at-the-open order."""
        return await self.place_order(
            account_no, symbol, side, quantity, price=0, order_type=OrderType.ATO
        )

    async def place_atc_order(
        self, account_no: str, symbol: str, side: OrderSide, quantity: int
    ) -> PlaceOrderResponse:
        """Place an at-the-close order."""
        return await self.place_order(
            account_no, symbol, side, quantity, price=0, order_type=OrderType.ATC
        )

    # Modify order methods
    async def __modify_order(
        self, account_no: str,
        order_id: str | None = None, client_request_id: str | None = None,
        price: float | None = None, quantity: int | None = None
    ) -> ModifyOrderResponse:
        """Internal method to modify an existing order."""
        require_non_empty(account_no, "Account number must be provided")
        if price is not None:
            require_non_negative(price, "New price must be positive")
            require_empty(quantity, "New quantity must not be provided when modifying price")
        if quantity is not None:
            require_positive(quantity, "New quantity must be positive")
            require_empty(price, "New price must not be provided when modifying quantity")
        modify_request = ModifyOrderRequest(
            account_no=account_no,
            quantity=quantity,
            price=price,
            order_id=order_id,
            client_request_id=client_request_id,
            client_modify_id=generate_request_id()
        ).to_str()
        signature = sign(modify_request, self._rest.get_private_key())
        self._rest.set_signature_header(signature=signature)
        try:
            logger.debug('Modifying order with request: %s', modify_request)
            order_info = await self._rest.put(
                EP_TRADING_ORDER,
                content=modify_request.encode('utf-8'),
                headers=self._rest.get_headers()
            )
            logger.debug("Order modified successfully: %s", order_info)
            return ModifyOrderResponse.from_dict(order_info)
        except SSIError as exc:
            logger.error(
                "Error modifying order: %s | status_code=%s | response_body=%s",
                exc, exc.status_code, exc.response_body,
            )
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error modifying order for account %s, order_id %s, "
                "client_request_id %s: %s",
                account_no, order_id, client_request_id, exc
            )
            raise APIError(f"Unexpected error modifying order: {exc}") from exc

    async def modify_order_price(
        self, account_no: str, client_request_id: str, price: float
    ) -> ModifyOrderResponse:
        """Modify the price of an existing order."""
        require_non_empty(price, "New price must be provided")
        return await self.__modify_order(
            account_no=account_no, client_request_id=client_request_id, price=price
        )

    async def modify_order_price_by_order_id(
        self, account_no: str, order_id: str, price: float,
    ) -> ModifyOrderResponse:
        """Modify the price of an existing order."""
        require_non_empty(price, "New price must be provided")
        return await self.__modify_order(
            account_no=account_no, order_id=order_id, price=price
        )

    async def modify_order_quantity(
        self, account_no: str, client_request_id: str, quantity: int
    ) -> ModifyOrderResponse:
        """Modify the quantity of an existing order."""
        require_non_empty(quantity, "New quantity must be provided")
        return await self.__modify_order(
            account_no=account_no, client_request_id=client_request_id, quantity=quantity
        )

    async def modify_order_quantity_by_order_id(
        self, account_no: str, order_id: str, quantity: int
    ) -> ModifyOrderResponse:
        """Modify the quantity of an existing order."""
        require_non_empty(quantity, "New quantity must be provided")
        return await self.__modify_order(
            account_no=account_no, order_id=order_id, quantity=quantity
        )

    # Cancel order methods
    async def __cancel_order(
        self,
        account_no: str, order_id: str | None = None, client_request_id: str | None = None
    ) -> CancelOrderResponse:
        """Internal method to cancel an existing order."""
        require_non_empty(account_no, "Account number must be provided")
        cancel_request = CancelOrderRequest(
            account_no=account_no,
            order_id=order_id,
            client_request_id=client_request_id,
            client_cancel_id=generate_request_id()
        ).to_str()
        signature = sign(cancel_request, self._rest.get_private_key())
        self._rest.set_signature_header(signature=signature)
        try:
            logger.debug('Canceling order with request: %s', cancel_request)
            order_info = await self._rest.delete(
                EP_TRADING_ORDER,
                content=cancel_request.encode('utf-8'),
                headers=self._rest.get_headers()
            )
            logger.debug("Order canceled successfully: %s", order_info)
            return CancelOrderResponse.from_dict(order_info)
        except SSIError as exc:
            logger.error(
                "Error canceling order: %s | status_code=%s | response_body=%s",
                exc, exc.status_code, exc.response_body,
            )
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error canceling order for account %s, order_id %s, "
                "client_request_id %s: %s",
                account_no, order_id, client_request_id, exc
            )
            raise APIError(f"Unexpected error canceling order: {exc}") from exc

    async def cancel_order(self, account_no: str, client_request_id: str) -> CancelOrderResponse:
        """Cancel an existing order using client request ID."""
        require_non_empty(client_request_id, "Client request ID must be provided")
        return await self.__cancel_order(
            account_no=account_no, client_request_id=client_request_id
        )

    async def cancel_order_by_order_id(self, account_no: str, order_id: str) -> CancelOrderResponse:
        """Cancel an existing order."""
        require_non_empty(order_id, "Order ID must be provided")
        return await self.__cancel_order(account_no=account_no, order_id=order_id)


    # Max Buy/Sell methods
    async def __get_max_buy_sell(
        self, account_no: str, symbol: str, price: int | float | None = None
    ) -> MaxBuySellResponse:
        """Internal method to get max buy/sell quantities."""
        require_non_empty(account_no, "Account number must be provided")
        require_non_empty(symbol, "Symbol must be provided")
        max_buy_sell_request = MaxBuySellRequest(
            account_no=account_no,
            symbol=symbol,
            price=price
        ).to_dict()
        logger.debug('Getting max buy/sell with request: %s', max_buy_sell_request)
        max_buy_sell_info = await self._rest.get(
            EP_TRADING_MAX_BUY_SELL,
            params=max_buy_sell_request,
            headers=self._rest.get_headers()
        )
        logger.debug("Max buy/sell retrieved successfully: %s", max_buy_sell_info)
        return MaxBuySellResponse.from_dict(max_buy_sell_info, symbol=symbol)


    async def get_max_buy_sell(
        self, account_no: str, symbol: str, price: int | float
    ) -> MaxBuySellResponse:
        """Get maximum buy/sell quantities for a given symbol."""
        require_positive(float(price), "Price must be positive")
        return await self.__get_max_buy_sell(account_no, symbol, price)

    async def get_max_buy_sell_at_market_price(
        self, account_no: str, symbol: str
    ) -> MaxBuySellResponse:
        """Get maximum buy/sell quantities at market price."""
        return await self.__get_max_buy_sell(account_no, symbol)


class TradingService:
    """Synchronous trading operations: place/cancel/modify orders."""

    def __init__(self, rest_client: RestClient):
        self._rest = rest_client

    # Place order methods
    def __place_order(
        self, account_no: str, symbol: str, side: OrderSide,
        quantity: int, price: float, order_type: OrderType,
    ) -> PlaceOrderResponse:
        """Internal method to place an order."""
        require_non_empty(account_no, "Account number must be provided")
        require_non_empty(symbol, "Symbol must be provided")
        require_non_empty(side, "Order side must be provided")
        require_non_empty(order_type, "Order type must be provided")
        order_request = PlaceOrderRequest(
            account_no=account_no,
            symbol=symbol,
            side=side,
            quantity=quantity,
            price=price,
            order_type=order_type,
            client_request_id=generate_request_id()
        ).to_str()
        signature = sign(order_request, self._rest.get_private_key())
        self._rest.set_signature_header(signature=signature)
        try:
            logger.debug('Placing order with request: %s', order_request)
            order_info =  self._rest.post(
                EP_TRADING_ORDER,
                content=order_request.encode('utf-8'),
                headers=self._rest.get_headers()
            )
            logger.debug("Order placed successfully: %s", order_info)
            return PlaceOrderResponse.from_dict(order_info)
        except SSIError as exc:
            logger.error(
                "Error placing order: %s | status_code=%s | response_body=%s",
                exc, exc.status_code, exc.response_body,
            )
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error placing order for symbol %s, side %s, quantity %d, price %f: %s",
                symbol, side.value, quantity, price, exc
            )
            raise APIError(f"Unexpected error placing order: {exc}") from exc


    def place_order(
        self, account_no: str, symbol: str, side: OrderSide,
        quantity: int, price: float, order_type: OrderType
    ) -> PlaceOrderResponse:
        """Place a new order."""
        require_non_negative(price, "Price must be positive")
        return self.__place_order(account_no, symbol, side, quantity, price, order_type)

    def place_limit_order(
        self, account_no: str, symbol: str, side: OrderSide,
        quantity: int, price: float
    ) -> PlaceOrderResponse:
        """Place a limit order."""
        require_positive(price, "Price must be positive")
        return self.place_order(account_no, symbol, side, quantity, price, OrderType.LO)

    def place_market_order(
        self, account_no: str, symbol: str, side: OrderSide,
        quantity: int
    ) -> PlaceOrderResponse:
        """Place a market order."""
        return self.place_order(
            account_no, symbol, side, quantity, price=0, order_type=OrderType.MTL
        )

    def place_ato_order(
        self, account_no: str, symbol: str, side: OrderSide,
        quantity: int
    ) -> PlaceOrderResponse:
        """Place an at-the-open order."""
        return self.place_order(
            account_no, symbol, side, quantity, price=0, order_type=OrderType.ATO
        )

    def place_atc_order(
        self, account_no: str, symbol: str, side: OrderSide, quantity: int
    ) -> PlaceOrderResponse:
        """Place an at-the-close order."""
        return self.place_order(
            account_no, symbol, side, quantity, price=0, order_type=OrderType.ATC
        )

    # Modify order methods
    def __modify_order(
        self, account_no: str,
        order_id: str | None = None, client_request_id: str | None = None,
        price: float | None = None, quantity: int | None = None
    ) -> ModifyOrderResponse:
        """Internal method to modify an existing order."""
        require_non_empty(account_no, "Account number must be provided")
        if price is not None:
            require_non_negative(price, "New price must be positive")
            require_empty(quantity, "New quantity must not be provided when modifying price")
        if quantity is not None:
            require_positive(quantity, "New quantity must be positive")
            require_empty(price, "New price must not be provided when modifying quantity")
        modify_request = ModifyOrderRequest(
            account_no=account_no,
            quantity=quantity,
            price=price,
            order_id=order_id,
            client_request_id=client_request_id,
            client_modify_id=generate_request_id()
        ).to_str()
        signature = sign(modify_request, self._rest.get_private_key())
        self._rest.set_signature_header(signature=signature)
        try:
            logger.debug('Modifying order with request: %s', modify_request)
            order_info =  self._rest.put(
                EP_TRADING_ORDER,
                content=modify_request.encode('utf-8'),
                headers=self._rest.get_headers()
            )
            logger.debug("Order modified successfully: %s", order_info)
            return ModifyOrderResponse.from_dict(order_info)
        except SSIError as exc:
            logger.error(
                "Error modifying order: %s | status_code=%s | response_body=%s",
                exc, exc.status_code, exc.response_body,
            )
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error modifying order with order_id %s, client_request_id %s: %s",
                order_id, client_request_id, exc
            )
            raise APIError(f"Unexpected error modifying order: {exc}") from exc

    def modify_order_price(
        self, account_no: str, client_request_id: str, price: float
    ) -> ModifyOrderResponse:
        """Modify the price of an existing order."""
        require_non_empty(price, "New price must be provided")
        return self.__modify_order(
            account_no=account_no, client_request_id=client_request_id, price=price
        )

    def modify_order_price_by_order_id(
        self, account_no: str, order_id: str, price: float,
    ) -> ModifyOrderResponse:
        """Modify the price of an existing order."""
        require_non_empty(price, "New price must be provided")
        return self.__modify_order(
            account_no=account_no, order_id=order_id, price=price
        )

    def modify_order_quantity(
        self, account_no: str, client_request_id: str, quantity: int
    ) -> ModifyOrderResponse:
        """Modify the quantity of an existing order."""
        require_non_empty(quantity, "New quantity must be provided")
        return self.__modify_order(
            account_no=account_no, client_request_id=client_request_id, quantity=quantity
        )

    def modify_order_quantity_by_order_id(
        self, account_no: str, order_id: str, quantity: int
    ) -> ModifyOrderResponse:
        """Modify the quantity of an existing order."""
        require_non_empty(quantity, "New quantity must be provided")
        return self.__modify_order(
            account_no=account_no, order_id=order_id, quantity=quantity
        )

    # Cancel order methods
    def __cancel_order(
        self,
        account_no: str, order_id: str | None = None, client_request_id: str | None = None
    ) -> CancelOrderResponse:
        """Internal method to cancel an existing order."""
        require_non_empty(account_no, "Account number must be provided")
        cancel_request = CancelOrderRequest(
            account_no=account_no,
            order_id=order_id,
            client_request_id=client_request_id,
            client_cancel_id=generate_request_id()
        ).to_str()
        signature = sign(cancel_request, self._rest.get_private_key())
        self._rest.set_signature_header(signature=signature)
        try:
            logger.debug('Canceling order with request: %s', cancel_request)
            order_info =  self._rest.delete(
                EP_TRADING_ORDER,
                content=cancel_request.encode('utf-8'),
                headers=self._rest.get_headers()
            )
            logger.debug("Order canceled successfully: %s", order_info)
            return CancelOrderResponse.from_dict(order_info)
        except SSIError as exc:
            logger.error(
                "Error canceling order: %s | status_code=%s | response_body=%s",
                exc, exc.status_code, exc.response_body,
            )
            raise
        except Exception as exc:
            logger.error(
                "Unexpected error canceling order with order_id %s, client_request_id %s: %s",
                order_id, client_request_id, exc
            )
            raise APIError(f"Unexpected error canceling order: {exc}") from exc

    def cancel_order(self, account_no: str, client_request_id: str) -> CancelOrderResponse:
        """Cancel an existing order using client request ID."""
        require_non_empty(client_request_id, "Client request ID must be provided")
        return self.__cancel_order(
            account_no=account_no, client_request_id=client_request_id
        )

    def cancel_order_by_order_id(self, account_no: str, order_id: str) -> CancelOrderResponse:
        """Cancel an existing order."""
        require_non_empty(order_id, "Order ID must be provided")
        return self.__cancel_order(account_no=account_no, order_id=order_id)


    # Max Buy/Sell methods
    def __get_max_buy_sell(
        self, account_no: str, symbol: str, price: int | float | None = None
    ) -> MaxBuySellResponse:
        """Internal method to get max buy/sell quantities."""
        require_non_empty(account_no, "Account number must be provided")
        require_non_empty(symbol, "Symbol must be provided")
        max_buy_sell_request = MaxBuySellRequest(
            account_no=account_no,
            symbol=symbol,
            price=price
        ).to_dict()
        logger.debug('Getting max buy/sell with request: %s', max_buy_sell_request)
        max_buy_sell_info = self._rest.get(
            EP_TRADING_MAX_BUY_SELL,
            params=max_buy_sell_request,
            headers=self._rest.get_headers()
        )
        logger.debug("Max buy/sell retrieved successfully: %s", max_buy_sell_info)
        return MaxBuySellResponse.from_dict(max_buy_sell_info, symbol=symbol)


    def get_max_buy_sell(
        self, account_no: str, symbol: str, price: int | float
    ) -> MaxBuySellResponse:
        """Get maximum buy/sell quantities for a given symbol."""
        require_positive(float(price), "Price must be positive")
        return self.__get_max_buy_sell(account_no, symbol, price)

    def get_max_buy_sell_at_market_price(
        self, account_no: str, symbol: str
    ) -> MaxBuySellResponse:
        """Get maximum buy/sell quantities at market price."""
        return self.__get_max_buy_sell(account_no, symbol)
