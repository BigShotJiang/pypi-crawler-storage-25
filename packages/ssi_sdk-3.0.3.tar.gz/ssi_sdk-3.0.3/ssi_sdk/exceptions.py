"""Custom exceptions for SSI SDK."""


class APIResponse:
    """Represents an API response."""

    def __init__(
        self,
        status_code: int,
        response_body: dict | None = None,
        headers: dict | None = None,
    ):
        self.status_code = status_code
        self.response_body = response_body
        self.headers = headers or {}


class SSIError(Exception):
    """Base exception for all SSI SDK errors."""

    def __init__(
        self,
        message: str = "",
        code: str | None = None,
        status_code: int | None = None,
        response_body: dict | None = None,
        headers: dict | None = None,
    ):
        self.message = message
        self.code = code
        self.status_code = status_code
        self.response_body = response_body
        self.headers = headers or {}
        super().__init__(self.message)


class AuthenticationError(SSIError):
    """Raised when authentication fails (invalid credentials, expired token, etc.)."""


class APIError(SSIError):
    """Raised when the SSI API returns an error response."""

    def __init__(
        self,
        message: str = "",
        code: str | None = None,
        status_code: int | None = None,
        response_body: dict | None = None,
    ):
        self.status_code = status_code
        self.response_body = response_body
        super().__init__(message, code)


class WebSocketError(SSIError):
    """Raised when a WebSocket connection or communication error occurs."""


class ValidationError(SSIError):
    """Raised when input validation fails."""


class RateLimitError(SSIError):
    """Raised when API rate limit is exceeded."""

    def __init__(self, message: str = "", retry_after: float | None = None):
        self.retry_after = retry_after
        super().__init__(message, code="RATE_LIMITED")
