"""HTTP status code enums for SSI SDK."""

from enum import IntEnum


class HTTPStatus(IntEnum):
    """Standard HTTP status codes used by the SSI API."""

    # 2xx Success
    OK = 200
    NO_CONTENT = 204

    # 4xx Client Errors
    BAD_REQUEST = 400
    UNAUTHORIZED = 401
    FORBIDDEN = 403
    NOT_FOUND = 404
    UNPROCESSABLE_ENTITY = 422
    TOO_MANY_REQUESTS = 429

    # 5xx Server Errors
    INTERNAL_SERVER_ERROR = 500
    BAD_GATEWAY = 502
    SERVICE_UNAVAILABLE = 503
    GATEWAY_TIMEOUT = 504

    @property
    def is_auth_error(self) -> bool:
        """Return True if this status indicates an authentication/authorization failure."""
        return self in (HTTPStatus.UNAUTHORIZED, HTTPStatus.FORBIDDEN)

    @property
    def is_rate_limit(self) -> bool:
        """Return True if this status indicates rate limiting."""
        return self == HTTPStatus.TOO_MANY_REQUESTS

    @property
    def is_client_error(self) -> bool:
        """Return True if this is a 4xx client error."""
        return 400 <= self < 500

    @property
    def is_server_error(self) -> bool:
        """Return True if this is a 5xx server error."""
        return self >= 500
