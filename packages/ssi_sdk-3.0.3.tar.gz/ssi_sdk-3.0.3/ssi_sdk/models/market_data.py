"""Market data models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ssi_sdk.enums import Timeframe, Board
from ssi_sdk.utils import to_float, to_int, to_number
from ssi_sdk.constant import DEFAULT_PAGE, DEFAULT_SIZE

@dataclass
class DownloadDataRequest:
    """Bulk download data request."""

    symbol: str = ""
    timeframe: Timeframe = Timeframe.DAY_1

    def to_dict(self) -> dict:
        """Convert the DownloadDataRequest to a dictionary for API requests."""
        return {
            "symbol": self.symbol,
            "timeFrame": self.timeframe.value,
        }

@dataclass
class DownloadData:
    """Bulk download data result."""

    data: list[dict[str, Any]] = field(default_factory=list)
    total_count: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> DownloadData:
        """Create a DownloadData instance from a dictionary."""
        items = data.get("data", [])
        return cls(
            data=items,
            total_count=data.get("totalCount", len(items)),
        )


@dataclass
class OHLCRequest:
    """OHLC data request."""

    symbol: str
    from_date: str
    to_date: str
    timeframe: Timeframe
    page: int = DEFAULT_PAGE
    size: int = DEFAULT_SIZE

    def to_dict(self) -> dict:
        """Convert the OHLCRequest to a dictionary for API requests."""
        return {
            "symbol": self.symbol,
            "from": self.from_date,
            "to": self.to_date,
            "timeFrame": self.timeframe.value,
            "pageIndex": self.page,
            "pageSize": self.size,
        }

@dataclass
class OHLCData:
    """OHLC data result."""

    symbol: str
    trading_date: str
    open_price: float | int
    high_price: float | int
    low_price: float | int
    close_price: float | int
    volume: int
    value: float | int

    @classmethod
    def from_list(cls, data: list[dict]) -> list[OHLCData]:
        """Create a list of OHLCData instances from a list of dictionaries."""
        return [
            cls(
                symbol=item.get("symbol", ""),
                trading_date=item.get("tradingDate", ""),
                open_price=to_number(item.get("open", 0.0)),
                high_price=to_number(item.get("high", 0.0)),
                low_price=to_number(item.get("low", 0.0)),
                close_price=to_number(item.get("close", 0.0)),
                volume=to_int(item.get("volume", 0)),
                value=to_number(item.get("value", 0.0)),
            )
            for item in data
        ]


@dataclass
class MarketIndexesRequest:
    """Market index information request."""

    board: Board | None = None

    def to_dict(self) -> dict:
        """Convert the MarketIndexesRequest to a dictionary for API requests."""
        if self.board is None:
            return {}
        return {
            "board": self.board.value,
        }

@dataclass
class MarketIndexes:
    """Market indices information."""

    index: str
    index_name: str
    board: Board | None = None

    @classmethod
    def from_list(cls, data: list[dict]) -> list[MarketIndexes]:
        """Create a list of MarketIndexes instances from a list of dictionaries."""
        return [
            cls(
                index=item.get("index", ""),
                index_name=item.get("indexName", ""),
                board=Board(item.get("board", "").upper()) if item.get("board") else None,
            )
            for item in data
        ]


@dataclass
class MarketIndexSummaryRequest:
    """Market index summary request."""

    index: str | None = None
    board: Board | None = None
    trading_date: str | None = None

    def to_dict(self) -> dict:
        """Convert the MarketIndexSummaryRequest to a dictionary for API requests."""
        data = {}
        if self.index is not None:
            data["index"] = self.index
        if self.board is not None:
            data["board"] = self.board.value
        if self.trading_date is not None:
            data["tradingDate"] = self.trading_date
        return data

@dataclass
class MarketIndexSummary:
    """Market index summary information."""
    index: str
    board: str
    trading_date: str
    total_trade: int
    total_trade_value: float
    total_match: int
    total_match_value: float
    total_deal: int
    total_deal_value: float
    index_change: float
    index_change_percent: float
    index_value: float
    total_advance_stock: int
    total_decline_stock: int
    total_steady_stock: int
    total_ceiling_stock: int
    total_floor_stock: int
    total_prop_buy: int
    total_prop_buy_value: float
    total_prop_sell: int
    total_prop_sell_value: float

    @classmethod
    def from_list(cls, data: list[dict]) -> list[MarketIndexSummary]:
        """Create a list of MarketIndexSummary instances from a list of dictionaries."""
        return [
            cls(
                index=item.get("index", ""),
                board=item.get("board", ""),
                trading_date=item.get("tradingDate", ""),
                total_trade=to_int(item.get("totalTrade", 0)),
                total_trade_value=to_float(item.get("totalTradeValue", 0.0)),
                total_match=to_int(item.get("totalMatch", 0)),
                total_match_value=to_float(item.get("totalMatchValue", 0.0)),
                total_deal=to_int(item.get("totalDeal", 0)),
                total_deal_value=to_float(item.get("totalDealValue", 0.0)),
                index_change=to_float(item.get("indexChange", 0.0)),
                index_change_percent=to_float(item.get("indexChangePercentage", 0.0)),
                index_value=to_float(item.get("indexValue", 0.0)),
                total_advance_stock=to_int(item.get("totalAdvanceStock", 0)),
                total_decline_stock=to_int(item.get("totalDeclineStock", 0)),
                total_steady_stock=to_int(item.get("totalNoChangeStock", 0)),
                total_ceiling_stock=to_int(item.get("totalCeilingStock", 0)),
                total_floor_stock=to_int(item.get("totalFloorStock", 0)),
                total_prop_buy=to_int(item.get("totalPropBuy", 0)),
                total_prop_buy_value=to_float(item.get("totalPropBuyValue", 0.0)),
                total_prop_sell=to_int(item.get("totalPropSell", 0)),
                total_prop_sell_value=to_float(item.get("totalPropSellValue", 0.0)),
            )
            for item in data
        ]


@dataclass
class SecuritiesInfoRequest:
    """Securities information request."""

    symbol: str | None = None
    board: Board | None = None
    index: str | None = None

    def to_dict(self) -> dict:
        """Convert the SecuritiesInfoRequest to a dictionary for API requests."""
        data = {}
        if self.symbol is not None:
            data["symbol"] = self.symbol
        if self.board is not None:
            data["board"] = self.board.value
        if self.index is not None:
            data["index"] = self.index
        return data

@dataclass
class SecuritiesInfo:
    """Securities information."""

    symbol: str
    board: Board | None = None
    index: str | None = None
    symbol_name_vi: str | None = None
    symbol_name_en: str | None = None
    lot_size: int | None = None
    maturity_date: str | None = None
    first_trading_date: str | None = None
    last_trading_date: str | None = None
    cw_underlying_symbol: str | None = None
    cw_exercise_price: float | None = None
    cw_execution_ratio: float | None = None
    listed_shares: int | None = None
    icb_code: str | None = None
    icb_name: str | None = None
    i_index: float | None = None
    i_nav: float | None = None

    @classmethod
    def from_list(cls, data: list[dict]) -> list[SecuritiesInfo]:
        """Create a list of SecuritiesInfo instances from a list of dictionaries."""
        return [
            cls(
                symbol=item.get("symbol", ""),
                board=Board(item.get("board", "").upper()) if item.get("board") else None,
                index=item.get("index"),
                symbol_name_vi=item.get("symbolNameVi"),
                symbol_name_en=item.get("symbolNameEn"),
                lot_size=to_int(item.get("lotSize", 0)),
                maturity_date=item.get("maturityDate"),
                first_trading_date=item.get("firstTradingDate"),
                last_trading_date=item.get("lastTradingDate"),
                cw_underlying_symbol=item.get("cwUnderlyingSymbol"),
                cw_exercise_price=to_float(item.get("cwExercisePrice", 0.0)),
                cw_execution_ratio=to_float(item.get("cwExecutionRatio", 0.0)),
                listed_shares=to_int(item.get("listedShares", 0)),
                icb_code=item.get("icbCode"),
                icb_name=item.get("icbName"),
                i_index=to_float(item.get("iIndex", 0.0)),
                i_nav=to_float(item.get("iNav", 0.0)),
            )
            for item in data
        ]

@dataclass
class SecuritiesSummaryRequest:
    """Securities summary request."""

    from_date: str
    to_date: str
    symbol: str | None = None
    index: str | None = None
    page: int = DEFAULT_PAGE
    size: int = DEFAULT_SIZE

    def to_dict(self) -> dict:
        """Convert the SecuritiesSummaryRequest to a dictionary for API requests."""
        data = {
            "from": self.from_date,
            "to": self.to_date,
            "pageIndex": self.page,
            "pageSize": self.size,
        }
        if self.symbol is not None:
            data["symbol"] = self.symbol
        if self.index is not None:
            data["index"] = self.index
        return data

@dataclass
class SecuritiesSummary:
    """Securities summary information."""

    symbol: str
    trading_date: str
    price_change: float
    price_change_percent: float
    open_price: float
    high_price: float
    low_price: float
    close_price: float
    average_price: float
    total_match: int
    total_match_value: float
    total_buy: int
    total_trade_buy: float
    total_sell: int
    total_trade_sell: float

    @classmethod
    def from_list(cls, data: list[dict]) -> list[SecuritiesSummary]:
        """Create a list of SecuritiesSummary instances from a list of dictionaries."""
        return [
            cls(
                symbol=item.get("symbol", ""),
                trading_date=item.get("tradingDate", ""),
                price_change=to_number(item.get("priceChange", 0.0)),
                price_change_percent=to_number(item.get("priceChangePercentage", 0.0)),
                open_price=to_number(item.get("open", 0.0)),
                high_price=to_number(item.get("high", 0.0)),
                low_price=to_number(item.get("low", 0.0)),
                close_price=to_number(item.get("close", 0.0)),
                average_price=to_number(item.get("average", 0.0)),
                total_match=to_int(item.get("totalMatch", 0)),
                total_match_value=to_number(item.get("totalMatchValue", 0.0)),
                total_buy=to_int(item.get("totalBuy", 0)),
                total_trade_buy=to_number(item.get("totalTradeBuy", 0.0)),
                total_sell=to_int(item.get("totalSell", 0)),
                total_trade_sell=to_number(item.get("totalTradeSell", 0.0)),
            )
            for item in data
        ]
