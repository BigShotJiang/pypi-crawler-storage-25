"""Data models for SSI SDK."""

from ssi_sdk.models.account import Account
from ssi_sdk.models.portfolio import (
    AccountBalanceRequest,
    AccountBalance,
    EquityAccountBalance,
    DerivativeAccountBalance,
    PositionsRequest,
    Position,
    DerivativePosition,
    AllDerivativePosition,
    EquityPosition,
    PPMMRRequest,
    PPMMR,
    EquityPPMMR,
    DerivativePPMMR,

    OrderBookRequest,
    OrderBook,
    Order,
)
from ssi_sdk.models.auth import Token, TokenRequest, OTPRequest, RefreshTokenRequest
from ssi_sdk.models.market_data import (
    DownloadData,
    DownloadDataRequest,

    OHLCRequest,
    OHLCData,

    MarketIndexes,
    MarketIndexesRequest,

    MarketIndexSummaryRequest,
    MarketIndexSummary,

    SecuritiesInfoRequest,
    SecuritiesInfo,

    SecuritiesSummaryRequest,
    SecuritiesSummary,
)
from ssi_sdk.models.trading import (
    PlaceOrderRequest,
    PlaceOrderResponse,
    ModifyOrderRequest,
    ModifyOrderResponse,
    CancelOrderRequest,
    CancelOrderResponse,
    MaxBuySellRequest,
    MaxBuySellResponse,
)
from ssi_sdk.models.streaming import (
    RequestMessage,

    HeartbeatMessage,

    ForeignRoomMessage,
    MarketStatusMessage,
    OddLotMessage,
    PutMessage,
    QuoteMessage,
    TradeMessage,
    IntervalMessage,

    OrderStatusMessage,
    PortfolioMessage,

)

__all__ = [
    # -------------------------------------------------------------------------
    # Authentication models
    # -------------------------------------------------------------------------
    "Token",
    "TokenRequest",
    "OTPRequest",
    "RefreshTokenRequest",
    # -------------------------------------------------------------------------
    # Account models
    # -------------------------------------------------------------------------
    "Account",
    # -------------------------------------------------------------------------
    # Market data models
    # -------------------------------------------------------------------------
    "DownloadData",
    "DownloadDataRequest",
    "OHLCRequest",
    "OHLCData",
    "MarketIndexes",
    "MarketIndexesRequest",
    "MarketIndexSummary",
    "MarketIndexSummaryRequest",
    "SecuritiesInfo",
    "SecuritiesInfoRequest",
    "SecuritiesSummary",
    "SecuritiesSummaryRequest",
    # -------------------------------------------------------------------------
    # Portfolio models
    # -------------------------------------------------------------------------
    "AccountBalanceRequest",
    "AccountBalance",
    "EquityAccountBalance",
    "DerivativeAccountBalance",
    "PositionsRequest",
    "Position",
    "DerivativePosition",
    "AllDerivativePosition",
    "EquityPosition",
    # -------------------------------------------------------------------------
    # PPMMR models
    # -------------------------------------------------------------------------
    "PPMMRRequest",
    "PPMMR",
    "EquityPPMMR",
    "DerivativePPMMR",
    # -------------------------------------------------------------------------
    # Trading models
    # -------------------------------------------------------------------------
    "PlaceOrderRequest",
    "PlaceOrderResponse",
    "ModifyOrderRequest",
    "ModifyOrderResponse",
    "CancelOrderRequest",
    "CancelOrderResponse",
    "MaxBuySellRequest",
    "MaxBuySellResponse",
    # -------------------------------------------------------------------------
    # Streaming models
    # -------------------------------------------------------------------------
    "RequestMessage",
    "HeartbeatMessage",
    "TradeMessage",
    "QuoteMessage",
    "IntervalMessage",
    "MarketStatusMessage",
    "ForeignRoomMessage",
    "PutMessage",
    "OddLotMessage",
    "OrderStatusMessage",
    "PortfolioMessage",
    # -------------------------------------------------------------------------
    # Order book models (not implemented yet)
    # -------------------------------------------------------------------------
    "OrderBookRequest",
    "OrderBook",
    "Order",
]
