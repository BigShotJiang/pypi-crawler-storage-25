"""Trading data models."""

from __future__ import annotations

import json
from dataclasses import dataclass

from ssi_sdk.enums import OrderType, OrderSide, OrderStatus
from ssi_sdk._version import __version__

@dataclass
class PlaceOrderRequest:
    """ Payload for placing a new order. """

    account_no: str = None
    symbol: str = None
    side: OrderSide = OrderSide.BUY
    quantity: int = None
    price: float = None
    order_type: OrderType = OrderType.LO
    client_request_id: str = None
    device_id: str = 'A1:B2:C3:D4:E5:F6'
    user_agent: str = 'SSI Python SDK/' + __version__

    def to_dict(self) -> dict:
        """ Convert the OrderRequest to a dictionary for API requests."""
        result = {
            'accountNo': self.account_no,
            'symbol': self.symbol,
            'side': self.side.value,
            'quantity': self.quantity,
            'price': f'{self.price}',
            'orderType': self.order_type.value,
            'clientRequestId': self.client_request_id,
            'deviceId': self.device_id,
            'userAgent': self.user_agent,
        }
        return result

    def to_str(self) -> str:
        """ Convert the OrderRequest to a JSON string for API requests."""
        return json.dumps(self.to_dict())

@dataclass
class PlaceOrderResponse:
    """ Response for placing a new order. """

    order_id: str
    client_request_id: str
    status: OrderStatus

    @classmethod
    def from_dict(cls, data: dict) -> PlaceOrderResponse:
        """ Create a PlaceOrderResponse instance from a dictionary."""
        return cls(
            order_id=data.get('orderId', ''),
            client_request_id=data.get('clientRequestId', ''),
            status=OrderStatus(data.get('orderStatus', '')),
        )

@dataclass
class ModifyOrderRequest:
    """ Modify order payload."""

    account_no: str = None
    quantity: int = None
    price: float = None
    order_id: str = None
    client_modify_id: str = None
    client_request_id: str = None
    device_id: str = 'A1:B2:C3:D4:E5:F6'
    user_agent: str = 'SSI Python SDK/' + __version__

    def to_dict(self) -> dict:
        """ Convert the OrderRequest to a dictionary for API requests."""
        result = {
            'accountNo': self.account_no,
            'clientModifyId': self.client_modify_id,
            'deviceId': self.device_id,
            'userAgent': self.user_agent
        }
        if self.order_id is not None:
            result['orderId'] = self.order_id
        if self.client_request_id is not None:
            result['clientRequestId'] = self.client_request_id
        if self.quantity is not None:
            result['quantity'] = self.quantity
        if self.price is not None:
            result['price'] = f'{self.price}'
        return result

    def to_str(self) -> str:
        """ Convert the OrderRequest to a JSON string for API requests."""
        return json.dumps(self.to_dict())

@dataclass
class ModifyOrderResponse:
    """ Response for modifying an order. """

    client_modify_id: str
    order_id: str
    client_request_id: str
    status: OrderStatus

    @classmethod
    def from_dict(cls, data: dict) -> ModifyOrderResponse:
        """ Create a ModifyOrderResponse instance from a dictionary."""
        return cls(
            client_modify_id=data.get('clientModifyId', ''),
            order_id=data.get('orderId', ''),
            client_request_id=data.get('clientRequestId', ''),
            status=OrderStatus(data.get('orderStatus', '')),
        )

@dataclass
class CancelOrderRequest:
    """ Cancel order payload."""

    account_no: str = None
    order_id: str = None
    client_request_id: str = None
    client_cancel_id: str = None
    device_id: str = 'A1:B2:C3:D4:E5:F6'
    user_agent: str = 'SSI Python SDK/' + __version__

    def to_dict(self) -> dict:
        """ Convert the OrderRequest to a dictionary for API requests."""
        result = {
            'accountNo': self.account_no,
            'clientCancelId': self.client_cancel_id,
            'deviceId': self.device_id,
            'userAgent': self.user_agent
        }
        if self.order_id is not None:
            result['orderId'] = self.order_id
        if self.client_cancel_id is not None:
            result['clientRequestId'] = self.client_request_id
        return result

    def to_str(self) -> str:
        """ Convert the OrderRequest to a JSON string for API requests."""
        return json.dumps(self.to_dict())

@dataclass
class CancelOrderResponse:
    """ Response for canceling an order. """

    client_cancel_id: str
    order_id: str
    client_request_id: str
    status: OrderStatus

    @classmethod
    def from_dict(cls, data: dict) -> CancelOrderResponse:
        """ Create a CancelOrderResponse instance from a dictionary."""
        try:
            order_status = OrderStatus(data.get('orderStatus', ''))
        except ValueError:
            order_status = data.get('orderStatus', '')
        return cls(
            client_cancel_id=data.get('clientCancelId', ''),
            order_id=data.get('orderId', ''),
            client_request_id=data.get('clientRequestId', ''),
            status=order_status,
        )
@dataclass
class MaxBuySellRequest:
    """ Payload for max buy/sell request."""

    account_no: str = None
    symbol: str = None
    price: int | float = 0

    def to_dict(self) -> dict:
        """ Convert the MaxBuySellRequest to a dictionary for API requests."""
        result = {
            'accountNo': self.account_no,
            'symbol': self.symbol.upper(),
        }
        if self.price is not None:
            result['price'] = f'{self.price}'
        return result

@dataclass
class MaxBuySellResponse:
    """ Response for max buy/sell request."""

    account_no: str
    symbol: str
    max_buy_quantity: int
    max_sell_quantity: int
    margin_ratio: str
    purchase_power: str

    @classmethod
    def from_dict(cls, data: dict, symbol: str) -> MaxBuySellResponse:
        """ Create a MaxBuySellResponse instance from a dictionary."""
        return cls(
            account_no=data.get('accountNo', ''),
            symbol=symbol.upper(),
            max_buy_quantity=data.get('maxBuyQty', 0),
            max_sell_quantity=data.get('maxSellQty', 0),
            margin_ratio=data.get('marginRatio', ''),
            purchase_power=data.get('purchasePower', '')
        )
