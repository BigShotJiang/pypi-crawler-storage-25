"""Serializer utility supporting JSON and binary formats."""

from __future__ import annotations

import json
from typing import Any


class Serializer:
    """Handles serialization/deserialization of data in various formats."""

    @staticmethod
    def to_json(data: Any) -> str:
        """Serialize data to JSON string."""
        return json.dumps(data, default=str, ensure_ascii=False)

    @staticmethod
    def from_json(data: str | bytes) -> Any:
        """Deserialize JSON string to Python object."""
        return json.loads(data)

    @staticmethod
    def to_bytes(data: Any) -> bytes:
        """Serialize data to bytes (JSON-encoded UTF-8)."""
        return json.dumps(data, default=str, ensure_ascii=False).encode("utf-8")

    @staticmethod
    def from_bytes(data: bytes) -> Any:
        """Deserialize bytes to Python object."""
        return json.loads(data.decode("utf-8"))
