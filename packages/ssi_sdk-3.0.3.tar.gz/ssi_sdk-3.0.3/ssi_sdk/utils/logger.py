"""Logging utility for SSI SDK."""

from __future__ import annotations

import logging
import sys


def get_logger(name: str = "ssi_sdk", level: str = "INFO") -> logging.Logger:
    """Get a configured logger instance.

    Args:
        name: Logger name.
        level: Logging level string.

    Returns:
        Configured logger.
    """
    logger = logging.getLogger(name)

    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            "%(asctime)s %(levelname)s [%(name)s]: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    return logger
