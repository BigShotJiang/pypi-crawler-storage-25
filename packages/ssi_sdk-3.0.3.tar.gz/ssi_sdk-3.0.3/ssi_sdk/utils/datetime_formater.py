"""Datetime formatter utilities."""
from datetime import datetime

def convert_to_datetime_str(date: datetime) -> str:
    """Convert a datetime object to a date string in 'YYYY/MM/DD HH:MM:SS' format."""
    return date.strftime("%Y/%m/%d %H:%M:%S")
def convert_to_datetime(date_str: str) -> datetime:
    """Convert a date string in 'YYYY/MM/DD HH:MM:SS' format to a datetime object."""
    return datetime.strptime(date_str, "%Y/%m/%d %H:%M:%S")

def today_date_str() -> str:
    """Get today's date as a string in 'YYYY/MM/DD' format."""
    return datetime.today().strftime("%Y/%m/%d")

def from_beginning_of_day() -> str:
    """Get the date string for the beginning of the current day."""
    return datetime.today().strftime("%Y/%m/%d 00:00:00")

def from_end_of_day() -> str:
    """Get the date string for the end of the current day."""
    return datetime.today().strftime("%Y/%m/%d 23:59:59")
