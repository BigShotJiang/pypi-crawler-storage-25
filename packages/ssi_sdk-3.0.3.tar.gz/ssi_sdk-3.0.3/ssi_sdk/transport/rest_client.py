"""REST client for SSI API (async and sync)."""

from __future__ import annotations

import logging
from typing import Any

import httpx

from ssi_sdk.config import Config
from ssi_sdk.constant import (
    AUTH_SCHEME_BEARER,
    CONTENT_TYPE_JSON,
    HEADER_ACCEPT,
    HEADER_AUTHORIZATION,
    HEADER_CONTENT_TYPE,
    HEADER_SIGNATURE,
    HEADER_RETRY_AFTER,
)
from ssi_sdk.enums import HTTPStatus
from ssi_sdk.exceptions import APIError, AuthenticationError, RateLimitError
from ssi_sdk.utils.retry import RateLimiter, retry_async, retry_sync

logger = logging.getLogger("ssi_sdk.transport.rest")


def _handle_response(response: httpx.Response) -> dict[str, Any]:
    """Parse and validate an HTTP response."""
    logger.debug("Received response: %s %s", response.status_code, response.text)
    if response.status_code in (HTTPStatus.UNAUTHORIZED, HTTPStatus.FORBIDDEN):
        body = None
        try:
            body = response.json()
        except Exception:  # pylint: disable=broad-exception-caught
            pass
        raise AuthenticationError(
            f"Authentication failed: {response.status_code}",
            code=str(response.status_code),
            status_code=response.status_code,
            response_body=body,
        )

    if response.status_code == HTTPStatus.TOO_MANY_REQUESTS:
        retry_after = response.headers.get(HEADER_RETRY_AFTER)
        raise RateLimitError(
            "Rate limit exceeded",
            retry_after=float(retry_after) if retry_after else None,
        )

    if response.status_code >= HTTPStatus.BAD_REQUEST:
        body = None
        try:
            body = response.json()
        except Exception:  # pylint: disable=broad-exception-caught
            pass
        raise APIError(
            message=f"API error: {response.status_code}",
            code=str(response.status_code),
            status_code=response.status_code,
            response_body=body,
        )

    if response.status_code == HTTPStatus.NO_CONTENT:
        return {}

    return response.json()


class AsyncRestClient:
    """Async HTTP client for SSI REST API."""

    def __init__(self, config: Config):
        self._config = config
        self._rate_limiter = RateLimiter(config.rate_limit_per_second)
        self._client: httpx.AsyncClient | None = None
        self._headers: dict = {
            HEADER_CONTENT_TYPE: CONTENT_TYPE_JSON,
            HEADER_ACCEPT: CONTENT_TYPE_JSON,
        }

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self._config.api_url,
                timeout=self._config.timeout,
                headers=self._headers,
                proxy=self._config.proxy,
            )
        return self._client

    def get_private_key(self) -> str:
        """Helper to get the private key for signing requests."""
        return self._config.private_key

    def set_auth_header(self, token: str) -> None:
        """Update the authorization header with a bearer token."""
        self._headers[HEADER_AUTHORIZATION] = f"{AUTH_SCHEME_BEARER}{token}"

        if self._client and not self._client.is_closed:
            self._client = None

    def set_signature_header(self, signature: str) -> None:
        """Update the signature header for request signing."""
        self._headers[HEADER_SIGNATURE] = signature
        logger.debug("Signature header set: %s", self._headers)
        if self._client and not self._client.is_closed:
            self._client = None

    def get_headers(self) -> dict[str, str]:
        """Get the current headers (for debugging)."""
        return self._headers

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
        content: str | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Make an authenticated async HTTP request."""
        await self._rate_limiter.async_acquire()

        async def _do_request() -> dict[str, Any]:
            client = await self._get_client()
            response = await client.request(
                method,
                path,
                params=params,
                json=json_body,
                content=content,
                headers=headers,
            )
            return _handle_response(response)

        return await retry_async(
            _do_request,
            max_retries=self._config.max_retries,
            delay=self._config.retry_delay,
        )

    async def get(self, path: str, **kwargs: Any) -> dict[str, Any]:
        """Send a GET request."""
        return await self.request("GET", path, **kwargs)

    async def post(self, path: str, **kwargs: Any) -> dict[str, Any]:
        """Send a POST request."""
        return await self.request("POST", path, **kwargs)

    async def put(self, path: str, **kwargs: Any) -> dict[str, Any]:
        """Send a PUT request."""
        return await self.request("PUT", path, **kwargs)

    async def delete(self, path: str, **kwargs: Any) -> dict[str, Any]:
        """Send a DELETE request."""
        return await self.request("DELETE", path, **kwargs)

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()
            self._client = None


class RestClient:
    """Synchronous HTTP client for SSI REST API."""

    def __init__(self, config: Config):
        self._config = config
        self._rate_limiter = RateLimiter(config.rate_limit_per_second)
        self._client: httpx.Client | None = None
        self._headers: dict = {
            HEADER_CONTENT_TYPE: CONTENT_TYPE_JSON,
            HEADER_ACCEPT: CONTENT_TYPE_JSON,
        }

    def _get_client(self) -> httpx.Client:
        if self._client is None or self._client.is_closed:
            self._client = httpx.Client(
                base_url=self._config.api_url,
                timeout=self._config.timeout,
                headers=self._headers,
                proxy=self._config.proxy,
            )
        return self._client

    def get_private_key(self) -> str:
        """Helper to get the private key for signing requests."""
        return self._config.private_key

    def set_auth_header(self, token: str) -> None:
        """Update the authorization header with a bearer token."""
        self._headers[HEADER_AUTHORIZATION] = f"{AUTH_SCHEME_BEARER}{token}"

        if self._client and not self._client.is_closed:
            self._client = None

    def set_signature_header(self, signature: str) -> None:
        """Update the signature header for request signing."""
        self._headers[HEADER_SIGNATURE] = signature
        logger.debug("Signature header set: %s", self._headers)
        if self._client and not self._client.is_closed:
            self._client = None

    def get_headers(self) -> dict[str, str]:
        """Get the current headers (for debugging)."""
        return self._headers

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        content: str | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Make an authenticated synchronous HTTP request."""
        self._rate_limiter.acquire()
        logger.debug(
            "[%s] %s with params=%s, data=%s, json=%s, content=%s, headers=%s",
            method, path, params, data, json_body, content, headers
        )
        def _do_request() -> dict[str, Any]:
            client = self._get_client()
            response = client.request(
                method,
                path,
                params=params,
                json=json_body,
                data=data,
                content=content,
                headers=headers
            )
            return _handle_response(response)

        return retry_sync(
            _do_request,
            max_retries=self._config.max_retries,
            delay=self._config.retry_delay,
        )

    def get(self, path: str, **kwargs: Any) -> dict[str, Any]:
        """Send a GET request."""
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> dict[str, Any]:
        """Send a POST request."""
        return self.request("POST", path, **kwargs)

    def put(self, path: str, **kwargs: Any) -> dict[str, Any]:
        """Send a PUT request."""
        return self.request("PUT", path, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> dict[str, Any]:
        """Send a DELETE request."""
        return self.request("DELETE", path, **kwargs)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._client is not None and not self._client.is_closed:
            self._client.close()
            self._client = None
