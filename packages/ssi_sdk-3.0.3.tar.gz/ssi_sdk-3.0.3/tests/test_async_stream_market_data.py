"""
Sample — WebSocket cập nhật dữ liệu thị trường real-time (async)
=================================================================
Phiên bản async của test_stream_market_data.py, sử dụng AsyncAuth và AsyncStream.

Luồng:
  1. Client mở kết nối WebSocket bằng token hợp lệ
  2. Gửi lệnh SUBSCRIBE các stream trade/ohlcv theo symbol
  3. Server push event khi có dữ liệu thị trường mới
  4. Parse message, in ra màn hình theo từng event
  5. Khi mất kết nối, chạy cơ chế reconnect exponential backoff

Chạy:
    python tests/test_async_stream_market_data.py
"""

import asyncio
import json
import os

from ssi_sdk import AsyncAuth, AsyncStream, Config
from ssi_sdk.enums.timeframe import Timeframe
from ssi_sdk.models import Token
from ssi_sdk.models.streaming import TradeMessage, QuoteMessage, ForeignRoomMessage

config = Config(
    api_url="https://fc-tradeapi-uat.ssi.com.vn",
    streaming_url="wss://fc-tradeapi-uat.ssi.com.vn/ws/v3",
    client_id="666666",
    api_key="9898b17932804741a7e775b8965dd173",
    api_secret="756b69905491421f82ba139363d4bd4d",
    private_key=(
        "PFJTQUtleVZhbHVlPjxNb2R1bHVzPnRyOHNyTHhmSkdKUFVyYTFXWENuYlpyTkNi"
        "eG5EZDZCdHE1NmptU1NKTjNaUVdFb0VqUnEyVkgwRm43cnZUbzZGRFY0aUF3RzRq"
        "K3cyRkt6cHBjc2VXWG1KYTg2MTF4c2xQR2lNbVdBRmZYV2J1MTJ4OC83MWtVcVNG"
        "THM2dXFZN0tMLzY1YUcwMjF1cnM5MkxjYXdIa2xzOXlmdlQvK2ZrY0FvbVI2ME5W"
        "VT08L01vZHVsdXM+PEV4cG9uZW50PkFRQUI8L0V4cG9uZW50PjxQPjIrRDVpREda"
        "OE9kdjdYZmJIbHJxSEMzSERkYnUyK2lMZ3NTQkFOWFhqSU52OXdaSDRTZ1czSWhh"
        "M0trQTFOcFllcFJXcFhyS29ncnU3alppWkh0aXh3PT08L1A+PFE+MU1TYnd6d0s5"
        "L2RreEdIeHAzM0FrZ1paaUs3UnlxcXlPeTFZOWdDak0vTldTR2pOMHpSSi9MaTZj"
        "Z1o0bjZYaGpRV1VDNEFyQUNPcnluQ0syR0NMQXc9PTwvUT48RFA+T0pSTG9hQWgz"
        "THV4TVlvRitHbXNsRk96UlB4cHVteThlWW5YS0QvZWwybTdCZlczeVZobmlaZ015"
        "WHN6bTVJVDhuYjVWTnVrQ002SGJRVFJqTW16UVE9PTwvRFA+PERRPnNuSVd4VDUx"
        "WUpTL2tha25tTGJ5TEVaaER5NjN5d2N3cGtzWkluRlViM3kxcjlNZVZQVzAyOTAr"
        "bWVWdGcxQUhoRlBhWDI3bUlaN0pOT2NBdkFyMGF3PT08L0RRPjxJbnZlcnNlUT4w"
        "aUduT09PNGs4ZGNDV053T1BnelJidTA4ekkzMGo0eGhYYW1Ca3dpUFEwcVVLUzU3"
        "OUdtWWJIcC80Qm90aGtBNDRtMXFHOUw1MGJrM2tpWEtobWdLQT09PC9JbnZlcnNl"
        "UT48RD5SMHVPUWxXN1NKYVNHOUxzTFZpbCtUekxnV0RmVTZuYk1Vb2d4aXkyVjJ1"
        "MXRxd1ExZ2xkSml1eTdwUFZwSjF5eXkrUk5vSjZyUW5zRkhrdlhXN2RDbGJNT1lp"
        "MkpWaXZsTEZOblZnTUdPNTVnOWFuY2dQVnFxd1dkL2UxU1UwbXhaTlNqaDhPTUdW"
        "ZTVPUTRvV0R2RGo0ZitGendOOUQ4b1dOc1U0Sm92b0U9PC9EPjwvUlNBS2V5VmFs"
        "dWU+"
    ),
    # log_level="DEBUG",
)

TOKEN_FILE = os.path.join(os.path.dirname(__file__), "token_cache.json")


def load_token() -> Token | None:
    """Load token từ file, trả về None nếu file không tồn tại."""
    if not os.path.exists(TOKEN_FILE):
        return None
    with open(TOKEN_FILE, "r", encoding="utf-8") as f:
        _token = json.load(f)
    return Token.from_dict(_token)


def save_token(token: Token) -> None:
    """Lưu token xuống file."""
    with open(TOKEN_FILE, "w", encoding="utf-8") as f:
        json.dump(token.to_dict(), f, indent=2)
    print(f"Token đã lưu vào {TOKEN_FILE}")


def on_market_data(msg):
    print(f"[DATA]: {msg}")


async def main() -> None:
    async with AsyncAuth(config) as auth:
        # Load token từ file, nếu không có thì authenticate để lấy token mới
        cached_token = load_token()
        if cached_token is None:
            print("Không tìm thấy file token, đang authenticate...")
            cached_token = await auth.token_manager.authenticate()
            save_token(cached_token)
            print("Authenticate thành công, token đã lưu.")

        await auth.token_manager.set_token(cached_token)
        if auth.token_manager.is_token_expired:
            print("Token đã hết hạn, đang refresh...")
            cached_token = await auth.token_manager.refresh()
            save_token(cached_token)
            print("Refresh token thành công.")
        else:
            print("Token còn hạn, dùng token từ file.")

        print("Đang kết nối WebSocket...")
        async with AsyncStream(auth) as stream:
            # --- Bước 1: Mở kết nối WebSocket ---
            await stream.streaming.connect()
            # --- Bước 2: Đăng ký callback xử lý dữ liệu thị trường ---
            stream.streaming.on_data = on_market_data
            # --- Bước 3: Gửi lệnh SUBSCRIBE để nhận dữ liệu thị trường,
            # đồng thời gửi ping để giữ kết nối ---
            await stream.streaming.subscribe_symbol_trade(symbols=["41I1G5000"])
            await stream.streaming.subscribe_symbol_ohlcv(
                symbols=["41I1G5000"], interval=Timeframe.MINUTE_1
            )
            await stream.streaming.ping(interval=30)
            # --- Bước 4: Lắng nghe sự kiện dữ liệu thị trường với callback đã đăng ký ---
            print("\nĐang lắng nghe... (Ctrl+C để dừng)\n")
            try:
                await stream.streaming.wait(timeout=300)  # 5 phút
            except KeyboardInterrupt:
                print("\nNgắt kết nối...")


if __name__ == "__main__":
    asyncio.run(main())
