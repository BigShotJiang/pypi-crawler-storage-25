import asyncio
import json
import os

from ssi_sdk import AsyncAuth, AsyncTrading, Config
from ssi_sdk.models import Token
from ssi_sdk.enums import OrderSide, OrderType

config = Config(
    api_url="https://fc-tradeapi-uat.ssi.com.vn",
    streaming_url="wss://fc-tradeapi-uat.ssi.com.vn/ws/v3",
    client_id="666666",
    api_key="9898b17932804741a7e775b8965dd173",
    api_secret="756b69905491421f82ba139363d4bd4d",
    private_key=(
        "PFJTQUtleVZhbHVlPjxNb2R1bHVzPnRyOHNyTHhmSkdKUFVyYTFXWENuYlpyTkNi"
        "eG5EZDZCdHE1NmptU1NKTjNaUVdFb0VqUnEyVkgwRm43cnZUbzZGRFY0aUF3RzRq"
        "K3cyRmt6cHBjc2VXWG1KYTg2MTF4c2xQR2lNbVdBRmZYV2J1MTJ4OC83MWtVcVNG"
        "THM2dXFZN0tMLzY1YUcwMjF1cnM5MkxjYXdIa2xzOXlmdlQvK2ZrY0FvbVI2ME5W"
        "VT08L01vZHVsdXM+PEV4cG9uZW50PkFRQUI8L0V4cG9uZW50PjxQPjIrRDVpREda"
        "OE9kdjdYZmJIbHJxSEMzSERkYnUyK2lMZ3NTQkFOWFhqSU52OXdaSDRTZ1czSWhh"
        "M0trQTFOcFllcFJXcFhyS29ncnU3alppWkh0aXh3PT08L1A+PFE+MU1TYnd6d0s5"
        "L2RreEdIeHAzM0FrZ1paaUs3UnlxcXlPeTFZOWdDak0vTldTR2pOMHpSSi9MaTZj"
        "Z1o0bjZYaGpRV1VDNEFyQUNPcnluQ0syR0NMQXc5PTwvUT48RFA+T0pSTG9hQWgz"
        "THV4TVlvRitHbXNsRk96UlB4cHVteThlWW5YS0QvZWwybTdCZlczeVZobmlaZ015"
        "WHN6bTVJVDhuYjVWTnVrQ002SGJRVFJqTW16UVE5PTwvRFA+PERRPnNuSVd4VDUx"
        "WUpTL2tha25tTGJ5TEVaaER5NjN5d2N3cGtzWkluRlViM3kxcjlNZVZQVzAyOTAr"
        "bWVWdGcxQUhoRlBhWDI3bUlaN0pOT2NBdkFyMGF3PT08L0RRPjxJbnZlcnNlUT4w"
        "aUduT09PNGs4ZGNDV053T1BnelJidTA4ekkzMGo0eGhYYW1Ca3dpUFEwcVVLUzU3"
        "OUdtWWJIcC80Qm90aGtBNDRtMXFHOUw1MGJrM2tpWEtobWdLQT09PC9JbnZlcnNl"
        "UT48RD5SMHVPUWxXN1NKYVNHOUxzTFZpbCtUekxnV0RmVTZuYk1Vb2d4aXkyVjJ1"
        "MXRxd1ExZ2xkSml1eTdwUFZwSjF5eXkrUk5vSjZyUW5zRkhrdlhXN2RDbGJNT1lp"
        "MkpWaXZsTEZOblZnTUdPNTVnOWFuY2dQVnFxd1dkL2UxU1UwbXhaTlNqaDhPTUdW"
        "ZTVPUTRvV0R2RGo0ZitGendOOUQ4b1dOc1U0Sm92b0U5PC9EPjwvUlNBS2V5VmFs"
        "dWU+"
    ),
    log_level="DEBUG",
)

TOKEN_FILE = os.path.join(os.path.dirname(__file__), "token_cache.json")


def load_token() -> Token | None:
    """Load token từ file, trả về None nếu file không tồn tại."""
    if not os.path.exists(TOKEN_FILE):
        return None
    with open(TOKEN_FILE, "r", encoding="utf-8") as f:
        _token = json.load(f)
    return Token.from_dict(_token)


def save_token(token: Token) -> None:
    """Lưu token xuống file."""
    with open(TOKEN_FILE, "w", encoding="utf-8") as f:
        json.dump(token.to_dict(), f, indent=2)
    print(f"Token đã lưu vào {TOKEN_FILE}")


async def ensure_auth(auth) -> None:
    """Đảm bảo auth có token hợp lệ."""
    cached_token = load_token()
    if cached_token is None:
        print("Không tìm thấy file token, đang authenticate...")
        cached_token = await auth.token_manager.authenticate()
        save_token(cached_token)
        print("Authenticate thành công, token đã lưu.")
    await auth.token_manager.set_token(cached_token)
    if auth.token_manager.is_token_expired:
        print("Token đã hết hạn, đang refresh...")
        cached_token = await auth.token_manager.refresh()
        save_token(cached_token)
        print("Refresh token thành công.")
    else:
        print("Token còn hạn, dùng token từ file.")


async def test_account(trading):
    """Test account methods."""
    print("\n=== Account ===")
    account_info = await trading.account.get_account_info()
    print(f"Account Info: {len(account_info)} accounts")
    for acc in account_info:
        print(f"  {acc.account_no} - {acc.account_type}")
    return account_info


async def test_portfolio_balance(trading, equity_account, derivative_account):
    """Test portfolio balance methods."""
    print("\n=== Portfolio Balance ===")

    equity_balance = await trading.portfolio.get_equity_balance(equity_account)
    print(f"Equity Balance: {equity_balance}")

    derivative_balance = await trading.portfolio.get_derivative_balance(derivative_account)
    print(f"Derivative Balance: {derivative_balance}")


async def test_portfolio_positions(trading, equity_account, derivative_account):
    """Test portfolio positions methods."""
    print("\n=== Portfolio Positions ===")

    equity_positions = await trading.portfolio.get_equity_positions(equity_account)
    print(f"Equity Positions: {len(equity_positions)} items")

    derivative_positions = await trading.portfolio.get_derivative_positions(derivative_account)
    print(f"Derivative Positions: {derivative_positions}")

    open_positions = await trading.portfolio.get_open_derivative_positions(derivative_account)
    print(f"Open Derivative Positions: {len(open_positions)} items")

    closed_positions = await trading.portfolio.get_closed_derivative_positions(derivative_account)
    print(f"Closed Derivative Positions: {len(closed_positions)} items")


async def test_portfolio_orders(trading, equity_account):
    """Test portfolio order book methods."""
    print("\n=== Portfolio Orders ===")

    today_orders = await trading.portfolio.get_today_orders(equity_account)
    print(f"Today Orders: {len(today_orders)} items")

    historical_orders = await trading.portfolio.get_historical_orders(
        equity_account, "2025/01/01", "2025/01/31"
    )
    print(f"Historical Orders: {len(historical_orders)} items")


async def test_portfolio_ppmmr(trading, equity_account, derivative_account):
    """Test portfolio PPMMR methods."""
    print("\n=== Portfolio PPMMR ===")

    equity_ppmmr = await trading.portfolio.get_equity_ppmmr(equity_account)
    print(f"Equity PPMMR: {equity_ppmmr}")

    derivative_ppmmr = await trading.portfolio.get_derivative_ppmmr(derivative_account)
    print(f"Derivative PPMMR: {derivative_ppmmr}")


async def test_max_buy_sell(trading, equity_account):
    """Test max buy/sell methods."""
    print("\n=== Max Buy/Sell ===")

    max_bs = await trading.trading.get_max_buy_sell(
        account_no=equity_account, symbol="SSI", price=27000
    )
    print(f"Max Buy/Sell (SSI@27000): {max_bs}")

    max_bs_market = await trading.trading.get_max_buy_sell_at_market_price(
        account_no=equity_account, symbol="SSI"
    )
    print(f"Max Buy/Sell at Market (SSI): {max_bs_market}")


async def test_place_order(trading, equity_account):
    """Test place order methods (commented out to avoid side effects)."""
    print("\n=== Place Order (commented out) ===")

    # new_order = await trading.trading.place_order(
    #     account_no=equity_account,
    #     symbol="SSI",
    #     side=OrderSide.BUY,
    #     quantity=100,
    #     price=27000,
    #     order_type=OrderType.LO
    # )
    # print("Placed Order:", new_order)

    # limit_order = await trading.trading.place_limit_order(
    #     account_no=equity_account,
    #     symbol="SSI",
    #     side=OrderSide.BUY,
    #     quantity=100,
    #     price=27000
    # )
    # print("Placed Limit Order:", limit_order)

    # market_order = await trading.trading.place_market_order(
    #     account_no=equity_account,
    #     symbol="SSI",
    #     side=OrderSide.BUY,
    #     quantity=100
    # )
    # print("Placed Market Order:", market_order)

    # ato_order = await trading.trading.place_ato_order(
    #     account_no=equity_account,
    #     symbol="SSI",
    #     side=OrderSide.BUY,
    #     quantity=100
    # )
    # print("Placed ATO Order:", ato_order)

    # atc_order = await trading.trading.place_atc_order(
    #     account_no=equity_account,
    #     symbol="SSI",
    #     side=OrderSide.BUY,
    #     quantity=100
    # )
    # print("Placed ATC Order:", atc_order)


async def test_modify_order(trading, equity_account):
    """Test modify order methods (commented out to avoid side effects)."""
    print("\n=== Modify Order (commented out) ===")

    # modify_price = await trading.trading.modify_order_price(
    #     account_no=equity_account,
    #     client_request_id="YOUR_CLIENT_REQUEST_ID",
    #     price=28000
    # )
    # print("Modified Order Price:", modify_price)

    # modify_price_by_id = await trading.trading.modify_order_price_by_order_id(
    #     account_no=equity_account,
    #     order_id="YOUR_ORDER_ID",
    #     price=28000
    # )
    # print("Modified Order Price by ID:", modify_price_by_id)

    # modify_qty = await trading.trading.modify_order_quantity(
    #     account_no=equity_account,
    #     client_request_id="YOUR_CLIENT_REQUEST_ID",
    #     quantity=200
    # )
    # print("Modified Order Quantity:", modify_qty)

    # modify_qty_by_id = await trading.trading.modify_order_quantity_by_order_id(
    #     account_no=equity_account,
    #     order_id="YOUR_ORDER_ID",
    #     quantity=200
    # )
    # print("Modified Order Quantity by ID:", modify_qty_by_id)


async def test_cancel_order(trading, equity_account):
    """Test cancel order methods (commented out to avoid side effects)."""
    print("\n=== Cancel Order (commented out) ===")

    # cancel = await trading.trading.cancel_order(
    #     account_no=equity_account,
    #     client_request_id="YOUR_CLIENT_REQUEST_ID"
    # )
    # print("Canceled Order:", cancel)

    # cancel_by_id = await trading.trading.cancel_order_by_order_id(
    #     account_no=equity_account,
    #     order_id="YOUR_ORDER_ID"
    # )
    # print("Canceled Order by ID:", cancel_by_id)


async def main() -> None:
    async with AsyncAuth(config) as auth:
        await ensure_auth(auth)

        async with AsyncTrading(auth) as trading:
            # Account
            account_info = await test_account(trading)

            # Determine account numbers
            equity_account = account_info[0].account_no if account_info else "6666661"
            derivative_account = (
                next((a.account_no for a in account_info if "8" in a.account_no), None)
                or "6666668"
            )

            # Portfolio
            await test_portfolio_balance(trading, equity_account, derivative_account)
            await test_portfolio_positions(trading, equity_account, derivative_account)
            await test_portfolio_orders(trading, equity_account)
            await test_portfolio_ppmmr(trading, equity_account, derivative_account)

            # Trading - read only
            await test_max_buy_sell(trading, equity_account)

            # Trading - write operations (commented out)
            await test_place_order(trading, equity_account)
            await test_modify_order(trading, equity_account)
            await test_cancel_order(trading, equity_account)


if __name__ == "__main__":
    asyncio.run(main())
