import json
import os

from ssi_sdk import Auth, Data, Config
from ssi_sdk.models import Token
from ssi_sdk.enums import Board

config = Config(
    api_url="https://fc-tradeapi-uat.ssi.com.vn",
    streaming_url="wss://fc-tradeapi-uat.ssi.com.vn/ws/v3",
    client_id="666666",
    api_key="9898b17932804741a7e775b8965dd173",
    api_secret="756b69905491421f82ba139363d4bd4d",
    private_key=(
        "PFJTQUtleVZhbHVlPjxNb2R1bHVzPnRyOHNyTHhmSkdKUFVyYTFXWENuYlpyTkNi"
        "eG5EZDZCdHE1NmptU1NKTjNaUVdFb0VqUnEyVkgwRm43cnZUbzZGRFY0aUF3RzRq"
        "K3cyRkt6cHBjc2VXWG1KYTg2MTF4c2xQR2lNbVdBRmZYV2J1MTJ4OC83MWtVcVNG"
        "THM2dXFZN0tMLzY1YUcwMjF1cnM5MkxjYXdIa2xzOXlmdlQvK2ZrY0FvbVI2ME5W"
        "VT08L01vZHVsdXM+PEV4cG9uZW50PkFRQUI8L0V4cG9uZW50PjxQPjIrRDVpREda"
        "OE9kdjdYZmJIbHJxSEMzSERkYnUyK2lMZ3NTQkFOWFhqSU52OXdaSDRTZ1czSWhh"
        "M0trQTFOcFllcFJXcFhyS29ncnU3alppWkh0aXh3PT08L1A+PFE+MU1TYnd6d0s5"
        "L2RreEdIeHAzM0FrZ1paaUs3UnlxcXlPeTFZOWdDak0vTldTR2pOMHpSSi9MaTZj"
        "Z1o0bjZYaGpRV1VDNEFyQUNPcnluQ0syR0NMQXc9PTwvUT48RFA+T0pSTG9hQWgz"
        "THV4TVlvRitHbXNsRk96UlB4cHVteThlWW5YS0QvZWwybTdCZlczeVZobmlaZ015"
        "WHN6bTVJVDhuYjVWTnVrQ002SGJRVFJqTW16UVE9PTwvRFA+PERRPnNuSVd4VDUx"
        "WUpTL2tha25tTGJ5TEVaaER5NjN5d2N3cGtzWkluRlViM3kxcjlNZVZQVzAyOTAr"
        "bWVWdGcxQUhoRlBhWDI3bUlaN0pOT2NBdkFyMGF3PT08L0RRPjxJbnZlcnNlUT4w"
        "aUduT09PNGs4ZGNDV053T1BnelJidTA4ekkzMGo0eGhYYW1Ca3dpUFEwcVVLUzU3"
        "OUdtWWJIcC80Qm90aGtBNDRtMXFHOUw1MGJrM2tpWEtobWdLQT09PC9JbnZlcnNl"
        "UT48RD5SMHVPUWxXN1NKYVNHOUxzTFZpbCtUekxnV0RmVTZuYk1Vb2d4aXkyVjJ1"
        "MXRxd1ExZ2xkSml1eTdwUFZwSjF5eXkrUk5vSjZyUW5zRkhrdlhXN2RDbGJNT1lp"
        "MkpWaXZsTEZOblZnTUdPNTVnOWFuY2dQVnFxd1dkL2UxU1UwbXhaTlNqaDhPTUdW"
        "ZTVPUTRvV0R2RGo0ZitGendOOUQ4b1dOc1U0Sm92b0U9PC9EPjwvUlNBS2V5VmFs"
        "dWU+"
    ),
    log_level="DEBUG",
)

TOKEN_FILE = os.path.join(os.path.dirname(__file__), "token_cache.json")


def load_token() -> Token | None:
    """Load token từ file, trả về None nếu file không tồn tại."""
    if not os.path.exists(TOKEN_FILE):
        return None
    with open(TOKEN_FILE, "r", encoding="utf-8") as f:
        _token = json.load(f)
    return Token.from_dict(_token)


def save_token(token: Token) -> None:
    """Lưu token xuống file."""
    with open(TOKEN_FILE, "w", encoding="utf-8") as f:
        json.dump(token.to_dict(), f, indent=2)
    print(f"Token đã lưu vào {TOKEN_FILE}")


def ensure_auth(auth) -> None:
    """Đảm bảo auth có token hợp lệ."""
    cached_token = load_token()
    if cached_token is None:
        print("Không tìm thấy file token, đang authenticate...")
        cached_token = auth.token_manager.authenticate()
        save_token(cached_token)
        print("Authenticate thành công, token đã lưu.")
    auth.token_manager.set_token(cached_token)
    if auth.token_manager.is_token_expired:
        print("Token đã hết hạn, đang refresh...")
        cached_token = auth.token_manager.refresh()
        save_token(cached_token)
        print("Refresh token thành công.")
    else:
        print("Token còn hạn, dùng token từ file.")


def test_ohlc_intraday(data):
    """Test tất cả OHLC intraday methods."""
    print("\n=== OHLC Intraday ===")

    ohlc_1m = data.market_data.get_ohlc_1minute("SSI")
    print(f"OHLC 1 Minute: {len(ohlc_1m)} records")

    ohlc_3m = data.market_data.get_ohlc_3minute("SSI")
    print(f"OHLC 3 Minute: {len(ohlc_3m)} records")

    ohlc_5m = data.market_data.get_ohlc_5minute("SSI")
    print(f"OHLC 5 Minute: {len(ohlc_5m)} records")

    ohlc_15m = data.market_data.get_ohlc_15minute("SSI")
    print(f"OHLC 15 Minute: {len(ohlc_15m)} records")

    ohlc_1h = data.market_data.get_ohlc_1hour("SSI")
    print(f"OHLC 1 Hour: {len(ohlc_1h)} records")


def test_ohlc_historical(data):
    """Test tất cả OHLC historical methods."""
    print("\n=== OHLC Historical ===")
    from_date = "2025/01/01 00:00:00"
    to_date = "2025/01/31 23:59:59"

    ohlc_1m = data.market_data.get_ohlc_1minute_historical("SSI", from_date, to_date)
    print(f"OHLC 1 Minute Historical: {len(ohlc_1m)} records")

    ohlc_3m = data.market_data.get_ohlc_3minute_historical("SSI", from_date, to_date)
    print(f"OHLC 3 Minute Historical: {len(ohlc_3m)} records")

    ohlc_5m = data.market_data.get_ohlc_5minute_historical("SSI", from_date, to_date)
    print(f"OHLC 5 Minute Historical: {len(ohlc_5m)} records")

    ohlc_15m = data.market_data.get_ohlc_15minute_historical("SSI", from_date, to_date)
    print(f"OHLC 15 Minute Historical: {len(ohlc_15m)} records")

    ohlc_1h = data.market_data.get_ohlc_1hour_historical("SSI", from_date, to_date)
    print(f"OHLC 1 Hour Historical: {len(ohlc_1h)} records")

    ohlc_1d = data.market_data.get_ohlc_1day_historical("SSI", from_date, to_date)
    print(f"OHLC 1 Day Historical: {len(ohlc_1d)} records")

    # ohlc_1w = data.market_data.get_ohlc_1week_historical("SSI", from_date, to_date)
    # print(f"OHLC 1 Week Historical: {len(ohlc_1w)} records")

    # ohlc_1mo = data.market_data.get_ohlc_1month_historical("SSI", from_date, to_date)
    # print(f"OHLC 1 Month Historical: {len(ohlc_1mo)} records")


def test_indexes(data):
    """Test index methods."""
    print("\n=== Indexes ===")

    indexes = data.market_data.get_indexes()
    print(f"All Indexes: {len(indexes)} items")
    for idx in indexes[:3]:
        print(f"  {idx.index} - {idx.index_name}")

    indexes_hose = data.market_data.get_indexes_by_board(Board.HOSE)
    print(f"HOSE Indexes: {len(indexes_hose)} items")

    indexes_hnx = data.market_data.get_indexes_by_board(Board.HNX)
    print(f"HNX Indexes: {len(indexes_hnx)} items")


def test_index_summary(data):
    """Test index summary methods."""
    print("\n=== Index Summary ===")

    summary = data.market_data.get_index_summary("VNINDEX")
    print(f"VNINDEX Summary: value={summary.index_value}, change={summary.index_change}" if summary else "VNINDEX Summary: None")

    summary_hist = data.market_data.get_index_summary_historical("VNINDEX", "2025/01/15")
    print(f"VNINDEX Historical: value={summary_hist.index_value}" if summary_hist else "VNINDEX Historical: None")

    board_summary = data.market_data.get_board_summary(Board.HOSE)
    print(f"HOSE Board Summary: value={board_summary.index_value}" if board_summary else "HOSE Board Summary: None")

    board_summary_hist = data.market_data.get_board_summary_historical(Board.HOSE, "2025/01/15")
    print(f"HOSE Board Historical: value={board_summary_hist.index_value}" if board_summary_hist else "HOSE Board Historical: None")


def test_securities_info(data):
    """Test securities info methods."""
    print("\n=== Securities Info ===")

    info = data.market_data.get_securities_info("SSI")
    print(f"SSI Info: symbol={info.symbol}, board={info.board}" if info else "SSI Info: None")

    # by_index = data.market_data.get_securities_info_by_index("VN30")
    # print(f"VN30 Securities Info: {len(by_index)} items")

    # by_board = data.market_data.get_securities_info_by_board(Board.HOSE)
    # print(f"HOSE Securities Info: {len(by_board)} items")


def test_securities_summary(data):
    """Test securities summary methods."""
    print("\n=== Securities Summary ===")

    summary = data.market_data.get_securities_summary("SSI")
    print(f"SSI Summary: {len(summary)} records")

    summary_hist = data.market_data.get_securities_summary_historical(
        "SSI", "2025/01/01", "2025/01/31"
    )
    print(f"SSI Summary Historical: {len(summary_hist)} records")

    by_index = data.market_data.get_securities_summary_by_index("VN30")
    print(f"VN30 Summary: {len(by_index)} records")

    by_index_hist = data.market_data.get_securities_summary_by_index_historical(
        "VN30", "2025/01/01", "2025/01/31"
    )
    print(f"VN30 Summary Historical: {len(by_index_hist)} records")


with Auth(config) as auth:
    ensure_auth(auth)

    with Data(auth) as data:
        test_ohlc_intraday(data)
        test_ohlc_historical(data)
        test_indexes(data)
        test_index_summary(data)
        test_securities_info(data)
        test_securities_summary(data)
