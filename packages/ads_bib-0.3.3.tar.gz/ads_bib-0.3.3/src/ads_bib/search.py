"""Step 1 – Query the NASA ADS API for bibcodes, references and e-sources."""

from __future__ import annotations

import logging
import shutil
from datetime import datetime
from pathlib import Path
from collections.abc import Callable

from ._utils.ads_api import create_session, retry_request

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

ADS_SEARCH_URL = "https://api.adsabs.harvard.edu/v1/search/query"
ADS_LINK_GATEWAY_URL_TEMPLATE = "https://ui.adsabs.harvard.edu/link_gateway/{bibcode}/{resource}"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def search_ads(
    query: str,
    token: str,
    *,
    fields: str = "bibcode,reference,esources",
    rows: int = 2000,
    sort: str = "date desc, id asc",
    raw_dir: Path | None = None,
    force_refresh: bool = False,
    progress_callback: Callable[[int], None] | None = None,
    progress_total_callback: Callable[[int], None] | None = None,
) -> tuple[list[str], list[list[str]], list[list[str]], list[str | None]]:
    """Run an ADS search and return bibcodes with their references.

    Parameters
    ----------
    query : str
        ADS query string (e.g. ``"abs:(cosmology) AND year:1990-2000"``).
    token : str
        ADS API bearer token.
    fields : str
        Comma-separated field list to retrieve.
    rows : int
        Page size for cursor-based deep paging (max 2000).
    sort : str
        Sort order.  Must include a unique tie-breaker for cursor paging.
    raw_dir : Path, optional
        Directory for caching search results.  When given, results are
        persisted via :func:`save_search_results` and reloaded on subsequent
        calls unless *force_refresh* is ``True``.
    force_refresh : bool
        If ``True``, ignore cached results even when *raw_dir* is set.

    Returns
    -------
    tuple
        ``(bibcodes, references, esources, fulltext_urls)`` – each a list
        aligned by index.
    """
    if raw_dir is not None:
        latest = Path(raw_dir) / "search_results_latest.pkl"
        if not force_refresh and latest.exists():
            from ._utils.io import load_pickle
            logger.info("Loading cached search results: %s", latest.name)
            return load_pickle(latest)

    session = create_session(token)
    url = ADS_SEARCH_URL

    params: dict = {"q": query, "fl": fields, "rows": rows, "sort": sort}
    cursor = "*"

    bibcodes: list[str] = []
    references: list[list[str]] = []
    esources: list[list[str]] = []
    fulltext_urls: list[str | None] = []
    reported_total = False

    logger.info("Starting ADS search ...")

    while True:
        params["cursorMark"] = cursor
        resp = retry_request(session, "get", url, params=params)
        data = resp.json()
        response = data.get("response", {})
        docs = response.get("docs", [])
        if not reported_total and progress_total_callback is not None:
            total = int(response.get("numFound") or 0)
            if total > 0:
                progress_total_callback(total)
                reported_total = True

        if not docs:
            break

        for doc in docs:
            bc = doc.get("bibcode")
            bibcodes.append(bc)
            references.append(doc.get("reference", []))
            esources.append(doc.get("esources", []))

            pdf = next(
                (
                    ADS_LINK_GATEWAY_URL_TEMPLATE.format(bibcode=bc, resource=res)
                    for res in doc.get("esources", [])
                    if any(p in res for p in ("ADS_PDF", "PUB_PDF"))
                ),
                None,
            )
            fulltext_urls.append(pdf)
        if progress_callback is not None:
            progress_callback(len(docs))

        next_cursor = data.get("nextCursorMark")
        if next_cursor == cursor or not next_cursor:
            break
        cursor = next_cursor
        logger.info("  %s records fetched ...", f"{len(bibcodes):,}")

    session.close()

    unique_refs = len(set(r for rl in references for r in rl))
    total_refs = sum(len(rl) for rl in references)
    logger.info(
        "Done. Bibcodes: %s | Unique refs: %s | Total refs: %s",
        f"{len(bibcodes):,}", f"{unique_refs:,}", f"{total_refs:,}",
    )

    if raw_dir is not None:
        save_search_results(
            (bibcodes, references, esources, fulltext_urls), Path(raw_dir),
        )

    return bibcodes, references, esources, fulltext_urls


def save_search_results(
    data: tuple,
    raw_dir: Path,
    *,
    prefix: str = "search_results",
) -> Path:
    """Persist search results as a timestamped pickle with a *latest* alias.

    Parameters
    ----------
    data : tuple
        ``(bibcodes, references, esources, fulltext_urls)``.
    raw_dir : Path
        Directory for raw data (e.g. ``data/raw``).
    prefix : str
        Filename prefix.

    Returns
    -------
    Path
        Path to the saved file.
    """
    from ._utils.io import save_pickle

    raw_dir = Path(raw_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_path = raw_dir / f"{prefix}_{ts}.pkl"
    latest_path = raw_dir / f"{prefix}_latest.pkl"

    save_pickle(data, run_path)
    shutil.copy(run_path, latest_path)

    logger.info("Saved: %s", run_path.name)
    logger.info("Latest: %s", latest_path.name)
    return run_path
