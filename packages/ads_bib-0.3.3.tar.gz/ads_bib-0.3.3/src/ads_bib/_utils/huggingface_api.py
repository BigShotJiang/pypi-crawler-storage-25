"""Minimal Hugging Face model and token helpers."""

from __future__ import annotations

import os

HF_TOKEN_ENV_VAR = "HF_TOKEN"


def resolve_huggingface_api_key(api_key: str | None = None) -> str | None:
    """Return an explicit key or the canonical Hugging Face env var."""
    if api_key:
        return str(api_key)
    return os.getenv(HF_TOKEN_ENV_VAR) or None


def _split_huggingface_model(model: str) -> tuple[str, str | None]:
    """Return ``(model_id, provider)`` for canonical HF ids."""
    value = str(model).strip()
    if not value:
        raise ValueError("Hugging Face model must not be empty.")

    if value.startswith("huggingface/"):
        raise ValueError(
            "Use canonical Hugging Face model syntax 'org/model[:provider]', "
            "not 'huggingface/...'."
        )

    if ":" in value:
        model_id, provider = value.rsplit(":", 1)
        if model_id and provider and "/" not in provider:
            return model_id, provider

    return value, None


def normalize_huggingface_model(model: str) -> str:
    """Return the canonical public HF form: ``org/model[:provider]``."""
    model_id, provider = _split_huggingface_model(model)
    if provider:
        return f"{model_id}:{provider}"
    return model_id


def normalize_huggingface_model_for_litellm(model: str) -> str:
    """Return BERTopic/LiteLLM's expected HF model syntax."""
    model_id, provider = _split_huggingface_model(model)
    if provider:
        return f"huggingface/{provider}/{model_id}"
    return f"huggingface/{model_id}"
