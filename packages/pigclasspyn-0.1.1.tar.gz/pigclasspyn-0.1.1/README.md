# pig

😊😊😊😊😊

## 功能

`Pig` 类包含以下功能：

- 初始化猪的名字、编号，年龄默认为 1。
- `age_add()`：年龄增加 1 并返回当前年龄。
- `display()`：显示猪的名字、年龄和编号。
- `modify(modify_name, modify_serial_number)`：修改名字或编号，如果某个参数为 `None` 则提示用户输入。
- `pig_play(play_content)`：打印猪玩耍的内容。
- `pig_sleep(sleep_time)`：打印猪睡觉的时长。
- `pig_eat(food, food_time, quantity_of_food)`：打印猪进食的信息。

## 安装

使用 `pip` 安装：

```bash

pip install pig-class
```