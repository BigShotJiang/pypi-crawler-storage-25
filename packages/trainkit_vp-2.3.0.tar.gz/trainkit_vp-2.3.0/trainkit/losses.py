"""Multi-level loss with per-expert breakdown for CELMoE hierarchies.

Computes separate losses for each expert at each hierarchy level
(e.g., family/slavic, family/romance, language/rus, language/bul),
then aggregates them with configurable weights.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TypeAlias

import torch
import torch.nn.functional as F

ModelOutput: TypeAlias = dict[str, torch.Tensor | list[str]]


def _empty_expert_losses() -> dict[str, float]:
    return {}


@dataclass
class LossBreakdown:
    """Full loss breakdown with per-expert granularity.

    Attributes:
        total: Weighted sum of all losses (used for backward).
        final: Loss from the fused output head.
        universal: Loss from the universal expert.
        family_total: Weighted average loss across all family experts.
        language_total: Weighted average loss across all language experts.
        per_expert: Per-expert losses keyed as "family/{name}" or "language/{name}".
    """

    total: torch.Tensor
    final: torch.Tensor
    universal: torch.Tensor
    family_total: torch.Tensor
    language_total: torch.Tensor
    per_expert: dict[str, float] = field(default_factory=_empty_expert_losses)

    def as_scalars(self) -> dict[str, float]:
        """Convert all losses to a flat dict of floats for logging.

        Returns keys like:
            total, final, universal, family/slavic, family/romance,
            language/rus, language/bul, ...
        """
        scalars: dict[str, float] = {
            "total": float(self.total.detach().cpu()),
            "final": float(self.final.detach().cpu()),
            "universal": float(self.universal.detach().cpu()),
        }
        scalars.update(self.per_expert)
        return scalars


class MultiLevelSequenceLoss:
    """Cross-entropy loss at each hierarchy level with per-expert breakdown.

    Computes separate CE losses for:
    - The fused final output (weighted by final_weight)
    - Universal expert output (weighted by universal_weight)
    - Each family expert individually, then averaged (weighted by family_weight)
    - Each language expert individually, then averaged (weighted by language_weight)

    The per-expert losses are tracked for logging but the total loss
    uses aggregated family/language losses for stable gradients.
    """

    def __init__(
        self,
        pad_id: int,
        final_weight: float = 1.0,
        universal_weight: float = 0.25,
        family_weight: float = 0.35,
        language_weight: float = 0.5,
    ) -> None:
        self.pad_id = pad_id
        self.final_weight = final_weight
        self.universal_weight = universal_weight
        self.family_weight = family_weight
        self.language_weight = language_weight

    def _ce(self, logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """Cross-entropy loss ignoring pad tokens."""
        vocab_size = logits.size(-1)
        return F.cross_entropy(
            logits.reshape(-1, vocab_size),
            target.reshape(-1),
            ignore_index=self.pad_id,
        )

    def _per_expert_ce(
        self,
        logits: torch.Tensor,
        target: torch.Tensor,
        routing: list[str],
        level_prefix: str,
    ) -> tuple[torch.Tensor, dict[str, float]]:
        """Compute per-expert CE losses within a hierarchy level.

        Groups samples by expert, computes CE for each, then averages.
        Returns the aggregated loss (for backward) and per-expert floats (for logging).
        """
        device = logits.device
        unique_experts = sorted(set(routing))
        expert_losses: dict[str, float] = {}
        loss_tensors: list[torch.Tensor] = []
        expert_sample_counts: list[int] = []

        for expert_name in unique_experts:
            indices = [idx for idx, route in enumerate(routing) if route == expert_name]
            if not indices:
                continue
            index_tensor = torch.tensor(indices, device=device, dtype=torch.long)
            expert_logits = logits.index_select(0, index_tensor)
            expert_target = target.index_select(0, index_tensor)
            expert_loss = self._ce(expert_logits, expert_target)
            expert_losses[f"{level_prefix}/{expert_name}"] = float(expert_loss.detach().cpu())
            loss_tensors.append(expert_loss)
            expert_sample_counts.append(len(indices))

        if not loss_tensors:
            zero = logits.new_zeros(())
            return zero, expert_losses

        total_samples = sum(expert_sample_counts)
        weighted_loss = logits.new_zeros(())
        for loss, count in zip(loss_tensors, expert_sample_counts):
            weighted_loss = weighted_loss + loss * (count / total_samples)
        return weighted_loss, expert_losses

    def __call__(
        self,
        output: ModelOutput,
        target: torch.Tensor,
    ) -> LossBreakdown:
        """Compute the full multi-level loss.

        Args:
            output: Model output dict with keys:
                - "logits": fused output logits (batch, seq, vocab)
                - "universal_logits": universal expert logits
                - "family_logits": family expert logits
                - "language_logits": language expert logits
                - "family_routing": list[str] mapping each sample to its family
                - "language_routing": list[str] mapping each sample to its language
            target: Target token IDs (batch, seq).

        Returns:
            LossBreakdown with total loss, level losses, and per-expert breakdown.
        """
        logits = output["logits"]
        assert isinstance(logits, torch.Tensor)
        universal_logits = output["universal_logits"]
        assert isinstance(universal_logits, torch.Tensor)
        family_logits = output["family_logits"]
        assert isinstance(family_logits, torch.Tensor)
        language_logits = output["language_logits"]
        assert isinstance(language_logits, torch.Tensor)

        final_loss = self._ce(logits, target)
        universal_loss = self._ce(universal_logits, target)

        per_expert: dict[str, float] = {}

        family_routing = output.get("family_routing")
        if isinstance(family_routing, list) and len(family_routing) > 0:
            family_total, family_expert_losses = self._per_expert_ce(
                family_logits, target, family_routing, "family",
            )
            per_expert.update(family_expert_losses)
        else:
            family_total = self._ce(family_logits, target)

        language_routing = output.get("language_routing")
        if isinstance(language_routing, list) and len(language_routing) > 0:
            language_total, language_expert_losses = self._per_expert_ce(
                language_logits, target, language_routing, "language",
            )
            per_expert.update(language_expert_losses)
        else:
            language_total = self._ce(language_logits, target)

        total = (
            self.final_weight * final_loss
            + self.universal_weight * universal_loss
            + self.family_weight * family_total
            + self.language_weight * language_total
        )

        return LossBreakdown(
            total=total,
            final=final_loss,
            universal=universal_loss,
            family_total=family_total,
            language_total=language_total,
            per_expert=per_expert,
        )
