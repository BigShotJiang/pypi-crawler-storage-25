"""Public API for the trainkit package."""

from trainkit.checkpoint import load_checkpoint, save_checkpoint
from trainkit.freezing import freeze_stages, set_requires_grad
from trainkit.losses import LossBreakdown, MultiLevelSequenceLoss
from trainkit.memory import (
    detect_memory, plan_training, estimate_model_memory,
    estimate_training_vram, suggest_batch_size, format_bytes,
    MemoryProfile, TrainingPlan,
)
from trainkit.scheduler import create_cosine_schedule

__all__: list[str] = [
    "LossBreakdown",
    "MemoryProfile",
    "MultiLevelSequenceLoss",
    "TrainingPlan",
    "create_cosine_schedule",
    "detect_memory",
    "estimate_model_memory",
    "estimate_training_vram",
    "format_bytes",
    "freeze_stages",
    "load_checkpoint",
    "plan_training",
    "save_checkpoint",
    "set_requires_grad",
    "suggest_batch_size",
]

__version__: str = "2.3.0"
