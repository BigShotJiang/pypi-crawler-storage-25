from __future__ import annotations

import torch.nn as nn
from typing import cast


def set_requires_grad(module: nn.Module, enabled: bool) -> None:
    for param in module.parameters():
        param.requires_grad = enabled


def _module_dict_entry(module_dict: nn.ModuleDict, name: str) -> nn.Module:
    return module_dict[name]


def freeze_stages(model: nn.Module, stage: str) -> None:
    celmoe = getattr(model, "celmoe", None)
    if celmoe is None:
        return

    level_modules = cast(nn.ModuleDict | None, getattr(celmoe, "level_modules", None))
    if level_modules is None:
        return

    if stage == "universal":
        set_requires_grad(_module_dict_entry(level_modules, "universal"), True)
        set_requires_grad(_module_dict_entry(level_modules, "family"), False)
        set_requires_grad(_module_dict_entry(level_modules, "language"), False)
    elif stage == "family":
        set_requires_grad(_module_dict_entry(level_modules, "universal"), False)
        set_requires_grad(_module_dict_entry(level_modules, "family"), True)
        set_requires_grad(_module_dict_entry(level_modules, "language"), False)
    elif stage == "language":
        set_requires_grad(_module_dict_entry(level_modules, "universal"), False)
        set_requires_grad(_module_dict_entry(level_modules, "family"), True)
        set_requires_grad(_module_dict_entry(level_modules, "language"), True)
    elif stage == "joint":
        set_requires_grad(_module_dict_entry(level_modules, "universal"), True)
        set_requires_grad(_module_dict_entry(level_modules, "family"), True)
        set_requires_grad(_module_dict_entry(level_modules, "language"), True)
