from __future__ import annotations

from pathlib import Path
from typing import Mapping, TypeAlias, cast

import torch

CheckpointPayload: TypeAlias = Mapping[str, object]


def save_checkpoint(path: str | Path, payload: CheckpointPayload) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    torch.save(payload, destination)


def load_checkpoint(path: str | Path, map_location: str | torch.device = "cpu") -> dict[str, object]:
    return cast(dict[str, object], torch.load(Path(path), map_location=map_location))
