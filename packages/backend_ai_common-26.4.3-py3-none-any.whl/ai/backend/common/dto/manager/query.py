from __future__ import annotations

import uuid
from collections.abc import Callable
from datetime import date, datetime
from typing import TypeVar

from pydantic import Field

from ai.backend.common.api_handlers import BaseRequestModel
from ai.backend.common.data.filter_specs import (
    StringInMatchSpec,
    StringMatchSpec,
    UUIDEqualMatchSpec,
    UUIDInMatchSpec,
)

_QC = TypeVar("_QC")


class DateFilter(BaseRequestModel):
    """Filter for date fields (not datetime) supporting range and equality operations."""

    before: date | None = Field(default=None, description="Before this date (inclusive)")
    after: date | None = Field(default=None, description="After this date (inclusive)")
    equals: date | None = Field(default=None, description="Exact date match")
    not_equals: date | None = Field(default=None, description="Not equal to this date")


class IntFilter(BaseRequestModel):
    """Filter for integer fields supporting equality and comparison operations."""

    equals: int | None = Field(default=None, description="Exact integer match")
    not_equals: int | None = Field(default=None, description="Not equal to this integer")
    greater_than: int | None = Field(default=None, description="Greater than this integer")
    greater_than_or_equal: int | None = Field(
        default=None, description="Greater than or equal to this integer"
    )
    less_than: int | None = Field(default=None, description="Less than this integer")
    less_than_or_equal: int | None = Field(
        default=None, description="Less than or equal to this integer"
    )

    def build_query_condition(
        self,
        equals_factory: Callable[[int], _QC],
        not_equals_factory: Callable[[int], _QC],
        greater_than_factory: Callable[[int], _QC],
        greater_than_or_equal_factory: Callable[[int], _QC],
        less_than_factory: Callable[[int], _QC],
        less_than_or_equal_factory: Callable[[int], _QC],
    ) -> _QC | None:
        """Build a query condition from this filter using the provided factory callables.

        Args:
            equals_factory: Factory for == comparison.
            not_equals_factory: Factory for != comparison.
            greater_than_factory: Factory for > comparison.
            greater_than_or_equal_factory: Factory for >= comparison.
            less_than_factory: Factory for < comparison.
            less_than_or_equal_factory: Factory for <= comparison.

        Returns:
            A query condition if any filter field is set, None otherwise.
        """
        if self.equals is not None:
            return equals_factory(self.equals)
        if self.not_equals is not None:
            return not_equals_factory(self.not_equals)
        if self.greater_than is not None:
            return greater_than_factory(self.greater_than)
        if self.greater_than_or_equal is not None:
            return greater_than_or_equal_factory(self.greater_than_or_equal)
        if self.less_than is not None:
            return less_than_factory(self.less_than)
        if self.less_than_or_equal is not None:
            return less_than_or_equal_factory(self.less_than_or_equal)
        return None


class DateTimeFilter(BaseRequestModel):
    """Filter for datetime fields supporting range and equality operations."""

    before: datetime | None = Field(default=None, description="Before this datetime (inclusive)")
    after: datetime | None = Field(default=None, description="After this datetime (inclusive)")
    equals: datetime | None = Field(default=None, description="Exact datetime match")
    not_equals: datetime | None = Field(default=None, description="Not equal to this datetime")

    def build_query_condition(
        self,
        before_factory: Callable[[datetime], _QC],
        after_factory: Callable[[datetime], _QC],
        equals_factory: Callable[[datetime], _QC],
    ) -> _QC | None:
        """Build a query condition from this filter using the provided factory callables.

        Args:
            before_factory: Factory function that takes datetime and returns a condition for <= comparison
            after_factory: Factory function that takes datetime and returns a condition for >= comparison
            equals_factory: Factory function for = comparison

        Returns:
            A query condition if any filter field is set, None otherwise
        """
        if self.equals is not None:
            return equals_factory(self.equals)
        if self.before is not None:
            return before_factory(self.before)
        if self.after is not None:
            return after_factory(self.after)
        return None


class NullableDateTimeFilter(DateTimeFilter):
    """Filter for nullable datetime fields.

    Extends DateTimeFilter with is_null support for columns that allow NULL values
    (e.g., last_triggered_at). Use DateTimeFilter for NOT NULL columns.
    """

    is_null: bool | None = Field(
        default=None,
        description="Filter by null status: true = IS NULL, false = IS NOT NULL",
    )

    def build_query_condition(
        self,
        before_factory: Callable[[datetime], _QC],
        after_factory: Callable[[datetime], _QC],
        equals_factory: Callable[[datetime], _QC],
        is_null_factory: Callable[[], _QC] | None = None,
        is_not_null_factory: Callable[[], _QC] | None = None,
    ) -> _QC | None:
        if self.is_null is not None:
            if self.is_null and is_null_factory is not None:
                return is_null_factory()
            if not self.is_null and is_not_null_factory is not None:
                return is_not_null_factory()
        return super().build_query_condition(before_factory, after_factory, equals_factory)


class DateTimeRangeFilter(BaseRequestModel):
    """
    Filters records by a datetime range.

    Both boundaries are inclusive. You can specify just 'after', just 'before',
    or both to define the range. Records matching the boundary values are included.
    This filter is shared across all report types for datetime fields like
    created_at, modified_at, terminated_at, etc.
    """

    after: datetime | None = Field(
        default=None,
        description=(
            "Include only records created on or after this datetime. "
            "Should be in ISO 8601 format (e.g., '2024-01-01T00:00:00Z'). "
            "If not specified, there is no lower bound on the datetime range."
        ),
    )
    before: datetime | None = Field(
        default=None,
        description=(
            "Include only records created on or before this datetime. "
            "Should be in ISO 8601 format (e.g., '2024-12-31T23:59:59Z'). "
            "If not specified, there is no upper bound on the datetime range."
        ),
    )


class DateRangeFilter(BaseRequestModel):
    """
    Filters records by a date range.

    Both boundaries are inclusive. You can specify just 'after', just 'before',
    or both to define the range. Records matching the boundary values are included.
    This filter is used for date fields like period_start in usage buckets.
    """

    after: date | None = Field(
        default=None,
        description=(
            "Include only records with dates on or after this date. "
            "Should be in ISO 8601 date format (e.g., '2024-01-01'). "
            "If not specified, there is no lower bound on the date range."
        ),
    )
    before: date | None = Field(
        default=None,
        description=(
            "Include only records with dates on or before this date. "
            "Should be in ISO 8601 date format (e.g., '2024-12-31'). "
            "If not specified, there is no upper bound on the date range."
        ),
    )


class StringFilter(BaseRequestModel):
    """Comprehensive string field filter supporting multiple match operations.

    Provides flexible string matching with four operation types (equals, contains,
    starts_with, ends_with), each available in case-sensitive, case-insensitive,
    and negated variants for complete filtering control.
    """

    # Basic operations (case-sensitive)
    equals: str | None = Field(default=None, description="Exact match (case-sensitive)")
    contains: str | None = Field(default=None, description="Contains (case-sensitive)")
    starts_with: str | None = Field(default=None, description="Starts with (case-sensitive)")
    ends_with: str | None = Field(default=None, description="Ends with (case-sensitive)")

    # NOT operations (case-sensitive)
    not_equals: str | None = Field(default=None, description="Not equals (case-sensitive)")
    not_contains: str | None = Field(default=None, description="Not contains (case-sensitive)")
    not_starts_with: str | None = Field(
        default=None, description="Not starts with (case-sensitive)"
    )
    not_ends_with: str | None = Field(default=None, description="Not ends with (case-sensitive)")

    # Case-insensitive operations
    i_equals: str | None = Field(default=None, description="Exact match (case-insensitive)")
    i_contains: str | None = Field(default=None, description="Contains (case-insensitive)")
    i_starts_with: str | None = Field(default=None, description="Starts with (case-insensitive)")
    i_ends_with: str | None = Field(default=None, description="Ends with (case-insensitive)")

    # Case-insensitive NOT operations
    i_not_equals: str | None = Field(default=None, description="Not equals (case-insensitive)")
    i_not_contains: str | None = Field(default=None, description="Not contains (case-insensitive)")
    i_not_starts_with: str | None = Field(
        default=None, description="Not starts with (case-insensitive)"
    )
    i_not_ends_with: str | None = Field(
        default=None, description="Not ends with (case-insensitive)"
    )

    # IN operations
    in_: list[str] | None = Field(
        default=None, alias="in", description="Value is in the provided list (case-sensitive)"
    )
    not_in: list[str] | None = Field(
        default=None, description="Value is not in the provided list (case-sensitive)"
    )
    i_in: list[str] | None = Field(
        default=None, description="Value is in the provided list (case-insensitive)"
    )
    i_not_in: list[str] | None = Field(
        default=None, description="Value is not in the provided list (case-insensitive)"
    )

    def build_query_condition(
        self,
        contains_factory: Callable[[StringMatchSpec], _QC],
        equals_factory: Callable[[StringMatchSpec], _QC],
        starts_with_factory: Callable[[StringMatchSpec], _QC],
        ends_with_factory: Callable[[StringMatchSpec], _QC],
        in_factory: Callable[[StringInMatchSpec], _QC],
    ) -> _QC | None:
        """Build a query condition from this filter using the provided factory callables.

        Args:
            contains_factory: Factory for LIKE '%value%' operations
            equals_factory: Factory for exact match (=) operations
            starts_with_factory: Factory for LIKE 'value%' operations
            ends_with_factory: Factory for LIKE '%value' operations
            in_factory: Factory for IN (list membership) operations

        Returns:
            _QC if any filter field is set, None otherwise
        """
        # equals operations
        if self.equals is not None:
            return equals_factory(
                StringMatchSpec(self.equals, case_insensitive=False, negated=False)
            )
        if self.i_equals is not None:
            return equals_factory(
                StringMatchSpec(self.i_equals, case_insensitive=True, negated=False)
            )
        if self.not_equals is not None:
            return equals_factory(
                StringMatchSpec(self.not_equals, case_insensitive=False, negated=True)
            )
        if self.i_not_equals is not None:
            return equals_factory(
                StringMatchSpec(self.i_not_equals, case_insensitive=True, negated=True)
            )

        # contains operations
        if self.contains is not None:
            return contains_factory(
                StringMatchSpec(self.contains, case_insensitive=False, negated=False)
            )
        if self.i_contains is not None:
            return contains_factory(
                StringMatchSpec(self.i_contains, case_insensitive=True, negated=False)
            )
        if self.not_contains is not None:
            return contains_factory(
                StringMatchSpec(self.not_contains, case_insensitive=False, negated=True)
            )
        if self.i_not_contains is not None:
            return contains_factory(
                StringMatchSpec(self.i_not_contains, case_insensitive=True, negated=True)
            )

        # starts_with operations
        if self.starts_with is not None:
            return starts_with_factory(
                StringMatchSpec(self.starts_with, case_insensitive=False, negated=False)
            )
        if self.i_starts_with is not None:
            return starts_with_factory(
                StringMatchSpec(self.i_starts_with, case_insensitive=True, negated=False)
            )
        if self.not_starts_with is not None:
            return starts_with_factory(
                StringMatchSpec(self.not_starts_with, case_insensitive=False, negated=True)
            )
        if self.i_not_starts_with is not None:
            return starts_with_factory(
                StringMatchSpec(self.i_not_starts_with, case_insensitive=True, negated=True)
            )

        # ends_with operations
        if self.ends_with is not None:
            return ends_with_factory(
                StringMatchSpec(self.ends_with, case_insensitive=False, negated=False)
            )
        if self.i_ends_with is not None:
            return ends_with_factory(
                StringMatchSpec(self.i_ends_with, case_insensitive=True, negated=False)
            )
        if self.not_ends_with is not None:
            return ends_with_factory(
                StringMatchSpec(self.not_ends_with, case_insensitive=False, negated=True)
            )
        if self.i_not_ends_with is not None:
            return ends_with_factory(
                StringMatchSpec(self.i_not_ends_with, case_insensitive=True, negated=True)
            )

        # IN operations
        if self.in_ is not None:
            return in_factory(
                StringInMatchSpec(values=self.in_, case_insensitive=False, negated=False)
            )
        if self.not_in is not None:
            return in_factory(
                StringInMatchSpec(values=self.not_in, case_insensitive=False, negated=True)
            )
        if self.i_in is not None:
            return in_factory(
                StringInMatchSpec(values=self.i_in, case_insensitive=True, negated=False)
            )
        if self.i_not_in is not None:
            return in_factory(
                StringInMatchSpec(values=self.i_not_in, case_insensitive=True, negated=True)
            )

        return None


class UUIDFilter(BaseRequestModel):
    """Filter for UUID fields supporting equality and set operations.

    Provides UUID matching with equals/not_equals and in/not_in operations.
    """

    # Basic operations
    equals: uuid.UUID | None = Field(default=None, description="Exact UUID match")
    in_: list[uuid.UUID] | None = Field(default=None, alias="in", description="UUID is in list")

    # NOT operations
    not_equals: uuid.UUID | None = Field(default=None, description="Not equals UUID")
    not_in: list[uuid.UUID] | None = Field(default=None, description="UUID is not in list")

    def build_query_condition(
        self,
        equals_factory: Callable[[UUIDEqualMatchSpec], _QC],
        in_factory: Callable[[UUIDInMatchSpec], _QC],
    ) -> _QC | None:
        """Build a query condition from this filter using the provided factory callables.

        Args:
            equals_factory: Factory function for equality operations (=, !=)
            in_factory: Factory function for IN operations (IN, NOT IN)

        Returns:
            _QC if any filter field is set, None otherwise
        """
        if self.equals is not None:
            return equals_factory(UUIDEqualMatchSpec(value=self.equals, negated=False))
        if self.not_equals is not None:
            return equals_factory(UUIDEqualMatchSpec(value=self.not_equals, negated=True))
        if self.in_ is not None:
            return in_factory(UUIDInMatchSpec(values=self.in_, negated=False))
        if self.not_in is not None:
            return in_factory(UUIDInMatchSpec(values=self.not_in, negated=True))
        return None


class ListGroupQuery(BaseRequestModel):
    group_id: uuid.UUID | None = Field(default=None, alias="groupId")
