"""Smoke test that the package imports and exposes a version."""

from importlib.metadata import version as _pkg_version

import agentboundary


def test_package_imports() -> None:
    assert agentboundary is not None


def test_package_exposes_version() -> None:
    assert hasattr(agentboundary, "__version__")
    assert isinstance(agentboundary.__version__, str)
    assert agentboundary.__version__ == _pkg_version("agentboundary")


def test_validate_receipt_is_importable_from_top_level() -> None:
    from agentboundary import validate_receipt

    assert callable(validate_receipt)


def test_load_action_receipt_schema_is_importable_from_top_level() -> None:
    from agentboundary import load_action_receipt_schema

    assert callable(load_action_receipt_schema)


def test_w3_public_surface_importable() -> None:
    import agentboundary

    assert agentboundary.ReferenceImplementation is not None
    assert agentboundary.check_conformance is not None
    assert agentboundary.load_scenario is not None
