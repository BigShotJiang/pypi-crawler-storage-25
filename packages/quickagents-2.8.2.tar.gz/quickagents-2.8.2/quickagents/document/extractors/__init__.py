"""Knowledge extraction from documents."""
