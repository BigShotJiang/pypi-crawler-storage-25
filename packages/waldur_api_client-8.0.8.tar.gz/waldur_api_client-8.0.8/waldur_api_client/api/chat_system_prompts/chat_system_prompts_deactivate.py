from http import HTTPStatus
from typing import Any, Union
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.system_prompt import SystemPrompt
from ...models.system_prompt_request import SystemPromptRequest
from ...types import Response


def _get_kwargs(
    uuid: UUID,
    *,
    body: SystemPromptRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": f"/api/chat-system-prompts/{uuid}/deactivate/",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> SystemPrompt:
    if response.status_code == 404:
        raise errors.UnexpectedStatus(response.status_code, response.content, response.url)
    if response.status_code == 200:
        response_200 = SystemPrompt.from_dict(response.json())

        return response_200
    raise errors.UnexpectedStatus(response.status_code, response.content, response.url)


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[SystemPrompt]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    uuid: UUID,
    *,
    client: AuthenticatedClient,
    body: SystemPromptRequest,
) -> Response[SystemPrompt]:
    """Deactivate the active system prompt

     Deactivate this prompt. The system will fall back to Constance overrides or built-in defaults.

    Args:
        uuid (UUID):
        body (SystemPromptRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SystemPrompt]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    uuid: UUID,
    *,
    client: AuthenticatedClient,
    body: SystemPromptRequest,
) -> SystemPrompt:
    """Deactivate the active system prompt

     Deactivate this prompt. The system will fall back to Constance overrides or built-in defaults.

    Args:
        uuid (UUID):
        body (SystemPromptRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SystemPrompt
    """

    return sync_detailed(
        uuid=uuid,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    uuid: UUID,
    *,
    client: AuthenticatedClient,
    body: SystemPromptRequest,
) -> Response[SystemPrompt]:
    """Deactivate the active system prompt

     Deactivate this prompt. The system will fall back to Constance overrides or built-in defaults.

    Args:
        uuid (UUID):
        body (SystemPromptRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SystemPrompt]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    uuid: UUID,
    *,
    client: AuthenticatedClient,
    body: SystemPromptRequest,
) -> SystemPrompt:
    """Deactivate the active system prompt

     Deactivate this prompt. The system will fall back to Constance overrides or built-in defaults.

    Args:
        uuid (UUID):
        body (SystemPromptRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SystemPrompt
    """

    return (
        await asyncio_detailed(
            uuid=uuid,
            client=client,
            body=body,
        )
    ).parsed
