from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING

from shapely.geometry import Polygon

if TYPE_CHECKING:
    from scadpy.d2.shape import Shape


def map_geometries_to_shape(geometries: Sequence[Polygon]) -> Shape:
    """Map a sequence of polygons to a shape.

    Each polygon is validated and oriented via :func:`map_parts_to_shape`.

    Parameters
    ----------
    geometries : Sequence[Polygon]
        The polygons to map.

    Returns
    -------
    Shape
        A new shape containing all valid, oriented polygons.

    """
    from scadpy.core.part import Part
    from scadpy.d2.shape import Shape

    return Shape.from_parts([Part[Polygon].from_geometry(g) for g in geometries])
