# Framework Chief

The language used when deciding which spec-driven-development tooling to install into a project and how to wire multiple tools together safely.

## Language

### Installation units

**Framework**:
An installable unit declared in an adapter file; carries its own detection markers, prerequisites, install mode, and install commands.
_Avoid_: tool, plugin, package

**Adapter**:
A `.md` file with YAML front-matter that declares all facts about a single framework.
_Avoid_: framework manifest, framework descriptor, config

**Install Mode**:
The execution strategy for a framework's install commands — `run` (fully automated), `interactive` (requires user input for configuration), or `recommend_only` (prints commands only; never executes).

**Shell Interpreter**:
The binary that executes a deployed script at runtime — `bash` on Linux/macOS, `pwsh` (or `powershell`) on Windows. Selected automatically based on platform; never configured by the user. Distinct from the script file itself.
_Avoid_: shell, runtime, executor

**Detection Marker**:
A filesystem path checked to determine whether a framework is already installed; a framework may have a primary marker and an optional alternate; `null` for plugin-based frameworks.

### Composition

**Quickstart**:
A first-artifact walkthrough authored inside a Framework's Adapter (as a `## Quickstart` markdown section in the body). Displayed once per Framework at the end of the INSTALL state, in install order. For `recommend_only` frameworks, the Quickstart is prefixed with a note that the install command must be run first.
_Avoid_: guide, tutorial, getting-started doc

**Stack**:
One or more frameworks combined with a compatibility verdict, optionally wired via a composition block or spec-kit extensions.

**Slot**:
The composition role a framework occupies — exactly one of `plan_spec`, `execute`, or `discipline`; two frameworks in the same slot always produce a RED compatibility; the set of three slots is closed and treated as a design invariant (see ADR-0007).

**Compatibility**:
The verdict assigned to a stack — GREEN (safe to combine), YELLOW (combinable but the bridge/seam needs more work, gray area), or RED (structurally invalid; immediate refusal, no clarification).

**Composition Block**:
An artifact written into `AGENTS.md` that implements Bridge 1: demotes competing framework skills, activates the discipline subset, pins versions for stale-override detection, and carries audit metadata.
_Avoid_: demotion block, bridge block

**Bridge**:
The mechanism or pattern that connects frameworks in a hybrid stack; three types exist — Bridge 1 (composition block, built), Bridge 2 (format-transform shim, deliberately not built), Bridge 3 (ingestion handoff for spec-kit → GSD-2).

### Audit

**Decision Log**:
The append-only record at `.chief/decision.md`; primary role is audit trail; secondary role is consistency oracle via `last_stack()`, which warns when a framework being installed is not part of the logged stack.

## Relationships

- A **Stack** contains one or more **Frameworks**
- Each **Framework** occupies exactly one **Slot**; two **Frameworks** in the same **Slot** → RED **Compatibility**
- A **Framework** is described by exactly one **Adapter**
- A **Framework**'s **Install Mode** governs how its install commands run
- A **Detection Marker** belongs to one **Framework**; checking it prevents re-initialisation over an existing install
- A GREEN or YELLOW hybrid **Stack** may carry one **Composition Block**; RED stacks never reach install
- A **Bridge** is the runtime mechanism behind a **Composition Block** (Bridge 1) or a migration handoff (Bridge 3)
- Every install outcome is appended to the **Decision Log**

## Example dialogue

> **Dev:** "The user wants BMAD and OpenSpec together — can we just install both?"
> **Domain expert:** "No — both claim the `plan_spec` **Slot**, so the **Compatibility** is RED. Refuse immediately and offer the closest GREEN alternative."

> **Dev:** "We installed OpenSpec and Superpowers — do we need a **Bridge**?"
> **Domain expert:** "Yes. Superpowers also wants the planning phases. Write the **Composition Block** into `AGENTS.md` now — before Superpowers loads — so its skills read the demotion rules on first run."

> **Dev:** "GSD-2's **Adapter** says `recommend_only`. Why doesn't `chief install gsd2` actually run the command?"
> **Domain expert:** "Its **Install Mode** is `recommend_only` — the CLI never executes it. It prints the command for the user to run themselves."

## Flagged ambiguities

- "bridge" and "composition block" were used interchangeably early on — resolved: **Bridge** is the abstract mechanism/pattern (three types); **Composition Block** is the concrete AGENTS.md artifact implementing Bridge 1 only.
- "YELLOW" was initially described as "works but with trade-offs" — sharpened: YELLOW means the seam/bridge needs more work; it is a gray area, not a clean combination. Prefer GREEN; only propose YELLOW when the request genuinely requires both frameworks.
