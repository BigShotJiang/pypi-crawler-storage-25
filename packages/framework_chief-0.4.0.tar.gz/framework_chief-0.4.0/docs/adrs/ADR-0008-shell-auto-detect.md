# ADR-0008 — Shell dispatch uses auto-detect, not an explicit flag

**Status:** Accepted  
**Date:** 2026-05-21

## Context

`chief init`, `chief sync`, and the install pipeline all invoke shell scripts
(`chief-install.sh`, `chief-sync.sh`) via subprocess. The tool ships paired scripts:
a `.sh` for bash (Linux/macOS) and a `.ps1` for PowerShell 7+ (Windows).

Two designs were considered for selecting the right interpreter:

1. **Explicit flag / config** — user passes `--shell pwsh` or sets a config key.
   Gives full user control; makes the choice visible in `--help`.

2. **Auto-detect** — inspect `sys.platform == "win32"` and
   `shutil.which("pwsh") / shutil.which("powershell")` at runtime; pick the
   interpreter silently; raise `RuntimeError` with an install hint if nothing is found.

## Decision

**Auto-detect** (`_shell_cmd` in `src/framework_chief/_shell.py`).

The tool targets developers who `pip install framework-chief` and run `chief init`
immediately. Requiring a `--shell` flag on every invocation adds ceremony for a
decision the OS already encodes. Every target platform has exactly one correct
interpreter; there is no legitimate reason for a Windows user to invoke bash or a
Linux user to invoke PowerShell.

The explicit-flag design would require every calling site (CLI, phases, future
subcommands) to thread the flag through its argument chain — an ongoing maintenance
cost with no user benefit.

If `shutil.which` cannot find any interpreter on Windows, `_shell_cmd` raises
`RuntimeError` immediately with an actionable message rather than letting the
subprocess fail with a cryptic OS error.

## Consequences

- No `--shell` flag exists and none should be added without reopening this ADR.
- `_shell_cmd` is the single dispatch point; callsites must not hardcode `"bash"`.
- The `.ps1` sibling lookup (`script.with_suffix(".ps1")`) is the extension contract:
  adding Windows support for a new script means shipping a `.ps1` alongside the `.sh`.
- `_split_cmd` uses `cmd_str.split()` on Windows instead of `shlex.split()` (POSIX
  quoting rules break on Windows paths). This is safe only because bundled adapter
  `install_commands` strings have no spaces within individual arguments. If the adapter
  format ever opens to user-authored adapters, `_split_cmd` must be revisited.
- Auto-detect is tested by monkeypatching `sys.platform` and `shutil.which` in
  `tests/unit/test_shell.py`.
