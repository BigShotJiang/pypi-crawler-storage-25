"""checks.py — Prerequisite checking for framework-chief.

Pure domain logic: no Rich, no argparse, no console I/O.
The caller (cli.py) is responsible for rendering CheckItem lists.
"""

from __future__ import annotations

import re
import subprocess  # nosec B404
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from framework_chief.stacks import FrameworkMeta, Stack


class CheckLevel(Enum):
    OK = "ok"
    MISS_SOFT = "miss"  # soft miss: one candidate in an OR-group was absent
    MISS = "MISS"  # hard miss: required prerequisite absent
    NOTE = "note"
    WARN = "warn"


@dataclass
class CheckItem:
    level: CheckLevel
    message: str

    def to_str(self) -> str:
        return f"  {self.level.value:<6}{self.message}"


@dataclass
class ToolCheck:
    ok: bool
    message: str


def parse_version(raw: str) -> tuple[int, int] | None:
    """Parse 'v20.19.0', 'Python 3.11.2', '1.2.3' → (major, minor) or None."""
    ver_str = raw.lstrip("vV")
    if ver_str.lower().startswith("python "):
        ver_str = ver_str[7:]
    m = re.search(r"(\d+)\.(\d+)", ver_str)
    if not m:
        return None
    return int(m.group(1)), int(m.group(2))


def check_tool(tool: str, min_version: str | None) -> ToolCheck:
    """Handles 'v20.19.0' node output format."""
    try:
        result = subprocess.run(  # nosec B603
            [tool, "--version"],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except FileNotFoundError:
        return ToolCheck(False, f"{tool}: not found")
    except subprocess.TimeoutExpired:
        return ToolCheck(False, f"{tool}: timed out")

    raw = (result.stdout + result.stderr).strip().split("\n")[0].strip()
    if min_version is None:
        return ToolCheck(True, f"{tool}: present ({raw})")

    parsed = parse_version(raw)
    if parsed is None:
        return ToolCheck(False, f"{tool}: version unrecognized: '{raw}'")

    actual_maj, actual_min = parsed
    req_parts = min_version.split(".")
    req_maj = int(req_parts[0])
    req_min = int(req_parts[1]) if len(req_parts) > 1 else 0

    meets = actual_maj > req_maj or (actual_maj == req_maj and actual_min >= req_min)
    if meets:
        return ToolCheck(True, f"{tool}: {actual_maj}.{actual_min} >= {min_version} OK")
    return ToolCheck(
        False, f"{tool}: {actual_maj}.{actual_min} < {min_version} required"
    )


def check_framework(
    fw: FrameworkMeta,
    project: Path,
    last_stack: str | None = None,
    *,
    stacks: dict[str, Stack],
) -> tuple[bool, list[CheckItem]]:
    """Return (ok, items). ok=False means a prerequisite is missing.

    last_stack — most recently logged stack name from decision.md, used to
    warn when a framework is not part of the logged stack. Caller supplies it
    so this module has no dependency on DecisionLog.
    stacks — injected from the caller; no hidden REGISTRY dependency.
    """
    items: list[CheckItem] = []
    ok = True

    for tool, min_ver in fw.prerequisites.items():
        tc = check_tool(tool, min_ver)
        level = CheckLevel.OK if tc.ok else CheckLevel.MISS
        items.append(CheckItem(level, tc.message))
        if not tc.ok:
            ok = False

    if fw.prerequisite_any:
        found_any = False
        any_items: list[CheckItem] = []
        for tool in fw.prerequisite_any:
            tc = check_tool(tool, None)
            level = CheckLevel.OK if tc.ok else CheckLevel.MISS_SOFT
            any_items.append(CheckItem(level, tc.message))
            if tc.ok:
                found_any = True
        items.extend(any_items)
        if not found_any:
            tools_str = ", ".join(fw.prerequisite_any)
            items.append(
                CheckItem(CheckLevel.MISS, f"need at least one of: {tools_str}")
            )
            ok = False

    for marker in (fw.detection_marker, fw.detection_marker_alt):
        if marker and (project / marker).exists():
            items.append(
                CheckItem(
                    CheckLevel.NOTE,
                    f"already installed — {marker}/ exists",
                )
            )
            if last_stack is not None:
                stack = stacks.get(last_stack)
                members = stack.members if stack else []
                if fw.name not in members:
                    items.append(
                        CheckItem(
                            CheckLevel.WARN,
                            f"decision.md logs stack '{last_stack}'"
                            f" — {fw.name} is not part of that stack"
                            " (may be installed for a different project)",
                        )
                    )

    return ok, items
