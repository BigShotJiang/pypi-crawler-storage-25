#!/usr/bin/env pwsh
# chief-install — the mechanical half of the Framework Chief's INSTALL state.
#
# This script does ONLY deterministic, context-free work: prerequisite checks,
# existing-install detection, running install commands, appending to the decision log.
# It makes no decisions. The agent decides WHAT to install and WHETHER to proceed;
# this script only executes what was already decided and already approved at the gate.
#
# Subcommands:
#   init                   bootstrap .chief/ directory and decision.md. Run once per project.
#   check <framework>      verify prereqs + detect existing install. Exit 0 = clear to go.
#   dry-run <stack>        print the exact command sequence (feeds the AGREE gate). No mutation.
#   install <framework>    run the install commands for one framework, echoing each. MUTATES.
#   log <key=val>...       append one structured entry to .chief/decision.md.
#
# Frameworks: spec-kit | openspec | bmad | superpowers | gsd2
# Stacks:     spec-kit | openspec | bmad | gsd2
#             openspec-superpowers | bmad-superpowers | spec-kit-gsd2
#
# Usage:  .\scripts\chief-install.ps1 <subcommand> [args]   (run from project root)

param(
    [string]$Subcommand = "",
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$Rest
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$ROOT = (Get-Location).Path
$CHIEF_DIR = Join-Path $ROOT ".chief"
$DECISION_LOG = Join-Path $CHIEF_DIR "decision.md"

# --- Helper functions --------------------------------------------------------
function Say {
    param([string]$Message)
    Write-Host $Message
}

function Ok {
    param([string]$Message)
    Write-Host "  ok    $Message"
}

function Miss {
    param([string]$Message)
    $host.UI.WriteErrorLine("  MISS  $Message")
}

function Err {
    param([string]$Message)
    $host.UI.WriteErrorLine("  ERROR $Message")
}

function Run {
    param([string[]]$Command)
    Write-Host "  `$ $($Command -join ' ')"
    $exe, $rest = $Command
    & $exe @rest
}

function Have {
    param([string]$CommandName)
    $null = Get-Command -Name $CommandName -ErrorAction SilentlyContinue
    return $?
}

# --- init: bootstrap .chief/ on a fresh project ----------------------------
function Invoke-Init {
    $null = New-Item -ItemType Directory -Force -Path (Join-Path $CHIEF_DIR "adapters")
    $null = New-Item -ItemType Directory -Force -Path (Join-Path $CHIEF_DIR "composition-blocks")

    if (Test-Path $DECISION_LOG) {
        Say "init: .chief/ already exists — skipping"
        return
    }

    $content = @"
# Framework Chief — Decision Log

Append-only audit log. Each entry records one install event: what stack was chosen,
why, what commands ran, and any deviations from the standard flow.

Do not edit existing entries.

---
"@

    Set-Content -Path $DECISION_LOG -Value $content
    Say "init: .chief/ bootstrapped. decision.md created."
}

# --- prerequisite + existing-install checks --------------------------------
function Invoke-Check {
    param([string]$Framework)

    if ([string]::IsNullOrWhiteSpace($Framework)) {
        Say "usage: check <framework>"
        exit 2
    }

    Say "check: $Framework"
    $fail = 0

    switch ($Framework) {
        "spec-kit" {
            if (Have python3) {
                $version = & python3 --version 2>&1 | ForEach-Object { ($_ -split ' ')[1] }
                Ok "python3 $version"
            } else {
                Miss "python3 (need 3.11+)"
                $fail = 1
            }

            if (Have uv) {
                Ok "uv present"
            } elseif (Have pipx) {
                Ok "pipx present (uv preferred but pipx works)"
            } else {
                Miss "neither uv nor pipx — install uv: https://docs.astral.sh/uv/"
                $fail = 1
            }

            if (Have git) {
                Ok "git present"
            } else {
                Miss "git"
                $fail = 1
            }

            if (Test-Path (Join-Path $ROOT ".specify")) {
                Miss "already initialized — .specify/ exists"
                exit 3
            }
        }
        "openspec" {
            if (Have node) {
                $version = & node --version
                Ok "node $version"
            } else {
                Miss "node (need 20.19+)"
                $fail = 1
            }

            if (Have npm) {
                Ok "npm present"
            } else {
                Miss "npm"
                $fail = 1
            }

            if (Have git) {
                Ok "git present"
            } else {
                Miss "git"
                $fail = 1
            }

            if (Test-Path (Join-Path $ROOT "openspec")) {
                Miss "already initialized — openspec/ exists"
                exit 3
            }
        }
        "bmad" {
            if (Have node) {
                $version = & node --version
                Ok "node $version"
            } else {
                Miss "node (need 20+)"
                $fail = 1
            }

            if (Have git) {
                Ok "git present"
            } else {
                Miss "git"
                $fail = 1
            }

            $bmadPath1 = Join-Path $ROOT "_bmad"
            $bmadPath2 = Join-Path $ROOT ".bmad"
            if ((Test-Path $bmadPath1) -or (Test-Path $bmadPath2)) {
                Miss "already installed — _bmad/ or .bmad/ exists"
                exit 3
            }
        }
        "superpowers" {
            if (Have git) {
                Ok "git present"
            } else {
                Miss "git"
                $fail = 1
            }
            Say "  note  Superpowers installs per-harness via plugin marketplace — see .chief/adapters/superpowers.md"
            Say "  note  install LAST in a hybrid, after the composition block is written to AGENTS.md"
        }
        "gsd2" {
            if (Have node) {
                $version = & node --version
                Ok "node $version"
            } else {
                Miss "node (need 20.6+)"
                $fail = 1
            }

            if (Test-Path (Join-Path $ROOT ".gsd")) {
                Miss "GSD-2 already manages this project — .gsd/ exists"
                $fail = 1
            }

            Say "  note  GSD-2 is recommend-only — this script will NOT auto-run its global install"
        }
        default {
            Err "unknown framework: $Framework"
            exit 2
        }
    }

    if ($fail -ne 0) {
        Err "check: $Framework — NOT clear. Stop and report to the user."
        exit 1
    }
    Say "check: $Framework — clear."
}

# --- the command sequences (single source for dry-run and install) ---------
function Get-CommandsFor {
    param([string]$Framework)

    switch ($Framework) {
        "spec-kit" {
            @(
                "uv tool install specify-cli --from git+https://github.com/github/spec-kit.git",
                "specify init --here --force"
            )
        }
        "openspec" {
            @(
                "npm install -g @fission-ai/openspec@latest",
                "openspec init --tools claude"
            )
        }
        "bmad" {
            @(
                "npx bmad-method install"
            )
        }
        "superpowers" {
            @(
                "# Claude Code:",
                "/plugin marketplace add obra/superpowers-marketplace",
                "/plugin install superpowers@superpowers-marketplace",
                "# Codex / Copilot CLI / others: install per-harness from the plugin marketplace"
            )
        }
        "gsd2" {
            @(
                "# RECOMMEND ONLY — user runs this themselves:",
                "npm install -g gsd-pi",
                "gsd   # then /login"
            )
        }
        default {
            Err "unknown framework: $Framework"
            exit 1
        }
    }
}

# --- dry-run: print the full sequence for a stack, no mutation -------------
function Invoke-DryRun {
    param([string]$Stack)

    if ([string]::IsNullOrWhiteSpace($Stack)) {
        Say "usage: dry-run <stack>"
        exit 2
    }

    Say "dry-run: $Stack"
    Say "the AGREE gate should show the user exactly this:"
    Say ""

    switch ($Stack) {
        { @("spec-kit", "openspec", "bmad", "gsd2") -contains $_ } {
            Say "[$Stack]"
            Get-CommandsFor $Stack | ForEach-Object { Say "  $_" }
        }
        "openspec-superpowers" {
            Say "install order: openspec, then composition block, then superpowers"
            Say "[openspec]"
            Get-CommandsFor "openspec" | ForEach-Object { Say "  $_" }
            Say "[composition block] write .chief/composition-blocks/openspec-superpowers.md into AGENTS.md"
            Say "[superpowers]"
            Get-CommandsFor "superpowers" | ForEach-Object { Say "  $_" }
        }
        "bmad-superpowers" {
            Say "install order: bmad, then composition block, then superpowers"
            Say "[bmad]"
            Get-CommandsFor "bmad" | ForEach-Object { Say "  $_" }
            Say "[composition block] write .chief/composition-blocks/bmad-superpowers.md into AGENTS.md"
            Say "[superpowers]"
            Get-CommandsFor "superpowers" | ForEach-Object { Say "  $_" }
        }
        "spec-kit-gsd2" {
            Say "this is a migration handoff, not a co-running stack"
            Say "[spec-kit]"
            Get-CommandsFor "spec-kit" | ForEach-Object { Say "  $_" }
            Say "[handoff]  run spec-kit through /speckit.plan, then seed GSD-2 context from specs/ — see .chief/adapters/gsd2.md"
            Say "[gsd2]"
            Get-CommandsFor "gsd2" | ForEach-Object { Say "  $_" }
        }
        "superpowers" {
            Say "[superpowers]"
            Get-CommandsFor "superpowers" | ForEach-Object { Say "  $_" }
        }
        { @("spec-kit-superpowers", "spec-kit-superpowers-bridge") -contains $_ } {
            Say "install order: spec-kit, then superpowers-bridge extension"
            Say "note: spec-kit's constitution already enforces TDD + code review natively."
            Say "      this is YELLOW — use only when enforced testing discipline is explicitly needed."
            Say "[spec-kit]"
            Get-CommandsFor "spec-kit" | ForEach-Object { Say "  $_" }
            Say "[superpowers-bridge]  specify extension add superpowers-bridge"
        }
        "spec-kit-fleet" {
            Say "install order: spec-kit, then fleet extension"
            Say "[spec-kit]"
            Get-CommandsFor "spec-kit" | ForEach-Object { Say "  $_" }
            Say "[fleet extension]  specify extension add fleet"
        }
        "spec-kit-product-forge" {
            Say "install order: spec-kit, then product-forge extension"
            Say "[spec-kit]"
            Get-CommandsFor "spec-kit" | ForEach-Object { Say "  $_" }
            Say "[product-forge extension]  specify extension add product-forge"
        }
        "spec-kit-canon" {
            Say "install order: spec-kit, then canon extension"
            Say "[spec-kit]"
            Get-CommandsFor "spec-kit" | ForEach-Object { Say "  $_" }
            Say "[canon extension]  specify extension add canon"
        }
        "spec-kit-brownfield" {
            Say "install order: spec-kit, then brownfield extension"
            Say "[spec-kit]"
            Get-CommandsFor "spec-kit" | ForEach-Object { Say "  $_" }
            Say "[brownfield extension]  specify extension add brownfield"
        }
        "spec-kit-brownkit" {
            Say "install order: spec-kit, then brownkit extension"
            Say "[spec-kit]"
            Get-CommandsFor "spec-kit" | ForEach-Object { Say "  $_" }
            Say "[brownkit extension]  specify extension add brownkit"
        }
        "spec-kit-ralph" {
            Say "install order: spec-kit, then ralph extension"
            Say "[spec-kit]"
            Get-CommandsFor "spec-kit" | ForEach-Object { Say "  $_" }
            Say "[ralph extension]  specify extension add ralph"
        }
        default {
            Err "unknown stack: $Stack"
            exit 2
        }
    }

    Say ""
    $date = (Get-Date).ToString('yyyy-MM-dd')
    Say "[log] .\scripts\chief-install.ps1 log stack=$Stack date=$date ..."
    Say ""
    Say "dry-run: nothing was executed."
}

# --- install: run the commands for ONE framework, echoing each ------------
function Invoke-Install {
    param([string]$Framework)

    if ([string]::IsNullOrWhiteSpace($Framework)) {
        Say "usage: install <framework>"
        exit 2
    }

    if ($Framework -eq "gsd2") {
        Say "install: gsd2 — RECOMMEND ONLY. Not auto-running. Give the user:"
        Get-CommandsFor "gsd2" | ForEach-Object { Say "  $_" }
        exit 0
    }

    if ($Framework -eq "superpowers") {
        Say "install: superpowers — per-harness plugin install, not a shell command."
        Say "Give the user the marketplace steps:"
        Get-CommandsFor "superpowers" | ForEach-Object { Say "  $_" }
        exit 0
    }

    # Validate prereqs before touching anything.
    try {
        Invoke-Check $Framework
    } catch {
        Err "install aborted: check failed for $Framework"
        exit 1
    }

    Say "install: $Framework — running. Each command is echoed before it runs."

    $commands = Get-CommandsFor $Framework
    foreach ($cmd in $commands) {
        # Skip comments and empty lines
        if ($cmd -match '^\s*#.*$' -or [string]::IsNullOrWhiteSpace($cmd)) {
            continue
        }

        # Execute the command
        Write-Host "  `$ $cmd"
        $exe, $rest = $cmd -split '\s+'
        & $exe @rest
    }

    Say "install: $Framework — done."
}

# --- log: append one entry to the decision log ----------------------------
function Invoke-Log {
    param([string[]]$Pairs = @())

    # Auto-bootstrap if needed so log never hard-errors on a fresh repo.
    if (-not (Test-Path $DECISION_LOG)) {
        Say "log: .chief/decision.md not found — running init first"
        Invoke-Init
    }

    if (-not $Pairs) {
        Err "log: requires at least one key=value argument"
        exit 2
    }

    # Validate all arguments before appending
    foreach ($kv in $Pairs) {
        if ($kv -notmatch '=') {
            Err "log: malformed argument '$kv' — expected key=value format"
            exit 2
        }

        $key = $kv -split '=' | Select-Object -First 1
        $val = $kv -split '=', 2 | Select-Object -Last 1

        if ([string]::IsNullOrEmpty($val)) {
            Err "log: empty value for key '$key'"
            exit 2
        }

        if ($key -notmatch '^[A-Za-z0-9_-]+$') {
            Err "log: invalid key '$key' — keys must match [A-Za-z0-9_-]+"
            exit 2
        }

        if ($val -match '\n') {
            Err "log: newline in value for key '$key'"
            exit 2
        }
    }

    # Append the entry
    $date = (Get-Date).ToString('yyyy-MM-dd')
    $content = @(
        "",
        "### $date — install event"
    )

    foreach ($kv in $Pairs) {
        $key = $kv -split '=' | Select-Object -First 1
        $val = $kv -split '=', 2 | Select-Object -Last 1
        $content += "- **${key}:** $val"
    }

    Add-Content -Path $DECISION_LOG -Value $content
    Say "log: appended entry to .chief/decision.md"
}

# --- dispatch --------------------------------------------------------------
switch ($Subcommand) {
    "init" {
        Invoke-Init
    }
    "check" {
        Invoke-Check @Rest
    }
    "dry-run" {
        Invoke-DryRun @Rest
    }
    "install" {
        Invoke-Install @Rest
    }
    "log" {
        Invoke-Log @Rest
    }
    default {
        Write-Host @"
chief-install — the mechanical half of the Chief's INSTALL state.

  init                  bootstrap .chief/ directory and decision.md (run once)
  check <framework>     verify prereqs + detect existing install
  dry-run <stack>       print the command sequence (feeds the AGREE gate)
  install <framework>   run the install commands for one framework
  log <key=val>...      append an entry to .chief/decision.md

frameworks: spec-kit openspec bmad superpowers gsd2
stacks:     spec-kit openspec bmad gsd2
            openspec-superpowers bmad-superpowers spec-kit-gsd2
"@
        exit 2
    }
}
