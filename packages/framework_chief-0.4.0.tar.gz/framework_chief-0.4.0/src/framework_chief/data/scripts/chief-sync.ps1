#!/usr/bin/env pwsh
# chief-sync — propagate the Framework Chief router to every coding agent's expected path.
#
# AGENTS.md is the single source of truth (read natively by Codex, Copilot, Cursor, etc.).
# This script makes Claude Code and GitHub Copilot pick up the same router without
# duplicating its content.
#
# Usage:  .\scripts\chief-sync.ps1 [--ai VENDOR] [ProjectRoot]
#         VENDOR: all (default), claude, copilot, codex
#         PROJECT_ROOT defaults to the current directory.
#
# Arguments use POSIX double-dash style (--ai) so the Python subprocess caller
# can pass uniform args on all platforms without platform-specific branching.

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Parse POSIX-style arguments: [--ai VENDOR] [PROJECT_ROOT]
# PowerShell param() only binds single-dash (-Ai); Python passes --ai (double-dash).
$Ai = "all"
$ProjectRoot = (Get-Location).Path

$i = 0
while ($i -lt $args.Count) {
    if ($args[$i] -eq "--ai") {
        if (($i + 1) -ge $args.Count) {
            Write-Error "error: --ai requires a value" -ErrorAction Stop
            exit 1
        }
        $Ai = $args[$i + 1]
        $i += 2
    } else {
        $ProjectRoot = $args[$i]
        $i++
    }
}

if (@("all", "claude", "copilot", "codex") -notcontains $Ai) {
    Write-Error "error: --ai must be one of: all, claude, copilot, codex" -ErrorAction Stop
    exit 1
}

$AGENTS = Join-Path $ProjectRoot "AGENTS.md"

if (-not (Test-Path $AGENTS)) {
    Write-Error "error: $AGENTS not found — the chief router must exist before syncing." -ErrorAction Stop
    exit 1
}

Write-Host "chief-sync: source of truth = $AGENTS  (--ai=$Ai)"

# --- Claude Code: CLAUDE.md overlay + /chief slash command ------------------
if ($Ai -eq "all" -or $Ai -eq "claude") {
    $CLAUDE = Join-Path $ProjectRoot "CLAUDE.md"
    $OVERLAY_MARKER = "@AGENTS.md"

    if ((Test-Path $CLAUDE) -and (Get-Item $CLAUDE).LinkType -ne "SymbolicLink") {
        # Check if file exists and contains the overlay marker
        $content = Get-Content $CLAUDE -Raw -ErrorAction SilentlyContinue
        if ($content -and $content.Contains($OVERLAY_MARKER)) {
            Write-Host "  CLAUDE.md       already a real overlay file — ok"
        } elseif ($content) {
            Write-Host "  CLAUDE.md       exists without overlay marker — leaving it alone." -ForegroundColor Yellow
            Write-Host "                  (add '@AGENTS.md' to it, or rm and re-run)" -ForegroundColor Yellow
        } else {
            # File exists but is empty
            $overlay = @"
# Framework Chief — Claude Code overlay

@AGENTS.md

<!-- Claude Code-specific additions below.
     Add tool-use hooks, memory instructions, or harness mechanics here.
     Currently empty — AGENTS.md base is sufficient for Claude Code. -->
"@
            Set-Content -Path $CLAUDE -Value $overlay
            Write-Host "  CLAUDE.md       overlay file written"
        }
    } elseif ((Test-Path $CLAUDE) -and (Get-Item $CLAUDE).LinkType -eq "SymbolicLink") {
        # Replace symlink with real file
        Remove-Item $CLAUDE -Force
        $overlay = @"
# Framework Chief — Claude Code overlay

@AGENTS.md

<!-- Claude Code-specific additions below.
     Add tool-use hooks, memory instructions, or harness mechanics here.
     Currently empty — AGENTS.md base is sufficient for Claude Code. -->
"@
        Set-Content -Path $CLAUDE -Value $overlay
        Write-Host "  CLAUDE.md       symlink replaced with real overlay file"
    } else {
        # File doesn't exist
        $overlay = @"
# Framework Chief — Claude Code overlay

@AGENTS.md

<!-- Claude Code-specific additions below.
     Add tool-use hooks, memory instructions, or harness mechanics here.
     Currently empty — AGENTS.md base is sufficient for Claude Code. -->
"@
        Set-Content -Path $CLAUDE -Value $overlay
        Write-Host "  CLAUDE.md       overlay file written"
    }

    $commandsDir = Join-Path $ProjectRoot ".claude" "commands"
    $null = New-Item -ItemType Directory -Force -Path $commandsDir

    $chiefCmd = @"
---
description: Invoke the Framework Chief — decide and install the right framework stack.
---
Read AGENTS.md and act as the Framework Chief defined there. Run the loop:
classify the user's request, clarify if confidence is low, present the AGREE gate,
and only install after explicit confirmation.

User request:
`$ARGUMENTS
"@

    Set-Content -Path (Join-Path $commandsDir "chief.md") -Value $chiefCmd
    Write-Host "  .claude/commands/chief.md   written"
}

# --- GitHub Copilot: pointer file -------------------------------------------
if ($Ai -eq "all" -or $Ai -eq "copilot") {
    $null = New-Item -ItemType Directory -Force -Path (Join-Path $ProjectRoot ".github")
    $COPILOT = Join-Path $ProjectRoot ".github" "copilot-instructions.md"
    $CHIEF_MARKER = "<!-- framework-chief-block -->"

    if ((Test-Path $COPILOT) -and (Get-Content $COPILOT -Raw).Contains($CHIEF_MARKER)) {
        Write-Host "  .github/copilot-instructions.md   already contains Framework Chief block — skipping"
    } elseif (Test-Path $COPILOT) {
        $existing = Get-Content $COPILOT -Raw
        $block = @"

$CHIEF_MARKER
## Framework Chief

This project uses the **Framework Chief**. The full router, rubric, compatibility
matrix, and install protocol live in `/AGENTS.md` at the repository root — read it
and follow it as the authority for any framework-selection or install request.
$CHIEF_MARKER
"@
        Add-Content -Path $COPILOT -Value $block
        Write-Host "  .github/copilot-instructions.md   Framework Chief block appended (existing rules preserved)"
    } else {
        $copilotInstructions = @"
# Copilot Instructions

$CHIEF_MARKER
## Framework Chief

This project uses the **Framework Chief**. The full router, rubric, compatibility
matrix, and install protocol live in `/AGENTS.md` at the repository root — read it
and follow it as the authority for any framework-selection or install request.
$CHIEF_MARKER

For Copilot-specific behavior, add rules below this line.
"@
        Set-Content -Path $COPILOT -Value $copilotInstructions
        Write-Host "  .github/copilot-instructions.md   written"
    }
}

# --- Codex: prompt entry (optional slash trigger) ---------------------------
if ($Ai -eq "all" -or $Ai -eq "codex") {
    $null = New-Item -ItemType Directory -Force -Path (Join-Path $ProjectRoot ".codex" "prompts")
    $codexPrompt = @"
Read AGENTS.md and act as the Framework Chief defined there. Run the classify →
clarify → agree → install loop. Do not install before the AGREE gate passes.
"@
    Set-Content -Path (Join-Path $ProjectRoot ".codex" "prompts" "chief.md") -Value $codexPrompt
    Write-Host "  .codex/prompts/chief.md   written"
}

Write-Host "chief-sync: done."
