---
name: bmad
slot: plan_spec
detection_marker: _bmad
detection_marker_alt: .bmad
prerequisites:
  node: "20.0"
  git: null
install_mode: interactive
install_commands:
  - "npx bmad-method install"
---

# Adapter: bmad

BMAD (bmad-code-org/BMAD-METHOD) occupies the **Plan/Spec slot** but is also a **full
rail** — it runs its own brainstorm → plan → execute flow and forces the next phase.
Choose BMAD when the gap is process and role discipline: lots of discovery work, full
lifecycle structure, multi-role handoffs.

## Prerequisites

| Tool | Minimum | Check |
|------|---------|-------|
| node | 20+ | `node --version` |
| git | any | `git --version` |

## Existing install detection

`_bmad/` or `.bmad/` directory at project root. If either exists, do not re-init.

## Install commands

```bash
npx bmad-method install
```

## Artifacts created

| Path | Purpose |
|------|---------|
| `_bmad/` or `.bmad/` | BMAD configuration, role templates, workflow files |

## Routing-relevant modules

These modules change a Framework Chief routing or composition decision. They are not
general workflow enhancements — they affect which stack to recommend or how to configure
BMAD for the specific request.

| Module | When it changes routing |
|---|---|
| **Test Architect (TEA)** | Testing-heavy project with BMAD — add TEA instead of composing with Superpowers for test discipline. TEA provides a dedicated test-architect persona within BMAD's rail; Superpowers' `tdd` skill becomes redundant and the YELLOW BMAD+Superpowers warning applies. Discriminator: if the user's primary gap is test architecture *within* a multi-role BMAD workflow, TEA is the lower-friction path. |
| **Game Dev Studio (BMGD)** | Unity / Unreal / Godot projects — route to BMAD + BMGD rather than generic BMAD or OpenSpec when the project is a game with multi-role structure (design, engineering, QA). BMGD adds game-domain personas and asset/scene conventions. |
| **Creative Intelligence Suite (CIS)** | Innovation, ideation, or creative product work — route to BMAD + CIS when the project is exploratory and benefits from BMAD's multi-role discovery but needs creative-domain prompting (brand, UX innovation, content). Standard BMAD roles are engineering-centric; CIS replaces them for creative contexts. |
| **BMad Builder (BMB)** | User wants to customize BMAD personas for a domain not covered by existing modules — BMB lets the user define their own agent persona set. Surface this when the user describes a domain-specific workflow that does not map cleanly to BMAD's defaults and no existing module covers it. |

Install any module during or after `npx bmad-method install` — follow BMAD's module-install
prompts or add them manually per the BMAD documentation.

## Composition notes

**BMAD is a full rail.** It runs its own planning phases. Composing with Superpowers
is YELLOW — it works, but requires surgical disabling on *both* sides. This is an
advanced combination; only propose it when the user explicitly needs BMAD's role/process
discipline AND Superpowers' TDD enforcement.

The demotion block for BMAD + Superpowers is in
`.chief/composition-blocks/bmad-superpowers.md`. It turns off BMAD's execution phases
(so Superpowers can own execution discipline) and turns off Superpowers' planning/brainstorm
phases (so BMAD can own planning). This requires careful version-awareness — if BMAD or
Superpowers rename skills between versions, update the block accordingly.

Install order: BMAD first → write composition block into AGENTS.md → Superpowers.

Never compose with spec-kit or OpenSpec (same Plan/Spec slot).
Never compose with GSD-2 (both want to own execution).

## Quickstart

After `npx bmad-method install`, open your project in your AI IDE and orient with:

```
bmad-help
```

This agent inspects your project and routes you to the right starting persona. For most greenfield projects, proceed with the Product Manager role to create your first PRD:

```
bmad-prd
```

The PM persona guides you through requirements gathering and outputs `prd.md` with decision logs.

For faster iteration on an existing codebase, skip straight to the Developer agent:

```
bmad-quick-dev
```

This creates a technical specification and begins implementation planning. After the first artifact is created, BMAD routes you through Architecture → Design → Implementation with explicit role handoffs at each gate.

More info: https://github.com/bmad-code-org/BMAD-METHOD
