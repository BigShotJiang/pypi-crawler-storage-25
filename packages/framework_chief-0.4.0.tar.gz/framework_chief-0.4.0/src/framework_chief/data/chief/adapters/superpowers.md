---
name: superpowers
slot: discipline
detection_marker: null
prerequisites:
  git: null
install_mode: recommend_only
install_commands:
  - "/plugin marketplace add obra/superpowers-marketplace"
  - "/plugin install superpowers@superpowers-marketplace"
---

# Adapter: superpowers

Superpowers (obra/superpowers) occupies the **Discipline slot**. It is not a planning
layer — it enforces *how* each unit of work is done: TDD, code review, debugging protocol.
It is a full rail with its own brainstorm → plan → execute flow, which means composing it
with a Plan/Spec layer REQUIRES a demotion block.

## Prerequisites

| Tool | Requirement |
|------|------------|
| git | any |
| agent harness | Claude Code, Codex, or compatible harness with plugin support |

## Install — NOT a shell command

Superpowers installs per-harness via the plugin marketplace. It cannot be installed with
a shell command. The install step for the agent is to give the user these instructions:

**Claude Code:**
```
/plugin marketplace add obra/superpowers-marketplace
/plugin install superpowers@superpowers-marketplace
```

**Other harnesses (Codex, Copilot CLI, etc.):**
Install via the harness's own plugin marketplace. Refer to the Superpowers README for
harness-specific instructions.

## CRITICAL: install order in a hybrid

**Always install Superpowers LAST.** The composition block must be written to AGENTS.md
*before* Superpowers runs for the first time. Superpowers reads AGENTS.md on startup;
if the demotion block is absent, it will activate all skills including the planning-phase
skills that collide with the Plan/Spec layer.

## The priority rule

Superpowers' own documented rule: **user instructions in AGENTS.md outrank skills.**
The demotion block exploits this rule — it is an AGENTS.md block that turns specific
skills OFF. This is the mechanism behind Bridge 1 (see AGENTS.md § Bridges).

## Discipline skills (keep ON in all hybrids)

These skills do not conflict with any Plan/Spec layer and should remain active:

- `tdd` — test-driven development enforcement
- `code-review` — structured code review protocol
- `debugging` — systematic debugging process
- `refactoring` — safe refactoring discipline

## Planning-phase skills (turn OFF in hybrids via demotion block)

These skills conflict with the Plan/Spec layer and must be disabled in a hybrid:

- `writing-plans` — **exception:** in OpenSpec+Superpowers, this stays ON and reads
  OpenSpec's `specs/` + `design/` directly. See the composition block.
- `brainstorm` — disable when a Plan/Spec layer owns discovery
- Any skill that generates a spec, plan, or task list

## Version-pin warning

Superpowers renames and consolidates skills between versions. If the demotion block
names a skill that no longer exists, the mismatch is silent — the old name is ignored
rather than erroring. After any Superpowers upgrade, re-verify that the skill names in
`.chief/composition-blocks/*.md` still match the installed version's skill list.

## Quickstart

> Install the plugin first (see commands above), then:

Clarify requirements and explore your design before writing any code:

```
/brainstorm
```

Once you've sketched the approach, break the work into small testable chunks:

```
/write-plan
```

Execute the plan — Superpowers enforces RED-GREEN-REFACTOR TDD within each task and adds code-review checkpoints between tasks:

```
/execute-plan
```

For a standalone discipline skill (no full plan), invoke directly:

```
/tdd          # enforce test-first on the current task
/code-review  # structured review of recent changes
/debugging    # systematic debugging protocol
```

More info: https://github.com/obra/superpowers
