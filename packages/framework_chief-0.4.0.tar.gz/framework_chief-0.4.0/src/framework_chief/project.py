"""project.py — ProjectLayout: named paths for an initialized project root."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ProjectLayout:
    root: Path

    @property
    def agents_md(self) -> Path:
        return self.root / "AGENTS.md"

    @property
    def chief_dir(self) -> Path:
        return self.root / ".chief"

    @property
    def decision_log(self) -> Path:
        return self.root / ".chief" / "decision.md"

    @property
    def scripts_dir(self) -> Path:
        return self.root / "scripts"

    @property
    def claude_md(self) -> Path:
        return self.root / "CLAUDE.md"
