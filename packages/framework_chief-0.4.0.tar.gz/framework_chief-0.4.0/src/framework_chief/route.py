"""route.py — Interactive routing loop for `chief route`.

Sends the user's project description to an AI provider with AGENTS.md as
the system prompt, runs the classify→clarify→agree conversation, and on
AGREE prints the recommended stack with next-step commands.

Supported providers:
  anthropic — Claude (default). pip install 'framework-chief[route]'
  openai    — GPT-4o / OpenAI API.  Same extra.
  github    — GitHub Copilot via GitHub Models API. Same extra.
"""

from __future__ import annotations

import os
import re
import sys
from pathlib import Path

DEFAULT_MODEL = "claude-sonnet-4-6"
MAX_SENTINEL_RETRIES = 3
MAX_LOOP_ITERATIONS = 20

# (default_model, env_var_name)
_PROVIDER_DEFAULTS: dict[str, tuple[str, str]] = {
    "anthropic": ("claude-sonnet-4-6", "ANTHROPIC_API_KEY"),
    "openai": ("gpt-4o", "OPENAI_API_KEY"),
    "github": ("openai/gpt-4o", "GITHUB_TOKEN"),
}

_GITHUB_BASE_URL = "https://models.inference.ai.azure.com"

# Valid state and verdict values per AGENTS.md
_VALID_STATES = frozenset(("AGREE", "CLARIFY", "REFUSE", "NO_FRAMEWORK"))
_VALID_VERDICT_PATTERNS = frozenset(
    (
        # Stack slugs
        "openspec",
        "openspec-superpowers",
        "bmad",
        "bmad-superpowers",
        "spec-kit",
        "spec-kit-canon",
        "spec-kit-fleet",
        "spec-kit-product-forge",
        "spec-kit-brownfield",
        "spec-kit-brownkit",
        "spec-kit-ralph",
        "spec-kit-superpowers-bridge",
        "gsd2",
        # Special tokens
        "no-framework",
        "refuse",
    )
)

# fmt: off
_ROUTE_SENTINEL = """

---
<!-- route-mode: internal state tracking — do not display this block -->
Append this line verbatim at the end of every response. Do not put it in a code block:
CHIEF_EVAL: state=<STATE> verdict=<VERDICT>
STATE is exactly one of: AGREE CLARIFY REFUSE NO_FRAMEWORK
VERDICT is the stack slug (e.g. openspec, openspec-superpowers, spec-kit, gsd2) or: no-framework, refuse
"""
# fmt: on


def _load_system(agents_md: Path) -> str:
    return agents_md.read_text(encoding="utf-8") + _ROUTE_SENTINEL


def _strip_fenced_blocks(text: str) -> str:
    """Remove fenced code blocks so sentinels inside them are not matched."""
    return re.sub(r"```.*?```", "", text, flags=re.DOTALL)


def _strip_sentinel(text: str) -> tuple[str, str | None, str | None, str | None]:
    """Return (display_text, state, verdict, error_msg).

    Removes CHIEF_EVAL line from output. Returns error_msg if sentinel is malformed.
    """
    # Strip fenced code blocks so sentinels inside them are not accidentally matched
    clean = _strip_fenced_blocks(text)

    # Try to match the sentinel with explicit validation
    m = re.search(
        r"CHIEF_EVAL:\s*state\s*=\s*([A-Z_]+)\s+verdict\s*=\s*([a-z0-9-]+)(?:\s|$)",
        clean,
        re.IGNORECASE,
    )
    if m:
        state = m.group(1).upper()
        verdict = m.group(2).lower()

        # Validate state
        if state not in _VALID_STATES:
            error = f"invalid state: {state!r} (must be one of {sorted(_VALID_STATES)})"
            return text.rstrip(), None, None, error

        # Validate verdict
        if verdict not in _VALID_VERDICT_PATTERNS:
            error = f"invalid verdict: {verdict!r} (not a recognized stack slug)"
            return text.rstrip(), None, None, error

        return text[: m.start()].rstrip(), state, verdict, None

    # Check if there's a malformed sentinel (helps diagnose issues)
    raw_sentinel = re.search(r"CHIEF_EVAL:.*", clean, re.IGNORECASE)
    if raw_sentinel:
        error = f"sentinel format mismatch: {raw_sentinel.group(0)!r}"
        return text.rstrip(), None, None, error

    return text.rstrip(), None, None, None


# ── provider call functions ──────────────────────────────────────────────────


def _call_anthropic(
    client: object, model: str, system: str, messages: list[dict]
) -> str:
    response = client.messages.create(  # type: ignore[union-attr]
        model=model,
        max_tokens=4096,
        system=system,
        messages=messages,
    )
    return response.content[0].text  # type: ignore[union-attr]


def _call_openai(client: object, model: str, system: str, messages: list[dict]) -> str:
    oai_messages = [{"role": "system", "content": system}] + messages
    response = client.chat.completions.create(  # type: ignore[union-attr]
        model=model,
        max_tokens=4096,
        messages=oai_messages,
    )
    return response.choices[0].message.content  # type: ignore[union-attr]


def _make_client(provider: str, api_key: str) -> tuple[object | None, object | None]:
    """Return (client, call_fn), or (None, None) if the SDK is not installed."""
    if provider == "anthropic":
        try:
            import anthropic  # noqa: PLC0415
        except ImportError:
            return None, None
        return anthropic.Anthropic(api_key=api_key), _call_anthropic
    else:  # openai or github
        try:
            import openai  # noqa: PLC0415
        except ImportError:
            return None, None
        kwargs: dict = {"api_key": api_key}
        if provider == "github":
            kwargs["base_url"] = _GITHUB_BASE_URL
        return openai.OpenAI(**kwargs), _call_openai


# ── main entry point ─────────────────────────────────────────────────────────


def run_route(
    agents_md: Path,
    initial_request: str | None,
    model: str | None,
    provider: str,
) -> int:
    default_model, env_var = _PROVIDER_DEFAULTS.get(
        provider, _PROVIDER_DEFAULTS["anthropic"]
    )
    resolved_model = model or default_model

    api_key = os.environ.get(env_var)
    if not api_key:
        from framework_chief import renderer  # noqa: PLC0415

        renderer.render_error(f"{env_var} not set")
        return 1

    client, call_fn = _make_client(provider, api_key)
    if client is None:
        from framework_chief import renderer  # noqa: PLC0415

        renderer.render_error(
            f"Required package not installed for provider '{provider}'.\n"
            "  Run: pip install 'framework-chief[route]'"
        )
        return 1

    from framework_chief import renderer  # noqa: PLC0415
    from framework_chief.stacks import REGISTRY  # noqa: PLC0415

    system = _load_system(agents_md)
    messages: list[dict] = []

    if initial_request:
        user_text = initial_request
    else:
        renderer.render_route_prompt_initial()
        try:
            user_text = sys.stdin.readline().strip()
        except (EOFError, KeyboardInterrupt):
            return 0
        if not user_text:
            return 0

    loop_iteration = 0
    sentinel_failures = 0

    while True:
        loop_iteration += 1
        if loop_iteration > MAX_LOOP_ITERATIONS:
            renderer.render_error(
                f"Routing loop exceeded {MAX_LOOP_ITERATIONS} iterations. "
                "The model may be stuck in an unexpected state."
            )
            return 1

        messages.append({"role": "user", "content": user_text})
        try:
            with renderer.route_thinking_status():
                raw = call_fn(client, resolved_model, system, messages)  # type: ignore[operator]
        except KeyboardInterrupt:
            renderer.console.print()
            return 0
        except Exception as exc:
            renderer.render_error(f"API error: {exc}")
            return 1

        clean, state, verdict, sentinel_error = _strip_sentinel(raw)
        renderer.render_route_response(clean)
        messages.append({"role": "assistant", "content": raw})

        # Handle sentinel detection failures
        if state is None:
            sentinel_failures += 1
            if sentinel_error:
                renderer.render_error(f"Sentinel error: {sentinel_error}")
            else:
                renderer.render_error(
                    "Response did not include CHIEF_EVAL sentinel. "
                    "The model must include 'CHIEF_EVAL: state=<STATE> verdict=<VERDICT>' in every response."
                )

            if sentinel_failures >= MAX_SENTINEL_RETRIES:
                renderer.render_error(
                    f"Failed to extract valid sentinel after {MAX_SENTINEL_RETRIES} attempts. Aborting."
                )
                return 1

            # Prompt the user to continue or retry
            renderer.console.print(
                "[yellow]Please continue describing your project or ask a follow-up question.[/yellow]"
            )
            renderer.render_route_prompt_turn()
            try:
                user_text = sys.stdin.readline().strip()
            except (EOFError, KeyboardInterrupt):
                renderer.console.print()
                return 0
            if not user_text:
                return 0
            continue

        # Reset sentinel failure counter on successful extraction
        sentinel_failures = 0

        if state in ("AGREE", "NO_FRAMEWORK"):
            stack = REGISTRY.get_stack(verdict or "") if verdict else None
            renderer.render_route_agree(verdict, stack)
            return 0

        if state == "REFUSE":
            return 0

        if state == "CLARIFY":
            # Normal CLARIFY flow — prompt for next turn
            renderer.render_route_prompt_turn()
            try:
                user_text = sys.stdin.readline().strip()
            except (EOFError, KeyboardInterrupt):
                renderer.console.print()
                return 0
            if not user_text:
                return 0
            continue

        # Should not reach here if state is valid (checked in _strip_sentinel)
        renderer.render_error(f"Unexpected state: {state}")
        return 1
