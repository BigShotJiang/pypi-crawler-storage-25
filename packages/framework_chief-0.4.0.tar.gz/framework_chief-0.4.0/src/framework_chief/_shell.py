"""_shell.py — cross-platform shell dispatch helpers."""

from __future__ import annotations

import shlex
import shutil
import sys
from pathlib import Path


def _shell_cmd(script: Path) -> list[str]:
    """Return the interpreter + script args for the current platform."""
    if sys.platform == "win32":
        ps = shutil.which("pwsh") or shutil.which("powershell")
        if not ps:
            raise RuntimeError(
                "No shell interpreter found on Windows. "
                "Install PowerShell 7+ (pwsh) from https://aka.ms/powershell and ensure it is on PATH."
            )
        # Use the .ps1 sibling if it exists, else fall back to the .sh
        ps1 = script.with_suffix(".ps1")
        target = ps1 if ps1.exists() else script
        return [ps, "-NonInteractive", "-File", str(target)]
    return ["bash", str(script)]


def _split_cmd(cmd_str: str) -> list[str]:
    """Split a shell command string safely for the current platform.

    Invariant: adapter install_commands strings must not contain spaces within
    individual arguments on Windows (e.g. paths with spaces). Current bundled
    adapters (npm/npx/uv commands) satisfy this. If the adapter format ever
    opens to user-authored adapters, revisit and use subprocess.list2cmdline or
    a proper Windows-aware parser instead.
    """
    if sys.platform == "win32":
        # shlex uses POSIX rules which break on Windows paths; simple split is
        # safe given the invariant above.
        return cmd_str.split()
    return shlex.split(cmd_str)
