"""decision_log.py — Append-only decision log for framework-chief."""

from __future__ import annotations

import datetime
import re
from dataclasses import dataclass
from pathlib import Path


class LogEntryError(Exception):
    """Raised when a raw log entry cannot be parsed or validated."""


_KEY_RE = re.compile(r"^[a-zA-Z0-9_-]+$")

_DECISION_LOG_HEADER = (
    "# Framework Chief — Decision Log\n"
    "\n"
    "Append-only audit log. Each entry records one install event: what\n"
    "stack was chosen, why, what commands ran, and any deviations from\n"
    "the standard flow.\n"
    "\n"
    "Do not edit existing entries.\n"
    "\n"
    "---\n"
)


@dataclass
class DecisionLog:
    path: Path

    def bootstrap(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text(_DECISION_LOG_HEADER, encoding="utf-8")

    def _append(self, kvpairs: list[tuple[str, str]]) -> str:
        self.bootstrap()
        date = datetime.date.today().isoformat()
        with self.path.open("a", encoding="utf-8") as f:
            f.write(f"\n### {date} — install event\n")
            for key, val in kvpairs:
                f.write(f"- **{key}:** {val}\n")
        return date

    def parse_and_append(self, raw: list[str]) -> tuple[list[tuple[str, str]], str]:
        """Validate raw key=value strings, append, and return (pairs, date).

        Raises LogEntryError on missing entries, malformed pairs, invalid
        keys, or empty values.
        """
        if not raw:
            raise LogEntryError("log requires at least one key=value argument")
        parsed: list[tuple[str, str]] = []
        for kv in raw:
            if "=" not in kv:
                raise LogEntryError(
                    f"malformed argument '{kv}' — expected key=value format"
                )
            key, val = kv.split("=", 1)
            if not _KEY_RE.match(key):
                raise LogEntryError(
                    f"invalid key '{key}' — keys must match [a-zA-Z0-9_-]"
                )
            if not val:
                raise LogEntryError(f"empty value for key '{key}'")
            if "\n" in val or "\r" in val:
                raise LogEntryError(
                    f"value for key '{key}' must not contain newlines"
                )
            parsed.append((key, val))
        date = self._append(parsed)
        return parsed, date

    def last_stack(self) -> str | None:
        if not self.path.exists():
            return None
        last: str | None = None
        for line in self.path.read_text(encoding="utf-8").splitlines():
            m = re.match(
                r"^-\s+\*\*stack:\*\*\s+(.+)$",
                line,
            )
            if m:
                last = m.group(1).strip()
        return last

    def read_entries(self) -> str:
        history = self.path.read_text(encoding="utf-8")
        first_entry = history.find("\n### ")
        return history[first_entry:].lstrip() if first_entry >= 0 else history
