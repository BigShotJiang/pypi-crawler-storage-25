"""compose.py — Composition block engine for framework-chief."""

from __future__ import annotations

import datetime
import os
import re
import tempfile
from pathlib import Path
from typing import Callable

from framework_chief.stacks import Stack, parse_front_matter


# ── exceptions ───────────────────────────────────────────────────────────────


class CompositionError(Exception):
    """Raised when the engine cannot complete."""


class BlockAlreadyPresent(Exception):
    """Raised when the marker already exists in AGENTS.md."""


class PlaceholderError(CompositionError):
    """Raised when a required placeholder cannot be filled."""


# ── internals ────────────────────────────────────────────────────────────────

_MARKER_TPL = "<!-- chief:composition-block:{stack} -->"
_BLOCKS_DIR = Path(__file__).parent / "data" / "chief" / "composition-blocks"
_PLACEHOLDER_PATTERN = re.compile(r"<([A-Za-z_][A-Za-z0-9_]*)>")

# Dispatch table for auto-resolved placeholders by name
_AUTO_RESOLVERS: dict[str, Callable[[], str]] = {
    "DATE": lambda: datetime.date.today().isoformat(),
}


def _resolve_auto(
    placeholder: str,
    _values: dict[str, str],
    _input_fn: Callable[[str], str],
) -> str | None:
    """Resolve auto placeholders from dispatch table.

    Raises CompositionError if the placeholder is not registered.
    """
    resolver = _AUTO_RESOLVERS.get(placeholder)
    if resolver is None:
        raise CompositionError(
            f"auto placeholder '{placeholder}' has no registered resolver; "
            f"available: {sorted(_AUTO_RESOLVERS.keys())}"
        )
    return resolver()


def _resolve_required(
    placeholder: str,
    values: dict[str, str],
    input_fn: Callable[[str], str],
) -> str | None:
    key = placeholder.lower().replace(" ", "_")
    value = (
        values.get(key, "").strip() or os.environ.get(placeholder.upper(), "").strip()
    )
    if not value:
        try:
            value = input_fn(f"Enter {placeholder}: ").strip()
        except EOFError:
            value = ""
    if not value:
        raise PlaceholderError(
            f"{placeholder} is required"
            f" — use --request-summary"
            f" or set {placeholder.upper()} env var"
        )
    return value


def _resolve_prompt(
    placeholder: str,
    _values: dict[str, str],
    input_fn: Callable[[str], str],
) -> str | None:
    try:
        value = input_fn(f"Enter {placeholder} (press Enter to skip): ").strip()
    except EOFError:
        value = ""
    return value or None


_RESOLVERS: dict[str, Callable] = {
    "auto": _resolve_auto,
    "required": _resolve_required,
    "prompt": _resolve_prompt,
}


# ── validation helpers ──────────────────────────────────────────────────────


def _extract_body_tokens(body: str) -> set[str]:
    """Extract all placeholder token names from body text.

    Returns a set of placeholder names found in angle brackets,
    e.g., {"DATE", "REQUEST_SUMMARY"} from "installed: <DATE>\nrequest: <REQUEST_SUMMARY>"
    """
    return {m.group(1) for m in _PLACEHOLDER_PATTERN.finditer(body)}


def _validate_placeholders(
    body: str,
    declared: dict[str, str],
    block_name: str,
) -> None:
    """Validate that declared placeholders match body tokens.

    Raises CompositionError if:
    - Declared in meta but not in body (unfilled token)
    - Present in body but not declared in meta (missing resolver strategy)
    """
    declared_set = set(declared.keys())
    body_tokens = _extract_body_tokens(body)

    # Check for declared but unimplemented
    missing_in_body = declared_set - body_tokens
    if missing_in_body:
        raise CompositionError(
            f"composition block {block_name!r}: "
            f"placeholder(s) declared in meta but no matching token in body: "
            f"{', '.join(f'<{p}>' for p in sorted(missing_in_body))}"
        )

    # Check for undeclared but present in body (missing resolver strategy)
    undeclared_in_meta = body_tokens - declared_set
    if undeclared_in_meta:
        raise CompositionError(
            f"composition block {block_name!r}: "
            f"placeholder token(s) in body but not declared in meta: "
            f"{', '.join(f'<{p}>' for p in sorted(undeclared_in_meta))}"
        )


def _check_unfilled_tokens(
    filled: str, block_name: str, placeholders: dict[str, str]
) -> None:
    """Detect unfilled tokens that should have been filled.

    Only raises if a token remains but had a 'required' resolver strategy.
    Optional tokens (prompt, auto) may be left unfilled for manual completion.
    """
    unfilled = _extract_body_tokens(filled)
    # Filter to only required placeholders that remain unfilled
    unfilled_required = {p for p in unfilled if placeholders.get(p) == "required"}
    if unfilled_required:
        raise CompositionError(
            f"composition block {block_name!r}: "
            f"required placeholder(s) remain unfilled after resolver pass: "
            f"{', '.join(f'<{p}>' for p in sorted(unfilled_required))}"
        )


# ── public interface ─────────────────────────────────────────────────────────


def apply_composition_block(
    stack: Stack,
    agents_md: Path,
    *,
    values: dict[str, str],
    input_fn: Callable[[str], str] = input,
) -> None:
    """Fill and append a composition block to agents_md.

    Raises BlockAlreadyPresent if the marker already exists.
    Raises PlaceholderError if a required placeholder cannot be filled.
    Raises CompositionError on any other failure.
    """
    block_name = stack.composition_block
    if not block_name or "/" in block_name or "\\" in block_name or ".." in block_name:
        raise CompositionError(f"invalid composition block name: {block_name!r}")
    block_path = _BLOCKS_DIR / f"{block_name}.md"
    if not block_path.exists():
        raise CompositionError(f"composition block not found: {block_path}")

    text = block_path.read_text(encoding="utf-8")
    meta, block_body = parse_front_matter(text)
    if not meta:
        raise CompositionError("composition block has no YAML front-matter")
    if not isinstance(block_body, str) or not block_body.strip():
        raise CompositionError(
            f"composition block {stack.composition_block!r} has empty body"
        )
    placeholders: dict[str, str] = meta.get("placeholders", {})

    # Validate placeholders: declared ↔ body tokens must match exactly
    _validate_placeholders(block_body, placeholders, stack.composition_block)

    marker = _MARKER_TPL.format(stack=stack.name)
    if agents_md.exists() and marker in agents_md.read_text(encoding="utf-8"):
        raise BlockAlreadyPresent(stack.name)

    filled = block_body
    for placeholder, strategy in placeholders.items():
        token = f"<{placeholder}>"
        resolver = _RESOLVERS.get(strategy)
        if resolver is None:
            raise CompositionError(
                f"unknown placeholder strategy '{strategy}' for {placeholder}"
            )
        value = resolver(placeholder, values, input_fn)
        if value is not None:
            filled = filled.replace(token, value)

    # Verify required tokens were filled
    _check_unfilled_tokens(filled, stack.composition_block, placeholders)

    # Write atomically: temp file → rename to target
    tmp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=agents_md.parent,
            delete=False,
            suffix=".tmp",
        ) as tmp:
            tmp_path = Path(tmp.name)
            # If target exists, copy its content to temp file
            if agents_md.exists():
                tmp.write(agents_md.read_text(encoding="utf-8"))
            # Append the new composition block
            tmp.write(f"\n{marker}\n")
            tmp.write(filled)
        # Atomic rename
        tmp_path.replace(agents_md)
    except Exception as exc:
        # Clean up temp file if it exists
        if tmp_path is not None:
            try:
                tmp_path.unlink(missing_ok=True)
            except Exception:  # nosec B110
                pass
        raise CompositionError(
            f"failed to write composition block to {agents_md}: {exc}"
        ) from exc
