#!/usr/bin/env python3
"""
eval-quickstart.py — Automated quickstart eval for Framework Chief.

Sends each case from quickstart-cases.md to the Claude API with AGENTS.md
as the system prompt. The system prompt is extended (eval-only) with a
sentinel instruction; the chief appends:

    CHIEF_QUICKSTART_EVAL: framework=<FW> has_quickstart=<yes|no> correct_commands=<yes|no|na>

to every response. The harness parses that line and compares it against
expected values to produce a pass/fail per case.

This eval tests whether the Framework Chief correctly:
1. Displays quickstart sections in the right state (after INSTALL or AGREE for recommend-only)
2. Does not confuse quickstart commands across frameworks
3. Correctly qualifies recommend-only quickstarts (GSD-2, Superpowers)

Usage:
    python3 tests/eval/eval-quickstart.py
    python3 tests/eval/eval-quickstart.py --cases CASE-QS-01,CASE-QS-05
    python3 tests/eval/eval-quickstart.py --model claude-sonnet-4-6
    python3 tests/eval/eval-quickstart.py --dry-run   # parse cases, no API calls
    python3 tests/eval/eval-quickstart.py --verbose   # show full response on failure

Requires:
    pip install anthropic
    export ANTHROPIC_API_KEY=sk-ant-...
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
AGENTS_MD = ROOT / "src" / "framework_chief" / "data" / "AGENTS.md"
CASES_MD = Path(__file__).resolve().parent / "quickstart-cases.md"

DEFAULT_MODEL = "claude-sonnet-4-6"

# Appended to AGENTS.md at eval time only — not part of the shipped router.
EVAL_SUFFIX = """

---
<!-- EVAL MODE: automated test harness active. -->

MANDATORY SENTINEL — YOU MUST INCLUDE THIS IN EVERY RESPONSE WITHOUT EXCEPTION:

    CHIEF_QUICKSTART_EVAL: framework=<FW> has_quickstart=<yes|no> correct_commands=<yes|no|na>

This line is REQUIRED in ALL responses.
A response without this line is invalid and will be marked as a test failure.
Include it anywhere in your response — beginning, middle, or end — but it MUST be present.

FRAMEWORK is the slug of the framework whose quickstart is expected (e.g., openspec, spec-kit, bmad, gsd2, superpowers).

HAS_QUICKSTART is exactly one of: yes no
- Use yes if your response surfaces/mentions a quickstart or first-steps walkthrough for the framework
- Use no if you do not provide a quickstart or if the framework doesn't exist

CORRECT_COMMANDS is exactly one of: yes no na
- Use yes if the quickstart commands you mention match the framework (e.g., /opsx:propose for openspec, /speckit.specify for spec-kit, bmad-help for BMAD, gsd for GSD-2, /brainstorm for Superpowers)
- Use no if the commands mentioned don't match the framework (e.g., mentioning spec-kit commands when asked about openspec)
- Use na if no commands were mentioned or if has_quickstart=no

Examples:
  CHIEF_QUICKSTART_EVAL: framework=openspec has_quickstart=yes correct_commands=yes
  CHIEF_QUICKSTART_EVAL: framework=spec-kit has_quickstart=yes correct_commands=no
  CHIEF_QUICKSTART_EVAL: framework=gsd2 has_quickstart=yes correct_commands=yes
  CHIEF_QUICKSTART_EVAL: framework=nonexistent has_quickstart=no correct_commands=na

REMINDER: Before finishing your response, verify that you have included the CHIEF_QUICKSTART_EVAL
sentinel line above. Every response must contain it. Do not omit it.
"""

# Framework-specific command patterns for validation
_FRAMEWORK_COMMANDS = {
    "openspec": [r"/opsx:propose", r"opsx:propose", r"/opsx:apply", r"opsx:apply"],
    "spec-kit": [r"/speckit\.", r"speckit\.", r"specify init"],
    "bmad": [r"bmad-help", r"bmad-prd", r"bmad-quick-dev", r"bmad-method"],
    "gsd2": [r"\bgsd\b", r"gsd /status"],
    "superpowers": [
        r"/brainstorm",
        r"/write-plan",
        r"/execute-plan",
        r"/plugin list",
    ],
}


# ── Markdown parser ────────────────────────────────────────────────────────────


def parse_cases(text: str) -> list[dict]:
    cases = []
    for chunk in re.split(r"(?=### CASE-QS-\d+:)", text):
        if not chunk.strip().startswith("### CASE-QS-"):
            continue
        m = re.match(r"### (CASE-QS-\d+): (.+)", chunk.strip())
        if not m:
            continue

        case_id = m.group(1)
        title = m.group(2).strip()

        req_m = re.search(r"\*\*REQUEST(?:[^*]*):\*\*\s*((?:>.*(?:\n|$))+)", chunk)
        if not req_m:
            continue
        req_lines = [
            ln.lstrip("> ").strip()
            for ln in req_m.group(1).splitlines()
            if ln.strip().lstrip("> ")
        ]

        fw_m = re.search(r"\*\*EXPECTED FRAMEWORK:\*\*\s*(.+)", chunk)
        qs_m = re.search(r"\*\*EXPECTED HAS_QUICKSTART:\*\*\s*(.+)", chunk)
        cmd_m = re.search(r"\*\*EXPECTED CORRECT_COMMANDS:\*\*\s*(.+)", chunk)

        fw_text = fw_m.group(1).strip() if fw_m else ""
        qs_text = qs_m.group(1).strip() if qs_m else ""
        cmd_text = cmd_m.group(1).strip() if cmd_m else ""

        exp_framework = _parse_framework(fw_text)
        exp_has_quickstart = _parse_yes_no(qs_text)
        exp_correct_commands = _parse_yes_no_na(cmd_text)

        cases.append(
            {
                "id": case_id,
                "title": title,
                "req_lines": req_lines,
                "fw_text": fw_text,
                "qs_text": qs_text,
                "cmd_text": cmd_text,
                "exp_framework": exp_framework,
                "exp_has_quickstart": exp_has_quickstart,
                "exp_correct_commands": exp_correct_commands,
            }
        )
    return cases


def _parse_framework(text: str) -> str:
    """Normalize framework slug from expected text."""
    low = text.lower()
    for slug in ["openspec", "spec-kit", "bmad", "gsd2", "gsd-2", "superpowers"]:
        if slug in low or slug.replace("-", "") in low.replace("-", ""):
            return slug.replace("-2", "2")
    return None


def _parse_yes_no(text: str) -> str | None:
    """Parse yes/no value."""
    low = text.lower().strip()
    if "yes" in low:
        return "yes"
    if "no" in low:
        return "no"
    return None


def _parse_yes_no_na(text: str) -> str | None:
    """Parse yes/no/na value."""
    low = text.lower().strip()
    if "na" in low or "n/a" in low:
        return "na"
    if "yes" in low:
        return "yes"
    if "no" in low:
        return "no"
    return None


# ── API helpers ────────────────────────────────────────────────────────────────


def load_system_prompt() -> str:
    return AGENTS_MD.read_text() + EVAL_SUFFIX


def call_api(client, system: str, case: dict, model: str) -> str:
    lines = case["req_lines"]

    r = client.messages.create(
        model=model,
        max_tokens=2048,
        system=system,
        messages=[{"role": "user", "content": " ".join(lines)}],
    )
    return r.content[0].text


def _strip_fenced_blocks(text: str) -> str:
    """Remove fenced code blocks so sentinels inside them are not matched."""
    return re.sub(r"```.*?```", "", text, flags=re.DOTALL)


def extract_sentinel(
    response: str,
) -> tuple[str | None, str | None, str | None, str | None]:
    # Strip fenced code blocks before searching so an example sentinel inside
    # a block is never mistaken for the real one.
    clean = _strip_fenced_blocks(response)
    # Match the sentinel with lenient spacing.
    m = re.search(
        r"CHIEF_QUICKSTART_EVAL:\s*framework\s*=\s*([a-z0-9-]+)\s+has_quickstart\s*=\s*(yes|no)\s+correct_commands\s*=\s*(yes|no|na)",
        clean,
        re.IGNORECASE,
    )
    if m:
        framework = m.group(1).lower().replace("-2", "2")
        has_quickstart = m.group(2).lower()
        correct_commands = m.group(3).lower()
        return framework, has_quickstart, correct_commands, None
    raw = re.search(r"CHIEF_QUICKSTART_EVAL:.*", clean, re.IGNORECASE)
    if raw:
        return None, None, None, f"sentinel format mismatch: {raw.group(0)!r}"
    return None, None, None, None


# ── Command validation ────────────────────────────────────────────────────────


def has_framework_commands(response: str, framework: str) -> bool:
    """Check if response contains any commands specific to the framework."""
    if framework not in _FRAMEWORK_COMMANDS:
        return False
    patterns = _FRAMEWORK_COMMANDS[framework]
    for pattern in patterns:
        if re.search(pattern, response, re.IGNORECASE):
            return True
    return False


def has_wrong_framework_commands(response: str, expected_framework: str) -> bool:
    """Check if response contains commands from other frameworks."""
    for framework, patterns in _FRAMEWORK_COMMANDS.items():
        if framework == expected_framework:
            continue
        for pattern in patterns:
            if re.search(pattern, response, re.IGNORECASE):
                return True
    return False


# ── Evaluation logic ───────────────────────────────────────────────────────────


def evaluate(
    actual_framework: str | None,
    actual_has_quickstart: str | None,
    actual_correct_commands: str | None,
    case: dict,
) -> tuple[bool, str]:
    exp_framework = case["exp_framework"]
    exp_has_quickstart = case["exp_has_quickstart"]
    exp_correct_commands = case["exp_correct_commands"]

    if actual_framework is None:
        return False, "no CHIEF_QUICKSTART_EVAL sentinel in response"

    if actual_framework != exp_framework:
        return False, f"framework: got {actual_framework}, want {exp_framework}"

    if actual_has_quickstart != exp_has_quickstart:
        return (
            False,
            f"has_quickstart: got {actual_has_quickstart}, want {exp_has_quickstart}",
        )

    if exp_correct_commands == "na":
        return (
            True,
            f"framework={actual_framework} has_quickstart={actual_has_quickstart} correct_commands=na",
        )

    if actual_correct_commands != exp_correct_commands:
        return (
            False,
            f"correct_commands: got {actual_correct_commands}, want {exp_correct_commands}",
        )

    return (
        True,
        f"framework={actual_framework} has_quickstart={actual_has_quickstart} correct_commands={actual_correct_commands}",
    )


# ── CLI ────────────────────────────────────────────────────────────────────────

GREEN = "\033[32m"
RED = "\033[31m"
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
SEP = "─" * 62


def main() -> None:
    ap = argparse.ArgumentParser(description="Framework Chief quickstart eval")
    ap.add_argument(
        "--cases",
        help="Comma-separated case IDs, e.g. CASE-QS-01,CASE-QS-05",
    )
    ap.add_argument(
        "--model",
        default=DEFAULT_MODEL,
        help=f"Claude model (default: {DEFAULT_MODEL})",
    )
    ap.add_argument(
        "--dry-run",
        action="store_true",
        help="Parse and display cases; no API calls",
    )
    ap.add_argument(
        "--verbose",
        action="store_true",
        help="Show full response for every case",
    )
    ap.add_argument(
        "--output",
        metavar="PATH",
        help="Write JSON summary to PATH",
    )
    args = ap.parse_args()

    all_cases = parse_cases(CASES_MD.read_text())
    if args.cases:
        ids = {c.strip().upper() for c in args.cases.split(",")}
        all_cases = [c for c in all_cases if c["id"] in ids]

    if not all_cases:
        print("No cases matched.", file=sys.stderr)
        sys.exit(1)

    print(SEP)
    print("  Framework Chief — Quickstart Eval")
    print(f"  model:  {args.model}")
    print(f"  cases:  {len(all_cases)}")
    if args.dry_run:
        print("  mode:   dry-run (no API calls)")
    print(SEP + "\n")

    if args.dry_run:
        for c in all_cases:
            req_preview = " ".join(c["req_lines"])
            if len(req_preview) > 80:
                req_preview = req_preview[:79] + "…"
            print(f"  {BOLD}{c['id']}{RESET}  {c['title']}")
            print(f"    framework:       {c['exp_framework']}")
            print(f"    has_quickstart:  {c['exp_has_quickstart']}")
            print(f"    correct_commands: {c['exp_correct_commands']}")
            print(f"    {DIM}request:         {req_preview}{RESET}")
            print()
        sys.exit(0)

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("ERROR: ANTHROPIC_API_KEY not set", file=sys.stderr)
        sys.exit(1)

    try:
        import anthropic  # noqa: PLC0415
    except ImportError:
        print("ERROR: pip install anthropic", file=sys.stderr)
        sys.exit(1)

    client = anthropic.Anthropic(api_key=api_key)
    system = load_system_prompt()
    passed = failed = 0
    results: list[dict] = []

    for c in all_cases:
        print(f"  {BOLD}{c['id']}{RESET}  {c['title']}")
        response = ""
        try:
            response = call_api(client, system, c, args.model)
            (
                actual_framework,
                actual_has_quickstart,
                actual_correct_commands,
                fmt_err,
            ) = extract_sentinel(response)
            if actual_framework is None and fmt_err:
                ok, note = False, fmt_err
            else:
                ok, note = evaluate(
                    actual_framework,
                    actual_has_quickstart,
                    actual_correct_commands,
                    c,
                )
        except Exception as exc:
            ok, note = False, f"API error: {exc}"

        results.append({"id": c["id"], "title": c["title"], "passed": ok, "note": note})

        if ok:
            print(f"    {GREEN}PASS{RESET}  {note}")
            passed += 1
        else:
            print(f"    {RED}FAIL{RESET}  {note}")
            failed += 1

        if args.verbose or not ok:
            preview = response[:500].replace("\n", "\n    ")
            print(f"    {DIM}...\n    {preview}")
            if len(response) > 500:
                print(f"    [+{len(response) - 500} chars]")
            print(RESET)

    total = passed + failed
    print(f"\n{SEP}")
    print(f"  {passed}/{total} passed")
    if failed:
        print(f"  {RED}{failed} case(s) FAILED{RESET}")
    else:
        print(f"  {GREEN}all quickstart cases OK{RESET}")
    print(SEP)

    if args.output:
        import datetime
        import json

        summary = {
            "model": args.model,
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "total": total,
            "passed": passed,
            "failed": failed,
            "cases": results,
        }
        Path(args.output).write_text(json.dumps(summary, indent=2))

    sys.exit(0 if failed == 0 else 1)


if __name__ == "__main__":
    main()
