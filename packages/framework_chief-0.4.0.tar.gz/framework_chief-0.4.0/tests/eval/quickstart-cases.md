# Framework Chief — Quickstart Eval Cases

Each case defines a user request asking about quickstart/first steps for a framework
or combination of frameworks. The eval measures whether the Framework Chief correctly:

1. Surfaces the right quickstart (or states that it doesn't exist)
2. Mentions the correct commands for the framework
3. Qualifies recommend-only frameworks (GSD-2, Superpowers) with install-first notes

**How to run:** `python3 tests/eval/eval-quickstart.py [--dry-run] [--verbose]`

Expected sentinel in every response:
```
CHIEF_QUICKSTART_EVAL: framework=<FW> has_quickstart=<yes|no> correct_commands=<yes|no|na>
```

---

### CASE-QS-01: OpenSpec quickstart first-steps
**REQUEST:**
> I just installed OpenSpec. What do I do first?

**EXPECTED FRAMEWORK:** openspec
**EXPECTED HAS_QUICKSTART:** yes
**EXPECTED CORRECT_COMMANDS:** yes
**KEY SIGNAL:** User asks for immediate next steps after installing OpenSpec.
Chief should surface the quickstart section from `openspec.md` adapter.
**VERIFY:** Response mentions `/opsx:propose` or `opsx:propose` (the first command
to create a proposal). Response contains "proposal.md" or "changes/" directory reference.
Quickstart commands are correct for OpenSpec.

---

### CASE-QS-02: Spec-Kit quickstart after install
**REQUEST:**
> I've set up spec-kit. How do I start creating specs?

**EXPECTED FRAMEWORK:** spec-kit
**EXPECTED HAS_QUICKSTART:** yes
**EXPECTED CORRECT_COMMANDS:** yes
**KEY SIGNAL:** User asks for quickstart guidance for spec-kit.
Chief should reference `/speckit.specify` or `/speckit.constitution` from the adapter.
**VERIFY:** Response mentions `/speckit.specify`, `/speckit.constitution`, or `specify init`.
No OpenSpec or BMAD commands are mentioned. Quickstart is surfaced correctly.

---

### CASE-QS-03: BMAD quickstart guidance
**REQUEST:**
> We just installed BMAD. What's the first command to run?

**EXPECTED FRAMEWORK:** bmad
**EXPECTED HAS_QUICKSTART:** yes
**EXPECTED CORRECT_COMMANDS:** yes
**KEY SIGNAL:** User asks for BMAD first steps. Chief should mention `bmad-help` and
optionally `bmad-prd` from the BMAD adapter quickstart.
**VERIFY:** Response mentions `bmad-help`, `bmad-prd`, or `bmad-method` commands.
Response indicates these are available immediately (not recommend-only).
Quickstart matches BMAD expectations.

---

### CASE-QS-04: GSD-2 quickstart with install-first qualification
**REQUEST:**
> What are the first steps to use GSD-2?

**EXPECTED FRAMEWORK:** gsd2
**EXPECTED HAS_QUICKSTART:** yes
**EXPECTED CORRECT_COMMANDS:** yes
**KEY SIGNAL:** GSD-2 is recommend-only. Chief should surface the quickstart (the `gsd`
command from the adapter) but MUST qualify that GSD-2 itself must be installed first.
**VERIFY:** Response mentions `gsd` command (or `gsd /status`). Response contains a note
about installing GSD-2 as a separate CLI before using these commands. Quickstart is present
with qualification.

---

### CASE-QS-05: Superpowers quickstart with install-first note
**REQUEST:**
> I'm interested in Superpowers. What's the workflow?

**EXPECTED FRAMEWORK:** superpowers
**EXPECTED HAS_QUICKSTART:** yes
**EXPECTED CORRECT_COMMANDS:** yes
**KEY SIGNAL:** Superpowers is recommend-only (plugin-based). Chief should surface
the quickstart (`/brainstorm`, `/write-plan`, `/execute-plan`) but note that the
plugin must be installed in the harness first.
**VERIFY:** Response mentions `/brainstorm`, `/write-plan`, or `/execute-plan` commands.
Response includes a note that Superpowers is a plugin and must be installed via `/plugin add` first.
Quickstart is present with install-first qualification.

---

### CASE-QS-06: OpenSpec quickstart mentions correct commands only
**REQUEST:**
> How do I get started with OpenSpec? Show me the first commands.

**EXPECTED FRAMEWORK:** openspec
**EXPECTED HAS_QUICKSTART:** yes
**EXPECTED CORRECT_COMMANDS:** yes
**KEY SIGNAL:** User asks specifically for OpenSpec first commands. Response should
mention `/opsx:propose` or `/opsx:apply`. Should NOT mention `/speckit.*` commands,
`bmad-*` commands, or Superpowers `/brainstorm` commands.
**VERIFY:** Only OpenSpec commands are mentioned. No commands from other frameworks
appear in the response. Quickstart is clean and framework-specific.

---

### CASE-QS-07: Nonexistent framework — no fabrication
**REQUEST:**
> What's the quickstart for fictitious-tool?

**EXPECTED FRAMEWORK:** fictitious-tool
**EXPECTED HAS_QUICKSTART:** no
**EXPECTED CORRECT_COMMANDS:** na
**KEY SIGNAL:** User asks about a framework that does not exist in Framework Chief.
Chief must NOT fabricate a quickstart. Must state that fictitious-tool is not a
recognized framework.
**VERIFY:** Response clearly states that fictitious-tool is not a recognized framework.
has_quickstart=no, correct_commands=na (no commands to check). No fabricated quickstart
or placeholder commands appear.

---

### CASE-QS-08: BMAD + Superpowers hybrid quickstart
**REQUEST:**
> I want to use BMAD with Superpowers. What commands do I run first?

**EXPECTED FRAMEWORK:** bmad
**EXPECTED HAS_QUICKSTART:** yes
**EXPECTED CORRECT_COMMANDS:** yes
**KEY SIGNAL:** User asks about a hybrid: BMAD for planning + Superpowers for discipline.
Chief should mention BMAD commands first (e.g., `bmad-help`, `bmad-prd`).
Optionally mention Superpowers commands, but they should be separate/sequenced.
BMAD commands should be correct, and Superpowers note should qualify its install-first status.
**VERIFY:** BMAD commands appear (e.g., `bmad-help`, `bmad-prd`). Response is clear about
which commands run first. Superpowers is mentioned as secondary/follow-on. No command confusion.
Quickstart matches BMAD expectations primarily.

---

### CASE-QS-09: Spec-Kit + Ralph extension quickstart
**REQUEST:**
> I have spec-kit installed with the ralph extension for in-session task execution. What do I do now?

**EXPECTED FRAMEWORK:** spec-kit
**EXPECTED HAS_QUICKSTART:** yes
**EXPECTED CORRECT_COMMANDS:** yes
**KEY SIGNAL:** User has a spec-kit + ralph extension stack (in-session automatic execution).
Quickstart should be spec-kit's commands (`/speckit.specify`, `/speckit.constitution`).
Ralph is an execution helper, not a separate-command interface, so chief should mention
spec-kit commands only.
**VERIFY:** Response mentions `/speckit.specify` or `/speckit.constitution` (spec-kit commands).
No separate "ralph" commands are mentioned as user-facing. Quickstart is spec-kit's.
Response may mention that ralph will automate tasks after specs are created.

---

### CASE-QS-10: Ask for quickstart of installed framework without context
**REQUEST:**
> What are my first steps?

**EXPECTED FRAMEWORK:** openspec
**EXPECTED HAS_QUICKSTART:** yes
**EXPECTED CORRECT_COMMANDS:** no
**KEY SIGNAL:** Ambiguous request — chief cannot determine which framework to show.
Chief should ask for clarification about which framework was installed.
This is a LOW-confidence request that may route to CLARIFY.
Alternatively, Chief may default to a framework based on most likely context.
If Chief defaults to OpenSpec, has_quickstart=yes but correct_commands may be marked
as 'no' if the response is hedged or unclear about command correctness.
**VERIFY:** Either Chief asks which framework (CLARIFY route), or Chief defaults to
one (note: this case is intentionally loose — the key is that Chief does not fabricate
commands it cannot be confident about). If response mentions OpenSpec commands, mark correct_commands=yes.
If response is hedged or says "depends on your framework", mark correct_commands=no.

---
