#!/usr/bin/env pwsh
# run-mechanical.ps1 — assert the mechanical layer of the Framework Chief (PowerShell variant).
#
# Mirrors the bash mechanical test, covering:
#   - chief-sync.ps1 is idempotent (3 runs, exit 0 each)
#   - CLAUDE.md is a real overlay file (not symlink), contains @AGENTS.md
#   - .claude/commands/chief.md exists
#   - .github/copilot-instructions.md exists with exactly 2 framework-chief-block markers
#   - .codex/prompts/chief.md exists
#   - --ai isolation: each flag creates only its target files
#   - Error handling: missing AGENTS.md exits non-zero
#
# Usage: pwsh tests/mechanical/run-mechanical.ps1 [ProjectRoot]
#        ProjectRoot defaults to two levels up from this script.

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$ProjectRoot = if ($args.Count -gt 0) { $args[0] } else { Join-Path $PSScriptRoot ".." ".." }
$SYNC = Join-Path $ProjectRoot "src" "framework_chief" "data" "scripts" "chief-sync.ps1"
$AGENTS_SOURCE = Join-Path $ProjectRoot "src" "framework_chief" "data" "AGENTS.md"

$Pass = 0
$Fail = 0

function Pass {
    param([string]$Label)
    "  PASS  $Label" | Write-Host
    $script:Pass++
}

function Fail {
    param([string]$Label)
    "  FAIL  $Label" | Write-Host -ForegroundColor Red
    $script:Fail++
}

function AssertExit {
    param([string]$Label, [int]$Want, [scriptblock]$Command)
    $Got = 0
    try {
        $null = & $Command 2>$null
    } catch {
        $Got = $LASTEXITCODE
    }
    if ($LASTEXITCODE -eq $Want -or $Got -eq $Want) {
        Pass "$Label (exit $Want)"
    } else {
        Fail "$Label (want $Want, got $LASTEXITCODE)"
    }
}

if (-not (Test-Path $SYNC)) {
    "ERROR: chief-sync.ps1 not found at: $SYNC" | Write-Host -ForegroundColor Red
    "  pass the correct project root: pwsh tests/mechanical/run-mechanical.ps1 /path/to/project" | Write-Host -ForegroundColor Red
    exit 1
}

"mechanical: $SYNC"
""

# ── chief-sync.ps1: idempotency (temp project) ──────────────────────────────
"chief-sync.ps1 — idempotency (temp project):"
$syncTemp = Join-Path ([System.IO.Path]::GetTempPath()) ([System.IO.Path]::GetRandomFileName())

try {
    $null = New-Item -ItemType Directory -Force -Path $syncTemp
    $null = & git init -q $syncTemp 2>$null

    Copy-Item $AGENTS_SOURCE -Destination (Join-Path $syncTemp "AGENTS.md") -Force

    # Run sync 3 times
    & pwsh -NonInteractive -File $SYNC --ai all $syncTemp 2>$null
    $exit1 = $LASTEXITCODE

    & pwsh -NonInteractive -File $SYNC --ai all $syncTemp 2>$null
    $exit2 = $LASTEXITCODE

    & pwsh -NonInteractive -File $SYNC --ai all $syncTemp 2>$null
    $exit3 = $LASTEXITCODE

    if ($exit1 -eq 0) { Pass "sync run 1 (exit 0)" } else { Fail "sync run 1 (exit $exit1)" }
    if ($exit2 -eq 0) { Pass "sync run 2 (exit 0)" } else { Fail "sync run 2 (exit $exit2)" }
    if ($exit3 -eq 0) { Pass "sync run 3 (exit 0)" } else { Fail "sync run 3 (exit $exit3)" }

    $claudeFile = Join-Path $syncTemp "CLAUDE.md"
    if ((Test-Path $claudeFile) -and ((Get-Item $claudeFile).LinkType -ne "SymbolicLink" -and (Get-Item $claudeFile).LinkType -ne "Junction")) {
        $content = Get-Content $claudeFile -Raw
        if ($content.Contains("@AGENTS.md")) {
            Pass "sync: CLAUDE.md is a real overlay file containing @AGENTS.md"
        } else {
            Fail "sync: CLAUDE.md does not contain @AGENTS.md"
        }
    } else {
        Fail "sync: CLAUDE.md is missing or a symlink/junction"
    }

    $chiefCmd = Join-Path $syncTemp ".claude" "commands" "chief.md"
    if (Test-Path $chiefCmd) {
        Pass "sync: .claude/commands/chief.md exists"
    } else {
        Fail "sync: .claude/commands/chief.md missing"
    }

    $copilot = Join-Path $syncTemp ".github" "copilot-instructions.md"
    if (Test-Path $copilot) {
        $copilotContent = Get-Content $copilot -Raw
        $markerCount = ($copilotContent | Select-String "framework-chief-block" -AllMatches).Matches.Count
        if ($markerCount -eq 2) {
            Pass "sync: copilot marker count = 2 after 3 syncs"
        } else {
            Fail "sync: copilot marker count = $markerCount (want 2)"
        }
    } else {
        Fail "sync: copilot-instructions.md not created"
    }

    $codex = Join-Path $syncTemp ".codex" "prompts" "chief.md"
    if (Test-Path $codex) {
        Pass "sync: .codex/prompts/chief.md exists"
    } else {
        Fail "sync: .codex/prompts/chief.md missing"
    }

    ""

    # ── --ai claude isolation ────────────────────────────────────────────────
    "chief-sync.ps1 — --ai claude isolation:"
    $aiTemp = Join-Path ([System.IO.Path]::GetTempPath()) ([System.IO.Path]::GetRandomFileName())
    $null = New-Item -ItemType Directory -Force -Path $aiTemp
    $null = & git init -q $aiTemp 2>$null
    Copy-Item $AGENTS_SOURCE -Destination (Join-Path $aiTemp "AGENTS.md") -Force

    & pwsh -NonInteractive -File $SYNC --ai claude $aiTemp 2>$null

    if ((Test-Path (Join-Path $aiTemp "CLAUDE.md"))) {
        Pass "--ai claude: CLAUDE.md created"
    } else {
        Fail "--ai claude: CLAUDE.md not created"
    }

    if (-not (Test-Path (Join-Path $aiTemp ".github" "copilot-instructions.md"))) {
        Pass "--ai claude: copilot-instructions.md NOT created"
    } else {
        Fail "--ai claude: copilot-instructions.md should not exist"
    }

    if (-not (Test-Path (Join-Path $aiTemp ".codex" "prompts" "chief.md"))) {
        Pass "--ai claude: .codex/prompts/chief.md NOT created"
    } else {
        Fail "--ai claude: .codex/prompts/chief.md should not exist"
    }

    Remove-Item $aiTemp -Recurse -Force

    ""

    # ── --ai copilot isolation ───────────────────────────────────────────────
    "chief-sync.ps1 — --ai copilot isolation:"
    $aiTemp = Join-Path ([System.IO.Path]::GetTempPath()) ([System.IO.Path]::GetRandomFileName())
    $null = New-Item -ItemType Directory -Force -Path $aiTemp
    $null = & git init -q $aiTemp 2>$null
    Copy-Item $AGENTS_SOURCE -Destination (Join-Path $aiTemp "AGENTS.md") -Force

    & pwsh -NonInteractive -File $SYNC --ai copilot $aiTemp 2>$null

    if (-not (Test-Path (Join-Path $aiTemp "CLAUDE.md"))) {
        Pass "--ai copilot: CLAUDE.md NOT created"
    } else {
        Fail "--ai copilot: CLAUDE.md should not exist"
    }

    if ((Test-Path (Join-Path $aiTemp ".github" "copilot-instructions.md"))) {
        Pass "--ai copilot: copilot-instructions.md created"
    } else {
        Fail "--ai copilot: copilot-instructions.md not created"
    }

    if (-not (Test-Path (Join-Path $aiTemp ".codex" "prompts" "chief.md"))) {
        Pass "--ai copilot: .codex/prompts/chief.md NOT created"
    } else {
        Fail "--ai copilot: .codex/prompts/chief.md should not exist"
    }

    Remove-Item $aiTemp -Recurse -Force

    ""

    # ── --ai codex isolation ─────────────────────────────────────────────────
    "chief-sync.ps1 — --ai codex isolation:"
    $aiTemp = Join-Path ([System.IO.Path]::GetTempPath()) ([System.IO.Path]::GetRandomFileName())
    $null = New-Item -ItemType Directory -Force -Path $aiTemp
    $null = & git init -q $aiTemp 2>$null
    Copy-Item $AGENTS_SOURCE -Destination (Join-Path $aiTemp "AGENTS.md") -Force

    & pwsh -NonInteractive -File $SYNC --ai codex $aiTemp 2>$null

    if (-not (Test-Path (Join-Path $aiTemp "CLAUDE.md"))) {
        Pass "--ai codex: CLAUDE.md NOT created"
    } else {
        Fail "--ai codex: CLAUDE.md should not exist"
    }

    if (-not (Test-Path (Join-Path $aiTemp ".github" "copilot-instructions.md"))) {
        Pass "--ai codex: copilot-instructions.md NOT created"
    } else {
        Fail "--ai codex: copilot-instructions.md should not exist"
    }

    if ((Test-Path (Join-Path $aiTemp ".codex" "prompts" "chief.md"))) {
        Pass "--ai codex: .codex/prompts/chief.md created"
    } else {
        Fail "--ai codex: .codex/prompts/chief.md not created"
    }

    Remove-Item $aiTemp -Recurse -Force

    ""

    # ── Error handling: missing AGENTS.md ────────────────────────────────────
    "chief-sync.ps1 — error handling:"
    $noAgents = Join-Path ([System.IO.Path]::GetTempPath()) ([System.IO.Path]::GetRandomFileName())
    $null = New-Item -ItemType Directory -Force -Path $noAgents

    & pwsh -NonInteractive -File $SYNC --ai all $noAgents 2>$null
    $exitCode = $LASTEXITCODE

    if ($exitCode -ne 0) {
        Pass "sync exits non-zero when AGENTS.md missing"
    } else {
        Fail "sync should exit non-zero when AGENTS.md missing"
    }

    Remove-Item $noAgents -Recurse -Force

} finally {
    if (Test-Path $syncTemp) {
        Remove-Item $syncTemp -Recurse -Force
    }
}

""

# ── summary ──────────────────────────────────────────────────────────────────
$total = $Pass + $Fail
"────────────────────────────────"
"  $Pass/$total passed"
if ($Fail -eq 0) {
    "  all mechanical checks OK"
    exit 0
} else {
    "  $Fail check(s) FAILED"
    exit 1
}
