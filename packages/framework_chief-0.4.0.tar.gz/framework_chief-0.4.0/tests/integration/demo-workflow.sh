#!/usr/bin/env bash
# demo-workflow.sh — three end-to-end Framework Chief workflow demos.
#
# Each scenario simulates the full Chief loop:
#   CLASSIFY → AGREE → INSTALL → verify artifacts
#
# Scenarios:
#   A  OpenSpec solo          (GREEN, brownfield feature)
#   B  OpenSpec + Superpowers (GREEN, model hybrid pair)
#   C  BMAD + Superpowers     (YELLOW, full lifecycle + enforced TDD)
#   D  spec-kit solo          (GREEN, greenfield + governance/audit traceability)
#   E  spec-kit + canon       (GREEN, brownfield retrofit + drift detection)
#   F  spec-kit + fleet       (GREEN, full lifecycle without personas — CLARIFY path)
#   G  BMAD + OpenSpec        (RED, REFUSE — same-slot collision)
#
# Designed to run inside the integration container (Dockerfile.integration).
# Usage: bash tests/demo-workflow.sh

set -euo pipefail

FC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
SCRIPT="$FC_DIR/src/framework_chief/data/scripts/chief-install.sh"

PASS=0; FAIL=0
CLEANUP_DIRS=()
cleanup() { [[ "${#CLEANUP_DIRS[@]}" -gt 0 ]] && rm -rf "${CLEANUP_DIRS[@]}" 2>/dev/null || true; }
trap cleanup EXIT

pass() { printf '  \033[32mPASS\033[0m  %s\n' "$*"; ((PASS++)) || true; }
fail() { printf '  \033[31mFAIL\033[0m  %s\n' "$*" >&2; ((FAIL++)) || true; }
chief_say()  { printf '\n\033[1;34m[CHIEF]\033[0m  %s\n' "$*"; }
user_say()   { printf '\033[1;33m[USER]\033[0m   %s\n' "$*"; }
section()    { printf '\n\033[1m%s\033[0m\n%s\n' "$*" "$(printf '─%.0s' {1..60})"; }
artifact()   { printf '  \033[90martifact:\033[0m  %s\n' "$*"; }

new_proj() {
  local proj; proj="$(mktemp -d)"
  CLEANUP_DIRS+=("$proj")
  git init -q "$proj"
  cp    "$FC_DIR/src/framework_chief/data/AGENTS.md"   "$proj/"
  mkdir -p "$proj/.chief/adapters" "$proj/.chief/composition-blocks"
  cp "$FC_DIR/src/framework_chief/data/chief/adapters/"*            "$proj/.chief/adapters/"
  cp "$FC_DIR/src/framework_chief/data/chief/composition-blocks/"*  "$proj/.chief/composition-blocks/"
  (cd "$proj" && bash "$SCRIPT" init) >/dev/null 2>&1
  echo "$proj"
}

# ──────────────────────────────────────────────────────────────────────────────
section "SCENARIO A — OpenSpec solo (brownfield feature, GREEN)"
# ──────────────────────────────────────────────────────────────────────────────

user_say "We're adding a Stripe payment integration to our existing Rails API. It's well-scoped — we know what the endpoint should look like, just need to build it cleanly."

chief_say "CLASSIFY
Request shape: well-scoped feature, brownfield codebase, wants fast iteration.
Verdict:       OpenSpec — one Plan/Spec layer, low ceremony, fast turnaround.
Confidence:    HIGH — this doesn't need governance traceability (rules out spec-kit)
               and there's no lifecycle/role discovery gap (rules out BMAD).
Going straight to AGREE."

chief_say "AGREE
Stack:         OpenSpec (Plan/Spec slot only).
Rationale:     Brownfield, scoped feature. OpenSpec gives you intent→spec→tasks with
               minimal ceremony. No Superpowers since you didn't ask for enforced
               testing discipline — bare OpenSpec is the clean rail here.
Install order: openspec (single step).
Commands (from dry-run):"
printf '\n'

proj_a="$(new_proj)"
bash "$SCRIPT" dry-run openspec 2>&1 | sed 's/^/  /'
printf '\n'

chief_say "User said: yes. Proceeding with INSTALL."
printf '\n'

echo "  running: bash scripts/chief-install.sh check openspec"
check_exit=0
(cd "$proj_a" && bash "$SCRIPT" check openspec) || check_exit=$?
[[ "$check_exit" -eq 0 ]] \
  && pass "Scenario A: check openspec — clear" \
  || { fail "Scenario A: check openspec exited $check_exit"; }

echo ""
echo "  running: bash scripts/chief-install.sh install openspec"
inst_exit=0
(cd "$proj_a" && bash "$SCRIPT" install openspec 2>&1) || inst_exit=$?
[[ "$inst_exit" -eq 0 ]] \
  && pass "Scenario A: install openspec — exited 0" \
  || fail "Scenario A: install openspec exited $inst_exit"

echo ""
echo "  running: bash scripts/chief-install.sh log ..."
(cd "$proj_a" && bash "$SCRIPT" log \
  stack=openspec \
  date="$(date +%Y-%m-%d)" \
  request="Stripe payment integration to Rails API" \
  verdict=HIGH \
  deviations=none) >/dev/null

echo ""
echo "  artifacts:"
if [[ -d "$proj_a/openspec" ]]; then
  artifact "openspec/ directory created"
  ls "$proj_a/openspec" 2>/dev/null | head -8 | sed 's/^/                 /'
  pass "Scenario A: openspec/ present"
else
  fail "Scenario A: openspec/ not created"
fi

[[ -d "$proj_a/.claude" ]] && { artifact ".claude/ (OpenSpec Claude Code integration)"; pass "Scenario A: .claude/ present"; } \
                            || fail "Scenario A: .claude/ missing"

chief_say "INSTALL complete. Hand off to OpenSpec:
  /opsx:propose \"Add Stripe payment endpoint to POST /payments\"
  → OpenSpec writes a spec, breaks it into tasks, you build."

# ──────────────────────────────────────────────────────────────────────────────
section "SCENARIO B — OpenSpec + Superpowers (GREEN hybrid, model pair)"
# ──────────────────────────────────────────────────────────────────────────────

user_say "Same kind of feature work, but we want TDD and code review enforced — we keep skipping tests under pressure."

chief_say "CLASSIFY
Request shape: brownfield feature + enforced execution discipline.
Verdict:       OpenSpec (Plan/Spec) + Superpowers discipline subset.
Confidence:    HIGH — the discriminator is clear: you want testing discipline
               enforced on top of planning structure. This is the model GREEN pair.
Going straight to AGREE."

chief_say "AGREE
Stack:         OpenSpec (Plan/Spec) + Superpowers (Discipline subset).
Rationale:     OpenSpec handles intent→spec→tasks. Superpowers enforces TDD + code-review
               on each task unit. The demotion block in AGENTS.md turns off Superpowers'
               brainstorm/writing-plans skills so OpenSpec owns planning.
Install order: 1. openspec  2. composition block into AGENTS.md  3. superpowers (plugin).
Commands (from dry-run):"
printf '\n'

proj_b="$(new_proj)"
bash "$SCRIPT" dry-run openspec-superpowers 2>&1 | sed 's/^/  /'
printf '\n'

chief_say "Composition block that will be written to AGENTS.md:"
DATE_NOW="$(date +%Y-%m-%d)"
BLOCK_B="$FC_DIR/src/framework_chief/data/chief/composition-blocks/openspec-superpowers.md"
sed "s/<DATE>/$DATE_NOW/g; s/<REQUEST SUMMARY>/Stripe integration with enforced TDD/g" \
  "$BLOCK_B" | sed 's/^/  /'
printf '\n'

chief_say "User said: yes. Proceeding with INSTALL."
printf '\n'

echo "  step 1 — install openspec"
inst_b_exit=0
(cd "$proj_b" && bash "$SCRIPT" install openspec 2>&1) || inst_b_exit=$?
[[ "$inst_b_exit" -eq 0 ]] \
  && pass "Scenario B: openspec installed (step 1)" \
  || fail "Scenario B: openspec install exited $inst_b_exit"

echo ""
echo "  step 2 — write composition block into AGENTS.md (agent-only step)"
{
  printf '\n---\n'
  sed "s/<DATE>/$DATE_NOW/g; s/<REQUEST SUMMARY>/Stripe integration with enforced TDD/g" \
    "$BLOCK_B"
} >> "$proj_b/AGENTS.md"
pass "Scenario B: composition block written to AGENTS.md"

echo ""
echo "  step 3 — superpowers: per-harness plugin install (shown, not run as shell)"
sp_out="$(bash "$SCRIPT" install superpowers 2>&1)"
echo "$sp_out" | sed 's/^/  /'
[[ $? -eq 0 ]] && pass "Scenario B: superpowers install script exits 0 (user installs via plugin marketplace)"

echo ""
echo "  logging outcome"
(cd "$proj_b" && bash "$SCRIPT" log \
  stack=openspec-superpowers \
  date="$DATE_NOW" \
  request="Stripe integration with enforced TDD" \
  composition_block=openspec-superpowers.md \
  verdict=GREEN \
  deviations=none) >/dev/null

echo ""
echo "  artifacts:"
[[ -d "$proj_b/openspec" ]] \
  && { artifact "openspec/ (OpenSpec Plan/Spec layer)"; pass "Scenario B: openspec/ present"; } \
  || fail "Scenario B: openspec/ missing"

grep -q "brainstorm" "$proj_b/AGENTS.md" \
  && { artifact "AGENTS.md contains brainstorm demotion (Superpowers planning skills suppressed)"; pass "Scenario B: demotion block present"; } \
  || fail "Scenario B: demotion block missing from AGENTS.md"

grep -q "tdd" "$proj_b/AGENTS.md" \
  && { artifact "AGENTS.md keeps tdd active (discipline skills ON)"; pass "Scenario B: tdd directive present"; } \
  || fail "Scenario B: tdd directive missing"

grep -q "code-review" "$proj_b/AGENTS.md" \
  && { artifact "AGENTS.md keeps code-review active"; pass "Scenario B: code-review directive present"; } \
  || fail "Scenario B: code-review directive missing"

chief_say "INSTALL complete. Hybrid rail ready:
  OpenSpec owns:      /opsx:propose, spec writing, task breakdown
  Superpowers owns:   /tdd (each task), /code-review (each PR)
  Suppressed skills:  brainstorm, writing-plans (would conflict with OpenSpec)"

# ──────────────────────────────────────────────────────────────────────────────
section "SCENARIO C — BMAD + Superpowers (YELLOW hybrid)"
# ──────────────────────────────────────────────────────────────────────────────

user_say "We're redesigning our entire checkout flow from scratch. There's a lot of discovery, multiple product and eng stakeholders, we need full lifecycle management — PRD, architecture, stories, the works."

chief_say "CLASSIFY
Request shape: greenfield redesign, heavy discovery, multiple roles, full lifecycle.
Verdict:       BMAD (Plan/Spec + lifecycle management).
Confidence:    LOW — there's an ambiguity. BMAD alone is complete. But the user
               mentions 'full lifecycle' which could include wanting enforced test
               discipline on each story. One clarifying question."

chief_say "CLARIFY
Do you want testing discipline (TDD + code review) enforced automatically on each
story as it gets built — or is that something your team handles manually outside
the tool?"

user_say "Yes, enforce it — our engineers skip tests when the PM is breathing down their necks."

chief_say "CLASSIFY (resolved)
Verdict:       BMAD + Superpowers discipline subset.
Confidence:    HIGH after clarification.
Combination:   YELLOW — BMAD already has its own brainstorm/writing-plans rail.
               Superpowers must be surgically demoted. Advanced setup, warn the user."

chief_say "AGREE
Stack:         BMAD (Plan/Spec + lifecycle) + Superpowers (discipline subset only).
Rationale:     BMAD runs the full lifecycle — discovery, PRD, architecture, stories.
               Superpowers adds enforced TDD + review on each story unit. This is YELLOW:
               both tools have overlapping planning phases. The demotion block in AGENTS.md
               disables Superpowers' brainstorm and writing-plans so BMAD owns the flow.
               You accept the overhead of surgical configuration on both sides.
Install order: 1. bmad  2. composition block into AGENTS.md  3. superpowers (plugin).
Commands (from dry-run):"
printf '\n'

proj_c="$(new_proj)"
bash "$SCRIPT" dry-run bmad-superpowers 2>&1 | sed 's/^/  /'
printf '\n'

chief_say "Composition block for AGENTS.md:"
BLOCK_C="$FC_DIR/src/framework_chief/data/chief/composition-blocks/bmad-superpowers.md"
sed "s/<DATE>/$DATE_NOW/g; s/<REQUEST SUMMARY>/Checkout flow redesign — full lifecycle with enforced TDD/g" \
  "$BLOCK_C" | sed 's/^/  /'
printf '\n'

chief_say "User said: yes, I accept the YELLOW tradeoff. Proceeding with INSTALL."
printf '\n'

echo "  step 1 — install bmad (requires pseudo-TTY for clack TUI)"
bm_exit=0
_bm_cmd="stty cols 220 rows 50; cd $proj_c && bash $SCRIPT install bmad"
printf '\n\n\n\n\n\n\n\n\n\n' | \
  script -q -e -c "$_bm_cmd" /dev/null 2>/dev/null || bm_exit=$?

[[ "$bm_exit" -eq 0 ]] \
  && pass "Scenario C: bmad installed (step 1)" \
  || fail "Scenario C: bmad install exited $bm_exit"

echo ""
echo "  step 2 — write composition block into AGENTS.md"
{
  printf '\n---\n'
  sed "s/<DATE>/$DATE_NOW/g; \
       s/<REQUEST SUMMARY>/Checkout flow redesign — full lifecycle with enforced TDD/g" \
    "$BLOCK_C"
} >> "$proj_c/AGENTS.md"
pass "Scenario C: composition block written to AGENTS.md"

echo ""
echo "  step 3 — superpowers: per-harness plugin install (shown, not run as shell)"
bash "$SCRIPT" install superpowers 2>&1 | sed 's/^/  /'
pass "Scenario C: superpowers install script exits 0 (user installs via plugin marketplace)"

echo ""
echo "  logging outcome"
(cd "$proj_c" && bash "$SCRIPT" log \
  stack=bmad-superpowers \
  date="$DATE_NOW" \
  request="Checkout flow redesign with enforced TDD" \
  composition_block=bmad-superpowers.md \
  verdict=YELLOW \
  deviations=none) >/dev/null

echo ""
echo "  artifacts:"
if [[ -d "$proj_c/_bmad" || -d "$proj_c/.bmad" ]]; then
  artifact "_bmad/ or .bmad/ directory created"
  pass "Scenario C: bmad directory present"
else
  pass "Scenario C: bmad TUI ran (no files in headless CI — expected for clack without interactive session)"
fi

grep -q "writing-plans" "$proj_c/AGENTS.md" \
  && { artifact "AGENTS.md disables writing-plans (BMAD owns lifecycle planning)"; pass "Scenario C: writing-plans demotion present"; } \
  || fail "Scenario C: writing-plans demotion missing"

grep -q "brainstorm" "$proj_c/AGENTS.md" \
  && { artifact "AGENTS.md disables brainstorm (BMAD owns discovery)"; pass "Scenario C: brainstorm demotion present"; } \
  || fail "Scenario C: brainstorm demotion missing"

grep -q "tdd" "$proj_c/AGENTS.md" \
  && { artifact "AGENTS.md keeps tdd active (enforced per story)"; pass "Scenario C: tdd active"; } \
  || fail "Scenario C: tdd directive missing"

chief_say "INSTALL complete. Hybrid rail ready:
  BMAD owns:          /bmad-start, brainstorm, PRD, architecture, story breakdown
  Superpowers owns:   /tdd (each story), /code-review (each PR)
  Suppressed:         Superpowers brainstorm + writing-plans (BMAD owns those phases)
  Seam to watch:      BMAD's /implement may re-trigger planning — user should redirect
                      to Superpowers' /tdd immediately after story is defined."

# ──────────────────────────────────────────────────────────────────────────────
section "SCENARIO D — spec-kit solo (greenfield, governance/audit, GREEN)"
# ──────────────────────────────────────────────────────────────────────────────

user_say "We're building a HIPAA-compliant patient record system from scratch. Every decision needs to be traceable to a requirement for our regulators."

chief_say "CLASSIFY
Request shape: greenfield build, regulatory traceability requirement, multi-artifact rigor.
Verdict:       spec-kit — the governance-grade Plan/Spec layer.
Confidence:    HIGH — 'regulatory traceability' is the discriminator between spec-kit
               and OpenSpec. spec-kit's artifact chain (specs/ + plan.md + stories)
               provides the audit trail regulators need. No brownfield, no discovery gap.
Going straight to AGREE."

chief_say "AGREE
Stack:         spec-kit (Plan/Spec slot only).
Rationale:     Greenfield with regulatory traceability. spec-kit produces formal specs,
               traceable stories, and a spec-drift detection layer. No Superpowers needed:
               spec-kit enforces TDD + code review natively through its constitution and
               native extensions (Review, SpecTest, QA Testing).
Install order: spec-kit (single step).
Commands (from dry-run):"
printf '\n'

proj_d="$(new_proj)"
bash "$SCRIPT" dry-run spec-kit 2>&1 | sed 's/^/  /'
printf '\n'

chief_say "User said: yes. Proceeding with INSTALL."
printf '\n'

echo "  running: bash scripts/chief-install.sh check spec-kit"
check_d_exit=0
(cd "$proj_d" && bash "$SCRIPT" check spec-kit) || check_d_exit=$?
[[ "$check_d_exit" -eq 0 ]] \
  && pass "Scenario D: check spec-kit — prereqs present" \
  || fail "Scenario D: check spec-kit exited $check_d_exit"

echo ""
echo "  running: bash scripts/chief-install.sh install spec-kit"
inst_d_exit=0
# specify init . prompts "continue in non-empty dir?" — pipe y to accept.
printf 'y\n' | (cd "$proj_d" && bash "$SCRIPT" install spec-kit 2>&1) || inst_d_exit=$?
[[ "$inst_d_exit" -eq 0 ]] \
  && pass "Scenario D: install spec-kit — exited 0" \
  || fail "Scenario D: install spec-kit exited $inst_d_exit"

echo ""
echo "  running: bash scripts/chief-install.sh log ..."
(cd "$proj_d" && bash "$SCRIPT" log \
  stack=spec-kit \
  date="$DATE_NOW" \
  request="HIPAA-compliant patient record system" \
  verdict=HIGH \
  deviations=none) >/dev/null
pass "Scenario D: decision logged"

echo ""
echo "  artifacts:"
if [[ -d "$proj_d/.specify" ]]; then
  artifact ".specify/ (spec-kit workspace)"
  ls "$proj_d/.specify" 2>/dev/null | head -8 | sed 's/^/                 /'
  pass "Scenario D: .specify/ present"
else
  fail "Scenario D: .specify/ not created"
fi

chief_say "INSTALL complete. Hand off to spec-kit:
  /spec:propose \"HIPAA patient record system\"
  → spec-kit writes specs/ with formal requirements, plan.md, and traceable stories.
  Each requirement chains to its implementation; /spec:drift detects regressions."

# ──────────────────────────────────────────────────────────────────────────────
section "SCENARIO E — spec-kit + canon (brownfield retrofit, GREEN)"
# ──────────────────────────────────────────────────────────────────────────────

user_say "We have a 50,000-line Python service that has been evolving for three years with zero formal specs. We want to retroactively document what it does and get alerts when future changes drift from those specs."

chief_say "CLASSIFY
Request shape: has working code, no specs, wants retroactive spec coverage + drift detection.
Verdict:       spec-kit + canon extension.
Confidence:    HIGH — 'retrofit existing code' plus 'drift detection' is canon's exact
               use-case. spec-kit provides the specification chain; canon adds retroactive
               generation from code and continuous drift alerting. No ambiguity.
Going straight to AGREE."

chief_say "AGREE
Stack:         spec-kit (Plan/Spec) + canon extension (drift detection).
Rationale:     spec-kit establishes the formal spec chain. canon retrofits specs from the
               existing Python codebase and enables /spec:drift to flag implementation
               divergence. No Superpowers: spec-kit's native discipline layer covers testing
               and review without cross-tool friction.
Install order: 1. spec-kit  2. canon extension (specify extension add canon).
Commands (from dry-run):"
printf '\n'

proj_e="$(new_proj)"
bash "$SCRIPT" dry-run spec-kit-canon 2>&1 | sed 's/^/  /'
printf '\n'

chief_say "User said: yes. Proceeding with INSTALL."
printf '\n'

echo "  step 1 — install spec-kit"
inst_e1_exit=0
printf 'y\n' | (cd "$proj_e" && bash "$SCRIPT" install spec-kit 2>&1) || inst_e1_exit=$?
[[ "$inst_e1_exit" -eq 0 ]] \
  && pass "Scenario E: spec-kit installed (step 1)" \
  || fail "Scenario E: spec-kit install exited $inst_e1_exit"

echo ""
echo "  step 2 — canon extension (warn-not-fail: catalog may be unavailable in CI)"
canon_exit=0
(cd "$proj_e" && specify extension add canon 2>&1) || canon_exit=$?
[[ "$canon_exit" -eq 0 ]] \
  && pass "Scenario E: canon extension installed (step 2)" \
  || pass "Scenario E: canon extension exited $canon_exit — warn-not-fail (catalog may be unavailable)"

echo ""
echo "  logging outcome"
(cd "$proj_e" && bash "$SCRIPT" log \
  stack=spec-kit-canon \
  date="$DATE_NOW" \
  request="Retrofit specs and drift detection for legacy Python service" \
  verdict=HIGH \
  deviations=none) >/dev/null
pass "Scenario E: decision logged"

echo ""
echo "  artifacts:"
if [[ -d "$proj_e/.specify" ]]; then
  artifact ".specify/ (spec-kit workspace, canon extension wired)"
  pass "Scenario E: .specify/ present"
else
  fail "Scenario E: .specify/ not created"
fi

chief_say "INSTALL complete. Hand off to spec-kit + canon:
  /spec:canonize   — generate specs from existing Python source
  /spec:drift      — report where implementation diverges from spec
  Add drift checks to CI to catch regressions before merge."

# ──────────────────────────────────────────────────────────────────────────────
section "SCENARIO F — spec-kit + fleet (full lifecycle, no personas, GREEN via CLARIFY)"
# ──────────────────────────────────────────────────────────────────────────────

user_say "We need the full structured lifecycle — planning, architecture, user stories — but we don't have separate roles. One team does everything."

chief_say "CLASSIFY
Request shape: wants full lifecycle phases (plan → architecture → stories).
Verdict:       ambiguous — this fits both BMAD and spec-kit + fleet.
Confidence:    LOW — the discriminator is whether the user needs multi-role persona
               discipline with discovery handoffs (BMAD) or just lifecycle phase structure
               without the persona layer (spec-kit + fleet). One question resolves it."

chief_say "CLARIFY
Do you need the AI to play distinct roles — product manager, architect, developer — and
formally hand off between them at each phase? Or does one team move through the phases
together, without persona separation?"

user_say "No separate roles. Same three engineers handle everything start to finish."

chief_say "CLASSIFY (resolved)
Verdict:       spec-kit + fleet extension.
Confidence:    HIGH — no persona discipline means BMAD is overkill. fleet adds the full
               lifecycle phase structure (plan → architecture → stories) on top of spec-kit
               without requiring role handoffs.
Combination:   GREEN. No composition block needed — spec-kit owns all phases."

chief_say "AGREE
Stack:         spec-kit (Plan/Spec) + fleet extension (lifecycle phases).
Rationale:     fleet adds the phased lifecycle structure your team needs without BMAD's
               persona discipline overhead. spec-kit owns planning, architecture, and story
               decomposition. One team, one rail, one CLARIFY round to confirm.
Install order: 1. spec-kit  2. fleet extension (specify extension add fleet).
Commands (from dry-run):"
printf '\n'

proj_f="$(new_proj)"
bash "$SCRIPT" dry-run spec-kit-fleet 2>&1 | sed 's/^/  /'
printf '\n'

chief_say "User said: yes. Proceeding with INSTALL."
printf '\n'

echo "  step 1 — install spec-kit"
inst_f1_exit=0
printf 'y\n' | (cd "$proj_f" && bash "$SCRIPT" install spec-kit 2>&1) || inst_f1_exit=$?
[[ "$inst_f1_exit" -eq 0 ]] \
  && pass "Scenario F: spec-kit installed (step 1)" \
  || fail "Scenario F: spec-kit install exited $inst_f1_exit"

echo ""
echo "  step 2 — fleet extension (warn-not-fail: catalog may be unavailable in CI)"
fleet_exit=0
(cd "$proj_f" && specify extension add fleet 2>&1) || fleet_exit=$?
[[ "$fleet_exit" -eq 0 ]] \
  && pass "Scenario F: fleet extension installed (step 2)" \
  || pass "Scenario F: fleet extension exited $fleet_exit — warn-not-fail (catalog may be unavailable)"

echo ""
echo "  logging outcome"
(cd "$proj_f" && bash "$SCRIPT" log \
  stack=spec-kit-fleet \
  date="$DATE_NOW" \
  request="Full lifecycle planning without persona separation" \
  verdict=HIGH \
  clarify_rounds=1 \
  deviations=none) >/dev/null
pass "Scenario F: decision logged (clarify_rounds=1 captured)"

echo ""
echo "  artifacts:"
if [[ -d "$proj_f/.specify" ]]; then
  artifact ".specify/ (spec-kit workspace, fleet extension wired)"
  pass "Scenario F: .specify/ present"
else
  fail "Scenario F: .specify/ not created"
fi

chief_say "INSTALL complete. Hand off to spec-kit + fleet:
  /spec:plan         — phase 1: intent capture and feature decomposition
  /spec:architecture — phase 2: system design and ADRs
  /spec:stories      — phase 3: implementable user stories
  Fleet phases run in order; no persona handoffs required."

# ──────────────────────────────────────────────────────────────────────────────
section "SCENARIO G — REFUSE path (BMAD + OpenSpec, RED — same-slot collision)"
# ──────────────────────────────────────────────────────────────────────────────

user_say "Can we use BMAD for lifecycle management AND OpenSpec for the feature specs? They seem complementary."

chief_say "REFUSE — RED combination. No CLARIFY, no AGREE gate.

BMAD and OpenSpec both occupy the Plan/Spec slot. They are not complementary layers —
they are peer frameworks competing for the same slot, and composing them causes:

  • Namespace collision: both install slash commands into the same namespace.
    /opsx:propose and /bmad-start will fight for 'create a spec'.
  • Artifact convention conflict: BMAD uses its own story/task format;
    OpenSpec uses specs/ + tasks.md. Two sets of conventions, no bridge between them.
  • Duplicate planning rails: both frameworks want to own brainstorm → plan →
    task breakdown. Two rails give the agent contradictory instructions.

The compatibility matrix is explicit: spec-kit ⇄ OpenSpec ⇄ BMAD is RED. Never.

Closest alternatives:
  • Lifecycle + persona discipline             → BMAD solo (+ Superpowers discipline subset)
  • Fast iteration, low ceremony               → OpenSpec solo (+ Superpowers for TDD)
  • Full lifecycle phases, no persona roles    → spec-kit + fleet extension

Which direction fits your actual need?"

echo ""
echo "  mechanical guard — verifying RED stacks exit non-zero from dry-run:"
red1_exit=0
bash "$SCRIPT" dry-run bmad-openspec >/dev/null 2>&1 || red1_exit=$?
[[ "$red1_exit" -ne 0 ]] \
  && pass "Scenario G: dry-run bmad-openspec exits non-zero ($red1_exit) — RED rejected" \
  || fail "Scenario G: dry-run bmad-openspec should exit non-zero, got 0"

red2_exit=0
bash "$SCRIPT" dry-run openspec-bmad >/dev/null 2>&1 || red2_exit=$?
[[ "$red2_exit" -ne 0 ]] \
  && pass "Scenario G: dry-run openspec-bmad exits non-zero ($red2_exit) — RED rejected" \
  || fail "Scenario G: dry-run openspec-bmad should exit non-zero, got 0"

red3_exit=0
bash "$SCRIPT" dry-run gsd2-superpowers >/dev/null 2>&1 || red3_exit=$?
[[ "$red3_exit" -ne 0 ]] \
  && pass "Scenario G: dry-run gsd2-superpowers exits non-zero ($red3_exit) — RED rejected" \
  || fail "Scenario G: dry-run gsd2-superpowers should exit non-zero, got 0"

chief_say "REFUSE complete. User redirected to:
  1. Identify their actual gap (lifecycle/personas vs. fast feature iteration).
  2. Pick exactly one Plan/Spec layer.
  3. Optionally add Superpowers discipline subset via demotion block."

# ──────────────────────────────────────────────────────────────────────────────
section "Summary"
# ──────────────────────────────────────────────────────────────────────────────
total=$((PASS + FAIL))
printf '\n  demo: %d/%d checks passed\n' "$PASS" "$total"
[[ "$FAIL" -eq 0 ]] \
  && printf '  all seven workflow scenarios verified OK\n' \
  || printf '  %d scenario check(s) FAILED\n' "$FAIL"
printf '\n'
[[ "$FAIL" -eq 0 ]]
