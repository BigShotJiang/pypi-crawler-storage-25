"""Unit tests for compose.py."""

from __future__ import annotations

import datetime

import pytest

from framework_chief import compose
from framework_chief.compose import (
    BlockAlreadyPresent,
    CompositionError,
    PlaceholderError,
    _resolve_auto,
    _resolve_prompt,
    _resolve_required,
    apply_composition_block,
)
from framework_chief.stacks import REGISTRY


def _noop_input(prompt: str) -> str:
    return ""


# ── resolver unit tests ──────────────────────────────────────────────────────


def test_resolve_auto_returns_today_iso():
    result = _resolve_auto("DATE", {}, _noop_input)
    assert result == datetime.date.today().isoformat()


def test_resolve_required_from_values():
    result = _resolve_required(
        "REQUEST_SUMMARY", {"request_summary": "build a thing"}, _noop_input
    )
    assert result == "build a thing"


def test_resolve_required_from_input_fn():
    result = _resolve_required("REQUEST_SUMMARY", {}, lambda _: "from prompt")
    assert result == "from prompt"


def test_resolve_required_raises_when_missing():
    with pytest.raises(CompositionError, match="required"):
        _resolve_required("REQUEST_SUMMARY", {}, _noop_input)


def test_resolve_prompt_returns_none_on_empty():
    assert _resolve_prompt("superpowers_version", {}, _noop_input) is None


def test_resolve_prompt_returns_value_when_given():
    result = _resolve_prompt("superpowers_version", {}, lambda _: "2.1.0")
    assert result == "2.1.0"


# ── apply_composition_block integration ──────────────────────────────────────


def test_apply_raises_when_marker_already_present(tmp_path):
    stack = REGISTRY.get_stack("openspec-superpowers")
    agents_md = tmp_path / "AGENTS.md"
    marker = f"<!-- chief:composition-block:{stack.name} -->"
    agents_md.write_text(marker, encoding="utf-8")
    with pytest.raises(BlockAlreadyPresent):
        apply_composition_block(
            stack,
            agents_md,
            values={"request_summary": "test"},
            input_fn=_noop_input,
        )


def test_apply_appends_marker_and_content(tmp_path):
    stack = REGISTRY.get_stack("openspec-superpowers")
    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")
    apply_composition_block(
        stack,
        agents_md,
        values={"request_summary": "test request"},
        input_fn=_noop_input,
    )
    content = agents_md.read_text(encoding="utf-8")
    assert f"<!-- chief:composition-block:{stack.name} -->" in content
    assert "test request" in content


def test_apply_is_idempotent_via_already_present(tmp_path):
    stack = REGISTRY.get_stack("openspec-superpowers")
    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")
    apply_composition_block(
        stack,
        agents_md,
        values={"request_summary": "first"},
        input_fn=_noop_input,
    )
    with pytest.raises(BlockAlreadyPresent):
        apply_composition_block(
            stack,
            agents_md,
            values={"request_summary": "second"},
            input_fn=_noop_input,
        )


def test_apply_raises_for_missing_block_file(tmp_path, monkeypatch):
    stack = REGISTRY.get_stack("openspec-superpowers")
    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")
    monkeypatch.setattr(compose, "_BLOCKS_DIR", tmp_path / "no-such-dir")
    with pytest.raises(CompositionError, match="not found"):
        apply_composition_block(
            stack,
            agents_md,
            values={"request_summary": "test"},
            input_fn=_noop_input,
        )


# ── hardening: unfilled token detection ──────────────────────────────────────


def test_resolve_auto_raises_for_unknown_placeholder():
    """auto strategy raises if placeholder is not in _AUTO_RESOLVERS."""
    with pytest.raises(CompositionError, match="no registered resolver"):
        _resolve_auto("UNKNOWN_AUTO", {}, _noop_input)


def test_apply_raises_for_undeclared_body_token(tmp_path, monkeypatch):
    """Tokens in body but not declared in meta raise an error."""
    # Create a stack with a custom composition_block
    from framework_chief.stacks import Stack, Compatibility

    stack = Stack(
        name="test-custom",
        members=["test"],
        compatibility=Compatibility.GREEN,
        composition_block="bad-block",
    )
    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    # Monkeypatch the block file to have a token without a resolver
    bad_block_content = """---
placeholders:
  DATE: auto
  REQUEST_SUMMARY: required
  superpowers_version: prompt
---

installed: <DATE>
request: <REQUEST_SUMMARY>
undeclared_token: <UNDECLARED>
superpowers: <superpowers_version>
"""
    block_path = tmp_path / "bad-block.md"
    block_path.write_text(bad_block_content, encoding="utf-8")
    monkeypatch.setattr(compose, "_BLOCKS_DIR", block_path.parent)

    with pytest.raises(CompositionError, match="not declared in meta"):
        apply_composition_block(
            stack,
            agents_md,
            values={"request_summary": "test"},
            input_fn=_noop_input,
        )


def test_apply_optional_placeholders_may_remain_unfilled(tmp_path):
    """prompt strategy placeholders may remain unfilled without error."""
    stack = REGISTRY.get_stack("openspec-superpowers")
    assert stack is not None
    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")
    apply_composition_block(
        stack,
        agents_md,
        values={"request_summary": "test request"},
        input_fn=_noop_input,
    )
    content = agents_md.read_text(encoding="utf-8")
    # The superpowers_version is optional (prompt strategy), so it's okay if unfilled
    # This test verifies that optional prompts are left as tokens, not causing errors
    assert f"<!-- chief:composition-block:{stack.name} -->" in content
    assert "test request" in content


def test_apply_raises_for_unfilled_required_placeholder(tmp_path, monkeypatch):
    """required placeholders that cannot be filled raise PlaceholderError."""
    from framework_chief.stacks import Stack, Compatibility

    stack = Stack(
        name="test-required",
        members=["test"],
        compatibility=Compatibility.GREEN,
        composition_block="required-block",
    )
    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    # Block with a required placeholder
    block_content = """---
placeholders:
  DATE: auto
  REQUEST_SUMMARY: required
---

installed: <DATE>
request: <REQUEST_SUMMARY>
"""
    block_path = tmp_path / "required-block.md"
    block_path.write_text(block_content, encoding="utf-8")
    monkeypatch.setattr(compose, "_BLOCKS_DIR", block_path.parent)

    # PlaceholderError is raised when a required placeholder cannot be filled
    with pytest.raises(PlaceholderError, match="required"):
        apply_composition_block(
            stack,
            agents_md,
            values={},  # No values provided
            input_fn=_noop_input,  # Returns empty string
        )


def test_apply_writes_atomically(tmp_path):
    """Composition block is written atomically (temp → rename)."""
    stack = REGISTRY.get_stack("openspec-superpowers")
    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Original content\n", encoding="utf-8")

    apply_composition_block(
        stack,
        agents_md,
        values={"request_summary": "atomic write test"},
        input_fn=_noop_input,
    )

    content = agents_md.read_text(encoding="utf-8")
    assert "# Original content" in content
    assert "atomic write test" in content
    # Verify no temp files left behind
    temp_files = list(tmp_path.glob("*.tmp"))
    assert len(temp_files) == 0


def test_apply_creates_agents_md_if_not_exists(tmp_path):
    """apply_composition_block creates AGENTS.md if it doesn't exist."""
    stack = REGISTRY.get_stack("openspec-superpowers")
    agents_md = tmp_path / "AGENTS.md"
    assert not agents_md.exists()

    apply_composition_block(
        stack,
        agents_md,
        values={"request_summary": "new file test"},
        input_fn=_noop_input,
    )

    assert agents_md.exists()
    content = agents_md.read_text(encoding="utf-8")
    assert f"<!-- chief:composition-block:{stack.name} -->" in content
    assert "new file test" in content


# ── additional coverage tests ────────────────────────────────────────────────


def test_check_unfilled_tokens_prompt_strategy_ok(tmp_path, monkeypatch):
    """_check_unfilled_tokens allows unfilled tokens with prompt strategy."""
    from framework_chief.stacks import Stack, Compatibility

    # Create a custom stack
    stack = Stack(
        name="test-prompt-ok",
        members=["test"],
        compatibility=Compatibility.GREEN,
        composition_block="prompt-block",
    )
    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    # Block with a prompt strategy placeholder left unfilled
    block_content = """---
placeholders:
  DATE: auto
  REQUEST_SUMMARY: required
  superpowers_version: prompt
---

installed: <DATE>
request: <REQUEST_SUMMARY>
superpowers: <superpowers_version>
"""
    block_path = tmp_path / "prompt-block.md"
    block_path.write_text(block_content, encoding="utf-8")
    monkeypatch.setattr(compose, "_BLOCKS_DIR", block_path.parent)

    apply_composition_block(
        stack,
        agents_md,
        values={"request_summary": "test"},
        input_fn=_noop_input,  # Returns empty string, so superpowers_version stays unfilled
    )

    # Should succeed because superpowers_version is prompt (optional)
    content = agents_md.read_text(encoding="utf-8")
    assert f"<!-- chief:composition-block:{stack.name} -->" in content
    assert "test" in content


def test_apply_raises_for_block_without_front_matter(tmp_path, monkeypatch):
    """apply_composition_block raises CompositionError when block has no front-matter."""
    from framework_chief.stacks import Stack, Compatibility

    stack = Stack(
        name="test-no-frontmatter",
        members=["test"],
        compatibility=Compatibility.GREEN,
        composition_block="no-fm-block",
    )
    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    # Block without YAML front-matter
    block_content = """Just some content without front-matter.
This should fail."""
    block_path = tmp_path / "no-fm-block.md"
    block_path.write_text(block_content, encoding="utf-8")
    monkeypatch.setattr(compose, "_BLOCKS_DIR", block_path.parent)

    with pytest.raises(CompositionError, match="no YAML front-matter"):
        apply_composition_block(
            stack,
            agents_md,
            values={"request_summary": "test"},
            input_fn=_noop_input,
        )


def test_apply_raises_for_block_with_empty_body(tmp_path, monkeypatch):
    """apply_composition_block raises CompositionError when block body is empty."""
    from framework_chief.stacks import Stack, Compatibility

    stack = Stack(
        name="test-empty-body",
        members=["test"],
        compatibility=Compatibility.GREEN,
        composition_block="empty-body-block",
    )
    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    # Block with front-matter but empty body
    block_content = """---
placeholders:
  DATE: auto
---
"""
    block_path = tmp_path / "empty-body-block.md"
    block_path.write_text(block_content, encoding="utf-8")
    monkeypatch.setattr(compose, "_BLOCKS_DIR", block_path.parent)

    with pytest.raises(CompositionError, match="empty body"):
        apply_composition_block(
            stack,
            agents_md,
            values={},
            input_fn=_noop_input,
        )
