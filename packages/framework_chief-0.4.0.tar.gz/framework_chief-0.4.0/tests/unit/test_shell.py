"""Unit tests for _shell.py — cross-platform shell dispatch helpers."""

from __future__ import annotations


import pytest

from framework_chief._shell import _shell_cmd, _split_cmd


class TestSplitCmd:
    """Tests for _split_cmd — safe command string splitting."""

    def test_split_cmd_unix_simple(self, monkeypatch):
        """On Unix, _split_cmd uses shlex.split for POSIX-style splitting."""
        monkeypatch.setattr("framework_chief._shell.sys.platform", "linux")
        result = _split_cmd("npm install -g @fission-ai/openspec@latest")
        assert result == ["npm", "install", "-g", "@fission-ai/openspec@latest"]

    def test_split_cmd_unix_with_quoted_args(self, monkeypatch):
        """On Unix, _split_cmd handles quoted arguments via shlex.split."""
        monkeypatch.setattr("framework_chief._shell.sys.platform", "linux")
        result = _split_cmd("uv tool install 'foo bar'")
        assert result == ["uv", "tool", "install", "foo bar"]

    def test_split_cmd_unix_with_double_quotes(self, monkeypatch):
        """On Unix, _split_cmd handles double-quoted arguments correctly."""
        monkeypatch.setattr("framework_chief._shell.sys.platform", "linux")
        result = _split_cmd('echo "hello world"')
        assert result == ["echo", "hello world"]

    def test_split_cmd_windows_simple(self, monkeypatch):
        """On Windows, _split_cmd uses simple .split() for basic commands."""
        monkeypatch.setattr("framework_chief._shell.sys.platform", "win32")
        result = _split_cmd("npm install -g @fission-ai/openspec@latest")
        # On Windows, quoted strings are not unquoted by .split()
        assert result == ["npm", "install", "-g", "@fission-ai/openspec@latest"]

    def test_split_cmd_windows_no_space_in_args(self, monkeypatch):
        """On Windows, commands without spaces in args work fine with .split()."""
        monkeypatch.setattr("framework_chief._shell.sys.platform", "win32")
        result = _split_cmd("uv run pytest tests/unit/test_shell.py -v")
        assert result == ["uv", "run", "pytest", "tests/unit/test_shell.py", "-v"]

    def test_split_cmd_unix_multiple_spaces(self, monkeypatch):
        """On Unix, multiple spaces are handled correctly by shlex.split."""
        monkeypatch.setattr("framework_chief._shell.sys.platform", "linux")
        result = _split_cmd("npm   install    -g")
        assert result == ["npm", "install", "-g"]


class TestShellCmd:
    """Tests for _shell_cmd — shell interpreter selection and script dispatch."""

    def test_shell_cmd_unix_returns_bash(self, monkeypatch, tmp_path):
        """On Unix, _shell_cmd returns ['bash', script_path]."""
        monkeypatch.setattr("framework_chief._shell.sys.platform", "linux")
        script = tmp_path / "test.sh"
        script.write_text("#!/bin/bash\necho hello", encoding="utf-8")
        result = _shell_cmd(script)
        assert result == ["bash", str(script)]

    def test_shell_cmd_macos_returns_bash(self, monkeypatch, tmp_path):
        """On macOS, _shell_cmd returns ['bash', script_path]."""
        monkeypatch.setattr("framework_chief._shell.sys.platform", "darwin")
        script = tmp_path / "test.sh"
        script.write_text("#!/bin/bash\necho hello", encoding="utf-8")
        result = _shell_cmd(script)
        assert result == ["bash", str(script)]

    def test_shell_cmd_windows_with_pwsh_and_ps1_exists(self, monkeypatch, tmp_path):
        """On Windows with pwsh found and .ps1 sibling exists, use PowerShell."""
        monkeypatch.setattr("framework_chief._shell.sys.platform", "win32")
        # Mock shutil.which to return pwsh
        monkeypatch.setattr(
            "framework_chief._shell.shutil.which",
            lambda tool: "/usr/bin/pwsh" if tool == "pwsh" else None,
        )
        script = tmp_path / "test.sh"
        ps1 = tmp_path / "test.ps1"
        script.write_text("#!/bin/bash\necho hello", encoding="utf-8")
        ps1.write_text("Write-Host 'hello'", encoding="utf-8")

        result = _shell_cmd(script)
        assert result == ["/usr/bin/pwsh", "-NonInteractive", "-File", str(ps1)]

    def test_shell_cmd_windows_with_pwsh_no_ps1_fallback(self, monkeypatch, tmp_path):
        """On Windows with pwsh found but no .ps1, fall back to .sh."""
        monkeypatch.setattr("framework_chief._shell.sys.platform", "win32")
        monkeypatch.setattr(
            "framework_chief._shell.shutil.which",
            lambda tool: "/usr/bin/pwsh" if tool == "pwsh" else None,
        )
        script = tmp_path / "test.sh"
        script.write_text("#!/bin/bash\necho hello", encoding="utf-8")
        # No .ps1 file created

        result = _shell_cmd(script)
        assert result == ["/usr/bin/pwsh", "-NonInteractive", "-File", str(script)]

    def test_shell_cmd_windows_with_powershell_fallback(self, monkeypatch, tmp_path):
        """On Windows, try powershell if pwsh is not found."""
        monkeypatch.setattr("framework_chief._shell.sys.platform", "win32")
        monkeypatch.setattr(
            "framework_chief._shell.shutil.which",
            lambda tool: (
                "C:\\Windows\\System32\\powershell.exe"
                if tool == "powershell"
                else None
            ),
        )
        script = tmp_path / "test.sh"
        script.write_text("#!/bin/bash\necho hello", encoding="utf-8")

        result = _shell_cmd(script)
        assert result == [
            "C:\\Windows\\System32\\powershell.exe",
            "-NonInteractive",
            "-File",
            str(script),
        ]

    def test_shell_cmd_windows_no_powershell_raises(self, monkeypatch, tmp_path):
        """On Windows with no PowerShell found, raise RuntimeError with install hint."""
        monkeypatch.setattr("framework_chief._shell.sys.platform", "win32")
        monkeypatch.setattr(
            "framework_chief._shell.shutil.which",
            lambda tool: None,
        )
        script = tmp_path / "test.sh"
        script.write_text("#!/bin/bash\necho hello", encoding="utf-8")

        with pytest.raises(RuntimeError, match="No shell interpreter found on Windows"):
            _shell_cmd(script)

    def test_shell_cmd_with_nonexistent_script_path(self, monkeypatch, tmp_path):
        """_shell_cmd handles nonexistent script paths correctly."""
        monkeypatch.setattr("framework_chief._shell.sys.platform", "linux")
        script = tmp_path / "nonexistent.sh"

        result = _shell_cmd(script)
        assert result == ["bash", str(script)]

    def test_shell_cmd_prefers_pwsh_over_powershell(self, monkeypatch, tmp_path):
        """On Windows, _shell_cmd prefers pwsh over powershell if both are available."""
        monkeypatch.setattr("framework_chief._shell.sys.platform", "win32")

        def mock_which(tool):
            if tool == "pwsh":
                return "/usr/bin/pwsh"
            elif tool == "powershell":
                return "C:\\Windows\\System32\\powershell.exe"
            return None

        monkeypatch.setattr("framework_chief._shell.shutil.which", mock_which)
        script = tmp_path / "test.sh"
        script.write_text("#!/bin/bash\necho hello", encoding="utf-8")

        result = _shell_cmd(script)
        # Should prefer pwsh
        assert result[0] == "/usr/bin/pwsh"
