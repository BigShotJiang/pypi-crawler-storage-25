"""Unit tests for route.py — Framework Chief routing logic."""

from __future__ import annotations

from unittest import mock


from framework_chief.route import (
    MAX_LOOP_ITERATIONS,
    MAX_SENTINEL_RETRIES,
    _call_anthropic,
    _call_openai,
    _make_client,
    _strip_fenced_blocks,
    _strip_sentinel,
    run_route,
)


# ── _strip_fenced_blocks tests ───────────────────────────────────────────────


def test_strip_fenced_blocks_removes_triple_backtick_blocks():
    """Remove fenced code blocks with triple backticks."""
    text = "before\n```python\ncode here\n```\nafter"
    result = _strip_fenced_blocks(text)
    assert result == "before\n\nafter"


def test_strip_fenced_blocks_removes_multiple_blocks():
    """Remove multiple fenced blocks in sequence."""
    text = "a\n```\nblock1\n```\nb\n```\nblock2\n```\nc"
    result = _strip_fenced_blocks(text)
    assert result == "a\n\nb\n\nc"


def test_strip_fenced_blocks_handles_nested_triple_backticks():
    """Remove blocks with nested triple backticks (up to first closing)."""
    text = "start\n```\ntext with ``` inside\n```\nend"
    result = _strip_fenced_blocks(text)
    # Regex greedily matches to the first closing ```, so the middle ``` closes it
    assert "start" in result and "end" in result


def test_strip_fenced_blocks_preserves_non_fenced_content():
    """Keep text outside fenced blocks intact."""
    text = "# Title\n\nContent here\n"
    result = _strip_fenced_blocks(text)
    assert result == text


def test_strip_fenced_blocks_empty_string():
    """Handle empty string gracefully."""
    assert _strip_fenced_blocks("") == ""


# ── _strip_sentinel tests ────────────────────────────────────────────────────


def test_strip_sentinel_valid_agree_state():
    """Extract valid AGREE state with openspec verdict."""
    text = "Some response\nCHIEF_EVAL: state=AGREE verdict=openspec"
    display, state, verdict, error = _strip_sentinel(text)
    assert state == "AGREE"
    assert verdict == "openspec"
    assert error is None
    assert "CHIEF_EVAL" not in display


def test_strip_sentinel_valid_clarify_state():
    """Extract valid CLARIFY state with any verdict slug."""
    text = "Question for you...\nCHIEF_EVAL: state=CLARIFY verdict=spec-kit-superpowers-bridge"
    display, state, verdict, error = _strip_sentinel(text)
    assert state == "CLARIFY"
    assert verdict == "spec-kit-superpowers-bridge"
    assert error is None


def test_strip_sentinel_valid_refuse_state():
    """Extract valid REFUSE state."""
    text = "Cannot help\nCHIEF_EVAL: state=REFUSE verdict=refuse"
    display, state, verdict, error = _strip_sentinel(text)
    assert state == "REFUSE"
    assert verdict == "refuse"
    assert error is None


def test_strip_sentinel_valid_no_framework_state():
    """Extract valid NO_FRAMEWORK state."""
    text = "Use no framework\nCHIEF_EVAL: state=NO_FRAMEWORK verdict=no-framework"
    display, state, verdict, error = _strip_sentinel(text)
    assert state == "NO_FRAMEWORK"
    assert verdict == "no-framework"
    assert error is None


def test_strip_sentinel_case_insensitive_parsing():
    """Parse state and verdict case-insensitively but normalize to uppercase/lowercase."""
    text = "Response\nCHIEF_EVAL: state=agree verdict=OPENSPEC"
    display, state, verdict, error = _strip_sentinel(text)
    assert state == "AGREE"
    assert verdict == "openspec"
    assert error is None


def test_strip_sentinel_flexible_whitespace():
    """Handle extra whitespace around state and verdict."""
    text = "Response\nCHIEF_EVAL: state  =  AGREE  verdict  =  openspec"
    display, state, verdict, error = _strip_sentinel(text)
    assert state == "AGREE"
    assert verdict == "openspec"
    assert error is None


def test_strip_sentinel_invalid_state():
    """Reject unknown state value."""
    text = "Response\nCHIEF_EVAL: state=INVALID verdict=openspec"
    display, state, verdict, error = _strip_sentinel(text)
    assert state is None
    assert verdict is None
    assert error is not None
    assert "invalid state" in error.lower()


def test_strip_sentinel_invalid_verdict():
    """Reject unknown verdict slug."""
    text = "Response\nCHIEF_EVAL: state=AGREE verdict=unknown-framework"
    display, state, verdict, error = _strip_sentinel(text)
    assert state is None
    assert verdict is None
    assert error is not None
    assert "invalid verdict" in error.lower()


def test_strip_sentinel_missing_sentinel():
    """Return None sentinel when absent."""
    text = "Just a normal response without sentinel"
    display, state, verdict, error = _strip_sentinel(text)
    assert state is None
    assert verdict is None
    assert error is None


def test_strip_sentinel_malformed_in_fenced_block_not_matched():
    """Malformed sentinel inside code block should not match."""
    text = "Valid response\n```\nCHIEF_EVAL: state=INVALID verdict=unknown\n```"
    display, state, verdict, error = _strip_sentinel(text)
    # The sentinel inside the fence should be stripped before matching
    assert state is None
    assert verdict is None
    assert error is None


def test_strip_sentinel_malformed_format_error():
    """Detect malformed sentinel format."""
    text = "Response\nCHIEF_EVAL: malformed-format"
    display, state, verdict, error = _strip_sentinel(text)
    assert state is None
    assert verdict is None
    assert error is not None
    assert "format mismatch" in error.lower()


def test_strip_sentinel_removes_line_from_output():
    """The display text does not include the CHIEF_EVAL line."""
    text = "Line 1\nLine 2\nCHIEF_EVAL: state=AGREE verdict=openspec\n"
    display, state, verdict, error = _strip_sentinel(text)
    assert "Line 1" in display
    assert "Line 2" in display
    assert "CHIEF_EVAL" not in display


# ── _call_anthropic tests ────────────────────────────────────────────────────


def test_call_anthropic_creates_message():
    """_call_anthropic calls client.messages.create with correct parameters."""
    mock_client = mock.MagicMock()
    mock_response = mock.MagicMock()
    mock_response.content = [mock.MagicMock(text="Response text")]
    mock_client.messages.create.return_value = mock_response

    result = _call_anthropic(
        mock_client,
        model="claude-sonnet-4-6",
        system="System prompt",
        messages=[{"role": "user", "content": "User message"}],
    )

    assert result == "Response text"
    mock_client.messages.create.assert_called_once()
    call_kwargs = mock_client.messages.create.call_args[1]
    assert call_kwargs["model"] == "claude-sonnet-4-6"
    assert call_kwargs["max_tokens"] == 4096
    assert call_kwargs["system"] == "System prompt"


# ── _call_openai tests ───────────────────────────────────────────────────────


def test_call_openai_creates_chat_completion():
    """_call_openai calls client.chat.completions.create with system in messages."""
    mock_client = mock.MagicMock()
    mock_response = mock.MagicMock()
    mock_choice = mock.MagicMock()
    mock_choice.message.content = "Response text"
    mock_response.choices = [mock_choice]
    mock_client.chat.completions.create.return_value = mock_response

    result = _call_openai(
        mock_client,
        model="gpt-4o",
        system="System prompt",
        messages=[{"role": "user", "content": "User message"}],
    )

    assert result == "Response text"
    call_kwargs = mock_client.chat.completions.create.call_args[1]
    assert call_kwargs["model"] == "gpt-4o"
    assert call_kwargs["max_tokens"] == 4096
    # System is prepended to messages for OpenAI
    assert call_kwargs["messages"][0]["role"] == "system"
    assert call_kwargs["messages"][0]["content"] == "System prompt"


# ── _make_client tests ───────────────────────────────────────────────────────


def test_make_client_anthropic_success(monkeypatch):
    """_make_client returns Anthropic client and _call_anthropic."""
    # Mock the anthropic import
    mock_anthropic_module = mock.MagicMock()
    mock_anthropic_client = mock.MagicMock()
    mock_anthropic_module.Anthropic.return_value = mock_anthropic_client

    monkeypatch.setitem(
        __import__("sys").modules,
        "anthropic",
        mock_anthropic_module,
    )

    client, call_fn = _make_client("anthropic", "test-key")
    assert client is not None
    assert call_fn == _call_anthropic


def test_make_client_anthropic_import_error(monkeypatch):
    """_make_client returns None when anthropic is not installed."""

    # Create a module that raises ImportError
    class FailingModule:
        def __getattr__(self, name):
            raise ImportError("anthropic not installed")

    monkeypatch.setitem(
        __import__("sys").modules,
        "anthropic",
        None,
    )

    client, call_fn = _make_client("anthropic", "test-key")
    assert client is None
    assert call_fn is None


def test_make_client_openai_success(monkeypatch):
    """_make_client returns OpenAI client and _call_openai."""
    mock_openai_module = mock.MagicMock()
    mock_openai_client = mock.MagicMock()
    mock_openai_module.OpenAI.return_value = mock_openai_client

    monkeypatch.setitem(
        __import__("sys").modules,
        "openai",
        mock_openai_module,
    )

    client, call_fn = _make_client("openai", "test-key")
    assert client is not None
    assert call_fn == _call_openai


def test_make_client_github_with_base_url(monkeypatch):
    """_make_client sets GitHub base URL for provider='github'."""
    mock_openai_module = mock.MagicMock()
    mock_openai_client = mock.MagicMock()
    mock_openai_module.OpenAI.return_value = mock_openai_client

    monkeypatch.setitem(
        __import__("sys").modules,
        "openai",
        mock_openai_module,
    )

    client, call_fn = _make_client("github", "test-token")
    assert client is not None
    call_kwargs = mock_openai_module.OpenAI.call_args[1]
    assert call_kwargs["base_url"] == "https://models.inference.ai.azure.com"


# ── run_route integration tests ──────────────────────────────────────────────


def test_run_route_missing_api_key(tmp_path, monkeypatch, capsys):
    """run_route exits with error when API key env var is not set."""
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    result = run_route(agents_md, "some request", None, "anthropic")
    assert result == 1


def test_run_route_missing_openai_key(tmp_path, monkeypatch):
    """run_route exits with error when OpenAI API key is not set."""
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    result = run_route(agents_md, "some request", None, "openai")
    assert result == 1


def test_run_route_sdk_not_installed(tmp_path, monkeypatch):
    """run_route exits with error when required SDK is not installed."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    # Mock _make_client to return None (SDK not installed)
    with mock.patch("framework_chief.route._make_client", return_value=(None, None)):
        result = run_route(agents_md, "some request", None, "anthropic")

    assert result == 1


def test_run_route_single_turn_agree(tmp_path, monkeypatch):
    """run_route handles AGREE state and exits."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    mock_client = mock.MagicMock()
    mock_response = mock.MagicMock()
    mock_response.content = [
        mock.MagicMock(
            text="Recommendation here\nCHIEF_EVAL: state=AGREE verdict=openspec"
        )
    ]
    mock_client.messages.create.return_value = mock_response

    with mock.patch("framework_chief.route._make_client") as mock_make_client:
        mock_make_client.return_value = (mock_client, _call_anthropic)

        result = run_route(agents_md, "user request", None, "anthropic")

    assert result == 0


def test_run_route_single_turn_refuse(tmp_path, monkeypatch):
    """run_route handles REFUSE state and exits."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    mock_client = mock.MagicMock()
    mock_response = mock.MagicMock()
    mock_response.content = [
        mock.MagicMock(text="Cannot help\nCHIEF_EVAL: state=REFUSE verdict=refuse")
    ]
    mock_client.messages.create.return_value = mock_response

    with mock.patch("framework_chief.route._make_client") as mock_make_client:
        mock_make_client.return_value = (mock_client, _call_anthropic)

        result = run_route(agents_md, "user request", None, "anthropic")

    assert result == 0


def test_run_route_max_loop_iterations_exceeded(tmp_path, monkeypatch):
    """run_route exits with error after MAX_LOOP_ITERATIONS."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    mock_client = mock.MagicMock()
    mock_response = mock.MagicMock()
    # Always return CLARIFY so loop continues
    mock_response.content = [
        mock.MagicMock(
            text="Please continue\nCHIEF_EVAL: state=CLARIFY verdict=spec-kit"
        )
    ]
    mock_client.messages.create.return_value = mock_response

    with (
        mock.patch("framework_chief.route._make_client") as mock_make_client,
        mock.patch("sys.stdin.readline", side_effect=["answer"] * MAX_LOOP_ITERATIONS),
    ):
        mock_make_client.return_value = (mock_client, _call_anthropic)

        result = run_route(agents_md, "user request", None, "anthropic")

    assert result == 1


def test_run_route_max_sentinel_retries_exceeded(tmp_path, monkeypatch):
    """run_route exits with error after MAX_SENTINEL_RETRIES sentinel failures."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    mock_client = mock.MagicMock()
    mock_response = mock.MagicMock()
    # Always return response without valid sentinel
    mock_response.content = [mock.MagicMock(text="No sentinel in this response")]
    mock_client.messages.create.return_value = mock_response

    with (
        mock.patch("framework_chief.route._make_client") as mock_make_client,
        mock.patch(
            "sys.stdin.readline",
            side_effect=["user response"] * MAX_SENTINEL_RETRIES,
        ),
    ):
        mock_make_client.return_value = (mock_client, _call_anthropic)

        result = run_route(agents_md, "user request", None, "anthropic")

    assert result == 1


def test_run_route_clarify_flow(tmp_path, monkeypatch):
    """run_route handles CLARIFY state and prompts for follow-up."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    mock_client = mock.MagicMock()

    # First call returns CLARIFY, second returns AGREE
    mock_responses = [
        mock.MagicMock(
            content=[
                mock.MagicMock(
                    text="Need more info\nCHIEF_EVAL: state=CLARIFY verdict=spec-kit"
                )
            ]
        ),
        mock.MagicMock(
            content=[
                mock.MagicMock(
                    text="Thank you\nCHIEF_EVAL: state=AGREE verdict=spec-kit"
                )
            ]
        ),
    ]
    mock_client.messages.create.side_effect = mock_responses

    with (
        mock.patch("framework_chief.route._make_client") as mock_make_client,
        mock.patch("sys.stdin.readline", return_value="follow-up answer"),
    ):
        mock_make_client.return_value = (mock_client, _call_anthropic)

        result = run_route(agents_md, "user request", None, "anthropic")

    assert result == 0
    # Should have made 2 API calls (initial + follow-up)
    assert mock_client.messages.create.call_count == 2


def test_run_route_keyboard_interrupt_on_initial_prompt(tmp_path, monkeypatch):
    """run_route returns 0 on KeyboardInterrupt during initial prompt."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    with (
        mock.patch("framework_chief.route._make_client") as mock_make_client,
        mock.patch("sys.stdin.readline", side_effect=KeyboardInterrupt()),
    ):
        mock_make_client.return_value = (mock.MagicMock(), _call_anthropic)

        result = run_route(agents_md, None, None, "anthropic")

    assert result == 0


def test_run_route_api_error_handling(tmp_path, monkeypatch):
    """run_route handles API errors gracefully."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    mock_client = mock.MagicMock()
    mock_client.messages.create.side_effect = RuntimeError("API timeout")

    with mock.patch("framework_chief.route._make_client") as mock_make_client:
        mock_make_client.return_value = (mock_client, _call_anthropic)

        result = run_route(agents_md, "user request", None, "anthropic")

    assert result == 1


# ── Fragile point 1: Raw response appended before validation ────────────────


def test_run_route_malformed_sentinel_no_message_duplication(tmp_path, monkeypatch):
    """When sentinel parsing fails, raw response is appended but not duplicated on retry.

    Regression test for fragile point 1: raw response is appended to messages
    before validation. On retry, we should not see duplicate malformed entries
    accumulating.
    """
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    mock_client = mock.MagicMock()

    # First response: no sentinel. Second response: valid AGREE with sentinel.
    mock_responses = [
        mock.MagicMock(content=[mock.MagicMock(text="Response without sentinel")]),
        mock.MagicMock(
            content=[
                mock.MagicMock(
                    text="Valid response\nCHIEF_EVAL: state=AGREE verdict=openspec"
                )
            ]
        ),
    ]
    mock_client.messages.create.side_effect = mock_responses

    with (
        mock.patch("framework_chief.route._make_client") as mock_make_client,
        mock.patch("sys.stdin.readline", return_value="user follow-up"),
    ):
        mock_make_client.return_value = (mock_client, _call_anthropic)

        result = run_route(agents_md, "user request", None, "anthropic")

    assert result == 0
    # Verify messages list contains exactly 3 items:
    # [0] user's initial request, [1] assistant's malformed response, [2] user's retry
    # (assistant's final AGREE comes after, but we're checking the state was clean)
    # We check call count to ensure no duplication: 2 calls total (initial + retry)
    assert mock_client.messages.create.call_count == 2


def test_run_route_sentinel_retry_counter_increments_without_duplication(
    tmp_path, monkeypatch
):
    """Sentinel failure counter increments independently of message history growth.

    Even after appending malformed response, the sentinel_failures counter
    should track actual failures, not message count.
    """
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    mock_client = mock.MagicMock()

    # Three malformed responses (no sentinel)
    mock_responses = [
        mock.MagicMock(content=[mock.MagicMock(text="Response 1 without sentinel")]),
        mock.MagicMock(content=[mock.MagicMock(text="Response 2 without sentinel")]),
        mock.MagicMock(content=[mock.MagicMock(text="Response 3 without sentinel")]),
        mock.MagicMock(content=[mock.MagicMock(text="Response 4 without sentinel")]),
    ]
    mock_client.messages.create.side_effect = mock_responses

    with (
        mock.patch("framework_chief.route._make_client") as mock_make_client,
        mock.patch("sys.stdin.readline", side_effect=["retry1", "retry2", "retry3"]),
    ):
        mock_make_client.return_value = (mock_client, _call_anthropic)

        result = run_route(agents_md, "user request", None, "anthropic")

    # Should fail after MAX_SENTINEL_RETRIES (3) attempts
    assert result == 1
    # Should have exactly 3 API calls (initial + 2 retries before giving up)
    assert mock_client.messages.create.call_count == 3


# ── Fragile point 2: Partial sentinel match (empty verdict through regex) ────


def test_strip_sentinel_rejects_empty_verdict():
    """_strip_sentinel should reject sentinel with empty verdict group.

    Regression test for fragile point 2: regex pattern can match
    'CHIEF_EVAL: state=AGREE verdict=' with empty verdict.
    """
    text = "Response\nCHIEF_EVAL: state=AGREE verdict="
    _, state, verdict, error = _strip_sentinel(text)
    # Empty verdict should not match the pattern at all (requires [a-z0-9-]+)
    assert state is None
    assert verdict is None
    # Either no error (sentinel not matched) or format error
    assert error is None or "format mismatch" in error.lower()


def test_strip_sentinel_rejects_empty_state():
    """_strip_sentinel should reject sentinel with empty state group."""
    text = "Response\nCHIEF_EVAL: state= verdict=openspec"
    _, state, verdict, error = _strip_sentinel(text)
    # Empty state should not match the pattern (requires [A-Z_]+)
    assert state is None
    assert verdict is None
    assert error is None or "format mismatch" in error.lower()


def test_strip_sentinel_requires_non_empty_groups():
    """Ensure regex pattern requires at least one character for both groups."""
    # Pattern: ([A-Z_]+) requires 1+, ([a-z0-9-]+) requires 1+
    # These should all fail:
    test_cases = [
        "CHIEF_EVAL: state=AGREE verdict=",  # empty verdict
        "CHIEF_EVAL: state= verdict=openspec",  # empty state
        "CHIEF_EVAL: state= verdict=",  # both empty
        "CHIEF_EVAL: state=AGREE verdict= extra",  # empty verdict before extra
    ]
    for text in test_cases:
        _, state, verdict, _ = _strip_sentinel(text)
        assert state is None, f"Failed for: {text}"
        assert verdict is None, f"Failed for: {text}"


# ── Fragile point 3: Sentinel UX ambiguity on failure (MAX_SENTINEL_RETRIES) ──


def test_run_route_sentinel_exhaustion_exits_non_zero(tmp_path, monkeypatch):
    """When MAX_SENTINEL_RETRIES exhausted, run_route exits with code 1 (non-zero).

    Regression test for fragile point 3: ensures no infinite loop and no
    misleading "continue describing" prompt after exhaustion.
    """
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    mock_client = mock.MagicMock()
    # Always return response without sentinel
    mock_response = mock.MagicMock(
        content=[mock.MagicMock(text="No sentinel here, just text")]
    )
    mock_client.messages.create.return_value = mock_response

    with (
        mock.patch("framework_chief.route._make_client") as mock_make_client,
        mock.patch(
            "sys.stdin.readline",
            side_effect=["user response"] * (MAX_SENTINEL_RETRIES - 1),
        ),
    ):
        mock_make_client.return_value = (mock_client, _call_anthropic)

        result = run_route(agents_md, "initial request", None, "anthropic")

    # Must exit with non-zero when sentinel exhaustion occurs
    assert result == 1
    # Verify we made exactly MAX_SENTINEL_RETRIES API calls
    assert mock_client.messages.create.call_count == MAX_SENTINEL_RETRIES


def test_run_route_sentinel_failure_message_not_infinite(tmp_path, monkeypatch):
    """Ensure no infinite retry loop when sentinel parsing fails consistently."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    mock_client = mock.MagicMock()
    mock_response = mock.MagicMock(
        content=[
            mock.MagicMock(
                text="CHIEF_EVAL: state=INVALID verdict=unknown"
            )  # malformed sentinel
        ]
    )
    mock_client.messages.create.return_value = mock_response

    with (
        mock.patch("framework_chief.route._make_client") as mock_make_client,
        mock.patch(
            "sys.stdin.readline",
            side_effect=["response"] * MAX_SENTINEL_RETRIES,
        ),
    ):
        mock_make_client.return_value = (mock_client, _call_anthropic)

        result = run_route(agents_md, "initial request", None, "anthropic")

    assert result == 1
    # Exactly MAX_SENTINEL_RETRIES calls, then abort
    assert mock_client.messages.create.call_count == MAX_SENTINEL_RETRIES


# ── Verify existing tests: CLARIFY→AGREE multi-turn flow ────────────────────


def test_run_route_clarify_flow_validates_two_turns(tmp_path, monkeypatch):
    """Explicit test that CLARIFY→AGREE flow makes exactly 2 API calls.

    Regression test: ensuring the mock checks both turns, not just the first.
    """
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    mock_client = mock.MagicMock()

    # First call returns CLARIFY, second returns AGREE
    mock_responses = [
        mock.MagicMock(
            content=[
                mock.MagicMock(
                    text="I need clarification. What is your requirement?\nCHIEF_EVAL: state=CLARIFY verdict=spec-kit"
                )
            ]
        ),
        mock.MagicMock(
            content=[
                mock.MagicMock(
                    text="Thank you. Based on your answer, I recommend this stack.\nCHIEF_EVAL: state=AGREE verdict=spec-kit"
                )
            ]
        ),
    ]
    mock_client.messages.create.side_effect = mock_responses

    with (
        mock.patch("framework_chief.route._make_client") as mock_make_client,
        mock.patch("sys.stdin.readline", return_value="my clarification answer"),
    ):
        mock_make_client.return_value = (mock_client, _call_anthropic)

        result = run_route(agents_md, "user request", None, "anthropic")

    assert result == 0
    # Verify exactly 2 API calls were made
    assert mock_client.messages.create.call_count == 2
    # Verify the second call included the user's follow-up
    second_call_messages = mock_client.messages.create.call_args_list[1][1]["messages"]
    assert len(second_call_messages) >= 2  # at least initial + follow-up


# ── Verify _call_github sets correct base_url and uses GITHUB_TOKEN ──────────


def test_call_github_sets_base_url_and_token(monkeypatch):
    """_make_client('github', token) must use GitHub Models endpoint and token."""
    mock_openai_module = mock.MagicMock()
    mock_openai_client = mock.MagicMock()
    mock_openai_module.OpenAI.return_value = mock_openai_client

    monkeypatch.setitem(
        __import__("sys").modules,
        "openai",
        mock_openai_module,
    )

    github_token = "test-github-token-12345"
    client, call_fn = _make_client("github", github_token)

    # Verify OpenAI was instantiated with GitHub base URL
    assert client is not None
    assert call_fn == _call_openai

    call_kwargs = mock_openai_module.OpenAI.call_args[1]
    assert call_kwargs["base_url"] == "https://models.inference.ai.azure.com"
    assert call_kwargs["api_key"] == github_token


def test_call_github_in_run_route_uses_github_token(tmp_path, monkeypatch):
    """run_route with provider='github' must use GITHUB_TOKEN env var."""
    github_token = "ghp_test1234567890"
    monkeypatch.setenv("GITHUB_TOKEN", github_token)

    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")

    mock_client = mock.MagicMock()
    mock_choice = mock.MagicMock()
    mock_choice.message.content = (
        "Recommendation\nCHIEF_EVAL: state=AGREE verdict=openspec"
    )
    mock_response = mock.MagicMock()
    mock_response.choices = [mock_choice]
    mock_client.chat.completions.create.return_value = mock_response

    with mock.patch("framework_chief.route._make_client") as mock_make_client:
        mock_make_client.return_value = (mock_client, _call_openai)

        result = run_route(agents_md, "user request", None, "github")

    assert result == 0
    # Verify _make_client was called with github provider and GITHUB_TOKEN
    mock_make_client.assert_called_once_with("github", github_token)
