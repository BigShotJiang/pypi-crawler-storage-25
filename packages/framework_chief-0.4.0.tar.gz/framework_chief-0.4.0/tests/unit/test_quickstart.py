"""test_quickstart.py — Unit tests for load_quickstart and render_quickstart.

Test coverage:
1. load_quickstart happy paths — all five frameworks return non-None strings
2. load_quickstart edge cases — missing files, no section, etc.
3. render_quickstart output — panel rendering with Rich console
4. Integration — CLI calls load_quickstart and render_quickstart after install

Run with:
    pytest tests/unit/test_quickstart.py
    uv run pytest tests/unit/test_quickstart.py -v
"""

from __future__ import annotations

import re
import subprocess
import sys
from io import StringIO
from pathlib import Path
from unittest.mock import patch

import pytest
from rich.console import Console

from framework_chief.renderer import render_quickstart
from framework_chief.stacks import load_quickstart

ROOT = Path(__file__).resolve().parent.parent.parent

_VENV_PY = ROOT / ".venv" / "bin" / "python"
_PY = str(_VENV_PY) if _VENV_PY.exists() else sys.executable
_CHIEF = [_PY, "-m", "framework_chief.cli"]


def run(*args: str, cwd: Path = ROOT) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [*_CHIEF, *args],
        cwd=cwd,
        capture_output=True,
        text=True,
    )


# ── load_quickstart: happy paths ─────────────────────────────────────────────


KNOWN_FRAMEWORKS = [
    "spec-kit",
    "openspec",
    "bmad",
    "gsd2",
    "superpowers",
]


@pytest.mark.parametrize("fw_name", KNOWN_FRAMEWORKS)
def test_load_quickstart_returns_non_none_for_known_frameworks(fw_name: str):
    """All five known frameworks have a non-None quickstart section."""
    result = load_quickstart(fw_name)
    assert result is not None, f"{fw_name} returned None — check adapter file"
    assert isinstance(result, str), f"{fw_name} returned {type(result)}, not str"
    assert len(result) > 0, f"{fw_name} returned empty string"


@pytest.mark.parametrize("fw_name", KNOWN_FRAMEWORKS)
def test_load_quickstart_content_is_stripped(fw_name: str):
    """Quickstart content has no leading/trailing whitespace."""
    result = load_quickstart(fw_name)
    assert result is not None
    assert result == result.strip(), (
        f"{fw_name}: content is not stripped. "
        f"Got leading/trailing whitespace: {repr(result[:20])}...{repr(result[-20:])}"
    )


@pytest.mark.parametrize("fw_name", KNOWN_FRAMEWORKS)
def test_load_quickstart_last_line_contains_more_info(fw_name: str):
    """The last non-empty line should contain 'More info:' with a URL."""
    result = load_quickstart(fw_name)
    assert result is not None
    lines = [line.strip() for line in result.split("\n") if line.strip()]
    assert lines, f"{fw_name}: quickstart has no content"
    last_line = lines[-1]
    assert "More info:" in last_line, (
        f"{fw_name}: last line missing 'More info:'. "
        f"Last 3 lines: {lines[-3:]}"
    )
    # Verify URL is present (basic check: contains http)
    assert "http" in last_line, (
        f"{fw_name}: 'More info:' line missing URL. Last line: {last_line}"
    )


@pytest.mark.parametrize("fw_name", KNOWN_FRAMEWORKS)
def test_load_quickstart_does_not_include_next_section(fw_name: str):
    """Quickstart body stops at the next '##' heading (regression test)."""
    result = load_quickstart(fw_name)
    assert result is not None
    # Verify no content from subsequent ## sections leaked in
    # (The regex uses (?=^## |\Z) to stop at the next ## section)
    sections = re.split(r"^## ", result, flags=re.MULTILINE)
    # If the regex is correct, we should only have 1 section (the quickstart content)
    # Additional sections would cause sections to have length > 1
    assert len(sections) == 1, (
        f"{fw_name}: quickstart contains another ## section. "
        f"Sections found: {len(sections)}"
    )


# ── load_quickstart: edge cases ──────────────────────────────────────────────


def test_load_quickstart_returns_none_for_nonexistent_framework():
    """Unknown framework name (missing adapter file) → None."""
    result = load_quickstart("totally-bogus-framework-xyz-123")
    assert result is None


def test_load_quickstart_returns_none_for_file_without_quickstart_section(tmp_path):
    """Adapter with front-matter but no ## Quickstart section → None."""
    adapter_file = tmp_path / "test.md"
    adapter_file.write_text(
        """---
name: test-fw
slot: plan_spec
install_commands: []
---

# Adapter: test-fw

Some content here.

## Prerequisites

This is about prerequisites, not quickstart.

## Install commands

Some install commands.
""",
        encoding="utf-8",
    )

    # Test parse logic directly
    from framework_chief.stacks import parse_front_matter

    adapter_content = adapter_file.read_text(encoding="utf-8")
    _, body = parse_front_matter(adapter_content)
    m = re.search(
        r"^## Quickstart\s*\n(.*?)(?=^## |\Z)",
        body,
        re.DOTALL | re.MULTILINE,
    )
    assert m is None, "Should not find ## Quickstart section"


def test_load_quickstart_returns_none_for_file_with_frontmatter_no_quickstart(tmp_path):
    """Adapter with front-matter only, no content with quickstart → None."""
    adapter_file = tmp_path / "empty-adapter.md"
    adapter_file.write_text(
        """---
name: empty-fw
slot: plan_spec
install_commands: []
---
""",
        encoding="utf-8",
    )

    # Test parse logic directly
    from framework_chief.stacks import parse_front_matter

    adapter_content = adapter_file.read_text(encoding="utf-8")
    _, body = parse_front_matter(adapter_content)
    m = re.search(
        r"^## Quickstart\s*\n(.*?)(?=^## |\Z)",
        body,
        re.DOTALL | re.MULTILINE,
    )
    assert m is None, "Empty adapter should have no quickstart"


def test_load_quickstart_returns_none_for_file_without_frontmatter():
    """File with no YAML front-matter but has Quickstart section → still extract it."""
    # Note: load_quickstart still processes files without front-matter
    # (it just gets an empty dict and full body text)
    # So this test verifies the regex works on the full text
    from framework_chief.stacks import parse_front_matter

    content_no_frontmatter = """# Some Adapter

## Quickstart

Run this command:

```bash
some-command
```

More info: https://example.com
"""
    _, body = parse_front_matter(content_no_frontmatter)
    assert body == content_no_frontmatter  # parse_front_matter returns full text as body
    m = re.search(
        r"^## Quickstart\s*\n(.*?)(?=^## |\Z)",
        body,
        re.DOTALL | re.MULTILINE,
    )
    assert m is not None, "Should find quickstart even without front-matter"
    assert "Run this command:" in m.group(1)


# ── render_quickstart: output ────────────────────────────────────────────────


def test_render_quickstart_outputs_to_console(capsys):
    """render_quickstart produces output containing framework name and 'quickstart'."""
    render_quickstart("openspec", "Test quickstart content\n\nMore info: https://test.com")
    captured = capsys.readouterr()
    assert "quickstart" in captured.out.lower()
    assert "openspec" in captured.out.lower()


def test_render_quickstart_uses_rule_and_markdown():
    """render_quickstart emits a cyan Rule, then Markdown, then a dim Rule."""
    from rich.markdown import Markdown
    from rich.rule import Rule

    with patch("framework_chief.renderer.console") as mock_console:
        render_quickstart("spec-kit", "**Bold text** and *italic text*\n\nMore info: https://example.com")
        assert mock_console.print.call_count == 3, "Expected 3 console.print calls"
        first_arg = mock_console.print.call_args_list[0][0][0]
        assert isinstance(first_arg, Rule), f"Expected Rule, got {type(first_arg)}"
        assert "quickstart" in str(first_arg.title).lower()
        assert "spec-kit" in str(first_arg.title).lower()
        second_arg = mock_console.print.call_args_list[1][0][0]
        assert isinstance(second_arg, Markdown), f"Expected Markdown, got {type(second_arg)}"


def test_render_quickstart_rule_has_cyan_style():
    """render_quickstart leading Rule uses cyan style."""
    from rich.rule import Rule

    with patch("framework_chief.renderer.console") as mock_console:
        render_quickstart("bmad", "Test content\n\nMore info: https://test.com")
        first_arg = mock_console.print.call_args_list[0][0][0]
        assert isinstance(first_arg, Rule)
        assert first_arg.style == "cyan"


# ── integration: CLI calls quickstart after install ──────────────────────────


def test_dry_run_openspec_exits_0():
    """Smoke test: `chief dry-run openspec` exits 0."""
    r = run("dry-run", "openspec")
    assert r.returncode == 0, f"Expected exit 0, got {r.returncode}. stderr: {r.stderr}"


def test_dry_run_includes_framework_name_in_output():
    """Smoke test: dry-run output contains the framework name."""
    r = run("dry-run", "openspec")
    assert r.returncode == 0
    assert "openspec" in r.stdout.lower()


@pytest.mark.parametrize("fw_name", KNOWN_FRAMEWORKS)
def test_all_known_frameworks_exist_in_registry(fw_name: str):
    """Verify all five frameworks are loadable from REGISTRY."""
    from framework_chief.stacks import REGISTRY

    fw = REGISTRY.frameworks.get(fw_name)
    assert fw is not None, f"{fw_name} not in REGISTRY"


# ── parse_front_matter helper tests ──────────────────────────────────────────


def test_parse_front_matter_extracts_yaml():
    """parse_front_matter correctly extracts YAML metadata."""
    from framework_chief.stacks import parse_front_matter

    text = """---
name: test-fw
slot: plan_spec
---

# Content here

## Quickstart

Some quickstart content.
"""
    meta, body = parse_front_matter(text)
    assert meta.get("name") == "test-fw"
    assert meta.get("slot") == "plan_spec"
    # Body may have leading newline after front-matter separator
    assert "# Content here" in body
    assert "---" not in body  # Front-matter separator removed


def test_parse_front_matter_handles_missing_frontmatter():
    """parse_front_matter returns empty dict when no front-matter present."""
    from framework_chief.stacks import parse_front_matter

    text = "# Just a heading\n\nNo front-matter here."
    meta, body = parse_front_matter(text)
    assert meta == {}
    assert body == text


def test_parse_front_matter_handles_empty_yaml():
    """parse_front_matter handles empty YAML blocks."""
    from framework_chief.stacks import parse_front_matter

    text = """---
---

# Content
"""
    meta, body = parse_front_matter(text)
    # Empty YAML blocks might return None or empty dict
    assert meta == {} or meta is None
    assert "# Content" in body
