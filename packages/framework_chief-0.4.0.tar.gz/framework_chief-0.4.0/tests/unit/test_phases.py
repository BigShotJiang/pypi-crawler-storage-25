"""Unit tests for phases.py — Phase checkpointing logic."""

from __future__ import annotations

from framework_chief.phases import Phase, PhaseResult, _INIT_PHASES, _exec_copy_scripts, _exec_wire_agents
from framework_chief.project import ProjectLayout


def _sentinel_phase(artifact_name: str) -> Phase:
    """A Phase whose execute_fn writes a sentinel file."""

    def _execute(layout: ProjectLayout, _force: bool) -> PhaseResult:
        sentinel = layout.root / artifact_name
        sentinel.write_text("done", encoding="utf-8")
        return PhaseResult("sentinel", "done", f"{artifact_name} written")

    return Phase(
        name="sentinel",
        artifact=lambda layout: layout.root / artifact_name,
        execute_fn=_execute,
    )


def test_is_done_false_when_artifact_missing(tmp_path):
    assert _sentinel_phase("marker.txt").is_done(tmp_path) is False


def test_is_done_true_when_artifact_exists(tmp_path):
    (tmp_path / "marker.txt").write_text("x", encoding="utf-8")
    assert _sentinel_phase("marker.txt").is_done(tmp_path) is True


def test_status_done_when_artifact_exists(tmp_path):
    (tmp_path / "marker.txt").write_text("x", encoding="utf-8")
    result = _sentinel_phase("marker.txt").status(tmp_path)
    assert result.status == "done"


def test_status_failed_when_artifact_missing(tmp_path):
    result = _sentinel_phase("marker.txt").status(tmp_path)
    assert result.status == "failed"


def test_run_skips_when_already_done(tmp_path):
    (tmp_path / "marker.txt").write_text("x", encoding="utf-8")
    result = _sentinel_phase("marker.txt").run(tmp_path, force=False)
    assert result.status == "skipped"


def test_run_executes_when_not_done(tmp_path):
    result = _sentinel_phase("marker.txt").run(tmp_path, force=False)
    assert result.status == "done"
    assert (tmp_path / "marker.txt").exists()


def test_run_force_overwrites_existing(tmp_path):
    (tmp_path / "marker.txt").write_text("old", encoding="utf-8")
    result = _sentinel_phase("marker.txt").run(tmp_path, force=True)
    assert result.status == "done"
    assert (tmp_path / "marker.txt").read_text(encoding="utf-8") == "done"


def test_run_skips_symlink_as_done(tmp_path):
    target = tmp_path / "real.txt"
    target.write_text("x", encoding="utf-8")
    link = tmp_path / "marker.txt"
    link.symlink_to(target)
    result = _sentinel_phase("marker.txt").run(tmp_path, force=False)
    assert result.status == "skipped"


# ── always_run ────────────────────────────────────────────────────────────────


def test_run_executes_when_always_run_true_despite_artifact_exists(tmp_path):
    """Phase with always_run=True bypasses the sentinel skip when artifact exists."""
    executed: list[bool] = []

    def _execute(*_) -> PhaseResult:
        executed.append(True)
        return PhaseResult("test", "done", "executed")

    phase = Phase(
        name="test",
        artifact=lambda layout: layout.root / "marker.txt",
        execute_fn=_execute,
        always_run=True,
    )
    (tmp_path / "marker.txt").write_text("exists", encoding="utf-8")

    result = phase.run(tmp_path, force=False)
    assert result.status == "done"
    assert executed, "execute_fn should have been called"


def test_run_skips_when_always_run_false_and_artifact_exists(tmp_path):
    """Phase with always_run=False (default) still skips when artifact exists."""
    executed: list[bool] = []

    def _execute(*_) -> PhaseResult:
        executed.append(True)
        return PhaseResult("test", "done", "executed")

    phase = Phase(
        name="test",
        artifact=lambda layout: layout.root / "marker.txt",
        execute_fn=_execute,
        always_run=False,
    )
    (tmp_path / "marker.txt").write_text("exists", encoding="utf-8")

    result = phase.run(tmp_path, force=False)
    assert result.status == "skipped"
    assert not executed, "execute_fn must not be called when skipping"


def test_copy_scripts_phase_is_always_run():
    """copy_scripts in _INIT_PHASES has always_run=True so upgrades propagate .ps1 files."""
    copy_scripts = next(p for p in _INIT_PHASES if p.name == "copy_scripts")
    assert copy_scripts.always_run is True


# ── _exec_wire_agents error paths ─────────────────────────────────────────────


def test_exec_wire_agents_returns_failed_on_runtime_error(monkeypatch, tmp_path):
    """_exec_wire_agents returns failed PhaseResult when _shell_cmd raises RuntimeError."""

    def _raises(*_):
        raise RuntimeError("No shell interpreter found on Windows.")

    monkeypatch.setattr("framework_chief.phases._shell_cmd", _raises)
    result = _exec_wire_agents(ProjectLayout(tmp_path), False)
    assert result.status == "failed"
    assert "No shell interpreter found" in result.message
    assert "PowerShell" in result.remediation


def test_exec_wire_agents_returns_failed_on_file_not_found(monkeypatch, tmp_path):
    """_exec_wire_agents returns failed PhaseResult when the bash binary is missing."""

    def _raises(*_):
        raise FileNotFoundError("bash: No such file or directory")

    monkeypatch.setattr("framework_chief.phases._shell_cmd", _raises)
    result = _exec_wire_agents(ProjectLayout(tmp_path), False)
    assert result.status == "failed"
    assert "bash" in result.message


# ── _exec_copy_scripts CRLF normalisation ────────────────────────────────────


def test_copy_scripts_normalizes_ps1_to_crlf_on_windows(monkeypatch, tmp_path):
    """On Windows, deployed .ps1 files are normalised to CRLF."""
    import framework_chief.phases as _phases

    scripts_src = tmp_path / "data" / "scripts"
    scripts_src.mkdir(parents=True)
    (scripts_src / "test.ps1").write_bytes(b"line1\nline2\n")

    layout_root = tmp_path / "project"
    layout_root.mkdir()

    monkeypatch.setattr("sys.platform", "win32")
    monkeypatch.setattr(_phases, "_data", lambda: tmp_path / "data")

    result = _exec_copy_scripts(ProjectLayout(layout_root), False)

    assert result.status == "done"
    deployed = layout_root / "scripts" / "test.ps1"
    content = deployed.read_bytes()
    assert b"\r\n" in content, "CRLF must be present after normalisation"
    assert b"\r\r\n" not in content, "double-CRLF must not be introduced"


def test_copy_scripts_leaves_ps1_unchanged_on_non_windows(monkeypatch, tmp_path):
    """On Linux/macOS, deployed .ps1 files are NOT converted to CRLF."""
    import framework_chief.phases as _phases

    scripts_src = tmp_path / "data" / "scripts"
    scripts_src.mkdir(parents=True)
    (scripts_src / "test.ps1").write_bytes(b"line1\nline2\n")

    layout_root = tmp_path / "project"
    layout_root.mkdir()

    monkeypatch.setattr("sys.platform", "linux")
    monkeypatch.setattr(_phases, "_data", lambda: tmp_path / "data")

    result = _exec_copy_scripts(ProjectLayout(layout_root), False)

    assert result.status == "done"
    deployed = layout_root / "scripts" / "test.ps1"
    content = deployed.read_bytes()
    assert content == b"line1\nline2\n", "LF-only content must be preserved on non-Windows"
