"""Unit tests for cli.py — subcommand handlers."""

from __future__ import annotations

import argparse

from framework_chief.cli import cmd_sync


class TestCmdSync:
    """cmd_sync returns 127 when the shell interpreter is unavailable."""

    def test_returns_127_on_runtime_error(self, monkeypatch, tmp_path):
        """RuntimeError from _shell_cmd (no PowerShell found) → exit 127."""

        def _raises(*_):
            raise RuntimeError("No shell interpreter found on Windows.")

        monkeypatch.setattr("framework_chief.cli._shell_cmd", _raises)
        args = argparse.Namespace(project_dir=str(tmp_path), ai="all")
        assert cmd_sync(args) == 127

    def test_returns_127_on_file_not_found(self, monkeypatch, tmp_path):
        """FileNotFoundError from subprocess (bash missing) → exit 127."""

        def _raises(*_):
            raise FileNotFoundError("bash: No such file or directory")

        monkeypatch.setattr("framework_chief.cli._shell_cmd", _raises)
        args = argparse.Namespace(project_dir=str(tmp_path), ai="all")
        assert cmd_sync(args) == 127
