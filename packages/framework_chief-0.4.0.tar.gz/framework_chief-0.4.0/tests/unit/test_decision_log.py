"""Unit tests for decision_log.py."""

from __future__ import annotations

import pytest

from framework_chief.decision_log import DecisionLog, LogEntryError


def _log(tmp_path):
    return DecisionLog(tmp_path / ".chief" / "decision.md")


def test_bootstrap_creates_file(tmp_path):
    log = _log(tmp_path)
    assert not log.path.exists()
    log.bootstrap()
    assert log.path.exists()
    assert "# Framework Chief" in log.path.read_text(encoding="utf-8")


def test_bootstrap_is_idempotent(tmp_path):
    log = _log(tmp_path)
    log.bootstrap()
    first = log.path.read_text(encoding="utf-8")
    log.bootstrap()
    assert log.path.read_text(encoding="utf-8") == first


def test_parse_and_append_empty_raises(tmp_path):
    with pytest.raises(LogEntryError, match="at least one"):
        _log(tmp_path).parse_and_append([])


def test_parse_and_append_no_equals_raises(tmp_path):
    with pytest.raises(LogEntryError, match="malformed"):
        _log(tmp_path).parse_and_append(["stack"])


def test_parse_and_append_empty_value_raises(tmp_path):
    with pytest.raises(LogEntryError, match="empty value"):
        _log(tmp_path).parse_and_append(["stack="])


def test_parse_and_append_invalid_key_raises(tmp_path):
    with pytest.raises(LogEntryError, match="invalid key"):
        _log(tmp_path).parse_and_append(["bad key=val"])


def test_parse_and_append_valid_writes_and_returns(tmp_path):
    log = _log(tmp_path)
    pairs, date = log.parse_and_append(["stack=openspec", "mode=solo"])
    assert pairs == [("stack", "openspec"), ("mode", "solo")]
    assert date
    content = log.path.read_text(encoding="utf-8")
    assert "openspec" in content


def test_last_stack_no_file_returns_none(tmp_path):
    assert _log(tmp_path).last_stack() is None


def test_last_stack_returns_most_recent(tmp_path):
    log = _log(tmp_path)
    log.parse_and_append(["stack=openspec"])
    log.parse_and_append(["stack=bmad"])
    assert log.last_stack() == "bmad"


def test_last_stack_ignores_non_stack_lines(tmp_path):
    log = _log(tmp_path)
    log.parse_and_append(["stack=openspec", "reason=fast"])
    assert log.last_stack() == "openspec"


def test_read_entries_strips_header(tmp_path):
    log = _log(tmp_path)
    log.parse_and_append(["stack=openspec"])
    entries = log.read_entries()
    assert entries.startswith("### ")
    assert "# Framework Chief" not in entries


def test_read_entries_on_empty_log_returns_header(tmp_path):
    log = _log(tmp_path)
    log.bootstrap()
    entries = log.read_entries()
    assert entries  # non-empty — returns header when no entries
