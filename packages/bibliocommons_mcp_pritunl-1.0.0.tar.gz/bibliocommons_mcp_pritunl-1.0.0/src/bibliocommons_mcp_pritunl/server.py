#!/usr/bin/env python3
import base64
import hashlib
import hmac
import logging
import ipaddress
import os
import re
import time
import uuid

import requests

from ._shared import load_config as _base_load_config, setup_ssl
from fastmcp import FastMCP

mcp = FastMCP("Pritunl VPN")

logger = logging.getLogger(__name__)


def _validate_id(value: str, name: str) -> str:
    if not re.match(r'^[a-f0-9]{24}$', value):
        raise ValueError(f"Invalid {name}: expected 24-char hex string, got '{value}'")
    return value


def _validate_network(network: str) -> str:
    try:
        ipaddress.ip_network(network, strict=False)
    except ValueError:
        raise ValueError(f"Invalid network CIDR: '{network}'")
    return network


class PritunlClient:
    def __init__(self, host: str, api_token: str, api_secret: str, verify_ssl: bool = True,
                 ca_cert_path: str | None = None, timeout: int = 30):
        self.base_url = f"https://{host.rstrip('/')}"
        self.api_token = api_token
        self.api_secret = api_secret
        self.timeout = timeout
        self.session = requests.Session()
        setup_ssl(self.session, verify_ssl, ca_cert_path)

    def _auth_request(self, method: str, path: str, data=None):
        timestamp = str(int(time.time()))
        nonce = uuid.uuid4().hex
        auth_string = "&".join([self.api_token, timestamp, nonce, method.upper(), path])
        signature = base64.b64encode(
            hmac.new(self.api_secret.encode(), auth_string.encode(), hashlib.sha256).digest()
        ).decode()

        headers = {
            "Auth-Token": self.api_token,
            "Auth-Timestamp": timestamp,
            "Auth-Nonce": nonce,
            "Auth-Signature": signature,
        }

        url = f"{self.base_url}{path}"
        kwargs = {"headers": headers, "timeout": self.timeout}
        if data is not None:
            kwargs["json"] = data

        response = self.session.request(method.upper(), url, **kwargs)
        if not response.ok:
            logger.debug("API error response: %s", response.text[:500])
            raise RuntimeError(f"Pritunl API error: {response.status_code} {response.reason}")
        return response.json() if response.content else {}

    def get(self, path: str):
        return self._auth_request("GET", path)

    def post(self, path: str, data=None):
        return self._auth_request("POST", path, data)

    def put(self, path: str, data=None):
        return self._auth_request("PUT", path, data)

    def delete(self, path: str):
        return self._auth_request("DELETE", path)


def load_config(config_path: str | None = None) -> dict:
    return _base_load_config(config_path=config_path, default_dir=os.path.dirname(__file__), env_prefix="PRITUNL")


client: PritunlClient | None = None


def init_client(config_path: str | None = None):
    global client
    config = load_config(config_path)
    client = PritunlClient(**config)


def _client() -> PritunlClient:
    if client is None:
        init_client()
    return client


TOOL_REGISTRY: list[dict] = []

READ_ONLY_EXCLUDE = {
    "create_organization", "update_organization", "delete_organization",
    "create_user", "update_user", "delete_user",
    "create_server", "update_server", "delete_server",
    "start_server", "stop_server", "restart_server",
    "add_server_route", "update_server_route", "delete_server_route",
    "attach_organization", "detach_organization",
    "update_settings",
}


def _register(fn, tag: str, http_method: str = "GET", http_path: str | None = None):
    TOOL_REGISTRY.append({"fn": fn, "tag": tag, "http_method": http_method, "http_path": http_path or f"/{fn.__name__}"})


def _register_gateway_tools(tools, read_only=False):
    """Register 2 gateway tools that dispatch to all operations."""
    available = [t for t in tools if not (read_only and t["fn"].__name__ in READ_ONLY_EXCLUDE)]
    tool_map = {t["fn"].__name__: t for t in available}

    @mcp.tool()
    def pritunl_api(action: str, params: dict | None = None) -> dict | list:
        """Execute a Pritunl VPN action. Use pritunl_help to discover available actions and their parameters."""
        if params is None:
            params = {}
        if action not in tool_map:
            available_actions = sorted(tool_map.keys())
            raise ValueError(f"Unknown action '{action}'. Use pritunl_help to see available actions. Available: {', '.join(available_actions[:10])}...")
        fn = tool_map[action]["fn"]
        return fn(**params)

    @mcp.tool()
    def pritunl_help(query: str = "") -> list[dict]:
        """Search available Pritunl VPN actions. Returns action names, parameters, and descriptions. Call with empty query to list all actions."""
        import inspect
        results = []
        for name, entry in sorted(tool_map.items()):
            fn = entry["fn"]
            if query and query.lower() not in name.lower() and query.lower() not in (fn.__doc__ or "").lower():
                continue
            sig = inspect.signature(fn)
            params = {k: str(v.annotation.__name__) if v.annotation != inspect.Parameter.empty else "any"
                      for k, v in sig.parameters.items()}
            results.append({
                "action": name,
                "params": params,
                "description": (fn.__doc__ or "").strip().split("\n")[0],
                "category": entry.get("tag", ""),
                "read_only": name not in READ_ONLY_EXCLUDE,
            })
        return results


def register_mcp_tools(read_only: bool = False, expanded: bool = False):
    if expanded:
        for entry in TOOL_REGISTRY:
            fn = entry["fn"]
            if read_only and fn.__name__ in READ_ONLY_EXCLUDE:
                continue
            mcp.tool(name=fn.__name__, description=fn.__doc__, tags={entry["tag"]})(fn)
    else:
        _register_gateway_tools(TOOL_REGISTRY, read_only=read_only)


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------

def get_status() -> dict:
    """Get Pritunl system status (server count, host count, org count, online users)."""
    return _client().get("/status")
_register(get_status, "Status", "GET", "/status")


def get_events() -> list | dict:
    """Get real-time event stream from Pritunl."""
    return _client().get("/event")
_register(get_events, "Status", "GET", "/events")


# ---------------------------------------------------------------------------
# Organizations
# ---------------------------------------------------------------------------

def list_organizations() -> list | dict:
    """List all organizations."""
    return _client().get("/organization")
_register(list_organizations, "Organizations", "GET", "/organizations")


def get_organization(org_id: str) -> dict:
    """Get organization details by ID."""
    _validate_id(org_id, "org_id")
    return _client().get(f"/organization/{org_id}")
_register(get_organization, "Organizations", "GET", "/organizations/{org_id}")


def create_organization(name: str) -> dict:
    """Create a new organization."""
    return _client().post("/organization", {"name": name})
_register(create_organization, "Organizations", "POST", "/organizations")


def update_organization(org_id: str, name: str) -> dict:
    """Update an organization's name."""
    _validate_id(org_id, "org_id")
    return _client().put(f"/organization/{org_id}", {"name": name})
_register(update_organization, "Organizations", "PUT", "/organizations/{org_id}")


def delete_organization(org_id: str) -> dict:
    """Delete an organization."""
    _validate_id(org_id, "org_id")
    return _client().delete(f"/organization/{org_id}")
_register(delete_organization, "Organizations", "DELETE", "/organizations/{org_id}")


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------

def list_users(org_id: str) -> list | dict:
    """List all users in an organization."""
    _validate_id(org_id, "org_id")
    return _client().get(f"/user/{org_id}")
_register(list_users, "Users", "GET", "/users/{org_id}")


def get_user(org_id: str, user_id: str) -> dict:
    """Get user details by organization and user ID."""
    _validate_id(org_id, "org_id")
    _validate_id(user_id, "user_id")
    return _client().get(f"/user/{org_id}/{user_id}")
_register(get_user, "Users", "GET", "/users/{org_id}/{user_id}")


def create_user(org_id: str, name: str, email: str | None = None, disabled: bool = False) -> dict:
    """Create a new user in an organization."""
    _validate_id(org_id, "org_id")
    data = {"name": name, "disabled": disabled}
    if email is not None:
        data["email"] = email
    return _client().post(f"/user/{org_id}", data)
_register(create_user, "Users", "POST", "/users/{org_id}")


def update_user(org_id: str, user_id: str, name: str | None = None, email: str | None = None, disabled: bool | None = None) -> dict:
    """Update a user's properties (name, email, disabled status)."""
    _validate_id(org_id, "org_id")
    _validate_id(user_id, "user_id")
    data = {}
    if name is not None:
        data["name"] = name
    if email is not None:
        data["email"] = email
    if disabled is not None:
        data["disabled"] = disabled
    return _client().put(f"/user/{org_id}/{user_id}", data)
_register(update_user, "Users", "PUT", "/users/{org_id}/{user_id}")


def delete_user(org_id: str, user_id: str) -> dict:
    """Delete a user from an organization."""
    _validate_id(org_id, "org_id")
    _validate_id(user_id, "user_id")
    return _client().delete(f"/user/{org_id}/{user_id}")
_register(delete_user, "Users", "DELETE", "/users/{org_id}/{user_id}")


def get_user_audit(org_id: str, user_id: str) -> list | dict:
    """Get audit log for a specific user."""
    _validate_id(org_id, "org_id")
    _validate_id(user_id, "user_id")
    return _client().get(f"/user/{org_id}/{user_id}/audit")
_register(get_user_audit, "Users", "GET", "/users/{org_id}/{user_id}/audit")


def get_user_key_download_url(org_id: str, user_id: str) -> dict:
    """Get temporary key download links for a user."""
    _validate_id(org_id, "org_id")
    _validate_id(user_id, "user_id")
    return _client().get(f"/key/{org_id}/{user_id}")
_register(get_user_key_download_url, "Users", "GET", "/users/{org_id}/{user_id}/keys")


# ---------------------------------------------------------------------------
# Servers
# ---------------------------------------------------------------------------

def list_servers() -> list | dict:
    """List all VPN servers."""
    return _client().get("/server")
_register(list_servers, "Servers", "GET", "/servers")


def get_server(server_id: str) -> dict:
    """Get VPN server details by ID."""
    _validate_id(server_id, "server_id")
    return _client().get(f"/server/{server_id}")
_register(get_server, "Servers", "GET", "/servers/{server_id}")


def create_server(name: str, network: str, port: int, protocol: str = "udp",
                  dns_address: str | None = None, search_domain: str | None = None,
                  cipher: str | None = None, hash: str | None = None,
                  inter_client: bool = True, dns_mapping: bool = False,
                  otp_auth: bool = False, lzo_compression: bool = False,
                  debug: bool = False) -> dict:
    """Create a new VPN server."""
    data = {"name": name, "network": network, "port": port, "protocol": protocol,
            "inter_client": inter_client, "dns_mapping": dns_mapping,
            "otp_auth": otp_auth, "lzo_compression": lzo_compression, "debug": debug}
    if dns_address is not None:
        data["dns_address"] = dns_address
    if search_domain is not None:
        data["search_domain"] = search_domain
    if cipher is not None:
        data["cipher"] = cipher
    if hash is not None:
        data["hash"] = hash
    return _client().post("/server", data)
_register(create_server, "Servers", "POST", "/servers")


def update_server(server_id: str, name: str | None = None, network: str | None = None,
                  port: int | None = None, protocol: str | None = None,
                  dns_address: str | None = None, cipher: str | None = None,
                  hash: str | None = None, inter_client: bool | None = None,
                  dns_mapping: bool | None = None, otp_auth: bool | None = None,
                  debug: bool | None = None) -> dict:
    """Update a VPN server. Fetches current config, merges changes, then PUTs the full object."""
    _validate_id(server_id, "server_id")
    current = _client().get(f"/server/{server_id}")
    params = {"name": name, "network": network, "port": port, "protocol": protocol,
              "dns_address": dns_address, "cipher": cipher, "hash": hash,
              "inter_client": inter_client, "dns_mapping": dns_mapping,
              "otp_auth": otp_auth, "debug": debug}
    current.update({k: v for k, v in params.items() if v is not None})
    return _client().put(f"/server/{server_id}", current)
_register(update_server, "Servers", "PUT", "/servers/{server_id}")


def delete_server(server_id: str) -> dict:
    """Delete a VPN server."""
    _validate_id(server_id, "server_id")
    return _client().delete(f"/server/{server_id}")
_register(delete_server, "Servers", "DELETE", "/servers/{server_id}")


def start_server(server_id: str) -> dict:
    """Start a VPN server."""
    _validate_id(server_id, "server_id")
    return _client().put(f"/server/{server_id}/operation/start")
_register(start_server, "Servers", "PUT", "/servers/{server_id}/start")


def stop_server(server_id: str) -> dict:
    """Stop a VPN server."""
    _validate_id(server_id, "server_id")
    return _client().put(f"/server/{server_id}/operation/stop")
_register(stop_server, "Servers", "PUT", "/servers/{server_id}/stop")


def restart_server(server_id: str) -> dict:
    """Restart a VPN server."""
    _validate_id(server_id, "server_id")
    return _client().put(f"/server/{server_id}/operation/restart")
_register(restart_server, "Servers", "PUT", "/servers/{server_id}/restart")


def get_server_output(server_id: str) -> dict:
    """Get server log output."""
    _validate_id(server_id, "server_id")
    return _client().get(f"/server/{server_id}/output")
_register(get_server_output, "Servers", "GET", "/servers/{server_id}/output")


def get_server_bandwidth(server_id: str, period: str = "1m") -> dict:
    """Get server bandwidth statistics. Period: 1m, 5m, 30m, 2h, 1d."""
    valid_periods = ('1m', '5m', '30m', '2h', '1d')
    if period not in valid_periods:
        raise ValueError(f"Invalid period '{period}'. Must be one of: {', '.join(valid_periods)}")
    _validate_id(server_id, "server_id")
    return _client().get(f"/server/{server_id}/bandwidth/{period}")
_register(get_server_bandwidth, "Servers", "GET", "/servers/{server_id}/bandwidth/{period}")


# ---------------------------------------------------------------------------
# Server Routes
# ---------------------------------------------------------------------------

def list_server_routes(server_id: str) -> list | dict:
    """List all routes on a VPN server."""
    _validate_id(server_id, "server_id")
    return _client().get(f"/server/{server_id}/route")
_register(list_server_routes, "Server Routes", "GET", "/servers/{server_id}/routes")


def add_server_route(server_id: str, network: str, nat: bool = True, comment: str | None = None) -> dict:
    """Add a route to a VPN server."""
    _validate_id(server_id, "server_id")
    _validate_network(network)
    data = {"network": network, "nat": nat}
    if comment is not None:
        data["comment"] = comment
    return _client().post(f"/server/{server_id}/route", data)
_register(add_server_route, "Server Routes", "POST", "/servers/{server_id}/routes")


def update_server_route(server_id: str, network: str, nat: bool | None = None, comment: str | None = None) -> dict:
    """Update a route on a VPN server."""
    _validate_id(server_id, "server_id")
    _validate_network(network)
    data = {}
    if nat is not None:
        data["nat"] = nat
    if comment is not None:
        data["comment"] = comment
    return _client().put(f"/server/{server_id}/route/{network}", data)
_register(update_server_route, "Server Routes", "PUT", "/servers/{server_id}/routes/{network}")


def delete_server_route(server_id: str, network: str) -> dict:
    """Delete a route from a VPN server."""
    _validate_id(server_id, "server_id")
    _validate_network(network)
    return _client().delete(f"/server/{server_id}/route/{network}")
_register(delete_server_route, "Server Routes", "DELETE", "/servers/{server_id}/routes/{network}")


# ---------------------------------------------------------------------------
# Server Organizations
# ---------------------------------------------------------------------------

def attach_organization(server_id: str, org_id: str) -> dict:
    """Attach an organization to a VPN server."""
    _validate_id(server_id, "server_id")
    _validate_id(org_id, "org_id")
    return _client().put(f"/server/{server_id}/organization/{org_id}")
_register(attach_organization, "Server Organizations", "PUT", "/servers/{server_id}/organizations/{org_id}")


def detach_organization(server_id: str, org_id: str) -> dict:
    """Detach an organization from a VPN server."""
    _validate_id(server_id, "server_id")
    _validate_id(org_id, "org_id")
    return _client().delete(f"/server/{server_id}/organization/{org_id}")
_register(detach_organization, "Server Organizations", "DELETE", "/servers/{server_id}/organizations/{org_id}")


# ---------------------------------------------------------------------------
# Hosts
# ---------------------------------------------------------------------------

def list_hosts() -> list | dict:
    """List all Pritunl hosts."""
    return _client().get("/host")
_register(list_hosts, "Hosts", "GET", "/hosts")


def get_host(host_id: str) -> dict:
    """Get host details by ID."""
    _validate_id(host_id, "host_id")
    return _client().get(f"/host/{host_id}")
_register(get_host, "Hosts", "GET", "/hosts/{host_id}")


def list_server_hosts(server_id: str) -> list | dict:
    """List hosts attached to a VPN server."""
    _validate_id(server_id, "server_id")
    return _client().get(f"/server/{server_id}/host")
_register(list_server_hosts, "Hosts", "GET", "/servers/{server_id}/hosts")


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------

def get_settings() -> dict:
    """Get global Pritunl settings."""
    return _client().get("/settings")
_register(get_settings, "Settings", "GET", "/settings")


def update_settings(theme: str | None = None, auditing: str | None = None,
                    monitoring: str | None = None, sso: str | None = None,
                    sso_match: str | None = None, sso_org: str | None = None,
                    email_server: str | None = None, email_from: str | None = None,
                    pin_mode: str | None = None) -> dict:
    """Update global Pritunl settings. Fetches current settings, merges changes, then PUTs the full object."""
    current = _client().get("/settings")
    params = {"theme": theme, "auditing": auditing, "monitoring": monitoring,
              "sso": sso, "sso_match": sso_match, "sso_org": sso_org,
              "email_server": email_server, "email_from": email_from, "pin_mode": pin_mode}
    current.update({k: v for k, v in params.items() if v is not None})
    return _client().put("/settings", current)
_register(update_settings, "Settings", "PUT", "/settings")
