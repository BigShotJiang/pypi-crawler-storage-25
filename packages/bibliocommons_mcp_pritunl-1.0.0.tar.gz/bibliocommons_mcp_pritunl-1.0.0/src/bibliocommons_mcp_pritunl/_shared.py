import os
import json
import logging

logger = logging.getLogger("mcp-servers")


def load_config(
    config_path: str | None = None,
    default_dir: str = ".",
    env_prefix: str = "",
    required_fields: list[str] | None = None,
) -> dict:
    """Load config from file or env vars. Validates required fields."""
    if config_path is None:
        config_path = os.path.join(default_dir, "config.json")

    try:
        if os.path.exists(config_path):
            check_file_permissions(config_path)
            with open(config_path) as f:
                config = json.load(f)
        else:
            p = f"{env_prefix}_" if env_prefix else ""
            config = {
                "host": os.getenv(f"{p}HOST"),
                "api_token": os.getenv(f"{p}API_TOKEN"),
                "api_secret": os.getenv(f"{p}API_SECRET"),
                "verify_ssl": os.getenv(f"{p}VERIFY_SSL", "true").lower() == "true",
                "ca_cert_path": os.getenv(f"{p}CA_CERT_PATH"),
                "timeout": int(os.getenv(f"{p}TIMEOUT", "30")),
            }
    except (IOError, json.JSONDecodeError) as e:
        raise ValueError(f"Failed to load config: {e}")

    required = required_fields or ["host", "api_token", "api_secret"]
    missing = [k for k in required if not config.get(k)]
    if missing:
        p = f"{env_prefix}_" if env_prefix else ""
        env_hint = ", ".join(f"{p}{k.upper()}" for k in required)
        raise ValueError(
            f"Missing required configuration: {', '.join(missing)}. "
            f"Set in config.json or environment variables ({env_hint})"
        )
    return config


def check_file_permissions(path: str) -> None:
    """Warn if a config file is readable by others."""
    try:
        mode = os.stat(path).st_mode & 0o777
        if mode & 0o077:
            logger.warning(
                "Config file %s is readable by others (mode %s). Run: chmod 600 %s",
                path, oct(mode), path,
            )
    except OSError:
        pass


def setup_ssl(session, verify_ssl: bool = True, ca_cert_path: str | None = None) -> None:
    """Configure SSL verification on a requests.Session."""
    if ca_cert_path and os.path.exists(ca_cert_path):
        session.verify = ca_cert_path
    elif not verify_ssl:
        session.verify = False
        logger.warning("SSL verification disabled. Use ca_cert_path for self-signed certs.")
    else:
        session.verify = True
