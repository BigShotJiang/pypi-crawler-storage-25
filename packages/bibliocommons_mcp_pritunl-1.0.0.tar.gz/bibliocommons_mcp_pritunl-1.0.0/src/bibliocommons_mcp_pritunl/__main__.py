import argparse
import os

from . import __version__
from .server import mcp, init_client, register_mcp_tools


def main():
    env = "PRITUNL"
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", action="version", version=__version__)
    parser.add_argument("--config", default=os.getenv(f"{env}_CONFIG"),
                        help=f"Path to config.json (env: {env}_CONFIG)")
    parser.add_argument("--read-only", action="store_true",
                        default=os.getenv(f"{env}_READ_ONLY", "").lower() in ("1", "true", "yes"),
                        help=f"Exclude destructive tools (env: {env}_READ_ONLY)")
    parser.add_argument("--expanded", action="store_true",
                        default=os.getenv(f"{env}_EXPANDED", "").lower() in ("1", "true", "yes"),
                        help=f"Register all tools individually instead of gateway mode (env: {env}_EXPANDED)")
    parser.add_argument("--transport", choices=["stdio", "http"],
                        default=os.getenv(f"{env}_TRANSPORT", "stdio"),
                        help=f"Transport mode (env: {env}_TRANSPORT)")
    parser.add_argument("--port", type=int,
                        default=int(os.getenv(f"{env}_PORT", "8000")),
                        help=f"HTTP port (env: {env}_PORT)")
    args = parser.parse_args()

    init_client(args.config)
    register_mcp_tools(read_only=args.read_only, expanded=args.expanded)

    if args.transport == "http":
        mcp.run(transport="streamable-http", port=args.port)
    else:
        mcp.run()


if __name__ == "__main__":
    main()
