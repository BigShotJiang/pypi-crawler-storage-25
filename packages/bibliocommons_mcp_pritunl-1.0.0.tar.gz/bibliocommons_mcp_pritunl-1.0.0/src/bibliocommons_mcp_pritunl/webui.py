#!/usr/bin/env python3
import inspect
import os

import requests as _requests
from fastapi import FastAPI, HTTPException
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

from . import __version__
from .server import init_client, TOOL_REGISTRY, READ_ONLY_EXCLUDE


def create_app(config_path: str | None = None, read_only: bool = False) -> FastAPI:
    app = FastAPI(
        title="Pritunl VPN API",
        description="REST API wrapper for Pritunl VPN MCP Server",
        version=__version__,
    )

    static_dir = os.path.join(os.path.dirname(__file__), "static")
    if os.path.exists(static_dir):
        app.mount("/static", StaticFiles(directory=static_dir), name="static")

    @app.get("/", include_in_schema=False)
    async def root():
        return RedirectResponse(url="/docs")

    @app.get("/health", tags=["Health"])
    async def health():
        return {"status": "ok"}

    init_client(config_path)

    for entry in TOOL_REGISTRY:
        fn = entry["fn"]
        if read_only and fn.__name__ in READ_ONLY_EXCLUDE:
            continue
        tag = entry["tag"]
        method = entry["http_method"].upper()
        path = entry["http_path"]

        def make_endpoint(tool_fn):
            sig = inspect.signature(tool_fn)

            async def endpoint(**kwargs):
                try:
                    return tool_fn(**kwargs)
                except ValueError as e:
                    raise HTTPException(status_code=422, detail=str(e))
                except RuntimeError as e:
                    raise HTTPException(status_code=502, detail=str(e))
                except _requests.exceptions.ConnectionError:
                    raise HTTPException(status_code=502, detail="Pritunl server unreachable")

            endpoint.__signature__ = sig
            endpoint.__name__ = tool_fn.__name__
            endpoint.__doc__ = tool_fn.__doc__
            return endpoint

        getattr(app, method.lower())(path, tags=[tag])(make_endpoint(fn))

    return app


def run_webui():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", action="version", version=__version__)
    parser.add_argument("--config", default=os.getenv("PRITUNL_CONFIG"), help="Path to config.json (env: PRITUNL_CONFIG)")
    parser.add_argument("--read-only", action="store_true",
                        default=os.getenv("PRITUNL_READ_ONLY", "").lower() in ("1", "true", "yes"),
                        help="Exclude destructive tools (env: PRITUNL_READ_ONLY)")
    parser.add_argument("--port", type=int, default=int(os.getenv("PRITUNL_PORT", "8000")), help="Port (env: PRITUNL_PORT)")
    parser.add_argument("--host", default=os.getenv("PRITUNL_HOST", "127.0.0.1"), help="Host (env: PRITUNL_HOST)")
    args = parser.parse_args()
    app = create_app(config_path=args.config, read_only=args.read_only)
    uvicorn.run(app, host=args.host, port=args.port)


if __name__ == "__main__":
    run_webui()
