"""BiblioCommons MCP Server for Pritunl Enterprise VPN."""

__version__ = "1.0.0"
