import base64
import hashlib
import hmac
import json
import os
import sys
import pytest
from unittest.mock import Mock, patch, MagicMock

from bibliocommons_mcp_pritunl.server import PritunlClient, load_config
from bibliocommons_mcp_pritunl import server

# Valid 24-char hex IDs for testing
ORG_ID = "aabbccddee112233aabb0001"
USER_ID = "aabbccddee112233aabb0002"
SERVER_ID = "aabbccddee112233aabb0003"
HOST_ID = "aabbccddee112233aabb0004"


# ============================================================
# PritunlClient.__init__ / SSL
# ============================================================

class TestPritunlClientInit:
    def test_host_trailing_slash_stripped(self):
        with patch("requests.Session"):
            c = PritunlClient("host.com/", "t", "s")
            assert c.base_url == "https://host.com"

    def test_verify_ssl_true(self):
        with patch("requests.Session"):
            c = PritunlClient("h", "t", "s", verify_ssl=True)
            assert c.session.verify is True

    def test_verify_ssl_false(self):
        with patch("requests.Session"):
            c = PritunlClient("h", "t", "s", verify_ssl=False)
            assert c.session.verify is False

    def test_ca_cert_path_existing(self, tmp_path):
        ca = tmp_path / "ca.crt"
        ca.write_text("cert")
        with patch("requests.Session"):
            c = PritunlClient("h", "t", "s", ca_cert_path=str(ca))
            assert c.session.verify == str(ca)

    def test_ca_cert_path_nonexistent(self):
        with patch("requests.Session"):
            c = PritunlClient("h", "t", "s", verify_ssl=True, ca_cert_path="/nonexistent")
            assert c.session.verify is True


# ============================================================
# PritunlClient HMAC signature
# ============================================================

class TestPritunlClientHMAC:
    def test_signature_generation(self, mock_client):
        with patch("time.time", return_value=1700000000), \
             patch("uuid.uuid4") as mock_uuid:
            mock_uuid.return_value = Mock(hex="aabbccdd11223344")
            mock_client.session.request.return_value = Mock(
                ok=True, content=b'{}', json=Mock(return_value={})
            )
            mock_client._auth_request("GET", "/test")

            call_args = mock_client.session.request.call_args
            headers = call_args[1]["headers"]

            assert headers["Auth-Token"] == "test-token"
            assert headers["Auth-Timestamp"] == "1700000000"
            assert headers["Auth-Nonce"] == "aabbccdd11223344"

            auth_string = "test-token&1700000000&aabbccdd11223344&GET&/test"
            expected_sig = base64.b64encode(
                hmac.new(b"test-secret", auth_string.encode(), hashlib.sha256).digest()
            ).decode()
            assert headers["Auth-Signature"] == expected_sig


# ============================================================
# PritunlClient._auth_request
# ============================================================

class TestPritunlClientAuthRequest:
    def test_request_success_with_body(self, mock_client):
        mock_client.session.request.return_value = Mock(
            ok=True, content=b'{"key":"val"}', json=Mock(return_value={"key": "val"})
        )
        result = mock_client._auth_request("GET", "/test")
        assert result == {"key": "val"}

    def test_request_empty_response(self, mock_client):
        mock_client.session.request.return_value = Mock(ok=True, content=b"")
        result = mock_client._auth_request("DELETE", "/item")
        assert result == {}

    def test_request_sends_json_data(self, mock_client):
        mock_client.session.request.return_value = Mock(
            ok=True, content=b'{}', json=Mock(return_value={})
        )
        mock_client._auth_request("POST", "/test", data={"name": "x"})
        call_kwargs = mock_client.session.request.call_args[1]
        assert call_kwargs["json"] == {"name": "x"}

    def test_request_no_json_for_get(self, mock_client):
        mock_client.session.request.return_value = Mock(
            ok=True, content=b'{}', json=Mock(return_value={})
        )
        mock_client._auth_request("GET", "/test")
        call_kwargs = mock_client.session.request.call_args[1]
        assert "json" not in call_kwargs

    def test_http_error_raises(self, mock_client):
        resp = Mock(ok=False, status_code=404, reason="Not Found", text="not found")
        mock_client.session.request.return_value = resp
        with pytest.raises(Exception, match="404"):
            mock_client._auth_request("GET", "/bad")

    def test_http_500_raises(self, mock_client):
        resp = Mock(ok=False, status_code=500, reason="Internal Server Error", text="boom")
        mock_client.session.request.return_value = resp
        with pytest.raises(Exception, match="500"):
            mock_client._auth_request("GET", "/fail")


# ============================================================
# PritunlClient convenience methods
# ============================================================

class TestPritunlClientMethods:
    def test_get(self, mock_client):
        mock_client._auth_request = Mock(return_value={"data": 1})
        assert mock_client.get("/ep") == {"data": 1}
        mock_client._auth_request.assert_called_once_with("GET", "/ep")

    def test_post(self, mock_client):
        mock_client._auth_request = Mock(return_value={"id": 1})
        assert mock_client.post("/ep", {"k": "v"}) == {"id": 1}
        mock_client._auth_request.assert_called_once_with("POST", "/ep", {"k": "v"})

    def test_put(self, mock_client):
        mock_client._auth_request = Mock(return_value={"ok": True})
        assert mock_client.put("/ep", {"k": "v"}) == {"ok": True}
        mock_client._auth_request.assert_called_once_with("PUT", "/ep", {"k": "v"})

    def test_delete(self, mock_client):
        mock_client._auth_request = Mock(return_value={})
        assert mock_client.delete("/ep") == {}
        mock_client._auth_request.assert_called_once_with("DELETE", "/ep")


# ============================================================
# load_config
# ============================================================

class TestLoadConfig:
    def test_load_from_file(self, tmp_config_dir, mock_config):
        with patch("bibliocommons_mcp_pritunl.server.os.path.dirname", return_value=str(tmp_config_dir)):
            result = load_config()
        assert result["host"] == "https://pritunl.example.com"
        assert result["api_token"] == "test-token"

    def test_load_from_env(self, monkeypatch, tmp_path):
        monkeypatch.setenv("PRITUNL_HOST", "https://env.example.com")
        monkeypatch.setenv("PRITUNL_API_TOKEN", "envtoken")
        monkeypatch.setenv("PRITUNL_API_SECRET", "envsecret")
        monkeypatch.setenv("PRITUNL_VERIFY_SSL", "false")
        with patch("bibliocommons_mcp_pritunl.server.os.path.dirname", return_value=str(tmp_path)):
            result = load_config()
        assert result["host"] == "https://env.example.com"
        assert result["verify_ssl"] is False

    def test_missing_required_fields(self, tmp_path, monkeypatch):
        monkeypatch.delenv("PRITUNL_HOST", raising=False)
        monkeypatch.delenv("PRITUNL_API_TOKEN", raising=False)
        monkeypatch.delenv("PRITUNL_API_SECRET", raising=False)
        with patch("bibliocommons_mcp_pritunl.server.os.path.dirname", return_value=str(tmp_path)):
            with pytest.raises(ValueError, match="Missing required configuration"):
                load_config()

    def test_invalid_json(self, tmp_path):
        (tmp_path / "config.json").write_text("{bad json")
        with patch("bibliocommons_mcp_pritunl.server.os.path.dirname", return_value=str(tmp_path)):
            with pytest.raises(ValueError, match="Failed to load config"):
                load_config()

    def test_file_permission_warning(self, tmp_path, mock_config):
        cfg = tmp_path / "config.json"
        cfg.write_text(json.dumps(mock_config))
        cfg.chmod(0o644)
        with patch("bibliocommons_mcp_pritunl.server.os.path.dirname", return_value=str(tmp_path)):
            result = load_config()
        assert result["host"] == "https://pritunl.example.com"

    def test_explicit_config_path(self, tmp_path, mock_config):
        cfg = tmp_path / "custom.json"
        cfg.write_text(json.dumps(mock_config))
        result = load_config(str(cfg))
        assert result["api_token"] == "test-token"

    def test_check_file_permissions_oserror(self, tmp_path, mock_config):
        """Cover the OSError branch in check_file_permissions."""
        from bibliocommons_mcp_pritunl._shared import check_file_permissions
        with patch("bibliocommons_mcp_pritunl._shared.os.stat", side_effect=OSError("nope")):
            # Should not raise - the OSError is silently caught
            check_file_permissions(str(tmp_path / "config.json"))


# ============================================================
# Tool functions
# ============================================================

class TestToolFunctions:
    @pytest.fixture(autouse=True)
    def _patch_client(self, mock_client):
        with patch.object(server, "client", mock_client):
            mock_client.get = Mock(return_value={"ok": True})
            mock_client.post = Mock(return_value={"id": "new"})
            mock_client.put = Mock(return_value={"updated": True})
            mock_client.delete = Mock(return_value={})
            yield

    # --- Status ---

    def test_get_status(self, mock_client):
        server.get_status()
        mock_client.get.assert_called_once_with("/status")

    def test_get_events(self, mock_client):
        server.get_events()
        mock_client.get.assert_called_once_with("/event")

    # --- Organizations ---

    def test_list_organizations(self, mock_client):
        server.list_organizations()
        mock_client.get.assert_called_once_with("/organization")

    def test_get_organization(self, mock_client):
        server.get_organization(ORG_ID)
        mock_client.get.assert_called_once_with(f"/organization/{ORG_ID}")

    def test_create_organization(self, mock_client):
        server.create_organization("MyOrg")
        mock_client.post.assert_called_once_with("/organization", {"name": "MyOrg"})

    def test_update_organization(self, mock_client):
        server.update_organization(ORG_ID, "NewName")
        mock_client.put.assert_called_once_with(f"/organization/{ORG_ID}", {"name": "NewName"})

    def test_delete_organization(self, mock_client):
        server.delete_organization(ORG_ID)
        mock_client.delete.assert_called_once_with(f"/organization/{ORG_ID}")

    # --- Users ---

    def test_list_users(self, mock_client):
        server.list_users(ORG_ID)
        mock_client.get.assert_called_once_with(f"/user/{ORG_ID}")

    def test_get_user(self, mock_client):
        server.get_user(ORG_ID, USER_ID)
        mock_client.get.assert_called_once_with(f"/user/{ORG_ID}/{USER_ID}")

    def test_create_user_minimal(self, mock_client):
        server.create_user(ORG_ID, "alice")
        mock_client.post.assert_called_once_with(f"/user/{ORG_ID}", {"name": "alice", "disabled": False})

    def test_create_user_full(self, mock_client):
        server.create_user(ORG_ID, "alice", email="a@b.com", disabled=True)
        mock_client.post.assert_called_once_with(
            f"/user/{ORG_ID}", {"name": "alice", "email": "a@b.com", "disabled": True}
        )

    def test_update_user_name_only(self, mock_client):
        server.update_user(ORG_ID, USER_ID, name="bob")
        mock_client.put.assert_called_once_with(f"/user/{ORG_ID}/{USER_ID}", {"name": "bob"})

    def test_update_user_all_fields(self, mock_client):
        server.update_user(ORG_ID, USER_ID, name="bob", email="b@c.com", disabled=True)
        mock_client.put.assert_called_once_with(
            f"/user/{ORG_ID}/{USER_ID}", {"name": "bob", "email": "b@c.com", "disabled": True}
        )

    def test_update_user_no_fields(self, mock_client):
        server.update_user(ORG_ID, USER_ID)
        mock_client.put.assert_called_once_with(f"/user/{ORG_ID}/{USER_ID}", {})

    def test_delete_user(self, mock_client):
        server.delete_user(ORG_ID, USER_ID)
        mock_client.delete.assert_called_once_with(f"/user/{ORG_ID}/{USER_ID}")

    def test_get_user_audit(self, mock_client):
        server.get_user_audit(ORG_ID, USER_ID)
        mock_client.get.assert_called_once_with(f"/user/{ORG_ID}/{USER_ID}/audit")

    def test_get_user_key_download_url(self, mock_client):
        server.get_user_key_download_url(ORG_ID, USER_ID)
        mock_client.get.assert_called_once_with(f"/key/{ORG_ID}/{USER_ID}")

    # --- Servers ---

    def test_list_servers(self, mock_client):
        server.list_servers()
        mock_client.get.assert_called_once_with("/server")

    def test_get_server(self, mock_client):
        server.get_server(SERVER_ID)
        mock_client.get.assert_called_once_with(f"/server/{SERVER_ID}")

    def test_create_server(self, mock_client):
        server.create_server("vpn1", "10.0.0.0/24", 1194)
        mock_client.post.assert_called_once_with(
            "/server", {"name": "vpn1", "network": "10.0.0.0/24", "port": 1194, "protocol": "udp",
                        "inter_client": True, "dns_mapping": False, "otp_auth": False,
                        "lzo_compression": False, "debug": False}
        )

    def test_create_server_with_options(self, mock_client):
        server.create_server("vpn1", "10.0.0.0/24", 1194, protocol="tcp", dns_address="8.8.8.8")
        call_data = mock_client.post.call_args[0][1]
        assert call_data["protocol"] == "tcp"
        assert call_data["dns_address"] == "8.8.8.8"

    def test_update_server_get_then_put(self, mock_client):
        mock_client.get.return_value = {"name": "old", "port": 1194}
        mock_client.put.return_value = {"name": "new", "port": 1194}
        result = server.update_server(SERVER_ID, name="new")
        mock_client.get.assert_called_once_with(f"/server/{SERVER_ID}")
        mock_client.put.assert_called_once_with(f"/server/{SERVER_ID}", {"name": "new", "port": 1194})
        assert result["name"] == "new"

    def test_delete_server(self, mock_client):
        server.delete_server(SERVER_ID)
        mock_client.delete.assert_called_once_with(f"/server/{SERVER_ID}")

    def test_start_server(self, mock_client):
        server.start_server(SERVER_ID)
        mock_client.put.assert_called_once_with(f"/server/{SERVER_ID}/operation/start")

    def test_stop_server(self, mock_client):
        server.stop_server(SERVER_ID)
        mock_client.put.assert_called_once_with(f"/server/{SERVER_ID}/operation/stop")

    def test_restart_server(self, mock_client):
        server.restart_server(SERVER_ID)
        mock_client.put.assert_called_once_with(f"/server/{SERVER_ID}/operation/restart")

    def test_get_server_output(self, mock_client):
        server.get_server_output(SERVER_ID)
        mock_client.get.assert_called_once_with(f"/server/{SERVER_ID}/output")

    def test_get_server_bandwidth(self, mock_client):
        server.get_server_bandwidth(SERVER_ID, period="5m")
        mock_client.get.assert_called_once_with(f"/server/{SERVER_ID}/bandwidth/5m")

    def test_get_server_bandwidth_default(self, mock_client):
        server.get_server_bandwidth(SERVER_ID)
        mock_client.get.assert_called_once_with(f"/server/{SERVER_ID}/bandwidth/1m")

    # --- Server Routes ---

    def test_list_server_routes(self, mock_client):
        server.list_server_routes(SERVER_ID)
        mock_client.get.assert_called_once_with(f"/server/{SERVER_ID}/route")

    def test_add_server_route_minimal(self, mock_client):
        server.add_server_route(SERVER_ID, "10.0.0.0/24")
        mock_client.post.assert_called_once_with(
            f"/server/{SERVER_ID}/route", {"network": "10.0.0.0/24", "nat": True}
        )

    def test_add_server_route_full(self, mock_client):
        server.add_server_route(SERVER_ID, "10.0.0.0/24", nat=False, comment="test")
        mock_client.post.assert_called_once_with(
            f"/server/{SERVER_ID}/route", {"network": "10.0.0.0/24", "nat": False, "comment": "test"}
        )

    def test_update_server_route(self, mock_client):
        server.update_server_route(SERVER_ID, "10.0.0.0/24", nat=False, comment="updated")
        mock_client.put.assert_called_once_with(
            f"/server/{SERVER_ID}/route/10.0.0.0/24", {"nat": False, "comment": "updated"}
        )

    def test_update_server_route_no_fields(self, mock_client):
        server.update_server_route(SERVER_ID, "10.0.0.0/24")
        mock_client.put.assert_called_once_with(f"/server/{SERVER_ID}/route/10.0.0.0/24", {})

    def test_delete_server_route(self, mock_client):
        server.delete_server_route(SERVER_ID, "10.0.0.0/24")
        mock_client.delete.assert_called_once_with(f"/server/{SERVER_ID}/route/10.0.0.0/24")

    # --- Server Organizations ---

    def test_attach_organization(self, mock_client):
        server.attach_organization(SERVER_ID, ORG_ID)
        mock_client.put.assert_called_once_with(f"/server/{SERVER_ID}/organization/{ORG_ID}")

    def test_detach_organization(self, mock_client):
        server.detach_organization(SERVER_ID, ORG_ID)
        mock_client.delete.assert_called_once_with(f"/server/{SERVER_ID}/organization/{ORG_ID}")

    # --- Hosts ---

    def test_list_hosts(self, mock_client):
        server.list_hosts()
        mock_client.get.assert_called_once_with("/host")

    def test_get_host(self, mock_client):
        server.get_host(HOST_ID)
        mock_client.get.assert_called_once_with(f"/host/{HOST_ID}")

    def test_list_server_hosts(self, mock_client):
        server.list_server_hosts(SERVER_ID)
        mock_client.get.assert_called_once_with(f"/server/{SERVER_ID}/host")

    # --- Settings ---

    def test_get_settings(self, mock_client):
        server.get_settings()
        mock_client.get.assert_called_once_with("/settings")

    def test_update_settings_get_then_put(self, mock_client):
        mock_client.get.return_value = {"theme": "dark", "sso": False}
        mock_client.put.return_value = {"theme": "light", "sso": False}
        result = server.update_settings(theme="light")
        mock_client.get.assert_called_once_with("/settings")
        mock_client.put.assert_called_once_with("/settings", {"theme": "light", "sso": False})
        assert result["theme"] == "light"


# ============================================================
# Read-Only Mode
# ============================================================

class TestReadOnly:
    def test_registry_count(self):
        assert len(server.TOOL_REGISTRY) == 35

    def test_read_only_exclude_count(self):
        assert len(server.READ_ONLY_EXCLUDE) == 18

    def test_excluded_tools_exist_in_registry(self):
        names = {e["fn"].__name__ for e in server.TOOL_REGISTRY}
        for excluded in server.READ_ONLY_EXCLUDE:
            assert excluded in names

    def test_read_only_skips_destructive(self):
        registered = []
        original_tool = server.mcp.tool

        def mock_tool(name=None, description=None, tags=None):
            registered.append(name)
            return lambda fn: fn

        server.mcp.tool = mock_tool
        try:
            server.register_mcp_tools(read_only=True, expanded=True)
            for excluded in server.READ_ONLY_EXCLUDE:
                assert excluded not in registered
            assert len(registered) == 17
        finally:
            server.mcp.tool = original_tool

    def test_read_only_false_includes_all(self):
        registered = []
        original_tool = server.mcp.tool

        def mock_tool(name=None, description=None, tags=None):
            registered.append(name)
            return lambda fn: fn

        server.mcp.tool = mock_tool
        try:
            server.register_mcp_tools(read_only=False, expanded=True)
            assert len(registered) == 35
        finally:
            server.mcp.tool = original_tool


# ============================================================
# _client() lazy init
# ============================================================

class TestClientLazyInit:
    def test_client_lazy_init_when_none(self, mock_config):
        original = server.client
        try:
            server.client = None
            with patch("bibliocommons_mcp_pritunl.server.init_client") as mock_init:
                def set_client(cfg=None):
                    server.client = Mock()
                mock_init.side_effect = set_client
                result = server._client()
                mock_init.assert_called_once()
                assert result is not None
        finally:
            server.client = original

    def test_client_returns_existing(self, mock_client):
        original = server.client
        try:
            server.client = mock_client
            assert server._client() is mock_client
        finally:
            server.client = original


# ============================================================
# MCP Integration - stdio mode
# ============================================================

class TestMCPStdioMode:
    @pytest.mark.asyncio
    async def test_tool_listing(self):
        from fastmcp import FastMCP, Client
        mcp_instance = FastMCP("test-pritunl")

        @mcp_instance.tool(tags={"Status"})
        def get_status() -> dict:
            return {"status": "ok"}

        async with Client(mcp_instance) as client:
            tools = await client.list_tools()
            assert any(t.name == "get_status" for t in tools)


# ============================================================
# MCP Integration - HTTP mode
# ============================================================

class TestMCPHTTPMode:
    @pytest.mark.asyncio
    async def test_http_transport(self):
        from fastmcp import FastMCP, Client
        mcp_instance = FastMCP("test-pritunl")

        @mcp_instance.tool()
        def test_ping() -> str:
            return "pong"

        async with Client(mcp_instance) as client:
            tools = await client.list_tools()
            assert any(t.name == "test_ping" for t in tools)
            result = await client.call_tool("test_ping", {})
            assert result is not None


# ============================================================
# __main__ block
# ============================================================

class TestServerMain:
    def test_server_main_help(self):
        import subprocess
        result = subprocess.run(
            [sys.executable, "-m", "bibliocommons_mcp_pritunl", "--help"],
            capture_output=True, text=True,
            cwd=os.path.join(os.path.dirname(__file__), ".."),
        )
        assert result.returncode == 0
        assert "--config" in result.stdout
        assert "--read-only" in result.stdout

    def test_server_main_version(self):
        import subprocess
        result = subprocess.run(
            [sys.executable, "-m", "bibliocommons_mcp_pritunl", "--version"],
            capture_output=True, text=True,
            cwd=os.path.join(os.path.dirname(__file__), ".."),
        )
        assert result.returncode == 0
        assert "1.0.0" in result.stdout

    def test_server_main_runs(self):
        with patch("bibliocommons_mcp_pritunl.__main__.init_client") as mock_init, \
             patch("bibliocommons_mcp_pritunl.__main__.register_mcp_tools") as mock_reg, \
             patch("bibliocommons_mcp_pritunl.__main__.mcp") as mock_mcp, \
             patch("sys.argv", ["bibliocommons_mcp_pritunl"]):
            from bibliocommons_mcp_pritunl.__main__ import main
            main()
            mock_init.assert_called_once_with(None)
            mock_reg.assert_called_once_with(read_only=False, expanded=False)
            mock_mcp.run.assert_called_once()

    def test_server_main_read_only(self):
        with patch("bibliocommons_mcp_pritunl.__main__.init_client"), \
             patch("bibliocommons_mcp_pritunl.__main__.register_mcp_tools") as mock_reg, \
             patch("bibliocommons_mcp_pritunl.__main__.mcp"), \
             patch("sys.argv", ["prog", "--read-only"]):
            from bibliocommons_mcp_pritunl.__main__ import main
            main()
            mock_reg.assert_called_once_with(read_only=True, expanded=False)

    def test_server_main_with_config(self):
        with patch("bibliocommons_mcp_pritunl.__main__.init_client") as mock_init, \
             patch("bibliocommons_mcp_pritunl.__main__.register_mcp_tools"), \
             patch("bibliocommons_mcp_pritunl.__main__.mcp"), \
             patch("sys.argv", ["prog", "--config", "/tmp/test.json"]):
            from bibliocommons_mcp_pritunl.__main__ import main
            main()
            mock_init.assert_called_once_with("/tmp/test.json")
