import json
import os
import sys
import pytest
from unittest.mock import Mock, patch

import httpx
import requests as _requests
import bibliocommons_mcp_pritunl.webui as _webui_module

# Valid 24-char hex IDs for testing
ORG_ID = "aabbccddee112233aabb0001"
USER_ID = "aabbccddee112233aabb0002"
SERVER_ID = "aabbccddee112233aabb0003"
HOST_ID = "aabbccddee112233aabb0004"


def _make_app(mock_config, read_only=False):
    mock_client_instance = Mock()
    mock_client_instance.get = Mock(return_value={"ok": True})
    mock_client_instance.post = Mock(return_value={"id": "new"})
    mock_client_instance.put = Mock(return_value={"updated": True})
    mock_client_instance.delete = Mock(return_value={})

    with patch("bibliocommons_mcp_pritunl.server.load_config", return_value=mock_config), \
         patch("bibliocommons_mcp_pritunl.server.PritunlClient", return_value=mock_client_instance):
        app = _webui_module.create_app(read_only=read_only)

    return app, mock_client_instance


def _make_client(app):
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test")


@pytest.mark.asyncio
class TestWebUIHealth:
    async def test_health_endpoint(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get("/health")
            assert resp.status_code == 200
            assert resp.json() == {"status": "ok"}


@pytest.mark.asyncio
class TestWebUIRoot:
    async def test_root_redirects_to_docs(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get("/", follow_redirects=False)
            assert resp.status_code == 307
            assert resp.headers["location"] == "/docs"


@pytest.mark.asyncio
class TestWebUIToolList:
    async def test_openapi_includes_all_paths(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get("/openapi.json")
            assert resp.status_code == 200
            paths = resp.json()["paths"]
            expected = [
                "/status", "/events",
                "/organizations", "/organizations/{org_id}",
                "/users/{org_id}", "/users/{org_id}/{user_id}",
                "/servers", "/servers/{server_id}",
                "/hosts", "/hosts/{host_id}",
                "/settings",
            ]
            for path in expected:
                assert path in paths, f"Missing path: {path}"


@pytest.mark.asyncio
class TestWebUIReadTools:
    async def test_get_status(self, mock_config):
        app, mc = _make_app(mock_config)
        mc.get.return_value = {"server_count": 2}
        async with _make_client(app) as client:
            resp = await client.get("/status")
            assert resp.status_code == 200
            mc.get.assert_called_with("/status")

    async def test_list_organizations(self, mock_config):
        app, mc = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get("/organizations")
            assert resp.status_code == 200

    async def test_get_organization(self, mock_config):
        app, mc = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get(f"/organizations/{ORG_ID}")
            assert resp.status_code == 200

    async def test_list_users(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get(f"/users/{ORG_ID}")
            assert resp.status_code == 200

    async def test_get_user(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get(f"/users/{ORG_ID}/{USER_ID}")
            assert resp.status_code == 200

    async def test_get_user_audit(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get(f"/users/{ORG_ID}/{USER_ID}/audit")
            assert resp.status_code == 200

    async def test_get_user_key_download_url(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get(f"/users/{ORG_ID}/{USER_ID}/keys")
            assert resp.status_code == 200

    async def test_list_servers(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get("/servers")
            assert resp.status_code == 200

    async def test_get_server(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get(f"/servers/{SERVER_ID}")
            assert resp.status_code == 200

    async def test_get_server_output(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get(f"/servers/{SERVER_ID}/output")
            assert resp.status_code == 200

    async def test_get_server_bandwidth(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get(f"/servers/{SERVER_ID}/bandwidth/1m")
            assert resp.status_code == 200

    async def test_list_server_routes(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get(f"/servers/{SERVER_ID}/routes")
            assert resp.status_code == 200

    async def test_list_hosts(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get("/hosts")
            assert resp.status_code == 200

    async def test_get_host(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get(f"/hosts/{HOST_ID}")
            assert resp.status_code == 200

    async def test_list_server_hosts(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get(f"/servers/{SERVER_ID}/hosts")
            assert resp.status_code == 200

    async def test_get_settings(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get("/settings")
            assert resp.status_code == 200

    async def test_get_events(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.get("/events")
            assert resp.status_code == 200


@pytest.mark.asyncio
class TestWebUIWriteTools:
    async def test_create_organization(self, mock_config):
        app, mc = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.post("/organizations", params={"name": "NewOrg"})
            assert resp.status_code == 200

    async def test_update_organization(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.put(f"/organizations/{ORG_ID}", params={"name": "Updated"})
            assert resp.status_code == 200

    async def test_delete_organization(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.delete(f"/organizations/{ORG_ID}")
            assert resp.status_code == 200

    async def test_create_user(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.post(f"/users/{ORG_ID}", params={"name": "alice"})
            assert resp.status_code == 200

    async def test_delete_user(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.delete(f"/users/{ORG_ID}/{USER_ID}")
            assert resp.status_code == 200

    async def test_create_server(self, mock_config):
        app, mc = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.post("/servers", params={"name": "vpn1", "network": "10.0.0.0/24", "port": "1194"})
            assert resp.status_code == 200

    async def test_delete_server(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.delete(f"/servers/{SERVER_ID}")
            assert resp.status_code == 200

    async def test_start_server(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.put(f"/servers/{SERVER_ID}/start")
            assert resp.status_code == 200

    async def test_stop_server(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.put(f"/servers/{SERVER_ID}/stop")
            assert resp.status_code == 200

    async def test_restart_server(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.put(f"/servers/{SERVER_ID}/restart")
            assert resp.status_code == 200

    async def test_add_server_route(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.post(f"/servers/{SERVER_ID}/routes", params={"network": "10.0.0.0/24"})
            assert resp.status_code == 200

    async def test_delete_server_route(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.delete(f"/servers/{SERVER_ID}/routes/10.0.0.0")
            assert resp.status_code == 200

    async def test_attach_organization(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.put(f"/servers/{SERVER_ID}/organizations/{ORG_ID}")
            assert resp.status_code == 200

    async def test_detach_organization(self, mock_config):
        app, _ = _make_app(mock_config)
        async with _make_client(app) as client:
            resp = await client.delete(f"/servers/{SERVER_ID}/organizations/{ORG_ID}")
            assert resp.status_code == 200


@pytest.mark.asyncio
class TestWebUIErrorHandling:
    async def test_connection_error_returns_502(self, mock_config):
        app, mc = _make_app(mock_config)
        mc.get.side_effect = _requests.exceptions.ConnectionError("refused")
        async with _make_client(app) as client:
            resp = await client.get("/status")
            assert resp.status_code == 502
            assert "unreachable" in resp.json()["detail"]

    async def test_runtime_error_returns_502(self, mock_config):
        app, mc = _make_app(mock_config)
        mc.get.side_effect = RuntimeError("Pritunl API error: 403 Forbidden")
        async with _make_client(app) as client:
            resp = await client.get("/status")
            assert resp.status_code == 502
            assert "403 Forbidden" in resp.json()["detail"]

    async def test_value_error_returns_422(self, mock_config):
        app, mc = _make_app(mock_config)
        mc.get.side_effect = ValueError("Invalid org_id")
        async with _make_client(app) as client:
            resp = await client.get("/status")
            assert resp.status_code == 422
            assert "Invalid" in resp.json()["detail"]


@pytest.mark.asyncio
class TestWebUIReadOnly:
    async def test_read_only_excludes_write_endpoints(self, mock_config):
        app, _ = _make_app(mock_config, read_only=True)
        async with _make_client(app) as client:
            resp = await client.get("/openapi.json")
            paths = resp.json()["paths"]
            # create_organization is POST /organizations - should be excluded
            orgs = paths.get("/organizations", {})
            assert "post" not in orgs
            # delete_server is DELETE /servers/{server_id} - should be excluded
            srvs = paths.get("/servers/{server_id}", {})
            assert "delete" not in srvs
            # read endpoints should still exist
            assert "get" in paths.get("/status", {})
            assert "get" in paths.get("/organizations", {})

    async def test_read_only_read_endpoints_work(self, mock_config):
        app, _ = _make_app(mock_config, read_only=True)
        async with _make_client(app) as client:
            resp = await client.get("/status")
            assert resp.status_code == 200


@pytest.mark.asyncio
class TestWebUIStaticDir:
    async def test_static_dir_mounted_when_exists(self, mock_config):
        with patch("bibliocommons_mcp_pritunl.server.load_config", return_value=mock_config), \
             patch("bibliocommons_mcp_pritunl.server.PritunlClient", return_value=Mock()):
            app = _webui_module.create_app()
        route_paths = [r.path for r in app.routes if hasattr(r, "path")]
        # static dir may or may not exist; just verify no crash
        assert "/health" in route_paths


class TestWebUIMain:
    def test_webui_main_help(self):
        import subprocess
        result = subprocess.run(
            [sys.executable, "-c",
             "from bibliocommons_mcp_pritunl.webui import run_webui; run_webui()",
             "--help"],
            capture_output=True, text=True,
            cwd=os.path.join(os.path.dirname(__file__), ".."),
        )
        assert result.returncode == 0
        assert "--port" in result.stdout

    def test_webui_main_version(self):
        import subprocess
        result = subprocess.run(
            [sys.executable, "-c",
             "from bibliocommons_mcp_pritunl.webui import run_webui; run_webui()",
             "--version"],
            capture_output=True, text=True,
            cwd=os.path.join(os.path.dirname(__file__), ".."),
        )
        assert result.returncode == 0
        assert "1.0.0" in result.stdout

    def test_webui_main_runs(self, mock_config):
        with patch("bibliocommons_mcp_pritunl.server.load_config", return_value=mock_config), \
             patch("bibliocommons_mcp_pritunl.server.PritunlClient", return_value=Mock()), \
             patch("uvicorn.run") as mock_uvicorn, \
             patch("sys.argv", ["webui", "--port", "8000"]):
            _webui_module.run_webui()
            mock_uvicorn.assert_called_once()
            assert mock_uvicorn.call_args[1]["port"] == 8000

    def test_webui_main_custom_port(self, mock_config):
        with patch("bibliocommons_mcp_pritunl.server.load_config", return_value=mock_config), \
             patch("bibliocommons_mcp_pritunl.server.PritunlClient", return_value=Mock()), \
             patch("uvicorn.run") as mock_uvicorn, \
             patch("sys.argv", ["webui", "--port", "9000"]):
            _webui_module.run_webui()
            assert mock_uvicorn.call_args[1]["port"] == 9000
