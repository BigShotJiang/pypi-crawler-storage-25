"""Unit tests for dbt_cloud_run_runner.models."""

from dbt_cloud_run_runner.models import DBT_CLOUD_RUN_BUILTIN_ENV_KEYS, DbtCloudRunSetup


def _minimal_setup(**kwargs) -> DbtCloudRunSetup:
    defaults = dict(
        profiles_yml_blob="gs://b/p",
        dbt_project_blob="gs://b/d",
        credentials_blob="gs://b/c",
        output_blob="gs://b/o",
        logs_blob="gs://b/l",
        profiles_yml_url="http://p",
        dbt_project_url="http://d",
        credentials_url="http://c",
        output_url="http://o",
        logs_url="http://l",
        image="img:latest",
    )
    defaults.update(kwargs)
    return DbtCloudRunSetup(**defaults)


def test_builtin_env_keys_match_to_env_vars():
    """Keep DBT_CLOUD_RUN_BUILTIN_ENV_KEYS in sync with to_env_vars()."""
    # Without optional keys
    setup = _minimal_setup()
    expected_keys = DBT_CLOUD_RUN_BUILTIN_ENV_KEYS - {
        "DBT_DOCS_SELECTOR",
        "DBT_COMPILE_FLAGS",
        "DBT_DOCS_FLAGS",
        "EXTRA_ENV_VARS",
    }
    assert frozenset(setup.to_env_vars().keys()) == expected_keys

    # With docs_generate_selector, all builtin keys should be present
    setup_with_selector = _minimal_setup(
        docs_generate_selector="my_selector",
        dbt_compile_flags=["--full-refresh"],
        dbt_docs_flags=["--empty-catalog"],
        extra_env={"MY_VAR": "1"},
    )
    assert frozenset(setup_with_selector.to_env_vars().keys()) == DBT_CLOUD_RUN_BUILTIN_ENV_KEYS


def test_env_vars_for_cloud_run_merges_extra_env():
    setup = _minimal_setup(extra_env={"MY_FLAG": "1", "DBT_VAR": "x"})
    merged = setup.env_vars_for_cloud_run()
    assert merged["MY_FLAG"] == "1"
    assert merged["DBT_VAR"] == "x"
    assert merged["LOGS_URL"] == "http://l"


def test_env_vars_for_cloud_run_builtin_wins_on_overlap():
    """If extra_env ever contained a builtin key, built-ins would win (prepare rejects overlap)."""
    setup = _minimal_setup(
        extra_env={"CUSTOM": "a"},
    )
    # Simulated overlap: merge order puts to_env_vars last
    setup.extra_env = {"CUSTOM": "a", "LOGS_URL": "user-would-lose"}
    merged = setup.env_vars_for_cloud_run()
    assert merged["LOGS_URL"] == "http://l"


def test_docs_generate_selector_not_included_when_none():
    """DBT_DOCS_SELECTOR should not be in env vars when not provided."""
    setup = _minimal_setup()
    env_vars = setup.to_env_vars()
    assert "DBT_DOCS_SELECTOR" not in env_vars


def test_docs_generate_selector_included_when_provided():
    """DBT_DOCS_SELECTOR should be in env vars when provided."""
    setup = _minimal_setup(docs_generate_selector="my_custom_selector")
    env_vars = setup.to_env_vars()
    assert "DBT_DOCS_SELECTOR" in env_vars
    assert env_vars["DBT_DOCS_SELECTOR"] == "my_custom_selector"


def test_docs_generate_selector_in_cloud_run_env():
    """DBT_DOCS_SELECTOR should be in env_vars_for_cloud_run when provided."""
    setup = _minimal_setup(
        extra_env={"MY_VAR": "value"},
        docs_generate_selector="production_selector",
    )
    merged = setup.env_vars_for_cloud_run()
    assert merged["DBT_DOCS_SELECTOR"] == "production_selector"
    assert merged["MY_VAR"] == "value"


def test_dbt_compile_flags_not_included_when_none():
    """DBT_COMPILE_FLAGS should not be in env vars when not provided."""
    setup = _minimal_setup()
    env_vars = setup.to_env_vars()
    assert "DBT_COMPILE_FLAGS" not in env_vars


def test_dbt_compile_flags_included_when_provided():
    """DBT_COMPILE_FLAGS should serialize list values with newlines."""
    setup = _minimal_setup(dbt_compile_flags=["--full-refresh", "--fail-fast"])
    env_vars = setup.to_env_vars()
    assert env_vars["DBT_COMPILE_FLAGS"] == "--full-refresh\n--fail-fast"


def test_dbt_docs_flags_not_included_when_none():
    """DBT_DOCS_FLAGS should not be in env vars when not provided."""
    setup = _minimal_setup()
    env_vars = setup.to_env_vars()
    assert "DBT_DOCS_FLAGS" not in env_vars


def test_dbt_docs_flags_included_when_provided():
    """DBT_DOCS_FLAGS should serialize list values with newlines."""
    setup = _minimal_setup(dbt_docs_flags=["--empty-catalog", "--no-compile"])
    env_vars = setup.to_env_vars()
    assert env_vars["DBT_DOCS_FLAGS"] == "--empty-catalog\n--no-compile"


def test_extra_env_vars_not_included_when_no_extra_env():
    """EXTRA_ENV_VARS should not be in env vars when no extra_env is provided."""
    setup = _minimal_setup()
    env_vars = setup.to_env_vars()
    assert "EXTRA_ENV_VARS" not in env_vars


def test_extra_env_vars_included_when_extra_env_is_provided():
    """EXTRA_ENV_VARS should list comma-separated extra_env variable names."""
    setup = _minimal_setup(
        extra_env={
            "CORE_GITHUB_PATH": "github_pat_xxx",
            "ANOTHER_SECRET": "secret-value",
        }
    )
    env_vars = setup.to_env_vars()
    assert env_vars["EXTRA_ENV_VARS"] == "CORE_GITHUB_PATH,ANOTHER_SECRET"
