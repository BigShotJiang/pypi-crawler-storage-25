"""Tests for prepare_bigquery extra_env validation."""

from unittest.mock import patch

import pytest

from dbt_cloud_run_runner import Client

_MIN_SA = {
    "type": "service_account",
    "project_id": "p",
    "private_key_id": "k",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIE\n-----END PRIVATE KEY-----\n",
    "client_email": "x@p.iam.gserviceaccount.com",
    "client_id": "1",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
}


@patch("dbt_cloud_run_runner.client.service_account.Credentials.from_service_account_info")
def test_prepare_bigquery_rejects_conflicting_extra_env(_mock_creds):
    client = Client(
        gcp_project="p",
        gcs_bucket="b",
        service_account_key=_MIN_SA,
    )
    with pytest.raises(ValueError, match="CREDENTIALS_URL"):
        client.prepare_bigquery(
            service_account_key=_MIN_SA,
            target_project="p",
            target_dataset="d",
            path_to_local_dbt_project="/tmp/not-used",
            image="img",
            extra_env={"CREDENTIALS_URL": "https://evil"},
        )


@patch("dbt_cloud_run_runner.client.service_account.Credentials.from_service_account_info")
def test_prepare_bigquery_rejects_dbt_docs_selector_in_extra_env(_mock_creds):
    """DBT_DOCS_SELECTOR is a built-in key and should not be allowed in extra_env."""
    client = Client(
        gcp_project="p",
        gcs_bucket="b",
        service_account_key=_MIN_SA,
    )
    with pytest.raises(ValueError, match="DBT_DOCS_SELECTOR"):
        client.prepare_bigquery(
            service_account_key=_MIN_SA,
            target_project="p",
            target_dataset="d",
            path_to_local_dbt_project="/tmp/not-used",
            image="img",
            extra_env={"DBT_DOCS_SELECTOR": "should_use_argument_instead"},
        )


@patch("dbt_cloud_run_runner.client.service_account.Credentials.from_service_account_info")
def test_prepare_bigquery_rejects_extra_env_vars_key_in_extra_env(_mock_creds):
    """EXTRA_ENV_VARS is a built-in key and should not be allowed in extra_env."""
    client = Client(
        gcp_project="p",
        gcs_bucket="b",
        service_account_key=_MIN_SA,
    )
    with pytest.raises(ValueError, match="EXTRA_ENV_VARS"):
        client.prepare_bigquery(
            service_account_key=_MIN_SA,
            target_project="p",
            target_dataset="d",
            path_to_local_dbt_project="/tmp/not-used",
            image="img",
            extra_env={"EXTRA_ENV_VARS": "CORE_GITHUB_PATH"},
        )


@patch("dbt_cloud_run_runner.client.service_account.Credentials.from_service_account_info")
def test_prepare_bigquery_rejects_dbt_compile_flags_in_extra_env(_mock_creds):
    """DBT_COMPILE_FLAGS is a built-in key and should not be allowed in extra_env."""
    client = Client(
        gcp_project="p",
        gcs_bucket="b",
        service_account_key=_MIN_SA,
    )
    with pytest.raises(ValueError, match="DBT_COMPILE_FLAGS"):
        client.prepare_bigquery(
            service_account_key=_MIN_SA,
            target_project="p",
            target_dataset="d",
            path_to_local_dbt_project="/tmp/not-used",
            image="img",
            extra_env={"DBT_COMPILE_FLAGS": "--select model_a"},
        )


@patch("dbt_cloud_run_runner.client.service_account.Credentials.from_service_account_info")
def test_prepare_bigquery_rejects_dbt_docs_flags_in_extra_env(_mock_creds):
    """DBT_DOCS_FLAGS is a built-in key and should not be allowed in extra_env."""
    client = Client(
        gcp_project="p",
        gcs_bucket="b",
        service_account_key=_MIN_SA,
    )
    with pytest.raises(ValueError, match="DBT_DOCS_FLAGS"):
        client.prepare_bigquery(
            service_account_key=_MIN_SA,
            target_project="p",
            target_dataset="d",
            path_to_local_dbt_project="/tmp/not-used",
            image="img",
            extra_env={"DBT_DOCS_FLAGS": "--empty-catalog"},
        )
