"""Exponential backoff retry decorator for transient errors.

This module provides a decorator for retrying operations that may fail with
transient errors (rate limits, timeouts, network issues). It uses exponential
backoff with jitter to prevent thundering herd problems.

Usage:
    from obra.execution.retry import retry_with_backoff

    @retry_with_backoff(max_retries=3, base_delay=1.0)
    def call_external_api():
        # This will be retried on transient errors
        return api.get_data()

    # Async functions are also supported
    @retry_with_backoff(max_retries=5)
    async def async_api_call():
        return await api.async_get_data()

Metrics:
    - obra_retry_attempts_total: Counter of retry attempts with outcome label
    - obra_retry_exhaustion_total: Counter of retries that hit max attempts
    - obra_retry_success_rate: Gauge of successful retries / total retries

Related:
    - obra/execution/derivation_metrics.py (similar metrics pattern)
    - obra/review/metrics.py (quality gate metrics)
"""

from __future__ import annotations

import asyncio
import functools
import inspect
import logging
import random
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, ParamSpec, TypeVar

from obra.execution.errors import get_retry_after, is_transient
from obra.execution.metrics_base import BaseMetric, BaseMetricsCollector

if TYPE_CHECKING:
    from collections.abc import Callable, Generator

logger = logging.getLogger(__name__)

# Metric names following Prometheus naming convention
METRIC_RETRY_ATTEMPTS = "obra_retry_attempts_total"
METRIC_RETRY_EXHAUSTION = "obra_retry_exhaustion_total"
METRIC_RETRY_SUCCESS_RATE = "obra_retry_success_rate"


@dataclass
class RetryMetric(BaseMetric):
    """Structured metric event for retry operations."""


class RetryMetricsCollector(BaseMetricsCollector[RetryMetric]):
    """Collects and aggregates retry metrics.

    Thread-safety:
        This class is NOT thread-safe. Use external synchronization if
        accessing from multiple threads.
    """

    def __init__(self) -> None:
        """Initialize the metrics collector."""
        super().__init__()
        self._total_retries: int = 0
        self._successful_retries: int = 0
        self._exhausted_retries: int = 0

    def record_retry_attempt(
        self,
        operation: str,
        outcome: str,
        attempt_number: int,
        max_retries: int,
        error_type: str | None = None,
        log_event: Any | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
    ) -> RetryMetric:
        """Record a single retry attempt.

        Args:
            operation: Name/identifier of the operation being retried
            outcome: "success" or "failure"
            attempt_number: Current attempt number (1-indexed)
            max_retries: Maximum retry attempts configured
            error_type: Type of error that triggered the retry (if any)
            log_event: Optional event logger callback
            trace_id: Optional trace ID for correlation
            parent_span_id: Optional parent span ID for correlation

        Returns:
            The RetryMetric that was recorded
        """
        timestamp = datetime.now(UTC).isoformat()
        is_retry = attempt_number > 1

        # Only count as retry if this is not the first attempt
        if is_retry:
            self._total_retries += 1
            if outcome == "success":
                self._successful_retries += 1

        metric = RetryMetric(
            metric_name=METRIC_RETRY_ATTEMPTS,
            value=1.0,
            labels={
                "outcome": outcome,
                "operation": operation,
                "error_type": error_type or "none",
                "is_retry": str(is_retry).lower(),
            },
            timestamp=timestamp,
            metadata={
                "attempt_number": attempt_number,
                "max_retries": max_retries,
            },
        )
        self._metrics_buffer.append(metric)

        # Log metric event
        if log_event:
            try:
                log_event(
                    "retry_metric",
                    session_id=None,
                    trace_id=trace_id,
                    parent_span_id=parent_span_id,
                    **metric.to_dict(),
                )
            except Exception as e:
                logger.debug("Failed to log retry attempt metric: %s", e)

        return metric

    def record_retry_exhaustion(
        self,
        operation: str,
        max_retries: int,
        error_type: str | None = None,
        error_message: str | None = None,
        log_event: Any | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
    ) -> RetryMetric:
        """Record when retries are exhausted (max attempts reached).

        Args:
            operation: Name/identifier of the operation that exhausted retries
            max_retries: Maximum retry attempts that were configured
            error_type: Type of the final error
            error_message: Final error message
            log_event: Optional event logger callback
            trace_id: Optional trace ID for correlation
            parent_span_id: Optional parent span ID for correlation

        Returns:
            The RetryMetric that was recorded
        """
        timestamp = datetime.now(UTC).isoformat()
        self._exhausted_retries += 1

        metric = RetryMetric(
            metric_name=METRIC_RETRY_EXHAUSTION,
            value=1.0,
            labels={
                "operation": operation,
                "error_type": error_type or "unknown",
            },
            timestamp=timestamp,
            metadata={
                "max_retries": max_retries,
                "error_message": error_message or "",
            },
        )
        self._metrics_buffer.append(metric)

        # Log metric event
        if log_event:
            try:
                log_event(
                    "retry_metric",
                    session_id=None,
                    trace_id=trace_id,
                    parent_span_id=parent_span_id,
                    **metric.to_dict(),
                )
            except Exception as e:
                logger.debug("Failed to log retry exhaustion metric: %s", e)

        logger.warning(
            "Retry exhaustion for operation '%s': max retries (%d) reached. Error: %s - %s",
            operation,
            max_retries,
            error_type or "unknown",
            (
                (error_message[:100] + "...")
                if error_message and len(error_message) > 100
                else (error_message or "")
            ),
        )

        return metric

    def get_success_rate(self) -> float:
        """Calculate the retry success rate.

        Returns:
            Float between 0.0 and 1.0 representing successful retries / total retries.
            Returns 0.0 if no retries have been recorded.
        """
        if self._total_retries == 0:
            return 0.0
        return self._successful_retries / self._total_retries

    def emit_success_rate_metric(
        self,
        log_event: Any | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
    ) -> RetryMetric:
        """Emit the current retry success rate as a gauge metric.

        Args:
            log_event: Optional event logger callback
            trace_id: Optional trace ID for correlation
            parent_span_id: Optional parent span ID for correlation

        Returns:
            The RetryMetric representing the success rate
        """
        timestamp = datetime.now(UTC).isoformat()
        rate = self.get_success_rate()

        metric = RetryMetric(
            metric_name=METRIC_RETRY_SUCCESS_RATE,
            value=rate,
            labels={},
            timestamp=timestamp,
            metadata={
                "total_retries": self._total_retries,
                "successful_retries": self._successful_retries,
                "exhausted_retries": self._exhausted_retries,
            },
        )

        # Log metric event
        if log_event:
            try:
                log_event(
                    "retry_metric",
                    session_id=None,
                    trace_id=trace_id,
                    parent_span_id=parent_span_id,
                    **metric.to_dict(),
                )
            except Exception as e:
                logger.debug("Failed to log retry success rate metric: %s", e)

        return metric

    def get_summary(self) -> dict[str, Any]:
        """Get a summary of retry metrics.

        Returns:
            Dict with:
            - total_retries: Total number of retry attempts (excluding first attempts)
            - successful_retries: Number of successful retries
            - exhausted_retries: Number of times max retries was reached
            - success_rate: Ratio of successful retries to total retries
        """
        return {
            "total_retries": self._total_retries,
            "successful_retries": self._successful_retries,
            "exhausted_retries": self._exhausted_retries,
            "success_rate": self.get_success_rate(),
        }

    def clear(self) -> None:
        """Clear all metrics and reset counters."""
        super().clear()
        self._total_retries = 0
        self._successful_retries = 0
        self._exhausted_retries = 0


# Global singleton instance
_retry_metrics_collector: RetryMetricsCollector | None = None


def get_retry_metrics_collector() -> RetryMetricsCollector:
    """Get the global retry metrics collector singleton.

    Returns:
        The global RetryMetricsCollector instance
    """
    global _retry_metrics_collector
    if _retry_metrics_collector is None:
        _retry_metrics_collector = RetryMetricsCollector()
    return _retry_metrics_collector


P = ParamSpec("P")
T = TypeVar("T")


def retry_with_backoff(
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    exponential_base: float = 2.0,
    jitter: float = 0.25,
    operation_name: str | None = None,
    collect_metrics: bool = True,
) -> Callable[[Callable[P, T]], Callable[P, T]]:
    """Decorator that retries a function on transient errors with exponential backoff.

    The delay between retries follows: base_delay * (exponential_base ^ attempt)
    with random jitter applied to prevent thundering herd.

    Args:
        max_retries: Maximum number of retry attempts (default 3). The function
            will be called at most max_retries + 1 times total.
        base_delay: Initial delay in seconds between retries (default 1.0).
        max_delay: Maximum delay in seconds, caps the exponential growth (default 60.0).
        exponential_base: Base for exponential backoff calculation (default 2.0).
        jitter: Random jitter factor applied to delay (default 0.25, meaning +/-25%).
        operation_name: Optional name for this operation in metrics. If None, uses
            the decorated function's name.
        collect_metrics: Whether to collect retry metrics (default True). Set to False
            to disable metrics collection for this decorator.

    Returns:
        A decorator that wraps functions with retry logic.

    Raises:
        The original exception if:
        - The error is non-transient (fails fast without retry)
        - All retry attempts are exhausted

    Example:
        @retry_with_backoff(max_retries=3, base_delay=1.0)
        def fetch_data():
            return requests.get("https://api.example.com/data")

        # Delays: ~1s, ~2s, ~4s (with jitter) between retries
        # Total max attempts: 4 (1 initial + 3 retries)
    """

    def decorator(func: Callable[P, T]) -> Callable[P, T]:
        # Determine operation name for metrics
        op_name = operation_name or func.__name__

        if inspect.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
                loop = _retry_loop(
                    op_name=op_name,
                    max_retries=max_retries,
                    base_delay=base_delay,
                    max_delay=max_delay,
                    exponential_base=exponential_base,
                    jitter=jitter,
                    collect_metrics=collect_metrics,
                )
                action = next(loop)
                while True:
                    if action[0] == "call":
                        try:
                            result = await func(*args, **kwargs)  # type: ignore[misc]
                            action = loop.send(("success", result))
                        except Exception as e:
                            action = loop.send(("error", e))
                    elif action[0] == "sleep":
                        await asyncio.sleep(action[1])
                        action = next(loop)
                    elif action[0] == "return":
                        return action[1]  # type: ignore[return-value]
                    elif action[0] == "raise":
                        raise action[1]
                    else:
                        msg = f"Unknown retry loop action: {action[0]}"
                        raise RuntimeError(msg)

            return async_wrapper  # type: ignore[return-value]

        @functools.wraps(func)
        def sync_wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            loop = _retry_loop(
                op_name=op_name,
                max_retries=max_retries,
                base_delay=base_delay,
                max_delay=max_delay,
                exponential_base=exponential_base,
                jitter=jitter,
                collect_metrics=collect_metrics,
            )
            action = next(loop)
            while True:
                if action[0] == "call":
                    try:
                        result = func(*args, **kwargs)
                        action = loop.send(("success", result))
                    except Exception as e:
                        action = loop.send(("error", e))
                elif action[0] == "sleep":
                    time.sleep(action[1])
                    action = next(loop)
                elif action[0] == "return":
                    return action[1]  # type: ignore[return-value]
                elif action[0] == "raise":
                    raise action[1]
                else:
                    msg = f"Unknown retry loop action: {action[0]}"
                    raise RuntimeError(msg)

        return sync_wrapper

    return decorator


def _retry_loop(
    *,
    op_name: str,
    max_retries: int,
    base_delay: float,
    max_delay: float,
    exponential_base: float,
    jitter: float,
    collect_metrics: bool,
) -> Generator[tuple[str, ...], tuple[str, Any] | None, None]:
    """Generator that drives the retry control flow.

    Yields action tuples that the caller (sync or async wrapper) interprets:
    - ``("call",)`` -- invoke the wrapped function; caller must ``.send()``
      back ``("success", result)`` or ``("error", exception)``.
    - ``("sleep", delay)`` -- wait *delay* seconds before advancing.
    - ``("return", value)`` -- the wrapper should return *value*.
    - ``("raise", exception)`` -- the wrapper should re-raise *exception*.

    All retry counting, backoff calculation, transient-error classification,
    metrics collection, and logging live here so that both the async and sync
    wrappers share a single implementation.
    """
    last_exception: BaseException | None = None
    collector = get_retry_metrics_collector() if collect_metrics else None
    last_error_type: str | None = None

    for attempt in range(max_retries + 1):
        outcome: tuple[str, Any] | None = yield ("call",)

        if outcome is not None and outcome[0] == "success":
            # Record successful attempt in metrics
            if collector:
                collector.record_retry_attempt(
                    operation=op_name,
                    outcome="success",
                    attempt_number=attempt + 1,
                    max_retries=max_retries,
                    error_type=last_error_type,
                )
            yield ("return", outcome[1])
            return  # Generator exhausted after yield; defensive.

        # outcome is ("error", exception)
        assert outcome is not None
        e: Exception = outcome[1]
        last_exception = e
        last_error_type = type(e).__name__

        if not is_transient(e):
            logger.debug(
                "Non-transient error on attempt %d, failing fast: %s",
                attempt + 1,
                e,
            )
            # Record failed attempt for non-transient error
            if collector:
                collector.record_retry_attempt(
                    operation=op_name,
                    outcome="failure",
                    attempt_number=attempt + 1,
                    max_retries=max_retries,
                    error_type=last_error_type,
                )
            yield ("raise", e)
            return

        if attempt >= max_retries:
            logger.warning(
                "Max retries (%d) exhausted, giving up: %s",
                max_retries,
                e,
            )
            # Record retry exhaustion
            if collector:
                collector.record_retry_attempt(
                    operation=op_name,
                    outcome="failure",
                    attempt_number=attempt + 1,
                    max_retries=max_retries,
                    error_type=last_error_type,
                )
                collector.record_retry_exhaustion(
                    operation=op_name,
                    max_retries=max_retries,
                    error_type=last_error_type,
                    error_message=str(e),
                )
            yield ("raise", e)
            return

        # Record failed attempt that will be retried
        if collector:
            collector.record_retry_attempt(
                operation=op_name,
                outcome="failure",
                attempt_number=attempt + 1,
                max_retries=max_retries,
                error_type=last_error_type,
            )

        delay = _calculate_delay(
            attempt=attempt,
            base_delay=base_delay,
            max_delay=max_delay,
            exponential_base=exponential_base,
            jitter=jitter,
            error=e,
        )

        logger.info(
            "Transient error on attempt %d/%d, retrying in %.2fs: %s",
            attempt + 1,
            max_retries + 1,
            delay,
            e,
        )

        yield ("sleep", delay)

    # This should never be reached, but satisfies the type checker
    if last_exception is not None:
        yield ("raise", last_exception)
        return
    msg = "Unexpected state: no exception and no return value"
    raise RuntimeError(msg)


def _calculate_delay(
    *,
    attempt: int,
    base_delay: float,
    max_delay: float,
    exponential_base: float,
    jitter: float,
    error: BaseException,
) -> float:
    """Calculate the delay before the next retry attempt.

    Uses exponential backoff with jitter. If the error provides a retry_after
    hint, that value is used instead (but still capped at max_delay).

    Args:
        attempt: The current attempt number (0-indexed).
        base_delay: Base delay in seconds.
        max_delay: Maximum delay cap in seconds.
        exponential_base: Base for exponential calculation.
        jitter: Jitter factor (0.25 = +/-25% randomization).
        error: The exception that triggered the retry.

    Returns:
        Delay in seconds before the next retry.
    """
    # Check if error provides a retry_after hint
    retry_after = get_retry_after(error)
    if retry_after is not None:
        # Use the hint, but still cap at max_delay
        return min(retry_after, max_delay)

    # Calculate exponential delay: base_delay * (exponential_base ^ attempt)
    delay = base_delay * (exponential_base**attempt)

    # Cap at max_delay
    delay = min(delay, max_delay)

    # Apply jitter: randomize by +/- jitter factor
    jitter_range = delay * jitter
    delay = delay + random.uniform(-jitter_range, jitter_range)

    # Ensure delay is non-negative
    return max(0.0, delay)


__all__ = [
    "METRIC_RETRY_ATTEMPTS",
    "METRIC_RETRY_EXHAUSTION",
    "METRIC_RETRY_SUCCESS_RATE",
    "RetryMetric",
    "RetryMetricsCollector",
    "get_retry_metrics_collector",
    "retry_with_backoff",
]
