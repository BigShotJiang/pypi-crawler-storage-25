"""Skip record metrics helpers.

Extracted from obra/execution/skip_record.py for structural clarity.
Handles metric emission and summary aggregation for skip events.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from obra.execution.skip_record import (
    METRIC_SKIPS_TOTAL,
    SkipReason,
    SkipSource,
    _skip_metrics,
)

logger = logging.getLogger(__name__)


def emit_skip_metric(
    source: SkipSource,
    reason: SkipReason,
    task_id: str,
    tier: int,
    log_event: Any | None = None,
    trace_id: str | None = None,
    *,
    agent_type: str | None = None,
    model_name: str | None = None,
    attempt_count: int | None = None,
    error_type: str | None = None,
    phase: str | None = None,
) -> dict[str, Any]:
    """Emit a skip counter metric.

    Optional enrichment fields improve post-session diagnosis of
    transient failures and convergence exhaustion (P1-2).
    """
    metric: dict[str, Any] = {
        "metric_name": METRIC_SKIPS_TOTAL,
        "value": 1,
        "labels": {
            "source": source.value,
            "reason": reason.value,
            "tier": str(tier),
        },
        "timestamp": datetime.now(UTC).isoformat(),
        "metadata": {
            "task_id": task_id,
        },
    }
    if agent_type:
        metric["metadata"]["agent_type"] = agent_type
    if model_name:
        metric["metadata"]["model_name"] = model_name
    if attempt_count is not None:
        metric["metadata"]["attempt_count"] = attempt_count
    if error_type:
        metric["metadata"]["error_type"] = error_type
    if phase:
        metric["metadata"]["phase"] = phase
    _skip_metrics.append(metric)

    if log_event:
        try:
            log_event(
                "skip_metric",
                session_id=None,
                trace_id=trace_id,
                **metric,
            )
        except Exception as e:
            logger.debug("Failed to log skip metric: %s", e)

    logger.debug(
        "Emitted skip metric: source=%s, reason=%s, task_id=%s",
        source.value,
        reason.value,
        task_id,
    )
    return metric


def get_skip_metrics_summary(
    base_dir: str | Path | None = None,
) -> dict[str, Any]:
    """Get summary of skip records by source/reason/status."""
    from obra.execution.skip_persistence import list_skip_records

    records = list_skip_records(base_dir=base_dir)
    if not records:
        return {
            "total": 0,
            "by_source": {},
            "by_reason": {},
            "by_status": {},
        }

    by_source: dict[str, int] = {}
    by_reason: dict[str, int] = {}
    by_status: dict[str, int] = {}
    for record in records:
        by_source[record.source.value] = by_source.get(record.source.value, 0) + 1
        by_reason[record.reason.value] = by_reason.get(record.reason.value, 0) + 1
        by_status[record.status.value] = by_status.get(record.status.value, 0) + 1

    return {
        "total": len(records),
        "by_source": by_source,
        "by_reason": by_reason,
        "by_status": by_status,
    }


__all__ = [
    "emit_skip_metric",
    "get_skip_metrics_summary",
]
