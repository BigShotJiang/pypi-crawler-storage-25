"""Epic parsing and normalization helpers for the derivation pipeline."""

from __future__ import annotations

import logging
import re
from typing import Any

from obra.hybrid.json_utils import parse_planning_json_response

logger = logging.getLogger(__name__)


class EpicParser:
    """Own Step 1 epic parsing, normalization, and prose rendering."""

    @staticmethod
    def validate_step1_epics(content: dict, min_epics: int) -> tuple[bool, str | None]:
        """Validate Step 1 epic identification output."""
        if "epics" not in content:
            return (False, "Missing 'epics' field")
        if not isinstance(content["epics"], list):
            return (False, "'epics' field must be an array")

        epics = content["epics"]
        if len(epics) < min_epics:
            return (False, f"Need at least {min_epics} epics, got {len(epics)}")

        required_fields = {"id", "title", "description", "acceptance_criteria"}
        for i, epic in enumerate(epics):
            if not isinstance(epic, dict):
                return (False, f"Epic {i} is not an object")
            if not required_fields.issubset(epic.keys()):
                missing = required_fields - epic.keys()
                return (False, f"Epic {i} missing fields: {missing}")
            for field_name in ["title", "description"]:
                value = epic.get(field_name, "")
                if isinstance(value, str) and "<FILL:" in value:
                    return (
                        False,
                        f"Epic {i} has unfilled placeholder in '{field_name}' field",
                    )
            criteria = epic.get("acceptance_criteria")
            if not isinstance(criteria, list):
                return (False, f"Epic {i} acceptance_criteria must be an array")
            for j, criterion in enumerate(criteria):
                if isinstance(criterion, str) and "<FILL:" in criterion:
                    return (
                        False,
                        f"Epic {i} has unfilled placeholder in criterion {j}",
                    )

        return (True, None)

    @staticmethod
    def normalize_epics(epics_data: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Normalize epic data from template edit output."""
        if not isinstance(epics_data, list):
            return []

        normalized: list[dict[str, Any]] = []
        for idx, entry in enumerate(epics_data):
            if not isinstance(entry, dict):
                continue
            raw_id = entry.get("id")
            epic_id = str(raw_id).strip() if raw_id else f"E{idx + 1}"
            title = str(entry.get("title") or "").strip()
            description = str(entry.get("description") or "").strip()
            if not title:
                continue
            normalized.append(
                {
                    "id": epic_id,
                    "title": title,
                    "description": description,
                }
            )
        return normalized

    def parse_epics_from_prose(self, epics_prose: str) -> list[dict[str, Any]]:
        """Parse epics from Step 1 output into structured metadata."""
        cleaned = epics_prose.strip()
        if not cleaned:
            return []

        parsed, error_reason = parse_planning_json_response(cleaned)
        if parsed is not None:
            if isinstance(parsed, dict):
                epics_data = parsed.get("epics", [])
            elif isinstance(parsed, list):
                epics_data = parsed
            else:
                epics_data = []

            if isinstance(epics_data, list) and epics_data:
                return self.normalize_epics(epics_data)

            logger.warning(
                "Step 1 JSON parsed but contained no epics; proceeding with phased derivation."
            )
            return []

        epics = self.extract_epics_from_prose(cleaned)
        if epics:
            if error_reason:
                logger.info(
                    "Step 1 JSON parse failed (%s); parsed epics from prose.",
                    error_reason,
                )
            return epics

        if error_reason:
            logger.warning(
                "Step 1 JSON parsing failed (%s) and no epics found in prose.",
                error_reason,
            )
        else:
            logger.warning("Step 1 output did not contain epics JSON or prose headers.")
        return []

    @staticmethod
    def extract_epics_from_prose(epics_prose: str) -> list[dict[str, Any]]:
        """Extract epic metadata from prose output."""
        header_re = re.compile(
            r"^E(?P<num>\d+)\s*(?:EPIC\s*)?[:\-]\s*(?P<title>.+)$",
            re.IGNORECASE,
        )
        story_re = re.compile(r"^E\d+\.S\d+\b", re.IGNORECASE)

        epics: list[dict[str, Any]] = []
        current: dict[str, Any] | None = None
        description_lines: list[str] = []

        for raw_line in epics_prose.splitlines():
            line = raw_line.strip()
            if not line:
                if current and description_lines:
                    description_lines.append("")
                continue

            header_match = header_re.match(line)
            if header_match:
                if current is not None:
                    current["description"] = "\n".join(
                        ln for ln in description_lines if ln is not None
                    ).strip()
                    epics.append(current)
                current = {
                    "id": f"E{header_match.group('num')}",
                    "title": header_match.group("title").strip(),
                    "description": "",
                }
                description_lines = []
                continue

            if story_re.match(line):
                if current is not None:
                    current["description"] = "\n".join(
                        ln for ln in description_lines if ln is not None
                    ).strip()
                    epics.append(current)
                current = None
                description_lines = []
                continue

            if current is not None:
                description_lines.append(line)

        if current is not None:
            current["description"] = "\n".join(
                ln for ln in description_lines if ln is not None
            ).strip()
            epics.append(current)

        return [epic for epic in epics if epic.get("title")]

    @staticmethod
    def render_epics_prose(epics: list[dict[str, Any]]) -> str:
        """Render epics into the prose format expected by Step 2."""
        lines: list[str] = []
        for epic in epics:
            epic_id = str(epic.get("id", "")).strip()
            title = str(epic.get("title", "")).strip() or "Untitled"
            description = str(epic.get("description", "")).strip()
            header = f"{epic_id}: {title}" if epic_id else f"E?: {title}"
            lines.append(header)
            if description:
                lines.append(description)
            lines.append("")
        return "\n".join(lines).strip()
