"""Validation, diagnostics, and recovery helpers for derivation serialization."""

from __future__ import annotations

import json
import logging
import os
import re
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class PlanValidator:
    """Own validation, diagnostics, and recovery support helpers."""

    def __init__(
        self,
        *,
        raw_response_preview_limit: int,
        item_count_warning_thresholds: tuple[int, ...],
        epic_limits: Any,
        valid_phases: list[str],
        phase_to_agent: dict[str, str | None],
    ) -> None:
        self._raw_response_preview_limit = raw_response_preview_limit
        self._item_count_warning_thresholds = item_count_warning_thresholds
        self._epic_limits = epic_limits
        self._valid_phases = valid_phases
        self._phase_to_agent = phase_to_agent

    @staticmethod
    def extract_epic_story_task_titles(
        epic_detail_prose: str,
        epic_id: str,
    ) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
        """Extract story/task titles for a single epic from Step 2 prose."""
        stories: list[dict[str, str]] = []
        tasks: list[dict[str, str]] = []
        seen_story_ids: set[str] = set()
        seen_task_ids: set[str] = set()

        story_pattern = re.compile(rf"\b({re.escape(epic_id)}\.S\d+):\s*(.+)$")
        task_pattern = re.compile(rf"\b({re.escape(epic_id)}\.S\d+\.T\d+):\s*(.+)$")

        for raw_line in epic_detail_prose.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            task_match = task_pattern.search(line)
            if task_match:
                task_id = task_match.group(1).strip()
                title = task_match.group(2).strip()
                if task_id not in seen_task_ids and title:
                    tasks.append({"id": task_id, "title": title})
                    seen_task_ids.add(task_id)
                continue

            story_match = story_pattern.search(line)
            if story_match:
                story_id = story_match.group(1).strip()
                title = story_match.group(2).strip()
                if story_id not in seen_story_ids and title:
                    stories.append({"id": story_id, "title": title})
                    seen_story_ids.add(story_id)

        return stories, tasks

    @staticmethod
    def estimate_output_tokens(text: str) -> int:
        return max(1, len(text) // 4)

    def validate_epic_prose(self, content: str, epic_id: str) -> tuple[bool, str | None]:
        """Validate prose output from per-epic template editing."""
        if not content or not content.strip():
            return (False, "Empty response")
        if "<FILL:" in content:
            return (False, "Template placeholders not filled")

        all_story_ids = set(re.findall(r"\b(E\d+\.S\d+):", content))
        all_task_ids = set(re.findall(r"\b(E\d+\.S\d+\.T\d+):", content))
        target_story_ids = sorted(
            story_id for story_id in all_story_ids if story_id.startswith(f"{epic_id}.")
        )
        target_task_ids = sorted(
            task_id for task_id in all_task_ids if task_id.startswith(f"{epic_id}.")
        )

        if not target_story_ids:
            return (False, f"No structural content found for {epic_id}")

        wrong_epic_story_ids = sorted(
            story_id for story_id in all_story_ids if not story_id.startswith(f"{epic_id}.")
        )
        wrong_epic_task_ids = sorted(
            task_id for task_id in all_task_ids if not task_id.startswith(f"{epic_id}.")
        )
        if wrong_epic_story_ids or wrong_epic_task_ids:
            wrong_ids = wrong_epic_story_ids + wrong_epic_task_ids
            return (False, f"Found IDs for non-target epic(s): {', '.join(wrong_ids[:3])}")

        story_count, task_count = self.count_epic_story_task_ids(content, epic_id)
        if story_count == 0:
            return (False, f"No structural content found for {epic_id}")
        if task_count == 0:
            return (False, f"No task IDs found for {epic_id} (expected {epic_id}.S#.T#:)")

        story_to_tasks: dict[str, set[str]] = {story_id: set() for story_id in target_story_ids}
        orphan_tasks: list[str] = []
        for task_id in target_task_ids:
            story_id = task_id.rsplit(".T", 1)[0]
            if story_id in story_to_tasks:
                story_to_tasks[story_id].add(task_id)
            else:
                orphan_tasks.append(task_id)

        if orphan_tasks:
            orphan_task = orphan_tasks[0]
            orphan_story = orphan_task.rsplit(".T", 1)[0]
            return (
                False,
                f"Task {orphan_task} references missing story {orphan_story} in {epic_id}",
            )

        stories_missing_tasks = [
            story_id for story_id, tasks in story_to_tasks.items() if not tasks
        ]
        if stories_missing_tasks:
            story_id = stories_missing_tasks[0]
            return (False, f"Story {story_id} has no task IDs (expected {story_id}.T#:)")

        return (True, None)

    @staticmethod
    def count_epic_story_task_ids(epic_detail_prose: str, epic_id: str) -> tuple[int, int]:
        """Count unique story/task IDs for a specific epic in prose content."""
        story_ids = set(re.findall(rf"\b{epic_id}\.S\d+:", epic_detail_prose))
        task_ids = set(re.findall(rf"\b{epic_id}\.S\d+\.T\d+:", epic_detail_prose))
        return len(story_ids), len(task_ids)

    def count_epic_items(self, epic_detail_prose: str, epic_id: str | None = None) -> int:
        """Count story/task items in epic detail prose."""
        if epic_id:
            story_count, task_count = self.count_epic_story_task_ids(epic_detail_prose, epic_id)
            return story_count + task_count

        story_ids = set(re.findall(r"\bE\d+\.S\d+:", epic_detail_prose))
        task_ids = set(re.findall(r"\bE\d+\.S\d+\.T\d+:", epic_detail_prose))
        return len(story_ids) + len(task_ids)

    def extract_reason_codes_for_epic(
        self,
        epic_detail_prose: str,
        epic_id: str,
        *,
        status: str = "",
        item_count: int | None = None,
        output_tokens: int | None = None,
    ) -> list[str]:
        """Infer structured reason codes for epic derivation quality/recovery."""
        item_limit, token_limit = self._epic_limits()
        reason_codes: list[str] = []
        if status in {"template_fallback", "template_error", "validation_failed"}:
            reason_codes.append("template_fallback")

        all_story_ids = set(re.findall(r"\b(E\d+\.S\d+):", epic_detail_prose))
        all_task_ids = set(re.findall(r"\b(E\d+\.S\d+\.T\d+):", epic_detail_prose))
        target_story_ids = sorted(
            story_id for story_id in all_story_ids if story_id.startswith(f"{epic_id}.")
        )
        target_task_ids = sorted(
            task_id for task_id in all_task_ids if task_id.startswith(f"{epic_id}.")
        )

        if not target_story_ids:
            reason_codes.append("no_stories")
        if not target_task_ids:
            reason_codes.append("no_tasks")

        if any(not story_id.startswith(f"{epic_id}.") for story_id in all_story_ids) or any(
            not task_id.startswith(f"{epic_id}.") for task_id in all_task_ids
        ):
            reason_codes.append("wrong_epic_ids")

        story_to_tasks: dict[str, set[str]] = {story_id: set() for story_id in target_story_ids}
        orphan_tasks: list[str] = []
        for task_id in target_task_ids:
            story_id = task_id.rsplit(".T", 1)[0]
            if story_id in story_to_tasks:
                story_to_tasks[story_id].add(task_id)
            else:
                orphan_tasks.append(task_id)
        if orphan_tasks:
            reason_codes.append("orphan_tasks")
        if any(not tasks for tasks in story_to_tasks.values()):
            reason_codes.append("no_tasks_for_story")

        if item_count is not None and item_count > item_limit:
            reason_codes.append("oversized_items")
        if output_tokens is not None and output_tokens > token_limit:
            reason_codes.append("oversized_tokens")

        deduped: list[str] = []
        for code in reason_codes:
            if code not in deduped:
                deduped.append(code)
        return deduped

    @staticmethod
    def write_epic_failure_artifact(
        working_dir: Path,
        *,
        epic_id: str,
        story_count: int,
        task_count: int,
        reason_codes: list[str],
        retry_metadata: dict[str, Any],
        output_preview: str,
    ) -> str | None:
        """Persist terminal derivation failure details for remote diagnostics."""
        try:
            debug_dir = working_dir / ".obra" / "debug"
            debug_dir.mkdir(parents=True, exist_ok=True)
            timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
            path = debug_dir / f"derivation_epic_failure_{epic_id}_{timestamp}.json"
            payload = {
                "epic_id": epic_id,
                "story_count": story_count,
                "task_count": task_count,
                "reason_codes": reason_codes,
                "retry_metadata": retry_metadata,
                "output_preview": output_preview[:240],
                "session_id": os.getenv("OBRA_SESSION_ID"),
                "created_at": datetime.now(UTC).isoformat(),
            }
            path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            return str(path)
        except Exception as exc:
            logger.warning("Failed to write epic failure artifact for %s: %s", epic_id, exc)
            return None

    def log_item_count_warning(self, item_count: int) -> None:
        """Log tiered warnings for large derived plans."""
        for threshold in sorted(self._item_count_warning_thresholds, reverse=True):
            if item_count >= threshold:
                logger.warning(
                    "Large derived plan: %s items (>= %s). Ensure items stay small, single-action, and self-contained; no hard cap applied.",
                    item_count,
                    threshold,
                )
                return

    def create_diagnostic_fallback(
        self,
        error_type: str,
        diagnostic: str,
        raw_response: str,
    ) -> list[dict[str, Any]]:
        """Create a diagnostic fallback task with saved raw response context."""
        response_preview = (
            raw_response[: self._raw_response_preview_limit] if raw_response else "(empty)"
        )
        if len(raw_response) > self._raw_response_preview_limit:
            response_preview += "... (truncated)"

        try:
            debug_dir = Path.home() / ".obra" / "debug"
            debug_dir.mkdir(parents=True, exist_ok=True)
            debug_file = debug_dir / f"parse_error_{int(time.time())}.txt"
            debug_file.write_text(
                f"Error Type: {error_type}\n\n"
                f"Diagnostic: {diagnostic}\n\n"
                f"Raw Response:\n{raw_response}\n",
                encoding="utf-8",
            )
            logger.info("Full parse error details saved to: %s", debug_file)
            debug_path_info = f"\n\nFull response saved to: {debug_file}"
        except Exception as exc:
            logger.warning("Could not save debug file: %s", exc)
            debug_path_info = ""

        return [
            {
                "id": "T1",
                "item_type": "task",
                "title": "LLM Response Parse Error - Manual Review Required",
                "description": (
                    f"**Error**: {error_type}\n\n"
                    f"**Diagnostic**: {diagnostic}\n\n"
                    f"**Raw Response Preview**:\n```\n{response_preview}\n```"
                    f"{debug_path_info}\n\n"
                    f"**Next Steps**:\n"
                    f"1. Review the raw response in the debug file above\n"
                    f"2. Check LLM provider configuration (API key, model, endpoint)\n"
                    f"3. Verify the prompt format is compatible with the LLM\n"
                    f"4. Check for rate limiting or quota issues\n"
                    f"5. If using extended thinking, try without it\n"
                ),
                "acceptance_criteria": [
                    "Root cause identified",
                    "LLM returns valid JSON response",
                    "Plan items parse successfully",
                ],
                "dependencies": [],
                "work_phase": "explore",
            }
        ]

    def normalize_hierarchical_plan_items(
        self,
        items: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Normalize hierarchical plan items and apply item-count warnings."""
        normalized: list[dict[str, Any]] = []

        for i, item in enumerate(items):
            if not isinstance(item, dict):
                continue

            raw_item_type = item.get("item_type", "task")
            item_type = (
                raw_item_type
                if raw_item_type in {"epic", "story", "task", "subtask", "milestone"}
                else "task"
            )

            raw_work_phase = item.get("work_phase", "implement")
            work_phase = raw_work_phase if raw_work_phase in self._valid_phases else "implement"

            raw_suggested_agent = item.get("suggested_agent")
            suggested_agent = (
                raw_suggested_agent
                if raw_suggested_agent is not None
                else self._phase_to_agent.get(work_phase)
            )

            normalized.append(
                {
                    "id": item.get("id", f"T{i + 1}"),
                    "item_type": item_type,
                    "title": item.get("title", "Untitled"),
                    "description": item.get("description", "") or item.get("title", "Untitled"),
                    "acceptance_criteria": item.get("acceptance_criteria", []),
                    "dependencies": item.get("dependencies", []),
                    "work_phase": work_phase,
                    "suggested_agent": suggested_agent,
                }
            )

        self.log_item_count_warning(len(normalized))
        return normalized

    @staticmethod
    def validate_plan_items(plan_items: list[dict[str, Any]]) -> list[str]:
        """Validate plan items for structural correctness."""
        violations: list[str] = []
        seen_ids: set[str] = set()
        item_ids: set[str] = {item.get("id", "") for item in plan_items if item.get("id")}

        for idx, item in enumerate(plan_items):
            if not isinstance(item, dict):
                violations.append(f"Item {idx}: not a dict")
                continue

            item_id = item.get("id")
            if not item_id:
                violations.append(f"Item {idx}: missing 'id' field")
                continue

            if "item_type" not in item:
                violations.append(f"Item {item_id}: missing 'item_type' field")
            if "title" not in item:
                violations.append(f"Item {item_id}: missing 'title' field")
            if "parent_id" not in item:
                violations.append(f"Item {item_id}: missing 'parent_id' field")
            if "depth" not in item:
                violations.append(f"Item {item_id}: missing 'depth' field")

            if item_id in seen_ids:
                violations.append(f"Item {item_id}: duplicate ID")
            seen_ids.add(item_id)

            item_type = item.get("item_type")
            parent_id = item.get("parent_id")
            if item_type == "epic":
                if parent_id is not None:
                    violations.append(
                        f"Item {item_id}: epic should have parent_id=None, got '{parent_id}'"
                    )
            elif not parent_id:
                violations.append(f"Item {item_id}: {item_type} missing parent_id")
            elif parent_id not in item_ids:
                violations.append(f"Item {item_id}: parent_id '{parent_id}' not found in plan")

            depth = item.get("depth")
            expected_depth = {"epic": 0, "story": 1, "task": 2, "subtask": 3}.get(
                str(item_type) if item_type else "",
                -1,
            )
            if expected_depth >= 0 and depth != expected_depth:
                violations.append(
                    f"Item {item_id}: depth {depth} does not match {item_type} (expected {expected_depth})"
                )

        return violations
