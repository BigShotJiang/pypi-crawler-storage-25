"""Shared JSON serialization mixin for execution record dataclasses.

Eliminates identical to_json/from_json boilerplate in SkipRecord and
Breakpoint. Consuming classes must implement to_dict() and from_dict().
"""

from __future__ import annotations

import json
from typing import Any


class JsonSerializableMixin:
    """Mixin providing to_json/from_json via to_dict/from_dict."""

    def to_dict(self) -> dict[str, Any]:
        raise NotImplementedError

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Any:
        raise NotImplementedError

    def to_json(self, indent: int | None = 2) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), indent=indent)

    @classmethod
    def from_json(cls, json_str: str) -> Any:
        """Deserialize from JSON string."""
        data = json.loads(json_str)
        return cls.from_dict(data)
