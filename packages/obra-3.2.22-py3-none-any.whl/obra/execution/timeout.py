"""Centralized timeout enforcement utilities.

Provides run_with_timeout() and @with_timeout() for wrapping arbitrary
callables with a configurable timeout using concurrent.futures.ThreadPoolExecutor.

This replaces ad-hoc timeout patterns across the codebase with a single,
tested mechanism. See docs/design/briefs/TIMEOUT_ARCHITECTURE_BRIEF.md for
the design rationale and docs/decisions/ADR-077-timeout-strategy-architecture.md
for the architectural decision record.

Usage:
    from obra.execution.timeout import run_with_timeout, with_timeout

    # Direct invocation
    result = run_with_timeout(expensive_fn, timeout_s=30.0, arg1, arg2)

    # With typed exception
    result = run_with_timeout(
        subprocess_fn, timeout_s=60.0,
        exception_class=SubprocessTimeoutError,
        context={"call_site": "popen"},
    )

    # Decorator
    @with_timeout(30.0)
    def fetch_data():
        ...
"""

from __future__ import annotations

import functools
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FuturesTimeoutError
from typing import Any, Callable, TypeVar

from obra.execution.errors import TimeoutError

T = TypeVar("T")


def run_with_timeout(
    fn: Callable[..., T],
    timeout_s: float,
    *args: Any,
    on_timeout: Callable[[], None] | None = None,
    context: dict[str, Any] | None = None,
    exception_class: type[TimeoutError] = TimeoutError,
    **kwargs: Any,
) -> T:
    """Run a callable with a timeout enforced via ThreadPoolExecutor.

    Args:
        fn: The callable to execute.
        timeout_s: Maximum seconds to wait for completion.
        *args: Positional arguments forwarded to fn.
        on_timeout: Optional cleanup callback invoked on timeout
            (e.g., proc.kill()). Called before raising the exception.
        context: Optional dict of structured context merged into the
            exception as keyword arguments (e.g., call_site, provider).
        exception_class: The TimeoutError subclass to raise on timeout.
            Defaults to the base TimeoutError for general use.
        **kwargs: Keyword arguments forwarded to fn.

    Returns:
        The return value of fn(*args, **kwargs).

    Raises:
        TimeoutError (or subclass): If fn does not complete within timeout_s.
        Exception: Any exception raised by fn is propagated unchanged.
    """
    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(fn, *args, **kwargs)
        try:
            return future.result(timeout=timeout_s)
        except FuturesTimeoutError:
            if on_timeout is not None:
                on_timeout()
            ctx = context or {}
            msg = f"Operation timed out after {timeout_s}s"
            raise exception_class(msg, **ctx) from None


def with_timeout(
    timeout_s: float,
    *,
    on_timeout: Callable[[], None] | None = None,
    exception_class: type[TimeoutError] = TimeoutError,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Decorator factory that wraps a function with run_with_timeout.

    Args:
        timeout_s: Maximum seconds to wait for completion.
        on_timeout: Optional cleanup callback invoked on timeout.
        exception_class: The TimeoutError subclass to raise on timeout.

    Returns:
        A decorator that wraps the target function.

    Example:
        @with_timeout(30.0)
        def fetch_data():
            ...

        @with_timeout(60.0, exception_class=SubprocessTimeoutError)
        def run_subprocess():
            ...
    """

    def decorator(fn: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            return run_with_timeout(
                fn,
                timeout_s,
                *args,
                on_timeout=on_timeout,
                exception_class=exception_class,
                **kwargs,
            )

        return wrapper

    return decorator
