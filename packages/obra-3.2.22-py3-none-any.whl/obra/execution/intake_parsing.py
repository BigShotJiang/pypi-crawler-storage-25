"""Structured-input parsing and classification helpers for UserPlan intake."""

from __future__ import annotations

import json
from typing import Any

import yaml

from obra.schemas.userplan_schema import SourceType, UserPlan

# Fields that indicate a valid UserPlan structure.
USERPLAN_REQUIRED_FIELDS = {"id", "steps", "project_id"}
USERPLAN_OPTIONAL_INDICATOR_FIELDS = {
    "source",
    "version",
    "status",
    "created_at",
    "updated_at",
}

# Minimum fields to consider input as structured UserPlan.
USERPLAN_MIN_FIELDS_FOR_DETECTION = 2


def try_parse_structured_input(input_text: str) -> dict[str, Any] | None:
    """Try to parse input text as JSON or YAML."""
    if input_text.lstrip().startswith("{"):
        try:
            data = json.loads(input_text.strip())
            if isinstance(data, dict):
                return data
        except json.JSONDecodeError:
            pass

    try:
        data = yaml.safe_load(input_text)
        if isinstance(data, dict):
            return data
    except yaml.YAMLError:
        pass

    return None


def is_userplan_structure(data: dict[str, Any]) -> bool:
    """Return whether parsed data looks like a UserPlan."""
    indicator_fields = USERPLAN_REQUIRED_FIELDS | USERPLAN_OPTIONAL_INDICATOR_FIELDS
    present_fields = set(data.keys()) & indicator_fields
    if len(present_fields) < USERPLAN_MIN_FIELDS_FOR_DETECTION:
        return False

    steps = data.get("steps")
    if not isinstance(steps, list) or not steps:
        return False

    first_step = steps[0]
    if not isinstance(first_step, dict):
        return False

    return "title" in first_step or "description" in first_step


def detect_input_type(input_text: str) -> str:
    """Classify input text as structured or unstructured."""
    data = try_parse_structured_input(input_text)
    if data is None:
        return "unstructured"
    if is_userplan_structure(data):
        return "structured"
    return "unstructured"


def _ensure_defaults(data: dict[str, Any]) -> None:
    """Mutate parsed structured data to include required defaults."""
    from datetime import UTC, datetime

    if "id" not in data:
        first_step = data.get("steps", [{}])[0]
        title = first_step.get("title", "userplan")
        slug = UserPlan.slugify(title)
        data["id"] = UserPlan.generate_id(slug)

    if "project_id" not in data:
        data["project_id"] = "default"

    if "source" not in data:
        data["source"] = {
            "type": SourceType.STRUCTURED.value,
            "generated": False,
        }
    elif isinstance(data["source"], dict) and "type" not in data["source"]:
        data["source"]["type"] = SourceType.STRUCTURED.value

    now = datetime.now(UTC).isoformat()
    if "created_at" not in data:
        data["created_at"] = now
    if "updated_at" not in data:
        data["updated_at"] = now


def _process_step(step: dict[str, Any], index: int, userplan_id: str) -> dict[str, Any]:
    """Normalize a single structured-input step."""
    step_data = {
        "id": step.get("id", UserPlan.generate_step_id(userplan_id, index)),
        "index": step.get("index", index),
        "title": step.get("title", step.get("description", f"Step {index}")[:100]),
        "description": step.get("description", step.get("title", f"Step {index}")),
    }
    for field in ("derivation_status", "context", "raw_text"):
        if field in step:
            step_data[field] = step[field]
    return step_data


def parse_structured_userplan(input_text: str) -> UserPlan:
    """Parse and validate structured UserPlan input."""
    data = try_parse_structured_input(input_text)
    if data is None:
        msg = "Failed to parse input as YAML or JSON"
        raise ValueError(msg)

    _ensure_defaults(data)

    userplan_id = data["id"]
    steps = data.get("steps", [])
    data["steps"] = [
        _process_step(step, index, userplan_id)
        for index, step in enumerate(steps, start=1)
        if isinstance(step, dict)
    ]

    try:
        return UserPlan.model_validate(data)
    except Exception as exc:
        msg = f"Invalid UserPlan structure: {exc}"
        raise ValueError(msg) from exc
