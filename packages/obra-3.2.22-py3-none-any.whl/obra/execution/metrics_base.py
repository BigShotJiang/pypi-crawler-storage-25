"""Base classes for structured metrics in the execution subsystem.

Provides BaseMetric (dataclass) and BaseMetricsCollector[T] (generic buffer)
to eliminate duplicated __post_init__, to_dict, get_buffered_metrics, and
clear implementations across DecompositionTriggerMetric, RetryMetric,
DerivationMetric and their collectors.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Generic, TypeVar

T = TypeVar("T")


@dataclass
class BaseMetric:
    """Shared fields and methods for all execution metrics.

    Attributes:
        metric_name: Prometheus-style metric name
        value: Metric value (1 for counter increment, rate for gauge)
        labels: Metric labels dict
        timestamp: ISO-8601 timestamp (auto-set if None)
        metadata: Additional context dict
    """

    metric_name: str
    value: float
    labels: dict[str, str]
    timestamp: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Initialize timestamp if not provided."""
        if self.timestamp is None:
            self.timestamp = datetime.now(UTC).isoformat()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for event logging."""
        return {
            "metric_name": self.metric_name,
            "value": self.value,
            "labels": self.labels,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }


class BaseMetricsCollector(Generic[T]):
    """Generic metrics buffer with get/clear operations.

    Subclasses add domain-specific recording methods and counters.
    When overriding clear(), call super().clear() to reset the buffer.
    """

    def __init__(self) -> None:
        self._metrics_buffer: list[T] = []

    def get_buffered_metrics(self) -> list[T]:
        """Return a copy of all buffered metrics."""
        return list(self._metrics_buffer)

    def clear(self) -> None:
        """Clear the metrics buffer. Subclasses should call super().clear()."""
        self._metrics_buffer.clear()
