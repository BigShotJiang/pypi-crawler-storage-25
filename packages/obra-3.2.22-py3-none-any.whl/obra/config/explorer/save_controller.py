"""Save and persistence orchestration for the config explorer."""

from __future__ import annotations

import logging
from typing import Any

from textual.widgets import Header

from obra import config

from .widgets import SavePreviewModal

logger = logging.getLogger(__name__)


class SaveController:
    """Owns per-view and global save flows for ``ConfigExplorerApp``."""

    def __init__(self, app: Any) -> None:
        self._app = app

    def action_save(self) -> None:
        """Save the current view or the full config tree."""
        from obra.config.explorer.debug import is_debug_enabled, log_action

        if is_debug_enabled():
            log_action("save_requested", f"current_view={self._app._current_view}")

        if self._app._current_view in {"full_config", "personas"}:
            self.save_full_config()
            return

        current_widget = self._app._get_current_view_widget()
        if current_widget is None:
            self._app.notify("No saveable view active")
            return

        if not current_widget.is_dirty():
            self._app.notify("No changes to save")
            return

        pending_changes = current_widget.get_pending_changes()
        if not pending_changes:
            self._app.notify("No changes to save")
            return

        def handle_save_preview(confirmed: bool | None) -> None:
            if confirmed:
                self.save_current_view()

        self._app.push_screen(
            SavePreviewModal(pending_changes=pending_changes),
            handle_save_preview,
        )

    def save_full_config(self) -> None:
        """Save all pending full-config changes."""
        from obra.config.explorer.debug import is_debug_enabled, log_action, log_pending_changes

        if is_debug_enabled():
            log_action("save_full_config_requested")
            log_pending_changes(self._app._config_tree, "at_save_request")

        if not self._app._config_tree or not self._app._config_tree.has_pending_changes:
            if is_debug_enabled():
                log_action("save_rejected", "no pending changes")
            self._app.notify("No changes to save")
            return

        def handle_save_preview(confirmed: bool | None) -> None:
            if confirmed:
                self.perform_save()

        self._app.push_screen(
            SavePreviewModal(pending_changes=self._app._config_tree.pending_changes),
            handle_save_preview,
        )

    def save_current_view(self) -> None:
        """Save only the current view's dirty state."""
        current_widget = self._app._get_current_view_widget()
        if current_widget is None or not current_widget.is_dirty():
            return

        pending_changes = current_widget.get_pending_changes()
        if not pending_changes:
            return

        new_values = {path: new_val for path, (_, new_val) in pending_changes.items()}

        if self._app._config_tree:
            for path, value in new_values.items():
                self._app._config_tree.set_value(path, value)

        try:
            self.save_local_changes(new_values)
            current_widget.mark_saved()
            if self._app._config_tree:
                for path in pending_changes:
                    self._app._config_tree.pending_changes.pop(path, None)
            self._app._update_status_bar()
            change_count = len(pending_changes)
            self._app.notify(f"Saved {change_count} change{'s' if change_count != 1 else ''}")
        except Exception as exc:
            self._app.notify(f"Save failed: {exc}", severity="error")

    def perform_save(self) -> None:
        """Persist all pending local and server changes."""
        from obra.config.explorer.debug import is_debug_enabled, log_action, log_tree_rebuild

        if is_debug_enabled():
            log_action("perform_save", "starting")

        if not self._app._config_tree:
            return

        local_changes = self._app._config_tree.get_local_changes()
        server_changes = self._app._config_tree.get_server_changes()

        if is_debug_enabled():
            log_action(
                "perform_save",
                f"local={len(local_changes)}, server={len(server_changes)}",
            )

        saved_count = 0
        errors: list[str] = []

        if local_changes:
            try:
                self.save_local_changes(local_changes)
                saved_count += len(local_changes)
            except Exception as exc:
                errors.append(f"Local save failed: {exc}")

        if server_changes:
            try:
                self.save_server_changes(server_changes)
                saved_count += len(server_changes)
            except Exception as exc:
                errors.append(f"Server save failed: {exc}")

        if errors:
            self._app.notify(f"Save errors: {'; '.join(errors)}", severity="error")
            return

        self._app._config_tree.clear_pending()
        try:
            if is_debug_enabled():
                log_tree_rebuild("after_save: reloading config")
            self._app._tree_controller.reload_from_layered_config()
        except Exception as exc:
            logger.warning("Failed to refresh layered config after save: %s", exc)
            self._app._update_status_bar()
        self._app.notify(f"Saved {saved_count} change{'s' if saved_count != 1 else ''}")

    def save_local_changes(self, changes: dict[str, Any]) -> None:
        """Persist local config changes to the user config layer."""
        current_config = config.load_config()
        for path, value in changes.items():
            self._set_nested_value(current_config, path, value)
        config.save_config(current_config)
        self._app._local_config = current_config

    def save_server_changes(self, changes: dict[str, Any]) -> None:
        """Persist server config changes through the API client."""
        if self._app._api_client is None:
            raise RuntimeError(
                "No API client configured - cannot save server changes. You may be in offline mode."
            )

        if not self._app._connected:
            raise RuntimeError(
                "Server connection unavailable. Please check your network and try again."
            )

        overrides: dict[str, Any] = {}
        for path, value in changes.items():
            clean_path = path
            for prefix in ["Server Settings (SaaS).", "resolved."]:
                if clean_path.startswith(prefix):
                    clean_path = clean_path[len(prefix) :]
            overrides[clean_path] = value

        try:
            result = self._app._api_client.update_user_config(overrides=overrides)
            self._app._server_config = result
        except Exception as exc:
            self.set_offline_mode()
            raise RuntimeError(f"Server save failed: {exc}") from exc

    def set_offline_mode(self) -> None:
        """Switch the explorer into offline mode."""
        if self._app._connected:
            self._app._connected = False
            self._app._update_status_bar()
            try:
                self._app.query_one("#offline-banner")
            except Exception:
                header = self._app.query_one(Header)
                self._app.mount(self._app._offline_banner_cls(id="offline-banner"), after=header)

    def _set_nested_value(self, data: dict[str, Any], path: str, value: Any) -> None:
        """Set a nested dotted-path value inside a dictionary."""
        parts = path.split(".")
        current = data
        for part in parts[:-1]:
            if part not in current:
                current[part] = {}
            current = current[part]
        current[parts[-1]] = value
