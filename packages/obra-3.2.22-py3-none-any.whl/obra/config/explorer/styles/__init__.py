"""Packaged config explorer stylesheet resources."""
