"""Value resolution helpers for the Configuration Explorer.

Resolves 'default' placeholder values to concrete model names using
role-tier defaults from the loaded config or the LLM registry.
"""

from __future__ import annotations

from typing import Any

from .llm_registry import get_role_tier_defaults


def _get_nested(config: dict[str, Any], path: str) -> Any:
    """Get a nested value from config using dot notation."""
    parts = path.split(".")
    current = config
    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def _resolve_default_value(
    path: str,
    value: Any,
    full_config: dict[str, Any],
    role_tier_defaults_cache: dict[tuple[str, str], dict[str, str]] | None = None,
) -> tuple[Any, bool]:
    """Resolve 'default' values to actual values at load time.

    When a tier or model has value 'default', resolve it to the actual
    model name and mark it as using_default=True.

    Args:
        path: Dot-notation path like "llm.orchestrator.tiers.fast"
        value: The current value (may be 'default')
        full_config: Full config dict for provider lookup

    Returns:
        Tuple of (resolved_value, is_using_default)
        - resolved_value: The actual model name (or original value if not 'default')
        - is_using_default: True if original value was 'default'
    """
    # Only resolve string 'default' values
    if value != "default":
        return value, False

    # Check if this is a tier path: llm.{role}.tiers.{tier}
    if ".tiers." in path:
        parts = path.split(".")
        if len(parts) >= 4 and parts[0] == "llm":
            role = parts[1]  # orchestrator or implementation
            tier = parts[-1]  # fast, medium, or high

            if tier in ("fast", "medium", "high") and role in (
                "orchestrator",
                "implementation",
            ):
                # Get provider for this role
                provider = _get_nested(full_config, f"llm.{role}.provider")
                if not provider or provider == "per-role":
                    provider = _get_nested(full_config, "llm.provider")
                if not provider or provider == "per-role":
                    provider = "anthropic"  # Safe fallback

                role_model = _get_nested(full_config, f"llm.{role}.model")
                if not role_model or role_model == "per-role":
                    role_model = _get_nested(full_config, "llm.model")

                if isinstance(role_model, str) and role_model not in ("per-tier", "per-role"):
                    if role_model == "default":
                        from obra.model_registry import get_default_model

                        resolved = get_default_model(provider) or "default"
                    else:
                        resolved = role_model
                    return resolved, True

                # Resolve using role-tier defaults from the already-loaded config.
                # Fall back to runtime loader only if config data is missing.
                role_defaults = _get_role_tier_defaults_cached(
                    provider,
                    role,
                    full_config,
                    role_tier_defaults_cache,
                )
                resolved = role_defaults.get(tier, "default")
                return resolved, True

    # Check if this is a model path: llm.{role}.model
    if path.endswith(".model") and path.startswith("llm."):
        parts = path.split(".")
        if len(parts) == 3:  # llm.{role}.model
            role = parts[1]
            if role in ("orchestrator", "implementation"):
                # Get provider for this role
                provider = _get_nested(full_config, f"llm.{role}.provider")
                if not provider or provider == "per-role":
                    provider = _get_nested(full_config, "llm.provider")
                if not provider or provider == "per-role":
                    provider = "anthropic"

                from obra.model_registry import get_default_model

                resolved = get_default_model(provider) or "default"
                return resolved, True

    # Not a resolvable path, keep as-is
    return value, value == "default"


def _get_role_tier_defaults_cached(
    provider: str,
    role: str,
    full_config: dict[str, Any],
    cache: dict[tuple[str, str], dict[str, str]] | None,
) -> dict[str, str]:
    """Get role tier defaults with per-build caching.

    Priority:
    1. Read from already-loaded full_config (fast path; no I/O)
    2. Fall back to llm_registry helper (legacy/runtime compatibility)
    """
    cache_key = (provider, role)
    if cache is not None and cache_key in cache:
        return cache[cache_key]

    role_defaults: dict[str, str] = {}

    llm_section = full_config.get("llm")
    if isinstance(llm_section, dict):
        raw_role_defaults = llm_section.get("role_defaults")
        if isinstance(raw_role_defaults, dict):
            provider_defaults = raw_role_defaults.get(provider)
            if isinstance(provider_defaults, dict):
                role_map = provider_defaults.get(role)
                if isinstance(role_map, dict):
                    role_defaults = {
                        str(k): str(v)
                        for k, v in role_map.items()
                        if isinstance(k, str) and isinstance(v, str)
                    }

        if not role_defaults:
            raw_provider_defaults = llm_section.get("provider_defaults")
            if isinstance(raw_provider_defaults, dict):
                provider_map = raw_provider_defaults.get(provider)
                if isinstance(provider_map, dict):
                    role_defaults = {
                        str(k): str(v)
                        for k, v in provider_map.items()
                        if isinstance(k, str) and isinstance(v, str)
                    }

    # Fallback for edge cases where the provided config is incomplete
    if not role_defaults:
        role_defaults = get_role_tier_defaults(provider, role)

    if cache is not None:
        cache[cache_key] = role_defaults
    return role_defaults
