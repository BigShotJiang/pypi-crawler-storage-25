"""Configuration Tree View widget.

Provides an interactive tree widget for browsing and editing configuration.
"""

from typing import Any, cast

from textual.binding import Binding
from textual.message import Message
from textual.widgets import Tree
from textual.widgets.tree import TreeNode

from obra.config.explorer.models import ConfigNode, ConfigTree, SettingTier, ValueType


class ConfigTreeView(Tree[ConfigNode]):
    """Interactive tree view of configuration.

    Extends Textual's Tree widget to display ConfigNode structures with
    proper formatting, expand/collapse, and selection handling.
    """

    # Navigation bindings
    # Arrow keys handled by parent Tree widget (up/down/cursor_up/cursor_down).
    # Page/Home/End override ScrollView's viewport-only scroll with cursor movement.
    BINDINGS = [
        # Arrow-key collapse/expand (shadows ScrollView's useless horizontal scroll)
        Binding("left", "cursor_parent", "Collapse/Parent", show=False),
        Binding("right", "cursor_expand", "Expand/Enter", show=False),
        # Vim line movement
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("h", "cursor_parent", "Collapse/Parent", show=False),
        Binding("l", "cursor_expand", "Expand/Enter", show=False),
        # Selection
        Binding("enter", "select_cursor", "Toggle/Edit", priority=True),
        Binding("space", "toggle_node", "Toggle/Expand/Collapse", show=False),
        # Page-level cursor movement (shadows ScrollView's viewport-only scroll)
        Binding("pageup", "cursor_page_up", "Page Up", show=False),
        Binding("pagedown", "cursor_page_down", "Page Down", show=False),
        Binding("home", "cursor_first", "First", show=False),
        Binding("end", "cursor_last", "Last", show=False),
        # Vim page/half-page movement
        Binding("ctrl+f", "cursor_page_down", "Page Down", show=False),
        Binding("ctrl+b", "cursor_page_up", "Page Up", show=False),
        Binding("ctrl+d", "cursor_half_page_down", "Half Page Down", show=False),
        Binding("ctrl+u", "cursor_half_page_up", "Half Page Up", show=False),
    ]

    DEFAULT_CSS = """
    ConfigTreeView {
        height: 1fr;
        scrollbar-gutter: stable;
        padding: 1;
    }

    ConfigTreeView > .tree--cursor {
        background: $accent;
        color: $text;
    }

    ConfigTreeView > .tree--guides {
        color: $text-muted;
    }

    ConfigTreeView > .tree--guides-hover {
        color: $primary;
    }
    """

    def __init__(
        self,
        config_tree: ConfigTree,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        """Initialize the tree view.

        Args:
            config_tree: ConfigTree containing local and server configurations
            *args: Additional positional arguments for Tree
            **kwargs: Additional keyword arguments for Tree
        """
        super().__init__("Configuration", *args, **kwargs)
        self.config_tree = config_tree
        self._node_map: dict[str, TreeNode[ConfigNode]] = {}

    def on_mount(self) -> None:
        """Build the UI tree when mounted."""
        self._build_ui_tree()
        # Ensure root is expanded to show Local/Server sections
        self.root.expand()

    def _build_ui_tree(self) -> None:
        """Populate the Textual Tree from ConfigTree."""
        # Clear existing nodes
        self.root.remove_children()
        self._node_map.clear()

        # Local settings section
        local_label = self._format_section_label(
            self.config_tree.local_root.key,
            self.config_tree.local_root,
        )
        local_node = self.root.add(local_label, expand=True)
        local_node.data = self.config_tree.local_root
        self._add_config_children(local_node, self.config_tree.local_root)

        # Server settings section (collapsed by default - read-only info)
        server_label = self._format_section_label(
            self.config_tree.server_root.key,
            self.config_tree.server_root,
        )
        server_node = self.root.add(server_label, expand=False)
        server_node.data = self.config_tree.server_root
        self._add_config_children(server_node, self.config_tree.server_root)

    def _format_section_label(self, label: str, node: ConfigNode) -> str:
        """Format a section header label with item count.

        Args:
            label: Base label text
            node: ConfigNode to count children of

        Returns:
            Formatted label like "Local Settings (5 items)"
        """
        count = self._count_leaf_children(node)
        if count > 0:
            return f"{label} ({count} items)"
        return label

    def _count_leaf_children(self, node: ConfigNode) -> int:
        """Count leaf nodes (actual settings) in a config node.

        Args:
            node: ConfigNode to count

        Returns:
            Number of leaf children
        """
        count = 0
        for child in node.children:
            if child.is_leaf:
                count += 1
            else:
                count += self._count_leaf_children(child)
        return count

    def _add_config_children(
        self,
        ui_node: TreeNode[ConfigNode],
        config_node: ConfigNode,
    ) -> None:
        """Recursively add ConfigNode children to UI tree.

        Args:
            ui_node: Textual TreeNode to add children to
            config_node: ConfigNode containing children to add
        """
        for child in config_node.children:
            if child.is_leaf:
                # Leaf node with value
                label = self._format_leaf(child)
                leaf = ui_node.add_leaf(label, data=child)
                self._node_map[child.path] = leaf
            else:
                # Branch node (expandable)
                # Collapse advanced sections by default
                should_expand = child.tier != SettingTier.ADVANCED
                tier_suffix = " (advanced)" if child.tier == SettingTier.ADVANCED else ""

                branch_label = f"{child.key}{tier_suffix}"
                branch = ui_node.add(branch_label, expand=should_expand, data=child)
                self._node_map[child.path] = branch
                self._add_config_children(branch, child)

    def _format_leaf(self, node: ConfigNode) -> str:
        """Format a leaf node for display.

        Args:
            node: ConfigNode to format

        Returns:
            Formatted label string
        """
        modified = " *" if node.is_modified else ""
        readonly_marker = " [dim](read-only)[/dim]" if node.is_readonly else ""
        origin_badge = self._format_origin_badge(node)

        # Show default value when current value differs from default
        default_hint = self._format_default_hint(node)

        if node.value_type == ValueType.BOOLEAN:
            icon = "●" if node.value else "○"
            value_str = str(node.value).lower()
            return (
                f"{icon} {node.key}: {value_str}"
                f"{origin_badge}{default_hint}{modified}{readonly_marker}"
            )

        value_str = str(node.value) if node.value is not None else "null"

        # Add derived CLI hint for provider fields
        derived_cli = self._format_derived_cli(node)

        return (
            f"{node.key}: {value_str}{derived_cli}"
            f"{origin_badge}{default_hint}{modified}{readonly_marker}"
        )

    def _format_origin_badge(self, node: ConfigNode) -> str:
        """Format a badge for layered origin."""
        if not node.origin or node.origin == "user":
            return ""
        return f" [dim][{node.origin}][/dim]"

    def _format_derived_cli(self, node: ConfigNode) -> str:
        """Format a derived CLI hint for provider fields.

        Shows "CLI: claude (derived)" next to provider values to help users
        understand which CLI will be invoked.

        Args:
            node: ConfigNode to check

        Returns:
            Formatted hint like " [dim]CLI: claude[/dim]" or empty string
        """
        # Only show for provider fields with real provider values
        if not node.path.endswith(".provider"):
            return ""

        # Skip top-level llm.provider when set to "per-role"
        if node.value == "per-role":
            return ""

        # Get CLI from provider
        try:
            from obra.config.providers import LLM_PROVIDERS

            provider_info = LLM_PROVIDERS.get(str(node.value), {})
            cli = provider_info.get("cli")
            if cli:
                return f" [dim]CLI: {cli}[/dim]"
        except ImportError:
            pass

        return ""

    def _format_default_hint(self, node: ConfigNode) -> str:
        """Format a hint showing the default value when it differs from current.

        Args:
            node: ConfigNode to check

        Returns:
            Formatted hint like " [dim](default: value)[/dim]" or empty string
        """
        if node.default_value is None:
            return ""

        # Skip default hints for provider and model fields (too noisy)
        if node.path.endswith(".provider") or node.path.endswith(".model"):
            return ""
        # Also skip for tier model fields (fast, medium, high under .tiers.)
        if ".tiers." in node.path:
            return ""

        # Compare values - handle type differences gracefully
        if node.value == node.default_value:
            return ""

        # Format the default value for display
        if isinstance(node.default_value, bool):
            default_str = str(node.default_value).lower()
        elif node.default_value is None:
            default_str = "null"
        else:
            default_str = str(node.default_value)

        return f" [dim](default: {default_str})[/dim]"

    def refresh_node(self, path: str) -> None:
        """Refresh the display of a specific node.

        Args:
            path: Dot-notation path of the node to refresh
        """
        if path not in self._node_map:
            return

        ui_node = self._node_map[path]
        config_node = self.config_tree.get_node(path)

        if config_node and config_node.is_leaf:
            ui_node.set_label(self._format_leaf(config_node))

    def refresh_subtree(self, path: str) -> None:
        """Refresh a node and all its children.

        Useful when a parent node changes and affects child node values
        (e.g., changing a tier provider auto-updates tier model values).

        Args:
            path: Dot-notation path of the node whose subtree should be refreshed
        """
        # Refresh the node itself
        self.refresh_node(path)

        # Refresh all children (recursively)
        # Find all paths that start with this path
        path_prefix = path + "."
        for child_path in self._node_map:
            if child_path.startswith(path_prefix):
                config_node = self.config_tree.get_node(child_path)
                if config_node and config_node.is_leaf:
                    ui_node = self._node_map[child_path]
                    ui_node.set_label(self._format_leaf(config_node))

    def refresh_tree(self) -> None:
        """Rebuild the entire tree from the config data.

        Use this after bulk changes to the config tree.
        """
        self._build_ui_tree()

    def get_selected_node(self) -> ConfigNode | None:
        """Get the ConfigNode for the currently selected tree node.

        Returns:
            The selected ConfigNode or None
        """
        if self.cursor_node is None:
            return None
        return cast(ConfigNode | None, self.cursor_node.data)

    def find_node_by_path(self, path: str) -> TreeNode[ConfigNode] | None:
        """Find a tree node by its config path.

        Args:
            path: Dot-notation path

        Returns:
            The TreeNode or None if not found
        """
        return self._node_map.get(path)

    def expand_to_path(self, path: str) -> None:
        """Expand all parent nodes to reveal a path.

        Args:
            path: Dot-notation path to reveal
        """
        parts = path.split(".")
        current_path = ""

        for part in parts[:-1]:  # Don't include the final node
            current_path = f"{current_path}.{part}" if current_path else part
            node = self._node_map.get(current_path)
            if node and not node.is_expanded:
                node.expand()

    def scroll_to_path(self, path: str) -> None:
        """Scroll to make a path visible.

        Args:
            path: Dot-notation path to scroll to
        """
        self.expand_to_path(path)
        node = self._node_map.get(path)
        if node:
            self.select_node(node)
            self.scroll_to_node(node)

    def action_cursor_parent(self) -> None:
        """Move to parent node or collapse if expanded.

        Vim 'h' key behavior: if current node is expanded, collapse it.
        Otherwise, move to the parent node.
        """
        if self.cursor_node is None:
            return

        if self.cursor_node.is_expanded and self.cursor_node.children:
            # Collapse the current node
            self.cursor_node.collapse()
        elif self.cursor_node.parent is not None:
            # Move to parent
            self.select_node(self.cursor_node.parent)

    def action_cursor_expand(self) -> None:
        """Expand node or move to first child.

        Vim 'l' key behavior: if current node is collapsed, expand it.
        If already expanded, move to first child. If leaf, do nothing.
        """
        if self.cursor_node is None:
            return

        if not self.cursor_node.is_expanded and self.cursor_node.children:
            # Expand the current node
            self.cursor_node.expand()
        elif self.cursor_node.is_expanded and self.cursor_node.children:
            # Move to first child
            first_child = self.cursor_node.children[0]
            self.select_node(first_child)

    def _visible_line_count(self) -> int:
        """Return the number of tree lines visible in the viewport."""
        region = self.scrollable_content_region
        # Each tree line is 1 row high; fall back to a reasonable default.
        return max(region.height, 1)

    def _move_cursor_by(self, delta: int) -> None:
        """Move the cursor by *delta* lines (positive = down, negative = up).

        Clamps to valid range and scrolls to keep cursor visible.
        """
        if self.cursor_line == -1:
            self.cursor_line = 0 if delta > 0 else self.last_line
        else:
            target = self.cursor_line + delta
            self.cursor_line = max(0, min(target, self.last_line))
        self.scroll_to_line(self.cursor_line, animate=False)

    # -- Page-level cursor movement ------------------------------------------

    def action_cursor_page_down(self) -> None:
        """Move the cursor down by one page of visible lines."""
        self._move_cursor_by(self._visible_line_count())

    def action_cursor_page_up(self) -> None:
        """Move the cursor up by one page of visible lines."""
        self._move_cursor_by(-self._visible_line_count())

    def action_cursor_half_page_down(self) -> None:
        """Move the cursor down by half a page of visible lines."""
        self._move_cursor_by(self._visible_line_count() // 2)

    def action_cursor_half_page_up(self) -> None:
        """Move the cursor up by half a page of visible lines."""
        self._move_cursor_by(-(self._visible_line_count() // 2))

    def action_cursor_first(self) -> None:
        """Move the cursor to the first node."""
        self.cursor_line = 0
        self.scroll_to_line(0, animate=False)

    def action_cursor_last(self) -> None:
        """Move the cursor to the last node."""
        self.cursor_line = self.last_line
        self.scroll_to_line(self.last_line, animate=False)

    def action_toggle_node(self) -> None:
        """Handle Space key on selected node.

        Branch nodes: expand/collapse (default Tree behavior).
        Boolean leaves: toggle value (matches VS Code checkbox convention).
        Other leaves: no-op.
        """
        if self.cursor_node is None:
            return

        config_node = self.cursor_node.data
        if config_node is None:
            # Structural node (root) — fall back to default expand/collapse
            super().action_toggle_node()
            return

        if config_node.is_leaf and config_node.value_type == ValueType.BOOLEAN:
            if not config_node.is_readonly:
                self._toggle_boolean(config_node)
        else:
            # Branch node — expand/collapse
            super().action_toggle_node()

    def action_select_cursor(self) -> None:
        """Handle Enter key on selected node.

        For boolean nodes: toggle the value.
        For string/enum nodes: emit event to open edit modal.
        For branch nodes: expand/collapse.
        Read-only nodes cannot be edited.
        """
        if self.cursor_node is None:
            return

        config_node = self.cursor_node.data
        if config_node is None:
            return

        # Block editing on read-only fields
        if config_node.is_readonly:
            self.app.notify("This field is read-only")
            return

        if config_node.value_type == ValueType.BOOLEAN:
            self._toggle_boolean(config_node)
        elif config_node.is_leaf:
            # String/enum/integer - emit event for edit modal
            self.post_message(self.EditRequested(config_node))
        # Branch node - toggle expand/collapse
        elif self.cursor_node.is_expanded:
            self.cursor_node.collapse()
        else:
            self.cursor_node.expand()

    def _toggle_boolean(self, node: ConfigNode) -> None:
        """Toggle a boolean config value.

        Args:
            node: ConfigNode with boolean value to toggle
        """
        new_value = not node.value
        success = self.config_tree.set_value(node.path, new_value)

        if success:
            # Refresh the display
            self.refresh_node(node.path)
            # Update status bar
            self.post_message(self.ValueChanged(node.path, new_value))

    class EditRequested(Message):
        """Message posted when a non-boolean node needs editing."""

        def __init__(self, node: ConfigNode) -> None:
            super().__init__()
            self.node = node

    class ValueChanged(Message):
        """Message posted when a config value has changed."""

        def __init__(self, path: str, value: Any) -> None:
            super().__init__()
            self.path = path
            self.value = value
