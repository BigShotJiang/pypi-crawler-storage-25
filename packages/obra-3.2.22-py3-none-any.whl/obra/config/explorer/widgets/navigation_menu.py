"""Navigation Menu widget for config explorer entry points.

Provides 11 entry points ordered by increasing complexity:
0. Domain - Top-level runtime context
1. Personas - Behavior presets (safety/autonomy)
2. LLM Simple - Single provider/model
3. LLM Moderate - Tier-based models
4. LLM Custom - Per-action control
5. Runtime & CLI - Codex runtime execution controls
6. Pipeline Options - Behavior settings
7. Specialized Agents - Review agents
8. Pre-Execution Setup - Environment, tooling, automation
9. Debug & Advanced - Prompts, logging, breakpoints, timeouts
10. Full Config - Raw access (most complex)
"""

from textual.app import ComposeResult
from textual.containers import Container, Vertical
from textual.message import Message
from textual.widgets import Button, Static

from obra.config.catalog import build_catalog


def _build_entry_points() -> list[tuple[str, str, str]]:
    """Derive ENTRY_POINTS from catalog sections."""
    sections = build_catalog()["sections"]
    sections_sorted = sorted(sections, key=lambda s: s.order)
    result = []
    for i, s in enumerate(sections_sorted):
        prefix = f"{i}."
        result.append((s.id, f"{prefix} {s.label}", s.description))
    return result


ENTRY_POINTS = _build_entry_points()

# Build lookup dict for quick access by entry_point ID
_ENTRY_POINT_LOOKUP = {ep[0]: {"label": ep[1], "subtitle": ep[2]} for ep in ENTRY_POINTS}


def get_menu_info(entry_point: str) -> dict[str, str]:
    """Get menu info (label, subtitle) for an entry point.

    Args:
        entry_point: Entry point ID (e.g., 'moderate_llm')

    Returns:
        Dict with 'label' and 'subtitle' keys, or defaults if not found.

    Example:
        >>> get_menu_info('moderate_llm')
        {'label': '2. LLM Moderate', 'subtitle': 'Tier-based - Configure fast/medium/high models.'}
    """
    return _ENTRY_POINT_LOOKUP.get(entry_point, {"label": entry_point, "subtitle": ""})


class NavigationMenu(Static):
    """Navigation menu with 11 entry points for config explorer.

    Renders buttons for each entry point with subtitles describing the workflow.
    Emits Selected message when user clicks a button.
    """

    DEFAULT_CSS = """
    NavigationMenu {
        width: 100%;
        height: auto;
        align: center middle;
        padding: 1 2;
    }

    NavigationMenu > Vertical {
        width: auto;
        height: auto;
        align: center middle;
    }

    NavigationMenu .title {
        text-style: bold;
        text-align: center;
        margin-bottom: 1;
        width: 100%;
    }

    NavigationMenu .entry-container {
        width: auto;
        height: auto;
        margin-bottom: 1;
        align: center middle;
    }

    NavigationMenu Button {
        width: 50;
        margin-bottom: 0;
    }

    NavigationMenu .subtitle {
        width: 50;
        color: $text-muted;
        text-align: center;
        margin-bottom: 1;
    }
    """

    class Selected(Message):
        """Message emitted when an entry point is selected."""

        def __init__(self, entry_point: str) -> None:
            """Initialize the Selected message.

            Args:
                entry_point: ID of the selected entry point
            """
            super().__init__()
            self.entry_point = entry_point

    def compose(self) -> ComposeResult:
        """Create the navigation menu content."""
        with Vertical():
            yield Static("Configuration Explorer", classes="title")
            yield Static("Select a configuration area:", classes="title")

            for entry_id, label, subtitle in ENTRY_POINTS:
                with Container(classes="entry-container"):
                    yield Button(label, id=entry_id)
                    yield Static(subtitle, classes="subtitle")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button clicks by emitting Selected message."""
        entry_point = event.button.id
        if entry_point:
            self.post_message(self.Selected(entry_point))
