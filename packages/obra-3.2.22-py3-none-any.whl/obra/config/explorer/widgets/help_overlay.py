"""Help Overlay widget showing all keybindings.

Provides a modal overlay displaying all available keyboard shortcuts.
"""

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Label, Static

# Keybinding definitions organized by category
KEYBINDINGS = {
    "Navigation": [
        ("Up / k", "Move selection up"),
        ("Down / j", "Move selection down"),
        ("Left / h", "Collapse node / parent"),
        ("Right / l", "Expand node / enter"),
        ("PgDn / Ctrl+F", "Page down"),
        ("PgUp / Ctrl+B", "Page up"),
        ("Ctrl+D / Ctrl+U", "Half-page down / up"),
        ("Home", "Jump to first item"),
        ("End", "Jump to last item"),
        ("Shift+Left", "Scroll left"),
        ("Shift+Right", "Scroll right"),
        ("Enter", "Toggle boolean / Edit value"),
        ("Space", "Toggle boolean / Expand-Collapse"),
    ],
    "Quick Actions": [
        ("1", "Change LLM provider/model"),
        ("2 / p", "Switch preset"),
        ("3", "Jump to Features section"),
        ("a", "Toggle Advanced section"),
        ("v", "Toggle Pipeline view"),
    ],
    "Search & Filter": [
        ("/", "Enter search mode"),
        ("Esc", "Clear search / Cancel"),
        ("tag:<name>", "Filter by tag (e.g., tag:llm)"),
    ],
    "File Operations": [
        ("s", "Save changes"),
        ("u", "Discard unsaved changes"),
        ("r", "Reset section (in Custom LLM)"),
        ("R", "Reset all to defaults"),
    ],
    "General": [
        ("?", "Show this help"),
        ("q", "Quit"),
    ],
}


class HelpOverlay(ModalScreen[None]):
    """Modal overlay showing all available keybindings."""

    BINDINGS = [
        Binding("escape", "dismiss", "Close"),
        Binding("question_mark", "dismiss", "Close", show=False),
        Binding("q", "dismiss", "Close", show=False),
    ]

    DEFAULT_CSS = """
    HelpOverlay {
        align: center middle;
    }

    HelpOverlay > VerticalScroll {
        width: 70;
        max-height: 85%;
        background: $surface;
        border: thick $accent;
        padding: 1 2;
    }

    HelpOverlay #title {
        text-style: bold;
        text-align: center;
        width: 100%;
        margin-bottom: 1;
    }

    HelpOverlay .category {
        margin-top: 1;
        margin-bottom: 0;
        color: $accent;
        text-style: bold;
    }

    HelpOverlay .keybinding-row {
        padding: 0 1;
    }

    HelpOverlay .key {
        color: $primary;
        min-width: 12;
    }

    HelpOverlay .desc {
        color: $text;
    }

    HelpOverlay #footer {
        margin-top: 1;
        text-align: center;
        color: $text-muted;
    }
    """

    def compose(self) -> ComposeResult:
        """Create the help overlay content."""
        with VerticalScroll():
            yield Label("Keyboard Shortcuts", id="title")

            with Vertical():
                for category, bindings in KEYBINDINGS.items():
                    yield Static(f"-- {category} --", classes="category")
                    for key, description in bindings:
                        yield Static(
                            f"  [bold]{key:12}[/bold] {description}",
                            classes="keybinding-row",
                        )

                # Add configuration explanation
                yield Static("-- About Configuration --", classes="category")
                yield Static(
                    "  [bold]Local Settings[/bold] - Stored in ~/.obra/config-layers/01-user.yaml",
                    classes="keybinding-row",
                )
                yield Static(
                    "    Changes apply immediately to this machine only.",
                    classes="keybinding-row",
                )
                yield Static(
                    "  [bold]Server Settings[/bold] - Stored in Obra cloud",
                    classes="keybinding-row",
                )
                yield Static(
                    "    Synced across all your devices via your account.",
                    classes="keybinding-row",
                )

            yield Static("Press Esc or ? to close", id="footer")

    async def action_dismiss(self, result: None = None) -> None:
        """Close the help overlay."""
        self.dismiss(result)
