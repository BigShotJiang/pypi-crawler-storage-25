"""Dirty-state, discard, reset, and quit flows for the config explorer."""

from __future__ import annotations

from typing import Any

from .utils import build_reset_user_config, load_default_config_schema
from .widgets import UnsavedAction, UnsavedChangesModal
from .widgets.saveable_view import SaveableViewMixin


class DirtyStateController:
    """Owns dirty-state transitions for ``ConfigExplorerApp``."""

    def __init__(self, app: Any) -> None:
        self._app = app

    def get_current_view_widget(self) -> SaveableViewMixin | None:
        """Return the active saveable view widget, if one is mounted."""
        view_id_map = {
            "domain": "#domain-view",
            "simple_llm": "#simple-llm-view",
            "moderate_llm": "#moderate-llm-view",
            "custom_llm": "#custom-llm-view",
            "runtime_cli": "#runtime-cli-view",
            "pipeline": "#pipeline-options-view",
            "agents": "#specialized-agents-view",
            "validation": "#validation-tooling-view",
            "debug_advanced": "#debug-advanced-view",
            "personas": "#persona-view",
        }
        widget_id = view_id_map.get(self._app._current_view)
        if not widget_id:
            return None

        try:
            widget = self._app.query_one(widget_id)
            if isinstance(widget, SaveableViewMixin):
                return widget
        except Exception:
            pass
        return None

    def navigate_with_dirty_check(self, target: str) -> None:
        """Prompt before navigating away from a dirty saveable view."""
        current_widget = self.get_current_view_widget()
        if current_widget is None or not current_widget.is_dirty():
            self._navigate(target)
            return

        def handle_result(action: UnsavedAction | None) -> None:
            if action == UnsavedAction.SAVE:
                self._app._save_controller.save_current_view()
                self._navigate(target)
            elif action == UnsavedAction.DISCARD:
                current_widget.discard_changes()
                self._app._tree_controller.reload_from_layered_config(rebuild_widget=False)
                self._navigate(target)

        pending_count = len(current_widget.get_pending_changes())
        self._app.push_screen(UnsavedChangesModal(pending_count), handle_result)

    async def action_quit(self) -> None:
        """Quit the app after resolving pending changes."""
        if self._app._config_tree and self._app._config_tree.has_pending_changes:
            self.show_unsaved_changes_modal()
            return
        self._app.exit()

    def show_unsaved_changes_modal(self) -> None:
        """Prompt for save/discard when quitting with pending changes."""
        pending_count = self._app._config_tree.pending_count if self._app._config_tree else 0

        def handle_result(action: UnsavedAction | None) -> None:
            if action == UnsavedAction.SAVE:
                self._app._save_controller.action_save()
                if self._app._config_tree and not self._app._config_tree.has_pending_changes:
                    self._app.exit()
            elif action == UnsavedAction.DISCARD:
                if self._app._config_tree:
                    self._app._config_tree.discard_changes()
                self._app.exit()

        self._app.push_screen(UnsavedChangesModal(pending_count), handle_result)

    async def action_discard(self) -> None:
        """Discard pending changes and reload the current config state."""
        if not self._app._config_tree:
            return

        if not self._app._config_tree.has_pending_changes:
            self._app.notify("No pending changes to discard")
            return

        pending_count = self._app._config_tree.pending_count
        self._app._config_tree.discard_changes()
        self._app._tree_controller.reload_from_layered_config()
        self._app.notify(f"Discarded {pending_count} pending change(s)")

    async def action_reset_to_defaults(self) -> None:
        """Show the reset confirmation flow."""
        from .widgets.confirm_modal import ConfirmModal

        def handle_result(confirmed: bool | None) -> None:
            if confirmed:
                self.perform_reset_to_defaults()

        self._app.push_screen(
            ConfirmModal(
                title="Reset All Settings",
                message=(
                    "This will reset ALL configuration to bundled defaults.\n"
                    "Auth credentials and account info will be preserved.\n\n"
                    "This cannot be undone."
                ),
            ),
            handle_result,
        )

    def perform_reset_to_defaults(self) -> None:
        """Reset the local config while preserving auth/account metadata."""
        from obra.config import save_config
        from obra.config.explorer.widgets.preset_picker import apply_default_persona_to_config

        auth_preserve_fields = {
            "terms_accepted",
            "firebase_uid",
            "user_email",
            "auth_token",
            "refresh_token",
            "auth_provider",
            "auth_timestamp",
            "token_expires_at",
            "display_name",
            "user_id",
        }

        defaults = load_default_config_schema()
        if not defaults:
            self._app.notify("Could not load bundled defaults", severity="error")
            return

        apply_default_persona_to_config(defaults)

        current_config = self._app._config_module.load_config()
        preserved = {
            field: current_config[field]
            for field in auth_preserve_fields
            if field in current_config
        }

        new_config = build_reset_user_config(defaults, preserved)
        save_config(new_config)

        self._app._tree_controller.reload_from_layered_config()
        preserved_count = len(preserved)
        self._app.notify(
            f"Reset to defaults (preserved {preserved_count} auth fields)",
            severity="information",
        )

    def _navigate(self, target: str) -> None:
        """Perform the actual navigation after dirty handling completes."""
        if target == "menu":
            self._app._view_router.show_menu()
        else:
            self._app._view_router.show_view(target)
