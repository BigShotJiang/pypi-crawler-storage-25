"""Tree, search, and edit coordination for the config explorer."""

from __future__ import annotations

import logging
from typing import Any

from textual.containers import Vertical
from textual.widgets import Tree

from .models import ConfigNode, ConfigTree, SettingTier, ValueType
from .utils import dict_to_config_tree, filter_tree_by_predicate, find_nodes_by_path_pattern
from .widgets import ConfigTreeView, EditModal

logger = logging.getLogger(__name__)


class TreeController:
    """Owns tree construction, rebuilds, search, and edit flows."""

    def __init__(self, app: Any) -> None:
        self._app = app

    def build_view_tree(self) -> ConfigTree:
        """Build the projected config tree for the current view mode."""
        if self._app._base_tree is None:
            return dict_to_config_tree(self._app._local_config, self._app._server_config)

        local_root = self._app._base_tree.local_root
        server_root = self._app._base_tree.server_root

        if self._app._active_tag_filter:
            tag = self._app._active_tag_filter
            local_filtered = filter_tree_by_predicate(local_root, lambda node: tag in node.tags)
            server_filtered = filter_tree_by_predicate(server_root, lambda node: tag in node.tags)
            if local_filtered is None:
                local_filtered = ConfigNode(
                    key="Local Settings",
                    path="local",
                    value=None,
                    value_type=ValueType.OBJECT,
                    source=local_root.source,
                    tier=SettingTier.STANDARD,
                    description="Local settings (no matches)",
                )
            if server_filtered is None:
                server_filtered = ConfigNode(
                    key="[Server] SaaS - Read Only",
                    path="server",
                    value=None,
                    value_type=ValueType.OBJECT,
                    source=server_root.source,
                    tier=SettingTier.STANDARD,
                    description="Server settings (no matches)",
                )
            local_root = local_filtered
            server_root = server_filtered

        if self._app._view_mode == "pipeline":
            from .utils import build_pipeline_root

            pipeline_root = build_pipeline_root(local_root)
            pipeline_root.key = "Local Settings"
            local_root = pipeline_root

        return ConfigTree(
            local_root=local_root,
            server_root=server_root,
            pending_changes=self._app._base_tree.pending_changes,
        )

    def on_tree_node_highlighted(self, event: Tree.NodeHighlighted) -> None:
        """Update the description panel when the tree selection changes."""
        node_data = event.node.data
        description_panel = self._app.query_one("#description")

        if node_data is not None:
            description_panel.update_description(
                node_data.description, node_data.path or node_data.key
            )
        else:
            description_panel.update_description(None, "")

    def open_edit_modal(self, node: Any) -> None:
        """Open the edit modal for one config node."""
        if not isinstance(node, ConfigNode):
            return

        def handle_result(result: Any) -> None:
            if result is None or self._app._config_tree is None:
                return

            self._app._config_tree.set_value(node.path, result)
            tree_view = self._app.query_one("#tree", ConfigTreeView)
            tree_view.refresh_node(node.path)

            cascade_paths = self._app._config_tree.get_cascade_paths(node.path)
            for cascade_path in cascade_paths:
                tree_view.refresh_node(cascade_path)

            if node.path in ("llm.orchestrator.provider", "llm.implementation.provider"):
                self._app._auto_update_tiers_for_provider(node.path, result)
                role_path = node.path.rsplit(".provider", 1)[0]
                tree_view.refresh_subtree(f"{role_path}.tiers")

            self._app._update_status_bar()

        self._app.push_screen(EditModal(node, self._app._config_tree), handle_result)

    def apply_search_filter(self, query: str) -> None:
        """Apply a search or tag filter to the tree."""
        if not self._app._config_tree or not query:
            return

        if query.startswith("tag:"):
            tag = query.split("tag:", 1)[1].strip()
            if tag:
                self._app._active_tag_filter = tag
                self._app._config_tree = self.build_view_tree()
                self.rebuild_tree_view()
                self._app.notify(f"Filtered by tag: {tag}")
            return

        local_matches = find_nodes_by_path_pattern(self._app._config_tree.local_root, query)
        server_matches = find_nodes_by_path_pattern(self._app._config_tree.server_root, query)
        all_matches = local_matches + server_matches

        if all_matches:
            tree_view = self._app.query_one("#tree", ConfigTreeView)
            first_match = all_matches[0]
            if first_match.path:
                tree_view.scroll_to_path(first_match.path)
            self._app.notify(f"Found {len(all_matches)} matching settings")
            return

        self._app.notify("No matching settings found", severity="warning")

    def clear_search_filter(self) -> None:
        """Clear the active tag filter."""
        if self._app._active_tag_filter:
            self._app._active_tag_filter = None
            self._app._config_tree = self.build_view_tree()
            self.rebuild_tree_view()
            self._app.notify("Tag filter cleared")

    def rebuild_tree_view(self) -> None:
        """Rebuild or refresh the tree widget from the current config tree."""
        if self._app._config_tree is None:
            return

        try:
            tree_view = self._app.query_one("#tree", ConfigTreeView)
            tree_view.config_tree = self._app._config_tree
            tree_view.refresh_tree()
            self._app._update_status_bar()
        except Exception:
            pass
        else:
            return

        tree_container = self._app.query_one("#tree-container", Vertical)
        tree_view = ConfigTreeView(self._app._config_tree, id="tree")
        tree_container.mount(tree_view)
        self._app._update_status_bar()

    def reload_from_layered_config(self, *, rebuild_widget: bool = True) -> None:
        """Reload layered config and rebuild the projected tree."""
        from obra.config.loaders import load_layered_config

        self._app._local_config, self._app._origins, warnings = load_layered_config(
            include_defaults=True
        )
        if warnings:
            for warning in warnings:
                logger.warning("Config layer warning: %s", warning)

        self._app._base_tree = dict_to_config_tree(
            self._app._local_config,
            self._app._server_config,
            origins=self._app._origins,
        )
        self._app._config_tree = self.build_view_tree()

        if rebuild_widget:
            self.rebuild_tree_view()
        else:
            self._app._update_status_bar()
