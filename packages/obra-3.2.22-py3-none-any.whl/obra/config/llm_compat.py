"""Backward-compatible runtime-refresh constants for LLM configuration.

Moved from obra.config.llm (S6.T2) to reduce the surface area of the main
LLM config module.  All symbols are re-exported from obra.config.llm so
existing ``from obra.config.llm import TIER_FALLBACKS`` still works.

The ``_RuntimeRefreshDict`` facade and the four deprecated constant
wrappers (TIER_FALLBACKS, PROVIDER_TIER_DEFAULTS, XHIGH_SUPPORTED_MODELS,
ROLE_TIER_DEFAULTS) live here.
"""

from __future__ import annotations

from typing import Any, Callable, cast

from obra.config.loaders import (
    get_provider_tier_defaults,
    get_role_tier_defaults,
    get_tier_fallbacks,
    get_xhigh_supported_models,
)


class _RuntimeRefreshDict(dict[str, Any]):
    """Dictionary facade that refreshes from runtime config on each read.

    This keeps public constants backward-compatible while avoiding import-time
    freezing of layered config data.
    """

    def __init__(self, loader: Callable[[], dict[str, Any]]):
        super().__init__()
        self._loader = loader

    def _refresh(self) -> None:
        super().clear()
        super().update(self._loader())

    def __getitem__(self, key: str) -> Any:
        self._refresh()
        return super().__getitem__(key)

    def get(self, key: str, default: Any = None) -> Any:
        self._refresh()
        return super().get(key, default)

    def items(self):
        self._refresh()
        return super().items()

    def keys(self):
        self._refresh()
        return super().keys()

    def values(self):
        self._refresh()
        return super().values()

    def __contains__(self, key: object) -> bool:
        self._refresh()
        return super().__contains__(key)

    def __iter__(self):
        self._refresh()
        return super().__iter__()

    def __len__(self) -> int:
        self._refresh()
        return super().__len__()

    def copy(self) -> dict[str, Any]:
        self._refresh()
        return dict(super().items())


# ── Loader helpers ─────────────────────────────────────────────────────


def _load_runtime_provider_tier_defaults() -> dict[str, dict[str, str]]:
    """Load provider tier defaults from layered runtime config."""
    return get_provider_tier_defaults()


def _load_runtime_tier_fallbacks() -> dict[str, tuple[str, ...]]:
    """Load tier fallback chains from layered runtime config."""
    raw = get_tier_fallbacks()
    return {tier: tuple(fallback_list) for tier, fallback_list in raw.items()}


def _load_runtime_xhigh_supported_models() -> dict[str, set[str]]:
    """Load xhigh-supported model sets from layered runtime config."""
    raw = get_xhigh_supported_models()
    return {provider: set(models) for provider, models in raw.items()}


def _load_runtime_role_tier_defaults() -> dict[str, dict[str, dict[str, str]]]:
    """Load role-tier defaults from layered runtime config."""
    return get_role_tier_defaults()


# ── Deprecated constants (runtime-refreshing) ──────────────────────────
#
# These were originally top-level constants in obra.config.llm. They are
# now thin facades that read from layered config on every access.  Prefer
# calling the underlying ``get_*`` loaders directly in new code.


# DEPRECATED: This constant now reads from config. To modify defaults, edit
# obra/config/default_config.yaml under llm.tier_fallbacks.
# User config can override at ~/.obra/config.yaml.
TIER_FALLBACKS: dict[str, tuple[str, ...]] = cast(
    dict[str, tuple[str, ...]],
    _RuntimeRefreshDict(_load_runtime_tier_fallbacks),
)

# Provider-specific tier defaults (FEAT-LLM-TIERS-SPLIT-001)
# Maps provider name to default tier model assignments
# Source: docs/design/PROVIDER_TIER_DEFAULTS.md and obra/model_registry.py
# Note: Use explicit model names for clarity in UI and logs
# DEPRECATED: This constant now reads from config. To modify defaults, edit
# obra/config/default_config.yaml under llm.provider_defaults.
# User config can override at ~/.obra/config.yaml.
PROVIDER_TIER_DEFAULTS: dict[str, dict[str, str]] = cast(
    dict[str, dict[str, str]],
    _RuntimeRefreshDict(_load_runtime_provider_tier_defaults),
)

# Models that support xhigh/maximum reasoning effort
# Used by get_effective_reasoning_value() for fallback logic
# DEPRECATED: This constant now reads from config. To modify defaults, edit
# obra/config/default_config.yaml under llm.xhigh_supported_models.
# User config can override at ~/.obra/config.yaml.
XHIGH_SUPPORTED_MODELS: dict[str, set[str]] = cast(
    dict[str, set[str]],
    _RuntimeRefreshDict(_load_runtime_xhigh_supported_models),
)

# Role-aware tier defaults: provider -> role -> {fast, medium, high}
# Orchestrator may use higher-capability models than implementation for the same tier.
# When a role's tiers are set to "default" (passthrough), these values are used.
# DEPRECATED as hardcoded constant: Now reads from config llm.role_defaults.
# User config can override at ~/.obra/config-layers/01-user.yaml.
ROLE_TIER_DEFAULTS: dict[str, dict[str, dict[str, str]]] = cast(
    dict[str, dict[str, dict[str, str]]],
    _RuntimeRefreshDict(_load_runtime_role_tier_defaults),
)
