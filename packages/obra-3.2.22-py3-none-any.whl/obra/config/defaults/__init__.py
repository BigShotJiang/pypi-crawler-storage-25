"""Packaged default configuration resources."""
