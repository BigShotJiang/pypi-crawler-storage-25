"""Packaged configuration schema resources."""
