"""Provider inference from model names.

Provides model-to-provider mapping via regex pattern matching and prefix lookup,
plus model name validation against provider model lists.

Extracted from obra.config.llm as part of REFACTOR-HIGH-PRIORITY-P10-001.

Example:
    >>> from obra.config.provider_inference import infer_provider_from_model, validate_model
    >>> infer_provider_from_model("gpt-4o")
    'openai'
    >>> validate_model("sonnet", "anthropic")
    'sonnet'
"""

import re
from collections.abc import Sequence
from typing import cast

from obra.config.providers import DEFAULT_MODEL, DEFAULT_PROVIDER, LLM_PROVIDERS

# Known model shortcuts for quick switching
# Full model names (e.g., "claude-sonnet-4-6") are passed through
MODEL_SHORTCUTS = {"default", "sonnet", "opus", "haiku"}

# Model name patterns for provider inference (regex)
# Used by infer_provider_from_model() to auto-detect provider
MODEL_PROVIDER_PATTERNS: dict[str, str] = {
    # Anthropic/Claude patterns
    r"^opus$": "anthropic",
    r"^sonnet$": "anthropic",
    r"^haiku$": "anthropic",
    r"^claude": "anthropic",  # claude-*, claude-3-*, etc.
    # OpenAI/Codex patterns
    r"^gpt": "openai",  # gpt-4, gpt-5.2, etc.
    r"^o[134]": "openai",  # o1, o3, o4 models
    r"^codex": "openai",  # codex-*, codex-mini, etc.
    # Google/Gemini patterns
    r"^gemini": "google",  # gemini-2.5-*, gemini-3-*, etc.
}

# Model name prefixes for fast provider inference (non-regex fallback)
MODEL_PROVIDER_PREFIXES: dict[str, str] = {
    "opus": "anthropic",
    "sonnet": "anthropic",
    "haiku": "anthropic",
    "claude": "anthropic",
    "gpt": "openai",
    "o1": "openai",
    "o3": "openai",
    "o4": "openai",
    "codex": "openai",
    "gemini": "google",
}


def infer_provider_from_model(model: str) -> str | None:
    """Infer the LLM provider from a model name.

    Uses regex patterns first (MODEL_PROVIDER_PATTERNS), then falls back
    to prefix matching (MODEL_PROVIDER_PREFIXES).

    Args:
        model: Model name to analyze (e.g., "opus", "gpt-5.2", "gemini-2.5-flash")

    Returns:
        Provider name ("anthropic", "openai", "google") or None if unknown

    Examples:
        >>> infer_provider_from_model("opus")
        'anthropic'
        >>> infer_provider_from_model("gpt-5.2")
        'openai'
        >>> infer_provider_from_model("gemini-2.5-flash")
        'google'
        >>> infer_provider_from_model("custom-model")
        None
    """
    if not model or model == "default":
        return None

    model_lower = model.lower()

    # Try regex patterns first (most precise)
    for pattern, provider in MODEL_PROVIDER_PATTERNS.items():
        if re.match(pattern, model_lower):
            return provider

    # Fall back to prefix matching
    for prefix, provider in MODEL_PROVIDER_PREFIXES.items():
        if model_lower.startswith(prefix):
            return provider

    return None


def validate_model(model: str, provider: str = DEFAULT_PROVIDER) -> str:
    """Validate and normalize a model name.

    Supports two types of model names:
    1. Shortcuts: default, sonnet, opus, haiku (validated against provider)
    2. Full model names: claude-sonnet-4-6, gpt-4o, etc. (passthrough)

    Args:
        model: Model name to validate (shortcut or full name)
        provider: Provider to validate against for shortcuts

    Returns:
        Validated model name (unchanged)

    Raises:
        ValueError: If shortcut is not valid for the given provider
    """
    if not model:
        return DEFAULT_MODEL

    # Shortcuts are validated against provider's model list
    if model in MODEL_SHORTCUTS:
        provider_info = LLM_PROVIDERS.get(provider, LLM_PROVIDERS[DEFAULT_PROVIDER])
        valid_models = cast(Sequence[str], provider_info.get("models", []))
        if model not in valid_models:
            msg = (
                f"Model '{model}' not valid for provider '{provider}'. "
                f"Valid: {', '.join(valid_models)}"
            )
            raise ValueError(msg)
        return model

    # Full model names are passed through without validation
    # This allows users to use specific model versions like "claude-sonnet-4-6"
    return model
