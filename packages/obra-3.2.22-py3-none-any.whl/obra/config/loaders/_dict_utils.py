"""Nested dict navigation helpers for dotted config paths."""

from __future__ import annotations

from typing import Any


def _get_nested_value(config: dict[str, Any], path: str) -> Any:
    """Return nested value by dotted path."""
    current: Any = config
    for part in path.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def _has_nested_key(config: dict[str, Any], path: str) -> bool:
    """Check whether a dotted path exists in the config."""
    current: Any = config
    for part in path.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return False
    return True


def _set_nested_value(config: dict[str, Any], path: str, value: Any) -> None:
    """Set a nested value by dotted path, creating containers as needed."""
    parts = path.split(".")
    current: dict[str, Any] = config
    for part in parts[:-1]:
        if part not in current or not isinstance(current[part], dict):
            current[part] = {}
        current = current[part]
    current[parts[-1]] = value
