"""Thread-safe process-level config cache.

The cache dict is mutated in-place (.clear(), key assignment) and never
reassigned, so ``from`` imports in other modules share the same object.
"""

from __future__ import annotations

import threading
from typing import Any

# Process-level layered config cache.
# Key: (resolved_project_id, resolved_session_path_str, include_defaults)
# Value: the tuple returned by load_layered_config — (merged_config, origins, warnings)
# Invalidated on every config write (save_config, _migrate_auth_from_config).
# Guards concurrent dict access; disk I/O is performed outside the lock.
_config_cache: dict[
    tuple[str | None, str | None, bool],
    tuple[dict[str, Any], dict[str, str], list[str]],
] = {}
_config_cache_lock = threading.Lock()


def _invalidate_config_cache() -> None:
    with _config_cache_lock:
        _config_cache.clear()


def clear_config_cache() -> None:
    """Clear the process-level config cache.

    Call in test teardown to ensure isolation between test cases.
    """
    _invalidate_config_cache()
