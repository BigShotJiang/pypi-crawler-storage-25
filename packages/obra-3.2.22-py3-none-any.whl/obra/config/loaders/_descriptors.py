"""Frozen dataclass descriptors for declarative config getters."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

__all__ = [
    "ConfigEntry",
    "SectionField",
    "ConfigSection",
]


@dataclass(frozen=True)
class ConfigEntry:
    """Declarative descriptor for a scalar config getter.

    Args:
        name: Getter suffix without 'get_' prefix (e.g., 'derive_alignment_timeout').
        config_path: Dot-separated config key path (e.g., 'handlers.derive.alignment_timeout_s').
        default: Fallback value when neither env nor config provides a value.
        env_var: Optional environment variable name (e.g., 'OBRA_AGENT_EXECUTION_TIMEOUT').
        return_type: Target Python type — int, float, str, or bool.
        docstring: Custom docstring text for the generated function.
        min_val: Minimum inclusive constraint (raises ConfigurationError if violated).
        max_val: Maximum inclusive constraint (raises ConfigurationError if violated).
        choices: Tuple of allowed values (raises ConfigurationError if not in set).
        positive: If True, require value > 0 (raises ConfigurationError if violated).
        fail_fast: If True, raise ConfigurationError when config key is missing instead
            of returning the default.
    """

    name: str
    config_path: str
    default: Any
    env_var: str | None = None
    return_type: type = int
    docstring: str | None = None
    min_val: float | None = None
    max_val: float | None = None
    choices: tuple | None = None
    positive: bool = False
    fail_fast: bool = False


@dataclass(frozen=True)
class SectionField:
    """Descriptor for a single field within a composite-dict config getter.

    Args:
        name: Key name in the output dict (e.g., 'host').
        config_key: Key name in the config section (e.g., 'host').
        default: Fallback value for this field.
        field_type: Target Python type for coercion.
    """

    name: str
    config_key: str
    default: Any
    field_type: type = str


@dataclass(frozen=True)
class ConfigSection:
    """Declarative descriptor for a composite-dict config getter.

    Args:
        name: Getter suffix without 'get_' prefix (e.g., 'log_viewer_config').
        config_path: Dot-separated path to the config section
            (e.g., 'observability.log_viewer').
        fields: Per-key declarations.
        docstring: Custom docstring text for the generated function.
    """

    name: str
    config_path: str
    fields: tuple[SectionField, ...]
    docstring: str | None = None
