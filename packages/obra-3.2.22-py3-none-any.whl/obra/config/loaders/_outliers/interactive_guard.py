"""Interactive guard getter owners."""

from __future__ import annotations

from typing import Any

from .. import _core, _defaults

__all__ = [
    "get_interactive_guard_enabled",
    "get_interactive_guard_patterns",
    "get_interactive_guard_retry_max",
    "get_interactive_guard_rollback_codes",
    "get_interactive_guard_rollback_enabled",
]


def _get_interactive_guard_config() -> dict[str, Any]:
    """Return orchestration.interactive_guard config section."""
    config, _, _ = _core.load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        guard_config = orch_config.get("interactive_guard", {})
        if isinstance(guard_config, dict):
            return guard_config
    return {}


def get_interactive_guard_enabled() -> bool:
    """Get interactive guard enabled flag."""
    guard_config = _get_interactive_guard_config()
    enabled = guard_config.get("enabled")
    if enabled is not None:
        return bool(enabled)
    return _defaults.DEFAULT_INTERACTIVE_GUARD_ENABLED


def get_interactive_guard_patterns() -> list[str]:
    """Get interactive guard regex patterns."""
    guard_config = _get_interactive_guard_config()
    patterns = guard_config.get("patterns")
    if isinstance(patterns, list) and patterns:
        return [str(pattern) for pattern in patterns]
    return _defaults.DEFAULT_INTERACTIVE_GUARD_PATTERNS.copy()


def get_interactive_guard_retry_max() -> int:
    """Get interactive guard retry max."""
    guard_config = _get_interactive_guard_config()
    retry_max = guard_config.get("retry_max")
    if retry_max is not None:
        return int(retry_max)
    return _defaults.DEFAULT_INTERACTIVE_GUARD_RETRY_MAX


def get_interactive_guard_rollback_enabled() -> bool:
    """Get interactive guard rollback enabled flag."""
    guard_config = _get_interactive_guard_config()
    rollback = guard_config.get("rollback")
    if isinstance(rollback, dict):
        enabled = rollback.get("enabled")
        if enabled is not None:
            return bool(enabled)
    return _defaults.DEFAULT_INTERACTIVE_GUARD_ROLLBACK_ENABLED


def get_interactive_guard_rollback_codes() -> list[str]:
    """Get interactive guard rollback trigger codes."""
    guard_config = _get_interactive_guard_config()
    rollback = guard_config.get("rollback")
    if isinstance(rollback, dict):
        codes = rollback.get("trigger_codes")
        if isinstance(codes, list) and codes:
            return [str(code) for code in codes]
    return _defaults.DEFAULT_INTERACTIVE_GUARD_ROLLBACK_CODES.copy()
