"""Runtime and local-environment config getters."""

from __future__ import annotations

import logging
import os
from typing import Any

from .. import _core, _defaults

logger = logging.getLogger(__name__)

__all__ = [
    "get_api_base_url",
    "get_default_project_override",
    "get_heartbeat_initial_delay",
    "get_heartbeat_interval",
    "get_local_emulator_api_url",
    "get_template_retention_settings",
    "is_local_mode",
]


def get_local_emulator_api_url() -> str:
    """Get local emulator API base URL from the current emulator project id."""
    project_id = os.environ.get(
        "OBRA_FIREBASE_EMULATOR_PROJECT_ID",
        _defaults.LOCAL_EMULATOR_PROJECT_ID,
    )
    return f"http://localhost:5001/{project_id.rstrip('/')}/us-central1"


def get_api_base_url() -> str:
    """Get API base URL with environment variable override support.

    Resolution order:
    1. OBRA_API_BASE_URL environment variable
    2. api_base_url from config file
    3. DEFAULT_API_BASE_URL constant

    Returns:
        API base URL string
    """
    env_url = os.environ.get("OBRA_API_BASE_URL")
    if env_url:
        return env_url.rstrip("/")

    config, _, _ = _core.load_layered_config()
    config_url = config.get("api_base_url")
    if isinstance(config_url, str):
        return config_url.rstrip("/")

    return _defaults.DEFAULT_API_BASE_URL


def is_local_mode() -> bool:
    """Check if local emulator mode is currently enabled.

    Returns:
        True if the API base URL is set to the local emulator URL
    """
    return get_api_base_url() == get_local_emulator_api_url()


def get_template_retention_settings() -> tuple[bool, bool]:
    """Get template edit retention settings.

    Resolution order:
    1. orchestration.template_retention.keep_on_success from config file
    2. orchestration.template_retention.keep_on_error from config file
    3. DEFAULT_TEMPLATE_RETAIN_ON_SUCCESS/ERROR constants

    Returns:
        Tuple of (keep_on_success, keep_on_error)
    """
    config, _, _ = _core.load_layered_config()
    orch_config = config.get("orchestration", {})
    keep_on_success = _defaults.DEFAULT_TEMPLATE_RETAIN_ON_SUCCESS
    keep_on_error = _defaults.DEFAULT_TEMPLATE_RETAIN_ON_ERROR
    if isinstance(orch_config, dict):
        template_config = orch_config.get("template_retention", {})
        if isinstance(template_config, dict):
            if template_config.get("keep_on_success") is not None:
                keep_on_success = bool(template_config.get("keep_on_success"))
            if template_config.get("keep_on_error") is not None:
                keep_on_error = bool(template_config.get("keep_on_error"))

    return (keep_on_success, keep_on_error)


def get_heartbeat_interval() -> int:
    """Get heartbeat interval in seconds.

    Resolution order:
    1. OBRA_HEARTBEAT_INTERVAL environment variable
    2. orchestration.progress.heartbeat_interval_s from config file
    3. Default 60 seconds

    Returns:
        Heartbeat interval in seconds
    """
    env_interval = os.environ.get("OBRA_HEARTBEAT_INTERVAL")
    if env_interval:
        try:
            value = int(env_interval)
            if value > 0:
                return value
            logger.warning("OBRA_HEARTBEAT_INTERVAL must be > 0 (got %s)", env_interval)
        except ValueError:
            pass

    config, _, _ = _core.load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        progress_config = orch_config.get("progress", {})
        if isinstance(progress_config, dict):
            interval = progress_config.get("heartbeat_interval_s")
            if interval is not None:
                value = int(interval)
                if value > 0:
                    return value
                logger.warning(
                    "orchestration.progress.heartbeat_interval_s must be > 0 (got %s)",
                    interval,
                )

    return 60


def get_heartbeat_initial_delay() -> int:
    """Get heartbeat initial delay in seconds.

    Resolution order:
    1. OBRA_HEARTBEAT_INITIAL_DELAY environment variable
    2. orchestration.progress.heartbeat_initial_delay_s from config file
    3. Default 30 seconds

    Returns:
        Heartbeat initial delay in seconds
    """
    env_delay = os.environ.get("OBRA_HEARTBEAT_INITIAL_DELAY")
    if env_delay:
        try:
            value = int(env_delay)
            if value >= 0:
                return value
            logger.warning("OBRA_HEARTBEAT_INITIAL_DELAY must be >= 0 (got %s)", env_delay)
        except ValueError:
            pass

    config, _, _ = _core.load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        progress_config = orch_config.get("progress", {})
        if isinstance(progress_config, dict):
            delay = progress_config.get("heartbeat_initial_delay_s")
            if delay is not None:
                value = int(delay)
                if value >= 0:
                    return value
                logger.warning(
                    "orchestration.progress.heartbeat_initial_delay_s must be >= 0 (got %s)",
                    delay,
                )

    return 30


def get_default_project_override() -> str | None:
    """Get local default project override from layered config."""
    config, _, _ = _core.load_layered_config()
    projects = config.get("projects", {})
    if isinstance(projects, dict):
        value = projects.get("default_project")
        return str(value) if value is not None else None
    return None
