"""API config getter owners."""

from __future__ import annotations

from .. import _core

__all__ = [
    "get_api_connection_pool_config",
    "get_api_limits",
    "get_api_retry_delays",
    "get_api_timeouts",
]


def get_api_limits(config: dict | None = None) -> dict[str, int]:
    """Get API pagination limits configuration.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Dict with keys: sessions, events, plans, user_feedback.

    Raises:
        KeyError: If api.limits section is missing from config
    """
    if config is None:
        config = _core._load_default_schema()

    try:
        return config["api"]["limits"]
    except KeyError as e:
        msg = f"Missing config section: api.limits. Expected in default_config.yaml. Key error: {e}"
        raise KeyError(msg) from e


def get_api_connection_pool_config(
    config: dict | None = None,
) -> dict[str, int | float]:
    """Get API connection pool configuration.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Dict with connection pool settings.

    Raises:
        KeyError: If api.connection_pool section is missing from config
    """
    if config is None:
        config = _core._load_default_schema()

    try:
        return config["api"]["connection_pool"]
    except KeyError as e:
        msg = (
            f"Missing config section: api.connection_pool. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_api_retry_delays(config: dict | None = None) -> list[int]:
    """Get API retry delays configuration.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        List of retry delays in seconds.

    Raises:
        KeyError: If api.retry_delays_s is missing from config
    """
    if config is None:
        config = _core._load_default_schema()

    try:
        return config["api"]["retry_delays_s"]
    except KeyError as e:
        msg = (
            f"Missing config key: api.retry_delays_s. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_api_timeouts(config: dict | None = None) -> dict[str, int]:
    """Get API operation timeouts configuration.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Dict with timeout keys in seconds.

    Raises:
        KeyError: If api.timeouts section is missing from config
    """
    if config is None:
        config = _core._load_default_schema()

    try:
        return config["api"]["timeouts"]
    except KeyError as e:
        msg = (
            f"Missing config section: api.timeouts. Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e
