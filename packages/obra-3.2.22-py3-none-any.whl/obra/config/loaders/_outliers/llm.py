"""LLM and model-tier getter owners."""

from __future__ import annotations

import os
from typing import Any

from .. import _core, _defaults

__all__ = [
    "get_input_budget_on_exceed",
    "get_llm_timeouts",
    "get_ollama_endpoint",
    "get_ollama_timeouts",
    "get_provider_tier_defaults",
    "get_role_tier_defaults",
    "get_slow_llm_call_threshold_ms",
    "get_subprocess_runner_timeouts",
    "get_thinking_config",
    "get_tier_fallbacks",
    "get_timeout_config",
    "get_xhigh_supported_models",
]


def get_input_budget_on_exceed() -> str:
    """Get input budget exceed policy.

    Resolution order:
    1. OBRA_INPUT_BUDGET_ON_EXCEED environment variable
    2. llm.input_budget.on_exceed from config file
    3. DEFAULT_INPUT_BUDGET_ON_EXCEED constant ("warn")

    Returns:
        "warn" (log and continue) or "fail" (return error, no provider call)
    """
    env_val = os.environ.get("OBRA_INPUT_BUDGET_ON_EXCEED")
    if env_val is not None:
        return env_val.lower()

    config, _, _ = _core.load_layered_config()
    llm_config = config.get("llm", {})
    if isinstance(llm_config, dict):
        budget_config = llm_config.get("input_budget", {})
        if isinstance(budget_config, dict):
            on_exceed = budget_config.get("on_exceed")
            if on_exceed is not None:
                return str(on_exceed).lower()

    return _defaults.DEFAULT_INPUT_BUDGET_ON_EXCEED


def get_slow_llm_call_threshold_ms(tier: str = "quality") -> int:
    """Get threshold (ms) for slow LLM call alerting, scoped by model tier.

    Resolution order:
    1. orchestration.llm.slow_call_threshold_ms.<tier> from config (dict)
    2. orchestration.llm.slow_call_threshold_ms from config (int, backwards compat)
    3. DEFAULT_SLOW_LLM_CALL_THRESHOLD_MS[tier]
    4. DEFAULT_SLOW_LLM_CALL_THRESHOLD_FALLBACK_MS

    Set to 0 to disable slow call alerting.
    """
    try:
        config, _, _ = _core.load_layered_config()
        orchestration = config.get("orchestration", {})
        if isinstance(orchestration, dict):
            llm_section = orchestration.get("llm", {})
            if isinstance(llm_section, dict):
                raw = llm_section.get("slow_call_threshold_ms")
                if isinstance(raw, dict):
                    tier_val = raw.get(tier)
                    if tier_val is not None:
                        return int(tier_val)
                elif raw is not None:
                    return int(raw)
    except Exception:
        pass
    return _defaults.DEFAULT_SLOW_LLM_CALL_THRESHOLD_MS.get(
        tier, _defaults.DEFAULT_SLOW_LLM_CALL_THRESHOLD_FALLBACK_MS
    )


def get_provider_tier_defaults(config: dict | None = None) -> dict[str, dict[str, str]]:
    """Get provider tier defaults from configuration.

    Args:
        config: Optional config dict. If None, loads layered runtime config.

    Returns:
        Nested dict mapping provider -> tier -> model name.

    Raises:
        KeyError: If llm.provider_defaults section is missing from config
    """
    if config is None:
        config, _, _ = _core.load_layered_config(include_defaults=True)

    try:
        return config["llm"]["provider_defaults"]
    except KeyError as e:
        msg = (
            f"Missing config section: llm.provider_defaults. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_role_tier_defaults(config: dict | None = None) -> dict[str, dict[str, dict[str, str]]]:
    """Get role-aware tier defaults from configuration.

    Args:
        config: Optional config dict. If None, loads layered runtime config.

    Returns:
        Nested dict: provider -> role -> tier -> model name.

    Raises:
        KeyError: If llm.role_defaults section is missing from config
    """
    if config is None:
        config, _, _ = _core.load_layered_config(include_defaults=True)

    try:
        return config["llm"]["role_defaults"]
    except KeyError as e:
        msg = (
            f"Missing config section: llm.role_defaults. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_thinking_config(config: dict | None = None) -> dict[str, int]:
    """Get thinking/reasoning token budget configuration.

    Args:
        config: Optional config dict. If None, loads layered runtime config.

    Returns:
        Dict with keys: min_tokens, standard_tokens, max_tokens, default_budget.

    Raises:
        KeyError: If llm.thinking section is missing from config
    """
    if config is None:
        config, _, _ = _core.load_layered_config(include_defaults=True)

    try:
        return config["llm"]["thinking"]
    except KeyError as e:
        msg = (
            f"Missing config section: llm.thinking. Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_tier_fallbacks(config: dict | None = None) -> dict[str, list[str]]:
    """Get tier fallback sequences from configuration.

    Args:
        config: Optional config dict. If None, loads layered runtime config.

    Returns:
        Dict mapping tier name to list of fallback tiers in priority order.

    Raises:
        KeyError: If llm.tier_fallbacks section is missing from config
    """
    if config is None:
        config, _, _ = _core.load_layered_config(include_defaults=True)

    try:
        return config["llm"]["tier_fallbacks"]
    except KeyError as e:
        msg = (
            f"Missing config section: llm.tier_fallbacks. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_xhigh_supported_models(config: dict | None = None) -> dict[str, list[str]]:
    """Get models supporting xhigh/maximum reasoning effort.

    Args:
        config: Optional config dict. If None, loads layered runtime config.

    Returns:
        Dict mapping provider name to list of model names supporting xhigh.

    Raises:
        KeyError: If llm.xhigh_supported_models section is missing from config
    """
    if config is None:
        config, _, _ = _core.load_layered_config(include_defaults=True)

    try:
        return config["llm"]["xhigh_supported_models"]
    except KeyError as e:
        msg = (
            f"Missing config section: llm.xhigh_supported_models. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_timeout_config(config: dict | None = None) -> dict:
    """Get full timeouts configuration section.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Dict containing all timeout configurations.

    Raises:
        KeyError: If timeouts section is missing from config
    """
    if config is None:
        config = _core._load_default_schema()

    try:
        return config["timeouts"]
    except KeyError as e:
        msg = f"Missing config section: timeouts. Expected in default_config.yaml. Key error: {e}"
        raise KeyError(msg) from e


def get_llm_timeouts(config: dict | None = None) -> dict[str, int]:
    """Get LLM operation timeout configuration.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Dict with keys: auto_assessor_s, auto_story_s, llm_subprocess_s.

    Raises:
        KeyError: If timeouts section is missing from config
    """
    if config is None:
        config = _core._load_default_schema()

    try:
        timeouts = config["timeouts"]
        return {
            "auto_assessor_s": timeouts["auto_assessor_s"],
            "auto_story_s": timeouts["auto_story_s"],
            "llm_subprocess_s": timeouts["llm_subprocess_s"],
        }
    except KeyError as e:
        msg = (
            f"Missing config key in timeouts section. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_ollama_timeouts(config: dict | None = None) -> dict[str, int]:
    """Get Ollama-specific timeout configuration.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Dict with keys: default_s, status_s, status_ready_s.

    Raises:
        KeyError: If timeouts.ollama section is missing from config
    """
    if config is None:
        config = _core._load_default_schema()

    try:
        return config["timeouts"]["ollama"]
    except KeyError as e:
        msg = (
            f"Missing config section: timeouts.ollama. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_subprocess_runner_timeouts(config: dict | None = None) -> dict[str, float]:
    """Get subprocess runner timeout configuration.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Dict with keys: poll_interval_s, process_wait_s, error_cleanup_s.

    Raises:
        KeyError: If timeouts.subprocess_runner section is missing from config
    """
    if config is None:
        config = _core._load_default_schema()

    try:
        return config["timeouts"]["subprocess_runner"]
    except KeyError as e:
        msg = (
            f"Missing config section: timeouts.subprocess_runner. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e


def get_ollama_endpoint(config: dict | None = None) -> str:
    """Get Ollama API endpoint URL.

    Args:
        config: Optional config dict. If None, loads from default_config.yaml

    Returns:
        Ollama endpoint URL.

    Raises:
        KeyError: If llm.ollama.endpoint is missing from config
    """
    if config is None:
        config = _core._load_default_schema()

    try:
        return config["llm"]["ollama"]["endpoint"]
    except KeyError as e:
        msg = (
            f"Missing config key: llm.ollama.endpoint. "
            f"Expected in default_config.yaml. Key error: {e}"
        )
        raise KeyError(msg) from e
