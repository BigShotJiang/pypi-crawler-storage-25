"""Shared traversal and coercion helpers for config-loader outlier modules."""

from __future__ import annotations

import logging
import os
from collections.abc import Callable
from typing import Any

from obra.exceptions import ConfigurationError

from .. import _core

logger = logging.getLogger(__name__)


def _get_nested_config_dict(config: dict, path: list[str], schema_defaults: dict) -> dict:
    """Traverse nested dicts along *path* keys, returning the leaf or *schema_defaults*.

    Each intermediate key is checked with ``isinstance(dict)`` so that
    non-dict values (``None``, scalars, lists) short-circuit to the
    defaults rather than raising.

    Args:
        config: Root configuration dictionary.
        path: Ordered key segments to traverse
            (e.g. ``["review", "complexity", "simple"]``).
        schema_defaults: Returned (as a copy) when the path cannot be
            fully resolved or the leaf is not a dict.

    Returns:
        The dict found at the end of *path*, or a copy of
        *schema_defaults* when traversal fails at any level.
    """
    current: Any = config
    for key in path:
        if not isinstance(current, dict):
            return schema_defaults.copy()
        current = current.get(key, {})
    if not isinstance(current, dict):
        return schema_defaults.copy()
    return current


def _resolve_config_value(
    env_key: str | None,
    config_path: str,
    default: Any,
    coerce_fn: Callable[[str], Any] | None = None,
    *,
    include_defaults: bool = False,
) -> Any:
    """Resolve a single scalar config value via env → layered-config → default.

    Args:
        env_key: Environment variable name to check first.  ``None`` skips
            the env lookup entirely.
        config_path: Dot-separated path into the layered config dict
            (e.g. ``"quality.threshold"``).
        default: Fallback value returned when neither env nor config
            provides a value.
        coerce_fn: Optional callable applied to the raw *string* env value
            before returning.  If the callable raises, a
            :class:`ConfigurationError` is propagated.
        include_defaults: Forwarded to
            :func:`_core.load_layered_config`.

    Returns:
        The resolved value — from env (optionally coerced), from the
        config dict, or *default*.

    Raises:
        ConfigurationError: If *coerce_fn* raises on the env value.
    """
    # 1. Environment variable
    if env_key is not None:
        raw_env = os.environ.get(env_key)
        if raw_env:
            if coerce_fn is not None:
                try:
                    return coerce_fn(raw_env)
                except Exception as exc:
                    raise ConfigurationError(f"Invalid value '{raw_env}' for {env_key}") from exc
            return raw_env

    # 2. Layered config lookup
    try:
        config, _, _ = _core.load_layered_config(include_defaults=include_defaults)
    except Exception:
        return default

    # 3. Navigate the dot-separated path
    parts = config_path.split(".")
    current: Any = config
    for part in parts:
        if not isinstance(current, dict):
            return default
        current = current.get(part)
        if current is None:
            return default

    # 4. Value found
    return current


# ---------------------------------------------------------------------------
# Boolean coercion — moved from review.py so all outlier modules can share it.
# ---------------------------------------------------------------------------

_BOOL_TRUE = {"1", "true", "yes", "on"}
_BOOL_FALSE = {"0", "false", "no", "off"}


def _coerce_bool(value: Any) -> bool:
    """Coerce a raw config/env value to bool.

    Raises:
        ConfigurationError: If *value* cannot be interpreted as boolean.
    """
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in _BOOL_TRUE:
            return True
        if normalized in _BOOL_FALSE:
            return False
    if isinstance(value, (int, float)):
        return bool(value)
    raise ConfigurationError(f"Invalid boolean value: {value!r}")


# ---------------------------------------------------------------------------
# Typed resolver functions — eliminate per-getter boilerplate.
# ---------------------------------------------------------------------------


def resolve_bool_config(
    env_key: str | None,
    config_path: str,
    *,
    default: bool | None,
    fail_fast: bool = False,
    include_defaults: bool = False,
    label: str = "",
) -> bool:
    """Resolve a boolean config value via env -> layered-config -> default.

    Args:
        env_key: Environment variable name to check first. ``None`` skips
            the env lookup entirely.
        config_path: Dot-separated path into the layered config dict.
        default: Fallback value when neither env nor config provides a value.
            When ``None`` and no value is found, a :class:`ConfigurationError`
            is raised (fail-fast semantics).
        fail_fast: When ``True``, raise :class:`ConfigurationError` on
            any coercion failure instead of falling back to *default*.
        include_defaults: Forwarded to :func:`_core.load_layered_config`.
        label: Human-readable prefix for error messages (e.g.
            ``"Convergence setting"``).  Defaults to ``config_path``.

    Returns:
        The resolved boolean value.

    Raises:
        ConfigurationError: If the value cannot be coerced to bool and
            *fail_fast* is ``True`` or *default* is ``None``.
    """
    tag = label or config_path
    value = _resolve_config_value(
        env_key=env_key,
        config_path=config_path,
        default=None,
        coerce_fn=_coerce_bool if env_key is not None else None,
        include_defaults=include_defaults,
    )
    if value is None:
        if default is None:
            raise ConfigurationError(f"{tag} missing at {config_path}")
        return default
    try:
        return _coerce_bool(value)
    except ConfigurationError:
        if fail_fast or default is None:
            raise ConfigurationError(f"{tag} {config_path} is invalid: {value!r}") from None
        return default


def resolve_int_config(
    env_key: str | None,
    config_path: str,
    *,
    default: int | None,
    min_val: int | None = None,
    max_val: int | None = None,
    fail_fast: bool = False,
    include_defaults: bool = False,
    label: str = "",
) -> int:
    """Resolve an integer config value via env -> layered-config -> default.

    Args:
        env_key: Environment variable name to check first. ``None`` skips
            the env lookup entirely.
        config_path: Dot-separated path into the layered config dict.
        default: Fallback value when neither env nor config provides a value.
            When ``None`` and no value is found, a :class:`ConfigurationError`
            is raised.
        min_val: Optional inclusive lower bound. Values below this trigger
            either a clamp to *default* or a :class:`ConfigurationError`
            depending on *fail_fast*.
        max_val: Optional inclusive upper bound.
        fail_fast: When ``True``, raise :class:`ConfigurationError` on
            coercion failure or range violation.
        include_defaults: Forwarded to :func:`_core.load_layered_config`.
        label: Human-readable prefix for error messages.  Defaults to
            ``config_path``.

    Returns:
        The resolved integer value.

    Raises:
        ConfigurationError: On coercion failure or range violation when
            *fail_fast* is ``True`` or *default* is ``None``.
    """
    tag = label or config_path
    value = _resolve_config_value(
        env_key=env_key,
        config_path=config_path,
        default=None,
        coerce_fn=int if env_key is not None else None,
        include_defaults=include_defaults,
    )
    if value is None:
        if default is None:
            raise ConfigurationError(f"{tag} missing/invalid at {config_path}")
        return default
    try:
        int_val = int(value)
    except (TypeError, ValueError) as exc:
        if fail_fast or default is None:
            raise ConfigurationError(f"{tag} missing/invalid at {config_path}") from exc
        return default  # type: ignore[return-value]
    if min_val is not None and int_val < min_val:
        if fail_fast or default is None:
            raise ConfigurationError(f"{tag} {config_path} must be >= {min_val} (got {int_val})")
        return default
    if max_val is not None and int_val > max_val:
        if fail_fast or default is None:
            raise ConfigurationError(f"{tag} {config_path} must be <= {max_val} (got {int_val})")
        return default
    return int_val


def resolve_float_config(
    env_key: str | None,
    config_path: str,
    *,
    default: float | None,
    min_val: float | None = None,
    max_val: float | None = None,
    fail_fast: bool = False,
    include_defaults: bool = False,
    label: str = "",
) -> float:
    """Resolve a float config value via env -> layered-config -> default.

    Args:
        env_key: Environment variable name to check first. ``None`` skips
            the env lookup entirely.
        config_path: Dot-separated path into the layered config dict.
        default: Fallback value when neither env nor config provides a value.
            When ``None`` and no value is found, a :class:`ConfigurationError`
            is raised.
        min_val: Optional inclusive lower bound.
        max_val: Optional inclusive upper bound.
        fail_fast: When ``True``, raise :class:`ConfigurationError` on
            coercion failure or range violation.
        include_defaults: Forwarded to :func:`_core.load_layered_config`.
        label: Human-readable prefix for error messages.  Defaults to
            ``config_path``.

    Returns:
        The resolved float value.

    Raises:
        ConfigurationError: On coercion failure or range violation when
            *fail_fast* is ``True`` or *default* is ``None``.
    """
    tag = label or config_path
    value = _resolve_config_value(
        env_key=env_key,
        config_path=config_path,
        default=None,
        coerce_fn=float if env_key is not None else None,
        include_defaults=include_defaults,
    )
    if value is None:
        if default is None:
            raise ConfigurationError(f"{tag} missing/invalid at {config_path}")
        return default
    try:
        float_val = float(value)
    except (TypeError, ValueError) as exc:
        if fail_fast or default is None:
            raise ConfigurationError(f"{tag} missing/invalid at {config_path}") from exc
        return default  # type: ignore[return-value]
    if min_val is not None and float_val < min_val:
        if fail_fast or default is None:
            raise ConfigurationError(
                f"{tag} {config_path} must be in [{min_val}, {max_val}] (got {float_val})"
            )
        return default
    if max_val is not None and float_val > max_val:
        if fail_fast or default is None:
            raise ConfigurationError(
                f"{tag} {config_path} must be in [{min_val}, {max_val}] (got {float_val})"
            )
        return default
    return float_val


def coerce_float_with_default(value: Any, default: float, key: str = "") -> float:
    """Coerce *value* to ``float``, falling back to *default* on failure.

    Args:
        value: Raw config value (may be ``str``, ``int``, ``None``, etc.).
        default: Returned when *value* is ``None`` or cannot be converted.
        key: Optional config key name used in the warning log message.

    Returns:
        ``float(value)`` on success, or *default*.
    """
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        if key:
            logger.warning(
                "Could not coerce %s value %r to float; using default %s", key, value, default
            )
        return default
