"""Auth state persistence and one-time migration.

Auth credentials live in ``~/.obra/auth.yaml``, separate from the main
config so the schema validator does not flag them as unknown keys.
"""

from __future__ import annotations

import logging
import os
from typing import Any

import yaml

from . import _defaults
from ._cache import _invalidate_config_cache

logger = logging.getLogger(__name__)


def _load_auth_state_from_env() -> dict[str, Any] | None:
    """Load auth state from explicit environment variables when provided."""
    auth_token = os.environ.get("OBRA_AUTH_TOKEN", "").strip()
    if not auth_token:
        return None

    env_auth_state: dict[str, Any] = {"auth_token": auth_token}
    env_mappings = {
        "OBRA_REFRESH_TOKEN": "refresh_token",
        "OBRA_FIREBASE_API_KEY": "firebase_api_key",
        "OBRA_TOKEN_EXPIRES_AT": "token_expires_at",
        "OBRA_AUTH_PROVIDER": "auth_provider",
        "OBRA_AUTH_TIMESTAMP": "auth_timestamp",
        "OBRA_FIREBASE_UID": "firebase_uid",
        "OBRA_USER_ID": "user_id",
        "OBRA_USER_EMAIL": "user_email",
        "OBRA_DISPLAY_NAME": "display_name",
    }
    for env_key, state_key in env_mappings.items():
        value = os.environ.get(env_key, "").strip()
        if value:
            env_auth_state[state_key] = value
    return env_auth_state


def _load_local_emulator_auth_state() -> dict[str, Any] | None:
    """Return a synthetic auth state when running against the local emulator."""
    emulator_host = os.environ.get("FIRESTORE_EMULATOR_HOST", "").strip()
    if not emulator_host:
        return None

    project_id = (
        os.environ.get(
            "OBRA_FIREBASE_EMULATOR_PROJECT_ID",
            _defaults.LOCAL_EMULATOR_PROJECT_ID,
        ).strip()
        or _defaults.LOCAL_EMULATOR_PROJECT_ID
    )
    local_api_url = f"http://localhost:5001/{project_id.rstrip('/')}/us-central1"
    api_base_url = os.environ.get("OBRA_API_BASE_URL", "").strip().rstrip("/")
    if api_base_url != local_api_url:
        return None

    user_id = os.environ.get("OBRA_LOCAL_EMULATOR_USER_ID", "dev-local").strip() or "dev-local"
    user_email = (
        os.environ.get("OBRA_LOCAL_EMULATOR_USER_EMAIL", "dev@local.test").strip()
        or "dev@local.test"
    )
    auth_token = (
        os.environ.get("OBRA_LOCAL_EMULATOR_AUTH_TOKEN", "emulator-local-token").strip()
        or "emulator-local-token"
    )
    return {
        "firebase_uid": user_id,
        "user_id": user_id,
        "user_email": user_email,
        "auth_token": auth_token,
        "refresh_token": "",
        "token_expires_at": "",
        "auth_provider": "emulator",
    }


def _merge_auth_state_defaults(
    auth_state: dict[str, Any],
    defaults: dict[str, Any] | None,
) -> dict[str, Any]:
    """Overlay non-empty auth fields on top of supplied defaults."""
    if defaults is None:
        return auth_state

    merged = dict(defaults)
    for key, value in auth_state.items():
        if value is None:
            continue
        if isinstance(value, str) and not value.strip():
            continue
        merged[key] = value
    return merged


def load_auth_state() -> dict[str, Any]:
    """Load auth state from ~/.obra/auth.yaml.

    Auth credentials are stored separately from application config so that
    the config schema validator does not flag them as unknown keys.

    On first call after upgrade, migrates auth keys from the old location
    (01-user.yaml) into auth.yaml so users don't need to re-login.

    Returns:
        Auth state dictionary (empty if file does not exist)
    """
    env_auth_state = _load_auth_state_from_env()
    if env_auth_state is not None:
        return env_auth_state
    local_emulator_auth_state = _load_local_emulator_auth_state()

    if not _defaults.AUTH_STATE_PATH.exists():
        _migrate_auth_from_config()
        if not _defaults.AUTH_STATE_PATH.exists():
            return local_emulator_auth_state or {}

    try:
        with _defaults.AUTH_STATE_PATH.open(encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
    except Exception:
        logger.warning("Failed to load auth state from %s", _defaults.AUTH_STATE_PATH)
        return local_emulator_auth_state or {}

    if not isinstance(data, dict):
        return local_emulator_auth_state or {}
    if local_emulator_auth_state is not None:
        # Local emulator auth must win over persisted workstation login state so
        # local CLI invocations stay bound to the emulator identity and never
        # inherit production refresh metadata.
        merged = _merge_auth_state_defaults(local_emulator_auth_state, data)
        merged["refresh_token"] = local_emulator_auth_state.get("refresh_token", "")
        merged["token_expires_at"] = local_emulator_auth_state.get("token_expires_at", "")
        return merged
    return data


def _migrate_auth_from_config() -> None:
    """One-time migration: extract auth keys from 01-user.yaml into auth.yaml.

    Runs only when auth.yaml does not exist and the old config has auth keys.
    After extraction, the auth keys are removed from 01-user.yaml.
    """
    if not _defaults.CONFIG_PATH.exists():
        return

    try:
        with _defaults.CONFIG_PATH.open(encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
    except Exception:
        return

    if not isinstance(config, dict):
        return

    # Extract auth keys that exist in the old config
    auth_state = {k: config[k] for k in _defaults._AUTH_STATE_KEYS if k in config}
    if not auth_state:
        return

    # Write auth state to new location
    _defaults.AUTH_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    with _defaults.AUTH_STATE_PATH.open("w", encoding="utf-8") as f:
        yaml.safe_dump(auth_state, f, default_flow_style=False, sort_keys=False)

    # Remove auth keys from old config
    for k in _defaults._AUTH_STATE_KEYS:
        config.pop(k, None)
    with _defaults.CONFIG_PATH.open("w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)

    _invalidate_config_cache()
    logger.info(
        "Migrated auth credentials from %s to %s",
        _defaults.CONFIG_PATH,
        _defaults.AUTH_STATE_PATH,
    )


def save_auth_state(state: dict[str, Any]) -> None:
    """Save auth state to ~/.obra/auth.yaml.

    Args:
        state: Auth state dictionary to save
    """
    _defaults.AUTH_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)

    with _defaults.AUTH_STATE_PATH.open("w", encoding="utf-8") as f:
        yaml.safe_dump(state, f, default_flow_style=False, sort_keys=False)
