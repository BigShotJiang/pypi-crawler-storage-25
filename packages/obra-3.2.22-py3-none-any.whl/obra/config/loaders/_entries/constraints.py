"""Constraint-validated scalar getters (CONSTRAINT_ENTRIES).

Candidates verified against two criteria:
  (1) calls load_layered_config() WITHOUT include_defaults=True
  (2) raises ConfigurationError on constraint violation (not warn-and-fallback)

None of the four candidates from CONFIG_LOADERS_ANALYSIS.md section 4.1 qualify:
  get_generated_plan_quality_threshold -- silent fallback on range violation (no raise)
  get_heartbeat_initial_delay         -- warn-and-fallback (logs warning, falls through)
  get_refinement_regression_min_delta -- warn-and-fallback (logs warning, falls through)
  get_revision_plan_shrinkage_warning_threshold -- uses include_defaults=True

These remain handwritten outliers in loaders.py.
"""

from __future__ import annotations

from .._descriptors import ConfigEntry

CONSTRAINT_ENTRIES: list[ConfigEntry] = []
