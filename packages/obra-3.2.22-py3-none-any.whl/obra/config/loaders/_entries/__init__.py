"""Domain-split config entry lists.

Re-exports all five entry lists so callers can use::

    from obra.config.loaders._entries import HANDLER_ENTRIES, INFRA_ENTRIES, ...
"""

from __future__ import annotations

from .constraints import CONSTRAINT_ENTRIES
from .domain import DOMAIN_ENTRIES
from .handlers import HANDLER_ENTRIES
from .infra import INFRA_ENTRIES
from .sections import SECTION_ENTRIES

__all__ = [
    "HANDLER_ENTRIES",
    "INFRA_ENTRIES",
    "DOMAIN_ENTRIES",
    "SECTION_ENTRIES",
    "CONSTRAINT_ENTRIES",
]
