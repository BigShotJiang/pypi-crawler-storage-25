"""Re-export facade — see sub-modules for implementations.

This module preserves backward compatibility for existing imports of the form
``from obra.config.loaders._core import <function>``.  All implementations
live in the focused sub-modules (_paths, _cache, _dict_utils, _auth,
_transforms, _schema, _loading).
"""

from ._auth import (
    _load_auth_state_from_env,
    _migrate_auth_from_config,
    load_auth_state,
    save_auth_state,
)
from ._cache import (
    _config_cache,
    _config_cache_lock,
    _invalidate_config_cache,
    clear_config_cache,
)
from ._dict_utils import _get_nested_value, _has_nested_key, _set_nested_value
from ._loading import (
    _convert_legacy_tools_config,
    _empty_tools_config,
    _load_layer_file,
    _merge_with_origins,
    _normalize_tools_config,
    _record_origins,
    enable_local_mode,
    expand_automation_mode,
    get_isolated_mode,
    load_config,
    load_config_with_warnings,
    load_layered_config,
    load_llm_section,
    load_project_layer,
    save_config,
    set_isolated_mode,
)
from ._paths import (
    _ensure_user_config_exists,
    _yaml_safe_load,
    get_config_path,
    get_project_layer_path,
    get_session_layer_override,
    get_session_layer_path,
)
from ._schema import (
    _get_default_code_verify_config,
    _get_default_escalation_fixer_config,
    _get_default_schema_cached,
    _load_default_schema,
    validate_default_schema,
    validate_pipeline_config,
)
from ._transforms import (
    _apply_config_aliases,
    _check_deprecated_fields,
    _get_pipeline_project_overlay_entries,
    _legacy_issue_route,
    _legacy_runner_activation,
    _legacy_sound_route,
    _normalize_agent_bool_configs,
    _normalize_pipeline_runner_catalog,
    _normalize_text,
    _project_legacy_runner_catalog_entry,
    _project_legacy_stage_quality_loop,
    _project_session_pipeline_compatibility,
    _set_pipeline_project_overlay_entries,
    resolve_config_alias,
    resolve_semantic_alias,
)

# Mutable scalar globals (_config_validated, _DEFAULT_SCHEMA_CACHE) are NOT
# re-exported via ``from`` import — bool/None are immutable so reassignment
# in _schema.py would create a new binding invisible here.  Tests that need
# these must target ``obra.config.loaders._schema._config_validated`` directly.

__all__ = [
    "_apply_config_aliases",
    "_check_deprecated_fields",
    "_config_cache",
    "_config_cache_lock",
    "_convert_legacy_tools_config",
    "_empty_tools_config",
    "_ensure_user_config_exists",
    "_get_default_code_verify_config",
    "_get_default_escalation_fixer_config",
    "_get_default_schema_cached",
    "_get_nested_value",
    "_get_pipeline_project_overlay_entries",
    "_has_nested_key",
    "_invalidate_config_cache",
    "_legacy_issue_route",
    "_legacy_runner_activation",
    "_legacy_sound_route",
    "_load_auth_state_from_env",
    "_load_default_schema",
    "_load_layer_file",
    "_merge_with_origins",
    "_migrate_auth_from_config",
    "_normalize_agent_bool_configs",
    "_normalize_pipeline_runner_catalog",
    "_normalize_text",
    "_normalize_tools_config",
    "_project_legacy_runner_catalog_entry",
    "_project_legacy_stage_quality_loop",
    "_project_session_pipeline_compatibility",
    "_record_origins",
    "_set_nested_value",
    "_set_pipeline_project_overlay_entries",
    "_yaml_safe_load",
    "clear_config_cache",
    "enable_local_mode",
    "expand_automation_mode",
    "get_config_path",
    "get_isolated_mode",
    "get_project_layer_path",
    "get_session_layer_override",
    "get_session_layer_path",
    "load_auth_state",
    "load_config",
    "load_config_with_warnings",
    "load_layered_config",
    "load_llm_section",
    "load_project_layer",
    "resolve_config_alias",
    "resolve_semantic_alias",
    "save_auth_state",
    "save_config",
    "set_isolated_mode",
    "validate_default_schema",
    "validate_pipeline_config",
]
