"""Client IP extraction with trusted-proxy boundaries for gateway transports."""

from __future__ import annotations

import ipaddress
from typing import Iterable

from fastapi import Request, WebSocket


def _parse_trusted_networks(trusted_proxy_cidrs: Iterable[str]) -> list[ipaddress._BaseNetwork]:
    networks: list[ipaddress._BaseNetwork] = []
    for cidr in trusted_proxy_cidrs:
        try:
            networks.append(ipaddress.ip_network(cidr, strict=False))
        except ValueError:
            continue
    return networks


def _extract_peer_ip(peer_host: str | None) -> str:
    if not peer_host:
        return "0.0.0.0"
    try:
        return str(ipaddress.ip_address(peer_host.strip()))
    except ValueError:
        return "0.0.0.0"


def _is_trusted_proxy(peer_ip: str, trusted_proxy_cidrs: Iterable[str]) -> bool:
    networks = _parse_trusted_networks(trusted_proxy_cidrs)
    if not networks:
        return False
    try:
        peer = ipaddress.ip_address(peer_ip)
    except ValueError:
        return False
    return any(peer in network for network in networks)


def _extract_forwarded_ip(headers: dict[str, str]) -> str | None:
    xff = headers.get("x-forwarded-for")
    if xff:
        candidate = xff.split(",", 1)[0].strip()
        try:
            return str(ipaddress.ip_address(candidate))
        except ValueError:
            return None
    x_real_ip = headers.get("x-real-ip")
    if x_real_ip:
        candidate = x_real_ip.strip()
        try:
            return str(ipaddress.ip_address(candidate))
        except ValueError:
            return None
    return None


def extract_client_ip_from_request(
    request: Request,
    trusted_proxy_cidrs: Iterable[str],
) -> str:
    """Resolve client IP for HTTP requests with optional trusted-proxy forwarding."""
    peer_ip = _extract_peer_ip(request.client.host if request.client else None)
    if not _is_trusted_proxy(peer_ip, trusted_proxy_cidrs):
        return peer_ip
    forwarded_ip = _extract_forwarded_ip(dict(request.headers))
    return forwarded_ip or peer_ip


def extract_client_ip_from_websocket(
    ws: WebSocket,
    trusted_proxy_cidrs: Iterable[str],
) -> str:
    """Resolve client IP for WebSockets with optional trusted-proxy forwarding."""
    peer_ip = _extract_peer_ip(ws.client.host if ws.client else None)
    if not _is_trusted_proxy(peer_ip, trusted_proxy_cidrs):
        return peer_ip
    forwarded_ip = _extract_forwarded_ip(dict(ws.headers))
    return forwarded_ip or peer_ip
