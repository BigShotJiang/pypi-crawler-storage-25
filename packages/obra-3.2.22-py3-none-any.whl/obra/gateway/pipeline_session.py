"""Background session manager for assistant pipeline executions."""

from __future__ import annotations

import asyncio
import threading
from dataclasses import asdict, dataclass, is_dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Literal
from uuid import uuid4

from obra.gateway.event_bus import SessionEventBus


def _utc_now() -> datetime:
    return datetime.now(tz=timezone.utc)


@dataclass
class PipelineSessionRecord:
    """Tracks state for one background assistant pipeline execution."""

    id: str
    thread_id: str
    turn_id: str
    pipeline_id: str
    display_name: str | None
    status: Literal["running", "completed", "failed", "cancelled"]
    event_bus: SessionEventBus
    cancel_event: threading.Event
    thread: threading.Thread
    created_at: datetime
    result: dict[str, Any] | None = None


class PipelineSessionLimitError(Exception):
    """Raised when the configured concurrent pipeline session limit is exceeded."""

    def __init__(self, max_pipeline_sessions: int) -> None:
        self.max_pipeline_sessions = max_pipeline_sessions
        super().__init__(
            f"Pipeline session limit reached: maximum {max_pipeline_sessions} concurrent sessions"
        )


class PipelineSessionManager:
    """Manage assistant pipeline executions in daemon threads."""

    def __init__(
        self,
        max_pipeline_sessions: int,
        eviction_ttl_seconds: int,
        gateway_config: dict | None = None,
    ) -> None:
        self._sessions: dict[str, PipelineSessionRecord] = {}
        self._lock = threading.Lock()
        self._max_pipeline_sessions = int(max_pipeline_sessions)
        self._eviction_ttl_seconds = int(eviction_ttl_seconds)
        self._gateway_config = dict(gateway_config or {})
        self._terminal_marked_at: dict[str, datetime] = {}

    def create_session(
        self,
        thread_id: str,
        turn_id: str,
        pipeline_id: str,
        engine: Any,
        display_name: str | None,
        result_callback: Any,
        trigger_source: str,
    ) -> str:
        """Create and start a background pipeline execution session."""
        session_id = uuid4().hex[:12]
        cancel_event = threading.Event()
        event_bus = SessionEventBus(
            session_id=session_id,
            max_queue_size=int(self._gateway_config["max_event_queue_size"]),
        )
        thread = threading.Thread(
            target=self._run_pipeline_in_thread,
            args=(
                session_id,
                engine,
                event_bus,
                cancel_event,
                result_callback,
                trigger_source,
            ),
            name=f"assistant-pipeline-{session_id}",
            daemon=True,
        )
        record = PipelineSessionRecord(
            id=session_id,
            thread_id=thread_id,
            turn_id=turn_id,
            pipeline_id=pipeline_id,
            display_name=display_name,
            status="running",
            event_bus=event_bus,
            cancel_event=cancel_event,
            thread=thread,
            created_at=_utc_now(),
        )

        with self._lock:
            self._evict_terminal_sessions_locked()
            running = sum(1 for existing in self._sessions.values() if existing.status == "running")
            if running >= self._max_pipeline_sessions:
                raise PipelineSessionLimitError(self._max_pipeline_sessions)
            self._sessions[session_id] = record

        try:
            thread.start()
        except Exception:
            with self._lock:
                self._sessions.pop(session_id, None)
            raise
        return session_id

    def get_session(self, session_id: str) -> PipelineSessionRecord:
        """Return one tracked session or raise KeyError if not found."""
        with self._lock:
            self._evict_terminal_sessions_locked()
            record = self._sessions.get(session_id)
            if record is None:
                raise KeyError(session_id)
            return record

    def cancel_session(self, session_id: str) -> str | None:
        """Request cancellation for one tracked session.

        Returns the resulting status string (``"cancelling"``, ``"completed"``,
        ``"failed"``, etc.) or ``None`` when the session is unknown.
        """
        with self._lock:
            record = self._sessions.get(session_id)
            if record is None:
                return None
            current_status = record.status
            if current_status == "running":
                record.cancel_event.set()
        if current_status != "running":
            return current_status
        record.event_bus.push_event(
            "pipeline_cancel_requested",
            {
                "event": "pipeline_cancel_requested",
                "pipeline_id": record.pipeline_id,
                "thread_id": record.thread_id,
                "turn_id": record.turn_id,
            },
        )
        return "cancelling"

    def list_active(self, thread_id: str | None = None) -> list[dict[str, Any]]:
        """Return pipeline session summaries in authoritative newest-first order."""
        with self._lock:
            self._evict_terminal_sessions_locked()
            records = list(self._sessions.values())

        filtered = [
            record for record in records if thread_id is None or record.thread_id == thread_id
        ]
        filtered.sort(
            key=lambda record: (
                0 if record.status == "running" else 1,
                -record.created_at.timestamp(),
            )
        )
        return [
            {
                "id": record.id,
                "pipeline_id": record.pipeline_id,
                "thread_id": record.thread_id,
                "turn_id": record.turn_id,
                "display_name": record.display_name,
                "status": record.status,
                "event_count": max(record.event_bus.latest_sequence() + 1, 0),
                "created_at": record.created_at.isoformat(),
            }
            for record in filtered
        ]

    def _evict_terminal_sessions_locked(self) -> None:
        if self._eviction_ttl_seconds <= 0:
            return
        cutoff = _utc_now() - timedelta(seconds=self._eviction_ttl_seconds)
        to_remove = [
            session_id
            for session_id, marked_at in self._terminal_marked_at.items()
            if marked_at <= cutoff
        ]
        for session_id in to_remove:
            self._terminal_marked_at.pop(session_id, None)
            self._sessions.pop(session_id, None)

    def _run_pipeline_in_thread(
        self,
        session_id: str,
        engine: Any,
        event_bus: SessionEventBus,
        cancel_event: threading.Event,
        result_callback: Any,
        trigger_source: str,
    ) -> None:
        loop = asyncio.new_event_loop()
        try:
            asyncio.set_event_loop(loop)
            loop.run_until_complete(
                self._execute_pipeline_async(
                    session_id,
                    engine,
                    event_bus,
                    cancel_event,
                    result_callback,
                    trigger_source,
                )
            )
        finally:
            asyncio.set_event_loop(None)
            loop.close()

    async def _execute_pipeline_async(
        self,
        session_id: str,
        engine: Any,
        event_bus: SessionEventBus,
        cancel_event: threading.Event,
        result_callback: Any,
        trigger_source: str,
    ) -> None:
        terminal_status: Literal["completed", "failed", "cancelled"] = "completed"
        try:
            async for payload in engine.run(trigger_source=trigger_source):
                event_name = str(payload.get("event") or "pipeline_message")
                if cancel_event.is_set():
                    engine.cancel()
                if event_name == "pipeline_done":
                    if cancel_event.is_set():
                        terminal_status = "cancelled"
                        payload = {**payload, "status": "cancelled"}
                    else:
                        terminal_status = self._normalize_terminal_status(payload.get("status"))
                    persisted_turn = None
                    result = getattr(engine, "result", None)
                    if result is not None:
                        persisted_turn = result_callback(payload)
                    if persisted_turn is not None:
                        payload = {**payload, "turn": persisted_turn}
                elif event_name == "pipeline_cancelled":
                    terminal_status = "cancelled"
                event_bus.push_event(event_name, payload)
        except Exception as exc:
            terminal_status = "failed"
            event_bus.push_event(
                "pipeline_done",
                {
                    "event": "pipeline_done",
                    "pipeline_id": getattr(getattr(engine, "pipeline_def", None), "pipeline_id", ""),
                    "status": "failed",
                    "detail": str(exc),
                    "proposal_count": 0,
                },
            )
        finally:
            with self._lock:
                record = self._sessions.get(session_id)
                if record is not None:
                    record.status = terminal_status
                    result = getattr(engine, "result", None)
                    if result is not None:
                        record.result = self._serialize_result(result)
                    self._terminal_marked_at[session_id] = _utc_now()
            event_bus.close()

    def _normalize_terminal_status(
        self,
        value: Any,
    ) -> Literal["completed", "failed", "cancelled"]:
        status = str(value or "").strip().lower()
        if status == "failed":
            return "failed"
        if status == "cancelled":
            return "cancelled"
        return "completed"

    def _serialize_result(self, result: Any) -> dict[str, Any] | None:
        if result is None:
            return None
        if is_dataclass(result):
            return asdict(result)
        if isinstance(result, dict):
            return dict(result)
        return {"value": result}
