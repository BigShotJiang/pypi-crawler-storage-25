"""Persisted onboarding state for desktop provider setup."""

from __future__ import annotations

import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from obra.utils.obra_home import resolve_runtime_dir


class OnboardingState:
    """Manages onboarding state persisted to disk.

    State file: ``${OBRA_RUNTIME_DIR:-~/.obra-runtime}/desktop/onboarding.json``
    """

    def __init__(self) -> None:
        runtime = resolve_runtime_dir()
        self._state_dir = runtime.path / "desktop"
        self._state_file = self._state_dir / "onboarding.json"
        self._lock = threading.Lock()
        self._state: dict[str, Any] = self.load()

    def load(self) -> dict[str, Any]:
        """Load state from disk. Returns empty state if file is missing."""
        try:
            data = self._state_file.read_text(encoding="utf-8")
            return json.loads(data)
        except (FileNotFoundError, json.JSONDecodeError):
            return {
                "completed": False,
                "completed_at": None,
                "providers": {},
            }

    def save(self) -> None:
        """Write state to disk. Creates directory with mode 0700 if needed."""
        self._state_dir.mkdir(parents=True, exist_ok=True)
        os.chmod(str(self._state_dir), 0o700)
        self._state_file.write_text(
            json.dumps(self._state, indent=2),
            encoding="utf-8",
        )

    def mark_provider_installed(self, provider_id: str) -> None:
        """Record that a provider binary has been detected."""
        with self._lock:
            providers = self._state.setdefault("providers", {})
            entry = providers.setdefault(provider_id, {})
            if not entry.get("installed_at"):
                entry["installed_at"] = _now_iso()
            self.save()

    def mark_provider_authenticated(self, provider_id: str) -> None:
        """Record that a provider has been authenticated."""
        with self._lock:
            providers = self._state.setdefault("providers", {})
            entry = providers.setdefault(provider_id, {})
            entry["authenticated_at"] = _now_iso()
            self.save()

    def mark_completed(self) -> None:
        """Mark onboarding as complete."""
        with self._lock:
            self._state["completed"] = True
            self._state["completed_at"] = _now_iso()
            self.save()

    def is_completed(self) -> bool:
        """Check if onboarding has been completed."""
        return bool(self._state.get("completed", False))

    def get_provider_state(self, provider_id: str) -> dict[str, Any]:
        """Get persisted state for a provider."""
        return self._state.get("providers", {}).get(provider_id, {})

    def as_dict(self) -> dict[str, Any]:
        """Return a copy of the full state dict."""
        return dict(self._state)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
