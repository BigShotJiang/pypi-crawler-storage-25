"""Config-driven provider registry for desktop onboarding."""

from __future__ import annotations

import importlib
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass(frozen=True)
class ProviderEntry:
    """A registered LLM provider with detection and auth handlers."""

    provider_id: str
    display_name: str
    binary_name: str
    auth_method: str  # "oauth_cli", "api_key", or "none"
    install_url: str
    install_command: str | None
    detection_handler: str  # dotted path to detection function
    auth_handler: str  # dotted path to auth/authenticate function
    check_handler: str | None = None  # dotted path to auth-check function


class ProviderRegistry:
    """Registry of available LLM providers, loaded from config."""

    def __init__(self, providers_config: list[dict[str, Any]] | None = None) -> None:
        self._providers: dict[str, ProviderEntry] = {}
        if providers_config:
            for entry in providers_config:
                provider = ProviderEntry(
                    provider_id=str(entry["provider_id"]),
                    display_name=str(entry["display_name"]),
                    binary_name=str(entry["binary_name"]),
                    auth_method=str(entry["auth_method"]),
                    install_url=str(entry["install_url"]),
                    install_command=entry.get("install_command"),
                    detection_handler=str(entry["detection_handler"]),
                    auth_handler=str(entry["auth_handler"]),
                    check_handler=entry.get("check_handler"),
                )
                self._providers[provider.provider_id] = provider

    def get(self, provider_id: str) -> ProviderEntry | None:
        """Get a provider by ID."""
        return self._providers.get(provider_id)

    def list_providers(self) -> list[ProviderEntry]:
        """List all registered providers."""
        return list(self._providers.values())

    def resolve_detection_handler(self, provider_id: str) -> Callable[..., dict]:
        """Resolve and return the detection handler function."""
        provider = self._providers.get(provider_id)
        if not provider:
            raise KeyError(f"Unknown provider: {provider_id}")
        return _import_handler(provider.detection_handler)

    def resolve_auth_handler(self, provider_id: str) -> Callable[..., dict]:
        """Resolve and return the auth handler function."""
        provider = self._providers.get(provider_id)
        if not provider:
            raise KeyError(f"Unknown provider: {provider_id}")
        return _import_handler(provider.auth_handler)

    def resolve_check_handler(self, provider_id: str) -> Callable[..., dict]:
        """Resolve and return the auth-check handler function.

        Uses the ``check_handler`` dotted path if configured; otherwise
        falls back to the legacy convention of importing
        ``check_{provider_id}_auth`` from the auth_handler's module.
        """
        provider = self._providers.get(provider_id)
        if not provider:
            raise KeyError(f"Unknown provider: {provider_id}")
        if provider.check_handler:
            return _import_handler(provider.check_handler)
        # Legacy fallback: construct name from provider_id.
        module_path = provider.auth_handler.rsplit(".", 1)[0]
        import importlib as _imp

        mod = _imp.import_module(module_path)
        fn = getattr(mod, f"check_{provider_id}_auth", None)
        if fn and callable(fn):
            return fn
        raise ImportError(
            f"No check_handler configured and check_{provider_id}_auth "
            f"not found in {module_path}"
        )


def _import_handler(dotted_path: str) -> Callable[..., dict]:
    """Import a handler function from a dotted module path."""
    module_path, _, func_name = dotted_path.rpartition(".")
    if not module_path:
        raise ImportError(f"Invalid handler path: {dotted_path}")
    module = importlib.import_module(module_path)
    handler = getattr(module, func_name)
    if not callable(handler):
        raise TypeError(f"{dotted_path} is not callable")
    return handler
