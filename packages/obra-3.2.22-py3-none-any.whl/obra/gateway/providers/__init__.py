"""Provider registry for desktop onboarding."""

from __future__ import annotations

from obra.gateway.providers.registry import ProviderRegistry

__all__ = ["ProviderRegistry"]
