"""Registry for assistant action pipelines."""

from __future__ import annotations

from obra.gateway.assistant.pipelines.types import PipelineDefinition

_PIPELINES: dict[str, PipelineDefinition] = {}


def register_pipeline(definition: PipelineDefinition) -> None:
    """Register one pipeline definition."""
    if definition.pipeline_id in _PIPELINES:
        raise ValueError(f"Pipeline already registered: {definition.pipeline_id}")
    _PIPELINES[definition.pipeline_id] = definition


def get_pipeline(pipeline_id: str) -> PipelineDefinition | None:
    """Look up one registered pipeline."""
    return _PIPELINES.get(pipeline_id)


def list_pipelines() -> list[PipelineDefinition]:
    """Return all registered pipelines."""
    return list(_PIPELINES.values())


def clear_pipelines() -> None:
    """Test helper to reset the in-memory registry."""
    _PIPELINES.clear()
