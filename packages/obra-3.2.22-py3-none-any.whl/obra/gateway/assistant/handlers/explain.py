"""Explain action handlers — read-only workflow/stage introspection."""

from __future__ import annotations

from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext


def explain_workflow(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Return a structured explanation of the workflow."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    defn = workflow.get("workflow_definition", {})
    stages = defn.get("stages", [])

    stage_summaries = []
    for s in stages:
        stage_summaries.append(
            {
                "stage_id": s.get("stage_id", ""),
                "title": s.get("title", ""),
                "category": s.get("category", ""),
                "runner_id": s.get("runner_id", ""),
                "has_quality_loop": bool(s.get("quality_loop")),
                "dependency_count": len(s.get("depends_on", [])),
            }
        )

    connections: list[str] = []
    for s in stages:
        for dep in s.get("depends_on", []):
            connections.append(f"{dep} -> {s.get('stage_id', '')}")

    return {
        "outcome": "applied",
        "workflow_id": wf_id,
        "title": workflow.get("title", ""),
        "description": workflow.get("description", ""),
        "domain_id": workflow.get("domain_id", ""),
        "stage_count": len(stages),
        "stage_summaries": stage_summaries,
        "connection_summary": "; ".join(connections) if connections else "No connections",
    }


def explain_stage(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Return a structured explanation of a single stage."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    stage_id = inputs.get("stage_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    defn = workflow.get("workflow_definition", {})
    stages = defn.get("stages", [])
    stage_map = {s.get("stage_id", ""): s for s in stages}

    target = stage_map.get(stage_id)
    if target is None:
        return {"outcome": "invalid", "detail": f"Stage not found: {stage_id}"}

    # Compute dependencies and dependents
    dependencies = [
        stage_map[d].get("title", d) for d in target.get("depends_on", []) if d in stage_map
    ]
    dependents = [
        s.get("title", s.get("stage_id", "")) for s in stages if stage_id in s.get("depends_on", [])
    ]

    # Quality loop summary
    ql = target.get("quality_loop")
    quality_loop_summary = None
    if ql:
        quality_loop_summary = {
            "entry_conditions": ql.get("entry_conditions", {}),
            "thresholds": ql.get("thresholds", {}),
            "outcome_routing": ql.get("outcome_routing", {}),
        }

    # Position
    position = next(
        (i for i, s in enumerate(stages) if s.get("stage_id") == stage_id),
        None,
    )

    return {
        "outcome": "applied",
        "stage_id": stage_id,
        "title": target.get("title", ""),
        "category": target.get("category", ""),
        "runner_id": target.get("runner_id", ""),
        "runner_kind": target.get("runner_kind"),
        "template_bindings": [
            {"role": b.get("role", ""), "asset_id": b.get("asset_id", "")}
            for b in target.get("template_bindings", [])
        ],
        "quality_loop": quality_loop_summary,
        "dependencies": dependencies,
        "dependents": dependents,
        "position_in_sequence": position,
    }
