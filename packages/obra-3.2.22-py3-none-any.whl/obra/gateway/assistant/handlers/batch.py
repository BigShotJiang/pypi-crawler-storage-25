"""Atomic batch workflow mutation handlers for the studio assistant."""

from __future__ import annotations

import copy
from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.assistant.handlers.metadata import apply_metadata_updates_to_candidate
from obra.gateway.assistant.handlers.quality_gate import (
    apply_quality_gate_to_candidate,
    build_quality_loop_payload,
)
from obra.gateway.assistant.handlers.structural import (
    apply_stage_update_to_candidate,
    connect_stages_in_candidate,
    disconnect_stages_in_candidate,
    insert_stage_into_candidate,
    remove_stage_from_candidate,
)
from obra.gateway.assistant.handlers.template_edit import _apply_template_to_candidate
from obra.gateway.assistant.proposal_records import build_proposal_record

_SUPPORTED_OPERATIONS = {
    "insert_stage",
    "remove_stage",
    "connect",
    "disconnect",
    "update_stage",
    "update_workflow_metadata",
    "set_quality_gate",
    "edit_template",
}


def _apply_operation(candidate: dict[str, Any], operation: dict[str, Any]) -> dict[str, Any]:
    operation_name = str(operation.get("operation") or operation.get("op") or "").strip()
    if not operation_name:
        raise ValueError("Batch operations must declare operation.")
    if operation_name not in _SUPPORTED_OPERATIONS:
        raise ValueError(f"Unsupported batch operation: {operation_name}")

    if operation_name == "insert_stage":
        stage_definition = operation.get("stage_definition")
        if not isinstance(stage_definition, dict) or not stage_definition:
            raise ValueError("insert_stage requires stage_definition.")
        insert_stage_into_candidate(
            candidate,
            after_stage_id=operation.get("after_stage_id"),
            stage_definition=stage_definition,
        )
        return {"operation": operation_name, "stage_definition": stage_definition}

    if operation_name == "remove_stage":
        stage_id = str(operation.get("stage_id") or "").strip()
        if not stage_id:
            raise ValueError("remove_stage requires stage_id.")
        remove_stage_from_candidate(candidate, stage_id)
        return {"operation": operation_name, "stage_id": stage_id}

    if operation_name == "connect":
        source_stage_id = str(operation.get("source_stage_id") or "").strip()
        target_stage_id = str(operation.get("target_stage_id") or "").strip()
        if not source_stage_id or not target_stage_id:
            raise ValueError("connect requires source_stage_id and target_stage_id.")
        connect_stages_in_candidate(candidate, source_stage_id, target_stage_id)
        return {
            "operation": operation_name,
            "source_stage_id": source_stage_id,
            "target_stage_id": target_stage_id,
        }

    if operation_name == "disconnect":
        source_stage_id = str(operation.get("source_stage_id") or "").strip()
        target_stage_id = str(operation.get("target_stage_id") or "").strip()
        if not source_stage_id or not target_stage_id:
            raise ValueError("disconnect requires source_stage_id and target_stage_id.")
        disconnect_stages_in_candidate(candidate, source_stage_id, target_stage_id)
        return {
            "operation": operation_name,
            "source_stage_id": source_stage_id,
            "target_stage_id": target_stage_id,
        }

    if operation_name == "update_stage":
        stage_id = str(operation.get("stage_id") or "").strip()
        updates = operation.get("updates")
        if not stage_id or not isinstance(updates, dict):
            raise ValueError("update_stage requires stage_id and updates.")
        apply_stage_update_to_candidate(candidate, stage_id, updates)
        return {"operation": operation_name, "stage_id": stage_id, "updates": dict(updates)}

    if operation_name == "update_workflow_metadata":
        updates = operation.get("updates")
        if not isinstance(updates, dict):
            raise ValueError("update_workflow_metadata requires updates.")
        normalized_updates = apply_metadata_updates_to_candidate(candidate, updates)
        return {"operation": operation_name, "updates": normalized_updates}

    if operation_name == "edit_template":
        stage_id = str(operation.get("stage_id") or "").strip()
        template_role = str(operation.get("template_role") or "purpose").strip() or "purpose"
        proposed_content = str(operation.get("proposed_content") or "").strip()
        if not stage_id or not proposed_content:
            raise ValueError("edit_template requires stage_id and proposed_content.")
        _apply_template_to_candidate(candidate, stage_id, template_role, proposed_content)
        return {
            "operation": operation_name,
            "stage_id": stage_id,
            "template_role": template_role,
            "proposed_content": proposed_content,
        }

    stage_id = str(operation.get("stage_id") or "").strip()
    if not stage_id:
        raise ValueError("set_quality_gate requires stage_id.")
    quality_loop = operation.get("quality_loop")
    if not isinstance(quality_loop, dict):
        quality_loop = build_quality_loop_payload(
            candidate,
            stage_id=stage_id,
            loop_back_to=str(operation.get("loop_back_to") or "").strip() or None,
            evaluators=operation.get("evaluators"),
            thresholds=operation.get("thresholds"),
        )
    apply_quality_gate_to_candidate(candidate, stage_id, quality_loop)
    return {"operation": operation_name, "stage_id": stage_id, "quality_loop": quality_loop}


def _simulate_batch(
    workflow: dict[str, Any], operations: list[dict[str, Any]]
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    candidate = copy.deepcopy(workflow)
    normalized_operations: list[dict[str, Any]] = []
    for operation in operations:
        if not isinstance(operation, dict):
            raise ValueError("Batch operations must be objects.")
        normalized_operations.append(_apply_operation(candidate, operation))
    return candidate, normalized_operations


def propose_batch(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose one atomic batch of workflow mutations."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    operations = inputs.get("operations")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}
    if not isinstance(operations, list) or not operations:
        return {"outcome": "invalid", "detail": "Batch mutation requires at least one operation."}

    try:
        _, normalized_operations = _simulate_batch(workflow, operations)
    except ValueError as exc:
        return {"outcome": "invalid", "detail": str(exc)}

    return build_proposal_record(
        action_id="execute_batch_mutation",
        action_type="propose_batch_mutation",
        action_inputs={
            "workflow_id": wf_id,
            "operations": normalized_operations,
            "expected_revision_id": inputs.get("expected_revision_id", ""),
        },
        preview_type="diff",
        outcome="proposal",
        workflow_id=wf_id,
        operations=normalized_operations,
        operation_count=len(normalized_operations),
    )


def execute_batch(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply one atomic batch of workflow mutations."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    operations = inputs.get("operations")
    expected_revision_id = str(inputs.get("expected_revision_id") or "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}
    if not isinstance(operations, list) or not operations:
        return {"outcome": "invalid", "detail": "Batch mutation requires at least one operation."}

    try:
        candidate, _ = _simulate_batch(workflow, operations)
    except ValueError as exc:
        return {"outcome": "invalid", "detail": str(exc)}

    result = ctx.action_service.apply_workflow(
        wf_id,
        candidate,
        expected_revision_id=expected_revision_id,
    )
    outcome = result.get("outcome", "")
    if outcome == "conflict":
        return {
            "outcome": "conflict",
            "conflict_summary": result.get("conflict_summary", {}),
            "workflow_id": wf_id,
        }
    if outcome == "invalid":
        return {
            "outcome": "invalid",
            "validation_summary": result.get("validation_summary", {}),
            "workflow_id": wf_id,
        }
    return {
        "outcome": "applied",
        "resulting_revision_ref": result.get("resulting_revision_ref"),
        "workflow_id": wf_id,
    }
