"""Draft workflow handler — create a new workflow from a conversation scaffold."""

from __future__ import annotations

from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.assistant.proposal_records import build_proposal_record


def propose_draft(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose creating a new workflow from an LLM-generated scaffold definition."""
    scaffold_definition: dict[str, Any] = inputs.get("scaffold_definition", {})

    stages = scaffold_definition.get("stages", [])
    if not stages:
        return {"outcome": "invalid", "detail": "scaffold_definition must have at least one stage"}

    title = scaffold_definition.get("title", "")
    if not title:
        return {"outcome": "invalid", "detail": "scaffold_definition must have a title"}

    connections = sum(len(s.get("depends_on", [])) for s in stages)
    action_inputs = {
        "scaffold_definition": scaffold_definition,
        "domain_id": inputs.get("domain_id", scaffold_definition.get("domain_id", "")),
    }

    return build_proposal_record(
        action_id="execute_draft_workflow_from_thread",
        action_type="draft_workflow_from_thread",
        action_inputs=action_inputs,
        preview_type="scaffold",
        outcome="proposal",
        scaffold_definition=scaffold_definition,
        stage_count=len(stages),
        connection_count=connections,
    )


def execute_draft(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Execute: create a new workflow from the accepted scaffold definition."""
    scaffold_definition: dict[str, Any] = inputs.get("scaffold_definition", {})
    domain_id: str = inputs.get("domain_id", scaffold_definition.get("domain_id", ""))

    payload: dict[str, Any] = {
        "title": scaffold_definition.get("title", ""),
        "domain_id": domain_id,
        "workflow_definition": scaffold_definition,
    }

    result = ctx.action_service.create_workflow(payload)

    # Extract workflow_id and revision ref from CF response.
    # CF returns: { "workflow": { "workflow_id": ... }, "resulting_revision_ref": { "revision_id": ... } }
    workflow_data = result.get("workflow", {})
    new_workflow_id = workflow_data.get("workflow_id", "")
    revision_ref = result.get("resulting_revision_ref", {})

    return {
        "outcome": "applied",
        "workflow_id": new_workflow_id,
        "resulting_revision_ref": revision_ref,
    }
