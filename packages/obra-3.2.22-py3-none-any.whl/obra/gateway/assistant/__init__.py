# obra.gateway.assistant — Action broker and guided-actions subsystem (Phase B).
