"""Action audit record storage (TR-3.5).

In-memory implementation matching Phase A's AssistantRepository pattern.
Interface designed for future Firestore-backed swap without caller changes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from uuid import uuid4


@dataclass
class ActionAuditRecord:
    """Immutable audit trail entry for a single action execution."""

    audit_id: str
    thread_id: str
    turn_id: str
    action_id: str
    initiated_by: str
    safety_mode: str
    action_inputs: dict
    outcome: str
    resulting_revision_ref: str | None = None
    base_revision_ref: str | None = None
    workflow_id: str | None = None
    error_detail: str | None = None
    timestamp: str = ""
    correlation: dict = field(default_factory=dict)


class ActionAuditStore:
    """In-memory audit store.

    The interface (``record`` / ``list_by_thread``) is stable; a
    Firestore-backed implementation can be substituted without changing
    callers.
    """

    def __init__(self) -> None:
        self._records: dict[str, ActionAuditRecord] = {}

    def record(self, audit: ActionAuditRecord) -> None:
        """Persist an audit record."""
        self._records[audit.audit_id] = audit

    def get(self, audit_id: str) -> ActionAuditRecord | None:
        """Return one audit record by identifier."""
        return self._records.get(audit_id)

    def list_by_thread(self, thread_id: str) -> list[ActionAuditRecord]:
        """Return audit records for *thread_id*, ordered by timestamp."""
        return sorted(
            (r for r in self._records.values() if r.thread_id == thread_id),
            key=lambda r: r.timestamp,
        )


def generate_audit_id() -> str:
    """Generate a unique audit identifier."""
    return str(uuid4())
