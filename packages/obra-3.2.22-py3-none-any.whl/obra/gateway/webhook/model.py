"""Webhook registration models and validation helpers."""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import StrEnum
from typing import Any
from urllib.parse import urlsplit


class WebhookStatus(StrEnum):
    """Lifecycle state for one webhook registration."""

    ACTIVE = "active"
    FAILING = "failing"
    DISABLED = "disabled"
    EXPIRED = "expired"


@dataclass(slots=True)
class DeliveryRecord:
    """Result metadata for one outbound webhook delivery."""

    timestamp: str
    status_code: int | None
    duration_ms: float
    success: bool
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "status_code": self.status_code,
            "duration_ms": self.duration_ms,
            "success": self.success,
            "error": self.error,
        }


@dataclass(slots=True)
class WebhookRegistration:
    """Stored webhook registration state."""

    webhook_id: str
    owner_key: str
    callback_url: str
    resource_type: str
    resource_id: str
    events: list[str]
    secret: str
    status: WebhookStatus = WebhookStatus.ACTIVE
    created_at: str = field(default_factory=lambda: datetime.now(tz=timezone.utc).isoformat())
    expired_at: str | None = None
    consecutive_failures: int = 0
    last_delivery_at: str | None = None
    last_failure_reason: str | None = None
    delivery_history: list[DeliveryRecord] = field(default_factory=list)

    def to_summary_dict(self) -> dict[str, Any]:
        return {
            "webhook_id": self.webhook_id,
            "status": self.status.value,
            "callback_url": self.callback_url,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "events": list(self.events),
            "created_at": self.created_at,
            "expired_at": self.expired_at,
            "consecutive_failures": self.consecutive_failures,
            "last_delivery_at": self.last_delivery_at,
            "last_failure_reason": self.last_failure_reason,
        }

    def to_detail_dict(self) -> dict[str, Any]:
        return {
            **self.to_summary_dict(),
            "delivery_history": [record.to_dict() for record in self.delivery_history],
        }


def validate_callback_url(url: str) -> None:
    """Validate callback URL against the gateway webhook policy."""
    parsed = urlsplit(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("Callback URL must use http or https")
    if not parsed.netloc or not parsed.hostname:
        raise ValueError("Callback URL must include a host")
    if parsed.username or parsed.password:
        raise ValueError("Callback URL must not embed credentials")

    hostname = parsed.hostname.strip().lower()
    is_loopback = hostname == "localhost"
    try:
        ip_address = ipaddress.ip_address(hostname)
        is_loopback = ip_address.is_loopback
        if not ip_address.is_loopback and ip_address.is_private:
            raise ValueError("Callback URL must not target a private IP address")
    except ValueError as exc:
        if hostname != "localhost":
            if str(exc) == "Callback URL must not target a private IP address":
                raise
    if parsed.scheme != "https" and not is_loopback:
        raise ValueError("Callback URL must use https unless targeting localhost or loopback")


def validate_secret(secret: str) -> None:
    """Validate the webhook HMAC secret."""
    if len(secret) < 16:
        raise ValueError("Webhook secret must be at least 16 characters")
