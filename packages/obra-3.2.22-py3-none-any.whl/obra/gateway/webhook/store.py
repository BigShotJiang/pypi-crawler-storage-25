"""Webhook storage abstractions."""

from __future__ import annotations

from copy import deepcopy
from threading import Lock
from typing import Protocol

from obra.gateway.webhook.model import WebhookRegistration, WebhookStatus


class WebhookStore(Protocol):
    """Storage contract for webhook registrations."""

    def add(self, registration: WebhookRegistration) -> None: ...

    def get(self, webhook_id: str) -> WebhookRegistration | None: ...

    def list_all(self, *, include_expired: bool = False) -> list[WebhookRegistration]: ...

    def list_for_owner(
        self,
        owner_key: str,
        *,
        include_expired: bool = False,
    ) -> list[WebhookRegistration]: ...

    def list_for_resource(self, resource_type: str, resource_id: str) -> list[WebhookRegistration]: ...

    def delete(self, webhook_id: str) -> bool: ...

    def update(self, registration: WebhookRegistration) -> None: ...

    def count_for_owner(self, owner_key: str) -> int: ...


class InMemoryWebhookStore:
    """Thread-safe in-memory webhook registration store."""

    def __init__(self) -> None:
        self._registrations: dict[str, WebhookRegistration] = {}
        self._lock = Lock()

    def add(self, registration: WebhookRegistration) -> None:
        with self._lock:
            self._registrations[registration.webhook_id] = deepcopy(registration)

    def get(self, webhook_id: str) -> WebhookRegistration | None:
        with self._lock:
            registration = self._registrations.get(webhook_id)
            return deepcopy(registration) if registration is not None else None

    def list_all(self, *, include_expired: bool = False) -> list[WebhookRegistration]:
        with self._lock:
            registrations = list(self._registrations.values())
        if not include_expired:
            registrations = [
                registration
                for registration in registrations
                if registration.status is not WebhookStatus.EXPIRED
            ]
        return [deepcopy(registration) for registration in registrations]

    def list_for_owner(
        self,
        owner_key: str,
        *,
        include_expired: bool = False,
    ) -> list[WebhookRegistration]:
        registrations = [
            registration
            for registration in self.list_all(include_expired=include_expired)
            if registration.owner_key == owner_key
        ]
        return [deepcopy(registration) for registration in registrations]

    def list_for_resource(self, resource_type: str, resource_id: str) -> list[WebhookRegistration]:
        with self._lock:
            registrations = list(self._registrations.values())
        matches = [
            registration
            for registration in registrations
            if registration.resource_type == resource_type
            and registration.resource_id == resource_id
            and registration.status in {WebhookStatus.ACTIVE, WebhookStatus.FAILING}
        ]
        return [deepcopy(registration) for registration in matches]

    def delete(self, webhook_id: str) -> bool:
        with self._lock:
            if webhook_id not in self._registrations:
                return False
            del self._registrations[webhook_id]
            return True

    def update(self, registration: WebhookRegistration) -> None:
        with self._lock:
            self._registrations[registration.webhook_id] = deepcopy(registration)

    def count_for_owner(self, owner_key: str) -> int:
        with self._lock:
            return sum(1 for registration in self._registrations.values() if registration.owner_key == owner_key)
