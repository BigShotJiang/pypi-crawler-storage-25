"""Webhook outbound delivery service."""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone
from time import perf_counter
from typing import Any

import httpx

from obra.gateway.webhook.model import DeliveryRecord, WebhookRegistration
from obra.gateway.webhook.signing import sign_payload

logger = logging.getLogger(__name__)


class WebhookDeliveryService:
    """Deliver webhook payloads to registered callback URLs."""

    def __init__(
        self,
        *,
        timeout_s: float,
        retry_backoff_schedule_s: tuple[float, ...],
    ) -> None:
        self.timeout_s = timeout_s
        self.retry_backoff_schedule_s = retry_backoff_schedule_s

    async def deliver(
        self,
        registration: WebhookRegistration,
        envelope: dict[str, Any],
    ) -> DeliveryRecord:
        """Send one webhook delivery attempt."""
        payload_bytes = json.dumps(envelope).encode("utf-8")
        signature = sign_payload(payload_bytes, registration.secret)
        started = perf_counter()
        timestamp = datetime.now(tz=timezone.utc).isoformat()
        try:
            async with httpx.AsyncClient(timeout=self.timeout_s) as client:
                response = await client.post(
                    registration.callback_url,
                    content=payload_bytes,
                    headers={
                        "Content-Type": "application/json",
                        "X-Obra-Signature": signature,
                        "X-Obra-Event": str(envelope["event_name"]),
                        "X-Obra-Webhook-ID": registration.webhook_id,
                    },
                )
        except Exception as exc:
            logger.info(
                "Webhook delivery failed callback_url=%s webhook_id=%s error=%s",
                registration.callback_url,
                registration.webhook_id,
                type(exc).__name__,
            )
            return DeliveryRecord(
                timestamp=timestamp,
                status_code=None,
                duration_ms=(perf_counter() - started) * 1000,
                success=False,
                error=str(exc),
            )

        success = 200 <= response.status_code < 300
        if not success:
            logger.info(
                "Webhook delivery non-2xx callback_url=%s webhook_id=%s status_code=%s",
                registration.callback_url,
                registration.webhook_id,
                response.status_code,
            )
        return DeliveryRecord(
            timestamp=timestamp,
            status_code=response.status_code,
            duration_ms=(perf_counter() - started) * 1000,
            success=success,
            error=None if success else f"HTTP {response.status_code}",
        )

    async def deliver_with_retry(
        self,
        registration: WebhookRegistration,
        envelope: dict[str, Any],
    ) -> DeliveryRecord:
        """Deliver with the configured retry schedule and return the last result."""
        last_result = await self.deliver(registration, envelope)
        if last_result.success:
            return last_result
        for delay_s in self.retry_backoff_schedule_s:
            await asyncio.sleep(delay_s)
            last_result = await self.deliver(registration, envelope)
            if last_result.success:
                return last_result
        return last_result
