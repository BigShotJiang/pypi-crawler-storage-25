"""Canonical Workflow Studio artifact inspection routes."""

from __future__ import annotations

import json

from fastapi import APIRouter, Query, Request, status

from obra.gateway.error_codes import ARTIFACT_CONTENT_NOT_FOUND, ARTIFACT_NOT_FOUND
from obra.gateway.errors import GatewayAPIError
from obra.gateway.pagination import paginate_collection, pagination_params_from_request
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository

router = APIRouter(prefix="/api/artifacts", tags=["workflow-studio"])


def _detect_content_type(content: str) -> str:
    """Infer a stable content type for workspace-backed artifact text."""
    try:
        parsed = json.loads(content)
    except json.JSONDecodeError:
        parsed = None
    if isinstance(parsed, dict | list):
        return "application/json"
    if content.lstrip().startswith("# ") or "\n## " in content or "\n- " in content:
        return "text/markdown"
    return "text/plain"


@router.get("/")
async def list_artifacts(
    request: Request,
    run_id: str | None = Query(default=None),
    stage_name: str | None = Query(default=None),
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    return paginate_collection(
        collection_key="artifacts",
        items=repository.list_artifacts(run_id=run_id, stage_name=stage_name),
        params=pagination_params_from_request(request),
    )


@router.get("/{artifact_id}")
async def get_artifact(artifact_id: str, request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    artifact = repository.get_artifact(artifact_id)
    if artifact is None:
        raise GatewayAPIError(
            error_code=ARTIFACT_NOT_FOUND,
            message="Artifact not found",
            status_code=status.HTTP_404_NOT_FOUND,
        )
    return {"artifact": artifact}


@router.get("/{artifact_id}/content")
async def get_artifact_content(
    artifact_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    content = repository.get_artifact_content(artifact_id)
    if content is None:
        raise GatewayAPIError(
            error_code=ARTIFACT_CONTENT_NOT_FOUND,
            message="Artifact content not found",
            status_code=status.HTTP_404_NOT_FOUND,
        )
    return {
        "artifact_id": artifact_id,
        "content": content,
        "content_type": _detect_content_type(content),
    }


@router.get("/{artifact_id}/references")
async def get_artifact_references(
    artifact_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    payload = repository.get_artifact_references(artifact_id)
    if payload is None:
        raise GatewayAPIError(
            error_code=ARTIFACT_NOT_FOUND,
            message="Artifact not found",
            status_code=status.HTTP_404_NOT_FOUND,
        )
    return payload


@router.get("/{artifact_id}/provenance")
async def get_artifact_provenance(
    artifact_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    payload = repository.get_artifact_provenance(artifact_id)
    if payload is None:
        raise GatewayAPIError(
            error_code=ARTIFACT_NOT_FOUND,
            message="Artifact not found",
            status_code=status.HTTP_404_NOT_FOUND,
        )
    return payload
