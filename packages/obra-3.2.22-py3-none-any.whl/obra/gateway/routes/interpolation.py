"""Runner-config interpolation validation routes."""

from __future__ import annotations

import re
from typing import Any

from fastapi import APIRouter, Query, Request
from pydantic import BaseModel, Field

router = APIRouter(prefix="/api/interpolation", tags=["authoring"])

_INTERPOLATION_PATTERN = re.compile(r"\$\{([^}]+)\}")
_VALID_NAMESPACES = {"stage_input", "workflow", "stage", "secrets"}


class ValidateInterpolationRequest(BaseModel):
    """Interpolation validation request."""

    expression: str = Field(..., max_length=1000)
    context_hint: dict[str, Any] | None = Field(default=None)


@router.post("/validate")
async def validate_interpolation(
    body: ValidateInterpolationRequest,
    request: Request,
    resolve: bool = Query(default=False),
) -> dict[str, Any]:
    """Validate interpolation syntax, namespace usage, and optional stage resolution."""
    del request
    matches = _INTERPOLATION_PATTERN.findall(body.expression)
    if not matches:
        return _result(valid=False, error="No interpolation expression found")

    available_stages = []
    if resolve and isinstance(body.context_hint, dict):
        raw_stages = body.context_hint.get("available_stages")
        if isinstance(raw_stages, list):
            available_stages = [str(stage) for stage in raw_stages if str(stage).strip()]

    first_namespace: str | None = None
    first_path: str | None = None
    for match in matches:
        parts = match.split(".")
        namespace = parts[0]
        path = ".".join(parts[1:]) or None
        if first_namespace is None:
            first_namespace = namespace
            first_path = path

        if namespace not in _VALID_NAMESPACES:
            return _result(
                valid=False,
                error=f"Unknown namespace: {namespace}",
                resolved_namespace=namespace,
                resolved_path=path,
            )
        if namespace in {"stage_input", "workflow"} and len(parts) < 2:
            return _result(
                valid=False,
                error=f"Namespace '{namespace}' requires a path",
                resolved_namespace=namespace,
            )
        if namespace == "secrets" and len(parts) != 2:
            return _result(
                valid=False,
                error="Namespace 'secrets' expects exactly one key",
                resolved_namespace=namespace,
                resolved_path=path,
            )
        if namespace == "stage":
            if len(parts) < 4 or parts[2] != "output":
                suggestion = None
                if len(parts) >= 2 and parts[1] == "output":
                    suggestion = "Missing stage name. Use ${stage.<stage_name>.output.exit_code}"
                return _result(
                    valid=False,
                    error="Stage references must use ${stage.<stage_name>.output.<path>}",
                    resolved_namespace=namespace,
                    resolved_path=path,
                    suggestion=suggestion,
                )
            if resolve and available_stages and parts[1] not in available_stages:
                return _result(
                    valid=False,
                    error=f"Unknown stage name: {parts[1]}",
                    resolved_namespace=namespace,
                    resolved_path=".".join(parts[1:]),
                )

    return _result(
        valid=True,
        resolved_namespace=first_namespace,
        resolved_path=first_path,
    )


def _result(
    *,
    valid: bool,
    error: str | None = None,
    resolved_namespace: str | None = None,
    resolved_path: str | None = None,
    suggestion: str | None = None,
) -> dict[str, Any]:
    return {
        "valid": valid,
        "error": error,
        "resolved_namespace": resolved_namespace,
        "resolved_path": resolved_path,
        "suggestion": suggestion,
    }
