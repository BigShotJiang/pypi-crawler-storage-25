"""Gateway API discovery routes."""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from fastapi import APIRouter, Request
from fastapi.routing import APIRoute

from obra.gateway import __version__

router = APIRouter(tags=["discovery"])


@router.get("/api")
async def get_capabilities(request: Request) -> dict[str, Any]:
    """Return a lightweight capabilities manifest built from registered routes."""
    grouped: dict[str, list[APIRoute]] = defaultdict(list)
    for route in request.app.routes:
        if not isinstance(route, APIRoute):
            continue
        if not route.path.startswith("/api"):
            continue
        segment = _route_group_name(route.path)
        grouped[segment].append(route)

    route_groups: list[dict[str, Any]] = []
    for group_name in sorted(grouped):
        routes = grouped[group_name]
        base_path = "/api" if group_name == "root" else f"/api/{group_name}"
        description = next(
            (
                str(route.summary or route.name).replace("_", " ")
                for route in routes
                if route.summary or route.name
            ),
            f"Routes under {base_path}",
        )
        route_groups.append(
            {
                "name": group_name,
                "description": description,
                "base_path": base_path,
                "route_count": len(routes),
            }
        )

    return {
        "version": __version__,
        "route_groups": route_groups,
        "_links": {
            "self": "/api",
            "domains": "/api/domains",
            "runners_kinds": "/api/runners/kinds",
            "sessions": "/api/sessions",
        },
    }


def _route_group_name(path: str) -> str:
    segments = [segment for segment in path.split("/") if segment]
    if len(segments) <= 1:
        return "root"
    return segments[1]
