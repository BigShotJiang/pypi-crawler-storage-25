"""Gateway callback inspection routes over persisted stage metadata."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, status

from obra.gateway.pagination import paginate_collection, pagination_params_from_request
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository

router = APIRouter(prefix="/api/callbacks", tags=["workflow-studio"])


@router.get("/")
async def list_callbacks(request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    return paginate_collection(
        collection_key="callbacks",
        items=repository.list_callbacks(),
        params=pagination_params_from_request(request),
    )


@router.get("/{callback_id:path}")
async def get_callback(callback_id: str, request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    callback = repository.get_callback(callback_id)
    if callback is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Callback not found")
    return {"callback": callback}
