"""Gateway session inspection and recovery routes."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Query, Request
from pydantic import BaseModel, Field

from obra.api import APIClient
from obra.exceptions import APIError
from obra.gateway.errors import GatewayAPIError
from obra.gateway.links import build_resource_links
from obra.gateway.pagination import paginate_collection, pagination_params_from_request
from obra.gateway.session_manager import SessionNotFoundError

router = APIRouter(prefix="/api/sessions", tags=["sessions"])

_TERMINAL_SESSION_STATUSES = {"completed", "failed", "cancelled"}


class ForceCompleteSessionRequest(BaseModel):
    """Optional force-complete payload."""

    reason: str | None = Field(default=None, max_length=500)


@router.get("/")
async def list_sessions(
    request: Request,
    status_filter: str | None = Query(default=None, alias="status"),
) -> dict[str, Any]:
    """List gateway-known sessions."""
    normalized_filter = (status_filter or "active").strip().lower()
    if normalized_filter not in {"active", "all"}:
        raise GatewayAPIError(
            error_code="invalid_session_filter",
            message=f"Unsupported session filter: {status_filter}",
            hint="Valid values: active, all",
            status_code=400,
        )

    records = request.app.state.session_manager.list_sessions()
    if normalized_filter == "active":
        records = [
            record
            for record in records
            if str(record.status).lower() not in _TERMINAL_SESSION_STATUSES
        ]

    return paginate_collection(
        collection_key="sessions",
        items=[
            {
                "session_id": record.session_id,
                "status": record.status,
                "domain": record.domain_id,
                "created": record.created_at.isoformat(),
                "phase": _phase_for_record(record),
                "hybrid_session_id": record.hybrid_session_id,
            }
            for record in records
        ],
        params=pagination_params_from_request(request),
    )


@router.get("/{session_id}")
async def get_session(session_id: str, request: Request) -> dict[str, Any]:
    """Return remote hybrid session detail when available, else the local gateway snapshot."""
    record = _get_gateway_record(request, session_id)
    if record.hybrid_session_id:
        client = _get_api_client(request)
        try:
            remote_session = client.sessions.get_session(record.hybrid_session_id)
        except APIError as exc:
            raise GatewayAPIError.from_api_error(
                exc,
                default_error_code="remote_session_request_failed",
                default_message=f"Failed to load remote hybrid session for {session_id}",
            ) from exc
        return {"session": _remote_session_payload(session_id, record, remote_session)}
    return {"session": _local_session_payload(record)}


@router.post("/{session_id}/repair")
async def repair_session(session_id: str, request: Request) -> dict[str, Any]:
    """Repair a remote hybrid session through the canonical API client."""
    record = _get_gateway_record(request, session_id)
    hybrid_session_id = _require_hybrid_session_id(record)
    client = _get_api_client(request)
    try:
        result = client.sessions.repair_session(hybrid_session_id)
        remote_session = client.sessions.get_session(hybrid_session_id)
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code="remote_session_repair_failed",
            default_message=f"Failed to repair session {session_id}",
        ) from exc

    repairs_applied = result.get("repairs_applied") if isinstance(result, dict) else []
    actions_taken = []
    if isinstance(repairs_applied, list):
        for entry in repairs_applied:
            if not isinstance(entry, dict):
                continue
            field_name = str(entry.get("field") or "unknown")
            action_name = str(entry.get("action") or "updated")
            actions_taken.append(f"{field_name}:{action_name}")

    return {
        "issues_found": len(repairs_applied) if isinstance(repairs_applied, list) else 0,
        "actions_taken": actions_taken,
        "new_status": _remote_status(remote_session, record),
        "new_phase": _remote_phase(remote_session, record),
        "remote_result": result,
    }


@router.post("/{session_id}/force-complete")
async def force_complete_session(
    session_id: str,
    request: Request,
    body: ForceCompleteSessionRequest | None = None,
) -> dict[str, Any]:
    """Force-complete a remote hybrid session."""
    record = _get_gateway_record(request, session_id)
    hybrid_session_id = _require_hybrid_session_id(record)
    client = _get_api_client(request)
    try:
        result = client.sessions.force_complete_session(
            hybrid_session_id,
            reason=body.reason if body is not None else None,
        )
        remote_session = client.sessions.get_session(hybrid_session_id)
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code="remote_session_force_complete_failed",
            default_message=f"Failed to force-complete session {session_id}",
        ) from exc

    warnings = result.get("warnings") if isinstance(result, dict) else []
    return {
        "new_status": _remote_status(remote_session, record),
        "new_phase": _remote_phase(remote_session, record),
        "message": str(result.get("message") or "Session force-completed"),
        "preserved_results": result.get("preserved_results"),
        "warnings": list(warnings) if isinstance(warnings, list) else [],
        "remote_result": result,
    }


@router.post("/{session_id}/reset-review")
async def reset_review_session(session_id: str, request: Request) -> dict[str, Any]:
    """Reset review state on a remote hybrid session."""
    record = _get_gateway_record(request, session_id)
    hybrid_session_id = _require_hybrid_session_id(record)
    client = _get_api_client(request)
    try:
        result = client.sessions.reset_review(hybrid_session_id)
        remote_session = client.sessions.get_session(hybrid_session_id)
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code="remote_session_reset_review_failed",
            default_message=f"Failed to reset review for session {session_id}",
        ) from exc

    return {
        "new_status": _remote_status(remote_session, record),
        "new_phase": _remote_phase(remote_session, record),
        "message": str(result.get("message") or "Review state reset"),
        "item_id": result.get("item_id"),
        "previous_phase": result.get("previous_phase"),
        "remote_result": result,
    }


def _get_gateway_record(request: Request, session_id: str) -> Any:
    try:
        return request.app.state.session_manager.get_session(session_id)
    except SessionNotFoundError as exc:
        raise GatewayAPIError(
            error_code="session_not_found",
            message=f"Session {session_id} not found",
            status_code=404,
        ) from exc


def _require_hybrid_session_id(record: Any) -> str:
    hybrid_session_id = getattr(record, "hybrid_session_id", None)
    if isinstance(hybrid_session_id, str) and hybrid_session_id:
        return hybrid_session_id
    raise GatewayAPIError(
        error_code="remote_session_unavailable",
        message="Gateway session is not yet bound to a hybrid session",
        status_code=409,
    )


def _get_api_client(request: Request) -> APIClient:
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    if callable(client_factory):
        return client_factory()
    return APIClient.from_config()


def _phase_for_record(record: Any) -> str | None:
    latest_remote = (
        dict(record.latest_remote_session)
        if isinstance(getattr(record, "latest_remote_session", None), dict)
        else {}
    )
    current_phase = latest_remote.get("current_phase")
    if isinstance(current_phase, str) and current_phase:
        return current_phase
    current_stage = (
        dict(record.current_stage)
        if isinstance(getattr(record, "current_stage", None), dict)
        else {}
    )
    stage_name = current_stage.get("stage_name")
    if isinstance(stage_name, str) and stage_name:
        return stage_name
    return None


def _local_session_payload(record: Any) -> dict[str, Any]:
    latest_remote = (
        dict(record.latest_remote_session)
        if isinstance(getattr(record, "latest_remote_session", None), dict)
        else {}
    )
    return {
        "session_id": record.session_id,
        "hybrid_session_id": record.hybrid_session_id,
        "status": record.status,
        "current_phase": _phase_for_record(record),
        "pipeline_stages": list(latest_remote.get("pipeline_stages") or []),
        "workflow_lifecycle_state": dict(latest_remote.get("workflow_lifecycle_state") or {}),
        "workflow_lifecycle_decisions": dict(
            latest_remote.get("workflow_lifecycle_decisions") or {}
        ),
        "created_at": record.created_at.isoformat(),
        "updated_at": latest_remote.get("updated_at") or record.created_at.isoformat(),
        "source": "gateway_local",
        "links": build_resource_links("session", record.session_id),
    }


def _remote_session_payload(
    session_id: str,
    record: Any,
    remote_session: dict[str, Any],
) -> dict[str, Any]:
    return {
        "session_id": session_id,
        "hybrid_session_id": record.hybrid_session_id,
        "status": _remote_status(remote_session, record),
        "current_phase": _remote_phase(remote_session, record),
        "pipeline_stages": list(remote_session.get("pipeline_stages") or []),
        "workflow_lifecycle_state": dict(remote_session.get("workflow_lifecycle_state") or {}),
        "workflow_lifecycle_decisions": dict(
            remote_session.get("workflow_lifecycle_decisions") or {}
        ),
        "created_at": remote_session.get("created_at") or record.created_at.isoformat(),
        "updated_at": remote_session.get("updated_at") or record.created_at.isoformat(),
        "source": "remote_hybrid",
        "links": build_resource_links("session", session_id),
    }


def _remote_status(remote_session: dict[str, Any], record: Any) -> str:
    status = remote_session.get("status") or remote_session.get("state")
    return str(status or record.status)


def _remote_phase(remote_session: dict[str, Any], record: Any) -> str | None:
    current_phase = remote_session.get("current_phase")
    if isinstance(current_phase, str) and current_phase:
        return current_phase
    resume_context = remote_session.get("resume_context")
    if isinstance(resume_context, dict):
        resume_phase = resume_context.get("current_phase")
        if isinstance(resume_phase, str) and resume_phase:
            return resume_phase
    return _phase_for_record(record)
