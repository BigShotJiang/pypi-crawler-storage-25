"""Local filesystem browsing for the gateway.

Provides a directory listing endpoint so the Studio frontend can offer a
folder-picker UI without requiring Tauri-specific APIs.  Only directories
are returned — no file contents are exposed.
"""

from __future__ import annotations

import os
from pathlib import Path

from fastapi import APIRouter, Query, status

from obra.gateway.errors import GatewayAPIError

router = APIRouter(prefix="/api/filesystem", tags=["filesystem"])

_DEFAULT_PROJECTS_BASE = "~/obra-projects"


def _resolve_home(raw: str) -> Path:
    return Path(os.path.expanduser(raw)).resolve()


@router.get("/browse")
async def browse_directory(
    path: str | None = Query(default=None),
) -> dict[str, object]:
    """List immediate subdirectories of *path*.

    If *path* is omitted the user's home directory is used.  Returns the
    resolved absolute path, its parent (for "go up" navigation), and
    a sorted list of child directory names.
    """
    base = path or "~"
    resolved = _resolve_home(base)

    if not resolved.is_dir():
        raise GatewayAPIError(
            error_code="not_a_directory",
            message=f"Path is not a directory: {resolved}",
            status_code=status.HTTP_400_BAD_REQUEST,
        )

    children: list[str] = []
    try:
        for entry in sorted(resolved.iterdir()):
            if entry.name.startswith("."):
                continue
            if entry.is_dir():
                children.append(entry.name)
    except PermissionError:
        pass

    parent = str(resolved.parent) if resolved.parent != resolved else None

    return {
        "path": str(resolved),
        "parent": parent,
        "directories": children,
    }


@router.get("/defaults")
async def filesystem_defaults() -> dict[str, str]:
    """Return the default projects base directory and home directory."""
    projects_base = _resolve_home(_DEFAULT_PROJECTS_BASE)
    home = _resolve_home("~")
    return {
        "projects_base": str(projects_base),
        "home": str(home),
    }
