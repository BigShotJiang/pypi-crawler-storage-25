"""Assistant thread management routes."""

from __future__ import annotations

import asyncio
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, AsyncIterator, Literal

from fastapi import APIRouter, HTTPException, Query, Request, status
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field

from obra.gateway.automation.workspaces import resolve_gateway_workspace_from_request
from obra.gateway.errors import GatewayAPIError
from obra.gateway.links import build_resource_links
from obra.gateway.pagination import paginate_collection, pagination_params_from_request
from obra.gateway.workflow_studio.assistant_context import (
    AssistantContextAssembler,
    ContextAttachment,
)
from obra.gateway.workflow_studio.assistant_llm import call_assistant_llm_sync
from obra.gateway.workflow_studio.assistant_memory import build_thread_memory
from obra.gateway.workflow_studio.assistant_prompts import (
    _build_first_use_introduction,
    _render_transcript_turn,
    build_brainstorming_system_prompt,
    build_contextual_system_prompt,
    build_diagnostic_system_prompt,
)
from obra.gateway.workflow_studio.assistant_provider import (
    build_assistant_model_catalog,
    cache_model_catalog,
    configure_assistant_runtime,
    ensure_assistant_runtime,
    get_cached_model_catalog,
)
from obra.gateway.workflow_studio.assistant_repository import AssistantRepository
from obra.gateway.workflow_studio.assistant_response_planner import (
    build_recent_guided_decision_context,
)
from obra.gateway.workflow_studio.assistant_session_logger import AssistantSessionLogger
from obra.gateway.workflow_studio.assistant_streaming import _sse, stream_assistant_response
from obra.gateway.workflow_studio.file_checkpoint import AlreadyRevertedError, restore_checkpoint
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository
from obra.gateway.workflow_studio.safety import enforce_no_actions, enforce_safety_mode
from obra.gateway.workflow_studio.local_workflow_store import LocalWorkflowStore
from obra.gateway.workflow_studio.workflow_actions import WorkflowActionService
from obra.model_registry import MODEL_REGISTRY, resolve_alias, validate_model

router = APIRouter(prefix="/api/assistant", tags=["assistant"])

_session_loggers: dict[str, AssistantSessionLogger] = {}


@router.get("/pipelines")
async def list_pipelines(request: Request) -> dict[str, Any]:
    """List built-in assistant pipelines."""
    from obra.gateway.assistant.pipelines import list_pipelines as list_registered_pipelines
    from obra.gateway.assistant.pipelines.builtin import register_builtin_pipelines

    register_builtin_pipelines()
    return paginate_collection(
        collection_key="pipelines",
        items=[
            {
                "pipeline_id": definition.pipeline_id,
                "display_name": definition.display_name,
                "trigger_mode": definition.trigger_mode,
                "timeout_s": definition.timeout_s,
            }
            for definition in list_registered_pipelines()
        ],
        params=pagination_params_from_request(request),
    )


@router.get("/pipelines/active")
async def list_active_pipelines(
    request: Request,
    thread_id: str | None = Query(default=None),
) -> dict[str, list[dict[str, Any]]]:
    """List retained pipeline sessions in authoritative server order."""
    pipeline_session_manager = request.app.state.pipeline_session_manager
    return {"pipelines": pipeline_session_manager.list_active(thread_id=thread_id)}


@router.get("/pipelines/{pipeline_id}")
async def get_pipeline(pipeline_id: str, request: Request) -> dict[str, Any]:
    """Return one assistant pipeline definition."""
    del request
    from obra.gateway.assistant.pipelines import get_pipeline as get_registered_pipeline
    from obra.gateway.assistant.pipelines.builtin import register_builtin_pipelines

    register_builtin_pipelines()
    definition = get_registered_pipeline(pipeline_id)
    if definition is None:
        raise GatewayAPIError(
            error_code="pipeline_not_found",
            message=f"Pipeline {pipeline_id} not found",
            status_code=404,
        )

    try:
        steps = definition.steps_factory({}) if definition.steps_factory is not None else []
    except Exception as exc:
        raise GatewayAPIError(
            error_code="pipeline_definition_invalid",
            message=f"Pipeline {pipeline_id} definition could not be materialized",
            status_code=500,
        ) from exc

    return {
        "pipeline": {
            "pipeline_id": definition.pipeline_id,
            "display_name": definition.display_name,
            "trigger_mode": definition.trigger_mode,
            "timeout_s": definition.timeout_s,
            "steps": [
                {
                    "step_id": step.step_id,
                    "description": step.description,
                    "step_type": step.step_type,
                    "depends_on": list(step.depends_on),
                }
                for step in steps
            ],
        }
    }


class CreateThreadRequest(BaseModel):
    """Create a new assistant thread."""

    project_id: str = Field(..., min_length=1)
    name: str = Field(..., min_length=1, max_length=200)
    safety_mode: str | None = None
    carry_forward_thread_id: str | None = None


class UpdateThreadRequest(BaseModel):
    """Update mutable thread fields."""

    name: str | None = Field(default=None, max_length=200)
    archived: bool | None = None
    safety_mode: str | None = None
    workflow_id: str | None = None
    current_route: str | None = None


class CarryForwardThreadRequest(BaseModel):
    """Create a new thread from an archived or older summary."""

    project_id: str = Field(..., min_length=1)
    name: str = Field(..., min_length=1, max_length=200)
    safety_mode: str | None = None


class SubmitTurnRequest(BaseModel):
    """Submit a user turn to the assistant."""

    message: str = Field(..., min_length=1, max_length=50000)
    context: ContextAttachment
    model_id: str | None = None


class ExecuteActionRequest(BaseModel):
    """Execute an assistant action."""

    thread_id: str = Field(..., min_length=1)
    turn_id: str = Field(..., min_length=1)
    safety_mode: str = Field(..., min_length=1)
    action_inputs: dict[str, Any] = Field(default_factory=dict)
    workflow_id: str | None = None
    expected_revision_id: str | None = None
    working_dir: str | None = None


class BatchExecuteRecord(BaseModel):
    """One action item within a batch execute request."""

    source_record_index: int = Field(..., ge=0)
    action_id: str = Field(..., min_length=1)
    action_inputs: dict[str, Any] = Field(default_factory=dict)
    workflow_id: str | None = None
    expected_revision_id: str | None = None
    working_dir: str | None = None


class BatchExecuteRequest(BaseModel):
    """Execute multiple assistant actions in order."""

    thread_id: str = Field(..., min_length=1)
    turn_id: str = Field(..., min_length=1)
    safety_mode: str = Field(..., min_length=1)
    records: list[BatchExecuteRecord] = Field(..., min_length=1)
    working_dir: str | None = None


class UpdateTurnRequest(BaseModel):
    """Persist client-observed turn outcome or record status changes."""

    outcome: str | None = None
    action_records: list[dict[str, Any]] | None = None


class ExecutePipelineRequest(BaseModel):
    """Execute an assistant pipeline."""

    pipeline_id: str = Field(..., min_length=1)
    thread_id: str = Field(..., min_length=1)
    turn_id: str = Field(..., min_length=1)
    trigger_source: Literal["system_auto", "llm_proposed", "user_explicit"] = "user_explicit"
    workflow_id: str | None = None
    workflow_context: dict[str, Any] | None = None
    params: dict[str, Any] = Field(default_factory=dict)
    working_dir: str | None = None


class RevertActionRequest(BaseModel):
    """Revert a checkpoint-backed assistant file action."""

    safety_mode: str = Field(..., min_length=1)
    working_dir: str | None = None


def _get_action_broker(request: Request):
    """Build an ActionBroker from the current request context."""
    from obra.gateway.assistant.action_broker import ActionBroker
    from obra.gateway.assistant.audit import ActionAuditStore
    from obra.gateway.workflow_studio.operator_actions import WorkflowRunActionService

    repository = WorkflowStudioRepository.from_request(request)
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    local_store = getattr(request.app.state, "local_workflow_store", None)
    workflow_storage = str(
        getattr(
            request.app.state,
            "workflow_storage",
            getattr(request.app.state, "gateway_config", {}).get("workflow_storage", "cloud"),
        )
        or "cloud"
    ).strip().lower()
    action_service = WorkflowActionService(
        client_factory=client_factory,
        local_store=local_store if isinstance(local_store, LocalWorkflowStore) else None,
        workflow_storage=workflow_storage,
    )
    if callable(client_factory):
        request.app.state.session_manager.set_client_factory(client_factory)
    run_action_service = WorkflowRunActionService(request.app.state.session_manager)

    audit_store = getattr(request.app.state, "action_audit_store", None)
    if audit_store is None:
        audit_store = ActionAuditStore()
        request.app.state.action_audit_store = audit_store

    return ActionBroker(
        repository=repository,
        action_service=action_service,
        run_action_service=run_action_service,
        audit_store=audit_store,
    )


def _resolve_assistant_project_root(
    request: Request,
    *,
    project_id: str,
    working_dir: str | None,
) -> Path:
    resolution = resolve_gateway_workspace_from_request(
        request,
        project_id=project_id,
        working_dir=working_dir,
    )
    return Path(resolution.working_dir)


def _maybe_resolve_assistant_project_root(
    request: Request,
    *,
    project_id: str,
    working_dir: str | None,
) -> Path | None:
    try:
        return _resolve_assistant_project_root(
            request,
            project_id=project_id,
            working_dir=working_dir,
        )
    except ValueError:
        return None


def _append_system_turn(
    repository: AssistantRepository,
    *,
    thread_id: str,
    event_type: str,
    event_title: str,
    message: str,
    metadata: dict[str, Any] | None = None,
) -> None:
    repository.append_turn(
        thread_id,
        role="system",
        message=message,
        context=None,
        event_type=event_type,
        event_title=event_title,
        metadata=metadata,
    )


def _normalize_nonempty_string(value: Any) -> str | None:
    """Return *value* as a stripped non-empty string."""
    if not isinstance(value, str):
        return None
    normalized = value.strip()
    return normalized or None


def _build_action_inputs(
    action_inputs: dict[str, Any],
    *,
    workflow_id: str | None,
    expected_revision_id: str | None,
) -> dict[str, Any]:
    """Merge route-level workflow/revision context into action inputs."""
    merged_inputs = dict(action_inputs)
    merged_workflow_id = _normalize_nonempty_string(merged_inputs.get("workflow_id"))
    if workflow_id and not merged_workflow_id:
        merged_inputs["workflow_id"] = workflow_id

    merged_revision_id = _normalize_nonempty_string(merged_inputs.get("expected_revision_id"))
    if expected_revision_id and not merged_revision_id:
        merged_inputs["expected_revision_id"] = expected_revision_id
    return merged_inputs


def _extract_revision_id(resulting_revision_ref: Any) -> str | None:
    """Extract a revision id from handler output."""
    if isinstance(resulting_revision_ref, dict):
        return _normalize_nonempty_string(resulting_revision_ref.get("revision_id"))
    return _normalize_nonempty_string(resulting_revision_ref)


def _extract_workflow_id_from_result(result: Any) -> str | None:
    if isinstance(getattr(result, "resulting_revision_ref", None), dict):
        workflow_id = _normalize_nonempty_string(result.resulting_revision_ref.get("workflow_id"))
        if workflow_id:
            return workflow_id
    payload = getattr(result, "payload", None)
    if isinstance(payload, dict):
        workflow_id = _normalize_nonempty_string(payload.get("workflow_id"))
        if workflow_id:
            return workflow_id
    return None


def _entry_point_for_action(action_id: str) -> str | None:
    return "clone" if action_id == "execute_clone_and_adapt" else None


def _persist_thread_workflow_context_after_action(
    assistant_repository: AssistantRepository,
    *,
    thread_id: str,
    action_id: str,
    result: Any,
) -> None:
    if str(getattr(result, "outcome", "") or "") != "applied":
        return

    workflow_id = _extract_workflow_id_from_result(result)
    entry_point = _entry_point_for_action(action_id)
    if workflow_id is None and entry_point is None:
        return

    updates: dict[str, Any] = {}
    if workflow_id is not None:
        updates["workflow_id"] = workflow_id
    if entry_point is not None:
        updates["construction_context"] = {"entry_point": entry_point}
    if updates:
        assistant_repository.update_thread(thread_id, **updates)


def _merged_action_record(
    record: dict[str, Any],
    *,
    result: Any,
) -> dict[str, Any]:
    """Overlay broker execution results on top of a stored action record."""
    updated_record = {
        **record,
        **result.payload,
        "status": result.outcome,
        "audit_id": result.audit_id,
    }
    if result.conflict_summary is not None:
        updated_record["conflict_summary"] = result.conflict_summary
    return updated_record


def _record_matches_inputs(
    record: dict[str, Any],
    *,
    action_id: str,
    submitted_inputs: dict[str, Any],
) -> bool:
    """Return whether *record* matches the submitted action and inputs."""
    if str(record.get("action_id") or "") != action_id:
        return False
    record_inputs = record.get("action_inputs")
    return isinstance(record_inputs, dict) and record_inputs == submitted_inputs


def _merge_result_into_turn_records(
    updated_records: list[dict[str, Any]],
    *,
    action_id: str,
    submitted_inputs: dict[str, Any],
    result: Any,
    source_record_index: int | None = None,
) -> None:
    """Merge one execution result into an assistant turn's action records."""
    if (
        source_record_index is not None
        and 0 <= source_record_index < len(updated_records)
        and str(updated_records[source_record_index].get("action_id") or "") == action_id
    ):
        updated_records[source_record_index] = _merged_action_record(
            updated_records[source_record_index],
            result=result,
        )
        return

    for index, record in enumerate(updated_records):
        if not _record_matches_inputs(
            record, action_id=action_id, submitted_inputs=submitted_inputs
        ):
            continue
        updated_records[index] = _merged_action_record(record, result=result)
        return

    for index, record in enumerate(updated_records):
        if str(record.get("action_id") or "") != action_id:
            continue
        updated_records[index] = _merged_action_record(record, result=result)
        return

    updated_records.append(
        {
            "action_id": action_id,
            "action_inputs": submitted_inputs,
            "status": result.outcome,
            "audit_id": result.audit_id,
            **result.payload,
        }
    )


def _resolve_action_project_root(
    request: Request,
    *,
    thread: Any,
    action_id: str,
    action_inputs: dict[str, Any],
    working_dir: str | None,
) -> Path | None:
    """Resolve a project root for actions that need workspace access."""
    from obra.gateway.assistant.action_registry import get_action

    action_definition = get_action(action_id)
    if action_definition is None:
        return None
    if action_definition.category != "project_files" and action_id != "execute_launch_run":
        return None
    return _resolve_assistant_project_root(
        request,
        project_id=thread.project_id,
        working_dir=(
            working_dir
            or (
                str(action_inputs.get("working_dir")).strip()
                if isinstance(action_inputs.get("working_dir"), str)
                else None
            )
        ),
    )


def _assistant_context_snapshot(
    resolved_context: dict[str, Any],
    *,
    safety_mode: str,
) -> dict[str, Any]:
    ui_context = resolved_context.get("ui_context")
    return {
        "safety_mode": safety_mode,
        "project_id": resolved_context.get("project_id"),
        "workflow_id": resolved_context.get("workflow_id"),
        "current_route": ui_context.get("current_route") if isinstance(ui_context, dict) else None,
        "domain_id": resolved_context.get("domain_id"),
    }


def _build_thread_compact_context_snapshot(
    resolved_context: dict[str, Any],
    *,
    context_attachment: ContextAttachment,
    construction_context: dict[str, Any] | None,
) -> dict[str, Any]:
    """Persist the compact assistant thread context needed for carry-forward."""
    ui_context = resolved_context.get("ui_context")
    workflow_readiness = resolved_context.get("workflow_readiness")
    readiness_snapshot = (
        {
            "phase": workflow_readiness.get("phase"),
            "phase_confidence": workflow_readiness.get("phase_confidence"),
            "can_run": workflow_readiness.get("can_run"),
            "overall_completeness": workflow_readiness.get("overall_completeness"),
            "run_count": workflow_readiness.get("run_count"),
            "refinement_count": workflow_readiness.get("refinement_count"),
            "has_seed": workflow_readiness.get("has_seed"),
            "has_persisted_seed": workflow_readiness.get("has_persisted_seed"),
            "suggested_next_action": workflow_readiness.get("suggested_next_action"),
            "suggested_next_stage_id": workflow_readiness.get("suggested_next_stage_id"),
        }
        if isinstance(workflow_readiness, dict)
        else None
    )
    workflow_seed_summary = resolved_context.get("workflow_seed_summary")
    construction_snapshot = (
        {
            "has_scaffold_draft": bool(construction_context.get("scaffold_draft")),
            "refinement_count": int(construction_context.get("refinement_count") or 0),
        }
        if isinstance(construction_context, dict)
        else None
    )
    return {
        "project_id": resolved_context.get("project_id"),
        "working_dir": resolved_context.get("working_dir"),
        "safety_mode": resolved_context.get("safety_mode"),
        "workflow_id": resolved_context.get("workflow_id"),
        "revision_id": resolved_context.get("revision_id"),
        "run_id": context_attachment.run_id,
        "artifact_id": context_attachment.artifact_id,
        "derivation_id": context_attachment.derivation_id,
        "domain_id": resolved_context.get("domain_id"),
        "current_route": ui_context.get("current_route") if isinstance(ui_context, dict) else None,
        "ui_context": (
            {
                "editor_mode": ui_context.get("editor_mode"),
                "stage_count": ui_context.get("stage_count"),
                "has_validation_errors": ui_context.get("has_validation_errors"),
                "last_save_status": ui_context.get("last_save_status"),
                "save_readiness": ui_context.get("save_readiness"),
                "page": ui_context.get("page"),
            }
            if isinstance(ui_context, dict)
            else None
        ),
        "workflow_readiness": readiness_snapshot,
        "workflow_seed_summary": (
            dict(workflow_seed_summary) if isinstance(workflow_seed_summary, dict) else None
        ),
        "construction_context": construction_snapshot,
    }


def _normalize_pipeline_workflow_context(
    workflow_payload: dict[str, Any],
    *,
    workflow_id: str | None = None,
) -> dict[str, Any]:
    """Normalize persisted workflows and inline scaffold drafts into one shape."""
    normalized = dict(workflow_payload)
    definition = normalized.get("workflow_definition")
    if not isinstance(definition, dict):
        definition = dict(normalized)
        normalized["workflow_definition"] = definition
    stages = definition.get("stages")
    if isinstance(stages, list):
        normalized["stages"] = [stage for stage in stages if isinstance(stage, dict)]
    else:
        normalized["stages"] = []
        definition["stages"] = normalized["stages"]
    resolved_workflow_id = _normalize_nonempty_string(
        normalized.get("workflow_id") or definition.get("workflow_id") or workflow_id
    )
    if resolved_workflow_id:
        normalized["workflow_id"] = resolved_workflow_id
        definition.setdefault("workflow_id", resolved_workflow_id)
    return normalized


def _pipeline_working_dir(
    request: Request,
    *,
    thread: Any,
    working_dir: str | None,
) -> Path:
    candidate_working_dir = working_dir or (
        str(thread.last_context.get("working_dir")).strip()
        if isinstance(getattr(thread, "last_context", None), dict)
        and isinstance(thread.last_context.get("working_dir"), str)
        else None
    )
    resolved = _maybe_resolve_assistant_project_root(
        request,
        project_id=thread.project_id,
        working_dir=candidate_working_dir,
    )
    return resolved or Path.cwd()


def _select_strategy(
    resolved_context: dict[str, Any],
    user_message: str,
) -> list[str]:
    """Examine context signals and return a list of active strategy names."""
    from obra.config.loaders import (
        get_gateway_assistant_config,
        get_readiness_first_use_intro_enabled,
    )

    assistant_config = get_gateway_assistant_config()
    strategies: list[str] = []

    latest_run = resolved_context.get("latest_run")
    workflow = resolved_context.get("workflow")
    readiness = resolved_context.get("workflow_readiness")
    ui_context = resolved_context.get("ui_context") or {}
    current_route = str(ui_context.get("current_route") or "").strip()
    page = str(ui_context.get("page") or "").strip().lower()
    all_turns = resolved_context.get("all_turns")
    prior_user_turns = [
        turn
        for turn in all_turns
        if isinstance(turn, dict) and turn.get("role") == "user"
    ] if isinstance(all_turns, list) else []
    is_first_use_intro = (
        get_readiness_first_use_intro_enabled()
        and ui_context.get("editor_mode") == "create"
        and len(prior_user_turns) <= 1
        and (
            workflow is None
            or (
                isinstance(readiness, dict)
                and str(readiness.get("phase") or "").strip().lower() == "seed"
            )
        )
    )

    # 1. Diagnostic — failed/cancelled run
    if isinstance(latest_run, dict):
        run_status = str(latest_run.get("status") or "unknown")
        failure_stage_id = latest_run.get("failure_stage_id")
        if failure_stage_id is None:
            blocking_summary = latest_run.get("blocking_summary", {})
            if isinstance(blocking_summary, dict):
                failure_stage_id = blocking_summary.get("failure_stage_id")
        if run_status in {"failed", "cancelled"} or failure_stage_id:
            strategies.append("diagnostic")

    if page == "console" or current_route.startswith("/studio/console"):
        strategies.append("console_objective_drafting")

    # 2. Brainstorming — no workflow
    if workflow is None:
        if "console_objective_drafting" in strategies:
            strategies.append("contextual")
            return strategies
        return [
            "brainstorming",
            *(["first_use_introduction"] if is_first_use_intro else []),
            *strategies,
        ]

    # 3. Error resolution — validation errors present
    if ui_context.get("has_validation_errors"):
        strategies.append("error_resolution")

    # 4. Design guidance — create mode with few stages
    max_stages = assistant_config.get("strategy_design_guidance_max_stages", 3)
    if ui_context.get("editor_mode") == "create" and ui_context.get("stage_count", 0) < max_stages:
        strategies.append("design_guidance")

    # 5. Connection guidance — all stages isolated
    projection = ui_context.get("semantic_projection")
    if isinstance(projection, dict):
        proj_stages = projection.get("stages", {})
        if isinstance(proj_stages, dict) and proj_stages:
            all_isolated = all(
                (isinstance(s, dict) and s.get("role") == "isolated") for s in proj_stages.values()
            )
            if all_isolated:
                strategies.append("connection_guidance")

        # 6. Interaction help — non-idle interaction mode
        interaction = projection.get("interaction_state")
        if isinstance(interaction, dict) and interaction.get("mode") != "idle":
            strategies.append("interaction_help")

    # 7. Readiness assessment — clean save, no errors
    if ui_context.get("last_save_status") == "success" and not ui_context.get(
        "has_validation_errors"
    ):
        strategies.append("readiness_assessment")

    if is_first_use_intro:
        strategies.append("first_use_introduction")

    # 8. Contextual is always the default fallback
    strategies.append("contextual")
    return strategies


def _build_system_prompt_for_turn(
    resolved_context: dict[str, Any],
    user_message: str,
) -> str:
    from obra.config.loaders import get_gateway_assistant_config
    from obra.gateway.workflow_studio.assistant_prompts import _apply_strategy_adjustments
    from obra.token_budgets import get_max_prompt_tokens_for_model

    assistant_config = get_gateway_assistant_config()

    # Dynamic prompt budget based on the resolved model's context window.
    # Falls back to the static config value when model info is unavailable.
    static_budget = int(assistant_config.get("prompt_budget_tokens", 16000))
    model_id = str(resolved_context.get("model_id") or "")
    provider_name = str(resolved_context.get("provider_name") or "")
    if model_id and provider_name:
        model_max_prompt = get_max_prompt_tokens_for_model(provider_name, model_id)
        # Reserve one third of the model's prompt capacity for assistant
        # system context; the remainder is for conversation history and output.
        dynamic_budget = max(model_max_prompt // 3, static_budget)
        assistant_config = {**assistant_config, "prompt_budget_tokens": dynamic_budget}

    strategies = _select_strategy(resolved_context, user_message)
    resolved_context["strategies"] = strategies

    # Brainstorming branch — uses a focused prompt but includes conversation
    # history so the assistant retains context across turns.
    if "brainstorming" in strategies:
        prompt = build_brainstorming_system_prompt(
            first_use_intro=(
                _build_first_use_introduction(resolved_context)
                if "first_use_introduction" in strategies
                else None
            )
        )
        all_turns = resolved_context.get("all_turns") or []
        max_history = int(assistant_config.get("conversation_history_max_proposal_turns", 10))
        if all_turns:
            history_lines = []
            for turn in all_turns[-max_history:]:
                rendered = _render_transcript_turn(turn, prefix="")
                if rendered:
                    history_lines.append(rendered)
            if history_lines:
                prompt += "\n\n## Conversation History\n" + "\n\n".join(history_lines)
        construction_context = resolved_context.get("construction_context")
        if isinstance(construction_context, dict):
            scaffold_draft = construction_context.get("scaffold_draft")
            if isinstance(scaffold_draft, dict):
                stage_titles = [
                    str(stage.get("title") or stage.get("id") or "").strip()
                    for stage in scaffold_draft.get("stages", [])
                    if isinstance(stage, dict)
                ]
                prompt += (
                    "\n\n## Current Draft\n"
                    f"Stage count: {len(stage_titles)}\n"
                    f"Stages: {', '.join(title for title in stage_titles if title) or 'none'}\n"
                    f"Refinement count: {int(construction_context.get('refinement_count') or 0)}"
                )
        return prompt

    # All other strategies go through budget-aware contextual prompt
    prompt = build_contextual_system_prompt(
        resolved_context,
        assistant_config=assistant_config,
        strategies=strategies,
    )
    construction_context = resolved_context.get("construction_context")
    if isinstance(construction_context, dict):
        scaffold_draft = construction_context.get("scaffold_draft")
        if isinstance(scaffold_draft, dict):
            stage_titles = [
                str(stage.get("title") or stage.get("id") or "").strip()
                for stage in scaffold_draft.get("stages", [])
                if isinstance(stage, dict)
            ]
            prompt += (
                "\n\n## Current Draft\n"
                f"Stage count: {len(stage_titles)}\n"
                f"Stages: {', '.join(title for title in stage_titles if title) or 'none'}\n"
                f"Refinement count: {int(construction_context.get('refinement_count') or 0)}"
            )
    return prompt


def _resolve_turn_model_id(
    request: Request,
    *,
    thread_id: str,
    thread_model_id: str | None,
    requested_model_id: str | None,
) -> str:
    assistant_state = request.app.state.assistant_llm_provider_state
    provider_name = assistant_state.provider_name
    default_model_id = assistant_state.default_model_id
    provider = MODEL_REGISTRY.get(provider_name)

    def _validate_selectable_model(model_id: str) -> str:
        validation = validate_model(provider_name, model_id)
        if not validation.valid:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail=validation.error or "Invalid model id",
            )
        if provider is None or model_id not in provider.models:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail=f"Unsupported model id for configured provider '{provider_name}': {model_id}",
            )
        return resolve_alias(provider_name, model_id)

    if requested_model_id is not None:
        requested_model_id = str(requested_model_id).strip()
        if requested_model_id == "default":
            AssistantRepository.from_request(request).update_thread(thread_id, model_id=None)
            return default_model_id

        canonical_model_id = _validate_selectable_model(requested_model_id)
        AssistantRepository.from_request(request).update_thread(
            thread_id,
            model_id=canonical_model_id,
        )
        return canonical_model_id

    if thread_model_id:
        canonical_model_id = _validate_selectable_model(thread_model_id)
        if canonical_model_id != thread_model_id:
            AssistantRepository.from_request(request).update_thread(
                thread_id,
                model_id=canonical_model_id,
            )
        return canonical_model_id

    return default_model_id


@router.post("/threads")
async def create_thread(body: CreateThreadRequest, request: Request) -> dict:
    repository = AssistantRepository.from_request(request)
    safety_mode = body.safety_mode or "guided"
    enforce_safety_mode(safety_mode)
    if body.carry_forward_thread_id:
        if repository.get_thread(body.carry_forward_thread_id) is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Source thread not found",
            )
        thread = repository.create_carry_forward_thread(
            project_id=body.project_id,
            name=body.name,
            source_thread_id=body.carry_forward_thread_id,
            safety_mode=safety_mode,
        )
    else:
        thread = repository.create_thread(body.project_id, body.name, safety_mode=safety_mode)
    return {"thread": asdict(thread)}


@router.get("/threads")
async def list_threads(
    request: Request,
    project_id: str,
    archived: bool = False,
    search: str | None = None,
) -> dict:
    repository = AssistantRepository.from_request(request)
    threads = repository.list_threads(project_id, archived=archived, search_query=search)
    return paginate_collection(
        collection_key="threads",
        items=[asdict(t) for t in threads],
        params=pagination_params_from_request(request),
    )


@router.get("/threads/{thread_id}")
async def get_thread(thread_id: str, request: Request) -> dict:
    repository = AssistantRepository.from_request(request)
    thread = repository.get_thread(thread_id)
    if thread is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )
    turns = repository.list_turns(thread_id)
    payload = asdict(thread)
    payload["links"] = build_resource_links("thread", thread_id)
    return {"thread": payload, "turns": [asdict(t) for t in turns]}


@router.patch("/threads/{thread_id}")
async def update_thread(
    thread_id: str,
    body: UpdateThreadRequest,
    request: Request,
) -> dict:
    repository = AssistantRepository.from_request(request)
    existing = repository.get_thread(thread_id)
    if existing is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )
    previous_safety_mode = existing.safety_mode
    previous_archived = existing.archived
    if body.safety_mode is not None:
        enforce_safety_mode(body.safety_mode)
    thread = repository.update_thread(
        thread_id,
        name=body.name,
        archived=body.archived,
        safety_mode=body.safety_mode,
        workflow_id=body.workflow_id,
        current_route=body.current_route,
    )
    if thread is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Thread not found")

    if body.safety_mode is not None and body.safety_mode != previous_safety_mode:
        _append_system_turn(
            repository,
            thread_id=thread_id,
            event_type="mode_change",
            event_title="Safety mode changed",
            message=(
                f"Safety mode changed from {previous_safety_mode} to {body.safety_mode}. "
                "The same thread and its conversation memory were retained."
            ),
            metadata={
                "from_mode": previous_safety_mode,
                "to_mode": body.safety_mode,
            },
        )

    if body.archived is not None and body.archived != previous_archived:
        if body.archived:
            _append_system_turn(
                repository,
                thread_id=thread_id,
                event_type="archived",
                event_title="Thread archived",
                message="This thread was archived but kept for future restore or carry-forward.",
            )
        else:
            _append_system_turn(
                repository,
                thread_id=thread_id,
                event_type="restored",
                event_title="Thread restored",
                message="This thread was restored from the archive and remains on the same timeline.",
            )
    return {"thread": asdict(thread)}


@router.post("/threads/{thread_id}/restore")
async def restore_thread(thread_id: str, request: Request) -> dict:
    repository = AssistantRepository.from_request(request)
    thread = repository.restore_thread(thread_id)
    if thread is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )
    _append_system_turn(
        repository,
        thread_id=thread_id,
        event_type="restored",
        event_title="Thread restored",
        message="This thread was restored from the archive and remains available for resume.",
    )
    return {"thread": asdict(thread)}


@router.delete("/threads/{thread_id}")
async def delete_thread(thread_id: str, request: Request) -> dict:
    repository = AssistantRepository.from_request(request)
    thread = repository.soft_delete_thread(thread_id)
    if thread is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )
    return {"thread": asdict(thread)}


@router.post("/threads/{thread_id}/carry-forward")
async def carry_forward_thread(
    thread_id: str,
    body: CarryForwardThreadRequest,
    request: Request,
) -> dict:
    if body.safety_mode is not None:
        enforce_safety_mode(body.safety_mode)
    repository = AssistantRepository.from_request(request)
    if repository.get_thread(thread_id) is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Source thread not found",
        )
    thread = repository.create_carry_forward_thread(
        project_id=body.project_id,
        name=body.name,
        source_thread_id=thread_id,
        safety_mode=body.safety_mode or "guided",
    )
    return {"thread": asdict(thread)}


@router.post("/threads/{thread_id}/turns")
async def submit_turn(
    thread_id: str,
    body: SubmitTurnRequest,
    request: Request,
) -> StreamingResponse:
    ensure_assistant_runtime(request.app.state)
    repository = AssistantRepository.from_request(request)
    thread = repository.get_thread(thread_id)
    if thread is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )

    enforce_safety_mode(body.context.safety_mode)

    user_turn = repository.append_turn(
        thread_id,
        role="user",
        message=body.message,
        context=body.context.model_dump(),
    )

    # --- Session logger initialisation (S0.T1 / S0.T2) ---
    from obra.config.loaders import get_gateway_assistant_config as _get_ac

    assistant_config = _get_ac()

    is_new_session = False
    if thread.session_id is None:
        sid = AssistantSessionLogger.generate_session_id(thread_id)
        repository.update_thread(thread_id, session_id=sid)
        is_new_session = True

    logging_config = assistant_config.get("logging", {})
    if thread.session_id not in _session_loggers:
        session_logger = AssistantSessionLogger(
            thread.session_id,  # type: ignore[arg-type]
            config=logging_config,
        )
        session_logger.set_thread_context(thread_id)
        _session_loggers[thread.session_id] = session_logger  # type: ignore[index]
    else:
        session_logger = _session_loggers[thread.session_id]  # type: ignore[index]

    ws_repository = WorkflowStudioRepository.from_request(request)
    project_root = _maybe_resolve_assistant_project_root(
        request,
        project_id=thread.project_id,
        working_dir=body.context.working_dir,
    )
    construction_context = repository.get_construction_context(thread_id)
    assembler = AssistantContextAssembler(ws_repository, project_root=project_root)
    resolved_context = assembler.resolve(
        body.context,
        construction_context=construction_context,
    )

    ui_context = resolved_context.get("ui_context")
    repository.update_thread(
        thread_id,
        workflow_id=str(resolved_context.get("workflow_id") or "").strip() or None,
        current_route=(
            str(ui_context.get("current_route") or "").strip()
            if isinstance(ui_context, dict)
            else None
        ),
        last_context=_build_thread_compact_context_snapshot(
            resolved_context,
            context_attachment=body.context,
            construction_context=construction_context,
        ),
    )

    # Screenshot
    if body.context.ui_state and isinstance(body.context.ui_state.get("screenshot"), str):
        screenshot = body.context.ui_state["screenshot"]
        if screenshot.startswith("data:image/"):
            resolved_context["screenshot"] = screenshot

    resolved_model_id = _resolve_turn_model_id(
        request,
        thread_id=thread_id,
        thread_model_id=thread.model_id,
        requested_model_id=body.model_id,
    )
    resolved_context["model_id"] = resolved_model_id
    resolved_context["provider_name"] = request.app.state.assistant_llm_provider_state.provider_name

    # (2) Log turn submitted
    session_logger.log_event(
        "asst.turn_submitted",
        turn_id=user_turn.turn_id,
        role="user",
        message=body.message,
        context_attachment=body.context.model_dump(),
    )

    # Conversation continuity — add turn history for re-proposal suppression
    all_turns = repository.list_turns(thread_id)
    max_proposal_turns = assistant_config.get("conversation_history_max_proposal_turns", 10)
    proposal_turns = [
        asdict(t) for t in all_turns if t.outcome is not None and t.outcome != "advice"
    ][-max_proposal_turns:]
    resolved_context["turn_history"] = proposal_turns
    resolved_context["all_turns"] = [asdict(t) for t in all_turns]
    resolved_context["recent_guided_decisions"] = build_recent_guided_decision_context(
        resolved_context["all_turns"],
        limit=max_proposal_turns,
    )
    if construction_context is not None:
        resolved_context["construction_context"] = construction_context
    resolved_context.update(
        build_thread_memory(
            resolved_context["all_turns"],
            assistant_config,
        )
    )
    if thread.carry_forward_summary:
        resolved_context["carry_forward_summary"] = thread.carry_forward_summary
    if thread.summary:
        resolved_context["thread_summary"] = thread.summary

    system_prompt = _build_system_prompt_for_turn(resolved_context, body.message)

    # (1) Log session started (first turn only, after model is resolved)
    if is_new_session:
        session_logger.log_event(
            "asst.session_started",
            thread_name=thread.name,
            project_id=thread.project_id,
            safety_mode=thread.safety_mode,
            model_id=resolved_model_id,
        )

    # (3) Log context resolved (after _build_system_prompt_for_turn sets strategies)
    session_logger.log_event(
        "asst.context_resolved",
        strategies=resolved_context.get("strategies"),
        model_id=resolved_context.get("model_id"),
        has_workflow=resolved_context.get("workflow") is not None,
        has_latest_run=resolved_context.get("latest_run") is not None,
        has_artifact=resolved_context.get("selected_artifact") is not None,
        has_derivation=resolved_context.get("selected_derivation") is not None,
        turn_history_count=len(resolved_context.get("turn_history", [])),
        knowledge_doc_count=len(resolved_context.get("knowledge_documents", [])),
        template_asset_count=len(resolved_context.get("template_assets", {})),
        has_screenshot="screenshot" in resolved_context,
    )

    # (4) Log system prompt
    session_logger.log_event(
        "asst.system_prompt",
        system_prompt=system_prompt,
        prompt_length=len(system_prompt),
        strategy_primary=resolved_context.get("strategies", ["contextual"])[0],
    )

    # Prune old session files opportunistically
    session_logger.prune_sessions()

    return StreamingResponse(
        stream_assistant_response(
            thread,
            user_turn,
            resolved_context,
            repository,
            system_prompt=system_prompt,
            app_state=request.app.state,
            session_logger=session_logger,
            assistant_turn_context=_assistant_context_snapshot(
                resolved_context,
                safety_mode=thread.safety_mode,
            ),
        ),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("/models")
async def list_models(request: Request) -> dict:
    """List available LLM models with health status."""
    cached_models = get_cached_model_catalog(request.app.state)
    if cached_models is not None:
        return paginate_collection(
            collection_key="models",
            items=cached_models,
            params=pagination_params_from_request(request),
        )

    state = ensure_assistant_runtime(request.app.state)
    models = build_assistant_model_catalog(state)
    cache_model_catalog(request.app.state, models)
    return paginate_collection(
        collection_key="models",
        items=models,
        params=pagination_params_from_request(request),
    )


@router.post("/models/refresh")
async def refresh_models(request: Request) -> dict:
    """Clear model health cache and re-probe."""
    configure_assistant_runtime(request.app.state)
    return await list_models(request)


@router.post("/actions/{action_id}/execute")
async def execute_action(
    action_id: str,
    body: ExecuteActionRequest,
    request: Request,
) -> dict:
    from obra.gateway.assistant.action_broker import (
        ActionInputError,
        ActionNotFoundError,
        SafetyModeInsufficientError,
    )
    from obra.gateway.assistant.action_registry import get_action

    enforce_no_actions(body.safety_mode, action_requested=True)

    assistant_repository = AssistantRepository.from_request(request)
    thread = assistant_repository.get_thread(body.thread_id)
    if thread is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )
    action_definition = get_action(action_id)
    if action_definition is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Action not found: {action_id}",
        )
    merged_inputs = _build_action_inputs(
        body.action_inputs,
        workflow_id=body.workflow_id,
        expected_revision_id=body.expected_revision_id,
    )
    project_root = _resolve_action_project_root(
        request,
        thread=thread,
        action_id=action_id,
        action_inputs=merged_inputs,
        working_dir=body.working_dir,
    )
    turn_index = next(
        (
            index
            for index, turn in enumerate(assistant_repository.list_turns(body.thread_id))
            if turn.turn_id == body.turn_id
        ),
        0,
    )

    broker = _get_action_broker(request)
    try:
        result = await asyncio.to_thread(
            broker.execute,
            action_id=action_id,
            inputs=merged_inputs,
            safety_mode=body.safety_mode,
            thread_id=body.thread_id,
            turn_id=body.turn_id,
            user_id="current-user",
            correlation={"turn_index": turn_index},
            project_root=project_root,
            llm_call=lambda system_prompt, user_message, **kwargs: call_assistant_llm_sync(
                system_prompt,
                user_message,
                app_state=request.app.state,
                **kwargs,
            ),
        )
    except ActionNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Action not found: {action_id}",
        )
    except SafetyModeInsufficientError as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "safety_mode_insufficient",
                "current_mode": exc.current_mode,
                "required_mode": exc.required_mode,
            },
        )
    except ActionInputError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=str(exc),
        )

    existing_turn = assistant_repository.get_turn(body.thread_id, body.turn_id)
    updated_records = list(existing_turn.action_records or []) if existing_turn is not None else []
    _merge_result_into_turn_records(
        updated_records,
        action_id=action_id,
        submitted_inputs=merged_inputs,
        result=result,
    )
    assistant_repository.update_turn(
        body.thread_id,
        body.turn_id,
        outcome=result.outcome,
        action_records=updated_records,
    )
    _persist_thread_workflow_context_after_action(
        assistant_repository,
        thread_id=body.thread_id,
        action_id=action_id,
        result=result,
    )

    # Log action execution
    if thread.session_id and thread.session_id in _session_loggers:
        _session_loggers[thread.session_id].log_event(
            "asst.action_executed",
            action_id=action_id,
            audit_id=result.audit_id,
            status=result.outcome,
            turn_id=body.turn_id,
        )

    return asdict(result)


@router.post("/actions/execute-batch")
async def execute_action_batch(
    body: BatchExecuteRequest,
    request: Request,
) -> dict[str, Any]:
    from obra.gateway.assistant.action_broker import (
        ActionInputError,
        ActionNotFoundError,
        SafetyModeInsufficientError,
    )
    from obra.gateway.assistant.action_registry import get_action

    enforce_no_actions(body.safety_mode, action_requested=True)

    assistant_repository = AssistantRepository.from_request(request)
    thread = assistant_repository.get_thread(body.thread_id)
    if thread is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )

    turn_index = next(
        (
            index
            for index, turn in enumerate(assistant_repository.list_turns(body.thread_id))
            if turn.turn_id == body.turn_id
        ),
        0,
    )

    broker = _get_action_broker(request)
    results: list[dict[str, Any]] = []
    executed_inputs_by_index: dict[int, dict[str, Any]] = {}
    last_applied_revision_id: str | None = None

    try:
        for record in body.records:
            action_definition = get_action(record.action_id)
            if action_definition is None:
                raise ActionNotFoundError(record.action_id)

            expected_revision_id = record.expected_revision_id or last_applied_revision_id
            merged_inputs = _build_action_inputs(
                record.action_inputs,
                workflow_id=record.workflow_id,
                expected_revision_id=expected_revision_id,
            )
            project_root = _resolve_action_project_root(
                request,
                thread=thread,
                action_id=record.action_id,
                action_inputs=merged_inputs,
                working_dir=record.working_dir or body.working_dir,
            )

            result = await asyncio.to_thread(
                broker.execute,
                action_id=record.action_id,
                inputs=merged_inputs,
                safety_mode=body.safety_mode,
                thread_id=body.thread_id,
                turn_id=body.turn_id,
                user_id="current-user",
                correlation={
                    "turn_index": turn_index,
                    "batch_execution": True,
                    "source_record_index": record.source_record_index,
                },
                project_root=project_root,
                llm_call=lambda system_prompt, user_message, **kwargs: call_assistant_llm_sync(
                    system_prompt,
                    user_message,
                    app_state=request.app.state,
                    **kwargs,
                ),
            )
            executed_inputs_by_index[record.source_record_index] = dict(merged_inputs)

            results.append(
                {
                    "source_record_index": record.source_record_index,
                    "action_id": record.action_id,
                    "base_revision_id": _normalize_nonempty_string(
                        merged_inputs.get("expected_revision_id")
                    )
                    or "",
                    "head_revision_id": _extract_revision_id(result.resulting_revision_ref) or "",
                    **asdict(result),
                }
            )

            if thread.session_id and thread.session_id in _session_loggers:
                _session_loggers[thread.session_id].log_event(
                    "asst.action_executed",
                    action_id=record.action_id,
                    audit_id=result.audit_id,
                    status=result.outcome,
                    turn_id=body.turn_id,
                    batch_execution=True,
                    source_record_index=record.source_record_index,
                )

            if result.outcome != "applied":
                break
            last_applied_revision_id = _extract_revision_id(result.resulting_revision_ref)
            _persist_thread_workflow_context_after_action(
                assistant_repository,
                thread_id=body.thread_id,
                action_id=record.action_id,
                result=result,
            )
    except ActionNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Action not found",
        )
    except SafetyModeInsufficientError as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "safety_mode_insufficient",
                "current_mode": exc.current_mode,
                "required_mode": exc.required_mode,
            },
        )
    except ActionInputError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=str(exc),
        )

    overall_outcome = "applied"
    if results:
        first_non_applied = next(
            (result for result in results if str(result.get("outcome") or "") != "applied"),
            None,
        )
        if first_non_applied is not None:
            overall_outcome = (
                str(first_non_applied.get("outcome") or "invalid")
                if first_non_applied is results[0]
                else "partial"
            )

    existing_turn = assistant_repository.get_turn(body.thread_id, body.turn_id)
    updated_records = list(existing_turn.action_records or []) if existing_turn is not None else []
    for executed in results:
        action_id = str(executed.get("action_id") or "")
        payload = executed.get("payload")
        submitted_inputs = executed_inputs_by_index.get(int(executed["source_record_index"]), {})
        pseudo_result = type(
            "BatchResult",
            (),
            {
                "payload": payload if isinstance(payload, dict) else {},
                "outcome": str(executed.get("outcome") or ""),
                "audit_id": str(executed.get("audit_id") or ""),
                "conflict_summary": executed.get("conflict_summary"),
            },
        )()
        _merge_result_into_turn_records(
            updated_records,
            action_id=action_id,
            submitted_inputs=submitted_inputs,
            result=pseudo_result,
            source_record_index=int(executed["source_record_index"]),
        )

    assistant_repository.update_turn(
        body.thread_id,
        body.turn_id,
        outcome=overall_outcome,
        action_records=updated_records,
    )

    return {
        "results": results,
        "overall_outcome": overall_outcome,
    }


@router.post("/pipelines/execute")
async def execute_pipeline(
    body: ExecutePipelineRequest,
    request: Request,
) -> JSONResponse:
    """Launch a registered assistant pipeline in the background."""
    from obra.config.loaders import get_gateway_assistant_config
    from obra.gateway.assistant.pipelines import PipelineEngine, get_pipeline
    from obra.gateway.assistant.pipelines.builtin import register_builtin_pipelines
    from obra.gateway.assistant.pipelines.llm import build_pipeline_llm_config

    register_builtin_pipelines()
    pipeline_definition = get_pipeline(body.pipeline_id)
    if pipeline_definition is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Pipeline not found: {body.pipeline_id}",
        )

    if (body.workflow_id is None) == (body.workflow_context is None):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail="Exactly one of workflow_id or workflow_context is required.",
        )

    assistant_repository = AssistantRepository.from_request(request)
    thread = assistant_repository.get_thread(body.thread_id)
    if thread is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )

    workflow_repository = WorkflowStudioRepository.from_request(request)
    if body.workflow_context is not None:
        resolved_workflow_context = _normalize_pipeline_workflow_context(body.workflow_context)
    else:
        workflow = workflow_repository.get_workflow(str(body.workflow_id or ""))
        if workflow is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Workflow not found: {body.workflow_id}",
            )
        resolved_workflow_context = _normalize_pipeline_workflow_context(
            workflow,
            workflow_id=body.workflow_id,
        )

    if body.params:
        resolved_workflow_context = {
            **resolved_workflow_context,
            **body.params,
            "params": dict(body.params),
        }
        run_id = _normalize_nonempty_string(body.params.get("run_id"))
        if run_id:
            run_detail = workflow_repository.get_run(run_id)
            if isinstance(run_detail, dict):
                resolved_workflow_context.setdefault("run", run_detail)
                stage_outputs = run_detail.get("stage_outputs") or run_detail.get("outputs")
                if isinstance(stage_outputs, dict):
                    resolved_workflow_context.setdefault("run_outputs", stage_outputs)

    working_dir = _pipeline_working_dir(
        request,
        thread=thread,
        working_dir=body.working_dir,
    )
    session_logger = _session_loggers.get(str(thread.session_id or ""))

    def on_step_progress(event_type: str, payload: dict[str, Any]) -> None:
        if session_logger is None:
            return
        session_logger.log_event(
            f"asst.{event_type}",
            step_id=payload.get("step_id"),
            message=payload.get("message"),
            detail=payload.get("detail"),
            progress_pct=payload.get("progress_pct"),
        )

    assistant_config = get_gateway_assistant_config()
    per_step_budget = int(assistant_config["pipelines"]["per_step_timeout_budget_s"])

    engine = PipelineEngine(
        pipeline_definition,
        resolved_workflow_context,
        llm_call=lambda system_prompt, user_message, **kwargs: call_assistant_llm_sync(
            system_prompt,
            user_message,
            app_state=request.app.state,
            **kwargs,
        ),
        thread_id=body.thread_id,
        turn_id=body.turn_id,
        working_dir=working_dir,
        llm_config=build_pipeline_llm_config(request.app.state),
        log_event=session_logger.log_event if session_logger is not None else None,
        params=body.params,
        on_progress=on_step_progress,
        per_step_timeout_budget_s=per_step_budget,
    )
    pipeline_session_manager = request.app.state.pipeline_session_manager

    if session_logger is not None:
        session_logger.log_event(
            "asst.pipeline_started",
            pipeline_id=body.pipeline_id,
            thread_id=body.thread_id,
            turn_id=body.turn_id,
            trigger_source=body.trigger_source,
        )

    def result_callback(payload: dict[str, Any]) -> dict[str, Any] | None:
        result = engine.result
        if result is None:
            return None
        proposals = result.proposals or []
        summary_message = result.summary_message or (
            f"{pipeline_definition.display_name} completed with workflow proposals."
            if proposals
            else f"{pipeline_definition.display_name} completed with no findings."
        )
        appended_turn = assistant_repository.append_turn(
            body.thread_id,
            role="assistant",
            message=summary_message,
            context={
                "workflow_id": resolved_workflow_context.get("workflow_id"),
            },
            outcome="proposal" if proposals else "advice",
            action_records=proposals,
            event_type="pipeline_result",
            event_title=pipeline_definition.display_name,
            metadata={"pipeline_id": body.pipeline_id},
        )
        if session_logger is not None:
            session_logger.log_event(
                "asst.pipeline_completed",
                pipeline_id=body.pipeline_id,
                thread_id=body.thread_id,
                turn_id=body.turn_id,
                status=payload.get("status"),
                proposal_count=payload.get("proposal_count"),
            )
        return asdict(appended_turn)

    from obra.gateway.pipeline_session import PipelineSessionLimitError

    try:
        session_id = pipeline_session_manager.create_session(
            thread_id=body.thread_id,
            turn_id=body.turn_id,
            pipeline_id=body.pipeline_id,
            engine=engine,
            display_name=pipeline_definition.display_name,
            result_callback=result_callback,
            trigger_source=body.trigger_source,
        )
    except PipelineSessionLimitError as exc:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=str(exc),
        ) from exc

    return JSONResponse({"pipeline_session_id": session_id, "status": "running"})


@router.post("/pipelines/sessions/{session_id}/cancel")
async def cancel_pipeline(
    session_id: str,
    request: Request,
) -> dict[str, str]:
    """Cancel a running background assistant pipeline session."""
    pipeline_session_manager = request.app.state.pipeline_session_manager
    status = pipeline_session_manager.cancel_session(session_id)
    if status is None:
        return {"status": "not_found"}
    return {"status": status}


@router.get("/pipelines/sessions/{session_id}/events")
async def stream_pipeline_events(
    session_id: str,
    request: Request,
    after_sequence: int | None = Query(default=None, ge=0),
) -> StreamingResponse:
    """Stream one pipeline session's retained and live events over SSE."""
    from obra.config.loaders import get_gateway_assistant_config

    pipeline_session_manager = request.app.state.pipeline_session_manager
    try:
        record = pipeline_session_manager.get_session(session_id)
    except KeyError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Pipeline session not found",
        ) from exc

    heartbeat_interval_s = float(
        get_gateway_assistant_config()["pipelines"]["sse_heartbeat_interval_s"]
    )

    async def _event_stream() -> AsyncIterator[str]:
        subscription = record.event_bus.subscribe(after_sequence=after_sequence).__aiter__()
        while True:
            try:
                event = await asyncio.wait_for(
                    subscription.__anext__(),
                    timeout=heartbeat_interval_s,
                )
            except asyncio.TimeoutError:
                yield ":keepalive\n\n"
                continue
            except StopAsyncIteration:
                break

            payload = {
                **dict(event["payload"]),
                "sequence": event["sequence"],
                "event_id": event["event_id"],
                "timestamp": event["timestamp"],
                "session_id": event["session_id"],
            }
            yield f"event: {event['event_type']}\n"
            yield f"data: {json.dumps(payload)}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(
        _event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
@router.patch("/threads/{thread_id}/turns/{turn_id}")
async def update_turn(
    thread_id: str,
    turn_id: str,
    body: UpdateTurnRequest,
    request: Request,
) -> dict:
    repository = AssistantRepository.from_request(request)
    thread = repository.get_thread(thread_id)
    if thread is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )
    turn = repository.update_turn(
        thread_id,
        turn_id,
        outcome=body.outcome,
        action_records=body.action_records,
    )
    if turn is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Turn not found",
        )
    return {"turn": asdict(turn)}


@router.get("/threads/{thread_id}/audit")
async def get_thread_audit(thread_id: str, request: Request) -> list:
    repository = AssistantRepository.from_request(request)
    persisted_records = repository.list_persisted_audits(thread_id)
    audit_store = getattr(request.app.state, "action_audit_store", None)
    if audit_store is None:
        return persisted_records
    records = audit_store.list_by_thread(thread_id)
    return [asdict(r) for r in records] + persisted_records


@router.post("/actions/{audit_id}/revert")
async def revert_action(
    audit_id: str,
    body: RevertActionRequest,
    request: Request,
) -> dict[str, Any]:
    from obra.gateway.assistant.audit import ActionAuditStore

    enforce_no_actions(body.safety_mode, action_requested=True)

    audit_store = getattr(request.app.state, "action_audit_store", None)
    if audit_store is None:
        audit_store = ActionAuditStore()
        request.app.state.action_audit_store = audit_store

    assistant_repository = AssistantRepository.from_request(request)
    audit_record = audit_store.get(audit_id)
    persisted_audit = assistant_repository.find_action_audit(audit_id)
    if audit_record is None and persisted_audit is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "audit_not_found"},
        )

    checkpoint_id = (
        audit_record.correlation.get("checkpoint_id")
        if audit_record is not None
        else persisted_audit.checkpoint_id
    )
    if checkpoint_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "no_checkpoint",
                "message": "This action has no associated file checkpoint",
            },
        )

    thread_id = audit_record.thread_id if audit_record is not None else persisted_audit.thread_id
    thread = assistant_repository.get_thread(thread_id)
    if thread is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )
    project_root = _resolve_assistant_project_root(
        request,
        project_id=thread.project_id,
        working_dir=body.working_dir,
    )
    try:
        checkpoint = restore_checkpoint(project_root, checkpoint_id)
    except AlreadyRevertedError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"error": "already_reverted"},
        )
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "checkpoint_not_found"},
        )

    # Log action revert
    if thread.session_id and thread.session_id in _session_loggers:
        _session_loggers[thread.session_id].log_event(
            "asst.action_reverted",
            audit_id=audit_id,
            action_id=(
                audit_record.action_id if audit_record is not None else persisted_audit.action_id
            ),
            revert_status="reverted",
        )

    if persisted_audit is not None:
        turn = assistant_repository.get_turn(persisted_audit.thread_id, persisted_audit.turn_id)
        if turn is not None:
            updated_records = []
            for record in turn.action_records or []:
                if str(record.get("audit_id") or "") == audit_id:
                    updated_records.append({**record, "reverted": True, "status": "reverted"})
                else:
                    updated_records.append(record)
            assistant_repository.update_turn(
                persisted_audit.thread_id,
                persisted_audit.turn_id,
                outcome="reverted",
                action_records=updated_records,
            )

    return {
        "status": "reverted",
        "checkpoint_id": checkpoint_id,
        "files_restored": [
            f"{checkpoint.target_directory}/{relative_path}".replace("//", "/")
            for relative_path in checkpoint.files_before
        ],
        "correlation": {
            "action_id": "revert_file_action",
            "audit_id": audit_id,
            "checkpoint_id": checkpoint_id,
        },
    }
