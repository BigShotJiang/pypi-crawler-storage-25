"""Webhook registration and test-delivery routes."""

from __future__ import annotations

from datetime import datetime, timezone
from http import HTTPStatus
from typing import Any
from uuid import uuid4

from fastapi import APIRouter, HTTPException, Query, Request, Response, status
from pydantic import BaseModel, ConfigDict, Field

from obra.gateway.auth import get_request_owner_key
from obra.gateway.webhook.model import WebhookRegistration, validate_callback_url, validate_secret
from obra.gateway.workflow_studio.events import canonical_event_names_for_resource_type

router = APIRouter(prefix="/api/webhooks", tags=["webhooks"])

_ALLOWED_RESOURCE_TYPES = {"workflow_run", "workflow_derivation", "workflow"}


class CreateWebhookRequest(BaseModel):
    """Request body for webhook registration."""

    model_config = ConfigDict(extra="forbid")

    callback_url: str = Field(..., min_length=1)
    resource_type: str = Field(..., min_length=1)
    resource_id: str = Field(..., min_length=1)
    events: list[str] = Field(..., min_length=1)
    secret: str = Field(..., min_length=1)


def _webhook_store(request: Request) -> Any:
    return request.app.state.webhook_store


def _webhook_config(request: Request) -> dict[str, Any]:
    return dict(request.app.state.webhook_config)


def _owned_registration(request: Request, webhook_id: str) -> WebhookRegistration:
    owner_key = get_request_owner_key(request)
    registration = _webhook_store(request).get(webhook_id)
    if registration is None or registration.owner_key != owner_key:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Webhook not found",
        )
    return registration


def _validate_registration_request(body: CreateWebhookRequest) -> frozenset[str]:
    if body.resource_type not in _ALLOWED_RESOURCE_TYPES:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail="Invalid resource_type",
        )
    try:
        validate_callback_url(body.callback_url)
        validate_secret(body.secret)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=str(exc),
        ) from exc
    allowed_events = canonical_event_names_for_resource_type(body.resource_type)
    normalized_events = [event.strip() for event in body.events if event.strip()]
    if not normalized_events:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail="At least one event is required",
        )
    invalid_events = [event for event in normalized_events if event not in allowed_events]
    if invalid_events:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=f"Invalid events for resource_type={body.resource_type}: {invalid_events}",
        )
    body.events = normalized_events
    return allowed_events


def _test_envelope(registration: WebhookRegistration) -> dict[str, Any]:
    now = datetime.now(tz=timezone.utc).isoformat()
    correlation = {
        "workflow_run_id": registration.resource_id if registration.resource_type == "workflow_run" else None,
        "workflow_derivation_id": (
            registration.resource_id if registration.resource_type == "workflow_derivation" else None
        ),
        "workflow_id": registration.resource_id if registration.resource_type == "workflow" else None,
        "workflow_revision_id": None,
        "domain_id": None,
        "checkpoint_id": None,
        "escalation_id": None,
        "trace_id": None,
        "base_revision_id": None,
        "current_revision_id": None,
        "resulting_revision_id": None,
    }
    return {
        "resource_type": registration.resource_type,
        "event_id": f"webhook.test:{registration.webhook_id}",
        "event_name": "webhook.test",
        "sequence": 0,
        "timestamp": now,
        "workflow_run_id": correlation["workflow_run_id"],
        "workflow_derivation_id": correlation["workflow_derivation_id"],
        "payload": {
            "test": True,
            "webhook_id": registration.webhook_id,
            "resource_type": registration.resource_type,
            "resource_id": registration.resource_id,
        },
        "correlation": correlation,
    }


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_webhook(body: CreateWebhookRequest, request: Request) -> dict[str, Any]:
    _validate_registration_request(body)
    owner_key = get_request_owner_key(request)
    webhook_store = _webhook_store(request)
    webhook_config = _webhook_config(request)
    if webhook_store.count_for_owner(owner_key) >= int(webhook_config["max_per_owner"]):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Webhook registration limit reached for this owner",
        )

    registration = WebhookRegistration(
        webhook_id=str(uuid4()),
        owner_key=owner_key,
        callback_url=body.callback_url,
        resource_type=body.resource_type,
        resource_id=body.resource_id,
        events=list(body.events),
        secret=body.secret,
    )
    webhook_store.add(registration)
    return registration.to_summary_dict()


@router.get("/")
async def list_webhooks(
    request: Request,
    status_filter: str | None = Query(default=None, alias="status"),
) -> dict[str, Any]:
    owner_key = get_request_owner_key(request)
    include_expired = status_filter == "all"
    webhooks = _webhook_store(request).list_for_owner(owner_key, include_expired=include_expired)
    return {"webhooks": [registration.to_summary_dict() for registration in webhooks]}


@router.get("/{webhook_id}")
async def get_webhook_detail(webhook_id: str, request: Request) -> dict[str, Any]:
    return {"webhook": _owned_registration(request, webhook_id).to_detail_dict()}


@router.delete("/{webhook_id}", response_model=None)
async def delete_webhook(webhook_id: str, request: Request) -> Response:
    _owned_registration(request, webhook_id)
    deleted = _webhook_store(request).delete(webhook_id)
    if not deleted:
        raise HTTPException(status_code=HTTPStatus.NOT_FOUND, detail="Webhook not found")
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/{webhook_id}/test")
async def send_test_webhook(webhook_id: str, request: Request) -> dict[str, Any]:
    registration = _owned_registration(request, webhook_id)
    delivery_service = request.app.state.webhook_delivery_service
    result = await delivery_service.deliver(registration, _test_envelope(registration))
    return {
        "delivery_status": "success" if result.success else "failure",
        "status_code": result.status_code,
        "duration_ms": result.duration_ms,
        "error": result.error,
    }
