"""Workflow Studio voice transcription routes."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, File, HTTPException, Request, UploadFile, status

from obra.config.loaders import get_gateway_transcription_config
from obra.gateway.pagination import paginate_collection, pagination_params_from_request
from obra.gateway.workflow_studio.stt_provider import (
    get_stt_provider,
    get_voice_install_hint,
)

router = APIRouter(prefix="/api/transcription", tags=["transcription"])


def _unavailable_detail() -> str:
    return f"No STT provider available. Install faster-whisper with: {get_voice_install_hint()}"


def _transcription_config(request: Request) -> dict[str, Any]:
    config = getattr(request.app.state, "gateway_transcription_config", None)
    if not isinstance(config, dict):
        config = get_gateway_transcription_config()
        request.app.state.gateway_transcription_config = config
    return config


@router.post("/transcribe")
async def transcribe_audio(
    request: Request,
    file: UploadFile = File(...),
) -> dict[str, Any]:
    config = _transcription_config(request)
    audio_data = await file.read()
    if len(audio_data) > int(config["max_audio_bytes"]):
        raise HTTPException(
            status_code=status.HTTP_413_CONTENT_TOO_LARGE,
            detail="Audio payload exceeds configured limit",
        )

    provider = get_stt_provider(request.app.state)
    if provider is None or not provider.is_available():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=_unavailable_detail(),
        )

    text = provider.transcribe(audio_data, file.content_type or "audio/webm")
    return {"text": text, "provider": str(config["provider"])}


@router.get("/providers")
async def list_providers(request: Request) -> dict[str, Any]:
    config = _transcription_config(request)
    provider = get_stt_provider(request.app.state)
    provider_id = str(config["provider"])
    available = provider is not None and provider.is_available()
    provider_payload: dict[str, Any] = {
        "id": provider_id,
        "name": "Local Whisper" if provider_id == "local-whisper" else provider_id,
        "status": "available" if available else "unavailable",
        "requires_credentials": False,
    }
    if not available:
        provider_payload["unavailable_reason"] = "Local Whisper is not installed"
        provider_payload["install_hint"] = get_voice_install_hint()
    return paginate_collection(
        collection_key="providers",
        items=[provider_payload],
        params=pagination_params_from_request(request),
    )
