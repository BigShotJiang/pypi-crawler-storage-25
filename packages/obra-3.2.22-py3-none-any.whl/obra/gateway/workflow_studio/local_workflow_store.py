"""Local persisted workflow store for Workflow Studio."""

from __future__ import annotations

from copy import deepcopy
from datetime import UTC, datetime
import json
import logging
from pathlib import Path
import threading
from typing import Any
from urllib.parse import quote

from obra.utils.obra_home import get_runtime_dir
from obra.workflow.workflow_mutation_engine import CanonicalWorkflowMutationEngine

logger = logging.getLogger(__name__)


class LocalWorkflowStore:
    """Persist canonical workflow heads and revisions under the runtime directory."""

    def __init__(self, storage_dir: Path | None = None) -> None:
        self._storage_dir = storage_dir or (get_runtime_dir() / "workflows")
        self._lock = threading.RLock()
        self._engine = CanonicalWorkflowMutationEngine(self)

    def list_workflows(
        self,
        *,
        include_archived: bool = False,
        include_deleted: bool = False,
    ) -> list[dict[str, Any]]:
        """List persisted workflow heads."""
        with self._lock:
            workflows: list[dict[str, Any]] = []
            for path in self._snapshot_paths():
                snapshot = self._read_snapshot(path)
                workflow = dict(snapshot.get("workflow") or {})
                if not workflow:
                    continue
                if workflow.get("deleted_at") and not include_deleted:
                    continue
                if workflow.get("archived_at") and not include_archived:
                    continue
                workflows.append(deepcopy(workflow))
            return sorted(
                workflows,
                key=lambda workflow: (
                    str(workflow.get("updated_at") or ""),
                    str(workflow.get("workflow_id") or ""),
                ),
                reverse=True,
            )

    def get_workflow_head(self, workflow_id: str) -> dict[str, Any] | None:
        """Return one persisted workflow head."""
        with self._lock:
            snapshot = self._load_snapshot(workflow_id)
            if snapshot is None:
                return None
            workflow = snapshot.get("workflow")
            return deepcopy(workflow) if isinstance(workflow, dict) else None

    def list_workflow_revisions(self, workflow_id: str) -> list[dict[str, Any]]:
        """Return one workflow's persisted revisions."""
        with self._lock:
            snapshot = self._load_snapshot(workflow_id)
            if snapshot is None:
                return []
            revisions = snapshot.get("revisions")
            if not isinstance(revisions, list):
                return []
            payloads = [deepcopy(item) for item in revisions if isinstance(item, dict)]
            return sorted(
                payloads,
                key=lambda revision: str(revision.get("revision_id") or ""),
                reverse=True,
            )

    def get_workflow_revision(
        self,
        workflow_id: str,
        revision_id: str,
    ) -> dict[str, Any] | None:
        """Return one persisted workflow revision."""
        revisions = self.list_workflow_revisions(workflow_id)
        for revision in revisions:
            if str(revision.get("revision_id") or "") == revision_id:
                return revision
        return None

    def get_workflow_seed(self, workflow_id: str) -> dict[str, Any] | None:
        """Return the persisted canonical workflow seed document."""
        workflow = self.get_workflow_head(workflow_id)
        if not isinstance(workflow, dict):
            return None
        metadata = workflow.get("metadata")
        if not isinstance(metadata, dict):
            return None
        seed = metadata.get("seed")
        return dict(seed) if isinstance(seed, dict) else None

    def set_workflow_seed(self, workflow_id: str, seed: dict[str, Any]) -> dict[str, Any]:
        """Persist a canonical workflow seed document onto the current head."""
        with self._lock:
            snapshot = self._load_snapshot(workflow_id)
            if snapshot is None:
                raise ValueError(f"Workflow not found: {workflow_id}")
            workflow = dict(snapshot.get("workflow") or {})
            if not workflow:
                raise ValueError(f"Malformed workflow payload: {workflow_id}")
            metadata = workflow.get("metadata")
            normalized_metadata = dict(metadata) if isinstance(metadata, dict) else {}
            normalized_metadata["seed"] = dict(seed)
            workflow["metadata"] = normalized_metadata
            workflow["updated_at"] = datetime.now(UTC).isoformat()

            head_revision_id = str(
                workflow.get("head_revision_id")
                or workflow.get("revision_id")
                or ""
            ).strip()
            revisions: list[dict[str, Any]] = []
            for item in snapshot.get("revisions", []):
                if not isinstance(item, dict):
                    continue
                revision = deepcopy(item)
                revision_id = str(revision.get("revision_id") or "").strip()
                if revision_id and revision_id == head_revision_id:
                    revision_metadata = revision.get("metadata")
                    normalized_revision_metadata = (
                        dict(revision_metadata) if isinstance(revision_metadata, dict) else {}
                    )
                    normalized_revision_metadata["seed"] = dict(seed)
                    revision["metadata"] = normalized_revision_metadata
                    revision["updated_at"] = workflow["updated_at"]
                revisions.append(revision)
            self._write_snapshot(
                workflow_id,
                {
                    "workflow": workflow,
                    "revisions": revisions,
                },
            )
            return deepcopy(workflow)

    def create_workflow_revision(
        self,
        workflow_id: str,
        revision_id: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Create a new workflow head and first revision."""
        with self._lock:
            if self._load_snapshot(workflow_id) is not None:
                raise ValueError(f"Workflow already exists: {workflow_id}")
            now = datetime.now(UTC).isoformat()
            stored_payload = self._normalize_revision_payload(
                workflow_id,
                revision_id,
                payload,
                head_revision_id=revision_id,
                created_at=str(payload.get("created_at") or now),
                updated_at=str(payload.get("updated_at") or now),
            )
            self._write_snapshot(
                workflow_id,
                {
                    "workflow": stored_payload,
                    "revisions": [stored_payload],
                },
            )
            return deepcopy(stored_payload)

    def apply_workflow_revision(
        self,
        workflow_id: str,
        revision_id: str,
        payload: dict[str, Any],
        *,
        expected_revision_id: str | None = None,
    ) -> dict[str, Any]:
        """Persist a new canonical head revision."""
        with self._lock:
            snapshot = self._load_snapshot(workflow_id)
            if snapshot is None:
                raise ValueError(f"Workflow not found: {workflow_id}")
            current_payload = dict(snapshot.get("workflow") or {})
            current_revision_id = str(
                current_payload.get("head_revision_id")
                or current_payload.get("revision_id")
                or ""
            ).strip()
            normalized_expected = str(expected_revision_id or "").strip()
            if normalized_expected and current_revision_id != normalized_expected:
                raise ValueError(
                    "Workflow revision conflict: "
                    f"expected {normalized_expected}, current {current_revision_id}"
                )

            now = datetime.now(UTC).isoformat()
            stored_payload = self._normalize_revision_payload(
                workflow_id,
                revision_id,
                {
                    **payload,
                    "previous_revision_id": current_revision_id,
                    "archived_at": current_payload.get("archived_at"),
                    "deleted_at": current_payload.get("deleted_at"),
                    "deleted_by": current_payload.get("deleted_by"),
                },
                head_revision_id=revision_id,
                created_at=str(current_payload.get("created_at") or payload.get("created_at") or now),
                updated_at=str(payload.get("updated_at") or now),
            )

            revisions = [
                self._normalize_revision_payload(
                    str(item.get("workflow_id") or workflow_id),
                    str(item.get("revision_id") or ""),
                    item,
                    head_revision_id=str(item.get("head_revision_id") or item.get("revision_id") or ""),
                    created_at=str(item.get("created_at") or now),
                    updated_at=str(item.get("updated_at") or now),
                )
                for item in snapshot.get("revisions", [])
                if isinstance(item, dict)
            ]
            revisions = [
                revision
                for revision in revisions
                if str(revision.get("revision_id") or "") != revision_id
            ]
            revisions.append(deepcopy(stored_payload))
            revisions.sort(key=lambda revision: str(revision.get("revision_id") or ""))
            self._write_snapshot(
                workflow_id,
                {
                    "workflow": stored_payload,
                    "revisions": revisions,
                },
            )
            return deepcopy(stored_payload)

    def archive_workflow(self, workflow_id: str) -> dict[str, Any]:
        """Archive one workflow head."""
        return self._update_workflow_head(
            workflow_id,
            archived_at=datetime.now(UTC).isoformat(),
        )

    def restore_workflow(self, workflow_id: str) -> dict[str, Any]:
        """Restore one archived or soft-deleted workflow head."""
        return self._update_workflow_head(
            workflow_id,
            archived_at=None,
            deleted_at=None,
            deleted_by=None,
        )

    def soft_delete_workflow(self, workflow_id: str) -> dict[str, Any]:
        """Soft-delete one workflow head."""
        return self._update_workflow_head(
            workflow_id,
            deleted_at=datetime.now(UTC).isoformat(),
            deleted_by="user",
        )

    def hard_delete_workflow(self, workflow_id: str) -> None:
        """Delete one workflow snapshot permanently."""
        with self._lock:
            path = self._snapshot_path(workflow_id)
            if not path.exists():
                raise ValueError(f"Workflow not found: {workflow_id}")
            path.unlink()

    def create_workflow(self, candidate: dict[str, Any]) -> dict[str, Any]:
        """Create a workflow through the shared canonical mutation engine."""
        return self._engine.create_workflow(candidate)

    def validate_workflow_candidate(
        self,
        candidate: dict[str, Any],
        *,
        expected_revision_id: str | None = None,
    ) -> dict[str, Any]:
        """Validate a workflow candidate through canonical shared logic."""
        return self._engine.validate_candidate(candidate, expected_revision_id=expected_revision_id)

    def apply_workflow_candidate(
        self,
        candidate: dict[str, Any],
        *,
        expected_revision_id: str | None = None,
    ) -> dict[str, Any]:
        """Apply a workflow candidate through canonical shared logic."""
        return self._engine.apply_candidate(candidate, expected_revision_id=expected_revision_id)

    def store_snapshot(
        self,
        workflow: dict[str, Any],
        revisions: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Replace one workflow snapshot with canonical payloads."""
        with self._lock:
            workflow_id = str(workflow.get("workflow_id") or "").strip()
            if not workflow_id:
                raise ValueError("Workflow snapshot is missing workflow_id")
            normalized_revisions = [
                self._normalize_revision_payload(
                    workflow_id,
                    str(revision.get("revision_id") or ""),
                    revision,
                    head_revision_id=str(
                        revision.get("head_revision_id")
                        or revision.get("revision_id")
                        or ""
                    ),
                    created_at=str(revision.get("created_at") or ""),
                    updated_at=str(revision.get("updated_at") or ""),
                )
                for revision in revisions
                if isinstance(revision, dict) and str(revision.get("revision_id") or "").strip()
            ]
            if not normalized_revisions:
                revision_id = str(
                    workflow.get("head_revision_id")
                    or workflow.get("revision_id")
                    or ""
                ).strip()
                if revision_id:
                    normalized_revisions = [
                        self._normalize_revision_payload(
                            workflow_id,
                            revision_id,
                            workflow,
                            head_revision_id=revision_id,
                            created_at=str(workflow.get("created_at") or ""),
                            updated_at=str(workflow.get("updated_at") or ""),
                        )
                    ]
            normalized_revisions.sort(key=lambda revision: str(revision.get("revision_id") or ""))
            head_revision_id = str(
                workflow.get("head_revision_id")
                or workflow.get("revision_id")
                or (
                    normalized_revisions[-1].get("revision_id")
                    if normalized_revisions
                    else ""
                )
            ).strip()
            normalized_workflow = self._normalize_revision_payload(
                workflow_id,
                str(workflow.get("revision_id") or head_revision_id),
                workflow,
                head_revision_id=head_revision_id,
                created_at=str(
                    workflow.get("created_at")
                    or (normalized_revisions[0].get("created_at") if normalized_revisions else "")
                ),
                updated_at=str(
                    workflow.get("updated_at")
                    or (normalized_revisions[-1].get("updated_at") if normalized_revisions else "")
                ),
            )
            self._write_snapshot(
                workflow_id,
                {
                    "workflow": normalized_workflow,
                    "revisions": normalized_revisions,
                },
            )
            return deepcopy(normalized_workflow)

    def export_snapshot(self) -> dict[str, Any]:
        """Export all local workflow snapshots."""
        with self._lock:
            workflows: list[dict[str, Any]] = []
            for path in self._snapshot_paths():
                snapshot = self._read_snapshot(path)
                workflow = snapshot.get("workflow")
                if not isinstance(workflow, dict):
                    continue
                revisions = snapshot.get("revisions")
                workflows.append(
                    {
                        "workflow": deepcopy(workflow),
                        "revisions": [
                            deepcopy(item) for item in revisions if isinstance(item, dict)
                        ],
                    }
                )
            workflows.sort(key=lambda item: str(item["workflow"].get("workflow_id") or ""))
            return {
                "resource_type": "workflow_snapshot_export",
                "schema_version": 1,
                "exported_at": datetime.now(UTC).isoformat(),
                "workflows": workflows,
            }

    def import_snapshot(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Import previously exported workflow snapshots."""
        entries = payload.get("workflows")
        if not isinstance(entries, list):
            raise ValueError("Snapshot import requires a workflows list")
        imported = 0
        skipped = 0
        errors = 0
        error_messages: list[str] = []
        ordered_entries = sorted(
            [entry for entry in entries if isinstance(entry, dict)],
            key=lambda item: str((item.get("workflow") or {}).get("workflow_id") or ""),
        )
        for entry in ordered_entries:
            workflow = entry.get("workflow")
            revisions = entry.get("revisions")
            workflow_id = str((workflow or {}).get("workflow_id") or "").strip()
            if not workflow_id:
                errors += 1
                error_messages.append("Missing workflow_id in imported snapshot entry")
                continue
            if self.get_workflow_head(workflow_id) is not None:
                skipped += 1
                continue
            try:
                if not isinstance(workflow, dict):
                    raise ValueError(f"Imported workflow {workflow_id} is malformed")
                if not isinstance(revisions, list):
                    raise ValueError(f"Imported workflow {workflow_id} is missing revisions")
                self.store_snapshot(workflow, revisions)
                imported += 1
            except Exception as exc:
                errors += 1
                error_messages.append(f"{workflow_id}: {exc}")
        return {
            "resource_type": "workflow_snapshot_import",
            "schema_version": 1,
            "imported_count": imported,
            "skipped_count": skipped,
            "error_count": errors,
            "errors": error_messages,
        }

    def sync_from_remote(self, api_client: Any) -> dict[str, Any]:
        """Hydrate local snapshots from the remote workflow store."""
        response = api_client.list_workflows(include_archived=True, include_deleted=True)
        workflows = response.get("workflows")
        if not isinstance(workflows, list):
            raise ValueError("Remote workflow listing did not return workflows")
        synced = 0
        for workflow in sorted(
            [item for item in workflows if isinstance(item, dict)],
            key=lambda item: str(item.get("workflow_id") or ""),
        ):
            workflow_id = str(workflow.get("workflow_id") or "").strip()
            if not workflow_id:
                continue
            revisions_response = api_client.list_workflow_revisions(workflow_id)
            revisions = revisions_response.get("revisions")
            if not isinstance(revisions, list):
                raise ValueError(f"Remote revisions did not return a list for {workflow_id}")
            self.store_snapshot(workflow, [item for item in revisions if isinstance(item, dict)])
            synced += 1
        return {
            "resource_type": "workflow_snapshot_sync",
            "schema_version": 1,
            "synced_count": synced,
        }

    def _update_workflow_head(
        self,
        workflow_id: str,
        **updates: str | None,
    ) -> dict[str, Any]:
        with self._lock:
            snapshot = self._load_snapshot(workflow_id)
            if snapshot is None:
                raise ValueError(f"Workflow not found: {workflow_id}")
            workflow = dict(snapshot.get("workflow") or {})
            if not workflow:
                raise ValueError(f"Malformed workflow payload: {workflow_id}")
            workflow["updated_at"] = datetime.now(UTC).isoformat()
            for key, value in updates.items():
                if value is None:
                    workflow.pop(key, None)
                else:
                    workflow[key] = value
            self._write_snapshot(
                workflow_id,
                {
                    "workflow": workflow,
                    "revisions": [
                        deepcopy(item)
                        for item in snapshot.get("revisions", [])
                        if isinstance(item, dict)
                    ],
                },
            )
            return deepcopy(workflow)

    def _load_snapshot(self, workflow_id: str) -> dict[str, Any] | None:
        path = self._snapshot_path(workflow_id)
        if not path.exists():
            return None
        return self._read_snapshot(path)

    def _read_snapshot(self, path: Path) -> dict[str, Any]:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"Malformed local workflow snapshot: {path}") from exc
        if not isinstance(data, dict):
            raise ValueError(f"Malformed local workflow snapshot: {path}")
        workflow = data.get("workflow")
        revisions = data.get("revisions")
        if not isinstance(workflow, dict) or not isinstance(revisions, list):
            raise ValueError(f"Malformed local workflow snapshot: {path}")
        return data

    def _write_snapshot(self, workflow_id: str, payload: dict[str, Any]) -> None:
        self._ensure_storage_dir()
        path = self._snapshot_path(workflow_id)
        tmp_path = path.with_suffix(".tmp")
        tmp_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        tmp_path.replace(path)

    def _snapshot_paths(self) -> list[Path]:
        if not self._storage_dir.exists():
            return []
        return sorted(self._storage_dir.glob("*.json"))

    def _ensure_storage_dir(self) -> None:
        self._storage_dir.mkdir(parents=True, exist_ok=True)

    def _snapshot_path(self, workflow_id: str) -> Path:
        return self._storage_dir / f"{quote(workflow_id, safe='-_.')}.json"

    @staticmethod
    def _normalize_revision_payload(
        workflow_id: str,
        revision_id: str,
        payload: dict[str, Any],
        *,
        head_revision_id: str,
        created_at: str,
        updated_at: str,
    ) -> dict[str, Any]:
        if not revision_id:
            raise ValueError(f"Workflow {workflow_id} snapshot is missing revision_id")
        normalized = dict(payload)
        normalized["workflow_id"] = workflow_id
        normalized["revision_id"] = revision_id
        normalized["head_revision_id"] = head_revision_id or revision_id
        if created_at:
            normalized["created_at"] = created_at
        if updated_at:
            normalized["updated_at"] = updated_at
        return normalized
