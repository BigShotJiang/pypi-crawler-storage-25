"""Cross-run comparison projections for Workflow Studio."""

from __future__ import annotations

from typing import Any

from obra.gateway.workflow_studio.artifacts import resolve_artifact_content
from obra.gateway.workflow_studio.data_access import (
    WorkflowStudioRunBundle,
    workflow_identity_from_sources,
)


def align_stages(bundles: list[WorkflowStudioRunBundle]) -> list[dict[str, Any]]:
    """Align pipeline stages across runs using stage name as the primary identity."""
    stage_names: list[str] = []
    stage_maps = [_stage_map(bundle) for bundle in bundles]
    for bundle in bundles:
        for stage in bundle.pipeline_stages:
            stage_name = _stage_name(stage)
            if stage_name and stage_name not in stage_names:
                stage_names.append(stage_name)

    alignments: list[dict[str, Any]] = []
    for stage_name in stage_names:
        runs: dict[str, dict[str, Any] | None] = {}
        present = []
        for bundle, stage_map in zip(bundles, stage_maps, strict=False):
            run_id = _bundle_run_id(bundle)
            stage = stage_map.get(stage_name)
            runs[run_id] = stage
            present.append(stage is not None)
        alignment_type = _alignment_type(present)
        alignments.append(
            {
                "stage_name": stage_name,
                "alignment_type": alignment_type,
                "runs": runs,
            }
        )
    return alignments


def build_run_comparison(bundles: list[WorkflowStudioRunBundle]) -> dict[str, Any]:
    """Build a structured comparison payload across workflow runs."""
    runs = [
        {
            "run_id": _bundle_run_id(bundle),
            "workflow_ref": workflow_identity_from_sources(bundle.record, bundle.remote_session),
            "status": bundle.record.status,
            "created_at": bundle.record.created_at.isoformat(),
        }
        for bundle in bundles
    ]

    stage_alignment: list[dict[str, Any]] = []
    for aligned in align_stages(bundles):
        stage_name = str(aligned.get("stage_name") or "")
        run_entries: dict[str, Any] = {}
        positions: dict[str, int | None] = {}
        statuses: dict[str, str | None] = {}
        verdicts: dict[str, str | None] = {}
        runners: dict[str, str | None] = {}

        for bundle in bundles:
            run_id = _bundle_run_id(bundle)
            stage = (
                aligned.get("runs", {}).get(run_id)
                if isinstance(aligned.get("runs"), dict)
                else None
            )
            position = _stage_position(bundle, stage_name)
            positions[run_id] = position
            projected = _project_aligned_stage(bundle, stage_name, stage, position=position)
            run_entries[run_id] = projected
            statuses[run_id] = projected.get("status")
            verdicts[run_id] = projected.get("loop_verdict")
            runners[run_id] = projected.get("runner_id")

        stage_alignment.append(
            {
                "stage_name": stage_name,
                "alignment_type": aligned.get("alignment_type"),
                "delta": {
                    "status_changed": _distinct_non_null_count(statuses.values()) > 1,
                    "loop_verdict_changed": _distinct_non_null_count(verdicts.values()) > 1,
                    "runner_changed": _distinct_non_null_count(runners.values()) > 1,
                    "reordered": _distinct_non_null_count(positions.values()) > 1,
                },
                "runs": run_entries,
            }
        )

    return {
        "resource_type": "workflow_run_comparison",
        "runs": runs,
        "stage_alignment": stage_alignment,
        "revision_chain": _build_revision_chain(bundles),
    }


def _alignment_type(present: list[bool]) -> str:
    if present and all(present):
        return "matched"
    if present and present[0]:
        return "removed"
    return "added"


def _build_revision_chain(bundles: list[WorkflowStudioRunBundle]) -> list[dict[str, Any]]:
    chain: dict[tuple[str, str], dict[str, Any]] = {}
    sorted_bundles = sorted(
        bundles,
        key=lambda bundle: (
            bundle.record.created_at.isoformat(),
            _bundle_run_id(bundle),
        ),
    )
    for bundle in sorted_bundles:
        workflow_ref = workflow_identity_from_sources(bundle.record, bundle.remote_session)
        workflow_id = str(workflow_ref.get("workflow_id") or "")
        revision_id = str(workflow_ref.get("revision_id") or "")
        if not workflow_id or not revision_id:
            continue
        key = (workflow_id, revision_id)
        baseline = (
            bundle.remote_session.get("workflow_derivation_state")
            if isinstance(bundle.remote_session.get("workflow_derivation_state"), dict)
            else {}
        )
        expected_baseline = (
            baseline.get("expected_baseline_ref")
            if isinstance(baseline.get("expected_baseline_ref"), dict)
            else {}
        )
        entry = chain.setdefault(
            key,
            {
                "workflow_id": workflow_id,
                "revision_id": revision_id,
                "previous_revision_id": "",
                "created_at": bundle.record.created_at.isoformat(),
                "run_ids": [],
            },
        )
        previous_revision_id = str(
            expected_baseline.get("revision_id") or expected_baseline.get("version") or ""
        ).strip()
        if previous_revision_id and not entry["previous_revision_id"]:
            entry["previous_revision_id"] = previous_revision_id
        if _bundle_run_id(bundle) not in entry["run_ids"]:
            entry["run_ids"].append(_bundle_run_id(bundle))

    return list(chain.values())


def _bundle_run_id(bundle: WorkflowStudioRunBundle) -> str:
    return str(bundle.record.workflow_run_id or bundle.record.session_id)


def _project_aligned_stage(
    bundle: WorkflowStudioRunBundle,
    stage_name: str,
    stage: dict[str, Any] | None,
    *,
    position: int | None,
) -> dict[str, Any]:
    if stage is None:
        return {
            "stage_execution_id": None,
            "status": None,
            "loop_verdict": None,
            "runner_id": None,
            "position": position,
            "artifact_refs": [],
            "content_preview": None,
        }

    artifact_ids = _stage_output_artifact_ids(bundle, stage_name)
    content_preview: str | None = None
    if artifact_ids:
        content = resolve_artifact_content(bundle, artifact_ids[0])
        if content is not None:
            content_preview = content[:2000]

    return {
        "stage_execution_id": stage.get("stage_execution_id"),
        "status": stage.get("status"),
        "loop_verdict": _loop_verdict(stage),
        "runner_id": _runner_id(stage),
        "position": position,
        "artifact_refs": artifact_ids,
        "content_preview": content_preview,
    }


def _stage_map(bundle: WorkflowStudioRunBundle) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for stage in bundle.pipeline_stages:
        stage_name = _stage_name(stage)
        if stage_name and stage_name not in result:
            result[stage_name] = stage
    return result


def _stage_name(stage: dict[str, Any]) -> str:
    return str(stage.get("stage_name") or stage.get("trigger") or "").strip()


def _stage_position(bundle: WorkflowStudioRunBundle, stage_name: str) -> int | None:
    for index, stage in enumerate(bundle.pipeline_stages):
        if _stage_name(stage) == stage_name:
            return index
    return None


def _stage_output_artifact_ids(
    bundle: WorkflowStudioRunBundle,
    stage_name: str,
) -> list[str]:
    artifact_ids: list[str] = []
    for artifact in bundle.workflow_artifacts:
        if str(artifact.get("artifact_type") or "").strip() != "stage_output":
            continue
        runtime_metadata = (
            artifact.get("runtime_metadata")
            if isinstance(artifact.get("runtime_metadata"), dict)
            else {}
        )
        if str(runtime_metadata.get("stage_name") or "").strip() != stage_name:
            continue
        artifact_id = str(artifact.get("artifact_id") or "").strip()
        if artifact_id:
            artifact_ids.append(artifact_id)
    return artifact_ids


def _loop_verdict(stage: dict[str, Any]) -> str | None:
    direct_value = str(stage.get("loop_verdict") or "").strip()
    if direct_value:
        return direct_value
    loop_signal = stage.get("loop_signal") if isinstance(stage.get("loop_signal"), dict) else {}
    signal_value = str(loop_signal.get("loop_verdict") or "").strip()
    return signal_value or None


def _runner_id(stage: dict[str, Any]) -> str | None:
    direct_value = str(stage.get("runner_id") or "").strip()
    if direct_value:
        return direct_value
    runner = stage.get("runner") if isinstance(stage.get("runner"), dict) else {}
    runner_value = str(runner.get("runner_id") or "").strip()
    return runner_value or None


def _distinct_non_null_count(values: Any) -> int:
    return len({value for value in values if value not in {None, ""}})
