"""Replay projections for Workflow Studio Stage A."""

from __future__ import annotations

from typing import Any

from obra.gateway.workflow_studio.data_access import WorkflowStudioRunBundle
from obra.gateway.workflow_studio.events import build_event_envelope


def build_replay_payload(bundle: WorkflowStudioRunBundle) -> dict[str, Any]:
    """Build canonical replay payload from retained or persisted events."""
    entries: list[dict[str, Any]] = []
    for index, event in enumerate(bundle.remote_events):
        envelope = build_event_envelope(
            event,
            run_id=bundle.record.workflow_run_id,
            record=bundle.record,
        )
        raw_sequence = event.get("sequence")
        envelope["sequence"] = raw_sequence if isinstance(raw_sequence, int) else index
        entries.append(
            {
                "replay_entry_id": f"{bundle.record.workflow_run_id}:replay:{envelope['sequence']}",
                **envelope,
            }
        )
    return {
        "resource_type": "workflow_replay",
        "workflow_run_id": bundle.record.workflow_run_id,
        "entries": entries,
        "count": len(entries),
    }
