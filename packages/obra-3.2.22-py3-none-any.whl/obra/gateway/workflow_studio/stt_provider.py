"""Speech-to-text provider helpers for Workflow Studio voice input."""

from __future__ import annotations

import importlib
import logging
import os
import tempfile
from typing import Any, Protocol

from obra.config.loaders import get_gateway_transcription_config

logger = logging.getLogger(__name__)

_INITIAL_PROMPT = "Workflow, YAML, API, OAuth, stage, derivation, Firestore"


def get_voice_install_hint() -> str:
    """Return the most appropriate local install hint for voice support."""
    from obra.install_guidance import recommended_voice_install_hint

    return recommended_voice_install_hint()


class STTProvider(Protocol):
    """Protocol for gateway speech-to-text providers."""

    def is_available(self) -> bool:
        """Return True when the provider can transcribe audio."""

    def transcribe(self, audio_data: bytes, content_type: str) -> str:
        """Transcribe uploaded audio bytes into text."""


class LocalWhisperProvider:
    """Local `faster-whisper` implementation with lazy model loading."""

    def __init__(self, model_size: str = "base") -> None:
        self._model_size = model_size
        self._model: Any | None = None

    def is_available(self) -> bool:
        try:
            importlib.import_module("faster_whisper")
        except ImportError:
            return False
        return True

    def _load_model(self) -> Any:
        if self._model is not None:
            return self._model
        module = importlib.import_module("faster_whisper")
        whisper_model = module.WhisperModel
        self._model = whisper_model(self._model_size, device="cpu", compute_type="int8")
        return self._model

    def transcribe(self, audio_data: bytes, content_type: str) -> str:
        del content_type
        path: str | None = None
        try:
            model = self._load_model()
            with tempfile.NamedTemporaryFile(
                delete=False,
                suffix=".webm",
            ) as handle:
                handle.write(audio_data)
                path = handle.name
            segments, _info = model.transcribe(
                path,
                beam_size=5,
                initial_prompt=_INITIAL_PROMPT,
            )
            text = " ".join(
                segment_text
                for segment_text in (
                    str(getattr(segment, "text", "")).strip() for segment in segments
                )
                if segment_text
            ).strip()
            return text
        except ImportError as exc:
            raise RuntimeError(
                f"faster-whisper not installed. Install with: {get_voice_install_hint()}"
            ) from exc
        except Exception:
            logger.warning("Voice transcription failed", exc_info=True)
            raise
        finally:
            if path:
                try:
                    os.unlink(path)
                except FileNotFoundError:
                    pass


def get_stt_provider(app_state: Any) -> STTProvider | None:
    """Return the configured STT provider for the current app state."""
    config = getattr(app_state, "gateway_transcription_config", None)
    if not isinstance(config, dict):
        config = get_gateway_transcription_config()
        app_state.gateway_transcription_config = config

    provider_name = str(config["provider"]).strip()
    model_size = str(config["model_size"]).strip()
    cached_provider = getattr(app_state, "stt_provider", None)
    cached_key = getattr(app_state, "stt_provider_cache_key", None)
    cache_key = (provider_name, model_size)
    if cached_provider is not None and cached_key == cache_key:
        return cached_provider if cached_provider.is_available() else None

    if provider_name != "local-whisper":
        logger.warning("Unsupported STT provider configured: %s", provider_name)
        return None

    provider = LocalWhisperProvider(model_size=model_size)
    if not provider.is_available():
        return None

    app_state.stt_provider = provider
    app_state.stt_provider_cache_key = cache_key
    return provider
