"""Gateway-side workflow mutation service for Workflow Studio Stage C."""

from __future__ import annotations

import logging
from typing import Any, Callable

from obra.api import APIClient
from obra.api.protocol_workflow import WorkflowCandidateEnvelope
from obra.gateway.workflow_studio.local_workflow_store import LocalWorkflowStore

logger = logging.getLogger(__name__)


class WorkflowActionService:
    """Dispatch canonical workflow create, validate, and apply flows."""

    def __init__(
        self,
        *,
        client_factory: Callable[[], APIClient] | None = None,
        local_store: LocalWorkflowStore | None = None,
        workflow_storage: str = "cloud",
        workflow_run_count_resolver: Callable[[str], int] | None = None,
    ) -> None:
        self._client_factory = client_factory or APIClient.from_config
        self._local_store = local_store
        self._workflow_storage = workflow_storage
        self._workflow_run_count_resolver = workflow_run_count_resolver
        self._client: APIClient | None = None

    def create_workflow(self, candidate: dict[str, Any]) -> dict[str, Any]:
        """Create a canonical workflow."""
        payload = self._candidate_payload(
            workflow_id=str(candidate.get("workflow_id") or ""),
            candidate=candidate,
            expected_revision_id=None,
        )
        if self._local_store is None:
            return self._get_client().create_workflow(payload)
        local_result = self._create_locally(payload)
        if not self._uses_remote_workflow_store():
            return local_result
        remote_payload = dict(payload)
        local_workflow_id = self._workflow_id_from_result(local_result)
        if local_workflow_id:
            remote_payload["workflow_id"] = local_workflow_id
        remote_result = self._write_remote_result(
            "create",
            local_result=local_result,
            remote_call=lambda client: client.create_workflow(remote_payload),
        )
        self._reconcile_remote_snapshot(
            remote_result,
            local_result=local_result,
        )
        return remote_result

    def archive_workflow(self, workflow_id: str) -> dict[str, Any]:
        """Archive one canonical workflow."""
        if self._local_store is None:
            return self._get_client().archive_workflow(workflow_id)
        local_result = self._archive_locally(workflow_id)
        if not self._uses_remote_workflow_store():
            return local_result
        remote_result = self._write_remote_result(
            "archive",
            workflow_id=workflow_id,
            local_result=local_result,
            remote_call=lambda client: client.archive_workflow(workflow_id),
        )
        self._reconcile_remote_snapshot(remote_result, local_result=local_result)
        return remote_result

    def restore_workflow(self, workflow_id: str) -> dict[str, Any]:
        """Restore one archived or soft-deleted workflow."""
        if self._local_store is None:
            return self._get_client().restore_workflow(workflow_id)
        local_result = self._restore_locally(workflow_id)
        if not self._uses_remote_workflow_store():
            return local_result
        remote_result = self._write_remote_result(
            "restore",
            workflow_id=workflow_id,
            local_result=local_result,
            remote_call=lambda client: client.restore_workflow(workflow_id),
        )
        self._reconcile_remote_snapshot(remote_result, local_result=local_result)
        return remote_result

    def soft_delete_workflow(self, workflow_id: str) -> dict[str, Any]:
        """Move one canonical workflow to trash."""
        if self._local_store is None:
            return self._get_client().soft_delete_workflow(workflow_id)
        local_result = self._soft_delete_locally(workflow_id)
        if not self._uses_remote_workflow_store():
            return local_result
        remote_result = self._write_remote_result(
            "soft-delete",
            workflow_id=workflow_id,
            local_result=local_result,
            remote_call=lambda client: client.soft_delete_workflow(workflow_id),
        )
        self._reconcile_remote_snapshot(remote_result, local_result=local_result)
        return remote_result

    def hard_delete_workflow(self, workflow_id: str) -> None:
        """Permanently delete one canonical workflow."""
        if self._local_store is not None:
            self._local_store.hard_delete_workflow(workflow_id)
        elif not self._uses_remote_workflow_store():
            raise ValueError(f"Workflow not found: {workflow_id}")
        if not self._uses_remote_workflow_store():
            return
        client = self._get_client_or_none()
        if client is None:
            return
        try:
            client.hard_delete_workflow(workflow_id)
        except Exception as exc:
            logger.warning(
                "Remote hard-delete failed for workflow %s; local deletion remains authoritative: %s",
                workflow_id,
                exc,
            )

    def validate_workflow(
        self,
        workflow_id: str,
        candidate: dict[str, Any],
        *,
        expected_revision_id: str | None = None,
    ) -> dict[str, Any]:
        """Validate a canonical workflow candidate."""
        payload = self._candidate_payload(
            workflow_id=workflow_id,
            candidate=candidate,
            expected_revision_id=expected_revision_id,
        )
        if self._local_store is None:
            return self._get_client().validate_workflow_candidate(
                payload,
                expected_revision_id=expected_revision_id,
            )
        if workflow_id and not self._ensure_local_head(workflow_id):
            client = self._get_client_or_none()
            if client is not None:
                return client.validate_workflow_candidate(
                    payload,
                    expected_revision_id=expected_revision_id,
                )
        return self._local_store.validate_workflow_candidate(
            payload,
            expected_revision_id=expected_revision_id,
        )

    def apply_workflow(
        self,
        workflow_id: str,
        candidate: dict[str, Any],
        *,
        expected_revision_id: str | None = None,
    ) -> dict[str, Any]:
        """Apply a guarded canonical workflow candidate."""
        payload = self._candidate_payload(
            workflow_id=workflow_id,
            candidate=candidate,
            expected_revision_id=expected_revision_id,
        )
        if self._local_store is None:
            return self._get_client().apply_workflow_candidate(
                payload,
                expected_revision_id=expected_revision_id,
            )
        if workflow_id and not self._ensure_local_head(workflow_id):
            client = self._get_client_or_none()
            if client is not None:
                return client.apply_workflow_candidate(
                    payload,
                    expected_revision_id=expected_revision_id,
                )
        local_result = self._local_store.apply_workflow_candidate(
            payload,
            expected_revision_id=expected_revision_id,
        )
        if not self._uses_remote_workflow_store():
            return local_result
        outcome = str(local_result.get("outcome") or "").strip().lower()
        if outcome != "accepted":
            return local_result
        create_fork = bool(payload.get("create_fork"))
        if create_fork:
            remote_payload = self._create_payload_from_result(local_result)
            remote_result = self._write_remote_result(
                "fork-create",
                workflow_id=workflow_id,
                local_result=local_result,
                remote_call=lambda client: client.create_workflow(remote_payload),
            )
        else:
            remote_result = self._write_remote_result(
                "apply",
                workflow_id=workflow_id,
                local_result=local_result,
                remote_call=lambda client: client.apply_workflow_candidate(
                    payload,
                    expected_revision_id=expected_revision_id,
                ),
            )
        self._reconcile_remote_snapshot(remote_result, local_result=local_result)
        return remote_result

    def _candidate_payload(
        self,
        *,
        workflow_id: str,
        candidate: dict[str, Any],
        expected_revision_id: str | None,
    ) -> dict[str, Any]:
        """Normalize a workflow edit view into the canonical candidate contract."""
        payload = dict(candidate)
        payload["workflow_id"] = workflow_id
        if expected_revision_id:
            payload["expected_revision_id"] = expected_revision_id
        payload["workflow_run_count"] = self._resolve_workflow_run_count(workflow_id)
        return WorkflowCandidateEnvelope.from_dict(payload).to_dict()

    def _resolve_workflow_run_count(self, workflow_id: str) -> int:
        normalized_workflow_id = str(workflow_id or "").strip()
        if not normalized_workflow_id:
            return 0
        if self._workflow_run_count_resolver is None:
            return 0
        try:
            return max(0, int(self._workflow_run_count_resolver(normalized_workflow_id)))
        except Exception as exc:
            logger.warning(
                "Failed to resolve workflow run count for %s: %s",
                normalized_workflow_id,
                exc,
            )
            return 0

    def _create_locally(self, payload: dict[str, Any]) -> dict[str, Any]:
        if self._local_store is None:
            return self._get_client().create_workflow(payload)
        return self._local_store.create_workflow(payload)

    def _archive_locally(self, workflow_id: str) -> dict[str, Any]:
        if self._local_store is None:
            return self._get_client().archive_workflow(workflow_id)
        if not self._ensure_local_head(workflow_id):
            client = self._get_client_or_none()
            if client is not None:
                return client.archive_workflow(workflow_id)
        return self._local_store.archive_workflow(workflow_id)

    def _restore_locally(self, workflow_id: str) -> dict[str, Any]:
        if self._local_store is None:
            return self._get_client().restore_workflow(workflow_id)
        if not self._ensure_local_head(workflow_id):
            client = self._get_client_or_none()
            if client is not None:
                return client.restore_workflow(workflow_id)
        return self._local_store.restore_workflow(workflow_id)

    def _soft_delete_locally(self, workflow_id: str) -> dict[str, Any]:
        if self._local_store is None:
            return self._get_client().soft_delete_workflow(workflow_id)
        if not self._ensure_local_head(workflow_id):
            client = self._get_client_or_none()
            if client is not None:
                return client.soft_delete_workflow(workflow_id)
        return self._local_store.soft_delete_workflow(workflow_id)

    def _write_remote_result(
        self,
        action: str,
        *,
        local_result: dict[str, Any],
        remote_call: Callable[[APIClient], dict[str, Any]],
        workflow_id: str | None = None,
    ) -> dict[str, Any]:
        client = self._get_client_or_none()
        if client is None:
            return local_result
        try:
            return remote_call(client)
        except Exception as exc:
            logger.warning(
                "Remote workflow %s failed%s; local result remains authoritative: %s",
                action,
                f" for {workflow_id}" if workflow_id else "",
                exc,
            )
            return local_result

    def _reconcile_remote_snapshot(
        self,
        result: dict[str, Any],
        *,
        local_result: dict[str, Any] | None = None,
    ) -> None:
        if self._local_store is None or not self._uses_remote_workflow_store():
            return
        workflow_id = self._workflow_id_from_result(result)
        if not workflow_id:
            return
        local_workflow_id = self._workflow_id_from_result(local_result) if local_result else ""
        if local_workflow_id and local_workflow_id != workflow_id:
            try:
                self._local_store.hard_delete_workflow(local_workflow_id)
            except Exception:
                pass
        if self._refresh_snapshot_from_remote(workflow_id):
            return
        workflow = result.get("workflow")
        if not isinstance(workflow, dict):
            return
        try:
            existing_revisions = self._local_store.list_workflow_revisions(workflow_id)
            revisions = [
                revision
                for revision in existing_revisions
                if str(revision.get("revision_id") or "") != str(workflow.get("revision_id") or "")
            ]
            revisions.append(workflow)
            self._local_store.store_snapshot(workflow, revisions)
        except Exception as exc:
            logger.debug("Fallback workflow snapshot reconciliation failed for %s: %s", workflow_id, exc)

    def _refresh_snapshot_from_remote(self, workflow_id: str) -> bool:
        if self._local_store is None or not self._uses_remote_workflow_store():
            return False
        client = self._get_client_or_none()
        if client is None:
            return False
        try:
            workflow_response = client.get_workflow(workflow_id)
            revisions_response = client.list_workflow_revisions(workflow_id)
            workflow = workflow_response.get("workflow")
            revisions = revisions_response.get("revisions")
            if not isinstance(workflow, dict) or not isinstance(revisions, list):
                return False
            self._local_store.store_snapshot(
                workflow,
                [item for item in revisions if isinstance(item, dict)],
            )
            return True
        except Exception as exc:
            logger.debug("Remote workflow refresh failed for %s: %s", workflow_id, exc)
            return False

    def _ensure_local_head(self, workflow_id: str) -> bool:
        if self._local_store is None:
            return False
        if self._local_store.get_workflow_head(workflow_id) is not None:
            return True
        if not self._uses_remote_workflow_store():
            return False
        return self._refresh_snapshot_from_remote(workflow_id)

    @staticmethod
    def _create_payload_from_result(result: dict[str, Any]) -> dict[str, Any]:
        workflow = result.get("workflow")
        if not isinstance(workflow, dict):
            raise ValueError("Accepted workflow result is missing workflow payload")
        return WorkflowCandidateEnvelope(
            workflow_id=str(workflow.get("workflow_id") or ""),
            title=str(workflow.get("title") or ""),
            description=str(workflow.get("description") or ""),
            domain_id=str(workflow.get("domain_id") or ""),
            workflow_definition=(
                dict(workflow.get("workflow_definition", {}))
                if isinstance(workflow.get("workflow_definition"), dict)
                else {}
            ),
            workflow_run_count=0,
            correlation=(
                dict(workflow.get("correlation", {}))
                if isinstance(workflow.get("correlation"), dict)
                else {}
            ),
        ).to_dict()

    @staticmethod
    def _workflow_id_from_result(result: dict[str, Any] | None) -> str:
        if not isinstance(result, dict):
            return ""
        return str(
            result.get("workflow_id")
            or result.get("workflow", {}).get("workflow_id")
            or result.get("resulting_revision_ref", {}).get("workflow_id")
            or result.get("current_revision_ref", {}).get("workflow_id")
            or ""
        ).strip()

    def _uses_remote_workflow_store(self) -> bool:
        return self._workflow_storage != "local"

    def _get_client(self) -> APIClient:
        if self._client is None:
            self._client = self._client_factory()
        return self._client

    def _get_client_or_none(self) -> APIClient | None:
        try:
            return self._get_client()
        except Exception as exc:
            logger.debug("Workflow Studio API client unavailable: %s", exc)
            return None
