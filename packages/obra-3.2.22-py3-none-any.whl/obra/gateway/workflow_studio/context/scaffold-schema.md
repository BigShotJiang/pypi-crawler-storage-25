# Scaffold Schema

When creating a new workflow draft, populate `scaffold_definition` with:

- `title`: concise workflow name
- `domain_id`: inferred or explicit business domain
- `description`: one-sentence workflow summary
- `stages`: ordered list of stage objects

Each stage should include:

- `id`: stable slug-style identifier
- `title`: user-facing stage title
- `purpose`: clear business purpose
- `depends_on`: list of upstream stage ids

Optionally include `quality_gates`: a list of gate objects attached to existing stages.

Each quality gate should include:

- `after_stage_id` (required): the existing stage this gate configures
- `gate_type`: type of gate, e.g. `"review"`, `"sense_check"` (defaults to `"review"`)
- `loop_back_to`: stage id to route revisions back to on failure — creates targeted revision routing so failures loop back to a specific earlier stage rather than restarting the workflow

During scaffold enrichment, the gateway translates each matching `quality_gates`
entry into the referenced stage's canonical `quality_loop` payload. The
scaffold contract does not insert a synthetic gate stage between existing stages.

Prefer specific stage names derived from the request. Avoid generic sequences like `Intake`, `Process`, `Review` unless the user truly gave no usable structure.
