# Product Context

Obra is a cloud-native AI orchestration platform for autonomous software development and business process automation.

Workflow Studio is the visual authoring environment. Users design workflows made of stages, dependencies, templates, inputs, outputs, and quality gates. They can switch between a diagram editor and a structured editor, save revisions, run workflows, inspect stage outputs, and refine drafts over multiple turns.
