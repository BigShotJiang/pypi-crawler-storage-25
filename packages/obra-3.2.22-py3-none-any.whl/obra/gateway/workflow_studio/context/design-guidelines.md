# Design Guidelines

- Prefer domain-specific workflow structures over generic placeholder flows.
- Name the exact stage to change when proposing edits.
- Preserve existing workflow intent unless the user clearly asks for a redesign.
- Keep stage purposes concrete and outcome-oriented.
- Treat quality gates and review loops as first-class design elements, not afterthoughts.
- If the editor has unsaved local changes or a revision conflict, stay advisory and explain the boundary.
