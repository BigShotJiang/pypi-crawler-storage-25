"""Safety mode enforcement for the assistant."""

from __future__ import annotations

from fastapi import HTTPException

_VALID_MODES = {"advisory", "guided", "active"}
_AVAILABLE_MODES = ["advisory", "guided"]


def enforce_safety_mode(safety_mode: str) -> None:
    """Validate safety mode; raise HTTPException if unsupported.

    Phase A only supports advisory mode. Guided and active are
    recognized but not yet available.
    """
    if safety_mode not in _VALID_MODES:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "unknown_safety_mode",
                "detail": f"Unknown safety mode: {safety_mode}",
                "valid_modes": sorted(_VALID_MODES),
            },
        )
    if safety_mode not in _AVAILABLE_MODES:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "safety_mode_not_available",
                "detail": f"Safety mode {safety_mode} is not yet supported",
                "available_modes": _AVAILABLE_MODES,
            },
        )


def enforce_no_actions(safety_mode: str, action_requested: bool) -> None:
    """Block action execution in advisory mode."""
    if safety_mode == "advisory" and action_requested:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "safety_mode_violation",
                "detail": "Advisory mode does not permit action execution",
                "safety_mode": safety_mode,
            },
        )
