"""Operator-action dispatch for Workflow Studio Stage A."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from obra.api.protocol import EscalationDecision, UserDecisionChoice
from obra.gateway.session_manager import SessionManager


class WorkflowRunActionService:
    """Dispatch canonical run control actions through the gateway substrate."""

    def __init__(self, session_manager: SessionManager) -> None:
        self._session_manager = session_manager

    def launch(
        self,
        *,
        objective: str,
        project_id: str,
        working_dir: str | None,
        workflow_id: str | None,
        revision_id: str | None,
        domain_id: str | None,
        repository: Any,
        client_factory: Any | None = None,
    ) -> dict[str, Any]:
        """Create a workflow run through the canonical session manager."""
        if callable(client_factory):
            self._session_manager.set_client_factory(client_factory)
        run_id = self._session_manager.create_workflow_run(
            objective=objective,
            project_id=project_id,
            working_dir=working_dir,
            workflow_id=workflow_id,
            revision_id=revision_id,
            domain_id=domain_id,
        )
        workflow_run = repository.get_run(run_id)
        return {
            "workflow_run": workflow_run or {"run_id": run_id, "workflow_run_id": run_id},
        }

    def cancel(
        self,
        run_id: str,
        *,
        client_request_id: str | None = None,
    ) -> dict[str, Any]:
        self._session_manager.cancel_session(run_id)
        record = self._session_manager.get_session(run_id)
        return _build_action_response(
            record,
            action_id="cancel",
            status="cancelling",
            outcome="accepted",
            client_request_id=client_request_id,
        )

    def resume(
        self,
        run_id: str,
        *,
        resume_target: str | None = None,
        client_request_id: str | None = None,
    ) -> dict[str, Any]:
        record = self._session_manager.resume_session(
            run_id,
            resume_target=resume_target,
        )
        return _build_action_response(
            record,
            action_id="resume",
            status=record.status,
            outcome="accepted",
            client_request_id=client_request_id,
            resume_target=resume_target,
        )

    def resolve_escalation(
        self,
        run_id: str,
        escalation_id: str,
        *,
        choice: str,
        was_timeout: bool = False,
        client_request_id: str | None = None,
    ) -> dict[str, Any]:
        record = self._session_manager.get_session(run_id)
        event_bus = self._session_manager.get_event_bus(run_id)
        decision = EscalationDecision(
            choice=UserDecisionChoice(choice),
            was_timeout=was_timeout,
        )
        resolved = event_bus.resolve_escalation(decision)
        if not resolved:
            return _build_action_response(
                record,
                action_id="resolve_escalation",
                status="conflict",
                outcome="no_pending_escalation",
                client_request_id=client_request_id,
                escalation_id=escalation_id,
            )
        remote_session = dict(record.latest_remote_session or {})
        outcome_status, blocking_summary, event_type = _escalation_resolution_state(choice)
        remote_session["status"] = outcome_status
        remote_session["updated_at"] = datetime.now(tz=UTC).isoformat()
        record.status = outcome_status
        record.blocking_summary = dict(blocking_summary)
        record.escalation_id = None
        resolution_payload = {
            "run_id": run_id,
            "workflow_run_id": run_id,
            "escalation_id": escalation_id,
            "choice": choice,
            "trace_id": record.trace_id,
        }
        self._session_manager.update_remote_snapshot(
            run_id,
            remote_session=remote_session,
            remote_events=_append_remote_event(
                record,
                event_type=event_type,
                payload=resolution_payload,
            ),
        )
        record.event_bus.push_event(event_type, resolution_payload)
        return _build_action_response(
            record,
            action_id="resolve_escalation",
            status="resolved",
            outcome="accepted",
            client_request_id=client_request_id,
            escalation_id=escalation_id,
            choice=choice,
            was_timeout=was_timeout,
        )

    def approve_operator_review(
        self,
        run_id: str,
        *,
        client_request_id: str | None = None,
    ) -> dict[str, Any]:
        record = self._session_manager.get_session(run_id)
        remote_session = dict(record.latest_remote_session or {})
        resume_context = (
            dict(remote_session.get("resume_context", {}))
            if isinstance(remote_session.get("resume_context"), dict)
            else {}
        )
        operator_review = (
            dict(resume_context.get("operator_review", {}))
            if isinstance(resume_context.get("operator_review"), dict)
            else {}
        )
        operator_review["status"] = "approved"
        operator_review["approved_at"] = datetime.now(tz=UTC).isoformat()
        resume_context["operator_review"] = operator_review
        remote_session["resume_context"] = resume_context
        remote_session["status"] = "completed"
        remote_session["updated_at"] = datetime.now(tz=UTC).isoformat()
        record.status = "completed"
        record.blocking_summary = {
            "state": "operator_review_approved",
            "terminal": False,
        }
        completion_payload = {
            "run_id": run_id,
            "workflow_run_id": run_id,
            "action": "approve_operator_review",
            "checkpoint_id": record.checkpoint_id,
            "trace_id": record.trace_id,
        }
        self._session_manager.update_remote_snapshot(
            run_id,
            remote_session=remote_session,
            remote_events=_append_remote_event(
                record,
                event_type="workflow_run.completed",
                payload=completion_payload,
            ),
        )
        record.event_bus.push_event(
            "workflow_run.completed",
            completion_payload,
        )
        return _build_action_response(
            record,
            action_id="approve_operator_review",
            status="accepted",
            outcome="operator_review_approved",
            client_request_id=client_request_id,
        )

    def dispatch(
        self,
        run_id: str,
        *,
        action: str,
        payload: dict[str, Any],
        client_request_id: str | None = None,
    ) -> dict[str, Any]:
        """Dispatch a generic operator action."""
        if action == "cancel":
            return self.cancel(run_id, client_request_id=client_request_id)
        if action == "resume":
            return self.resume(
                run_id,
                resume_target=_string_or_none(payload.get("resume_target")),
                client_request_id=client_request_id,
            )
        if action in {"approve_operator_review", "approve_checkpoints"}:
            return self.approve_operator_review(
                run_id,
                client_request_id=client_request_id,
            )
        if action == "resolve_escalation":
            escalation_id = _string_or_none(payload.get("escalation_id"))
            choice = _string_or_none(payload.get("choice"))
            if escalation_id is None or choice is None:
                record = self._session_manager.get_session(run_id)
                return _build_action_response(
                    record,
                    action_id="resolve_escalation",
                    status="invalid",
                    outcome="missing_escalation_fields",
                    client_request_id=client_request_id,
                )
            return self.resolve_escalation(
                run_id,
                escalation_id,
                choice=choice,
                was_timeout=bool(payload.get("was_timeout", False)),
                client_request_id=client_request_id,
            )
        record = self._session_manager.get_session(run_id)
        return _build_action_response(
            record,
            action_id=action,
            status="invalid",
            outcome="unsupported_action",
            client_request_id=client_request_id,
        )


def _string_or_none(value: Any) -> str | None:
    if isinstance(value, str):
        normalized = value.strip()
        if normalized:
            return normalized
    return None


def _escalation_resolution_state(
    choice: str,
) -> tuple[str, dict[str, Any], str]:
    if choice == "force_complete":
        return "completed", {"state": "force_completed", "terminal": True}, "workflow_run.completed"
    if choice == "abandon":
        return "cancelled", {"state": "abandoned", "terminal": True}, "workflow_run.cancelled"
    return "running", {}, "workflow_run.resumed"


def _append_remote_event(
    record: Any,
    *,
    event_type: str,
    payload: dict[str, Any],
) -> list[dict[str, Any]]:
    remote_events = [dict(event) for event in (record.latest_remote_events or [])]
    next_sequence = (
        max(
            (
                int(event.get("sequence", -1))
                for event in remote_events
                if isinstance(event.get("sequence"), int)
            ),
            default=-1,
        )
        + 1
    )
    remote_events.append(
        {
            "event_id": f"{record.workflow_run_id}:{next_sequence}",
            "event_type": event_type,
            "timestamp": datetime.now(tz=UTC).isoformat(),
            "sequence": next_sequence,
            "trace_id": record.trace_id,
            "payload": dict(payload),
        }
    )
    return remote_events


def _build_action_response(
    record: Any,
    *,
    action_id: str,
    status: str,
    outcome: str,
    client_request_id: str | None,
    **extra: Any,
) -> dict[str, Any]:
    response = {
        "run_id": record.workflow_run_id,
        "workflow_run_id": record.workflow_run_id,
        "action_id": action_id,
        "status": status,
        "outcome": outcome,
        "correlation": {
            "action_id": action_id,
            "client_request_id": client_request_id,
            "trace_id": record.trace_id,
            "workflow_run_id": record.workflow_run_id,
            "checkpoint_id": record.checkpoint_id,
            "escalation_id": record.escalation_id,
        },
    }
    response.update(extra)
    return response
