"""Event projections for Workflow Studio Stage A."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from obra.gateway.session_manager import SessionRecord

_RUN_EVENT_NAME_MAP = {
    "session_completed": "workflow_run.completed",
    "session_error": "workflow_run.failed",
    "session_cancelled": "workflow_run.cancelled",
    "stream": "workflow_run.stream",
    "workflow_run.cancel_requested": "workflow_run.cancel_requested",
    "workflow_run.cancelled": "workflow_run.cancelled",
    "workflow_run.completed": "workflow_run.completed",
    "workflow_run.failed": "workflow_run.failed",
    "workflow_run.resumed": "workflow_run.resumed",
    "escalation_notice": "workflow_run.blocked",
}

_DERIVATION_EVENT_NAME_MAP = {
    "session_completed": "workflow_derivation.completed",
    "session_error": "workflow_derivation.failed",
    "session_cancelled": "workflow_derivation.cancelled",
    "workflow_derivation.started": "workflow_derivation.started",
    "workflow_derivation.completed": "workflow_derivation.completed",
    "workflow_run.cancel_requested": "workflow_derivation.progress",
    "workflow_run.cancelled": "workflow_derivation.cancelled",
    "workflow_run.completed": "workflow_derivation.completed",
    "workflow_run.failed": "workflow_derivation.failed",
    "workflow_run.resumed": "workflow_derivation.progress",
    "escalation_notice": "workflow_derivation.awaiting_operator",
}

_WORKFLOW_EVENT_NAME_MAP = {
    "workflow.created": "workflow.created",
    "workflow.updated": "workflow.updated",
    "workflow.validated": "workflow.validated",
    "workflow.archived": "workflow.archived",
    "workflow.restored": "workflow.restored",
    "workflow.deleted": "workflow.deleted",
}

WORKFLOW_RUN_EVENT_NAMES = frozenset(
    {
        *(_RUN_EVENT_NAME_MAP.values()),
        "workflow_run.stream",
        "workflow_run.progress",
        "workflow_run.stage_started",
        "workflow_run.stage_completed",
        "workflow_run.stage_failed",
    }
)
WORKFLOW_DERIVATION_EVENT_NAMES = frozenset(
    {
        *(_DERIVATION_EVENT_NAME_MAP.values()),
        "workflow_derivation.progress",
        "workflow_derivation.waiting",
        "workflow_derivation.stage_started",
        "workflow_derivation.stage_completed",
        "workflow_derivation.stage_failed",
    }
)
WORKFLOW_EVENT_NAMES = frozenset(_WORKFLOW_EVENT_NAME_MAP.values())
CANONICAL_EVENT_NAMES_BY_RESOURCE_TYPE: Mapping[str, frozenset[str]] = {
    "workflow_run": WORKFLOW_RUN_EVENT_NAMES,
    "workflow_derivation": WORKFLOW_DERIVATION_EVENT_NAMES,
    "workflow": WORKFLOW_EVENT_NAMES,
}


def canonical_event_names_for_resource_type(resource_type: str) -> frozenset[str]:
    """Return the allowed canonical event names for one gateway resource type."""
    return CANONICAL_EVENT_NAMES_BY_RESOURCE_TYPE.get(resource_type, frozenset())


def build_event_envelope(
    event: dict[str, Any],
    *,
    run_id: str,
    record: SessionRecord | None,
    resource_type: str = "workflow_run",
) -> dict[str, Any]:
    """Normalize a raw session event into the canonical Stage A envelope."""
    event_type = str(event.get("event_type") or "unknown")
    payload = dict(event.get("payload") or {})
    is_derivation = bool(getattr(record, "derivation_id", None)) if record is not None else False
    canonical_name = _canonical_event_name(
        event_type,
        payload,
        derivation_backed=is_derivation,
        resource_type=resource_type,
    )
    workflow_derivation_id = (
        getattr(record, "derivation_id", None)
        if record is not None
        else None or event.get("derivation_id") or payload.get("derivation_id")
    )
    correlation = {
        "workflow_run_id": run_id,
        "workflow_derivation_id": workflow_derivation_id,
        "workflow_id": (
            (record.workflow_id if record is not None else None)
            or event.get("workflow_id")
            or payload.get("workflow_id")
        ),
        "workflow_revision_id": (
            (record.workflow_revision_id if record is not None else None)
            or event.get("workflow_revision_id")
            or payload.get("workflow_revision_id")
        ),
        "domain_id": (
            (record.domain_id if record is not None else None)
            or event.get("domain_id")
            or payload.get("domain_id")
        ),
        "checkpoint_id": (
            (record.checkpoint_id if record is not None else None)
            or event.get("checkpoint_id")
            or payload.get("checkpoint_id")
        ),
        "escalation_id": (
            (record.escalation_id if record is not None else None)
            or event.get("escalation_id")
            or payload.get("escalation_id")
        ),
        "trace_id": (
            (record.trace_id if record is not None else None)
            or event.get("trace_id")
            or payload.get("trace_id")
        ),
        "base_revision_id": payload.get("base_revision_id")
        or payload.get("base_revision_ref", {}).get("revision_id"),
        "current_revision_id": payload.get("current_revision_id")
        or payload.get("current_revision_ref", {}).get("revision_id"),
        "resulting_revision_id": (
            payload.get("workflow_revision_id")
            or payload.get("resulting_revision_id")
            or payload.get("resulting_revision_ref", {}).get("revision_id")
        ),
    }
    return {
        "resource_type": "workflow_event",
        "event_id": event.get("event_id") or f"{run_id}:{event.get('sequence', 0)}",
        "event_name": canonical_name,
        "sequence": event.get("sequence", 0),
        "timestamp": event.get("timestamp"),
        "workflow_run_id": run_id,
        "workflow_derivation_id": record.derivation_id if record is not None else None,
        "payload": payload,
        "correlation": correlation,
    }


def _canonical_event_name(
    event_type: str,
    payload: dict[str, Any],
    *,
    derivation_backed: bool,
    resource_type: str,
) -> str:
    if resource_type == "workflow":
        return _WORKFLOW_EVENT_NAME_MAP.get(event_type, event_type)
    if derivation_backed:
        if event_type == "progress":
            action = str(payload.get("action") or "").strip().lower()
            if action in {"stage_started", "stage_completed", "stage_failed"}:
                return f"workflow_derivation.{action}"
            if action in {"wait", "waiting"}:
                return "workflow_derivation.waiting"
            if "operator_review" in action or "checkpoint" in action:
                return "workflow_derivation.awaiting_operator"
            return "workflow_derivation.progress"
        return _DERIVATION_EVENT_NAME_MAP.get(event_type, f"workflow_derivation.{event_type}")

    if event_type == "progress":
        action = str(payload.get("action") or "").strip().lower()
        if action in {"stage_started", "stage_completed", "stage_failed"}:
            return f"workflow_run.{action}"
        return "workflow_run.progress"
    return _RUN_EVENT_NAME_MAP.get(event_type, f"workflow_run.{event_type}")


def emitted_event_envelopes(envelope: dict[str, Any]) -> list[dict[str, Any]]:
    """Return the primary envelope plus any backward-compatible progress alias."""
    event_name = str(envelope.get("event_name") or "")
    if event_name.startswith("workflow_run.stage_"):
        return [envelope, {**envelope, "event_name": "workflow_run.progress"}]
    if event_name.startswith("workflow_derivation.stage_"):
        return [envelope, {**envelope, "event_name": "workflow_derivation.progress"}]
    return [envelope]
