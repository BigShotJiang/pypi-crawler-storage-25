"""Workflow contract projection helpers for API integrators."""

from __future__ import annotations

from typing import Any


def build_workflow_contract(
    workflow_id: str,
    workflow_detail: dict[str, Any],
) -> dict[str, Any]:
    """Project a workflow detail payload into a stable I/O contract shape."""
    workflow_definition = workflow_detail.get("workflow_definition")
    if not isinstance(workflow_definition, dict):
        return {
            "workflow_id": workflow_id,
            "version": "1.0.0",
            "input_contract": None,
            "output_contract": None,
            "stages": [],
            "contract_available": False,
        }

    input_contract = _project_input_contract(workflow_definition.get("input_document"))
    output_contract = _project_output_contract(workflow_definition.get("output_document"))
    contract: dict[str, Any] = {
        "workflow_id": workflow_id,
        "version": str(workflow_definition.get("version") or "1.0.0"),
        "input_contract": input_contract,
        "output_contract": output_contract,
        "stages": _project_stages(workflow_definition.get("stages")),
    }
    if input_contract is None or output_contract is None:
        contract["contract_available"] = False
    return contract


def _project_input_contract(raw_input_document: Any) -> dict[str, Any] | None:
    if not isinstance(raw_input_document, dict):
        return None
    return {
        "name": raw_input_document.get("name"),
        "format": raw_input_document.get("format"),
        "required_fields": list(raw_input_document.get("required_fields") or []),
        "description": raw_input_document.get("description", ""),
        "input_schema": raw_input_document.get("input_schema"),
    }


def _project_output_contract(raw_output_document: Any) -> dict[str, Any] | None:
    if not isinstance(raw_output_document, dict):
        return None
    output_contract = {
        "name": raw_output_document.get("name"),
        "format": raw_output_document.get("format"),
        "deliverables": list(raw_output_document.get("deliverables") or []),
        "description": raw_output_document.get("description", ""),
    }
    if raw_output_document.get("deliverable_specs") is not None:
        output_contract["deliverable_specs"] = list(raw_output_document["deliverable_specs"])
    return output_contract


def _project_stages(raw_stages: Any) -> list[dict[str, Any]]:
    if not isinstance(raw_stages, list):
        return []
    stages: list[dict[str, Any]] = []
    for stage in raw_stages:
        if not isinstance(stage, dict):
            continue
        stages.append(
            {
                "id": stage.get("id"),
                "name": stage.get("name"),
                "type": stage.get("type"),
                "depends_on": list(stage.get("depends_on") or []),
            }
        )
    return stages
