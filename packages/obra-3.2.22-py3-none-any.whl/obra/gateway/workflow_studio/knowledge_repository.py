"""File-based knowledge document repository for assistant context enrichment."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4


class KnowledgeRepository:
    """Stores and retrieves user-uploaded reference documents.

    Documents are stored in {project_root}/.obra/knowledge/docs/ with
    metadata tracked in an index.json file.
    """

    def __init__(
        self,
        project_root: Path,
        max_document_bytes: int,
        max_total_bytes: int,
    ) -> None:
        self._root = project_root / ".obra" / "knowledge"
        self._docs_dir = self._root / "docs"
        self._index_path = self._root / "index.json"
        self._max_document_bytes = max_document_bytes
        self._max_total_bytes = max_total_bytes

    def _ensure_dirs(self) -> None:
        self._docs_dir.mkdir(parents=True, exist_ok=True)

    def _load_index(self) -> list[dict[str, Any]]:
        if not self._index_path.exists():
            return []
        try:
            return json.loads(self._index_path.read_text("utf-8"))
        except (json.JSONDecodeError, OSError):
            return []

    def _save_index(self, entries: list[dict[str, Any]]) -> None:
        self._ensure_dirs()
        self._index_path.write_text(json.dumps(entries, indent=2, default=str), "utf-8")

    def add_document(
        self,
        name: str,
        content: bytes,
        content_type: str,
        scope: str,
        workflow_id: str | None = None,
        description: str | None = None,
    ) -> dict[str, Any]:
        """Store a document and return its metadata."""
        # Validate scope
        if scope not in ("org-wide", "workflow"):
            raise ValueError(f"Invalid scope: {scope}. Must be 'org-wide' or 'workflow'.")
        if scope == "workflow" and not workflow_id:
            raise ValueError("workflow_id is required when scope is 'workflow'.")

        size_bytes = len(content)

        # Validate document size
        if size_bytes > self._max_document_bytes:
            raise ValueError(
                f"Document exceeds maximum size: {size_bytes} bytes > "
                f"{self._max_document_bytes} bytes limit."
            )

        # Validate total size
        index = self._load_index()
        total_existing = sum(e.get("size_bytes", 0) for e in index)
        if total_existing + size_bytes > self._max_total_bytes:
            raise ValueError(
                f"Adding this document would exceed total storage limit: "
                f"{total_existing + size_bytes} > {self._max_total_bytes} bytes."
            )

        # Determine file extension
        ext_map = {
            "text/plain": ".txt",
            "text/markdown": ".md",
            "application/json": ".json",
            "application/x-yaml": ".yaml",
            "application/pdf": ".pdf",
        }
        ext = ext_map.get(content_type, ".txt")
        doc_id = str(uuid4())
        filename = f"{doc_id}{ext}"

        self._ensure_dirs()
        doc_path = self._docs_dir / filename
        doc_path.write_bytes(content)

        # PDF text extraction
        extracted_text_path: str | None = None
        if content_type == "application/pdf":
            extracted = self._extract_pdf_text(content)
            if extracted:
                txt_path = self._docs_dir / f"{doc_id}.txt"
                txt_path.write_text(extracted, "utf-8")
                extracted_text_path = str(txt_path.relative_to(self._root))

        metadata: dict[str, Any] = {
            "id": doc_id,
            "name": name,
            "scope": scope,
            "workflow_id": workflow_id,
            "content_type": content_type,
            "description": description,
            "added_at": datetime.now(timezone.utc).isoformat(),
            "size_bytes": size_bytes,
            "filename": filename,
        }
        if extracted_text_path:
            metadata["extracted_text_path"] = extracted_text_path

        index.append(metadata)
        self._save_index(index)
        return metadata

    def list_documents(
        self,
        scope: str | None = None,
        workflow_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """List documents, optionally filtered by scope and workflow_id."""
        index = self._load_index()
        result = index
        if scope is not None:
            result = [e for e in result if e.get("scope") == scope]
        if workflow_id is not None:
            result = [e for e in result if e.get("workflow_id") == workflow_id]
        return result

    def get_document(self, doc_id: str) -> tuple[dict[str, Any], str]:
        """Return (metadata, content_text) for a document."""
        index = self._load_index()
        entry = next((e for e in index if e.get("id") == doc_id), None)
        if entry is None:
            raise FileNotFoundError(f"Document not found: {doc_id}")

        filename = entry.get("filename", "")
        doc_path = self._docs_dir / filename

        # For PDFs, read extracted text
        if entry.get("content_type") == "application/pdf":
            extracted = entry.get("extracted_text_path")
            if extracted:
                txt_path = self._root / extracted
                if txt_path.exists():
                    return entry, txt_path.read_text("utf-8")
            return entry, "[PDF content — text extraction unavailable]"

        if doc_path.exists():
            return entry, doc_path.read_text("utf-8")
        raise FileNotFoundError(f"Document file not found: {filename}")

    def delete_document(self, doc_id: str) -> bool:
        """Delete a document and its index entry. Returns True if found."""
        index = self._load_index()
        entry = next((e for e in index if e.get("id") == doc_id), None)
        if entry is None:
            return False

        # Remove file
        filename = entry.get("filename", "")
        doc_path = self._docs_dir / filename
        if doc_path.exists():
            doc_path.unlink()

        # Remove extracted text for PDFs
        extracted = entry.get("extracted_text_path")
        if extracted:
            txt_path = self._root / extracted
            if txt_path.exists():
                txt_path.unlink()

        # Update index
        index = [e for e in index if e.get("id") != doc_id]
        self._save_index(index)
        return True

    @staticmethod
    def _extract_pdf_text(content: bytes) -> str | None:
        """Extract text from PDF bytes using pypdf (BSD-3-Clause)."""
        try:
            import io

            from pypdf import PdfReader  # type: ignore[import-untyped]

            reader = PdfReader(io.BytesIO(content))
            pages = [page.extract_text() or "" for page in reader.pages]
            text = "\n".join(pages).strip()
            return text if text else None
        except ImportError:
            pass
        except Exception:
            # Invalid PDF data
            pass

        return None
