"""Local persisted project store for Workflow Studio."""

from __future__ import annotations

from copy import deepcopy
from datetime import UTC, datetime
import json
from pathlib import Path
import threading
from typing import Any
from urllib.parse import quote

from obra.utils.obra_home import get_runtime_dir


class LocalProjectStore:
    """Persist project summaries and the selected default project locally."""

    _INDEX_FILENAME = "_index.json"

    def __init__(self, storage_dir: Path | None = None) -> None:
        self._storage_dir = storage_dir or (get_runtime_dir() / "projects")
        self._lock = threading.RLock()

    def list_projects(self, *, include_deleted: bool = False) -> list[dict[str, Any]]:
        """List persisted projects."""
        with self._lock:
            projects: list[dict[str, Any]] = []
            for path in self._snapshot_paths():
                project = self._read_snapshot(path)
                if not include_deleted and self._is_deleted(project):
                    continue
                projects.append(deepcopy(project))
            return sorted(
                projects,
                key=lambda project: (
                    str(project.get("updated_at") or ""),
                    str(project.get("project_id") or ""),
                ),
                reverse=True,
            )

    def get_project(self, project_id: str) -> dict[str, Any] | None:
        """Return one persisted project."""
        with self._lock:
            snapshot = self._load_snapshot(project_id)
            if snapshot is None:
                return None
            return deepcopy(snapshot)

    def upsert_project(self, project: dict[str, Any]) -> dict[str, Any]:
        """Create or replace one persisted project snapshot."""
        with self._lock:
            normalized = self._normalize_project(project)
            self._write_snapshot(normalized["project_id"], normalized)
            return deepcopy(normalized)

    def replace_projects(
        self,
        projects: list[dict[str, Any]],
        *,
        default_project_id: str | None,
        hydrated_at: str | None = None,
    ) -> dict[str, Any]:
        """Replace the entire local project cache from a remote listing."""
        normalized_projects = [
            self._normalize_project(project)
            for project in projects
            if isinstance(project, dict) and str(project.get("project_id") or "").strip()
        ]
        normalized_projects.sort(key=lambda project: str(project.get("project_id") or ""))
        with self._lock:
            self._ensure_storage_dir()
            expected_ids = {str(project["project_id"]) for project in normalized_projects}
            for path in self._snapshot_paths():
                if path.stem not in {quote(project_id, safe="-_.") for project_id in expected_ids}:
                    path.unlink()
            for project in normalized_projects:
                self._write_snapshot(project["project_id"], project)
            self._write_index(
                {
                    "default_project_id": str(default_project_id).strip() or None
                    if default_project_id is not None
                    else None,
                    "hydrated_at": hydrated_at or datetime.now(UTC).isoformat(),
                }
            )
        return {
            "resource_type": "project_snapshot_sync",
            "schema_version": 1,
            "synced_count": len(normalized_projects),
        }

    def sync_from_remote(self, api_client: Any) -> dict[str, Any]:
        """Hydrate local projects from the remote control plane."""
        response = api_client.list_projects_with_selection(include_deleted=True)
        projects = response.get("projects")
        if not isinstance(projects, list):
            raise ValueError("Remote project listing did not return projects")
        return self.replace_projects(
            [project for project in projects if isinstance(project, dict)],
            default_project_id=_normalize_optional_string(response.get("default_project_id")),
        )

    def get_default_project_id(self) -> str | None:
        """Return the locally persisted default project id."""
        with self._lock:
            index = self._read_index()
            return _normalize_optional_string(index.get("default_project_id"))

    def set_default_project_id(self, project_id: str | None) -> None:
        """Persist the selected default project id."""
        with self._lock:
            index = self._read_index()
            index["default_project_id"] = _normalize_optional_string(project_id)
            self._write_index(index)

    def is_hydrated(self) -> bool:
        """Return whether the project cache has been fully hydrated at least once."""
        with self._lock:
            index = self._read_index()
            return bool(_normalize_optional_string(index.get("hydrated_at")))

    def _load_snapshot(self, project_id: str) -> dict[str, Any] | None:
        path = self._snapshot_path(project_id)
        if not path.exists():
            return None
        return self._read_snapshot(path)

    def _read_snapshot(self, path: Path) -> dict[str, Any]:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"Malformed local project snapshot: {path}") from exc
        if not isinstance(data, dict):
            raise ValueError(f"Malformed local project snapshot: {path}")
        if not str(data.get("project_id") or "").strip():
            raise ValueError(f"Malformed local project snapshot: {path}")
        return data

    def _write_snapshot(self, project_id: str, payload: dict[str, Any]) -> None:
        self._ensure_storage_dir()
        path = self._snapshot_path(project_id)
        tmp_path = path.with_suffix(".tmp")
        tmp_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        tmp_path.replace(path)

    def _read_index(self) -> dict[str, Any]:
        path = self._index_path()
        if not path.exists():
            return {}
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"Malformed local project index: {path}") from exc
        if not isinstance(data, dict):
            raise ValueError(f"Malformed local project index: {path}")
        return data

    def _write_index(self, payload: dict[str, Any]) -> None:
        self._ensure_storage_dir()
        path = self._index_path()
        tmp_path = path.with_suffix(".tmp")
        tmp_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        tmp_path.replace(path)

    def _snapshot_paths(self) -> list[Path]:
        if not self._storage_dir.exists():
            return []
        return sorted(
            path
            for path in self._storage_dir.glob("*.json")
            if path.name != self._INDEX_FILENAME
        )

    def _ensure_storage_dir(self) -> None:
        self._storage_dir.mkdir(parents=True, exist_ok=True)

    def _index_path(self) -> Path:
        return self._storage_dir / self._INDEX_FILENAME

    def _snapshot_path(self, project_id: str) -> Path:
        return self._storage_dir / f"{quote(project_id, safe='-_.')}.json"

    @staticmethod
    def _normalize_project(project: dict[str, Any]) -> dict[str, Any]:
        normalized = dict(project)
        project_id = str(normalized.get("project_id") or "").strip()
        if not project_id:
            raise ValueError("Project snapshot is missing project_id")
        normalized["project_id"] = project_id
        return normalized

    @staticmethod
    def _is_deleted(project: dict[str, Any]) -> bool:
        return bool(project.get("is_deleted") or project.get("deleted_at"))


def _normalize_optional_string(value: Any) -> str | None:
    text = str(value).strip() if value is not None else ""
    return text or None
