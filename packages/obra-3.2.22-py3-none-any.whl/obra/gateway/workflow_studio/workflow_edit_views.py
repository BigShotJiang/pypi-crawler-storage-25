"""Semantic edit views for Workflow Studio Stage C workflow payloads."""

from __future__ import annotations

from typing import Any


def build_workflow_semantic_view(workflow: dict[str, Any]) -> dict[str, Any]:
    """Build a stable semantic edit view for a workflow payload."""
    workflow_id = str(workflow.get("workflow_id") or "")
    revision_id = str(workflow.get("revision_id") or workflow.get("latest_revision_id") or "")
    workflow_definition = (
        workflow.get("workflow_definition")
        if isinstance(workflow.get("workflow_definition"), dict)
        else {}
    )
    stages = [stage for stage in workflow_definition.get("stages", []) if isinstance(stage, dict)]
    selectors = [
        {
            "kind": "workflow",
            "resource_id": workflow_id,
            "revision_id": revision_id,
        }
    ]
    for index, stage in enumerate(stages, start=1):
        selectors.append(
            {
                "kind": "stage",
                "workflow_id": workflow_id,
                "revision_id": revision_id,
                "stage_id": stage.get("id"),
                "ordinal": index,
                "title": stage.get("title"),
            }
        )

    validation_summary = (
        workflow.get("validation_summary")
        if isinstance(workflow.get("validation_summary"), dict)
        else {}
    )
    diff_summary = (
        workflow.get("diff_summary") if isinstance(workflow.get("diff_summary"), dict) else {}
    )
    conflict_summary = (
        workflow.get("conflict_summary")
        if isinstance(workflow.get("conflict_summary"), dict)
        else {}
    )
    blocking_issue_count = int(validation_summary.get("blocking_issue_count", 0) or 0)
    action_affordances = [
        {
            "action": "validate",
            "enabled": True,
            "guard": "side_effect_free",
        },
        {
            "action": "save",
            "enabled": not conflict_summary and blocking_issue_count == 0,
            "guard": "expected_revision",
        },
        {
            "action": "fork",
            "enabled": bool(conflict_summary),
            "guard": "create_fork",
        },
    ]
    stage_lines = [
        f"{stage.get('id') or 'stage'}: {stage.get('title') or stage.get('purpose') or ''}".strip()
        for stage in stages
    ]
    text_projection = "\n".join(
        line
        for line in [
            f"workflow {workflow_id}".strip(),
            f"revision {revision_id}".strip() if revision_id else "",
            *stage_lines,
        ]
        if line
    )
    return {
        "selectors": selectors,
        "action_affordances": action_affordances,
        "text_projection": text_projection,
        "json_projection": {
            "workflow_id": workflow_id,
            "revision_id": revision_id,
            "stage_ids": [stage.get("id") for stage in stages],
            "validation_summary": validation_summary,
            "diff_summary": diff_summary,
            "conflict_summary": conflict_summary,
        },
    }
