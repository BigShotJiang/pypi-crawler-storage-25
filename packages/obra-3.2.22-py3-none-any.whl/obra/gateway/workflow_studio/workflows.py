"""Workflow projections for Workflow Studio Stage A."""

from __future__ import annotations

from typing import Any

from obra.gateway.links import build_resource_links
from obra.gateway.workflow_studio.data_access import (
    WorkflowStudioRunBundle,
    workflow_identity_from_sources,
    workflow_lifecycle_decisions_from_payload,
    workflow_lifecycle_from_sources,
)


def build_workflow_revision(bundle: WorkflowStudioRunBundle) -> dict[str, Any] | None:
    """Build a canonical revision projection from one run bundle."""
    identity = workflow_identity_from_sources(bundle.record, bundle.remote_session)
    workflow_id = identity["workflow_id"]
    revision_id = identity["revision_id"]
    if workflow_id is None:
        return None

    stage_names = [
        str(stage.get("stage_name") or stage.get("trigger") or "")
        for stage in bundle.pipeline_stages
        if str(stage.get("stage_name") or stage.get("trigger") or "").strip()
    ]
    validation_summary = _build_validation_summary(bundle.remote_session)
    lifecycle_summary = _build_lifecycle_summary(bundle)
    return {
        "resource_type": "workflow_revision",
        "workflow_id": workflow_id,
        "revision_id": revision_id or "current",
        "domain_id": identity["domain_id"],
        "title": bundle.record.objective,
        "status": bundle.record.status,
        "stage_order": stage_names,
        "stage_count": len(stage_names),
        "validation_summary": validation_summary,
        "lifecycle_summary": lifecycle_summary,
        "current_run_id": bundle.record.workflow_run_id,
    }


def build_workflow_summary(
    workflow_id: str,
    revisions: list[dict[str, Any]],
) -> dict[str, Any]:
    """Collapse workflow revisions into a workflow summary."""
    latest = revisions[0]
    return {
        "resource_type": "workflow",
        "workflow_id": workflow_id,
        "domain_id": latest.get("domain_id"),
        "latest_revision_id": latest.get("revision_id"),
        "status": latest.get("status"),
        "title": latest.get("title"),
        "revision_count": len(revisions),
        "stage_order": latest.get("stage_order", []),
        "validation_summary": latest.get("validation_summary", {}),
        "lifecycle_summary": latest.get("lifecycle_summary", {}),
        "current_run_id": latest.get("current_run_id"),
        "links": build_resource_links("workflow", workflow_id),
    }


def build_workflow_detail(
    workflow_id: str,
    revisions: list[dict[str, Any]],
) -> dict[str, Any]:
    """Build workflow detail with embedded revision summaries."""
    summary = build_workflow_summary(workflow_id, revisions)
    summary["revisions"] = revisions
    return summary


def _build_validation_summary(remote_session: dict[str, Any]) -> dict[str, Any]:
    workflow_derivation_state = (
        remote_session.get("workflow_derivation_state")
        if isinstance(remote_session.get("workflow_derivation_state"), dict)
        else {}
    )
    validation_report = (
        workflow_derivation_state.get("validation_report")
        if isinstance(workflow_derivation_state.get("validation_report"), dict)
        else {}
    )
    checkpoint_state = (
        workflow_derivation_state.get("operator_review_checkpoint_state")
        if isinstance(workflow_derivation_state.get("operator_review_checkpoint_state"), dict)
        else {}
    )
    return {
        "outcome": validation_report.get("outcome"),
        "issue_codes": list(validation_report.get("issue_codes") or []),
        "pending_operator_review_checkpoint_ids": list(
            checkpoint_state.get("checkpoint_ids") or []
        ),
    }


def _build_lifecycle_summary(bundle: WorkflowStudioRunBundle) -> dict[str, Any]:
    workflow_lifecycle = workflow_lifecycle_from_sources(bundle.record, bundle.remote_session)
    lifecycle_decisions = (
        bundle.remote_session.get("workflow_lifecycle_decisions")
        if isinstance(bundle.remote_session.get("workflow_lifecycle_decisions"), dict)
        else {}
    )
    remote_lifecycle_state = (
        bundle.remote_session.get("workflow_lifecycle_state")
        if isinstance(bundle.remote_session.get("workflow_lifecycle_state"), dict)
        else {}
    )
    if workflow_lifecycle and (
        not lifecycle_decisions
        or (
            not remote_lifecycle_state
            and str(lifecycle_decisions.get("selected_path") or "").strip()
            == "story0_compatibility"
        )
    ):
        lifecycle_decisions = workflow_lifecycle_decisions_from_payload(workflow_lifecycle)
    return {
        "workflow_lifecycle": workflow_lifecycle,
        "lifecycle_decisions": lifecycle_decisions,
        "current_phase": bundle.remote_session.get("current_phase"),
        "status": bundle.remote_session.get("status"),
    }
