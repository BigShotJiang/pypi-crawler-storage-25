"""Semantic view models for Workflow Studio Stage B derivation surfaces."""

from __future__ import annotations

from typing import Any


def build_derivation_view_models(detail: dict[str, Any]) -> dict[str, Any]:
    """Build JSON-ready Stage B semantic views from canonical derivation detail."""
    normalized_inputs = (
        dict(detail.get("normalized_inputs", {}))
        if isinstance(detail.get("normalized_inputs"), dict)
        else {}
    )
    checkpoint_summary = (
        dict(detail.get("checkpoint_summary", {}))
        if isinstance(detail.get("checkpoint_summary"), dict)
        else {}
    )
    candidate_workflow_ref = (
        dict(detail.get("candidate_workflow_ref", {}))
        if isinstance(detail.get("candidate_workflow_ref"), dict)
        else {}
    )
    acceptance = (
        dict(detail.get("acceptance", {})) if isinstance(detail.get("acceptance"), dict) else {}
    )
    return {
        "submission_review": {
            "mission": normalized_inputs.get("mission"),
            "domain_id": normalized_inputs.get("domain_id"),
            "artifact_refs": {
                "input_spec_refs": list(normalized_inputs.get("input_spec_refs") or []),
                "output_spec_refs": list(normalized_inputs.get("output_spec_refs") or []),
                "rule_pack_refs": list(normalized_inputs.get("rule_pack_refs") or []),
                "quality_pack_refs": list(normalized_inputs.get("quality_pack_refs") or []),
                "example_case_refs": list(normalized_inputs.get("example_case_refs") or []),
                "exception_case_refs": list(normalized_inputs.get("exception_case_refs") or []),
            },
            "baseline_workflow_ref": detail.get("baseline_workflow_ref"),
            "operator_constraints": dict(normalized_inputs.get("operator_constraints") or {}),
        },
        "candidate_inspection": {
            "candidate_workflow_ref": candidate_workflow_ref,
            "baseline_workflow_ref": detail.get("baseline_workflow_ref"),
            "validation_summary": detail.get("validation_summary"),
            "lifecycle_summary": detail.get("lifecycle_summary"),
            "links": dict(detail.get("links", {})),
        },
        "checkpoint_handling": {
            "status": checkpoint_summary.get("status"),
            "pending_count": checkpoint_summary.get("pending_count", 0),
            "checkpoint_ids": list(checkpoint_summary.get("checkpoint_ids") or []),
            "pending_points": list(checkpoint_summary.get("pending_points") or []),
            "resume_supported": bool(detail.get("resume_supported", False)),
            "acceptance_ready": bool(acceptance.get("ready", False)),
        },
    }
