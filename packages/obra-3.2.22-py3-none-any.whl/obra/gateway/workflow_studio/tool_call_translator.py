"""Translate LLM tool calls into assistant proposal records."""

from __future__ import annotations

import json
import re
import uuid
from dataclasses import dataclass
from typing import Any, Callable

from obra.gateway.assistant.handlers.metadata import _ALLOWED_METADATA_FIELDS
from obra.gateway.assistant.handlers.pipeline_dispatch import build_pipeline_proposal
from obra.gateway.assistant.handlers.quality_gate import build_quality_loop_payload
from obra.gateway.assistant.proposal_records import build_proposal_record
from obra.gateway.assistant.tool_schema import TOOL_NAME_TO_ACTION_ID
from obra.gateway.workflow_studio.assistant_response_planner import (
    _build_batch_mutation_record,
    _build_connection_record,
    _build_generate_documentation_record,
    _build_insert_stage_record,
    _build_output_review_response,
    _build_quality_gate_record,
    _build_remove_stage_record,
    _build_reorder_stage_record,
    _build_stage_definition,
    _build_stage_update_record,
    _build_template_edit_response,
    _build_workflow_metadata_record,
    _current_stage_before_content,
    _default_scaffold_title,
    _default_template_after_content,
    _default_workflow_top_level,
    _enrich_scaffold_stage,
    _extract_embedded_json,
    _infer_domain_id,
    _resolve_stage_id,
    _resolve_workflow_ref,
    _selected_stage_id,
    _slugify_stage_id,
    _workflow_mutation_boundary_message,
)
from obra.gateway.workflow_studio.assistant_types import AssistantLlmResponse
from obra.hybrid.json_utils import _sanitize_control_chars, extract_json_payload
from obra.workflow.readiness import validate_seed_document


@dataclass(frozen=True)
class ToolCallResult:
    """Parsed tool call emitted by the guided provider."""

    tool_name: str
    arguments: dict[str, Any]
    raw_text: str | None = None


def _assign_proposal_group(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Assign one shared proposal_group to all provided records."""
    if len(records) < 2:
        return records
    group_id = str(uuid.uuid4())
    for record in records:
        record["proposal_group"] = group_id
    return records


def _is_executable_proposal_record(record: dict[str, Any]) -> bool:
    """Return whether a record is an executable assistant proposal."""
    return str(record.get("action_type") or "").startswith("propose_")


def _safe_json_loads(text: str) -> dict[str, Any] | None:
    def _loads_dict(candidate: str) -> dict[str, Any] | None:
        sanitized = _sanitize_control_chars(candidate)
        try:
            data = json.loads(sanitized)
        except json.JSONDecodeError as exc:
            repaired = _repair_missing_comma(sanitized, exc)
            if repaired is None:
                return None
            return repaired
        return data if isinstance(data, dict) else None

    direct = _loads_dict(text)
    if direct is not None:
        return direct

    payload = extract_json_payload(text)
    if payload:
        result = _loads_dict(payload)
        if result is not None:
            return result

    # Fallback: brace-depth extraction handles cases where code-block
    # regex is confused by triple-backticks inside JSON string values
    # (e.g. template content containing markdown code blocks).
    embedded = _extract_embedded_json(text)
    if isinstance(embedded, dict):
        return embedded
    return None


def _repair_missing_comma(text: str, error: json.JSONDecodeError) -> dict[str, Any] | None:
    """Attempt the narrow comma repair used by TemplateJsonParser."""
    if error.msg != "Expecting ',' delimiter":
        return None
    insert_at = error.pos
    if insert_at <= 0 or insert_at > len(text):
        return None
    prev_index = insert_at - 1
    while prev_index >= 0 and text[prev_index].isspace():
        prev_index -= 1
    if prev_index < 0 or text[prev_index] in "{[,":
        return None
    repaired_text = _sanitize_control_chars(f"{text[:insert_at]},{text[insert_at:]}")
    try:
        data = json.loads(repaired_text)
    except json.JSONDecodeError:
        return None
    return data if isinstance(data, dict) else None


def _summarize_pipeline_user_context(
    resolved_context: dict[str, Any] | None,
    *,
    max_messages: int = 3,
    max_chars: int = 500,
) -> str:
    """Summarize recent user turns for pipeline-local prompt context."""
    turns = (resolved_context or {}).get("all_turns") or []
    user_messages = [
        str(turn.get("message") or "").strip()
        for turn in turns
        if isinstance(turn, dict)
        and turn.get("role") == "user"
        and str(turn.get("message") or "").strip()
    ]
    if not user_messages:
        return ""
    summary = "\n".join(user_messages[-max_messages:])
    return summary[:max_chars].strip()


def parse_tool_calls(llm_response: str) -> tuple[str, list[ToolCallResult]]:
    """Parse tool calls from an LLM response string."""
    raw_text = str(llm_response or "").strip()
    if not raw_text:
        return "", []

    data = _safe_json_loads(raw_text)
    if not isinstance(data, dict):
        return raw_text, []

    message = str(data.get("message") or "").strip()
    tool_calls_raw = data.get("tool_calls")
    if not isinstance(tool_calls_raw, list):
        return message or raw_text, []

    tool_calls: list[ToolCallResult] = []
    for entry in tool_calls_raw:
        if not isinstance(entry, dict):
            continue
        tool_name = str(entry.get("tool") or "").strip()
        args = entry.get("args")
        if not tool_name or not isinstance(args, dict):
            continue
        tool_calls.append(
            ToolCallResult(tool_name=tool_name, arguments=args, raw_text=message or raw_text)
        )
    return message or raw_text, tool_calls


def _would_create_cycle(
    stage_id: str,
    dependency_id: str,
    dependencies: dict[str, list[str]],
) -> bool:
    stack = [dependency_id]
    seen: set[str] = set()
    while stack:
        current = stack.pop()
        if current == stage_id:
            return True
        if current in seen:
            continue
        seen.add(current)
        stack.extend(dependencies.get(current, []))
    return False


def repair_scaffold_definition(scaffold: dict[str, Any]) -> dict[str, Any]:
    """Repair a scaffold definition in-place enough for proposal building."""
    stages = scaffold.get("stages")
    if not isinstance(stages, list):
        raise ValueError("stages must be a list")
    if not stages:
        raise ValueError("stages must not be empty")

    def _register_stage_aliases(
        alias_map: dict[str, str],
        value: Any,
        canonical_stage_id: str,
    ) -> None:
        text = str(value or "").strip().lower()
        if not text:
            return
        alias_map[text] = canonical_stage_id
        slug = _slugify_stage_id(text)
        alias_map[slug] = canonical_stage_id
        alias_map[slug.replace("-", "_")] = canonical_stage_id

    staged_rows: list[tuple[dict[str, Any], list[str]]] = []
    stage_aliases: dict[str, str] = {}
    seen_stage_ids: set[str] = set()
    for index, stage in enumerate(stages, start=1):
        if not isinstance(stage, dict):
            raise ValueError("stage entries must be objects")
        stage_data = dict(stage)
        title = str(stage_data.get("title") or "").strip() or f"Stage {index}"
        raw_stage_id = str(stage_data.get("stage_id") or stage_data.get("id") or "").strip()
        stage_id = raw_stage_id or _slugify_stage_id(title)
        if not re.fullmatch(r"^[a-z0-9][a-z0-9-]*$", stage_id):
            stage_id = _slugify_stage_id(stage_id)
        if stage_id in seen_stage_ids:
            suffix = 2
            while f"{stage_id}-{suffix}" in seen_stage_ids:
                suffix += 1
            stage_id = f"{stage_id}-{suffix}"
        purpose = str(stage_data.get("purpose") or "").strip() or f"Process the {title} step"
        depends_on_raw = stage_data.get("depends_on")
        if isinstance(depends_on_raw, str):
            depends_on = [depends_on_raw.strip()] if depends_on_raw.strip() else []
        elif isinstance(depends_on_raw, list):
            depends_on = [str(item).strip() for item in depends_on_raw if str(item).strip()]
        else:
            depends_on = []

        stage_data["id"] = stage_id
        stage_data["stage_id"] = stage_id
        stage_data["title"] = title
        stage_data["purpose"] = purpose
        staged_rows.append((stage_data, depends_on))
        _register_stage_aliases(stage_aliases, raw_stage_id, stage_id)
        _register_stage_aliases(stage_aliases, stage_data.get("id"), stage_id)
        _register_stage_aliases(stage_aliases, title, stage_id)
        seen_stage_ids.add(stage_id)

    repaired_stages: list[dict[str, Any]] = []
    dependencies: dict[str, list[str]] = {}
    for stage_data, raw_dependencies in staged_rows:
        stage_id = str(stage_data.get("id") or "").strip()
        cleaned_dependencies: list[str] = []
        seen_dependencies: set[str] = set()
        for dependency in raw_dependencies:
            resolved_dependency = stage_aliases.get(str(dependency or "").strip().lower())
            if not resolved_dependency:
                slug = _slugify_stage_id(str(dependency or ""))
                resolved_dependency = (
                    stage_aliases.get(slug)
                    or stage_aliases.get(slug.replace("-", "_"))
                    or dependency
                )
            if resolved_dependency == stage_id or resolved_dependency in seen_dependencies:
                continue
            if _would_create_cycle(stage_id, resolved_dependency, dependencies):
                continue
            cleaned_dependencies.append(resolved_dependency)
            seen_dependencies.add(resolved_dependency)

        stage_data["depends_on"] = cleaned_dependencies
        repaired_stages.append(stage_data)
        dependencies[stage_id] = cleaned_dependencies

    repaired = dict(scaffold)
    repaired["stages"] = repaired_stages
    return repaired


def merge_scaffold_drafts(existing: dict[str, Any], incoming: dict[str, Any]) -> dict[str, Any]:
    """Merge an incoming scaffold draft onto an existing draft."""
    existing_repaired = repair_scaffold_definition(existing)
    incoming_repaired = repair_scaffold_definition(incoming)

    existing_stages = {
        str(stage.get("id") or ""): dict(stage)
        for stage in existing_repaired.get("stages", [])
        if isinstance(stage, dict) and str(stage.get("id") or "").strip()
    }
    merged_order = list(existing_stages)

    for stage in incoming_repaired.get("stages", []):
        if not isinstance(stage, dict):
            continue
        stage_id = str(stage.get("id") or "").strip()
        if not stage_id:
            continue
        existing_stages[stage_id] = dict(stage)
        if stage_id not in merged_order:
            merged_order.append(stage_id)

    merged_stages: list[dict[str, Any]] = []
    valid_ids = set(merged_order)
    for stage_id in merged_order:
        stage = dict(existing_stages[stage_id])
        stage["depends_on"] = [
            dependency
            for dependency in stage.get("depends_on", [])
            if isinstance(dependency, str) and dependency in valid_ids and dependency != stage_id
        ]
        merged_stages.append(stage)

    merged = {
        **existing_repaired,
        **incoming_repaired,
        "title": str(
            incoming_repaired.get("title") or existing_repaired.get("title") or ""
        ).strip(),
        "description": str(
            incoming_repaired.get("description") or existing_repaired.get("description") or ""
        ).strip(),
        "domain_id": str(
            incoming_repaired.get("domain_id") or existing_repaired.get("domain_id") or ""
        ).strip(),
        "stages": merged_stages,
    }
    return repair_scaffold_definition(merged)


def _apply_scaffold_quality_gates(scaffold_definition: dict[str, Any]) -> None:
    """Apply top-level quality_gates entries to their matching stages.

    Mutates stages in *scaffold_definition* in place, setting each matched
    stage's ``quality_loop`` to the canonical payload built from the gate
    entry.  Unmatched entries (no stage found for ``after_stage_id``) are
    silently skipped.
    """
    quality_gates = scaffold_definition.get("quality_gates")
    if not isinstance(quality_gates, list) or not quality_gates:
        return

    stages: list[dict[str, Any]] = scaffold_definition.get("stages") or []
    if not stages:
        return

    stage_by_id: dict[str, dict[str, Any]] = {}
    stage_by_slug: dict[str, dict[str, Any]] = {}
    for stage in stages:
        if not isinstance(stage, dict):
            continue
        sid = str(stage.get("id") or "").strip()
        if sid:
            stage_by_id[sid] = stage
            stage_by_slug[_slugify_stage_id(sid)] = stage
        stage_title = str(stage.get("title") or "").strip()
        if stage_title:
            stage_by_slug[_slugify_stage_id(stage_title)] = stage

    # Build a synthetic workflow structure for build_quality_loop_payload
    # which expects workflow["workflow_definition"]["stages"].
    synthetic_workflow: dict[str, Any] = {
        "workflow_definition": {"stages": stages},
    }

    for gate_entry in quality_gates:
        if not isinstance(gate_entry, dict):
            continue
        after_stage_id = str(gate_entry.get("after_stage_id") or "").strip()
        if not after_stage_id:
            continue

        # Resolve the target stage — try exact id first, then slugified lookup
        target_stage = stage_by_id.get(after_stage_id)
        if target_stage is None:
            target_stage = stage_by_slug.get(_slugify_stage_id(after_stage_id))
        if target_stage is None:
            continue

        resolved_stage_id = str(target_stage.get("id") or "").strip()
        if not resolved_stage_id:
            continue

        # Resolve loop_back_to
        loop_back_to_raw = str(gate_entry.get("loop_back_to") or "").strip()
        loop_back_to: str | None = None
        if loop_back_to_raw:
            if loop_back_to_raw in stage_by_id:
                loop_back_to = loop_back_to_raw
            else:
                slug = _slugify_stage_id(loop_back_to_raw)
                resolved = stage_by_slug.get(slug)
                if resolved is not None:
                    loop_back_to = str(resolved.get("id") or "").strip() or None

        try:
            quality_loop = build_quality_loop_payload(
                synthetic_workflow,
                stage_id=resolved_stage_id,
                loop_back_to=loop_back_to,
                evaluators=gate_entry.get("evaluators"),
                thresholds=gate_entry.get("thresholds"),
            )
        except ValueError:
            continue

        target_stage["quality_loop"] = quality_loop


def _build_scaffold_record(
    scaffold_definition: dict[str, Any],
    *,
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> dict[str, Any]:
    domain_id = str(scaffold_definition.get("domain_id") or "").strip() or _infer_domain_id(
        resolved_context
    )
    title = str(scaffold_definition.get("title") or "").strip() or _default_scaffold_title(
        user_message,
        resolved_context,
    )
    description = str(scaffold_definition.get("description") or "").strip() or (
        f"Workflow designed from assistant conversation: {title}"
    )
    _apply_scaffold_quality_gates(scaffold_definition)
    stages = [
        _enrich_scaffold_stage(
            dict(stage),
            index=index,
            total=len(scaffold_definition.get("stages") or []),
            domain_id=domain_id,
        )
        for index, stage in enumerate(scaffold_definition.get("stages") or [])
        if isinstance(stage, dict)
    ]
    top_level = _default_workflow_top_level(
        title=title,
        domain_id=domain_id,
        description=description,
    )
    resolved_scaffold = {
        **dict(scaffold_definition),
        **top_level,
        "stages": stages,
    }
    return build_proposal_record(
        action_id="execute_draft_workflow_from_thread",
        action_type="draft_workflow_from_thread",
        action_inputs={
            "scaffold_definition": resolved_scaffold,
            "domain_id": domain_id,
        },
        preview_type="scaffold",
        scaffold_definition=resolved_scaffold,
        stage_count=len(stages),
        connection_count=sum(len(stage.get("depends_on", [])) for stage in stages),
    )


def _translate_build_workflow_scaffold(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    incoming_scaffold = repair_scaffold_definition(
        tool_call.arguments.get("scaffold_definition", {})
    )
    scaffold = incoming_scaffold
    if construction_context and isinstance(construction_context.get("scaffold_draft"), dict):
        scaffold = merge_scaffold_drafts(construction_context["scaffold_draft"], incoming_scaffold)
    record = _build_scaffold_record(
        scaffold,
        user_message=tool_call.raw_text or "",
        resolved_context=resolved_context,
    )
    return AssistantLlmResponse(
        message=tool_call.raw_text or "",
        outcome="proposal",
        action_records=[record],
    )


def _require_workflow_ref(resolved_context: dict[str, Any] | None) -> tuple[str, str | None]:
    workflow_id, revision_id = _resolve_workflow_ref(resolved_context)
    if workflow_id is None:
        raise ValueError("workflow context is required for this tool")
    return workflow_id, revision_id


# Tools that can fall back to modifying the scaffold draft when no persisted
# workflow exists.  ``edit_template`` is excluded because templates are
# file-backed and don't exist until the workflow is created.
_SCAFFOLD_DRAFT_ELIGIBLE_TOOLS = {
    "add_stage",
    "remove_stage",
    "update_stage",
    "reorder_stages",
    "connect_stages",
    "disconnect_stages",
    "update_workflow_metadata",
    "set_quality_gate",
    "add_quality_gate",
    "batch_mutation",
}


def _has_scaffold_draft(construction_context: dict[str, Any] | None) -> bool:
    return bool(
        construction_context and isinstance(construction_context.get("scaffold_draft"), dict)
    )


_BATCH_OP_TO_TOOL = {
    "insert_stage": "add_stage",
    "remove_stage": "remove_stage",
    "connect": "connect_stages",
    "disconnect": "disconnect_stages",
    "update_stage": "update_stage",
    "update_workflow_metadata": "update_workflow_metadata",
    "set_quality_gate": "set_quality_gate",
}


def _find_stage(
    stage_id: str | None,
    stages: list[dict[str, Any]],
) -> dict[str, Any] | None:
    if not stage_id:
        return None
    for stage in stages:
        if str(stage.get("id") or "") == stage_id:
            return stage
        if _slugify_stage_id(str(stage.get("title") or "")) == _slugify_stage_id(stage_id):
            return stage
    return None


def _find_stage_index(
    stage_id: str | None,
    stages: list[dict[str, Any]],
) -> int | None:
    if not stage_id:
        return None
    for index, stage in enumerate(stages):
        if str(stage.get("id") or "") == stage_id:
            return index
        if _slugify_stage_id(str(stage.get("title") or "")) == _slugify_stage_id(stage_id):
            return index
    return None


def _mutate_add_stage(
    _tool_name: str,
    args: dict[str, Any],
    _draft: dict[str, Any],
    stages: list[dict[str, Any]],
    resolved_context: dict[str, Any] | None,
) -> None:
    stage_def, after_stage_id = _build_stage_definition(args, resolved_context)
    index = _find_stage_index(after_stage_id, stages)
    if index is not None:
        stages.insert(index + 1, stage_def)
        return
    stages.append(stage_def)


def _mutate_remove_stage(
    _tool_name: str,
    args: dict[str, Any],
    _draft: dict[str, Any],
    stages: list[dict[str, Any]],
    _resolved_context: dict[str, Any] | None,
) -> None:
    stage_id = str(args.get("stage_id") or "").strip()
    stages[:] = [stage for stage in stages if str(stage.get("id") or "") != stage_id]
    for stage in stages:
        depends_on = stage.get("depends_on")
        if isinstance(depends_on, list) and stage_id in depends_on:
            depends_on.remove(stage_id)


def _mutate_update_stage(
    _tool_name: str,
    args: dict[str, Any],
    _draft: dict[str, Any],
    stages: list[dict[str, Any]],
    _resolved_context: dict[str, Any] | None,
) -> None:
    stage_id = str(args.get("stage_id") or "").strip()
    target = _find_stage(stage_id, stages)
    if target is None:
        return
    for key, value in _normalize_stage_updates(args).items():
        target[key] = value


def _mutate_reorder_stages(
    _tool_name: str,
    args: dict[str, Any],
    _draft: dict[str, Any],
    stages: list[dict[str, Any]],
    _resolved_context: dict[str, Any] | None,
) -> None:
    ordered_ids = [str(item).strip() for item in args.get("ordered_stage_ids", []) if str(item).strip()]
    if not ordered_ids:
        return
    stage_map = {str(stage.get("id") or ""): stage for stage in stages}
    reordered = [stage_map[stage_id] for stage_id in ordered_ids if stage_id in stage_map]
    remaining_ids = set(ordered_ids)
    remaining = [stage for stage in stages if str(stage.get("id") or "") not in remaining_ids]
    stages[:] = reordered + remaining


def _mutate_connection(
    tool_name: str,
    args: dict[str, Any],
    _draft: dict[str, Any],
    stages: list[dict[str, Any]],
    _resolved_context: dict[str, Any] | None,
) -> None:
    source_id = str(args.get("source_stage_id") or "").strip()
    target_id = str(args.get("target_stage_id") or "").strip()
    target_stage = _find_stage(target_id, stages)
    if target_stage is None:
        return
    depends_on = target_stage.get("depends_on")
    if not isinstance(depends_on, list):
        depends_on = []
        target_stage["depends_on"] = depends_on
    if tool_name == "connect_stages" and source_id not in depends_on:
        depends_on.append(source_id)
    elif tool_name == "disconnect_stages" and source_id in depends_on:
        depends_on.remove(source_id)


def _mutate_metadata(
    _tool_name: str,
    args: dict[str, Any],
    draft: dict[str, Any],
    _stages: list[dict[str, Any]],
    _resolved_context: dict[str, Any] | None,
) -> None:
    for key, value in _normalize_metadata_updates(args).items():
        if key == "metadata" and isinstance(value, dict):
            existing_metadata = draft.get("metadata")
            normalized_existing = (
                dict(existing_metadata) if isinstance(existing_metadata, dict) else {}
            )
            normalized_existing.update(value)
            draft["metadata"] = normalized_existing
            continue
        draft[key] = value


def _mutate_set_quality_gate(
    _tool_name: str,
    args: dict[str, Any],
    _draft: dict[str, Any],
    stages: list[dict[str, Any]],
    _resolved_context: dict[str, Any] | None,
) -> None:
    stage_id = str(args.get("stage_id") or "").strip()
    target = _find_stage(stage_id, stages)
    if target is None:
        return
    synthetic_workflow: dict[str, Any] = {"workflow_definition": {"stages": stages}}
    resolved_id = str(target.get("id") or "").strip()
    try:
        quality_loop = build_quality_loop_payload(
            synthetic_workflow,
            stage_id=resolved_id,
            loop_back_to=str(args.get("loop_back_to") or "").strip() or None,
            evaluators=args.get("evaluators"),
            thresholds=args.get("thresholds"),
        )
        target["quality_loop"] = quality_loop
    except ValueError:
        pass


def _mutate_add_quality_gate(
    _tool_name: str,
    args: dict[str, Any],
    draft: dict[str, Any],
    _stages: list[dict[str, Any]],
    _resolved_context: dict[str, Any] | None,
) -> None:
    after_stage_id = str(args.get("after_stage_id") or "").strip()
    gate_type = str(args.get("gate_type") or "review").strip() or "review"
    loop_back_to = str(args.get("loop_back_to") or "").strip() or None
    if not after_stage_id:
        return
    draft.setdefault("quality_gates", []).append(
        {
            "after_stage_id": after_stage_id,
            "gate_type": gate_type,
            "loop_back_to": loop_back_to,
        }
    )


_MUTATION_DISPATCH: dict[str, Callable[[str, dict[str, Any], dict[str, Any], list[dict[str, Any]], dict[str, Any] | None], None]] = {
    "add_stage": _mutate_add_stage,
    "remove_stage": _mutate_remove_stage,
    "update_stage": _mutate_update_stage,
    "reorder_stages": _mutate_reorder_stages,
    "connect_stages": _mutate_connection,
    "disconnect_stages": _mutate_connection,
    "update_workflow_metadata": _mutate_metadata,
    "set_quality_gate": _mutate_set_quality_gate,
    "add_quality_gate": _mutate_add_quality_gate,
}


def _mutate_draft_in_place(
    tool_name: str,
    args: dict[str, Any],
    draft: dict[str, Any],
    stages: list[dict[str, Any]],
    resolved_context: dict[str, Any] | None,
) -> None:
    """Apply a single mutation to *draft* and *stages* in place."""
    handler = _MUTATION_DISPATCH.get(tool_name)
    if handler is None:
        return
    handler(tool_name, args, draft, stages, resolved_context)


def _apply_mutation_to_scaffold_draft(
    tool_name: str,
    tool_call: ToolCallResult,
    construction_context: dict[str, Any],
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    """Apply a mutation tool's intent to the scaffold draft and re-emit a scaffold proposal.

    Instead of requiring a persisted workflow, this modifies the in-progress
    scaffold draft and returns a new ``build_workflow_scaffold`` proposal that
    the user can accept.
    """
    import copy

    draft = copy.deepcopy(construction_context["scaffold_draft"])
    stages: list[dict[str, Any]] = draft.get("stages") or []

    if tool_name == "batch_mutation":
        operations = tool_call.arguments.get("operations")
        if isinstance(operations, list):
            for op in operations:
                if not isinstance(op, dict):
                    continue
                op_type = str(op.get("operation") or op.get("op") or "").strip()
                mapped_tool = _BATCH_OP_TO_TOOL.get(op_type)
                if not mapped_tool:
                    continue
                op_args = {k: v for k, v in op.items() if k not in {"op", "operation"}}
                _mutate_draft_in_place(mapped_tool, op_args, draft, stages, resolved_context)
    else:
        _mutate_draft_in_place(tool_name, tool_call.arguments, draft, stages, resolved_context)

    draft["stages"] = stages
    repaired = repair_scaffold_definition(draft)
    record = _build_scaffold_record(
        repaired,
        user_message=tool_call.raw_text or "",
        resolved_context=resolved_context,
    )
    return AssistantLlmResponse(
        message=tool_call.raw_text or "",
        outcome="proposal",
        action_records=[record],
    )


def _normalize_stage_updates(arguments: dict[str, Any]) -> dict[str, Any]:
    updates = arguments.get("updates")
    if not isinstance(updates, dict):
        return {}
    return {
        str(key): value
        for key, value in updates.items()
        if str(key).strip() and key not in {"id", "stage_id"}
    }


def _normalize_metadata_updates(arguments: dict[str, Any]) -> dict[str, Any]:
    nested_updates = arguments.get("updates")
    candidate_updates = nested_updates if isinstance(nested_updates, dict) else arguments
    normalized = {
        key: candidate_updates.get(key)
        for key in _ALLOWED_METADATA_FIELDS
        if key in candidate_updates
    }
    workflow_metadata = candidate_updates.get("metadata")
    if isinstance(workflow_metadata, dict) and "seed" in workflow_metadata:
        normalized["metadata"] = {
            "seed": validate_seed_document(workflow_metadata.get("seed"))
        }
    return normalized


def _normalize_batch_operations(
    operations: list[Any],
    *,
    resolved_context: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    normalized_operations: list[dict[str, Any]] = []
    workflow = (resolved_context or {}).get("workflow") or {}
    for entry in operations:
        if not isinstance(entry, dict):
            continue
        operation_name = str(entry.get("operation") or entry.get("op") or "").strip()
        if not operation_name:
            continue
        normalized: dict[str, Any] = {"operation": operation_name}
        if operation_name == "insert_stage":
            after_stage_id = _resolve_stage_id(entry.get("after_stage_id"), resolved_context)
            if after_stage_id:
                normalized["after_stage_id"] = after_stage_id
            if isinstance(entry.get("stage_definition"), dict):
                normalized["stage_definition"] = dict(entry["stage_definition"])
        elif operation_name == "remove_stage":
            stage_id = _resolve_stage_id(entry.get("stage_id"), resolved_context)
            if stage_id:
                normalized["stage_id"] = stage_id
        elif operation_name in {"connect", "disconnect"}:
            source_stage_id = _resolve_stage_id(entry.get("source_stage_id"), resolved_context)
            target_stage_id = _resolve_stage_id(entry.get("target_stage_id"), resolved_context)
            if source_stage_id:
                normalized["source_stage_id"] = source_stage_id
            if target_stage_id:
                normalized["target_stage_id"] = target_stage_id
        elif operation_name == "update_stage":
            stage_id = _resolve_stage_id(entry.get("stage_id"), resolved_context)
            if stage_id:
                normalized["stage_id"] = stage_id
            normalized["updates"] = _normalize_stage_updates(entry)
        elif operation_name == "update_workflow_metadata":
            normalized["updates"] = _normalize_metadata_updates(entry)
        elif operation_name == "edit_template":
            stage_id = _resolve_stage_id(entry.get("stage_id"), resolved_context)
            if stage_id:
                normalized["stage_id"] = stage_id
            template_role = str(entry.get("template_role") or "purpose").strip() or "purpose"
            normalized["template_role"] = template_role
            proposed_content = str(entry.get("proposed_content") or "").strip()
            if proposed_content:
                normalized["proposed_content"] = proposed_content
        elif operation_name == "set_quality_gate":
            stage_id = _resolve_stage_id(entry.get("stage_id"), resolved_context)
            if stage_id:
                normalized["stage_id"] = stage_id
                normalized["quality_loop"] = build_quality_loop_payload(
                    workflow,
                    stage_id=stage_id,
                    loop_back_to=_resolve_stage_id(entry.get("loop_back_to"), resolved_context),
                    evaluators=entry.get("evaluators"),
                    thresholds=entry.get("thresholds"),
                )
        normalized_operations.append(normalized)
    return normalized_operations


def _translate_run_action(
    tool_call: ToolCallResult,
    *,
    action_id: str,
    action_type: str,
    required_fields: dict[str, Any],
    preview_fields: dict[str, Any],
) -> AssistantLlmResponse:
    return AssistantLlmResponse(
        message=tool_call.raw_text or "",
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id=action_id,
                action_type=action_type,
                action_inputs=required_fields,
                preview_type="run_action",
                **preview_fields,
            )
        ],
    )


def _translate_add_stage(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    workflow_id, revision_id = _require_workflow_ref(resolved_context)
    stage_definition, after_stage_id = _build_stage_definition(tool_call.arguments, resolved_context)
    return _build_insert_stage_record(
        workflow_id=workflow_id,
        revision_id=revision_id,
        stage_definition=stage_definition,
        after_stage_id=after_stage_id,
        explanation=tool_call.raw_text or "",
        resolved_context=resolved_context,
    )


def _translate_remove_stage(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    workflow_id, revision_id = _require_workflow_ref(resolved_context)
    stage_id = _resolve_stage_id(tool_call.arguments.get("stage_id"), resolved_context) or _selected_stage_id(
        resolved_context
    )
    if not stage_id:
        return AssistantLlmResponse(message=tool_call.raw_text or "")
    return _build_remove_stage_record(
        workflow_id=workflow_id,
        revision_id=revision_id,
        stage_id=stage_id,
        explanation=tool_call.raw_text or "",
        resolved_context=resolved_context,
    )


def _translate_update_stage(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    workflow_id, revision_id = _require_workflow_ref(resolved_context)
    stage_id = _resolve_stage_id(tool_call.arguments.get("stage_id"), resolved_context) or _selected_stage_id(
        resolved_context
    )
    updates = _normalize_stage_updates(tool_call.arguments)
    if not stage_id or not updates:
        return AssistantLlmResponse(message=tool_call.raw_text or "")
    return _build_stage_update_record(
        workflow_id=workflow_id,
        revision_id=revision_id,
        stage_id=stage_id,
        updates=updates,
        explanation=tool_call.raw_text or "",
        resolved_context=resolved_context,
    )


def _translate_reorder_stages(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    workflow_id, revision_id = _require_workflow_ref(resolved_context)
    ordered_stage_ids = [
        stage_id
        for item in tool_call.arguments.get("ordered_stage_ids", [])
        if (stage_id := _resolve_stage_id(item, resolved_context)) is not None
    ]
    if not ordered_stage_ids:
        return AssistantLlmResponse(message=tool_call.raw_text or "")
    return _build_reorder_stage_record(
        workflow_id=workflow_id,
        revision_id=revision_id,
        ordered_stage_ids=ordered_stage_ids,
        explanation=tool_call.raw_text or "",
        resolved_context=resolved_context,
    )


def _translate_connection(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    workflow_id, revision_id = _require_workflow_ref(resolved_context)
    source_stage_id = _resolve_stage_id(tool_call.arguments.get("source_stage_id"), resolved_context)
    target_stage_id = _resolve_stage_id(tool_call.arguments.get("target_stage_id"), resolved_context)
    if not source_stage_id or not target_stage_id:
        return AssistantLlmResponse(message=tool_call.raw_text or "")
    return _build_connection_record(
        workflow_id=workflow_id,
        revision_id=revision_id,
        source_stage_id=source_stage_id,
        target_stage_id=target_stage_id,
        action="add" if tool_call.tool_name == "connect_stages" else "remove",
        explanation=tool_call.raw_text or "",
        resolved_context=resolved_context,
    )


def _translate_update_metadata(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    workflow_id, revision_id = _require_workflow_ref(resolved_context)
    updates = _normalize_metadata_updates(tool_call.arguments)
    if not updates:
        return AssistantLlmResponse(message=tool_call.raw_text or "")
    return _build_workflow_metadata_record(
        workflow_id=workflow_id,
        revision_id=revision_id,
        updates=updates,
        explanation=tool_call.raw_text or "",
        resolved_context=resolved_context,
    )


def _translate_set_quality_gate(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    workflow_id, revision_id = _require_workflow_ref(resolved_context)
    stage_id = _resolve_stage_id(tool_call.arguments.get("stage_id"), resolved_context) or _selected_stage_id(
        resolved_context
    )
    if not stage_id:
        return AssistantLlmResponse(message=tool_call.raw_text or "")
    workflow = (resolved_context or {}).get("workflow") or {}
    try:
        quality_loop = build_quality_loop_payload(
            workflow,
            stage_id=stage_id,
            loop_back_to=_resolve_stage_id(tool_call.arguments.get("loop_back_to"), resolved_context),
            evaluators=tool_call.arguments.get("evaluators"),
            thresholds=tool_call.arguments.get("thresholds"),
        )
    except ValueError as exc:
        return AssistantLlmResponse(message=str(exc), outcome="invalid")
    return _build_quality_gate_record(
        workflow_id=workflow_id,
        revision_id=revision_id,
        stage_id=stage_id,
        quality_loop=quality_loop,
        explanation=tool_call.raw_text or "",
        resolved_context=resolved_context,
    )


def _translate_edit_template(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    workflow_id, revision_id = _require_workflow_ref(resolved_context)
    stage_id = _resolve_stage_id(tool_call.arguments.get("stage_id"), resolved_context) or _selected_stage_id(
        resolved_context
    )
    template_role = str(tool_call.arguments.get("template_role") or "purpose").strip() or "purpose"
    after_content = str(tool_call.arguments.get("proposed_content") or "").strip()
    if not after_content:
        return AssistantLlmResponse(message=tool_call.raw_text or "")
    before_content = _current_stage_before_content(resolved_context, stage_id, template_role)
    return _build_template_edit_response(
        workflow_id=workflow_id,
        revision_id=revision_id,
        stage_id=stage_id,
        template_role=template_role,
        before_content=before_content,
        after_content=after_content,
        explanation=tool_call.raw_text or "",
    )


def _translate_generate_documentation(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    workflow_id, _revision_id = _require_workflow_ref(resolved_context)
    return _build_generate_documentation_record(
        workflow_id=workflow_id,
        explanation=tool_call.raw_text or "",
    )


def _translate_launch_run(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    workflow_id, revision_id = _require_workflow_ref(resolved_context)
    project_id = str((resolved_context or {}).get("project_id") or "").strip()
    working_dir = (resolved_context or {}).get("working_dir")
    objective = str(tool_call.arguments.get("objective") or f"Assistant launch for {workflow_id}")
    return _translate_run_action(
        tool_call,
        action_id="execute_launch_run",
        action_type="propose_launch_run",
        required_fields={
            "objective": objective,
            "project_id": project_id,
            "working_dir": working_dir,
            "workflow_id": workflow_id,
            "revision_id": revision_id,
            "domain_id": _infer_domain_id(resolved_context),
        },
        preview_fields={
            "run_action_kind": "launch_run",
            "workflow_id": workflow_id,
            "revision_id": revision_id,
            "objective": objective,
        },
    )


def _translate_run_pipeline(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    workflow_id, _revision_id = _require_workflow_ref(resolved_context)
    pipeline_id = str(tool_call.arguments.get("pipeline_id") or "").strip()
    if not pipeline_id:
        return AssistantLlmResponse(message=tool_call.raw_text or "")
    params = (
        dict(tool_call.arguments.get("params"))
        if isinstance(tool_call.arguments.get("params"), dict)
        else {}
    )
    if "user_context" not in params:
        user_context = _summarize_pipeline_user_context(resolved_context)
        if user_context:
            params["user_context"] = user_context
    proposal = build_pipeline_proposal(
        workflow_id=workflow_id,
        pipeline_id=pipeline_id,
        params=params,
        trigger_source="llm_proposed",
    )
    if proposal.get("outcome") == "invalid":
        return AssistantLlmResponse(
            message=str(proposal.get("detail") or tool_call.raw_text or ""),
            outcome="invalid",
        )
    return AssistantLlmResponse(
        message=tool_call.raw_text or "",
        outcome="proposal",
        action_records=[proposal],
    )


def _translate_approve_operator_review(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    selected_run = ((resolved_context or {}).get("selected_run") or (resolved_context or {}).get("latest_run") or {})
    run_id = str(selected_run.get("workflow_run_id") or selected_run.get("run_id") or "").strip()
    if not run_id:
        return AssistantLlmResponse(message=tool_call.raw_text or "")
    blocking_summary = selected_run.get("blocking_summary", {})
    return _translate_run_action(
        tool_call,
        action_id="execute_approve_operator_review",
        action_type="propose_approve_operator_review",
        required_fields={"run_id": run_id},
        preview_fields={
            "run_action_kind": "approve_operator_review",
            "run_id": run_id,
            "required_action": str(
                blocking_summary.get("required_action") or "approve_operator_review"
            ),
        },
    )


def _translate_resolve_escalation(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    selected_run = ((resolved_context or {}).get("selected_run") or (resolved_context or {}).get("latest_run") or {})
    run_id = str(selected_run.get("workflow_run_id") or selected_run.get("run_id") or "").strip()
    escalation_id = str(
        selected_run.get("escalation_id")
        or selected_run.get("correlation", {}).get("escalation_id")
        or ""
    ).strip()
    choice = str(tool_call.arguments.get("choice") or "force_complete").strip()
    if not run_id or not escalation_id:
        return AssistantLlmResponse(message=tool_call.raw_text or "")
    return _translate_run_action(
        tool_call,
        action_id="execute_resolve_escalation",
        action_type="propose_resolve_escalation",
        required_fields={
            "run_id": run_id,
            "escalation_id": escalation_id,
            "choice": choice,
        },
        preview_fields={
            "run_action_kind": "resolve_escalation",
            "run_id": run_id,
            "escalation_id": escalation_id,
            "choice": choice,
        },
    )


def _translate_add_quality_gate(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    workflow_id, revision_id = _require_workflow_ref(resolved_context)
    after_stage_id = _resolve_stage_id(tool_call.arguments.get("after_stage_id"), resolved_context)
    if not after_stage_id:
        return AssistantLlmResponse(message=tool_call.raw_text or "")
    workflow = (resolved_context or {}).get("workflow") or {}
    try:
        quality_loop = build_quality_loop_payload(
            workflow,
            stage_id=after_stage_id,
            loop_back_to=_resolve_stage_id(tool_call.arguments.get("loop_back_to"), resolved_context),
            evaluators=tool_call.arguments.get("evaluators"),
            thresholds=tool_call.arguments.get("thresholds"),
        )
    except ValueError as exc:
        return AssistantLlmResponse(message=str(exc), outcome="invalid")
    return _build_quality_gate_record(
        workflow_id=workflow_id,
        revision_id=revision_id,
        stage_id=after_stage_id,
        quality_loop=quality_loop,
        explanation=tool_call.raw_text or "",
        resolved_context=resolved_context,
    )


def _translate_batch_mutation(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    workflow_id, revision_id = _require_workflow_ref(resolved_context)
    operations_raw = tool_call.arguments.get("operations")
    if not isinstance(operations_raw, list) or not operations_raw:
        return AssistantLlmResponse(message=tool_call.raw_text or "", outcome="invalid")
    try:
        operations = _normalize_batch_operations(operations_raw, resolved_context=resolved_context)
    except ValueError as exc:
        return AssistantLlmResponse(message=str(exc), outcome="invalid")
    if not operations:
        return AssistantLlmResponse(message=tool_call.raw_text or "", outcome="invalid")
    return _build_batch_mutation_record(
        workflow_id=workflow_id,
        revision_id=revision_id,
        operations=operations,
        explanation=tool_call.raw_text or "",
    )


def _translate_review_output(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    del construction_context
    workflow_id, revision_id = _require_workflow_ref(resolved_context)
    response = _build_output_review_response(
        workflow_id=workflow_id,
        revision_id=revision_id,
        explanation=tool_call.raw_text or "",
        resolved_context=resolved_context,
    )
    executable_records = [
        record
        for record in response.action_records or []
        if _is_executable_proposal_record(record)
    ]
    _assign_proposal_group(executable_records)
    return response


_MUTATION_BOUNDARY_TOOLS = {
    "add_stage",
    "remove_stage",
    "update_stage",
    "reorder_stages",
    "connect_stages",
    "disconnect_stages",
    "update_workflow_metadata",
    "set_quality_gate",
    "batch_mutation",
    "edit_template",
    "add_quality_gate",
    "review_output",
    "run_pipeline",
}


_TOOL_DISPATCH: dict[str, Callable[..., AssistantLlmResponse]] = {
    "build_workflow_scaffold": _translate_build_workflow_scaffold,
    "add_stage": _translate_add_stage,
    "remove_stage": _translate_remove_stage,
    "update_stage": _translate_update_stage,
    "reorder_stages": _translate_reorder_stages,
    "connect_stages": _translate_connection,
    "disconnect_stages": _translate_connection,
    "update_workflow_metadata": _translate_update_metadata,
    "set_quality_gate": _translate_set_quality_gate,
    "edit_template": _translate_edit_template,
    "generate_documentation": _translate_generate_documentation,
    "launch_run": _translate_launch_run,
    "run_pipeline": _translate_run_pipeline,
    "approve_operator_review": _translate_approve_operator_review,
    "resolve_escalation": _translate_resolve_escalation,
    "add_quality_gate": _translate_add_quality_gate,
    "batch_mutation": _translate_batch_mutation,
    "review_output": _translate_review_output,
}


def translate_tool_call(
    tool_call: ToolCallResult,
    *,
    resolved_context: dict[str, Any] | None = None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    """Translate a single tool call into one or more proposal records."""
    resolved_context = resolved_context or {}
    tool_name = tool_call.tool_name
    mutation_boundary = _workflow_mutation_boundary_message(resolved_context)

    if tool_name in _MUTATION_BOUNDARY_TOOLS and mutation_boundary:
        return AssistantLlmResponse(message=mutation_boundary)

    # Scaffold-draft fallback: when a mutation tool is called but no persisted
    # workflow exists, apply the mutation to the in-progress scaffold draft
    # instead of failing.  This lets users refine a proposed scaffold before
    # accepting it (e.g. "add a quality gate after lesson skeleton" right after
    # the assistant proposes the scaffold but before the user clicks Accept).
    if (
        tool_name in _SCAFFOLD_DRAFT_ELIGIBLE_TOOLS
        and _resolve_workflow_ref(resolved_context)[0] is None
        and _has_scaffold_draft(construction_context)
    ):
        return _apply_mutation_to_scaffold_draft(
            tool_name,
            tool_call,
            construction_context,  # type: ignore[arg-type]
            resolved_context,
        )

    handler = _TOOL_DISPATCH.get(tool_name)
    if handler is not None:
        return handler(
            tool_call,
            resolved_context=resolved_context,
            construction_context=construction_context,
        )

    if tool_name not in TOOL_NAME_TO_ACTION_ID:
        available_tools = ", ".join(sorted(TOOL_NAME_TO_ACTION_ID.keys()))
        base_message = tool_call.raw_text or ""
        unknown_note = (
            f"\n\nI attempted to use a tool called '{tool_name}' which is not available."
            f" Available tools: {available_tools}."
        )
        return AssistantLlmResponse(message=base_message + unknown_note)

    return AssistantLlmResponse(message=tool_call.raw_text or "")


def translate_tool_calls(
    message: str,
    tool_calls: list[ToolCallResult],
    *,
    resolved_context: dict[str, Any] | None = None,
    construction_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    """Translate a list of tool calls into a single assistant response."""
    if not tool_calls:
        return AssistantLlmResponse(message=message)

    merged_records: list[dict[str, Any]] = []
    outcome = "proposal"
    fallback_message = message
    for tool_call in tool_calls:
        translated = translate_tool_call(
            ToolCallResult(
                tool_name=tool_call.tool_name,
                arguments=tool_call.arguments,
                raw_text=message,
            ),
            resolved_context=resolved_context,
            construction_context=construction_context,
        )
        if not translated.action_records:
            translated_message = str(translated.message or "").strip()
            if translated_message:
                fallback_message = translated_message
            if translated.outcome != "proposal":
                return AssistantLlmResponse(message=fallback_message, outcome=translated.outcome)
            continue
        if translated.outcome != "proposal":
            outcome = translated.outcome
        merged_records.extend(translated.action_records or [])

    if not merged_records:
        return AssistantLlmResponse(message=fallback_message, outcome=outcome)
    return AssistantLlmResponse(message=message, outcome=outcome, action_records=merged_records)
