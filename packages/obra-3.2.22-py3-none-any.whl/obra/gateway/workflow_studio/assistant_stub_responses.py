"""Deterministic stub responses for browser-rig regression tests.

When OBRA_GATEWAY_ASSISTANT_STUB_FALLBACK=true (the browser-rig default),
these responses replace real LLM calls so regression tests get instant,
deterministic answers.

Real user-simulation tests set OBRA_GATEWAY_ASSISTANT_STUB_FALLBACK=false
and hit the live LLM with appropriate long timeouts.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Any

_STUB_ENABLED: bool | None = None


def is_stub_enabled() -> bool:
    """Return True when the gateway should use stub responses instead of the LLM."""
    global _STUB_ENABLED  # noqa: PLW0603
    if _STUB_ENABLED is None:
        _STUB_ENABLED = os.environ.get(
            "OBRA_GATEWAY_ASSISTANT_STUB_FALLBACK", ""
        ).lower() in {"1", "true", "yes"}
    return _STUB_ENABLED


@dataclass(slots=True)
class StubResponse:
    message: str
    outcome: str
    action_records: list[dict[str, Any]] | None = None


def _visual_qa_stub_response(user_message: str) -> StubResponse | None:
    if "IMPORTANT: You are a visual QA evaluator, NOT a workflow assistant." not in user_message:
        return None

    rubric_match = re.search(
        r"(?:Standard design dimensions .*?:|Holistic design dimensions .*?:)\n"
        r"(?P<body>.*?)\nFor each question, respond with EXACTLY one line in this format:",
        user_message,
        re.DOTALL,
    )
    rubric_body = rubric_match.group("body") if rubric_match else ""
    rubric_lines = [
        line.strip()
        for line in rubric_body.splitlines()
        if re.match(r"^\d+\.\s+", line.strip())
    ]

    if not rubric_lines:
        return None

    response_lines: list[str] = []
    for index, line in enumerate(rubric_lines, start=1):
        question_text = re.sub(r"^\d+\.\s+", "", line)
        question_text = re.sub(r"^\[[^\]]+\]\s+", "", question_text).strip()
        response_lines.append(
            f"Q{index}: SOLID - {question_text or f'Question {index}'} is visually clear and coherent in this state."
        )

    response_lines.append("OVERALL: SOLID")
    return StubResponse(
        message="\n".join(response_lines),
        outcome="advice",
    )


def _scaffold_action(
    title: str,
    domain_id: str,
    stages: list[dict[str, Any]],
    *,
    compile_ready: bool = False,
    quality_gates: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    scaffold_definition = {
        "title": title,
        "domain_id": domain_id,
        "description": f"Auto-generated {title.lower()} workflow.",
        "stages": stages,
    }
    if compile_ready:
        scaffold_definition["compile_ready"] = True
    if quality_gates:
        scaffold_definition["quality_gates"] = quality_gates
    return {
        "action_id": "execute_draft_workflow_from_thread",
        "action_type": "draft_workflow_from_thread",
        "preview_type": "scaffold",
        "status": "pending",
        "preview": {
            "preview_type": "scaffold",
            "scaffold_definition": scaffold_definition,
        },
        "action_inputs": {
            "scaffold_definition": scaffold_definition,
        },
        "scaffold_definition": scaffold_definition,
    }


def _diff_action(
    stage_id: str,
    template_role: str,
    before: str,
    after: str,
) -> dict[str, Any]:
    return {
        "action_id": f"propose_template_edit_{stage_id}",
        "action_type": "propose_template_edit",
        "preview_type": "diff",
        "status": "pending",
        "preview": {
            "preview_type": "diff",
            "stage_id": stage_id,
            "template_role": template_role,
            "before_content": before,
            "after_content": after,
        },
        "stage_id": stage_id,
        "template_role": template_role,
        "before_content": before,
        "after_content": after,
    }


def _template_edit_action(
    stage_id: str,
    template_role: str,
    proposed_content: str,
) -> dict[str, Any]:
    return {
        "action_id": "execute_template_edit",
        "action_type": "propose_template_edit",
        "preview_type": "diff",
        "status": "pending",
        "preview": {
            "preview_type": "diff",
            "stage_id": stage_id,
            "template_role": template_role,
            "before_content": "",
            "after_content": proposed_content,
        },
        "action_inputs": {
            "stage_id": stage_id,
            "template_role": template_role,
            "proposed_content": proposed_content,
        },
        "stage_id": stage_id,
        "template_role": template_role,
        "before_content": "",
        "after_content": proposed_content,
    }


def _batch_mutation_action(operations: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "action_id": "execute_batch_mutation",
        "action_type": "batch_mutation",
        "preview_type": "batch_mutation",
        "status": "pending",
        "preview": {
            "preview_type": "batch_mutation",
            "operation_count": len(operations),
        },
        "action_inputs": {
            "operations": operations,
        },
        "operation_count": len(operations),
    }


def _output_review_findings(route: str) -> dict[str, Any]:
    return {
        "action_id": "review_output_findings",
        "action_type": "review_output",
        "preview_type": "output_review_findings",
        "status": "pending",
        "route": route,
        "preview": {
            "preview_type": "output_review_findings",
            "route": route,
            "findings": [
                {
                    "issue": "Stage output lacks required verification evidence.",
                    "suggestion": "Add explicit verification criteria to the stage template.",
                    "severity": "revise",
                },
            ],
        },
        "findings": [
            {
                "issue": "Stage output lacks required verification evidence.",
                "suggestion": "Add explicit verification criteria to the stage template.",
                "severity": "revise",
            },
        ],
    }


def _documentation_action() -> dict[str, Any]:
    return {
        "action_id": "generate_documentation",
        "action_type": "generate_documentation",
        "preview_type": "documentation",
        "status": "pending",
        "preview": {
            "preview_type": "documentation",
            "markdown_content": (
                "# Workflow Documentation\n\n"
                "## Overview\n"
                "This workflow processes data through a series of stages.\n\n"
                "## Stages\n"
                "1. **Intake** — Normalize incoming data.\n"
                "2. **Review** — Assess against policy.\n"
            ),
        },
        "markdown_content": (
            "# Workflow Documentation\n\n"
            "## Overview\n"
            "This workflow processes data through a series of stages.\n\n"
            "## Stages\n"
            "1. **Intake** — Normalize incoming data.\n"
            "2. **Review** — Assess against policy.\n"
        ),
    }


def _starter_action() -> dict[str, Any]:
    return {
        "action_id": "starter_recommendation",
        "action_type": "starter_recommendation",
        "preview_type": "starter_recommendation",
        "status": "pending",
        "preview": {
            "preview_type": "starter_recommendation",
            "starter_id": "invoice-processing",
            "display_name": "Invoice Processing Starter",
        },
    }


def _launch_run_action(ctx: dict[str, Any]) -> dict[str, Any]:
    workflow = ctx.get("workflow") or {}
    workflow_id = str(workflow.get("workflow_id") or "")
    return {
        "action_id": "execute_launch_run",
        "action_type": "launch_run",
        "preview_type": "run_action",
        "status": "pending",
        "preview": {
            "preview_type": "run_action",
            "action": "launch_run",
        },
        "action_inputs": {
            "objective": f"Browser rig stub run for {workflow_id}",
            "project_id": "workflow-studio-browser-rig",
            "workflow_id": workflow_id,
        },
    }


def _approve_action(ctx: dict[str, Any]) -> dict[str, Any]:
    latest_run = ctx.get("latest_run") or {}
    run_id = str(latest_run.get("workflow_run_id") or latest_run.get("run_id") or "")
    return {
        "action_id": "execute_approve_operator_review",
        "action_type": "approve_operator_review",
        "preview_type": "run_action",
        "status": "pending",
        "preview": {
            "preview_type": "run_action",
            "action": "approve_operator_review",
        },
        "action_inputs": {
            "run_id": run_id,
        },
    }


_INVOICE_STAGES = [
    {"id": "receive-email", "title": "Receive email attachment", "purpose": "Extract invoice from inbound email.", "depends_on": []},
    {"id": "extract-data", "title": "Extract invoice data", "purpose": "OCR and field extraction.", "depends_on": ["receive-email"]},
    {"id": "validate-data", "title": "Validate extracted data", "purpose": "Check completeness and format.", "depends_on": ["extract-data"]},
    {"id": "route-approval", "title": "Route for approval", "purpose": "Send to the appropriate approver.", "depends_on": ["validate-data"]},
]

_DOCUMENT_REVIEW_STAGES = [
    {
        "id": "document-intake",
        "title": "Document Intake",
        "purpose": "Receive the source document and establish the processing context.",
        "depends_on": [],
    },
    {
        "id": "metadata-extraction",
        "title": "Metadata Extraction",
        "purpose": "Extract routing metadata, source provenance, and basic document attributes.",
        "depends_on": ["document-intake"],
    },
    {
        "id": "content-classification",
        "title": "Content Classification",
        "purpose": "Classify the document type and the downstream review path.",
        "depends_on": ["metadata-extraction"],
    },
    {
        "id": "pii-detection",
        "title": "PII Detection",
        "purpose": "Detect regulated personal data and tag sensitive spans.",
        "depends_on": ["content-classification"],
    },
    {
        "id": "compliance-check",
        "title": "Compliance Check",
        "purpose": "Validate retention, handling, and policy obligations before release.",
        "depends_on": ["pii-detection"],
    },
    {
        "id": "redaction-application",
        "title": "Redaction Application",
        "purpose": "Apply the approved redaction strategy to the sensitive content.",
        "depends_on": ["compliance-check"],
    },
    {
        "id": "final-assembly",
        "title": "Final Assembly",
        "purpose": "Assemble the reviewed output package and supporting metadata.",
        "depends_on": ["redaction-application"],
    },
    {
        "id": "delivery",
        "title": "Delivery",
        "purpose": "Deliver the reviewed package to the target destination.",
        "depends_on": ["final-assembly"],
    },
]

_DOCUMENT_REVIEW_QUALITY_GATES = [
    {
        "after_stage_id": "pii-detection",
        "gate_type": "review",
        "loop_back_to": "pii-detection",
    },
    {
        "after_stage_id": "compliance-check",
        "gate_type": "review",
        "loop_back_to": "compliance-check",
    },
]


def _slugify_stage_title(title: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", title.strip().lower()).strip("-")
    return normalized or "stage"


def _primary_instruction_binding(stage_id: str, stage_title: str) -> dict[str, Any]:
    path_hint = f"stages/{stage_id}_{_slugify_stage_title(stage_title)}.md"
    return {
        "binding_role": "primary_stage_instruction",
        "binding_scope": "stage",
        "stage_id": stage_id,
        "path_hint": path_hint,
        "content_format": "markdown",
        "adoption_state": "approved_for_execution",
        "target_artifact_type": "stage_asset",
        "target_artifact_id": path_hint,
        "target_version_selector": "current",
        "relationship_type": "binds_to",
        "materialization_metadata": {"path": path_hint},
    }


def _compile_ready_stages(stages: list[dict[str, Any]], *, first_input: str) -> list[dict[str, Any]]:
    enriched: list[dict[str, Any]] = []
    prior_outputs: list[str] = [first_input]
    for index, stage in enumerate(stages):
        stage_id = str(stage.get("id") or "").strip()
        title = str(stage.get("title") or stage_id).strip()
        output_name = f"{stage_id}-output"
        enriched_stage = dict(stage)
        enriched_stage["inputs"] = [first_input] if index == 0 else list(prior_outputs)
        enriched_stage["outputs"] = [output_name]
        enriched_stage["verification"] = [
            f"Verify {title.lower()} produced the expected handoff artifacts and metadata."
        ]
        enriched_stage["quality_gates"] = ["contract_validation"]
        enriched_stage["template_asset_bindings"] = [
            _primary_instruction_binding(stage_id, title)
        ]
        enriched.append(enriched_stage)
        prior_outputs = [output_name]
    return enriched

_DATA_ANALYSIS_STAGES = [
    {"id": "collect-sources", "title": "Collect data sources", "purpose": "Gather input datasets.", "depends_on": []},
    {"id": "clean-transform", "title": "Clean and transform", "purpose": "Normalize and prepare data.", "depends_on": ["collect-sources"]},
    {"id": "analyze", "title": "Run analysis", "purpose": "Apply analytical models.", "depends_on": ["clean-transform"]},
    {"id": "report", "title": "Generate report", "purpose": "Produce analysis output.", "depends_on": ["analyze"]},
]

_QUARTERLY_REPORT_STAGES = [
    {
        "id": "collect-finance-ledger",
        "title": "Collect Finance Ledger",
        "purpose": "Pull the primary finance ledger for the reporting window.",
        "depends_on": [],
    },
    {
        "id": "collect-sales-signals",
        "title": "Collect Sales Signals",
        "purpose": "Gather pipeline, bookings, and revenue-supporting source data.",
        "depends_on": [],
    },
    {
        "id": "collect-forecast-inputs",
        "title": "Collect Forecast Inputs",
        "purpose": "Gather forecast assumptions and scenario inputs.",
        "depends_on": [],
    },
    {
        "id": "data-validation",
        "title": "Data Validation",
        "purpose": "Validate completeness and reconcile source anomalies.",
        "depends_on": [
            "collect-finance-ledger",
            "collect-sales-signals",
            "collect-forecast-inputs",
        ],
    },
    {
        "id": "metric-calculation",
        "title": "Metric Calculation",
        "purpose": "Compute the core quarterly financial metrics.",
        "depends_on": ["data-validation"],
    },
    {
        "id": "trend-analysis",
        "title": "Trend Analysis",
        "purpose": "Interpret directional movement and major quarter-over-quarter changes.",
        "depends_on": ["metric-calculation"],
    },
    {
        "id": "executive-summary",
        "title": "Executive Summary",
        "purpose": "Draft the executive summary narrative.",
        "depends_on": ["trend-analysis"],
    },
    {
        "id": "revenue-analysis",
        "title": "Revenue Analysis",
        "purpose": "Draft the revenue analysis narrative section.",
        "depends_on": ["trend-analysis"],
    },
    {
        "id": "expense-analysis",
        "title": "Expense Analysis",
        "purpose": "Draft the expense analysis narrative section.",
        "depends_on": ["trend-analysis"],
    },
    {
        "id": "forecast",
        "title": "Forecast",
        "purpose": "Draft the forecast narrative and forward-looking assumptions.",
        "depends_on": ["trend-analysis"],
    },
    {
        "id": "chart-generation",
        "title": "Chart Generation",
        "purpose": "Generate charts and visual evidence for each report section.",
        "depends_on": ["metric-calculation"],
    },
    {
        "id": "final-assembly-and-signoff",
        "title": "Final Assembly and Sign-Off",
        "purpose": "Assemble the report with cross-references and complete compliance sign-off.",
        "depends_on": [
            "executive-summary",
            "revenue-analysis",
            "expense-analysis",
            "forecast",
            "chart-generation",
        ],
    },
]


# ---------------------------------------------------------------------------
# Pattern matchers — order matters, first match wins
# ---------------------------------------------------------------------------

_PATTERNS: list[tuple[re.Pattern[str], Any]] = []


def _p(pattern: str, fn: Any) -> None:
    _PATTERNS.append((re.compile(pattern, re.IGNORECASE), fn))


def _dirty_draft_response(_msg: str, ctx: dict[str, Any]) -> StubResponse | None:
    """Return advisory if the editor has unsaved changes."""
    ui = ctx.get("ui_context") or ctx.get("ui_state") or {}
    dirty = ui.get("dirty") or ui.get("unsaved_changes")
    if not dirty:
        return None
    return StubResponse(
        message=(
            "Save, discard, or reload the draft before I prepare "
            "an executable workflow mutation against the persisted workflow."
        ),
        outcome="advice",
    )


def _draft_invoice(_msg: str, _ctx: dict[str, Any]) -> StubResponse:
    return StubResponse(
        message="Designing an invoice processing workflow from email attachments.",
        outcome="proposal",
        action_records=[
            _scaffold_action("Invoice Processing", "business", _INVOICE_STAGES),
        ],
    )


def _draft_data_analysis(_msg: str, _ctx: dict[str, Any]) -> StubResponse:
    return StubResponse(
        message="Designing a data analysis workflow.",
        outcome="proposal",
        action_records=[
            _scaffold_action("Data Analysis Pipeline", "software", _DATA_ANALYSIS_STAGES),
        ],
    )


def _draft_document_review_with_gates(_msg: str, _ctx: dict[str, Any]) -> StubResponse:
    return StubResponse(
        message="Designing a document review workflow with explicit PII and compliance gates.",
        outcome="proposal",
        action_records=[
            _scaffold_action(
                "Document Review Workflow",
                "software",
                _compile_ready_stages(
                    _DOCUMENT_REVIEW_STAGES,
                    first_input="document-review-request",
                ),
                compile_ready=True,
                quality_gates=_DOCUMENT_REVIEW_QUALITY_GATES,
            ),
        ],
    )


def _draft_quarterly_financial_report(_msg: str, _ctx: dict[str, Any]) -> StubResponse:
    return StubResponse(
        message="Designing a quarterly financial reporting workflow with downstream self-review.",
        outcome="proposal",
        action_records=[
            _scaffold_action(
                "Quarterly Financial Report Workflow",
                "software",
                _QUARTERLY_REPORT_STAGES,
            ),
        ],
    )


def _draft_pii_template(_msg: str, _ctx: dict[str, Any]) -> StubResponse:
    content = (
        "# PII Detection\n\n"
        "## Inputs\n"
        "- `content-classification-output`\n"
        "- Document metadata and routing context.\n\n"
        "## Outputs\n"
        "- `pii-detection-output` with sensitive spans, entity categories, and confidence flags.\n\n"
        "## Checks\n"
        "- Detect direct identifiers and regulated personal data markers.\n"
        "- Record unresolved low-confidence findings for manual review.\n"
        "- Fail the gate when required entity classes are missing from the scan.\n\n"
        "## Decision Rules\n"
        "- Proceed when required PII classes are tagged with sufficient confidence.\n"
        "- Return to the stage for refinement when confidence is below the release threshold.\n"
    )
    return StubResponse(
        message="Proposing an execution-ready template for the PII detection stage.",
        outcome="proposal",
        action_records=[_template_edit_action("pii-detection", "main", content)],
    )


def _draft_batch_mutation(_msg: str, _ctx: dict[str, Any]) -> StubResponse:
    operations = [
        {
            "operation": "update_stage",
            "stage_id": "content-classification",
            "updates": {"title": "Document Categorization"},
        },
        {
            "operation": "edit_template",
            "stage_id": "content-classification",
            "template_role": "main",
            "proposed_content": (
                "# Document Categorization\n\n"
                "## Inputs\n"
                "- `metadata-extraction-output`\n\n"
                "## Outputs\n"
                "- `document-categorization-output`\n\n"
                "## Checks\n"
                "- Classify SOX, HIPAA, and GDPR-sensitive document types explicitly.\n\n"
                "## Decision Rules\n"
                "- Route mixed-regulation packets to the strictest downstream compliance path.\n"
            ),
        },
    ]
    return StubResponse(
        message="Bundling the stage rename and template update into one workflow mutation.",
        outcome="proposal",
        action_records=[_batch_mutation_action(operations)],
    )


def _draft_generic(_msg: str, _ctx: dict[str, Any]) -> StubResponse:
    return StubResponse(
        message="Designing a workflow based on your description.",
        outcome="proposal",
        action_records=[
            _scaffold_action("Custom Workflow", "software", _INVOICE_STAGES),
        ],
    )


def _launch_run(_msg: str, ctx: dict[str, Any]) -> StubResponse:
    return StubResponse(
        message="Launching a new run for this workflow.",
        outcome="proposal",
        action_records=[_launch_run_action(ctx)],
    )


def _approve_run(_msg: str, ctx: dict[str, Any]) -> StubResponse:
    return StubResponse(
        message="Approving the blocked operator checkpoint.",
        outcome="proposal",
        action_records=[_approve_action(ctx)],
    )


def _review_output(_msg: str, ctx: dict[str, Any]) -> StubResponse:
    route = "artifact" if ctx.get("selected_artifact") else "run"
    return StubResponse(
        message="Reviewing the output and proposing workflow fixes.",
        outcome="proposal",
        action_records=[
            _output_review_findings(route),
            _diff_action(
                "intake", "main",
                "Original stage template content.",
                "Improved stage template with verification criteria.",
            ),
            _diff_action(
                "review", "main",
                "Original review template.",
                "Enhanced review template with explicit policy references.",
            ),
        ],
    )


def _generate_docs(_msg: str, _ctx: dict[str, Any]) -> StubResponse:
    return StubResponse(
        message="Generating documentation for this workflow.",
        outcome="proposal",
        action_records=[_documentation_action()],
    )


def _recommend_starter(_msg: str, _ctx: dict[str, Any]) -> StubResponse:
    return StubResponse(
        message="Recommending a starter workflow template for invoice processing.",
        outcome="proposal",
        action_records=[_starter_action()],
    )


def _add_stage(_msg: str, ctx: dict[str, Any]) -> StubResponse | None:
    dirty = _dirty_draft_response(_msg, ctx)
    if dirty is not None:
        return dirty
    return StubResponse(
        message="Proposing to add a new stage to the workflow.",
        outcome="proposal",
        action_records=[
            {
                "action_id": "execute_add_stage",
                "action_type": "add_stage",
                "preview_type": "diff",
                "status": "pending",
                "preview": {"preview_type": "diff", "operation": "add_stage"},
            },
        ],
    )


def _remove_stage(_msg: str, ctx: dict[str, Any]) -> StubResponse | None:
    dirty = _dirty_draft_response(_msg, ctx)
    if dirty is not None:
        return dirty
    return StubResponse(
        message="Proposing to remove the selected stage.",
        outcome="proposal",
        action_records=[
            {
                "action_id": "execute_remove_stage",
                "action_type": "remove_stage",
                "preview_type": "diff",
                "status": "pending",
                "preview": {"preview_type": "diff", "operation": "remove_stage"},
            },
        ],
    )


def _generic_advice(_msg: str, _ctx: dict[str, Any]) -> StubResponse:
    return StubResponse(
        message=(
            "I'm the Studio Assistant for Obra Workflow Studio. "
            "I can help you design, refine, debug, and improve workflow graphs."
        ),
        outcome="advice",
    )


# Register patterns — first match wins
_p(r"launch run", _launch_run)
_p(r"approve.*blocked", _approve_run)
_p(r"review this (output|run output).*propose", _review_output)
_p(r"review this output", _review_output)
_p(r"generate doc", _generate_docs)
_p(r"document this workflow", _generate_docs)
_p(r"recommend.*starter", _recommend_starter)
_p(r"stage template.*pii detection|pii detection stage", _draft_pii_template)
_p(
    r"rename.*content classification.*document categorization|do both changes in one batch",
    _draft_batch_mutation,
)
_p(
    r"document review workflow|pii detection|compliance check|redaction application",
    _draft_document_review_with_gates,
)
_p(
    r"quarterly financial report workflow|financial report workflow.*chart generation|executive summary.*revenue analysis.*expense analysis.*forecast",
    _draft_quarterly_financial_report,
)
_p(r"draft.*workflow.*invoice|invoice.*workflow", _draft_invoice)
_p(r"draft.*workflow.*data.analy", _draft_data_analysis)
_p(r"draft.*workflow|build.*workflow", _draft_generic)
_p(r"add.*(stage|step|approval)", _add_stage)
_p(r"remove.*(stage|step|this stage)", _remove_stage)


def match_stub_response(
    user_message: str,
    resolved_context: dict[str, Any],
) -> StubResponse | None:
    """Return a deterministic stub response if the message matches, else None."""
    if not is_stub_enabled():
        return None

    visual_qa_response = _visual_qa_stub_response(user_message)
    if visual_qa_response is not None:
        return visual_qa_response

    for pattern, handler in _PATTERNS:
        if pattern.search(user_message):
            result = handler(user_message, resolved_context)
            if result is not None:
                return result

    # Fallback: generic advice for anything unmatched
    return _generic_advice(user_message, resolved_context)
