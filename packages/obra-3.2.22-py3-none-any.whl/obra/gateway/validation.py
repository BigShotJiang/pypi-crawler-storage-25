"""Gateway validation helpers for workflow-run launch requests."""

from __future__ import annotations

from typing import Any


def validate_input_against_spec(
    input_document: dict[str, Any],
    input_payload: dict[str, str] | None,
) -> list[str]:
    """Return validation errors for a run payload against a workflow input spec."""
    required_fields = [str(field).strip() for field in input_document.get("required_fields", [])]
    required_fields = [field for field in required_fields if field]
    if not required_fields:
        return []
    if input_payload is None:
        return [
            "input_payload is required; workflow expects fields: "
            + ", ".join(required_fields)
        ]

    missing_fields = [field for field in required_fields if field not in input_payload]
    if missing_fields:
        return [f"Missing required input fields: {', '.join(missing_fields)}"]
    return []


def resolve_input_document_from_workflow(
    workflow_detail: dict[str, Any],
) -> dict[str, Any] | None:
    """Extract the canonical input_document payload from a workflow detail."""
    workflow_definition = workflow_detail.get("workflow_definition", {})
    if not isinstance(workflow_definition, dict):
        return None
    input_document = workflow_definition.get("input_document")
    return input_document if isinstance(input_document, dict) else None
