"""Unified directory walker for codebase exploration.

Replaces 4 duplicated directory-walking implementations with a single
BFS-based walker. Supports extension filtering, early exit, and
graceful error handling.

Extracted from obra/hybrid/handlers/derive.py as part of
REFACTOR-EXPLORATION-001.

Related:
    - obra/intent/detection.py (EXCLUDED_DIRS, EXCLUDED_PATTERNS)
"""

from collections.abc import Iterator
from pathlib import Path


def walk_project_files(
    root: Path,
    *,
    max_files: int = 10000,
    excluded_dirs: set[str] | None = None,
    excluded_patterns: set[str] | None = None,
    extensions: set[str] | None = None,
) -> Iterator[Path]:
    """Walk project files using iterative BFS, skipping excluded directories.

    Args:
        root: Root directory to walk
        max_files: Maximum files to yield (early exit)
        excluded_dirs: Directory names to skip. Defaults to EXCLUDED_DIRS
            from obra.intent.detection.
        excluded_patterns: File name patterns to skip. Defaults to
            EXCLUDED_PATTERNS from obra.intent.detection.
        extensions: If provided, only yield files whose suffix (lowercased)
            is in this set. Example: {'.py', '.js'}

    Yields:
        Path objects for each matching file
    """
    if excluded_dirs is None:
        from obra.intent.detection import EXCLUDED_DIRS

        excluded_dirs = EXCLUDED_DIRS
    if excluded_patterns is None:
        from obra.intent.detection import EXCLUDED_PATTERNS

        excluded_patterns = EXCLUDED_PATTERNS

    if not root.exists():
        return

    count = 0
    dirs_to_process = [root]
    while dirs_to_process and count < max_files:
        current_dir = dirs_to_process.pop()
        try:
            for item in current_dir.iterdir():
                if item.is_dir():
                    if item.name not in excluded_dirs:
                        dirs_to_process.append(item)
                elif item.is_file():
                    if any(pattern in item.name for pattern in excluded_patterns):
                        continue
                    if extensions is not None and item.suffix.lower() not in extensions:
                        continue
                    yield item
                    count += 1
                    if count >= max_files:
                        break
        except (PermissionError, OSError):
            continue


def count_project_files(
    root: Path,
    *,
    max_count: int = 10000,
    excluded_dirs: set[str] | None = None,
    excluded_patterns: set[str] | None = None,
    extensions: set[str] | None = None,
) -> int:
    """Count project files, exiting early when max_count is reached.

    Args:
        root: Root directory to count files in
        max_count: Stop counting after this many files
        excluded_dirs: Directory names to skip. Defaults to EXCLUDED_DIRS.
        excluded_patterns: File name patterns to skip. Defaults to EXCLUDED_PATTERNS.
        extensions: If provided, only count files whose suffix (lowercased)
            is in this set.

    Returns:
        Count of matching files (capped at max_count)
    """
    if excluded_dirs is None:
        from obra.intent.detection import EXCLUDED_DIRS

        excluded_dirs = EXCLUDED_DIRS
    if excluded_patterns is None:
        from obra.intent.detection import EXCLUDED_PATTERNS

        excluded_patterns = EXCLUDED_PATTERNS

    if not root.exists():
        return 0

    count = 0
    dirs_to_process = [root]
    while dirs_to_process and count < max_count:
        current_dir = dirs_to_process.pop()
        try:
            for item in current_dir.iterdir():
                if item.is_dir():
                    if item.name not in excluded_dirs:
                        dirs_to_process.append(item)
                elif item.is_file():
                    if any(pattern in item.name for pattern in excluded_patterns):
                        continue
                    if extensions is not None and item.suffix.lower() not in extensions:
                        continue
                    count += 1
                    if count >= max_count:
                        break
        except (PermissionError, OSError):
            continue

    return count
