"""Codebase exploration module for auto-exploration before derivation (ADR-055).

This package provides the exploration subsystem extracted from
obra/hybrid/handlers/derive.py. It handles:

- Decision logic for when to auto-explore
- Codebase context collection (directory tree, file summary, key files)
- LLM-based exploration execution and response parsing
- Exploration result caching with invalidation
- Recent exploration detection from session logs

Public API (lazy-loaded via PEP 562):
    ExplorationContext: Exploration result dataclass
    ExplorationDecision: Decision result dataclass
    ExplorationCacheEntry: Cache entry dataclass
    FILE_PATH_PATTERN: Regex for file path detection
    walk_project_files: Unified directory walker
    count_project_files: File counting with early exit
    should_auto_explore: Decision function
    detect_work_type: Work type classifier
    detect_recent_exploration: Recent exploration detector
    run_exploration: LLM exploration runner
    ExplorationCache: Session-scoped cache
    get_exploration_config: Config loader (cached)
    clear_config_cache: Config cache invalidation
    collect_codebase_context: Context collection

Related:
    - docs/decisions/ADR-055-conditional-auto-exploration.md
    - docs/design/prds/CONDITIONAL_AUTO_EXPLORATION_PRD.md
"""

from typing import Any

__all__ = [
    "COMPLEXITY_THRESHOLDS",
    "ExplorationCacheEntry",
    "ExplorationCache",
    "ExplorationContext",
    "ExplorationDecision",
    "FILE_PATH_PATTERN",
    "clear_config_cache",
    "collect_codebase_context",
    "count_project_files",
    "detect_recent_exploration",
    "detect_work_type",
    "get_exploration_config",
    "run_exploration",
    "should_auto_explore",
    "walk_project_files",
]

# Submodule import map for PEP 562 lazy loading (Rule 20, ADR-045)
_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "ExplorationContext": (".models", "ExplorationContext"),
    "ExplorationDecision": (".models", "ExplorationDecision"),
    "ExplorationCacheEntry": (".models", "ExplorationCacheEntry"),
    "FILE_PATH_PATTERN": (".models", "FILE_PATH_PATTERN"),
    "COMPLEXITY_THRESHOLDS": (".models", "COMPLEXITY_THRESHOLDS"),
    "walk_project_files": (".walker", "walk_project_files"),
    "count_project_files": (".walker", "count_project_files"),
    "should_auto_explore": (".decision", "should_auto_explore"),
    "detect_work_type": (".decision", "detect_work_type"),
    "detect_recent_exploration": (".detection", "detect_recent_exploration"),
    "run_exploration": (".runner", "run_exploration"),
    "ExplorationCache": (".cache", "ExplorationCache"),
    "get_exploration_config": (".config", "get_exploration_config"),
    "clear_config_cache": (".config", "clear_config_cache"),
    "collect_codebase_context": (".context", "collect_codebase_context"),
}


def __getattr__(name: str) -> Any:
    """PEP 562 lazy loading for exploration submodules (ADR-045, Rule 20).

    Defers import of submodules until the specific symbol is accessed,
    avoiding heavy transitive imports for consumers that only need a subset.
    """
    if name in _LAZY_IMPORTS:
        module_path, attr_name = _LAZY_IMPORTS[name]
        import importlib

        module = importlib.import_module(module_path, __name__)
        return getattr(module, attr_name)
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)
