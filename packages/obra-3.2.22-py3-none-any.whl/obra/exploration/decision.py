"""Exploration decision logic for auto-exploration before derivation (ADR-055).

Extracted from DeriveHandler._should_auto_explore() and
DeriveHandler._detect_work_type() as part of REFACTOR-EXPLORATION-001.

Determines whether codebase exploration should run before plan derivation
based on config flags, bypass modes, work type, and project state.

Related:
    - obra/config/default_config.yaml (orchestration.exploration)
    - docs/decisions/ADR-055-conditional-auto-exploration.md
"""

import logging
from pathlib import Path
from typing import Any

from obra.exploration.models import FILE_PATH_PATTERN, ExplorationDecision
from obra.workflow.derivation.domain_metadata import (
    classify_work_type_from_metadata,
    resolve_domain_derivation_metadata,
)

logger = logging.getLogger(__name__)


def should_auto_explore(
    objective: str,
    work_type: str,
    exploration_state: dict[str, Any],
    working_dir: Path | None,
    *,
    complexity_score: float | None = None,
    exploration_config: dict[str, Any] | None = None,
    bypass_modes: list[str] | None = None,
) -> ExplorationDecision:
    """Determine if auto-exploration should run before derivation (ADR-055).

    Default behavior: Explore if project has files. Skip conditions are
    evaluated in order; the first match short-circuits.

    Skip conditions (in order):
    1. exploration.enabled = false in config
    2. force_explore bypass → forces exploration
    3. skip_explore bypass → skips exploration
    4. Bug fix with explicit file paths in objective
    5. Recent exploration detected (< N hours)
    6. Empty project (< threshold files)
    7. No working directory configured

    If none of the skip conditions apply, exploration runs.

    Args:
        objective: User objective text
        work_type: Detected work type (for logging/observability)
        exploration_state: Result from detect_recent_exploration()
        working_dir: Project working directory (None if not configured)
        complexity_score: Optional complexity score (for logging)
        exploration_config: Pre-loaded config (loads from cache if None)
        bypass_modes: Active bypass modes (e.g., ['force_explore'])

    Returns:
        ExplorationDecision with should_explore flag and reasoning
    """
    bypass_modes = bypass_modes or []

    # Load exploration config if not provided
    if exploration_config is None:
        from obra.exploration.config import get_exploration_config

        exploration_config = get_exploration_config()

    # 1. Check master enable flag
    if not exploration_config["enabled"]:
        return ExplorationDecision(
            should_explore=False,
            reason="exploration disabled via config",
            skip_reason="config_disabled",
        )

    # 2. Check force_explore bypass
    if "force_explore" in bypass_modes:
        return ExplorationDecision(
            should_explore=True,
            reason="force_explore bypass mode active",
            work_type=work_type,
        )

    # 3. Check skip_explore bypass
    if "skip_explore" in bypass_modes:
        return ExplorationDecision(
            should_explore=False,
            reason="skip_explore bypass mode active",
            skip_reason="skip_explore",
        )

    # 4. Check for bug fix with explicit file paths
    has_explicit_paths = bool(FILE_PATH_PATTERN.search(objective))
    skip_config = exploration_config["skip"]

    if work_type == "bug_fix" and has_explicit_paths:
        if skip_config["bug_fix_with_path"]:
            return ExplorationDecision(
                should_explore=False,
                reason="bug fix with explicit file paths",
                work_type=work_type,
                has_explicit_paths=True,
                skip_reason="bug_fix_with_path",
            )

    # 5. Check recent exploration
    recent_exploration = exploration_state.get("recent_exploration", False)
    if recent_exploration:
        return ExplorationDecision(
            should_explore=False,
            reason="recent exploration detected",
            work_type=work_type,
            recent_exploration=True,
            skip_reason="recent_exploration",
        )

    # 6. Check for empty/small project
    empty_project_threshold = skip_config["empty_project_files"]
    if working_dir and empty_project_threshold > 0:
        from obra.exploration.walker import count_project_files

        file_count = count_project_files(working_dir, max_count=empty_project_threshold + 1)
        logger.debug(
            "Empty project check: %d files in %s, threshold=%d",
            file_count,
            working_dir,
            empty_project_threshold,
        )
        if file_count < empty_project_threshold:
            return ExplorationDecision(
                should_explore=False,
                reason=f"project has {file_count} files (< {empty_project_threshold} threshold)",
                work_type=work_type,
                skip_reason="empty_project",
            )
    elif not working_dir:
        # 7. No working directory - skip exploration entirely
        logger.warning("No working directory set, skipping exploration")
        return ExplorationDecision(
            should_explore=False,
            reason="no working directory configured",
            work_type=work_type,
            skip_reason="no_working_dir",
        )

    # All skip conditions passed - explore the codebase
    return ExplorationDecision(
        should_explore=True,
        reason="project has files to explore",
        work_type=work_type,
        complexity_score=complexity_score,
    )


def detect_work_type(
    objective: str,
    *,
    domain: Any | None = None,
    work_type_keywords: dict[str, list[str]] | None = None,
    work_type_override: str | None = None,
) -> str:
    """Classify the objective into a coarse work type.

    Uses explicit work type keywords when provided. If a work_type_override is
    provided, it is used directly. Domain-aware derivation paths resolve
    keyword sources and fallback work types from the active domain metadata.

    Args:
        objective: User objective text
        domain: Optional active domain module for derivation-time defaults
        work_type_keywords: Optional work-type keyword mapping from active domain
        work_type_override: Manual override (e.g., from --work-type CLI flag)

    Returns:
        Work type string (e.g., 'bug_fix', 'feature_implementation', 'general')
    """
    if work_type_override:
        logger.info("Using manual work type override: %s", work_type_override)
        return work_type_override

    metadata = resolve_domain_derivation_metadata(domain)
    resolved_keywords = work_type_keywords or metadata.work_type_keywords
    if not resolved_keywords:
        return metadata.fallback_work_type or "general"

    return (
        classify_work_type_from_metadata(
            objective,
            metadata,
            work_type_override=work_type_override,
        )
        if resolved_keywords == metadata.work_type_keywords
        else _classify_from_keywords(
            objective,
            resolved_keywords,
            fallback_work_type=metadata.fallback_work_type or "general",
        )
    )


def _classify_from_keywords(
    objective: str,
    work_type_keywords: dict[str, list[str]],
    *,
    fallback_work_type: str,
) -> str:
    lowered = objective.lower()
    for work_type, keywords in work_type_keywords.items():
        if any(keyword in lowered for keyword in keywords):
            return str(work_type)
    return fallback_work_type
