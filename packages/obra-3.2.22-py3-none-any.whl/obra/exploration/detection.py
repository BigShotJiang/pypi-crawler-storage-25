"""Recent exploration detection from session logs.

Extracted from obra/execution/derivation.py as part of
REFACTOR-EXPLORATION-001.

Detects whether exploration or plan mode activity occurred recently by
scanning JSON/JSONL log files for matching entries within a configurable
lookback window.

P0 bug fix: Uses collections.deque-based tail reading for JSONL files
to bound memory usage on large log files (only parses last ~200 lines).

Related:
    - obra/execution/derivation.py (original location)
    - docs/decisions/ADR-055-conditional-auto-exploration.md
"""

import collections
import json
import logging
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Sequence

logger = logging.getLogger(__name__)

EXPLORATION_LOOKBACK_MINUTES = 180  # Now in derivation.exploration_lookback_minutes

# Maximum number of lines to read from the tail of JSONL files.
# Bounds memory usage on large log files.
_JSONL_TAIL_LINES = 200


def detect_recent_exploration(
    working_dir: Path,
    *,
    lookback_minutes: int = EXPLORATION_LOOKBACK_MINUTES,
    log_paths: Sequence[Path] | None = None,
) -> dict[str, Any]:
    """Detect whether exploration or plan mode activity occurred recently.

    Checks a set of JSON/JSONL log files for entries indicating either an
    explore agent run or Plan Mode activity inside a configurable lookback
    window. Returns a small report that can be used for nudging the user.

    Args:
        working_dir: Project working directory
        lookback_minutes: How far back to look for exploration activity
        log_paths: Override log file paths (defaults to canonical + legacy)

    Returns:
        Dict with 'recent_exploration' (bool) and 'signals' (list of dicts)
    """
    cutoff = datetime.now(UTC) - timedelta(minutes=lookback_minutes)
    candidates = (
        list(log_paths) if log_paths is not None else _default_exploration_log_paths(working_dir)
    )

    signals: list[dict[str, str]] = []
    for path in candidates:
        signals.extend(_collect_exploration_signals(path, cutoff))

    signals.sort(key=lambda signal: signal["timestamp"], reverse=True)
    return {
        "recent_exploration": bool(signals),
        "signals": signals,
    }


def _default_exploration_log_paths(working_dir: Path) -> list[Path]:
    """Return default log candidates for recent exploration detection.

    Canonical-first order:
    1) Runtime hybrid log (and first rotated file)
    2) Legacy .obra activity/session files for backward compatibility
    """
    from obra.utils.obra_home import get_runtime_dir

    runtime_logs: list[Path] = []
    try:
        runtime_dir = get_runtime_dir()
        runtime_logs = [
            runtime_dir / "logs" / "hybrid.jsonl",
            runtime_dir / "logs" / "hybrid.jsonl.1",
        ]
    except Exception:
        logger.debug("Failed to resolve runtime log directory", exc_info=True)

    return [
        *runtime_logs,
        working_dir / ".obra" / "activity.log",
        working_dir / ".obra" / "session_history.jsonl",
        Path.home() / ".obra" / "memory" / "activity.log",
        Path.home() / ".obra" / "last-session.json",
    ]


def _collect_exploration_signals(path: Path, cutoff: datetime) -> list[dict[str, str]]:
    """Parse a log file and collect exploration signals within cutoff.

    P0 fix: For JSONL files, uses deque-based tail reading to only parse
    the last ~200 lines, bounding memory usage on large log files.
    For non-JSONL files (plain JSON array/object), falls back to full read
    only if tail parsing yields 0 entries.
    """
    if not path.exists() or not path.is_file():
        return []

    entries: list[Any] = []

    # Try tail-based JSONL reading first (bounded memory)
    try:
        with open(path, encoding="utf-8") as f:
            tail_lines = collections.deque(f, maxlen=_JSONL_TAIL_LINES)
    except OSError:
        return []

    for line in tail_lines:
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
            entries.append(entry)
        except json.JSONDecodeError:
            continue

    # If JSONL parsing yielded nothing, try full read as plain JSON
    if not entries:
        try:
            content = path.read_text(encoding="utf-8")
            stripped = content.strip()
            if not stripped:
                return []
            loaded = json.loads(stripped)
            if isinstance(loaded, list):
                entries = loaded
            elif isinstance(loaded, dict):
                entries = [loaded]
        except (OSError, json.JSONDecodeError):
            return []

    signals: list[dict[str, str]] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        if not _is_exploration_entry(entry):
            continue

        ts = _extract_timestamp(entry) or datetime.fromtimestamp(path.stat().st_mtime, tz=UTC)
        if ts < cutoff:
            continue

        signals.append(
            {
                "source": str(path),
                "timestamp": ts.isoformat(),
                "reason": _extract_reason(entry),
            }
        )
    return signals


def _is_exploration_entry(entry: dict[str, Any]) -> bool:
    """Determine if an entry represents exploration or plan mode activity."""
    event_name = str(
        entry.get("event_type") or entry.get("type") or entry.get("action") or ""
    ).lower()
    action = str(entry.get("action", "")).lower()
    mode = str(entry.get("mode", "")).lower()
    agent = str(entry.get("agent", "")).lower()
    tags = entry.get("tags", [])
    tag_values = tags if isinstance(tags, list) else ([tags] if tags else [])

    tagged_exploration = any(
        str(tag).lower() in {"explore", "exploration", "plan_mode"} for tag in tag_values
    )

    # Canonical hybrid exploration events.
    if event_name.startswith("exploration_"):
        if event_name == "exploration_complete":
            return bool(entry.get("success", True))
        if event_name in {"exploration_cache_hit", "exploration_cache_stored"}:
            return True
        return False

    # Legacy activity/session formats.
    return bool(
        tagged_exploration
        or event_name in {"explore", "exploration", "plan_mode"}
        or action in {"explore", "exploration", "plan_mode"}
        or agent == "explore"
        or entry.get("plan_mode") is True
        or "plan_mode" in mode
    )


def _extract_timestamp(entry: dict[str, Any]) -> datetime | None:
    """Extract a timestamp from common log fields."""
    candidates = [
        entry.get("timestamp"),
        entry.get("created_at"),
        entry.get("ts"),
        entry.get("time"),
    ]
    for value in candidates:
        if value is None:
            continue
        if isinstance(value, (int, float)):
            try:
                return datetime.fromtimestamp(float(value), tz=UTC)
            except (OSError, ValueError):
                continue
        if isinstance(value, str):
            parsed = _parse_iso_timestamp(value)
            if parsed:
                return parsed
    return None


def _parse_iso_timestamp(value: str) -> datetime | None:
    """Parse ISO timestamp strings, including those ending with Z."""
    try:
        normalized = value.replace("Z", "+00:00") if value.endswith("Z") else value
        parsed = datetime.fromisoformat(normalized)
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)
    except ValueError:
        return None


def _extract_reason(entry: dict[str, Any]) -> str:
    """Extract a human-friendly reason for the detected signal."""
    for key in ["event_type", "type", "action", "mode", "agent"]:
        value = entry.get(key)
        if value:
            return str(value)
    return "exploration"
