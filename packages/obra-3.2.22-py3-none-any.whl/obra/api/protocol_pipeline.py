"""Pipeline stage protocol types shared across client and server.

This module is part of the protocol*.py family and is kept byte-for-byte
in sync between:
- functions/src/orchestration/protocol_pipeline.py
- obra/api/protocol_pipeline.py

Contains PipelineStage* dataclasses and their helper functions, extracted
from protocol.py to reduce cognitive load for LLM-led development.
"""

from dataclasses import dataclass, field
from typing import Any

from obra.workflow.stage_artifacts import (
    collect_artifact_contract_issues,
    normalize_stage_output_artifacts,
    normalize_workflow_accumulation_artifact,
)

from .protocol_core import _coerce_lifecycle_payload, _coerce_optional_dict


@dataclass
class StageRoutingSignal:
    """Advisory routing recommendation returned by a stage runner."""

    recommended_action: str = ""
    reason: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "recommended_action": self.recommended_action,
            "reason": self.reason,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "StageRoutingSignal | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            recommended_action=str(data.get("recommended_action", "") or ""),
            reason=str(data.get("reason", "") or ""),
            metadata=(data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {}),
        )


@dataclass
class StageLoopSignal:
    """Advisory loop-control recommendation returned by a stage runner."""

    recommended_action: str = ""
    reason: str = ""
    current_iteration: int = 0
    max_iterations: int = 0
    loop_verdict: str = ""
    loop_state: str = ""
    retry_with: dict[str, Any] = field(default_factory=dict)
    pending_manual: "PendingManualPayload | None" = None
    resume: "LoopResumePayload | None" = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "recommended_action": self.recommended_action,
            "reason": self.reason,
            "current_iteration": self.current_iteration,
            "max_iterations": self.max_iterations,
            "loop_verdict": self.loop_verdict,
            "loop_state": self.loop_state,
            "retry_with": self.retry_with,
            "pending_manual": (
                self.pending_manual.to_dict() if self.pending_manual is not None else None
            ),
            "resume": self.resume.to_dict() if self.resume is not None else None,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "StageLoopSignal | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            recommended_action=str(data.get("recommended_action", "") or ""),
            reason=str(data.get("reason", "") or ""),
            current_iteration=int(data.get("current_iteration", 0) or 0),
            max_iterations=int(data.get("max_iterations", 0) or 0),
            loop_verdict=str(data.get("loop_verdict", "") or ""),
            loop_state=str(data.get("loop_state", "") or ""),
            retry_with=(
                data.get("retry_with", {}) if isinstance(data.get("retry_with"), dict) else {}
            ),
            pending_manual=PendingManualPayload.from_dict(data.get("pending_manual")),
            resume=LoopResumePayload.from_dict(data.get("resume")),
            metadata=(data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {}),
        )


@dataclass
class LoopResumePayload:
    """Explicit loop-resume metadata carried across request, result, and state payloads."""

    checkpoint: str = ""
    strategy: str = ""
    token: str = ""
    token_field: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "checkpoint": self.checkpoint,
            "strategy": self.strategy,
            "token": self.token,
            "token_field": self.token_field,
            "metadata": self.metadata,
            "workflow_lifecycle": self.workflow_lifecycle,
            "lifecycle_decisions": self.lifecycle_decisions,
            "legacy_phase_normalization": self.legacy_phase_normalization,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "LoopResumePayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            checkpoint=str(data.get("checkpoint", "") or ""),
            strategy=str(data.get("strategy", "") or ""),
            token=str(data.get("token", "") or ""),
            token_field=str(data.get("token_field", "") or ""),
            metadata=(data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {}),
            workflow_lifecycle=_coerce_lifecycle_payload(data.get("workflow_lifecycle")),
            lifecycle_decisions=_coerce_optional_dict(data.get("lifecycle_decisions")),
            legacy_phase_normalization=_coerce_optional_dict(
                data.get("legacy_phase_normalization")
            ),
        )


@dataclass
class PendingManualPayload:
    """Explicit metadata for a stage paused in pending-manual loop state."""

    reason: str = ""
    required_action: str = ""
    blocking: bool = True
    resume: LoopResumePayload | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "reason": self.reason,
            "required_action": self.required_action,
            "blocking": self.blocking,
            "resume": self.resume.to_dict() if self.resume is not None else None,
            "metadata": self.metadata,
            "workflow_lifecycle": self.workflow_lifecycle,
            "lifecycle_decisions": self.lifecycle_decisions,
            "legacy_phase_normalization": self.legacy_phase_normalization,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "PendingManualPayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            reason=str(data.get("reason", "") or ""),
            required_action=str(data.get("required_action", "") or ""),
            blocking=bool(True if data.get("blocking") is None else data.get("blocking")),
            resume=LoopResumePayload.from_dict(data.get("resume")),
            metadata=(data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {}),
            workflow_lifecycle=_coerce_lifecycle_payload(data.get("workflow_lifecycle")),
            lifecycle_decisions=_coerce_optional_dict(data.get("lifecycle_decisions")),
            legacy_phase_normalization=_coerce_optional_dict(
                data.get("legacy_phase_normalization")
            ),
        )


@dataclass
class WaitPayload:
    """Explicit WAIT action payload contract for polling and resume flows."""

    status: str = ""
    reason: str = ""
    confidence: float | None = None
    polling: dict[str, Any] = field(default_factory=dict)
    pending_manual: PendingManualPayload | None = None
    resume: LoopResumePayload | None = None
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)
    derivation_id: str | None = None
    operator_review_checkpoint_state: dict[str, Any] = field(default_factory=dict)
    accepted_revision_ref: dict[str, Any] = field(default_factory=dict)
    expected_baseline_ref: dict[str, Any] = field(default_factory=dict)
    correlation: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        payload: dict[str, Any] = {
            "status": self.status,
            "reason": self.reason,
            "polling": self.polling,
            "workflow_lifecycle": self.workflow_lifecycle,
            "lifecycle_decisions": self.lifecycle_decisions,
            "legacy_phase_normalization": self.legacy_phase_normalization,
        }
        if self.confidence is not None:
            payload["confidence"] = self.confidence
        if self.pending_manual is not None:
            payload["pending_manual"] = self.pending_manual.to_dict()
        if self.resume is not None:
            payload["resume"] = self.resume.to_dict()
        if self.derivation_id is not None:
            payload["derivation_id"] = self.derivation_id
        if self.operator_review_checkpoint_state:
            payload["operator_review_checkpoint_state"] = self.operator_review_checkpoint_state
        if self.accepted_revision_ref:
            payload["accepted_revision_ref"] = self.accepted_revision_ref
        if self.expected_baseline_ref:
            payload["expected_baseline_ref"] = self.expected_baseline_ref
        if self.correlation:
            payload["correlation"] = self.correlation
        if self.metadata:
            payload["metadata"] = self.metadata
        return payload

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "WaitPayload":
        """Create from ServerAction payload."""
        return cls(
            status=str(payload.get("status") or ""),
            reason=str(payload.get("reason") or ""),
            confidence=(
                float(payload["confidence"]) if payload.get("confidence") is not None else None
            ),
            polling=_coerce_optional_dict(payload.get("polling")),
            pending_manual=PendingManualPayload.from_dict(payload.get("pending_manual")),
            resume=LoopResumePayload.from_dict(payload.get("resume")),
            workflow_lifecycle=_coerce_lifecycle_payload(payload.get("workflow_lifecycle")),
            lifecycle_decisions=_coerce_optional_dict(payload.get("lifecycle_decisions")),
            legacy_phase_normalization=_coerce_optional_dict(
                payload.get("legacy_phase_normalization")
            ),
            derivation_id=(
                str(payload.get("derivation_id"))
                if payload.get("derivation_id") is not None
                else None
            ),
            operator_review_checkpoint_state=_coerce_optional_dict(
                payload.get("operator_review_checkpoint_state")
            ),
            accepted_revision_ref=_coerce_optional_dict(payload.get("accepted_revision_ref")),
            expected_baseline_ref=_coerce_optional_dict(payload.get("expected_baseline_ref")),
            correlation=_coerce_optional_dict(payload.get("correlation")),
            metadata=_coerce_optional_dict(payload.get("metadata")),
        )


@dataclass
class ArtifactReferencePayload:
    """Wire-safe canonical artifact reference."""

    target_artifact_type: str = ""
    target_artifact_id: str = ""
    target_version_selector: str = "latest"
    relationship_type: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "target_artifact_type": self.target_artifact_type,
            "target_artifact_id": self.target_artifact_id,
            "target_version_selector": self.target_version_selector,
            "relationship_type": self.relationship_type,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "ArtifactReferencePayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            target_artifact_type=str(data.get("target_artifact_type", "") or ""),
            target_artifact_id=str(data.get("target_artifact_id", "") or ""),
            target_version_selector=str(data.get("target_version_selector", "latest") or "latest"),
            relationship_type=str(data.get("relationship_type", "") or ""),
            metadata=(data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {}),
        )


@dataclass
class ResolvedStageAssetBindingPayload:
    """Wire-safe resolved stage-template binding metadata."""

    binding_role: str = ""
    binding_scope: str = ""
    stage_id: str = ""
    artifact_ref: ArtifactReferencePayload | None = None
    content_format: str = ""
    adoption_state: str = ""
    materialized_path: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "binding_role": self.binding_role,
            "binding_scope": self.binding_scope,
            "stage_id": self.stage_id,
            "artifact_ref": (
                self.artifact_ref.to_dict() if self.artifact_ref is not None else None
            ),
            "content_format": self.content_format,
            "adoption_state": self.adoption_state,
            "materialized_path": self.materialized_path,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "ResolvedStageAssetBindingPayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            binding_role=str(data.get("binding_role", "") or ""),
            binding_scope=str(data.get("binding_scope", "") or ""),
            stage_id=str(data.get("stage_id", "") or ""),
            artifact_ref=ArtifactReferencePayload.from_dict(data.get("artifact_ref")),
            content_format=str(data.get("content_format", "") or ""),
            adoption_state=str(data.get("adoption_state", "") or ""),
            materialized_path=str(data.get("materialized_path", "") or ""),
            metadata=(data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {}),
        )


@dataclass
class ProducedArtifactPayload:
    """Wire-safe produced artifact metadata used by stage runners."""

    artifact_type: str = ""
    artifact_id: str = ""
    version: str = ""
    compatibility_version: str = ""
    created_at: str = ""
    producer_kind: str = ""
    producer_id: str = ""
    operation_kind: str = ""
    workflow_execution_id: str = ""
    attempt_id: str = ""
    stage_id: str = ""
    stage_name: str = ""
    path: str = ""
    file_targets: list[str] = field(default_factory=list)
    files_changed: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "artifact_type": self.artifact_type,
            "artifact_id": self.artifact_id,
            "version": self.version,
            "compatibility_version": self.compatibility_version,
            "created_at": self.created_at,
            "producer_kind": self.producer_kind,
            "producer_id": self.producer_id,
            "operation_kind": self.operation_kind,
            "workflow_execution_id": self.workflow_execution_id,
            "attempt_id": self.attempt_id,
            "stage_id": self.stage_id,
            "stage_name": self.stage_name,
            "path": self.path,
            "file_targets": self.file_targets,
            "files_changed": self.files_changed,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "ProducedArtifactPayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            artifact_type=str(data.get("artifact_type", "") or ""),
            artifact_id=str(data.get("artifact_id", "") or ""),
            version=str(data.get("version", "") or ""),
            compatibility_version=str(data.get("compatibility_version", "") or ""),
            created_at=str(data.get("created_at", "") or ""),
            producer_kind=str(data.get("producer_kind", "") or ""),
            producer_id=str(data.get("producer_id", "") or ""),
            operation_kind=str(data.get("operation_kind", "") or ""),
            workflow_execution_id=str(data.get("workflow_execution_id", "") or ""),
            attempt_id=str(data.get("attempt_id", "") or ""),
            stage_id=str(data.get("stage_id", "") or ""),
            stage_name=str(data.get("stage_name", "") or ""),
            path=str(data.get("path", "") or ""),
            file_targets=(
                [str(item) for item in data.get("file_targets", []) if str(item).strip()]
                if isinstance(data.get("file_targets"), list)
                else []
            ),
            files_changed=(
                [str(item) for item in data.get("files_changed", []) if str(item).strip()]
                if isinstance(data.get("files_changed"), list)
                else []
            ),
            metadata=(data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {}),
        )


@dataclass
class StageRunnerContext:
    """Typed runtime context passed to a stage runner."""

    stage_name: str = ""
    stage_execution_id: str = ""
    trigger: str = ""
    input_type: str = ""
    domain_id: str = ""
    workflow_refs: dict[str, Any] = field(default_factory=dict)
    stage_refs: dict[str, Any] = field(default_factory=dict)
    workflow_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    execution_input_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    stage_asset_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    resolved_stage_asset_bindings: list[ResolvedStageAssetBindingPayload] = field(
        default_factory=list
    )
    prior_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    accepted_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    candidate_stage_output_artifacts: list[ProducedArtifactPayload] = field(default_factory=list)
    accepted_workflow_accumulation_artifact_ref: ArtifactReferencePayload | None = None
    candidate_workflow_accumulation_artifact: ProducedArtifactPayload | None = None
    payload: dict[str, Any] = field(default_factory=dict)
    history: list[dict[str, Any]] = field(default_factory=list)
    loop_state: dict[str, Any] = field(default_factory=dict)
    loop_verdict: str = ""
    pending_manual: PendingManualPayload | None = None
    resume: LoopResumePayload | None = None
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)
    working_directory: str = ""
    timeout_s: int = 600
    runtime_metadata: dict[str, Any] = field(default_factory=dict)
    runner_config: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "stage_name": self.stage_name,
            "stage_execution_id": self.stage_execution_id,
            "trigger": self.trigger,
            "input_type": self.input_type,
            "domain_id": self.domain_id,
            "workflow_refs": self.workflow_refs,
            "stage_refs": self.stage_refs,
            "workflow_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.workflow_artifact_refs
            ],
            "execution_input_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.execution_input_artifact_refs
            ],
            "stage_asset_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.stage_asset_artifact_refs
            ],
            "resolved_stage_asset_bindings": [
                binding.to_dict() for binding in self.resolved_stage_asset_bindings
            ],
            "prior_stage_output_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.prior_stage_output_artifact_refs
            ],
            "accepted_stage_output_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.accepted_stage_output_artifact_refs
            ],
            "candidate_stage_output_artifacts": [
                artifact.to_dict() for artifact in self.candidate_stage_output_artifacts
            ],
            "accepted_workflow_accumulation_artifact_ref": (
                self.accepted_workflow_accumulation_artifact_ref.to_dict()
                if self.accepted_workflow_accumulation_artifact_ref is not None
                else None
            ),
            "candidate_workflow_accumulation_artifact": (
                self.candidate_workflow_accumulation_artifact.to_dict()
                if self.candidate_workflow_accumulation_artifact is not None
                else None
            ),
            "payload": self.payload,
            "history": self.history,
            "loop_state": self.loop_state,
            "loop_verdict": self.loop_verdict,
            "pending_manual": (
                self.pending_manual.to_dict() if self.pending_manual is not None else None
            ),
            "resume": self.resume.to_dict() if self.resume is not None else None,
            "workflow_lifecycle": self.workflow_lifecycle,
            "lifecycle_decisions": self.lifecycle_decisions,
            "legacy_phase_normalization": self.legacy_phase_normalization,
            "working_directory": self.working_directory,
            "timeout_s": self.timeout_s,
            "runtime_metadata": self.runtime_metadata,
            "runner_config": self.runner_config,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "StageRunnerContext":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return cls()
        artifact_fields = {
            "workflow_artifact_refs": _parse_artifact_refs(data.get("workflow_artifact_refs") or []),
            "execution_input_artifact_refs": _parse_artifact_refs(
                data.get("execution_input_artifact_refs") or []
            ),
            "stage_asset_artifact_refs": _parse_artifact_refs(
                data.get("stage_asset_artifact_refs") or []
            ),
            "resolved_stage_asset_bindings": _parse_resolved_stage_asset_bindings(
                data.get("resolved_stage_asset_bindings") or []
            ),
            "prior_stage_output_artifact_refs": _parse_artifact_refs(
                data.get("prior_stage_output_artifact_refs") or []
            ),
            "accepted_stage_output_artifact_refs": _parse_artifact_refs(
                data.get("accepted_stage_output_artifact_refs") or []
            ),
            "candidate_stage_output_artifacts": _parse_produced_artifacts(
                data.get("candidate_stage_output_artifacts") or []
            ),
        }
        core_fields = _build_runner_context_core_fields(data)
        loop_and_runtime_fields = _build_runner_context_loop_and_runtime_fields(data)
        return cls(
            **core_fields,
            **loop_and_runtime_fields,
            **artifact_fields,
        )


def _build_runner_context_core_fields(data: dict[str, Any]) -> dict[str, Any]:
    """Build the non-artifact StageRunnerContext fields with simple coercions."""
    return {
        "stage_name": str(data.get("stage_name", "") or ""),
        "stage_execution_id": str(data.get("stage_execution_id", "") or ""),
        "trigger": str(data.get("trigger", "") or ""),
        "input_type": str(data.get("input_type", "") or ""),
        "domain_id": str(data.get("domain_id", "") or ""),
        "workflow_refs": (
            data.get("workflow_refs", {}) if isinstance(data.get("workflow_refs"), dict) else {}
        ),
        "stage_refs": data.get("stage_refs", {}) if isinstance(data.get("stage_refs"), dict) else {},
        "payload": data.get("payload", {}) if isinstance(data.get("payload"), dict) else {},
        "history": data.get("history", []) if isinstance(data.get("history"), list) else [],
        "working_directory": str(data.get("working_directory", "") or ""),
        "timeout_s": int(data.get("timeout_s", 600) or 600),
        "runtime_metadata": (
            data.get("runtime_metadata", {})
            if isinstance(data.get("runtime_metadata"), dict)
            else {}
        ),
        "runner_config": (
            data.get("runner_config", {}) if isinstance(data.get("runner_config"), dict) else {}
        ),
    }


def _build_runner_context_loop_and_runtime_fields(data: dict[str, Any]) -> dict[str, Any]:
    """Build loop-related and optional runtime fields for StageRunnerContext."""
    return {
        "loop_state": data.get("loop_state", {}) if isinstance(data.get("loop_state"), dict) else {},
        "loop_verdict": str(data.get("loop_verdict", "") or ""),
        "pending_manual": PendingManualPayload.from_dict(data.get("pending_manual")),
        "resume": LoopResumePayload.from_dict(data.get("resume")),
        "accepted_workflow_accumulation_artifact_ref": ArtifactReferencePayload.from_dict(
            data.get("accepted_workflow_accumulation_artifact_ref")
        ),
        "candidate_workflow_accumulation_artifact": ProducedArtifactPayload.from_dict(
            data.get("candidate_workflow_accumulation_artifact")
        ),
        "workflow_lifecycle": _coerce_lifecycle_payload(data.get("workflow_lifecycle")),
        "lifecycle_decisions": _coerce_optional_dict(data.get("lifecycle_decisions")),
        "legacy_phase_normalization": _coerce_optional_dict(
            data.get("legacy_phase_normalization")
        ),
    }


def _hydrate_stage_request_fields(req: "PipelineStageRequest") -> None:
    """Parse raw dicts into typed dataclass fields on a PipelineStageRequest."""
    if isinstance(req.context, dict):
        req.context = StageRunnerContext.from_dict(req.context)
    if isinstance(req.runner_diagnostic, dict):
        req.runner_diagnostic = RunnerDiagnosticPayload.from_dict(req.runner_diagnostic)
    req.workflow_artifact_refs = _parse_artifact_refs(req.workflow_artifact_refs)
    req.execution_input_artifact_refs = _parse_artifact_refs(req.execution_input_artifact_refs)
    req.stage_asset_artifact_refs = _parse_artifact_refs(req.stage_asset_artifact_refs)
    req.resolved_stage_asset_bindings = _parse_resolved_stage_asset_bindings(
        req.resolved_stage_asset_bindings
    )
    req.prior_stage_output_artifact_refs = _parse_artifact_refs(
        req.prior_stage_output_artifact_refs
    )
    req.accepted_stage_output_artifact_refs = _parse_artifact_refs(
        req.accepted_stage_output_artifact_refs
    )
    req.candidate_stage_output_artifacts = _parse_produced_artifacts(
        normalize_stage_output_artifacts(req.candidate_stage_output_artifacts)
    )
    if isinstance(req.accepted_workflow_accumulation_artifact_ref, dict):
        req.accepted_workflow_accumulation_artifact_ref = ArtifactReferencePayload.from_dict(
            req.accepted_workflow_accumulation_artifact_ref
        )
    if isinstance(req.candidate_workflow_accumulation_artifact, dict):
        req.candidate_workflow_accumulation_artifact = ProducedArtifactPayload.from_dict(
            normalize_workflow_accumulation_artifact(req.candidate_workflow_accumulation_artifact)
        )
    if isinstance(req.pending_manual, dict):
        req.pending_manual = PendingManualPayload.from_dict(req.pending_manual)
    if isinstance(req.resume, dict):
        req.resume = LoopResumePayload.from_dict(req.resume)


def _resolve_stage_artifact_fallbacks(
    req: "PipelineStageRequest",
) -> tuple[list[ProducedArtifactPayload] | list[dict[str, Any]], ProducedArtifactPayload | dict[str, Any] | None]:
    """Resolve stage-output and accumulation artifacts from request, content, or context."""
    content_payload = req.content if isinstance(req.content, dict) else {}
    context_payload = req.context.payload if isinstance(req.context.payload, dict) else {}

    stage_output_payloads: list[ProducedArtifactPayload] | list[dict[str, Any]] = (
        req.stage_output_artifacts
    )
    if not stage_output_payloads and isinstance(content_payload.get("stage_output_artifacts"), list):
        stage_output_payloads = content_payload.get("stage_output_artifacts", [])
    if not stage_output_payloads and isinstance(context_payload.get("stage_output_artifacts"), list):
        stage_output_payloads = context_payload.get("stage_output_artifacts", [])

    workflow_accumulation_payload: ProducedArtifactPayload | dict[str, Any] | None = (
        req.workflow_accumulation_artifact
    )
    if workflow_accumulation_payload is None and isinstance(
        content_payload.get("workflow_accumulation_artifact"), dict
    ):
        workflow_accumulation_payload = content_payload.get("workflow_accumulation_artifact")
    if workflow_accumulation_payload is None and isinstance(
        context_payload.get("workflow_accumulation_artifact"), dict
    ):
        workflow_accumulation_payload = context_payload.get("workflow_accumulation_artifact")

    return stage_output_payloads, workflow_accumulation_payload


def _normalize_stage_request_artifacts(req: "PipelineStageRequest") -> None:
    """Resolve and validate stage-output and accumulation artifacts."""
    content_payload = req.content if isinstance(req.content, dict) else {}
    context_payload = req.context.payload if isinstance(req.context.payload, dict) else {}
    stage_output_payloads, workflow_accumulation_payload = _resolve_stage_artifact_fallbacks(req)

    issues = collect_artifact_contract_issues(
        payload=content_payload,
        stage_output_artifacts=stage_output_payloads,
        candidate_stage_output_artifacts=req.candidate_stage_output_artifacts,
        accepted_stage_output_artifact_refs=req.accepted_stage_output_artifact_refs,
        workflow_accumulation_artifact=workflow_accumulation_payload,
        candidate_workflow_accumulation_artifact=(req.candidate_workflow_accumulation_artifact),
        accepted_workflow_accumulation_artifact_ref=(
            req.accepted_workflow_accumulation_artifact_ref
        ),
    )
    issues.extend(
        collect_artifact_contract_issues(
            payload=context_payload,
            stage_output_artifacts=(
                context_payload.get("stage_output_artifacts", [])
                if isinstance(context_payload.get("stage_output_artifacts"), list)
                else None
            ),
            candidate_stage_output_artifacts=(
                context_payload.get("candidate_stage_output_artifacts", [])
                if isinstance(context_payload.get("candidate_stage_output_artifacts"), list)
                else None
            ),
            accepted_stage_output_artifact_refs=(
                context_payload.get("accepted_stage_output_artifact_refs", [])
                if isinstance(context_payload.get("accepted_stage_output_artifact_refs"), list)
                else None
            ),
            workflow_accumulation_artifact=context_payload.get("workflow_accumulation_artifact"),
            candidate_workflow_accumulation_artifact=context_payload.get(
                "candidate_workflow_accumulation_artifact"
            ),
            accepted_workflow_accumulation_artifact_ref=context_payload.get(
                "accepted_workflow_accumulation_artifact_ref"
            ),
        )
    )
    _raise_artifact_contract_issues(issues)

    req.stage_output_artifacts = _parse_produced_artifacts(
        normalize_stage_output_artifacts(stage_output_payloads)
    )
    if workflow_accumulation_payload is not None:
        req.workflow_accumulation_artifact = ProducedArtifactPayload.from_dict(
            normalize_workflow_accumulation_artifact(workflow_accumulation_payload)
        )
    else:
        req.workflow_accumulation_artifact = None


_BIDI_LIST_FIELDS = (
    "workflow_artifact_refs",
    "execution_input_artifact_refs",
    "stage_asset_artifact_refs",
    "resolved_stage_asset_bindings",
    "prior_stage_output_artifact_refs",
    "accepted_stage_output_artifact_refs",
    "candidate_stage_output_artifacts",
)

_BIDI_OPTIONAL_FIELDS = (
    "accepted_workflow_accumulation_artifact_ref",
    "candidate_workflow_accumulation_artifact",
)


def _sync_request_identity_fields(req: "PipelineStageRequest") -> None:
    """Synchronize identity, content, and timeout fields between request and context."""
    if not req.stage_execution_id:
        runner_fragment = req.runner_id or "runner"
        req.stage_execution_id = f"{req.stage_name}:{runner_fragment}:{req.runner_position}"
    if not req.content and req.context.payload:
        req.content = dict(req.context.payload)
    if not req.context.stage_name:
        req.context.stage_name = req.stage_name
    if not req.context.stage_execution_id:
        req.context.stage_execution_id = req.stage_execution_id
    if not req.context.trigger:
        req.context.trigger = req.trigger
    if not req.context.input_type:
        req.context.input_type = req.input_type
    if not req.context.payload and req.content:
        req.context.payload = dict(req.content)
    if not req.context.timeout_s:
        req.context.timeout_s = req.timeout_s


def _sync_bidirectional_list_fields(req: "PipelineStageRequest") -> None:
    """Mirror list and optional artifact fields between the request and context."""
    for field_name in _BIDI_LIST_FIELDS:
        req_value = getattr(req, field_name)
        context_value = getattr(req.context, field_name)
        if not req_value and context_value:
            setattr(req, field_name, list(context_value))
        elif not context_value and req_value:
            setattr(req.context, field_name, list(req_value))
    for field_name in _BIDI_OPTIONAL_FIELDS:
        req_value = getattr(req, field_name)
        context_value = getattr(req.context, field_name)
        if req_value is None and context_value is not None:
            setattr(req, field_name, context_value)
        elif context_value is None and req_value is not None:
            setattr(req.context, field_name, req_value)


def _inject_artifacts_into_content(req: "PipelineStageRequest") -> None:
    """Backfill canonical artifact payloads into content and context payloads."""
    if isinstance(req.content, dict):
        if req.stage_output_artifacts and "stage_output_artifacts" not in req.content:
            req.content["stage_output_artifacts"] = [
                artifact.to_dict() for artifact in req.stage_output_artifacts
            ]
        if (
            req.workflow_accumulation_artifact is not None
            and "workflow_accumulation_artifact" not in req.content
        ):
            req.content["workflow_accumulation_artifact"] = (
                req.workflow_accumulation_artifact.to_dict()
            )

    if isinstance(req.context.payload, dict):
        if req.stage_output_artifacts and "stage_output_artifacts" not in req.context.payload:
            req.context.payload["stage_output_artifacts"] = [
                artifact.to_dict() for artifact in req.stage_output_artifacts
            ]
        if (
            req.workflow_accumulation_artifact is not None
            and "workflow_accumulation_artifact" not in req.context.payload
        ):
            req.context.payload["workflow_accumulation_artifact"] = (
                req.workflow_accumulation_artifact.to_dict()
            )


def _sync_loop_state(req: "PipelineStageRequest") -> None:
    """Synchronize loop metadata between the request and its embedded context."""
    if isinstance(req.pending_manual, dict):
        req.pending_manual = PendingManualPayload.from_dict(req.pending_manual)

    loop_state = req.context.loop_state if isinstance(req.context.loop_state, dict) else {}
    if not req.iteration and "current_iteration" in loop_state:
        req.iteration = int(loop_state.get("current_iteration", 0) or 0)
    if (
        req.max_iterations == 3
        and "max_iterations" in loop_state
        and loop_state.get("max_iterations") is not None
    ):
        req.max_iterations = int(loop_state.get("max_iterations", 3) or 3)

    if not loop_state:
        req.context.loop_state = {
            "current_iteration": req.iteration,
            "max_iterations": req.max_iterations,
        }
    else:
        req.context.loop_state.setdefault("current_iteration", req.iteration)
        req.context.loop_state.setdefault("max_iterations", req.max_iterations)

    if req.loop_state:
        req.context.loop_state["state"] = req.loop_state
    if req.loop_verdict and not req.context.loop_verdict:
        req.context.loop_verdict = req.loop_verdict
    if req.pending_manual is not None and req.context.pending_manual is None:
        req.context.pending_manual = req.pending_manual
    if req.resume is not None and req.context.resume is None:
        req.context.resume = req.resume


def _sync_stage_request_context(req: "PipelineStageRequest") -> None:
    """Synchronize fields bidirectionally between request and context, and handle loop state."""
    _sync_request_identity_fields(req)
    _sync_bidirectional_list_fields(req)
    _inject_artifacts_into_content(req)
    _sync_loop_state(req)


def _parse_payload_artifact_refs(payload: dict[str, Any]) -> dict[str, Any]:
    """Parse artifact reference fields from a stage-request payload."""
    return {
        "workflow_artifact_refs": _parse_artifact_refs(payload.get("workflow_artifact_refs") or []),
        "execution_input_artifact_refs": _parse_artifact_refs(
            payload.get("execution_input_artifact_refs") or []
        ),
        "stage_asset_artifact_refs": _parse_artifact_refs(
            payload.get("stage_asset_artifact_refs") or []
        ),
        "resolved_stage_asset_bindings": _parse_resolved_stage_asset_bindings(
            payload.get("resolved_stage_asset_bindings") or []
        ),
        "prior_stage_output_artifact_refs": _parse_artifact_refs(
            payload.get("prior_stage_output_artifact_refs") or []
        ),
        "accepted_stage_output_artifact_refs": _parse_artifact_refs(
            payload.get("accepted_stage_output_artifact_refs") or []
        ),
        "candidate_stage_output_artifacts": _parse_produced_artifacts(
            payload.get("candidate_stage_output_artifacts") or []
        ),
        "stage_output_artifacts": _parse_produced_artifacts(
            payload.get("stage_output_artifacts") or []
        ),
        "accepted_workflow_accumulation_artifact_ref": ArtifactReferencePayload.from_dict(
            payload.get("accepted_workflow_accumulation_artifact_ref")
        ),
        "candidate_workflow_accumulation_artifact": ProducedArtifactPayload.from_dict(
            payload.get("candidate_workflow_accumulation_artifact")
        ),
    }


def _build_stage_request_identity_fields(
    payload: dict[str, Any],
    context: StageRunnerContext,
) -> dict[str, Any]:
    """Build the identity and runner fields for PipelineStageRequest.from_payload."""
    runner_id = str(payload.get("runner_id") or "")
    runner_position = int(payload.get("runner_position", 0) or 0)
    stage_name = str(payload.get("stage_name") or context.stage_name or "")
    stage_execution_id = str(
        payload.get("stage_execution_id")
        or context.stage_execution_id
        or (f"{stage_name}:{runner_id or 'runner'}:{runner_position}" if stage_name else "")
    )
    return {
        "stage_name": stage_name,
        "trigger": str(payload.get("trigger") or context.trigger or ""),
        "input_type": str(payload.get("input_type") or context.input_type or ""),
        "runner_id": runner_id,
        "runner_version": str(payload.get("runner_version", "") or ""),
        "runner_selector": str(payload.get("runner_selector", "") or ""),
        "runner_kind": str(payload.get("runner_kind") or "extension_runner"),
        "runner_diagnostic": RunnerDiagnosticPayload.from_dict(payload.get("runner_diagnostic")),
        "stage_execution_id": stage_execution_id,
        "runner_position": runner_position,
        "runner_count": int(payload.get("runner_count", 1) or 1),
        "timeout_s": int(payload.get("timeout_s") or context.timeout_s or 600),
    }


def _build_stage_request_iteration_fields(
    payload: dict[str, Any],
    context: StageRunnerContext,
) -> dict[str, int]:
    """Build iteration counters for PipelineStageRequest.from_payload."""
    loop_state = context.loop_state if isinstance(context.loop_state, dict) else {}
    return {
        "iteration": int(
            payload.get("iteration")
            if payload.get("iteration") is not None
            else loop_state.get("current_iteration", 0)
        ),
        "max_iterations": int(
            payload.get("max_iterations")
            if payload.get("max_iterations") is not None
            else loop_state.get("max_iterations", 3)
        ),
    }


def _resolve_stage_request_content(
    payload: dict[str, Any],
    context: StageRunnerContext,
) -> dict[str, Any]:
    """Resolve request content from the payload or embedded context."""
    if isinstance(payload.get("content"), dict):
        return payload.get("content", {})
    return dict(context.payload)


@dataclass
class PipelineStageRequest:
    """Request to run a custom pipeline stage."""

    stage_name: str
    trigger: str
    input_type: str
    runner_id: str = ""
    runner_version: str = ""
    runner_selector: str = ""
    runner_kind: str = "extension_runner"
    runner_diagnostic: "RunnerDiagnosticPayload | None" = None
    stage_execution_id: str = ""
    runner_position: int = 0
    runner_count: int = 1
    context: StageRunnerContext = field(default_factory=StageRunnerContext)
    timeout_s: int = 600
    workflow_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    execution_input_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    stage_asset_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    resolved_stage_asset_bindings: list[ResolvedStageAssetBindingPayload] = field(
        default_factory=list
    )
    prior_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    accepted_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    candidate_stage_output_artifacts: list[ProducedArtifactPayload] = field(default_factory=list)
    accepted_workflow_accumulation_artifact_ref: ArtifactReferencePayload | None = None
    candidate_workflow_accumulation_artifact: ProducedArtifactPayload | None = None
    loop_verdict: str = ""
    loop_state: str = ""
    pending_manual: PendingManualPayload | None = None
    resume: LoopResumePayload | None = None
    stage_output_artifacts: list[ProducedArtifactPayload] = field(default_factory=list)
    workflow_accumulation_artifact: ProducedArtifactPayload | None = None
    content: dict[str, Any] = field(default_factory=dict)
    iteration: int = 0
    max_iterations: int = 3

    def __post_init__(self) -> None:
        """Hydrate canonical request fields from whichever shape was provided."""
        _hydrate_stage_request_fields(self)
        _normalize_stage_request_artifacts(self)
        _sync_stage_request_context(self)

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "PipelineStageRequest":
        """Create from ServerAction payload."""
        context = StageRunnerContext.from_dict(payload.get("context"))
        artifact_fields = _parse_payload_artifact_refs(payload)
        identity_fields = _build_stage_request_identity_fields(payload, context)
        iteration_fields = _build_stage_request_iteration_fields(payload, context)
        return cls(
            context=context,
            loop_verdict=str(payload.get("loop_verdict") or ""),
            loop_state=str(payload.get("loop_state") or ""),
            pending_manual=PendingManualPayload.from_dict(payload.get("pending_manual")),
            resume=LoopResumePayload.from_dict(payload.get("resume")),
            workflow_accumulation_artifact=ProducedArtifactPayload.from_dict(
                payload.get("workflow_accumulation_artifact")
            ),
            content=_resolve_stage_request_content(payload, context),
            **identity_fields,
            **iteration_fields,
            **artifact_fields,
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "stage_name": self.stage_name,
            "trigger": self.trigger,
            "runner_id": self.runner_id,
            "runner_version": self.runner_version,
            "runner_selector": self.runner_selector,
            "runner_kind": self.runner_kind,
            "runner_diagnostic": (
                self.runner_diagnostic.to_dict() if self.runner_diagnostic is not None else None
            ),
            "stage_execution_id": self.stage_execution_id,
            "runner_position": self.runner_position,
            "runner_count": self.runner_count,
            "context": self.context.to_dict(),
            "timeout_s": self.timeout_s,
            "workflow_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.workflow_artifact_refs
            ],
            "execution_input_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.execution_input_artifact_refs
            ],
            "stage_asset_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.stage_asset_artifact_refs
            ],
            "resolved_stage_asset_bindings": [
                binding.to_dict() for binding in self.resolved_stage_asset_bindings
            ],
            "prior_stage_output_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.prior_stage_output_artifact_refs
            ],
            "accepted_stage_output_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.accepted_stage_output_artifact_refs
            ],
            "candidate_stage_output_artifacts": [
                artifact.to_dict() for artifact in self.candidate_stage_output_artifacts
            ],
            "accepted_workflow_accumulation_artifact_ref": (
                self.accepted_workflow_accumulation_artifact_ref.to_dict()
                if self.accepted_workflow_accumulation_artifact_ref is not None
                else None
            ),
            "candidate_workflow_accumulation_artifact": (
                self.candidate_workflow_accumulation_artifact.to_dict()
                if self.candidate_workflow_accumulation_artifact is not None
                else None
            ),
            "loop_verdict": self.loop_verdict,
            "loop_state": self.loop_state,
            "pending_manual": (
                self.pending_manual.to_dict() if self.pending_manual is not None else None
            ),
            "resume": self.resume.to_dict() if self.resume is not None else None,
            "stage_output_artifacts": [
                artifact.to_dict() for artifact in self.stage_output_artifacts
            ],
            "workflow_accumulation_artifact": (
                self.workflow_accumulation_artifact.to_dict()
                if self.workflow_accumulation_artifact is not None
                else None
            ),
            "input_type": self.input_type,
            "content": self.content,
            "iteration": self.iteration,
            "max_iterations": self.max_iterations,
        }


@dataclass
class RunnerDiagnosticPayload:
    """Structured runner resolution or installability diagnostic."""

    code: str
    message: str
    runner_id: str = ""
    requested_selector: str = ""
    requested_version: str = ""
    source_layer: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "RunnerDiagnosticPayload | None":
        """Create from dictionary payload."""
        if not isinstance(data, dict):
            return None
        return cls(
            code=str(data.get("code", "") or ""),
            message=str(data.get("message", "") or ""),
            runner_id=str(data.get("runner_id", "") or ""),
            requested_selector=str(data.get("requested_selector", "") or ""),
            requested_version=str(data.get("requested_version", "") or ""),
            source_layer=str(data.get("source_layer", "") or ""),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary payload."""
        return {
            "code": self.code,
            "message": self.message,
            "runner_id": self.runner_id,
            "requested_selector": self.requested_selector,
            "requested_version": self.requested_version,
            "source_layer": self.source_layer,
        }


def _hydrate_result_signals(result: "PipelineStageResult") -> None:
    """Hydrate typed signal and lifecycle fields on a PipelineStageResult."""
    if isinstance(result.routing_signal, dict):
        result.routing_signal = StageRoutingSignal.from_dict(result.routing_signal)
    if isinstance(result.loop_signal, dict):
        result.loop_signal = StageLoopSignal.from_dict(result.loop_signal)
    if isinstance(result.pending_manual, dict):
        result.pending_manual = PendingManualPayload.from_dict(result.pending_manual)
    if isinstance(result.resume, dict):
        result.resume = LoopResumePayload.from_dict(result.resume)
    result.workflow_lifecycle = _coerce_lifecycle_payload(result.workflow_lifecycle)
    result.lifecycle_decisions = _coerce_optional_dict(result.lifecycle_decisions)
    result.legacy_phase_normalization = _coerce_optional_dict(result.legacy_phase_normalization)
    if isinstance(result.runner_diagnostic, dict):
        result.runner_diagnostic = RunnerDiagnosticPayload.from_dict(result.runner_diagnostic)


def _validate_and_normalize_result_artifacts(result: "PipelineStageResult") -> None:
    """Validate artifact contract fields and normalize artifact payload shapes."""
    issues = collect_artifact_contract_issues(
        stage_output_artifacts=result.stage_output_artifacts,
        candidate_stage_output_artifacts=result.candidate_stage_output_artifacts,
        accepted_stage_output_artifact_refs=result.accepted_stage_output_artifact_refs,
        workflow_accumulation_artifact=result.workflow_accumulation_artifact,
        candidate_workflow_accumulation_artifact=result.candidate_workflow_accumulation_artifact,
        accepted_workflow_accumulation_artifact_ref=result.accepted_workflow_accumulation_artifact_ref,
    )
    if isinstance(result.metadata, dict) and (
        result.metadata.get("produced_outputs")
        or result.metadata.get("files_changed")
        or result.metadata.get("file_targets")
    ):
        issues.extend(collect_artifact_contract_issues(payload=result.metadata))
    _raise_artifact_contract_issues(issues)

    result.candidate_stage_output_artifacts = _parse_produced_artifacts(
        normalize_stage_output_artifacts(result.candidate_stage_output_artifacts)
    )
    result.accepted_stage_output_artifact_refs = _parse_artifact_refs(
        result.accepted_stage_output_artifact_refs
    )
    if isinstance(result.candidate_workflow_accumulation_artifact, dict):
        result.candidate_workflow_accumulation_artifact = ProducedArtifactPayload.from_dict(
            normalize_workflow_accumulation_artifact(result.candidate_workflow_accumulation_artifact)
        )
    if isinstance(result.accepted_workflow_accumulation_artifact_ref, dict):
        result.accepted_workflow_accumulation_artifact_ref = ArtifactReferencePayload.from_dict(
            result.accepted_workflow_accumulation_artifact_ref
        )
    result.stage_output_artifacts = _parse_produced_artifacts(
        normalize_stage_output_artifacts(result.stage_output_artifacts)
    )
    if isinstance(result.workflow_accumulation_artifact, dict):
        result.workflow_accumulation_artifact = ProducedArtifactPayload.from_dict(
            normalize_workflow_accumulation_artifact(result.workflow_accumulation_artifact)
        )


def _reconcile_result_fields(result: "PipelineStageResult") -> None:
    """Reconcile canonical result fields after signal and artifact hydration."""
    _reconcile_result_runner_metadata(result)
    _sync_result_findings_and_issues(result)
    _resolve_result_verdict_state(result)
    _enrich_result_metadata(result)


def _reconcile_result_runner_metadata(result: "PipelineStageResult") -> None:
    """Backfill runner fields and duration from metadata when omitted."""
    metadata = result.metadata if isinstance(result.metadata, dict) else None
    if metadata is None:
        return
    if not result.runner_id:
        result.runner_id = str(metadata.get("runner_id", "") or "")
    if not result.runner_version:
        result.runner_version = str(metadata.get("runner_version", "") or "")
    if not result.runner_selector:
        result.runner_selector = str(metadata.get("runner_selector", "") or "")
    if result.runner_diagnostic is None:
        result.runner_diagnostic = RunnerDiagnosticPayload.from_dict(
            metadata.get("runner_diagnostic")
        )
    if not result.duration_s and metadata.get("duration_s") is not None:
        result.duration_s = float(metadata.get("duration_s"))


def _sync_result_findings_and_issues(result: "PipelineStageResult") -> None:
    """Keep findings and issues populated from whichever side was provided."""
    if not result.findings and result.issues:
        result.findings = list(result.issues)
    if not result.issues and result.findings:
        result.issues = list(result.findings)


def _resolve_result_verdict_state(result: "PipelineStageResult") -> None:
    """Normalize verdict, outcome, and execution status defaults."""
    if not result.verdict:
        result.verdict = "sound" if result.outcome == "passed" and not result.issues else "issues"
    if not result.outcome:
        result.outcome = "passed" if result.verdict == "sound" else "issues_found"
    if not result.execution_status:
        result.execution_status = "complete"
    if result.verdict == "sound" and (result.issues or result.findings):
        result.verdict = "issues"
    if result.verdict != "sound" and result.outcome == "passed":
        result.outcome = "issues_found"


def _enrich_result_metadata(result: "PipelineStageResult") -> None:
    """Write canonical result fields back into metadata when absent."""
    if not isinstance(result.metadata, dict):
        return
    if result.runner_id and "runner_id" not in result.metadata:
        result.metadata["runner_id"] = result.runner_id
    if result.runner_version and "runner_version" not in result.metadata:
        result.metadata["runner_version"] = result.runner_version
    if result.runner_selector and "runner_selector" not in result.metadata:
        result.metadata["runner_selector"] = result.runner_selector
    if result.runner_diagnostic is not None and "runner_diagnostic" not in result.metadata:
        result.metadata["runner_diagnostic"] = result.runner_diagnostic.to_dict()
    if result.loop_verdict and "loop_verdict" not in result.metadata:
        result.metadata["loop_verdict"] = result.loop_verdict
    if result.loop_state and "loop_state" not in result.metadata:
        result.metadata["loop_state"] = result.loop_state


def _parse_result_signal_fields(data: dict[str, Any]) -> dict[str, Any]:
    """Build signal and lifecycle fields for PipelineStageResult.from_dict."""
    return {
        "routing_signal": StageRoutingSignal.from_dict(data.get("routing_signal")),
        "loop_signal": StageLoopSignal.from_dict(data.get("loop_signal")),
        "loop_verdict": str(data.get("loop_verdict") or ""),
        "loop_state": str(data.get("loop_state") or ""),
        "pending_manual": PendingManualPayload.from_dict(data.get("pending_manual")),
        "resume": LoopResumePayload.from_dict(data.get("resume")),
        "workflow_lifecycle": _coerce_lifecycle_payload(data.get("workflow_lifecycle")),
        "lifecycle_decisions": _coerce_optional_dict(data.get("lifecycle_decisions")),
        "legacy_phase_normalization": _coerce_optional_dict(data.get("legacy_phase_normalization")),
    }


def _parse_result_runner_fields(data: dict[str, Any]) -> dict[str, Any]:
    """Build runner and verdict fields for PipelineStageResult.from_dict."""
    return {
        "runner_id": str(data.get("runner_id", "") or ""),
        "runner_version": str(data.get("runner_version", "") or ""),
        "runner_selector": str(data.get("runner_selector", "") or ""),
        "runner_diagnostic": RunnerDiagnosticPayload.from_dict(data.get("runner_diagnostic")),
        "metadata": data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {},
        "verdict": str(data.get("verdict", "sound") or "sound"),
        "issues": data.get("issues", []) if isinstance(data.get("issues"), list) else [],
        "iteration": int(data.get("iteration", 0) or 0),
        "duration_s": float(data.get("duration_s", 0.0) or 0.0),
    }


@dataclass
class PipelineStageResult:
    """Result from a custom pipeline stage execution."""

    stage_name: str
    stage_execution_id: str = ""
    execution_status: str = "complete"
    outcome: str = "passed"
    findings: list[dict[str, Any]] = field(default_factory=list)
    stage_output_artifacts: list[ProducedArtifactPayload] = field(default_factory=list)
    workflow_accumulation_artifact: ProducedArtifactPayload | None = None
    candidate_stage_output_artifacts: list[ProducedArtifactPayload] = field(default_factory=list)
    accepted_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    candidate_workflow_accumulation_artifact: ProducedArtifactPayload | None = None
    accepted_workflow_accumulation_artifact_ref: ArtifactReferencePayload | None = None
    routing_signal: StageRoutingSignal | None = None
    loop_signal: StageLoopSignal | None = None
    loop_verdict: str = ""
    loop_state: str = ""
    pending_manual: PendingManualPayload | None = None
    resume: LoopResumePayload | None = None
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)
    runner_id: str = ""
    runner_version: str = ""
    runner_selector: str = ""
    runner_diagnostic: "RunnerDiagnosticPayload | None" = None
    metadata: dict[str, Any] = field(default_factory=dict)
    verdict: str = "sound"
    issues: list[dict[str, Any]] = field(default_factory=list)
    iteration: int = 0
    duration_s: float = 0.0

    def __post_init__(self) -> None:
        """Hydrate canonical result fields while preserving diagnostic signals."""
        _hydrate_result_signals(self)
        _validate_and_normalize_result_artifacts(self)
        _reconcile_result_fields(self)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "stage_name": self.stage_name,
            "stage_execution_id": self.stage_execution_id,
            "execution_status": self.execution_status,
            "outcome": self.outcome,
            "findings": self.findings,
            "stage_output_artifacts": [
                artifact.to_dict() for artifact in self.stage_output_artifacts
            ],
            "workflow_accumulation_artifact": (
                self.workflow_accumulation_artifact.to_dict()
                if self.workflow_accumulation_artifact is not None
                else None
            ),
            "candidate_stage_output_artifacts": [
                artifact.to_dict() for artifact in self.candidate_stage_output_artifacts
            ],
            "accepted_stage_output_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.accepted_stage_output_artifact_refs
            ],
            "candidate_workflow_accumulation_artifact": (
                self.candidate_workflow_accumulation_artifact.to_dict()
                if self.candidate_workflow_accumulation_artifact is not None
                else None
            ),
            "accepted_workflow_accumulation_artifact_ref": (
                self.accepted_workflow_accumulation_artifact_ref.to_dict()
                if self.accepted_workflow_accumulation_artifact_ref is not None
                else None
            ),
            "routing_signal": (self.routing_signal.to_dict() if self.routing_signal else None),
            "loop_signal": self.loop_signal.to_dict() if self.loop_signal else None,
            "loop_verdict": self.loop_verdict,
            "loop_state": self.loop_state,
            "pending_manual": (
                self.pending_manual.to_dict() if self.pending_manual is not None else None
            ),
            "resume": self.resume.to_dict() if self.resume is not None else None,
            "workflow_lifecycle": self.workflow_lifecycle,
            "lifecycle_decisions": self.lifecycle_decisions,
            "legacy_phase_normalization": self.legacy_phase_normalization,
            "runner_id": self.runner_id,
            "runner_version": self.runner_version,
            "runner_selector": self.runner_selector,
            "runner_diagnostic": (
                self.runner_diagnostic.to_dict() if self.runner_diagnostic is not None else None
            ),
            "metadata": self.metadata,
            "verdict": self.verdict,
            "issues": self.issues,
            "iteration": self.iteration,
            "duration_s": self.duration_s,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PipelineStageResult":
        """Create from dictionary."""
        _raise_artifact_contract_issues(
            collect_artifact_contract_issues(
                payload=data,
                stage_output_artifacts=(
                    data.get("stage_output_artifacts", [])
                    if isinstance(data.get("stage_output_artifacts"), list)
                    else None
                ),
                candidate_stage_output_artifacts=(
                    data.get("candidate_stage_output_artifacts", [])
                    if isinstance(data.get("candidate_stage_output_artifacts"), list)
                    else None
                ),
                accepted_stage_output_artifact_refs=(
                    data.get("accepted_stage_output_artifact_refs", [])
                    if isinstance(data.get("accepted_stage_output_artifact_refs"), list)
                    else None
                ),
                workflow_accumulation_artifact=data.get("workflow_accumulation_artifact"),
                candidate_workflow_accumulation_artifact=data.get(
                    "candidate_workflow_accumulation_artifact"
                ),
                accepted_workflow_accumulation_artifact_ref=data.get(
                    "accepted_workflow_accumulation_artifact_ref"
                ),
            )
        )
        artifact_fields = {
            "stage_output_artifacts": _parse_produced_artifacts(
                data.get("stage_output_artifacts") if isinstance(data.get("stage_output_artifacts"), list) else []
            ),
            "workflow_accumulation_artifact": ProducedArtifactPayload.from_dict(
                data.get("workflow_accumulation_artifact")
            ),
            "candidate_stage_output_artifacts": _parse_produced_artifacts(
                data.get("candidate_stage_output_artifacts")
                if isinstance(data.get("candidate_stage_output_artifacts"), list)
                else []
            ),
            "accepted_stage_output_artifact_refs": _parse_artifact_refs(
                data.get("accepted_stage_output_artifact_refs")
                if isinstance(data.get("accepted_stage_output_artifact_refs"), list)
                else []
            ),
            "candidate_workflow_accumulation_artifact": ProducedArtifactPayload.from_dict(
                data.get("candidate_workflow_accumulation_artifact")
            ),
            "accepted_workflow_accumulation_artifact_ref": ArtifactReferencePayload.from_dict(
                data.get("accepted_workflow_accumulation_artifact_ref")
            ),
        }
        signal_fields = _parse_result_signal_fields(data)
        runner_fields = _parse_result_runner_fields(data)
        return cls(
            stage_name=str(data.get("stage_name", "") or ""),
            stage_execution_id=str(data.get("stage_execution_id", "") or ""),
            execution_status=str(data.get("execution_status") or "complete"),
            outcome=str(
                data.get("outcome")
                or ("passed" if data.get("verdict", "sound") == "sound" else "issues_found")
            ),
            findings=(data.get("findings", []) if isinstance(data.get("findings"), list) else []),
            **artifact_fields,
            **signal_fields,
            **runner_fields,
        )


def _parse_artifact_refs(
    refs: list[ArtifactReferencePayload] | list[dict[str, Any]] | None,
) -> list[ArtifactReferencePayload]:
    """Normalize artifact reference payloads from dicts or dataclasses."""
    normalized: list[ArtifactReferencePayload] = []
    for item in refs or []:
        if isinstance(item, ArtifactReferencePayload):
            normalized.append(item)
        elif isinstance(item, dict):
            artifact_ref = ArtifactReferencePayload.from_dict(item)
            if artifact_ref is not None:
                normalized.append(artifact_ref)
    return normalized


def _parse_resolved_stage_asset_bindings(
    bindings: list[ResolvedStageAssetBindingPayload] | list[dict[str, Any]] | None,
) -> list[ResolvedStageAssetBindingPayload]:
    """Normalize resolved stage bindings from dict or dataclass form."""
    normalized: list[ResolvedStageAssetBindingPayload] = []
    for item in bindings or []:
        if isinstance(item, ResolvedStageAssetBindingPayload):
            normalized.append(item)
            continue
        if isinstance(item, dict):
            binding = ResolvedStageAssetBindingPayload.from_dict(item)
            if binding is not None:
                normalized.append(binding)
    return normalized


def _parse_produced_artifacts(
    artifacts: list[ProducedArtifactPayload] | list[dict[str, Any]] | None,
) -> list[ProducedArtifactPayload]:
    """Normalize produced artifact payloads from dicts or dataclasses."""
    normalized: list[ProducedArtifactPayload] = []
    for item in artifacts or []:
        if isinstance(item, ProducedArtifactPayload):
            normalized.append(item)
        elif isinstance(item, dict):
            artifact = ProducedArtifactPayload.from_dict(item)
            if artifact is not None:
                normalized.append(artifact)
    return normalized


def _raise_artifact_contract_issues(issues: list[dict[str, Any]]) -> None:
    """Raise a deterministic validation error for typed artifact contract issues."""
    if not issues:
        return
    first_issue = issues[0]
    field_name = str(first_issue.get("field") or "artifact_contract")
    message = str(first_issue.get("message") or "Invalid stage artifact payload.")
    raise ValueError(f"{field_name}: {message}")
