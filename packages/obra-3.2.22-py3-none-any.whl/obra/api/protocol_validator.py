"""Validator-specific protocol constants, schema helpers, and validation dispatch.

Extracted from protocol.py to reduce module size and isolate validator
infrastructure.  All symbols are re-exported by protocol.py for backward
compatibility during the migration window.

This module is part of the protocol family and is kept byte-for-byte in sync
between:
- functions/src/orchestration/protocol_validator.py
- obra/api/protocol_validator.py
"""

import json
import logging
from functools import lru_cache
from importlib import resources
from typing import Any

from .protocol import EscalationFixerResult, ValidatorRequest, ValidatorResult

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Validator constants
# ---------------------------------------------------------------------------

VALIDATOR_STAGES = {
    "intent",
    "plan",
    "review_filter",
    "code",
    "code_verify",
    "escalation_fix",
}
VALIDATOR_SUBJECT_TYPES = {
    "intent",
    "plan_items",
    "agent_reports",
    "code_delta",
    "escalation_context",
}
ESCALATION_FIXER_ROUTES = frozenset(
    {
        "amend_plan",
        "fix_code",
        "reclassify_review",
        "retry_stage",
        "escalate",
    }
)
ESCALATION_FIXER_FIX_CODE_VERIFICATION_SCOPES = frozenset(
    {"auto", "tests", "lint", "security"}
)
_VALIDATOR_SCHEMA_PACKAGE = f"{__package__.rsplit('.', 1)[0]}.config.schemas"
_VALIDATOR_SCHEMA_FILE = "validator_payload.schema.json"


# ---------------------------------------------------------------------------
# Schema helper functions
# ---------------------------------------------------------------------------

@lru_cache(maxsize=1)
def _load_validator_payload_schema() -> dict[str, Any]:
    try:
        schema_path = resources.files(_VALIDATOR_SCHEMA_PACKAGE).joinpath(
            _VALIDATOR_SCHEMA_FILE
        )
        content = schema_path.read_text(encoding="utf-8")
        return json.loads(content) if content.strip() else {}
    except Exception as exc:
        raise RuntimeError(
            "Failed to load validator schema from packaged resources "
            f"{_VALIDATOR_SCHEMA_PACKAGE}.{_VALIDATOR_SCHEMA_FILE}: {exc}"
        ) from exc


def _schema_type_matches(value: Any, expected_type: str) -> bool:
    if expected_type == "boolean":
        return isinstance(value, bool)
    if expected_type == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected_type == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected_type == "string":
        return isinstance(value, str)
    if expected_type == "object":
        return isinstance(value, dict)
    if expected_type == "array":
        return isinstance(value, list)
    return True


def _validate_against_schema(
    value: Any, schema: dict[str, Any], path: str = "payload"
) -> tuple[bool, str]:
    expected_type = schema.get("type")
    if expected_type:
        types = expected_type if isinstance(expected_type, list) else [expected_type]
        if not any(_schema_type_matches(value, t) for t in types):
            return False, f"{path} must be of type {expected_type}"

    if "enum" in schema and value not in schema["enum"]:
        return False, f"{path} must be one of {schema['enum']}"

    if expected_type == "integer" and "minimum" in schema:
        minimum = schema.get("minimum")
        if isinstance(value, int) and not isinstance(value, bool) and value < minimum:
            return False, f"{path} must be >= {minimum}"

    if expected_type == "object":
        if not isinstance(value, dict):
            return False, f"{path} must be an object"
        required = schema.get("required", [])
        for field_name in required:
            if field_name not in value:
                return False, f"Missing required field: {field_name}"

        properties = schema.get("properties", {})
        for key, subschema in properties.items():
            if key in value:
                is_valid, error = _validate_against_schema(
                    value[key],
                    subschema,
                    path=f"{path}.{key}",
                )
                if not is_valid:
                    return False, error

        if schema.get("additionalProperties") is False:
            extra = set(value.keys()) - set(properties.keys())
            if extra:
                return False, f"Unexpected fields: {', '.join(sorted(extra))}"

    if expected_type == "array":
        if not isinstance(value, list):
            return False, f"{path} must be an array"
        items_schema = schema.get("items")
        if items_schema:
            for index, item in enumerate(value):
                is_valid, error = _validate_against_schema(
                    item,
                    items_schema,
                    path=f"{path}[{index}]",
                )
                if not is_valid:
                    return False, error

    return True, ""


def _validate_validator_schema(
    payload: dict[str, Any],
    schema_name: str,
) -> tuple[bool, str]:
    try:
        schema = _load_validator_payload_schema()
    except FileNotFoundError as exc:
        return False, str(exc)

    definitions = schema.get("$defs", {})
    definition = definitions.get(schema_name)
    if not isinstance(definition, dict):
        return False, f"Schema definition not found: {schema_name}"
    return _validate_against_schema(payload, definition)


# ---------------------------------------------------------------------------
# Validation dispatch functions
# ---------------------------------------------------------------------------

def validate_validator_request(
    request: ValidatorRequest, *, schema_validation: bool = True
) -> tuple[bool, str]:
    """Validate a ValidatorRequest."""
    if not isinstance(request, ValidatorRequest):
        return False, "Request must be a ValidatorRequest"
    if not request.stage:
        return False, "Missing required field: stage"
    if request.stage not in VALIDATOR_STAGES:
        return False, f"Invalid stage: {request.stage}"
    if not request.subject_type:
        return False, "Missing required field: subject_type"
    if request.subject_type not in VALIDATOR_SUBJECT_TYPES:
        return False, f"Invalid subject_type: {request.subject_type}"
    if request.subject_payload is None:
        return False, "Missing required field: subject_payload"
    if not isinstance(request.subject_payload, dict):
        return False, "subject_payload must be a dict"
    if request.prompt_id is None:
        return False, "Missing required field: prompt_id"
    if request.prompt_version is None:
        return False, "Missing required field: prompt_version"
    if request.compiled_prompt is None:
        return False, "Missing required field: compiled_prompt"
    if request.timeout_s is None:
        return False, "Missing required field: timeout_s"
    if not isinstance(request.timeout_s, int):
        return False, "timeout_s must be an int"
    if request.config is None:
        return False, "Missing required field: config"
    if not isinstance(request.config, dict):
        return False, "config must be a dict"
    if schema_validation:
        schema_valid, schema_error = _validate_validator_schema(
            request.to_dict(), "validator_request"
        )
        if not schema_valid:
            return False, schema_error
    return True, ""


def validate_validator_result(
    result: ValidatorResult, *, schema_validation: bool = True
) -> tuple[bool, str]:
    """Validate a ValidatorResult."""
    if not isinstance(result, ValidatorResult):
        return False, "Result must be a ValidatorResult"
    if not isinstance(result.sound, bool):
        return False, "sound must be a bool"
    if not isinstance(result.issues, list):
        return False, "issues must be a list"
    if not isinstance(result.constraints, list):
        return False, "constraints must be a list"
    if not isinstance(result.decisions, list):
        return False, "decisions must be a list"
    if not isinstance(result.provenance, dict):
        return False, "provenance must be a dict"
    if schema_validation:
        schema_valid, schema_error = _validate_validator_schema(
            result.to_dict(), "validator_result"
        )
        if not schema_valid:
            return False, schema_error
    return True, ""


def validate_escalation_fixer_result(
    result: EscalationFixerResult,
    *,
    schema_validation: bool = True,
) -> tuple[bool, str]:
    """Validate an EscalationFixerResult."""
    if not isinstance(result, EscalationFixerResult):
        return False, "Result must be an EscalationFixerResult"
    if result.stage != "escalation_fix":
        return False, "stage must be 'escalation_fix'"
    if not isinstance(result.repairable, bool):
        return False, "repairable must be a bool"
    if result.route not in ESCALATION_FIXER_ROUTES:
        return False, f"route must be one of {sorted(ESCALATION_FIXER_ROUTES)}"
    if not isinstance(result.root_cause, str):
        return False, "root_cause must be a string"
    if not isinstance(result.summary, str):
        return False, "summary must be a string"
    if not isinstance(result.version, str):
        return False, "version must be a string"
    if not isinstance(result.provenance, dict):
        return False, "provenance must be a dict"

    route_payloads = {
        "amend_plan": result.amend_plan,
        "fix_code": result.fix_code,
        "reclassify_review": result.reclassify_review,
        "retry_stage": result.retry_stage,
    }
    for route_name, payload in route_payloads.items():
        if payload is not None and not isinstance(payload, dict):
            return False, f"{route_name} must be a dict when provided"

    required_payload_field = {
        "amend_plan": "amend_plan",
        "fix_code": "fix_code",
        "reclassify_review": "reclassify_review",
        "retry_stage": "retry_stage",
    }.get(result.route)
    if required_payload_field is not None and getattr(result, required_payload_field) is None:
        return False, f"{required_payload_field} is required for route={result.route!r}"

    if result.route == "fix_code":
        payload = result.fix_code or {}
        reason = payload.get("reason")
        guidance = payload.get("guidance")
        if not isinstance(reason, str) or not reason.strip():
            return False, "fix_code.reason must be a non-empty string"
        if not isinstance(guidance, str) or not guidance.strip():
            return False, "fix_code.guidance must be a non-empty string"
        issue_ids = payload.get("issue_ids", [])
        if not isinstance(issue_ids, list) or not all(
            isinstance(issue_id, str) for issue_id in issue_ids
        ):
            return False, "fix_code.issue_ids must be a list[str]"
        fresh_fix = payload.get("fresh_fix")
        if fresh_fix is not None and not isinstance(fresh_fix, bool):
            return False, "fix_code.fresh_fix must be a bool when provided"
        drop_fix_history = payload.get("drop_fix_history")
        if drop_fix_history is not None and not isinstance(drop_fix_history, bool):
            return False, "fix_code.drop_fix_history must be a bool when provided"
        verification_scope = payload.get("verification_scope")
        if verification_scope is not None:
            if not isinstance(verification_scope, str) or not verification_scope.strip():
                return False, "fix_code.verification_scope must be a non-empty string"
            if (
                verification_scope.strip().lower()
                not in ESCALATION_FIXER_FIX_CODE_VERIFICATION_SCOPES
            ):
                return (
                    False,
                    "fix_code.verification_scope must be one of "
                    f"{sorted(ESCALATION_FIXER_FIX_CODE_VERIFICATION_SCOPES)}",
                )

    if schema_validation:
        schema_valid, schema_error = _validate_validator_schema(
            result.to_dict(), "escalation_fixer_result"
        )
        if not schema_valid:
            return False, schema_error
    return True, ""
