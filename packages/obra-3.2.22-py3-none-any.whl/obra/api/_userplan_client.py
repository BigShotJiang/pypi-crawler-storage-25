"""UserPlan resource sub-client for the Obra API.

Provides UserPlan CRUD operations: creation, retrieval, listing, quality
assessment updates, step management (add, remove, update, status), and
step context updates.

All HTTP operations delegate to the shared HTTPCore instance.
"""

from __future__ import annotations

from http import HTTPStatus
from typing import TYPE_CHECKING, Any

from obra.constants import API_LIMIT_MAX
from obra.exceptions import APIError

if TYPE_CHECKING:
    from obra.api._http_core import HTTPCore

import logging

logger = logging.getLogger(__name__)


class UserPlanClient:
    """Sub-client for UserPlan-related API operations.

    Encapsulates UserPlan creation, retrieval, quality updates, and step
    management. Delegates all HTTP transport to a shared HTTPCore.

    Example:
        from obra.api._http_core import HTTPCore

        http = HTTPCore(base_url="https://...", auth_token="...")
        userplans = UserPlanClient(http)
        plan = userplans.get_userplan("UP-20260116-auth-feature")
    """

    def __init__(self, http: HTTPCore) -> None:
        """Initialize UserPlanClient.

        Args:
            http: Shared HTTPCore instance for HTTP transport
        """
        self._http = http

    @staticmethod
    def _normalize_project_id(project_id: str | int | None) -> str | None:
        """Normalize project identifiers to strings for API payloads."""
        if project_id is None:
            return None
        return str(project_id)

    def create_userplan(
        self,
        userplan_id: str,
        project_id: str,
        source: dict[str, Any],
        steps: list[dict[str, Any]],
        session_id: str | None = None,
        status: str = "draft",
        quality_score: float | None = None,
        quality_status: str = "not_assessed",
        work_type: str | None = None,
        context: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new UserPlan in storage.

        S2.T3: Plan file imports must create a UserPlan before derivation.
        This method persists the UserPlan to server storage.

        Args:
            userplan_id: Unique identifier (format: UP-<timestamp>-<slug>)
            project_id: Project identifier
            source: Metadata about how the UserPlan was created
            steps: List of UserPlan steps (at least 1 required)
            session_id: Optional session context reference
            status: UserPlan lifecycle status (default: 'draft')
            quality_score: Quality assessment score (0.0-1.0)
            quality_status: Quality assessment status (default: 'not_assessed')
            work_type: Detected or specified work type
            context: Top-level context inherited by all steps
            metadata: Optional extensibility metadata

        Returns:
            Dictionary with created UserPlan data including:
            - id: UserPlan ID
            - project_id: Project identifier
            - created_at: Creation timestamp

        Raises:
            APIError: If creation fails or validation fails

        Example:
            >>> userplans = UserPlanClient(http)
            >>> result = userplans.create_userplan(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     project_id="my-app",
            ...     source={"type": "plan_file", "generated": False},
            ...     steps=[{"id": "UP-20260116-auth-feature:S1", "index": 1, ...}]
            ... )
            >>> print(f"Created: {result['id']}")
        """
        normalized_project_id = self._normalize_project_id(project_id)
        payload: dict[str, Any] = {
            "userplan_id": userplan_id,
            "project_id": normalized_project_id,
            "source": source,
            "steps": steps,
            "status": status,
            "quality_status": quality_status,
        }
        if session_id is not None:
            payload["session_id"] = session_id
        if quality_score is not None:
            payload["quality_score"] = quality_score
        if work_type is not None:
            payload["work_type"] = work_type
        if context is not None:
            payload["context"] = context
        if metadata is not None:
            payload["metadata"] = metadata

        return self._http._request("POST", "create_userplan", json=payload)

    def get_userplan(self, userplan_id: str) -> dict[str, Any] | None:
        """Get a UserPlan by ID.

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)

        Returns:
            UserPlan data dictionary or None if not found

        Raises:
            APIError: If request fails (other than not found)

        Example:
            >>> userplans = UserPlanClient(http)
            >>> userplan = userplans.get_userplan("UP-20260116-auth-feature")
            >>> if userplan:
            ...     print(f"Found: {userplan['id']}")
        """
        try:
            return self._http._request("GET", f"get_userplan?userplan_id={userplan_id}")
        except APIError as e:
            if e.status_code == HTTPStatus.NOT_FOUND:
                return None
            raise

    def list_userplans(
        self,
        project_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """List UserPlans with optional filters.

        Args:
            project_id: Filter by project identifier (optional)
            status: Filter by status (draft, active, completed, archived)
            limit: Maximum number of UserPlans to return (default: 50, max: 100)

        Returns:
            List of UserPlan dictionaries with fields:
            - id: UserPlan ID
            - project_id: Project identifier
            - status: UserPlan lifecycle status
            - source: Source metadata
            - step_count: Number of steps
            - created_at: Creation timestamp
            - updated_at: Last update timestamp
            - quality_score: Quality assessment score (if assessed)
            - quality_status: Quality assessment status

        Raises:
            APIError: If list request fails

        Example:
            >>> userplans = UserPlanClient(http)
            >>> plans = userplans.list_userplans(project_id="my-app", limit=10)
            >>> for up in plans:
            ...     print(f"{up['id']}: {up['step_count']} steps")
        """
        normalized_project_id = self._normalize_project_id(project_id)
        params: list[str] = [f"limit={min(limit, API_LIMIT_MAX)}"]
        if normalized_project_id:
            params.append(f"project_id={normalized_project_id}")
        if status:
            params.append(f"status={status}")

        query_string = "&".join(params)
        response = self._http._request("GET", f"list_userplans?{query_string}")
        userplans = response.get("userplans")
        if isinstance(userplans, list):
            return userplans
        return []

    def update_userplan_quality(
        self,
        userplan_id: str,
        quality_score: float | None,
        quality_status: str,
        quality_hints: list[str] | None = None,
        quality_threshold: float = 0.6,
    ) -> dict[str, Any]:
        """Update UserPlan with quality assessment results.

        Args:
            userplan_id: UserPlan ID to update
            quality_score: Quality score (0.0-1.0), or None if not assessed
            quality_status: Quality status (passed, failed, skipped, not_assessed)
            quality_hints: Optional list of improvement suggestions
            quality_threshold: Threshold used for assessment (default 0.6)

        Returns:
            Updated UserPlan data dictionary

        Raises:
            APIError: If request fails

        Example:
            >>> userplans = UserPlanClient(http)
            >>> result = userplans.update_userplan_quality(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     quality_score=0.75,
            ...     quality_status="passed",
            ...     quality_hints=[]
            ... )
        """
        payload: dict[str, Any] = {
            "userplan_id": userplan_id,
            "quality_status": quality_status,
            "quality_threshold": quality_threshold,
        }
        if quality_score is not None:
            payload["quality_score"] = quality_score
        if quality_hints is not None:
            payload["quality_hints"] = quality_hints

        return self._http._request("PATCH", "update_userplan_quality", json=payload)

    def update_userplan_step(
        self,
        userplan_id: str,
        step_index: int,
        title: str | None = None,
        description: str | None = None,
        expected_version: int | None = None,
        cascade: bool = False,
    ) -> dict[str, Any]:
        """Update a specific step in a UserPlan.

        When step content (title or description) is modified, the step's
        derivation_status is automatically set to STALE to indicate that
        re-derivation is needed.

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)
            step_index: 1-based index of the step to update
            title: New step title (optional)
            description: New step description (optional)
            expected_version: Optional version for optimistic locking
            cascade: If True, mark sibling steps (steps after the edited step)
                    as STALE to handle staleness propagation

        Returns:
            Updated UserPlan data dictionary with the modified step.
            Includes 'cascaded_steps' list of step indices that were marked STALE.

        Raises:
            APIError: If request fails or step not found
            ValueError: If neither title nor description is provided

        Example:
            >>> userplans = UserPlanClient(http)
            >>> result = userplans.update_userplan_step(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     step_index=1,
            ...     title="Implement JWT authentication",
            ...     description="Create JWT token handling with refresh tokens",
            ...     cascade=True
            ... )
            >>> # Step derivation_status is now STALE
            >>> print(result['updated_step']['derivation_status'])
            'stale'
            >>> # Sibling steps after step 1 are also marked STALE
            >>> print(result['cascaded_steps'])
            [2, 3]
        """
        if title is None and description is None:
            msg = "At least one of 'title' or 'description' must be provided"
            raise ValueError(msg)

        payload: dict[str, Any] = {
            "step_index": step_index,
        }
        if title is not None:
            payload["title"] = title
        if description is not None:
            payload["description"] = description
        if expected_version is not None:
            payload["expected_version"] = expected_version
        if cascade:
            payload["cascade"] = cascade

        payload["userplan_id"] = userplan_id
        payload["step_index"] = step_index
        return self._http._request(
            "PATCH",
            "update_userplan_step",
            json=payload,
        )

    def update_userplan_step_status(
        self,
        userplan_id: str,
        step_index: int,
        derivation_status: str,
        expected_version: int | None = None,
    ) -> dict[str, Any]:
        """Update the derivation status of a specific step in a UserPlan.

        Used for --from-step re-derivation to mark steps as DERIVING before
        derivation and DERIVED after completion.

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)
            step_index: 1-based index of the step to update
            derivation_status: New status (not_derived, deriving, derived, stale)
            expected_version: Optional version for optimistic locking

        Returns:
            Updated UserPlan data dictionary with the modified step

        Raises:
            APIError: If request fails or step not found

        Example:
            >>> userplans = UserPlanClient(http)
            >>> # Mark step 3 as deriving before re-derivation
            >>> result = userplans.update_userplan_step_status(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     step_index=3,
            ...     derivation_status="deriving"
            ... )
            >>> print(result['steps'][2]['derivation_status'])
            'deriving'
        """
        # Route single step status update through batch endpoint
        payload: dict[str, Any] = {
            "userplan_id": userplan_id,
            "step_indices": [step_index],
            "derivation_status": derivation_status,
        }
        if expected_version is not None:
            payload["expected_version"] = expected_version

        return self._http._request(
            "PATCH",
            "update_userplan_steps_status_batch",
            json=payload,
        )

    def update_userplan_steps_status_batch(
        self,
        userplan_id: str,
        step_indices: list[int],
        derivation_status: str,
        expected_version: int | None = None,
    ) -> dict[str, Any]:
        """Update the derivation status of multiple steps in a UserPlan.

        Batch operation to update status of multiple steps at once,
        useful for --from-step re-derivation which affects steps N through end.

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)
            step_indices: List of 1-based indices of steps to update
            derivation_status: New status (not_derived, deriving, derived, stale)
            expected_version: Optional version for optimistic locking

        Returns:
            Updated UserPlan data dictionary with modified steps

        Raises:
            APIError: If request fails or any step not found

        Example:
            >>> userplans = UserPlanClient(http)
            >>> # Mark steps 3, 4, 5 as deriving before re-derivation
            >>> result = userplans.update_userplan_steps_status_batch(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     step_indices=[3, 4, 5],
            ...     derivation_status="deriving"
            ... )
        """
        payload: dict[str, Any] = {
            "userplan_id": userplan_id,
            "step_indices": step_indices,
            "derivation_status": derivation_status,
        }
        if expected_version is not None:
            payload["expected_version"] = expected_version

        return self._http._request(
            "PATCH",
            "update_userplan_steps_status_batch",
            json=payload,
        )

    def add_userplan_step(
        self,
        userplan_id: str,
        title: str,
        description: str,
        index: int | None = None,
        context: dict[str, Any] | None = None,
        expected_version: int | None = None,
    ) -> dict[str, Any]:
        """Add a new step to a UserPlan.

        Inserts a new step at the specified index (or appends to end if not specified).
        Steps after the insertion point are re-indexed automatically.

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)
            title: Step title (required)
            description: Step description (required)
            index: 1-based index for insertion (default: append to end)
            context: Optional step context (deliverables, requirements, etc.)
            expected_version: Optional version for optimistic locking

        Returns:
            Updated UserPlan data dictionary with the new step.
            Includes:
            - added_step: The newly added step
            - steps: All steps with updated indices

        Raises:
            APIError: If request fails or UserPlan not found

        Example:
            >>> userplans = UserPlanClient(http)
            >>> result = userplans.add_userplan_step(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     title="Add password validation",
            ...     description="Implement password strength validation rules",
            ...     index=2  # Insert as second step
            ... )
            >>> print(result['added_step']['id'])
            'UP-20260116-auth-feature:S2'
        """
        payload: dict[str, Any] = {
            "userplan_id": userplan_id,
            "title": title,
            "description": description,
        }
        if index is not None:
            payload["index"] = index
        if context is not None:
            payload["context"] = context
        if expected_version is not None:
            payload["expected_version"] = expected_version

        return self._http._request(
            "POST",
            "add_userplan_step",
            json=payload,
        )

    def remove_userplan_step(
        self,
        userplan_id: str,
        step_index: int,
        expected_version: int | None = None,
    ) -> dict[str, Any]:
        """Remove a step from a UserPlan.

        Removes the step at the specified index. Steps after the removed step
        are re-indexed automatically. This operation cannot be undone.

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)
            step_index: 1-based index of the step to remove
            expected_version: Optional version for optimistic locking

        Returns:
            Updated UserPlan data dictionary without the removed step.
            Includes:
            - removed_step: The step that was removed
            - steps: Remaining steps with updated indices

        Raises:
            APIError: If request fails, UserPlan not found, or step not found

        Example:
            >>> userplans = UserPlanClient(http)
            >>> result = userplans.remove_userplan_step(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     step_index=2
            ... )
            >>> print(f"Removed: {result['removed_step']['title']}")
        """
        params = f"userplan_id={userplan_id}&step_index={step_index}"
        if expected_version is not None:
            params += f"&expected_version={expected_version}"

        return self._http._request(
            "DELETE",
            f"remove_userplan_step?{params}",
        )

    def get_userplan_step(
        self,
        userplan_id: str,
        step_index: int,
    ) -> dict[str, Any] | None:
        """Get a specific step from a UserPlan.

        Retrieves detailed information about a single step including
        its context and derivation status.

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)
            step_index: 1-based index of the step to retrieve

        Returns:
            Step data dictionary or None if not found.
            Includes:
            - id: Step ID
            - index: Step index
            - title: Step title
            - description: Step description
            - context: Step context (if set)
            - derivation_status: Current derivation status

        Raises:
            APIError: If request fails (other than not found)

        Example:
            >>> userplans = UserPlanClient(http)
            >>> step = userplans.get_userplan_step(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     step_index=1
            ... )
            >>> if step:
            ...     print(f"Step: {step['title']}")
        """
        try:
            return self._http._request(
                "GET",
                f"get_userplan_step?userplan_id={userplan_id}&step_index={step_index}",
            )
        except APIError as e:
            if e.status_code == HTTPStatus.NOT_FOUND:
                return None
            raise

    def update_userplan_step_context(
        self,
        userplan_id: str,
        step_index: int,
        context: dict[str, Any],
        expected_version: int | None = None,
    ) -> dict[str, Any]:
        """Update the context of a specific step in a UserPlan.

        Updates the step's context fields (deliverables, success_criteria,
        requirements, tech_stack, constraints, assumptions).

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)
            step_index: 1-based index of the step to update
            context: Context fields to update (merged with existing)
            expected_version: Optional version for optimistic locking

        Returns:
            Updated UserPlan data dictionary with the modified step.

        Raises:
            APIError: If request fails or step not found

        Example:
            >>> userplans = UserPlanClient(http)
            >>> result = userplans.update_userplan_step_context(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     step_index=1,
            ...     context={
            ...         "deliverables": ["JWT middleware", "Token refresh endpoint"],
            ...         "tech_stack": ["Python", "FastAPI", "PyJWT"]
            ...     }
            ... )
        """
        payload: dict[str, Any] = {
            "userplan_id": userplan_id,
            "step_index": step_index,
            "context": context,
        }
        if expected_version is not None:
            payload["expected_version"] = expected_version

        return self._http._request(
            "PATCH",
            "update_userplan_step_context",
            json=payload,
        )
