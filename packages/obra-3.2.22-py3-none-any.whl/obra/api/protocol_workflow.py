"""Workflow artifact protocol families shared across client and server."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .protocol_core import _coerce_optional_dict


def _coerce_dict_list(data: Any) -> list[dict[str, Any]]:
    """Return a shallow-copied list of dictionaries."""
    if not isinstance(data, list):
        return []
    return [dict(item) for item in data if isinstance(item, dict)]


def _coerce_optional_int(data: Any) -> int | None:
    """Return an integer when the input is numeric-like."""
    if data is None or data == "":
        return None
    try:
        return int(data)
    except (TypeError, ValueError):
        return None


@dataclass(slots=True)
class WorkflowRevisionRef:
    """Canonical workflow revision identifier."""

    workflow_id: str = ""
    revision_id: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Serialize the revision ref."""
        return {
            "workflow_id": self.workflow_id,
            "revision_id": self.revision_id,
        }

    @classmethod
    def from_dict(cls, data: Any) -> "WorkflowRevisionRef | None":
        """Parse a workflow revision ref when possible."""
        if not isinstance(data, dict):
            return None
        workflow_id = str(data.get("workflow_id", "") or "")
        revision_id = str(data.get("revision_id", "") or "")
        if not workflow_id and not revision_id:
            return None
        return cls(
            workflow_id=workflow_id,
            revision_id=revision_id,
        )


@dataclass(slots=True)
class WorkflowCandidateEnvelope:
    """Canonical workflow-edit request envelope."""

    workflow_id: str = ""
    expected_revision_id: str = ""
    create_fork: bool = False
    title: str = ""
    description: str = ""
    domain_id: str = ""
    workflow_run_count: int | None = None
    workflow_definition: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    correlation: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the candidate envelope."""
        payload: dict[str, Any] = {
            "workflow_id": self.workflow_id,
            "expected_revision_id": self.expected_revision_id,
            "create_fork": self.create_fork,
            "title": self.title,
            "description": self.description,
            "domain_id": self.domain_id,
            "workflow_definition": dict(self.workflow_definition),
        }
        if self.workflow_run_count is not None:
            payload["workflow_run_count"] = self.workflow_run_count
        if self.metadata:
            payload["metadata"] = dict(self.metadata)
        if self.correlation:
            payload["correlation"] = dict(self.correlation)
        return payload

    @classmethod
    def from_dict(cls, data: Any) -> "WorkflowCandidateEnvelope":
        """Parse a workflow-edit candidate envelope."""
        payload = dict(data) if isinstance(data, dict) else {}
        return cls(
            workflow_id=str(payload.get("workflow_id", "") or ""),
            expected_revision_id=str(payload.get("expected_revision_id", "") or ""),
            create_fork=bool(payload.get("create_fork", False)),
            title=str(payload.get("title", "") or ""),
            description=str(payload.get("description", "") or ""),
            domain_id=str(payload.get("domain_id", "") or ""),
            workflow_run_count=_coerce_optional_int(payload.get("workflow_run_count")),
            workflow_definition=(
                dict(payload.get("workflow_definition", {}))
                if isinstance(payload.get("workflow_definition"), dict)
                else {}
            ),
            metadata=_coerce_optional_dict(payload.get("metadata")),
            correlation=_coerce_optional_dict(payload.get("correlation")),
        )


@dataclass(slots=True)
class WorkflowSemanticView:
    """Automation-friendly semantic workflow edit view."""

    selectors: list[dict[str, Any]] = field(default_factory=list)
    action_affordances: list[dict[str, Any]] = field(default_factory=list)
    text_projection: str = ""
    json_projection: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the semantic view."""
        payload: dict[str, Any] = {
            "selectors": _coerce_dict_list(self.selectors),
            "action_affordances": _coerce_dict_list(self.action_affordances),
            "json_projection": dict(self.json_projection),
        }
        if self.text_projection:
            payload["text_projection"] = self.text_projection
        return payload

    @classmethod
    def from_dict(cls, data: Any) -> "WorkflowSemanticView":
        """Parse a semantic view payload."""
        payload = dict(data) if isinstance(data, dict) else {}
        return cls(
            selectors=_coerce_dict_list(payload.get("selectors")),
            action_affordances=_coerce_dict_list(payload.get("action_affordances")),
            text_projection=str(payload.get("text_projection", "") or ""),
            json_projection=(
                dict(payload.get("json_projection", {}))
                if isinstance(payload.get("json_projection"), dict)
                else {}
            ),
        )


@dataclass(slots=True)
class WorkflowRevisionPayload:
    """Canonical workflow head or revision payload."""

    workflow_id: str = ""
    revision_id: str = ""
    previous_revision_id: str = ""
    domain_id: str = ""
    title: str = ""
    description: str = ""
    workflow_definition: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    validation_summary: dict[str, Any] = field(default_factory=dict)
    diff_summary: dict[str, Any] = field(default_factory=dict)
    conflict_summary: dict[str, Any] = field(default_factory=dict)
    runner_diagnostics: list[dict[str, Any]] = field(default_factory=list)
    binding_diagnostics: list[dict[str, Any]] = field(default_factory=list)
    lifecycle_validation: dict[str, Any] = field(default_factory=dict)
    workflow_readiness: dict[str, Any] | None = None
    semantic_view: WorkflowSemanticView | None = None
    correlation: dict[str, Any] = field(default_factory=dict)
    created_at: str = ""
    updated_at: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Serialize the revision payload."""
        payload: dict[str, Any] = {
            "workflow_id": self.workflow_id,
            "revision_id": self.revision_id,
            "previous_revision_id": self.previous_revision_id,
            "domain_id": self.domain_id,
            "title": self.title,
            "description": self.description,
            "workflow_definition": dict(self.workflow_definition),
            "metadata": dict(self.metadata),
            "validation_summary": dict(self.validation_summary),
            "diff_summary": dict(self.diff_summary),
            "conflict_summary": dict(self.conflict_summary),
            "runner_diagnostics": _coerce_dict_list(self.runner_diagnostics),
            "binding_diagnostics": _coerce_dict_list(self.binding_diagnostics),
            "lifecycle_validation": dict(self.lifecycle_validation),
            "workflow_readiness": (
                dict(self.workflow_readiness)
                if isinstance(self.workflow_readiness, dict)
                else None
            ),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }
        if self.semantic_view is not None:
            payload["semantic_view"] = self.semantic_view.to_dict()
        if self.correlation:
            payload["correlation"] = dict(self.correlation)
        return payload

    @classmethod
    def from_dict(cls, data: Any) -> "WorkflowRevisionPayload":
        """Parse a workflow revision payload."""
        payload = dict(data) if isinstance(data, dict) else {}
        return cls(
            workflow_id=str(payload.get("workflow_id", "") or ""),
            revision_id=str(payload.get("revision_id", "") or ""),
            previous_revision_id=str(payload.get("previous_revision_id", "") or ""),
            domain_id=str(payload.get("domain_id", "") or ""),
            title=str(payload.get("title", "") or ""),
            description=str(payload.get("description", "") or ""),
            workflow_definition=(
                dict(payload.get("workflow_definition", {}))
                if isinstance(payload.get("workflow_definition"), dict)
                else {}
            ),
            metadata=_coerce_optional_dict(payload.get("metadata")),
            validation_summary=_coerce_optional_dict(payload.get("validation_summary")),
            diff_summary=_coerce_optional_dict(payload.get("diff_summary")),
            conflict_summary=_coerce_optional_dict(payload.get("conflict_summary")),
            runner_diagnostics=_coerce_dict_list(payload.get("runner_diagnostics")),
            binding_diagnostics=_coerce_dict_list(payload.get("binding_diagnostics")),
            lifecycle_validation=_coerce_optional_dict(payload.get("lifecycle_validation")),
            workflow_readiness=(
                dict(payload.get("workflow_readiness", {}))
                if isinstance(payload.get("workflow_readiness"), dict)
                else None
            ),
            semantic_view=(
                WorkflowSemanticView.from_dict(payload.get("semantic_view"))
                if isinstance(payload.get("semantic_view"), dict)
                else None
            ),
            correlation=_coerce_optional_dict(payload.get("correlation")),
            created_at=str(payload.get("created_at", "") or ""),
            updated_at=str(payload.get("updated_at", "") or ""),
        )


@dataclass(slots=True)
class WorkflowMutationResult:
    """Canonical workflow create, validate, or apply result."""

    outcome: str = ""
    workflow: WorkflowRevisionPayload | None = None
    base_revision_ref: WorkflowRevisionRef | None = None
    current_revision_ref: WorkflowRevisionRef | None = None
    resulting_revision_ref: WorkflowRevisionRef | None = None
    validation_summary: dict[str, Any] = field(default_factory=dict)
    diff_summary: dict[str, Any] = field(default_factory=dict)
    conflict_summary: dict[str, Any] = field(default_factory=dict)
    workflow_readiness: dict[str, Any] | None = None
    correlation: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the mutation result."""
        payload: dict[str, Any] = {
            "outcome": self.outcome,
            "validation_summary": dict(self.validation_summary),
            "diff_summary": dict(self.diff_summary),
            "conflict_summary": dict(self.conflict_summary),
            "workflow_readiness": (
                dict(self.workflow_readiness)
                if isinstance(self.workflow_readiness, dict)
                else None
            ),
        }
        if self.workflow is not None:
            payload["workflow"] = self.workflow.to_dict()
        if self.base_revision_ref is not None:
            payload["base_revision_ref"] = self.base_revision_ref.to_dict()
        if self.current_revision_ref is not None:
            payload["current_revision_ref"] = self.current_revision_ref.to_dict()
        if self.resulting_revision_ref is not None:
            payload["resulting_revision_ref"] = self.resulting_revision_ref.to_dict()
        if self.correlation:
            payload["correlation"] = dict(self.correlation)
        return payload

    @classmethod
    def from_dict(cls, data: Any) -> "WorkflowMutationResult":
        """Parse a workflow mutation result payload."""
        payload = dict(data) if isinstance(data, dict) else {}
        workflow_payload = payload.get("workflow")
        return cls(
            outcome=str(payload.get("outcome", "") or ""),
            workflow=(
                WorkflowRevisionPayload.from_dict(workflow_payload)
                if isinstance(workflow_payload, dict)
                else None
            ),
            base_revision_ref=WorkflowRevisionRef.from_dict(payload.get("base_revision_ref")),
            current_revision_ref=WorkflowRevisionRef.from_dict(
                payload.get("current_revision_ref")
            ),
            resulting_revision_ref=WorkflowRevisionRef.from_dict(
                payload.get("resulting_revision_ref")
            ),
            validation_summary=_coerce_optional_dict(payload.get("validation_summary")),
            diff_summary=_coerce_optional_dict(payload.get("diff_summary")),
            conflict_summary=_coerce_optional_dict(payload.get("conflict_summary")),
            workflow_readiness=(
                dict(payload.get("workflow_readiness", {}))
                if isinstance(payload.get("workflow_readiness"), dict)
                else None
            ),
            correlation=_coerce_optional_dict(payload.get("correlation")),
        )


@dataclass(slots=True)
class WorkflowMutationEvent:
    """Workflow-level event payload for Stage C editing."""

    event_name: str = ""
    workflow_id: str = ""
    base_revision_ref: WorkflowRevisionRef | None = None
    current_revision_ref: WorkflowRevisionRef | None = None
    resulting_revision_ref: WorkflowRevisionRef | None = None
    correlation: dict[str, Any] = field(default_factory=dict)
    payload: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the workflow mutation event."""
        data: dict[str, Any] = {
            "event_name": self.event_name,
            "workflow_id": self.workflow_id,
            "payload": dict(self.payload),
        }
        if self.base_revision_ref is not None:
            data["base_revision_ref"] = self.base_revision_ref.to_dict()
        if self.current_revision_ref is not None:
            data["current_revision_ref"] = self.current_revision_ref.to_dict()
        if self.resulting_revision_ref is not None:
            data["resulting_revision_ref"] = self.resulting_revision_ref.to_dict()
        if self.correlation:
            data["correlation"] = dict(self.correlation)
        return data

    @classmethod
    def from_dict(cls, data: Any) -> "WorkflowMutationEvent":
        """Parse a workflow mutation event payload."""
        payload = dict(data) if isinstance(data, dict) else {}
        return cls(
            event_name=str(payload.get("event_name", "") or ""),
            workflow_id=str(payload.get("workflow_id", "") or ""),
            base_revision_ref=WorkflowRevisionRef.from_dict(payload.get("base_revision_ref")),
            current_revision_ref=WorkflowRevisionRef.from_dict(
                payload.get("current_revision_ref")
            ),
            resulting_revision_ref=WorkflowRevisionRef.from_dict(
                payload.get("resulting_revision_ref")
            ),
            correlation=_coerce_optional_dict(payload.get("correlation")),
            payload=_coerce_optional_dict(payload.get("payload")),
        )


__all__ = [
    "WorkflowCandidateEnvelope",
    "WorkflowMutationEvent",
    "WorkflowMutationResult",
    "WorkflowRevisionPayload",
    "WorkflowRevisionRef",
    "WorkflowSemanticView",
]
