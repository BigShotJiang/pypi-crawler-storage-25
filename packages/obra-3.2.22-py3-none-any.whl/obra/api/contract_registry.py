"""API contract registry for client/server compatibility checks.

Defines hybrid and resource request contract mappings used by schema sync
validation and contract tests. This module is intended for tooling and CI,
not runtime.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Any, Iterable

from obra.api.protocol import (
    ActionType,
    DerivedPlan,
    DeriveRequest,
    EscalationNotice,
    ExaminationReport,
    ExamineRequest,
    ExecutionRequest,
    ExecutionResult,
    FixReport,
    FixRequest,
    IntentReport,
    IntentRequest,
    PipelineStageRequest,
    ResumeRequest,
    ReviewRequest,
    RevisedPlan,
    RevisionRequest,
    SessionStart,
    StoryPreflightRequest,
    ValidatorRequest,
    WaitPayload,
)

_SERVER_PATH = Path(__file__).resolve().parents[2] / "functions"
if _SERVER_PATH.exists() and str(_SERVER_PATH) not in sys.path:
    sys.path.insert(0, str(_SERVER_PATH))

try:
    from functions.src.schemas.planning_schemas import IntentReportSchema, PlanUploadSchema
    from functions.src.schemas.project_schemas import (
        ProjectCreateSchema,
        ProjectSelectSchema,
        ProjectUpdateSchema,
    )
    from functions.src.schemas.request_schemas import (
        DerivedPlanSchema,
        ExaminationReportSchema,
        ExecutionReportSchema,
        FixReportSchema,
        PipelineStageReportSchema,
        ResumeRequestSchema,
        ReviewReportSchema,
        RevisedPlanSchema,
        SessionStartSchema,
        Story0ReportSchema,
    )
    from functions.src.schemas.session_schemas import (
        ForceCompleteSessionSchema,
        SessionMutationSchema,
    )
    from functions.src.schemas.userplan_schemas import (
        UserPlanAddStepSchema,
        UserPlanCreateSchema,
        UserPlanQualityUpdateSchema,
        UserPlanStepBatchStatusSchema,
        UserPlanStepContextSchema,
        UserPlanStepUpdateSchema,
    )
    from functions.src.schemas.workflow_schemas import (
        RunnerCompatibilityCheckSchema,
        WorkflowCandidateSchema,
    )
except Exception as exc:  # pragma: no cover - only hit outside repo context
    IntentReportSchema = None  # type: ignore[assignment]
    PlanUploadSchema = None  # type: ignore[assignment]
    ProjectCreateSchema = None  # type: ignore[assignment]
    ProjectSelectSchema = None  # type: ignore[assignment]
    ProjectUpdateSchema = None  # type: ignore[assignment]
    DerivedPlanSchema = None  # type: ignore[assignment]
    ExaminationReportSchema = None  # type: ignore[assignment]
    ExecutionReportSchema = None  # type: ignore[assignment]
    FixReportSchema = None  # type: ignore[assignment]
    PipelineStageReportSchema = None  # type: ignore[assignment]
    ForceCompleteSessionSchema = None  # type: ignore[assignment]
    ResumeRequestSchema = None  # type: ignore[assignment]
    ReviewReportSchema = None  # type: ignore[assignment]
    RevisedPlanSchema = None  # type: ignore[assignment]
    SessionStartSchema = None  # type: ignore[assignment]
    Story0ReportSchema = None  # type: ignore[assignment]
    SessionMutationSchema = None  # type: ignore[assignment]
    UserPlanAddStepSchema = None  # type: ignore[assignment]
    UserPlanCreateSchema = None  # type: ignore[assignment]
    UserPlanQualityUpdateSchema = None  # type: ignore[assignment]
    UserPlanStepBatchStatusSchema = None  # type: ignore[assignment]
    UserPlanStepContextSchema = None  # type: ignore[assignment]
    UserPlanStepUpdateSchema = None  # type: ignore[assignment]
    RunnerCompatibilityCheckSchema = None  # type: ignore[assignment]
    WorkflowCandidateSchema = None  # type: ignore[assignment]
    _SERVER_IMPORT_ERROR: Exception | None = exc
else:
    _SERVER_IMPORT_ERROR = None


@dataclass(frozen=True)
class ContractSpec:
    """Defines a client/server API contract mapping."""

    name: str
    client_request_type: type[Any] | None
    server_request_schema: type[Any] | None
    client_response_type: type[Any] | None = None
    server_response_type: type[Any] | None = None
    allow_server_superset: bool = False
    client_fields: set[str] | None = None
    field_aliases: dict[str, str] | None = None
    fixture_name: str | None = None
    endpoint: str | None = None


@dataclass(frozen=True)
class ActionContractSpec:
    """Defines a server-action payload contract for client parsing."""

    name: str
    action_type: str
    client_payload_type: type[Any]
    fixture_name: str
    required_payload_fields: set[str] = field(default_factory=set)
    parse_kwargs: dict[str, Any] = field(default_factory=dict)
    payload_field_aliases: dict[str, str] = field(default_factory=dict)
    allowed_extra_payload_fields: set[str] = field(default_factory=set)


HYBRID_REQUEST_CONTRACTS: list[ContractSpec] = [
    ContractSpec(
        name="session_start",
        client_request_type=SessionStart,
        server_request_schema=SessionStartSchema,
        fixture_name="session_start",
        endpoint="hybrid_orchestrate",
    ),
    ContractSpec(
        name="report_intent",
        client_request_type=IntentReport,
        server_request_schema=IntentReportSchema,
        fixture_name="report_intent",
        endpoint="report_intent",
    ),
    ContractSpec(
        name="report_derivation",
        client_request_type=DerivedPlan,
        server_request_schema=DerivedPlanSchema,
        fixture_name="report_derivation",
        endpoint="report_derivation",
    ),
    ContractSpec(
        name="resume",
        client_request_type=ResumeRequest,
        server_request_schema=ResumeRequestSchema,
        fixture_name="resume",
        endpoint="resume",
    ),
    ContractSpec(
        name="report_examination",
        client_request_type=ExaminationReport,
        server_request_schema=ExaminationReportSchema,
        fixture_name="report_examination",
        endpoint="report_examination",
    ),
    ContractSpec(
        name="report_revision",
        client_request_type=RevisedPlan,
        server_request_schema=RevisedPlanSchema,
        fixture_name="report_revision",
        endpoint="report_revision",
    ),
    ContractSpec(
        name="report_execution",
        client_request_type=ExecutionResult,
        server_request_schema=ExecutionReportSchema,
        fixture_name="report_execution",
        endpoint="report_execution",
    ),
    ContractSpec(
        name="report_review",
        client_request_type=None,
        server_request_schema=ReviewReportSchema,
        client_fields={
            "session_id",
            "item_id",
            "agent_reports",
            "iteration",
            "progress_cursor",
        },
        fixture_name="report_review",
        endpoint="report_review",
    ),
    ContractSpec(
        name="report_fix",
        client_request_type=FixReport,
        server_request_schema=FixReportSchema,
        fixture_name="report_fix",
        endpoint="report_fix",
    ),
    ContractSpec(
        name="report_pipeline_stage",
        client_request_type=None,
        server_request_schema=PipelineStageReportSchema,
        client_fields={
            "session_id",
            "stage_name",
            "stage_execution_id",
            "execution_status",
            "outcome",
            "findings",
            "stage_output_artifacts",
            "workflow_accumulation_artifact",
            "candidate_stage_output_artifacts",
            "accepted_stage_output_artifact_refs",
            "candidate_workflow_accumulation_artifact",
            "accepted_workflow_accumulation_artifact_ref",
            "routing_signal",
            "loop_signal",
            "loop_verdict",
            "loop_state",
            "pending_manual",
            "resume",
            "workflow_lifecycle",
            "lifecycle_decisions",
            "legacy_phase_normalization",
            "runner_id",
            "runner_version",
            "runner_selector",
            "runner_diagnostic",
            "metadata",
            "verdict",
            "issues",
            "iteration",
            "duration_s",
            "progress_cursor",
        },
        fixture_name="report_pipeline_stage",
        endpoint="report_pipeline_stage",
    ),
    ContractSpec(
        name="report_story0",
        client_request_type=None,
        server_request_schema=Story0ReportSchema,
        client_fields={
            "session_id",
            "status",
            "completed_prereqs",
            "failed_prereqs",
            "blocking_failures",
            "non_blocking_failures",
            "verification_tools",
            "mocked_credentials",
            "progress_cursor",
        },
        fixture_name="report_story0",
        endpoint="report_story0",
    ),
]


RESOURCE_REQUEST_CONTRACTS: list[ContractSpec] = [
    ContractSpec(
        name="create_userplan",
        client_request_type=None,
        server_request_schema=UserPlanCreateSchema,
        client_fields={
            "userplan_id",
            "project_id",
            "source",
            "steps",
            "session_id",
            "status",
            "quality_score",
            "quality_status",
            "work_type",
            "context",
            "metadata",
        },
        fixture_name="create_userplan",
        endpoint="create_userplan",
    ),
    ContractSpec(
        name="update_userplan_quality",
        client_request_type=None,
        server_request_schema=UserPlanQualityUpdateSchema,
        client_fields={
            "userplan_id",
            "quality_score",
            "quality_status",
            "quality_hints",
            "quality_threshold",
        },
        fixture_name="update_userplan_quality",
        endpoint="update_userplan_quality",
    ),
    ContractSpec(
        name="update_userplan_step",
        client_request_type=None,
        server_request_schema=UserPlanStepUpdateSchema,
        client_fields={
            "userplan_id",
            "step_index",
            "title",
            "description",
            "expected_version",
            "cascade",
        },
        fixture_name="update_userplan_step",
        endpoint="update_userplan_step",
    ),
    ContractSpec(
        name="update_userplan_steps_status_batch",
        client_request_type=None,
        server_request_schema=UserPlanStepBatchStatusSchema,
        client_fields={
            "userplan_id",
            "step_indices",
            "derivation_status",
            "expected_version",
        },
        fixture_name="update_userplan_steps_status_batch",
        endpoint="update_userplan_steps_status_batch",
    ),
    ContractSpec(
        name="add_userplan_step",
        client_request_type=None,
        server_request_schema=UserPlanAddStepSchema,
        client_fields={
            "userplan_id",
            "title",
            "description",
            "index",
            "context",
            "expected_version",
        },
        fixture_name="add_userplan_step",
        endpoint="add_userplan_step",
    ),
    ContractSpec(
        name="update_userplan_step_context",
        client_request_type=None,
        server_request_schema=UserPlanStepContextSchema,
        client_fields={
            "userplan_id",
            "step_index",
            "context",
            "expected_version",
        },
        fixture_name="update_userplan_step_context",
        endpoint="update_userplan_step_context",
    ),
    ContractSpec(
        name="create_project",
        client_request_type=None,
        server_request_schema=ProjectCreateSchema,
        client_fields={"name", "working_dir", "description", "config", "domain_id"},
        fixture_name="create_project",
        endpoint="create_project",
    ),
    ContractSpec(
        name="update_project",
        client_request_type=None,
        server_request_schema=ProjectUpdateSchema,
        client_fields={"project_id", "name", "working_dir", "domain_id"},
        fixture_name="update_project",
        endpoint="update_project",
    ),
    ContractSpec(
        name="delete_project",
        client_request_type=None,
        server_request_schema=ProjectSelectSchema,
        client_fields={"project_id"},
        fixture_name="delete_project",
        endpoint="delete_project",
    ),
    ContractSpec(
        name="select_project",
        client_request_type=None,
        server_request_schema=ProjectSelectSchema,
        client_fields={"project_id"},
        fixture_name="select_project",
        endpoint="select_project",
    ),
    ContractSpec(
        name="upload_plan",
        client_request_type=None,
        server_request_schema=PlanUploadSchema,
        client_fields={"name", "plan_data"},
        fixture_name="upload_plan",
        endpoint="upload_plan",
    ),
    ContractSpec(
        name="create_workflow",
        client_request_type=None,
        server_request_schema=WorkflowCandidateSchema,
        client_fields={
            "workflow_id",
            "expected_revision_id",
            "create_fork",
            "title",
            "description",
            "domain_id",
            "workflow_run_count",
            "workflow_definition",
            "correlation",
        },
        fixture_name="create_workflow",
        endpoint="create_workflow",
    ),
    ContractSpec(
        name="validate_workflow_candidate",
        client_request_type=None,
        server_request_schema=WorkflowCandidateSchema,
        client_fields={
            "workflow_id",
            "expected_revision_id",
            "create_fork",
            "title",
            "description",
            "domain_id",
            "workflow_run_count",
            "workflow_definition",
            "correlation",
        },
        fixture_name="validate_workflow_candidate",
        endpoint="validate_workflow_candidate",
    ),
    ContractSpec(
        name="apply_workflow_candidate",
        client_request_type=None,
        server_request_schema=WorkflowCandidateSchema,
        client_fields={
            "workflow_id",
            "expected_revision_id",
            "create_fork",
            "title",
            "description",
            "domain_id",
            "workflow_run_count",
            "workflow_definition",
            "correlation",
        },
        fixture_name="apply_workflow_candidate",
        endpoint="apply_workflow_candidate",
    ),
    ContractSpec(
        name="check_runner_compatibility",
        client_request_type=None,
        server_request_schema=RunnerCompatibilityCheckSchema,
        client_fields={
            "runner_id",
            "runner_version",
            "runner_selector",
            "domain_id",
            "input_type",
            "stage_archetype",
            "workflow_capabilities",
            "artifact_roles",
            "available_executables",
            "available_packages",
        },
        fixture_name="check_runner_compatibility",
        endpoint="check_runner_compatibility",
    ),
    ContractSpec(
        name="cancel_session",
        client_request_type=None,
        server_request_schema=SessionMutationSchema,
        client_fields={"session_id"},
        fixture_name="cancel_session",
        endpoint="cancel_session",
    ),
    ContractSpec(
        name="repair_session",
        client_request_type=None,
        server_request_schema=SessionMutationSchema,
        client_fields={"session_id"},
        fixture_name="repair_session",
        endpoint="repair_session",
    ),
    ContractSpec(
        name="reset_review",
        client_request_type=None,
        server_request_schema=SessionMutationSchema,
        client_fields={"session_id"},
        fixture_name="reset_review",
        endpoint="reset_review",
    ),
    ContractSpec(
        name="force_complete_session",
        client_request_type=None,
        server_request_schema=ForceCompleteSessionSchema,
        client_fields={"session_id", "reason"},
        fixture_name="force_complete_session",
        endpoint="force_complete_session",
    ),
]


REQUEST_CONTRACTS: list[ContractSpec] = HYBRID_REQUEST_CONTRACTS + RESOURCE_REQUEST_CONTRACTS


ACTION_CONTRACTS: list[ActionContractSpec] = [
    ActionContractSpec(
        name="action_wait_payload",
        action_type=ActionType.WAIT.value,
        client_payload_type=WaitPayload,
        fixture_name="action_wait_payload",
        required_payload_fields={"status"},
    ),
    ActionContractSpec(
        name="action_intent_payload",
        action_type=ActionType.INTENT.value,
        client_payload_type=IntentRequest,
        fixture_name="action_intent_payload",
        required_payload_fields={"objective", "userplan_id", "userplan_version"},
    ),
    ActionContractSpec(
        name="action_derive_payload",
        action_type=ActionType.DERIVE.value,
        client_payload_type=DeriveRequest,
        fixture_name="action_derive_payload",
        required_payload_fields={"objective", "userplan_id", "userplan_version"},
    ),
    ActionContractSpec(
        name="action_examine_payload",
        action_type=ActionType.EXAMINE.value,
        client_payload_type=ExamineRequest,
        fixture_name="action_examine_payload",
        required_payload_fields={"plan_version_id", "plan_items"},
    ),
    ActionContractSpec(
        name="action_revise_payload",
        action_type=ActionType.REVISE.value,
        client_payload_type=RevisionRequest,
        fixture_name="action_revise_payload",
        required_payload_fields={
            "issues",
            "blocking_issues",
            "current_plan_version_id",
            "batch_index",
            "total_batches",
            "batches_remaining",
        },
    ),
    ActionContractSpec(
        name="action_execute_payload",
        action_type=ActionType.EXECUTE.value,
        client_payload_type=ExecutionRequest,
        fixture_name="action_execute_payload",
        required_payload_fields={"plan_items", "execution_index"},
    ),
    ActionContractSpec(
        name="action_story_preflight_payload",
        action_type=ActionType.STORY_PREFLIGHT.value,
        client_payload_type=StoryPreflightRequest,
        fixture_name="action_story_preflight_payload",
        required_payload_fields={"story_item", "plan_items"},
    ),
    ActionContractSpec(
        name="action_review_payload",
        action_type=ActionType.REVIEW.value,
        client_payload_type=ReviewRequest,
        fixture_name="action_review_payload",
        required_payload_fields={"item_id", "review_agents", "changed_files"},
        payload_field_aliases={"review_agents": "agents_to_run"},
    ),
    ActionContractSpec(
        name="action_pipeline_stage_payload",
        action_type=ActionType.PIPELINE_STAGE.value,
        client_payload_type=PipelineStageRequest,
        fixture_name="action_pipeline_stage_payload",
        required_payload_fields={
            "stage_name",
            "trigger",
            "input_type",
            "runner_id",
            "runner_version",
            "runner_kind",
            "stage_execution_id",
            "context",
        },
    ),
    ActionContractSpec(
        name="action_fix_payload",
        action_type=ActionType.FIX.value,
        client_payload_type=FixRequest,
        fixture_name="action_fix_payload",
        required_payload_fields={"item_id", "issues_to_fix", "issue_details", "fix_history"},
    ),
    ActionContractSpec(
        name="action_escalate_payload",
        action_type=ActionType.ESCALATE.value,
        client_payload_type=EscalationNotice,
        fixture_name="action_escalate_payload",
        required_payload_fields={"reason", "blocking_issues", "convergence_diagnostic"},
    ),
    ActionContractSpec(
        name="action_validator_payload",
        action_type=ActionType.VALIDATOR.value,
        client_payload_type=ValidatorRequest,
        fixture_name="action_validator_payload",
        required_payload_fields={
            "stage",
            "subject_type",
            "subject_payload",
            "prompt_id",
            "prompt_version",
            "compiled_prompt",
            "timeout_s",
            "config",
        },
        parse_kwargs={"schema_validation": False},
    ),
]


def ensure_server_imports() -> None:
    """Raise a clear error if server schemas are unavailable."""

    if _SERVER_IMPORT_ERROR is not None:
        raise RuntimeError(
            "Server schema imports unavailable. Run from repo root with "
            "functions/ available in PYTHONPATH."
        ) from _SERVER_IMPORT_ERROR


def client_field_names(spec: ContractSpec) -> set[str]:
    """Return client request field names for a contract spec."""

    if spec.client_fields:
        return set(spec.client_fields)
    if spec.client_request_type and is_dataclass(spec.client_request_type):
        return {field.name for field in fields(spec.client_request_type)}
    return set()


def apply_field_aliases(field_names: Iterable[str], aliases: dict[str, str] | None) -> set[str]:
    """Apply alias mapping to a field set."""

    names = set(field_names)
    if not aliases:
        return names
    for client_name, server_name in aliases.items():
        if client_name in names:
            names.add(server_name)
    return names
