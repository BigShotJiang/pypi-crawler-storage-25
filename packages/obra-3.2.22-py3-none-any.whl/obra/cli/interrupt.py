"""Interrupt management for Obra CLI.

Handles CTRL+C behavior: graceful shutdown on first press, force quit on second.
Provides helper functions for printing session resume and recovery hints.
"""

from __future__ import annotations

import os
import sys
import time
from typing import Any

import typer

from obra.core.interrupts import request_interrupt, should_defer_interrupts
from obra.display import console, glyphs, print_warning


class InterruptManager:
    """Manages CTRL+C interrupt state for Obra CLI sessions."""

    FORCE_QUIT_WINDOW_SECONDS: float = 3.0

    def __init__(self) -> None:
        self.last_time: float = 0.0
        self.count: int = 0
        self.total: int = 0
        self.session_id: str | None = None
        self.orchestrator: Any = None
        self.recovery_hint_printed: bool = False
        self.recovery_hint_session_id: str | None = None

    def reset(self) -> None:
        """Reset all interrupt counters and session state to defaults."""
        self.count = 0
        self.total = 0
        self.last_time = 0.0
        self.session_id = None
        self.orchestrator = None
        self.recovery_hint_printed = False
        self.recovery_hint_session_id = None

    def handle_interrupt(self, _sig: Any, _frame: Any) -> None:
        """Handle CTRL+C with graceful shutdown on first press, force quit on second.

        First Ctrl+C: Shows message that interrupt was received, will exit gracefully
        Second Ctrl+C within 3s: Force quits immediately (may lose session state)
        Third+ Ctrl+C (anytime): Force quits immediately (bypasses countdown)
        """
        current_time = time.time()

        # Track total interrupts (never resets - 3rd+ always force quits)
        self.total = self.total + 1

        # Reset window counter if enough time has passed since last interrupt
        if current_time - self.last_time > self.FORCE_QUIT_WINDOW_SECONDS:
            self.count = 0

        self.count = self.count + 1
        self.last_time = current_time

        # Force quit conditions (thresholds from config):
        # 1. Nth Ctrl+C within window (default: 2nd), OR
        # 2. Mth+ Ctrl+C total (default: 3rd) - bypasses countdown
        from obra.config.loaders import (
            get_cli_force_exit_threshold,
            get_cli_interrupt_threshold,
        )

        interrupt_threshold = get_cli_interrupt_threshold()
        force_exit_threshold = get_cli_force_exit_threshold()
        if self.count >= interrupt_threshold or self.total >= force_exit_threshold:
            import signal

            # Reset signal handler to default so the NEXT Ctrl+C kills immediately
            # via the OS (prevents re-entrant handler from blocking os._exit).
            signal.signal(signal.SIGINT, signal.SIG_DFL)

            # Suppress Rich/Typer exception rendering — the exit traceback
            # is garbled when SIGINT fires mid-render (e.g. during syntax
            # highlighting).  Restore the plain Python hook so Exit(130)
            # propagates quietly.
            sys.excepthook = sys.__excepthook__

            # Try a bounded graceful shutdown first, then hard-exit as fallback.
            console.print()
            print_warning("Force quit requested - attempting graceful shutdown...")
            _print_interrupt_resume_block(mark_as_printed=True)
            request_interrupt("sigint_force")
            if not should_defer_interrupts():
                raise typer.Exit(130)
            grace_deadline = time.time() + 1.5
            while time.time() < grace_deadline:
                if not should_defer_interrupts():
                    raise typer.Exit(130)
                time.sleep(0.05)
            print_warning("Force quitting... (session state may be lost)")
            # P0-2: Emit session_interrupted before os._exit (atexit won't fire)
            try:
                from obra.hybrid.orchestrator import emit_force_quit_terminal_event

                emit_force_quit_terminal_event()
            except Exception:
                pass  # Best-effort — must not block force-quit
            os._exit(130)
        else:
            # First Ctrl+C - graceful shutdown message
            console.print()
            print_warning("Interrupt received - finishing current operation...")
            console.print("[dim]Press Ctrl+C again to force quit (session state may be lost)[/dim]")
            console.print()
            _print_interrupt_resume_block(mark_as_printed=True)
            request_interrupt("sigint")
            if not should_defer_interrupts():
                raise typer.Exit(130)  # Standard SIGINT exit code
            return

    def install(self) -> None:
        """Register this manager as the SIGINT handler."""
        import signal

        signal.signal(signal.SIGINT, self.handle_interrupt)


# Module-level singleton — shared between handler and helper functions.
# _run_derive calls _manager.reset() and _manager.install() at session start.
_manager = InterruptManager()


def _print_bug_hint() -> None:
    """Print a hint to report bugs after errors."""
    console.print("[dim]Report this issue: obra bug 'description'[/dim]")


def _resolve_interrupt_session_id(session_id: str | None = None) -> str | None:
    """Resolve best-available session ID from explicit arg, interrupt state, or orchestrator."""
    sid = session_id or _manager.session_id
    if not sid or sid == "<pending>":
        orch = _manager.orchestrator
        if orch and hasattr(orch, "session_id"):
            sid = orch.session_id
    if not sid or sid == "<pending>":
        return None
    return str(sid)


def _print_interrupt_resume_block(
    session_id: str | None = None, *, mark_as_printed: bool = False
) -> None:
    """Print a compact Ctrl+C recovery block with resume/continue commands."""
    from obra.display.recovery_hints import build_interrupt_recovery_hints

    sid = _resolve_interrupt_session_id(session_id)

    console.print(glyphs.divider)
    for line in build_interrupt_recovery_hints(sid).splitlines():
        if line:
            console.print(f"[dim]{line}[/dim]")
        else:
            console.print()
    if mark_as_printed:
        _manager.recovery_hint_printed = True
        _manager.recovery_hint_session_id = sid


def _print_session_resume_hints(session_id: str | None = None) -> None:
    """Print session resume and continue hints after errors.

    This provides a consistent UX for recovering from session crashes/errors.
    Resolves session ID from: explicit arg → interrupt state → orchestrator.

    Args:
        session_id: Optional session ID to use. If None, resolves from state.
    """
    sid = _resolve_interrupt_session_id(session_id)
    if not sid:
        return

    short_id = str(sid).split("-")[0]
    console.print(glyphs.divider)
    console.print(
        f"[dim]Resume:   obra run --resume {short_id}  (pick up exactly where you left off)[/dim]"
    )
    console.print(
        f"[dim]Target:   obra run --resume {short_id} --from story-0|derivation|execution[/dim]"
    )
    console.print(
        f"[dim]Continue: obra run --continue-from {short_id}  "
        "(re-derive, skip completed; uses original objective)[/dim]"
    )


def _print_session_completion_footer(
    session_id: str | None = None,
    was_escalated: bool = False,
    items_completed: int = 0,
) -> None:
    """Print session completion footer with stats and next-step hints.

    Called after successful session completion (not just errors) to provide
    clear guidance on how to continue or review the work.

    Args:
        session_id: Session ID for resume/continue hints
        was_escalated: Whether the session was escalated (affects messaging)
        items_completed: Number of items completed (for context)
    """
    sid = _resolve_interrupt_session_id(session_id)
    if not sid:
        return

    short_id = str(sid).split("-")[0]
    console.print()
    console.print(glyphs.divider)

    if was_escalated:
        console.print("[bold]Session escalated - manual intervention needed[/bold]")
        console.print()
        console.print(f"[dim]Status:   obra status {short_id}[/dim]")
        console.print(f"[dim]Resume:   obra run --resume {short_id}[/dim]")
    elif items_completed == 0:
        console.print("[bold]Session ended with no items completed[/bold]")
        console.print()
        console.print(f"[dim]Status:   obra status {short_id}[/dim]")
        console.print(f"[dim]Retry:    obra run --continue-from {short_id}[/dim]")
    else:
        console.print(f"[bold]Session {short_id} complete[/bold]")
        console.print()
        console.print(f"[dim]Review:   obra status {short_id}[/dim]")
        console.print(f"[dim]Plan:     obra sessions plan {short_id}[/dim]")
        console.print(f"[dim]Continue: obra run --continue-from {short_id}[/dim]")
