# ruff: noqa: F401 — backward-compat re-export shim
"""Backward-compatibility shim.

Canonical location moved to obra.hybrid.interaction_mode.
This shim preserves the old import path for existing consumers.
"""

from obra.hybrid.interaction_mode import (
    InteractionMode,
    current_mode_is_interactive,
    get_current_mode,
    is_interactive,
    resolve_interaction_mode,
    restore_current_mode,
    set_current_mode,
)
