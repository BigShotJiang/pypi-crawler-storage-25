"""Heartbeat helpers for CLI run/derive flows."""

from __future__ import annotations

from typing import Any

_HEARTBEAT_NOISE_EVENTS = frozenset({"file_event", "llm_streaming"})
_HEARTBEAT_FORCE_WRITE_EVENTS = frozenset(
    {
        "epic_derivation_heartbeat",
        "item_heartbeat",
        "phase_started",
        "planning_stage_started",
        "stage_heartbeat",
        "stage_started",
    }
)
_STAGE_PHASE_HINTS = {
    "derive": "derivation",
    "examine": "refinement",
    "execute": "execution",
    "intent": "derivation",
    "review": "review",
    "revise": "refinement",
    "story0": "story0",
}


def _infer_heartbeat_phase(
    orchestrator: Any | None,
    action: str,
    payload: dict[str, Any],
) -> str | None:
    """Infer the freshest phase label for local session heartbeat updates."""
    if action == "phase_started":
        raw_phase = payload.get("phase")
        if isinstance(raw_phase, str) and raw_phase.strip():
            return raw_phase.strip().lower()

    current_phase = getattr(orchestrator, "_current_phase", None)
    current_value = getattr(current_phase, "value", current_phase)
    if isinstance(current_value, str) and current_value.strip():
        return current_value.strip().lower()

    raw_stage = payload.get("stage")
    if isinstance(raw_stage, str) and raw_stage.strip():
        stage_name = raw_stage.strip().lower().split("_pass_")[0]
        return _STAGE_PHASE_HINTS.get(stage_name, stage_name)

    return None


def _refresh_local_session_heartbeat(
    orchestrator: Any | None,
    action: str,
    payload: dict[str, Any],
) -> None:
    """Keep the local session heartbeat file fresh during long-running work."""
    if orchestrator is None or action in _HEARTBEAT_NOISE_EVENTS:
        return

    session_guard = getattr(orchestrator, "_session_guard", None)
    if session_guard is None:
        return

    invocation = getattr(orchestrator, "_invocation", None)
    items_completed = getattr(invocation, "items_completed_this_invocation", 0)
    try:
        completed_count = int(items_completed)
    except (TypeError, ValueError):
        completed_count = 0

    phase = _infer_heartbeat_phase(orchestrator, action, payload)
    session_guard.update(
        items_completed=completed_count,
        phase=phase,
        force_write=action in _HEARTBEAT_FORCE_WRITE_EVENTS,
    )
