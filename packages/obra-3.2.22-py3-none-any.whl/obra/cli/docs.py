"""Documentation and log viewer commands for the Obra CLI.

Extracted from obra/cli/_main.py as part of REFACTOR-CLI-SUBAPPS-001.
"""

from pathlib import Path

import typer

from obra.display import (
    console,
    err_console,
    handle_encoding_errors,
)
from obra.messages.warnings import build_deprecation_warning

# Create docs subcommand group
docs_app = typer.Typer(
    name="docs",
    help="Access local Obra documentation",
    invoke_without_command=True,
    rich_markup_mode="rich",
)

logs_app = typer.Typer(
    name="logs",
    help="Log tooling and local observability utilities",
    rich_markup_mode="rich",
)


def _docs_show_default() -> None:
    """Show default docs output with paths to documentation files."""
    package_root = Path(__file__).parent.parent
    readme_path = package_root / "README.md"
    llm_onboarding_path = package_root / ".obra" / "LLM_ONBOARDING.md"

    console.print()
    console.print("[bold]Obra Documentation (Local)[/bold]", style="cyan")
    console.print()
    console.print("[bold]Package Documentation:[/bold]")
    console.print(f"  README:           {readme_path}")
    console.print()
    console.print("[bold]LLM Operator Guide:[/bold]")
    console.print(f"  LLM_ONBOARDING:   {llm_onboarding_path}")
    console.print("  Quick access:     [cyan]obra docs llm[/cyan]")
    console.print()
    console.print("[dim]Use 'cat <path>' or your text editor to read these files.[/dim]")


def _docs_show_llm() -> None:
    """Show path to LLM_ONBOARDING.md for LLM operators."""
    package_root = Path(__file__).parent.parent
    llm_onboarding_path = package_root / ".obra" / "LLM_ONBOARDING.md"

    console.print()
    console.print("[bold]LLM Operator Guide[/bold]", style="cyan")
    console.print()
    console.print(f"Path: {llm_onboarding_path}")
    console.print()
    console.print("[dim]Use 'cat' or your text editor to read this file.[/dim]")
    console.print(
        "[dim]Recommended next commands: obra briefing quick, obra models, obra help domains, obra help run[/dim]"
    )


@docs_app.callback(invoke_without_command=True)
@handle_encoding_errors
def docs_callback(
    ctx: typer.Context,
    # Hidden alias for deprecated flag (S3.T3 - backwards compatibility)
    llm: bool = typer.Option(
        False,
        "--llm",
        hidden=True,
        help="[DEPRECATED] Use 'obra docs llm' instead",
    ),
) -> None:
    """Access local Obra documentation.

    Displays paths to documentation files shipped with the package.

    Subcommands:
        llm  - Show path to LLM operator guide

    Examples:
        obra docs           # Show all doc paths
        obra docs llm       # Show LLM operator guide path
    """
    # Handle deprecated --llm flag
    if llm:
        err_console.print(
            f"[yellow]{build_deprecation_warning('--llm', 'obra docs llm')}[/yellow]",
            style="yellow",
        )
        _docs_show_llm()
        return

    # If no subcommand was invoked, show default docs output
    if ctx.invoked_subcommand is None:
        _docs_show_default()


@logs_app.command("viewer")
@handle_encoding_errors
def logs_viewer(
    host: str = typer.Option(
        "127.0.0.1",
        "--host",
        help="Host to bind (use 0.0.0.0 for remote/headless access)",
    ),
    port: int = typer.Option(
        8844,
        "--port",
        help="Port to bind for the log viewer",
    ),
    log_path: Path | None = typer.Option(
        None,
        "--log-path",
        help="Override hybrid.jsonl log path",
    ),
    production_log_path: Path | None = typer.Option(
        None,
        "--production-log-path",
        help="Override production.jsonl log path",
    ),
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Skip auto-opening browser (for headless/remote servers)",
    ),
    stay_open: bool = typer.Option(
        False,
        "--stay-open",
        help="Keep server alive after browser disconnects (recommended for remote access)",
    ),
) -> None:
    """Launch the local log viewer (aggregates hybrid + production logs)."""
    from obra.observability.log_viewer.server import (
        default_hybrid_log_path,
        default_production_log_path,
        run_log_viewer,
    )

    run_log_viewer(
        host=host,
        port=port,
        hybrid_log_path=log_path or default_hybrid_log_path(),
        production_log_path=production_log_path or default_production_log_path(),
        open_browser=not no_browser,
        stay_open=stay_open,
    )


@docs_app.command(name="llm")
@handle_encoding_errors
def docs_llm() -> None:
    """Show path to LLM operator guide.

    Displays the path to LLM_ONBOARDING.md, which contains guidance
    for AI assistants using Obra.

    Examples:
        obra docs llm

    Exit Codes:
        0: Always (informational command)
    """
    _docs_show_llm()
