"""Sessions sub-app for the Obra CLI.

Extracted from obra/cli/_main.py (REFACTOR-CLI-SUBAPPS-001 S1.T0).
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

import typer
from rich.console import Console
from rich.table import Table

from obra.cli._error_handling import handle_command_error
from obra.cli._shared import _extract_plan_progress, require_authenticated_client
from obra.cli.lifecycle import (
    extract_lifecycle_status,
    format_lifecycle_capability_states,
)
from obra.display import (
    console,
    handle_encoding_errors,
    print_error,
    print_info,
    print_success,
)
from obra.exceptions import APIError
from obra.messages import get_message

logger = logging.getLogger(__name__)


def _execute_api_command(
    client_method: Callable[..., dict[str, Any]],
    args: tuple[Any, ...],
    success_msg: str,
    command_name: str,
    target_console: Console,
    *,
    kwargs: dict[str, Any] | None = None,
    on_success: Callable[[dict[str, Any]], None] | None = None,
) -> None:
    """Execute an API command with shared error and success/failure handling.

    Calls *client_method* with *args* and *kwargs*, checks
    ``response.get('success')``, prints *success_msg* on success (or delegates
    to *on_success* if provided), prints an error and raises
    ``typer.Exit(1)`` on failure.  The entire call is wrapped in a try/except
    that delegates to ``handle_command_error``.

    Args:
        client_method: Bound method on the API client (e.g. ``client.cancel_session``).
        args: Positional arguments forwarded to *client_method*.
        success_msg: Message printed via ``print_success`` on the happy path
            (ignored when *on_success* is provided).
        command_name: Human-readable command name for error logging.
        target_console: Rich console instance for output.
        kwargs: Optional keyword arguments forwarded to *client_method*.
        on_success: Optional callback receiving the successful response dict.
            When provided, *success_msg* is not printed automatically.
    """
    try:
        response = client_method(*args, **(kwargs or {}))

        if response.get("success"):
            if on_success is not None:
                on_success(response)
            else:
                print_success(success_msg)
                msg = response.get("message", "")
                if msg:
                    target_console.print(f"\n[dim]{msg}[/dim]")
        else:
            print_error(f"Failed to {command_name.replace('sessions ', '')}")
            target_console.print(
                f"\n[dim]{response.get('message', 'Unknown error occurred')}[/dim]"
            )
            raise typer.Exit(1)

    except Exception as e:
        handle_command_error(e, None, command_name, target_console)


sessions_app = typer.Typer(help="Manage derivation sessions")


@sessions_app.command("list")
@handle_encoding_errors
def sessions_list(
    limit: int = typer.Option(
        10,
        "--limit",
        "-n",
        help="Maximum number of sessions to list",
    ),
    status_filter: str | None = typer.Option(
        None,
        "--status",
        "-s",
        help="Filter by status (active, completed, expired)",
    ),
) -> None:
    """List recent derivation sessions.

    Displays all sessions for the current user, ordered by
    creation time (most recent first).

    Examples:
        $ obra sessions list
        $ obra sessions list --limit 20
        $ obra sessions list --status active
    """
    try:
        client = require_authenticated_client()
        sessions = client.list_sessions(limit=limit, status=status_filter)

        console.print()
        if not sessions:
            print_info("No sessions found")
            console.print('\nStart a new session with: [cyan]obra run "your objective"[/cyan]')
            return

        console.print(f"[bold]Recent Sessions[/bold] ({len(sessions)} shown)", style="cyan")
        console.print()

        table = Table()
        table.add_column("Session ID", style="cyan")
        table.add_column("Status", style="bold")
        table.add_column("Project")
        table.add_column("Project ID")
        table.add_column("Phase")
        table.add_column("Created", style="dim")

        for session in sessions:
            session_id_short = session.get("session_id", "")[:12] + "..."
            status = session.get("status", "unknown")
            phase = session.get("phase", "N/A")
            created_at = session.get("created_at", "N/A")
            project_name = session.get("project_name", "")
            project_id = str(session.get("project_id", ""))

            # Format timestamp if it's ISO format
            if "T" in str(created_at):
                from datetime import datetime

                try:
                    dt = datetime.fromisoformat(str(created_at).replace("Z", "+00:00"))
                    created_at = dt.strftime("%Y-%m-%d %H:%M")
                except (ValueError, TypeError):
                    pass

            # Color-code status
            if status == "active":
                status = f"[green]{status}[/green]"
            elif status == "completed":
                status = f"[blue]{status}[/blue]"
            elif status == "expired":
                status = f"[dim]{status}[/dim]"

            table.add_row(session_id_short, status, project_name, project_id, phase, created_at)

        console.print(table)
        console.print()
        console.print("[dim]Check details:[/dim] [cyan]obra status <session_id>[/cyan]")
        console.print("[dim]Resume:[/dim] [cyan]obra run --resume <session_id>[/cyan]")

    except Exception as e:
        handle_command_error(e, None, "sessions list", console)


@sessions_app.command("cancel")
@handle_encoding_errors
def sessions_cancel(
    session_id: str = typer.Argument(
        ...,
        help="Session ID to cancel",
    ),
) -> None:
    """Cancel a derivation session.

    Cancels a session by setting its status to 'abandoned'. This is useful for
    cleaning up sessions that are no longer needed or were started in error.

    Cancellation is idempotent - cancelling an already-cancelled session succeeds.

    Examples:
        $ obra sessions cancel abc123...
        $ obra sessions cancel $(obra sessions list --limit 1 | awk 'NR==4 {print $1}')

    Note:
        You can only cancel sessions you own. Attempting to cancel another
        user's session will result in a permission error.
    """
    client = require_authenticated_client()
    _execute_api_command(
        client.cancel_session,
        (session_id,),
        f"Session cancelled: {session_id}",
        "sessions cancel",
        console,
    )


@sessions_app.command("repair")
@handle_encoding_errors
def sessions_repair(
    session_id: str = typer.Argument(
        ...,
        help="Session ID to repair",
    ),
) -> None:
    """Repair a stuck session by auto-detecting and fixing common issues.

    Auto-detects and repairs common session issues without manual intervention.
    Safe to run multiple times - if no issues are found, no changes are made.

    Repairs Supported:
        - missing_item_id: Recovers missing item_id from execution results
        - stuck_wait_state: Advances phase when stuck in WAIT status
        - inconsistent_status: Reconciles status/phase mismatches

    Examples:
        $ obra sessions repair abc123
        $ obra sessions repair $(obra status --format json | jq -r '.session_id')

    Notes:
        - Safe to run multiple times (idempotent)
        - Only repairs sessions you own
        - Use after encountering 500 errors or stuck sessions
    """

    def _on_repair_success(response: dict[str, Any]) -> None:
        repairs_applied = response.get("repairs_applied", [])
        if repairs_applied:
            print_success(f"Session repaired: {session_id}")
            console.print(f"\n[bold]Repairs applied ({len(repairs_applied)}):[/bold]")
            for repair in repairs_applied:
                field = repair.get("field", "unknown")
                action = repair.get("action", "unknown")
                console.print(f"  \u2022 {field}: {action}")
        else:
            print_info(f"No issues found in session: {session_id}")
            console.print("\n[dim]Session state is consistent.[/dim]")

    client = require_authenticated_client()
    _execute_api_command(
        client.repair_session,
        (session_id,),
        f"Session repaired: {session_id}",
        "sessions repair",
        console,
        on_success=_on_repair_success,
    )


@sessions_app.command("force-complete")
@handle_encoding_errors
def sessions_force_complete(
    session_id: str = typer.Argument(
        ...,
        help="Session ID to force-complete",
    ),
    reason: str = typer.Option(
        None,
        "--reason",
        "-r",
        help="Reason for force completion (for audit trail)",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip confirmation prompt",
    ),
) -> None:
    """Force-complete a session regardless of current phase.

    Marks the session as COMPLETED and preserves all execution results.
    Use this for stuck sessions that have completed work but cannot progress.

    This command will prompt for confirmation if the session has incomplete work,
    unless --yes is specified.

    Examples:
        $ obra sessions force-complete abc123
        $ obra sessions force-complete abc123 --reason "LLM timeout, work complete"
        $ obra sessions force-complete abc123 --yes

    Notes:
        - Preserves all execution results
        - Only force-completes sessions you own
        - Use after work is complete but session cannot progress
    """
    try:
        client = require_authenticated_client()

        # Check for confirmation if not --yes
        if not yes:
            # Get session status first to check for incomplete work
            try:
                session_data = client.get_session(session_id)
            except APIError:
                # Session not found or access denied - let the force_complete call handle it
                session_data = None

            if session_data:
                phase = session_data.get("phase", "UNKNOWN")
                status = session_data.get("status", "UNKNOWN")

                # Check for incomplete work indicators
                incomplete_work = False
                if phase not in ["COMPLETED", "FORCE_COMPLETED"]:
                    incomplete_work = True

                if incomplete_work:
                    console.print(
                        f"\n[yellow]Warning:[/yellow] Session is in {phase} phase with status {status}"
                    )
                    console.print("This may indicate incomplete work.\n")

                    if not typer.confirm(
                        get_message("prompt.confirm.force_complete"), default=False
                    ):
                        print_info("Cancelled")
                        raise typer.Exit(0)

        def _on_force_complete_success(response: dict[str, Any]) -> None:
            print_success(f"Session force-completed: {session_id}")

            preserved_results = response.get("preserved_results", 0)
            console.print(f"\n[bold]Preserved results:[/bold] {preserved_results}")

            warnings = response.get("warnings", [])
            if warnings:
                console.print("\n[bold yellow]Warnings:[/bold yellow]")
                for warning in warnings:
                    console.print(f"  \u2022 {warning}")

            if reason:
                console.print(f"\n[dim]Reason: {reason}[/dim]")

        _execute_api_command(
            client.force_complete_session,
            (session_id,),
            f"Session force-completed: {session_id}",
            "sessions force-complete",
            console,
            kwargs={"reason": reason},
            on_success=_on_force_complete_success,
        )

    except Exception as e:
        handle_command_error(e, None, "sessions force-complete", console)


@sessions_app.command("reset-review")
@handle_encoding_errors
def sessions_reset_review(
    session_id: str = typer.Argument(
        ...,
        help="Session ID to reset review for",
    ),
) -> None:
    """Reset a session's review state and return to execution phase.

    Clears review results for the current item and resets the session phase
    to EXECUTION, allowing the item to be re-executed. Useful when review
    keeps failing or incorrect review results need to be discarded.

    Examples:
        $ obra sessions reset-review abc123
        $ obra sessions reset-review $(obra status --format json | jq -r '.session_id')

    Notes:
        - Only resets sessions in REVIEW or FIX phase
        - For sessions not in review, this is a no-op
        - Only affects sessions you own
    """

    def _on_reset_success(response: dict[str, Any]) -> None:
        item_id = response.get("item_id")
        if item_id:
            # Session was in review phase and was reset
            print_success(f"Review reset for item {item_id}")
            console.print(f"\n[bold]Session:[/bold] {session_id}")
            console.print(
                f"[bold]Previous phase:[/bold] {response.get('previous_phase', 'UNKNOWN')}"
            )
            console.print("\n[dim]Session is ready to re-execute the item.[/dim]")
        else:
            # Session not in review phase
            print_info(f"Session not in review phase: {session_id}")
            console.print("\n[dim]No reset needed - this session is not in item review/fix.[/dim]")
            console.print(f"[dim]Inspect lifecycle state with: obra status {session_id}[/dim]")

    client = require_authenticated_client()
    _execute_api_command(
        client.reset_review,
        (session_id,),
        f"Review reset for session: {session_id}",
        "sessions reset-review",
        console,
        on_success=_on_reset_success,
    )


@sessions_app.command("plan")
@handle_encoding_errors
def sessions_plan(
    session_id: str | None = typer.Argument(
        None,
        help="Session ID (full UUID or short prefix). Defaults to most recent session.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON (machine-readable format for LLM operators)",
    ),
) -> None:
    """View the DerivedPlan for a session.

    Displays the DerivedPlan items derived by Obra for a session, including
    the completion status of each task. This helps you understand
    what Obra planned to do and track progress.

    Status indicators:
        ✓  completed - Task finished successfully
        ⏳  in_progress - Task currently running
        ○  pending - Task not yet started
        ✗  failed - Task failed

    Examples:
        $ obra sessions plan                    # Show DerivedPlan for most recent session
        $ obra sessions plan abc123             # Use short session ID
        $ obra sessions plan abc123-def456...   # Use full session ID
        $ obra sessions plan --json             # JSON output for scripting
    """
    try:
        client = require_authenticated_client()

        # If no session ID provided, use most recent session
        if session_id is None:
            sessions = client.list_sessions(limit=1)
            if not sessions:
                if json_output:
                    import json

                    print(json.dumps({"error": "No sessions found", "plan_items": []}))
                else:
                    print_info("No sessions found")
                    console.print(
                        '\nStart a new session with: [cyan]obra run "your objective"[/cyan]'
                    )
                return
            session_id = sessions[0].get("session_id", "")
            if not json_output:
                console.print(f"[dim]Using most recent session: {session_id[:12]}...[/dim]")
                console.print()

        # Get plan from server
        plan_data = client.get_session_plan(session_id)
        session_data = client.get_session(session_id)

        plan_items, total_count, completed_count = _extract_plan_progress(plan_data)
        objective = plan_data.get("objective", "")
        full_session_id = plan_data.get("session_id", session_id)
        resume_context = (
            session_data.get("resume_context", {})
            if isinstance(session_data.get("resume_context"), dict)
            else {}
        )
        workflow_lifecycle = (
            resume_context.get("workflow_lifecycle")
            if isinstance(resume_context.get("workflow_lifecycle"), dict)
            else {}
        )
        lifecycle_decisions = (
            resume_context.get("lifecycle_decisions")
            if isinstance(resume_context.get("lifecycle_decisions"), dict)
            else {}
        )
        legacy_phase_normalization = (
            resume_context.get("legacy_phase_normalization")
            if isinstance(resume_context.get("legacy_phase_normalization"), dict)
            else {}
        )
        workflow_derivation_summary = (
            session_data.get("workflow_derivation_summary")
            if isinstance(session_data.get("workflow_derivation_summary"), dict)
            else {}
        )
        lifecycle_status = extract_lifecycle_status(
            workflow_lifecycle,
            lifecycle_decisions,
        )
        lifecycle_states_display = format_lifecycle_capability_states(workflow_lifecycle)

        # JSON output for LLM operators
        if json_output:
            import json

            from obra.execution.plan_tree import build_plan_tree_snapshot

            plan_tree = build_plan_tree_snapshot(plan_items, objective)
            output = {
                "session_id": full_session_id,
                "objective": objective,
                "total_count": total_count,
                "completed_count": completed_count,
                "plan_items": plan_items,
                "plan_tree": plan_tree,
            }
            if workflow_derivation_summary:
                output["workflow_derivation_summary"] = workflow_derivation_summary
            if workflow_lifecycle:
                output["workflow_lifecycle"] = workflow_lifecycle
            if lifecycle_decisions:
                output["lifecycle_decisions"] = lifecycle_decisions
            if legacy_phase_normalization:
                output["legacy_phase_normalization"] = legacy_phase_normalization
            print(json.dumps(output, indent=2))
            return

        console.print()

        if not plan_items:
            print_info("No DerivedPlan items found for this session")
            console.print(
                "\n[dim]The session may not have derived a DerivedPlan yet, or it uses direct execution.[/dim]"
            )
            return

        # Display header
        console.print("[bold cyan]DerivedPlan[/bold cyan]")
        if objective:
            console.print(f"[dim]Objective:[/dim] {objective}")
        console.print(f"[dim]Session:[/dim] {full_session_id[:12]}...")
        console.print(
            f"[dim]Progress:[/dim] {completed_count}/{total_count} DerivedPlan tasks completed"
        )
        if lifecycle_status["selected_path"]:
            console.print(f"[dim]Lifecycle path:[/dim] {lifecycle_status['selected_path']}")
        if lifecycle_states_display:
            console.print(f"[dim]Lifecycle:[/dim] {lifecycle_states_display}")
        if lifecycle_status["operator_review_pending"]:
            console.print("[dim]Operator review:[/dim] pending")
        elif workflow_derivation_summary:
            review_count = int(
                workflow_derivation_summary.get("pending_operator_review_count", 0) or 0
            )
            if review_count > 0:
                checkpoint_ids = workflow_derivation_summary.get(
                    "pending_operator_review_checkpoint_ids",
                    [],
                )
                checkpoint_display = ", ".join(
                    str(checkpoint_id)
                    for checkpoint_id in checkpoint_ids
                    if str(checkpoint_id).strip()
                )
                review_display = f"{review_count} pending"
                if checkpoint_display:
                    review_display += f" ({checkpoint_display})"
                console.print(f"[dim]Operator review:[/dim] {review_display}")
        console.print()

        from obra.display.plan_tree import render_plan_tree

        render_plan_tree(console, plan_items, objective)

    except Exception as e:
        handle_command_error(e, None, "sessions plan", console, include_bug_hint=False)
