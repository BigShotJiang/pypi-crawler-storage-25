"""Display helpers for UserPlan CLI commands."""

from __future__ import annotations

from typing import Any

from obra.display import console, print_info, print_success


def display_step_context(context: dict[str, Any], header: str) -> None:
    """Display step context in the existing formatted text layout."""
    console.print(f"[bold]{header}:[/bold]")

    deliverables = context.get("deliverables", [])
    if deliverables:
        console.print("  [cyan]Deliverables:[/cyan]")
        for item in deliverables:
            console.print(f"    - {item}")

    success_criteria = context.get("success_criteria")
    if success_criteria:
        console.print(f"  [cyan]Success Criteria:[/cyan] {success_criteria}")

    requirements = context.get("requirements", [])
    if requirements:
        console.print("  [cyan]Requirements:[/cyan]")
        for item in requirements:
            console.print(f"    - {item}")

    tech_stack = context.get("tech_stack", [])
    if tech_stack:
        console.print(f"  [cyan]Tech Stack:[/cyan] {', '.join(tech_stack)}")

    constraints = context.get("constraints", [])
    if constraints:
        console.print("  [cyan]Constraints:[/cyan]")
        for item in constraints:
            console.print(f"    - {item}")

    assumptions = context.get("assumptions", [])
    if assumptions:
        console.print("  [cyan]Assumptions:[/cyan]")
        for item in assumptions:
            console.print(f"    - {item}")


def emit_machine_output(entries: dict[str, str]) -> None:
    """Emit the existing machine-parseable output block."""
    console.print()
    console.print("[dim]-- LLM-parseable output --[/dim]")
    for key, value in entries.items():
        console.print(f"{key}={value}")
    console.print()


def render_step_context_update(
    *,
    userplan_id: str,
    step_index: int,
    context: dict[str, Any],
) -> None:
    """Render the text output for a successful step-context update."""
    console.print()
    print_success(f"Updated context for step {step_index}")
    console.print()
    display_step_context(context, "Updated context")
    emit_machine_output(
        {
            "STEP_INDEX": str(step_index),
            "USERPLAN_ID": userplan_id,
            "CONTEXT_UPDATED": "true",
            "FIELDS_UPDATED": ",".join(context.keys()),
        }
    )


def render_step_context_view(
    *,
    userplan_id: str,
    step_index: int,
    step_title: str,
    step_context: dict[str, Any],
) -> None:
    """Render the text output for viewing a step context."""
    console.print()
    console.print(f"[bold cyan]Context for Step {step_index}: {step_title}[/bold cyan]")
    console.print("=" * 60)
    console.print()

    if not step_context:
        console.print("[dim]No context set for this step.[/dim]")
        console.print()
        console.print("Set context with options like:")
        console.print(
            f'  [cyan]obra userplan step context {userplan_id} {step_index} --deliverables "item1,item2"[/cyan]'
        )
    else:
        display_step_context(step_context, "Current context")

    emit_machine_output(
        {
            "STEP_INDEX": str(step_index),
            "STEP_TITLE": step_title,
            "USERPLAN_ID": userplan_id,
            "HAS_CONTEXT": "true" if step_context else "false",
        }
    )


def render_rederive_summary(
    *,
    userplan_id: str,
    total_steps: int,
    steps_to_rederive: list[int],
    start_step: int,
    steps: list[dict[str, Any]],
    from_step: int | None,
    verbose: int,
    cascaded_steps: list[int],
) -> None:
    """Render the existing text summary for re-derive."""
    console.print()
    print_success("Re-derivation queued successfully")
    console.print()

    console.print("[bold]Re-derivation Summary:[/bold]")
    console.print(f"  [cyan]UserPlan:[/cyan] {userplan_id}")
    console.print(f"  [cyan]Total Steps:[/cyan] {total_steps}")
    console.print(f"  [cyan]Steps to Re-derive:[/cyan] {len(steps_to_rederive)}")
    if from_step is not None and from_step > 1:
        console.print(f"  [cyan]Preserved Steps:[/cyan] 1 to {from_step - 1}")
    console.print(f"  [cyan]Re-derive Range:[/cyan] {start_step} to {total_steps}")
    if cascaded_steps:
        console.print(f"  [cyan]Cascaded (STALE):[/cyan] {cascaded_steps}")
    console.print()

    console.print("[bold]Steps queued for re-derivation:[/bold]")
    for step in steps:
        step_index = step.get("index", 0)
        step_title = step.get("title", "Untitled")
        if step_index in steps_to_rederive:
            console.print(f"  [yellow]>[/yellow] {step_index}. {step_title}")
        elif verbose >= 1:
            console.print(f"  [dim]-[/dim] {step_index}. {step_title} [dim](preserved)[/dim]")
    console.print()

    emit_machine_output(
        {
            "USERPLAN_ID": userplan_id,
            "REDERIVE_FROM_STEP": str(start_step),
            "REDERIVE_STEPS_COUNT": str(len(steps_to_rederive)),
            "REDERIVE_STEP_INDICES": ",".join(map(str, steps_to_rederive)),
            "TOTAL_STEPS": str(total_steps),
            "REDERIVE_STATUS": "queued",
        }
    )

    console.print("Next steps:")
    console.print(
        f"  [cyan]obra derive --userplan {userplan_id}[/cyan] - "
        "Run derivation to generate execution plan"
    )
    if from_step is not None:
        console.print(
            f"  [cyan]obra derive --userplan {userplan_id} --from-step {from_step}[/cyan] - "
            "Derive from specified step"
        )
    console.print()


def render_clarify_result(result: Any, *, verbose: int) -> None:
    """Render clarification loop text output."""
    console.print("[bold cyan]Clarification Results[/bold cyan]")
    console.print("=" * 60)
    console.print()

    console.print(f"[bold]UserPlan:[/bold]       {result.userplan_id}")
    console.print(f"[bold]Initial Quality:[/bold] {result.initial_quality:.2%}")
    console.print(f"[bold]Final Quality:[/bold]   {result.final_quality:.2%}")
    console.print(f"[bold]Improvement:[/bold]     {result.total_improvement:+.2%}")
    console.print(f"[bold]Iterations:[/bold]      {result.iterations_run}")
    console.print(f"[bold]Termination:[/bold]     {result.final_terminal_reason.value}")
    console.print()

    if verbose >= 1 and result.iterations:
        console.print("[bold]Iteration Details:[/bold]")
        console.print("-" * 40)
        for iteration in result.iterations:
            console.print(
                f"  Iteration {iteration.iteration}: "
                f"{iteration.quality_before:.2%} -> {iteration.quality_after:.2%} "
                f"(delta: {iteration.quality_delta:+.3f})"
            )
            if verbose >= 2 and iteration.fields_improved:
                for fb in iteration.fields_improved[:5]:
                    console.print(f"    [yellow]{fb.field}[/yellow]: {fb.issue.value}")
                    if verbose >= 3:
                        console.print(f"      {fb.description}")
                        console.print(f"      [dim]Suggestion: {fb.suggestion}[/dim]")
            if iteration.terminal:
                reason = iteration.terminal_reason.value if iteration.terminal_reason else "unknown"
                console.print(f"    [dim]Terminal: {reason}[/dim]")
        console.print()

    if result.total_improvement > 0.01:
        print_success(
            f"Quality improved by {result.total_improvement:.1%} "
            f"in {result.iterations_run} iteration(s)"
        )
    elif result.iterations_run == 0:
        print_info("No clarification needed - quality already at target")
    else:
        print_info(f"Clarification complete ({result.final_terminal_reason.value})")
    console.print()

    emit_machine_output(
        {
            "USERPLAN_ID": result.userplan_id,
            "INITIAL_QUALITY": f"{result.initial_quality:.4f}",
            "FINAL_QUALITY": f"{result.final_quality:.4f}",
            "IMPROVEMENT": f"{result.total_improvement:.4f}",
            "ITERATIONS": str(result.iterations_run),
            "TERMINAL_REASON": result.final_terminal_reason.value,
            "FIELDS_IMPROVED": str(result.fields_improved_count),
        }
    )
