"""Quality and workflow UserPlan CLI command handlers."""

from __future__ import annotations

import logging

import typer

from obra.cli.userplan_display import render_clarify_result, render_rederive_summary
from obra.cli.userplan_shared import build_json_formatter, get_api_client, output_json_error
from obra.cli.userplan_support import build_rederive_step_range
from obra.display import console, handle_encoding_errors, print_error, print_info
from obra.display.errors import display_error, display_obra_error
from obra.exceptions import APIError, ConfigurationError, ObraError

logger = logging.getLogger(__name__)


@handle_encoding_errors
def userplan_rederive(
    ctx: typer.Context,
    userplan_id: str = typer.Argument(..., help="UserPlan ID to re-derive"),
    from_step: int | None = typer.Option(
        None,
        "--from-step",
        min=1,
        help="Re-derive from step N onwards (1-indexed). Steps 1 to N-1 retain existing derivation.",
    ),
    force: bool = typer.Option(
        False, "--force", help="Force re-derivation even if quality gate fails"
    ),
    cascade: bool = typer.Option(
        False,
        "--cascade",
        help="Mark sibling steps after the re-derived step as STALE for staleness propagation",
    ),
    verbose: int = typer.Option(
        0, "--verbose", "-v", count=True, max=3, help="Verbosity level (0-3, use -v/-vv/-vvv)"
    ),
    format_output: str = typer.Option("text", "--format", "-f", help="Output format: text, json"),
) -> None:
    """Re-derive execution plan for a UserPlan."""
    from obra.cli._shared import _resolve_command_verbosity, setup_logging
    from obra.schemas.userplan_schema import DerivationStatus

    del force
    verbose = _resolve_command_verbosity(ctx, verbose)
    setup_logging(verbose)

    try:
        client = get_api_client()

        if format_output != "json":
            console.print()
            print_info(f"Fetching UserPlan: {userplan_id}")

        userplan = client.get_userplan(userplan_id)
        if not userplan:
            if format_output == "json":
                output_json_error(f"UserPlan not found: {userplan_id}", "NOT_FOUND")
                raise typer.Exit(1)
            console.print()
            print_error(f"UserPlan not found: {userplan_id}")
            console.print()
            raise typer.Exit(1)

        steps = userplan.get("steps", [])
        total_steps = len(steps)
        if total_steps == 0:
            if format_output == "json":
                output_json_error(f"UserPlan {userplan_id} has no steps to re-derive", "NO_STEPS")
                raise typer.Exit(1)
            console.print()
            print_error(f"UserPlan {userplan_id} has no steps to re-derive")
            console.print()
            raise typer.Exit(1)

        if from_step is not None and from_step > total_steps:
            if format_output == "json":
                output_json_error(
                    f"--from-step {from_step} exceeds total steps ({total_steps})",
                    "OUT_OF_RANGE",
                )
                raise typer.Exit(1)
            console.print()
            print_error(f"--from-step {from_step} exceeds total steps ({total_steps})")
            console.print()
            raise typer.Exit(1)

        start_step, steps_to_rederive = build_rederive_step_range(
            total_steps=total_steps,
            from_step=from_step,
        )

        console.print()
        if from_step is not None:
            print_info(
                f"Re-deriving steps {start_step} to {total_steps} ({len(steps_to_rederive)} steps)"
            )
            if start_step > 1:
                console.print(
                    f"  [dim]Steps 1 to {start_step - 1} will retain existing derivation[/dim]"
                )
        else:
            print_info(f"Re-deriving all {total_steps} steps")

        console.print()
        print_info("Marking steps as DERIVING...")

        try:
            client.update_userplan_steps_status_batch(
                userplan_id=userplan_id,
                step_indices=steps_to_rederive,
                derivation_status=DerivationStatus.DERIVING.value,
            )
            if verbose >= 1:
                console.print(f"  [dim]Marked steps {steps_to_rederive} as DERIVING[/dim]")
        except APIError as exc:
            console.print()
            print_error(f"Failed to mark steps as DERIVING: {exc}")
            console.print()
            raise typer.Exit(1) from exc

        cascaded_steps: list[int] = []
        if cascade and from_step is not None and from_step > 1:
            pass

        if format_output == "json":
            formatter = build_json_formatter()
            formatter.output_success(
                data={
                    "rederive_status": "queued",
                    "total_steps": total_steps,
                    "steps_to_rederive": len(steps_to_rederive),
                    "step_indices": steps_to_rederive,
                    "from_step": start_step,
                    "preserved_steps": list(range(1, start_step)) if start_step > 1 else [],
                    "cascaded_steps": cascaded_steps,
                },
                ids={"userplan_id": userplan_id},
            )
            return

        render_rederive_summary(
            userplan_id=userplan_id,
            total_steps=total_steps,
            steps_to_rederive=steps_to_rederive,
            start_step=start_step,
            steps=steps,
            from_step=from_step,
            verbose=verbose,
            cascaded_steps=cascaded_steps,
        )

    except typer.Exit:
        raise
    except APIError as exc:
        if format_output == "json":
            output_json_error(str(exc), "API_ERROR")
            raise typer.Exit(1) from exc
        console.print()
        display_error(exc, console)
        logger.error("API error in userplan rederive command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ConfigurationError as exc:
        if format_output == "json":
            output_json_error(str(exc), "CONFIG_ERROR")
            raise typer.Exit(1) from exc
        console.print()
        display_error(exc, console)
        logger.error("Configuration error in userplan rederive command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ObraError as exc:
        if format_output == "json":
            output_json_error(str(exc), "OBRA_ERROR")
            raise typer.Exit(1) from exc
        console.print()
        display_obra_error(exc, console)
        logger.error("Obra error in userplan rederive command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except Exception as exc:
        if format_output == "json":
            output_json_error(str(exc), "UNKNOWN_ERROR")
            raise typer.Exit(1) from exc
        console.print()
        display_error(exc, console)
        logger.exception("Unexpected error in userplan rederive command: %s", exc)
        raise typer.Exit(1) from exc


@handle_encoding_errors
def userplan_clarify(
    ctx: typer.Context,
    userplan_id: str = typer.Argument(..., help="UserPlan ID to clarify"),
    max_iterations: int | None = typer.Option(
        None,
        "--max-iterations",
        "-n",
        help="Maximum clarification iterations (default: from config, usually 3)",
    ),
    target_quality: float | None = typer.Option(
        None,
        "--target",
        "-t",
        help="Target quality score (0.0-1.0, default: 0.8)",
    ),
    verbose: int = typer.Option(
        0, "--verbose", "-v", count=True, max=3, help="Verbosity level (0-3, use -v/-vv/-vvv)"
    ),
    format_output: str = typer.Option("text", "--format", "-f", help="Output format: text, json"),
) -> None:
    """Run clarification loop to refine UserPlan quality."""
    from obra.cli._shared import _resolve_command_verbosity, setup_logging
    from obra.hybrid.quality.clarification import ClarificationLoop
    from obra.schemas.userplan_schema import UserPlan

    verbose = _resolve_command_verbosity(ctx, verbose)
    setup_logging(verbose)

    try:
        client = get_api_client()

        if format_output != "json":
            console.print()
            print_info(f"Fetching UserPlan: {userplan_id}")

        userplan_data = client.get_userplan(userplan_id)
        if not userplan_data:
            if format_output == "json":
                output_json_error(f"UserPlan not found: {userplan_id}", "NOT_FOUND")
                raise typer.Exit(1)
            console.print()
            print_error(f"UserPlan not found: {userplan_id}")
            raise typer.Exit(1)

        try:
            userplan = UserPlan(**userplan_data)
        except typer.Exit:
            raise
        except Exception as exc:
            if format_output == "json":
                output_json_error(f"Invalid UserPlan data: {exc}", "PARSE_ERROR")
                raise typer.Exit(1) from exc
            console.print()
            print_error(f"Failed to parse UserPlan: {exc}")
            raise typer.Exit(1) from exc

        if max_iterations is not None and target_quality is not None:
            clarification_loop = ClarificationLoop(
                max_iterations=max_iterations,
                target_quality=target_quality,
            )
        elif max_iterations is not None:
            clarification_loop = ClarificationLoop(max_iterations=max_iterations)
        elif target_quality is not None:
            clarification_loop = ClarificationLoop(target_quality=target_quality)
        else:
            clarification_loop = ClarificationLoop()

        if format_output != "json":
            console.print()
            print_info("Running clarification loop...")
            console.print()
            console.print(
                f"[dim]Config: max_iterations={clarification_loop.max_iterations}, "
                f"target_quality={clarification_loop.target_quality:.2f}, "
                f"delta_threshold={clarification_loop.quality_delta_threshold}[/dim]"
            )
            console.print()

        result = clarification_loop.run(userplan)

        if format_output == "json":
            formatter = build_json_formatter()
            formatter.output_success(
                data={
                    "clarification_result": {
                        "userplan_id": result.userplan_id,
                        "initial_quality": result.initial_quality,
                        "final_quality": result.final_quality,
                        "total_improvement": result.total_improvement,
                        "iterations_run": result.iterations_run,
                        "terminal_reason": result.final_terminal_reason.value,
                        "fields_improved_count": result.fields_improved_count,
                        "fields_auto_filled": result.fields_auto_filled,
                        "iterations": [
                            {
                                "iteration": fb.iteration,
                                "quality_before": fb.quality_before,
                                "quality_after": fb.quality_after,
                                "quality_delta": fb.quality_delta,
                                "terminal": fb.terminal,
                                "terminal_reason": (
                                    fb.terminal_reason.value if fb.terminal_reason else None
                                ),
                                "fields_improved": [
                                    {
                                        "field": field.field,
                                        "issue": field.issue.value,
                                        "description": field.description,
                                        "suggestion": field.suggestion,
                                        "resolved": field.resolved,
                                        "step_id": field.step_id,
                                    }
                                    for field in fb.fields_improved
                                ],
                            }
                            for fb in result.iterations
                        ],
                    }
                },
                ids={"userplan_id": result.userplan_id},
            )
            return

        render_clarify_result(result, verbose=verbose)

    except typer.Exit:
        raise
    except APIError as exc:
        if format_output == "json":
            output_json_error(str(exc), "API_ERROR")
            raise typer.Exit(1) from exc
        console.print()
        display_error(exc, console)
        logger.error("API error in userplan clarify command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ConfigurationError as exc:
        if format_output == "json":
            output_json_error(str(exc), "CONFIG_ERROR")
            raise typer.Exit(1) from exc
        console.print()
        display_error(exc, console)
        logger.error("Configuration error in userplan clarify command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ObraError as exc:
        if format_output == "json":
            output_json_error(str(exc), "OBRA_ERROR")
            raise typer.Exit(1) from exc
        console.print()
        display_obra_error(exc, console)
        logger.error("Obra error in userplan clarify command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except Exception as exc:
        if format_output == "json":
            output_json_error(str(exc), "UNKNOWN_ERROR")
            raise typer.Exit(1) from exc
        console.print()
        display_error(exc, console)
        logger.exception("Unexpected error in userplan clarify command: %s", exc)
        raise typer.Exit(1) from exc
