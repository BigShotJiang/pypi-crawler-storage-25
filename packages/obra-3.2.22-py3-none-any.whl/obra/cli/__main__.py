"""Module entry point for ``python -m obra.cli``."""

from __future__ import annotations

from obra.cli import main

if __name__ == "__main__":
    main()
