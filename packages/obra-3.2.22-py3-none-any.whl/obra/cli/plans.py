"""Plans sub-app for the Obra CLI.

Extracted from obra/cli/_main.py (REFACTOR-CLI-SUBAPPS-001 S1.T2).
"""

import logging
import sys
from pathlib import Path

import typer
from rich.table import Table

from obra.cli._shared import require_authenticated_client
from obra.cli_commands import UploadPlanCommand
from obra.display import console, handle_encoding_errors, print_error, print_info, print_success
from obra.display.errors import display_error, display_obra_error
from obra.exceptions import APIError, ConfigurationError, ObraError

logger = logging.getLogger(__name__)

plans_app = typer.Typer(
    name="plans",
    help="Manage uploaded DerivedPlan files. DerivedPlan only. Use `obra userplan` for UserPlans.",
    no_args_is_help=True,
)


@plans_app.command("list")
@handle_encoding_errors
def plans_list(
    limit: int = typer.Option(
        50,
        "--limit",
        "-n",
        help="Maximum number of DerivedPlans to list (max: 100)",
    ),
) -> None:
    """List uploaded DerivedPlan files.

    Displays all DerivedPlans uploaded by the current user, ordered by
    creation time (most recent first).

    Examples:
        $ obra plans list
        $ obra plans list --limit 10
    """
    try:
        client = require_authenticated_client()
        plans = client.list_plans(limit=limit)

        console.print()
        if not plans:
            print_info("No DerivedPlans uploaded")
            console.print(
                "\nUpload a DerivedPlan with: [cyan]obra plans upload path/to/plan.yaml[/cyan]"
            )
            return

        console.print(f"[bold]Uploaded DerivedPlans[/bold] ({len(plans)} total)", style="cyan")
        console.print()

        table = Table()
        table.add_column("DerivedPlan ID", style="cyan")
        table.add_column("Name", style="bold")
        table.add_column("Stories", justify="right")
        table.add_column("Uploaded", style="dim")

        for plan in plans:
            plan_id_short = plan.get("plan_id", "")[:8] + "..."
            name = plan.get("name", "N/A")
            story_count = str(plan.get("story_count", 0))
            created_at = plan.get("created_at", "N/A")

            # Format timestamp if it's ISO format
            if "T" in created_at:
                from datetime import datetime

                try:
                    dt = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
                    created_at = dt.strftime("%Y-%m-%d %H:%M")
                except (ValueError, TypeError):
                    # Invalid timestamp format, use as-is
                    pass

            table.add_row(plan_id_short, name, story_count, created_at)

        console.print(table)
        console.print()
        console.print('[dim]Use with:[/dim] [cyan]obra run --plan-id <plan_id> "objective"[/cyan]')

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in plans list command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in plans list command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in plans list command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in plans list command: {e}")
        raise typer.Exit(1) from e


@plans_app.command("show")
@handle_encoding_errors
def plans_show(
    plan_id: str = typer.Argument(..., help="DerivedPlan ID to display"),
) -> None:
    """Display details of an uploaded DerivedPlan file.

    Shows complete information about a DerivedPlan including:
    - DerivedPlan metadata (name, work_id, description)
    - Story list with titles and status
    - Task count per story

    Examples:
        $ obra plans show abc123
        $ obra plans show abc12345-6789-...
    """
    try:
        client = require_authenticated_client()
        plan = client.get_plan(plan_id)

        if not plan:
            print_error(f"DerivedPlan not found: {plan_id}")
            raise typer.Exit(1)

        console.print()
        console.print("[bold cyan]DerivedPlan Details[/bold cyan]")
        console.print("=" * 60)
        console.print()

        # Basic info
        console.print(f"[bold]DerivedPlan ID:[/bold]   {plan.get('plan_id', 'N/A')}")
        console.print(f"[bold]Name:[/bold]      {plan.get('name', 'N/A')}")
        console.print(f"[bold]Work ID:[/bold]   {plan.get('work_id', 'N/A')}")

        # Format and display creation time
        created_at = plan.get("created_at", "N/A")
        if "T" in str(created_at):
            from datetime import datetime

            try:
                dt = datetime.fromisoformat(str(created_at).replace("Z", "+00:00"))
                created_at = dt.strftime("%Y-%m-%d %H:%M:%S UTC")
            except (ValueError, TypeError):
                pass
        console.print(f"[bold]Uploaded:[/bold]  {created_at}")

        # Description if present
        if plan.get("description"):
            console.print("[bold]Description:[/bold]")
            console.print(f"  {plan.get('description')}")

        # Epics and stories
        epics = plan.get("epics", [])
        if epics:
            console.print()
            console.print(f"[bold]Epics[/bold] ({len(epics)} total)")
            console.print("-" * 40)

            story_table = Table(show_header=True, header_style="bold")
            story_table.add_column("Epic", style="cyan")
            story_table.add_column("Story")
            story_table.add_column("Status", style="dim")
            story_table.add_column("Tasks", justify="right")

            for epic in epics:
                epic_id = epic.get("id", "?")
                epic_stories = epic.get("stories", [])
                if not isinstance(epic_stories, list):
                    continue
                for story in epic_stories:
                    story_id = story.get("id", "?")
                    title = story.get("title", "Untitled")
                    status = story.get("status", "pending")
                    task_count = len(story.get("tasks", []))
                    story_table.add_row(epic_id, f"{story_id}: {title}", status, str(task_count))

            console.print(story_table)

        console.print()
        console.print(
            f'[dim]Use with:[/dim] [cyan]obra --plan-id {plan_id[:8]}... "your objective"[/cyan]'
        )

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in plans show command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in plans show command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in plans show command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in plans show command: {e}")
        raise typer.Exit(1) from e


@plans_app.command("delete")
@handle_encoding_errors
def plans_delete(
    plan_id: str = typer.Argument(..., help="DerivedPlan ID to delete"),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Skip confirmation prompt",
    ),
) -> None:
    """Delete an uploaded DerivedPlan file.

    Permanently removes the DerivedPlan from the server. This cannot be undone.
    Existing sessions using this DerivedPlan are not affected.

    Examples:
        $ obra plans delete abc123-uuid
        $ obra plans delete abc123-uuid --force
    """
    try:
        client = require_authenticated_client()

        console.print()
        console.print("[dim]Fetching DerivedPlan details...[/dim]")

        try:
            plan = client.get_plan(plan_id)
            plan_name = plan.get("name", "Unknown")
            story_count = plan.get("story_count", 0)

            console.print()
            console.print("[bold]DerivedPlan Details[/bold]", style="yellow")
            console.print(f"ID: {plan_id}")
            console.print(f"Name: {plan_name}")
            console.print(f"Stories: {story_count}")
            console.print()

        except (APIError, ObraError) as e:
            # Plan not found or error fetching - proceed with deletion anyway
            logger.warning(f"Could not fetch plan details: {e}")
            plan_name = "Unknown"

        # Confirm deletion
        if not force:
            # C14: Check for non-interactive mode before prompting
            if not sys.stdin.isatty():
                # Non-interactive mode: default to not deleting (safe default)
                console.print(
                    "Non-interactive mode: skipping deletion confirmation (defaulting to cancel)"
                )
                console.print("Use --force to delete without confirmation")
                return

            confirm = typer.confirm(
                f"Are you sure you want to delete DerivedPlan '{plan_name}'?",
                default=False,
            )
            if not confirm:
                console.print("Cancelled")
                return

        # Delete plan
        console.print("[dim]Deleting DerivedPlan...[/dim]")
        result = client.delete_plan(plan_id)

        if result.get("success"):
            console.print()
            print_success(f"DerivedPlan deleted: {plan_name}")
        else:
            print_error("Failed to delete DerivedPlan")
            raise typer.Exit(1)

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in plans delete command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in plans delete command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in plans delete command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in plans delete command: {e}")
        raise typer.Exit(1) from e


@plans_app.command("upload")
@handle_encoding_errors
def plans_upload(
    file_path: Path = typer.Argument(
        ..., help="Path to DerivedPlan MACHINE_PLAN file (JSON or YAML) to upload"
    ),
    validate_only: bool = typer.Option(
        False,
        "--validate-only",
        help="Only validate the plan file without uploading",
    ),
) -> None:
    """Upload a DerivedPlan MACHINE_PLAN file (JSON or YAML) to Obra SaaS.

    Validates and uploads a DerivedPlan file to Firestore for later use.
    After upload, use the returned plan_id with 'obra run --plan-id'.

    Examples:
        $ obra plans upload docs/development/MY_PLAN.yaml
        $ obra plans upload --validate-only plan.yaml

    Exit Codes:
        0: Upload successful or validation passed
        1: Upload failed or validation failed
    """
    try:
        command = UploadPlanCommand()
        exit_code = command.execute(str(file_path), validate_only)

        if exit_code != 0:
            raise typer.Exit(exit_code)

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in plans upload command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in plans upload command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in plans upload command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except OSError as e:
        print_error(f"Failed to read plan file: {e}")
        logger.error(f"File I/O error in plans upload command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in plans upload command: {e}")
        raise typer.Exit(1) from e


# NOTE: 'plans validate' command removed - use 'dobra plan validate' instead
# Plan validation is a local operation, not a SaaS operation.
# See CHORE-DOBRA-CLI-001 for migration details.
