"""Telemetry CLI commands extracted from obra.cli.feedback."""

from __future__ import annotations

import typer

from obra.cli.feedback_shared import _load_feedback_config, _save_feedback_consent
from obra.display import console, glyphs, handle_encoding_errors, print_error, print_success

telemetry_app = typer.Typer(
    name="telemetry",
    help="Manage telemetry and feedback data collection",
    rich_markup_mode="rich",
)


def telemetry_enable() -> None:
    """Enable telemetry and feedback data collection.

    Grants consent for Obra to collect diagnostic data when you submit
    bug reports or feedback. Data is used to improve Obra and prioritize fixes.

    You can revoke consent at any time with: obra telemetry disable

    Example:
        obra telemetry enable
    """
    try:
        _save_feedback_consent(True)
        print_success(f"{glyphs.success} Telemetry enabled")
        console.print()
        console.print("Thank you for helping improve Obra!")
        console.print(
            "Data will be collected when you submit feedback with: obra feedback bug/feature/comment"
        )
        console.print()
        console.print("To see what data is collected: obra telemetry explain")
        console.print("To disable: obra telemetry disable")
    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Failed to enable telemetry: {e}")
        raise typer.Exit(1) from e


def telemetry_disable() -> None:
    """Disable telemetry and feedback data collection.

    Revokes consent for data collection. Bug reports and feedback submissions
    will be blocked until you re-enable telemetry.

    Example:
        obra telemetry disable
    """
    try:
        _save_feedback_consent(False)
        print_success(f"{glyphs.success} Telemetry disabled")
        console.print()
        console.print("Data collection has been disabled.")
        console.print("Note: Feedback submission will be blocked until you re-enable telemetry.")
        console.print()
        console.print("To re-enable: obra telemetry enable")
    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Failed to disable telemetry: {e}")
        raise typer.Exit(1) from e


def telemetry_status() -> None:
    """Show current telemetry consent status and data collection settings.

    Displays:
    - Whether telemetry is enabled or disabled
    - What data is currently being collected
    - How to change settings

    Example:
        obra telemetry status
    """
    try:
        config = _load_feedback_config()
        consent = config.get("telemetry_consent")
        data_level = config.get("data_level", "minimal")

        console.print()
        console.print("[bold]Telemetry Status[/bold]")
        console.print()

        # Consent status
        if consent is None:
            console.print("Status: [yellow]Not configured[/yellow]")
            console.print("You have not yet been asked for consent.")
            console.print()
            console.print("To enable: obra telemetry enable")
            console.print("To disable: obra telemetry disable")
        elif consent:
            console.print("Status: [green]Enabled[/green]")
            console.print("Data collection is active when you submit feedback.")
        else:
            console.print("Status: [red]Disabled[/red]")
            console.print("Data collection is blocked.")

        console.print()
        console.print(f"Data level: {data_level}")
        console.print()

        # Data fields
        data_fields = config.get("data_fields", {}).get(data_level, [])
        if data_fields:
            console.print("[bold]Data collected:[/bold]")
            for field in data_fields:
                console.print(f"  • {field}")

        console.print()
        console.print("For more details: obra telemetry explain")
        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Failed to get telemetry status: {e}")
        raise typer.Exit(1) from e


def telemetry_explain() -> None:
    """Explain what data is collected and why.

    Provides detailed information about:
    - What data Obra collects
    - Why each piece of data is collected
    - How data is protected (redaction, encryption)
    - Your privacy controls

    Example:
        obra telemetry explain
    """
    console.print()
    console.print("[bold cyan]What data does Obra collect?[/bold cyan]")
    console.print()

    console.print("[bold]When you submit feedback (bug/feature/comment):[/bold]")
    console.print()

    console.print("📊 [bold]Minimal data level[/bold] (default):")
    console.print("  • Feedback type (bug, feature request, comment)")
    console.print("  • Your description")
    console.print("  • Obra version")
    console.print("  • Timestamp")
    console.print("  • Platform (Linux, macOS, Windows)")
    console.print("  • Python version")
    console.print()

    console.print("📈 [bold]Detailed data level[/bold] (opt-in):")
    console.print("  • All minimal data, plus:")
    console.print("  • Session ID (for tracking related issues)")
    console.print("  • Stack trace (if error occurred)")
    console.print("  • Environment variables (redacted)")
    console.print("  • Recent logs (last 50 lines)")
    console.print("  • Command history (last 10 commands)")
    console.print("  • Active task ID")
    console.print()

    console.print("[bold cyan]How is your data protected?[/bold cyan]")
    console.print()
    console.print("🔒 [bold]Automatic redaction:[/bold]")
    console.print("  • API keys, tokens, passwords")
    console.print("  • AWS credentials")
    console.print("  • GitHub tokens")
    console.print("  • Home directory paths → replaced with ~")
    console.print("  • Usernames → replaced with [USER]")
    console.print("  • SSH keys, .env files, credentials")
    console.print()

    console.print("[bold cyan]Your privacy controls:[/bold cyan]")
    console.print()
    console.print(f"{glyphs.success} You must explicitly consent before ANY data is sent")
    console.print(f"{glyphs.success} In interactive mode, you can preview data before sending")
    console.print(f"{glyphs.success} You can revoke consent at any time")
    console.print(f"{glyphs.success} Non-interactive submissions are blocked without consent")
    console.print()

    console.print("[bold cyan]Why collect this data?[/bold cyan]")
    console.print()
    console.print("Your feedback helps us:")
    console.print("  • Prioritize bug fixes")
    console.print("  • Understand common issues")
    console.print("  • Improve error messages")
    console.print("  • Build features users actually need")
    console.print()

    console.print("[bold cyan]Commands:[/bold cyan]")
    console.print("  obra telemetry enable     - Grant consent")
    console.print("  obra telemetry disable    - Revoke consent")
    console.print("  obra telemetry status     - Check current settings")
    console.print()


telemetry_enable = handle_encoding_errors(telemetry_enable)
telemetry_disable = handle_encoding_errors(telemetry_disable)
telemetry_status = handle_encoding_errors(telemetry_status)
telemetry_explain = handle_encoding_errors(telemetry_explain)
telemetry_app.command("enable")(telemetry_enable)
telemetry_app.command("disable")(telemetry_disable)
telemetry_app.command("status")(telemetry_status)
telemetry_app.command("explain")(telemetry_explain)
