"""Feedback CLI facade preserving the public import surface."""

from __future__ import annotations

from obra.cli.feedback_commands import bug, feedback_app
from obra.cli.feedback_shared import offer_bug_report
from obra.cli.telemetry_commands import telemetry_app
from obra.cli.triage_commands import triage_app

__all__ = [
    "bug",
    "feedback_app",
    "offer_bug_report",
    "telemetry_app",
    "triage_app",
]
