"""Prompt file management commands for the Obra CLI.

Extracted from obra/cli/_main.py as part of REFACTOR-CLI-SUBAPPS-001.
"""

import logging
import time
from pathlib import Path
from typing import Any

import typer

from obra.constants import KIBIBYTE
from obra.display import (
    console,
    handle_encoding_errors,
    print_info,
    print_success,
)
from obra.messages import get_message

logger = logging.getLogger(__name__)

prompts_app = typer.Typer(
    name="prompts",
    help="Manage prompt files used during LLM orchestration",
    no_args_is_help=True,
    rich_markup_mode="rich",
)


@prompts_app.command("cleanup")
@handle_encoding_errors
def prompts_cleanup(
    age_hours: int | None = typer.Option(
        None,
        "--age-hours",
        "-a",
        help="Only delete prompts older than this many hours (default: from config)",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Delete all prompt files regardless of age (requires confirmation)",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        "-n",
        help="Show what would be deleted without actually deleting",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip confirmation prompt (use with --force)",
    ),
) -> None:
    """Clean up old prompt files from the .obra/prompts directory.

    By default, only deletes prompt files older than the configured age threshold
    (default: 24 hours). Use --force to delete all files regardless of age.

    This command is safe to run during active orchestration - it respects
    age-based protection to avoid deleting prompts in use.

    Examples:
        obra prompts cleanup                  # Delete prompts older than 24h
        obra prompts cleanup --age-hours 48   # Delete prompts older than 48h
        obra prompts cleanup --dry-run        # Preview what would be deleted
        obra prompts cleanup --force --yes    # Delete all prompts (no confirm)
    """

    from obra.config import get_prompt_cleanup_age_hours

    working_dir = Path.cwd()
    prompts_dir = working_dir / ".obra" / "prompts"

    if not prompts_dir.exists():
        console.print()
        print_info("No prompt files to clean up")
        console.print(f"  Directory not found: {prompts_dir}")
        console.print()
        return

    # Determine age threshold
    if force:
        threshold_hours = 0  # Delete everything
        threshold_desc = "all files"
    else:
        threshold_hours = age_hours if age_hours is not None else get_prompt_cleanup_age_hours()
        threshold_desc = f"files older than {threshold_hours}h"

    cutoff_time = time.time() - (threshold_hours * 3600)

    # Collect files to delete
    files_to_delete: list[tuple[Path, float]] = []
    files_skipped = 0
    total_size = 0

    for run_dir in prompts_dir.iterdir():
        if not run_dir.is_dir():
            continue
        if run_dir.name.startswith("."):
            continue  # Skip index files

        for prompt_file in run_dir.glob(".obra-prompt-*.txt"):
            try:
                stat = prompt_file.stat()
                age_hours_actual = (time.time() - stat.st_mtime) / 3600
                if force or stat.st_mtime < cutoff_time:
                    files_to_delete.append((prompt_file, age_hours_actual))
                    total_size += stat.st_size
                else:
                    files_skipped += 1
            except OSError:
                pass  # Skip files we can't stat

    if not files_to_delete:
        console.print()
        print_info(f"No prompt files match criteria ({threshold_desc})")
        if files_skipped:
            console.print(f"  Skipped {files_skipped} recent file(s)")
        console.print()
        return

    # Show summary
    console.print()
    if dry_run:
        console.print("[bold yellow]DRY RUN[/bold yellow] - No files will be deleted")
        console.print()

    console.print(f"[bold]Prompt cleanup: {threshold_desc}[/bold]")
    console.print(f"  Files to delete: {len(files_to_delete)}")
    console.print(f"  Total size: {total_size / KIBIBYTE:.1f} KB")
    if files_skipped:
        console.print(f"  Files skipped (recent): {files_skipped}")
    console.print()

    # Show files
    if len(files_to_delete) <= 10:
        console.print("[dim]Files:[/dim]")
        for file_path, age_h in files_to_delete:
            rel_path = file_path.relative_to(prompts_dir)
            console.print(f"  [dim]{rel_path}[/dim] ({age_h:.1f}h old)")
        console.print()

    if dry_run:
        console.print("[yellow]No changes made (dry run)[/yellow]")
        console.print()
        return

    # Confirm if force and not yes
    if force and not yes:
        console.print(
            "[yellow]⚠️  This will delete ALL prompt files, including recent ones.[/yellow]"
        )
        confirm = typer.confirm(get_message("prompt.confirm.continue_action"))
        if not confirm:
            print_info("Cleanup cancelled")
            raise typer.Exit(0)

    # Delete files
    deleted_count = 0
    deleted_size = 0
    empty_dirs: set[Path] = set()

    for file_path, _ in files_to_delete:
        try:
            file_size = file_path.stat().st_size
            file_path.unlink()
            deleted_count += 1
            deleted_size += file_size
            empty_dirs.add(file_path.parent)
        except OSError as e:
            logger.warning(f"Could not delete {file_path}: {e}")

    # Clean up empty run directories
    dirs_removed = 0
    for dir_path in empty_dirs:
        try:
            if dir_path.exists() and not any(dir_path.iterdir()):
                dir_path.rmdir()
                dirs_removed += 1
        except OSError:
            pass

    print_success(f"Deleted {deleted_count} prompt file(s) ({deleted_size / KIBIBYTE:.1f} KB)")
    if dirs_removed:
        console.print(f"  [dim]Removed {dirs_removed} empty directory(s)[/dim]")
    console.print()


@prompts_app.command("list")
@handle_encoding_errors
def prompts_list(
    show_all: bool = typer.Option(
        False,
        "--all",
        "-a",
        help="Show all prompt files (default: show summary only)",
    ),
) -> None:
    """List prompt files in the .obra/prompts directory.

    Shows a summary of prompt files organized by session/run ID.

    Examples:
        obra prompts list          # Show summary
        obra prompts list --all    # Show all files
    """

    working_dir = Path.cwd()
    prompts_dir = working_dir / ".obra" / "prompts"

    if not prompts_dir.exists():
        console.print()
        print_info("No prompt files found")
        console.print(f"  Directory: {prompts_dir}")
        console.print()
        return

    # Collect stats per run_id
    run_stats: dict[str, dict[str, Any]] = {}
    total_files = 0
    total_size = 0

    for run_dir in prompts_dir.iterdir():
        if not run_dir.is_dir():
            continue
        if run_dir.name.startswith("."):
            continue

        run_id = run_dir.name
        files: list[tuple[Path, float, int]] = []

        for prompt_file in run_dir.glob(".obra-prompt-*.txt"):
            try:
                stat = prompt_file.stat()
                age_hours = (time.time() - stat.st_mtime) / 3600
                files.append((prompt_file, age_hours, stat.st_size))
                total_files += 1
                total_size += stat.st_size
            except OSError:
                pass

        if files:
            files.sort(key=lambda x: x[1])  # Sort by age
            oldest_age = files[-1][1] if files else 0
            newest_age = files[0][1] if files else 0
            run_size = sum(f[2] for f in files)

            run_stats[run_id] = {
                "count": len(files),
                "size": run_size,
                "oldest_age": oldest_age,
                "newest_age": newest_age,
                "files": files,
            }

    if not run_stats:
        console.print()
        print_info("No prompt files found")
        console.print()
        return

    console.print()
    console.print(
        f"[bold]Prompt files: {total_files} total ({total_size / KIBIBYTE:.1f} KB)[/bold]"
    )
    console.print()

    # Sort runs by newest file age (most recent first)
    sorted_runs = sorted(run_stats.items(), key=lambda x: x[1]["newest_age"])

    for run_id, stats in sorted_runs:
        age_range = f"{stats['newest_age']:.1f}h"
        if stats["oldest_age"] != stats["newest_age"]:
            age_range = f"{stats['newest_age']:.1f}-{stats['oldest_age']:.1f}h"

        # Truncate run_id for display
        display_id = run_id[:12] + "..." if len(run_id) > 15 else run_id

        console.print(
            f"  [cyan]{display_id}[/cyan]: "
            f"{stats['count']} file(s), "
            f"{stats['size'] / KIBIBYTE:.1f} KB, "
            f"age: {age_range}"
        )

        if show_all:
            for file_path, age_h, size in stats["files"]:
                console.print(f"    [dim]{file_path.name}[/dim] ({age_h:.1f}h, {size} bytes)")

    console.print()
    console.print("[dim]Use 'obra prompts cleanup' to remove old prompt files[/dim]")
    console.print()
