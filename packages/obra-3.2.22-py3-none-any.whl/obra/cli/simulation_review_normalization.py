"""Pure data normalization for seeded review-episode simulations.

This module contains the validation and normalization logic that operates
on plain data structures without any Firestore or Firebase dependencies.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import yaml

_ALLOWED_SESSION_PATCH_FIELDS = frozenset(
    {
        "current_phase",
        "current_iteration",
        "fix_attempts",
        "review_fix_cycle_count",
        "fix_attempt_fingerprints",
        "fresh_fix_requested",
        "fresh_fix_item_id",
        "plan_revision_attempts",
        "verification_tools",
        "verification_preflight_attempted",
        "verification_preflight_attempts",
        "project_context",
    }
)
_ALLOWED_SCORECARD_FIELDS = frozenset(
    {
        "item_id",
        "iteration",
        "agent_reports",
        "compiled_score",
        "blocking_issues",
        "resolved_issues",
        "tests_required",
        "status",
        "forced_complete",
        "fix_failure_context",
        "issue_registry",
        "blocking_set_history",
        "blocking_set_profile_history",
        "fresh_fix_attempted",
    }
)
_ALLOWED_PENDING_ESCALATION_FIELDS = frozenset(
    {
        "reason_code",
        "reason_text",
        "item_id",
        "iteration",
        "blocking_issue_ids",
    }
)
_SESSION_SNAPSHOT_VERSION = 1
_SEEDED_SESSION_EXPIRY_HOURS = 24
_SUPPORTED_SESSION_SNAPSHOT_SUBCOLLECTIONS = (
    "plan_versions",
    "examinations",
    "execution_results",
    "quality_scorecards",
    "workflow_artifacts",
    "progress_events",
)
_SNAPSHOT_DATETIME_FIELDS = frozenset(
    {
        "accepted_at",
        "created_at",
        "derived_at",
        "emitted_at",
        "ended_at",
        "expires_at",
        "failed_at",
        "started_at",
        "timestamp",
        "updated_at",
    }
)


def _fresh_seeded_session_expiry() -> str:
    """Return a fresh session expiry aligned with the local session lease."""
    return (datetime.now(timezone.utc) + timedelta(hours=_SEEDED_SESSION_EXPIRY_HOURS)).isoformat()


def _load_structured_file(path: Path) -> dict[str, Any]:
    """Load a JSON or YAML mapping payload."""
    raw_text = path.read_text(encoding="utf-8")
    suffix = path.suffix.lower()
    if suffix in {".yaml", ".yml"}:
        payload = yaml.safe_load(raw_text)
    else:
        payload = json.loads(raw_text)
    if not isinstance(payload, dict):
        raise ValueError(f"Structured payload must be a mapping: {path}")
    return payload


def _resolve_relative_asset(
    scenario_path: Path | None,
    asset_path: str,
    *,
    field_name: str,
) -> Path:
    """Resolve a scenario-relative asset path."""
    if not asset_path.strip():
        raise ValueError(f"{field_name} must be a non-empty string")
    base_dir = scenario_path.parent if scenario_path is not None else Path.cwd()
    resolved = (base_dir / asset_path).expanduser().resolve(strict=False)
    if not resolved.exists():
        raise ValueError(f"{field_name} not found: {resolved}")
    return resolved


def _deep_merge(base: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge mappings without mutating inputs."""
    merged = dict(base)
    for key, value in patch.items():
        existing = merged.get(key)
        if isinstance(existing, dict) and isinstance(value, dict):
            merged[key] = _deep_merge(existing, value)
        else:
            merged[key] = value
    return merged


def _serialize_snapshot_value(value: Any) -> Any:
    """Convert Firestore payloads into JSON-safe seed data."""
    if isinstance(value, dict):
        return {str(key): _serialize_snapshot_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_serialize_snapshot_value(item) for item in value]
    if isinstance(value, tuple):
        return [_serialize_snapshot_value(item) for item in value]
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return value


def _restore_snapshot_value(value: Any, *, field_name: str | None = None) -> Any:
    """Convert JSON-safe snapshot data back into Firestore-friendly values."""
    if isinstance(value, dict):
        return {
            str(key): _restore_snapshot_value(item, field_name=str(key))
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_restore_snapshot_value(item) for item in value]
    if field_name in _SNAPSHOT_DATETIME_FIELDS and isinstance(value, str) and value.strip():
        normalized = value.replace("Z", "+00:00")
        try:
            return datetime.fromisoformat(normalized)
        except ValueError:
            return value
    return value


def _normalize_session_snapshot(raw_snapshot: Any) -> dict[str, Any]:
    """Validate a replayable session snapshot payload."""
    if raw_snapshot in (None, {}):
        return {}
    if not isinstance(raw_snapshot, dict):
        raise ValueError("Seeded review session snapshot must be a mapping")

    session_id = str(raw_snapshot.get("session_id", "") or "").strip()
    user_id = str(raw_snapshot.get("user_id", "") or "").strip()
    if not session_id:
        raise ValueError("Seeded review session snapshot must include session_id")
    if not user_id:
        raise ValueError("Seeded review session snapshot must include user_id")

    global_session = raw_snapshot.get("global_session")
    user_session = raw_snapshot.get("user_session")
    if not isinstance(global_session, dict) or not global_session:
        raise ValueError("Seeded review session snapshot must include global_session")
    if not isinstance(user_session, dict) or not user_session:
        raise ValueError("Seeded review session snapshot must include user_session")
    project_snapshot = raw_snapshot.get("project_snapshot")
    normalized_project_snapshot: dict[str, Any] = {}
    if project_snapshot not in (None, {}):
        if not isinstance(project_snapshot, dict):
            raise ValueError("Seeded review session snapshot project_snapshot must be a mapping")
        project_id = str(project_snapshot.get("project_id", "") or "").strip()
        project_data = project_snapshot.get("data")
        if not project_id:
            raise ValueError(
                "Seeded review session snapshot project_snapshot must include project_id"
            )
        if not isinstance(project_data, dict) or not project_data:
            raise ValueError("Seeded review session snapshot project_snapshot must include data")
        normalized_project_snapshot = {
            "project_id": project_id,
            "data": _serialize_snapshot_value(dict(project_data)),
        }

    normalized_subcollections: dict[str, list[dict[str, Any]]] = {}
    raw_subcollections = raw_snapshot.get("subcollections") or {}
    if raw_subcollections not in ({}, None) and not isinstance(raw_subcollections, dict):
        raise ValueError("Seeded review session snapshot subcollections must be a mapping")
    for name, entries in dict(raw_subcollections).items():
        if name not in _SUPPORTED_SESSION_SNAPSHOT_SUBCOLLECTIONS:
            raise ValueError(
                f"Seeded review session snapshot contains unsupported subcollection {name!r}"
            )
        if not isinstance(entries, list):
            raise ValueError(
                "Seeded review session snapshot subcollections must contain lists of documents"
            )
        normalized_entries: list[dict[str, Any]] = []
        for entry in entries:
            if not isinstance(entry, dict):
                raise ValueError("Seeded review session snapshot documents must be mappings")
            doc_id = str(entry.get("doc_id", "") or "").strip()
            data = entry.get("data")
            if not doc_id:
                raise ValueError("Seeded review session snapshot documents must include doc_id")
            if not isinstance(data, dict):
                raise ValueError(
                    "Seeded review session snapshot documents must include mapping data"
                )
            normalized_entries.append({"doc_id": doc_id, "data": _serialize_snapshot_value(data)})
        normalized_subcollections[name] = normalized_entries

    return {
        "snapshot_version": int(
            raw_snapshot.get("snapshot_version", _SESSION_SNAPSHOT_VERSION)
            or _SESSION_SNAPSHOT_VERSION
        ),
        "session_id": session_id,
        "user_id": user_id,
        "project_snapshot": normalized_project_snapshot,
        "global_session": _serialize_snapshot_value(dict(global_session)),
        "user_session": _serialize_snapshot_value(dict(user_session)),
        "subcollections": normalized_subcollections,
    }


def _normalize_session_patch(raw_patch: Any) -> dict[str, Any]:
    """Validate the bounded session patch contract."""
    if raw_patch in (None, {}):
        return {}
    if not isinstance(raw_patch, dict):
        raise ValueError(
            "Scenario simulation.seeded_review_episode.session_patch must be a mapping"
        )
    unexpected = sorted(set(raw_patch) - _ALLOWED_SESSION_PATCH_FIELDS)
    if unexpected:
        raise ValueError(
            "Scenario simulation.seeded_review_episode.session_patch contains "
            f"unsupported fields: {', '.join(unexpected)}"
        )

    normalized = dict(raw_patch)
    if "current_phase" in normalized:
        value = str(normalized["current_phase"] or "").strip()
        if not value:
            raise ValueError(
                "Scenario simulation.seeded_review_episode.session_patch.current_phase "
                "must be a non-empty string"
            )
        normalized["current_phase"] = value
    for field_name in (
        "current_iteration",
        "fix_attempts",
        "review_fix_cycle_count",
        "plan_revision_attempts",
        "verification_preflight_attempts",
    ):
        if field_name not in normalized:
            continue
        value = normalized[field_name]
        if not isinstance(value, int) or value < 0:
            raise ValueError(
                "Scenario simulation.seeded_review_episode.session_patch."
                f"{field_name} must be a non-negative integer"
            )
    for field_name in (
        "fresh_fix_requested",
        "verification_preflight_attempted",
    ):
        if field_name in normalized and not isinstance(normalized[field_name], bool):
            raise ValueError(
                "Scenario simulation.seeded_review_episode.session_patch."
                f"{field_name} must be a boolean"
            )
    if "fresh_fix_item_id" in normalized:
        normalized["fresh_fix_item_id"] = str(normalized["fresh_fix_item_id"] or "").strip()
    for field_name in (
        "fix_attempt_fingerprints",
        "verification_tools",
        "project_context",
    ):
        if field_name in normalized and not isinstance(normalized[field_name], dict):
            raise ValueError(
                "Scenario simulation.seeded_review_episode.session_patch."
                f"{field_name} must be a mapping"
            )
    return normalized


def _normalize_scorecard_payload(
    raw_entry: Any,
    *,
    scenario_path: Path | None,
    index: int,
) -> dict[str, Any]:
    """Validate one scorecard seed entry."""
    if not isinstance(raw_entry, dict):
        raise ValueError(
            "Scenario simulation.seeded_review_episode.scorecards entries must be mappings"
        )
    payload_file = raw_entry.get("payload_file")
    if payload_file is not None:
        if len(raw_entry) != 1:
            raise ValueError(
                "Scenario simulation.seeded_review_episode.scorecards entries using "
                "payload_file may not define additional fields"
            )
        if not isinstance(payload_file, str):
            raise ValueError(
                "Scenario simulation.seeded_review_episode.scorecards[].payload_file "
                "must be a string"
            )
        payload = _load_structured_file(
            _resolve_relative_asset(
                scenario_path,
                payload_file,
                field_name=("Scenario simulation.seeded_review_episode.scorecards[].payload_file"),
            )
        )
    else:
        payload = dict(raw_entry)

    unexpected = sorted(set(payload) - _ALLOWED_SCORECARD_FIELDS)
    if unexpected:
        raise ValueError(
            "Scenario simulation.seeded_review_episode.scorecards contains unsupported "
            f"fields at index {index}: {', '.join(unexpected)}"
        )

    item_id = str(payload.get("item_id", "") or "").strip()
    if not item_id:
        raise ValueError(
            "Scenario simulation.seeded_review_episode.scorecards[].item_id must be a "
            "non-empty string"
        )
    iteration = payload.get("iteration")
    if not isinstance(iteration, int) or iteration < 0:
        raise ValueError(
            "Scenario simulation.seeded_review_episode.scorecards[].iteration must be "
            "a non-negative integer"
        )

    normalized = dict(payload)
    normalized["item_id"] = item_id
    normalized["iteration"] = iteration
    if "compiled_score" in normalized:
        value = normalized["compiled_score"]
        if not isinstance(value, int | float):
            raise ValueError(
                "Scenario simulation.seeded_review_episode.scorecards[].compiled_score "
                "must be numeric"
            )
        normalized["compiled_score"] = float(value)
    for field_name in ("blocking_issues", "resolved_issues"):
        value = normalized.get(field_name)
        if value is None:
            continue
        if not isinstance(value, list) or not all(
            isinstance(item, str) and item.strip() for item in value
        ):
            raise ValueError(
                "Scenario simulation.seeded_review_episode.scorecards[]."
                f"{field_name} must be a list of non-empty strings"
            )
        normalized[field_name] = [item.strip() for item in value]
    for field_name in (
        "agent_reports",
        "fix_failure_context",
        "issue_registry",
        "blocking_set_history",
        "blocking_set_profile_history",
    ):
        value = normalized.get(field_name)
        if value is None:
            continue
        expected_type = list if field_name == "agent_reports" else dict
        if not isinstance(value, expected_type):
            expected_name = "list" if expected_type is list else "mapping"
            raise ValueError(
                "Scenario simulation.seeded_review_episode.scorecards[]."
                f"{field_name} must be a {expected_name}"
            )
    for field_name in ("tests_required", "forced_complete", "fresh_fix_attempted"):
        if field_name in normalized and not isinstance(normalized[field_name], bool):
            raise ValueError(
                "Scenario simulation.seeded_review_episode.scorecards[]."
                f"{field_name} must be a boolean"
            )
    if "status" in normalized:
        normalized["status"] = str(normalized["status"] or "").strip()
    return normalized


def _normalize_pending_escalation_fixer(raw_pending: Any) -> dict[str, Any]:
    """Validate an optional pre-dispatched escalation-fixer episode."""
    if raw_pending in (None, {}):
        return {}
    if not isinstance(raw_pending, dict):
        raise ValueError(
            "Scenario simulation.seeded_review_episode.pending_escalation_fixer must be a mapping"
        )

    unexpected = sorted(set(raw_pending) - _ALLOWED_PENDING_ESCALATION_FIELDS)
    if unexpected:
        raise ValueError(
            "Scenario simulation.seeded_review_episode.pending_escalation_fixer "
            f"contains unsupported fields: {', '.join(unexpected)}"
        )

    reason_code = str(raw_pending.get("reason_code", "") or "").strip()
    if not reason_code:
        raise ValueError(
            "Scenario simulation.seeded_review_episode.pending_escalation_fixer."
            "reason_code must be a non-empty string"
        )

    normalized: dict[str, Any] = {"reason_code": reason_code}
    reason_text = str(raw_pending.get("reason_text", "") or "").strip()
    if reason_text:
        normalized["reason_text"] = reason_text

    item_id = str(raw_pending.get("item_id", "") or "").strip()
    if item_id:
        normalized["item_id"] = item_id

    if "iteration" in raw_pending:
        iteration = raw_pending.get("iteration")
        if not isinstance(iteration, int) or iteration < 0:
            raise ValueError(
                "Scenario simulation.seeded_review_episode.pending_escalation_fixer."
                "iteration must be a non-negative integer"
            )
        normalized["iteration"] = iteration

    blocking_issue_ids = raw_pending.get("blocking_issue_ids")
    if blocking_issue_ids is not None:
        if not isinstance(blocking_issue_ids, list) or not all(
            isinstance(issue_id, str) and issue_id.strip() for issue_id in blocking_issue_ids
        ):
            raise ValueError(
                "Scenario simulation.seeded_review_episode.pending_escalation_fixer."
                "blocking_issue_ids must be a list of non-empty strings"
            )
        normalized["blocking_issue_ids"] = [
            str(issue_id).strip() for issue_id in blocking_issue_ids
        ]

    return normalized


def normalize_seeded_review_episode(
    raw_scenario: dict[str, Any],
    *,
    scenario_path: Path | None = None,
) -> dict[str, Any]:
    """Normalize the optional seeded review-episode contract."""
    raw_simulation = raw_scenario.get("simulation")
    if raw_simulation in (None, {}):
        return {}
    if not isinstance(raw_simulation, dict):
        raise ValueError("Scenario simulation must be a mapping when provided")

    raw_episode = raw_simulation.get("seeded_review_episode")
    if raw_episode in (None, {}):
        return {}
    if not isinstance(raw_episode, dict):
        raise ValueError("Scenario simulation.seeded_review_episode must be a mapping")

    scorecards_raw = raw_episode.get("scorecards")
    if not isinstance(scorecards_raw, list) or not scorecards_raw:
        raise ValueError(
            "Scenario simulation.seeded_review_episode.scorecards must be a non-empty list"
        )

    scorecards = [
        _normalize_scorecard_payload(
            entry,
            scenario_path=scenario_path,
            index=index,
        )
        for index, entry in enumerate(scorecards_raw)
    ]
    item_ids = sorted(
        {
            str(scorecard["item_id"]).strip()
            for scorecard in scorecards
            if str(scorecard["item_id"]).strip()
        }
    )
    return {
        "session_patch": _normalize_session_patch(raw_episode.get("session_patch")),
        "scorecards": scorecards,
        "item_ids": item_ids,
        "scorecard_count": len(scorecards),
        "pending_escalation_fixer": _normalize_pending_escalation_fixer(
            raw_episode.get("pending_escalation_fixer")
        ),
    }


def _build_project_context_patch(simulation_control: dict[str, Any]) -> dict[str, Any]:
    """Translate simulator controls into resumed-session config state."""
    simulation_patch: dict[str, Any] = {}
    config_patch: dict[str, Any] = {}

    escalation_control = simulation_control.get("escalation_fixer")
    if isinstance(escalation_control, dict) and escalation_control:
        review_config: dict[str, Any] = {"enabled": True}
        for field_name in ("timeout_s", "allowed_routes", "eligible_reason_codes"):
            value = escalation_control.get(field_name)
            if value not in (None, {}, []):
                review_config[field_name] = value
        simulation_patch["escalation_fixer"] = dict(escalation_control)
        config_patch["review"] = {"escalation_fixer": review_config}

    adaptive_control = simulation_control.get("adaptive_decomposition")
    if isinstance(adaptive_control, dict) and adaptive_control:
        simulation_patch["adaptive_decomposition"] = dict(adaptive_control)
        adaptive_config = adaptive_control.get("config")
        if isinstance(adaptive_config, dict) and adaptive_config:
            orchestration = dict(config_patch.get("orchestration") or {})
            orchestration["decomposition"] = dict(adaptive_config)
            config_patch["orchestration"] = orchestration

    if not simulation_patch and not config_patch:
        return {}

    patch: dict[str, Any] = {}
    if simulation_patch:
        patch["simulation"] = simulation_patch
    if config_patch:
        patch["config"] = config_patch
    return patch


def prepare_seeded_review_session_updates(
    *,
    session: Any,
    session_patch: dict[str, Any],
) -> dict[str, Any]:
    """Prepare bounded session updates for a seeded review replay."""
    updates = dict(session_patch)
    project_context_patch = updates.pop("project_context", None)
    if project_context_patch:
        existing_context = dict(getattr(session, "project_context", {}) or {})
        updates["project_context"] = _deep_merge(existing_context, project_context_patch)

    current_phase = str(updates.get("current_phase") or "").strip().lower()
    if current_phase:
        existing_lifecycle_decisions = dict(
            getattr(session, "workflow_lifecycle_decisions", {}) or {}
        )
        existing_lifecycle_decisions["resume_target"] = current_phase
        updates["workflow_lifecycle_decisions"] = existing_lifecycle_decisions

        existing_derivation_state = dict(getattr(session, "workflow_derivation_state", {}) or {})
        existing_derivation_state["resume_target"] = current_phase
        updates["workflow_derivation_state"] = existing_derivation_state

    current_status = str(getattr(session, "status", "") or "").strip().lower()
    if current_status and current_status != "active":
        updates["status"] = "active"
    return updates


def build_seeded_review_episode_plan(
    *,
    checkpoint_file: str | Path,
    seeded_review_episode: dict[str, Any],
    simulation_control: dict[str, Any],
    seed_pack: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the late-review hydration plan for a resumed scenario."""
    if not seeded_review_episode:
        return {}

    checkpoint = _load_structured_file(Path(checkpoint_file).expanduser())
    checkpoint_type = str(checkpoint.get("checkpoint_type", "") or "").strip()
    if checkpoint_type != "resume_checkpoint":
        raise ValueError("Seeded review episodes require a resume_checkpoint scenario checkpoint")
    session_id = str(checkpoint.get("session_id", "") or "").strip()
    if not session_id:
        raise ValueError("Seeded review episodes require checkpoint_file.session_id to be set")
    session_snapshot: dict[str, Any] = {}
    if isinstance(seed_pack, dict):
        snapshot_file = str(seed_pack.get("session_snapshot_file", "") or "").strip()
        if snapshot_file:
            session_snapshot = _normalize_session_snapshot(
                _load_structured_file(Path(snapshot_file).expanduser())
            )
            snapshot_session_id = str(session_snapshot.get("session_id", "") or "").strip()
            if snapshot_session_id and snapshot_session_id != session_id:
                raise ValueError(
                    "Seeded review session snapshot session_id does not match "
                    "checkpoint_file.session_id"
                )

    session_patch = dict(seeded_review_episode.get("session_patch") or {})
    project_context_patch = _build_project_context_patch(simulation_control)
    if project_context_patch:
        existing_project_context = dict(session_patch.get("project_context") or {})
        session_patch["project_context"] = _deep_merge(
            existing_project_context,
            project_context_patch,
        )

    return {
        "session_id": session_id,
        "session_snapshot": session_snapshot,
        "session_patch": session_patch,
        "scorecards": list(seeded_review_episode.get("scorecards") or []),
        "item_ids": list(seeded_review_episode.get("item_ids") or []),
        "scorecard_count": int(seeded_review_episode.get("scorecard_count", 0) or 0),
        "pending_escalation_fixer": dict(
            seeded_review_episode.get("pending_escalation_fixer") or {}
        ),
    }
