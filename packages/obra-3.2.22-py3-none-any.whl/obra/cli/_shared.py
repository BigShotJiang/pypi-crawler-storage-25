"""Shared CLI utilities used across multiple sub-apps.

These utilities were previously defined in obra/cli/_main.py and are extracted
here to eliminate backward-import debt in sibling modules.
"""

import logging
import sys
from typing import Any, Callable

import click
import typer

from obra.display import console, display_obra_error, refresh_console_streams
from obra.exceptions import AuthenticationError
from obra.messages import get_message
from obra.utils.numeric import _safe_int


def require_authenticated_client() -> Any:
    """Validate auth and return an API client.

    Calls ensure_valid_token() which handles all auth states: missing auth,
    invalid/expired tokens, and token refresh. On failure, displays a
    user-friendly error panel and exits cleanly with no traceback.

    Returns:
        Authenticated APIClient instance.
    """
    from obra.api import APIClient
    from obra.auth import ensure_valid_token

    refresh_console_streams()
    try:
        ensure_valid_token()
    except AuthenticationError as e:
        display_obra_error(e, console)
        raise typer.Exit(1) from e
    return APIClient.from_config()


def setup_logging(verbose: int = 0) -> None:
    """Configure logging for CLI commands.

    Args:
        verbose: Verbosity level (0-3); logs shown only when verbose >= 2
    """
    refresh_console_streams()

    # Verbosity level mapping: 0-1=ERROR, 2=INFO, 3+=DEBUG - CLI design constant
    if verbose <= 1:
        level = logging.ERROR
    elif verbose == 2:
        level = logging.INFO
    else:
        level = logging.DEBUG

    class _QuietInfoFormatter(logging.Formatter):
        """Dim INFO lines and colorize severity tags in TTY."""

        def __init__(self, use_color: bool) -> None:
            super().__init__()
            self._use_color = use_color

        def format(self, record: logging.LogRecord) -> str:
            level = record.levelname
            timestamp = self.formatTime(record, self.datefmt)
            message = record.getMessage()
            base = f"{level} [{timestamp}] {record.name} - {message}"

            if record.exc_info:
                base = f"{base}\n{self.formatException(record.exc_info)}"
            if record.stack_info:
                base = f"{base}\n{self.formatStack(record.stack_info)}"

            if not self._use_color:
                return base

            if record.levelno == logging.INFO:
                return f"\x1b[90m{base}\x1b[0m"
            if record.levelno >= logging.ERROR:
                tag = f"\x1b[31m{level}\x1b[0m"
            elif record.levelno == logging.WARNING:
                tag = f"\x1b[33m{level}\x1b[0m"
            else:
                return base

            return base.replace(level, tag, 1)

    use_color = hasattr(sys.stderr, "isatty") and sys.stderr.isatty()
    from obra.display.spinner import suspend_active_spinner

    class _SpinnerAwareHandler(logging.StreamHandler):
        """Logging handler that suspends the active spinner during emits."""

        def emit(self, record: logging.LogRecord) -> None:
            with suspend_active_spinner():
                super().emit(record)

    handler = _SpinnerAwareHandler()
    handler.setLevel(level)
    handler.setFormatter(_QuietInfoFormatter(use_color=use_color))
    logging.basicConfig(level=level, handlers=[handler])


def _resolve_command_verbosity(ctx: typer.Context, verbose: int) -> int:
    """Prefer global verbosity when the command-level flag is not set."""
    try:
        source = ctx.get_parameter_source("verbose")
    except Exception:
        return verbose
    if source == click.core.ParameterSource.DEFAULT:
        ctx_obj = ctx.obj if isinstance(ctx.obj, dict) else {}
        ctx_verbose = ctx_obj.get("verbose")
        if isinstance(ctx_verbose, int):
            return ctx_verbose
    return verbose


def require_terms_accepted(func: Callable) -> Callable:
    """Decorator to ensure terms have been accepted before running a command.

    Checks if the user has accepted the current version of the Beta Software
    Agreement. If not, raises TermsNotAcceptedError with clear instructions
    to run 'obra setup'.

    Raises:
        TermsNotAcceptedError: If terms not accepted or version mismatch

    Example:
        @app.command()
        @require_terms_accepted
        def my_command():
            # This will only run if terms are accepted
            pass
    """
    import functools

    from obra.config import TERMS_VERSION, is_terms_accepted, needs_reacceptance
    from obra.exceptions import TermsNotAcceptedError

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # Check if terms have been accepted
        if not is_terms_accepted():
            raise TermsNotAcceptedError(
                message="Terms not accepted",
                required_version=TERMS_VERSION,
                action=get_message("recovery.auth.terms"),
            )

        # Check if re-acceptance is needed due to version change
        if needs_reacceptance():
            raise TermsNotAcceptedError(
                message=f"Terms have been updated to version {TERMS_VERSION}",
                required_version=TERMS_VERSION,
                action=get_message("recovery.auth.terms"),
            )

        return func(*args, **kwargs)

    return wrapper


def _extract_plan_progress(plan_data: dict[str, Any]) -> tuple[list[dict[str, Any]], int, int]:
    """Normalize plan progress counts across legacy and current API key shapes."""
    raw_items = plan_data.get("plan_items", [])
    plan_items = (
        [item for item in raw_items if isinstance(item, dict)]
        if isinstance(raw_items, list)
        else []
    )

    total_tasks = _safe_int(plan_data.get("total"), default=-1)
    if total_tasks < 0:
        total_tasks = _safe_int(plan_data.get("total_count"), default=-1)
    if total_tasks < 0:
        total_tasks = len(plan_items)

    completed_tasks = _safe_int(plan_data.get("completed"), default=-1)
    if completed_tasks < 0:
        completed_tasks = _safe_int(plan_data.get("completed_count"), default=-1)
    if completed_tasks < 0:
        completed_tasks = sum(1 for item in plan_items if item.get("status") == "completed")

    return plan_items, total_tasks, completed_tasks
