"""Detect stale editable installs by comparing pyproject.toml content hash.

When Obra is installed with ``pip install -e .``, changes to pyproject.toml
(new dependencies, entry points, package additions) require a reinstall to
take effect.  This module warns developers when pyproject.toml has changed
since the last install.

This check is zero-cost for wheel installs: it exits immediately when the
PEP 610 ``direct_url.json`` editable marker is absent.
"""

from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

_CACHE_DIR = Path.home() / ".obra"
_CACHE_FILE = _CACHE_DIR / ".editable_install_check"


def check_editable_install_freshness() -> None:
    """Warn if pyproject.toml changed since the last editable install.

    Safe to call on every CLI invocation — returns immediately for wheel
    installs and suppresses all exceptions so it never blocks the CLI.
    """
    try:
        _check()
    except Exception:
        pass


def _check() -> None:
    from importlib import metadata

    try:
        dist = metadata.distribution("obra")
    except metadata.PackageNotFoundError:
        return

    # Only applies to editable installs (PEP 610 direct_url.json)
    dist_path = Path(str(dist._path))
    direct_url_file = dist_path / "direct_url.json"
    if not direct_url_file.is_file():
        return
    try:
        direct_url = json.loads(direct_url_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return
    if not direct_url.get("dir_info", {}).get("editable", False):
        return

    # Find pyproject.toml from the editable URL
    url = direct_url.get("url", "")
    if not url.startswith("file://"):
        return
    pkg_dir = Path(url.removeprefix("file://"))
    pyproject = pkg_dir / "pyproject.toml"
    if not pyproject.is_file():
        # Try parent (URL may point to obra/ subdir)
        pyproject = pkg_dir.parent / "pyproject.toml"
        # Also check obra/pyproject.toml specifically
        if not pyproject.is_file():
            pyproject = pkg_dir / "pyproject.toml"
    if not pyproject.is_file():
        return

    # Hash pyproject.toml content
    current_hash = hashlib.sha256(pyproject.read_bytes()).hexdigest()[:16]

    # Get RECORD mtime as a proxy for "last install time"
    record_file = dist_path / "RECORD"
    if not record_file.is_file():
        return
    record_mtime = str(record_file.stat().st_mtime)

    # Load cached state
    cached = _load_cache()
    cached_hash = cached.get("pyproject_hash", "")
    cached_record_mtime = cached.get("record_mtime", "")

    if cached_record_mtime != record_mtime:
        # A new install happened (RECORD changed) — record the current
        # pyproject hash silently.  This covers the fresh-install case
        # and the case where someone just ran pip install -e .
        _save_cache(current_hash, record_mtime)
        return

    if cached_hash == current_hash:
        # pyproject.toml unchanged since last install — all good.
        return

    # pyproject.toml changed but no reinstall happened.
    _warn(pyproject)


def _warn(pyproject: Path) -> None:
    """Print a one-line warning to stderr."""
    try:
        from obra.display import print_warning

        print_warning(
            "pyproject.toml has changed since last install — "
            "run `uv pip install -e .` to pick up new packages/dependencies."
        )
    except Exception:
        import sys

        print(
            "WARNING: pyproject.toml has changed since last install — "
            "run `uv pip install -e .` to pick up new packages/dependencies.",
            file=sys.stderr,
        )


def _load_cache() -> dict[str, str]:
    try:
        if _CACHE_FILE.is_file():
            return json.loads(_CACHE_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        pass
    return {}


def _save_cache(pyproject_hash: str, record_mtime: str) -> None:
    try:
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        _CACHE_FILE.write_text(
            json.dumps(
                {
                    "pyproject_hash": pyproject_hash,
                    "record_mtime": record_mtime,
                }
            ),
            encoding="utf-8",
        )
    except OSError:
        pass
