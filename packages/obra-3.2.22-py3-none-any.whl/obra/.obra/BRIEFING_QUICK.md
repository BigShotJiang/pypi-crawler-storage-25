# Obra Quick Start for AI Agents

**Version**: 1.5
**Read time**: ~2 minutes
**Purpose**: The shortest reliable path to a good `obra run`

---

## LLM Fast Path

Run these in order:

1. `obra briefing quick`
2. `obra models`
3. `obra help domains`
4. `obra help run`

Then invoke:

```bash
obra run --domain <domain> "objective with stack, features, and success criteria"
```

### Gateway API Path

If you are operating API-first instead of driving work through the CLI:

```bash
obra gateway start
curl http://127.0.0.1:18790/api -H "Authorization: Bearer <token>"
curl http://127.0.0.1:18790/api/domains -H "Authorization: Bearer <token>"
curl http://127.0.0.1:18790/api/runners/kinds -H "Authorization: Bearer <token>"
```

All major CLI workflow-control surfaces now have gateway API equivalents. Once
the gateway is running, API-only operation is supported.

### Before you run

- **Models**: use `obra models` to discover valid provider/model names.
- **Domains**: `obra run` needs an explicit resolved domain from `--domain`, project config, or layered config. If none resolve, the run fails before session creation.
- **Rigor override**: use `--plan-mode light|balanced|thorough` only when you need to override routing. Compatibility aliases remain accepted: `quick=light`, `standard=balanced`.
- **Working directory**: run inside the target repo, or pass `--dir /path`.
- **WSL paths**: map `C:\...` to `/mnt/c/...`. Native Windows uses `C:\...` directly.
- **Verbosity**: default is PROGRESS. Use `-q` for quiet, `-vv/-vvv` for more detail.
- **Long runs**: do not let your tool kill `obra run` with a short timeout. Background it if needed and monitor with `obra status <id>`.

### Model selection

- Session overrides:
```bash
obra run --model opus --impl-provider anthropic "objective"
obra run --model gpt-5.2 --impl-provider openai "objective"
```
- Env vars:
  `OBRA_MODEL`, `OBRA_FAST_MODEL`, `OBRA_HIGH_MODEL`, `OBRA_PROVIDER`
- Do **not** use `obra config set llm.*.model` as the normal path.

---

## Input Quality Gate

Do not submit vague objectives like:

```bash
obra run "build a website"
obra run "fix the bug"
obra run "make it better"
```

Use one compact objective that includes:

- **What**: the deliverable or change
- **Stack**: language, framework, database, runtime
- **Features**: concrete capabilities
- **Success criteria**: testable outcomes
- **Constraints**: integrations, performance, security, or anti-patterns when relevant

Good example:

```bash
obra run --domain software "User management API for FastAPI + PostgreSQL:
CRUD users, JWT auth with refresh tokens, admin/user RBAC, bcrypt passwords.
Success: all endpoints return correct status codes, unauthorized requests get 401,
tests pass with >80% coverage."
```

Business example:

```bash
obra run --domain business "Invoice review workflow:
validate invoice packet, route exceptions for approval, produce final finance summary.
Success: clear handoff steps, explicit approval branch, review checkpoints visible."
```

---

## Minimum Checklist

Before invoking Obra, make sure you have:

- **Clear objective**: 2-4 sentences, not a fragment
- **Tech stack**: inferred from files or explicitly stated
- **Specific features**: not just "auth", "search", or "admin"
- **Success criteria**: measurable outcomes
- **Git repo**: or intentionally use `--auto-init-git`

If the request is vague:

- inspect the repo first
- make the best assumption from local context
- state the assumption explicitly in the objective
- proceed

Do not waste turns asking what the codebase already tells you.

---

## Smart Patterns

### Infer first

Check files before asking:

- `package.json`
- `pyproject.toml` / `requirements.txt`
- `go.mod`
- `Cargo.toml`
- `pom.xml` / `build.gradle`

### Push vague nouns into specifics

- `"authentication"` -> `"JWT auth with refresh tokens and RBAC"`
- `"search"` -> `"search by name/description with category and price filters"`
- `"admin panel"` -> `"admin dashboard with user CRUD, filters, and analytics summary"`

### Keep one objective string

Do not spread core requirements across multiple partial commands. Build one good objective and run it once.

---

## Monitoring And Recovery

During execution:

```bash
obra status <id>
```

When recovery is needed:

```bash
obra run --resume <id>
obra run --continue-from <id>
obra sessions repair <id>
```

Use `--continue-from` when resumability is unclear or the session failed/escalated and you want a fresh session that skips completed work.

---

## Feedback

If Obra is wrong or stuck:

```bash
obra feedback bug "description"
obra feedback feature "title"
```

For automation:

```bash
obra feedback bug "description" --non-interactive --format json
```

---

## Next Reads

- `obra briefing` for the broader operator guide
- `obra briefing examples` for good vs bad objective patterns
- `obra briefing protocol` for unattended execution behavior
- `obra docs llm` for the packaged onboarding path
