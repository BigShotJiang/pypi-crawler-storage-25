"""Escalation configuration — typed config loaded from orchestrator config dict."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)

_VALID_DEFAULT_ACTIONS = frozenset(
    {
        "force_complete",
        "continue_fixing",
        "skip_issues",
        "abandon",
    }
)


@dataclass
class EscalationConfig:
    """Typed escalation configuration.

    All defaults match the current codebase values.
    """

    prompt_timeout_s: float = 300.0
    """Timeout for interactive escalation prompt (seconds)."""

    default_action: str = "force_complete"
    """Action to take when prompt times out or no callback provided."""

    description_truncation_chars: int = 57
    """Character limit for issue description truncation in escalation display."""

    timeout_s: int = 600
    """Overall escalation timeout (seconds)."""

    continue_iteration_reset: int = 0
    """Iteration value to reset to on CONTINUE_FIXING. 0 = full budget."""

    @classmethod
    def from_config(cls, config: dict[str, Any] | None) -> EscalationConfig:
        """Load escalation config from orchestrator config dict.

        Uses nested ``.get()`` calls following the pattern in
        ``obra/config/loaders.py``.

        Args:
            config: The orchestrator's ``self._config`` dict, or None.

        Returns:
            Populated EscalationConfig with values from config or defaults.
        """
        if config is None:
            return cls()

        escalate_cfg = config.get("handlers", {}).get("escalate", {})
        if not isinstance(escalate_cfg, dict):
            escalate_cfg = {}

        refinement_cfg = config.get("refinement", {})
        if not isinstance(refinement_cfg, dict):
            refinement_cfg = {}

        # prompt_timeout_s
        raw_timeout = escalate_cfg.get("prompt_timeout_s")
        prompt_timeout_s = float(raw_timeout) if raw_timeout is not None else 300.0

        # default_action
        raw_action = escalate_cfg.get("default_action")
        if isinstance(raw_action, str) and raw_action.strip():
            default_action = raw_action.strip()
        else:
            default_action = "force_complete"

        if default_action not in _VALID_DEFAULT_ACTIONS:
            logger.warning(
                "Invalid escalation default_action %r; falling back to 'force_complete'",
                default_action,
            )
            default_action = "force_complete"

        # description_truncation_chars
        raw_trunc = escalate_cfg.get("description_truncation_chars")
        description_truncation_chars = int(raw_trunc) if raw_trunc is not None else 57

        # timeout_s
        raw_esc_timeout = escalate_cfg.get("timeout_s")
        timeout_s = int(raw_esc_timeout) if raw_esc_timeout is not None else 600

        # continue_iteration_reset
        raw_reset = refinement_cfg.get("escalation_continue_iteration_reset")
        continue_iteration_reset = int(raw_reset) if raw_reset is not None else 0

        return cls(
            prompt_timeout_s=prompt_timeout_s,
            default_action=default_action,
            description_truncation_chars=description_truncation_chars,
            timeout_s=timeout_s,
            continue_iteration_reset=continue_iteration_reset,
        )
