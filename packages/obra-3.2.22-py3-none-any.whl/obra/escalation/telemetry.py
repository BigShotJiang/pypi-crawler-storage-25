"""Typed escalation telemetry event definitions.

Pure data/schema layer — no side effects, no imports of orchestrator or manager.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any


@dataclass
class EscalationEvent:
    """Base class for escalation telemetry events."""

    event_type: str
    escalation_id: str
    reason: str
    timestamp: float = field(default_factory=time.time)

    def to_kwargs(self) -> dict[str, Any]:
        """Return kwargs dict suitable for ``log_session_event(event_type, **kwargs)``."""
        return {
            "escalation_id": self.escalation_id,
            "reason": self.reason,
        }


@dataclass
class EscalationPromptWaitingEvent(EscalationEvent):
    """Emitted when the escalation prompt is displayed, before blocking on input.

    Currently emitted at two sites in orchestrator.py (callback and no-callback paths).
    """

    event_type: str = field(init=False, default="escalation_prompt_waiting")

    def to_kwargs(self) -> dict[str, Any]:
        """Return kwargs for escalation_prompt_waiting event."""
        return {
            "escalation_id": self.escalation_id,
            "reason": self.reason,
        }


@dataclass
class EscalationDecisionEvent(EscalationEvent):
    """Emitted when an escalation decision is made (user input, timeout, or default)."""

    event_type: str = field(init=False, default="escalation_decision")
    decision: str = ""
    was_timeout: bool = False
    decision_source: str = ""
    decision_wait_ms: float = 0.0
    blocking_issues_count: int = 0
    blocking_item_ids: list[str] = field(default_factory=list)
    fix_failure_summary: dict[str, Any] | None = None

    def to_kwargs(self) -> dict[str, Any]:
        """Return kwargs for escalation_decision event."""
        return {
            "escalation_id": self.escalation_id,
            "decision": self.decision,
            "reason": self.reason,
            "was_timeout": self.was_timeout,
            "decision_source": self.decision_source,
            "decision_wait_ms": round(self.decision_wait_ms, 1),
            "blocking_issues_count": self.blocking_issues_count,
            "blocking_item_ids": self.blocking_item_ids,
            "fix_failure_summary": self.fix_failure_summary,
        }


def emit(event: EscalationEvent, log_fn: Callable[..., None]) -> None:
    """Emit an escalation event via the provided logging function.

    Args:
        event: Typed escalation event.
        log_fn: Callable with signature ``(event_type: str, **kwargs) -> None``.
    """
    log_fn(event.event_type, **event.to_kwargs())
