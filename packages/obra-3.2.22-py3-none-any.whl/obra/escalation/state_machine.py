"""Escalation state machine — validates transitions, tracks permanent escalation flag."""

from __future__ import annotations

from collections.abc import Callable
from typing import ClassVar

from obra.escalation.models import EscalationInvariantError, EscalationState


class EscalationStateMachine:
    """Finite state machine for escalation lifecycle.

    Enforces valid transitions and prevents execution after terminal states.
    Uses an ``on_transition`` callback for extensibility (no direct telemetry
    coupling within the state machine).
    """

    TRANSITIONS: ClassVar[dict[EscalationState, set[EscalationState]]] = {
        EscalationState.NONE: {EscalationState.TRIGGERED},
        EscalationState.TRIGGERED: {EscalationState.WAITING_DECISION},
        EscalationState.WAITING_DECISION: {EscalationState.DECIDED},
        EscalationState.DECIDED: {EscalationState.RESUMED, EscalationState.TERMINAL},
        EscalationState.RESUMED: {EscalationState.NONE},
        EscalationState.TERMINAL: set(),
    }

    def __init__(
        self,
        on_transition: Callable[[EscalationState, EscalationState], None] | None = None,
    ) -> None:
        self._state = EscalationState.NONE
        self._ever_escalated: bool = False
        self._on_transition = on_transition

    @property
    def state(self) -> EscalationState:
        """Current escalation state."""
        return self._state

    @property
    def is_terminal(self) -> bool:
        """Whether the state machine has reached a terminal state."""
        return self._state == EscalationState.TERMINAL

    @property
    def is_waiting(self) -> bool:
        """Whether the state machine is waiting for a user decision."""
        return self._state == EscalationState.WAITING_DECISION

    @property
    def was_escalated(self) -> bool:
        """Whether this session ever experienced an escalation.

        This is a permanent flag — once True, it stays True even after
        RESUMED -> NONE resets the state. Matches the semantics of
        orchestrator's ``_was_escalated``.
        """
        return self._ever_escalated

    def transition(self, to: EscalationState) -> None:
        """Advance the state machine to *to*.

        Raises:
            EscalationInvariantError: If the transition is not allowed.
        """
        allowed = self.TRANSITIONS.get(self._state, set())
        if to not in allowed:
            msg = f"Invalid escalation transition: {self._state.value} \u2192 {to.value}"
            raise EscalationInvariantError(msg)

        from_state = self._state
        self._state = to

        # Mark permanent escalation flag on first departure from NONE.
        if from_state == EscalationState.NONE:
            self._ever_escalated = True

        if self._on_transition is not None:
            self._on_transition(from_state, to)

    def reset(self) -> None:
        """Reset to NONE state (only valid from NONE or RESUMED).

        Does NOT clear ``_ever_escalated``.
        """
        if self._state not in {EscalationState.NONE, EscalationState.RESUMED}:
            msg = f"Cannot reset from state {self._state.value}; only NONE and RESUMED allowed"
            raise EscalationInvariantError(msg)
        self._state = EscalationState.NONE
