"""Health monitoring for HybridOrchestrator.

Extracted from obra/hybrid/orchestrator.py as part of REFACTOR-ORCH-EXTRACT-001.
Handles session watchdog, stall detection, CLI cache health, and session guard management.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any

from obra.api.protocol import SessionPhase
from obra.display import console, print_warning
from obra.exceptions import OrchestratorError
from obra.hybrid.event_logger import HybridEventLogger
from obra.hybrid.session_guard import SessionGuard
from obra.messages import get_message
from obra.utils.cli_cache_monitor import CLICacheMonitor

if TYPE_CHECKING:
    from obra.hybrid.orchestrator import InvocationState, WatchdogState
    from obra.hybrid.runtime_state import HybridRuntimeState

logger = logging.getLogger(__name__)


class HealthMonitor:
    """Health monitoring extracted from HybridOrchestrator.

    Handles session watchdog stall detection, CLI cache health checks,
    session timeout warnings, and session guard management.
    Receives shared state via constructor injection.
    """

    def __init__(
        self,
        watchdog: WatchdogState,
        runtime_state: HybridRuntimeState,
        session_guard_getter: Callable[[], SessionGuard | None],
        config_getter: Callable[[], dict[str, Any] | None],
        event_logger_getter: Callable[[], HybridEventLogger],
        working_dir_getter: Callable[[], Path],
        invocation: InvocationState,
    ) -> None:
        self._watchdog = watchdog
        self._state = runtime_state
        self._session_guard_getter = session_guard_getter
        self._config_getter = config_getter
        self._event_logger_getter = event_logger_getter
        self._working_dir_getter = working_dir_getter
        self._invocation = invocation

    def _log_session_event(self, event_type: str, **kwargs) -> None:
        kwargs.pop("session_id", None)
        session_id = self._state.session_id or ""
        try:
            self._event_logger_getter().log_event(event_type, session_id=session_id, **kwargs)
            self._watchdog.last_event_time = time.time()
        except Exception as e:
            logger.warning(f"Failed to log hybrid event '{event_type}': {e}")

    def create_monitoring_context(
        self,
        task_id: str | None = None,
        liveness_interval: int = 180,
    ) -> dict[str, Any] | None:
        """Create monitoring context dict for subprocess operations.

        ADR-043 Phase 3: Helper factory to simplify monitoring context construction.
        Returns dict compatible with MonitoringThread initialization.

        Args:
            task_id: Optional task ID for monitoring context (agent operations)
            liveness_interval: Liveness check interval in seconds (default: 180s)

        Returns:
            Monitoring context dict with keys: config, workspace_path, event_logger, session_id
            Returns None if session_id not available

        Usage:
            context = orchestrator.create_monitoring_context(task_id="T-001")
            handler = DeriveHandler(..., monitoring_context=context)
        """
        session_id = self._state.session_id
        if not session_id:
            return None

        return {
            "config": {
                "orchestration": {
                    "monitoring": {"enabled": True},
                    "timeouts": {"liveness": {"check_interval_s": liveness_interval}},
                }
            },
            "workspace_path": str(self._working_dir_getter()),
            "event_logger": self._event_logger_getter(),
            "session_id": session_id,
            "task_id": task_id,
        }

    def _get_straggler_alert_threshold(self) -> float:
        """Get the straggler alert threshold from config.

        P2-2: Returns the threshold above which a batch_straggler_alert
        event is emitted for parallel batch imbalance detection.
        """
        from obra.config.loaders import get_refinement_straggler_alert_threshold

        config = self._config_getter()
        if isinstance(config, dict):
            refinement_cfg = config.get("refinement")
            if isinstance(refinement_cfg, dict) and "straggler_alert_threshold" in refinement_cfg:
                try:
                    value = float(refinement_cfg["straggler_alert_threshold"])
                    if value > 0:
                        return value
                except (TypeError, ValueError):
                    logger.warning(
                        "Invalid refinement.straggler_alert_threshold in runtime config: %s",
                        refinement_cfg.get("straggler_alert_threshold"),
                    )
        return get_refinement_straggler_alert_threshold()

    def _check_stall(self) -> None:
        """Check for session stall and raise if detected (ISSUE-HYBRID-003, ISSUE-HYBRID-008).

        Two-tier stall detection:
        1. Normal stall: No handler active + time > stall_timeout_s (ISSUE-HYBRID-003)
        2. Max silent stall: Time > max_silent_seconds, REGARDLESS of handler state (ISSUE-HYBRID-008)

        The max_silent_seconds timeout catches HTTP hangs and other silent failures
        that occur during handler execution when the normal watchdog is suppressed.

        Raises:
            OrchestratorError: If stall detected
        """
        if not self._watchdog.enabled:
            return

        elapsed = time.time() - self._watchdog.last_event_time

        # ISSUE-HYBRID-008: Check max_silent_seconds FIRST (applies regardless of handler state)
        # This catches HTTP hangs and other silent failures during handler execution
        if elapsed > self._watchdog.max_silent_seconds:
            # Log stall event with handler context before raising
            self._log_session_event(
                "stall_detected",
                elapsed_seconds=elapsed,
                max_silent_seconds=self._watchdog.max_silent_seconds,
                handler_active=self._watchdog.handler_active,
                during_handler=self._watchdog.handler_active,
            )
            session_id = self._state.session_id
            short_id = session_id.split("-")[0] if session_id else ""
            msg = (
                f"Session stalled during handler execution: no events for {int(elapsed)}s "
                f"(max_silent_seconds: {self._watchdog.max_silent_seconds}s). "
                "This may indicate HTTP connection hang or subprocess failure. "
                "Check hybrid.jsonl for last event."
                f"\n\nSession may be stuck. Try: {get_message('recovery.session.force_complete', short_id=short_id)}"
            )
            logger.error(msg)
            raise OrchestratorError(
                msg,
                session_id=session_id or "",
            )

        # ISSUE-HYBRID-003: Original stall check (only when handler NOT active)
        if self._watchdog.handler_active:
            # Handler is running and within max_silent_seconds - don't check normal timeout
            # The handler's LLM calls have their own monitoring (MonitoringThread)
            return

        if elapsed > self._watchdog.stall_timeout:
            # Log stall event before raising
            self._log_session_event(
                "stall_detected",
                elapsed_seconds=elapsed,
                stall_timeout_s=self._watchdog.stall_timeout,
                handler_active=False,
            )
            session_id = self._state.session_id
            short_id = session_id.split("-")[0] if session_id else ""
            msg = (
                f"Session stalled: no progress for {int(elapsed)}s "
                f"(threshold: {self._watchdog.stall_timeout}s). "
                "Check hybrid.jsonl for last event."
                f"\n\nSession may be stuck. Try: {get_message('recovery.session.force_complete', short_id=short_id)}"
            )
            logger.error(msg)
            raise OrchestratorError(
                msg,
                session_id=session_id or "",
            )

    def _check_cli_cache_health(self, check_type: str = "pre_session") -> None:
        """Check CLI tool cache directories and log warnings.

        CLI-CACHE-MONITOR-001: Monitor cache sizes to detect potential resource
        exhaustion during long coding sessions.

        Args:
            check_type: Type of check (pre_session, mid_session).
        """
        try:
            monitor = CLICacheMonitor(
                warn_threshold_mb=500,
                critical_threshold_mb=1000,
            )
            warnings = monitor.check_and_warn()

            for warning in warnings:
                # Log to production log for crash analysis
                self._log_session_event(
                    "cli_cache_warning",
                    check_type=check_type,
                    tool=warning.tool,
                    cache_path=warning.path,
                    size_mb=warning.size_mb,
                    threshold_mb=warning.threshold_mb,
                    severity=warning.severity,
                    message=warning.message,
                )

                # Also print to console for immediate visibility
                if warning.severity == "critical":
                    print_warning(
                        f"CRITICAL: {warning.tool.capitalize()} cache is {warning.size_mb:.0f}MB. "
                        f"Risk of resource exhaustion!"
                    )
                else:
                    print_warning(
                        f"{warning.tool.capitalize()} cache is large ({warning.size_mb:.0f}MB). "
                        f"Consider cleanup if session becomes unstable."
                    )
        except Exception as e:
            # Never let cache monitoring interrupt the main workflow
            logger.debug("CLI cache health check failed: %s", e)

    def _handle_session_timeout_warning(self, runtime_hours: float, warning_count: int) -> bool:
        """Handle session timeout warning prompt.

        FEAT-SESSION-GUARD-001: Called when session exceeds warning threshold.
        User input resets the timer for another warning period.

        Args:
            runtime_hours: Current runtime in hours
            warning_count: Number of times user has been warned

        Returns:
            True to continue session, False to terminate
        """
        import sys

        # Log the warning event
        self._log_session_event(
            "session_runtime_warning",
            runtime_hours=runtime_hours,
            warning_count=warning_count,
            items_completed=self._invocation.items_completed_this_invocation,
            phase=self._state.current_phase.value if self._state.current_phase else "unknown",
        )

        # Headless mode: auto-continue with warning
        from obra.hybrid.interaction_mode import current_mode_is_interactive

        if not current_mode_is_interactive():
            session_id = self._state.session_id
            logger.warning(
                f"Session {session_id} running for {runtime_hours:.1f}h "
                f"in headless mode, auto-continuing"
            )
            return True

        # Interactive prompt
        console.print()
        console.print(f"[yellow]Session has been running for {runtime_hours:.1f} hours.[/yellow]")
        console.print(f"Items completed: {self._invocation.items_completed_this_invocation}")
        current_phase = self._state.current_phase
        if current_phase:
            console.print(f"Current phase: {current_phase.value}")
        console.print()

        try:
            from obra.display.prompting import prompt_input

            response = prompt_input("Continue session? [Y/n]: ").strip().lower()
            if response in ("", "y", "yes"):
                console.print("[green]Continuing session...[/green]")
                # Record user activity to reset warning timer
                session_guard = self._session_guard_getter()
                if session_guard:
                    session_guard.record_user_activity()
                return True
            else:
                console.print("[dim]Stopping session...[/dim]")
                return False
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]Stopping session...[/dim]")
            return False

    def _update_session_guard(self) -> None:
        """Update session guard with current progress.

        FEAT-SESSION-GUARD-001: Called after each action to track progress.
        """
        session_guard = self._session_guard_getter()
        if session_guard:
            current_phase = self._state.current_phase
            session_guard.update(
                items_completed=self._invocation.items_completed_this_invocation,
                phase=current_phase.value if current_phase else "unknown",
            )
