"""Minimal event logger for hybrid mode observability (ISSUE-SAAS-042).

This module provides a standalone event logger that works in both:
- Development environment (running from source)
- Installed package (pip install obra)

The logger writes JSONL events to the resolved runtime log path.

Why this exists:
- ProductionLogger (src/monitoring/production_logger.py) is not packaged
- Sessions run from installed package had no event logging (silent failure)
- This minimal implementation provides observability for all obra users

Design principles:
- No dependencies on src/ modules (must work in installed package)
- Thread-safe for concurrent event logging
- Simple JSONL format compatible with ProductionLogger events
- Immediate flush for real-time monitoring
- ISSUE-OBS-003: Log rotation at 10MB with 5 backup files

Event Schemas (Derivation Pipeline - FEAT-UNIFIED-DERIVE-001):
- derivation_pipeline_started:
    session_id: str - Session identifier
    objective_length: int - Length of the objective string

- derivation_pipeline_completed:
    session_id: str - Session identifier
    total_duration_ms: int - Total pipeline duration in milliseconds
    total_tokens: int - Total tokens used across all steps
    item_count: int - Number of plan items produced

- derivation_pipeline_failed:
    session_id: str - Session identifier
    failed_at_step: int - Step number where failure occurred (1-3)
    step_name: str - Step name (structure/tasks/serialize)
    error_type: str - Error class name
    error_message: str - Error description

- derivation_step_completed:
    session_id: str - Session identifier
    step: int - Step number (1-3)
    step_name: str - Step name (structure/tasks/serialize)
    duration_ms: int - Step duration in milliseconds
    input_tokens: int - Input tokens for this step
    output_tokens: int - Output tokens for this step
    items_produced: int - Number of items produced in this step

- derivation_stall_warning:
    session_id: str - Session identifier
    step: int - Step number (1-3)
    step_name: str - Step name (structure/tasks/serialize)
    no_output_seconds: int - Seconds with no output from LLM
"""

import json
import logging
import time
import uuid
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from pathlib import Path
from threading import Lock
from typing import Any

from obra.constants import EVENT_LOG_MAX_BACKUP_COUNT, EVENT_LOG_MAX_SIZE_BYTES
from obra.utils.obra_home import get_runtime_dir

try:
    from obra.telemetry.events import TelemetryEvent
except ImportError:  # pragma: no cover — graceful if telemetry not yet loaded
    TelemetryEvent = None  # type: ignore[assignment, misc]

# Log rotation settings
MAX_LOG_SIZE_BYTES = EVENT_LOG_MAX_SIZE_BYTES  # 10MB
MAX_BACKUP_COUNT = EVENT_LOG_MAX_BACKUP_COUNT  # Keep 5 rotated files

logger = logging.getLogger(__name__)


def _canonical_to_local_iso(canonical_ts: str, fallback_local_iso: str) -> str:
    """Convert canonical timestamp string to local ISO8601, fallback on parse failure."""
    raw_ts = str(canonical_ts or "").strip()
    if not raw_ts:
        return fallback_local_iso
    normalized = raw_ts[:-1] + "+00:00" if raw_ts.endswith("Z") else raw_ts
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        return fallback_local_iso
    if parsed.tzinfo is None:
        return fallback_local_iso
    return parsed.astimezone().isoformat()


def _ensure_event_modules_loaded() -> None:
    """Import all event definition modules to populate the registry."""
    # fmt: off
    import obra.telemetry.events.client
    import obra.telemetry.events.derivation
    import obra.telemetry.events.escalation
    import obra.telemetry.events.fix
    import obra.telemetry.events.intent
    import obra.telemetry.events.item
    import obra.telemetry.events.llm
    import obra.telemetry.events.monitoring
    import obra.telemetry.events.pipeline
    import obra.telemetry.events.progress
    import obra.telemetry.events.quality
    import obra.telemetry.events.refinement
    import obra.telemetry.events.review
    import obra.telemetry.events.session
    import obra.telemetry.events.template  # noqa: F401
    # fmt: on


def _build_forward_events() -> frozenset[str]:
    """Compute forwarded event types from the telemetry registry.

    Not cached — EventRegistry._reset() may be called in tests, and caching
    would serve stale results. The computation cost is negligible (dict
    comprehension over ~149 entries) and module imports are cached by Python.

    Self-heals if the registry was emptied by _reset() in tests by calling
    _repopulate() when the registry appears empty.
    """
    _ensure_event_modules_loaded()
    from obra.telemetry.registry import EventRegistry

    result = EventRegistry.get_forward_events()
    if not result and not EventRegistry.all_event_types():
        EventRegistry._repopulate()
        result = EventRegistry.get_forward_events()
    return frozenset(result)


def _build_suppressed_events() -> frozenset[str]:
    """Compute suppressed event types from the telemetry registry.

    Not cached — see _build_forward_events() rationale.
    """
    _ensure_event_modules_loaded()
    from obra.telemetry.registry import EventRegistry

    result = EventRegistry.get_suppressed_events()
    if not result and not EventRegistry.all_event_types():
        EventRegistry._repopulate()
        result = EventRegistry.get_suppressed_events()
    return frozenset(result)


# Legacy reference: original PRODUCTION_FORWARD_EVENTS
# {
#     "review_completed", "review_loop_completed", "review_score_finalized",
#     "fix_completed", "fix_scope_warning", "fix_scope_exceeded",
#     "escalation_decision", "session_completed", "pipeline_completed",
#     "item_started", "item_completed", "session_interrupted",
#     "closeout_rendered", "refinement_parallel_examine",
#     "refinement_parallel_revise", "parallelization_cycle_summary",
#     "parallelization_session_summary", "batch_straggler_alert",
#     "fix_started", "fix_issue_result", "prompt_displayed",
#     "prompt_response", "prompt_skipped_reason",
# }

# Legacy reference: original PRODUCTION_SUPPRESSED_EVENTS
# {
#     "client_request_started", "client_request_completed",
#     "client_request_interrupted", "refinement_batch_completed",
#     "progress_stage_heartbeat", "resource_snapshot", "llm_call",
#     "slow_llm_call", "template_created", "template_read",
#     "parse_attempt", "parse_success", "parse_error",
#     "template_unchanged_detected", "template_unchanged_rejected",
#     "template_unchanged_short_circuit", "session_started",
#     "session_failed", "session_resumed", "session_runtime_warning",
#     "stall_detected", "cli_cache_warning", "phase_started",
#     "phase_completed", "phase_failed", "subphase_started",
#     "subphase_completed", "pipeline_started", "pipeline_failed",
#     "derivation_started", "derivation_complete", "derived_plan_snapshot",
#     "userplan_snapshot", "intent_snapshot", "intent_generated",
#     "story0_snapshot", "escalation_prompt_waiting", "item_skipped",
#     "revision_merge_rejected", "report_revision", "examine_start",
#     "examine_complete", "examine_failed", "revise_start",
#     "revise_complete", "revise_failed", "refinement_guard_triggered",
#     "derived_plan_item_keys_dropped", "c9_non_fixable_findings",
# }


class _LazyRegistrySet:
    """Descriptor that lazily computes a frozenset from the telemetry registry.

    Works for both class-level (``HybridEventLogger.PRODUCTION_FORWARD_EVENTS``)
    and instance-level (``self.PRODUCTION_FORWARD_EVENTS``) access.
    """

    def __init__(self, builder: Callable[[], frozenset[str]]) -> None:
        self._builder = builder

    def __set_name__(self, owner: type, name: str) -> None:
        self._attr = name

    def __get__(self, obj: Any, objtype: type | None = None) -> frozenset[str]:
        return self._builder()


class HybridEventLogger:
    """Minimal JSONL event logger for hybrid mode.

    Thread-safe event logger that writes structured events to a JSONL file.
    Compatible with ProductionLogger event format for tooling compatibility.

    FIX-HYBRID-053: Optionally forwards key lifecycle events to the
    production logger to close the production observability gap.

    Forwarding policy is derived from the telemetry EventRegistry — see
    ``_build_forward_events()`` and ``_build_suppressed_events()``.

    Example:
        >>> logger = HybridEventLogger()
        >>> logger.log_event("session_started", session_id="abc-123", objective="test")
    """

    PRODUCTION_FORWARD_EVENTS = _LazyRegistrySet(_build_forward_events)
    PRODUCTION_SUPPRESSED_EVENTS = _LazyRegistrySet(_build_suppressed_events)

    # DEPRECATED: Superseded by dataclass required fields in obra.telemetry.events.*.
    # This dict covers only 3 events with best-effort validation (no raise). The new
    # emit(TelemetryEvent) API validates required fields via dataclass construction
    # (TypeError on missing args). Remove this dict in Phase 2 when all log_event()
    # call sites are migrated to emit(). See REFACTOR-TELEMETRY-001.
    # TODO(REFACTOR-TELEMETRY-Phase2): Remove REQUIRED_EVENT_FIELDS after log_event() migration.
    REQUIRED_EVENT_FIELDS: dict[str, tuple[str, ...]] = {
        "session_interrupted": ("reason", "tasks_completed", "tasks_total"),
        "review_score_finalized": ("score", "threshold", "passed"),
        "closeout_rendered": ("state", "tasks_completed", "tasks_total"),
    }
    _CONTEXT_FIELDS: tuple[tuple[str, str], ...] = (
        ("trace_id", "_trace_id"),
        ("span_id", "_span_id"),
        ("parent_span_id", "_parent_span_id"),
        ("component", "_component"),
        ("work_unit_id", "_work_unit_id"),
        ("project_id", "_project_id"),
        ("project_name", "_project_name"),
        ("invocation_id", "_invocation_id"),
        ("attempt_id", "_invocation_id"),
        ("invocation_index", "_invocation_index"),
        ("attempt_index", "_invocation_index"),
    )

    def __init__(
        self,
        log_path: Path | None = None,
        production_logger: Any | None = None,
    ):
        """Initialize HybridEventLogger.

        Args:
            log_path: Path to log file. Defaults to the runtime hybrid.jsonl log.
            production_logger: Optional ProductionLogger instance for forwarding
                key lifecycle events (FIX-HYBRID-053).
        """
        self._lock = Lock()
        self._log_path = log_path or self._get_default_log_path()
        self._production_logger = production_logger
        # Monotonic-offset clock: immune to NTP/WSL2 clock corrections.
        # Same pattern as orchestrator._request_with_observability (line 1200).
        self._clock_ref_wall = datetime.now(UTC)
        self._clock_ref_mono = time.perf_counter()
        self._trace_id: str | None = None
        self._span_id: str | None = None
        self._parent_span_id: str | None = None
        self._component: str | None = "hybrid_client"
        self._work_unit_id: str | None = None
        self._project_id: str | None = None
        self._project_name: str | None = None
        self._session_id: str | None = None
        self._invocation_id: str | None = None
        self._invocation_index: int | None = None
        self._subphase_span_id: str | None = None
        self._active_subphase: str | None = None
        self._active_subphase_start_time: float | None = None
        self._phase_span_id: str | None = None
        # REFACTOR-TELEMETRY-002 S2.T0: Terminal-event flags (moved from orchestrator)
        self.session_completed_logged: bool = False
        self.session_interrupted_logged: bool = False

        # Ensure log directory exists
        self._log_path.parent.mkdir(parents=True, exist_ok=True)

        logger.debug(f"HybridEventLogger initialized: {self._log_path}")

    def set_trace_context(
        self,
        trace_id: str,
        span_id: str | None = None,
        parent_span_id: str | None = None,
    ) -> None:
        """Set trace context for subsequent log events."""
        self._trace_id = trace_id
        if span_id:
            self._span_id = span_id
        if parent_span_id:
            self._parent_span_id = parent_span_id

    def set_component(self, component: str) -> None:
        """Set component label for subsequent log events."""
        self._component = component

    def set_work_unit(self, work_unit_id: str | None) -> None:
        """Set work unit ID for subsequent log events."""
        self._work_unit_id = work_unit_id

    def set_project(self, project_id: str | None, project_name: str | None = None) -> None:
        """Set project context for subsequent log events.

        Args:
            project_id: Project ID (UUID or short form)
            project_name: Human-readable project name (optional)
        """
        self._project_id = project_id
        self._project_name = project_name

    def set_session_context(
        self,
        session_id: str,
        invocation_id: str | None = None,
        invocation_index: int | None = None,
    ) -> None:
        """Set session context for auto-injection into subsequent log events.

        Args:
            session_id: Session identifier to auto-inject when log_event is called
                with an empty session_id.
            invocation_id: Optional invocation UUID; auto-injected as both
                invocation_id and attempt_id aliases.
            invocation_index: Optional invocation counter; auto-injected as both
                invocation_index and attempt_index aliases.
        """
        self._session_id = session_id
        if invocation_id is not None:
            self._invocation_id = invocation_id
        if invocation_index is not None:
            self._invocation_index = invocation_index

    def set_phase_span_id(self, span_id: str | None) -> None:
        """Set the current phase span ID for use as parent in subphase events."""
        self._phase_span_id = span_id

    @property
    def subphase_span_id(self) -> str | None:
        """Current subphase span ID, or None if no subphase is active."""
        return self._subphase_span_id

    def start_subphase(self, subphase: str) -> float:
        """Start a subphase span and return its start time.

        Args:
            subphase: Name of the subphase (e.g. "intent", "derive").

        Returns:
            Wall-clock start time (``time.time()``).
        """
        self._subphase_span_id = uuid.uuid4().hex
        self._active_subphase = subphase
        self._active_subphase_start_time = time.time()
        self.log_event(
            "subphase_started",
            subphase=subphase,
            span_id=self._subphase_span_id,
            parent_span_id=self._phase_span_id,
        )
        return self._active_subphase_start_time

    def complete_subphase(
        self,
        subphase: str,
        start_time: float,
        status: str = "success",
        error_message: str | None = None,
        active_duration_ms: int | None = None,
    ) -> None:
        """Complete subphase span with duration and status.

        Args:
            subphase: Name of the subphase (e.g. "intent", "derive").
            start_time: Wall-clock start time (``time.time()``).
            status: Completion status string.
            error_message: Optional error message if status is not success.
            active_duration_ms: Optional active-compute duration excluding user
                idle time. When provided, emitted alongside ``wall_clock_ms``.
        """
        wall_clock_ms = int((time.time() - start_time) * 1000)
        extras: dict[str, Any] = {}
        if active_duration_ms is not None:
            extras["wall_clock_ms"] = wall_clock_ms
            extras["active_duration_ms"] = active_duration_ms
        self.log_event(
            "subphase_completed",
            subphase=subphase,
            duration_ms=wall_clock_ms,
            status=status,
            error_message=error_message,
            span_id=self._subphase_span_id,
            parent_span_id=self._phase_span_id,
            **extras,
        )
        self._subphase_span_id = None
        self._active_subphase = None
        self._active_subphase_start_time = None

    def interrupt_active_subphase(self, reason: str) -> str | None:
        """Close active subphase with interrupted status.

        Args:
            reason: Interruption reason to record as error_message.

        Returns:
            Interrupted subphase name when one was active, else ``None``.
        """
        if self._active_subphase is None or self._active_subphase_start_time is None:
            return None

        subphase = self._active_subphase
        self.complete_subphase(
            subphase,
            self._active_subphase_start_time,
            status="interrupted",
            error_message=reason,
        )
        return subphase

    def emit_atexit_interrupted(self, **payload_kwargs: Any) -> None:
        """Safety-net: emit session_interrupted if session ended without terminal event.

        No-op when either terminal flag is already set or no session_id is known.
        Wraps emission in try/except so atexit handlers never raise.
        """
        if self.session_completed_logged or self.session_interrupted_logged:
            return
        if not self._session_id:
            return
        try:
            self.session_interrupted_logged = True
            self.log_event("session_interrupted", **payload_kwargs)
        except Exception:
            pass

    @property
    def has_terminal_event(self) -> bool:
        """Whether a terminal event (session_completed or session_interrupted) has been logged."""
        return self.session_completed_logged or self.session_interrupted_logged

    def emit_session_still_active_marker(self) -> None:
        """Emit a diagnostic marker when no terminal event has been logged.

        SESSION-92257c4c: When analyzing session telemetry, the absence of both
        session_completed and session_interrupted makes it ambiguous whether the
        session is still running or crashed. This marker provides an explicit
        timestamp so diagnostics can say "last seen at X" instead of leaving
        the session state unknown.
        """
        if self.has_terminal_event:
            return
        if not self._session_id:
            return
        try:
            self.log_event(
                "session_still_active",
                session_id=self._session_id,
                note="No terminal event logged — session may still be running or crashed without cleanup",
            )
        except Exception:
            pass

    def log_pipeline_completed(
        self,
        pipeline_start_time: float | None,
        pipeline_span_id: str | None,
    ) -> None:
        """Log pipeline completion with duration and a resource snapshot.

        Args:
            pipeline_start_time: Wall-clock time when pipeline started, or None
                to skip emission.
            pipeline_span_id: Active pipeline span ID for correlation.
        """
        if pipeline_start_time is None:
            return
        duration_ms = int((time.time() - pipeline_start_time) * 1000)
        self.log_event("pipeline_completed", duration_ms=duration_ms, span_id=pipeline_span_id)
        self.log_event("resource_snapshot", snapshot_type="pipeline_end")

    def log_closeout_rendered(
        self,
        banner_mode: str,
        *,
        state: str,
        quality_score: float | None,
        quality_status: str,
        epics_completed: int,
        epics_total: int,
        stories_completed: int,
        stories_total: int,
        tasks_completed: int,
        tasks_total: int,
    ) -> None:
        """Log closeout rendering details for telemetry correlation.

        Args:
            banner_mode: Banner variant used by CLI closeout rendering.
            state: Session termination state shown in closeout.
        """
        if not self._session_id:
            return
        self.log_event(
            "closeout_rendered",
            banner_mode=banner_mode,
            state=state,
            quality_score=quality_score,
            quality_status=quality_status,
            epics_completed=epics_completed,
            epics_total=epics_total,
            stories_completed=stories_completed,
            stories_total=stories_total,
            tasks_completed=tasks_completed,
            tasks_total=tasks_total,
        )

    def log_governor_wait(self, provider: str, wait_ms: float, queue_depth: int) -> None:
        """Log a governor permit wait event.

        Emits ``governor_permit_waited`` when the concurrency governor had to
        wait before granting a permit.  Follows the existing :meth:`log_event`
        pattern.

        The wiring is automatic — both LLM chokepoints pass their
        ``log_event`` callback through :func:`~obra.llm.governor.LLMConcurrencyGovernor.permit`,
        so calls backed by this logger appear in production.jsonl without
        any additional singleton coupling.

        Args:
            provider: LLM provider name (e.g. ``'anthropic'``, ``'google'``).
            wait_ms: Time spent waiting for the permit in milliseconds.
            queue_depth: Approximate number of concurrent callers at grant time.
        """
        self.log_event(
            "governor_permit_waited",
            provider=provider,
            wait_ms=wait_ms,
            queue_depth=queue_depth,
        )

    @staticmethod
    def _get_default_log_path() -> Path:
        """Get the default log file path.

        Returns:
            Path to the resolved runtime hybrid.jsonl log
        """
        runtime_dir = get_runtime_dir()
        return runtime_dir / "logs" / "hybrid.jsonl"

    def _rotate_if_needed(self) -> None:
        """Rotate log file if it exceeds MAX_LOG_SIZE_BYTES.

        ISSUE-OBS-003: Implements simple log rotation to prevent unbounded growth.
        Rotates to .1, .2, etc. and keeps MAX_BACKUP_COUNT backups.
        """
        try:
            if not self._log_path.exists():
                return

            current_size = self._log_path.stat().st_size
            if current_size < MAX_LOG_SIZE_BYTES:
                return

            # Rotate existing backups (.5 -> deleted, .4 -> .5, etc.)
            for i in range(MAX_BACKUP_COUNT, 0, -1):
                old_path = self._log_path.with_suffix(f".jsonl.{i}")
                if i == MAX_BACKUP_COUNT:
                    # Delete oldest backup
                    if old_path.exists():
                        old_path.unlink()
                else:
                    # Rename to next number
                    new_path = self._log_path.with_suffix(f".jsonl.{i + 1}")
                    if old_path.exists():
                        old_path.rename(new_path)

            # Rotate current file to .1
            backup_path = self._log_path.with_suffix(".jsonl.1")
            self._log_path.rename(backup_path)

            logger.info(f"Rotated log file: {self._log_path} -> {backup_path}")

        except Exception as e:
            # Never fail logging due to rotation errors
            logger.warning(f"Log rotation failed: {e}")

    def _normalize_event_payload(self, event_type: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Normalize event payload aliases before persistence/forwarding."""
        normalized = dict(payload)
        if event_type in {"agent_started", "agent_completed"}:
            agent_name = (
                normalized.get("agent_name")
                or normalized.get("agent")
                or normalized.get("agent_type")
            )
            if agent_name:
                normalized["agent_name"] = str(agent_name)
                normalized.setdefault("agent", str(agent_name))
        return normalized

    def _validate_required_fields(self, event_type: str, payload: dict[str, Any]) -> None:
        """Best-effort contract validation for critical telemetry events."""
        required = self.REQUIRED_EVENT_FIELDS.get(event_type)
        if not required:
            return
        missing = [
            field
            for field in required
            if field not in payload or payload[field] is None or payload[field] == ""
        ]
        if missing:
            logger.debug(
                "Event '%s' missing required field(s): %s",
                event_type,
                ", ".join(missing),
            )

    def _resolve_canonical_timestamp(
        self,
        event_kwargs: dict[str, Any],
        emission_iso: str,
        local_iso: str,
    ) -> tuple[str, str, dict[str, Any]]:
        """Resolve canonical and local timestamps from event kwargs."""
        event_time = str(event_kwargs.pop("event_time", "")).strip()
        canonical_ts = event_time or emission_iso
        if "timestamp" in event_kwargs and not event_time:
            caller_ts = str(event_kwargs.pop("timestamp")).strip()
            if caller_ts:
                canonical_ts = caller_ts
        canonical_local_iso = _canonical_to_local_iso(canonical_ts, local_iso)
        return canonical_ts, canonical_local_iso, event_kwargs

    def _inject_logger_context(self, event: dict[str, Any]) -> None:
        """Populate missing logger context fields on the event payload."""
        for field, attr in self._CONTEXT_FIELDS:
            value = getattr(self, attr, None)
            if field not in event and value is not None:
                event[field] = value

    def _write_event_and_update_flags(self, event: dict[str, Any], event_type: str) -> None:
        """Append a JSONL record and update terminal session flags."""
        with self._log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event, default=str) + "\n")
            f.flush()
        if event_type in ("session_completed", "pipeline_completed"):
            self.session_completed_logged = True
        if event_type == "session_interrupted":
            self.session_interrupted_logged = True

    def log_event(self, event_type: str, session_id: str = "", **kwargs: Any) -> None:
        """Log a structured event to the JSONL file.

        Args:
            event_type: Type of event (session_started, phase_started, etc.)
            session_id: Session ID for event correlation
            **kwargs: Event-specific data. Pass ``event_time`` (ISO string) to
                record the canonical time the event occurred (before any async
                pipeline). When omitted, emission time is used.

        Example:
            >>> logger.log_event(
            ...     "derivation_started",
            ...     session_id="abc-123",
            ...     objective="Build calculator app"
            ... )
        """
        event_kwargs = self._normalize_event_payload(event_type, kwargs)
        forward_work_unit = event_kwargs.get("work_unit_id", self._work_unit_id)
        forward_payload: dict[str, Any] = {}

        # Auto-inject stored session_id when caller passes empty string
        if not session_id and self._session_id:
            session_id = self._session_id

        with self._lock:
            try:
                # ISSUE-OBS-003: Check for log rotation before writing
                self._rotate_if_needed()

                # Derive timestamps from monotonic offset to prevent
                # WSL2/NTP clock corrections from inverting event order.
                elapsed = time.perf_counter() - self._clock_ref_mono
                now_utc = self._clock_ref_wall + timedelta(seconds=elapsed)
                emission_iso = now_utc.isoformat()
                local_iso = now_utc.astimezone().isoformat()

                canonical_ts, canonical_local_iso, event_kwargs = self._resolve_canonical_timestamp(
                    event_kwargs,
                    emission_iso,
                    local_iso,
                )

                self._validate_required_fields(event_type, event_kwargs)

                event: dict[str, Any] = {
                    "type": event_type,
                    "event_type": event_type,
                    "ts": canonical_ts,
                    "timestamp": canonical_ts,
                    "timestamp_local": canonical_local_iso,
                    "occurred_at": canonical_ts,
                    "emitted_at": emission_iso,
                    "emitted_at_local": local_iso,
                    "session": session_id,
                    **event_kwargs,
                }
                # Preserve legacy emission_time for backward compatibility
                if canonical_ts != emission_iso:
                    event["emission_time"] = emission_iso

                self._inject_logger_context(event)

                # Keep production-forwarded timestamps and context aligned
                # with the fully enriched hybrid event.
                forward_work_unit = event.get("work_unit_id") or self._work_unit_id
                forward_payload = {
                    k: v
                    for k, v in event.items()
                    if k not in {"type", "event_type", "work_unit_id"}
                }
                forward_payload["session_id"] = str(
                    forward_payload.get("session_id") or event.get("session") or session_id
                )

                self._write_event_and_update_flags(event, event_type)

            except Exception as e:
                # Never fail the main operation due to logging
                logger.warning(f"Failed to log event '{event_type}': {e}")

        # FIX-HYBRID-053: Forward key lifecycle events to production.jsonl
        if self._production_logger and event_type in self.PRODUCTION_FORWARD_EVENTS:
            try:
                self._production_logger.log_event(
                    event_type,
                    work_unit_id=forward_work_unit,
                    **forward_payload,
                )
            except Exception as e:
                logger.debug("Failed to forward '%s' to production: %s", event_type, e)

    def emit(self, event: "TelemetryEvent") -> None:
        """Emit a typed telemetry event via log_event().

        Typed wrapper around :meth:`log_event` that accepts a
        :class:`~obra.telemetry.events.TelemetryEvent` dataclass instance.
        All existing log_event() behaviour is preserved — timestamp injection,
        rotation, validation, and production forwarding.

        Context injection safety: base class context fields (component,
        work_unit_id, project_id, project_name) default to ``None`` and
        ``to_dict()`` excludes them, so the logger's own context values
        are injected by the guards at log_event() time.

        Args:
            event: A TelemetryEvent dataclass instance.
        """
        if TelemetryEvent is None:
            raise RuntimeError("obra.telemetry package not available")
        event_dict = event.to_dict()
        session_id = event_dict.pop("session_id", event.session_id or "")
        self.log_event(
            event.event_type,
            session_id=session_id,
            **{k: v for k, v in event_dict.items() if k != "event_type"},
        )


# Module-level singleton for convenience
_hybrid_logger: HybridEventLogger | None = None


def get_hybrid_logger() -> HybridEventLogger:
    """Get or create the module-level HybridEventLogger instance.

    Returns:
        HybridEventLogger singleton instance
    """
    global _hybrid_logger
    if _hybrid_logger is None:
        _hybrid_logger = HybridEventLogger()
    return _hybrid_logger


TERMINAL_EVENT_TYPES = frozenset({"session_completed", "session_interrupted"})


def check_session_terminal_state(events: list[dict[str, Any]]) -> dict[str, Any]:
    """Analyze a list of session events for terminal state.

    SESSION-92257c4c: Utility for diagnostics tools to determine whether
    a session ended cleanly. Returns a dict with terminal state info.

    Args:
        events: List of parsed event dicts from hybrid.jsonl

    Returns:
        Dict with keys:
        - has_terminal_event: bool
        - terminal_event_type: str | None
        - terminal_timestamp: str | None
        - last_event_timestamp: str | None
        - last_event_type: str | None
        - session_may_be_active: bool (True if no terminal event found)
    """
    terminal_event: dict[str, Any] | None = None
    last_event: dict[str, Any] | None = None

    for event in events:
        event_type = event.get("event_type") or event.get("type") or ""
        last_event = event
        if event_type in TERMINAL_EVENT_TYPES:
            terminal_event = event

    has_terminal = terminal_event is not None
    return {
        "has_terminal_event": has_terminal,
        "terminal_event_type": (
            (terminal_event.get("event_type") or terminal_event.get("type"))
            if terminal_event
            else None
        ),
        "terminal_timestamp": terminal_event.get("timestamp") if terminal_event else None,
        "last_event_timestamp": last_event.get("timestamp") if last_event else None,
        "last_event_type": (
            (last_event.get("event_type") or last_event.get("type")) if last_event else None
        ),
        "session_may_be_active": not has_terminal,
    }


__all__ = ["HybridEventLogger", "check_session_terminal_state", "get_hybrid_logger"]
