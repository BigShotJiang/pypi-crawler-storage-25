"""Error and interrupt handling for HybridOrchestrator.

Extracted from obra/hybrid/orchestrator.py as part of REFACTOR-ORCH-EXTRACT-001.
Handles error context building, crash snapshots, interrupt finalization,
and session interrupted telemetry.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from obra.api.protocol import SessionPhase
from obra.api.protocol_core import FixStatus
from obra.core.interrupts import interrupt_reason, interrupt_requested
from obra.exceptions import ErrorContext
from obra.hybrid.event_logger import HybridEventLogger
from obra.utils.obra_home import get_runtime_dir

if TYPE_CHECKING:
    from obra.hybrid.orchestrator import (
        InvocationState,
        RefinementState,
        TraceContext,
        WatchdogState,
    )
    from obra.hybrid.runtime_state import HybridRuntimeState

logger = logging.getLogger(__name__)


class ErrorHandler:
    """Error and interrupt handling extracted from HybridOrchestrator.

    Handles error context building, crash snapshots, redacted server action
    retrieval, termination type classification, interrupt finalization, and
    session interrupted telemetry emission.
    Receives shared state via constructor injection.
    """

    def __init__(
        self,
        invocation: InvocationState,
        trace: TraceContext,
        watchdog: WatchdogState,
        refinement: RefinementState,
        event_logger: HybridEventLogger,
        runtime_state: HybridRuntimeState,
        was_escalated_getter: Callable[[], bool],
        locally_completed_phases: set[str],
        emit_progress: Callable[[str, dict[str, Any]], None],
        session_completed_logged_getter: Callable[[], bool],
        session_interrupted_logged_getter: Callable[[], bool],
        session_interrupted_logged_setter: Callable[[bool], None],
    ) -> None:
        self._invocation = invocation
        self._trace = trace
        self._watchdog = watchdog
        self._refinement = refinement
        self._event_logger = event_logger
        self._state = runtime_state
        self._was_escalated_getter = was_escalated_getter
        self._locally_completed_phases = locally_completed_phases
        self._emit_progress = emit_progress
        self._session_completed_logged_getter = session_completed_logged_getter
        self._session_interrupted_logged_getter = session_interrupted_logged_getter
        self._session_interrupted_logged_setter = session_interrupted_logged_setter

    def _log_session_event(self, event_type: str, **kwargs) -> None:
        kwargs.pop("session_id", None)
        session_id = self._state.session_id or ""
        try:
            self._event_logger.log_event(event_type, session_id=session_id, **kwargs)
            self._watchdog.last_event_time = time.time()
        except Exception as e:
            logger.warning(f"Failed to log hybrid event '{event_type}': {e}")

    def _build_error_context(
        self, phase: str | None = None, action: str | None = None
    ) -> ErrorContext:
        """Build ErrorContext for error enrichment.

        Creates an ErrorContext with current session state for inclusion
        in OrchestratorError instances. Enables better debugging by
        including session ID, project ID, current phase, and log path.

        Args:
            phase: Override phase (defaults to _current_phase if set)
            action: Specific action that failed (e.g., 'poll_session', 'derive')

        Returns:
            ErrorContext populated with available session metadata
        """
        # Use explicit phase or current tracking phase
        effective_phase = phase
        current_phase = self._state.current_phase
        if effective_phase is None and current_phase is not None:
            effective_phase = current_phase.value

        return ErrorContext(
            session_id=self._state.session_id,
            project_id=self._state.project_id,
            phase=effective_phase,
            action=action,
            log_path=str(get_runtime_dir() / "logs" / "hybrid.jsonl"),
        )

    def get_crash_snapshot(self) -> dict[str, Any]:
        """Build a snapshot of orchestrator state for crash/bug reports.

        Returns non-sensitive orchestration metadata useful for diagnosing
        crashes without exposing prompts, user content, or credentials.

        Returns:
            Dictionary with session state, phase, and last action metadata.
        """
        current_phase = self._state.current_phase
        snapshot: dict[str, Any] = {
            "session_id": self._state.session_id,
            "phase": current_phase.value if current_phase else None,
            "last_item_id": self._state.last_item_id,
            "items_completed": self._invocation.items_completed_this_invocation,
            "refinement_cycles": self._refinement.cycle_count,
            "polling_failures": self._state.polling_failure_count,
            "degraded_mode": self._state.degraded_mode,
            "was_escalated": self._was_escalated_getter(),
        }
        # Runtime duration
        if self._invocation.invocation_start_time:
            snapshot["runtime_s"] = round(time.time() - self._invocation.invocation_start_time, 1)
        # Last action metadata (type + structural keys only, no prompt content)
        if self._watchdog.last_action_payload:
            snapshot["last_action_keys"] = sorted(self._watchdog.last_action_payload.keys())
            # Include execution_index if present (helps locate crash point in plan)
            if "execution_index" in self._watchdog.last_action_payload:
                snapshot["execution_index"] = self._watchdog.last_action_payload["execution_index"]
            if "plan_items" in self._watchdog.last_action_payload:
                snapshot["plan_item_count"] = len(self._watchdog.last_action_payload["plan_items"])
        return snapshot

    def get_last_server_action_redacted(self) -> dict[str, Any]:
        """Return the last server action payload with sensitive fields redacted.

        Redacts prompt content, base_prompt, and any field containing
        user-authored content. Preserves structural metadata needed
        for crash diagnosis (action type, field names, item IDs, counts).

        Returns:
            Redacted copy of the last server action payload.
        """
        if not self._watchdog.last_action_payload:
            return {}

        # Fields that may contain user/LLM content — redact values
        redact_keys = {
            "base_prompt",
            "prompt",
            "system_prompt",
            "user_prompt",
            "objective",
            "description",
            "acceptance_criteria",
            "context",
            "rationale",
            "instructions",
        }

        def _redact(obj: Any, depth: int = 0) -> Any:
            if depth > 4:
                return "<truncated>"
            if isinstance(obj, dict):
                result = {}
                for k, v in obj.items():
                    if k in redact_keys:
                        result[k] = f"<redacted, {len(str(v))} chars>"
                    elif isinstance(v, (dict, list)):
                        result[k] = _redact(v, depth + 1)
                    elif isinstance(v, str) and len(v) > 500:
                        result[k] = f"<string, {len(v)} chars>"
                    else:
                        result[k] = v
                return result
            if isinstance(obj, list):
                if len(obj) > 10:
                    return [_redact(obj[0], depth + 1), f"... ({len(obj)} items)"]
                return [_redact(item, depth + 1) for item in obj]
            return obj

        return _redact(self._watchdog.last_action_payload)

    def _get_termination_type(self) -> str:
        """Get the termination type for the current invocation.

        FEAT-SESSION-CLOSEOUT-001: Used for invocation history tracking.

        Returns:
            One of: 'completed', 'escalated', 'interrupted', 'error'
        """
        if self._invocation.was_interrupted or interrupt_requested():
            return "interrupted"
        if self._was_escalated_getter():
            return "escalated"
        # Check for error state (could be indicated by various conditions)
        # Currently we don't have a dedicated error flag, so default to completed
        # if neither interrupted nor escalated
        return "completed"

    def _build_session_interrupted_payload(self, *, reason: str) -> dict[str, Any]:
        """Build canonical session_interrupted payload across all exit paths."""
        current_phase = self._state.current_phase
        tasks_total = self._state.tasks_total
        last_phase = current_phase.value if current_phase else "unknown"

        # SESSION-92257c4c: Warn if tasks_total is still 0 (pre-derivation
        # interrupt or resume path didn't populate it).
        if tasks_total == 0:
            logger.warning(
                "session_interrupted: tasks_total=0 (interrupted before derivation "
                "or tasks_total not restored on resume), last_phase=%s",
                last_phase,
            )
        if last_phase == "unknown":
            logger.warning(
                "session_interrupted: last_phase=unknown — phase was not set before interrupt"
            )

        interrupted_kwargs: dict[str, Any] = {
            "reason": reason,
            "tasks_completed": self._invocation.items_completed_this_invocation,
            "tasks_total": tasks_total,
            "last_phase": last_phase,
            "was_escalated": self._was_escalated_getter(),
        }
        fix_result_history = self._state.fix_result_history
        if fix_result_history:
            failed: list[dict[str, Any]] = []
            latest_status_by_issue: dict[str, str] = {}
            for fix_result in fix_result_history:
                status = str(fix_result.get("status") or "").strip().lower()
                if status in {"error", "failure"}:
                    status = "failed"
                if not status:
                    continue
                if status == FixStatus.FAILED.value:
                    failed.append(fix_result)
                canonical_id = str(
                    fix_result.get("canonical_id") or fix_result.get("issue_id") or ""
                ).strip()
                if canonical_id:
                    latest_status_by_issue[canonical_id] = status
            if failed:
                interrupted_kwargs["fix_failure_summary"] = {
                    "total_attempts": len(fix_result_history),
                    "failed": len(failed),
                    "unresolved_canonical_ids": sorted(
                        canonical_id
                        for canonical_id, status in latest_status_by_issue.items()
                        if status == FixStatus.FAILED.value
                    ),
                }
        return interrupted_kwargs

    def _resolve_interrupt_reason(self, *, fallback: str) -> str:
        """Resolve a stable interruption reason with explicit fallback."""
        resolved = str(interrupt_reason() or "").strip()
        return resolved or fallback

    def _finalize_active_phase_for_interrupt(self, *, reason: str) -> None:
        """Best-effort closure of active subphase/phase telemetry on interrupt."""
        interrupted_subphase: str | None = None
        interrupt_subphase = getattr(self._event_logger, "interrupt_active_subphase", None)
        if callable(interrupt_subphase):
            try:
                candidate = interrupt_subphase(reason)
            except Exception:
                candidate = None
            interrupted_subphase = candidate if isinstance(candidate, str) else None

        current_phase = self._state.current_phase
        if current_phase and interrupted_subphase:
            self._log_session_event(
                "phase_failed",
                phase=current_phase.value,
                failure_stage=interrupted_subphase or "interrupt",
                error_code="SESSION_INTERRUPTED",
                error_class="GracefulInterrupt",
                error_message=reason,
                span_id=self._trace.phase_span_id,
                parent_span_id=self._trace.pipeline_span_id,
            )

        if current_phase is None or self._state.phase_start_time is None:
            return

        duration_ms = int((time.time() - self._state.phase_start_time) * 1000)
        self._emit_progress(
            "phase_completed",
            {
                "phase": current_phase.value,
                "duration_ms": duration_ms,
                "result": {"interrupted": True, "reason": reason},
            },
        )
        self._locally_completed_phases.add(current_phase.value)
        self._log_session_event(
            "phase_completed",
            phase=current_phase.value,
            duration_ms=duration_ms,
            duration_seconds=round(duration_ms / 1000, 1),
            status="interrupted",
            interrupted=True,
            interruption_reason=reason,
            span_id=self._trace.phase_span_id,
            parent_span_id=self._trace.pipeline_span_id,
        )
        self._log_session_event(
            "resource_snapshot",
            snapshot_type=f"phase_{current_phase.value}_end",
        )
        self._state.current_phase = None
        self._state.phase_start_time = None
        self._trace.phase_span_id = None
        self._event_logger.set_phase_span_id(None)

    def _emit_session_interrupted(self, *, reason: str) -> None:
        """Emit session_interrupted once and finalize phase lifecycle context."""
        if self._session_completed_logged_getter() or self._session_interrupted_logged_getter():
            return
        if not self._state.session_id:
            return

        interrupted_payload = self._build_session_interrupted_payload(reason=reason)
        self._finalize_active_phase_for_interrupt(reason=reason)
        self._invocation.was_interrupted = True
        self._session_interrupted_logged_setter(True)
        self._log_session_event(
            "session_interrupted",
            **interrupted_payload,
        )
