"""Git operations for HybridOrchestrator.

Extracted from obra/hybrid/orchestrator.py as part of REFACTOR-ORCH-EXTRACT-001.
Handles git preflight validation and session file commit operations.
"""

from __future__ import annotations

import hashlib
import logging
import subprocess
from collections.abc import Callable
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class GitOperations:
    """Git operations extracted from HybridOrchestrator.

    Handles git repository validation, session file commits, and working
    directory hashing. Receives shared state via constructor injection.
    """

    def __init__(
        self,
        working_dir: Path,
        session_id_getter: Callable[[], str | None],
        get_session_files: Callable[[str], list[str]],
        llm_config_getter: Callable[[], dict[str, Any] | None],
        working_dir_explicit: bool,
        domain: Any = None,
    ) -> None:
        self._working_dir = working_dir
        self._session_id_getter = session_id_getter
        self._get_session_files = get_session_files
        self._llm_config_getter = llm_config_getter
        self._working_dir_explicit = working_dir_explicit
        self._domain = domain

    def _resolve_domain(self) -> Any:
        """Resolve domain from value or callable getter."""
        if callable(self._domain):
            return self._domain()
        return self._domain

    def _run_git_command(self, args: list[str]) -> str:
        """Run a git subcommand and return stdout, or empty string on error.

        FEAT-SESSION-CLOSEOUT-001 S4.T2: Shared git helper for closeout display.

        Args:
            args: Git subcommand arguments (e.g. ["rev-parse", "--abbrev-ref", "HEAD"]).

        Returns:
            stdout stripped, or empty string if not in a git repo or on error.
        """
        try:
            result = subprocess.run(
                ["git", *args],
                check=False,
                capture_output=True,
                text=True,
                cwd=self._working_dir,
                timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except (
            subprocess.CalledProcessError,
            FileNotFoundError,
            subprocess.TimeoutExpired,
        ):
            pass
        return ""

    def _commit_orphaned_changes(self) -> str:
        """Commit uncommitted session changes left by the final review-fix cycle.

        Only stages files the session actually modified (from the execute handler's
        file tracker). Does not touch pre-existing dirty files.

        Returns:
            Commit hash if a commit was made, empty string otherwise.
        """
        try:
            # Guard: must be inside a git work tree
            result = subprocess.run(
                ["git", "rev-parse", "--is-inside-work-tree"],
                check=False,
                capture_output=True,
                text=True,
                cwd=self._working_dir,
                timeout=5,
            )
            if result.returncode != 0:
                return ""

            # Guard: anything dirty at all?
            result = subprocess.run(
                ["git", "status", "--porcelain"],
                check=False,
                capture_output=True,
                text=True,
                cwd=self._working_dir,
                timeout=5,
            )
            if result.returncode != 0 or not result.stdout.strip():
                return ""

            # Only stage files the session actually touched
            session_files = self._get_session_files("added") + self._get_session_files("modified")
            if not session_files:
                return ""

            subprocess.run(
                ["git", "add", "--", *session_files],
                check=False,
                capture_output=True,
                text=True,
                cwd=self._working_dir,
                timeout=5,
            )

            # Check if anything was actually staged
            result = subprocess.run(
                ["git", "diff", "--cached", "--quiet"],
                check=False,
                capture_output=True,
                text=True,
                cwd=self._working_dir,
                timeout=5,
            )
            if result.returncode == 0:
                # Nothing staged
                return ""

            session_id = self._session_id_getter() or ""
            message = f"chore({session_id[:8]}): apply final review-cycle fixes"
            subprocess.run(
                ["git", "commit", "-m", message],
                check=False,
                capture_output=True,
                text=True,
                cwd=self._working_dir,
                timeout=5,
            )

            result = subprocess.run(
                ["git", "rev-parse", "--short", "HEAD"],
                check=False,
                capture_output=True,
                text=True,
                cwd=self._working_dir,
                timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            logger.warning("Failed to commit orphaned changes — continuing session completion")
        return ""

    def _hash_working_dir(self) -> str:
        """Create SHA256 hash of working directory path.

        Returns:
            SHA256 hex digest of working directory path
        """
        return hashlib.sha256(str(self._working_dir).encode()).hexdigest()

    def _git_preflight(self) -> None:
        """Run git repository validation before orchestration begins.

        GIT-HARD-001 Story 2: Git preflight check for hybrid orchestration.

        Validates that the working directory is a git repository before starting
        orchestration. Behavior controlled by llm.git config section.

        Config options:
            llm.git.skip_check (bool): Skip git validation entirely (default: True).
                ISSUE-REVIEW-AGENTS-002: Changed default from False to True since
                Obra now uses FileStateTracker for change detection instead of git.
                Note: auto_init=True overrides skip_check - validation must run to
                detect missing repos before auto-initializing.
            llm.git.auto_init (bool): Auto-initialize git if missing (default: False)

        Exemptions:
            - Inbox projects (working_dir is None) are exempted from validation

        Raises:
            GitValidationError: If not in git repo and auto_init is False

        Task breakdown:
            S2.T0: Method exists and reads config
            S2.T1: Called before first handler dispatch
            S2.T2: Validates working_dir not cwd
            S2.T3: Exempts Inbox projects
            S2.T4: Logs auto-init actions
        """
        # S2.T3: Exempt Inbox projects (no explicit working_dir provided)
        # When working_dir is not explicitly provided (None in constructor),
        # it defaults to cwd but should be treated as an Inbox project
        if not self._working_dir_explicit:
            logger.debug("Git preflight: Skipping (Inbox project - no explicit working_dir)")
            return

        domain = self._resolve_domain()
        if domain is not None and not getattr(domain, "requires_git", True):
            logger.info("Git preflight: Skipping (domain.requires_git=False)")
            return

        # Get git config settings (with safe defaults)
        llm_config = self._llm_config_getter()
        git_config = {}
        if llm_config:
            git_config = llm_config.get("git", {})

        skip_check = git_config.get("skip_check", True)  # ISSUE-REVIEW-AGENTS-002: Default True
        auto_init = git_config.get("auto_init", False)

        # Honor skip_check flag (but auto_init overrides - if user wants auto-init,
        # we must run the check to detect missing repos)
        if skip_check and not auto_init:
            logger.info("Git preflight: Skipping (llm.git.skip_check enabled)")
            return

        # S2.T2: Validate working_dir not cwd
        # Use self._working_dir which is the project working directory
        logger.debug(f"Git preflight: Validating {self._working_dir}")

        # Import git_utils locally to avoid circular imports
        from obra.utils.git_utils import ensure_git_repository

        try:
            # S2.T4: Log auto-init actions (handled by ensure_git_repository)
            # Note: ensure_git_repository logs auto-init at INFO level
            # Pass full config for auto-init safety checks
            ensure_git_repository(self._working_dir, auto_init=auto_init, config=llm_config)
            logger.info(f"Git preflight: Passed for {self._working_dir}")
        except Exception:
            logger.exception(f"Git preflight: Failed for {self._working_dir}")
            raise
