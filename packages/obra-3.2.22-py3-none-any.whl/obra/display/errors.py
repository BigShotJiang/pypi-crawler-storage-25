"""Error UX mapping for user-friendly error messages per PRD Pre-Implementation #3.

Maps error codes to user-friendly messages and recovery actions.
This module ensures consistent error handling across all CLI commands.

Reference: docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section "Pre-Implementation Requirements #3"
"""

from dataclasses import dataclass
from http import HTTPStatus

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from obra.display.recovery_hints import (
    build_resume_continue_hints,
    has_resume_continue_hints,
)
from obra.exceptions import (
    APIError,
    AuthenticationError,
    ConfigurationError,
    ConnectionError,
    ExecutionError,
    ObraError,
    OrchestratorError,
    TermsNotAcceptedError,
)
from obra.messages.registry import get_message
from obra.utils.obra_home import (
    legacy_notice_needed,
    mark_legacy_notice_shown,
    resolve_runtime_dir,
)


@dataclass
class ErrorDisplay:
    """Structured error display information."""

    code: str
    title: str
    message: str
    recovery: str
    details: str | None = None


# Mapping from error codes to message template keys
ERROR_MESSAGE_KEYS: dict[str, str] = {
    "SESSION_NOT_FOUND": "error.session.not_found",
    "SESSION_EXPIRED": "error.session.expired",
    "INVALID_STATE": "error.session.invalid_state",
    "AUTH_EXPIRED": "error.auth.expired",
    "AUTH_REQUIRED": "error.auth.required",
    "TERMS_NOT_ACCEPTED": "error.auth.terms_not_accepted",
    "BETA_ACCESS_DENIED": "error.auth.beta_denied",
    "NETWORK_ERROR": "error.network.error",
    "RATE_LIMITED": "error.network.rate_limited",
    "SERVER_ERROR": "error.network.server_error",
    "SERVER_CODE_ERROR": "error.server.code_error",
    "INVALID_CONFIG": "error.config.invalid",
    "LLM_NOT_FOUND": "error.config.llm_not_found",
    "VERSION_MISMATCH": "error.config.version_mismatch",
    "EXECUTION_TIMEOUT": "error.execution.timeout",
}

# Error code mappings from PRD Pre-Implementation #3
# Note: message field is used as fallback; get_error_display() uses templates
ERROR_CODE_MAP: dict[str, ErrorDisplay] = {
    "SESSION_NOT_FOUND": ErrorDisplay(
        code="SESSION_NOT_FOUND",
        title="Session Not Found",
        message="Session not found. It may have expired or been completed.",
        recovery=(
            "To start a new session:\n"
            '  obra run "your task description"\n\n'
            "To check active sessions:\n"
            "  obra status"
        ),
    ),
    "SESSION_EXPIRED": ErrorDisplay(
        code="SESSION_EXPIRED",
        title="Session Expired",
        message="Session expired after 24 hours of inactivity.",
        recovery="Run 'obra run \"<objective>\"' to start a new session.",
    ),
    "RATE_LIMITED": ErrorDisplay(
        code="RATE_LIMITED",
        title="Rate Limit Reached",
        message="Rate limit reached. Try again in {retry_after} seconds.",
        recovery="Wait for the specified time and try again.",
    ),
    "INVALID_STATE": ErrorDisplay(
        code="INVALID_STATE",
        title="Invalid State",
        message="Cannot {action} - session is in {state} state.",
        recovery="Run 'obra status' to check current state.",
    ),
    "SERVER_ERROR": ErrorDisplay(
        code="SERVER_ERROR",
        title="Server Error",
        message="Server error. Your work is saved.",
        recovery=(
            "To resume this session:\n"
            "  obra run --resume {session_id}\n\n"
            "To check session status:\n"
            "  obra status"
        ),
    ),
    "SERVER_CODE_ERROR": ErrorDisplay(
        code="SERVER_CODE_ERROR",
        title="Server Code Error",
        message=(
            "A server-side code error occurred ({error_class}). "
            "This is a bug that requires a server fix, not a transient failure."
        ),
        recovery=(
            "This is a known error type that won't resolve by retrying.\n\n"
            "To resume once the server is fixed:\n"
            "  obra run --resume {session_id}\n\n"
            "To report this issue:\n"
            "  https://github.com/Unpossible-Creations/Obra/issues"
        ),
    ),
    "NETWORK_ERROR": ErrorDisplay(
        code="NETWORK_ERROR",
        title="Connection Lost",
        message="Connection lost. Your work is saved locally.",
        recovery=f"Check network and try again. {get_message('recovery.config.doctor')}",
    ),
    "NOT_FOUND": ErrorDisplay(
        code="NOT_FOUND",
        title="Not Found",
        message="The requested resource was not found.",
        recovery="Check the resource identifier or command target and try again.",
    ),
    "AUTH_EXPIRED": ErrorDisplay(
        code="AUTH_EXPIRED",
        title="Authentication Expired",
        message="Session expired. Run 'obra login' to re-authenticate.",
        recovery=get_message("recovery.auth.login"),
    ),
    "AUTH_REQUIRED": ErrorDisplay(
        code="AUTH_REQUIRED",
        title="Authentication Required",
        message="You must be logged in to use this command.",
        recovery=get_message("recovery.auth.login"),
    ),
    "TERMS_NOT_ACCEPTED": ErrorDisplay(
        code="TERMS_NOT_ACCEPTED",
        title="Terms Not Accepted",
        message="You must accept the beta terms to continue.",
        recovery=get_message("recovery.auth.terms"),
    ),
    "INVALID_CONFIG": ErrorDisplay(
        code="INVALID_CONFIG",
        title="Invalid Configuration",
        message="Configuration is invalid or missing.",
        recovery=get_message("recovery.config.config"),
    ),
    "LLM_NOT_FOUND": ErrorDisplay(
        code="LLM_NOT_FOUND",
        title="LLM CLI Not Found",
        message="No LLM CLI found (claude, gemini, or codex).",
        recovery=get_message("recovery.config.llm_setup"),
    ),
    "EXECUTION_TIMEOUT": ErrorDisplay(
        code="EXECUTION_TIMEOUT",
        title="Execution Timeout",
        message="The task took too long to complete.",
        recovery="Rerun with --stream flag, or break into smaller steps.",
    ),
    "VERSION_MISMATCH": ErrorDisplay(
        code="VERSION_MISMATCH",
        title="Version Mismatch",
        message="Client version is not compatible with server.",
        recovery="Upgrade your local Obra CLI and retry.",
    ),
    "BETA_ACCESS_DENIED": ErrorDisplay(
        code="BETA_ACCESS_DENIED",
        title="Beta Access Required",
        message="Your email is not on the beta allowlist.",
        recovery="Request access at obra.dev/beta or contact support.",
    ),
}


def get_error_display(error_code: str, **kwargs: object) -> ErrorDisplay:
    """Get error display for an error code.

    Args:
        error_code: The error code to look up
        **kwargs: Placeholders to substitute in message/recovery

    Returns:
        ErrorDisplay with formatted message and recovery
    """
    display = ERROR_CODE_MAP.get(error_code)
    if not display:
        message_value = kwargs.get("message")
        recovery_value = kwargs.get("recovery")
        return ErrorDisplay(
            code=error_code or "UNKNOWN_ERROR",
            title="Error",
            message=(
                str(message_value) if message_value is not None else "An unexpected error occurred."
            ),
            recovery=(
                str(recovery_value)
                if recovery_value is not None
                else "Please try again or contact support."
            ),
        )

    if error_code == "VERSION_MISMATCH":
        from obra.install_guidance import recommended_upgrade_recovery

        return ErrorDisplay(
            code=display.code,
            title=display.title,
            message=display.message.format(**kwargs),
            recovery=recommended_upgrade_recovery(),
        )

    # Use error template if available, falling back to ERROR_CODE_MAP message
    message_key = ERROR_MESSAGE_KEYS.get(error_code)
    if message_key:
        verbose_value = kwargs.get("verbose")
        ascii_value = kwargs.get("ascii_mode")
        verbose_flag = verbose_value if isinstance(verbose_value, bool) else False
        ascii_flag = ascii_value if isinstance(ascii_value, bool) or ascii_value is None else None
        placeholders = {
            key: value for key, value in kwargs.items() if key not in {"verbose", "ascii_mode"}
        }
        try:
            message = get_message(
                message_key,
                verbose=verbose_flag,
                ascii_mode=ascii_flag,
                **placeholders,
            )
        except (KeyError, ValueError):
            # Fallback to original message with string replacement
            message = display.message
            for key, value in kwargs.items():
                message = message.replace(f"{{{key}}}", str(value))
    else:
        # Old behavior for unknown codes
        message = display.message
        for key, value in kwargs.items():
            message = message.replace(f"{{{key}}}", str(value))

    # Recovery still uses string replacement for now
    recovery = display.recovery
    for key, value in kwargs.items():
        recovery = recovery.replace(f"{{{key}}}", str(value))

    details_value = kwargs.get("details")
    return ErrorDisplay(
        code=display.code,
        title=display.title,
        message=message,
        recovery=recovery,
        details=str(details_value) if details_value is not None else None,
    )


def exception_to_error_code(exc: Exception) -> str:
    """Map exception type to error code.

    Args:
        exc: The exception to map

    Returns:
        Error code string
    """
    if isinstance(exc, TermsNotAcceptedError):
        return "TERMS_NOT_ACCEPTED"
    if isinstance(exc, AuthenticationError):
        return "AUTH_REQUIRED"
    if isinstance(exc, ConnectionError):
        return "NETWORK_ERROR"
    if isinstance(exc, ConfigurationError):
        return "INVALID_CONFIG"
    if isinstance(exc, APIError):
        status_code = getattr(exc, "status_code", 0)
        raw_error_code = getattr(exc, "error_code", None)
        error_code = raw_error_code.lower() if isinstance(raw_error_code, str) else ""
        message = str(exc).lower()
        if status_code == HTTPStatus.NOT_FOUND.value:
            if error_code == "session_not_found" or (
                "session" in message and "not found" in message
            ):
                return "SESSION_NOT_FOUND"
            return "NOT_FOUND"
        if status_code == HTTPStatus.UNAUTHORIZED.value:
            return "AUTH_EXPIRED"
        if status_code == HTTPStatus.FORBIDDEN.value:
            return "BETA_ACCESS_DENIED"
        if status_code == HTTPStatus.CONFLICT.value:
            return "INVALID_STATE"
        if status_code == HTTPStatus.GONE.value:
            return "SESSION_EXPIRED"
        if status_code == HTTPStatus.TOO_MANY_REQUESTS.value:
            return "RATE_LIMITED"
        if status_code >= HTTPStatus.INTERNAL_SERVER_ERROR.value:
            # SESSION-92257c4c: Classify NameError/AttributeError as server
            # code bugs so the user sees "requires fix" instead of "try again".
            msg = str(exc).lower()
            if any(
                err_type in msg
                for err_type in ("nameerror", "attributeerror", "importerror", "typeerror")
            ):
                return "SERVER_CODE_ERROR"
            return "SERVER_ERROR"
    elif isinstance(exc, ExecutionError):
        message_lower = str(exc).lower()
        if "not found" in message_lower:
            return "LLM_NOT_FOUND"
        if "timeout" in message_lower:
            return "EXECUTION_TIMEOUT"
    elif isinstance(exc, OrchestratorError):
        return "SERVER_ERROR"

    return "UNKNOWN_ERROR"


def get_default_log_path() -> str:
    """Return the default hybrid event log path for error context."""
    selection = resolve_runtime_dir()
    return str(selection.path / "logs" / "hybrid.jsonl")


def _resolve_recovery_text(
    recovery: str,
    *,
    session_id: str | None,
) -> str:
    """Apply shared recovery decorations for resumable/runtime-aware errors."""
    resolved = recovery
    if session_id and not has_resume_continue_hints(resolved):
        resolved = f"{resolved}\n\n{build_resume_continue_hints(session_id)}"

    selection = resolve_runtime_dir()
    if legacy_notice_needed(selection):
        resolved = (
            f"{resolved}\n\nNote: Obra is using the legacy runtime directory "
            f"{selection.path}. The canonical runtime path is ~/.obra-runtime. "
            "Set OBRA_RUNTIME_DIR to override."
        )
        mark_legacy_notice_shown(selection)
    return resolved


def _build_error_panel(
    content: Text,
    *,
    title: str,
    panel_style: str,
) -> Panel:
    """Build the shared Rich panel wrapper for CLI error output."""
    return Panel(
        content,
        title=f"[bold {panel_style}]{title}[/bold {panel_style}]",
        title_align="left",
        border_style=panel_style,
        padding=(1, 2),
    )


def display_error(exc: Exception, console: Console | None = None) -> None:
    """Display an error with user-friendly formatting.

    Args:
        exc: The exception to display
        console: Optional Rich Console (uses default if not provided)
    """
    if console is None:
        console = Console()

    error_code = exception_to_error_code(exc)

    # Build kwargs from exception attributes
    kwargs: dict[str, str] = {
        "message": str(exc),
    }

    # SESSION-92257c4c: Extract error class for SERVER_CODE_ERROR display
    if error_code == "SERVER_CODE_ERROR":
        msg = str(exc)
        for err_type in ("NameError", "AttributeError", "ImportError", "TypeError"):
            if err_type.lower() in msg.lower():
                kwargs["error_class"] = err_type
                break
        else:
            kwargs["error_class"] = "unknown"

    # Extract session_id if available
    if hasattr(exc, "session_id") and exc.session_id:
        kwargs["session_id"] = exc.session_id
    elif hasattr(exc, "error_context") and exc.error_context:
        session_id = exc.error_context.session_id
        if session_id:
            kwargs["session_id"] = session_id

    # Extract retry_after from rate limit responses
    if hasattr(exc, "response_body"):
        try:
            import json

            body = json.loads(exc.response_body)
            if "retry_after" in body:
                kwargs["retry_after"] = str(body["retry_after"])
        except (json.JSONDecodeError, TypeError):
            pass

    # Extract recovery from exception if available
    if hasattr(exc, "recovery") and exc.recovery:
        kwargs["recovery"] = exc.recovery

    display = get_error_display(error_code, **kwargs)

    session_id = kwargs.get("session_id")
    recovery = _resolve_recovery_text(display.recovery, session_id=session_id)

    # Build error panel
    content = Text()
    content.append(display.message, style="white")

    if display.details:
        content.append(f"\n\n{display.details}", style="dim")

    # Render error context if available
    if hasattr(exc, "error_context") and exc.error_context:
        ctx_dict = exc.error_context.to_display_dict()
        if ctx_dict:
            content.append("\n\n" + "\u2500" * 76, style="dim")
            content.append("\nContext:", style="dim bold")

            # User-friendly key labels (CHORE-SERVER-ERROR-CONTEXT-001)
            key_labels = {
                "session_id": "Session",
                "project_id": "Project",
                "request_id": "Request ID",
                "server_trace_id": "Trace ID",
                "phase": "Phase",
                "action": "Action",
                "retry_count": "Retries",
                "error_classification": "Error Type",
            }

            for key, val in ctx_dict.items():
                if key in ("log_path", "recent_activity", "recovery_suggestion"):
                    continue  # Handle these specially
                label = key_labels.get(key, key.replace("_", " ").title())
                content.append(f"\n    {label}:".ljust(18) + str(val), style="dim")

            # Show recent activity if present
            if ctx_dict.get("recent_activity"):
                content.append("\n    Recent Activity:", style="dim")
                for activity in ctx_dict["recent_activity"][-3:]:  # Show last 3
                    ts = activity.get("ts", "")
                    action = activity.get("action", "")
                    status = activity.get("status", "")
                    status_style = "green" if status == "success" else "red"
                    content.append(f"\n      {ts} ", style="dim")
                    content.append(action, style="dim")
                    content.append(f" [{status}]", style=f"dim {status_style}")

            if "log_path" in ctx_dict:
                content.append(f"\n\nLogs:          {ctx_dict['log_path']}", style="dim cyan")

    content.append(f"\n\n{recovery}", style="cyan")

    panel_title = getattr(exc, "display_title", display.title)
    panel_style = getattr(exc, "display_style", "red")

    panel = _build_error_panel(content, title=panel_title, panel_style=panel_style)

    console.print()
    console.print(panel)


def display_obra_error(error: ObraError, console: Console | None = None) -> None:
    """Display an ObraError with its built-in recovery guidance.

    All ObraError subclasses include recovery guidance. This function
    displays both the error and the recovery action.

    Args:
        error: The ObraError to display
        console: Optional Rich Console (uses default if not provided)
    """
    if console is None:
        console = Console()

    error_code = exception_to_error_code(error)
    display = get_error_display(error_code)

    # Build error panel
    content = Text()
    content.append(str(error), style="white")

    # Render error context if available
    if hasattr(error, "error_context") and error.error_context:
        ctx_dict = error.error_context.to_display_dict()
        if ctx_dict:
            content.append("\n\n" + "\u2500" * 76, style="dim")
            content.append("\nContext:", style="dim bold")
            for key, val in ctx_dict.items():
                if key != "log_path":
                    content.append(f"\n    {key}:".ljust(18) + str(val), style="dim")
            if "log_path" in ctx_dict:
                content.append(f"\n\nLogs:          {ctx_dict['log_path']}", style="dim cyan")

    # Use error's built-in recovery if available, otherwise use mapped recovery
    recovery = error.recovery if hasattr(error, "recovery") and error.recovery else display.recovery
    session_id = None
    if hasattr(error, "session_id") and error.session_id:
        session_id = error.session_id
    elif hasattr(error, "error_context") and error.error_context:
        session_id = error.error_context.session_id
    recovery = _resolve_recovery_text(recovery, session_id=session_id)
    content.append(f"\n\n{recovery}", style="cyan")

    panel = _build_error_panel(content, title=display.title, panel_style="red")

    console.print()
    console.print(panel)


__all__ = [
    "ERROR_CODE_MAP",
    "ERROR_MESSAGE_KEYS",
    "ErrorDisplay",
    "display_error",
    "display_obra_error",
    "exception_to_error_code",
    "get_default_log_path",
    "get_error_display",
]
