"""Session launch banner formatting functions.

This module provides pure formatting functions for the session startup banner,
including LLM pipeline display, quality policy, review configuration, git status,
and environment labeling.

Usage:
    from obra.display.session_banner import _format_llm_banner, _format_quality_policy_lines
"""

import logging
import platform
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any

from obra.utils.git_utils import is_git_repository

if TYPE_CHECKING:
    from obra.review.config import ReviewConfig

logger = logging.getLogger(__name__)


def _summarize_config_layers(origins: dict[str, str]) -> str:
    """Summarize active config layers from origin metadata."""
    active_layers = [layer for layer in ("user", "project", "session") if layer in origins.values()]
    if not active_layers:
        return "defaults"
    return f"{'+'.join(active_layers)} (defaults)"


def _format_run_mode(api_base_url: str | None = None, local_mode: bool | None = None) -> str:
    """Format the run mode label with API host context."""
    if api_base_url is None or local_mode is None:
        from urllib.parse import urlparse

        from obra.config.loaders import get_api_base_url, is_local_mode

        if api_base_url is None:
            api_base_url = get_api_base_url()
        if local_mode is None:
            local_mode = is_local_mode()
        host = urlparse(api_base_url).netloc or api_base_url
    else:
        from urllib.parse import urlparse

        host = urlparse(api_base_url).netloc or api_base_url
    label = "Local emulator" if local_mode else "SaaS"
    return f"{label} ({host})" if host else label


def _format_git_status(work_dir: Path) -> str | None:
    """Return a short git status summary for display."""
    if not is_git_repository(work_dir):
        return "not a repo"
    try:
        import subprocess

        branch_result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=work_dir,
            capture_output=True,
            text=True,
            check=True,
        )
        branch = branch_result.stdout.strip() or "detached"
        status_result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=work_dir,
            capture_output=True,
            text=True,
            check=True,
        )
        dirty_lines = [line for line in status_result.stdout.splitlines() if line.strip()]
        if dirty_lines:
            return f"{branch} (+{len(dirty_lines)})"
        return f"{branch} (clean)"
    except Exception:
        # Check if repo exists but has no commits yet
        import subprocess

        try:
            result = subprocess.run(
                ["git", "rev-list", "-n1", "--all"],
                check=False,
                cwd=work_dir,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0 and not result.stdout.strip():
                return "no commits yet"
        except Exception:
            pass
        return "unknown"


def _format_environment_label(system: str | None = None, release: str | None = None) -> str:
    """Return OS and Python version summary."""
    system_label = system or platform.system()
    release_label = release or platform.release()
    py_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    return f"{system_label} {release_label} | Python {py_version}".strip()


def _resolve_project_display(client: Any, project_id: str | None) -> str:
    """Resolve a project display label with optional name lookup.

    When project_id is None, fetches the user's server-selected default project
    to display the actual project that will be used, not just "server default".
    """
    if not project_id:
        # Fetch server's selected default project
        try:
            result = client.list_projects_with_selection()
            default_id = result.get("default_project_id")
            if default_id:
                project_id = str(default_id)
            else:
                return "none (no default selected)"
        except Exception:
            logger.debug("Failed to fetch server default project", exc_info=True)
            return "server default"
    try:
        project = client.get_project(project_id)
        if isinstance(project, dict):
            name = project.get("name") or project.get("project_name")
            if isinstance(name, str) and name.strip():
                return f"{name.strip()} ({project_id})"
    except Exception:
        logger.debug("Failed to resolve project name for %s", project_id, exc_info=True)
    return project_id


def _format_review_line(review_config: "ReviewConfig") -> str:
    """Summarize review configuration for launch banner."""
    if review_config.skip_review:
        return "disabled"
    if review_config.full_review:
        return "full"
    if review_config.explicit_agents:
        return f"custom (agents: {', '.join(review_config.explicit_agents)})"
    resolved = review_config.resolve_agents(detected_agents=None, server_agents=None)
    if resolved:
        return f"auto (agents: {', '.join(resolved)})"
    return "auto (agents: server/detected)"


def _format_llm_banner(
    effective_map: dict[str, dict[str, str]],
    preflight_results: dict[str, dict[str, str | None]],
    server_validation: dict[str, dict[str, Any]],
    verbose: int,
) -> list[str]:
    """Format the LLM Pipeline Models banner for session startup.

    Groups map entries by (provider, model) tuple and formats summary lines
    with preflight and server validation indicators.

    Args:
        effective_map: Per-stage LLM configuration map.
        preflight_results: Provider preflight check results.
        server_validation: Server-side validation results per entry.
        verbose: Verbosity level (0=grouped, 1+=per-stage).

    Returns:
        List of formatted banner lines.
    """
    from collections import defaultdict

    AGENT_NAMES = {"sense_check", "code_quality", "test_execution"}
    ALL_PIPELINE_STAGES = {"derive", "examine", "revise", "execute", "fix", "review"}
    lines: list[str] = []
    preflight_results = dict(preflight_results) if isinstance(preflight_results, dict) else {}

    # Separate stages and agent overrides
    stage_entries = {k: v for k, v in effective_map.items() if k not in AGENT_NAMES}
    agent_entries = {k: v for k, v in effective_map.items() if k in AGENT_NAMES}

    # Group stage entries by (provider, model)
    groups: dict[tuple[str, str], list[str]] = defaultdict(list)
    for stage, entry in stage_entries.items():
        key = (entry["provider"], entry["model"])
        groups[key].append(stage)

    def _preflight_icon(provider: str) -> str:
        pf = preflight_results.get(provider, {})
        status = pf.get("status", "")
        if status == "ok":
            return "\u2713 preflight"
        if status == "failed":
            return "\u2717 preflight"
        return ""

    def _server_icon_for(stages_to_check: list[str]) -> str:
        if not server_validation:
            return ""
        statuses = [server_validation.get(s, {}).get("status", "") for s in stages_to_check]
        if any(s == "tier_mismatch" for s in statuses):
            return "\u26a0 mismatch"
        if all(s == "resolved" for s in statuses):
            return "\u2713 resolved"
        if all(s == "accepted" for s in statuses):
            return "\u2713 accepted"
        return "\u2713 resolved"

    for (provider, model), stages in groups.items():
        tier = stage_entries[stages[0]]["tier"]
        pf_icon = _preflight_icon(provider)
        sv_icon = _server_icon_for(stages)
        pf_result = preflight_results.get(provider, {})

        if verbose >= 1:
            # Per-stage expansion
            for stage in stages:
                entry = stage_entries[stage]
                reasoning = entry.get("reasoning_level", "medium")
                stage_sv = _server_icon_for([stage])
                indicators = f"  {pf_icon}"
                if stage_sv:
                    indicators += f" {stage_sv}"
                lines.append(
                    f"  {stage}: {provider} ({model}) | tier: {entry['tier']} | "
                    f"reasoning: {reasoning}{indicators}"
                )
        else:
            # Grouped format — use "all stages" when covering full pipeline
            stage_set = set(stages)
            if stage_set >= ALL_PIPELINE_STAGES:
                stages_label = "all stages"
            else:
                stages_label = ", ".join(stages)
            indicators = f"  {pf_icon}"
            if sv_icon:
                indicators += f" {sv_icon}"
            lines.append(f"  {provider} ({model}) \u2192 {stages_label} | tier: {tier}{indicators}")

        # Preflight failure detail
        if pf_result.get("status") == "failed":
            error = pf_result.get("error", "unknown error")
            lines.append(f"    \u2514 {provider}: {error}")

        # Server tier mismatch details
        if server_validation:
            for stage in stages:
                sv = server_validation.get(stage, {})
                if sv.get("status") == "tier_mismatch":
                    lines.append(
                        f"    \u2514 Server computed tier {sv.get('server_tier')} for {stage}"
                    )

    # Agent overrides (always expanded with \u2514 prefix)
    for agent, entry in agent_entries.items():
        provider = entry["provider"]
        model = entry["model"]
        tier = entry["tier"]
        reasoning = entry.get("reasoning_level", "medium")
        pf_icon = _preflight_icon(provider)
        sv_icon = _server_icon_for([agent])
        indicators = f"  {pf_icon}"
        if sv_icon:
            indicators += f" {sv_icon}"
        lines.append(
            f"    \u2514 {agent}: {provider} ({model}) | tier: {tier} | "
            f"reasoning: {reasoning}{indicators}"
        )

    return lines


def _format_quality_policy_lines(
    impl_tier: str,
    policy_mode: str,
) -> list[str]:
    """Format quality policy lines for the launch banner.

    Args:
        impl_tier: Execute model tier (fast, medium, high).
        policy_mode: Quality policy mode (auto, fast, medium, high).

    Returns:
        List of formatted banner lines for quality policy display.
    """
    lines: list[str] = []
    effective_tier = impl_tier if policy_mode == "auto" else policy_mode

    if policy_mode == "auto":
        lines.append(f"Quality policy: {effective_tier} (auto - from model tier)")
    else:
        lines.append(f"Quality policy: {effective_tier} (forced via config)")

    # Mismatch note when forced mode differs from model-derived tier
    if policy_mode not in ("auto", impl_tier):
        lines.append(
            f"  Note: Model tier is {impl_tier}, but quality gates use {policy_mode} policy"
        )

    return lines
