"""ReviewEmitter — review-domain progress events.

Owns all review loop, scorecard, fix, story-review, and fix-pass progress
events.  Receives EmitterContext at construction and delegates all shared
operations (print, spinner, pipeline, utilities) through self._ctx.

Design decision D3: domain composition — no registry, just explicit wiring
in ProgressEmitter.__init__.
"""

import threading
from typing import TYPE_CHECKING

from obra.display.charset import glyphs
from obra.display.observability._emitter import VerbosityLevel

if TYPE_CHECKING:
    from obra.display.observability._context import EmitterContext


class ReviewEmitter:
    """Emits all review-domain progress events.

    Owns review loop state, scorecard display, fix-pass tracking, and
    story-level review progress.  All shared infrastructure (print, spinner,
    utilities) is accessed via self._ctx.
    """

    def __init__(self, ctx: "EmitterContext") -> None:
        self._ctx = ctx

        # Review loop state
        self._review_attempt: int = 0
        self._review_max_attempts: int = 0
        self._review_agents: dict[str, str] = {}
        self._review_agent_count: int | None = None
        self._review_parallel: bool | None = None
        self._review_retry_pending: bool = False
        self._last_completion_data: dict[str, object] = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ #
    # Review context management                                            #
    # ------------------------------------------------------------------ #

    def reset_review_state(self) -> None:
        """Reset review loop tracking state to defaults."""
        self._review_attempt = 0
        self._review_max_attempts = 0
        self._review_agents = {}
        self._ctx._review_ctx.clear()
        self._review_retry_pending = False

    def set_review_context(
        self,
        *,
        item_id: str | None = None,
        review_cycle_id: str | None = None,
    ) -> None:
        """Set active review context for cycle-correlated progress rendering."""
        normalized_item = str(item_id).strip() if item_id else ""
        normalized_cycle = str(review_cycle_id).strip() if review_cycle_id else ""
        if normalized_item:
            self._ctx._review_ctx.set_context(item_id=normalized_item)
        if normalized_cycle:
            self._ctx._review_ctx.set_context(cycle_id=normalized_cycle)

    def _review_context_matches(
        self,
        *,
        item_id: str | None = None,
        review_cycle_id: str | None = None,
    ) -> bool:
        normalized_item = str(item_id).strip() if item_id else ""
        normalized_cycle = str(review_cycle_id).strip() if review_cycle_id else ""
        active_cycle = self._ctx._review_ctx.get_cycle_id()
        active_item = self._ctx._review_ctx.get_item_id()
        if active_cycle and normalized_cycle and normalized_cycle != active_cycle:
            return False
        if active_item and normalized_item and normalized_item != active_item:
            return False
        return True

    # ------------------------------------------------------------------ #
    # LLM state (shared via EmitterContext)                                #
    # ------------------------------------------------------------------ #

    def set_llm_state(self, state: str) -> None:
        """Set the current LLM state.

        Args:
            state: LLM state string ("idle", "waiting", "streaming", "processing")
        """
        self._ctx._llm.set_state(state)

    def get_llm_state(self) -> str:
        """Return the current LLM state."""
        return self._ctx._llm.get_state()

    # ------------------------------------------------------------------ #
    # Review loop events                                                   #
    # ------------------------------------------------------------------ #

    def review_loop_started(
        self,
        attempt: int,
        max_attempts: int,
        *,
        agent_count: int | None = None,
        parallel: bool | None = None,
        item_id: str | None = None,
        review_cycle_id: str | None = None,
    ) -> None:
        """Emit event when a review loop begins."""
        if not self._review_context_matches(item_id=item_id, review_cycle_id=review_cycle_id):
            if self._ctx.config.verbosity >= VerbosityLevel.DEBUG:
                self._ctx._print(
                    "[DEBUG] ProgressEmitter: dropped stale review_loop_started event",
                    style="dim",
                )
            return

        self._review_attempt = attempt
        self._review_max_attempts = max_attempts
        self._review_agents = {}
        self._review_agent_count = agent_count
        self._review_parallel = parallel
        self._review_retry_pending = False
        if item_id:
            self._ctx._review_ctx.set_context(item_id=str(item_id).strip())
        if review_cycle_id:
            self._ctx._review_ctx.set_context(cycle_id=str(review_cycle_id).strip())

        item_label = ""
        active_item = self._ctx._review_ctx.get_item_id()
        if active_item:
            item_label = f" [{active_item}]"

        count_label = None
        if isinstance(agent_count, int) and agent_count > 0:
            noun = "agent" if agent_count == 1 else "agents"
            count_label = f"{agent_count} {noun}"
            # Only show "parallel" when there are multiple agents running
            # concurrently — labeling a single agent as "parallel" is misleading.
            if parallel is True and agent_count > 1:
                count_label = f"{count_label}, parallel"
            elif parallel is False and agent_count > 1:
                count_label = f"{count_label}, series"

        if self._ctx.config.verbosity == VerbosityLevel.QUIET:
            detail = f" ({count_label})" if count_label else ""
            self._ctx._print(
                f"review — running review agents{item_label}{detail} [attempt {attempt}/{max_attempts}]"
            )
            return

        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # Render pipeline banner for Review stage with iteration
        if self._ctx._pipeline_enabled and self._ctx._pipeline.should_render_banner("Review"):
            self._ctx._print("")  # Blank line before banner
            self._ctx._pipeline.stage_transition(
                "Review",
                iteration=attempt,
                max_iterations=max_attempts,
            )
            self._ctx._last_pipeline_stage = "Review"
            if count_label:
                timestamp = self._ctx._timestamp()
                self._ctx._print(
                    f"{timestamp}review — running review agents{item_label} ({count_label})",
                    style="cyan",
                )
        else:
            # Show iteration update without full banner
            timestamp = self._ctx._timestamp()
            detail = f" ({count_label})" if count_label else ""
            self._ctx._print(
                f"{timestamp}review — running review agents{item_label}{detail} [attempt {attempt}/{max_attempts}]",
                style="cyan",
            )

        if count_label and self._ctx._spinner and self._ctx._spinner.is_active:
            self._ctx._spinner.update_status_line(
                f"review — running review agents{item_label} ({count_label})",
                style="cyan",
            )

    def review_agent_started(self, agent_name: str) -> None:
        """Emit event when a review agent starts running."""
        with self._lock:
            self._review_agents[agent_name] = "running"

        self._ctx.start_spinner(reason=f"review_agent:{agent_name}")

        if self._ctx.config.verbosity == VerbosityLevel.QUIET:
            return

        if self._ctx.config.verbosity == VerbosityLevel.PROGRESS:
            self._ctx._print(f"  {glyphs.arrow} {agent_name} \u2014 running...", style="dim")
            return

        if self._ctx.config.verbosity >= VerbosityLevel.DETAIL:
            timestamp = self._ctx._timestamp()
            self._ctx._print(
                f"{timestamp}  {glyphs.arrow} {agent_name} \u2014 running...", style="dim"
            )

    def review_agent_completed(
        self,
        agent_name: str,
        passed: bool,
        details: str | None = None,
        *,
        status: str | None = None,
        item_id: str | None = None,
        review_cycle_id: str | None = None,
    ) -> None:
        """Emit event when a review agent finishes."""
        if not self._review_context_matches(item_id=item_id, review_cycle_id=review_cycle_id):
            if self._ctx.config.verbosity >= VerbosityLevel.DEBUG:
                self._ctx._print(
                    "[DEBUG] ProgressEmitter: dropped stale review_agent_completed event",
                    style="dim",
                )
            return
        if item_id:
            self._ctx._review_ctx.set_context(item_id=str(item_id).strip())
        if review_cycle_id:
            self._ctx._review_ctx.set_context(cycle_id=str(review_cycle_id).strip())
        self._ctx.stop_spinner(reason=f"review_agent:{agent_name}")
        normalized_status = str(status or "").strip().lower()
        if normalized_status == "skipped":
            render_status = "skipped"
            symbol = glyphs.success
            style = "yellow"
        elif not passed and self._review_retry_pending:
            # Suppress failure display when server has signaled retry-pending
            # (review_indeterminate). The retry will produce the real result.
            render_status = "retrying"
            symbol = glyphs.arrow
            style = "yellow"
        else:
            render_status = "passed" if passed else "failed"
            symbol = glyphs.success if passed else glyphs.failure
            style = "green" if passed else "red"

        with self._lock:
            previous_status = self._review_agents.get(agent_name)
            if previous_status == render_status:
                return
            self._review_agents[agent_name] = render_status
            all_agents_finished = bool(self._review_agents) and all(
                value != "running" for value in self._review_agents.values()
            )

        if all_agents_finished:
            self._ctx._restore_spinner_status_line()

        if self._ctx.config.verbosity == VerbosityLevel.QUIET:
            return

        if self._ctx.config.verbosity == VerbosityLevel.PROGRESS:
            self._ctx._print(f"  {symbol} {agent_name} \u2014 {render_status}", style=style)
            return

        if self._ctx.config.verbosity >= VerbosityLevel.DETAIL:
            timestamp = self._ctx._timestamp()
            message = f"{timestamp}  {symbol} {agent_name} \u2014 {render_status}"
            if details:
                self._ctx._print(message, style=style)
                self._ctx._print(f"  - {details}", style="dim")
            else:
                self._ctx._print(message, style=style)

    def review_indeterminate(
        self,
        *,
        item_id: str | None = None,
        reason: str | None = None,
    ) -> None:
        """Handle review_indeterminate: mark retry pending and show retrying badge.

        When the server signals that all review agents were skipped (indeterminate
        state), mark the review as retry-pending so that premature agent failure
        lines are suppressed until the retry completes.
        """
        self._review_retry_pending = True
        if item_id:
            self._ctx._review_ctx.set_context(item_id=str(item_id).strip())

        if self._ctx.config.verbosity >= VerbosityLevel.PROGRESS:
            item_context = f" ({item_id})" if item_id else ""
            display_reason = reason or "review agents degraded"
            self._ctx._print(
                f"  {glyphs.arrow} Review{item_context}: retrying ({display_reason})",
                style="yellow",
            )

    @staticmethod
    def _to_percent(value: float) -> int:
        """Normalize ratio (0-1) or percent (0-100) values to integer percent."""
        normalized = float(value)
        if normalized <= 1.0:
            normalized *= 100.0
        return max(0, min(100, round(normalized)))

    def _resolve_threshold_percent(
        self,
        *,
        threshold: int | None,
        threshold_ratio: float | None,
    ) -> int:
        """Resolve stabilization threshold as integer percent."""
        if isinstance(threshold, int):
            return max(0, min(100, threshold))
        if isinstance(threshold_ratio, float):
            return self._to_percent(threshold_ratio)
        from obra.config.loaders import get_quality_threshold

        return self._to_percent(get_quality_threshold())

    def _sync_scorecard_context(
        self,
        *,
        item_id: str | None,
        review_cycle_id: str | None,
    ) -> tuple[str, str] | None:
        """Validate and store scorecard review context."""
        normalized_item = str(item_id).strip() if item_id else ""
        normalized_cycle = str(review_cycle_id).strip() if review_cycle_id else ""
        if self._ctx._review_ctx.get_cycle_id() and not normalized_cycle:
            if self._ctx.config.verbosity >= VerbosityLevel.DEBUG:
                self._ctx._print(
                    "[DEBUG] ProgressEmitter: dropped scorecard_available without review_cycle_id",
                    style="dim",
                )
            return None
        if self._ctx._review_ctx.get_item_id() and not normalized_item:
            if self._ctx.config.verbosity >= VerbosityLevel.DEBUG:
                self._ctx._print(
                    "[DEBUG] ProgressEmitter: dropped scorecard_available without item_id",
                    style="dim",
                )
            return None
        if not self._review_context_matches(item_id=item_id, review_cycle_id=review_cycle_id):
            if self._ctx.config.verbosity >= VerbosityLevel.DEBUG:
                self._ctx._print(
                    "[DEBUG] ProgressEmitter: dropped stale scorecard_available event",
                    style="dim",
                )
            return None
        if normalized_item:
            self._ctx._review_ctx.set_context(item_id=normalized_item)
        if normalized_cycle:
            self._ctx._review_ctx.set_context(cycle_id=normalized_cycle)
        return normalized_item, normalized_cycle

    def _compute_scorecard_verdict(
        self,
        total: int,
        threshold: int,
        status: str | None,
        decision_state: str | None,
        skipped_agents: int | None,
        total_agents: int | None,
        degraded: bool | None,
    ) -> tuple[bool, bool, str, str]:
        """Compute pass/fail presentation for a scorecard."""
        passed = total >= threshold
        if status and str(status).strip().lower() == "failing":
            passed = False
        all_agents_skipped = (
            isinstance(skipped_agents, int)
            and isinstance(total_agents, int)
            and skipped_agents == total_agents
            and total_agents > 0
        )
        indeterminate = str(decision_state or "").strip().lower() == "indeterminate" or all_agents_skipped
        style = "green" if passed and not indeterminate else "yellow"
        display_status = "pass" if passed and not indeterminate else "fail"
        return passed, indeterminate, style, display_status

    def _build_scorecard_suffixes(
        self,
        item_id: str | None,
        item_context: str,
        review_filter_applied: bool,
        filtered_issue_count: int | None,
        source: str | None,
        skipped_agents: int | None,
        total_agents: int | None,
    ) -> tuple[str, str, str]:
        """Build contextual suffix strings for scorecard output."""
        item_suffix = item_context or (f" ({item_id})" if item_id else "")
        normalized_source = str(source or "").strip().lower()
        is_post_filter = review_filter_applied or normalized_source == "post_filter"
        filter_suffix = ""
        if is_post_filter and isinstance(filtered_issue_count, int) and filtered_issue_count > 0:
            finding_label = "finding" if filtered_issue_count == 1 else "findings"
            filter_suffix = f" after filtering {filtered_issue_count} {finding_label}"

        agent_suffix = ""
        if isinstance(skipped_agents, int) and skipped_agents > 0 and isinstance(total_agents, int):
            active_count = total_agents - skipped_agents
            agent_label = "agent" if active_count == 1 else "agents"
            agent_suffix = f" ({active_count} {agent_label}, {skipped_agents} skipped)"
        elif isinstance(total_agents, int) and total_agents > 0:
            agent_label = "agent" if total_agents == 1 else "agents"
            agent_suffix = f" ({total_agents} {agent_label})"
        return item_suffix, filter_suffix, agent_suffix

    def _render_scorecard_quiet(
        self,
        passed: bool,
        indeterminate: bool,
        total: int,
        threshold: int,
        display_status: str,
        style: str,
        item_suffix: str,
        filter_suffix: str,
        agent_suffix: str,
    ) -> None:
        """Render the compact quiet-mode scorecard output."""
        if indeterminate:
            self._ctx._print(f"Score{item_suffix}: indeterminate{agent_suffix}", style="yellow")
            return
        self._ctx._print(
            f"Score{item_suffix}: {total}/100 (threshold: {threshold}) - {display_status}",
            style=style,
        )

    def _render_scorecard_detail(
        self,
        component_scores: dict[str, int],
        issue_counts: dict[str, int] | None,
        has_health_issues: bool,
        total_agents: int | None,
        failed_agents: int | None,
        skipped_agents: int | None,
        style: str,
    ) -> None:
        """Render detail-level scorecard breakdown sections."""
        if component_scores:
            self._ctx._print("  Agent assessments:", style="dim")
            max_score = 100
            for category, score in component_scores.items():
                self._ctx._print(
                    f"  {glyphs.tree_mid} {category}: {score}/{max_score}",
                    style=style,
                )
        if issue_counts:
            self._ctx._print("  Reported issue counts:", style="dim")
            for category, count in issue_counts.items():
                self._ctx._print(f"  {glyphs.tree_mid} {category} issues: {count}", style="dim")
        if has_health_issues and isinstance(total_agents, int):
            ok_count = total_agents - (failed_agents or 0) - (skipped_agents or 0)
            parts = [f"{ok_count} ok"]
            if isinstance(failed_agents, int) and failed_agents > 0:
                parts.append(f"{failed_agents} err")
            if isinstance(skipped_agents, int) and skipped_agents > 0:
                parts.append(f"{skipped_agents} skipped")
            self._ctx._print(
                f"  {glyphs.tree_last} Agents: [{' / '.join(parts)}]",
                style="yellow",
            )

    # ------------------------------------------------------------------ #
    # Scorecard events                                                     #
    # ------------------------------------------------------------------ #

    def scorecard_available(
        self,
        component_scores: dict[str, int],
        total: int,
        threshold: int,
        item_id: str | None = None,
        *,
        review_cycle_id: str | None = None,
        issue_counts: dict[str, int] | None = None,
        scorecard_source: str | None = None,
        filtered_issue_count: int | None = None,
        review_filter_applied: bool = False,
        status: str | None = None,
        decision_state: str | None = None,
        failed_agents: int | None = None,
        degraded: bool | None = None,
        total_agents: int | None = None,
        skipped_agents: int | None = None,
    ) -> None:
        """Emit event when a scorecard summary is available.

        Args:
            component_scores: Mapping of normalized category scores (0-100)
            total: Total score (0-100)
            threshold: Passing threshold
            item_id: Optional item ID for context (which item was reviewed)
            review_cycle_id: Optional review cycle identifier for stale-event filtering
            issue_counts: Optional mapping of issue counts per agent/category
            scorecard_source: Optional scorecard source marker ("direct", "post_filter")
            filtered_issue_count: Optional count of findings removed by review filtering
            review_filter_applied: Whether review filtering was applied before scoring
            status: Optional server scorecard status (e.g. "failing", "passing")
            decision_state: Optional decision state marker ("determinate", "indeterminate")
            failed_agents: Optional count of agents that errored or timed out
            degraded: Optional flag indicating agent health degradation
            total_agents: Optional total number of agents that ran
        """
        context = self._sync_scorecard_context(item_id=item_id, review_cycle_id=review_cycle_id)
        if context is None:
            return
        normalized_item, _normalized_cycle = context

        passed, indeterminate, style, display_status = self._compute_scorecard_verdict(
            total,
            threshold,
            status,
            decision_state,
            skipped_agents,
            total_agents,
            degraded,
        )
        all_agents_skipped = (
            isinstance(skipped_agents, int)
            and isinstance(total_agents, int)
            and skipped_agents == total_agents
            and total_agents > 0
        )
        item_context = f" ({normalized_item})" if normalized_item else ""
        item_suffix, filter_suffix, agent_suffix = self._build_scorecard_suffixes(
            normalized_item or item_id,
            item_context,
            review_filter_applied,
            filtered_issue_count,
            scorecard_source,
            skipped_agents,
            total_agents,
        )
        is_post_filter = review_filter_applied or str(scorecard_source or "").strip().lower() == "post_filter"
        summary_label = "Adjusted review score" if is_post_filter else "Review score"

        if self._ctx.config.verbosity == VerbosityLevel.QUIET:
            self._render_scorecard_quiet(
                passed,
                indeterminate,
                total,
                threshold,
                display_status,
                style,
                item_suffix,
                filter_suffix,
                agent_suffix,
            )
            return

        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # HYBRID-086: When all agents were skipped, show "unreviewed" instead of
        # a numeric score to avoid implying the code was reviewed and clean.
        if all_agents_skipped:
            self._ctx._print(
                f"Review status{item_suffix}: unreviewed — "
                f"{skipped_agents} {'agent' if skipped_agents == 1 else 'agents'} skipped",
                style="yellow",
            )
            return

        if indeterminate:
            reason = "review agent health degraded" if degraded else "review coverage incomplete"
            self._ctx._print(
                f"Review status{item_suffix}: indeterminate ({reason}){agent_suffix}",
                style="yellow",
            )
            return

        self._ctx._print(
            f"{summary_label}{item_suffix}: {total}/100 (pass \u2265 {threshold}){filter_suffix}{agent_suffix}",
            style=style,
        )

        if self._ctx.config.verbosity < VerbosityLevel.DETAIL:
            return

        has_health_issues = (
            degraded
            or (isinstance(failed_agents, int) and failed_agents > 0)
            or (isinstance(skipped_agents, int) and skipped_agents > 0)
        )
        self._render_scorecard_detail(
            component_scores,
            issue_counts,
            has_health_issues,
            total_agents,
            failed_agents,
            skipped_agents,
            style,
        )

    def scorecard_warning(self, message: str) -> None:
        """Emit a single-line scorecard warning."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        self._ctx._print(f"Scorecard: {message}", style="yellow")

    # ------------------------------------------------------------------ #
    # Session completion                                                   #
    # ------------------------------------------------------------------ #

    def session_completed(
        self,
        items_completed: int,
        quality_score: float,
        session_summary: str,
        *,
        was_escalated: bool = False,
    ) -> None:
        """Record session completion for progress tracking.

        Note: Final completion message is now handled by CLI closeout builder
        (FEAT-SESSION-CLOSEOUT-001) to avoid double-printing. This method is
        retained for progress event tracking and internal state updates.

        Args:
            items_completed: Number of items completed in the session
            quality_score: Quality score (0.0-1.0 or 0-100)
            session_summary: Summary of what was accomplished
            was_escalated: If True, session ended via escalation
        """
        # Normalize quality score to 0-100 for internal tracking
        if quality_score <= 1.0:
            quality_score = quality_score * 100

        # Store for potential later use (e.g., summary queries)
        self._last_completion_data = {
            "items_completed": items_completed,
            "quality_score": quality_score,
            "session_summary": session_summary,
            "was_escalated": was_escalated,
        }

        # Note: Completion banner printing removed - CLI closeout builder handles it
        # See obra/display/closeout.py build_closeout_message()

    # ------------------------------------------------------------------ #
    # Fix-pass events                                                      #
    # ------------------------------------------------------------------ #

    def stabilization_auto_accept(
        self,
        item_id: str,
        quality_score: float,
        fix_cycles: int,
        reason: str,
        threshold: int | None = None,
        threshold_ratio: float | None = None,
    ) -> None:
        """Emit explicit stabilization auto-accept explanation."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        score = self._to_percent(quality_score)
        resolved_threshold = self._resolve_threshold_percent(
            threshold=threshold,
            threshold_ratio=threshold_ratio,
        )
        display_reason = str(reason).strip() or "only_deferred_non_critical_remain"
        self._ctx._print(
            f"Auto-accepted ({score}/{resolved_threshold}) after {fix_cycles} review cycles — {display_reason}",
            style="yellow",
        )
        if self._ctx.config.verbosity >= VerbosityLevel.DETAIL:
            self._ctx._print(f"  {glyphs.tree_last} Item: {item_id}", style="dim")

    def review_fix_progress(
        self,
        item_id: str,
        *,
        changes_applied: int = 0,
        changes_failed: int = 0,
    ) -> None:
        """Emit a one-line fix progress summary per item.

        Called after a FIX action completes to show cumulative fix stats.
        The review-fix loop is server-driven (one action at a time) so
        item_index/total_items are not available client-side.

        Args:
            item_id: Plan item identifier (e.g. "E2.S3.T1").
            changes_applied: Cumulative code changes written this session.
            changes_failed: Cumulative code-change attempts failed this session.
        """
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        self._ctx._print(
            f"  Fix {item_id}: {changes_applied} change(s) written, {changes_failed} failed",
            style="dim",
        )

    def escalation_summary(
        self,
        *,
        reason: str,
        failing_items: list[str] | None = None,
        fix_attempts: int = 0,
        fix_results: list[dict[str, object]] | None = None,
    ) -> None:
        """Emit a structured escalation summary with fix failure context.

        Args:
            reason: Escalation reason value.
            failing_items: List of item IDs that could not be fixed.
            fix_attempts: Total fix attempts in the session.
            fix_results: List of fix_issue_result dicts with verification details.
        """
        if self._ctx.config.verbosity < VerbosityLevel.QUIET:
            return
        self._ctx._print("")
        self._ctx._print(f"  Escalation: {reason}", style="bold yellow")
        if failing_items:
            self._ctx._print(f"  Failing items: {', '.join(failing_items)}", style="yellow")
        if fix_attempts > 0:
            self._ctx._print(f"  Fix attempts: {fix_attempts}", style="yellow")
        if fix_results:
            for fr in fix_results[:5]:
                status = fr.get("status", "unknown")
                issue_id = fr.get("issue_id", "?")
                verification_cmd = fr.get("verification_command", "")
                reason_detail = fr.get("reason", "")
                self._ctx._print(
                    f"    {issue_id}: {status} — {reason_detail}"
                    + (f" ({verification_cmd})" if verification_cmd else ""),
                    style="dim yellow",
                )

    def fix_started(self, issue_count: int) -> None:
        """Emit event when fix pass starts."""
        self._ctx.start_spinner(reason="fix")

        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # Render pipeline banner for Fix stage
        if self._ctx._pipeline_enabled and self._ctx._pipeline.should_render_banner("Fix"):
            self._ctx._print("")  # Blank line before banner
            self._ctx._pipeline.stage_transition("Fix")
            self._ctx._last_pipeline_stage = "Fix"

        timestamp = self._ctx._timestamp()
        self._ctx._print(f"{timestamp}Fix started: {issue_count} issue(s)", style="cyan")

    def fix_completed(self, fixed: int, failed: int, skipped: int) -> None:
        """Emit event when fix pass completes."""
        self._ctx.stop_spinner(reason="fix")

        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        self._ctx._print(
            f"{timestamp}Fix completed: {fixed} fixed, {failed} failed, {skipped} skipped",
            style="green",
        )
        # Clarify that review will re-evaluate code quality (independent of fix success/failure)
        if self._ctx.config.verbosity >= VerbosityLevel.PROGRESS:
            self._ctx._print("Re-reviewing current code quality...", style="dim")

    # ------------------------------------------------------------------ #
    # Story-level review events                                            #
    # ------------------------------------------------------------------ #

    def story_review_started(
        self,
        story_id: str,
        story_title: str,
        story_index: int,
        total_stories: int,
        task_count: int,
    ) -> None:
        """Emit event when reviewing a story starts."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        title = self._ctx._truncate_title(story_title)
        self._ctx._print(
            f"{timestamp} Reviewing story {story_index}/{total_stories}: {title} ({task_count} tasks)...",
            style="cyan",
        )

    def story_review_completed(
        self,
        story_id: str,
        story_title: str,
        story_index: int,
        total_stories: int,
        changes_required: bool,
        issue_count: int,
        duration_s: float,
    ) -> None:
        """Emit event when a story review completes."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        title = self._ctx._truncate_title(story_title)
        if changes_required:
            status = f"[yellow]{issue_count} issue(s)[/yellow]"
        else:
            status = "[green]OK[/green]"
        self._ctx._print(
            self._ctx._format_status_line(
                status,
                f"Story {story_index}/{total_stories}: {title} ({duration_s:.1f}s)",
            )
        )

    def story_review_batch_started(self, story_count: int, max_concurrent: int) -> None:
        """Emit event when parallel story review starts."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        self._ctx._print(
            f"{timestamp}  \u2192 Reviewing {story_count} stories (parallel, {max_concurrent} workers)...",
            style="dim",
        )

    def review_issues_found(self, story_id: str, story_title: str, issues: list[str]) -> None:
        """Emit event when review finds issues in a story."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        # Note: story_title truncation removed - was dead code (result unused)
        for issue in issues[:3]:  # Show up to 3 issues
            issue_text = self._ctx._truncate_description(issue)
            self._ctx._print(f"{timestamp}    [dim]- {issue_text}[/dim]")

    def review_no_fixes(self, item_id: str | None = None) -> None:
        """Emit event when review finds no issues (no fixes required)."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        item_label = (
            f" for {item_id}"
            if item_id and self._ctx.config.verbosity >= VerbosityLevel.DETAIL
            else ""
        )
        self._ctx._print(f"{timestamp}No fix required{item_label} (0 findings)", style="green")

    # ------------------------------------------------------------------ #
    # Review filter event                                                  #
    # ------------------------------------------------------------------ #

    def review_filter_applied(
        self,
        *,
        removed_count: int,
        adjusted_count: int,
        kept_count: int,
        enriched_count: int = 0,
        item_id: str | None = None,
        review_cycle_id: str | None = None,
    ) -> None:
        """Emit event when server applies review-filter decisions to reports."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        normalized_item = str(item_id).strip() if item_id else ""
        normalized_cycle = str(review_cycle_id).strip() if review_cycle_id else ""
        if self._ctx._review_ctx.get_cycle_id() and not normalized_cycle:
            return
        if self._ctx._review_ctx.get_item_id() and not normalized_item:
            return
        if not self._review_context_matches(item_id=item_id, review_cycle_id=review_cycle_id):
            return

        if normalized_item:
            self._ctx._review_ctx.set_context(item_id=normalized_item)
        if normalized_cycle:
            self._ctx._review_ctx.set_context(cycle_id=normalized_cycle)

        timestamp = self._ctx._timestamp()
        item_context = f" ({normalized_item})" if normalized_item else ""
        message = (
            f"Applied review filter{item_context}: "
            f"removed={int(removed_count)}, adjusted={int(adjusted_count)}, "
            f"kept={int(kept_count)}, enriched={int(enriched_count)}"
        )
        self._ctx._print(f"{timestamp}  {glyphs.arrow} {message}", style="yellow")
