"""Observability infrastructure for Obra CLI operations.

This package provides progressive verbosity levels and progress emission
for CLI commands.  The public API is unchanged — all callers import from
``obra.display.observability`` as before.

Submodules
----------
_emitter   Thin ProgressEmitter facade using __getattr__ dispatch and narrow compatibility accessors
_context   EmitterContext — shared spinner/print/utility infrastructure
"""

# Re-export helpers so tests can patch them at the obra.display.observability level.
# Code in sub-modules (_context.py, _emitter.py) accesses these at runtime via
# sys.modules["obra.display.observability"] to ensure patches take effect.
import time

from obra.config.loaders import get_display_limit, get_spinner_config
from obra.core.interrupts import interrupt_requested
from obra.display.observability._emitter import (
    _PHASE_STATUS_LINES,
    _STAGE_USER_LABELS,
    ObservabilityConfig,
    ProgressEmitter,
    VerbosityLevel,
    get_runtime_verbosity,
    set_runtime_verbosity,
)
from obra.display.spinner import StatusSpinner

__all__ = [
    "ObservabilityConfig",
    "ProgressEmitter",
    "StatusSpinner",
    "VerbosityLevel",
    "_PHASE_STATUS_LINES",
    "_STAGE_USER_LABELS",
    "get_display_limit",
    "get_runtime_verbosity",
    "get_spinner_config",
    "interrupt_requested",
    "set_runtime_verbosity",
    "time",
]
