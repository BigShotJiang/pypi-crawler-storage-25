"""ValidatorEmitter — SenseCheck pipeline progress events.

Owns all validator_started, validator_completed, validator_skipped, and
validator_error events.  Receives EmitterContext at construction and delegates
all shared operations (print, spinner, utilities) through self._ctx.

Design decision D3: domain composition — no registry, just explicit wiring
in ProgressEmitter.__init__.
"""

from typing import TYPE_CHECKING

from obra.display.charset import glyphs
from obra.display.observability._emitter import VerbosityLevel

if TYPE_CHECKING:
    from obra.display.observability._context import EmitterContext


class ValidatorEmitter:
    """Emits all SenseCheck validator pipeline progress events.

    Zero dedicated state variables — all shared infrastructure (print, spinner,
    utilities) is accessed via self._ctx.
    """

    def __init__(self, ctx: "EmitterContext") -> None:
        self._ctx = ctx

    # =========================================================================
    # Validator / SenseCheck Pipeline Events
    # =========================================================================

    def validator_started(self, stage: str) -> None:
        """Emit event when a SenseCheck validator stage starts.

        Args:
            stage: Validation stage ('intent', 'plan', 'review_filter')
        """
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        from obra.messages.validator import get_validator

        timestamp = self._ctx._timestamp()
        verbose = self._ctx.config.verbosity >= VerbosityLevel.DETAIL
        message = get_validator(f"{stage}.running", verbose=verbose)
        self._ctx._print(f"{timestamp}  {glyphs.arrow} {message}", style="cyan")
        if self._ctx._spinner and self._ctx._spinner.is_active:
            self._ctx._spinner.update_status_line(f"validator — {message}", style="cyan")

    def validator_completed(
        self,
        stage: str,
        sound: bool,
        *,
        count: int | None = None,
        duration_s: float | None = None,
    ) -> None:
        """Emit event when a SenseCheck validator stage completes.

        Args:
            stage: Validation stage ('intent', 'plan', 'review_filter')
            sound: Whether the validation found no issues (sound=True)
            count: Number of constraints/issues/decisions (if any)
            duration_s: Duration in seconds
        """
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        from obra.messages.validator import get_validator

        timestamp = self._ctx._timestamp()
        verbose = self._ctx.config.verbosity >= VerbosityLevel.DETAIL

        # Determine appropriate message key based on stage and result
        if sound:
            message = get_validator(f"{stage}.sound", verbose=verbose)
            style = "green"
            symbol = glyphs.success
        else:
            # Stage-specific result messages
            if stage == "intent":
                message = get_validator(f"{stage}.constraints", count=count or 0, verbose=verbose)
            elif stage == "plan":
                message = get_validator(f"{stage}.issues", count=count or 0, verbose=verbose)
            elif stage == "review_filter":
                decision_count = int(count or 0)
                label = "decision" if decision_count == 1 else "decisions"
                message = f"Generated {decision_count} review filter {label}"
            elif stage == "escalation_fix":
                message = get_validator(f"{stage}.repair", verbose=verbose)
            else:
                message = f"Validation completed ({stage})"
            style = "yellow"
            symbol = glyphs.arrow

        duration_str = f" ({duration_s:.1f}s)" if duration_s is not None else ""
        self._ctx._print(f"{timestamp}  {symbol} {message}{duration_str}", style=style)
        self._ctx._restore_spinner_status_line()

    def validator_skipped(self, stage: str) -> None:
        """Emit event when a SenseCheck validator stage is skipped (disabled).

        Args:
            stage: Validation stage ('intent', 'plan', 'review_filter')
        """
        if self._ctx.config.verbosity < VerbosityLevel.DETAIL:
            self._ctx._restore_spinner_status_line()
            return

        from obra.messages.validator import get_validator

        timestamp = self._ctx._timestamp()
        verbose = self._ctx.config.verbosity >= VerbosityLevel.DETAIL
        message = get_validator(f"{stage}.skipped", verbose=verbose)
        self._ctx._print(f"{timestamp}  {glyphs.skip} {message}", style="dim")
        self._ctx._restore_spinner_status_line()

    def validator_error(
        self,
        stage: str,
        error: str,
        *,
        duration_s: float | None = None,
    ) -> None:
        """Emit event when a SenseCheck validator stage fails.

        Args:
            stage: Validation stage ('intent', 'plan', 'review_filter')
            error: Error message
            duration_s: Duration in seconds
        """
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        from obra.messages.validator import build_validator_message

        timestamp = self._ctx._timestamp()
        verbose = self._ctx.config.verbosity >= VerbosityLevel.DETAIL
        message = build_validator_message(stage, "error", message=error, verbose=verbose)
        duration_str = f" ({duration_s:.1f}s)" if duration_s is not None else ""
        self._ctx._print(f"{timestamp}  {glyphs.failure} {message}{duration_str}", style="red")
        self._ctx._restore_spinner_status_line()
