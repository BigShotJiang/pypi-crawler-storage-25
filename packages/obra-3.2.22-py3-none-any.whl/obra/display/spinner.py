"""Interactive status spinner for action-first CLI status lines."""

from __future__ import annotations

import contextlib
import threading
from typing import TYPE_CHECKING, Iterator

from rich.console import Group
from rich.segment import Segment
from rich.spinner import Spinner
from rich.text import Text

from obra.display.spinner_status import SpinnerStatus, format_spinner_status

if TYPE_CHECKING:
    from rich.console import Console
    from rich.live import Live

# Custom OSC sequence marking spinner output. Terminals silently ignore
# unrecognized OSC codes per ECMA-48. The session logger TeeWriter checks
# for this before ANSI stripping to exclude transient spinner renders from
# session log files.
SPINNER_SENTINEL = "\x1b]9999;\x07"

_ACTIVE_SPINNER: "StatusSpinner | None" = None
_SPINNER_SUSPEND_DEPTH = 0
_SPINNER_SUSPEND_STATE: dict[str, object] | None = None
_SPINNER_SUSPEND_LOCK = threading.Lock()


def set_active_spinner(spinner: "StatusSpinner | None") -> None:
    """Register the active spinner for global prompt coordination."""
    global _ACTIVE_SPINNER
    _ACTIVE_SPINNER = spinner


def get_active_spinner() -> "StatusSpinner | None":
    """Return the currently registered spinner, if any."""
    return _ACTIVE_SPINNER


def suspend_active_spinner() -> "contextlib.AbstractContextManager[None]":
    """Suspend the active spinner while running interactive prompts."""

    @contextlib.contextmanager
    def _suspend() -> Iterator[None]:
        global _SPINNER_SUSPEND_DEPTH, _SPINNER_SUSPEND_STATE
        spinner = get_active_spinner()
        if spinner is None or not spinner.is_active:
            yield
            return
        with _SPINNER_SUSPEND_LOCK:
            if _SPINNER_SUSPEND_DEPTH == 0:
                _SPINNER_SUSPEND_STATE = spinner.snapshot_state()
                spinner.stop()
            _SPINNER_SUSPEND_DEPTH += 1
        try:
            yield
        finally:
            with _SPINNER_SUSPEND_LOCK:
                _SPINNER_SUSPEND_DEPTH = max(0, _SPINNER_SUSPEND_DEPTH - 1)
                if _SPINNER_SUSPEND_DEPTH == 0 and _SPINNER_SUSPEND_STATE:
                    spinner.restore_state(_SPINNER_SUSPEND_STATE)
                    _SPINNER_SUSPEND_STATE = None

    return _suspend()


class StatusSpinner:
    """Interactive status spinner for structured action-first text."""

    def __init__(
        self,
        console: "Console",
        phrase_rotation_interval_s: float = 4.0,
        phrase_rotation_min_s: float | None = None,
        phrase_rotation_max_s: float | None = None,
        accent_enabled: bool = True,
        accent_highlight_color: str = "#f5c090",
        accent_highlight_width: int = 2,
        accent_highlight_gradient: bool = True,
        accent_sweep_target_s: float = 6.0,
        accent_step_min_ms: int = 80,
        accent_step_max_ms: int = 150,
        accent_pause_min_s: float = 5.0,
        accent_pause_max_s: float = 9.0,
        refresh_rate_hz: int = 10,
    ) -> None:
        """Initialize the status spinner.

        Legacy phrase/accent parameters are retained for constructor compatibility
        but are no longer used now that the spinner renders only explicit status text.
        """
        del (
            phrase_rotation_interval_s,
            phrase_rotation_min_s,
            phrase_rotation_max_s,
            accent_enabled,
            accent_highlight_color,
            accent_highlight_width,
            accent_highlight_gradient,
            accent_sweep_target_s,
            accent_step_min_ms,
            accent_step_max_ms,
            accent_pause_min_s,
            accent_pause_max_s,
        )
        self._console = console
        self._refresh_rate_hz = refresh_rate_hz
        self._live: "Live | None" = None
        self._status_lock = threading.Lock()
        self._status_line: str | None = None
        self._status_style: str | None = None
        self._status: SpinnerStatus | None = None
        self._stop_event = threading.Event()
        self._renderable: "_SpinnerRenderable | None" = None
        self._spinner_renderable: Spinner | None = None
        self._rotation_paused: bool = False

    def start(self, initial_phrase: str | None = None) -> None:
        """Start the spinner.

        The legacy ``initial_phrase`` parameter is ignored.
        """
        del initial_phrase
        if self._live is not None:
            return

        from rich.live import Live

        self._stop_event.clear()
        self._spinner_renderable = Spinner("dots", text=Text(""))
        self._renderable = _SpinnerRenderable(self, self._spinner_renderable)
        self._live = Live(
            self._renderable,
            console=self._console,
            refresh_per_second=self._refresh_rate_hz,
            transient=True,
        )
        self._live.start()

    def stop(self) -> None:
        """Stop the spinner and clear the line."""
        self._stop_event.set()
        if self._live:
            self._live.stop()
            self._live = None
        self._renderable = None
        self._spinner_renderable = None
        with self._status_lock:
            self._status_line = None
            self._status_style = None
            self._status = None

    def update_status(self, status: SpinnerStatus, style: str | None = None) -> None:
        """Update the spinner to render a single structured status line."""
        with self._status_lock:
            self._status = status
            self._status_line = status.label
            self._status_style = style
        self._refresh_live()

    def update_status_line(self, line: str, style: str | None = None) -> None:
        """Compatibility wrapper for callers still passing a raw status string."""
        self.update_status(SpinnerStatus(label=line), style=style)

    def clear_status_line(self) -> None:
        """Clear any active structured or legacy status line."""
        with self._status_lock:
            self._status = None
            self._status_line = None
            self._status_style = None
        self._refresh_live()

    def set_rotation_paused(self, paused: bool) -> None:
        """Compatibility no-op retained for callers that pause phrase rotation."""
        self._rotation_paused = bool(paused)

    def print_above(self, message: str, style: str | None = None) -> None:
        """Print a persistent message above the spinner."""
        if self._live:
            self._live.console.print(message, style=style)
        else:
            self._console.print(message, style=style)

    @property
    def is_active(self) -> bool:
        """Return True if the spinner is currently running."""
        return self._live is not None

    def snapshot_state(self) -> dict[str, object]:
        """Capture current spinner state for suspension/resume."""
        with self._status_lock:
            status = self._status
            status_line = self._status_line
            status_style = self._status_style
        return {
            "status": status,
            "status_line": status_line,
            "status_style": status_style,
            "rotation_paused": self._rotation_paused,
            "active": self.is_active,
        }

    def restore_state(self, state: dict[str, object]) -> None:
        """Restore spinner state after suspension."""
        if not state.get("active"):
            return
        self.start()
        status = state.get("status")
        status_style = state.get("status_style")
        if isinstance(status, SpinnerStatus):
            self.update_status(status, style=str(status_style) if status_style else None)
        status_line = state.get("status_line")
        if status_line and not isinstance(status, SpinnerStatus):
            self.update_status_line(str(status_line), str(status_style) if status_style else None)
        self.set_rotation_paused(bool(state.get("rotation_paused", False)))

    def _refresh_live(self) -> None:
        """Refresh the Live renderable when active."""
        if self._live and self._renderable:
            self._live.update(self._renderable)


class _SpinnerRenderable:
    """Renderable wrapper to allow Live refresh to drive spinner updates."""

    def __init__(self, spinner: StatusSpinner, renderable: Spinner) -> None:
        self._spinner = spinner
        self._renderable = renderable

    def __rich_console__(self, console, options):
        yield Segment(SPINNER_SENTINEL, control=True)
        with self._spinner._status_lock:
            status = self._spinner._status
            status_line = self._spinner._status_line
            status_style = self._spinner._status_style
        if status is not None:
            available_width = max(16, int(getattr(options, "max_width", 80)) - 4)
            text = Text(
                f" {format_spinner_status(status, width=available_width)}",
                style=status_style or "cyan",
            )
            self._renderable.update(text=text)
            yield self._renderable
            return
        self._renderable.update(text=Text(""))
        if status_line:
            status_text = Text(status_line, style=status_style)
            yield Group(status_text, self._renderable)
            return
        yield self._renderable
