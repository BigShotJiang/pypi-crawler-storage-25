"""Shared types for review agents.

Provides AgentIssue and AgentResult dataclasses used by BaseAgent,
AgentResponseParser, and all agent subclasses. Extracted to break
circular import dependencies between base.py and response_parser.py.
"""

from dataclasses import dataclass, field
from typing import Any

from obra.api.protocol import AgentType, Priority


@dataclass
class AgentIssue:
    """Issue found by a review agent.

    Attributes:
        id: Unique issue identifier
        title: Short description of the issue
        description: Detailed description
        priority: Issue priority (P0-P3)
        file_path: File where issue was found (if applicable)
        line_number: Line number (if applicable)
        dimension: Quality dimension (security, testing, docs, maintainability)
        suggestion: Suggested fix
        issue_type: Optional issue classification (e.g., test_gap)
        target_test_file: Optional target test file for test gap issues
        target_paths: Optional list of acceptable target file paths
        test_name: Optional test function name
        arrange: Optional arrange steps for the test
        act: Optional act steps for the test
        assert_steps: Optional assert steps for the test
        issue_kind: Optional issue intent (defect | coverage_gap | docs)
        resolution_path: Optional fix routing hint (code_and_tests | tests_only)
        verification_scope: Optional verification scope hint (auto | tests | lint | security)
        metadata: Additional metadata
    """

    id: str
    title: str
    description: str
    priority: Priority
    file_path: str | None = None
    line_number: int | None = None
    dimension: str = ""
    suggestion: str = ""
    issue_type: str | None = None
    target_test_file: str | None = None
    target_paths: list[str] | None = None
    test_name: str | None = None
    arrange: str | None = None
    act: str | None = None
    assert_steps: str | None = None
    issue_kind: str = "defect"
    resolution_path: str = "code_and_tests"
    verification_scope: str = "auto"
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "priority": self.priority.value,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "dimension": self.dimension,
            "suggestion": self.suggestion,
            "issue_type": self.issue_type,
            "target_test_file": self.target_test_file,
            "target_paths": self.target_paths or [],
            "test_name": self.test_name,
            "arrange": self.arrange,
            "act": self.act,
            "assert": self.assert_steps,
            "issue_kind": self.issue_kind,
            "resolution_path": self.resolution_path,
            "verification_scope": self.verification_scope,
            "metadata": self.metadata,
        }


@dataclass
class AgentResult:
    """Result from agent execution.

    Attributes:
        agent_type: Type of agent that produced this result
        status: Execution status (complete, timeout, error)
        issues: List of issues found
        scores: Dimension scores (0.0 - 1.0)
        execution_time_ms: Time taken in milliseconds
        error: Error message if status is error
        metadata: Additional metadata
    """

    agent_type: AgentType
    status: str  # complete, timeout, error
    issues: list[AgentIssue] = field(default_factory=list)
    scores: dict[str, float] = field(default_factory=dict)
    execution_time_ms: int = 0
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API serialization."""
        return {
            "agent_type": self.agent_type.value,
            "status": self.status,
            "issues": [issue.to_dict() for issue in self.issues],
            "scores": self.scores,
            "execution_time_ms": self.execution_time_ms,
            "error": self.error,
            "metadata": self.metadata,
        }


__all__ = ["AgentIssue", "AgentResult"]
