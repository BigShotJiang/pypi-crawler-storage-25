"""File scanning utilities for review agents.

Provides the FileScanner class that handles file discovery, filtering,
and reading for agent analysis. Extracted from BaseAgent to provide
a focused single-responsibility module.
"""

import fnmatch
import logging
from pathlib import Path
from typing import Any

from obra.domains.core_filters import (
    BINARY_CHECK_BYTES,
    BINARY_EXTENSIONS,
    EXCLUDED_FILES,
    EXCLUDED_PATTERNS,
    FILE_SIZE_WARN_BYTES,
    IGNORE_DIR_SUFFIXES,
    IGNORE_DIRS,
    MAX_FILE_SIZE_BYTES,
)

logger = logging.getLogger(__name__)


class FileScanner:
    """Scans and filters files for agent analysis."""

    def __init__(
        self,
        working_dir: Path,
        domain: Any = None,
    ) -> None:
        self._working_dir = working_dir
        self._ignore_patterns = self._load_ignore_patterns()
        self._composed_ignore_dirs = IGNORE_DIRS
        self._composed_ignore_dir_suffixes = IGNORE_DIR_SUFFIXES
        self._composed_binary_extensions = BINARY_EXTENSIONS
        self._composed_excluded_files = EXCLUDED_FILES
        self._composed_excluded_patterns = list(EXCLUDED_PATTERNS)

        if domain is not None:
            domain_filters = domain.get_file_filters()
            self._composed_ignore_dirs = IGNORE_DIRS | domain_filters.ignore_dirs
            self._composed_ignore_dir_suffixes = tuple(
                dict.fromkeys(IGNORE_DIR_SUFFIXES + domain_filters.ignore_dir_suffixes)
            )
            self._composed_binary_extensions = BINARY_EXTENSIONS | domain_filters.binary_extensions
            self._composed_excluded_files = EXCLUDED_FILES | domain_filters.excluded_files
            self._composed_excluded_patterns = list(
                dict.fromkeys(list(EXCLUDED_PATTERNS) + domain_filters.excluded_patterns)
            )

    def _load_ignore_patterns(self) -> list[str]:
        """Load ignore patterns for agent scans from config."""
        try:
            from obra.config.loaders import get_agent_ignore_patterns

            return get_agent_ignore_patterns()
        except Exception:
            return []

    def _matches_ignore_pattern(self, path: Path) -> bool:
        """Check if a path matches configured ignore patterns."""
        if not self._ignore_patterns:
            return False

        try:
            rel_path = path.relative_to(self._working_dir)
            rel_str = rel_path.as_posix()
            rel_parts = rel_path.parts
        except ValueError:
            rel_str = path.as_posix()
            rel_parts = path.parts

        for pattern in self._ignore_patterns:
            if not pattern:
                continue
            if "/" not in pattern and "\\" not in pattern:
                if pattern in rel_parts:
                    return True
                continue
            if fnmatch.fnmatch(rel_str, pattern):
                return True
            if fnmatch.fnmatch(rel_str + "/", pattern):
                return True
            if pattern.endswith("/**"):
                prefix = pattern[:-3].rstrip("/")
                if prefix and (rel_str == prefix or rel_str.startswith(prefix + "/")):
                    return True
            if pattern.endswith("/**/*"):
                prefix = pattern[:-4].rstrip("/")
                if prefix and (rel_str == prefix or rel_str.startswith(prefix + "/")):
                    return True
        return False

    def _is_ignored_path(self, path: Path) -> bool:
        """Check if a path should be ignored based on IGNORE_DIRS and IGNORE_DIR_SUFFIXES.

        Only checks paths RELATIVE to working_dir. Parent directories outside
        the working directory do not affect filtering. This prevents incorrectly
        filtering all files when the working directory itself is named "build",
        ".cache", etc. (ISSUE-001).

        Args:
            path: Path to check (can be relative or absolute)

        Returns:
            True if any path component (relative to working_dir) matches an ignored
            directory name or ends with an ignored suffix (e.g., .egg-info)
        """
        try:
            # Only check relative path components within working_dir
            rel_path = path.relative_to(self._working_dir)
            if self._matches_ignore_pattern(rel_path):
                return True
            for part in rel_path.parts:
                # Exact match
                if part in self._composed_ignore_dirs:
                    return True
                # Suffix match (e.g., *.egg-info)
                if part.endswith(self._composed_ignore_dir_suffixes):
                    return True
            return False
        except ValueError:
            # Path is outside working_dir, don't filter
            return False

    # adr-042-skip — extracted from BaseAgent, contracts preserved in docstring
    def get_files_to_analyze(
        self,
        changed_files: list[str] | None = None,
        extensions: list[str] | None = None,
        exclude_binary: bool = True,
    ) -> list[Path]:
        """Get list of files to analyze.

        Args:
            changed_files: If provided, only analyze these files (scope constraint)
            extensions: DEPRECATED. If provided, filter by file extensions (allowlist)
            exclude_binary: If True, exclude binary files using blocklist (default: True)

        Returns:
            List of file paths to analyze (all paths are absolute Path objects)
        """
        if changed_files is not None:
            # Short-circuit: empty list means no files to analyze
            if not changed_files:
                return []

            # Filter to existing files, respecting IGNORE_DIRS
            files = []
            for f in changed_files:
                path = self._working_dir / f if not Path(f).is_absolute() else Path(f)
                if path.exists() and path.is_file():
                    # Skip ignored directories (e.g., .obra/, node_modules/)
                    # ISSUE-REVIEW-AGENTS-002: changed_files path was missing this filter
                    if self._is_ignored_path(path):
                        continue
                    # Allowlist takes precedence (legacy behavior)
                    if extensions is not None:
                        if path.suffix not in extensions:
                            continue
                    # Otherwise use blocklist if enabled
                    elif exclude_binary and self._is_binary_file(path):
                        continue
                    files.append(path)
            return files

        # Scan all files in working directory
        # Short-circuit: empty extensions list means nothing matches
        if extensions is not None and not extensions:
            return []

        files = []

        for path in self._working_dir.rglob("*"):
            # Skip ignored directories (uses composed core+domain filters)
            if self._is_ignored_path(path):
                continue

            if not path.is_file():
                continue

            # Allowlist takes precedence (legacy behavior)
            if extensions is not None:
                if path.suffix not in extensions:
                    continue
            # Otherwise use blocklist if enabled
            elif exclude_binary and self._is_binary_file(path):
                continue

            files.append(path)

        return files

    def _is_binary_file(self, path: Path) -> bool:
        """Check if a file should be excluded as binary/generated.

        Args:
            path: Path to check

        Returns:
            True if file should be excluded (is binary/generated)
        """
        # Check suffix against blocklist
        suffix = path.suffix.lower()
        if suffix in self._composed_binary_extensions:
            return True

        # Check for compound extensions like .min.js, .min.css
        name_lower = path.name.lower()
        return bool(name_lower.endswith((".min.js", ".min.css")))

    def read_file(self, path: Path) -> str:
        """Read file contents safely.

        Performs layered checks before reading:
        1. Hard size limit (skip files > MAX_FILE_SIZE_BYTES)
        2. Warn threshold (log warning for files > FILE_SIZE_WARN_BYTES)
        3. Binary detection (null bytes in first BINARY_CHECK_BYTES)
        4. UTF-8 decode with graceful fallback

        Args:
            path: Path to file

        Returns:
            File contents or empty string if unreadable
        """
        try:
            # Check file size first
            file_size = path.stat().st_size

            # Hard limit - skip files that are almost certainly not source code
            if file_size > MAX_FILE_SIZE_BYTES:
                logger.debug(f"Skipping very large file ({file_size:,} bytes): {path}")
                return ""

            # Warn threshold - large but possibly legitimate, let downstream handle
            if file_size > FILE_SIZE_WARN_BYTES:
                logger.warning(
                    f"Reading large file ({file_size:,} bytes): {path} - "
                    "may exceed LLM context limits"
                )

            # Proactive binary detection: check for null bytes in first chunk
            # This is faster than attempting full UTF-8 decode on large binaries
            with path.open("rb") as f:
                chunk = f.read(BINARY_CHECK_BYTES)
                if b"\x00" in chunk:
                    logger.debug(f"Skipping binary file (null bytes detected): {path}")
                    return ""

            # Now safe to read as text
            return path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            # Binary file slipped through null byte check (rare but possible)
            logger.debug(f"Skipping binary file (decode failed): {path}")
            return ""
        except Exception as e:
            # Unexpected error (permissions, missing file, etc.)
            logger.warning(f"Could not read {path}: {e}")
            return ""

    # adr-042-skip — extracted from BaseAgent
    def is_test_file(self, path: Path, patterns: list[str] | None = None) -> bool:
        """Check if a file is a test file.

        Args:
            path: Path to check
            patterns: Optional list of glob patterns for test files

        Returns:
            True if this is a test file
        """
        name = path.name
        test_patterns = patterns or ["test_*", "*_test.*", "*.test.*", "*.spec.*"]
        if any(fnmatch.fnmatch(name, pattern) for pattern in test_patterns):
            return True
        # Check if in a tests directory
        return bool("tests" in path.parts or "test" in path.parts)

    def is_excluded_file(self, path: Path) -> bool:
        """Check if a file should be excluded from analysis.

        Args:
            path: Path to check

        Returns:
            True if file should be excluded
        """
        # Check exact filename matches
        if path.name in self._composed_excluded_files:
            return True

        # Check patterns
        rel_path = str(path)
        if self._matches_ignore_pattern(path):
            return True
        return any(
            fnmatch.fnmatch(rel_path, pattern) for pattern in self._composed_excluded_patterns
        )
