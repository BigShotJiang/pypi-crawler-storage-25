"""Escalation detection for review agents.

Provides the EscalationDetector class that identifies sensitive code
requiring higher-tier LLM analysis. Extracted from BaseAgent to
provide a focused single-responsibility module.
"""

import logging
from pathlib import Path

logger = logging.getLogger(__name__)


class EscalationDetector:
    """Detects sensitive code patterns requiring escalation to higher-tier LLM."""

    # Paths that indicate sensitive code requiring escalation
    ESCALATION_PATHS: frozenset[str] = frozenset(
        {
            "auth",
            "authentication",
            "authorization",
            "payment",
            "payments",
            "billing",
            "tenant",
            "tenants",
            "migrations",
            "security",
            "crypto",
            "encryption",
        }
    )

    # Keywords in content that indicate sensitive code
    ESCALATION_KEYWORDS: frozenset[str] = frozenset(
        {
            # Authentication/Authorization
            "authenticate",
            "authorize",
            "authorization",
            "jwt",
            "oauth",
            "token",
            "session",
            "login",
            "logout",
            "password",
            "credential",
            # Payment/Financial
            "stripe",
            "paypal",
            "payment",
            "charge",
            "refund",
            "billing",
            "invoice",
            "credit_card",
            "creditcard",
            # Concurrency (race conditions)
            "asyncio.lock",
            "threading.lock",
            "multiprocessing.lock",
            "mutex",
            "semaphore",
            "atomic",
            "race_condition",
            # Security/Crypto
            "encrypt",
            "decrypt",
            "hash",
            "secret",
            "private_key",
            "privatekey",
            "api_key",
            "apikey",
            # Database migrations
            "alembic",
            "migrate",
            "migration",
            "schema",
            # Multi-tenancy
            "tenant_id",
            "tenant",
            "isolation",
        }
    )

    # adr-042-skip — stateless escalation check
    def needs_escalation(
        self,
        file_path: Path | str | None = None,
        content: str | None = None,
    ) -> bool:
        """Check if code requires escalation to higher-tier LLM.

        Detects sensitive code patterns that benefit from deeper analysis:
        - Authentication/authorization logic
        - Payment processing
        - Concurrency primitives (race condition risk)
        - Cryptographic operations
        - Multi-tenant isolation
        - Database migrations

        Args:
            file_path: File path to check (checks directory components)
            content: File content to check (scans for keywords)

        Returns:
            True if sensitive code detected, requiring escalation
        """
        # Check file path components
        if file_path:
            path = Path(file_path) if isinstance(file_path, str) else file_path
            # Check each path component
            for part in path.parts:
                if part.lower() in self.ESCALATION_PATHS:
                    logger.debug(f"Escalation triggered by path component: {part}")
                    return True

        # Check content for keywords
        if content:
            content_lower = content.lower()
            for keyword in self.ESCALATION_KEYWORDS:
                if keyword in content_lower:
                    logger.debug(f"Escalation triggered by keyword: {keyword}")
                    return True

        return False
