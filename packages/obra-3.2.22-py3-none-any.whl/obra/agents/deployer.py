"""Agent deployment manager for subprocess-based agent execution.

This module provides AgentDeployer, which manages the deployment and
execution of review agents. Each agent runs in isolation and returns
structured results.

Architecture:
    - AgentDeployer receives ReviewRequest from orchestrator
    - Deploys specified agents (sequentially or in parallel)
    - Each agent analyzes code and returns AgentResult
    - Deployer collects results and returns to orchestrator

Execution Modes:
    - Sequential: Run agents one at a time (default, safer)
    - Parallel: Run agents concurrently (faster, more memory)

Timeout Handling:
    - Each agent has a timeout (default 60s)
    - If agent exceeds timeout, result status is "timeout"
    - Deployer continues with remaining agents

Related:
    - obra/agents/base.py
    - obra/agents/registry.py
    - obra/hybrid/handlers/review.py
"""

import logging
import time
import traceback
import uuid
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FutureTimeoutError
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from obra.agents.base import AgentResult, BaseAgent
from obra.agents.registry import get_registry
from obra.api.protocol import AgentType
from obra.config import get_review_agent_timeout

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class AgentRunContext:
    """Bundles the shared parameters for agent run orchestration.

    Consolidates the 12 parameters that are threaded through
    run_agents, _run_sequential, and _run_parallel into a single
    immutable context object.
    """

    agents: list[AgentType]
    item_id: str
    changed_files: list[str] | None
    timeout_ms: int
    budgets: dict[str, dict[str, Any]]
    intent_context: str | None
    production_logger: Any | None
    session_id: str | None
    task_id: int | None
    log_event: Callable[..., None] | None
    trace_id: str | None
    parent_span_id: str | None


class AgentDeployer:
    """Manages agent deployment and execution.

    AgentDeployer is responsible for:
    - Creating agent instances from registry
    - Running agents with timeout enforcement
    - Collecting and aggregating results
    - Handling errors gracefully

    Example:
        >>> deployer = AgentDeployer(Path("/workspace"), llm_config=llm_config)
        >>> results = deployer.run_agents(
        ...     agents=[AgentType.SECURITY, AgentType.TESTING],
        ...     item_id="T1",
        ...     timeout_ms=60000
        ... )
        >>> for result in results:
        ...     print(f"{result.agent_type.value}: {len(result.issues)} issues")
    """

    def __init__(
        self,
        working_dir: Path,
        parallel: bool = False,
        max_workers: int = 4,
        llm_config: dict[str, Any] | None = None,
        domain: Any = None,
    ) -> None:
        """Initialize agent deployer.

        Args:
            working_dir: Working directory for agents
            parallel: Whether to run agents in parallel
            max_workers: Maximum concurrent agents if parallel=True
            llm_config: Optional LLM configuration dict for CLI-based analysis.
                       If None, agents return empty results (no analysis performed).
                       Pass llm_config to enable LLM-powered code analysis.
            domain: Optional domain module for prompt/filter specialization.
        """
        self._working_dir = working_dir
        self._parallel = parallel
        self._max_workers = max_workers
        self._registry = get_registry()
        self._llm_config = llm_config
        self._domain = domain

        logger.info(
            f"AgentDeployer initialized: working_dir={working_dir}, "
            f"parallel={parallel}, max_workers={max_workers}, "
            f"llm_config={'enabled' if llm_config else 'disabled'}, "
            f"domain={'set' if domain is not None else 'unset'}"
        )

    @staticmethod
    def _emit_agent_event(
        *,
        action: str,
        agent_type: AgentType,
        item_id: str,
        trace_id: str | None,
        span_id: str,
        parent_span_id: str | None,
        log_event: Callable[..., None] | None,
        production_logger: Any | None,
        session_id: str | None,
        **kwargs: Any,
    ) -> None:
        """Emit paired log_event + production_logger calls for agent lifecycle.

        Args:
            action: Event action name (e.g. "agent_started", "agent_completed").
            agent_type: The agent type enum.
            item_id: Plan item ID.
            trace_id: Trace identifier.
            span_id: Span identifier.
            parent_span_id: Parent span identifier.
            log_event: Optional event logging callback.
            production_logger: Optional ProductionLogger instance.
            session_id: Optional session ID for production logging.
            **kwargs: Additional keyword arguments forwarded to both loggers.
        """
        if log_event:
            log_event(
                action,
                agent_type=agent_type.value,
                item_id=item_id,
                trace_id=trace_id,
                span_id=span_id,
                parent_span_id=parent_span_id,
                **kwargs,
            )
        if production_logger and session_id:
            prod_method = getattr(production_logger, f"log_{action}", None)
            if callable(prod_method):
                prod_method(
                    session_id=session_id,
                    agent_type=agent_type.value,
                    span_id=span_id,
                    parent_span_id=parent_span_id,
                    **kwargs,
                )

    @property
    def working_dir(self) -> Path:
        """Get working directory."""
        return self._working_dir

    # adr-042-skip - deployer methods outside Phase 2 scope
    def run_agents(
        self,
        agents: list[AgentType],
        item_id: str,
        changed_files: list[str] | None = None,
        timeout_ms: int | None = None,
        budgets: dict[str, dict[str, Any]] | None = None,
        intent_context: str | None = None,
        production_logger: Any | None = None,
        session_id: str | None = None,
        task_id: int | None = None,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
    ) -> list[AgentResult]:
        """Run specified agents and collect results.

        Args:
            agents: List of agent types to run
            item_id: Plan item ID being reviewed
            changed_files: List of files that changed (for focused review)
            timeout_ms: Default timeout per agent in milliseconds (None = use config default)
            budgets: Per-agent budget overrides {agent_name: {"timeout_ms": int}}
            production_logger: Optional ProductionLogger for event logging
            session_id: Optional session ID for event logging
            task_id: Optional task ID for event logging

        Returns:
            List of AgentResult from each agent
        """
        # Resolve timeout from config if not provided
        if timeout_ms is None:
            timeout_ms = get_review_agent_timeout() * 1000

        ctx = AgentRunContext(
            agents=agents,
            item_id=item_id,
            changed_files=changed_files,
            timeout_ms=timeout_ms,
            budgets=budgets or {},
            intent_context=intent_context,
            production_logger=production_logger,
            session_id=session_id,
            task_id=task_id,
            log_event=log_event,
            trace_id=trace_id,
            parent_span_id=parent_span_id,
        )

        logger.info(f"Running {len(agents)} agents for item {item_id}: {[a.value for a in agents]}")

        if self._parallel:
            results = self._run_parallel(ctx)
        else:
            results = self._run_sequential(ctx)

        total_issues = sum(len(r.issues) for r in results)
        logger.info(f"Agent run complete: {len(results)} agents, {total_issues} total issues")

        return results

    # adr-042-skip - deployer methods outside Phase 2 scope
    def run_agent(
        self,
        agent_type: AgentType,
        item_id: str,
        changed_files: list[str] | None = None,
        timeout_ms: int | None = None,
        intent_context: str | None = None,
        production_logger: Any | None = None,
        session_id: str | None = None,
        task_id: int | None = None,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
    ) -> AgentResult:
        """Run a single agent.

        Args:
            agent_type: Type of agent to run
            item_id: Plan item ID being reviewed
            changed_files: List of files that changed
            timeout_ms: Timeout in milliseconds (None = use config default)
            production_logger: Optional ProductionLogger for event logging
            session_id: Optional session ID for event logging
            task_id: Optional task ID for event logging

        Returns:
            AgentResult from agent execution
        """
        # Resolve timeout from config if not provided
        if timeout_ms is None:
            timeout_ms = get_review_agent_timeout() * 1000

        start_time = time.time()
        span_id = uuid.uuid4().hex
        logger.debug(f"Deploying {agent_type.value} agent for {item_id}")

        self._emit_agent_event(
            action="agent_started",
            agent_type=agent_type,
            item_id=item_id,
            trace_id=trace_id,
            span_id=span_id,
            parent_span_id=parent_span_id,
            log_event=log_event,
            production_logger=production_logger,
            session_id=session_id,
            timeout_ms=timeout_ms,
        )

        # Create agent instance (with optional llm_config for CLI-based analysis)
        agent = self._registry.create_agent(
            agent_type,
            self._working_dir,
            llm_config=self._llm_config,
            log_event=log_event,
            domain=self._domain,
        )
        if agent is None:
            logger.error(f"No agent registered for type: {agent_type.value}")

            # Log task failure if production logger available
            if production_logger and session_id and task_id is not None:
                production_logger.log_task_failed(
                    session_id=session_id,
                    task_id=task_id,
                    error_type="AgentRegistrationError",
                    error_message=f"Agent type not registered: {agent_type.value}",
                    stack_trace=None,
                )

            return AgentResult(
                agent_type=agent_type,
                status="error",
                error=f"Agent type not registered: {agent_type.value}",
                execution_time_ms=int((time.time() - start_time) * 1000),
            )

        if hasattr(agent, "set_intent_context"):
            agent.set_intent_context(intent_context)

        # Run with timeout
        try:
            result = self._run_with_timeout(
                agent=agent,
                item_id=item_id,
                changed_files=changed_files,
                timeout_ms=timeout_ms,
            )
            result.execution_time_ms = int((time.time() - start_time) * 1000)
            self._emit_agent_event(
                action="agent_completed",
                agent_type=agent_type,
                item_id=item_id,
                trace_id=trace_id,
                span_id=span_id,
                parent_span_id=parent_span_id,
                log_event=log_event,
                production_logger=production_logger,
                session_id=session_id,
                duration_ms=result.execution_time_ms,
                status=result.status,
            )
            return result

        except TimeoutError:
            execution_time_ms = int((time.time() - start_time) * 1000)
            logger.warning(f"Agent {agent_type.value} timed out after {execution_time_ms}ms")

            # Log task failure if production logger available
            if production_logger and session_id and task_id is not None:
                production_logger.log_task_failed(
                    session_id=session_id,
                    task_id=task_id,
                    error_type="TimeoutError",
                    error_message=f"Agent {agent_type.value} timed out after {execution_time_ms}ms",
                    stack_trace=traceback.format_exc(),
                )

            self._emit_agent_event(
                action="agent_completed",
                agent_type=agent_type,
                item_id=item_id,
                trace_id=trace_id,
                span_id=span_id,
                parent_span_id=parent_span_id,
                log_event=log_event,
                production_logger=production_logger,
                session_id=session_id,
                duration_ms=execution_time_ms,
                status="timeout",
            )
            return AgentResult(
                agent_type=agent_type,
                status="timeout",
                execution_time_ms=execution_time_ms,
            )

        except Exception as e:
            execution_time_ms = int((time.time() - start_time) * 1000)
            logger.exception(f"Agent {agent_type.value} failed: {e}")

            # Log task failure if production logger available
            if production_logger and session_id and task_id is not None:
                production_logger.log_task_failed(
                    session_id=session_id,
                    task_id=task_id,
                    error_type=type(e).__name__,
                    error_message=str(e),
                    stack_trace=traceback.format_exc(),
                )

            self._emit_agent_event(
                action="agent_completed",
                agent_type=agent_type,
                item_id=item_id,
                trace_id=trace_id,
                span_id=span_id,
                parent_span_id=parent_span_id,
                log_event=log_event,
                production_logger=production_logger,
                session_id=session_id,
                duration_ms=execution_time_ms,
                status="error",
            )
            return AgentResult(
                agent_type=agent_type,
                status="error",
                error=str(e),
                execution_time_ms=execution_time_ms,
            )

    def _run_sequential(self, ctx: AgentRunContext) -> list[AgentResult]:
        """Run agents sequentially.

        Args:
            ctx: Agent run context with all shared parameters

        Returns:
            List of results
        """
        results: list[AgentResult] = []

        for agent_type in ctx.agents:
            # Get per-agent timeout
            agent_timeout = ctx.budgets.get(agent_type.value, {}).get("timeout_ms", ctx.timeout_ms)

            result = self.run_agent(
                agent_type=agent_type,
                item_id=ctx.item_id,
                changed_files=ctx.changed_files,
                timeout_ms=agent_timeout,
                intent_context=ctx.intent_context,
                production_logger=ctx.production_logger,
                session_id=ctx.session_id,
                task_id=ctx.task_id,
                log_event=ctx.log_event,
                trace_id=ctx.trace_id,
                parent_span_id=ctx.parent_span_id,
            )
            results.append(result)

        return results

    def _run_parallel(self, ctx: AgentRunContext) -> list[AgentResult]:
        """Run agents in parallel using thread pool.

        Args:
            ctx: Agent run context with all shared parameters

        Returns:
            List of results
        """
        results: list[AgentResult] = []

        with ThreadPoolExecutor(max_workers=self._max_workers) as executor:
            # Rate limiting handled by LLMConcurrencyGovernor (FEAT-LLM-GOVERNOR-001)
            futures = {}
            for _idx, agent_type in enumerate(ctx.agents):
                agent_timeout = ctx.budgets.get(agent_type.value, {}).get(
                    "timeout_ms", ctx.timeout_ms
                )
                future = executor.submit(
                    self.run_agent,
                    agent_type=agent_type,
                    item_id=ctx.item_id,
                    changed_files=ctx.changed_files,
                    timeout_ms=agent_timeout,
                    intent_context=ctx.intent_context,
                    production_logger=ctx.production_logger,
                    session_id=ctx.session_id,
                    task_id=ctx.task_id,
                    log_event=ctx.log_event,
                    trace_id=ctx.trace_id,
                    parent_span_id=ctx.parent_span_id,
                )
                futures[future] = agent_type

            # Collect results
            for future in futures:
                agent_type = futures[future]
                try:
                    result = future.result(timeout=ctx.timeout_ms / 1000 + 5)
                    results.append(result)
                except FutureTimeoutError:
                    self._log_agent_failure(
                        ctx,
                        error_type="FutureTimeoutError",
                        error_message=f"Agent {agent_type.value} parallel execution timed out",
                    )
                    results.append(
                        AgentResult(
                            agent_type=agent_type,
                            status="timeout",
                            execution_time_ms=ctx.timeout_ms,
                        )
                    )
                except Exception as e:
                    self._log_agent_failure(
                        ctx,
                        error_type=type(e).__name__,
                        error_message=f"Agent {agent_type.value} parallel execution failed: {e!s}",
                    )
                    results.append(
                        AgentResult(
                            agent_type=agent_type,
                            status="error",
                            error=str(e),
                        )
                    )

        return results

    @staticmethod
    def _log_agent_failure(
        ctx: AgentRunContext,
        *,
        error_type: str,
        error_message: str,
    ) -> None:
        """Log agent failure to production logger when available.

        Args:
            ctx: Agent run context
            error_type: Exception class name
            error_message: Human-readable error description
        """
        if ctx.production_logger and ctx.session_id and ctx.task_id is not None:
            ctx.production_logger.log_task_failed(
                session_id=ctx.session_id,
                task_id=ctx.task_id,
                error_type=error_type,
                error_message=error_message,
                stack_trace=traceback.format_exc(),
            )

    def _run_with_timeout(
        self,
        agent: BaseAgent,
        item_id: str,
        changed_files: list[str] | None,
        timeout_ms: int,
    ) -> AgentResult:
        """Run agent with timeout using thread pool.

        Args:
            agent: Agent instance
            item_id: Plan item ID
            changed_files: Changed files
            timeout_ms: Timeout in milliseconds

        Returns:
            AgentResult from agent

        Raises:
            TimeoutError: If agent exceeds timeout
        """
        with ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(
                agent.analyze,
                item_id=item_id,
                changed_files=changed_files,
                timeout_ms=timeout_ms,
            )
            try:
                return future.result(timeout=timeout_ms / 1000)
            except FutureTimeoutError as exc:
                msg = f"Agent timed out after {timeout_ms}ms"
                raise TimeoutError(msg) from exc


# adr-042-skip - deployer factory function outside Phase 2 scope
def create_deployer(
    working_dir: Path,
    parallel: bool = False,
    llm_config: dict[str, Any] | None = None,
    domain: Any = None,
) -> AgentDeployer:
    """Factory function to create an AgentDeployer.

    Args:
        working_dir: Working directory for agents
        parallel: Whether to run agents in parallel
        llm_config: Optional LLM configuration dict for CLI-based analysis.
                   If None, agents return empty results (no analysis performed).
        domain: Optional domain module for prompt/filter specialization.

    Returns:
        Configured AgentDeployer instance
    """
    return AgentDeployer(
        working_dir=working_dir,
        parallel=parallel,
        llm_config=llm_config,
        domain=domain,
    )


__all__ = ["AgentDeployer", "AgentRunContext", "create_deployer"]
