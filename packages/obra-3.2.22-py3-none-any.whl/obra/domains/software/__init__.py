"""Software development domain module.

This domain provides specialized configuration for software development
workflows including feature implementation, bug fixes, refactoring, and more.

This is the default domain used when no --domain flag is specified.

Usage:
    >>> from obra.domains.software import SoftwareDomain
    >>> domain = SoftwareDomain()
    >>> print(domain.name)
    software
    >>> work_types = domain.get_work_type_patterns()
    >>> print(len(work_types['work_types']))
    10

Related:
    - obra/domains/interface.py (protocol definition)
    - docs/guides/domains/using-domains.md
"""

import importlib.resources
from functools import lru_cache
from typing import Any

import yaml

from obra.domains.interface import FileFilterConfig, QualityDimension
from obra.domains.lifecycle import (
    ACTIVE_STATE,
    COMPATIBILITY_PATH_STATE,
    DERIVE_CAPABILITY,
    EXECUTE_CAPABILITY,
    GIT_REQUIRED_CAPABILITY,
    PREFLIGHT_CAPABILITY,
    REVIEW_CAPABILITY,
    STORY0_CAPABILITY,
    TOOLING_VERIFICATION_CAPABILITY,
    WAIT_RESUME_CAPABILITY,
    DomainDerivationDefaults,
    DomainLifecyclePolicy,
)

from .derivation import SIZING_GUIDANCE, WORK_TYPE_KEYWORDS
from .filters import (
    BINARY_EXTENSIONS,
    EXCLUDED_FILES,
    EXCLUDED_PATTERNS,
    IGNORE_DIR_SUFFIXES,
    IGNORE_DIRS,
)


class SoftwareDomain:
    """Domain module for software development workflows.

    Provides work types, quality prompts, and file filters optimized for
    software development tasks.
    """

    @property
    def name(self) -> str:
        """Return domain name."""
        return "software"

    @property
    def display_name(self) -> str:
        """Return human-readable domain name."""
        return "Software Development"

    @property
    def description(self) -> str:
        """Return short description for this domain."""
        return "Orchestration for software engineering projects"

    @property
    def example_objectives(self) -> list[str]:
        """Return representative objective examples."""
        return [
            "Add OAuth2 authentication",
            "Fix pagination bug",
            "Refactor database layer",
        ]

    @property
    def requires_git(self) -> bool:
        """Return whether this domain requires a git repository."""
        return True

    @property
    def default_sandbox_policy(self) -> str:
        """Return default sandbox policy for this domain."""
        return "WORKSPACE_WRITE"

    @property
    def closeout_key(self) -> str:
        """Return closeout template key for this domain."""
        return "software-dev"

    @lru_cache(maxsize=1)  # noqa: B019 - singleton domain, no memory leak concern
    def _load_work_types(self) -> dict[str, Any]:
        """Load work type patterns from YAML."""
        files = importlib.resources.files("obra.domains.software")
        content = (files / "work_types.yaml").read_text()
        return yaml.safe_load(content)

    def get_work_type_patterns(self) -> dict[str, Any]:
        """Return work type definitions for software development.

        Returns:
            Dictionary with work_types list, detection_settings, and fallback
        """
        return self._load_work_types()

    def get_quality_prompts(self) -> dict[str, str]:
        """Return quality assessment prompts for software development.

        Returns:
            Dictionary mapping prompt name to prompt content
        """
        return self._load_prompts()

    def get_quality_dimensions(self) -> list[QualityDimension]:
        """Return quality assessment dimensions for software workflows."""
        return [
            QualityDimension(
                id="code_quality",
                display_name="Code Quality",
                description="Static analysis and design pattern review",
                default_enabled=True,
            ),
            QualityDimension(
                id="testing_coverage",
                display_name="Test Coverage",
                description="Test gap detection and coverage analysis",
                default_enabled=True,
            ),
            QualityDimension(
                id="security_sweep",
                display_name="Security",
                description="Vulnerability scanning and OWASP checks",
                default_enabled=False,
            ),
            QualityDimension(
                id="docs_analysis",
                display_name="Documentation",
                description="Documentation quality and completeness analysis",
                default_enabled=False,
            ),
        ]

    @lru_cache(maxsize=1)  # noqa: B019 - singleton domain, no memory leak concern
    def _load_prompts(self) -> dict[str, str]:
        """Load quality prompts from prompt files."""
        files = importlib.resources.files("obra.domains.software.prompts")
        prompts = {}
        prompt_names = [
            "code_quality",
            "testing_coverage",
            "docs_analysis",
            "security_sweep",
            "security_deep",
        ]
        for name in prompt_names:
            prompts[name] = (files / f"{name}.txt").read_text()
        return prompts

    def get_file_filters(self) -> FileFilterConfig:
        """Return file exclusion/inclusion patterns for software projects.

        Returns:
            FileFilterConfig with software-specific exclusion rules
        """
        return FileFilterConfig(
            excluded_files=EXCLUDED_FILES,
            excluded_patterns=EXCLUDED_PATTERNS,
            binary_extensions=BINARY_EXTENSIONS,
            ignore_dirs=IGNORE_DIRS,
            ignore_dir_suffixes=IGNORE_DIR_SUFFIXES,
        )

    def get_derivation_keywords(self) -> dict[str, list[str]]:
        """Return keywords for work type detection.

        Returns:
            Dictionary mapping work type ID to list of detection keywords
        """
        return WORK_TYPE_KEYWORDS

    def get_sizing_guidance(self) -> str:
        """Return sizing guidance text for software development.

        Returns:
            Markdown-formatted sizing guidance
        """
        return SIZING_GUIDANCE

    def get_lifecycle_policy(self) -> DomainLifecyclePolicy:
        """Return workflow-lifecycle defaults for software projects."""
        return DomainLifecyclePolicy(
            capability_states={
                DERIVE_CAPABILITY: ACTIVE_STATE,
                EXECUTE_CAPABILITY: ACTIVE_STATE,
                STORY0_CAPABILITY: COMPATIBILITY_PATH_STATE,
                PREFLIGHT_CAPABILITY: ACTIVE_STATE,
                REVIEW_CAPABILITY: COMPATIBILITY_PATH_STATE,
                WAIT_RESUME_CAPABILITY: ACTIVE_STATE,
                GIT_REQUIRED_CAPABILITY: ACTIVE_STATE,
                TOOLING_VERIFICATION_CAPABILITY: ACTIVE_STATE,
            }
        )

    def get_derivation_defaults(self) -> DomainDerivationDefaults:
        """Return structured derivation defaults for software workflows."""
        return DomainDerivationDefaults(default_work_type="general")

    def get_runner_catalog_entries(self) -> list[dict[str, Any]]:
        """Return catalog-backed runner declarations for the software domain."""
        return [
            {
                "id": "software.test.pytest",
                "display_name": "Pytest Runner",
                "kind": "command_runner",
                "version": "1.0.0",
                "scope": "domain",
                "domain_ids": ["software"],
                "portability": "portable",
                "compatibility": {"catalog_api_version": "1"},
                "source": {
                    "source_type": "obra_builtin",
                    "package": "obra",
                },
                "activation": {"command": ["pytest", "--tb=short", "-q"]},
                "description": "Run pytest test suite",
                "tags": ["software", "testing", "pytest"],
            },
            {
                "id": "software.lint.ruff",
                "display_name": "Ruff Linter",
                "kind": "command_runner",
                "version": "1.0.0",
                "scope": "domain",
                "domain_ids": ["software"],
                "portability": "portable",
                "compatibility": {"catalog_api_version": "1"},
                "source": {
                    "source_type": "obra_builtin",
                    "package": "obra",
                },
                "activation": {"command": ["ruff", "check"]},
                "description": "Run ruff linter",
                "tags": ["software", "linting", "ruff"],
            },
        ]


def build_code_quality_prompt() -> str:
    """Return software domain code-quality prompt."""
    return SoftwareDomain().get_quality_prompts()["code_quality"]


def build_testing_coverage_prompt() -> str:
    """Return software domain testing-coverage prompt."""
    return SoftwareDomain().get_quality_prompts()["testing_coverage"]


def build_docs_analysis_prompt() -> str:
    """Return software domain docs-analysis prompt."""
    return SoftwareDomain().get_quality_prompts()["docs_analysis"]


def build_security_sweep_prompt() -> str:
    """Return software domain fast security prompt."""
    return SoftwareDomain().get_quality_prompts()["security_sweep"]


def build_security_deep_prompt() -> str:
    """Return software domain deep security prompt."""
    return SoftwareDomain().get_quality_prompts()["security_deep"]
