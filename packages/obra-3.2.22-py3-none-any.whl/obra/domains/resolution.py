"""Shared domain-resolution contracts for client, gateway, and server flows."""

from __future__ import annotations

from dataclasses import dataclass
from http import HTTPStatus
from typing import Any, Literal, Mapping, Sequence

from .loader import DomainNotFoundError, DomainValidationError, load_domain

DomainResolutionStatus = Literal[
    "explicit",
    "configured_default",
    "legacy_recovered",
    "unresolved",
    "invalid",
]

_RESOLVED_STATUSES: set[str] = {
    "explicit",
    "configured_default",
    "legacy_recovered",
}
_VALID_RESOLUTION_STATUSES: set[str] = _RESOLVED_STATUSES | {"unresolved", "invalid"}
_VALID_INPUT_STATUSES: set[str] = {
    "explicit",
    "configured_default",
    "legacy_recovered",
}


class DomainResolutionError(ValueError):
    """Raised when a boundary cannot proceed with a resolved domain."""

    def __init__(
        self,
        code: Literal["unresolved_domain", "invalid_domain", "domain_conflict"],
        message: str,
        *,
        http_status: HTTPStatus,
        resolution: DomainResolutionResult | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.http_status = http_status
        self.resolution = resolution

    def to_payload(self) -> dict[str, str]:
        payload = {"error": str(self), "code": self.code}
        if self.resolution is not None:
            payload["domain_resolution_state"] = self.resolution.to_dict()
        return payload


class InvalidDomainError(DomainResolutionError):
    """Raised when a provided or recovered domain is invalid."""

    def __init__(
        self,
        message: str,
        *,
        resolution: DomainResolutionResult | None = None,
    ) -> None:
        super().__init__(
            "invalid_domain",
            message,
            http_status=HTTPStatus.BAD_REQUEST,
            resolution=resolution,
        )


class UnresolvedDomainError(DomainResolutionError):
    """Raised when no explicit or configured-default domain resolves."""

    def __init__(
        self,
        message: str,
        *,
        resolution: DomainResolutionResult | None = None,
    ) -> None:
        super().__init__(
            "unresolved_domain",
            message,
            http_status=HTTPStatus.BAD_REQUEST,
            resolution=resolution,
        )


class DomainConflictError(DomainResolutionError):
    """Raised when two explicit domain sources disagree."""

    def __init__(
        self,
        message: str,
        *,
        resolution: DomainResolutionResult | None = None,
    ) -> None:
        super().__init__(
            "domain_conflict",
            message,
            http_status=HTTPStatus.CONFLICT,
            resolution=resolution,
        )


@dataclass(frozen=True, slots=True)
class DomainResolutionResult:
    """Structured domain-resolution outcome."""

    status: DomainResolutionStatus
    domain_id: str | None = None
    source: str | None = None
    message: str | None = None
    raw_value: str | None = None

    @property
    def is_resolved(self) -> bool:
        return self.status in _RESOLVED_STATUSES and bool(self.domain_id)

    @property
    def domain_name(self) -> str | None:
        return self.domain_id

    @property
    def invalid_value(self) -> str | None:
        return self.raw_value

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"status": self.status}
        if self.domain_id is not None:
            payload["domain_id"] = self.domain_id
        if self.source is not None:
            payload["source"] = self.source
        if self.message is not None:
            payload["message"] = self.message
        if self.raw_value is not None:
            payload["raw_value"] = self.raw_value
        return payload

    def to_state_dict(self) -> dict[str, Any]:
        return self.to_dict()

    @classmethod
    def from_dict(
        cls,
        payload: Mapping[str, Any] | None,
    ) -> "DomainResolutionResult":
        data = payload if isinstance(payload, Mapping) else {}
        raw_status = str(data.get("status", "") or "").strip()
        status: DomainResolutionStatus = (
            raw_status if raw_status in _VALID_RESOLUTION_STATUSES else "unresolved"
        )
        domain_id = normalize_domain_id(data.get("domain_id", data.get("domain")))
        source = normalize_optional_text(data.get("source")) or "missing"
        message = normalize_optional_text(data.get("message"))
        raw_value = normalize_optional_text(data.get("raw_value", data.get("invalid_value")))
        if status in _RESOLVED_STATUSES and domain_id is None:
            status = "unresolved"
        return cls(
            status=status,
            domain_id=domain_id,
            source=source,
            message=message,
            raw_value=raw_value,
        )

    @classmethod
    def from_state_dict(
        cls,
        payload: Mapping[str, Any] | None,
    ) -> "DomainResolutionResult":
        return cls.from_dict(payload)


def normalize_optional_text(value: Any) -> str | None:
    """Normalize a string-like value to stripped text or None."""
    if not isinstance(value, str):
        return None
    normalized = value.strip()
    return normalized or None


def normalize_domain_name(value: Any) -> str | None:
    """Normalize a domain identifier."""
    normalized = normalize_optional_text(value)
    if normalized is None:
        return None
    return normalized.lower()


def normalize_domain_id(value: Any) -> str | None:
    """Alias for domain identifier normalization."""
    return normalize_domain_name(value)


def unresolved_domain(
    *,
    source: str = "missing",
    message: str | None = None,
) -> DomainResolutionResult:
    """Build a canonical unresolved-domain result."""
    return DomainResolutionResult(
        status="unresolved",
        source=source,
        message=message,
    )


def validate_domain_id(
    domain_id: str | None,
    *,
    status: Literal["explicit", "configured_default", "legacy_recovered"],
    source: str,
) -> DomainResolutionResult:
    """Validate and classify a single domain identifier."""
    normalized = normalize_domain_id(domain_id)
    if normalized is None:
        return unresolved_domain(source=source)
    try:
        return DomainResolutionResult(
            status=status,
            domain_id=_validate_domain_id(normalized),
            source=source,
        )
    except InvalidDomainError as exc:
        return DomainResolutionResult(
            status="invalid",
            source=source,
            raw_value=normalized,
            message=str(exc),
        )


def resolve_domain_candidate(
    domain_name: str | None,
    *,
    source: str,
    status: Literal["explicit", "configured_default", "legacy_recovered"] = "explicit",
) -> DomainResolutionResult:
    """Compatibility wrapper for validating one candidate."""
    return validate_domain_id(domain_name, status=status, source=source)


def resolve_domain_precedence(
    candidates: Sequence[tuple[str | None, str, str]],
) -> DomainResolutionResult:
    """Resolve the first valid domain candidate in priority order."""
    for raw_value, raw_status, source in candidates:
        status = raw_status if raw_status in _VALID_INPUT_STATUSES else "explicit"
        result = validate_domain_id(raw_value, status=status, source=source)
        if result.status == "unresolved":
            continue
        return result
    return unresolved_domain()


def resolve_domain_candidates(
    candidates: Sequence["DomainResolutionCandidate"],
    *,
    unresolved_source: str | None = None,
) -> DomainResolutionResult:
    """Resolve candidates from structured candidate objects."""
    result = resolve_domain_precedence(
        [(candidate.domain_id, candidate.status, candidate.source) for candidate in candidates]
    )
    if result.status == "unresolved" and unresolved_source is not None:
        return unresolved_domain(source=unresolved_source)
    return result


@dataclass(frozen=True, slots=True)
class DomainResolutionCandidate:
    """One ordered candidate for domain resolution."""

    domain_id: str | None
    source: str
    status: Literal["explicit", "configured_default", "legacy_recovered"] = "explicit"

    @property
    def domain_name(self) -> str | None:
        return self.domain_id


def ensure_matching_domains(
    *,
    explicit_request_domain_id: str | None,
    workflow_domain_id: str | None,
    source: str,
) -> None:
    """Raise when two explicit domains disagree."""
    request_domain = normalize_domain_id(explicit_request_domain_id)
    workflow_domain = normalize_domain_id(workflow_domain_id)
    if request_domain is None or workflow_domain is None:
        return
    request_result = validate_domain_id(
        request_domain,
        status="explicit",
        source=f"{source}.request_domain",
    )
    if request_result.status == "invalid":
        raise InvalidDomainError(request_result.message or f"Invalid request domain for {source}.")
    workflow_result = validate_domain_id(
        workflow_domain,
        status="explicit",
        source=f"{source}.workflow_domain",
    )
    if workflow_result.status == "invalid":
        raise InvalidDomainError(
            workflow_result.message or f"Invalid workflow domain for {source}."
        )
    if request_result.domain_id != workflow_result.domain_id:
        raise DomainConflictError(
            (
                f"Explicit domain conflict for {source}: request resolved to "
                f"'{request_result.domain_id}' but workflow metadata resolved to "
                f"'{workflow_result.domain_id}'."
            )
        )


def detect_domain_conflict(
    *,
    request_domain_name: str | None,
    resolved_domain_name: str | None,
    request_source: str = "request.domain_id",
    resolved_source: str = "workflow.domain_id",
) -> None:
    """Compatibility wrapper for explicit domain conflict detection."""
    ensure_matching_domains(
        explicit_request_domain_id=request_domain_name,
        workflow_domain_id=resolved_domain_name,
        source=f"{request_source}->{resolved_source}",
    )


def require_resolved_domain(
    result: DomainResolutionResult,
    *,
    context: str,
) -> str:
    """Return a resolved domain identifier or raise a typed boundary error."""
    if result.status == "invalid":
        raise InvalidDomainError(
            result.message or f"{context} cannot continue because the resolved domain is invalid.",
            resolution=result,
        )
    if not result.is_resolved:
        raise UnresolvedDomainError(
            (
                f"{context} requires an explicit domain selection or an explicit "
                "configured default domain."
            ),
            resolution=result,
        )
    return str(result.domain_id)


def require_session_domain(
    session: Any,
    *,
    context: str,
) -> str:
    """Require a resolved session domain from persisted session metadata."""
    stored_resolution = DomainResolutionResult.from_dict(
        getattr(session, "domain_resolution_state", None)
        if isinstance(getattr(session, "domain_resolution_state", None), Mapping)
        else None
    )
    if stored_resolution.source != "missing":
        return require_resolved_domain(stored_resolution, context=context)

    fallback_domain = normalize_domain_id(getattr(session, "domain", None))
    return require_resolved_domain(
        validate_domain_id(
            fallback_domain,
            status="explicit",
            source="session.domain",
        ),
        context=context,
    )


def recover_legacy_session_domain(data: Mapping[str, Any]) -> DomainResolutionResult:
    """Recover a legacy session domain from explicit persisted workflow metadata."""
    candidates: list[tuple[str, str]] = []
    for path in (
        ("workflow_derivation_state", "request", "domain_id"),
        ("workflow_derivation_state", "normalized_inputs", "domain_id"),
        ("workflow_derivation_state", "derived_workflow_artifact", "domain_id"),
        ("workflow_lifecycle_state", "accepted", "domain_id"),
    ):
        raw_value = _get_nested_mapping_value(data, path)
        normalized = normalize_domain_id(raw_value)
        if normalized is None:
            continue
        candidates.append((normalized, ".".join(path)))

    if not candidates:
        return unresolved_domain(
            source="missing",
            message=(
                "Session restore could not recover a domain from persisted workflow metadata."
            ),
        )

    unique_domains = {domain_id for domain_id, _ in candidates}
    if len(unique_domains) > 1:
        return DomainResolutionResult(
            status="invalid",
            source="legacy_recovery",
            message=(
                "Session restore found conflicting legacy domain metadata: "
                + ", ".join(sorted(unique_domains))
            ),
            raw_value=", ".join(sorted(unique_domains)),
        )

    domain_id, source = candidates[0]
    return validate_domain_id(
        domain_id,
        status="legacy_recovered",
        source=source,
    )


def _get_nested_mapping_value(data: Mapping[str, Any], path: Sequence[str]) -> Any:
    current: Any = data
    for part in path:
        if not isinstance(current, Mapping):
            return None
        current = current.get(part)
    return current


def _validate_domain_id(domain_id: str) -> str:
    try:
        return load_domain(domain_id).name
    except (DomainNotFoundError, DomainValidationError) as exc:
        raise InvalidDomainError(f"Invalid domain '{domain_id}': {exc}") from exc


__all__ = [
    "DomainConflictError",
    "DomainResolutionCandidate",
    "DomainResolutionError",
    "DomainResolutionResult",
    "InvalidDomainError",
    "UnresolvedDomainError",
    "detect_domain_conflict",
    "ensure_matching_domains",
    "normalize_domain_id",
    "normalize_domain_name",
    "normalize_optional_text",
    "recover_legacy_session_domain",
    "require_resolved_domain",
    "require_session_domain",
    "resolve_domain_candidate",
    "resolve_domain_candidates",
    "resolve_domain_precedence",
    "unresolved_domain",
    "validate_domain_id",
]
