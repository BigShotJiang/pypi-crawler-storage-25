"""YAML-backed base class for domain modules."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from obra.domains.interface import FileFilterConfig, QualityDimension
from obra.domains.lifecycle import DomainDerivationDefaults, DomainLifecyclePolicy


class ConfigDomain:
    """Base class for domains that load metadata from YAML configuration."""

    def __init__(self, config_path: Path) -> None:
        self._config_path = Path(config_path)
        if not self._config_path.exists():
            msg = f"Domain config not found: {self._config_path}"
            raise FileNotFoundError(msg)

        raw = yaml.safe_load(self._config_path.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            msg = f"Domain config must be a mapping: {self._config_path}"
            raise ValueError(msg)
        self._config = raw

        self._name = self._required_str("name")
        self._display_name = self._required_str("display_name")
        self._description = self._required_str("description")
        self._example_objectives = self._required_str_list("example_objectives")
        self._requires_git = self._required_bool("requires_git")
        self._default_sandbox_policy = self._required_str("default_sandbox_policy")
        self._closeout_key = self._required_str("closeout_key")

    def _required_value(self, key: str) -> Any:
        if key not in self._config:
            msg = f"Missing required domain config key '{key}' in {self._config_path}"
            raise ValueError(msg)
        return self._config[key]

    def _required_str(self, key: str) -> str:
        value = self._required_value(key)
        if not isinstance(value, str):
            msg = f"Domain config key '{key}' must be a string in {self._config_path}"
            raise ValueError(msg)
        return value

    def _required_bool(self, key: str) -> bool:
        value = self._required_value(key)
        if not isinstance(value, bool):
            msg = f"Domain config key '{key}' must be a boolean in {self._config_path}"
            raise ValueError(msg)
        return value

    def _required_str_list(self, key: str) -> list[str]:
        value = self._required_value(key)
        if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
            msg = f"Domain config key '{key}' must be a list[str] in {self._config_path}"
            raise ValueError(msg)
        return value

    @property
    def name(self) -> str:
        return self._name

    @property
    def display_name(self) -> str:
        return self._display_name

    @property
    def description(self) -> str:
        return self._description

    @property
    def example_objectives(self) -> list[str]:
        return self._example_objectives

    @property
    def requires_git(self) -> bool:
        return self._requires_git

    @property
    def default_sandbox_policy(self) -> str:
        return self._default_sandbox_policy

    @property
    def closeout_key(self) -> str:
        return self._closeout_key

    def get_work_type_patterns(self) -> dict[str, Any]:
        raise NotImplementedError("Subclasses must implement get_work_type_patterns()")

    def get_quality_prompts(self) -> dict[str, str]:
        raise NotImplementedError("Subclasses must implement get_quality_prompts()")

    def get_file_filters(self) -> FileFilterConfig:
        raise NotImplementedError("Subclasses must implement get_file_filters()")

    def get_derivation_keywords(self) -> dict[str, list[str]]:
        raise NotImplementedError("Subclasses must implement get_derivation_keywords()")

    def get_sizing_guidance(self) -> str:
        raise NotImplementedError("Subclasses must implement get_sizing_guidance()")

    def get_quality_dimensions(self) -> list[QualityDimension]:
        raise NotImplementedError("Subclasses must implement get_quality_dimensions()")

    def get_lifecycle_policy(self) -> DomainLifecyclePolicy:
        return DomainLifecyclePolicy()

    def get_derivation_defaults(self) -> DomainDerivationDefaults:
        return DomainDerivationDefaults()
