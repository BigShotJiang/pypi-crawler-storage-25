"""Automatic session console output capture for feedback reports.

This module provides automatic capture of all CLI output to session-specific
log files, enabling zero-friction inclusion of console output in bug reports.

Design:
- Captures stdout/stderr to session-specific log files
- Strips Rich formatting for plain text storage
- On resume, appends to existing log with a separator (single file per session)
- Auto-prunes old session logs (keeps last 10)
- Thread-safe for concurrent output
- Works with Rich Console streaming output

Usage:
    with SessionConsoleLogger(session_id="abc-123") as logger:
        # All print/console output is captured
        console.print("Hello world")
        print("Also captured")

    # Or as a singleton for the CLI entry point:
    logger = get_session_logger()
    logger.start("session-123")
    # ... CLI execution ...
    logger.stop()
"""

import io
import logging
import sys
from contextlib import contextmanager, suppress
from datetime import UTC, datetime
from pathlib import Path
from threading import Lock
from typing import Any, TextIO
from uuid import uuid4

from obra.constants import FEEDBACK_MAX_SESSIONS
from obra.utils.obra_home import get_runtime_dir
from obra.utils.retention import prune_files_by_mtime

logger = logging.getLogger(__name__)


def _uses_in_memory_capture_stream(stream: Any) -> bool:
    """Return whether a stream is an in-memory capture wrapper.

    CliRunner uses wrapped in-memory streams such as
    ``click.testing._NamedTextIOWrapper`` over ``click.testing.BytesIOCopy``.
    Session logging must not install its own tee writer on top of those
    capture streams because restoring them later can hand Click a closed
    wrapper from a previous invocation.
    """
    seen: set[int] = set()
    to_visit = [stream]

    while to_visit:
        current = to_visit.pop()
        if current is None:
            continue

        current_id = id(current)
        if current_id in seen:
            continue
        seen.add(current_id)

        if isinstance(current, io.StringIO | io.BytesIO):
            return True

        current_type = type(current)
        if current_type.__module__.startswith(("click.testing", "typer.testing")):
            return True

        for attr_name in (
            "buffer",
            "raw",
            "wrapped",
            "stream",
            "_stream",
            "_buffer",
            "_wrapped",
        ):
            with suppress(Exception):
                nested = getattr(current, attr_name, None)
            if nested is not None:
                to_visit.append(nested)

    return False


class SessionConsoleLogger:
    """Captures console output to a session-specific log file.

    This class intercepts stdout/stderr and writes a copy to a log file
    while still displaying output to the terminal.

    Features:
    - Tee-style capture (output goes to both terminal and file)
    - Thread-safe writing
    - Auto-creates log directory
    - Auto-prunes old session logs
    - Strips ANSI escape codes for clean log files
    """

    # Maximum sessions to keep
    MAX_SESSIONS = FEEDBACK_MAX_SESSIONS

    # Log directory
    LOG_DIR = get_runtime_dir() / "logs" / "sessions"

    def __init__(self, session_id: str | None = None):
        """Initialize session console logger.

        Args:
            session_id: Session ID for log file naming. If None, uses timestamp.
        """
        self.session_id = (
            session_id or f"{datetime.now(UTC).strftime('%Y%m%d_%H%M%S')}_{uuid4().hex[:8]}"
        )
        self._log_path = self._get_log_path(self.session_id)
        self._lock = Lock()
        self._file: TextIO | None = None
        self._original_stdout: TextIO | None = None
        self._original_stderr: TextIO | None = None
        self._started = False

    def _get_log_path(self, session_id: str) -> Path:
        """Get the log file path for a session.

        Always returns {session_id}.log. On resume, the same file is
        reopened in append mode with a resume separator (see start()).

        Args:
            session_id: Session ID

        Returns:
            Path to the session log file
        """
        return self.LOG_DIR / f"{session_id}.log"

    @property
    def log_path(self) -> Path:
        """Get the path to the session log file."""
        return self._log_path

    def start(self) -> "SessionConsoleLogger":
        """Start capturing console output.

        Returns:
            Self for chaining
        """
        if self._started:
            return self
        if _uses_in_memory_capture_stream(sys.stdout) or _uses_in_memory_capture_stream(sys.stderr):
            try:
                from obra.display import refresh_console_streams

                refresh_console_streams()
            except ImportError:
                pass
            logger.debug("Skipping session console logging for in-memory stdout.")
            return self

        try:
            # Create log directory
            self.LOG_DIR.mkdir(parents=True, exist_ok=True)

            # Append to existing log on resume, create new for initial run
            is_resume = self._log_path.exists() and self._log_path.stat().st_size > 0
            if is_resume:
                self._file = self._log_path.open("a", encoding="utf-8")
                self._file.write("\n" + "=" * 60 + "\n")
                self._file.write("# Session Resumed\n")
                self._file.write(f"# Started: {datetime.now(UTC).isoformat()}\n")
                self._file.write("=" * 60 + "\n\n")
            else:
                self._file = self._log_path.open("w", encoding="utf-8")
                self._file.write(f"# Session Console Log: {self.session_id}\n")
                self._file.write(f"# Started: {datetime.now(UTC).isoformat()}\n")
                self._file.write("# This log is auto-generated for debugging purposes\n")
                self._file.write("-" * 60 + "\n\n")
            self._file.flush()

            # Install tee writers
            self._original_stdout = sys.stdout
            self._original_stderr = sys.stderr
            sys.stdout = _TeeWriter(self._original_stdout, self._file, self._lock)
            sys.stderr = _TeeWriter(
                self._original_stderr, self._file, self._lock, prefix="[stderr] "
            )

            self._started = True

            # Refresh Rich Console file handles to use the TeeWriter
            # This ensures console.print() output is captured in the log
            try:
                from obra.display import refresh_console_streams

                refresh_console_streams()
            except ImportError:
                pass  # Display module not available, skip refresh

            # Prune old sessions
            self._prune_old_sessions()

            logger.debug(f"Session console logging started: {self._log_path}")

        except Exception as e:
            logger.warning(f"Failed to start session console logging: {e}")
            # Don't fail the CLI if logging fails
            self._cleanup()

        return self

    def stop(self) -> None:
        """Stop capturing console output."""
        if not self._started:
            return

        try:
            # Restore original streams
            if self._original_stdout and self._owns_stream(sys.stdout, self._original_stdout):
                sys.stdout = self._original_stdout
            if self._original_stderr and self._owns_stream(sys.stderr, self._original_stderr):
                sys.stderr = self._original_stderr

            # Refresh Rich Console file handles back to original streams
            try:
                from obra.display import refresh_console_streams

                refresh_console_streams()
            except ImportError:
                pass  # Display module not available, skip refresh

            # Write footer and close
            if self._file:
                self._file.write("\n" + "-" * 60 + "\n")
                self._file.write(f"# Ended: {datetime.now(UTC).isoformat()}\n")
                self._file.close()

            logger.debug(f"Session console logging stopped: {self._log_path}")

        except Exception as e:
            logger.warning(f"Error stopping session console logging: {e}")
        finally:
            self._cleanup()

    def _owns_stream(self, current_stream: TextIO, original_stream: TextIO) -> bool:
        """Return whether the current process stream belongs to this logger."""
        if current_stream is original_stream:
            return True
        return (
            isinstance(current_stream, _TeeWriter) and current_stream._terminal is original_stream
        )

    def rename_session(self, new_session_id: str) -> bool:
        """Rename the log file to use a new session ID.

        This is useful when logging starts before the real session ID is known.
        The log file is renamed while keeping it open (content preserved).

        Args:
            new_session_id: The new session ID to use for the log file

        Returns:
            True if rename succeeded, False otherwise
        """
        if not self._started or not self._file:
            return False

        if new_session_id == self.session_id:
            return True  # Already using this ID

        new_path = self.LOG_DIR / f"{new_session_id}.log"
        old_path = self._log_path

        try:
            with self._lock:
                # Flush current content
                self._file.flush()

                # Close, rename, reopen
                self._file.close()
                old_path.rename(new_path)
                self._file = new_path.open("a", encoding="utf-8")

                # Update internal state
                self._log_path = new_path
                self.session_id = new_session_id

                # Update tee writers with new file handle
                if isinstance(sys.stdout, _TeeWriter):
                    sys.stdout._file = self._file
                if isinstance(sys.stderr, _TeeWriter):
                    sys.stderr._file = self._file

                # Log the rename
                self._file.write(f"\n# Session ID updated: {new_session_id}\n")
                self._file.flush()

            logger.debug(f"Session log renamed: {old_path} -> {new_path}")
            return True

        except Exception as e:
            logger.warning(f"Failed to rename session log: {e}")
            # Try to recover by reopening the old file
            try:
                if old_path.exists():
                    self._file = old_path.open("a", encoding="utf-8")
                elif new_path.exists():
                    self._file = new_path.open("a", encoding="utf-8")
                    self._log_path = new_path
                    self.session_id = new_session_id
            except Exception:
                pass
            return False

    def _cleanup(self) -> None:
        """Clean up resources."""
        self._file = None
        self._original_stdout = None
        self._original_stderr = None
        self._started = False

    def _prune_old_sessions(self) -> None:
        """Remove old session logs, keeping only the most recent."""
        try:
            deleted = prune_files_by_mtime(
                self.LOG_DIR,
                max_files=self.MAX_SESSIONS,
                glob="*.log",
                protected_paths={self._log_path},
                logger=logger,
            )
            if deleted:
                logger.debug("Pruned %s old session log(s).", deleted)
        except Exception as e:
            logger.warning("Failed to prune old session logs: %s", e)

    def __enter__(self) -> "SessionConsoleLogger":
        """Context manager entry."""
        return self.start()

    def __exit__(self, _exc_type: Any, _exc_val: Any, _exc_tb: Any) -> None:
        """Context manager exit."""
        self.stop()

    @classmethod
    def get_session_logs(cls, session_id: str) -> list[Path]:
        """Get the log file for a session.

        Args:
            session_id: Session ID to find logs for

        Returns:
            List containing the session log path, or empty if not found
        """
        if not cls.LOG_DIR.exists():
            return []

        log_path = cls.LOG_DIR / f"{session_id}.log"
        return [log_path] if log_path.exists() else []

    @classmethod
    def get_session_log(cls, session_id: str) -> str | None:
        """Read log contents for a session.

        Args:
            session_id: Session ID to read

        Returns:
            Log contents as string, or None if not found
        """
        log_path = cls.LOG_DIR / f"{session_id}.log"
        if not log_path.exists():
            return None

        try:
            return log_path.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            logger.warning(f"Failed to read session log {session_id}: {e}")
            return None

    @classmethod
    def get_recent_session_log(cls) -> tuple[str | None, str | None]:
        """Get the most recent session log file.

        Returns:
            Tuple of (session_id, log_contents) or (None, None) if no logs exist
        """
        try:
            if not cls.LOG_DIR.exists():
                return None, None

            log_files = sorted(
                cls.LOG_DIR.glob("*.log"),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )

            if not log_files:
                return None, None

            most_recent = log_files[0]
            session_id = most_recent.stem
            content = most_recent.read_text(encoding="utf-8", errors="replace")
            return session_id, content

        except Exception as e:
            logger.warning(f"Failed to get recent session log: {e}")
            return None, None

    @classmethod
    def list_sessions(cls) -> list[dict[str, Any]]:
        """List all available session logs.

        Returns:
            List of session info dictionaries with fields:
            - session_id: Session ID (filename stem)
            - file_name: Log filename
            - path: Full path to log file
            - size_bytes: File size
            - modified: Last modified timestamp
        """
        sessions = []
        try:
            if not cls.LOG_DIR.exists():
                return []

            for log_file in cls.LOG_DIR.glob("*.log"):
                stat = log_file.stat()
                sessions.append(
                    {
                        "session_id": log_file.stem,
                        "file_name": log_file.name,
                        "path": str(log_file),
                        "size_bytes": stat.st_size,
                        "modified": datetime.fromtimestamp(stat.st_mtime, UTC).isoformat(),
                    }
                )

            return sorted(sessions, key=lambda x: x["modified"], reverse=True)

        except Exception as e:
            logger.warning(f"Failed to list session logs: {e}")
            return []


class _TeeWriter(io.TextIOBase):
    """A writer that outputs to both a terminal and a file.

    Strips ANSI escape codes when writing to the file for clean logs.
    Uses a sentinel-based approach to identify and exclude spinner renders:
    the StatusSpinner injects a custom OSC escape sequence (SPINNER_SENTINEL)
    at the start of every render. Any content from the sentinel onwards is
    transient spinner output and is truncated before logging.
    """

    # ANSI escape code pattern
    import re

    ANSI_PATTERN = re.compile(r"\x1b\[[0-9;?]*[a-zA-Z]|\x1b\].*?\x07")

    def __init__(
        self,
        terminal: TextIO,
        file: TextIO,
        lock: Lock,
        prefix: str = "",
    ):
        """Initialize tee writer.

        Args:
            terminal: Original terminal stream
            file: File to also write to
            lock: Lock for thread-safe writing
            prefix: Optional prefix for file output (e.g., "[stderr] ")
        """
        self._terminal = terminal
        self._file = file
        self._lock = lock
        self._prefix = prefix
        # Store encoding in private attr to avoid conflict with io.TextIOBase.encoding property
        self._encoding_value: str = getattr(terminal, "encoding", None) or "utf-8"

    @property
    def encoding(self) -> str:  # type: ignore[override]
        """Return the encoding used by this writer."""
        return self._encoding_value

    def write(self, data: str) -> int:
        """Write to both terminal and file.

        Spinner output is identified by a custom OSC sentinel sequence
        injected by StatusSpinner. Everything from the sentinel onwards
        is transient spinner content and is excluded from the log file.
        Any real content (e.g., from print_above) precedes the sentinel
        and is preserved.

        As a secondary filter, transient terminal output using \\r without
        \\n (e.g., subprocess progress bars) is also excluded.
        """
        if not data:
            return 0

        original_len = len(data)

        # Always write to terminal with original formatting
        with suppress(Exception):
            self._terminal.write(data)

        # Write cleaned version to file
        try:
            with self._lock:
                # Truncate at spinner sentinel before any processing.
                # The sentinel marks the boundary between real content
                # (before) and transient spinner content (after).
                from obra.display.spinner import SPINNER_SENTINEL

                sentinel_idx = data.find(SPINNER_SENTINEL)
                if sentinel_idx != -1:
                    data = data[:sentinel_idx]
                    if not data:
                        return original_len

                # Strip ANSI codes for clean log
                clean_data = self.ANSI_PATTERN.sub("", data)
                if not clean_data:
                    return original_len

                # Skip transient terminal output (e.g., subprocess progress
                # bars). These use \r for overwriting without \n.
                if "\r" in clean_data and "\n" not in clean_data:
                    return original_len

                # Strip \r from remaining output — it's a terminal control
                # character with no meaning in a plain text log file
                clean_data = clean_data.replace("\r", "")
                if not clean_data:
                    return original_len

                if self._prefix and clean_data.strip():
                    # Add prefix only to non-empty lines
                    lines = clean_data.split("\n")
                    prefixed = "\n".join(
                        f"{self._prefix}{line}" if line.strip() else line for line in lines
                    )
                    self._file.write(prefixed)
                else:
                    self._file.write(clean_data)
                self._file.flush()
        except Exception:
            pass

        return original_len

    def flush(self) -> None:
        """Flush both streams."""
        with suppress(Exception):
            self._terminal.flush()
        with suppress(Exception):
            self._file.flush()

    def fileno(self) -> int:
        """Return terminal's file descriptor for compatibility."""
        return self._terminal.fileno()

    def isatty(self) -> bool:
        """Return whether terminal is a TTY."""
        try:
            return self._terminal.isatty()
        except Exception:
            return False


# Module-level singleton
_session_logger: SessionConsoleLogger | None = None


def get_session_logger() -> SessionConsoleLogger | None:
    """Get the current session logger singleton.

    Returns:
        SessionConsoleLogger instance or None if not started
    """
    return _session_logger


def start_session_logging(session_id: str) -> SessionConsoleLogger:
    """Start session console logging (singleton).

    Args:
        session_id: Session ID for log file naming

    Returns:
        SessionConsoleLogger instance
    """
    global _session_logger
    if _session_logger is not None:
        _session_logger.stop()

    _session_logger = SessionConsoleLogger(session_id)
    _session_logger.start()
    return _session_logger


def stop_session_logging() -> None:
    """Stop session console logging."""
    global _session_logger
    if _session_logger is not None:
        _session_logger.stop()
        _session_logger = None


def rename_session_logging(new_session_id: str) -> bool:
    """Rename the current session log to use the given session ID.

    Args:
        new_session_id: The new session ID

    Returns:
        True if rename succeeded, False otherwise
    """
    if _session_logger is not None:
        return _session_logger.rename_session(new_session_id)
    return False


@contextmanager
def session_logging(session_id: str):
    """Context manager for session console logging.

    Args:
        session_id: Session ID for log file naming

    Yields:
        SessionConsoleLogger instance
    """
    logger = start_session_logging(session_id)
    try:
        yield logger
    finally:
        stop_session_logging()


__all__ = [
    "SessionConsoleLogger",
    "get_session_logger",
    "rename_session_logging",
    "session_logging",
    "start_session_logging",
    "stop_session_logging",
]
