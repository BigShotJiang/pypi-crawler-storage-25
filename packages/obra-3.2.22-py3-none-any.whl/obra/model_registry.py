"""Unified Model Registry - Single Source of Truth for LLM Configurations.

This module provides a centralized registry of LLM provider configurations,
model definitions, and validation functions. All consumers (obra package,
DObra agents, interactive mode) should import from this module.

Example:
    >>> from obra.model_registry import validate_model, get_cli_args
    >>> result = validate_model("anthropic", "sonnet")
    >>> result.valid
    True
    >>> get_cli_args("anthropic", "opus")
    ['--model', 'opus']

Schema Version:
    Major: Breaking changes to data structures
    Minor: New models/fields added
    Patch: Fixes to existing data

Migration Note:
    This module was migrated from obra_client.model_registry as part of
    CLIENT-SUNSET-001. The obra_client package has been superseded by obra.

    As of REFACTOR-SCHEMAS-P7-001 this module is a re-export facade.
    Canonical implementations live in:
    - obra.model_lookup  (MODEL_REGISTRY, classes, lookup functions)
    - obra.token_budgets (context-window / output budget calculations)
    - obra.quality_tiers (tier resolution, dimension parsing, reasoning)

    All public symbols remain importable from ``obra.model_registry`` for
    backward compatibility.
"""

# ── model_lookup: data classes, registry data, and lookup functions ──────────
from obra.model_lookup import (  # noqa: F401
    MODEL_REGISTRY,
    REASONING_LEVELS,
    REASONING_ROLE_TIER_KEYS,
    REGISTRY_VERSION,
    ModelInfo,
    ModelStatus,
    ProviderConfig,
    QualityTier,
    ValidationResult,
    get_cli_args,
    get_default_model,
    get_model_info,
    get_provider,
    get_provider_models,
    get_provider_names,
    resolve_alias,
    validate_model,
)

# ── quality_tiers: tier resolution, dimension parsing, reasoning profiles ────
from obra.quality_tiers import (  # noqa: F401
    MODEL_DIMENSION_PATTERNS,
    QUALITY_TIER_DEFAULTS,
    QUALITY_TIER_RULES,
    ModelDimensions,
    ReasoningProfile,
    get_quality_config_for_model,
    get_reasoning_profile,
    parse_model_dimensions,
    resolve_quality_tier,
    scale_max_refinement_iterations,
    supports_anthropic_cli_effort,
    supports_extended_thinking,
)

# ── token_budgets: context-window and output budget calculations ─────────────
from obra.token_budgets import (  # noqa: F401
    DEFAULT_CONTEXT_WINDOW,
    DEFAULT_OUTPUT_BUDGET,
    MAX_RESERVED_OUTPUT,
    MIN_RESERVED_OUTPUT,
    calculate_max_prompt_tokens,
    get_default_output_budget,
    get_max_prompt_tokens_for_model,
    get_model_context_window,
)
