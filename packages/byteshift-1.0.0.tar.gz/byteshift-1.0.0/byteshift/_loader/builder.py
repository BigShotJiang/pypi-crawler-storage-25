import os as _os

_MARKER = b'\xDE\xAD\xC0\xDE\xFA\xCE'

_B91_TABLE = (
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    '0123456789!#$%&()*+,./:;<=>?@[]^_`{|}~"'
)

def _hex_key(k: bytes) -> str:
    return ''.join(f'\\x{b:02x}' for b in k)


def build_payload(user_bytecode: bytes, keys: tuple) -> str:
    import zlib, lzma
    from .._crypto.xor import xor_single
    from .._crypto.integrity import build_mac
    from .._vendor.base91 import encode as b91enc

    k1, k2, k3, k4 = keys
    c1 = zlib.compress(user_bytecode, level=9)
    c2 = lzma.compress(c1, preset=9)
    x1 = xor_single(c2, k1)
    x2 = xor_single(x1, k2)
    x3 = xor_single(x2, k3)
    x4 = xor_single(x3, k4)
    mac = build_mac(k1, x4)
    payload = mac + x4
    pad_n = 12288 + (_os.urandom(1)[0] << 4) % 4096
    pad = _os.urandom(pad_n)
    combined = pad + _MARKER + payload
    return b91enc(combined)


def build_loader(encoded_b91: str, keys: tuple) -> str:
    k1, k2, k3, k4 = keys
    k1r = _hex_key(k1)
    k2r = _hex_key(k2)
    k3r = _hex_key(k3)
    k4r = _hex_key(k4)

    S = '\U0001d516'
    T = '\U0001d517'
    v = '\U0001d573'
    B = '\U0001d539'
    n = '\U0001d56b'
    o = '\U0001d56c'
    p = '\U0001d52d'
    c = '\U0001d4b8'

    tbl = _B91_TABLE

    b91_lambda = (
        f"(lambda {S}:"
        f"(lambda {T},{v},{B},{n},{o}:"
        f"([[(lambda {p}:{v}.__setitem__(0,{p}) if {v}[0]<0 else"
        f"[{v}.__setitem__(0,{v}[0]+{p}*91),"
        f"{B}.__setitem__(0,{B}[0]|({v}[0]<<{n}[0])),"
        f"{n}.__setitem__(0,{n}[0]+(13 if({v}[0]&8191)>88 else 14)),"
        f"{v}.__setitem__(0,-1),"
        f"[{o}.append({B}[0]&255) or {B}.__setitem__(0,{B}[0]>>8) or {n}.__setitem__(0,{n}[0]-8)"
        f" for _ in range({n}[0]//8)]])"
        f"({T}.get({c},-1))"
        f" for {c} in {S} if {T}.get({c},-1)>=0]],"
        f"{v}[0]>-1 and {o}.append(({B}[0]|{v}[0]<<{n}[0])&255),"
        f"bytes({o}))[-1])"
        f"({{ch:i for i,ch in enumerate('{tbl}')}},"
        f"[-1],[0],[0],bytearray()))"
    )

    _sy = "__import__('sys')"
    _os_ = "__import__('os')"
    _it = "__import__('itertools')"
    _zl = "__import__('zlib')"
    _lz = "__import__('lzma')"
    _mr = "__import__('marshal')"
    _hm = "__import__('hmac')"
    _gc = "__import__('gc')"

    K1 = '\U0001d50e'
    K2 = '\U0001d50f'
    K3 = '\U0001d510'
    K4 = '\U0001d511'
    D  = '\U0001d521'
    F  = '\U0001d51f'
    LQ = 'ꓠ'
    LK = 'ꓫ'

    line = (
        f"(not {_sy}.gettrace()"
        f" and not any({_sy}.modules.get({LQ}) for {LQ} in"
        f" ('pdb','bdb','pydevd','debugpy','_pydev_bundle'))"
        f" or ({_gc}.collect(),{_os_}._exit(0)))"
        f" and (lambda {K1},{K2},{K3},{K4},{D},{F}:"
        f"[exec({_mr}.loads({LK}),globals())"
        f" for _r in [{F}({D})]"
        f" for _i in [_r.index(b'\\xde\\xad\\xc0\\xde\\xfa\\xce')]"
        f" for _p in [_r[_i+6:]]"
        f" for _h,_d in [(_p[:32],_p[32:])]"
        f" for _m in [{_hm}.digest({K1},_d,'sha256')]"
        f" if _m==_h or ({_gc}.collect(),{_os_}._exit(0))"
        f" for _X4 in [bytes(\u03b1^\u03b2 for \u03b1,\u03b2 in zip(_d,{_it}.cycle({K4})))]"
        f" for _X3 in [bytes(\u03b1^\u03b2 for \u03b1,\u03b2 in zip(_X4,{_it}.cycle({K3})))]"
        f" for _X2 in [bytes(\u03b1^\u03b2 for \u03b1,\u03b2 in zip(_X3,{_it}.cycle({K2})))]"
        f" for _X1 in [bytes(\u03b1^\u03b2 for \u03b1,\u03b2 in zip(_X2,{_it}.cycle({K1})))]"
        f" for _L in [{_lz}.decompress(_X1)]"
        f" for {LK} in [{_zl}.decompress(_L)]]"
        f")(b'{k1r}',b'{k2r}',b'{k3r}',b'{k4r}','{encoded_b91}',{b91_lambda})"
    )
    return line
