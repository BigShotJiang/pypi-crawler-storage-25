_TABLE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!#$%&()*+,./:;<=>?@[]^_`{|}~"'
_DECODE = {c: i for i, c in enumerate(_TABLE)}

def encode(data: bytes) -> str:
    b = 0; n = 0; o = []
    for byte in data:
        b |= byte << n; n += 8
        if n > 13:
            v = b & 8191
            if v > 88:
                b >>= 13; n -= 13
            else:
                v = b & 16383; b >>= 14; n -= 14
            o.append(_TABLE[v % 91]); o.append(_TABLE[v // 91])
    if n:
        o.append(_TABLE[b % 91])
        if n > 7 or b > 90:
            o.append(_TABLE[b // 91])
    return ''.join(o)

def decode(data: str) -> bytes:
    v = -1; b = 0; n = 0; o = bytearray()
    for c in data:
        p = _DECODE.get(c, -1)
        if p == -1: continue
        if v < 0:
            v = p
        else:
            v += p * 91; b |= v << n; n += 13 if (v & 8191) > 88 else 14
            v = -1
            while n > 7:
                o.append(b & 255); b >>= 8; n -= 8
    if v > -1:
        o.append((b | v << n) & 255)
    return bytes(o)
