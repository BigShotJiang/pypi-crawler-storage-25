from .encoder import Encoder, encode, _DEFAULT_SEED
from . import _vendor

__author__ = 'addy'
__version__ = '1.0.0'
__all__ = ['Encoder', 'encode', '_DEFAULT_SEED', '𝔈', '𝔢', '𝔖𝔢𝔢𝔡']

𝔈 = Encoder
𝔢 = encode
𝔖𝔢𝔢𝔡 = _DEFAULT_SEED
