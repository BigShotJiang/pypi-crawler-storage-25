import sys as 𝔖
import os as 𝔒
import argparse
from pathlib import Path as 𝔓
from .encoder import Encoder, _DEFAULT_SEED, __author__, __version__

_BANNER = f"""
  ██████╗ ██╗   ██╗████████╗███████╗███████╗██╗  ██╗██╗███████╗████████╗
  ██╔══██╗╚██╗ ██╔╝╚══██╔══╝██╔════╝██╔════╝██║  ██║██║██╔════╝╚══██╔══╝
  ██████╔╝ ╚████╔╝    ██║   █████╗  ███████╗███████║██║█████╗     ██║
  ██╔══██╗  ╚██╔╝     ██║   ██╔══╝  ╚════██║██╔══██║██║██╔══╝     ██║
  ██████╔╝   ██║      ██║   ███████╗███████║██║  ██║██║██║        ██║
  ╚═════╝    ╚═╝      ╚═╝   ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝╚═╝        ╚═╝
  v{__version__} — by {__author__} | Extreme Python Obfuscator
"""

def _parse_seed(s: str) -> bytes:
    return s.encode('utf-8')


def main():
    print(_BANNER)
    𝔭 = argparse.ArgumentParser(
        prog='byteshift',
        description='ByteShift — Extreme Python Obfuscator: AST + 4-Layer XOR + HMAC + Anti-Debug',
        formatter_class=argparse.RawTextHelpFormatter,
    )
    𝔭.add_argument('--version', action='version', version=f'byteshift {__version__}')
    𝔰𝔲𝔟 = 𝔭.add_subparsers(dest='cmd', required=True)

    𝔢𝔫𝔠 = 𝔰𝔲𝔟.add_parser('encode', help='Encode a .py file')
    𝔢𝔫𝔠.add_argument('input', help='Input Python file')
    𝔢𝔫𝔠.add_argument('-o', '--output', default=None, help='Output file (default: <input>_byteshift.py)')
    𝔢𝔫𝔠.add_argument('-s', '--seed', default=None, help='Custom seed string')
    𝔢𝔫𝔠.add_argument('--seed-file', default=None, help='File containing seed bytes')
    𝔢𝔫𝔠.add_argument('--no-ast', action='store_true', help='Disable AST obfuscation layer')
    𝔢𝔫𝔠.add_argument('--stdout', action='store_true', help='Print to stdout')

    𝔢𝔫𝔠𝔰 = 𝔰𝔲𝔟.add_parser('encode-str', help='Encode a Python string directly')
    𝔢𝔫𝔠𝔰.add_argument('code', help='Python source code string')
    𝔢𝔫𝔠𝔰.add_argument('-o', '--output', default=None, help='Output file')
    𝔢𝔫𝔠𝔰.add_argument('-s', '--seed', default=None, help='Custom seed string')
    𝔢𝔫𝔠𝔰.add_argument('--no-ast', action='store_true', help='Disable AST obfuscation layer')
    𝔢𝔫𝔠𝔰.add_argument('--stdout', action='store_true', help='Print to stdout')

    𝔞 = 𝔭.parse_args()

    if hasattr(𝔞, 'seed_file') and 𝔞.seed_file:
        𝔰𝔢𝔢𝔡 = 𝔓(𝔞.seed_file).read_bytes()
    elif 𝔞.seed:
        𝔰𝔢𝔢𝔡 = _parse_seed(𝔞.seed)
    else:
        𝔰𝔢𝔢𝔡 = _DEFAULT_SEED

    𝔞𝔰𝔱 = not getattr(𝔞, 'no_ast', False)
    𝔢 = Encoder(seed=𝔰𝔢𝔢𝔡, ast_obfuscate=𝔞𝔰𝔱)

    if 𝔞.cmd == 'encode':
        𝔦𝔫𝔭 = 𝔓(𝔞.input)
        if not 𝔦𝔫𝔭.exists():
            print(f'[byteshift] Error: File not found: {𝔦𝔫𝔭}', file=𝔖.stderr)
            𝔖.exit(1)
        𝔯𝔢𝔰 = 𝔢.encode_file(𝔦𝔫𝔭)
        if 𝔞.stdout:
            print(𝔯𝔢𝔰)
        else:
            𝔬𝔲𝔱 = 𝔞.output or str(𝔦𝔫𝔭.parent / (𝔦𝔫𝔭.stem + '_byteshift.py'))
            𝔓(𝔬𝔲𝔱).write_text(𝔯𝔢𝔰, encoding='utf-8')
            print(f'[byteshift] ✓ Encoded → {𝔬𝔲𝔱}')

    elif 𝔞.cmd == 'encode-str':
        𝔯𝔢𝔰 = 𝔢.encode_string(𝔞.code)
        if 𝔞.stdout or not 𝔞.output:
            print(𝔯𝔢𝔰)
        else:
            𝔓(𝔞.output).write_text(𝔯𝔢𝔰, encoding='utf-8')
            print(f'[byteshift] ✓ Encoded → {𝔞.output}')
