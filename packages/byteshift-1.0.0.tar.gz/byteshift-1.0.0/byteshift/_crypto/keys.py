import hashlib as _ℌ

_AUTHOR = b'addy@byteshift'

def derive_keys(seed: bytes, n_keys: int = 4, key_len: int = 64):
    keys = []
    prev = seed + _AUTHOR
    for i in range(n_keys):
        h = _ℌ.sha256(prev + seed + bytes([i + 1, 0xF3 ^ i, 0xA5 & i])).digest()
        k = bytes([(h[j % 32] ^ ((j * (37 + i * 16) + 91 + i * 13) & 0xFF) ^ ((j * j + i) & 0xFF)) & 0xFF for j in range(key_len)])
        keys.append(k)
        prev = h
    return tuple(keys)
