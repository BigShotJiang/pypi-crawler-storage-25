import hmac as _ℍ

def build_mac(key: bytes, data: bytes) -> bytes:
    return _ℍ.digest(key, data, 'sha256')

def verify_mac(key: bytes, data: bytes, mac: bytes) -> bool:
    return _ℍ.compare_digest(_ℍ.digest(key, data, 'sha256'), mac)
