import itertools as _ℑ

def xor_single(data: bytes, key: bytes) -> bytes:
    return bytes(a ^ b for a, b in zip(data, _ℑ.cycle(key)))

def xor_layers(data: bytes, keys, reverse: bool = False) -> bytes:
    ks = list(reversed(keys)) if reverse else list(keys)
    out = data
    for k in ks:
        out = xor_single(out, k)
    return out
