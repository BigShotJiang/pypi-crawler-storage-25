import ast
from .renamer import ASTRenamer
from .junk_injector import JunkInjector
from .str_encryptor import StrEncryptor

def apply_all(tree, seed: int = 0x4164_6479):
    tree = JunkInjector(seed).visit(tree)
    tree = StrEncryptor(seed).visit(tree)
    renamer = ASTRenamer(seed)
    renamer.build_mapping(tree)
    tree = renamer.visit(tree)
    ast.fix_missing_locations(tree)
    return tree
