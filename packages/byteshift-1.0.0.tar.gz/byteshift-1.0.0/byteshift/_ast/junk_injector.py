import ast
import random

_JUNK_EXPRS = [
    '(lambda: None)()',
    '(0xDEAD ^ 0xBEEF) & 0xFFFF',
    'abs(-0x41646479) >> 8',
    '(lambda ア,イ: ア)(0, 1)',
    'list(range(0))',
    '{"ア": 0}.get("イ", 0)',
    'bool(0 and False)',
    '(0x00,)',
    'None or False or 0',
    '1 if False else 0',
    '[] or {} or ()',
    'divmod(0xAD, 0xAD)[1]',
]

def _junk_stmt(rng: random.Random) -> ast.stmt:
    expr_src = rng.choice(_JUNK_EXPRS)
    try:
        expr_node = ast.parse(expr_src, mode='eval').body
        return ast.Expr(value=expr_node)
    except Exception:
        return ast.Expr(value=ast.Constant(value=0))

class JunkInjector(ast.NodeTransformer):
    def __init__(self, seed: int = 0, density: int = 2):
        self._rng = random.Random(seed ^ 0xADD1_CAFE)
        self._density = density

    def _inject(self, stmts: list) -> list:
        out = []
        for stmt in stmts:
            out.append(stmt)
            if self._rng.randint(0, self._density) == 0:
                out.append(_junk_stmt(self._rng))
        return out

    def visit_Module(self, node):
        self.generic_visit(node)
        node.body = self._inject(node.body)
        return node

    def visit_FunctionDef(self, node):
        self.generic_visit(node)
        node.body = self._inject(node.body)
        return node

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_ClassDef(self, node):
        self.generic_visit(node)
        node.body = self._inject(node.body)
        return node
