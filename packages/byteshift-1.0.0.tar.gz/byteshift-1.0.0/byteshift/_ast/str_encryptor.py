import ast
import random
import itertools

def _xor_bytes(data: bytes, key: bytes) -> bytes:
    return bytes(a ^ b for a, b in zip(data, itertools.cycle(key)))

def _make_decode_node(enc_bytes: bytes, key_bytes: bytes) -> ast.expr:
    enc_repr = repr(enc_bytes)
    key_repr = repr(key_bytes)
    # Use _x, _y as loop vars: underscore-prefix => ASTRenamer._should_skip() skips them
    src = (
        f"__import__('builtins').bytes("
        f"_x^_y for _x,_y in zip({enc_repr},"
        f"__import__('itertools').cycle({key_repr})))"
        f".decode('utf-8','replace')"
    )
    try:
        return ast.parse(src, mode='eval').body
    except Exception:
        return ast.Constant(value='')

class StrEncryptor(ast.NodeTransformer):
    def __init__(self, seed: int = 0, min_len: int = 4):
        self._rng = random.Random(seed ^ 0xBEEF_F00D)
        self._min_len = min_len
        self._in_joinedstr = 0

    def _make_key(self) -> bytes:
        return bytes([self._rng.randint(1, 255) for _ in range(16)])

    def visit_JoinedStr(self, node):
        # f-strings: only recurse into FormattedValue children.
        # Never replace Constant literal fragments — that breaks JoinedStr AST structure.
        self._in_joinedstr += 1
        for child in node.values:
            if isinstance(child, ast.FormattedValue):
                child.value = self.visit(child.value)
        self._in_joinedstr -= 1
        return node

    def visit_Constant(self, node):
        if self._in_joinedstr:
            return node
        if (isinstance(node.value, str) and len(node.value) >= self._min_len
                and '\n' not in node.value and '\r' not in node.value):
            try:
                raw = node.value.encode('utf-8')
                key = self._make_key()
                enc = _xor_bytes(raw, key)
                return _make_decode_node(enc, key)
            except Exception:
                pass
        return node
