import ast
import itertools
import builtins

_KATAKANA = 'アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワン'
_HIRAGANA = 'あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわをん'

_POOL = _KATAKANA + _HIRAGANA

_BUILTINS = set(dir(builtins))
_SKIP_NAMES = {
    'self', 'cls', 'args', 'kwargs', 'None', 'True', 'False',
    'print', 'range', 'len', 'type', 'int', 'str', 'bytes',
    'list', 'dict', 'set', 'tuple', 'bool', 'float', 'object',
    'super', 'property', 'classmethod', 'staticmethod',
    'Exception', 'BaseException', 'ValueError', 'TypeError',
    'KeyError', 'IndexError', 'AttributeError', 'ImportError',
    'StopIteration', 'RuntimeError', 'NotImplementedError',
    'encode', 'decode', 'main', 'open', 'input', 'format',
    'zip', 'map', 'filter', 'enumerate', 'sorted', 'reversed',
    'max', 'min', 'sum', 'any', 'all', 'hasattr', 'getattr',
    'setattr', 'delattr', 'isinstance', 'issubclass', 'id',
    'repr', 'hash', 'iter', 'next', 'vars', 'dir',
}

def _should_skip(name: str) -> bool:
    if name in _BUILTINS: return True
    if name in _SKIP_NAMES: return True
    if name.startswith('__') and name.endswith('__'): return True
    if name.startswith('_'): return True
    return False

def _name_stream(seed: int):
    import random
    rng = random.Random(seed)
    pool = list(_POOL)
    rng.shuffle(pool)
    used = set()
    for length in range(1, 6):
        for combo in itertools.product(pool, repeat=length):
            name = ''.join(combo)
            if name not in used:
                used.add(name)
                yield name


class _ScopedCollector(ast.NodeVisitor):
    def __init__(self):
        self.module_names: set[str] = set()
        self.class_methods: dict[str, set[str]] = {}
        self._in_class: list[str] = []

    def visit_FunctionDef(self, node):
        if self._in_class:
            cls = self._in_class[-1]
            self.class_methods.setdefault(cls, set())
            if not _should_skip(node.name):
                self.class_methods[cls].add(node.name)
        else:
            if not _should_skip(node.name):
                self.module_names.add(node.name)
        self._visit_func_args(node)
        self.generic_visit(node)

    visit_AsyncFunctionDef = visit_FunctionDef

    def _visit_func_args(self, node):
        for arg in node.args.args + node.args.posonlyargs + node.args.kwonlyargs:
            if not _should_skip(arg.arg) and arg.arg not in ('self', 'cls'):
                self.module_names.add(arg.arg)
        if node.args.vararg and not _should_skip(node.args.vararg.arg):
            self.module_names.add(node.args.vararg.arg)
        if node.args.kwarg and not _should_skip(node.args.kwarg.arg):
            self.module_names.add(node.args.kwarg.arg)

    def visit_ClassDef(self, node):
        if not _should_skip(node.name):
            self.module_names.add(node.name)
        self._in_class.append(node.name)
        self.generic_visit(node)
        self._in_class.pop()

    def visit_Name(self, node):
        if isinstance(node.ctx, (ast.Store, ast.Del)) and not _should_skip(node.id):
            self.module_names.add(node.id)
        self.generic_visit(node)


class ASTRenamer(ast.NodeTransformer):
    def __init__(self, seed: int = 0):
        self._seed = seed
        self._mapping: dict[str, str] = {}
        self._method_maps: dict[str, dict[str, str]] = {}
        self._in_class: list[str] = []
        self._mapping_built = False

    def build_mapping(self, tree):
        collector = _ScopedCollector()
        collector.visit(tree)
        stream = _name_stream(self._seed)
        for name in sorted(collector.module_names):
            self._mapping[name] = next(stream)
        for cls_name, methods in collector.class_methods.items():
            self._method_maps[cls_name] = {}
            for m in sorted(methods):
                self._method_maps[cls_name][m] = next(stream)
        self._mapping_built = True

    def _rename(self, name: str) -> str:
        return self._mapping.get(name, name)

    def _rename_method(self, name: str) -> str:
        if self._in_class:
            cls = self._in_class[-1]
            mmap = self._method_maps.get(cls, {})
            if name in mmap:
                return mmap[name]
        return name

    def visit_FunctionDef(self, node):
        if self._in_class:
            node.name = self._rename_method(node.name)
        else:
            node.name = self._rename(node.name)
        for arg in node.args.args + node.args.posonlyargs + node.args.kwonlyargs:
            if arg.arg not in ('self', 'cls'):
                arg.arg = self._rename(arg.arg)
        if node.args.vararg:
            node.args.vararg.arg = self._rename(node.args.vararg.arg)
        if node.args.kwarg:
            node.args.kwarg.arg = self._rename(node.args.kwarg.arg)
        self.generic_visit(node)
        return node

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_ClassDef(self, node):
        self._in_class.append(node.name)
        node.name = self._rename(node.name)
        self.generic_visit(node)
        self._in_class.pop()
        return node

    def visit_Name(self, node):
        node.id = self._rename(node.id)
        return node

    def visit_Attribute(self, node):
        if self._in_class:
            cls = self._in_class[-1]
            mmap = self._method_maps.get(cls, {})
            if node.attr in mmap:
                node.attr = mmap[node.attr]
        else:
            for cls, mmap in self._method_maps.items():
                if node.attr in mmap:
                    node.attr = mmap[node.attr]
                    break
        self.generic_visit(node)
        return node

    def visit_Global(self, node):
        node.names = [self._rename(n) for n in node.names]
        return node

    def visit_Nonlocal(self, node):
        node.names = [self._rename(n) for n in node.names]
        return node

    def visit_ImportFrom(self, node):
        for alias in node.names:
            if alias.asname and not _should_skip(alias.asname):
                alias.asname = self._mapping.get(alias.asname, alias.asname)
        return node

    def visit_Import(self, node):
        for alias in node.names:
            if alias.asname and not _should_skip(alias.asname):
                alias.asname = self._mapping.get(alias.asname, alias.asname)
        return node
