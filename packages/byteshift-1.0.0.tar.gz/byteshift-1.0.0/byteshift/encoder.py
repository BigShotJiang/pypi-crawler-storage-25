import ast as _ast
import marshal as _𝔪
import os as _𝔒
from pathlib import Path as _𝔓

from ._crypto import derive_keys
from ._loader.builder import build_payload, build_loader
from ._ast import apply_all as _ast_transform

__author__ = 'addy'
__version__ = '1.0.0'

_DEFAULT_SEED = b'addy@byteshift-v1'


def _compile_source(source_bytes: bytes, ast_seed: int) -> bytes:
    try:
        source = source_bytes.decode('utf-8')
        tree = _ast.parse(source, filename='<byteshift>')
        tree = _ast_transform(tree, seed=ast_seed)
        code = compile(tree, '<byteshift>', 'exec')
    except SyntaxError:
        code = compile(source_bytes, '<byteshift>', 'exec')
    return _𝔪.dumps(code)


class Encoder:
    def __init__(self, seed: bytes = _DEFAULT_SEED, ast_obfuscate: bool = True):
        self._𝔰𝔢𝔢𝔡 = seed
        self._𝔞𝔰𝔱 = ast_obfuscate
        self._𝔨𝔢𝔶𝔰 = derive_keys(seed)
        self._𝔞𝔰𝔱_𝔰𝔢𝔢𝔡 = int.from_bytes(seed[:4], 'little')

    def encode_file(self, path) -> str:
        src = _𝔓(path).read_bytes()
        return self._𝔢𝔫𝔠𝔬𝔡𝔢(src)

    def encode_string(self, code: str) -> str:
        return self._𝔢𝔫𝔠𝔬𝔡𝔢(code.encode('utf-8'))

    def encode_bytes(self, code: bytes) -> str:
        return self._𝔢𝔫𝔠𝔬𝔡𝔢(code)

    def _𝔢𝔫𝔠𝔬𝔡𝔢(self, src: bytes) -> str:
        if self._𝔞𝔰𝔱:
            bytecode = _compile_source(src, self._𝔞𝔰𝔱_𝔰𝔢𝔢𝔡)
        else:
            code = compile(src, '<byteshift>', 'exec')
            bytecode = _𝔪.dumps(code)
        payload_b85 = build_payload(bytecode, self._𝔨𝔢𝔶𝔰)
        return build_loader(payload_b85, self._𝔨𝔢𝔶𝔰)

    def encode_file_to_file(self, src_path, dst_path=None) -> str:
        result = self.encode_file(src_path)
        if dst_path is None:
            𝔭 = _𝔓(src_path)
            dst_path = 𝔭.parent / (𝔭.stem + '_byteshift.py')
        _𝔓(dst_path).write_text(result, encoding='utf-8')
        return str(dst_path)


def encode(source, seed: bytes = _DEFAULT_SEED, output_path=None,
           ast_obfuscate: bool = True) -> str:
    𝔢 = Encoder(seed=seed, ast_obfuscate=ast_obfuscate)
    if isinstance(source, (str, _𝔓)) and _𝔓(str(source)).exists():
        if output_path:
            𝔢.encode_file_to_file(source, output_path)
            return str(output_path)
        return 𝔢.encode_file(source)
    if isinstance(source, bytes):
        return 𝔢.encode_bytes(source)
    return 𝔢.encode_string(str(source))
