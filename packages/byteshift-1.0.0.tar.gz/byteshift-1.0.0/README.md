# byteshift

**byteshift** is a Python source-code obfuscation library by **addy**.

It transforms Python scripts into heavily obfuscated, single-line loaders that are resistant to casual reverse engineering while remaining fully runnable on CPython 3.9+, Pydroid 3, and Termux.

---

## Features

| Feature | Details |
|---|---|
| **AST renaming** | Identifiers renamed to Katakana / Hiragana Unicode sequences |
| **String encryption** | String literals encrypted with per-file random keys and inlined as XOR decoders |
| **Junk injection** | Dead-code expressions spliced between real statements |
| **4-layer XOR** | Bytecode XOR'd sequentially with four 64-byte derived keys |
| **HMAC-SHA256** | Payload integrity verified; process exits on tamper |
| **Base91 encoding** | Compact printable encoding; decoder inlined as a pure-lambda inside the loader |
| **Single-line output** | Entire loader is one Python expression — no newlines |
| **Anti-debug gate** | Checks `sys.gettrace()` and common debugger modules; exits if detected |
| **Works on mobile** | Tested on Pydroid 3 and Termux (pure-stdlib, no native extensions) |

---

## Installation

```bash
git clone https://github.com/pooraddyy/byteshift.git
cd byteshift
pip install -e .
```

---

## Quick start

### From the command line

```python
from byteshift import encode

# Encode a file → returns the loader string
loader = encode("my_script.py")

# Write to a file
with open("my_script_enc.py", "w", encoding="utf-8") as f:
    f.write(loader)
```

Then just run the output:

```bash
python my_script_enc.py
```

### Encode-to-file helper

```python
from byteshift import Encoder

enc = Encoder()
out_path = enc.encode_file_to_file("my_script.py")
print("Written to:", out_path)
```

### Disable AST obfuscation (faster, less thorough)

```python
loader = encode("my_script.py", ast_obfuscate=False)
```

### Encode a string directly

```python
from byteshift import encode

src = """
def hello(name):
    print(f"Hello, {name}!")

hello("world")
"""

loader = encode(src)
```

---

## How it works

1. **Parse** — the source is parsed into an AST.
2. **Junk injection** — harmless dead-code expressions are inserted between statements.
3. **String encryption** — string literals are replaced with inline XOR-decode calls.
4. **AST renaming** — all user-defined names are mapped to Katakana/Hiragana strings using a seeded shuffle.
5. **Compile + marshal** — the transformed AST is compiled and serialised with `marshal`.
6. **4-layer XOR + HMAC** — the bytecode is encrypted with four 64-byte keys derived via HKDF-SHA256 from a fixed seed (`addy@byteshift-v1`), and a HMAC-SHA256 integrity tag is prepended.
7. **LZMA + zlib compression** — the encrypted blob is double-compressed.
8. **Base91 encoding** — the compressed blob is base91-encoded into printable ASCII.
9. **Loader generation** — a single-line Python expression is produced that:
   - checks for active debuggers and exits if found
   - decodes the base91 payload using an inlined pure-lambda decoder
   - finds the padding marker, verifies the HMAC, decrypts, decompresses, and `marshal.loads` the bytecode
   - calls `exec()` with the current module globals so all names resolve correctly

---

## Limitations

- Output is CPython bytecode — it is version-specific. Encode and run on the **same Python version**.
- The anti-debug check is lightweight (not foolproof against a determined attacker).
- Bytecode can still be extracted from a running process; byteshift is a deterrent, not DRM.

---

## Project structure

```
byteshift/
├── byteshift/
│   ├── __init__.py          # Public API: encode(), Encoder
│   ├── encoder.py           # Orchestrates the full pipeline
│   ├── _ast/
│   │   ├── __init__.py      # apply_all(): junk → encrypt → rename
│   │   ├── junk_injector.py # Dead-code statement injection
│   │   ├── renamer.py       # Katakana/Hiragana AST renamer
│   │   └── str_encryptor.py # String-literal XOR encryption
│   ├── _crypto/
│   │   ├── __init__.py      # derive_keys() via HKDF-SHA256
│   │   ├── xor.py           # Cycling XOR helper
│   │   └── integrity.py     # HMAC-SHA256 build/verify
│   ├── _loader/
│   │   └── builder.py       # build_payload() + build_loader()
│   └── _vendor/
│       └── base91.py        # Pure-Python base91 codec
├── demo.py                  # Example source file
└── pyproject.toml
```

---

## Author

**addy** — [github.com/pooraddyy](https://github.com/pooraddyy)
