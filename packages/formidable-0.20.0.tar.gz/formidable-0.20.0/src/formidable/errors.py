"""
Formidable | Copyright (c) 2025 Juan-Pablo Scaletti
"""

INVALID = "invalid"
REQUIRED = "required"
ONE_OF = "one_of"

GT = "gt"
GTE = "gte"
LT = "lt"
LTE = "lte"
MULTIPLE_OF = "multiple_of"

MIN_ITEMS = "min_items"
MAX_ITEMS = "max_items"

MIN_LENGTH = "min_length"
MAX_LENGTH = "max_length"
PATTERN = "pattern"

PAST_DATE = "past_date"
FUTURE_DATE = "future_date"
AFTER_DATE = "after_date"
BEFORE_DATE = "before_date"

AFTER_TIME = "after_time"
BEFORE_TIME = "before_time"
PAST_TIME = "past_time"
FUTURE_TIME = "future_time"

INVALID_URL = "invalid_url"
INVALID_EMAIL = "invalid_email"
INVALID_SLUG = "invalid_slug"

INVALID_JSON = "invalid_json"
