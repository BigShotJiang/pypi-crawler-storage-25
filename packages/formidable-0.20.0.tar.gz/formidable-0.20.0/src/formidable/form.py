"""
Formidable | Copyright (c) 2025 Juan-Pablo Scaletti
"""

import logging
import typing as t
from contextlib import nullcontext

from markupsafe import Markup

from .common import get_pk
from .fields.base import Field
from .fields.text import TextField
from .parser import parse
from .wrappers import ObjectManager


RESERVED_NAMES = (
    "get_errors",
    "hidden_tags",
    "save",
    "validate",
    "after_validate",
)

logger = logging.getLogger("formidable")


class DefaultMeta:
    # ORM class to use for creating new objects.
    orm_cls: t.Any = None

    # The primary key field of the objects in the form.
    pk: str = "id"

    # Custom messages for validation errors that expand/update the default ones to
    # customize or translate them. This argument should be a dictionary where keys
    # are error codes and values are human error messages.
    messages: dict[str, str]


class Form():
    """
    Base class for creating forms.

    Args:
        reqdata:
            The request data to parse and set the form fields. Defaults to `None`.
        object:
            An object to use as the source of the initial data for the form.
            Will be updated on `save()`. Defaults to `None`.
        name_format:
            A format string for the field names. Defaults to "{name}".
        messages:
            Custom messages for validation errors. Defaults to `None`, which uses the default messages.
            The messages are inherited to the forms of `NestedForms` and `FormField` fields, however,
            if those forms have their own `messages` defined, those will take precedence over the
            parent messages.

    """

    # The class to use for wrapping objects in the form.
    _ObjectManager: type[ObjectManager] = ObjectManager

    Meta: t.Any
    _messages: dict[str, str]
    _name_format: str = "{name}"
    _fields: dict[str, Field]
    _object: ObjectManager

    _valid: bool | None = None
    _deleted: bool = False

    # Whether the form allows deletion of objects.
    # If set to True, the form will delete the object when the "_destroy"
    # field is present.
    _allow_delete: bool = False

    # Populated by __init_subclass__
    _field_names: list[str]
    _custom_filters: set[str]
    _custom_validators: set[str]
    _ProcessedMeta: t.Any

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)

        # Discover field names once at class creation time
        field_names = []
        for name in dir(cls):
            if name.startswith("_"):
                continue
            if name in ("is_valid", "is_invalid"):
                if name in cls.__dict__ and isinstance(
                    cls.__dict__[name], Field
                ):
                    raise ValueError(
                        f"Form cannot have a field named '{name}'"
                    )
                continue

            obj = cls.__dict__.get(name)
            if obj is None:
                for base in cls.__mro__[1:]:
                    if name in base.__dict__:
                        obj = base.__dict__[name]
                        break
            if isinstance(obj, Field):
                if name in RESERVED_NAMES:
                    raise ValueError(
                        f"Form cannot have a field named '{name}'"
                    )
                field_names.append(name)

        cls._field_names = field_names
        cls._custom_filters = {
            n for n in field_names if callable(getattr(cls, f"filter_{n}", None))
        }
        cls._custom_validators = {
            n for n in field_names
            if callable(getattr(cls, f"validate_{n}", None))
        }

        # Process Meta once per class
        base_meta = cls.__dict__.get("Meta", DefaultMeta)
        processed = type("Meta", (), {
            k: v for k, v in vars(base_meta).items()
            if not k.startswith("__")
        })
        orm_cls = getattr(processed, "orm_cls", None)
        if orm_cls is not None and not isinstance(orm_cls, type):
            raise ValueError("Meta.orm_cls must be a class, not an instance.")
        processed.orm_cls = orm_cls
        messages = getattr(processed, "messages", {})
        if not isinstance(messages, dict):
            raise ValueError("Meta.messages must be a dictionary.")
        processed.messages = messages
        pk = getattr(processed, "pk", "id")
        if not isinstance(pk, str):
            raise ValueError("Meta.pk must be a string.")
        processed.pk = pk
        cls._ProcessedMeta = processed

    def __init__(
        self,
        reqdata: t.Any = None,
        object: t.Any = None,
        *,
        name_format: str = "{name}",
        messages: dict[str, str] | None = None,
    ):
        self._fields = {}
        self.Meta = self._ProcessedMeta

        merged_messages = {**self.Meta.messages, **(messages or {})}
        self._messages = merged_messages
        self._name_format = name_format

        for name in self._field_names:
            field = getattr(type(self), name).__copy__()
            field.parent = self
            field.field_name = name

            if name in self._custom_filters:
                field._custom_filter = getattr(self, f"filter_{name}")
            if name in self._custom_validators:
                field._custom_validator = getattr(self, f"validate_{name}")

            # Inline set_messages + set_name_format to avoid extra iterations
            field.set_messages(merged_messages)
            field.set_name_format(name_format)

            self._fields[name] = field
            setattr(self, name, field)

        if reqdata is not None or object is not None:
            self._set(reqdata, object)
        else:
            self._object = self._ObjectManager(orm_cls=self.Meta.orm_cls)

    def __repr__(self) -> str:
        attrs = []
        for name, field in self._fields.items():
            attrs.append(f"{name}={field.value!r}")
        return f"{self.__class__.__name__}({', '.join(attrs)})"

    def __iter__(self):
        return iter(self._fields.values())

    def __contains__(self, name: str) -> bool:
        return name in self._fields

    @property
    def is_valid(self) -> bool:
        """
        Returns whether the form is valid.

        This is a property with side effects: it triggers validation of all fields
        and the form itself.

        It wasn't designed as a method to prevent the common mistake of forgetting
        to call it, which would lead to incorrect assumptions about the form's validity.

        The result is cached, so to re-validate the form, you need to call `form.validate()`.
        """
        if self._valid is None:
            return self.validate()
        return self._valid

    @property
    def is_invalid(self) -> bool:
        """
        Returns whether the form is invalid.
        """
        return not self.is_valid

    def get_errors(self) -> dict[str, str]:
        """
        Returns a dictionary of field names and their error messages.
        """
        errors = {}
        for name, field in self._fields.items():
            if field.error is not None:
                errors[name] = field.error
        return errors

    def save(self, **extra) -> t.Any:
        """
        Saves the form data.

        If the form is valid, this method will collect all the field values and:

        a) If the form is not connected to an ORM model and it wasn't instantiated with
           an object, it will return the data as a dictionary.
        b) If it *was* instantiated with an object, it will update and return the
           object (even if the "object" in question is a dictionary).
        c) If it *wasn't* instantiated with an object, but it is connected to an ORM
           model, it will create a new object and return it.

        For ORM-bound forms, the field-save loop and the object save run inside
        a single transaction (see `_persistence_context`). This ensures that
        side-effecting fields (e.g. an `AttachmentField` that uploads + INSERTs
        a child row) and the parent save commit or roll back together.

        Args:
            **extra:
                Extra data to add before saving. This is useful
                to set fields that are not part of the form (e.g.: foreign keys).

        """

        if not self._deleted and not self.is_valid:
            raise ValueError("Form is not valid", self.get_errors())

        if self._deleted:
            if not self._object.exists():
                return None
            if self._allow_delete:
                self._object.delete()
                return None
            else:
                # Deletion not allowed: log the attempt and return the
                # existing object unchanged.
                logger.error("Deletion is not allowed for this form %s", self)
                return self._object.object

        with self._persistence_context():
            data = {}
            for name, field in self._fields.items():
                data[name] = field.save()

            data.update(extra)
            return self._object.save(data)

    def _persistence_context(self) -> t.ContextManager:
        """Return a context manager wrapping the persistence operations of
        `save()` in a transaction.

        The default duck-types peewee's database handle: if the form's
        `Meta.orm_cls` exposes `_meta.database.atomic()` (peewee's pattern),
        all field saves and the final object save run inside a single
        transaction (a savepoint when nested in an outer atomic block).

        For ORMs that don't expose that shape (SQLAlchemy, Django, plain
        dicts), this returns `nullcontext` and behavior is unchanged —
        transaction management stays the consumer's responsibility.

        Override this method to plug in a different transaction primitive
        (e.g. SQLAlchemy's `session.begin()`).
        """
        orm_cls = self.Meta.orm_cls
        if orm_cls is None:
            return nullcontext()
        meta = getattr(orm_cls, "_meta", None)
        db = getattr(meta, "database", None) if meta else None
        atomic = getattr(db, "atomic", None) if db is not None else None
        return atomic() if callable(atomic) else nullcontext()

    def validate(self) -> bool:
        """
        Triggers validation of each of the fields and the form itself.

        Returns:
            `True` or `False`, whether the form is valid after validation.

        """
        self._valid = True

        for field in self._fields.values():
            field.validate()
            if field.error is not None:
                self._valid = False

        if not self._valid:
            return False

        self._valid = self.after_validate()
        return self._valid

    def after_validate(self) -> bool:
        """
        Called after the individual field validations.

        You can use it to validate the relation between fields (e.g.: `password1 == password2`)
        or to modify the field values before saving.

        To indicate validation errors, set the `error` attribute of the individual fields.

        Returns:
            `True` or `False`, whether the form is valid after the custom validation.

        """
        return True

    def hidden_tags(self) -> str:
        """
        Returns hidden inputs for dealing with objects in nested forms
        """
        tags = []
        delete_tag = self._delete_tag()
        if delete_tag:
            tags.append(delete_tag)
        pk_tag = self._pk_tag()
        if pk_tag:
            tags.append(pk_tag)
        return Markup("\n".join(tags))

    # Private methods

    def _set_messages(self, messages: dict[str, str]):
        self._messages = {**self.Meta.messages, **messages}
        for field in self._fields.values():
            field.set_messages(self._messages)

    def _set_name_format(self, name_format: str) -> None:
        self._name_format = name_format
        for field in self._fields.values():
            field.set_name_format(name_format)

    def _set(self, reqdata: t.Any = None, object: t.Any = None) -> None:
        self._valid = None

        reqdata = parse(reqdata or {})
        self._object = self._ObjectManager(
            orm_cls=self.Meta.orm_cls,
            object=object,
        )
        self._deleted = bool(reqdata.get("_destroy", None))

        if not self._deleted:
            for name, field in self._fields.items():
                field.set(reqdata.get(name), self._object.get(name))

    def _delete_tag(self) -> str:
        """
        Returns a hidden input for marking the form as deleted.
        """
        if self._allow_delete:
            delete_field = TextField(required=False)
            delete_field.parent = self
            delete_field.field_name = "_destroy"
            delete_field.name_format = self._name_format
            return delete_field.hidden_input()
        return ""

    def _pk_tag(self) -> str:
        """
        Returns a hidden input for the primary key of the object.
        """
        if self._object.exists():
            pk_name = getattr(self.Meta, "pk", "id")
            pk = get_pk(self._object.object, pk_name)
            if pk:
                pk_field = TextField(required=False)
                pk_field.parent = self
                pk_field.field_name = "_id"
                pk_field.name_format = self._name_format
                pk_field.value = pk
                return pk_field.hidden_input()
        return ""
