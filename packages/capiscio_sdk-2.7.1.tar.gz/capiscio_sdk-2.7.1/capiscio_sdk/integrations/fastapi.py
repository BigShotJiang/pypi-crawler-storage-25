"""FastAPI integration for Capiscio SimpleGuard."""
from typing import Callable, Awaitable, Any, Dict, List, Optional, Union, TYPE_CHECKING
try:
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.requests import Request
    from starlette.responses import JSONResponse, Response
    from starlette.types import ASGIApp
except ImportError:
    raise ImportError("FastAPI/Starlette is required for this integration. Install with 'pip install fastapi'.")

from ..simple_guard import SimpleGuard
from ..errors import VerificationError
from ..events import EventEmitter
import time
import logging

if TYPE_CHECKING:
    from ..config import SecurityConfig

logger = logging.getLogger(__name__)

class CapiscioMiddleware(BaseHTTPMiddleware):
    """
    Middleware to enforce A2A identity verification on incoming requests.
    
    Args:
        app: The ASGI application.
        guard: SimpleGuard instance, or a callable returning one (for lazy binding).
            When a callable is provided, the guard is resolved on first request.
            This allows registering middleware at module level before connect() runs.
        exclude_paths: List of paths to skip verification (e.g., ["/health", "/.well-known/agent-card.json"]).
        config: Optional SecurityConfig to control enforcement behavior.
        emitter: Optional EventEmitter for auto-event emission. When provided,
            the middleware automatically emits request.received, verification.success,
            and verification.failed events. request.completed is emitted for requests
            that reach the downstream ASGI app; blocked 4xx responses do not emit it.
    
    Security behavior:
        - If config is None, defaults to strict blocking mode
        - fail_mode takes precedence: "log"/"monitor" always allow through (regardless of require_signatures)
        - When fail_mode="block" and require_signatures=False, missing badges are allowed
        - When fail_mode="block" and require_signatures=True, badges are enforced
    """
    def __init__(
        self, 
        app: ASGIApp, 
        guard: Union[SimpleGuard, Callable[[], Optional[SimpleGuard]], None] = None, 
        exclude_paths: Optional[List[str]] = None,
        *,  # Force config to be keyword-only
        config: Optional["SecurityConfig"] = None,
        emitter: Optional[EventEmitter] = None,
    ) -> None:
        super().__init__(app)
        self._guard_factory: Optional[Callable[[], Optional[SimpleGuard]]] = None
        # Treat as factory if it's a plain callable without guard interface,
        # OR if it's a class/type (e.g. passing SimpleGuard itself, not an instance)
        if guard is not None and callable(guard) and (isinstance(guard, type) or not hasattr(guard, 'verify_inbound')):
            self._guard_factory = guard
            self._guard: Optional[SimpleGuard] = None
        else:
            self._guard = guard
        self.config = config
        self.exclude_paths = exclude_paths or []
        self._emitter = emitter
        
        # Default to strict mode if no config
        self.require_signatures = config.downstream.require_signatures if config is not None else True
        self.fail_mode = config.fail_mode if config is not None else "block"
        
        logger.info(f"CapiscioMiddleware initialized: exclude_paths={self.exclude_paths}, require_signatures={self.require_signatures}, fail_mode={self.fail_mode}, auto_events={emitter is not None}")

    @property
    def guard(self) -> Optional[SimpleGuard]:
        """Resolve guard lazily if a factory was provided."""
        if self._guard is None and self._guard_factory is not None:
            self._guard = self._guard_factory()
        return self._guard
    
    def set_guard(self, guard: SimpleGuard) -> None:
        """Set or replace the guard instance after construction.
        
        Useful for binding the guard in a lifespan handler after connect().
        """
        self._guard = guard
        self._guard_factory = None

    async def dispatch(
        self, 
        request: Request, 
        call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        # Allow CORS preflight
        if request.method == "OPTIONS":
            return await call_next(request)
        
        # Skip verification for excluded paths
        path = request.url.path
        logger.debug(f"CapiscioMiddleware: path={path!r}, exclude_paths={self.exclude_paths}, match={path in self.exclude_paths}")
        if path in self.exclude_paths:
            logger.debug(f"CapiscioMiddleware: SKIPPING verification for {path}")
            return await call_next(request)

        # If guard is not yet bound (lazy binding), fail closed to avoid unverified access
        if self.guard is None:
            logger.error("CapiscioMiddleware: guard not bound or unavailable; blocking request")
            request.state.agent = None
            request.state.agent_id = None
            self._auto_emit(EventEmitter.EVENT_VERIFICATION_FAILED, {
                "method": request.method,
                "path": path,
                "reason": "guard_unavailable",
                "duration_ms": 0.0,
            })
            return JSONResponse(
                {"error": "CapiscIO guard is not available. Requests cannot be verified at this time."},
                status_code=503,
            )

        request_start = time.perf_counter()

        # Auto-event: request.received
        self._auto_emit(EventEmitter.EVENT_REQUEST_RECEIVED, {
            "method": request.method,
            "path": path,
        })

        # RFC-002 §9.1: X-Capiscio-Badge header
        auth_header = request.headers.get("X-Capiscio-Badge")
        
        # Handle missing badge based on config
        if not auth_header:
            if not self.require_signatures:
                # No badge required - allow through but mark as unverified
                request.state.agent = None
                request.state.agent_id = None
                response = await call_next(request)
                self._auto_emit_completed(request, response, request_start)
                return response
            
            # Badge required but missing
            if self.fail_mode in ("log", "monitor"):
                logger.warning(f"Missing X-Capiscio-Badge header for {request.url.path} ({self.fail_mode} mode)")
                self._auto_emit(EventEmitter.EVENT_VERIFICATION_FAILED, {
                    "method": request.method,
                    "path": path,
                    "reason": "missing_badge",
                    "duration_ms": round((time.perf_counter() - request_start) * 1000, 2),
                })
                request.state.agent = None
                request.state.agent_id = None
                response = await call_next(request)
                self._auto_emit_completed(request, response, request_start)
                return response
            else:  # block
                self._auto_emit(EventEmitter.EVENT_VERIFICATION_FAILED, {
                    "method": request.method,
                    "path": path,
                    "reason": "missing_badge",
                    "duration_ms": round((time.perf_counter() - request_start) * 1000, 2),
                })
                return JSONResponse(
                    {"error": "Missing X-Capiscio-Badge header. This endpoint is protected by CapiscIO."}, 
                    status_code=401
                )

        verify_start = time.perf_counter()
        try:
            # Read the body for integrity check
            body_bytes = await request.body()
            
            # Verify the JWS with body
            payload = self.guard.verify_inbound(auth_header, body=body_bytes)
            
            # Reset the receive channel so downstream can read the body
            async def receive() -> Dict[str, Any]:
                return {"type": "http.request", "body": body_bytes, "more_body": False}
            request._receive = receive
            
            # Inject claims into request.state
            request.state.agent = payload
            request.state.agent_id = payload.get("iss")

            verification_duration = (time.perf_counter() - verify_start) * 1000

            # Auto-event: verification.success
            self._auto_emit(EventEmitter.EVENT_VERIFICATION_SUCCESS, {
                "method": request.method,
                "path": path,
                "caller_did": payload.get("iss"),
                "duration_ms": round(verification_duration, 2),
            })
            
        except VerificationError as e:
            verification_duration = (time.perf_counter() - verify_start) * 1000

            # Auto-event: verification.failed
            self._auto_emit(EventEmitter.EVENT_VERIFICATION_FAILED, {
                "method": request.method,
                "path": path,
                "reason": str(e),
                "duration_ms": round(verification_duration, 2),
            })

            if self.fail_mode in ("log", "monitor"):
                logger.warning(f"Badge verification failed: {e} ({self.fail_mode} mode)")
                request.state.agent = None
                request.state.agent_id = None
                # Reset receive so downstream can read body (body_bytes was consumed above)
                async def receive() -> Dict[str, Any]:
                    return {"type": "http.request", "body": body_bytes, "more_body": False}
                request._receive = receive
                response = await call_next(request)
                self._auto_emit_completed(request, response, request_start)
                return response
            else:  # block
                return JSONResponse({"error": f"Access Denied: {str(e)}"}, status_code=403)

        response = await call_next(request)
        
        # Add Server-Timing header (standard for performance metrics)
        # Syntax: metric_name;dur=123.4;desc="Description"
        response.headers["Server-Timing"] = f"capiscio-auth;dur={verification_duration:.3f};desc=\"CapiscIO Verification\""

        # Auto-event: request.completed
        self._auto_emit_completed(request, response, request_start)
        
        return response

    def _auto_emit(self, event_type: str, data: Dict[str, Any]) -> None:
        """Emit an auto-event if emitter is configured."""
        if self._emitter:
            try:
                self._emitter.emit(event_type, data)
            except Exception:
                logger.debug(f"Failed to emit auto-event {event_type}", exc_info=True)

    def _auto_emit_completed(
        self, request: Request, response: Response, start_time: float
    ) -> None:
        """Emit request.completed auto-event."""
        if self._emitter:
            duration_ms = (time.perf_counter() - start_time) * 1000
            self._auto_emit(EventEmitter.EVENT_REQUEST_COMPLETED, {
                "method": request.method,
                "path": request.url.path,
                "status_code": response.status_code,
                "duration_ms": round(duration_ms, 2),
                "caller_did": getattr(request.state, "agent_id", None),
            })
