import typing
from datetime import datetime

from kungfu.library.monad.result import Result

from telegrinder.api.api import APIError
from telegrinder.bot.cute_types.base import BaseCute, BaseShortcuts, compose_method_params, shortcut
from telegrinder.types.objects import *
from telegrinder.types.utils import get_params

if typing.TYPE_CHECKING:
    from telegrinder.bot.cute_types.chat_join_request import ChatJoinRequestCute  # noqa


async def chat_member_interaction(
    update: typing.Any,
    method_name: str,
    params: dict[str, typing.Any],
    result_type: typing.Any,
) -> Result[typing.Any, APIError]:
    params = compose_method_params(
        get_params(params),
        update,
        default_params={"chat_id", "user_id"},
    )
    return await getattr(update.bound_api, method_name)(**params)


class ChatMemberShortcuts(BaseShortcuts["ChatMemberUpdatedCute | ChatJoinRequestCute"]):
    """Shortcut methods for `ChatMemberUpdatedCute`, `ChatJoinRequestCute` objects."""

    @shortcut(
        "ban_chat_member", executor=chat_member_interaction, return_type=bool, custom_params={"chat_id", "user_id"}
    )
    async def ban_chat_member(
        self,
        *,
        chat_id: int | str | None = None,
        revoke_messages: bool | None = None,
        until_date: datetime | int | None = None,
        user_id: int | None = None,
        **other: typing.Any,
    ) -> Result[bool, APIError]:
        """Shortcut `API.ban_chat_member()`, see the [documentation](https://core.telegram.org/bots/api#banchatmember)

        Use this method to ban a user in a group, a supergroup or a channel. In the case
        of supergroups and channels, the user will not be able to return to the chat
        on their own using invite links, etc., unless unbanned first. The bot must
        be an administrator in the chat for this to work and must have the appropriate
        administrator rights. Returns True on success.
        :param chat_id: [`CUSTOM PARAMETER`] Unique identifier for the target group or username of the target supergroupor channel in the format @username.

        :param user_id: Unique identifier of the target user.

        :param until_date: Date when the user will be unbanned; Unix time. If user is banned for morethan 366 days or less than 30 seconds from the current time they are consideredto be banned forever. Applied for supergroups and channels only.

        :param revoke_messages: Pass True to delete all messages from the chat for the user that is being removed.If False, the user will be able to see messages in the group that were sentbefore the user was removed. Always True for supergroups and channels."""
        ...

    @shortcut(
        "unban_chat_member", executor=chat_member_interaction, return_type=bool, custom_params={"chat_id", "user_id"}
    )
    async def unban_chat_member(
        self,
        *,
        chat_id: int | str | None = None,
        only_if_banned: bool | None = None,
        user_id: int | None = None,
        **other: typing.Any,
    ) -> Result[bool, APIError]:
        """Shortcut `API.unban_chat_member()`, see the [documentation](https://core.telegram.org/bots/api#unbanchatmember)

        Use this method to unban a previously banned user in a supergroup or channel.
        The user will not return to the group or channel automatically, but will
        be able to join via link, etc. The bot must be an administrator for this to
        work. By default, this method guarantees that after the call the user is
        not a member of the chat, but will be able to join it. So if the user is a member
        of the chat they will also be removed from the chat. If you don't want this,
        use the parameter only_if_banned. Returns True on success.
        :param chat_id: [`CUSTOM PARAMETER`] Unique identifier for the target group or username of the target supergroupor channel in the format @username.

        :param user_id: Unique identifier of the target user.

        :param only_if_banned: Do nothing if the user is not banned."""
        ...

    @shortcut(
        "restrict_chat_member",
        executor=chat_member_interaction,
        return_type=bool,
        custom_params={"chat_id", "user_id"},
    )
    async def restrict_chat_member(
        self,
        *,
        permissions: ChatPermissions,
        chat_id: int | str | None = None,
        until_date: datetime | int | None = None,
        use_independent_chat_permissions: bool | None = None,
        user_id: int | None = None,
        **other: typing.Any,
    ) -> Result[bool, APIError]:
        """Shortcut `API.restrict_chat_member()`, see the [documentation](https://core.telegram.org/bots/api#restrictchatmember)

        Use this method to restrict a user in a supergroup. The bot must be an administrator
        in the supergroup for this to work and must have the appropriate administrator
        rights. Pass True for all permissions to lift restrictions from a user.
        Returns True on success.
        :param chat_id: [`CUSTOM PARAMETER`] Unique identifier for the target chat or username of the target supergroupin the format @username.

        :param user_id: Unique identifier of the target user.

        :param permissions: A JSON-serialized object for new user permissions.

        :param use_independent_chat_permissions: Pass True if chat permissions are set independently. Otherwise, the can_send_other_messagesand can_add_web_page_previews permissions will imply the can_send_messages,can_send_audios, can_send_documents, can_send_photos, can_send_videos,can_send_video_notes, and can_send_voice_notes permissions; the can_send_pollspermission will imply the can_send_messages permission.

        :param until_date: Date when restrictions will be lifted for the user; Unix time. If user isrestricted for more than 366 days or less than 30 seconds from the currenttime, they are considered to be restricted forever."""
        ...

    @shortcut(
        "promote_chat_member",
        executor=chat_member_interaction,
        return_type=bool,
        custom_params={"chat_id", "user_id"},
    )
    async def promote_chat_member(
        self,
        *,
        can_change_info: bool | None = None,
        can_delete_messages: bool | None = None,
        can_delete_stories: bool | None = None,
        can_edit_messages: bool | None = None,
        can_edit_stories: bool | None = None,
        can_invite_users: bool | None = None,
        can_manage_chat: bool | None = None,
        can_manage_direct_messages: bool | None = None,
        can_manage_tags: bool | None = None,
        can_manage_topics: bool | None = None,
        can_manage_video_chats: bool | None = None,
        can_pin_messages: bool | None = None,
        can_post_messages: bool | None = None,
        can_post_stories: bool | None = None,
        can_promote_members: bool | None = None,
        can_restrict_members: bool | None = None,
        chat_id: int | str | None = None,
        is_anonymous: bool | None = None,
        user_id: int | None = None,
        **other: typing.Any,
    ) -> Result[bool, APIError]:
        """Shortcut `API.promote_chat_member()`, see the [documentation](https://core.telegram.org/bots/api#promotechatmember)

        Use this method to promote or demote a user in a supergroup or a channel. The
        bot must be an administrator in the chat for this to work and must have the
        appropriate administrator rights. Pass False for all boolean parameters
        to demote a user. Returns True on success.
        :param chat_id: [`CUSTOM PARAMETER`] Unique identifier for the target chat or username of the target channelin the format @username.

        :param user_id: Unique identifier of the target user.

        :param is_anonymous: Pass True if the administrator's presence in the chat is hidden.

        :param can_manage_chat: Pass True if the administrator can access the chat event log, get boost list,see hidden supergroup and channel members, report spam messages, ignoreslow mode, and send messages to the chat without paying Telegram Stars.Implied by any other administrator privilege.

        :param can_delete_messages: Pass True if the administrator can delete messages of other users.

        :param can_manage_video_chats: Pass True if the administrator can manage video chats.

        :param can_restrict_members: Pass True if the administrator can restrict, ban or unban chat members,or access supergroup statistics. For backward compatibility, defaultsto True for promotions of channel administrators.

        :param can_promote_members: Pass True if the administrator can add new administrators with a subsetof their own privileges or demote administrators that they have promoted,directly or indirectly (promoted by administrators that were appointedby him).

        :param can_change_info: Pass True if the administrator can change chat title, photo and other settings.
        :param can_invite_users: Pass True if the administrator can invite new users to the chat.

        :param can_post_stories: Pass True if the administrator can post stories to the chat.

        :param can_edit_stories: Pass True if the administrator can edit stories posted by other users, poststories to the chat page, pin chat stories, and access the chat's story archive.
        :param can_delete_stories: Pass True if the administrator can delete stories posted by other users.
        :param can_post_messages: Pass True if the administrator can post messages in the channel, approvesuggested posts, or access channel statistics; for channels only.

        :param can_edit_messages: Pass True if the administrator can edit messages of other users and can pinmessages; for channels only.

        :param can_pin_messages: Pass True if the administrator can pin messages; for supergroups only.
        :param can_manage_topics: Pass True if the user is allowed to create, rename, close, and reopen forumtopics; for supergroups only.

        :param can_manage_direct_messages: Pass True if the administrator can manage direct messages within the channeland decline suggested posts; for channels only.

        :param can_manage_tags: Pass True if the administrator can edit the tags of regular members; forgroups and supergroups only."""
        ...

    @shortcut(
        "set_chat_administrator_custom_title",
        executor=chat_member_interaction,
        return_type=bool,
        custom_params={"chat_id", "user_id"},
    )
    async def set_chat_administrator_custom_title(
        self,
        *,
        custom_title: str,
        chat_id: int | str | None = None,
        user_id: int | None = None,
        **other: typing.Any,
    ) -> Result[bool, APIError]:
        """Shortcut `API.set_chat_administrator_custom_title()`, see the [documentation](https://core.telegram.org/bots/api#setchatadministratorcustomtitle)

        Use this method to set a custom title for an administrator in a supergroup
        promoted by the bot. Returns True on success.
        :param chat_id: [`CUSTOM PARAMETER`] Unique identifier for the target chat or username of the target supergroupin the format @username.

        :param user_id: Unique identifier of the target user.

        :param custom_title: New custom title for the administrator; 0-16 characters, emoji are notallowed."""
        ...


class ChatMemberUpdatedCute(BaseCute[ChatMemberUpdated], ChatMemberUpdated, ChatMemberShortcuts, kw_only=True):
    @property
    def from_user(self) -> User:
        return self.from_

    @property
    def user_id(self) -> int:
        return self.from_user.id


__all__ = (
    "ChatMemberShortcuts",
    "ChatMemberUpdatedCute",
)
