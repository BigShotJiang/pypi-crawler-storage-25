# NetCloak

Cross-platform traffic anonymization tool for Windows, Linux, and macOS — designed for authorized security research.

## Overview

NetCloak routes all system traffic through Tor with a proxy pool fallback, enforces a kill switch to prevent leaks, locks DNS to Tor's resolver, and provides a live Textual TUI dashboard for real-time monitoring and control.

## Features

- **Tor routing** — all traffic exits via Tor SOCKS5; obfs4 bridge support for censored networks
- **Proxy pool** — SOCKS5 proxy scraping, validation, weighted selection, and auto-rotation
- **Kill switch** — Windows Firewall / iptables blocks all non-Tor traffic when active
- **DNS lockdown** — per-adapter DNS forced to 127.0.0.1 (Tor DNSPort relay); leak detection
- **Wintun TUN** — transparent Layer-3 routing on Windows (no per-app proxy config needed)
- **Live TUI dashboard** — Textual app with real-time status panels and inline CLI command bar
- **ProxyChains config** — auto-generated `proxychains.conf` for chain-based routing on Linux

## Requirements

- Python 3.11+
- Tor installed and in PATH (`tor` binary)
- **Windows:** Administrator privileges; [Wintun](https://www.wintun.net/) driver (optional, for TUN mode)
- **Linux:** root + iptables
- **macOS:** root + pfctl

## Installation

```bash
pip install -e ".[dev]"
```

## Usage

```bash
# Start — fetch proxies, start Tor, enable kill switch, lock DNS
netcloak start                  # Tor mode (default)
netcloak start --proxy          # proxy-only mode
netcloak start --auto           # auto mode (Tor with proxy fallback)

# Stop — tear down routing, restore network
netcloak stop

# Status — show IPs, Tor status, DNS leak check, proxy pool
netcloak status
netcloak status --json

# Rotate proxy pool
netcloak rotate

# Bridges — fetch obfs4 bridges via Tor (when running) or directly
netcloak bridges                # fetch and display bridges
netcloak bridges --save         # fetch and write to config.toml automatically
netcloak bridges --add "obfs4 <ip>:<port> cert=... iat-mode=0"  # add custom bridge

# Live TUI dashboard (requires a running session)
netcloak tui
```

## TUI Dashboard

The `netcloak tui` command opens a live Textual dashboard:

- **Network Status panel** — mode, IP hidden, Tor active, kill switch, local proxy liveness
- **Proxy Pool panel** — pool size, active proxy IP/latency/country
- **Scrolling log** — timestamped output from active checks and commands
- **Command input bar** — type any `netcloak` command and see output inline

Panels refresh from `state.json` every 2 seconds. Active checks (leak test, proxy liveness) run every 30 seconds in a background thread.

## Configuration

Copy `config.toml.example` to `config.toml` (or edit the existing one):

```toml
[tor]
socks_port = 9050
control_port = 9051
use_bridges = false
bridge_type = "obfs4"
bridges = []
# bridges = ["obfs4 1.2.3.4:1234 cert=ABC... iat-mode=0"]

[proxy]
local_port = 8080
chain_length = 2
chain_type = "dynamic"
rotation_interval_min = 0    # 0 = disabled

[routing]
kill_switch = true

[monitor]
check_interval_sec = 30
```

## Using Tor Bridges

Bridges bypass Tor censorship. Three ways to add them:

**Auto-fetch:**
```bash
netcloak bridges --save
```

**Fetch manually** from [bridges.torproject.org](https://bridges.torproject.org), then:
```bash
netcloak bridges --add "obfs4 <ip>:<port> cert=<cert> iat-mode=0"
```

**Edit config.toml directly:**
```toml
[tor]
use_bridges = true
bridge_type = "obfs4"
bridges = ["obfs4 1.2.3.4:1234 cert=ABC... iat-mode=0"]
```

## IP Hidden / Leak Check Notes

On Windows with the kill switch and Wintun TUN active, **all** traffic — including the "real IP" probe — exits via Tor. This means `real_ip == tunnel_ip`, which NetCloak correctly reports as **IP Hidden: Yes** (kill switch is working; your real IP is unreachable directly).

DNS leak detection checks:
1. Whether all network adapters are pointed at `127.0.0.1` (Tor DNS relay)
2. Whether Tor's DNSPort (9053) is responding to queries

## Security Notice

For authorized security research only. Ensure you have permission before routing traffic through any network or using this tool in production environments.
