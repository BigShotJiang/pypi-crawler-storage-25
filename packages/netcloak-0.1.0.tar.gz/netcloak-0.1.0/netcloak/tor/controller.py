"""Tor controller — stem-based bootstrap monitoring and circuit management.

Wraps stem's Controller to provide:
- Bootstrap monitoring with configurable timeout
- NEWNYM (new identity) signalling
- Exit IP detection via check.torproject.org
- is_tor() verification

Usage:
    controller = TorController(control_port=9051)
    controller.connect()
    pct = controller.monitor_bootstrap(timeout=60)   # raises TorBootstrapTimeout if < 15
    controller.new_identity()
    exit_ip = controller.get_exit_ip()
    controller.disconnect()
"""
from __future__ import annotations

import logging
import re
import time

import requests

try:
    from stem.control import Controller
    from stem import Signal
except ImportError:
    Controller = None  # type: ignore[assignment,misc]
    Signal = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)

_BOOTSTRAP_RE = re.compile(r"PROGRESS=(\d+)")


class TorBootstrapTimeout(Exception):
    """Raised when Tor fails to reach bootstrap threshold within the timeout."""


class TorController:
    """Stem-based Tor controller for bootstrap monitoring and circuit management."""

    def __init__(self, control_port: int = 9051) -> None:
        self._control_port = control_port
        self._controller = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """Authenticate to the Tor control port via stem."""
        if Controller is None:
            raise ImportError("stem is required — pip install stem")
        self._controller = Controller.from_port(port=self._control_port)
        self._controller.authenticate()
        logger.debug("Connected to Tor control port %d", self._control_port)

    def disconnect(self) -> None:
        """Close the stem controller connection."""
        if self._controller is not None:
            try:
                self._controller.close()
            except Exception as exc:
                logger.debug("Error closing controller: %s", exc)
            finally:
                self._controller = None

    # ------------------------------------------------------------------
    # Bootstrap monitoring
    # ------------------------------------------------------------------

    def monitor_bootstrap(self, timeout: float = 60.0) -> int:
        """Poll Tor's bootstrap progress until threshold or timeout.

        Returns the final bootstrap percentage (>= 15).
        Raises TorBootstrapTimeout if Tor does not reach 15% within *timeout* seconds.
        """
        if self._controller is None:
            raise RuntimeError("Not connected — call connect() first")

        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try:
                status = self._controller.get_info("status/bootstrap-phase", "")
                match = _BOOTSTRAP_RE.search(status)
                pct = int(match.group(1)) if match else 0
                logger.debug("Bootstrap: %d%%", pct)
                if pct >= 15:
                    return pct
            except Exception as exc:
                logger.debug("Bootstrap poll error: %s", exc)
            time.sleep(2.0)

        raise TorBootstrapTimeout(
            f"Tor did not reach 15% bootstrap within {timeout:.0f}s"
        )

    # ------------------------------------------------------------------
    # Circuit management
    # ------------------------------------------------------------------

    def new_identity(self) -> None:
        """Request a new Tor circuit (NEWNYM signal)."""
        if self._controller is None:
            raise RuntimeError("Not connected — call connect() first")
        self._controller.signal(Signal.NEWNYM)
        logger.info("NEWNYM signal sent — new Tor circuit requested")

    # ------------------------------------------------------------------
    # Exit IP / verification
    # ------------------------------------------------------------------

    def get_exit_ip(self, socks_port: int = 9050) -> str | None:
        """Return the current Tor exit IP from check.torproject.org.

        Routes the request through the Tor SOCKS5H proxy.
        Returns IP string on success, None on failure.
        """
        proxies = {
            "http": f"socks5h://127.0.0.1:{socks_port}",
            "https": f"socks5h://127.0.0.1:{socks_port}",
        }
        try:
            resp = requests.get(
                "https://check.torproject.org/api/ip",
                proxies=proxies,
                timeout=15,
            )
            resp.raise_for_status()
            data = resp.json()
            ip = data.get("IP", "")
            logger.info("Tor exit IP: %s", ip)
            return ip if ip else None
        except Exception as exc:
            logger.warning("Failed to get Tor exit IP: %s", exc)
            return None

    def is_tor(self, socks_port: int = 9050) -> bool:
        """Return True if the current connection routes through Tor.

        Checks check.torproject.org/api/ip's isTor field.
        """
        proxies = {
            "http": f"socks5h://127.0.0.1:{socks_port}",
            "https": f"socks5h://127.0.0.1:{socks_port}",
        }
        try:
            resp = requests.get(
                "https://check.torproject.org/api/ip",
                proxies=proxies,
                timeout=15,
            )
            resp.raise_for_status()
            return bool(resp.json().get("IsTor", False))
        except Exception as exc:
            logger.warning("is_tor() check failed: %s", exc)
            return False
