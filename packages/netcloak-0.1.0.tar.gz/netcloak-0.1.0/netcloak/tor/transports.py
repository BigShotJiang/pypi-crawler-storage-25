"""Pluggable transports torrc configuration helpers.

Provides torrc line generation for obfs4 and snowflake transports.
The existing bridge logic in TorManager._build_torrc() handles the
actual bridge line insertion — this module provides standalone helpers
for building transport-specific torrc fragments.
"""
from __future__ import annotations

import shutil
from pathlib import Path

_OBFS4PROXY_CANDIDATES = [
    "/usr/bin/obfs4proxy",
    "/usr/local/bin/obfs4proxy",
]


def find_obfs4proxy() -> str | None:
    """Locate the obfs4proxy binary. Returns path or None."""
    found = shutil.which("obfs4proxy")
    if found:
        return found
    for candidate in _OBFS4PROXY_CANDIDATES:
        if Path(candidate).is_file():
            return candidate
    return None


def get_transport_lines(transport: str, bridges: list[str]) -> list[str]:
    """Return torrc lines for the specified transport and bridges.

    Args:
        transport: "obfs4" or "snowflake"
        bridges: List of bridge strings

    Returns:
        List of torrc lines (without newlines)
    """
    lines: list[str] = ["UseBridges 1"]

    if transport == "obfs4":
        obfs4 = find_obfs4proxy()
        if obfs4:
            lines.append(f"ClientTransportPlugin obfs4 exec {obfs4}")
    elif transport == "snowflake":
        snowflake = shutil.which("snowflake-client")
        if snowflake:
            lines.append(f"ClientTransportPlugin snowflake exec {snowflake}")

    for bridge in bridges:
        lines.append(f"Bridge {bridge}")

    return lines


__all__ = ["find_obfs4proxy", "get_transport_lines"]
