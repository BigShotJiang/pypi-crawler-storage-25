"""Tor daemon manager — cross-platform (Linux + Windows)."""
from __future__ import annotations

import os
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

import requests
from rich.console import Console

_console = Console(stderr=True)

_SOCKS_HOST = "127.0.0.1"
_CHECK_URL = "https://api.ipify.org?format=json"

# Common Windows Tor Browser installation paths
_WINDOWS_TOR_CANDIDATES = [
    r"C:\Program Files\Tor Browser\Browser\TorBrowser\Tor\tor.exe",
    r"C:\Program Files (x86)\Tor Browser\Browser\TorBrowser\Tor\tor.exe",
    r"C:\Users\{username}\Desktop\Tor Browser\Browser\TorBrowser\Tor\tor.exe",
]

_OBFS4PROXY_CANDIDATES = [
    "/usr/bin/obfs4proxy",
    "/usr/local/bin/obfs4proxy",
]


def check_obfs4proxy() -> bool:
    """Return True if obfs4proxy binary is available in PATH or common locations."""
    if shutil.which("obfs4proxy"):
        return True
    return any(Path(p).is_file() for p in _OBFS4PROXY_CANDIDATES)


def _default_data_dir() -> str:
    """Return a platform-appropriate default data directory."""
    if sys.platform == "win32":
        return os.path.expandvars(r"%APPDATA%\NetCloak\tor")
    return "/tmp/netcloak_tor"


class TorManager:
    """Manage a local Tor daemon subprocess."""

    def __init__(
        self,
        socks_port: int = 9050,
        control_port: int = 9051,
        dns_port: int = 9053,
        trans_port: int = 9040,
        data_dir: str | None = None,
        binary_path: str = "",
        use_bridges: bool = False,
        bridge_type: str = "obfs4",
        bridges: list[str] | None = None,
    ) -> None:
        self.socks_port = socks_port
        self.control_port = control_port
        self.dns_port = dns_port
        self.trans_port = trans_port
        # Expand env vars in data_dir (handles %APPDATA% on Windows)
        self.data_dir = os.path.expandvars(data_dir or _default_data_dir())
        self.binary_path = binary_path
        self.use_bridges = use_bridges
        self.bridge_type = bridge_type
        self.bridges: list[str] = bridges or []
        self._process: Optional[subprocess.Popen] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start(self) -> bool:
        """Write torrc, launch Tor daemon, and wait up to 30 s for SOCKS5 port.

        Returns True on success, False on timeout or missing binary.
        """
        if self.is_running():
            _console.print("[yellow]Tor is already running.[/yellow]")
            return True

        tor_bin = self._find_tor_binary()
        if tor_bin is None:
            return False  # error already printed in _find_tor_binary

        data_path = Path(self.data_dir)
        data_path.mkdir(parents=True, exist_ok=True)

        torrc_path = data_path / "torrc"
        torrc_content = self._build_torrc()
        torrc_path.write_text(torrc_content)
        _console.print(f"[cyan]torrc written to {torrc_path}[/cyan]")

        cmd = [tor_bin, "-f", str(torrc_path)]
        _console.print("[cyan]Starting Tor daemon…[/cyan]")
        self._process = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            if self._port_open(self.socks_port):
                _console.print(f"[green]Tor SOCKS5 ready on port {self.socks_port}.[/green]")
                self._write_pid()
                return True
            time.sleep(0.5)

        _console.print("[red]Tor failed to start within 30 seconds.[/red]")
        self._process.kill()
        self._process = None
        return False

    def stop(self) -> None:
        """Stop the managed Tor subprocess.

        If this TorManager does not own the process (e.g. ``netcloak stop``
        runs in a fresh interpreter), falls back to the PID file written by
        the original ``start()`` call and terminates that process via psutil.
        """
        stopped = False

        if self._process is not None:
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
            self._process = None
            stopped = True
        else:
            # Cross-invocation stop: find the process written at start() time.
            pid = self._read_pid()
            if pid is not None:
                try:
                    import psutil
                    proc = psutil.Process(pid)
                    proc.terminate()
                    try:
                        proc.wait(timeout=5)
                    except psutil.TimeoutExpired:
                        proc.kill()
                    stopped = True
                    _console.print(f"[cyan]Tor daemon (PID {pid}) terminated.[/cyan]")
                except psutil.NoSuchProcess:
                    _console.print(f"[yellow]Tor process (PID {pid}) was already gone.[/yellow]")
                except Exception as exc:
                    _console.print(f"[red]Could not stop Tor (PID {pid}):[/red] {exc}")

        self._clear_pid_file()

        if stopped:
            _console.print("[cyan]Tor daemon stopped.[/cyan]")
        else:
            _console.print("[yellow]No active Tor process found to stop.[/yellow]")

    def is_running(self) -> bool:
        """Return True if the Tor process is alive and SOCKS5 port is open."""
        if self._process is not None and self._process.poll() is not None:
            self._process = None
        return self._port_open(self.socks_port)

    def get_pid(self) -> int | None:
        """Return the PID of the running Tor process, or None if not running."""
        if self._process is not None and self._process.poll() is None:
            return self._process.pid
        return self._read_pid()

    def get_circuit_ip(self) -> str | None:
        """Query the current Tor exit IP via the SOCKS5 proxy."""
        proxies = {
            "http": f"socks5h://{_SOCKS_HOST}:{self.socks_port}",
            "https": f"socks5h://{_SOCKS_HOST}:{self.socks_port}",
        }
        try:
            resp = requests.get(_CHECK_URL, proxies=proxies, timeout=15)
            resp.raise_for_status()
            return resp.json().get("ip")
        except Exception as exc:
            _console.print(f"[red]Failed to get Tor circuit IP:[/red] {exc}")
            return None

    def new_identity(self) -> None:
        """Send NEWNYM signal to Tor control port to get a new circuit."""
        try:
            from stem import Signal
            from stem.control import Controller

            with Controller.from_port(port=self.control_port) as ctrl:
                ctrl.authenticate()
                ctrl.signal(Signal.NEWNYM)
            _console.print("[green]New Tor identity requested.[/green]")
        except ImportError:
            _console.print("[red]stem library not installed.[/red]")
        except Exception as exc:
            _console.print(f"[red]Failed to send NEWNYM:[/red] {exc}")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _pid_file_path(self) -> Path:
        return Path(self.data_dir) / "tor.pid"

    def _write_pid(self) -> None:
        """Write the current process PID to <data_dir>/tor.pid."""
        if self._process is not None:
            try:
                self._pid_file_path().write_text(str(self._process.pid))
            except OSError as exc:
                _console.print(f"[yellow]Could not write PID file:[/yellow] {exc}")

    def _read_pid(self) -> int | None:
        """Read PID from tor.pid file. Returns None if missing or invalid."""
        try:
            return int(self._pid_file_path().read_text().strip())
        except (OSError, ValueError):
            return None

    def _clear_pid_file(self) -> None:
        """Remove tor.pid if it exists."""
        self._pid_file_path().unlink(missing_ok=True)

    def _build_torrc(self) -> str:
        """Build a torrc string for the current configuration."""
        # On Windows: DNSPort enabled so the UDP DNS relay proxy can forward
        # queries through Tor.  TransPort is Linux-only (iptables transparent proxy).
        if sys.platform == "win32":
            lines = [
                f"DataDirectory {self.data_dir}",
                f"SocksPort {self.socks_port}",
                f"ControlPort {self.control_port}",
                f"DNSPort {self.dns_port}",
                "CookieAuthentication 1",
                "Log notice stderr",
            ]
        else:
            lines = [
                f"DataDirectory {self.data_dir}",
                f"SocksPort {self.socks_port}",
                f"ControlPort {self.control_port}",
                f"DNSPort {self.dns_port}",
                f"TransPort {self.trans_port}",
                "CookieAuthentication 1",
                "AutomapHostsOnResolve 1",
                "VirtualAddrNetworkIPv4 10.192.0.0/10",
                "Log notice stderr",
            ]

        if self.use_bridges and self.bridges:
            lines.append("UseBridges 1")
            # Locate obfs4proxy binary
            obfs4proxy_path = shutil.which("obfs4proxy")
            if not obfs4proxy_path:
                for candidate in _OBFS4PROXY_CANDIDATES:
                    if Path(candidate).is_file():
                        obfs4proxy_path = candidate
                        break
            if obfs4proxy_path:
                lines.append(f"ClientTransportPlugin {self.bridge_type} exec {obfs4proxy_path}")
            for bridge in self.bridges:
                lines.append(f"Bridge {bridge}")

        return "\n".join(lines) + "\n"

    def _find_tor_binary(self) -> str | None:
        """Locate the Tor binary. Returns path or None (with error message)."""
        # 1. Explicit config override
        if self.binary_path:
            if Path(self.binary_path).is_file():
                return self.binary_path
            _console.print(
                f"[red]Configured binary_path not found:[/red] {self.binary_path}"
            )
            return None

        # 2. PATH
        name = "tor.exe" if sys.platform == "win32" else "tor"
        found = shutil.which(name)
        if found:
            return found

        # 3. Windows common locations
        if sys.platform == "win32":
            username = os.environ.get("USERNAME", "")
            for candidate in _WINDOWS_TOR_CANDIDATES:
                path = candidate.replace("{username}", username)
                if Path(path).is_file():
                    return path

            _console.print(
                "[red]tor.exe not found.[/red]\n"
                "Install Tor Browser from [link]https://www.torproject.org/download/[/link] "
                "or set [bold]binary_path[/bold] in config.toml."
            )
        else:
            _console.print(
                "[red]'tor' binary not found in PATH.[/red]\n"
                "Install Tor: [bold]sudo apt install tor[/bold] (Debian/Ubuntu) "
                "or [bold]sudo dnf install tor[/bold] (Fedora)."
            )
        return None

    @staticmethod
    def _port_open(port: int, host: str = _SOCKS_HOST) -> bool:
        try:
            with socket.create_connection((host, port), timeout=1):
                return True
        except OSError:
            return False
