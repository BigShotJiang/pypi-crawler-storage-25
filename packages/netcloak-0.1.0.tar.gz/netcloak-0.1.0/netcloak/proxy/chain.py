"""Proxy chaining via pproxy.

Provides a thin wrapper around pproxy for chaining multiple proxies
before reaching the Tor SOCKS5 endpoint.
"""
from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


def create_chain(proxies: list[str], listen_port: int = 18080) -> Any | None:
    """Create a pproxy chain server listening on localhost.

    Args:
        proxies: List of proxy URLs to chain through (e.g. ["socks5h://1.2.3.4:1080"])
        listen_port: Local port to listen on

    Returns:
        Tuple of (pproxy.Server, pproxy.Connection), or None if pproxy unavailable.
    """
    try:
        import pproxy
        chain = " ".join(proxies)
        server = pproxy.Server(f"socks5://127.0.0.1:{listen_port}")
        remote = pproxy.Connection(chain)
        logger.info("Proxy chain created: %s -> 127.0.0.1:%d", chain, listen_port)
        return (server, remote)
    except ImportError:
        logger.warning("pproxy not installed — proxy chaining unavailable")
        return None
    except Exception as exc:
        logger.error("Failed to create proxy chain: %s", exc)
        return None


__all__ = ["create_chain"]
