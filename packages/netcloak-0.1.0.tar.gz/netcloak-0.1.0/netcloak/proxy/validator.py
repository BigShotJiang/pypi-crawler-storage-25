"""Proxy validator — latency check via SOCKS5 connection."""
from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

import requests
import socks  # PySocks
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TaskProgressColumn, TimeElapsedColumn

_console = Console(stderr=True)

_CHECK_URL = "https://api.ipify.org?format=json"


def validate_proxy(proxy: dict[str, Any], timeout: int = 5) -> dict[str, Any] | None:
    """Test a SOCKS5 proxy by connecting through it to _CHECK_URL.

    Returns the proxy dict with an added ``latency_ms`` key on success,
    or ``None`` if the proxy is unreachable / too slow.
    """
    ip = proxy["ip"]
    port = proxy["port"]
    proxies = {
        "http": f"socks5://{ip}:{port}",
        "https": f"socks5://{ip}:{port}",
    }
    try:
        start = time.monotonic()
        resp = requests.get(_CHECK_URL, proxies=proxies, timeout=timeout)
        latency_ms = int((time.monotonic() - start) * 1000)
        resp.raise_for_status()
        result = dict(proxy)
        result["latency_ms"] = latency_ms
        return result
    except Exception:
        return None


def validate_pool(
    proxies: list[dict[str, Any]],
    max_workers: int = 20,
) -> list[dict[str, Any]]:
    """Validate a list of proxies concurrently.

    Returns list sorted by ascending latency_ms.
    Shows a Rich progress bar during validation.
    """
    valid: list[dict[str, Any]] = []

    with Progress(
        SpinnerColumn(),
        "[progress.description]{task.description}",
        BarColumn(),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        console=_console,
        transient=True,
    ) as progress:
        task = progress.add_task(
            f"[cyan]Validating {len(proxies)} proxies…", total=len(proxies)
        )
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_proxy = {executor.submit(validate_proxy, p): p for p in proxies}
            for future in as_completed(future_to_proxy):
                result = future.result()
                if result is not None:
                    valid.append(result)
                progress.advance(task)

    valid.sort(key=lambda p: p["latency_ms"])
    _console.print(f"[green]{len(valid)} proxies passed validation.[/green]")
    return valid
