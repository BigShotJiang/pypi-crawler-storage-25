"""Proxy rotation engine with TTL-cached pool persistence."""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from rich.console import Console

from netcloak.proxy.fetcher import fetch_proxies, fetch_proxies_text
from netcloak.proxy.validator import validate_pool

_console = Console(stderr=True)

_POOL_CACHE_TTL = 30 * 60  # 30 minutes in seconds
_POOL_MIN_SIZE = 5


class ProxyRotator:
    """Fetch, validate, cache and rotate a pool of SOCKS5 proxies."""

    def __init__(self, config: dict[str, Any]) -> None:
        self._cfg = config
        proxy_cfg = config.get("proxy", {})
        tor_cfg = config.get("tor", {})

        self._source_url: str = proxy_cfg.get(
            "source_url",
            "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/all/data.json",
        )
        self._max_latency: int = proxy_cfg.get("max_latency_ms", 2000)
        self._max_workers: int = proxy_cfg.get("validation_workers", 20)
        self._min_anonymity: str = proxy_cfg.get("min_anonymity", "anonymous")

        data_dir = tor_cfg.get("data_dir", "/tmp/netcloak_tor")
        self._pool_path = Path(data_dir) / "proxy_pool.json"

        self._pool: list[dict[str, Any]] = []
        self._active_index: int = 0
        self._pool_timestamp: float = 0.0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load_pool(
        self,
        preferred_countries: list[str] | None = None,
        exclude_countries: list[str] | None = None,
    ) -> int:
        """Load the proxy pool, using the on-disk cache if fresh enough.

        If *preferred_countries* is provided (e.g. ["US", "DE"]), only proxies
        matching those country codes are kept. If *exclude_countries* is
        provided (e.g. ["CN", "RU"]), those are always removed. Both filters
        are applied after loading/refreshing the pool.

        Returns the number of valid proxies after filtering.
        """
        cached = self._load_cache()
        if cached is not None:
            self._pool = cached["proxies"]
            self._pool_timestamp = cached["timestamp"]
            self._active_index = 0
            _console.print(
                f"[cyan]Using cached proxy pool ({len(self._pool)} proxies, "
                f"{int(time.time() - self._pool_timestamp)}s old).[/cyan]"
            )
        else:
            self._refresh_pool()

        # Apply geo-filters
        if preferred_countries:
            preferred_upper = [c.upper() for c in preferred_countries]
            self._pool = [
                p for p in self._pool
                if p.get("country", "").upper() in preferred_upper
            ]
        if exclude_countries:
            excluded_upper = [c.upper() for c in exclude_countries]
            self._pool = [
                p for p in self._pool
                if p.get("country", "").upper() not in excluded_upper
            ]

        if preferred_countries or exclude_countries:
            _console.print(f"[cyan]After geo-filter: {len(self._pool)} proxies.[/cyan]")

        return len(self._pool)

    def get_current(self) -> dict[str, Any] | None:
        """Return the currently active proxy, or None if the pool is empty."""
        if not self._pool:
            return None
        return self._pool[self._active_index % len(self._pool)]

    def rotate(self) -> dict[str, Any] | None:
        """Advance to the next proxy (round-robin).

        If the pool is exhausted (wrapped around fully), re-fetches and
        re-validates. Returns the new active proxy, or None on failure.
        """
        if not self._pool:
            self._refresh_pool()
            if not self._pool:
                return None
            return self.get_current()

        self._active_index += 1
        if self._active_index >= len(self._pool):
            _console.print("[yellow]Pool exhausted — re-fetching proxies…[/yellow]")
            self._refresh_pool()
            if not self._pool:
                return None

        proxy = self.get_current()
        if proxy:
            _console.print(
                f"[green]Rotated to proxy {self._active_index + 1}/{len(self._pool)}: "
                f"{proxy['ip']}:{proxy['port']} ({proxy.get('country', '?')}, "
                f"{proxy.get('latency_ms', '?')} ms)[/green]"
            )
        return proxy

    def get_pool_status(self) -> dict[str, Any]:
        """Return a snapshot of pool state."""
        return {
            "total": len(self._pool),
            "active_index": self._active_index,
            "current_proxy": self.get_current(),
            "pool_age_seconds": int(time.time() - self._pool_timestamp) if self._pool_timestamp else None,
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _refresh_pool(self) -> int:
        """Fetch + validate proxies, persist to cache, reset index."""
        socks_port: int = self._cfg.get("tor", {}).get("socks_port", 9050)
        raw = fetch_proxies(url=self._source_url, socks_port=socks_port)

        # JSON source returned 0 — fall back to text-format SOCKS5-only sources.
        if not raw:
            _console.print(
                "[yellow]JSON proxy source returned 0 — trying text-format fallback sources…[/yellow]"
            )
            raw = fetch_proxies_text(socks_port=socks_port)

        validated = validate_pool(raw, max_workers=self._max_workers)

        # Apply latency filter
        filtered = [p for p in validated if p.get("latency_ms", 99999) <= self._max_latency]

        self._pool = filtered
        self._active_index = 0
        self._pool_timestamp = time.time()
        self._save_cache()

        _console.print(f"[green]Proxy pool refreshed: {len(self._pool)} proxies.[/green]")
        return len(self._pool)

    def _load_cache(self) -> dict[str, Any] | None:
        """Return cached pool data if it exists and is fresh, else None."""
        if not self._pool_path.exists():
            return None
        try:
            data = json.loads(self._pool_path.read_text())
            age = time.time() - data.get("timestamp", 0)
            count = len(data.get("proxies", []))
            if age < _POOL_CACHE_TTL and count >= _POOL_MIN_SIZE:
                return data
        except Exception:
            pass
        return None

    def _save_cache(self) -> None:
        """Persist current pool to disk."""
        try:
            self._pool_path.parent.mkdir(parents=True, exist_ok=True)
            self._pool_path.write_text(
                json.dumps({"timestamp": self._pool_timestamp, "proxies": self._pool}, indent=2)
            )
        except Exception as exc:
            _console.print(f"[yellow]Could not save proxy pool cache:[/yellow] {exc}")
