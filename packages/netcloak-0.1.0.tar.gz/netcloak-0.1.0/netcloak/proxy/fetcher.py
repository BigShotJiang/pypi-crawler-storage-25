"""Download and parse the Proxifly free proxy list."""
from __future__ import annotations

import re
from typing import Any

import requests
from rich.console import Console

_console = Console(stderr=True)

PROXIFLY_URL = "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/all/data.json"

# Text-format fallback sources — return IP:PORT lines (one per line), SOCKS5 only.
# spys.me lines have format "IP:PORT CC" (country after space) — handled by the regex below.
_TEXT_SOURCES = [
    "https://spys.me/socks.txt",                                                                        # spys.one official .txt — updated hourly
    "https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks5/data.txt",     # proxifly SOCKS5 only
    "https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5&timeout=10000&country=all",    # proxyscrape
]

_BLOCKED_ANONYMITY = {"transparent"}

# Matches IP:PORT at the START of a line (trailing country/comment is ignored).
# Handles both "1.2.3.4:1080" and "1.2.3.4:1080 US" (spys.me format).
_IP_PORT_RE = re.compile(r"^(\d{1,3}(?:\.\d{1,3}){3}):(\d{2,5})")

# spys.me lines: "1.2.3.4:1080 US" — optional 2-letter country after the port.
_SPYSME_CC_RE = re.compile(r"^[\d.]+:\d+\s+([A-Z]{2})\b")


def _make_session_proxies(socks_port: int | None) -> dict | None:
    if socks_port is not None:
        return {
            "http": f"socks5h://127.0.0.1:{socks_port}",
            "https": f"socks5h://127.0.0.1:{socks_port}",
        }
    return None


def fetch_proxies(url: str = PROXIFLY_URL, socks_port: int | None = None) -> list[dict[str, Any]]:
    """Download the Proxifly JSON proxy list and return SOCKS5 entries.

    Filters to protocol == "socks5" (or "type" == "socks5") and excludes
    "transparent" anonymity proxies.  All other anonymity levels are accepted
    to avoid returning 0 when the source only tags proxies as e.g. "anonymous".

    Returns a list of dicts with keys: protocol, ip, port, country, anonymity.

    Args:
        socks_port: If provided, route the fetch through socks5h://127.0.0.1:{socks_port}.
                    Required after kill switch is active (direct traffic is blocked).
    """
    req_proxies = _make_session_proxies(socks_port)
    try:
        _console.print(f"[cyan]Fetching proxy list from {url}…[/cyan]")
        response = requests.get(url, timeout=15, proxies=req_proxies)
        response.raise_for_status()
        raw: list[dict] = response.json()
    except requests.exceptions.ConnectionError as exc:
        _console.print(f"[red]Network error fetching proxies:[/red] {exc}")
        return []
    except requests.exceptions.Timeout:
        _console.print("[red]Timeout fetching proxy list.[/red]")
        return []
    except requests.exceptions.HTTPError as exc:
        _console.print(f"[red]HTTP error fetching proxy list:[/red] {exc}")
        return []
    except ValueError as exc:
        _console.print(f"[red]Failed to parse proxy list JSON:[/red] {exc}")
        return []

    results: list[dict[str, Any]] = []
    for entry in raw:
        # Accept both "protocol" and "type" field names (different source formats)
        protocol = str(entry.get("protocol") or entry.get("type") or "").lower()
        anonymity = str(entry.get("anonymity", "")).lower()
        if protocol != "socks5":
            continue
        if anonymity in _BLOCKED_ANONYMITY:
            continue
        results.append(
            {
                "protocol": "socks5",
                "ip": str(entry.get("ip", "")),
                "port": int(entry.get("port", 0)),
                "country": str(entry.get("country", "")),
                "anonymity": anonymity or "unknown",
            }
        )

    _console.print(f"[green]Found {len(results)} SOCKS5 proxies from JSON source.[/green]")
    return results


def fetch_proxies_text(socks_port: int | None = None) -> list[dict[str, Any]]:
    """Fetch SOCKS5 proxies from text-format sources (IP:PORT per line).

    Tries multiple sources in order, returns combined deduplicated list.
    All entries are tagged protocol=socks5, anonymity=unknown.

    Args:
        socks_port: Route fetch through Tor SOCKS5 if kill switch is active.
    """
    req_proxies = _make_session_proxies(socks_port)
    seen: set[str] = set()
    results: list[dict[str, Any]] = []

    for url in _TEXT_SOURCES:
        try:
            _console.print(f"[cyan]Fetching text proxy list from {url}…[/cyan]")
            response = requests.get(url, timeout=15, proxies=req_proxies)
            response.raise_for_status()
            for line in response.text.splitlines():
                line = line.strip()
                m = _IP_PORT_RE.match(line)
                if not m:
                    continue
                ip, port_str = m.group(1), m.group(2)
                key = f"{ip}:{port_str}"
                if key in seen:
                    continue
                seen.add(key)
                # Extract country if present (e.g. spys.me "1.2.3.4:1080 US")
                cc_match = _SPYSME_CC_RE.match(line)
                country = cc_match.group(1) if cc_match else ""
                results.append({
                    "protocol": "socks5",
                    "ip": ip,
                    "port": int(port_str),
                    "country": country,
                    "anonymity": "unknown",
                })
        except Exception as exc:
            _console.print(f"[yellow]Text source {url} failed:[/yellow] {exc}")

    _console.print(f"[green]Found {len(results)} SOCKS5 proxies from text sources.[/green]")
    return results
