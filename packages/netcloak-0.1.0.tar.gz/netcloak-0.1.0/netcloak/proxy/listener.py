"""Local SOCKS5 proxy listener that forwards connections through ProxyPool.

Socks5Listener accepts SOCKS5 CONNECT requests on 127.0.0.1:{port} and
forwards each connection through an upstream proxy selected from ProxyPool
using weighted selection and circuit-breaker logic.

Implementation follows RFC 1928 no-auth SOCKS5 handshake and runs the
asyncio event loop in a dedicated daemon thread so engine.start() returns
after setup (same pattern as ProxyPool health thread).

Security:
- Binds to 127.0.0.1 only — never 0.0.0.0 (T-3-01)
- Full handler wrapped in try/except with 10s handshake timeout (T-3-02, T-3-05)
- Unsupported SOCKS5 commands rejected with 0x07 (T-3-05)
- Errors logged at DEBUG level only, no internal state leaked (T-3-04)
"""
from __future__ import annotations

import asyncio
import logging
import socket
import threading
from typing import TYPE_CHECKING

from python_socks import ProxyType

if TYPE_CHECKING:
    from netcloak.proxy.pool import ProxyPool

logger = logging.getLogger(__name__)

# SOCKS5 reply codes
_REP_SUCCESS = b"\x05\x00\x00\x01\x00\x00\x00\x00\x00\x00"
_REP_GENERAL_FAILURE = b"\x05\x01\x00\x01\x00\x00\x00\x00\x00\x00"
_REP_CMD_NOT_SUPPORTED = b"\x05\x07\x00\x01\x00\x00\x00\x00\x00\x00"
_REP_ADDR_NOT_SUPPORTED = b"\x05\x08\x00\x01\x00\x00\x00\x00\x00\x00"


class Socks5Listener:
    """Local SOCKS5 proxy listener with per-connection ProxyPool selection.

    Runs an asyncio SOCKS5 server in a daemon thread. Each accepted connection
    calls ProxyPool.get_proxy() to select an upstream proxy with weighted
    selection and circuit-breaker logic, then relays traffic bidirectionally.

    Usage::

        listener = Socks5Listener(pool=proxy_pool, port=8080)
        listener.start()
        # ... engine running ...
        listener.stop()
    """

    def __init__(
        self,
        pool: "ProxyPool",
        port: int = 8080,
        host: str = "127.0.0.1",
    ) -> None:
        """Initialize the listener.

        Args:
            pool: ProxyPool to select upstream proxies from.
            port: Local port to bind to (default 8080).
            host: Local address to bind to. Must be 127.0.0.1 (loopback).
                  Binding to 0.0.0.0 or empty string is rejected (T-3-01).

        Raises:
            ValueError: If host is not a loopback address.
        """
        if host not in ("127.0.0.1", "::1"):
            raise ValueError(
                f"Socks5Listener must bind to loopback only, got host={host!r}. "
                "Binding to non-loopback addresses would expose an unauthenticated "
                "SOCKS5 proxy to the network."
            )
        self._pool = pool
        self._port = port
        self._host = host
        self._server: asyncio.Server | None = None
        self._thread: threading.Thread | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._stop_event = threading.Event()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start the SOCKS5 listener in a daemon thread."""
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run_loop,
            daemon=True,
            name="socks5-listener",
        )
        self._thread.start()

    def stop(self) -> None:
        """Signal the listener to stop and wait for the thread to exit (max 5s)."""
        self._stop_event.set()
        loop = self._loop
        server = self._server
        if loop is not None and not loop.is_closed():
            if server is not None:
                loop.call_soon_threadsafe(server.close)
            loop.call_soon_threadsafe(loop.stop)
        if self._thread is not None:
            self._thread.join(timeout=5)

    def is_alive(self) -> bool:
        """Return True if the listener thread is running."""
        return self._thread is not None and self._thread.is_alive()

    # ------------------------------------------------------------------
    # Internal: event loop lifecycle
    # ------------------------------------------------------------------

    def _run_loop(self) -> None:
        """Run the asyncio event loop in this daemon thread."""
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._serve())
        except RuntimeError as exc:
            # Expected on Windows (IOCP) when loop.stop() is called while
            # serve_forever() is running — not an error condition.
            if "Event loop stopped before Future completed" not in str(exc):
                logger.debug("Listener loop RuntimeError: %s", exc)
        except Exception as exc:
            logger.debug("Listener loop error: %s", exc)
        finally:
            self._loop.close()

    async def _serve(self) -> None:
        """Start the asyncio server and run until stopped."""
        self._server = await asyncio.start_server(
            self._handle_connection,
            host=self._host,
            port=self._port,
        )
        async with self._server:
            await self._server.serve_forever()

    # ------------------------------------------------------------------
    # Internal: SOCKS5 connection handler
    # ------------------------------------------------------------------

    async def _handle_connection(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        """Handle a single SOCKS5 client connection (RFC 1928 no-auth).

        Security: T-3-02 — entire handler is wrapped in try/except.
        Handshake reads are bounded by a 10s timeout to prevent slowloris.
        Errors logged at DEBUG level only (T-3-04).
        """
        proxy_url: str | None = None
        r_writer: asyncio.StreamWriter | None = None
        try:
            # --- Step 1: Greeting ---
            header = await asyncio.wait_for(reader.readexactly(2), timeout=10)
            if header[0] != 5:
                logger.debug("SOCKS5 greeting: wrong VER=%d, closing", header[0])
                return
            nmethods = header[1]
            await reader.readexactly(nmethods)  # discard method list
            writer.write(b"\x05\x00")           # METHOD=0 (no auth)
            await writer.drain()

            # --- Step 2: Connection request ---
            req = await asyncio.wait_for(reader.readexactly(4), timeout=10)
            cmd = req[1]
            if cmd != 0x01:
                # T-3-05: Reject BIND (0x02) and UDP ASSOCIATE (0x03)
                writer.write(_REP_CMD_NOT_SUPPORTED)
                await writer.drain()
                logger.debug("SOCKS5: CMD=0x%02x not supported, rejecting", cmd)
                return

            atyp = req[3]
            if atyp == 0x01:   # IPv4
                addr_bytes = await reader.readexactly(4)
                dest_host = socket.inet_ntoa(addr_bytes)
            elif atyp == 0x03:  # Domain name
                n = (await reader.readexactly(1))[0]
                dest_host = (await reader.readexactly(n)).decode()
            elif atyp == 0x04:  # IPv6
                addr_bytes = await reader.readexactly(16)
                dest_host = socket.inet_ntop(socket.AF_INET6, addr_bytes)
            else:
                writer.write(_REP_ADDR_NOT_SUPPORTED)
                await writer.drain()
                logger.debug("SOCKS5: unsupported ATYP=0x%02x", atyp)
                return

            port_bytes = await reader.readexactly(2)
            dest_port = int.from_bytes(port_bytes, "big")

            # --- Step 3: Select upstream proxy ---
            proxy_url = self._pool.get_proxy()
            if proxy_url is None:
                writer.write(_REP_GENERAL_FAILURE)
                await writer.drain()
                logger.debug("SOCKS5: pool empty or all quarantined, replying 0x01")
                return

            # --- Step 4: Connect through upstream ---
            sock = await self._connect_upstream(proxy_url, dest_host, dest_port)
            writer.write(_REP_SUCCESS)
            await writer.drain()

            # --- Step 5: Bidirectional relay ---
            r_reader, r_writer = await asyncio.open_connection(sock=sock)
            relay_results = await asyncio.gather(
                self._relay(reader, r_writer),
                self._relay(r_reader, writer),
                return_exceptions=True,
            )
            # Only report success if relay completed without hard failures.
            # "success" means the upstream accepted and relayed traffic, not
            # merely that it accepted the connection.
            if not any(isinstance(r, Exception) for r in relay_results):
                self._pool.report_success(proxy_url)

        except Exception as exc:
            if proxy_url is not None:
                self._pool.report_failure(proxy_url)
            logger.debug("SOCKS5 handler error: %s", exc)
        finally:
            try:
                writer.close()
            except Exception:
                pass
            if r_writer is not None:
                try:
                    r_writer.close()
                except Exception:
                    pass

    # ------------------------------------------------------------------
    # Internal: upstream connection and relay
    # ------------------------------------------------------------------

    async def _connect_upstream(
        self,
        proxy_url: str,
        dest_host: str,
        dest_port: int,
    ) -> socket.socket:
        """Connect to dest_host:dest_port through the given proxy URL.

        CRITICAL: python_socks does not support the socks5h:// scheme.
        Parse URL manually and use Proxy(proxy_type=..., rdns=...) instead
        of Proxy.from_url() to avoid ValueError.
        """
        from python_socks.async_.asyncio import Proxy

        proxy_type, p_host, p_port, rdns = self._parse_proxy_url(proxy_url)
        proxy = Proxy(
            proxy_type=proxy_type,
            host=p_host,
            port=p_port,
            rdns=rdns,
        )
        return await asyncio.wait_for(
            proxy.connect(dest_host=dest_host, dest_port=dest_port),
            timeout=15,
        )

    @staticmethod
    def _parse_proxy_url(url: str) -> tuple[ProxyType, str, int, bool]:
        """Parse a socks5:// or socks5h:// proxy URL.

        Returns:
            (proxy_type, host, port, rdns)
            rdns=True for socks5h:// (remote DNS resolution via proxy)
            rdns=False for socks5:// (local DNS resolution)

        Note: python_socks does not accept socks5h:// in Proxy.from_url().
              This method avoids that by parsing manually.
        """
        rdns = url.startswith("socks5h://")
        loc = url.split("://", 1)[1]
        p_host, p_port_str = loc.rsplit(":", 1)
        return ProxyType.SOCKS5, p_host, int(p_port_str), rdns

    @staticmethod
    async def _relay(src: asyncio.StreamReader, dst: asyncio.StreamWriter) -> None:
        """Relay data from src to dst until EOF or connection error."""
        try:
            while True:
                data = await src.read(65536)
                if not data:
                    break
                dst.write(data)
                await dst.drain()
        except (asyncio.CancelledError, ConnectionError, OSError):
            pass
        except Exception as exc:
            logger.debug("Unexpected relay error: %s", type(exc).__name__)


__all__ = ["Socks5Listener"]
