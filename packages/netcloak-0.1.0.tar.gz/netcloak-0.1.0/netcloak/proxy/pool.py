"""Weighted proxy pool with circuit breaker and background health monitoring.

Provides ProxyPool class that manages a list of validated SOCKS5 proxies
with weighted random selection (faster proxies preferred) and automatic
quarantine of failing proxies (3 consecutive failures = 60s quarantine).
"""
from __future__ import annotations

import asyncio
import logging
import random
import threading
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ValidatedProxy:
    """A validated SOCKS5 proxy with latency and circuit-breaker state."""

    url: str
    latency_ms: float
    validated_at: float
    failures: int = 0
    quarantine_until: float = 0.0


class ProxyPool:
    """Weighted proxy pool with circuit breaker and background health monitoring."""

    _QUARANTINE_SECONDS = 60
    _FAILURE_THRESHOLD = 3
    _HEALTH_INTERVAL = 300
    _MIN_POOL_SIZE = 5

    def __init__(self, proxies: list[ValidatedProxy], auto_replenish: bool = True) -> None:
        self._proxies: list[ValidatedProxy] = list(proxies)
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._health_thread: threading.Thread | None = None

        if auto_replenish:
            self._health_thread = threading.Thread(
                target=self._health_loop,
                daemon=True,
                name="proxy-pool-health",
            )
            self._health_thread.start()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_proxy(self) -> str | None:
        """Return a weighted-random proxy URL, skipping quarantined proxies."""
        with self._lock:
            now = time.monotonic()
            available = [p for p in self._proxies if p.quarantine_until < now]
            if not available:
                return None
            weights = [max(1.0, 100.0 - p.latency_ms / 100.0) for p in available]
            chosen = random.choices(available, weights=weights, k=1)[0]
            return chosen.url

    def report_failure(self, url: str) -> None:
        """Increment failure count; quarantine after threshold."""
        with self._lock:
            for proxy in self._proxies:
                if proxy.url == url:
                    proxy.failures += 1
                    if proxy.failures >= self._FAILURE_THRESHOLD:
                        proxy.quarantine_until = time.monotonic() + self._QUARANTINE_SECONDS
                        logger.debug("Proxy %s quarantined for %ds", url, self._QUARANTINE_SECONDS)
                    break

    def report_success(self, url: str) -> None:
        """Reset failure count and quarantine for a proxy."""
        with self._lock:
            for proxy in self._proxies:
                if proxy.url == url:
                    proxy.failures = 0
                    proxy.quarantine_until = 0.0
                    break

    def get_stats(self) -> dict[str, Any]:
        """Return pool statistics."""
        with self._lock:
            now = time.monotonic()
            quarantined = [p for p in self._proxies if p.quarantine_until >= now]
            available = [p for p in self._proxies if p.quarantine_until < now]
            return {
                "pool_size": len(self._proxies),
                "available": len(available),
                "quarantined": len(quarantined),
            }

    def stop(self) -> None:
        """Stop background health thread."""
        self._stop_event.set()
        if self._health_thread and self._health_thread.is_alive():
            self._health_thread.join(timeout=2)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _health_loop(self) -> None:
        """Daemon health thread: re-validate every 5 min, replenish if pool < 5."""
        while not self._stop_event.wait(timeout=self._HEALTH_INTERVAL):
            try:
                with self._lock:
                    urls = [p.url for p in self._proxies]

                refreshed = asyncio.run(validate_async(urls))

                with self._lock:
                    self._proxies = refreshed

                if len(refreshed) < self._MIN_POOL_SIZE:
                    logger.info("Pool below minimum (%d), replenishing from scraper", len(refreshed))
                    from netcloak.proxy.scraper import scrape_proxies
                    new_urls = scrape_proxies()
                    new_validated = asyncio.run(validate_async(new_urls))
                    with self._lock:
                        existing = {p.url for p in self._proxies}
                        for p in new_validated:
                            if p.url not in existing:
                                self._proxies.append(p)
            except Exception as exc:
                logger.debug("Health loop error: %s", exc)


# ------------------------------------------------------------------
# Async validator (module-level)
# ------------------------------------------------------------------

async def _validate_one(url: str, semaphore: asyncio.Semaphore) -> ValidatedProxy | None:
    """Validate a single proxy via python-socks async SOCKS5 connect to httpbin.org:80."""
    from python_socks.async_.asyncio import Proxy
    async with semaphore:
        proxy = Proxy.from_url(url)
        t0 = time.monotonic()
        try:
            async with asyncio.timeout(8):
                sock = await proxy.connect(dest_host="httpbin.org", dest_port=80)
                sock.close()
            latency_ms = (time.monotonic() - t0) * 1000
            if latency_ms > 8000:
                return None
            return ValidatedProxy(url=url, latency_ms=latency_ms, validated_at=time.monotonic())
        except Exception as exc:
            logger.debug("Proxy %s validation failed: %s", url, exc)
            return None


async def validate_async(urls: list[str]) -> list[ValidatedProxy]:
    """Validate proxies concurrently (max 50). Return top 20 by latency."""
    semaphore = asyncio.Semaphore(50)
    tasks = [_validate_one(url, semaphore) for url in urls]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    valid = [r for r in results if isinstance(r, ValidatedProxy)]
    return sorted(valid, key=lambda x: x.latency_ms)[:20]


def validate_proxies(urls: list[str]) -> list[ValidatedProxy]:
    """Synchronous wrapper for validate_async."""
    return asyncio.run(validate_async(urls))


__all__ = ["ProxyPool", "ValidatedProxy", "validate_proxies", "validate_async"]
