"""Async multi-source SOCKS5 proxy scraper.

Fetches proxy lists from 4 sources concurrently using aiohttp,
parses IP:PORT lines, deduplicates, and returns socks5h:// URLs.

Provides both async (scrape_all) and sync (scrape_proxies) entry points.
Disk cache at %APPDATA%/netcloak/proxy_cache.json with 30-min TTL.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import sys
import time
from pathlib import Path

import aiohttp

_SOURCES = [
    "https://api.proxyscrape.com/?request=getproxies&proxytype=socks5&country=all",
    "https://www.proxy-list.download/api/v1/get?type=socks5",
    "https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks5/data.txt",
    "https://api.proxyscrape.com/?request=getproxies&proxytype=http&country=all",
]
_IP_PORT_RE = re.compile(r"^(\d{1,3}(?:\.\d{1,3}){3}):(\d{2,5})$")
_CACHE_TTL = 30 * 60  # 30 minutes


async def _fetch_one(session: aiohttp.ClientSession, url: str) -> list[str]:
    """Fetch one source with 10s timeout, parse IP:PORT lines, return socks5h:// URLs."""
    try:
        async with asyncio.timeout(10):
            async with session.get(url) as resp:
                text = await resp.text()
        proxies: list[str] = []
        for line in text.splitlines():
            line = line.strip()
            if _IP_PORT_RE.match(line):
                proxies.append(f"socks5h://{line}")
        return proxies
    except Exception:
        return []


async def scrape_all() -> list[str]:
    """Fetch all 4 sources concurrently, deduplicate, return socks5h:// URLs."""
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15)) as session:
        tasks = [_fetch_one(session, url) for url in _SOURCES]
        results = await asyncio.gather(*tasks, return_exceptions=True)

    seen: set[str] = set()
    ordered: list[str] = []
    for result in results:
        if isinstance(result, list):
            for proxy in result:
                if proxy not in seen:
                    seen.add(proxy)
                    ordered.append(proxy)
    return ordered


def scrape_proxies() -> list[str]:
    """Synchronous wrapper: return asyncio.run(scrape_all())."""
    return asyncio.run(scrape_all())


def _cache_path() -> Path:
    """Return platform-appropriate cache file path."""
    if sys.platform == "win32":
        appdata = os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming")
        return Path(appdata) / "netcloak" / "proxy_cache.json"
    return Path("/var/lib/netcloak/proxy_cache.json")


def scrape_proxies_cached() -> list[str]:
    """Return cached proxy list if fresh; otherwise fetch, cache, and return."""
    path = _cache_path()
    if path.exists():
        try:
            data = json.loads(path.read_text())
            age = time.time() - data.get("timestamp", 0)
            if age < _CACHE_TTL:
                return data.get("proxies", [])
        except Exception:
            pass

    proxies = scrape_proxies()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"timestamp": time.time(), "proxies": proxies}))
    except Exception:
        pass
    return proxies


__all__ = ["scrape_proxies", "scrape_all", "scrape_proxies_cached"]
