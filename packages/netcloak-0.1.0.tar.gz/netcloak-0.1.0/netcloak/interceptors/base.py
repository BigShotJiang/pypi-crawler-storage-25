"""TrafficInterceptor ABC — defines the interface for OS-level traffic interception.

Contract:
    deactivate() MUST be called in a finally block by the caller to ensure
    OS state is restored even if an exception occurs during active operation.

Example::

    interceptor = WindowsInterceptor()
    interceptor.activate()
    try:
        run_protected_session()
    finally:
        interceptor.deactivate()
"""
from __future__ import annotations

from abc import ABC, abstractmethod


class TrafficInterceptor(ABC):
    """Abstract base for OS-level traffic interception.

    Implementations redirect system traffic through a proxy/Tor by modifying
    OS-level settings (registry, iptables, networksetup). Each implementation
    is responsible for restoring all OS changes when deactivate() is called.
    """

    @abstractmethod
    def activate(self) -> None:
        """Apply OS-level proxy/DNS/routing changes to redirect system traffic.

        Must be idempotent — calling activate() when already active should
        not cause duplicate settings or resource leaks.
        """

    @abstractmethod
    def deactivate(self) -> None:
        """Restore all OS-level changes made by activate().

        MUST be called in a finally block by the caller to guarantee cleanup.
        Must be safe to call even if activate() failed partway through.
        """

    @abstractmethod
    def is_active(self) -> bool:
        """Return True if this interceptor is currently active."""
