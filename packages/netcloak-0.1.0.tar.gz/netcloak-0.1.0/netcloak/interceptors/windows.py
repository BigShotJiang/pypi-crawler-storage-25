"""Windows traffic interceptor — system proxy via winreg + DNS via TorDNSRedirect.

Sets the system-wide SOCKS5 proxy in HKCU Internet Settings and delegates
DNS redirection to TorDNSRedirect (UDP relay on 127.0.0.1:53 → Tor DNSPort).

All subprocess calls use list form. No shell=True. No bare except.
Requires Administrator privileges on Windows.
"""
from __future__ import annotations

import subprocess
import sys
from typing import TYPE_CHECKING

from rich.console import Console

from netcloak.interceptors.base import TrafficInterceptor

if TYPE_CHECKING:
    from netcloak.routing.dns_tor import TorDNSRedirect as _TorDNSRedirectType

_console = Console(stderr=True)

_PROXY_KEY = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"


def _get_connected_adapters() -> list[str]:
    """Return names of Connected network adapters from netsh."""
    result = subprocess.run(
        ["netsh", "interface", "show", "interface"],
        capture_output=True, text=True, check=False,
    )
    adapters = []
    for line in result.stdout.splitlines():
        if "Connected" in line and "Enabled" in line:
            parts = line.split()
            if len(parts) >= 4:
                adapters.append(" ".join(parts[3:]))
    return adapters


class WindowsInterceptor(TrafficInterceptor):
    """Windows system proxy + DNS interceptor.

    Activates:
      1. HKCU registry ProxyEnable=1, ProxyServer="socks=<addr>"
      2. _broadcast_settings_change() so running apps pick up the proxy
      3. TorDNSRedirect.start() — UDP relay 127.0.0.1:53 → Tor DNSPort
      4. mark_dns_redirected() coordination flag
      5. IPv6 DNS → ::1 on all Connected adapters (disables IPv6 DNS path)
      6. ipconfig /flushdns — clear cached non-Tor DNS entries
    """

    def __init__(self, socks_port: int = 9050, dns_port: int = 9053) -> None:
        self._proxy_addr = f"127.0.0.1:{socks_port}"
        self._dns_port = dns_port
        self._dns_redirect: "_TorDNSRedirectType | None" = None
        self._active: bool = False

    def activate(self) -> None:
        """Apply Windows system proxy + DNS redirection."""
        # 1. Set registry proxy
        self._set_registry_proxy(enable=True)

        # 2. Broadcast so running processes pick up the change
        from netcloak.routing.windows_routing import _broadcast_settings_change
        _broadcast_settings_change()

        # 3. Start DNS relay — exact pattern from windows_routing._route_via_system_proxy()
        from netcloak.routing.dns_tor import TorDNSRedirect
        from netcloak.routing.dns import mark_dns_redirected
        self._dns_redirect = TorDNSRedirect(dns_port=self._dns_port)
        if self._dns_redirect.start():
            mark_dns_redirected()
        else:
            _console.print("[yellow]DNS redirect could not start — DNS may leak.[/yellow]")
            self._dns_redirect = None

        # 4. Set IPv6 DNS to ::1 on all Connected adapters (disables IPv6 DNS leak path)
        self._set_ipv6_dns_loopback()

        # 5. Flush DNS cache
        subprocess.run(
            ["ipconfig", "/flushdns"],
            capture_output=True, check=False,
        )

        self._active = True

    def deactivate(self) -> None:
        """Restore Windows system proxy and DNS settings."""
        # 1. Stop DNS relay (internally restores adapter DNS)
        if self._dns_redirect is not None:
            self._dns_redirect.stop()
            self._dns_redirect = None

        # 2. Clear coordination flag
        from netcloak.routing.dns import clear_dns_redirected
        clear_dns_redirected()

        # 3. Disable registry proxy
        self._set_registry_proxy(enable=False)

        # 4. Broadcast proxy change
        from netcloak.routing.windows_routing import _broadcast_settings_change
        _broadcast_settings_change()

        self._active = False

    def is_active(self) -> bool:
        """Return True if this interceptor is currently active."""
        return self._active

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _set_registry_proxy(self, enable: bool) -> None:
        """Write or clear HKCU Internet Settings proxy entries."""
        if sys.platform != "win32":
            # Guard: only execute on Windows; silently skip on other platforms
            return
        try:
            import winreg
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER, _PROXY_KEY, 0, winreg.KEY_SET_VALUE
            ) as key:
                if enable:
                    winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 1)
                    winreg.SetValueEx(
                        key, "ProxyServer", 0, winreg.REG_SZ,
                        f"socks={self._proxy_addr}",
                    )
                else:
                    winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 0)
                    try:
                        winreg.DeleteValue(key, "ProxyServer")
                    except FileNotFoundError:
                        pass  # ProxyServer key may not exist
        except Exception as exc:
            _console.print(f"[yellow]Registry proxy update failed:[/yellow] {exc}")

    def _set_ipv6_dns_loopback(self) -> None:
        """Set IPv6 DNS to ::1 on all Connected adapters.

        This disables the IPv6 DNS path by routing any IPv6 DNS queries to
        loopback, preventing DNS leaks over IPv6 while NetCloak is active.
        """
        adapters = _get_connected_adapters()
        for adapter in adapters:
            subprocess.run(
                [
                    "netsh", "interface", "ipv6", "set", "dnsservers",
                    f"name={adapter}", "static", "::1",
                ],
                capture_output=True, check=False,
            )
