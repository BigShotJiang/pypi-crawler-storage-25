"""macOS traffic interceptor — networksetup SOCKS proxy + DNS per-service.

Uses networksetup to enumerate all network services and configure each with
a SOCKS proxy and DNS override. Saves original settings for restoration.

All subprocess calls use list form. No shell=True. No bare except.
"""
from __future__ import annotations

import subprocess
from typing import Any

from rich.console import Console

from netcloak.interceptors.base import TrafficInterceptor

_console = Console(stderr=True)


def _run(*args: str) -> subprocess.CompletedProcess:
    """Run a subprocess command (list form, never shell=True)."""
    return subprocess.run(list(args), capture_output=True, text=True, check=False)


class DarwinInterceptor(TrafficInterceptor):
    """macOS interceptor using networksetup for SOCKS proxy + DNS per service.

    Enumerates all network services via ``networksetup -listallnetworkservices``
    and configures each with a SOCKS5 proxy to 127.0.0.1:{socks_port} and
    DNS override to 127.0.0.1. Flushes DNS cache after activation.
    """

    def __init__(self, socks_port: int = 9050) -> None:
        self._socks_port = socks_port
        self._saved_settings: dict[str, dict[str, Any]] = {}
        self._active: bool = False

    def activate(self) -> None:
        """Apply SOCKS proxy and DNS override on all network services."""
        services = self._list_services()
        for service in services:
            # Save current SOCKS proxy settings
            socks_info = self._get_socks_proxy(service)
            dns_info = self._get_dns(service)
            self._saved_settings[service] = {
                "socks": socks_info,
                "dns": dns_info,
            }

            # Set SOCKS proxy
            _run(
                "networksetup", "-setsocksfirewallproxy",
                service, "127.0.0.1", str(self._socks_port),
            )
            _run("networksetup", "-setsocksfirewallproxystate", service, "on")

            # Set DNS to 127.0.0.1
            _run("networksetup", "-setdnsservers", service, "127.0.0.1")

        # Flush DNS cache
        _run("dscacheutil", "-flushcache")
        _run("killall", "-HUP", "mDNSResponder")

        self._active = True
        _console.print("[green]macOS interceptor active — SOCKS proxy and DNS configured.[/green]")

    def deactivate(self) -> None:
        """Restore saved SOCKS proxy and DNS settings on all services."""
        for service, settings in self._saved_settings.items():
            socks = settings.get("socks", {})
            dns = settings.get("dns", [])

            # Restore SOCKS proxy
            if socks.get("enabled"):
                _run(
                    "networksetup", "-setsocksfirewallproxy",
                    service, socks.get("host", ""), str(socks.get("port", "")),
                )
                _run("networksetup", "-setsocksfirewallproxystate", service, "on")
            else:
                _run("networksetup", "-setsocksfirewallproxystate", service, "off")

            # Restore DNS (empty string = DHCP)
            if dns:
                _run("networksetup", "-setdnsservers", service, *dns)
            else:
                _run("networksetup", "-setdnsservers", service, "empty")

        self._saved_settings.clear()
        self._active = False
        _console.print("[green]macOS interceptor deactivated — network settings restored.[/green]")

    def is_active(self) -> bool:
        """Return True if this interceptor is currently active."""
        return self._active

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _list_services(self) -> list[str]:
        """Return all network service names from networksetup."""
        result = _run("networksetup", "-listallnetworkservices")
        lines = result.stdout.strip().splitlines()
        # First line is a header "An asterisk (*) denotes that a network service is disabled."
        return [
            line.lstrip("* ").strip()
            for line in lines[1:]
            if line.strip() and not line.startswith("An asterisk")
        ]

    def _get_socks_proxy(self, service: str) -> dict[str, Any]:
        """Return current SOCKS proxy settings for a service."""
        result = _run("networksetup", "-getsocksfirewallproxy", service)
        info: dict[str, Any] = {"enabled": False, "host": "", "port": 0}
        for line in result.stdout.splitlines():
            low = line.lower()
            if "enabled: yes" in low:
                info["enabled"] = True
            elif "server:" in low:
                info["host"] = line.split(":", 1)[-1].strip()
            elif "port:" in low:
                try:
                    info["port"] = int(line.split(":", 1)[-1].strip())
                except ValueError:
                    pass
        return info

    def _get_dns(self, service: str) -> list[str]:
        """Return current DNS servers for a service, empty list = DHCP."""
        result = _run("networksetup", "-getdnsservers", service)
        output = result.stdout.strip()
        if "There aren't any DNS Servers" in output or not output:
            return []
        return [line.strip() for line in output.splitlines() if line.strip()]
