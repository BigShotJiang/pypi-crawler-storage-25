"""Linux traffic interceptor — iptables transparent proxy + resolv.conf lockdown.

Applies iptables NAT rules to redirect all TCP and DNS traffic through Tor's
TransPort and DNSPort. Disables IPv6 to prevent leaks. Backs up and rewrites
resolv.conf.

All subprocess calls use list form. No shell=True. No bare except.
Requires root privileges (os.geteuid() == 0).
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

from rich.console import Console

from netcloak.interceptors.base import TrafficInterceptor

_console = Console(stderr=True)

_RESOLV_CONF = Path("/etc/resolv.conf")
_RESOLV_BACKUP = Path("/tmp/netcloak_resolv_backup_interceptor")
_NETCLOAK_COMMENT = "netcloak-interceptor"

# LAN address ranges that must not be intercepted (RFC 1918 + loopback)
_LAN_RANGES = ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "127.0.0.0/8")


def _run(*args: str, check: bool = False) -> subprocess.CompletedProcess:
    """Run a subprocess command (list form, never shell=True)."""
    return subprocess.run(list(args), capture_output=True, text=True, check=check)


class LinuxInterceptor(TrafficInterceptor):
    """Linux iptables transparent proxy interceptor.

    Redirects all DNS (UDP :53) to Tor's DNSPort and all TCP traffic to
    Tor's TransPort, while exempting the Tor process itself and LAN ranges.
    """

    def __init__(
        self,
        socks_port: int = 9050,
        dns_port: int = 5353,
        trans_port: int = 9040,
    ) -> None:
        self._socks_port = socks_port
        self._dns_port = dns_port
        self._trans_port = trans_port
        self._active: bool = False

    def activate(self) -> None:
        """Apply iptables rules, disable IPv6, rewrite resolv.conf."""
        if sys.platform != "win32":
            self._require_root()

        # Get Tor UID (fallback to current user if debian-tor not found)
        tor_uid = self._get_tor_uid()

        # Apply iptables NAT rules
        self._apply_iptables_rules(tor_uid)

        # Disable IPv6
        _run("sysctl", "-w", "net.ipv6.conf.all.disable_ipv6=1")

        # Backup and rewrite resolv.conf
        if _RESOLV_CONF.exists():
            shutil.copy2(str(_RESOLV_CONF), str(_RESOLV_BACKUP))
        _RESOLV_CONF.write_text("nameserver 127.0.0.1\n")

        self._active = True
        _console.print("[green]Linux interceptor active — all traffic routed through Tor.[/green]")

    def deactivate(self) -> None:
        """Flush netcloak-tagged iptables rules, re-enable IPv6, restore resolv.conf."""
        # Flush only rules we added (by comment tag — never iptables -F)
        self._flush_netcloak_rules()

        # Re-enable IPv6
        _run("sysctl", "-w", "net.ipv6.conf.all.disable_ipv6=0")

        # Restore resolv.conf from backup
        if _RESOLV_BACKUP.exists():
            shutil.copy2(str(_RESOLV_BACKUP), str(_RESOLV_CONF))
            try:
                _RESOLV_BACKUP.unlink(missing_ok=True)
            except TypeError:
                # Python < 3.8 compat: missing_ok not supported
                if _RESOLV_BACKUP.exists():
                    _RESOLV_BACKUP.unlink()
        else:
            _console.print("[yellow]No resolv.conf backup found; leaving current file intact.[/yellow]")

        self._active = False
        _console.print("[green]Linux interceptor deactivated — network settings restored.[/green]")

    def is_active(self) -> bool:
        """Return True if this interceptor is currently active."""
        return self._active

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _require_root(self) -> None:
        if os.geteuid() != 0:
            raise PermissionError(
                "NetCloak Linux interceptor requires root privileges. Run with sudo."
            )

    def _get_tor_uid(self) -> int:
        """Return the Tor process UID. Falls back to current user UID."""
        try:
            import pwd  # Unix-only; not available on Windows
            return pwd.getpwnam("debian-tor").pw_uid
        except (KeyError, ImportError, AttributeError):
            # KeyError: debian-tor user not found
            # ImportError: pwd not available (Windows)
            # AttributeError: mock or stub environment
            try:
                return os.getuid()
            except AttributeError:
                return 0  # Fallback for non-Unix environments (tests)

    def _apply_iptables_rules(self, tor_uid: int) -> None:
        """Apply iptables NAT rules for transparent proxy."""
        # --- nat table: DNS redirect ---
        # Redirect UDP port 53 to Tor DNSPort (skip Tor's own traffic)
        _run(
            "iptables", "-t", "nat", "-A", "OUTPUT",
            "!", "-o", "lo",
            "-p", "udp", "--dport", "53",
            "-m", "owner", "!", "--uid-owner", str(tor_uid),
            "-j", "REDIRECT", "--to-ports", str(self._dns_port),
            "-m", "comment", "--comment", _NETCLOAK_COMMENT,
        )
        _run(
            "iptables", "-t", "nat", "-A", "OUTPUT",
            "!", "-o", "lo",
            "-p", "tcp", "--dport", "53",
            "-m", "owner", "!", "--uid-owner", str(tor_uid),
            "-j", "REDIRECT", "--to-ports", str(self._dns_port),
            "-m", "comment", "--comment", _NETCLOAK_COMMENT,
        )

        # --- nat table: TCP transparent proxy ---
        # Exempt Tor's own traffic
        _run(
            "iptables", "-t", "nat", "-A", "OUTPUT",
            "-m", "owner", "--uid-owner", str(tor_uid),
            "-j", "RETURN",
            "-m", "comment", "--comment", _NETCLOAK_COMMENT,
        )

        # Exempt LAN and loopback ranges
        for lan_range in _LAN_RANGES:
            _run(
                "iptables", "-t", "nat", "-A", "OUTPUT",
                "-d", lan_range,
                "-j", "RETURN",
                "-m", "comment", "--comment", _NETCLOAK_COMMENT,
            )

        # Redirect all remaining TCP SYN to TransPort
        _run(
            "iptables", "-t", "nat", "-A", "OUTPUT",
            "-p", "tcp", "--syn",
            "-j", "REDIRECT", "--to-ports", str(self._trans_port),
            "-m", "comment", "--comment", _NETCLOAK_COMMENT,
        )

        # --- filter table: drop INVALID packets ---
        _run(
            "iptables", "-A", "OUTPUT",
            "-m", "state", "--state", "INVALID",
            "-j", "DROP",
            "-m", "comment", "--comment", _NETCLOAK_COMMENT,
        )

    def _flush_netcloak_rules(self) -> None:
        """Remove only rules tagged with the netcloak-interceptor comment."""
        for table, chain in [("nat", "OUTPUT"), ("filter", "OUTPUT")]:
            try:
                if table == "filter":
                    list_cmd = ["iptables", "-L", chain, "--line-numbers", "-n"]
                    delete_cmd_prefix = ["iptables", "-D", chain]
                else:
                    list_cmd = ["iptables", "-t", table, "-L", chain, "--line-numbers", "-n"]
                    delete_cmd_prefix = ["iptables", "-t", table, "-D", chain]

                result = _run(*list_cmd)
                rule_nums = []
                for line in result.stdout.splitlines():
                    if _NETCLOAK_COMMENT in line:
                        parts = line.split()
                        if parts and parts[0].isdigit():
                            rule_nums.append(int(parts[0]))

                # Delete in reverse order so line numbers stay valid
                for num in sorted(rule_nums, reverse=True):
                    _run(*delete_cmd_prefix, str(num))
            except Exception as exc:
                _console.print(f"[yellow]iptables flush error ({table}/{chain}):[/yellow] {exc}")
