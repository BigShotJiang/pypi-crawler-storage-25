"""Traffic interceptor package — OS-level proxy/DNS/routing abstractions."""
from netcloak.interceptors.base import TrafficInterceptor

__all__ = ["TrafficInterceptor"]
