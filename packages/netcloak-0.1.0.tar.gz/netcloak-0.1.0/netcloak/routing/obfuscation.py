"""Traffic padding — application-level timing noise to mask usage patterns.

NOT a substitute for Tor's built-in obfuscation. This adds cover traffic
at the application layer to make traffic volume and timing less distinctive.
"""
from __future__ import annotations

import logging
import random
import threading
import time
from typing import Any

import requests

_log = logging.getLogger(__name__)

_SOCKS_HOST = "127.0.0.1"

_COVER_DOMAINS = [
    "www.google.com",
    "www.wikipedia.org",
    "www.reddit.com",
    "www.github.com",
    "www.cloudflare.com",
]


class TrafficPadder:
    """
    Sends cover traffic to mask real usage patterns.
    Runs as a background thread while NetCloak is active.
    NOT a substitute for Tor's built-in obfuscation —
    this adds application-level timing noise only.
    """

    def __init__(self, config: dict[str, Any]) -> None:
        obf_cfg = config.get("obfuscation", {})
        tor_cfg = config.get("tor", {})
        self.enabled: bool = obf_cfg.get("traffic_padding", False)
        self.interval_range: tuple[int, int] = (
            int(obf_cfg.get("padding_interval_min", 5)),
            int(obf_cfg.get("padding_interval_max", 30)),
        )
        self._socks_port: int = tor_cfg.get("socks_port", 9050)
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        """Launch background cover-traffic thread if enabled."""
        if not self.enabled:
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True, name="NetCloak-TrafficPadder")
        self._thread.start()
        _log.info("TrafficPadder started (interval %s–%ss)", *self.interval_range)

    def stop(self) -> None:
        """Signal the background thread to stop and wait for it."""
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=5)
            self._thread = None

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _run(self) -> None:
        proxies = {
            "http": f"socks5h://{_SOCKS_HOST}:{self._socks_port}",
            "https": f"socks5h://{_SOCKS_HOST}:{self._socks_port}",
        }
        while not self._stop_event.is_set():
            sleep_sec = random.uniform(*self.interval_range)
            # Sleep in short increments so stop() is responsive
            deadline = time.monotonic() + sleep_sec
            while time.monotonic() < deadline:
                if self._stop_event.is_set():
                    return
                time.sleep(min(1.0, deadline - time.monotonic()))

            domain = random.choice(_COVER_DOMAINS)
            try:
                requests.get(
                    f"https://{domain}",
                    proxies=proxies,
                    timeout=10,
                    stream=True,  # don't download the full body
                ).close()
                _log.debug("Cover request sent to %s", domain)
            except Exception as exc:
                _log.debug("Cover request to %s failed (non-fatal): %s", domain, exc)
