"""Windows routing backend — netsh advfirewall + winreg system proxy.

Kill switch strategy
--------------------
Uses Windows Filtering Platform (WFP) via ``netsh advfirewall``:
- Exports current firewall state as a .wfw backup before changes.
- Sets all-profiles policy to block inbound + outbound by default.
- Adds "NetCloak-*" named rules for loopback, Tor SOCKS5, and Tor ORPort.
- Windows Firewall is stateful by default — established connections are
  handled automatically.

Transparent proxy limitation
-----------------------------
Full transparent proxy on Windows requires a TUN adapter (e.g. Wintun) to
intercept all traffic at the network layer — this is flagged as a Phase 3+
enhancement. The current implementation sets the system-wide SOCKS5 proxy via
the registry (HKCU Internet Settings) and ``netsh winhttp``, which covers
browser and most application traffic that respects system proxy settings.
UDP traffic and apps that bypass system proxy settings are NOT covered.

All public methods require Administrator privileges.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
import ctypes
from typing import Any

from rich.console import Console

from netcloak.routing.base import BaseRouter

_console = Console(stderr=True)

_RULE_PREFIX = "NetCloak-"
_TOR_SOCKS_PORT = 9050
_TOR_OR_PORT = 9001

# All rule suffixes ever created — used for deterministic cleanup.
_RULE_SUFFIXES = ("Loopback", "Tor-SOCKS", "Tor-ORPort", "Tor-Process")

# Default data directory on Windows; expanded from env vars at runtime.
_DEFAULT_DATA_DIR = os.path.expandvars(r"%APPDATA%\NetCloak")


def _run(*args: str, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(list(args), check=check, capture_output=True, text=True)


def _is_admin() -> bool:
    """Return True if the current process has Administrator privileges."""
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


class WindowsRouter(BaseRouter):
    """Windows routing backend — netsh advfirewall + winreg system proxy."""

    def __init__(
        self,
        socks_port: int = _TOR_SOCKS_PORT,
        or_port: int = _TOR_OR_PORT,
        data_dir: str = _DEFAULT_DATA_DIR,
        wintun_path: str = "",
        tor_binary: str = "",
    ) -> None:
        self.socks_port = socks_port
        self.or_port = or_port
        self.data_dir = data_dir
        self.wintun_path = wintun_path
        self.tor_binary = tor_binary
        self._fw_backup = str(Path(data_dir) / "netcloak_fw_backup.wfw")
        self._wintun_adapter = None  # handle for cleanup

    # ------------------------------------------------------------------
    # BaseRouter interface
    # ------------------------------------------------------------------

    def check_root_or_admin(self) -> None:
        """Raise PermissionError if not running as Administrator."""
        if not _is_admin():
            raise PermissionError(
                "NetCloak requires Administrator privileges on Windows. "
                "Re-run from an elevated command prompt."
            )

    def enable_kill_switch(self) -> None:
        """Enable Windows Firewall kill switch via netsh advfirewall.

        Steps:
        1. Export current firewall state to backup .wfw file.
        2. Block all inbound/outbound traffic by default.
        3. Allow loopback (127.0.0.1).
        4. Allow outbound to Tor SOCKS5 port (9050).
        5. Allow outbound on Tor ORPort (9001) for relay connections.
        """
        self.check_root_or_admin()
        Path(self.data_dir).mkdir(parents=True, exist_ok=True)

        # 1. Export firewall backup
        _console.print("[cyan]Backing up Windows Firewall state…[/cyan]")
        _run("netsh", "advfirewall", "export", self._fw_backup, check=False)
        _console.print(f"[green]Firewall backup saved to {self._fw_backup}[/green]")

        # 2. Block all by default
        _run(
            "netsh", "advfirewall", "set", "allprofiles",
            "firewallpolicy", "blockinbound,blockoutbound",
        )

        # 3. Allow loopback outbound
        _run(
            "netsh", "advfirewall", "firewall", "add", "rule",
            f"name={_RULE_PREFIX}Loopback",
            "dir=out", "action=allow",
            "remoteip=127.0.0.1",
            "enable=yes",
        )

        # 4. Allow outbound to Tor SOCKS5
        _run(
            "netsh", "advfirewall", "firewall", "add", "rule",
            f"name={_RULE_PREFIX}Tor-SOCKS",
            "dir=out", "action=allow",
            "protocol=TCP",
            f"remoteport={self.socks_port}",
            "remoteip=127.0.0.1",
            "enable=yes",
        )

        # 5. Allow Tor process outbound so it can reach guard nodes and directory
        #    servers (ports 9001 and 443).  A program rule is preferred — only
        #    tor.exe gets the exception.  If the binary path is unknown, fall back
        #    to opening the two ports Tor needs for bootstrapping.
        if self.tor_binary and Path(self.tor_binary).is_file():
            _run(
                "netsh", "advfirewall", "firewall", "add", "rule",
                f"name={_RULE_PREFIX}Tor-Process",
                "dir=out", "action=allow",
                f"program={self.tor_binary}",
                "enable=yes",
            )
        else:
            _run(
                "netsh", "advfirewall", "firewall", "add", "rule",
                f"name={_RULE_PREFIX}Tor-ORPort",
                "dir=out", "action=allow",
                "protocol=TCP",
                f"remoteport={self.or_port},443",
                "enable=yes",
            )

        _console.print("[green]Kill switch enabled. All non-Tor traffic is now blocked.[/green]")

    def disable_kill_switch(self) -> None:
        """Remove all NetCloak-* firewall rules and restore backup policy.

        Also reverses the routing set by route_through_tor().
        """
        self.check_root_or_admin()

        # Stop Wintun if it was active; always also clear system proxy
        self._stop_wintun()
        self.unroute_through_tor()

        # Delete each NetCloak rule by exact name.
        # netsh advfirewall does NOT support wildcards in "delete rule name=",
        # so we enumerate every suffix explicitly.
        for suffix in _RULE_SUFFIXES:
            _run(
                "netsh", "advfirewall", "firewall", "delete", "rule",
                f"name={_RULE_PREFIX}{suffix}",
                check=False,
            )
        _console.print("[cyan]Removed all NetCloak firewall rules.[/cyan]")

        # Restore from backup if available
        bkp = Path(self._fw_backup)
        if bkp.exists():
            _console.print("[cyan]Restoring firewall state from backup…[/cyan]")
            result = _run(
                "netsh", "advfirewall", "import", self._fw_backup, check=False
            )
            if result.returncode == 0:
                _console.print("[green]Firewall state restored.[/green]")
            else:
                # Fallback: re-enable defaults
                _console.print(
                    "[yellow]Restore failed — resetting to default allow policy.[/yellow]"
                )
                _run(
                    "netsh", "advfirewall", "set", "allprofiles",
                    "firewallpolicy", "blockinbound,allowoutbound",
                    check=False,
                )
            bkp.unlink(missing_ok=True)
        else:
            _console.print(
                "[yellow]No firewall backup found — resetting to default allow policy.[/yellow]"
            )
            _run(
                "netsh", "advfirewall", "set", "allprofiles",
                "firewallpolicy", "blockinbound,allowoutbound",
                check=False,
            )

    def route_through_tor(self) -> None:
        """Route traffic through Tor.

        If wintun.dll is available, uses a TUN adapter for full transparent
        proxy (all TCP/UDP). Otherwise falls back to system proxy settings
        (registry + netsh winhttp), which covers browsers and WinInet apps.
        """
        self.check_root_or_admin()
        if self._wintun_available():
            _console.print("[cyan]Wintun detected — using transparent TUN proxy.[/cyan]")
            self._route_via_wintun()
        else:
            self._route_via_system_proxy()

    def _wintun_available(self) -> bool:
        """Return True if wintun.dll can be found."""
        candidates = []
        if self.wintun_path:
            candidates.append(self.wintun_path)
        candidates.extend([
            r"C:\Windows\System32\wintun.dll",
            str(Path(__file__).parent.parent.parent / "scripts" / "wintun.dll"),
        ])
        return any(Path(p).is_file() for p in candidates)

    def _route_via_wintun(self) -> None:
        """Create a Wintun TUN adapter and forward packets to SOCKS5 127.0.0.1:9050.

        Steps:
        1. Load wintun.dll via ctypes.
        2. Create a TUN adapter named "NetCloak".
        3. Start a Wintun session.
        4. Set adapter IP to 10.0.0.1/8 via netsh.
        5. Add a default route through the adapter.
        6. Launch packet-forwarding thread → SOCKS5 127.0.0.1:9050.
        """
        import ctypes

        dll_path = None
        candidates = []
        if self.wintun_path:
            candidates.append(self.wintun_path)
        candidates.extend([
            r"C:\Windows\System32\wintun.dll",
            str(Path(__file__).parent.parent.parent / "scripts" / "wintun.dll"),
        ])
        for p in candidates:
            if Path(p).is_file():
                dll_path = p
                break

        if dll_path is None:
            _console.print("[red]wintun.dll not found — cannot create TUN adapter.[/red]")
            self._route_via_system_proxy()
            return

        try:
            wintun = ctypes.WinDLL(dll_path)

            # Set function signatures so ctypes uses 64-bit pointer returns
            # instead of the default c_int, which truncates pointers on x64
            # and causes access violations.
            wintun.WintunCreateAdapter.restype = ctypes.c_void_p
            wintun.WintunCreateAdapter.argtypes = [
                ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_void_p,
            ]
            wintun.WintunStartSession.restype = ctypes.c_void_p
            wintun.WintunStartSession.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
            wintun.WintunReceivePacket.restype = ctypes.c_void_p
            wintun.WintunReceivePacket.argtypes = [
                ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32),
            ]
            wintun.WintunReleaseReceivePacket.restype = None
            wintun.WintunReleaseReceivePacket.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
            wintun.WintunEndSession.restype = None
            wintun.WintunEndSession.argtypes = [ctypes.c_void_p]
            wintun.WintunCloseAdapter.restype = None
            wintun.WintunCloseAdapter.argtypes = [ctypes.c_void_p]

            # WintunCreateAdapter(name, tunnel_type, guid)
            adapter = wintun.WintunCreateAdapter("NetCloak", "NetCloak", None)
            if not adapter:
                raise RuntimeError("WintunCreateAdapter returned NULL")
            self._wintun_adapter = adapter

            # WintunStartSession(adapter, capacity)
            session = wintun.WintunStartSession(adapter, 0x400000)
            if not session:
                raise RuntimeError("WintunStartSession returned NULL")

            # Configure adapter IP
            _run(
                "netsh", "interface", "ip", "set", "address",
                "NetCloak", "static", "10.0.0.1", "255.0.0.0",
                check=False,
            )
            # Add default route through adapter
            _run(
                "netsh", "interface", "ip", "add", "route",
                "0.0.0.0/0", "NetCloak", "10.0.0.1",
                check=False,
            )

            # Launch packet-forwarding thread (forwards TUN reads → SOCKS5)
            import threading
            self._wintun_session = session
            self._wintun_dll = wintun
            fwd_thread = threading.Thread(
                target=self._wintun_forward_loop,
                args=(wintun, session),
                daemon=True,
                name="NetCloak-WintunForward",
            )
            fwd_thread.start()

            _console.print("[green]Wintun TUN adapter active — all traffic routed through Tor.[/green]")

            # Set system SOCKS5 proxy so browsers/WinInet apps use Tor directly.
            # The Wintun forward loop handles raw-packet routing; the system proxy
            # ensures application-layer traffic (browsers) works immediately.
            self._apply_system_proxy()

            # Redirect OS DNS through Tor DNSPort (9053) via UDP relay proxy.
            # Required regardless of routing path — Wintun intercepts packets
            # but the Windows DNS client still queries port 53 directly.
            try:
                from netcloak.routing.dns_tor import TorDNSRedirect
                from netcloak.routing.dns import mark_dns_redirected
                self._dns_forwarder = TorDNSRedirect(dns_port=9053)
                if self._dns_forwarder.start():
                    mark_dns_redirected()
                else:
                    _console.print("[yellow]DNS redirect could not start — DNS may leak.[/yellow]")
                    self._dns_forwarder = None
            except Exception as exc:
                _console.print(f"[yellow]DNS redirect error:[/yellow] {exc}")
                self._dns_forwarder = None

        except OSError as exc:
            winerr = getattr(exc, "winerror", None)
            if winerr == 126:
                reason = f"DLL not found or a dependency is missing (winerror=126): {dll_path}"
            elif winerr == 193:
                reason = "DLL architecture mismatch — use the 64-bit wintun.dll (winerror=193)"
            elif winerr == 998:
                reason = (
                    "Access violation loading wintun.dll — "
                    "DLL version incompatible (requires ≥0.14) or adapter already exists"
                )
            else:
                reason = str(exc)
            _console.print(f"[yellow]Wintun unavailable:[/yellow] {reason}")
            _console.print("[yellow]Falling back to system proxy settings.[/yellow]")
            self._route_via_system_proxy()
        except Exception as exc:
            _console.print(f"[yellow]Wintun setup failed:[/yellow] {exc!r}")
            _console.print("[yellow]Falling back to system proxy settings.[/yellow]")
            self._route_via_system_proxy()

    def _wintun_forward_loop(self, wintun: Any, session: Any) -> None:
        """Read packets from the Wintun TUN and forward them to SOCKS5.

        This is a best-effort forwarding loop. Packets that cannot be
        forwarded (e.g. UDP that SOCKS5 cannot handle) are silently dropped.
        """
        import socket as _socket
        socks_addr = ("127.0.0.1", self.socks_port)
        while True:
            try:
                packet_size = ctypes.c_uint32(0)
                packet = wintun.WintunReceivePacket(session, ctypes.byref(packet_size))
                if packet:
                    data = ctypes.string_at(packet, packet_size.value)
                    wintun.WintunReleaseReceivePacket(session, packet)
                    # Forward raw IP packet data through SOCKS5 (TCP only)
                    try:
                        with _socket.create_connection(socks_addr, timeout=5) as sock:
                            sock.sendall(data)
                    except Exception:
                        pass
            except Exception:
                break

    def _stop_wintun(self) -> None:
        """End Wintun session, close adapter, remove route and adapter."""
        try:
            if hasattr(self, "_wintun_session") and self._wintun_session:
                self._wintun_dll.WintunEndSession(self._wintun_session)
                self._wintun_session = None
            if self._wintun_adapter:
                self._wintun_dll.WintunCloseAdapter(self._wintun_adapter)
                self._wintun_adapter = None
        except Exception as exc:
            _console.print(f"[yellow]Wintun cleanup error:[/yellow] {exc}")

        # Remove route and adapter
        _run("netsh", "interface", "ip", "delete", "route", "0.0.0.0/0", "NetCloak", check=False)
        _run("netsh", "interface", "set", "interface", "NetCloak", "admin=disabled", check=False)

    def _apply_system_proxy(self) -> None:
        """Write SOCKS5 proxy to Windows registry + winhttp and broadcast the change.

        Called by both _route_via_wintun() and _route_via_system_proxy() so
        browsers and WinInet/WinHTTP apps always use Tor SOCKS5 regardless of
        which routing path is active.
        """
        proxy_server = f"127.0.0.1:{self.socks_port}"

        try:
            import winreg
            key_path = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE
            ) as key:
                winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 1)
                winreg.SetValueEx(key, "ProxyServer", 0, winreg.REG_SZ, f"socks={proxy_server}")
            _console.print(f"[green]System proxy set: socks={proxy_server}[/green]")
        except Exception as exc:
            _console.print(f"[yellow]Could not set registry proxy:[/yellow] {exc}")

        _run("netsh", "winhttp", "set", "proxy", proxy_server, check=False)
        _broadcast_settings_change()

    def _route_via_system_proxy(self) -> None:
        """Set system-wide SOCKS5 proxy to Tor (127.0.0.1:9050).

        Uses:
        1. HKCU registry Internet Settings (covers browsers + WinInet apps).
        2. ``netsh winhttp set proxy`` (covers WinHTTP / system-level apps).
        3. Sends WM_SETTINGCHANGE to notify running applications.
        4. DNS redirect via TorDNSRedirect (OS-level DNS through Tor DNSPort).
        """
        self._apply_system_proxy()

        # Redirect OS DNS through Tor DNSPort (9053) via UDP relay proxy.
        try:
            from netcloak.routing.dns_tor import TorDNSRedirect
            from netcloak.routing.dns import mark_dns_redirected
            self._dns_forwarder = TorDNSRedirect(dns_port=9053)
            if self._dns_forwarder.start():
                mark_dns_redirected()
            else:
                _console.print("[yellow]DNS redirect could not start — DNS may leak.[/yellow]")
                self._dns_forwarder = None
        except Exception as exc:
            _console.print(f"[yellow]DNS redirect error:[/yellow] {exc}")
            self._dns_forwarder = None

    def unroute_through_tor(self) -> None:
        """Reverse the routing settings applied by route_through_tor()."""
        # Stop DNS forwarder — set by both _route_via_wintun and _route_via_system_proxy
        dns_forwarder = getattr(self, "_dns_forwarder", None)
        if dns_forwarder is not None:
            dns_forwarder.stop()
            self._dns_forwarder = None
            try:
                from netcloak.routing.dns import clear_dns_redirected
                clear_dns_redirected()
            except Exception:
                pass

        # 1. Registry — disable proxy
        try:
            import winreg
            key_path = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE
            ) as key:
                winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 0)
                winreg.DeleteValue(key, "ProxyServer")
        except FileNotFoundError:
            pass  # ProxyServer key may not exist if we never set it
        except Exception as exc:
            _console.print(f"[yellow]Could not clear registry proxy:[/yellow] {exc}")

        # 2. Reset winhttp proxy
        _run("netsh", "winhttp", "reset", "proxy", check=False)

        # 3. Broadcast WM_SETTINGCHANGE
        _broadcast_settings_change()
        _console.print("[green]System proxy settings cleared.[/green]")

    def is_kill_switch_active(self) -> bool:
        """Return True if the NetCloak-Tor-SOCKS firewall rule exists."""
        try:
            result = _run(
                "netsh", "advfirewall", "firewall", "show", "rule",
                f"name={_RULE_PREFIX}Tor-SOCKS",
                check=False,
            )
            return f"{_RULE_PREFIX}Tor-SOCKS" in result.stdout
        except Exception:
            return False


# ------------------------------------------------------------------
# Internal helpers
# ------------------------------------------------------------------

def _broadcast_settings_change() -> None:
    """Send WM_SETTINGCHANGE to notify running processes of proxy changes."""
    try:
        import ctypes
        HWND_BROADCAST = 0xFFFF
        WM_SETTINGCHANGE = 0x001A
        SMTO_ABORTIFHUNG = 0x0002
        result = ctypes.c_long()
        ctypes.windll.user32.SendMessageTimeoutW(
            HWND_BROADCAST,
            WM_SETTINGCHANGE,
            0,
            "Internet Settings",
            SMTO_ABORTIFHUNG,
            5000,
            ctypes.byref(result),
        )
    except Exception:
        pass  # Non-critical; apps will pick up the change on next request
