"""DNS redirect via Tor DNSPort for Windows routing.

Uses a Python UDP relay proxy: binds a UDP socket on 127.0.0.1:53 and
relays every DNS query to 127.0.0.1:9053 (Tor DNSPort), then relays the
response back to the original caller.  DNS queries are UDP, so this relay
correctly handles them — unlike a TCP-only forwarding approach.

Steps on start():
  1. Enumerate connected adapters and save their current DNS configuration.
     (CRITICAL: backup BEFORE setting anything — BUG 2 fix)
  2. Set DNS to 127.0.0.1 on each adapter.
  3. Persist backup to file for cross-process restore.
  4. Bind a UDP socket to 127.0.0.1:53.
  5. Launch a daemon relay thread that forwards queries to Tor DNSPort.

Steps on stop():
  1. Signal the relay thread via threading.Event and join it.
  2. Close the relay socket.
  3. Restore each adapter's original DNS setting (DHCP or static).
  4. Delete cross-process backup file.
"""
from __future__ import annotations

import json
import os
import re
import socket
import struct
import subprocess
import sys
import threading
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console

if TYPE_CHECKING:
    pass

_console = Console(stderr=True)

# Mirrors _DNS_BACKUP_WINDOWS in routing/dns.py — written by start() so
# cross-process stop() can restore DNS even without in-memory state.
_DNS_BACKUP_FILE = Path(os.path.expandvars(r"%APPDATA%\NetCloak\dns_backup_windows.json"))

# Suppresses ICMP→WSAECONNRESET (10054) on Windows UDP sockets.
# Without this, recvfrom() on a UDP socket raises ConnectionResetError when
# the target port is closed (e.g. Tor DNSPort not ready yet).
_SIO_UDP_CONNRESET = -1744830452  # 0xFFFF9805 as signed 32-bit int

_DNS_REDIRECT_ADDR = "127.0.0.1"
_LISTEN_PORT = 53
_TOR_DNS_PORT = 9053
_RELAY_BUFFER = 4096  # DNS packets are small (512–4096 bytes)


def _is_admin() -> bool:
    """Return True if the current process has Administrator privileges (Windows only)."""
    if sys.platform != "win32":
        return True
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _run(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(list(args), capture_output=True, text=True, check=False)


def _get_connected_adapters() -> list[str]:
    """Return names of all Connected network adapters."""
    result = _run("netsh", "interface", "show", "interface")
    adapters = []
    for line in result.stdout.splitlines():
        # Lines: "Enabled   Connected   Dedicated   Wi-Fi"
        if "Connected" in line and "Enabled" in line:
            parts = line.split()
            if len(parts) >= 4:
                adapters.append(" ".join(parts[3:]))
    return adapters


def _get_adapter_dns(adapter: str) -> dict:
    """Return DNS info for adapter: {'mode': 'dhcp'|'static', 'servers': [...]}.

    Parses output of: netsh interface ip show dns "<adapter>"
    """
    result = _run("netsh", "interface", "ip", "show", "dns", adapter)
    output = result.stdout.lower()

    if "dhcp" in output:
        return {"mode": "dhcp", "servers": []}

    servers = re.findall(r'(\d{1,3}(?:\.\d{1,3}){3})', result.stdout)
    # Exclude link-local addresses
    dns_servers = [s for s in servers if not s.startswith("169.254")]
    return {"mode": "static", "servers": dns_servers}


def _suppress_win_udp_reset(sock: socket.socket) -> None:
    """Suppress WinError 10054 (ICMP unreachable → WSAECONNRESET) on Windows UDP sockets.

    When a UDP packet is sent to a closed port on Windows, an ICMP "port
    unreachable" response is delivered back to the sending socket.  The next
    recvfrom() then raises ConnectionResetError (WinError 10054), which would
    kill the relay loop.  SIO_UDP_CONNRESET = 0 disables this behaviour.
    """
    if sys.platform == "win32":
        try:
            sock.ioctl(_SIO_UDP_CONNRESET, struct.pack("B", 0))
        except Exception:
            pass  # Non-critical — relay will handle 10054 via ConnectionResetError catch


def _dns_relay_loop(
    sock: socket.socket,
    tor_dns_port: int,
    stop_event: threading.Event,
) -> None:
    """UDP DNS relay loop — runs in a daemon thread.

    Receives DNS queries on ``sock`` (bound to 127.0.0.1:53), forwards each
    query to Tor DNSPort at ``(127.0.0.1, tor_dns_port)``, and relays the
    response back to the original client.

    The loop checks ``stop_event`` every 1 second via socket timeout so it
    shuts down cleanly when ``TorDNSRedirect.stop()`` is called.
    """
    sock.settimeout(1.0)

    while not stop_event.is_set():
        try:
            try:
                data, client_addr = sock.recvfrom(_RELAY_BUFFER)
            except socket.timeout:
                continue  # Check stop_event and loop
            except ConnectionResetError:
                continue  # WinError 10054 — ICMP unreachable (Tor DNS port not ready yet)

            # Forward query to Tor DNSPort and relay response back
            relay_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            _suppress_win_udp_reset(relay_sock)
            try:
                relay_sock.sendto(data, (_DNS_REDIRECT_ADDR, tor_dns_port))
                relay_sock.settimeout(5.0)
                try:
                    response, _ = relay_sock.recvfrom(_RELAY_BUFFER)
                    sock.sendto(response, client_addr)
                except socket.timeout:
                    pass  # Tor DNS port not ready — silently drop, client will retry
                except ConnectionResetError:
                    pass  # WinError 10054 from Tor side — silently drop
            except Exception as exc:
                _console.print(f"[yellow]DNS relay iteration error:[/yellow] {exc}")
            finally:
                relay_sock.close()

        except Exception as exc:
            # Keep the loop alive — log and continue
            _console.print(f"[yellow]DNS relay loop error:[/yellow] {exc}")


class TorDNSRedirect:
    """Redirect DNS through Tor DNSPort via UDP relay proxy."""

    def __init__(self, dns_port: int = _TOR_DNS_PORT) -> None:
        self.dns_port = dns_port
        self._saved_dns: dict[str, dict] = {}
        self._sock: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start(self) -> bool:
        """Configure DNS redirect via UDP relay proxy.

        Returns True on success, False if not admin, no adapters found, or
        socket bind fails.

        CRITICAL ORDER (BUG 2 fix):
          1. Back up every adapter's current DNS FIRST.
          2. Then set adapters to 127.0.0.1.
          3. Then bind socket and start relay thread.
        """
        if sys.platform == "win32" and not _is_admin():
            _console.print(
                "[red]DNS relay requires Administrator privileges.[/red] "
                "Re-run NetCloak from an elevated command prompt."
            )
            return False

        adapters = _get_connected_adapters()
        if not adapters:
            _console.print("[yellow]No connected adapters found — DNS redirect skipped.[/yellow]")
            return False

        # --- STEP 1: Back up ALL adapters before touching any of them ---
        for adapter in adapters:
            self._saved_dns[adapter] = _get_adapter_dns(adapter)

        # Persist backup to file so cross-process stop() can restore DNS.
        # (The stop command runs in a new Python process — in-memory backup is gone.)
        try:
            _DNS_BACKUP_FILE.parent.mkdir(parents=True, exist_ok=True)
            _DNS_BACKUP_FILE.write_text(json.dumps(self._saved_dns, indent=2))
        except Exception:
            pass  # Best-effort — in-process restore still works via _saved_dns

        # --- STEP 2: Set each adapter DNS to 127.0.0.1 ---
        for adapter in adapters:
            result = _run(
                "netsh", "interface", "ip", "set", "dns",
                adapter, "static", _DNS_REDIRECT_ADDR,
            )
            if result.returncode == 0:
                _console.print(
                    f"[cyan]DNS → {_DNS_REDIRECT_ADDR} on adapter: {adapter}[/cyan]"
                )
            else:
                _console.print(
                    f"[yellow]Could not set DNS on {adapter}:[/yellow] "
                    f"{result.stderr.strip() or result.stdout.strip()}"
                )

        # --- STEP 3: Bind UDP socket to 127.0.0.1:53 ---
        if not self._start_relay_socket():
            # Restore DNS backup if socket bind failed
            self._restore_dns()
            self._saved_dns.clear()
            return False

        # --- STEP 4: Coordinate with dns.py ---
        try:
            from netcloak.routing.dns import mark_dns_redirected
            mark_dns_redirected()
        except Exception:
            pass  # Coordination is best-effort; don't fail start() for this

        _console.print(
            f"[green]DNS UDP relay active: {_DNS_REDIRECT_ADDR}:{_LISTEN_PORT} "
            f"→ {_DNS_REDIRECT_ADDR}:{self.dns_port}[/green]"
        )
        return True

    def _start_relay_socket(self) -> bool:
        """Bind the relay UDP socket and start the relay thread. Returns True on success."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((_DNS_REDIRECT_ADDR, _LISTEN_PORT))
            _suppress_win_udp_reset(sock)
            self._sock = sock
        except OSError as exc:
            _console.print(
                f"[red]DNS relay: could not bind {_DNS_REDIRECT_ADDR}:{_LISTEN_PORT}:[/red] {exc}\n"
                "[red]DNS redirect is NOT active — DNS may leak.[/red]"
            )
            return False

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=_dns_relay_loop,
            args=(self._sock, self.dns_port, self._stop_event),
            daemon=True,
            name="NetCloak-DNSRelay",
        )
        self._thread.start()
        return True

    def stop(self) -> None:
        """Stop the UDP relay and restore adapter DNS settings."""
        # Signal relay thread to exit
        self._stop_event.set()

        if self._thread is not None:
            self._thread.join(timeout=3)
            self._thread = None

        if self._sock is not None:
            try:
                self._sock.close()
            except Exception:
                pass
            self._sock = None

        self._restore_dns()
        self._saved_dns.clear()

        # Coordinate with dns.py
        try:
            from netcloak.routing.dns import clear_dns_redirected
            clear_dns_redirected()
        except Exception:
            pass  # Best-effort

        _console.print("[cyan]DNS UDP relay stopped.[/cyan]")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _restore_dns(self) -> None:
        """Restore adapter DNS from the saved backup."""
        for adapter, dns_info in self._saved_dns.items():
            if dns_info["mode"] == "dhcp" or not dns_info["servers"]:
                _run("netsh", "interface", "ip", "set", "dns", adapter, "dhcp")
                _console.print(f"[cyan]Restored DNS to DHCP on adapter: {adapter}[/cyan]")
            else:
                _run(
                    "netsh", "interface", "ip", "set", "dns",
                    adapter, "static", dns_info["servers"][0],
                )
                _console.print(
                    f"[cyan]Restored DNS to {dns_info['servers'][0]} on adapter: {adapter}[/cyan]"
                )

        # Remove the cross-process backup file — it was consumed, don't leave it stale.
        try:
            _DNS_BACKUP_FILE.unlink(missing_ok=True)
        except Exception:
            pass
