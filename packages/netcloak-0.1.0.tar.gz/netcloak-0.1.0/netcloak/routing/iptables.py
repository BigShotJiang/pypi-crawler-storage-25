"""iptables-based kill switch and transparent traffic routing for Linux.

All public methods require root privileges and raise PermissionError if not root.

Transparent proxy approach
--------------------------
route_through_tor() uses a dedicated NETCLOAK_REDIRECT chain in the nat table:
- Excludes private / loopback ranges from redirection.
- Redirects remaining TCP traffic to Tor's TransPort (default 9040).
- Redirects UDP port 53 (DNS) to Tor's DNSPort (default 9053).

This approach uses only the standard iptables nat REDIRECT target — no special
kernel modules (xt_TPROXY, xt_socket) are required.

Tor UID note: When Tor runs as a dedicated system user (e.g. debian-tor), its
traffic can be excluded by UID with --uid-owner to prevent a redirect loop.
When Tor is launched as root (common in test environments), there is no
separate UID, so traffic is excluded only by destination port matching the
TransPort/SocksPort allowlist in the kill switch.
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

from rich.console import Console

from netcloak.routing.base import BaseRouter

_console = Console(stderr=True)

_BACKUP_PATH = Path("/tmp/netcloak_iptables_backup")
_NETCLOAK_COMMENT = "netcloak"
_REDIRECT_CHAIN = "NETCLOAK_REDIRECT"
_TOR_SOCKS_PORT = 9050
_TOR_OR_PORT = 9001
_TOR_TRANS_PORT = 9040
_TOR_DNS_PORT = 9053

# Private / non-routable ranges excluded from transparent redirect
_PRIVATE_RANGES = [
    "127.0.0.0/8",
    "10.0.0.0/8",
    "172.16.0.0/12",
    "192.168.0.0/16",
    "224.0.0.0/4",
]


def _run(*args: str, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(list(args), check=check, capture_output=True, text=True)


class LinuxRouter(BaseRouter):
    """Linux routing backend using iptables."""

    def __init__(
        self,
        socks_port: int = _TOR_SOCKS_PORT,
        or_port: int = _TOR_OR_PORT,
        trans_port: int = _TOR_TRANS_PORT,
        dns_port: int = _TOR_DNS_PORT,
    ) -> None:
        self.socks_port = socks_port
        self.or_port = or_port
        self.trans_port = trans_port
        self.dns_port = dns_port

    # ------------------------------------------------------------------
    # BaseRouter interface
    # ------------------------------------------------------------------

    def check_root_or_admin(self) -> None:
        """Raise PermissionError if not running as root."""
        if os.geteuid() != 0:
            raise PermissionError(
                "NetCloak iptables operations require root privileges. Run with sudo."
            )

    def enable_kill_switch(self) -> None:
        """Enable iptables kill switch.

        1. Backs up existing rules to /tmp/netcloak_iptables_backup.
        2. Sets INPUT/OUTPUT/FORWARD default policies to DROP.
        3. Allows loopback, established/related, outbound to Tor SOCKS5 and ORPort.
        """
        self.check_root_or_admin()
        _console.print("[cyan]Saving existing iptables rules…[/cyan]")
        result = _run("iptables-save")
        _BACKUP_PATH.write_text(result.stdout)
        _console.print(f"[green]Backup saved to {_BACKUP_PATH}[/green]")

        for chain in ("INPUT", "OUTPUT", "FORWARD"):
            _run("iptables", "-P", chain, "DROP")

        _run("iptables", "-A", "INPUT", "-i", "lo", "-j", "ACCEPT",
             "-m", "comment", "--comment", _NETCLOAK_COMMENT)
        _run("iptables", "-A", "OUTPUT", "-o", "lo", "-j", "ACCEPT",
             "-m", "comment", "--comment", _NETCLOAK_COMMENT)

        _run("iptables", "-A", "INPUT", "-m", "conntrack", "--ctstate", "ESTABLISHED,RELATED",
             "-j", "ACCEPT", "-m", "comment", "--comment", _NETCLOAK_COMMENT)
        _run("iptables", "-A", "OUTPUT", "-m", "conntrack", "--ctstate", "ESTABLISHED,RELATED",
             "-j", "ACCEPT", "-m", "comment", "--comment", _NETCLOAK_COMMENT)

        _run("iptables", "-A", "OUTPUT", "-d", "127.0.0.1", "-p", "tcp",
             "--dport", str(self.socks_port), "-j", "ACCEPT",
             "-m", "comment", "--comment", _NETCLOAK_COMMENT)

        _run("iptables", "-A", "OUTPUT", "-p", "tcp", "--dport", str(self.or_port),
             "-j", "ACCEPT", "-m", "comment", "--comment", _NETCLOAK_COMMENT)

        _console.print("[green]Kill switch enabled. All non-Tor traffic is now blocked.[/green]")

    def disable_kill_switch(self) -> None:
        """Restore iptables rules from backup and clean up the NETCLOAK_REDIRECT chain."""
        self.check_root_or_admin()
        _teardown_redirect_chain()

        if not _BACKUP_PATH.exists():
            _console.print(
                "[yellow]No backup found. Resetting to ACCEPT defaults and flushing rules.[/yellow]"
            )
            _flush_netcloak_rules()
            for chain in ("INPUT", "OUTPUT", "FORWARD"):
                _run("iptables", "-P", chain, "ACCEPT")
            return

        _console.print("[cyan]Restoring iptables rules from backup…[/cyan]")
        restore_proc = subprocess.run(
            ["iptables-restore"],
            input=_BACKUP_PATH.read_text(),
            text=True,
            capture_output=True,
        )
        if restore_proc.returncode != 0:
            _console.print(f"[red]iptables-restore failed:[/red] {restore_proc.stderr}")
        else:
            _console.print("[green]iptables rules restored.[/green]")
        _BACKUP_PATH.unlink(missing_ok=True)

    def route_through_tor(self) -> None:
        """Set up transparent TCP + DNS routing through Tor via a dedicated chain."""
        self.check_root_or_admin()
        _teardown_redirect_chain()

        _run("iptables", "-t", "nat", "-N", _REDIRECT_CHAIN)

        for cidr in _PRIVATE_RANGES:
            _run("iptables", "-t", "nat", "-A", _REDIRECT_CHAIN,
                 "-d", cidr, "-j", "RETURN",
                 "-m", "comment", "--comment", _NETCLOAK_COMMENT)

        # Exclude Tor UID if a dedicated system user exists (e.g. debian-tor).
        # When tor runs as root there is no separate UID; skip silently.
        import pwd
        try:
            tor_uid = pwd.getpwnam("debian-tor").pw_uid
            _run("iptables", "-t", "nat", "-A", _REDIRECT_CHAIN,
                 "-m", "owner", "--uid-owner", str(tor_uid),
                 "-j", "RETURN",
                 "-m", "comment", "--comment", _NETCLOAK_COMMENT)
            _console.print(f"[cyan]Excluding debian-tor UID {tor_uid} from redirect.[/cyan]")
        except KeyError:
            _console.print(
                "[yellow]debian-tor user not found — tor traffic excluded only by loopback rules "
                "(ensure Tor is not running as root in production).[/yellow]"
            )

        _run("iptables", "-t", "nat", "-A", _REDIRECT_CHAIN,
             "-p", "tcp", "-j", "REDIRECT", "--to-ports", str(self.trans_port),
             "-m", "comment", "--comment", _NETCLOAK_COMMENT)

        _run("iptables", "-t", "nat", "-A", _REDIRECT_CHAIN,
             "-p", "udp", "--dport", "53",
             "-j", "REDIRECT", "--to-ports", str(self.dns_port),
             "-m", "comment", "--comment", _NETCLOAK_COMMENT)

        _run("iptables", "-t", "nat", "-A", "OUTPUT",
             "-j", _REDIRECT_CHAIN,
             "-m", "comment", "--comment", _NETCLOAK_COMMENT)

        _console.print(
            f"[green]Transparent routing active: TCP→:{self.trans_port}, "
            f"DNS→:{self.dns_port}[/green]"
        )

    def is_kill_switch_active(self) -> bool:
        """Return True if the default OUTPUT policy is DROP."""
        try:
            result = _run("iptables", "-L", "OUTPUT", "--line-numbers", "-n")
            return "policy DROP" in result.stdout
        except Exception:
            return False


# ---------------------------------------------------------------------------
# Module-level convenience wrappers (backward-compatible with Phase 1/2 callers)
# ---------------------------------------------------------------------------

def _default_router() -> LinuxRouter:
    return LinuxRouter()


def enable_kill_switch(socks_port: int = _TOR_SOCKS_PORT, or_port: int = _TOR_OR_PORT) -> None:
    r = LinuxRouter(socks_port=socks_port, or_port=or_port)
    r.enable_kill_switch()


def disable_kill_switch() -> None:
    _default_router().disable_kill_switch()


def route_through_tor(
    trans_port: int = _TOR_TRANS_PORT,
    dns_port: int = _TOR_DNS_PORT,
) -> None:
    LinuxRouter(trans_port=trans_port, dns_port=dns_port).route_through_tor()


def is_kill_switch_active() -> bool:
    return _default_router().is_kill_switch_active()


# ------------------------------------------------------------------
# Internal helpers (shared by LinuxRouter methods)
# ------------------------------------------------------------------

def _teardown_redirect_chain() -> None:
    """Remove the NETCLOAK_REDIRECT chain and its jump rule from OUTPUT."""
    _run("iptables", "-t", "nat", "-D", "OUTPUT",
         "-j", _REDIRECT_CHAIN,
         "-m", "comment", "--comment", _NETCLOAK_COMMENT,
         check=False)
    _run("iptables", "-t", "nat", "-F", _REDIRECT_CHAIN, check=False)
    _run("iptables", "-t", "nat", "-X", _REDIRECT_CHAIN, check=False)


def _flush_netcloak_rules() -> None:
    """Remove all iptables rules tagged with the netcloak comment."""
    for table in ("filter", "nat"):
        for chain in ("INPUT", "OUTPUT", "FORWARD", "PREROUTING", "POSTROUTING"):
            try:
                result = _run(
                    "iptables", "-t", table, "-L", chain, "--line-numbers", "-n",
                    check=False,
                )
                rule_nums = []
                for line in result.stdout.splitlines():
                    if _NETCLOAK_COMMENT in line:
                        parts = line.split()
                        if parts and parts[0].isdigit():
                            rule_nums.append(int(parts[0]))
                for num in sorted(rule_nums, reverse=True):
                    _run("iptables", "-t", table, "-D", chain, str(num), check=False)
            except Exception:
                pass
