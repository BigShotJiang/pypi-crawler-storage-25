"""DNS lockdown — redirect system DNS through Tor, prevent leaks.

Supports Linux (resolv.conf + iptables) and Windows (netsh per-adapter DNS).
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

import requests
from rich.console import Console

_console = Console(stderr=True)

_RESOLV_CONF = Path("/etc/resolv.conf")
_RESOLV_BACKUP = Path("/tmp/netcloak_resolv_backup")
_NETCLOAK_COMMENT = "netcloak-dns"
_DNS_BACKUP_WINDOWS = Path(os.path.expandvars(r"%APPDATA%\NetCloak\dns_backup_windows.json"))

# resolv.conf does not support specifying a port number — it always queries
# port 53.  We write nameserver 127.0.0.1 here; the iptables REDIRECT rule in
# routing/iptables.py (route_through_tor) remaps outbound UDP/TCP port 53 to
# Tor's DNSPort (9053), so DNS queries transparently reach Tor without any
# port configuration in resolv.conf.
_TOR_DNS_PORT = 9053

# ---------------------------------------------------------------------------
# TorDNSRedirect coordination flag
# ---------------------------------------------------------------------------
# When TorDNSRedirect.start() succeeds, it calls mark_dns_redirected() so that
# the subsequent lock_dns() call (cli.py) knows it should only add firewall
# rules — the adapter backup and DNS set were already done by TorDNSRedirect.
_dns_redirected_by_tor: bool = False


def mark_dns_redirected() -> None:
    """Called by TorDNSRedirect after it handles DNS backup + redirect."""
    global _dns_redirected_by_tor
    _dns_redirected_by_tor = True


def clear_dns_redirected() -> None:
    """Called when TorDNSRedirect.stop() completes."""
    global _dns_redirected_by_tor
    _dns_redirected_by_tor = False


# ===========================================================================
# Public API — platform-dispatched
# ===========================================================================

def lock_dns(tor_dns_port: int = _TOR_DNS_PORT) -> None:
    """Lock DNS to Tor on the current platform."""
    if sys.platform.startswith("linux"):
        _lock_dns_linux(tor_dns_port)
    elif sys.platform == "win32":
        _lock_dns_windows()
    else:
        _console.print(f"[yellow]DNS lockdown not supported on {sys.platform}.[/yellow]")


def unlock_dns() -> None:
    """Restore DNS settings on the current platform."""
    if sys.platform.startswith("linux"):
        _unlock_dns_linux()
    elif sys.platform == "win32":
        _unlock_dns_windows()
    else:
        _console.print(f"[yellow]DNS unlock not supported on {sys.platform}.[/yellow]")


def check_dns_leak(socks_port: int | None = None) -> dict[str, Any]:
    """Check for DNS leaks (cross-platform).

    When ``socks_port`` is supplied, Tor is assumed to be running.  The check
    verifies that the local Tor DNSPort is responding and that all system
    adapters are pointed at 127.x — without hitting any external API whose
    results would be misinterpreted (Tor exit-node resolvers are external IPs
    by design, not a leak).

    Returns ``{"leaked": bool, "resolvers": list[str]}``.
    """
    if sys.platform == "win32":
        return _check_dns_leak_windows(socks_port)

    if sys.platform.startswith("linux"):
        return _check_dns_leak_linux()

    # Fallback for other platforms: best-effort via resolv.conf
    return {"leaked": False, "resolvers": []}


def _check_dns_leak_windows(socks_port: int | None) -> dict[str, Any]:
    """Windows DNS leak check: netsh adapter inspection + optional Tor DNSPort probe."""
    import re
    _IP_RE = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")

    # Collect DNS server IPs from all adapters via netsh
    resolvers: list[str] = []
    try:
        result = subprocess.run(
            ["netsh", "interface", "ip", "show", "dns"],
            capture_output=True, text=True, check=False,
        )
        for line in result.stdout.splitlines():
            stripped = line.strip()
            low = stripped.lower()
            if "statically configured dns servers" in low or "dns servers configured through dhcp" in low:
                parts = stripped.split(":", 1)
                if len(parts) == 2:
                    ip = parts[1].strip()
                    if _IP_RE.match(ip):
                        resolvers.append(ip)
            elif _IP_RE.match(stripped) and stripped not in resolvers:
                resolvers.append(stripped)
    except Exception:
        pass

    all_local = bool(resolvers) and all(r.startswith("127.") for r in resolvers)

    if socks_port is not None:
        # Tor is running — also probe the Tor DNSPort to confirm DNS is routing through it.
        tor_dns_ok = _probe_tor_dns_port(_TOR_DNS_PORT)
        leaked = not all_local or not tor_dns_ok
    else:
        leaked = not all_local

    return {"leaked": leaked, "resolvers": resolvers}


def _check_dns_leak_linux() -> dict[str, Any]:
    """Linux DNS leak check: inspect /etc/resolv.conf."""
    resolvers: list[str] = []
    try:
        content = _RESOLV_CONF.read_text()
        for line in content.splitlines():
            line = line.strip()
            if line.startswith("nameserver"):
                parts = line.split()
                if len(parts) >= 2:
                    resolvers.append(parts[1])
    except Exception as exc:
        _console.print(f"[yellow]Could not read {_RESOLV_CONF}:[/yellow] {exc}")
    leaked = any(not r.startswith("127.") for r in resolvers)
    return {"leaked": leaked, "resolvers": resolvers}


def _probe_tor_dns_port(dns_port: int = _TOR_DNS_PORT, timeout: float = 3.0) -> bool:
    """Return True if Tor's DNSPort is responding to a minimal DNS query."""
    query = (
        b'\x12\x34'
        b'\x01\x00'
        b'\x00\x01'
        b'\x00\x00'
        b'\x00\x00'
        b'\x00\x00'
        b'\x05check\x0btorproject\x03org\x00'
        b'\x00\x01'
        b'\x00\x01'
    )
    sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)
        sock.sendto(query, ("127.0.0.1", dns_port))
        response, _ = sock.recvfrom(4096)
        return len(response) >= 4 and response[:2] == b'\x12\x34' and bool(response[2] & 0x80)
    except Exception:
        return False
    finally:
        if sock is not None:
            sock.close()


# ===========================================================================
# Linux implementation
# ===========================================================================

def _require_root_linux() -> None:
    if os.geteuid() != 0:
        raise PermissionError(
            "NetCloak DNS operations require root privileges. Run with sudo."
        )


def _run_linux(*args: str, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(list(args), check=check, capture_output=True, text=True)


def _lock_dns_linux(tor_dns_port: int = _TOR_DNS_PORT) -> None:
    """Lock DNS on Linux via resolv.conf + iptables."""
    _require_root_linux()

    if _RESOLV_CONF.exists():
        shutil.copy2(str(_RESOLV_CONF), str(_RESOLV_BACKUP))
        _console.print(f"[green]Backed up {_RESOLV_CONF} to {_RESOLV_BACKUP}[/green]")

    _RESOLV_CONF.write_text("nameserver 127.0.0.1\n")
    _console.print("[green]/etc/resolv.conf updated to use 127.0.0.1 (Tor DNS).[/green]")

    for proto in ("udp", "tcp"):
        _run_linux(
            "iptables", "-A", "OUTPUT",
            "!", "-d", "127.0.0.1",
            "-p", proto, "--dport", "53",
            "-j", "DROP",
            "-m", "comment", "--comment", _NETCLOAK_COMMENT,
        )

    _console.print("[green]DNS lockdown active. Only local Tor DNS resolver is allowed.[/green]")


def _unlock_dns_linux() -> None:
    """Restore /etc/resolv.conf and remove DNS iptables rules on Linux."""
    _require_root_linux()

    if _RESOLV_BACKUP.exists():
        shutil.copy2(str(_RESOLV_BACKUP), str(_RESOLV_CONF))
        _RESOLV_BACKUP.unlink(missing_ok=True)
        _console.print(f"[green]{_RESOLV_CONF} restored from backup.[/green]")
    else:
        _console.print("[yellow]No resolv.conf backup found; leaving current file intact.[/yellow]")

    _flush_dns_rules_linux()
    _console.print("[green]DNS lockdown removed.[/green]")


def _flush_dns_rules_linux() -> None:
    for chain in ("INPUT", "OUTPUT"):
        try:
            result = _run_linux("iptables", "-L", chain, "--line-numbers", "-n", check=False)
            rule_nums = []
            for line in result.stdout.splitlines():
                if _NETCLOAK_COMMENT in line:
                    parts = line.split()
                    if parts and parts[0].isdigit():
                        rule_nums.append(int(parts[0]))
            for num in sorted(rule_nums, reverse=True):
                _run_linux("iptables", "-D", chain, str(num), check=False)
        except Exception:
            pass


# ===========================================================================
# Windows implementation
# ===========================================================================

def _require_admin_windows() -> None:
    try:
        import ctypes
        if not ctypes.windll.shell32.IsUserAnAdmin():
            raise PermissionError(
                "NetCloak DNS operations require Administrator privileges on Windows."
            )
    except AttributeError:
        raise PermissionError("Cannot verify admin status on this platform.")


def _run_win(*args: str, check: bool = False) -> subprocess.CompletedProcess:
    return subprocess.run(list(args), capture_output=True, text=True, check=check)


def _get_connected_adapters() -> list[str]:
    """Return list of connected adapter names from netsh."""
    result = _run_win("netsh", "interface", "show", "interface")
    adapters = []
    for line in result.stdout.splitlines():
        if "Connected" in line or "Dedicated" in line:
            parts = line.split()
            if len(parts) >= 4:
                # Adapter name is everything after the 3rd field
                name = " ".join(parts[3:])
                adapters.append(name)
    return adapters


def _parse_dns_config(netsh_output: str) -> dict[str, Any]:
    """Parse ``netsh interface ip show dns`` output for a single adapter.

    Returns ``{"mode": "static"|"dhcp", "servers": [list of IPs]}``.
    Continuation lines (additional IPs indented below the header) are included.
    """
    import re
    mode = "dhcp"
    servers: list[str] = []
    _IP_RE = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")

    for line in netsh_output.splitlines():
        stripped = line.strip()
        low = stripped.lower()

        if "statically configured dns servers" in low:
            mode = "static"
            parts = stripped.split(":", 1)
            if len(parts) == 2:
                ip = parts[1].strip()
                if _IP_RE.match(ip):
                    servers.append(ip)
        elif "dns servers configured through dhcp" in low:
            mode = "dhcp"
            parts = stripped.split(":", 1)
            if len(parts) == 2:
                ip = parts[1].strip()
                if _IP_RE.match(ip):
                    servers.append(ip)
        elif _IP_RE.match(stripped):
            # Continuation line — additional DNS server
            servers.append(stripped)

    return {"mode": mode, "servers": servers}


def _lock_dns_windows() -> None:
    """Lock DNS on Windows via netsh per-adapter settings + firewall rule."""
    _require_admin_windows()

    if _dns_redirected_by_tor:
        # TorDNSRedirect already backed up and set adapter DNS — skip those
        # steps to avoid overwriting a backup that already holds 127.0.0.1.
        # Still add the firewall rules as defense-in-depth.
        _console.print(
            "[cyan]DNS already redirected by TorDNSRedirect — adding firewall rules only.[/cyan]"
        )
    else:
        adapters = _get_connected_adapters()
        backup: dict[str, Any] = {}

        for adapter in adapters:
            result = _run_win("netsh", "interface", "ip", "show", "dns", f'"{adapter}"')
            backup[adapter] = _parse_dns_config(result.stdout)

        # Save backup
        backup_path = _DNS_BACKUP_WINDOWS
        backup_path.parent.mkdir(parents=True, exist_ok=True)
        backup_path.write_text(json.dumps(backup, indent=2))
        _console.print(f"[green]DNS backup saved to {backup_path}[/green]")

        # Set DNS to 127.0.0.1 on each adapter
        for adapter in adapters:
            _run_win(
                "netsh", "interface", "ip", "set", "dns",
                f'"{adapter}"', "static", "127.0.0.1",
            )
            _console.print(f"[cyan]DNS set to 127.0.0.1 on adapter: {adapter}[/cyan]")

    # Block outbound DNS (port 53) except to 127.0.0.1
    _run_win(
        "netsh", "advfirewall", "firewall", "add", "rule",
        "name=NetCloak-BlockDNS",
        "dir=out", "action=block",
        "protocol=UDP", "remoteport=53",
        "remoteip=!127.0.0.1",
        "enable=yes",
    )
    _run_win(
        "netsh", "advfirewall", "firewall", "add", "rule",
        "name=NetCloak-BlockDNS-TCP",
        "dir=out", "action=block",
        "protocol=TCP", "remoteport=53",
        "remoteip=!127.0.0.1",
        "enable=yes",
    )

    _console.print("[green]DNS lockdown active on Windows.[/green]")


def _unlock_dns_windows() -> None:
    """Restore per-adapter DNS from backup and remove firewall rules."""
    _require_admin_windows()

    if _dns_redirected_by_tor:
        # TorDNSRedirect.stop() handles DNS restore — skip to avoid double-restore.
        # Still remove the firewall rules we added.
        _console.print(
            "[cyan]DNS restore handled by TorDNSRedirect — removing firewall rules only.[/cyan]"
        )
    else:
        backup_path = _DNS_BACKUP_WINDOWS
        if backup_path.exists():
            try:
                backup = json.loads(backup_path.read_text())
                for adapter, config in backup.items():
                    mode = config.get("mode", "dhcp")
                    servers: list[str] = config.get("servers", [])

                    if mode == "static" and servers:
                        # Restore primary DNS server
                        _run_win(
                            "netsh", "interface", "ip", "set", "dns",
                            f'"{adapter}"', "static", servers[0],
                        )
                        # Restore additional DNS servers
                        for idx, server in enumerate(servers[1:], start=2):
                            _run_win(
                                "netsh", "interface", "ip", "add", "dns",
                                f'"{adapter}"', server, f"index={idx}",
                            )
                        _console.print(
                            f"[cyan]DNS restored (static: {', '.join(servers)}) on adapter: {adapter}[/cyan]"
                        )
                    else:
                        _run_win(
                            "netsh", "interface", "ip", "set", "dns",
                            f'"{adapter}"', "dhcp",
                        )
                        _console.print(f"[cyan]DNS restored (DHCP) on adapter: {adapter}[/cyan]")
                backup_path.unlink(missing_ok=True)
            except Exception as exc:
                _console.print(f"[yellow]DNS restore failed:[/yellow] {exc}")
        else:
            _console.print("[yellow]No Windows DNS backup found.[/yellow]")

    # Remove firewall rules (always — added by lock_dns regardless of tor flag)
    for rule in ("NetCloak-BlockDNS", "NetCloak-BlockDNS-TCP"):
        _run_win("netsh", "advfirewall", "firewall", "delete", "rule", f"name={rule}")

    _console.print("[green]DNS lockdown removed on Windows.[/green]")
