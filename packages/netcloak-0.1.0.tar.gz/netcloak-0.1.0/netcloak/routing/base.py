"""Abstract routing base class — implemented by LinuxRouter and WindowsRouter."""
from __future__ import annotations

from abc import ABC, abstractmethod


class BaseRouter(ABC):
    """Platform-agnostic routing interface.

    Concrete implementations:
    - LinuxRouter  (routing/iptables.py)   — iptables / Linux
    - WindowsRouter (routing/windows_routing.py) — netsh advfirewall / Windows
    """

    @abstractmethod
    def check_root_or_admin(self) -> None:
        """Raise PermissionError with a platform-appropriate message if the
        process does not have the required elevated privileges."""
        ...

    @abstractmethod
    def enable_kill_switch(self) -> None:
        """Block all traffic except through Tor."""
        ...

    @abstractmethod
    def disable_kill_switch(self) -> None:
        """Restore normal traffic flow and remove all NetCloak rules."""
        ...

    @abstractmethod
    def route_through_tor(self) -> None:
        """Configure the system to route traffic through Tor."""
        ...

    @abstractmethod
    def is_kill_switch_active(self) -> bool:
        """Return True if the kill switch is currently enforced."""
        ...
