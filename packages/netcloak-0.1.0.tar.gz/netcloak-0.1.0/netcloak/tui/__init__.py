"""NetCloak TUI — Textual-based live dashboard."""
from netcloak.tui.app import NetCloakApp

__all__ = ["NetCloakApp"]
