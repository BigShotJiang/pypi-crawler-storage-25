"""NetCloak TUI — Textual App with hybrid refresh (fast state.json poll + slow active checks)."""
from __future__ import annotations

import json
import os
import shlex
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

from textual.app import App, ComposeResult
from textual.containers import Horizontal
from textual.widgets import Footer, Header, Input, Static

from netcloak.tui.widgets import LogPanel, NetworkStatusPanel, ProxyPoolPanel


class NetCloakApp(App):
    """Live NetCloak dashboard — reads state from a running netcloak session."""

    TITLE = "NetCloak Dashboard"

    CSS = """
#panels {
    height: 1fr;
}

#left-panel {
    width: 1fr;
    border: solid green;
}

#right-panel {
    width: 1fr;
    border: solid cyan;
}

#log-area {
    height: 10;
}

#command-input {
    dock: bottom;
    height: 3;
    border: solid green;
}
"""

    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__()
        self._cfg = config

        # Resolve state.json path using the same logic as cli._state_path()
        if sys.platform == "win32":
            raw = config.get("tor", {}).get("data_dir_windows", r"%APPDATA%\NetCloak\tor")
        else:
            raw = config.get("tor", {}).get("data_dir", "/tmp/netcloak_tor")
        data_dir = os.path.expandvars(raw) or os.path.join(tempfile.gettempdir(), "netcloak_tor")
        self._state_path = Path(data_dir) / "state.json"

        # Intervals: slow from config, fast hardcoded to 2s
        self._slow_interval = float(
            config.get("monitor", {}).get("check_interval_sec", 30)
        )
        self._fast_interval = 2.0

        # Mutable state updated by slow poll worker
        self._leak_data: dict[str, Any] | None = None
        self._local_alive: bool | None = None

    def compose(self) -> ComposeResult:
        yield Header()
        yield Horizontal(
            NetworkStatusPanel(id="net-status"),
            ProxyPoolPanel(id="proxy-pool"),
            id="panels",
        )
        yield LogPanel(id="log-area")
        yield Input(placeholder="Type a command (start, stop, status, rotate, bridges)...", id="command-input")
        yield Footer()

    def on_mount(self) -> None:
        """Set up refresh timers and trigger immediate first polls."""
        self.set_interval(self._fast_interval, self._fast_poll)
        self.set_interval(self._slow_interval, self._slow_poll)
        # Immediate first update from state.json
        self._fast_poll()
        # Immediate first slow poll (active checks) in a worker thread
        self.run_worker(self._slow_poll_worker, thread=True)
        # Log startup message
        log_panel = self.query_one("#log-area", LogPanel)
        log_panel.append_line("[green]NetCloak TUI started. Type commands below.[/green]")

    def _fast_poll(self) -> None:
        """Read state.json and update both panels. Runs on the main thread every 2s."""
        if self._state_path.exists():
            try:
                state: dict[str, Any] = json.loads(self._state_path.read_text())
            except Exception:
                state = {"mode": "unknown", "tor_running": False}
                try:
                    log_panel = self.query_one("#log-area", LogPanel)
                    log_panel.append_line("[yellow]Could not read state.json[/yellow]")
                except Exception:
                    pass
        else:
            state = {"mode": "unknown", "tor_running": False}

        self.query_one("#net-status", NetworkStatusPanel).update_data(
            state, self._leak_data, self._local_alive
        )
        self.query_one("#proxy-pool", ProxyPoolPanel).update_data(
            state.get("proxy_pool")
        )

    def _slow_poll(self) -> None:
        """Dispatch a worker thread for active checks (run_leak_check, check_local_proxy_port)."""
        self.run_worker(self._slow_poll_worker, thread=True)

    def _slow_poll_worker(self) -> None:
        """Worker method: runs active network checks in a background thread.

        Imports are deferred inside this method so that importing netcloak.cli
        (or the tui module) does NOT trigger textual slow imports on every invocation.
        The worker calls call_from_thread(_fast_poll) when done so the UI updates
        immediately with the fresh leak/proxy data.
        """
        # Deferred imports — MUST stay inside this method body, not at module top-level
        from netcloak.status.checker import check_local_proxy_port, run_leak_check

        socks_port = self._cfg.get("tor", {}).get("socks_port", 9050)
        local_port = self._cfg.get("proxy", {}).get("local_port", 8080)

        # Read kill_switch_active from state.json so we can pass it to run_leak_check.
        # This lets the IP-hidden logic correctly handle Wintun routing all traffic through Tor.
        kill_switch_active = False
        try:
            if self._state_path.exists():
                state_data = json.loads(self._state_path.read_text())
                kill_switch_active = bool(state_data.get("kill_switch_active", False))
        except Exception:
            pass

        try:
            self._leak_data = run_leak_check(
                socks_port=socks_port,
                kill_switch_active=kill_switch_active,
            )
        except Exception:
            self._leak_data = None

        try:
            alive, _ = check_local_proxy_port(port=local_port)
            self._local_alive = alive
        except Exception:
            self._local_alive = None

        # Schedule a UI refresh on the main thread with the new data
        self.call_from_thread(self._fast_poll)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle command input — dispatch to netcloak CLI via subprocess."""
        raw = event.value.strip()
        if not raw:
            return
        event.input.value = ""  # Clear the input field

        log = self.query_one("#log-area", LogPanel)  # main thread — safe
        log.append_line(f"[bold]> {raw}[/bold]")

        # Parse the command — strip "netcloak" prefix if user types it
        cmd = raw
        if cmd.startswith("netcloak "):
            cmd = cmd[len("netcloak "):]

        # Prevent running 'tui' from within tui (infinite recursion)
        if cmd.strip() == "tui":
            log.append_line("[yellow]Cannot launch TUI from within TUI.[/yellow]")
            return

        # Run as subprocess to capture output — pass log widget to worker
        self.run_worker(lambda: self._run_command(cmd, log), thread=True)

    def _run_command(self, cmd: str, log: "LogPanel") -> None:
        """Execute a netcloak CLI command in a subprocess and capture output."""
        try:
            # Build the full command — use sys.executable to ensure same Python
            full_cmd = [sys.executable, "-m", "netcloak", *shlex.split(cmd)]
            result = subprocess.run(
                full_cmd,
                capture_output=True,
                text=True,
                timeout=60,
            )
            # Show stdout lines
            if result.stdout:
                for line in result.stdout.strip().splitlines():
                    self.call_from_thread(log.append_line, line)
            # Show stderr lines
            if result.stderr:
                for line in result.stderr.strip().splitlines():
                    self.call_from_thread(log.append_line, f"[red]{line}[/red]")
            if result.returncode != 0 and not result.stdout and not result.stderr:
                self.call_from_thread(log.append_line, f"[red]Command exited with code {result.returncode}[/red]")
        except subprocess.TimeoutExpired:
            self.call_from_thread(log.append_line, "[red]Command timed out after 60s[/red]")
        except Exception as exc:
            self.call_from_thread(log.append_line, f"[red]Error: {exc}[/red]")
