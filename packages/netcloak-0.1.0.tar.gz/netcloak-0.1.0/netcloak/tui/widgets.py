"""NetCloak TUI panel widgets — NetworkStatusPanel, ProxyPoolPanel, and LogPanel."""
from __future__ import annotations

from datetime import datetime
from typing import Any

from rich.table import Table
from textual.widgets import RichLog, Static


class NetworkStatusPanel(Static):
    """Left panel: displays real-time network status from state.json and leak checks."""

    DEFAULT_CSS = """
    NetworkStatusPanel {
        height: auto;
        width: 1fr;
    }
    """

    def update_data(
        self,
        state: dict[str, Any],
        leak_data: dict[str, Any] | None,
        local_alive: bool | None,
    ) -> None:
        """Rebuild the Rich table and push it to the widget for rendering.

        Args:
            state:       Parsed state.json dict (from fast poll).
            leak_data:   Result of run_leak_check() — may be None before first slow poll.
            local_alive: Result of check_local_proxy_port() — may be None before first slow poll.
        """
        table = Table(title="Network Status", border_style="green", show_lines=True)
        table.add_column("Property", style="bold", min_width=14)
        table.add_column("Value")

        # Mode
        mode = state.get("mode", "unknown")
        table.add_row("Mode", mode)

        # IP Hidden — use leak_data if available, else "Checking..."
        if leak_data is not None:
            ip_hidden = leak_data.get("ip_hidden", False)
            ip_hidden_str = "[green]Yes[/green]" if ip_hidden else "[red]No[/red]"
        else:
            ip_hidden_str = "[dim]Checking...[/dim]"
        table.add_row("IP Hidden", ip_hidden_str)

        # Tor Active — prefer leak_data, fall back to state
        if leak_data is not None:
            tor_active = leak_data.get("tor_active", False)
            tor_active_str = "[green]Yes[/green]" if tor_active else "[red]No[/red]"
        else:
            tor_running = state.get("tor_running", False)
            tor_active_str = "[green]Yes[/green]" if tor_running else "[red]No[/red]"
        table.add_row("Tor Active", tor_active_str)

        # Kill Switch
        kill_switch = state.get("kill_switch_active", False)
        kill_switch_str = "[green]Active[/green]" if kill_switch else "[yellow]Inactive[/yellow]"
        table.add_row("Kill Switch", kill_switch_str)

        # Local Proxy
        port = state.get("local_proxy_port", 8080)
        if local_alive is None:
            proxy_str = "[dim]Checking...[/dim]"
        elif local_alive:
            proxy_str = f"[green]Up (127.0.0.1:{port})[/green]"
        else:
            proxy_str = "[red]Down[/red]"
        table.add_row("Local Proxy", proxy_str)

        # Last Check
        last_check = state.get("last_check", "N/A") or "N/A"
        table.add_row("Last Check", last_check)

        self.update(table)


class ProxyPoolPanel(Static):
    """Right panel: displays proxy pool status from state.json."""

    DEFAULT_CSS = """
    ProxyPoolPanel {
        height: auto;
        width: 1fr;
    }
    """

    def update_data(self, pool: dict[str, Any] | None) -> None:
        """Rebuild the Rich table and push it to the widget for rendering.

        Args:
            pool: The proxy_pool dict from state.json, or None if unavailable.
        """
        table = Table(title="Proxy Pool", border_style="cyan", show_lines=True)
        table.add_column("Property", style="bold", min_width=14)
        table.add_column("Value")

        if pool is None:
            table.add_row("Pool Size", "[dim]N/A[/dim]")
            table.add_row("Active Proxy", "[dim]N/A[/dim]")
            table.add_row("Latency", "[dim]N/A[/dim]")
            table.add_row("Country", "[dim]N/A[/dim]")
            table.add_row("Pool Age", "[dim]N/A[/dim]")
        else:
            current = pool.get("current_proxy")

            # Pool Size
            table.add_row("Pool Size", str(pool.get("total", 0)))

            # Active Proxy
            if current:
                proxy_str = f"{current.get('ip')}:{current.get('port')}"
            else:
                proxy_str = "None"
            table.add_row("Active Proxy", proxy_str)

            # Latency
            if current:
                latency = current.get("latency_ms", "?")
                table.add_row("Latency", f"{latency} ms")
            else:
                table.add_row("Latency", "[dim]N/A[/dim]")

            # Country
            if current:
                country = current.get("country", "Unknown")
            else:
                country = "Unknown"
            table.add_row("Country", country)

            # Pool Age
            age = pool.get("pool_age_seconds")
            age_str = f"{age}s" if age is not None else "N/A"
            table.add_row("Pool Age", age_str)

        self.update(table)


class LogPanel(RichLog):
    """Scrolling log feed with timestamped entries."""

    DEFAULT_CSS = """
    LogPanel {
        height: 100%;
        border: solid white;
    }
    """

    def append_line(self, text: str) -> None:
        """Add a timestamped line to the log."""
        ts = datetime.now().strftime("%H:%M:%S")
        self.write(f"[dim]{ts}[/dim] {text}")
