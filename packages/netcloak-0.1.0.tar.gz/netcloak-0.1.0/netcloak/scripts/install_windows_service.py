# NetCloak Windows Service
# Requires: pip install pywin32
#
# Usage:
#   python install_windows_service.py install   — register as a Windows service
#   python install_windows_service.py start     — start the service
#   python install_windows_service.py stop      — stop the service
#   python install_windows_service.py remove    — unregister the service
#
# Must be run from an elevated (Administrator) command prompt.

import subprocess
import sys

try:
    import win32service
    import win32serviceutil
    import win32event
    import servicemanager
except ImportError:
    print("ERROR: pywin32 is required. Install it with: pip install pywin32")
    sys.exit(1)


class NetCloakService(win32serviceutil.ServiceFramework):
    """Windows service wrapper for NetCloak."""

    _svc_name_ = "NetCloakService"
    _svc_display_name_ = "NetCloak Privacy Routing Service"
    _svc_description_ = (
        "Routes traffic through Tor and proxy chain for privacy. "
        "Manages kill switch and DNS lockdown. "
        "For authorized security research use only."
    )

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)
        self._process: subprocess.Popen | None = None

    def SvcStop(self):
        """Called by SCM to stop the service."""
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        # Send netcloak stop
        try:
            subprocess.run(
                [sys.executable, "-m", "netcloak", "stop"],
                check=False,
                capture_output=True,
            )
        except Exception:
            pass
        if self._process:
            self._process.terminate()
            try:
                self._process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self._process.kill()
        win32event.SetEvent(self.stop_event)

    def SvcDoRun(self):
        """Called by SCM to start the service."""
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, ""),
        )
        self._process = subprocess.Popen(
            [sys.executable, "-m", "netcloak", "start"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        # Wait for stop signal or process exit
        win32event.WaitForSingleObject(self.stop_event, win32event.INFINITE)


if __name__ == "__main__":
    if len(sys.argv) == 1:
        print(
            "Usage:\n"
            "  python install_windows_service.py install\n"
            "  python install_windows_service.py start\n"
            "  python install_windows_service.py stop\n"
            "  python install_windows_service.py remove\n"
        )
        sys.exit(0)
    win32serviceutil.HandleCommandLine(NetCloakService)
