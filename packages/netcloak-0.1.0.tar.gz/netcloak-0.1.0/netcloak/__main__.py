"""Allows running NetCloak as ``python -m netcloak``."""
from netcloak.cli import app

if __name__ == "__main__":
    app()
