"""Platform detection and privilege check helpers."""
from __future__ import annotations

import os
import sys


def get_platform_name() -> str:
    """Return the current platform as a lowercase string.

    Returns one of: "windows", "linux", "darwin".
    """
    if sys.platform == "win32":
        return "windows"
    elif sys.platform.startswith("linux"):
        return "linux"
    elif sys.platform == "darwin":
        return "darwin"
    return sys.platform


def check_privileges() -> bool:
    """Return True if the current process has admin/root privileges.

    On Windows: uses ctypes IsUserAnAdmin().
    On Linux/macOS: checks os.geteuid() == 0.
    """
    if sys.platform == "win32":
        try:
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        except Exception:
            return False
    else:
        return os.geteuid() == 0


def require_admin_or_exit() -> None:
    """Raise PermissionError if the current process lacks admin/root privileges.

    Raises:
        PermissionError: with a platform-specific message if not elevated.
    """
    if not check_privileges():
        if sys.platform == "win32":
            raise PermissionError(
                "NetCloak requires Administrator privileges on Windows. "
                "Re-run from an elevated command prompt."
            )
        else:
            raise PermissionError(
                "NetCloak requires root privileges. Run with sudo."
            )
