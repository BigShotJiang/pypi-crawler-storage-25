"""Network utility functions — thin public API over existing internal helpers."""
from __future__ import annotations


def get_real_ip(timeout: int = 10) -> str:
    """Return the machine's real public IP address (direct, no proxy).

    Delegates to netcloak.status.checker.get_real_ip() to avoid duplication.
    """
    from netcloak.status.checker import get_real_ip as _get_real_ip
    return _get_real_ip(timeout=timeout)


def enumerate_adapters() -> list[str]:
    """Return names of all currently connected network adapters.

    On Windows: enumerates via netsh (Connected + Enabled adapters).
    On other platforms: returns an empty list.

    Delegates to netcloak.routing.dns_tor._get_connected_adapters() for
    public API access.
    """
    import sys
    if sys.platform != "win32":
        return []
    from netcloak.routing.dns_tor import _get_connected_adapters
    return _get_connected_adapters()
