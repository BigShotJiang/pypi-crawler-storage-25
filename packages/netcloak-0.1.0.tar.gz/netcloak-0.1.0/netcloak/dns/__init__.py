"""DNS management package — public API for DNS redirection and leak testing."""
