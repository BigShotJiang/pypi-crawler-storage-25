"""DNS leak testing — wraps status/checker.py for clean public API."""
from netcloak.status.checker import run_leak_check
from netcloak.routing.dns import check_dns_leak

__all__ = ["run_leak_check", "check_dns_leak"]
