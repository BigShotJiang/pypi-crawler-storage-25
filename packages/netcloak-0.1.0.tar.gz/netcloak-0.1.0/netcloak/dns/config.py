"""OS DNS configuration — wraps routing/dns.py for clean public API."""
from netcloak.routing.dns import lock_dns, unlock_dns, mark_dns_redirected, clear_dns_redirected


def lock_dns_os(tor_dns_port: int = 9053) -> None:
    """Lock DNS to Tor on the current platform."""
    lock_dns(tor_dns_port=tor_dns_port)


def unlock_dns_os() -> None:
    """Restore DNS settings on the current platform."""
    unlock_dns()


__all__ = ["lock_dns_os", "unlock_dns_os", "mark_dns_redirected", "clear_dns_redirected"]
