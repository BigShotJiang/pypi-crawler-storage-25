"""Re-exports TorDNSRedirect from routing/dns_tor.py for public API access."""
from netcloak.routing.dns_tor import TorDNSRedirect

__all__ = ["TorDNSRedirect"]
