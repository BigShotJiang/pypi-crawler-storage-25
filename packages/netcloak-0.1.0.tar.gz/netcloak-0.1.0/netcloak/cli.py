"""NetCloak CLI — Typer + Rich entry point."""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any

import requests
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

app = typer.Typer(
    name="netcloak",
    help="NetCloak — privacy and traffic routing tool for authorized security research.",
    add_completion=False,
)

_console = Console()
_err = Console(stderr=True)


def _load_cfg() -> dict:
    from netcloak.config import load_config
    return load_config()


def _data_dir(cfg: dict) -> str:
    """Return the platform-appropriate data directory from config."""
    if sys.platform == "win32":
        raw = cfg["tor"].get("data_dir_windows", r"%APPDATA%\NetCloak\tor")
    else:
        raw = cfg["tor"].get("data_dir", "/tmp/netcloak_tor")
    return os.path.expandvars(raw) or os.path.join(tempfile.gettempdir(), "netcloak_tor")


def _state_path(cfg: dict) -> Path:
    return Path(_data_dir(cfg)) / "state.json"


def _require_elevated_or_exit() -> None:
    """Exit with a clear message if the process lacks elevated privileges."""
    from netcloak.core.platform import get_router
    try:
        get_router().check_root_or_admin()
    except PermissionError as exc:
        _err.print(
            Panel(
                f"[red]{exc}[/red]",
                title="Permission Denied",
                border_style="red",
            )
        )
        raise typer.Exit(code=1)
    except NotImplementedError as exc:
        _err.print(Panel(f"[red]{exc}[/red]", title="Unsupported Platform", border_style="red"))
        raise typer.Exit(code=1)


@app.command()
def start(
    mode: str = typer.Option("tor", "--mode", "-m", help="Routing mode: tor, proxy, or auto."),
    proxy_flag: bool = typer.Option(False, "--proxy", help="Shorthand for --mode proxy."),
    auto_flag: bool = typer.Option(False, "--auto", help="Shorthand for --mode auto."),
) -> None:
    """Fetch + validate proxies, start Tor, enable kill switch, lock DNS, start monitor."""
    # Resolve shorthand flags
    if proxy_flag and auto_flag:
        _err.print("[red]Error:[/red] Cannot use --proxy and --auto together.")
        raise typer.Exit(code=1)
    if proxy_flag:
        mode = "proxy"
    if auto_flag:
        mode = "auto"

    # Validate mode
    if mode not in ("tor", "proxy", "auto"):
        _err.print(f"[red]Error:[/red] Invalid mode '{mode}'. Choose one of: tor, proxy, auto.")
        raise typer.Exit(code=1)

    _require_elevated_or_exit()
    cfg = _load_cfg()

    _console.print(Panel(f"[bold cyan]NetCloak — Starting ({mode} mode)[/bold cyan]", border_style="cyan"))

    # 0. Connectivity pre-flight
    from netcloak.status.checker import check_connectivity
    connected, conn_reason = check_connectivity()
    if not connected:
        _console.print(
            f"[yellow]Warning:[/yellow] No internet connectivity detected ({conn_reason}).\n"
            "Tor may fail to bootstrap. Proceeding anyway."
        )

    tor_cfg = cfg["tor"]
    tor = None
    tor_started = False
    _early_rotator = None

    if mode in ("tor", "auto"):
        # 1. Start Tor (with bridge support)
        from netcloak.tor.manager import TorManager, check_obfs4proxy

        use_bridges = tor_cfg.get("use_bridges", False)
        bridges: list[str] = tor_cfg.get("bridges", [])
        bridge_type: str = tor_cfg.get("bridge_type", "obfs4")

        if use_bridges:
            if not check_obfs4proxy():
                _console.print(
                    "[yellow]Warning:[/yellow] use_bridges=true but obfs4proxy not found.\n"
                    "  Install: [bold]sudo apt install obfs4proxy[/bold] (Debian/Ubuntu)\n"
                    "           [bold]brew install obfs4proxy[/bold] (macOS)"
                )
            if not bridges:
                _console.print(
                    "[yellow]Warning:[/yellow] No bridges configured — add bridge strings to config.toml under [tor] bridges = [...]"
                )

        tor = TorManager(
            socks_port=tor_cfg["socks_port"],
            control_port=tor_cfg["control_port"],
            dns_port=tor_cfg.get("dns_port", 9053),
            trans_port=tor_cfg.get("trans_port", 9040),
            data_dir=_data_dir(cfg),
            binary_path=tor_cfg.get("binary_path", ""),
            use_bridges=use_bridges,
            bridge_type=bridge_type,
            bridges=bridges,
        )
        if not tor.start():
            if mode == "tor":
                _err.print("[red]Failed to start Tor. Aborting.[/red]")
                raise typer.Exit(code=1)
            else:
                # auto mode: fall through to proxy-only
                _console.print("[yellow]Warning:[/yellow] Tor failed to start — falling back to proxy-only mode.")
                tor = None
                mode = "proxy"
        else:
            tor_started = True

            # 2. Load proxy pool BEFORE kill switch — validation needs outbound access.
            #    Fetch goes through Tor SOCKS5 (kill switch not yet active).
            from netcloak.proxy.rotator import ProxyRotator as _RotatorEarly
            _early_rotator = _RotatorEarly(cfg)
            _early_rotator.load_pool(
                preferred_countries=cfg.get("proxy", {}).get("preferred_countries") or None,
                exclude_countries=cfg.get("proxy", {}).get("exclude_countries") or None,
            )

            # 3. Enable kill switch + route through Tor (platform-aware)
            if cfg["routing"]["kill_switch"]:
                from netcloak.core.platform import get_router
                router = get_router()
                if sys.platform.startswith("linux"):
                    from netcloak.routing.iptables import LinuxRouter
                    router = LinuxRouter(
                        socks_port=cfg["tor"]["socks_port"],
                        trans_port=cfg["tor"].get("trans_port", 9040),
                        dns_port=cfg["tor"].get("dns_port", 9053),
                    )
                elif sys.platform == "win32":
                    import shutil as _shutil
                    from netcloak.routing.windows_routing import WindowsRouter
                    _tor_bin = (
                        tor_cfg.get("binary_path", "")
                        or _shutil.which("tor.exe")
                        or ""
                    )
                    router = WindowsRouter(
                        socks_port=cfg["tor"]["socks_port"],
                        data_dir=_data_dir(cfg),
                        wintun_path=cfg.get("routing", {}).get("wintun_path", ""),
                        tor_binary=_tor_bin,
                    )
                router.enable_kill_switch()
                router.route_through_tor()

            # 3. Lock DNS (platform-aware via dns.py dispatcher)
            if cfg["routing"]["dns_lock"]:
                from netcloak.routing.dns import lock_dns
                lock_dns(tor_dns_port=cfg["tor"].get("dns_port", 9053))

            # Verify DNS is actually routing through Tor DNSPort after lock.
            from netcloak.status.checker import verify_dns_through_tor
            _dns_ok, _dns_reason = verify_dns_through_tor(dns_port=cfg["tor"].get("dns_port", 9053))
            if not _dns_ok:
                _console.print(
                    f"[yellow]Warning:[/yellow] DNS not routing through Tor yet: {_dns_reason}\n"
                    "[yellow]DNS may leak until Tor fully bootstraps.[/yellow]"
                )
            else:
                _console.print("[green]DNS routing through Tor DNSPort verified.[/green]")

    # 4. Proxy pool — use the rotator loaded before kill switch (tor mode)
    #    or create fresh for proxy/auto mode (kill switch not active in that path).
    from netcloak.proxy.rotator import ProxyRotator

    if tor_started and _early_rotator is not None:
        rotator = _early_rotator  # already fetched + validated pre-kill-switch
        pool_size = len(rotator._pool)
    else:
        rotator = ProxyRotator(cfg)
        preferred = cfg.get("proxy", {}).get("preferred_countries", [])
        excluded = cfg.get("proxy", {}).get("exclude_countries", [])
        pool_size = rotator.load_pool(
            preferred_countries=preferred or None,
            exclude_countries=excluded or None,
        )

    # 5. Generate proxychains config (Linux only — proxychains4 not available on Windows)
    proxychains_conf = str(Path(_data_dir(cfg)) / "proxychains.conf")
    if not sys.platform == "win32":
        from netcloak.proxy.proxychains import generate_proxychains_conf
        current_proxy = rotator.get_current()
        pool_for_chains = [current_proxy] if current_proxy else []
        generate_proxychains_conf(
            proxies=pool_for_chains,
            output_path=proxychains_conf,
            chain_type=cfg["proxy"].get("chain_type", "dynamic"),
            chain_length=cfg["proxy"].get("chain_length", 2),
        )
        _console.print(f"[cyan]ProxyChains config written to {proxychains_conf}[/cyan]")

    # 6. Write initial state.json
    data_dir_path = Path(_data_dir(cfg))
    data_dir_path.mkdir(parents=True, exist_ok=True)
    state: dict[str, Any] = {
        "tor_running": tor_started,
        "mode": mode,
        "tunnel_ip": None,
        "last_check": None,
        "kill_switch_active": cfg["routing"]["kill_switch"],
        "consecutive_failures": 0,
        "proxy_pool": rotator.get_pool_status(),
        "platform": sys.platform,
        "local_proxy_port": cfg.get("proxy", {}).get("local_port", 8080),
    }
    sp = _state_path(cfg)
    sp.write_text(json.dumps(state, indent=2))

    # 7. Start health monitor
    from netcloak.core.monitor import HealthMonitor

    monitor = HealthMonitor(tor_manager=tor, rotator=rotator, config=cfg, mode=mode)
    monitor.start()

    # 8. Start traffic padder
    from netcloak.routing.obfuscation import TrafficPadder

    padder = TrafficPadder(cfg)
    padder.start()
    if padder.enabled:
        _console.print("[cyan]Traffic padding enabled.[/cyan]")

    # 9. Print status
    _console.print(
        Panel(
            f"[green]Mode:[/green] {mode}\n"
            f"[green]Proxy pool:[/green] {pool_size} proxies loaded\n"
            f"[green]ProxyChains conf:[/green] {proxychains_conf}\n"
            f"[green]State:[/green] {sp}\n"
            f"[green]Platform:[/green] {sys.platform}",
            title="NetCloak Started",
            border_style="green",
        )
    )
    _print_status_table(cfg)


@app.command()
def stop() -> None:
    """Disable kill switch, unlock DNS, stop Tor."""
    _require_elevated_or_exit()
    cfg = _load_cfg()

    _console.print(Panel("[bold yellow]NetCloak — Stopping[/bold yellow]", border_style="yellow"))

    # Stop traffic padder (daemon thread, stop_event signals graceful exit)
    from netcloak.routing.obfuscation import TrafficPadder
    TrafficPadder(cfg).stop()

    # Kill switch + unroute (platform-aware)
    if sys.platform.startswith("linux"):
        from netcloak.routing.iptables import disable_kill_switch
        disable_kill_switch()
    elif sys.platform == "win32":
        from netcloak.routing.windows_routing import WindowsRouter
        WindowsRouter(data_dir=_data_dir(cfg)).disable_kill_switch()

    # DNS unlock (platform-aware via dispatcher)
    from netcloak.routing.dns import unlock_dns
    unlock_dns()

    # Stop Tor
    from netcloak.tor.manager import TorManager
    tor = TorManager(
        socks_port=cfg["tor"]["socks_port"],
        control_port=cfg["tor"]["control_port"],
        data_dir=_data_dir(cfg),
        binary_path=cfg["tor"].get("binary_path", ""),
    )
    tor.stop()

    # Remove state.json
    _state_path(cfg).unlink(missing_ok=True)

    _console.print(Panel("[green]NetCloak stopped. Network restored.[/green]", border_style="green"))


@app.command()
def status(
    output_json: bool = typer.Option(False, "--json", help="Output status as JSON."),
) -> None:
    """Show current status — reads state.json if available."""
    cfg = _load_cfg()
    sp = _state_path(cfg)

    if not sp.exists():
        if output_json:
            _console.print_json(json.dumps({"running": False, "reason": f"No state file at {sp}"}))
        else:
            _console.print(
                Panel(
                    "[yellow]NetCloak is not running.[/yellow]\n"
                    f"(No state file found at {sp})",
                    title="NetCloak Status",
                    border_style="yellow",
                )
            )
        return

    try:
        saved = json.loads(sp.read_text())
    except Exception as exc:
        _err.print(f"[yellow]Could not parse state.json:[/yellow] {exc}")
        saved = {}

    if output_json:
        _print_status_json(cfg, saved)
    else:
        _print_status_table(cfg, saved_state=saved)


@app.command()
def rotate() -> None:
    """Rotate Tor circuit (NEWNYM) when in tor mode, or rotate proxy pool otherwise."""
    cfg = _load_cfg()
    sp = _state_path(cfg)

    if not sp.exists():
        _err.print(
            Panel(
                "[yellow]NetCloak does not appear to be running.[/yellow]\n"
                "Start with [bold]sudo netcloak start[/bold] first.",
                title="Not Running",
                border_style="yellow",
            )
        )
        raise typer.Exit(code=1)

    try:
        saved = json.loads(sp.read_text())
    except Exception as exc:
        _err.print(f"[yellow]Could not read state.json:[/yellow] {exc}")
        saved = {}

    tor_running = saved.get("tor_running", False)

    if tor_running:
        # Tor mode: issue NEWNYM to rotate Tor circuit
        try:
            from netcloak.tor.controller import TorController
            tor_cfg = cfg["tor"]
            controller = TorController(control_port=tor_cfg["control_port"])
            controller.connect()
            controller.new_identity()
            exit_ip: str | None = None
            try:
                exit_ip = controller.get_exit_ip()
            except Exception:
                pass
            controller.disconnect()
            msg = "[green]Tor circuit rotated (NEWNYM sent).[/green]"
            if exit_ip:
                msg += f"\n[green]New exit IP:[/green] {exit_ip}"
            _console.print(Panel(msg, title="Tor Circuit Rotated", border_style="green"))
        except Exception as exc:
            _err.print(f"[yellow]Warning:[/yellow] Tor NEWNYM failed: {exc}")
        return

    # Proxy mode: rotate proxy pool
    from netcloak.proxy.rotator import ProxyRotator
    rotator = ProxyRotator(cfg)
    rotator.load_pool()
    new_proxy = rotator.rotate()

    # Regenerate proxychains config (Linux only)
    proxychains_conf = str(Path(_data_dir(cfg)) / "proxychains.conf")
    if not sys.platform == "win32":
        from netcloak.proxy.proxychains import generate_proxychains_conf
        pool_for_chains = [new_proxy] if new_proxy else []
        generate_proxychains_conf(
            proxies=pool_for_chains,
            output_path=proxychains_conf,
            chain_type=cfg["proxy"].get("chain_type", "dynamic"),
            chain_length=cfg["proxy"].get("chain_length", 2),
        )

    if new_proxy:
        rotation_interval = cfg.get("proxy", {}).get("rotation_interval_min", 0)
        rotation_line = (
            f"[green]Auto-rotation:[/green] ON (every {rotation_interval} min)"
            if rotation_interval > 0
            else "[yellow]Auto-rotation:[/yellow] OFF"
        )
        _console.print(
            Panel(
                f"[green]Active proxy:[/green] {new_proxy['ip']}:{new_proxy['port']}\n"
                f"[green]Country:[/green] {new_proxy.get('country', '?')}\n"
                f"[green]Latency:[/green] {new_proxy.get('latency_ms', '?')} ms\n"
                f"[green]Anonymity:[/green] {new_proxy.get('anonymity', '?')}\n"
                f"[green]ProxyChains conf:[/green] {proxychains_conf}\n"
                f"{rotation_line}",
                title="Proxy Rotated",
                border_style="green",
            )
        )
        try:
            saved["proxy_pool"] = rotator.get_pool_status()
            sp.write_text(json.dumps(saved, indent=2))
        except Exception:
            pass
    else:
        _err.print("[red]No valid proxies available after rotation.[/red]")


@app.command()
def bridges(
    save: bool = typer.Option(
        False, "--save", help="Save fetched bridges to config.toml automatically."
    ),
    add: str = typer.Option(
        "", "--add", help="Add a custom bridge string to config.toml (paste from bridges.torproject.org).",
    ),
) -> None:
    """Fetch obfs4 bridges from the Tor Project, or add a custom bridge."""
    cfg = _load_cfg()

    # --add: write a user-supplied bridge string directly to config.toml
    if add.strip():
        _save_bridges_to_config([add.strip()])
        _console.print(f"[green]Bridge added to config.toml.[/green]")
        _console.print("[dim]Restart NetCloak with use_bridges = true in [tor] to activate.[/dim]")
        return

    # Route through Tor SOCKS5 when NetCloak is running — kill switch blocks
    # direct outbound connections, so requests without a proxy will fail with
    # getaddrinfo / connection errors.  Use socks5h:// so hostname resolution
    # also happens inside Tor (not locally).
    sp = _state_path(cfg)
    proxies: dict[str, str] | None = None
    if sp.exists():
        socks_port = cfg["tor"].get("socks_port", 9050)
        proxies = {
            "http": f"socks5h://127.0.0.1:{socks_port}",
            "https": f"socks5h://127.0.0.1:{socks_port}",
        }
        _console.print(f"[dim]NetCloak is running — routing through Tor (port {socks_port})…[/dim]")

    _console.print("[cyan]Fetching obfs4 bridges from bridges.torproject.org…[/cyan]")
    try:
        resp = requests.get(
            "https://bridges.torproject.org/bridges?transport=obfs4",
            proxies=proxies,
            timeout=30,
        )
        resp.raise_for_status()
    except Exception as exc:
        _err.print(f"[red]Failed to fetch bridges:[/red] {exc}")
        _err.print(
            "Get bridges manually at: [link]https://bridges.torproject.org[/link]\n"
            "Then add with: [bold]netcloak bridges --add \"<bridge string>\"[/bold]"
        )
        raise typer.Exit(code=1)

    lines = [ln.strip() for ln in resp.text.splitlines() if ln.strip()]
    bridge_lines = [ln for ln in lines if ln.startswith("obfs4")]

    if not bridge_lines:
        _console.print("[yellow]No obfs4 bridges found in response.[/yellow]")
        return

    table = Table(title="Available obfs4 Bridges", border_style="cyan", show_lines=True)
    table.add_column("#", style="bold", width=4)
    table.add_column("Bridge string")
    for i, b in enumerate(bridge_lines, 1):
        table.add_row(str(i), b)
    _console.print(table)

    if save:
        _save_bridges_to_config(bridge_lines)
        _console.print("[green]Bridges saved to config.toml.[/green]")
        _console.print("[dim]Restart NetCloak with use_bridges = true in [tor] to activate.[/dim]")
    else:
        _console.print(
            "\n[bold]To use these bridges,[/bold] either:\n"
            "  • Run [bold]netcloak bridges --save[/bold] to write them automatically\n"
            "  • Or add manually to config.toml:\n"
            "    [cyan][[tor]][/cyan]\n"
            "    [cyan]use_bridges = true[/cyan]\n"
            "    [cyan]bridge_type = \"obfs4\"[/cyan]\n"
            "    [cyan]bridges = [\"" + bridge_lines[0] + "\", ...][/cyan]"
        )


@app.command()
def tui() -> None:
    """Open the live TUI dashboard (read-only — reads state from a running session)."""
    cfg = _load_cfg()
    sp = _state_path(cfg)
    if not sp.exists():
        _err.print(
            Panel(
                "[yellow]NetCloak does not appear to be running.[/yellow]\n"
                f"(No state file at {sp})\n"
                "Start with [bold]netcloak start[/bold] first.",
                title="Not Running",
                border_style="yellow",
            )
        )
        raise typer.Exit(code=1)
    from netcloak.tui.app import NetCloakApp
    app_instance = NetCloakApp(config=cfg)
    app_instance.run()


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _save_bridges_to_config(bridges: list[str]) -> None:
    """Append bridges to config.toml under [tor], enabling bridge mode."""
    import toml
    cfg_path = Path("config.toml")
    if not cfg_path.exists():
        cfg_path = Path(__file__).parent.parent / "config.toml"
    try:
        data = toml.loads(cfg_path.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    tor_section = data.setdefault("tor", {})
    existing = tor_section.get("bridges", [])
    merged = list(dict.fromkeys(existing + bridges))  # dedup, preserve order
    tor_section["bridges"] = merged
    tor_section["use_bridges"] = True
    tor_section["bridge_type"] = tor_section.get("bridge_type", "obfs4")
    cfg_path.write_text(toml.dumps(data), encoding="utf-8")


def _read_tor_pid(cfg: dict) -> int | None:
    """Return the Tor process PID from the PID file, or None if not available."""
    pid_path = Path(_data_dir(cfg)) / "tor.pid"
    try:
        return int(pid_path.read_text().strip())
    except (OSError, ValueError):
        return None


def _print_status_json(cfg: dict, saved_state: dict) -> None:
    """Print status as JSON to stdout."""
    from netcloak.status.checker import run_leak_check, check_connectivity

    kill_switch = False
    try:
        from netcloak.core.platform import get_router
        kill_switch = get_router().is_kill_switch_active()
    except Exception:
        pass

    connected, conn_reason = check_connectivity()
    result = run_leak_check(
        socks_port=cfg["tor"]["socks_port"],
        kill_switch_active=kill_switch,
    )

    # Local SOCKS5 proxy status
    local_port = saved_state.get("local_proxy_port", cfg.get("proxy", {}).get("local_port", 8080))
    from netcloak.status.checker import check_local_proxy_port
    local_alive, _ = check_local_proxy_port(port=local_port)

    data = {
        "running": True,
        "platform": saved_state.get("platform", sys.platform),
        "tor_pid": _read_tor_pid(cfg),
        "connectivity": {"ok": connected, "reason": conn_reason},
        "real_ip": result["real_ip"],
        "tunnel_ip": result["tunnel_ip"],
        "ip_hidden": result["ip_hidden"],
        "tor_active": result["tor_active"],
        "dns_leak": result["dns_leak"],
        "kill_switch_active": kill_switch,
        "proxy_pool": saved_state.get("proxy_pool"),
        "last_check": saved_state.get("last_check"),
        "local_proxy_port": local_port,
        "local_proxy_alive": local_alive,
    }
    _console.print_json(json.dumps(data, indent=2))


def _print_status_table(cfg: dict, saved_state: dict | None = None) -> None:
    from netcloak.status.checker import run_leak_check, check_connectivity

    # Determine kill-switch state first so run_leak_check can use it to
    # correctly interpret real_ip == tunnel_ip (Wintun routes all traffic
    # through Tor, making the "direct" IP check also exit via Tor).
    kill_switch = False
    try:
        from netcloak.core.platform import get_router
        kill_switch = get_router().is_kill_switch_active()
    except Exception:
        pass

    _console.print("[cyan]Running leak check…[/cyan]")
    result = run_leak_check(
        socks_port=cfg["tor"]["socks_port"],
        kill_switch_active=kill_switch,
    )

    connected, conn_reason = check_connectivity()

    tor_pid = _read_tor_pid(cfg)
    pool_status = saved_state.get("proxy_pool") if saved_state else None
    last_check = saved_state.get("last_check") if saved_state else None
    platform_str = (saved_state or {}).get("platform", sys.platform)

    table = Table(title="NetCloak Status", border_style="cyan", show_lines=True)
    table.add_column("Property", style="bold")
    table.add_column("Value")

    table.add_row("Platform", platform_str)
    if tor_pid is not None:
        table.add_row("Tor PID", str(tor_pid))
    table.add_row(
        "Connectivity",
        "[green]OK[/green]" if connected else f"[red]No ({conn_reason})[/red]",
    )
    table.add_row("Real IP", result["real_ip"])
    table.add_row("Tunnel IP (Tor)", result["tunnel_ip"])
    table.add_row(
        "IP Hidden",
        "[green]Yes[/green]" if result["ip_hidden"] else "[red]No[/red]",
    )
    table.add_row(
        "Tor Active",
        "[green]Yes[/green]" if result["tor_active"] else "[red]No[/red]",
    )
    table.add_row(
        "DNS Leak",
        "[red]Yes[/red]" if result["dns_leak"] else "[green]No[/green]",
    )
    table.add_row(
        "Kill Switch",
        "[green]Active[/green]" if kill_switch else "[yellow]Inactive[/yellow]",
    )

    # Local SOCKS5 proxy status
    local_port = cfg.get("proxy", {}).get("local_port", 8080)
    if (saved_state or {}).get("local_proxy_port"):
        local_port = saved_state["local_proxy_port"]
    from netcloak.status.checker import check_local_proxy_port
    local_alive, local_reason = check_local_proxy_port(port=local_port)
    table.add_row(
        "Local Proxy",
        f"[green]Up[/green] (127.0.0.1:{local_port})" if local_alive
        else f"[red]Down[/red] (127.0.0.1:{local_port})",
    )

    if pool_status:
        table.add_row("Proxy Pool Size", str(pool_status.get("total", "?")))
        cp = pool_status.get("current_proxy")
        if cp:
            table.add_row(
                "Active Proxy",
                f"{cp.get('ip')}:{cp.get('port')} ({cp.get('latency_ms', '?')} ms)",
            )
            table.add_row("Active Proxy Country", cp.get("country", "Unknown"))
        age = pool_status.get("pool_age_seconds")
        if age is not None:
            table.add_row("Pool Age", f"{age}s")

    if last_check:
        table.add_row("Last Monitor Check", last_check)

    # Rotation timer status
    auto_rotation = (saved_state or {}).get("auto_rotation")
    if auto_rotation:
        interval = auto_rotation.get("interval_min", "?")
        next_sec = auto_rotation.get("next_rotation_sec", "?")
        table.add_row(
            "Auto-rotation",
            f"[green]ON[/green] (every {interval} min, next in {next_sec}s)"
        )
    else:
        rotation_interval = cfg.get("proxy", {}).get("rotation_interval_min", 0)
        if rotation_interval > 0:
            table.add_row("Auto-rotation", f"[green]ON[/green] (every {rotation_interval} min)")
        else:
            table.add_row("Auto-rotation", "[yellow]OFF[/yellow]")

    _console.print(table)


if __name__ == "__main__":
    app()
