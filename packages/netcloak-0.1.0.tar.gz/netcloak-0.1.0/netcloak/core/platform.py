"""Platform detector — returns the appropriate router for the current OS."""
from __future__ import annotations

import sys

from netcloak.routing.base import BaseRouter


def get_router() -> BaseRouter:
    """Return a router instance appropriate for the current platform.

    Raises NotImplementedError for unsupported platforms.
    """
    if sys.platform.startswith("linux"):
        from netcloak.routing.iptables import LinuxRouter
        return LinuxRouter()
    elif sys.platform == "win32":
        from netcloak.routing.windows_routing import WindowsRouter
        return WindowsRouter()
    else:
        raise NotImplementedError(f"Platform '{sys.platform}' is not supported yet.")


def is_windows() -> bool:
    return sys.platform == "win32"


def is_linux() -> bool:
    return sys.platform.startswith("linux")
