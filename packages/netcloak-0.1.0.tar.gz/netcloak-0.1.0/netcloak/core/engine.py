"""NetCloak Engine — central orchestrator for system-wide traffic anonymization.

Coordinates: NetworkState (crash recovery) → TorManager (daemon) → TorController
(bootstrap) → TrafficInterceptor (OS-level proxy/DNS) → ProxyPool (fallback) →
HealthMonitor + TrafficPadder + Watchdog (health monitoring).

Usage:
    engine = NetCloakEngine.instance()
    engine.start(mode='tor', config=cfg)
    engine.stop()
"""
from __future__ import annotations

import logging
import os
import socket
import sys
import threading
import time
from typing import Any

from rich.console import Console

from netcloak.config import load_config
from netcloak.core.monitor import HealthMonitor
from netcloak.core.state import NetworkState
from netcloak.routing.obfuscation import TrafficPadder
from netcloak.tor.controller import TorBootstrapTimeout, TorController
from netcloak.tor.manager import TorManager
from netcloak.proxy.pool import ProxyPool, validate_proxies
from netcloak.proxy.rotator import ProxyRotator
from netcloak.proxy.scraper import scrape_proxies_cached
from netcloak.utils.platform import require_admin_or_exit

logger = logging.getLogger(__name__)
_console = Console(stderr=True)


class NetCloakEngine:
    """Singleton orchestrator for NetCloak v2 start/stop lifecycle."""

    _instance: NetCloakEngine | None = None

    @classmethod
    def instance(cls) -> NetCloakEngine:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self) -> None:
        self._state: NetworkState | None = None
        self._tor = None
        self._controller = None
        self._interceptor = None
        self._pool = None
        self._monitor = None
        self._padder = None
        self._watchdog_thread: threading.Thread | None = None
        self._watchdog_stop = threading.Event()
        self._mode: str = ""
        self._start_time: float = 0.0
        self._running: bool = False

    # ------------------------------------------------------------------
    # Start
    # ------------------------------------------------------------------

    def start(self, mode: str = "tor", config: dict[str, Any] | None = None) -> None:
        """Start NetCloak in the given mode ('tor', 'proxy', or 'auto')."""
        require_admin_or_exit()
        cfg = config or load_config()
        tor_cfg = cfg["tor"]

        # 1. Detect OS → instantiate interceptor
        self._interceptor = self._make_interceptor(tor_cfg)

        # 2. Snapshot network state BEFORE any OS changes
        self._state = NetworkState()
        self._state.capture(mode=mode)

        # 3. Tor mode
        actual_mode = mode
        if mode in ("tor", "auto"):
            actual_mode = self._start_tor(cfg, tor_cfg)

        # 4. Proxy mode / fallback
        if actual_mode == "proxy":
            self._start_proxy(cfg)

        # 5. Existing features: HealthMonitor + TrafficPadder
        if self._tor is not None:
            rotator = ProxyRotator(cfg)
            self._monitor = HealthMonitor(tor_manager=self._tor, rotator=rotator, config=cfg)
            self._monitor.start()

        self._padder = TrafficPadder(cfg)
        self._padder.start()

        # 6. Watchdog
        self._watchdog_stop.clear()
        self._watchdog_thread = threading.Thread(
            target=self._watchdog_loop, daemon=True, name="netcloak-watchdog"
        )
        self._watchdog_thread.start()

        self._mode = actual_mode
        self._start_time = time.monotonic()
        self._running = True
        _console.print(f"[green]NetCloak started in {actual_mode} mode.[/green]")

    def _make_interceptor(self, tor_cfg: dict[str, Any]):
        socks_port: int = tor_cfg.get("socks_port", 9050)
        dns_port: int = tor_cfg.get("dns_port", 9053)
        trans_port: int = tor_cfg.get("trans_port", 9040)
        if sys.platform == "win32":
            from netcloak.interceptors.windows import WindowsInterceptor
            return WindowsInterceptor(socks_port=socks_port, dns_port=dns_port)
        if sys.platform.startswith("linux"):
            from netcloak.interceptors.linux import LinuxInterceptor
            return LinuxInterceptor(socks_port=socks_port, dns_port=dns_port, trans_port=trans_port)
        if sys.platform == "darwin":
            from netcloak.interceptors.darwin import DarwinInterceptor
            return DarwinInterceptor(socks_port=socks_port)
        raise NotImplementedError(f"Unsupported platform: {sys.platform}")

    def _start_tor(self, cfg: dict[str, Any], tor_cfg: dict[str, Any]) -> str:
        """Start Tor, monitor bootstrap. Returns 'tor' on success, 'proxy' on failure."""
        tor = TorManager(
            socks_port=tor_cfg["socks_port"],
            control_port=tor_cfg["control_port"],
            dns_port=tor_cfg.get("dns_port", 9053),
            trans_port=tor_cfg.get("trans_port", 9040),
            data_dir=self._data_dir(cfg),
            binary_path=tor_cfg.get("binary_path", ""),
        )
        if not tor.start():
            _console.print("[yellow]Tor failed to start — falling back to proxy mode.[/yellow]")
            return "proxy"
        self._tor = tor

        controller = TorController(control_port=tor_cfg["control_port"])
        try:
            controller.connect()
            controller.monitor_bootstrap(timeout=60)
            self._controller = controller
        except TorBootstrapTimeout:
            _console.print("[yellow]Tor bootstrap timed out — falling back to proxy mode.[/yellow]")
            controller.disconnect()
            return "proxy"
        except Exception as exc:
            logger.warning("Tor controller error: %s", exc)

        # Activate interceptor
        if self._interceptor is not None:
            self._interceptor.activate()

        return "tor"

    def _start_proxy(self, cfg: dict[str, Any]) -> None:
        """Scrape + validate proxy pool and activate interceptor."""
        _console.print("[cyan]Fetching proxy pool...[/cyan]")
        urls = scrape_proxies_cached()
        validated = validate_proxies(urls)
        if not validated:
            _console.print("[yellow]No valid proxies found — continuing without proxy pool.[/yellow]")
            return
        self._pool = ProxyPool(validated)

        # Generate proxychains.conf (Linux only — per D-01, D-03, D-04)
        if not sys.platform == "win32":
            from netcloak.proxy.proxychains import generate_proxychains_conf
            from urllib.parse import urlparse
            from pathlib import Path as _Path
            proxychains_conf = str(_Path(self._data_dir(cfg)) / "proxychains.conf")
            proxy_dicts = []
            for vp in self._pool._proxies:
                parsed = urlparse(vp.url)
                if parsed.hostname and parsed.port:
                    proxy_dicts.append({
                        "ip": parsed.hostname,
                        "port": parsed.port,
                        "protocol": (parsed.scheme or "socks5").replace("h", ""),
                    })
            generate_proxychains_conf(
                proxies=proxy_dicts,
                output_path=proxychains_conf,
                chain_type=cfg["proxy"].get("chain_type", "dynamic"),
                chain_length=cfg["proxy"].get("chain_length", 2),
            )
            logger.info("ProxyChains config written to %s", proxychains_conf)

        if self._interceptor is not None:
            self._interceptor.activate()

    def _data_dir(self, cfg: dict[str, Any]) -> str:
        import tempfile
        if sys.platform == "win32":
            raw = cfg["tor"].get("data_dir_windows", r"%APPDATA%\NetCloak\tor")
        else:
            raw = cfg["tor"].get("data_dir", "/tmp/netcloak_tor")
        return os.path.expandvars(raw) or os.path.join(tempfile.gettempdir(), "netcloak_tor")

    # ------------------------------------------------------------------
    # Stop
    # ------------------------------------------------------------------

    def stop(self) -> None:
        """Stop NetCloak and restore all OS settings."""
        # 1. Stop watchdog
        if self._watchdog_thread is not None:
            self._watchdog_stop.set()
            self._watchdog_thread.join(timeout=5)
            self._watchdog_thread = None

        # 2. Stop controller
        try:
            if self._controller is not None:
                self._controller.disconnect()
        except Exception as exc:
            logger.warning("Controller disconnect error: %s", exc)

        # 3. Stop Tor
        try:
            if self._tor is not None:
                self._tor.stop()
        except Exception as exc:
            logger.warning("Tor stop error: %s", exc)

        # 4. Stop proxy pool
        try:
            if self._pool is not None:
                self._pool.stop()
        except Exception as exc:
            logger.warning("Pool stop error: %s", exc)

        # 5. Stop monitor + padder
        try:
            if self._monitor is not None:
                self._monitor.stop()
        except Exception as exc:
            logger.warning("Monitor stop error: %s", exc)
        try:
            if self._padder is not None:
                self._padder.stop()
        except Exception as exc:
            logger.warning("Padder stop error: %s", exc)

        # 6. Restore network state BEFORE deactivate (prevents double DNS restore)
        try:
            if self._state is not None:
                self._state.restore()
        except Exception as exc:
            logger.warning("State restore error: %s", exc)

        # 7. Deactivate interceptor
        try:
            if self._interceptor is not None:
                self._interceptor.deactivate()
        except Exception as exc:
            logger.warning("Interceptor deactivate error: %s", exc)

        # 8. Verify DNS
        try:
            socket.getaddrinfo("google.com", 80)
            _console.print("[green]DNS verified: google.com resolves.[/green]")
        except Exception as exc:
            _console.print(f"[yellow]DNS check after stop: {exc}[/yellow]")

        # 9. Delete state file
        try:
            if self._state is not None:
                self._state.delete()
        except Exception as exc:
            logger.warning("State delete error: %s", exc)

        self._running = False
        _console.print("[green]NetCloak stopped. Network restored.[/green]")

    # ------------------------------------------------------------------
    # Watchdog
    # ------------------------------------------------------------------

    def _watchdog_loop(self) -> None:
        restart_failures = 0
        while not self._watchdog_stop.wait(timeout=30):
            try:
                if self._mode in ("tor", "auto") and self._tor is not None:
                    if not self._tor.is_running():
                        logger.warning("Watchdog: Tor died — attempting restart")
                        if not self._tor.start():
                            restart_failures += 1
                        else:
                            restart_failures = 0
                elif self._mode == "proxy" and self._pool is not None:
                    if self._pool.get_proxy() is None:
                        logger.warning("Watchdog: proxy pool empty")
                        restart_failures += 1
                    else:
                        restart_failures = 0
                if restart_failures >= 3:
                    logger.error("Watchdog: 3 consecutive failures — stopping NetCloak")
                    self.stop()
                    return
            except Exception as exc:
                logger.debug("Watchdog error: %s", exc)

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def get_status(self) -> dict[str, Any]:
        uptime = time.monotonic() - self._start_time if self._running else 0.0
        exit_ip: str | None = None
        is_tor_flag = False
        if self._controller is not None:
            try:
                exit_ip = self._controller.get_exit_ip()
                is_tor_flag = self._controller.is_tor()
            except Exception:
                pass
        pool_size = 0
        if self._pool is not None:
            try:
                pool_size = self._pool.get_stats().get("pool_size", 0)
            except Exception:
                pass
        return {
            "running": self._running,
            "mode": self._mode,
            "exit_ip": exit_ip,
            "is_tor": is_tor_flag,
            "uptime": int(uptime),
            "proxy_pool_size": pool_size,
            "tor_running": self._tor.is_running() if self._tor else False,
        }
