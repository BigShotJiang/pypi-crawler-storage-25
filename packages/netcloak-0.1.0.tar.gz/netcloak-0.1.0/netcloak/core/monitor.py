"""Background health monitor — checks Tor, tunnel IP, and manages kill-switch failsafe."""
from __future__ import annotations

import json
import logging
import os
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, TYPE_CHECKING

from rich.console import Console

if TYPE_CHECKING:
    from netcloak.tor.manager import TorManager
    from netcloak.proxy.rotator import ProxyRotator

_console = Console(stderr=True)


class HealthMonitor:
    """Periodically checks Tor liveness and tunnel reachability.

    State is written to <data_dir>/state.json after every check so that
    the CLI's ``status`` command can read it without a live monitor handle.

    Kill-switch activation: if the tunnel IP check fails twice in a row the
    kill switch is re-enabled as a failsafe (requires root; logged as a
    warning instead of crashing if not root).
    """

    def __init__(
        self,
        tor_manager: "TorManager",
        rotator: "ProxyRotator",
        config: dict[str, Any],
        check_interval: int = 30,
        mode: str = "unknown",
    ) -> None:
        monitor_cfg = config.get("monitor", {})
        self._tor = tor_manager
        self._rotator = rotator
        self._interval = monitor_cfg.get("check_interval_sec", check_interval)
        self._max_restarts = monitor_cfg.get("max_restart_attempts", 3)
        self._mode = mode

        # Auto-rotation timer (0 = disabled)
        self.rotation_interval = config.get("proxy", {}).get("rotation_interval_min", 0)
        self.last_rotation = time.time()

        tor_cfg = config.get("tor", {})
        data_dir = tor_cfg.get("data_dir", "/tmp/netcloak_tor")
        self._state_path = Path(data_dir) / "state.json"
        self._log_path = Path(data_dir) / "netcloak.log"

        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

        self._consecutive_failures = 0
        self._restart_count = 0

        # Set up file logger
        self._logger = logging.getLogger("netcloak.monitor")
        if not self._logger.handlers:
            self._log_path.parent.mkdir(parents=True, exist_ok=True)
            fh = logging.FileHandler(str(self._log_path))
            fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
            self._logger.addHandler(fh)
            self._logger.setLevel(logging.INFO)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def _log(self, message: str) -> None:
        self._logger.info(message)
        _console.print(f"[cyan]{message}[/cyan]")

    def start(self) -> None:
        """Launch the monitor background thread."""
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._loop, name="netcloak-monitor", daemon=True
        )
        self._thread.start()
        _console.print("[cyan]Health monitor started.[/cyan]")

    def stop(self) -> None:
        """Signal the background thread to exit and wait for it."""
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=self._interval + 5)
        _console.print("[cyan]Health monitor stopped.[/cyan]")

    # ------------------------------------------------------------------
    # Internal loop
    # ------------------------------------------------------------------

    def _loop(self) -> None:
        while not self._stop_event.is_set():
            self._check()
            self._stop_event.wait(timeout=self._interval)

    def _check(self) -> None:
        now = datetime.now(timezone.utc).isoformat()

        # 1. Check Tor is running; attempt restart if not
        tor_running = self._tor.is_running()
        if not tor_running:
            self._logger.warning("Tor is not running — attempting restart")
            if self._restart_count < self._max_restarts:
                success = self._tor.start()
                self._restart_count += 1
                if success:
                    self._logger.info("Tor restarted successfully (attempt %d)", self._restart_count)
                    tor_running = True
                else:
                    self._logger.error("Tor restart failed (attempt %d)", self._restart_count)
            else:
                self._logger.error("Max restart attempts (%d) reached", self._max_restarts)
        else:
            self._restart_count = 0  # Reset restart counter on healthy check

        # 2. Check tunnel IP reachability
        tunnel_ip: str | None = None
        if tor_running:
            from netcloak.status.checker import get_tunnel_ip
            try:
                tunnel_ip = get_tunnel_ip(socks_port=self._tor.socks_port, timeout=10)
                if tunnel_ip == "unavailable":
                    tunnel_ip = None
            except Exception:
                tunnel_ip = None

        if tunnel_ip:
            self._consecutive_failures = 0
            self._logger.info("Health check OK — tunnel IP: %s", tunnel_ip)
        else:
            self._consecutive_failures += 1
            self._logger.warning(
                "Tunnel IP check failed (consecutive: %d)", self._consecutive_failures
            )

        # 3. Trigger kill switch if tunnel fails twice in a row
        kill_switch_active = False
        if self._consecutive_failures >= 2:
            self._logger.error("Two consecutive tunnel failures — activating kill switch")
            try:
                if sys.platform.startswith("linux") and os.geteuid() == 0:
                    from netcloak.routing.iptables import enable_kill_switch
                    enable_kill_switch()
                    kill_switch_active = True
                elif sys.platform.startswith("linux"):
                    self._logger.warning("Not root — cannot activate kill switch automatically")
                else:
                    self._logger.warning(
                        "Kill switch auto-activate not supported on %s", sys.platform
                    )
            except Exception as exc:
                self._logger.error("Failed to activate kill switch: %s", exc)

        # 4. Auto-rotation timer
        if self.rotation_interval > 0:
            if time.time() - self.last_rotation > self.rotation_interval * 60:
                self._rotator.rotate()
                self.last_rotation = time.time()
                self._log("Proxy rotated (auto-timer)")

        # 5. Write state.json
        rotation_status = None
        if self.rotation_interval > 0:
            next_rotation_sec = max(0, self.rotation_interval * 60 - (time.time() - self.last_rotation))
            rotation_status = {
                "enabled": True,
                "interval_min": self.rotation_interval,
                "next_rotation_sec": int(next_rotation_sec),
            }
        state: dict[str, Any] = {
            "tor_running": tor_running,
            "mode": self._mode,
            "tunnel_ip": tunnel_ip,
            "last_check": now,
            "kill_switch_active": kill_switch_active,
            "consecutive_failures": self._consecutive_failures,
            "proxy_pool": self._rotator.get_pool_status() if self._rotator else None,
            "auto_rotation": rotation_status,
        }
        try:
            self._state_path.write_text(json.dumps(state, indent=2))
        except Exception as exc:
            self._logger.error("Could not write state.json: %s", exc)
