"""Network state snapshot and crash-recovery for NetCloak.

NetworkState captures a snapshot of the OS network configuration (DNS,
system proxy registry) before any interceptor runs, and restores it
on stop or crash.

Usage:
    state = NetworkState()
    state.capture(mode="tor")   # snapshot + register cleanup handlers
    # ... interceptors run ...
    state.restore()             # re-apply saved state
    state.delete()              # remove state file on clean exit
"""
from __future__ import annotations

import atexit
import json
import logging
import os
import signal
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module-level helpers (patchable in tests)
# ---------------------------------------------------------------------------

def _get_connected_adapters_win() -> list[str]:
    """Return names of Connected+Enabled adapters via netsh."""
    from netcloak.routing.dns_tor import _get_connected_adapters
    return _get_connected_adapters()


def _get_adapter_dns_win(adapter: str) -> dict[str, Any]:
    """Return DNS info for a Windows adapter."""
    from netcloak.routing.dns_tor import _get_adapter_dns
    return _get_adapter_dns(adapter)


def _run_netsh(*args: str) -> subprocess.CompletedProcess:
    """Run netsh with the given arguments."""
    return subprocess.run(
        ["netsh"] + list(args),
        capture_output=True,
        text=True,
        check=False,
    )


def _capture_windows_dns() -> dict[str, Any]:
    """Snapshot DNS config for all connected adapters."""
    adapters = _get_connected_adapters_win()
    dns: dict[str, Any] = {}
    for adapter in adapters:
        dns[adapter] = _get_adapter_dns_win(adapter)
    return dns


def _capture_windows_proxy() -> dict[str, Any]:
    """Read Windows HKCU proxy registry settings."""
    proxy: dict[str, Any] = {"ProxyEnable": 0, "ProxyServer": None}
    if sys.platform != "win32":
        return proxy
    try:
        import winreg
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path) as key:
            try:
                val, _ = winreg.QueryValueEx(key, "ProxyEnable")
                proxy["ProxyEnable"] = int(val)
            except OSError:
                pass
            try:
                val, _ = winreg.QueryValueEx(key, "ProxyServer")
                proxy["ProxyServer"] = str(val)
            except OSError:
                pass
    except (ImportError, OSError) as exc:
        logger.debug("Could not read proxy registry: %s", exc)
    return proxy


def _restore_windows_dns(dns_data: dict[str, Any]) -> None:
    """Restore per-adapter DNS from snapshot data."""
    for adapter, dns_info in dns_data.items():
        mode = dns_info.get("mode", "dhcp")
        servers: list[str] = dns_info.get("servers", [])
        if mode == "static" and servers:
            _run_netsh("interface", "ip", "set", "dns",
                       adapter, "static", servers[0])
            for idx, server in enumerate(servers[1:], start=2):
                _run_netsh("interface", "ip", "add", "dns",
                           adapter, server, f"index={idx}")
        else:
            _run_netsh("interface", "ip", "set", "dns", adapter, "dhcp")


def _restore_windows_proxy(proxy_data: dict[str, Any]) -> None:
    """Restore Windows HKCU proxy registry from snapshot data."""
    if sys.platform != "win32":
        return
    try:
        import winreg
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER, key_path,
            access=winreg.KEY_SET_VALUE
        ) as key:
            enable = proxy_data.get("ProxyEnable", 0)
            winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, int(enable))
            server = proxy_data.get("ProxyServer")
            if server:
                winreg.SetValueEx(key, "ProxyServer", 0, winreg.REG_SZ, str(server))
            else:
                try:
                    winreg.DeleteValue(key, "ProxyServer")
                except OSError:
                    pass
    except (ImportError, OSError) as exc:
        logger.debug("Could not restore proxy registry: %s", exc)

    # Broadcast settings change so Windows picks up the update
    try:
        from netcloak.routing.windows_routing import _broadcast_settings_change
        _broadcast_settings_change()
    except Exception:
        pass


# Coordination flag — checked to skip DNS restore when TorDNSRedirect owns it
def _get_dns_redirected_flag() -> bool:
    try:
        from netcloak.routing.dns import _dns_redirected_by_tor
        return _dns_redirected_by_tor
    except Exception:
        return False


# ---------------------------------------------------------------------------
# NetworkState class
# ---------------------------------------------------------------------------

class NetworkState:
    """Capture and restore OS network state (DNS + system proxy).

    The state file is written to:
      - Windows: %APPDATA%\\netcloak\\network_snapshot.json
      - Linux/macOS: /var/lib/netcloak/network_snapshot.json

    Pass ``state_dir`` to override the directory (used in tests).
    """

    def __init__(self, state_dir: str | None = None) -> None:
        if state_dir is not None:
            self._state_file = Path(state_dir) / "network_snapshot.json"
        elif sys.platform == "win32":
            appdata = os.environ.get("APPDATA", os.path.expanduser("~"))
            self._state_file = Path(appdata) / "netcloak" / "network_snapshot.json"
        else:
            self._state_file = Path("/var/lib/netcloak/network_snapshot.json")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def capture(self, mode: str = "tor") -> dict[str, Any]:
        """Snapshot current OS network state and write to state file.

        If a state file already exists (crash detected): log a warning,
        call restore() to clean up, then delete() before capturing fresh.

        Registers atexit + signal handlers so cleanup runs on abnormal exit.

        Returns the snapshot dict.
        """
        if self.exists():
            logger.warning(
                "Recovered from previous crash — restoring network state"
            )
            self.restore()
            self.delete()

        snapshot = self._build_snapshot(mode)

        # Write state file
        self._state_file.parent.mkdir(parents=True, exist_ok=True)
        self._state_file.write_text(
            json.dumps(snapshot, indent=2),
            encoding="utf-8",
        )
        logger.debug("Network state captured to %s", self._state_file)

        self._register_handlers()
        return snapshot

    def restore(self) -> None:
        """Read state file and restore network configuration.

        Skips DNS restore if TorDNSRedirect currently owns DNS
        (checked via netcloak.routing.dns._dns_redirected_by_tor).
        """
        if not self.exists():
            logger.debug("No state file found — nothing to restore.")
            return

        try:
            snapshot = json.loads(self._state_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            logger.error("Could not read state file: %s", exc)
            return

        platform = snapshot.get("platform", sys.platform)
        if platform == "win32":
            self._restore_windows(snapshot)
        elif platform == "linux":
            self._restore_linux(snapshot)
        else:
            logger.info("macOS state restore not yet implemented")

    def delete(self) -> None:
        """Remove the state file if it exists."""
        try:
            self._state_file.unlink(missing_ok=True)
        except OSError as exc:
            logger.debug("Could not delete state file: %s", exc)

    def exists(self) -> bool:
        """Return True if the state file exists."""
        return self._state_file.exists()

    def _register_handlers(self) -> None:
        """Register atexit and signal handlers to auto-restore on abnormal exit."""
        atexit.register(self._cleanup)

        def _sig_handler(signum: int, frame: Any) -> None:
            self._cleanup(signum, frame)

        try:
            signal.signal(signal.SIGTERM, _sig_handler)
        except (OSError, ValueError):
            pass
        try:
            signal.signal(signal.SIGINT, _sig_handler)
        except (OSError, ValueError):
            pass

        if sys.platform == "win32":
            try:
                signal.signal(signal.SIGBREAK, _sig_handler)
            except (OSError, ValueError, AttributeError):
                pass
            try:
                import win32api

                def _ctrl_handler(ctrl_type: int) -> bool:
                    self._cleanup()
                    return False

                win32api.SetConsoleCtrlHandler(_ctrl_handler, True)
            except ImportError:
                pass

    def _cleanup(self, signum: Any = None, frame: Any = None) -> None:
        """Restore state and delete file — called by atexit and signal handlers."""
        try:
            self.restore()
        except Exception as exc:
            logger.error("Cleanup restore failed: %s", exc)
        try:
            self.delete()
        except Exception as exc:
            logger.error("Cleanup delete failed: %s", exc)

    # ------------------------------------------------------------------
    # Platform-specific capture
    # ------------------------------------------------------------------

    def _build_snapshot(self, mode: str) -> dict[str, Any]:
        """Build the snapshot dict for the current platform."""
        timestamp = datetime.now(timezone.utc).isoformat()
        if sys.platform == "win32":
            platform_data = self._capture_windows()
            return {
                "timestamp": timestamp,
                "mode": mode,
                "platform": "win32",
                **platform_data,
            }
        elif sys.platform.startswith("linux"):
            platform_data = self._capture_linux()
            return {
                "timestamp": timestamp,
                "mode": mode,
                "platform": "linux",
                **platform_data,
            }
        else:
            logger.info("macOS state capture not yet implemented")
            return {
                "timestamp": timestamp,
                "mode": mode,
                "platform": sys.platform,
                "dns": {},
                "proxy_registry": {},
            }

    def _capture_windows(self) -> dict[str, Any]:
        """Capture Windows DNS and proxy registry state."""
        dns = _capture_windows_dns()
        proxy_registry = _capture_windows_proxy()
        return {"dns": dns, "proxy_registry": proxy_registry}

    def _capture_linux(self) -> dict[str, Any]:
        """Capture Linux resolv.conf, iptables rules, and IPv6 sysctl."""
        resolv_conf = ""
        iptables_rules = ""
        ipv6_disabled = ""

        try:
            with open("/etc/resolv.conf", "r", encoding="utf-8") as f:
                resolv_conf = f.read()
        except OSError as exc:
            logger.debug("Could not read /etc/resolv.conf: %s", exc)

        try:
            result = subprocess.run(
                ["iptables-save"],
                capture_output=True,
                text=True,
                check=False,
            )
            iptables_rules = result.stdout
        except OSError as exc:
            logger.debug("Could not run iptables-save: %s", exc)

        try:
            result = subprocess.run(
                ["sysctl", "net.ipv6.conf.all.disable_ipv6"],
                capture_output=True,
                text=True,
                check=False,
            )
            ipv6_disabled = result.stdout.strip()
        except OSError as exc:
            logger.debug("Could not read IPv6 sysctl: %s", exc)

        return {
            "dns": {"resolv_conf": resolv_conf},
            "proxy_registry": {},
            "resolv_conf": resolv_conf,
            "iptables_rules": iptables_rules,
            "ipv6_disabled": ipv6_disabled,
        }

    def _capture_darwin(self) -> dict[str, Any]:
        """macOS state capture — stub."""
        logger.info("macOS state capture not yet implemented")
        return {"dns": {}, "proxy_registry": {}}

    # ------------------------------------------------------------------
    # Platform-specific restore
    # ------------------------------------------------------------------

    def _restore_windows(self, snapshot: dict[str, Any]) -> None:
        """Restore Windows network state from snapshot."""
        if not _get_dns_redirected_flag():
            dns_data = snapshot.get("dns", {})
            _restore_windows_dns(dns_data)
        else:
            logger.debug("DNS restore skipped — TorDNSRedirect owns DNS")

        proxy_data = snapshot.get("proxy_registry", {})
        _restore_windows_proxy(proxy_data)

    def _restore_linux(self, snapshot: dict[str, Any]) -> None:
        """Restore Linux network state from snapshot."""
        resolv_conf = snapshot.get("resolv_conf", "")
        iptables_rules = snapshot.get("iptables_rules", "")
        ipv6_disabled = snapshot.get("ipv6_disabled", "")

        if resolv_conf:
            try:
                with open("/etc/resolv.conf", "w", encoding="utf-8") as f:
                    f.write(resolv_conf)
            except OSError as exc:
                logger.error("Could not restore /etc/resolv.conf: %s", exc)

        if iptables_rules:
            try:
                subprocess.run(
                    ["iptables-restore"],
                    input=iptables_rules,
                    text=True,
                    check=False,
                )
            except OSError as exc:
                logger.error("Could not restore iptables: %s", exc)

        # Restore IPv6 sysctl: extract value from "key = value" output
        if ipv6_disabled:
            parts = ipv6_disabled.split("=")
            if len(parts) == 2:
                value = parts[1].strip()
                try:
                    subprocess.run(
                        ["sysctl", "-w",
                         f"net.ipv6.conf.all.disable_ipv6={value}"],
                        capture_output=True,
                        text=True,
                        check=False,
                    )
                except OSError as exc:
                    logger.debug("Could not restore IPv6 sysctl: %s", exc)

    def _restore_darwin(self, snapshot: dict[str, Any]) -> None:
        """macOS state restore — stub."""
        logger.info("macOS state restore not yet implemented")
