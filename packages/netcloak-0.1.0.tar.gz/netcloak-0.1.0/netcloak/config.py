"""TOML config loader for NetCloak."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import toml

_DEFAULT_CONFIG: dict[str, Any] = {
    "tor": {
        "socks_port": 9050,
        "control_port": 9051,
        "data_dir": "/tmp/netcloak_tor",
    },
    "proxy": {
        "source_url": "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/all/data.json",
        "min_anonymity": "anonymous",
        "max_latency_ms": 2000,
        "validation_workers": 20,
    },
    "routing": {
        "kill_switch": True,
        "dns_lock": True,
    },
    "logging": {
        "level": "INFO",
    },
}


def _deep_merge(base: dict, override: dict) -> dict:
    result = dict(base)
    for key, val in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(val, dict):
            result[key] = _deep_merge(result[key], val)
        else:
            result[key] = val
    return result


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    """Load config from *path* (default: config.toml in cwd or project root).

    Falls back to built-in defaults for any missing keys.
    """
    if path is None:
        candidates = [
            Path.cwd() / "config.toml",
            Path(__file__).parent.parent / "config.toml",
        ]
        for c in candidates:
            if c.exists():
                path = c
                break

    if path is not None:
        user_cfg = toml.load(str(path))
        return _deep_merge(_DEFAULT_CONFIG, user_cfg)

    return dict(_DEFAULT_CONFIG)
