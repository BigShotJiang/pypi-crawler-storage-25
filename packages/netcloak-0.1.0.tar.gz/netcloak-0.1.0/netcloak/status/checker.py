"""External IP and leak detection."""
from __future__ import annotations

import socket
from typing import Any

import requests
from rich.console import Console

from netcloak.routing.dns import check_dns_leak

_console = Console(stderr=True)

_IP_CHECK_URL = "https://api.ipify.org?format=json"
_SOCKS_HOST = "127.0.0.1"

# Lightweight connectivity probes — no DNS, TCP-only to well-known IPs/ports.
# Using raw IP addresses avoids relying on DNS resolution (which may already
# be locked to 127.0.0.1 by the time this is called on subsequent runs).
_CONNECTIVITY_PROBES = [
    ("1.1.1.1", 443),   # Cloudflare HTTPS
    ("8.8.8.8", 53),    # Google DNS
    ("9.9.9.9", 53),    # Quad9 DNS
]


def verify_dns_through_tor(dns_port: int = 9053, timeout: float = 5.0) -> tuple[bool, str]:
    """Verify that Tor's DNSPort is responding to DNS queries.

    Sends a minimal UDP DNS query to 127.0.0.1:{dns_port} and checks for
    a valid response.  Call this after Tor starts to confirm DNS routing is
    active before trusting that DNS is leak-free.

    Returns:
        (True, "OK")         — DNSPort responded with a DNS reply
        (False, "<reason>")  — DNSPort not responding or unreachable
    """
    # Minimal DNS query: ID=0x1234, RD=1, QDCOUNT=1
    # QNAME: check.torproject.org, QTYPE=A, QCLASS=IN
    query = (
        b'\x12\x34'  # Transaction ID
        b'\x01\x00'  # Flags: standard query, recursion desired
        b'\x00\x01'  # QDCOUNT=1
        b'\x00\x00'  # ANCOUNT=0
        b'\x00\x00'  # NSCOUNT=0
        b'\x00\x00'  # ARCOUNT=0
        b'\x05check\x0btorproject\x03org\x00'  # QNAME
        b'\x00\x01'  # QTYPE=A
        b'\x00\x01'  # QCLASS=IN
    )
    sock: socket.socket | None = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)
        sock.sendto(query, ("127.0.0.1", dns_port))
        response, _ = sock.recvfrom(4096)
        # A valid DNS response starts with the same transaction ID and QR=1
        if len(response) >= 4 and response[:2] == b'\x12\x34' and (response[2] & 0x80):
            return True, "OK"
        return False, f"Unexpected response from DNSPort (length={len(response)})"
    except socket.timeout:
        return False, f"Tor DNSPort 127.0.0.1:{dns_port} did not respond within {timeout}s"
    except OSError as exc:
        return False, f"Could not reach Tor DNSPort 127.0.0.1:{dns_port}: {exc}"
    finally:
        if sock is not None:
            sock.close()


def check_connectivity(timeout: float = 5.0) -> tuple[bool, str]:
    """Test whether raw internet connectivity is available (pre-Tor check).

    Tries TCP connections to well-known IPs without going through any proxy.
    Uses raw IP addresses to avoid dependency on local DNS resolution.

    Returns:
        (True, "OK")                — at least one probe succeeded
        (False, "<reason>")         — all probes failed
    """
    errors: list[str] = []
    for host, port in _CONNECTIVITY_PROBES:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True, "OK"
        except OSError as exc:
            errors.append(f"{host}:{port} — {exc}")

    return False, "; ".join(errors)


def get_real_ip(timeout: int = 10) -> str:
    """Return the machine's real public IP (direct, no proxy)."""
    try:
        resp = requests.get(_IP_CHECK_URL, timeout=timeout)
        resp.raise_for_status()
        return resp.json().get("ip", "unknown")
    except Exception as exc:
        _console.print(f"[red]Failed to get real IP:[/red] {exc}")
        return "unavailable"


def get_tunnel_ip(socks_port: int = 9050, timeout: int = 15) -> str:
    """Return the public IP as seen through the Tor SOCKS5 proxy."""
    proxies = {
        "http": f"socks5h://{_SOCKS_HOST}:{socks_port}",
        "https": f"socks5h://{_SOCKS_HOST}:{socks_port}",
    }
    try:
        resp = requests.get(_IP_CHECK_URL, proxies=proxies, timeout=timeout)
        resp.raise_for_status()
        return resp.json().get("ip", "unknown")
    except Exception as exc:
        _console.print(f"[red]Failed to get tunnel IP:[/red] {exc}")
        return "unavailable"


def check_local_proxy_port(port: int = 8080, timeout: float = 2.0) -> tuple[bool, str]:
    """Check whether the local SOCKS5 proxy port is accepting connections.

    Returns:
        (True, "OK")         — port is accepting TCP connections
        (False, "<reason>")  — port is not reachable
    """
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=timeout):
            return True, "OK"
    except OSError as exc:
        return False, str(exc)


def run_leak_check(
    socks_port: int = 9050,
    kill_switch_active: bool = False,
) -> dict[str, Any]:
    """Run a full leak check.

    Args:
        socks_port:          Tor SOCKS5 port (default 9050).
        kill_switch_active:  When True, the kill switch is blocking all direct
                             traffic.  On Windows with Wintun, ``get_real_ip()``
                             also exits via Tor, so real_ip == tunnel_ip is
                             expected and NOT a leak — treat it as ip_hidden=True.

    Returns::

        {
            "real_ip":    str,
            "tunnel_ip":  str,
            "ip_hidden":  bool,
            "dns_leak":   bool,
            "tor_active": bool,
        }
    """
    real_ip = get_real_ip()
    tunnel_ip = get_tunnel_ip(socks_port=socks_port)

    _valid = {"unavailable", "unknown"}
    real_valid = real_ip not in _valid
    tunnel_valid = tunnel_ip not in _valid

    ip_hidden = real_valid and tunnel_valid and real_ip != tunnel_ip

    # Kill-switch + Wintun edge case: all traffic (including the "direct" real-IP
    # check) is routed through Tor, so real_ip == tunnel_ip.  This is correct
    # behaviour — the real IP is not reachable — report as hidden.
    if (not ip_hidden and kill_switch_active
            and real_valid and tunnel_valid and real_ip == tunnel_ip):
        ip_hidden = True
        real_ip = f"{real_ip} (via Tor — kill switch active)"

    # tor_active: Tor SOCKS5 is reachable and returned an exit IP.
    tor_active = tunnel_valid

    dns_info = check_dns_leak(socks_port=socks_port)

    return {
        "real_ip": real_ip,
        "tunnel_ip": tunnel_ip,
        "ip_hidden": ip_hidden,
        "dns_leak": dns_info.get("leaked", False),
        "tor_active": tor_active,
    }
