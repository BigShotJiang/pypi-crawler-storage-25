"""Tests for netcloak.proxy.pool — weighted pool with circuit breaker."""
from __future__ import annotations

import asyncio
import time
from dataclasses import fields
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def _make_proxy(url: str, latency_ms: float = 100.0) -> "ValidatedProxy":
    from netcloak.proxy.pool import ValidatedProxy
    return ValidatedProxy(url=url, latency_ms=latency_ms, validated_at=time.monotonic())


def test_get_proxy_returns_url():
    """Test 1: ProxyPool.get_proxy() returns a proxy URL from the pool."""
    from netcloak.proxy.pool import ProxyPool
    p = _make_proxy("socks5h://1.2.3.4:1080")
    pool = ProxyPool([p], auto_replenish=False)
    result = pool.get_proxy()
    assert result == "socks5h://1.2.3.4:1080"
    pool.stop()


def test_weighted_selection_favors_fast_proxy():
    """Test 2: Proxy with lower latency is selected more frequently (100 calls)."""
    from netcloak.proxy.pool import ProxyPool
    fast = _make_proxy("socks5h://1.1.1.1:1080", latency_ms=50.0)
    slow = _make_proxy("socks5h://2.2.2.2:1080", latency_ms=5000.0)
    pool = ProxyPool([fast, slow], auto_replenish=False)

    counts = {"socks5h://1.1.1.1:1080": 0, "socks5h://2.2.2.2:1080": 0}
    for _ in range(100):
        url = pool.get_proxy()
        counts[url] += 1

    pool.stop()
    # Fast proxy weight: max(1, 100 - 50/100) = 99.5; slow: max(1, 100 - 5000/100) = 1
    assert counts["socks5h://1.1.1.1:1080"] > 60, f"Fast proxy only selected {counts['socks5h://1.1.1.1:1080']} times"


def test_circuit_breaker_quarantines_after_3_failures():
    """Test 3: After 3 report_failure() calls on same proxy, get_proxy() skips it."""
    from netcloak.proxy.pool import ProxyPool
    p = _make_proxy("socks5h://1.2.3.4:1080")
    good = _make_proxy("socks5h://5.6.7.8:1081")
    pool = ProxyPool([p, good], auto_replenish=False)

    pool.report_failure("socks5h://1.2.3.4:1080")
    pool.report_failure("socks5h://1.2.3.4:1080")
    pool.report_failure("socks5h://1.2.3.4:1080")

    for _ in range(20):
        result = pool.get_proxy()
        assert result != "socks5h://1.2.3.4:1080", "Quarantined proxy should not be returned"

    pool.stop()


def test_circuit_breaker_quarantine_expires():
    """Test 4: Circuit breaker quarantine expires after 60s (mock time.monotonic)."""
    from netcloak.proxy import pool as pool_module
    from netcloak.proxy.pool import ProxyPool

    p = _make_proxy("socks5h://1.2.3.4:1080")
    pool_obj = ProxyPool([p], auto_replenish=False)

    base_time = 1000.0

    with patch.object(pool_module, "time") as mock_time:
        mock_time.monotonic.return_value = base_time
        pool_obj.report_failure("socks5h://1.2.3.4:1080")
        pool_obj.report_failure("socks5h://1.2.3.4:1080")
        pool_obj.report_failure("socks5h://1.2.3.4:1080")

        # Still quarantined at base_time + 30
        mock_time.monotonic.return_value = base_time + 30
        result = pool_obj.get_proxy()
        assert result is None

        # Quarantine expired at base_time + 61
        mock_time.monotonic.return_value = base_time + 61
        result = pool_obj.get_proxy()
        assert result == "socks5h://1.2.3.4:1080"

    pool_obj.stop()


def test_report_success_resets_failures():
    """Test 5: report_success() resets failure count to 0."""
    from netcloak.proxy.pool import ProxyPool
    p = _make_proxy("socks5h://1.2.3.4:1080")
    pool = ProxyPool([p], auto_replenish=False)

    pool.report_failure("socks5h://1.2.3.4:1080")
    pool.report_failure("socks5h://1.2.3.4:1080")
    pool.report_success("socks5h://1.2.3.4:1080")

    # Third failure on reset counter — should NOT quarantine yet
    pool.report_failure("socks5h://1.2.3.4:1080")
    result = pool.get_proxy()
    assert result == "socks5h://1.2.3.4:1080"
    pool.stop()


def test_get_proxy_returns_none_when_all_quarantined():
    """Test 6: get_proxy() returns None when all proxies are quarantined."""
    from netcloak.proxy.pool import ProxyPool
    p = _make_proxy("socks5h://1.2.3.4:1080")
    pool = ProxyPool([p], auto_replenish=False)

    pool.report_failure("socks5h://1.2.3.4:1080")
    pool.report_failure("socks5h://1.2.3.4:1080")
    pool.report_failure("socks5h://1.2.3.4:1080")

    assert pool.get_proxy() is None
    pool.stop()


def test_get_stats_returns_expected_keys():
    """Test 7: get_stats() returns dict with pool_size, available, quarantined keys."""
    from netcloak.proxy.pool import ProxyPool
    p1 = _make_proxy("socks5h://1.2.3.4:1080")
    p2 = _make_proxy("socks5h://5.6.7.8:1081")
    pool = ProxyPool([p1, p2], auto_replenish=False)

    pool.report_failure("socks5h://1.2.3.4:1080")
    pool.report_failure("socks5h://1.2.3.4:1080")
    pool.report_failure("socks5h://1.2.3.4:1080")

    stats = pool.get_stats()
    assert "pool_size" in stats
    assert "available" in stats
    assert "quarantined" in stats
    assert stats["pool_size"] == 2
    assert stats["available"] == 1
    assert stats["quarantined"] == 1
    pool.stop()


def test_validated_proxy_dataclass_fields():
    """Test 8: ValidatedProxy dataclass has url, latency_ms, validated_at, failures, quarantine_until."""
    from netcloak.proxy.pool import ValidatedProxy
    field_names = {f.name for f in fields(ValidatedProxy)}
    assert "url" in field_names
    assert "latency_ms" in field_names
    assert "validated_at" in field_names
    assert "failures" in field_names
    assert "quarantine_until" in field_names

    # Defaults
    p = ValidatedProxy(url="socks5h://1.2.3.4:1080", latency_ms=100.0, validated_at=0.0)
    assert p.failures == 0
    assert p.quarantine_until == 0.0


@pytest.mark.asyncio
async def test_validate_async_returns_top_20_by_latency():
    """Test 9: validate_async() returns top 20 sorted by latency, discards >8000ms (mocked)."""
    from netcloak.proxy import pool as pool_module
    from netcloak.proxy.pool import validate_async, ValidatedProxy

    call_counter = {"n": 0}

    async def _fake_validate_one(url, semaphore):
        call_counter["n"] += 1
        # Parse latency from URL port for predictable ordering
        port = int(url.split(":")[-1])
        latency = port * 10.0  # port 1 → 10ms, port 9000 → 90000ms
        if latency > 8000:
            return None
        return ValidatedProxy(url=url, latency_ms=latency, validated_at=0.0)

    with patch.object(pool_module, "_validate_one", side_effect=_fake_validate_one):
        urls = [f"socks5h://1.2.3.4:{i}" for i in range(1, 35)]  # 34 URLs
        results = await validate_async(urls)

    # Max 20 returned
    assert len(results) <= 20
    # Sorted by latency ascending
    for i in range(len(results) - 1):
        assert results[i].latency_ms <= results[i + 1].latency_ms
    # No result > 8000ms
    for r in results:
        assert r.latency_ms <= 8000


def test_health_thread_is_daemon():
    """Test 10: Background health thread is a daemon thread."""
    from netcloak.proxy.pool import ProxyPool
    import threading

    p = _make_proxy("socks5h://1.2.3.4:1080")

    with patch("netcloak.proxy.pool.threading.Thread") as mock_thread_cls:
        mock_thread = MagicMock()
        mock_thread_cls.return_value = mock_thread

        pool = ProxyPool([p], auto_replenish=True)

        # Thread must have been created as daemon
        call_kwargs = mock_thread_cls.call_args
        # daemon=True either as kwarg or set as attribute
        daemon_kwarg = call_kwargs.kwargs.get("daemon", False) if call_kwargs else False
        daemon_attr = mock_thread.daemon

        # Check that daemon was set (either via constructor kwarg or attribute)
        assert daemon_kwarg or daemon_attr or True  # see attribute set below

        # More reliable: check that mock_thread.daemon was set to True
        # OR check the keyword argument passed to Thread()
        if call_kwargs:
            assert call_kwargs.kwargs.get("daemon") is True or mock_thread.daemon is True

        mock_thread.start.assert_called_once()
        pool.stop()
