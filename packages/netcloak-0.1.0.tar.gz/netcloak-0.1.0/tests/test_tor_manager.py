"""Tests for TorManager lifecycle — PID file tracking and cross-invocation stop."""
from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch


def _make_manager(data_dir: str) -> "TorManager":
    from netcloak.tor.manager import TorManager
    return TorManager(
        socks_port=19050,
        control_port=19051,
        dns_port=19053,
        trans_port=19040,
        data_dir=data_dir,
        binary_path="",
    )


class TestTorManagerPidFile:
    """PID file is written after start and cleaned up after stop."""

    def test_start_writes_pid_file(self):
        """start() writes tor.pid containing the process PID after SOCKS5 port opens."""
        with tempfile.TemporaryDirectory() as tmp:
            mgr = _make_manager(tmp)
            mock_proc = MagicMock()
            mock_proc.pid = 12345
            mock_proc.poll.return_value = None

            # First call is from is_running() pre-check (must return False so start
            # proceeds); subsequent calls are from the polling loop (return True).
            port_open_calls = iter([False, True])

            with (
                patch.object(mgr, "_find_tor_binary", return_value="/usr/bin/tor"),
                patch("subprocess.Popen", return_value=mock_proc),
                patch.object(mgr, "_port_open", side_effect=port_open_calls),
            ):
                result = mgr.start()

            assert result is True
            pid_path = Path(tmp) / "tor.pid"
            assert pid_path.exists(), "tor.pid must be created after a successful start()"
            assert pid_path.read_text().strip() == "12345"

    def test_stop_removes_pid_file(self):
        """stop() removes tor.pid regardless of how the process was stopped."""
        with tempfile.TemporaryDirectory() as tmp:
            mgr = _make_manager(tmp)
            pid_path = Path(tmp) / "tor.pid"
            pid_path.write_text("12345")

            mock_proc = MagicMock()
            mgr._process = mock_proc

            mgr.stop()

            assert not pid_path.exists(), "tor.pid must be removed after stop()"

    def test_stop_no_process_reads_pid_file(self):
        """stop() with _process=None reads the PID file and kills the process via psutil."""
        with tempfile.TemporaryDirectory() as tmp:
            mgr = _make_manager(tmp)
            pid_path = Path(tmp) / "tor.pid"
            pid_path.write_text("99999")

            mock_proc = MagicMock()
            mock_proc.wait.return_value = None

            with patch("psutil.Process", return_value=mock_proc) as mock_psutil:
                mgr.stop()

            mock_psutil.assert_called_once_with(99999)
            mock_proc.terminate.assert_called_once()
            assert not pid_path.exists(), "tor.pid must be cleaned up after cross-invocation stop"

    def test_stop_no_process_no_pid_file_is_graceful(self):
        """stop() with _process=None and no PID file prints a warning without raising."""
        with tempfile.TemporaryDirectory() as tmp:
            mgr = _make_manager(tmp)
            # No _process, no pid file
            mgr.stop()  # must not raise


class TestTorManagerGetPid:
    """get_pid() returns the live PID or falls back to the PID file."""

    def test_get_pid_from_live_process(self):
        """get_pid() returns _process.pid when the process is alive."""
        with tempfile.TemporaryDirectory() as tmp:
            mgr = _make_manager(tmp)
            mock_proc = MagicMock()
            mock_proc.pid = 42
            mock_proc.poll.return_value = None
            mgr._process = mock_proc

            assert mgr.get_pid() == 42

    def test_get_pid_from_pid_file_when_no_process(self):
        """get_pid() reads from tor.pid when _process is None."""
        with tempfile.TemporaryDirectory() as tmp:
            mgr = _make_manager(tmp)
            (Path(tmp) / "tor.pid").write_text("7777")

            assert mgr.get_pid() == 7777

    def test_get_pid_returns_none_when_nothing_running(self):
        """get_pid() returns None when there is no process and no PID file."""
        with tempfile.TemporaryDirectory() as tmp:
            mgr = _make_manager(tmp)
            assert mgr.get_pid() is None


class TestTorManagerIsRunning:
    """is_running() reflects SOCKS5 port availability and clears dead _process."""

    def test_is_running_true_when_port_open(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = _make_manager(tmp)
            with patch.object(mgr, "_port_open", return_value=True):
                assert mgr.is_running() is True

    def test_is_running_false_when_port_closed(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = _make_manager(tmp)
            with patch.object(mgr, "_port_open", return_value=False):
                assert mgr.is_running() is False

    def test_is_running_clears_dead_process_ref(self):
        """is_running() sets _process = None when the subprocess has exited."""
        with tempfile.TemporaryDirectory() as tmp:
            mgr = _make_manager(tmp)
            mock_proc = MagicMock()
            mock_proc.poll.return_value = 1  # process exited
            mgr._process = mock_proc

            with patch.object(mgr, "_port_open", return_value=False):
                mgr.is_running()

            assert mgr._process is None
