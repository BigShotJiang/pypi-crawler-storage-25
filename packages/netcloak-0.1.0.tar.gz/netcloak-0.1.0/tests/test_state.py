"""Unit tests for NetworkState — capture, restore, crash recovery, signal registration.

All tests mock subprocess, winreg, and file I/O — no real OS changes.
winreg is Windows-only so it is mocked as a MagicMock module on all platforms.
"""
from __future__ import annotations

import atexit
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, call, patch


# ---------------------------------------------------------------------------
# Helpers: build a mock winreg module usable on non-Windows test runners
# ---------------------------------------------------------------------------

def _make_winreg_mock():
    """Return a MagicMock that mimics winreg enough for NetworkState."""
    m = MagicMock()
    m.HKEY_CURRENT_USER = 0x80000001
    m.REG_DWORD = 4
    m.REG_SZ = 1
    m.OpenKey.return_value.__enter__ = lambda s: s
    m.OpenKey.return_value.__exit__ = MagicMock(return_value=False)
    m.QueryValueEx.return_value = (0, 4)  # (value, type)
    return m


# ---------------------------------------------------------------------------
# Test 1: capture() returns correct top-level keys (Windows path)
# ---------------------------------------------------------------------------

class TestCaptureWindowsKeys(unittest.TestCase):
    """capture() returns dict with timestamp, mode, platform, dns, proxy_registry."""

    def test_capture_returns_required_keys(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict("sys.modules", {"winreg": _make_winreg_mock()}):
                with patch("sys.platform", "win32"):
                    from netcloak.core import state as state_mod
                    import importlib
                    importlib.reload(state_mod)
                    NetworkState = state_mod.NetworkState

                    with (
                        patch.object(state_mod, "_capture_windows_dns",
                                     return_value={}),
                        patch.object(state_mod, "_capture_windows_proxy",
                                     return_value={"ProxyEnable": 0, "ProxyServer": None}),
                        patch.object(state_mod.NetworkState, "_register_handlers"),
                    ):
                        ns = NetworkState(state_dir=tmpdir)
                        result = ns.capture(mode="tor")

        required_keys = {"timestamp", "mode", "platform", "dns", "proxy_registry"}
        self.assertTrue(
            required_keys.issubset(result.keys()),
            f"Missing keys: {required_keys - result.keys()}",
        )
        self.assertEqual(result["mode"], "tor")


# ---------------------------------------------------------------------------
# Test 2: capture() calls _get_adapter_dns for each connected adapter
# ---------------------------------------------------------------------------

class TestCaptureCallsAdapterDns(unittest.TestCase):
    """capture() calls _get_adapter_dns for each connected adapter."""

    def test_dns_captured_per_adapter(self):
        adapters = ["Wi-Fi", "Ethernet"]
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict("sys.modules", {"winreg": _make_winreg_mock()}):
                with patch("sys.platform", "win32"):
                    from netcloak.core import state as state_mod
                    import importlib
                    importlib.reload(state_mod)
                    NetworkState = state_mod.NetworkState

                    mock_get_adapters = MagicMock(return_value=adapters)
                    mock_get_dns = MagicMock(
                        return_value={"mode": "static", "servers": ["8.8.8.8"]}
                    )

                    with (
                        patch.object(state_mod, "_get_connected_adapters_win",
                                     mock_get_adapters),
                        patch.object(state_mod, "_get_adapter_dns_win", mock_get_dns),
                        patch.object(state_mod, "_capture_windows_proxy",
                                     return_value={"ProxyEnable": 0, "ProxyServer": None}),
                        patch.object(state_mod.NetworkState, "_register_handlers"),
                    ):
                        ns = NetworkState(state_dir=tmpdir)
                        result = ns.capture(mode="tor")

        self.assertEqual(mock_get_dns.call_count, len(adapters))
        self.assertEqual(set(result["dns"].keys()), set(adapters))


# ---------------------------------------------------------------------------
# Test 3: capture() reads winreg ProxyEnable and ProxyServer
# ---------------------------------------------------------------------------

class TestCaptureReadsWinreg(unittest.TestCase):
    """capture() reads HKCU Internet Settings ProxyEnable and ProxyServer."""

    def test_proxy_registry_values_captured(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_reg = _make_winreg_mock()
            mock_reg.QueryValueEx.side_effect = [
                (1, 4),    # ProxyEnable = 1
                ("socks=127.0.0.1:9050", 1),  # ProxyServer
            ]
            with patch.dict("sys.modules", {"winreg": mock_reg}):
                with patch("sys.platform", "win32"):
                    from netcloak.core import state as state_mod
                    import importlib
                    importlib.reload(state_mod)
                    NetworkState = state_mod.NetworkState

                    with (
                        patch.object(state_mod, "_capture_windows_dns",
                                     return_value={}),
                        patch.object(state_mod.NetworkState, "_register_handlers"),
                    ):
                        ns = NetworkState(state_dir=tmpdir)
                        result = ns.capture(mode="tor")

        proxy_reg = result["proxy_registry"]
        self.assertIn("ProxyEnable", proxy_reg)
        self.assertIn("ProxyServer", proxy_reg)


# ---------------------------------------------------------------------------
# Test 4: restore() calls netsh for each adapter
# ---------------------------------------------------------------------------

class TestRestoreWindowsNetsh(unittest.TestCase):
    """restore() calls netsh to set DNS back per adapter."""

    def test_restore_calls_netsh_per_adapter(self):
        snapshot = {
            "timestamp": "2026-01-01T00:00:00Z",
            "mode": "tor",
            "platform": "win32",
            "dns": {
                "Wi-Fi": {"mode": "static", "servers": ["8.8.8.8"]},
                "Ethernet": {"mode": "dhcp", "servers": []},
            },
            "proxy_registry": {"ProxyEnable": 0, "ProxyServer": None},
        }
        with tempfile.TemporaryDirectory() as tmpdir:
            state_file = Path(tmpdir) / "network_snapshot.json"
            state_file.write_text(json.dumps(snapshot))

            mock_run = MagicMock(return_value=MagicMock(returncode=0))
            with patch.dict("sys.modules", {"winreg": _make_winreg_mock()}):
                with patch("sys.platform", "win32"):
                    from netcloak.core import state as state_mod
                    import importlib
                    importlib.reload(state_mod)
                    NetworkState = state_mod.NetworkState

                    with (
                        patch.object(state_mod, "_run_netsh", mock_run),
                        patch.object(state_mod, "_restore_windows_proxy"),
                        patch.object(state_mod, "_dns_redirected_by_tor",
                                     False, create=True),
                    ):
                        ns = NetworkState(state_dir=tmpdir)
                        ns.restore()

        # Should have called netsh for both adapters
        self.assertGreaterEqual(mock_run.call_count, 2)


# ---------------------------------------------------------------------------
# Test 5: restore() writes winreg ProxyEnable=0
# ---------------------------------------------------------------------------

class TestRestoreWindowsProxy(unittest.TestCase):
    """restore() writes winreg ProxyEnable to saved value."""

    def test_restore_sets_proxy_enable(self):
        snapshot = {
            "timestamp": "2026-01-01T00:00:00Z",
            "mode": "tor",
            "platform": "win32",
            "dns": {},
            "proxy_registry": {"ProxyEnable": 0, "ProxyServer": None},
        }
        with tempfile.TemporaryDirectory() as tmpdir:
            state_file = Path(tmpdir) / "network_snapshot.json"
            state_file.write_text(json.dumps(snapshot))

            mock_restore_proxy = MagicMock()
            with patch.dict("sys.modules", {"winreg": _make_winreg_mock()}):
                with patch("sys.platform", "win32"):
                    from netcloak.core import state as state_mod
                    import importlib
                    importlib.reload(state_mod)
                    NetworkState = state_mod.NetworkState

                    with (
                        patch.object(state_mod, "_restore_windows_dns"),
                        patch.object(state_mod, "_restore_windows_proxy",
                                     mock_restore_proxy),
                    ):
                        ns = NetworkState(state_dir=tmpdir)
                        ns.restore()

        mock_restore_proxy.assert_called_once()
        call_kwargs = mock_restore_proxy.call_args
        proxy_data = call_kwargs[0][0] if call_kwargs[0] else call_kwargs[1].get("proxy_data", {})
        self.assertIn("ProxyEnable", proxy_data)


# ---------------------------------------------------------------------------
# Test 6: crash recovery — existing state file triggers restore before capture
# ---------------------------------------------------------------------------

class TestCrashRecovery(unittest.TestCase):
    """If state file exists on capture(), restore() is called first."""

    def test_crash_recovery_restores_before_capture(self):
        old_snapshot = {
            "timestamp": "2026-01-01T00:00:00Z",
            "mode": "tor",
            "platform": "win32",
            "dns": {"Wi-Fi": {"mode": "dhcp", "servers": []}},
            "proxy_registry": {"ProxyEnable": 0, "ProxyServer": None},
        }
        with tempfile.TemporaryDirectory() as tmpdir:
            state_file = Path(tmpdir) / "network_snapshot.json"
            state_file.write_text(json.dumps(old_snapshot))

            restore_called = []
            with patch.dict("sys.modules", {"winreg": _make_winreg_mock()}):
                with patch("sys.platform", "win32"):
                    from netcloak.core import state as state_mod
                    import importlib
                    importlib.reload(state_mod)
                    NetworkState = state_mod.NetworkState

                    original_restore = NetworkState.restore

                    def tracking_restore(self_inner):
                        restore_called.append(True)

                    with (
                        patch.object(NetworkState, "restore", tracking_restore),
                        patch.object(state_mod, "_capture_windows_dns",
                                     return_value={}),
                        patch.object(state_mod, "_capture_windows_proxy",
                                     return_value={"ProxyEnable": 0, "ProxyServer": None}),
                        patch.object(NetworkState, "_register_handlers"),
                    ):
                        ns = NetworkState(state_dir=tmpdir)
                        ns.capture(mode="tor")

        self.assertTrue(restore_called, "restore() must be called when state file already exists")


# ---------------------------------------------------------------------------
# Test 7: delete() removes the state file
# ---------------------------------------------------------------------------

class TestDelete(unittest.TestCase):
    """delete() removes the state file if it exists."""

    def test_delete_removes_state_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict("sys.modules", {"winreg": _make_winreg_mock()}):
                from netcloak.core import state as state_mod
                import importlib
                importlib.reload(state_mod)
                NetworkState = state_mod.NetworkState

                ns = NetworkState(state_dir=tmpdir)
                state_file = Path(tmpdir) / "network_snapshot.json"
                state_file.write_text('{"test": true}')
                self.assertTrue(ns.exists())
                ns.delete()
                self.assertFalse(ns.exists())

    def test_delete_is_idempotent(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict("sys.modules", {"winreg": _make_winreg_mock()}):
                from netcloak.core import state as state_mod
                import importlib
                importlib.reload(state_mod)
                NetworkState = state_mod.NetworkState

                ns = NetworkState(state_dir=tmpdir)
                ns.delete()  # File doesn't exist — must not raise


# ---------------------------------------------------------------------------
# Test 8: signal handlers registered (atexit.register called)
# ---------------------------------------------------------------------------

class TestSignalHandlers(unittest.TestCase):
    """_register_handlers() calls atexit.register."""

    def test_atexit_registered(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict("sys.modules", {"winreg": _make_winreg_mock()}):
                from netcloak.core import state as state_mod
                import importlib
                importlib.reload(state_mod)
                NetworkState = state_mod.NetworkState

                with patch("atexit.register") as mock_atexit:
                    ns = NetworkState(state_dir=tmpdir)
                    ns._register_handlers()

        mock_atexit.assert_called()


# ---------------------------------------------------------------------------
# Test 9: capture_linux() saves resolv.conf + iptables-save output
# ---------------------------------------------------------------------------

class TestCaptureLInux(unittest.TestCase):
    """_capture_linux() reads resolv.conf content and iptables-save output."""

    def test_linux_capture_includes_resolv_and_iptables(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            resolv_content = "nameserver 8.8.8.8\n"
            iptables_output = "# Generated by iptables-save\n-A OUTPUT -j ACCEPT\n"

            with patch.dict("sys.modules", {"winreg": _make_winreg_mock()}):
                from netcloak.core import state as state_mod
                import importlib
                importlib.reload(state_mod)
                NetworkState = state_mod.NetworkState

                with (
                    patch("builtins.open",
                          unittest.mock.mock_open(read_data=resolv_content)),
                    patch("subprocess.run") as mock_sub,
                ):
                    mock_sub.return_value = MagicMock(
                        stdout=iptables_output, returncode=0
                    )
                    ns = NetworkState(state_dir=tmpdir)
                    result = ns._capture_linux()

        self.assertIn("resolv_conf", result)
        self.assertIn("iptables_rules", result)
        self.assertEqual(result["resolv_conf"], resolv_content)


# ---------------------------------------------------------------------------
# Test 10: state file written as human-readable JSON with indent=2
# ---------------------------------------------------------------------------

class TestStateFileFormat(unittest.TestCase):
    """State file is written as indent=2 JSON."""

    def test_json_indent_2(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict("sys.modules", {"winreg": _make_winreg_mock()}):
                with patch("sys.platform", "win32"):
                    from netcloak.core import state as state_mod
                    import importlib
                    importlib.reload(state_mod)
                    NetworkState = state_mod.NetworkState

                    with (
                        patch.object(state_mod, "_capture_windows_dns",
                                     return_value={}),
                        patch.object(state_mod, "_capture_windows_proxy",
                                     return_value={"ProxyEnable": 0, "ProxyServer": None}),
                        patch.object(state_mod.NetworkState, "_register_handlers"),
                    ):
                        ns = NetworkState(state_dir=tmpdir)
                        ns.capture(mode="tor")

            state_file = Path(tmpdir) / "network_snapshot.json"
            content = state_file.read_text()
            # indent=2 means lines start with exactly 2 spaces
            self.assertIn("  ", content, "State file must use 2-space indentation")
            # Validate it's valid JSON
            parsed = json.loads(content)
            self.assertIn("timestamp", parsed)


if __name__ == "__main__":
    unittest.main()
