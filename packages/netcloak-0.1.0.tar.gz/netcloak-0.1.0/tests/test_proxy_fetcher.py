"""Tests for proxy.fetcher — mocks the HTTP call and asserts filtering logic."""
from __future__ import annotations

from unittest.mock import MagicMock, patch

# Sample proxy entries matching Proxifly API format
MOCK_PROXIES = [
    {"protocol": "socks5", "ip": "1.2.3.4", "port": 1080, "anonymity": "elite", "country": "US"},
    {"protocol": "socks5", "ip": "5.6.7.8", "port": 1081, "anonymity": "anonymous", "country": "DE"},
    {"protocol": "http", "ip": "9.10.11.12", "port": 8080, "anonymity": "elite", "country": "FR"},
    {"protocol": "socks5", "ip": "13.14.15.16", "port": 1083, "anonymity": "transparent", "country": "RU"},
    {"protocol": "socks4", "ip": "17.18.19.20", "port": 1084, "anonymity": "anonymous", "country": "JP"},
]


def _make_mock_response(data: list) -> MagicMock:
    """Build a mock requests.Response returning JSON proxy list."""
    mock_resp = MagicMock()
    mock_resp.raise_for_status.return_value = None
    mock_resp.json.return_value = data
    return mock_resp


@patch("netcloak.proxy.fetcher.requests.get")
def test_fetch_returns_only_socks5(mock_get):
    """fetch_proxies() should filter out non-socks5 proxies."""
    mock_get.return_value = _make_mock_response(MOCK_PROXIES)

    from netcloak.proxy.fetcher import fetch_proxies
    proxies = fetch_proxies()

    assert len(proxies) > 0, "Expected at least one proxy"
    for p in proxies:
        assert p["protocol"] == "socks5", f"Expected socks5 but got {p['protocol']}"


@patch("netcloak.proxy.fetcher.requests.get")
def test_fetch_filters_transparent(mock_get):
    """fetch_proxies() should exclude 'transparent' anonymity proxies."""
    mock_get.return_value = _make_mock_response(MOCK_PROXIES)

    from netcloak.proxy.fetcher import fetch_proxies
    proxies = fetch_proxies()

    for p in proxies:
        assert p.get("anonymity") != "transparent", (
            f"Transparent proxy should be excluded: {p}"
        )


@patch("netcloak.proxy.fetcher.requests.get")
def test_fetch_empty_response(mock_get):
    """fetch_proxies() should return an empty list when the API returns nothing."""
    mock_get.return_value = _make_mock_response([])

    from netcloak.proxy.fetcher import fetch_proxies
    proxies = fetch_proxies()

    assert proxies == []


@patch("netcloak.proxy.fetcher.requests.get")
def test_fetch_returns_list(mock_get):
    """fetch_proxies() should always return a list."""
    mock_get.return_value = _make_mock_response(MOCK_PROXIES)

    from netcloak.proxy.fetcher import fetch_proxies
    result = fetch_proxies()

    assert isinstance(result, list)


@patch("netcloak.proxy.fetcher.requests.get")
def test_fetch_correct_count(mock_get):
    """fetch_proxies() should return only the 2 valid socks5/elite-or-anonymous proxies."""
    mock_get.return_value = _make_mock_response(MOCK_PROXIES)

    from netcloak.proxy.fetcher import fetch_proxies
    result = fetch_proxies()

    # From MOCK_PROXIES: entries [0] and [1] are socks5 + elite/anonymous
    # Entry [2] is http (filtered), [3] is socks5 transparent (filtered), [4] is socks4 (filtered)
    assert len(result) == 2
