"""Unit tests for TorDNSRedirect — UDP relay proxy and init order.

Tests are designed to run without Administrator privileges (no actual port 53
binding). Real UDP socket tests use high-numbered ports to avoid admin requirement.
"""
from __future__ import annotations

import socket
import threading
import time
import unittest
from unittest.mock import MagicMock, call, patch


class TestTorDNSRedirectInitOrder(unittest.TestCase):
    """BUG 2 regression: DNS backup must happen BEFORE adapter DNS is set to 127.0.0.1."""

    def _make_adapter_list(self):
        return ["Wi-Fi", "Ethernet"]

    @patch("netcloak.routing.dns_tor._is_admin", return_value=True)
    @patch("netcloak.routing.dns_tor._get_connected_adapters")
    @patch("netcloak.routing.dns_tor._get_adapter_dns")
    @patch("netcloak.routing.dns_tor._run")
    @patch("socket.socket")
    def test_backup_before_set_dns(
        self, mock_socket_cls, mock_run, mock_get_dns, mock_get_adapters, mock_admin
    ):
        """_get_adapter_dns must be called for all adapters BEFORE any netsh set dns command."""
        from netcloak.routing.dns_tor import TorDNSRedirect

        adapters = self._make_adapter_list()
        mock_get_adapters.return_value = adapters
        mock_get_dns.return_value = {"mode": "static", "servers": ["8.8.8.8"]}

        # Make socket bind succeed
        mock_sock = MagicMock()
        mock_socket_cls.return_value.__enter__ = lambda s: mock_sock
        mock_socket_cls.return_value.__exit__ = MagicMock(return_value=False)
        mock_socket_cls.return_value = mock_sock

        call_order = []

        def track_get_dns(adapter):
            call_order.append(("backup", adapter))
            return {"mode": "static", "servers": ["8.8.8.8"]}

        def track_run(*args):
            if "set" in args and "dns" in args:
                call_order.append(("set_dns", args))
            result = MagicMock()
            result.returncode = 0
            return result

        mock_get_dns.side_effect = track_get_dns
        mock_run.side_effect = track_run

        redirect = TorDNSRedirect(dns_port=9053)

        # Patch socket binding to avoid actual port 53 requirement
        with patch.object(redirect, "_start_relay_socket", return_value=True):
            redirect.start()

        # All backup calls must precede all set_dns calls
        backup_indices = [i for i, (op, _) in enumerate(call_order) if op == "backup"]
        set_dns_indices = [i for i, (op, _) in enumerate(call_order) if op == "set_dns"]

        if backup_indices and set_dns_indices:
            self.assertLess(
                max(backup_indices),
                min(set_dns_indices),
                "All DNS backups must occur before any netsh set dns call",
            )

    @patch("netcloak.routing.dns_tor._is_admin", return_value=True)
    @patch("netcloak.routing.dns_tor._get_connected_adapters")
    @patch("netcloak.routing.dns_tor._get_adapter_dns")
    @patch("netcloak.routing.dns_tor._run")
    def test_backup_captures_real_servers_not_127(
        self, mock_run, mock_get_dns, mock_get_adapters, mock_admin
    ):
        """Backup must store actual DNS servers, not 127.0.0.1."""
        from netcloak.routing.dns_tor import TorDNSRedirect

        mock_get_adapters.return_value = ["Wi-Fi"]
        real_dns = {"mode": "static", "servers": ["8.8.8.8", "8.8.4.4"]}
        mock_get_dns.return_value = real_dns
        mock_run.return_value = MagicMock(returncode=0)

        redirect = TorDNSRedirect(dns_port=9053)
        with patch.object(redirect, "_start_relay_socket", return_value=True):
            redirect.start()

        self.assertEqual(redirect._saved_dns.get("Wi-Fi"), real_dns)


class TestTorDNSRedirectSocketBind(unittest.TestCase):
    """start() returns False when socket.bind() fails."""

    @patch("netcloak.routing.dns_tor._is_admin", return_value=True)
    @patch("netcloak.routing.dns_tor._get_connected_adapters")
    @patch("netcloak.routing.dns_tor._get_adapter_dns")
    @patch("netcloak.routing.dns_tor._run")
    def test_returns_false_on_bind_failure(
        self, mock_run, mock_get_dns, mock_get_adapters, mock_admin
    ):
        """start() returns False and restores DNS when socket bind fails."""
        from netcloak.routing.dns_tor import TorDNSRedirect

        mock_get_adapters.return_value = ["Wi-Fi"]
        mock_get_dns.return_value = {"mode": "static", "servers": ["1.1.1.1"]}
        mock_run.return_value = MagicMock(returncode=0)

        redirect = TorDNSRedirect(dns_port=9053)

        # Force bind to fail
        with patch("socket.socket") as mock_sock_cls:
            mock_sock = MagicMock()
            mock_sock.bind.side_effect = OSError("Address already in use")
            mock_sock_cls.return_value = mock_sock

            result = redirect.start()

        self.assertFalse(result, "start() must return False when socket bind fails")


class TestTorDNSRelayLoop(unittest.TestCase):
    """UDP relay: query from :listen_port is forwarded to :tor_port and response returned."""

    def _find_free_port(self) -> int:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.bind(("127.0.0.1", 0))
            return s.getsockname()[1]

    def test_relay_forwards_udp_datagram(self):
        """Real UDP relay test: query sent to relay port is forwarded to tor-side and response returned."""
        from netcloak.routing.dns_tor import _dns_relay_loop

        listen_port = self._find_free_port()
        tor_port = self._find_free_port()

        # Create the relay socket
        relay_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        relay_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        relay_sock.bind(("127.0.0.1", listen_port))

        # Create a mock Tor DNS server
        tor_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        tor_sock.bind(("127.0.0.1", tor_port))
        tor_sock.settimeout(3.0)

        stop_event = threading.Event()
        relay_thread = threading.Thread(
            target=_dns_relay_loop,
            args=(relay_sock, tor_port, stop_event),
            daemon=True,
        )
        relay_thread.start()

        # Mock Tor DNS server: echo the query back with a marker
        def tor_server():
            try:
                data, addr = tor_sock.recvfrom(4096)
                response = b"RESPONSE:" + data
                tor_sock.sendto(response, addr)
            except Exception:
                pass

        tor_thread = threading.Thread(target=tor_server, daemon=True)
        tor_thread.start()

        # Client sends a DNS query to the relay
        client_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        client_sock.settimeout(3.0)
        try:
            query = b"\x00\x01DNS_QUERY_DATA"
            client_sock.sendto(query, ("127.0.0.1", listen_port))
            response, _ = client_sock.recvfrom(4096)
            self.assertEqual(response, b"RESPONSE:" + query)
        finally:
            stop_event.set()
            relay_thread.join(timeout=3)
            client_sock.close()
            relay_sock.close()
            tor_sock.close()

    def test_relay_uses_sock_dgram(self):
        """_dns_relay_loop creates a new UDP socket per relay iteration."""
        from netcloak.routing import dns_tor

        # Verify the module uses SOCK_DGRAM constant
        import inspect
        source = inspect.getsource(dns_tor._dns_relay_loop)
        self.assertIn("SOCK_DGRAM", source)


class TestTorDNSRedirectStop(unittest.TestCase):
    """stop() signals thread to exit and restores DNS."""

    @patch("netcloak.routing.dns_tor._is_admin", return_value=True)
    @patch("netcloak.routing.dns_tor._get_connected_adapters")
    @patch("netcloak.routing.dns_tor._get_adapter_dns")
    @patch("netcloak.routing.dns_tor._run")
    def test_stop_restores_dns_and_clears_saved(
        self, mock_run, mock_get_dns, mock_get_adapters, mock_admin
    ):
        """stop() restores DNS for all saved adapters and clears _saved_dns."""
        from netcloak.routing.dns_tor import TorDNSRedirect

        mock_get_adapters.return_value = ["Wi-Fi"]
        mock_get_dns.return_value = {"mode": "static", "servers": ["8.8.8.8"]}
        mock_run.return_value = MagicMock(returncode=0)

        redirect = TorDNSRedirect(dns_port=9053)
        with patch.object(redirect, "_start_relay_socket", return_value=True):
            redirect.start()

        self.assertIn("Wi-Fi", redirect._saved_dns)
        redirect.stop()

        self.assertEqual(redirect._saved_dns, {}, "stop() must clear _saved_dns")

        # Verify a restore netsh call was made (args are passed as positional varargs)
        restore_calls = [
            c for c in mock_run.call_args_list
            if "set" in c.args and "dns" in c.args and "static" in c.args
        ]
        self.assertTrue(len(restore_calls) >= 1, "stop() must restore adapter DNS")

    @patch("netcloak.routing.dns_tor._is_admin", return_value=True)
    @patch("netcloak.routing.dns_tor._get_connected_adapters")
    @patch("netcloak.routing.dns_tor._get_adapter_dns")
    @patch("netcloak.routing.dns_tor._run")
    def test_stop_sets_stop_event(
        self, mock_run, mock_get_dns, mock_get_adapters, mock_admin
    ):
        """stop() sets _stop_event to signal relay thread exit."""
        from netcloak.routing.dns_tor import TorDNSRedirect

        mock_get_adapters.return_value = ["Wi-Fi"]
        mock_get_dns.return_value = {"mode": "dhcp", "servers": []}
        mock_run.return_value = MagicMock(returncode=0)

        redirect = TorDNSRedirect(dns_port=9053)
        with patch.object(redirect, "_start_relay_socket", return_value=True):
            redirect.start()

        self.assertFalse(redirect._stop_event.is_set())
        redirect.stop()
        self.assertTrue(redirect._stop_event.is_set())


if __name__ == "__main__":
    unittest.main()
