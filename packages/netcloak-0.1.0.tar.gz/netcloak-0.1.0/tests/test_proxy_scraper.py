"""Tests for netcloak.proxy.scraper — async multi-source SOCKS5 fetcher."""
from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SOURCE_0 = "https://api.proxyscrape.com/?request=getproxies&proxytype=socks5&country=all"
_SOURCE_1 = "https://www.proxy-list.download/api/v1/get?type=socks5"
_SOURCE_2 = "https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks5/data.txt"
_SOURCE_3 = "https://api.proxyscrape.com/?request=getproxies&proxytype=http&country=all"

_PROXY_A = "1.2.3.4:1080"
_PROXY_B = "5.6.7.8:1081"
_PROXY_C = "9.10.11.12:1082"
_PROXY_D = "13.14.15.16:1083"

# ---------------------------------------------------------------------------
# Mock factory for aiohttp.ClientSession
# ---------------------------------------------------------------------------

def _make_session_mock(url_to_text: dict) -> MagicMock:
    """Return a mock aiohttp.ClientSession whose get() returns preset text."""

    async def _get_text():
        pass

    class _FakeResponse:
        def __init__(self, text):
            self._text = text

        async def text(self):
            return self._text

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            pass

    class _FakeSession:
        def get(self, url, **kwargs):
            text = url_to_text.get(url, "")
            if isinstance(text, Exception):
                raise text
            return _FakeResponse(text)

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            pass

    return _FakeSession()


def _make_timeout_session(timeout_url: str, other_text: str) -> MagicMock:
    """Return a session mock where timeout_url raises asyncio.TimeoutError."""

    class _TimeoutResponse:
        async def text(self):
            raise asyncio.TimeoutError

        async def __aenter__(self):
            raise asyncio.TimeoutError

        async def __aexit__(self, *args):
            pass

    class _GoodResponse:
        def __init__(self, text):
            self._text = text

        async def text(self):
            return self._text

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            pass

    class _MixedSession:
        def get(self, url, **kwargs):
            if url == timeout_url:
                return _TimeoutResponse()
            return _GoodResponse(other_text)

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            pass

    return _MixedSession()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_scrape_all_fetches_all_4_sources():
    """Test 1: scrape_all() fetches all 4 sources concurrently."""
    from netcloak.proxy.scraper import scrape_all, _SOURCES

    url_to_text = {
        _SOURCES[0]: f"{_PROXY_A}\n",
        _SOURCES[1]: f"{_PROXY_B}\n",
        _SOURCES[2]: f"{_PROXY_C}\n",
        _SOURCES[3]: f"{_PROXY_D}\n",
    }
    session = _make_session_mock(url_to_text)

    with patch("aiohttp.ClientSession", return_value=session):
        results = await scrape_all()

    assert f"socks5h://{_PROXY_A}" in results
    assert f"socks5h://{_PROXY_B}" in results
    assert f"socks5h://{_PROXY_C}" in results
    assert f"socks5h://{_PROXY_D}" in results


@pytest.mark.asyncio
async def test_scrape_all_deduplicates():
    """Test 2: Identical proxies from different sources appear only once."""
    from netcloak.proxy.scraper import scrape_all, _SOURCES

    # Source 0 and 1 both return PROXY_A
    url_to_text = {
        _SOURCES[0]: f"{_PROXY_A}\n{_PROXY_B}\n",
        _SOURCES[1]: f"{_PROXY_A}\n",  # duplicate
        _SOURCES[2]: f"{_PROXY_C}\n",
        _SOURCES[3]: f"{_PROXY_D}\n",
    }
    session = _make_session_mock(url_to_text)

    with patch("aiohttp.ClientSession", return_value=session):
        results = await scrape_all()

    assert results.count(f"socks5h://{_PROXY_A}") == 1


@pytest.mark.asyncio
async def test_scrape_all_parses_valid_ip_port_only():
    """Test 3: IP:PORT parsing — only valid lines accepted, garbage ignored."""
    from netcloak.proxy.scraper import scrape_all, _SOURCES

    garbage_text = (
        f"{_PROXY_A}\n"
        "not-an-ip\n"
        "999.999.999.999:1080\n"  # invalid IP octets
        "1.2.3.4\n"              # missing port
        ":1080\n"                # missing IP
        "abc:xyz\n"              # non-numeric
        f"{_PROXY_B}\n"
    )
    url_to_text = {
        _SOURCES[0]: garbage_text,
        _SOURCES[1]: "",
        _SOURCES[2]: "",
        _SOURCES[3]: "",
    }
    session = _make_session_mock(url_to_text)

    with patch("aiohttp.ClientSession", return_value=session):
        results = await scrape_all()

    assert f"socks5h://{_PROXY_A}" in results
    assert f"socks5h://{_PROXY_B}" in results
    # Garbage lines must NOT appear
    for r in results:
        assert r.startswith("socks5h://")
        # Must match IP:PORT pattern
        host_port = r.replace("socks5h://", "")
        parts = host_port.split(":")
        assert len(parts) == 2
        assert parts[1].isdigit()


@pytest.mark.asyncio
async def test_scrape_all_timeout_source_returns_empty_others_succeed():
    """Test 4: Source that times out returns empty list; other sources still succeed."""
    from netcloak.proxy.scraper import scrape_all, _SOURCES

    session = _make_timeout_session(_SOURCES[0], f"{_PROXY_B}\n{_PROXY_C}\n")

    with patch("aiohttp.ClientSession", return_value=session):
        results = await scrape_all()

    # Non-timed-out sources must still contribute
    assert f"socks5h://{_PROXY_B}" in results
    assert f"socks5h://{_PROXY_C}" in results


@pytest.mark.asyncio
async def test_scrape_all_all_sources_fail_returns_empty():
    """Test 5: All sources fail — returns empty list, no exception raised."""
    from netcloak.proxy.scraper import scrape_all, _SOURCES

    url_to_text = {url: "" for url in _SOURCES}
    # All sources raise exception
    class _ErrorSession:
        def get(self, url, **kwargs):
            class _ErrResp:
                async def __aenter__(self):
                    raise OSError("network error")
                async def __aexit__(self, *a):
                    pass
            return _ErrResp()

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            pass

    with patch("aiohttp.ClientSession", return_value=_ErrorSession()):
        results = await scrape_all()

    assert results == []


def test_scrape_proxies_is_sync_wrapper():
    """Test 6: scrape_proxies() is synchronous wrapper calling asyncio.run(scrape_all())."""
    from netcloak.proxy import scraper

    called_with = []

    async def _fake_scrape_all():
        return [f"socks5h://{_PROXY_A}"]

    with patch.object(scraper, "scrape_all", side_effect=_fake_scrape_all):
        result = scraper.scrape_proxies()

    assert result == [f"socks5h://{_PROXY_A}"]


def test_disk_cache_returns_cached_if_fresh(tmp_path):
    """Test 7: scrape_proxies_cached() reads from cache file if TTL not expired."""
    from netcloak.proxy import scraper

    cached_proxies = [f"socks5h://{_PROXY_A}", f"socks5h://{_PROXY_B}"]
    cache_data = {"timestamp": time.time(), "proxies": cached_proxies}
    cache_file = tmp_path / "proxy_cache.json"
    cache_file.write_text(json.dumps(cache_data))

    with patch.object(scraper, "_cache_path", return_value=cache_file):
        with patch.object(scraper, "scrape_proxies") as mock_scrape:
            result = scraper.scrape_proxies_cached()

    mock_scrape.assert_not_called()
    assert result == cached_proxies


def test_disk_cache_fetches_fresh_if_expired(tmp_path):
    """Test 8: scrape_proxies_cached() fetches fresh if TTL expired."""
    from netcloak.proxy import scraper

    old_timestamp = time.time() - (31 * 60)  # 31 minutes ago (expired)
    cache_data = {"timestamp": old_timestamp, "proxies": [f"socks5h://{_PROXY_A}"]}
    cache_file = tmp_path / "proxy_cache.json"
    cache_file.write_text(json.dumps(cache_data))

    fresh_proxies = [f"socks5h://{_PROXY_C}", f"socks5h://{_PROXY_D}"]

    with patch.object(scraper, "_cache_path", return_value=cache_file):
        with patch.object(scraper, "scrape_proxies", return_value=fresh_proxies) as mock_scrape:
            result = scraper.scrape_proxies_cached()

    mock_scrape.assert_called_once()
    assert result == fresh_proxies
    # Cache file should be updated
    updated = json.loads(cache_file.read_text())
    assert updated["proxies"] == fresh_proxies


@pytest.mark.asyncio
async def test_returned_urls_are_socks5h_format():
    """Test 9: Returned URLs are all in 'socks5h://IP:PORT' format."""
    from netcloak.proxy.scraper import scrape_all, _SOURCES

    url_to_text = {
        _SOURCES[0]: f"{_PROXY_A}\n{_PROXY_B}\n",
        _SOURCES[1]: f"{_PROXY_C}\n",
        _SOURCES[2]: f"{_PROXY_D}\n",
        _SOURCES[3]: "",
    }
    session = _make_session_mock(url_to_text)

    with patch("aiohttp.ClientSession", return_value=session):
        results = await scrape_all()

    for url in results:
        assert url.startswith("socks5h://"), f"Expected socks5h:// prefix, got: {url}"
        # IP:PORT after prefix
        host_port = url[len("socks5h://"):]
        ip, port = host_port.rsplit(":", 1)
        octets = ip.split(".")
        assert len(octets) == 4
        assert all(o.isdigit() for o in octets)
        assert port.isdigit()
