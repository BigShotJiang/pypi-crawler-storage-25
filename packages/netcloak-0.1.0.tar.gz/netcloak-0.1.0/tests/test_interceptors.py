"""Unit tests for TrafficInterceptor ABC and platform implementations.

Tests run without OS privileges: winreg, subprocess, TorDNSRedirect, and
_broadcast_settings_change are all mocked. The test file is designed to work
on any platform (Windows, Linux, macOS).
"""
from __future__ import annotations

import sys
import types
import unittest
from unittest.mock import MagicMock, call, patch


# ---------------------------------------------------------------------------
# Helpers — inject a fake winreg module so imports work on non-Windows
# ---------------------------------------------------------------------------

def _make_fake_winreg():
    """Return a MagicMock winreg module with required constants."""
    winreg = MagicMock()
    winreg.HKEY_CURRENT_USER = 0x80000001
    winreg.KEY_SET_VALUE = 0x0002
    winreg.REG_DWORD = 4
    winreg.REG_SZ = 1
    return winreg


class TestTrafficInterceptorABC(unittest.TestCase):
    """Test 10: TrafficInterceptor ABC cannot be instantiated directly."""

    def test_abc_cannot_be_instantiated(self):
        from netcloak.interceptors.base import TrafficInterceptor
        with self.assertRaises(TypeError):
            TrafficInterceptor()  # type: ignore[abstract]

    def test_abc_has_required_abstract_methods(self):
        from netcloak.interceptors.base import TrafficInterceptor
        abstract_methods = getattr(TrafficInterceptor, "__abstractmethods__", set())
        self.assertIn("activate", abstract_methods)
        self.assertIn("deactivate", abstract_methods)
        self.assertIn("is_active", abstract_methods)


class TestWindowsInterceptorRegistry(unittest.TestCase):
    """Tests 1, 6: Registry proxy set/clear."""

    def setUp(self):
        self._fake_winreg = _make_fake_winreg()
        sys.modules["winreg"] = self._fake_winreg

    def tearDown(self):
        sys.modules.pop("winreg", None)
        # Remove cached module so next import re-runs with fresh mocks
        sys.modules.pop("netcloak.interceptors.windows", None)

    @patch("subprocess.run")
    @patch("netcloak.routing.windows_routing._broadcast_settings_change")
    @patch("netcloak.routing.dns_tor.TorDNSRedirect")
    @patch("netcloak.routing.dns.mark_dns_redirected")
    def test_activate_sets_proxy_enable_and_server(
        self, mock_mark, mock_tor_cls, mock_broadcast, mock_subproc
    ):
        """Test 1: activate() sets ProxyEnable=1 and ProxyServer='socks=127.0.0.1:9050'."""
        mock_tor = MagicMock()
        mock_tor.start.return_value = True
        mock_tor_cls.return_value = mock_tor
        mock_subproc.return_value = MagicMock(returncode=0, stdout="", stderr="")

        from netcloak.interceptors.windows import WindowsInterceptor
        interceptor = WindowsInterceptor(socks_port=9050, dns_port=9053)
        interceptor.activate()

        winreg = self._fake_winreg
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
        winreg.OpenKey.assert_called()

        # Collect all SetValueEx calls
        set_calls = winreg.SetValueEx.call_args_list
        keys_set = {c.args[1]: c.args[4] for c in set_calls}

        self.assertEqual(keys_set.get("ProxyEnable"), 1,
                         "ProxyEnable must be set to 1")
        self.assertEqual(keys_set.get("ProxyServer"), "socks=127.0.0.1:9050",
                         "ProxyServer must be 'socks=127.0.0.1:9050'")

    @patch("subprocess.run")
    @patch("netcloak.routing.windows_routing._broadcast_settings_change")
    @patch("netcloak.routing.dns_tor.TorDNSRedirect")
    @patch("netcloak.routing.dns.mark_dns_redirected")
    def test_deactivate_sets_proxy_enable_zero_and_deletes_server(
        self, mock_mark, mock_tor_cls, mock_broadcast, mock_subproc
    ):
        """Test 6: deactivate() sets ProxyEnable=0 and deletes ProxyServer."""
        mock_tor = MagicMock()
        mock_tor.start.return_value = True
        mock_tor_cls.return_value = mock_tor
        mock_subproc.return_value = MagicMock(returncode=0, stdout="", stderr="")

        from netcloak.interceptors.windows import WindowsInterceptor
        interceptor = WindowsInterceptor()
        interceptor.activate()

        # Reset mocks before deactivate
        self._fake_winreg.SetValueEx.reset_mock()
        self._fake_winreg.DeleteValue.reset_mock()

        interceptor.deactivate()

        set_calls = self._fake_winreg.SetValueEx.call_args_list
        keys_set = {c.args[1]: c.args[4] for c in set_calls}
        self.assertEqual(keys_set.get("ProxyEnable"), 0,
                         "ProxyEnable must be set to 0 on deactivate")

        del_calls = [c.args[1] for c in self._fake_winreg.DeleteValue.call_args_list]
        self.assertIn("ProxyServer", del_calls,
                      "ProxyServer must be deleted on deactivate")


class TestWindowsInterceptorDNS(unittest.TestCase):
    """Tests 2, 7: TorDNSRedirect and mark/clear_dns_redirected."""

    def setUp(self):
        self._fake_winreg = _make_fake_winreg()
        sys.modules["winreg"] = self._fake_winreg

    def tearDown(self):
        sys.modules.pop("winreg", None)
        sys.modules.pop("netcloak.interceptors.windows", None)

    @patch("subprocess.run")
    @patch("netcloak.routing.windows_routing._broadcast_settings_change")
    @patch("netcloak.routing.dns.mark_dns_redirected")
    @patch("netcloak.routing.dns_tor.TorDNSRedirect")
    def test_activate_calls_tor_dns_redirect_and_mark(
        self, mock_tor_cls, mock_mark, mock_broadcast, mock_subproc
    ):
        """Test 2: activate() calls TorDNSRedirect.start() and mark_dns_redirected()."""
        mock_tor = MagicMock()
        mock_tor.start.return_value = True
        mock_tor_cls.return_value = mock_tor
        mock_subproc.return_value = MagicMock(returncode=0, stdout="", stderr="")

        from netcloak.interceptors.windows import WindowsInterceptor
        interceptor = WindowsInterceptor(dns_port=9053)
        interceptor.activate()

        mock_tor_cls.assert_called_once_with(dns_port=9053)
        mock_tor.start.assert_called_once()
        mock_mark.assert_called_once()

    @patch("subprocess.run")
    @patch("netcloak.routing.windows_routing._broadcast_settings_change")
    @patch("netcloak.routing.dns.clear_dns_redirected")
    @patch("netcloak.routing.dns.mark_dns_redirected")
    @patch("netcloak.routing.dns_tor.TorDNSRedirect")
    def test_deactivate_calls_tor_stop_and_clear(
        self, mock_tor_cls, mock_mark, mock_clear, mock_broadcast, mock_subproc
    ):
        """Test 7: deactivate() calls TorDNSRedirect.stop() and clear_dns_redirected()."""
        mock_tor = MagicMock()
        mock_tor.start.return_value = True
        mock_tor_cls.return_value = mock_tor
        mock_subproc.return_value = MagicMock(returncode=0, stdout="", stderr="")

        from netcloak.interceptors.windows import WindowsInterceptor
        interceptor = WindowsInterceptor()
        interceptor.activate()
        interceptor.deactivate()

        mock_tor.stop.assert_called_once()
        mock_clear.assert_called_once()


class TestWindowsInterceptorBroadcast(unittest.TestCase):
    """Test 3: _broadcast_settings_change() called after registry set."""

    def setUp(self):
        self._fake_winreg = _make_fake_winreg()
        sys.modules["winreg"] = self._fake_winreg

    def tearDown(self):
        sys.modules.pop("winreg", None)
        sys.modules.pop("netcloak.interceptors.windows", None)

    @patch("subprocess.run")
    @patch("netcloak.routing.dns.mark_dns_redirected")
    @patch("netcloak.routing.dns_tor.TorDNSRedirect")
    @patch("netcloak.routing.windows_routing._broadcast_settings_change")
    def test_activate_broadcasts_after_registry_set(
        self, mock_broadcast, mock_tor_cls, mock_mark, mock_subproc
    ):
        """Test 3: _broadcast_settings_change() is called during activate()."""
        mock_tor = MagicMock()
        mock_tor.start.return_value = True
        mock_tor_cls.return_value = mock_tor
        mock_subproc.return_value = MagicMock(returncode=0, stdout="", stderr="")

        call_order = []
        winreg = self._fake_winreg

        def track_set_value_ex(*args, **kwargs):
            call_order.append("registry_set")

        def track_broadcast():
            call_order.append("broadcast")

        winreg.SetValueEx.side_effect = track_set_value_ex
        mock_broadcast.side_effect = track_broadcast

        from netcloak.interceptors.windows import WindowsInterceptor
        interceptor = WindowsInterceptor()
        interceptor.activate()

        # broadcast must occur, and after at least one registry write
        self.assertIn("broadcast", call_order, "_broadcast_settings_change must be called")
        self.assertIn("registry_set", call_order, "Registry must be set")
        first_reg = next(i for i, op in enumerate(call_order) if op == "registry_set")
        first_broadcast = next(i for i, op in enumerate(call_order) if op == "broadcast")
        self.assertGreater(first_broadcast, first_reg,
                           "_broadcast_settings_change must come AFTER registry set")

    @patch("subprocess.run")
    @patch("netcloak.routing.dns.clear_dns_redirected")
    @patch("netcloak.routing.dns.mark_dns_redirected")
    @patch("netcloak.routing.dns_tor.TorDNSRedirect")
    @patch("netcloak.routing.windows_routing._broadcast_settings_change")
    def test_deactivate_broadcasts_after_registry_clear(
        self, mock_broadcast, mock_tor_cls, mock_mark, mock_clear, mock_subproc
    ):
        """Test 6 (broadcast part): deactivate() calls _broadcast_settings_change()."""
        mock_tor = MagicMock()
        mock_tor.start.return_value = True
        mock_tor_cls.return_value = mock_tor
        mock_subproc.return_value = MagicMock(returncode=0, stdout="", stderr="")

        from netcloak.interceptors.windows import WindowsInterceptor
        interceptor = WindowsInterceptor()
        interceptor.activate()
        mock_broadcast.reset_mock()
        interceptor.deactivate()

        mock_broadcast.assert_called()


class TestWindowsInterceptorIPv6DNS(unittest.TestCase):
    """Test 4: IPv6 DNS set to ::1 on connected adapters."""

    def setUp(self):
        self._fake_winreg = _make_fake_winreg()
        sys.modules["winreg"] = self._fake_winreg

    def tearDown(self):
        sys.modules.pop("winreg", None)
        sys.modules.pop("netcloak.interceptors.windows", None)

    @patch("netcloak.routing.dns.mark_dns_redirected")
    @patch("netcloak.routing.dns_tor.TorDNSRedirect")
    @patch("netcloak.routing.windows_routing._broadcast_settings_change")
    @patch("subprocess.run")
    def test_activate_sets_ipv6_dns(
        self, mock_subproc, mock_broadcast, mock_tor_cls, mock_mark
    ):
        """Test 4: activate() runs netsh ipv6 set dnsservers ... static ::1."""
        mock_tor = MagicMock()
        mock_tor.start.return_value = True
        mock_tor_cls.return_value = mock_tor

        netsh_ipv6_output = (
            "Admin State    State          Type             Interface Name\n"
            "-------------------------------------------------------------------------\n"
            "Enabled        Connected      Dedicated        Wi-Fi\n"
        )

        def fake_subproc(args, **kwargs):
            result = MagicMock()
            result.returncode = 0
            result.stdout = netsh_ipv6_output if "show" in args and "interface" in args else ""
            result.stderr = ""
            return result

        mock_subproc.side_effect = fake_subproc

        from netcloak.interceptors.windows import WindowsInterceptor
        interceptor = WindowsInterceptor()
        interceptor.activate()

        all_calls = [c.args[0] for c in mock_subproc.call_args_list if c.args]
        ipv6_calls = [
            c for c in all_calls
            if "netsh" in c and "ipv6" in c and "dnsservers" in c and "::1" in c
        ]
        self.assertTrue(len(ipv6_calls) >= 1,
                        "activate() must call netsh interface ipv6 set dnsservers ... static ::1")


class TestWindowsInterceptorFlushDNS(unittest.TestCase):
    """Test 5: DNS cache flushed via ipconfig /flushdns."""

    def setUp(self):
        self._fake_winreg = _make_fake_winreg()
        sys.modules["winreg"] = self._fake_winreg

    def tearDown(self):
        sys.modules.pop("winreg", None)
        sys.modules.pop("netcloak.interceptors.windows", None)

    @patch("netcloak.routing.dns.mark_dns_redirected")
    @patch("netcloak.routing.dns_tor.TorDNSRedirect")
    @patch("netcloak.routing.windows_routing._broadcast_settings_change")
    @patch("subprocess.run")
    def test_activate_flushes_dns_cache(
        self, mock_subproc, mock_broadcast, mock_tor_cls, mock_mark
    ):
        """Test 5: activate() calls ipconfig /flushdns."""
        mock_tor = MagicMock()
        mock_tor.start.return_value = True
        mock_tor_cls.return_value = mock_tor
        mock_subproc.return_value = MagicMock(returncode=0, stdout="", stderr="")

        from netcloak.interceptors.windows import WindowsInterceptor
        interceptor = WindowsInterceptor()
        interceptor.activate()

        all_calls = [c.args[0] for c in mock_subproc.call_args_list if c.args]
        flush_calls = [c for c in all_calls if "ipconfig" in c and "/flushdns" in c]
        self.assertTrue(len(flush_calls) >= 1,
                        "activate() must call ipconfig /flushdns")


class TestLinuxInterceptorIptables(unittest.TestCase):
    """Tests 8, 9: LinuxInterceptor iptables rules."""

    def _get_interceptor(self, **kwargs):
        """Import and return a LinuxInterceptor, injecting a fake pwd if needed."""
        if "pwd" not in sys.modules:
            fake_pwd = MagicMock()
            pw_entry = MagicMock()
            pw_entry.pw_uid = 1000
            fake_pwd.getpwnam.return_value = pw_entry
            sys.modules["pwd"] = fake_pwd
        from netcloak.interceptors.linux import LinuxInterceptor
        return LinuxInterceptor(**kwargs)

    @patch("subprocess.run")
    def test_activate_applies_iptables_redirect_rules(self, mock_subproc):
        """Test 8: activate() calls iptables with UDP :53 redirect and TCP SYN redirect."""
        mock_subproc.return_value = MagicMock(returncode=0, stdout="", stderr="")

        # Patch _require_root so no privilege check runs in test
        interceptor = self._get_interceptor(dns_port=5353, trans_port=9040)
        with patch.object(interceptor, "_require_root"), \
             patch("shutil.copy2"), \
             patch("pathlib.Path.write_text"), \
             patch("pathlib.Path.exists", return_value=True):
            interceptor.activate()

        all_calls = [c.args[0] for c in mock_subproc.call_args_list if c.args]
        iptables_calls = [c for c in all_calls if c and "iptables" in c]

        # Must have at least one DNS redirect (UDP port 53) and one TCP redirect
        dns_redirects = [
            c for c in iptables_calls
            if "53" in c and "REDIRECT" in c
        ]
        tcp_redirects = [
            c for c in iptables_calls
            if ("tcp" in c or "TCP" in c) and "REDIRECT" in c
        ]
        self.assertTrue(len(dns_redirects) >= 1,
                        "activate() must redirect UDP port 53")
        self.assertTrue(len(tcp_redirects) >= 1,
                        "activate() must redirect TCP traffic to trans_port")

    @patch("subprocess.run")
    def test_deactivate_does_not_flush_all_rules(self, mock_subproc):
        """Test 9: deactivate() flushes only netcloak-tagged rules, NOT iptables -F."""
        mock_subproc.return_value = MagicMock(returncode=0, stdout="", stderr="")

        interceptor = self._get_interceptor()
        interceptor._active = True  # Simulate active state
        with patch("shutil.copy2"), \
             patch("pathlib.Path.exists", return_value=True), \
             patch("pathlib.Path.read_text", return_value="nameserver 8.8.8.8\n"), \
             patch("pathlib.Path.unlink"):
            interceptor.deactivate()

        all_calls = [c.args[0] for c in mock_subproc.call_args_list if c.args]
        flush_all_calls = [c for c in all_calls if c == ["iptables", "-F"]]
        self.assertEqual(len(flush_all_calls), 0,
                         "deactivate() must NOT call iptables -F (would wipe all rules)")


if __name__ == "__main__":
    unittest.main()
