"""Unit tests for netcloak.proxy.listener.Socks5Listener.

Tests cover:
- __init__ stores pool, host, port correctly
- Listener binds to 127.0.0.1 only (never 0.0.0.0)
- _parse_proxy_url correctly handles socks5h:// and socks5:// schemes
- SOCKS5 greeting (VER=5) returns METHOD=0
- Unsupported SOCKS5 commands (BIND, UDP ASSOCIATE) rejected with 0x07
- Empty pool handling returns general failure (0x01)
- Daemon thread lifecycle: start/stop/is_alive
"""
from __future__ import annotations

import asyncio
import socket
import struct
import threading
import time
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from python_socks import ProxyType

from netcloak.proxy.listener import Socks5Listener
from netcloak.proxy.pool import ProxyPool, ValidatedProxy


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_pool(proxies=None) -> ProxyPool:
    """Create a ProxyPool with auto_replenish=False for test isolation."""
    if proxies is None:
        proxies = [
            ValidatedProxy(
                url="socks5h://127.0.0.1:9050",
                latency_ms=50.0,
                validated_at=time.monotonic(),
            )
        ]
    return ProxyPool(proxies=proxies, auto_replenish=False)


# ---------------------------------------------------------------------------
# Test 1: __init__ stores pool, host, port correctly
# ---------------------------------------------------------------------------

class TestSocks5ListenerInit(unittest.TestCase):
    def test_init_stores_pool_host_port(self):
        pool = _make_pool()
        listener = Socks5Listener(pool=pool, port=8888, host="127.0.0.1")
        self.assertIs(listener._pool, pool)
        self.assertEqual(listener._port, 8888)
        self.assertEqual(listener._host, "127.0.0.1")
        self.assertIsNone(listener._server)
        self.assertIsNone(listener._thread)
        self.assertIsNone(listener._loop)

    def test_init_default_host_is_loopback(self):
        """Default host must be 127.0.0.1, never 0.0.0.0."""
        pool = _make_pool()
        listener = Socks5Listener(pool=pool, port=8080)
        self.assertEqual(listener._host, "127.0.0.1")

    def test_init_default_port(self):
        pool = _make_pool()
        listener = Socks5Listener(pool=pool)
        self.assertEqual(listener._port, 8080)


# ---------------------------------------------------------------------------
# Test 2: Listener binds to 127.0.0.1 only
# ---------------------------------------------------------------------------

class TestSocks5ListenerBindAddress(unittest.TestCase):
    def test_host_stored_is_loopback(self):
        """Verify host is stored as 127.0.0.1, not 0.0.0.0."""
        pool = _make_pool()
        listener = Socks5Listener(pool=pool, port=8080)
        self.assertEqual(listener._host, "127.0.0.1")
        self.assertNotEqual(listener._host, "0.0.0.0")

    def test_cannot_override_host_to_wildcard(self):
        """Creating with host='0.0.0.0' should raise ValueError."""
        pool = _make_pool()
        with self.assertRaises(ValueError):
            Socks5Listener(pool=pool, port=8080, host="0.0.0.0")

    def test_cannot_override_host_to_empty_string(self):
        """Creating with host='' should raise ValueError."""
        pool = _make_pool()
        with self.assertRaises(ValueError):
            Socks5Listener(pool=pool, port=8080, host="")


# ---------------------------------------------------------------------------
# Test 3 & 4: _parse_proxy_url
# ---------------------------------------------------------------------------

class TestParseProxyUrl(unittest.TestCase):
    def test_socks5h_url(self):
        """socks5h:// URL must yield rdns=True."""
        proxy_type, host, port, rdns = Socks5Listener._parse_proxy_url(
            "socks5h://1.2.3.4:1080"
        )
        self.assertEqual(proxy_type, ProxyType.SOCKS5)
        self.assertEqual(host, "1.2.3.4")
        self.assertEqual(port, 1080)
        self.assertTrue(rdns)

    def test_socks5_url(self):
        """socks5:// URL must yield rdns=False."""
        proxy_type, host, port, rdns = Socks5Listener._parse_proxy_url(
            "socks5://1.2.3.4:1080"
        )
        self.assertEqual(proxy_type, ProxyType.SOCKS5)
        self.assertEqual(host, "1.2.3.4")
        self.assertEqual(port, 1080)
        self.assertFalse(rdns)

    def test_high_port_number(self):
        proxy_type, host, port, rdns = Socks5Listener._parse_proxy_url(
            "socks5h://192.168.1.100:64000"
        )
        self.assertEqual(port, 64000)
        self.assertTrue(rdns)

    def test_socks5h_with_hostname(self):
        """Domain-only proxies (socks5h) must also be handled."""
        proxy_type, host, port, rdns = Socks5Listener._parse_proxy_url(
            "socks5h://proxy.example.com:9050"
        )
        self.assertEqual(host, "proxy.example.com")
        self.assertEqual(port, 9050)
        self.assertTrue(rdns)


# ---------------------------------------------------------------------------
# Test 5: SOCKS5 greeting — no-auth response
# ---------------------------------------------------------------------------

class TestSocks5Greeting(unittest.IsolatedAsyncioTestCase):
    async def test_greeting_no_auth_response(self):
        """Server must respond VER=5, METHOD=0 (no auth) to a valid greeting."""
        pool = _make_pool()
        listener = Socks5Listener(pool=pool, port=0)

        # Build a mock reader that provides a valid SOCKS5 greeting
        # VER=5, NMETHODS=1, METHOD=0 (no-auth)
        greeting_bytes = bytes([5, 1, 0])
        reader = asyncio.StreamReader()
        reader.feed_data(greeting_bytes)
        # After greeting, feed a BIND command so handler exits quickly with 0x07
        bind_request = bytes([5, 2, 0, 1]) + socket.inet_aton("0.0.0.0") + struct.pack("!H", 0)
        reader.feed_data(bind_request)
        reader.feed_eof()

        written_data = bytearray()

        async def fake_drain():
            pass

        writer = MagicMock()
        writer.write = lambda data: written_data.extend(data)
        writer.drain = fake_drain
        writer.close = MagicMock()

        await listener._handle_connection(reader, writer)

        # First 2 bytes must be 0x05 0x00 (VER=5, METHOD=0 no-auth)
        self.assertGreaterEqual(len(written_data), 2)
        self.assertEqual(written_data[0], 5)   # VER
        self.assertEqual(written_data[1], 0)   # METHOD = 0 (no auth)


# ---------------------------------------------------------------------------
# Test 6: SOCKS5 CMD=2 (BIND) returns 0x07
# ---------------------------------------------------------------------------

class TestUnsupportedCommands(unittest.IsolatedAsyncioTestCase):
    async def _run_with_cmd(self, cmd_byte: int) -> bytes:
        """Helper: feed a greeting + request with given CMD, capture response."""
        pool = _make_pool()
        listener = Socks5Listener(pool=pool, port=0)

        greeting = bytes([5, 1, 0])
        request = bytes([5, cmd_byte, 0, 1]) + socket.inet_aton("127.0.0.1") + struct.pack("!H", 80)

        reader = asyncio.StreamReader()
        reader.feed_data(greeting + request)
        reader.feed_eof()

        written_data = bytearray()

        async def fake_drain():
            pass

        writer = MagicMock()
        writer.write = lambda data: written_data.extend(data)
        writer.drain = fake_drain
        writer.close = MagicMock()

        await listener._handle_connection(reader, writer)
        return bytes(written_data)

    async def test_cmd_bind_rejected_with_07(self):
        """CMD=2 (BIND) must return 0x07 (command not supported)."""
        response = await self._run_with_cmd(0x02)
        # Greeting response (2 bytes) + reply (10 bytes)
        # Reply[1] must be 0x07
        self.assertGreaterEqual(len(response), 12)
        self.assertEqual(response[3], 0x07)  # 0x05 0x07 0x00 0x01 ...

    async def test_cmd_udp_associate_rejected_with_07(self):
        """CMD=3 (UDP ASSOCIATE) must return 0x07 (command not supported)."""
        response = await self._run_with_cmd(0x03)
        self.assertGreaterEqual(len(response), 12)
        self.assertEqual(response[3], 0x07)


# ---------------------------------------------------------------------------
# Test 8: Pool returns None → general failure (0x01)
# ---------------------------------------------------------------------------

class TestPoolEmptyHandling(unittest.IsolatedAsyncioTestCase):
    async def test_empty_pool_returns_general_failure(self):
        """When get_proxy() returns None, handler must reply with 0x01."""
        pool = ProxyPool(proxies=[], auto_replenish=False)
        listener = Socks5Listener(pool=pool, port=0)

        greeting = bytes([5, 1, 0])
        request = bytes([5, 1, 0, 1]) + socket.inet_aton("8.8.8.8") + struct.pack("!H", 80)

        reader = asyncio.StreamReader()
        reader.feed_data(greeting + request)
        reader.feed_eof()

        written_data = bytearray()

        async def fake_drain():
            pass

        writer = MagicMock()
        writer.write = lambda data: written_data.extend(data)
        writer.drain = fake_drain
        writer.close = MagicMock()

        await listener._handle_connection(reader, writer)

        # The first write is greeting (2 bytes): 0x05 0x00
        # The second write is the failure reply: 0x05 0x01 ...
        self.assertGreaterEqual(len(written_data), 2)
        # Find the reply byte: after the greeting, look for 0x05 0x01
        remaining = bytes(written_data[2:])
        if len(remaining) >= 2:
            self.assertEqual(remaining[0], 0x05)
            self.assertEqual(remaining[1], 0x01)  # general failure


# ---------------------------------------------------------------------------
# Test 9: start() launches daemon thread named "socks5-listener"
# ---------------------------------------------------------------------------

class TestListenerThreadLifecycle(unittest.TestCase):
    def test_start_launches_daemon_thread(self):
        """start() must launch a daemon thread named 'socks5-listener'."""
        pool = _make_pool()
        # Use a free port
        listener = Socks5Listener(pool=pool, port=18765)
        try:
            listener.start()
            time.sleep(0.15)  # let thread start
            self.assertTrue(listener.is_alive())
            self.assertIsNotNone(listener._thread)
            self.assertEqual(listener._thread.name, "socks5-listener")
            self.assertTrue(listener._thread.daemon)
        finally:
            listener.stop()

    def test_stop_terminates_thread(self):
        """stop() must cause thread to exit."""
        pool = _make_pool()
        listener = Socks5Listener(pool=pool, port=18766)
        listener.start()
        time.sleep(0.15)
        self.assertTrue(listener.is_alive())
        listener.stop()
        # Thread should be dead within 5 seconds
        self.assertFalse(listener.is_alive())

    def test_is_alive_false_before_start(self):
        """is_alive() must return False before start() is called."""
        pool = _make_pool()
        listener = Socks5Listener(pool=pool, port=18767)
        self.assertFalse(listener.is_alive())

    def test_is_alive_true_after_start(self):
        """is_alive() must return True after start() is called."""
        pool = _make_pool()
        listener = Socks5Listener(pool=pool, port=18768)
        try:
            listener.start()
            time.sleep(0.15)
            self.assertTrue(listener.is_alive())
        finally:
            listener.stop()

    def test_is_alive_false_after_stop(self):
        """is_alive() must return False after stop() is called."""
        pool = _make_pool()
        listener = Socks5Listener(pool=pool, port=18769)
        listener.start()
        time.sleep(0.15)
        listener.stop()
        self.assertFalse(listener.is_alive())


if __name__ == "__main__":
    unittest.main()
