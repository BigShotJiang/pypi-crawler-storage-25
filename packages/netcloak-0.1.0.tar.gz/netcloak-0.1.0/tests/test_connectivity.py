"""Tests for status.checker.check_connectivity()."""
from __future__ import annotations

import socket
from unittest.mock import patch, MagicMock


def test_check_connectivity_returns_true_when_probe_succeeds():
    """check_connectivity() returns (True, 'OK') when any TCP probe connects."""
    from netcloak.status.checker import check_connectivity

    with patch("socket.create_connection") as mock_conn:
        mock_conn.return_value.__enter__ = lambda s: s
        mock_conn.return_value.__exit__ = MagicMock(return_value=False)
        ok, msg = check_connectivity()

    assert ok is True
    assert msg == "OK"


def test_check_connectivity_returns_false_when_all_probes_fail():
    """check_connectivity() returns (False, reason) when all TCP probes fail."""
    from netcloak.status.checker import check_connectivity

    with patch("socket.create_connection", side_effect=OSError("Network unreachable")):
        ok, msg = check_connectivity()

    assert ok is False
    assert msg  # non-empty reason string


def test_check_connectivity_tries_multiple_probes():
    """check_connectivity() retries remaining probes after a failure."""
    from netcloak.status import checker

    call_count = 0
    results = [OSError("timeout"), None]  # first fails, second succeeds

    def fake_connect(addr, timeout):
        nonlocal call_count
        if call_count == 0:
            call_count += 1
            raise OSError("timeout")
        call_count += 1
        m = MagicMock()
        m.__enter__ = lambda s: s
        m.__exit__ = MagicMock(return_value=False)
        return m

    with patch("socket.create_connection", side_effect=fake_connect):
        ok, msg = checker.check_connectivity()

    assert ok is True
    assert call_count == 2  # stopped after first success
