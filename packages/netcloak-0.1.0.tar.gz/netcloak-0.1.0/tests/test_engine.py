"""Tests for NetCloakEngine orchestrator. All external modules mocked."""
from __future__ import annotations

import socket
from unittest.mock import MagicMock, call, patch

import pytest

import netcloak.core.engine as engine_module
from netcloak.core.engine import NetCloakEngine


@pytest.fixture(autouse=True)
def reset_singleton():
    """Reset engine singleton between tests."""
    engine_module.NetCloakEngine._instance = None
    yield
    engine_module.NetCloakEngine._instance = None


def _mock_config():
    return {
        "tor": {
            "socks_port": 9050,
            "control_port": 9051,
            "dns_port": 9053,
            "trans_port": 9040,
            "data_dir": "/tmp/test_netcloak",
            "data_dir_windows": r"%TEMP%\test_netcloak",
            "binary_path": "",
        },
        "routing": {"kill_switch": False, "dns_lock": False, "wintun_path": ""},
        "proxy": {},
    }


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

def test_singleton_returns_same_instance():
    """instance() always returns the same NetCloakEngine object."""
    a = NetCloakEngine.instance()
    b = NetCloakEngine.instance()
    assert a is b


# ---------------------------------------------------------------------------
# start() — state captured before interceptor
# ---------------------------------------------------------------------------

def test_start_captures_state_before_interceptor_activates():
    """state.capture() must be called before interceptor.activate()."""
    call_order: list[str] = []

    mock_state = MagicMock()
    mock_state.capture.side_effect = lambda **_: call_order.append("capture")
    mock_interceptor = MagicMock()
    mock_interceptor.activate.side_effect = lambda: call_order.append("activate")

    mock_tor = MagicMock()
    mock_tor.start.return_value = True
    mock_tor.is_running.return_value = True
    mock_ctrl = MagicMock()
    mock_ctrl.monitor_bootstrap.return_value = 100

    engine = NetCloakEngine.instance()
    with patch("netcloak.core.engine.NetCloakEngine._make_interceptor", return_value=mock_interceptor), \
         patch("netcloak.core.engine.NetworkState", return_value=mock_state), \
         patch("netcloak.core.engine.require_admin_or_exit"), \
         patch("netcloak.core.engine.load_config", return_value=_mock_config()), \
         patch("netcloak.core.engine.TorManager", return_value=mock_tor), \
         patch("netcloak.core.engine.TorController", return_value=mock_ctrl), \
         patch("netcloak.core.engine.HealthMonitor"), \
         patch("netcloak.core.engine.TrafficPadder"), \
         patch("threading.Thread"):
        engine.start(mode="tor")

    assert call_order.index("capture") < call_order.index("activate")


# ---------------------------------------------------------------------------
# start() — Tor mode
# ---------------------------------------------------------------------------

def test_start_tor_calls_tor_manager_and_controller():
    """start('tor') starts TorManager and connects TorController."""
    mock_tor = MagicMock()
    mock_tor.start.return_value = True
    mock_tor.is_running.return_value = True
    mock_ctrl = MagicMock()
    mock_ctrl.monitor_bootstrap.return_value = 100

    with patch("netcloak.utils.platform.check_privileges", return_value=True), \
         patch("netcloak.core.engine.load_config", return_value=_mock_config()), \
         patch("netcloak.core.engine.NetworkState"), \
         patch("netcloak.core.engine.NetCloakEngine._make_interceptor", return_value=MagicMock()), \
         patch("netcloak.core.engine.TorManager", return_value=mock_tor), \
         patch("netcloak.core.engine.TorController", return_value=mock_ctrl), \
         patch("netcloak.core.engine.HealthMonitor"), \
         patch("netcloak.core.engine.TrafficPadder"), \
         patch("threading.Thread"):
        engine = NetCloakEngine.instance()
        engine.start(mode="tor")

    mock_tor.start.assert_called_once()
    mock_ctrl.connect.assert_called_once()
    mock_ctrl.monitor_bootstrap.assert_called_once()


# ---------------------------------------------------------------------------
# start() — proxy fallback on TorBootstrapTimeout
# ---------------------------------------------------------------------------

def test_start_falls_back_to_proxy_on_bootstrap_timeout():
    """start('tor') falls back to proxy mode when TorBootstrapTimeout is raised."""
    from netcloak.tor.controller import TorBootstrapTimeout

    mock_tor = MagicMock()
    mock_tor.start.return_value = True
    mock_ctrl = MagicMock()
    mock_ctrl.monitor_bootstrap.side_effect = TorBootstrapTimeout("timeout")
    mock_pool = MagicMock()
    mock_proxy = MagicMock()
    mock_proxy.url = "socks5h://1.2.3.4:1080"

    with patch("netcloak.utils.platform.check_privileges", return_value=True), \
         patch("netcloak.core.engine.load_config", return_value=_mock_config()), \
         patch("netcloak.core.engine.NetworkState"), \
         patch("netcloak.core.engine.NetCloakEngine._make_interceptor", return_value=MagicMock()), \
         patch("netcloak.core.engine.TorManager", return_value=mock_tor), \
         patch("netcloak.core.engine.TorController", return_value=mock_ctrl), \
         patch("netcloak.core.engine.scrape_proxies_cached", return_value=["socks5h://1.2.3.4:1080"]), \
         patch("netcloak.core.engine.validate_proxies", return_value=[mock_proxy]), \
         patch("netcloak.core.engine.ProxyPool", return_value=mock_pool), \
         patch("netcloak.core.engine.HealthMonitor"), \
         patch("netcloak.core.engine.TrafficPadder"), \
         patch("threading.Thread"):
        engine = NetCloakEngine.instance()
        engine.start(mode="tor")

    assert engine._mode == "proxy"


# ---------------------------------------------------------------------------
# start() — proxy mode direct
# ---------------------------------------------------------------------------

def test_start_proxy_skips_tor():
    """start('proxy') skips Tor entirely."""
    mock_pool = MagicMock()
    mock_proxy = MagicMock()
    mock_proxy.url = "socks5h://1.2.3.4:1080"

    with patch("netcloak.utils.platform.check_privileges", return_value=True), \
         patch("netcloak.core.engine.load_config", return_value=_mock_config()), \
         patch("netcloak.core.engine.NetworkState"), \
         patch("netcloak.core.engine.NetCloakEngine._make_interceptor", return_value=MagicMock()), \
         patch("netcloak.core.engine.TorManager") as MockTor, \
         patch("netcloak.core.engine.scrape_proxies_cached", return_value=["socks5h://1.2.3.4:1080"]), \
         patch("netcloak.core.engine.validate_proxies", return_value=[mock_proxy]), \
         patch("netcloak.core.engine.ProxyPool", return_value=mock_pool), \
         patch("netcloak.core.engine.HealthMonitor"), \
         patch("netcloak.core.engine.TrafficPadder"), \
         patch("threading.Thread"):
        engine = NetCloakEngine.instance()
        engine.start(mode="proxy")

    MockTor.assert_not_called()
    assert engine._mode == "proxy"


# ---------------------------------------------------------------------------
# stop() — correct order: state.restore BEFORE interceptor.deactivate
# ---------------------------------------------------------------------------

def test_stop_restores_state_before_deactivating_interceptor():
    """stop() calls state.restore() before interceptor.deactivate()."""
    call_order: list[str] = []

    mock_state = MagicMock()
    mock_state.restore.side_effect = lambda: call_order.append("restore")
    mock_state.delete = MagicMock()
    mock_interceptor = MagicMock()
    mock_interceptor.deactivate.side_effect = lambda: call_order.append("deactivate")

    engine = NetCloakEngine.instance()
    engine._state = mock_state
    engine._interceptor = mock_interceptor
    engine._running = True

    engine.stop()

    assert call_order.index("restore") < call_order.index("deactivate")


# ---------------------------------------------------------------------------
# stop() — resilience (Test 11)
# ---------------------------------------------------------------------------

def test_stop_restores_and_deletes_state_even_if_deactivate_raises():
    """state.restore() and state.delete() called even if interceptor.deactivate() raises."""
    mock_state = MagicMock()
    mock_interceptor = MagicMock()
    mock_interceptor.deactivate.side_effect = RuntimeError("deactivate failed")

    engine = NetCloakEngine.instance()
    engine._state = mock_state
    engine._interceptor = mock_interceptor
    engine._running = True

    engine.stop()  # must not raise

    mock_state.restore.assert_called_once()
    mock_state.delete.assert_called_once()


# ---------------------------------------------------------------------------
# stop() — deactivate called even if Tor stop fails
# ---------------------------------------------------------------------------

def test_stop_deactivates_even_if_tor_stop_fails():
    """stop() deactivates interceptor even if Tor stop raises."""
    mock_tor = MagicMock()
    mock_tor.stop.side_effect = RuntimeError("tor crash")
    mock_interceptor = MagicMock()
    mock_state = MagicMock()

    engine = NetCloakEngine.instance()
    engine._tor = mock_tor
    engine._interceptor = mock_interceptor
    engine._state = mock_state
    engine._running = True

    engine.stop()

    mock_interceptor.deactivate.assert_called_once()
    mock_state.restore.assert_called_once()


# ---------------------------------------------------------------------------
# Watchdog thread starts
# ---------------------------------------------------------------------------

def test_watchdog_thread_starts_after_start():
    """A watchdog daemon thread is started after start()."""
    mock_thread = MagicMock()

    with patch("netcloak.utils.platform.check_privileges", return_value=True), \
         patch("netcloak.core.engine.load_config", return_value=_mock_config()), \
         patch("netcloak.core.engine.NetworkState"), \
         patch("netcloak.core.engine.NetCloakEngine._make_interceptor", return_value=MagicMock()), \
         patch("netcloak.core.engine.NetCloakEngine._start_tor", return_value="tor"), \
         patch("netcloak.core.engine.HealthMonitor"), \
         patch("netcloak.core.engine.TrafficPadder"), \
         patch("netcloak.core.engine.threading") as mock_threading:
        mock_threading.Thread.return_value = mock_thread
        mock_threading.Event.return_value = MagicMock()
        engine = NetCloakEngine.instance()
        # Re-init to pick up mock threading
        engine._watchdog_stop = mock_threading.Event.return_value
        engine.start(mode="tor")

    mock_thread.start.assert_called()


# ---------------------------------------------------------------------------
# auto mode == tor with fallback
# ---------------------------------------------------------------------------

def test_auto_mode_behaves_same_as_tor():
    """start('auto') routes through the same Tor path as 'tor'."""
    mock_tor = MagicMock()
    mock_tor.start.return_value = True
    mock_ctrl = MagicMock()
    mock_ctrl.monitor_bootstrap.return_value = 100

    with patch("netcloak.utils.platform.check_privileges", return_value=True), \
         patch("netcloak.core.engine.load_config", return_value=_mock_config()), \
         patch("netcloak.core.engine.NetworkState"), \
         patch("netcloak.core.engine.NetCloakEngine._make_interceptor", return_value=MagicMock()), \
         patch("netcloak.core.engine.TorManager", return_value=mock_tor), \
         patch("netcloak.core.engine.TorController", return_value=mock_ctrl), \
         patch("netcloak.core.engine.HealthMonitor"), \
         patch("netcloak.core.engine.TrafficPadder"), \
         patch("threading.Thread"):
        engine = NetCloakEngine.instance()
        engine.start(mode="auto")

    mock_tor.start.assert_called_once()
    assert engine._mode == "tor"


# ---------------------------------------------------------------------------
# proxychains.conf generation — _start_proxy() Linux guard
# ---------------------------------------------------------------------------

def _proxy_chain_config():
    cfg = _mock_config()
    cfg["proxy"]["local_port"] = 8080
    cfg["proxy"]["chain_length"] = 2
    cfg["proxy"]["chain_type"] = "dynamic"
    return cfg


def test_start_proxy_writes_proxychains_conf_on_linux():
    """On Linux, _start_proxy() calls generate_proxychains_conf with correct args."""
    mock_pool = MagicMock()
    mock_proxy = MagicMock()
    mock_proxy.url = "socks5://1.2.3.4:1080"

    with patch("netcloak.utils.platform.check_privileges", return_value=True), \
         patch("netcloak.core.engine.load_config", return_value=_proxy_chain_config()), \
         patch("netcloak.core.engine.NetworkState"), \
         patch("netcloak.core.engine.NetCloakEngine._make_interceptor", return_value=MagicMock()), \
         patch("netcloak.core.engine.scrape_proxies_cached", return_value=["socks5://1.2.3.4:1080"]), \
         patch("netcloak.core.engine.validate_proxies", return_value=[mock_proxy]), \
         patch("netcloak.core.engine.ProxyPool", return_value=mock_pool), \
         patch("netcloak.core.engine.HealthMonitor"), \
         patch("netcloak.core.engine.TrafficPadder"), \
         patch("threading.Thread"), \
         patch("sys.platform", "linux"), \
         patch("netcloak.proxy.proxychains.generate_proxychains_conf") as mock_gen:
        engine = NetCloakEngine.instance()
        engine.start(mode="proxy")

    mock_gen.assert_called_once()
    call_kwargs = mock_gen.call_args
    assert call_kwargs.kwargs["chain_type"] == "dynamic"
    assert call_kwargs.kwargs["chain_length"] == 2
    assert call_kwargs.kwargs["output_path"].endswith("proxychains.conf")


def test_start_proxy_skips_proxychains_conf_on_windows():
    """On Windows, _start_proxy() does NOT call generate_proxychains_conf."""
    mock_pool = MagicMock()
    mock_proxy = MagicMock()
    mock_proxy.url = "socks5://1.2.3.4:1080"

    with patch("netcloak.utils.platform.check_privileges", return_value=True), \
         patch("netcloak.core.engine.load_config", return_value=_proxy_chain_config()), \
         patch("netcloak.core.engine.NetworkState"), \
         patch("netcloak.core.engine.NetCloakEngine._make_interceptor", return_value=MagicMock()), \
         patch("netcloak.core.engine.scrape_proxies_cached", return_value=["socks5://1.2.3.4:1080"]), \
         patch("netcloak.core.engine.validate_proxies", return_value=[mock_proxy]), \
         patch("netcloak.core.engine.ProxyPool", return_value=mock_pool), \
         patch("netcloak.core.engine.HealthMonitor"), \
         patch("netcloak.core.engine.TrafficPadder"), \
         patch("threading.Thread"), \
         patch("sys.platform", "win32"), \
         patch("netcloak.proxy.proxychains.generate_proxychains_conf") as mock_gen:
        engine = NetCloakEngine.instance()
        engine.start(mode="proxy")

    mock_gen.assert_not_called()


def test_start_proxy_uses_chain_config_values():
    """_start_proxy() passes chain_type and chain_length from cfg to generate_proxychains_conf."""
    mock_pool = MagicMock()
    mock_proxy = MagicMock()
    mock_proxy.url = "socks5://5.6.7.8:3128"
    cfg = _proxy_chain_config()
    cfg["proxy"]["chain_type"] = "strict"
    cfg["proxy"]["chain_length"] = 3

    with patch("netcloak.utils.platform.check_privileges", return_value=True), \
         patch("netcloak.core.engine.load_config", return_value=cfg), \
         patch("netcloak.core.engine.NetworkState"), \
         patch("netcloak.core.engine.NetCloakEngine._make_interceptor", return_value=MagicMock()), \
         patch("netcloak.core.engine.scrape_proxies_cached", return_value=["socks5://5.6.7.8:3128"]), \
         patch("netcloak.core.engine.validate_proxies", return_value=[mock_proxy]), \
         patch("netcloak.core.engine.ProxyPool", return_value=mock_pool), \
         patch("netcloak.core.engine.HealthMonitor"), \
         patch("netcloak.core.engine.TrafficPadder"), \
         patch("threading.Thread"), \
         patch("sys.platform", "linux"), \
         patch("netcloak.proxy.proxychains.generate_proxychains_conf") as mock_gen:
        engine = NetCloakEngine.instance()
        engine.start(mode="proxy")

    mock_gen.assert_called_once()
    assert mock_gen.call_args.kwargs["chain_type"] == "strict"
    assert mock_gen.call_args.kwargs["chain_length"] == 3
