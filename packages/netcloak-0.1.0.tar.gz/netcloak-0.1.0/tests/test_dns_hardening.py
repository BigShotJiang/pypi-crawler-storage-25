"""Tests for verify_dns_through_tor() DNS-leak hardening check."""
from __future__ import annotations

import socket
import threading
from unittest.mock import MagicMock, patch


def _find_free_udp_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class TestVerifyDnsThroughTor:
    """verify_dns_through_tor() returns (True, 'OK') when DNSPort responds."""

    def test_returns_true_when_dns_port_responds(self):
        """Real UDP test: a mock DNS server replies and verify returns True."""
        from netcloak.status.checker import verify_dns_through_tor

        port = _find_free_udp_port()

        # Minimal valid DNS response: same ID (0x1234), QR=1 in flags
        dns_response = (
            b'\x12\x34'  # Same transaction ID
            b'\x81\x80'  # Flags: QR=1, RA=1 (standard response)
            b'\x00\x01'  # QDCOUNT=1
            b'\x00\x01'  # ANCOUNT=1
            b'\x00\x00'  # NSCOUNT=0
            b'\x00\x00'  # ARCOUNT=0
        )

        server_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        server_sock.bind(("127.0.0.1", port))
        server_sock.settimeout(3.0)

        def mock_dns_server():
            try:
                data, addr = server_sock.recvfrom(4096)
                server_sock.sendto(dns_response, addr)
            except Exception:
                pass

        t = threading.Thread(target=mock_dns_server, daemon=True)
        t.start()

        ok, reason = verify_dns_through_tor(dns_port=port, timeout=3.0)

        t.join(timeout=4)
        server_sock.close()

        assert ok is True
        assert reason == "OK"

    def test_returns_false_on_timeout(self):
        """verify_dns_through_tor returns (False, reason) when no DNS server responds."""
        from netcloak.status.checker import verify_dns_through_tor

        port = _find_free_udp_port()
        # Nothing listening on that port — query will time out
        ok, reason = verify_dns_through_tor(dns_port=port, timeout=0.3)

        assert ok is False
        assert "did not respond" in reason or "127.0.0.1" in reason

    def test_returns_false_on_wrong_transaction_id(self):
        """verify_dns_through_tor returns False if response has wrong transaction ID."""
        from netcloak.status.checker import verify_dns_through_tor

        port = _find_free_udp_port()

        # Response with wrong transaction ID
        bad_response = b'\xff\xff\x81\x80\x00\x01\x00\x01\x00\x00\x00\x00'

        server_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        server_sock.bind(("127.0.0.1", port))
        server_sock.settimeout(3.0)

        def mock_bad_server():
            try:
                _, addr = server_sock.recvfrom(4096)
                server_sock.sendto(bad_response, addr)
            except Exception:
                pass

        t = threading.Thread(target=mock_bad_server, daemon=True)
        t.start()

        ok, reason = verify_dns_through_tor(dns_port=port, timeout=3.0)

        t.join(timeout=4)
        server_sock.close()

        assert ok is False

    def test_socket_is_always_closed(self):
        """verify_dns_through_tor does not leak the UDP socket on success or failure."""
        from netcloak.status.checker import verify_dns_through_tor

        # Run against a port that doesn't respond (quick timeout)
        port = _find_free_udp_port()
        verify_dns_through_tor(dns_port=port, timeout=0.1)
        # If socket leaked, binding to the same port would fail on some systems.
        # This test just checks no exception is raised in the cleanup path.
