"""Tests for TorController — stem mocked, no real Tor required."""
from __future__ import annotations

import time
from unittest.mock import MagicMock, patch

import pytest

from netcloak.tor.controller import TorBootstrapTimeout, TorController


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_controller(bootstrap_pct: int = 80) -> MagicMock:
    ctrl = MagicMock()
    ctrl.get_info.return_value = f"PROGRESS={bootstrap_pct} TAG=done SUMMARY=done"
    return ctrl


# ---------------------------------------------------------------------------
# connect / disconnect
# ---------------------------------------------------------------------------

def test_connect_authenticates():
    """connect() calls Controller.from_port and authenticate()."""
    ctrl_mock = MagicMock()
    with patch("netcloak.tor.controller.Controller") as MockCtrl:
        MockCtrl.from_port.return_value = ctrl_mock
        tc = TorController(control_port=9051)
        tc.connect()
        MockCtrl.from_port.assert_called_once_with(port=9051)
        ctrl_mock.authenticate.assert_called_once()


def test_disconnect_closes_controller():
    """disconnect() calls close() on the underlying controller."""
    ctrl_mock = MagicMock()
    with patch("netcloak.tor.controller.Controller") as MockCtrl:
        MockCtrl.from_port.return_value = ctrl_mock
        tc = TorController()
        tc.connect()
        tc.disconnect()
        ctrl_mock.close.assert_called_once()
        assert tc._controller is None


def test_disconnect_noop_when_not_connected():
    """disconnect() is safe to call when not connected."""
    tc = TorController()
    tc.disconnect()  # Should not raise


# ---------------------------------------------------------------------------
# monitor_bootstrap
# ---------------------------------------------------------------------------

def test_monitor_bootstrap_returns_progress_above_threshold():
    """Returns percentage when Tor is already bootstrapped above 15%."""
    ctrl_mock = _make_controller(bootstrap_pct=100)
    with patch("netcloak.tor.controller.Controller") as MockCtrl:
        MockCtrl.from_port.return_value = ctrl_mock
        tc = TorController()
        tc.connect()
        result = tc.monitor_bootstrap(timeout=5.0)
        assert result >= 15


def test_monitor_bootstrap_raises_on_timeout():
    """Raises TorBootstrapTimeout when progress stays below 15%."""
    ctrl_mock = _make_controller(bootstrap_pct=5)
    with patch("netcloak.tor.controller.Controller") as MockCtrl:
        MockCtrl.from_port.return_value = ctrl_mock
        with patch("netcloak.tor.controller.time") as mock_time:
            # Simulate time advancing past the deadline immediately
            start = 1000.0
            mock_time.monotonic.side_effect = [start, start + 61.0, start + 62.0]
            mock_time.sleep = MagicMock()
            tc = TorController()
            tc._controller = ctrl_mock
            with pytest.raises(TorBootstrapTimeout):
                tc.monitor_bootstrap(timeout=60.0)


def test_monitor_bootstrap_raises_if_not_connected():
    """Raises RuntimeError when called before connect()."""
    tc = TorController()
    with pytest.raises(RuntimeError, match="Not connected"):
        tc.monitor_bootstrap(timeout=1.0)


# ---------------------------------------------------------------------------
# new_identity
# ---------------------------------------------------------------------------

def test_new_identity_sends_newnym():
    """new_identity() signals NEWNYM to the controller."""
    ctrl_mock = MagicMock()
    with patch("netcloak.tor.controller.Controller") as MockCtrl, \
         patch("netcloak.tor.controller.Signal") as MockSignal:
        MockCtrl.from_port.return_value = ctrl_mock
        tc = TorController()
        tc.connect()
        tc.new_identity()
        ctrl_mock.signal.assert_called_once_with(MockSignal.NEWNYM)


def test_new_identity_raises_if_not_connected():
    """Raises RuntimeError when called before connect()."""
    tc = TorController()
    with pytest.raises(RuntimeError, match="Not connected"):
        tc.new_identity()


# ---------------------------------------------------------------------------
# get_exit_ip / is_tor
# ---------------------------------------------------------------------------

def test_get_exit_ip_returns_ip_string():
    """get_exit_ip() returns IP string from check.torproject.org."""
    mock_resp = MagicMock()
    mock_resp.json.return_value = {"IP": "185.220.101.1", "IsTor": True}
    mock_resp.raise_for_status = MagicMock()
    with patch("netcloak.tor.controller.requests.get", return_value=mock_resp):
        tc = TorController()
        result = tc.get_exit_ip(socks_port=9050)
        assert result == "185.220.101.1"


def test_get_exit_ip_returns_none_on_failure():
    """get_exit_ip() returns None on network error."""
    with patch("netcloak.tor.controller.requests.get", side_effect=Exception("timeout")):
        tc = TorController()
        result = tc.get_exit_ip()
        assert result is None


def test_is_tor_returns_true_when_using_tor():
    """is_tor() returns True when IsTor field is True."""
    mock_resp = MagicMock()
    mock_resp.json.return_value = {"IP": "185.220.101.1", "IsTor": True}
    mock_resp.raise_for_status = MagicMock()
    with patch("netcloak.tor.controller.requests.get", return_value=mock_resp):
        tc = TorController()
        assert tc.is_tor() is True


def test_is_tor_returns_false_on_failure():
    """is_tor() returns False on network error."""
    with patch("netcloak.tor.controller.requests.get", side_effect=Exception("timeout")):
        tc = TorController()
        assert tc.is_tor() is False


# ---------------------------------------------------------------------------
# Module-level imports
# ---------------------------------------------------------------------------

def test_torbstraptimeout_is_importable():
    """TorBootstrapTimeout is a proper Exception subclass."""
    assert issubclass(TorBootstrapTimeout, Exception)
