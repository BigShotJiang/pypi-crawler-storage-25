"""Project package root (template)."""
