# Istari Digital Client

The `istari-digital-client` library is a client SDK for interacting with the [Istari Digital platform](https://www.istaridigital.com).

- **Install:** `pip install istari-digital-client`
- **Documentation and Usage:** Please see [docs.istaridigital.com](https://docs.istaridigital.com).
- **Supported Versions:** This library supports Python 3.10, 3.11, 3.12, and 3.14
- **License:** This library is released under an MIT license with the following clarification:

> No license is hereby implied or granted to any patent or patent application relating to the Istari Digital platform itself. The list of patents applicable to the Istari Digital platform may be found at istaridigital.com/patent-list.

## Direct S3 Upload

For environments with direct access to the backing S3 bucket, the client can bypass presigned URLs and upload via `boto3` instead. This can improve throughput and simplifies large-file handling (boto3 manages multipart automatically).

Install the optional dependency:

```bash
# S3-compatible storage (minio, AWS, etc.)
pip install istari-digital-client[s3]

# AWS with high-speed CRT transfers (recommended for EC2 containers in same s3 environment as the data plane buckets)
pip install istari-digital-client[s3-crt]
```

Then configure via environment variables or constructor arguments:

| Environment Variable | Constructor Arg | Description |
|---|---|---|
| `ISTARI_CLIENT_S3_DIRECT_UPLOAD` | `s3_direct_upload_enabled` | Set to `true` to enable direct S3 uploads |
| `ISTARI_CLIENT_S3_BUCKET_NAME` | `s3_bucket_name` | Target S3 bucket name (required when enabled) |

Standard AWS credentials (environment variables, profile, or instance role) must be available for `boto3` to authenticate.

## Contributing

See the [contributing doc](./CONTRIBUTING.md) for additional info.
