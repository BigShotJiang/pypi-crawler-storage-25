"""
Tests for environment safety validation (Safety Invariants).

These tests verify that validate_environment() catches production credentials
in non-production environments and refuses to start. This is the "last line
of defense" described in plan.md Section 301.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from spaps_server_quickstart.spaps_settings import SpapsSettings
from spaps_server_quickstart.startup import EnvironmentSafetyError, validate_environment


def _make_settings(**overrides) -> SpapsSettings:
    """Create SpapsSettings with test defaults + overrides."""
    defaults = {
        "env": "development",
        "database_url": "postgresql+asyncpg://postgres:postgres@localhost:5434/spaps_test",
        "spaps_local_mode": True,
        "cors_allow_origins": ("https://app.example.com",),
    }
    defaults.update(overrides)
    return SpapsSettings(**defaults)


# =============================================================================
# Production mode — should pass all checks
# =============================================================================


class TestProductionMode:
    def test_production_with_live_keys_passes(self) -> None:
        """Production environment is allowed to have production credentials."""
        settings = _make_settings(
            env="production",
            spaps_local_mode=False,
            mailgun_api_key="key-abc123",
            stripe_secret_key="sk_live_abc123",
            solana_rpc_url="https://api.mainnet-beta.solana.com",
            quickbooks_client_id="prod-client-id",
            quickbooks_client_secret="prod-client-secret",
            cfo_public_key="-----BEGIN PUBLIC KEY-----test-----END PUBLIC KEY-----",
            legacy_api_key_auth_enabled=False,
            webhook_destination_policy_mode="allowlist",
            webhook_allowed_domains=["hooks.example.com"],
            self_service_allowed_ips=["10.0.0.0/8"],
        )
        # Should not raise
        validate_environment(settings)

    def test_production_with_local_mode_refuses(self) -> None:
        """SPAPS_LOCAL_MODE=true in production is always an error."""
        settings = SpapsSettings(
            env="production",
            database_url="postgresql+asyncpg://postgres:pass@db:5432/spaps",
            spaps_local_mode=True,
        )
        with pytest.raises(EnvironmentSafetyError, match="SPAPS_LOCAL_MODE"):
            validate_environment(settings)

    def test_production_rejects_legacy_api_key_auth(self) -> None:
        """Legacy plaintext API key auth must be disabled in production."""
        settings = _make_settings(
            env="production",
            spaps_local_mode=False,
            legacy_api_key_auth_enabled=True,
            webhook_destination_policy_mode="allowlist",
            webhook_allowed_domains=["hooks.example.com"],
            self_service_allowed_ips=["10.0.0.0/8"],
        )
        with pytest.raises(EnvironmentSafetyError, match="LEGACY_API_KEY_AUTH_ENABLED"):
            validate_environment(settings)

    def test_production_requires_webhook_allowlist_mode(self) -> None:
        """Production must enforce webhook destination allowlist policy."""
        settings = _make_settings(
            env="production",
            spaps_local_mode=False,
            legacy_api_key_auth_enabled=False,
            webhook_destination_policy_mode="off",
            webhook_allowed_domains=["hooks.example.com"],
            self_service_allowed_ips=["10.0.0.0/8"],
        )
        with pytest.raises(EnvironmentSafetyError, match="WEBHOOK_DESTINATION_POLICY_MODE"):
            validate_environment(settings)

    def test_production_requires_non_empty_webhook_allowed_domains(self) -> None:
        """Allowlist mode without domains is invalid in production."""
        settings = _make_settings(
            env="production",
            spaps_local_mode=False,
            legacy_api_key_auth_enabled=False,
            webhook_destination_policy_mode="allowlist",
            webhook_allowed_domains=[],
            self_service_allowed_ips=["10.0.0.0/8"],
        )
        with pytest.raises(EnvironmentSafetyError, match="WEBHOOK_ALLOWED_DOMAINS"):
            validate_environment(settings)

    def test_production_requires_self_service_allowlist(self) -> None:
        """Production must define self-service allowed IP/CIDR entries."""
        settings = _make_settings(
            env="production",
            spaps_local_mode=False,
            legacy_api_key_auth_enabled=False,
            webhook_destination_policy_mode="allowlist",
            webhook_allowed_domains=["hooks.example.com"],
            self_service_allowed_ips=[],
        )
        with pytest.raises(EnvironmentSafetyError, match="SELF_SERVICE_ALLOWED_IPS"):
            validate_environment(settings)

    def test_production_rejects_shared_self_service_password(self) -> None:
        """Production should not run shared-password self-service auth."""
        settings = _make_settings(
            env="production",
            spaps_local_mode=False,
            legacy_api_key_auth_enabled=False,
            webhook_destination_policy_mode="allowlist",
            webhook_allowed_domains=["hooks.example.com"],
            self_service_allowed_ips=["10.0.0.0/8"],
            self_service_password="shared-password",
        )
        with pytest.raises(EnvironmentSafetyError, match="SELF_SERVICE_PASSWORD"):
            validate_environment(settings)

    def test_production_rejects_invalid_self_service_allowlist_entry(self) -> None:
        """Production allowlist entries must be valid IP/CIDR values."""
        settings = _make_settings(
            env="production",
            spaps_local_mode=False,
            legacy_api_key_auth_enabled=False,
            webhook_destination_policy_mode="allowlist",
            webhook_allowed_domains=["hooks.example.com"],
            self_service_allowed_ips=["10.0.0.0/8", "not-an-ip"],
        )
        with pytest.raises(EnvironmentSafetyError, match="invalid IP/CIDR"):
            validate_environment(settings)

    def test_production_rejects_invalid_trusted_proxy_cidr(self) -> None:
        """Trusted proxy CIDR entries must be valid IP/CIDR values."""
        settings = _make_settings(
            env="production",
            spaps_local_mode=False,
            legacy_api_key_auth_enabled=False,
            webhook_destination_policy_mode="allowlist",
            webhook_allowed_domains=["hooks.example.com"],
            self_service_allowed_ips=["10.0.0.0/8"],
            trusted_proxy_cidrs=["not-a-cidr"],
        )
        with pytest.raises(EnvironmentSafetyError, match="TRUSTED_PROXY_CIDRS"):
            validate_environment(settings)

    def test_prod_alias_enforces_production_invariants(self) -> None:
        """env=prod should run the same production safety checks."""
        settings = _make_settings(
            env="prod",
            spaps_local_mode=False,
            legacy_api_key_auth_enabled=False,
            webhook_destination_policy_mode="off",
            webhook_allowed_domains=["hooks.example.com"],
            self_service_allowed_ips=["10.0.0.0/8"],
        )
        with pytest.raises(EnvironmentSafetyError, match="WEBHOOK_DESTINATION_POLICY_MODE"):
            validate_environment(settings)


# =============================================================================
# Invariant 1: No real emails in dev
# =============================================================================


class TestMailgunSafety:
    def test_mailgun_key_in_dev_refuses(self) -> None:
        """MAILGUN_API_KEY set in non-production must refuse to start."""
        settings = _make_settings(mailgun_api_key="key-abc123")
        with pytest.raises(EnvironmentSafetyError, match="MAILGUN_API_KEY"):
            validate_environment(settings)

    def test_empty_mailgun_key_passes(self) -> None:
        """Empty MAILGUN_API_KEY in non-production is fine."""
        settings = _make_settings(mailgun_api_key="")
        validate_environment(settings)

    def test_mailgun_key_in_dev_can_be_forced_with_warning(self) -> None:
        """SPAPS_FORCE_EMAIL_DELIVERY=true allows key but logs explicit warning."""
        settings = _make_settings(mailgun_api_key="key-abc123")
        with (
            patch.dict("os.environ", {"SPAPS_FORCE_EMAIL_DELIVERY": "true"}),
            patch("spaps_server_quickstart.startup.logger") as mock_logger,
        ):
            validate_environment(settings)
            warning_calls = [
                c for c in mock_logger.warning.call_args_list
                if "mailgun_api_key_allowed_by_force_flag" in c.args
            ]
            assert len(warning_calls) == 1


# =============================================================================
# Invariant 2: No real Stripe charges in dev
# =============================================================================


class TestStripeSafety:
    def test_live_stripe_key_in_dev_refuses(self) -> None:
        """sk_live_* key in non-production must refuse to start."""
        settings = _make_settings(stripe_secret_key="sk_live_abc123def456")
        with pytest.raises(EnvironmentSafetyError, match="STRIPE_SECRET_KEY.*live key"):
            validate_environment(settings)

    def test_test_stripe_key_passes(self) -> None:
        """sk_test_* key in non-production is fine."""
        settings = _make_settings(stripe_secret_key="sk_test_abc123def456")
        validate_environment(settings)

    def test_empty_stripe_key_passes(self) -> None:
        """Empty Stripe key is fine (not all devs need Stripe)."""
        settings = _make_settings(stripe_secret_key="")
        validate_environment(settings)


# =============================================================================
# Invariant 4: No real QuickBooks calls in dev
# =============================================================================


class TestQuickBooksSafety:
    def test_both_qb_credentials_in_dev_refuses(self) -> None:
        """Both QB client ID and secret set in non-production must refuse."""
        settings = _make_settings(
            quickbooks_client_id="prod-client-id",
            quickbooks_client_secret="prod-client-secret",
        )
        with pytest.raises(EnvironmentSafetyError, match="QUICKBOOKS"):
            validate_environment(settings)

    def test_both_qb_credentials_in_dev_pass_with_force_flag(self) -> None:
        """QB credentials are allowed with explicit non-prod override."""
        settings = _make_settings(
            quickbooks_client_id="sandbox-client-id",
            quickbooks_client_secret="sandbox-client-secret",
        )
        with patch.dict(
            "os.environ",
            {"SPAPS_ALLOW_QUICKBOOKS_IN_NON_PRODUCTION": "true"},
        ):
            validate_environment(settings)

    def test_only_client_id_passes(self) -> None:
        """Only client ID without secret is not a complete config — allow."""
        settings = _make_settings(
            quickbooks_client_id="some-id",
            quickbooks_client_secret="",
        )
        validate_environment(settings)

    def test_empty_qb_passes(self) -> None:
        """No QB config is fine."""
        settings = _make_settings(
            quickbooks_client_id="",
            quickbooks_client_secret="",
        )
        validate_environment(settings)


# =============================================================================
# Invariant 5: No real blockchain interactions in dev
# =============================================================================


class TestBlockchainSafety:
    def test_solana_mainnet_in_dev_refuses(self) -> None:
        """Solana mainnet RPC in non-production must refuse."""
        settings = _make_settings(solana_rpc_url="https://api.mainnet-beta.solana.com")
        with pytest.raises(EnvironmentSafetyError, match="SOLANA_RPC_URL.*mainnet"):
            validate_environment(settings)

    def test_solana_devnet_passes(self) -> None:
        """Solana devnet is fine."""
        settings = _make_settings(solana_rpc_url="https://api.devnet.solana.com")
        validate_environment(settings)

    def test_ethereum_mainnet_in_dev_refuses(self) -> None:
        """Ethereum mainnet RPC in non-production must refuse."""
        settings = _make_settings(
            ethereum_rpc_url="https://eth-mainnet.alchemyapi.io/v2/demo"
        )
        with pytest.raises(EnvironmentSafetyError, match="ETHEREUM_RPC_URL.*mainnet"):
            validate_environment(settings)

    def test_ethereum_testnet_passes(self) -> None:
        """Ethereum testnet is fine."""
        settings = _make_settings(
            ethereum_rpc_url="https://eth-sepolia.g.alchemy.com/v2/demo"
        )
        validate_environment(settings)

    def test_empty_rpc_urls_pass(self) -> None:
        """Empty RPC URLs are fine (not all devs need blockchain)."""
        settings = _make_settings(solana_rpc_url="", ethereum_rpc_url="")
        validate_environment(settings)

    def test_lightning_non_localhost_in_dev_refuses(self) -> None:
        """Non-localhost Lightning gRPC host in non-production must refuse."""
        settings = _make_settings(lightning_grpc_host="lightning.prod.example.com")
        with pytest.raises(EnvironmentSafetyError, match="LIGHTNING_GRPC_HOST"):
            validate_environment(settings)

    def test_lightning_localhost_passes(self) -> None:
        """localhost Lightning host is fine for dev."""
        settings = _make_settings(lightning_grpc_host="localhost")
        validate_environment(settings)


# =============================================================================
# Invariant 6: PII key isolation (warning, not fatal)
# =============================================================================


class TestPiiKeySafety:
    def test_pii_key_with_0000_host_warns(self) -> None:
        """SPAPS_PII_MASTER_KEY set + binding to 0.0.0.0 should log a warning."""
        settings = _make_settings(
            spaps_pii_master_key="my-dev-pii-key-1234567890",
            host="0.0.0.0",
        )
        with patch("spaps_server_quickstart.startup.logger") as mock_logger:
            # Should NOT raise (warning only)
            validate_environment(settings)
            warning_calls = [
                c for c in mock_logger.warning.call_args_list
                if "pii_key_network_exposure_risk" in c.args
            ]
            assert len(warning_calls) == 1

    def test_pii_key_with_localhost_no_warning(self) -> None:
        """SPAPS_PII_MASTER_KEY set + binding to 127.0.0.1 should not warn."""
        settings = _make_settings(
            spaps_pii_master_key="my-dev-pii-key-1234567890",
            host="127.0.0.1",
        )
        with patch("spaps_server_quickstart.startup.logger") as mock_logger:
            validate_environment(settings)
            warning_calls = [
                c for c in mock_logger.warning.call_args_list
                if "pii_key_network_exposure_risk" in c.args
            ]
            assert len(warning_calls) == 0


# =============================================================================
# Invariant 7: JWT secret isolation (warning, not fatal)
# =============================================================================


class TestJwtSecretWarning:
    def test_jwt_secret_with_0000_host_warns(self) -> None:
        """JWT_SECRET set + binding to 0.0.0.0 should log a warning."""
        settings = _make_settings(
            jwt_secret="my-dev-secret",
            host="0.0.0.0",
        )
        with patch("spaps_server_quickstart.startup.logger") as mock_logger:
            # Should NOT raise (warning only)
            validate_environment(settings)
            warning_calls = [
                c for c in mock_logger.warning.call_args_list
                if "jwt_secret_network_exposure_risk" in c.args
            ]
            assert len(warning_calls) == 1

    def test_jwt_secret_with_localhost_no_warning(self) -> None:
        """JWT_SECRET set + binding to 127.0.0.1 should not warn."""
        settings = _make_settings(
            jwt_secret="my-dev-secret",
            host="127.0.0.1",
        )
        with patch("spaps_server_quickstart.startup.logger") as mock_logger:
            validate_environment(settings)
            warning_calls = [
                c for c in mock_logger.warning.call_args_list
                if "jwt_secret_network_exposure_risk" in c.args
            ]
            assert len(warning_calls) == 0


# =============================================================================
# Multiple violations
# =============================================================================


class TestMultipleViolations:
    def test_multiple_violations_all_reported(self) -> None:
        """All violations should be reported in one error message."""
        settings = _make_settings(
            mailgun_api_key="key-abc123",
            stripe_secret_key="sk_live_abc123",
            solana_rpc_url="https://api.mainnet-beta.solana.com",
        )
        with pytest.raises(EnvironmentSafetyError, match="3 safety violation") as exc_info:
            validate_environment(settings)

        error_msg = str(exc_info.value)
        assert "MAILGUN_API_KEY" in error_msg
        assert "STRIPE_SECRET_KEY" in error_msg
        assert "SOLANA_RPC_URL" in error_msg


# =============================================================================
# Clean dev environment — should pass all checks
# =============================================================================


class TestCleanDevEnvironment:
    def test_minimal_dev_settings_pass(self) -> None:
        """Minimal dev settings with no production credentials should pass."""
        settings = _make_settings()
        validate_environment(settings)

    def test_test_env_passes(self) -> None:
        """Test environment should pass."""
        settings = _make_settings(env="test")
        validate_environment(settings)

    def test_dev_with_test_stripe_key_passes(self) -> None:
        """Dev with test Stripe key should pass."""
        settings = _make_settings(stripe_secret_key="sk_test_abc123")
        validate_environment(settings)


# =============================================================================
# EnvironmentSafetyError is a RuntimeError subclass
# =============================================================================


class TestErrorType:
    def test_inherits_from_runtime_error(self) -> None:
        """EnvironmentSafetyError should be catchable as RuntimeError."""
        err = EnvironmentSafetyError("test")
        assert isinstance(err, RuntimeError)
