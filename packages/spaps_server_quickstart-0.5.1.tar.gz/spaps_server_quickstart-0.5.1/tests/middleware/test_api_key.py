"""Unit tests for the api_key middleware module.

Tests extract_api_key() and validate_api_key() in isolation with mocked
Request objects and database sessions.
"""

from __future__ import annotations

import hashlib
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4


from spaps_server_quickstart.domains.applications.models import Application
from spaps_server_quickstart.middleware.api_key import (
    KeyType,
    extract_api_key,
    validate_api_key,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_request(headers: dict[str, str] | None = None) -> MagicMock:
    """Return a mock FastAPI Request with the given headers."""
    req = MagicMock()
    _headers = headers or {}
    req.headers = _headers
    return req


def _make_application(**overrides) -> MagicMock:
    """Return a mock Application with sensible defaults."""
    defaults = dict(
        id=uuid4(),
        name="Test App",
        slug="test-app",
        api_key="spaps_legacy_key_123",
        publishable_key_hash=None,
        secret_key_hash=None,
    )
    defaults.update(overrides)
    app = MagicMock(spec=Application)
    for k, v in defaults.items():
        setattr(app, k, v)
    return app


def _hash_key(key: str) -> str:
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


def _mock_db() -> AsyncMock:
    return AsyncMock()


def _db_returning(app_or_none):
    """Create a mock AsyncSession whose execute().scalar_one_or_none() returns the value."""
    db = AsyncMock()
    result_mock = MagicMock()
    result_mock.scalar_one_or_none.return_value = app_or_none
    db.execute.return_value = result_mock
    return db


def _db_returning_sequence(values: list):
    """Mock session that returns different values on successive execute() calls."""
    db = AsyncMock()
    result_mocks = []
    for v in values:
        rm = MagicMock()
        rm.scalar_one_or_none.return_value = v
        result_mocks.append(rm)
    db.execute.side_effect = result_mocks
    return db


# ===========================================================================
# extract_api_key
# ===========================================================================


class TestExtractApiKey:
    def test_extracts_from_x_api_key_header(self):
        req = _make_request({"X-API-Key": "spaps_pub_abc123"})
        assert extract_api_key(req) == "spaps_pub_abc123"

    def test_extracts_from_lowercase_x_api_key_header(self):
        req = _make_request({"x-api-key": "spaps_sec_xyz"})
        assert extract_api_key(req) == "spaps_sec_xyz"

    def test_extracts_from_authorization_bearer_non_jwt(self):
        req = _make_request({"Authorization": "Bearer spaps_sec_my_key"})
        assert extract_api_key(req) == "spaps_sec_my_key"

    def test_returns_none_when_no_header_present(self):
        req = _make_request({})
        assert extract_api_key(req) is None

    def test_skips_jwt_tokens_in_authorization(self):
        jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0In0.signature"
        req = _make_request({"Authorization": f"Bearer {jwt}"})
        assert extract_api_key(req) is None

    def test_prefers_x_api_key_over_authorization(self):
        req = _make_request({
            "X-API-Key": "spaps_pub_preferred",
            "Authorization": "Bearer spaps_sec_fallback",
        })
        assert extract_api_key(req) == "spaps_pub_preferred"

    def test_skips_non_bearer_authorization(self):
        req = _make_request({"Authorization": "Basic dXNlcjpwYXNz"})
        assert extract_api_key(req) is None

    def test_skips_empty_bearer_token(self):
        # "Bearer " with nothing after it — the token itself is empty string
        req = _make_request({"Authorization": "Bearer "})
        # Empty string is falsy, but the function returns auth_header[7:] which is ""
        result = extract_api_key(req)
        # An empty string would not look like a JWT (0 dots), so it gets returned
        # but it's technically an empty string — the caller handles validity
        assert result == "" or result is None


# ===========================================================================
# validate_api_key
# ===========================================================================


class TestValidateApiKeyPublishable:
    async def test_validates_publishable_key_by_hash(self):
        key = "spaps_pub_test_key_abc"
        expected_hash = _hash_key(key)
        app = _make_application(publishable_key_hash=expected_hash)
        db = _db_returning(app)

        result_app, key_type = await validate_api_key(db, key)

        assert result_app is app
        assert key_type == KeyType.PUBLISHABLE
        db.execute.assert_awaited_once()

    async def test_publishable_key_not_found_returns_none(self):
        key = "spaps_pub_nonexistent"
        db = _db_returning(None)

        result_app, key_type = await validate_api_key(db, key)

        assert result_app is None
        assert key_type == KeyType.PUBLISHABLE

    async def test_publishable_key_uses_timing_safe_comparison(self):
        """H1: Verify timing-safe comparison prevents timing attacks on key validation."""
        key = "spaps_pub_secure_key"
        correct_hash = _hash_key(key)
        wrong_hash = _hash_key("spaps_pub_wrong_key")

        # App with wrong hash should not validate even if DB returns it
        app = _make_application(publishable_key_hash=wrong_hash)
        db = _db_returning(app)

        result_app, key_type = await validate_api_key(db, key)

        # Should return None because timing-safe comparison fails
        assert result_app is None
        assert key_type == KeyType.PUBLISHABLE


class TestValidateApiKeySecret:
    async def test_validates_secret_key_by_hash(self):
        key = "spaps_sec_my_secret"
        expected_hash = _hash_key(key)
        app = _make_application(secret_key_hash=expected_hash)
        db = _db_returning(app)

        result_app, key_type = await validate_api_key(db, key)

        assert result_app is app
        assert key_type == KeyType.SECRET
        db.execute.assert_awaited_once()

    async def test_secret_key_uses_timing_safe_comparison(self):
        """H1: Verify timing-safe comparison prevents timing attacks on secret key validation."""
        key = "spaps_sec_secure_secret"
        correct_hash = _hash_key(key)
        wrong_hash = _hash_key("spaps_sec_wrong_secret")

        # App with wrong hash should not validate even if DB returns it
        app = _make_application(secret_key_hash=wrong_hash)
        db = _db_returning_sequence([app, None, None])  # First query returns app, fallback returns None

        result_app, key_type = await validate_api_key(db, key)

        # Should return None because timing-safe comparison fails and fallback finds nothing
        assert result_app is None
        assert key_type == KeyType.SECRET

    async def test_secret_key_falls_back_to_legacy_column(self, caplog):
        """Legacy fallback still works when enabled (default behavior)."""
        import logging
        caplog.set_level(logging.WARNING)

        key = "spaps_sec_fallback_key"
        app = _make_application(api_key=key)
        # First execute (secret_key_hash lookup) returns None,
        # second execute (legacy api_key lookup) returns app
        db = _db_returning_sequence([None, app])

        result_app, key_type = await validate_api_key(db, key, legacy_api_key_auth_enabled=True)

        assert result_app is app
        assert key_type == KeyType.LEGACY
        assert db.execute.await_count == 2
        # Should also log deprecation warning
        assert any("TM-009" in record.message for record in caplog.records)

    async def test_secret_key_falls_back_to_hashed_legacy_column(self, caplog):
        """Legacy keys stored as SHA-256 hashes are accepted while legacy auth is enabled."""
        import logging
        caplog.set_level(logging.WARNING)

        key = "spaps_sec_hashed_legacy"
        app = _make_application(api_key=_hash_key(key))
        db = _db_returning_sequence([None, None, app])

        result_app, key_type = await validate_api_key(db, key, legacy_api_key_auth_enabled=True)

        assert result_app is app
        assert key_type == KeyType.LEGACY
        assert db.execute.await_count == 3
        assert any("TM-009" in record.message for record in caplog.records)

    async def test_secret_key_not_found_anywhere(self):
        key = "spaps_sec_nowhere"
        db = _db_returning_sequence([None, None, None])

        result_app, key_type = await validate_api_key(db, key)

        assert result_app is None
        # When secret hash returns None and legacy also returns None,
        # key_type should be SECRET (the fallback didn't find anything either)
        assert key_type == KeyType.SECRET

    async def test_spaps_prefix_without_sec_checks_secret_hash_first(self):
        """Keys starting with 'spaps_' (no _pub_ or _sec_) hit the secret branch."""
        key = "spaps_my_app_key"
        expected_hash = _hash_key(key)
        app = _make_application(secret_key_hash=expected_hash)
        db = _db_returning(app)

        result_app, key_type = await validate_api_key(db, key)

        assert result_app is app
        assert key_type == KeyType.SECRET


class TestValidateApiKeyLegacy:
    async def test_validates_legacy_key_direct_match(self):
        key = "some_random_legacy_key"
        app = _make_application(api_key=key)
        db = _db_returning(app)

        result_app, key_type = await validate_api_key(db, key, legacy_api_key_auth_enabled=True)

        assert result_app is app
        assert key_type == KeyType.LEGACY

    async def test_legacy_key_not_found_returns_none(self):
        key = "unknown_legacy_key"
        db = _db_returning_sequence([None, None])

        result_app, key_type = await validate_api_key(db, key, legacy_api_key_auth_enabled=True)

        assert result_app is None
        assert key_type == KeyType.LEGACY

    async def test_validates_hashed_legacy_key(self, caplog):
        """Legacy keys generated by rotation are stored hashed but still authenticate."""
        import logging
        caplog.set_level(logging.WARNING)

        key = "legacy_key_stored_hashed"
        app = _make_application(api_key=_hash_key(key))
        db = _db_returning_sequence([None, app])

        result_app, key_type = await validate_api_key(db, key, legacy_api_key_auth_enabled=True)

        assert result_app is app
        assert key_type == KeyType.LEGACY
        assert any("TM-009" in record.message for record in caplog.records)

    async def test_legacy_key_auth_succeeds_when_enabled_with_warning(self, caplog):
        """TM-009: Legacy key auth succeeds when enabled, with deprecation warning."""
        import logging
        caplog.set_level(logging.WARNING)

        key = "legacy_key_deprecated"
        app = _make_application(api_key=key)
        db = _db_returning(app)

        result_app, key_type = await validate_api_key(db, key, legacy_api_key_auth_enabled=True)

        assert result_app is app
        assert key_type == KeyType.LEGACY
        # Verify deprecation warning was logged
        assert any("TM-009" in record.message for record in caplog.records)
        assert any("legacy_api_key_used" in str(record.__dict__.get("event", "")) for record in caplog.records)

    async def test_legacy_key_auth_rejected_when_disabled(self, caplog):
        """TM-009: Legacy key auth is rejected when disabled."""
        import logging
        caplog.set_level(logging.INFO)

        key = "legacy_key_disabled"
        app = _make_application(api_key=key)
        db = _db_returning(app)

        result_app, key_type = await validate_api_key(db, key, legacy_api_key_auth_enabled=False)

        assert result_app is None
        assert key_type == KeyType.LEGACY
        # Verify rejection was logged
        assert any("legacy_api_key_rejected" in str(record.__dict__.get("event", "")) for record in caplog.records)

    async def test_legacy_fallback_rejected_when_disabled(self):
        """TM-009: Secret key legacy fallback is blocked when disabled."""
        key = "spaps_sec_fallback_key"
        app = _make_application(api_key=key)
        # First execute (secret_key_hash lookup) returns None,
        # second execute would be legacy fallback but should be skipped
        db = _db_returning_sequence([None])

        result_app, key_type = await validate_api_key(db, key, legacy_api_key_auth_enabled=False)

        assert result_app is None
        assert key_type == KeyType.SECRET
        # Only one DB query should have been made (no fallback)
        assert db.execute.await_count == 1

    async def test_deprecation_log_structure(self, caplog):
        """TM-009: Deprecation log contains correct structured data without full key."""
        import logging
        caplog.set_level(logging.WARNING)

        key = "some_legacy_key_12345"
        app_id = uuid4()
        app = _make_application(id=app_id, api_key=key)
        db = _db_returning(app)

        await validate_api_key(db, key, legacy_api_key_auth_enabled=True)

        # Find the deprecation warning
        warning_records = [r for r in caplog.records if r.levelname == "WARNING"]
        assert len(warning_records) > 0

        record = warning_records[0]
        assert "TM-009" in record.message
        # Check extra fields
        assert hasattr(record, "event") or "event" in record.__dict__
        assert hasattr(record, "application_id") or "application_id" in record.__dict__
        assert hasattr(record, "key_prefix") or "key_prefix" in record.__dict__
        # Ensure full key is NOT in the log
        assert key not in record.message

    async def test_modern_keys_unaffected_by_legacy_flag(self):
        """TM-009: Modern hashed keys work regardless of legacy flag setting."""
        # Test publishable key
        pub_key = "spaps_pub_modern_key"
        pub_hash = _hash_key(pub_key)
        pub_app = _make_application(publishable_key_hash=pub_hash)
        db = _db_returning(pub_app)

        result_app, key_type = await validate_api_key(db, pub_key, legacy_api_key_auth_enabled=False)
        assert result_app is pub_app
        assert key_type == KeyType.PUBLISHABLE

        # Test secret key
        sec_key = "spaps_sec_modern_key"
        sec_hash = _hash_key(sec_key)
        sec_app = _make_application(secret_key_hash=sec_hash)
        db = _db_returning(sec_app)

        result_app, key_type = await validate_api_key(db, sec_key, legacy_api_key_auth_enabled=False)
        assert result_app is sec_app
        assert key_type == KeyType.SECRET
