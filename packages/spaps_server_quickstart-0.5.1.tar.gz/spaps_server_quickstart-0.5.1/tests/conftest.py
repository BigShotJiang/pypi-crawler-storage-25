"""
Root test conftest for spaps-server-quickstart.

pytest_plugins MUST be declared at the top-level conftest (pytest requirement).
Domain-specific TestConfig registration lives in tests/domains/conftest.py.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from spaps_server_quickstart.settings import BaseServiceSettings
from spaps_server_quickstart.spaps_settings import SpapsSettings

# Register quickstart testing plugin (provides infrastructure fixtures + hooks)
pytest_plugins = ["spaps_server_quickstart.testing"]


def _settings_env_keys() -> tuple[str, ...]:
    keys = {
        "ENV",
        "SPAPS_ENV",
        "DEVELOPMENT_ENVIRONMENT",
        "DEBUG",
    }
    for model in (BaseServiceSettings, SpapsSettings):
        for field_name in model.model_fields:
            keys.add(field_name.upper())
    return tuple(sorted(keys))


_ISOLATED_SETTINGS_ENV_KEYS = _settings_env_keys()


@pytest.fixture(autouse=True)
def isolate_non_domain_settings_env(monkeypatch: pytest.MonkeyPatch, request: pytest.FixtureRequest) -> None:
    """Keep non-domain settings tests deterministic against local shell env."""
    test_path = Path(str(getattr(request.node, "path", ""))).as_posix()
    if "/tests/domains/" in test_path:
        return

    for key in _ISOLATED_SETTINGS_ENV_KEYS:
        monkeypatch.delenv(key, raising=False)
