"""Tests for callback_url origin validation in agent_approvals.

Exercises validate_callback_url_origin which delegates to
domains.redirects.validate_payment_redirect_url for origin-checking
against application.allowed_origins.

Also includes service-layer integration tests that verify the wiring
of create_approval → validate_callback_url_origin.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.agent_approvals import service
from spaps_server_quickstart.domains.agent_approvals.schemas import (
    validate_callback_url_origin,
)
from spaps_server_quickstart.domains.errors import ValidationError


def _make_settings(*, env: str = "production") -> MagicMock:
    settings = MagicMock()
    settings.env = env
    return settings


def _make_application(*, allowed_origins: list[str] | None = None) -> MagicMock:
    app = MagicMock()
    app.allowed_origins = allowed_origins
    return app


class TestCallbackUrlOriginPositive:
    """Valid callback_url whose origin matches allowed_origins should pass."""

    def test_valid_origin_in_allowed_origins(self):
        settings = _make_settings(env="production")
        application = _make_application(allowed_origins=["https://myapp.example.com"])
        result = validate_callback_url_origin(
            "https://myapp.example.com/webhook/callback",
            settings=settings,
            application=application,
        )
        assert result == "https://myapp.example.com/webhook/callback"

    def test_none_callback_url_passes(self):
        settings = _make_settings(env="production")
        application = _make_application(allowed_origins=["https://example.com"])
        assert validate_callback_url_origin(None, settings=settings, application=application) is None

    def test_wildcard_origin_allowed_in_development(self):
        settings = _make_settings(env="development")
        application = _make_application(allowed_origins=["*"])
        result = validate_callback_url_origin(
            "https://dev.example.com/callback",
            settings=settings,
            application=application,
        )
        assert result == "https://dev.example.com/callback"

    def test_multiple_allowed_origins_match_second(self):
        settings = _make_settings(env="production")
        application = _make_application(
            allowed_origins=["https://app1.example.com", "https://app2.example.com"]
        )
        result = validate_callback_url_origin(
            "https://app2.example.com/hook",
            settings=settings,
            application=application,
        )
        assert result == "https://app2.example.com/hook"


class TestCallbackUrlOriginForeignRejected:
    """callback_url whose origin is NOT in allowed_origins must be rejected."""

    def test_foreign_origin_rejected(self):
        settings = _make_settings(env="production")
        application = _make_application(allowed_origins=["https://trusted.example.com"])
        with pytest.raises(ValidationError, match="callback_url origin is not allowed"):
            validate_callback_url_origin(
                "https://evil.attacker.com/steal",
                settings=settings,
                application=application,
            )

    def test_foreign_origin_rejected_in_development(self):
        settings = _make_settings(env="development")
        application = _make_application(allowed_origins=["https://trusted.example.com"])
        with pytest.raises(ValidationError, match="callback_url origin is not allowed"):
            validate_callback_url_origin(
                "https://evil.attacker.com/steal",
                settings=settings,
                application=application,
            )


class TestCallbackUrlOriginEmptyAllowlistRejected:
    """callback_url must fail closed if no valid allowed_origins are configured."""

    def test_missing_allowed_origins_rejected(self):
        settings = _make_settings(env="production")
        application = _make_application(allowed_origins=None)
        with pytest.raises(ValidationError, match="callback_url origin is not allowed"):
            validate_callback_url_origin(
                "https://trusted.example.com/callback",
                settings=settings,
                application=application,
            )

    def test_empty_allowed_origins_rejected(self):
        settings = _make_settings(env="production")
        application = _make_application(allowed_origins=[])
        with pytest.raises(ValidationError, match="callback_url origin is not allowed"):
            validate_callback_url_origin(
                "https://trusted.example.com/callback",
                settings=settings,
                application=application,
            )

    def test_sanitized_empty_allowed_origins_rejected(self):
        settings = _make_settings(env="production")
        application = _make_application(allowed_origins=["   ", "/", "///"])
        with pytest.raises(ValidationError, match="callback_url origin is not allowed"):
            validate_callback_url_origin(
                "https://trusted.example.com/callback",
                settings=settings,
                application=application,
            )


class TestCallbackUrlWildcardOriginInProduction:
    """Any wildcard in allowed_origins must be rejected in production."""

    def test_wildcard_star_rejected_in_production(self):
        settings = _make_settings(env="production")
        application = _make_application(allowed_origins=["*"])
        with pytest.raises(ValidationError, match="wildcard"):
            validate_callback_url_origin(
                "https://anything.com/callback",
                settings=settings,
                application=application,
            )

    def test_https_wildcard_rejected_in_production(self):
        settings = _make_settings(env="production")
        application = _make_application(allowed_origins=["https://*"])
        with pytest.raises(ValidationError, match="wildcard"):
            validate_callback_url_origin(
                "https://anything.com/callback",
                settings=settings,
                application=application,
            )

    def test_mixed_wildcard_and_concrete_rejected_in_production(self):
        """Even if concrete origins are present, any wildcard triggers rejection."""
        settings = _make_settings(env="production")
        application = _make_application(
            allowed_origins=["*", "https://legit.example.com"]
        )
        with pytest.raises(ValidationError, match="wildcard"):
            validate_callback_url_origin(
                "https://legit.example.com/callback",
                settings=settings,
                application=application,
            )

    def test_mixed_wildcard_and_concrete_allowed_in_development(self):
        settings = _make_settings(env="development")
        application = _make_application(
            allowed_origins=["*", "https://legit.example.com"]
        )
        result = validate_callback_url_origin(
            "https://anything.com/callback",
            settings=settings,
            application=application,
        )
        assert result == "https://anything.com/callback"


# ===========================================================================
# Service-layer integration: create_approval wiring
# ===========================================================================

_REPO = "spaps_server_quickstart.domains.agent_approvals.service.repo"


def _make_agent_mock(*, scopes: list[str] | None = None) -> MagicMock:
    agent = MagicMock()
    agent.id = uuid4()
    agent.application_id = uuid4()
    agent.owner_user_id = uuid4()
    agent.name = "test-agent"
    agent.scopes = scopes or []
    agent.is_active = True
    return agent


def _make_approval_mock() -> MagicMock:
    approval = MagicMock()
    approval.id = uuid4()
    approval.code = "ABCD-EFGH"
    approval.expires_at = datetime.now(UTC) + timedelta(minutes=15)
    return approval


class TestCreateApprovalCallbackUrlWiring:
    """Service.create_approval rejects callback_url with foreign origin."""

    @patch(_REPO)
    async def test_foreign_callback_url_rejected_by_service(self, mock_repo):
        agent = _make_agent_mock(scopes=[])
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        app_model = MagicMock()
        app_model.settings = {}
        app_model.allowed_origins = ["https://trusted.example.com"]
        mock_repo.get_application = AsyncMock(return_value=app_model)

        settings = _make_settings(env="production")
        db = AsyncMock()

        with pytest.raises(ValidationError, match="callback_url origin is not allowed"):
            await service.create_approval(
                db,
                agent_id=agent.id,
                application_id=agent.application_id,
                action="deploy:prod",
                callback_url="https://evil.attacker.com/exfil",
                settings=settings,
            )

    @patch(_REPO)
    async def test_valid_callback_url_passes_through_service(self, mock_repo):
        agent = _make_agent_mock(scopes=[])
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        app_model = MagicMock()
        app_model.settings = {}
        app_model.allowed_origins = ["https://trusted.example.com"]
        mock_repo.get_application = AsyncMock(return_value=app_model)
        mock_repo.create_approval = AsyncMock(return_value=_make_approval_mock())

        settings = _make_settings(env="production")
        db = AsyncMock()

        result = await service.create_approval(
            db,
            agent_id=agent.id,
            application_id=agent.application_id,
            action="deploy:prod",
            callback_url="https://trusted.example.com/hook",
            settings=settings,
        )
        assert result["status"] == "pending"

    @patch(_REPO)
    async def test_wildcard_callback_url_rejected_in_prod(self, mock_repo):
        agent = _make_agent_mock(scopes=[])
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        app_model = MagicMock()
        app_model.settings = {}
        app_model.allowed_origins = ["*"]
        mock_repo.get_application = AsyncMock(return_value=app_model)

        settings = _make_settings(env="production")
        db = AsyncMock()

        with pytest.raises(ValidationError, match="wildcard"):
            await service.create_approval(
                db,
                agent_id=agent.id,
                application_id=agent.application_id,
                action="deploy:prod",
                callback_url="https://anything.com/callback",
                settings=settings,
            )
