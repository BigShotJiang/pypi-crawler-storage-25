"""Unit tests for the documentation domain repository layer.

The database session is fully mocked so tests exercise only the
repository query construction and result handling.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

from spaps_server_quickstart.domains.docs import repository as repo

FAKE_DOC_ID = uuid4()


def _mock_db_result(items):
    """Create a mock DB result that supports scalar_one_or_none and scalars."""
    result = MagicMock()
    result.scalar_one_or_none.return_value = items[0] if items else None

    scalars_mock = MagicMock()
    scalars_mock.all.return_value = items
    scalars_mock.first.return_value = items[0] if items else None
    result.scalars.return_value = scalars_mock

    return result


def _mock_doc(**overrides):
    """Create a mock Documentation object."""
    doc = MagicMock()
    doc.id = overrides.get("id", uuid4())
    doc.slug = overrides.get("slug", "getting-started")
    doc.title = overrides.get("title", "Getting Started")
    doc.content = overrides.get("content", "Welcome to SPAPS")
    doc.category = overrides.get("category", "guides")
    doc.category_id = overrides.get("category_id", None)
    doc.tags = overrides.get("tags", ["intro"])
    doc.metadata_ = overrides.get("metadata_", {})
    doc.is_published = overrides.get("is_published", True)
    doc.created_at = datetime.now(UTC)
    return doc


def _mock_endpoint_doc(**overrides):
    """Create a mock EndpointDocumentation object."""
    endpoint = MagicMock()
    endpoint.id = overrides.get("id", uuid4())
    endpoint.method = overrides.get("method", "POST")
    endpoint.path = overrides.get("path", "/api/auth/login")
    endpoint.description = overrides.get("description", "Login endpoint")
    endpoint.authentication = overrides.get("authentication", {"type": "api_key"})
    endpoint.request_body = overrides.get("request_body", {})
    endpoint.response_body = overrides.get("response_body", {})
    endpoint.error_codes = overrides.get("error_codes", {})
    endpoint.rate_limit = overrides.get("rate_limit", None)
    endpoint.deprecated = overrides.get("deprecated", False)
    endpoint.created_at = datetime.now(UTC)
    return endpoint


def _mock_error_doc(**overrides):
    """Create a mock ErrorDoc object."""
    error = MagicMock()
    error.id = overrides.get("id", uuid4())
    error.code = overrides.get("code", "INVALID_CREDENTIALS")
    error.http_status = overrides.get("http_status", 401)
    error.message = overrides.get("message", "Invalid credentials")
    error.description = overrides.get("description", "Login failed")
    error.possible_causes = overrides.get("possible_causes", ["Wrong password"])
    error.solutions = overrides.get("solutions", ["Check password"])
    error.related_errors = overrides.get("related_errors", [])
    error.created_at = datetime.now(UTC)
    return error


def _mock_example(**overrides):
    """Create a mock CodeExample object."""
    example = MagicMock()
    example.id = overrides.get("id", uuid4())
    example.title = overrides.get("title", "Login Example")
    example.description = overrides.get("description", "How to login")
    example.language = overrides.get("language", "typescript")
    example.code = overrides.get("code", "const response = await fetch(...)")
    example.dependencies = overrides.get("dependencies", None)
    example.output = overrides.get("output", None)
    example.doc_id = overrides.get("doc_id", None)
    example.endpoint = overrides.get("endpoint", None)
    example.error_code = overrides.get("error_code", None)
    example.feature = overrides.get("feature", "authentication")
    example.created_at = datetime.now(UTC)
    return example


def _mock_category(**overrides):
    """Create a mock DocumentationCategory object."""
    cat = MagicMock()
    cat.id = overrides.get("id", uuid4())
    cat.name = overrides.get("name", "Guides")
    cat.slug = overrides.get("slug", "guides")
    cat.description = overrides.get("description", "User guides")
    cat.order_index = overrides.get("order_index", 0)
    cat.created_at = datetime.now(UTC)
    return cat


# ===========================================================================
# search_docs_keyword
# ===========================================================================


class TestSearchDocsKeyword:
    async def test_returns_matching_docs(self):
        """Returns published docs matching keyword."""
        docs = [_mock_doc(), _mock_doc(title="API Reference")]
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(docs)

        result = await repo.search_docs_keyword(db, query="getting")
        assert len(result) == 2

    async def test_returns_empty_on_no_match(self):
        """Returns empty list when no docs match."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.search_docs_keyword(db, query="nonexistent")
        assert len(result) == 0

    async def test_respects_limit(self):
        """Respects the limit parameter."""
        docs = [_mock_doc()]
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(docs)

        result = await repo.search_docs_keyword(db, query="test", limit=5)
        assert len(result) == 1


# ===========================================================================
# get_endpoint_doc
# ===========================================================================


class TestGetEndpointDoc:
    async def test_found(self):
        """Returns endpoint doc when found."""
        endpoint = _mock_endpoint_doc()
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([endpoint])

        result = await repo.get_endpoint_doc(db, "POST", "/api/auth/login")
        assert result == endpoint

    async def test_not_found(self):
        """Returns None when endpoint doc not found."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.get_endpoint_doc(db, "GET", "/nonexistent")
        assert result is None


# ===========================================================================
# get_error_doc
# ===========================================================================


class TestGetErrorDoc:
    async def test_found(self):
        """Returns error doc when found."""
        error = _mock_error_doc()
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([error])

        result = await repo.get_error_doc(db, "INVALID_CREDENTIALS")
        assert result == error

    async def test_not_found(self):
        """Returns None when error doc not found."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.get_error_doc(db, "NONEXISTENT")
        assert result is None


# ===========================================================================
# get_examples_by_feature
# ===========================================================================


class TestGetExamplesByFeature:
    async def test_returns_examples(self):
        """Returns examples for a feature."""
        examples = [_mock_example(), _mock_example(language="python")]
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(examples)

        result = await repo.get_examples_by_feature(db, "authentication")
        assert len(result) == 2

    async def test_empty(self):
        """Returns empty list when no examples."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.get_examples_by_feature(db, "nonexistent")
        assert len(result) == 0

    async def test_with_language_filter(self):
        """Filters examples by language."""
        examples = [_mock_example(language="python")]
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(examples)

        result = await repo.get_examples_by_feature(
            db, "authentication", language="python"
        )
        assert len(result) == 1


# ===========================================================================
# get_examples_by_error_code
# ===========================================================================


class TestGetExamplesByErrorCode:
    async def test_returns_examples(self):
        """Returns examples for an error code."""
        examples = [_mock_example(error_code="INVALID_CREDENTIALS")]
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(examples)

        result = await repo.get_examples_by_error_code(db, "INVALID_CREDENTIALS")
        assert len(result) == 1


# ===========================================================================
# get_examples_by_doc_id
# ===========================================================================


class TestGetExamplesByDocId:
    async def test_returns_examples(self):
        """Returns examples for a doc ID."""
        examples = [_mock_example(doc_id=FAKE_DOC_ID)]
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(examples)

        result = await repo.get_examples_by_doc_id(db, FAKE_DOC_ID)
        assert len(result) == 1


class TestGetExamplesByDocIds:
    async def test_returns_examples_grouped_by_doc_id(self):
        """Returns examples grouped by documentation ID."""
        other_doc_id = uuid4()
        first_example = _mock_example(doc_id=FAKE_DOC_ID, title="First Example")
        second_example = _mock_example(doc_id=other_doc_id, title="Second Example")
        third_example = _mock_example(doc_id=FAKE_DOC_ID, title="Third Example")
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(
            [first_example, second_example, third_example]
        )

        result = await repo.get_examples_by_doc_ids(db, [FAKE_DOC_ID, other_doc_id])

        assert result == {
            FAKE_DOC_ID: [first_example, third_example],
            other_doc_id: [second_example],
        }

    async def test_returns_empty_mapping_without_doc_ids(self):
        """Avoids a database round-trip when there are no doc IDs."""
        db = AsyncMock()

        result = await repo.get_examples_by_doc_ids(db, [])

        assert result == {}
        db.execute.assert_not_called()

    async def test_filters_grouped_examples_by_language(self):
        """Passes the language filter through the grouped query."""
        examples = [_mock_example(doc_id=FAKE_DOC_ID, language="python")]
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(examples)

        result = await repo.get_examples_by_doc_ids(
            db, [FAKE_DOC_ID], language="python"
        )

        assert result == {FAKE_DOC_ID: examples}


# ===========================================================================
# list_categories
# ===========================================================================


class TestListCategories:
    async def test_returns_categories(self):
        """Returns all categories."""
        cats = [_mock_category(), _mock_category(name="API Reference", slug="api-reference")]
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(cats)

        result = await repo.list_categories(db)
        assert len(result) == 2

    async def test_empty(self):
        """Returns empty list when no categories."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.list_categories(db)
        assert len(result) == 0


# ===========================================================================
# create_feedback
# ===========================================================================


class TestCreateFeedback:
    async def test_creates_and_returns(self):
        """Creates feedback and returns it."""
        db = AsyncMock()
        db.add = MagicMock()

        result = await repo.create_feedback(
            db,
            document_id="doc-123",
            helpful=True,
            suggestion="Great doc!",
        )

        db.add.assert_called_once()
        db.flush.assert_called_once()
        db.refresh.assert_called_once()


# ===========================================================================
# create_documentation
# ===========================================================================


class TestCreateDocumentation:
    async def test_creates_and_returns(self):
        """Creates documentation article and returns it."""
        db = AsyncMock()
        db.add = MagicMock()

        result = await repo.create_documentation(
            db,
            slug="test-doc",
            title="Test Doc",
            content="Test content",
        )

        db.add.assert_called_once()
        db.flush.assert_called_once()
        db.refresh.assert_called_once()
