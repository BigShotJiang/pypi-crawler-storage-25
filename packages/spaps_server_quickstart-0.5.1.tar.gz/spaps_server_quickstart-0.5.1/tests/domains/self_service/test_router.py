"""Unit tests for the self-service domain router (HTTP layer).

Each test creates a minimal FastAPI test app with dependency overrides.
The applications repository is mocked so tests exercise only routing,
request validation, status codes, and response shapes.
"""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.self_service.router import router
from spaps_server_quickstart.domains.self_service import service as ss_service
from spaps_server_quickstart.domains.errors import DomainError
from spaps_server_quickstart.middleware.spaps_deps import get_db_session

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_REPO_MODULE = "spaps_server_quickstart.domains.self_service.service"


def _create_test_app(*, password: str = "test-password"):
    """Create a FastAPI test app with overridden dependencies."""
    app = FastAPI()

    settings = MagicMock()
    settings.self_service_password = password
    settings.env = "test"
    settings.self_service_allowed_ips = []  # TM-008: default empty = no restriction
    settings.trusted_proxy_cidrs = []
    app.state.settings = settings

    # Register the domain error handler
    @app.exception_handler(DomainError)
    async def _domain_error_handler(request, exc):
        from fastapi.responses import JSONResponse

        return JSONResponse(
            status_code=exc.status_code,
            content={
                "success": False,
                "error": {"code": exc.code, "message": exc.message},
            },
        )

    app.include_router(router)

    # Override DB dependency
    mock_db = AsyncMock()
    app.dependency_overrides[get_db_session] = lambda: mock_db

    return app, mock_db


async def _client(app: FastAPI, *, client_host: str = "127.0.0.1"):
    """Create an httpx async client for the given app."""
    transport = ASGITransport(app=app, client=(client_host, 123))
    return AsyncClient(transport=transport, base_url="http://test")


def _make_mock_app(**overrides):
    """Build a mock Application ORM object."""
    defaults = {
        "id": uuid4(),
        "name": "Test App",
        "slug": "test-app",
        "description": "A test application",
        "api_key": "hashed-key",
        "webhook_url": None,
        "allowed_origins": None,
        "settings": {"supported_chains": ["solana"]},
        "whitelist_enabled": False,
        "whitelist_count": 0,
        "publishable_key_hash": "pub-hash",
        "secret_key_hash": "sec-hash",
        "created_at": datetime(2025, 1, 1, tzinfo=timezone.utc),
        "updated_at": datetime(2025, 1, 1, tzinfo=timezone.utc),
    }
    defaults.update(overrides)
    app = MagicMock()
    for k, v in defaults.items():
        setattr(app, k, v)
    return app


def _get_valid_token() -> str:
    """Generate and store a valid self-service token."""
    token = ss_service.generate_token()
    ss_service.store_token(token)
    return token


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _reset_service_state():
    """Reset in-memory stores before each test."""
    ss_service._reset_stores()
    yield
    ss_service._reset_stores()


# ---------------------------------------------------------------------------
# Tests: POST /self-service/auth
# ---------------------------------------------------------------------------


class TestAuth:
    async def test_valid_password_returns_token(self):
        app, _ = _create_test_app(password="correct-password")
        async with await _client(app) as c:
            resp = await c.post(
                "/self-service/auth",
                json={"password": "correct-password"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["token"].startswith("ss_")
        assert len(data["token"]) == 67
        assert "expiresAt" in data
        datetime.fromisoformat(data["expiresAt"])
        assert "Bearer" in data["message"]

    async def test_wrong_password_returns_401(self):
        app, _ = _create_test_app(password="correct-password")
        async with await _client(app) as c:
            resp = await c.post(
                "/self-service/auth",
                json={"password": "wrong-password"},
            )

        assert resp.status_code == 401
        data = resp.json()
        assert data["error"]["code"] == "INVALID_CREDENTIALS"

    async def test_missing_password_returns_400(self):
        app, _ = _create_test_app(password="correct-password")
        async with await _client(app) as c:
            resp = await c.post(
                "/self-service/auth",
                json={"password": ""},
            )

        assert resp.status_code == 400
        data = resp.json()
        assert data["error"]["code"] == "MISSING_PASSWORD"

    async def test_rate_limiting_after_5_failures(self):
        app, _ = _create_test_app(password="correct-password")
        async with await _client(app) as c:
            # Exhaust rate limit with 5 failures
            for _ in range(5):
                await c.post(
                    "/self-service/auth",
                    json={"password": "wrong"},
                )

            # 6th attempt should be rate limited
            resp = await c.post(
                "/self-service/auth",
                json={"password": "wrong"},
            )

        assert resp.status_code == 429
        data = resp.json()
        assert data["error"]["code"] == "RATE_LIMIT_EXCEEDED"

    async def test_rate_limit_resets_on_success(self):
        app, _ = _create_test_app(password="correct")
        async with await _client(app) as c:
            # Make 4 failed attempts
            for _ in range(4):
                await c.post(
                    "/self-service/auth",
                    json={"password": "wrong"},
                )

            # Successful auth should reset the counter
            resp = await c.post(
                "/self-service/auth",
                json={"password": "correct"},
            )
            assert resp.status_code == 200

            # Now we should be able to fail again without hitting limit
            resp = await c.post(
                "/self-service/auth",
                json={"password": "wrong"},
            )
            assert resp.status_code == 401  # Not 429

    async def test_service_unavailable_when_no_password_configured(self):
        app, _ = _create_test_app(password="")
        async with await _client(app) as c:
            resp = await c.post(
                "/self-service/auth",
                json={"password": "anything"},
            )

        assert resp.status_code == 503
        data = resp.json()
        assert data["error"]["code"] == "SERVICE_UNAVAILABLE"


# ---------------------------------------------------------------------------
# Tests: Token validation
# ---------------------------------------------------------------------------


class TestTokenValidation:
    async def test_valid_token_grants_access(self):
        app, mock_db = _create_test_app()
        token = _get_valid_token()

        with patch(f"{_REPO_MODULE}.apps_repo.list_applications", new_callable=AsyncMock) as mock_list:
            mock_list.return_value = []
            async with await _client(app) as c:
                resp = await c.get(
                    "/self-service/applications",
                    headers={"Authorization": f"Bearer {token}"},
                )

        assert resp.status_code == 200

    async def test_missing_token_returns_401(self):
        app, _ = _create_test_app()
        async with await _client(app) as c:
            resp = await c.get("/self-service/applications")

        assert resp.status_code == 401
        data = resp.json()
        assert data["error"]["code"] == "UNAUTHORIZED"

    async def test_malformed_token_returns_401(self):
        app, _ = _create_test_app()
        async with await _client(app) as c:
            resp = await c.get(
                "/self-service/applications",
                headers={"Authorization": "Bearer not-a-valid-token"},
            )

        assert resp.status_code == 401

    async def test_expired_token_returns_401(self):
        app, _ = _create_test_app()
        token = ss_service.generate_token()
        # Store with already-expired TTL
        ss_service._valid_tokens.add(token)
        ss_service._token_timers[token] = 0  # epoch = expired

        async with await _client(app) as c:
            resp = await c.get(
                "/self-service/applications",
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 401

    async def test_unknown_token_returns_401(self):
        app, _ = _create_test_app()
        # Generate a token but do NOT store it
        token = ss_service.generate_token()

        async with await _client(app) as c:
            resp = await c.get(
                "/self-service/applications",
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 401


# ---------------------------------------------------------------------------
# Tests: POST /self-service/applications
# ---------------------------------------------------------------------------


class TestCreateApplication:
    @patch(f"{_REPO_MODULE}.apps_repo.get_application_by_name", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.apps_repo.create_application", new_callable=AsyncMock)
    async def test_success(self, mock_create, mock_get_by_name):
        mock_get_by_name.return_value = None
        mock_app = _make_mock_app()
        mock_create.return_value = mock_app

        app, mock_db = _create_test_app()
        mock_db.commit = AsyncMock()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.post(
                "/self-service/applications",
                json={"name": "My App", "slug": "my-app"},
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 201
        data = resp.json()
        assert "application" in data
        assert data["publishable_key"].startswith("spaps_pub_")
        assert data["secret_key"].startswith("spaps_sec_")
        assert data["api_key"] == data["secret_key"]
        assert "warning" in data

        create_kwargs = mock_create.await_args.kwargs
        assert create_kwargs["api_key"] == ss_service.hash_key(data["secret_key"])
        assert create_kwargs["secret_key_hash"] == ss_service.hash_key(data["secret_key"])

    @patch(f"{_REPO_MODULE}.apps_repo.get_application_by_name", new_callable=AsyncMock)
    async def test_duplicate_name_returns_409(self, mock_get_by_name):
        mock_get_by_name.return_value = _make_mock_app(name="Existing App")

        app, _ = _create_test_app()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.post(
                "/self-service/applications",
                json={"name": "Existing App", "slug": "existing-app"},
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 409
        data = resp.json()
        assert data["error"]["code"] == "APPLICATION_EXISTS"

    async def test_missing_name_returns_422(self):
        app, _ = _create_test_app()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.post(
                "/self-service/applications",
                json={"slug": "my-app"},
                headers={"Authorization": f"Bearer {token}"},
            )

        # FastAPI returns 422 for missing required fields
        assert resp.status_code == 422

    async def test_missing_slug_returns_422(self):
        app, _ = _create_test_app()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.post(
                "/self-service/applications",
                json={"name": "My App"},
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 422

    async def test_invalid_slug_returns_422(self):
        app, _ = _create_test_app()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.post(
                "/self-service/applications",
                json={"name": "My App", "slug": "INVALID SLUG!"},
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 422

    async def test_invalid_allowed_origins_returns_422(self):
        app, _ = _create_test_app()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.post(
                "/self-service/applications",
                json={
                    "name": "My App",
                    "slug": "my-app",
                    "allowed_origins": ["not-a-url"],
                },
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 422

    @patch(f"{_REPO_MODULE}.apps_repo.get_application_by_name", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.apps_repo.create_application", new_callable=AsyncMock)
    async def test_default_settings_applied(self, mock_create, mock_get_by_name):
        mock_get_by_name.return_value = None
        mock_app = _make_mock_app()
        mock_create.return_value = mock_app

        app, mock_db = _create_test_app()
        mock_db.commit = AsyncMock()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.post(
                "/self-service/applications",
                json={"name": "My App", "slug": "my-app"},
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 201
        # Verify create_application was called with merged settings
        call_kwargs = mock_create.call_args
        settings_arg = call_kwargs.kwargs.get("settings") or call_kwargs[1].get("settings")
        assert settings_arg is not None
        assert "supported_chains" in settings_arg

    @patch(f"{_REPO_MODULE}.apps_repo.get_application_by_name", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.apps_repo.create_application", new_callable=AsyncMock)
    async def test_blueprint_compiles_publishable_scope(self, mock_create, mock_get_by_name):
        mock_get_by_name.return_value = None
        mock_app = _make_mock_app()
        mock_create.return_value = mock_app

        app, mock_db = _create_test_app()
        mock_db.commit = AsyncMock()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.post(
                "/self-service/applications",
                json={
                    "name": "My App",
                    "slug": "my-app",
                    "allowed_origins": ["https://app.example.com"],
                    "blueprint_key": "browser_auth",
                    "blueprint": {
                        "publishable_scopes": ["auth", "docs"],
                        "settings": {"feature_flags": {"beta": True}},
                    },
                },
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 201
        call_kwargs = mock_create.call_args
        settings_arg = call_kwargs.kwargs.get("settings") or call_kwargs[1].get("settings")
        assert settings_arg["application_blueprint"]["key"] == "browser_auth"
        assert settings_arg["application_blueprint"]["publishable_scopes"] == [
            "auth",
            "docs",
        ]
        assert settings_arg["feature_flags"] == {"beta": True}
        assert settings_arg["publishable_key_access"]["allowed_patterns"] == [
            "/api/auth/login",
            "/api/auth/register",
            "/api/auth/refresh",
            "/api/auth/logout",
            "/api/auth/nonce",
            "/api/auth/wallet-sign-in",
            "/api/auth/magic-link",
            "/api/auth/verify-magic-link",
            "/api/auth/password-reset",
            "/api/auth/reset-password-confirm",
            "/api/auth/set-password",
            "/api/auth/user",
            "/api/auth/solana/",
            "/api/auth/ethereum/",
            "/docs",
            "/api-docs",
            "/api/docs/",
        ]
        assert {
            "path": "/api/auth/login",
            "methods": ["POST"],
            "match": "exact",
        } in settings_arg["publishable_key_access"]["allowed_routes"]
        assert {
            "path": "/api/auth/user",
            "methods": ["GET"],
            "match": "exact",
        } in settings_arg["publishable_key_access"]["allowed_routes"]

    @patch(f"{_REPO_MODULE}.policy_repo.create_policy", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.apps_repo.get_application_by_name", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.apps_repo.create_application", new_callable=AsyncMock)
    async def test_golden_path_blueprint_persists_reference_contract(
        self, mock_create, mock_get_by_name, mock_create_policy
    ):
        mock_get_by_name.return_value = None
        mock_app = _make_mock_app()
        mock_create.return_value = mock_app
        mock_create_policy.return_value = {"policy": {"name": "access-paid-features"}}

        app, mock_db = _create_test_app()
        mock_db.commit = AsyncMock()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.post(
                "/self-service/applications",
                json={
                    "name": "Golden Path",
                    "slug": "golden-path",
                    "allowed_origins": ["https://app.example.com"],
                    "blueprint_key": "golden_path",
                },
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 201
        call_kwargs = mock_create.call_args
        settings_arg = call_kwargs.kwargs.get("settings") or call_kwargs[1].get("settings")
        assert settings_arg["application_blueprint"]["key"] == "golden_path"
        assert settings_arg["feature_flags"] == {"golden_path_reference": True}
        assert settings_arg["application_blueprint"]["journeys"][0]["publishable_scopes"] == [
            "auth",
            "sessions",
        ]
        assert settings_arg["application_blueprint"]["journeys"][1]["entitlement_key"] == "paid_access"
        assert settings_arg["application_blueprint"]["journeys"][1]["policy_name"] == "access-paid-features"
        assert (
            "docs/downstream_apps/golden-path-reference/README.md"
            in settings_arg["application_blueprint"]["docs"]
        )
        mock_create_policy.assert_awaited_once()


# ---------------------------------------------------------------------------
# Tests: GET /self-service/applications
# ---------------------------------------------------------------------------


class TestListApplications:
    @patch(f"{_REPO_MODULE}.apps_repo.list_applications", new_callable=AsyncMock)
    async def test_returns_masked_keys(self, mock_list):
        mock_list.return_value = [
            _make_mock_app(name="App 1"),
            _make_mock_app(name="App 2"),
        ]

        app, _ = _create_test_app()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.get(
                "/self-service/applications",
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        assert len(data["applications"]) == 2
        for a in data["applications"]:
            assert a["api_key"] == "spaps_****"

    @patch(f"{_REPO_MODULE}.apps_repo.list_applications", new_callable=AsyncMock)
    async def test_empty_list(self, mock_list):
        mock_list.return_value = []

        app, _ = _create_test_app()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.get(
                "/self-service/applications",
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0
        assert data["applications"] == []


# ---------------------------------------------------------------------------
# Tests: GET /self-service/applications/{app_id}
# ---------------------------------------------------------------------------


class TestGetApplication:
    @patch(f"{_REPO_MODULE}.apps_repo.get_application_by_id", new_callable=AsyncMock)
    async def test_found(self, mock_get):
        mock_app = _make_mock_app()
        mock_get.return_value = mock_app

        app, _ = _create_test_app()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.get(
                f"/self-service/applications/{mock_app.id}",
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["application"]["name"] == "Test App"
        assert data["application"]["api_key"] == "spaps_****"

    @patch(f"{_REPO_MODULE}.apps_repo.get_application_by_id", new_callable=AsyncMock)
    async def test_not_found(self, mock_get):
        mock_get.return_value = None

        app, _ = _create_test_app()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.get(
                f"/self-service/applications/{uuid4()}",
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 404
        data = resp.json()
        assert data["error"]["code"] == "NOT_FOUND"


# ---------------------------------------------------------------------------
# Tests: POST /self-service/applications/{app_id}/rotate-key (legacy)
# ---------------------------------------------------------------------------


class TestRotateKey:
    @patch(f"{_REPO_MODULE}.apps_repo.update_application", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.apps_repo.get_application_by_id", new_callable=AsyncMock)
    async def test_success(self, mock_get, mock_update):
        mock_app = _make_mock_app()
        mock_get.return_value = mock_app
        mock_update.return_value = mock_app

        app, mock_db = _create_test_app()
        mock_db.commit = AsyncMock()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.post(
                f"/self-service/applications/{mock_app.id}/rotate-key",
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["api_key"].startswith("spaps_")
        assert "warning" in data
        assert "old key is now invalid" in data["warning"]

    @patch(f"{_REPO_MODULE}.apps_repo.get_application_by_id", new_callable=AsyncMock)
    async def test_not_found(self, mock_get):
        mock_get.return_value = None

        app, _ = _create_test_app()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.post(
                f"/self-service/applications/{uuid4()}/rotate-key",
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Tests: POST /self-service/applications/{app_id}/rotate-key/{key_type}
# ---------------------------------------------------------------------------


class TestRotateTypedKey:
    @patch(f"{_REPO_MODULE}.apps_repo.update_application", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.apps_repo.get_application_by_id", new_callable=AsyncMock)
    async def test_rotate_publishable_key(self, mock_get, mock_update):
        mock_app = _make_mock_app()
        mock_get.return_value = mock_app
        mock_update.return_value = mock_app

        app, mock_db = _create_test_app()
        mock_db.commit = AsyncMock()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.post(
                f"/self-service/applications/{mock_app.id}/rotate-key/publishable",
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["key"].startswith("spaps_pub_")
        assert data["key_type"] == "publishable"
        assert "warning" in data

    @patch(f"{_REPO_MODULE}.apps_repo.update_application", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.apps_repo.get_application_by_id", new_callable=AsyncMock)
    async def test_rotate_secret_key(self, mock_get, mock_update):
        mock_app = _make_mock_app()
        mock_get.return_value = mock_app
        mock_update.return_value = mock_app

        app, mock_db = _create_test_app()
        mock_db.commit = AsyncMock()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.post(
                f"/self-service/applications/{mock_app.id}/rotate-key/secret",
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["key"].startswith("spaps_sec_")
        assert data["key_type"] == "secret"

    async def test_invalid_key_type_returns_400(self):
        app, _ = _create_test_app()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.post(
                f"/self-service/applications/{uuid4()}/rotate-key/invalid",
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 400
        data = resp.json()
        assert data["error"]["code"] == "INVALID_KEY_TYPE"

    @patch(f"{_REPO_MODULE}.apps_repo.get_application_by_id", new_callable=AsyncMock)
    async def test_not_found(self, mock_get):
        mock_get.return_value = None

        app, _ = _create_test_app()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.post(
                f"/self-service/applications/{uuid4()}/rotate-key/publishable",
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Tests: DELETE /self-service/applications/{app_id}
# ---------------------------------------------------------------------------


class TestDeleteApplication:
    @patch(f"{_REPO_MODULE}.apps_repo.delete_application", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.apps_repo.get_application_by_id", new_callable=AsyncMock)
    async def test_success(self, mock_get, mock_delete):
        mock_app = _make_mock_app(name="Doomed App")
        mock_get.return_value = mock_app
        mock_delete.return_value = True

        app, mock_db = _create_test_app()
        mock_db.commit = AsyncMock()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.delete(
                f"/self-service/applications/{mock_app.id}",
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["message"] == "Application deleted successfully"
        assert data["application_name"] == "Doomed App"

    @patch(f"{_REPO_MODULE}.apps_repo.get_application_by_id", new_callable=AsyncMock)
    async def test_not_found(self, mock_get):
        mock_get.return_value = None

        app, _ = _create_test_app()
        token = _get_valid_token()

        async with await _client(app) as c:
            resp = await c.delete(
                f"/self-service/applications/{uuid4()}",
                headers={"Authorization": f"Bearer {token}"},
            )

        assert resp.status_code == 404
        data = resp.json()
        assert data["error"]["code"] == "NOT_FOUND"


# ---------------------------------------------------------------------------
# Tests: Service layer (token management)
# ---------------------------------------------------------------------------


class TestServiceTokenManagement:
    def test_generate_token_format(self):
        token = ss_service.generate_token()
        assert token.startswith("ss_")
        assert len(token) == 67

    def test_validate_stored_token(self):
        token = ss_service.generate_token()
        ss_service.store_token(token)
        assert ss_service.validate_token(token) is True

    def test_validate_unstored_token(self):
        token = ss_service.generate_token()
        # Do not store
        assert ss_service.validate_token(token) is False

    def test_validate_none_token(self):
        assert ss_service.validate_token(None) is False

    def test_validate_empty_token(self):
        assert ss_service.validate_token("") is False

    def test_validate_wrong_prefix(self):
        assert ss_service.validate_token("xx_" + "a" * 64) is False

    def test_validate_wrong_length(self):
        assert ss_service.validate_token("ss_short") is False

    def test_expired_token_invalid(self):
        token = ss_service.generate_token()
        ss_service._valid_tokens.add(token)
        ss_service._token_timers[token] = 0  # epoch = expired
        assert ss_service.validate_token(token) is False
        # Expired token should be cleaned up
        assert token not in ss_service._valid_tokens
        assert token not in ss_service._token_timers

    def test_rate_limit_allows_under_max(self):
        assert ss_service.check_rate_limit("1.2.3.4") is True
        for _ in range(4):
            ss_service.record_attempt("1.2.3.4")
        assert ss_service.check_rate_limit("1.2.3.4") is True

    def test_rate_limit_blocks_at_max(self):
        for _ in range(5):
            ss_service.record_attempt("1.2.3.4")
        assert ss_service.check_rate_limit("1.2.3.4") is False

    def test_reset_rate_limit(self):
        for _ in range(5):
            ss_service.record_attempt("1.2.3.4")
        assert ss_service.check_rate_limit("1.2.3.4") is False
        ss_service.reset_rate_limit("1.2.3.4")
        assert ss_service.check_rate_limit("1.2.3.4") is True


# ---------------------------------------------------------------------------
# Tests: TM-008 Network Boundary Enforcement
# ---------------------------------------------------------------------------


class TestNetworkBoundary:
    """TM-008: Self-service network boundary enforcement."""

    async def test_empty_allowlist_allows_all_ips(self):
        """When self_service_allowed_ips is empty, all IPs are allowed (backward compatible)."""
        app, _ = _create_test_app(password="test-password")
        app.state.settings.self_service_allowed_ips = []

        async with await _client(app) as c:
            resp = await c.post(
                "/self-service/auth",
                json={"password": "test-password"},
                headers={"X-Forwarded-For": "203.0.113.42"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["token"].startswith("ss_")

    async def test_allowlisted_ip_can_access(self):
        """When client IP is in allowlist, request proceeds to auth."""
        app, _ = _create_test_app(password="test-password")
        app.state.settings.self_service_allowed_ips = ["203.0.113.42", "198.51.100.0"]

        async with await _client(app, client_host="203.0.113.42") as c:
            resp = await c.post(
                "/self-service/auth",
                json={"password": "test-password"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["token"].startswith("ss_")

    async def test_allowlisted_cidr_can_access(self):
        """CIDR allowlist entries should permit matching client IPs."""
        app, _ = _create_test_app(password="test-password")
        app.state.settings.self_service_allowed_ips = ["203.0.113.0/24"]

        async with await _client(app, client_host="203.0.113.42") as c:
            resp = await c.post(
                "/self-service/auth",
                json={"password": "test-password"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["token"].startswith("ss_")

    async def test_non_matching_cidr_denied(self):
        """Requests outside configured CIDR ranges should be denied."""
        app, _ = _create_test_app(password="test-password")
        app.state.settings.self_service_allowed_ips = ["203.0.113.0/24"]

        async with await _client(app, client_host="198.51.100.10") as c:
            resp = await c.post(
                "/self-service/auth",
                json={"password": "test-password"},
            )

        assert resp.status_code == 403
        data = resp.json()
        assert data["error"]["code"] == "SELF_SERVICE_NETWORK_RESTRICTED"

    async def test_non_allowlisted_ip_denied(self):
        """When client IP is NOT in allowlist, request is denied with 403."""
        app, _ = _create_test_app(password="test-password")
        app.state.settings.self_service_allowed_ips = ["203.0.113.42"]

        async with await _client(app, client_host="198.51.100.99") as c:
            resp = await c.post(
                "/self-service/auth",
                json={"password": "test-password"},
            )

        assert resp.status_code == 403
        data = resp.json()
        assert data["error"]["code"] == "SELF_SERVICE_NETWORK_RESTRICTED"

    async def test_spoofed_forwarded_for_denied_without_trusted_proxy(self):
        """Untrusted peers must not influence client IP via X-Forwarded-For."""
        app, _ = _create_test_app(password="test-password")
        app.state.settings.self_service_allowed_ips = ["203.0.113.42"]

        async with await _client(app, client_host="198.51.100.99") as c:
            resp = await c.post(
                "/self-service/auth",
                json={"password": "test-password"},
                headers={"X-Forwarded-For": "203.0.113.42, 198.51.100.99"},
            )

        assert resp.status_code == 403
        data = resp.json()
        assert data["error"]["code"] == "SELF_SERVICE_NETWORK_RESTRICTED"

    async def test_trusted_proxy_can_forward_allowlisted_client_ip(self):
        """Trusted proxy peers may supply the client IP chain."""
        app, _ = _create_test_app(password="test-password")
        app.state.settings.self_service_allowed_ips = ["203.0.113.42"]
        app.state.settings.trusted_proxy_cidrs = ["10.0.0.0/8"]

        async with await _client(app, client_host="10.0.0.5") as c:
            resp = await c.post(
                "/self-service/auth",
                json={"password": "test-password"},
                headers={"X-Forwarded-For": "203.0.113.42"},
            )

        assert resp.status_code == 200

    async def test_network_boundary_applies_to_all_endpoints(self):
        """Network boundary check applies to all self-service endpoints."""
        app, _ = _create_test_app(password="test-password")
        app.state.settings.self_service_allowed_ips = ["203.0.113.42"]
        token = _get_valid_token()

        with patch(f"{_REPO_MODULE}.apps_repo.list_applications", new_callable=AsyncMock) as mock_list:
            mock_list.return_value = []

            # Allowlisted IP can access
            async with await _client(app, client_host="203.0.113.42") as c:
                resp = await c.get(
                    "/self-service/applications",
                    headers={
                        "Authorization": f"Bearer {token}",
                    },
                )
            assert resp.status_code == 200

            # Non-allowlisted IP is denied
            async with await _client(app, client_host="198.51.100.99") as c:
                resp = await c.get(
                    "/self-service/applications",
                    headers={
                        "Authorization": f"Bearer {token}",
                    },
                )
            assert resp.status_code == 403
            data = resp.json()
            assert data["error"]["code"] == "SELF_SERVICE_NETWORK_RESTRICTED"
