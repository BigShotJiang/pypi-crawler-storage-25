"""Unit tests for support_telemetry_platform service logic."""

from __future__ import annotations

from datetime import UTC, datetime
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.support_telemetry_platform.errors import (
    SupportTelemetryBackpressureError,
    SupportTelemetryInvalidTransitionError,
    SupportTelemetryPayloadTooLargeError,
    ValidationFailedError,
)
from spaps_server_quickstart.domains.support_telemetry_platform.service import (
    UNSET,
    ingest_event,
    update_case_lifecycle,
)

_REPO = "spaps_server_quickstart.domains.support_telemetry_platform.service.repo"


def _make_case(**overrides) -> SimpleNamespace:
    now = datetime.now(UTC)
    return SimpleNamespace(
        id=overrides.get("id", uuid4()),
        application_id=overrides.get("application_id", uuid4()),
        external_case_ref=overrides.get("external_case_ref"),
        title=overrides.get("title", "Case title"),
        status=overrides.get("status", "open"),
        priority=overrides.get("priority", "normal"),
        highest_severity=overrides.get("highest_severity", "info"),
        assigned_to_user_id=overrides.get("assigned_to_user_id"),
        first_event_at=overrides.get("first_event_at", now),
        last_event_at=overrides.get("last_event_at", now),
        resolved_at=overrides.get("resolved_at"),
        created_at=overrides.get("created_at", now),
        updated_at=overrides.get("updated_at", now),
    )


def _make_event(**overrides) -> SimpleNamespace:
    now = datetime.now(UTC)
    return SimpleNamespace(
        id=overrides.get("id", uuid4()),
        case_id=overrides.get("case_id", uuid4()),
        application_id=overrides.get("application_id", uuid4()),
        event_key=overrides.get("event_key", "event_key_1"),
        source_channel=overrides.get("source_channel", "api"),
        event_type=overrides.get("event_type", "issue_reported"),
        severity=overrides.get("severity", "warning"),
        actor_type=overrides.get("actor_type", "service"),
        actor_external_id=overrides.get("actor_external_id"),
        correlation_id=overrides.get("correlation_id"),
        payload=overrides.get("payload", {}),
        redacted_keys=overrides.get("redacted_keys", []),
        occurred_at=overrides.get("occurred_at", now),
        received_at=overrides.get("received_at", now),
        ingested_by_user_id=overrides.get("ingested_by_user_id"),
    )


class TestIngestEvent:
    @patch(_REPO)
    async def test_backpressure_guard_raises(self, mock_repo):
        settings = SimpleNamespace(support_telemetry_max_inflight_ingest=1)
        with patch(
            "spaps_server_quickstart.domains.support_telemetry_platform.service.get_spaps_settings",
        ) as mock_global_settings:
            with patch(
                "spaps_server_quickstart.domains.support_telemetry_platform.service._SUPPORT_TELEMETRY_INGEST_INFLIGHT",
                1,
            ):
                with pytest.raises(SupportTelemetryBackpressureError):
                    await ingest_event(
                        AsyncMock(),
                        application_id=uuid4(),
                        event_key="evt_backpressure",
                        occurred_at=datetime.now(UTC),
                        source_channel="api",
                        event_type="issue_reported",
                        severity="warning",
                        actor_type="service",
                        actor_id=None,
                        correlation_id=None,
                        external_case_ref=None,
                        title="Backpressure check",
                        payload={"foo": "bar"},
                        ingested_by_user_id=None,
                        settings=settings,
                    )

            mock_global_settings.assert_not_called()

        mock_repo.get_event_by_key.assert_not_called()

    @patch(_REPO)
    async def test_duplicate_event_key_returns_idempotent_result(self, mock_repo):
        application_id = uuid4()
        case = _make_case(id=uuid4(), application_id=application_id, status="open")
        event = _make_event(
            id=uuid4(),
            case_id=case.id,
            application_id=application_id,
            event_key="dup_event",
        )

        mock_repo.get_event_by_key = AsyncMock(return_value=event)
        mock_repo.get_case_by_id = AsyncMock(return_value=case)
        mock_repo.create_event = AsyncMock()
        mock_repo.create_case = AsyncMock()

        result = await ingest_event(
            AsyncMock(),
            application_id=application_id,
            event_key="dup_event",
            occurred_at=datetime.now(UTC),
            source_channel="api",
            event_type="issue_reported",
            severity="warning",
            actor_type="service",
            actor_id=None,
            correlation_id=None,
            external_case_ref=None,
            title="Something happened",
            payload={"foo": "bar"},
            ingested_by_user_id=None,
        )

        assert result["deduplicated"] is True
        assert result["created_case"] is False
        assert result["event_id"] == str(event.id)
        assert result["case_id"] == str(case.id)
        mock_repo.create_event.assert_not_called()
        mock_repo.create_case.assert_not_called()

    @patch(_REPO)
    async def test_external_case_ref_has_precedence_over_correlation(self, mock_repo):
        application_id = uuid4()
        matched_case = _make_case(
            id=uuid4(),
            application_id=application_id,
            external_case_ref="thread_123",
            status="open",
        )
        created_event = _make_event(
            id=uuid4(),
            case_id=matched_case.id,
            application_id=application_id,
            event_key="event_2",
        )

        mock_repo.get_event_by_key = AsyncMock(return_value=None)
        mock_repo.get_case_by_external_ref = AsyncMock(return_value=matched_case)
        mock_repo.find_open_case_by_correlation_id = AsyncMock(return_value=_make_case())
        mock_repo.create_case = AsyncMock()
        mock_repo.create_event = AsyncMock(return_value=created_event)
        mock_repo.update_case_summary = AsyncMock(return_value=matched_case)

        result = await ingest_event(
            AsyncMock(),
            application_id=application_id,
            event_key="event_2",
            occurred_at=datetime.now(UTC),
            source_channel="support_thread",
            event_type="message_received",
            severity="error",
            actor_type="service",
            actor_id="svc_1",
            correlation_id="corr_1",
            external_case_ref="thread_123",
            title="Cannot reopen thread",
            payload={"token": "raw-secret"},
            ingested_by_user_id=None,
        )

        assert result["created_case"] is False
        assert result["deduplicated"] is False
        mock_repo.find_open_case_by_correlation_id.assert_not_called()
        mock_repo.create_case.assert_not_called()
        create_kwargs = mock_repo.create_event.await_args.kwargs
        assert create_kwargs["payload"]["token"] == "[REDACTED]"
        assert create_kwargs["redacted_keys"] == ["token"]

    @patch(_REPO)
    async def test_ambiguous_correlation_match_emits_audit_event(self, mock_repo):
        application_id = uuid4()
        matched_case = _make_case(
            id=uuid4(),
            application_id=application_id,
            status="open",
        )
        created_event = _make_event(
            id=uuid4(),
            case_id=matched_case.id,
            application_id=application_id,
            event_key="event_primary",
        )
        audit_event = _make_event(
            id=uuid4(),
            case_id=matched_case.id,
            application_id=application_id,
            event_key="event_audit",
            event_type="correlation_match_ambiguous",
            severity="info",
        )

        mock_repo.get_event_by_key = AsyncMock(return_value=None)
        mock_repo.get_case_by_external_ref = AsyncMock(return_value=None)
        mock_repo.find_open_case_by_correlation_id = AsyncMock(return_value=matched_case)
        mock_repo.count_open_cases_by_correlation_id = AsyncMock(return_value=2)
        mock_repo.create_case = AsyncMock()
        mock_repo.create_event = AsyncMock(side_effect=[created_event, audit_event])
        mock_repo.update_case_summary = AsyncMock(return_value=matched_case)

        result = await ingest_event(
            AsyncMock(),
            application_id=application_id,
            event_key="event_primary",
            occurred_at=datetime.now(UTC),
            source_channel="api",
            event_type="issue_reported",
            severity="warning",
            actor_type="service",
            actor_id="svc_1",
            correlation_id="corr_ambiguous",
            external_case_ref=None,
            title="Ambiguous correlation",
            payload={"ok": True},
            ingested_by_user_id=None,
        )

        assert result["created_case"] is False
        assert result["deduplicated"] is False
        assert mock_repo.create_event.await_count == 2
        audit_kwargs = mock_repo.create_event.await_args_list[1].kwargs
        assert audit_kwargs["event_type"] == "correlation_match_ambiguous"
        assert audit_kwargs["correlation_id"] == "corr_ambiguous"
        assert audit_kwargs["payload"]["matched_open_case_count"] == 2
        assert audit_kwargs["payload"]["selected_case_id"] == str(matched_case.id)

    @patch(_REPO)
    async def test_creates_case_when_no_match_exists(self, mock_repo):
        application_id = uuid4()
        created_case = _make_case(id=uuid4(), application_id=application_id, status="open")
        created_event = _make_event(id=uuid4(), case_id=created_case.id, application_id=application_id)

        mock_repo.get_event_by_key = AsyncMock(return_value=None)
        mock_repo.get_case_by_external_ref = AsyncMock(return_value=None)
        mock_repo.find_open_case_by_correlation_id = AsyncMock(return_value=None)
        mock_repo.create_case = AsyncMock(return_value=created_case)
        mock_repo.create_event = AsyncMock(return_value=created_event)
        mock_repo.update_case_summary = AsyncMock(return_value=created_case)

        result = await ingest_event(
            AsyncMock(),
            application_id=application_id,
            event_key="event_3",
            occurred_at=datetime.now(UTC),
            source_channel="issue_log",
            event_type="issue_reported",
            severity="warning",
            actor_type="practitioner",
            actor_id="user_1",
            correlation_id="corr_9",
            external_case_ref="case_ref_9",
            title="Issue report",
            payload={"nested": {"password": "abc"}},
            ingested_by_user_id=None,
        )

        assert result["created_case"] is True
        assert result["deduplicated"] is False
        mock_repo.create_case.assert_called_once()

    async def test_raises_when_payload_exceeds_64kb(self):
        oversized = {"blob": "x" * (65 * 1024)}

        with pytest.raises(SupportTelemetryPayloadTooLargeError):
            await ingest_event(
                AsyncMock(),
                application_id=uuid4(),
                event_key="event_big",
                occurred_at=datetime.now(UTC),
                source_channel="api",
                event_type="issue_reported",
                severity="warning",
                actor_type="service",
                actor_id=None,
                correlation_id=None,
                external_case_ref=None,
                title="Large payload",
                payload=oversized,
                ingested_by_user_id=None,
            )


class TestUpdateCaseLifecycle:
    @patch(_REPO)
    async def test_invalid_transition_raises(self, mock_repo):
        case = _make_case(status="ignored")
        mock_repo.get_case_by_id = AsyncMock(return_value=case)

        with pytest.raises(SupportTelemetryInvalidTransitionError):
            await update_case_lifecycle(
                AsyncMock(),
            case_id=case.id,
            application_id=None,
            status="resolved",
            priority=UNSET,
            assigned_to_user_id=UNSET,
            resolution_note="done",
            actor_user_id=uuid4(),
        )

    @patch(_REPO)
    async def test_terminal_states_require_resolution_note(self, mock_repo):
        case = _make_case(status="open")
        mock_repo.get_case_by_id = AsyncMock(return_value=case)

        with pytest.raises(ValidationFailedError):
            await update_case_lifecycle(
                AsyncMock(),
            case_id=case.id,
            application_id=None,
            status="resolved",
            priority=UNSET,
            assigned_to_user_id=UNSET,
            resolution_note=UNSET,
            actor_user_id=uuid4(),
        )

    @patch(_REPO)
    async def test_reopen_clears_resolved_at(self, mock_repo):
        now = datetime.now(UTC)
        case = _make_case(status="resolved", resolved_at=now)
        updated = _make_case(id=case.id, status="open", resolved_at=None)

        mock_repo.get_case_by_id = AsyncMock(return_value=case)
        mock_repo.update_case = AsyncMock(return_value=updated)
        mock_repo.create_event = AsyncMock(return_value=_make_event(case_id=case.id))
        mock_repo.update_case_summary = AsyncMock(return_value=updated)

        result = await update_case_lifecycle(
            AsyncMock(),
            case_id=case.id,
            application_id=None,
            status="open",
            priority=UNSET,
            assigned_to_user_id=UNSET,
            resolution_note=UNSET,
            actor_user_id=uuid4(),
        )

        kwargs = mock_repo.update_case.await_args.kwargs
        assert kwargs["resolved_at"] is None
        assert result["case"]["status"] == "open"
