"""Route tests for support_telemetry_platform endpoints."""

from __future__ import annotations

from datetime import UTC, datetime
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from spaps_server_quickstart.domains.support_telemetry_platform.errors import SupportTelemetryBackpressureError
from spaps_server_quickstart.domains.support_telemetry_platform.router import router
from spaps_server_quickstart.middleware.error_handler import install_error_handlers

_SVC = "spaps_server_quickstart.domains.support_telemetry_platform.router.service"

FAKE_APP_ID = str(uuid4())
FAKE_CASE_ID = str(uuid4())


def _make_app() -> FastAPI:
    app = FastAPI()
    app.state.settings = SimpleNamespace(support_telemetry_max_inflight_ingest=7)
    install_error_handlers(app)
    app.include_router(router, prefix="/api")
    return app


def _make_application(app_id: str = FAKE_APP_ID) -> SimpleNamespace:
    return SimpleNamespace(id=app_id)


def _make_user(*, super_admin: bool, app_id: str = FAKE_APP_ID) -> SimpleNamespace:
    roles = ["super_admin"] if super_admin else ["user"]
    return SimpleNamespace(
        id=str(uuid4()),
        application_id=app_id,
        is_super_admin=super_admin,
        roles=roles,
        is_admin=super_admin,
    )


@pytest.fixture
def app() -> FastAPI:
    return _make_app()


@pytest.fixture
def client(app: FastAPI) -> TestClient:
    return TestClient(app, raise_server_exceptions=False)


class TestIngestRoute:
    @patch(_SVC)
    def test_trusted_service_ingest_returns_201(self, mock_svc, app: FastAPI, client: TestClient):
        mock_svc.ingest_event = AsyncMock(return_value={
            "event_id": str(uuid4()),
            "case_id": FAKE_CASE_ID,
            "created_case": True,
            "deduplicated": False,
            "case_status": "open",
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: None

        response = client.post("/api/v1/support-telemetry/events", json={
            "application_id": FAKE_APP_ID,
            "event_key": "evt_1",
            "occurred_at": datetime.now(UTC).isoformat(),
            "source_channel": "api",
            "event_type": "issue_reported",
            "severity": "warning",
            "actor": {"type": "service", "id": None},
            "payload": {"k": "v"},
        })

        assert response.status_code == 201
        assert mock_svc.ingest_event.await_args.kwargs["application_id"] is not None
        assert mock_svc.ingest_event.await_args.kwargs["settings"] is app.state.settings

    @patch(_SVC)
    def test_ingest_backpressure_returns_429(self, mock_svc, app: FastAPI, client: TestClient):
        mock_svc.ingest_event = AsyncMock(side_effect=SupportTelemetryBackpressureError())

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: None

        response = client.post("/api/v1/support-telemetry/events", json={
            "application_id": FAKE_APP_ID,
            "event_key": "evt_backpressure",
            "occurred_at": datetime.now(UTC).isoformat(),
            "source_channel": "api",
            "event_type": "issue_reported",
            "severity": "warning",
            "actor": {"type": "service", "id": None},
            "payload": {"k": "v"},
        })

        assert response.status_code == 429
        assert response.json()["error"]["code"] == "SUPPORT_TELEMETRY_BACKPRESSURE"

    @patch(_SVC)
    def test_non_super_admin_user_cannot_ingest(self, mock_svc, app: FastAPI, client: TestClient):
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user(super_admin=False)

        response = client.post("/api/v1/support-telemetry/events", json={
            "application_id": FAKE_APP_ID,
            "event_key": "evt_2",
            "occurred_at": datetime.now(UTC).isoformat(),
            "source_channel": "api",
            "event_type": "issue_reported",
            "severity": "warning",
            "actor": {"type": "service", "id": None},
            "payload": {"k": "v"},
        })

        assert response.status_code == 403
        assert response.json()["error"]["code"] == "NOT_AUTHORIZED"
        mock_svc.ingest_event.assert_not_called()


class TestListCasesRoute:
    @patch(_SVC)
    def test_trusted_service_cannot_query_other_application(
        self,
        mock_svc,
        app: FastAPI,
        client: TestClient,
    ):
        other_app = str(uuid4())
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: None

        response = client.get(f"/api/v1/support-telemetry/cases?application_id={other_app}")

        assert response.status_code == 403
        assert response.json()["error"]["code"] == "NOT_AUTHORIZED"
        mock_svc.list_cases.assert_not_called()

    @patch(_SVC)
    def test_super_admin_can_query_other_application(
        self,
        mock_svc,
        app: FastAPI,
        client: TestClient,
    ):
        other_app = str(uuid4())
        mock_svc.list_cases = AsyncMock(return_value={"items": [], "total": 0})

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user(super_admin=True)

        response = client.get(f"/api/v1/support-telemetry/cases?application_id={other_app}")

        assert response.status_code == 200
        assert mock_svc.list_cases.await_args.kwargs["application_id"] is not None


class TestByExternalRoute:
    @patch(_SVC)
    def test_super_admin_requires_application_id_for_by_external(
        self,
        mock_svc,
        app: FastAPI,
        client: TestClient,
    ):
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user(super_admin=True)

        response = client.get("/api/v1/support-telemetry/cases/by-external/thread_123")

        assert response.status_code == 400
        assert response.json()["error"]["code"] == "VALIDATION_FAILED"
        mock_svc.get_case_by_external_ref.assert_not_called()


class TestPatchRoute:
    @patch(_SVC)
    def test_patch_case_lifecycle_success(self, mock_svc, app: FastAPI, client: TestClient):
        mock_svc.update_case_lifecycle = AsyncMock(return_value={
            "case": {
                "id": FAKE_CASE_ID,
                "status": "resolved",
                "priority": "high",
                "assigned_to_user_id": str(uuid4()),
                "resolved_at": datetime.now(UTC).isoformat(),
                "updated_at": datetime.now(UTC).isoformat(),
            }
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            require_super_admin_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[require_super_admin_user] = lambda: _make_user(super_admin=True)

        response = client.patch(f"/api/v1/support-telemetry/cases/{FAKE_CASE_ID}", json={
            "status": "resolved",
            "priority": "high",
            "assigned_to_user_id": str(uuid4()),
            "resolution_note": "resolved in triage",
        })

        assert response.status_code == 200
        mock_svc.update_case_lifecycle.assert_awaited_once()
