"""Unit tests for the auth domain service layer.

The auth service orchestrates all authentication flows by coordinating
repositories, JWT services, password services, nonce services, blacklist
services, admin detection, and wallet signature verification.  Every
external dependency is mocked so tests are fast and deterministic.
"""

from __future__ import annotations

import unittest.mock
from unittest.mock import AsyncMock, MagicMock, patch
from urllib.parse import parse_qs, urlparse
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.auth import service
from spaps_server_quickstart.domains.errors import (
    EmailAlreadyExistsError,
    InvalidCredentialsError,
    InvalidRefreshTokenError,
    InvalidSignatureError,
    InvalidTokenError,
    NotFoundError,
    WeakPasswordError,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SERVICE_MODULE = "spaps_server_quickstart.domains.auth.service"
_REPO_MODULE = f"{_SERVICE_MODULE}.repo"
_AFFILIATE_ATTRIBUTION = (
    "spaps_server_quickstart.domains.affiliate_referrals.service.attribute_referral"
)


def _make_settings(**overrides):
    """Build a mock SpapsSettings."""
    settings = MagicMock()
    settings.jwt_secret = overrides.get("jwt_secret", "test-jwt-secret")
    settings.refresh_token_secret = overrides.get("refresh_token_secret", "test-refresh-secret")
    settings.jwt_expires_in = overrides.get("jwt_expires_in", "1h")
    settings.jwt_refresh_expires_in = overrides.get("jwt_refresh_expires_in", "365d")
    settings.env = overrides.get("env", "test")
    settings.auth_base_url = overrides.get("auth_base_url", "https://fallback.example.com")
    settings.is_spaps_local_mode = overrides.get("is_spaps_local_mode", False)
    return settings


def _make_user(**overrides):
    """Build a mock User object."""
    user = MagicMock()
    user.id = overrides.get("id", uuid4())
    user.email = overrides.get("email", "alice@example.com")
    user.username = overrides.get("username", "alice")
    user.password_hash = overrides.get("password_hash", "$2b$12$hashedvalue")
    user.tier = overrides.get("tier", "basic")
    user.metadata_ = overrides.get("metadata_", None)
    user.phone_number = overrides.get("phone_number", None)
    user.last_sign_in_at = None
    user.email_confirmed_at = overrides.get("email_confirmed_at", None)
    user.confirmed_at = overrides.get("confirmed_at", None)
    return user


def _make_wallet(**overrides):
    """Build a mock UserWallet object."""
    wallet = MagicMock()
    wallet.id = overrides.get("id", uuid4())
    wallet.user_id = overrides.get("user_id", uuid4())
    wallet.wallet_address = overrides.get(
        "wallet_address", "HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy"
    )
    wallet.chain_type = overrides.get("chain_type", "solana")
    wallet.is_primary = overrides.get("is_primary", True)
    return wallet


def _make_token_pair():
    """Build a mock TokenPair."""
    tp = MagicMock()
    tp.access_token = "eyJ.access.token"
    tp.refresh_token = "eyJ.refresh.token"
    tp.expires_in = 3600
    return tp


def _make_refresh_payload(**overrides):
    """Build a mock RefreshTokenPayload."""
    payload = MagicMock()
    payload.sub = overrides.get("sub", str(uuid4()))
    payload.app_id = overrides.get("app_id", "test-app-id")
    payload.jti = overrides.get("jti", str(uuid4()))
    payload.email = overrides.get("email", "alice@example.com")
    payload.roles = overrides.get("roles", ["user"])
    payload.isAdmin = overrides.get("isAdmin", False)
    return payload


def _make_db():
    """Build a mock AsyncSession."""
    db = AsyncMock()
    db.add = MagicMock()
    db.flush = AsyncMock()
    return db


# ---------------------------------------------------------------------------
# Tests: login
# ---------------------------------------------------------------------------


class TestLogin:
    @patch(f"{_REPO_MODULE}.store_refresh_token", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.generate_token_pair")
    @patch(f"{_SERVICE_MODULE}.password_service")
    @patch(f"{_REPO_MODULE}.find_user_for_login", new_callable=AsyncMock)
    async def test_happy_path(
        self, mock_find_user, mock_pw_svc, mock_gen_tokens, mock_store_rt
    ):
        user = _make_user()
        mock_find_user.return_value = user
        mock_pw_svc.verify_password.return_value = True
        mock_pw_svc.verify_password_async = AsyncMock(return_value=True)
        mock_gen_tokens.return_value = _make_token_pair()
        mock_store_rt.return_value = MagicMock()

        db = _make_db()
        settings = _make_settings()

        result = await service.login(
            db, settings, email="alice@example.com", password="Passw0rd!"
        )

        assert result["access_token"] == "eyJ.access.token"
        assert result["refresh_token"] == "eyJ.refresh.token"
        assert result["user"]["id"] == str(user.id)
        mock_find_user.assert_called_once_with(db, "alice@example.com")
        mock_pw_svc.verify_password_async.assert_called_once_with("Passw0rd!", user.password_hash)

    @patch(f"{_SERVICE_MODULE}.password_service")
    @patch(f"{_REPO_MODULE}.find_user_for_login", new_callable=AsyncMock)
    async def test_wrong_password_raises_invalid_credentials(
        self, mock_find_user, mock_pw_svc
    ):
        user = _make_user()
        mock_find_user.return_value = user
        mock_pw_svc.verify_password.return_value = False
        mock_pw_svc.verify_password_async = AsyncMock(return_value=False)

        db = _make_db()
        settings = _make_settings()

        with pytest.raises(InvalidCredentialsError):
            await service.login(
                db, settings, email="alice@example.com", password="wrong"
            )

    @patch(f"{_REPO_MODULE}.find_user_for_login", new_callable=AsyncMock)
    async def test_user_not_found_raises_invalid_credentials(self, mock_find_user):
        mock_find_user.return_value = None

        db = _make_db()
        settings = _make_settings()

        with pytest.raises(InvalidCredentialsError):
            await service.login(
                db, settings, email="nobody@example.com", password="Passw0rd!"
            )

    @patch(f"{_REPO_MODULE}.find_user_for_login", new_callable=AsyncMock)
    async def test_no_password_hash_raises_invalid_credentials(self, mock_find_user):
        user = _make_user(password_hash=None)
        mock_find_user.return_value = user

        db = _make_db()
        settings = _make_settings()

        with pytest.raises(InvalidCredentialsError):
            await service.login(
                db, settings, email="alice@example.com", password="Passw0rd!"
            )

    @patch(f"{_REPO_MODULE}.store_refresh_token", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.generate_token_pair")
    @patch(f"{_SERVICE_MODULE}.password_service")
    @patch(f"{_REPO_MODULE}.find_user_for_login", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}._resolve_roles_and_permissions")
    async def test_admin_roles_not_granted_when_email_unconfirmed(
        self,
        mock_resolve_roles,
        mock_find_user,
        mock_pw_svc,
        mock_gen_tokens,
        mock_store_rt,
    ):
        """Even if the email matches an admin list, require email confirmation first.

        TM-001: Prevent privilege escalation where an attacker registers an
        operator/admin email address but has not verified control of that email.
        """
        # Use a known admin email from domains/sessions/admin_detection.py to make
        # the intent of the test obvious.
        user = _make_user(email="buildooor@gmail.com", email_confirmed_at=None)
        mock_find_user.return_value = user
        mock_pw_svc.verify_password.return_value = True
        mock_pw_svc.verify_password_async = AsyncMock(return_value=True)
        mock_gen_tokens.return_value = _make_token_pair()
        mock_store_rt.return_value = MagicMock()

        # This should not be called for unconfirmed users; if it is, the test fails.
        mock_resolve_roles.side_effect = AssertionError(
            "_resolve_roles_and_permissions should not run for unconfirmed users"
        )

        db = _make_db()
        settings = _make_settings()

        result = await service.login(db, settings, email=user.email, password="Passw0rd!")

        assert result["user"]["roles"] == ["user"]
        assert result["user"]["permissions"] == ["view_products"]
        assert result["user"]["isAdmin"] is False

        # Ensure JWT claims are minted without admin privileges.
        call_kwargs = mock_gen_tokens.call_args.kwargs
        assert call_kwargs["roles"] == ["user"]
        assert call_kwargs["permissions"] == ["view_products"]
        assert call_kwargs["is_admin"] is False
        assert call_kwargs["is_super_admin"] is False


# ---------------------------------------------------------------------------
# Tests: register
# ---------------------------------------------------------------------------


class TestRegister:
    @patch(f"{_REPO_MODULE}.store_refresh_token", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.generate_token_pair")
    @patch(f"{_SERVICE_MODULE}.password_service")
    async def test_happy_path_auto_confirm(
        self, mock_pw_svc, mock_gen_tokens, mock_store_rt
    ):
        user = _make_user()
        mock_pw_svc.validate_password_strength.return_value = None
        mock_pw_svc.hash_password.return_value = "$2b$12$newhash"
        mock_pw_svc.hash_password_async = AsyncMock(return_value="$2b$12$newhash")
        mock_gen_tokens.return_value = _make_token_pair()
        mock_store_rt.return_value = MagicMock()

        db = _make_db()
        settings = _make_settings(env="test")

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_email",
            new_callable=AsyncMock,
            return_value=None,
        ), patch(
            "spaps_server_quickstart.domains.users.repository.create_user",
            new_callable=AsyncMock,
            return_value=user,
        ):
            result = await service.register(
                db, settings,
                email="alice@example.com",
                password="Passw0rd!",
                username="alice",
            )

        assert result["tokens"]["access_token"] == "eyJ.access.token"
        assert result["email_confirmed"] is True
        assert result["user"]["email"] == "alice@example.com"

    @patch(f"{_SERVICE_MODULE}.password_service")
    async def test_duplicate_email_raises_conflict(self, mock_pw_svc):
        existing_user = _make_user()
        db = _make_db()
        settings = _make_settings()

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_email",
            new_callable=AsyncMock,
            return_value=existing_user,
        ):
            with pytest.raises(EmailAlreadyExistsError):
                await service.register(
                    db, settings,
                    email="alice@example.com",
                    password="Passw0rd!",
                )

    async def test_weak_password_raises_validation_error(self):
        db = _make_db()
        settings = _make_settings()

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_email",
            new_callable=AsyncMock,
            return_value=None,
        ), patch(
            f"{_SERVICE_MODULE}.password_service"
        ) as mock_pw_svc:
            mock_pw_svc.validate_password_strength.side_effect = WeakPasswordError(
                "Password must contain: at least 8 characters"
            )

            with pytest.raises(WeakPasswordError):
                await service.register(
                    db, settings,
                    email="alice@example.com",
                    password="weak",
                )

    @patch(f"{_SERVICE_MODULE}._attribute_signup_referral", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.store_refresh_token", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.generate_token_pair")
    @patch(f"{_SERVICE_MODULE}.password_service")
    async def test_register_attempts_referral_attribution(
        self,
        mock_pw_svc,
        mock_gen_tokens,
        mock_store_rt,
        mock_attribute_referral,
    ):
        user = _make_user()
        mock_pw_svc.validate_password_strength.return_value = None
        mock_pw_svc.hash_password.return_value = "$2b$12$newhash"
        mock_pw_svc.hash_password_async = AsyncMock(return_value="$2b$12$newhash")
        mock_gen_tokens.return_value = _make_token_pair()
        mock_store_rt.return_value = MagicMock()
        mock_attribute_referral.return_value = None

        db = _make_db()
        settings = _make_settings(env="test")
        app_id = str(uuid4())

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_email",
            new_callable=AsyncMock,
            return_value=None,
        ), patch(
            "spaps_server_quickstart.domains.users.repository.create_user",
            new_callable=AsyncMock,
            return_value=user,
        ):
            await service.register(
                db,
                settings,
                email="alice@example.com",
                password="Passw0rd!",
                application_id=app_id,
                referral_click_id=str(uuid4()),
                referral_slug="partner-bot",
            )

        mock_attribute_referral.assert_called_once()
        assert mock_attribute_referral.await_args.kwargs["user_id"] == user.id
        assert mock_attribute_referral.await_args.kwargs["application_id"] == app_id


# ---------------------------------------------------------------------------
# Tests: _attribute_signup_referral
# ---------------------------------------------------------------------------


class TestAttributeSignupReferral:
    @patch(_AFFILIATE_ATTRIBUTION, new_callable=AsyncMock)
    async def test_skips_when_application_id_missing(self, mock_attribute_referral):
        db = _make_db()

        await service._attribute_signup_referral(
            db,
            user_id=uuid4(),
            application_id=None,
            referral_click_id=str(uuid4()),
        )

        mock_attribute_referral.assert_not_called()

    @patch(_AFFILIATE_ATTRIBUTION, new_callable=AsyncMock)
    async def test_skips_when_click_and_slug_missing(self, mock_attribute_referral):
        db = _make_db()

        await service._attribute_signup_referral(
            db,
            user_id=uuid4(),
            application_id=str(uuid4()),
        )

        mock_attribute_referral.assert_not_called()

    @patch(f"{_SERVICE_MODULE}.logger")
    @patch(_AFFILIATE_ATTRIBUTION, new_callable=AsyncMock)
    async def test_invalid_application_uuid_logs_warning(
        self,
        mock_attribute_referral,
        mock_logger,
    ):
        db = _make_db()

        await service._attribute_signup_referral(
            db,
            user_id=uuid4(),
            application_id="not-a-uuid",
            referral_click_id=str(uuid4()),
        )

        mock_attribute_referral.assert_not_called()
        mock_logger.warning.assert_called_once()

    @patch(_AFFILIATE_ATTRIBUTION, new_callable=AsyncMock)
    async def test_valid_payload_calls_affiliate_attribution(
        self,
        mock_attribute_referral,
    ):
        db = _make_db()
        user_id = uuid4()
        app_id = str(uuid4())
        click_id = str(uuid4())

        await service._attribute_signup_referral(
            db,
            user_id=user_id,
            application_id=app_id,
            referral_click_id=click_id,
            referral_slug="partner-bot",
        )

        mock_attribute_referral.assert_awaited_once()
        kwargs = mock_attribute_referral.await_args.kwargs
        assert kwargs["referred_entity_type"] == "user"
        assert kwargs["referred_entity_id"] == user_id
        assert kwargs["click_id"] is not None
        assert str(kwargs["click_id"]) == click_id
        assert kwargs["slug"] == "partner-bot"
        assert str(kwargs["application_id"]) == app_id

    @patch(f"{_SERVICE_MODULE}.logger")
    @patch(_AFFILIATE_ATTRIBUTION, new_callable=AsyncMock)
    async def test_known_attribution_errors_are_swallowed(
        self,
        mock_attribute_referral,
        mock_logger,
    ):
        from spaps_server_quickstart.domains.affiliate_referrals.errors import (
            ClickExpiredError,
        )

        mock_attribute_referral.side_effect = ClickExpiredError()
        db = _make_db()

        await service._attribute_signup_referral(
            db,
            user_id=uuid4(),
            application_id=str(uuid4()),
            referral_click_id=str(uuid4()),
        )

        mock_logger.info.assert_called_once()


# ---------------------------------------------------------------------------
# Tests: refresh_tokens
# ---------------------------------------------------------------------------


class TestRefreshTokens:
    @patch(f"{_REPO_MODULE}.store_refresh_token", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.generate_token_pair")
    @patch(f"{_REPO_MODULE}.revoke_refresh_token", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.find_refresh_token_for_update", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.blacklist_service")
    @patch(f"{_SERVICE_MODULE}.verify_refresh_token")
    async def test_happy_path(
        self,
        mock_verify_rt,
        mock_blacklist,
        mock_find_rt,
        mock_revoke_rt,
        mock_gen_tokens,
        mock_store_rt,
    ):
        payload = _make_refresh_payload()
        mock_verify_rt.return_value = payload
        mock_blacklist.is_blacklisted = AsyncMock(return_value=False)
        mock_find_rt.return_value = MagicMock()  # token found
        mock_revoke_rt.return_value = True
        mock_gen_tokens.return_value = _make_token_pair()
        mock_store_rt.return_value = MagicMock()

        user = _make_user(id=payload.sub)
        db = _make_db()
        settings = _make_settings()

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_id",
            new_callable=AsyncMock,
            return_value=user,
        ):
            result = await service.refresh_tokens(
                db, settings, refresh_token_str="eyJ.refresh.old"
            )

        assert result["access_token"] == "eyJ.access.token"
        assert result["refresh_token"] == "eyJ.refresh.token"
        mock_revoke_rt.assert_called_once()

    @patch(f"{_REPO_MODULE}.store_refresh_token", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.generate_token_pair")
    @patch(f"{_REPO_MODULE}.revoke_refresh_token", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.find_refresh_token_for_update", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.blacklist_service")
    @patch(f"{_SERVICE_MODULE}.verify_refresh_token")
    @patch(f"{_SERVICE_MODULE}._resolve_roles_and_permissions")
    async def test_unconfirmed_email_does_not_gain_admin_on_refresh(
        self,
        mock_resolve_roles,
        mock_verify_rt,
        mock_blacklist,
        mock_find_rt,
        mock_revoke_rt,
        mock_gen_tokens,
        mock_store_rt,
    ):
        payload = _make_refresh_payload(email="buildooor@gmail.com")
        mock_verify_rt.return_value = payload
        mock_blacklist.is_blacklisted = AsyncMock(return_value=False)
        mock_find_rt.return_value = MagicMock()
        mock_revoke_rt.return_value = True
        mock_gen_tokens.return_value = _make_token_pair()
        mock_store_rt.return_value = MagicMock()

        user = _make_user(
            id=payload.sub,
            email="buildooor@gmail.com",
            email_confirmed_at=None,
        )
        db = _make_db()
        settings = _make_settings()

        mock_resolve_roles.side_effect = AssertionError(
            "_resolve_roles_and_permissions should not run for unconfirmed users on refresh"
        )

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_id",
            new_callable=AsyncMock,
            return_value=user,
        ):
            result = await service.refresh_tokens(
                db, settings, refresh_token_str="eyJ.refresh.old"
            )

        assert result["access_token"] == "eyJ.access.token"
        assert result["refresh_token"] == "eyJ.refresh.token"

        call_kwargs = mock_gen_tokens.call_args.kwargs
        assert call_kwargs["roles"] == ["user"]
        assert call_kwargs["permissions"] == ["view_products"]
        assert call_kwargs["is_admin"] is False
        assert call_kwargs["is_super_admin"] is False

    @patch(f"{_REPO_MODULE}.store_refresh_token", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.generate_token_pair")
    @patch(f"{_REPO_MODULE}.revoke_refresh_token", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.find_refresh_token_for_update", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.blacklist_service")
    @patch(f"{_SERVICE_MODULE}.verify_refresh_token")
    async def test_ip_and_ua_tracking_logged(
        self,
        mock_verify_rt,
        mock_blacklist,
        mock_find_rt,
        mock_revoke_rt,
        mock_gen_tokens,
        mock_store_rt,
    ):
        """TM-011: Verify IP and user-agent are logged for anomaly detection."""
        payload = _make_refresh_payload()
        mock_verify_rt.return_value = payload
        mock_blacklist.is_blacklisted = AsyncMock(return_value=False)
        mock_find_rt.return_value = MagicMock()
        mock_revoke_rt.return_value = True
        mock_gen_tokens.return_value = _make_token_pair()
        mock_store_rt.return_value = MagicMock()

        user = _make_user(id=payload.sub)
        db = _make_db()
        settings = _make_settings()

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_id",
            new_callable=AsyncMock,
            return_value=user,
        ), patch(
            f"{_SERVICE_MODULE}.logger"
        ) as mock_logger:
            result = await service.refresh_tokens(
                db,
                settings,
                refresh_token_str="eyJ.refresh.old",
                client_ip="192.168.1.100",
                user_agent="Mozilla/5.0 (Test Browser)",
            )

        assert result["access_token"] == "eyJ.access.token"

        # Verify structured logging includes IP, UA hash, and anomaly status (TM-011)
        mock_logger.info.assert_any_call(
            "Token refresh event: user_id=%s app_id=%s jti=%s client_ip=%s user_agent_hash=%s anomaly=%s",
            payload.sub,
            payload.app_id,
            payload.jti,
            "192.168.1.100",
            unittest.mock.ANY,  # UA hash is computed, just verify it's present
            unittest.mock.ANY,  # anomaly boolean
            extra=unittest.mock.ANY,
        )

    @patch(f"{_SERVICE_MODULE}.verify_refresh_token")
    async def test_expired_token_raises(self, mock_verify_rt):
        mock_verify_rt.side_effect = InvalidRefreshTokenError("Refresh token expired")

        db = _make_db()
        settings = _make_settings()

        with pytest.raises(InvalidRefreshTokenError, match="expired"):
            await service.refresh_tokens(
                db, settings, refresh_token_str="expired-token"
            )

    @patch(f"{_SERVICE_MODULE}.blacklist_service")
    @patch(f"{_SERVICE_MODULE}.verify_refresh_token")
    async def test_blacklisted_token_raises(self, mock_verify_rt, mock_blacklist):
        mock_verify_rt.return_value = _make_refresh_payload()
        mock_blacklist.is_blacklisted = AsyncMock(return_value=True)

        db = _make_db()
        settings = _make_settings()

        with pytest.raises(InvalidRefreshTokenError, match="revoked"):
            await service.refresh_tokens(
                db, settings, refresh_token_str="blacklisted-token"
            )

    @patch(f"{_REPO_MODULE}.find_refresh_token_for_update", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.blacklist_service")
    @patch(f"{_SERVICE_MODULE}.verify_refresh_token")
    async def test_not_found_in_db_raises(
        self, mock_verify_rt, mock_blacklist, mock_find_rt
    ):
        mock_verify_rt.return_value = _make_refresh_payload()
        mock_blacklist.is_blacklisted = AsyncMock(return_value=False)
        mock_find_rt.return_value = None  # not in DB

        db = _make_db()
        settings = _make_settings()

        with pytest.raises(InvalidRefreshTokenError, match="not found"):
            await service.refresh_tokens(
                db, settings, refresh_token_str="missing-from-db"
            )

    @patch(f"{_REPO_MODULE}.revoke_all_user_refresh_tokens", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.revoke_refresh_token", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.find_refresh_token_for_update", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.blacklist_service")
    @patch(f"{_SERVICE_MODULE}.verify_refresh_token")
    async def test_replay_detection_revokes_all_sessions(
        self,
        mock_verify_rt,
        mock_blacklist,
        mock_find_rt,
        mock_revoke_rt,
        mock_revoke_all,
    ):
        """TM-011: When revoke returns False (already consumed), revoke all sessions."""
        payload = _make_refresh_payload()
        mock_verify_rt.return_value = payload
        mock_blacklist.is_blacklisted = AsyncMock(return_value=False)
        mock_find_rt.return_value = MagicMock()  # token found by locked lookup
        mock_revoke_rt.return_value = False  # already consumed → replay
        mock_revoke_all.return_value = 3

        db = _make_db()
        settings = _make_settings()

        with pytest.raises(InvalidRefreshTokenError) as exc_info:
            await service.refresh_tokens(
                db, settings, refresh_token_str="eyJ.refresh.replayed"
            )

        assert exc_info.value.code == "REFRESH_TOKEN_REPLAY"
        mock_revoke_all.assert_called_once_with(db, payload.sub)

    @patch(f"{_SERVICE_MODULE}.verify_refresh_token")
    async def test_application_mismatch_raises_invalid_refresh_token(self, mock_verify_rt):
        mock_verify_rt.return_value = _make_refresh_payload(app_id="app-a")

        db = _make_db()
        settings = _make_settings()

        with pytest.raises(InvalidRefreshTokenError, match="application mismatch"):
            await service.refresh_tokens(
                db,
                settings,
                refresh_token_str="eyJ.refresh.old",
                application_id="app-b",
            )


# ---------------------------------------------------------------------------
# Tests: wallet_sign_in
# ---------------------------------------------------------------------------


class TestWalletSignIn:
    @patch(f"{_REPO_MODULE}.store_refresh_token", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.generate_token_pair")
    @patch(f"{_SERVICE_MODULE}.nonce_service")
    @patch(f"{_SERVICE_MODULE}.verify_wallet_signature")
    @patch(f"{_SERVICE_MODULE}.extract_chain_from_address")
    @patch(f"{_REPO_MODULE}.find_user_by_wallet", new_callable=AsyncMock)
    async def test_existing_user_happy_path(
        self,
        mock_find_wallet,
        mock_extract_chain,
        mock_verify_sig,
        mock_nonce_svc,
        mock_gen_tokens,
        mock_store_rt,
    ):
        user = _make_user()
        wallet = _make_wallet(user_id=user.id)
        mock_find_wallet.return_value = (user, wallet)
        mock_extract_chain.return_value = "solana"
        mock_verify_sig.return_value = {"valid": True}
        mock_nonce_svc.validate_nonce = AsyncMock()
        mock_gen_tokens.return_value = _make_token_pair()
        mock_store_rt.return_value = MagicMock()

        db = _make_db()
        settings = _make_settings()
        message = "SPAPS wants you to sign in\nNonce: abc123def456\nTimestamp: 2025-01-01T00:00:00"

        result = await service.wallet_sign_in(
            db, settings,
            wallet_address=wallet.wallet_address,
            signature="valid-sig",
            message=message,
        )

        assert result["access_token"] == "eyJ.access.token"
        assert result["is_new_user"] is False
        assert result["user"]["id"] == str(user.id)

    @patch(f"{_REPO_MODULE}.store_refresh_token", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.generate_token_pair")
    @patch(f"{_SERVICE_MODULE}.nonce_service")
    @patch(f"{_SERVICE_MODULE}.verify_wallet_signature")
    @patch(f"{_SERVICE_MODULE}.extract_chain_from_address")
    @patch(f"{_REPO_MODULE}.create_user_with_wallet", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.find_user_by_wallet", new_callable=AsyncMock)
    async def test_new_user_happy_path(
        self,
        mock_find_wallet,
        mock_create,
        mock_extract_chain,
        mock_verify_sig,
        mock_nonce_svc,
        mock_gen_tokens,
        mock_store_rt,
    ):
        user = _make_user()
        wallet = _make_wallet(user_id=user.id)
        mock_find_wallet.return_value = (None, None)
        mock_create.return_value = (user, wallet)
        mock_extract_chain.return_value = "solana"
        mock_verify_sig.return_value = {"valid": True}
        mock_nonce_svc.validate_nonce = AsyncMock()
        mock_gen_tokens.return_value = _make_token_pair()
        mock_store_rt.return_value = MagicMock()

        db = _make_db()
        settings = _make_settings()
        message = "SPAPS wants you to sign in\nNonce: abc123def456\nTimestamp: 2025-01-01T00:00:00"

        result = await service.wallet_sign_in(
            db, settings,
            wallet_address=wallet.wallet_address,
            signature="valid-sig",
            message=message,
        )

        assert result["is_new_user"] is True
        mock_create.assert_called_once()

    @patch(f"{_SERVICE_MODULE}.verify_wallet_signature")
    @patch(f"{_SERVICE_MODULE}.extract_chain_from_address")
    async def test_invalid_signature_raises(
        self, mock_extract_chain, mock_verify_sig
    ):
        mock_extract_chain.return_value = "solana"
        mock_verify_sig.return_value = {"valid": False, "error": "Bad signature"}

        db = _make_db()
        settings = _make_settings()
        message = "SPAPS wants you to sign in\nNonce: abc123\nTimestamp: 2025-01-01"

        with pytest.raises(InvalidSignatureError):
            await service.wallet_sign_in(
                db, settings,
                wallet_address="SomeWalletAddress",
                signature="bad-sig",
                message=message,
            )


# ---------------------------------------------------------------------------
# Tests: request_nonce
# ---------------------------------------------------------------------------


class TestRequestNonce:
    @patch(f"{_SERVICE_MODULE}.nonce_service")
    async def test_happy_path(self, mock_nonce_svc):
        mock_nonce_svc.generate_nonce.return_value = "abcdef1234567890" * 4
        mock_nonce_svc.store_nonce = AsyncMock()
        mock_nonce_svc.create_auth_message.return_value = "Sign this message"

        db = _make_db()

        result = await service.request_nonce(
            db, wallet_address="HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy"
        )

        assert result["nonce"] == "abcdef1234567890" * 4
        assert result["message"] == "Sign this message"
        assert result["wallet_address"] == "HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy"
        assert "expires_at" in result
        mock_nonce_svc.store_nonce.assert_called_once()


# ---------------------------------------------------------------------------
# Tests: request_magic_link
# ---------------------------------------------------------------------------


class TestRequestMagicLink:
    @patch(f"{_REPO_MODULE}.create_auth_token", new_callable=AsyncMock)
    async def test_happy_path_with_state(self, mock_create_token):
        mock_create_token.return_value = "plaintext-token"

        db = _make_db()
        settings = _make_settings()

        with patch(
            f"{_REPO_MODULE}.store_magic_link_state", new_callable=AsyncMock
        ) as mock_store_state:
            result = await service.request_magic_link(
                db, settings,
                email="alice@example.com",
                state="custom-state",
            )

        assert result["email"] == "alice@example.com"
        assert result["state"] == "custom-state"
        assert "sent_at" in result
        mock_store_state.assert_called_once()

    @patch(f"{_REPO_MODULE}.create_auth_token", new_callable=AsyncMock)
    async def test_raw_token_not_logged_in_dev_mode(self, mock_create_token):
        """TM-011: Verify raw tokens are never logged (only redacted prefix)."""
        mock_create_token.return_value = "very-long-secret-token-value-12345"

        db = _make_db()
        settings = _make_settings(env="dev")

        with patch(f"{_SERVICE_MODULE}.logger") as mock_logger:
            result = await service.request_magic_link(
                db, settings, email="alice@example.com"
            )

        # Verify full token was never logged
        for call in mock_logger.info.call_args_list:
            args_str = str(call)
            assert "very-long-secret-token-value-12345" not in args_str

        # Verify redacted prefix was logged
        mock_logger.info.assert_any_call(
            "Magic link token (dev mode, redacted): %s for email %s",
            "very-lon...",
            "alice@example.com",
        )

    @patch(f"{_REPO_MODULE}.create_auth_token", new_callable=AsyncMock)
    async def test_happy_path_without_state(self, mock_create_token):
        mock_create_token.return_value = "plaintext-token"

        db = _make_db()
        settings = _make_settings()

        result = await service.request_magic_link(
            db, settings,
            email="alice@example.com",
        )

        assert result["email"] == "alice@example.com"
        assert result["state"] is None

    @patch(f"{_REPO_MODULE}.store_magic_link_state", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.create_auth_token", new_callable=AsyncMock)
    async def test_generate_state_flag(self, mock_create_token, mock_store_state):
        mock_create_token.return_value = "plaintext-token"

        db = _make_db()
        settings = _make_settings()

        result = await service.request_magic_link(
            db, settings,
            email="alice@example.com",
            generate_state=True,
        )

        assert result["state"] is not None
        assert isinstance(result["state"], str)
        mock_store_state.assert_called_once()

    @patch(f"{_REPO_MODULE}.create_auth_token", new_callable=AsyncMock)
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_id",
        new_callable=AsyncMock,
    )
    @patch("spaps_server_quickstart.domains.email.service.send_email", new_callable=AsyncMock)
    async def test_uses_application_redirect_url_for_magic_link(
        self,
        mock_send_email,
        mock_get_application,
        mock_create_token,
    ):
        mock_create_token.return_value = "plaintext-token"
        app = MagicMock()
        app.settings = {
            "email_redirect_url": "https://www.htmalabs.com/auth/confirm?source=email",
        }
        mock_get_application.return_value = app

        db = _make_db()
        settings = _make_settings(auth_base_url="https://your-app.com")
        application_id = str(uuid4())

        await service.request_magic_link(
            db,
            settings,
            email="alice@example.com",
            application_id=application_id,
        )

        link = mock_send_email.call_args.kwargs["context"]["link"]
        parsed = urlparse(link)
        params = parse_qs(parsed.query)

        assert parsed.scheme == "https"
        assert parsed.netloc == "www.htmalabs.com"
        assert parsed.path == "/auth/confirm"
        assert params["source"] == ["email"]
        assert params["token"] == ["plaintext-token"]
        assert params["type"] == ["magiclink"]

    @patch(f"{_REPO_MODULE}.create_auth_token", new_callable=AsyncMock)
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_id",
        new_callable=AsyncMock,
    )
    @patch("spaps_server_quickstart.domains.email.service.send_email", new_callable=AsyncMock)
    async def test_magic_link_prefers_client_redirect_with_same_origin(
        self,
        mock_send_email,
        mock_get_application,
        mock_create_token,
    ):
        mock_create_token.return_value = "plaintext-token"
        app = MagicMock()
        app.settings = {
            "email_redirect_url": "https://unclawg.com/reset-password",
        }
        mock_get_application.return_value = app

        db = _make_db()
        settings = _make_settings(auth_base_url="https://fallback.example.com")
        application_id = str(uuid4())

        await service.request_magic_link(
            db,
            settings,
            email="alice@example.com",
            application_id=application_id,
            redirect_url="https://unclawg.com/auth/cli-callback",
        )

        link = mock_send_email.call_args.kwargs["context"]["link"]
        parsed = urlparse(link)
        params = parse_qs(parsed.query)

        assert parsed.scheme == "https"
        assert parsed.netloc == "unclawg.com"
        assert parsed.path == "/auth/cli-callback"
        assert params["token"] == ["plaintext-token"]
        assert params["type"] == ["magiclink"]

    @patch(f"{_REPO_MODULE}.create_auth_token", new_callable=AsyncMock)
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_id",
        new_callable=AsyncMock,
    )
    @patch("spaps_server_quickstart.domains.email.service.send_email", new_callable=AsyncMock)
    async def test_magic_link_legacy_login_redirect_is_overridden_by_callback_redirect(
        self,
        mock_send_email,
        mock_get_application,
        mock_create_token,
    ):
        mock_create_token.return_value = "plaintext-token"
        app = MagicMock()
        app.settings = {
            "email_redirect_url": "https://unclawg.com/login?return_url=https%3A%2F%2Funclawg.com%2Finbox",
        }
        mock_get_application.return_value = app

        db = _make_db()
        settings = _make_settings(auth_base_url="https://fallback.example.com")
        application_id = str(uuid4())

        await service.request_magic_link(
            db,
            settings,
            email="alice@example.com",
            application_id=application_id,
            redirect_url="https://unclawg.com/auth/cli-callback",
        )

        link = mock_send_email.call_args.kwargs["context"]["link"]
        parsed = urlparse(link)
        params = parse_qs(parsed.query)

        assert parsed.path == "/auth/cli-callback"
        assert parsed.path != "/login"
        assert params["token"] == ["plaintext-token"]
        assert params["type"] == ["magiclink"]

    @patch(f"{_REPO_MODULE}.create_auth_token", new_callable=AsyncMock)
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_id",
        new_callable=AsyncMock,
    )
    @patch("spaps_server_quickstart.domains.email.service.send_email", new_callable=AsyncMock)
    async def test_magic_link_legacy_login_redirect_falls_back_to_safe_default(
        self,
        mock_send_email,
        mock_get_application,
        mock_create_token,
    ):
        mock_create_token.return_value = "plaintext-token"
        app = MagicMock()
        app.settings = {
            "email_redirect_url": "https://unclawg.com/login?return_url=https%3A%2F%2Funclawg.com%2Finbox",
        }
        mock_get_application.return_value = app

        db = _make_db()
        settings = _make_settings(auth_base_url="https://fallback.example.com")
        application_id = str(uuid4())

        await service.request_magic_link(
            db,
            settings,
            email="alice@example.com",
            application_id=application_id,
        )

        link = mock_send_email.call_args.kwargs["context"]["link"]
        parsed = urlparse(link)
        params = parse_qs(parsed.query)

        assert parsed.scheme == "https"
        assert parsed.netloc == "fallback.example.com"
        assert parsed.path == "/auth/confirm"
        assert parsed.path != "/login"
        assert params["token"] == ["plaintext-token"]
        assert params["type"] == ["magiclink"]

    @patch(f"{_REPO_MODULE}.create_auth_token", new_callable=AsyncMock)
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_id",
        new_callable=AsyncMock,
    )
    @patch("spaps_server_quickstart.domains.email.service.send_email", new_callable=AsyncMock)
    async def test_magic_link_rejects_client_redirect_with_different_origin(
        self,
        mock_send_email,
        mock_get_application,
        mock_create_token,
    ):
        mock_create_token.return_value = "plaintext-token"
        app = MagicMock()
        app.settings = {
            "email_redirect_url": "https://unclawg.com/reset-password",
        }
        mock_get_application.return_value = app

        db = _make_db()
        settings = _make_settings(auth_base_url="https://fallback.example.com")
        application_id = str(uuid4())

        await service.request_magic_link(
            db,
            settings,
            email="alice@example.com",
            application_id=application_id,
            redirect_url="https://evil.example.com/phish",
        )

        link = mock_send_email.call_args.kwargs["context"]["link"]
        parsed = urlparse(link)

        assert parsed.scheme == "https"
        assert parsed.netloc == "unclawg.com"
        assert parsed.path == "/reset-password"

    @patch(f"{_REPO_MODULE}.create_auth_token", new_callable=AsyncMock)
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_id",
        new_callable=AsyncMock,
        return_value=None,
    )
    @patch("spaps_server_quickstart.domains.email.service.send_email", new_callable=AsyncMock)
    async def test_magic_link_falls_back_to_auth_base_url(
        self,
        mock_send_email,
        _mock_get_application,
        mock_create_token,
    ):
        mock_create_token.return_value = "plaintext-token"

        db = _make_db()
        settings = _make_settings(auth_base_url="https://fallback.example.com")
        application_id = str(uuid4())

        await service.request_magic_link(
            db,
            settings,
            email="alice@example.com",
            application_id=application_id,
        )

        link = mock_send_email.call_args.kwargs["context"]["link"]
        parsed = urlparse(link)
        params = parse_qs(parsed.query)

        assert parsed.scheme == "https"
        assert parsed.netloc == "fallback.example.com"
        assert parsed.path == "/auth/confirm"
        assert params["token"] == ["plaintext-token"]
        assert params["type"] == ["magiclink"]


# ---------------------------------------------------------------------------
# Tests: verify_magic_link
# ---------------------------------------------------------------------------


class TestVerifyMagicLink:
    @patch(f"{_REPO_MODULE}.store_refresh_token", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.generate_token_pair")
    @patch(f"{_REPO_MODULE}.validate_and_consume_auth_token", new_callable=AsyncMock)
    async def test_happy_path(
        self, mock_validate_token, mock_gen_tokens, mock_store_rt
    ):
        auth_token = MagicMock()
        auth_token.email = "alice@example.com"
        mock_validate_token.return_value = auth_token
        mock_gen_tokens.return_value = _make_token_pair()
        mock_store_rt.return_value = MagicMock()

        user = _make_user(email="alice@example.com")
        db = _make_db()
        settings = _make_settings()

        with patch(
            "spaps_server_quickstart.domains.users.service.find_or_create_user",
            new_callable=AsyncMock,
            return_value=(user, False),
        ):
            result = await service.verify_magic_link(
                db, settings,
                token="valid-token",
                token_type="magic_link",
            )

        assert result["tokens"]["access_token"] == "eyJ.access.token"
        assert result["user"]["email"] == "alice@example.com"

    @patch(f"{_REPO_MODULE}.validate_and_consume_auth_token", new_callable=AsyncMock)
    async def test_invalid_token_raises(self, mock_validate_token):
        mock_validate_token.return_value = None

        db = _make_db()
        settings = _make_settings()

        with pytest.raises(InvalidTokenError):
            await service.verify_magic_link(
                db, settings,
                token="invalid-token",
                token_type="magic_link",
            )

    @patch(f"{_REPO_MODULE}.validate_and_consume_auth_token", new_callable=AsyncMock)
    async def test_token_without_email_raises(self, mock_validate_token):
        auth_token = MagicMock()
        auth_token.email = None
        mock_validate_token.return_value = auth_token

        db = _make_db()
        settings = _make_settings()

        with pytest.raises(InvalidTokenError, match="no associated email"):
            await service.verify_magic_link(
                db, settings,
                token="token-no-email",
                token_type="magic_link",
            )

    @patch(f"{_REPO_MODULE}.store_refresh_token", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.generate_token_pair")
    @patch(f"{_REPO_MODULE}.validate_and_consume_auth_token", new_callable=AsyncMock)
    async def test_rejects_token_redeemed_under_other_application(
        self,
        mock_validate_token,
        mock_gen_tokens,
        mock_store_rt,
    ):
        redeeming_application_id = uuid4()

        async def validate_side_effect(
            db,
            token,
            token_type,
            application_id=None,
        ):
            assert application_id == redeeming_application_id
            return None

        mock_validate_token.side_effect = validate_side_effect

        db = _make_db()
        settings = _make_settings()

        with pytest.raises(
            InvalidTokenError,
            match="Invalid, expired, or already-used magic link",
        ):
            await service.verify_magic_link(
                db,
                settings,
                token="tenant-a-token",
                token_type="magic_link",
                application_id=str(redeeming_application_id),
            )

        mock_gen_tokens.assert_not_called()
        mock_store_rt.assert_not_awaited()

    @patch(f"{_REPO_MODULE}.find_magic_link_state", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.store_refresh_token", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.generate_token_pair")
    @patch(f"{_REPO_MODULE}.validate_and_consume_auth_token", new_callable=AsyncMock)
    async def test_uses_token_application_for_state_lookup_and_session(
        self,
        mock_validate_token,
        mock_gen_tokens,
        mock_store_rt,
        mock_find_state,
    ):
        token_application_id = uuid4()
        auth_token = MagicMock()
        auth_token.email = "alice@example.com"
        auth_token.application_id = token_application_id
        mock_validate_token.return_value = auth_token
        mock_gen_tokens.return_value = _make_token_pair()
        mock_store_rt.return_value = MagicMock()

        async def find_state_side_effect(db, state, application_id=None):
            assert state == "valid-state"
            assert application_id == token_application_id
            state_row = MagicMock()
            state_row.email = "alice@example.com"
            state_row.application_id = token_application_id
            return state_row

        mock_find_state.side_effect = find_state_side_effect

        user = _make_user(email="alice@example.com")
        db = _make_db()
        settings = _make_settings()

        with patch(
            "spaps_server_quickstart.domains.users.service.find_or_create_user",
            new_callable=AsyncMock,
            return_value=(user, False),
        ):
            result = await service.verify_magic_link(
                db,
                settings,
                token="valid-token",
                token_type="magic_link",
                state="valid-state",
            )

        assert result["tokens"]["access_token"] == "eyJ.access.token"
        assert mock_gen_tokens.call_args.kwargs["application_id"] == str(
            token_application_id
        )
        assert mock_store_rt.await_args.kwargs["application_id"] == str(
            token_application_id
        )

    @patch(
        "spaps_server_quickstart.domains.users.service.find_or_create_user",
        new_callable=AsyncMock,
    )
    @patch(f"{_SERVICE_MODULE}._generate_and_store_tokens", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.validate_and_consume_auth_token", new_callable=AsyncMock)
    async def test_rejects_cross_tenant_redemption(
        self,
        mock_validate_token,
        mock_generate_and_store_tokens,
        mock_find_or_create_user,
    ):
        stored_application_id = uuid4()
        request_application_id = uuid4()
        auth_token = MagicMock()
        auth_token.email = "alice@example.com"
        auth_token.application_id = stored_application_id
        mock_validate_token.return_value = auth_token
        mock_generate_and_store_tokens.return_value = _make_token_pair()
        mock_find_or_create_user.return_value = (_make_user(email="alice@example.com"), False)

        db = _make_db()
        settings = _make_settings()

        with pytest.raises(
            InvalidTokenError, match="Invalid, expired, or already-used magic link"
        ):
            await service.verify_magic_link(
                db,
                settings,
                token="valid-token",
                token_type="magic_link",
                application_id=str(request_application_id),
            )

        mock_validate_token.assert_awaited_once_with(
            db,
            "valid-token",
            "magiclink",
            application_id=request_application_id,
        )
        mock_generate_and_store_tokens.assert_not_awaited()

    @patch(
        "spaps_server_quickstart.domains.users.service.find_or_create_user",
        new_callable=AsyncMock,
    )
    @patch(f"{_SERVICE_MODULE}._generate_and_store_tokens", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.validate_and_consume_auth_token", new_callable=AsyncMock)
    async def test_uses_stored_application_id_for_session_when_request_context_missing(
        self,
        mock_validate_token,
        mock_generate_and_store_tokens,
        mock_find_or_create_user,
    ):
        stored_application_id = uuid4()
        auth_token = MagicMock()
        auth_token.email = "alice@example.com"
        auth_token.application_id = stored_application_id
        mock_validate_token.return_value = auth_token
        mock_generate_and_store_tokens.return_value = _make_token_pair()
        mock_find_or_create_user.return_value = (_make_user(email="alice@example.com"), False)

        db = _make_db()
        settings = _make_settings()

        await service.verify_magic_link(
            db,
            settings,
            token="valid-token",
            token_type="magic_link",
            application_id=None,
        )

        assert (
            mock_generate_and_store_tokens.await_args.kwargs["application_id"]
            == str(stored_application_id)
        )

    @patch(f"{_REPO_MODULE}.find_magic_link_state", new_callable=AsyncMock)
    @patch(
        "spaps_server_quickstart.domains.users.service.find_or_create_user",
        new_callable=AsyncMock,
    )
    @patch(f"{_SERVICE_MODULE}._generate_and_store_tokens", new_callable=AsyncMock)
    @patch(f"{_REPO_MODULE}.validate_and_consume_auth_token", new_callable=AsyncMock)
    async def test_scopes_magic_link_state_lookup_to_application(
        self,
        mock_validate_token,
        mock_generate_and_store_tokens,
        mock_find_or_create_user,
        mock_find_magic_link_state,
    ):
        stored_application_id = uuid4()
        auth_token = MagicMock()
        auth_token.email = "alice@example.com"
        auth_token.application_id = stored_application_id
        mock_validate_token.return_value = auth_token
        mock_generate_and_store_tokens.return_value = _make_token_pair()
        mock_find_or_create_user.return_value = (_make_user(email="alice@example.com"), False)

        state_row = MagicMock()
        state_row.email = "alice@example.com"
        state_row.application_id = stored_application_id
        mock_find_magic_link_state.return_value = state_row

        db = _make_db()
        settings = _make_settings()
        request_application_id = stored_application_id

        await service.verify_magic_link(
            db,
            settings,
            token="valid-token",
            token_type="magic_link",
            application_id=str(request_application_id),
            state="expected-state",
        )

        mock_find_magic_link_state.assert_awaited_once_with(
            db,
            "expected-state",
            application_id=request_application_id,
        )


# ---------------------------------------------------------------------------
# Tests: request_password_reset
# ---------------------------------------------------------------------------


class TestRequestPasswordReset:
    @patch(f"{_REPO_MODULE}.create_auth_token", new_callable=AsyncMock)
    async def test_happy_path_known_email(self, mock_create_token):
        mock_create_token.return_value = "reset-token"
        user = _make_user()
        db = _make_db()
        settings = _make_settings()

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_email",
            new_callable=AsyncMock,
            return_value=user,
        ):
            result = await service.request_password_reset(
                db, settings, email="alice@example.com"
            )

        assert result["email"] == "alice@example.com"
        assert "sent_at" in result
        mock_create_token.assert_called_once()

    @patch(f"{_REPO_MODULE}.create_auth_token", new_callable=AsyncMock)
    async def test_raw_token_not_logged_in_dev_mode(self, mock_create_token):
        """TM-011: Verify raw reset tokens are never logged (only redacted prefix)."""
        mock_create_token.return_value = "very-long-reset-token-secret-value-99999"
        user = _make_user()
        db = _make_db()
        settings = _make_settings(env="dev")

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_email",
            new_callable=AsyncMock,
            return_value=user,
        ), patch(f"{_SERVICE_MODULE}.logger") as mock_logger:
            result = await service.request_password_reset(
                db, settings, email="alice@example.com"
            )

        # Verify full token was never logged
        for call in mock_logger.info.call_args_list:
            args_str = str(call)
            assert "very-long-reset-token-secret-value-99999" not in args_str

        # Verify redacted prefix was logged
        mock_logger.info.assert_any_call(
            "Password reset token (dev mode, redacted): %s for email %s",
            "very-lon...",
            "alice@example.com",
        )

    async def test_unknown_email_still_returns_success(self):
        """No enumeration: unknown emails should return the same shape."""
        db = _make_db()
        settings = _make_settings()

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_email",
            new_callable=AsyncMock,
            return_value=None,
        ):
            result = await service.request_password_reset(
                db, settings, email="unknown@example.com"
            )

        assert result["email"] == "unknown@example.com"
        assert "sent_at" in result

    @patch(f"{_REPO_MODULE}.create_auth_token", new_callable=AsyncMock)
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_id",
        new_callable=AsyncMock,
    )
    @patch("spaps_server_quickstart.domains.email.service.send_email", new_callable=AsyncMock)
    async def test_uses_application_redirect_url_for_password_reset(
        self,
        mock_send_email,
        mock_get_application,
        mock_create_token,
    ):
        mock_create_token.return_value = "reset-token"
        app = MagicMock()
        app.settings = {
            "email_redirect_url": "https://www.htmalabs.com/auth/confirm?source=email",
        }
        mock_get_application.return_value = app
        user = _make_user()

        db = _make_db()
        settings = _make_settings(auth_base_url="https://your-app.com")
        application_id = str(uuid4())

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_email",
            new_callable=AsyncMock,
            return_value=user,
        ):
            await service.request_password_reset(
                db,
                settings,
                email="alice@example.com",
                application_id=application_id,
            )

        link = mock_send_email.call_args.kwargs["context"]["link"]
        parsed = urlparse(link)
        params = parse_qs(parsed.query)

        assert parsed.scheme == "https"
        assert parsed.netloc == "www.htmalabs.com"
        assert parsed.path == "/auth/confirm"
        assert params["source"] == ["email"]
        assert params["token"] == ["reset-token"]
        assert params["type"] == ["recovery"]

    @patch(f"{_REPO_MODULE}.create_auth_token", new_callable=AsyncMock)
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_id",
        new_callable=AsyncMock,
    )
    @patch("spaps_server_quickstart.domains.email.service.send_email", new_callable=AsyncMock)
    async def test_password_reset_prefers_client_redirect_with_same_origin(
        self,
        mock_send_email,
        mock_get_application,
        mock_create_token,
    ):
        mock_create_token.return_value = "reset-token"
        app = MagicMock()
        app.settings = {
            "email_redirect_url": "https://unclawg.com/auth/cli-callback",
        }
        mock_get_application.return_value = app
        user = _make_user()

        db = _make_db()
        settings = _make_settings(auth_base_url="https://fallback.example.com")
        application_id = str(uuid4())

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_email",
            new_callable=AsyncMock,
            return_value=user,
        ):
            await service.request_password_reset(
                db,
                settings,
                email="alice@example.com",
                application_id=application_id,
                redirect_url="https://unclawg.com/reset-password",
            )

        link = mock_send_email.call_args.kwargs["context"]["link"]
        parsed = urlparse(link)
        params = parse_qs(parsed.query)

        assert parsed.scheme == "https"
        assert parsed.netloc == "unclawg.com"
        assert parsed.path == "/reset-password"
        assert params["token"] == ["reset-token"]
        assert params["type"] == ["recovery"]

    @patch(f"{_REPO_MODULE}.create_auth_token", new_callable=AsyncMock)
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_id",
        new_callable=AsyncMock,
        return_value=None,
    )
    @patch("spaps_server_quickstart.domains.email.service.send_email", new_callable=AsyncMock)
    async def test_password_reset_falls_back_to_auth_base_url(
        self,
        mock_send_email,
        _mock_get_application,
        mock_create_token,
    ):
        mock_create_token.return_value = "reset-token"
        user = _make_user()
        db = _make_db()
        settings = _make_settings(auth_base_url="https://fallback.example.com")
        application_id = str(uuid4())

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_email",
            new_callable=AsyncMock,
            return_value=user,
        ):
            await service.request_password_reset(
                db,
                settings,
                email="alice@example.com",
                application_id=application_id,
            )

        link = mock_send_email.call_args.kwargs["context"]["link"]
        parsed = urlparse(link)
        params = parse_qs(parsed.query)

        assert parsed.scheme == "https"
        assert parsed.netloc == "fallback.example.com"
        assert parsed.path == "/auth/reset-password-confirm"
        assert params["token"] == ["reset-token"]
        assert params["type"] == ["recovery"]


# ---------------------------------------------------------------------------
# Tests: confirm_password_reset
# ---------------------------------------------------------------------------


class TestConfirmPasswordReset:
    @patch(f"{_SERVICE_MODULE}.blacklist_service")
    @patch(f"{_REPO_MODULE}.revoke_all_user_refresh_tokens", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.password_service")
    @patch(f"{_REPO_MODULE}.validate_and_consume_auth_token", new_callable=AsyncMock)
    async def test_happy_path(
        self, mock_validate, mock_pw_svc, mock_revoke_all, mock_blacklist
    ):
        user_id = str(uuid4())
        auth_token = MagicMock()
        auth_token.user_id = user_id
        mock_validate.return_value = auth_token
        mock_pw_svc.validate_password_strength.return_value = None
        mock_pw_svc.hash_password.return_value = "$2b$12$newhash"
        mock_pw_svc.hash_password_async = AsyncMock(return_value="$2b$12$newhash")
        mock_revoke_all.return_value = 2
        mock_blacklist.blacklist_all_user_tokens = AsyncMock()

        db = _make_db()
        settings = _make_settings()

        with patch(
            "spaps_server_quickstart.domains.users.service.set_password",
            new_callable=AsyncMock,
            return_value=True,
        ):
            result = await service.confirm_password_reset(
                db, settings,
                token="valid-reset-token",
                new_password="NewPassw0rd!",
            )

        assert "reset successfully" in result["message"].lower()
        mock_revoke_all.assert_called_once_with(db, user_id)

    @patch(f"{_REPO_MODULE}.validate_and_consume_auth_token", new_callable=AsyncMock)
    async def test_invalid_token_raises(self, mock_validate):
        mock_validate.return_value = None

        db = _make_db()
        settings = _make_settings()

        with pytest.raises(InvalidTokenError):
            await service.confirm_password_reset(
                db, settings,
                token="bad-token",
                new_password="NewPassw0rd!",
            )

    @patch(f"{_SERVICE_MODULE}.password_service")
    @patch(f"{_REPO_MODULE}.validate_and_consume_auth_token", new_callable=AsyncMock)
    async def test_weak_password_raises(self, mock_validate, mock_pw_svc):
        auth_token = MagicMock()
        auth_token.user_id = str(uuid4())
        mock_validate.return_value = auth_token
        mock_pw_svc.validate_password_strength.side_effect = WeakPasswordError(
            "Password must contain: at least 1 digit"
        )

        db = _make_db()
        settings = _make_settings()

        with pytest.raises(WeakPasswordError):
            await service.confirm_password_reset(
                db, settings,
                token="valid-token",
                new_password="weakpassword",
            )


# ---------------------------------------------------------------------------
# Tests: set_password
# ---------------------------------------------------------------------------


class TestSetPassword:
    @patch(f"{_SERVICE_MODULE}.password_service")
    async def test_happy_path_with_existing_password(self, mock_pw_svc):
        user = _make_user(password_hash="$2b$12$oldhash")
        mock_pw_svc.verify_password.return_value = True
        mock_pw_svc.verify_password_async = AsyncMock(return_value=True)
        mock_pw_svc.validate_password_strength.return_value = None
        mock_pw_svc.hash_password.return_value = "$2b$12$newhash"
        mock_pw_svc.hash_password_async = AsyncMock(return_value="$2b$12$newhash")

        db = _make_db()
        settings = _make_settings()

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_id",
            new_callable=AsyncMock,
            return_value=user,
        ), patch(
            "spaps_server_quickstart.domains.users.service.set_password",
            new_callable=AsyncMock,
            return_value=True,
        ):
            result = await service.set_password(
                db, settings,
                user_id=str(user.id),
                current_password="OldPassw0rd!",
                new_password="NewPassw0rd!",
            )

        assert "updated" in result["message"].lower()
        mock_pw_svc.verify_password_async.assert_called_once_with(
            "OldPassw0rd!", "$2b$12$oldhash"
        )

    @patch(f"{_SERVICE_MODULE}.password_service")
    async def test_wallet_only_user_no_current_password(self, mock_pw_svc):
        """Wallet-only users can set password without providing current password."""
        user = _make_user(password_hash=None)
        mock_pw_svc.validate_password_strength.return_value = None
        mock_pw_svc.hash_password.return_value = "$2b$12$newhash"
        mock_pw_svc.hash_password_async = AsyncMock(return_value="$2b$12$newhash")

        db = _make_db()
        settings = _make_settings()

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_id",
            new_callable=AsyncMock,
            return_value=user,
        ), patch(
            "spaps_server_quickstart.domains.users.service.set_password",
            new_callable=AsyncMock,
            return_value=True,
        ):
            result = await service.set_password(
                db, settings,
                user_id=str(user.id),
                new_password="NewPassw0rd!",
            )

        assert "updated" in result["message"].lower()
        # verify_password should NOT be called for wallet-only user
        mock_pw_svc.verify_password.assert_not_called()
        mock_pw_svc.verify_password_async.assert_not_called()

    @patch(f"{_SERVICE_MODULE}.password_service")
    async def test_wrong_current_password_raises(self, mock_pw_svc):
        user = _make_user(password_hash="$2b$12$oldhash")
        mock_pw_svc.verify_password.return_value = False
        mock_pw_svc.verify_password_async = AsyncMock(return_value=False)

        db = _make_db()
        settings = _make_settings()

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_id",
            new_callable=AsyncMock,
            return_value=user,
        ):
            with pytest.raises(InvalidCredentialsError, match="incorrect"):
                await service.set_password(
                    db, settings,
                    user_id=str(user.id),
                    current_password="wrong",
                    new_password="NewPassw0rd!",
                )

    async def test_missing_current_password_with_existing_hash_raises(self):
        user = _make_user(password_hash="$2b$12$oldhash")
        db = _make_db()
        settings = _make_settings()

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_id",
            new_callable=AsyncMock,
            return_value=user,
        ):
            with pytest.raises(InvalidCredentialsError, match="required"):
                await service.set_password(
                    db, settings,
                    user_id=str(user.id),
                    new_password="NewPassw0rd!",
                )

    async def test_user_not_found_raises(self):
        db = _make_db()
        settings = _make_settings()

        with patch(
            "spaps_server_quickstart.domains.users.repository.get_user_by_id",
            new_callable=AsyncMock,
            return_value=None,
        ):
            with pytest.raises(NotFoundError):
                await service.set_password(
                    db, settings,
                    user_id="nonexistent-id",
                    new_password="NewPassw0rd!",
                )


# ---------------------------------------------------------------------------
# Tests: get_me
# ---------------------------------------------------------------------------


class TestGetMe:
    @patch(f"{_REPO_MODULE}.find_user_with_wallets", new_callable=AsyncMock)
    async def test_happy_path_with_wallets(self, mock_find):
        user = _make_user()
        wallets = [
            _make_wallet(
                user_id=user.id,
                wallet_address="HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy",
                chain_type="solana",
            )
        ]
        mock_find.return_value = (user, wallets)

        db = _make_db()

        result = await service.get_me(db, user_id=str(user.id))

        assert result["user"]["id"] == str(user.id)
        assert result["user"]["wallets"] is not None
        assert len(result["user"]["wallets"]) == 1
        assert result["user"]["wallets"][0]["chain_type"] == "solana"

    @patch(f"{_REPO_MODULE}.find_user_with_wallets", new_callable=AsyncMock)
    async def test_user_not_found_raises(self, mock_find):
        mock_find.return_value = (None, [])

        db = _make_db()

        with pytest.raises(NotFoundError):
            await service.get_me(db, user_id="nonexistent-id")


# ---------------------------------------------------------------------------
# Tests: logout
# ---------------------------------------------------------------------------


class TestLogout:
    @patch(f"{_REPO_MODULE}.revoke_refresh_token", new_callable=AsyncMock)
    @patch(f"{_SERVICE_MODULE}.blacklist_service")
    async def test_with_refresh_token(self, mock_blacklist, mock_revoke_rt):
        mock_blacklist.blacklist_token = AsyncMock()
        mock_revoke_rt.return_value = True

        db = _make_db()
        user_id = str(uuid4())

        result = await service.logout(
            db,
            user_id=user_id,
            access_token_jti="jti-123",
            access_token_exp=9999999999,
            refresh_token="eyJ.refresh.token",
        )

        assert "logged out" in result["message"].lower()
        mock_blacklist.blacklist_token.assert_called_once()
        mock_revoke_rt.assert_called_once_with(db, "eyJ.refresh.token")

    @patch(f"{_SERVICE_MODULE}.blacklist_service")
    async def test_without_refresh_token(self, mock_blacklist):
        mock_blacklist.blacklist_token = AsyncMock()

        db = _make_db()
        user_id = str(uuid4())

        result = await service.logout(
            db,
            user_id=user_id,
            access_token_jti="jti-123",
            access_token_exp=9999999999,
        )

        assert "logged out" in result["message"].lower()
        mock_blacklist.blacklist_token.assert_called_once()
