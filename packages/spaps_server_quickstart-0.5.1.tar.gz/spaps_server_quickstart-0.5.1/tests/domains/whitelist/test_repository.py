"""Unit tests for the whitelist domain repository layer.

Mocks the AsyncSession to test each repository function in isolation
without hitting a real database.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID, uuid4


from spaps_server_quickstart.domains.whitelist import repository as repo
from spaps_server_quickstart.domains.whitelist.models import EmailWhitelist


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_whitelist_entry(
    entry_id: str | None = None,
    application_id: UUID | None = None,
    email: str = "user@example.com",
    tier: str = "premium",
    bypass_payment: bool = True,
    metadata: dict | None = None,
    created_by: UUID | None = None,
) -> MagicMock:
    """Return a mock EmailWhitelist with sensible defaults."""
    entry = MagicMock(spec=EmailWhitelist)
    entry.id = UUID(entry_id) if entry_id else uuid4()
    entry.application_id = application_id or uuid4()
    entry.email = email
    entry.tier = tier
    entry.bypass_payment = bypass_payment
    entry.metadata_ = metadata or {}
    entry.created_by = created_by
    entry.created_at = datetime.now(UTC)
    entry.updated_at = datetime.now(UTC)
    return entry


def _mock_session() -> AsyncMock:
    """Create a mock AsyncSession with the common interface."""
    session = AsyncMock()
    session.add = MagicMock()
    session.flush = AsyncMock()
    session.refresh = AsyncMock()
    session.execute = AsyncMock()
    return session


# ---------------------------------------------------------------------------
# get_by_email
# ---------------------------------------------------------------------------


class TestGetByEmail:
    async def test_returns_entry_when_found(self):
        app_id = uuid4()
        entry = _make_whitelist_entry(application_id=app_id, email="test@example.com")
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = entry
        db.execute.return_value = result_mock

        result = await repo.get_by_email(db, app_id, "test@example.com")

        assert result is entry
        db.execute.assert_awaited_once()

    async def test_returns_none_when_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        result = await repo.get_by_email(db, uuid4(), "nonexistent@example.com")

        assert result is None

    async def test_lowercases_email(self):
        """The repository should normalize email to lowercase before querying."""
        app_id = uuid4()
        entry = _make_whitelist_entry(application_id=app_id, email="test@example.com")
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = entry
        db.execute.return_value = result_mock

        result = await repo.get_by_email(db, app_id, "TEST@EXAMPLE.COM")

        assert result is entry
        db.execute.assert_awaited_once()


# ---------------------------------------------------------------------------
# count
# ---------------------------------------------------------------------------


class TestCount:
    async def test_returns_count(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one.return_value = 5
        db.execute.return_value = result_mock

        result = await repo.count(db, uuid4())

        assert result == 5
        db.execute.assert_awaited_once()

    async def test_returns_zero_when_empty(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one.return_value = 0
        db.execute.return_value = result_mock

        result = await repo.count(db, uuid4())

        assert result == 0

    async def test_filters_by_tier(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one.return_value = 3
        db.execute.return_value = result_mock

        result = await repo.count(db, uuid4(), tier="enterprise")

        assert result == 3
        db.execute.assert_awaited_once()

    async def test_no_tier_filter_when_none(self):
        """Passing tier=None should not add a tier filter."""
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one.return_value = 10
        db.execute.return_value = result_mock

        result = await repo.count(db, uuid4(), tier=None)

        assert result == 10
        db.execute.assert_awaited_once()


# ---------------------------------------------------------------------------
# create
# ---------------------------------------------------------------------------


class TestCreate:
    async def test_creates_and_flushes(self):
        db = _mock_session()
        app_id = uuid4()
        creator_id = uuid4()

        async def _fake_refresh(obj):
            obj.id = uuid4()
            obj.created_at = datetime.now(UTC)
            obj.updated_at = datetime.now(UTC)

        db.refresh.side_effect = _fake_refresh

        result = await repo.create(
            db,
            application_id=app_id,
            email="NEW@EXAMPLE.COM",
            tier="enterprise",
            bypass_payment=False,
            metadata={"source": "admin"},
            created_by=creator_id,
        )

        assert result.application_id == app_id
        assert result.email == "new@example.com"
        assert result.tier == "enterprise"
        assert result.bypass_payment is False
        assert result.metadata_ == {"source": "admin"}
        assert result.created_by == creator_id
        db.add.assert_called_once()
        db.flush.assert_awaited_once()
        db.refresh.assert_awaited_once()

    async def test_creates_with_defaults(self):
        db = _mock_session()
        app_id = uuid4()

        result = await repo.create(
            db,
            application_id=app_id,
            email="default@example.com",
        )

        assert result.email == "default@example.com"
        assert result.tier == "premium"
        assert result.bypass_payment is False
        assert result.metadata_ == {}
        assert result.created_by is None
        db.add.assert_called_once()

    async def test_lowercases_email(self):
        db = _mock_session()

        result = await repo.create(
            db,
            application_id=uuid4(),
            email="UPPER@CASE.COM",
        )

        assert result.email == "upper@case.com"


# ---------------------------------------------------------------------------
# bulk_create
# ---------------------------------------------------------------------------


class TestBulkCreate:
    async def test_creates_multiple_entries(self):
        db = _mock_session()
        app_id = uuid4()

        # get_by_email returns None (no existing entry)
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        entries = [
            {"email": "a@example.com", "tier": "premium"},
            {"email": "b@example.com", "tier": "enterprise"},
        ]

        successful, failed = await repo.bulk_create(
            db, application_id=app_id, entries=entries
        )

        assert len(successful) == 2
        assert len(failed) == 0

    async def test_skips_existing_entries(self):
        db = _mock_session()
        app_id = uuid4()
        existing = _make_whitelist_entry(application_id=app_id, email="exists@example.com")

        # First call returns existing, second returns None
        result_existing = MagicMock()
        result_existing.scalar_one_or_none.return_value = existing
        result_none = MagicMock()
        result_none.scalar_one_or_none.return_value = None

        db.execute.side_effect = [result_existing, result_none]

        entries = [
            {"email": "exists@example.com"},
            {"email": "new@example.com"},
        ]

        successful, failed = await repo.bulk_create(
            db, application_id=app_id, entries=entries
        )

        assert len(successful) == 1
        assert len(failed) == 1
        assert failed[0]["email"] == "exists@example.com"
        assert "already whitelisted" in failed[0]["error"].lower()

    async def test_handles_flush_exception(self):
        db = _mock_session()
        app_id = uuid4()

        # get_by_email returns None (no existing)
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        # flush raises on first call, succeeds on second
        db.flush.side_effect = [Exception("DB error"), AsyncMock()]

        entries = [
            {"email": "fail@example.com"},
            {"email": "pass@example.com"},
        ]

        successful, failed = await repo.bulk_create(
            db, application_id=app_id, entries=entries
        )

        assert len(failed) == 1
        assert failed[0]["email"] == "fail@example.com"
        assert "DB error" in failed[0]["error"]

    async def test_returns_empty_for_empty_input(self):
        db = _mock_session()

        successful, failed = await repo.bulk_create(
            db, application_id=uuid4(), entries=[]
        )

        assert successful == []
        assert failed == []

    async def test_lowercases_emails(self):
        db = _mock_session()
        app_id = uuid4()

        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        entries = [{"email": "UPPER@CASE.COM"}]

        successful, failed = await repo.bulk_create(
            db, application_id=app_id, entries=entries
        )

        assert len(successful) == 1
        assert successful[0].email == "upper@case.com"

    async def test_applies_created_by(self):
        db = _mock_session()
        app_id = uuid4()
        creator_id = uuid4()

        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        entries = [{"email": "user@example.com"}]

        successful, failed = await repo.bulk_create(
            db, application_id=app_id, entries=entries, created_by=creator_id
        )

        assert len(successful) == 1
        assert successful[0].created_by == creator_id

    async def test_uses_default_tier_when_not_specified(self):
        db = _mock_session()
        app_id = uuid4()

        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        entries = [{"email": "user@example.com"}]

        successful, failed = await repo.bulk_create(
            db, application_id=app_id, entries=entries
        )

        assert len(successful) == 1
        assert successful[0].tier == "premium"


# ---------------------------------------------------------------------------
# list_entries
# ---------------------------------------------------------------------------


class TestListEntries:
    async def test_returns_entries(self):
        app_id = uuid4()
        e1 = _make_whitelist_entry(application_id=app_id, email="a@example.com")
        e2 = _make_whitelist_entry(application_id=app_id, email="b@example.com")
        db = _mock_session()

        result_mock = MagicMock()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = [e1, e2]
        result_mock.scalars.return_value = scalars_mock
        db.execute.return_value = result_mock

        result = await repo.list_entries(db, app_id)

        assert len(result) == 2
        assert e1 in result
        assert e2 in result

    async def test_returns_empty_list_when_none(self):
        db = _mock_session()

        result_mock = MagicMock()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = []
        result_mock.scalars.return_value = scalars_mock
        db.execute.return_value = result_mock

        result = await repo.list_entries(db, uuid4())

        assert result == []

    async def test_accepts_pagination_params(self):
        db = _mock_session()

        result_mock = MagicMock()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = []
        result_mock.scalars.return_value = scalars_mock
        db.execute.return_value = result_mock

        result = await repo.list_entries(db, uuid4(), limit=5, offset=10)

        assert result == []
        db.execute.assert_awaited_once()

    async def test_filters_by_tier(self):
        db = _mock_session()

        result_mock = MagicMock()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = []
        result_mock.scalars.return_value = scalars_mock
        db.execute.return_value = result_mock

        result = await repo.list_entries(db, uuid4(), tier="enterprise")

        assert result == []
        db.execute.assert_awaited_once()


# ---------------------------------------------------------------------------
# update_entry
# ---------------------------------------------------------------------------


class TestUpdateEntry:
    async def test_updates_existing_entry(self):
        app_id = uuid4()
        entry = _make_whitelist_entry(application_id=app_id, email="user@example.com", tier="premium")
        db = _mock_session()

        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = entry
        db.execute.return_value = result_mock

        result = await repo.update_entry(db, app_id, "user@example.com", tier="enterprise")

        assert result is entry
        assert result.tier == "enterprise"
        db.flush.assert_awaited()
        db.refresh.assert_awaited()

    async def test_returns_none_when_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        result = await repo.update_entry(db, uuid4(), "nobody@example.com", tier="enterprise")

        assert result is None

    async def test_sets_updated_at(self):
        entry = _make_whitelist_entry()
        original_updated = entry.updated_at
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = entry
        db.execute.return_value = result_mock

        await repo.update_entry(db, entry.application_id, entry.email, tier="changed")

        assert entry.updated_at >= original_updated

    async def test_metadata_kwarg_maps_to_metadata_field(self):
        """Passing metadata= should set entry.metadata_ (the column alias)."""
        entry = _make_whitelist_entry()
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = entry
        db.execute.return_value = result_mock

        new_meta = {"key": "value"}
        await repo.update_entry(
            db, entry.application_id, entry.email, metadata=new_meta
        )

        assert entry.metadata_ == new_meta

    async def test_lowercases_email(self):
        """The email lookup inside update_entry should be case-insensitive."""
        entry = _make_whitelist_entry(email="user@example.com")
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = entry
        db.execute.return_value = result_mock

        result = await repo.update_entry(
            db, entry.application_id, "USER@EXAMPLE.COM", tier="enterprise"
        )

        assert result is entry


# ---------------------------------------------------------------------------
# get_stats
# ---------------------------------------------------------------------------


class TestGetStats:
    async def test_returns_stats_dict(self):
        app_id = uuid4()
        db = _mock_session()

        # First call: count (scalar_one)
        count_result = MagicMock()
        count_result.scalar_one.return_value = 5

        # Second call: tier breakdown (all)
        tier_row_1 = MagicMock()
        tier_row_1.tier = "premium"
        tier_row_1.count = 3
        tier_row_2 = MagicMock()
        tier_row_2.tier = "enterprise"
        tier_row_2.count = 2
        tier_result = MagicMock()
        tier_result.all.return_value = [tier_row_1, tier_row_2]

        db.execute.side_effect = [count_result, tier_result]

        result = await repo.get_stats(db, app_id, whitelist_enabled=True)

        assert result["enabled"] is True
        assert result["total"] == 5
        assert len(result["tier_breakdown"]) == 2
        assert {"tier": "premium", "count": 3} in result["tier_breakdown"]
        assert {"tier": "enterprise", "count": 2} in result["tier_breakdown"]

    async def test_returns_empty_stats(self):
        app_id = uuid4()
        db = _mock_session()

        count_result = MagicMock()
        count_result.scalar_one.return_value = 0

        tier_result = MagicMock()
        tier_result.all.return_value = []

        db.execute.side_effect = [count_result, tier_result]

        result = await repo.get_stats(db, app_id)

        assert result["enabled"] is False
        assert result["total"] == 0
        assert result["tier_breakdown"] == []

    async def test_whitelist_enabled_defaults_false(self):
        db = _mock_session()

        count_result = MagicMock()
        count_result.scalar_one.return_value = 0
        tier_result = MagicMock()
        tier_result.all.return_value = []
        db.execute.side_effect = [count_result, tier_result]

        result = await repo.get_stats(db, uuid4())

        assert result["enabled"] is False


# ---------------------------------------------------------------------------
# clear_all
# ---------------------------------------------------------------------------


class TestClearAll:
    async def test_deletes_entries_and_returns_count(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.rowcount = 7
        db.execute.return_value = result_mock

        deleted = await repo.clear_all(db, uuid4())

        assert deleted == 7
        db.execute.assert_awaited_once()
        db.flush.assert_awaited_once()

    async def test_returns_zero_when_empty(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.rowcount = 0
        db.execute.return_value = result_mock

        deleted = await repo.clear_all(db, uuid4())

        assert deleted == 0
        db.flush.assert_awaited_once()


# ---------------------------------------------------------------------------
# delete_by_email
# ---------------------------------------------------------------------------


class TestDeleteByEmail:
    async def test_returns_true_when_deleted(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.rowcount = 1
        db.execute.return_value = result_mock

        result = await repo.delete_by_email(db, uuid4(), "user@example.com")

        assert result is True
        db.execute.assert_awaited_once()
        db.flush.assert_awaited_once()

    async def test_returns_false_when_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.rowcount = 0
        db.execute.return_value = result_mock

        result = await repo.delete_by_email(db, uuid4(), "nonexistent@example.com")

        assert result is False
        db.flush.assert_not_awaited()

    async def test_lowercases_email(self):
        """The delete should normalize email to lowercase."""
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.rowcount = 1
        db.execute.return_value = result_mock

        result = await repo.delete_by_email(db, uuid4(), "USER@EXAMPLE.COM")

        assert result is True
        db.execute.assert_awaited_once()
