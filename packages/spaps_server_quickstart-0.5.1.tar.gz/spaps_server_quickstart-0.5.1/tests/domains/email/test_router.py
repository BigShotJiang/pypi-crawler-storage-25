"""Unit tests for the email domain router (HTTP layer).

Each test creates a minimal FastAPI test app with dependency overrides for
the database session, application, current user, and admin user. The
email service layer is fully mocked so tests exercise only routing,
request validation, status codes, and response shapes.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.email.router import email_router
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_current_user,
    get_db_session,
    require_admin_user,
)

# ---------------------------------------------------------------------------
# Helpers / Constants
# ---------------------------------------------------------------------------

FAKE_USER_ID = str(uuid4())
FAKE_APP_ID = str(uuid4())
FAKE_ADMIN_ID = str(uuid4())
FAKE_TEMPLATE_ID = str(uuid4())
FAKE_LOG_ID = str(uuid4())

_EMAIL_SERVICE = "spaps_server_quickstart.domains.email.service"


def _fake_template(
    template_key: str = "auth_magic_link",
    name: str = "Magic Link",
) -> dict:
    """Return a realistic template dict."""
    return {
        "id": FAKE_TEMPLATE_ID,
        "application_id": FAKE_APP_ID,
        "template_key": template_key,
        "name": name,
        "description": "Magic link email",
        "subject": "Your magic link",
        "html_body": "<p>Click {{ link }}</p>",
        "text_body": "Click {{ link }}",
        "from_email": "noreply@example.com",
        "from_name": "SPAPS",
        "reply_to": None,
        "variables": {"link": "string"},
        "sample_context": {"link": "https://example.com"},
        "is_active": True,
        "category": "auth",
        "created_at": datetime.now(UTC).isoformat(),
        "updated_at": datetime.now(UTC).isoformat(),
    }


def _fake_log(status: str = "sent") -> dict:
    """Return a realistic email log dict."""
    return {
        "id": FAKE_LOG_ID,
        "application_id": FAKE_APP_ID,
        "template_id": FAKE_TEMPLATE_ID,
        "user_id": FAKE_USER_ID,
        "owner_id": None,
        "to_email": "user@example.com",
        "template_key": "auth_magic_link",
        "subject": "Your magic link",
        "status": status,
        "mailgun_message_id": "msg-123",
        "error_message": None,
        "sent_at": datetime.now(UTC).isoformat(),
        "delivered_at": None,
        "opened_at": None,
        "clicked_at": None,
        "created_at": datetime.now(UTC).isoformat(),
    }


def _fake_user():
    """Return a mock authenticated user."""
    user = MagicMock()
    user.id = FAKE_USER_ID
    user.email = "user@example.com"
    user.username = "user"
    user.tier = "premium"
    user.roles = ["user"]
    user.permissions = []
    user.is_admin = False
    user.is_super_admin = False
    user.wallet_addresses = []
    return user


def _fake_admin():
    """Return a mock admin user."""
    admin = MagicMock()
    admin.id = FAKE_ADMIN_ID
    admin.email = "admin@example.com"
    admin.username = "admin"
    admin.tier = "premium"
    admin.roles = ["admin"]
    admin.permissions = ["manage_templates"]
    admin.is_admin = True
    admin.is_super_admin = False
    admin.wallet_addresses = []
    return admin


def _fake_application():
    """Return a mock application."""
    app = MagicMock()
    app.id = FAKE_APP_ID
    app.name = "Test App"
    app.settings = {"email": {"mailgun_domain": "mail.app.example.com"}}
    return app


def _create_test_app():
    """Create a FastAPI test app with email router and overridden deps."""
    app = FastAPI()

    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    settings.env = "injected-test"
    settings.is_spaps_local_mode = True
    app.state.settings = settings

    install_error_handlers(app)
    app.include_router(email_router)

    mock_db = AsyncMock()

    async def override_db_session():
        yield mock_db

    app.dependency_overrides[get_db_session] = override_db_session
    app.dependency_overrides[get_application] = _fake_application
    app.dependency_overrides[get_current_user] = _fake_user
    app.dependency_overrides[require_admin_user] = _fake_admin

    return app


@pytest.fixture
def test_app():
    return _create_test_app()


@pytest.fixture
async def client(test_app):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ===========================================================================
# POST /email/send
# ===========================================================================


class TestSendEmail:
    @patch(f"{_EMAIL_SERVICE}.send_email", new_callable=AsyncMock)
    async def test_success(self, mock_send, client: AsyncClient):
        """POST /email/send returns message_id."""
        mock_send.return_value = {"message_id": "local-123"}

        resp = await client.post(
            "/email/send",
            json={
                "template_key": "auth_magic_link",
                "to": "user@example.com",
                "context": {"link": "https://example.com"},
            },
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["message_id"] == "local-123"
        assert mock_send.await_args is not None
        assert (
            mock_send.await_args.kwargs["app_settings"]
            == {"email": {"mailgun_domain": "mail.app.example.com"}}
        )
        assert mock_send.await_args.kwargs["settings_env"] == "injected-test"
        assert mock_send.await_args.kwargs["settings_local_mode"] is True

    async def test_missing_template_key_returns_400(self, client: AsyncClient):
        """POST /email/send without template_key returns 400."""
        resp = await client.post(
            "/email/send",
            json={"to": "user@example.com"},
        )
        assert resp.status_code == 400

    async def test_missing_to_returns_400(self, client: AsyncClient):
        """POST /email/send without to returns 400."""
        resp = await client.post(
            "/email/send",
            json={"template_key": "auth_magic_link"},
        )
        assert resp.status_code == 400

    @patch(f"{_EMAIL_SERVICE}.send_email", new_callable=AsyncMock)
    async def test_template_not_found_returns_404(self, mock_send, client: AsyncClient):
        """POST /email/send returns 404 when template not found."""
        from spaps_server_quickstart.domains.email.errors import TemplateNotFoundError

        mock_send.side_effect = TemplateNotFoundError()

        resp = await client.post(
            "/email/send",
            json={
                "template_key": "nonexistent",
                "to": "user@example.com",
            },
        )

        assert resp.status_code == 404

    @patch(f"{_EMAIL_SERVICE}.send_email", new_callable=AsyncMock)
    async def test_send_failure_returns_500(self, mock_send, client: AsyncClient):
        """POST /email/send returns 500 when delivery fails."""
        from spaps_server_quickstart.domains.email.errors import EmailSendFailedError

        mock_send.side_effect = EmailSendFailedError()

        resp = await client.post(
            "/email/send",
            json={
                "template_key": "auth_magic_link",
                "to": "user@example.com",
            },
        )

        assert resp.status_code == 500


# ===========================================================================
# GET /email/templates
# ===========================================================================


class TestListTemplates:
    @patch(f"{_EMAIL_SERVICE}.list_templates", new_callable=AsyncMock)
    async def test_success(self, mock_list, client: AsyncClient):
        """GET /email/templates returns templates list."""
        mock_list.return_value = {
            "templates": [_fake_template()],
        }

        resp = await client.get("/email/templates")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data["templates"]) == 1

    @patch(f"{_EMAIL_SERVICE}.list_templates", new_callable=AsyncMock)
    async def test_empty(self, mock_list, client: AsyncClient):
        """GET /email/templates returns empty list."""
        mock_list.return_value = {"templates": []}

        resp = await client.get("/email/templates")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data["templates"]) == 0


# ===========================================================================
# POST /email/templates (create)
# ===========================================================================


class TestCreateTemplate:
    @patch(f"{_EMAIL_SERVICE}.create_template", new_callable=AsyncMock)
    async def test_success(self, mock_create, client: AsyncClient):
        """POST /email/templates creates template and returns 201."""
        mock_create.return_value = {"template": _fake_template(template_key="new_tpl")}

        resp = await client.post(
            "/email/templates",
            json={
                "name": "New Template",
                "template_key": "new_tpl",
                "subject": "Hello",
                "html_body": "<p>Hello</p>",
            },
        )

        assert resp.status_code == 201
        data = resp.json()
        assert data["template"]["template_key"] == "new_tpl"

    async def test_missing_name_returns_400(self, client: AsyncClient):
        """POST /email/templates without name returns 400."""
        resp = await client.post(
            "/email/templates",
            json={
                "template_key": "test",
                "subject": "Hello",
                "html_body": "<p>Hello</p>",
            },
        )
        # FastAPI validation strips 'name' required field -> 400
        assert resp.status_code == 400

    async def test_missing_html_body_returns_400(self, client: AsyncClient):
        """POST /email/templates without html_body returns 400."""
        resp = await client.post(
            "/email/templates",
            json={
                "name": "Test",
                "template_key": "test",
                "subject": "Hello",
            },
        )
        assert resp.status_code == 400

    @patch(f"{_EMAIL_SERVICE}.create_template", new_callable=AsyncMock)
    async def test_duplicate_returns_409(self, mock_create, client: AsyncClient):
        """POST /email/templates returns 409 for duplicate key."""
        from spaps_server_quickstart.domains.email.errors import TemplateAlreadyExistsError

        mock_create.side_effect = TemplateAlreadyExistsError()

        resp = await client.post(
            "/email/templates",
            json={
                "name": "Dup",
                "template_key": "auth_magic_link",
                "subject": "Hello",
                "html_body": "<p>Hello</p>",
            },
        )

        assert resp.status_code == 409


# ===========================================================================
# GET /email/templates/:key
# ===========================================================================


class TestGetTemplate:
    @patch(f"{_EMAIL_SERVICE}.get_template", new_callable=AsyncMock)
    async def test_success(self, mock_get, client: AsyncClient):
        """GET /email/templates/:key returns template."""
        mock_get.return_value = _fake_template()

        resp = await client.get("/email/templates/auth_magic_link")

        assert resp.status_code == 200
        data = resp.json()
        assert data["template_key"] == "auth_magic_link"

    @patch(f"{_EMAIL_SERVICE}.get_template", new_callable=AsyncMock)
    async def test_not_found_returns_404(self, mock_get, client: AsyncClient):
        """GET /email/templates/:key returns 404 when not found."""
        from spaps_server_quickstart.domains.email.errors import TemplateNotFoundError

        mock_get.side_effect = TemplateNotFoundError()

        resp = await client.get("/email/templates/nonexistent")

        assert resp.status_code == 404


# ===========================================================================
# GET /email/templates/:key/preview
# ===========================================================================


class TestPreviewTemplateGet:
    @patch(f"{_EMAIL_SERVICE}.preview_template", new_callable=AsyncMock)
    async def test_success(self, mock_preview, client: AsyncClient):
        """GET /email/templates/:key/preview returns HTML."""
        mock_preview.return_value = "<p>Hello User</p>"

        resp = await client.get("/email/templates/auth_magic_link/preview")

        assert resp.status_code == 200
        assert "Hello User" in resp.text

    @patch(f"{_EMAIL_SERVICE}.preview_template", new_callable=AsyncMock)
    async def test_not_found_returns_404(self, mock_preview, client: AsyncClient):
        """GET /email/templates/:key/preview returns 404."""
        from spaps_server_quickstart.domains.email.errors import TemplateNotFoundError

        mock_preview.side_effect = TemplateNotFoundError()

        resp = await client.get("/email/templates/nonexistent/preview")

        assert resp.status_code == 404


# ===========================================================================
# POST /email/templates/:key/preview
# ===========================================================================


class TestPreviewTemplatePost:
    @patch(f"{_EMAIL_SERVICE}.preview_template", new_callable=AsyncMock)
    async def test_success(self, mock_preview, client: AsyncClient):
        """POST /email/templates/:key/preview returns HTML with custom context."""
        mock_preview.return_value = "<p>Hello Alice</p>"

        resp = await client.post(
            "/email/templates/auth_magic_link/preview",
            json={"context": {"name": "Alice", "link": "https://test.com"}},
        )

        assert resp.status_code == 200
        assert "Alice" in resp.text

    @patch(f"{_EMAIL_SERVICE}.preview_template", new_callable=AsyncMock)
    async def test_empty_context(self, mock_preview, client: AsyncClient):
        """POST /email/templates/:key/preview with empty context."""
        mock_preview.return_value = "<p>Hello {{ name }}</p>"

        resp = await client.post(
            "/email/templates/auth_magic_link/preview",
            json={"context": {}},
        )

        assert resp.status_code == 200


# ===========================================================================
# PUT /email/templates/:key
# ===========================================================================


class TestUpdateTemplate:
    @patch(f"{_EMAIL_SERVICE}.update_template", new_callable=AsyncMock)
    async def test_success(self, mock_update, client: AsyncClient):
        """PUT /email/templates/:key updates and returns template."""
        tpl = _fake_template()
        tpl["name"] = "Updated Name"
        mock_update.return_value = {"template": tpl}

        resp = await client.put(
            "/email/templates/auth_magic_link",
            json={"name": "Updated Name"},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["template"]["name"] == "Updated Name"

    @patch(f"{_EMAIL_SERVICE}.update_template", new_callable=AsyncMock)
    async def test_not_found_returns_404(self, mock_update, client: AsyncClient):
        """PUT /email/templates/:key returns 404 for unknown."""
        from spaps_server_quickstart.domains.email.errors import TemplateNotFoundError

        mock_update.side_effect = TemplateNotFoundError()

        resp = await client.put(
            "/email/templates/nonexistent",
            json={"name": "Updated"},
        )

        assert resp.status_code == 404


# ===========================================================================
# Template overrides
# ===========================================================================


class TestTemplateOverrides:
    @patch(f"{_EMAIL_SERVICE}.get_template_override", new_callable=AsyncMock)
    async def test_get_override_success(self, mock_get, client: AsyncClient):
        """GET /email/templates/:key/override returns override payload."""
        mock_get.return_value = {
            "subject_override": "Custom subject",
            "body_override": "<p>Custom body</p>",
        }

        resp = await client.get("/email/templates/auth_magic_link/override")

        assert resp.status_code == 200
        data = resp.json()
        assert data["subject_override"] == "Custom subject"
        assert data["body_override"] == "<p>Custom body</p>"

    @patch(f"{_EMAIL_SERVICE}.get_template_override", new_callable=AsyncMock)
    async def test_get_override_missing_returns_404(self, mock_get, client: AsyncClient):
        """GET /email/templates/:key/override returns 404 when missing."""
        from spaps_server_quickstart.domains.email.errors import (
            TemplateOverrideNotFoundError,
        )

        mock_get.side_effect = TemplateOverrideNotFoundError()

        resp = await client.get("/email/templates/auth_magic_link/override")

        assert resp.status_code == 404
        data = resp.json()
        assert data["error"]["code"] == "OVERRIDE_NOT_FOUND"

    @patch(f"{_EMAIL_SERVICE}.create_or_update_template_override", new_callable=AsyncMock)
    async def test_put_override_success(self, mock_put, client: AsyncClient):
        """PUT /email/templates/:key/override upserts and returns payload."""
        mock_put.return_value = {
            "subject_override": "Updated subject",
            "body_override": "<p>Updated body</p>",
        }

        resp = await client.put(
            "/email/templates/auth_magic_link/override",
            json={
                "subject_override": "Updated subject",
                "body_override": "<p>Updated body</p>",
            },
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["subject_override"] == "Updated subject"
        assert data["body_override"] == "<p>Updated body</p>"

    @patch(f"{_EMAIL_SERVICE}.create_or_update_template_override", new_callable=AsyncMock)
    async def test_put_override_requires_admin(
        self,
        mock_put,
        test_app: FastAPI,
    ):
        """PUT /email/templates/:key/override returns 403 for non-admin users."""
        from spaps_server_quickstart.middleware.jwt_auth import AuthenticatedUser

        if require_admin_user in test_app.dependency_overrides:
            del test_app.dependency_overrides[require_admin_user]

        test_app.dependency_overrides[get_current_user] = lambda: AuthenticatedUser(
            id=FAKE_USER_ID,
            email="user@example.com",
            roles=["user"],
            permissions=["view_products"],
            is_admin=False,
            is_super_admin=False,
        )

        transport = ASGITransport(app=test_app)
        async with AsyncClient(transport=transport, base_url="http://test") as guarded_client:
            resp = await guarded_client.put(
                "/email/templates/auth_magic_link/override",
                json={"subject_override": "Updated subject"},
            )

        assert resp.status_code == 403
        assert resp.json()["error"]["code"] == "FORBIDDEN"
        mock_put.assert_not_called()

    async def test_put_override_requires_at_least_one_field(self, client: AsyncClient):
        """PUT /email/templates/:key/override validates non-empty payload."""
        resp = await client.put("/email/templates/auth_magic_link/override", json={})
        assert resp.status_code == 400

    @patch(f"{_EMAIL_SERVICE}.delete_template_override", new_callable=AsyncMock)
    async def test_delete_override_success(self, mock_delete, client: AsyncClient):
        """DELETE /email/templates/:key/override removes override."""
        mock_delete.return_value = {"deleted": True}

        resp = await client.delete("/email/templates/auth_magic_link/override")

        assert resp.status_code == 200
        data = resp.json()
        assert data["deleted"] is True

    @patch(f"{_EMAIL_SERVICE}.delete_template_override", new_callable=AsyncMock)
    async def test_delete_override_requires_admin(
        self,
        mock_delete,
        test_app: FastAPI,
    ):
        """DELETE /email/templates/:key/override returns 403 for non-admin users."""
        from spaps_server_quickstart.middleware.jwt_auth import AuthenticatedUser

        if require_admin_user in test_app.dependency_overrides:
            del test_app.dependency_overrides[require_admin_user]

        test_app.dependency_overrides[get_current_user] = lambda: AuthenticatedUser(
            id=FAKE_USER_ID,
            email="user@example.com",
            roles=["user"],
            permissions=["view_products"],
            is_admin=False,
            is_super_admin=False,
        )

        transport = ASGITransport(app=test_app)
        async with AsyncClient(transport=transport, base_url="http://test") as guarded_client:
            resp = await guarded_client.delete("/email/templates/auth_magic_link/override")

        assert resp.status_code == 403
        assert resp.json()["error"]["code"] == "FORBIDDEN"
        mock_delete.assert_not_called()

    @patch(f"{_EMAIL_SERVICE}.delete_template_override", new_callable=AsyncMock)
    async def test_delete_override_missing_returns_404(
        self,
        mock_delete,
        client: AsyncClient,
    ):
        """DELETE /email/templates/:key/override returns 404 when missing."""
        from spaps_server_quickstart.domains.email.errors import (
            TemplateOverrideNotFoundError,
        )

        mock_delete.side_effect = TemplateOverrideNotFoundError()

        resp = await client.delete("/email/templates/auth_magic_link/override")

        assert resp.status_code == 404
        data = resp.json()
        assert data["error"]["code"] == "OVERRIDE_NOT_FOUND"


# ===========================================================================
# GET /email/logs
# ===========================================================================


class TestListLogs:
    @patch(f"{_EMAIL_SERVICE}.get_logs", new_callable=AsyncMock)
    async def test_non_admin_defaults_to_self_scope(
        self,
        mock_get_logs,
        client: AsyncClient,
    ):
        """GET /email/logs passes caller identity for self-scoping."""
        mock_get_logs.return_value = {
            "logs": [_fake_log()],
            "total": 1,
        }

        resp = await client.get("/email/logs")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert len(data["logs"]) == 1
        mock_get_logs.assert_awaited_once()
        assert mock_get_logs.await_args is not None
        assert mock_get_logs.await_args.kwargs == {
            "application_id": UUID(FAKE_APP_ID),
            "current_user_id": UUID(FAKE_USER_ID),
            "is_admin": False,
            "owner_id": None,
            "user_id": None,
            "limit": 50,
            "offset": 0,
        }

    @patch(f"{_EMAIL_SERVICE}.get_logs", new_callable=AsyncMock)
    async def test_non_admin_can_filter_to_self_user_id(
        self,
        mock_get_logs,
        client: AsyncClient,
    ):
        """GET /email/logs accepts a self user_id filter for non-admins."""
        mock_get_logs.return_value = {"logs": [], "total": 0}

        resp = await client.get(
            "/email/logs", params={"user_id": FAKE_USER_ID}
        )

        assert resp.status_code == 200
        assert mock_get_logs.await_args is not None
        assert mock_get_logs.await_args.kwargs["user_id"] == UUID(FAKE_USER_ID)
        assert mock_get_logs.await_args.kwargs["is_admin"] is False

    @patch(f"{_EMAIL_SERVICE}.get_logs", new_callable=AsyncMock)
    async def test_non_admin_forbidden_filter_returns_403(
        self,
        mock_get_logs,
        client: AsyncClient,
    ):
        """GET /email/logs returns 403 when the service rejects widening filters."""
        from spaps_server_quickstart.domains.errors import ForbiddenError

        mock_get_logs.side_effect = ForbiddenError(
            "Users may only read their own email logs"
        )

        resp = await client.get(
            "/email/logs",
            params={"owner_id": str(uuid4())},
        )

        assert resp.status_code == 403
        assert resp.json()["error"]["code"] == "FORBIDDEN"

    @patch(f"{_EMAIL_SERVICE}.get_logs", new_callable=AsyncMock)
    async def test_admin_can_query_app_wide_and_owner_filters(
        self,
        mock_get_logs,
        test_app: FastAPI,
    ):
        """GET /email/logs preserves app-wide and owner filters for admins."""
        test_app.dependency_overrides[get_current_user] = _fake_admin
        mock_get_logs.return_value = {"logs": [], "total": 0}

        owner_id = uuid4()
        target_user_id = uuid4()
        transport = ASGITransport(app=test_app)
        async with AsyncClient(
            transport=transport,
            base_url="http://test",
        ) as admin_client:
            resp = await admin_client.get(
                "/email/logs",
                params={
                    "owner_id": str(owner_id),
                    "user_id": str(target_user_id),
                },
            )

        assert resp.status_code == 200
        assert mock_get_logs.await_args is not None
        assert mock_get_logs.await_args.kwargs["current_user_id"] == UUID(
            FAKE_ADMIN_ID
        )
        assert mock_get_logs.await_args.kwargs["is_admin"] is True
        assert mock_get_logs.await_args.kwargs["owner_id"] == owner_id
        assert mock_get_logs.await_args.kwargs["user_id"] == target_user_id

    @patch(f"{_EMAIL_SERVICE}.get_logs", new_callable=AsyncMock)
    async def test_with_pagination(self, mock_get_logs, client: AsyncClient):
        """GET /email/logs with limit and offset."""
        mock_get_logs.return_value = {"logs": [], "total": 0}

        resp = await client.get(
            "/email/logs", params={"limit": 10, "offset": 20}
        )

        assert resp.status_code == 200

    @patch(f"{_EMAIL_SERVICE}.get_logs", new_callable=AsyncMock)
    async def test_empty_logs(self, mock_get_logs, client: AsyncClient):
        """GET /email/logs returns empty list."""
        mock_get_logs.return_value = {"logs": [], "total": 0}

        resp = await client.get("/email/logs")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0
        assert len(data["logs"]) == 0
