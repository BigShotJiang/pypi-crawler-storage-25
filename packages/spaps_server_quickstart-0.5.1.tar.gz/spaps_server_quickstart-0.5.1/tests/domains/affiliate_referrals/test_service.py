"""Unit tests for the affiliate_referrals domain service layer.

The repository layer is fully mocked so tests exercise only the
service orchestration, business logic, and error handling.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from spaps_server_quickstart.domains.affiliate_referrals import service
from spaps_server_quickstart.domains.affiliate_referrals.errors import (
    AffiliateAlreadyExistsError,
    AffiliateNotFoundError,
    AlreadyAttributedError,
    ClickExpiredError,
    ClickNotFoundError,
    ClickRateLimitedError,
    InsufficientBalanceError,
    NotApplicationOwnerError,
    PayoutNotApprovedError,
    PayoutNotFoundError,
    PayoutNotPendingError,
    PayoutWalletNotSetError,
    SelfReferralError,
    SlugAlreadyExistsError,
)

_REPO = "spaps_server_quickstart.domains.affiliate_referrals.service.repo"
_WEBHOOK_TRIGGER = (
    "spaps_server_quickstart.domains.affiliate_referrals.service.webhook_service.trigger_event"
)

FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()
FAKE_AGENT_ID = uuid4()
FAKE_AFFILIATE_ID = uuid4()
FAKE_CLICK_ID = uuid4()


# ---------------------------------------------------------------------------
# Mock factories
# ---------------------------------------------------------------------------


def _make_affiliate(
    affiliate_id: UUID | None = None,
    affiliate_type: str = "user",
    user_id: UUID | None = None,
    agent_id: UUID | None = None,
    slug: str = "test-bot",
    referred_by_affiliate_id: UUID | None = None,
    referral_depth: int = 0,
    is_active: bool = True,
    credit_balance_cents: int = 0,
    payout_wallet_address: str | None = None,
    payout_chain: str | None = None,
) -> MagicMock:
    aff = MagicMock()
    aff.id = affiliate_id or FAKE_AFFILIATE_ID
    aff.affiliate_type = affiliate_type
    aff.user_id = user_id or (FAKE_USER_ID if affiliate_type == "user" else None)
    aff.agent_id = agent_id or (FAKE_AGENT_ID if affiliate_type == "agent" else None)
    aff.slug = slug
    aff.referred_by_affiliate_id = referred_by_affiliate_id
    aff.referral_depth = referral_depth
    aff.is_active = is_active
    aff.credit_balance_cents = credit_balance_cents
    aff.lifetime_earned_cents = 0
    aff.lifetime_paid_out_cents = 0
    aff.payout_wallet_address = payout_wallet_address
    aff.payout_chain = payout_chain
    aff.created_at = datetime.now(UTC)
    aff.updated_at = datetime.now(UTC)
    return aff


def _make_click(
    click_id: UUID | None = None,
    affiliate_id: UUID | None = None,
    expires_at: datetime | None = None,
    converted_at: datetime | None = None,
) -> MagicMock:
    click = MagicMock()
    click.id = click_id or FAKE_CLICK_ID
    click.affiliate_id = affiliate_id or FAKE_AFFILIATE_ID
    click.expires_at = expires_at or (datetime.now(UTC) + timedelta(days=30))
    click.converted_at = converted_at
    return click


def _make_attribution(
    affiliate_id: UUID | None = None,
) -> MagicMock:
    attr = MagicMock()
    attr.id = uuid4()
    attr.affiliate_id = affiliate_id or FAKE_AFFILIATE_ID
    attr.referred_entity_type = "user"
    attr.referred_entity_id = uuid4()
    attr.attributed_at = datetime.now(UTC)
    return attr


def _make_agent(
    agent_id: UUID | None = None,
    owner_user_id: UUID | None = None,
) -> MagicMock:
    agent = MagicMock()
    agent.id = agent_id or FAKE_AGENT_ID
    agent.owner_user_id = owner_user_id or FAKE_USER_ID
    return agent


def _make_payout(
    payout_id: UUID | None = None,
    affiliate_id: UUID | None = None,
    status: str = "requested",
    amount_cents: int = 5000,
) -> MagicMock:
    payout = MagicMock()
    payout.id = payout_id or uuid4()
    payout.affiliate_id = affiliate_id or FAKE_AFFILIATE_ID
    payout.amount_cents = amount_cents
    payout.payout_method = "usdc_onchain"
    payout.wallet_address = "0x" + "a" * 40
    payout.chain = "eip155:8453"
    payout.tx_hash = None
    payout.status = status
    payout.requested_at = datetime.now(UTC)
    payout.approved_at = None
    payout.completed_at = None
    return payout


def _make_commission(
    affiliate_id: UUID | None = None,
    level: int = 1,
    amount_cents: int = 50,
    rate_bps: int = 1000,
) -> MagicMock:
    c = MagicMock()
    c.id = uuid4()
    c.affiliate_id = affiliate_id or FAKE_AFFILIATE_ID
    c.source_entity_type = "agent"
    c.source_entity_id = uuid4()
    c.payment_event_type = "x402_topup"
    c.payment_amount_cents = 500
    c.commission_level = level
    c.commission_rate_bps = rate_bps
    c.commission_amount_cents = amount_cents
    c.credited_at = datetime.now(UTC)
    return c


# ===========================================================================
# Registration tests
# ===========================================================================


class TestRegisterAffiliate:
    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_register_user_affiliate_success(self, mock_repo):
        db = AsyncMock()
        affiliate = _make_affiliate()
        mock_repo.get_affiliate_by_slug = AsyncMock(return_value=None)
        mock_repo.get_affiliate_by_user_id = AsyncMock(return_value=None)
        mock_repo.get_attribution_by_entity = AsyncMock(return_value=None)
        mock_repo.create_affiliate = AsyncMock(return_value=affiliate)

        result = await service.register_affiliate(
            db,
            user_id=FAKE_USER_ID,
            affiliate_type="user",
            slug="test-bot",
        )

        assert result["slug"] == "test-bot"
        assert result["affiliate_type"] == "user"
        mock_repo.create_affiliate.assert_called_once()

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_register_slug_taken(self, mock_repo):
        db = AsyncMock()
        mock_repo.get_affiliate_by_slug = AsyncMock(return_value=_make_affiliate())

        with pytest.raises(SlugAlreadyExistsError):
            await service.register_affiliate(
                db, user_id=FAKE_USER_ID, affiliate_type="user", slug="taken"
            )

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_register_already_exists(self, mock_repo):
        db = AsyncMock()
        mock_repo.get_affiliate_by_slug = AsyncMock(return_value=None)
        mock_repo.get_affiliate_by_user_id = AsyncMock(return_value=_make_affiliate())

        with pytest.raises(AffiliateAlreadyExistsError):
            await service.register_affiliate(
                db, user_id=FAKE_USER_ID, affiliate_type="user", slug="new-slug"
            )

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_register_agent_affiliate_with_referral_chain(self, mock_repo):
        db = AsyncMock()
        referrer = _make_affiliate(affiliate_id=uuid4(), referral_depth=1)
        attribution = _make_attribution(affiliate_id=referrer.id)
        agent = _make_agent()
        new_affiliate = _make_affiliate(
            affiliate_type="agent",
            referred_by_affiliate_id=referrer.id,
            referral_depth=2,
        )

        mock_repo.get_affiliate_by_slug = AsyncMock(return_value=None)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.get_affiliate_by_agent_id = AsyncMock(return_value=None)
        mock_repo.get_attribution_by_entity = AsyncMock(return_value=attribution)
        mock_repo.get_affiliate_by_id = AsyncMock(return_value=referrer)
        mock_repo.create_affiliate = AsyncMock(return_value=new_affiliate)

        result = await service.register_affiliate(
            db,
            user_id=FAKE_USER_ID,
            affiliate_type="agent",
            agent_id=FAKE_AGENT_ID,
            slug="child-bot",
        )

        assert result["referral_depth"] == 2


# ===========================================================================
# Ownership boundary tests
# ===========================================================================


class TestAffiliateOwnership:
    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_agent_lookup_requires_owner(self, mock_repo):
        """Agent-scoped lookups must be limited to the agent owner."""
        db = AsyncMock()
        mock_repo.get_agent_by_id = AsyncMock(
            return_value=_make_agent(owner_user_id=uuid4())
        )

        with pytest.raises(AffiliateNotFoundError):
            await service.get_my_affiliate(
                db,
                user_id=FAKE_USER_ID,
                agent_id=FAKE_AGENT_ID,
            )

        mock_repo.get_affiliate_by_agent_id.assert_not_called()

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_agent_lookup_owner_allowed(self, mock_repo):
        db = AsyncMock()
        affiliate = _make_affiliate(affiliate_type="agent", agent_id=FAKE_AGENT_ID)
        mock_repo.get_agent_by_id = AsyncMock(
            return_value=_make_agent(owner_user_id=FAKE_USER_ID)
        )
        mock_repo.get_affiliate_by_agent_id = AsyncMock(return_value=affiliate)

        result = await service.get_my_affiliate(
            db,
            user_id=FAKE_USER_ID,
            agent_id=FAKE_AGENT_ID,
        )

        assert result["id"] == str(affiliate.id)


# ===========================================================================
# Affiliate profile updates
# ===========================================================================


class TestUpdateAffiliate:
    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_update_slug_taken(self, mock_repo):
        db = AsyncMock()
        affiliate = _make_affiliate(slug="current-slug")
        mock_repo.get_affiliate_by_user_id = AsyncMock(return_value=affiliate)
        mock_repo.get_affiliate_by_slug = AsyncMock(return_value=_make_affiliate())

        with pytest.raises(SlugAlreadyExistsError):
            await service.update_my_affiliate(
                db,
                user_id=FAKE_USER_ID,
                slug="taken-slug",
            )

        mock_repo.update_affiliate.assert_not_called()

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_update_same_slug_skips_uniqueness_lookup(self, mock_repo):
        db = AsyncMock()
        affiliate = _make_affiliate(slug="same-slug")
        mock_repo.get_affiliate_by_user_id = AsyncMock(return_value=affiliate)
        mock_repo.update_affiliate = AsyncMock(return_value=affiliate)

        result = await service.update_my_affiliate(
            db,
            user_id=FAKE_USER_ID,
            slug="same-slug",
        )

        assert result["slug"] == "same-slug"
        mock_repo.get_affiliate_by_slug.assert_not_called()
        update_kwargs = mock_repo.update_affiliate.await_args.kwargs
        assert update_kwargs == {"slug": "same-slug"}

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_update_only_passes_explicit_fields(self, mock_repo):
        db = AsyncMock()
        affiliate = _make_affiliate(slug="current-slug")
        updated = _make_affiliate(
            slug="current-slug",
            payout_wallet_address="0x" + "a" * 40,
            payout_chain="eip155:8453",
            is_active=False,
        )
        mock_repo.get_affiliate_by_user_id = AsyncMock(return_value=affiliate)
        mock_repo.update_affiliate = AsyncMock(return_value=updated)

        result = await service.update_my_affiliate(
            db,
            user_id=FAKE_USER_ID,
            payout_wallet_address="0x" + "a" * 40,
            is_active=False,
        )

        assert result["is_active"] is False
        update_kwargs = mock_repo.update_affiliate.await_args.kwargs
        assert update_kwargs == {
            "payout_wallet_address": "0x" + "a" * 40,
            "is_active": False,
        }


# ===========================================================================
# Click tracking tests
# ===========================================================================


class TestRecordClick:
    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_record_click_success(self, mock_repo):
        db = AsyncMock()
        affiliate = _make_affiliate()
        click = _make_click()

        mock_repo.get_affiliate_by_slug = AsyncMock(return_value=affiliate)
        mock_repo.get_recent_click = AsyncMock(return_value=None)
        mock_repo.get_app_config = AsyncMock(return_value=None)
        mock_repo.create_click = AsyncMock(return_value=click)

        result = await service.record_click(
            db,
            slug="test-bot",
            application_id=FAKE_APP_ID,
            ip_address="1.2.3.4",
        )

        assert "click_id" in result
        assert result["affiliate_slug"] == "test-bot"

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_record_click_inactive_affiliate(self, mock_repo):
        db = AsyncMock()
        mock_repo.get_affiliate_by_slug = AsyncMock(
            return_value=_make_affiliate(is_active=False)
        )

        with pytest.raises(AffiliateNotFoundError):
            await service.record_click(
                db, slug="inactive", application_id=FAKE_APP_ID, ip_address="1.2.3.4"
            )

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_record_click_rate_limited(self, mock_repo):
        db = AsyncMock()
        mock_repo.get_affiliate_by_slug = AsyncMock(return_value=_make_affiliate())
        mock_repo.get_recent_click = AsyncMock(return_value=_make_click())

        with pytest.raises(ClickRateLimitedError):
            await service.record_click(
                db, slug="test-bot", application_id=FAKE_APP_ID, ip_address="1.2.3.4"
            )


# ===========================================================================
# Attribution tests
# ===========================================================================


class TestAttributeReferral:
    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_attribute_by_click_id(self, mock_repo):
        db = AsyncMock()
        affiliate = _make_affiliate()
        click = _make_click()
        attr = _make_attribution()

        mock_repo.get_attribution_by_entity = AsyncMock(return_value=None)
        mock_repo.get_click_by_id = AsyncMock(return_value=click)
        mock_repo.get_affiliate_by_id = AsyncMock(return_value=affiliate)
        mock_repo.get_agent_by_id = AsyncMock(return_value=None)
        mock_repo.create_attribution = AsyncMock(return_value=attr)
        mock_repo.update_click_conversion = AsyncMock()

        result = await service.attribute_referral(
            db,
            referred_entity_type="agent",
            referred_entity_id=uuid4(),
            click_id=FAKE_CLICK_ID,
            application_id=FAKE_APP_ID,
        )

        assert "attribution_id" in result

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_attribute_expired_click(self, mock_repo):
        db = AsyncMock()
        expired_click = _make_click(
            expires_at=datetime.now(UTC) - timedelta(hours=1)
        )

        mock_repo.get_attribution_by_entity = AsyncMock(return_value=None)
        mock_repo.get_click_by_id = AsyncMock(return_value=expired_click)

        with pytest.raises(ClickExpiredError):
            await service.attribute_referral(
                db,
                referred_entity_type="user",
                referred_entity_id=uuid4(),
                click_id=FAKE_CLICK_ID,
                application_id=FAKE_APP_ID,
            )

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_attribute_cross_app_click_fails_closed(self, mock_repo):
        db = AsyncMock()

        mock_repo.get_attribution_by_entity = AsyncMock(return_value=None)
        mock_repo.get_click_by_id = AsyncMock(return_value=None)

        with pytest.raises(ClickNotFoundError):
            await service.attribute_referral(
                db,
                referred_entity_type="user",
                referred_entity_id=uuid4(),
                click_id=FAKE_CLICK_ID,
                application_id=FAKE_APP_ID,
            )

        mock_repo.get_click_by_id.assert_awaited_once_with(
            db,
            FAKE_CLICK_ID,
            application_id=FAKE_APP_ID,
        )
        mock_repo.get_affiliate_by_id.assert_not_called()
        mock_repo.create_attribution.assert_not_called()

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_attribute_already_attributed(self, mock_repo):
        db = AsyncMock()
        mock_repo.get_attribution_by_entity = AsyncMock(
            return_value=_make_attribution()
        )

        with pytest.raises(AlreadyAttributedError):
            await service.attribute_referral(
                db,
                referred_entity_type="user",
                referred_entity_id=uuid4(),
                click_id=FAKE_CLICK_ID,
                application_id=FAKE_APP_ID,
            )

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_self_referral_blocked_user(self, mock_repo):
        db = AsyncMock()
        affiliate = _make_affiliate(user_id=FAKE_USER_ID)
        click = _make_click()

        mock_repo.get_attribution_by_entity = AsyncMock(return_value=None)
        mock_repo.get_click_by_id = AsyncMock(return_value=click)
        mock_repo.get_affiliate_by_id = AsyncMock(return_value=affiliate)

        with pytest.raises(SelfReferralError):
            await service.attribute_referral(
                db,
                referred_entity_type="user",
                referred_entity_id=FAKE_USER_ID,
                click_id=FAKE_CLICK_ID,
                application_id=FAKE_APP_ID,
            )

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_self_referral_blocked_agent_owner(self, mock_repo):
        """User owns the agent that's the affiliate — blocked."""
        db = AsyncMock()
        affiliate = _make_affiliate(
            affiliate_type="agent", agent_id=FAKE_AGENT_ID
        )
        click = _make_click()
        agent = _make_agent(owner_user_id=FAKE_USER_ID)

        mock_repo.get_attribution_by_entity = AsyncMock(return_value=None)
        mock_repo.get_click_by_id = AsyncMock(return_value=click)
        mock_repo.get_affiliate_by_id = AsyncMock(return_value=affiliate)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        with pytest.raises(SelfReferralError):
            await service.attribute_referral(
                db,
                referred_entity_type="user",
                referred_entity_id=FAKE_USER_ID,
                click_id=FAKE_CLICK_ID,
                application_id=FAKE_APP_ID,
            )

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_attribute_triggers_webhook_event(self, mock_repo):
        db = AsyncMock()
        affiliate = _make_affiliate()
        click = _make_click()
        attr = _make_attribution(affiliate_id=affiliate.id)

        mock_repo.get_attribution_by_entity = AsyncMock(return_value=None)
        mock_repo.get_click_by_id = AsyncMock(return_value=click)
        mock_repo.get_affiliate_by_id = AsyncMock(return_value=affiliate)
        mock_repo.get_agent_by_id = AsyncMock(return_value=None)
        mock_repo.create_attribution = AsyncMock(return_value=attr)
        mock_repo.update_click_conversion = AsyncMock()

        with patch(_WEBHOOK_TRIGGER, new_callable=AsyncMock, create=True) as mock_trigger:
            await service.attribute_referral(
                db,
                referred_entity_type="user",
                referred_entity_id=uuid4(),
                click_id=FAKE_CLICK_ID,
                application_id=FAKE_APP_ID,
            )

        mock_trigger.assert_called_once()
        assert mock_trigger.call_args.kwargs["event_type"] == "REFERRAL_ATTRIBUTED"


# ===========================================================================
# Commission chain walker tests
# ===========================================================================


class TestProcessCommissions:
    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_no_attribution_no_commissions(self, mock_repo):
        db = AsyncMock()
        mock_repo.get_attribution_by_entity = AsyncMock(return_value=None)

        result = await service.process_commissions(
            db,
            payer_entity_type="agent",
            payer_entity_id=uuid4(),
            payment_amount_cents=500,
            payment_event_type="x402_topup",
            payment_reference="0xabc",
            application_id=FAKE_APP_ID,
        )

        assert result["commissions"] == []

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_single_level_commission(self, mock_repo):
        db = AsyncMock()
        l1 = _make_affiliate(credit_balance_cents=0)
        l1.referred_by_affiliate_id = None
        attr = _make_attribution(affiliate_id=l1.id)

        mock_repo.get_attribution_by_entity = AsyncMock(return_value=attr)
        mock_repo.get_affiliate_by_id = AsyncMock(return_value=l1)
        mock_repo.get_app_config = AsyncMock(return_value=None)
        mock_repo.get_commission_by_reference = AsyncMock(return_value=None)
        mock_repo.create_commission = AsyncMock(return_value=_make_commission())
        mock_repo.credit_affiliate_balance = AsyncMock()

        result = await service.process_commissions(
            db,
            payer_entity_type="agent",
            payer_entity_id=uuid4(),
            payment_amount_cents=500,
            payment_event_type="x402_topup",
            payment_reference="0xabc",
            application_id=FAKE_APP_ID,
        )

        assert len(result["commissions"]) == 1
        assert result["commissions"][0]["level"] == 1
        assert result["commissions"][0]["amount_cents"] == 50  # 500 * 1000/10000

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_three_level_chain(self, mock_repo):
        db = AsyncMock()
        l3 = _make_affiliate(affiliate_id=uuid4(), credit_balance_cents=0)
        l3.referred_by_affiliate_id = None
        l2 = _make_affiliate(
            affiliate_id=uuid4(),
            credit_balance_cents=0,
            referred_by_affiliate_id=l3.id,
        )
        l2.referred_by_affiliate_id = l3.id
        l1 = _make_affiliate(
            affiliate_id=uuid4(),
            credit_balance_cents=0,
            referred_by_affiliate_id=l2.id,
        )
        l1.referred_by_affiliate_id = l2.id
        attr = _make_attribution(affiliate_id=l1.id)

        # Chain: payer → l1 → l2 → l3
        affiliate_map = {l1.id: l1, l2.id: l2, l3.id: l3}

        mock_repo.get_attribution_by_entity = AsyncMock(return_value=attr)
        mock_repo.get_affiliate_by_id = AsyncMock(side_effect=lambda db, aid: affiliate_map.get(aid))
        mock_repo.get_app_config = AsyncMock(return_value=None)
        mock_repo.get_commission_by_reference = AsyncMock(return_value=None)
        mock_repo.create_commission = AsyncMock(return_value=_make_commission())
        mock_repo.credit_affiliate_balance = AsyncMock()

        result = await service.process_commissions(
            db,
            payer_entity_type="agent",
            payer_entity_id=uuid4(),
            payment_amount_cents=1000,
            payment_event_type="x402_topup",
            payment_reference="0xdef",
            application_id=FAKE_APP_ID,
        )

        assert len(result["commissions"]) == 3
        levels = [c["level"] for c in result["commissions"]]
        assert levels == [1, 2, 3]

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_skip_inactive_affiliate_continue_chain(self, mock_repo):
        db = AsyncMock()
        l2 = _make_affiliate(affiliate_id=uuid4(), credit_balance_cents=0)
        l2.referred_by_affiliate_id = None
        l1 = _make_affiliate(
            affiliate_id=uuid4(),
            credit_balance_cents=0,
            is_active=False,
            referred_by_affiliate_id=l2.id,
        )
        l1.referred_by_affiliate_id = l2.id
        attr = _make_attribution(affiliate_id=l1.id)

        affiliate_map = {l1.id: l1, l2.id: l2}

        mock_repo.get_attribution_by_entity = AsyncMock(return_value=attr)
        mock_repo.get_affiliate_by_id = AsyncMock(side_effect=lambda db, aid: affiliate_map.get(aid))
        mock_repo.get_app_config = AsyncMock(return_value=None)
        mock_repo.get_commission_by_reference = AsyncMock(return_value=None)
        mock_repo.create_commission = AsyncMock(return_value=_make_commission())
        mock_repo.credit_affiliate_balance = AsyncMock()

        result = await service.process_commissions(
            db,
            payer_entity_type="agent",
            payer_entity_id=uuid4(),
            payment_amount_cents=500,
            payment_event_type="x402_topup",
            payment_reference="0xghi",
            application_id=FAKE_APP_ID,
        )

        # L1 is inactive → skipped. L2 gets commission at level 2.
        assert len(result["commissions"]) == 1
        assert result["commissions"][0]["level"] == 2

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_zero_cent_commission_skipped(self, mock_repo):
        db = AsyncMock()
        l1 = _make_affiliate(credit_balance_cents=0)
        l1.referred_by_affiliate_id = None
        attr = _make_attribution(affiliate_id=l1.id)

        mock_repo.get_attribution_by_entity = AsyncMock(return_value=attr)
        mock_repo.get_affiliate_by_id = AsyncMock(return_value=l1)
        mock_repo.get_app_config = AsyncMock(return_value=None)

        result = await service.process_commissions(
            db,
            payer_entity_type="agent",
            payer_entity_id=uuid4(),
            payment_amount_cents=1,  # 1 cent * 10% = 0.001 → rounds to 0
            payment_event_type="x402_topup",
            payment_reference="0xtiny",
            application_id=FAKE_APP_ID,
        )

        assert result["commissions"] == []

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_idempotent_duplicate_reference(self, mock_repo):
        db = AsyncMock()
        l1 = _make_affiliate(credit_balance_cents=0)
        l1.referred_by_affiliate_id = None
        attr = _make_attribution(affiliate_id=l1.id)
        existing_commission = _make_commission()

        mock_repo.get_attribution_by_entity = AsyncMock(return_value=attr)
        mock_repo.get_affiliate_by_id = AsyncMock(return_value=l1)
        mock_repo.get_app_config = AsyncMock(return_value=None)
        mock_repo.get_commission_by_reference = AsyncMock(return_value=existing_commission)

        result = await service.process_commissions(
            db,
            payer_entity_type="agent",
            payer_entity_id=uuid4(),
            payment_amount_cents=500,
            payment_event_type="x402_topup",
            payment_reference="0xduplicate",
            application_id=FAKE_APP_ID,
        )

        # Returns existing commission, doesn't create new one
        assert len(result["commissions"]) == 1
        mock_repo.create_commission.assert_not_called()

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_app_disabled_no_commissions(self, mock_repo):
        db = AsyncMock()
        l1 = _make_affiliate()
        attr = _make_attribution(affiliate_id=l1.id)
        config = MagicMock()
        config.enabled = False

        mock_repo.get_attribution_by_entity = AsyncMock(return_value=attr)
        mock_repo.get_affiliate_by_id = AsyncMock(return_value=l1)
        mock_repo.get_app_config = AsyncMock(return_value=config)

        result = await service.process_commissions(
            db,
            payer_entity_type="agent",
            payer_entity_id=uuid4(),
            payment_amount_cents=500,
            payment_event_type="x402_topup",
            payment_reference="0xno",
            application_id=FAKE_APP_ID,
        )

        assert result["commissions"] == []

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_process_commissions_triggers_webhook_event(self, mock_repo):
        db = AsyncMock()
        l1 = _make_affiliate(credit_balance_cents=0, slug="l1-bot")
        attr = _make_attribution(affiliate_id=l1.id)

        mock_repo.get_attribution_by_entity = AsyncMock(return_value=attr)
        mock_repo.get_affiliate_by_id = AsyncMock(return_value=l1)
        mock_repo.get_app_config = AsyncMock(return_value=None)
        mock_repo.get_commission_by_reference = AsyncMock(return_value=None)
        mock_repo.create_commission = AsyncMock(return_value=_make_commission())
        mock_repo.credit_affiliate_balance = AsyncMock()

        with patch(_WEBHOOK_TRIGGER, new_callable=AsyncMock, create=True) as mock_trigger:
            await service.process_commissions(
                db,
                payer_entity_type="user",
                payer_entity_id=uuid4(),
                payment_amount_cents=500,
                payment_event_type="stripe_onetime",
                payment_reference="pi_123",
                application_id=FAKE_APP_ID,
            )

        mock_trigger.assert_called_once()
        assert (
            mock_trigger.call_args.kwargs["event_type"]
            == "AFFILIATE_COMMISSION_EARNED"
        )


# ===========================================================================
# Commission enrichment tests
# ===========================================================================


class TestGetCommissions:
    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_commission_enrichment(self, mock_repo):
        """Commission list enriches source_slug and application_name."""
        db = AsyncMock()
        affiliate = _make_affiliate(credit_balance_cents=5000)
        commission = _make_commission(affiliate_id=affiliate.id)
        commission.application_id = FAKE_APP_ID

        source_affiliate = _make_affiliate(
            affiliate_id=uuid4(), slug="payer-bot", affiliate_type="agent"
        )
        app_mock = MagicMock()
        app_mock.name = "OpenClaw"

        mock_repo.get_affiliate_by_user_id = AsyncMock(return_value=affiliate)
        mock_repo.list_commissions = AsyncMock(return_value=[commission])
        mock_repo.count_commissions = AsyncMock(return_value=1)
        mock_repo.sum_commissions_by_level = AsyncMock(return_value={1: 50})
        mock_repo.get_affiliate_by_agent_id = AsyncMock(return_value=source_affiliate)
        mock_repo.get_application_by_id = AsyncMock(return_value=app_mock)

        result = await service.get_commissions(
            db, user_id=FAKE_USER_ID, limit=20, offset=0
        )

        assert result["commissions"][0]["source_slug"] == "payer-bot"
        assert result["commissions"][0]["application_name"] == "OpenClaw"

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_commission_enrichment_no_affiliate(self, mock_repo):
        """source_slug is None when payer has no affiliate record."""
        db = AsyncMock()
        affiliate = _make_affiliate(credit_balance_cents=5000)
        commission = _make_commission(affiliate_id=affiliate.id)
        commission.source_entity_type = "user"
        commission.application_id = FAKE_APP_ID

        mock_repo.get_affiliate_by_user_id = AsyncMock(
            side_effect=lambda db, uid: affiliate if uid == FAKE_USER_ID else None
        )
        mock_repo.list_commissions = AsyncMock(return_value=[commission])
        mock_repo.count_commissions = AsyncMock(return_value=1)
        mock_repo.sum_commissions_by_level = AsyncMock(return_value={1: 50})
        mock_repo.get_application_by_id = AsyncMock(return_value=None)

        result = await service.get_commissions(
            db, user_id=FAKE_USER_ID, limit=20, offset=0
        )

        assert result["commissions"][0]["source_slug"] is None
        assert result["commissions"][0]["application_name"] is None


# ===========================================================================
# Payout tests
# ===========================================================================


class TestRequestPayout:
    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_request_payout_success(self, mock_repo):
        db = AsyncMock()
        affiliate = _make_affiliate(
            credit_balance_cents=10000,
            payout_wallet_address="0x" + "a" * 40,
            payout_chain="eip155:8453",
        )
        payout = _make_payout()

        mock_repo.get_affiliate_by_user_id = AsyncMock(return_value=affiliate)
        mock_repo.get_app_config = AsyncMock(return_value=None)
        mock_repo.get_active_payout = AsyncMock(return_value=None)
        mock_repo.create_payout = AsyncMock(return_value=payout)

        result = await service.request_payout(
            db,
            user_id=FAKE_USER_ID,
            amount_cents=5000,
            application_id=FAKE_APP_ID,
        )

        assert result["status"] == "requested"

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_request_payout_no_wallet(self, mock_repo):
        db = AsyncMock()
        affiliate = _make_affiliate(credit_balance_cents=10000)

        mock_repo.get_affiliate_by_user_id = AsyncMock(return_value=affiliate)

        with pytest.raises(PayoutWalletNotSetError):
            await service.request_payout(
                db, user_id=FAKE_USER_ID, amount_cents=5000, application_id=FAKE_APP_ID
            )

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_request_payout_below_minimum(self, mock_repo):
        db = AsyncMock()
        affiliate = _make_affiliate(
            credit_balance_cents=10000,
            payout_wallet_address="0x" + "a" * 40,
            payout_chain="eip155:8453",
        )

        mock_repo.get_affiliate_by_user_id = AsyncMock(return_value=affiliate)
        mock_repo.get_app_config = AsyncMock(return_value=None)

        with pytest.raises(InsufficientBalanceError):
            await service.request_payout(
                db, user_id=FAKE_USER_ID, amount_cents=100, application_id=FAKE_APP_ID
            )

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_request_payout_exceeds_balance(self, mock_repo):
        db = AsyncMock()
        affiliate = _make_affiliate(
            credit_balance_cents=3000,
            payout_wallet_address="0x" + "a" * 40,
            payout_chain="eip155:8453",
        )

        mock_repo.get_affiliate_by_user_id = AsyncMock(return_value=affiliate)
        mock_repo.get_app_config = AsyncMock(return_value=None)

        with pytest.raises(InsufficientBalanceError):
            await service.request_payout(
                db, user_id=FAKE_USER_ID, amount_cents=5000, application_id=FAKE_APP_ID
            )

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_request_payout_active_payout_blocks(self, mock_repo):
        db = AsyncMock()
        affiliate = _make_affiliate(
            credit_balance_cents=10000,
            payout_wallet_address="0x" + "a" * 40,
            payout_chain="eip155:8453",
        )

        mock_repo.get_affiliate_by_user_id = AsyncMock(return_value=affiliate)
        mock_repo.get_app_config = AsyncMock(return_value=None)
        mock_repo.get_active_payout = AsyncMock(return_value=_make_payout())

        with pytest.raises(InsufficientBalanceError):
            await service.request_payout(
                db, user_id=FAKE_USER_ID, amount_cents=5000, application_id=FAKE_APP_ID
            )


# ===========================================================================
# Admin payout tests
# ===========================================================================


class TestAdminPayouts:
    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_approve_payout(self, mock_repo):
        db = AsyncMock()
        payout = _make_payout(status="requested")
        mock_repo.get_payout_by_id = AsyncMock(return_value=payout)
        mock_repo.update_payout = AsyncMock(return_value=payout)

        result = await service.approve_payout(
            db, payout_id=payout.id, admin_user_id=uuid4()
        )

        assert result["status"] == "approved"

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_approve_payout_not_pending(self, mock_repo):
        db = AsyncMock()
        payout = _make_payout(status="approved")
        mock_repo.get_payout_by_id = AsyncMock(return_value=payout)

        with pytest.raises(PayoutNotPendingError):
            await service.approve_payout(
                db, payout_id=payout.id, admin_user_id=uuid4()
            )

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_complete_payout(self, mock_repo):
        db = AsyncMock()
        payout = _make_payout(status="approved")
        mock_repo.get_payout_by_id = AsyncMock(return_value=payout)
        mock_repo.update_payout = AsyncMock(return_value=payout)
        mock_repo.get_affiliate_by_id = AsyncMock(return_value=None)

        result = await service.complete_payout(
            db, payout_id=payout.id, tx_hash="0xabc", application_id=FAKE_APP_ID
        )

        assert result["status"] == "completed"
        assert result["tx_hash"] == "0xabc"

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_complete_payout_not_approved(self, mock_repo):
        db = AsyncMock()
        payout = _make_payout(status="requested")
        mock_repo.get_payout_by_id = AsyncMock(return_value=payout)

        with pytest.raises(PayoutNotApprovedError):
            await service.complete_payout(
                db, payout_id=payout.id, tx_hash="0xabc", application_id=FAKE_APP_ID
            )

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_complete_payout_triggers_webhook_event(self, mock_repo):
        db = AsyncMock()
        payout = _make_payout(status="approved")
        affiliate = _make_affiliate(slug="test-bot", credit_balance_cents=900)
        mock_repo.get_payout_by_id = AsyncMock(return_value=payout)
        mock_repo.update_payout = AsyncMock(return_value=payout)
        mock_repo.get_affiliate_by_id = AsyncMock(return_value=affiliate)

        with patch(_WEBHOOK_TRIGGER, new_callable=AsyncMock, create=True) as mock_trigger:
            await service.complete_payout(
                db,
                payout_id=payout.id,
                tx_hash="0xabc",
                application_id=FAKE_APP_ID,
            )

        mock_trigger.assert_called_once()
        assert mock_trigger.call_args.kwargs["event_type"] == "AFFILIATE_PAYOUT_COMPLETED"

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_deny_payout_refunds_balance(self, mock_repo):
        db = AsyncMock()
        payout = _make_payout(status="requested")
        mock_repo.get_payout_by_id = AsyncMock(return_value=payout)
        mock_repo.update_payout = AsyncMock(return_value=payout)
        mock_repo.refund_payout_to_balance = AsyncMock()

        result = await service.deny_payout(
            db, payout_id=payout.id, reason="Suspicious"
        )

        assert result["status"] == "denied"
        mock_repo.refund_payout_to_balance.assert_called_once()

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_fail_payout_refunds_balance(self, mock_repo):
        db = AsyncMock()
        payout = _make_payout(status="approved")
        mock_repo.get_payout_by_id = AsyncMock(return_value=payout)
        mock_repo.update_payout = AsyncMock(return_value=payout)
        mock_repo.refund_payout_to_balance = AsyncMock()

        result = await service.fail_payout(
            db, payout_id=payout.id, reason="TX failed"
        )

        assert result["status"] == "failed"
        mock_repo.refund_payout_to_balance.assert_called_once()

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_deny_payout_passes_payout_to_refund(self, mock_repo):
        """Verify refund_payout_to_balance receives the payout so it can reverse lifetime counter."""
        db = AsyncMock()
        payout = _make_payout(status="requested", amount_cents=3000)
        mock_repo.get_payout_by_id = AsyncMock(return_value=payout)
        mock_repo.update_payout = AsyncMock(return_value=payout)
        mock_repo.refund_payout_to_balance = AsyncMock()

        await service.deny_payout(db, payout_id=payout.id, reason="Test")

        mock_repo.refund_payout_to_balance.assert_called_once_with(db, payout)

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_fail_payout_passes_payout_to_refund(self, mock_repo):
        """Verify refund_payout_to_balance receives the payout so it can reverse lifetime counter."""
        db = AsyncMock()
        payout = _make_payout(status="approved", amount_cents=3000)
        mock_repo.get_payout_by_id = AsyncMock(return_value=payout)
        mock_repo.update_payout = AsyncMock(return_value=payout)
        mock_repo.refund_payout_to_balance = AsyncMock()

        await service.fail_payout(db, payout_id=payout.id, reason="TX failed")

        mock_repo.refund_payout_to_balance.assert_called_once_with(db, payout)

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_payout_not_found(self, mock_repo):
        db = AsyncMock()
        mock_repo.get_payout_by_id = AsyncMock(return_value=None)

        with pytest.raises(PayoutNotFoundError):
            await service.approve_payout(
                db, payout_id=uuid4(), admin_user_id=uuid4()
            )


# ===========================================================================
# App config tests
# ===========================================================================


class TestAffiliateConfig:
    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_get_config_defaults(self, mock_repo):
        db = AsyncMock()
        mock_repo.get_app_config = AsyncMock(return_value=None)

        result = await service.get_affiliate_config(db, application_id=FAKE_APP_ID)

        assert result["l1_rate_bps"] == 1000
        assert result["l2_rate_bps"] == 500
        assert result["l3_rate_bps"] == 200
        assert result["enabled"] is True

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_update_config_admin(self, mock_repo):
        db = AsyncMock()
        config = MagicMock()
        config.enabled = True
        config.l1_rate_bps = 1200
        config.l2_rate_bps = 600
        config.l3_rate_bps = 300
        config.attribution_window_days = 30
        config.min_payout_cents = 2500
        config.updated_at = datetime.now(UTC)

        mock_repo.upsert_app_config = AsyncMock(return_value=config)

        result = await service.update_affiliate_config(
            db,
            application_id=FAKE_APP_ID,
            user_id=uuid4(),
            is_admin=True,
            enabled=True,
            l1_rate_bps=1200,
            l2_rate_bps=600,
            l3_rate_bps=300,
            attribution_window_days=30,
            min_payout_cents=2500,
        )

        assert result["l1_rate_bps"] == 1200

    @pytest.mark.asyncio
    @patch(_REPO)
    async def test_update_config_not_owner(self, mock_repo):
        db = AsyncMock()
        mock_repo.get_application_owner_id = AsyncMock(return_value=uuid4())

        with pytest.raises(NotApplicationOwnerError):
            await service.update_affiliate_config(
                db,
                application_id=FAKE_APP_ID,
                user_id=FAKE_USER_ID,
                is_admin=False,
                enabled=True,
                l1_rate_bps=1000,
                l2_rate_bps=500,
                l3_rate_bps=200,
                attribution_window_days=30,
                min_payout_cents=2500,
            )


# ===========================================================================
# Repository: refund_payout_to_balance accounting
# ===========================================================================


class TestRefundPayoutAccounting:
    """Direct repository test for payout refund accounting."""

    @pytest.mark.asyncio
    async def test_refund_reverses_lifetime_paid_out(self):
        """Denied/failed payouts must reverse lifetime_paid_out_cents."""
        from spaps_server_quickstart.domains.affiliate_referrals import repository as repo

        db = AsyncMock()
        affiliate = _make_affiliate(credit_balance_cents=5000)
        affiliate.lifetime_paid_out_cents = 3000

        payout = _make_payout(amount_cents=3000)

        # Mock get_affiliate_by_id to return our affiliate
        with patch.object(repo, "get_affiliate_by_id", new=AsyncMock(return_value=affiliate)):
            await repo.refund_payout_to_balance(db, payout)

        assert affiliate.credit_balance_cents == 8000  # 5000 + 3000
        assert affiliate.lifetime_paid_out_cents == 0  # 3000 - 3000
