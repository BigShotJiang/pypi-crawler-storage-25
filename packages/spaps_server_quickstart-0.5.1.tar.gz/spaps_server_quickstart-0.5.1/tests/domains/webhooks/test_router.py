"""Unit tests for the webhooks domain routers (HTTP layer).

Each test creates a minimal FastAPI test app with dependency overrides for
the database session and application. The webhooks service layer is fully
mocked so tests exercise only routing, request validation, status codes,
and response shapes.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.webhooks.router import (
    mailgun_router,
    webhooks_router,
)
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_db_session,
)

# ---------------------------------------------------------------------------
# Helpers / Constants
# ---------------------------------------------------------------------------

FAKE_APP_ID = str(uuid4())
FAKE_WEBHOOK_ID = str(uuid4())

_WH_SERVICE = "spaps_server_quickstart.domains.webhooks.service"


def _fake_webhook(
    webhook_id: str | None = None,
    url: str = "https://example.com/hook",
    events: list[str] | None = None,
    include_secret: bool = False,
) -> dict:
    """Return a realistic webhook dict."""
    webhook = {
        "id": webhook_id or FAKE_WEBHOOK_ID,
        "application_id": FAKE_APP_ID,
        "url": url,
        "events": events or ["user.registered"],
        "is_active": True,
        "headers": {},
        "retry_config": {"max_attempts": 3, "initial_delay_ms": 1000, "max_delay_ms": 10000},
        "created_at": datetime.now(UTC).isoformat(),
        "updated_at": datetime.now(UTC).isoformat(),
    }
    if include_secret:
        webhook["secret"] = "a" * 64
    return webhook


def _fake_delivery(event_type: str = "user.registered") -> dict:
    """Return a realistic delivery dict."""
    return {
        "id": str(uuid4()),
        "webhook_id": FAKE_WEBHOOK_ID,
        "event_type": event_type,
        "payload": {"type": event_type},
        "response_status": 200,
        "response_body": "OK",
        "delivered_at": datetime.now(UTC).isoformat(),
        "retry_count": 0,
        "attempt": 1,
        "error_message": None,
    }


def _fake_application():
    """Return a mock application."""
    app = MagicMock()
    app.id = FAKE_APP_ID
    app.name = "Test App"
    return app


def _create_test_app():
    """Create a FastAPI test app with both routers and overridden deps."""
    app = FastAPI()

    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    settings.is_spaps_local_mode = False
    app.state.settings = settings

    install_error_handlers(app)
    app.include_router(webhooks_router)
    app.include_router(mailgun_router)

    mock_db = AsyncMock()

    async def override_db_session():
        yield mock_db

    app.dependency_overrides[get_db_session] = override_db_session
    app.dependency_overrides[get_application] = _fake_application

    return app


@pytest.fixture
def test_app():
    return _create_test_app()


@pytest.fixture
async def client(test_app):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ===========================================================================
# GET /webhooks
# ===========================================================================


class TestListWebhooks:
    @patch(f"{_WH_SERVICE}.list_webhooks", new_callable=AsyncMock)
    async def test_success(self, mock_list, client: AsyncClient):
        """GET /webhooks returns webhooks and total."""
        mock_list.return_value = {
            "webhooks": [_fake_webhook(include_secret=True)],
            "total": 1,
        }

        resp = await client.get("/webhooks")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert len(data["webhooks"]) == 1
        assert "secret" not in data["webhooks"][0]

    @patch(f"{_WH_SERVICE}.list_webhooks", new_callable=AsyncMock)
    async def test_empty(self, mock_list, client: AsyncClient):
        """GET /webhooks with no webhooks returns empty list."""
        mock_list.return_value = {"webhooks": [], "total": 0}

        resp = await client.get("/webhooks")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0
        assert data["webhooks"] == []


# ===========================================================================
# POST /webhooks
# ===========================================================================


class TestCreateWebhook:
    @patch(f"{_WH_SERVICE}.create_webhook", new_callable=AsyncMock)
    async def test_success(self, mock_create, client: AsyncClient):
        """POST /webhooks creates webhook and returns 201."""
        mock_create.return_value = {
            "webhook": _fake_webhook(include_secret=True),
            "signing_secret": "s" * 64,
            "message": "Webhook registered successfully",
        }

        resp = await client.post(
            "/webhooks",
            json={
                "url": "https://example.com/hook",
                "events": ["user.registered"],
            },
        )

        assert resp.status_code == 201
        data = resp.json()
        assert data["webhook"]["url"] == "https://example.com/hook"
        assert "secret" not in data["webhook"]
        assert data["signing_secret"] == "s" * 64
        assert data["message"] == "Webhook registered successfully"

    async def test_missing_url_returns_400(self, client: AsyncClient):
        """POST /webhooks without url returns 400."""
        resp = await client.post(
            "/webhooks",
            json={"events": ["user.registered"]},
        )
        assert resp.status_code == 400

    async def test_missing_events_returns_400(self, client: AsyncClient):
        """POST /webhooks without events returns 400."""
        resp = await client.post(
            "/webhooks",
            json={"url": "https://example.com/hook"},
        )
        assert resp.status_code == 400

    @patch(f"{_WH_SERVICE}.create_webhook", new_callable=AsyncMock)
    async def test_invalid_url_returns_400(self, mock_create, client: AsyncClient):
        """POST /webhooks with invalid URL scheme returns 400."""
        from spaps_server_quickstart.domains.webhooks.errors import InvalidWebhookUrlError

        mock_create.side_effect = InvalidWebhookUrlError()

        resp = await client.post(
            "/webhooks",
            json={
                "url": "ftp://bad.com",
                "events": ["user.registered"],
            },
        )

        assert resp.status_code == 400

    @patch(f"{_WH_SERVICE}.create_webhook", new_callable=AsyncMock)
    async def test_invalid_event_type_returns_400(self, mock_create, client: AsyncClient):
        """POST /webhooks with invalid event type returns 400."""
        from spaps_server_quickstart.domains.webhooks.errors import InvalidEventTypeError

        mock_create.side_effect = InvalidEventTypeError()

        resp = await client.post(
            "/webhooks",
            json={
                "url": "https://example.com/hook",
                "events": ["bad.event"],
            },
        )

        assert resp.status_code == 400

    @patch(f"{_WH_SERVICE}.create_webhook", new_callable=AsyncMock)
    async def test_with_headers(self, mock_create, client: AsyncClient):
        """POST /webhooks with custom headers."""
        mock_create.return_value = {
            "webhook": _fake_webhook(),
            "signing_secret": "s" * 64,
            "message": "Webhook registered successfully",
        }

        resp = await client.post(
            "/webhooks",
            json={
                "url": "https://example.com/hook",
                "events": ["user.registered"],
                "headers": {"X-Custom": "value"},
            },
        )

        assert resp.status_code == 201


# ===========================================================================
# PUT /webhooks/{webhookId}
# ===========================================================================


class TestUpdateWebhook:
    @patch(f"{_WH_SERVICE}.update_webhook", new_callable=AsyncMock)
    async def test_success(self, mock_update, client: AsyncClient):
        """PUT /webhooks/{id} updates and returns webhook."""
        mock_update.return_value = {
            "webhook": _fake_webhook(url="https://new.com/hook", include_secret=True),
        }

        resp = await client.put(
            f"/webhooks/{FAKE_WEBHOOK_ID}",
            json={"url": "https://new.com/hook"},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["webhook"]["url"] == "https://new.com/hook"
        assert "secret" not in data["webhook"]

    @patch(f"{_WH_SERVICE}.update_webhook", new_callable=AsyncMock)
    async def test_not_found_returns_404(self, mock_update, client: AsyncClient):
        """PUT /webhooks/{id} returns 404 for unknown webhook."""
        from spaps_server_quickstart.domains.webhooks.errors import WebhookNotFoundError

        mock_update.side_effect = WebhookNotFoundError()

        resp = await client.put(
            f"/webhooks/{uuid4()}",
            json={"url": "https://new.com/hook"},
        )

        assert resp.status_code == 404

    @patch(f"{_WH_SERVICE}.update_webhook", new_callable=AsyncMock)
    async def test_update_is_active(self, mock_update, client: AsyncClient):
        """PUT /webhooks/{id} can update is_active."""
        wh = _fake_webhook(include_secret=True)
        wh["is_active"] = False
        mock_update.return_value = {"webhook": wh}

        resp = await client.put(
            f"/webhooks/{FAKE_WEBHOOK_ID}",
            json={"is_active": False},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["webhook"]["is_active"] is False
        assert "secret" not in data["webhook"]


# ===========================================================================
# DELETE /webhooks/{webhookId}
# ===========================================================================


class TestDeleteWebhook:
    @patch(f"{_WH_SERVICE}.delete_webhook", new_callable=AsyncMock)
    async def test_success(self, mock_delete, client: AsyncClient):
        """DELETE /webhooks/{id} deletes and returns message."""
        mock_delete.return_value = {
            "message": "Webhook deleted successfully",
            "webhook_id": FAKE_WEBHOOK_ID,
        }

        resp = await client.delete(f"/webhooks/{FAKE_WEBHOOK_ID}")

        assert resp.status_code == 200
        data = resp.json()
        assert "deleted" in data["message"].lower()
        assert data["webhook_id"] == FAKE_WEBHOOK_ID

    @patch(f"{_WH_SERVICE}.delete_webhook", new_callable=AsyncMock)
    async def test_not_found_returns_404(self, mock_delete, client: AsyncClient):
        """DELETE /webhooks/{id} returns 404 for unknown webhook."""
        from spaps_server_quickstart.domains.webhooks.errors import WebhookNotFoundError

        mock_delete.side_effect = WebhookNotFoundError()

        resp = await client.delete(f"/webhooks/{uuid4()}")

        assert resp.status_code == 404


# ===========================================================================
# GET /webhooks/{webhookId}/deliveries
# ===========================================================================


class TestListDeliveries:
    @patch(f"{_WH_SERVICE}.list_deliveries", new_callable=AsyncMock)
    async def test_success(self, mock_list, client: AsyncClient):
        """GET /webhooks/{id}/deliveries returns deliveries and total."""
        mock_list.return_value = {
            "deliveries": [_fake_delivery()],
            "total": 1,
        }

        resp = await client.get(f"/webhooks/{FAKE_WEBHOOK_ID}/deliveries")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert len(data["deliveries"]) == 1

    @patch(f"{_WH_SERVICE}.list_deliveries", new_callable=AsyncMock)
    async def test_with_limit(self, mock_list, client: AsyncClient):
        """GET /webhooks/{id}/deliveries with limit param."""
        mock_list.return_value = {"deliveries": [], "total": 0}

        resp = await client.get(
            f"/webhooks/{FAKE_WEBHOOK_ID}/deliveries",
            params={"limit": 10},
        )

        assert resp.status_code == 200

    @patch(f"{_WH_SERVICE}.list_deliveries", new_callable=AsyncMock)
    async def test_not_found_returns_404(self, mock_list, client: AsyncClient):
        """GET /webhooks/{id}/deliveries returns 404 for unknown webhook."""
        from spaps_server_quickstart.domains.webhooks.errors import WebhookNotFoundError

        mock_list.side_effect = WebhookNotFoundError()

        resp = await client.get(f"/webhooks/{uuid4()}/deliveries")

        assert resp.status_code == 404


# ===========================================================================
# GET /webhooks/events
# ===========================================================================


class TestListEventTypes:
    @patch(f"{_WH_SERVICE}.list_event_types", new_callable=AsyncMock)
    async def test_success(self, mock_list, client: AsyncClient):
        """GET /webhooks/events returns event types and total."""
        mock_list.return_value = {
            "events": [
                {"key": "user.registered", "value": "user.registered", "description": "User registered"},
            ],
            "total": 1,
        }

        resp = await client.get("/webhooks/events")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert data["events"][0]["key"] == "user.registered"


# ===========================================================================
# POST /webhooks/mailgun/events
# ===========================================================================


class TestMailgunEventHandler:
    @patch(f"{_WH_SERVICE}.process_mailgun_event")
    async def test_rejects_when_signing_key_missing(self, mock_process):
        """POST /webhooks/mailgun/events returns 500 when signing key not configured."""
        from spaps_server_quickstart.domains.webhooks.errors import WebhookNotConfiguredError

        app = _create_test_app()
        app.state.settings.mailgun_webhook_signing_key = ""

        mock_process.side_effect = WebhookNotConfiguredError(
            "Mailgun webhook signing key is not configured"
        )

        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/webhooks/mailgun/events",
                json={
                    "signature": {
                        "timestamp": "1234567890",
                        "token": "tok",
                        "signature": "sig",
                    },
                    "event-data": {
                        "event": "delivered",
                        "message": {
                            "headers": {"message-id": "msg-1"},
                        },
                    },
                },
            )

        assert resp.status_code == 500
        data = resp.json()
        assert data["success"] is False
        assert data["error"]["code"] == "WEBHOOK_NOT_CONFIGURED"

    @patch(f"{_WH_SERVICE}.process_mailgun_event")
    async def test_success_with_valid_signature(self, mock_process):
        """POST /webhooks/mailgun/events succeeds with valid signing key."""
        app = _create_test_app()
        app.state.settings.mailgun_webhook_signing_key = "test-key"

        mock_process.return_value = {
            "message": "Event processed",
            "event": "delivered",
            "status": "delivered",
            "email_log_updated": False,
        }

        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/webhooks/mailgun/events",
                json={
                    "signature": {
                        "timestamp": "1234567890",
                        "token": "tok",
                        "signature": "sig",
                    },
                    "event-data": {
                        "event": "delivered",
                        "message": {
                            "headers": {"message-id": "msg-1"},
                        },
                    },
                },
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert data["data"]["event"] == "delivered"
        assert data["data"]["status"] == "delivered"

    @patch(f"{_WH_SERVICE}.process_mailgun_event")
    async def test_invalid_signature_returns_401(self, mock_process):
        """POST /webhooks/mailgun/events returns 401 for bad signature."""
        from spaps_server_quickstart.domains.webhooks.errors import InvalidWebhookSignatureError

        app = _create_test_app()
        app.state.settings.mailgun_webhook_signing_key = "test-key"

        mock_process.side_effect = InvalidWebhookSignatureError(
            "Invalid Mailgun webhook signature"
        )

        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/webhooks/mailgun/events",
                json={
                    "signature": {
                        "timestamp": "123",
                        "token": "tok",
                        "signature": "bad",
                    },
                    "event-data": {
                        "event": "delivered",
                        "message": {"headers": {}},
                    },
                },
            )

        assert resp.status_code == 401

    @patch(f"{_WH_SERVICE}.process_mailgun_event")
    async def test_event_type_mapping(self, mock_process):
        """POST /webhooks/mailgun/events maps event types correctly."""
        app = _create_test_app()
        app.state.settings.mailgun_webhook_signing_key = "test-key"

        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            for event_type, expected_status in [
                ("delivered", "delivered"),
                ("opened", "opened"),
                ("clicked", "clicked"),
                ("complained", "complained"),
                ("failed", "failed"),
                ("bounced", "bounced"),
            ]:
                mock_process.return_value = {
                    "message": "Event processed",
                    "event": event_type,
                    "status": expected_status,
                    "email_log_updated": False,
                }

                resp = await client.post(
                    "/webhooks/mailgun/events",
                    json={
                        "signature": {"timestamp": "1", "token": "t", "signature": "s"},
                        "event-data": {
                            "event": event_type,
                            "message": {"headers": {}},
                        },
                    },
                )

                assert resp.status_code == 200
                data = resp.json()
                assert data["data"]["status"] == expected_status
