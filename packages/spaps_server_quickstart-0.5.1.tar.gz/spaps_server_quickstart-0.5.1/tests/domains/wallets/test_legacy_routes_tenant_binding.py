"""Regression tests for deprecated legacy wallet sign-in routes."""

from __future__ import annotations

from unittest.mock import MagicMock
from uuid import uuid4

from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

import pytest

from spaps_server_quickstart.domains.wallets.router import (
    ethereum_router,
    solana_router,
)
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import get_application

FAKE_SOLANA_WALLET_ADDRESS = "HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy"
FAKE_ETHEREUM_WALLET_ADDRESS = "0xa72bb7CeF1e4B2Cc144373d8dE0Add7CCc8DF4Ba"
FAKE_SIGNATURE = "fakesig123"
FAKE_MESSAGE = "SPAPS wants you to sign in"
VALIDATED_APPLICATION_ID = uuid4()


def _fake_application():
    app = MagicMock()
    app.id = VALIDATED_APPLICATION_ID
    app.name = "Validated App"
    return app


@pytest.fixture
def test_app():
    app = FastAPI()
    install_error_handlers(app)
    app.include_router(solana_router)
    app.include_router(ethereum_router)
    app.dependency_overrides[get_application] = _fake_application
    return app


@pytest.fixture
async def client(test_app):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


@pytest.mark.parametrize(
    ("path", "payload"),
    [
        (
            "/auth/solana/sign-in",
            {
                "wallet_address": FAKE_SOLANA_WALLET_ADDRESS,
                "signature": FAKE_SIGNATURE,
                "message": FAKE_MESSAGE,
            },
        ),
        (
            "/auth/ethereum/sign-in",
            {
                "wallet_address": FAKE_ETHEREUM_WALLET_ADDRESS,
                "signature": FAKE_SIGNATURE,
                "message": FAKE_MESSAGE,
            },
        ),
    ],
)
async def test_legacy_wallet_sign_in_routes_return_gone(
    client: AsyncClient, path: str, payload: dict[str, str]
):
    """Legacy wallet sign-in routes fail loudly with 410 Gone."""
    response = await client.post(
        path,
        json=payload,
    )

    assert response.status_code == 410
    assert "wallet-sign-in" in response.text
