"""Unit tests for the security domain repository layer.

Tests repository functions with mocked AsyncSession.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

from spaps_server_quickstart.domains.security import repository as repo
from spaps_server_quickstart.domains.security.models import SecurityAlert


def _mock_db():
    """Create a mocked AsyncSession."""
    db = AsyncMock()
    db.add = MagicMock()  # add() is synchronous in SQLAlchemy
    db.flush = AsyncMock()
    db.refresh = AsyncMock()
    return db


def _mock_alert(alert_type="rate_limit_exceeded", severity="warning"):
    """Create a mock security alert."""
    alert = MagicMock(spec=SecurityAlert)
    alert.id = uuid4()
    alert.application_id = uuid4()
    alert.alert_type = alert_type
    alert.severity = severity
    alert.timestamp = datetime.now(UTC)
    alert.details = {"ip": "1.2.3.4"}
    return alert


def _executed_sql(db, index: int) -> str:
    """Return the SQLAlchemy statement text for an executed statement."""
    stmt = db.execute.call_args_list[index].args[0]
    return str(stmt)


# ===========================================================================
# Alert Creation
# ===========================================================================


class TestCreateAlert:
    async def test_creates_and_returns(self):
        """create_alert adds alert to session and returns it."""
        db = _mock_db()

        result = await repo.create_alert(
            db,
            alert_type="rate_limit_exceeded",
            severity="warning",
            details={"ip": "1.2.3.4", "endpoint": "/api/test"},
        )

        assert result is not None
        assert isinstance(result, SecurityAlert)
        db.add.assert_called_once()
        db.flush.assert_called_once()
        db.refresh.assert_called_once()


# ===========================================================================
# Alert Queries
# ===========================================================================


class TestListAlerts:
    async def test_returns_alerts_and_count(self):
        """list_alerts returns alerts and total count."""
        alerts = [_mock_alert(), _mock_alert()]

        db = _mock_db()

        # Mock count query
        count_result = MagicMock()
        count_result.scalar_one.return_value = 2

        # Mock data query
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = alerts
        data_result = MagicMock()
        data_result.scalars.return_value = scalars_mock

        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result_alerts, total = await repo.list_alerts(
            db,
            application_id=uuid4(),
        )

        assert len(result_alerts) == 2
        assert total == 2

    async def test_filters_by_alert_type(self):
        """list_alerts filters by alert_type."""
        db = _mock_db()

        count_result = MagicMock()
        count_result.scalar_one.return_value = 1

        scalars_mock = MagicMock()
        scalars_mock.all.return_value = [_mock_alert(alert_type="privilege_escalation")]
        data_result = MagicMock()
        data_result.scalars.return_value = scalars_mock

        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result_alerts, total = await repo.list_alerts(
            db,
            application_id=uuid4(),
            alert_type="privilege_escalation",
        )

        assert total == 1

    async def test_filters_by_severity(self):
        """list_alerts filters by severity."""
        db = _mock_db()

        count_result = MagicMock()
        count_result.scalar_one.return_value = 1

        scalars_mock = MagicMock()
        scalars_mock.all.return_value = [_mock_alert(severity="critical")]
        data_result = MagicMock()
        data_result.scalars.return_value = scalars_mock

        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result_alerts, total = await repo.list_alerts(
            db,
            application_id=uuid4(),
            severity="critical",
        )

        assert total == 1

    async def test_respects_limit(self):
        """list_alerts respects limit parameter."""
        db = _mock_db()

        count_result = MagicMock()
        count_result.scalar_one.return_value = 100

        scalars_mock = MagicMock()
        scalars_mock.all.return_value = [_mock_alert() for _ in range(10)]
        data_result = MagicMock()
        data_result.scalars.return_value = scalars_mock

        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result_alerts, total = await repo.list_alerts(
            db,
            application_id=uuid4(),
            limit=10,
        )

        assert len(result_alerts) == 10
        assert total == 100

    async def test_filters_by_application_id(self):
        """list_alerts scopes count and result queries to an application."""
        db = _mock_db()
        application_id = uuid4()

        count_result = MagicMock()
        count_result.scalar_one.return_value = 0

        scalars_mock = MagicMock()
        scalars_mock.all.return_value = []
        data_result = MagicMock()
        data_result.scalars.return_value = scalars_mock

        db.execute = AsyncMock(side_effect=[count_result, data_result])

        await repo.list_alerts(db, application_id=application_id)

        count_sql = _executed_sql(db, 0)
        data_sql = _executed_sql(db, 1)
        assert "security_alerts.application_id" in count_sql
        assert "security_alerts.application_id" in data_sql


class TestGetSummary:
    async def test_returns_summary_statistics(self):
        """get_summary returns counts by type and severity."""
        since = datetime.now(UTC) - timedelta(days=7)

        db = _mock_db()

        # Mock total count
        count_result = MagicMock()
        count_result.scalar_one.return_value = 50

        # Mock by_type query
        type_row = MagicMock()
        type_row.alert_type = "rate_limit_exceeded"
        type_row.count = 30
        type_result = MagicMock()
        type_result.__iter__ = lambda self: iter([type_row])

        # Mock by_severity query
        severity_row = MagicMock()
        severity_row.severity = "warning"
        severity_row.count = 40
        severity_result = MagicMock()
        severity_result.__iter__ = lambda self: iter([severity_row])

        db.execute = AsyncMock(side_effect=[count_result, type_result, severity_result])

        result = await repo.get_summary(
            db,
            application_id=uuid4(),
            since=since,
        )

        assert result["total"] == 50
        assert len(result["by_type"]) == 1
        assert result["by_type"][0]["alert_type"] == "rate_limit_exceeded"
        assert result["by_type"][0]["count"] == 30
        assert len(result["by_severity"]) == 1
        assert result["by_severity"][0]["severity"] == "warning"
        assert result["by_severity"][0]["count"] == 40

    async def test_empty_summary(self):
        """get_summary handles no alerts gracefully."""
        since = datetime.now(UTC) - timedelta(days=7)

        db = _mock_db()

        # Mock total count = 0
        count_result = MagicMock()
        count_result.scalar_one.return_value = 0

        # Mock empty by_type query
        type_result = MagicMock()
        type_result.__iter__ = lambda self: iter([])

        # Mock empty by_severity query
        severity_result = MagicMock()
        severity_result.__iter__ = lambda self: iter([])

        db.execute = AsyncMock(side_effect=[count_result, type_result, severity_result])

        result = await repo.get_summary(
            db,
            application_id=uuid4(),
            since=since,
        )

        assert result["total"] == 0
        assert result["by_type"] == []
        assert result["by_severity"] == []

    async def test_multiple_types_and_severities(self):
        """get_summary aggregates multiple types and severities."""
        since = datetime.now(UTC) - timedelta(hours=1)

        db = _mock_db()

        count_result = MagicMock()
        count_result.scalar_one.return_value = 100

        # Multiple types
        type_rows = [
            MagicMock(alert_type="rate_limit_exceeded", count=50),
            MagicMock(alert_type="privilege_escalation", count=30),
            MagicMock(alert_type="invalid_token", count=20),
        ]
        type_result = MagicMock()
        type_result.__iter__ = lambda self: iter(type_rows)

        # Multiple severities
        severity_rows = [
            MagicMock(severity="warning", count=60),
            MagicMock(severity="critical", count=40),
        ]
        severity_result = MagicMock()
        severity_result.__iter__ = lambda self: iter(severity_rows)

        db.execute = AsyncMock(side_effect=[count_result, type_result, severity_result])

        result = await repo.get_summary(
            db,
            application_id=uuid4(),
            since=since,
        )

        assert result["total"] == 100
        assert len(result["by_type"]) == 3
        assert len(result["by_severity"]) == 2

    async def test_filters_summary_queries_by_application_id(self):
        """get_summary scopes total, type, and severity counts."""
        since = datetime.now(UTC) - timedelta(hours=1)

        db = _mock_db()
        count_result = MagicMock()
        count_result.scalar_one.return_value = 0
        type_result = MagicMock()
        type_result.__iter__ = lambda self: iter([])
        severity_result = MagicMock()
        severity_result.__iter__ = lambda self: iter([])

        db.execute = AsyncMock(side_effect=[count_result, type_result, severity_result])

        await repo.get_summary(
            db,
            application_id=uuid4(),
            since=since,
        )

        for index in range(3):
            assert "security_alerts.application_id" in _executed_sql(db, index)
