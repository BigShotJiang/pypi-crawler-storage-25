"""Unit tests for the billing_accounts repository layer."""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

from spaps_server_quickstart.domains.billing_accounts import repository as repo
from spaps_server_quickstart.domains.billing_accounts.models import BillingAccount


def _make_billing_account(
    billing_account_id: str | None = None,
    provider: str = "stripe",
    ownership_mode: str = "platform_managed",
    credential_source: str = "env_ref",
    status: str = "active",
    livemode: bool = False,
    stripe_account_id: str | None = None,
    stripe_publishable_key: str | None = None,
    encrypted_secret_key: str | None = None,
    encrypted_webhook_secret: str | None = None,
    stripe_webhook_endpoint_id: str | None = None,
) -> MagicMock:
    """Return a mock BillingAccount with sensible defaults."""
    billing_account = MagicMock(spec=BillingAccount)
    billing_account.id = UUID(billing_account_id) if billing_account_id else uuid4()
    billing_account.provider = provider
    billing_account.ownership_mode = ownership_mode
    billing_account.credential_source = credential_source
    billing_account.status = status
    billing_account.livemode = livemode
    billing_account.stripe_account_id = stripe_account_id
    billing_account.stripe_publishable_key = stripe_publishable_key
    billing_account.encrypted_secret_key = encrypted_secret_key
    billing_account.encrypted_webhook_secret = encrypted_webhook_secret
    billing_account.stripe_webhook_endpoint_id = stripe_webhook_endpoint_id
    billing_account.created_at = datetime.now(UTC)
    billing_account.updated_at = datetime.now(UTC)
    return billing_account


def _mock_session() -> AsyncMock:
    """Create a mock AsyncSession with the common interface."""
    session = AsyncMock()
    session.add = MagicMock()
    session.flush = AsyncMock()
    session.refresh = AsyncMock()
    session.execute = AsyncMock()
    return session


class TestGetBillingAccountById:
    async def test_returns_billing_account_when_found(self):
        billing_account = _make_billing_account()
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = billing_account
        db.execute.return_value = result_mock

        result = await repo.get_billing_account_by_id(
            db,
            str(billing_account.id),
        )

        assert result is billing_account
        db.execute.assert_awaited_once()

    async def test_returns_none_when_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        result = await repo.get_billing_account_by_id(db, str(uuid4()))

        assert result is None


class TestGetBillingAccountByStripeAccountId:
    async def test_returns_billing_account_when_found(self):
        billing_account = _make_billing_account(stripe_account_id="acct_123")
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = billing_account
        db.execute.return_value = result_mock

        result = await repo.get_billing_account_by_stripe_account_id(
            db,
            "acct_123",
        )

        assert result is billing_account
        assert result.stripe_account_id == "acct_123"

    async def test_returns_none_when_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        result = await repo.get_billing_account_by_stripe_account_id(
            db,
            "acct_missing",
        )

        assert result is None


class TestCreateBillingAccount:
    async def test_creates_and_flushes(self):
        db = _mock_session()

        async def _fake_refresh(obj):
            obj.id = uuid4()
            obj.created_at = datetime.now(UTC)
            obj.updated_at = datetime.now(UTC)

        db.refresh.side_effect = _fake_refresh

        result = await repo.create_billing_account(
            db,
            provider="stripe",
            ownership_mode="customer_owned",
            credential_source="encrypted_secret",
            status="active",
            livemode=True,
            stripe_account_id="acct_live_123",
            stripe_publishable_key="pk_live_123",
            encrypted_secret_key="enc_sk_live_123",
            encrypted_webhook_secret="enc_whsec_live_123",
            stripe_webhook_endpoint_id="we_123",
        )

        assert result.provider == "stripe"
        assert result.ownership_mode == "customer_owned"
        assert result.credential_source == "encrypted_secret"
        assert result.status == "active"
        assert result.livemode is True
        assert result.stripe_account_id == "acct_live_123"
        assert result.stripe_publishable_key == "pk_live_123"
        assert result.encrypted_secret_key == "enc_sk_live_123"
        assert result.encrypted_webhook_secret == "enc_whsec_live_123"
        assert result.stripe_webhook_endpoint_id == "we_123"
        db.add.assert_called_once()
        db.flush.assert_awaited_once()
        db.refresh.assert_awaited_once()

    async def test_defaults_status_and_livemode(self):
        db = _mock_session()

        result = await repo.create_billing_account(
            db,
            provider="stripe",
            ownership_mode="platform_managed",
            credential_source="env_ref",
        )

        assert result.status == "active"
        assert result.livemode is False
        db.add.assert_called_once()


class TestUpdateBillingAccount:
    async def test_updates_existing_billing_account(self):
        billing_account = _make_billing_account(
            ownership_mode="platform_managed",
            credential_source="env_ref",
            livemode=False,
        )
        db = _mock_session()

        with patch.object(
            repo,
            "get_billing_account_by_id",
            new_callable=AsyncMock,
        ) as mock_get:
            mock_get.return_value = billing_account

            result = await repo.update_billing_account(
                db,
                str(billing_account.id),
                ownership_mode="customer_owned",
                credential_source="encrypted_secret",
                livemode=True,
                stripe_account_id="acct_updated",
            )

        assert result is billing_account
        assert result.ownership_mode == "customer_owned"
        assert result.credential_source == "encrypted_secret"
        assert result.livemode is True
        assert result.stripe_account_id == "acct_updated"
        db.flush.assert_awaited()
        db.refresh.assert_awaited()

    async def test_returns_none_when_not_found(self):
        db = _mock_session()

        with patch.object(
            repo,
            "get_billing_account_by_id",
            new_callable=AsyncMock,
        ) as mock_get:
            mock_get.return_value = None

            result = await repo.update_billing_account(
                db,
                str(uuid4()),
                status="disabled",
            )

        assert result is None


class TestListBillingAccounts:
    async def test_returns_all_billing_accounts(self):
        billing_account_1 = _make_billing_account(stripe_account_id="acct_1")
        billing_account_2 = _make_billing_account(stripe_account_id="acct_2")
        db = _mock_session()

        result_mock = MagicMock()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = [billing_account_1, billing_account_2]
        result_mock.scalars.return_value = scalars_mock
        db.execute.return_value = result_mock

        result = await repo.list_billing_accounts(db)

        assert len(result) == 2
        assert billing_account_1 in result
        assert billing_account_2 in result

    async def test_active_only_filter_is_accepted(self):
        db = _mock_session()

        result_mock = MagicMock()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = []
        result_mock.scalars.return_value = scalars_mock
        db.execute.return_value = result_mock

        result = await repo.list_billing_accounts(
            db,
            provider="stripe",
            active_only=True,
        )

        assert result == []
        db.execute.assert_awaited_once()
