"""Unit tests for billing-account-aware Stripe resolution."""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.errors import InvalidStateError
from spaps_server_quickstart.domains.billing_accounts import resolver
from spaps_server_quickstart.domains.secure_messages.encryption import (
    PiiEncryptionService,
)


FAKE_APP_ID = uuid4()
FAKE_BILLING_ACCOUNT_ID = uuid4()

_APP_REPO = "spaps_server_quickstart.domains.billing_accounts.resolver.applications_repo"
_BILLING_REPO = "spaps_server_quickstart.domains.billing_accounts.resolver.billing_accounts_repo"


def _make_application(*, billing_account_id=FAKE_BILLING_ACCOUNT_ID) -> MagicMock:
    application = MagicMock()
    application.id = FAKE_APP_ID
    application.billing_account_id = billing_account_id
    return application


def _make_billing_account() -> MagicMock:
    billing_account = MagicMock()
    billing_account.id = FAKE_BILLING_ACCOUNT_ID
    billing_account.provider = "stripe"
    billing_account.ownership_mode = "customer_owned"
    billing_account.credential_source = "encrypted_secret"
    billing_account.livemode = True
    billing_account.stripe_account_id = "acct_live_bound"
    billing_account.stripe_publishable_key = "pk_live_bound"
    billing_account.encrypted_secret_key = "sk_live_bound"
    billing_account.encrypted_webhook_secret = "whsec_bound"
    return billing_account


class TestResolveStripeBillingContext:
    @patch(f"{_APP_REPO}.get_application_by_id", new_callable=AsyncMock)
    @patch(f"{_BILLING_REPO}.get_billing_account_by_id", new_callable=AsyncMock)
    async def test_prefers_bound_billing_account_for_trusted_application(
        self,
        mock_get_billing_account,
        mock_get_application,
    ):
        application = _make_application()
        billing_account = _make_billing_account()
        mock_get_billing_account.return_value = billing_account

        result = await resolver.resolve_stripe_billing_context(
            AsyncMock(),
            application=application,
        )

        assert result.application_id == FAKE_APP_ID
        assert result.source == "billing_account"
        assert result.billing_account_id == FAKE_BILLING_ACCOUNT_ID
        assert result.stripe_secret_key == "sk_live_bound"
        assert result.stripe_webhook_secret == "whsec_bound"
        assert result.stripe_publishable_key == "pk_live_bound"
        assert result.stripe_account_id == "acct_live_bound"
        assert result.credential_source == "encrypted_secret"
        assert result.ownership_mode == "customer_owned"
        assert result.livemode is True
        mock_get_application.assert_not_awaited()
        mock_get_billing_account.assert_awaited_once()

    @patch(f"{_APP_REPO}.get_application_by_id", new_callable=AsyncMock)
    @patch(f"{_BILLING_REPO}.get_billing_account_by_id", new_callable=AsyncMock)
    async def test_resolves_bound_billing_account_from_application_id_lookup(
        self,
        mock_get_billing_account,
        mock_get_application,
    ):
        application = _make_application()
        billing_account = _make_billing_account()
        mock_get_application.return_value = application
        mock_get_billing_account.return_value = billing_account
        db = AsyncMock()

        result = await resolver.resolve_stripe_billing_context(
            db,
            application_id=FAKE_APP_ID,
        )

        assert result.source == "billing_account"
        assert result.application_id == FAKE_APP_ID
        mock_get_application.assert_awaited_once_with(db, str(FAKE_APP_ID))
        mock_get_billing_account.assert_awaited_once_with(
            db,
            str(FAKE_BILLING_ACCOUNT_ID),
        )

    @patch(f"{_BILLING_REPO}.get_billing_account_by_id", new_callable=AsyncMock)
    async def test_decrypts_encrypted_billing_account_credentials(
        self,
        mock_get_billing_account,
    ):
        billing_account = _make_billing_account()
        encryption_service = PiiEncryptionService(
            master_key="billing-secret-master-key-1234567890",
        )
        billing_account.encrypted_secret_key = encryption_service.encrypt_field(
            application_id=str(FAKE_BILLING_ACCOUNT_ID),
            value="sk_live_bound",
        )
        billing_account.encrypted_webhook_secret = encryption_service.encrypt_field(
            application_id=str(FAKE_BILLING_ACCOUNT_ID),
            value="whsec_bound",
        )
        mock_get_billing_account.return_value = billing_account

        settings = SimpleNamespace(
            stripe_secret_key="sk_test_default",
            stripe_webhook_secret="whsec_default",
            spaps_pii_master_key="billing-secret-master-key-1234567890",
        )

        result = await resolver.resolve_stripe_billing_context(
            AsyncMock(),
            application=_make_application(),
            settings=settings,
        )

        assert result.stripe_secret_key == "sk_live_bound"
        assert result.stripe_webhook_secret == "whsec_bound"

    @patch(f"{_BILLING_REPO}.get_billing_account_by_id", new_callable=AsyncMock)
    async def test_falls_back_to_legacy_env_when_trusted_application_has_no_binding(
        self,
        mock_get_billing_account,
    ):
        application = _make_application(billing_account_id=None)
        settings = SimpleNamespace(
            stripe_secret_key="sk_test_default",
            stripe_webhook_secret="whsec_default",
        )

        with patch(
            "spaps_server_quickstart.domains.billing_accounts.resolver.get_spaps_settings",
            return_value=settings,
        ):
            result = await resolver.resolve_stripe_billing_context(
                AsyncMock(),
                application=application,
            )

        assert result.application_id == FAKE_APP_ID
        assert result.source == "legacy_env_default"
        assert result.billing_account_id is None
        assert result.stripe_secret_key == "sk_test_default"
        assert result.stripe_webhook_secret == "whsec_default"
        assert result.credential_source == "env_ref"
        assert result.ownership_mode == "platform_managed"
        assert result.livemode is False
        mock_get_billing_account.assert_not_awaited()

    @patch(f"{_APP_REPO}.get_application_by_id", new_callable=AsyncMock)
    @patch(f"{_BILLING_REPO}.get_billing_account_by_id", new_callable=AsyncMock)
    async def test_falls_back_to_legacy_env_when_application_lookup_has_no_binding(
        self,
        mock_get_billing_account,
        mock_get_application,
    ):
        mock_get_application.return_value = _make_application(billing_account_id=None)
        settings = SimpleNamespace(
            stripe_secret_key="sk_live_default",
            stripe_webhook_secret="whsec_live_default",
        )
        db = AsyncMock()

        result = await resolver.resolve_stripe_billing_context(
            db,
            application_id=FAKE_APP_ID,
            settings=settings,
        )

        assert result.source == "legacy_env_default"
        assert result.stripe_secret_key == "sk_live_default"
        assert result.stripe_webhook_secret == "whsec_live_default"
        assert result.livemode is True
        mock_get_application.assert_awaited_once_with(db, str(FAKE_APP_ID))
        mock_get_billing_account.assert_not_awaited()

    @patch(f"{_BILLING_REPO}.get_billing_account_by_id", new_callable=AsyncMock)
    async def test_does_not_silently_fallback_when_binding_is_invalid(
        self,
        mock_get_billing_account,
    ):
        mock_get_billing_account.return_value = None

        with pytest.raises(
            InvalidStateError,
            match="Application billing account binding is invalid",
        ):
            await resolver.resolve_stripe_billing_context(
                AsyncMock(),
                application=_make_application(),
                settings=SimpleNamespace(
                    stripe_secret_key="sk_test_default",
                    stripe_webhook_secret="whsec_default",
                ),
            )
