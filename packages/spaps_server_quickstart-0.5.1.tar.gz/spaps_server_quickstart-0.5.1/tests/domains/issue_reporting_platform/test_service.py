"""Unit tests for issue_reporting_platform service logic."""

from __future__ import annotations

from datetime import UTC, datetime
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from uuid import uuid4

import httpx
import pytest
import respx

from spaps_server_quickstart.domains.issue_reporting_platform.errors import (
    IssueReportCannotEditClosedError,
    IssueReportCannotReplyOpenError,
    IssueReportCaseLinkBrokenError,
    IssueReportNotFoundError,
    IssueReportVoiceUnavailableError,
)
from spaps_server_quickstart.domains.issue_reporting_platform.service import (
    ELEVENLABS_SCRIBE_TOKEN_URL,
    HTMALegacyIssueLogRecord,
    create_issue_report,
    create_voice_token,
    get_issue_report_detail,
    get_issue_report_status,
    import_htma_issue_logs,
    list_issue_reports,
    reply_to_issue_report,
    update_issue_report_note,
)

_REPO = "spaps_server_quickstart.domains.issue_reporting_platform.service.repo"
_SUPPORT_REPO = "spaps_server_quickstart.domains.issue_reporting_platform.service.support_repo"


def _make_issue_report(**overrides) -> SimpleNamespace:
    now = datetime.now(UTC)
    return SimpleNamespace(
        id=overrides.get("id", uuid4()),
        application_id=overrides.get("application_id", uuid4()),
        reporter_user_id=overrides.get("reporter_user_id", uuid4()),
        reporter_role_hint=overrides.get("reporter_role_hint", "practitioner"),
        component_key=overrides.get("component_key", "patient_protocol_widget"),
        component_label=overrides.get("component_label", "Patient Protocol Widget"),
        page_url=overrides.get("page_url", "/patients/123/protocol"),
        surface_ref=overrides.get("surface_ref"),
        target_metadata=overrides.get("target_metadata", {"section": "daily log"}),
        note=overrides.get("note", "Detailed issue note."),
        parent_issue_report_id=overrides.get("parent_issue_report_id"),
        support_case_id=overrides.get("support_case_id", uuid4()),
        created_at=overrides.get("created_at", now),
        updated_at=overrides.get("updated_at", now),
    )


def _make_case(**overrides) -> SimpleNamespace:
    now = datetime.now(UTC)
    return SimpleNamespace(
        id=overrides.get("id", uuid4()),
        application_id=overrides.get("application_id", uuid4()),
        external_case_ref=overrides.get("external_case_ref"),
        title=overrides.get("title", "Patient Protocol Widget"),
        status=overrides.get("status", "open"),
        priority=overrides.get("priority", "normal"),
        highest_severity=overrides.get("highest_severity", "warning"),
        assigned_to_user_id=overrides.get("assigned_to_user_id"),
        first_event_at=overrides.get("first_event_at", now),
        last_event_at=overrides.get("last_event_at", now),
        resolved_at=overrides.get("resolved_at"),
        created_at=overrides.get("created_at", now),
        updated_at=overrides.get("updated_at", now),
    )


def _make_event(**overrides) -> SimpleNamespace:
    now = datetime.now(UTC)
    return SimpleNamespace(
        id=overrides.get("id", uuid4()),
        case_id=overrides.get("case_id", uuid4()),
        application_id=overrides.get("application_id", uuid4()),
        event_key=overrides.get("event_key", "evt_1"),
        source_channel=overrides.get("source_channel", "frontend"),
        event_type=overrides.get("event_type", "issue_reported"),
        severity=overrides.get("severity", "warning"),
        actor_type=overrides.get("actor_type", "practitioner"),
        actor_external_id=overrides.get("actor_external_id"),
        correlation_id=overrides.get("correlation_id"),
        payload=overrides.get("payload", {}),
        redacted_keys=overrides.get("redacted_keys", []),
        occurred_at=overrides.get("occurred_at", now),
        ingested_by_user_id=overrides.get("ingested_by_user_id"),
    )


class TestCreateVoiceToken:
    async def test_returns_voice_token_for_configured_elevenlabs(self):
        settings = SimpleNamespace(elevenlabs_api_key="elevenlabs_test_key")
        expected_token = "sutkn_test"

        with respx.mock(assert_all_called=True) as mocked:
            route = mocked.post(ELEVENLABS_SCRIBE_TOKEN_URL).mock(
                return_value=httpx.Response(200, json={"token": expected_token})
            )
            result = await create_voice_token(settings=settings)

        assert route.call_count == 1
        assert route.calls[0].request.headers["xi-api-key"] == "elevenlabs_test_key"
        assert result == {
            "provider": "elevenlabs_scribe_realtime",
            "model_id": "scribe_v2_realtime",
            "token": expected_token,
            "expires_in_seconds": 900,
            "retain_audio": False,
            "attach_transcript": True,
        }

    async def test_raises_when_elevenlabs_key_missing(self):
        settings = SimpleNamespace(elevenlabs_api_key="  ")

        with pytest.raises(IssueReportVoiceUnavailableError) as exc:
            await create_voice_token(settings=settings)

        assert exc.value.code == "ISSUE_REPORT_VOICE_UNAVAILABLE"

    async def test_raises_when_elevenlabs_returns_error(self):
        settings = SimpleNamespace(elevenlabs_api_key="elevenlabs_test_key")

        with respx.mock(assert_all_called=True) as mocked:
            mocked.post(ELEVENLABS_SCRIBE_TOKEN_URL).mock(
                return_value=httpx.Response(502, json={"detail": "upstream unavailable"})
            )
            with pytest.raises(IssueReportVoiceUnavailableError) as exc:
                await create_voice_token(settings=settings)

        assert exc.value.code == "ISSUE_REPORT_VOICE_UNAVAILABLE"


class TestCreateIssueReport:
    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_creates_issue_report_and_linked_case(self, mock_repo, mock_support_repo):
        application_id = uuid4()
        reporter_user_id = uuid4()
        created_case = _make_case(id=uuid4(), application_id=application_id, status="open")
        created_issue_report = _make_issue_report(
            id=uuid4(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            support_case_id=created_case.id,
        )
        created_event = _make_event(case_id=created_case.id, application_id=application_id)

        mock_support_repo.create_case = AsyncMock(return_value=created_case)
        mock_repo.create_issue_report = AsyncMock(return_value=created_issue_report)
        mock_support_repo.create_event = AsyncMock(return_value=created_event)
        mock_support_repo.update_case_summary = AsyncMock(return_value=created_case)

        result = await create_issue_report(
            AsyncMock(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            reporter_role_hint=None,
            user_roles=["practitioner"],
            target={
                "component_key": "patient_protocol_widget",
                "component_label": "Patient Protocol Widget",
                "page_url": "/patients/123/protocol",
                "surface_ref": "daily-log",
                "metadata": {"section": "daily log"},
            },
            note="The save action silently fails after I edit today's protocol note.",
        )

        assert result["id"] == str(created_issue_report.id)
        assert result["status"] == "open"
        assert result["linked_case"]["case_id"] == str(created_case.id)
        assert mock_repo.create_issue_report.await_args.kwargs["parent_issue_report_id"] is None
        assert mock_support_repo.create_event.await_args.kwargs["event_type"] == "issue_reported"


class TestListIssueReports:
    @patch(_REPO)
    async def test_list_raises_when_case_link_is_broken(self, mock_repo):
        issue_report = _make_issue_report()
        mock_repo.list_issue_report_rows = AsyncMock(return_value=([(issue_report, None)], 1))

        with pytest.raises(IssueReportCaseLinkBrokenError):
            await list_issue_reports(
                AsyncMock(),
                application_id=uuid4(),
                reporter_user_id=uuid4(),
                status=None,
                limit=50,
                offset=0,
            )

    @patch(_REPO)
    async def test_list_projects_current_linked_case_status(self, mock_repo):
        application_id = uuid4()
        reporter_user_id = uuid4()
        issue_report = _make_issue_report(
            application_id=application_id,
            reporter_user_id=reporter_user_id,
        )
        resolved_case = _make_case(
            id=issue_report.support_case_id,
            application_id=application_id,
            status="resolved",
            resolved_at=datetime.now(UTC),
        )
        mock_repo.list_issue_report_rows = AsyncMock(return_value=([(issue_report, resolved_case)], 1))

        result = await list_issue_reports(
            AsyncMock(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            status=None,
            limit=50,
            offset=0,
        )

        assert result["items"][0]["status"] == "resolved"
        assert result["items"][0]["linked_case"]["status"] == "resolved"


class TestGetIssueReportDetail:
    @patch(_REPO)
    async def test_detail_raises_when_issue_report_is_not_owned(self, mock_repo):
        mock_repo.get_issue_report_row = AsyncMock(return_value=None)

        with pytest.raises(IssueReportNotFoundError):
            await get_issue_report_detail(
                AsyncMock(),
                application_id=uuid4(),
                reporter_user_id=uuid4(),
                issue_report_id=uuid4(),
            )

    @patch(_REPO)
    async def test_detail_reflects_current_linked_case_status(self, mock_repo):
        application_id = uuid4()
        reporter_user_id = uuid4()
        issue_report = _make_issue_report(
            application_id=application_id,
            reporter_user_id=reporter_user_id,
        )
        reopened_case = _make_case(
            id=issue_report.support_case_id,
            application_id=application_id,
            status="open",
            resolved_at=None,
        )
        mock_repo.get_issue_report_row = AsyncMock(return_value=(issue_report, reopened_case))

        result = await get_issue_report_detail(
            AsyncMock(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            issue_report_id=issue_report.id,
        )

        assert result["status"] == "open"
        assert result["linked_case"]["status"] == "open"


class TestUpdateIssueReportNote:
    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_edit_rejects_closed_issue_report(self, mock_repo, mock_support_repo):
        issue_report = _make_issue_report()
        closed_case = _make_case(id=issue_report.support_case_id, status="resolved")
        mock_repo.get_issue_report_row = AsyncMock(return_value=(issue_report, closed_case))

        with pytest.raises(IssueReportCannotEditClosedError):
            await update_issue_report_note(
                AsyncMock(),
                application_id=uuid4(),
                reporter_user_id=uuid4(),
                issue_report_id=uuid4(),
                note="This should still be enough text.",
                reporter_role_hint=None,
                user_roles=["practitioner"],
            )

        mock_support_repo.create_event.assert_not_called()

    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_edit_rejects_unowned_issue_report(self, mock_repo, mock_support_repo):
        mock_repo.get_issue_report_row = AsyncMock(return_value=None)

        with pytest.raises(IssueReportNotFoundError):
            await update_issue_report_note(
                AsyncMock(),
                application_id=uuid4(),
                reporter_user_id=uuid4(),
                issue_report_id=uuid4(),
                note="This should still be enough text.",
                reporter_role_hint=None,
                user_roles=["practitioner"],
            )

        mock_support_repo.create_event.assert_not_called()


class TestReplyToIssueReport:
    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_reply_rejects_open_issue_report(self, mock_repo, mock_support_repo):
        issue_report = _make_issue_report()
        open_case = _make_case(id=issue_report.support_case_id, status="open")
        mock_repo.get_issue_report_row = AsyncMock(return_value=(issue_report, open_case))

        with pytest.raises(IssueReportCannotReplyOpenError):
            await reply_to_issue_report(
                AsyncMock(),
                application_id=uuid4(),
                reporter_user_id=uuid4(),
                issue_report_id=uuid4(),
                note="This is still happening after the fix landed.",
                reporter_role_hint=None,
                user_roles=["practitioner"],
            )

        mock_repo.create_issue_report.assert_not_called()
        mock_support_repo.update_case.assert_not_called()

    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_reply_rejects_unowned_issue_report(self, mock_repo, mock_support_repo):
        mock_repo.get_issue_report_row = AsyncMock(return_value=None)

        with pytest.raises(IssueReportNotFoundError):
            await reply_to_issue_report(
                AsyncMock(),
                application_id=uuid4(),
                reporter_user_id=uuid4(),
                issue_report_id=uuid4(),
                note="This is still happening after the fix landed.",
                reporter_role_hint=None,
                user_roles=["practitioner"],
            )

        mock_repo.create_issue_report.assert_not_called()
        mock_support_repo.update_case.assert_not_called()

    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_reply_creates_child_and_reopens_case(self, mock_repo, mock_support_repo):
        application_id = uuid4()
        reporter_user_id = uuid4()
        parent_issue_report = _make_issue_report(
            application_id=application_id,
            reporter_user_id=reporter_user_id,
        )
        closed_case = _make_case(
            id=parent_issue_report.support_case_id,
            application_id=application_id,
            status="resolved",
            resolved_at=datetime.now(UTC),
        )
        child_issue_report = _make_issue_report(
            id=uuid4(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            parent_issue_report_id=parent_issue_report.id,
            support_case_id=closed_case.id,
            note="This still fails after the reported fix.",
        )
        reopened_case = _make_case(
            id=closed_case.id,
            application_id=application_id,
            status="open",
            resolved_at=None,
        )
        created_event = _make_event(case_id=reopened_case.id, application_id=application_id)

        mock_repo.get_issue_report_row = AsyncMock(return_value=(parent_issue_report, closed_case))
        mock_repo.create_issue_report = AsyncMock(return_value=child_issue_report)
        mock_support_repo.update_case = AsyncMock(return_value=reopened_case)
        mock_support_repo.create_event = AsyncMock(return_value=created_event)
        mock_support_repo.update_case_summary = AsyncMock(return_value=reopened_case)

        result = await reply_to_issue_report(
            AsyncMock(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            issue_report_id=parent_issue_report.id,
            note="This still fails after the reported fix.",
            reporter_role_hint=None,
            user_roles=["practitioner"],
        )

        assert result["parent_issue_report_id"] == str(parent_issue_report.id)
        assert result["linked_case"]["status"] == "open"
        assert mock_support_repo.update_case.await_args.kwargs["status"] == "open"
        assert mock_support_repo.create_event.await_args.kwargs["event_type"] == "issue_report_replied"


class TestIssueReportStatus:
    @patch(_REPO)
    async def test_status_uses_open_and_recent_resolved_counts(self, mock_repo):
        mock_repo.count_open_issue_reports = AsyncMock(return_value=2)
        mock_repo.count_recent_resolved_issue_reports = AsyncMock(return_value=1)

        result = await get_issue_report_status(
            AsyncMock(),
            application_id=uuid4(),
            reporter_user_id=uuid4(),
        )

        assert result == {
            "has_open": True,
            "has_recent_resolved": True,
            "open_count": 2,
            "recent_resolved_count": 1,
        }


class TestImportHTMAIssueLogs:
    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_import_creates_root_and_reply_with_parity_summary(self, mock_repo, mock_support_repo):
        application_id = uuid4()
        reporter_user_id = uuid4()
        root_legacy_id = uuid4()
        reply_legacy_id = uuid4()
        root_created_at = datetime(2026, 3, 10, 14, 30, tzinfo=UTC)
        root_fixed_at = datetime(2026, 3, 11, 9, 0, tzinfo=UTC)
        reply_created_at = datetime(2026, 3, 12, 8, 45, tzinfo=UTC)

        root_case = _make_case(
            id=uuid4(),
            application_id=application_id,
            title="Protocol Builder",
            status="open",
            resolved_at=None,
            first_event_at=root_created_at,
            last_event_at=root_fixed_at,
        )
        resolved_case = _make_case(
            id=root_case.id,
            application_id=application_id,
            title=root_case.title,
            status="resolved",
            resolved_at=root_fixed_at,
            first_event_at=root_created_at,
            last_event_at=root_fixed_at,
        )
        reopened_case = _make_case(
            id=root_case.id,
            application_id=application_id,
            title=root_case.title,
            status="open",
            resolved_at=None,
            first_event_at=root_created_at,
            last_event_at=reply_created_at,
        )
        imported_root = _make_issue_report(
            id=uuid4(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            reporter_role_hint="practitioner",
            component_key="protocol_builder",
            component_label="Protocol Builder",
            page_url="/patients/123/protocol",
            note="The protocol builder save action failed on the first attempt.",
            support_case_id=root_case.id,
            created_at=root_created_at,
            updated_at=root_fixed_at,
        )
        imported_reply = _make_issue_report(
            id=uuid4(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            reporter_role_hint="practitioner",
            component_key="protocol_builder",
            component_label="Protocol Builder",
            page_url="/patients/123/protocol",
            note="The same bug came back after the reported fix.",
            parent_issue_report_id=imported_root.id,
            support_case_id=root_case.id,
            created_at=reply_created_at,
            updated_at=reply_created_at,
        )

        mock_repo.get_issue_report_by_source_record = AsyncMock(side_effect=[None, None])
        mock_support_repo.get_case_by_external_ref = AsyncMock(return_value=None)
        mock_support_repo.create_case = AsyncMock(return_value=root_case)
        mock_support_repo.update_case = AsyncMock(side_effect=[resolved_case, reopened_case])
        mock_support_repo.get_case_by_id = AsyncMock(return_value=resolved_case)
        mock_repo.create_issue_report = AsyncMock(side_effect=[imported_root, imported_reply])
        mock_support_repo.create_event = AsyncMock(
            side_effect=[
                _make_event(case_id=root_case.id, application_id=application_id),
                _make_event(case_id=root_case.id, application_id=application_id),
            ]
        )
        mock_support_repo.update_case_summary = AsyncMock(side_effect=[resolved_case, reopened_case])

        summary = await import_htma_issue_logs(
            AsyncMock(),
            application_id=application_id,
            legacy_issue_logs=[
                HTMALegacyIssueLogRecord(
                    legacy_issue_id=root_legacy_id,
                    reporter_user_id=reporter_user_id,
                    reporter_role_hint="practitioner",
                    component_label="Protocol Builder",
                    page_url="/patients/123/protocol",
                    note="The protocol builder save action failed on the first attempt.",
                    created_at=root_created_at,
                    updated_at=root_fixed_at,
                    is_fixed=True,
                    fixed_at=root_fixed_at,
                ),
                HTMALegacyIssueLogRecord(
                    legacy_issue_id=reply_legacy_id,
                    reporter_user_id=reporter_user_id,
                    reporter_role_hint="practitioner",
                    component_label="Protocol Builder",
                    page_url="/patients/123/protocol",
                    note="The same bug came back after the reported fix.",
                    created_at=reply_created_at,
                    updated_at=reply_created_at,
                    is_fixed=False,
                    parent_legacy_issue_id=root_legacy_id,
                ),
            ],
        )

        assert summary["created_issue_reports"] == 2
        assert summary["reused_issue_reports"] == 0
        assert summary["created_support_cases"] == 1
        assert summary["reused_support_cases"] == 0
        assert summary["root_count"] == 1
        assert summary["reply_count"] == 1
        assert summary["orphaned_reply_count"] == 0
        assert summary["parity"]["ok"] is True
        assert summary["parity"]["expected_open_lineages"] == 1
        assert summary["parity"]["imported_open_lineages"] == 1

        assert mock_support_repo.create_case.await_args.kwargs["external_case_ref"] == f"htma:issue-log:{root_legacy_id}"
        assert mock_repo.create_issue_report.await_args_list[0].kwargs["source_record_id"] == str(root_legacy_id)
        assert mock_repo.create_issue_report.await_args_list[1].kwargs["parent_issue_report_id"] == imported_root.id
        assert mock_repo.create_issue_report.await_args_list[1].kwargs["source_record_id"] == str(reply_legacy_id)
        assert mock_support_repo.update_case.await_args_list[0].kwargs["status"] == "resolved"
        assert mock_support_repo.update_case.await_args_list[1].kwargs["status"] == "open"

    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_import_processes_ready_roots_before_newly_ready_replies(self, mock_repo, mock_support_repo):
        application_id = uuid4()
        reporter_user_id = uuid4()
        root_a_legacy_id = "root-a"
        reply_a_legacy_id = "reply-a"
        root_b_legacy_id = "root-b"
        root_a_created_at = datetime(2026, 3, 10, 9, 0, tzinfo=UTC)
        reply_a_created_at = datetime(2026, 3, 10, 9, 1, tzinfo=UTC)
        root_b_created_at = datetime(2026, 3, 10, 9, 2, tzinfo=UTC)

        root_a_case = _make_case(
            id=uuid4(),
            application_id=application_id,
            title="Protocol Builder",
            status="open",
            first_event_at=root_a_created_at,
            last_event_at=root_a_created_at,
        )
        root_b_case = _make_case(
            id=uuid4(),
            application_id=application_id,
            title="Drawer Surface",
            status="open",
            first_event_at=root_b_created_at,
            last_event_at=root_b_created_at,
        )
        imported_root_a = _make_issue_report(
            id=uuid4(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            reporter_role_hint="practitioner",
            component_key="protocol_builder",
            component_label="Protocol Builder",
            page_url="/patients/123/protocol",
            note="The protocol builder save action failed on the first attempt.",
            support_case_id=root_a_case.id,
            created_at=root_a_created_at,
            updated_at=root_a_created_at,
        )
        imported_root_b = _make_issue_report(
            id=uuid4(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            reporter_role_hint="patient",
            component_key="drawer_surface",
            component_label="Drawer Surface",
            page_url="/patients/123/checkin",
            note="The drawer still closes itself before I finish typing.",
            support_case_id=root_b_case.id,
            created_at=root_b_created_at,
            updated_at=root_b_created_at,
        )
        imported_reply_a = _make_issue_report(
            id=uuid4(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            reporter_role_hint="practitioner",
            component_key="protocol_builder",
            component_label="Protocol Builder",
            page_url="/patients/123/protocol",
            note="The same problem still happens after the reported fix.",
            parent_issue_report_id=imported_root_a.id,
            support_case_id=root_a_case.id,
            created_at=reply_a_created_at,
            updated_at=reply_a_created_at,
        )

        mock_repo.get_issue_report_by_source_record = AsyncMock(side_effect=[None, None, None])
        mock_support_repo.get_case_by_external_ref = AsyncMock(side_effect=[None, None])
        mock_support_repo.get_case_by_id = AsyncMock(return_value=root_a_case)
        mock_support_repo.create_case = AsyncMock(side_effect=[root_a_case, root_b_case])
        mock_repo.create_issue_report = AsyncMock(
            side_effect=[imported_root_a, imported_root_b, imported_reply_a]
        )
        mock_support_repo.create_event = AsyncMock(
            side_effect=[
                _make_event(case_id=root_a_case.id, application_id=application_id, occurred_at=root_a_created_at),
                _make_event(case_id=root_b_case.id, application_id=application_id, occurred_at=root_b_created_at),
                _make_event(case_id=root_a_case.id, application_id=application_id, occurred_at=reply_a_created_at),
            ]
        )
        mock_support_repo.update_case_summary = AsyncMock(
            side_effect=[root_a_case, root_b_case, root_a_case]
        )

        summary = await import_htma_issue_logs(
            AsyncMock(),
            application_id=application_id,
            legacy_issue_logs=[
                HTMALegacyIssueLogRecord(
                    legacy_issue_id=reply_a_legacy_id,
                    reporter_user_id=reporter_user_id,
                    reporter_role_hint="practitioner",
                    component_label="Protocol Builder",
                    page_url="/patients/123/protocol",
                    note="The same problem still happens after the reported fix.",
                    created_at=reply_a_created_at,
                    updated_at=reply_a_created_at,
                    is_fixed=False,
                    parent_legacy_issue_id=root_a_legacy_id,
                ),
                HTMALegacyIssueLogRecord(
                    legacy_issue_id=root_b_legacy_id,
                    reporter_user_id=reporter_user_id,
                    reporter_role_hint="patient",
                    component_label="Drawer Surface",
                    page_url="/patients/123/checkin",
                    note="The drawer still closes itself before I finish typing.",
                    created_at=root_b_created_at,
                    updated_at=root_b_created_at,
                    is_fixed=False,
                ),
                HTMALegacyIssueLogRecord(
                    legacy_issue_id=root_a_legacy_id,
                    reporter_user_id=reporter_user_id,
                    reporter_role_hint="practitioner",
                    component_label="Protocol Builder",
                    page_url="/patients/123/protocol",
                    note="The protocol builder save action failed on the first attempt.",
                    created_at=root_a_created_at,
                    updated_at=root_a_created_at,
                    is_fixed=False,
                ),
            ],
        )

        assert summary["created_issue_reports"] == 3
        assert [call.kwargs["source_record_id"] for call in mock_repo.create_issue_report.await_args_list] == [
            root_a_legacy_id,
            root_b_legacy_id,
            reply_a_legacy_id,
        ]
        assert mock_repo.create_issue_report.await_args_list[2].kwargs["parent_issue_report_id"] == imported_root_a.id

    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_import_skips_existing_source_records_on_replay(self, mock_repo, mock_support_repo):
        application_id = uuid4()
        reporter_user_id = uuid4()
        legacy_issue_id = uuid4()
        created_at = datetime(2026, 3, 10, 14, 30, tzinfo=UTC)

        existing_case = _make_case(
            id=uuid4(),
            application_id=application_id,
            title="Protocol Builder",
            status="open",
            first_event_at=created_at,
            last_event_at=created_at,
        )
        existing_issue_report = _make_issue_report(
            id=uuid4(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            reporter_role_hint="practitioner",
            component_key="protocol_builder",
            component_label="Protocol Builder",
            page_url="/patients/123/protocol",
            note="The protocol builder save action failed on the first attempt.",
            support_case_id=existing_case.id,
            created_at=created_at,
            updated_at=created_at,
        )

        mock_repo.get_issue_report_by_source_record = AsyncMock(return_value=existing_issue_report)
        mock_support_repo.get_case_by_id = AsyncMock(return_value=existing_case)
        mock_repo.create_issue_report = AsyncMock()
        mock_support_repo.create_case = AsyncMock()
        mock_support_repo.create_event = AsyncMock()

        summary = await import_htma_issue_logs(
            AsyncMock(),
            application_id=application_id,
            legacy_issue_logs=[
                HTMALegacyIssueLogRecord(
                    legacy_issue_id=legacy_issue_id,
                    reporter_user_id=reporter_user_id,
                    reporter_role_hint="practitioner",
                    component_label="Protocol Builder",
                    page_url="/patients/123/protocol",
                    note="The protocol builder save action failed on the first attempt.",
                    created_at=created_at,
                    updated_at=created_at,
                    is_fixed=False,
                )
            ],
        )

        assert summary["created_issue_reports"] == 0
        assert summary["reused_issue_reports"] == 1
        assert summary["created_support_cases"] == 0
        assert summary["reused_support_cases"] == 1
        assert summary["parity"]["ok"] is True
        mock_repo.create_issue_report.assert_not_called()
        mock_support_repo.create_case.assert_not_called()
        mock_support_repo.create_event.assert_not_called()

    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_import_promotes_orphan_reply_to_root_case(self, mock_repo, mock_support_repo):
        application_id = uuid4()
        reporter_user_id = uuid4()
        legacy_issue_id = uuid4()
        created_at = datetime(2026, 3, 10, 14, 30, tzinfo=UTC)

        root_case = _make_case(
            id=uuid4(),
            application_id=application_id,
            title="Drawer Surface",
            status="open",
            first_event_at=created_at,
            last_event_at=created_at,
        )
        imported_issue = _make_issue_report(
            id=uuid4(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            reporter_role_hint="patient",
            component_key="drawer_surface",
            component_label="Drawer Surface",
            page_url="/patients/123/checkin",
            note="The drawer still closes itself before I finish typing.",
            support_case_id=root_case.id,
            created_at=created_at,
            updated_at=created_at,
        )

        mock_repo.get_issue_report_by_source_record = AsyncMock(return_value=None)
        mock_support_repo.get_case_by_external_ref = AsyncMock(return_value=None)
        mock_support_repo.create_case = AsyncMock(return_value=root_case)
        mock_support_repo.create_event = AsyncMock(
            return_value=_make_event(case_id=root_case.id, application_id=application_id)
        )
        mock_support_repo.update_case_summary = AsyncMock(return_value=root_case)
        mock_repo.create_issue_report = AsyncMock(return_value=imported_issue)

        summary = await import_htma_issue_logs(
            AsyncMock(),
            application_id=application_id,
            legacy_issue_logs=[
                HTMALegacyIssueLogRecord(
                    legacy_issue_id=legacy_issue_id,
                    reporter_user_id=reporter_user_id,
                    reporter_role_hint="patient",
                    component_label="Drawer Surface",
                    page_url="/patients/123/checkin",
                    note="The drawer still closes itself before I finish typing.",
                    created_at=created_at,
                    updated_at=created_at,
                    is_fixed=False,
                    parent_legacy_issue_id=uuid4(),
                )
            ],
        )

        assert summary["root_count"] == 1
        assert summary["reply_count"] == 0
        assert summary["orphaned_reply_count"] == 1
        assert mock_repo.create_issue_report.await_args.kwargs["parent_issue_report_id"] is None
        assert mock_support_repo.create_case.await_args.kwargs["external_case_ref"] == f"htma:issue-log:{legacy_issue_id}"
