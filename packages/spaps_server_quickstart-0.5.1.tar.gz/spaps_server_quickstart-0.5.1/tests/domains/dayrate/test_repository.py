"""Unit tests for the dayrate domain repository layer.

The database session is fully mocked so tests exercise only the
repository query construction and result handling.
"""

from __future__ import annotations

import datetime as dt
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

from spaps_server_quickstart.domains.dayrate import repository as repo

FAKE_APP_ID = uuid4()


def _mock_config(**overrides):
    """Create a mock DayRateConfig object."""
    config = MagicMock()
    config.id = overrides.get("id", uuid4())
    config.application_id = overrides.get("application_id", FAKE_APP_ID)
    config.base_rate = overrides.get("base_rate", 10000)
    config.available_days = overrides.get("available_days", ["monday", "tuesday"])
    config.slots = overrides.get("slots", None)
    config.fill_tiers = overrides.get("fill_tiers", None)
    config.time_tiers = overrides.get("time_tiers", None)
    config.horizon_weeks = overrides.get("horizon_weeks", 4)
    config.meeting_link = overrides.get("meeting_link", None)
    config.min_notice_hours = overrides.get("min_notice_hours", 24)
    config.hold_duration_minutes = overrides.get("hold_duration_minutes", 30)
    config.timezone = overrides.get("timezone", "America/New_York")
    config.slot_definitions = overrides.get("slot_definitions", None)
    config.currency = overrides.get("currency", "usd")
    config.product_name = overrides.get("product_name", None)
    config.created_at = dt.datetime.now(dt.UTC)
    config.updated_at = dt.datetime.now(dt.UTC)
    return config


def _mock_booking(**overrides):
    """Create a mock DayRateBooking object."""
    booking = MagicMock()
    booking.id = overrides.get("id", uuid4())
    booking.application_id = overrides.get("application_id", FAKE_APP_ID)
    booking.user_id = overrides.get("user_id", None)
    booking.date = overrides.get("date", dt.date.today())
    booking.slot_type = overrides.get("slot_type", "AM")
    booking.client_email = overrides.get("client_email", "test@example.com")
    booking.client_name = overrides.get("client_name", "Test Client")
    booking.price_paid = overrides.get("price_paid", 10000)
    booking.stripe_session_id = overrides.get("stripe_session_id", None)
    booking.stripe_payment_intent_id = overrides.get("stripe_payment_intent_id", None)
    booking.status = overrides.get("status", "pending")
    booking.metadata_ = overrides.get("metadata_", {})
    booking.booking_group_id = overrides.get("booking_group_id", None)
    booking.expires_at = overrides.get("expires_at", None)
    booking.created_at = dt.datetime.now(dt.UTC)
    booking.updated_at = dt.datetime.now(dt.UTC)
    return booking


def _mock_db_result(items):
    """Create a mock DB result that supports scalar_one_or_none and scalars."""
    result = MagicMock()
    result.scalar_one_or_none.return_value = items[0] if items else None

    scalars_mock = MagicMock()
    scalars_mock.all.return_value = items
    scalars_mock.first.return_value = items[0] if items else None
    result.scalars.return_value = scalars_mock

    return result


# ===========================================================================
# get_config
# ===========================================================================


class TestGetConfig:
    async def test_found(self):
        """Returns config when found."""
        config = _mock_config()
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([config])

        result = await repo.get_config(db, FAKE_APP_ID)
        assert result == config

    async def test_not_found(self):
        """Returns None when not found."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.get_config(db, FAKE_APP_ID)
        assert result is None


# ===========================================================================
# upsert_config
# ===========================================================================


class TestUpsertConfig:
    async def test_creates_new(self):
        """Creates new config when none exists."""
        db = AsyncMock()
        # First call (get_config) returns None
        db.execute.return_value = _mock_db_result([])
        db.add = MagicMock()

        result = await repo.upsert_config(
            db, FAKE_APP_ID, base_rate=15000
        )

        db.add.assert_called_once()
        db.flush.assert_called()
        db.refresh.assert_called()

    async def test_updates_existing(self):
        """Updates existing config."""
        config = _mock_config(base_rate=10000)
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([config])

        result = await repo.upsert_config(
            db, FAKE_APP_ID, base_rate=15000
        )

        assert config.base_rate == 15000
        db.flush.assert_called()
        db.refresh.assert_called()


# ===========================================================================
# Booking operations
# ===========================================================================


class TestGetBookingById:
    async def test_found(self):
        """Returns booking when found."""
        booking = _mock_booking()
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([booking])

        result = await repo.get_booking_by_id(db, booking.id)
        assert result == booking

    async def test_not_found(self):
        """Returns None when not found."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.get_booking_by_id(db, uuid4())
        assert result is None


class TestGetBookingsByStripeSessionId:
    async def test_returns_all_bookings_for_checkout_session(self):
        """Returns every booking tied to the Stripe checkout session."""
        bookings = [
            _mock_booking(slot_type="AM", stripe_session_id="cs_dayrate_123"),
            _mock_booking(slot_type="PM", stripe_session_id="cs_dayrate_123"),
        ]
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(bookings)

        result = await repo.get_bookings_by_stripe_session_id(db, "cs_dayrate_123")

        assert result == bookings
        sql = str(db.execute.await_args.args[0])
        assert "dayrate_bookings.stripe_session_id" in sql


class TestGetBookingsForDate:
    async def test_returns_bookings(self):
        """Returns list of bookings for a date."""
        bookings = [_mock_booking(), _mock_booking(slot_type="PM")]
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(bookings)

        result = await repo.get_bookings_for_date(
            db, FAKE_APP_ID, dt.date.today()
        )
        assert len(result) == 2

    async def test_empty(self):
        """Returns empty list when no bookings."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.get_bookings_for_date(
            db, FAKE_APP_ID, dt.date.today()
        )
        assert len(result) == 0


class TestGetBookingsInRange:
    async def test_returns_bookings(self):
        """Returns bookings within date range."""
        bookings = [_mock_booking(), _mock_booking()]
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(bookings)

        result = await repo.get_bookings_in_range(
            db,
            FAKE_APP_ID,
            dt.date.today(),
            dt.date.today() + dt.timedelta(weeks=4),
        )
        assert len(result) == 2


class TestGetBookingsForDates:
    async def test_returns_bookings_across_dates(self):
        """Returns active bookings for all requested dates in one query."""
        bookings = [
            _mock_booking(date=dt.date(2026, 1, 10), slot_type="AM"),
            _mock_booking(date=dt.date(2026, 1, 11), slot_type="PM"),
        ]
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(bookings)

        result = await repo.get_bookings_for_dates(
            db,
            FAKE_APP_ID,
            [dt.date(2026, 1, 10), dt.date(2026, 1, 11)],
        )

        assert result == bookings
        sql = str(db.execute.await_args.args[0])
        assert "dayrate_bookings.date IN" in sql

    async def test_empty_dates_short_circuits(self):
        """Does not issue a query when no dates are requested."""
        db = AsyncMock()

        result = await repo.get_bookings_for_dates(db, FAKE_APP_ID, [])

        assert result == []
        db.execute.assert_not_awaited()


class TestCreateBooking:
    async def test_creates_and_returns(self):
        """Creates booking and returns it."""
        db = AsyncMock()
        db.add = MagicMock()

        result = await repo.create_booking(
            db,
            application_id=FAKE_APP_ID,
            date=dt.date.today(),
            slot_type="AM",
            client_email="test@example.com",
            client_name="Test Client",
            price_paid=10000,
            status="pending",
        )

        db.add.assert_called_once()
        db.flush.assert_called_once()
        db.refresh.assert_called_once()


class TestCreateBookings:
    async def test_creates_and_returns_all(self):
        """Creates multiple bookings with one flush."""
        db = AsyncMock()
        db.add_all = MagicMock()

        result = await repo.create_bookings(
            db,
            [
                {
                    "application_id": FAKE_APP_ID,
                    "date": dt.date(2026, 1, 10),
                    "slot_type": "AM",
                    "client_email": "test@example.com",
                    "client_name": "Test Client",
                    "price_paid": 10000,
                    "status": "pending",
                },
                {
                    "application_id": FAKE_APP_ID,
                    "date": dt.date(2026, 1, 11),
                    "slot_type": "PM",
                    "client_email": "test@example.com",
                    "client_name": "Test Client",
                    "price_paid": 10000,
                    "status": "pending",
                },
            ],
        )

        db.add_all.assert_called_once()
        db.flush.assert_called_once()
        assert len(result) == 2
        assert all(booking.application_id == FAKE_APP_ID for booking in result)

    async def test_empty_bookings_short_circuits(self):
        """Returns an empty list without touching the session."""
        db = AsyncMock()
        db.add_all = MagicMock()

        result = await repo.create_bookings(db, [])

        assert result == []
        db.add_all.assert_not_called()
        db.flush.assert_not_awaited()


class TestExpireStalePendingsForSlots:
    async def test_updates_all_requested_slots(self):
        """Expires stale pending holds for all requested slots in one statement."""
        db = AsyncMock()
        result = MagicMock()
        result.rowcount = 3
        db.execute.return_value = result

        updated = await repo.expire_stale_pendings_for_slots(
            db,
            FAKE_APP_ID,
            [
                (dt.date(2026, 1, 10), "AM"),
                (dt.date(2026, 1, 11), "PM"),
            ],
        )

        assert updated == 3
        sql = str(db.execute.await_args.args[0])
        assert "dayrate_bookings.date = " in sql
        assert "dayrate_bookings.slot_type = " in sql

    async def test_empty_slots_short_circuits(self):
        """Does not issue an update when no slots are requested."""
        db = AsyncMock()

        updated = await repo.expire_stale_pendings_for_slots(db, FAKE_APP_ID, [])

        assert updated == 0
        db.execute.assert_not_awaited()


class TestUpdateBooking:
    async def test_updates(self):
        """Updates booking fields."""
        booking = _mock_booking(status="pending")
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([booking])

        result = await repo.update_booking(
            db, booking.id, status="confirmed"
        )

        assert booking.status == "confirmed"
        db.flush.assert_called()
        db.refresh.assert_called()

    async def test_not_found(self):
        """Returns None for unknown booking."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.update_booking(db, uuid4(), status="confirmed")
        assert result is None


class TestListBookings:
    async def test_returns_bookings_and_total(self):
        """Returns bookings list and total count."""
        bookings = [_mock_booking(), _mock_booking()]
        db = AsyncMock()

        # First execute: COUNT(*) query returns scalar int
        count_result = MagicMock()
        count_result.scalar.return_value = 2

        # Second execute: paginated query returns ORM rows
        db.execute.side_effect = [
            count_result,
            _mock_db_result(bookings),
        ]

        result_bookings, total = await repo.list_bookings(
            db, FAKE_APP_ID
        )
        assert len(result_bookings) == 2
        assert total == 2

    async def test_applies_all_optional_filters_to_count_and_data_queries(self):
        bookings = [_mock_booking(user_id=uuid4(), client_email="client@example.com")]
        db = AsyncMock()

        count_result = MagicMock()
        count_result.scalar.return_value = 1
        db.execute.side_effect = [
            count_result,
            _mock_db_result(bookings),
        ]

        await repo.list_bookings(
            db,
            FAKE_APP_ID,
            status="confirmed",
            start_date=dt.date(2026, 1, 1),
            end_date=dt.date(2026, 1, 31),
            client_email="client@example.com",
            enrollment_id="enroll-123",
            user_id=uuid4(),
            is_free=True,
            limit=25,
            offset=10,
        )

        count_sql = str(db.execute.await_args_list[0].args[0])
        data_sql = str(db.execute.await_args_list[1].args[0])
        assert "dayrate_bookings.status" in count_sql
        assert "dayrate_bookings.client_email" in count_sql
        assert "dayrate_bookings.enrollment_id" in count_sql
        assert "dayrate_bookings.user_id" in count_sql
        assert "dayrate_bookings.is_free" in count_sql
        assert "ORDER BY dayrate_bookings.date DESC" in data_sql


class TestCountAllotmentBookings:
    async def test_matches_by_user_or_email(self):
        db = AsyncMock()
        count_result = MagicMock()
        count_result.scalar.return_value = 3
        db.execute.return_value = count_result

        result = await repo.count_allotment_bookings(
            db,
            FAKE_APP_ID,
            dt.datetime(2026, 1, 1, tzinfo=dt.UTC),
            user_id=uuid4(),
            email="client@example.com",
        )

        assert result == 3
        sql = str(db.execute.await_args.args[0])
        assert "dayrate_bookings.replaces_booking_id IS NULL" in sql
        assert "dayrate_bookings.client_email" in sql
        assert "dayrate_bookings.user_id" in sql

    async def test_matches_by_user_only(self):
        db = AsyncMock()
        count_result = MagicMock()
        count_result.scalar.return_value = 1
        db.execute.return_value = count_result

        await repo.count_allotment_bookings(
            db,
            FAKE_APP_ID,
            dt.datetime(2026, 1, 1, tzinfo=dt.UTC),
            user_id=uuid4(),
        )

        sql = str(db.execute.await_args.args[0])
        assert "dayrate_bookings.user_id" in sql

    async def test_matches_by_email_only(self):
        db = AsyncMock()
        count_result = MagicMock()
        count_result.scalar.return_value = 2
        db.execute.return_value = count_result

        await repo.count_allotment_bookings(
            db,
            FAKE_APP_ID,
            dt.datetime(2026, 1, 1, tzinfo=dt.UTC),
            email="legacy@example.com",
        )

        sql = str(db.execute.await_args.args[0])
        assert "dayrate_bookings.client_email" in sql
