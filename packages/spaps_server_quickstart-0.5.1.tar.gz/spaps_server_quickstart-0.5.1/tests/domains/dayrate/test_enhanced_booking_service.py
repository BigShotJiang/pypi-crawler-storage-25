"""Unit tests for enhanced booking service: free path, reschedule, cancel.

Tests the policy-aware booking flow, atomic reschedule, patient cancel,
ownership resolution, and webhook dispatch.
Written TDD-first -- implements shared.md US-1,2,3,4,6,9 and backend.md Rules 2,3,4,6.
"""

from __future__ import annotations

import datetime as dt
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.dayrate import service as dayrate_service
from spaps_server_quickstart.domains.dayrate.errors import (
    AllotmentExhaustedError,
    BookingAlreadyCancelledError,
    BookingNotFoundError,
    NotBookingOwnerError,
    PolicyNotFoundError,
    SlotUnavailableError,
)

_REPO = "spaps_server_quickstart.domains.dayrate.service.repo"
_ENT_REPO = "spaps_server_quickstart.domains.dayrate.service.ent_repo"
_WEBHOOK = "spaps_server_quickstart.domains.dayrate.service.webhook_service"

FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()


def _make_config(**overrides) -> MagicMock:
    """Build a mock DayRateConfig model instance.

    Defaults to HTMA-style 30-minute slot definitions for checkin_call tests.
    """
    config = MagicMock()
    config.id = overrides.get("id", uuid4())
    config.application_id = overrides.get("application_id", FAKE_APP_ID)
    config.base_rate = overrides.get("base_rate", 10000)
    config.available_days = overrides.get(
        "available_days", ["monday", "tuesday", "wednesday", "thursday", "friday"]
    )
    config.slots = overrides.get("slots", None)
    config.fill_tiers = overrides.get("fill_tiers", None)
    config.time_tiers = overrides.get("time_tiers", None)
    config.horizon_weeks = overrides.get("horizon_weeks", 4)
    config.meeting_link = overrides.get("meeting_link", "https://meet.example.com")
    config.min_notice_hours = overrides.get("min_notice_hours", 0)
    config.hold_duration_minutes = overrides.get("hold_duration_minutes", 30)
    config.timezone = overrides.get("timezone", "America/New_York")
    # Default to HTMA-style slot definitions so time-based slots validate
    config.slot_definitions = overrides.get("slot_definitions", {
        "AM": {"label": "Morning", "startHour": 9, "endHour": 13},
        "PM": {"label": "Afternoon", "startHour": 13, "endHour": 17},
        "10:00": {"label": "10:00am", "startHour": 10, "endHour": 10},
        "10:30": {"label": "10:30am", "startHour": 10, "endHour": 11},
        "14:00": {"label": "2:00pm", "startHour": 14, "endHour": 14},
        "14:30": {"label": "2:30pm", "startHour": 14, "endHour": 15},
    })
    config.currency = overrides.get("currency", "usd")
    config.product_name = overrides.get("product_name", "Day Rate Consulting")
    config.created_at = dt.datetime.now(dt.UTC)
    config.updated_at = dt.datetime.now(dt.UTC)
    return config


def _make_policy(**overrides) -> MagicMock:
    """Build a mock BookingPolicy model instance."""
    policy = MagicMock()
    policy.id = overrides.get("id", uuid4())
    policy.application_id = overrides.get("application_id", FAKE_APP_ID)
    policy.policy_key = overrides.get("policy_key", "checkin_call")
    policy.entitlement_key = overrides.get("entitlement_key", "htma_checkin_call")
    policy.free_bookings_per_period = overrides.get("free_bookings_per_period", 2)
    policy.period_days = overrides.get("period_days", 28)
    policy.overage_rate = overrides.get("overage_rate", 5000)
    policy.overage_currency = overrides.get("overage_currency", "usd")
    policy.overage_product_name = overrides.get(
        "overage_product_name", "Additional Check-in Call"
    )
    policy.reschedule_is_free = overrides.get("reschedule_is_free", True)
    policy.is_active = overrides.get("is_active", True)
    policy.metadata_ = overrides.get("metadata_", {})
    policy.created_at = dt.datetime.now(dt.UTC)
    policy.updated_at = dt.datetime.now(dt.UTC)
    return policy


def _make_entitlement(**overrides) -> MagicMock:
    """Build a mock Entitlement."""
    ent = MagicMock()
    ent.id = overrides.get("id", uuid4())
    ent.beneficiary_user_id = overrides.get("beneficiary_user_id", FAKE_USER_ID)
    ent.beneficiary_email = overrides.get("beneficiary_email", "patient@example.com")
    ent.entitlement_key = overrides.get("entitlement_key", "htma_checkin_call")
    ent.revoked_at = overrides.get("revoked_at", None)
    ent.ends_at = overrides.get("ends_at", None)
    return ent


def _make_booking(**overrides) -> MagicMock:
    """Build a mock DayRateBooking model instance."""
    booking = MagicMock()
    booking.id = overrides.get("id", uuid4())
    booking.application_id = overrides.get("application_id", FAKE_APP_ID)
    booking.user_id = overrides.get("user_id", FAKE_USER_ID)
    booking.date = overrides.get("date", dt.date.today() + dt.timedelta(days=7))
    booking.slot_type = overrides.get("slot_type", "10:00")
    booking.client_email = overrides.get("client_email", "patient@example.com")
    booking.client_name = overrides.get("client_name", "Jane Doe")
    booking.price_paid = overrides.get("price_paid", 0)
    booking.stripe_session_id = overrides.get("stripe_session_id", None)
    booking.stripe_payment_intent_id = overrides.get("stripe_payment_intent_id", None)
    booking.status = overrides.get("status", "confirmed")
    booking.metadata_ = overrides.get("metadata_", {})
    booking.booking_group_id = overrides.get("booking_group_id", None)
    booking.expires_at = overrides.get("expires_at", None)
    booking.enrollment_id = overrides.get("enrollment_id", None)
    booking.replaces_booking_id = overrides.get("replaces_booking_id", None)
    booking.policy_key = overrides.get("policy_key", "checkin_call")
    booking.is_free = overrides.get("is_free", True)
    booking.created_at = overrides.get("created_at", dt.datetime.now(dt.UTC))
    booking.updated_at = overrides.get("updated_at", dt.datetime.now(dt.UTC))
    return booking


# ===========================================================================
# Enhanced book_slot: free booking path (US-1)
# ===========================================================================


class TestFreeBookingPath:
    @patch(_WEBHOOK)
    @patch(_ENT_REPO)
    @patch(_REPO)
    async def test_free_booking_success(self, mock_repo, mock_ent_repo, mock_webhook):
        """Patient with entitlement + remaining allotment -> auto-confirmed free booking."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        policy = _make_policy(free_bookings_per_period=2)
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=policy)
        mock_repo.lock_policy_for_allotment = AsyncMock(return_value=policy)

        ent = _make_entitlement()
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent])
        mock_repo.count_allotment_bookings = AsyncMock(return_value=0)

        future_date = dt.date.today() + dt.timedelta(days=7)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])

        booking = _make_booking(date=future_date, is_free=True, status="confirmed")
        mock_repo.create_booking = AsyncMock(return_value=booking)
        mock_webhook.trigger_event = AsyncMock(return_value=None)

        db = AsyncMock()
        result = await dayrate_service.book_slot(
            db,
            application_id=FAKE_APP_ID,
            date_str=future_date.isoformat(),
            slot="AM",
            client_email="patient@example.com",
            client_name="Jane Doe",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            policy_key="checkin_call",
            user_id=FAKE_USER_ID,
        )

        assert result["bookingId"] == str(booking.id)
        assert result["status"] == "confirmed"
        assert result["isFree"] is True
        assert result["allotment"]["total"] == 2
        assert result["allotment"]["used"] == 1  # after creating this booking
        assert result["allotment"]["remaining"] == 1
        entitlement_kwargs = mock_ent_repo.list_entitlements.await_args.kwargs
        assert entitlement_kwargs["user_id"] == FAKE_USER_ID
        assert entitlement_kwargs["email"] == "patient@example.com"

    @patch(_WEBHOOK)
    @patch(_ENT_REPO)
    @patch(_REPO)
    async def test_free_booking_uses_trusted_identity_instead_of_caller_input(
        self,
        mock_repo,
        mock_ent_repo,
        mock_webhook,
    ):
        """Free bookings qualify and persist against the trusted identity only."""
        trusted_user_id = uuid4()
        caller_supplied_user_id = uuid4()
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        policy = _make_policy(free_bookings_per_period=2)
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=policy)
        mock_repo.lock_policy_for_allotment = AsyncMock(return_value=policy)

        ent = _make_entitlement(
            beneficiary_user_id=trusted_user_id,
            beneficiary_email="member@example.com",
        )
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent])
        mock_repo.count_allotment_bookings = AsyncMock(return_value=0)

        future_date = dt.date.today() + dt.timedelta(days=7)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])

        booking = _make_booking(
            date=future_date,
            is_free=True,
            status="confirmed",
            user_id=trusted_user_id,
            client_email="member@example.com",
        )
        mock_repo.create_booking = AsyncMock(return_value=booking)
        mock_webhook.trigger_event = AsyncMock(return_value=None)

        db = AsyncMock()
        result = await dayrate_service.book_slot(
            db,
            application_id=FAKE_APP_ID,
            date_str=future_date.isoformat(),
            slot="AM",
            client_email="victim@example.com",
            client_name="Jane Doe",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            policy_key="checkin_call",
            user_id=caller_supplied_user_id,
            allow_free_booking=True,
            free_booking_user_id=trusted_user_id,
            free_booking_email="member@example.com",
        )

        assert result["isFree"] is True
        entitlement_kwargs = mock_ent_repo.list_entitlements.await_args.kwargs
        assert entitlement_kwargs["user_id"] == trusted_user_id
        assert entitlement_kwargs["email"] == "member@example.com"
        allotment_kwargs = mock_repo.count_allotment_bookings.await_args.kwargs
        assert allotment_kwargs["user_id"] == trusted_user_id
        assert allotment_kwargs["email"] == "member@example.com"
        create_kwargs = mock_repo.create_booking.await_args.kwargs
        assert create_kwargs["user_id"] == trusted_user_id
        assert create_kwargs["client_email"] == "member@example.com"

    @patch(_WEBHOOK)
    @patch(_ENT_REPO)
    @patch(_REPO)
    async def test_no_policy_key_falls_to_paid(self, mock_repo, mock_ent_repo, mock_webhook):
        """No policyKey -> existing paid Stripe flow (buildooor path)."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        future_date = dt.date.today() + dt.timedelta(days=7)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        booking = _make_booking(date=future_date, is_free=False, status="pending")
        mock_repo.create_booking = AsyncMock(return_value=booking)

        db = AsyncMock()
        result = await dayrate_service.book_slot(
            db,
            application_id=FAKE_APP_ID,
            date_str=future_date.isoformat(),
            slot="AM",
            client_email="test@example.com",
            client_name="Test Client",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            # No policy_key -> paid flow
        )

        # Paid flow returns checkoutUrl, not allotment
        assert "checkoutUrl" in result
        assert "bookingId" in result

    @patch(_WEBHOOK)
    @patch(_ENT_REPO)
    @patch(_REPO)
    async def test_policy_key_not_found_raises(self, mock_repo, mock_ent_repo, mock_webhook):
        """policyKey provided but no matching policy -> 404."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)

        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=None)

        future_date = dt.date.today() + dt.timedelta(days=7)
        db = AsyncMock()
        with pytest.raises(PolicyNotFoundError):
            await dayrate_service.book_slot(
                db,
                application_id=FAKE_APP_ID,
                date_str=future_date.isoformat(),
                slot="AM",
                client_email="patient@example.com",
                client_name="Jane Doe",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
                policy_key="nonexistent",
            )

    @patch(_WEBHOOK)
    @patch(_ENT_REPO)
    @patch(_REPO)
    async def test_no_entitlement_falls_to_paid(self, mock_repo, mock_ent_repo, mock_webhook):
        """Policy exists but user lacks entitlement -> falls to Stripe paid flow."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        policy = _make_policy()
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=policy)
        mock_repo.lock_policy_for_allotment = AsyncMock(return_value=policy)

        # No entitlement
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[])

        future_date = dt.date.today() + dt.timedelta(days=7)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        booking = _make_booking(date=future_date, is_free=False, status="pending")
        mock_repo.create_booking = AsyncMock(return_value=booking)

        db = AsyncMock()
        result = await dayrate_service.book_slot(
            db,
            application_id=FAKE_APP_ID,
            date_str=future_date.isoformat(),
            slot="AM",
            client_email="patient@example.com",
            client_name="Jane Doe",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            policy_key="checkin_call",
        )

        # Falls to paid flow
        assert "checkoutUrl" in result

    @patch(_WEBHOOK)
    @patch(_ENT_REPO)
    @patch(_REPO)
    async def test_disallowed_free_booking_falls_to_paid_without_entitlement_lookup(
        self,
        mock_repo,
        mock_ent_repo,
        mock_webhook,
    ):
        """Unauthenticated publishable callers keep the paid path and skip free redemption."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        policy = _make_policy()
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=policy)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        future_date = dt.date.today() + dt.timedelta(days=7)
        booking = _make_booking(date=future_date, is_free=False, status="pending")
        mock_repo.create_booking = AsyncMock(return_value=booking)

        db = AsyncMock()
        result = await dayrate_service.book_slot(
            db,
            application_id=FAKE_APP_ID,
            date_str=future_date.isoformat(),
            slot="AM",
            client_email="victim@example.com",
            client_name="Jane Doe",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            policy_key="checkin_call",
            user_id=uuid4(),
            allow_free_booking=False,
        )

        assert "checkoutUrl" in result
        mock_repo.lock_policy_for_allotment.assert_not_called()
        mock_ent_repo.list_entitlements.assert_not_called()

    @patch(_WEBHOOK)
    @patch(_ENT_REPO)
    @patch(_REPO)
    async def test_allotment_exhausted_no_overage_raises(
        self, mock_repo, mock_ent_repo, mock_webhook
    ):
        """Allotment exhausted + no overage_rate -> 403."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)

        policy = _make_policy(
            free_bookings_per_period=1, overage_rate=None
        )
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=policy)
        mock_repo.lock_policy_for_allotment = AsyncMock(return_value=policy)

        ent = _make_entitlement()
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent])
        mock_repo.count_allotment_bookings = AsyncMock(return_value=1)

        future_date = dt.date.today() + dt.timedelta(days=7)
        db = AsyncMock()
        with pytest.raises(AllotmentExhaustedError):
            await dayrate_service.book_slot(
                db,
                application_id=FAKE_APP_ID,
                date_str=future_date.isoformat(),
                slot="AM",
                client_email="patient@example.com",
                client_name="Jane Doe",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
                policy_key="checkin_call",
                user_id=FAKE_USER_ID,
            )

    @patch(_WEBHOOK)
    @patch(_ENT_REPO)
    @patch(_REPO)
    async def test_allotment_exhausted_with_overage_falls_to_stripe(
        self, mock_repo, mock_ent_repo, mock_webhook
    ):
        """Allotment exhausted + overage_rate set -> Stripe checkout at overage_rate."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        policy = _make_policy(
            free_bookings_per_period=1, overage_rate=5000
        )
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=policy)
        mock_repo.lock_policy_for_allotment = AsyncMock(return_value=policy)

        ent = _make_entitlement()
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent])
        mock_repo.count_allotment_bookings = AsyncMock(return_value=1)

        future_date = dt.date.today() + dt.timedelta(days=7)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        booking = _make_booking(date=future_date, is_free=False, status="pending")
        mock_repo.create_booking = AsyncMock(return_value=booking)

        db = AsyncMock()
        result = await dayrate_service.book_slot(
            db,
            application_id=FAKE_APP_ID,
            date_str=future_date.isoformat(),
            slot="AM",
            client_email="patient@example.com",
            client_name="Jane Doe",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            policy_key="checkin_call",
            user_id=FAKE_USER_ID,
        )

        # Should get checkout at overage_rate
        assert "checkoutUrl" in result
        assert result["price"] == 5000

    @patch(_WEBHOOK)
    @patch(_ENT_REPO)
    @patch(_REPO)
    async def test_enrollment_id_stored(self, mock_repo, mock_ent_repo, mock_webhook):
        """enrollmentId passed on booking creation is stored."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        policy = _make_policy()
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=policy)
        mock_repo.lock_policy_for_allotment = AsyncMock(return_value=policy)

        ent = _make_entitlement()
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent])
        mock_repo.count_allotment_bookings = AsyncMock(return_value=0)

        future_date = dt.date.today() + dt.timedelta(days=7)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])

        enrollment_id = str(uuid4())
        booking = _make_booking(
            date=future_date, enrollment_id=enrollment_id, is_free=True
        )
        mock_repo.create_booking = AsyncMock(return_value=booking)
        mock_webhook.trigger_event = AsyncMock(return_value=None)

        db = AsyncMock()
        result = await dayrate_service.book_slot(
            db,
            application_id=FAKE_APP_ID,
            date_str=future_date.isoformat(),
            slot="AM",
            client_email="patient@example.com",
            client_name="Jane Doe",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            policy_key="checkin_call",
            user_id=FAKE_USER_ID,
            enrollment_id=enrollment_id,
        )

        # Verify enrollment_id was passed to create_booking
        call_kwargs = mock_repo.create_booking.call_args.kwargs
        assert call_kwargs["enrollment_id"] == enrollment_id


# ===========================================================================
# Reschedule (US-2)
# ===========================================================================


class TestReschedule:
    @patch(_WEBHOOK)
    @patch(_REPO)
    async def test_reschedule_success(self, mock_repo, mock_webhook):
        """Atomic reschedule: cancel old, create new, allotment unchanged."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        old_booking_id = uuid4()
        old_booking = _make_booking(
            id=old_booking_id,
            status="confirmed",
            user_id=FAKE_USER_ID,
            is_free=True,
            policy_key="checkin_call",
            enrollment_id="enrollment-123",
        )
        mock_repo.get_booking_by_id_for_update = AsyncMock(return_value=old_booking)
        mock_repo.update_booking = AsyncMock(return_value=old_booking)

        new_date = dt.date.today() + dt.timedelta(days=8)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])

        new_booking = _make_booking(
            date=new_date,
            replaces_booking_id=old_booking_id,
            is_free=True,
            enrollment_id="enrollment-123",
        )
        mock_repo.create_booking = AsyncMock(return_value=new_booking)
        mock_webhook.trigger_event = AsyncMock(return_value=None)

        db = AsyncMock()
        result = await dayrate_service.book_slot(
            db,
            application_id=FAKE_APP_ID,
            date_str=new_date.isoformat(),
            slot="14:00",
            client_email="patient@example.com",
            client_name="Jane Doe",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            replaces_booking_id=old_booking_id,
            user_id=FAKE_USER_ID,
        )

        assert result["bookingId"] == str(new_booking.id)
        assert result["status"] == "confirmed"
        # Old booking should be cancelled
        mock_repo.update_booking.assert_called()

    @patch(_WEBHOOK)
    @patch(_REPO)
    async def test_reschedule_old_not_found(self, mock_repo, mock_webhook):
        """replacesBookingId not found -> 404."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)

        mock_repo.get_booking_by_id_for_update = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(BookingNotFoundError):
            await dayrate_service.book_slot(
                db,
                application_id=FAKE_APP_ID,
                date_str=(dt.date.today() + dt.timedelta(days=7)).isoformat(),
                slot="10:00",
                client_email="patient@example.com",
                client_name="Jane Doe",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
                replaces_booking_id=uuid4(),
                user_id=FAKE_USER_ID,
            )

    @patch(_WEBHOOK)
    @patch(_REPO)
    async def test_reschedule_old_already_cancelled(self, mock_repo, mock_webhook):
        """Old booking already cancelled -> 400."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)

        old_booking = _make_booking(status="cancelled", user_id=FAKE_USER_ID)
        mock_repo.get_booking_by_id_for_update = AsyncMock(return_value=old_booking)

        db = AsyncMock()
        with pytest.raises(BookingAlreadyCancelledError):
            await dayrate_service.book_slot(
                db,
                application_id=FAKE_APP_ID,
                date_str=(dt.date.today() + dt.timedelta(days=7)).isoformat(),
                slot="10:00",
                client_email="patient@example.com",
                client_name="Jane Doe",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
                replaces_booking_id=old_booking.id,
                user_id=FAKE_USER_ID,
            )

    @patch(_WEBHOOK)
    @patch(_REPO)
    async def test_reschedule_not_owner_raises(self, mock_repo, mock_webhook):
        """Different user tries to reschedule -> 403."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)

        other_user = uuid4()
        old_booking = _make_booking(status="confirmed", user_id=other_user)
        mock_repo.get_booking_by_id_for_update = AsyncMock(return_value=old_booking)

        db = AsyncMock()
        with pytest.raises(NotBookingOwnerError):
            await dayrate_service.book_slot(
                db,
                application_id=FAKE_APP_ID,
                date_str=(dt.date.today() + dt.timedelta(days=7)).isoformat(),
                slot="10:00",
                client_email="patient@example.com",
                client_name="Jane Doe",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
                replaces_booking_id=old_booking.id,
                user_id=FAKE_USER_ID,
            )

    @patch(_WEBHOOK)
    @patch(_REPO)
    async def test_reschedule_new_slot_unavailable_preserves_old(
        self, mock_repo, mock_webhook
    ):
        """New slot unavailable -> 409 SLOT_UNAVAILABLE, old booking NOT cancelled."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)

        old_booking = _make_booking(status="confirmed", user_id=FAKE_USER_ID)
        mock_repo.get_booking_by_id_for_update = AsyncMock(return_value=old_booking)

        # New slot already taken
        taken = _make_booking(slot_type="14:00")
        new_date = dt.date.today() + dt.timedelta(days=7)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[taken])

        db = AsyncMock()
        with pytest.raises(SlotUnavailableError):
            await dayrate_service.book_slot(
                db,
                application_id=FAKE_APP_ID,
                date_str=new_date.isoformat(),
                slot="14:00",
                client_email="patient@example.com",
                client_name="Jane Doe",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
                replaces_booking_id=old_booking.id,
                user_id=FAKE_USER_ID,
            )

        # Old booking should NOT be cancelled
        mock_repo.update_booking.assert_not_called()


# ===========================================================================
# Patient Cancel (US-4)
# ===========================================================================


class TestCancelBookingByOwner:
    @patch(_WEBHOOK)
    @patch(_REPO)
    async def test_cancel_success(self, mock_repo, mock_webhook):
        """Owner cancels own booking -> status=cancelled, allotment returned."""
        booking = _make_booking(status="confirmed", user_id=FAKE_USER_ID)
        mock_repo.get_booking_by_id = AsyncMock(return_value=booking)
        mock_repo.update_booking = AsyncMock(return_value=booking)

        # For allotment calculation after cancel
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=None)
        mock_webhook.trigger_event = AsyncMock(return_value=None)

        db = AsyncMock()
        result = await dayrate_service.cancel_booking_by_owner(
            db,
            application_id=FAKE_APP_ID,
            booking_id=booking.id,
            user_id=FAKE_USER_ID,
        )

        assert result["bookingId"] == str(booking.id)
        assert result["status"] == "cancelled"

    @patch(_WEBHOOK)
    @patch(_REPO)
    async def test_cancel_not_found(self, mock_repo, mock_webhook):
        """Booking not found -> 404."""
        mock_repo.get_booking_by_id = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(BookingNotFoundError):
            await dayrate_service.cancel_booking_by_owner(
                db,
                application_id=FAKE_APP_ID,
                booking_id=uuid4(),
                user_id=FAKE_USER_ID,
            )

    @patch(_WEBHOOK)
    @patch(_REPO)
    async def test_cancel_already_cancelled(self, mock_repo, mock_webhook):
        """Already cancelled -> 400."""
        booking = _make_booking(status="cancelled", user_id=FAKE_USER_ID)
        mock_repo.get_booking_by_id = AsyncMock(return_value=booking)

        db = AsyncMock()
        with pytest.raises(BookingAlreadyCancelledError):
            await dayrate_service.cancel_booking_by_owner(
                db,
                application_id=FAKE_APP_ID,
                booking_id=booking.id,
                user_id=FAKE_USER_ID,
            )

    @patch(_WEBHOOK)
    @patch(_REPO)
    async def test_cancel_not_owner_user_id_mismatch(self, mock_repo, mock_webhook):
        """Caller user_id doesn't match booking user_id -> 403."""
        other_user = uuid4()
        booking = _make_booking(status="confirmed", user_id=other_user)
        mock_repo.get_booking_by_id = AsyncMock(return_value=booking)

        db = AsyncMock()
        with pytest.raises(NotBookingOwnerError):
            await dayrate_service.cancel_booking_by_owner(
                db,
                application_id=FAKE_APP_ID,
                booking_id=booking.id,
                user_id=FAKE_USER_ID,
            )

    @patch(_WEBHOOK)
    @patch(_REPO)
    async def test_cancel_ownership_email_fallback(self, mock_repo, mock_webhook):
        """Booking has no user_id -> fallback to client_email matching."""
        booking = _make_booking(
            status="confirmed",
            user_id=None,
            client_email="patient@example.com",
        )
        mock_repo.get_booking_by_id = AsyncMock(return_value=booking)
        mock_repo.update_booking = AsyncMock(return_value=booking)
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=None)
        mock_webhook.trigger_event = AsyncMock(return_value=None)

        db = AsyncMock()
        result = await dayrate_service.cancel_booking_by_owner(
            db,
            application_id=FAKE_APP_ID,
            booking_id=booking.id,
            email="patient@example.com",
        )

        assert result["status"] == "cancelled"

    @patch(_WEBHOOK)
    @patch(_REPO)
    async def test_cancel_ownership_email_fallback_mismatch(
        self, mock_repo, mock_webhook
    ):
        """Booking has no user_id + email doesn't match -> 403."""
        booking = _make_booking(
            status="confirmed",
            user_id=None,
            client_email="other@example.com",
        )
        mock_repo.get_booking_by_id = AsyncMock(return_value=booking)

        db = AsyncMock()
        with pytest.raises(NotBookingOwnerError):
            await dayrate_service.cancel_booking_by_owner(
                db,
                application_id=FAKE_APP_ID,
                booking_id=booking.id,
                email="patient@example.com",
            )
