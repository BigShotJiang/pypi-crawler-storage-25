"""Unit tests for the policy engine service layer.

The repository and evaluator are mocked so tests exercise only the
service orchestration, validation, and error handling.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.policies import service
from spaps_server_quickstart.domains.policies.errors import (
    InvalidConditionError,
    PolicyAlreadyExistsError,
    PolicyNotFoundError,
)

_REPO = "spaps_server_quickstart.domains.policies.service.repo"

FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()


def _make_policy(
    name: str = "test_policy",
    effect: str = "allow",
    conditions: dict | None = None,
    is_active: bool = True,
) -> MagicMock:
    policy = MagicMock()
    policy.id = uuid4()
    policy.application_id = FAKE_APP_ID
    policy.name = name
    policy.description = "A test policy"
    policy.effect = effect
    policy.conditions = conditions or {"has_role": {"role": "admin"}}
    policy.priority = 0
    policy.is_active = is_active
    policy.metadata_ = {}
    policy.created_at = datetime.now(UTC)
    policy.updated_at = datetime.now(UTC)
    return policy


# ---------------------------------------------------------------------------
# Create
# ---------------------------------------------------------------------------


class TestCreatePolicy:
    @pytest.mark.asyncio
    async def test_creates_successfully(self):
        db = AsyncMock()
        policy = _make_policy()

        with patch(f"{_REPO}.get_policy_by_name", return_value=None), \
             patch(f"{_REPO}.create_policy", return_value=policy):
            result = await service.create_policy(
                db,
                application_id=FAKE_APP_ID,
                name="test_policy",
                conditions={"has_role": {"role": "admin"}},
            )

        assert result["policy"]["name"] == "test_policy"

    @pytest.mark.asyncio
    async def test_rejects_duplicate_name(self):
        db = AsyncMock()
        existing = _make_policy()

        with patch(f"{_REPO}.get_policy_by_name", return_value=existing), \
             pytest.raises(PolicyAlreadyExistsError):
            await service.create_policy(
                db,
                application_id=FAKE_APP_ID,
                name="test_policy",
                conditions={"has_role": {"role": "admin"}},
            )

    @pytest.mark.asyncio
    async def test_rejects_invalid_conditions(self):
        db = AsyncMock()
        with pytest.raises(InvalidConditionError):
            await service.create_policy(
                db,
                application_id=FAKE_APP_ID,
                name="bad_policy",
                conditions={"bogus_type": {"foo": "bar"}},
            )

    @pytest.mark.asyncio
    async def test_rejects_empty_conditions(self):
        db = AsyncMock()
        with pytest.raises(InvalidConditionError):
            await service.create_policy(
                db,
                application_id=FAKE_APP_ID,
                name="empty_policy",
                conditions={},
            )


# ---------------------------------------------------------------------------
# Get / List
# ---------------------------------------------------------------------------


class TestGetPolicy:
    @pytest.mark.asyncio
    async def test_returns_policy(self):
        db = AsyncMock()
        policy = _make_policy()

        with patch(f"{_REPO}.get_policy_by_id", return_value=policy):
            result = await service.get_policy(
                db,
                policy_id=policy.id,
                application_id=FAKE_APP_ID,
            )

        assert result["policy"]["id"] == str(policy.id)

    @pytest.mark.asyncio
    async def test_not_found(self):
        db = AsyncMock()
        with patch(f"{_REPO}.get_policy_by_id", return_value=None), \
             pytest.raises(PolicyNotFoundError):
            await service.get_policy(
                db,
                policy_id=uuid4(),
                application_id=FAKE_APP_ID,
            )

    @pytest.mark.asyncio
    async def test_wrong_app_returns_not_found(self):
        db = AsyncMock()
        policy = _make_policy()

        with patch(f"{_REPO}.get_policy_by_id", return_value=policy), \
             pytest.raises(PolicyNotFoundError):
            await service.get_policy(
                db,
                policy_id=policy.id,
                application_id=uuid4(),  # Different app
            )


class TestListPolicies:
    @pytest.mark.asyncio
    async def test_lists_policies(self):
        db = AsyncMock()
        policies = [_make_policy("p1"), _make_policy("p2")]

        with patch(f"{_REPO}.list_policies", return_value=policies):
            result = await service.list_policies(
                db,
                application_id=FAKE_APP_ID,
            )

        assert result["count"] == 2
        assert len(result["policies"]) == 2


# ---------------------------------------------------------------------------
# Update / Delete
# ---------------------------------------------------------------------------


class TestUpdatePolicy:
    @pytest.mark.asyncio
    async def test_updates_name(self):
        db = AsyncMock()
        policy = _make_policy()
        updated = _make_policy(name="new_name")

        with patch(f"{_REPO}.get_policy_by_id", return_value=policy), \
             patch(f"{_REPO}.get_policy_by_name", return_value=None), \
             patch(f"{_REPO}.update_policy", return_value=updated):
            result = await service.update_policy(
                db,
                policy_id=policy.id,
                application_id=FAKE_APP_ID,
                name="new_name",
            )

        assert result["policy"]["name"] == "new_name"


class TestDeletePolicy:
    @pytest.mark.asyncio
    async def test_deletes_policy(self):
        db = AsyncMock()
        policy = _make_policy()

        with patch(f"{_REPO}.get_policy_by_id", return_value=policy), \
             patch(f"{_REPO}.delete_policy", return_value=True):
            result = await service.delete_policy(
                db,
                policy_id=policy.id,
                application_id=FAKE_APP_ID,
            )

        assert result["message"] == "Policy deleted"


# ---------------------------------------------------------------------------
# Authorize
# ---------------------------------------------------------------------------


class TestAuthorize:
    @pytest.mark.asyncio
    async def test_authorize_allowed(self):
        db = AsyncMock()
        policy = _make_policy(conditions={"has_role": {"role": "admin"}})

        with patch(f"{_REPO}.get_policy_by_name", return_value=policy), \
             patch(
                 "spaps_server_quickstart.domains.policies.service.evaluate_policy",
                 return_value=(True, ["has role 'admin'"], 2),
             ), \
             patch(f"{_REPO}.create_evaluation_log"):
            result = await service.authorize(
                db,
                application_id=FAKE_APP_ID,
                policy_name="test_policy",
                user_id=FAKE_USER_ID,
            )

        assert result["allowed"] is True
        assert result["decision"] == "allow"
        assert result["policy_name"] == "test_policy"
        assert result["evaluation_ms"] == 2

    @pytest.mark.asyncio
    async def test_authorize_denied(self):
        db = AsyncMock()
        policy = _make_policy(conditions={"has_role": {"role": "admin"}})

        with patch(f"{_REPO}.get_policy_by_name", return_value=policy), \
             patch(
                 "spaps_server_quickstart.domains.policies.service.evaluate_policy",
                 return_value=(False, ["missing role 'admin'"], 1),
             ), \
             patch(f"{_REPO}.create_evaluation_log"):
            result = await service.authorize(
                db,
                application_id=FAKE_APP_ID,
                policy_name="test_policy",
                user_id=FAKE_USER_ID,
            )

        assert result["allowed"] is False
        assert result["decision"] == "deny"

    @pytest.mark.asyncio
    async def test_policy_not_found(self):
        db = AsyncMock()
        with patch(f"{_REPO}.get_policy_by_name", return_value=None), \
             pytest.raises(PolicyNotFoundError):
            await service.authorize(
                db,
                application_id=FAKE_APP_ID,
                policy_name="nonexistent",
            )

    @pytest.mark.asyncio
    async def test_disabled_policy(self):
        db = AsyncMock()
        policy = _make_policy(is_active=False)

        with patch(f"{_REPO}.get_policy_by_name", return_value=policy), \
             pytest.raises(PolicyNotFoundError):
            await service.authorize(
                db,
                application_id=FAKE_APP_ID,
                policy_name="test_policy",
            )


# ---------------------------------------------------------------------------
# Condition validation
# ---------------------------------------------------------------------------


class TestConditionValidation:
    def test_valid_leaf(self):
        service._validate_conditions({"has_role": {"role": "admin"}})

    def test_valid_all(self):
        service._validate_conditions({
            "all": [
                {"has_role": {"role": "admin"}},
                {"has_wallet": {"chain": "solana"}},
            ]
        })

    def test_valid_nested(self):
        service._validate_conditions({
            "any": [
                {"has_entitlement": {"key": "pro"}},
                {"all": [
                    {"subscription_status": {"eq": "active"}},
                    {"not": {"user_tier": {"eq": "free"}}},
                ]},
            ]
        })

    def test_invalid_type_rejected(self):
        with pytest.raises(InvalidConditionError, match="Unknown condition type"):
            service._validate_conditions({"bogus": {"foo": "bar"}})

    def test_all_must_be_list(self):
        with pytest.raises(InvalidConditionError, match="must contain a list"):
            service._validate_conditions({"all": {"has_role": {"role": "admin"}}})

    def test_not_must_be_dict(self):
        with pytest.raises(InvalidConditionError, match="must contain a condition object"):
            service._validate_conditions({"not": [{"has_role": {"role": "admin"}}]})
