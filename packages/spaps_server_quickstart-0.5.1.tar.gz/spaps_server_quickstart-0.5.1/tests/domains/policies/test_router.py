"""Router tests for the policies domain.

These tests focus on request parsing and HTTP error mapping rather than the
policy service behavior itself.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

from fastapi import FastAPI
from fastapi.testclient import TestClient

from spaps_server_quickstart.domains.policies.router import policies_router
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_db_session,
    require_admin_user,
)

_SVC = "spaps_server_quickstart.domains.policies.router.service"


def _make_application():
    app = MagicMock()
    app.id = str(uuid4())
    return app


def _make_admin_user():
    user = MagicMock()
    user.id = str(uuid4())
    user.is_admin = True
    user.roles = ["admin"]
    return user


def _make_test_app() -> FastAPI:
    app = FastAPI()
    install_error_handlers(app)
    app.include_router(policies_router, prefix="/api")

    async def override_db_session():
        yield AsyncMock()

    app.dependency_overrides[get_db_session] = override_db_session
    app.dependency_overrides[get_application] = _make_application
    app.dependency_overrides[require_admin_user] = _make_admin_user
    return app


class TestPoliciesRouterValidation:
    def test_invalid_policy_id_returns_validation_error(self):
        app = _make_test_app()
        client = TestClient(app, raise_server_exceptions=False)

        with patch(f"{_SVC}.get_policy", new_callable=AsyncMock) as mock_get_policy:
            response = client.get("/api/policies/not-a-uuid")

        assert response.status_code == 400
        assert response.json()["error"]["code"] == "VALIDATION_ERROR"
        mock_get_policy.assert_not_called()

    def test_invalid_evaluation_user_id_returns_validation_error(self):
        app = _make_test_app()
        client = TestClient(app, raise_server_exceptions=False)

        with patch(
            f"{_SVC}.get_evaluation_logs",
            new_callable=AsyncMock,
        ) as mock_get_logs:
            response = client.get("/api/policies/evaluations?user_id=not-a-uuid")

        assert response.status_code == 400
        assert response.json()["error"]["code"] == "VALIDATION_ERROR"
        mock_get_logs.assert_not_called()
