"""Unit tests for the policy condition evaluator.

Tests the core evaluation engine in isolation with mocked user context.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.policies.evaluator import (
    UserContext,
    evaluate_condition,
    evaluate_policy,
)

FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()


def _make_context(
    *,
    user_id=None,
    email=None,
    extra=None,
    wallets=None,
    entitlements=None,
    subscriptions=None,
    roles=None,
    profile=None,
) -> UserContext:
    """Build a UserContext with pre-populated caches (no DB needed)."""
    ctx = UserContext(
        AsyncMock(),
        user_id=user_id or FAKE_USER_ID,
        application_id=FAKE_APP_ID,
        email=email,
        extra=extra or {},
    )
    ctx._wallets = wallets if wallets is not None else []
    ctx._entitlements = entitlements if entitlements is not None else {"entitlements": [], "count": 0}
    ctx._subscriptions = subscriptions if subscriptions is not None else []
    ctx._roles = roles if roles is not None else ["user"]
    ctx._user_profile = profile if profile is not None else {
        "id": str(FAKE_USER_ID),
        "email": "test@example.com",
        "tier": "basic",
        "created_at": datetime.now(UTC) - timedelta(days=60),
    }
    return ctx


# ---------------------------------------------------------------------------
# Leaf condition tests
# ---------------------------------------------------------------------------


class TestHasEntitlement:
    @pytest.mark.asyncio
    async def test_has_matching_entitlement(self):
        ctx = _make_context(entitlements={
            "entitlements": [
                {"entitlement_key": "premium_access", "revoked_at": None},
            ],
            "count": 1,
        })
        result = await evaluate_condition(ctx, {"has_entitlement": {"key": "premium_access"}})
        assert result.matched is True

    @pytest.mark.asyncio
    async def test_missing_entitlement(self):
        ctx = _make_context()
        result = await evaluate_condition(ctx, {"has_entitlement": {"key": "premium_access"}})
        assert result.matched is False

    @pytest.mark.asyncio
    async def test_revoked_entitlement_not_matched(self):
        ctx = _make_context(entitlements={
            "entitlements": [
                {"entitlement_key": "premium_access", "revoked_at": "2026-01-01T00:00:00Z"},
            ],
            "count": 1,
        })
        result = await evaluate_condition(ctx, {"has_entitlement": {"key": "premium_access"}})
        assert result.matched is False


class TestSubscriptionStatus:
    @pytest.mark.asyncio
    async def test_active_subscription(self):
        ctx = _make_context(subscriptions=[{"status": "active", "id": "sub_123"}])
        result = await evaluate_condition(ctx, {"subscription_status": {"eq": "active"}})
        assert result.matched is True

    @pytest.mark.asyncio
    async def test_no_subscription(self):
        ctx = _make_context()
        result = await evaluate_condition(ctx, {"subscription_status": {"eq": "active"}})
        assert result.matched is False


class TestAccountAgeDays:
    @pytest.mark.asyncio
    async def test_old_enough(self):
        ctx = _make_context(profile={
            "created_at": datetime.now(UTC) - timedelta(days=60),
        })
        result = await evaluate_condition(ctx, {"account_age_days": {"gte": 30}})
        assert result.matched is True

    @pytest.mark.asyncio
    async def test_too_new(self):
        ctx = _make_context(profile={
            "created_at": datetime.now(UTC) - timedelta(days=5),
        })
        result = await evaluate_condition(ctx, {"account_age_days": {"gte": 30}})
        assert result.matched is False


class TestHasWallet:
    @pytest.mark.asyncio
    async def test_has_solana_wallet(self):
        ctx = _make_context(wallets=[
            {"chain_type": "solana", "wallet_address": "abc123"},
        ])
        result = await evaluate_condition(ctx, {"has_wallet": {"chain": "solana"}})
        assert result.matched is True

    @pytest.mark.asyncio
    async def test_wrong_chain(self):
        ctx = _make_context(wallets=[
            {"chain_type": "ethereum", "wallet_address": "0xabc"},
        ])
        result = await evaluate_condition(ctx, {"has_wallet": {"chain": "solana"}})
        assert result.matched is False

    @pytest.mark.asyncio
    async def test_any_wallet(self):
        ctx = _make_context(wallets=[
            {"chain_type": "ethereum", "wallet_address": "0xabc"},
        ])
        result = await evaluate_condition(ctx, {"has_wallet": {}})
        assert result.matched is True

    @pytest.mark.asyncio
    async def test_no_wallets(self):
        ctx = _make_context()
        result = await evaluate_condition(ctx, {"has_wallet": {}})
        assert result.matched is False


class TestHasRole:
    @pytest.mark.asyncio
    async def test_has_admin_role(self):
        ctx = _make_context(roles=["admin", "super_admin"])
        result = await evaluate_condition(ctx, {"has_role": {"role": "admin"}})
        assert result.matched is True

    @pytest.mark.asyncio
    async def test_missing_role(self):
        ctx = _make_context(roles=["user"])
        result = await evaluate_condition(ctx, {"has_role": {"role": "admin"}})
        assert result.matched is False


class TestUserTier:
    @pytest.mark.asyncio
    async def test_matching_tier(self):
        ctx = _make_context(profile={"tier": "pro", "created_at": datetime.now(UTC)})
        result = await evaluate_condition(ctx, {"user_tier": {"eq": "pro"}})
        assert result.matched is True

    @pytest.mark.asyncio
    async def test_different_tier(self):
        ctx = _make_context(profile={"tier": "basic", "created_at": datetime.now(UTC)})
        result = await evaluate_condition(ctx, {"user_tier": {"eq": "pro"}})
        assert result.matched is False


class TestContextValue:
    @pytest.mark.asyncio
    async def test_eq(self):
        ctx = _make_context(extra={"ip_country": "US"})
        result = await evaluate_condition(ctx, {"context_value": {"key": "ip_country", "eq": "US"}})
        assert result.matched is True

    @pytest.mark.asyncio
    async def test_neq(self):
        ctx = _make_context(extra={"ip_country": "CA"})
        result = await evaluate_condition(ctx, {"context_value": {"key": "ip_country", "neq": "US"}})
        assert result.matched is True

    @pytest.mark.asyncio
    async def test_in(self):
        ctx = _make_context(extra={"ip_country": "US"})
        result = await evaluate_condition(ctx, {"context_value": {"key": "ip_country", "in": ["US", "CA"]}})
        assert result.matched is True

    @pytest.mark.asyncio
    async def test_missing_key(self):
        ctx = _make_context()
        result = await evaluate_condition(ctx, {"context_value": {"key": "ip_country", "eq": "US"}})
        assert result.matched is False


# ---------------------------------------------------------------------------
# Combinator tests
# ---------------------------------------------------------------------------


class TestAllCombinator:
    @pytest.mark.asyncio
    async def test_all_match(self):
        ctx = _make_context(
            roles=["admin"],
            wallets=[{"chain_type": "solana", "wallet_address": "abc"}],
        )
        condition = {
            "all": [
                {"has_role": {"role": "admin"}},
                {"has_wallet": {"chain": "solana"}},
            ]
        }
        result = await evaluate_condition(ctx, condition)
        assert result.matched is True

    @pytest.mark.asyncio
    async def test_one_fails(self):
        ctx = _make_context(roles=["user"])
        condition = {
            "all": [
                {"has_role": {"role": "admin"}},
                {"has_wallet": {}},
            ]
        }
        result = await evaluate_condition(ctx, condition)
        assert result.matched is False


class TestAnyCombinator:
    @pytest.mark.asyncio
    async def test_one_matches(self):
        ctx = _make_context(
            entitlements={
                "entitlements": [{"entitlement_key": "pro_access", "revoked_at": None}],
                "count": 1,
            },
        )
        condition = {
            "any": [
                {"has_role": {"role": "admin"}},
                {"has_entitlement": {"key": "pro_access"}},
            ]
        }
        result = await evaluate_condition(ctx, condition)
        assert result.matched is True

    @pytest.mark.asyncio
    async def test_none_match(self):
        ctx = _make_context()
        condition = {
            "any": [
                {"has_role": {"role": "admin"}},
                {"has_entitlement": {"key": "pro_access"}},
            ]
        }
        result = await evaluate_condition(ctx, condition)
        assert result.matched is False


class TestNotCombinator:
    @pytest.mark.asyncio
    async def test_negation(self):
        ctx = _make_context(roles=["user"])
        condition = {"not": {"has_role": {"role": "admin"}}}
        result = await evaluate_condition(ctx, condition)
        assert result.matched is True

    @pytest.mark.asyncio
    async def test_double_negation(self):
        ctx = _make_context(roles=["admin"])
        condition = {"not": {"has_role": {"role": "admin"}}}
        result = await evaluate_condition(ctx, condition)
        assert result.matched is False


class TestNestedConditions:
    @pytest.mark.asyncio
    async def test_complex_tree(self):
        """Test a realistic nested condition tree:

        any(
            has_entitlement("premium"),
            all(
                subscription_status == "active",
                account_age_days >= 30
            )
        )
        """
        ctx = _make_context(
            subscriptions=[{"status": "active"}],
            profile={"created_at": datetime.now(UTC) - timedelta(days=60)},
        )
        condition = {
            "any": [
                {"has_entitlement": {"key": "premium"}},
                {
                    "all": [
                        {"subscription_status": {"eq": "active"}},
                        {"account_age_days": {"gte": 30}},
                    ]
                },
            ]
        }
        result = await evaluate_condition(ctx, condition)
        assert result.matched is True


# ---------------------------------------------------------------------------
# Policy-level evaluation
# ---------------------------------------------------------------------------


class TestEvaluatePolicy:
    @pytest.mark.asyncio
    async def test_allow_policy_matched(self):
        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.policies.evaluator.UserContext.get_roles",
            return_value=["admin"],
        ):
            allowed, reasons, elapsed_ms = await evaluate_policy(
                db,
                conditions={"has_role": {"role": "admin"}},
                effect="allow",
                user_id=FAKE_USER_ID,
                application_id=FAKE_APP_ID,
            )
        assert allowed is True
        assert elapsed_ms >= 0

    @pytest.mark.asyncio
    async def test_deny_policy_blocks(self):
        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.policies.evaluator.UserContext.get_roles",
            return_value=["user"],
        ), patch(
            "spaps_server_quickstart.domains.policies.evaluator.UserContext.get_user_profile",
            return_value={"tier": "free", "created_at": datetime.now(UTC)},
        ):
            allowed, reasons, elapsed_ms = await evaluate_policy(
                db,
                conditions={"user_tier": {"eq": "free"}},
                effect="deny",
                user_id=FAKE_USER_ID,
                application_id=FAKE_APP_ID,
            )
        assert allowed is False

    @pytest.mark.asyncio
    async def test_unknown_condition_type(self):
        ctx = _make_context()
        result = await evaluate_condition(ctx, {"bogus_check": {"foo": "bar"}})
        assert result.matched is False
        assert "unknown condition type" in result.reasons[0]

    @pytest.mark.asyncio
    async def test_empty_condition(self):
        ctx = _make_context()
        result = await evaluate_condition(ctx, {})
        assert result.matched is False
