"""Unit tests for the CFO domain service (business logic layer).

Tests exercise service functions with mocked repositories and
QuickBooks API client. No database or network calls.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from spaps_server_quickstart.domains.cfo import service
from spaps_server_quickstart.domains.cfo.errors import (
    CfoConnectionAlreadyRevokedError,
    CfoConnectionNotFoundError,
    CfoInvalidCodeError,
)
from spaps_server_quickstart.domains.errors import ValidationError
from spaps_server_quickstart.domains.cfo.models import (
    CfoAuthCode,
    CfoConnection,
    CfoMagicLink,
)

_REPO = "spaps_server_quickstart.domains.cfo.repository"
_QB = "spaps_server_quickstart.domains.cfo.quickbooks"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_connection(
    *,
    id: UUID | None = None,
    user_id: UUID | None = None,
    company_id: UUID | None = None,
    status: str = "connected",
    company_name: str = "Acme Corp",
    realm_id: str = "123456789",
) -> MagicMock:
    """Create a mock CfoConnection."""
    conn = MagicMock(spec=CfoConnection)
    conn.id = id or uuid4()
    conn.user_id = user_id
    conn.company_id = company_id
    conn.client_name = "Test Client"
    conn.realm_id = realm_id
    conn.company_name = company_name
    conn.encrypted_refresh_token = "encrypted"
    conn.token_expires_at = datetime.now(UTC) + timedelta(hours=1)
    conn.accounting_method = None
    conn.risk_tier = None
    conn.status = status
    conn.connected_at = datetime.now(UTC)
    conn.created_at = datetime.now(UTC)
    return conn


def _make_magic_link(
    *,
    token: str = "test-token-abc",
    client_name: str = "Test Client",
    connection_id: UUID | None = None,
    used_at: datetime | None = None,
    expired: bool = False,
) -> MagicMock:
    """Create a mock CfoMagicLink."""
    link = MagicMock(spec=CfoMagicLink)
    link.id = uuid4()
    link.token = token
    link.client_name = client_name
    link.connection_id = connection_id or uuid4()
    link.used_at = used_at
    if expired:
        link.expires_at = datetime.now(UTC) - timedelta(hours=1)
    else:
        link.expires_at = datetime.now(UTC) + timedelta(hours=24)
    link.created_at = datetime.now(UTC)
    return link


def _make_auth_code(
    *,
    code: str = "a" * 64,
    user_id: UUID | None = None,
    used_at: datetime | None = None,
    expired: bool = False,
) -> MagicMock:
    """Create a mock CfoAuthCode."""
    ac = MagicMock(spec=CfoAuthCode)
    ac.id = uuid4()
    ac.code = code
    ac.user_id = user_id
    ac.company_name = "Acme Corp"
    ac.realm_id = "123456789"
    ac.encrypted_auth_data = "encrypted-data"
    ac.used_at = used_at
    if expired:
        ac.expires_at = datetime.now(UTC) - timedelta(minutes=1)
    else:
        ac.expires_at = datetime.now(UTC) + timedelta(minutes=5)
    ac.created_at = datetime.now(UTC)
    return ac


# ===========================================================================
# generate_magic_link
# ===========================================================================


class TestGenerateMagicLink:
    @patch(f"{_REPO}.create_magic_link", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_connection", new_callable=AsyncMock)
    async def test_creates_connection_and_link(
        self, mock_create_conn, mock_create_link
    ):
        """generate_magic_link creates a connection and magic link."""
        conn = _make_connection(status="pending")
        mock_create_conn.return_value = conn

        link = _make_magic_link(connection_id=conn.id)
        mock_create_link.return_value = link

        db = AsyncMock()
        result = await service.generate_magic_link(
            db,
            client_name="Acme",
            frontend_url="https://app.example.com",
        )

        assert "url" in result
        assert "token" in result
        assert result["connectionId"] == str(conn.id)
        mock_create_conn.assert_called_once()
        mock_create_link.assert_called_once()


# ===========================================================================
# get_runtime_connection_token
# ===========================================================================


class TestGetRuntimeConnectionToken:
    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    @patch(f"{service.__name__}.encrypt_refresh_token")
    async def test_returns_encrypted_token_by_connection_id(self, mock_encrypt, mock_get_conn):
        """Should return encrypted refresh token for a connected connection."""
        conn = _make_connection()
        conn.encrypted_refresh_token = "encrypted-refresh-token"
        mock_get_conn.return_value = conn
        mock_encrypt.return_value = "encrypted-client-secret"

        db = AsyncMock()
        result = await service.get_runtime_connection_token(
            db,
            connection_id=conn.id,
            client_id="test-client-id",
            client_secret="test-client-secret",
            cfo_public_key="test-public-key",
        )

        assert result["connection_id"] == str(conn.id)
        assert result["realm_id"] == conn.realm_id
        assert result["company_name"] == conn.company_name
        assert result["encrypted_refresh_token"] == "encrypted-refresh-token"
        assert result["client_id"] == "test-client-id"
        assert result["environment"] == "production"
        assert result["encrypted_client_secret"] == "encrypted-client-secret"
        mock_encrypt.assert_called_once_with("test-client-secret", "test-public-key")

    @patch(f"{_REPO}.find_connection_by_realm_id", new_callable=AsyncMock)
    @patch(f"{service.__name__}.encrypt_refresh_token")
    async def test_returns_encrypted_token_by_realm_id(self, mock_encrypt, mock_find_conn):
        """Should support realm_id lookup for runtime token export."""
        conn = _make_connection(realm_id="9341452909252408")
        conn.encrypted_refresh_token = "encrypted-refresh-token"
        mock_find_conn.return_value = conn
        mock_encrypt.return_value = "encrypted-client-secret"

        db = AsyncMock()
        result = await service.get_runtime_connection_token(
            db,
            realm_id="9341452909252408",
            client_id="test-client-id",
            client_secret="test-client-secret",
            cfo_public_key="test-public-key",
        )

        assert result["connection_id"] == str(conn.id)
        assert result["realm_id"] == "9341452909252408"
        assert result["encrypted_refresh_token"] == "encrypted-refresh-token"
        assert result["encrypted_client_secret"] == "encrypted-client-secret"

    async def test_requires_lookup_parameter(self):
        """Should reject requests without connection_id or realm_id."""
        db = AsyncMock()

        with pytest.raises(ValidationError, match="connection_id or realm_id"):
            await service.get_runtime_connection_token(
                db,
                client_id="test-client-id",
                client_secret="test-client-secret",
                cfo_public_key="test-public-key",
            )

    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    async def test_raises_not_found_when_connection_missing(self, mock_get_conn):
        """Missing connections should raise not-found."""
        mock_get_conn.return_value = None
        db = AsyncMock()

        with pytest.raises(CfoConnectionNotFoundError):
            await service.get_runtime_connection_token(
                db,
                connection_id=uuid4(),
                client_id="test-client-id",
                client_secret="test-client-secret",
                cfo_public_key="test-public-key",
            )

    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    async def test_raises_when_refresh_token_missing(self, mock_get_conn):
        """Disconnected or scrubbed rows should not export a runtime token."""
        conn = _make_connection()
        conn.encrypted_refresh_token = None
        mock_get_conn.return_value = conn
        db = AsyncMock()

        with pytest.raises(CfoConnectionNotFoundError, match="No stored refresh token"):
            await service.get_runtime_connection_token(
                db,
                connection_id=conn.id,
                client_id="test-client-id",
                client_secret="test-client-secret",
                cfo_public_key="test-public-key",
            )

    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    async def test_raises_when_connection_is_disconnected(self, mock_get_conn):
        """Disconnected rows should never export runtime credentials."""
        conn = _make_connection(status="disconnected")
        conn.encrypted_refresh_token = "stale-encrypted-token"
        mock_get_conn.return_value = conn
        db = AsyncMock()

        with pytest.raises(
            CfoConnectionNotFoundError,
            match="Connection is not active for runtime token export",
        ):
            await service.get_runtime_connection_token(
                db,
                connection_id=conn.id,
                client_id="test-client-id",
                client_secret="test-client-secret",
                cfo_public_key="test-public-key",
            )

    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    async def test_raises_when_cfo_public_key_missing(self, mock_get_conn):
        """Runtime token export should fail closed without the CFO public key."""
        conn = _make_connection()
        mock_get_conn.return_value = conn
        db = AsyncMock()

        with pytest.raises(ValidationError, match="CFO public key is required"):
            await service.get_runtime_connection_token(
                db,
                connection_id=conn.id,
                client_id="test-client-id",
                client_secret="test-client-secret",
                cfo_public_key="",
            )


# ===========================================================================
# validate_magic_link_token
# ===========================================================================


class TestValidateMagicLinkToken:
    @patch(f"{_REPO}.get_magic_link_by_token", new_callable=AsyncMock)
    async def test_valid_token(self, mock_get_link):
        """validate returns valid=True for unexpired, unused token."""
        link = _make_magic_link()
        mock_get_link.return_value = link

        db = AsyncMock()
        result = await service.validate_magic_link_token(
            db,
            token="test-token-abc",
            client_id="client-id",
            redirect_uri="https://app.example.com/api/cfo/callback",
        )

        assert result["valid"] is True
        assert result["clientName"] == "Test Client"
        assert "authUrl" in result

    @patch(f"{_REPO}.get_magic_link_by_token", new_callable=AsyncMock)
    async def test_unknown_token(self, mock_get_link):
        """validate returns valid=False for unknown token."""
        mock_get_link.return_value = None

        db = AsyncMock()
        result = await service.validate_magic_link_token(
            db,
            token="unknown",
            client_id="client-id",
            redirect_uri="https://example.com/callback",
        )

        assert result["valid"] is False

    @patch(f"{_REPO}.get_magic_link_by_token", new_callable=AsyncMock)
    async def test_expired_token(self, mock_get_link):
        """validate returns valid=False for expired token."""
        link = _make_magic_link(expired=True)
        mock_get_link.return_value = link

        db = AsyncMock()
        result = await service.validate_magic_link_token(
            db,
            token="test-token",
            client_id="client-id",
            redirect_uri="https://example.com/callback",
        )

        assert result["valid"] is False

    @patch(f"{_REPO}.get_magic_link_by_token", new_callable=AsyncMock)
    async def test_used_token(self, mock_get_link):
        """validate returns valid=False for already-used token."""
        link = _make_magic_link(used_at=datetime.now(UTC))
        mock_get_link.return_value = link

        db = AsyncMock()
        result = await service.validate_magic_link_token(
            db,
            token="test-token",
            client_id="client-id",
            redirect_uri="https://example.com/callback",
        )

        assert result["valid"] is False


# ===========================================================================
# process_oauth_callback — state validation
# ===========================================================================


class TestProcessOAuthCallbackStateValidation:
    @patch(f"{_QB}.fetch_user_info", new_callable=AsyncMock)
    @patch(f"{_QB}.fetch_company_info", new_callable=AsyncMock)
    @patch(f"{_QB}.exchange_code_for_tokens", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_magic_link_by_token", new_callable=AsyncMock)
    async def test_rejects_non_uuid_state(
        self,
        mock_get_link,
        mock_get_conn,
        mock_exchange,
        mock_company,
        mock_user,
    ):
        """OAuth callback with non-UUID state returns error redirect."""
        mock_get_link.return_value = None  # Not a magic link token
        mock_exchange.return_value = {
            "access_token": "at",
            "refresh_token": "rt",
            "expires_in": 3600,
        }
        mock_company.return_value = {"CompanyName": "Acme"}
        mock_user.return_value = {"email": "user@example.com"}

        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.cfo.service.encrypt_refresh_token",
            return_value="encrypted-token",
        ):
            result = await service.process_oauth_callback(
                db,
                code="auth-code",
                state="not-a-uuid",
                realm_id="123456789",
                client_id="cid",
                client_secret="csec",
                redirect_uri="https://example.com/callback",
                cfo_public_key="configured-key",
                frontend_url="https://app.example.com",
            )

        assert result["error"] is True
        assert "Invalid+OAuth+state" in result["redirect"]
        # Should NOT have created a connection (direct flow blocked)
        mock_get_conn.assert_not_called()


# ===========================================================================
# process_oauth_callback — company_id passthrough
# ===========================================================================


class TestProcessOAuthCallbackCompanyId:
    """Test that company_id is included in redirect URL when present."""

    @patch(f"{_REPO}.update_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_magic_link_by_token", new_callable=AsyncMock)
    @patch(f"{_QB}.fetch_user_info", new_callable=AsyncMock)
    @patch(f"{_QB}.fetch_company_info", new_callable=AsyncMock)
    @patch(f"{_QB}.exchange_code_for_tokens", new_callable=AsyncMock)
    async def test_user_flow_with_company_id(
        self,
        mock_exchange,
        mock_company,
        mock_user,
        mock_get_link,
        mock_get_conn,
        mock_update,
    ):
        """User-initiated flow with company_id includes it in redirect URL."""
        company_id = uuid4()
        conn = _make_connection(status="pending", company_id=company_id)
        mock_exchange.return_value = {
            "access_token": "at",
            "refresh_token": "rt",
            "expires_in": 3600,
        }
        mock_company.return_value = {"CompanyName": "Acme"}
        mock_user.return_value = {"email": "user@example.com"}
        mock_get_link.return_value = None  # Not a magic link
        mock_get_conn.return_value = conn
        mock_update.return_value = conn

        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.cfo.service.encrypt_refresh_token",
            return_value="encrypted-token",
        ):
            result = await service.process_oauth_callback(
                db,
                code="auth-code",
                state=str(conn.id),
                realm_id="123456789",
                client_id="cid",
                client_secret="csec",
                redirect_uri="https://example.com/callback",
                cfo_public_key="configured-key",
                frontend_url="https://app.example.com",
            )

        assert result["error"] is False
        assert f"company_id={company_id}" in result["redirect"]
        assert f"connection_id={conn.id}" in result["redirect"]
        assert "company=Acme" in result["redirect"]

    @patch(f"{_REPO}.update_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_magic_link_by_token", new_callable=AsyncMock)
    @patch(f"{_QB}.fetch_user_info", new_callable=AsyncMock)
    @patch(f"{_QB}.fetch_company_info", new_callable=AsyncMock)
    @patch(f"{_QB}.exchange_code_for_tokens", new_callable=AsyncMock)
    async def test_user_flow_without_company_id(
        self,
        mock_exchange,
        mock_company,
        mock_user,
        mock_get_link,
        mock_get_conn,
        mock_update,
    ):
        """User-initiated flow without company_id omits it from redirect URL."""
        conn = _make_connection(status="pending", company_id=None)
        mock_exchange.return_value = {
            "access_token": "at",
            "refresh_token": "rt",
            "expires_in": 3600,
        }
        mock_company.return_value = {"CompanyName": "Acme"}
        mock_user.return_value = {"email": "user@example.com"}
        mock_get_link.return_value = None  # Not a magic link
        mock_get_conn.return_value = conn
        mock_update.return_value = conn

        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.cfo.service.encrypt_refresh_token",
            return_value="encrypted-token",
        ):
            result = await service.process_oauth_callback(
                db,
                code="auth-code",
                state=str(conn.id),
                realm_id="123456789",
                client_id="cid",
                client_secret="csec",
                redirect_uri="https://example.com/callback",
                cfo_public_key="configured-key",
                frontend_url="https://app.example.com",
            )

        assert result["error"] is False
        assert "company_id" not in result["redirect"]
        assert f"connection_id={conn.id}" in result["redirect"]
        assert "company=Acme" in result["redirect"]

    @patch(f"{_REPO}.mark_magic_link_used", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_magic_link_by_token", new_callable=AsyncMock)
    @patch(f"{_QB}.fetch_user_info", new_callable=AsyncMock)
    @patch(f"{_QB}.fetch_company_info", new_callable=AsyncMock)
    @patch(f"{_QB}.exchange_code_for_tokens", new_callable=AsyncMock)
    async def test_magic_link_flow_with_company_id(
        self,
        mock_exchange,
        mock_company,
        mock_user,
        mock_get_link,
        mock_get_conn,
        mock_update,
        mock_mark_used,
    ):
        """Magic link flow with company_id includes it in redirect URL."""
        company_id = uuid4()
        conn = _make_connection(status="pending", company_id=company_id)
        link = _make_magic_link(connection_id=conn.id)

        mock_exchange.return_value = {
            "access_token": "at",
            "refresh_token": "rt",
            "expires_in": 3600,
        }
        mock_company.return_value = {"CompanyName": "Acme"}
        mock_user.return_value = {"email": "user@example.com"}
        mock_get_link.return_value = link
        mock_get_conn.return_value = conn
        mock_update.return_value = conn
        mock_mark_used.return_value = None

        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.cfo.service.encrypt_refresh_token",
            return_value="encrypted-token",
        ):
            result = await service.process_oauth_callback(
                db,
                code="auth-code",
                state=link.token,
                realm_id="123456789",
                client_id="cid",
                client_secret="csec",
                redirect_uri="https://example.com/callback",
                cfo_public_key="configured-key",
                frontend_url="https://app.example.com",
            )

        assert result["error"] is False
        assert f"company_id={company_id}" in result["redirect"]
        assert f"connection_id={conn.id}" in result["redirect"]
        assert "company=Acme" in result["redirect"]

    @patch(f"{_REPO}.mark_magic_link_used", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_magic_link_by_token", new_callable=AsyncMock)
    @patch(f"{_QB}.fetch_user_info", new_callable=AsyncMock)
    @patch(f"{_QB}.fetch_company_info", new_callable=AsyncMock)
    @patch(f"{_QB}.exchange_code_for_tokens", new_callable=AsyncMock)
    async def test_magic_link_flow_without_company_id(
        self,
        mock_exchange,
        mock_company,
        mock_user,
        mock_get_link,
        mock_get_conn,
        mock_update,
        mock_mark_used,
    ):
        """Magic link flow without company_id omits it from redirect URL."""
        conn = _make_connection(status="pending", company_id=None)
        link = _make_magic_link(connection_id=conn.id)

        mock_exchange.return_value = {
            "access_token": "at",
            "refresh_token": "rt",
            "expires_in": 3600,
        }
        mock_company.return_value = {"CompanyName": "Acme"}
        mock_user.return_value = {"email": "user@example.com"}
        mock_get_link.return_value = link
        mock_get_conn.return_value = conn
        mock_update.return_value = conn
        mock_mark_used.return_value = None

        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.cfo.service.encrypt_refresh_token",
            return_value="encrypted-token",
        ):
            result = await service.process_oauth_callback(
                db,
                code="auth-code",
                state=link.token,
                realm_id="123456789",
                client_id="cid",
                client_secret="csec",
                redirect_uri="https://example.com/callback",
                cfo_public_key="configured-key",
                frontend_url="https://app.example.com",
            )

        assert result["error"] is False
        assert "company_id" not in result["redirect"]
        assert f"connection_id={conn.id}" in result["redirect"]
        assert "company=Acme" in result["redirect"]


# ===========================================================================
# exchange_auth_code
# ===========================================================================


class TestExchangeAuthCode:
    @patch(f"{_REPO}.mark_auth_code_used", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_auth_code_by_code", new_callable=AsyncMock)
    async def test_valid_code(self, mock_get_code, mock_mark_used):
        """exchange_auth_code returns data for valid code."""
        code = _make_auth_code()
        mock_get_code.return_value = code
        mock_mark_used.return_value = None

        db = AsyncMock()
        result = await service.exchange_auth_code(db, code="a" * 64)

        assert result["company_name"] == "Acme Corp"
        assert result["realm_id"] == "123456789"
        mock_mark_used.assert_called_once_with(db, code.id)

    @patch(f"{_REPO}.get_auth_code_by_code", new_callable=AsyncMock)
    async def test_unknown_code_raises(self, mock_get_code):
        """exchange_auth_code raises INVALID_CODE for unknown code."""
        mock_get_code.return_value = None

        db = AsyncMock()
        with pytest.raises(CfoInvalidCodeError):
            await service.exchange_auth_code(db, code="a" * 64)

    @patch(f"{_REPO}.get_auth_code_by_code", new_callable=AsyncMock)
    async def test_used_code_raises(self, mock_get_code):
        """exchange_auth_code raises INVALID_CODE for already-used code."""
        code = _make_auth_code(used_at=datetime.now(UTC))
        mock_get_code.return_value = code

        db = AsyncMock()
        with pytest.raises(CfoInvalidCodeError, match="already been used"):
            await service.exchange_auth_code(db, code="a" * 64)

    @patch(f"{_REPO}.get_auth_code_by_code", new_callable=AsyncMock)
    async def test_expired_code_raises(self, mock_get_code):
        """exchange_auth_code raises INVALID_CODE for expired code."""
        code = _make_auth_code(expired=True)
        mock_get_code.return_value = code

        db = AsyncMock()
        with pytest.raises(CfoInvalidCodeError, match="expired"):
            await service.exchange_auth_code(db, code="a" * 64)


# ===========================================================================
# get_connection_status
# ===========================================================================


class TestGetConnectionStatus:
    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    async def test_found(self, mock_get):
        """get_connection_status returns connection details."""
        conn = _make_connection()
        mock_get.return_value = conn

        db = AsyncMock()
        result = await service.get_connection_status(
            db, connection_id=conn.id
        )

        assert result["id"] == str(conn.id)
        assert result["status"] == "connected"

    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    async def test_not_found(self, mock_get):
        """get_connection_status raises NOT_FOUND for unknown connection."""
        mock_get.return_value = None

        db = AsyncMock()
        with pytest.raises(CfoConnectionNotFoundError):
            await service.get_connection_status(
                db, connection_id=uuid4()
            )


# ===========================================================================
# revoke_connection
# ===========================================================================


class TestRevokeConnection:
    @patch(f"{_REPO}.update_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    async def test_success(self, mock_get, mock_update):
        """revoke_connection returns revoked=True."""
        conn = _make_connection(status="connected")
        mock_get.return_value = conn
        mock_update.return_value = conn

        db = AsyncMock()
        result = await service.revoke_connection(
            db, connection_id=conn.id
        )

        assert result["revoked"] is True
        mock_update.assert_called_once_with(
            db,
            conn.id,
            status="revoked",
            encrypted_refresh_token=None,
            token_expires_at=None,
        )

    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    async def test_not_found(self, mock_get):
        """revoke_connection raises NOT_FOUND for unknown connection."""
        mock_get.return_value = None

        db = AsyncMock()
        with pytest.raises(CfoConnectionNotFoundError):
            await service.revoke_connection(db, connection_id=uuid4())

    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    async def test_already_revoked(self, mock_get):
        """revoke_connection raises ALREADY_REVOKED for revoked connection."""
        conn = _make_connection(status="revoked")
        mock_get.return_value = conn

        db = AsyncMock()
        with pytest.raises(CfoConnectionAlreadyRevokedError):
            await service.revoke_connection(db, connection_id=conn.id)


# ===========================================================================
# list_connections
# ===========================================================================


class TestListConnections:
    @patch(f"{_REPO}.list_connections", new_callable=AsyncMock)
    async def test_all(self, mock_list):
        """list_connections returns all connections."""
        mock_list.return_value = [_make_connection(), _make_connection()]

        db = AsyncMock()
        result = await service.list_connections(db)

        assert len(result["connections"]) == 2

    @patch(f"{_REPO}.list_connections", new_callable=AsyncMock)
    async def test_by_user_id(self, mock_list):
        """list_connections filters by user_id."""
        user_id = uuid4()
        mock_list.return_value = [_make_connection(user_id=user_id)]

        db = AsyncMock()
        result = await service.list_connections(db, user_id=user_id)

        assert len(result["connections"]) == 1
        mock_list.assert_called_once_with(db, user_id=user_id)


# ===========================================================================
# user_connect
# ===========================================================================


class TestUserConnect:
    @patch(f"{_REPO}.create_connection", new_callable=AsyncMock)
    async def test_creates_pending_connection(self, mock_create):
        """user_connect creates a pending connection and returns auth URL."""
        conn = _make_connection(status="pending")
        mock_create.return_value = conn

        db = AsyncMock()
        result = await service.user_connect(
            db,
            user_id=uuid4(),
            client_id="test-client",
            redirect_uri="https://example.com/callback",
        )

        assert "authUrl" in result
        assert result["connectionId"] == str(conn.id)
        mock_create.assert_called_once()


# ===========================================================================
# user_status
# ===========================================================================


class TestUserStatus:
    @patch(f"{_REPO}.count_user_connections", new_callable=AsyncMock)
    @patch(f"{_REPO}.find_user_primary_connection", new_callable=AsyncMock)
    async def test_with_connection(self, mock_find, mock_count):
        """user_status returns connection details."""
        conn = _make_connection()
        mock_find.return_value = conn
        mock_count.return_value = 1

        db = AsyncMock()
        user_id = uuid4()
        result = await service.user_status(db, user_id=user_id)

        assert result["connection"] is not None
        assert result["totalConnections"] == 1

    @patch(f"{_REPO}.count_user_connections", new_callable=AsyncMock)
    @patch(f"{_REPO}.find_user_primary_connection", new_callable=AsyncMock)
    async def test_no_connection(self, mock_find, mock_count):
        """user_status returns None when no connection exists."""
        mock_find.return_value = None
        mock_count.return_value = 0

        db = AsyncMock()
        result = await service.user_status(db, user_id=uuid4())

        assert result["connection"] is None
        assert result["totalConnections"] == 0


# ===========================================================================
# user_disconnect
# ===========================================================================


class TestUserDisconnect:
    @patch(f"{_REPO}.update_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.find_user_primary_connection", new_callable=AsyncMock)
    async def test_success(self, mock_find, mock_update):
        """user_disconnect scrubs runtime credentials and sets disconnected."""
        conn = _make_connection()
        mock_find.return_value = conn
        mock_update.return_value = conn

        db = AsyncMock()
        result = await service.user_disconnect(db, user_id=uuid4())

        assert result["success"] is True
        assert result["message"] == "QuickBooks disconnected"
        mock_update.assert_called_once_with(
            db,
            conn.id,
            status="disconnected",
            encrypted_refresh_token=None,
            token_expires_at=None,
        )

    @patch(f"{_REPO}.find_user_primary_connection", new_callable=AsyncMock)
    async def test_no_connection_raises(self, mock_find):
        """user_disconnect raises NOT_FOUND when no connection."""
        mock_find.return_value = None

        db = AsyncMock()
        with pytest.raises(CfoConnectionNotFoundError):
            await service.user_disconnect(db, user_id=uuid4())


# ===========================================================================
# user_connections
# ===========================================================================


class TestUserConnections:
    @patch(f"{_REPO}.list_connections", new_callable=AsyncMock)
    async def test_user_connections(self, mock_list):
        """user_connections returns user's connections."""
        user_id = uuid4()
        mock_list.return_value = [_make_connection(user_id=user_id)]

        db = AsyncMock()
        result = await service.user_connections(
            db, user_id=user_id, include_all=False, is_admin=False
        )

        assert len(result["connections"]) == 1

    @patch(f"{_REPO}.list_all_connections", new_callable=AsyncMock)
    async def test_admin_all_connections(self, mock_list_all):
        """user_connections with include_all + admin returns all."""
        mock_list_all.return_value = [
            _make_connection(user_id=uuid4()),
            _make_connection(user_id=uuid4()),
        ]

        db = AsyncMock()
        result = await service.user_connections(
            db, user_id=uuid4(), include_all=True, is_admin=True
        )

        assert len(result["connections"]) == 2
        mock_list_all.assert_called_once()

    @patch(f"{_REPO}.list_connections", new_callable=AsyncMock)
    async def test_non_admin_all_ignored(self, mock_list):
        """user_connections with include_all=True but non-admin returns only user's."""
        user_id = uuid4()
        mock_list.return_value = [_make_connection(user_id=user_id)]

        db = AsyncMock()
        result = await service.user_connections(
            db, user_id=user_id, include_all=True, is_admin=False
        )

        assert len(result["connections"]) == 1
        mock_list.assert_called_once_with(db, user_id=user_id)


# ===========================================================================
# user_add_connection
# ===========================================================================


class TestUserAddConnection:
    @patch(f"{_REPO}.create_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.count_user_connections", new_callable=AsyncMock)
    async def test_success(self, mock_count, mock_create):
        """user_add_connection creates new connection."""
        mock_count.return_value = 1
        conn = _make_connection(status="pending")
        mock_create.return_value = conn

        db = AsyncMock()
        result = await service.user_add_connection(
            db,
            user_id=uuid4(),
            client_id="test-client",
            redirect_uri="https://example.com/callback",
        )

        assert "authUrl" in result
        assert result["existingConnections"] == 1

    @patch(f"{_REPO}.create_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.count_user_connections", new_callable=AsyncMock)
    async def test_with_company_id(self, mock_count, mock_create):
        """user_add_connection passes company_id to repo.create_connection."""
        mock_count.return_value = 0
        company_id = uuid4()
        conn = _make_connection(status="pending", company_id=company_id)
        mock_create.return_value = conn

        db = AsyncMock()
        user_id = uuid4()
        result = await service.user_add_connection(
            db,
            user_id=user_id,
            client_id="test-client",
            redirect_uri="https://example.com/callback",
            company_id=str(company_id),
        )

        assert "authUrl" in result
        assert result["connectionId"] == str(conn.id)
        # Verify company_id was passed to create_connection
        mock_create.assert_called_once_with(
            db,
            user_id=user_id,
            company_id=company_id,
            status="pending",
        )

    @patch(f"{_REPO}.create_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.count_user_connections", new_callable=AsyncMock)
    async def test_without_company_id(self, mock_count, mock_create):
        """user_add_connection without company_id does not pass it to repo."""
        mock_count.return_value = 0
        conn = _make_connection(status="pending")
        mock_create.return_value = conn

        db = AsyncMock()
        user_id = uuid4()
        result = await service.user_add_connection(
            db,
            user_id=user_id,
            client_id="test-client",
            redirect_uri="https://example.com/callback",
        )

        assert "authUrl" in result
        # Verify company_id was NOT passed to create_connection
        mock_create.assert_called_once_with(
            db,
            user_id=user_id,
            status="pending",
        )

    @patch(f"{_REPO}.create_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.count_user_connections", new_callable=AsyncMock)
    async def test_invalid_company_id_raises_validation_error(self, mock_count, mock_create):
        """user_add_connection rejects malformed UUID company_id."""
        from spaps_server_quickstart.domains.errors import ValidationError

        mock_count.return_value = 0
        db = AsyncMock()

        with pytest.raises(ValidationError, match="company_id must be a valid UUID"):
            await service.user_add_connection(
                db,
                user_id=uuid4(),
                client_id="test-client",
                redirect_uri="https://example.com/callback",
                company_id="not-a-uuid",
            )

        mock_create.assert_not_called()

    @patch(f"{_REPO}.create_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.count_user_connections", new_callable=AsyncMock)
    async def test_missing_client_id_raises_validation_error(self, mock_count, mock_create):
        """user_add_connection rejects missing OAuth client config."""
        from spaps_server_quickstart.domains.errors import ValidationError

        mock_count.return_value = 0
        db = AsyncMock()

        with pytest.raises(ValidationError, match="missing QUICKBOOKS_CLIENT_ID"):
            await service.user_add_connection(
                db,
                user_id=uuid4(),
                client_id="",
                redirect_uri="https://example.com/callback",
            )

        mock_count.assert_not_called()
        mock_create.assert_not_called()


# ===========================================================================
# user_delete_connection
# ===========================================================================


class TestUserDeleteConnection:
    @patch(f"{_REPO}.update_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    async def test_success(self, mock_get, mock_update):
        """user_delete_connection scrubs runtime credentials and disconnects."""
        user_id = uuid4()
        conn = _make_connection(user_id=user_id)
        mock_get.return_value = conn
        mock_update.return_value = conn

        db = AsyncMock()
        result = await service.user_delete_connection(
            db, user_id=user_id, connection_id=conn.id
        )

        assert result["success"] is True
        mock_update.assert_called_once_with(
            db,
            conn.id,
            status="disconnected",
            encrypted_refresh_token=None,
            token_expires_at=None,
        )

    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    async def test_not_found(self, mock_get):
        """user_delete_connection raises NOT_FOUND for unknown connection."""
        mock_get.return_value = None

        db = AsyncMock()
        with pytest.raises(CfoConnectionNotFoundError):
            await service.user_delete_connection(
                db, user_id=uuid4(), connection_id=uuid4()
            )

    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    async def test_wrong_user(self, mock_get):
        """user_delete_connection raises NOT_FOUND for other user's connection."""
        conn = _make_connection(user_id=uuid4())
        mock_get.return_value = conn

        db = AsyncMock()
        with pytest.raises(CfoConnectionNotFoundError, match="not found for this user"):
            await service.user_delete_connection(
                db, user_id=uuid4(), connection_id=conn.id
            )


# ===========================================================================
# generate_auth_code
# ===========================================================================


class TestGenerateAuthCode:
    def test_generates_64_hex_chars(self):
        """generate_auth_code returns a 64-character hex string."""
        code = service.generate_auth_code()
        assert len(code) == 64
        assert all(c in "0123456789abcdef" for c in code)


# ===========================================================================
# get_connect_start_url
# ===========================================================================


class TestGetConnectStartUrl:
    async def test_with_token(self):
        """get_connect_start_url uses token as state."""
        result = await service.get_connect_start_url(
            client_id="test-client",
            redirect_uri="https://example.com/callback",
            token="my-token",
        )

        assert "authUrl" in result
        assert result["state"] == "my-token"
        assert "my-token" in result["authUrl"]

    async def test_without_token(self):
        """get_connect_start_url generates random state."""
        result = await service.get_connect_start_url(
            client_id="test-client",
            redirect_uri="https://example.com/callback",
        )

        assert "authUrl" in result
        assert result["state"] is not None
        assert len(result["state"]) > 0


# ===========================================================================
# connect_with_email
# ===========================================================================


class TestConnectWithEmail:
    @patch(f"{_REPO}.create_connection", new_callable=AsyncMock)
    async def test_success(self, mock_create):
        """connect_with_email creates connection and returns auth URL."""
        conn = _make_connection(status="pending")
        mock_create.return_value = conn

        db = AsyncMock()
        result = await service.connect_with_email(
            db,
            email="client@example.com",
            client_id="test-client",
            redirect_uri="https://example.com/callback",
        )

        assert "authUrl" in result
        assert result["connectionId"] == str(conn.id)

    async def test_empty_email_raises(self):
        """connect_with_email raises ValidationError for empty email."""
        from spaps_server_quickstart.domains.errors import ValidationError

        db = AsyncMock()
        with pytest.raises(ValidationError):
            await service.connect_with_email(
                db,
                email="",
                client_id="test-client",
                redirect_uri="https://example.com/callback",
            )


# ===========================================================================
# CFO public key fail-closed (security hardening)
# ===========================================================================


class TestCfoPublicKeyFailClosed:
    @patch(f"{_REPO}.create_auth_code", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_magic_link_by_token", new_callable=AsyncMock)
    @patch(f"{_QB}.fetch_user_info", new_callable=AsyncMock)
    @patch(f"{_QB}.fetch_company_info", new_callable=AsyncMock)
    @patch(f"{_QB}.exchange_code_for_tokens", new_callable=AsyncMock)
    async def test_rejects_callback_when_public_key_missing(
        self,
        mock_exchange,
        mock_company,
        mock_user,
        mock_get_link,
        mock_get_conn,
        mock_update_conn,
        mock_create_conn,
        mock_create_auth_code,
    ):
        """OAuth callback fails closed when refresh token encryption is unavailable."""
        conn = _make_connection(status="pending")
        mock_exchange.return_value = {
            "access_token": "at",
            "refresh_token": "rt_present",
            "expires_in": 3600,
        }
        mock_company.return_value = {"CompanyName": "Acme"}
        mock_user.return_value = {"email": "user@example.com"}
        mock_get_link.return_value = None
        mock_get_conn.return_value = conn

        db = AsyncMock()
        result = await service.process_oauth_callback(
            db,
            code="auth-code",
            state=str(conn.id),
            realm_id="123456789",
            client_id="cid",
            client_secret="csec",
            redirect_uri="https://example.com/callback",
            cfo_public_key="",
            frontend_url="https://app.example.com",
        )

        assert result["error"] is True
        assert "Token+encryption+not+configured" in result["redirect"]
        mock_update_conn.assert_not_called()
        mock_create_conn.assert_not_called()
        mock_create_auth_code.assert_not_called()

    @patch(f"{_REPO}.create_auth_code", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_magic_link_by_token", new_callable=AsyncMock)
    @patch(f"{_QB}.fetch_user_info", new_callable=AsyncMock)
    @patch(f"{_QB}.fetch_company_info", new_callable=AsyncMock)
    @patch(f"{_QB}.exchange_code_for_tokens", new_callable=AsyncMock)
    async def test_rejects_callback_when_encryption_fails(
        self,
        mock_exchange,
        mock_company,
        mock_user,
        mock_get_link,
        mock_get_conn,
        mock_update_conn,
        mock_create_conn,
        mock_create_auth_code,
    ):
        """OAuth callback fails closed if refresh-token encryption raises."""
        conn = _make_connection(status="pending")
        mock_exchange.return_value = {
            "access_token": "at",
            "refresh_token": "rt_present",
            "expires_in": 3600,
        }
        mock_company.return_value = {"CompanyName": "Acme"}
        mock_user.return_value = {"email": "user@example.com"}
        mock_get_link.return_value = None
        mock_get_conn.return_value = conn

        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.cfo.service.encrypt_refresh_token",
            side_effect=service.CfoOAuthError("encryption failed"),
        ):
            result = await service.process_oauth_callback(
                db,
                code="auth-code",
                state=str(conn.id),
                realm_id="123456789",
                client_id="cid",
                client_secret="csec",
                redirect_uri="https://example.com/callback",
                cfo_public_key="valid-public-key",
                frontend_url="https://app.example.com",
            )

        assert result["error"] is True
        assert "Token+encryption+failed" in result["redirect"]
        mock_update_conn.assert_not_called()
        mock_create_conn.assert_not_called()
        mock_create_auth_code.assert_not_called()


class TestProcessOAuthCallbackDirectFlow:
    @patch(f"{_QB}.exchange_code_for_tokens", new_callable=AsyncMock)
    async def test_exchange_failure_returns_error_redirect(self, mock_exchange):
        mock_exchange.side_effect = service.qb.QuickBooksAPIError("boom")

        db = AsyncMock()
        result = await service.process_oauth_callback(
            db,
            code="auth-code",
            state=str(uuid4()),
            realm_id="123456789",
            client_id="cid",
            client_secret="csec",
            redirect_uri="https://example.com/callback",
            cfo_public_key="configured-key",
            frontend_url="https://app.example.com",
        )

        assert result["error"] is True
        assert "OAuth+exchange+failed" in result["redirect"]

    @patch(f"{_QB}.exchange_code_for_tokens", new_callable=AsyncMock)
    async def test_missing_refresh_token_returns_error_redirect(self, mock_exchange):
        mock_exchange.return_value = {
            "access_token": "at",
            "refresh_token": "",
            "expires_in": 3600,
        }

        db = AsyncMock()
        result = await service.process_oauth_callback(
            db,
            code="auth-code",
            state=str(uuid4()),
            realm_id="123456789",
            client_id="cid",
            client_secret="csec",
            redirect_uri="https://example.com/callback",
            cfo_public_key="configured-key",
            frontend_url="https://app.example.com",
        )

        assert result["error"] is True
        assert "OAuth+exchange+failed" in result["redirect"]

    @patch(f"{_REPO}.create_auth_code", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_connection", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_connection_by_id", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_magic_link_by_token", new_callable=AsyncMock)
    @patch(f"{_QB}.fetch_user_info", new_callable=AsyncMock)
    @patch(f"{_QB}.fetch_company_info", new_callable=AsyncMock)
    @patch(f"{_QB}.exchange_code_for_tokens", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.cfo.service.generate_auth_code")
    async def test_direct_flow_creates_connection_and_auth_code(
        self,
        mock_generate_auth_code,
        mock_exchange,
        mock_company,
        mock_user,
        mock_get_link,
        mock_get_conn,
        mock_create_conn,
        mock_create_auth_code,
    ):
        mock_generate_auth_code.return_value = "a" * 64
        mock_exchange.return_value = {
            "access_token": "at",
            "refresh_token": "rt",
            "expires_in": 3600,
        }
        mock_company.return_value = {"CompanyName": "Acme"}
        mock_user.return_value = {"email": "user@example.com"}
        mock_get_link.return_value = None
        mock_get_conn.return_value = None
        conn = _make_connection(status="connected")
        mock_create_conn.return_value = conn

        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.cfo.service.encrypt_refresh_token",
            side_effect=["encrypted-refresh", "encrypted-auth-data"],
        ):
            result = await service.process_oauth_callback(
                db,
                code="auth-code",
                state=str(uuid4()),
                realm_id="123456789",
                client_id="cid",
                client_secret="csec",
                redirect_uri="https://example.com/callback",
                cfo_public_key="configured-key",
                frontend_url="https://app.example.com",
            )

        assert result["error"] is False
        assert result["connection_id"] == str(conn.id)
        assert result["auth_code"] == "a" * 64
        assert result["redirect"].endswith(f"code={'a' * 64}")
        mock_create_conn.assert_awaited_once()
        assert (
            mock_create_auth_code.await_args.kwargs["encrypted_auth_data"]
            == "encrypted-auth-data"
        )
