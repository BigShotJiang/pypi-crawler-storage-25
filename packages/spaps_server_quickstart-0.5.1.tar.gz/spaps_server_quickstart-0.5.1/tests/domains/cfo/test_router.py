"""Unit tests for the CFO domain router (HTTP layer).

Each test creates a minimal FastAPI test app with dependency overrides.
The CFO service layer is fully mocked so tests exercise only routing,
request validation, status codes, and response shapes.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.cfo.router import cfo_router
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_current_user,
    get_db_session,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

FAKE_USER_ID = str(uuid4())
FAKE_ADMIN_ID = str(uuid4())
FAKE_CONNECTION_ID = str(uuid4())
FAKE_TOKEN = "test-magic-link-token-abc123"
FAKE_AUTH_CODE = "a" * 64
FAKE_CFO_ADMIN_KEY = "test-cfo-admin-key-12345"

_CFO_SERVICE = "spaps_server_quickstart.domains.cfo.service"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fake_user():
    """Return a mock authenticated user."""
    user = MagicMock()
    user.id = FAKE_USER_ID
    user.email = "user@example.com"
    user.username = "user"
    user.tier = "premium"
    user.roles = ["user"]
    user.permissions = []
    user.is_admin = False
    user.is_super_admin = False
    user.wallet_addresses = []
    return user


def _fake_admin_user():
    """Return a mock admin user."""
    user = MagicMock()
    user.id = FAKE_ADMIN_ID
    user.email = "admin@example.com"
    user.username = "admin"
    user.tier = "enterprise"
    user.roles = ["admin"]
    user.permissions = ["manage_connections"]
    user.is_admin = True
    user.is_super_admin = False
    user.wallet_addresses = []
    return user


def _create_test_app(user_override=None):
    """Create a FastAPI test app with CFO router and overridden deps."""
    app = FastAPI()

    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    settings.cfo_admin_api_key = FAKE_CFO_ADMIN_KEY
    settings.quickbooks_client_id = "test-client-id"
    settings.quickbooks_client_secret = "test-client-secret"
    settings.quickbooks_redirect_uri = ""
    settings.cfo_public_key = "configured-key"
    settings.cfo_frontend_url = "https://app.example.com"
    app.state.settings = settings

    install_error_handlers(app)
    app.include_router(cfo_router)

    mock_db = AsyncMock()

    async def override_db_session():
        yield mock_db

    app.dependency_overrides[get_db_session] = override_db_session
    app.dependency_overrides[get_current_user] = user_override or _fake_user

    return app


@pytest.fixture
def test_app():
    return _create_test_app()


@pytest.fixture
def admin_test_app():
    return _create_test_app(user_override=_fake_admin_user)


@pytest.fixture
async def client(test_app):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


@pytest.fixture
async def admin_client(admin_test_app):
    transport = ASGITransport(app=admin_test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ===========================================================================
# POST /cfo/generate-link
# ===========================================================================


class TestGenerateLink:
    @patch(f"{_CFO_SERVICE}.generate_magic_link", new_callable=AsyncMock)
    async def test_success(self, mock_gen, client: AsyncClient):
        """POST /cfo/generate-link returns link details."""
        expires = (datetime.now(UTC) + timedelta(hours=24)).isoformat()
        mock_gen.return_value = {
            "url": "https://app.example.com/cfo/connect?token=abc",
            "token": "abc",
            "expiresAt": expires,
            "connectionId": FAKE_CONNECTION_ID,
        }

        resp = await client.post(
            "/cfo/generate-link",
            json={"clientName": "Acme Corp"},
            headers={"X-CFO-Admin-Key": FAKE_CFO_ADMIN_KEY},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert "url" in data
        assert "token" in data
        assert data["connectionId"] == FAKE_CONNECTION_ID

    async def test_missing_admin_key_returns_401(self, client: AsyncClient):
        """POST /cfo/generate-link without admin key returns 401."""
        resp = await client.post(
            "/cfo/generate-link",
            json={"clientName": "Acme Corp"},
        )
        assert resp.status_code == 401

    async def test_wrong_admin_key_returns_401(self, client: AsyncClient):
        """POST /cfo/generate-link with wrong admin key returns 401."""
        resp = await client.post(
            "/cfo/generate-link",
            json={"clientName": "Acme Corp"},
            headers={"X-CFO-Admin-Key": "wrong-key"},
        )
        assert resp.status_code == 401

    @patch(f"{_CFO_SERVICE}.generate_magic_link", new_callable=AsyncMock)
    async def test_admin_key_uses_constant_time_comparison(
        self, mock_gen, client: AsyncClient
    ):
        """Admin key check uses hmac.compare_digest (timing-safe)."""
        import hmac as hmac_mod

        expires = (datetime.now(UTC) + timedelta(hours=24)).isoformat()
        mock_gen.return_value = {
            "url": "https://app.example.com/cfo/connect?token=abc",
            "token": "abc",
            "expiresAt": expires,
            "connectionId": FAKE_CONNECTION_ID,
        }

        with patch.object(hmac_mod, "compare_digest", wraps=hmac_mod.compare_digest) as mock_cmp:
            resp = await client.post(
                "/cfo/generate-link",
                json={"clientName": "Acme Corp"},
                headers={"X-CFO-Admin-Key": FAKE_CFO_ADMIN_KEY},
            )
            assert resp.status_code == 200
            mock_cmp.assert_called_once_with(FAKE_CFO_ADMIN_KEY, FAKE_CFO_ADMIN_KEY)

    async def test_missing_client_name_returns_400(self, client: AsyncClient):
        """POST /cfo/generate-link without clientName returns 400."""
        resp = await client.post(
            "/cfo/generate-link",
            json={},
            headers={"X-CFO-Admin-Key": FAKE_CFO_ADMIN_KEY},
        )
        assert resp.status_code == 400


# ===========================================================================
# GET /cfo/validate-token
# ===========================================================================


class TestValidateToken:
    @patch(
        f"{_CFO_SERVICE}.validate_magic_link_token", new_callable=AsyncMock
    )
    async def test_valid_token(self, mock_validate, client: AsyncClient):
        """GET /cfo/validate-token returns valid=True for good token."""
        mock_validate.return_value = {
            "valid": True,
            "clientName": "Acme Corp",
            "authUrl": "https://intuit.com/oauth?...",
            "expiresAt": datetime.now(UTC).isoformat(),
        }

        resp = await client.get(
            "/cfo/validate-token", params={"token": FAKE_TOKEN}
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["valid"] is True
        assert data["clientName"] == "Acme Corp"
        assert "authUrl" in data

    @patch(
        f"{_CFO_SERVICE}.validate_magic_link_token", new_callable=AsyncMock
    )
    async def test_invalid_token(self, mock_validate, client: AsyncClient):
        """GET /cfo/validate-token returns valid=False for bad token."""
        mock_validate.return_value = {"valid": False}

        resp = await client.get(
            "/cfo/validate-token", params={"token": "bad-token"}
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["valid"] is False

    async def test_missing_token_returns_400(self, client: AsyncClient):
        """GET /cfo/validate-token without token returns 400."""
        resp = await client.get("/cfo/validate-token")
        assert resp.status_code == 400


# ===========================================================================
# GET /cfo/callback
# ===========================================================================


class TestOAuthCallback:
    @patch(
        f"{_CFO_SERVICE}.process_oauth_callback", new_callable=AsyncMock
    )
    async def test_success_redirect(self, mock_callback, client: AsyncClient):
        """GET /cfo/callback redirects to success page."""
        mock_callback.return_value = {
            "redirect": "https://app.example.com/cfo/success?company=Acme",
            "error": False,
        }

        resp = await client.get(
            "/cfo/callback",
            params={
                "code": "auth-code-123",
                "state": "some-state",
                "realmId": "123456789",
            },
            follow_redirects=False,
        )

        assert resp.status_code == 302
        assert "cfo/success" in resp.headers["location"]

    async def test_missing_params_redirects_to_error(
        self, client: AsyncClient
    ):
        """GET /cfo/callback without required params redirects to error."""
        resp = await client.get(
            "/cfo/callback",
            params={"code": "abc"},
            follow_redirects=False,
        )

        assert resp.status_code == 302
        assert "cfo/expired" in resp.headers["location"]
        assert "Missing" in resp.headers["location"]

    async def test_non_numeric_realm_id_redirects_to_error(
        self, client: AsyncClient
    ):
        """GET /cfo/callback with non-numeric realmId redirects to error."""
        resp = await client.get(
            "/cfo/callback",
            params={
                "code": "abc",
                "state": "state",
                "realmId": "not-a-number",
            },
            follow_redirects=False,
        )

        assert resp.status_code == 302
        assert "Invalid+company+identifier" in resp.headers["location"]

    async def test_error_param_redirects_to_error(
        self, client: AsyncClient
    ):
        """GET /cfo/callback with error param redirects to error page."""
        resp = await client.get(
            "/cfo/callback",
            params={"error": "access_denied"},
            follow_redirects=False,
        )

        assert resp.status_code == 302
        assert "cfo/expired" in resp.headers["location"]
        assert "access_denied" in resp.headers["location"]

    @patch(f"{_CFO_SERVICE}.process_oauth_callback", new_callable=AsyncMock)
    async def test_missing_public_key_fails_closed(
        self, mock_callback, test_app: FastAPI
    ):
        """GET /cfo/callback fails closed when CFO public key is missing."""
        test_app.state.settings.cfo_public_key = ""

        transport = ASGITransport(app=test_app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get(
                "/cfo/callback",
                params={
                    "code": "auth-code-123",
                    "state": "some-state",
                    "realmId": "123456789",
                },
                follow_redirects=False,
            )

        assert resp.status_code == 302
        assert "cfo/expired" in resp.headers["location"]
        assert "Token+encryption+not+configured" in resp.headers["location"]
        mock_callback.assert_not_called()


# ===========================================================================
# GET /cfo/connect-start
# ===========================================================================


class TestConnectStart:
    @patch(
        f"{_CFO_SERVICE}.get_connect_start_url", new_callable=AsyncMock
    )
    async def test_redirect(self, mock_start, client: AsyncClient):
        """GET /cfo/connect-start redirects to Intuit OAuth."""
        mock_start.return_value = {
            "authUrl": "https://appcenter.intuit.com/connect/oauth2?...",
            "state": "random-uuid",
        }

        resp = await client.get(
            "/cfo/connect-start",
            follow_redirects=False,
        )

        assert resp.status_code == 302
        assert "intuit.com" in resp.headers["location"]
        mock_start.assert_awaited_once()
        assert mock_start.call_args.kwargs["redirect_uri"] == "http://test/api/cfo/callback"

    @patch(
        f"{_CFO_SERVICE}.get_connect_start_url", new_callable=AsyncMock
    )
    async def test_uses_configured_redirect_uri(self, mock_start):
        """Configured QUICKBOOKS_REDIRECT_URI is used over request base URL."""
        app = _create_test_app()
        app.state.settings.quickbooks_redirect_uri = (
            "https://api.sweetpotato.dev/api/cfo/callback"
        )
        mock_start.return_value = {
            "authUrl": "https://appcenter.intuit.com/connect/oauth2?...",
            "state": "random-uuid",
        }

        transport = ASGITransport(app=app)
        async with AsyncClient(
            transport=transport,
            base_url="http://100.72.131.124:3301",
        ) as local_client:
            resp = await local_client.get(
                "/cfo/connect-start",
                follow_redirects=False,
            )

        assert resp.status_code == 302
        mock_start.assert_awaited_once()
        assert (
            mock_start.call_args.kwargs["redirect_uri"]
            == "https://api.sweetpotato.dev/api/cfo/callback"
        )


# ===========================================================================
# POST /cfo/connect-with-email
# ===========================================================================


class TestConnectWithEmail:
    @patch(f"{_CFO_SERVICE}.connect_with_email", new_callable=AsyncMock)
    async def test_success(self, mock_connect, client: AsyncClient):
        """POST /cfo/connect-with-email returns auth URL."""
        mock_connect.return_value = {
            "authUrl": "https://intuit.com/oauth?...",
            "connectionId": FAKE_CONNECTION_ID,
        }

        resp = await client.post(
            "/cfo/connect-with-email",
            json={"email": "client@example.com"},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert "authUrl" in data
        assert data["connectionId"] == FAKE_CONNECTION_ID

    async def test_missing_email_returns_400(self, client: AsyncClient):
        """POST /cfo/connect-with-email without email returns 400."""
        resp = await client.post(
            "/cfo/connect-with-email",
            json={},
        )
        assert resp.status_code == 400


# ===========================================================================
# POST /cfo/exchange-code
# ===========================================================================


class TestExchangeCode:
    @patch(f"{_CFO_SERVICE}.exchange_auth_code", new_callable=AsyncMock)
    async def test_success(self, mock_exchange, client: AsyncClient):
        """POST /cfo/exchange-code returns tokens and user info."""
        mock_exchange.return_value = {
            "company_name": "Acme Corp",
            "realm_id": "123456789",
            "user_id": FAKE_USER_ID,
            "encrypted_auth_data": "encrypted-data",
        }

        resp = await client.post(
            "/cfo/exchange-code",
            json={"code": FAKE_AUTH_CODE},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["company_name"] == "Acme Corp"
        assert data["realm_id"] == "123456789"

    @patch(f"{_CFO_SERVICE}.exchange_auth_code", new_callable=AsyncMock)
    async def test_invalid_code_returns_401(
        self, mock_exchange, client: AsyncClient
    ):
        """POST /cfo/exchange-code with bad code returns 401."""
        from spaps_server_quickstart.domains.cfo.errors import (
            CfoInvalidCodeError,
        )

        mock_exchange.side_effect = CfoInvalidCodeError()

        resp = await client.post(
            "/cfo/exchange-code",
            json={"code": FAKE_AUTH_CODE},
        )

        assert resp.status_code == 401

    async def test_short_code_returns_400(self, client: AsyncClient):
        """POST /cfo/exchange-code with short code returns 400."""
        resp = await client.post(
            "/cfo/exchange-code",
            json={"code": "too-short"},
        )
        assert resp.status_code == 400

    async def test_missing_code_returns_400(self, client: AsyncClient):
        """POST /cfo/exchange-code without code returns 400."""
        resp = await client.post(
            "/cfo/exchange-code",
            json={},
        )
        assert resp.status_code == 400


# ===========================================================================
# GET /cfo/status (admin)
# ===========================================================================


class TestGetStatus:
    @patch(f"{_CFO_SERVICE}.get_connection_status", new_callable=AsyncMock)
    async def test_success(self, mock_status, client: AsyncClient):
        """GET /cfo/status returns connection details."""
        mock_status.return_value = {
            "id": FAKE_CONNECTION_ID,
            "user_id": FAKE_USER_ID,
            "client_name": "Acme Corp",
            "company_name": "Acme Corporation",
            "realm_id": "123456789",
            "status": "connected",
            "accounting_method": None,
            "risk_tier": None,
            "connected_at": datetime.now(UTC).isoformat(),
            "token_expires_at": None,
            "created_at": datetime.now(UTC).isoformat(),
        }

        resp = await client.get(
            "/cfo/status",
            params={"connectionId": FAKE_CONNECTION_ID},
            headers={"X-CFO-Admin-Key": FAKE_CFO_ADMIN_KEY},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "connected"

    async def test_missing_admin_key_returns_401(self, client: AsyncClient):
        """GET /cfo/status without admin key returns 401."""
        resp = await client.get(
            "/cfo/status",
            params={"connectionId": FAKE_CONNECTION_ID},
        )
        assert resp.status_code == 401


# ===========================================================================
# POST /cfo/revoke (admin)
# ===========================================================================


class TestRevokeConnection:
    @patch(f"{_CFO_SERVICE}.revoke_connection", new_callable=AsyncMock)
    async def test_success(self, mock_revoke, client: AsyncClient):
        """POST /cfo/revoke returns revoked=True."""
        mock_revoke.return_value = {
            "revoked": True,
            "message": "Connection revoked successfully",
        }

        resp = await client.post(
            "/cfo/revoke",
            json={"connectionId": FAKE_CONNECTION_ID},
            headers={"X-CFO-Admin-Key": FAKE_CFO_ADMIN_KEY},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["revoked"] is True

    @patch(f"{_CFO_SERVICE}.revoke_connection", new_callable=AsyncMock)
    async def test_not_found_returns_404(
        self, mock_revoke, client: AsyncClient
    ):
        """POST /cfo/revoke with unknown ID returns 404."""
        from spaps_server_quickstart.domains.cfo.errors import (
            CfoConnectionNotFoundError,
        )

        mock_revoke.side_effect = CfoConnectionNotFoundError()

        resp = await client.post(
            "/cfo/revoke",
            json={"connectionId": str(uuid4())},
            headers={"X-CFO-Admin-Key": FAKE_CFO_ADMIN_KEY},
        )

        assert resp.status_code == 404

    async def test_missing_admin_key_returns_401(self, client: AsyncClient):
        """POST /cfo/revoke without admin key returns 401."""
        resp = await client.post(
            "/cfo/revoke",
            json={"connectionId": FAKE_CONNECTION_ID},
        )
        assert resp.status_code == 401


# ===========================================================================
# GET /cfo/connections (admin)
# ===========================================================================


class TestListConnections:
    @patch(f"{_CFO_SERVICE}.list_connections", new_callable=AsyncMock)
    async def test_success(self, mock_list, client: AsyncClient):
        """GET /cfo/connections returns connection list."""
        mock_list.return_value = {
            "connections": [
                {
                    "id": FAKE_CONNECTION_ID,
                    "user_id": FAKE_USER_ID,
                    "client_name": "Acme",
                    "company_name": "Acme Corp",
                    "realm_id": "123",
                    "status": "connected",
                    "accounting_method": None,
                    "risk_tier": None,
                    "connected_at": datetime.now(UTC).isoformat(),
                    "token_expires_at": None,
                    "created_at": datetime.now(UTC).isoformat(),
                },
            ],
        }

        resp = await client.get(
            "/cfo/connections",
            headers={"X-CFO-Admin-Key": FAKE_CFO_ADMIN_KEY},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert len(data["connections"]) == 1

    @patch(f"{_CFO_SERVICE}.list_connections", new_callable=AsyncMock)
    async def test_with_user_id_filter(self, mock_list, client: AsyncClient):
        """GET /cfo/connections with user_id filter."""
        mock_list.return_value = {"connections": []}

        resp = await client.get(
            "/cfo/connections",
            params={"user_id": FAKE_USER_ID},
            headers={"X-CFO-Admin-Key": FAKE_CFO_ADMIN_KEY},
        )

        assert resp.status_code == 200

    async def test_missing_admin_key_returns_401(self, client: AsyncClient):
        """GET /cfo/connections without admin key returns 401."""
        resp = await client.get("/cfo/connections")
        assert resp.status_code == 401


# ===========================================================================
# GET /cfo/runtime-token (admin)
# ===========================================================================


class TestGetRuntimeToken:
    @patch(f"{_CFO_SERVICE}.get_runtime_connection_token", new_callable=AsyncMock)
    async def test_success_by_connection_id(self, mock_get_token, client: AsyncClient):
        """GET /cfo/runtime-token returns encrypted token payload."""
        mock_get_token.return_value = {
            "connection_id": FAKE_CONNECTION_ID,
            "realm_id": "123456789",
            "company_name": "Acme Corp",
            "status": "connected",
            "client_id": "test-client-id",
            "environment": "production",
            "encrypted_refresh_token": "encrypted-token",
            "encrypted_client_secret": "encrypted-secret",
        }

        resp = await client.get(
            "/cfo/runtime-token",
            params={"connectionId": FAKE_CONNECTION_ID},
            headers={"X-CFO-Admin-Key": FAKE_CFO_ADMIN_KEY},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["connection_id"] == FAKE_CONNECTION_ID
        assert data["encrypted_refresh_token"] == "encrypted-token"
        assert data["encrypted_client_secret"] == "encrypted-secret"

    @patch(f"{_CFO_SERVICE}.get_runtime_connection_token", new_callable=AsyncMock)
    async def test_success_by_realm_id(self, mock_get_token, client: AsyncClient):
        """GET /cfo/runtime-token supports realmId lookups."""
        mock_get_token.return_value = {
            "connection_id": FAKE_CONNECTION_ID,
            "realm_id": "123456789",
            "company_name": "Acme Corp",
            "status": "connected",
            "client_id": "test-client-id",
            "environment": "production",
            "encrypted_refresh_token": "encrypted-token",
            "encrypted_client_secret": "encrypted-secret",
        }

        resp = await client.get(
            "/cfo/runtime-token",
            params={"realmId": "123456789"},
            headers={"X-CFO-Admin-Key": FAKE_CFO_ADMIN_KEY},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["realm_id"] == "123456789"

    async def test_invalid_connection_id_returns_400(self, client: AsyncClient):
        """GET /cfo/runtime-token validates connectionId query params."""
        resp = await client.get(
            "/cfo/runtime-token",
            params={"connectionId": "not-a-uuid"},
            headers={"X-CFO-Admin-Key": FAKE_CFO_ADMIN_KEY},
        )

        assert resp.status_code == 400

    async def test_missing_admin_key_returns_401(self, client: AsyncClient):
        """GET /cfo/runtime-token without admin key returns 401."""
        resp = await client.get(
            "/cfo/runtime-token",
            params={"realmId": "123456789"},
        )
        assert resp.status_code == 401


# ===========================================================================
# POST /cfo/user-connect
# ===========================================================================


class TestUserConnect:
    @patch(f"{_CFO_SERVICE}.user_connect", new_callable=AsyncMock)
    async def test_success(self, mock_connect, client: AsyncClient):
        """POST /cfo/user-connect returns auth URL and connection ID."""
        mock_connect.return_value = {
            "authUrl": "https://intuit.com/oauth?...",
            "connectionId": FAKE_CONNECTION_ID,
        }

        resp = await client.post("/cfo/user-connect")

        assert resp.status_code == 200
        data = resp.json()
        assert "authUrl" in data
        assert data["connectionId"] == FAKE_CONNECTION_ID


# ===========================================================================
# GET /cfo/user-status
# ===========================================================================


class TestUserStatus:
    @patch(f"{_CFO_SERVICE}.user_status", new_callable=AsyncMock)
    async def test_with_connection(self, mock_status, client: AsyncClient):
        """GET /cfo/user-status returns connection details."""
        mock_status.return_value = {
            "connection": {
                "id": FAKE_CONNECTION_ID,
                "status": "connected",
                "companyName": "Acme Corp",
                "realmId": "123456789",
                "connectedAt": datetime.now(UTC).isoformat(),
                "tokenExpiresAt": None,
            },
            "totalConnections": 1,
        }

        resp = await client.get("/cfo/user-status")

        assert resp.status_code == 200
        data = resp.json()
        assert data["connection"] is not None
        assert data["totalConnections"] == 1

    @patch(f"{_CFO_SERVICE}.user_status", new_callable=AsyncMock)
    async def test_no_connection(self, mock_status, client: AsyncClient):
        """GET /cfo/user-status returns null connection."""
        mock_status.return_value = {
            "connection": None,
            "totalConnections": 0,
        }

        resp = await client.get("/cfo/user-status")

        assert resp.status_code == 200
        data = resp.json()
        assert data["connection"] is None
        assert data["totalConnections"] == 0


# ===========================================================================
# POST /cfo/user-disconnect
# ===========================================================================


class TestUserDisconnect:
    @patch(f"{_CFO_SERVICE}.user_disconnect", new_callable=AsyncMock)
    async def test_success(self, mock_disconnect, client: AsyncClient):
        """POST /cfo/user-disconnect returns success."""
        mock_disconnect.return_value = {
            "success": True,
            "message": "QuickBooks disconnected",
        }

        resp = await client.post("/cfo/user-disconnect")

        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert str(mock_disconnect.call_args.kwargs["user_id"]) == FAKE_USER_ID

    @patch(f"{_CFO_SERVICE}.user_disconnect", new_callable=AsyncMock)
    async def test_no_connection_returns_404(
        self, mock_disconnect, client: AsyncClient
    ):
        """POST /cfo/user-disconnect with no connection returns 404."""
        from spaps_server_quickstart.domains.cfo.errors import (
            CfoConnectionNotFoundError,
        )

        mock_disconnect.side_effect = CfoConnectionNotFoundError(
            "No active connection found"
        )

        resp = await client.post("/cfo/user-disconnect")

        assert resp.status_code == 404


# ===========================================================================
# GET /cfo/user-connections
# ===========================================================================


class TestUserConnections:
    @patch(f"{_CFO_SERVICE}.user_connections", new_callable=AsyncMock)
    async def test_success(self, mock_conns, client: AsyncClient):
        """GET /cfo/user-connections returns connection list."""
        mock_conns.return_value = {
            "connections": [
                {
                    "id": FAKE_CONNECTION_ID,
                    "status": "connected",
                    "companyName": "Acme Corp",
                    "realmId": "123",
                    "connectedAt": datetime.now(UTC).isoformat(),
                    "tokenExpiresAt": None,
                },
            ],
        }

        resp = await client.get("/cfo/user-connections")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data["connections"]) == 1

    @patch(f"{_CFO_SERVICE}.user_connections", new_callable=AsyncMock)
    async def test_admin_all(self, mock_conns, admin_client: AsyncClient):
        """GET /cfo/user-connections?all=true returns all connections for admin."""
        mock_conns.return_value = {
            "connections": [
                {
                    "id": FAKE_CONNECTION_ID,
                    "status": "connected",
                    "companyName": "Acme",
                    "realmId": "123",
                    "connectedAt": datetime.now(UTC).isoformat(),
                    "tokenExpiresAt": None,
                    "connectedBy": FAKE_USER_ID,
                },
            ],
        }

        resp = await admin_client.get(
            "/cfo/user-connections", params={"all": "true"}
        )

        assert resp.status_code == 200
        data = resp.json()
        assert len(data["connections"]) >= 1


# ===========================================================================
# POST /cfo/user-add-connection
# ===========================================================================


class TestUserAddConnection:
    @patch(f"{_CFO_SERVICE}.user_add_connection", new_callable=AsyncMock)
    async def test_success(self, mock_add, client: AsyncClient):
        """POST /cfo/user-add-connection returns auth URL."""
        mock_add.return_value = {
            "authUrl": "https://intuit.com/oauth?...",
            "connectionId": FAKE_CONNECTION_ID,
            "existingConnections": 1,
        }

        resp = await client.post("/cfo/user-add-connection")

        assert resp.status_code == 200
        data = resp.json()
        assert "authUrl" in data
        assert data["existingConnections"] == 1
        mock_add.assert_called_once()
        assert mock_add.call_args.kwargs["redirect_uri"] == "http://test/api/cfo/callback"

    @patch(f"{_CFO_SERVICE}.user_add_connection", new_callable=AsyncMock)
    async def test_with_company_id(self, mock_add, client: AsyncClient):
        """POST /cfo/user-add-connection with company_id passes it to service."""
        company_id = str(uuid4())
        mock_add.return_value = {
            "authUrl": "https://intuit.com/oauth?...",
            "connectionId": FAKE_CONNECTION_ID,
            "existingConnections": 0,
        }

        resp = await client.post(
            "/cfo/user-add-connection",
            json={"company_id": company_id},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert "authUrl" in data
        # Verify the service was called with company_id
        mock_add.assert_called_once()
        call_kwargs = mock_add.call_args
        assert call_kwargs.kwargs.get("company_id") == company_id

    @patch(f"{_CFO_SERVICE}.user_add_connection", new_callable=AsyncMock)
    async def test_without_body_backward_compatible(self, mock_add, client: AsyncClient):
        """POST /cfo/user-add-connection without body is backward compatible."""
        mock_add.return_value = {
            "authUrl": "https://intuit.com/oauth?...",
            "connectionId": FAKE_CONNECTION_ID,
            "existingConnections": 2,
        }

        resp = await client.post("/cfo/user-add-connection")

        assert resp.status_code == 200
        mock_add.assert_called_once()
        call_kwargs = mock_add.call_args
        assert call_kwargs.kwargs.get("company_id") is None

    @patch(f"{_CFO_SERVICE}.user_add_connection", new_callable=AsyncMock)
    async def test_invalid_company_id_returns_400(self, mock_add, client: AsyncClient):
        """POST /cfo/user-add-connection rejects malformed company_id."""
        resp = await client.post(
            "/cfo/user-add-connection",
            json={"company_id": "not-a-uuid"},
        )

        assert resp.status_code == 400
        data = resp.json()
        assert data["error"]["code"] == "VALIDATION_ERROR"
        mock_add.assert_not_called()


# ===========================================================================
# DELETE /cfo/user-connections/:connectionId
# ===========================================================================


class TestUserDeleteConnection:
    @patch(f"{_CFO_SERVICE}.user_delete_connection", new_callable=AsyncMock)
    async def test_success(self, mock_delete, client: AsyncClient):
        """DELETE /cfo/user-connections/:id returns success."""
        mock_delete.return_value = {
            "success": True,
            "message": "Connection disconnected",
        }

        resp = await client.delete(
            f"/cfo/user-connections/{FAKE_CONNECTION_ID}"
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert str(mock_delete.call_args.kwargs["user_id"]) == FAKE_USER_ID
        assert str(mock_delete.call_args.kwargs["connection_id"]) == FAKE_CONNECTION_ID

    @patch(f"{_CFO_SERVICE}.user_delete_connection", new_callable=AsyncMock)
    async def test_not_found_returns_404(
        self, mock_delete, client: AsyncClient
    ):
        """DELETE /cfo/user-connections/:id returns 404 for unknown."""
        from spaps_server_quickstart.domains.cfo.errors import (
            CfoConnectionNotFoundError,
        )

        mock_delete.side_effect = CfoConnectionNotFoundError()

        resp = await client.delete(
            f"/cfo/user-connections/{uuid4()}"
        )

        assert resp.status_code == 404

    @patch(f"{_CFO_SERVICE}.user_delete_connection", new_callable=AsyncMock)
    async def test_wrong_user_returns_404(
        self, mock_delete, client: AsyncClient
    ):
        """DELETE /cfo/user-connections/:id returns 404 for other user's connection."""
        from spaps_server_quickstart.domains.cfo.errors import (
            CfoConnectionNotFoundError,
        )

        mock_delete.side_effect = CfoConnectionNotFoundError(
            "Connection not found for this user"
        )

        resp = await client.delete(
            f"/cfo/user-connections/{uuid4()}"
        )

        assert resp.status_code == 404
