"""Unit tests for the device flow service layer.

Tests business logic for initiate, verify, and poll operations
with mocked application lookups and token generation.
"""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.device_flow import service
from spaps_server_quickstart.domains.errors import UnknownClientError, ValidationError

FAKE_APP_ID = str(uuid4())
FAKE_USER_ID = str(uuid4())

_SERVICE_MODULE = "spaps_server_quickstart.domains.device_flow.service"


@pytest.fixture(autouse=True)
def _reset_store():
    """Reset the device flow store before each test."""
    service.reset_store()
    yield
    service.reset_store()


def _mock_application():
    """Create a mock application."""
    app = MagicMock()
    app.id = FAKE_APP_ID
    app.name = "Test App"
    app.slug = "buildooor"
    return app


# ===========================================================================
# Initiate device flow
# ===========================================================================


class TestInitiateDeviceFlow:
    @patch(f"{_SERVICE_MODULE}.resolve_application_by_slug", new_callable=AsyncMock)
    async def test_success(self, mock_resolve):
        """initiate_device_flow creates entry with correct data."""
        mock_resolve.return_value = _mock_application()

        result = await service.initiate_device_flow(
            AsyncMock(),
            client_id="buildooor",
            verification_uri="https://example.com/verify",
        )

        assert "device_code" in result
        assert "user_code" in result
        assert result["verification_uri"] == "https://example.com/verify"
        assert result["expires_in"] == 900
        assert result["interval"] == 5
        assert "verification_uri_complete" in result
        assert result["user_code"] in result["verification_uri_complete"]

    @patch(f"{_SERVICE_MODULE}.resolve_application_by_slug", new_callable=AsyncMock)
    async def test_unknown_client_raises(self, mock_resolve):
        """initiate_device_flow raises for unknown client_id."""
        mock_resolve.side_effect = UnknownClientError()

        with pytest.raises(UnknownClientError):
            await service.initiate_device_flow(
                AsyncMock(),
                client_id="nonexistent",
                verification_uri="https://example.com/verify",
            )

    async def test_empty_client_id_raises(self):
        """initiate_device_flow raises for empty client_id."""
        with pytest.raises(ValidationError):
            await service.initiate_device_flow(
                AsyncMock(),
                client_id="",
                verification_uri="https://example.com/verify",
            )

    @patch(f"{_SERVICE_MODULE}.resolve_application_by_slug", new_callable=AsyncMock)
    async def test_creates_store_entry(self, mock_resolve):
        """initiate_device_flow adds entry to the store."""
        mock_resolve.return_value = _mock_application()

        result = await service.initiate_device_flow(
            AsyncMock(),
            client_id="buildooor",
            verification_uri="https://example.com/verify",
        )

        store = service.get_store()
        entry = store.get_by_device_code(result["device_code"])
        assert entry is not None
        assert entry.client_id == "buildooor"
        assert entry.application_id == FAKE_APP_ID


# ===========================================================================
# Verify device
# ===========================================================================


class TestVerifyDevice:
    @patch(f"{_SERVICE_MODULE}.resolve_application_by_slug", new_callable=AsyncMock)
    async def test_authorize_success(self, mock_resolve):
        """verify_device authorizes pending entry."""
        mock_app = _mock_application()
        mock_resolve.return_value = mock_app

        store = service.get_store()
        entry = store.create("buildooor")
        entry.application_id = FAKE_APP_ID
        sentinel_settings = SimpleNamespace(
            jwt_secret="access-secret",
            refresh_token_secret="refresh-secret",
            jwt_expires_in="10m",
            jwt_refresh_expires_in="30d",
        )

        with patch(
            f"{_SERVICE_MODULE}.generate_device_flow_tokens",
            new_callable=AsyncMock,
        ) as mock_tokens:
            mock_tokens.return_value = {
                "access_token": "at_test",
                "refresh_token": "rt_test",
            }

            result = await service.verify_device(
                AsyncMock(),
                device_code=entry.device_code,
                user_code=entry.user_code,
                action="authorize",
                user_id=FAKE_USER_ID,
                settings=sentinel_settings,
            )

        assert result["message"] == "Device authorized"
        updated = store.get_by_device_code(entry.device_code)
        assert updated.status == "authorized"
        assert updated.access_token == "at_test"
        assert mock_tokens.await_args.kwargs["settings"] is sentinel_settings

    async def test_generate_tokens_uses_explicit_settings(self):
        """generate_device_flow_tokens uses injected settings, not global settings."""
        explicit_settings = SimpleNamespace(
            jwt_secret="injected-access-secret",
            refresh_token_secret="injected-refresh-secret",
            jwt_expires_in="11m",
            jwt_refresh_expires_in="22d",
        )

        with patch(
            "spaps_server_quickstart.spaps_settings.get_spaps_settings",
        ) as mock_global_settings:
            with patch(
                "spaps_server_quickstart.domains.sessions.jwt_service.generate_token_pair",
            ) as mock_generate_pair:
                mock_generate_pair.return_value = SimpleNamespace(
                    access_token="at_injected",
                    refresh_token="rt_injected",
                )

                result = await service.generate_device_flow_tokens(
                    AsyncMock(),
                    user_id=FAKE_USER_ID,
                    application_id=FAKE_APP_ID,
                    email="user@example.com",
                    settings=explicit_settings,
                )

        assert result == {
            "access_token": "at_injected",
            "refresh_token": "rt_injected",
        }
        mock_global_settings.assert_not_called()
        call_kwargs = mock_generate_pair.call_args.kwargs
        assert call_kwargs["access_secret"] == "injected-access-secret"
        assert call_kwargs["refresh_secret"] == "injected-refresh-secret"
        assert call_kwargs["access_expires_in"] == "11m"
        assert call_kwargs["refresh_expires_in"] == "22d"

    @patch(f"{_SERVICE_MODULE}.resolve_application_by_slug", new_callable=AsyncMock)
    async def test_authorize_by_user_code_only(self, mock_resolve):
        """verify_device authorizes when only user_code is provided (browser path)."""
        mock_app = _mock_application()
        mock_resolve.return_value = mock_app

        store = service.get_store()
        entry = store.create("buildooor")
        entry.application_id = FAKE_APP_ID

        with patch(
            f"{_SERVICE_MODULE}.generate_device_flow_tokens",
            new_callable=AsyncMock,
        ) as mock_tokens:
            mock_tokens.return_value = {
                "access_token": "at_browser",
                "refresh_token": "rt_browser",
            }

            result = await service.verify_device(
                AsyncMock(),
                user_code=entry.user_code,
                action="authorize",
                user_id=FAKE_USER_ID,
            )

        assert result["message"] == "Device authorized"
        updated = store.get_by_device_code(entry.device_code)
        assert updated.status == "authorized"
        assert updated.access_token == "at_browser"

    async def test_deny_success(self):
        """verify_device denies pending entry."""
        store = service.get_store()
        entry = store.create("buildooor")

        result = await service.verify_device(
            AsyncMock(),
            device_code=entry.device_code,
            user_code=entry.user_code,
            action="deny",
            user_id=FAKE_USER_ID,
        )

        assert result["message"] == "Device authorization denied"

    async def test_invalid_device_code_raises(self):
        """verify_device raises for invalid device code."""
        with pytest.raises(ValidationError, match="Invalid or expired"):
            await service.verify_device(
                AsyncMock(),
                device_code="nonexistent",
                user_code="XXXX-YYYY",
                action="authorize",
                user_id=FAKE_USER_ID,
            )

    async def test_wrong_user_code_raises(self):
        """verify_device raises for mismatched user code."""
        store = service.get_store()
        entry = store.create("buildooor")

        with pytest.raises(ValidationError, match="User code does not match"):
            await service.verify_device(
                AsyncMock(),
                device_code=entry.device_code,
                user_code="XXXX-YYYY",
                action="authorize",
                user_id=FAKE_USER_ID,
            )

    async def test_already_authorized_raises(self):
        """verify_device raises for already authorized entry."""
        store = service.get_store()
        entry = store.create("buildooor")
        store.authorize(
            entry.device_code,
            access_token="at",
            refresh_token="rt",
            user_id="u",
        )

        with pytest.raises(ValidationError, match="already authorized"):
            await service.verify_device(
                AsyncMock(),
                device_code=entry.device_code,
                user_code=entry.user_code,
                action="authorize",
                user_id=FAKE_USER_ID,
            )

    async def test_invalid_action_raises(self):
        """verify_device raises for invalid action."""
        store = service.get_store()
        entry = store.create("buildooor")

        with pytest.raises(ValidationError, match="Invalid action"):
            await service.verify_device(
                AsyncMock(),
                device_code=entry.device_code,
                user_code=entry.user_code,
                action="invalid",
                user_id=FAKE_USER_ID,
            )


# ===========================================================================
# Poll token
# ===========================================================================


class TestPollToken:
    async def test_pending_returns_authorization_pending(self):
        """poll_token returns authorization_pending for pending entry."""
        store = service.get_store()
        entry = store.create("buildooor")

        result = await service.poll_token(
            grant_type=service.DEVICE_CODE_GRANT_TYPE,
            device_code=entry.device_code,
            client_id="buildooor",
        )

        assert result["error"] == "authorization_pending"

    async def test_authorized_returns_tokens(self):
        """poll_token returns tokens for authorized entry."""
        store = service.get_store()
        entry = store.create("buildooor")
        store.authorize(
            entry.device_code,
            access_token="at_test",
            refresh_token="rt_test",
            user_id=FAKE_USER_ID,
        )

        result = await service.poll_token(
            grant_type=service.DEVICE_CODE_GRANT_TYPE,
            device_code=entry.device_code,
            client_id="buildooor",
        )

        assert "error" not in result
        assert result["access_token"] == "at_test"
        assert result["refresh_token"] == "rt_test"
        assert result["token_type"] == "Bearer"
        assert result["user_id"] == FAKE_USER_ID

    async def test_authorized_consumes_entry(self):
        """poll_token removes entry after returning tokens."""
        store = service.get_store()
        entry = store.create("buildooor")
        store.authorize(
            entry.device_code,
            access_token="at",
            refresh_token="rt",
            user_id="u",
        )

        await service.poll_token(
            grant_type=service.DEVICE_CODE_GRANT_TYPE,
            device_code=entry.device_code,
            client_id="buildooor",
        )

        assert store.size == 0

    async def test_denied_returns_access_denied(self):
        """poll_token returns access_denied for denied entry."""
        store = service.get_store()
        entry = store.create("buildooor")
        store.deny(entry.device_code)

        result = await service.poll_token(
            grant_type=service.DEVICE_CODE_GRANT_TYPE,
            device_code=entry.device_code,
            client_id="buildooor",
        )

        assert result["error"] == "access_denied"

    async def test_expired_returns_expired_token(self):
        """poll_token returns expired_token for unknown/expired code."""
        result = await service.poll_token(
            grant_type=service.DEVICE_CODE_GRANT_TYPE,
            device_code="nonexistent",
            client_id="buildooor",
        )

        assert result["error"] == "expired_token"

    async def test_wrong_grant_type_returns_unsupported(self):
        """poll_token returns unsupported_grant_type for wrong type."""
        result = await service.poll_token(
            grant_type="authorization_code",
            device_code="any",
            client_id="buildooor",
        )

        assert result["error"] == "unsupported_grant_type"

    async def test_wrong_client_id_returns_expired(self):
        """poll_token returns expired_token when client_id doesn't match."""
        store = service.get_store()
        entry = store.create("buildooor")

        result = await service.poll_token(
            grant_type=service.DEVICE_CODE_GRANT_TYPE,
            device_code=entry.device_code,
            client_id="wrong-app",
        )

        assert result["error"] == "expired_token"
