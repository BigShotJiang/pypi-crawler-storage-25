"""Unit tests for the device flow domain router (HTTP layer).

Each test creates a minimal FastAPI test app with dependency overrides.
The device flow service layer is fully mocked so tests exercise only
routing, request validation, status codes, and response shapes.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.device_flow.router import device_flow_router
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_current_user,
    get_db_session,
)

# ---------------------------------------------------------------------------
# Helpers / Constants
# ---------------------------------------------------------------------------

FAKE_USER_ID = str(uuid4())
FAKE_APP_ID = str(uuid4())

_DF_SERVICE = "spaps_server_quickstart.domains.device_flow.service"


def _fake_user():
    """Return a mock authenticated user."""
    user = MagicMock()
    user.id = FAKE_USER_ID
    user.email = "user@example.com"
    user.username = "user"
    user.tier = "premium"
    user.roles = ["user"]
    user.permissions = []
    user.is_admin = False
    user.is_super_admin = False
    user.wallet_addresses = []
    return user


def _fake_application():
    """Return a mock application."""
    app = MagicMock()
    app.id = FAKE_APP_ID
    app.name = "Test App"
    return app


def _create_test_app():
    """Create a FastAPI test app with device flow router and overridden deps."""
    app = FastAPI()

    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    settings.device_flow_verification_uri = "https://example.com/verify"
    app.state.settings = settings

    install_error_handlers(app)
    app.include_router(device_flow_router)

    mock_db = AsyncMock()

    async def override_db_session():
        yield mock_db

    app.dependency_overrides[get_db_session] = override_db_session
    app.dependency_overrides[get_application] = _fake_application
    app.dependency_overrides[get_current_user] = _fake_user

    return app


@pytest.fixture
def test_app():
    return _create_test_app()


@pytest.fixture
async def client(test_app):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ===========================================================================
# POST /cli/device/authorize
# ===========================================================================


class TestAuthorize:
    @patch(f"{_DF_SERVICE}.initiate_device_flow", new_callable=AsyncMock)
    async def test_success(self, mock_initiate, client: AsyncClient):
        """POST /cli/device/authorize returns device and user codes."""
        mock_initiate.return_value = {
            "device_code": "dc_123",
            "user_code": "ABCD-EFGH",
            "verification_uri": "https://example.com/verify",
            "verification_uri_complete": "https://example.com/verify?user_code=ABCD-EFGH",
            "auth_url": "https://example.com/verify?user_code=ABCD-EFGH",
            "expires_in": 900,
            "interval": 5,
        }

        resp = await client.post(
            "/cli/device/authorize",
            json={"client_id": "buildooor"},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["device_code"] == "dc_123"
        assert data["user_code"] == "ABCD-EFGH"
        assert data["expires_in"] == 900
        assert data["interval"] == 5

    async def test_missing_client_id_returns_400(self, client: AsyncClient):
        """POST /cli/device/authorize without client_id returns 400."""
        resp = await client.post(
            "/cli/device/authorize",
            json={},
        )
        assert resp.status_code == 400

    @patch(f"{_DF_SERVICE}.initiate_device_flow", new_callable=AsyncMock)
    async def test_unknown_client_returns_400(self, mock_initiate, client: AsyncClient):
        """POST /cli/device/authorize with unknown client returns 400."""
        from spaps_server_quickstart.domains.errors import UnknownClientError

        mock_initiate.side_effect = UnknownClientError()

        resp = await client.post(
            "/cli/device/authorize",
            json={"client_id": "nonexistent"},
        )

        assert resp.status_code == 400


# ===========================================================================
# POST /cli/device/verify
# ===========================================================================


class TestVerify:
    @patch(f"{_DF_SERVICE}.verify_device", new_callable=AsyncMock)
    async def test_authorize_success(
        self,
        mock_verify,
        test_app: FastAPI,
        client: AsyncClient,
    ):
        """POST /cli/device/verify with authorize action."""
        mock_verify.return_value = {"message": "Device authorized"}

        resp = await client.post(
            "/cli/device/verify",
            json={
                "device_code": "dc_123",
                "user_code": "ABCD-EFGH",
                "action": "authorize",
            },
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["message"] == "Device authorized"
        assert mock_verify.await_args.kwargs["settings"] is test_app.state.settings

    @patch(f"{_DF_SERVICE}.verify_device", new_callable=AsyncMock)
    async def test_deny_success(self, mock_verify, client: AsyncClient):
        """POST /cli/device/verify with deny action."""
        mock_verify.return_value = {"message": "Device authorization denied"}

        resp = await client.post(
            "/cli/device/verify",
            json={
                "device_code": "dc_123",
                "user_code": "ABCD-EFGH",
                "action": "deny",
            },
        )

        assert resp.status_code == 200
        data = resp.json()
        assert "denied" in data["message"].lower()

    async def test_missing_device_code_returns_400(self, client: AsyncClient):
        """POST /cli/device/verify without device_code returns 400."""
        resp = await client.post(
            "/cli/device/verify",
            json={"user_code": "ABCD-EFGH", "action": "authorize"},
        )
        assert resp.status_code == 400

    async def test_missing_user_code_returns_400(self, client: AsyncClient):
        """POST /cli/device/verify without user_code returns 400."""
        resp = await client.post(
            "/cli/device/verify",
            json={"device_code": "dc_123", "action": "authorize"},
        )
        assert resp.status_code == 400

    async def test_invalid_action_returns_400(self, client: AsyncClient):
        """POST /cli/device/verify with invalid action returns 400."""
        resp = await client.post(
            "/cli/device/verify",
            json={
                "device_code": "dc_123",
                "user_code": "ABCD-EFGH",
                "action": "invalid",
            },
        )
        assert resp.status_code == 400

    @patch(f"{_DF_SERVICE}.verify_device", new_callable=AsyncMock)
    async def test_invalid_device_code_returns_400(self, mock_verify, client: AsyncClient):
        """POST /cli/device/verify with invalid device code returns 400."""
        from spaps_server_quickstart.domains.errors import ValidationError

        mock_verify.side_effect = ValidationError("Invalid or expired device code")

        resp = await client.post(
            "/cli/device/verify",
            json={
                "device_code": "bad_code",
                "user_code": "ABCD-EFGH",
                "action": "authorize",
            },
        )

        assert resp.status_code == 400


# ===========================================================================
# POST /cli/device/token
# ===========================================================================


class TestToken:
    @patch(f"{_DF_SERVICE}.poll_token", new_callable=AsyncMock)
    async def test_authorized_returns_tokens(self, mock_poll, client: AsyncClient):
        """POST /cli/device/token returns tokens when authorized."""
        mock_poll.return_value = {
            "access_token": "at_test",
            "refresh_token": "rt_test",
            "token_type": "Bearer",
            "expires_in": 3600,
            "user_id": FAKE_USER_ID,
        }

        resp = await client.post(
            "/cli/device/token",
            json={
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "device_code": "dc_123",
                "client_id": "buildooor",
            },
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["access_token"] == "at_test"
        assert data["token_type"] == "Bearer"

    @patch(f"{_DF_SERVICE}.poll_token", new_callable=AsyncMock)
    async def test_pending_returns_400(self, mock_poll, client: AsyncClient):
        """POST /cli/device/token returns 400 with authorization_pending."""
        mock_poll.return_value = {
            "error": "authorization_pending",
            "error_description": "The user has not yet completed authorization",
        }

        resp = await client.post(
            "/cli/device/token",
            json={
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "device_code": "dc_123",
                "client_id": "buildooor",
            },
        )

        assert resp.status_code == 400
        data = resp.json()
        assert data["error"] == "authorization_pending"

    @patch(f"{_DF_SERVICE}.poll_token", new_callable=AsyncMock)
    async def test_denied_returns_400(self, mock_poll, client: AsyncClient):
        """POST /cli/device/token returns 400 with access_denied."""
        mock_poll.return_value = {
            "error": "access_denied",
            "error_description": "The user denied the authorization request",
        }

        resp = await client.post(
            "/cli/device/token",
            json={
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "device_code": "dc_123",
                "client_id": "buildooor",
            },
        )

        assert resp.status_code == 400
        data = resp.json()
        assert data["error"] == "access_denied"

    @patch(f"{_DF_SERVICE}.poll_token", new_callable=AsyncMock)
    async def test_expired_returns_400(self, mock_poll, client: AsyncClient):
        """POST /cli/device/token returns 400 with expired_token."""
        mock_poll.return_value = {
            "error": "expired_token",
            "error_description": "Device code has expired or is invalid",
        }

        resp = await client.post(
            "/cli/device/token",
            json={
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "device_code": "expired_code",
                "client_id": "buildooor",
            },
        )

        assert resp.status_code == 400
        data = resp.json()
        assert data["error"] == "expired_token"

    @patch(f"{_DF_SERVICE}.poll_token", new_callable=AsyncMock)
    async def test_wrong_grant_type_returns_400(self, mock_poll, client: AsyncClient):
        """POST /cli/device/token with wrong grant_type returns 400."""
        mock_poll.return_value = {
            "error": "unsupported_grant_type",
            "error_description": "Expected urn:ietf:params:oauth:grant-type:device_code",
        }

        resp = await client.post(
            "/cli/device/token",
            json={
                "grant_type": "authorization_code",
                "device_code": "dc_123",
                "client_id": "buildooor",
            },
        )

        assert resp.status_code == 400
        data = resp.json()
        assert data["error"] == "unsupported_grant_type"

    async def test_missing_grant_type_returns_400(self, client: AsyncClient):
        """POST /cli/device/token without grant_type returns 400."""
        resp = await client.post(
            "/cli/device/token",
            json={"device_code": "dc_123", "client_id": "buildooor"},
        )
        assert resp.status_code == 400

    async def test_missing_device_code_returns_400(self, client: AsyncClient):
        """POST /cli/device/token without device_code returns 400."""
        resp = await client.post(
            "/cli/device/token",
            json={
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "client_id": "buildooor",
            },
        )
        assert resp.status_code == 400

    async def test_missing_client_id_returns_400(self, client: AsyncClient):
        """POST /cli/device/token without client_id returns 400."""
        resp = await client.post(
            "/cli/device/token",
            json={
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "device_code": "dc_123",
            },
        )
        assert resp.status_code == 400
