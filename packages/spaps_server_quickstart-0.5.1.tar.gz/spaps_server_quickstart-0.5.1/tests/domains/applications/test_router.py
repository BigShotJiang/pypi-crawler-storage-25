"""Unit tests for the admin / applications router (HTTP layer).

Each test creates a minimal FastAPI test app with dependency overrides
for the database session and application.  The service layer is fully
mocked so tests exercise only routing, request validation, status
codes, and response shapes.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.applications.router import router
from spaps_server_quickstart.domains.errors import DomainError, NotFoundError, ValidationError
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_current_user,
    get_db_session,
    require_super_admin_user,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SERVICE_MODULE = "spaps_server_quickstart.domains.applications.service"


def _fake_application():
    """Return a mock resolved application (simulates API-key middleware)."""
    app = MagicMock()
    app.id = uuid4()
    app.name = "Test App"
    app.slug = "test-app"
    app.description = "A test application"
    app.webhook_url = "https://example.com/webhook"
    app.allowed_origins = ["https://example.com"]
    app.settings = {"rate_limit": {"window_ms": 900000, "max_requests": 100}}
    app.whitelist_enabled = False
    return app


def _fake_super_admin():
    """Return a mock super-admin user (simulates JWT auth)."""
    user = MagicMock()
    user.id = str(uuid4())
    user.email = "superadmin@example.com"
    user.username = "superadmin"
    user.tier = "premium"
    user.roles = ["admin", "super_admin"]
    user.permissions = ["manage_applications"]
    user.is_admin = True
    user.is_super_admin = True
    user.wallet_addresses = []
    return user


def _create_test_app():
    """Create a FastAPI test app with overridden dependencies."""
    app = FastAPI()

    # Install the standard error handlers so DomainErrors produce correct status codes
    install_error_handlers(app)

    app.include_router(router)

    # Override dependencies
    mock_db = AsyncMock()
    mock_app_obj = _fake_application()

    app.dependency_overrides[get_db_session] = lambda: mock_db
    app.dependency_overrides[get_application] = lambda: mock_app_obj
    app.dependency_overrides[get_current_user] = _fake_super_admin
    app.dependency_overrides[require_super_admin_user] = _fake_super_admin

    return app, mock_db, mock_app_obj


async def _client(app: FastAPI):
    """Create an httpx async client for the given app."""
    transport = ASGITransport(app=app)
    return AsyncClient(transport=transport, base_url="http://test")


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def test_app():
    return _create_test_app()


@pytest.fixture
async def client(test_app):
    app, _, _ = test_app
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ---------------------------------------------------------------------------
# Tests: POST /admin/create-app
# ---------------------------------------------------------------------------


class TestCreateApp:
    @patch(f"{_SERVICE_MODULE}.create_application_with_keys", new_callable=AsyncMock)
    async def test_success(self, mock_create):
        """POST /admin/create-app returns 201 with application and api_key."""
        mock_app = MagicMock()
        mock_app.id = uuid4()
        mock_app.name = "New App"
        mock_app.slug = "new-app"
        mock_app.description = "My new application"
        mock_app.webhook_url = None
        mock_app.allowed_origins = None
        mock_app.settings = {
            "supported_chains": ["solana", "ethereum"],
            "allow_email_auth": True,
            "allow_wallet_auth": True,
            "allow_magic_link": True,
            "stripe_enabled": False,
            "rate_limit": {"window_ms": 900000, "max_requests": 100},
        }
        mock_app.created_at = datetime.now(UTC)

        mock_create.return_value = {
            "application": mock_app,
            "api_key": "spaps_sec_fakesecretkey",
            "warning": "Store this API key securely. It will not be shown again.",
        }

        app, _, _ = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/admin/create-app",
                json={"name": "New App", "slug": "new-app", "description": "My new application"},
            )

        assert resp.status_code == 201
        data = resp.json()
        assert data["application"]["name"] == "New App"
        assert data["application"]["slug"] == "new-app"
        assert data["api_key"] == "spaps_sec_fakesecretkey"
        assert "warning" in data
        mock_create.assert_awaited_once()

    @patch(f"{_SERVICE_MODULE}.create_application_with_keys", new_callable=AsyncMock)
    async def test_duplicate_name_returns_400(self, mock_create):
        """POST /admin/create-app returns 400 for duplicate name."""
        mock_create.side_effect = ValidationError("Application with name 'Existing' already exists")

        app, _, _ = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/admin/create-app",
                json={"name": "Existing", "slug": "existing"},
            )

        assert resp.status_code == 400
        data = resp.json()
        assert data["success"] is False
        assert data["error"]["code"] == "VALIDATION_ERROR"

    @patch(f"{_SERVICE_MODULE}.create_application_with_keys", new_callable=AsyncMock)
    async def test_duplicate_slug_returns_400(self, mock_create):
        """POST /admin/create-app returns 400 for duplicate slug."""
        mock_create.side_effect = ValidationError("Application with slug 'existing' already exists")

        app, _, _ = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/admin/create-app",
                json={"name": "New Name", "slug": "existing"},
            )

        assert resp.status_code == 400
        data = resp.json()
        assert data["error"]["code"] == "VALIDATION_ERROR"

    async def test_invalid_slug_returns_400(self):
        """POST /admin/create-app returns 400 for invalid slug format."""
        app, _, _ = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/admin/create-app",
                json={"name": "Test", "slug": "Invalid Slug!"},
            )

        assert resp.status_code == 400

    async def test_missing_name_returns_400(self):
        """POST /admin/create-app returns 400 when name is missing."""
        app, _, _ = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/admin/create-app",
                json={"slug": "my-app"},
            )

        assert resp.status_code == 400

    async def test_missing_slug_returns_400(self):
        """POST /admin/create-app returns 400 when slug is missing."""
        app, _, _ = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/admin/create-app",
                json={"name": "My App"},
            )

        assert resp.status_code == 400

    async def test_requires_super_admin(self):
        """POST /admin/create-app returns 403 when user is not super-admin.

        This locks in the operator-only invariant for key provisioning.
        """
        from spaps_server_quickstart.middleware.jwt_auth import AuthenticatedUser

        app, _, _ = _create_test_app()

        # Use the real dependency to ensure the router is wired to SuperAdminUser.
        if require_super_admin_user in app.dependency_overrides:
            del app.dependency_overrides[require_super_admin_user]

        # Override get_current_user to a regular admin (not super-admin).
        app.dependency_overrides[get_current_user] = lambda: AuthenticatedUser(
            id="admin-1",
            email="admin@example.com",
            roles=["admin"],
            permissions=["access_admin"],
            is_admin=True,
            is_super_admin=False,
        )

        async with await _client(app) as c:
            resp = await c.post(
                "/admin/create-app",
                json={"name": "New App", "slug": "new-app"},
            )

        assert resp.status_code == 403
        body = resp.json()
        assert body["success"] is False
        assert body["error"]["code"] == "FORBIDDEN"

    @patch(f"{_SERVICE_MODULE}.create_application_with_keys", new_callable=AsyncMock)
    async def test_creation_failure_returns_500(self, mock_create):
        """POST /admin/create-app returns 500 on unexpected failure."""
        mock_create.side_effect = DomainError(
            code="APPLICATION_CREATION_FAILED",
            message="Failed to create application",
            status_code=500,
        )

        app, _, _ = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/admin/create-app",
                json={"name": "New App", "slug": "new-app"},
            )

        assert resp.status_code == 500
        data = resp.json()
        assert data["error"]["code"] == "APPLICATION_CREATION_FAILED"

    @patch(f"{_SERVICE_MODULE}.create_application_with_keys", new_callable=AsyncMock)
    async def test_with_all_optional_fields(self, mock_create):
        """POST /admin/create-app accepts all optional fields."""
        mock_app = MagicMock()
        mock_app.id = uuid4()
        mock_app.name = "Full App"
        mock_app.slug = "full-app"
        mock_app.description = "Fully described"
        mock_app.webhook_url = "https://hooks.example.com"
        mock_app.allowed_origins = ["https://example.com", "https://app.example.com"]
        mock_app.settings = {"custom": True}
        mock_app.created_at = datetime.now(UTC)

        mock_create.return_value = {
            "application": mock_app,
            "api_key": "spaps_sec_fullkey",
            "warning": "Store this API key securely. It will not be shown again.",
        }

        app, _, _ = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/admin/create-app",
                json={
                    "name": "Full App",
                    "slug": "full-app",
                    "description": "Fully described",
                    "webhook_url": "https://hooks.example.com",
                    "allowed_origins": ["https://example.com", "https://app.example.com"],
                    "settings": {"custom": True},
                },
            )

        assert resp.status_code == 201
        data = resp.json()
        assert data["application"]["description"] == "Fully described"
        assert data["application"]["webhook_url"] == "https://hooks.example.com"
        assert len(data["application"]["allowed_origins"]) == 2

    @patch(f"{_SERVICE_MODULE}.create_application_with_keys", new_callable=AsyncMock)
    async def test_accepts_blueprint_fields(self, mock_create):
        """POST /admin/create-app forwards blueprint inputs to the service layer."""
        mock_app = MagicMock()
        mock_app.id = uuid4()
        mock_app.name = "Blueprint App"
        mock_app.slug = "blueprint-app"
        mock_app.description = None
        mock_app.webhook_url = None
        mock_app.allowed_origins = ["https://app.example.com"]
        mock_app.settings = {
            "application_blueprint": {
                "key": "browser_auth",
                "publishable_scopes": ["auth", "sessions", "docs"],
            }
        }
        mock_app.created_at = datetime.now(UTC)

        mock_create.return_value = {
            "application": mock_app,
            "api_key": "spaps_sec_blueprintkey",
            "warning": "Store this API key securely. It will not be shown again.",
        }

        app, mock_db, _ = _create_test_app()
        inline_blueprint = {
            "publishable_scopes": ["auth", "sessions"],
            "settings": {"stripe_enabled": True},
            "default_policies": [
                {
                    "name": "allow-authenticated-users",
                    "effect": "allow",
                    "conditions": {"account_age_days": {"gte": 0}},
                }
            ],
        }
        async with await _client(app) as c:
            resp = await c.post(
                "/admin/create-app",
                json={
                    "name": "Blueprint App",
                    "slug": "blueprint-app",
                    "allowed_origins": ["https://app.example.com"],
                    "blueprint_key": "browser_auth",
                    "blueprint": inline_blueprint,
                },
            )

        assert resp.status_code == 201
        mock_create.assert_awaited_once_with(
            mock_db,
            name="Blueprint App",
            slug="blueprint-app",
            description=None,
            webhook_url=None,
            allowed_origins=["https://app.example.com"],
            settings=None,
            blueprint_key="browser_auth",
            blueprint=inline_blueprint,
        )


# ---------------------------------------------------------------------------
# Tests: POST /admin/rotate-api-key/{app_id}
# ---------------------------------------------------------------------------


class TestRotateApiKey:
    @patch(f"{_SERVICE_MODULE}.rotate_api_key", new_callable=AsyncMock)
    async def test_success(self, mock_rotate):
        """POST /admin/rotate-api-key/{app_id} returns 200 with new key."""
        mock_rotate.return_value = {
            "api_key": "spaps_newkey123",
            "warning": "Store this new API key securely. The old key is now invalid.",
        }

        app, _, _ = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post("/admin/rotate-api-key/some-app-id")

        assert resp.status_code == 200
        data = resp.json()
        assert data["api_key"] == "spaps_newkey123"
        assert "warning" in data
        mock_rotate.assert_awaited_once_with(
            # The mock_db is passed as the first positional arg
            app.dependency_overrides[get_db_session](),
            "some-app-id",
        )

    @patch(f"{_SERVICE_MODULE}.rotate_api_key", new_callable=AsyncMock)
    async def test_not_found_returns_404(self, mock_rotate):
        """POST /admin/rotate-api-key/{app_id} returns 404 when app not found."""
        mock_rotate.side_effect = NotFoundError("Application not-found-id not found")

        app, _, _ = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post("/admin/rotate-api-key/not-found-id")

        assert resp.status_code == 404
        data = resp.json()
        assert data["error"]["code"] == "NOT_FOUND"

    @patch(f"{_SERVICE_MODULE}.rotate_api_key", new_callable=AsyncMock)
    async def test_rotation_failure_returns_500(self, mock_rotate):
        """POST /admin/rotate-api-key/{app_id} returns 500 on unexpected failure."""
        mock_rotate.side_effect = DomainError(
            code="API_KEY_ROTATION_FAILED",
            message="Failed to rotate API key",
            status_code=500,
        )

        app, _, _ = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post("/admin/rotate-api-key/some-app-id")

        assert resp.status_code == 500
        data = resp.json()
        assert data["error"]["code"] == "API_KEY_ROTATION_FAILED"


# ---------------------------------------------------------------------------
# Tests: GET /admin/apps
# ---------------------------------------------------------------------------


class TestListApps:
    async def test_returns_requesting_application(self):
        """GET /admin/apps returns the requesting application only."""
        app, _, mock_app_obj = _create_test_app()
        async with await _client(app) as c:
            resp = await c.get("/admin/apps")

        assert resp.status_code == 200
        data = resp.json()
        assert data["application"]["name"] == mock_app_obj.name
        assert data["application"]["slug"] == mock_app_obj.slug
        assert data["application"]["id"] == str(mock_app_obj.id)
        assert "note" in data
        assert "super admin" in data["note"].lower()

    async def test_response_excludes_sensitive_fields(self):
        """GET /admin/apps does not expose key hashes."""
        app, _, _ = _create_test_app()
        async with await _client(app) as c:
            resp = await c.get("/admin/apps")

        data = resp.json()
        app_data = data["application"]
        assert "api_key" not in app_data
        assert "publishable_key_hash" not in app_data
        assert "secret_key_hash" not in app_data


# ---------------------------------------------------------------------------
# Tests: Service layer — key generation helpers
# ---------------------------------------------------------------------------


class TestKeyGenerationHelpers:
    """Test the key generation and hashing functions."""

    def test_generate_api_key_prefix(self):
        from spaps_server_quickstart.domains.applications.service import generate_api_key

        key = generate_api_key()
        assert key.startswith("spaps_")
        # 32 hex bytes = 64 chars + prefix
        assert len(key) == len("spaps_") + 64

    def test_generate_publishable_key_prefix(self):
        from spaps_server_quickstart.domains.applications.service import generate_publishable_key

        key = generate_publishable_key()
        assert key.startswith("spaps_pub_")
        assert len(key) == len("spaps_pub_") + 64

    def test_generate_secret_key_prefix(self):
        from spaps_server_quickstart.domains.applications.service import generate_secret_key

        key = generate_secret_key()
        assert key.startswith("spaps_sec_")
        assert len(key) == len("spaps_sec_") + 64

    def test_hash_key_is_deterministic(self):
        from spaps_server_quickstart.domains.applications.service import hash_key

        h1 = hash_key("test-key")
        h2 = hash_key("test-key")
        assert h1 == h2

    def test_hash_key_is_sha256(self):
        import hashlib

        from spaps_server_quickstart.domains.applications.service import hash_key

        expected = hashlib.sha256(b"test-key").hexdigest()
        assert hash_key("test-key") == expected

    def test_keys_are_unique(self):
        from spaps_server_quickstart.domains.applications.service import generate_api_key

        keys = {generate_api_key() for _ in range(10)}
        assert len(keys) == 10


# ---------------------------------------------------------------------------
# Tests: Service layer — create_application_with_keys
# ---------------------------------------------------------------------------


class TestCreateApplicationWithKeysService:
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_name",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_slug",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.applications.repository.create_application",
        new_callable=AsyncMock,
    )
    async def test_success(self, mock_create, mock_slug, mock_name):
        mock_name.return_value = None
        mock_slug.return_value = None

        mock_app = MagicMock()
        mock_app.id = uuid4()
        mock_app.name = "Test"
        mock_app.slug = "test"
        mock_app.description = None
        mock_app.settings = {}
        mock_app.created_at = datetime.now(UTC)
        mock_create.return_value = mock_app

        from spaps_server_quickstart.domains.applications.service import (
            create_application_with_keys,
        )

        db = AsyncMock()
        result = await create_application_with_keys(db, name="Test", slug="test")

        assert result["application"] is mock_app
        assert result["api_key"].startswith("spaps_sec_")
        assert "warning" in result
        mock_create.assert_awaited_once()

    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_name",
        new_callable=AsyncMock,
    )
    async def test_duplicate_name_raises_validation(self, mock_name):
        mock_name.return_value = MagicMock()  # existing app

        from spaps_server_quickstart.domains.applications.service import (
            create_application_with_keys,
        )

        db = AsyncMock()
        with pytest.raises(ValidationError):
            await create_application_with_keys(db, name="Dup", slug="dup")

    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_name",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_slug",
        new_callable=AsyncMock,
    )
    async def test_duplicate_slug_raises_validation(self, mock_slug, mock_name):
        mock_name.return_value = None
        mock_slug.return_value = MagicMock()  # existing app

        from spaps_server_quickstart.domains.applications.service import (
            create_application_with_keys,
        )

        db = AsyncMock()
        with pytest.raises(ValidationError):
            await create_application_with_keys(db, name="New", slug="existing")

    async def test_missing_name_raises_validation(self):
        from spaps_server_quickstart.domains.applications.service import (
            create_application_with_keys,
        )

        db = AsyncMock()
        with pytest.raises(ValidationError):
            await create_application_with_keys(db, name="", slug="test")

    async def test_missing_slug_raises_validation(self):
        from spaps_server_quickstart.domains.applications.service import (
            create_application_with_keys,
        )

        db = AsyncMock()
        with pytest.raises(ValidationError):
            await create_application_with_keys(db, name="Test", slug="")

    @patch(
        "spaps_server_quickstart.domains.applications.service.policy_repo.create_policy",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_name",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_slug",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.applications.repository.create_application",
        new_callable=AsyncMock,
    )
    async def test_blueprint_compiles_settings_and_seeds_policies(
        self,
        mock_create,
        mock_slug,
        mock_name,
        mock_create_policy,
    ):
        mock_name.return_value = None
        mock_slug.return_value = None

        mock_app = MagicMock()
        mock_app.id = uuid4()
        mock_app.name = "Blueprint"
        mock_app.slug = "blueprint"
        mock_app.description = None
        mock_app.allowed_origins = ["https://app.example.com"]
        mock_app.settings = {}
        mock_app.created_at = datetime.now(UTC)
        mock_create.return_value = mock_app

        from spaps_server_quickstart.domains.applications.service import (
            create_application_with_keys,
        )

        db = AsyncMock()
        inline_blueprint = {
            "publishable_scopes": ["auth", "docs"],
            "settings": {"stripe_enabled": True, "feature_flags": {"beta": True}},
            "default_policies": [
                {
                    "name": "allow-new-users",
                    "description": "Example seeded policy",
                    "effect": "allow",
                    "conditions": {"account_age_days": {"gte": 0}},
                    "priority": 25,
                    "metadata": {"source": "test"},
                }
            ],
        }

        result = await create_application_with_keys(
            db,
            name="Blueprint",
            slug="blueprint",
            allowed_origins=["https://app.example.com"],
            blueprint_key="browser_auth",
            blueprint=inline_blueprint,
        )

        assert result["application"] is mock_app
        create_kwargs = mock_create.await_args.kwargs
        assert create_kwargs["allowed_origins"] == ["https://app.example.com"]
        assert create_kwargs["settings"]["stripe_enabled"] is True
        assert create_kwargs["settings"]["feature_flags"] == {"beta": True}
        assert create_kwargs["settings"]["application_blueprint"]["key"] == "browser_auth"
        assert create_kwargs["settings"]["application_blueprint"]["publishable_scopes"] == [
            "auth",
            "docs",
        ]
        assert (
            create_kwargs["settings"]["publishable_key_access"]["allowed_patterns"]
            == ["/api/auth/login", "/api/auth/register", "/api/auth/refresh", "/api/auth/logout",
                "/api/auth/nonce", "/api/auth/wallet-sign-in", "/api/auth/magic-link",
                "/api/auth/verify-magic-link", "/api/auth/password-reset",
                "/api/auth/reset-password-confirm", "/api/auth/set-password", "/api/auth/user",
                "/api/auth/solana/", "/api/auth/ethereum/", "/docs", "/api-docs", "/api/docs/"]
        )
        assert {
            "path": "/api/auth/login",
            "methods": ["POST"],
            "match": "exact",
        } in create_kwargs["settings"]["publishable_key_access"]["allowed_routes"]
        assert {
            "path": "/api/auth/user",
            "methods": ["GET"],
            "match": "exact",
        } in create_kwargs["settings"]["publishable_key_access"]["allowed_routes"]
        mock_create_policy.assert_awaited_once()
        policy_kwargs = mock_create_policy.await_args.kwargs
        assert policy_kwargs["application_id"] == mock_app.id
        assert policy_kwargs["name"] == "allow-new-users"

    async def test_unknown_blueprint_raises_validation(self):
        from spaps_server_quickstart.domains.applications.service import (
            create_application_with_keys,
        )

        db = AsyncMock()

        with pytest.raises(ValidationError, match="Unknown application blueprint"):
            await create_application_with_keys(
                db,
                name="Blueprint",
                slug="blueprint",
                blueprint_key="does-not-exist",
            )

    @patch(
        "spaps_server_quickstart.domains.applications.service.policy_repo.create_policy",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_name",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_slug",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.applications.repository.create_application",
        new_callable=AsyncMock,
    )
    async def test_golden_path_blueprint_seeds_paid_access_policy(
        self,
        mock_create,
        mock_slug,
        mock_name,
        mock_create_policy,
    ):
        mock_name.return_value = None
        mock_slug.return_value = None

        mock_app = MagicMock()
        mock_app.id = uuid4()
        mock_app.name = "Golden Path"
        mock_app.slug = "golden-path"
        mock_app.description = None
        mock_app.allowed_origins = ["https://app.example.com"]
        mock_app.settings = {}
        mock_app.created_at = datetime.now(UTC)
        mock_create.return_value = mock_app

        from spaps_server_quickstart.domains.applications.service import (
            create_application_with_keys,
        )

        db = AsyncMock()

        result = await create_application_with_keys(
            db,
            name="Golden Path",
            slug="golden-path",
            allowed_origins=["https://app.example.com"],
            blueprint_key="golden_path",
        )

        assert result["application"] is mock_app
        create_kwargs = mock_create.await_args.kwargs
        assert create_kwargs["settings"]["stripe_enabled"] is True
        assert create_kwargs["settings"]["feature_flags"] == {
            "golden_path_reference": True,
        }
        assert create_kwargs["settings"]["application_blueprint"]["key"] == "golden_path"
        assert create_kwargs["settings"]["application_blueprint"]["journeys"][1] == {
            "key": "checkout_projects_paid_access",
            "name": "Checkout projects paid access",
            "description": "A Stripe checkout or subscription event projects the paid_access entitlement for the application user.",
            "publishable_scopes": ["stripe_consumer", "entitlements_read"],
            "entitlement_key": "paid_access",
            "policy_name": "access-paid-features",
        }
        assert (
            "docs/downstream_apps/golden-path-reference/README.md"
            in create_kwargs["settings"]["application_blueprint"]["docs"]
        )
        mock_create_policy.assert_awaited_once()
        policy_kwargs = mock_create_policy.await_args.kwargs
        assert policy_kwargs["application_id"] == mock_app.id
        assert policy_kwargs["name"] == "access-paid-features"
        assert policy_kwargs["conditions"] == {
            "any": [
                {"has_role": {"role": "admin"}},
                {"has_entitlement": {"key": "paid_access"}},
            ]
        }
        assert policy_kwargs["metadata_"] == {
            "source": "application-blueprint",
            "blueprint_key": "golden_path",
            "journey": "checkout_projects_paid_access",
        }


# ---------------------------------------------------------------------------
# Tests: Service layer — rotate_api_key
# ---------------------------------------------------------------------------


class TestRotateApiKeyService:
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_id",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.applications.repository.update_application",
        new_callable=AsyncMock,
    )
    async def test_success(self, mock_update, mock_get):
        mock_get.return_value = MagicMock()
        mock_update.return_value = MagicMock()

        from spaps_server_quickstart.domains.applications.service import rotate_api_key

        db = AsyncMock()
        result = await rotate_api_key(db, "app-id-123")

        assert result["api_key"].startswith("spaps_")
        assert "warning" in result

    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_id",
        new_callable=AsyncMock,
    )
    async def test_not_found_raises(self, mock_get):
        mock_get.return_value = None

        from spaps_server_quickstart.domains.applications.service import rotate_api_key

        db = AsyncMock()
        with pytest.raises(NotFoundError):
            await rotate_api_key(db, "missing-id")


# ---------------------------------------------------------------------------
# Tests: Service layer — rotate_typed_key
# ---------------------------------------------------------------------------


class TestRotateTypedKeyService:
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_id",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.applications.repository.update_application",
        new_callable=AsyncMock,
    )
    async def test_rotate_publishable(self, mock_update, mock_get):
        mock_get.return_value = MagicMock()
        mock_update.return_value = MagicMock()

        from spaps_server_quickstart.domains.applications.service import rotate_typed_key

        db = AsyncMock()
        result = await rotate_typed_key(db, "app-id", "publishable")

        assert result["key"].startswith("spaps_pub_")
        assert "publishable" in result["warning"]

    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_id",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.applications.repository.update_application",
        new_callable=AsyncMock,
    )
    async def test_rotate_secret(self, mock_update, mock_get):
        mock_get.return_value = MagicMock()
        mock_update.return_value = MagicMock()

        from spaps_server_quickstart.domains.applications.service import rotate_typed_key

        db = AsyncMock()
        result = await rotate_typed_key(db, "app-id", "secret")

        assert result["key"].startswith("spaps_sec_")
        assert "secret" in result["warning"]

    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_id",
        new_callable=AsyncMock,
    )
    async def test_not_found_raises(self, mock_get):
        mock_get.return_value = None

        from spaps_server_quickstart.domains.applications.service import rotate_typed_key

        db = AsyncMock()
        with pytest.raises(NotFoundError):
            await rotate_typed_key(db, "missing-id", "publishable")


# ---------------------------------------------------------------------------
# Tests: Service layer — delete_application
# ---------------------------------------------------------------------------


class TestDeleteApplicationService:
    @patch(
        "spaps_server_quickstart.domains.applications.repository.delete_application",
        new_callable=AsyncMock,
    )
    async def test_success(self, mock_delete):
        mock_delete.return_value = True

        from spaps_server_quickstart.domains.applications.service import delete_application

        db = AsyncMock()
        result = await delete_application(db, "app-id")
        assert result is True

    @patch(
        "spaps_server_quickstart.domains.applications.repository.delete_application",
        new_callable=AsyncMock,
    )
    async def test_not_found_raises(self, mock_delete):
        mock_delete.return_value = False

        from spaps_server_quickstart.domains.applications.service import delete_application

        db = AsyncMock()
        with pytest.raises(NotFoundError):
            await delete_application(db, "missing-id")
