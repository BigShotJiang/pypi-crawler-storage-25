"""Unit tests for the audit domain service layer.

The repository layer is mocked so tests exercise only business logic,
error handling, and data transformation.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

_AUDIT_REPO = "spaps_server_quickstart.domains.audit.repository"


def _mock_audit_log(**overrides):
    """Create a mock AuditLog model instance."""
    log = MagicMock()
    log.id = overrides.get("id", uuid4())
    log.admin_user_id = overrides.get("admin_user_id", uuid4())
    log.admin_email = overrides.get("admin_email", "admin@example.com")
    log.action = overrides.get("action", "create_product")
    log.resource_type = overrides.get("resource_type", "product")
    log.resource_id = overrides.get("resource_id", "prod_123")
    log.resource_data = overrides.get("resource_data", {"name": "Test"})
    log.error_details = overrides.get("error_details", None)
    log.ip_address = overrides.get("ip_address", "127.0.0.1")
    log.user_agent = overrides.get("user_agent", "TestAgent/1.0")
    log.application_id = overrides.get("application_id", uuid4())
    log.severity = overrides.get("severity", "info")
    log.timestamp = overrides.get("timestamp", datetime.now(UTC))
    return log


# ===========================================================================
# log_action
# ===========================================================================


class TestLogAction:
    @patch(f"{_AUDIT_REPO}.create_audit_log", new_callable=AsyncMock)
    async def test_creates_log_entry(self, mock_create):
        """log_action creates an audit log entry."""
        from spaps_server_quickstart.domains.audit.service import log_action

        mock_log = _mock_audit_log(action="create_product")
        mock_create.return_value = mock_log

        db = AsyncMock()
        result = await log_action(
            db,
            admin_user_id=mock_log.admin_user_id,
            admin_email="admin@example.com",
            action="create_product",
            resource_type="product",
            resource_id="prod_123",
            severity="info",
        )

        mock_create.assert_called_once()
        assert result["action"] == "create_product"
        assert result["severity"] == "info"
        assert result["admin_email"] == "admin@example.com"

    @patch(f"{_AUDIT_REPO}.create_audit_log", new_callable=AsyncMock)
    async def test_returns_serializable_dict(self, mock_create):
        """log_action returns a dict with string UUIDs."""
        from spaps_server_quickstart.domains.audit.service import log_action

        mock_log = _mock_audit_log()
        mock_create.return_value = mock_log

        db = AsyncMock()
        result = await log_action(
            db,
            action="test_action",
        )

        assert isinstance(result["id"], str)
        assert isinstance(result["timestamp"], str)

    @patch(f"{_AUDIT_REPO}.create_audit_log", new_callable=AsyncMock)
    async def test_with_resource_data(self, mock_create):
        """log_action passes resource_data through."""
        from spaps_server_quickstart.domains.audit.service import log_action

        resource_data = {"product_id": "prod_123", "price": 99.99}
        mock_log = _mock_audit_log(resource_data=resource_data)
        mock_create.return_value = mock_log

        db = AsyncMock()
        result = await log_action(
            db,
            action="create_product",
            resource_data=resource_data,
        )

        assert result["resource_data"] == resource_data


# ===========================================================================
# log_failed_action
# ===========================================================================


class TestLogFailedAction:
    @patch(f"{_AUDIT_REPO}.create_audit_log", new_callable=AsyncMock)
    async def test_creates_log_with_error_details(self, mock_create):
        """log_failed_action creates a log entry with error details."""
        from spaps_server_quickstart.domains.audit.service import log_failed_action

        error_details = {"code": "VALIDATION_ERROR", "message": "Invalid input"}
        mock_log = _mock_audit_log(
            error_details=error_details,
            severity="warning",
        )
        mock_create.return_value = mock_log

        db = AsyncMock()
        result = await log_failed_action(
            db,
            action="create_product",
            error_details=error_details,
            severity="warning",
        )

        mock_create.assert_called_once()
        assert result["error_details"] == error_details
        assert result["severity"] == "warning"

    @patch(f"{_AUDIT_REPO}.create_audit_log", new_callable=AsyncMock)
    async def test_default_severity_is_warning(self, mock_create):
        """log_failed_action defaults to warning severity."""
        from spaps_server_quickstart.domains.audit.service import log_failed_action

        mock_log = _mock_audit_log(severity="warning")
        mock_create.return_value = mock_log

        db = AsyncMock()
        await log_failed_action(db, action="test")

        call_kwargs = mock_create.call_args
        assert call_kwargs.kwargs.get("severity") == "warning" or \
            (len(call_kwargs.args) > 1 or "severity" in str(call_kwargs))


# ===========================================================================
# get_admin_logs
# ===========================================================================


class TestGetAdminLogs:
    @patch(f"{_AUDIT_REPO}.list_logs_by_admin", new_callable=AsyncMock)
    async def test_returns_logs_and_total(self, mock_list):
        """get_admin_logs returns logs dict and total count."""
        from spaps_server_quickstart.domains.audit.service import get_admin_logs

        admin_id = uuid4()
        mock_logs = [_mock_audit_log(), _mock_audit_log()]
        mock_list.return_value = (mock_logs, 2)

        db = AsyncMock()
        result = await get_admin_logs(db, current_admin_user_id=admin_id)

        assert result["total"] == 2
        assert len(result["logs"]) == 2

    @patch(f"{_AUDIT_REPO}.list_logs_by_admin", new_callable=AsyncMock)
    async def test_empty_result(self, mock_list):
        """get_admin_logs returns empty list when no logs exist."""
        from spaps_server_quickstart.domains.audit.service import get_admin_logs

        mock_list.return_value = ([], 0)

        db = AsyncMock()
        result = await get_admin_logs(db, current_admin_user_id=uuid4())

        assert result["total"] == 0
        assert result["logs"] == []

    @patch(f"{_AUDIT_REPO}.list_logs_by_admin", new_callable=AsyncMock)
    async def test_passes_filters_through(self, mock_list):
        """get_admin_logs passes action and resource_type filters."""
        from spaps_server_quickstart.domains.audit.service import get_admin_logs

        mock_list.return_value = ([], 0)

        db = AsyncMock()
        admin_id = uuid4()
        await get_admin_logs(
            db,
            current_admin_user_id=admin_id,
            action="create_product",
            resource_type="product",
            limit=25,
            offset=10,
        )

        mock_list.assert_called_once_with(
            db,
            admin_id,
            action="create_product",
            resource_type="product",
            limit=25,
            offset=10,
        )

    @patch(f"{_AUDIT_REPO}.list_logs_by_admin", new_callable=AsyncMock)
    async def test_allows_explicit_self_scope(self, mock_list):
        """get_admin_logs allows an explicit self-scoped admin_user_id."""
        from spaps_server_quickstart.domains.audit.service import get_admin_logs

        admin_id = uuid4()
        mock_list.return_value = ([], 0)

        db = AsyncMock()
        await get_admin_logs(
            db,
            current_admin_user_id=admin_id,
            requested_admin_user_id=admin_id,
        )

        mock_list.assert_called_once_with(
            db,
            admin_id,
            action=None,
            resource_type=None,
            limit=50,
            offset=0,
        )

    @patch(f"{_AUDIT_REPO}.list_logs_by_admin", new_callable=AsyncMock)
    async def test_rejects_cross_admin_scope(self, mock_list):
        """get_admin_logs rejects a normal admin querying another admin's logs."""
        from spaps_server_quickstart.domains.audit.service import get_admin_logs
        from spaps_server_quickstart.domains.errors import ForbiddenError

        db = AsyncMock()
        with pytest.raises(ForbiddenError, match="own audit logs"):
            await get_admin_logs(
                db,
                current_admin_user_id=uuid4(),
                requested_admin_user_id=uuid4(),
            )

        mock_list.assert_not_called()


# ===========================================================================
# get_all_logs
# ===========================================================================


class TestGetAllLogs:
    @patch(f"{_AUDIT_REPO}.list_all_logs", new_callable=AsyncMock)
    async def test_returns_all_logs(self, mock_list):
        """get_all_logs returns logs from all admins."""
        from spaps_server_quickstart.domains.audit.service import get_all_logs

        mock_logs = [_mock_audit_log(), _mock_audit_log(), _mock_audit_log()]
        mock_list.return_value = (mock_logs, 3)

        db = AsyncMock()
        result = await get_all_logs(db)

        assert result["total"] == 3
        assert len(result["logs"]) == 3

    @patch(f"{_AUDIT_REPO}.list_all_logs", new_callable=AsyncMock)
    async def test_passes_filters(self, mock_list):
        """get_all_logs passes all filters through."""
        from spaps_server_quickstart.domains.audit.service import get_all_logs

        mock_list.return_value = ([], 0)

        db = AsyncMock()
        admin_id = uuid4()
        await get_all_logs(
            db,
            admin_user_id=admin_id,
            action="delete_product",
            resource_type="product",
            limit=100,
            offset=50,
        )

        mock_list.assert_called_once_with(
            db,
            admin_user_id=admin_id,
            action="delete_product",
            resource_type="product",
            limit=100,
            offset=50,
        )


# ===========================================================================
# retention_cleanup
# ===========================================================================


class TestRetentionCleanup:
    @patch(f"{_AUDIT_REPO}.purge_old_archives", new_callable=AsyncMock)
    @patch(f"{_AUDIT_REPO}.archive_old_logs", new_callable=AsyncMock)
    async def test_archives_and_purges(self, mock_archive, mock_purge):
        """retention_cleanup archives old logs and purges old archives."""
        from spaps_server_quickstart.domains.audit.service import retention_cleanup

        mock_archive.return_value = 5
        mock_purge.return_value = 3

        db = AsyncMock()
        result = await retention_cleanup(db, retention_days=90, archive_retention_days=365)

        assert result["archived"] == 5
        assert result["purged"] == 3
        mock_archive.assert_called_once()
        mock_purge.assert_called_once()

    @patch(f"{_AUDIT_REPO}.purge_old_archives", new_callable=AsyncMock)
    @patch(f"{_AUDIT_REPO}.archive_old_logs", new_callable=AsyncMock)
    async def test_no_work_to_do(self, mock_archive, mock_purge):
        """retention_cleanup returns zeros when nothing to process."""
        from spaps_server_quickstart.domains.audit.service import retention_cleanup

        mock_archive.return_value = 0
        mock_purge.return_value = 0

        db = AsyncMock()
        result = await retention_cleanup(db)

        assert result["archived"] == 0
        assert result["purged"] == 0

    @patch(f"{_AUDIT_REPO}.purge_old_archives", new_callable=AsyncMock)
    @patch(f"{_AUDIT_REPO}.archive_old_logs", new_callable=AsyncMock)
    async def test_uses_custom_retention_days(self, mock_archive, mock_purge):
        """retention_cleanup uses custom retention days."""
        from spaps_server_quickstart.domains.audit.service import retention_cleanup

        mock_archive.return_value = 0
        mock_purge.return_value = 0

        db = AsyncMock()
        await retention_cleanup(db, retention_days=30, archive_retention_days=180)

        # Verify the cutoff dates are calculated correctly
        archive_cutoff = mock_archive.call_args[0][1]
        purge_cutoff = mock_purge.call_args[0][1]

        now = datetime.now(UTC)
        expected_archive_delta = timedelta(days=30)
        expected_purge_delta = timedelta(days=180)

        # Allow 1 second of tolerance
        assert abs((now - archive_cutoff) - expected_archive_delta) < timedelta(seconds=2)
        assert abs((now - purge_cutoff) - expected_purge_delta) < timedelta(seconds=2)
