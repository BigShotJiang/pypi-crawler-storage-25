"""Unit tests for the Stripe domain repository layer.

Tests repository functions with mocked AsyncSession.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4


from spaps_server_quickstart.domains.stripe import repository as repo
from spaps_server_quickstart.domains.stripe.models import (
    CheckoutSession,
    PaymentHistory,
    StripeCustomer,
    StripePayment,
    StripePrice,
    StripeProduct,
    Subscription,
)


FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()


def _mock_db():
    """Create a mocked AsyncSession."""
    db = AsyncMock()
    db.add = MagicMock()
    db.flush = AsyncMock()
    db.refresh = AsyncMock()
    return db


# ===========================================================================
# Products
# ===========================================================================


class TestGetProduct:
    async def test_found(self):
        db = _mock_db()
        product = MagicMock(spec=StripeProduct)
        product.stripe_product_id = "prod_test"
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = product
        db.execute = AsyncMock(return_value=result_mock)
        result = await repo.get_product(db, "prod_test")
        assert result is product

    async def test_not_found(self):
        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=result_mock)
        result = await repo.get_product(db, "prod_nonexistent")
        assert result is None


class TestCreateProduct:
    async def test_success(self):
        db = _mock_db()
        result = await repo.create_product(
            db,
            stripe_product_id="prod_new",
            application_id=FAKE_APP_ID,
            name="Test Product",
            description="Description",
        )
        db.add.assert_called_once()
        db.flush.assert_called_once()
        db.refresh.assert_called_once()


class TestListProducts:
    async def test_success(self):
        db = _mock_db()
        products = [MagicMock(spec=StripeProduct)]
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = products
        result_mock = MagicMock()
        result_mock.scalars.return_value = scalars_mock
        db.execute = AsyncMock(return_value=result_mock)
        result = await repo.list_products(db, FAKE_APP_ID)
        assert len(result) == 1


class TestArchiveProduct:
    async def test_success(self):
        db = _mock_db()
        product = MagicMock(spec=StripeProduct)
        product.active = True

        # Mock get_product inside archive
        with patch.object(repo, "get_product", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = product
            result = await repo.archive_product(db, "prod_test")
            assert result is product
            assert product.active is False


class TestUpdateProduct:
    async def test_success(self):
        db = _mock_db()
        product = MagicMock(spec=StripeProduct)
        product.name = "Old Name"

        with patch.object(repo, "get_product", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = product
            result = await repo.update_product(db, "prod_test", name="New Name")
            assert result is product

    async def test_not_found(self):
        db = _mock_db()
        with patch.object(repo, "get_product", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = None
            result = await repo.update_product(db, "prod_nonexistent", name="Test")
            assert result is None


# ===========================================================================
# Prices
# ===========================================================================


class TestGetPrice:
    async def test_found(self):
        db = _mock_db()
        price = MagicMock(spec=StripePrice)
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = price
        db.execute = AsyncMock(return_value=result_mock)
        result = await repo.get_price(db, "price_test")
        assert result is price


class TestCreatePrice:
    async def test_success(self):
        db = _mock_db()
        result = await repo.create_price(
            db,
            stripe_price_id="price_new",
            stripe_product_id="prod_test",
            currency="usd",
            unit_amount=999,
            type_="one_time",
        )
        db.add.assert_called_once()
        db.flush.assert_called_once()


class TestDeactivatePrice:
    async def test_success(self):
        db = _mock_db()
        price = MagicMock(spec=StripePrice)
        price.active = True

        with patch.object(repo, "get_price", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = price
            result = await repo.deactivate_price(db, "price_test")
            assert result is price
            assert price.active is False

    async def test_not_found(self):
        db = _mock_db()
        with patch.object(repo, "get_price", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = None
            result = await repo.deactivate_price(db, "price_nonexistent")
            assert result is None


# ===========================================================================
# Checkout Sessions
# ===========================================================================


class TestCreateCheckoutSession:
    async def test_success(self):
        db = _mock_db()
        result = await repo.create_checkout_session(
            db,
            session_id="cs_test",
            application_id=FAKE_APP_ID,
            status="open",
            mode="payment",
        )
        db.add.assert_called_once()
        db.flush.assert_called_once()


class TestGetCheckoutSession:
    async def test_found(self):
        db = _mock_db()
        session = MagicMock(spec=CheckoutSession)
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = session
        db.execute = AsyncMock(return_value=result_mock)
        result = await repo.get_checkout_session(db, "cs_test")
        assert result is session


class TestListCheckoutSessions:
    async def test_success(self):
        db = _mock_db()
        sessions = [MagicMock(spec=CheckoutSession)]
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = sessions
        result_mock = MagicMock()
        result_mock.scalars.return_value = scalars_mock
        db.execute = AsyncMock(return_value=result_mock)
        result = await repo.list_checkout_sessions(db, user_id=FAKE_USER_ID)
        assert len(result) == 1


# ===========================================================================
# Payments
# ===========================================================================


class TestUpsertPayment:
    async def test_create_new(self):
        db = _mock_db()
        db.get = AsyncMock(return_value=None)
        result = await repo.upsert_payment(
            db,
            payment_intent_id="pi_test",
            amount=999,
            currency="usd",
            status="succeeded",
        )
        db.add.assert_called_once()

    async def test_update_existing(self):
        db = _mock_db()
        existing = MagicMock(spec=StripePayment)
        existing.status = "processing"
        db.get = AsyncMock(return_value=existing)
        result = await repo.upsert_payment(
            db,
            payment_intent_id="pi_test",
            amount=999,
            currency="usd",
            status="succeeded",
        )
        assert result is existing


# ===========================================================================
# Webhook Events
# ===========================================================================


class TestStoreWebhookEvent:
    async def test_success(self):
        db = _mock_db()
        result = await repo.store_webhook_event(
            db,
            event_id="evt_test",
            event_type="checkout.session.completed",
            data={"test": True},
        )
        db.add.assert_called_once()
        db.flush.assert_called_once()


# ===========================================================================
# Subscriptions
# ===========================================================================


class TestCreateSubscription:
    async def test_success(self):
        db = _mock_db()
        result = await repo.create_subscription(
            db,
            user_id=FAKE_USER_ID,
            stripe_subscription_id="sub_test",
            status="active",
        )
        db.add.assert_called_once()


class TestListSubscriptions:
    async def test_success(self):
        db = _mock_db()
        subs = [MagicMock(spec=Subscription)]
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = subs
        result_mock = MagicMock()
        result_mock.scalars.return_value = scalars_mock
        db.execute = AsyncMock(return_value=result_mock)
        result = await repo.list_subscriptions(db, user_id=FAKE_USER_ID)
        assert len(result) == 1


# ===========================================================================
# Payment History
# ===========================================================================


class TestListPaymentHistory:
    async def test_success(self):
        db = _mock_db()
        records = [MagicMock(spec=PaymentHistory)]
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = records
        result_mock = MagicMock()
        result_mock.scalars.return_value = scalars_mock
        db.execute = AsyncMock(return_value=result_mock)
        result = await repo.list_payment_history(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
        )
        assert len(result) == 1
        stmt = db.execute.await_args.args[0]
        compiled = stmt.compile()
        assert "payment_history.application_id" in str(stmt)
        assert FAKE_APP_ID in compiled.params.values()
        assert FAKE_USER_ID in compiled.params.values()


class TestGetPaymentRecord:
    async def test_found(self):
        db = _mock_db()
        payment_id = uuid4()
        record = MagicMock(spec=PaymentHistory)
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = record
        db.execute = AsyncMock(return_value=result_mock)
        result = await repo.get_payment_record(
            db,
            payment_id,
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
        )
        assert result is record
        stmt = db.execute.await_args.args[0]
        compiled = stmt.compile()
        assert "payment_history.application_id" in str(stmt)
        assert payment_id in compiled.params.values()
        assert FAKE_APP_ID in compiled.params.values()
        assert FAKE_USER_ID in compiled.params.values()

    async def test_not_found(self):
        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=result_mock)
        result = await repo.get_payment_record(
            db,
            uuid4(),
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
        )
        assert result is None


# ===========================================================================
# Customers
# ===========================================================================


class TestCustomers:
    async def test_get_by_user_id(self):
        db = _mock_db()
        customer = MagicMock(spec=StripeCustomer)
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = customer
        db.execute = AsyncMock(return_value=result_mock)
        result = await repo.get_customer_by_user_id(db, FAKE_USER_ID)
        assert result is customer

    async def test_create(self):
        db = _mock_db()
        result = await repo.create_customer(
            db, user_id=FAKE_USER_ID, email="test@example.com"
        )
        db.add.assert_called_once()

    async def test_get_latest_checkout_customer_id(self):
        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = "cus_test_123"
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.get_latest_checkout_customer_id(
            db, user_id=FAKE_USER_ID, application_id=FAKE_APP_ID
        )

        assert result == "cus_test_123"

    async def test_get_latest_checkout_customer_id_not_found(self):
        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.get_latest_checkout_customer_id(
            db, user_id=FAKE_USER_ID, application_id=FAKE_APP_ID
        )

        assert result is None


# ===========================================================================
# Guest Checkout Conversions
# ===========================================================================


class TestGuestConversions:
    async def test_create(self):
        db = _mock_db()
        result = await repo.create_guest_conversion(
            db,
            session_id="cs_test",
            guest_email="guest@example.com",
            converted_user_id=FAKE_USER_ID,
            converted_at=datetime.now(UTC),
        )
        db.add.assert_called_once()
        db.flush.assert_called_once()
