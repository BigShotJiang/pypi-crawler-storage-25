"""Unit tests for the Stripe webhook handler.

Tests webhook signature verification and event dispatching.
All Stripe API calls and repository calls are mocked.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.stripe import webhook_handler
from spaps_server_quickstart.domains.stripe.errors import (
    WebhookProcessingError,
    WebhookSignatureError,
)


_REPO = "spaps_server_quickstart.domains.stripe.repository"
_AFFILIATE_SERVICE = (
    "spaps_server_quickstart.domains.affiliate_referrals.service.process_commissions"
)


def _mock_checkout_context(*, app_id=None, user_id=None, payment_intent_id=None):
    row = MagicMock()
    row.application_id = app_id or uuid4()
    row.user_id = user_id or uuid4()
    row.payment_intent_id = payment_intent_id or "pi_test124"
    row.subscription_id = "sub_test123"
    row.customer_id = "cus_test"
    return row


def _mock_subscription_context(*, app_id=None, user_id=None, status="active"):
    row = MagicMock()
    row.application_id = app_id or uuid4()
    row.user_id = user_id or uuid4()
    row.status = status
    row.cancel_at = None
    row.canceled_at = None
    row.stripe_subscription_id = "sub_test123"
    return row


# ===========================================================================
# Signature Verification
# ===========================================================================


class TestVerifyWebhookSignature:
    @patch("stripe.Webhook.construct_event")
    def test_valid_signature(self, mock_construct):
        mock_construct.return_value = {
            "id": "evt_test123",
            "type": "checkout.session.completed",
            "data": {"object": {}},
        }
        result = webhook_handler.verify_webhook_signature(
            b'{"test": true}', "sig_abc", "whsec_test"
        )
        assert result["id"] == "evt_test123"

    @patch("stripe.Webhook.construct_event")
    def test_invalid_signature(self, mock_construct):
        import stripe as stripe_mod
        mock_construct.side_effect = stripe_mod.SignatureVerificationError(
            "Invalid signature", "sig_header"
        )
        with pytest.raises(WebhookSignatureError):
            webhook_handler.verify_webhook_signature(
                b'{"test": true}', "sig_invalid", "whsec_test"
            )


# ===========================================================================
# Event Dispatching
# ===========================================================================


class TestHandleWebhookEvent:
    @patch(f"{_REPO}.update_checkout_session_status", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_checkout_completed(self, mock_store, mock_get_webhook_event, mock_update):
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        mock_update.return_value = MagicMock()
        db = AsyncMock()
        event = {
            "id": "evt_123",
            "type": "checkout.session.completed",
            "data": {"object": {"id": "cs_test123"}},
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True
        mock_update.assert_called_once()

    @patch(f"{_REPO}.update_checkout_session_status", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_checkout_expired(self, mock_store, mock_get_webhook_event, mock_update):
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        mock_update.return_value = MagicMock()
        db = AsyncMock()
        event = {
            "id": "evt_124",
            "type": "checkout.session.expired",
            "data": {"object": {"id": "cs_test456"}},
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True

    @patch(f"{_REPO}.upsert_payment", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_payment_intent_succeeded(self, mock_store, mock_get_webhook_event, mock_upsert):
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        mock_upsert.return_value = MagicMock()
        db = AsyncMock()
        event = {
            "id": "evt_125",
            "type": "payment_intent.succeeded",
            "data": {
                "object": {
                    "id": "pi_test123",
                    "amount": 2999,
                    "currency": "usd",
                    "customer": "cus_test",
                    "metadata": {"app_id": str(uuid4())},
                }
            },
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True
        mock_upsert.assert_called_once()

    @patch(f"{_REPO}.get_checkout_session_by_payment_intent", new_callable=AsyncMock, create=True)
    @patch(_AFFILIATE_SERVICE, new_callable=AsyncMock)
    @patch(f"{_REPO}.upsert_payment", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_payment_intent_succeeded_triggers_affiliate_commissions(
        self,
        mock_store,
        mock_get_webhook_event,
        mock_upsert,
        mock_process_commissions,
        mock_get_checkout_by_payment_intent,
    ):
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        mock_upsert.return_value = MagicMock()
        mock_process_commissions.return_value = {"commissions": []}
        db = AsyncMock()
        app_id = str(uuid4())
        user_id = str(uuid4())
        mock_get_checkout_by_payment_intent.return_value = _mock_checkout_context(
            app_id=uuid4(), user_id=uuid4(), payment_intent_id="pi_test124"
        )
        trusted_checkout = mock_get_checkout_by_payment_intent.return_value
        event = {
            "id": "evt_125b",
            "type": "payment_intent.succeeded",
            "data": {
                "object": {
                    "id": "pi_test124",
                    "amount": 4999,
                    "currency": "usd",
                    "customer": "cus_test",
                    "metadata": {"app_id": app_id, "user_id": user_id},
                }
            },
        }

        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True
        mock_process_commissions.assert_called_once()
        kwargs = mock_process_commissions.await_args.kwargs
        assert kwargs["payer_entity_type"] == "user"
        assert kwargs["payment_reference"] == "pi_test124"
        assert str(kwargs["application_id"]) == str(trusted_checkout.application_id)
        assert str(kwargs["payer_entity_id"]) == str(trusted_checkout.user_id)

    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_payment_intent_failed(self, mock_store, mock_get_webhook_event):
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        db = AsyncMock()
        event = {
            "id": "evt_126",
            "type": "payment_intent.payment_failed",
            "data": {"object": {"id": "pi_test_fail"}},
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True

    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_subscription_created(self, mock_store, mock_get_webhook_event):
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        db = AsyncMock()
        event = {
            "id": "evt_127",
            "type": "customer.subscription.created",
            "data": {"object": {"id": "sub_test123", "status": "active"}},
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True

    @patch(_AFFILIATE_SERVICE, new_callable=AsyncMock)
    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_checkout_session_status", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_checkout_completed_triggers_affiliate_commissions(
        self,
        mock_store,
        mock_get_webhook_event,
        mock_update,
        mock_get_checkout_session,
        mock_process_commissions,
    ):
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        trusted_checkout = _mock_checkout_context(app_id=uuid4(), user_id=uuid4())
        mock_update.return_value = trusted_checkout
        mock_get_checkout_session.return_value = trusted_checkout
        mock_process_commissions.return_value = {"commissions": []}
        db = AsyncMock()
        app_id = str(uuid4())
        user_id = str(uuid4())
        event = {
            "id": "evt_checkout_aff",
            "type": "checkout.session.completed",
            "data": {
                "object": {
                    "id": "cs_test_aff",
                    "payment_intent": "pi_checkout_123",
                    "amount_total": 799,
                    "metadata": {"app_id": app_id, "user_id": user_id},
                }
            },
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True
        mock_process_commissions.assert_called_once()
        kwargs = mock_process_commissions.await_args.kwargs
        assert kwargs["payment_event_type"] == "stripe_onetime"
        assert str(kwargs["application_id"]) == str(trusted_checkout.application_id)
        assert str(kwargs["payer_entity_id"]) == str(trusted_checkout.user_id)

    @patch(f"{_REPO}.update_subscription", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_subscription_updated(self, mock_store, mock_get_webhook_event, mock_update):
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        mock_update.return_value = MagicMock()
        db = AsyncMock()
        event = {
            "id": "evt_128",
            "type": "customer.subscription.updated",
            "data": {"object": {"id": "sub_test123", "status": "past_due"}},
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True

    @patch(f"{_REPO}.update_subscription", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_subscription_deleted(self, mock_store, mock_get_webhook_event, mock_update):
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        mock_update.return_value = MagicMock()
        db = AsyncMock()
        event = {
            "id": "evt_129",
            "type": "customer.subscription.deleted",
            "data": {"object": {"id": "sub_test123"}},
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True
        mock_update.assert_called_once()

    @patch(f"{_REPO}.upsert_invoice", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_invoice_payment_succeeded(self, mock_store, mock_get_webhook_event, mock_upsert):
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        mock_upsert.return_value = MagicMock()
        db = AsyncMock()
        event = {
            "id": "evt_130",
            "type": "invoice.payment_succeeded",
            "data": {
                "object": {
                    "id": "in_test123",
                    "subscription": "sub_test123",
                    "customer": "cus_test",
                    "amount_paid": 2999,
                    "amount_due": 2999,
                    "currency": "usd",
                    "metadata": {},
                }
            },
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True
        mock_upsert.assert_called_once()

    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_invoice_payment_failed(self, mock_store, mock_get_webhook_event):
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        db = AsyncMock()
        event = {
            "id": "evt_131",
            "type": "invoice.payment_failed",
            "data": {"object": {"id": "in_test_fail"}},
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True

    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_unhandled_event(self, mock_store, mock_get_webhook_event):
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        db = AsyncMock()
        event = {
            "id": "evt_132",
            "type": "some.unknown.event",
            "data": {"object": {}},
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True

    @patch(f"{_REPO}.get_product", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_product", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_product_updated(self, mock_store, mock_get_webhook_event, mock_update, mock_get):
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        mock_get.return_value = MagicMock()
        mock_update.return_value = MagicMock()
        db = AsyncMock()
        event = {
            "id": "evt_133",
            "type": "product.updated",
            "data": {
                "object": {
                    "id": "prod_test123",
                    "name": "Updated Product",
                    "active": True,
                }
            },
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True

    @patch(f"{_REPO}.get_price", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_price_updated(self, mock_store, mock_get_webhook_event, mock_get_price):
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        price = MagicMock()
        price.active = True
        price.unit_amount = 999
        mock_get_price.return_value = price
        db = AsyncMock()
        db.flush = AsyncMock()
        event = {
            "id": "evt_134",
            "type": "price.updated",
            "data": {
                "object": {
                    "id": "price_test123",
                    "active": True,
                    "unit_amount": 1999,
                }
            },
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True


class TestDayrateCheckoutReconciliation:
    @patch("spaps_server_quickstart.domains.stripe.webhook_handler.security_service.create_alert", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.stripe.webhook_handler.dayrate_service.confirm_paid_bookings_for_checkout_session", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_checkout_session_status", new_callable=AsyncMock)
    @patch(f"{_REPO}.mark_webhook_event_processed", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    async def test_dayrate_checkout_completed_confirms_matching_bookings(
        self,
        mock_get_webhook_event,
        mock_store_webhook_event,
        mock_mark_processed,
        mock_update_checkout_session_status,
        mock_confirm_dayrate_bookings,
        mock_create_alert,
    ):
        mock_get_webhook_event.return_value = None
        mock_store_webhook_event.return_value = MagicMock()
        mock_mark_processed.return_value = MagicMock()
        mock_update_checkout_session_status.return_value = None
        mock_confirm_dayrate_bookings.return_value = {
            "matched": 1,
            "confirmed": 1,
            "bookings": [{"id": str(uuid4())}],
        }
        db = AsyncMock()
        event = {
            "id": "evt_dayrate_1",
            "type": "checkout.session.completed",
            "data": {
                "object": {
                    "id": "cs_dayrate_123",
                    "payment_intent": "pi_dayrate_123",
                    "metadata": {
                        "dayrate_booking": "true",
                        "application_id": str(uuid4()),
                        "date": "2026-01-10",
                        "slot": "AM",
                        "client_email": "client@example.com",
                    },
                }
            },
        }

        result = await webhook_handler.handle_webhook_event(db, event=event)

        assert result == {"received": True}
        kwargs = mock_confirm_dayrate_bookings.await_args.kwargs
        assert kwargs["stripe_session_id"] == "cs_dayrate_123"
        assert kwargs["stripe_payment_intent_id"] == "pi_dayrate_123"
        mock_create_alert.assert_not_awaited()

    @patch("spaps_server_quickstart.domains.stripe.webhook_handler.security_service.create_alert", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.stripe.webhook_handler.dayrate_service.confirm_paid_bookings_for_checkout_session", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_checkout_session_status", new_callable=AsyncMock)
    @patch(f"{_REPO}.mark_webhook_event_processed", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    async def test_dayrate_checkout_without_matching_booking_creates_alert(
        self,
        mock_get_webhook_event,
        mock_store_webhook_event,
        mock_mark_processed,
        mock_update_checkout_session_status,
        mock_confirm_dayrate_bookings,
        mock_create_alert,
    ):
        app_id = str(uuid4())
        mock_get_webhook_event.return_value = None
        mock_store_webhook_event.return_value = MagicMock()
        mock_mark_processed.return_value = MagicMock()
        mock_update_checkout_session_status.return_value = None
        mock_confirm_dayrate_bookings.return_value = {
            "matched": 0,
            "confirmed": 0,
            "bookings": [],
        }
        mock_create_alert.return_value = {"id": str(uuid4())}
        db = AsyncMock()
        event = {
            "id": "evt_dayrate_missing",
            "type": "checkout.session.completed",
            "data": {
                "object": {
                    "id": "cs_dayrate_missing",
                    "payment_intent": "pi_dayrate_missing",
                    "metadata": {
                        "dayrate_booking": "true",
                        "application_id": app_id,
                        "date": "2026-01-10",
                        "slot": "PM",
                        "client_email": "client@example.com",
                    },
                }
            },
        }

        result = await webhook_handler.handle_webhook_event(db, event=event)

        assert result == {"received": True}
        kwargs = mock_create_alert.await_args.kwargs
        assert kwargs["alert_type"] == "dayrate_checkout_reconciliation_failure"
        assert kwargs["severity"] == "high"
        assert kwargs["details"]["stripe_session_id"] == "cs_dayrate_missing"
        assert kwargs["details"]["application_id"] == app_id

    @patch("spaps_server_quickstart.domains.stripe.webhook_handler.dayrate_service.confirm_paid_bookings_for_checkout_session", new_callable=AsyncMock)
    @patch(f"{_REPO}.mark_webhook_event_processed", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    async def test_duplicate_dayrate_event_short_circuits(
        self,
        mock_get_webhook_event,
        mock_store_webhook_event,
        mock_mark_processed,
        mock_confirm_dayrate_bookings,
    ):
        existing_event = MagicMock()
        existing_event.processed_at = object()
        mock_get_webhook_event.return_value = existing_event

        result = await webhook_handler.handle_webhook_event(
            AsyncMock(),
            event={
                "id": "evt_dayrate_duplicate",
                "type": "checkout.session.completed",
                "data": {"object": {"id": "cs_dayrate_duplicate"}},
            },
        )

        assert result == {"received": True, "duplicate": True}
        mock_store_webhook_event.assert_not_awaited()
        mock_mark_processed.assert_not_awaited()
        mock_confirm_dayrate_bookings.assert_not_awaited()

    @patch("spaps_server_quickstart.domains.stripe.webhook_handler.dayrate_service.expire_pending_bookings_for_checkout_session", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_checkout_session_status", new_callable=AsyncMock)
    @patch(f"{_REPO}.mark_webhook_event_processed", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    async def test_dayrate_checkout_expired_expires_matching_bookings(
        self,
        mock_get_webhook_event,
        mock_store_webhook_event,
        mock_mark_processed,
        mock_update_checkout_session_status,
        mock_expire_dayrate_bookings,
    ):
        mock_get_webhook_event.return_value = None
        mock_store_webhook_event.return_value = MagicMock()
        mock_mark_processed.return_value = MagicMock()
        mock_update_checkout_session_status.return_value = None
        mock_expire_dayrate_bookings.return_value = {
            "matched": 1,
            "expired": 1,
            "bookings": [{"id": str(uuid4())}],
        }

        result = await webhook_handler.handle_webhook_event(
            AsyncMock(),
            event={
                "id": "evt_dayrate_expired",
                "type": "checkout.session.expired",
                "data": {
                    "object": {
                        "id": "cs_dayrate_expired",
                        "metadata": {
                            "dayrate_booking": "true",
                        },
                    }
                },
            },
        )

        assert result == {"received": True}
        kwargs = mock_expire_dayrate_bookings.await_args.kwargs
        assert kwargs["stripe_session_id"] == "cs_dayrate_expired"


# ===========================================================================
# Error Handling
# ===========================================================================


class TestWebhookErrorHandling:
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_store_failure_raises_processing_error(self, mock_store, mock_get_webhook_event):
        mock_get_webhook_event.return_value = None
        mock_store.side_effect = Exception("DB error")
        db = AsyncMock()
        event = {
            "id": "evt_err1",
            "type": "some.unknown.event",
            "data": {"object": {}},
        }
        with pytest.raises(WebhookProcessingError):
            await webhook_handler.handle_webhook_event(db, event=event)

    @patch(f"{_REPO}.update_checkout_session_status", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_handler_failure_raises(self, mock_store, mock_get_webhook_event, mock_update):
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        mock_update.side_effect = Exception("Handler error")
        db = AsyncMock()
        event = {
            "id": "evt_err2",
            "type": "checkout.session.completed",
            "data": {"object": {"id": "cs_fail"}},
        }
        with pytest.raises(WebhookProcessingError):
            await webhook_handler.handle_webhook_event(db, event=event)


# ===========================================================================
# Entitlement Events
# ===========================================================================


class TestEntitlementEvents:
    @patch("spaps_server_quickstart.domains.entitlements.service.process_stripe_checkout", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_checkout_session_status", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_checkout_completed_with_entitlement_grant(
        self,
        mock_store,
        mock_get_webhook_event,
        mock_update,
        mock_get_checkout_session,
        mock_entitlement,
    ):
        """checkout.session.completed triggers entitlement grant."""
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        trusted_checkout = _mock_checkout_context(app_id=uuid4(), user_id=uuid4())
        mock_update.return_value = trusted_checkout
        mock_get_checkout_session.return_value = trusted_checkout
        mock_entitlement.return_value = None
        db = AsyncMock()
        app_id = str(uuid4())
        event = {
            "id": "evt_ent1",
            "type": "checkout.session.completed",
            "data": {
                "object": {
                    "id": "cs_test_ent",
                    "metadata": {"app_id": app_id},
                    "line_items": {"data": [{"price": {"id": "price_test"}}]},
                }
            },
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True
        mock_entitlement.assert_called_once()
        assert mock_entitlement.await_args.kwargs["app_id"] == trusted_checkout.application_id
        assert mock_entitlement.await_args.kwargs["trusted_user_id"] == trusted_checkout.user_id

    @patch("spaps_server_quickstart.domains.entitlements.service.process_stripe_checkout", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_checkout_session_status", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_checkout_entitlement_failure_raises(self, mock_store, mock_get_webhook_event, mock_update, mock_get_checkout_session, mock_entitlement):
        """Entitlement grant failure bubbles so Stripe retries."""
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        trusted_checkout = _mock_checkout_context(app_id=uuid4(), user_id=uuid4())
        mock_update.return_value = trusted_checkout
        mock_get_checkout_session.return_value = trusted_checkout
        mock_entitlement.side_effect = Exception("Entitlement error")
        db = AsyncMock()
        app_id = str(uuid4())
        event = {
            "id": "evt_ent2",
            "type": "checkout.session.completed",
            "data": {
                "object": {
                    "id": "cs_test_ent_fail",
                    "metadata": {"app_id": app_id},
                }
            },
        }
        with pytest.raises(WebhookProcessingError):
            await webhook_handler.handle_webhook_event(db, event=event)

    @patch("spaps_server_quickstart.domains.entitlements.service.process_stripe_subscription", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_subscription_by_stripe_id", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_subscription_created_with_entitlement(
        self, mock_store, mock_get_webhook_event, mock_get_subscription, mock_entitlement
    ):
        """subscription.created triggers entitlement grant."""
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        trusted_subscription = _mock_subscription_context(app_id=uuid4(), user_id=uuid4())
        mock_get_subscription.return_value = trusted_subscription
        mock_entitlement.return_value = None
        db = AsyncMock()
        app_id = str(uuid4())
        event = {
            "id": "evt_sub_ent1",
            "type": "customer.subscription.created",
            "data": {
                "object": {
                    "id": "sub_test_ent",
                    "status": "active",
                    "metadata": {"app_id": app_id},
                }
            },
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True
        mock_entitlement.assert_called_once()
        assert mock_entitlement.await_args.kwargs["app_id"] == trusted_subscription.application_id
        assert mock_entitlement.await_args.kwargs["trusted_user_id"] == trusted_subscription.user_id

    @patch("spaps_server_quickstart.domains.entitlements.service.process_stripe_subscription", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_subscription", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_subscription_updated_with_entitlement(
        self, mock_store, mock_get_webhook_event, mock_update_sub, mock_entitlement
    ):
        """subscription.updated triggers entitlement update."""
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        trusted_subscription = _mock_subscription_context(app_id=uuid4(), user_id=uuid4())
        mock_update_sub.return_value = trusted_subscription
        mock_entitlement.return_value = None
        db = AsyncMock()
        app_id = str(uuid4())
        event = {
            "id": "evt_sub_ent2",
            "type": "customer.subscription.updated",
            "data": {
                "object": {
                    "id": "sub_test_ent_upd",
                    "status": "past_due",
                    "metadata": {"app_id": app_id},
                }
            },
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True
        assert mock_entitlement.await_args.kwargs["app_id"] == trusted_subscription.application_id
        assert mock_entitlement.await_args.kwargs["trusted_user_id"] == trusted_subscription.user_id

    @patch("spaps_server_quickstart.domains.entitlements.service.process_stripe_subscription", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_subscription", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_subscription_deleted_with_entitlement(
        self, mock_store, mock_get_webhook_event, mock_update_sub, mock_entitlement
    ):
        """subscription.deleted triggers entitlement removal."""
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        trusted_subscription = _mock_subscription_context(app_id=uuid4(), user_id=uuid4(), status="canceled")
        mock_update_sub.return_value = trusted_subscription
        mock_entitlement.return_value = None
        db = AsyncMock()
        app_id = str(uuid4())
        event = {
            "id": "evt_sub_ent3",
            "type": "customer.subscription.deleted",
            "data": {
                "object": {
                    "id": "sub_test_ent_del",
                    "status": "canceled",
                    "metadata": {"app_id": app_id},
                }
            },
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True
        assert mock_entitlement.await_args.kwargs["app_id"] == trusted_subscription.application_id
        assert mock_entitlement.await_args.kwargs["trusted_user_id"] == trusted_subscription.user_id

    @patch("spaps_server_quickstart.domains.entitlements.service.process_stripe_invoice", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_subscription_by_stripe_id", new_callable=AsyncMock)
    @patch(f"{_REPO}.upsert_invoice", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_invoice_payment_with_entitlement_renewal(
        self, mock_store, mock_get_webhook_event, mock_upsert, mock_get_subscription, mock_entitlement
    ):
        """invoice.payment_succeeded triggers entitlement renewal."""
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        mock_upsert.return_value = MagicMock()
        trusted_subscription = _mock_subscription_context(app_id=uuid4(), user_id=uuid4())
        mock_get_subscription.return_value = trusted_subscription
        mock_entitlement.return_value = None
        db = AsyncMock()
        app_id = str(uuid4())
        event = {
            "id": "evt_inv_ent",
            "type": "invoice.payment_succeeded",
            "data": {
                "object": {
                    "id": "in_test_ent",
                    "subscription": "sub_test123",
                    "customer": "cus_test",
                    "amount_paid": 2999,
                    "amount_due": 2999,
                    "currency": "usd",
                    "metadata": {"app_id": app_id},
                }
            },
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True
        mock_entitlement.assert_called_once()
        assert mock_entitlement.await_args.kwargs["app_id"] == trusted_subscription.application_id


# ===========================================================================
# Product/Price Edge Cases
# ===========================================================================


class TestProductPriceEvents:
    @patch(f"{_REPO}.get_product", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_product_created_without_local_record(self, mock_store, mock_get_webhook_event, mock_get):
        """product.created skipped if no local record."""
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        mock_get.return_value = None
        db = AsyncMock()
        event = {
            "id": "evt_prod1",
            "type": "product.created",
            "data": {
                "object": {
                    "id": "prod_new",
                    "name": "New Product",
                    "active": True,
                }
            },
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True

    @patch(f"{_REPO}.get_product", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_product_event_without_id(self, mock_store, mock_get_webhook_event, mock_get):
        """product event without id is handled gracefully."""
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        db = AsyncMock()
        event = {
            "id": "evt_prod2",
            "type": "product.updated",
            "data": {
                "object": {
                    # Missing "id"
                    "name": "Product",
                    "active": True,
                }
            },
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True

    @patch(f"{_REPO}.get_price", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_price_created_without_local_record(self, mock_store, mock_get_webhook_event, mock_get):
        """price.created skipped if no local record."""
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        mock_get.return_value = None
        db = AsyncMock()
        event = {
            "id": "evt_price1",
            "type": "price.created",
            "data": {
                "object": {
                    "id": "price_new",
                    "unit_amount": 999,
                    "active": True,
                }
            },
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True

    @patch(f"{_REPO}.get_price", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.store_webhook_event", new_callable=AsyncMock)
    async def test_price_event_without_id(self, mock_store, mock_get_webhook_event, mock_get):
        """price event without id is handled gracefully."""
        mock_store.return_value = MagicMock()
        mock_get_webhook_event.return_value = None
        db = AsyncMock()
        event = {
            "id": "evt_price2",
            "type": "price.updated",
            "data": {
                "object": {
                    # Missing "id"
                    "unit_amount": 999,
                    "active": True,
                }
            },
        }
        result = await webhook_handler.handle_webhook_event(db, event=event)
        assert result["received"] is True


# ===========================================================================
# Edge Cases & Invalid Exceptions
# ===========================================================================


class TestWebhookEdgeCases:
    @patch("stripe.Webhook.construct_event")
    def test_verify_generic_exception(self, mock_construct):
        """Generic exception in signature verification raises WebhookSignatureError."""
        mock_construct.side_effect = ValueError("Bad format")
        with pytest.raises(WebhookSignatureError, match="verification failed"):
            webhook_handler.verify_webhook_signature(
                b'{"test": true}', "sig_bad", "whsec_test"
            )
