"""Hardening regressions for Stripe metadata and webhook processing."""

from __future__ import annotations

from datetime import UTC, datetime
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest
from pydantic import ValidationError as PydanticValidationError

from spaps_server_quickstart.domains.stripe import guest_checkout, service, webhook_handler
from spaps_server_quickstart.domains.stripe.errors import (
    WebhookProcessingError,
)
from spaps_server_quickstart.domains.stripe.schemas import CreateCheckoutSessionRequest


FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()

_SERVICE_REPO = "spaps_server_quickstart.domains.stripe.service.repo"
_GUEST_REPO = "spaps_server_quickstart.domains.stripe.guest_checkout.repo"
_WEBHOOK_REPO = "spaps_server_quickstart.domains.stripe.repository"
_AFFILIATE_SERVICE = (
    "spaps_server_quickstart.domains.affiliate_referrals.service.process_commissions"
)


def _checkout_session_row(
    *,
    application_id: UUID = FAKE_APP_ID,
    user_id: UUID | None = FAKE_USER_ID,
    payment_intent_id: str | None = "pi_checkout_123",
) -> MagicMock:
    row = MagicMock()
    row.session_id = "cs_checkout_123"
    row.application_id = application_id
    row.user_id = user_id
    row.payment_intent_id = payment_intent_id
    row.subscription_id = "sub_checkout_123"
    row.customer_id = "cus_checkout_123"
    row.metadata_ = {
        "app_id": str(application_id),
        **({"user_id": str(user_id)} if user_id else {}),
    }
    row.status = "open"
    row.amount_total = 1999
    row.currency = "usd"
    row.payment_status = "unpaid"
    return row


def _mock_billing_context(*, secret_key: str, source: str) -> SimpleNamespace:
    return SimpleNamespace(
        stripe_secret_key=secret_key,
        source=source,
        billing_account_id=uuid4() if source == "billing_account" else None,
    )


class TestMetadataSpreadHardening:
    @patch(f"{_SERVICE_REPO}.get_product", new_callable=AsyncMock)
    @patch(f"{_SERVICE_REPO}.get_price", new_callable=AsyncMock)
    @patch(
        "spaps_server_quickstart.domains.stripe.service._resolve_checkout_billing_context",
        new_callable=AsyncMock,
    )
    @patch("spaps_server_quickstart.domains.stripe.service._run_stripe_call", new_callable=AsyncMock)
    @patch(f"{_SERVICE_REPO}.create_checkout_session", new_callable=AsyncMock)
    async def test_checkout_session_server_metadata_wins(
        self,
        mock_repo,
        mock_run_stripe_call,
        mock_resolve_billing_context,
        mock_get_price,
        mock_get_product,
    ):
        stripe_session = MagicMock(
            id="cs_test_hardened",
            status="open",
            url="https://checkout.stripe.com/test",
            amount_total=2999,
            currency="usd",
        )
        stripe_session.get = lambda key, default=None: getattr(stripe_session, key, default)
        mock_run_stripe_call.return_value = stripe_session
        mock_get_price.return_value = MagicMock(
            stripe_price_id="price_123",
            stripe_product_id="prod_123",
            active=True,
        )
        mock_get_product.return_value = MagicMock(
            stripe_product_id="prod_123",
            application_id=FAKE_APP_ID,
            active=True,
        )
        mock_resolve_billing_context.return_value = _mock_billing_context(
            secret_key="sk_test_checkout_default",
            source="legacy_env_default",
        )

        session_row = _checkout_session_row()
        session_row.session_id = stripe_session.id
        session_row.metadata_ = {
            "app_id": str(FAKE_APP_ID),
            "user_id": str(FAKE_USER_ID),
            "coupon": "SAVE10",
        }
        mock_repo.return_value = session_row

        attacker_app_id = uuid4()
        attacker_user_id = uuid4()
        result = await service.create_checkout_session(
            AsyncMock(),
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
            line_items=[{"price_id": "price_123", "quantity": 1}],
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            metadata={
                "app_id": str(attacker_app_id),
                "user_id": str(attacker_user_id),
                "coupon": "SAVE10",
            },
        )

        assert result["id"] == "cs_test_hardened"
        stripe_metadata = mock_run_stripe_call.await_args.args[1]["metadata"]
        assert stripe_metadata["app_id"] == str(FAKE_APP_ID)
        assert stripe_metadata["user_id"] == str(FAKE_USER_ID)
        assert stripe_metadata["coupon"] == "SAVE10"
        repo_metadata = mock_repo.await_args.kwargs["metadata"]
        assert repo_metadata["app_id"] == str(FAKE_APP_ID)
        assert repo_metadata["user_id"] == str(FAKE_USER_ID)
        assert repo_metadata["coupon"] == "SAVE10"

    @patch(f"{_SERVICE_REPO}.get_product", new_callable=AsyncMock)
    @patch(f"{_SERVICE_REPO}.get_price", new_callable=AsyncMock)
    @patch(
        "spaps_server_quickstart.domains.stripe.guest_checkout._resolve_checkout_billing_context",
        new_callable=AsyncMock,
    )
    @patch("spaps_server_quickstart.domains.stripe.guest_checkout.stripe.StripeClient")
    @patch(f"{_GUEST_REPO}.create_checkout_session", new_callable=AsyncMock)
    async def test_guest_checkout_server_metadata_wins(
        self,
        mock_repo,
        mock_stripe_client,
        mock_resolve_billing_context,
        mock_get_price,
        mock_get_product,
    ):
        stripe_session = MagicMock(
            id="cs_guest_hardened",
            status="open",
            url="https://checkout.stripe.com/guest",
            amount_total=1999,
            currency="usd",
        )
        stripe_session.get = lambda key, default=None: getattr(stripe_session, key, default)
        mock_stripe_client.return_value.checkout.sessions.create.return_value = (
            stripe_session
        )
        mock_get_price.return_value = MagicMock(
            stripe_price_id="price_123",
            stripe_product_id="prod_123",
            active=True,
        )
        mock_get_product.return_value = MagicMock(
            stripe_product_id="prod_123",
            application_id=FAKE_APP_ID,
            active=True,
        )
        mock_resolve_billing_context.return_value = _mock_billing_context(
            secret_key="sk_test_guest_default",
            source="legacy_env_default",
        )

        guest_row = _checkout_session_row(application_id=FAKE_APP_ID, user_id=None)
        guest_row.session_id = stripe_session.id
        guest_row.metadata_ = {
            "app_id": str(FAKE_APP_ID),
            "is_guest": "true",
            "campaign": "spring",
        }
        guest_row.customer_email = "guest@example.com"
        guest_row.expires_at = datetime.now(UTC)
        mock_repo.return_value = guest_row

        result = await guest_checkout.create_guest_checkout_session(
            AsyncMock(),
            application_id=FAKE_APP_ID,
            customer_email="guest@example.com",
            line_items=[{"price_id": "price_123", "quantity": 1}],
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            metadata={
                "app_id": str(uuid4()),
                "is_guest": "false",
                "campaign": "spring",
            },
        )

        assert result["id"] == "cs_guest_hardened"
        stripe_metadata = (
            mock_stripe_client.return_value.checkout.sessions.create.call_args.args[0][
                "metadata"
            ]
        )
        assert stripe_metadata["app_id"] == str(FAKE_APP_ID)
        assert stripe_metadata["is_guest"] == "true"
        assert stripe_metadata["campaign"] == "spring"
        repo_metadata = mock_repo.await_args.kwargs["metadata"]
        assert repo_metadata["app_id"] == str(FAKE_APP_ID)
        assert repo_metadata["is_guest"] == "true"
        assert repo_metadata["campaign"] == "spring"

    def test_checkout_request_rejects_reserved_metadata_keys(self):
        with pytest.raises(PydanticValidationError, match="reserved metadata keys"):
            CreateCheckoutSessionRequest(
                mode="payment",
                line_items=[{"price_id": "price_123", "quantity": 1}],
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
                metadata={"app_id": str(uuid4())},
            )


class TestWebhookHardening:
    @patch(f"{_WEBHOOK_REPO}.update_checkout_session_status", new_callable=AsyncMock)
    @patch(f"{_WEBHOOK_REPO}.store_webhook_event", new_callable=AsyncMock)
    @patch(f"{_WEBHOOK_REPO}.get_webhook_event", new_callable=AsyncMock)
    async def test_duplicate_event_short_circuits_before_dispatch(
        self,
        mock_get_webhook_event,
        mock_store_webhook_event,
        mock_update_checkout_session_status,
    ):
        mock_get_webhook_event.side_effect = [None, MagicMock()]
        mock_store_webhook_event.return_value = MagicMock()
        mock_update_checkout_session_status.return_value = MagicMock()

        event = {
            "id": "evt_duplicate_123",
            "type": "checkout.session.expired",
            "data": {"object": {"id": "cs_checkout_123"}},
        }
        db = AsyncMock()

        first = await webhook_handler.handle_webhook_event(db, event=event)
        second = await webhook_handler.handle_webhook_event(db, event=event)

        assert first == {"received": True}
        assert second == {"received": True, "duplicate": True}
        mock_store_webhook_event.assert_awaited_once()
        mock_update_checkout_session_status.assert_awaited_once()

    @patch(_AFFILIATE_SERVICE, new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.entitlements.service.process_stripe_checkout", new_callable=AsyncMock)
    @patch(f"{_WEBHOOK_REPO}.get_checkout_session", new_callable=AsyncMock)
    @patch(f"{_WEBHOOK_REPO}.update_checkout_session_status", new_callable=AsyncMock)
    @patch(f"{_WEBHOOK_REPO}.store_webhook_event", new_callable=AsyncMock)
    @patch(f"{_WEBHOOK_REPO}.get_webhook_event", new_callable=AsyncMock)
    async def test_checkout_completed_uses_stored_context_not_event_metadata(
        self,
        mock_get_webhook_event,
        mock_store_webhook_event,
        mock_update_checkout_session_status,
        mock_get_checkout_session,
        mock_process_checkout,
        mock_process_commissions,
    ):
        trusted_checkout = _checkout_session_row()
        mock_get_webhook_event.return_value = None
        mock_store_webhook_event.return_value = MagicMock()
        mock_update_checkout_session_status.return_value = trusted_checkout
        mock_get_checkout_session.return_value = trusted_checkout
        mock_process_checkout.return_value = []
        mock_process_commissions.return_value = {"commissions": []}

        event = {
            "id": "evt_checkout_context",
            "type": "checkout.session.completed",
            "data": {
                "object": {
                    "id": "cs_checkout_123",
                    "payment_intent": "pi_checkout_123",
                    "amount_total": 2500,
                    "customer": "cus_checkout_123",
                    "metadata": {
                        "app_id": str(uuid4()),
                        "user_id": str(uuid4()),
                    },
                }
            },
        }

        result = await webhook_handler.handle_webhook_event(AsyncMock(), event=event)

        assert result == {"received": True}
        process_kwargs = mock_process_checkout.await_args.kwargs
        assert process_kwargs["app_id"] == FAKE_APP_ID
        assert process_kwargs["trusted_user_id"] == FAKE_USER_ID
        affiliate_kwargs = mock_process_commissions.await_args.kwargs
        assert str(affiliate_kwargs["application_id"]) == str(FAKE_APP_ID)
        assert str(affiliate_kwargs["payer_entity_id"]) == str(FAKE_USER_ID)

    @patch("spaps_server_quickstart.domains.entitlements.service.process_stripe_checkout", new_callable=AsyncMock)
    @patch(f"{_WEBHOOK_REPO}.get_checkout_session", new_callable=AsyncMock)
    @patch(f"{_WEBHOOK_REPO}.update_checkout_session_status", new_callable=AsyncMock)
    @patch(f"{_WEBHOOK_REPO}.store_webhook_event", new_callable=AsyncMock)
    @patch(f"{_WEBHOOK_REPO}.get_webhook_event", new_callable=AsyncMock)
    async def test_entitlement_projection_failure_returns_5xx_for_retry(
        self,
        mock_get_webhook_event,
        mock_store_webhook_event,
        mock_update_checkout_session_status,
        mock_get_checkout_session,
        mock_process_checkout,
    ):
        mock_get_webhook_event.return_value = None
        mock_store_webhook_event.return_value = MagicMock()
        mock_update_checkout_session_status.return_value = _checkout_session_row()
        mock_get_checkout_session.return_value = _checkout_session_row()
        mock_process_checkout.side_effect = RuntimeError("projection failed")

        event = {
            "id": "evt_checkout_retry",
            "type": "checkout.session.completed",
            "data": {"object": {"id": "cs_checkout_123"}},
        }

        with pytest.raises(WebhookProcessingError):
            await webhook_handler.handle_webhook_event(AsyncMock(), event=event)
